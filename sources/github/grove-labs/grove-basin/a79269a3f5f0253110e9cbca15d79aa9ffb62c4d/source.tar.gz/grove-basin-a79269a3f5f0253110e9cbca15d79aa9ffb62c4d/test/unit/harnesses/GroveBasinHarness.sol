// SPDX-License-Identifier: AGPL-3.0-or-later
pragma solidity ^0.8.24;

import { GroveBasin } from "src/GroveBasin.sol";

contract GroveBasinHarness is GroveBasin {

    constructor(
        address owner_,
        address liquidityProvider_,
        address swapToken_,
        address collateralToken_,
        address creditToken_,
        address swapTokenRateProvider_,
        address collateralTokenRateProvider_,
        address creditTokenRateProvider_
    )
        GroveBasin(owner_, liquidityProvider_, swapToken_, collateralToken_, creditToken_, swapTokenRateProvider_, collateralTokenRateProvider_, creditTokenRateProvider_) {}

    function getSwapTokenValue(uint256 amount, bool roundUp) external view returns (uint256) {
        return _getAssetValue(swapToken, amount, roundUp);
    }

    function getCollateralTokenValue(uint256 amount, bool roundUp) external view returns (uint256) {
        return _getAssetValue(collateralToken, amount, roundUp);
    }

    function getCreditTokenValue(uint256 amount, bool roundUp) external view returns (uint256) {
        return _getAssetValue(creditToken, amount, roundUp);
    }

    function getAssetCustodian(address asset) external view returns (address) {
        return _getAssetCustodian(asset);
    }

    function getConversionRate(address rateProvider) external view returns (uint256) {
        return _getConversionRate(rateProvider);
    }

    function accrueFeeShares(address asset, uint256 feeAmount) external {
        _accrueFeeShares(asset, feeAmount);
    }

    function setFeeClaimerDirect(address newFeeClaimer) external {
        feeClaimer = newFeeClaimer;
    }

}
