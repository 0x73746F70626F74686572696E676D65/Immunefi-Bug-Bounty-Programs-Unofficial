// Copyright 2021-2023 Protocol Labs
// Copyright 2019-2022 ChainSafe Systems
// SPDX-License-Identifier: Apache-2.0, MIT

use fvm::externs::Rand;
use fvm_shared::clock::ChainEpoch;

use crate::vector::{RandomnessKind, RandomnessMatch, RandomnessRule};

/// Takes recorded randomness and replays it when input parameters match.
/// When there's no match, it falls back to TestFallbackRand, which returns a
/// fixed output.
pub struct ReplayingRand {
    pub recorded: Vec<RandomnessMatch>,
    pub fallback: TestFallbackRand,
}

/// Implements the Rand extern and returns static values as randomness outputs
/// when there's a vector miss.
pub struct TestFallbackRand;

impl Rand for TestFallbackRand {
    fn get_chain_randomness(&self, _: ChainEpoch) -> anyhow::Result<[u8; 32]> {
        Ok(*b"i_am_random_____i_am_random_____")
    }

    fn get_beacon_randomness(&self, _: ChainEpoch) -> anyhow::Result<[u8; 32]> {
        Ok(*b"i_am_random_____i_am_random_____")
    }
}

impl ReplayingRand {
    pub fn new(recorded: &[RandomnessMatch]) -> Self {
        Self {
            recorded: Vec::from(recorded),
            fallback: TestFallbackRand,
        }
    }

    pub fn matches(&self, requested: RandomnessRule) -> Option<[u8; 32]> {
        for other in &self.recorded {
            if other.on == requested {
                let mut randomness = [0u8; 32];
                randomness.copy_from_slice(&other.ret);
                return Some(randomness);
            }
        }
        None
    }
}

impl Rand for ReplayingRand {
    fn get_chain_randomness(&self, epoch: ChainEpoch) -> anyhow::Result<[u8; 32]> {
        let rule = RandomnessRule {
            kind: RandomnessKind::Chain,
            epoch,
        };
        if let Some(bz) = self.matches(rule) {
            Ok(bz)
        } else {
            self.fallback.get_chain_randomness(epoch)
        }
    }
    fn get_beacon_randomness(&self, epoch: ChainEpoch) -> anyhow::Result<[u8; 32]> {
        let rule = RandomnessRule {
            kind: RandomnessKind::Beacon,
            epoch,
        };
        if let Some(bz) = self.matches(rule) {
            Ok(bz)
        } else {
            self.fallback.get_beacon_randomness(epoch)
        }
    }
}
