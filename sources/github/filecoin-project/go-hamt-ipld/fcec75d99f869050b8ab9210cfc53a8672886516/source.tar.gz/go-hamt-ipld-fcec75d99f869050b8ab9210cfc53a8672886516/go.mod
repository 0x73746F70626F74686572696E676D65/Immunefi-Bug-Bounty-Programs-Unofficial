module github.com/filecoin-project/go-hamt-ipld/v3

go 1.26.0

require (
	github.com/ipfs/go-block-format v0.2.4
	github.com/ipfs/go-cid v0.6.2
	github.com/ipfs/go-ipld-cbor v0.3.0
	github.com/spaolacci/murmur3 v1.1.0
	github.com/stretchr/testify v1.12.1
	github.com/whyrusleeping/cbor-gen v0.3.1
	golang.org/x/sync v0.23.0
	golang.org/x/sys v0.46.0 // indirect
	golang.org/x/xerrors v0.0.0-20240903120638-7835f813f4da
)

require (
	github.com/ipfs/boxo v0.41.0 // indirect
	github.com/ipfs/go-ipld-format v0.6.3 // indirect
	github.com/klauspost/cpuid/v2 v2.3.0 // indirect
	github.com/minio/sha256-simd v1.0.1 // indirect
	github.com/mr-tron/base58 v1.3.0 // indirect
	github.com/multiformats/go-base32 v0.1.0 // indirect
	github.com/multiformats/go-base36 v0.2.0 // indirect
	github.com/multiformats/go-multibase v0.3.0 // indirect
	github.com/multiformats/go-multihash v0.2.3 // indirect
	github.com/multiformats/go-varint v0.1.0 // indirect
	github.com/polydawn/refmt v0.90.0 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
	golang.org/x/crypto v0.53.0 // indirect
	lukechampine.com/blake3 v1.4.1 // indirect
)
