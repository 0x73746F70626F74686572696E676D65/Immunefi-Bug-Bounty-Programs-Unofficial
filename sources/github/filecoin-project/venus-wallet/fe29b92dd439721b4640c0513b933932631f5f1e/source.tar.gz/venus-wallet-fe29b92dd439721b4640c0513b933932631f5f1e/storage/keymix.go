package storage

import (
	"bytes"
	"context"
	"errors"
	"sync"

	"github.com/filecoin-project/go-jsonrpc/auth"
	"github.com/filecoin-project/venus-wallet/config"
	"github.com/filecoin-project/venus-wallet/crypto"
	"github.com/filecoin-project/venus-wallet/crypto/aes"
	"github.com/filecoin-project/venus-wallet/errcode"

	walletAPI "github.com/filecoin-project/venus/venus-shared/api/wallet"
	"github.com/filecoin-project/venus/venus-shared/types"

	"github.com/ipfs-force-community/sophon-auth/core"
)

var (
	ErrLocked          = errors.New("wallet locked")
	ErrPasswordEmpty   = errors.New("password not set")
	ErrInvalidPassword = errors.New("password mismatch")
	ErrPasswordExist   = errors.New("the password already exists")
	ErrAlreadyUnlocked = errors.New("wallet already unlocked")
	ErrAlreadyLocked   = errors.New("wallet already locked")
)

var EmptyPassword []byte

type DecryptFunc func(keyJson []byte, keyType types.KeyType) (crypto.PrivateKey, error)

// KeyMiddleware the middleware bridging strategy and wallet
type KeyMiddleware interface {
	// Encrypt aes encrypt key
	Encrypt(password []byte, key crypto.PrivateKey) (*aes.EncryptedKey, error)
	// Decrypt aes decrypt key
	Decrypt(password []byte, key *aes.EncryptedKey) (crypto.PrivateKey, error)
	// Next Check the password has been set and the wallet is locked
	Next() error
	// CheckToken check if the `strategy` token has all permissions
	CheckToken(ctx context.Context) error
	walletAPI.IWalletLock
}

type KeyMixLayer struct {
	m        sync.RWMutex
	locked   bool
	password []byte
	scryptN  int // aes cryptographic variable
	scryptP  int // aes cryptographic variable
}

func NewKeyMiddleware(cnf *config.CryptoFactor) KeyMiddleware {
	return &KeyMixLayer{
		locked:   true,
		password: nil,
		scryptN:  cnf.ScryptN,
		scryptP:  cnf.ScryptP,
	}
}

func (o *KeyMixLayer) SetPassword(ctx context.Context, password string) error {
	o.m.Lock()
	defer o.m.Unlock()
	if len(o.password) != 0 {
		return ErrPasswordExist
	}
	hashPasswd := aes.Keccak256([]byte(password))
	o.password = hashPasswd
	o.locked = false
	return nil
}

func (o *KeyMixLayer) Unlock(ctx context.Context, password string) error {
	err := o.changeLock(password, false)
	if err != nil && err == ErrPasswordEmpty {
		return o.SetPassword(ctx, password)
	}
	return err
}

func (o *KeyMixLayer) Lock(ctx context.Context, password string) error {
	return o.changeLock(password, true)
}

func (o *KeyMixLayer) LockState(ctx context.Context) bool {
	return o.locked
}

func (o *KeyMixLayer) changeLock(password string, lock bool) error {
	o.m.Lock()
	defer o.m.Unlock()
	if len(o.password) == 0 {
		return ErrPasswordEmpty
	}
	if o.locked == lock {
		if o.locked {
			return ErrAlreadyLocked
		} else {
			return ErrAlreadyUnlocked
		}
	}
	hashPasswd := aes.Keccak256([]byte(password))
	if !bytes.Equal(o.password, hashPasswd) {
		return ErrInvalidPassword
	}
	o.locked = lock
	if !o.locked {
		o.password = hashPasswd
	}
	return nil
}

func (o *KeyMixLayer) CheckToken(ctx context.Context) error {
	if len(o.password) == 0 {
		return ErrPasswordEmpty
	}

	allPermissions := core.AdaptOldStrategy(core.PermAdmin)
	if auth.HasPerm(ctx, allPermissions, core.PermAdmin) {
		return nil
	}

	return errcode.ErrWithoutPermission
}

// Next Check the password has been set and the wallet is locked
func (o *KeyMixLayer) Next() error {
	o.m.RLock()
	defer o.m.RUnlock()
	if len(o.password) == 0 {
		return ErrPasswordEmpty
	}
	if o.locked {
		return ErrLocked
	}
	return nil
}

func (o *KeyMixLayer) Encrypt(password []byte, key crypto.PrivateKey) (*aes.EncryptedKey, error) {
	if len(password) == 0 {
		password = o.password
	}
	// EncryptKey encrypts a key using the specified scrypt parameters into a json
	// blob that can be decrypted later on.
	cryptoStruct, err := o.encryptData(password, key.Bytes())
	if err != nil {
		return nil, err
	}
	addr, _ := key.Address()
	encryptedKeyJSON := &aes.EncryptedKey{
		Address: addr.String(),
		KeyType: key.KeyType(),
		Crypto:  cryptoStruct,
	}
	return encryptedKeyJSON, nil
}

func (o *KeyMixLayer) encryptData(password []byte, data []byte) (*aes.CryptoJSON, error) {
	return aes.EncryptData(password, data, o.scryptN, o.scryptP)
}

func (o *KeyMixLayer) Decrypt(password []byte, key *aes.EncryptedKey) (crypto.PrivateKey, error) {
	if len(password) == 0 {
		password = o.password
	}
	// Depending on the version try to parse one way or another
	keyBytes, err := aes.Decrypt(key.Crypto, password)
	// Handle any decryption errors and return the key
	if err != nil {
		return nil, err
	}
	pkey, err := crypto.NewKeyFromData2(key.KeyType, keyBytes)
	if err != nil {
		return nil, err
	}
	return pkey, nil
}

func (o *KeyMixLayer) VerifyPassword(_ context.Context, password string) error {
	if bytes.Equal(o.password, aes.Keccak256([]byte(password))) {
		return nil
	}
	return ErrInvalidPassword
}
