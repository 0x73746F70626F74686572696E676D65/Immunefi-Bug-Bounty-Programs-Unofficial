(module
  (type (;0;) (func))
  (func (;0;) (type 0)
    nop
  )
)
