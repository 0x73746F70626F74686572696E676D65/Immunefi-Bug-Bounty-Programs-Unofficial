(component
  (import "" (instance))
)
