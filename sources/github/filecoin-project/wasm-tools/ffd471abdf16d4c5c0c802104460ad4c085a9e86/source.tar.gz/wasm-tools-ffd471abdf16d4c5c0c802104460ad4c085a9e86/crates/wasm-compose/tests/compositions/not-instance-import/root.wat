(component
  (import "" (func))
)
