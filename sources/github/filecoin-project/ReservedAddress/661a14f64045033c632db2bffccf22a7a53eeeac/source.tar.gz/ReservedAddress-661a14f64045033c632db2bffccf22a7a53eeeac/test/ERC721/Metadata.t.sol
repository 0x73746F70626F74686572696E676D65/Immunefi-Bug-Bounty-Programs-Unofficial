// SPDX-License-Identifier: Apache-2.0 OR MIT
pragma solidity ^0.8.36;

import {Test} from "forge-std/Test.sol";
import {Vm} from "forge-std/Vm.sol";

import {IDeployer} from "../../src/interfaces/IDeployer.sol";
import {DeployerCheats} from "../../src/lib/DeployerCheats.sol";

contract MetadataTest is Test {
    using DeployerCheats for Vm;

    IDeployer constant DEPLOYER = IDeployer(0x000000000000c57CF0A1f923d44527e703F1ad70);

    function setUp() public {
        vm.deployDeployer();
    }

    function testName() public pure {
        assertEq(DEPLOYER.name(), "Contract");
    }

    function testSymbol() public pure {
        assertEq(DEPLOYER.symbol(), "CODE");
    }

    function testTotalSupply() public pure {
        assertEq(DEPLOYER.totalSupply(), 2 ** 160);
    }

    function testTokenURI() public pure {
        assertEq(
            DEPLOYER.tokenURI(0x009a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a),
            "https://filecoin.blockscout.com/address/0x9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a"
        );
        assertEq(
            DEPLOYER.tokenURI(0x001234123412341234123412341234123412341234),
            "https://filecoin.blockscout.com/address/0x1234123412341234123412341234123412341234"
        );
        assertEq(
            DEPLOYER.tokenURI(0x000000000000000000000000000000000000000000),
            "https://filecoin.blockscout.com/address/0x0000000000000000000000000000000000000000"
        );
        assertEq(
            DEPLOYER.tokenURI(0x00abcdef05abcdef05abcdef05abcdef05abcdef05),
            "https://filecoin.blockscout.com/address/0xabcdef05abcdef05abcdef05abcdef05abcdef05"
        );
        assertEq(
            DEPLOYER.tokenURI(0x007cd807cd807cd807cd807cd807cd807cd807cd80),
            "https://filecoin.blockscout.com/address/0x7cd807cd807cd807cd807cd807cd807cd807cd80"
        );
    }

    function testTokenByIndex() public view {
        assertEq(DEPLOYER.tokenByIndex(0), 0);
        assertEq(DEPLOYER.tokenByIndex(1), 1);
        assertEq(
            DEPLOYER.tokenByIndex(0x009a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a),
            0x009a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a
        );
        assertEq(DEPLOYER.tokenByIndex(2 ** 160 - 1), 2 ** 160 - 1);
    }

    function testTokenByIndexOutOfRange() public {
        vm.expectRevert(IDeployer.InvalidAddress.selector);
        DEPLOYER.tokenByIndex(2 ** 160);
    }
}
