module github.com/filecoin-project/go-fil-commcid

go 1.25.0

require (
	github.com/filecoin-project/go-fil-commp-hashhash v0.4.0
	github.com/ipfs/go-cid v0.6.2
	github.com/multiformats/go-multibase v0.3.0
	github.com/multiformats/go-multicodec v0.10.0
	github.com/multiformats/go-multihash v0.2.3
	github.com/multiformats/go-varint v0.1.0
	github.com/stretchr/testify v1.12.1
	golang.org/x/xerrors v0.0.0-20240903120638-7835f813f4da
)

require (
	github.com/klauspost/cpuid/v2 v2.2.8 // indirect
	github.com/minio/sha256-simd v1.0.1 // indirect
	github.com/mr-tron/base58 v1.3.0 // indirect
	github.com/multiformats/go-base32 v0.1.0 // indirect
	github.com/multiformats/go-base36 v0.2.0 // indirect
	github.com/spaolacci/murmur3 v1.1.0 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
	golang.org/x/crypto v0.53.0 // indirect
	golang.org/x/sys v0.46.0 // indirect
	lukechampine.com/blake3 v1.3.0 // indirect
)
