# Core Devs Meetings

## Purpose
The core devs meeting is a technical meeting intended to bring together various Filecoin teams who play major roles in determining the direction of the protocol. Filecoin implementation and research teams provide updates to their projects, discuss the implementation of various [FIPs](https://github.com/filecoin-project/FIPs), set priorities for network upgrades, and are convened for decision-making in the instance of a network-critical security breach or bug. 

Core Devs provide a central pillar of technical expertise to the broader Filecoin community as we work to build a decentralized, efficient, and robust foundation for humanity’s most important information.

## Recent Meetings

№  | Date                           | Agenda          | Notes         | Recording            
--- | ----------------------------- | -------------- |-------------- | -------------------- 
49  | Thursday, September 1, 2022   | [agenda](https://github.com/filecoin-project/core-devs/issues/110) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200049.md) | [meeting](https://www.youtube.com/watch?v=Zm1eNpGK6Zw) 
50  | Thursday, October 6, 2022     | [agenda](https://github.com/filecoin-project/core-devs/issues/111) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200050.md) | [meeting](https://www.youtube.com/watch?v=pvrGxhelIkU) 
51  | Friday, November 11, 2022     | [agenda](https://github.com/filecoin-project/core-devs/issues/120) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200051.md) | [meeting](https://www.youtube.com/watch?v=NaaJ-pqzMxE) 
52  | Thursday, December 1, 2022    | [agenda](https://github.com/filecoin-project/core-devs/issues/124) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200052.md) | [meeting](https://youtu.be/v_ljI98Xrl8) 
53  | Thursday, January 5, 2023     | [agenda](https://github.com/filecoin-project/core-devs/issues/124) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200053.md) | [meeting](https://youtu.be/MRV6f7jwVE0) 
54  | Thursday, February 2, 2023    | [agenda](https://github.com/filecoin-project/core-devs/issues/125) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting0054.md) | [meeting](https://youtu.be/5OxUyx_nrJA) 
55  | Friday, March 3, 2023        | [agenda](https://github.com/filecoin-project/core-devs/issues/131) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting0055.md) | [meeting](https://youtu.be/6Bz8-jK3K18) 
56  | Thursday, April 6, 2023      | [agenda](https://github.com/filecoin-project/core-devs/issues/134) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200056.md) | [meeting](https://youtu.be/upUHn21ZIlQ) 
57  | Friday, May 5, 2023          | [agenda](https://github.com/filecoin-project/core-devs/issues/136) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200057.md) | [meeting](https://youtu.be/Fdm-eq8Ie6w) 
58  | Thursday, June 1, 2023       | [agenda](https://github.com/filecoin-project/core-devs/issues/141) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200058.md) | [meeting](https://youtu.be/5-MVAhzC2nw) 
59  | Thursday, July 6, 2023       | [agenda](https://github.com/filecoin-project/core-devs/issues/142) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200059.md) | [meeting](https://youtu.be/qhd0u7z9Fnw) 
60  | Thursday, August 3, 2023     | [agenda](https://github.com/filecoin-project/core-devs/issues/144) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200060.md) | [meeting](https://youtu.be/77TnY_vmm94) 
61  | Friday, September 1, 2023    | [agenda](https://github.com/filecoin-project/core-devs/issues/146) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200061.md) | [meeting](https://youtu.be/s5msHsLjlB4) 
62  | Thursday, October 5, 2023    | [agenda](https://github.com/filecoin-project/core-devs/issues/152) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200062.md) | [meeting](https://youtu.be/YhsXe3hRcww) 
63  | Friday, November 3, 2023     | [agenda](https://github.com/filecoin-project/core-devs/issues/156) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200063.md) | [meeting](https://youtu.be/K9fa2WI00Mw) 
64  | Thursday, December 7, 2023   | [agenda](https://github.com/filecoin-project/core-devs/issues/159) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200064.md) | [meeting](https://youtu.be/xY7MaLc5Y-U) 
65  | Friday, January 19, 2024     | [agenda](https://github.com/filecoin-project/core-devs/issues/160) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200065.md) | [meeting](https://youtu.be/xnxFm5vAFfs) 
66  | Thursday, February 1, 2024   | [agenda](https://github.com/filecoin-project/core-devs/issues/161) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200066.md) | [meeting](https://youtu.be/LzlRbDnsZtw) 
67  | Thursday, March 7, 2024      | Meeting Cancelled |  |  
68  | Thursday, April 4, 2024      | [agenda](https://github.com/filecoin-project/core-devs/issues/168) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200068.md) | [meeting](https://youtu.be/cYG0o1sG9L8) 
69  | Ad hoc meeting unrecorded    |  |  |  
70  | Friday, May 3, 2024         | [agenda](https://github.com/filecoin-project/core-devs/issues/171) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200070.md) | [meeting](https://youtu.be/VHvkIHcGdUM) 
71  | Thursday, June 6, 2024      | [agenda](https://github.com/filecoin-project/core-devs/issues/173) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200071.md) | [meeting](https://youtu.be/ARW5nUhnRlQ) 
72  | Thursday, June 6, 2024      | Brussels Convening |  |  
73  | Thursday, August 1, 2024    | [agenda](https://github.com/filecoin-project/core-devs/issues/176) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200073.md) | [meeting](https://youtu.be/ibkfXroadU8) 
74  | Friday, August 6, 2024      | [agenda](https://github.com/filecoin-project/core-devs/issues/178) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200074.md) | [meeting](https://youtu.be/sneAmyEFAwU) 
75  | Thursday, November 14, 2024 | [agenda](https://github.com/filecoin-project/core-devs/issues/181) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200075.md) | [meeting](https://www.youtube.com/watch?v=LXFhPbPyU38) 
76  | Thursday, December 5, 2024  | [agenda](https://github.com/filecoin-project/core-devs/issues/186) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200076.md) | [meeting](https://youtu.be/UDPvCb90C9E) 
77  | Thursday, February 6, 2025  | [agenda](https://github.com/filecoin-project/core-devs/issues/188) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200077.md) | [meeting](https://youtu.be/RewkL5t_114) 
78  | Thursday, March 6, 2025  | [agenda](https://github.com/filecoin-project/core-devs/issues/190) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200078.md) | [meeting](https://youtu.be/ClAIBm_iZJw) 
79  | Thursday, March 13, 2025  | | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200079.md) | [meeting](https://youtu.be/Vr6QfkFpNRA) 
82  | Thursday, August 14, 2025  | [agenda](https://github.com/filecoin-project/core-devs/issues/199#issue-3292238697) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200082.md) | [meeting](https://danny.spesh.com/video/coredevs-2025-08-07/GMT20250807-150442_Recording_1790x920.mp4) 
83  | Friday, September 5, 2025  | [agenda](https://github.com/filecoin-project/core-devs/issues/202) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200083.md) | [meeting (passcode: Y9Qx1qh*)](https://fil-org.zoom.us/rec/share/pPkLyzSELAKgaGLMZweInyZ3E06o27PCIbAs-jeErM27ZfNWWZbv-VYiNSTB1wFP.qC9jlqnjUCoqNmRW) 
84  | Friday, October 2, 2025  | [agenda](https://github.com/filecoin-project/core-devs/issues/204) | [notes](https://docs.google.com/presentation/d/1RbOUGmqcH1v5BO05nbCkHXyJZ93E1MTwLGaiWTxJFpQ/edit?slide=id.g19157ff4f70_0_0#slide=id.g19157ff4f70_0_0) | [meeting](https://fil-org.zoom.us/rec/share/pPkLyzSELAKgaGLMZweInyZ3E06o27PCIbAs-jeErM27ZfNWWZbv-VYiNSTB1wFP.qC9jlqnjUCoqNmRW) 
85  | Friday, November 7, 2025  | [agenda](https://github.com/filecoin-project/core-devs/issues/208) | [notes](https://docs.google.com/presentation/d/1PuDTGj0qN0VHeZsiLGbt7GyZC3vdy_2pS132qXHA33s/edit?slide=id.g19157ff4f70_0_0#slide=id.g19157ff4f70_0_0) | [meeting](https://fil-org.zoom.us/rec/share/pPkLyzSELAKgaGLMZweInyZ3E06o27PCIbAs-jeErM27ZfNWWZbv-VYiNSTB1wFP.qC9jlqnjUCoqNmRW) 
86  | Tuesday, December 8, 2025  | [agenda](https://github.com/filecoin-project/core-devs/issues/211) | [notes](https://docs.google.com/presentation/d/1npLu6ufltSmEl8lZLCxHpiSBMOfnmN6pmYFIpXdDjn8/edit?slide=id.g19157ff4f70_0_0#slide=id.g19157ff4f70_0_0) | [meeting (passcode: w6L690m#)](https://fil-org.zoom.us/rec/share/EYiq_NZTVuhIKl2X04zevWd9k69CqDHCfVozrOnaSdYAK_fPLxfz0zS25t_b3Q6I.M_VA9oMFTLdseiNG?from=hub) 
87  | Tuesday, January 20, 2026  | [agenda](https://github.com/filecoin-project/core-devs/issues/212) | [notes](https://docs.google.com/presentation/d/1fTPOod9Pq-bQ0_qIziN0_k-ZzMLsAjC7vMLhDqyiCDY/edit?slide=id.g3bae32cf71d_2_245#slide=id.g3bae32cf71d_2_245)) | Passcode: *vJDd.T1 [meeting](https://us02web.zoom.us/rec/play/JPSHL8bBqxUJh5IyDK5PwVGDwxt13qU8lsQoHjW7mWNJeA0QgFNqtm1zabJZXiChTc39IW_qOib3Sut9.VyLf9Xwm5Q-dB5O1?eagerLoadZvaPages=sidemenu.billing.plan_management&accessLevel=meeting&canPlayFromShare=true&from=share_recording_detail&continueMode=true&oldStyle=true&iet=M8_7qsJ8vDrSR5Dgod02GR_hcoZRoizdbT0TkJoSEUU.AG.Lv0-rcbyX71zqrPs1fe_OI5kMG_rpYe9eraF_IelYkG-c_cF560n9CnbXI-qkKgTgvqSSTRQz63ILQj6Pj6fwFSt09G9xtK7K174xX481BISD3ISArf0hD72.HIwpE9-9Ae_QrFCYiDQk1w.F4btu5kzWHhUAUko&componentName=rec-play&originRequestUrl=https%3A%2F%2Fus02web.zoom.us%2Frec%2Fshare%2FrTX1UwVUCcZd1nTwOG5Hmm45F3qmU00EUYTPfnQkFzJOUko5OZZIHLf1Ne4XHAxf.tOmlt0yUoX56XSf7%3Fiet%3DM8_7qsJ8vDrSR5Dgod02GR_hcoZRoizdbT0TkJoSEUU.AG.Lv0-rcbyX71zqrPs1fe_OI5kMG_rpYe9eraF_IelYkG-c_cF560n9CnbXI-qkKgTgvqSSTRQz63ILQj6Pj6fwFSt09G9xtK7K174xX481BISD3ISArf0hD72.HIwpE9-9Ae_QrFCYiDQk1w.F4btu5kzWHhUAUko) 
88  | Tuesday, February 24, 2026 | [agenda](https://github.com/filecoin-project/core-devs/issues/213) | [notes](https://docs.google.com/presentation/d/16NVKAsGIl0L9Yh11l8-UxmbMH17cMckkz5fy0Hsv56Q/edit?slide=id.g3bae32cf71d_2_297#slide=id.g3bae32cf71d_2_297)) | Passcode: 2bihCf.v [meeting](https://us02web.zoom.us/rec/play/y7rKDYBb-6PekjNU-WMwr1MWV29Kqpe-OYqMoQmDkD_fFgF6AvVkm7DzGx8-5szXYQMsbXQ37b7Ax8QG.qdg0hhcSHzcTOa1c?eagerLoadZvaPages=sidemenu.billing.plan_management&accessLevel=meeting&canPlayFromShare=true&from=share_recording_detail&continueMode=true&oldStyle=true&iet=gVeA2hmQeLqlW3lDY8h_jnwX494QbuopRGcltvPFg1M.AG.Z0OxU_sC2llwf1ZuecYHPOMAfYYSrcMBzbzzk5NKma1tsyHHUW7P_4po6l22WQBwhZq0mMDa-j4A038_SfFT-EQ9r7zez4vJSapZ260KZtZ8T0MO3EGZ3JiC.Gy9HXjzoz6apc6UyTeBzzQ.eS34Z1qnhZ5HnGG0&componentName=rec-play&originRequestUrl=https%3A%2F%2Fus02web.zoom.us%2Frec%2Fshare%2FcqqpX677Sx49M_F9MRizQCIy8kUx9O0r5XN8Ipc1dnR7baUs0gQkGVN0KrpC0Fy9.h1TXMmU-T5NsABSH%3Fiet%3DgVeA2hmQeLqlW3lDY8h_jnwX494QbuopRGcltvPFg1M.AG.Z0OxU_sC2llwf1ZuecYHPOMAfYYSrcMBzbzzk5NKma1tsyHHUW7P_4po6l22WQBwhZq0mMDa-j4A038_SfFT-EQ9r7zez4vJSapZ260KZtZ8T0MO3EGZ3JiC.Gy9HXjzoz6apc6UyTeBzzQ.eS34Z1qnhZ5HnGG0) 
89  | Tuesday, March 17, 2026  | [agenda](https://github.com/filecoin-project/core-devs/issues/214) | [notes](https://docs.google.com/presentation/d/1Da8zdoqSXxleenidcm6vHgm-ZS764A1NGipWx2GEc5w/edit?slide=id.g3c583afd27e_0_3#slide=id.g3c583afd27e_0_3)) | Passcode: =5wVTgeG [meeting](https://us02web.zoom.us/rec/play/-oP7WTgbAZlCz0F9KD5p2hshI6gSJ-xVy1utTJQ4ZcT1dOoBWEZcXuiuzRAG4Q3mG5S7l-UYGiLbX2OP.JENSD19Rfuz2_v6Q?eagerLoadZvaPages=sidemenu.billing.plan_management&accessLevel=meeting&canPlayFromShare=true&from=share_recording_detail&continueMode=true&oldStyle=true&iet=79jyVeSE_Byp6W9T9pte84aFoCFWW-9Zt_G814ymYVg.AG.Q8XfiSPfbubTBeywlI2s6VnBuhwPoPv9lMiVTPAAoixtMK8y-k4QkPoL2sg0dKump8B3dkhO2_zc5qYzZVCgm78XxDORJB1TrWf4T1uZVQldMr08UTeV6TGK.d38ZE6COOx1zaKnkerf13Q.rKrHivx5H8jcAkYw&componentName=rec-play&originRequestUrl=https%3A%2F%2Fus02web.zoom.us%2Frec%2Fshare%2FxnJUMwVnfbqYWzK7zh0-rN3_89Fc0TOCvaaiMVaflTQKPNUZ2SE8FHcjLtvLjmB8.rjN3dltAuJ1fFWiz%3Fiet%3D79jyVeSE_Byp6W9T9pte84aFoCFWW-9Zt_G814ymYVg.AG.Q8XfiSPfbubTBeywlI2s6VnBuhwPoPv9lMiVTPAAoixtMK8y-k4QkPoL2sg0dKump8B3dkhO2_zc5qYzZVCgm78XxDORJB1TrWf4T1uZVQldMr08UTeV6TGK.d38ZE6COOx1zaKnkerf13Q.rKrHivx5H8jcAkYw) 
90  | Tuesday, April 14, 2026  | [agenda](https://github.com/filecoin-project/core-devs/issues/215) | [notes](https://docs.google.com/presentation/d/1LHWBV-dYNa1MpiqRnHK3D0zhy0J8Pf4shuKZVYCuFkc/edit?slide=id.g3c06ad91076_2_7#slide=id.g3c06ad91076_2_7)) | Passcode: 2uKjZ$qc [meeting](https://fil-org.zoom.us/rec/share/hAREKeKJ62TJuej30Y4f3tevuJCDWrZ9B5jj7UifYhNk_uU72Je6HUsPzgwSdRmX.daANrytLzZEgSHsQ) 
91  | Tuesday, May 19, 2026  | [agenda](https://github.com/filecoin-project/core-devs/issues/220) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200091.md)) | Passcode: 022757 [meeting](https://fil-org.zoom.us/s/81113254352?pwd=gJ7LlkvVf0oh7SbPX5lbUWeiZ8hEyk.1&jst=2#success)
92  | Tuesday, June 30, 2026  | [agenda](https://github.com/filecoin-project/core-devs/issues/222) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200092.md)) | [meeting](https://www.youtube.com/watch?v=yuVVX6ObdVE)
93  | Wednesday, August 5, 2026  | [agenda](https://github.com/filecoin-project/core-devs/issues/223) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200093.md)) | [meeting](https://youtu.be/dogDmwEpCho)
94  | Wednesday, August 5, 2026  | [agenda](https://github.com/filecoin-project/core-devs/issues/225) | [notes](https://github.com/filecoin-project/core-devs/blob/master/Core%20Dev%20Meetings/Meeting%200094.md)) | [meeting](https://youtu.be/it1ft03pI4A?si=60JbSPORPuuDPBRy)


A full record of all meeting notes can be found [HERE](https://github.com/filecoin-project/core-devs/tree/master/Core%20Dev%20Meetings). 

## Who Can Attend
As an open source project, anyone is able to contribute their work, skills, or other expertise to Filecoin.  Individuals do not need to be 'Core Devs' to develop the Filecoin tech stack, or make meaningful contributions to the Filecoin community. 

Typically, core devs are individuals who have 1) been involved in the project for a long time, are 2) deeply knowledgeable about the Filecoin protocol and related subsystems, and 3) are interested in committing their time and expertise to reviewing work and contributing technical guidance outside of their immediate work domain. Furthermore, individuals who serve as Core Devs are publicly known, expected to participate in monthly Core Devs meetings, and are included in closed communication channels in order to discuss technical issues related to the security and development of the Filecoin protocol. 

### Becoming a Core Dev
* Anyone who wishes to become a Core Dev can send their request to the repo admin, Christian Taylor (christian@fil.org, or @christiantaylor on Slack) 
* Your request will be flagged for existing Core Devs, who are asked to consider your inclusion according to open source principles of [thoughtful meritocracy](https://postmeritocracy.org/). 
* If no one opposes your inclusion, you will be added to the meeting invite and all private groups.  You will be listed publicly as a Core Dev. 
* If anyone raises meaningful opposition to your inclusion, a simple majority vote to accept or reject your request will be levied at the next Core Devs meeting.

### Core Dev Observers
Occasionally, Filecoin community members may want or need to join a Core Devs meeting.  Common reasons for this include: 
   * They are authoring a FIP and have been asked to present their proposal. 
   * They have expertise in a topic of discussion, and have been asked to contribute their knowledge. 
   * Their work is relevant to a series of Core Dev discussions (e.g., network upgrades) but they do not want to contribute as full Core Devs. 

As a reminder, being a Core Dev means opting into a position of community leadership, lending your time to help move forward work and technical discussions for the entire Filecoin community.  Individuals can be significant contributors to Filecoin and not serve as Core Devs. Please keep these expectations in mind when you request to observe or become a part of the group. 

If you'd like to be an observer, please send your request to Christian via email (christian@fil.org) and explain exactly how many meetings you expect to be able to attend. 

### Addendum: Removing a Core Dev
Occasionally, the repo admins will review Core Dev attendance records and follow up with Core Devs who have been less engaged in the group.  These individuals will be reminded of group expectations and/or given the opportunity to step down as Core Devs. 

Please note that Filecoin is a decentralized, global community.  As such, there are not currently any requirements for attendance or participation for Core Devs.  However, it is important that Core Devs be reachable, reliable, and engaged.  Anyone who wishes to maintain their status as a Core Dev is expected to be so. 

Though unlikely, anyone can propose the removal of someone as a Core Dev.  If a significant reason is raised for removal, a simple majority vote among current Core Devs will be taken at the next Core Devs meeting. 

## Meeting Scheduling 
The schedule for Core Dev meetings periodically changes, depending on needs. 

Currently, meetings occur monthly for half an hour.  Exact timing alternates every other month and are curenntly schduled ad hoc but normal sessions are schduled on: 
* 15:30 UTC on the last wednesday of every month

## Agenda Items
Agendas are posted to https://github.com/filecoin-project/core-devs/issues. Anyone is welcome to add an item to the agenda.  Items should generally be technical in nature, and relate to FIPs, FRCs or other network standards, network upgrades, technical network operations, or security issues. 

Please note that agenda items are accepted at the sole discretion of repo admins. 

## Who Manages the Meetings
As of April 2026, [@ThatGuyLLC](https://github.com/ThatGuyLLC) is the primary repo admin.  

The meetings are independent of any organization. However, the Filecoin Foundation pays for the videoconference software used in the meetings. 

