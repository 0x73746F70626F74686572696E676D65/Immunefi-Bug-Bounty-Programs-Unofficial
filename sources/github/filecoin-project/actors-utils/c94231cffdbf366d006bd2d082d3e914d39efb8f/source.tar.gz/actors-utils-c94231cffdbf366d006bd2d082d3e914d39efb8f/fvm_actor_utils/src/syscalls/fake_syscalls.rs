use std::{cell::RefCell, collections::HashMap};

use cid::Cid;
use fvm_ipld_encoding::ipld_block::IpldBlock;
use fvm_shared::{
    address::Address, econ::TokenAmount, error::ErrorNumber, error::ExitCode, ActorID, Response,
};

use super::Syscalls;

#[derive(Clone, Default, Debug)]
pub struct TestMessage {
    pub method: u64,
    pub params: Option<IpldBlock>,
    pub value: TokenAmount,
}

#[derive(Clone, Default, Debug)]
pub struct FakeSyscalls {
    /// The root of the receiving actor.
    pub root: RefCell<Cid>,
    /// The f0 ID of the receiving actor.
    pub actor_id: ActorID,

    /// Actor ID to return as caller ID.
    pub caller_id: RefCell<ActorID>,

    /// A map of addresses that were instantiated in this runtime.
    pub addresses: RefCell<HashMap<Address, ActorID>>,
    /// The next-to-allocate f0 address.
    pub next_actor_id: RefCell<ActorID>,

    /// The last message sent via this runtime.
    pub last_message: RefCell<Option<TestMessage>>,
    /// Flag to control message success.
    pub abort_next_send: RefCell<bool>,
}

impl FakeSyscalls {
    /// Set the ActorID returned as caller.
    pub fn set_caller_id(&self, new_id: ActorID) {
        self.caller_id.replace(new_id);
    }
}

impl Syscalls for FakeSyscalls {
    fn root(&self) -> Result<Cid, super::NoStateError> {
        Ok(*self.root.borrow())
    }

    fn set_root(&self, cid: &Cid) -> Result<(), super::NoStateError> {
        self.root.replace(*cid);
        Ok(())
    }

    fn receiver(&self) -> fvm_shared::ActorID {
        self.actor_id
    }

    fn caller(&self) -> fvm_shared::ActorID {
        *self.caller_id.borrow()
    }

    fn send(
        &self,
        to: &fvm_shared::address::Address,
        method: fvm_shared::MethodNum,
        params: Option<fvm_ipld_encoding::ipld_block::IpldBlock>,
        value: fvm_shared::econ::TokenAmount,
    ) -> Result<Response, ErrorNumber> {
        if *self.abort_next_send.borrow() {
            self.abort_next_send.replace(false);
            Err(ErrorNumber::AssertionFailed)
        } else {
            // sending to an address instantiates it if it isn't already
            let mut map = self.addresses.borrow_mut();

            match to.payload() {
                // TODO: in a real system, this is fallible if the address does not exist
                // This impl assumes that any f0 form address is in the map/instantiated but does not check so
                // Sending to actors should succeed if the actor exists but not instantiate it
                fvm_shared::address::Payload::ID(_) | fvm_shared::address::Payload::Actor(_) => {
                    Ok(())
                }
                // Sending to public keys should instantiate the actor
                fvm_shared::address::Payload::Secp256k1(_)
                | fvm_shared::address::Payload::BLS(_)
                | fvm_shared::address::Payload::Delegated(_) => {
                    if !map.contains_key(to) {
                        let actor_id = self.next_actor_id.replace_with(|old| *old + 1);
                        map.insert(*to, actor_id);
                    }
                    Ok(())
                }
            }?;

            // save the fake message as being sent
            let message = TestMessage { method, params: params.clone(), value };
            self.last_message.replace(Some(message));

            Ok(Response { exit_code: ExitCode::OK, return_data: params })
        }
    }

    fn resolve_address(&self, addr: &Address) -> Option<ActorID> {
        // if it is already an ID-address, just return it
        if let fvm_shared::address::Payload::ID(id) = addr.payload() {
            return Some(*id);
        }

        let map = self.addresses.borrow();
        map.get(addr).copied()
    }
}
