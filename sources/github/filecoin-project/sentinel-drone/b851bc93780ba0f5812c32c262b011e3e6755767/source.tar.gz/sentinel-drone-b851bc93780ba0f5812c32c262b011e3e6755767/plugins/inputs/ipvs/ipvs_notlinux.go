// +build !linux

package ipvs
