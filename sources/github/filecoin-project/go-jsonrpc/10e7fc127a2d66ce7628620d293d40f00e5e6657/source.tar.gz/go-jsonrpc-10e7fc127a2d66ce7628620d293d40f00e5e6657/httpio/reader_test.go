package httpio

import (
	"context"
	"io"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gorilla/mux"
	"github.com/stretchr/testify/require"

	"github.com/filecoin-project/go-jsonrpc"
)

type ReaderHandler struct {
}

func (h *ReaderHandler) ReadAll(ctx context.Context, r io.Reader) ([]byte, error) {
	return io.ReadAll(r)
}

func (h *ReaderHandler) ReadUrl(ctx context.Context, u string) (string, error) {
	return u, nil
}

func TestReaderProxy(t *testing.T) {
	var client struct {
		ReadAll func(ctx context.Context, r io.Reader) ([]byte, error)
	}

	serverHandler := &ReaderHandler{}

	readerHandler, readerServerOpt := ReaderParamDecoder()
	rpcServer := jsonrpc.NewServer(readerServerOpt)
	rpcServer.Register("ReaderHandler", serverHandler)

	mux := mux.NewRouter()
	mux.Handle("/rpc/v0", rpcServer)
	mux.Handle("/rpc/streams/v0/push/{uuid}", readerHandler)

	testServ := httptest.NewServer(mux)
	defer testServ.Close()

	re := ReaderParamEncoder("http://" + testServ.Listener.Addr().String() + "/rpc/streams/v0/push")
	closer, err := jsonrpc.NewMergeClient(context.Background(), "ws://"+testServ.Listener.Addr().String()+"/rpc/v0", "ReaderHandler", []any{&client}, nil, re)
	require.NoError(t, err)

	defer closer()

	read, err := client.ReadAll(context.TODO(), strings.NewReader("pooooootato"))
	require.NoError(t, err)
	require.Equal(t, "pooooootato", string(read), "potatos weren't equal")
}

func TestWaitReadCloserCloseAfterEOF(t *testing.T) {
	wr := &waitReadCloser{
		ReadCloser: io.NopCloser(strings.NewReader("")),
		wait:       make(chan struct{}),
	}

	_, err := io.ReadAll(wr)
	require.NoError(t, err)
	require.NotPanics(t, func() {
		require.NoError(t, wr.Close())
	})
}
