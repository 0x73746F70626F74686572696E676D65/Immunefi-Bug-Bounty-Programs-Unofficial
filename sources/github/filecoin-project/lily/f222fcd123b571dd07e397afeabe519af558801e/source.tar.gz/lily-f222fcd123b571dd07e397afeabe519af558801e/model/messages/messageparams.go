package messages

import (
	"context"

	"go.opencensus.io/tag"

	"github.com/filecoin-project/lily/metrics"
	"github.com/filecoin-project/lily/model"
)

type MessageParam struct {
	tableName struct{} `pg:"message_params"` // nolint: structcheck
	Cid       string   `pg:",pk,notnull"`
	Params    []byte
}

func (m *MessageParam) Persist(ctx context.Context, s model.StorageBatch, _ model.Version) error {
	ctx, _ = tag.New(ctx, tag.Upsert(metrics.Table, "message_params"))

	metrics.RecordCount(ctx, metrics.PersistModel, 1)
	return s.PersistModel(ctx, m)
}

type MessageParamList []*MessageParam

func (ml MessageParamList) Persist(ctx context.Context, s model.StorageBatch, _ model.Version) error {
	if len(ml) == 0 {
		return nil
	}
	ctx, _ = tag.New(ctx, tag.Upsert(metrics.Table, "message_params"))

	metrics.RecordCount(ctx, metrics.PersistModel, len(ml))
	return s.PersistModel(ctx, ml)
}
