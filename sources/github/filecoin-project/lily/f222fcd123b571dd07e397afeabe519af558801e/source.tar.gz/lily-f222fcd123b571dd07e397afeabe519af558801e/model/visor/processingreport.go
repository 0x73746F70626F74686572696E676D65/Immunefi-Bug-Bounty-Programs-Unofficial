package visor

import (
	"context"
	"time"

	"go.opencensus.io/tag"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/attribute"

	"github.com/filecoin-project/lily/metrics"
	"github.com/filecoin-project/lily/model"
)

const (
	ProcessingStatusOK    = "OK"
	ProcessingStatusInfo  = "INFO"  // Processing was successful but the task reported information in the StatusInformation column
	ProcessingStatusError = "ERROR" // one or more errors were encountered, data may be incomplete
	ProcessingStatusSkip  = "SKIP"  // no processing was attempted, a reason may be given in the StatusInformation column
)

const (
	// ProcessingStatusInformationNullRound is set byt the consensus task to indicate a null round
	ProcessingStatusInformationNullRound = "NULL_ROUND" // used by consensus task to indicate a null round
	// TODO this could likely be a status of its own, but the indexer isn't currently suited for tasks to set their own status.
)

type ProcessingReport struct {
	tableName struct{} `pg:"visor_processing_reports"` // nolint: structcheck

	Height    int64  `pg:",pk,use_zero"`
	StateRoot string `pg:",pk,notnull"`

	// Reporter is the name of the instance that is reporting the result
	Reporter string `pg:",pk,notnull"`

	// Task is the name of the sub task that generated the report
	Task string `pg:",pk,notnull"`

	StartedAt   time.Time `pg:",pk,use_zero"`
	CompletedAt time.Time `pg:",use_zero"`

	Status            string `pg:",notnull"`
	StatusInformation string
	ErrorsDetected    interface{} `pg:",type:jsonb"`
}

func (p *ProcessingReport) Persist(ctx context.Context, s model.StorageBatch, _ model.Version) error {
	ctx, _ = tag.New(ctx, tag.Upsert(metrics.Table, "visor_processing_reports"))

	metrics.RecordCount(ctx, metrics.PersistModel, 1)
	return s.PersistModel(ctx, p)
}

type ProcessingReportList []*ProcessingReport

func (pl ProcessingReportList) Persist(ctx context.Context, s model.StorageBatch, _ model.Version) error {
	if len(pl) == 0 {
		return nil
	}
	ctx, span := otel.Tracer("").Start(ctx, "ProcessingReportList.Persist")
	if span.IsRecording() {
		span.SetAttributes(attribute.Int("count", len(pl)))
	}
	defer span.End()

	ctx, _ = tag.New(ctx, tag.Upsert(metrics.Table, "visor_processing_reports"))
	metrics.RecordCount(ctx, metrics.PersistModel, len(pl))
	return s.PersistModel(ctx, pl)
}
