package msapprovals

import (
	"context"

	"go.opencensus.io/tag"

	"github.com/filecoin-project/lily/metrics"
	"github.com/filecoin-project/lily/model"
)

type MultisigApproval struct {
	tableName      struct{} `pg:"multisig_approvals"` // nolint structcheck
	Height         int64    `pg:",pk,notnull,use_zero"`
	StateRoot      string   `pg:",pk,notnull"`
	MultisigID     string   `pg:",pk,notnull"`
	Message        string   `pg:",pk,notnull"`       // cid of message
	Method         uint64   `pg:",notnull,use_zero"` // method number used for the approval 2=propose, 3=approve
	Approver       string   `pg:",pk,notnull"`       // address of signer that triggered approval
	Threshold      uint64   `pg:",notnull,use_zero"`
	InitialBalance string   `pg:"type:numeric,notnull"`
	Signers        []string `pg:",notnull"`
	GasUsed        int64    `pg:",use_zero"`
	TransactionID  int64    `pg:",notnull,use_zero"`
	To             string   `pg:",use_zero"`            // address funds will move to in transaction
	Value          string   `pg:"type:numeric,notnull"` // amount of funds moved in transaction
}

func (ma *MultisigApproval) Persist(ctx context.Context, s model.StorageBatch, _ model.Version) error {
	ctx, _ = tag.New(ctx, tag.Upsert(metrics.Table, "multisig_approvals"))
	metrics.RecordCount(ctx, metrics.PersistModel, 1)
	return s.PersistModel(ctx, ma)
}

type MultisigApprovalList []*MultisigApproval

func (mal MultisigApprovalList) Persist(ctx context.Context, s model.StorageBatch, _ model.Version) error {
	if len(mal) == 0 {
		return nil
	}
	ctx, _ = tag.New(ctx, tag.Upsert(metrics.Table, "multisig_approvals"))
	metrics.RecordCount(ctx, metrics.PersistModel, len(mal))
	return s.PersistModel(ctx, mal)
}
