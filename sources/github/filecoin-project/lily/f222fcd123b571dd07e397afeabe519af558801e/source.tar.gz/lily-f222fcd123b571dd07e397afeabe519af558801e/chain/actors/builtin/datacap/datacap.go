package datacap

import (
	"github.com/ipfs/go-cid"
	"golang.org/x/xerrors"

	"github.com/filecoin-project/go-address"
	"github.com/filecoin-project/go-state-types/abi"
	actorstypes "github.com/filecoin-project/go-state-types/actors"
	builtin19 "github.com/filecoin-project/go-state-types/builtin"
	"github.com/filecoin-project/go-state-types/cbor"
	"github.com/filecoin-project/go-state-types/manifest"

	lotusactors "github.com/filecoin-project/lotus/chain/actors"
	"github.com/filecoin-project/lotus/chain/actors/adt"
	"github.com/filecoin-project/lotus/chain/types"
)

var (
	Address = builtin19.DatacapActorAddr
	Methods = builtin19.MethodsDatacap
)

func Load(store adt.Store, act *types.Actor) (State, error) {
	if name, av, ok := lotusactors.GetActorMetaByCode(act.Code); ok {
		if name != manifest.DatacapKey {
			return nil, xerrors.Errorf("actor code is not datacap: %s", name)
		}

		switch av {

		case actorstypes.Version9:
			return load9(store, act.Head)

		case actorstypes.Version10:
			return load10(store, act.Head)

		case actorstypes.Version11:
			return load11(store, act.Head)

		case actorstypes.Version12:
			return load12(store, act.Head)

		case actorstypes.Version13:
			return load13(store, act.Head)

		case actorstypes.Version14:
			return load14(store, act.Head)

		case actorstypes.Version15:
			return load15(store, act.Head)

		case actorstypes.Version16:
			return load16(store, act.Head)

		case actorstypes.Version17:
			return load17(store, act.Head)

		case actorstypes.Version18:
			return load18(store, act.Head)

		case actorstypes.Version19:
			return load19(store, act.Head)

		}
	}

	return nil, xerrors.Errorf("unknown actor code %s", act.Code)
}

func MakeState(store adt.Store, av actorstypes.Version, governor address.Address, bitwidth uint64) (State, error) {
	switch av {

	case actorstypes.Version9:
		return make9(store, governor, bitwidth)

	case actorstypes.Version10:
		return make10(store, governor, bitwidth)

	case actorstypes.Version11:
		return make11(store, governor, bitwidth)

	case actorstypes.Version12:
		return make12(store, governor, bitwidth)

	case actorstypes.Version13:
		return make13(store, governor, bitwidth)

	case actorstypes.Version14:
		return make14(store, governor, bitwidth)

	case actorstypes.Version15:
		return make15(store, governor, bitwidth)

	case actorstypes.Version16:
		return make16(store, governor, bitwidth)

	case actorstypes.Version17:
		return make17(store, governor, bitwidth)

	case actorstypes.Version18:
		return make18(store, governor, bitwidth)

	case actorstypes.Version19:
		return make19(store, governor, bitwidth)

	default:
		return nil, xerrors.Errorf("datacap actor only valid for actors v9 and above, got %d", av)
	}
}

type State interface {
	cbor.Marshaler

	Code() cid.Cid
	ActorKey() string
	ActorVersion() actorstypes.Version

	ForEachClient(func(addr address.Address, dcap abi.StoragePower) error) error
	VerifiedClientDataCap(address.Address) (bool, abi.StoragePower, error)
	Governor() (address.Address, error)
	GetState() interface{}

	VerifiedClients() (adt.Map, error)
	VerifiedClientsMapBitWidth() int
	VerifiedClientsMapHashFunction() func(input []byte) []byte
}

func AllCodes() []cid.Cid {
	return []cid.Cid{
		(&state9{}).Code(),
		(&state10{}).Code(),
		(&state11{}).Code(),
		(&state12{}).Code(),
		(&state13{}).Code(),
		(&state14{}).Code(),
		(&state15{}).Code(),
		(&state16{}).Code(),
		(&state17{}).Code(),
		(&state18{}).Code(),
		(&state19{}).Code(),
	}
}

func VersionCodes() map[actorstypes.Version]cid.Cid {
	return map[actorstypes.Version]cid.Cid{
		actorstypes.Version9:  (&state9{}).Code(),
		actorstypes.Version10: (&state10{}).Code(),
		actorstypes.Version11: (&state11{}).Code(),
		actorstypes.Version12: (&state12{}).Code(),
		actorstypes.Version13: (&state13{}).Code(),
		actorstypes.Version14: (&state14{}).Code(),
		actorstypes.Version15: (&state15{}).Code(),
		actorstypes.Version16: (&state16{}).Code(),
		actorstypes.Version17: (&state17{}).Code(),
		actorstypes.Version18: (&state18{}).Code(),
		actorstypes.Version19: (&state19{}).Code(),
	}
}
