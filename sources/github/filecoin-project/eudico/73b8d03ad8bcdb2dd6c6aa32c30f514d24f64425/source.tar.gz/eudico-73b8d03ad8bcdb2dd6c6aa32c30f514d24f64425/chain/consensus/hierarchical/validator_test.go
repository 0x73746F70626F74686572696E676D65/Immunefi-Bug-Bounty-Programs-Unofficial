package hierarchical

import (
	"testing"

	"github.com/stretchr/testify/require"
)

func TestValidatorsFromString(t *testing.T) {
	validators, err := ValidatorsFromString("t1wpixt5mihkj75lfhrnaa6v56n27epvlgwparujy@/ip4/127.0.0.1/tcp/10000/p2p/12D3KooWJhKBXvytYgPCAaiRtiNLJNSFG5jreKDu2jiVpJetzvVJ,t1k7t2zufxvtgamk7ogoifa5mvdagb4cafu6pdzga@/ip4/127.0.0.1/tcp/10001/p2p/12D3KooWKPASbibHcHMCEuUk5qx4AQbbPiNgot7F4A4VPeEV6srp,t1rlhubezzmetmmpxyze22tc2uxuiiqv3iy6rvpra@/ip4/127.0.0.1/tcp/10002/p2p/12D3KooWNuDQaGuwVLPyroJ4FZyNkiFcH2Qi61bNGehK2Mhgq3TK,t1sqbkluz5elnekdu62ute5zjammslkplgdcpa2zi@/ip4/127.0.0.1/tcp/10003/p2p/12D3KooWRF48VL58mRkp5DmysHp2wLwWyycJ6df2ocEHPvRxMrLs,t1sqbkluz5elnekdu62ute5zjammslkplgdcpa2zi@/ip4/127.0.0.1/tcp/10004/p2p/12D3KooWMMNKpXU1NNRE9WyH7CmV4JweJLpVyW76igZYVMfHAUtt\n")
	require.NoError(t, err)
	require.Equal(t, 5, len(validators))
}
