---
name: DEPRECATED Notary Application
about: Application to become a Notary and recieve DataCap to allocation (both new and existing notaries should fill this out)
title: ''
labels: Notary Application
assignees: ''

---
# DEPRECATED Notary Application
**Please use the new Allocator Application Template**


To apply to be a Fil+ Notary, please review the Notary Overview [here](https://github.com/filecoin-project/notary-governance/tree/main/notaries#overview) and then fill out the following form. 

## Core Information
- Name:
- Affiliated organization: 
- On-chain address to be notarized (recommend using a new address):
- Country of Operation: 
- Region of Operation: [North America, South America, Europe, Africa, Greater China Region (GCR), Asia minus GCR, Oceania]
- Use case(s) to be supported: [Please select from [here](https://github.com/filecoin-project/notary-governance/tree/main/notaries)]
- DataCap requested for allocation (10TiB - 1PiB):
- Are you applying on behalf of yourself or an organization?: [Individual, Organization]

_Please respond to the questions below in paragraph form, replacing the text saying "Please answer here". Include as much detail as you can in your answer!_

## Long Term Network Alignment
### Time Commitment
Describe the nature and duration of your affiliation with the Filecoin network. Please include relevant GitHub handles, Storage Provider IDs, significant projects or contributions (with links).
```
Please answer here.
```

### Stake Exposure
Please cite total token at stake (currently available, locked as collateral, vesting over time) and any substantiating evidence (i.e., addresses on chain with their corresponding FIL amounts).
```
Please answer here.
```

How did you acquire the FIL cited above?
```
Please answer here.
```

## Industry Reputation
### In-protocol Reputation
Please describe (in detail) your activity and tenure as a member of the Filecoin community. Please note (with links where possible) any contributions made to implementations of Filecoin, the spec, documentation, or to substantially help the Filecoin ecosystem grow. 
```
Please answer here.
```

### In-protocol Security
Please describe your contributions to the security of Filecoin and the duration over which you've made contributions. Please also include any links or references that can substantiate your contributions. 
```
Please answer here. 
```

### Organizational Reputation
Please describe the nature of your organization, including the country of registration, size of the organization, and time since inception.
```
Please answer here.
```

Please share any relevant details to help substantiate information about your organization (website, named officers, links to social media profiles).
```
Please answer here.
```

Please share any relevant external information regarding your organization (e.g. news articles, social media profiles, etc.)
```
Please answer here.
```

### Individual Reputation
Please share links to at least 2 of your (personal) social media profiles (or accounts that you are able to use) and the approximate size of your audience (i.e., followers, subscribers) for each one.
```
Please answer here.
```

Please share any additional relevant information regarding your presence (e.g. news articles, interviews, podcasts, videos, awards, etc.)
```
Please answer here.
```

# Allocation Plan [refer to the Rubric to see how this impacts your Notary score](https://docs.google.com/spreadsheets/d/172-sbd5qzdbSofvL_C5FHRyXEsTUpMiKspItygAVJA4/edit?usp=sharings)
## Concreteness of Allocation Plan 
### Allocation Strategy
How do you plan on allocating the DataCap requested above? Please describe your allocation strategy with as much specificity as you can. This includes the target amount per client and rate at which you'll allocate DataCap.
```
Please answer here.
```

How do you plan on securing the DataCap to ensure your organization (and its delegated members) are the ones allocating the DataCap?
```
Please answer here.
```

### Client Due Diligence
How will you vet the clients that are applying for DataCap? What questions will you ask to ensure your trust is placed well and that clients can properly handle the DataCap you intend to allocate to them? 
```
Please answer here. 
```

What processes will you employ when granting additional DataCap to a client that has previously been verified? This includes confirming that the client is not improperly using the DataCap they were previously granted, i.e., making deals with a single SP entity.
```
Please answer here. 
```

### Bookkeeping Plan
Do you plan on conducting all your allocation decisions in public (e.g. Github repo), private (e.g. over email, Telegram, etc), or both? 
```
Please answer here. 
```

Where do you plan on keeping a publicly accessible record of all your allocation decisions?
```
Please answer here.
```

## Service Level Agreement
### Engagement in Program
Which level (1-5) of service commitment are you willing to dedicate to participating in the Fil+ program? This includes making DataCap allocations (direct and/or Large Datasets), joining working groups, adding comments on discussion/issues, attendance in governance calls, messages in Slack, etc. For a full list of the service levels and time commitments please review the [rubric](https://github.com/filecoin-project/notary-governance/issues/630) 
```
Please answer here.
```


## Track Record
### Past allocation 
Have you previously received DataCap to allocate before? If so, please link to any previous applications.
```
Please answer here.
```

## Disclosures
Do you/your organization have any relationship(s) with other existing notaries or their organizations? If yes, please list the names of the Notary individuals or organizations you may be related to.
```
Please answer here.
```
