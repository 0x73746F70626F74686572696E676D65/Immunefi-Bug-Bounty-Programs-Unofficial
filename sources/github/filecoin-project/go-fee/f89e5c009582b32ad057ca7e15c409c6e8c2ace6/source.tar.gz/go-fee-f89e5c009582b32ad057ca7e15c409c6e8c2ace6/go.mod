module github.com/filecoin-project/go-fee

go 1.25.7

require (
	github.com/fxamacker/cbor/v2 v2.9.2
	github.com/go-jose/go-jose/v4 v4.1.4
	github.com/stretchr/testify v1.11.1
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	github.com/x448/float16 v0.8.4 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
