DROP TABLE params
