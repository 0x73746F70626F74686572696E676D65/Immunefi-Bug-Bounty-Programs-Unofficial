DROP TABLE leaderboard
