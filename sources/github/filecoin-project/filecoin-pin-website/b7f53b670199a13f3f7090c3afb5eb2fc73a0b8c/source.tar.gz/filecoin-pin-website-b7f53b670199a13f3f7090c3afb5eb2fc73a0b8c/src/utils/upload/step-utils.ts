import type { StepState } from '../../types/upload/step.ts'

export function getStepLabel(step: StepState['step']) {
  switch (step) {
    case 'creating-car':
    case 'checking-readiness':
      return 'Packing for IPFS'
    case 'uploading-car':
      return 'Uploading to Filecoin storage provider'
    case 'replicating':
      return 'Replicating across storage providers'
    case 'announcing-cids':
      return 'Announcing IPFS CIDs to IPNI'
    case 'finalizing-transaction':
      return 'Finalizing storage transaction on Calibration testnet'
  }
}

export function getStepEstimatedTime(step: StepState['step']) {
  switch (step) {
    case 'replicating':
      return 'Estimated time: ~10-60 seconds'
    case 'announcing-cids':
      return 'Estimated time: ~30 seconds'
    case 'finalizing-transaction':
      return 'Estimated time: ~30-60 seconds'
  }
}

export function stepHasActiveStatus(status?: StepState['status']) {
  return status === 'completed' || status === 'in-progress'
}
