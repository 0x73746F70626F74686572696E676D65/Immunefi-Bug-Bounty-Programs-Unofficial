// SPDX-License-Identifier: Apache-2.0 OR MIT
pragma solidity ^0.8.36;

// SRA registry tests
//
//   - orchestrator admission/cap: 64-full rejection, Remove release
//   - registerPairs: uniqueness, admission gating, re-claimable after Remove release
//   - replaceWallet: payout-wallet swap, identity does not move (spec §3.2); reassignBinding: binding reassignment

import {ERC1967Proxy} from "@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol";
import {Initializable} from "@openzeppelin/contracts/proxy/utils/Initializable.sol";

import {SRATestBase} from "./SRATestBase.sol";
import {FixedU18} from "../src/lib/FixedU18.sol";
import {Epoch} from "../src/lib/Epoch.sol";
import {ServiceRewardsActor} from "../src/ServiceRewardsActor.sol";
import {Binding, FilecoinPayVolume} from "../src/lib/SraTypes.sol";

/// @dev ERC-7201 Registry namespace slot (src/lib/SraStorage.sol) — the id allocator lives at
///      REGISTRY_SLOT + 3 (low 64 bits = allocatedIds). The test reads it directly because the id is
///      internal to the identity model (no public getter).
bytes32 constant REGISTRY_SLOT = 0xb7fd4b054ced95f43476af93bf71636318271f9e64f7661dc52f0fb4c1a54400;

contract SRARegistryTest is SRATestBase {
    // ------------------------------------------------------------------------
    // Orchestrator admission
    // ------------------------------------------------------------------------
    function test_Initialize_SeedsInitialOrchestratorAndEmitsAdmission() public {
        address orch = makeAddr("seed-orchestrator");
        address wallet = makeAddr("seed-wallet");
        address implementation = address(
            new ServiceRewardsActor(
                owner1,
                owner2,
                orch,
                wallet,
                Epoch.wrap(EPOCHS_PER_QUARTER),
                Epoch.wrap(POST_PERIOD),
                Epoch.wrap(VERIFICATION_WINDOW),
                Epoch.wrap(ACTIVATION_EPOCH),
                Epoch.wrap(SRA_UPGRADE_HOLD)
            )
        );

        vm.expectEmit(true, false, false, true);
        emit ServiceRewardsActor.OrchestratorAdmitted(orch, wallet);
        ServiceRewardsActor seeded = ServiceRewardsActor(
            address(new ERC1967Proxy(implementation, abi.encodeCall(ServiceRewardsActor.initialize, ())))
        );

        assertTrue(seeded.isAdmitted(orch));
        assertEq(seeded.admittedCount(), 1);
        vm.expectRevert(Initializable.InvalidInitialization.selector);
        seeded.initialize();
    }

    function test_Constructor_WithoutInitialOrchestrator_Reverts() public {
        vm.expectRevert(ServiceRewardsActor.InvalidParameter.selector);
        new ServiceRewardsActor(
            owner1,
            owner2,
            address(0),
            makeAddr("seed-wallet"),
            Epoch.wrap(EPOCHS_PER_QUARTER),
            Epoch.wrap(POST_PERIOD),
            Epoch.wrap(VERIFICATION_WINDOW),
            Epoch.wrap(ACTIVATION_EPOCH),
            Epoch.wrap(SRA_UPGRADE_HOLD)
        );
    }

    /// addOrchestrator carries a distinct payout wallet (no default wallet=orch); the
    /// OrchestratorAdmitted event carries the wallet, while bindingOf resolves the pair to the
    /// admit-time orchestrator identity (identity and wallet are separate concepts).
    function test_Admit_WalletDistinctFromOrch_EmitsWallet() public {
        address orch = makeAddr("orch");
        address wallet = _wallet("wallet"); // distinct payout wallet
        vm.prank(owner1);
        sra.addOrchestrator(orch, wallet); // vote 1 (approve)
        vm.expectEmit(true, false, false, true, address(sra));
        emit ServiceRewardsActor.OrchestratorAdmitted(orch, wallet);
        vm.prank(owner2);
        sra.addOrchestrator(orch, wallet); // vote 2 executes the body

        assertTrue(sra.isAdmitted(orch));
        Binding[] memory pairs = new Binding[](1);
        pairs[0] = _pair(makeAddr("payer"), makeAddr("operator"));
        _registerPairsAs(orch, pairs);
        assertEq(sra.bindingOf(makeAddr("payer"), makeAddr("operator")), orch); // identity, not wallet
        assertNotEq(sra.bindingOf(makeAddr("payer"), makeAddr("operator")), wallet);
    }

    /// Once the seeded Orchestrator plus 63 later admissions reaches 64, the next admit is rejected.
    function test_Admit_AtCapacity_Reverts() public {
        for (uint256 i = 0; i < 63; i++) {
            _admit(makeAddr(string.concat("orch-", vm.toString(i))), makeAddr(string.concat("orch-", vm.toString(i))));
        }
        assertEq(sra.admittedCount(), 64);

        address orch65 = makeAddr("orch-65");
        vm.prank(owner1);
        sra.addOrchestrator(orch65, orch65); // vote 1 (approve)
        vm.expectRevert(); // cap rejection: admit is full at 64 (second vote executes the body)
        vm.prank(owner2);
        sra.addOrchestrator(orch65, orch65);
    }

    /// After Remove frees a slot, a new orchestrator can be admitted.
    function test_Admit_RemoveFreesSlot() public {
        for (uint256 i = 0; i < 63; i++) {
            _admit(makeAddr(string.concat("orch-", vm.toString(i))), makeAddr(string.concat("orch-", vm.toString(i))));
        }
        address removed = makeAddr("orch-0");
        _remove(removed);
        assertEq(sra.admittedCount(), 63);

        _admit(makeAddr("orch-new"), makeAddr("orch-new")); // slot freed, can admit
        assertEq(sra.admittedCount(), 64);
    }

    /// Pre-activation removal succeeds: setUp leaves block.number (≈ 1 + MAINNET_TIMELOCK) below
    /// ACTIVATION_EPOCH, where no quarter has ever ended. The §3.2 guard must not block — nothing
    /// can be pending before activation (removal touches only the admitted set).
    function test_Remove_PreActivation_Succeeds() public {
        assertLt(block.number, ACTIVATION_EPOCH, "setUp must leave the contract pre-activation");
        address orch = makeAddr("pre-act");
        _admit(orch, orch);

        _remove(orch);

        assertFalse(sra.isAdmitted(orch));
        assertEq(sra.admittedCount(), 1, "initial Orchestrator remains admitted");
    }

    // ------------------------------------------------------------------------
    // registerPairs
    // ------------------------------------------------------------------------

    /// an admitted orchestrator can register binding pairs.
    function test_RegisterPairs_Success() public {
        address orch = makeAddr("orch");
        _admit(orch, orch);

        Binding[] memory pairs = new Binding[](1);
        pairs[0] = _pair(makeAddr("payer"), makeAddr("operator"));

        _registerPairsAs(orch, pairs);
        assertEq(sra.bindingOf(makeAddr("payer"), makeAddr("operator")), orch);
    }

    /// a non-admitted address cannot registerPairs.
    function test_RegisterPairs_NotAdmitted_Reverts() public {
        address stranger = makeAddr("stranger");
        Binding[] memory pairs = new Binding[](1);
        pairs[0] = _pair(makeAddr("payer"), makeAddr("operator"));

        vm.prank(stranger);
        vm.expectRevert();
        sra.registerPairs(pairs);
    }

    /// registerPairs reverts when the pair is already bound to another (uniqueness invariant).
    function test_RegisterPairs_DuplicatePair_Reverts() public {
        address orchA = makeAddr("orchA");
        address orchB = makeAddr("orchB");
        _admit(orchA, orchA);
        _admit(orchB, orchB);

        Binding[] memory pairs = new Binding[](1);
        pairs[0] = _pair(makeAddr("payer"), makeAddr("operator"));
        _registerPairsAs(orchA, pairs);

        vm.prank(orchB);
        vm.expectRevert(); // already bound to another -> uniqueness rejection
        sra.registerPairs(pairs);
    }

    /// the same orchestrator re-registering the same pair reverts (self-duplicates also disallowed).
    function test_RegisterPairs_SameOrchDuplicatePair_Reverts() public {
        address orch = makeAddr("orch");
        _admit(orch, orch);

        Binding[] memory pairs = new Binding[](1);
        pairs[0] = _pair(makeAddr("payer"), makeAddr("operator"));
        _registerPairsAs(orch, pairs);

        vm.prank(orch);
        vm.expectRevert();
        sra.registerPairs(pairs);
    }

    /// registerPairs with more than MAX_PAIRS (64) pairs reverts TooManyPairs (array-length bound).
    function test_RegisterPairs_TooManyPairs_Reverts() public {
        address orch = makeAddr("orch");
        _admit(orch, orch);

        Binding[] memory pairs = new Binding[](65);
        for (uint256 i = 0; i < pairs.length; i++) {
            pairs[i] =
                _pair(makeAddr(string.concat("payer", vm.toString(i))), makeAddr(string.concat("op", vm.toString(i))));
        }

        vm.prank(orch);
        vm.expectRevert(abi.encodeWithSelector(ServiceRewardsActor.TooManyPairs.selector));
        sra.registerPairs(pairs);
    }

    /// Control: exactly MAX_PAIRS (64) pairs is accepted (boundary value).
    function test_RegisterPairs_MaxPairs_Accepted() public {
        address orch = makeAddr("orch");
        _admit(orch, orch);

        Binding[] memory pairs = new Binding[](64);
        for (uint256 i = 0; i < pairs.length; i++) {
            pairs[i] =
                _pair(makeAddr(string.concat("payer", vm.toString(i))), makeAddr(string.concat("op", vm.toString(i))));
        }

        _registerPairsAs(orch, pairs);
        assertEq(sra.bindingOf(makeAddr("payer0"), makeAddr("op0")), orch);
    }

    /// Remove releases all bindings; pairs return to unclaimed and can be claimed by other orchestrators.
    function test_Remove_ReleasesPairs_CanBeReclaimed() public {
        address orchA = makeAddr("orchA");
        address orchB = makeAddr("orchB");
        _admit(orchA, orchA);
        _admit(orchB, orchB);

        Binding[] memory pairs = new Binding[](1);
        pairs[0] = _pair(makeAddr("payer"), makeAddr("operator"));
        _registerPairsAs(orchA, pairs);
        assertEq(sra.bindingOf(makeAddr("payer"), makeAddr("operator")), orchA);

        _remove(orchA);

        // released binding reads as unclaimed immediately (bindingOf returns 0 for a removed id)
        assertEq(sra.bindingOf(makeAddr("payer"), makeAddr("operator")), address(0));

        // original orchestrator removed; B can claim the same pair
        _registerPairsAs(orchB, pairs);
        assertEq(sra.bindingOf(makeAddr("payer"), makeAddr("operator")), orchB);
    }

    // ------------------------------------------------------------------------
    // replace / reassignBinding
    // ------------------------------------------------------------------------

    /// replaceWallet swaps the payout wallet (spec §3.2): the identity does not move — oldOrch stays
    /// admitted, and bindingOf keeps resolving to the same orchestrator identity (only the payout
    /// wallet reads as newWallet).
    function test_Replace_SwapsWallet() public {
        address oldOrch = makeAddr("oldOrch");
        address newWallet = _wallet("newWallet");
        _admit(oldOrch, oldOrch);

        Binding[] memory pairs = new Binding[](1);
        pairs[0] = _pair(makeAddr("payer"), makeAddr("operator"));
        _registerPairsAs(oldOrch, pairs);

        // governance replaceWallet(old, new): two votes; second executes (unanimousNoHold)
        vm.prank(owner1);
        sra.replaceWallet(oldOrch, newWallet);
        vm.expectEmit(true, true, false, true, address(sra));
        emit ServiceRewardsActor.OrchestratorWalletReplaced(oldOrch, newWallet);
        vm.prank(owner2);
        sra.replaceWallet(oldOrch, newWallet); // second vote executes (unanimousNoHold)

        assertTrue(sra.isAdmitted(oldOrch), "identity does not move (spec 3.2)");
        assertFalse(sra.isAdmitted(newWallet), "the new wallet is not an orchestrator identity");
        // the binding stays with the same orchestrator; bindingOf reads its identity, which a
        // replaceWallet does not move (issue #34: bindingOf returns the identity, not the wallet)
        assertEq(sra.bindingOf(makeAddr("payer"), makeAddr("operator")), oldOrch);
    }

    /// After replace, a third party cannot grab the binding pair — registerPairs's AlreadyBound
    /// check resolves along the identity to the current wallet.
    function test_RegisterPairs_AfterReplace_ThirdPartyReverts() public {
        address orchA = makeAddr("orchA");
        address orchB = _wallet("orchB"); // fresh address: the new payout wallet (identity stays at orchA)
        address orchC = makeAddr("orchC");
        _admit(orchA, orchA);
        _admit(orchC, orchC); // a third party must be admitted to reach the AlreadyBound check (registerPairs gating)

        Binding[] memory pairs = new Binding[](1);
        pairs[0] = _pair(makeAddr("payer"), makeAddr("operator"));
        _registerPairsAs(orchA, pairs);
        assertEq(sra.bindingOf(makeAddr("payer"), makeAddr("operator")), orchA);

        // governance replaceWallet(orchA -> orchB): two votes; second executes (unanimousNoHold)
        vm.prank(owner1);
        sra.replaceWallet(orchA, orchB);
        vm.prank(owner2);
        sra.replaceWallet(orchA, orchB); // second vote executes (unanimousNoHold)

        assertTrue(sra.isAdmitted(orchA), "identity does not move (spec 3.2)");
        assertFalse(sra.isAdmitted(orchB), "the new wallet is not an orchestrator identity");
        // the binding stays with the same orchestrator; bindingOf reads its identity, which a
        // replaceWallet does not move (issue #34: bindingOf returns the identity, not the wallet)
        assertEq(sra.bindingOf(makeAddr("payer"), makeAddr("operator")), orchA);

        // third party orchC tries to grab the same pair -> expect AlreadyBound revert
        vm.prank(orchC);
        vm.expectRevert();
        sra.registerPairs(pairs);
    }

    /// reassignBinding reassigns the (payer, operator) binding to another orchestrator.
    function test_ReassignBinding_ChangesBinding() public {
        address orchA = makeAddr("orchA");
        address orchB = makeAddr("orchB");
        _admit(orchA, orchA);
        _admit(orchB, orchB);

        Binding[] memory pairs = new Binding[](1);
        pairs[0] = _pair(makeAddr("payer"), makeAddr("operator"));
        _registerPairsAs(orchA, pairs);
        assertEq(sra.bindingOf(makeAddr("payer"), makeAddr("operator")), orchA);

        // governance reassignBinding(payer, operator, orchB); inherit carried in the event only
        vm.prank(owner1);
        sra.reassignBinding(makeAddr("payer"), makeAddr("operator"), orchB, true);
        vm.expectEmit(true, true, true, true, address(sra));
        emit ServiceRewardsActor.BindingReassigned(makeAddr("payer"), makeAddr("operator"), orchB, true);
        vm.prank(owner2);
        sra.reassignBinding(makeAddr("payer"), makeAddr("operator"), orchB, true); // second vote executes (unanimousNoHold)

        assertEq(sra.bindingOf(makeAddr("payer"), makeAddr("operator")), orchB);
    }

    // ------------------------------------------------------------------------
    // Governance failure-path closure (replaceWallet / reassignBinding / removeOrchestrator body-revert branches)
    // ------------------------------------------------------------------------

    /// A new wallet colliding with any admitted orchestrator's wallet -> DuplicateWallet revert.
    /// (Replace does not re-check the identity namespace — wallet and identity are decoupled; newWallet is
    /// admitted with _admit(x,x), so its wallet == itself and collides with the row being replaced.)
    function test_Replace_DuplicateWalletTarget_Reverts() public {
        address oldOrch = makeAddr("oldOrch");
        address newWallet = makeAddr("newWallet");
        _admit(oldOrch, oldOrch);
        _admit(newWallet, newWallet); // admitted: its wallet == itself -> collides with the new wallet

        vm.prank(owner1);
        sra.replaceWallet(oldOrch, newWallet); // vote 1 (approve)
        vm.expectRevert(); // DuplicateWallet(newWallet)
        vm.prank(owner2);
        sra.replaceWallet(oldOrch, newWallet); // vote 2 executes the body -> revert
    }

    /// The new wallet equals another orchestrator's *identity* address (wallet/identity decoupled) ->
    /// succeeds, as long as the wallet field itself does not collide with another orchestrator's wallet.
    function test_Replace_WalletEqualsOtherIdentity_Succeeds() public {
        address oldOrch = makeAddr("oldOrch");
        address orchB = _wallet("orchB"); // another orchestrator's identity address
        _admit(oldOrch, makeAddr("old-wallet")); // oldOrch's wallet is distinct
        _admit(orchB, makeAddr("orchB-wallet")); // orchB's wallet is distinct ( != its identity address)

        vm.prank(owner1);
        sra.replaceWallet(oldOrch, orchB); // new wallet = orchB (another identity's address)
        vm.prank(owner2);
        sra.replaceWallet(oldOrch, orchB); // succeeds: the wallet collides with no other wallet

        assertTrue(sra.isAdmitted(oldOrch), "identity does not move");
        assertTrue(sra.isAdmitted(orchB), "orchB identity unaffected");
    }

    /// reassignBinding target not admitted -> NotAdmitted revert at the body execution.
    function test_ReassignBinding_NotAdmittedTarget_Reverts() public {
        address orchA = makeAddr("orchA");
        _admit(orchA, orchA);

        Binding[] memory pairs = new Binding[](1);
        pairs[0] = _pair(makeAddr("payer"), makeAddr("operator"));
        _registerPairsAs(orchA, pairs);

        address stranger = makeAddr("stranger"); // unadmitted target
        vm.prank(owner1);
        sra.reassignBinding(makeAddr("payer"), makeAddr("operator"), stranger, false); // vote 1 (approve)
        vm.expectRevert(); // NotAdmitted(stranger)
        vm.prank(owner2);
        sra.reassignBinding(makeAddr("payer"), makeAddr("operator"), stranger, false); // vote 2 executes the body -> revert
    }

    /// remove on a non-orchestrator (unadmitted) -> NotAdmitted revert at the body execution.
    function test_Remove_NotAdmitted_Reverts() public {
        address stranger = makeAddr("stranger");
        vm.prank(owner1);
        sra.removeOrchestrator(stranger); // vote 1 (approve)
        vm.expectRevert(); // NotAdmitted(stranger)
        vm.prank(owner2);
        sra.removeOrchestrator(stranger); // vote 2 executes the body -> revert
    }

    // ------------------------------------------------------------------------
    // Governance failure branches + read-only view
    // ------------------------------------------------------------------------

    /// Re-admitting the same address -> AlreadyAdmitted revert at the body execution.
    function test_Admit_AlreadyAdmitted_Reverts() public {
        address orch = makeAddr("orch");
        _admit(orch, orch);
        assertTrue(sra.isAdmitted(orch));

        vm.prank(owner1);
        sra.addOrchestrator(orch, orch); // vote 1 (approve)
        vm.expectRevert(); // AlreadyAdmitted(orch)
        vm.prank(owner2);
        sra.addOrchestrator(orch, orch); // vote 2 executes the body -> revert
    }

    /// Replace with an unadmitted old address -> NotAdmitted(oldOrch) revert.
    function test_Replace_OldNotAdmitted_Reverts() public {
        address stranger = makeAddr("stranger"); // old address never admitted
        address newWallet = makeAddr("newWallet");

        vm.prank(owner1);
        sra.replaceWallet(stranger, newWallet); // vote 1 (approve)
        vm.expectRevert(); // NotAdmitted(stranger)
        vm.prank(owner2);
        sra.replaceWallet(stranger, newWallet); // vote 2 executes the body -> revert
    }

    /// orchestratorCount reflects admission/removal counts (consistent with admittedCount).
    function test_OrchestratorCount_ReflectsAdmissions() public {
        assertEq(sra.orchestratorCount(), 1);

        address a = makeAddr("orchA");
        address b = makeAddr("orchB");
        _admit(a, a);
        _admit(b, b);
        assertEq(sra.orchestratorCount(), 3);
        assertEq(sra.orchestratorCount(), sra.admittedCount()); // view consistency

        _remove(a);
        assertEq(sra.orchestratorCount(), 2);
    }

    // ------------------------------------------------------------------------
    // id-keyed identity: re-admit = fresh id (structural, not a cleanup step)
    // ------------------------------------------------------------------------

    /// id-keyed identity: re-admit of a removed address allocates a fresh id — the removed identity's bindings
    /// (pair bound by the old id) and FilecoinPayVolume do not carry over. The pair stays claimable and the fresh id's quarter
    /// record is empty (the old record lives on only under the archived id, unreachable from the address).
    function test_ReAdmit_FreshIdentity_NoBindingsNoFilecoinPayVolume() public {
        address oldOrch = makeAddr("fresh-old");
        address third = makeAddr("fresh-third");
        _admit(oldOrch, oldOrch);
        _admit(third, third);

        Binding[] memory pairs = new Binding[](1);
        pairs[0] = _pair(makeAddr("payer"), makeAddr("operator"));
        _registerPairsAs(oldOrch, pairs);
        assertEq(sra.bindingOf(makeAddr("payer"), makeAddr("operator")), oldOrch);

        vm.roll(_quarterStart(1) + 1); // q1 posting window
        _postAs(oldOrch, 1, _fpv(100e18));
        vm.roll(_bindingStart(1) + 1);
        sra.submitShares(1);

        _remove(oldOrch);
        assertFalse(sra.isAdmitted(oldOrch));

        // re-admit the same address: fresh identity
        _admit(oldOrch, oldOrch);
        assertTrue(sra.isAdmitted(oldOrch));

        // the removed identity's binding does not carry over: the pair is claimable by a third party
        _registerPairsAs(third, pairs); // no revert -> the old id's binding is not inherited
        assertEq(sra.bindingOf(makeAddr("payer"), makeAddr("operator")), third);

        // the removed identity's FilecoinPayVolume does not carry over: the fresh id's quarter-1 record is empty
        FilecoinPayVolume memory f = sra.fpvOf(1, oldOrch);
        assertEq(FixedU18.unwrap(f.usd), 0);
    }

    /// id allocation is monotonic and never reuses an id: 0 is the unregistered sentinel, and the
    /// deployment-seeded Orchestrator consumes id 1. Later admissions increase strictly; remove +
    /// re-admit of the same address consumes a new id (never the archived one).
    /// Reads the ERC-7201 registry slot directly (no public getter — the id is internal to the identity model).
    function test_Admit_IdMonotonic_NeverReused() public {
        bytes32 slot = bytes32(uint256(REGISTRY_SLOT) + 3); // allocatedIds sits alone in slot3's low 64 bits (no admittedCount packing)
        assertEq(uint64(uint256(vm.load(address(sra), slot))), 1, "initial Orchestrator consumes id 1");

        address a = makeAddr("id-a");
        _admit(a, a);
        assertEq(uint64(uint256(vm.load(address(sra), slot))), 2, "first later admit consumes id 2");

        _remove(a);
        _admit(a, a); // re-admit allocates a NEW id (never reused)
        assertEq(uint64(uint256(vm.load(address(sra), slot))), 3, "re-admit allocates a fresh id");

        _admit(makeAddr("id-b"), makeAddr("id-b"));
        assertEq(uint64(uint256(vm.load(address(sra), slot))), 4, "ids increase strictly");
    }

    // ------------------------------------------------------------------------
    // admittedIndex (O(1) removal bookkeeping) — raw ERC-7201 slot reads (no public getter)
    // ------------------------------------------------------------------------

    /// @dev admittedIds: uint64[] at REGISTRY_SLOT+4; elements packed 4 per 32B word (8B each), low-bytes first.
    bytes32 internal constant ADMITTED_IDS_SLOT = bytes32(uint256(REGISTRY_SLOT) + 4);

    function _admittedIdsLength() internal view returns (uint256 n) {
        n = uint256(vm.load(address(sra), ADMITTED_IDS_SLOT));
    }

    function _admittedIdAt(uint256 i) internal view returns (uint64 id) {
        bytes32 wordSlot = bytes32(uint256(keccak256(abi.encode(uint256(ADMITTED_IDS_SLOT)))) + i / 4);
        id = uint64(uint256(vm.load(address(sra), wordSlot)) >> ((i % 4) * 64));
    }

    /// @dev orchestrators mapping at REGISTRY_SLOT; struct word 4 = admittedIndex (orchestrator field added in word 0 shifts it past mirrorA/mirrorB).
    function _admittedIndexOf(uint64 id) internal view returns (uint64 idx) {
        bytes32 base = keccak256(abi.encode(uint64(id), REGISTRY_SLOT));
        idx = uint64(uint256(vm.load(address(sra), bytes32(uint256(base) + 4))));
    }

    /// OrchestratorInfo invariant: every admitted id's admittedIndex == its position in admittedIds.
    function _assertIndexConsistent() internal view {
        uint256 n = _admittedIdsLength();
        for (uint256 i = 0; i < n; i++) {
            uint64 id = _admittedIdAt(i);
            assertEq(_admittedIndexOf(id), i, "admittedIndex must equal array position");
        }
    }

    /// O(1) removal core: removing a middle element swaps the last one into its slot — the swapped
    /// element's admittedIndex must be rewritten to the new position (swap double-write).
    function test_Remove_MiddleElement_SwapUpdatesIndex() public {
        _remove(initialOrchestrator);
        address a = makeAddr("mid-a");
        address b = makeAddr("mid-b");
        address c = makeAddr("mid-c");
        _admit(a, a);
        _admit(b, b);
        _admit(c, c); // ids 2, 3, 4

        _remove(b); // remove middle (id 3): list [2, 4] — id 4 swapped into position 1

        assertEq(_admittedIdsLength(), 2);
        assertEq(_admittedIdAt(0), 2);
        assertEq(_admittedIdAt(1), 4, "last element swapped into removed slot");
        assertEq(_admittedIndexOf(4), 1, "swapped element's admittedIndex rewritten");
        assertEq(_admittedIndexOf(2), 0, "untouched element's admittedIndex intact");
        assertEq(_admittedIndexOf(3), 0, "removed id's admittedIndex cleared (dead pointer)");
        _assertIndexConsistent();
    }

    /// Removing the last element: no swap; remaining indices unchanged.
    function test_Remove_LastElement_IndexIntact() public {
        _remove(initialOrchestrator);
        address a = makeAddr("last-a");
        address b = makeAddr("last-b");
        _admit(a, a);
        _admit(b, b); // ids 2, 3

        _remove(b); // remove last (id 3): list [2]

        assertEq(_admittedIdsLength(), 1);
        assertEq(_admittedIdAt(0), 2);
        assertEq(_admittedIndexOf(2), 0, "remaining element's index unchanged");
        assertEq(_admittedIndexOf(3), 0, "removed id's admittedIndex cleared (dead pointer)");
        _assertIndexConsistent();
    }

    /// Multiple removals in sequence: the index invariant holds after every step (head/middle/last mixed).
    function test_Remove_ConsecutiveRemoves_IndexAlwaysConsistent() public {
        _remove(initialOrchestrator);
        address a = makeAddr("seq-a");
        address b = makeAddr("seq-b");
        address c = makeAddr("seq-c");
        address d = makeAddr("seq-d");
        _admit(a, a);
        _admit(b, b);
        _admit(c, c);
        _admit(d, d); // ids 2, 3, 4, 5

        _remove(a); // head: list [5, 3, 4]
        assertEq(_admittedIndexOf(5), 0, "head removal swaps last to front");
        assertEq(_admittedIndexOf(2), 0, "removed id's admittedIndex cleared (dead pointer)");
        _assertIndexConsistent();

        _remove(c); // middle: list [5, 3]
        assertEq(_admittedIndexOf(3), 1, "middle removal swaps last to slot 1");
        assertEq(_admittedIndexOf(4), 0, "removed id's admittedIndex cleared (dead pointer)");
        _assertIndexConsistent();

        _remove(b); // last: list [5]
        assertEq(_admittedIndexOf(3), 0, "removed id's admittedIndex cleared (dead pointer)");
        _assertIndexConsistent();

        assertEq(_admittedIdsLength(), 1);
        assertEq(_admittedIdAt(0), 5);
    }

    /// Re-admit after removal: the new id is pushed at list.length — its admittedIndex must be that position.
    /// Removes the last element (id 2): its stale admittedIndex would be 1, colliding with the new id's push
    /// position — clearing the dead pointer is what keeps the two apart.
    function test_Remove_ThenAdmit_NewAdmitGetsPushIndex() public {
        _remove(initialOrchestrator);
        address a = makeAddr("readmit-a");
        address b = makeAddr("readmit-b");
        _admit(a, a);
        _admit(b, b); // ids 2, 3; list [2, 3]

        _remove(b); // list [2] (length 1)
        assertEq(_admittedIndexOf(3), 0, "removed id's admittedIndex cleared (dead pointer)");

        address c = makeAddr("readmit-c");
        _admit(c, c); // id 4 pushed at position 1

        assertEq(_admittedIdsLength(), 2);
        assertEq(_admittedIdAt(0), 2);
        assertEq(_admittedIdAt(1), 4);
        assertEq(_admittedIndexOf(4), 1, "new admit's admittedIndex == push position (list.length)");
        _assertIndexConsistent();
    }
}
