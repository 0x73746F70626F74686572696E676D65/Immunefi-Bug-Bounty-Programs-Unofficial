// SPDX-License-Identifier: Apache-2.0 OR MIT
pragma solidity ^0.8.36;

// Active-quarter aggregate mirror — differential tests
//   aggregatedFilecoinPayVolume reads the O(1) mirror (totalUsd) for the active quarter; these
//   tests pin the mirror to the linear-scan semantics across post / correct /
//   replace / remove, plus the historical-quarter fallback.
//
// Time model (test base): E(Q)=100000+Q*1000; posting (E,E+300]; verification
//   (E+300,E+700]; post-binding > E+700. Governance methods execute immediately
//   (unanimousNoHold, spec §4.2).

import {SRATestBase} from "./SRATestBase.sol";
import {FixedU18} from "../src/lib/FixedU18.sol";
import {SERVICE_ID, Share} from "../src/lib/FVMRewardTypes.sol";
import {ServiceRewardsActor} from "../src/ServiceRewardsActor.sol";

contract SRAggregateMirrorTest is SRATestBase {
    /// Basic: two posters — mirror == their sum.
    function test_Mirror_Basic() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        _admit(a, a);
        _admit(b, b);

        vm.roll(_quarterStart(1) + 1); // posting
        _postAs(a, 1, _fpv(100e18));
        _postAs(b, 1, _fpv(200e18));

        vm.roll(_bindingStart(1) + 1); // post-binding
        assertEq(FixedU18.unwrap(sra.aggregatedFilecoinPayVolume(1)), 300e18);
    }

    /// Unposted orchestrator never enters the mirror.
    function test_Mirror_Unposted_Excluded() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        _admit(a, a);
        _admit(b, b);

        vm.roll(_quarterStart(1) + 1);
        _postAs(a, 1, _fpv(100e18));

        vm.roll(_bindingStart(1) + 1);
        assertEq(FixedU18.unwrap(sra.aggregatedFilecoinPayVolume(1)), 100e18);
    }

    /// CorrectVolume adjusts the mirror (up / down / clear-to-zero).
    function test_Mirror_CorrectVolume_Sync() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        _admit(a, a);
        _admit(b, b);

        vm.roll(_quarterStart(1) + 1);
        _postAs(a, 1, _fpv(100e18));
        _postAs(b, 1, _fpv(200e18));

        vm.roll(_postEnd(1) + 1); // verification window
        _correctVolume(a, 1, _fpv(150e18)); // up
        _correctVolume(b, 1, 0); // clear

        vm.roll(_bindingStart(1) + 1);
        assertEq(FixedU18.unwrap(sra.aggregatedFilecoinPayVolume(1)), 150e18);
    }

    /// Replacement during posting transfers identity — the old orchestrator's contribution is
    /// inherited by the new identity (aggregate unchanged; ownership moves), per the mirror design.
    function test_Mirror_ReplaceInPosting_Inherits() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        address a2 = _wallet("a2");
        _admit(a, a);
        _admit(b, b);

        vm.roll(_quarterStart(1) + 1);
        _postAs(a, 1, _fpv(100e18));
        _postAs(b, 1, _fpv(200e18));

        vm.prank(owner1);
        sra.replaceWallet(a, a2);
        vm.prank(owner2);
        sra.replaceWallet(a, a2); // second vote executes (unanimousNoHold) — still inside posting window

        vm.roll(_bindingStart(1) + 1);
        assertEq(FixedU18.unwrap(sra.aggregatedFilecoinPayVolume(1)), 300e18); // inherited — no deduction
    }

    /// Removal after the pending quarter is submitted leaves the bound aggregate as a binding
    /// snapshot — the §3.2 guard makes any removal post-binding, so no deduction rewrites the
    /// quarter's counter (spec §2.2: the read view exposes the bound values directly).
    function test_Mirror_Remove_Deducts() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        _admit(a, a);
        _admit(b, b);

        vm.roll(_quarterStart(1) + 1);
        _postAs(a, 1, _fpv(100e18));
        _postAs(b, 1, _fpv(200e18));

        vm.roll(_bindingStart(1) + 1); // q1 binds
        sra.submitShares(1); // guard lifts
        _remove(a); // post-binding removal: the aggregate is a binding snapshot, not rewritten
        assertEq(FixedU18.unwrap(sra.aggregatedFilecoinPayVolume(1)), 300e18);
    }

    /// Mirror switches quarters; the previous quarter falls back to the linear scan.
    function test_Mirror_QuarterSwitch_HistoricalFallback() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        _admit(a, a);
        _admit(b, b);

        vm.roll(_quarterStart(1) + 1);
        _postAs(a, 1, _fpv(100e18));
        vm.roll(_bindingStart(1) + 1);
        assertEq(FixedU18.unwrap(sra.aggregatedFilecoinPayVolume(1)), 100e18); // mirror for q1

        // quarter 2: mirror re-points; q1 becomes historical (linear fallback)
        vm.roll(_quarterStart(2) + 1);
        _postAs(b, 2, _fpv(50e18));
        vm.roll(_bindingStart(2) + 1);
        assertEq(FixedU18.unwrap(sra.aggregatedFilecoinPayVolume(1)), 100e18); // fallback scan
        assertEq(FixedU18.unwrap(sra.aggregatedFilecoinPayVolume(2)), 50e18); // mirror for q2
    }

    /// Lagging SubmitShares (spec: operates on the latest bound quarter, up to one quarter of lag):
    /// q1's mirror slot keeps its quarter tag while q2 writes into the other slot, so the lagging
    /// submitShares(1) matches the q1 tag and collects both contributors from that slot.
    function test_Mirror_SubmitShares_Lagging_ReadsPrevSlot() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        _admit(a, a);
        _admit(b, b);

        vm.roll(_quarterStart(1) + 1);
        _postAs(a, 1, _fpv(100e18));
        _postAs(b, 1, _fpv(200e18));

        // q2 writes into the second slot (a posts again — a fresh write only ever erases a
        // superseded quarter, so q1's tagged slot survives)
        vm.roll(_quarterStart(2) + 1);
        _postAs(a, 2, _fpv(50e18));

        // q1 is still the latest bound quarter (q2 not bound yet): lagging submit matches the q1 tag
        sra.submitShares(1);
        Share[] memory shares = rewardActor().getShares(SERVICE_ID);
        assertEq(shares.length, 2, "both q1 contributors from the mirror");
        // f02 stores shares in recipient order, so a's row is found by lookup, not by position.
        assertEq(_shareOf(shares, a), uint256(1e18) / 3, "a weighted by its q1 value of 100, not its q2 value");
        assertEq(_shareOf(shares, a) + _shareOf(shares, b), 1e18, "shares sum to 100%");
    }

    /// correctVolume can be the first writer of a quarter (backfill): the quarter gets its own
    /// tagged slot, and a backfill for an unposted orchestrator joins the already-posted ones.
    function test_Mirror_CorrectVolume_FirstWrite_Advances() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        _admit(a, a);
        _admit(b, b);

        vm.roll(_quarterStart(1) + 1);
        _postAs(a, 1, _fpv(100e18));

        // q=1: nobody posted — correctVolume backfill is the first write to q=1's own tagged slot
        vm.roll(_postEnd(2) + 1);
        _correctVolume(b, 2, _fpv(200e18));

        vm.roll(_bindingStart(2) + 1);
        assertEq(FixedU18.unwrap(sra.aggregatedFilecoinPayVolume(1)), 100e18); // q1 snapshot intact
        assertEq(FixedU18.unwrap(sra.aggregatedFilecoinPayVolume(2)), 200e18); // q2 counter

        sra.submitShares(2); // q2 latest bound, active quarter: reads fpv (b only)
        Share[] memory shares = rewardActor().getShares(SERVICE_ID);
        assertEq(shares.length, 1, "backfill only contributor of q2");
        assertEq(shares[0].wallet, b);
        assertEq(FixedU18.unwrap(shares[0].share), 1e18);
    }

    /// correctVolume backfill into a fresh tagged slot must not leak the previous quarter's value
    /// into the new quarter's counter: the old value is read from the quarter's own slot (0 for a
    /// fresh one), so a backfill with value < oldUsd cannot underflow and value > oldUsd lands exactly.
    function test_Mirror_CorrectVolume_Advance_NoLeak() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        _admit(a, a);
        _admit(b, b);

        vm.roll(_quarterStart(1) + 1);
        _postAs(a, 1, _fpv(100e18));
        _postAs(b, 1, _fpv(200e18));

        // q2 nobody posted: correctVolume backfills land in a fresh q2 slot, where every
        // orchestrator's old value reads 0 — a: value < oldUsd cannot underflow; b: value > oldUsd
        // lands exactly; neither may carry q1's contribution into the q2 counter.
        vm.roll(_postEnd(2) + 1);
        _correctVolume(a, 2, _fpv(50e18));
        _correctVolume(b, 2, _fpv(300e18));

        vm.roll(_bindingStart(2) + 1);
        assertEq(FixedU18.unwrap(sra.aggregatedFilecoinPayVolume(2)), 350e18); // 50 + 300, no leak from q1
    }

    /// Spec §3.2 timing guard: from the start of reportable q2, RemoveOrchestrator reverts with
    /// PendingShares(2) until q2's SubmitShares has run. Q1 remains the latest bound quarter during
    /// q2's posting window, so governance first submits q1, then submits q2 after it binds; only then
    /// can the same removal task succeed. This keeps the submitted map consistent with the quarter
    /// counter because no removal can bind between close-of-posting and SubmitShares.
    function test_Mirror_Remove_PendingShares_Reverts() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        _admit(a, a);
        _admit(b, b);

        vm.roll(_quarterStart(1) + 1);
        _postAs(a, 1, _fpv(100e18));
        _postAs(b, 1, _fpv(200e18));

        // q=1: a posts again — q1's tagged slot survives (a fresh write only ever erases a
        // superseded quarter), q1 stays the latest bound quarter (map pending).
        vm.roll(_quarterStart(2) + 1);
        _postAs(a, 2, _fpv(50e18));

        // lag window: q1 bound, submitShares(1) not yet called -> the second vote (which executes
        // the body under unanimousNoHold) hits the guard and reverts; the first approval persists.
        vm.prank(owner1);
        sra.removeOrchestrator(b); // vote 1 (approve)
        vm.expectRevert(abi.encodeWithSelector(ServiceRewardsActor.PendingShares.selector, 2));
        vm.prank(owner2);
        sra.removeOrchestrator(b); // current reporting quarter q2 awaits its share map

        // crank the pending quarters — q1 then q2 (q2's map holds a's contribution) —
        // then the same unanimous task completes on the second vote.
        sra.submitShares(1);
        Share[] memory shares = rewardActor().getShares(SERVICE_ID);
        assertEq(shares.length, 2, "both q1 contributors submitted while still admitted");
        vm.roll(_bindingStart(2) + 1); // q2 binds
        sra.submitShares(2); // q2 submitted (map = [a]; b's q2 slot is zero)
        vm.prank(owner2);
        sra.removeOrchestrator(b); // second vote again: full vote now executes, guard cleared
        assertEq(sra.isAdmitted(b), false, "removed after the pending quarters are cleared");
    }

    /// Spec §3.2: the guard covers the whole window from the end of a quarter until its
    /// SubmitShares has run — posting period, verification window and any crank delay — not only
    /// the post-binding lag. With q1 submitted (lastSubmittedQuarter = 1), a removal inside q2's
    /// posting/verification window must revert PendingShares(2); once submitShares(2) clears q2,
    /// the same unanimous task completes.
    function test_Remove_InsidePostingVerificationWindow_Reverts() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        _admit(a, a);
        _admit(b, b);

        // q1 binds and submits — lastSubmittedQuarter becomes 1, so no quarter is pending.
        vm.roll(_quarterStart(1) + 1);
        _postAs(a, 1, _fpv(100e18));
        vm.roll(_bindingStart(1) + 1);
        sra.submitShares(1);

        // q2 posting window (E(1)+1): q2 has ended and awaits its share map -> the second vote
        // (body execution) reverts; the first approval persists.
        vm.roll(_quarterStart(2) + 1);
        vm.prank(owner1);
        sra.removeOrchestrator(b); // vote 1 (approve)
        vm.expectRevert(abi.encodeWithSelector(ServiceRewardsActor.PendingShares.selector, 2));
        vm.prank(owner2);
        sra.removeOrchestrator(b); // vote 2 executes the body: guard reverts

        // q2 verification window (E(1)+POST+1): still before binding, still pending -> reverts again.
        vm.roll(_postEnd(2) + 1);
        vm.expectRevert(abi.encodeWithSelector(ServiceRewardsActor.PendingShares.selector, 2));
        vm.prank(owner2);
        sra.removeOrchestrator(b); // the persisted first approval + this second vote executes: guard reverts

        // q2 binds and submits — guard lifts; the same task completes on the next second vote.
        vm.roll(_bindingStart(2) + 1);
        sra.submitShares(2);
        vm.prank(owner2);
        sra.removeOrchestrator(b); // second vote again: full vote now executes, guard cleared
        assertEq(sra.isAdmitted(b), false, "removed after q1 submitted");
    }

    /// The remove guard's latest-bound determination is *time-driven* (via _quarterOf), not derived
    /// from the slot tags — the tags advance only on writes, so a gap quarter (bound but unwritten)
    /// would be missed: q2 bound, nobody wrote, no slot tagged q2, a tag-based reading wrongly
    /// reports latest = 0 (already submitted) and lets removal pass. The time-derived guard reverts
    /// until submitShares(2) (an all-zero no-op) clears q2.
    function test_Remove_PendingShares_GapWindow() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        _admit(a, a);
        _admit(b, b);

        vm.roll(_quarterStart(1) + 1); // Q1 posting window
        _postAs(a, 1, _fpv(100e18));
        vm.roll(_bindingStart(1) + 1); // Q1 binds
        sra.submitShares(1); // lastSubmittedQ = 1

        // Q2 gap: nobody writes (no slot tagged q2). Roll past Q2 binding, before Q3 begins.
        vm.roll(_bindingStart(2) + 1);

        // Time-derived latest bound = 1 (unsubmitted) -> the second vote (body execution) reverts.
        vm.prank(owner1);
        sra.removeOrchestrator(b); // vote 1 (approve)
        vm.expectRevert(abi.encodeWithSelector(ServiceRewardsActor.PendingShares.selector, 2));
        vm.prank(owner2);
        sra.removeOrchestrator(b); // vote 2 executes the body: gap-quarter pending -> guard reverts
    }

    /// @dev share of a wallet in the map (0 if absent).
    function _shareOf(Share[] memory shares, address wallet) internal pure returns (uint256) {
        for (uint256 i = 0; i < shares.length; i++) {
            if (shares[i].wallet == wallet) return FixedU18.unwrap(shares[i].share);
        }
        return 0;
    }

    /// invariant_NonZeroTotal_ValidShareMap regression (CI seed 0x8104...): submitShares(q) for a
    /// quarter bound but never written (posting/verification elapsed with no contribution) —
    /// must be an all-zero no-op. Tag matching finds no slot for the gap quarter, so the map can
    /// never be collected from an unrelated older slot (the stale-prevFpv class of bug).
    function test_Mirror_SubmitShares_FutureBoundQuarter_NoOp() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        _admit(a, a);
        _admit(b, b);

        // q1: both post (q1's slot)
        vm.roll(_quarterStart(1) + 1);
        _postAs(a, 1, _fpv(100e18));
        _postAs(b, 1, _fpv(200e18));

        // q2: only a is corrected (q2's own tagged slot — a:50)
        vm.roll(_postEnd(2) + 1);
        _correctVolume(a, 2, _fpv(50e18));

        // submit q2 (latest bound, active quarter): map = [a], lastSubmittedQ = 2
        vm.roll(_bindingStart(2) + 1);
        sra.submitShares(2);
        Share[] memory shares = rewardActor().getShares(SERVICE_ID);
        assertEq(shares.length, 1, "q1 map = a only");
        assertEq(shares[0].wallet, a);

        // q3 binds with no contribution ever (no q3 slot exists): submitShares(3)
        // must be an all-zero no-op — map unchanged, the quarter still counts as submitted.
        vm.roll(_bindingStart(3) + 1);
        sra.submitShares(3);
        shares = rewardActor().getShares(SERVICE_ID);
        assertEq(shares.length, 1, "future bound quarter no-op leaves the map untouched");
        assertEq(shares[0].wallet, a, "map still the q1 distribution");
        assertEq(FixedU18.unwrap(sra.aggregatedFilecoinPayVolume(3)), 0, "q2 has no contributions");
    }

    /// spec §3.2: the posting window itself reverts — from the end of a quarter until its
    /// SubmitShares has run (posting period included), RemoveOrchestrator is not callable. The
    /// pre-E+POST exclusion (spec §2.2) is unreachable in-window by design: governance defers the
    /// removal until the quarter is submitted, and the exclusion then follows from the removed
    /// orchestrator leaving the admitted list.
    function test_Mirror_Remove_InPostingWindow_Reverts() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        _admit(a, a);
        _admit(b, b);

        vm.roll(_quarterStart(1) + 1); // Q1 posting window
        _postAs(a, 1, _fpv(100e18));
        _postAs(b, 1, _fpv(200e18));

        // q1 ended and awaits its share map -> the second vote (body execution) reverts.
        vm.prank(owner1);
        sra.removeOrchestrator(b); // vote 1 (approve)
        vm.expectRevert(abi.encodeWithSelector(ServiceRewardsActor.PendingShares.selector, 1));
        vm.prank(owner2);
        sra.removeOrchestrator(b); // vote 2 executes the body: guard reverts
    }

    /// Once the verification window closes, AggregatedFilecoinPayVolume of the just-bound quarter is
    /// a fixed binding
    /// snapshot (spec §2.2: the read view exposes the bound values directly). A removal after
    /// binding must not rewrite it — only a pre-E+POST removal excludes the contribution.
    /// FIPs#1277 §2.4.4: removal binds through an immediate map push — the removed entry is repointed
    /// to f099 (burn address), every other share is left untouched. The bound aggregate is a binding
    /// snapshot and must not drift, but the f02 map *does* change: the removed id's row becomes f099
    /// (stored stripped of f099 rows, so its share leaves the stored map). Redistribution to survivors
    /// is still deferred to the next SubmitShares.
    function test_Mirror_Remove_AfterBinding_KeepsSnapshot() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        _admit(a, a);
        _admit(b, b);

        vm.roll(_quarterStart(1) + 1); // Q1 posting window
        _postAs(a, 1, _fpv(100e18));
        _postAs(b, 1, _fpv(200e18));

        vm.roll(_bindingStart(1) + 1); // Q1 binds
        sra.submitShares(1);
        Share[] memory shares = rewardActor().getShares(SERVICE_ID);
        assertEq(shares.length, 2, "both contributors in the bound map");
        assertEq(FixedU18.unwrap(sra.aggregatedFilecoinPayVolume(1)), 300e18, "bound aggregate");
        uint256 aShare = _shareOf(shares, a);
        uint256 bShare = _shareOf(shares, b);
        assertGt(aShare, 0, "a holds a share");
        assertGt(bShare, 0, "b holds a share");

        _remove(b); // post-binding removal: aggregate is a binding snapshot, must not drift
        assertEq(FixedU18.unwrap(sra.aggregatedFilecoinPayVolume(1)), 300e18, "bound aggregate unchanged after removal");
        shares = rewardActor().getShares(SERVICE_ID);
        // b's entry was repointed to f099 (stripped from storage): only a's share remains stored,
        // at its unchanged value; b's slice is recorded as the stripped burn.
        assertEq(shares.length, 1, "removed entry repointed to f099 leaves the stored map");
        assertEq(_shareOf(shares, a), aShare, "survivor share untouched until next SubmitShares");
        assertEq(rewardActor().strippedBurnOf(SERVICE_ID), bShare, "removed slice recorded as stripped f099 burn");
    }

    /// spec §3.2: the verification window also reverts — removal is deferred to after SubmitShares,
    /// so a misreport surfacing during verification cannot be silenced by removing the orchestrator
    /// (spec Security Considerations: a misreport surfaces during posting or verification, when
    /// removal is not yet callable). The old in-window exclusion semantics (deduct aggregate +
    /// omit map) are unreachable by design.
    function test_Mirror_Remove_InVerificationWindow_Reverts() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        _admit(a, a);
        _admit(b, b);

        vm.roll(_quarterStart(1) + 1); // Q1 posting window
        _postAs(a, 1, _fpv(100e18));
        _postAs(b, 1, _fpv(200e18));

        vm.roll(_postEnd(1) + 1); // Q1 verification window (E+POST+1)
        vm.prank(owner1);
        sra.removeOrchestrator(b); // vote 1 (approve)
        vm.expectRevert(abi.encodeWithSelector(ServiceRewardsActor.PendingShares.selector, 1));
        vm.prank(owner2);
        sra.removeOrchestrator(b); // vote 2 executes the body: guard reverts
    }

    /// A gap quarter (no writes, zero volume) submits as an all-zero no-op — no slot carries its
    /// tag, submitShares reads nothing and the existing map stands.
    function test_GapQuarter_SubmitShares_NoOp() public {
        address a = makeAddr("a");
        address b = makeAddr("b");
        _admit(a, a);
        _admit(b, b);

        vm.roll(_quarterStart(1) + 1); // Q1 posting window
        _postAs(a, 1, _fpv(100e18));
        vm.roll(_bindingStart(1) + 1); // Q1 binds
        sra.submitShares(1);
        Share[] memory shares = rewardActor().getShares(SERVICE_ID);
        assertEq(shares.length, 1, "q1 map = a");
        assertEq(shares[0].wallet, a);

        // Q2 gap (no slot); Q3: b posts into the vacant second slot.
        vm.roll(_quarterStart(3) + 1);
        _postAs(b, 3, _fpv(50e18));

        // Q2 binds with no contribution: submitShares(2) must be an all-zero no-op.
        sra.submitShares(2);
        shares = rewardActor().getShares(SERVICE_ID);
        assertEq(shares.length, 1, "gap quarter no-op leaves the map untouched");
        assertEq(shares[0].wallet, a, "map still the q1 distribution");
        assertEq(FixedU18.unwrap(sra.aggregatedFilecoinPayVolume(2)), 0, "gap quarter has no contributions");
    }
}
