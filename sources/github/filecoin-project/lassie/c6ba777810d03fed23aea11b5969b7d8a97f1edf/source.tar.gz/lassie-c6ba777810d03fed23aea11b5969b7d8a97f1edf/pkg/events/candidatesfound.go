package events

import (
	"fmt"
	"time"

	"github.com/filecoin-project/lassie/pkg/types"
	"github.com/ipfs/go-cid"
)

var (
	_ types.RetrievalEvent = CandidatesFoundEvent{}
	_ EventWithCandidates  = CandidatesFoundEvent{}
)

type CandidatesFoundEvent struct {
	retrievalEvent
	candidates []types.RetrievalCandidate
}

func (e CandidatesFoundEvent) Code() types.EventCode                  { return types.CandidatesFoundCode }
func (e CandidatesFoundEvent) Candidates() []types.RetrievalCandidate { return e.candidates }
func (e CandidatesFoundEvent) String() string {
	return fmt.Sprintf("CandidatesFoundEvent<%s, %s, %s, %d>", e.eventTime, e.retrievalId, e.rootCid, len(e.candidates))
}

func CandidatesFound(at time.Time, retrievalId types.RetrievalID, rootCid cid.Cid, candidates []types.RetrievalCandidate) CandidatesFoundEvent {
	c := make([]types.RetrievalCandidate, len(candidates))
	copy(c, candidates)
	return CandidatesFoundEvent{retrievalEvent{at, retrievalId, rootCid}, c}
}
