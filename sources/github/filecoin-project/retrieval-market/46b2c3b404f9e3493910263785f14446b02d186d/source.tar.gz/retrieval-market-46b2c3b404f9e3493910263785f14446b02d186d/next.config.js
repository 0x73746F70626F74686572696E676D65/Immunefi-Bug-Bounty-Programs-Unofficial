module.exports = {
  trailingSlash: true,
};
