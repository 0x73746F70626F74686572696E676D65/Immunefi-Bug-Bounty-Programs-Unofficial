import { Command } from 'commander'
import { runCarImportFromCli } from '../import/import.js'
import {
  addAuthOptions,
  addAutoFundOptions,
  addContextSelectionOptions,
  addUploadOptions,
} from '../utils/cli-options.js'
import { addEgressOptions } from '../utils/cli-options-egress.js'
import { addMetadataOptions } from '../utils/cli-options-metadata.js'

export const importCommand = new Command('import')
  .description('Upload an existing CAR file to Filecoin')
  .argument('<file>', 'Path to the CAR file to import')
  .option('--copies <n>', 'Number of storage copies to create (default: 2)', Number.parseInt)
  .addHelpText(
    'after',
    `
Session-key mode: checks the storage service is approved and
the account can pay for this upload. If not, exits 1 with a pre-filled console
funding link; nothing is uploaded. Session keys cannot deposit.`
  )
  .action(async (file: string, options) => {
    try {
      const result = await runCarImportFromCli(file, options)
      if ('dryRun' in result) return
      if (result.copies.length < result.requestedCopies) {
        process.exitCode = 1
      }
    } catch {
      process.exit(1)
    }
  })

addAuthOptions(importCommand)
addContextSelectionOptions(importCommand)
addUploadOptions(importCommand)
addAutoFundOptions(importCommand)
addEgressOptions(importCommand)
addMetadataOptions(importCommand, { includePieceMetadata: true, includeDataSetMetadata: true, includeErc8004: true })
