/**
 * Interactive payment setup flow with TTY support
 *
 * This module provides a guided, interactive setup experience for configuring
 * payment approvals. It uses @clack/prompts for a terminal interface
 * with password-style input for private keys and spinners for long operations.
 */

import { cancel, confirm, isCancel, password, text } from '@clack/prompts'
import pc from 'picocolors'
import { parseUnits } from 'viem'
import { CliFatal, isCliFatal, setIncompleteExitCode } from '../common/cli-errors.js'
import {
  calculateDepositCapacity,
  checkAllowances,
  checkAndSetAllowances,
  checkFILBalance,
  checkUSDFCBalance,
  DEFAULT_LOCKUP_DAYS,
  depositUSDFC,
  getPaymentStatus,
  validateGasRequirement,
  validatePaymentRequirements,
} from '../core/payments/index.js'
import { getClientAddress, initializeSynapse } from '../core/synapse/index.js'
import { formatUSDFC } from '../core/utils/format.js'
import { assertOwnerAuth, parseCLIAuth } from '../utils/cli-auth.js'
import { createSpinner, intro, outro } from '../utils/cli-helpers.js'
import { isTTY, log } from '../utils/cli-logger.js'
import { displayAccountInfo, displayDepositWarning, displayPricing } from './setup.js'
import type { PaymentSetupOptions } from './types.js'

/**
 * Run interactive payment setup
 *
 * @param options - Initial options from command line
 */
export async function runInteractiveSetup(options: PaymentSetupOptions): Promise<void> {
  // Check for TTY support
  if (!isTTY()) {
    log.line(pc.red('Error: Interactive mode requires a TTY terminal.'))
    log.line('Use --auto flag for non-interactive setup.')
    log.flush()
    throw new CliFatal('Interactive mode requires a TTY terminal')
  }

  intro(pc.bold('Filecoin Onchain Cloud Payment Setup'))
  const s = createSpinner()

  try {
    // Get private key
    let privateKey = options.privateKey

    // Only prompt for a private key when no signing auth mode was supplied. A
    // complete session key cannot run setup (it moves funds), so rather than
    // prompting for a second signer let it reach assertOwnerAuth below, which
    // refuses it with the targeted error. A view address (read-only) and a lone
    // session-key half cannot run setup either, but they do not suppress the
    // prompt: the prompted key becomes the explicit signer and wins.
    const nonEmpty = (value?: string): boolean => value != null && value !== ''
    const hasSigningAuth = nonEmpty(options.walletAddress) && nonEmpty(options.sessionKey)

    if (!privateKey && !hasSigningAuth) {
      const input = await password({
        message: 'Enter your private key',
        validate: (value) => {
          if (!value) return 'Private key is required'

          // Add 0x prefix if missing
          const key = value.startsWith('0x') ? value : `0x${value}`

          // Validate format: 0x followed by 64 hex characters
          if (!/^0x[0-9a-fA-F]{64}$/.test(key)) {
            return 'Private key must be 64 hex characters (with or without 0x prefix)'
          }

          return undefined
        },
      })

      if (isCancel(input)) {
        cancel('Setup cancelled')
        // User cancelled: not a failure. Signal "incomplete" (2) distinctly
        // from success (0) and a caught error (1).
        setIncompleteExitCode()
        return
      }

      // Add 0x prefix if it was missing
      privateKey = input.startsWith('0x') ? input : `0x${input}`
    }

    // Initialize Synapse
    s.start('Initializing connection...')

    const config = parseCLIAuth({ ...options, privateKey })
    assertOwnerAuth(config, 'payments setup')
    const synapse = await initializeSynapse(config)
    const network = synapse.chain.name
    const address = getClientAddress(synapse)

    s.stop(`${pc.green('✓')} Connected to ${pc.bold(network)}`)

    // Check balances
    s.start('Checking balances...')

    const filStatus = await checkFILBalance(synapse)
    const walletUsdfcBalance = await checkUSDFCBalance(synapse)
    const [status, allowanceCheck] = await Promise.all([getPaymentStatus(synapse), checkAllowances(synapse)])

    s.stop(`${pc.green('✓')} Balance check complete`)

    // Gate on wallet funding only when setup work remains. An account with a
    // deposit and current allowances can complete this flow without sending a
    // transaction. A first deposit spends wallet USDFC and gas; an allowance
    // update spends gas alone, so wallet USDFC is not required for it.
    const needsFirstDeposit = status.filecoinPayBalance === 0n
    if (needsFirstDeposit || allowanceCheck.needsUpdate) {
      const validation = needsFirstDeposit
        ? validatePaymentRequirements(filStatus.balance, walletUsdfcBalance, filStatus.isCalibnet)
        : validateGasRequirement(filStatus.balance, filStatus.isCalibnet)
      if (!validation.isValid) {
        const errorMsg = validation.errorMessage ?? 'Payment validation failed'
        log.line(`${pc.red('✗')} ${errorMsg}`)
        if (validation.helpMessage) {
          log.line('')
          log.line(`  ${pc.cyan(validation.helpMessage)}`)
        }
        log.flush()
        cancel('Please fund your wallet and try again')
        throw new CliFatal(errorMsg)
      }
    }

    displayAccountInfo(
      address,
      network,
      filStatus.balance,
      filStatus.isCalibnet,
      filStatus.hasSufficientGas,
      walletUsdfcBalance,
      status.filecoinPayBalance
    )

    // Get storage pricing info once for all subsequent operations
    s.start('Getting current pricing...')
    const storageInfo = await synapse.storage.getStorageInfo()
    const pricePerTiBPerEpoch = storageInfo.pricing.noCDN.perTiBPerEpoch
    const pricePerTiBPerMonth = storageInfo.pricing.noCDN.perTiBPerMonth
    const pricePerGiBPerMonth = pricePerTiBPerMonth / 1024n
    s.stop(`${pc.green('✓')} Pricing loaded`)

    // Initialize tracking variables
    let depositAmount = 0n
    let actionsTaken = false // Track if any changes were made

    // Show current deposit capacity
    const currentCapacity = calculateDepositCapacity(status.filecoinPayBalance, pricePerTiBPerEpoch)
    log.line(pc.bold('Current Storage Capacity:'))
    if (status.filecoinPayBalance > 0n) {
      const capacityStr =
        currentCapacity.gibPerMonth >= 1024
          ? `${(currentCapacity.gibPerMonth / 1024).toFixed(1)} TiB`
          : `${currentCapacity.gibPerMonth.toFixed(1)} GiB`
      log.indent(`Deposit: ${formatUSDFC(status.filecoinPayBalance)} USDFC`)
      log.indent(`Capacity: ~${capacityStr} for 1 month`)
    } else {
      log.indent(pc.gray('No deposit yet'))
    }
    log.flush()

    // Show pricing to help user understand costs
    displayPricing(pricePerGiBPerMonth, pricePerTiBPerMonth)

    // Offer deposit options with contextual message
    const depositMessage =
      status.filecoinPayBalance === 0n
        ? 'Would you like to deposit USDFC to enable storage?'
        : 'Would you like to deposit additional USDFC?'

    const shouldDeposit = await confirm({
      message: depositMessage,
      initialValue: status.filecoinPayBalance === 0n,
    })

    if (isCancel(shouldDeposit)) {
      cancel('Setup cancelled')
      setIncompleteExitCode()
      return
    }

    if (shouldDeposit) {
      // Show examples to help user decide
      log.line(pc.bold('Storage Examples (per month):'))
      log.indent(`100 GiB capacity: ~${formatUSDFC((pricePerGiBPerMonth * 100n * 11n) / 10n)} USDFC`)
      log.indent(`1 TiB capacity:   ~${formatUSDFC((pricePerTiBPerMonth * 11n) / 10n)} USDFC`)
      log.indent(`10 TiB capacity:  ~${formatUSDFC((pricePerTiBPerMonth * 10n * 11n) / 10n)} USDFC`)
      log.indent(pc.gray(`(deposit covers 1 month + ${DEFAULT_LOCKUP_DAYS}-day safety reserve)`))
      log.flush()

      const amountStr = await text({
        message: 'How much USDFC would you like to deposit?',
        placeholder: '10.0',
        initialValue: status.filecoinPayBalance === 0n ? '10.0' : '5.0',
        validate: (value) => {
          if (!value) return 'Amount is required'
          try {
            const amount = parseUnits(value, 18)
            if (amount <= 0n) return 'Amount must be greater than 0'
            if (amount > walletUsdfcBalance)
              return `Insufficient balance (have ${formatUSDFC(walletUsdfcBalance)} USDFC)`
            return undefined
          } catch {
            return 'Invalid amount'
          }
        },
      })

      if (isCancel(amountStr)) {
        cancel('Setup cancelled')
        setIncompleteExitCode()
        return
      }

      depositAmount = parseUnits(amountStr, 18)

      s.start('Depositing USDFC...')
      const { depositTx } = await depositUSDFC(synapse, depositAmount)
      s.stop(`${pc.green('✓')} Deposit complete`)

      log.indent(pc.gray(`Deposit tx: ${depositTx}`))
      actionsTaken = true

      // Show new capacity after deposit
      const newCapacity = calculateDepositCapacity(status.filecoinPayBalance + depositAmount, pricePerTiBPerEpoch)
      const newCapacityStr =
        newCapacity.gibPerMonth >= 1024
          ? `${(newCapacity.gibPerMonth / 1024).toFixed(1)} TiB`
          : `${newCapacity.gibPerMonth.toFixed(1)} GiB`
      log.line('')
      log.line(pc.bold('New Storage Capacity:'))
      log.indent(`Total deposit: ${formatUSDFC(status.filecoinPayBalance + depositAmount)} USDFC`)
      log.indent(`Capacity: ~${newCapacityStr} for 1 month`)
      log.flush()
    } else {
      const { updated, transactionHash } = await checkAndSetAllowances(synapse)
      if (updated) {
        log.indent(`${pc.green('✓')} Updated payment allowances, tx: ${transactionHash}`)
      } else {
        log.indent(`${pc.green('✓')} Deposit already sufficient (${formatUSDFC(status.filecoinPayBalance)} USDFC)`)
      }
    }

    // Final summary
    s.start('Fetching final status...')
    const finalStatus = await getPaymentStatus(synapse)
    s.stop('━━━ Setup Complete ━━━')

    const finalCapacity = calculateDepositCapacity(finalStatus.filecoinPayBalance, pricePerTiBPerEpoch)

    log.line(`Network: ${pc.bold(network)}`)
    log.line('')

    log.line(pc.bold('Wallet'))
    log.indent(`${formatUSDFC(walletUsdfcBalance)} USDFC available`)
    log.line('')

    log.line(pc.bold('Storage Deposit'))
    log.indent(`${formatUSDFC(finalStatus.filecoinPayBalance)} USDFC deposited`)
    if (finalCapacity.gibPerMonth > 0) {
      const capacityStr =
        finalCapacity.gibPerMonth >= 1024
          ? `${(finalCapacity.gibPerMonth / 1024).toFixed(1)} TiB`
          : `${finalCapacity.gibPerMonth.toFixed(1)} GiB`
      log.indent(`Capacity: ~${capacityStr} for 1 month`)
      log.indent(pc.gray(`(includes ${DEFAULT_LOCKUP_DAYS}-day safety reserve)`))
    }
    log.flush()

    // Show deposit warning if needed
    displayDepositWarning(finalStatus.filecoinPayBalance, finalStatus.currentAllowances.lockupUsage)

    // Show appropriate outro message based on whether actions were taken
    if (actionsTaken) {
      outro('Payment setup completed successfully')
    } else {
      outro('No changes made to payment setup')
    }
  } catch (error) {
    if (isCliFatal(error)) {
      s.stop()
      throw error
    }
    const msg = error instanceof Error ? error.message : String(error)
    s.stop(`${pc.red('✗')} Setup failed: ${msg}`)
    cancel('Setup failed')
    throw new CliFatal(msg, { cause: error instanceof Error ? error : undefined })
  }
}
