import { Command } from 'commander'
import { runAddFromCli } from '../add/add.js'
import {
  addAuthOptions,
  addAutoFundOptions,
  addContextSelectionOptions,
  addUploadOptions,
} from '../utils/cli-options.js'
import { addEgressOptions } from '../utils/cli-options-egress.js'
import { addMetadataOptions } from '../utils/cli-options-metadata.js'

export const addCommand = new Command('add')
  .description('Upload a file or directory to Filecoin')
  .argument('<path>', 'Path to the file or directory to add')
  .option(
    '--include-hidden',
    'Include hidden entries (dotfiles) when packing a directory. Ignored when the target directory itself starts with `.` — its descendants are always traversed in that case.'
  )
  .option('--copies <n>', 'Number of storage copies to create (default: 2)', Number.parseInt)
  .addHelpText(
    'after',
    `
Session-key mode: before packing, checks the storage service is approved and
the account can pay for this upload. If not, exits 1 with a pre-filled console
funding link; nothing is uploaded. Session keys cannot deposit.

Retrieving your content after an add:
  IPFS Root CID  view in a browser, or fetch from any IPFS gateway
  Piece CID      download the stored CAR directly from the provider
  Guide: https://github.com/filecoin-project/filecoin-pin/blob/master/documentation/retrieval.md`
  )

addCommand.action(async (path: string, options: any) => {
  try {
    const result = await runAddFromCli(path, options)
    if ('dryRun' in result) return
    if (result.copies.length < result.requestedCopies) {
      process.exitCode = 1
    }
  } catch {
    process.exit(1)
  }
})

addAuthOptions(addCommand)
addContextSelectionOptions(addCommand)
addUploadOptions(addCommand)
addAutoFundOptions(addCommand)
addEgressOptions(addCommand)
addMetadataOptions(addCommand, { includePieceMetadata: true, includeDataSetMetadata: true, includeErc8004: true })
