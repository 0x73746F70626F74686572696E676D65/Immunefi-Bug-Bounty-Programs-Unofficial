/**
 * Funds preflight for `add` and `import` in session-key mode.
 *
 * Runs before anything is packed or uploaded. A session key cannot deposit
 * (payment operations are owner-only), so instead of auto-funding it prints
 * the readiness lines and a pre-filled console funding link, then exits 1.
 * Private-key auth keeps its existing checks and `--auto-fund` behavior.
 */

import { opendir, stat } from 'node:fs/promises'
import { basename, join } from 'node:path'
import type { Synapse } from '@filoz/synapse-sdk'
import pc from 'picocolors'
import { buildFundingUrl, DEFAULT_SUGGESTED_DEPOSIT_USDFC, resolveConsoleUrl } from '../core/session/console-url.js'
import { checkAccountReadiness, formatReadinessLines, type UploadFunds } from '../login/index.js'
import type { Spinner } from '../utils/cli-helpers.js'
import { log } from '../utils/cli-logger.js'
import { CliFatal } from './cli-errors.js'
import { type EstimateUploadCostOptions, estimateUploadCost } from './upload-flow.js'

const USDFC_WEI = 10n ** 18n

/**
 * Bytes the upload will roughly carry: the file's size, or the sum of the
 * files under a directory. CAR framing adds a little on top; the estimate
 * is for the funds check, not the bill.
 *
 * Dot-named entries are skipped unless --include-hidden, directories
 * included, to match what the packer's glob will select. As in the packer,
 * a hidden root the user named explicitly still has its contents counted.
 */
export async function estimateInputBytes(path: string, isDirectory: boolean, includeHidden = false): Promise<number> {
  if (!isDirectory) return (await stat(path)).size
  return sumFileSizes(path, includeHidden || basename(path).startsWith('.'))
}

/**
 * Streams one directory level at a time with `opendir()` rather than
 * materialising a recursive `readdir()` listing, so a directory with
 * millions of files costs one open handle, not one array. Subdirectories
 * are walked after the handle closes, so depth never stacks handles.
 */
async function sumFileSizes(dir: string, includeHidden: boolean): Promise<number> {
  let total = 0
  const subdirectories: string[] = []
  for await (const entry of await opendir(dir)) {
    if (!includeHidden && entry.name.startsWith('.')) continue
    const path = join(dir, entry.name)
    if (entry.isDirectory()) subdirectories.push(path)
    else if (entry.isFile()) total += (await stat(path)).size
  }
  for (const subdirectory of subdirectories) total += await sumFileSizes(subdirectory, includeHidden)
  return total
}

// --rpc-url is included: hosted endpoints often carry the API key in the URL.
const SECRET_FLAGS = ['--session-key', '--private-key', '--rpc-url'] as const

/**
 * The command to run again after funding, rebuilt from argv with any secret
 * flag value redacted: the hint lands in CI logs and agent transcripts.
 */
export function rerunHint(argv: readonly string[] = process.argv): string {
  const words: string[] = []
  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i] as string
    const flag = SECRET_FLAGS.find((f) => arg === f || arg.startsWith(`${f}=`))
    if (flag === undefined) {
      words.push(arg)
      continue
    }
    words.push(`${flag} <redacted>`)
    if (arg === flag) i++
  }
  return `filecoin-pin ${words.join(' ')}`
}

/** Whole USDFC to pre-fill in the funding link: the shortfall rounded up, or the default when only approval is missing. */
function suggestedDeposit(shortfall: bigint): number {
  if (shortfall <= 0n) return DEFAULT_SUGGESTED_DEPOSIT_USDFC
  return Number((shortfall + USDFC_WEI - 1n) / USDFC_WEI)
}

/** Run one read; on failure stop the spinner with a plain line naming the step, then rethrow. */
async function readStep<T>(spinner: Spinner | undefined, what: string, read: () => Promise<T>): Promise<T> {
  try {
    return await read()
  } catch (error) {
    spinner?.stop(`${pc.red('✗')} Could not read the ${what}`)
    throw error
  }
}

/**
 * Check service approval and available funds against the upload's estimate.
 * Returns normally when the account can pay; otherwise prints the
 * remediation block and throws a {@link CliFatal} (exit 1).
 */
export async function assertUploadFunds(
  synapse: Synapse,
  estimatedBytes: number,
  estimateOptions: EstimateUploadCostOptions,
  rerunCommand: string,
  spinner?: Spinner
): Promise<void> {
  // Sequential so a failing step is named in the spinner rather than
  // surfacing as a raw SDK error under a stale "checking" line.
  spinner?.message('Checking the storage service approval...')
  const readiness = await readStep(spinner, 'account readiness', () => checkAccountReadiness(synapse))
  spinner?.message('Estimating the upload cost...')
  const estimate = await readStep(spinner, 'upload cost estimate', () =>
    estimateUploadCost(synapse, estimatedBytes, estimateOptions)
  )
  spinner?.message('Reading the account balance...')
  const summary = await readStep(spinner, 'account balance', () => synapse.payments.accountSummary({}))
  // The SDK's depositNeeded already nets available funds against lockups,
  // fees, runway, and debt, so it decides; the line shows the two amounts.
  const shortfall = estimate.costs.depositNeeded
  const funds: UploadFunds = {
    available: summary.availableFunds,
    needed:
      shortfall > 0n ? summary.availableFunds + shortfall : estimate.costs.lockups.total + estimate.costs.fees.total,
    covered: shortfall === 0n,
  }
  if (readiness.serviceApproved && estimate.costs.ready) return

  const consoleUrl = resolveConsoleUrl()
  const headline = `${pc.red('✗')} Account can't pay for this upload`
  if (spinner === undefined) log.line(headline)
  else spinner.stop(headline)
  for (const line of formatReadinessLines(readiness, true, funds)) log.line(line)
  log.line('  Top up (amount pre-filled, one transaction):')
  // The link on its own line, unstyled, so it copies and parses cleanly.
  log.line(buildFundingUrl(consoleUrl, suggestedDeposit(estimate.costs.depositNeeded), synapse.chain.id))
  log.line(`  Then re-run:  ${rerunCommand}     check anytime: filecoin-pin balance`)
  log.flush()
  throw new CliFatal("Account can't pay for this upload")
}
