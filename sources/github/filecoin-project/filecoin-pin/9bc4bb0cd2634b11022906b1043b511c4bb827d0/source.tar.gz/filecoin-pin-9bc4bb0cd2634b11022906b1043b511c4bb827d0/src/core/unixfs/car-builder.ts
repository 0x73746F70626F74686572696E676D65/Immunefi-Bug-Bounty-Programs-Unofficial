/**
 * UnixFS to CAR conversion functionality
 *
 * This module provides utilities to create CAR files from files and directories
 * using @helia/unixfs and CARWritingBlockstore.
 */

import { randomBytes } from 'node:crypto'
import { createReadStream } from 'node:fs'
import { open, stat, unlink } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { basename, dirname, join, resolve } from 'node:path'
import { Readable } from 'node:stream'
import { globSource, unixfs } from '@helia/unixfs'
import { CarWriter } from '@ipld/car'
import { CID } from 'multiformats/cid'
import type { Logger } from 'pino'
import { CARWritingBlockstore, carInputError, isCar } from '../car/index.js'
import { importerOptions } from './importer-options.js'

// Spinner type for progress reporting
export type Spinner = {
  start(msg: string): void
  stop(msg: string): void
  message(msg: string): void
}

// Placeholder CID used during CAR creation (will be replaced with actual root)
const PLACEHOLDER_CID = CID.parse('bafyaaiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')

// Default false according to the unixfs-v1-2025 CID profile.
const INCLUDE_HIDDEN_FILES = false

export interface CreateCarOptions {
  logger?: Logger
  spinner?: Spinner
  isDirectory?: boolean
  /** Include hidden entries (dotfiles, dotdirs) when packing a directory. */
  includeHidden?: boolean
}

export interface CreateCarResult {
  carPath: string
  rootCid: CID
  /** Basename of the source path, useful for piece metadata. */
  name: string
}

export async function createCarFromPath(path: string, options: CreateCarOptions = {}): Promise<CreateCarResult> {
  const { isDirectory = false } = options

  // Determine if path is a directory if not explicitly specified
  let pathIsDirectory = isDirectory
  if (!pathIsDirectory) {
    const stats = await stat(path)
    pathIsDirectory = stats.isDirectory()
  }

  // Handle directory
  if (pathIsDirectory) {
    return createCarFromDirectory(path, options)
  }

  // Handle file
  return createCarFromSingleFile(path, options)
}

async function createCar(
  contentPath: string,
  options: CreateCarOptions & { name: string },
  addContent: (fs: any) => Promise<CID>
): Promise<CreateCarResult> {
  const { logger, name } = options

  const tempCarPath = join(tmpdir(), `filecoin-pin-add-${Date.now()}-${randomBytes(8).toString('hex')}.car`)

  logger?.info({ path: contentPath, tempCarPath }, 'Creating CAR')
  logger?.debug({ placeholderCID: PLACEHOLDER_CID.toString() }, 'Using placeholder CID')

  // Create blockstore with placeholder CID
  const blockstoreOptions: any = {
    rootCID: PLACEHOLDER_CID,
    outputPath: tempCarPath,
  }
  if (logger) {
    blockstoreOptions.logger = logger
  }
  const blockstore = new CARWritingBlockstore(blockstoreOptions)

  // Initialize blockstore (writes CAR header with placeholder)
  await blockstore.initialize()

  // Create UnixFS instance with our blockstore
  const fs = unixfs({ blockstore })

  // Add content using the provided function
  const rootCid = await addContent(fs)

  logger?.info({ rootCid: rootCid.toString() }, `Content added to UnixFS`)

  // Finalize CAR (close writer, flush to disk)
  await blockstore.finalize()

  // Update the root CID in the CAR file
  logger?.debug('Updating root CID in CAR file')
  const fd = await open(tempCarPath, 'r+')
  try {
    await CarWriter.updateRootsInFile(fd, [rootCid])
  } finally {
    await fd.close()
  }

  logger?.info(
    {
      carPath: tempCarPath,
      rootCid: rootCid.toString(),
      stats: blockstore.getStats(),
    },
    `CAR file created successfully`
  )

  return { carPath: tempCarPath, rootCid, name }
}

/**
 * Single files are encoded without a parent-directory wrapper under the
 * IPIP-499 unixfs-v1-2025 profile; the basename is surfaced on the result
 * so callers can route it into piece metadata.
 */
async function createCarFromSingleFile(filePath: string, options: CreateCarOptions = {}): Promise<CreateCarResult> {
  const { logger } = options
  const name = basename(filePath)

  // Refuse to wrap an existing CAR in a new UnixFS DAG. Sniff a fresh stream
  // and discard it; the upload pipeline below opens its own.
  const sniff = createReadStream(filePath)
  try {
    if (await isCar(sniff)) {
      throw carInputError(filePath)
    }
  } finally {
    sniff.destroy()
  }

  return createCar(filePath, { ...options, name }, async (fs) => {
    const fileStream = createReadStream(filePath)
    const webStream = Readable.toWeb(fileStream) as ReadableStream<Uint8Array>

    logger?.info({ filePath, name }, 'Adding file to UnixFS')
    return fs.addByteStream(webStream, importerOptions)
  })
}

async function createCarFromDirectory(dirPath: string, options: CreateCarOptions = {}): Promise<CreateCarResult> {
  const { logger, spinner, includeHidden = INCLUDE_HIDDEN_FILES } = options

  // Resolve to absolute path to handle cases like '.' or relative paths
  const absolutePath = resolve(dirPath)
  const parentDir = dirname(absolutePath)
  const dirName = basename(absolutePath)

  return createCar(dirPath, { ...options, name: dirName }, async (fs) => {
    logger?.info({ dirPath }, 'Streaming directory contents to UnixFS')

    // Use globSource with the parent directory as base and include the directory name in the pattern
    // This ensures the directory name is part of the UnixFS structure
    // We match only the directory contents (/**/*), not the directory itself
    // addAll will automatically create the root directory entry with proper links
    const pattern = `${dirName}/**/*`
    // If the user explicitly targets a hidden root (e.g. `add .well-known`),
    // glob's hidden filter would discard every match because the root path
    // segment starts with `.`. Force hidden traversal in that case — the user
    // selected this directory, so its contents go in regardless of the
    // dotfile-exclusion default.
    const hidden = includeHidden || dirName.startsWith('.')
    logger?.info({ absolutePath, parentDir, dirName, pattern, hidden }, 'Directory structure for UnixFS')

    const candidates = globSource(parentDir, pattern, {
      hidden,
    })

    // Track progress
    let fileCount = 0
    async function* trackProgress(source: AsyncIterable<any>) {
      for await (const entry of source) {
        fileCount++
        spinner?.message(`Adding: ${entry.path}`)
        logger?.debug({ path: entry.path, hasContent: !!entry.content }, 'Processing entry')
        yield entry
      }
    }

    // Add all entries using addAll
    const entries = []
    for await (const entry of fs.addAll(trackProgress(candidates), importerOptions)) {
      logger?.debug({ path: entry.path || '(root)', cid: entry.cid.toString() }, 'Entry added to CAR')
      entries.push(entry)
    }

    // The last entry should be the root directory
    // For empty directories, addAll might still yield a root entry
    const rootCid = entries[entries.length - 1]?.cid
    if (!rootCid) {
      // Empty directory - create a single empty directory block
      const emptyDirCid = await fs.addDirectory(undefined, importerOptions)
      return emptyDirCid
    }

    logger?.info({ fileCount, rootCid: rootCid.toString() }, 'Directory added to UnixFS')
    return rootCid
  })
}

export async function cleanupTempCar(carPath: string, logger?: Logger): Promise<void> {
  try {
    await unlink(carPath)
    logger?.debug({ carPath }, 'Cleaned up temporary CAR file')
  } catch (error) {
    // Log but don't throw - best effort cleanup
    logger?.warn({ carPath, error }, 'Failed to cleanup temporary CAR file')
    console.warn(`Failed to cleanup temp CAR file: ${carPath}`, error)
  }
}
