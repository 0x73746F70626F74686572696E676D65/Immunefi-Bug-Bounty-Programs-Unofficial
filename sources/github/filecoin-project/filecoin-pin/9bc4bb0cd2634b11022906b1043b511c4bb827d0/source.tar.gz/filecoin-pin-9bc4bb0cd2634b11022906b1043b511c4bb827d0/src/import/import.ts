/**
 * CAR file import functionality
 *
 * This module handles importing existing CAR files to Filecoin via Synapse SDK.
 * It validates the CAR format, extracts root CIDs, and uploads to Filecoin.
 */

import { createReadStream } from 'node:fs'
import { stat } from 'node:fs/promises'
import { Readable } from 'node:stream'
import { AddPiecesPermission, CreateDataSetPermission } from '@filoz/synapse-core/session-key'
import { CarReader } from '@ipld/car'
import { CID } from 'multiformats/cid'
import pc from 'picocolors'
import pino from 'pino'
import { CliFatal, isCliFatal } from '../common/cli-errors.js'
import { assertUploadFunds, rerunHint } from '../common/funds-preflight.js'
import { DEVNET_CHAIN_ID } from '../common/get-rpc-url.js'
import { describeLockupShortfall } from '../common/lockup-error.js'
import {
  displayDryRunEstimate,
  displayUploadResults,
  type EstimateUploadCostOptions,
  estimateUploadCost,
  performAutoFunding,
  performUpload,
  resolveUploadTargets,
  validatePaymentSetup,
} from '../common/upload-flow.js'
import { normalizeMetadataConfig } from '../core/metadata/index.js'
import { DEFAULT_COPIES } from '../core/synapse/constants.js'
import { initializeSynapse, isSessionKeyMode } from '../core/synapse/index.js'
import { getNetworkSlug } from '../core/upload/index.js'
import { parseCLIAuth, parseContextSelectionOptions } from '../utils/cli-auth.js'
import { cancel, createSpinner, formatFileSize, intro, outro } from '../utils/cli-helpers.js'
import { log } from '../utils/cli-logger.js'
import { validateAndNormalizeAutoFundOptions } from '../utils/cli-options.js'
import { buildFilbeamUrl, chainSupportsFilbeam, printEgressNotice } from '../utils/cli-options-egress.js'
import { resolveMetadataOptions } from '../utils/cli-options-metadata.js'
import type { ImportDryRunResult, ImportOptions, ImportResult } from './types.js'

/**
 * Zero CID used when CAR has no roots
 * This is the identity CID with empty data
 */
const ZERO_CID = 'bafkqaaa'

/**
 * Validate and extract roots from a CAR file
 *
 * @param filePath - Path to the CAR file
 * @returns Array of root CIDs
 */
async function validateCarFile(filePath: string): Promise<CID[]> {
  const inStream = createReadStream(filePath)

  try {
    // CarReader.fromIterable will only read the header, not the entire file
    const reader = await CarReader.fromIterable(inStream as any)
    const roots = await reader.getRoots()
    return roots
  } finally {
    // Ensure stream is closed
    inStream.close()
  }
}

/**
 * Resolve the root CID from CAR file roots
 * Handles multiple cases: no roots, single root, multiple roots
 */
function resolveRootCID(roots: CID[]): {
  cid: CID
  cidString: string
  message?: string
} {
  if (roots.length === 0) {
    // No roots - use zero CID
    return {
      cid: CID.parse(ZERO_CID),
      cidString: ZERO_CID,
      message: `${pc.yellow('⚠')} No root CIDs found in CAR header, using zero CID: ${ZERO_CID}`,
    }
  }

  if (roots.length === 1 && roots[0]) {
    // Exactly one root - perfect
    const cid = roots[0]
    return {
      cid,
      cidString: cid.toString(),
      message: `Root CID: ${cid.toString()}`,
    }
  }

  if (roots[0]) {
    // Multiple roots - use first, warn about others
    const cid = roots[0]
    const otherRoots = roots
      .slice(1)
      .map((r) => r.toString())
      .join(', ')
    return {
      cid,
      cidString: cid.toString(),
      message: `${pc.yellow('⚠')} Multiple root CIDs found (${roots.length}), using first: ${cid.toString()}\n  Other roots: ${otherRoots}`,
    }
  }

  // This shouldn't happen but handle it gracefully
  return {
    cid: CID.parse(ZERO_CID),
    cidString: ZERO_CID,
    message: `${pc.yellow('⚠')} Invalid root CID structure, using zero CID: ${ZERO_CID}`,
  }
}

/**
 * Validate that a file exists and is a regular file
 */
async function validateFilePath(filePath: string): Promise<{ exists: boolean; stats?: any; error?: string }> {
  try {
    const stats = await stat(filePath)
    if (!stats.isFile()) {
      return { exists: false, error: `Not a file: ${filePath}` }
    }
    return { exists: true, stats }
  } catch (error: any) {
    // Differentiate between file not found and other errors
    if (error?.code === 'ENOENT') {
      return { exists: false, error: `File not found: ${filePath}` }
    }
    // Other errors like permission denied, etc.
    return {
      exists: false,
      error: `Cannot access file: ${filePath} (${error?.message || 'unknown error'})`,
    }
  }
}

/**
 * Normalize Commander options and run the CAR import flow.
 *
 * Commander wiring calls this so option validation errors are displayed by the
 * command UI layer and command files only own exit-code handling.
 */
export async function runCarImportFromCli(
  file: string,
  options: Record<string, any>
): Promise<ImportResult | ImportDryRunResult> {
  let importOptions: ImportOptions
  try {
    const autoFundOptions = validateAndNormalizeAutoFundOptions(options)
    const {
      metadata: _metadata,
      dataSetMetadata: _dataSetMetadata,
      datasetMetadata: _datasetMetadata,
      erc8004Type: _erc8004Type,
      erc8004Agent: _erc8004Agent,
      '8004Type': _erc8004TypeAlias,
      '8004Agent': _erc8004AgentAlias,
      autoFund: _autoFund,
      minRunwayDays: _minRunwayDays,
      maxBalance: _maxBalance,
      egressProvider: rawEgressProvider,
      ...importOptionsFromCli
    } = options

    const egressProvider = rawEgressProvider ?? 'none'

    const { pieceMetadata, dataSetMetadata } = resolveMetadataOptions(options, { includeErc8004: true })
    importOptions = {
      ...importOptionsFromCli,
      ...autoFundOptions,
      filePath: file,
      egressProvider,
      ...(pieceMetadata && { pieceMetadata }),
      ...(dataSetMetadata && { dataSetMetadata }),
    }
  } catch (error) {
    log.line(`${pc.red('Error:')} ${error instanceof Error ? error.message : String(error)}`)
    log.flush()
    cancel('Import cancelled')
    throw error
  }

  return await runCarImport(importOptions)
}

/**
 * Run the CAR import process
 *
 * @param options - Import configuration
 */
export async function runCarImport(options: ImportOptions): Promise<ImportResult | ImportDryRunResult> {
  intro(pc.bold('Filecoin Pin CAR Import'))

  const spinner = createSpinner()

  const { pieceMetadata, dataSetMetadata } = normalizeMetadataConfig({
    pieceMetadata: options.pieceMetadata,
    dataSetMetadata: options.dataSetMetadata,
  })

  // Initialize logger (silent for CLI output)
  const logger = pino({
    level: process.env.LOG_LEVEL || 'silent',
  })

  // Map the public egress provider to the SDK's withCDN boolean (internal only).
  const withCDN = options.egressProvider === 'beam'

  try {
    // Validate file exists and is readable
    spinner.start('Validating CAR file...')

    const fileValidation = await validateFilePath(options.filePath)
    if (!fileValidation.exists || !fileValidation.stats) {
      spinner.stop(`${pc.red('✗')} ${fileValidation.error}`)
      cancel('Import cancelled')
      throw new Error(fileValidation.error)
    }
    const fileStat = fileValidation.stats

    // Validate CAR format and extract roots
    let roots: CID[]
    try {
      roots = await validateCarFile(options.filePath)
    } catch (error) {
      spinner.stop(`${pc.red('✗')} Invalid CAR file: ${error instanceof Error ? error.message : 'Unknown error'}`)
      cancel('Import cancelled')
      throw new Error('Invalid CAR file')
    }

    // Handle root CID cases
    const rootCidInfo = resolveRootCID(roots)
    const { cid: rootCid, cidString: rootCidString, message } = rootCidInfo

    spinner.stop(`${pc.green('✓')} Valid CAR file (${formatFileSize(fileStat.size)})`)
    if (message) {
      log.line(message)
      log.flush()
    }

    // Validate context selection options early (before expensive operations)
    const contextSelection = parseContextSelectionOptions(options)

    // Initialize Synapse SDK
    spinner.start('Initializing Synapse SDK...')

    const config = parseCLIAuth(options)
    if (dataSetMetadata) {
      config.dataSetMetadata = dataSetMetadata
    }
    if (withCDN) config.withCDN = true
    config.requiredPermissions = [CreateDataSetPermission, AddPiecesPermission]

    const synapse = await initializeSynapse(config, logger)
    const networkSlug = getNetworkSlug(synapse.chain)
    const network = synapse.chain.name

    spinner.stop(`${pc.green('✓')} Connected to ${pc.bold(network)}`)

    if (withCDN && chainSupportsFilbeam(synapse)) {
      printEgressNotice('beam')
    }

    const targets = await resolveUploadTargets(synapse, contextSelection, {
      ...(dataSetMetadata != null && { dataSetMetadata }),
      ...(options.copies != null && { copies: options.copies }),
      withCDN,
      spinner,
      logger,
    })
    if (targets.dataSetIds != null) {
      contextSelection.dataSetIds = targets.dataSetIds
    }
    const effectiveDataSetMetadata = targets.dataSetMetadata
    const estimateOptions: EstimateUploadCostOptions = {
      ...(options.copies != null && { copies: options.copies }),
      ...(contextSelection.providerIds && { providerIds: contextSelection.providerIds }),
      ...(contextSelection.dataSetIds && { dataSetIds: contextSelection.dataSetIds }),
      ...(effectiveDataSetMetadata && { metadata: effectiveDataSetMetadata }),
      withCDN,
    }

    if (options.dryRun) {
      spinner.start('Estimating upload cost...')
      const estimate = await estimateUploadCost(synapse, fileStat.size, estimateOptions)
      spinner.stop(`${pc.green('✓')} Cost estimate ready`)

      const result: ImportDryRunResult = {
        dryRun: true,
        filePath: options.filePath,
        fileSize: fileStat.size,
        rootCid: rootCidString,
        requestedCopies: estimate.requestedCopies,
        newDataSetCount: estimate.newDataSetCount,
        costs: estimate.costs,
      }

      displayDryRunEstimate(result, estimate, network)
      outro('Dry run complete — no upload performed')
      return result
    }

    if (isSessionKeyMode(synapse)) {
      // Same contract as `add`: a session key cannot deposit, so check the
      // account can pay before uploading and point at the console when it cannot.
      spinner.start('Checking the account can pay for this upload...')
      await assertUploadFunds(synapse, fileStat.size, estimateOptions, rerunHint(), spinner)
      spinner.stop(`${pc.green('✓')} Account can pay for this upload`)
    } else if (options.autoFund) {
      const autoFundOptions: Parameters<typeof performAutoFunding>[3] = {
        withCDN,
        ...(dataSetMetadata && { metadata: dataSetMetadata }),
        ...(options.copies != null && { copies: options.copies }),
      }
      if (contextSelection.providerIds) {
        autoFundOptions.providerIds = contextSelection.providerIds
        autoFundOptions.copies = contextSelection.providerIds.length
      }
      if (contextSelection.dataSetIds) {
        autoFundOptions.dataSetIds = contextSelection.dataSetIds
        autoFundOptions.copies = contextSelection.dataSetIds.length
      }
      if (options.minRunwayDays !== undefined) {
        autoFundOptions.minRunwayDays = options.minRunwayDays
      }
      if (options.maxBalance !== undefined) {
        autoFundOptions.maxBalance = options.maxBalance
      }

      await performAutoFunding(synapse, fileStat.size, spinner, autoFundOptions)
    } else {
      spinner.start('Checking payment capacity...')
      await validatePaymentSetup(synapse, fileStat.size, spinner)
    }

    // Stream CAR file to Synapse
    spinner.start('Uploading to Filecoin...')

    const carData = Readable.toWeb(createReadStream(options.filePath)) as ReadableStream<Uint8Array>

    // Auto-skip IPNI on devnet (no IPNI infrastructure available)
    const skipIpniVerification = options.skipIpniVerification || synapse.chain.id === DEVNET_CHAIN_ID

    const uploadOptions: Parameters<typeof performUpload>[3] = {
      contextType: 'import',
      fileSize: fileStat.size,
      logger,
      spinner,
      skipIpniVerification,
      ...(pieceMetadata && { pieceMetadata }),
      ...(effectiveDataSetMetadata && { metadata: effectiveDataSetMetadata }),
      ...(options.copies != null && { copies: options.copies }),
    }
    if (contextSelection.providerIds) {
      uploadOptions.providerIds = contextSelection.providerIds
      uploadOptions.copies = contextSelection.providerIds.length
    }
    if (contextSelection.dataSetIds) {
      uploadOptions.dataSetIds = contextSelection.dataSetIds
      uploadOptions.copies = contextSelection.dataSetIds.length
    }

    const requestedCopies = uploadOptions.copies ?? DEFAULT_COPIES
    const uploadResult = await performUpload(synapse, carData, rootCid, uploadOptions)

    // Display results
    spinner.stop('━━━ Import Complete ━━━')

    const result: ImportResult = {
      filePath: options.filePath,
      fileSize: fileStat.size,
      rootCid: rootCidString,
      pieceCid: uploadResult.pieceCid,
      size: uploadResult.size,
      requestedCopies,
      copies: uploadResult.copies,
      failedAttempts: uploadResult.failedAttempts,
    }

    const filbeamUrl = buildFilbeamUrl(synapse, uploadResult.pieceCid, withCDN)
    const egress = filbeamUrl != null ? { filbeamUrl } : undefined

    displayUploadResults(result, 'Import', network, networkSlug, egress)

    if (uploadResult.copies.length < requestedCopies) {
      log.line('')
      log.line(
        pc.yellow(
          `${uploadResult.failedAttempts.length} copy failure(s). ` +
            `Got ${uploadResult.copies.length}/${requestedCopies} copies. Data is stored but with reduced redundancy.`
        )
      )
      log.flush()
      outro('Import completed with errors')
    } else if (uploadResult.failedAttempts.length > 0) {
      log.line('')
      log.line(pc.gray(`${uploadResult.failedAttempts.length} non-critical copy failure(s) during upload.`))
      log.flush()
      outro('Import completed successfully')
    } else {
      outro('Import completed successfully')
    }

    return result
  } catch (error) {
    if (isCliFatal(error)) {
      spinner.stop()
      logger.error({ event: 'import.failed', error }, 'Import failed')
      throw error
    }
    const msg = error instanceof Error ? error.message : 'Unknown error'
    const lockup = describeLockupShortfall(error)
    if (lockup != null) {
      spinner.stop(`${pc.red('✗')} Import failed: ${lockup.headline}`)
      log.line('')
      for (const hint of lockup.hints) {
        log.line(`  ${pc.cyan(hint)}`)
      }
      log.flush()
    } else {
      spinner.stop(`${pc.red('✗')} Import failed: ${msg}`)
    }
    logger.error({ event: 'import.failed', error }, 'Import failed')

    cancel('Import failed')
    throw new CliFatal(msg, { cause: error instanceof Error ? error : undefined })
  }
}
