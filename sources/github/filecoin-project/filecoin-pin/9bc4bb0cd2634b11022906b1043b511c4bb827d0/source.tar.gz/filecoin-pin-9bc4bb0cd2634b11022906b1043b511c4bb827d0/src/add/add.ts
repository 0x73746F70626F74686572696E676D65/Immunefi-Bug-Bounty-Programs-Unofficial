/**
 * File and directory add functionality
 *
 * This module handles adding files and directories to Filecoin via Synapse SDK.
 * It encodes content as UnixFS, creates CAR files, and uploads to Filecoin.
 */

import { createReadStream } from 'node:fs'
import { stat } from 'node:fs/promises'
import { Readable } from 'node:stream'
import { AddPiecesPermission, CreateDataSetPermission } from '@filoz/synapse-core/session-key'
import pc from 'picocolors'
import pino from 'pino'
import { CliFatal, isCliFatal } from '../common/cli-errors.js'
import { assertUploadFunds, estimateInputBytes, rerunHint } from '../common/funds-preflight.js'
import { DEVNET_CHAIN_ID } from '../common/get-rpc-url.js'
import { describeLockupShortfall } from '../common/lockup-error.js'
import {
  displayDryRunEstimate,
  displayUploadResults,
  type EstimateUploadCostOptions,
  estimateUploadCost,
  performAutoFunding,
  performUpload,
  resolveUploadTargets,
  validatePaymentSetup,
} from '../common/upload-flow.js'
import { carInputError, INPUT_IS_CAR, isCar } from '../core/car/index.js'
import { normalizeMetadataConfig, withDerivedNameMetadata } from '../core/metadata/index.js'
import { DEFAULT_COPIES } from '../core/synapse/constants.js'
import { initializeSynapse, isSessionKeyMode } from '../core/synapse/index.js'
import { cleanupTempCar, createCarFromPath } from '../core/unixfs/index.js'
import { getNetworkSlug } from '../core/upload/index.js'
import { parseCLIAuth, parseContextSelectionOptions } from '../utils/cli-auth.js'
import { cancel, createSpinner, formatFileSize, intro, outro } from '../utils/cli-helpers.js'
import { log } from '../utils/cli-logger.js'
import { validateAndNormalizeAutoFundOptions } from '../utils/cli-options.js'
import { buildFilbeamUrl, chainSupportsFilbeam, printEgressNotice } from '../utils/cli-options-egress.js'
import { resolveMetadataOptions } from '../utils/cli-options-metadata.js'
import type { AddDryRunResult, AddOptions, AddResult } from './types.js'

/**
 * Validate that a path exists and is a regular file or directory
 */
async function validatePath(path: string): Promise<{
  exists: boolean
  stats?: any
  isDirectory?: boolean
  error?: string
}> {
  try {
    const stats = await stat(path)
    if (stats.isFile()) {
      return { exists: true, stats, isDirectory: false }
    }
    if (stats.isDirectory()) {
      return { exists: true, stats, isDirectory: true }
    }
    // Not a file or directory (could be symlink, socket, etc.)
    return { exists: false, error: `Not a file or directory: ${path}` }
  } catch (error: any) {
    // Differentiate between not found and other errors
    if (error?.code === 'ENOENT') {
      return { exists: false, error: `Path not found: ${path}` }
    }
    // Other errors like permission denied, etc.
    return {
      exists: false,
      error: `Cannot access path: ${path} (${error?.message || 'unknown error'})`,
    }
  }
}

/**
 * Normalize Commander options and run the add flow.
 *
 * Commander wiring calls this so option validation errors are displayed by the
 * command UI layer and command files only own exit-code handling.
 */
export async function runAddFromCli(path: string, options: Record<string, any>): Promise<AddResult | AddDryRunResult> {
  let addOptions: AddOptions
  try {
    const autoFundOptions = validateAndNormalizeAutoFundOptions(options)
    const {
      metadata: _metadata,
      dataSetMetadata: _dataSetMetadata,
      datasetMetadata: _datasetMetadata,
      erc8004Type: _erc8004Type,
      erc8004Agent: _erc8004Agent,
      '8004Type': _erc8004TypeAlias,
      '8004Agent': _erc8004AgentAlias,
      autoFund: _autoFund,
      minRunwayDays: _minRunwayDays,
      maxBalance: _maxBalance,
      egressProvider: rawEgressProvider,
      ...addOptionsFromCli
    } = options
    const { pieceMetadata, dataSetMetadata } = resolveMetadataOptions(options, { includeErc8004: true })

    const egressProvider = rawEgressProvider ?? 'none'

    addOptions = {
      ...addOptionsFromCli,
      ...autoFundOptions,
      filePath: path,
      egressProvider,
      ...(pieceMetadata && { pieceMetadata }),
      ...(dataSetMetadata && { dataSetMetadata }),
    }
  } catch (error) {
    log.line(`${pc.red('Error:')} ${error instanceof Error ? error.message : String(error)}`)
    log.flush()
    cancel('Add cancelled')
    throw error
  }

  return await runAdd(addOptions)
}

/**
 * Run the file or directory add process
 *
 * @param options - Add configuration
 */
export async function runAdd(options: AddOptions): Promise<AddResult | AddDryRunResult> {
  intro(pc.bold('Filecoin Pin Add'))

  const spinner = createSpinner()

  const { pieceMetadata: userPieceMetadata, dataSetMetadata } = normalizeMetadataConfig({
    pieceMetadata: options.pieceMetadata,
    dataSetMetadata: options.dataSetMetadata,
  })

  // Initialize logger (silent for CLI output)
  const logger = pino({
    level: process.env.LOG_LEVEL || 'silent',
  })

  // Map the public egress provider to the SDK's withCDN boolean (internal only).
  const withCDN = options.egressProvider === 'beam'

  let tempCarPath: string | undefined

  try {
    // Validate path exists and is readable
    spinner.start('Validating path...')

    const pathValidation = await validatePath(options.filePath)
    if (!pathValidation.exists || !pathValidation.stats) {
      spinner.stop(`${pc.red('✗')} ${pathValidation.error}`)
      cancel('Add cancelled')
      throw new Error(pathValidation.error)
    }

    const pathStat = pathValidation.stats
    const isDirectory = pathValidation.isDirectory || false

    const pathType = isDirectory ? 'Directory' : 'File'
    const sizeDisplay = isDirectory ? '' : ` (${formatFileSize(pathStat.size)})`
    spinner.stop(`${pc.green('✓')} ${pathType} validated${sizeDisplay}`)

    // Fail fast on CAR-of-CAR before auth/payment checks run.
    if (!isDirectory) {
      const sniff = createReadStream(options.filePath)
      try {
        if (await isCar(sniff)) {
          throw carInputError(options.filePath)
        }
      } finally {
        sniff.destroy()
      }
    }

    // Validate context selection options early (before expensive operations)
    const contextSelection = parseContextSelectionOptions(options)

    // Initialize Synapse SDK
    spinner.start('Initializing Synapse SDK...')

    const config = parseCLIAuth(options)
    if (dataSetMetadata) {
      config.dataSetMetadata = dataSetMetadata
    }
    if (withCDN) config.withCDN = true
    config.requiredPermissions = [CreateDataSetPermission, AddPiecesPermission]

    const synapse = await initializeSynapse(config, logger)
    const networkSlug = getNetworkSlug(synapse.chain)
    const network = synapse.chain.name

    spinner.stop(`${pc.green('✓')} Connected to ${pc.bold(network)}`)

    if (withCDN && chainSupportsFilbeam(synapse)) {
      printEgressNotice('beam')
    }

    const targets = await resolveUploadTargets(synapse, contextSelection, {
      ...(dataSetMetadata != null && { dataSetMetadata }),
      ...(options.copies != null && { copies: options.copies }),
      withCDN,
      spinner,
      logger,
    })
    if (targets.dataSetIds != null) {
      contextSelection.dataSetIds = targets.dataSetIds
    }
    const effectiveDataSetMetadata = targets.dataSetMetadata

    const estimateOptions: EstimateUploadCostOptions = {
      ...(options.copies != null && { copies: options.copies }),
      ...(contextSelection.providerIds && { providerIds: contextSelection.providerIds }),
      ...(contextSelection.dataSetIds && { dataSetIds: contextSelection.dataSetIds }),
      ...(effectiveDataSetMetadata && { metadata: effectiveDataSetMetadata }),
      withCDN,
    }

    // The exact invocation, flags included, for the "Then re-run" hint.
    const rerunCommand = rerunHint()
    if (!options.dryRun && isSessionKeyMode(synapse)) {
      // A session key cannot deposit, so check the account can pay before
      // any packing happens and point at the console when it cannot.
      spinner.start('Checking the account can pay for this upload...')
      const estimatedBytes = await estimateInputBytes(options.filePath, isDirectory, options.includeHidden)
      await assertUploadFunds(synapse, estimatedBytes, estimateOptions, rerunCommand, spinner)
      spinner.stop(`${pc.green('✓')} Account can pay for this upload`)
    } else if (!options.autoFund && !options.dryRun) {
      // Check payment setup (may configure permissions if needed).
      // Skipped for --dry-run: this can submit an allowance-approval transaction,
      // which a dry run must never do.
      spinner.start('Checking payment setup...')
      await validatePaymentSetup(synapse, 0, spinner, {
        suppressSuggestions: true,
      })
    }

    // Create CAR from file or directory
    const packingMsg = isDirectory ? 'Packing directory for IPFS...' : 'Packing file for IPFS...'
    spinner.start(packingMsg)

    const { carPath, rootCid, name } = await createCarFromPath(options.filePath, {
      logger,
      spinner,
      isDirectory,
      ...(options.includeHidden !== undefined && { includeHidden: options.includeHidden }),
    })
    tempCarPath = carPath

    // File-vs-directory is recovered by inspecting the root CID
    // (codec + UnixFS Data.Type), not from a key-name distinction.
    const pieceMetadata = withDerivedNameMetadata(userPieceMetadata, name)

    spinner.stop(`${pc.green('✓')} ${isDirectory ? 'Directory' : 'File'} packed with root CID: ${rootCid.toString()}`)

    // The CLI still materializes a full CAR on disk first. This only avoids
    // buffering that CAR again in memory during upload.
    spinner.start('Inspecting packed IPFS content...')
    const { size: carSize } = await stat(tempCarPath)
    const carData = Readable.toWeb(createReadStream(tempCarPath)) as ReadableStream<Uint8Array>
    spinner.stop(`${pc.green('✓')} Packed IPFS content ready (${formatFileSize(carSize)})`)

    if (options.dryRun) {
      spinner.start('Estimating upload cost...')
      const estimate = await estimateUploadCost(synapse, carSize, estimateOptions)
      spinner.stop(`${pc.green('✓')} Cost estimate ready`)

      const result: AddDryRunResult = {
        dryRun: true,
        filePath: options.filePath,
        fileSize: carSize,
        ...(isDirectory && { isDirectory }),
        rootCid: rootCid.toString(),
        requestedCopies: estimate.requestedCopies,
        newDataSetCount: estimate.newDataSetCount,
        costs: estimate.costs,
      }

      displayDryRunEstimate(result, estimate, network)
      outro('Dry run complete — no upload performed')
      return result
    }

    const autoFundOptions: Parameters<typeof performAutoFunding>[3] = {
      withCDN,
      ...(dataSetMetadata && { metadata: dataSetMetadata }),
      ...(options.copies != null && { copies: options.copies }),
    }
    if (contextSelection.providerIds) {
      autoFundOptions.providerIds = contextSelection.providerIds
      autoFundOptions.copies = contextSelection.providerIds.length
    }
    if (contextSelection.dataSetIds) {
      autoFundOptions.dataSetIds = contextSelection.dataSetIds
      autoFundOptions.copies = contextSelection.dataSetIds.length
    }

    // Session mode wins over --auto-fund, as in import: a session key cannot deposit.
    if (isSessionKeyMode(synapse)) {
      // Same block and link as the preflight, now with the real CAR size.
      spinner.start('Checking the account can pay for this upload...')
      await assertUploadFunds(synapse, carSize, estimateOptions, rerunCommand, spinner)
      spinner.stop(`${pc.green('✓')} Account can pay for this upload`)
    } else if (options.autoFund) {
      if (options.minRunwayDays !== undefined) {
        autoFundOptions.minRunwayDays = options.minRunwayDays
      }
      if (options.maxBalance !== undefined) {
        autoFundOptions.maxBalance = options.maxBalance
      }

      await performAutoFunding(synapse, carSize, spinner, autoFundOptions)
    } else {
      spinner.start('Checking payment capacity...')
      await validatePaymentSetup(synapse, carSize, spinner)
    }

    // Auto-skip IPNI on devnet (no IPNI infrastructure available)
    const skipIpniVerification = options.skipIpniVerification || synapse.chain.id === DEVNET_CHAIN_ID

    const uploadOptions: Parameters<typeof performUpload>[3] = {
      contextType: 'add',
      fileSize: carSize,
      logger,
      spinner,
      skipIpniVerification,
      ...(pieceMetadata && { pieceMetadata }),
      ...(effectiveDataSetMetadata && { metadata: effectiveDataSetMetadata }),
      ...(options.copies != null && { copies: options.copies }),
    }
    if (contextSelection.providerIds) {
      uploadOptions.providerIds = contextSelection.providerIds
      uploadOptions.copies = contextSelection.providerIds.length
    }
    if (contextSelection.dataSetIds) {
      uploadOptions.dataSetIds = contextSelection.dataSetIds
      uploadOptions.copies = contextSelection.dataSetIds.length
    }

    // Upload to Synapse (SDK handles provider selection and multi-copy)
    const requestedCopies = uploadOptions.copies ?? DEFAULT_COPIES
    const uploadResult = await performUpload(synapse, carData, rootCid, uploadOptions)

    // Display results
    spinner.stop('━━━ Add Complete ━━━')

    const result: AddResult = {
      filePath: options.filePath,
      fileSize: carSize,
      ...(isDirectory && { isDirectory }),
      rootCid: rootCid.toString(),
      pieceCid: uploadResult.pieceCid,
      size: uploadResult.size,
      requestedCopies,
      copies: uploadResult.copies,
      failedAttempts: uploadResult.failedAttempts,
    }

    const filbeamUrl = buildFilbeamUrl(synapse, uploadResult.pieceCid, withCDN)
    const egress = filbeamUrl != null ? { filbeamUrl } : undefined

    displayUploadResults(result, 'Add', network, networkSlug, egress)

    if (uploadResult.copies.length < requestedCopies) {
      log.line('')
      log.line(
        pc.yellow(
          `${uploadResult.failedAttempts.length} copy failure(s). ` +
            `Got ${uploadResult.copies.length}/${requestedCopies} copies. Data is stored but with reduced redundancy.`
        )
      )
      log.flush()
      outro('Add completed with errors')
    } else if (uploadResult.failedAttempts.length > 0) {
      log.line('')
      log.line(pc.gray(`${uploadResult.failedAttempts.length} non-critical copy failure(s) during upload.`))
      log.flush()
      outro('Add completed successfully')
    } else {
      outro('Add completed successfully')
    }

    return result
  } catch (error) {
    if (isCliFatal(error)) {
      spinner.stop()
      logger.error({ event: 'add.failed', error }, 'Add failed')
      if (tempCarPath) {
        await cleanupTempCar(tempCarPath, logger)
      }
      throw error
    }

    const carInput = error instanceof Error && (error as { code?: string }).code === INPUT_IS_CAR
    const message = error instanceof Error ? error.message : 'Unknown error'
    const lockup = describeLockupShortfall(error)
    if (lockup != null) {
      spinner.stop(`${pc.red('✗')} Add failed: ${lockup.headline}`)
      log.line('')
      for (const hint of lockup.hints) {
        log.line(`  ${pc.cyan(hint)}`)
      }
      log.flush()
    } else {
      spinner.stop(`${pc.red('✗')} ${carInput ? message : `Add failed: ${message}`}`)
      if (carInput) {
        log.line('')
        log.line(pc.cyan(`  filecoin-pin import ${options.filePath}`))
        log.flush()
      }
    }
    logger.error({ event: 'add.failed', error }, 'Add failed')

    // Always cleanup temp CAR even on error
    if (tempCarPath) {
      await cleanupTempCar(tempCarPath, logger)
    }

    cancel(carInput ? 'Add cancelled' : 'Add failed')
    throw new CliFatal(message, { cause: error instanceof Error ? error : undefined })
  }
}
