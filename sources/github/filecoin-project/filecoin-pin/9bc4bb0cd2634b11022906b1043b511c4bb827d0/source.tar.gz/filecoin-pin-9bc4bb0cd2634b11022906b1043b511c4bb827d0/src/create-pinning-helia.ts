import { noise } from '@chainsafe/libp2p-noise'
import { yamux } from '@chainsafe/libp2p-yamux'
import { bitswap } from '@helia/block-brokers'
import type { Helia } from '@helia/interface'
import { httpGatewayRouting, libp2pRouting } from '@helia/routers'
import { Helia as HeliaClass } from '@helia/utils'
import { identify } from '@libp2p/identify'
import { tcp } from '@libp2p/tcp'
import { multiaddr } from '@multiformats/multiaddr'
import { MemoryDatastore } from 'datastore-core'
import { createLibp2p } from 'libp2p'
import type { CID } from 'multiformats/cid'
import type { Logger } from 'pino'
import { CARWritingBlockstore } from './core/car/index.js'
import type { Config } from './core/synapse/index.js'

const IDENTIFY_MAX_MESSAGE_SIZE = 1024 * 64

export interface PinningHeliaOptions {
  config: Config
  logger: Logger
  rootCID: CID
  outputPath: string
  origins?: string[] // Multiaddrs to connect to for content
}

/**
 * Create a Helia node with CAR-writing blockstore for a specific pin operation
 * This combines the server and CAR Helia functionality into one instance
 */
export async function createPinningHeliaNode(options: PinningHeliaOptions): Promise<{
  helia: Helia
  blockstore: CARWritingBlockstore
}> {
  const { logger, rootCID, outputPath, origins = [] } = options

  // Parse origins into multiaddrs
  const dialTargets = origins
    .map((origin) => {
      try {
        return multiaddr(origin)
      } catch (error) {
        logger.warn({ origin, error }, 'Failed to parse origin multiaddr')
        return null
      }
    })
    .filter((addr) => addr != null)

  const libp2p = await createLibp2p({
    addresses: {
      listen: ['/ip4/0.0.0.0/tcp/0'], // Random port
    },
    transports: [tcp()],
    connectionEncrypters: [noise()],
    streamMuxers: [yamux()],
    services: {
      identify: identify({ maxMessageSize: IDENTIFY_MAX_MESSAGE_SIZE }),
    },
    // No bootstrap or mdns - we'll connect directly to origins
  })

  // Create CAR-writing blockstore
  const carBlockstore = new CARWritingBlockstore({
    rootCID,
    outputPath,
    logger,
  })

  // Set up event handlers for monitoring
  carBlockstore.on('block:stored', (data) => {
    logger.debug({ cid: data.cid.toString(), size: data.size }, 'Block stored to CAR file')
  })

  carBlockstore.on('block:missing', (data) => {
    logger.warn({ cid: data.cid.toString() }, 'Block not found during fetch')
  })

  // The `helia` meta-package's createHelia statically imports its default
  // libp2p config, including @libp2p/webrtc and its node-datachannel native
  // module. This node supplies its own TCP-only libp2p, so Helia is
  // constructed directly from @helia/utils. libp2pRouting and
  // httpGatewayRouting are the same routers createHelia configures.
  const helia = new HeliaClass({
    libp2p,
    blockstore: carBlockstore,
    datastore: new MemoryDatastore(),
    blockBrokers: [bitswap()],
    routers: [libp2pRouting(libp2p), httpGatewayRouting()],
  })
  await helia.start()

  logger.info(`Pinning Helia node started with peer ID: ${helia.libp2p.peerId.toString()}`)
  logger.info(`Writing blocks to CAR file: ${outputPath}`)

  // Connect to origin node if provided
  if (dialTargets.length > 0) {
    logger.info({ origins: dialTargets.length }, 'Connecting to origin node')
    try {
      await helia.libp2p.dial(dialTargets)
      logger.info('Connected to origin node')
    } catch (error) {
      logger.warn({ error }, 'Failed to connect to origin node')
    }
  }

  return { helia, blockstore: carBlockstore }
}
