import { SchedulePieceRemovalsPermission } from '@filoz/synapse-core/session-key'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { runRmPiece } from '../../rm/remove-piece.js'
import type { RmPieceOptions } from '../../rm/types.js'

const {
  spinner,
  mockIntro,
  mockOutro,
  mockCancel,
  mockCreateSpinner,
  mockParseCLIAuth,
  mockInitializeSynapse,
  mockCreateContext,
  mockRemovePiece,
  mockLogSection,
} = vi.hoisted(() => {
  const spinner = {
    start: vi.fn(),
    stop: vi.fn(),
    message: vi.fn(),
    clear: vi.fn(),
  }

  const mockIntro = vi.fn()
  const mockOutro = vi.fn()
  const mockCancel = vi.fn()
  const mockCreateSpinner = vi.fn(() => spinner)
  const mockParseCLIAuth = vi.fn(() => ({ privateKey: '0xabc', rpcUrl: 'wss://rpc' }))
  const mockLogSection = vi.fn()

  const mockStorageContext = { dataSetId: 123n }
  const mockCreateContext = vi.fn(async () => mockStorageContext)

  const mockInitializeSynapse = vi.fn(() => ({
    chain: { name: 'calibration' },
    client: { account: { address: '0xtest' } },
    storage: { createContext: mockCreateContext },
  }))

  const mockRemovePiece = vi.fn(async (_pieceCid: string, _storage: any, opts: { onProgress?: any }) => {
    opts.onProgress?.({
      type: 'removePiece:submitted',
      data: { pieceCid: _pieceCid, dataSetId: Number(_storage.dataSetId), txHash: '0xtx' },
    })
    opts.onProgress?.({
      type: 'removePiece:complete',
      data: { txHash: '0xtx', confirmed: true },
    })
    return '0xtx'
  })

  return {
    spinner,
    mockIntro,
    mockOutro,
    mockCancel,
    mockCreateSpinner,
    mockParseCLIAuth,
    mockInitializeSynapse,
    mockCreateContext,
    mockRemovePiece,
    mockLogSection,
  }
})

vi.mock('../../utils/cli-helpers.js', () => ({
  intro: mockIntro,
  outro: mockOutro,
  cancel: mockCancel,
  createSpinner: mockCreateSpinner,
}))

vi.mock('../../utils/cli-auth.js', () => ({
  parseCLIAuth: mockParseCLIAuth,
}))

vi.mock('../../utils/cli-logger.js', () => ({
  log: { spinnerSection: mockLogSection },
}))

vi.mock('../../core/synapse/index.js', () => ({
  initializeSynapse: mockInitializeSynapse,
}))

vi.mock('../../core/piece/index.js', () => ({
  removePiece: mockRemovePiece,
}))

describe('runRmPiece', () => {
  const baseOptions: RmPieceOptions = {
    piece: 'bafkzcibpiece',
    dataSet: '123',
  }

  beforeEach(() => {
    vi.clearAllMocks()
    process.exitCode = 0
  })

  afterEach(() => {
    process.exitCode = 0
  })

  it('removes a piece and returns result with confirmation status', async () => {
    const result = await runRmPiece({ ...baseOptions, waitForConfirmation: true })

    expect(result).toEqual({
      pieceCid: 'bafkzcibpiece',
      dataSetId: 123,
      transactionHash: '0xtx',
      confirmed: true,
    })
    expect(process.exitCode).toBe(0)

    expect(mockInitializeSynapse).toHaveBeenCalledWith(
      expect.objectContaining({
        privateKey: '0xabc',
        rpcUrl: 'wss://rpc',
        requiredPermissions: [SchedulePieceRemovalsPermission],
      }),
      expect.anything()
    )
    expect(mockRemovePiece).toHaveBeenCalledWith(
      'bafkzcibpiece',
      expect.objectContaining({ dataSetId: 123n }),
      expect.objectContaining({
        waitForConfirmation: true,
        onProgress: expect.any(Function),
      })
    )
    expect(mockCreateContext).toHaveBeenCalledWith({ dataSetId: 123n })
    expect(spinner.stop).toHaveBeenCalledWith(expect.stringContaining('Piece removed'))
    expect(mockIntro).toHaveBeenCalled()
    expect(mockOutro).toHaveBeenCalledWith('Remove completed successfully')
  })

  it('exits with code 2 when a requested confirmation wait times out', async () => {
    mockRemovePiece.mockImplementationOnce(async (_pieceCid: string, _storage: any, opts: { onProgress?: any }) => {
      opts.onProgress?.({
        type: 'removePiece:submitted',
        data: { pieceCid: _pieceCid, dataSetId: Number(_storage.dataSetId), txHash: '0xtx' },
      })
      opts.onProgress?.({
        type: 'removePiece:confirmationFailed',
        data: { pieceCid: _pieceCid, dataSetId: Number(_storage.dataSetId), txHash: '0xtx', message: 'timed out' },
      })
      opts.onProgress?.({
        type: 'removePiece:complete',
        data: { txHash: '0xtx', confirmed: false },
      })
      return '0xtx'
    })

    const result = await runRmPiece({ ...baseOptions, waitForConfirmation: true })

    expect(result.confirmed).toBe(false)
    expect(process.exitCode).toBe(2)
    expect(mockOutro).toHaveBeenCalledWith('Remove submitted; confirmation still pending')
    expect(mockOutro).not.toHaveBeenCalledWith('Remove completed successfully')
  })

  it('does not downgrade a prior non-zero exit code on wait timeout', async () => {
    process.exitCode = 1
    mockRemovePiece.mockImplementationOnce(async (_pieceCid: string, _storage: any, opts: { onProgress?: any }) => {
      opts.onProgress?.({ type: 'removePiece:complete', data: { txHash: '0xtx', confirmed: false } })
      return '0xtx'
    })

    await runRmPiece({ ...baseOptions, waitForConfirmation: true })

    expect(process.exitCode).toBe(1)
  })

  it('does not set a failure exit code when confirmation was not requested', async () => {
    mockRemovePiece.mockImplementationOnce(async (_pieceCid: string, _storage: any, opts: { onProgress?: any }) => {
      opts.onProgress?.({
        type: 'removePiece:submitted',
        data: { pieceCid: _pieceCid, dataSetId: Number(_storage.dataSetId), txHash: '0xtx' },
      })
      opts.onProgress?.({
        type: 'removePiece:complete',
        data: { txHash: '0xtx', confirmed: false },
      })
      return '0xtx'
    })

    await runRmPiece({ ...baseOptions, waitForConfirmation: false })

    expect(process.exitCode).toBe(0)
  })

  it('throws when piece CID or data set is missing', async () => {
    await expect(
      runRmPiece({
        ...baseOptions,
        piece: '',
        dataSet: '',
      } as RmPieceOptions)
    ).rejects.toThrow('Piece CID and DataSet ID are required')

    expect(mockRemovePiece).not.toHaveBeenCalled()
    expect(mockCancel).toHaveBeenCalledWith('Remove cancelled')
    expect(spinner.stop).toHaveBeenCalled()
  })

  it('throws on invalid data set id', async () => {
    await expect(runRmPiece({ ...baseOptions, dataSet: '-5' })).rejects.toThrow('DataSet ID must be a positive integer')

    expect(mockRemovePiece).not.toHaveBeenCalled()
    expect(mockCancel).toHaveBeenCalledWith('Remove cancelled')
    expect(spinner.stop).toHaveBeenCalled()
  })
})
