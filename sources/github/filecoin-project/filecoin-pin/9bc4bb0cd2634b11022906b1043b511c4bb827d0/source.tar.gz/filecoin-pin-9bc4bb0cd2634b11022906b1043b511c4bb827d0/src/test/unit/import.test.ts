/**
 * Unit tests for CAR import functionality
 *
 * Tests the import command's ability to:
 * - Validate CAR files
 * - Handle various root CID scenarios
 * - Initialize Synapse with progress callbacks
 * - Upload to Filecoin
 * - Clean up resources properly
 */

import { createWriteStream } from 'node:fs'
import { mkdir, rm, stat, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { pipeline } from 'node:stream/promises'
import { ReadableStream } from 'node:stream/web'
import { AddPiecesPermission, CreateDataSetPermission } from '@filoz/synapse-core/session-key'
import { CarWriter } from '@ipld/car'
import { CID } from 'multiformats/cid'
import * as raw from 'multiformats/codecs/raw'
import { sha256 } from 'multiformats/hashes/sha2'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { runCarImport, runCarImportFromCli } from '../../import/import.js'
import type { ImportDryRunResult, ImportOptions, ImportResult } from '../../import/types.js'

// Test constants
const ZERO_CID = 'bafkqaaa' // Zero CID used when CAR has no roots

// Mock modules
vi.mock('@filoz/synapse-sdk', async () => await import('../mocks/synapse-sdk.js'))
vi.mock('../../common/upload-flow.js', () => ({
  validatePaymentSetup: vi.fn(),
  promptDataSetSelection: vi.fn().mockRejectedValue(new Error('not interactive')),
  // Mirrors the real no-match path: an unmatched --data-set-metadata filter is
  // carried forward so a newly created data set still gets it.
  resolveUploadTargets: vi.fn(async (_synapse: any, _selection: any, opts: any) => ({
    ...(opts?.dataSetMetadata != null && { dataSetMetadata: opts.dataSetMetadata }),
  })),
  performUpload: vi.fn().mockResolvedValue({
    pieceCid: 'bafkzcibtest1234567890',
    size: 1024,
    copies: [
      {
        providerId: 1n,
        dataSetId: 123n,
        pieceId: 789n,
        role: 'primary',
        retrievalUrl: 'http://test.provider/pdp/piece/bafkzcibtest1234567890',
        isNewDataSet: false,
      },
    ],
    failedAttempts: [],
    network: 'calibration',
  }),
  displayUploadResults: vi.fn(),
  performAutoFunding: vi.fn(),
  estimateUploadCost: vi.fn().mockResolvedValue({
    requestedCopies: 2,
    newDataSetCount: 0,
    costs: {
      rates: { perEpoch: 100n, perMonth: 3000n },
      fees: { total: 500n },
      lockups: { total: 90000n },
      depositNeeded: 0n,
      needsFwssMaxApproval: false,
      ready: true,
    },
  }),
  displayDryRunEstimate: vi.fn(),
}))
vi.mock('../../core/payments/index.js', async () => {
  const actual = await vi.importActual<typeof import('../../core/payments/index.js')>('../../core/payments/index.js')
  return {
    ...actual,
    checkFILBalance: vi.fn().mockResolvedValue({
      balance: 1000000000000000000n,
      isCalibnet: true,
      hasSufficientGas: true,
    }),
    checkUSDFCBalance: vi.fn().mockResolvedValue(1000000000000000000000n),
    checkAllowances: vi.fn().mockResolvedValue({
      needsUpdate: false,
      currentAllowances: {
        rateAllowance: BigInt('0xffffffffffffffff'),
        lockupAllowance: BigInt('0xffffffffffffffff'),
        rateUsed: 0n,
        lockupUsed: 0n,
      },
    }),
    setMaxAllowances: vi.fn().mockResolvedValue({
      transactionHash: '0x123...',
      currentAllowances: {
        rateAllowance: BigInt('0xffffffffffffffff'),
        lockupAllowance: BigInt('0xffffffffffffffff'),
        rateUsed: 0n,
        lockupUsed: 0n,
      },
    }),
    checkAndSetAllowances: vi.fn().mockResolvedValue({
      updated: false,
      currentAllowances: {
        rateAllowance: BigInt('0xffffffffffffffff'),
        lockupAllowance: BigInt('0xffffffffffffffff'),
        rateUsed: 0n,
        lockupUsed: 0n,
      },
    }),
    validatePaymentCapacity: vi.fn().mockResolvedValue({
      canUpload: true,
      storageTiB: 0.001,
      required: {
        rateAllowance: 100000000000000n,
        lockupAllowance: 1000000000000000000n,
        storageCapacityTiB: 0.001,
      },
      issues: {},
      suggestions: [],
    }),
  }
})
vi.mock('../../core/utils/validate-ipni-advertisement.js', () => ({
  waitForIndexingConfirmation: vi.fn().mockResolvedValue(true),
}))

vi.mock('../../payments/setup.js', () => ({
  formatUSDFC: vi.fn((amount) => `${amount} USDFC`),
  validatePaymentRequirements: vi.fn().mockReturnValue({ isValid: true }),
}))
const { mockFindDataSets } = vi.hoisted(() => ({ mockFindDataSets: vi.fn().mockResolvedValue([]) }))

vi.mock('../../common/funds-preflight.js', async (importOriginal) => ({
  ...(await importOriginal<typeof import('../../common/funds-preflight.js')>()),
  assertUploadFunds: vi.fn(async () => undefined),
}))

vi.mock('../../core/synapse/index.js', () => ({
  isSessionKeyMode: vi.fn(() => false),
  getClientAddress: vi.fn(() => '0x1234567890123456789012345678901234567890'),
  initializeSynapse: vi.fn((config: any, _logger: any) => {
    // Validate auth config (mirrors validateAuthConfig in actual code)
    const hasStandardAuth = config.privateKey != null
    const hasSessionKeyAuth = config.walletAddress != null && config.sessionKey != null
    const hasViewOnlyAuth = config.readOnly === true && config.walletAddress != null

    if (!hasStandardAuth && !hasSessionKeyAuth && !hasViewOnlyAuth) {
      throw new Error(
        'Authentication required: provide either privateKey, walletAddress + sessionKey, view-address, or signer'
      )
    }

    return {
      chain: { name: 'calibration', id: 314159, filbeam: { retrievalDomain: 'calibration.filbeam.io' } },
      client: { account: { address: '0x1234567890123456789012345678901234567890' } },
      storage: {
        upload: vi.fn(),
        findDataSets: mockFindDataSets,
      },
    }
  }),
}))

// Mock console methods to capture output
const consoleMocks = {
  log: vi.spyOn(console, 'log').mockImplementation(() => {
    // Intentionally empty - suppressing console output in tests
  }),
  error: vi.spyOn(console, 'error').mockImplementation(() => {
    // Intentionally empty - suppressing console output in tests
  }),
}

// Mock process.exit to prevent test runner from exiting
const processExitMock = vi.spyOn(process, 'exit').mockImplementation(() => {
  throw new Error('process.exit called')
})

/**
 * Create a test CAR file with the given content
 *
 * @param filePath - Path where the CAR file should be written
 * @param roots - Root CIDs for the CAR header
 * @param blocks - Array of { content, cid? } to add to the CAR
 */
async function createTestCarFile(
  filePath: string,
  roots: CID[],
  blocks: Array<{ content: string | Uint8Array; cid?: CID }> = []
): Promise<{ cids: CID[] }> {
  const { writer, out } = await CarWriter.create(roots)
  const writeStream = createWriteStream(filePath)

  // Start piping the CAR output to file
  const pipePromise = pipeline(out as any, writeStream)

  // Track CIDs for test assertions
  const cids: CID[] = []

  // Write blocks
  for (const block of blocks) {
    const bytes = typeof block.content === 'string' ? new TextEncoder().encode(block.content) : block.content

    let cid = block.cid
    if (!cid) {
      const hash = await sha256.digest(bytes)
      cid = CID.create(1, raw.code, hash)
    }

    cids.push(cid)
    await writer.put({ cid, bytes })
  }

  await writer.close()
  await pipePromise

  return { cids }
}

async function createCarWithRoot(carPath: string): Promise<CID> {
  const { cids } = await createTestCarFile(carPath, [], [{ content: 'test content' }])
  const cid = cids[0]
  if (!cid) throw new Error('No CID generated')
  await createTestCarFile(carPath, [cid], [{ content: 'test content', cid }])
  return cid
}

describe('CAR Import', () => {
  const testDir = './test-import-cars'
  const testPrivateKey = '0x0000000000000000000000000000000000000000000000000000000000000001'

  beforeEach(async () => {
    // Create test directory
    await mkdir(testDir, { recursive: true })

    // Clear all mocks
    vi.clearAllMocks()
    consoleMocks.log.mockClear()
    consoleMocks.error.mockClear()
    processExitMock.mockClear()
  })

  afterEach(async () => {
    // Clean up test files
    try {
      await stat(testDir)
      await rm(testDir, { recursive: true, force: true })
    } catch {
      // Directory doesn't exist, nothing to clean up
    }
  })

  describe('CAR File Validation', () => {
    it('should validate a proper CAR file with single root', async () => {
      const carPath = join(testDir, 'valid.car')
      const cid = await createCarWithRoot(carPath)

      const result = (await runCarImport({ filePath: carPath, privateKey: testPrivateKey })) as ImportResult

      expect(result.rootCid).toBe(cid.toString())
      expect(result.filePath).toBe(carPath)
      expect(result.pieceCid).toBeDefined()
      expect(result.copies).toHaveLength(1)
    })

    it('should handle CAR file with no roots (use zero CID)', async () => {
      const carPath = join(testDir, 'no-roots.car')
      await createTestCarFile(
        carPath,
        [], // Empty roots array
        [{ content: 'test content' }]
      )

      const options: ImportOptions = {
        filePath: carPath,
        privateKey: testPrivateKey,
      }

      const result = (await runCarImport(options)) as ImportResult

      expect(result.rootCid).toBe(ZERO_CID) // Zero CID
      expect(result.filePath).toBe(carPath)
      expect(result.pieceCid).toBeDefined()
    })

    it('should handle CAR file with multiple roots (use first)', async () => {
      const carPath = join(testDir, 'multi-roots.car')
      const { cids } = await createTestCarFile(
        carPath,
        [], // Will set roots after creating CIDs
        [{ content: 'content 1' }, { content: 'content 2' }]
      )

      const cid1 = cids[0]
      const cid2 = cids[1]
      if (!cid1 || !cid2) throw new Error('CIDs not generated')

      // Recreate with multiple roots
      await createTestCarFile(
        carPath,
        [cid1, cid2], // Multiple roots
        [
          { content: 'content 1', cid: cid1 },
          { content: 'content 2', cid: cid2 },
        ]
      )

      const options: ImportOptions = {
        filePath: carPath,
        privateKey: testPrivateKey,
      }

      const result = await runCarImport(options)

      expect(result.rootCid).toBe(cid1.toString()) // Should use first CID
      expect(consoleMocks.log).toHaveBeenCalledWith(expect.stringContaining('Multiple root CIDs found'))
    })

    it('should reject invalid CAR file', async () => {
      const invalidCarPath = join(testDir, 'invalid.car')
      await writeFile(invalidCarPath, 'not a car file')

      const options: ImportOptions = {
        filePath: invalidCarPath,
        privateKey: testPrivateKey,
      }

      await expect(runCarImport(options)).rejects.toThrow()
    })

    it('should reject non-existent file', async () => {
      const options: ImportOptions = {
        filePath: join(testDir, 'nonexistent.car'),
        privateKey: testPrivateKey,
      }

      await expect(runCarImport(options)).rejects.toThrow()
    })
  })

  describe('session-key funds preflight', () => {
    const sessionAuth = (carPath: string): ImportOptions => ({
      filePath: carPath,
      walletAddress: '0x1234567890123456789012345678901234567890',
      sessionKey: `0x${'11'.repeat(32)}`,
      rpcUrl: 'wss://test.rpc.url',
    })

    afterEach(async () => {
      const { isSessionKeyMode } = await import('../../core/synapse/index.js')
      vi.mocked(isSessionKeyMode).mockReturnValue(false)
    })

    it('checks funds on the CAR size before uploading', async () => {
      const carPath = join(testDir, 'session.car')
      await createTestCarFile(carPath, [], [{ content: 'test content' }])
      const { isSessionKeyMode } = await import('../../core/synapse/index.js')
      const { assertUploadFunds } = await import('../../common/funds-preflight.js')
      const { performUpload } = await import('../../common/upload-flow.js')
      vi.mocked(isSessionKeyMode).mockReturnValue(true)

      await runCarImport(sessionAuth(carPath))

      expect(vi.mocked(assertUploadFunds)).toHaveBeenCalledTimes(1)
      expect(vi.mocked(assertUploadFunds).mock.calls[0]?.[1]).toBe((await stat(carPath)).size)
      expect(vi.mocked(assertUploadFunds).mock.invocationCallOrder[0]).toBeLessThan(
        vi.mocked(performUpload).mock.invocationCallOrder[0] as number
      )
    })

    it('uploads nothing when the funds check refuses', async () => {
      const carPath = join(testDir, 'session-refused.car')
      await createTestCarFile(carPath, [], [{ content: 'test content' }])
      const { isSessionKeyMode } = await import('../../core/synapse/index.js')
      const { assertUploadFunds } = await import('../../common/funds-preflight.js')
      const { performUpload } = await import('../../common/upload-flow.js')
      vi.mocked(isSessionKeyMode).mockReturnValue(true)
      vi.mocked(assertUploadFunds).mockRejectedValueOnce(new Error("Account can't pay for this upload"))

      await expect(runCarImport(sessionAuth(carPath))).rejects.toThrow("Account can't pay")
      expect(vi.mocked(performUpload)).not.toHaveBeenCalled()
    })
  })

  describe('Synapse Integration', () => {
    it('should call performUpload during import', async () => {
      const carPath = join(testDir, 'progress.car')
      await createTestCarFile(
        carPath,
        [], // Will use first block's CID
        [{ content: 'test content' }]
      )

      const options: ImportOptions = {
        filePath: carPath,
        privateKey: testPrivateKey,
      }

      await runCarImport(options)

      // Verify performUpload was called (replaces old createContext check)
      const { performUpload } = await import('../../common/upload-flow.js')
      expect(vi.mocked(performUpload)).toHaveBeenCalled()
    })

    it('should require private key', async () => {
      const carPath = join(testDir, 'test.car')
      await createTestCarFile(carPath, [], [{ content: 'test content' }])

      const options: ImportOptions = {
        filePath: carPath,
        // No private key provided
      }

      await expect(runCarImport(options)).rejects.toThrow()
      // The error is caught and logged generically as "Import failed"
      expect(consoleMocks.error).toHaveBeenCalled()
    })

    it('should use custom RPC URL if provided', async () => {
      const carPath = join(testDir, 'rpc.car')
      await createTestCarFile(carPath, [], [{ content: 'test content' }])

      const customRpcUrl = 'wss://custom.rpc.url/ws'
      const options: ImportOptions = {
        filePath: carPath,
        privateKey: testPrivateKey,
        rpcUrl: customRpcUrl,
      }

      const { initializeSynapse } = await import('../../core/synapse/index.js')
      const initSpy = vi.mocked(initializeSynapse)

      await runCarImport(options)

      expect(initSpy).toHaveBeenCalledWith(
        expect.objectContaining({
          rpcUrl: customRpcUrl,
        }),
        expect.any(Object)
      )
    })

    it('passes metadata options through to upload', async () => {
      const carPath = join(testDir, 'metadata.car')
      await createTestCarFile(carPath, [], [{ content: 'test content' }])

      const options: ImportOptions = {
        filePath: carPath,
        privateKey: testPrivateKey,
        pieceMetadata: { ics: '8004' },
        dataSetMetadata: { erc8004Files: '' },
      }

      await runCarImport(options)
      const { initializeSynapse } = await import('../../core/synapse/index.js')

      expect(vi.mocked(initializeSynapse)).toHaveBeenCalledWith(
        expect.objectContaining({
          dataSetMetadata: { erc8004Files: '' },
          requiredPermissions: [CreateDataSetPermission, AddPiecesPermission],
        }),
        expect.any(Object)
      )

      const { performUpload } = await import('../../common/upload-flow.js')
      expect(vi.mocked(performUpload)).toHaveBeenCalledWith(
        expect.any(Object),
        expect.any(ReadableStream),
        expect.any(Object),
        expect.objectContaining({
          pieceMetadata: { ics: '8004' },
        })
      )
    })

    it('routes --data-set-metadata through resolveUploadTargets to performUpload', async () => {
      const carPath = join(testDir, 'resolve-match.car')
      await createTestCarFile(carPath, [], [{ content: 'resolve match' }])

      const { resolveUploadTargets, performUpload } = await import('../../common/upload-flow.js')
      vi.mocked(resolveUploadTargets).mockResolvedValueOnce({ dataSetIds: [13260n, 13261n] })

      await runCarImport({
        filePath: carPath,
        privateKey: testPrivateKey,
        dataSetMetadata: { source: 'storacha-migration', 'space-did': 'did:key:abc' },
      })

      expect(vi.mocked(resolveUploadTargets)).toHaveBeenCalledWith(
        expect.anything(),
        expect.any(Object),
        expect.objectContaining({ dataSetMetadata: { source: 'storacha-migration', 'space-did': 'did:key:abc' } })
      )
      expect(vi.mocked(performUpload)).toHaveBeenCalledWith(
        expect.any(Object),
        expect.any(ReadableStream),
        expect.any(Object),
        expect.objectContaining({ dataSetIds: [13260n, 13261n] })
      )
      const lastCall = vi.mocked(performUpload).mock.calls.at(-1)
      expect(lastCall?.[3]).not.toHaveProperty('metadata')
    })

    it('passes upload targeting options through to auto-funding', async () => {
      const carPath = join(testDir, 'auto-fund.car')
      await createTestCarFile(carPath, [], [{ content: 'test content' }])

      const options: ImportOptions = {
        filePath: carPath,
        privateKey: testPrivateKey,
        autoFund: true,
        dataSetIds: ['123'],
        dataSetMetadata: { erc8004Files: '' },
      }

      await runCarImport(options)

      const { performAutoFunding } = await import('../../common/upload-flow.js')
      expect(vi.mocked(performAutoFunding)).toHaveBeenCalledWith(
        expect.anything(),
        expect.any(Number),
        expect.anything(),
        expect.objectContaining({
          dataSetIds: [123n],
          copies: 1,
          metadata: { erc8004Files: '' },
        })
      )
    })
  })

  describe('Upload Result', () => {
    it('should return complete import result with copies', async () => {
      const carPath = join(testDir, 'result.car')
      const cid = await createCarWithRoot(carPath)

      const result = (await runCarImport({ filePath: carPath, privateKey: testPrivateKey })) as ImportResult

      expect(result).toMatchObject({
        filePath: carPath,
        fileSize: expect.any(Number),
        rootCid: cid.toString(),
        pieceCid: expect.stringMatching(/^bafkzcib/),
        size: 1024,
      })

      expect(result.copies).toHaveLength(1)
      expect(result.copies[0]?.role).toBe('primary')
      expect(result.copies[0]?.providerId).toBe(1n)
      expect(result.failedAttempts).toHaveLength(0)
    })
  })

  describe('dry-run', () => {
    it('returns ImportDryRunResult and skips upload, funding, and payment validation', async () => {
      const carPath = join(testDir, 'dry-run.car')
      await createTestCarFile(carPath, [], [{ content: 'dry-run content' }])

      const result = (await runCarImport({
        filePath: carPath,
        privateKey: testPrivateKey,
        rpcUrl: 'wss://test.rpc.url',
        dryRun: true,
      })) as ImportDryRunResult

      expect(result).toMatchObject({
        dryRun: true,
        filePath: carPath,
        fileSize: expect.any(Number),
        requestedCopies: 2,
        newDataSetCount: 0,
        costs: expect.objectContaining({ ready: true }),
      })

      const { performUpload, performAutoFunding, validatePaymentSetup } = await import('../../common/upload-flow.js')
      expect(vi.mocked(performUpload)).not.toHaveBeenCalled()
      expect(vi.mocked(performAutoFunding)).not.toHaveBeenCalled()
      expect(vi.mocked(validatePaymentSetup)).not.toHaveBeenCalled()
    })

    it('passes copies to estimateUploadCost', async () => {
      const carPath = join(testDir, 'dry-run-copies.car')
      await createTestCarFile(carPath, [], [{ content: 'copies content' }])

      await runCarImport({
        filePath: carPath,
        privateKey: testPrivateKey,
        rpcUrl: 'wss://test.rpc.url',
        dryRun: true,
        copies: 3,
      })

      const { estimateUploadCost } = await import('../../common/upload-flow.js')
      expect(vi.mocked(estimateUploadCost)).toHaveBeenCalledWith(
        expect.anything(),
        expect.any(Number),
        expect.objectContaining({ copies: 3 })
      )
    })

    it('passes providerIds to estimateUploadCost', async () => {
      const carPath = join(testDir, 'dry-run-providers.car')
      await createTestCarFile(carPath, [], [{ content: 'providers content' }])

      await runCarImport({
        filePath: carPath,
        privateKey: testPrivateKey,
        rpcUrl: 'wss://test.rpc.url',
        dryRun: true,
        providerIds: ['7', '8'],
      })

      const { estimateUploadCost } = await import('../../common/upload-flow.js')
      expect(vi.mocked(estimateUploadCost)).toHaveBeenCalledWith(
        expect.anything(),
        expect.any(Number),
        expect.objectContaining({ providerIds: [7n, 8n] })
      )
    })

    it('passes dataSetIds to estimateUploadCost', async () => {
      const carPath = join(testDir, 'dry-run-datasets.car')
      await createTestCarFile(carPath, [], [{ content: 'datasets content' }])

      await runCarImport({
        filePath: carPath,
        privateKey: testPrivateKey,
        rpcUrl: 'wss://test.rpc.url',
        dryRun: true,
        dataSetIds: ['123', '456'],
      })

      const { estimateUploadCost } = await import('../../common/upload-flow.js')
      expect(vi.mocked(estimateUploadCost)).toHaveBeenCalledWith(
        expect.anything(),
        expect.any(Number),
        expect.objectContaining({ dataSetIds: [123n, 456n] })
      )
    })

    it('passes withCDN: false to estimateUploadCost when egressProvider is none', async () => {
      const carPath = join(testDir, 'dry-run-egress.car')
      await createTestCarFile(carPath, [], [{ content: 'egress content' }])

      await runCarImport({
        filePath: carPath,
        privateKey: testPrivateKey,
        rpcUrl: 'wss://test.rpc.url',
        dryRun: true,
        egressProvider: 'none',
      })

      const { estimateUploadCost } = await import('../../common/upload-flow.js')
      expect(vi.mocked(estimateUploadCost)).toHaveBeenCalledWith(
        expect.anything(),
        expect.any(Number),
        expect.objectContaining({ withCDN: false })
      )
    })
  })
})

describe('runCarImport withCDN propagation', () => {
  const testDir = './test-import-cdn-cars'
  const testPrivateKey = '0x0000000000000000000000000000000000000000000000000000000000000001'

  beforeEach(async () => {
    await mkdir(testDir, { recursive: true })
    vi.clearAllMocks()
  })

  afterEach(async () => {
    try {
      await stat(testDir)
      await rm(testDir, { recursive: true, force: true })
    } catch {
      // Directory doesn't exist, nothing to clean up
    }
  })

  it('passes filbeamUrl to displayUploadResults when withCDN is true and chain.filbeam is set', async () => {
    const carPath = join(testDir, 'filbeam-url.car')
    await createTestCarFile(carPath, [], [{ content: 'filbeam url content' }])
    await runCarImport({
      filePath: carPath,
      privateKey: testPrivateKey,
      rpcUrl: 'wss://test.rpc.url',
      egressProvider: 'beam',
    })
    const { displayUploadResults } = await import('../../common/upload-flow.js')
    expect(vi.mocked(displayUploadResults)).toHaveBeenCalledWith(
      expect.anything(),
      'Import',
      expect.anything(),
      expect.anything(),
      expect.objectContaining({
        filbeamUrl: expect.stringMatching(/^https:\/\/0x[0-9a-fA-F]+\.calibration\.filbeam\.io\/.+$/),
      })
    )
  })

  it('omits egress arg to displayUploadResults when withCDN is false', async () => {
    const carPath = join(testDir, 'no-egress.car')
    await createTestCarFile(carPath, [], [{ content: 'no egress content' }])
    await runCarImport({
      filePath: carPath,
      privateKey: testPrivateKey,
      rpcUrl: 'wss://test.rpc.url',
      egressProvider: 'none',
    })
    const { displayUploadResults } = await import('../../common/upload-flow.js')
    const calls = vi.mocked(displayUploadResults).mock.calls
    const last = calls[calls.length - 1]
    expect(last?.[4]).toBeUndefined()
  })

  it('omits egress arg when chain.filbeam is null (devnet)', async () => {
    const { initializeSynapse } = await import('../../core/synapse/index.js')
    vi.mocked(initializeSynapse).mockImplementationOnce(async (config: any) => {
      if (config.privateKey == null) throw new Error('auth required')
      return {
        chain: { name: 'devnet', id: 31337, filbeam: null },
        client: { account: { address: '0x1234567890123456789012345678901234567890' } },
        storage: { upload: vi.fn(), findDataSets: mockFindDataSets },
      } as any
    })
    const carPath = join(testDir, 'devnet-egress.car')
    await createTestCarFile(carPath, [], [{ content: 'devnet egress content' }])
    await runCarImport({
      filePath: carPath,
      privateKey: testPrivateKey,
      rpcUrl: 'wss://test.rpc.url',
      egressProvider: 'beam',
    })
    const { displayUploadResults } = await import('../../common/upload-flow.js')
    const calls = vi.mocked(displayUploadResults).mock.calls
    const last = calls[calls.length - 1]
    expect(last?.[4]).toBeUndefined()
  })
})

describe('runCarImportFromCli egress glue', () => {
  const testDir = './test-import-cli-egress-cars'
  const testPrivateKey = '0x0000000000000000000000000000000000000000000000000000000000000001'

  beforeEach(async () => {
    await mkdir(testDir, { recursive: true })
    vi.clearAllMocks()
  })

  afterEach(async () => {
    try {
      await stat(testDir)
      await rm(testDir, { recursive: true, force: true })
    } catch {
      // Directory doesn't exist, nothing to clean up
    }
  })

  it('defaults to no egress (withCDN unset) when --egress-provider is omitted', async () => {
    const carPath = join(testDir, 'default-none.car')
    await createTestCarFile(carPath, [], [{ content: 'default none content' }])
    await runCarImportFromCli(carPath, { privateKey: testPrivateKey, rpcUrl: 'wss://test.rpc.url' })
    const { initializeSynapse } = await import('../../core/synapse/index.js')
    const calls = vi.mocked(initializeSynapse).mock.calls
    const lastConfig = calls[calls.length - 1]?.[0] as { withCDN?: boolean }
    expect(lastConfig.withCDN).toBeUndefined()
  })

  it('routes data set IDs from resolveUploadTargets to performUpload when no targeting is given', async () => {
    const carPath = join(testDir, 'default-reuse.car')
    await createTestCarFile(carPath, [], [{ content: 'default reuse content' }])
    const { resolveUploadTargets, performUpload } = await import('../../common/upload-flow.js')
    vi.mocked(resolveUploadTargets).mockResolvedValueOnce({ dataSetIds: [7n, 9n] })

    await runCarImportFromCli(carPath, { privateKey: testPrivateKey, rpcUrl: 'wss://test.rpc.url' })

    expect(vi.mocked(resolveUploadTargets)).toHaveBeenCalledWith(
      expect.anything(),
      expect.any(Object),
      expect.objectContaining({ withCDN: false })
    )
    expect(vi.mocked(performUpload)).toHaveBeenCalledWith(
      expect.anything(),
      expect.anything(),
      expect.anything(),
      expect.objectContaining({ dataSetIds: [7n, 9n], copies: 2 })
    )
  })

  it('opts in (withCDN: true) when --egress-provider beam is passed', async () => {
    const carPath = join(testDir, 'opt-in-beam.car')
    await createTestCarFile(carPath, [], [{ content: 'opt in beam content' }])
    await runCarImportFromCli(carPath, {
      privateKey: testPrivateKey,
      rpcUrl: 'wss://test.rpc.url',
      egressProvider: 'beam',
    })
    const { initializeSynapse } = await import('../../core/synapse/index.js')
    expect(vi.mocked(initializeSynapse)).toHaveBeenCalledWith(
      expect.objectContaining({ withCDN: true }),
      expect.anything()
    )
  })

  it('opts out (withCDN unset) when --egress-provider none is passed', async () => {
    const carPath = join(testDir, 'opt-out.car')
    await createTestCarFile(carPath, [], [{ content: 'opt out content' }])
    await runCarImportFromCli(carPath, {
      privateKey: testPrivateKey,
      rpcUrl: 'wss://test.rpc.url',
      egressProvider: 'none',
    })
    const { initializeSynapse } = await import('../../core/synapse/index.js')
    const calls = vi.mocked(initializeSynapse).mock.calls
    const lastConfig = calls[calls.length - 1]?.[0] as { withCDN?: boolean }
    expect(lastConfig.withCDN).toBeUndefined()
  })
})
