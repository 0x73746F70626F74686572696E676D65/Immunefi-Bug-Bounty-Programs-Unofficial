import { TerminateServiceError } from '@filoz/synapse-core/errors'
import { METADATA_KEYS } from '@filoz/synapse-sdk'
import pc from 'picocolors'
import { WaitForTransactionReceiptTimeoutError } from 'viem'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import type { DataSetSummary, PieceInfo } from '../../core/data-set/types.js'
import {
  runDataSetDetailsCommand,
  runDataSetListCommand,
  runDataSetPieceStatusCommand,
  runTerminateDataSetCommand,
} from '../../data-set/run.js'
import { log } from '../../utils/cli-logger.js'

const {
  displayDataSetListMock,
  displayDataSetsMock,
  displayPieceStatusesMock,
  spinnerMock,
  cancelMock,
  outroMock,
  mockGetPdpDataSets,
  mockGetProvider,
  mockGetPdpDataSet,
  mockTerminateService,
  mockWaitForTransactionReceipt,
  mockSynapseCreate,
  mockIsInteractive,
  mockConfirm,
  mockIsCancel,
  mockRunPieceStatusPager,
  state,
} = vi.hoisted(() => {
  const displayDataSetListMock = vi.fn()
  const displayDataSetsMock = vi.fn()
  const displayPieceStatusesMock = vi.fn()
  const cancelMock = vi.fn()
  const outroMock = vi.fn()
  const spinnerMock = {
    start: vi.fn(),
    stop: vi.fn(),
    message: vi.fn(),
    clear: vi.fn(),
  }
  const mockGetPdpDataSets = vi.fn()
  const mockGetProvider = vi.fn()
  const mockGetPdpDataSet = vi.fn()
  const mockTerminateService = vi.fn()
  const mockWaitForTransactionReceipt = vi.fn()
  const mockIsInteractive = vi.fn(() => false)
  const mockConfirm = vi.fn(async () => true)
  const mockIsCancel = vi.fn(() => false)
  const mockRunPieceStatusPager = vi.fn()
  const state = {
    pieceList: [] as Array<{ pieceId: bigint; pieceCid: string }>,
  }

  const mockCreateContext = vi.fn(async () => ({
    dataSetId: 158n,
    serviceProvider: '0xservice',
    provider: {
      id: 2n,
      name: 'Test Provider',
      serviceProvider: '0xservice',
      pdp: { serviceURL: 'https://provider.example.com' },
    },
    dataSetMetadata: {
      [METADATA_KEYS.WITH_IPFS_INDEXING]: '',
      source: 'filecoin-pin',
      note: 'demo',
    },
    async *getPieces() {
      for (const piece of state.pieceList) {
        yield {
          pieceId: piece.pieceId,
          pieceCid: {
            toString: () => piece.pieceCid,
          },
        }
      }
    },
    getScheduledRemovals: vi.fn(async () => []),
  }))

  const mockSynapseCreate = vi.fn((config: any) => {
    // Validate auth like the real initializeSynapse does
    const hasStandardAuth = config.privateKey != null
    const hasSessionKeyAuth = config.walletAddress != null && config.sessionKey != null
    const hasViewOnlyAuth = config.readOnly === true && config.walletAddress != null

    if (!hasStandardAuth && !hasSessionKeyAuth && !hasViewOnlyAuth) {
      throw new Error(
        'Authentication required: provide either privateKey, walletAddress + sessionKey, view-address, or signer'
      )
    }

    return {
      chain: { id: 314159, name: 'calibration' },
      client: {
        account: hasViewOnlyAuth ? config.walletAddress : { address: '0xtest-address' },
        waitForTransactionReceipt: mockWaitForTransactionReceipt,
      },
      sessionClient: hasSessionKeyAuth ? {} : undefined,
      storage: {
        createContext: mockCreateContext,
        terminateService: mockTerminateService,
      },
      providers: {
        getProvider: mockGetProvider,
      },
    }
  })

  return {
    displayDataSetListMock,
    displayDataSetsMock,
    displayPieceStatusesMock,
    cancelMock,
    outroMock,
    spinnerMock,
    mockGetPdpDataSets,
    mockGetProvider,
    mockGetPdpDataSet,
    mockTerminateService,
    mockWaitForTransactionReceipt,
    mockSynapseCreate,
    mockCreateContext,
    mockIsInteractive,
    mockConfirm,
    mockIsCancel,
    mockRunPieceStatusPager,
    state,
  }
})

vi.mock('../../data-set/display.js', () => ({
  displayDataSetList: displayDataSetListMock,
  displayDataSets: displayDataSetsMock,
  displayPieceStatuses: displayPieceStatusesMock,
}))

vi.mock('../../data-set/piece-status-pager.js', () => ({
  runPieceStatusPager: mockRunPieceStatusPager,
}))

vi.mock('../../core/synapse/index.js', () => ({
  initializeSynapse: mockSynapseCreate,
  getClientAddress: () => '0xtest',
}))

vi.mock('../../utils/cli-helpers.js', () => ({
  intro: vi.fn(),
  outro: outroMock,
  cancel: cancelMock,
  createSpinner: () => spinnerMock,
  isInteractive: mockIsInteractive,
}))

vi.mock('../../utils/cli-logger.js', () => ({
  log: {
    line: vi.fn(),
    indent: vi.fn(),
    flush: vi.fn(),
    spinnerSection: vi.fn(),
  },
}))

vi.mock('@clack/prompts', () => ({
  confirm: mockConfirm,
  isCancel: mockIsCancel,
}))

// Use shared SDK mock with custom extensions for dataset command testing
vi.mock('@filoz/synapse-sdk', async () => {
  const sharedMock = await import('../mocks/synapse-sdk.js')
  return {
    ...sharedMock,
  }
})

vi.mock('@filoz/synapse-core/warm-storage', () => ({
  getPdpDataSet: mockGetPdpDataSet,
  getPdpDataSets: mockGetPdpDataSets,
}))

vi.mock('@filoz/synapse-core/pdp-verifier', () => ({
  getActivePiecesByCursor: vi.fn(async () => ({
    items: state.pieceList.map((p) => ({ id: p.pieceId, cid: { toString: () => p.pieceCid } })),
  })),
  getScheduledRemovals: vi.fn(async () => [] as readonly bigint[]),
}))

vi.mock('@filoz/synapse-core/sp', () => ({
  getDataSet: vi.fn(async () => ({
    id: 158n,
    nextChallengeEpoch: 100,
    pieces: state.pieceList.map((p: any) => ({
      pieceId: p.pieceId,
      pieceCid: { toString: () => p.pieceCid },
      subPieceCid: { toString: () => p.pieceCid },
      subPieceOffset: 0,
    })),
  })),
}))

// Mock piece size calculation
vi.mock('@filoz/synapse-core/piece', () => ({
  MAX_UPLOAD_SIZE: 1048576,
  from: vi.fn(() => ({
    // Return a realistic piece size (1 MiB = 1048576 bytes)
    size: 1048576,
  })),
}))

type EnhancedDataSetFixture = Record<string, unknown> & {
  pdpVerifierDataSetId: bigint
  isLive?: boolean
  isManaged?: boolean
  withCDN?: boolean
  /** bigint to mirror synapse-sdk's DataSetInfo; number literals here misrepresent SDK data. */
  pdpEndEpoch?: bigint
  /** bigint to mirror synapse-sdk's DataSetInfo. */
  commissionBps?: bigint
  metadata: Record<string, string>
  payer: string
}

function toPdpDataSet(summary: EnhancedDataSetFixture, providerFixture: Record<string, unknown>) {
  return {
    pdpRailId: summary.pdpRailId,
    cacheMissRailId: summary.cacheMissRailId,
    cdnRailId: summary.cdnRailId,
    payer: summary.payer,
    payee: summary.payee,
    serviceProvider: summary.serviceProvider,
    commissionBps: summary.commissionBps,
    clientDataSetId: summary.clientDataSetId,
    pdpEndEpoch: summary.pdpEndEpoch,
    providerId: summary.providerId,
    dataSetId: summary.pdpVerifierDataSetId,
    live: summary.isLive ?? true,
    managed: summary.isManaged ?? true,
    cdn: summary.withCDN ?? false,
    metadata: summary.metadata,
    provider: providerFixture,
    hasActivePieces: false,
  }
}

function toPdpDataSetsPage(dataSets: EnhancedDataSetFixture[], providerFixture: Record<string, unknown>) {
  return { items: dataSets.map((ds) => toPdpDataSet(ds, providerFixture)) }
}

describe('runDataSetCommand', () => {
  const summaryDataSet = {
    pdpVerifierDataSetId: 158n,
    providerId: 2n,
    isManaged: true,
    withCDN: false,
    currentPieceCount: 3,
    nextPieceId: 3n,
    clientDataSetId: 1n,
    pdpRailId: 327n,
    cdnRailId: 0n,
    cacheMissRailId: 0n,
    payer: '0x123',
    payee: '0x456',
    serviceProvider: '0xservice',
    commissionBps: 100n,
    pdpEndEpoch: 0n,
    cdnEndEpoch: 0,
    metadata: {
      [METADATA_KEYS.WITH_IPFS_INDEXING]: '',
      source: 'filecoin-pin',
      note: 'demo',
    },
  }

  const provider = {
    id: 2n,
    name: 'Test Provider',
    serviceProvider: '0xservice',
    description: 'demo provider',
    payee: '0x456',
    active: true,
    pdp: {
      serviceURL: 'https://pdp.local',
    },
  }

  beforeEach(() => {
    vi.clearAllMocks()
    state.pieceList = []
    mockGetPdpDataSets.mockResolvedValue(toPdpDataSetsPage([summaryDataSet], provider))
    mockGetProvider.mockResolvedValue(provider)
    mockGetPdpDataSet.mockResolvedValue(toPdpDataSet(summaryDataSet, provider))
  })

  afterEach(() => {
    delete process.env.PRIVATE_KEY
    process.exitCode = 0
  })

  it('lists datasets without fetching details when no id is provided', async () => {
    await runDataSetListCommand({
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
    })

    expect(displayDataSetListMock).toHaveBeenCalledTimes(1)
    expect(displayDataSetsMock).not.toHaveBeenCalled()
    const firstCall = displayDataSetListMock.mock.calls[0]
    expect(firstCall).toBeDefined()
    const [context] = firstCall as [DataSetSummary[]]
    expect(context).toHaveLength(1)
    const summary = context[0]
    expect(summary).toBeDefined()
    expect(summary?.dataSetId).toBe(158n)
    expect(summary?.createdWithFilecoinPin).toBe(true)
  })

  it('filters datasets by metadata entries', async () => {
    await runDataSetListCommand({
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
      dataSetMetadata: { note: 'demo' },
    })

    const [dataSets] = displayDataSetListMock.mock.calls[0] as [DataSetSummary[]]
    expect(dataSets).toHaveLength(1)
    expect(dataSets[0]?.dataSetId).toBe(158n)
  })

  it('excludes datasets that do not match metadata filters', async () => {
    await runDataSetListCommand({
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
      dataSetMetadata: { note: 'unknown' },
    })

    const [dataSets] = displayDataSetListMock.mock.calls[0] as [DataSetSummary[]]
    expect(dataSets).toHaveLength(0)
  })

  it('includes non-filecoin-pin datasets when explicit metadata filter is passed', async () => {
    const migrationDataSet = {
      ...summaryDataSet,
      pdpVerifierDataSetId: 13260n,
      metadata: {
        [METADATA_KEYS.WITH_IPFS_INDEXING]: '',
        source: 'storacha-migration',
        'space-did': 'did:key:z6Mk',
      },
    }
    mockGetPdpDataSets.mockResolvedValueOnce(toPdpDataSetsPage([migrationDataSet], provider))

    await runDataSetListCommand({
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
      dataSetMetadata: { source: 'storacha-migration' },
    })

    const [dataSets] = displayDataSetListMock.mock.calls[0] as [DataSetSummary[]]
    expect(dataSets).toHaveLength(1)
    expect(dataSets[0]?.dataSetId).toBe(13260n)
    expect(dataSets[0]?.createdWithFilecoinPin).toBe(false)
  })

  it('passes a filter-aware empty message when explicit filter matches nothing', async () => {
    await runDataSetListCommand({
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
      dataSetMetadata: { source: 'nonexistent' },
    })

    const call = displayDataSetListMock.mock.calls[0] as [DataSetSummary[], string, string, string | undefined]
    expect(call[0]).toHaveLength(0)
    expect(call[3]).toMatch(/matched the requested filter/i)
  })

  it('uses neutral empty message when --all is set and no datasets exist', async () => {
    mockGetPdpDataSets.mockResolvedValueOnce({ items: [] })

    await runDataSetListCommand({
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
      all: true,
    })

    const call = displayDataSetListMock.mock.calls[0] as [DataSetSummary[], string, string, string | undefined]
    expect(call[0]).toHaveLength(0)
    expect(call[3]).toBe('No data sets were found for this account.')
  })

  it('hints at --all when default filter hides existing non-filecoin-pin datasets', async () => {
    const migrationDataSet = {
      ...summaryDataSet,
      pdpVerifierDataSetId: 13260n,
      metadata: {
        [METADATA_KEYS.WITH_IPFS_INDEXING]: '',
        source: 'storacha-migration',
      },
    }
    mockGetPdpDataSets.mockResolvedValueOnce(toPdpDataSetsPage([migrationDataSet], provider))

    await runDataSetListCommand({
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
    })

    const call = displayDataSetListMock.mock.calls[0] as [DataSetSummary[], string, string, string | undefined]
    expect(call[0]).toHaveLength(0)
    expect(call[3]).toMatch(/--all/)
  })

  it('loads detailed information without fetching pieces when a dataset id is provided', async () => {
    state.pieceList = [{ pieceId: 0n, pieceCid: 'bafkpiece0' }]

    await runDataSetDetailsCommand(158, {
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
    })

    expect(displayDataSetsMock).toHaveBeenCalledTimes(1)
    expect(displayDataSetListMock).not.toHaveBeenCalled()
    const statusCall = displayDataSetsMock.mock.calls[0]
    expect(statusCall).toBeDefined()
    const [dataSets] = statusCall as [DataSetSummary[]]
    expect(dataSets).toHaveLength(1)
    const dataSet = dataSets[0]
    expect(dataSet).toBeDefined()
    expect(dataSet?.dataSetId).toBe(158n)
    expect(dataSet?.pieces).toBeUndefined()
    expect(dataSet?.totalSizeBytes).toBeUndefined()
  })

  it('does not enumerate the whole account when loading a single dataset', async () => {
    state.pieceList = [{ pieceId: 0n, pieceCid: 'bafkpiece0' }]

    await runDataSetDetailsCommand(158, {
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
    })

    expect(mockGetPdpDataSet).toHaveBeenCalledWith(expect.anything(), { dataSetId: 158n })
    expect(mockGetPdpDataSets).not.toHaveBeenCalled()
  })

  it('assembles datasets across multiple pages instead of fetching them all in one unbatched call', async () => {
    const secondPageDataSet = { ...summaryDataSet, pdpVerifierDataSetId: 999n }
    mockGetPdpDataSets
      .mockResolvedValueOnce({ items: [toPdpDataSet(summaryDataSet, provider)], nextCursor: 200n })
      .mockResolvedValueOnce({ items: [toPdpDataSet(secondPageDataSet, provider)] })

    await runDataSetListCommand({
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
      all: true,
    })

    expect(mockGetPdpDataSets).toHaveBeenCalledTimes(2)
    expect(mockGetPdpDataSets).toHaveBeenNthCalledWith(1, expect.anything(), { address: '0xtest', cursor: 0n })
    expect(mockGetPdpDataSets).toHaveBeenNthCalledWith(2, expect.anything(), { address: '0xtest', cursor: 200n })
    const [dataSets] = displayDataSetListMock.mock.calls[0] as [DataSetSummary[]]
    expect(dataSets.map((ds) => ds.dataSetId)).toEqual([158n, 999n])
  })

  it('exits when no private key is provided', async () => {
    await expect(runDataSetListCommand({ rpcUrl: 'wss://sample' })).rejects.toThrow('Authentication required')

    // Should call cancel with failure message
    expect(cancelMock).toHaveBeenCalledWith('Listing failed')

    // Should stop spinner with error message
    expect(spinnerMock.stop).toHaveBeenCalledWith(expect.stringContaining('Failed to list data sets'))

    // Should not call display function since it failed early
    expect(displayDataSetListMock).not.toHaveBeenCalled()
    expect(displayDataSetsMock).not.toHaveBeenCalled()
  })
})

describe('runTerminateDataSetCommand', () => {
  const terminatableDataSet = {
    pdpVerifierDataSetId: 158n,
    providerId: 2n,
    isManaged: true,
    withCDN: false,
    isLive: true,
    currentPieceCount: 3,
    nextPieceId: 3n,
    clientDataSetId: 1n,
    pdpRailId: 327n,
    cdnRailId: 0n,
    cacheMissRailId: 0n,
    payer: '0xtest',
    payee: '0x456',
    serviceProvider: '0xservice',
    commissionBps: 100n,
    pdpEndEpoch: 0n,
    cdnEndEpoch: 0,
    metadata: {
      [METADATA_KEYS.WITH_IPFS_INDEXING]: '',
      source: 'filecoin-pin',
      note: 'demo',
    },
  }

  const provider = {
    id: 2n,
    name: 'Test Provider',
    serviceProvider: '0xservice',
    description: 'demo provider',
    payee: '0x456',
    active: true,
    pdp: {
      serviceURL: 'https://pdp.local',
    },
  }

  beforeEach(() => {
    vi.clearAllMocks()
    state.pieceList = []
    mockGetProvider.mockResolvedValue(provider)
    mockGetPdpDataSet.mockResolvedValue(toPdpDataSet(terminatableDataSet, provider))
    mockTerminateService.mockResolvedValue({ txHash: '0xtxhash123', dataSetId: 158n, endEpoch: 0n })
    mockWaitForTransactionReceipt.mockResolvedValue({ status: 'success' })
  })

  afterEach(() => {
    delete process.env.PRIVATE_KEY
    process.exitCode = 0
  })

  it('terminates a dataset without waiting', async () => {
    state.pieceList = [{ pieceId: 0n, pieceCid: 'bafkpiece0' }]

    await runTerminateDataSetCommand(158, {
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
    })

    expect(mockTerminateService).toHaveBeenCalledWith({ dataSetId: 158n, skipProvider: true })
    expect(mockWaitForTransactionReceipt).not.toHaveBeenCalled()
    expect(displayDataSetsMock).toHaveBeenCalledTimes(2)
    expect(displayDataSetListMock).not.toHaveBeenCalled()
  })

  it('exits with code 2 when the user cancels the confirmation prompt', async () => {
    mockIsInteractive.mockReturnValueOnce(true)
    mockConfirm.mockResolvedValueOnce(false)

    await runTerminateDataSetCommand(158, {
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
    })

    expect(mockTerminateService).not.toHaveBeenCalled()
    expect(cancelMock).toHaveBeenCalledWith('Termination cancelled')
    expect(process.exitCode).toBe(2)
  })

  it('terminates a dataset and waits for confirmation', async () => {
    state.pieceList = [{ pieceId: 0n, pieceCid: 'bafkpiece0' }]
    mockTerminateService.mockResolvedValue({ txHash: '0xtxhash123', dataSetId: 158n, endEpoch: 5000n })

    await runTerminateDataSetCommand(158, {
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
      wait: true,
    })

    expect(mockTerminateService).toHaveBeenCalledWith({ dataSetId: 158n, skipProvider: true })
    expect(mockWaitForTransactionReceipt).toHaveBeenCalledWith({ hash: '0xtxhash123' })
    // The final status comes from the termination's own end epoch, not a second chain read.
    expect(mockGetPdpDataSet).toHaveBeenCalledTimes(1)
    expect(displayDataSetsMock).toHaveBeenLastCalledWith(
      [expect.objectContaining({ isLive: false, pdpEndEpoch: 5000n })],
      expect.anything(),
      expect.anything()
    )
    expect(displayDataSetListMock).not.toHaveBeenCalled()
  })

  it('exits with code 2 when the confirmation wait times out', async () => {
    mockWaitForTransactionReceipt.mockRejectedValueOnce(
      new WaitForTransactionReceiptTimeoutError({ hash: '0xtxhash123' })
    )

    await runTerminateDataSetCommand(158, {
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
      wait: true,
    })

    expect(mockTerminateService).toHaveBeenCalledWith({ dataSetId: 158n, skipProvider: true })
    expect(process.exitCode).toBe(2)
  })

  it('spends a session key grant through the provider, never the owner-only direct call', async () => {
    mockTerminateService.mockResolvedValue({ dataSetId: 158n, endEpoch: 42n, confirmedTxHash: '0xprovider' })

    await runTerminateDataSetCommand(158, {
      walletAddress: '0xtest',
      sessionKey: `0x${'ab'.repeat(32)}`,
      rpcUrl: 'wss://sample',
    })

    expect(mockTerminateService).toHaveBeenCalledWith({ dataSetId: 158n })
    // The provider returns confirmed, so this side never waits on a receipt.
    expect(mockWaitForTransactionReceipt).not.toHaveBeenCalled()
    expect(process.exitCode).toBe(0)
  })

  it('reports a provider termination that names no transaction', async () => {
    mockTerminateService.mockResolvedValue({ dataSetId: 158n, endEpoch: 42n })

    await runTerminateDataSetCommand(158, {
      walletAddress: '0xtest',
      sessionKey: `0x${'ab'.repeat(32)}`,
      rpcUrl: 'wss://sample',
    })

    // Confirmed, with no hash appended and no "still pending" hedge.
    expect(spinnerMock.stop).toHaveBeenCalledWith(expect.stringContaining('termination confirmed'))
    expect(spinnerMock.stop).not.toHaveBeenCalledWith(expect.stringContaining('undefined'))
    expect(process.exitCode).toBe(0)
  })

  it('closes a provider termination as complete, not submitted', async () => {
    mockTerminateService.mockResolvedValue({ dataSetId: 158n, endEpoch: 42n, confirmedTxHash: '0xprovider' })

    // No --wait: the provider confirmed it, so the close must not read as pending.
    await runTerminateDataSetCommand(158, {
      walletAddress: '0xtest',
      sessionKey: `0x${'ab'.repeat(32)}`,
      rpcUrl: 'wss://sample',
    })

    expect(outroMock).toHaveBeenCalledWith('Data set termination complete')
    expect(log.line).toHaveBeenCalledWith(pc.bold('Final Data Set Status:'))
  })

  it('names the owner wallet when the provider refuses a session key', async () => {
    // What a provider that no longer holds the data set actually returns.
    mockTerminateService.mockRejectedValue(new TerminateServiceError('Data set not found'))

    await expect(
      runTerminateDataSetCommand(158, {
        walletAddress: '0xtest',
        sessionKey: `0x${'ab'.repeat(32)}`,
        rpcUrl: 'wss://sample',
      })
    ).rejects.toThrow('--private-key')
  })

  it('names the owner wallet for a lockup shortfall, which the SDK reports as advice to skip the provider', async () => {
    mockTerminateService.mockRejectedValue(
      new Error(
        'Synapse terminateService failed: Account cannot settle its lockup in full; terminate on-chain (skipProvider: true)'
      )
    )

    await expect(
      runTerminateDataSetCommand(158, {
        walletAddress: '0xtest',
        sessionKey: `0x${'ab'.repeat(32)}`,
        rpcUrl: 'wss://sample',
      })
    ).rejects.toThrow('--private-key')
  })

  it('keeps a network error as it is: the owner wallet is not the answer to a timeout', async () => {
    mockTerminateService.mockRejectedValue(new Error('fetch failed'))

    await expect(
      runTerminateDataSetCommand(158, {
        walletAddress: '0xtest',
        sessionKey: `0x${'ab'.repeat(32)}`,
        rpcUrl: 'wss://sample',
      })
    ).rejects.toThrow(/^fetch failed$/)
  })

  it('leaves a private-key failure alone, since that path is already the owner wallet', async () => {
    mockTerminateService.mockRejectedValue(new Error('reverted'))

    await expect(runTerminateDataSetCommand(158, { privateKey: 'test-key', rpcUrl: 'wss://sample' })).rejects.toThrow(
      /^reverted$/
    )
  })

  it('rejects termination for read-only accounts', async () => {
    await expect(
      runTerminateDataSetCommand(158, {
        viewAddress: '0xtest',
        rpcUrl: 'wss://sample',
      })
    ).rejects.toThrow('Signing required for termination')

    expect(cancelMock).toHaveBeenCalledWith('Termination failed')
    expect(mockTerminateService).not.toHaveBeenCalled()
  })

  it('rejects when dataset is not owned by the caller', async () => {
    const otherOwnerDataSet = { ...terminatableDataSet, payer: '0xother' }
    mockGetPdpDataSet.mockResolvedValue(toPdpDataSet(otherOwnerDataSet, provider))

    await expect(
      runTerminateDataSetCommand(158, {
        privateKey: 'test-key',
        rpcUrl: 'wss://sample',
      })
    ).rejects.toThrow('not owned by address')

    expect(cancelMock).toHaveBeenCalledWith('Termination failed')
    expect(mockTerminateService).not.toHaveBeenCalled()
  })

  it('reports already-terminated datasets without error', async () => {
    const terminatedDataSet = { ...terminatableDataSet, pdpEndEpoch: 5000n }
    mockGetPdpDataSet.mockResolvedValue(toPdpDataSet(terminatedDataSet, provider))

    await runTerminateDataSetCommand(158, {
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
    })

    expect(mockTerminateService).not.toHaveBeenCalled()
    expect(cancelMock).not.toHaveBeenCalled()
  })

  it('rejects invalid dataset IDs', async () => {
    await expect(
      runTerminateDataSetCommand(0, {
        privateKey: 'test-key',
        rpcUrl: 'wss://sample',
      })
    ).rejects.toThrow('Invalid data set ID')

    expect(cancelMock).toHaveBeenCalledWith('Termination failed')
  })
})

describe('runDataSetPieceStatusCommand', () => {
  const summaryDataSet = {
    pdpVerifierDataSetId: 158n,
    providerId: 2n,
    isManaged: true,
    withCDN: false,
    clientDataSetId: 1n,
    pdpRailId: 327n,
    cdnRailId: 0n,
    cacheMissRailId: 0n,
    payer: '0x123',
    payee: '0x456',
    serviceProvider: '0xservice',
    commissionBps: 100n,
    pdpEndEpoch: 0n,
    cdnEndEpoch: 0,
    metadata: {
      [METADATA_KEYS.WITH_IPFS_INDEXING]: '',
      source: 'filecoin-pin',
    },
  }

  const provider = {
    id: 2n,
    name: 'Test Provider',
    serviceProvider: '0xservice',
    description: 'demo provider',
    payee: '0x456',
    active: true,
    pdp: { serviceURL: 'https://pdp.local' },
  }

  beforeEach(() => {
    vi.clearAllMocks()
    state.pieceList = [
      { pieceId: 0n, pieceCid: 'bafkpiece0' },
      { pieceId: 1n, pieceCid: 'bafkpiece1' },
    ]
    mockGetProvider.mockResolvedValue(provider)
    mockGetPdpDataSet.mockResolvedValue(toPdpDataSet(summaryDataSet, provider))
  })

  afterEach(() => {
    delete process.env.PRIVATE_KEY
    process.exitCode = 0
  })

  it('displays all pieces when no pieceCid is provided', async () => {
    await runDataSetPieceStatusCommand(158, undefined, {
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
    })

    expect(displayPieceStatusesMock).toHaveBeenCalledTimes(1)
    const [pieces, dataSetId] = displayPieceStatusesMock.mock.calls[0] as [PieceInfo[], number]
    expect(dataSetId).toBe(158)
    expect(pieces).toHaveLength(2)
    expect(pieces.map((p) => p.pieceCid)).toEqual(['bafkpiece0', 'bafkpiece1'])
  })

  it('filters to a single piece when a pieceCid is provided', async () => {
    await runDataSetPieceStatusCommand(158, 'bafkpiece1', {
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
    })

    const [pieces] = displayPieceStatusesMock.mock.calls[0] as [PieceInfo[]]
    expect(pieces).toHaveLength(1)
    expect(pieces[0]?.pieceCid).toBe('bafkpiece1')
  })

  it('passes an empty list and message when the pieceCid is not found', async () => {
    await runDataSetPieceStatusCommand(158, 'bafkmissing', {
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
    })

    const call = displayPieceStatusesMock.mock.calls[0] as [PieceInfo[], number, string, string, string | undefined]
    expect(call[0]).toHaveLength(0)
    expect(call[4]).toMatch(/No piece matching bafkmissing/)
  })

  it('uses the interactive pager instead of the full dump when interactive and no pieceCid is given', async () => {
    mockIsInteractive.mockReturnValue(true)

    await runDataSetPieceStatusCommand(158, undefined, {
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
    })

    expect(displayPieceStatusesMock).not.toHaveBeenCalled()
    expect(mockRunPieceStatusPager).toHaveBeenCalledTimes(1)
    const [, dataSet] = mockRunPieceStatusPager.mock.calls[0] as [unknown, DataSetSummary]
    expect(dataSet.dataSetId).toBe(158n)
    // includePieces: false - the pager fetches pieces itself, lazily.
    expect(dataSet.pieces).toBeUndefined()
  })

  it('keeps the full-fetch/filter path when a pieceCid is given even while interactive', async () => {
    mockIsInteractive.mockReturnValue(true)

    await runDataSetPieceStatusCommand(158, 'bafkpiece1', {
      privateKey: 'test-key',
      rpcUrl: 'wss://sample',
    })

    expect(mockRunPieceStatusPager).not.toHaveBeenCalled()
    expect(displayPieceStatusesMock).toHaveBeenCalledTimes(1)
  })

  it('rejects invalid dataset IDs', async () => {
    await expect(
      runDataSetPieceStatusCommand(0, undefined, {
        privateKey: 'test-key',
        rpcUrl: 'wss://sample',
      })
    ).rejects.toThrow('Invalid data set ID')

    expect(cancelMock).toHaveBeenCalledWith('Piece status lookup failed')
    expect(displayPieceStatusesMock).not.toHaveBeenCalled()
  })
})
