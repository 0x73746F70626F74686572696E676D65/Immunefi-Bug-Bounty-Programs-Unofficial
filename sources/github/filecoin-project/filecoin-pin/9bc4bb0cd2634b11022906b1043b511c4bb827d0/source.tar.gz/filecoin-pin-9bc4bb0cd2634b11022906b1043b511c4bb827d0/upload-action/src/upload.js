import { access } from 'node:fs/promises'
import { calibration, initializeSynapse, mainnet } from 'filecoin-pin/core/synapse'
import pc from 'picocolors'
import pino from 'pino'
import { commentOnPR } from './comments/comment.js'
import { handlePayments, uploadCarToFilecoin } from './filecoin.js'
import { ensurePullRequestContext, updateCheck } from './github.js'
import { parseInputs } from './inputs.js'
import { writeOutputs, writeSummary } from './outputs.js'

/**
 * @typedef {import('./types.js').CombinedContext} CombinedContext
 * @typedef {import('./types.js').ParsedInputs} ParsedInputs
 * @typedef {import('./types.js').UploadResult} UploadResult
 * @typedef {import('./types.js').PaymentStatus} PaymentStatus
 * @typedef {import('./types.js').SimplifiedPaymentStatus} SimplifiedPaymentStatus
 * @typedef {import('./types.js').UploadConfig} UploadConfig
 */

/**
 * Run upload phase: Upload to Filecoin using context data from build phase
 * @param {Partial<CombinedContext>} [buildContext]
 */
export async function runUpload(buildContext = {}) {
  const logger = pino({ level: process.env.LOG_LEVEL || 'info' })

  console.log('━━━ Preparing for Upload ━━━')

  await updateCheck({
    title: 'Initializing upload workflow',
    summary: 'Preparing to upload to Filecoin...',
  })

  /** @type {Partial<CombinedContext>} */
  const context = { ...buildContext }

  const resolvedPr = await ensurePullRequestContext(context.pr)
  if (resolvedPr) {
    context.pr = resolvedPr
  }

  console.log('[context-debug] Loaded context from build phase:', context)

  // Check if this was a fork PR that was blocked
  // this gate is only safe because we share a process with runBuild; do not rehydrate uploadStatus from an external source
  if (context.uploadStatus === 'fork-pr-blocked') {
    console.log('━━━ Fork PR Upload Blocked ━━━')
    console.log('::notice::Fork PR detected - content built but not uploaded to Filecoin, will comment on PR')

    const rootCid = context.ipfsRootCid || ''

    await updateCheck({
      title: 'Fork PR detected',
      summary: 'Fork PR support is currently disabled for security reasons',
      text: 'CAR file built successfully but upload blocked. See PR comment for details.',
    })

    // Write outputs indicating fork PR was blocked
    await writeOutputs({
      ipfsRootCid: rootCid,
      dataSetId: '',
      pieceCid: '',
      providerId: '',
      providerName: '',
      carPath: context.carPath || '',
      uploadStatus: 'fork-pr-blocked',
    })

    await writeSummary(context, 'Fork PR blocked')

    // Comment on PR with the actual IPFS Root CID
    await commentOnPR({ ...context, uploadStatus: 'fork-pr-blocked' })

    console.log('✓ Fork PR blocked - PR comment posted explaining the limitation')
    return context
  }

  // Parse inputs only after the entry point has accepted the event provenance.
  /** @type {ParsedInputs} */
  const inputs = parseInputs('upload')
  const {
    walletPrivateKey,
    contentPath,
    network: inputNetwork,
    minStorageDays,
    filecoinPayBalanceLimit,
    withCDN,
    providerIds,
    dataSetIds,
    dryRun,
  } = inputs

  context.contentPath = contentPath
  context.dryRun = dryRun

  if (!context.ipfsRootCid) {
    throw new Error('No IPFS Root CID found in context. Build phase may have failed.')
  }

  const rootCid = context.ipfsRootCid
  console.log(`Root CID from context: ${rootCid}`)

  // Get CAR file path from context
  const carPath = context.carPath
  if (!carPath) {
    throw new Error('No CAR file path found in context. Build phase may have failed.')
  }

  // Verify CAR file exists
  try {
    await access(carPath)
  } catch {
    throw new Error(`CAR file not found at ${carPath}`)
  }

  /**
   * @type {Partial<UploadResult>}
   * This is a simple trick to get each of these variables defined easily without using a separate let statement and jsdoc for each one.
   * We already have them in the type we want.
   */
  let { pieceCid, pieceId, dataSetId, provider, previewUrl, network, ipniValidated } = {}
  /** @type {SimplifiedPaymentStatus} */
  let paymentStatus

  if (dryRun) {
    pieceCid = context.pieceCid || 'dry-run'
    pieceId = context.pieceId || 'dry-run'
    dataSetId = context.dataSetId || 'dry-run'
    provider = context.provider || {
      id: 'dry-run',
      name: 'Dry Run Mode',
    }
    previewUrl = context.previewUrl || 'https://example.com/ipfs/dry-run'
    network = context.network || 'dry-run'
    paymentStatus = {
      filecoinPayBalance: '0',
      walletUsdfcBalance: '0',
      storageCovered: 'Unknown',
      storageRunway: 'Unknown',
      depositedThisRun: '0',
      ...context.paymentStatus,
    }
  } else {
    if (!walletPrivateKey) {
      throw new Error('walletPrivateKey is required for upload phase')
    }

    const chain = inputNetwork === 'mainnet' ? mainnet : calibration
    const synapse = await initializeSynapse(
      {
        privateKey: /** @type {`0x${string}`} */ (walletPrivateKey),
        chain,
        ...(withCDN && { withCDN }),
      },
      logger
    )

    console.log('\n━━━ Funding Phase: Checking Filecoin Pay Account ━━━')

    await updateCheck({
      title: 'Checking Filecoin Pay balance',
      summary: 'Verifying account balance and calculating required deposits...',
    })

    paymentStatus = await handlePayments(
      synapse,
      {
        minStorageDays,
        filecoinPayBalanceLimit,
        pieceSizeBytes: context.carSize,
        withCDN,
        providerIds,
        dataSetIds,
      },
      logger
    )

    console.log('✓ Funding phase complete')

    console.log('\n━━━ Upload Phase: Uploading to Filecoin ━━━')

    await updateCheck({
      title: 'Uploading to storage provider',
      summary: `Uploading CAR file to Filecoin storage provider...`,
    })

    /** @type {UploadConfig} */
    const uploadOptions = { withCDN, providerIds, dataSetIds }

    const uploadResult = await uploadCarToFilecoin(synapse, carPath, rootCid, uploadOptions, logger)
    pieceCid = uploadResult.pieceCid
    pieceId = uploadResult.pieceId
    dataSetId = uploadResult.dataSetId
    provider = uploadResult.provider
    previewUrl = uploadResult.previewUrl
    network = uploadResult.network
    ipniValidated = uploadResult.ipniValidated
  }

  const uploadStatus = dryRun ? 'dry-run' : 'uploaded'

  const providerInfo = provider || { id: '', name: '' }

  Object.assign(context, {
    pieceCid,
    pieceId,
    dataSetId,
    provider: providerInfo,
    previewUrl,
    network: network || inputNetwork,
    uploadStatus,
    paymentStatus,
    dryRun,
    ipniValidated,
  })

  provider = providerInfo

  // Write outputs
  await writeOutputs({
    ipfsRootCid: rootCid,
    dataSetId: dataSetId,
    pieceCid: pieceCid,
    providerId: providerInfo.id || '',
    providerName: providerInfo.name || '',
    carPath: carPath,
    uploadStatus,
  })

  console.log('\n━━━ Upload Complete ━━━')
  console.log(`Network: ${network}`)
  console.log(`IPFS Root CID: ${pc.bold(rootCid)}`)
  console.log(`Data Set ID: ${dataSetId}`)
  console.log(`::notice::Upload complete. IPFS Root CID: ${rootCid}`)
  console.log(`Piece CID: ${pieceCid}`)
  console.log(`Provider: ${provider.name || 'Unknown'} (ID ${provider.id || 'Unknown'})`)
  console.log(`Preview: ${previewUrl}`)

  await updateCheck({
    title: 'Finalizing upload',
    summary: `Upload complete. IPFS Root CID: \`${rootCid}\``,
  })

  await writeSummary(context, 'Uploaded')

  // Comment on PR
  await commentOnPR(context)

  return context
}
