import { createReadStream, promises as fs } from 'node:fs'
import { Readable } from 'node:stream'
import { TIME_CONSTANTS } from '@filoz/synapse-sdk'
import { CarReader } from '@ipld/car'
import {
  calculateFilecoinPayFundingPlan,
  executeTopUp,
  formatFundingReason,
  getPaymentStatus,
  getStorageRunway,
} from 'filecoin-pin/core/payments'
import { createUnixfsCarBuilder } from 'filecoin-pin/core/unixfs'
import { executeUpload } from 'filecoin-pin/core/upload'
import { formatRunwaySummary, formatUSDFC } from 'filecoin-pin/core/utils'
import { CID } from 'multiformats/cid'
import { getErrorMessage } from './errors.js'

/**
 * @typedef {import('./types.js').ParsedInputs} ParsedInputs
 * @typedef {import('./types.js').BuildResult} BuildResult
 * @typedef {import('./types.js').UploadResult} UploadResult
 * @typedef {import('./types.js').PaymentStatus} PaymentStatus
 * @typedef {import('./types.js').SimplifiedPaymentStatus} SimplifiedPaymentStatus
 * @typedef {import('./types.js').PaymentFundingConfig} PaymentFundingConfig
 * @typedef {import('./types.js').UploadConfig} UploadConfig
 * @typedef {import('./types.js').FilecoinPinPaymentStatus} FilecoinPinPaymentStatus
 * @typedef {import('./types.js').Synapse} Synapse
 * @typedef {import('./types.js').Logger} Logger
 */

/**
 * Create CAR file from content path using core unixfs functionality
 * @param {string} targetPath - Path to content
 * @param {string} contentPath - Original content path for logging
 * @param {Logger} logger - Logger instance
 * @returns {Promise<BuildResult>} CAR file info
 */
export async function createCarFile(targetPath, contentPath, logger) {
  try {
    const builder = createUnixfsCarBuilder()
    logger.info(`Packing '${contentPath}' into CAR (UnixFS) ...`)

    const { carPath, rootCid, size } = await builder.buildCar(targetPath, {
      logger,
    })

    return { carPath, ipfsRootCid: rootCid, contentPath, carSize: size }
  } catch (error) {
    throw new Error(`Failed to create CAR file: ${getErrorMessage(error)}`)
  }
}

/**
 * Read a pre-built CAR file and extract its single root CID.
 *
 * Only the CAR header is parsed, so this is cheap even for large CARs.
 * The CAR must declare exactly one root; multi-root and rootless CARs
 * are rejected so the upload flow always has an unambiguous IPFS root CID.
 *
 * @param {string} targetPath - Absolute path to the CAR file
 * @param {string} contentPath - Original input path for logging
 * @param {Logger} logger - Logger instance
 * @returns {Promise<BuildResult>} CAR file info
 */
export async function readCarFile(targetPath, contentPath, logger) {
  try {
    logger.info(`Using pre-built CAR at '${contentPath}' ...`)

    const [{ size }, roots] = await Promise.all([fs.stat(targetPath), readCarRoots(targetPath)])

    const [rootCid, ...extraRoots] = roots
    if (!rootCid) {
      throw new Error('CAR file declares no roots; a single-root CAR is required')
    }
    if (extraRoots.length > 0) {
      throw new Error(`CAR file declares ${roots.length} roots; a single-root CAR is required`)
    }

    return { carPath: targetPath, ipfsRootCid: rootCid.toString(), contentPath, carSize: size }
  } catch (error) {
    throw new Error(`Failed to read CAR file: ${getErrorMessage(error)}`)
  }
}

/**
 * Stream-parse a CAR header and return its declared roots.
 * @param {string} filePath
 * @returns {Promise<CID[]>}
 */
async function readCarRoots(filePath) {
  const stream = createReadStream(filePath)
  try {
    const reader = await CarReader.fromIterable(/** @type {any} */ (stream))
    return await reader.getRoots()
  } finally {
    stream.destroy()
  }
}

/**
 * Handle payment setup and top-ups using core payment functions
 * @param {Synapse} synapse - Synapse service
 * @param {PaymentFundingConfig} options - Payment options
 * @param {Logger | undefined} logger - Logger instance
 * @returns {Promise<SimplifiedPaymentStatus>} Updated payment status
 */
export async function handlePayments(synapse, options, logger) {
  const { minStorageDays, filecoinPayBalanceLimit, pieceSizeBytes, withCDN, providerIds, dataSetIds } = options
  if (pieceSizeBytes == null) {
    throw new Error('pieceSizeBytes is required to calculate upload funding')
  }

  console.log('Checking current Filecoin Pay account balance...')
  const [rawStatus, accountSummary, contexts] = await Promise.all([
    getPaymentStatus(synapse),
    synapse.payments.accountSummary({}),
    synapse.storage.createContexts({
      ...(providerIds != null && providerIds.length > 0 ? { providerIds } : {}),
      ...(dataSetIds != null && dataSetIds.length > 0 ? { dataSetIds } : {}),
      ...(withCDN ? { withCDN } : {}),
    }),
  ])

  const initialFilecoinPayBalance = formatUSDFC(rawStatus.filecoinPayBalance)
  const initialWalletBalance = formatUSDFC(rawStatus.walletUsdfcBalance)

  console.log(`Current Filecoin Pay balance: ${initialFilecoinPayBalance} USDFC`)
  console.log(`Wallet USDFC balance: ${initialWalletBalance} USDFC`)

  const newDataSetCount = contexts.filter((context) => context.dataSetId == null).length
  const uploadCosts = await synapse.storage.calculateMultiContextCosts(contexts, {
    pieceSizes: [BigInt(pieceSizeBytes)],
    extraRunwayEpochs: BigInt(Math.floor(minStorageDays)) * TIME_CONSTANTS.EPOCHS_PER_DAY,
  })

  // Calculate required funding using the comprehensive funding planner
  const fundingPlan = calculateFilecoinPayFundingPlan({
    status: rawStatus,
    accountSummary,
    mode: 'minimum',
    allowWithdraw: false,
    targetRunwayDays: minStorageDays,
    pieceSizeBytes,
    newDataSetCount,
    withCDN,
    uploadCosts,
  })

  if (fundingPlan.delta > 0n) {
    const reasonMessage = formatFundingReason(fundingPlan.reasonCode, fundingPlan)
    console.log(`\n${reasonMessage}: ${formatUSDFC(fundingPlan.delta)} USDFC`)
  }

  if (newDataSetCount > 0) {
    const feeDescription = withCDN
      ? 'lifecycle-reserve funding (including operation fees) and CDN lockup'
      : 'lifecycle-reserve funding (including operation fees)'
    console.log(
      `Additional funding for ${newDataSetCount} new data set${newDataSetCount === 1 ? '' : 's'} ` +
        `(${feeDescription}) is included in the planned top-up`
    )
  }

  // Execute top-up with balance limit checking
  const topUpResult = await executeTopUp(synapse, fundingPlan.delta, {
    balanceLimit: filecoinPayBalanceLimit,
    logger,
  })

  if (topUpResult.success && topUpResult.deposited > 0n) {
    console.log(`\nSubmitting transaction to deposit ${topUpResult.deposited} USDFC to Filecoin Pay...`)
    console.log('✓ Transaction submitted successfully')
    console.log('(Note: Transaction will continue to process in the background)')
  } else if (topUpResult.success) {
    console.log('✓ No deposit required - sufficient balance available')
  } else {
    throw new Error(`Payment setup failed: ${topUpResult.message}`)
  }

  let finalStatus = rawStatus
  if (topUpResult.success && topUpResult.deposited > 0n) {
    finalStatus = await getPaymentStatus(synapse)
  }

  const filecoinPayBalance = formatUSDFC(finalStatus.filecoinPayBalance)
  const walletUsdfcBalance = formatUSDFC(finalStatus.walletUsdfcBalance)
  const finalRunway = await getStorageRunway(synapse)
  const runwayDisplay = formatRunwaySummary(finalRunway)

  return {
    filecoinPayBalance,
    walletUsdfcBalance,
    storageCovered: runwayDisplay.coverage,
    storageRunway: runwayDisplay.runway,
    depositedThisRun: topUpResult.deposited.toString(),
  }
}

/**
 * Format byte counts for upload progress logs.
 * @param {number} bytes
 * @returns {string}
 */
function formatProgressSize(bytes) {
  const units = ['B', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB']
  let size = bytes
  let unitIndex = 0

  while (size >= 1024 && unitIndex < units.length - 1) {
    size /= 1024
    unitIndex++
  }

  return `${size.toFixed(1)} ${units[unitIndex]}`
}

/**
 * Upload CAR to Filecoin using core upload functionality
 * @param {Synapse} synapse - Synapse instance
 * @param {string} carPath - Path to CAR file
 * @param {string} ipfsRootCid - Root CID
 * @param {UploadConfig} options - Upload options
 * @param {any} logger - Logger instance
 * @returns {Promise<UploadResult>} Upload result
 */
export async function uploadCarToFilecoin(synapse, carPath, ipfsRootCid, options, logger) {
  const { size } = await fs.stat(carPath)
  const carData = /** @type {ReadableStream<Uint8Array>} */ (Readable.toWeb(createReadStream(carPath)))
  const cid = CID.parse(ipfsRootCid)
  let lastProgressBucket = -1

  /** @type {bigint[] | undefined} */
  const providerIds = options.providerIds != null && options.providerIds.length > 0 ? options.providerIds : undefined
  if (providerIds) {
    logger.info(
      { event: 'upload.provider_override', providerIds: providerIds.map(String) },
      'Using provider ID override'
    )
  }

  /** @type {bigint[] | undefined} */
  const dataSetIds = options.dataSetIds != null && options.dataSetIds.length > 0 ? options.dataSetIds : undefined
  if (dataSetIds) {
    logger.info({ event: 'upload.dataset_override', dataSetIds: dataSetIds.map(String) }, 'Using data set ID override')
  }

  console.log('\nStarting upload to storage provider...')
  console.log('Uploading data to PDP server...')
  logger.info({ event: 'upload.stream_ready', carPath, size }, 'Streaming CAR upload from disk')

  const uploadResult = await executeUpload(synapse, carData, cid, {
    logger,
    contextId: `gha-upload-${Date.now()}`,
    ...(providerIds != null && { providerIds }),
    ...(dataSetIds != null && { dataSetIds }),
    onProgress: (event) => {
      switch (event.type) {
        case 'uploadProgress': {
          const totalBytes = Math.max(size, 1)
          const uploadedBytes = Math.min(event.data.bytesUploaded, totalBytes)
          const percent = Math.min(100, Math.floor((uploadedBytes / totalBytes) * 100))
          const bucket = percent === 100 ? 100 : Math.floor(percent / 10) * 10
          if (bucket > lastProgressBucket) {
            lastProgressBucket = bucket
            console.log(
              `Upload progress: ${percent}% (${formatProgressSize(uploadedBytes)}/${formatProgressSize(size)})`
            )
          }
          break
        }
        case 'stored': {
          console.log(`✓ Data stored on provider ${event.data.providerId}`)
          console.log(`Piece CID: ${event.data.pieceCid}`)
          break
        }
        case 'piecesAdded': {
          if (event.data.txHash) {
            console.log('✓ Piece registration transaction submitted')
            console.log(`Transaction hash: ${event.data.txHash}`)
          }
          break
        }
        case 'piecesConfirmed': {
          console.log(`✓ Piece confirmed on-chain (data set ${event.data.dataSetId})`)
          break
        }
        case 'copyComplete': {
          console.log(`✓ Secondary copy complete on provider ${event.data.providerId}`)
          break
        }
        case 'copyFailed': {
          console.log(
            `Warning: Secondary copy failed on provider ${event.data.providerId}: ${event.data.error.message}`
          )
          break
        }
        case 'pieceSyncStatus:retryUpdate': {
          const { serviceURL, providerIndex, providerCount, providerAttempt } = event.data
          const prefix = providerCount > 1 ? `[${providerIndex}/${providerCount}] ` : ''
          const suffix = providerCount > 1 ? ` on ${serviceURL}` : ''
          console.log(`${prefix}Piece sync status check attempt #${providerAttempt}${suffix}...`)
          break
        }
        case 'pieceSyncStatus:providerSynced': {
          const { serviceURL, providerIndex, providerCount } = event.data
          if (providerCount > 1) {
            console.log(`✓ [${providerIndex}/${providerCount}] Advertisement confirmed indexed on ${serviceURL}`)
          }
          break
        }
        case 'pieceSyncStatus:complete': {
          console.log('✓ Advertisement confirmed indexed')
          break
        }
        case 'pieceSyncStatus:failed': {
          console.log('Advertisement not confirmed indexed in time')
          console.log(`Error: ${event.data.error.message}`)
          break
        }
        case 'indexingConfirmation:mismatch': {
          console.log('Warning: storage provider reported sync, but a direct indexer lookup still disagrees')
          console.log(`Error: ${event.data.error.message}`)
          break
        }
        case 'ipniProviderResults:retryUpdate': {
          const attempt = event.data.attempt ?? (event.data.retryCount === 0 ? 1 : event.data.retryCount + 1)
          console.log(`IPNI provider results check attempt #${attempt}...`)
          break
        }
        case 'ipniProviderResults:complete': {
          console.log(event.data.result ? '✓ IPNI provider results found' : 'IPNI provider results not found')
          break
        }
        case 'ipniProviderResults:failed': {
          console.log('IPNI provider results not found')
          console.log(`Error: ${event.data.error.message}`)
          break
        }
        default: {
          break
        }
      }
    },
  })

  console.log('\n✓ Upload to Filecoin complete!')

  // Prefer the primary copy for backwards-compatible outputs, but accept any
  // successful copy so partial StorageManager success does not look like total
  // upload failure.
  const primaryCopy = uploadResult.copies.find((c) => c.role === 'primary')
  const outputCopy = primaryCopy ?? uploadResult.copies[0]

  if (outputCopy == null) {
    const failureCount = uploadResult.failedAttempts.length
    throw new Error(
      failureCount > 0
        ? `Upload failed: all ${failureCount} copy attempt(s) failed`
        : 'Upload failed: no copies were created'
    )
  }

  const requestedCopies = uploadResult.requestedCopies ?? uploadResult.copies.length
  const complete = uploadResult.complete ?? uploadResult.copies.length >= requestedCopies

  if (!complete) {
    console.log(
      `Warning: Upload completed with reduced redundancy (${uploadResult.copies.length}/${requestedCopies} copies).`
    )
  }

  if (primaryCopy == null) {
    console.log('Warning: Primary copy failed; using the first successful secondary copy for action outputs.')
  }

  return {
    pieceCid: uploadResult.pieceCid,
    pieceId: String(outputCopy.pieceId),
    dataSetId: String(outputCopy.dataSetId),
    provider: {
      id: String(outputCopy.providerId),
      name: '',
    },
    previewUrl: outputCopy.retrievalUrl ?? '',
    network: uploadResult.network,
    ipniValidated: uploadResult.ipniValidated,
    requestedCopies,
    complete,
    copies: uploadResult.copies,
    failedAttempts: uploadResult.failedAttempts,
  }
}
