# Filecoin Pin Upload Action

The Filecoin Pin Upload Action is a composite GitHub Action that packs a file or directory into a UnixFS CAR, uploads it to Filecoin, and publishes artifacts and context for easy reuse.

This is the GitHub Action that Filecoin Pin supports for uploading content to the Filecoin decentralized storage network from CI. It packs a file or directory into a UnixFS CAR and uploads it via filecoin-pin, so you can publish to Filecoin on every push or pull request.

*Note: The action defaults to Filecoin Mainnet (`network: mainnet`). Set `network: calibration` to target the Calibration testnet, where data isn't permanent and infrastructure resets regularly.*

## Quick Start

See the two-workflow approach in the [examples directory](./examples/) for complete workflow files and setup instructions.

## Inputs & Outputs

> **Using the CLI directly?** `filecoin-pin add` and `filecoin-pin import` accept `--auto-fund`, `--min-runway-days`, and `--max-balance` flags that mirror `minRunwayDays` and `maxBalance` here. See `filecoin-pin add --help`.

See [action.yml](./action.yml) for complete input documentation including:
- **Core**: `path`, `walletPrivateKey`, `network`
- **Financial**: `minRunwayDays`, `maxBalance`
- **Dataset targeting**: `dataSetIds`
- **Advanced**: `egressProvider`, `dryRun`, `disableTelemetry`

**Outputs**: `ipfsRootCid`, `dataSetId`, `pieceCid`, `providerId`, `providerName`, `carPath`, `uploadStatus`

> **Egress is off by default.** This action defaults `egressProvider` to `none`, matching the `filecoin-pin` CLI default. Set `egressProvider: beam` to route piece/CAR retrieval through the FilBeam CDN (egress is then drawn from the data set owner's lockup).

> **Disabling telemetry.** Either set the `disableTelemetry: true` input, or set `FILECOIN_PIN_TELEMETRY_DISABLED=true` / `DO_NOT_TRACK=1` in the job's `env:` block. See the [Telemetry section of the root README](../README.md#telemetry) for more info.

### Uploading a pre-built CAR

If `path` points to a regular file whose name ends in `.car`, the action skips its own UnixFS packing and uploads the file as-is, extracting the IPFS root CID from the CAR header. Useful for composing with upstream steps that already produce a CAR (e.g. [`ipfs-deploy-action`](https://github.com/ipfs/ipfs-deploy-action), [`ipfs dag export`](https://docs.ipfs.tech/reference/kubo/cli/#ipfs-dag-export)).

```yaml
- name: Upload pre-built CAR to Filecoin
  # For production, pin to a specific version (e.g. @v1.1.0) or commit SHA instead of @master.
  uses: filecoin-project/filecoin-pin/upload-action@master
  with:
    path: build.car
    walletPrivateKey: ${{ secrets.FILECOIN_WALLET_KEY }}
```

The CAR must declare exactly one root; multi-root and rootless CARs are rejected so the upload always has an unambiguous IPFS root CID. Directories (even named `foo.car/`) fall through to the UnixFS packer.

### Advanced: Provider Overrides

For most users, automatic provider selection is recommended. However, for advanced use cases where you need to target specific storage providers, set the `PROVIDER_IDS` environment variable to a comma-separated list of numeric on-chain provider IDs:

```yaml
- name: Upload to Filecoin
  # For production, pin to a specific version (e.g. @v1.1.0) or commit SHA instead of @master.
  uses: filecoin-project/filecoin-pin/upload-action@master
  env:
    PROVIDER_IDS: "1,2"  # Target specific providers by their numeric on-chain IDs
  with:
    path: dist
    walletPrivateKey: ${{ secrets.FILECOIN_WALLET_KEY }}
```

When omitted, the SDK selects providers automatically (recommended). With multi-copy uploads it picks an endorsed primary and approved secondaries; setting `PROVIDER_IDS` overrides that selection.

⚠️ **Warning**: Overriding providers may cause uploads to fail if a specified provider is unavailable or doesn't support IPFS indexing.

### Advanced: Targeting Existing Datasets

To append an upload to one or more existing Synapse datasets instead of creating a new one, set the `dataSetIds` input to a comma-separated list of numeric dataset IDs:

```yaml
- name: Upload to Filecoin
  # For production, pin to a specific version (e.g. @v1.1.0) or commit SHA instead of @master.
  uses: filecoin-project/filecoin-pin/upload-action@master
  with:
    path: dist
    walletPrivateKey: ${{ secrets.FILECOIN_WALLET_KEY }}
    dataSetIds: "13260,13261"
```

When omitted, the SDK selects or creates a dataset automatically (recommended). `dataSetIds` and `PROVIDER_IDS` are mutually exclusive, setting both will fail with a clear error.

## Security Checklist

- ✅ Pin action by specific version tag (`@v1.1.0`) or commit SHA (`@<sha>`) for production workflows. `@master` is acceptable for tracking latest but accepts whatever maintainers push between releases.
- ✅ Grant `actions: read` for artifact reuse (cache fallback)
- ✅ Grant `checks: write` for PR check status
- ✅ Grant `pull-requests: write` for PR comments
- ℹ️ GitHub token is automatically provided - no need to pass it
- ✅ **Always** hardcode `minRunwayDays` and `maxBalance` in trusted workflows
- ✅ **Never** use `pull_request_target` - use the two-workflow pattern instead
- ✅ Enable **branch protection** on main to require reviews for workflow changes
- ✅ Use **CODEOWNERS** to require security team approval for workflow modifications
- ⚠️ **Consider using GitHub Environments** with required approvals to gate wallet interactions - this prevents workflows from making deposits without maintainer approval (via label, manual approval, etc.)

## Current Limitations

**⚠️ Fork PR Support Disabled**
- Only same-repo PRs and direct pushes are supported
- Fork PRs that flow through the documented two-workflow `workflow_run` pattern are also blocked, not just direct `pull_request` triggers
- Their artifacts are rejected before wallet input validation or upload
- `workflow_run` events with incomplete repository provenance are rejected rather than allowed
- This prevents non-maintainer PR actors from draining funds

## Versioning and Updates

Pin the action to one of:

- **`@v1.1.0`** (or any specific [release tag](https://github.com/filecoin-project/filecoin-pin/releases)). Recommended for production.
- **`@<commit-sha>`**. Maximum supply-chain security; updates require an intentional commit.
- **`@master`**. Tracks the latest commit on master. Convenient, and what [filecoin-pin-website's CI](https://github.com/filecoin-project/filecoin-pin-website/blob/main/.github/workflows/filecoin-pin-upload.yml) currently uses, but it accepts whatever maintainers push, so avoid it in security-sensitive workflows.

> [!NOTE]
> Floating major-version tags (e.g. `@v1`) are not currently maintained. Pin to a specific version, commit SHA, or `@master`.

The action checks npm for a newer `filecoin-pin` release at the start of each run and posts a GitHub Actions notice when one is available.

## Caching & Artifacts

- **Cache key**: `filecoin-pin-v1-${ipfsRootCid}` enables reuse for identical content
- **Artifacts**: `filecoin-pin-artifacts/upload.car` and `filecoin-pin-artifacts/context.json` published for each run
- **PR comments**: Include IPFS root CID, dataset ID, piece CID, and preview link

## Examples & Documentation

- **[examples/](./examples/)** - Ready-to-use workflow files and setup instructions
- **[examples/cli-recipe/](./examples/cli-recipe/)** - Drive the `filecoin-pin` CLI directly from your own workflow steps, without this composite action
- **[Actual usage in filecoin-pin-website repo](https://github.com/filecoin-project/filecoin-pin-website/blob/main/.github/workflows/filecoin-pin-upload.yml)** ([🎥 demo recording](https://www.youtube.com/watch?v=_2ZsMYXfgwI))
- **[Filecoin Pin + ENS Demo](https://github.com/FIL-Builders/filecoin-pin-ens-demo)** ([🎥 demo recording](https://www.youtube.com/watch?v=tkDwXAVtnDA)) - A minimal demo showing a static website deployed with the Filecoin Pin Upload Action and an ENS update that points the ENS name to the latest IPFS CID after each push to main.
- **[FLOW.md](./FLOW.md)** - Internal architecture for contributors and maintainers

## Contributing

See [FLOW.md](./FLOW.md) for internal architecture.
