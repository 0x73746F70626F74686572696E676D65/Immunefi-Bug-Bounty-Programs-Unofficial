use byteorder::{LittleEndian, WriteBytesExt};
use filecoin_proofs::types::PaddedBytesAmount;

use crate::error::Result;
use crate::kv_store::KeyValueStore;
use crate::state::*;

pub struct SnapshotKey {
    prover_id: [u8; 32],
    sector_size: PaddedBytesAmount,
}

impl SnapshotKey {
    pub fn new(prover_id: [u8; 32], sector_size: PaddedBytesAmount) -> SnapshotKey {
        SnapshotKey {
            prover_id,
            sector_size,
        }
    }
}

pub fn load_snapshot<T: KeyValueStore>(
    kv_store: &T,
    key: &SnapshotKey,
) -> Result<Option<SectorBuilderState>> {
    let result: Option<Vec<u8>> = kv_store.get(&Vec::from(key))?;

    if let Some(val) = result {
        return serde_cbor::from_slice(&val[..])
            .map_err(|err| {
                format_err!(
                    "could not deserialize snapshot bytes to a SectorBuilderState: {}",
                    err
                )
            })
            .map(Option::Some);
    }

    Ok(None)
}

impl From<&SnapshotKey> for Vec<u8> {
    fn from(n: &SnapshotKey) -> Self {
        // convert the sector size to a byte vector
        let mut snapshot_key = Vec::with_capacity(n.prover_id.len() + 8);
        snapshot_key
            .write_u64::<LittleEndian>(u64::from(n.sector_size))
            .unwrap();

        // concatenate the prover id bytes
        snapshot_key.extend_from_slice(&n.prover_id[..]);

        snapshot_key
    }
}

pub fn persist_snapshot<T: KeyValueStore>(
    kv_store: &T,
    key: &SnapshotKey,
    state: &SectorBuilderState,
) -> Result<()> {
    let serialized = serde_cbor::to_vec(state)?;
    kv_store.put(&Vec::from(key), &serialized)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use std::collections::HashMap;

    use crate::kv_store::FileSystemKvs;
    use crate::metadata::StagedSectorMetadata;
    use crate::state::StagedState;
    use storage_proofs::sector::SectorId;

    use super::*;
    use std::io::Write;

    #[test]
    fn test_corrupted_snapshot_produces_error_on_load() {
        let metadata_dir = tempfile::tempdir().unwrap().into_path();

        let kv_store = FileSystemKvs::initialize(&metadata_dir).unwrap();

        let key = SnapshotKey::new([0; 32], PaddedBytesAmount(1024));
        let value = Default::default();

        let _ = persist_snapshot(&kv_store, &key, &value).unwrap();

        // corrupt the snapshot file
        let paths = std::fs::read_dir(&metadata_dir).unwrap();
        for path in paths {
            let x = path.unwrap().path().display().to_string();

            let mut f = std::fs::OpenOptions::new()
                .write(true)
                .read(true)
                .open(&x)
                .expect("could not open");

            f.write_all(b"eat at joe's").expect("could not write");
        }

        let result = load_snapshot(&kv_store, &key);

        assert!(result.is_err(), "corrupted file should cause an error");
    }

    #[test]
    fn test_missing_snapshot_produces_no_error_on_load() {
        let metadata_dir = tempfile::tempdir().unwrap().into_path();

        let kv_store = FileSystemKvs::initialize(&metadata_dir).unwrap();

        let key = SnapshotKey::new([0; 32], PaddedBytesAmount(1024));
        let value = Default::default();

        let _ = persist_snapshot(&kv_store, &key, &value).unwrap();

        // remove the snapshot file
        let paths = std::fs::read_dir(&metadata_dir).unwrap();
        for path in paths {
            std::fs::remove_file(&path.unwrap().path()).expect("could not remove snapshot file");
        }

        let result = load_snapshot(&kv_store, &key);

        assert!(result.is_ok(), "missing file must not produce error");
        assert!(result.unwrap().is_none(), "snapshot file didn't exist")
    }

    #[test]
    fn test_missing_snapshot_directory_produces_error_on_load() {
        let metadata_dir = tempfile::tempdir().unwrap().into_path();

        let kv_store = FileSystemKvs::initialize(&metadata_dir).unwrap();

        let key = SnapshotKey::new([0; 32], PaddedBytesAmount(1024));
        let value = Default::default();

        let _ = persist_snapshot(&kv_store, &key, &value).unwrap();

        // remove the snapshot directory
        std::fs::remove_dir_all(&metadata_dir).expect("could not remove snapshot dir");

        let result = load_snapshot(&kv_store, &key);

        assert!(result.is_ok(), "missing directory must not produce error");
        assert!(result.unwrap().is_none());
    }

    #[test]
    fn test_snapshotting() {
        let metadata_dir = tempfile::tempdir().unwrap().into_path();

        let kv_store = FileSystemKvs::initialize(metadata_dir).unwrap();

        // create a snapshot to persist and load
        let snapshot_a = {
            let mut m: HashMap<SectorId, StagedSectorMetadata> = HashMap::new();

            m.insert(SectorId::from(123), Default::default());

            let staged_state = StagedState { sectors: m };

            let sealed_state = Default::default();

            SectorBuilderState {
                sector_id_nonce: 100.into(),
                staged: staged_state,
                sealed: sealed_state,
            }
        };

        // create a second (different) snapshot
        let snapshot_b = {
            let mut m: HashMap<SectorId, StagedSectorMetadata> = HashMap::new();

            m.insert(SectorId::from(666), Default::default());

            let staged_state = StagedState { sectors: m };

            let sealed_state = Default::default();

            SectorBuilderState {
                sector_id_nonce: 102.into(),
                staged: staged_state,
                sealed: sealed_state,
            }
        };

        let key_a = SnapshotKey::new([0; 32], PaddedBytesAmount(1024));
        let key_b = SnapshotKey::new([0; 32], PaddedBytesAmount(1111));
        let key_c = SnapshotKey::new([1; 32], PaddedBytesAmount(1024));

        // persist both snapshots
        let _ = persist_snapshot(&kv_store, &key_a, &snapshot_a).unwrap();
        let _ = persist_snapshot(&kv_store, &key_b, &snapshot_b).unwrap();

        // load both snapshots
        let loaded_a = load_snapshot(&kv_store, &key_a).unwrap().unwrap();
        let loaded_b = load_snapshot(&kv_store, &key_b).unwrap().unwrap();

        // key corresponds to no snapshot
        let lookup_miss = load_snapshot(&kv_store, &key_c).unwrap();

        assert_eq!(snapshot_a, loaded_a);
        assert_eq!(snapshot_b, loaded_b);
        assert_eq!(true, lookup_miss.is_none());
    }
}
