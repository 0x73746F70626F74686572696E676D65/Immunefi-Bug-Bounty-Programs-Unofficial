// SPDX-License-Identifier: Apache-2.0 OR MIT
pragma solidity ^0.8.30;

import {CalldataSlice} from "./CalldataUtils.sol";

// =============================================================
//                          STRUCTS
// =============================================================

/// @notice A piece being added to a sector, as reported by the miner actor (FIP-0109)
struct PieceChange {
    /// @notice CID of the piece (raw bytes, 0x00 multibase prefix stripped)
    bytes data;
    /// @notice Padded piece size in bytes
    uint64 size;
    /// @notice Receiver-specific payload (e.g. CBOR-encoded allocation ID)
    bytes payload;
}

/// @notice Changes to a single sector, as reported by the miner actor
struct SectorChanges {
    uint64 sector;
    int64 minimumCommitmentEpoch;
    PieceChange[] added;
}

/// @notice Parameters for the SectorContentChanged notification (FIP-0109, method 2034386435)
struct SectorContentChangedParams {
    SectorChanges[] sectors;
}

/// @notice Per-sector response returned by the receiving contract.
///         Bit j of accepted[j/256] indicates whether piece j was accepted.
struct SectorReturn {
    uint256 numPieces;
    uint256[] accepted;
}

/// @notice Return value for the SectorContentChanged notification
struct SectorContentChangedReturn {
    SectorReturn[] sectors;
}

// =============================================================
//             CALLDATA ITERATOR STRUCTS  (zero-copy)
// =============================================================

/// @notice Sector header as decoded by the calldata iterator
struct SectorChangesHeader {
    uint64 sector;
    int64 minimumCommitmentEpoch;
    uint256 numPieces;
}

/// @notice Piece decoded by the calldata iterator; payload is a lazy calldata slice
struct PieceChangeIter {
    /// @notice Raw 32-byte digest of the piece CID (CommP, sha2-256-trunc254-padded)
    bytes32 digest;
    /// @notice Padded piece size in bytes
    uint64 paddedSize;
    /// @notice Receiver-specific payload; materialise on demand with CalldataUtils.load
    CalldataSlice payload;
}

// =============================================================
//                          LIBRARY
// =============================================================

library FVMSectorContentChanged {
    /// @dev CBOR major type byte did not match what was expected
    error UnexpectedCborMajorType(uint8 expected, uint8 actual);
    /// @dev CBOR array or byte string length exceeds what this decoder handles
    error CborLengthTooLarge();
    /// @dev A struct tuple array had the wrong number of elements
    error UnexpectedStructLength(uint256 expected, uint256 actual);
    /// @dev A CBOR bool value was neither 0xf4 (false) nor 0xf5 (true)
    error InvalidCborBool(uint8 actual);
    /// @dev CID was not encoded as CBOR tag 42
    error InvalidCidTag();

    // =========================================================
    //              ENCODE RETURN  (production use)
    // =========================================================

    /// @notice Initialise a caller-allocated SectorReturn for `numPieces` pieces.
    function initSectorReturn(SectorReturn memory sr, uint256 numPieces) internal pure {
        sr.numPieces = numPieces;
        sr.accepted = new uint256[]((numPieces + 255) >> 8);
    }

    /// @notice Mark piece `i` as accepted in a SectorReturn.
    function accept(SectorReturn memory sr, uint256 i) internal pure {
        sr.accepted[i >> 8] |= (uint256(1) << (i & 0xff));
    }

    /// @notice Mark all pieces as accepted in a SectorReturn.
    function acceptAll(SectorReturn memory sr) internal pure {
        uint256 words = sr.accepted.length;
        for (uint256 w = 0; w < words; w++) {
            sr.accepted[w] = type(uint256).max;
        }
    }

    /// @notice Encode SectorContentChangedReturn to CBOR.
    /// @dev Calculates exact output size first, allocates one buffer, writes in a single pass.
    ///      Bit j of accepted[j/256] encodes whether piece j was accepted.
    ///      All three wrapper types (SectorContentChangedReturn, SectorReturn, PieceReturn) are
    ///      transparent, so each serializes as its bare inner value.
    function encodeReturn(SectorContentChangedReturn memory ret) internal pure returns (bytes memory result) {
        // Pass 1: exact size.
        // sectors array header + per-sector (pieces array header + 1 byte per piece (0xf4/0xf5))
        uint256 size = _cborArrayHeaderSize(ret.sectors.length);
        for (uint256 i = 0; i < ret.sectors.length; i++) {
            size += _cborArrayHeaderSize(ret.sectors[i].numPieces) + ret.sectors[i].numPieces;
        }

        // Pass 2: allocate once, write directly via a raw memory pointer
        result = new bytes(size);
        uint256 ptr;
        assembly ("memory-safe") {
            ptr := add(result, 32)
        }
        ptr = _writeCborArrayHeader(ptr, ret.sectors.length);
        for (uint256 i = 0; i < ret.sectors.length; i++) {
            SectorReturn memory sr = ret.sectors[i];
            ptr = _writeCborArrayHeader(ptr, sr.numPieces);
            for (uint256 j = 0; j < sr.numPieces; j++) {
                // bit j of accepted[j/256]; j>>8 == j/256, j&0xff == j%256
                uint256 accepted = (sr.accepted[j >> 8] >> (j & 0xff)) & 1;
                assembly ("memory-safe") {
                    mstore8(ptr, add(0xf4, accepted)) // false=0xf4, true=0xf5
                    ptr := add(ptr, 1)
                }
            }
        }
    }

    // =========================================================
    //              ENCODE PARAMS  (test/mock use)
    // =========================================================

    /// @notice Encode SectorContentChangedParams to CBOR
    /// @dev Used by mocks to build the params that a miner actor would send.
    ///      SectorContentChangedParams is transparent so it serializes as bare Vec<SectorChanges>.
    function encodeParams(SectorContentChangedParams memory params) internal pure returns (bytes memory) {
        bytes memory sectorsArr = _cborArrayHeader(params.sectors.length);
        for (uint256 i = 0; i < params.sectors.length; i++) {
            sectorsArr = abi.encodePacked(sectorsArr, _encodeSectorChanges(params.sectors[i]));
        }
        return sectorsArr;
    }

    function _encodeSectorChanges(SectorChanges memory sc) private pure returns (bytes memory) {
        bytes memory addedArr = _cborArrayHeader(sc.added.length);
        for (uint256 i = 0; i < sc.added.length; i++) {
            addedArr = abi.encodePacked(addedArr, _encodePieceChange(sc.added[i]));
        }
        return
            abi.encodePacked(
                _cborArrayHeader(3), _cborUint64(sc.sector), _cborInt64(sc.minimumCommitmentEpoch), addedArr
            );
    }

    function _encodePieceChange(PieceChange memory pc) private pure returns (bytes memory) {
        return abi.encodePacked(_cborArrayHeader(3), _cborCid(pc.data), _cborUint64(pc.size), _cborBytes(pc.payload));
    }

    // =========================================================
    //              DECODE RETURN  (test/mock use)
    // =========================================================

    /// @notice Decode CBOR-encoded SectorContentChangedReturn
    /// @dev Used by mocks/tests to parse the return value from a receiving contract.
    ///      SectorContentChangedReturn, SectorReturn, and PieceReturn are all flat nested arrays
    function decodeReturn(bytes memory data) internal pure returns (SectorContentChangedReturn memory ret) {
        uint256 offset = 0;

        uint256 numSectors;
        (numSectors, offset) = _readArrayHeader(data, offset);
        ret.sectors = new SectorReturn[](numSectors);
        for (uint256 i = 0; i < numSectors; i++) {
            uint256 numPieces;
            (numPieces, offset) = _readArrayHeader(data, offset);
            ret.sectors[i].numPieces = numPieces;
            ret.sectors[i].accepted = new uint256[]((numPieces + 255) >> 8);
            for (uint256 j = 0; j < numPieces; j++) {
                uint8 b = uint8(data[offset++]);
                require(b == 0xf4 || b == 0xf5, InvalidCborBool(b));
                if (b == 0xf5) ret.sectors[i].accepted[j >> 8] |= (uint256(1) << (j & 0xff));
            }
        }
    }

    // =========================================================
    //          CALLDATA ITERATOR  (zero-copy)
    // =========================================================

    /// @notice Calldata offset where the CBOR params bytes begin in handle_filecoin_method
    /// @dev ABI layout: 4 selector + 32 method + 32 codec + 32 params_offset + 32 params_length = 132
    uint256 private constant PARAMS_START = 132;

    /// @notice Read the params sectors array; returns the number of sectors and the offset of
    ///         the first sector's CBOR data within calldata.
    ///         SectorContentChangedParams is transparent.
    function readParamsHeader() internal pure returns (uint256 numSectors, uint256 nextOffset) {
        (numSectors, nextOffset) = _cdReadArrayHeader(PARAMS_START);
    }

    /// @notice Read one sector header at `cdOffset`, filling `header` in place.
    /// @dev Caller allocates the struct once (outside any loop) and reuses it.
    function readSectorHeader(uint256 cdOffset, SectorChangesHeader memory header)
        internal
        pure
        returns (uint256 nextOffset)
    {
        uint256 len;
        (len, cdOffset) = _cdReadArrayHeader(cdOffset);
        require(len == 3, UnexpectedStructLength(3, len));
        (header.sector, cdOffset) = _cdReadUint64(cdOffset);
        (header.minimumCommitmentEpoch, cdOffset) = _cdReadInt64(cdOffset);
        (header.numPieces, nextOffset) = _cdReadArrayHeader(cdOffset);
    }

    /// @notice Read one piece at `cdOffset`, filling `piece` in place.
    /// @dev Caller allocates the struct once (outside any loop) and reuses it.
    function readPiece(uint256 cdOffset, PieceChangeIter memory piece) internal pure returns (uint256 nextOffset) {
        uint256 len;
        (len, cdOffset) = _cdReadArrayHeader(cdOffset);
        require(len == 3, UnexpectedStructLength(3, len));
        (piece.digest, cdOffset) = _cdReadCidDigest(cdOffset);
        (piece.paddedSize, cdOffset) = _cdReadUint64(cdOffset);
        (piece.payload.offset, piece.payload.length, nextOffset) = _cdReadBytesSlice(cdOffset);
    }

    // --- calldata CBOR read primitives ---

    function _cdReadArrayHeader(uint256 offset) private pure returns (uint256 len, uint256 newOffset) {
        uint8 b;
        assembly ("memory-safe") {
            b := byte(0, calldataload(offset))
        }
        offset++;
        require((b >> 5) == 4, UnexpectedCborMajorType(4, b >> 5));
        uint8 info = b & 0x1f;
        if (info <= 23) return (uint256(info), offset);
        if (info == 24) {
            assembly ("memory-safe") {
                len := byte(0, calldataload(offset))
            }
            return (len, offset + 1);
        }
        if (info == 25) {
            assembly ("memory-safe") {
                len := shr(240, calldataload(offset))
            }
            return (len, offset + 2);
        }
        revert CborLengthTooLarge();
    }

    function _cdReadUint64(uint256 offset) private pure returns (uint64 v, uint256 newOffset) {
        uint8 b;
        assembly ("memory-safe") {
            b := byte(0, calldataload(offset))
        }
        offset++;
        require((b >> 5) == 0, UnexpectedCborMajorType(0, b >> 5));
        uint8 info = b & 0x1f;
        if (info <= 23) return (uint64(info), offset);
        if (info == 24) {
            assembly ("memory-safe") {
                v := byte(0, calldataload(offset))
            }
            return (v, offset + 1);
        }
        if (info == 25) {
            assembly ("memory-safe") {
                v := shr(240, calldataload(offset))
            }
            return (v, offset + 2);
        }
        if (info == 26) {
            assembly ("memory-safe") {
                v := shr(224, calldataload(offset))
            }
            return (v, offset + 4);
        }
        if (info == 27) {
            assembly ("memory-safe") {
                v := shr(192, calldataload(offset))
            }
            return (v, offset + 8);
        }
        revert CborLengthTooLarge();
    }

    function _cdReadInt64(uint256 offset) private pure returns (int64 v, uint256 newOffset) {
        uint8 b;
        assembly ("memory-safe") {
            b := byte(0, calldataload(offset))
        }
        uint8 major = b >> 5;
        if (major == 0) {
            uint64 u;
            (u, newOffset) = _cdReadUint64(offset);
            return (int64(u), newOffset);
        }
        require(major == 1, UnexpectedCborMajorType(1, major));
        offset++;
        uint8 info = b & 0x1f;
        uint64 n;
        if (info <= 23) {
            n = uint64(info);
            newOffset = offset;
        } else if (info == 24) {
            assembly ("memory-safe") {
                n := byte(0, calldataload(offset))
            }
            newOffset = offset + 1;
        } else if (info == 25) {
            assembly ("memory-safe") {
                n := shr(240, calldataload(offset))
            }
            newOffset = offset + 2;
        } else {
            revert CborLengthTooLarge();
        }
        v = -1 - int64(n);
    }

    function _cdReadBytesLen(uint256 offset) private pure returns (uint256 len, uint256 newOffset) {
        uint8 b;
        assembly ("memory-safe") {
            b := byte(0, calldataload(offset))
        }
        offset++;
        require((b >> 5) == 2, UnexpectedCborMajorType(2, b >> 5));
        uint8 info = b & 0x1f;
        if (info <= 23) return (uint256(info), offset);
        if (info == 24) {
            assembly ("memory-safe") {
                len := byte(0, calldataload(offset))
            }
            return (len, offset + 1);
        }
        if (info == 25) {
            assembly ("memory-safe") {
                len := shr(240, calldataload(offset))
            }
            return (len, offset + 2);
        }
        revert CborLengthTooLarge();
    }

    function _cdReadBytesSlice(uint256 offset)
        private
        pure
        returns (uint256 sliceOffset, uint256 sliceLength, uint256 newOffset)
    {
        (sliceLength, offset) = _cdReadBytesLen(offset);
        sliceOffset = offset;
        newOffset = offset + sliceLength;
    }

    /// @notice Read a CBOR tag-42 CID from calldata, strip the 0x00 multibase prefix and the
    ///         7-byte CID header, and return a CalldataSlice pointing at the raw digest bytes.
    /// @dev CommP CID header is always: 01 81 e2 03 92 20 20
    ///      01       = CIDv1
    ///      81 e2 03 = LEB128(0xf101)  fil-commitment-unsealed codec
    ///      92 20    = LEB128(0x1012)  sha2-256-trunc254-padded multihash
    ///      20       = LEB128(32)      digest length in bytes
    function _cdReadCidDigest(uint256 offset) private pure returns (bytes32 digest, uint256 newOffset) {
        // CBOR tag 42 encodes as two bytes: 0xd8 0x2a
        uint16 tag;
        assembly ("memory-safe") {
            tag := shr(240, calldataload(offset))
        }
        require(tag == 0xd82a, InvalidCidTag());
        offset += 2;

        // Advance past the CBOR byte-string length header
        (, offset) = _cdReadBytesLen(offset);

        // Strip 0x00 identity multibase prefix
        uint8 multibase;
        assembly ("memory-safe") {
            multibase := byte(0, calldataload(offset))
        }
        require(multibase == 0x00, InvalidCidTag());
        offset++;

        // Skip the 7-byte CID header, then load the 32-byte digest word directly.
        // Header: 01  81 e2 03          92 20               20
        //         v1  LEB128(0xf101)    LEB128(0x1012)      LEB128(32)
        //         CIDv1  fil-commitment-unsealed  sha2-256-trunc254-padded  digest-length
        offset += 7;
        assembly ("memory-safe") {
            digest := calldataload(offset)
        }
        newOffset = offset + 32;
    }

    // =========================================================
    //                  CBOR WRITE PRIMITIVES
    // =========================================================

    function _cborArrayHeaderSize(uint256 len) private pure returns (uint256) {
        if (len <= 23) return 1; // 0x8n            (1-byte header)
        if (len <= 0xff) return 2; // 0x98 + uint8   (2-byte header)
        if (len <= 0xffff) return 3; // 0x99 + uint16  (3-byte header)
        return 5; // 0x9a + uint32   (5-byte header; no 4-byte form exists in CBOR)
    }

    function _writeCborArrayHeader(uint256 ptr, uint256 len) private pure returns (uint256 newPtr) {
        assembly ("memory-safe") {
            switch gt(len, 0xff)
            case 0 {
                switch gt(len, 23)
                case 0 {
                    mstore8(ptr, or(0x80, len))
                    newPtr := add(ptr, 1)
                }
                default {
                    mstore8(ptr, 0x98)
                    mstore8(add(ptr, 1), len)
                    newPtr := add(ptr, 2)
                }
            }
            default {
                switch gt(len, 0xffff)
                case 0 {
                    mstore8(ptr, 0x99)
                    mstore8(add(ptr, 1), shr(8, len))
                    mstore8(add(ptr, 2), and(len, 0xff))
                    newPtr := add(ptr, 3)
                }
                default {
                    mstore8(ptr, 0x9a)
                    mstore8(add(ptr, 1), shr(24, len))
                    mstore8(add(ptr, 2), shr(16, len))
                    mstore8(add(ptr, 3), shr(8, len))
                    mstore8(add(ptr, 4), and(len, 0xff))
                    newPtr := add(ptr, 5)
                }
            }
        }
    }

    function _cborArrayHeader(uint256 len) private pure returns (bytes memory) {
        if (len <= 23) return abi.encodePacked(uint8(0x80 | uint8(len)));
        if (len <= 0xff) return abi.encodePacked(uint8(0x98), uint8(len));
        if (len <= 0xffff) return abi.encodePacked(uint8(0x99), uint16(len));
        return abi.encodePacked(uint8(0x9a), uint32(len));
    }

    function _cborUint64(uint64 v) private pure returns (bytes memory) {
        if (v <= 23) return abi.encodePacked(uint8(v));
        if (v <= 0xff) return abi.encodePacked(uint8(0x18), uint8(v));
        if (v <= 0xffff) return abi.encodePacked(uint8(0x19), uint16(v));
        if (v <= 0xffffffff) return abi.encodePacked(uint8(0x1a), uint32(v));
        return abi.encodePacked(uint8(0x1b), v);
    }

    function _cborInt64(int64 v) private pure returns (bytes memory) {
        if (v >= 0) return _cborUint64(uint64(v));
        uint64 n = uint64(-1 - v);
        if (n <= 23) return abi.encodePacked(uint8(0x20 | uint8(n)));
        if (n <= 0xff) return abi.encodePacked(uint8(0x38), uint8(n));
        if (n <= 0xffff) return abi.encodePacked(uint8(0x39), uint16(n));
        if (n <= 0xffffffff) return abi.encodePacked(uint8(0x3a), uint32(n));
        return abi.encodePacked(uint8(0x3b), n);
    }

    function _cborBytes(bytes memory b) private pure returns (bytes memory) {
        uint256 len = b.length;
        bytes memory header;
        if (len <= 23) header = abi.encodePacked(uint8(0x40 | uint8(len)));
        else if (len <= 0xff) header = abi.encodePacked(uint8(0x58), uint8(len));
        else if (len <= 0xffff) header = abi.encodePacked(uint8(0x59), uint16(len));
        else header = abi.encodePacked(uint8(0x5a), uint32(len));
        return abi.encodePacked(header, b);
    }

    /// @notice Encode a CID as CBOR tag 42 + bytes(0x00 ++ cid)
    /// @dev `cid` is raw CID bytes without the 0x00 multibase prefix
    function _cborCid(bytes memory cid) private pure returns (bytes memory) {
        return abi.encodePacked(bytes2(0xd82a), _cborBytes(abi.encodePacked(bytes1(0x00), cid)));
    }

    // =========================================================
    //                  CBOR READ PRIMITIVES
    // =========================================================

    function _readArrayHeader(bytes memory data, uint256 offset) private pure returns (uint256 len, uint256 newOffset) {
        uint8 b = uint8(data[offset++]);
        require((b >> 5) == 4, UnexpectedCborMajorType(4, b >> 5));
        uint8 info = b & 0x1f;
        if (info <= 23) return (uint256(info), offset);
        if (info == 24) return (uint256(uint8(data[offset])), offset + 1);
        if (info == 25) {
            len = (uint256(uint8(data[offset])) << 8) | uint256(uint8(data[offset + 1]));
            return (len, offset + 2);
        }
        revert CborLengthTooLarge();
    }
}
