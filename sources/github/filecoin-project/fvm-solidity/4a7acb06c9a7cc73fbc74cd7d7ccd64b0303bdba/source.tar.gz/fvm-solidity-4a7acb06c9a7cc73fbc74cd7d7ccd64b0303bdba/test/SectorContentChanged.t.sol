// SPDX-License-Identifier: Apache-2.0 OR MIT
pragma solidity ^0.8.30;

import {MockFVMTest} from "../src/mocks/MockFVMTest.sol";
import {FVMMinerActor} from "../src/mocks/FVMMinerActor.sol";
import {FVMAddress} from "../src/FVMAddress.sol";
import {CBOR_CODEC} from "../src/FVMCodec.sol";
import {SECTOR_CONTENT_CHANGED} from "../src/FVMMethod.sol";
import {CalldataSlice, CalldataUtils} from "../src/CalldataUtils.sol";
import {
    FVMSectorContentChanged,
    PieceChange,
    PieceChangeIter,
    SectorChanges,
    SectorChangesHeader,
    SectorContentChangedParams,
    SectorContentChangedReturn,
    SectorReturn
} from "../src/FVMSectorContentChanged.sol";

// =============================================================
//              BENCHMARK RECEIVER CONTRACT
// =============================================================

/// @notice Benchmark receiver: calldata iterator → validate digest → abi.decode payload → encodeReturn
contract BenchIteratorReceiver {
    using CalldataUtils for CalldataSlice;

    bytes32 private constant _DIGEST_1 = 0xcdf33e17483f8397390b0a963ded6e34a18f2fce6daa671716057f905f645b36;
    bytes32 private constant _DIGEST_2 = 0xcdf33e1783f2ff8261e66f95858ff85f976bbc0bf05ce8476d3e360832165cd0;

    function handle_filecoin_method(uint64, uint64, bytes calldata)
        external
        pure
        returns (uint32, uint64, bytes memory)
    {
        uint256 numSectors;
        uint256 off;
        (numSectors, off) = FVMSectorContentChanged.readParamsHeader();

        SectorContentChangedReturn memory ret;
        ret.sectors = new SectorReturn[](numSectors);
        SectorChangesHeader memory header;
        PieceChangeIter memory piece;
        for (uint256 i = 0; i < numSectors; i++) {
            off = FVMSectorContentChanged.readSectorHeader(off, header);
            FVMSectorContentChanged.initSectorReturn(ret.sectors[i], header.numPieces);
            for (uint256 j = 0; j < header.numPieces; j++) {
                off = FVMSectorContentChanged.readPiece(off, piece);
                require(piece.digest == _DIGEST_1 || piece.digest == _DIGEST_2);
                uint64 allocationId = abi.decode(piece.payload.load(), (uint64));
                require(allocationId > 0);
                FVMSectorContentChanged.accept(ret.sectors[i], j);
            }
        }
        return (0, CBOR_CODEC, FVMSectorContentChanged.encodeReturn(ret));
    }
}

// =============================================================
//          CALLDATA ITERATOR RECEIVER CONTRACT
// =============================================================

/// @notice Receiver that uses the zero-copy calldata iterator instead of decodeParams
contract IteratorReceiver {
    address public lastCaller;
    uint256 public numSectors;
    uint64 public lastSector;
    int64 public lastMinEpoch;
    uint256 public lastNumPieces;
    bytes32 public lastDigest;
    uint64 public lastPaddedSize;
    bytes public lastPayload;

    function handle_filecoin_method(uint64 method, uint64 codec, bytes calldata)
        external
        returns (uint32, uint64, bytes memory)
    {
        require(method == SECTOR_CONTENT_CHANGED, "wrong method");
        require(codec == CBOR_CODEC, "wrong codec");

        lastCaller = msg.sender;

        uint256 off;
        (numSectors, off) = FVMSectorContentChanged.readParamsHeader();

        SectorChangesHeader memory header;
        PieceChangeIter memory piece;
        for (uint256 i = 0; i < numSectors; i++) {
            off = FVMSectorContentChanged.readSectorHeader(off, header);
            lastSector = header.sector;
            lastMinEpoch = header.minimumCommitmentEpoch;
            lastNumPieces = header.numPieces;

            for (uint256 j = 0; j < header.numPieces; j++) {
                off = FVMSectorContentChanged.readPiece(off, piece);
                lastPaddedSize = piece.paddedSize;
                lastDigest = piece.digest;
                lastPayload = CalldataUtils.load(piece.payload);
            }
        }

        // Accept everything (simplified: uses lastNumPieces for all sectors)
        SectorContentChangedReturn memory ret;
        ret.sectors = new SectorReturn[](numSectors);
        for (uint256 i = 0; i < numSectors; i++) {
            FVMSectorContentChanged.initSectorReturn(ret.sectors[i], lastNumPieces);
            FVMSectorContentChanged.acceptAll(ret.sectors[i]);
        }
        return (0, CBOR_CODEC, FVMSectorContentChanged.encodeReturn(ret));
    }
}

// =============================================================
//                          TESTS
// =============================================================

contract SectorContentChangedTest is MockFVMTest {
    using FVMAddress for uint64;

    IteratorReceiver iterReceiver;
    BenchIteratorReceiver benchIterator;

    // CommP CID (39 bytes): CIDv1 / fil-commitment-unsealed (0xf101) / sha2-256-trunc254-padded (0x1012) / 32-byte digest
    // Header: 01 81 e2 03 92 20 20
    bytes constant COMMP_CID = hex"0181e203922020cdf33e17483f8397390b0a963ded6e34a18f2fce6daa671716057f905f645b36";
    // Just the 32-byte digest portion (skipping the 7-byte prefix 01 81 e2 03 92 20 20)
    bytes32 constant COMMP_DIGEST = 0xcdf33e17483f8397390b0a963ded6e34a18f2fce6daa671716057f905f645b36;
    bytes constant COMMP_CID2 = hex"0181e203922020cdf33e1783f2ff8261e66f95858ff85f976bbc0bf05ce8476d3e360832165cd0";
    bytes32 constant COMMP_DIGEST2 = 0xcdf33e1783f2ff8261e66f95858ff85f976bbc0bf05ce8476d3e360832165cd0;

    function setUp() public override {
        super.setUp();
        iterReceiver = new IteratorReceiver();
        benchIterator = new BenchIteratorReceiver();
    }

    function testReturnRoundtrip() public pure {
        SectorReturn[] memory sectorRets = new SectorReturn[](1);
        sectorRets[0].numPieces = 2;
        sectorRets[0].accepted = new uint256[](1);
        sectorRets[0].accepted[0] = 1; // bit 0 = piece 0 accepted; bit 1 clear = piece 1 rejected

        SectorContentChangedReturn memory ret = SectorContentChangedReturn({sectors: sectorRets});

        bytes memory encoded = FVMSectorContentChanged.encodeReturn(ret);
        SectorContentChangedReturn memory decoded = FVMSectorContentChanged.decodeReturn(encoded);

        assertEq(decoded.sectors.length, 1);
        assertEq(decoded.sectors[0].numPieces, 2);
        assertTrue((decoded.sectors[0].accepted[0] & 1) != 0); // piece 0 accepted
        assertFalse((decoded.sectors[0].accepted[0] & 2) != 0); // piece 1 rejected
    }

    // -------------------------
    // Mock miner
    // -------------------------

    function _buildParams(uint64 sector, bytes memory cid) internal pure returns (SectorContentChangedParams memory) {
        PieceChange[] memory pieces = new PieceChange[](1);
        pieces[0] = PieceChange({data: cid, size: 1024, payload: bytes("")});
        SectorChanges[] memory sectors = new SectorChanges[](1);
        sectors[0] = SectorChanges({sector: sector, minimumCommitmentEpoch: 0, added: pieces});
        return SectorContentChangedParams({sectors: sectors});
    }

    function testMockMinerMsgSenderIsMaskedAddress() public {
        uint64 minerActorId = 5678;
        FVMMinerActor miner = mockMiner(minerActorId);

        miner.callSectorContentChanged(address(iterReceiver), _buildParams(1, COMMP_CID));

        assertEq(iterReceiver.lastCaller(), minerActorId.maskedAddress());
    }

    function testMultipleMinersHaveDifferentMaskedAddresses() public {
        FVMMinerActor miner1 = mockMiner(100);
        FVMMinerActor miner2 = mockMiner(200);

        miner1.callSectorContentChanged(address(iterReceiver), _buildParams(1, COMMP_CID));
        assertEq(iterReceiver.lastCaller(), uint64(100).maskedAddress());

        miner2.callSectorContentChanged(address(iterReceiver), _buildParams(1, COMMP_CID2));
        assertEq(iterReceiver.lastCaller(), uint64(200).maskedAddress());
    }

    // -------------------------
    // Calldata iterator
    // -------------------------

    function testIteratorDecodesCommPCid() public {
        FVMMinerActor miner = mockMiner(1234);

        PieceChange[] memory pieces = new PieceChange[](1);
        pieces[0] = PieceChange({data: COMMP_CID, size: 2048, payload: hex"deadbeef"});
        SectorChanges[] memory sectors = new SectorChanges[](1);
        sectors[0] = SectorChanges({sector: 77, minimumCommitmentEpoch: -5, added: pieces});
        SectorContentChangedParams memory params = SectorContentChangedParams({sectors: sectors});

        miner.callSectorContentChanged(address(iterReceiver), params);

        assertEq(iterReceiver.numSectors(), 1);
        assertEq(iterReceiver.lastSector(), 77);
        assertEq(iterReceiver.lastMinEpoch(), -5);
        assertEq(iterReceiver.lastNumPieces(), 1);
        assertEq(iterReceiver.lastPaddedSize(), 2048);
        assertEq(iterReceiver.lastDigest(), COMMP_DIGEST);
        assertEq(iterReceiver.lastPayload(), hex"deadbeef");
    }

    function testIteratorMultipleSectors() public {
        FVMMinerActor miner = mockMiner(5678);

        PieceChange[] memory pieces0 = new PieceChange[](1);
        pieces0[0] = PieceChange({data: COMMP_CID, size: 1024, payload: bytes("")});
        PieceChange[] memory pieces1 = new PieceChange[](1);
        pieces1[0] = PieceChange({data: COMMP_CID2, size: 4096, payload: hex"cafe"});

        SectorChanges[] memory sectors = new SectorChanges[](2);
        sectors[0] = SectorChanges({sector: 10, minimumCommitmentEpoch: 0, added: pieces0});
        sectors[1] = SectorChanges({sector: 20, minimumCommitmentEpoch: 999, added: pieces1});

        SectorContentChangedParams memory params = SectorContentChangedParams({sectors: sectors});
        miner.callSectorContentChanged(address(iterReceiver), params);

        // lastSector/lastDigest hold values from the final sector
        assertEq(iterReceiver.numSectors(), 2);
        assertEq(iterReceiver.lastSector(), 20);
        assertEq(iterReceiver.lastDigest(), COMMP_DIGEST2);
        assertEq(iterReceiver.lastPayload(), hex"cafe");
    }

    // -------------------------
    // Gas benchmarks (3 sectors × 3 pieces, CommP CIDs, abi.encoded allocation IDs)
    // -------------------------

    function _buildBenchParams() internal pure returns (SectorContentChangedParams memory) {
        SectorChanges[] memory sectors = new SectorChanges[](3);
        uint64 allocId = 1;
        bytes[2] memory cids = [COMMP_CID, COMMP_CID2];
        for (uint256 i = 0; i < 3; i++) {
            PieceChange[] memory pieces = new PieceChange[](3);
            for (uint256 j = 0; j < 3; j++) {
                pieces[j] =
                    PieceChange({data: cids[(i + j) % 2], size: uint64(2048 << j), payload: abi.encode(allocId++)});
            }
            sectors[i] = SectorChanges({
                sector: uint64(100 + i * 100), minimumCommitmentEpoch: int64(int256(i) * 1000), added: pieces
            });
        }
        return SectorContentChangedParams({sectors: sectors});
    }

    function _buildBenchParamsLarge() internal pure returns (SectorContentChangedParams memory) {
        uint256 numSectors = 3;
        uint256 numPieces = 32;
        SectorChanges[] memory sectors = new SectorChanges[](numSectors);
        uint64 allocId = 1;
        bytes[2] memory cids = [COMMP_CID, COMMP_CID2];
        for (uint256 i = 0; i < numSectors; i++) {
            PieceChange[] memory pieces = new PieceChange[](numPieces);
            for (uint256 j = 0; j < numPieces; j++) {
                pieces[j] =
                    PieceChange({data: cids[j % 2], size: uint64(2048 << (j % 8)), payload: abi.encode(allocId++)});
            }
            sectors[i] = SectorChanges({
                sector: uint64(100 + i * 100), minimumCommitmentEpoch: int64(int256(i) * 1000), added: pieces
            });
        }
        return SectorContentChangedParams({sectors: sectors});
    }

    function testGasBenchIteratorPath() public {
        FVMMinerActor miner = mockMiner(9002);
        miner.callSectorContentChanged(address(benchIterator), _buildBenchParams());
    }

    function testGasBenchIteratorPathLarge() public {
        FVMMinerActor miner = mockMiner(9004);
        miner.callSectorContentChanged(address(benchIterator), _buildBenchParamsLarge());
    }
}
