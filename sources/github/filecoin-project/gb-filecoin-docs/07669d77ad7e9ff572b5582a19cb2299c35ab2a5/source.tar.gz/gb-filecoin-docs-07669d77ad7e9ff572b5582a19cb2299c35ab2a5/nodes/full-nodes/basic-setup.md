---
description: >-
  This page gives a very basic overview of how to install Lotus on your
  computer.
---

# Basic setup

To install Lotus on your computer, follow these steps:

1. First, you need to download the appropriate binary file for your operating system. Go to the [official Lotus GitHub repository](https://github.com/filecoin-project/lotus) and select the latest release that is compatible with your system. You can choose from Windows, macOS, and Linux distributions.
2. Once you have downloaded the binary file, extract the contents to a directory of your choice. For example, if you are using Linux, you can extract the contents to the `/usr/local/bin directory` by running the command:

```sh
sudo tar -C /usr/local/bin -xzf lotus-X.X.X-linux-amd64.tar.gz
```

3. Replace `X.X.X` with the version number of the release you downloaded.
4. After extracting the contents, navigate to the `lotus` directory in your terminal. For example, if you extracted the contents to `/usr/local/bin`, you can navigate to the lotus directory by running the command:

```sh
cd /usr/local/bin/lotus-X.X.X
```

5. Again, replace `X.X.X` with the version number of the release you downloaded.
6. Run the `lotus` binary file to start the Lotus daemon. You can do this by running the command:

```sh
./lotus daemon
```

7. This will start the Lotus daemon, which will connect to the Filecoin network and start synchronizing with other nodes on the network.
8. Optionally, you can also run the lotus-miner binary file if you want to participate in the Filecoin mining process. You can do this by running the command:

```sh
./lotus-miner run
```

9. This will start the Lotus miner, which will use your computer’s computing power to mine new blocks on the Filecoin network.
