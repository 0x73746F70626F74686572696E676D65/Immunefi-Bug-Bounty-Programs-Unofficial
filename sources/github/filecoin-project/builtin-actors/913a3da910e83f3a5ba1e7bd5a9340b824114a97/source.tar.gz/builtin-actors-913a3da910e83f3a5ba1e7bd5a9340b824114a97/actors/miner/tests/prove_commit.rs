use fvm_shared::{
    bigint::{BigInt, Zero},
    clock::ChainEpoch,
    econ::TokenAmount,
    error::ExitCode,
};

use fil_actor_miner::{
    SectorOnChainInfoFlags, VestSpec, daily_proof_fee, max_prove_commit_duration,
    pre_commit_deposit_for_power, qa_power_for_sector, qa_power_max,
};
use fil_actors_runtime::reward::FilterEstimate;
use fil_actors_runtime::runtime::Runtime;
use fil_actors_runtime::test_utils::expect_abort;
use util::*;

mod util;

// an expiration ~10 days greater than effective min expiration taking into account 30 days max
// between pre and prove commit
const DEFAULT_SECTOR_EXPIRATION: ChainEpoch = 220;

const PERIOD_OFFSET: ChainEpoch = 100;

#[test]
fn prove_commit_aborts_if_pledge_requirement_not_met() {
    let mut h = ActorHarness::new(PERIOD_OFFSET);
    let rt = h.new_runtime();
    rt.balance.replace(BIG_BALANCE.clone());

    h.construct_and_verify(&rt);

    // Set the circulating supply high and expected reward low in order to coerce
    // pledge requirements (BR + share of money supply, but capped at 1FIL)
    // to exceed pre-commit deposit (BR only).
    rt.set_circulating_supply(TokenAmount::from_whole(100_000_000));
    h.epoch_reward_smooth = FilterEstimate::new(BigInt::from(1e15 as u64), BigInt::zero());

    // prove one sector to establish collateral and locked funds
    let sectors =
        h.commit_and_prove_sectors(&rt, 1, DEFAULT_SECTOR_EXPIRATION as u64, vec![], true);

    // precommit another sector so we may prove it
    let expiration = DEFAULT_SECTOR_EXPIRATION * rt.policy.wpost_proving_period + PERIOD_OFFSET - 1;
    let precommit_epoch = *rt.epoch.borrow() + 1;
    rt.set_epoch(precommit_epoch);
    let params =
        h.make_pre_commit_params(h.next_sector_no, *rt.epoch.borrow() - 1, expiration, vec![]);
    let precommit = h.pre_commit_sector_and_get(&rt, params, PreCommitConfig::default(), false);

    // Confirm the unlocked PCD will not cover the new IP
    assert!(sectors[0].initial_pledge > precommit.pre_commit_deposit);

    // Set balance to exactly cover locked funds.
    let st = h.get_state(&rt);
    rt.balance.replace(&st.pre_commit_deposits + &st.initial_pledge + &st.locked_funds);

    rt.set_epoch(
        precommit_epoch + max_prove_commit_duration(&rt.policy, h.seal_proof_type).unwrap() - 1,
    );
    expect_abort(
        ExitCode::USR_INSUFFICIENT_FUNDS,
        h.deprecated_sector_commit(
            &rt,
            &vec![],
            h.make_prove_commit_params(h.next_sector_no),
            ProveCommitConfig::empty(),
        ),
    );
    rt.reset();

    // succeeds with enough free balance (enough to cover 2x IP)
    rt.balance.replace(
        &st.pre_commit_deposits + &st.initial_pledge + &st.initial_pledge + &st.locked_funds,
    );
    h.deprecated_sector_commit(
        &rt,
        &vec![],
        h.make_prove_commit_params(h.next_sector_no),
        ProveCommitConfig::empty(),
    )
    .unwrap();
    h.check_state(&rt);
}

#[test]
fn prove_commit_just_after_period_start_permits_post() {
    let mut h = ActorHarness::new(PERIOD_OFFSET);
    let rt = h.new_runtime();
    rt.balance.replace(BIG_BALANCE.clone());

    // Epoch PERIOD_OFFSET+1 should be at the beginning of the miner's proving period so there will be time to commit
    // and PoSt a sector.
    rt.set_epoch(PERIOD_OFFSET + 1);
    h.construct_and_verify(&rt);

    // Commit a sector the very next epoch
    rt.set_epoch(PERIOD_OFFSET + 2);
    let sectors =
        h.commit_and_prove_sectors(&rt, 1, DEFAULT_SECTOR_EXPIRATION as u64, vec![], true);

    // advance cron to activate power.
    h.advance_and_submit_posts(&rt, &[sectors.first().unwrap().clone()]);
    h.check_state(&rt);
}

#[test]
fn verify_proof_does_not_vest_funds() {
    let h = ActorHarness::new(PERIOD_OFFSET);
    let rt = h.new_runtime();
    rt.balance.replace(BIG_BALANCE.clone());

    let precommit_epoch = PERIOD_OFFSET + 1;
    rt.set_epoch(precommit_epoch);

    h.construct_and_verify(&rt);
    let deadline = h.deadline(&rt);

    // Make a good commitment for the proof to target.
    let sector_no = 100;
    let params = h.make_pre_commit_params(
        sector_no,
        precommit_epoch - 1,
        deadline.period_end() + DEFAULT_SECTOR_EXPIRATION * rt.policy.wpost_proving_period,
        vec![],
    );
    h.pre_commit_sector_and_get(&rt, params, PreCommitConfig::default(), true);

    // add 1000 tokens that vest immediately
    let mut st = h.get_state(&rt);
    let _ = st
        .add_locked_funds(
            &rt.store,
            *rt.epoch.borrow(),
            &TokenAmount::from_atto(1000),
            &VestSpec { initial_delay: 0, vest_period: 1, step_duration: 1, quantization: 1 },
        )
        .unwrap();
    rt.replace_state(&st);

    rt.set_epoch(precommit_epoch + rt.policy.pre_commit_challenge_delay + 1);
    rt.balance.replace(TokenAmount::from_whole(1000));

    let prove_commit = h.make_prove_commit_params(sector_no);
    // The below call expects exactly the pledge delta for the proven sector, zero for any other vesting.
    h.deprecated_sector_commit(&rt, &vec![], prove_commit, ProveCommitConfig::empty()).unwrap();
}

// Genesis presealed sectors are activated by the system actor through
// InternalSectorSetupForPreseal since it's the only path that creates a sector
// without a seal proof.
#[test]
fn preseal_setup_activates_sector() {
    let h = ActorHarness::new(PERIOD_OFFSET);
    let rt = h.new_runtime();
    rt.balance.replace(BIG_BALANCE.clone());

    let precommit_epoch = PERIOD_OFFSET + 1;
    rt.set_epoch(precommit_epoch);
    h.construct_and_verify(&rt);
    let dl_info = h.deadline(&rt);

    let sector_no = 100;
    let prove_commit_epoch = precommit_epoch + rt.policy.pre_commit_challenge_delay + 1;
    let expiration =
        dl_info.period_end() + DEFAULT_SECTOR_EXPIRATION * rt.policy.wpost_proving_period;

    let precommit_params =
        h.make_pre_commit_params(sector_no, precommit_epoch - 1, expiration, vec![]);
    let precommit =
        h.pre_commit_sector_and_get(&rt, precommit_params, PreCommitConfig::empty(), true);
    assert_eq!(
        pre_commit_deposit_for_power(
            &h.epoch_reward_smooth,
            &h.epoch_qa_power_smooth,
            &qa_power_max(h.sector_size),
        ),
        precommit.pre_commit_deposit
    );

    // Name a second sector that was never pre-committed: the call activates the subset that
    // exists rather than failing, and the pledge and events cover one sector only.
    let missing_no = sector_no + 1;
    rt.set_epoch(prove_commit_epoch);
    h.internal_sector_setup_for_preseal(&rt, vec![sector_no, missing_no], vec![precommit.clone()])
        .unwrap();

    let st = h.get_state(&rt);
    assert!(st.get_sector(&rt.store, missing_no).unwrap().is_none());
    assert!(st.get_precommitted_sector(&rt.store, missing_no).unwrap().is_none());
    let sector = st.get_sector(&rt.store, sector_no).unwrap().unwrap();

    // The precommit is consumed and its deposit becomes pledge.
    assert!(st.get_precommitted_sector(&rt.store, sector_no).unwrap().is_none());
    assert!(st.pre_commit_deposits.is_zero());
    assert_eq!(st.initial_pledge, sector.initial_pledge);

    // No pieces: both weights are zero and the sector reaches 10x on the flag alone, with the
    // daily fee priced at full power.
    assert!(sector.deal_weight.is_zero());
    assert!(sector.verified_deal_weight.is_zero());
    assert!(sector.flags.contains(SectorOnChainInfoFlags::FULL_QA_POWER));
    assert_eq!(qa_power_max(h.sector_size), qa_power_for_sector(h.sector_size, &sector));
    assert_eq!(
        daily_proof_fee(&rt.policy, &rt.total_fil_circ_supply(), &qa_power_max(h.sector_size)),
        sector.daily_fee
    );

    // And it is assigned to a deadline.
    let (dl_idx, p_idx) = st.find_sector(&rt.store, sector_no).unwrap();
    let (deadline, partition) = h.get_deadline_and_partition(&rt, dl_idx, p_idx);
    assert_eq!(1, deadline.live_sectors);
    assert_bitfield_equals(&partition.sectors, &[sector_no]);

    h.check_state(&rt);
}
