use cid::Cid;
use fil_actor_miner::SectorOnChainInfo;
use fil_actors_runtime::test_utils::*;
use fvm_shared::{
    bigint::BigInt,
    clock::ChainEpoch,
    sector::{RegisteredSealProof, SectorNumber},
};

mod state_harness;
mod util;
use state_harness::*;

#[test]
fn put_and_get() {
    let mut h = StateHarness::new(0);

    let sector_no = 1u64;
    let sector_info_1 = new_sector_on_chain_info(
        sector_no,
        make_sealed_cid(b"1"),
        BigInt::from(1u64),
        ChainEpoch::from(1),
    );
    let sector_info_2 = new_sector_on_chain_info(
        sector_no,
        make_sealed_cid(b"2"),
        BigInt::from(2u64),
        ChainEpoch::from(2),
    );

    h.put_sector(&sector_info_1);
    assert!(h.has_sector_number(sector_no));
    let out = h.get_sector(sector_no);
    assert_eq!(sector_info_1, out);

    h.put_sector(&sector_info_2);
    assert!(h.has_sector_number(sector_no));
    let out = h.get_sector(sector_no);
    assert_eq!(sector_info_2, out);
}

#[test]
fn get_nonexistent_value_returns_false() {
    let h = StateHarness::new(ChainEpoch::from(0));

    let sector_number = 1u64;
    assert!(!h.has_sector_number(sector_number));
}

#[test]
fn iterate_multiple_sectors() {
    let mut h = StateHarness::new(ChainEpoch::from(0));

    // set of sectors, the larger numbers here are not significant
    let sector_nos = [100, 200, 300, 400, 500, 600, 700, 800, 900, 1000];

    // put all the sectors in the store
    for (i, s) in sector_nos.iter().enumerate() {
        h.put_sector(&new_sector_on_chain_info(
            *s,
            make_sealed_cid(format!("{}", i).as_bytes()),
            BigInt::from(i),
            i as i64,
        ))
    }

    let mut sector_no_idx = 0;
    h.st.for_each_sector(&h.store, |si| {
        assert_eq!(sector_nos[sector_no_idx], si.sector_number);
        sector_no_idx += 1;
        Ok(())
    })
    .unwrap();

    // ensure we iterated over the expected number of sectors
    assert_eq!(sector_nos.len(), sector_no_idx);
}

// returns a unique SectorOnChainInfo with each invocation with SectorNumber set to `sectorNo`.
fn new_sector_on_chain_info(
    sector_no: SectorNumber,
    sealed_cid: Cid,
    weight: BigInt,
    activation: ChainEpoch,
) -> SectorOnChainInfo {
    SectorOnChainInfo {
        sector_number: sector_no,
        seal_proof: RegisteredSealProof::StackedDRG32GiBV1,
        sealed_cid,
        deprecated_deal_ids: vec![],
        activation,
        power_base_epoch: activation,
        expiration: ChainEpoch::from(1),
        deal_weight: weight.clone(),
        verified_deal_weight: weight,
        ..Default::default()
    }
}
