use std::cell::RefCell;
use std::collections::HashMap;

use cid::Cid;

use frc46_token::receiver::FRC46TokenReceived;
use fvm_ipld_encoding::ipld_block::IpldBlock;
use fvm_shared::address::Address;
use fvm_shared::clock::ChainEpoch;
use fvm_shared::econ::TokenAmount;
use fvm_shared::error::ExitCode;
use fvm_shared::piece::PaddedPieceSize;
use fvm_shared::sector::SectorNumber;
use fvm_shared::{ActorID, MethodNum};

use fil_actor_verifreg::state::{DATACAP_MAP_CONFIG, DataCapMap};
use fil_actor_verifreg::testing::check_state_invariants;
use fil_actor_verifreg::{
    Actor as VerifregActor, Allocation, AllocationClaim, AllocationID, AllocationRequest,
    AllocationRequests, Claim, ClaimExtensionRequest, ClaimID, DataCap, GetClaimsParams,
    GetClaimsReturn, Method, RemoveExpiredClaimsParams, RemoveExpiredClaimsReturn,
    SectorAllocationClaims, State,
};
use fil_actors_runtime::cbor::serialize;
use fil_actors_runtime::runtime::Runtime;
use fil_actors_runtime::runtime::policy_constants::{
    MAXIMUM_VERIFIED_ALLOCATION_TERM, MINIMUM_VERIFIED_ALLOCATION_TERM,
};
use fil_actors_runtime::test_utils::*;
use fil_actors_runtime::{
    ActorError, AsActorError, EventBuilder, SYSTEM_ACTOR_ADDR, VERIFIED_REGISTRY_ACTOR_ADDR,
};

pub const ROOT_ADDR: Address = Address::new_id(101);

const TEST_VERIFIER_ADDR: u64 = 201;
const TEST_VERIFIER2_ADDR: u64 = 202;
const TEST_CLIENT_ADDR: u64 = 301;
const TEST_CLIENT2_ADDR: u64 = 302;
const TEST_CLIENT3_ADDR: u64 = 303;
const TEST_CLIENT4_ADDR: u64 = 304;

pub fn new_runtime() -> MockRuntime {
    let test_verifier_addr = Address::new_id(TEST_VERIFIER_ADDR);
    let test_verifier2_addr = Address::new_id(TEST_VERIFIER2_ADDR);
    let test_client_addr = Address::new_id(TEST_CLIENT_ADDR);
    let test_client2_addr = Address::new_id(TEST_CLIENT2_ADDR);
    let test_client3_addr = Address::new_id(TEST_CLIENT3_ADDR);
    let test_client4_addr = Address::new_id(TEST_CLIENT4_ADDR);
    let mut actor_code_cids = HashMap::default();
    actor_code_cids.insert(test_verifier_addr, *ACCOUNT_ACTOR_CODE_ID);
    actor_code_cids.insert(test_verifier2_addr, *ACCOUNT_ACTOR_CODE_ID);
    actor_code_cids.insert(test_client_addr, *ACCOUNT_ACTOR_CODE_ID);
    actor_code_cids.insert(test_client2_addr, *ACCOUNT_ACTOR_CODE_ID);
    actor_code_cids.insert(test_client3_addr, *ACCOUNT_ACTOR_CODE_ID);
    actor_code_cids.insert(test_client4_addr, *ACCOUNT_ACTOR_CODE_ID);
    MockRuntime {
        receiver: VERIFIED_REGISTRY_ACTOR_ADDR,
        caller: RefCell::new(SYSTEM_ACTOR_ADDR),
        caller_type: RefCell::new(*SYSTEM_ACTOR_CODE_ID),
        actor_code_cids: RefCell::new(actor_code_cids),
        ..Default::default()
    }
}

// Sets the miner code/type for an actor ID
pub fn add_miner(rt: &MockRuntime, id: ActorID) {
    rt.set_address_actor_type(Address::new_id(id), *MINER_ACTOR_CODE_ID);
}

pub fn new_harness() -> (Harness, MockRuntime) {
    let rt = new_runtime();
    let h = Harness { root: ROOT_ADDR };
    h.construct_and_verify(&rt, &h.root);
    (h, rt)
}

pub struct Harness {
    pub root: Address,
}

impl Harness {
    pub fn construct_and_verify(&self, rt: &MockRuntime, root_param: &Address) {
        rt.set_caller(*SYSTEM_ACTOR_CODE_ID, SYSTEM_ACTOR_ADDR);
        rt.expect_validate_caller_addr(vec![SYSTEM_ACTOR_ADDR]);
        let ret = rt
            .call::<VerifregActor>(
                Method::Constructor as MethodNum,
                IpldBlock::serialize_cbor(root_param).unwrap(),
            )
            .unwrap();

        assert!(ret.is_none());
        rt.verify();

        let empty_map = DataCapMap::empty(&rt.store, DATACAP_MAP_CONFIG, "empty").flush().unwrap();
        let state: State = rt.get_state();
        assert_eq!(self.root, state.root_key);
        assert_eq!(empty_map, state.verifiers);
    }

    /// Directly inserts a verifier into state without calling the (now-deprecated) AddVerifier method.
    /// Used for test setup after FIP-0118 disabled AddVerifier.
    pub fn add_verifier_directly(&self, rt: &MockRuntime, verifier: &Address, allowance: &DataCap) {
        let verifier_id_addr = rt.get_id_address(verifier).unwrap_or(*verifier);
        let mut st: State = rt.get_state();
        st.put_verifier(rt.store(), &verifier_id_addr, allowance).unwrap();
        rt.replace_state(&st);
    }

    pub fn assert_verifier_removed(&self, rt: &MockRuntime, verifier: &Address) {
        let verifier_id_addr = rt.get_id_address(verifier).unwrap();
        let verifiers = rt.get_state::<State>().load_verifiers(&rt.store).unwrap();
        assert!(!verifiers.contains_key(&verifier_id_addr).unwrap())
    }

    pub fn assert_verifier_allowance(
        &self,
        rt: &MockRuntime,
        verifier: &Address,
        allowance: &DataCap,
    ) {
        let verifier_id_addr = rt.get_id_address(verifier).unwrap();
        assert_eq!(*allowance, self.get_verifier_allowance(rt, &verifier_id_addr));
    }

    pub fn get_verifier_allowance(&self, rt: &MockRuntime, verifier: &Address) -> DataCap {
        let verifiers = rt.get_state::<State>().load_verifiers(&rt.store).unwrap();
        verifiers.get(verifier).unwrap().unwrap().clone().0
    }

    pub fn check_state(&self, rt: &MockRuntime) {
        let (_, acc) = check_state_invariants(&rt.get_state(), rt.store(), *rt.epoch.borrow());
        acc.assert_empty();
    }

    // TODO this should be implemented through a call to verifreg but for now it modifies state directly
    pub fn create_alloc(
        &self,
        rt: &MockRuntime,
        alloc: &Allocation,
    ) -> Result<AllocationID, ActorError> {
        let mut st: State = rt.get_state();
        let mut allocs = st.load_allocs(rt.store()).unwrap();
        let alloc_id = st.next_allocation_id;
        assert!(
            allocs
                .put_if_absent(alloc.client, alloc_id, alloc.clone())
                .context_code(ExitCode::USR_ILLEGAL_STATE, "faild to put")?
        );
        st.next_allocation_id += 1;
        st.allocations = allocs.flush().expect("failed flushing allocation table");
        rt.replace_state(&st);
        Ok(alloc_id)
    }

    pub fn load_alloc(
        &self,
        rt: &MockRuntime,
        client: ActorID,
        id: AllocationID,
    ) -> Option<Allocation> {
        let st: State = rt.get_state();
        let mut allocs = st.load_allocs(rt.store()).unwrap();
        allocs.get(client, id).unwrap().cloned()
    }

    // Invokes the RemoveExpiredClaims actor method.
    pub fn remove_expired_claims(
        &self,
        rt: &MockRuntime,
        provider: ActorID,
        claim_ids: Vec<ClaimID>,
        expect_removed: Vec<(ClaimID, Claim)>,
    ) -> Result<RemoveExpiredClaimsReturn, ActorError> {
        rt.expect_validate_caller_any();

        for (id, claim) in expect_removed {
            expect_claim_emitted(
                rt,
                "claim-removed",
                id,
                claim.client,
                claim.provider,
                &claim.data,
                claim.size.0,
                claim.sector,
                claim.term_min,
                claim.term_max,
                claim.term_start,
            )
        }

        let params = RemoveExpiredClaimsParams { provider, claim_ids };
        let ret = rt
            .call::<VerifregActor>(
                Method::RemoveExpiredClaims as MethodNum,
                IpldBlock::serialize_cbor(&params).unwrap(),
            )?
            .unwrap()
            .deserialize()
            .expect("failed to deserialize remove expired claims return");
        rt.verify();
        Ok(ret)
    }

    pub fn load_claim(&self, rt: &MockRuntime, provider: ActorID, id: ClaimID) -> Option<Claim> {
        let st: State = rt.get_state();
        let mut claims = st.load_claims(rt.store()).unwrap();
        claims.get(provider, id).unwrap().cloned()
    }

    // Creates a claim directly in state.
    pub fn create_claim(&self, rt: &MockRuntime, claim: &Claim) -> Result<ClaimID, ActorError> {
        let mut st: State = rt.get_state();
        let mut claims = st.load_claims(rt.store()).unwrap();
        let id = st.next_allocation_id;
        assert!(
            claims
                .put_if_absent(claim.provider, id, claim.clone())
                .context_code(ExitCode::USR_ILLEGAL_STATE, "faild to put")?
        );
        st.next_allocation_id += 1;
        st.claims = claims.flush().expect("failed flushing allocation table");
        rt.replace_state(&st);
        Ok(id)
    }

    pub fn get_claims(
        &self,
        rt: &MockRuntime,
        provider: ActorID,
        claim_ids: Vec<ClaimID>,
    ) -> Result<GetClaimsReturn, ActorError> {
        rt.expect_validate_caller_any();
        let params = GetClaimsParams { claim_ids, provider };
        let ret = rt
            .call::<VerifregActor>(
                Method::GetClaims as MethodNum,
                IpldBlock::serialize_cbor(&params).unwrap(),
            )?
            .unwrap()
            .deserialize()
            .expect("failed to deserialize get claims return");
        rt.verify();
        Ok(ret)
    }
}

#[allow(clippy::too_many_arguments)]
pub fn expect_claim_emitted(
    rt: &MockRuntime,
    typ: &str,
    id: u64,
    client: ActorID,
    provider: ActorID,
    piece_cid: &Cid,
    piece_size: u64,
    sector: SectorNumber,
    term_min: ChainEpoch,
    term_max: ChainEpoch,
    term_start: ChainEpoch,
) {
    rt.expect_emitted_event(
        EventBuilder::new()
            .typ(typ)
            .field_indexed("id", &id)
            .field_indexed("client", &client)
            .field_indexed("provider", &provider)
            .field_indexed("piece-cid", piece_cid)
            .field("piece-size", &piece_size)
            .field("term-min", &term_min)
            .field("term-max", &term_max)
            .field("term-start", &term_start)
            .field_indexed("sector", &sector)
            .build()
            .unwrap(),
    );
}

pub fn make_alloc(data_id: &str, client: ActorID, provider: ActorID, size: u64) -> Allocation {
    Allocation {
        client,
        provider,
        data: make_piece_cid(data_id.as_bytes()),
        size: PaddedPieceSize(size),
        term_min: MINIMUM_VERIFIED_ALLOCATION_TERM,
        term_max: MINIMUM_VERIFIED_ALLOCATION_TERM * 2,
        expiration: 100,
    }
}

// Creates an allocation request for fixed data with default terms.
pub fn make_alloc_req(rt: &MockRuntime, provider: ActorID, size: u64) -> AllocationRequest {
    AllocationRequest {
        provider,
        data: make_piece_cid("1234".as_bytes()),
        size: PaddedPieceSize(size),
        term_min: MINIMUM_VERIFIED_ALLOCATION_TERM,
        term_max: MAXIMUM_VERIFIED_ALLOCATION_TERM,
        expiration: *rt.epoch.borrow() + 100,
    }
}

pub fn make_extension_req(
    provider: ActorID,
    claim: ClaimID,
    term_max: ChainEpoch,
) -> ClaimExtensionRequest {
    ClaimExtensionRequest { provider, claim, term_max }
}

// Creates the expected allocation from a request.
pub fn alloc_from_req(client: ActorID, req: &AllocationRequest) -> Allocation {
    Allocation {
        client,
        provider: req.provider,
        data: req.data,
        size: req.size,
        term_min: req.term_min,
        term_max: req.term_max,
        expiration: req.expiration,
    }
}

pub fn make_claim_reqs(
    sector: SectorNumber,
    expiry: ChainEpoch,
    allocs: &[(AllocationID, &Allocation)],
) -> SectorAllocationClaims {
    SectorAllocationClaims {
        sector,
        expiry,
        claims: allocs
            .iter()
            .map(|(id, alloc)| AllocationClaim {
                client: alloc.client,
                allocation_id: *id,
                data: alloc.data,
                size: alloc.size,
            })
            .collect(),
    }
}

#[allow(clippy::too_many_arguments)]
pub fn make_claim(
    data_id: &str,
    client: ActorID,
    provider: ActorID,
    size: u64,
    term_min: i64,
    term_max: i64,
    term_start: i64,
    sector: u64,
) -> Claim {
    Claim {
        provider,
        client,
        data: make_piece_cid(data_id.as_bytes()),
        size: PaddedPieceSize(size),
        term_min,
        term_max,
        term_start,
        sector,
    }
}

pub fn claim_from_alloc(alloc: &Allocation, term_start: ChainEpoch, sector: SectorNumber) -> Claim {
    Claim {
        provider: alloc.provider,
        client: alloc.client,
        data: alloc.data,
        size: alloc.size,
        term_min: alloc.term_min,
        term_max: alloc.term_max,
        term_start,
        sector,
    }
}

pub fn make_receiver_hook_token_payload(
    client: ActorID,
    alloc_requests: Vec<AllocationRequest>,
    extension_requests: Vec<ClaimExtensionRequest>,
    datacap_received: u64,
) -> FRC46TokenReceived {
    // let total_size: u64 = alloc_requests.iter().map(|r| r.size.0).sum();
    let payload =
        AllocationRequests { allocations: alloc_requests, extensions: extension_requests };
    FRC46TokenReceived {
        from: client,
        to: VERIFIED_REGISTRY_ACTOR_ADDR.id().unwrap(),
        operator: client,
        amount: TokenAmount::from_whole(datacap_received as i64),
        operator_data: serialize(&payload, "operator data").unwrap(),
        token_data: Default::default(),
    }
}

pub fn assert_allocation(
    rt: &MockRuntime,
    client: ActorID,
    id: AllocationID,
    expected: &Allocation,
) {
    let st: State = rt.get_state();
    let store = &rt.store();
    let mut allocs = st.load_allocs(store).unwrap();

    assert_eq!(expected, allocs.get(client, id).unwrap().unwrap());
}

pub fn assert_claim(rt: &MockRuntime, provider: ActorID, id: ClaimID, expected: &Claim) {
    let st: State = rt.get_state();
    let store = &rt.store();
    let mut claims = st.load_claims(store).unwrap();

    assert_eq!(expected, claims.get(provider, id).unwrap().unwrap());
}

pub fn assert_alloc_claimed(
    rt: &MockRuntime,
    client: ActorID,
    provider: ActorID,
    id: ClaimID,
    alloc: &Allocation,
    epoch: ChainEpoch,
    sector: SectorNumber,
) -> Claim {
    let st: State = rt.get_state();
    let store = &rt.store();

    // Alloc is gone
    let mut allocs = st.load_allocs(&store).unwrap();
    assert!(allocs.get(client, id).unwrap().is_none());

    // Claim is present
    let expected_claim = claim_from_alloc(alloc, epoch, sector);
    assert_eq!(client, expected_claim.client); // Check the caller provided sensible arguments.
    assert_eq!(provider, expected_claim.provider);
    let mut claims = st.load_claims(store).unwrap();
    assert_eq!(&expected_claim, claims.get(provider, id).unwrap().unwrap());
    expected_claim
}
