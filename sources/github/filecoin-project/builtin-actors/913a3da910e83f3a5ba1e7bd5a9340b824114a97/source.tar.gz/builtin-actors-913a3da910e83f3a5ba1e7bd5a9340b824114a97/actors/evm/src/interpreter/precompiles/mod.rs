use std::{marker::PhantomData, num::TryFromIntError};

use fil_actors_evm_shared::{address::EthAddress, uints::U256};
use fil_actors_runtime::{ActorError, runtime::Runtime};
use fvm_shared::{address::Address, econ::TokenAmount};
use substrate_bn::{CurveError, FieldError, GroupError};
use thiserror::Error;

use crate::reader::OverflowError;

use super::{CallKind, System};
mod blake2f_impl;
mod bls12_381;
mod bls_util;
mod evm;
mod fvm;
mod secp256r1;

use bls12_381::{
    bls12_g1add, bls12_g1msm, bls12_g2add, bls12_g2msm, bls12_map_fp_to_g1, bls12_map_fp2_to_g2,
    bls12_pairing,
};
use evm::{blake2f, ec_add, ec_mul, ec_pairing, ec_recover, identity, modexp, ripemd160, sha256};
use fvm::{call_actor, call_actor_id, get_randomness, lookup_delegated_address, resolve_address};
use secp256r1::p256_verify;

type PrecompileFn<RT> = fn(&mut System<RT>, &[u8], PrecompileContext) -> PrecompileResult;
pub type PrecompileResult = Result<Vec<u8>, PrecompileError>;

pub const NATIVE_PRECOMPILE_ADDRESS_PREFIX: u8 = 0xFE;
const P256VERIFY_PRECOMPILE_ADDRESS: EthAddress =
    EthAddress(hex_literal::hex!("0000000000000000000000000000000000000100"));

struct PrecompileTable<RT: Runtime, const N: usize>([Option<PrecompileFn<RT>>; N]);

impl<RT: Runtime, const N: usize> PrecompileTable<RT, N> {
    /// Tries to lookup Precompile, None if empty slot or out of bounds.
    /// Last byte of precompile address - 1 is the index.
    fn get(&self, index: usize) -> Option<PrecompileFn<RT>> {
        self.0.get(index).and_then(|i| i.as_ref()).copied()
    }
}

pub fn is_reserved_precompile_address(addr: &EthAddress) -> bool {
    // Special case for the secp256r1 (P-256) `P256VERIFY` precompile at 0x0100.
    if addr.0 == P256VERIFY_PRECOMPILE_ADDRESS.0 {
        return true;
    }

    let [prefix, middle @ .., index] = addr.0;
    (prefix == 0x00 || prefix == NATIVE_PRECOMPILE_ADDRESS_PREFIX)
        && middle == [0u8; 18]
        && index > 0
}

pub struct Precompiles<RT>(PhantomData<RT>);

impl<RT: Runtime> Precompiles<RT> {
    /// FEVM specific precompiles (0xfe prefix)
    const NATIVE_PRECOMPILES: PrecompileTable<RT, 6> = PrecompileTable([
        Some(resolve_address::<RT>),          // 0xfe00..01
        Some(lookup_delegated_address::<RT>), // 0xfe00..02
        Some(call_actor::<RT>),               // 0xfe00..03
        None,                                 // 0xfe00..04 get_actor_type DISABLED
        Some(call_actor_id::<RT>),            // 0xfe00..05
        Some(get_randomness::<RT>),           // 0xfe00..06
    ]);

    /// EVM specific precompiles
    const EVM_PRECOMPILES: PrecompileTable<RT, 17> = PrecompileTable([
        Some(ec_recover::<RT>), // 0x01 ecrecover
        Some(sha256::<RT>),     // 0x02 SHA2-256
        Some(ripemd160::<RT>),  // 0x03 ripemd160
        Some(identity::<RT>),   // 0x04 identity
        Some(modexp::<RT>),     // 0x05 modexp
        Some(ec_add::<RT>),     // 0x06 ecAdd
        Some(ec_mul::<RT>),     // 0x07 ecMul
        Some(ec_pairing::<RT>), // 0x08 ecPairing
        Some(blake2f::<RT>),    // 0x09 blake2f
        // BLS12-381 precompiles (starting from 0x0b)
        None,                            // 0x0a (Unused slot)
        Some(bls12_g1add::<RT>),         // 0x0b BLS12_G1ADD
        Some(bls12_g1msm::<RT>),         // 0x0c BLS12_G1MSM
        Some(bls12_g2add::<RT>),         // 0x0d BLS12_G2ADD
        Some(bls12_g2msm::<RT>),         // 0x0e BLS12_G2MSM
        Some(bls12_pairing::<RT>),       // 0x0f BLS12_PAIRING_CHECK
        Some(bls12_map_fp_to_g1::<RT>),  // 0x10 BLS12_MAP_FP_TO_G1
        Some(bls12_map_fp2_to_g2::<RT>), // 0x11 BLS12_MAP_FP2_TO_G2
    ]);

    fn lookup_precompile(addr: &EthAddress) -> Option<PrecompileFn<RT>> {
        // Special-case the secp256r1 (P-256) `P256VERIFY` precompile at 0x0100.
        if addr.0 == P256VERIFY_PRECOMPILE_ADDRESS.0 {
            return Some(p256_verify::<RT>);
        }

        let [prefix, _m @ .., index] = addr.0;
        if is_reserved_precompile_address(addr) {
            let index = index as usize - 1;
            match prefix {
                NATIVE_PRECOMPILE_ADDRESS_PREFIX => Self::NATIVE_PRECOMPILES.get(index),
                0x00 => Self::EVM_PRECOMPILES.get(index),
                _ => None,
            }
        } else {
            None
        }
    }

    /// Call the specified precompile. This will automatically transfer any value (if non-zero) to
    /// the target contract.
    pub fn call_precompile(
        system: &mut System<RT>,
        precompile_addr: &EthAddress,
        input: &[u8],
        context: PrecompileContext,
    ) -> PrecompileResult {
        // First, try to call the precompile, if defined.
        let result = Self::lookup_precompile(precompile_addr)
            .map(|precompile_fn| precompile_fn(system, input, context))
            .transpose()?
            .unwrap_or_default();
        // Then transfer the value. We do this second because we don't want to transfer if the
        // precompile reverts.
        //
        // This shouldn't be observable as the only precompile with side-effects is the call_actor
        // precompile, and that precompile can only be called with delegatecall.
        if !context.value.is_zero() {
            let fil_addr: Address = precompile_addr.into();
            system
                .transfer(&fil_addr, TokenAmount::from(&context.value))
                .map_err(|_| PrecompileError::TransferFailed)?;
        }
        Ok(result)
    }

    /// Checks if word is an existing precompile
    #[inline]
    pub fn is_precompile(addr: &EthAddress) -> bool {
        !addr.is_null() && Self::lookup_precompile(addr).is_some()
    }
}

#[derive(Debug, Error)]
pub enum PrecompileError {
    // EVM precompile errors
    #[error("EC curve error in data passed to precompile: {0:?}")]
    EcErr(CurveError),
    #[error("incorrect input size to precompile")]
    IncorrectInputSize,
    // FVM precompile errors
    #[error("invalid input to precompile")]
    InvalidInput,
    #[error("calling convention forbidden for precompile")]
    CallForbidden,
    #[error("transfering funds to precompile failed")]
    TransferFailed,
    #[error("internal evm error when calling precompile: {0}")]
    VMError(ActorError),
}

impl From<ActorError> for PrecompileError {
    fn from(e: ActorError) -> Self {
        Self::VMError(e)
    }
}
impl From<TryFromIntError> for PrecompileError {
    fn from(_: TryFromIntError) -> Self {
        Self::InvalidInput
    }
}

impl From<OverflowError> for PrecompileError {
    fn from(_: OverflowError) -> Self {
        PrecompileError::InvalidInput
    }
}

impl From<FieldError> for PrecompileError {
    fn from(src: FieldError) -> Self {
        PrecompileError::EcErr(src.into())
    }
}

impl From<CurveError> for PrecompileError {
    fn from(src: CurveError) -> Self {
        PrecompileError::EcErr(src)
    }
}

impl From<GroupError> for PrecompileError {
    fn from(_: GroupError) -> Self {
        PrecompileError::EcErr(CurveError::NotMember)
    }
}

#[derive(Debug, PartialEq, Eq, Clone, Copy)]
pub struct PrecompileContext {
    pub call_type: CallKind,
    pub gas: U256,
    pub value: U256,
}

#[cfg(test)]
mod test {
    use fil_actors_evm_shared::address::EthAddress;
    use fil_actors_runtime::test_utils::MockRuntime;

    use crate::interpreter::precompiles::is_reserved_precompile_address;

    use super::{P256VERIFY_PRECOMPILE_ADDRESS, Precompiles};

    #[test]
    fn is_native_precompile() {
        let addr = EthAddress(hex_literal::hex!("fe00000000000000000000000000000000000001"));
        assert!(Precompiles::<MockRuntime>::is_precompile(&addr));
        assert!(is_reserved_precompile_address(&addr));
    }

    #[test]
    fn is_evm_precompile() {
        let addr = EthAddress(hex_literal::hex!("0000000000000000000000000000000000000001"));
        assert!(Precompiles::<MockRuntime>::is_precompile(&addr));
        assert!(is_reserved_precompile_address(&addr));
    }

    #[test]
    fn is_over_precompile() {
        let addr = EthAddress(hex_literal::hex!("ff00000000000000000000000000000000000001"));
        assert!(!Precompiles::<MockRuntime>::is_precompile(&addr));
        assert!(!is_reserved_precompile_address(&addr));
    }

    #[test]
    fn is_p256verify_precompile() {
        let addr = P256VERIFY_PRECOMPILE_ADDRESS;
        assert!(Precompiles::<MockRuntime>::is_precompile(&addr));
        assert!(is_reserved_precompile_address(&addr));
    }

    #[test]
    fn zero_addr_precompile() {
        let eth_addr = EthAddress(hex_literal::hex!("fe00000000000000000000000000000000000000"));
        let native_addr = EthAddress(hex_literal::hex!("0000000000000000000000000000000000000000"));
        assert!(!Precompiles::<MockRuntime>::is_precompile(&eth_addr));
        assert!(!Precompiles::<MockRuntime>::is_precompile(&native_addr));
        assert!(!is_reserved_precompile_address(&eth_addr));
        assert!(!is_reserved_precompile_address(&native_addr));
    }

    #[test]
    fn between_precompile() {
        let addr = EthAddress(hex_literal::hex!("a000000000000000000000000000000000000001"));
        assert!(!Precompiles::<MockRuntime>::is_precompile(&addr));
        assert!(!is_reserved_precompile_address(&addr));
    }

    #[test]
    fn bad_index() {
        let eth_addr = EthAddress(hex_literal::hex!("fe00000000000000000000000000000000000020"));
        let native_addr = EthAddress(hex_literal::hex!("0000000000000000000000000000000000000020"));
        assert!(!Precompiles::<MockRuntime>::is_precompile(&eth_addr));
        assert!(!Precompiles::<MockRuntime>::is_precompile(&native_addr));
        // reserved doesn't check index is within range
        assert!(is_reserved_precompile_address(&eth_addr));
        assert!(is_reserved_precompile_address(&native_addr));
    }
}
