use fil_actors_evm_shared::address::EthAddress;
use fil_actors_evm_shared::uints::U256;
use fil_actors_runtime::ActorError;
use fil_actors_runtime::EAM_ACTOR_ADDR;
use fil_actors_runtime::{deserialize_block, extract_send_result};
use fvm_ipld_encoding::BytesDe;
use fvm_ipld_encoding::ipld_block::IpldBlock;
use fvm_shared::METHOD_SEND;
use fvm_shared::MethodNum;
use fvm_shared::sys::SendFlags;
use fvm_shared::{address::Address, econ::TokenAmount};

use crate::EVM_CONTRACT_SELFDESTRUCT_FAILED;
use crate::ext::eam;
use crate::interpreter::Output;

use super::memory::{MemoryRegion, get_memory_region};
use {
    crate::interpreter::{ExecutionState, System},
    fil_actors_runtime::runtime::Runtime,
};

#[inline]
pub fn create(
    state: &mut ExecutionState,
    system: &mut System<impl Runtime>,
    endowment: U256,
    offset: U256,
    size: U256,
) -> Result<U256, ActorError> {
    if system.readonly {
        return Err(ActorError::read_only("create called while read-only".into()));
    }
    state.return_data = Vec::new();

    let input_region = get_memory_region(&mut state.memory, offset, size)?;

    let input_data = if let Some(MemoryRegion { offset, size }) = input_region {
        &state.memory[offset..][..size.get()]
    } else {
        &[]
    };

    // We increment the nonce earlier than in the EVM. See the comment in `create2` for details.
    let params = eam::CreateParams { code: input_data.to_vec(), nonce: system.nonce };
    create_common(
        state,
        system,
        IpldBlock::serialize_cbor(&params)?,
        eam::CREATE_METHOD_NUM,
        endowment,
    )
}

pub fn create2(
    state: &mut ExecutionState,
    system: &mut System<impl Runtime>,
    endowment: U256,
    offset: U256,
    size: U256,
    salt: U256,
) -> Result<U256, ActorError> {
    if system.readonly {
        return Err(ActorError::read_only("create2 called while read-only".into()));
    }

    let input_region = get_memory_region(&mut state.memory, offset, size)?;

    // BE encoded array
    let salt: [u8; 32] = salt.to_big_endian();

    let input_data = if let Some(MemoryRegion { offset, size }) = input_region {
        &state.memory[offset..][..size.get()]
    } else {
        &[]
    };
    let params = eam::Create2Params { code: input_data.to_vec(), salt };

    create_common(
        state,
        system,
        IpldBlock::serialize_cbor(&params)?,
        eam::CREATE2_METHOD_NUM,
        endowment,
    )
}

/// call into Ethereum Address Manager to make the new account
#[inline]
fn create_common(
    state: &mut ExecutionState,
    system: &mut System<impl Runtime>,
    params: Option<IpldBlock>,
    method: MethodNum,
    endowment: U256,
) -> Result<U256, ActorError> {
    // First, we clear the return data. We want to do this even if we, e.g., fail due to the
    // endowment.
    state.return_data = Vec::new();

    // Then we explicitly check the endowment. We could just try and deal with the error, but then
    // we'd need to add some logic for decrementing the nonce. It's easier to check up-front.
    let endowment = TokenAmount::from(&endowment);
    if endowment > system.rt.current_balance() {
        return Ok(U256::zero());
    }

    // We increment the nonce earlier than in the EVM, but this is unlikely to cause issues:
    //
    // 1. Like the EVM, we increment the nonce on address conflict (effectively "skipping" the
    //    address).
    // 2. Like the EVM, we increment the nonce even if the target contract runs out of gas.
    // 4. Like the EVM, we don't increment the nonce if the caller doesn't have enough funds to
    //    cover the endowment.
    // 4. Unlike the EVM, we increment the nonce if contract creation fails because we're at the max
    //    stack depth. However, given that there are other ways to increment the nonce without
    //    deploying a contract (e.g., 2), this shouldn't be an issue.
    system.increment_nonce();

    // Apply EIP-150
    let gas_limit = (63 * system.rt.gas_available()) / 64;

    // send bytecode & params to EAM to generate the address and contract
    let ret = system.send(
        &EAM_ACTOR_ADDR,
        method,
        params,
        endowment,
        Some(gas_limit),
        SendFlags::default(),
    );

    Ok(match ret {
        Ok(eam_ret) => {
            let ret: eam::CreateReturn = deserialize_block(eam_ret)?;
            ret.eth_address.as_evm_word()
        }
        Err(mut err) => {
            // Any non-empty return data here always comes from the constructor.
            if let Some(r) = err.take_data() {
                // As with CALL, ignore decode failures and fallback on returning the encoded value.
                state.return_data = r.deserialize().map(|BytesDe(d)| d).unwrap_or_else(|_| r.data);
            }
            U256::zero()
        }
    })
}

#[inline]
pub fn selfdestruct(
    _state: &mut ExecutionState,
    system: &mut System<impl Runtime>,
    pc: usize,
    beneficiary: U256,
) -> Result<Output, ActorError> {
    use crate::interpreter::output::Outcome;

    if system.readonly {
        return Err(ActorError::read_only("selfdestruct called while read-only".into()));
    }

    // Try to give funds to the beneficiary. If this fails, we abort the entire call. This can only
    // fail if:
    //
    // 1. The target address is an embedded ID address and said actor doesn't exist.
    // 2. We're at the maximum call depth.
    // 3. This call would cause us to exceed some system limit (e.g., a memory limit).
    let beneficiary: EthAddress = beneficiary.into();
    let beneficiary: Address = beneficiary.into();
    let balance = system.rt.current_balance();
    extract_send_result(system.rt.send_simple(&beneficiary, METHOD_SEND, None, balance)).map_err(
        |e| {
            ActorError::unchecked(
                EVM_CONTRACT_SELFDESTRUCT_FAILED,
                format!(
                    "failed to transfer funds to beneficiary {beneficiary} on SELFDESTRUCT: {e}"
                ),
            )
        },
    )?;

    // Now mark ourselves as deleted.
    system.mark_selfdestructed();

    // And "return".
    //
    // 1. In the constructor, this will set our code to "empty". This is correct.
    // 2. Otherwise, we'll successfully return nothing to the caller.
    Ok(Output { outcome: Outcome::Return, return_data: Vec::new(), pc })
}

#[cfg(test)]
mod tests {
    use crate::ext::eam;
    use crate::{EVM_CONTRACT_REVERTED, evm_unit_test};

    use fil_actors_evm_shared::uints::U256;
    use fil_actors_runtime::EAM_ACTOR_ADDR;
    use fvm_ipld_encoding::BytesSer;
    use fvm_ipld_encoding::ipld_block::IpldBlock;
    use fvm_shared::METHOD_SEND;
    use fvm_shared::address::Address as FilAddress;
    use fvm_shared::error::{ErrorNumber, ExitCode};
    use fvm_shared::sys::SendFlags;

    #[test]
    fn test_create() {
        let ret_addr = EthAddress(hex_literal::hex!("CAFEB0BA00000000000000000000000000000000"));

        evm_unit_test! {
            (rt) {
                rt.set_balance(TokenAmount::from_atto(1_000_000));

                let code = vec![0x01, 0x02, 0x03, 0x04];
                let nonce = 1;
                let create_params = eam::CreateParams { code, nonce };
                let create_ret = eam::CreateReturn {
                    actor_id: 12345,
                    eth_address: ret_addr,
                    robust_address: Some(ret_addr.into()),
                };

                rt.expect_gas_available(10_000_000_000);
                rt.expect_send(
                    EAM_ACTOR_ADDR,
                    eam::CREATE_METHOD_NUM,
                    IpldBlock::serialize_cbor(&create_params).unwrap(),
                    TokenAmount::from_atto(1234),
                    Some(63 * 10_000_000_000 / 64),
                    SendFlags::empty(),
                    IpldBlock::serialize_cbor(&create_ret).unwrap(),
                    ExitCode::OK,
                    None,
                );
            }
            (m) {
                // input data
                PUSH4; 0x01; 0x02; 0x03; 0x04;
                PUSH0;
                MSTORE;
                // the deed
                CREATE;
            }
            m.state.stack.push(U256::from(4)).unwrap();    // input size
            m.state.stack.push(U256::from(28)).unwrap();   // input offset
            m.state.stack.push(U256::from(1234)).unwrap(); // initial value
            for _ in 0..4 {
                m.step().expect("execution step failed");
            }
            assert_eq!(m.state.stack.len(), 1);
            assert_eq!(m.state.stack.pop().unwrap(), ret_addr.as_evm_word());
            assert_eq!(m.system.nonce, 2);
        };
    }

    #[test]
    fn test_create2() {
        let ret_addr = EthAddress(hex_literal::hex!("CAFEB0BA00000000000000000000000000000000"));

        evm_unit_test! {
            (rt) {
                rt.set_balance(TokenAmount::from_atto(1_000_000));

                let code = vec![0x01, 0x02, 0x03, 0x04];
                let mut salt = [0u8; 32];
                salt[28] = 0xDE;
                salt[29] = 0xAD;
                salt[30] = 0xBE;
                salt[31] = 0xEF;
                let create_params = eam::Create2Params { code, salt };
                let create_ret = eam::CreateReturn {
                    actor_id: 12345,
                    eth_address: ret_addr,
                    robust_address: Some(ret_addr.into()),
                };

                rt.expect_gas_available(10_000_000_000);
                rt.expect_send(
                    EAM_ACTOR_ADDR,
                    eam::CREATE2_METHOD_NUM,
                    IpldBlock::serialize_cbor(&create_params).unwrap(),
                    TokenAmount::from_atto(1234),
                    Some(63 * 10_000_000_000 / 64),
                    SendFlags::empty(),
                    IpldBlock::serialize_cbor(&create_ret).unwrap(),
                    ExitCode::OK,
                    None,
                );
            }
            (m) {
                // input data
                PUSH4; 0x01; 0x02; 0x03; 0x04;
                PUSH0;
                MSTORE;
                // the deed
                CREATE2;
            }
            m.state.return_data = b"deadbeef".to_vec();             // stale return data
            m.state.stack.push(U256::from(0xDEADBEEFu64)).unwrap(); // salt
            m.state.stack.push(U256::from(4)).unwrap();             // input size
            m.state.stack.push(U256::from(28)).unwrap();            // input offset
            m.state.stack.push(U256::from(1234)).unwrap();          // initial value
            for _ in 0..4 {
                m.step().expect("execution step failed");
            }
            assert_eq!(m.state.stack.len(), 1);
            assert_eq!(m.state.stack.pop().unwrap(), ret_addr.as_evm_word());
            assert_eq!(m.system.nonce, 2);
            assert!(m.state.return_data.is_empty());
        };
    }

    #[test]
    fn test_create_fail_eam() {
        // this covers the relevant create2 codepath as well (in create_init)
        evm_unit_test! {
            (rt) {
                rt.set_balance(TokenAmount::from_atto(1_000_000));

                let code = vec![0x01, 0x02, 0x03, 0x04];
                let nonce = 1;
                let create_params = eam::CreateParams { code, nonce };

                rt.expect_gas_available(10_000_000_000);
                rt.expect_send(
                    EAM_ACTOR_ADDR,
                    eam::CREATE_METHOD_NUM,
                    IpldBlock::serialize_cbor(&create_params).unwrap(),
                    TokenAmount::from_atto(1234),
                    Some(63 * 10_000_000_000 / 64),
                    SendFlags::empty(),
                    None,
                    ExitCode::USR_FORBIDDEN,
                    None,
                );
            }
            (m) {
                // input data
                PUSH4; 0x01; 0x02; 0x03; 0x04;
                PUSH0;
                MSTORE;
                // the deed
                CREATE;
            }
            m.state.stack.push(U256::from(4)).unwrap();    // input size
            m.state.stack.push(U256::from(28)).unwrap();   // input offset
            m.state.stack.push(U256::from(1234)).unwrap(); // initial value
            for _ in 0..4 {
                m.step().expect("execution step failed");
            }
            assert_eq!(m.state.stack.len(), 1);
            assert_eq!(m.state.stack.pop().unwrap(), U256::from(0));
            assert_eq!(m.system.nonce, 2);
        };
    }

    #[test]
    fn test_create_fail_nofunds() {
        evm_unit_test! {
            (rt) {
                rt.set_balance(TokenAmount::from_atto(1));
            }
            (m) {
                // input data
                PUSH4; 0x01; 0x02; 0x03; 0x04;
                PUSH0;
                MSTORE;
                // the deed
                CREATE;
            }
            m.state.stack.push(U256::from(4)).unwrap();    // input size
            m.state.stack.push(U256::from(28)).unwrap();   // input offset
            m.state.stack.push(U256::from(1234)).unwrap(); // initial value
            for _ in 0..4 {
                m.step().expect("execution step failed");
            }
            assert_eq!(m.state.stack.len(), 1);
            assert_eq!(m.state.stack.pop().unwrap(), U256::from(0));
            assert_eq!(m.system.nonce, 1);
        };
    }

    #[test]
    fn test_create2_fail_nofunds() {
        evm_unit_test! {
            (rt) {
                rt.set_balance(TokenAmount::from_atto(1));
            }
            (m) {
                // input data
                PUSH4; 0x01; 0x02; 0x03; 0x04;
                PUSH0;
                MSTORE;
                // the deed
                CREATE2;
            }
            m.state.stack.push(U256::from(0xDEADBEEFu64)).unwrap(); // salt
            m.state.stack.push(U256::from(4)).unwrap();    // input size
            m.state.stack.push(U256::from(28)).unwrap();   // input offset
            m.state.stack.push(U256::from(1234)).unwrap(); // initial value
            for _ in 0..4 {
                m.step().expect("execution step failed");
            }
            assert_eq!(m.state.stack.len(), 1);
            assert_eq!(m.state.stack.pop().unwrap(), U256::from(0));
            assert_eq!(m.system.nonce, 1);
        };
    }

    #[test]
    fn test_create_fail_readonly() {
        evm_unit_test! {
            (rt) {
                rt.set_balance(TokenAmount::from_atto(1));
            }
            (m) {
                // input data
                PUSH4; 0x01; 0x02; 0x03; 0x04;
                PUSH0;
                MSTORE;
                // the deed
                CREATE;
            }
            m.system.readonly = true;
            m.state.stack.push(U256::from(4)).unwrap();    // input size
            m.state.stack.push(U256::from(28)).unwrap();   // input offset
            m.state.stack.push(U256::from(1234)).unwrap(); // initial value
            for _ in 0..3 {
                m.step().expect("execution step failed");
            }
            let result = m.step();
            assert!(result.is_err());
            assert_eq!(result.err().unwrap().exit_code(), ExitCode::USR_READ_ONLY);
            assert_eq!(m.system.nonce, 1);
        };
    }

    #[test]
    fn test_create2_fail_readonly() {
        evm_unit_test! {
            (rt) {
                rt.set_balance(TokenAmount::from_atto(1));
            }
            (m) {
                // input data
                PUSH4; 0x01; 0x02; 0x03; 0x04;
                PUSH0;
                MSTORE;
                // the deed
                CREATE2;
            }
            m.system.readonly = true;
            m.state.stack.push(U256::from(0xDEADBEEFu64)).unwrap(); // salt
            m.state.stack.push(U256::from(4)).unwrap();    // input size
            m.state.stack.push(U256::from(28)).unwrap();   // input offset
            m.state.stack.push(U256::from(1234)).unwrap(); // initial value
            for _ in 0..3 {
                m.step().expect("execution step failed");
            }
            let result = m.step();
            assert!(result.is_err());
            assert_eq!(result.err().unwrap().exit_code(), ExitCode::USR_READ_ONLY);
            assert_eq!(m.system.nonce, 1);
        };
    }

    #[test]
    fn test_create_err() {
        // this covers the relevant create2 codepath as well (in create_init)
        evm_unit_test! {
            (rt) {
                rt.set_balance(TokenAmount::from_atto(1_000_000));

                let code = vec![0x01, 0x02, 0x03, 0x04];
                let nonce = 1;
                let create_params = eam::CreateParams { code, nonce };

                rt.expect_gas_available(10_000_000_000);
                rt.expect_send(
                    EAM_ACTOR_ADDR,
                    eam::CREATE_METHOD_NUM,
                    IpldBlock::serialize_cbor(&create_params).unwrap(),
                    TokenAmount::from_atto(1234),
                    Some(63 * 10_000_000_000 / 64),
                    SendFlags::empty(),
                    None,
                    ExitCode::OK,
                    Some(ErrorNumber::IllegalOperation),
                );
            }
            (m) {
                // input data
                PUSH4; 0x01; 0x02; 0x03; 0x04;
                PUSH0;
                MSTORE;
                // the deed
                CREATE;
            }
            m.state.return_data = b"deadbeef".to_vec();    // stale return data
            m.state.stack.push(U256::from(4)).unwrap();    // input size
            m.state.stack.push(U256::from(28)).unwrap();   // input offset
            m.state.stack.push(U256::from(1234)).unwrap(); // initial value
            for _ in 0..4 {
                m.step().expect("execution step failed");
            }
            assert_eq!(m.state.stack.len(), 1);
            assert_eq!(m.state.stack.pop().unwrap(), U256::from(0));
            assert_eq!(m.system.nonce, 2);
            assert!(m.state.return_data.is_empty());
        };
    }

    #[test]
    fn test_create_revert() {
        let revert_data = &b"foobar"[..];
        evm_unit_test! {
            (rt) {
                rt.set_balance(TokenAmount::from_atto(1_000_000));

                let code = vec![0x01, 0x02, 0x03, 0x04];
                let nonce = 1;
                let create_params = eam::CreateParams { code, nonce };
                let create_return = BytesSer(revert_data);

                rt.expect_gas_available(10_000_000_000);
                rt.expect_send(
                    EAM_ACTOR_ADDR,
                    eam::CREATE_METHOD_NUM,
                    IpldBlock::serialize_cbor(&create_params).unwrap(),
                    TokenAmount::from_atto(1234),
                    Some(63 * 10_000_000_000 / 64),
                    SendFlags::empty(),
                    IpldBlock::serialize_cbor(&create_return).unwrap(),
                    EVM_CONTRACT_REVERTED,
                    None,
                );
            }
            (m) {
                // input data
                PUSH4; 0x01; 0x02; 0x03; 0x04;
                PUSH0;
                MSTORE;
                // the deed
                CREATE;
            }
            m.state.return_data = b"deadbeef".to_vec();    // stale return data
            m.state.stack.push(U256::from(4)).unwrap();    // input size
            m.state.stack.push(U256::from(28)).unwrap();   // input offset
            m.state.stack.push(U256::from(1234)).unwrap(); // initial value
            for _ in 0..4 {
                m.step().expect("execution step failed");
            }
            assert_eq!(m.state.stack.len(), 1);
            assert_eq!(m.state.stack.pop().unwrap(), U256::from(0));
            assert_eq!(m.system.nonce, 2);
            assert_eq!(m.state.return_data, revert_data)
        };
    }

    #[test]
    fn test_selfdestruct() {
        // tests the outcome of selfdestruct
        let beneficiary = EthAddress::from_id(1001);
        let fil_beneficiary = FilAddress::new_id(1001);

        evm_unit_test! {
            (rt) {
                rt.set_balance(TokenAmount::from_atto(1_000_000));

                rt.expect_send(
                    fil_beneficiary,
                    METHOD_SEND,
                    None,
                    TokenAmount::from_atto(1_000_000),
                    None,
                    SendFlags::empty(),
                    None,
                    ExitCode::OK,
                    None,
                );
            }
            (m) {
                SELFDESTRUCT;
                // correctness check sled
                INVALID;
            }
            m.state.stack.push(beneficiary.as_evm_word()).unwrap();
            let result = m.execute().expect("execution failed");
            assert_eq!(result.outcome, crate::Outcome::Return);
            assert_eq!(result.return_data.len(), 0);
        }
    }

    #[test]
    fn test_selfdestruct_tombstone() {
        // tests the selfdestruct step to ensure a tombstone is created.
        // can't merge these two tests because rust....
        let beneficiary = EthAddress::from_id(1001);
        let fil_beneficiary = FilAddress::new_id(1001);

        evm_unit_test! {
            (rt) {
                rt.set_balance(TokenAmount::from_atto(1_000_000));
                rt.set_origin(fil_beneficiary);

                rt.expect_send(
                    fil_beneficiary,
                    METHOD_SEND,
                    None,
                    TokenAmount::from_atto(1_000_000),
                    None,
                    SendFlags::empty(),
                    None,
                    ExitCode::OK,
                    None,
                );
            }
            (m) {
                SELFDESTRUCT;
            }
            m.state.stack.push(beneficiary.as_evm_word()).unwrap();
            m.step().expect("execution step failed");
            assert!(m.system.tombstone.is_some());
            assert_eq!(m.system.tombstone.unwrap(),
                       crate::Tombstone {
                           origin: 1001,
                           nonce: 0,
                       });
        }
    }

    #[test]
    fn test_selfdestruct_fail() {
        // tests the outcome of selfdestruct
        let beneficiary = EthAddress::from_id(1001);
        let fil_beneficiary = FilAddress::new_id(1001);

        evm_unit_test! {
            (rt) {
                rt.set_balance(TokenAmount::from_atto(1_000_000));

                rt.expect_send(
                    fil_beneficiary,
                    METHOD_SEND,
                    None,
                    TokenAmount::from_atto(1_000_000),
                    None,
                    SendFlags::empty(),
                    None,
                    ExitCode::USR_FORBIDDEN,
                    None,
                );
            }
            (m) {
                SELFDESTRUCT;
            }
            m.state.stack.push(beneficiary.as_evm_word()).unwrap();
            let result = m.step();
            assert!(result.is_err());
            assert_eq!(result.err().unwrap().exit_code(), crate::EVM_CONTRACT_SELFDESTRUCT_FAILED);
        }
    }
}
