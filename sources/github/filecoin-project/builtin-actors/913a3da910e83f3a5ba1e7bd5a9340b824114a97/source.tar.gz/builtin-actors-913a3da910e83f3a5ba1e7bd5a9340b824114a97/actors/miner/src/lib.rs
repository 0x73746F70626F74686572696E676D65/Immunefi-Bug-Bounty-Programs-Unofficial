// Copyright 2019-2022 ChainSafe Systems
// SPDX-License-Identifier: Apache-2.0, MIT

use std::cmp;
use std::cmp::max;
use std::collections::btree_map::Entry;
use std::collections::{BTreeMap, BTreeSet, HashMap};
use std::ops::Neg;

use anyhow::{Error, anyhow};
use byteorder::{BigEndian, ByteOrder, WriteBytesExt};
use cid::Cid;
use fvm_ipld_bitfield::{BitField, Validate};
use fvm_ipld_blockstore::Blockstore;
use fvm_ipld_encoding::ipld_block::IpldBlock;
use fvm_ipld_encoding::{BytesDe, CborStore, RawBytes, from_slice};
use fvm_shared::address::{Address, Payload, Protocol};
use fvm_shared::bigint::BigInt;
use fvm_shared::clock::ChainEpoch;
use fvm_shared::econ::TokenAmount;
use fvm_shared::error::*;
use fvm_shared::piece::PieceInfo;
use fvm_shared::randomness::*;
use fvm_shared::sector::{
    AggregateSealVerifyInfo, AggregateSealVerifyProofAndInfos, InteractiveSealRandomness,
    PoStProof, RegisteredAggregateProof, RegisteredPoStProof, RegisteredSealProof,
    ReplicaUpdateInfo, SealRandomness, SealVerifyInfo, SectorID, SectorInfo, SectorNumber,
    SectorSize, StoragePower, WindowPoStVerifyInfo,
};
use fvm_shared::{ActorID, METHOD_CONSTRUCTOR, METHOD_SEND, MethodNum};
use itertools::Itertools;
use log::{error, info, warn};
use multihash_codetable::Code::Blake2b256;
use num_derive::FromPrimitive;
use num_traits::{Signed, Zero};

pub use beneficiary::*;
pub use bitfield_queue::*;
pub use commd::*;
pub use deadline_assignment::*;
pub use deadline_info::*;
pub use deadline_state::*;
pub use deadlines::*;
pub use expiration_queue::*;
use fil_actors_runtime::cbor::{serialize, serialize_vec};
use fil_actors_runtime::reward::{FilterEstimate, ThisEpochRewardReturn};
use fil_actors_runtime::runtime::builtins::Type;
use fil_actors_runtime::runtime::policy_constants::{
    CREATE_MINER_DEPOSIT_POWER, MAX_SECTOR_NUMBER,
};
use fil_actors_runtime::runtime::{ActorCode, DomainSeparationTag, Policy, Runtime};
use fil_actors_runtime::{
    ActorContext, ActorDowncast, ActorError, AsActorError, BURNT_FUNDS_ACTOR_ADDR, BatchReturn,
    BatchReturnGen, DealWeight, EPOCHS_IN_DAY, INIT_ACTOR_ADDR, REWARD_ACTOR_ADDR,
    STORAGE_MARKET_ACTOR_ADDR, STORAGE_POWER_ACTOR_ADDR, SYSTEM_ACTOR_ADDR, actor_dispatch,
    actor_error, deserialize_block, extract_send_result, util,
};
pub use monies::*;
pub use partition_state::*;
pub use policy::*;
pub use quantize::*;
pub use sector_map::*;
pub use sectors::*;
pub use state::*;
pub use termination::*;
pub use types::*;
pub use vesting_state::*;

use crate::notifications::{ActivationNotifications, notify_data_consumers};

// The following errors are particular cases of illegal state.
// They're not expected to ever happen, but if they do, distinguished codes can help us
// diagnose the problem.

#[cfg(feature = "fil-actor")]
fil_actors_runtime::wasm_trampoline!(Actor);

mod beneficiary;
mod bitfield_queue;
mod commd;
mod deadline_assignment;
mod deadline_info;
mod deadline_state;
mod deadlines;
mod emit;
mod expiration_queue;
#[doc(hidden)]
pub mod ext;
mod monies;
mod notifications;
mod partition_state;
mod policy;
mod quantize;
mod sector_map;
mod sectors;
mod state;
mod termination;
pub mod testing;
mod types;
mod vesting_state;

/// Storage Miner actor methods available
#[derive(FromPrimitive)]
#[repr(u64)]
pub enum Method {
    Constructor = METHOD_CONSTRUCTOR,
    ControlAddresses = 2,
    ChangeWorkerAddress = 3,
    ChangePeerID = 4,
    SubmitWindowedPoSt = 5,
    //PreCommitSector = 6, // Deprecated
    //ProveCommitSector = 7, // Deprecated
    //ExtendSectorExpiration = 8, // Deprecated
    TerminateSectors = 9,
    DeclareFaults = 10,
    DeclareFaultsRecovered = 11,
    OnDeferredCronEvent = 12,
    CheckSectorProven = 13,
    ApplyRewards = 14,
    ReportConsensusFault = 15,
    WithdrawBalance = 16,
    InternalSectorSetupForPreseal = 17,
    ChangeMultiaddrs = 18,
    CompactPartitions = 19,
    CompactSectorNumbers = 20,
    ConfirmChangeWorkerAddress = 21,
    RepayDebt = 22,
    ChangeOwnerAddress = 23,
    DisputeWindowedPoSt = 24,
    //PreCommitSectorBatch = 25, // Deprecated
    // ProveCommitAggregate = 26, // Deprecated
    // ProveReplicaUpdates = 27, // Deprecated
    PreCommitSectorBatch2 = 28,
    //ProveReplicaUpdates2 = 29, // Deprecated
    ChangeBeneficiary = 30,
    GetBeneficiary = 31,
    ExtendSectorExpiration2 = 32,
    // MovePartitions = 33,
    ProveCommitSectors3 = 34,
    ProveReplicaUpdates3 = 35,
    ProveCommitSectorsNI = 36,
    UpgradeSectorQuality = 37,
    // Method numbers derived from FRC-0042 standards
    ChangeWorkerAddressExported = frc42_dispatch::method_hash!("ChangeWorkerAddress"),
    ChangePeerIDExported = frc42_dispatch::method_hash!("ChangePeerID"),
    WithdrawBalanceExported = frc42_dispatch::method_hash!("WithdrawBalance"),
    ChangeMultiaddrsExported = frc42_dispatch::method_hash!("ChangeMultiaddrs"),
    ConfirmChangeWorkerAddressExported = frc42_dispatch::method_hash!("ConfirmChangeWorkerAddress"),
    RepayDebtExported = frc42_dispatch::method_hash!("RepayDebt"),
    ChangeOwnerAddressExported = frc42_dispatch::method_hash!("ChangeOwnerAddress"),
    ChangeBeneficiaryExported = frc42_dispatch::method_hash!("ChangeBeneficiary"),
    GetBeneficiaryExported = frc42_dispatch::method_hash!("GetBeneficiary"),
    GetOwnerExported = frc42_dispatch::method_hash!("GetOwner"),
    IsControllingAddressExported = frc42_dispatch::method_hash!("IsControllingAddress"),
    GetSectorSizeExported = frc42_dispatch::method_hash!("GetSectorSize"),
    GetAvailableBalanceExported = frc42_dispatch::method_hash!("GetAvailableBalance"),
    GetVestingFundsExported = frc42_dispatch::method_hash!("GetVestingFunds"),
    GetPeerIDExported = frc42_dispatch::method_hash!("GetPeerID"),
    GetMultiaddrsExported = frc42_dispatch::method_hash!("GetMultiaddrs"),
    MaxTerminationFeeExported = frc42_dispatch::method_hash!("MaxTerminationFee"),
    InitialPledgeExported = frc42_dispatch::method_hash!("InitialPledge"),
    GenerateSectorLocationExported = frc42_dispatch::method_hash!("GenerateSectorLocation"),
    ValidateSectorStatusExported = frc42_dispatch::method_hash!("ValidateSectorStatus"),
    GetNominalSectorExpirationExported = frc42_dispatch::method_hash!("GetNominalSectorExpiration"),
}

pub const SECTOR_CONTENT_CHANGED: MethodNum = frc42_dispatch::method_hash!("SectorContentChanged");

pub const ERR_BALANCE_INVARIANTS_BROKEN: ExitCode = ExitCode::new(1000);
pub const ERR_NOTIFICATION_SEND_FAILED: ExitCode = ExitCode::new(1001);
pub const ERR_NOTIFICATION_RECEIVER_ABORTED: ExitCode = ExitCode::new(1002);
pub const ERR_NOTIFICATION_RESPONSE_INVALID: ExitCode = ExitCode::new(1003);
pub const ERR_NOTIFICATION_REJECTED: ExitCode = ExitCode::new(1004);

/// Miner Actor
/// here in order to update the Power Actor to v3.
pub struct Actor;

impl Actor {
    pub fn constructor(
        rt: &impl Runtime,
        params: MinerConstructorParams,
    ) -> Result<(), ActorError> {
        rt.validate_immediate_caller_is(std::iter::once(&INIT_ACTOR_ADDR))?;

        check_control_addresses(rt.policy(), &params.control_addresses)?;
        check_peer_info(rt.policy(), &params.peer_id, &params.multi_addresses)?;
        check_valid_post_proof_type(rt.policy(), params.window_post_proof_type)?;

        let balance = rt.current_balance();
        let deposit = calculate_create_miner_deposit(rt)?;
        if balance < deposit {
            return Err(actor_error!(insufficient_funds;
                "not enough balance to lock for create miner deposit: \
                sent balance {} < deposit {}", balance.atto(), deposit.atto()));
        }

        let owner = rt.resolve_address(&params.owner).ok_or_else(|| {
            actor_error!(illegal_argument, "unable to resolve owner address: {}", params.owner)
        })?;

        let worker = resolve_worker_address(rt, params.worker)?;
        let control_addresses: Vec<_> = params
            .control_addresses
            .into_iter()
            .map(|address| {
                rt.resolve_address(&address).ok_or_else(|| {
                    actor_error!(illegal_argument, "unable to resolve control address: {}", address)
                })
            })
            .collect::<Result<_, _>>()?;

        let policy = rt.policy();
        let current_epoch = rt.curr_epoch();
        let blake2b = |b: &[u8]| rt.hash_blake2b(b);
        let offset =
            assign_proving_period_offset(policy, rt.message().receiver(), current_epoch, blake2b)
                .map_err(|e| {
                e.downcast_default(
                    ExitCode::USR_SERIALIZATION,
                    "failed to assign proving period offset",
                )
            })?;

        let period_start = current_proving_period_start(policy, current_epoch, offset);
        if period_start > current_epoch {
            return Err(actor_error!(
                illegal_state,
                "computed proving period start {} after current epoch {}",
                period_start,
                current_epoch
            ));
        }

        let deadline_idx = current_deadline_index(policy, current_epoch, period_start);
        if deadline_idx >= policy.wpost_period_deadlines {
            return Err(actor_error!(
                illegal_state,
                "computed proving deadline index {} invalid",
                deadline_idx
            ));
        }

        let info = MinerInfo::new(
            owner,
            worker,
            control_addresses,
            params.peer_id,
            params.multi_addresses,
            params.window_post_proof_type,
        )?;
        let info_cid = rt.store().put_cbor(&info, Blake2b256).map_err(|e| {
            e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to construct illegal state")
        })?;

        let store = rt.store();
        let mut st = State::new(policy, store, info_cid, period_start, deadline_idx)?;
        st.add_locked_funds(store, rt.curr_epoch(), &deposit, &REWARD_VESTING_SPEC)
            .map_err(|e| actor_error!(illegal_state, e))?;
        rt.create(&st)?;
        Ok(())
    }

    /// Returns the "controlling" addresses: the owner, the worker, and all control addresses
    fn control_addresses(rt: &impl Runtime) -> Result<GetControlAddressesReturn, ActorError> {
        rt.validate_immediate_caller_accept_any()?;
        let state: State = rt.state()?;
        let info = get_miner_info(rt.store(), &state)?;
        Ok(GetControlAddressesReturn {
            owner: info.owner,
            worker: info.worker,
            control_addresses: info.control_addresses,
        })
    }

    /// Returns the owner address, as well as the proposed new owner (if any).
    fn get_owner(rt: &impl Runtime) -> Result<GetOwnerReturn, ActorError> {
        rt.validate_immediate_caller_accept_any()?;
        let state: State = rt.state()?;
        let info = get_miner_info(rt.store(), &state)?;
        Ok(GetOwnerReturn { owner: info.owner, proposed: info.pending_owner_address })
    }

    /// Returns whether the provided address is "controlling".
    /// The "controlling" addresses are the Owner, the Worker, and all Control Addresses.
    fn is_controlling_address(
        rt: &impl Runtime,
        params: IsControllingAddressParam,
    ) -> Result<IsControllingAddressReturn, ActorError> {
        rt.validate_immediate_caller_accept_any()?;
        let input = match rt.resolve_address(&params.address) {
            Some(a) => Address::new_id(a),
            None => return Ok(IsControllingAddressReturn { is_controlling: false }),
        };
        let state: State = rt.state()?;
        let info = get_miner_info(rt.store(), &state)?;
        let is_controlling =
            info.control_addresses.iter().chain(&[info.worker, info.owner]).any(|a| *a == input);

        Ok(IsControllingAddressReturn { is_controlling })
    }

    /// Returns the miner's sector size.
    fn get_sector_size(rt: &impl Runtime) -> Result<GetSectorSizeReturn, ActorError> {
        rt.validate_immediate_caller_accept_any()?;
        let state: State = rt.state()?;
        let sector_size = get_miner_info(rt.store(), &state)?.sector_size;
        Ok(GetSectorSizeReturn { sector_size })
    }

    /// Returns the available balance of this miner.
    /// This is calculated as actor balance - (vesting funds + pre-commit deposit + ip requirement + fee debt)
    /// Can go negative if the miner is in IP debt.
    fn get_available_balance(rt: &impl Runtime) -> Result<GetAvailableBalanceReturn, ActorError> {
        rt.validate_immediate_caller_accept_any()?;
        let state: State = rt.state()?;
        let available_balance =
            state.get_available_balance(&rt.current_balance()).map_err(|e| {
                actor_error!(illegal_state, "failed to calculate available balance: {}", e)
            })?;
        Ok(GetAvailableBalanceReturn { available_balance })
    }

    /// Returns the funds vesting in this miner as a list of (vesting_epoch, vesting_amount) tuples.
    fn get_vesting_funds(rt: &impl Runtime) -> Result<GetVestingFundsReturn, ActorError> {
        rt.validate_immediate_caller_accept_any()?;
        let state: State = rt.state()?;
        let vesting_funds = state
            .vesting_funds
            .load(rt.store())?
            .into_iter()
            .map(|v| (v.epoch, v.amount))
            .collect_vec();
        Ok(GetVestingFundsReturn { vesting_funds })
    }

    /// Will ALWAYS overwrite the existing control addresses with the control addresses passed in the params.
    /// If an empty addresses vector is passed, the control addresses will be cleared.
    /// A worker change will be scheduled if the worker passed in the params is different from the existing worker.
    fn change_worker_address(
        rt: &impl Runtime,
        params: ChangeWorkerAddressParams,
    ) -> Result<(), ActorError> {
        check_control_addresses(rt.policy(), &params.new_control_addresses)?;

        let new_worker = Address::new_id(resolve_worker_address(rt, params.new_worker)?);
        let control_addresses: Vec<Address> = params
            .new_control_addresses
            .into_iter()
            .map(|address| {
                rt.resolve_address(&address).ok_or_else(|| {
                    actor_error!(illegal_argument, "unable to resolve control address: {}", address)
                })
            })
            .map(|id_result| id_result.map(Address::new_id))
            .collect::<Result<_, _>>()?;

        rt.transaction(|state: &mut State, rt| {
            let mut info = get_miner_info(rt.store(), state)?;

            // Only the Owner is allowed to change the new_worker and control addresses.
            rt.validate_immediate_caller_is(std::iter::once(&info.owner))?;

            // save the new control addresses
            info.control_addresses = control_addresses;

            // save new_worker addr key change request
            if new_worker != info.worker && info.pending_worker_key.is_none() {
                info.pending_worker_key = Some(WorkerKeyChange {
                    new_worker,
                    effective_at: rt.curr_epoch() + rt.policy().worker_key_change_delay,
                })
            }

            state.save_info(rt.store(), &info).map_err(|e| {
                e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "could not save miner info")
            })?;

            Ok(())
        })?;

        Ok(())
    }

    /// Triggers a worker address change if a change has been requested and its effective epoch has arrived.
    fn confirm_change_worker_address(rt: &impl Runtime) -> Result<(), ActorError> {
        rt.transaction(|state: &mut State, rt| {
            let mut info = get_miner_info(rt.store(), state)?;

            rt.validate_immediate_caller_is(std::iter::once(&info.owner))?;

            process_pending_worker(&mut info, rt, state)?;

            Ok(())
        })
    }

    /// Proposes or confirms a change of owner address.
    /// If invoked by the current owner, proposes a new owner address for confirmation. If the proposed address is the
    /// current owner address, revokes any existing proposal.
    /// If invoked by the previously proposed address, with the same proposal, changes the current owner address to be
    /// that proposed address.
    fn change_owner_address(
        rt: &impl Runtime,
        params: ChangeOwnerAddressParams,
    ) -> Result<(), ActorError> {
        let new_address = params.new_owner;
        // * Cannot match go checking for undef address, does go impl allow this to be
        // * deserialized over the wire? If so, a workaround will be needed

        if !matches!(new_address.protocol(), Protocol::ID) {
            return Err(actor_error!(illegal_argument, "owner address must be an ID address"));
        }

        rt.transaction(|state: &mut State, rt| {
            let mut info = get_miner_info(rt.store(), state)?;

            if rt.message().caller() == info.owner || info.pending_owner_address.is_none() {
                rt.validate_immediate_caller_is(std::iter::once(&info.owner))?;
                info.pending_owner_address = Some(new_address);
            } else if let Some(pending_address) = info.pending_owner_address {
                rt.validate_immediate_caller_is(std::iter::once(&pending_address))?;
                if new_address != pending_address {
                    return Err(actor_error!(
                        illegal_argument,
                        "expected confirmation of {} got {}",
                        pending_address,
                        new_address
                    ));
                }

                // Change beneficiary address to new owner if current beneficiary address equal to old owner address
                if info.beneficiary == info.owner {
                    info.beneficiary = pending_address;
                }
                // Cancel pending beneficiary term change when the owner changes
                info.pending_beneficiary_term = None;

                // Set the new owner address
                info.owner = pending_address;
            }

            // Clear any no-op change
            if let Some(p_addr) = info.pending_owner_address
                && p_addr == info.owner
            {
                info.pending_owner_address = None;
            }

            state.save_info(rt.store(), &info).map_err(|e| {
                e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to save miner info")
            })?;

            Ok(())
        })
    }

    /// Returns the Peer ID for this miner.
    fn get_peer_id(rt: &impl Runtime) -> Result<GetPeerIDReturn, ActorError> {
        rt.validate_immediate_caller_accept_any()?;
        let state: State = rt.state()?;
        let peer_id = get_miner_info(rt.store(), &state)?.peer_id;
        Ok(GetPeerIDReturn { peer_id })
    }

    fn change_peer_id(rt: &impl Runtime, params: ChangePeerIDParams) -> Result<(), ActorError> {
        let policy = rt.policy();
        check_peer_info(policy, &params.new_id, &[])?;

        rt.transaction(|state: &mut State, rt| {
            let mut info = get_miner_info(rt.store(), state)?;

            rt.validate_immediate_caller_is(
                info.control_addresses.iter().chain(&[info.worker, info.owner]),
            )?;

            info.peer_id = params.new_id;
            state.save_info(rt.store(), &info).map_err(|e| {
                e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "could not save miner info")
            })?;

            Ok(())
        })?;
        Ok(())
    }

    /// Returns the multiaddresses set for this miner.
    fn get_multiaddresses(rt: &impl Runtime) -> Result<GetMultiaddrsReturn, ActorError> {
        rt.validate_immediate_caller_accept_any()?;
        let state: State = rt.state()?;
        let multi_addrs = get_miner_info(rt.store(), &state)?.multi_address;
        Ok(GetMultiaddrsReturn { multi_addrs })
    }

    fn change_multiaddresses(
        rt: &impl Runtime,
        params: ChangeMultiaddrsParams,
    ) -> Result<(), ActorError> {
        let policy = rt.policy();
        check_peer_info(policy, &[], &params.new_multi_addrs)?;

        rt.transaction(|state: &mut State, rt| {
            let mut info = get_miner_info(rt.store(), state)?;

            rt.validate_immediate_caller_is(
                info.control_addresses.iter().chain(&[info.worker, info.owner]),
            )?;

            info.multi_address = params.new_multi_addrs;
            state.save_info(rt.store(), &info).map_err(|e| {
                e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "could not save miner info")
            })?;

            Ok(())
        })?;
        Ok(())
    }

    /// Invoked by miner's worker address to submit their fallback post
    fn submit_windowed_post(
        rt: &impl Runtime,
        mut params: SubmitWindowedPoStParams,
    ) -> Result<(), ActorError> {
        let current_epoch = rt.curr_epoch();

        {
            let policy = rt.policy();
            if params.proofs.len() != 1 {
                return Err(actor_error!(
                    illegal_argument,
                    "expected exactly one proof, got {}",
                    params.proofs.len()
                ));
            }

            if check_valid_post_proof_type(policy, params.proofs[0].post_proof).is_err() {
                return Err(actor_error!(
                    illegal_argument,
                    "proof type {:?} not allowed",
                    params.proofs[0].post_proof
                ));
            }

            if params.deadline >= policy.wpost_period_deadlines {
                return Err(actor_error!(
                    illegal_argument,
                    "invalid deadline {} of {}",
                    params.deadline,
                    policy.wpost_period_deadlines
                ));
            }

            if params.chain_commit_rand.0.len() > RANDOMNESS_LENGTH {
                return Err(actor_error!(
                    illegal_argument,
                    "expected at most {} bytes of randomness, got {}",
                    RANDOMNESS_LENGTH,
                    params.chain_commit_rand.0.len()
                ));
            }
        }

        let post_result = rt.transaction(|state: &mut State, rt| {
            let info = get_miner_info(rt.store(), state)?;

            let max_proof_size = info.window_post_proof_type.proof_size().map_err(|e| {
                actor_error!(illegal_state, "failed to determine max window post proof size: {}", e)
            })?;

            rt.validate_immediate_caller_is(
                info.control_addresses.iter().chain(&[info.worker, info.owner]),
            )?;

            // Make sure the miner is using the correct proof type.
            if params.proofs[0].post_proof != info.window_post_proof_type {
                return Err(actor_error!(
                    illegal_argument,
                    "expected proof of type {:?}, got {:?}",
                    info.window_post_proof_type,
                    params.proofs[0].post_proof
                ));
            }

            // Make sure the proof size doesn't exceed the max. We could probably check for an exact match, but this is safer.
            let max_size = max_proof_size * params.partitions.len();
            if params.proofs[0].proof_bytes.len() > max_size {
                return Err(actor_error!(
                    illegal_argument,
                    "expected proof to be smaller than {} bytes",
                    max_size
                ));
            }

            // Validate that the miner didn't try to prove too many partitions at once.
            let submission_partition_limit = cmp::min(
                load_partitions_sectors_max(rt.policy(), info.window_post_partition_sectors),
                rt.policy().posted_partitions_max,
            );

            if params.partitions.len() as u64 > submission_partition_limit {
                return Err(actor_error!(
                    illegal_argument,
                    "too many partitions {}, limit {}",
                    params.partitions.len(),
                    submission_partition_limit
                ));
            }
            let current_deadline = state.deadline_info(rt.policy(), current_epoch);

            // Check that the miner state indicates that the current proving deadline has started.
            // This should only fail if the cron actor wasn't invoked, and matters only in case that it hasn't been
            // invoked for a whole proving period, and hence the missed PoSt submissions from the prior occurrence
            // of this deadline haven't been processed yet.
            if !current_deadline.is_open() {
                return Err(actor_error!(
                    illegal_state,
                    "proving period {} not yet open at {}",
                    current_deadline.period_start,
                    current_epoch
                ));
            }

            // The miner may only submit a proof for the current deadline.
            if params.deadline != current_deadline.index {
                return Err(actor_error!(
                    illegal_argument,
                    "invalid deadline {} at epoch {}, expected {}",
                    params.deadline,
                    current_epoch,
                    current_deadline.index
                ));
            }

            // Verify that the PoSt was committed to the chain at most
            // WPoStChallengeLookback+WPoStChallengeWindow in the past.
            if params.chain_commit_epoch < current_deadline.challenge {
                return Err(actor_error!(
                    illegal_argument,
                    "expected chain commit epoch {} to be after {}",
                    params.chain_commit_epoch,
                    current_deadline.challenge
                ));
            }

            if params.chain_commit_epoch >= current_epoch {
                return Err(actor_error!(
                    illegal_argument,
                    "chain commit epoch {} must be less than the current epoch {}",
                    params.chain_commit_epoch,
                    current_epoch
                ));
            }

            // Verify the chain commit randomness
            let comm_rand = rt.get_randomness_from_tickets(
                DomainSeparationTag::PoStChainCommit,
                params.chain_commit_epoch,
                &[],
            )?;
            if Randomness(comm_rand.into()) != params.chain_commit_rand {
                return Err(actor_error!(illegal_argument, "post commit randomness mismatched"));
            }

            let sectors = Sectors::load(rt.store(), &state.sectors).map_err(|e| {
                e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to load sectors")
            })?;

            let mut deadlines =
                state.load_deadlines(rt.store()).map_err(|e| e.wrap("failed to load deadlines"))?;

            let mut deadline = deadlines.load_deadline(rt.store(), params.deadline)?;

            // Record proven sectors/partitions, returning updates to power and the final set of sectors
            // proven/skipped.
            //
            // NOTE: This function does not actually check the proofs but does assume that they're correct. Instead,
            // it snapshots the deadline's state and the submitted proofs at the end of the challenge window and
            // allows third-parties to dispute these proofs.
            //
            // While we could perform _all_ operations at the end of challenge window, we do as we can here to avoid
            // overloading cron.
            let policy = rt.policy();
            let fault_expiration = current_deadline.last() + policy.fault_max_age;
            let post_result = deadline
                .record_proven_sectors(
                    rt.store(),
                    &sectors,
                    info.sector_size,
                    current_deadline.quant_spec(),
                    fault_expiration,
                    &mut params.partitions,
                )
                .map_err(|e| {
                    e.downcast_default(
                        ExitCode::USR_ILLEGAL_STATE,
                        format!(
                            "failed to process post submission for deadline {}",
                            params.deadline
                        ),
                    )
                })?;

            // Make sure we actually proved something.
            let proven_sectors = &post_result.sectors - &post_result.ignored_sectors;
            if proven_sectors.is_empty() {
                // Abort verification if all sectors are (now) faults. There's nothing to prove.
                // It's not rational for a miner to submit a Window PoSt marking *all* non-faulty sectors as skipped,
                // since that will just cause them to pay a penalty at deadline end that would otherwise be zero
                // if they had *not* declared them.
                return Err(actor_error!(
                    illegal_argument,
                    "cannot prove partitions with no active sectors"
                ));
            }
            // If we're not recovering power, record the proof for optimistic verification.
            if post_result.recovered_power.is_zero() {
                deadline
                    .record_post_proofs(rt.store(), &post_result.partitions, &params.proofs)
                    .map_err(|e| {
                        e.downcast_default(
                            ExitCode::USR_ILLEGAL_STATE,
                            "failed to record proof for optimistic verification",
                        )
                    })?
            } else {
                // Load sector infos for proof, substituting a known-good sector for known-faulty sectors.
                // Note: this is slightly sub-optimal, loading info for the recovering sectors again after they were already
                // loaded above.
                let sector_infos = sectors
                    .load_for_proof(&post_result.sectors, &post_result.ignored_sectors)
                    .map_err(|e| {
                        e.downcast_default(
                            ExitCode::USR_ILLEGAL_STATE,
                            "failed to load sectors for post verification",
                        )
                    })?;
                if !verify_windowed_post(
                    rt,
                    current_deadline.challenge,
                    &sector_infos,
                    params.proofs,
                )
                .map_err(|e| e.wrap("window post failed"))?
                {
                    return Err(actor_error!(illegal_argument, "invalid post was submitted"));
                }
            }

            let deadline_idx = params.deadline;
            deadlines.update_deadline(policy, rt.store(), params.deadline, &deadline).map_err(
                |e| {
                    e.downcast_default(
                        ExitCode::USR_ILLEGAL_STATE,
                        format!("failed to update deadline {}", deadline_idx),
                    )
                },
            )?;

            state.save_deadlines(rt.store(), deadlines).map_err(|e| {
                e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to save deadlines")
            })?;

            Ok(post_result)
        })?;

        // Restore power for recovered sectors. Remove power for new faults.
        // NOTE: It would be permissible to delay the power loss until the deadline closes, but that would require
        // additional accounting state.
        // https://github.com/filecoin-project/specs-actors/issues/414
        request_update_power(rt, post_result.power_delta)?;

        let state: State = rt.state()?;
        state.check_balance_invariants(&rt.current_balance()).map_err(balance_invariants_broken)?;

        Ok(())
    }

    fn prove_replica_updates3(
        rt: &impl Runtime,
        params: ProveReplicaUpdates3Params,
    ) -> Result<ProveReplicaUpdates3Return, ActorError> {
        let state: State = rt.state()?;
        let store = rt.store();
        let info = get_miner_info(store, &state)?;

        // Validate parameters.
        rt.validate_immediate_caller_is(
            info.control_addresses.iter().chain(&[info.worker, info.owner]),
        )?;
        if !params.sector_proofs.is_empty() {
            if !params.aggregate_proof.is_empty() {
                return Err(actor_error!(
                    illegal_argument,
                    "exactly one of sector proofs or aggregate proof must be non-empty"
                ));
            }
            if params.aggregate_proof_type.is_some() {
                return Err(actor_error!(
                    illegal_argument,
                    "aggregate proof type must be empty when sector proofs are specified"
                ));
            }
        } else {
            if params.aggregate_proof.is_empty() {
                return Err(actor_error!(
                    illegal_argument,
                    "exactly one of sector proofs or aggregate proof must be non-empty"
                ));
            }
            if params.aggregate_proof_type.is_none() {
                return Err(actor_error!(
                    illegal_argument,
                    "aggregate proof type must be specified when aggregate proof is specified"
                ));
            }
        }
        if params.sector_proofs.is_empty() == params.aggregate_proof.is_empty() {
            return Err(actor_error!(
                illegal_argument,
                "exactly one of sector proofs or aggregate proof must be non-empty"
            ));
        }

        // Load sector infos for validation, failing if any don't exist.
        let sectors = Sectors::load(&store, &state.sectors)
            .context_code(ExitCode::USR_ILLEGAL_STATE, "failed to load sectors array")?;
        let mut sector_infos = Vec::with_capacity(params.sector_updates.len());
        for update in &params.sector_updates {
            sector_infos.push(sectors.must_get(update.sector)?);
        }

        // Validate inputs.
        let validation_batch = validate_replica_updates(
            &params,
            &sector_infos,
            &state,
            rt.policy(),
            rt.curr_epoch(),
            store,
        )?;
        let valid_sector_infos = validation_batch.successes(&sector_infos);
        let valid_manifests = validation_batch.successes(&params.sector_updates);

        let mut sector_commds: HashMap<SectorNumber, CompactCommD> =
            HashMap::with_capacity(params.sector_updates.len());

        // Verify proofs before activating anything.
        let mut proven_manifests: Vec<(&SectorUpdateManifest, &SectorOnChainInfo)> = vec![];
        let mut proven_batch_gen = BatchReturnGen::new(validation_batch.success_count as usize);
        if !params.sector_proofs.is_empty() {
            // Batched proofs, one per sector
            if params.sector_updates.len() != params.sector_proofs.len() {
                return Err(actor_error!(
                    illegal_argument,
                    "mismatched lengths: {} sector updates, {} proofs",
                    params.sector_updates.len(),
                    params.sector_proofs.len()
                ));
            }

            let valid_proofs = validation_batch.successes(&params.sector_proofs);
            for ((sector_info, manifest), proof) in
                valid_sector_infos.into_iter().zip(valid_manifests).zip(valid_proofs)
            {
                let sector_type = sector_info.seal_proof;
                let computed_commd = unsealed_cid_from_pieces(rt, &manifest.pieces, sector_type)?;
                let proof_inputs = ReplicaUpdateInfo {
                    update_proof_type: params.update_proofs_type,
                    new_sealed_cid: manifest.new_sealed_cid,
                    old_sealed_cid: sector_info.sealed_cid,
                    new_unsealed_cid: computed_commd.get_cid(sector_type)?,
                    proof: proof.clone().into(),
                };
                sector_commds.insert(manifest.sector, computed_commd);
                match rt.verify_replica_update(&proof_inputs) {
                    Ok(_) => {
                        proven_manifests.push((manifest, sector_info));
                        proven_batch_gen.add_success();
                    }
                    Err(e) => {
                        warn!(
                            "failed to verify replica update for sector {}: {e}",
                            sector_info.sector_number
                        );
                        proven_batch_gen.add_fail(ExitCode::USR_ILLEGAL_ARGUMENT);
                        if params.require_activation_success {
                            return Err(actor_error!(
                                illegal_argument,
                                "invalid proof for sector {} while requiring activation success: {}",
                                sector_info.sector_number,
                                e
                            ));
                        }
                    }
                }
            }
        } else {
            return Err(actor_error!(
                illegal_argument,
                "aggregate update proofs not yet supported"
            ));
            // proven_batch_gen.add_successes(valid_manifests.len());
        }
        if proven_manifests.is_empty() {
            return Err(actor_error!(illegal_argument, "no valid updates"));
        }
        let proven_batch = proven_batch_gen.generate();
        if proven_batch.success_count == 0 {
            return Err(actor_error!(illegal_argument, "no valid proofs specified"));
        }

        // Activate data.
        let sector_spaces = proven_manifests
            .iter()
            .map(|(update, _)| total_piece_space(update.sector, &update.pieces))
            .collect::<Result<Vec<_>, _>>()?;

        let mut state_updates_by_partition =
            BTreeMap::<(u64, u64), Vec<ReplicaUpdateStateInputs>>::new();
        for ((update, sector_info), space) in proven_manifests.iter().zip(sector_spaces) {
            state_updates_by_partition
                .entry((update.deadline, update.partition))
                .or_default()
                .push(ReplicaUpdateStateInputs {
                    sector_info,
                    seal_cid: update.new_sealed_cid,
                    space,
                });
        }

        let (power_delta, pledge_delta) =
            update_replica_states(rt, &state_updates_by_partition, info.sector_size)?;

        notify_pledge_changed(rt, &pledge_delta)?;
        request_update_power(rt, power_delta)?;

        // Notify data consumers.
        let mut notifications: Vec<ActivationNotifications> = vec![];
        for (update, sector_info) in proven_manifests {
            notifications.push(ActivationNotifications {
                sector_number: update.sector,
                sector_expiration: sector_info.expiration,
                pieces: &update.pieces,
            });

            let pieces: Vec<PieceInfo> =
                update.pieces.iter().map(|x| PieceInfo { cid: x.cid, size: x.size }).collect();

            emit::sector_updated(
                rt,
                update.sector,
                sector_commds.get(&update.sector).unwrap().0,
                &pieces,
            )?;
        }
        notify_data_consumers(rt, &notifications, params.require_notification_success)?;

        let result = util::stack(&[validation_batch, proven_batch]);
        Ok(ProveReplicaUpdates3Return { activation_results: result })
    }

    fn dispute_windowed_post(
        rt: &impl Runtime,
        params: DisputeWindowedPoStParams,
    ) -> Result<(), ActorError> {
        rt.validate_immediate_caller_accept_any()?;
        let reporter = rt.message().caller();

        {
            let policy = rt.policy();
            if params.deadline >= policy.wpost_period_deadlines {
                return Err(actor_error!(
                    illegal_argument,
                    "invalid deadline {} of {}",
                    params.deadline,
                    policy.wpost_period_deadlines
                ));
            }
        }
        let current_epoch = rt.curr_epoch();

        // Note: these are going to be slightly inaccurate as time
        // will have moved on from when the post was actually
        // submitted.
        //
        // However, these are estimates _anyways_.
        let epoch_reward = request_current_epoch_block_reward(rt)?;
        let power_total = request_current_total_power(rt)?;

        let (pledge_delta, mut to_burn, power_delta, to_reward) =
            rt.transaction(|st: &mut State, rt| {
                let policy = rt.policy();
                let dl_info = st.deadline_info(policy, current_epoch);

                if !deadline_available_for_optimistic_post_dispute(
                    policy,
                    dl_info.period_start,
                    params.deadline,
                    current_epoch,
                ) {
                    return Err(actor_error!(
                        forbidden,
                        "can only dispute window posts during the dispute window \
                    ({} epochs after the challenge window closes)",
                        policy.wpost_dispute_window
                    ));
                }

                let info = get_miner_info(rt.store(), st)?;
                // --- check proof ---

                // Find the proving period start for the deadline in question.
                let mut pp_start = dl_info.period_start;
                if dl_info.index < params.deadline {
                    pp_start -= policy.wpost_proving_period
                }
                let target_deadline =
                    new_deadline_info(policy, pp_start, params.deadline, current_epoch);
                // Load the target deadline
                let mut deadlines_current = st
                    .load_deadlines(rt.store())
                    .map_err(|e| e.wrap("failed to load deadlines"))?;

                let mut dl_current =
                    deadlines_current.load_deadline(rt.store(), params.deadline)?;

                // Take the post from the snapshot for dispute.
                // This operation REMOVES the PoSt from the snapshot so
                // it can't be disputed again. If this method fails,
                // this operation must be rolled back.
                let (partitions, proofs) =
                    dl_current.take_post_proofs(rt.store(), params.post_index).map_err(|e| {
                        e.downcast_default(
                            ExitCode::USR_ILLEGAL_STATE,
                            "failed to load proof for dispute",
                        )
                    })?;

                // When handling a dispute we need two different views of the deadline, one
                // from a snapshot taken when the deadline closed, and one from the current state.
                // The snapshot supplies what the disputed proof was submitted against (the
                // optimistic proof, the sector set and their sealed CIDs, and the claimed power
                // being disputed). The current state supplies the live state that the dispute will
                // change (the partition bookkeeping, and the sector records that give each newly
                // faulty sector the power and fee it holds now).
                // Compaction is excluded from the dispute window so both views agree on partition
                // membership. Sectors extended, upgraded or snapped since the close are faulted
                // from _live_ records below.
                let mut dispute_info = dl_current
                    .load_partitions_for_dispute(rt.store(), partitions)
                    .map_err(|e| {
                        e.downcast_default(
                            ExitCode::USR_ILLEGAL_STATE,
                            "failed to load partition for dispute",
                        )
                    })?;

                // Snapshot power, what the proof claimed, including sectors since terminated
                // or changed. For penalty base only.
                let penalised_power = dispute_info.disputed_power.clone();

                // Snapshot records, the proof inputs.
                let sectors =
                    Sectors::load(rt.store(), &dl_current.sectors_snapshot).map_err(|e| {
                        e.downcast_default(
                            ExitCode::USR_ILLEGAL_STATE,
                            "failed to load sectors array",
                        )
                    })?;
                let sector_infos = sectors
                    .load_for_proof(&dispute_info.all_sector_nos, &dispute_info.ignored_sector_nos)
                    .map_err(|e| {
                        e.downcast_default(
                            ExitCode::USR_ILLEGAL_STATE,
                            "failed to load sectors to dispute window post",
                        )
                    })?;

                // Check proof, we fail if validation succeeds.
                if verify_windowed_post(rt, target_deadline.challenge, &sector_infos, proofs)? {
                    return Err(actor_error!(illegal_argument, "failed to dispute valid post"));
                } else {
                    info!("Successfully disputed post- window post was invalid");
                }

                // Live records: a fault removes the power and fee the sector holds now, which
                // will differ from the snapshot for any sector snapped, upgraded or extended since.
                // Sectors terminated since are skipped by record_faults.
                let live_sectors = Sectors::load(rt.store(), &st.sectors).map_err(|e| {
                    e.downcast_default(
                        ExitCode::USR_ILLEGAL_STATE,
                        "failed to load live sectors array",
                    )
                })?;
                let fault_expiration_epoch = target_deadline.last() + policy.fault_max_age;
                let power_delta = dl_current
                    .record_faults(
                        rt.store(),
                        &live_sectors,
                        info.sector_size,
                        quant_spec_for_deadline(policy, &target_deadline),
                        fault_expiration_epoch,
                        &mut dispute_info.disputed_sectors,
                    )
                    .map_err(|e| {
                        e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to declare faults")
                    })?;

                deadlines_current
                    .update_deadline(policy, rt.store(), params.deadline, &dl_current)
                    .map_err(|e| {
                        e.downcast_default(
                            ExitCode::USR_ILLEGAL_STATE,
                            format!("failed to update deadline {}", params.deadline),
                        )
                    })?;

                st.save_deadlines(rt.store(), deadlines_current).map_err(|e| {
                    e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to save deadlines")
                })?;

                // --- penalties ---

                // Calculate the base penalty.
                let penalty_base = pledge_penalty_for_invalid_windowpost(
                    &epoch_reward.this_epoch_reward_smoothed,
                    &power_total.quality_adj_power_smoothed,
                    &penalised_power.qa,
                );

                // Calculate the target reward.
                let reward_target =
                    reward_for_disputed_window_post(info.window_post_proof_type, penalised_power);

                // Compute the target penalty by adding the
                // base penalty to the target reward. We don't
                // take reward out of the penalty as the miner
                // could end up receiving a substantial
                // portion of their fee back as a reward.
                let penalty_target = &penalty_base + &reward_target;
                st.apply_penalty(&penalty_target)
                    .map_err(|e| actor_error!(illegal_state, "failed to apply penalty {}", e))?;
                let (to_burn, total_unlocked) = st
                    .repay_partial_debt_in_priority_order(
                        rt.store(),
                        current_epoch,
                        &rt.current_balance(),
                    )
                    .map_err(|e| {
                        e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to pay debt")
                    })?;

                // Now, move as much of the target reward as
                // we can from the burn to the reward.
                let to_reward = std::cmp::min(&to_burn, &reward_target);
                let to_burn = &to_burn - to_reward;
                let pledge_delta = total_unlocked.neg();

                Ok((pledge_delta, to_burn, power_delta, to_reward.clone()))
            })?;

        request_update_power(rt, power_delta)?;
        if !to_reward.is_zero()
            && let Err(e) =
                extract_send_result(rt.send_simple(&reporter, METHOD_SEND, None, to_reward.clone()))
        {
            error!("failed to send reward: {}", e);
            to_burn += to_reward;
        }

        burn_funds(rt, to_burn)?;
        notify_pledge_changed(rt, &pledge_delta)?;

        let st: State = rt.state()?;
        st.check_balance_invariants(&rt.current_balance()).map_err(balance_invariants_broken)?;
        Ok(())
    }

    /// Pledges the miner to seal and commit some new sectors.
    /// The caller specifies sector numbers, sealed sector CIDs, unsealed sector CID, seal randomness epoch, expiration, and the IDs
    /// of any storage deals contained in the sector data. The storage deal proposals must be already submitted
    /// to the storage market actor.
    /// This method calculates the sector's power, locks a pre-commit deposit for the sector, stores information about the
    /// sector in state and waits for it to be proven or expire.
    fn pre_commit_sector_batch2(
        rt: &impl Runtime,
        params: PreCommitSectorBatchParams2,
    ) -> Result<(), ActorError> {
        let sectors = params.sectors;
        let curr_epoch = rt.curr_epoch();
        if sectors.is_empty() {
            return Err(actor_error!(illegal_argument, "batch empty"));
        }
        // Check per-sector preconditions before opening state transaction or sending other messages.
        let challenge_earliest = curr_epoch - rt.policy().max_pre_commit_randomness_lookback;
        let mut sector_numbers = BitField::new();
        for precommit in sectors.iter() {
            let set = sector_numbers.get(precommit.sector_number);
            if set {
                return Err(actor_error!(
                    illegal_argument,
                    "duplicate sector number {}",
                    precommit.sector_number
                ));
            }
            sector_numbers.set(precommit.sector_number);

            // Deals are no longer activated at pre-commit; a deal-bearing pre-commit could
            // never be proven, so reject it before it wastes a deposit.
            if !precommit.deal_ids.is_empty() {
                return Err(actor_error!(
                    illegal_argument,
                    "sector {} has deal ids, pre-committed deals are no longer supported",
                    precommit.sector_number
                ));
            }

            if !can_pre_commit_seal_proof(rt.policy(), precommit.seal_proof) {
                return Err(actor_error!(
                    illegal_argument,
                    "unsupported seal proof type {}",
                    i64::from(precommit.seal_proof)
                ));
            }
            if precommit.sector_number > MAX_SECTOR_NUMBER {
                return Err(actor_error!(
                    illegal_argument,
                    "sector number {} out of range 0..(2^63-1)",
                    precommit.sector_number
                ));
            }
            // Skip checking if CID is defined because it cannot be so in Rust

            if !is_sealed_sector(&precommit.sealed_cid) {
                return Err(actor_error!(illegal_argument, "sealed CID had wrong prefix"));
            }
            if precommit.seal_rand_epoch >= curr_epoch {
                return Err(actor_error!(
                    illegal_argument,
                    "seal challenge epoch {} must be before now {}",
                    precommit.seal_rand_epoch,
                    curr_epoch
                ));
            }
            if precommit.seal_rand_epoch < challenge_earliest {
                return Err(actor_error!(
                    illegal_argument,
                    "seal challenge epoch {} too old, must be after {}",
                    precommit.seal_rand_epoch,
                    challenge_earliest
                ));
            }

            if let Some(commd) = &precommit.unsealed_cid.0
                && !is_unsealed_sector(commd)
            {
                return Err(actor_error!(illegal_argument, "unsealed CID had wrong prefix"));
            }

            // Require sector lifetime meets minimum by assuming activation happens at last epoch permitted for seal proof.
            // This could make sector maximum lifetime validation more lenient if the maximum sector limit isn't hit first.
            let max_activation = curr_epoch
                + max_prove_commit_duration(rt.policy(), precommit.seal_proof).unwrap_or_default();
            validate_expiration(
                rt.policy(),
                curr_epoch,
                max_activation,
                precommit.expiration,
                precommit.seal_proof,
            )?;
        }
        // gather information from other actors
        let reward_stats = request_current_epoch_block_reward(rt)?;
        let power_total = request_current_total_power(rt)?;
        let mut fee_to_burn = TokenAmount::zero();
        let mut needs_cron = false;
        rt.transaction(|state: &mut State, rt| {
            // Available balance already accounts for fee debt so it is correct to call this before
            // repay_debts. We would have to subtract fee debt explicitly if we called this after.
            let available_balance = state
                .get_available_balance(&rt.current_balance())
                .map_err(|e| {
                    actor_error!(
                        illegal_state,
                        "failed to calculate available balance: {}",
                        e
                    )
                })?;
            fee_to_burn = repay_debts_or_abort(rt, state)?;

            let info = get_miner_info(rt.store(), state)?;

            rt.validate_immediate_caller_is(
                info.control_addresses
                    .iter()
                    .chain(&[info.worker, info.owner]),
            )?;
            let store = rt.store();
            if consensus_fault_active(&info, curr_epoch) {
                return Err(actor_error!(forbidden, "pre-commit not allowed during active consensus fault"));
            }

            let mut chain_infos = Vec::with_capacity(sectors.len());
            let mut total_deposit_required = TokenAmount::zero();
            let mut clean_up_events = Vec::with_capacity(sectors.len());

            let sector_weight_for_deposit = qa_power_max(info.sector_size);
            let deposit_req = pre_commit_deposit_for_power(&reward_stats.this_epoch_reward_smoothed, &power_total.quality_adj_power_smoothed, &sector_weight_for_deposit);

            for precommit in sectors.into_iter() {
                // Sector must have the same Window PoSt proof type as the miner's recorded seal type.
                let sector_wpost_proof = precommit.seal_proof
                    .registered_window_post_proof()
                    .map_err(|_e|
                        actor_error!(
                        illegal_argument,
                        "failed to lookup Window PoSt proof type for sector seal proof {}",
                        i64::from(precommit.seal_proof)
                    ))?;
                if sector_wpost_proof != info.window_post_proof_type {
                    return Err(actor_error!(illegal_argument, "sector Window PoSt proof type %d must match miner Window PoSt proof type {} (seal proof type {})", i64::from(sector_wpost_proof), i64::from(info.window_post_proof_type)));
                }
                // The declared CommD is recorded as given: the seal proof binds CommR to
                // CommD at prove-commit, and piece manifests are checked against it there.
                let on_chain_precommit = SectorPreCommitInfo {
                    seal_proof: precommit.seal_proof,
                    sector_number: precommit.sector_number,
                    sealed_cid: precommit.sealed_cid,
                    seal_rand_epoch: precommit.seal_rand_epoch,
                    deal_ids: precommit.deal_ids,
                    expiration: precommit.expiration,
                    unsealed_cid: precommit.unsealed_cid,
                };

                // Build on-chain record.
                chain_infos.push(SectorPreCommitOnChainInfo {
                    info: on_chain_precommit,
                    pre_commit_deposit: deposit_req.clone(),
                    pre_commit_epoch: curr_epoch,
                });

                total_deposit_required += &deposit_req;

                // Calculate pre-commit cleanup
                let seal_proof = precommit.seal_proof;
                let msd = max_prove_commit_duration(rt.policy(), seal_proof)
                    .ok_or_else(|| actor_error!(illegal_argument, "no max seal duration set for proof type: {}", i64::from(seal_proof)))?;
                // PreCommitCleanUpDelay > 0 here is critical for the batch verification of proofs. Without it, if a proof arrived exactly on the
                // due epoch, ProveCommitSector would accept it, then the expiry event would remove it, and then
                // ConfirmSectorProofsValid would fail to find it.
                let clean_up_bound = curr_epoch + msd + rt.policy().expired_pre_commit_clean_up_delay;
                clean_up_events.push((clean_up_bound, precommit.sector_number));
            }
            // Batch update actor state.
            if available_balance < total_deposit_required {
                return Err(actor_error!(insufficient_funds, "insufficient funds {} for pre-commit deposit: {}", available_balance, total_deposit_required));
            }
            state.add_pre_commit_deposit(&total_deposit_required)
                .map_err(|e|
                    actor_error!(
                        illegal_state,
                        "failed to add pre-commit deposit {}: {}",
                        total_deposit_required, e
                ))?;
            state.allocate_sector_numbers(store, &sector_numbers, CollisionPolicy::DenyCollisions)?;
            state.put_precommitted_sectors(store, chain_infos)
                .map_err(|e|
                    e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to write pre-committed sectors")
                )?;
            state.add_pre_commit_clean_ups(rt.policy(), store, clean_up_events)
                .map_err(|e| {
                    e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to add pre-commit expiry to queue")
                })?;

            for sector_num in sector_numbers.iter() {
                emit::sector_precommitted(rt, sector_num)?;
            }
            // Activate miner cron
            needs_cron = !state.deadline_cron_active;
            state.deadline_cron_active = true;
            Ok(())
        })?;
        burn_funds(rt, fee_to_burn)?;
        let state: State = rt.state()?;
        state.check_balance_invariants(&rt.current_balance()).map_err(balance_invariants_broken)?;
        if needs_cron {
            let new_dl_info = state.deadline_info(rt.policy(), curr_epoch);
            enroll_cron_event(
                rt,
                new_dl_info.last(),
                CronEventPayload { event_type: CRON_EVENT_PROVING_DEADLINE },
            )?;
        }
        Ok(())
    }

    fn prove_commit_sectors3(
        rt: &impl Runtime,
        params: ProveCommitSectors3Params,
    ) -> Result<ProveCommitSectors3Return, ActorError> {
        let state: State = rt.state()?;
        let store = rt.store();
        let policy = rt.policy();
        let miner_id = rt.message().receiver().id().unwrap();
        let info = get_miner_info(rt.store(), &state)?;

        // Validate caller and parameters.
        rt.validate_immediate_caller_is(
            info.control_addresses.iter().chain(&[info.worker, info.owner]),
        )?;

        // Load pre-commits, failing if any don't exist.
        let sector_numbers = params.sector_activations.iter().map(|sa| sa.sector_number);
        let precommits =
            state.get_precommitted_sectors(store, sector_numbers).context("loading precommits")?;
        if precommits.is_empty() {
            return Err(actor_error!(illegal_argument, "no sectors to prove"));
        }

        if params.sector_proofs.is_empty() == params.aggregate_proof.is_empty() {
            return Err(actor_error!(
                illegal_argument,
                "exactly one of sector proofs or aggregate proof must be non-empty"
            ));
        }

        if !params.sector_proofs.is_empty() {
            // Batched proofs, one per sector
            if params.aggregate_proof_type.is_some() {
                return Err(actor_error!(
                    illegal_argument,
                    "aggregate proof type must be null with batched proofs"
                ));
            }
            if params.sector_activations.len() != params.sector_proofs.len() {
                return Err(actor_error!(
                    illegal_argument,
                    "mismatched lengths: {} sector activations, {} proofs",
                    params.sector_activations.len(),
                    params.sector_proofs.len()
                ));
            }
            validate_seal_proofs(precommits[0].info.seal_proof, &params.sector_proofs)?;
        } else {
            if params.aggregate_proof_type != Some(RegisteredAggregateProof::SnarkPackV2) {
                return Err(actor_error!(
                    illegal_argument,
                    "aggregate proof type must be SnarkPackV2"
                ));
            }
            validate_seal_aggregate_proof(
                &params.aggregate_proof,
                params.sector_activations.len() as u64,
                policy,
                true,
            )?;
        }

        // Validate pre-commits.
        let (validation_batch, proof_inputs) =
            validate_precommits(rt, &precommits, params.require_activation_success)?;
        if validation_batch.success_count == 0 {
            return Err(actor_error!(illegal_argument, "no valid precommits specified"));
        }
        let valid_precommits = validation_batch.successes(&precommits);
        let valid_activation_inputs = validation_batch.successes(&params.sector_activations);
        let eligible_activation_inputs_iter = valid_activation_inputs.iter().zip(valid_precommits);

        // Verify seal proof(s), either batch or aggregate.
        let mut proven_activation_inputs: Vec<(
            &SectorActivationManifest,
            &SectorPreCommitOnChainInfo,
        )> = vec![];
        let mut proven_batch_gen = BatchReturnGen::new(validation_batch.success_count as usize);
        if !params.sector_proofs.is_empty() {
            // Verify batched proofs.
            // Filter proof inputs to those for valid pre-commits.
            let seal_verify_inputs: Vec<SealVerifyInfo> = validation_batch
                .successes(&proof_inputs)
                .iter()
                .zip(validation_batch.successes(&params.sector_proofs))
                .map(|(info, proof)| -> SealVerifyInfo {
                    info.to_seal_verify_info(miner_id, proof)
                })
                .collect();

            let res = rt
                .batch_verify_seals(&seal_verify_inputs)
                .context_code(ExitCode::USR_ILLEGAL_ARGUMENT, "failed to batch verify")?;

            // Filter eligible activations to those that were proven.
            for (verified, (activation, precommit)) in
                res.iter().zip(eligible_activation_inputs_iter)
            {
                if *verified {
                    proven_activation_inputs.push((*activation, precommit));
                    proven_batch_gen.add_success();
                } else {
                    proven_batch_gen.add_fail(ExitCode::USR_ILLEGAL_ARGUMENT);
                    if params.require_activation_success {
                        return Err(actor_error!(
                            illegal_argument,
                            "invalid proof for sector {} while requiring activation success: {:?}",
                            precommit.info.sector_number,
                            res
                        ));
                    }
                }
            }
        } else {
            // Verify a single aggregate proof.
            verify_aggregate_seal(
                rt,
                // All the proof inputs, even for invalid pre-commits,
                // must be provided as witnesses to the aggregate proof.
                &proof_inputs,
                miner_id,
                precommits[0].info.seal_proof,
                params.aggregate_proof_type.unwrap(),
                &params.aggregate_proof,
            )?;

            // All eligible activations are proven.
            proven_activation_inputs = eligible_activation_inputs_iter
                .map(|(activation, precommit)| (*activation, precommit))
                .collect();
            proven_batch_gen.add_successes(proven_activation_inputs.len());
        }
        let proven_batch = proven_batch_gen.generate();
        if proven_batch.success_count == 0 {
            return Err(actor_error!(illegal_argument, "no valid proofs specified"));
        }

        // Activate data and verify CommD matches the declared one.
        let sector_spaces = proven_activation_inputs
            .iter()
            .map(|(activation, precommit)| {
                validate_commd(rt, activation, precommit)?;
                total_piece_space(activation.sector_number, &activation.pieces)
            })
            .collect::<Result<Vec<_>, _>>()?;
        let successful_precommits =
            proven_activation_inputs.iter().map(|(_, second)| *second).collect();

        // Activate sector info state
        let rew = request_current_epoch_block_reward(rt)?;
        let pwr = request_current_total_power(rt)?;
        let circulating_supply = rt.total_fil_circ_supply();
        let pledge_inputs = NetworkPledgeInputs {
            network_qap: pwr.quality_adj_power_smoothed,
            network_baseline: rew.this_epoch_baseline_power,
            circulating_supply,
            epoch_reward: rew.this_epoch_reward_smoothed,
            epochs_since_ramp_start: rt.curr_epoch() - pwr.ramp_start_epoch,
            ramp_duration_epochs: pwr.ramp_duration_epochs,
        };
        activate_new_sector_infos(rt, successful_precommits, sector_spaces, &pledge_inputs, &info)?;

        // Notify data consumers.
        let mut notifications: Vec<ActivationNotifications> = vec![];
        for (activations, sector) in &proven_activation_inputs {
            notifications.push(ActivationNotifications {
                sector_number: activations.sector_number,
                sector_expiration: sector.info.expiration,
                pieces: &activations.pieces,
            });

            let pieces: Vec<PieceInfo> =
                activations.pieces.iter().map(|p| PieceInfo { cid: p.cid, size: p.size }).collect();
            let unsealed_cid = sector.info.unsealed_cid.0;

            emit::sector_activated(rt, sector.info.sector_number, unsealed_cid, &pieces)?;
        }
        notify_data_consumers(rt, &notifications, params.require_notification_success)?;

        let result = util::stack(&[validation_batch, proven_batch]);
        Ok(ProveCommitSectors3Return { activation_results: result })
    }

    /// Turns genesis preseal precommits into live sectors. System-callable only.
    /// Preseal sectors have no pieces and have the FULL_QA_POWER flag set.
    fn internal_sector_setup_preseal(
        rt: &impl Runtime,
        params: InternalSectorSetupForPresealParams,
    ) -> Result<(), ActorError> {
        rt.validate_immediate_caller_is(std::iter::once(&SYSTEM_ACTOR_ADDR))?;
        let st: State = rt.state()?;
        let store = rt.store();
        // This skips missing pre-commits.
        let precommited_sectors =
            st.find_precommitted_sectors(store, &params.sectors).map_err(|e| {
                e.downcast_default(
                    ExitCode::USR_ILLEGAL_STATE,
                    "failed to load pre-committed sectors",
                )
            })?;
        let info = get_miner_info(rt.store(), &st)?;

        let pledge_inputs = NetworkPledgeInputs {
            network_qap: params.quality_adj_power_smoothed,
            network_baseline: params.reward_baseline_power,
            circulating_supply: rt.total_fil_circ_supply(),
            epoch_reward: params.reward_smoothed,
            epochs_since_ramp_start: 0,
            ramp_duration_epochs: 0,
        };
        activate_new_sector_infos(
            rt,
            precommited_sectors.iter().collect(),
            vec![0; precommited_sectors.len()],
            &pledge_inputs,
            &info,
        )?;

        for pc in &precommited_sectors {
            emit::sector_activated(rt, pc.info.sector_number, pc.info.unsealed_cid.0, &[])?;
        }

        Ok(())
    }

    fn prove_commit_sectors_ni(
        rt: &impl Runtime,
        params: ProveCommitSectorsNIParams,
    ) -> Result<ProveCommitSectorsNIReturn, ActorError> {
        let policy = rt.policy();
        let curr_epoch = rt.curr_epoch();
        let state: State = rt.state()?;
        let store = rt.store();
        let info = get_miner_info(rt.store(), &state)?;

        validate_seal_aggregate_proof(
            &params.aggregate_proof,
            params.sectors.len() as u64,
            policy,
            false,
        )?;

        rt.validate_immediate_caller_is(
            info.control_addresses.iter().chain(&[info.worker, info.owner]),
        )?;

        if params.proving_deadline >= policy.wpost_period_deadlines {
            return Err(actor_error!(
                illegal_argument,
                "proving deadline index {} invalid",
                params.proving_deadline
            ));
        }

        if !deadline_is_mutable(
            policy,
            state.current_proving_period_start(policy, curr_epoch),
            params.proving_deadline,
            curr_epoch,
        ) {
            return Err(actor_error!(
                forbidden,
                "proving deadline {} must not be the current or next deadline ",
                params.proving_deadline
            ));
        }

        if consensus_fault_active(&info, rt.curr_epoch()) {
            return Err(actor_error!(
                forbidden,
                "ProveCommitSectorsNI not allowed during active consensus fault"
            ));
        }

        if !can_prove_commit_ni_seal_proof(rt.policy(), params.seal_proof_type) {
            return Err(actor_error!(
                illegal_argument,
                "unsupported seal proof type {}",
                i64::from(params.seal_proof_type)
            ));
        }

        if params.aggregate_proof_type != RegisteredAggregateProof::SnarkPackV2 {
            return Err(actor_error!(illegal_argument, "aggregate proof type must be SnarkPackV2"));
        }

        let (validation_batch, proof_inputs, sector_numbers) = validate_ni_sectors(
            rt,
            &params.sectors,
            params.seal_proof_type,
            params.require_activation_success,
        )?;

        if validation_batch.success_count == 0 {
            return Err(actor_error!(illegal_argument, "no valid NI commits specified"));
        }
        let valid_sectors = validation_batch.successes(&params.sectors);

        verify_aggregate_seal(
            rt,
            // All the proof inputs, even for invalid activations,
            // must be provided as witnesses to the aggregate proof.
            &proof_inputs,
            valid_sectors[0].sealer_id,
            params.seal_proof_type,
            params.aggregate_proof_type,
            &params.aggregate_proof,
        )?;

        // FIP-0118: all new sectors get 10x QA power regardless of content.
        let qa_sector_power = qa_power_max(info.sector_size);

        let rew = request_current_epoch_block_reward(rt)?;
        let pwr = request_current_total_power(rt)?;
        let circulating_supply = rt.total_fil_circ_supply();
        let pledge_inputs = NetworkPledgeInputs {
            network_qap: pwr.quality_adj_power_smoothed,
            network_baseline: rew.this_epoch_baseline_power,
            circulating_supply,
            epoch_reward: rew.this_epoch_reward_smoothed,
            epochs_since_ramp_start: rt.curr_epoch() - pwr.ramp_start_epoch,
            ramp_duration_epochs: pwr.ramp_duration_epochs,
        };

        let sector_initial_pledge = pledge_inputs.initial_pledge_for_power(&qa_sector_power);

        let circulating_supply = rt.total_fil_circ_supply();
        // Same fee for all sectors: same size, all raw
        let daily_fee = daily_proof_fee(policy, &circulating_supply, &qa_sector_power);

        let sectors_to_add = valid_sectors
            .iter()
            .map(|sector| SectorOnChainInfo {
                sector_number: sector.sector_number,
                seal_proof: params.seal_proof_type,
                sealed_cid: sector.sealed_cid,
                deprecated_deal_ids: vec![],
                expiration: sector.expiration,
                activation: curr_epoch,
                deal_weight: DealWeight::zero(),
                verified_deal_weight: DealWeight::zero(),
                initial_pledge: sector_initial_pledge.clone(),
                expected_day_reward: None,
                expected_storage_pledge: None,
                power_base_epoch: curr_epoch,
                replaced_day_reward: None,
                sector_key_cid: None,
                flags: SectorOnChainInfoFlags::SIMPLE_QA_POWER
                    | SectorOnChainInfoFlags::FULL_QA_POWER,
                daily_fee: daily_fee.clone(),
            })
            .collect::<Vec<SectorOnChainInfo>>();

        let sectors_len = sectors_to_add.len();

        let total_pledge = BigInt::from(sectors_len) * sector_initial_pledge;

        let (needs_cron, fee_to_burn) = rt.transaction(|state: &mut State, rt| {
            let current_balance = rt.current_balance();
            let available_balance =
                state.get_unlocked_balance(&current_balance).with_context_code(
                    ExitCode::USR_ILLEGAL_STATE,
                    || "failed to calculate unlocked balance",
                )?;
            if available_balance < total_pledge {
                return Err(actor_error!(
                    insufficient_funds,
                    "insufficient funds for aggregate initial pledge requirement {}, available: {}",
                    total_pledge,
                    available_balance
                ));
            }
            let needs_cron = !state.deadline_cron_active;
            state.deadline_cron_active = true;

            state.allocate_sector_numbers(
                store,
                &sector_numbers,
                CollisionPolicy::DenyCollisions,
            )?;

            state
                .put_sectors(store, sectors_to_add.clone())
                .with_context_code(ExitCode::USR_ILLEGAL_STATE, || "failed to put new sectors")?;

            state.assign_sectors_to_deadline(
                policy,
                store,
                rt.curr_epoch(),
                sectors_to_add,
                info.window_post_partition_sectors,
                info.sector_size,
                params.proving_deadline,
            )?;

            state.add_initial_pledge(&total_pledge).with_context_code(
                ExitCode::USR_ILLEGAL_STATE,
                || "failed to add initial pledgs",
            )?;

            let fee_to_burn = repay_debts_or_abort(rt, state)?;

            Ok((needs_cron, fee_to_burn))
        })?;

        burn_funds(rt, fee_to_burn)?;

        notify_pledge_changed(rt, &total_pledge)?;

        let state: State = rt.state()?;
        state.check_balance_invariants(&rt.current_balance()).map_err(balance_invariants_broken)?;

        for sector in valid_sectors.iter() {
            emit::sector_activated(rt, sector.sector_number, None, &[])?;
        }

        if needs_cron {
            let new_dl_info = state.deadline_info(rt.policy(), curr_epoch);
            enroll_cron_event(
                rt,
                new_dl_info.last(),
                CronEventPayload { event_type: CRON_EVENT_PROVING_DEADLINE },
            )?;
        }

        Ok(ProveCommitSectorsNIReturn { activation_results: validation_batch })
    }
    /// Returns the maximum termination fee calculation for a given initial pledge and power amount
    fn max_termination_fee(
        rt: &impl Runtime,
        params: MaxTerminationFeeParams,
    ) -> Result<MaxTerminationFeeReturn, ActorError> {
        rt.validate_immediate_caller_accept_any()?;
        let reward_smoothed = request_current_epoch_block_reward(rt)?.this_epoch_reward_smoothed;
        let quality_adj_power_smoothed =
            request_current_total_power(rt)?.quality_adj_power_smoothed;
        let fault_fee = pledge_penalty_for_continued_fault(
            &reward_smoothed,
            &quality_adj_power_smoothed,
            &params.power,
        );

        let max_fee = pledge_penalty_for_termination(
            &params.initial_pledge,
            TERMINATION_LIFETIME_CAP * EPOCHS_IN_DAY,
            &fault_fee,
        );

        Ok(MaxTerminationFeeReturn { max_fee })
    }

    /// Returns the miner's total initial pledge amount
    fn initial_pledge(rt: &impl Runtime) -> Result<InitialPledgeReturn, ActorError> {
        rt.validate_immediate_caller_accept_any()?;
        let state: State = rt.state()?;

        Ok(InitialPledgeReturn { initial_pledge: state.initial_pledge })
    }

    /// Generates sector location and status information.
    /// This is an expensive operation that searches through all deadlines and partitions
    /// to find a sector. Designed to be called offline.
    /// Returns (NO_DEADLINE, NO_PARTITION) if the sector is not tracked in any partition
    /// (e.g. compacted terminated sector or never committed).
    fn generate_sector_location(
        rt: &impl Runtime,
        params: GenerateSectorLocationParams,
    ) -> Result<GenerateSectorLocationReturn, ActorError> {
        rt.validate_immediate_caller_accept_any()?;

        let state: State = rt.state()?;

        // Check sectors AMT first to preempt expensive search when sector is
        // completely removed from state or does not exist.
        let sector_info = state.get_sector(rt.store(), params.sector_number)?;
        if sector_info.is_none() {
            let sector_location = SectorLocation { deadline: NO_DEADLINE, partition: NO_PARTITION };
            let aux_data = fvm_ipld_encoding::to_vec(&sector_location)
                .map_err(|e| actor_error!(illegal_state, e.description))?;
            return Ok(GenerateSectorLocationReturn { status: SectorStatusCode::Dead, aux_data });
        }

        // It is an invariant that all sectors in the AMT have a valid partition.
        let (deadline_idx, partition_idx) = state
            .find_sector(rt.store(), params.sector_number)
            .map_err(|e| actor_error!(illegal_state, "failed to find sector location: {}", e))?;

        // Load partition to determine status
        let deadlines = state.load_deadlines(rt.store())?;
        let deadline = deadlines.load_deadline(rt.store(), deadline_idx)?;
        let partition = deadline.load_partition(rt.store(), partition_idx)?;

        let current_status = if partition.terminated.get(params.sector_number) {
            SectorStatusCode::Dead
        } else if partition.faults.get(params.sector_number) {
            SectorStatusCode::Faulty
        } else {
            SectorStatusCode::Active
        };

        let sector_location =
            SectorLocation { deadline: deadline_idx as i64, partition: partition_idx as i64 };
        let aux_data = fvm_ipld_encoding::to_vec(&sector_location)
            .map_err(|e| actor_error!(illegal_state, e.description))?;

        Ok(GenerateSectorLocationReturn { status: current_status, aux_data })
    }

    /// Validates sector status using pre-computed location data.
    /// This is a cheap operation that directly loads the partition using provided
    /// location indices and checks if the current status matches the expected status.
    fn validate_sector_status(
        rt: &impl Runtime,
        params: ValidateSectorStatusParams,
    ) -> Result<ValidateSectorStatusReturn, ActorError> {
        rt.validate_immediate_caller_accept_any()?;

        let state: State = rt.state()?;

        // Deserialize aux_data to extract sector location
        let sector_location: SectorLocation = fvm_ipld_encoding::from_slice(&params.aux_data)
            .map_err(|e| actor_error!(illegal_argument, "invalid aux_data: {}", e))?;

        let no_deadline = sector_location.deadline == NO_DEADLINE;
        let no_partition = sector_location.partition == NO_PARTITION;

        // Mixed NO/non-NO is an invalid location
        if no_deadline != no_partition {
            return Err(actor_error!(
                illegal_argument,
                "invalid sector location: deadline and partition must both be NO or both be set"
            ));
        }

        if no_deadline {
            // (NO_DEADLINE, NO_PARTITION) can invalidate Live and Faulty sectors
            // and validate Dead sectors if sector is "found" here.
            // But it cannot confirm status if not found and will error
            let sector_info = state.get_sector(rt.store(), params.sector_number)?;
            if sector_info.is_none() {
                return Ok(ValidateSectorStatusReturn {
                    valid: params.status == SectorStatusCode::Dead,
                });
            }
            return Err(actor_error!(
                not_found,
                "sector {} not found at NO_DEADLINE, NO_PARTITION",
                params.sector_number
            ));
        }

        // Load partition directly using provided location indices
        let deadlines =
            state.load_deadlines(rt.store()).map_err(|e| e.wrap("failed to load deadlines"))?;
        let deadline = deadlines
            .load_deadline(rt.store(), sector_location.deadline as u64)
            .map_err(|e| e.wrap("failed to load deadline"))?;
        let partition = deadline.load_partition(rt.store(), sector_location.partition as u64)?;

        // Sector must exist at the provided location
        if !partition.sectors.get(params.sector_number) {
            return Err(actor_error!(
                not_found,
                "sector {} not found at deadline {} partition {}",
                params.sector_number,
                sector_location.deadline,
                sector_location.partition
            ));
        }

        let terminated = partition.terminated.get(params.sector_number);
        let faulty = partition.faults.get(params.sector_number);

        let valid = match params.status {
            SectorStatusCode::Active => !terminated && !faulty,
            SectorStatusCode::Dead => terminated,
            SectorStatusCode::Faulty => faulty,
        };

        Ok(ValidateSectorStatusReturn { valid })
    }

    /// Returns the nominal sector expiration epoch from the sectors AMT.
    /// Fails if the sector is not present in the sectors AMT.
    fn get_nominal_sector_expiration(
        rt: &impl Runtime,
        params: SectorNumber,
    ) -> Result<GetNominalSectorExpirationReturn, ActorError> {
        rt.validate_immediate_caller_accept_any()?;

        let state: State = rt.state()?;
        let sector_info = state
            .get_sector(rt.store(), params)?
            .ok_or_else(|| actor_error!(not_found, "sector {} not found", params))?;

        Ok(GetNominalSectorExpirationReturn { expiration: sector_info.expiration })
    }

    fn check_sector_proven(
        rt: &impl Runtime,
        params: CheckSectorProvenParams,
    ) -> Result<(), ActorError> {
        rt.validate_immediate_caller_accept_any()?;

        if params.sector_number > MAX_SECTOR_NUMBER {
            return Err(actor_error!(illegal_argument, "sector number out of range"));
        }

        let st: State = rt.state()?;

        match st.get_sector(rt.store(), params.sector_number) {
            Err(e) => Err(actor_error!(
                illegal_state,
                "failed to load proven sector {}: {}",
                params.sector_number,
                e
            )),
            Ok(None) => Err(actor_error!(not_found, "sector {} not proven", params.sector_number)),
            Ok(Some(_sector)) => Ok(()),
        }
    }

    // Extends sector expirations. Declarations may name sectors carrying FIL+ claims; those
    // claims are no longer consulted, so such sectors extend like any other and extension
    // never changes power.
    fn extend_sector_expiration2(
        rt: &impl Runtime,
        params: ExtendSectorExpiration2Params,
    ) -> Result<(), ActorError> {
        let policy = rt.policy();
        let curr_epoch = rt.curr_epoch();
        for decl in &params.extensions {
            validate_deadline_index(policy, decl.deadline)?;
            validate_sector_selection(
                decl.deadline,
                decl.partition,
                decl.sectors.is_empty() && decl.sectors_with_claims.is_empty(),
            )?;
            validate_expiration_bounds(policy, curr_epoch, decl.new_expiration)?;
        }

        let extensions: Vec<ValidatedExpirationExtension> =
            params.extensions.into_iter().map(Into::into).collect();
        let circulating_supply = rt.total_fil_circ_supply();
        let (power_delta, pledge_delta) = rt.transaction(|state: &mut State, rt| {
            let info = get_miner_info(rt.store(), state)?;
            rt.validate_immediate_caller_is(
                info.control_addresses.iter().chain(&[info.worker, info.owner]),
            )?;

            let rewrite_sector = |decl: &ValidatedExpirationExtension,
                                  sector: &SectorOnChainInfo| {
                match decl.new_expiration {
                    Some(new_expiration) => extend_sector_committment(
                        policy,
                        curr_epoch,
                        &circulating_supply,
                        new_expiration,
                        sector,
                        info.sector_size,
                    )
                    .map(Some),
                    None => Err(actor_error!(
                        illegal_state,
                        "missing expiration for sector {}",
                        sector.sector_number
                    )),
                }
            };

            replace_sector_records(
                policy,
                rt.store(),
                state,
                info.sector_size,
                &extensions,
                rewrite_sector,
            )
        })?;

        // Extension restates a sector's weights over the new duration, preserving its quality,
        // so the delta is zero or slightly negative where floor division shaves the restated
        // verified weight.
        request_update_power(rt, power_delta)?;

        // Extension does not recalculate pledge, so this is expected to be zero.
        notify_pledge_changed(rt, &pledge_delta)?;
        Ok(())
    }

    /// Upgrades sectors to full quality-adjusted power (FIP-0118), optionally also
    /// extending their expiration, and locks the pledge top-up the new power requires.
    ///
    /// May only be called by the miner's owner, worker, or a control address. Each
    /// declaration addresses active sectors in one partition; a declaration without a
    /// new expiration upgrades its sectors in place, leaving their expirations, power
    /// base epochs and weights untouched. A sector already at full power is not upgraded
    /// and its pledge is not raised: with a new expiration it is extended exactly as
    /// `ExtendSectorExpiration2` would, without one it is skipped, so repeating a call
    /// locks nothing.
    ///
    /// Once all pre FIP-0118 sectors in the network are upgraded or terminated, this
    /// method becomes a no-op and can be removed.
    ///
    /// # Errors
    /// Aborts with `USR_INSUFFICIENT_FUNDS` unless the available balance covers the
    /// whole batch's pledge increase and any outstanding fee debt, which is repaid in
    /// the same call. Any invalid declaration or non-active sector fails the whole
    /// message; no partial upgrade is applied.
    fn upgrade_sector_quality(
        rt: &impl Runtime,
        params: UpgradeSectorQualityParams,
    ) -> Result<(), ActorError> {
        let state: State = rt.state()?;
        let info = get_miner_info(rt.store(), &state)?;
        rt.validate_immediate_caller_is(
            info.control_addresses.iter().chain(&[info.worker, info.owner]),
        )?;
        let policy = rt.policy();
        let curr_epoch = rt.curr_epoch();
        validate_upgrade_quality_extensions(policy, curr_epoch, &params.upgrades)?;

        let rew = request_current_epoch_block_reward(rt)?;
        let pow = request_current_total_power(rt)?;
        let pledge_inputs = NetworkPledgeInputs {
            network_qap: pow.quality_adj_power_smoothed,
            network_baseline: rew.this_epoch_baseline_power,
            circulating_supply: rt.total_fil_circ_supply(),
            epoch_reward: rew.this_epoch_reward_smoothed,
            epochs_since_ramp_start: curr_epoch - pow.ramp_start_epoch,
            ramp_duration_epochs: pow.ramp_duration_epochs,
        };

        let full_qa_power = qa_power_max(info.sector_size);
        let full_power_pledge = pledge_inputs.initial_pledge_for_power(&full_qa_power);

        let rewrite_sector = |decl: &ValidatedExpirationExtension, sector: &SectorOnChainInfo| {
            // Already at full power, by flag or by weights, there is nothing to
            // upgrade or re-pledge: the sector is only extended if asked, else
            // skipped rather than failed.
            let at_full_power = qa_power_for_sector(info.sector_size, sector) >= full_qa_power;
            match (at_full_power, decl.new_expiration) {
                (true, None) => Ok(None),
                (true, Some(new_expiration)) => extend_sector_committment(
                    policy,
                    curr_epoch,
                    &pledge_inputs.circulating_supply,
                    new_expiration,
                    sector,
                    info.sector_size,
                )
                .map(Some),
                (false, _) => upgrade_sector_to_full_power(
                    policy,
                    curr_epoch,
                    decl.new_expiration,
                    sector,
                    info.sector_size,
                    &pledge_inputs.circulating_supply,
                    &full_power_pledge,
                )
                .map(Some),
            }
        };

        let (power_delta, pledge_delta, fee_to_burn) = rt.transaction(|state: &mut State, rt| {
            let declarations: Vec<ValidatedExpirationExtension> =
                params.upgrades.into_iter().map(|e| e.into()).collect();
            let (power_delta, pledge_delta) = replace_sector_records(
                policy,
                rt.store(),
                state,
                info.sector_size,
                &declarations,
                rewrite_sector,
            )?;

            // Lock the pledge top-up, checking funds before adding it so a shortfall
            // reports the true available balance. Fee debt must be repaid in full in
            // the same call.
            let current_balance = rt.current_balance();
            if pledge_delta.is_positive() {
                let available_balance =
                    state.get_available_balance(&current_balance).map_err(|e| {
                        actor_error!(illegal_state, "failed to calculate available balance: {}", e)
                    })?;
                if available_balance < pledge_delta {
                    return Err(actor_error!(
                        insufficient_funds,
                        "insufficient funds for aggregate initial pledge requirement {}, available: {}",
                        pledge_delta,
                        available_balance
                    ));
                }
            }

            state
                .add_initial_pledge(&pledge_delta)
                .map_err(|e| actor_error!(illegal_state, "failed to add initial pledge: {}", e))?;

            let fee_to_burn = repay_debts_or_abort(rt, state)?;
            Ok((power_delta, pledge_delta, fee_to_burn))
        })?;

        burn_funds(rt, fee_to_burn)?;
        request_update_power(rt, power_delta)?;
        notify_pledge_changed(rt, &pledge_delta)?;

        let state: State = rt.state()?;
        state.check_balance_invariants(&rt.current_balance()).map_err(balance_invariants_broken)?;
        Ok(())
    }

    /// Marks some sectors as terminated at the present epoch, earlier than their
    /// scheduled termination, and adds these sectors to the early termination queue.
    /// This method then processes up to AddressedSectorsMax sectors and
    /// AddressedPartitionsMax partitions from the early termination queue,
    /// terminating deals, paying fines, and returning pledge collateral. While
    /// sectors remain in this queue:
    ///
    ///  1. The miner will be unable to withdraw funds.
    ///  2. The chain will process up to AddressedSectorsMax sectors and
    ///     AddressedPartitionsMax per epoch until the queue is empty.
    ///
    /// The sectors are immediately ignored for Window PoSt proofs, and should be
    /// masked in the same way as faulty sectors. A miner may not terminate sectors in the
    /// current deadline or the next deadline to be proven.
    ///
    /// This function may be invoked with no new sectors to explicitly process the
    /// next batch of sectors.
    fn terminate_sectors(
        rt: &impl Runtime,
        params: TerminateSectorsParams,
    ) -> Result<TerminateSectorsReturn, ActorError> {
        // Note: this cannot terminate pre-committed but un-proven sectors.
        // They must be allowed to expire (and deposit burnt).

        let mut to_process = DeadlineSectorMap::new();

        for term in params.terminations {
            let deadline = term.deadline;
            let partition = term.partition;

            to_process.add(rt.policy(), deadline, partition, term.sectors).map_err(|e| {
                actor_error!(
                    illegal_argument,
                    "failed to process deadline {}, partition {}: {}",
                    deadline,
                    partition,
                    e
                )
            })?;
        }

        {
            let policy = rt.policy();
            to_process
                .check(policy.addressed_partitions_max, policy.addressed_sectors_max)
                .map_err(|e| {
                    actor_error!(illegal_argument, "cannot process requested parameters: {}", e)
                })?;
        }

        let (had_early_terminations, power_delta) = rt.transaction(|state: &mut State, rt| {
            let had_early_terminations = have_pending_early_terminations(state);

            let info = get_miner_info(rt.store(), state)?;

            rt.validate_immediate_caller_is(
                info.control_addresses.iter().chain(&[info.worker, info.owner]),
            )?;

            let store = rt.store();
            let curr_epoch = rt.curr_epoch();
            let mut power_delta = PowerPair::zero();

            let mut deadlines =
                state.load_deadlines(store).map_err(|e| e.wrap("failed to load deadlines"))?;

            // We're only reading the sectors, so there's no need to save this back.
            // However, we still want to avoid re-loading this array per-partition.
            let sectors = Sectors::load(store, &state.sectors).map_err(|e| {
                e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to load sectors")
            })?;

            for (deadline_idx, partition_sectors) in to_process.iter() {
                // If the deadline is the current or next deadline to prove, don't allow terminating sectors.
                // We assume that deadlines are immutable when being proven.
                if !deadline_is_mutable(
                    rt.policy(),
                    state.current_proving_period_start(rt.policy(), curr_epoch),
                    deadline_idx,
                    curr_epoch,
                ) {
                    return Err(actor_error!(
                        illegal_argument,
                        "cannot terminate sectors in immutable deadline {}",
                        deadline_idx
                    ));
                }

                let quant = state.quant_spec_for_deadline(rt.policy(), deadline_idx);
                let mut deadline = deadlines.load_deadline(store, deadline_idx)?;

                let removed_power = deadline
                    .terminate_sectors(
                        rt.policy(),
                        store,
                        &sectors,
                        curr_epoch,
                        partition_sectors,
                        info.sector_size,
                        quant,
                    )
                    .map_err(|e| {
                        e.downcast_default(
                            ExitCode::USR_ILLEGAL_STATE,
                            format!("failed to terminate sectors in deadline {}", deadline_idx),
                        )
                    })?;

                state.early_terminations.set(deadline_idx);
                power_delta -= &removed_power;

                deadlines.update_deadline(rt.policy(), store, deadline_idx, &deadline).map_err(
                    |e| {
                        e.downcast_default(
                            ExitCode::USR_ILLEGAL_STATE,
                            format!("failed to update deadline {}", deadline_idx),
                        )
                    },
                )?;
            }

            state.save_deadlines(store, deadlines).map_err(|e| {
                e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to save deadlines")
            })?;

            Ok((had_early_terminations, power_delta))
        })?;
        let epoch_reward = request_current_epoch_block_reward(rt)?;
        let pwr_total = request_current_total_power(rt)?;

        // Now, try to process these sectors.
        let more = process_early_terminations(
            rt,
            &epoch_reward.this_epoch_reward_smoothed,
            &pwr_total.quality_adj_power_smoothed,
        )?;

        if more && !had_early_terminations {
            // We have remaining terminations, and we didn't _previously_
            // have early terminations to process, schedule a cron job.
            // NOTE: This isn't quite correct. If we repeatedly fill, empty,
            // fill, empty, the queue, we'll keep scheduling new cron
            // jobs. However, in practice, that shouldn't be all that bad.
            schedule_early_termination_work(rt)?;
        }
        let state: State = rt.state()?;
        state.check_balance_invariants(&rt.current_balance()).map_err(balance_invariants_broken)?;

        request_update_power(rt, power_delta)?;
        Ok(TerminateSectorsReturn { done: !more })
    }

    fn declare_faults(rt: &impl Runtime, params: DeclareFaultsParams) -> Result<(), ActorError> {
        let mut to_process = DeadlineSectorMap::new();

        for term in params.faults {
            let deadline = term.deadline;
            let partition = term.partition;

            to_process.add(rt.policy(), deadline, partition, term.sectors).map_err(|e| {
                actor_error!(
                    illegal_argument,
                    "failed to process deadline {}, partition {}: {}",
                    deadline,
                    partition,
                    e
                )
            })?;
        }

        {
            let policy = rt.policy();
            to_process
                .check(policy.addressed_partitions_max, policy.addressed_sectors_max)
                .map_err(|e| {
                    actor_error!(illegal_argument, "cannot process requested parameters: {}", e)
                })?;
        }

        let power_delta = rt.transaction(|state: &mut State, rt| {
            let info = get_miner_info(rt.store(), state)?;

            rt.validate_immediate_caller_is(
                info.control_addresses.iter().chain(&[info.worker, info.owner]),
            )?;

            let store = rt.store();

            let mut deadlines =
                state.load_deadlines(store).map_err(|e| e.wrap("failed to load deadlines"))?;

            let sectors = Sectors::load(store, &state.sectors).map_err(|e| {
                e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to load sectors array")
            })?;

            let mut new_fault_power_total = PowerPair::zero();
            let curr_epoch = rt.curr_epoch();
            for (deadline_idx, partition_map) in to_process.iter() {
                let policy = rt.policy();
                let target_deadline = declaration_deadline_info(
                    policy,
                    state.current_proving_period_start(policy, curr_epoch),
                    deadline_idx,
                    curr_epoch,
                )
                .map_err(|e| {
                    actor_error!(
                        illegal_argument,
                        "invalid fault declaration deadline {}: {}",
                        deadline_idx,
                        e
                    )
                })?;

                validate_fr_declaration_deadline(&target_deadline).map_err(|e| {
                    actor_error!(
                        illegal_argument,
                        "failed fault declaration at deadline {}: {}",
                        deadline_idx,
                        e
                    )
                })?;

                let mut deadline = deadlines.load_deadline(store, deadline_idx)?;

                let fault_expiration_epoch = target_deadline.last() + policy.fault_max_age;

                let deadline_power_delta = deadline
                    .record_faults(
                        store,
                        &sectors,
                        info.sector_size,
                        target_deadline.quant_spec(),
                        fault_expiration_epoch,
                        partition_map,
                    )
                    .map_err(|e| {
                        e.downcast_default(
                            ExitCode::USR_ILLEGAL_STATE,
                            format!("failed to declare faults for deadline {}", deadline_idx),
                        )
                    })?;

                deadlines.update_deadline(policy, store, deadline_idx, &deadline).map_err(|e| {
                    e.downcast_default(
                        ExitCode::USR_ILLEGAL_STATE,
                        format!("failed to store deadline {} partitions", deadline_idx),
                    )
                })?;

                new_fault_power_total += &deadline_power_delta;
            }

            state.save_deadlines(store, deadlines).map_err(|e| {
                e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to save deadlines")
            })?;

            Ok(new_fault_power_total)
        })?;

        // Remove power for new faulty sectors.
        // NOTE: It would be permissible to delay the power loss until the deadline closes, but that would require
        // additional accounting state.
        // https://github.com/filecoin-project/specs-actors/issues/414
        request_update_power(rt, power_delta)?;

        // Payment of penalty for declared faults is deferred to the deadline cron.
        Ok(())
    }

    fn declare_faults_recovered(
        rt: &impl Runtime,
        params: DeclareFaultsRecoveredParams,
    ) -> Result<(), ActorError> {
        let mut to_process = DeadlineSectorMap::new();

        for term in params.recoveries {
            let deadline = term.deadline;
            let partition = term.partition;

            to_process.add(rt.policy(), deadline, partition, term.sectors).map_err(|e| {
                actor_error!(
                    illegal_argument,
                    "failed to process deadline {}, partition {}: {}",
                    deadline,
                    partition,
                    e
                )
            })?;
        }

        {
            let policy = rt.policy();
            to_process
                .check(policy.addressed_partitions_max, policy.addressed_sectors_max)
                .map_err(|e| {
                    actor_error!(illegal_argument, "cannot process requested parameters: {}", e)
                })?;
        }

        let fee_to_burn = rt.transaction(|state: &mut State, rt| {
            // Verify unlocked funds cover both InitialPledgeRequirement and FeeDebt
            // and repay fee debt now.
            let fee_to_burn = repay_debts_or_abort(rt, state)?;

            let info = get_miner_info(rt.store(), state)?;

            rt.validate_immediate_caller_is(
                info.control_addresses.iter().chain(&[info.worker, info.owner]),
            )?;

            if consensus_fault_active(&info, rt.curr_epoch()) {
                return Err(actor_error!(
                    forbidden,
                    "recovery not allowed during active consensus fault"
                ));
            }

            let store = rt.store();

            let mut deadlines =
                state.load_deadlines(store).map_err(|e| e.wrap("failed to load deadlines"))?;

            let sectors = Sectors::load(store, &state.sectors).map_err(|e| {
                e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to load sectors array")
            })?;
            let curr_epoch = rt.curr_epoch();
            for (deadline_idx, partition_map) in to_process.iter() {
                let policy = rt.policy();
                let target_deadline = declaration_deadline_info(
                    policy,
                    state.current_proving_period_start(policy, curr_epoch),
                    deadline_idx,
                    curr_epoch,
                )
                .map_err(|e| {
                    actor_error!(
                        illegal_argument,
                        "invalid recovery declaration deadline {}: {}",
                        deadline_idx,
                        e
                    )
                })?;

                validate_fr_declaration_deadline(&target_deadline).map_err(|e| {
                    actor_error!(
                        illegal_argument,
                        "failed recovery declaration at deadline {}: {}",
                        deadline_idx,
                        e
                    )
                })?;

                let mut deadline = deadlines.load_deadline(store, deadline_idx)?;

                deadline
                    .declare_faults_recovered(store, &sectors, info.sector_size, partition_map)
                    .map_err(|e| {
                        e.downcast_default(
                            ExitCode::USR_ILLEGAL_STATE,
                            format!("failed to declare recoveries for deadline {}", deadline_idx),
                        )
                    })?;

                deadlines.update_deadline(policy, store, deadline_idx, &deadline).map_err(|e| {
                    e.downcast_default(
                        ExitCode::USR_ILLEGAL_STATE,
                        format!("failed to store deadline {}", deadline_idx),
                    )
                })?;
            }

            state.save_deadlines(store, deadlines).map_err(|e| {
                e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to save deadlines")
            })?;

            Ok(fee_to_burn)
        })?;

        burn_funds(rt, fee_to_burn)?;
        let state: State = rt.state()?;
        state.check_balance_invariants(&rt.current_balance()).map_err(balance_invariants_broken)?;

        // Power is not restored yet, but when the recovered sectors are successfully PoSted.
        Ok(())
    }

    /// Compacts a number of partitions at one deadline by removing terminated sectors, re-ordering the remaining sectors,
    /// and assigning them to new partitions so as to completely fill all but one partition with live sectors.
    /// The addressed partitions are removed from the deadline, and new ones appended.
    /// The final partition in the deadline is always included in the compaction, whether or not explicitly requested.
    /// Removed sectors are removed from state entirely.
    /// May not be invoked if the deadline has any un-processed early terminations.
    fn compact_partitions(
        rt: &impl Runtime,
        params: CompactPartitionsParams,
    ) -> Result<(), ActorError> {
        {
            let policy = rt.policy();
            if params.deadline >= policy.wpost_period_deadlines {
                return Err(actor_error!(illegal_argument, "invalid deadline {}", params.deadline));
            }
        }

        let partitions = params.partitions.validate().map_err(|e| {
            actor_error!(illegal_argument, "failed to parse partitions bitfield: {}", e)
        })?;
        let partition_count = partitions.len();

        let params_deadline = params.deadline;

        rt.transaction(|state: &mut State, rt| {
            let info = get_miner_info(rt.store(), state)?;

            rt.validate_immediate_caller_is(
                info.control_addresses.iter().chain(&[info.worker, info.owner]),
            )?;

            let store = rt.store();
            let policy = rt.policy();

            if !deadline_available_for_compaction(
                policy,
                state.current_proving_period_start(policy, rt.curr_epoch()),
                params_deadline,
                rt.curr_epoch(),
            ) {
                return Err(actor_error!(
                    forbidden,
                    "cannot compact deadline {} during its challenge window, \
                    or the prior challenge window,
                    or before {} epochs have passed since its last challenge window ended",
                    params_deadline,
                    policy.wpost_dispute_window
                ));
            }

            let submission_partition_limit =
                load_partitions_sectors_max(policy, info.window_post_partition_sectors);
            if partition_count > submission_partition_limit {
                return Err(actor_error!(
                    illegal_argument,
                    "too many partitions {}, limit {}",
                    partition_count,
                    submission_partition_limit
                ));
            }

            let quant = state.quant_spec_for_deadline(policy, params_deadline);
            let mut deadlines =
                state.load_deadlines(store).map_err(|e| e.wrap("failed to load deadlines"))?;

            let mut deadline = deadlines.load_deadline(store, params_deadline)?;

            let daily_fee_before = deadline.daily_fee.clone();

            let mut sectors = Sectors::load(store, &state.sectors).map_err(|e| {
                e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to load sectors")
            })?;

            let dead = deadline
                .compact_partitions(
                    store,
                    &mut sectors,
                    info.sector_size,
                    info.window_post_partition_sectors,
                    partitions,
                    quant,
                )
                .map_err(|e| {
                    e.downcast_default(
                        ExitCode::USR_ILLEGAL_STATE,
                        format!("failed to remove partitions from deadline {}", params_deadline),
                    )
                })?;

            sectors.delete_sectors(&dead).map_err(|e| {
                e.wrap("failed to delete sectors removed during partition compaction")
            })?;
            state.sectors = sectors.amt.flush().with_context_code(
                ExitCode::USR_ILLEGAL_STATE,
                || "failed to save sectors after compaction",
            )?;

            deadlines.update_deadline(policy, store, params_deadline, &deadline).map_err(|e| {
                e.downcast_default(
                    ExitCode::USR_ILLEGAL_STATE,
                    format!("failed to update deadline {}", params_deadline),
                )
            })?;

            state.save_deadlines(store, deadlines).map_err(|e| {
                e.downcast_default(
                    ExitCode::USR_ILLEGAL_STATE,
                    format!("failed to save deadline {}", params_deadline),
                )
            })?;

            let daily_fee_after = deadline.daily_fee;
            if daily_fee_before != daily_fee_after {
                return Err(actor_error!(
                    illegal_state,
                    "unexpected daily fee change during partition compaction"
                ));
            }

            Ok(())
        })?;

        Ok(())
    }

    /// Compacts sector number allocations to reduce the size of the allocated sector
    /// number bitfield.
    ///
    /// When allocating sector numbers sequentially, or in sequential groups, this
    /// bitfield should remain fairly small. However, if the bitfield grows large
    /// enough such that PreCommitSector fails (or becomes expensive), this method
    /// can be called to mask out (throw away) entire ranges of unused sector IDs.
    /// For example, if sectors 1-99 and 101-200 have been allocated, sector number
    /// 99 can be masked out to collapse these two ranges into one.
    fn compact_sector_numbers(
        rt: &impl Runtime,
        params: CompactSectorNumbersParams,
    ) -> Result<(), ActorError> {
        let mask_sector_numbers = params
            .mask_sector_numbers
            .validate()
            .map_err(|e| actor_error!(illegal_argument, "invalid mask bitfield: {}", e))?;

        let last_sector_number = mask_sector_numbers
            .last()
            .ok_or_else(|| actor_error!(illegal_argument, "invalid mask bitfield"))?
            as SectorNumber;

        if last_sector_number > MAX_SECTOR_NUMBER {
            return Err(actor_error!(
                illegal_argument,
                "masked sector number {} exceeded max sector number",
                last_sector_number
            ));
        }

        rt.transaction(|state: &mut State, rt| {
            let info = get_miner_info(rt.store(), state)?;

            rt.validate_immediate_caller_is(
                info.control_addresses.iter().chain(&[info.worker, info.owner]),
            )?;

            state.allocate_sector_numbers(
                rt.store(),
                mask_sector_numbers,
                CollisionPolicy::AllowCollisions,
            )
        })?;

        Ok(())
    }

    /// Locks up some amount of a the miner's unlocked balance (including funds received alongside the invoking message).
    fn apply_rewards(rt: &impl Runtime, params: ApplyRewardParams) -> Result<(), ActorError> {
        if params.reward.is_negative() {
            return Err(actor_error!(
                illegal_argument,
                "cannot lock up a negative amount of funds"
            ));
        }
        if params.penalty.is_negative() {
            return Err(actor_error!(
                illegal_argument,
                "cannot penalize a negative amount of funds"
            ));
        }

        let (pledge_delta_total, to_burn) = rt.transaction(|st: &mut State, rt| {
            let mut pledge_delta_total = TokenAmount::zero();

            rt.validate_immediate_caller_is(std::iter::once(&REWARD_ACTOR_ADDR))?;

            let (reward_to_lock, locked_reward_vesting_spec) =
                locked_reward_from_reward(params.reward);

            // This ensures the miner has sufficient funds to lock up amountToLock.
            // This should always be true if reward actor sends reward funds with the message.
            let unlocked_balance = st.get_unlocked_balance(&rt.current_balance()).map_err(|e| {
                actor_error!(illegal_state, "failed to calculate unlocked balance: {}", e)
            })?;

            if unlocked_balance < reward_to_lock {
                return Err(actor_error!(
                    insufficient_funds,
                    "insufficient funds to lock, available: {}, requested: {}",
                    unlocked_balance,
                    reward_to_lock
                ));
            }

            let newly_vested = st
                .add_locked_funds(
                    rt.store(),
                    rt.curr_epoch(),
                    &reward_to_lock,
                    locked_reward_vesting_spec,
                )
                .map_err(|e| {
                    actor_error!(illegal_state, "failed to lock funds in vesting table: {}", e)
                })?;
            pledge_delta_total -= &newly_vested;
            pledge_delta_total += &reward_to_lock;

            st.apply_penalty(&params.penalty)
                .map_err(|e| actor_error!(illegal_state, "failed to apply penalty: {}", e))?;

            // Attempt to repay all fee debt in this call. In most cases the miner will have enough
            // funds in the *reward alone* to cover the penalty. In the rare case a miner incurs more
            // penalty than it can pay for with reward and existing funds, it will go into fee debt.
            let (to_burn, total_unlocked) = st
                .repay_partial_debt_in_priority_order(
                    rt.store(),
                    rt.curr_epoch(),
                    &rt.current_balance(),
                )
                .map_err(|e| {
                    e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to repay penalty")
                })?;
            pledge_delta_total -= &total_unlocked;
            Ok((pledge_delta_total, to_burn))
        })?;

        notify_pledge_changed(rt, &pledge_delta_total)?;
        burn_funds(rt, to_burn)?;
        let st: State = rt.state()?;
        st.check_balance_invariants(&rt.current_balance()).map_err(balance_invariants_broken)?;
        Ok(())
    }

    fn report_consensus_fault(
        rt: &impl Runtime,
        params: ReportConsensusFaultParams,
    ) -> Result<(), ActorError> {
        // Note: only the first report of any fault is processed because it sets the
        // ConsensusFaultElapsed state variable to an epoch after the fault, and reports prior to
        // that epoch are no longer valid
        rt.validate_immediate_caller_accept_any()?;
        let reporter = rt.message().caller();

        let fault = rt
            .verify_consensus_fault(&params.header1, &params.header2, &params.header_extra)
            .map_err(|e| e.downcast_default(ExitCode::USR_ILLEGAL_ARGUMENT, "fault not verified"))?
            .ok_or_else(|| actor_error!(illegal_argument, "No consensus fault found"))?;
        if fault.target != rt.message().receiver() {
            return Err(actor_error!(
                illegal_argument,
                "fault by {} reported to miner {}",
                fault.target,
                rt.message().receiver()
            ));
        }

        // Elapsed since the fault (i.e. since the higher of the two blocks)
        let fault_age = rt.curr_epoch() - fault.epoch;
        if fault_age <= 0 {
            return Err(actor_error!(
                illegal_argument,
                "invalid fault epoch {} ahead of current {}",
                fault.epoch,
                rt.curr_epoch()
            ));
        }

        // Reward reporter with a share of the miner's current balance.
        let reward_stats = request_current_epoch_block_reward(rt)?;

        // The policy amounts we should burn and send to reporter
        // These may differ from actual funds send when miner goes into fee debt
        let this_epoch_reward =
            TokenAmount::from_atto(reward_stats.this_epoch_reward_smoothed.estimate());
        let fault_penalty = consensus_fault_penalty(this_epoch_reward.clone());
        let slasher_reward = reward_for_consensus_slash_report(&this_epoch_reward);

        let mut pledge_delta = TokenAmount::zero();

        let (burn_amount, reward_amount) = rt.transaction(|st: &mut State, rt| {
            let mut info = get_miner_info(rt.store(), st)?;

            // Verify miner hasn't already been faulted
            if fault.epoch < info.consensus_fault_elapsed {
                return Err(actor_error!(
                    forbidden,
                    "fault epoch {} is too old, last exclusion period ended at {}",
                    fault.epoch,
                    info.consensus_fault_elapsed
                ));
            }

            st.apply_penalty(&fault_penalty).map_err(|e| {
                actor_error!(illegal_state, format!("failed to apply penalty: {}", e))
            })?;

            // Pay penalty
            let (mut burn_amount, total_unlocked) = st
                .repay_partial_debt_in_priority_order(
                    rt.store(),
                    rt.curr_epoch(),
                    &rt.current_balance(),
                )
                .map_err(|e| {
                    e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to pay fees")
                })?;

            pledge_delta -= total_unlocked;

            // clamp reward at funds burnt
            let reward_amount = std::cmp::min(&burn_amount, &slasher_reward).clone();
            burn_amount -= &reward_amount;

            info.consensus_fault_elapsed =
                rt.curr_epoch() + rt.policy().consensus_fault_ineligibility_duration;

            st.save_info(rt.store(), &info).map_err(|e| {
                e.downcast_default(ExitCode::USR_SERIALIZATION, "failed to save miner info")
            })?;

            Ok((burn_amount, reward_amount))
        })?;

        if let Err(e) =
            extract_send_result(rt.send_simple(&reporter, METHOD_SEND, None, reward_amount))
        {
            error!("failed to send reward: {}", e);
        }

        burn_funds(rt, burn_amount)?;
        notify_pledge_changed(rt, &pledge_delta)?;

        let state: State = rt.state()?;
        state.check_balance_invariants(&rt.current_balance()).map_err(balance_invariants_broken)?;
        Ok(())
    }

    fn withdraw_balance(
        rt: &impl Runtime,
        params: WithdrawBalanceParams,
    ) -> Result<WithdrawBalanceReturn, ActorError> {
        if params.amount_requested.is_negative() {
            return Err(actor_error!(
                illegal_argument,
                "negative fund requested for withdrawal: {}",
                params.amount_requested
            ));
        }

        let (info, amount_withdrawn, newly_vested, fee_to_burn, state) =
            rt.transaction(|state: &mut State, rt| {
                let mut info = get_miner_info(rt.store(), state)?;

                // Only the owner or the beneficiary is allowed to withdraw the balance.
                rt.validate_immediate_caller_is(&[info.owner, info.beneficiary])?;

                // Ensure we don't have any pending terminations.
                if !state.early_terminations.is_empty() {
                    return Err(actor_error!(
                        forbidden,
                        "cannot withdraw funds while {} deadlines have terminated sectors \
                        with outstanding fees",
                        state.early_terminations.len()
                    ));
                }

                // Unlock vested funds so we can spend them.
                let newly_vested =
                    state.unlock_vested_funds(rt.store(), rt.curr_epoch()).map_err(|e| {
                        e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "Failed to vest fund")
                    })?;

                // available balance already accounts for fee debt so it is correct to call
                // this before RepayDebts. We would have to
                // subtract fee debt explicitly if we called this after.
                let available_balance =
                    state.get_available_balance(&rt.current_balance()).map_err(|e| {
                        actor_error!(
                            illegal_state,
                            format!("failed to calculate available balance: {}", e)
                        )
                    })?;

                // Verify unlocked funds cover both InitialPledgeRequirement and FeeDebt
                // and repay fee debt now.
                let fee_to_burn = repay_debts_or_abort(rt, state)?;
                let mut amount_withdrawn =
                    std::cmp::min(&available_balance, &params.amount_requested);
                if amount_withdrawn.is_negative() {
                    return Err(actor_error!(
                        illegal_state,
                        "negative amount to withdraw: {}",
                        amount_withdrawn
                    ));
                }
                if info.beneficiary != info.owner {
                    // remaining_quota always zero and positive
                    let remaining_quota = info.beneficiary_term.available(rt.curr_epoch());
                    if remaining_quota.is_zero() {
                        return Err(actor_error!(
                            forbidden,
                            "beneficiary expiration of epoch {} passed or quota of {} depleted with {} used",
                            info.beneficiary_term.expiration,
                            info.beneficiary_term.quota,
                            info.beneficiary_term.used_quota
                        ));
                    }
                    amount_withdrawn = std::cmp::min(amount_withdrawn, &remaining_quota);
                    if amount_withdrawn.is_positive() {
                        info.beneficiary_term.used_quota += amount_withdrawn;
                        state.save_info(rt.store(), &info).map_err(|e| {
                            e.downcast_default(
                                ExitCode::USR_ILLEGAL_STATE,
                                "failed to save miner info",
                            )
                        })?;
                    }
                    Ok((info, amount_withdrawn.clone(), newly_vested, fee_to_burn, state.clone()))
                } else {
                    Ok((info, amount_withdrawn.clone(), newly_vested, fee_to_burn, state.clone()))
                }
            })?;

        if amount_withdrawn.is_positive() {
            extract_send_result(rt.send_simple(
                &info.beneficiary,
                METHOD_SEND,
                None,
                amount_withdrawn.clone(),
            ))?;
        }

        burn_funds(rt, fee_to_burn)?;
        notify_pledge_changed(rt, &newly_vested.neg())?;

        state.check_balance_invariants(&rt.current_balance()).map_err(balance_invariants_broken)?;
        Ok(WithdrawBalanceReturn { amount_withdrawn })
    }

    /// Proposes or confirms a change of beneficiary address.
    /// A proposal must be submitted by the owner, and takes effect after approval of both the proposed beneficiary and current beneficiary,
    /// if applicable, any current beneficiary that has time and quota remaining.
    //// See FIP-0029, https://github.com/filecoin-project/FIPs/blob/master/FIPS/fip-0029.md
    fn change_beneficiary(
        rt: &impl Runtime,
        params: ChangeBeneficiaryParams,
    ) -> Result<(), ActorError> {
        rt.validate_immediate_caller_accept_any()?;
        let caller = rt.message().caller();
        let new_beneficiary =
            Address::new_id(rt.resolve_address(&params.new_beneficiary).ok_or_else(|| {
                actor_error!(
                    illegal_argument,
                    "unable to resolve address: {}",
                    params.new_beneficiary
                )
            })?);

        rt.transaction(|state: &mut State, rt| {
            let mut info = get_miner_info(rt.store(), state)?;
            if caller == info.owner {
                // This is a ChangeBeneficiary proposal when the caller is Owner
                if new_beneficiary != info.owner {
                    // When beneficiary is not owner, just check quota in params,
                    // Expiration maybe an expiration value, but wouldn't cause problem, just the new beneficiary never get any benefit
                    if !params.new_quota.is_positive() {
                        return Err(actor_error!(
                            illegal_argument,
                            "beneficial quota {} must bigger than zero",
                            params.new_quota
                        ));
                    }
                } else {
                    // Expiration/quota must set to 0 while change beneficiary to owner
                    if !params.new_quota.is_zero() {
                        return Err(actor_error!(
                            illegal_argument,
                            "owner beneficial quota {} must be zero",
                            params.new_quota
                        ));
                    }

                    if params.new_expiration != 0 {
                        return Err(actor_error!(
                            illegal_argument,
                            "owner beneficial expiration {} must be zero",
                            params.new_expiration
                        ));
                    }
                }

                let mut pending_beneficiary_term = PendingBeneficiaryChange::new(
                    new_beneficiary,
                    params.new_quota,
                    params.new_expiration,
                );
                if info.beneficiary_term.available(rt.curr_epoch()).is_zero() {
                    // Set current beneficiary to approved when current beneficiary is not effective
                    pending_beneficiary_term.approved_by_beneficiary = true;
                }
                info.pending_beneficiary_term = Some(pending_beneficiary_term);
            } else if let Some(pending_term) = &info.pending_beneficiary_term {
                if caller != info.beneficiary && caller != pending_term.new_beneficiary {
                    return Err(actor_error!(
                        forbidden,
                        "message caller {} is neither proposal beneficiary{} nor current beneficiary{}",
                        caller,
                        params.new_beneficiary,
                        info.beneficiary
                    ));
                }

                if pending_term.new_beneficiary != new_beneficiary {
                    return Err(actor_error!(
                        illegal_argument,
                        "new beneficiary address must be equal expect {}, but got {}",
                        pending_term.new_beneficiary,
                        params.new_beneficiary
                    ));
                }
                if pending_term.new_quota != params.new_quota {
                    return Err(actor_error!(
                        illegal_argument,
                        "new beneficiary quota must be equal expect {}, but got {}",
                        pending_term.new_quota,
                        params.new_quota
                    ));
                }
                if pending_term.new_expiration != params.new_expiration {
                    return Err(actor_error!(
                        illegal_argument,
                        "new beneficiary expire date must be equal expect {}, but got {}",
                        pending_term.new_expiration,
                        params.new_expiration
                    ));
                }
            } else {
                return Err(actor_error!(forbidden, "No changeBeneficiary proposal exists"));
            }

            if let Some(pending_term) = info.pending_beneficiary_term.as_mut() {
                if caller == info.beneficiary {
                    pending_term.approved_by_beneficiary = true
                }

                if caller == new_beneficiary {
                    pending_term.approved_by_nominee = true
                }

                if pending_term.approved_by_beneficiary && pending_term.approved_by_nominee {
                    //approved by both beneficiary and nominee
                    if new_beneficiary != info.beneficiary {
                        //if beneficiary changes, reset used_quota to zero
                        info.beneficiary_term.used_quota = TokenAmount::zero();
                    }
                    info.beneficiary = new_beneficiary;
                    info.beneficiary_term.quota = pending_term.new_quota.clone();
                    info.beneficiary_term.expiration = pending_term.new_expiration;
                    // clear the pending proposal
                    info.pending_beneficiary_term = None;
                }
            }

            state.save_info(rt.store(), &info).map_err(|e| {
                e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to save miner info")
            })?;
            Ok(())
        })
    }

    // GetBeneficiary retrieves the currently active and proposed beneficiary information.
    // This method is for use by other actors (such as those acting as beneficiaries),
    // and to abstract the state representation for clients.
    fn get_beneficiary(rt: &impl Runtime) -> Result<GetBeneficiaryReturn, ActorError> {
        rt.validate_immediate_caller_accept_any()?;
        let st: State = rt.state()?;
        let info = get_miner_info(rt.store(), &st)?;

        Ok(GetBeneficiaryReturn {
            active: ActiveBeneficiary {
                beneficiary: info.beneficiary,
                term: info.beneficiary_term,
            },
            proposed: info.pending_beneficiary_term,
        })
    }

    fn repay_debt(rt: &impl Runtime) -> Result<(), ActorError> {
        let (burn_amount, total_unlocked, state) = rt.transaction(|state: &mut State, rt| {
            let info = get_miner_info(rt.store(), state)?;
            rt.validate_immediate_caller_is(
                info.control_addresses.iter().chain(&[info.worker, info.owner]),
            )?;

            // Repay as much fee debt as possible.
            let (burn_amount, total_unlocked) = state
                .repay_partial_debt_in_priority_order(
                    rt.store(),
                    rt.curr_epoch(),
                    &rt.current_balance(),
                )
                .map_err(|e| {
                    e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to unlock fee debt")
                })?;

            Ok((burn_amount, total_unlocked, state.clone()))
        })?;

        notify_pledge_changed(rt, &total_unlocked.neg())?;
        burn_funds(rt, burn_amount)?;

        state.check_balance_invariants(&rt.current_balance()).map_err(balance_invariants_broken)?;
        Ok(())
    }

    fn on_deferred_cron_event(
        rt: &impl Runtime,
        params: DeferredCronEventParams,
    ) -> Result<(), ActorError> {
        rt.validate_immediate_caller_is(std::iter::once(&STORAGE_POWER_ACTOR_ADDR))?;

        let payload: CronEventPayload = from_slice(&params.event_payload).map_err(|e| {
            actor_error!(
                illegal_state,
                format!("failed to unmarshal miner cron payload into expected structure: {}", e)
            )
        })?;

        match payload.event_type {
            CRON_EVENT_PROVING_DEADLINE => handle_proving_deadline(
                rt,
                &params.reward_smoothed,
                &params.quality_adj_power_smoothed,
            )?,
            CRON_EVENT_PROCESS_EARLY_TERMINATIONS => {
                if process_early_terminations(
                    rt,
                    &params.reward_smoothed,
                    &params.quality_adj_power_smoothed,
                )? {
                    schedule_early_termination_work(rt)?
                }
            }
            _ => {
                error!("onDeferredCronEvent invalid event type: {}", payload.event_type);
            }
        };
        let state: State = rt.state()?;
        state.check_balance_invariants(&rt.current_balance()).map_err(balance_invariants_broken)?;
        Ok(())
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct ValidatedExpirationExtension {
    pub deadline: u64,
    pub partition: u64,
    pub sectors: BitField,
    /// Absent when the declaration rewrites its sectors without moving their expiration.
    pub new_expiration: Option<ChainEpoch>,
}

// The two sector lists differed only in whether FIL+ claims needed per-sector instructions.
// FIP-0118 removed claim validation, so they now mean the same thing and merge. Merging is
// idempotent, so a sector named in both is extended once.
impl From<ExpirationExtension2> for ValidatedExpirationExtension {
    fn from(e2: ExpirationExtension2) -> Self {
        let mut sectors = BitField::new();
        for sc in e2.sectors_with_claims {
            sectors.set(sc.sector_number)
        }
        sectors |= &e2.sectors;

        Self {
            deadline: e2.deadline,
            partition: e2.partition,
            sectors,
            new_expiration: Some(e2.new_expiration),
        }
    }
}

impl From<UpgradeSectorQuality> for ValidatedExpirationExtension {
    fn from(uq: UpgradeSectorQuality) -> Self {
        let UpgradeSectorQuality { deadline, partition, sectors, new_expiration } = uq;
        Self { deadline, partition, sectors, new_expiration }
    }
}

/// Rewrites the sectors named by each declaration, moving each partition's expiration queue
/// and its deadline's power and fee books to match, and returns the aggregate power and
/// pledge deltas.
///
/// `rewrite` produces each sector's replacement record, or `None` to leave the sector exactly
/// as it is. Every named sector must be active, else the call fails with
/// `USR_ILLEGAL_ARGUMENT`. Declarations are not merged but applied in order, each seeing the
/// records the previous ones produced, so a sector named twice is offered to `rewrite` twice
/// (and rewritten again only if `rewrite` says so).
///
/// A declaration with a new expiration re-registers its partition in the deadline's expiration
/// queue if necessary.
fn replace_sector_records<BS: Blockstore>(
    policy: &Policy,
    store: &BS,
    state: &mut State,
    sector_size: SectorSize,
    declarations: &[ValidatedExpirationExtension],
    rewrite: impl Fn(
        &ValidatedExpirationExtension,
        &SectorOnChainInfo,
    ) -> Result<Option<SectorOnChainInfo>, ActorError>,
) -> Result<(PowerPair, TokenAmount), ActorError> {
    let replace_declaration_batch = |decl: &ValidatedExpirationExtension,
                                     key: &PartitionKey,
                                     partition: &mut Partition,
                                     sectors: &mut Sectors<BS>,
                                     quant: QuantSpec| {
        let mut old_sectors = Vec::new();
        let mut new_sectors = Vec::new();
        for sector in
            sectors.load_sectors(&decl.sectors).map_err(|e| e.wrap("failed to load sectors"))?
        {
            if !partition.is_active(sector.sector_number) {
                return Err(actor_error!(
                    illegal_argument,
                    "sector {} is not active in {:?}",
                    sector.sector_number,
                    key
                ));
            }
            if let Some(new_sector) = rewrite(decl, &sector)? {
                old_sectors.push(sector);
                new_sectors.push(new_sector);
            }
        }

        replace_partition_sector_records(
            SectorRecordReplacementContext { store, key, sector_size, quant },
            partition,
            sectors,
            old_sectors.iter(),
            new_sectors,
        )
    };

    replace_sector_record_batches(
        policy,
        store,
        state,
        declarations,
        |decl| SectorRecordBatchLocation {
            deadline: decl.deadline,
            partition: decl.partition,
            new_expiration: decl.new_expiration,
        },
        replace_declaration_batch,
    )
}
#[derive(Clone, Copy)]
struct SectorRecordBatchLocation {
    deadline: u64,
    partition: u64,
    new_expiration: Option<ChainEpoch>,
}

/// Applies batches of sector record replacements, updating the sectors AMT plus each affected
/// partition and deadline. Batches may carry caller-specific data; `replace` materializes and
/// applies their records.
fn replace_sector_record_batches<BS: Blockstore, B>(
    policy: &Policy,
    store: &BS,
    state: &mut State,
    batches: impl IntoIterator<Item = B>,
    location: impl Fn(&B) -> SectorRecordBatchLocation,
    mut replace: impl FnMut(
        B,
        &PartitionKey,
        &mut Partition,
        &mut Sectors<BS>,
        QuantSpec,
    ) -> Result<Option<(PowerPair, TokenAmount, TokenAmount)>, ActorError>,
) -> Result<(PowerPair, TokenAmount), ActorError> {
    let mut deadlines =
        state.load_deadlines(store).map_err(|e| e.wrap("failed to load deadlines"))?;

    // Group batches by deadline while preserving their order within each deadline.
    let mut batches_by_deadline: Vec<_> =
        std::iter::repeat_with(Vec::new).take(policy.wpost_period_deadlines as usize).collect();
    let mut deadlines_to_load = Vec::<u64>::new();
    for batch in batches {
        let location = location(&batch);
        // Deadline indices are validated by each caller before this function.
        let deadline_batches = &mut batches_by_deadline[location.deadline as usize];
        if deadline_batches.is_empty() {
            deadlines_to_load.push(location.deadline);
        }
        deadline_batches.push((location, batch));
    }

    let mut sectors = Sectors::load(store, &state.sectors).map_err(|e| {
        e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to load sectors array")
    })?;

    let mut power_delta = PowerPair::zero();
    let mut pledge_delta = TokenAmount::zero();

    for deadline_idx in deadlines_to_load {
        let mut deadline = deadlines.load_deadline(store, deadline_idx)?;
        let mut partitions = deadline.partitions_amt(store).map_err(|e| {
            e.downcast_default(
                ExitCode::USR_ILLEGAL_STATE,
                format!("failed to load partitions for deadline {}", deadline_idx),
            )
        })?;
        let quant = state.quant_spec_for_deadline(policy, deadline_idx);

        let mut deadline_power_delta = PowerPair::zero();
        let mut deadline_pledge_delta = TokenAmount::zero();
        let mut deadline_daily_fee_delta = TokenAmount::zero();

        // Group modified partitions by the epoch they move to. Duplicates are ok.
        let mut partitions_by_new_epoch = BTreeMap::<ChainEpoch, Vec<u64>>::new();
        let mut epochs_to_reschedule = Vec::<ChainEpoch>::new();

        for (location, batch) in std::mem::take(&mut batches_by_deadline[deadline_idx as usize]) {
            let key = PartitionKey { deadline: deadline_idx, partition: location.partition };
            let mut partition = partitions
                .get(location.partition)
                .map_err(|e| {
                    e.downcast_default(
                        ExitCode::USR_ILLEGAL_STATE,
                        format!("failed to load partition {:?}", key),
                    )
                })?
                .cloned()
                .ok_or_else(|| actor_error!(not_found, "no such partition {:?}", key))?;

            let Some((batch_power_delta, batch_pledge_delta, batch_daily_fee_delta)) =
                replace(batch, &key, &mut partition, &mut sectors, quant)?
            else {
                continue;
            };

            deadline_power_delta += &batch_power_delta;
            deadline_pledge_delta += &batch_pledge_delta;
            deadline_daily_fee_delta += &batch_daily_fee_delta;

            partitions.set(location.partition, partition).map_err(|e| {
                e.downcast_default(
                    ExitCode::USR_ILLEGAL_STATE,
                    format!("failed to save partition {:?}", key),
                )
            })?;

            if let Some(new_expiration) = location.new_expiration {
                let epoch_partitions = partitions_by_new_epoch.entry(new_expiration);
                let new_epoch = matches!(epoch_partitions, Entry::Vacant(_));
                epoch_partitions.or_default().push(location.partition);
                if new_epoch {
                    epochs_to_reschedule.push(new_expiration);
                }
            }
        }

        deadline.live_power += &deadline_power_delta;
        deadline.daily_fee += &deadline_daily_fee_delta;
        power_delta += &deadline_power_delta;
        pledge_delta += &deadline_pledge_delta;

        deadline.partitions = partitions.flush().map_err(|e| {
            e.downcast_default(
                ExitCode::USR_ILLEGAL_STATE,
                format!("failed to save partitions for deadline {}", deadline_idx),
            )
        })?;

        for epoch in epochs_to_reschedule {
            let partition_indices = partitions_by_new_epoch.get(&epoch).unwrap();
            deadline.add_expiration_partitions(store, epoch, partition_indices, quant).map_err(
                |e| {
                    e.downcast_default(
                        ExitCode::USR_ILLEGAL_STATE,
                        format!(
                            "failed to add expiration partitions to deadline {} epoch {}",
                            deadline_idx, epoch
                        ),
                    )
                },
            )?;
        }

        deadlines.update_deadline(policy, store, deadline_idx, &deadline).map_err(|e| {
            e.downcast_default(
                ExitCode::USR_ILLEGAL_STATE,
                format!("failed to save deadline {}", deadline_idx),
            )
        })?;
    }

    state.sectors = sectors
        .amt
        .flush()
        .map_err(|e| e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to save sectors"))?;
    state
        .save_deadlines(store, deadlines)
        .map_err(|e| e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to save deadlines"))?;

    Ok((power_delta, pledge_delta))
}

struct SectorRecordReplacementContext<'a, BS> {
    store: &'a BS,
    key: &'a PartitionKey,
    sector_size: SectorSize,
    quant: QuantSpec,
}

/// Commits prepared replacements to one partition and the sectors AMT, returning accounting
/// deltas, or `None` when there is nothing to replace.
fn replace_partition_sector_records<'a, BS, I>(
    context: SectorRecordReplacementContext<'_, BS>,
    partition: &mut Partition,
    sectors: &mut Sectors<BS>,
    old_sectors: I,
    new_sectors: Vec<SectorOnChainInfo>,
) -> Result<Option<(PowerPair, TokenAmount, TokenAmount)>, ActorError>
where
    BS: Blockstore,
    I: IntoIterator<Item = &'a SectorOnChainInfo>,
{
    if new_sectors.is_empty() {
        return Ok(None);
    }

    let deltas = partition
        .replace_sectors(
            context.store,
            old_sectors,
            new_sectors.iter(),
            context.sector_size,
            context.quant,
        )
        .map_err(|e| {
            e.downcast_default(
                ExitCode::USR_ILLEGAL_STATE,
                format!("failed to replace sector records at {:?}", context.key),
            )
        })?;

    sectors.store(new_sectors).map_err(|e| {
        e.downcast_default(
            ExitCode::USR_ILLEGAL_STATE,
            format!("failed to update sectors at {:?}", context.key),
        )
    })?;

    Ok(Some(deltas))
}

#[allow(clippy::too_many_arguments)]
fn extend_sector_committment(
    policy: &Policy,
    curr_epoch: ChainEpoch,
    circulating_supply: &TokenAmount,
    new_expiration: ChainEpoch,
    sector_info: &SectorOnChainInfo,
    sector_size: SectorSize,
) -> Result<SectorOnChainInfo, ActorError> {
    validate_extended_expiration(policy, curr_epoch, new_expiration, sector_info)?;

    let mut new_sector_info = extend_sector_weights(new_expiration, curr_epoch, sector_info)?;
    // As of FIP-0098, these fields are unused (and should be cleared).
    new_sector_info.expected_day_reward = None;
    new_sector_info.expected_storage_pledge = None;
    new_sector_info.replaced_day_reward = None;

    if new_sector_info.daily_fee.is_zero() {
        // pre-FIP-0100 sector
        let new_qa_power = qa_power_for_sector(sector_size, &new_sector_info);
        new_sector_info.daily_fee = daily_proof_fee(policy, circulating_supply, &new_qa_power);
    }
    Ok(new_sector_info)
}

fn validate_extended_expiration(
    policy: &Policy,
    curr_epoch: ChainEpoch,
    new_expiration: ChainEpoch,
    sector: &SectorOnChainInfo,
) -> Result<(), ActorError> {
    if !can_extend_seal_proof_type(sector.seal_proof) {
        return Err(actor_error!(
            forbidden,
            "cannot extend expiration for sector {} with unsupported \
            seal type {:?}",
            sector.sector_number,
            sector.seal_proof
        ));
    }
    if sector.expiration <= curr_epoch {
        return Err(actor_error!(
            forbidden,
            "cannot extend expiration for expired sector {} at {}",
            sector.sector_number,
            sector.expiration
        ));
    }

    if new_expiration <= sector.expiration {
        return Err(actor_error!(
            illegal_argument,
            "new expiration {} must be after sector {} expiration {}",
            new_expiration,
            sector.sector_number,
            sector.expiration
        ));
    }

    validate_expiration(policy, curr_epoch, sector.activation, new_expiration, sector.seal_proof)?;
    Ok(())
}

// Carries a sector's recorded weights across an extension. One algorithm covers legacy and
// new sectors: verified weight is restated over the new duration so quality, and therefore
// power, is unchanged, while deal weight keeps only what remains, since deals do not outlive
// the expiration they activated against. For FULL_QA_POWER sectors both are informational,
// QAP coming from the flag.
fn extend_sector_weights(
    new_expiration: ChainEpoch,
    curr_epoch: ChainEpoch,
    sector: &SectorOnChainInfo,
) -> Result<SectorOnChainInfo, ActorError> {
    let mut new_sector = sector.clone();

    new_sector.expiration = new_expiration;
    new_sector.power_base_epoch = curr_epoch;
    let old_duration = sector.expiration - sector.power_base_epoch;
    let new_duration = new_sector.expiration - new_sector.power_base_epoch;

    // Deals do not outlive the expiration they activated against, so carry only what remains.
    if sector.deal_weight.is_positive() {
        new_sector.deal_weight =
            &sector.deal_weight * (sector.expiration - curr_epoch) / old_duration;
    }

    // Restate over the new duration, preserving space and therefore quality.
    if sector.verified_deal_weight.is_positive() {
        let old_verified_deal_space = &sector.verified_deal_weight / old_duration;
        new_sector.verified_deal_weight = old_verified_deal_space * new_duration;
    }

    Ok(new_sector)
}

fn validate_sector_selection(
    deadline: u64,
    partition: u64,
    is_empty: bool,
) -> Result<(), ActorError> {
    if is_empty {
        return Err(actor_error!(
            illegal_argument,
            "no sectors selected in deadline {} partition {}",
            deadline,
            partition
        ));
    }
    Ok(())
}

fn validate_deadline_index(policy: &Policy, deadline: u64) -> Result<(), ActorError> {
    if deadline >= policy.wpost_period_deadlines {
        return Err(actor_error!(
            illegal_argument,
            "deadline {} not in range 0..{}",
            deadline,
            policy.wpost_period_deadlines
        ));
    }
    Ok(())
}

fn validate_expiration_bounds(
    policy: &Policy,
    curr_epoch: ChainEpoch,
    new_expiration: ChainEpoch,
) -> Result<(), ActorError> {
    if new_expiration <= curr_epoch {
        return Err(actor_error!(
            illegal_argument,
            "new expiration {} must be after current epoch {}",
            new_expiration,
            curr_epoch
        ));
    }
    if new_expiration > curr_epoch + policy.max_sector_expiration_extension {
        return Err(actor_error!(
            illegal_argument,
            "new expiration {} cannot be more than {} past current epoch {}",
            new_expiration,
            policy.max_sector_expiration_extension,
            curr_epoch
        ));
    }
    Ok(())
}

/// Validates `UpgradeSectorQuality` declarations before any state changes: at
/// least one declaration, deadline indices in range, no empty sector selections,
/// and requested expirations inside the allowed window.
fn validate_upgrade_quality_extensions(
    policy: &Policy,
    curr_epoch: ChainEpoch,
    extensions: &[UpgradeSectorQuality],
) -> Result<(), ActorError> {
    if extensions.is_empty() {
        return Err(actor_error!(illegal_argument, "no extension declarations"));
    }

    for decl in extensions {
        validate_deadline_index(policy, decl.deadline)?;

        validate_sector_selection(decl.deadline, decl.partition, decl.sectors.is_empty())?;

        if let Some(new_expiration) = decl.new_expiration {
            validate_expiration_bounds(policy, curr_epoch, new_expiration)?;
        }
    }

    Ok(())
}

/// Builds the record for one sector upgraded to full quality-adjusted power
/// (FIP-0118) by `UpgradeSectorQuality`, optionally extending it. Expects a sector
/// below full power (the caller only extends or skips any other), so the pledge, set
/// to the larger of the recorded pledge and `full_power_pledge`, is raised at most once.
///
/// Without a new expiration the record keeps its expiration, power base epoch and
/// weights, so the sector stays exactly where it is already scheduled; only the
/// flags, pledge and daily fee change. The deprecated day-reward and storage-pledge
/// estimates are cleared either way, as extension and replica update do.
///
/// # Errors
/// Rejects sectors that have already expired, and expirations that would shorten
/// the sector's life or fall outside the allowed window.
fn upgrade_sector_to_full_power(
    policy: &Policy,
    curr_epoch: ChainEpoch,
    new_expiration: Option<ChainEpoch>,
    sector: &SectorOnChainInfo,
    sector_size: SectorSize,
    circulating_supply: &TokenAmount,
    full_power_pledge: &TokenAmount,
) -> Result<SectorOnChainInfo, ActorError> {
    let mut new_sector = match new_expiration {
        None => {
            if sector.expiration <= curr_epoch {
                return Err(actor_error!(
                    forbidden,
                    "cannot upgrade expired sector {} at {}",
                    sector.sector_number,
                    sector.expiration
                ));
            }
            sector.clone()
        }
        Some(new_expiration) => {
            validate_extended_expiration(policy, curr_epoch, new_expiration, sector)?;
            extend_sector_weights(new_expiration, curr_epoch, sector)?
        }
    };

    new_sector.flags |=
        SectorOnChainInfoFlags::SIMPLE_QA_POWER | SectorOnChainInfoFlags::FULL_QA_POWER;
    let full_qa_power = qa_power_max(sector_size);

    // As of FIP-0098, these fields are unused and should be unset.
    new_sector.expected_day_reward = None;
    new_sector.expected_storage_pledge = None;
    new_sector.replaced_day_reward = None;

    new_sector.initial_pledge = max(new_sector.initial_pledge, full_power_pledge.clone());

    if new_sector.daily_fee.is_zero() {
        // Sector predates FIP-0100 fees; attach the fee at the upgraded rate.
        new_sector.daily_fee = daily_proof_fee(policy, circulating_supply, &full_qa_power);
    } else {
        // The old power must come from the pre-upgrade record; new_sector is flagged.
        let old_qa_power = qa_power_for_sector(sector_size, sector);
        new_sector.daily_fee =
            daily_proof_fee_adjust(&new_sector.daily_fee, &old_qa_power, &full_qa_power);
    }

    Ok(new_sector)
}

// Validates replica update manifests against parallel sector records.
fn validate_replica_updates<BS>(
    params: &ProveReplicaUpdates3Params,
    sector_infos: &[SectorOnChainInfo],
    state: &State,
    policy: &Policy,
    curr_epoch: ChainEpoch,
    store: BS,
) -> Result<BatchReturn, ActorError>
where
    BS: Blockstore,
{
    let mut sector_numbers = BTreeSet::<SectorNumber>::new();
    let mut validate_one = |update: &SectorUpdateManifest,
                            sector_info: &SectorOnChainInfo,
                            proof_len: usize|
     -> Result<(), ActorError> {
        if !sector_numbers.insert(update.sector) {
            return Err(actor_error!(
                illegal_argument,
                "skipping duplicate sector {}",
                update.sector
            ));
        }

        if proof_len > 4096 {
            return Err(actor_error!(
                illegal_argument,
                "update proof is too large ({}), skipping sector {}",
                proof_len,
                update.sector
            ));
        }

        if update.deadline >= policy.wpost_period_deadlines {
            return Err(actor_error!(
                illegal_argument,
                "deadline {} not in range 0..{}, skipping sector {}",
                update.deadline,
                policy.wpost_period_deadlines,
                update.sector
            ));
        }

        if !is_sealed_sector(&update.new_sealed_cid) {
            return Err(actor_error!(
                illegal_argument,
                "new sealed CID had wrong prefix {}, skipping sector {}",
                update.new_sealed_cid,
                update.sector
            ));
        }

        // Disallow upgrading sectors in immutable deadlines.
        if !deadline_is_mutable(
            policy,
            state.current_proving_period_start(policy, curr_epoch),
            update.deadline,
            curr_epoch,
        ) {
            return Err(actor_error!(
                illegal_argument,
                "cannot upgrade sectors in immutable deadline {}, skipping sector {}",
                update.deadline,
                update.sector
            ));
        }

        // This inefficiently loads deadline/partition info for each update.
        if !state.check_sector_active(
            &store,
            update.deadline,
            update.partition,
            update.sector,
            true,
        )? {
            return Err(actor_error!(
                illegal_argument,
                "sector isn't active, skipping sector {}",
                update.sector
            ));
        }

        if (&sector_info.deal_weight + &sector_info.verified_deal_weight) != DealWeight::zero() {
            return Err(actor_error!(
                illegal_argument,
                "cannot update sector with non-zero data, skipping sector {}",
                update.sector
            ));
        }

        let expected_proof_type = sector_info
            .seal_proof
            .registered_update_proof()
            .context_code(ExitCode::USR_ILLEGAL_STATE, "couldn't load update proof type")?;
        if params.update_proofs_type != expected_proof_type {
            return Err(actor_error!(
                illegal_argument,
                "expected proof type {}, was {}",
                i64::from(expected_proof_type),
                i64::from(params.update_proofs_type)
            ));
        }
        Ok(())
    };

    let mut batch = BatchReturnGen::new(params.sector_updates.len());
    for (i, (update, sector_info)) in params.sector_updates.iter().zip(sector_infos).enumerate() {
        let proof_len = params.sector_proofs.get(i).map_or(0, |proof| proof.len());
        match validate_one(update, sector_info, proof_len) {
            Ok(_) => {
                batch.add_success();
            }
            Err(e) => {
                let e = e.wrap(format!("invalid update {} while requiring activation success", i));
                info!("{}", e.msg());
                if params.require_activation_success {
                    return Err(e);
                }
                batch.add_fail(ExitCode::USR_ILLEGAL_ARGUMENT);
            }
        }
    }
    Ok(batch.generate())
}

fn update_replica_states<R: Runtime>(
    rt: &R,
    updates_by_partition: &BTreeMap<(u64, u64), Vec<ReplicaUpdateStateInputs>>,
    sector_size: SectorSize,
) -> Result<(PowerPair, TokenAmount), ActorError> {
    let rew = request_current_epoch_block_reward(rt)?;
    let pow = request_current_total_power(rt)?;
    let circulating_supply = rt.total_fil_circ_supply();
    let pledge_inputs = NetworkPledgeInputs {
        network_qap: pow.quality_adj_power_smoothed,
        network_baseline: rew.this_epoch_baseline_power,
        circulating_supply,
        epoch_reward: rew.this_epoch_reward_smoothed,
        epochs_since_ramp_start: rt.curr_epoch() - pow.ramp_start_epoch,
        ramp_duration_epochs: pow.ramp_duration_epochs,
    };

    // FIP-0118: all sectors get maximum QA power (10x); same for every update in this batch.
    let new_qa_power = qa_power_max(sector_size);

    rt.transaction(|state: &mut State, rt| {
        let replace_replica_batch =
            |(_, updates): (&(u64, u64), &Vec<ReplicaUpdateStateInputs<'_>>),
             key: &PartitionKey,
             partition: &mut Partition,
             sectors: &mut Sectors<R::Blockstore>,
             quant: QuantSpec| {
                let new_sectors = updates
                    .iter()
                    .map(|update| {
                        update_existing_sector_info(
                            rt.policy(),
                            update,
                            &pledge_inputs,
                            sector_size,
                            &new_qa_power,
                            rt.curr_epoch(),
                        )
                    })
                    .collect();

                replace_partition_sector_records(
                    SectorRecordReplacementContext { store: rt.store(), key, sector_size, quant },
                    partition,
                    sectors,
                    updates.iter().map(|update| update.sector_info),
                    new_sectors,
                )
            };

        let (power_delta, pledge_delta) = replace_sector_record_batches(
            rt.policy(),
            rt.store(),
            state,
            updates_by_partition,
            |((deadline, partition), _)| SectorRecordBatchLocation {
                deadline: *deadline,
                partition: *partition,
                new_expiration: None,
            },
            replace_replica_batch,
        )?;

        let current_balance = rt.current_balance();
        if pledge_delta.is_positive() {
            let unlocked_balance = state.get_unlocked_balance(&current_balance).map_err(|e| {
                actor_error!(illegal_state, "failed to calculate unlocked balance: {}", e)
            })?;
            if unlocked_balance < pledge_delta {
                return Err(actor_error!(
                    insufficient_funds,
                    "insufficient funds for aggregate initial pledge requirement {}, available: {}",
                    pledge_delta,
                    unlocked_balance
                ));
            }
        }

        state
            .add_initial_pledge(&pledge_delta)
            .map_err(|e| actor_error!(illegal_state, "failed to add initial pledge: {}", e))?;
        state.check_balance_invariants(&current_balance).map_err(balance_invariants_broken)?;

        Ok((power_delta, pledge_delta))
    })
}

// Builds a new sector info representing newly activated data in an existing sector.
fn update_existing_sector_info(
    policy: &Policy,
    update: &ReplicaUpdateStateInputs,
    pledge_inputs: &NetworkPledgeInputs,
    sector_size: SectorSize,
    // FIP-0118: all sectors get maximum QA power (10x). Computed once by the caller since it's
    // the same for every sector in a batch of replica updates.
    new_qa_power: &StoragePower,
    curr_epoch: ChainEpoch,
) -> SectorOnChainInfo {
    let sector_info = update.sector_info;
    let mut new_sector_info = sector_info.clone();

    new_sector_info.flags.set(SectorOnChainInfoFlags::SIMPLE_QA_POWER, true);
    // FIP-0118: replica updates always get full QA power.
    new_sector_info.flags.set(SectorOnChainInfoFlags::FULL_QA_POWER, true);
    new_sector_info.sealed_cid = update.seal_cid;
    new_sector_info.sector_key_cid = match new_sector_info.sector_key_cid {
        None => Some(sector_info.sealed_cid),
        Some(x) => Some(x),
    };

    new_sector_info.power_base_epoch = curr_epoch;

    let duration = new_sector_info.expiration - new_sector_info.power_base_epoch;

    new_sector_info.deal_weight = DealWeight::zero();
    new_sector_info.verified_deal_weight = BigInt::from(update.space) * duration;

    new_sector_info.expected_day_reward = None;
    new_sector_info.replaced_day_reward = None;
    new_sector_info.expected_storage_pledge = None;

    // Most snaps raise no power, so pledge and existing fees remain unchanged.
    let old_qa_power = qa_power_for_sector(sector_size, sector_info);
    let power_changed = old_qa_power != *new_qa_power;
    if power_changed {
        new_sector_info.initial_pledge = max(
            new_sector_info.initial_pledge,
            pledge_inputs.initial_pledge_for_power(new_qa_power),
        );
    }
    if new_sector_info.daily_fee.is_zero() {
        // pre-FIP-0100 sector
        new_sector_info.daily_fee =
            daily_proof_fee(policy, &pledge_inputs.circulating_supply, new_qa_power);
    } else {
        new_sector_info.daily_fee =
            daily_proof_fee_adjust(&new_sector_info.daily_fee, &old_qa_power, new_qa_power);
    }
    new_sector_info
}

// Note: We're using the current power+epoch reward, rather than at time of termination.
fn process_early_terminations(
    rt: &impl Runtime,
    reward_smoothed: &FilterEstimate,
    quality_adj_power_smoothed: &FilterEstimate,
) -> Result<
    bool, // has more
    ActorError,
> {
    let mut terminated_sector_nums = vec![];
    let mut sectors_with_data = vec![];
    let (result, more, penalty, pledge_delta) = rt.transaction(|state: &mut State, rt| {
        let store = rt.store();
        let policy = rt.policy();

        let (result, more) = state
            .pop_early_terminations(
                policy,
                store,
                policy.addressed_partitions_max,
                policy.addressed_sectors_max,
            )
            .context_code(ExitCode::USR_ILLEGAL_STATE, "failed to pop early terminations")?;

        // Nothing to do, don't waste any time.
        // This can happen if we end up processing early terminations
        // before the cron callback fires.
        if result.is_empty() {
            info!("no early terminations (maybe cron callback hasn't happened yet?)");
            return Ok((result, more, TokenAmount::zero(), TokenAmount::zero()));
        }

        let info = get_miner_info(rt.store(), state)?;
        let sectors = Sectors::load(store, &state.sectors).map_err(|e| {
            e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to load sectors array")
        })?;

        let mut total_initial_pledge = TokenAmount::zero();
        let mut total_penalty = TokenAmount::zero();

        for (epoch, sector_numbers) in result.iter() {
            let sectors = sectors
                .load_sectors(sector_numbers)
                .map_err(|e| e.wrap("failed to load sector infos"))?;

            for sector in &sectors {
                total_initial_pledge += &sector.initial_pledge;
                let sector_power = qa_power_for_sector(info.sector_size, sector);
                terminated_sector_nums.push(sector.sector_number);
                let sector_age = epoch - sector.activation;
                let fault_fee = pledge_penalty_for_continued_fault(
                    reward_smoothed,
                    quality_adj_power_smoothed,
                    &sector_power,
                );
                total_penalty +=
                    pledge_penalty_for_termination(&sector.initial_pledge, sector_age, &fault_fee);
                if sector.deal_weight.is_positive() || sector.verified_deal_weight.is_positive() {
                    sectors_with_data.push(sector.sector_number);
                }
            }
        }

        // Apply penalty (add to fee debt)
        state
            .apply_penalty(&total_penalty)
            .map_err(|e| actor_error!(illegal_state, "failed to apply penalty: {}", e))?;

        // Remove pledge requirement.
        let mut pledge_delta = -total_initial_pledge;
        state.add_initial_pledge(&pledge_delta).map_err(|e| {
            actor_error!(illegal_state, "failed to add initial pledge {}: {}", pledge_delta, e)
        })?;

        // Use unlocked pledge to pay down outstanding fee debt
        let (penalty, total_unlocked) = state
            .repay_partial_debt_in_priority_order(
                rt.store(),
                rt.curr_epoch(),
                &rt.current_balance(),
            )
            .map_err(|e| {
                e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to repay penalty")
            })?;

        pledge_delta -= total_unlocked;

        Ok((result, more, penalty, pledge_delta))
    })?;

    // We didn't do anything, abort.
    if result.is_empty() {
        info!("no early terminations");
        return Ok(more);
    }

    // Burn penalty.
    log::debug!(
        "storage provider {} penalized {} for sector termination",
        rt.message().receiver(),
        penalty
    );
    burn_funds(rt, penalty)?;

    // Return pledge.
    notify_pledge_changed(rt, &pledge_delta)?;

    // Terminate deals.
    let terminated_data = BitField::try_from_bits(sectors_with_data)
        .context_code(ExitCode::USR_ILLEGAL_STATE, "invalid sector number")?;
    request_terminate_deals(rt, rt.curr_epoch(), &terminated_data)?;

    for sector in terminated_sector_nums {
        emit::sector_terminated(rt, sector)?;
    }

    // reschedule cron worker, if necessary.
    Ok(more)
}

/// Invoked at the end of the last epoch for each proving deadline.
fn handle_proving_deadline(
    rt: &impl Runtime,
    reward_smoothed: &FilterEstimate,
    quality_adj_power_smoothed: &FilterEstimate,
) -> Result<(), ActorError> {
    let curr_epoch = rt.curr_epoch();

    let mut had_early_terminations = false;

    let mut power_delta_total = PowerPair::zero();
    let mut penalty_total = TokenAmount::zero();
    let mut pledge_delta_total = TokenAmount::zero();
    let mut continue_cron = false;

    let state: State = rt.transaction(|state: &mut State, rt| {
        let policy = rt.policy();

        // Process pending worker change if any
        let mut info = get_miner_info(rt.store(), state)?;
        process_pending_worker(&mut info, rt, state)?;

        let deposit_to_burn = state
            .cleanup_expired_pre_commits(policy, rt.store(), rt.curr_epoch())
            .map_err(|e| {
                e.downcast_default(
                    ExitCode::USR_ILLEGAL_STATE,
                    "failed to expire pre-committed sectors",
                )
            })?;
        state
            .apply_penalty(&deposit_to_burn)
            .map_err(|e| actor_error!(illegal_state, "failed to apply penalty: {}", e))?;

        log::debug!(
            "storage provider {} penalized {} for expired pre commits",
            rt.message().receiver(),
            deposit_to_burn
        );

        // Record whether or not we _had_ early terminations in the queue before this method.
        // That way, don't re-schedule a cron callback if one is already scheduled.
        had_early_terminations = have_pending_early_terminations(state);

        let result = state.advance_deadline(policy, rt.store(), rt.curr_epoch()).map_err(|e| {
            e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to advance deadline")
        })?;

        // Faults detected by this missed PoSt pay no penalty, but sectors that were already faulty
        // and remain faulty through this deadline pay the fault fee.
        let penalty_target = pledge_penalty_for_continued_fault(
            reward_smoothed,
            quality_adj_power_smoothed,
            &result.previously_faulty_power.qa,
        );

        power_delta_total += &result.power_delta;
        pledge_delta_total += &result.pledge_delta;

        state
            .apply_penalty(&penalty_target)
            .map_err(|e| actor_error!(illegal_state, "failed to apply penalty: {}", e))?;

        log::debug!(
            "storage provider {} penalized {} for continued fault",
            rt.message().receiver(),
            penalty_target
        );

        if result.daily_fee.is_positive() {
            // Apply daily fee for sectors in this deadline, applied through the penalty/fee_debt
            // mechanism. The daily fee payable is capped at a fraction of estimated daily block
            // reward for the sectors being charged.
            // Note that the daily_fee and live_power values here do not include sectors that have
            // just been removed from the deadline via advance_dealine (above), but they do include
            // sectors that have been added within the current proving period.
            let day_reward = expected_reward_for_power(
                reward_smoothed,
                quality_adj_power_smoothed,
                &result.live_power.qa,
                fil_actors_runtime::EPOCHS_IN_DAY,
            );
            let daily_fee = daily_proof_fee_payable(policy, &result.daily_fee, &day_reward);

            state
                .apply_penalty(&daily_fee)
                .map_err(|e| actor_error!(illegal_state, "failed to apply penalty: {}", e))?;
        }

        let (penalty, total_unlocked) = state
            .repay_partial_debt_in_priority_order(
                rt.store(),
                rt.curr_epoch(),
                &rt.current_balance(),
            )
            .map_err(|e| {
                e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to unlock penalty")
            })?;

        penalty_total = penalty;
        pledge_delta_total -= total_unlocked;

        // Vest locked funds. Locked funds will already have been vested automatically if we paid
        // any fees/penalties, but we try to vest one more time just in case.
        //
        // If there's nothing to vest, this is an inexpensive operation as it'll just look at the
        // "head" of the vesting queue, which is inlined into the root state object.
        let newly_vested = state
            .unlock_vested_funds(rt.store(), rt.curr_epoch())
            .map_err(|e| e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to vest funds"))?;

        pledge_delta_total -= newly_vested;

        continue_cron = state.continue_deadline_cron();
        if !continue_cron {
            state.deadline_cron_active = false;
        }

        Ok(state.clone())
    })?;

    // Remove power for new faults, and burn penalties.
    request_update_power(rt, power_delta_total)?;
    burn_funds(rt, penalty_total)?;
    // Update the total locked funds in the network.
    notify_pledge_changed(rt, &pledge_delta_total)?;

    // Schedule cron callback for next deadline's last epoch.
    if continue_cron {
        let new_deadline_info = state.deadline_info(rt.policy(), curr_epoch + 1);
        enroll_cron_event(
            rt,
            new_deadline_info.last(),
            CronEventPayload { event_type: CRON_EVENT_PROVING_DEADLINE },
        )?;
    } else {
        info!("miner {} going inactive, deadline cron discontinued", rt.message().receiver())
    }

    // Record whether or not we _have_ early terminations now.
    let has_early_terminations = have_pending_early_terminations(&state);

    // If we didn't have pending early terminations before, but we do now,
    // handle them at the next epoch.
    if !had_early_terminations && has_early_terminations {
        // First, try to process some of these terminations.
        if process_early_terminations(rt, reward_smoothed, quality_adj_power_smoothed)? {
            // If that doesn't work, just defer till the next epoch.
            schedule_early_termination_work(rt)?;
        }

        // Note: _don't_ process early terminations if we had a cron
        // callback already scheduled. In that case, we'll already have
        // processed AddressedSectorsMax terminations this epoch.
    }

    Ok(())
}

fn validate_expiration(
    policy: &Policy,
    curr_epoch: ChainEpoch,
    activation: ChainEpoch,
    expiration: ChainEpoch,
    seal_proof: RegisteredSealProof,
) -> Result<(), ActorError> {
    // Expiration must be after activation. Check this explicitly to avoid an underflow below.
    if expiration <= activation {
        return Err(actor_error!(
            illegal_argument,
            "sector expiration {} must be after activation {}",
            expiration,
            activation
        ));
    }

    // expiration cannot be less than minimum after activation
    if expiration - activation < policy.min_sector_expiration {
        return Err(actor_error!(
            illegal_argument,
            "invalid expiration {}, total sector lifetime ({}) must exceed {} after activation {}",
            expiration,
            expiration - activation,
            policy.min_sector_expiration,
            activation
        ));
    }

    // expiration cannot exceed MaxSectorExpirationExtension from now
    if expiration > curr_epoch + policy.max_sector_expiration_extension {
        return Err(actor_error!(
            illegal_argument,
            "invalid expiration {}, cannot be more than {} past current epoch {}",
            expiration,
            policy.max_sector_expiration_extension,
            curr_epoch
        ));
    }

    // total sector lifetime cannot exceed SectorMaximumLifetime for the sector's seal proof
    let max_lifetime = seal_proof_sector_maximum_lifetime(seal_proof).ok_or_else(|| {
        actor_error!(illegal_argument, "unrecognized seal proof type {:?}", seal_proof)
    })?;
    if expiration - activation > max_lifetime {
        return Err(actor_error!(
            illegal_argument,
            "invalid expiration {}, total sector lifetime ({}) cannot exceed {} after activation {}",
            expiration,
            expiration - activation,
            max_lifetime,
            activation
        ));
    }

    Ok(())
}

fn enroll_cron_event(
    rt: &impl Runtime,
    event_epoch: ChainEpoch,
    cb: CronEventPayload,
) -> Result<(), ActorError> {
    let payload = serialize(&cb, "cron payload")?;
    let ser_params =
        IpldBlock::serialize_cbor(&ext::power::EnrollCronEventParams { event_epoch, payload })?;
    extract_send_result(rt.send_simple(
        &STORAGE_POWER_ACTOR_ADDR,
        ext::power::ENROLL_CRON_EVENT_METHOD,
        ser_params,
        TokenAmount::zero(),
    ))?;

    Ok(())
}

fn request_update_power(rt: &impl Runtime, delta: PowerPair) -> Result<(), ActorError> {
    if delta.is_zero() {
        return Ok(());
    }

    let delta_clone = delta.clone();

    extract_send_result(rt.send_simple(
        &STORAGE_POWER_ACTOR_ADDR,
        ext::power::UPDATE_CLAIMED_POWER_METHOD,
        IpldBlock::serialize_cbor(&ext::power::UpdateClaimedPowerParams {
            raw_byte_delta: delta.raw,
            quality_adjusted_delta: delta.qa,
        })?,
        TokenAmount::zero(),
    ))
    .map_err(|e| e.wrap(format!("failed to update power with {:?}", delta_clone)))?;

    Ok(())
}

fn request_terminate_deals(
    rt: &impl Runtime,
    epoch: ChainEpoch,
    sectors: &BitField,
) -> Result<(), ActorError> {
    if !sectors.is_empty() {
        // The sectors bitfield could be large, but will fit into a single parameters block.
        // The FVM max block size of 1MiB supports 130K 8-byte integers, but the policy parameter
        // ADDRESSED_SECTORS_MAX (currently 25k) will avoid reaching that.
        let res = extract_send_result(rt.send_simple(
            &STORAGE_MARKET_ACTOR_ADDR,
            ext::market::ON_MINER_SECTORS_TERMINATE_METHOD,
            IpldBlock::serialize_cbor(&ext::market::OnMinerSectorsTerminateParams {
                epoch,
                sectors: sectors.clone(),
            })?,
            TokenAmount::zero(),
        ));
        // If running in a system / cron context intentionally swallow this error to prevent
        // frozen market cron corruption from also freezing this miner cron.
        if rt.message().origin() == SYSTEM_ACTOR_ADDR {
            if let Err(e) = res {
                error!("OnSectorsTerminate event failed from cron caller {}", e)
            }
        } else {
            res?;
        }
    }
    Ok(())
}

fn schedule_early_termination_work(rt: &impl Runtime) -> Result<(), ActorError> {
    info!("scheduling early terminations with cron...");
    enroll_cron_event(
        rt,
        rt.curr_epoch() + 1,
        CronEventPayload { event_type: CRON_EVENT_PROCESS_EARLY_TERMINATIONS },
    )
}

fn have_pending_early_terminations(state: &State) -> bool {
    let no_early_terminations = state.early_terminations.is_empty();
    !no_early_terminations
}

// returns true if valid, false if invalid, error if failed to validate either way!
fn verify_windowed_post(
    rt: &impl Runtime,
    challenge_epoch: ChainEpoch,
    sectors: &[SectorOnChainInfo],
    proofs: Vec<PoStProof>,
) -> Result<bool, ActorError> {
    let miner_actor_id: u64 = if let Payload::ID(i) = rt.message().receiver().payload() {
        *i
    } else {
        return Err(actor_error!(
            illegal_state,
            "runtime provided bad receiver address {}",
            rt.message().receiver()
        ));
    };

    // Regenerate challenge randomness, which must match that generated for the proof.
    let entropy = serialize(&rt.message().receiver(), "address for window post challenge")?;
    let randomness = rt.get_randomness_from_beacon(
        DomainSeparationTag::WindowedPoStChallengeSeed,
        challenge_epoch,
        &entropy,
    )?;

    let challenged_sectors = sectors
        .iter()
        .map(|s| SectorInfo {
            proof: s.seal_proof,
            sector_number: s.sector_number,
            sealed_cid: s.sealed_cid,
        })
        .collect();

    // get public inputs
    let pv_info = WindowPoStVerifyInfo {
        randomness: Randomness(randomness.into()),
        proofs,
        challenged_sectors,
        prover: miner_actor_id,
    };

    // verify the post proof
    let result = rt.verify_post(&pv_info);
    Ok(result.is_ok())
}

struct SectorSealProofInput {
    pub registered_proof: RegisteredSealProof,
    pub sector_number: SectorNumber,
    pub randomness: SealRandomness,
    pub interactive_randomness: InteractiveSealRandomness,
    // Commr
    pub sealed_cid: Cid,
    // Commd
    pub unsealed_cid: Cid,
}

impl SectorSealProofInput {
    fn to_seal_verify_info(&self, miner_actor_id: u64, proof: &RawBytes) -> SealVerifyInfo {
        SealVerifyInfo {
            registered_proof: self.registered_proof,
            sector_id: SectorID { miner: miner_actor_id, number: self.sector_number },
            deal_ids: vec![], // unused by the proofs api so this is safe to leave empty
            randomness: self.randomness.clone(),
            interactive_randomness: self.interactive_randomness.clone(),
            proof: proof.clone().into(),
            sealed_cid: self.sealed_cid,
            unsealed_cid: self.unsealed_cid,
        }
    }

    fn to_aggregate_seal_verify_info(&self) -> AggregateSealVerifyInfo {
        AggregateSealVerifyInfo {
            sector_number: self.sector_number,
            randomness: self.randomness.clone(),
            interactive_randomness: self.interactive_randomness.clone(),
            sealed_cid: self.sealed_cid,
            unsealed_cid: self.unsealed_cid,
        }
    }
}

// Validates pre-committed sectors are ready for proving and committing this epoch.
// Returns seal proof verification inputs for every pre-commit, even those that fail validation.
// The proof verification inputs are needed as witnesses to verify an aggregated proof to allow
// other, valid, sectors to succeed.
fn validate_precommits(
    rt: &impl Runtime,
    precommits: &[SectorPreCommitOnChainInfo],
    all_or_nothing: bool,
) -> Result<(BatchReturn, Vec<SectorSealProofInput>), ActorError> {
    if precommits.is_empty() {
        return Ok((BatchReturn::empty(), vec![]));
    }
    let mut batch = BatchReturnGen::new(precommits.len());

    let mut verify_infos = vec![];
    for (i, precommit) in precommits.iter().enumerate() {
        // We record failures and continue validation rather than continuing the loop in order to:
        // 1. compute aggregate seal verification inputs
        // 2. check for whole message failure conditions
        let mut fail_validation = false;
        // A pre-Solstice precommit may still carry deal ids; nothing activates them, so it
        // can never be proven.
        if !precommit.info.deal_ids.is_empty() {
            warn!(
                "skipping commitment for sector {}, precommit has deal ids which are disallowed",
                precommit.info.sector_number,
            );
            fail_validation = true;
        }
        let msd =
            max_prove_commit_duration(rt.policy(), precommit.info.seal_proof).ok_or_else(|| {
                actor_error!(
                    illegal_state,
                    "no max seal duration for proof type: {}",
                    i64::from(precommit.info.seal_proof)
                )
            })?;
        let prove_commit_due = precommit.pre_commit_epoch + msd;
        if rt.curr_epoch() > prove_commit_due {
            warn!(
                "skipping commitment for sector {}, too late at {}, due {}",
                precommit.info.sector_number,
                rt.curr_epoch(),
                prove_commit_due,
            );
            fail_validation = true
        }

        // All seal proof types should match
        if i >= 1 {
            let prev_seal_proof = precommits[i - 1].info.seal_proof;
            if prev_seal_proof != precommit.info.seal_proof {
                return Err(actor_error!(
                    illegal_state,
                    "seal proof group for verification contains mismatched seal proofs {} and {}",
                    i64::from(prev_seal_proof),
                    i64::from(precommit.info.seal_proof)
                ));
            }
        }
        let interactive_epoch = precommit.pre_commit_epoch + rt.policy().pre_commit_challenge_delay;
        if rt.curr_epoch() <= interactive_epoch {
            return Err(actor_error!(forbidden, "too early to prove sector"));
        }

        // Compute svi for all commits even those that will not be activated.
        // Callers might prove using aggregates and need witnesses for invalid commits.
        let entropy = serialize(&rt.message().receiver(), "address for get verify info")?;
        let randomness = Randomness(
            rt.get_randomness_from_tickets(
                DomainSeparationTag::SealRandomness,
                precommit.info.seal_rand_epoch,
                &entropy,
            )?
            .into(),
        );
        let interactive_randomness = Randomness(
            rt.get_randomness_from_beacon(
                DomainSeparationTag::InteractiveSealChallengeSeed,
                interactive_epoch,
                &entropy,
            )?
            .into(),
        );

        let unsealed_cid = precommit.info.unsealed_cid.get_cid(precommit.info.seal_proof)?;
        verify_infos.push(SectorSealProofInput {
            registered_proof: precommit.info.seal_proof,
            sector_number: precommit.info.sector_number,
            randomness,
            interactive_randomness,
            sealed_cid: precommit.info.sealed_cid,
            unsealed_cid,
        });

        if fail_validation {
            if all_or_nothing {
                return Err(actor_error!(
                    illegal_argument,
                    "invalid pre-commit {} while requiring activation success: {:?}",
                    i,
                    precommit
                ));
            }
            batch.add_fail(ExitCode::USR_ILLEGAL_ARGUMENT);
        } else {
            batch.add_success();
        }
    }
    Ok((batch.generate(), verify_infos))
}

fn validate_ni_sectors(
    rt: &impl Runtime,
    sectors: &[SectorNIActivationInfo],
    seal_proof_type: RegisteredSealProof,
    all_or_nothing: bool,
) -> Result<(BatchReturn, Vec<SectorSealProofInput>, BitField), ActorError> {
    let receiver = rt.message().receiver();
    let miner_id = receiver.id().unwrap();
    let curr_epoch = rt.curr_epoch();
    let activation_epoch = curr_epoch;
    let challenge_earliest = curr_epoch - rt.policy().max_prove_commit_ni_randomness_lookback;
    let unsealed_cid = CompactCommD::empty().get_cid(seal_proof_type).unwrap();
    let entropy = serialize(&receiver, "address for get verify info")?;

    if sectors.is_empty() {
        return Ok((BatchReturn::empty(), vec![], BitField::new()));
    }
    let mut batch = BatchReturnGen::new(sectors.len());

    let mut verify_infos = vec![];
    let mut sector_numbers = BitField::new();
    for (i, sector) in sectors.iter().enumerate() {
        let mut fail_validation = false;

        if sector_numbers.get(sector.sector_number) {
            return Err(actor_error!(
                illegal_argument,
                "duplicate sector number {}",
                sector.sector_number
            ));
        }

        if sector.sector_number > MAX_SECTOR_NUMBER {
            warn!("sector number {} out of range 0..(2^63-1)", sector.sector_number);
            fail_validation = true;
        }

        sector_numbers.set(sector.sector_number);

        if let Err(err) = validate_expiration(
            rt.policy(),
            curr_epoch,
            activation_epoch,
            sector.expiration,
            seal_proof_type,
        ) {
            warn!("invalid expiration: {}", err);
            fail_validation = true;
        }

        if sector.sealer_id != miner_id {
            warn!("sealer must be the same as the receiver actor for all sectors");
            fail_validation = true;
        }

        if sector.sector_number != sector.sealing_number {
            warn!("sealing number must be same as sector number for all sectors");
            fail_validation = true;
        }

        if !is_sealed_sector(&sector.sealed_cid) {
            warn!("sealed CID had wrong prefix");
            fail_validation = true;
        }

        if sector.seal_rand_epoch >= curr_epoch {
            // hard-fail because we can't access necessary randomness from the future
            return Err(actor_error!(
                illegal_argument,
                "seal challenge epoch {} must be before now {}",
                sector.seal_rand_epoch,
                curr_epoch
            ));
        }

        if sector.seal_rand_epoch < challenge_earliest {
            warn!(
                "seal challenge epoch {} too old, must be after {}",
                sector.seal_rand_epoch, challenge_earliest
            );
            fail_validation = true;
        }

        verify_infos.push(SectorSealProofInput {
            registered_proof: seal_proof_type,
            sector_number: sector.sealing_number,
            randomness: Randomness(
                rt.get_randomness_from_tickets(
                    DomainSeparationTag::SealRandomness,
                    sector.seal_rand_epoch,
                    &entropy,
                )?
                .into(),
            ),
            interactive_randomness: Randomness(vec![1u8; 32]),
            sealed_cid: sector.sealed_cid,
            unsealed_cid,
        });

        if fail_validation {
            if all_or_nothing {
                return Err(actor_error!(
                    illegal_argument,
                    "invalid NI commit {} while requiring activation success: {:?}",
                    i,
                    sector
                ));
            }
            batch.add_fail(ExitCode::USR_ILLEGAL_ARGUMENT);
        } else {
            batch.add_success();
        }
    }

    Ok((batch.generate(), verify_infos, sector_numbers))
}

// Validates a batch of sector sealing proofs.
fn validate_seal_proofs(
    seal_proof_type: RegisteredSealProof,
    proofs: &[RawBytes],
) -> Result<(), ActorError> {
    let max_proof_size =
        seal_proof_type.proof_size().with_context_code(ExitCode::USR_ILLEGAL_STATE, || {
            format!("failed to determine max proof size for type {:?}", seal_proof_type,)
        })?;
    for proof in proofs {
        if proof.len() > max_proof_size {
            return Err(actor_error!(
                illegal_argument,
                "sector proof size {} exceeds max {}",
                proof.len(),
                max_proof_size
            ));
        }
    }
    Ok(())
}

fn validate_seal_aggregate_proof(
    proof: &RawBytes,
    sector_count: u64,
    policy: &Policy,
    interactive: bool,
) -> Result<(), ActorError> {
    let (min, max) = match interactive {
        true => (policy.min_aggregated_sectors, policy.max_aggregated_sectors),
        false => (policy.min_aggregated_sectors_ni, policy.max_aggregated_sectors_ni),
    };

    if sector_count > max {
        return Err(actor_error!(
            illegal_argument,
            "too many sectors addressed, addressed {} want <= {}",
            sector_count,
            max
        ));
    } else if sector_count < min {
        return Err(actor_error!(
            illegal_argument,
            "too few sectors addressed, addressed {} want >= {}",
            sector_count,
            min
        ));
    }
    if proof.len() > policy.max_aggregated_proof_size {
        return Err(actor_error!(
            illegal_argument,
            "sector prove-commit proof of size {} exceeds max size of {}",
            proof.len(),
            policy.max_aggregated_proof_size
        ));
    }
    Ok(())
}

fn verify_aggregate_seal(
    rt: &impl Runtime,
    proof_inputs: &[SectorSealProofInput],
    miner_actor_id: ActorID,
    seal_proof: RegisteredSealProof,
    aggregate_proof: RegisteredAggregateProof,
    proof_bytes: &RawBytes,
) -> Result<(), ActorError> {
    let seal_verify_inputs =
        proof_inputs.iter().map(|pi| pi.to_aggregate_seal_verify_info()).collect();

    rt.verify_aggregate_seals(&AggregateSealVerifyProofAndInfos {
        miner: miner_actor_id,
        seal_proof,
        aggregate_proof,
        proof: proof_bytes.clone().into(),
        infos: seal_verify_inputs,
    })
    .context_code(ExitCode::USR_ILLEGAL_ARGUMENT, "aggregate seal verify failed")
}

/// Requests the current epoch target block reward from the reward actor.
/// return value includes reward, smoothed estimate of reward, and baseline power
fn request_current_epoch_block_reward(
    rt: &impl Runtime,
) -> Result<ThisEpochRewardReturn, ActorError> {
    deserialize_block(
        extract_send_result(rt.send_simple(
            &REWARD_ACTOR_ADDR,
            ext::reward::THIS_EPOCH_REWARD_METHOD,
            Default::default(),
            TokenAmount::zero(),
        ))
        .map_err(|e| e.wrap("failed to check epoch reward"))?,
    )
}

/// Requests the current network total power and pledge from the power actor.
fn request_current_total_power(
    rt: &impl Runtime,
) -> Result<ext::power::CurrentTotalPowerReturn, ActorError> {
    deserialize_block(
        extract_send_result(rt.send_simple(
            &STORAGE_POWER_ACTOR_ADDR,
            ext::power::CURRENT_TOTAL_POWER_METHOD,
            Default::default(),
            TokenAmount::zero(),
        ))
        .map_err(|e| e.wrap("failed to check current power"))?,
    )
}

/// Resolves an address to an ID address and verifies that it is address of an account actor with an associated BLS key.
/// The worker must be BLS since the worker key will be used alongside a BLS-VRF.
fn resolve_worker_address(rt: &impl Runtime, raw: Address) -> Result<ActorID, ActorError> {
    let resolved = rt
        .resolve_address(&raw)
        .ok_or_else(|| actor_error!(illegal_argument, "unable to resolve address: {}", raw))?;

    let worker_code = rt
        .get_actor_code_cid(&resolved)
        .ok_or_else(|| actor_error!(illegal_argument, "no code for address: {}", resolved))?;
    if rt.resolve_builtin_actor_type(&worker_code) != Some(Type::Account) {
        return Err(actor_error!(
            illegal_argument,
            "worker actor type must be an account, was {}",
            worker_code
        ));
    }

    if raw.protocol() != Protocol::BLS {
        let pub_key: Address = deserialize_block(extract_send_result(rt.send_simple(
            &Address::new_id(resolved),
            ext::account::PUBKEY_ADDRESS_METHOD,
            None,
            TokenAmount::zero(),
        ))?)?;
        if pub_key.protocol() != Protocol::BLS {
            return Err(actor_error!(
                illegal_argument,
                "worker account {} must have BLS pubkey, was {}",
                resolved,
                pub_key.protocol()
            ));
        }
    }
    Ok(resolved)
}

fn burn_funds(rt: &impl Runtime, amount: TokenAmount) -> Result<(), ActorError> {
    log::debug!("storage provder {} burning {}", rt.message().receiver(), amount);
    if amount.is_positive() {
        extract_send_result(rt.send_simple(&BURNT_FUNDS_ACTOR_ADDR, METHOD_SEND, None, amount))?;
    }
    Ok(())
}

fn notify_pledge_changed(rt: &impl Runtime, pledge_delta: &TokenAmount) -> Result<(), ActorError> {
    if !pledge_delta.is_zero() {
        extract_send_result(rt.send_simple(
            &STORAGE_POWER_ACTOR_ADDR,
            ext::power::UPDATE_PLEDGE_TOTAL_METHOD,
            IpldBlock::serialize_cbor(pledge_delta)?,
            TokenAmount::zero(),
        ))?;
    }
    Ok(())
}

/// Assigns proving period offset randomly in the range [0, WPoStProvingPeriod) by hashing
/// the actor's address and current epoch.
fn assign_proving_period_offset(
    policy: &Policy,
    addr: Address,
    current_epoch: ChainEpoch,
    blake2b: impl FnOnce(&[u8]) -> [u8; 32],
) -> anyhow::Result<ChainEpoch> {
    let mut my_addr = serialize_vec(&addr, "address")?;
    my_addr.write_i64::<BigEndian>(current_epoch)?;

    let digest = blake2b(&my_addr);

    let mut offset: u64 = BigEndian::read_u64(&digest);
    offset %= policy.wpost_proving_period as u64;

    // Conversion from i64 to u64 is safe because it's % WPOST_PROVING_PERIOD which is i64
    Ok(offset as ChainEpoch)
}

/// Computes the epoch at which a proving period should start such that it is greater than the current epoch, and
/// has a defined offset from being an exact multiple of WPoStProvingPeriod.
/// A miner is exempt from Winow PoSt until the first full proving period starts.
fn current_proving_period_start(
    policy: &Policy,
    current_epoch: ChainEpoch,
    offset: ChainEpoch,
) -> ChainEpoch {
    let curr_modulus = current_epoch % policy.wpost_proving_period;

    let period_progress = if curr_modulus >= offset {
        curr_modulus - offset
    } else {
        policy.wpost_proving_period - (offset - curr_modulus)
    };

    current_epoch - period_progress
}

fn current_deadline_index(
    policy: &Policy,
    current_epoch: ChainEpoch,
    period_start: ChainEpoch,
) -> u64 {
    ((current_epoch - period_start) / policy.wpost_challenge_window) as u64
}

/// Computes deadline information for a fault or recovery declaration.
/// If the deadline has not yet elapsed, the declaration is taken as being for the current proving period.
/// If the deadline has elapsed, it's instead taken as being for the next proving period after the current epoch.
fn declaration_deadline_info(
    policy: &Policy,
    period_start: ChainEpoch,
    deadline_idx: u64,
    current_epoch: ChainEpoch,
) -> anyhow::Result<DeadlineInfo> {
    if deadline_idx >= policy.wpost_period_deadlines {
        return Err(anyhow!(
            "invalid deadline {}, must be < {}",
            deadline_idx,
            policy.wpost_period_deadlines
        ));
    }

    let deadline =
        new_deadline_info(policy, period_start, deadline_idx, current_epoch).next_not_elapsed();
    Ok(deadline)
}

/// Checks that a fault or recovery declaration at a specific deadline is outside the exclusion window for the deadline.
fn validate_fr_declaration_deadline(deadline: &DeadlineInfo) -> anyhow::Result<()> {
    if deadline.fault_cutoff_passed() {
        Err(anyhow!("late fault or recovery declaration"))
    } else {
        Ok(())
    }
}

/// Validates that a partition contains the given sectors.
fn validate_partition_contains_sectors(
    partition: &Partition,
    sectors: &BitField,
) -> anyhow::Result<()> {
    // Check that the declared sectors are actually assigned to the partition.
    if partition.sectors.contains_all(sectors) {
        Ok(())
    } else {
        Err(anyhow!("not all sectors are assigned to the partition"))
    }
}

fn consensus_fault_active(info: &MinerInfo, curr_epoch: ChainEpoch) -> bool {
    // For penalization period to last for exactly finality epochs
    // consensus faults are active until currEpoch exceeds ConsensusFaultElapsed
    curr_epoch <= info.consensus_fault_elapsed
}

pub fn power_for_sector(sector_size: SectorSize, sector: &SectorOnChainInfo) -> PowerPair {
    PowerPair {
        raw: BigInt::from(sector_size as u64),
        qa: qa_power_for_sector(sector_size, sector),
    }
}

/// Returns the sum of the raw byte and quality-adjusted power for sectors.
pub fn power_for_sectors(sector_size: SectorSize, sectors: &[SectorOnChainInfo]) -> PowerPair {
    let qa = sectors.iter().map(|s| qa_power_for_sector(sector_size, s)).sum();

    PowerPair { raw: BigInt::from(sector_size as u64) * BigInt::from(sectors.len()), qa }
}

pub fn daily_fee_for_sectors(sectors: &[SectorOnChainInfo]) -> TokenAmount {
    sectors.iter().map(|s| &s.daily_fee).sum()
}

fn get_miner_info<BS>(store: &BS, state: &State) -> Result<MinerInfo, ActorError>
where
    BS: Blockstore,
{
    state
        .get_info(store)
        .map_err(|e| e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "could not read miner info"))
}

fn process_pending_worker(
    info: &mut MinerInfo,
    rt: &impl Runtime,
    state: &mut State,
) -> Result<(), ActorError> {
    let pending_worker_key = if let Some(k) = &info.pending_worker_key {
        k
    } else {
        return Ok(());
    };

    if rt.curr_epoch() < pending_worker_key.effective_at {
        return Ok(());
    }

    info.worker = pending_worker_key.new_worker;
    info.pending_worker_key = None;

    state
        .save_info(rt.store(), info)
        .map_err(|e| e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to save miner info"))
}

/// Repays all fee debt and then verifies that the miner has amount needed to cover
/// the pledge requirement after burning all fee debt.  If not aborts.
/// Returns an amount that must be burnt by the actor.
/// Note that this call does not compute recent vesting so reported unlocked balance
/// may be slightly lower than the true amount. Computing vesting here would be
/// almost always redundant since vesting is quantized to ~daily units.  Vesting
/// will be at most one proving period old if computed in the cron callback.
fn repay_debts_or_abort(rt: &impl Runtime, state: &mut State) -> Result<TokenAmount, ActorError> {
    let res = state.repay_debts(&rt.current_balance()).map_err(|e| {
        e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "unlocked balance can not repay fee debt")
    })?;
    info!("RepayDebtsOrAbort was called and succeeded");
    Ok(res)
}

fn check_control_addresses(policy: &Policy, control_addrs: &[Address]) -> Result<(), ActorError> {
    if control_addrs.len() > policy.max_control_addresses {
        return Err(actor_error!(
            illegal_argument,
            "control addresses length {} exceeds max control addresses length {}",
            control_addrs.len(),
            policy.max_control_addresses
        ));
    }

    Ok(())
}

fn check_valid_post_proof_type(
    policy: &Policy,
    proof_type: RegisteredPoStProof,
) -> Result<(), ActorError> {
    if policy.valid_post_proof_type.contains(proof_type) {
        Ok(())
    } else {
        Err(actor_error!(
            illegal_argument,
            "proof type {:?} not allowed for new miner actors",
            proof_type
        ))
    }
}

fn check_peer_info(
    policy: &Policy,
    peer_id: &[u8],
    multiaddrs: &[BytesDe],
) -> Result<(), ActorError> {
    if peer_id.len() > policy.max_peer_id_length {
        return Err(actor_error!(
            illegal_argument,
            "peer ID size of {} exceeds maximum size of {}",
            peer_id.len(),
            policy.max_peer_id_length
        ));
    }

    let mut total_size = 0;
    for ma in multiaddrs {
        if ma.0.is_empty() {
            return Err(actor_error!(illegal_argument, "invalid empty multiaddr"));
        }
        total_size += ma.0.len();
    }

    if total_size > policy.max_multiaddr_data {
        return Err(actor_error!(
            illegal_argument,
            "multiaddr size of {} exceeds maximum of {}",
            total_size,
            policy.max_multiaddr_data
        ));
    }

    Ok(())
}

fn activate_new_sector_infos(
    rt: &impl Runtime,
    precommits: Vec<&SectorPreCommitOnChainInfo>,
    sector_spaces: Vec<u64>,
    pledge_inputs: &NetworkPledgeInputs,
    info: &MinerInfo,
) -> Result<(), ActorError> {
    let activation_epoch = rt.curr_epoch();

    let (total_pledge, newly_vested) = rt.transaction(|state: &mut State, rt| {
        let policy = rt.policy();
        let store = rt.store();

        let mut new_sector_numbers = Vec::<SectorNumber>::with_capacity(sector_spaces.len());
        let mut deposit_to_unlock = TokenAmount::zero();
        let mut new_sectors = Vec::<SectorOnChainInfo>::new();
        let mut total_pledge = TokenAmount::zero();

        // FIP-0118: all new sectors get 10x QA power regardless of content or duration, so
        // power/fee/pledge are identical for every sector in this batch; compute them once.
        let power = qa_power_max(info.sector_size);
        let daily_fee = daily_proof_fee(policy, &pledge_inputs.circulating_supply, &power);
        let initial_pledge = pledge_inputs.initial_pledge_for_power(&power);

        for (pci, space) in precommits.iter().zip(sector_spaces) {
            // compute initial pledge
            let duration = pci.info.expiration - activation_epoch;
            // This is probably always caught in precommit but fail cleanly if it occurs
            if duration < policy.min_sector_expiration {
                return Err(actor_error!(
                    illegal_argument,
                    "precommit {} has lifetime {} less than minimum {}. ignoring",
                    pci.info.sector_number,
                    duration,
                    policy.min_sector_expiration
                ));
            }

            let verified_deal_weight = BigInt::from(space) * duration;

            deposit_to_unlock += pci.pre_commit_deposit.clone();
            total_pledge += &initial_pledge;

            let new_sector_info = SectorOnChainInfo {
                sector_number: pci.info.sector_number,
                seal_proof: pci.info.seal_proof,
                sealed_cid: pci.info.sealed_cid,
                deprecated_deal_ids: vec![], // deal ids field deprecated
                expiration: pci.info.expiration,
                activation: activation_epoch,
                deal_weight: DealWeight::zero(),
                verified_deal_weight,
                initial_pledge: initial_pledge.clone(),
                expected_day_reward: None,
                expected_storage_pledge: None,
                power_base_epoch: activation_epoch,
                replaced_day_reward: None,
                sector_key_cid: None,
                flags: SectorOnChainInfoFlags::SIMPLE_QA_POWER
                    | SectorOnChainInfoFlags::FULL_QA_POWER,
                daily_fee: daily_fee.clone(),
            };

            new_sector_numbers.push(new_sector_info.sector_number);
            new_sectors.push(new_sector_info);
        }

        state.put_sectors(store, new_sectors.clone()).map_err(|e| {
            e.downcast_default(ExitCode::USR_ILLEGAL_STATE, "failed to put new sectors")
        })?;
        state.delete_precommitted_sectors(store, &new_sector_numbers)?;
        state
            .assign_sectors_to_deadlines(
                policy,
                store,
                rt.curr_epoch(),
                new_sectors,
                info.window_post_partition_sectors,
                info.sector_size,
            )
            .map_err(|e| {
                e.downcast_default(
                    ExitCode::USR_ILLEGAL_STATE,
                    "failed to assign new sectors to deadlines",
                )
            })?;
        let newly_vested = TokenAmount::zero();

        // Unlock deposit for successful proofs, make it available for lock-up as initial pledge.
        state
            .add_pre_commit_deposit(&(-deposit_to_unlock))
            .map_err(|e| actor_error!(illegal_state, "failed to add precommit deposit: {}", e))?;

        let unlocked_balance = state.get_unlocked_balance(&rt.current_balance()).map_err(|e| {
            actor_error!(illegal_state, "failed to calculate unlocked balance: {}", e)
        })?;
        if unlocked_balance < total_pledge {
            return Err(actor_error!(
                insufficient_funds,
                "insufficient funds for aggregate initial pledge requirement {}, available: {}",
                total_pledge,
                unlocked_balance
            ));
        }

        state
            .add_initial_pledge(&total_pledge)
            .map_err(|e| actor_error!(illegal_state, "failed to add initial pledge: {}", e))?;

        state.check_balance_invariants(&rt.current_balance()).map_err(balance_invariants_broken)?;

        Ok((total_pledge, newly_vested))
    })?;
    // Request pledge update for activated sectors.
    // Power is not activated until first Window poST.
    notify_pledge_changed(rt, &(total_pledge - newly_vested))?;

    Ok(())
}

/// Calculate create miner deposit by MINIMUM_CONSENSUS_POWER x StateMinerInitialPledgeCollateral / 10
/// See FIP-0077, https://github.com/filecoin-project/FIPs/blob/master/FIPS/fip-0077.md
pub fn calculate_create_miner_deposit(rt: &impl Runtime) -> Result<TokenAmount, ActorError> {
    let rew = request_current_epoch_block_reward(rt)?;
    let pwr = request_current_total_power(rt)?;

    Ok(initial_pledge_for_power(
        &BigInt::from(CREATE_MINER_DEPOSIT_POWER),
        &rew.this_epoch_baseline_power,
        &rew.this_epoch_reward_smoothed,
        &pwr.quality_adj_power_smoothed,
        &rt.total_fil_circ_supply(),
        rt.curr_epoch() - pwr.ramp_start_epoch,
        pwr.ramp_duration_epochs,
    ))
}

// Inputs to state update for a single sector replica update.
struct ReplicaUpdateStateInputs<'a> {
    sector_info: &'a SectorOnChainInfo,
    seal_cid: Cid,
    space: u64,
}

fn validate_commd(
    rt: &impl Runtime,
    activation: &SectorActivationManifest,
    precommit: &SectorPreCommitOnChainInfo,
) -> Result<(), ActorError> {
    let sector_type = precommit.info.seal_proof;
    let computed_commd =
        unsealed_cid_from_pieces(rt, &activation.pieces, sector_type)?.get_cid(sector_type)?;
    let declared_commd = &precommit.info.unsealed_cid;

    // A declared zero CommD may be compact or fully computed.
    if declared_commd.get_cid(sector_type)? != computed_commd {
        return Err(actor_error!(
            illegal_argument,
            "unsealed CID does not match pieces for sector {}, computed {:?} declared {:?}",
            precommit.info.sector_number,
            computed_commd,
            declared_commd
        ));
    }
    Ok(())
}

fn total_piece_space(
    sector_number: SectorNumber,
    pieces: &[PieceActivationManifest],
) -> Result<u64, ActorError> {
    pieces.iter().try_fold(0u64, |space, piece| {
        space.checked_add(piece.size.0).ok_or_else(|| {
            actor_error!(illegal_argument, "piece sizes overflow for sector {}", sector_number)
        })
    })
}
fn unsealed_cid_from_pieces(
    rt: &impl Runtime,
    pieces: &[PieceActivationManifest],
    sector_type: RegisteredSealProof,
) -> Result<CompactCommD, ActorError> {
    let computed_commd = if !pieces.is_empty() {
        let pieces: Vec<PieceInfo> =
            pieces.iter().map(|piece| PieceInfo { cid: piece.cid, size: piece.size }).collect();
        let computed = rt.compute_unsealed_sector_cid(sector_type, &pieces).context_code(
            ExitCode::USR_ILLEGAL_ARGUMENT,
            "failed to compute unsealed sector CID",
        )?;
        CompactCommD::of(computed)
    } else {
        CompactCommD::empty()
    };
    Ok(computed_commd)
}

// Network inputs to calculation of sector pledge and associated parameters.
struct NetworkPledgeInputs {
    pub network_qap: FilterEstimate,
    pub network_baseline: StoragePower,
    pub circulating_supply: TokenAmount,
    pub epoch_reward: FilterEstimate,
    pub epochs_since_ramp_start: i64,
    pub ramp_duration_epochs: u64,
}

impl NetworkPledgeInputs {
    fn initial_pledge_for_power(&self, qa_power: &StoragePower) -> TokenAmount {
        initial_pledge_for_power(
            qa_power,
            &self.network_baseline,
            &self.epoch_reward,
            &self.network_qap,
            &self.circulating_supply,
            self.epochs_since_ramp_start,
            self.ramp_duration_epochs,
        )
    }
}

// Note: probably better to push this one level down into state
fn balance_invariants_broken(e: Error) -> ActorError {
    ActorError::unchecked(
        ERR_BALANCE_INVARIANTS_BROKEN,
        format!("balance invariants broken: {}", e),
    )
}

impl ActorCode for Actor {
    type Methods = Method;

    fn name() -> &'static str {
        "StorageMiner"
    }

    actor_dispatch! {
        Constructor => constructor,
        ControlAddresses => control_addresses,
        ChangeWorkerAddress|ChangeWorkerAddressExported => change_worker_address,
        ChangePeerID|ChangePeerIDExported => change_peer_id,
        SubmitWindowedPoSt => submit_windowed_post,
        TerminateSectors => terminate_sectors,
        DeclareFaults => declare_faults,
        DeclareFaultsRecovered => declare_faults_recovered,
        OnDeferredCronEvent => on_deferred_cron_event,
        CheckSectorProven => check_sector_proven,
        ApplyRewards => apply_rewards,
        ReportConsensusFault => report_consensus_fault,
        WithdrawBalance|WithdrawBalanceExported => withdraw_balance,
        InternalSectorSetupForPreseal => internal_sector_setup_preseal,
        ChangeMultiaddrs|ChangeMultiaddrsExported => change_multiaddresses,
        CompactPartitions => compact_partitions,
        CompactSectorNumbers => compact_sector_numbers,
        ConfirmChangeWorkerAddress|ConfirmChangeWorkerAddressExported => confirm_change_worker_address,
        RepayDebt|RepayDebtExported => repay_debt,
        ChangeOwnerAddress|ChangeOwnerAddressExported => change_owner_address,
        DisputeWindowedPoSt => dispute_windowed_post,
        PreCommitSectorBatch2 => pre_commit_sector_batch2,
        ChangeBeneficiary|ChangeBeneficiaryExported => change_beneficiary,
        GetBeneficiary|GetBeneficiaryExported => get_beneficiary,
        ExtendSectorExpiration2 => extend_sector_expiration2,
        GetOwnerExported => get_owner,
        IsControllingAddressExported => is_controlling_address,
        GetSectorSizeExported => get_sector_size,
        GetAvailableBalanceExported => get_available_balance,
        GetVestingFundsExported => get_vesting_funds,
        GetPeerIDExported => get_peer_id,
        GetMultiaddrsExported => get_multiaddresses,
        ProveCommitSectors3 => prove_commit_sectors3,
        ProveReplicaUpdates3 => prove_replica_updates3,
        ProveCommitSectorsNI => prove_commit_sectors_ni,
        UpgradeSectorQuality => upgrade_sector_quality,
        MaxTerminationFeeExported => max_termination_fee,
        InitialPledgeExported => initial_pledge,
        GenerateSectorLocationExported => generate_sector_location,
        ValidateSectorStatusExported => validate_sector_status,
        GetNominalSectorExpirationExported => get_nominal_sector_expiration,
    }
}

#[cfg(test)]
mod internal_tests;
