use fil_actor_eam::Return;
use fil_actor_evm::Method as EvmMethods;
use fil_actors_runtime::EAM_ACTOR_ADDR;
use fil_actors_runtime::cbor;
use fvm::executor::{ApplyKind, Executor};
use fvm_integration_tests::dummy::DummyExterns;
use fvm_integration_tests::tester::Account;
use fvm_ipld_encoding::strict_bytes;
use fvm_ipld_encoding::RawBytes;
use fvm_shared::address::Address;
use fvm_shared::econ::TokenAmount;
use fvm_shared::message::Message;
use serde::de::Expected;
use serde::{Deserialize as SerdeDeserialize, Serialize as SerdeSerialize};
use alloy_primitives::{fixed_bytes, address, Address as Alloy_Address};
use alloy_sol_types::{SolCall, SolType, sol_data};

use testing::{setup, api_contracts};
use testing::GasResult;
use testing::parse_gas;

const WASM_COMPILED_PATH: &str = "../build/v0.8/tests/PrecompilesApiTest.bin";

#[derive(SerdeSerialize, SerdeDeserialize)]
#[serde(transparent)]
pub struct CreateExternalParams(#[serde(with = "strict_bytes")] pub Vec<u8>);

#[test]
fn precompiles_tests() {
    println!("Testing solidity API");

    let mut gas_result: GasResult = vec![];
    let (mut tester, _manifest) = setup::setup_tester();

    // As the governor address for datacap is 200, we create many many address in order to initialize the ID 200 with some tokens
    // and make it a valid address to use.
    let sender: [Account; 300] = tester.create_accounts().unwrap();

    println!(
        "{}",
        format!(
            "Sender address id [{}] and bytes [{}]",
            &sender[0].0,
            hex::encode(&sender[0].1.to_bytes())
        )
    );
    println!(
        "{}",
        format!(
            "Sender address id [{}] and bytes [{}]",
            &sender[1].0,
            hex::encode(&sender[1].1.to_bytes())
        )
    );
    println!(
        "{}",
        format!(
            "Sender address id [{}] and bytes [{}]",
            &sender[2].0,
            hex::encode(&sender[2].1.to_bytes())
        )
    );
    println!(
        "{}",
        format!(
            "Sender address id [{}] and bytes [{}]",
            &sender[3].0,
            hex::encode(&sender[3].1.to_bytes())
        )
    );

    // Create embryo address to deploy the contract on it (assign some FILs to it)
    let tmp = hex::decode("DAFEA492D9c6733ae3d56b7Ed1ADB60692c98Bc5").unwrap();
    let embryo_eth_address = tmp.as_slice();
    let embryo_delegated_address = Address::new_delegated(10, embryo_eth_address).unwrap();
    tester
        .create_placeholder(&embryo_delegated_address, TokenAmount::from_whole(100))
        .unwrap();

    println!(
        "Embryo address delegated type [{}]",
        embryo_delegated_address
    );
    println!(
        "Embryo address delegated type on hex [{}]",
        hex::encode(embryo_delegated_address.to_bytes())
    );
    // println!("Embryo address ID type on decimal [{}]",embryo_actor_id);
    // println!("Embryo address ID type on hex [{}]",hex::encode(Address::new_id(embryo_actor_id).to_bytes()));

    // Instantiate machine
    tester.instantiate_machine(DummyExterns).unwrap();

    let executor = tester.executor.as_mut().unwrap();

    // First we deploy the contract in order to actually have an actor running on the embryo address
    println!("Calling init actor (EVM)");

    let evm_bin = setup::load_evm(WASM_COMPILED_PATH);

    let constructor_params = CreateExternalParams(evm_bin);

    let message = Message {
        from: sender[0].1,
        to: EAM_ACTOR_ADDR,
        gas_limit: 1000000000,
        method_num: 4,
        sequence: 0,
        params: RawBytes::serialize(constructor_params).unwrap(),
        ..Message::default()
    };

    let res = executor
        .execute_message(message, ApplyKind::Explicit, 100)
        .unwrap();

    assert_eq!(res.msg_receipt.exit_code.value(), 0);

    let exec_return: Return = RawBytes::deserialize(&res.msg_receipt.return_data).unwrap();

    println!(
        "Contract address ID type on decimal [{}]",
        exec_return.actor_id
    );
    println!(
        "Contract address ID type on hex [{}]",
        hex::encode(Address::new_id(exec_return.actor_id).to_bytes())
    );
    match exec_return.robust_address {
        Some(addr) => println!("Contract address robust type [{}]", addr),
        None => (),
    }

    println!(
        "Contract address eth address type [{}]",
        hex::encode(exec_return.eth_address.0)
    );

    let contract_actor_id = exec_return.actor_id;

    println!("Calling `resolve_address`");

    let abi_encoded_call = api_contracts::precompiles_test::resolve_addressCall{
        addr: api_contracts::precompiles_test::FilAddress{
            data: sender[0].1.to_bytes()
        }
    }.abi_encode();

    let cbor_encoded = api_contracts::cbor_encode(abi_encoded_call);

    let message = Message {
            from: sender[0].1,
            to: Address::new_id(contract_actor_id),
            gas_limit: 1000000000,
            method_num: EvmMethods::InvokeContract as u64,
            sequence: 1,
            params: RawBytes::new(hex::decode(
                // "58841D5F67A4000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000015011EDA43D05CA6D7D637E7065EF6B8C5DB89E5FB0C0000000000000000000000"
                cbor_encoded.as_str()
            ).unwrap()),
            ..Message::default()
        };

    let res = executor
        .execute_message(message, ApplyKind::Explicit, 100)
        .unwrap();
    let gas_used = parse_gas(res.exec_trace);
    gas_result.push(("resolve_address".into(), gas_used));
    assert_eq!(res.msg_receipt.exit_code.value(), 0);

    let expected_address = 0x64_u64;

    let abi_encoded_call = sol_data::Uint::<64>::abi_encode(&expected_address);

    let cbor_encoded = api_contracts::cbor_encode(abi_encoded_call);
    
    assert_eq!(
        hex::encode(res.msg_receipt.return_data.bytes()),
        // "58200000000000000000000000000000000000000000000000000000000000000064"
        cbor_encoded.as_str()
    );

    println!("Calling `lookup_delegated_address (empty response)`");

    let abi_encoded_call = api_contracts::precompiles_test::lookup_delegated_addressCall{
        actor_id: 0x64_u64
    }.abi_encode();

    let cbor_encoded = api_contracts::cbor_encode(abi_encoded_call);

    let message = Message {
        from: sender[0].1,
        to: Address::new_id(contract_actor_id),
        gas_limit: 1000000000,
        method_num: EvmMethods::InvokeContract as u64,
        sequence: 2,
        params: RawBytes::new(
            hex::decode(
                // "58249898B39A0000000000000000000000000000000000000000000000000000000000000064",
                cbor_encoded.as_str()
            )
            .unwrap(),
        ),
        ..Message::default()
    };

    let res = executor
        .execute_message(message, ApplyKind::Explicit, 100)
        .unwrap();

    let gas_used = parse_gas(res.exec_trace);
    gas_result.push((
        "lookup_delegated_address (empty response)".into(),
        gas_used,
    ));
    assert_eq!(res.msg_receipt.exit_code.value(), 0);

    let expected_delegated_addr = fixed_bytes!("");

    let abi_encoded_call = sol_data::Bytes::abi_encode(&expected_delegated_addr);

    let cbor_encoded = api_contracts::cbor_encode(abi_encoded_call);

    assert_eq!(
        hex::encode(res.msg_receipt.return_data.bytes()), 
        // "584000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000"
        cbor_encoded.as_str()
    );

    println!("Calling `lookup_delegated_address (address found)`");

    let abi_encoded_call = api_contracts::precompiles_test::lookup_delegated_addressCall{
        actor_id: 0x190_u64
    }.abi_encode();

    let cbor_encoded = api_contracts::cbor_encode(abi_encoded_call);

    let message = Message {
        from: sender[0].1,
        to: Address::new_id(contract_actor_id),
        gas_limit: 1000000000,
        method_num: EvmMethods::InvokeContract as u64,
        sequence: 3,
        params: RawBytes::new(
            hex::decode(
                // "58249898B39A0000000000000000000000000000000000000000000000000000000000000190",
                cbor_encoded.as_str()
            )
            .unwrap(),
        ),
        ..Message::default()
    };

    let res = executor
        .execute_message(message, ApplyKind::Explicit, 100)
        .unwrap();
    let gas_used = parse_gas(res.exec_trace);
    gas_result.push((
        "lookup_delegated_address (address found)".into(),
        gas_used,
    ));
    assert_eq!(res.msg_receipt.exit_code.value(), 0);

    let expected_delegated_addr = embryo_delegated_address.to_bytes();

    let abi_encoded_call = sol_data::Bytes::abi_encode(&expected_delegated_addr);

    let cbor_encoded = api_contracts::cbor_encode(abi_encoded_call);

    assert_eq!(
        hex::encode(res.msg_receipt.return_data.bytes()), 
        // "586000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000016040adafea492d9c6733ae3d56b7ed1adb60692c98bc500000000000000000000"
        cbor_encoded.as_str()
    );

    println!("Calling `resolve_eth_address`");

    let embryo_del_addr_bytes = embryo_delegated_address.to_bytes();
    let embryo_del_addr_slice = embryo_del_addr_bytes.as_slice();

    let eth_addr = Alloy_Address::from_slice( &embryo_del_addr_slice[2..]);

    let abi_encoded_call = api_contracts::precompiles_test::resolve_eth_addressCall{
        addr: eth_addr
    }.abi_encode();

    let cbor_encoded = api_contracts::cbor_encode(abi_encoded_call);

    let message = Message {
            from: sender[0].1,
            to: Address::new_id(contract_actor_id),
            gas_limit: 1000000000,
            method_num: EvmMethods::InvokeContract as u64,
            sequence: 4,
            params: RawBytes::new(hex::decode(
                // "5824DCA7CA03000000000000000000000000DAFEA492D9C6733AE3D56B7ED1ADB60692C98BC5"
                cbor_encoded.as_str()
            ).unwrap()),
            ..Message::default()
        };

    let res = executor
        .execute_message(message, ApplyKind::Explicit, 100)
        .unwrap();
    let gas_used = parse_gas(res.exec_trace);
    gas_result.push(("resolve_eth_address".into(), gas_used));
    assert_eq!(res.msg_receipt.exit_code.value(), 0);

    let expected_eth_address = 0x190_u64;

    let abi_encoded_call = sol_data::Uint::<64>::abi_encode(&expected_eth_address);

    let cbor_encoded = api_contracts::cbor_encode(abi_encoded_call);

    assert_eq!(
        hex::encode(res.msg_receipt.return_data.bytes()),
        // "58200000000000000000000000000000000000000000000000000000000000000190"
        cbor_encoded.as_str()
    );

    let table = testing::create_gas_table(gas_result);
    testing::save_gas_table(&table, "precompiles");

    table.printstd();
}
