/*******************************************************************************
 *   (c) 2022 Zondax AG
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 ********************************************************************************/
//
// THIS CODE WAS SECURITY REVIEWED BY KUDELSKI SECURITY, BUT NOT FORMALLY AUDITED

// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.17;

import "../../vendor/solidity-BigNumber/src/BigNumbers.sol";

import "../types/MinerTypes.sol";
import "../types/CommonTypes.sol";

/// @title This library is a proxy to a built-in Miner actor. Calling one of its methods will result in a cross-actor call being performed. However, in this mock library, no actual call is performed.
/// @author Zondax AG
/// @dev Methods prefixed with mock_ will not be available in the real library. These methods are merely used to set mock state. Note that this interface will likely break in the future as we align it
//       with that of the real library!
contract MinerMockAPI {
    bytes owner;
    bool isBeneficiarySet = false;
    MinerTypes.ActiveBeneficiary activeBeneficiary;
    mapping(MinerTypes.SectorSize => uint64) sectorSizesBytes;

    /// @notice (Mock method) Sets the owner of a Miner on contract deployment, which will be returned via get_owner().
    constructor(bytes memory _owner) {
        owner = _owner;

        sectorSizesBytes[MinerTypes.SectorSize._2KiB] = 2 << 10;
        sectorSizesBytes[MinerTypes.SectorSize._8MiB] = 8 << 20;
        sectorSizesBytes[MinerTypes.SectorSize._512MiB] = 512 << 20;
        sectorSizesBytes[MinerTypes.SectorSize._32GiB] = 32 << 30;
        sectorSizesBytes[MinerTypes.SectorSize._64GiB] = 2 * (32 << 30);
    }

    /// @notice (Mock method) Sets the owner of a Miner, which will be returned via get_owner().
    function mockSetOwner(bytes memory addr) public {
        require(owner.length == 0);
        owner = addr;
    }

    /// @notice Income and returned collateral are paid to this address
    /// @notice This address is also allowed to change the worker address for the miner
    /// @return the owner address of a Miner
    function getOwner() public view returns (MinerTypes.GetOwnerReturn memory) {
        require(owner.length != 0);

        bytes memory proposed = "0x00";

        return MinerTypes.GetOwnerReturn(CommonTypes.FilAddress(owner), CommonTypes.FilAddress(proposed));
    }

    /// @param addr New owner address
    /// @notice Proposes or confirms a change of owner address.
    /// @notice If invoked by the current owner, proposes a new owner address for confirmation. If the proposed address is the current owner address, revokes any existing proposal that proposed address.
    function changeOwnerAddress(bytes memory addr) public {
        owner = addr;
    }

    /// @param addr The "controlling" addresses are the Owner, the Worker, and all Control Addresses.
    /// @return Whether the provided address is "controlling".
    function isControllingAddress(CommonTypes.FilAddress memory addr) public pure returns (bool) {
        require(addr.data[0] >= 0x00);

        return false;
    }

    /// @return the miner's sector size.
    function getSectorSize() public view returns (uint64) {
        return sectorSizesBytes[MinerTypes.SectorSize._8MiB];
    }

    /// @notice This is calculated as actor balance - (vesting funds + pre-commit deposit + initial pledge requirement + fee debt)
    /// @notice Can go negative if the miner is in IP debt.
    /// @return the available balance of this miner.
    function getAvailableBalance() public pure returns (CommonTypes.BigInt memory) {
        return CommonTypes.BigInt(hex"021E19E0C9BAB2400000", false);
    }

    /// @return the funds vesting in this miner as a list of (vesting_epoch, vesting_amount) tuples.
    function getVestingFunds() public pure returns (MinerTypes.VestingFunds[] memory) {
        MinerTypes.VestingFunds[] memory vesting_funds = new MinerTypes.VestingFunds[](1);
        vesting_funds[0] = MinerTypes.VestingFunds(CommonTypes.ChainEpoch.wrap(1668514825), CommonTypes.BigInt(hex"6C6B935B8BBD400000", false));

        return vesting_funds;
    }

    /// @notice Proposes or confirms a change of beneficiary address.
    /// @notice A proposal must be submitted by the owner, and takes effect after approval of both the proposed beneficiary and current beneficiary, if applicable, any current beneficiary that has time and quota remaining.
    /// @notice See FIP-0029, https://github.com/filecoin-project/FIPs/blob/master/FIPS/fip-0029.md
    function changeBeneficiary(MinerTypes.ChangeBeneficiaryParams memory params) public {
        if (!isBeneficiarySet) {
            BigNumber memory zero = BigNumbers.zero();
            MinerTypes.BeneficiaryTerm memory term = MinerTypes.BeneficiaryTerm(
                params.new_quota,
                CommonTypes.BigInt(zero.val, zero.neg),
                params.new_expiration
            );
            activeBeneficiary = MinerTypes.ActiveBeneficiary(params.new_beneficiary, term);
            isBeneficiarySet = true;
        } else {
            activeBeneficiary.beneficiary = params.new_beneficiary;
            activeBeneficiary.term.quota = params.new_quota;
            activeBeneficiary.term.expiration = params.new_expiration;
        }
    }

    /// @notice This method is for use by other actors (such as those acting as beneficiaries), and to abstract the state representation for clients.
    /// @notice Retrieves the currently active and proposed beneficiary information.
    function getBeneficiary() public view returns (MinerTypes.GetBeneficiaryReturn memory) {
        require(isBeneficiarySet);

        MinerTypes.PendingBeneficiaryChange memory proposed;
        return MinerTypes.GetBeneficiaryReturn(activeBeneficiary, proposed);
    }
}
