/*******************************************************************************
 *   (c) 2022 Zondax AG
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 ********************************************************************************/
//
// THIS CODE WAS SECURITY REVIEWED BY KUDELSKI SECURITY, BUT NOT FORMALLY AUDITED

// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.17;

import "../SendAPI.sol";
import "../utils/Errors.sol";

/// @notice This file is meant to serve as a deployable contract of the send utilities, as the library by itself is not.
/// @notice It imports the library and create a callable method for each method in the library
/// @author Zondax AG
contract SendApiTest {
    function send(CommonTypes.FilActorId target, uint256 amount) public returns (int256) {
        int256 exit_code = SendAPI.send(target, amount);

        Errors.revertOnError(exit_code);

        return exit_code;
    }

    function send(CommonTypes.FilAddress memory target, uint256 amount) public returns (int256) {
        int256 exit_code = SendAPI.send(target, amount);

        Errors.revertOnError(exit_code);

        return exit_code;
    }

    function send_with_actor_id(CommonTypes.FilActorId target, uint256 amount) public returns (int256) {
        return send(target, amount);
    }

    function send_with_address(CommonTypes.FilAddress memory target, uint256 amount) public returns (int256) {
        return send(target, amount);
    }

    receive() external payable {}
    fallback() external payable {}
}
