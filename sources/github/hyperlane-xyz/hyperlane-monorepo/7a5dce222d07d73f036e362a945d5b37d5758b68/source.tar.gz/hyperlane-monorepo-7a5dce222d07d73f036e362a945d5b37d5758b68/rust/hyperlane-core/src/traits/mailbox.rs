use std::fmt::Debug;
use std::num::NonZeroU64;

use async_trait::async_trait;
use auto_impl::auto_impl;

use crate::{
    accumulator::incremental::IncrementalMerkle, traits::TxOutcome, utils::domain_hash,
    ChainResult, Checkpoint, HyperlaneContract, HyperlaneMessage, TxCostEstimate, H256, U256,
};

/// Interface for the Mailbox chain contract. Allows abstraction over different
/// chains
#[async_trait]
#[auto_impl(&, Box, Arc)]
pub trait Mailbox: HyperlaneContract + Send + Sync + Debug {
    /// Return the domain hash
    fn domain_hash(&self) -> H256 {
        domain_hash(self.address(), self.domain().id())
    }

    /// Return the incremental merkle tree in storage
    ///
    /// - `lag` is how far behind the current block to query, if not specified
    ///   it will query at the latest block.
    async fn tree(&self, lag: Option<NonZeroU64>) -> ChainResult<IncrementalMerkle>;

    /// Gets the current leaf count of the merkle tree
    ///
    /// - `lag` is how far behind the current block to query, if not specified
    ///   it will query at the latest block.
    async fn count(&self, lag: Option<NonZeroU64>) -> ChainResult<u32>;

    /// Fetch the status of a message
    async fn delivered(&self, id: H256) -> ChainResult<bool>;

    /// Get the latest checkpoint.
    ///
    /// - `lag` is how far behind the current block to query, if not specified
    ///   it will query at the latest block.
    async fn latest_checkpoint(&self, lag: Option<NonZeroU64>) -> ChainResult<Checkpoint>;

    /// Fetch the current default interchain security module value
    async fn default_ism(&self) -> ChainResult<H256>;

    /// Get the latest checkpoint.
    async fn recipient_ism(&self, recipient: H256) -> ChainResult<H256>;

    /// Process a message with a proof against the provided signed checkpoint
    async fn process(
        &self,
        message: &HyperlaneMessage,
        metadata: &[u8],
        tx_gas_limit: Option<U256>,
    ) -> ChainResult<TxOutcome>;

    /// Estimate transaction costs to process a message.
    async fn process_estimate_costs(
        &self,
        message: &HyperlaneMessage,
        metadata: &[u8],
    ) -> ChainResult<TxCostEstimate>;

    /// Get the calldata for a transaction to process a message with a proof
    /// against the provided signed checkpoint
    fn process_calldata(&self, message: &HyperlaneMessage, metadata: &[u8]) -> Vec<u8>;
}
