try {
  require('dotenv').config({ path: './config.env' });
} catch (e) {}

module.exports = {
  ETHEREUM_RPC: process.env.ETHEREUM_RPC,
  XDAI_RPC: process.env.XDAI_RPC,
  CRONOS_RPC: process.env.CRONOS_RPC,
  FANTOM_RPC: process.env.FANTOM_RPC,
  OPTIMISM_RPC: process.env.OPTIMISM_RPC,
  AVAX_RPC: process.env.AVAX_RPC,
  ARBITRUM_RPC: process.env.ARBITRUM_RPC,
  BASE_RPC: process.env.BASE_RPC,
  BSC_RPC: process.env.BSC_RPC,
  TRON_RPC: process.env.TRON_RPC,
  TVL_SPIKE_WEBHOOK: process.env.TVL_SPIKE_WEBHOOK,
  NEW_YIELDS_WEBHOOK: process.env.NEW_YIELDS_WEBHOOK,
  STALE_PROJECTS_WEBHOOK: process.env.STALE_PROJECTS_WEBHOOK,
  ZEROX_API: process.env.ZEROX_API,
  SMARDEX_SUBGRAPH_API_KEY: process.env.SMARDEX_SUBGRAPH_API_KEY,
  VENDOR_FINANCE: process.env.VENDOR_FINANCE,
  TRADERJOE: process.env.TRADERJOE,
  GRAPH_API_KEY: process.env.GRAPH_API_KEY,
  LLAMA_INDEXER_V2_ENDPOINT: process.env.LLAMA_INDEXER_V2_ENDPOINT,
  LLAMA_INDEXER_V2_API_KEY: process.env.LLAMA_INDEXER_V2_API_KEY,
  // Cloudflare R2
  R2_ENDPOINT: process.env.R2_ENDPOINT,
  R2_ACCESS_KEY_ID: process.env.R2_ACCESS_KEY_ID,
  R2_SECRET_ACCESS_KEY: process.env.R2_SECRET_ACCESS_KEY,
  // DB
  DATABASE_URL: process.env.DATABASE_URL,
  OSMOSIS_API_KEY: process.env.OSMOSIS_API_KEY,
  SAUCERSWAP_API_KEY: process.env.SAUCERSWAP_API_KEY,
  DUNE_API_KEY: process.env.DUNE_API_KEY,
  HYPERLIQUID_RPC: process.env.HYPERLIQUID_RPC,
  PLASMA_RPC: process.env.PLASMA_RPC,
  STARKNET_RPC: process.env.STARKNET_RPC,
  MONAD_RPC: process.env.MONAD_RPC,
};
