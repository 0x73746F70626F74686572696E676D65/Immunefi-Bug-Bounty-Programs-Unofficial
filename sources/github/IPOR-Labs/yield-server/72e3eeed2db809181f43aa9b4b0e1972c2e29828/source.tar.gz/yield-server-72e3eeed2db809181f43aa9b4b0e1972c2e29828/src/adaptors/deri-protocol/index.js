const utils = require('../utils');
const abi = require('./abi.js');
const sdk = require('@defillama/sdk');

const pools = [
  {
    pool: "0x243681B8Cd79E3823fF574e07B2378B8Ab292c1E",
    project: "deri-protocol",
    chain: "bsc",
    chainId: "56",
    btoken: "BUSD",
    underlyingToken: "0xe9e7cea3dedca5984780bafc599bd69add087d56",
  },
  {
    pool: "0xDE3447Eb47EcDf9B5F90E7A6960a14663916CeE8",
    project: "deri-protocol",
    chain: "arbitrum",
    chainId: "42161",
    btoken: "USDC",
    underlyingToken: "0xaf88d065e77c8cc2239327c5edb3a432268e5831",
  }
]
const poolsFunction = async () => {
  let apyData = pools.map(async (item) => {
    let url = `https://api.deri.io/pool_mining_info/${item.chainId}/${item.pool}`
    let res = await utils.getData(url)
    let data = []
    let obj = res.data.bTokens.map((token) => {
      if (token.bTokenSymbol === item.btoken) {
        let apy = Number(token.apy) + Number(token.supplyApy) + Number(token.xvsApy)
        data.push({
          pool: item.pool,
          chain: item.chain,
          project: item.project,
          apyReward: apy * 100,
          symbol: token.bTokenSymbol,
          underlyingToken: item.underlyingToken,
        })
      }
    })
    return data
  })
  apyData = await Promise.all(apyData)

  let Pool = []
  for (let index = 0; index < apyData.length; index++) {
    let obj = apyData[index].map(async (apyItem) => {
      let tvl = await sdk.api.abi.call({
        target: apyItem.pool,
        abi: abi.find((m) => m.name === 'liquidity'),
        chain: apyItem.chain
      })
      let pool = `${apyItem.pool}-${apyItem.chain}`
      let poolObj = {
        "pool": pool.toLowerCase(),
        "chain": utils.formatChain(apyItem.chain),
        "project": apyItem.project,
        "tvlUsd": Number(tvl.output) / 10 ** 18,
        "symbol": apyItem.symbol,
        "apyReward": apyItem.apyReward,
        "rewardTokens":["0xa487bf43cf3b10dffc97a9a744cbb7036965d3b9"],
        "underlyingTokens": [apyItem.underlyingToken],
      }
      return poolObj
    })
    let tvl = await Promise.all(obj)
    Pool.push(tvl[0])
  }
  return Pool
}
module.exports = {
  protocolId: '423',
  timetravel: false,
  apy: poolsFunction,
  url: 'https://deri.io',
};