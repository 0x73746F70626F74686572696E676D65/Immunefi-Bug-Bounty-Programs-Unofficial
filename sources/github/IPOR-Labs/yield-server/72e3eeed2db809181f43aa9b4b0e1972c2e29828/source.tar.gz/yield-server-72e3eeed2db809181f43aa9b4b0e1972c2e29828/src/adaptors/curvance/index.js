const sdk = require('@defillama/sdk');
const axios = require('axios');

const utils = require('../utils');
const { addMerklRewardApy } = require('../merkl/merkl-additional-reward');
const { getDynamicMarketDataAbi, getStaticMarketDataAbi } = require('./abi');

const SECONDS_PER_YEAR = 365 * 24 * 3600; // 31_536_000

// Rates are per-second in WAD (1e18 = 100% per second)
const calcApy = (ratePerSecond) => {
  const rate = Number(ratePerSecond) / 1e18;
  if (!rate || !Number.isFinite(rate) || rate <= 0) {
    return 0;
  }
  return rate * SECONDS_PER_YEAR * 100;
};

const getPrices = async (addresses) => {
  if (!addresses.length) {
    return {};
  }

  const chunkSize = 50;
  const prices = {};
  for (let i = 0; i < addresses.length; i += chunkSize) {
    const chunk = addresses.slice(i, i + chunkSize);
    try {
      const { data } = await axios.get(
        utils.getPriceApiUrl(`/prices/current/${chunk.join(',')}`),
        { timeout: 10_000 }
      );
      for (const [key, val] of Object.entries(data.coins || {})) {
        prices[key.split(':')[1].toLowerCase()] = val.price;
      }
    } catch (e) {
      console.error(`Failed to fetch prices for chunk: ${e.message}`);
    }
  }
  return prices;
};

const config = {
  monad: {
    centralRegistry: '0x1310f352f1389969Ece6741671c4B919523912fF',
    protocolReader: '0x878cDfc2F3D96a49A5CbD805FAF4F3080768a6d2',
  },
};

const getMerklMarketAddress = (pool) => pool.market;

const getPoolsForChain = async (chain, { centralRegistry, protocolReader }) => {
  const managersRes = await sdk.api.abi.call({
    target: centralRegistry,
    chain,
    abi: 'address[]:marketManagers',
    permitFailure: true,
  });
  const managers = managersRes.output;
  if (!managers || !managers.length) {
    return [];
  }

  const marketsRes = await sdk.api.abi.multiCall({
    chain,
    abi: 'address[]:queryTokensListed',
    calls: managers.map((addr) => ({ target: addr })),
    permitFailure: true,
  });

  // Preserve manager -> market mapping for poolMeta
  const marketToManager = {};
  const markets = [];
  for (let i = 0; i < managers.length; i++) {
    const list = marketsRes.output[i].output || [];
    for (const addr of list) {
      markets.push(addr);
      marketToManager[addr.toLowerCase()] = managers[i].toLowerCase();
    }
  }

  if (!markets.length) {
    return [];
  }

  const underlyingRes = await sdk.api.abi.multiCall({
    chain,
    abi: 'address:asset',
    calls: markets.map((addr) => ({ target: addr })),
    permitFailure: true,
  });
  const underlyings = underlyingRes.output.map((res) =>
    res.success ? res.output : null
  );
  const validUnderlyingIndexes = underlyings
    .map((addr, i) => (addr ? i : -1))
    .filter((i) => i !== -1);

  // Fetch dynamic + static market data + token metadata
  const [dynamicDataRes, staticDataRes, symbolRes, decimalsRes] = await Promise.all([
    sdk.api.abi.call({
      target: protocolReader,
      chain,
      abi: getDynamicMarketDataAbi,
      permitFailure: true,
    }),
    sdk.api.abi.call({
      target: protocolReader,
      chain,
      abi: getStaticMarketDataAbi,
      permitFailure: true,
    }),
    sdk.api.abi.multiCall({
      chain,
      abi: 'string:symbol',
      calls: validUnderlyingIndexes.map((i) => ({
        target: underlyings[i],
      })),
      permitFailure: true,
    }),
    sdk.api.abi.multiCall({
      chain,
      abi: 'uint8:decimals',
      calls: validUnderlyingIndexes.map((i) => ({
        target: underlyings[i],
      })),
      permitFailure: true,
    }),
  ]);

  // Index dynamic data by market token address for O(1) lookup
  const dynamicData = dynamicDataRes.output || [];
  const dynamicByMarket = {};
  for (const manager of dynamicData) {
    for (const token of (manager.tokens || [])) {
      dynamicByMarket[token._address.toLowerCase()] = token;
    }
  }

  // Index static data by market token address for O(1) lookup
  const staticData = staticDataRes.output || [];
  const staticByMarket = {};
  for (const manager of staticData) {
    for (const token of (manager.tokens || [])) {
      staticByMarket[token._address.toLowerCase()] = token;
    }
  }

  const symbols = Array(markets.length).fill(null);
  const allDecimals = Array(markets.length).fill(null);
  validUnderlyingIndexes.forEach((marketIdx, j) => {
    const symbol = symbolRes.output[j];
    const decimals = decimalsRes.output[j];
    symbols[marketIdx] = symbol?.success ? symbol.output : null;
    allDecimals[marketIdx] = decimals?.success ? decimals.output : null;
  });

  // Build manager -> symbols map for poolMeta disambiguation
  const managerSymbols = {};
  markets.forEach((market, i) => {
    const manager = marketToManager[market.toLowerCase()];
    if (!manager || !symbols[i]) {
      return;
    }
    if (!managerSymbols[manager]) {
      managerSymbols[manager] = [];
    }
    managerSymbols[manager].push(symbols[i]);
  });

  const uniqueUnderlyings = [
    ...new Set(underlyings.filter(Boolean).map((a) => a.toLowerCase())),
  ];
  const prices = await getPrices(
    uniqueUnderlyings.map((a) => `${chain}:${a}`)
  );

  const marketRecords = markets
    .map((market, i) => {
      const marketData = dynamicByMarket[market.toLowerCase()];

      const underlying = underlyings[i];
      const symbol = symbols[i];
      const decimals = Number(allDecimals[i]) || 18;
      const price = underlying ? prices[underlying.toLowerCase()] ?? 0 : 0;

      if (!symbol || !underlying || !price) {
        return null;
      }

      const factor = 10 ** decimals;
      const cash = marketData ? Number(marketData.liquidity) : 0;
      const debt = marketData ? Number(marketData.debt) : 0;

      const totalSupplyUsd = ((cash + debt) / factor) * price;
      const totalBorrowUsd = (debt / factor) * price;
      const tvlUsd = (cash / factor) * price;
      const apyBase = calcApy(marketData ? marketData.supplyRate : '0');

      const manager = marketToManager[market.toLowerCase()];
      const poolMeta = managerSymbols[manager].join('/');

      const staticToken = staticByMarket[market.toLowerCase()];
    // skip frozen
      if (staticToken?.mintPaused) {
        return null;
      }
      const isBorrowable =
        Boolean(staticToken?.isBorrowable) &&
        Boolean(staticToken?.isListed) &&
        !staticToken?.borrowPaused &&
        Number(staticToken?.debtCap || 0) > 0;
      const debtCap = Number(staticToken?.debtCap || 0);
      const availableBorrow = isBorrowable ? Math.min(cash, Math.max(debtCap - debt, 0)) : 0;
      const availableBorrowUsd = (availableBorrow / factor) * price;
      const apyBaseBorrow = isBorrowable ? calcApy(marketData ? marketData.borrowRate : '0') : null;
      const collateralLtv = staticToken ? Number(staticToken.collRatio) / 10000 : 0;
      const collateralEnabled =
        Boolean(staticToken?.isListed) &&
        !staticToken?.collateralizationPaused &&
        collateralLtv > 0 &&
        Number(staticToken?.collateralCap || 0) > 0;

      return {
        market: market.toLowerCase(),
        manager,
        pool: `${market.toLowerCase()}-${chain}`,
        chain: utils.formatChain(chain),
        project: 'curvance',
        symbol: symbol,
        apyBase,
        poolMeta,
        tvlUsd,
        totalSupplyUsd,
        totalBorrowUsd,
        availableBorrowUsd,
        ...(Number(staticToken?.collateralCap || 0) > 0 &&
          { supplyCapUsd: (Number(staticToken.collateralCap) / factor) * price }),
        apyBaseBorrow,
        isBorrowable,
        collateralEnabled,
        collateralLtv,
        borrowToken: underlying,
        underlyingTokens: [underlying],
      };
    })
    .filter(Boolean);

  const poolsByManager = marketRecords.reduce((acc, pool) => {
    if (!acc[pool.manager]) {
      acc[pool.manager] = [];
    }
    acc[pool.manager].push(pool);
    return acc;
  }, {});

  return Object.values(poolsByManager).flatMap((managerPools) => {
    return managerPools.map((collateralPool) => {
      const siblingPools = managerPools.filter(
        (pool) => pool.market !== collateralPool.market
      );
      const debtPool = siblingPools.length === 1 ? siblingPools[0] : null;
      const canBorrow =
        collateralPool.collateralEnabled && debtPool?.isBorrowable;

      return {
        market: collateralPool.market,
        debtMarket: canBorrow ? debtPool.market : null,
        pool: collateralPool.pool,
        chain: collateralPool.chain,
        project: collateralPool.project,
        symbol: collateralPool.symbol,
        tvlUsd: collateralPool.tvlUsd,
        totalSupplyUsd: collateralPool.totalSupplyUsd,
        ...(collateralPool.supplyCapUsd !== undefined
          ? { supplyCapUsd: collateralPool.supplyCapUsd }
          : {}),
        apyBase: collateralPool.apyBase,
        poolMeta: collateralPool.poolMeta,
        underlyingTokens: collateralPool.underlyingTokens,
        ...(canBorrow
          ? {
              borrowToken: debtPool.borrowToken,
              apyBaseBorrow: debtPool.apyBaseBorrow,
              totalBorrowUsd: debtPool.totalBorrowUsd,
              availableBorrowUsd: debtPool.availableBorrowUsd,
              borrowable: true,
              ltv: collateralPool.collateralLtv,
              url: 'https://app.curvance.com',
            }
          : {}),
      };
    });
  });
};

const main = async () => {
  const results = await Promise.all(
    Object.entries(config).map(([chain, addresses]) =>
      getPoolsForChain(chain, addresses)
    )
  );
  const poolsWithRewards = await addMerklRewardApy(
    results.flat(),
    'curvance',
    getMerklMarketAddress
  );
  const rewardsByMarket = Object.fromEntries(
    poolsWithRewards.map((pool) => [
      pool.market,
      {
        apyRewardBorrow: pool.apyRewardBorrow,
        rewardTokens: pool.rewardTokens || [],
      },
    ])
  );

  return poolsWithRewards.map((pool) => {
    const debtRewards = pool.debtMarket
      ? rewardsByMarket[pool.debtMarket]
      : null;
    const rewardTokens = [
      ...new Set([
        ...(pool.apyReward > 0 ? pool.rewardTokens || [] : []),
        ...(debtRewards?.apyRewardBorrow > 0
          ? debtRewards.rewardTokens || []
          : []),
      ]),
    ];
    const {
      market,
      debtMarket,
      apyReward,
      apyRewardBorrow,
      rewardTokens: _rewardTokens,
      ...cleanPool
    } = pool;

    return {
      ...cleanPool,
      ...(apyReward > 0 ? { apyReward } : {}),
      ...(debtRewards?.apyRewardBorrow > 0
        ? { apyRewardBorrow: debtRewards.apyRewardBorrow }
        : {}),
      ...(rewardTokens.length ? { rewardTokens } : {}),
    };
  });
};

module.exports = {
  protocolId: '7053',
  timetravel: false,
  apy: main,
  url: 'https://app.curvance.com',
};
