# ABIs and addresses

In this repository you can find all ABIs of deployed smart contracts and all addresses used in IPOR Protocol and other modules built in IPOR Labs Organization.



## Fuses List

*Last updated: 2026-09-28 18:54:00 UTC*

### Ethereum Fuses

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `AaveV3CollateralFuse` | `0xc06F56B865F45D4A80707e7d1403767177c44B22` [View](https://etherscan.io/address/0xc06F56B865F45D4A80707e7d1403767177c44B22#code) |
| `AaveV3CollateralFuseLido` | `0x8A898B69E553D452f5653E457725797282017f27` [View](https://etherscan.io/address/0x8A898B69E553D452f5653E457725797282017f27#code) |
| `AaveV3LidoWithPriceOracleMiddlewareBalanceFuse` | `0xc9eeEE3Ae20e9c5dB213a57eF102E4063FA12612` [View](https://etherscan.io/address/0xc9eeEE3Ae20e9c5dB213a57eF102E4063FA12612#code) |
| `AaveV3WithPriceOracleMiddlewareBalanceFuse` | `0xB12D9640A809543615F221f3609eA34BB1F10b25` [View](https://etherscan.io/address/0xB12D9640A809543615F221f3609eA34BB1F10b25#code) |
| `AaveV3WithPriceOracleMiddlewareBalanceLidoFuse` | `0x366aDb1F9a0743830d2C3Dc3fF0905A28Ca6F789` [View](https://etherscan.io/address/0x366aDb1F9a0743830d2C3Dc3fF0905A28Ca6F789#code) |
| `AguaBalanceFuse` | `0x8Ad87aE66c47932D64066214eE6a84BBB9009cCF` [View](https://etherscan.io/address/0x8Ad87aE66c47932D64066214eE6a84BBB9009cCF#code) |
| `AguaClaimRedemptionFuse` | `0xaAf109fcc6154014B586069743416c17b21af886` [View](https://etherscan.io/address/0xaAf109fcc6154014B586069743416c17b21af886#code) |
| `AguaRedeemEarlyFuse` | `0xb94C1CE771330e962341e60dc06544649F92440e` [View](https://etherscan.io/address/0xb94C1CE771330e962341e60dc06544649F92440e#code) |
| `AguaRequestRedemptionFuse` | `0xd275CA4D9b2f4dAE6e499421828Ee175c5859262` [View](https://etherscan.io/address/0xd275CA4D9b2f4dAE6e499421828Ee175c5859262#code) |
| `AguaSupplyFuse` | `0x12C7FC434aEF4A2360b2Bc1d08CfddeB391A9Ad9` [View](https://etherscan.io/address/0x12C7FC434aEF4A2360b2Bc1d08CfddeB391A9Ad9#code) |
| `AsyncActionBalanceFuse` | `0x37fb994757856Ec994203D01b54Adb7ae092Bf6f` [View](https://etherscan.io/address/0x37fb994757856Ec994203D01b54Adb7ae092Bf6f#code) |
| `AsyncActionFuse` | `0x04Bd1E6CaF008Ed831f888ced406cd616C671870` [View](https://etherscan.io/address/0x04Bd1E6CaF008Ed831f888ced406cd616C671870#code) |
| `BalanceFuseAaveV3` | `0x05bCb16a50DaFE0526FB7b3941B81B1B74a7877e` [View](https://etherscan.io/address/0x05bCb16a50DaFE0526FB7b3941B81B1B74a7877e#code) |
| `BalanceFuseAaveV3Lido` | `0x6755249F348611a65FbABc6413FbD19eF3799B57` [View](https://etherscan.io/address/0x6755249F348611a65FbABc6413FbD19eF3799B57#code) |
| `BalanceFuseAaveV4` | `0x018cc4747f53D394E9FB397d812fC74125d8f584` [View](https://etherscan.io/address/0x018cc4747f53D394E9FB397d812fC74125d8f584#code) |
| `BalanceFuseBurnRequestFee` | `0xbc2907d76964510a4232878e7aC6E2B18c474EFb` [View](https://etherscan.io/address/0xbc2907d76964510a4232878e7aC6E2B18c474EFb#code) |
| `BalanceFuseCompoundV3Usdc` | `0x7070d0A706Bf79A1e6d12706b9a429b9D8099C8b` [View](https://etherscan.io/address/0x7070d0A706Bf79A1e6d12706b9a429b9D8099C8b#code) |
| `BalanceFuseCompoundV3Usdt` | `0x9eF773720BbF05353b1D5e800E529315325A4481` [View](https://etherscan.io/address/0x9eF773720BbF05353b1D5e800E529315325A4481#code) |
| `BalanceFuseCompoundV3WithPriceOracleMiddlewareUsdc` | `0xEdDB6d8CfA366eEFeB587FE493035d0837563914` [View](https://etherscan.io/address/0xEdDB6d8CfA366eEFeB587FE493035d0837563914#code) |
| `BalanceFuseErc20` | `0x6cEBf3e3392D0860Ed174402884b941DCBB30654` [View](https://etherscan.io/address/0x6cEBf3e3392D0860Ed174402884b941DCBB30654#code) |
| `BalanceFuseErc4626Market1` | `0x2C10C36028C430f445a4bA9f7Dd096a5DcC75d5e` [View](https://etherscan.io/address/0x2C10C36028C430f445a4bA9f7Dd096a5DcC75d5e#code) |
| `BalanceFuseErc4626Market10` | `0x19E332aBA9cd9387e9310C9645B0a4B03a6e7906` [View](https://etherscan.io/address/0x19E332aBA9cd9387e9310C9645B0a4B03a6e7906#code) |
| `BalanceFuseErc4626Market11` | `0xf3D20CA7e35687b159C2EA4C3876C89aFa27BF11` [View](https://etherscan.io/address/0xf3D20CA7e35687b159C2EA4C3876C89aFa27BF11#code) |
| `BalanceFuseErc4626Market12` | `0x2E3266358674C8A54EaD81610C3C41033279E7Dd` [View](https://etherscan.io/address/0x2E3266358674C8A54EaD81610C3C41033279E7Dd#code) |
| `BalanceFuseErc4626Market13` | `0xa72f8391D7c9F1991769b76858b8Ac54cCEE92CF` [View](https://etherscan.io/address/0xa72f8391D7c9F1991769b76858b8Ac54cCEE92CF#code) |
| `BalanceFuseErc4626Market14` | `0x1469e4f7C78805C48b550fC4F49e4e2995512ee8` [View](https://etherscan.io/address/0x1469e4f7C78805C48b550fC4F49e4e2995512ee8#code) |
| `BalanceFuseErc4626Market15` | `0x5D4474A85b445671BD0d33Da944036D9522b9A9a` [View](https://etherscan.io/address/0x5D4474A85b445671BD0d33Da944036D9522b9A9a#code) |
| `BalanceFuseErc4626Market2` | `0x933bfF1078fF1a0ca3b53dad00d7B1850aF8749b` [View](https://etherscan.io/address/0x933bfF1078fF1a0ca3b53dad00d7B1850aF8749b#code) |
| `BalanceFuseErc4626Market3` | `0x318DC5D24bcC71bA0127A45e009B64BdBA0C2EdF` [View](https://etherscan.io/address/0x318DC5D24bcC71bA0127A45e009B64BdBA0C2EdF#code) |
| `BalanceFuseErc4626Market4` | `0xF9a1F7147D04d569AF9f9E1b6b713935cA1308fe` [View](https://etherscan.io/address/0xF9a1F7147D04d569AF9f9E1b6b713935cA1308fe#code) |
| `BalanceFuseErc4626Market5` | `0x560c836581476a95B5adf65b1986fBa3cF7772f0` [View](https://etherscan.io/address/0x560c836581476a95B5adf65b1986fBa3cF7772f0#code) |
| `BalanceFuseErc4626Market6` | `0x8c8f2A5250d440BDf6aC21B097BE04B07CCe78aF` [View](https://etherscan.io/address/0x8c8f2A5250d440BDf6aC21B097BE04B07CCe78aF#code) |
| `BalanceFuseErc4626Market7` | `0x32971e61678B0A77A07425F617F83C6D5aeCf8e7` [View](https://etherscan.io/address/0x32971e61678B0A77A07425F617F83C6D5aeCf8e7#code) |
| `BalanceFuseErc4626Market8` | `0x10e2c21205c180654b8eEa5B75c3A51014CDb336` [View](https://etherscan.io/address/0x10e2c21205c180654b8eEa5B75c3A51014CDb336#code) |
| `BalanceFuseErc4626Market9` | `0x806B55F731b0Bf5d32D9d14785743589ea23fb94` [View](https://etherscan.io/address/0x806B55F731b0Bf5d32D9d14785743589ea23fb94#code) |
| `BalanceFuseEulerV2` | `0xAE9a37DD9229687662834e6696e396e7837BAABD` [View](https://etherscan.io/address/0xAE9a37DD9229687662834e6696e396e7837BAABD#code) |
| `BalanceFuseFlashLoanMorpho` | `0xB1B74e885349cd9D1F0efFb2E1ce0fB79959D7cf` [View](https://etherscan.io/address/0xB1B74e885349cd9D1F0efFb2E1ce0fB79959D7cf#code) |
| `BalanceFuseFluidInstadappPoolFToken` | `0xA0777a5b44D36eE425DC0Ca828549f06E40E0cEE` [View](https://etherscan.io/address/0xA0777a5b44D36eE425DC0Ca828549f06E40E0cEE#code) |
| `BalanceFuseFluidInstadappStakingRewardsFToken` | `0xE9d0e294A0524962c43eEDFA935F1E8112A16AbA` [View](https://etherscan.io/address/0xE9d0e294A0524962c43eEDFA935F1E8112A16AbA#code) |
| `BalanceFuseGearboxV3DToken` | `0xE1FD88a76e95dd735c6dda45b2ABA9E5fFA9a7F3` [View](https://etherscan.io/address/0xE1FD88a76e95dd735c6dda45b2ABA9E5fFA9a7F3#code) |
| `BalanceFuseGearboxV3FarmDToken` | `0xE88982097ECdF1dcFC4D500e3392Ee0eb70B45f2` [View](https://etherscan.io/address/0xE88982097ECdF1dcFC4D500e3392Ee0eb70B45f2#code) |
| `BalanceFuseHarvestDoHardWork` | `0x759ddf11E56d2915fE10Ea8C4Dbfc44A8D048E6E` [View](https://etherscan.io/address/0x759ddf11E56d2915fE10Ea8C4Dbfc44A8D048E6E#code) |
| `BalanceFuseLiquity` | `0xF713395A26400c2ECd4af9fAF0f6AD7c569DAa97` [View](https://etherscan.io/address/0xF713395A26400c2ECd4af9fAF0f6AD7c569DAa97#code) |
| `BalanceFuseMetaMorphoMarket0001` | `0xCb6BB5ab51cDc6EFB3B81C84f252Cfe6bFbA6566` [View](https://etherscan.io/address/0xCb6BB5ab51cDc6EFB3B81C84f252Cfe6bFbA6566#code) |
| `BalanceFuseMorpho` | `0x0aD1776B9319a03216A44AbA0242cC0Bc7e3CaC3` [View](https://etherscan.io/address/0x0aD1776B9319a03216A44AbA0242cC0Bc7e3CaC3#code) |
| `BalanceFuseMorphoLiquidityInMarkets` | `0x9fb58405D628c702eF23fb1bD9cBB814A4850228` [View](https://etherscan.io/address/0x9fb58405D628c702eF23fb1bD9cBB814A4850228#code) |
| `BalanceFuseOdosSwapper` | `0x3aaE99DfdF99Bf86C400b618F470f1D2de94Ee51` [View](https://etherscan.io/address/0x3aaE99DfdF99Bf86C400b618F470f1D2de94Ee51#code) |
| `BalanceFusePendle` | `0x48bD852d83f6e58Af59255aBc708e3ddeCB1d1E6` [View](https://etherscan.io/address/0x48bD852d83f6e58Af59255aBc708e3ddeCB1d1E6#code) |
| `BalanceFuseSpark` | `0xb3ca07c9c10374D51046F94e5547a2C501DA0ab4` [View](https://etherscan.io/address/0xb3ca07c9c10374D51046F94e5547a2C501DA0ab4#code) |
| `BalanceFuseSwapPositionsUniswapV3` | `0x76e06A26483A625ed5816D378836644F8C6CDC46` [View](https://etherscan.io/address/0x76e06A26483A625ed5816D378836644F8C6CDC46#code) |
| `BalanceFuseSwapUniswapV2` | `0xf8Ba61Bf6352E34819717e2cd56f97Be6b131296` [View](https://etherscan.io/address/0xf8Ba61Bf6352E34819717e2cd56f97Be6b131296#code) |
| `BalanceFuseSwapUniswapV3` | `0x2D01C704Ad4502176a328094BF973f1868c2f082` [View](https://etherscan.io/address/0x2D01C704Ad4502176a328094BF973f1868c2f082#code) |
| `BalanceFuseUniswapV4` | `0x18192A95578db97539c0181Bb832DA7Bf2dD80B5` [View](https://etherscan.io/address/0x18192A95578db97539c0181Bb832DA7Bf2dD80B5#code) |
| `BalanceFuseUniversalTokenSwapper` | `0xe9562d7bd06b43E6391C5bE4B3c5F5C2BC1E06Bf` [View](https://etherscan.io/address/0xe9562d7bd06b43E6391C5bE4B3c5F5C2BC1E06Bf#code) |
| `BalanceFuseUniversalTokenSwapperV2` | `0x05968c1Ec31e9eF193da13A0C1131e59eBa0d580` [View](https://etherscan.io/address/0x05968c1Ec31e9eF193da13A0C1131e59eBa0d580#code) |
| `BalanceFuseVeloraSwapper` | `0xB5C14B4c741391d5625A56f70049ab2d720bE9C9` [View](https://etherscan.io/address/0xB5C14B4c741391d5625A56f70049ab2d720bE9C9#code) |
| `BorrowFuseAaveV3` | `0x820D879Ef89356B93A7c71ADDBf45c40a0dDE453` [View](https://etherscan.io/address/0x820D879Ef89356B93A7c71ADDBf45c40a0dDE453#code) |
| `BorrowFuseAaveV3Lido` | `0xF020b954e02D8B8419cF5625D4371F16a678d884` [View](https://etherscan.io/address/0xF020b954e02D8B8419cF5625D4371F16a678d884#code) |
| `BorrowFuseAaveV4` | `0x6A244a43E2081f04ceE900fAf157616A898D081e` [View](https://etherscan.io/address/0x6A244a43E2081f04ceE900fAf157616A898D081e#code) |
| `BorrowFuseCompoundV3Usdc` | `0xbe3468E35D8EBA45418F9dDAc7145aD500fd0F7F` [View](https://etherscan.io/address/0xbe3468E35D8EBA45418F9dDAc7145aD500fd0F7F#code) |
| `BorrowFuseEulerV2` | `0x6B339a926328B9a5A5705fD051aA5028D9f7f2F6` [View](https://etherscan.io/address/0x6B339a926328B9a5A5705fD051aA5028D9f7f2F6#code) |
| `BorrowFuseMorpho` | `0x9981e75b7254fD268C9182631Bf89C86101359d6` [View](https://etherscan.io/address/0x9981e75b7254fD268C9182631Bf89C86101359d6#code) |
| `BurnRequestFeeFuse` | `0x79e8B115Bd41baee318c1940F42F1a2d94D29ab4` [View](https://etherscan.io/address/0x79e8B115Bd41baee318c1940F42F1a2d94D29ab4#code) |
| `BurnRequestFeeFuseV2` | `0x6DebD98329d826bA79b6Fd9B14cC718D1720D0bE` [View](https://etherscan.io/address/0x6DebD98329d826bA79b6Fd9B14cC718D1720D0bE#code) |
| `ClaimRewardsFuseCompoundV3` | `0xe4374aEc1F73edc2AD5c9c9E7091143B0Af4a378` [View](https://etherscan.io/address/0xe4374aEc1F73edc2AD5c9c9E7091143B0Af4a378#code) |
| `ClaimRewardsFuseFluidInstadapp` | `0x59Da0ce05CfCf0DA3257a96446e5B98EDB788c25` [View](https://etherscan.io/address/0x59Da0ce05CfCf0DA3257a96446e5B98EDB788c25#code) |
| `ClaimRewardsFuseFluidProof` | `0x30AdE01153CB697BB751cacb6392F49C22558fe0` [View](https://etherscan.io/address/0x30AdE01153CB697BB751cacb6392F49C22558fe0#code) |
| `ClaimRewardsFuseGearboxV3FarmDToken` | `0xF710B1dAAB1623FeEB78D32bf34E288C3ee67072` [View](https://etherscan.io/address/0xF710B1dAAB1623FeEB78D32bf34E288C3ee67072#code) |
| `ClaimRewardsFuseMorpho` | `0x6820dF665BA09FBbd3240aA303421928EF4C71a1` [View](https://etherscan.io/address/0x6820dF665BA09FBbd3240aA303421928EF4C71a1#code) |
| `CollateralFuseAaveV4` | `0x6EA1DC6B21FF45263d761bcEcC40236aF8A1FA68` [View](https://etherscan.io/address/0x6EA1DC6B21FF45263d761bcEcC40236aF8A1FA68#code) |
| `CollateralFuseEulerV2` | `0x07d80997d57AD9489a4c48f6134dF91822e36514` [View](https://etherscan.io/address/0x07d80997d57AD9489a4c48f6134dF91822e36514#code) |
| `CollateralFuseMorpho` | `0xE1aA89eb42C23f292cDa1544566F6EBeE3a67EED` [View](https://etherscan.io/address/0xE1aA89eb42C23f292cDa1544566F6EBeE3a67EED#code) |
| `CollectFuseUniswapV4` | `0xb4A6b14d08bE159A6434c8668cF9044eCeFb64E7` [View](https://etherscan.io/address/0xb4A6b14d08bE159A6434c8668cF9044eCeFb64E7#code) |
| `CollectSwapFuseUniswapV3` | `0x4DeDFb0F957D844755069cfBA2f6828353662C77` [View](https://etherscan.io/address/0x4DeDFb0F957D844755069cfBA2f6828353662C77#code) |
| `ConfigureInstantWithdrawalFuse` | `0xd58F0EF796618F09f7fc6e63c25fae25CEB33799` [View](https://etherscan.io/address/0xd58F0EF796618F09f7fc6e63c25fae25CEB33799#code) |
| `ControllerFuseEulerV2` | `0x4bFEa07593844155c0BD5ee656cE54e864cA9B55` [View](https://etherscan.io/address/0x4bFEa07593844155c0BD5ee656cE54e864cA9B55#code) |
| `CurveStableswapNGSingleSideBalanceFuse` | `0x2Db6eE136c0532e8E04e60A25e81A680cF184F6b` [View](https://etherscan.io/address/0x2Db6eE136c0532e8E04e60A25e81A680cF184F6b#code) |
| `CurveStableswapNGSingleSideSupplyFuse` | `0xfCB0b631e82f80aF729aADE3ca3A58374A18293A` [View](https://etherscan.io/address/0xfCB0b631e82f80aF729aADE3ca3A58374A18293A#code) |
| `EModeFuseAaveV4` | `0x6A41DB0ad9065Fc8808016CEf6Bd748E4818EFFF` [View](https://etherscan.io/address/0x6A41DB0ad9065Fc8808016CEf6Bd748E4818EFFF#code) |
| `EbisuAdjustInterestRateFuse` | `0xf82a5730AdcE3e30c41d057928E1edF4606C67f9` [View](https://etherscan.io/address/0xf82a5730AdcE3e30c41d057928E1edF4606C67f9#code) |
| `EbisuAdjustTroveFuse` | `0xE30B07bb32181d1ffB76E1e1f88B6107A97CC9E8` [View](https://etherscan.io/address/0xE30B07bb32181d1ffB76E1e1f88B6107A97CC9E8#code) |
| `EbisuZapperBalanceFuse` | `0xb3a7F15034d664fA295B472732BFfC6953eEFb33` [View](https://etherscan.io/address/0xb3a7F15034d664fA295B472732BFfC6953eEFb33#code) |
| `EbisuZapperCreateFuse` | `0x1Aba4764dDE4Ae6D29C97aE3A20A95267a37069e` [View](https://etherscan.io/address/0x1Aba4764dDE4Ae6D29C97aE3A20A95267a37069e#code) |
| `EbisuZapperLeverModifyFuse` | `0xA3BabE2e9A1fdA1350B76EB77C40Dd394c836102` [View](https://etherscan.io/address/0xA3BabE2e9A1fdA1350B76EB77C40Dd394c836102#code) |
| `EulerV2BatchFuse` | `0x45F3bf4F5318D9683357fA8f9f4442263F7DdA6F` [View](https://etherscan.io/address/0x45F3bf4F5318D9683357fA8f9f4442263F7DdA6F#code) |
| `ExternalStateBalanceFuse` | `0x30DE3D8e37C55568653A94102080ea0e822AadD7` [View](https://etherscan.io/address/0x30DE3D8e37C55568653A94102080ea0e822AadD7#code) |
| `ExternalStateOperationFuse` | `0x18856A47C4D8124Ec42Ad7e1Bd82970d63dfa68c` [View](https://etherscan.io/address/0x18856A47C4D8124Ec42Ad7e1Bd82970d63dfa68c#code) |
| `ExternalStateRescueFuse` | `0xE07e04F2844125c5a30A7B9FF77cB51bbBD4C6c2` [View](https://etherscan.io/address/0xE07e04F2844125c5a30A7B9FF77cB51bbBD4C6c2#code) |
| `ExternalStateUnpauseFuse` | `0x6944BF59413F4aE9817cFeC06A0E1377F6801cdD` [View](https://etherscan.io/address/0x6944BF59413F4aE9817cFeC06A0E1377F6801cdD#code) |
| `FlashloanFuseMorpho` | `0x9185033e24dB36407b9b1A1886Cb47B9533433DE` [View](https://etherscan.io/address/0x9185033e24dB36407b9b1A1886Cb47B9533433DE#code) |
| `FuseHarvestDoHardWork` | `0xDA45fe8099358bba400554c9b640170246B43e50` [View](https://etherscan.io/address/0xDA45fe8099358bba400554c9b640170246B43e50#code) |
| `FusePendleRedeemPtAfterMaturity` | `0x40430a509188b71BdA9a0c06b132e978Ea2015BE` [View](https://etherscan.io/address/0x40430a509188b71BdA9a0c06b132e978Ea2015BE#code) |
| `FusePendleSwapPt` | `0xEEA3812B60ca4c6D0e2672a865bf7217eCd49f95` [View](https://etherscan.io/address/0xEEA3812B60ca4c6D0e2672a865bf7217eCd49f95#code) |
| `FuseRedeemFromRequestPlasmaVaultMarket1` | `0x906Af6A42079AdAF1aBD92F924a5d4263653AF0d` [View](https://etherscan.io/address/0x906Af6A42079AdAF1aBD92F924a5d4263653AF0d#code) |
| `FuseRequestSharesPlasmaVaultMarket1` | `0x7130383298822097531Cf5cc5e3414dda1e09542` [View](https://etherscan.io/address/0x7130383298822097531Cf5cc5e3414dda1e09542#code) |
| `FuseRequestSharesPlasmaVaultV2` | `0xD966e091Fd435b82D20952A0F4243B2786b5E379` [View](https://etherscan.io/address/0xD966e091Fd435b82D20952A0F4243B2786b5E379#code) |
| `LitePSMSupplyFuse` | `0x771359B201De4Ce50F0F96A13ac72A636dC55508` [View](https://etherscan.io/address/0x771359B201De4Ce50F0F96A13ac72A636dC55508#code) |
| `MaintenanceFuseUpdateWithdrawManager` | `0x74CA34C2C47d0865856A54060246AB736a0Bb0D0` [View](https://etherscan.io/address/0x74CA34C2C47d0865856A54060246AB736a0Bb0D0#code) |
| `MerklClaimFuse` | `0x47AcA48086036D213F2A5faa6764a62777B4Bbcc` [View](https://etherscan.io/address/0x47AcA48086036D213F2A5faa6764a62777B4Bbcc#code) |
| `MidasBalanceFuse` | `0x79Be255f9D5B02C15127b97A3F1EEBc49A070500` [View](https://etherscan.io/address/0x79Be255f9D5B02C15127b97A3F1EEBc49A070500#code) |
| `MidasClaimFromExecutorFuse` | `0xAe2459cB66CA9C404af897C3694d62ba760066Be` [View](https://etherscan.io/address/0xAe2459cB66CA9C404af897C3694d62ba760066Be#code) |
| `MidasRequestSupplyFuse` | `0x181703Ceda22a1e27679244ac4fb33A51f1A4973` [View](https://etherscan.io/address/0x181703Ceda22a1e27679244ac4fb33A51f1A4973#code) |
| `MidasSupplyFuse` | `0xadBf5B4739055B09440cd46c177D3f5B0d5E571F` [View](https://etherscan.io/address/0xadBf5B4739055B09440cd46c177D3f5B0d5E571F#code) |
| `ModifyPositionFuseUniswapV4` | `0x8Ff33d99A25B448387DCcad4Ed61C61b40C19815` [View](https://etherscan.io/address/0x8Ff33d99A25B448387DCcad4Ed61C61b40C19815#code) |
| `ModifyPositionSwapFuseUniswapV3` | `0xef0285fAA4BDb749CBFd3b1FcB4f61500307D8d4` [View](https://etherscan.io/address/0xef0285fAA4BDb749CBFd3b1FcB4f61500307D8d4#code) |
| `NapierCollectFuse` | `0x957BEAc5216D4556821B2D441C1e70f73B8A8Dba` [View](https://etherscan.io/address/0x957BEAc5216D4556821B2D441C1e70f73B8A8Dba#code) |
| `NapierCombineFuse` | `0x1e17d11750E11B4a179b56595167a3e7b46C2154` [View](https://etherscan.io/address/0x1e17d11750E11B4a179b56595167a3e7b46C2154#code) |
| `NapierDepositFuse` | `0x601A3566998dEb19025aC55C440828Dd0064e8dA` [View](https://etherscan.io/address/0x601A3566998dEb19025aC55C440828Dd0064e8dA#code) |
| `NapierRedeemFuse` | `0xcea2E1e1cf7a1A518c877986bAE93A7E7a7bf94e` [View](https://etherscan.io/address/0xcea2E1e1cf7a1A518c877986bAE93A7E7a7bf94e#code) |
| `NapierSupplyFuse` | `0x5BebfB72D40df444603c041c0179B6d921882F1A` [View](https://etherscan.io/address/0x5BebfB72D40df444603c041c0179B6d921882F1A#code) |
| `NapierSwapPtFuse` | `0xBa6A8B1DB7f1dCb93A101d2CfF78C7a37a9059c6` [View](https://etherscan.io/address/0xBa6A8B1DB7f1dCb93A101d2CfF78C7a37a9059c6#code) |
| `NapierSwapYtFuse` | `0x0Cd25aCbCE15bAC7bb2B129B69B452A70692F8C4` [View](https://etherscan.io/address/0x0Cd25aCbCE15bAC7bb2B129B69B452A70692F8C4#code) |
| `NapierZapDepositFuse` | `0xE067Eb9E64470b5707B305C4925671DFA50e7C67` [View](https://etherscan.io/address/0xE067Eb9E64470b5707B305C4925671DFA50e7C67#code) |
| `NewPositionFuseUniswapV4` | `0x1A2D2F51D1874BDc89F6E78feb99B8B7967d16dA` [View](https://etherscan.io/address/0x1A2D2F51D1874BDc89F6E78feb99B8B7967d16dA#code) |
| `NewPositionSwapFuseUniswapV3` | `0xe096501052d741DA5483bD2a6cCc93a4CDf879cd` [View](https://etherscan.io/address/0xe096501052d741DA5483bD2a6cCc93a4CDf879cd#code) |
| `OdosSwapperFuse` | `0xC13F3Fd20556A595990C35612E9e5c1C071Cb691` [View](https://etherscan.io/address/0xC13F3Fd20556A595990C35612E9e5c1C071Cb691#code) |
| `RequestFeeRefundFuse` | `0xcbB5cA86dB1E237bfA364A817F31F0812D88BF34` [View](https://etherscan.io/address/0xcbB5cA86dB1E237bfA364A817F31F0812D88BF34#code) |
| `RewardEulerTokenClaimFuse` | `0xFfBfB992487290E5DA9dE4C06BFfD2d42eaAe2bA` [View](https://etherscan.io/address/0xFfBfB992487290E5DA9dE4C06BFfD2d42eaAe2bA#code) |
| `SiloV2BalanceFuse` | `0x086acA94AA413932C6ac5e09b863AC2Cbe17998f` [View](https://etherscan.io/address/0x086acA94AA413932C6ac5e09b863AC2Cbe17998f#code) |
| `SiloV2BorrowFuse` | `0x1D24B8d16d87a570e8539c2849A23Bbc5F13005B` [View](https://etherscan.io/address/0x1D24B8d16d87a570e8539c2849A23Bbc5F13005B#code) |
| `SiloV2SupplyBorrowableCollateralFuse` | `0xb3d5c1b8D512bd41d845817f84E4Ea29bF038fb5` [View](https://etherscan.io/address/0xb3d5c1b8D512bd41d845817f84E4Ea29bF038fb5#code) |
| `SiloV2SupplyNonBorrowableCollateralFuse` | `0x897d96A7C91e2F1B8213f240CaD031f9acdEfA56` [View](https://etherscan.io/address/0x897d96A7C91e2F1B8213f240CaD031f9acdEfA56#code) |
| `SparkLendBorrowFuse` | `0xE3aBaE104B259c523f022a880AD4a73ea8DE4c5e` [View](https://etherscan.io/address/0xE3aBaE104B259c523f022a880AD4a73ea8DE4c5e#code) |
| `SparkLendCollateralFuse` | `0xACba93fAFc6886694583D20752D20Fb312d1cE46` [View](https://etherscan.io/address/0xACba93fAFc6886694583D20752D20Fb312d1cE46#code) |
| `SparkLendSupplyFuse` | `0x81DD10690E5690177F052b1b74c3070734831106` [View](https://etherscan.io/address/0x81DD10690E5690177F052b1b74c3070734831106#code) |
| `SparkLendWithPriceOracleMiddlewareBalanceFuse` | `0x05397aDb7A0B596DF88BCa2b06c0cbfB28e5222d` [View](https://etherscan.io/address/0x05397aDb7A0B596DF88BCa2b06c0cbfB28e5222d#code) |
| `StEthWrapperFuse` | `0x176F645b837663F4aF2579f37059bdC22EE69584` [View](https://etherscan.io/address/0x176F645b837663F4aF2579f37059bdC22EE69584#code) |
| `StabilityPoolFuseLiquity` | `0x5f0E7454F0AF81141806ec3B31D972401Bae3Edb` [View](https://etherscan.io/address/0x5f0E7454F0AF81141806ec3B31D972401Bae3Edb#code) |
| `StakeDaoV2BalanceFuse` | `0x0c59d9Cd3859673EDC70b0BcF66E2715831C3816` [View](https://etherscan.io/address/0x0c59d9Cd3859673EDC70b0BcF66E2715831C3816#code) |
| `StakeDaoV2ClaimFuse` | `0x7ec22C4deFE53eC35F03f0B6468ec319c577DEFc` [View](https://etherscan.io/address/0x7ec22C4deFE53eC35F03f0B6468ec319c577DEFc#code) |
| `StakeDaoV2SupplyFuse` | `0x5Be6e757763A3b7106D211dF5017823366cE3C1e` [View](https://etherscan.io/address/0x5Be6e757763A3b7106D211dF5017823366cE3C1e#code) |
| `SupplyFuseAaveV3` | `0x7b3957B38b1c91057755D71701247905b48D6063` [View](https://etherscan.io/address/0x7b3957B38b1c91057755D71701247905b48D6063#code) |
| `SupplyFuseAaveV3Lido` | `0x05c090ffB794abcAc1d0EFa8ebf321E862b75f66` [View](https://etherscan.io/address/0x05c090ffB794abcAc1d0EFa8ebf321E862b75f66#code) |
| `SupplyFuseAaveV4` | `0x63F8d451a5FF060fCC0EA0D53B5B2870c0D05790` [View](https://etherscan.io/address/0x63F8d451a5FF060fCC0EA0D53B5B2870c0D05790#code) |
| `SupplyFuseCompoundV3Usdc` | `0x46DfC76C2673462c1ceecFAf3061Ac354e371e98` [View](https://etherscan.io/address/0x46DfC76C2673462c1ceecFAf3061Ac354e371e98#code) |
| `SupplyFuseCompoundV3Usdt` | `0x4f35094b049e4aa0eA98CfA00fA55f30B12aaF29` [View](https://etherscan.io/address/0x4f35094b049e4aa0eA98CfA00fA55f30B12aaF29#code) |
| `SupplyFuseErc4626Market1` | `0x5e32f634157b94Feb5E004C2efa899Bb28f01999` [View](https://etherscan.io/address/0x5e32f634157b94Feb5E004C2efa899Bb28f01999#code) |
| `SupplyFuseErc4626Market10` | `0x886361d6eF54Df4E86F265BcEe5e9E73773bf095` [View](https://etherscan.io/address/0x886361d6eF54Df4E86F265BcEe5e9E73773bf095#code) |
| `SupplyFuseErc4626Market11` | `0x22E9F540c92a0dee0F7A83E1a868Df8d01D3A02e` [View](https://etherscan.io/address/0x22E9F540c92a0dee0F7A83E1a868Df8d01D3A02e#code) |
| `SupplyFuseErc4626Market12` | `0x30355D36f845CAe42f6f7BB2dE7BA85DfB3D9b87` [View](https://etherscan.io/address/0x30355D36f845CAe42f6f7BB2dE7BA85DfB3D9b87#code) |
| `SupplyFuseErc4626Market13` | `0x22632982F57155d4b7D5dbC1d5827e5719b27AD1` [View](https://etherscan.io/address/0x22632982F57155d4b7D5dbC1d5827e5719b27AD1#code) |
| `SupplyFuseErc4626Market14` | `0x922406d8F83d92E5eAf9b95f8A0297F2EC4e481D` [View](https://etherscan.io/address/0x922406d8F83d92E5eAf9b95f8A0297F2EC4e481D#code) |
| `SupplyFuseErc4626Market15` | `0x7cEAc6579C7DeB0D3768383884aCd1e9BFFC6BF4` [View](https://etherscan.io/address/0x7cEAc6579C7DeB0D3768383884aCd1e9BFFC6BF4#code) |
| `SupplyFuseErc4626Market2` | `0xeAcf9ccD2ebb4a2eA2224B162D795E5DEBF85153` [View](https://etherscan.io/address/0xeAcf9ccD2ebb4a2eA2224B162D795E5DEBF85153#code) |
| `SupplyFuseErc4626Market3` | `0x006F514f031a55488D4E19842424542C8aC8d21e` [View](https://etherscan.io/address/0x006F514f031a55488D4E19842424542C8aC8d21e#code) |
| `SupplyFuseErc4626Market4` | `0x59b57431Fb7EA6862d3BaE08E12d50435a442D58` [View](https://etherscan.io/address/0x59b57431Fb7EA6862d3BaE08E12d50435a442D58#code) |
| `SupplyFuseErc4626Market5` | `0xB7E947E4d7a7FEf871fC64549f94A5E82E62aE82` [View](https://etherscan.io/address/0xB7E947E4d7a7FEf871fC64549f94A5E82E62aE82#code) |
| `SupplyFuseErc4626Market6` | `0xE160A75bCA47bcA771B91565BD16b498299eF454` [View](https://etherscan.io/address/0xE160A75bCA47bcA771B91565BD16b498299eF454#code) |
| `SupplyFuseErc4626Market7` | `0x47e8DC81792173f5f6148081B2344E38C7A5bb3C` [View](https://etherscan.io/address/0x47e8DC81792173f5f6148081B2344E38C7A5bb3C#code) |
| `SupplyFuseErc4626Market8` | `0xBA1857457790eE06043e5871D6606FC31F42BfEA` [View](https://etherscan.io/address/0xBA1857457790eE06043e5871D6606FC31F42BfEA#code) |
| `SupplyFuseErc4626Market9` | `0xEa3a83f515b47c263bd387b60061F74A0FE8DB08` [View](https://etherscan.io/address/0xEa3a83f515b47c263bd387b60061F74A0FE8DB08#code) |
| `SupplyFuseEulerV2` | `0x9425Cc51E61F04942008B7cAFf129C2c6e57F217` [View](https://etherscan.io/address/0x9425Cc51E61F04942008B7cAFf129C2c6e57F217#code) |
| `SupplyFuseFluidInstadappPoolFToken` | `0xe49207496BB2Cf8C3D4FDadcad8e5f72E780B4Ae` [View](https://etherscan.io/address/0xe49207496BB2Cf8C3D4FDadcad8e5f72E780B4Ae#code) |
| `SupplyFuseFluidInstadappStakingRewardsFToken` | `0xa613249EF6D0C3dF83d0593abb63e0638d1d590F` [View](https://etherscan.io/address/0xa613249EF6D0C3dF83d0593abb63e0638d1d590F#code) |
| `SupplyFuseGearboxV3DToken` | `0x95acDF1C8f4447E655a097aEa3F92FB15035485D` [View](https://etherscan.io/address/0x95acDF1C8f4447E655a097aEa3F92FB15035485D#code) |
| `SupplyFuseGearboxV3FarmDToken` | `0xF6016A183745C86Dd584488c9E75c00BBD61C34E` [View](https://etherscan.io/address/0xF6016A183745C86Dd584488c9E75c00BBD61C34E#code) |
| `SupplyFuseMetaMorphoMarket0001` | `0x5E58D1f3c9155c74fC43dbBd0157ef49BaFA6A88` [View](https://etherscan.io/address/0x5E58D1f3c9155c74fC43dbBd0157ef49BaFA6A88#code) |
| `SupplyFuseMorpho` | `0xD08Cb606CEe700628E55b0B0159Ad65421E6c8Df` [View](https://etherscan.io/address/0xD08Cb606CEe700628E55b0B0159Ad65421E6c8Df#code) |
| `SupplyFuseMorphoLiquidityInMarkets` | `0x3a017de24585b2C8cAbfCca6ef8248c394DDb138` [View](https://etherscan.io/address/0x3a017de24585b2C8cAbfCca6ef8248c394DDb138#code) |
| `SupplyFuseSpark` | `0xB48CF802C2D648c46ac7f752C81e29Fa2C955E9B` [View](https://etherscan.io/address/0xB48CF802C2D648c46ac7f752C81e29Fa2C955E9B#code) |
| `SwapDeployFuseEulerV2` | `0x6A1E8Cef962AEb714A3e6FEcdB89ae6183cc0165` [View](https://etherscan.io/address/0x6A1E8Cef962AEb714A3e6FEcdB89ae6183cc0165#code) |
| `SwapFuseUniswapV2` | `0x37a720Cf7F7dA943E4244F97903a85c997cab359` [View](https://etherscan.io/address/0x37a720Cf7F7dA943E4244F97903a85c997cab359#code) |
| `SwapFuseUniswapV3` | `0xA1D8600f64aA82161ba9265ffeBFDe6a78F1275C` [View](https://etherscan.io/address/0xA1D8600f64aA82161ba9265ffeBFDe6a78F1275C#code) |
| `SwapFuseUniversalTokenSwapper` | `0x08dFdBB6Ecf19f1fc974E0675783E1150B2B650F` [View](https://etherscan.io/address/0x08dFdBB6Ecf19f1fc974E0675783E1150B2B650F#code) |
| `SwapFuseUniversalTokenSwapperEth` | `0xee9a18F0De64E8Eb399A3BaEF0550aa50A218768` [View](https://etherscan.io/address/0xee9a18F0De64E8Eb399A3BaEF0550aa50A218768#code) |
| `SwapFuseUniversalTokenSwapperEthNoSlippage` | `0xd932D47FcF53D8dc1eF58455Dd5910E19aF2DbF0` [View](https://etherscan.io/address/0xd932D47FcF53D8dc1eF58455Dd5910E19aF2DbF0#code) |
| `SwapFuseUniversalTokenSwapperEthNoSlippageV2` | `0xc4E6624736Ba9A33B2b59Ddc2C14cD16a0EcB564` [View](https://etherscan.io/address/0xc4E6624736Ba9A33B2b59Ddc2C14cD16a0EcB564#code) |
| `SwapFuseUniversalTokenSwapperWithVerification` | `0x4E0B22A5052B640967c55b92401b1c067FdA53e0` [View](https://etherscan.io/address/0x4E0B22A5052B640967c55b92401b1c067FdA53e0#code) |
| `SwapFuseUniversalTokenSwapperWithVerificationV2` | `0x65f24c9E91752BeC40397B232458DfdAC27e69a6` [View](https://etherscan.io/address/0x65f24c9E91752BeC40397B232458DfdAC27e69a6#code) |
| `SwapFuseUniversalTokenSwapper_PV_USDC_msyrupL` | `0x54c860323cCD609405a18E46b0F799BEb5DF5D50` [View](https://etherscan.io/address/0x54c860323cCD609405a18E46b0F799BEb5DF5D50#code) |
| `SwapReconfigureFuseEulerV2` | `0xd8c2DE8ddA805a8Bdc731A3f8c6EBAD99850005F` [View](https://etherscan.io/address/0xd8c2DE8ddA805a8Bdc731A3f8c6EBAD99850005F#code) |
| `SwapRegistryFuseEulerV2` | `0xcb7Ac645dA075a2b0391BA7102b8c383D4211fdC` [View](https://etherscan.io/address/0xcb7Ac645dA075a2b0391BA7102b8c383D4211fdC#code) |
| `SyrupClaimFuse` | `0x5b1a6B2E6Af64E74275015A65687de0ca941f537` [View](https://etherscan.io/address/0x5b1a6B2E6Af64E74275015A65687de0ca941f537#code) |
| `UniversalReaderBalanceFuses` | `0x870E1Fb75BEdbc2eFB92857DC2B2cF171a0AEC1f` [View](https://etherscan.io/address/0x870E1Fb75BEdbc2eFB92857DC2B2cF171a0AEC1f#code) |
| `UniversalTokenSwapperEthFuse` | `0xa07780FdaF46C0EFd5C4F6349268065E5D1fDBe5` [View](https://etherscan.io/address/0xa07780FdaF46C0EFd5C4F6349268065E5D1fDBe5#code) |
| `UniversalTokenSwapperEthFuseV2` | `0xf3777089A4b31EF0f9e8B6f3762C6FBeD4dDA449` [View](https://etherscan.io/address/0xf3777089A4b31EF0f9e8B6f3762C6FBeD4dDA449#code) |
| `UniversalTokenSwapperFuse` | `0x54c860323cCD609405a18E46b0F799BEb5DF5D50` [View](https://etherscan.io/address/0x54c860323cCD609405a18E46b0F799BEb5DF5D50#code) |
| `UniversalTokenSwapperFuseV2` | `0x5A62574a2b28cC73c63116919A9131fb4F51941b` [View](https://etherscan.io/address/0x5A62574a2b28cC73c63116919A9131fb4F51941b#code) |
| `VeloraSwapperFuse` | `0x8771e28451F0A2b891B3401c94bCfA272215D48b` [View](https://etherscan.io/address/0x8771e28451F0A2b891B3401c94bCfA272215D48b#code) |
| `ZeroBalanceFuseLitePSM` | `0x336a13cad401e82fda58bEC8e42AcdB568A998eC` [View](https://etherscan.io/address/0x336a13cad401e82fda58bEC8e42AcdB568A998eC#code) |
| `ZeroBalanceFuseNapier` | `0xCEa56CDcA4d718E2cf5951cD7Db5f0BbAed0A7c4` [View](https://etherscan.io/address/0xCEa56CDcA4d718E2cf5951cD7Db5f0BbAed0A7c4#code) |

#### Ethereum Older Fuses Versions

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `AaveV3WithPriceOracleMiddlewareBalanceLidoFuse` | `0x1d04A9d1Efa9D0C54e3757503F99d75B8f398BfA` [View](https://etherscan.io/address/0x1d04A9d1Efa9D0C54e3757503F99d75B8f398BfA#code) |
| `BalanceFuseAaveV3Lido` | `0xE5a3958B24767b30f0f5d3F47A25cFB4c08c1053` [View](https://etherscan.io/address/0xE5a3958B24767b30f0f5d3F47A25cFB4c08c1053#code) |
| `BalanceFuseAaveV4` | `0x79B23f39dA8fe16b60A306232216845584Bb7f1A` [View](https://etherscan.io/address/0x79B23f39dA8fe16b60A306232216845584Bb7f1A#code) |
| `BalanceFuseEulerV2` | `0xA607855Ec4881B5F25711d1404E0CddeAdEEacdC` [View](https://etherscan.io/address/0xA607855Ec4881B5F25711d1404E0CddeAdEEacdC#code) |
| `BalanceFuseLiquity` | `0x76E7F7174415E93D770Efe004d4b8C9c76C3C6E2` [View](https://etherscan.io/address/0x76E7F7174415E93D770Efe004d4b8C9c76C3C6E2#code) |
| `BorrowFuseAaveV4` | `0xffd8f39350A0ef7a866180657AD13ffE26aB0801` [View](https://etherscan.io/address/0xffd8f39350A0ef7a866180657AD13ffE26aB0801#code) |
| `BorrowFuseEulerV2` | `0x20c782C94800d709541660E322035785c89E32C2` [View](https://etherscan.io/address/0x20c782C94800d709541660E322035785c89E32C2#code) |
| `ClaimRewardsFuseCompoundV3` | `0x2B98080341D9469d8beAbf2db037dE8897c232cD` [View](https://etherscan.io/address/0x2B98080341D9469d8beAbf2db037dE8897c232cD#code) |
| `CollateralFuseEulerV2` | `0xF58d96142A6AbBeE5cB2f2eDe750Aa7429672618` [View](https://etherscan.io/address/0xF58d96142A6AbBeE5cB2f2eDe750Aa7429672618#code) |
| `ControllerFuseEulerV2` | `0x4DcA6Fd6f153EE18602ac77B4396070476ec6c25` [View](https://etherscan.io/address/0x4DcA6Fd6f153EE18602ac77B4396070476ec6c25#code) |
| `EbisuZapperCreateFuse` | `0x586a819AAd974F6EF49E2bD425a7526F3f2551F4` [View](https://etherscan.io/address/0x586a819AAd974F6EF49E2bD425a7526F3f2551F4#code) |
| `MidasBalanceFuse` | `0x177A82A592Ac7A6E5a68a6e1b9Df42ea52608A5E` [View](https://etherscan.io/address/0x177A82A592Ac7A6E5a68a6e1b9Df42ea52608A5E#code) |
| `MidasBalanceFuse` | `0x8193caEA6E5aa7006aeB25D55Afc10615EC96eB2` [View](https://etherscan.io/address/0x8193caEA6E5aa7006aeB25D55Afc10615EC96eB2#code) |
| `MidasBalanceFuse` | `0x1bFB9E4B7D849c641E7Ff896849a4D446322e050` [View](https://etherscan.io/address/0x1bFB9E4B7D849c641E7Ff896849a4D446322e050#code) |
| `MidasRequestSupplyFuse` | `0x3214edf0E033c134497e83325f3DFa011FbE22A6` [View](https://etherscan.io/address/0x3214edf0E033c134497e83325f3DFa011FbE22A6#code) |
| `MidasRequestSupplyFuse` | `0x45209c7F307894FD19fb0560827107B7c4bdcab8` [View](https://etherscan.io/address/0x45209c7F307894FD19fb0560827107B7c4bdcab8#code) |
| `MidasRequestSupplyFuse` | `0x1B66a7Dd521AE6ee23C280aF3277E54bDd209a3c` [View](https://etherscan.io/address/0x1B66a7Dd521AE6ee23C280aF3277E54bDd209a3c#code) |
| `MidasSupplyFuse` | `0x27Cc565483238DA3884D6031374E5feE3D6F571b` [View](https://etherscan.io/address/0x27Cc565483238DA3884D6031374E5feE3D6F571b#code) |
| `MidasSupplyFuse` | `0x9AA21e5101279229a02326E411dAfcBd48ba6DB1` [View](https://etherscan.io/address/0x9AA21e5101279229a02326E411dAfcBd48ba6DB1#code) |
| `MidasSupplyFuse` | `0x99bc0136Ba3cC8D1a920E68eADff4fd899Bec386` [View](https://etherscan.io/address/0x99bc0136Ba3cC8D1a920E68eADff4fd899Bec386#code) |
| `RequestFeeRefundFuse` | `0xE64902cB18bB176E944709886d6eaBCe272372ea` [View](https://etherscan.io/address/0xE64902cB18bB176E944709886d6eaBCe272372ea#code) |
| `RewardEulerTokenClaimFuse` | `0xAA2442F310D8D4a6d42160b1D2a22aCb1dd0866a` [View](https://etherscan.io/address/0xAA2442F310D8D4a6d42160b1D2a22aCb1dd0866a#code) |
| `StEthWrapperFuse` | `0xab97e49fcB752f7713090814199b4458b4Ea1bAd` [View](https://etherscan.io/address/0xab97e49fcB752f7713090814199b4458b4Ea1bAd#code) |
| `SupplyFuseAaveV3` | `0x465D639EB964158beE11f35E8fc23f704EC936a2` [View](https://etherscan.io/address/0x465D639EB964158beE11f35E8fc23f704EC936a2#code) |
| `SupplyFuseAaveV3Lido` | `0x02956820074400138a4602d35ee1b7f3886EeC1e` [View](https://etherscan.io/address/0x02956820074400138a4602d35ee1b7f3886EeC1e#code) |
| `SupplyFuseAaveV3Lido` | `0x09791C53218010eE59464386F6a3B9D656490d60` [View](https://etherscan.io/address/0x09791C53218010eE59464386F6a3B9D656490d60#code) |
| `SupplyFuseAaveV4` | `0x652813B390359f20789f7B399e692318b1b6F3Fc` [View](https://etherscan.io/address/0x652813B390359f20789f7B399e692318b1b6F3Fc#code) |
| `SupplyFuseCompoundV3Usdc` | `0x00A220F09C1CF5f549C98Fa37C837aed54aBA26c` [View](https://etherscan.io/address/0x00A220F09C1CF5f549C98Fa37C837aed54aBA26c#code) |
| `SupplyFuseErc4626Market1` | `0x12FD0EE183c85940CAedd4877f5d3Fc637515870` [View](https://etherscan.io/address/0x12FD0EE183c85940CAedd4877f5d3Fc637515870#code) |
| `SupplyFuseErc4626Market10` | `0x01D4fa645F3B98Fc9D870Dd687dE3665F0D45CDf` [View](https://etherscan.io/address/0x01D4fa645F3B98Fc9D870Dd687dE3665F0D45CDf#code) |
| `SupplyFuseErc4626Market11` | `0x6b9489369015233e049F548cE6C0deDcf17BFb90` [View](https://etherscan.io/address/0x6b9489369015233e049F548cE6C0deDcf17BFb90#code) |
| `SupplyFuseErc4626Market12` | `0xf16119e669C1fB8264DFFD92EcB1AB592f73D8e3` [View](https://etherscan.io/address/0xf16119e669C1fB8264DFFD92EcB1AB592f73D8e3#code) |
| `SupplyFuseErc4626Market13` | `0x970b4f5522685D4826eceb0377B3DdBF12836dFd` [View](https://etherscan.io/address/0x970b4f5522685D4826eceb0377B3DdBF12836dFd#code) |
| `SupplyFuseErc4626Market14` | `0xD6Fa88B765846615cE14d9a444e0cB350043b783` [View](https://etherscan.io/address/0xD6Fa88B765846615cE14d9a444e0cB350043b783#code) |
| `SupplyFuseErc4626Market15` | `0x361Baf77C94f4504691d9f3C463f9950591C9434` [View](https://etherscan.io/address/0x361Baf77C94f4504691d9f3C463f9950591C9434#code) |
| `SupplyFuseErc4626Market2` | `0x83Be46881AaeBA80B3d647e08a47301Db2e4E754` [View](https://etherscan.io/address/0x83Be46881AaeBA80B3d647e08a47301Db2e4E754#code) |
| `SupplyFuseErc4626Market3` | `0x53ecC250d70C9F8B88edb817a9097c6caAC81a6B` [View](https://etherscan.io/address/0x53ecC250d70C9F8B88edb817a9097c6caAC81a6B#code) |
| `SupplyFuseErc4626Market4` | `0x06B53AF012499D6429741B9D53e868Fd89a5D3B2` [View](https://etherscan.io/address/0x06B53AF012499D6429741B9D53e868Fd89a5D3B2#code) |
| `SupplyFuseErc4626Market5` | `0x59E58D1a800426dF9FDdDdbd248da0ACC4D38F89` [View](https://etherscan.io/address/0x59E58D1a800426dF9FDdDdbd248da0ACC4D38F89#code) |
| `SupplyFuseErc4626Market6` | `0xf492E277D6D6E051f9871E66bADFd089fB7BF5E7` [View](https://etherscan.io/address/0xf492E277D6D6E051f9871E66bADFd089fB7BF5E7#code) |
| `SupplyFuseErc4626Market7` | `0x87E3b7C430368eb4684ef622baE0D4c8C0cd590B` [View](https://etherscan.io/address/0x87E3b7C430368eb4684ef622baE0D4c8C0cd590B#code) |
| `SupplyFuseErc4626Market8` | `0xbD8a194d188Bc27A050f271a923459cAB847CA9F` [View](https://etherscan.io/address/0xbD8a194d188Bc27A050f271a923459cAB847CA9F#code) |
| `SupplyFuseErc4626Market9` | `0x62679B25956d525703c810a6c13e2324312649e8` [View](https://etherscan.io/address/0x62679B25956d525703c810a6c13e2324312649e8#code) |
| `SupplyFuseEulerV2` | `0xDd33b4b6b9A7aA6fcC5F1D1c8ebB649A796Fd5B5` [View](https://etherscan.io/address/0xDd33b4b6b9A7aA6fcC5F1D1c8ebB649A796Fd5B5#code) |
| `SupplyFuseEulerV2` | `0x225D3e01d3Ba0DdF904E1Fbb46256f7D3A7e7bF0` [View](https://etherscan.io/address/0x225D3e01d3Ba0DdF904E1Fbb46256f7D3A7e7bF0#code) |
| `SwapFuseUniversalTokenSwapper_PV_USDC_msyrupL` | `0x641B81E993E1C52a74a84cAf17f1aD50A49675B3` [View](https://etherscan.io/address/0x641B81E993E1C52a74a84cAf17f1aD50A49675B3#code) |
| `UniversalTokenSwapperFuse` | `0xA301D6f34f2c8399E8564681cF675999cc1f1584` [View](https://etherscan.io/address/0xA301D6f34f2c8399E8564681cF675999cc1f1584#code) |

### Arbitrum Fuses

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `AaveV3WithPriceOracleMiddlewareBalanceFuse` | `0xBb3C4Ba23bFbC2eBD4e11B900e05438EB9549602` [View](https://arbiscan.io/address/0xBb3C4Ba23bFbC2eBD4e11B900e05438EB9549602#code) |
| `AsyncActionBalanceFuse` | `0xb7FEBd5b21C7a0399Ad930117cC6c5CA05409Eec` [View](https://arbiscan.io/address/0xb7FEBd5b21C7a0399Ad930117cC6c5CA05409Eec#code) |
| `AsyncActionFuse` | `0xf414c7ebC7911eE730F62799BA5D3224b45E0d7F` [View](https://arbiscan.io/address/0xf414c7ebC7911eE730F62799BA5D3224b45E0d7F#code) |
| `BalanceFuseAaveV3` | `0x4CB1c4774BA1B65802c68Adb33DE99ABf8B21228` [View](https://arbiscan.io/address/0x4CB1c4774BA1B65802c68Adb33DE99ABf8B21228#code) |
| `BalanceFuseBurnRequestFee` | `0xF8a9E4D0899d6268421FC1af952d91782728b8E5` [View](https://arbiscan.io/address/0xF8a9E4D0899d6268421FC1af952d91782728b8E5#code) |
| `BalanceFuseCompoundV3Usdc` | `0xCF730BAA5542DC7570907696271bA96019FcD10C` [View](https://arbiscan.io/address/0xCF730BAA5542DC7570907696271bA96019FcD10C#code) |
| `BalanceFuseErc20` | `0x1a047137F2D4daE60853f87Dc13ae92C0dB2c123` [View](https://arbiscan.io/address/0x1a047137F2D4daE60853f87Dc13ae92C0dB2c123#code) |
| `BalanceFuseErc4626Market1` | `0xfc938b178e37788CECb6925C9034f589A91783FB` [View](https://arbiscan.io/address/0xfc938b178e37788CECb6925C9034f589A91783FB#code) |
| `BalanceFuseErc4626Market2` | `0xd78C731597247883103682eaF51097FB35d819B4` [View](https://arbiscan.io/address/0xd78C731597247883103682eaF51097FB35d819B4#code) |
| `BalanceFuseErc4626Market3` | `0x5e31e0c31Be569b0E8375B35b6354dE755525ecC` [View](https://arbiscan.io/address/0x5e31e0c31Be569b0E8375B35b6354dE755525ecC#code) |
| `BalanceFuseErc4626Market4` | `0xa57AE6DD2551eDE6eAd278E47DF9dF3535935418` [View](https://arbiscan.io/address/0xa57AE6DD2551eDE6eAd278E47DF9dF3535935418#code) |
| `BalanceFuseErc4626Market5` | `0xd3f1F690c9459c1cd7048725f420149668240b7B` [View](https://arbiscan.io/address/0xd3f1F690c9459c1cd7048725f420149668240b7B#code) |
| `BalanceFuseErc4626Market6` | `0x37189A0f865abACc9445F5E44D2d35426d0F2CF7` [View](https://arbiscan.io/address/0x37189A0f865abACc9445F5E44D2d35426d0F2CF7#code) |
| `BalanceFuseErc4626Market7` | `0xA1cD5b1112e6700D98a4A4B39A7946fEC3a4663B` [View](https://arbiscan.io/address/0xA1cD5b1112e6700D98a4A4B39A7946fEC3a4663B#code) |
| `BalanceFuseEulerV2` | `0xF7dF7b8eB5B0c6d02b1b8FEC769dFE65D9a27E3b` [View](https://arbiscan.io/address/0xF7dF7b8eB5B0c6d02b1b8FEC769dFE65D9a27E3b#code) |
| `BalanceFuseFlashLoanMorpho` | `0xAD5EdaEc3cd9a25C8Cc42284dDeF57dCFF40341d` [View](https://arbiscan.io/address/0xAD5EdaEc3cd9a25C8Cc42284dDeF57dCFF40341d#code) |
| `BalanceFuseFluidInstadappPoolFToken` | `0xdb26Af00177bFAE4439eB881b7742EF47EddfAF6` [View](https://arbiscan.io/address/0xdb26Af00177bFAE4439eB881b7742EF47EddfAF6#code) |
| `BalanceFuseFluidInstadappStakingRewardsFToken` | `0xA99ab2d4709c9FC83779Bd4B230e888DcCaEdaf6` [View](https://arbiscan.io/address/0xA99ab2d4709c9FC83779Bd4B230e888DcCaEdaf6#code) |
| `BalanceFuseGearboxV3DToken` | `0xd347F4BB96531b01c8fAB953CF8E920419193a8c` [View](https://arbiscan.io/address/0xd347F4BB96531b01c8fAB953CF8E920419193a8c#code) |
| `BalanceFuseGearboxV3FarmDToken` | `0xAa6C8DB1DA40f685e02564dE92Bc2276C12729f6` [View](https://arbiscan.io/address/0xAa6C8DB1DA40f685e02564dE92Bc2276C12729f6#code) |
| `BalanceFuseMorpho` | `0x502E904E9dd40B8274dFF84F2dbFcCA48dE8F802` [View](https://arbiscan.io/address/0x502E904E9dd40B8274dFF84F2dbFcCA48dE8F802#code) |
| `BalanceFuseMorphoLiquidityInMarkets` | `0x71CcCE8bd93F7CAD49BDe538D31F85427E388863` [View](https://arbiscan.io/address/0x71CcCE8bd93F7CAD49BDe538D31F85427E388863#code) |
| `BalanceFuseOdosSwapper` | `0x8447Eda17965F7E9CEEC0cCfc9BE0B8Cf47665C4` [View](https://arbiscan.io/address/0x8447Eda17965F7E9CEEC0cCfc9BE0B8Cf47665C4#code) |
| `BalanceFusePendle` | `0xE78D9bE2fAe6C0202Fd10fcDaf2cbc4DbfdDE7C1` [View](https://arbiscan.io/address/0xE78D9bE2fAe6C0202Fd10fcDaf2cbc4DbfdDE7C1#code) |
| `BalanceFuseSwapPositionsRamsesV2` | `0xD9fd7D42848A97F946f42c62eC3150D24C0a3835` [View](https://arbiscan.io/address/0xD9fd7D42848A97F946f42c62eC3150D24C0a3835#code) |
| `BalanceFuseSwapPositionsUniswapV3` | `0xf5f05a86e4fe84033940FC7FaEEa5E17C6614945` [View](https://arbiscan.io/address/0xf5f05a86e4fe84033940FC7FaEEa5E17C6614945#code) |
| `BalanceFuseSwapUniswapV2` | `0x0f0f43B3559bE3319a63082755AD05C158D3b011` [View](https://arbiscan.io/address/0x0f0f43B3559bE3319a63082755AD05C158D3b011#code) |
| `BalanceFuseSwapUniswapV3` | `0x43F3ca257B7e2d6BbE088B85eF2c2c57e2A3142c` [View](https://arbiscan.io/address/0x43F3ca257B7e2d6BbE088B85eF2c2c57e2A3142c#code) |
| `BalanceFuseUniversalTokenSwapper` | `0x7ceAe29f467db23210C6fDB95247355C87026eD0` [View](https://arbiscan.io/address/0x7ceAe29f467db23210C6fDB95247355C87026eD0#code) |
| `BalanceFuseUniversalTokenSwapperV2` | `0x69199E8360b3Baa536Cda2bd71dFFb30F79fBeF7` [View](https://arbiscan.io/address/0x69199E8360b3Baa536Cda2bd71dFFb30F79fBeF7#code) |
| `BalanceFuseVeloraSwapper` | `0xEb033a5c73f6Ad00b9DEb3091b205b802Ddf5bc7` [View](https://arbiscan.io/address/0xEb033a5c73f6Ad00b9DEb3091b205b802Ddf5bc7#code) |
| `BatchFuseEulerV2` | `0x91e5b36CD9070728878e733a872C2BC0AA1Fb3b5` [View](https://arbiscan.io/address/0x91e5b36CD9070728878e733a872C2BC0AA1Fb3b5#code) |
| `BorrowFuseAaveV3` | `0x28264E8b70902f6C55420EAF66AeeE12b602302E` [View](https://arbiscan.io/address/0x28264E8b70902f6C55420EAF66AeeE12b602302E#code) |
| `BorrowFuseEulerV2` | `0x10eb9B247e7Ce00F3290F66d8B5E83BfD311375F` [View](https://arbiscan.io/address/0x10eb9B247e7Ce00F3290F66d8B5E83BfD311375F#code) |
| `BurnRequestFeeFuse` | `0xee322e49268760878924d18A645278aB08Ae245c` [View](https://arbiscan.io/address/0xee322e49268760878924d18A645278aB08Ae245c#code) |
| `BurnRequestFeeFuseV2` | `0x2E8A9f5ee2438f62e77BF6298F4Ac46Ec7861D63` [View](https://arbiscan.io/address/0x2E8A9f5ee2438f62e77BF6298F4Ac46Ec7861D63#code) |
| `ClaimRewardsFuseCompoundV3` | `0xfa27F28934D3478F65bcfA158E3096045bFdb1Bd` [View](https://arbiscan.io/address/0xfa27F28934D3478F65bcfA158E3096045bFdb1Bd#code) |
| `ClaimRewardsFuseFluidInstadapp` | `0x5c7E10C4D6F65b89C026fC8df69891e6B90A8434` [View](https://arbiscan.io/address/0x5c7E10C4D6F65b89C026fC8df69891e6B90A8434#code) |
| `ClaimRewardsFuseGearboxV3FarmDToken` | `0xFa209140BBA92a64b1038649e7385fa860405099` [View](https://arbiscan.io/address/0xFa209140BBA92a64b1038649e7385fa860405099#code) |
| `ClaimRewardsFuseMorpho` | `0x8D8EF5f98E128A17B9184d81b0BA383aEe7f2374` [View](https://arbiscan.io/address/0x8D8EF5f98E128A17B9184d81b0BA383aEe7f2374#code) |
| `ClaimRewardsFuseRamsesV2` | `0x6F292d12a2966c9B796642cAFD67549bbbE3D066` [View](https://arbiscan.io/address/0x6F292d12a2966c9B796642cAFD67549bbbE3D066#code) |
| `CollateralFuseEulerV2` | `0x6D35934cB431B36338fF88641BEBF540e826bd7D` [View](https://arbiscan.io/address/0x6D35934cB431B36338fF88641BEBF540e826bd7D#code) |
| `CollateralFuseMorpho` | `0x19cc0d64bf870C179fD47d322BFB1250ce0A59dD` [View](https://arbiscan.io/address/0x19cc0d64bf870C179fD47d322BFB1250ce0A59dD#code) |
| `CollectSwapFuseRamsesV2` | `0x859F5c9D5CB2800A9Ff72C56d79323EA01cB30b9` [View](https://arbiscan.io/address/0x859F5c9D5CB2800A9Ff72C56d79323EA01cB30b9#code) |
| `CollectSwapFuseUniswapV3` | `0x75781AB6CdcE9c505DbD0848f4Ad8A97c68F53c1` [View](https://arbiscan.io/address/0x75781AB6CdcE9c505DbD0848f4Ad8A97c68F53c1#code) |
| `ConfigureInstantWithdrawalFuse` | `0x77C66a7A637D90662BDC35E2C8bBc29ef6a3264F` [View](https://arbiscan.io/address/0x77C66a7A637D90662BDC35E2C8bBc29ef6a3264F#code) |
| `ControllerFuseEulerV2` | `0x2A02Ae392816441E804aa9eCcf5c0333911Dc989` [View](https://arbiscan.io/address/0x2A02Ae392816441E804aa9eCcf5c0333911Dc989#code) |
| `ExternalStateBalanceFuse` | `0x4B5FB26C43591A13588bFE41678608E8159e20Fb` [View](https://arbiscan.io/address/0x4B5FB26C43591A13588bFE41678608E8159e20Fb#code) |
| `ExternalStateOperationFuse` | `0x4c8BA66e930B38c42696ff73cA1deE8e559c2eF2` [View](https://arbiscan.io/address/0x4c8BA66e930B38c42696ff73cA1deE8e559c2eF2#code) |
| `ExternalStateRescueFuse` | `0x5E6Cfe68008C1a8089f2c340A9cDF0536D44eB28` [View](https://arbiscan.io/address/0x5E6Cfe68008C1a8089f2c340A9cDF0536D44eB28#code) |
| `ExternalStateUnpauseFuse` | `0xb869785FD87609769D3E0510C41F03B223B0d31c` [View](https://arbiscan.io/address/0xb869785FD87609769D3E0510C41F03B223B0d31c#code) |
| `FlashloanFuseMorpho` | `0xeA36D6478CAAE9a5CDbEA0814bDe98533320d742` [View](https://arbiscan.io/address/0xeA36D6478CAAE9a5CDbEA0814bDe98533320d742#code) |
| `FusePendleRedeemPtAfterMaturity` | `0x1c1B7AcdF17b0B10c6F3a00B0a89fDBB6FDd61bF` [View](https://arbiscan.io/address/0x1c1B7AcdF17b0B10c6F3a00B0a89fDBB6FDd61bF#code) |
| `FusePendleSwapPt` | `0x31fA1E9dC753d0f565CfA9337d59A91298146244` [View](https://arbiscan.io/address/0x31fA1E9dC753d0f565CfA9337d59A91298146244#code) |
| `FuseRedeemFromRequestPlasmaVaultMarket1` | `0x4d3E8763E86Dee40B34bC21e098b26f5B9ba394d` [View](https://arbiscan.io/address/0x4d3E8763E86Dee40B34bC21e098b26f5B9ba394d#code) |
| `FuseRequestSharesPlasmaVaultMarket1` | `0xD6c4bf7Ac3AEA99Fa01532e4457202AE41A2596B` [View](https://arbiscan.io/address/0xD6c4bf7Ac3AEA99Fa01532e4457202AE41A2596B#code) |
| `FuseRequestSharesPlasmaVaultV2` | `0x023f0766Ec493fe5cC6634615df997F1396b6150` [View](https://arbiscan.io/address/0x023f0766Ec493fe5cC6634615df997F1396b6150#code) |
| `MerklClaimFuse` | `0x7db8a7A58fA64ABEfe85D90317C5F9EeeE8b7591` [View](https://arbiscan.io/address/0x7db8a7A58fA64ABEfe85D90317C5F9EeeE8b7591#code) |
| `ModifyPositionSwapFuseRamsesV2` | `0xD41501B46a68DeA06a460fD79a7bCda9e3b92674` [View](https://arbiscan.io/address/0xD41501B46a68DeA06a460fD79a7bCda9e3b92674#code) |
| `ModifyPositionSwapFuseUniswapV3` | `0xba503b6f2b95A4A47ee9884bbBcd80cAce2D2EB3` [View](https://arbiscan.io/address/0xba503b6f2b95A4A47ee9884bbBcd80cAce2D2EB3#code) |
| `NapierCollectFuse` | `0x7c5d3B9d2d76e7933aef648542CA1d9F021eE249` [View](https://arbiscan.io/address/0x7c5d3B9d2d76e7933aef648542CA1d9F021eE249#code) |
| `NapierCombineFuse` | `0xFa6E658931353Cb94965b5DbC3919ed9753e4110` [View](https://arbiscan.io/address/0xFa6E658931353Cb94965b5DbC3919ed9753e4110#code) |
| `NapierDepositFuse` | `0xCFf0E95d1B71c642739ECAAdaD25Bc428b979bd3` [View](https://arbiscan.io/address/0xCFf0E95d1B71c642739ECAAdaD25Bc428b979bd3#code) |
| `NapierRedeemFuse` | `0x24d6A0d8D428Bbb71423defD3860E9B65CAE663E` [View](https://arbiscan.io/address/0x24d6A0d8D428Bbb71423defD3860E9B65CAE663E#code) |
| `NapierSupplyFuse` | `0xD562034Efd1e29094cc370DAeaee5e76788Bd16f` [View](https://arbiscan.io/address/0xD562034Efd1e29094cc370DAeaee5e76788Bd16f#code) |
| `NapierSwapPtFuse` | `0x803c427ecEc9FDd5fe344d8e13fed0e890258172` [View](https://arbiscan.io/address/0x803c427ecEc9FDd5fe344d8e13fed0e890258172#code) |
| `NapierSwapYtFuse` | `0x96493C8458552681bDAbe3414199b21Fb3e4E084` [View](https://arbiscan.io/address/0x96493C8458552681bDAbe3414199b21Fb3e4E084#code) |
| `NapierZapDepositFuse` | `0xb3B0E2Bc08e81B1745E2a8b9F529b272C29922Ef` [View](https://arbiscan.io/address/0xb3B0E2Bc08e81B1745E2a8b9F529b272C29922Ef#code) |
| `NewPositionSwapFuseRamsesV2` | `0xb025CC5e73e2966e12e4d859360B51c1D0F45EA3` [View](https://arbiscan.io/address/0xb025CC5e73e2966e12e4d859360B51c1D0F45EA3#code) |
| `NewPositionSwapFuseUniswapV3` | `0x1DA7F95e63f12169B3495E2B83D01D0D6592DD86` [View](https://arbiscan.io/address/0x1DA7F95e63f12169B3495E2B83D01D0D6592DD86#code) |
| `OdosSwapperFuse` | `0x19eA0E29EdDe3209c34A86004957510EF3C9912e` [View](https://arbiscan.io/address/0x19eA0E29EdDe3209c34A86004957510EF3C9912e#code) |
| `PlasmaVaultBalanceAssetsValidationFuse` | `0x3232C95AaC56fB1C6d49852B57D79EdB76de8e4B` [View](https://arbiscan.io/address/0x3232C95AaC56fB1C6d49852B57D79EdB76de8e4B#code) |
| `RequestFeeRefundFuse` | `0xb5A1bb3445F5D8f9BF6de7cd81cAB1687eF31A0D` [View](https://arbiscan.io/address/0xb5A1bb3445F5D8f9BF6de7cd81cAB1687eF31A0D#code) |
| `RewardEulerTokenClaimFuse` | `0x9Ea8aFF2317793CB9f00bde40a78a33a78fE636b` [View](https://arbiscan.io/address/0x9Ea8aFF2317793CB9f00bde40a78a33a78fE636b#code) |
| `StakeDaoV2BalanceFuse` | `0x868358F70b43E23b650a11779442e048c9ec0Dd4` [View](https://arbiscan.io/address/0x868358F70b43E23b650a11779442e048c9ec0Dd4#code) |
| `StakeDaoV2ClaimFuse` | `0x9BB58bc262a4543De6136ae5FB16A80a2B111875` [View](https://arbiscan.io/address/0x9BB58bc262a4543De6136ae5FB16A80a2B111875#code) |
| `StakeDaoV2SupplyFuse` | `0x4af60343C2a6a9692559030936fBFf579c05779c` [View](https://arbiscan.io/address/0x4af60343C2a6a9692559030936fBFf579c05779c#code) |
| `SupplyFuseAaveV3` | `0x304756cD719382281fBD640f5F7932465eD663D6` [View](https://arbiscan.io/address/0x304756cD719382281fBD640f5F7932465eD663D6#code) |
| `SupplyFuseCompoundV3Usdc` | `0xB0b3dc1B27C6c8007c9B01a768d6717f6813fE94` [View](https://arbiscan.io/address/0xB0b3dc1B27C6c8007c9B01a768d6717f6813fE94#code) |
| `SupplyFuseErc4626Market1` | `0xC0C26EeB9c8BE5aa0f4e597E9BB7fDca3498E845` [View](https://arbiscan.io/address/0xC0C26EeB9c8BE5aa0f4e597E9BB7fDca3498E845#code) |
| `SupplyFuseErc4626Market2` | `0xBd0f8b717D75ecD1a304a9797946E32e00976D84` [View](https://arbiscan.io/address/0xBd0f8b717D75ecD1a304a9797946E32e00976D84#code) |
| `SupplyFuseErc4626Market3` | `0xB3aB3552c945A282DB2822029830B5097c94d80E` [View](https://arbiscan.io/address/0xB3aB3552c945A282DB2822029830B5097c94d80E#code) |
| `SupplyFuseErc4626Market4` | `0x2962bc673FF9c275DD59A4feEF3CA68c0e8A4a8f` [View](https://arbiscan.io/address/0x2962bc673FF9c275DD59A4feEF3CA68c0e8A4a8f#code) |
| `SupplyFuseErc4626Market5` | `0x2c3f01D0dEC6B2BBC375Eb263f08b7815D159cFc` [View](https://arbiscan.io/address/0x2c3f01D0dEC6B2BBC375Eb263f08b7815D159cFc#code) |
| `SupplyFuseErc4626Market6` | `0xDd0b08F4106989d2bE7b611C0EeeCD970883ed85` [View](https://arbiscan.io/address/0xDd0b08F4106989d2bE7b611C0EeeCD970883ed85#code) |
| `SupplyFuseErc4626Market7` | `0x5Da3B426f7BE5E73d8248E4f9fD409CfE03d5b99` [View](https://arbiscan.io/address/0x5Da3B426f7BE5E73d8248E4f9fD409CfE03d5b99#code) |
| `SupplyFuseEulerV2` | `0x920f6c81666877490A8D6dcFEFd85d151Ef04B7d` [View](https://arbiscan.io/address/0x920f6c81666877490A8D6dcFEFd85d151Ef04B7d#code) |
| `SupplyFuseFluidInstadappPoolFToken` | `0x4Ae8640B3A6b71Fa1a05372A59946e66bEb05F9f` [View](https://arbiscan.io/address/0x4Ae8640B3A6b71Fa1a05372A59946e66bEb05F9f#code) |
| `SupplyFuseFluidInstadappStakingRewardsFToken` | `0x2B83F05E463cbc34861b10CB020b6eB4740Bd890` [View](https://arbiscan.io/address/0x2B83F05E463cbc34861b10CB020b6eB4740Bd890#code) |
| `SupplyFuseGearboxV3DToken` | `0x07cD27531ee9dF28292B26Eeba3f457609DeAe07` [View](https://arbiscan.io/address/0x07cD27531ee9dF28292B26Eeba3f457609DeAe07#code) |
| `SupplyFuseGearboxV3FarmDToken` | `0xB0FBF6B7D0586C0a5Bc1C3b8a98773f4eD02c983` [View](https://arbiscan.io/address/0xB0FBF6B7D0586C0a5Bc1C3b8a98773f4eD02c983#code) |
| `SupplyFuseMorpho` | `0x5Ea9d92fb3975f9f9d1Fa69b98A37BF4dDe61e2a` [View](https://arbiscan.io/address/0x5Ea9d92fb3975f9f9d1Fa69b98A37BF4dDe61e2a#code) |
| `SupplyFuseMorphoLiquidityInMarkets` | `0xB9eeAe4234445Cb84e7d9f45686DCB934f21fFC9` [View](https://arbiscan.io/address/0xB9eeAe4234445Cb84e7d9f45686DCB934f21fFC9#code) |
| `SwapDeployFuseEulerV2` | `0x25bE82F7d186590A7Adb21cb7B179A75E1884D42` [View](https://arbiscan.io/address/0x25bE82F7d186590A7Adb21cb7B179A75E1884D42#code) |
| `SwapFuseUniswapV2` | `0xAdA9bF3c599DB229601dd1220D0b3CcAb6c7db84` [View](https://arbiscan.io/address/0xAdA9bF3c599DB229601dd1220D0b3CcAb6c7db84#code) |
| `SwapFuseUniswapV3` | `0x84C5aB008C66d664681698A9E4536D942B916F89` [View](https://arbiscan.io/address/0x84C5aB008C66d664681698A9E4536D942B916F89#code) |
| `SwapFuseUniversalTokenSwapper` | `0xB052b0D983E493B4D40DeC75A03D21b70b83c2ca` [View](https://arbiscan.io/address/0xB052b0D983E493B4D40DeC75A03D21b70b83c2ca#code) |
| `SwapFuseUniversalTokenSwapperEth` | `0xd43a359890072D1b3939366e612D7FA0C7DDdB32` [View](https://arbiscan.io/address/0xd43a359890072D1b3939366e612D7FA0C7DDdB32#code) |
| `SwapFuseUniversalTokenSwapperEthNoSlippage` | `0x6f6C1bB7526B2aeeefe2f5Afb402CE7fDf5f4d9A` [View](https://arbiscan.io/address/0x6f6C1bB7526B2aeeefe2f5Afb402CE7fDf5f4d9A#code) |
| `SwapFuseUniversalTokenSwapperEthNoSlippageV2` | `0xa3743Aa7085F6D4A5e22D7779649bF6b35e47fB6` [View](https://arbiscan.io/address/0xa3743Aa7085F6D4A5e22D7779649bF6b35e47fB6#code) |
| `SwapFuseUniversalTokenSwapperWithVerification` | `0x64D077CD727937E5A4861A2695C2C9AD65EED700` [View](https://arbiscan.io/address/0x64D077CD727937E5A4861A2695C2C9AD65EED700#code) |
| `SwapFuseUniversalTokenSwapperWithVerificationV2` | `0x717D1B12931F739292bF10ef7b22B732091D1Da6` [View](https://arbiscan.io/address/0x717D1B12931F739292bF10ef7b22B732091D1Da6#code) |
| `SwapReconfigureFuseEulerV2` | `0xC650f5b5f7785C925D70C6544B78f1b437b1C255` [View](https://arbiscan.io/address/0xC650f5b5f7785C925D70C6544B78f1b437b1C255#code) |
| `SwapRegistryFuseEulerV2` | `0x833A68A4bB4e0eb93130FcdbCAaac51b65ebeD0C` [View](https://arbiscan.io/address/0x833A68A4bB4e0eb93130FcdbCAaac51b65ebeD0C#code) |
| `UniversalReaderBalanceFuses` | `0xacDB88ea2E2D248369b5b3137Fc3f971543d706c` [View](https://arbiscan.io/address/0xacDB88ea2E2D248369b5b3137Fc3f971543d706c#code) |
| `UniversalTokenSwapperEthFuse` | `0xE53D515D7Dd5e4788a90607400FA8906Be494a28` [View](https://arbiscan.io/address/0xE53D515D7Dd5e4788a90607400FA8906Be494a28#code) |
| `UniversalTokenSwapperEthFuseV2` | `0x9D06578238713a08A1ece595AAb6188FAEE32b25` [View](https://arbiscan.io/address/0x9D06578238713a08A1ece595AAb6188FAEE32b25#code) |
| `UniversalTokenSwapperFuse` | `0x9Dab5e11Ece5470F9782C9BC818C519f730eE854` [View](https://arbiscan.io/address/0x9Dab5e11Ece5470F9782C9BC818C519f730eE854#code) |
| `UniversalTokenSwapperFuseV2` | `0x799b979A2377268ac2D5E43247cbd6F797229Ef3` [View](https://arbiscan.io/address/0x799b979A2377268ac2D5E43247cbd6F797229Ef3#code) |
| `VeloraSwapperFuse` | `0x922000aF6ac6659B3b6945E933B706B52453A531` [View](https://arbiscan.io/address/0x922000aF6ac6659B3b6945E933B706B52453A531#code) |
| `ZeroBalanceFuseNapier` | `0x31024FC8C4F4Eb64081DAAD5Ee6e1D1CBaEE051C` [View](https://arbiscan.io/address/0x31024FC8C4F4Eb64081DAAD5Ee6e1D1CBaEE051C#code) |

#### Arbitrum Older Fuses Versions

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `BalanceFuseEulerV2` | `0x654Ee0c6d477A4ddFE62f600Ed52134593c1733c` [View](https://arbiscan.io/address/0x654Ee0c6d477A4ddFE62f600Ed52134593c1733c#code) |
| `BorrowFuseEulerV2` | `0xe436decF5a8D7004338833555ee3970B24a9f47F` [View](https://arbiscan.io/address/0xe436decF5a8D7004338833555ee3970B24a9f47F#code) |
| `BurnRequestFeeFuse` | `0x292711bC63184318294593C38Ad914AcfCd1797B` [View](https://arbiscan.io/address/0x292711bC63184318294593C38Ad914AcfCd1797B#code) |
| `CollateralFuseEulerV2` | `0x4567EE5D7D531f2e09DA915d95c8c7bb0c2b1459` [View](https://arbiscan.io/address/0x4567EE5D7D531f2e09DA915d95c8c7bb0c2b1459#code) |
| `ControllerFuseEulerV2` | `0xc27E938FCA53E3f5fE5deb9141033573048a22B4` [View](https://arbiscan.io/address/0xc27E938FCA53E3f5fE5deb9141033573048a22B4#code) |
| `RewardEulerTokenClaimFuse` | `0x5b74A646Ce1D8AF41dbFd21D4c7C52Cf184DfCd6` [View](https://arbiscan.io/address/0x5b74A646Ce1D8AF41dbFd21D4c7C52Cf184DfCd6#code) |
| `StakeDaoV2SupplyFuse` | `0x588a48916262f726eFdB59200658829a4a6AB252` [View](https://arbiscan.io/address/0x588a48916262f726eFdB59200658829a4a6AB252#code) |
| `SupplyFuseAaveV3` | `0x9339acD4e73C8a11109f77bC87221bDfC7b7A4FC` [View](https://arbiscan.io/address/0x9339acD4e73C8a11109f77bC87221bDfC7b7A4FC#code) |
| `SupplyFuseErc4626Market1` | `0xe7d3a550F0aD32cCBEF570C670b5ac004C276f24` [View](https://arbiscan.io/address/0xe7d3a550F0aD32cCBEF570C670b5ac004C276f24#code) |
| `SupplyFuseErc4626Market2` | `0xBA4e51A46b562cBaEF372C07bF191c7111a067aA` [View](https://arbiscan.io/address/0xBA4e51A46b562cBaEF372C07bF191c7111a067aA#code) |
| `SupplyFuseErc4626Market3` | `0xF5c5E375d219e573B10f9c90A1815f93951AD275` [View](https://arbiscan.io/address/0xF5c5E375d219e573B10f9c90A1815f93951AD275#code) |
| `SupplyFuseErc4626Market4` | `0x2f34F8566952b055F3Cc32ACB8b9C8203E91132A` [View](https://arbiscan.io/address/0x2f34F8566952b055F3Cc32ACB8b9C8203E91132A#code) |
| `SupplyFuseErc4626Market5` | `0x28eE4cD5E888f6331B6c6c38959bBBE05eF7D73A` [View](https://arbiscan.io/address/0x28eE4cD5E888f6331B6c6c38959bBBE05eF7D73A#code) |
| `SupplyFuseErc4626Market6` | `0x0dE665bb75556ea407C23b513A5d521064245b3e` [View](https://arbiscan.io/address/0x0dE665bb75556ea407C23b513A5d521064245b3e#code) |
| `SupplyFuseErc4626Market7` | `0x624E2AB4E17aA38B078674eec75dbadcc10e295B` [View](https://arbiscan.io/address/0x624E2AB4E17aA38B078674eec75dbadcc10e295B#code) |
| `SupplyFuseEulerV2` | `0x96A29E00C13A3e23f91259364F118501e1a46344` [View](https://arbiscan.io/address/0x96A29E00C13A3e23f91259364F118501e1a46344#code) |
| `SupplyFuseEulerV2` | `0x371718ca5cf78A2C8fD2f44Ec2CE88363481B2D3` [View](https://arbiscan.io/address/0x371718ca5cf78A2C8fD2f44Ec2CE88363481B2D3#code) |

### Base Fuses

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `AaveV3WithPriceOracleMiddlewareBalanceFuse` | `0x952573Ec1B6895a88a95CA523097083d4da4D8e5` [View](https://basescan.org/address/0x952573Ec1B6895a88a95CA523097083d4da4D8e5#code) |
| `AsyncActionBalanceFuse` | `0x89a204AA373a56B02ABAd265BEa12B70C4f2a142` [View](https://basescan.org/address/0x89a204AA373a56B02ABAd265BEa12B70C4f2a142#code) |
| `AsyncActionFuse` | `0xF328E4e84446CF5400F9baf1482E939F88A9E460` [View](https://basescan.org/address/0xF328E4e84446CF5400F9baf1482E939F88A9E460#code) |
| `BalanceFuseAaveV3` | `0xf53f3EaFfDf67539256365cA7299540A98b60BA9` [View](https://basescan.org/address/0xf53f3EaFfDf67539256365cA7299540A98b60BA9#code) |
| `BalanceFuseAaveV4` | `0xB327aD8cB8Ff597C707790335638B62773a04c36` [View](https://basescan.org/address/0xB327aD8cB8Ff597C707790335638B62773a04c36#code) |
| `BalanceFuseAerodrome` | `0xDBBE09c09FCE1B841fE46Ac6b06e2a4F8128c838` [View](https://basescan.org/address/0xDBBE09c09FCE1B841fE46Ac6b06e2a4F8128c838#code) |
| `BalanceFuseAerodromeSlipstream` | `0x3075a82e51e3Ef3990656e4B3829507FB5275B53` [View](https://basescan.org/address/0x3075a82e51e3Ef3990656e4B3829507FB5275B53#code) |
| `BalanceFuseBurnRequestFee` | `0x341D2459606FEB164A986767cB72Ddd8230744Fe` [View](https://basescan.org/address/0x341D2459606FEB164A986767cB72Ddd8230744Fe#code) |
| `BalanceFuseCompoundV3Usdc` | `0x62286efb801ae4eE93733c3bc1bFA0746e5103D8` [View](https://basescan.org/address/0x62286efb801ae4eE93733c3bc1bFA0746e5103D8#code) |
| `BalanceFuseCompoundV3WEth` | `0x88810B5066A92d628A1Cb59A1902bc607eeb8C1B` [View](https://basescan.org/address/0x88810B5066A92d628A1Cb59A1902bc607eeb8C1B#code) |
| `BalanceFuseErc20` | `0x9ba147FC382DBf4D73512A45370ba0B70c25F6aa` [View](https://basescan.org/address/0x9ba147FC382DBf4D73512A45370ba0B70c25F6aa#code) |
| `BalanceFuseErc4626Market1` | `0x7F4D9EFdE7EfEBBAFbb506ca3f711764cBc96391` [View](https://basescan.org/address/0x7F4D9EFdE7EfEBBAFbb506ca3f711764cBc96391#code) |
| `BalanceFuseErc4626Market10` | `0xE1725cC2AF00941Db5847a59B4aA8bF47AD35bDF` [View](https://basescan.org/address/0xE1725cC2AF00941Db5847a59B4aA8bF47AD35bDF#code) |
| `BalanceFuseErc4626Market11` | `0x9332dafA9376b7E049755FD81B01B23fC772B8A6` [View](https://basescan.org/address/0x9332dafA9376b7E049755FD81B01B23fC772B8A6#code) |
| `BalanceFuseErc4626Market12` | `0x5f565d142815Eb430ab14bC9bdA9D12C9fCa3C6c` [View](https://basescan.org/address/0x5f565d142815Eb430ab14bC9bdA9D12C9fCa3C6c#code) |
| `BalanceFuseErc4626Market13` | `0x44B13c4af19D97af4dA32c46b533C3e632000bf8` [View](https://basescan.org/address/0x44B13c4af19D97af4dA32c46b533C3e632000bf8#code) |
| `BalanceFuseErc4626Market14` | `0x4b69AC30feDDd922eb26adB30713984d5fb0e972` [View](https://basescan.org/address/0x4b69AC30feDDd922eb26adB30713984d5fb0e972#code) |
| `BalanceFuseErc4626Market2` | `0x3Dfe25F60191AAee4213080398D2Fdf65EC3CF2F` [View](https://basescan.org/address/0x3Dfe25F60191AAee4213080398D2Fdf65EC3CF2F#code) |
| `BalanceFuseErc4626Market3` | `0xfEe84b6AF26a481C1819655dAde5f5588416e19f` [View](https://basescan.org/address/0xfEe84b6AF26a481C1819655dAde5f5588416e19f#code) |
| `BalanceFuseErc4626Market4` | `0x903c1ABb5A303Cf717196e8d12CE87F46dE56719` [View](https://basescan.org/address/0x903c1ABb5A303Cf717196e8d12CE87F46dE56719#code) |
| `BalanceFuseErc4626Market5` | `0xE017C7326d371828a6877727e46A203e915AF0fD` [View](https://basescan.org/address/0xE017C7326d371828a6877727e46A203e915AF0fD#code) |
| `BalanceFuseErc4626Market6` | `0xc8C0498e36a4f26744E8222C8749cd0143F6E6EB` [View](https://basescan.org/address/0xc8C0498e36a4f26744E8222C8749cd0143F6E6EB#code) |
| `BalanceFuseErc4626Market7` | `0xC5d840B15B8DcE3F38989F4bE9f42a9308Ed8FCe` [View](https://basescan.org/address/0xC5d840B15B8DcE3F38989F4bE9f42a9308Ed8FCe#code) |
| `BalanceFuseErc4626Market8` | `0x684b5c8866AaDE4E21f8A30697A56A805B108a67` [View](https://basescan.org/address/0x684b5c8866AaDE4E21f8A30697A56A805B108a67#code) |
| `BalanceFuseErc4626Market9` | `0x32b8389d5Cc5E50221C9a127aE2B47968919FD74` [View](https://basescan.org/address/0x32b8389d5Cc5E50221C9a127aE2B47968919FD74#code) |
| `BalanceFuseEulerV2` | `0xF8A6AA09bB55f2319113b0DA88883F392e66A5fa` [View](https://basescan.org/address/0xF8A6AA09bB55f2319113b0DA88883F392e66A5fa#code) |
| `BalanceFuseFlashLoanMorpho` | `0x2Ce01779CfE56DC253D0Ac1b47E3bb7E597bCaEA` [View](https://basescan.org/address/0x2Ce01779CfE56DC253D0Ac1b47E3bb7E597bCaEA#code) |
| `BalanceFuseFluidInstadappPoolFToken` | `0xC80e5a95540d6ebFE4970A0743E71C639DF8C25e` [View](https://basescan.org/address/0xC80e5a95540d6ebFE4970A0743E71C639DF8C25e#code) |
| `BalanceFuseFluidInstadappStakingRewardsFToken` | `0x29d294d3d8Bb422ddDc925Cb95a903d34eEB208A` [View](https://basescan.org/address/0x29d294d3d8Bb422ddDc925Cb95a903d34eEB208A#code) |
| `BalanceFuseMetaMorphoMarket0001` | `0xf760384518C9157B82CDC4ecb0f53799970728d9` [View](https://basescan.org/address/0xf760384518C9157B82CDC4ecb0f53799970728d9#code) |
| `BalanceFuseMoonwell` | `0x86417B0B3B03e8BC8b68377994363796b4ccD3Bc` [View](https://basescan.org/address/0x86417B0B3B03e8BC8b68377994363796b4ccD3Bc#code) |
| `BalanceFuseMorpho` | `0x7916856E11E0CA021967D0D4daC49D737b7d73d5` [View](https://basescan.org/address/0x7916856E11E0CA021967D0D4daC49D737b7d73d5#code) |
| `BalanceFuseMorphoLiquidityInMarkets` | `0x89d8b9a7E00cCea1C6d8f71D6a80708E1B211d20` [View](https://basescan.org/address/0x89d8b9a7E00cCea1C6d8f71D6a80708E1B211d20#code) |
| `BalanceFuseOdosSwapper` | `0x758524777B2a6eC40097eA442ca8e1BBaBc137b6` [View](https://basescan.org/address/0x758524777B2a6eC40097eA442ca8e1BBaBc137b6#code) |
| `BalanceFusePendle` | `0xc8A552BF7279a932b9fCA8F527Ef292083c5B87f` [View](https://basescan.org/address/0xc8A552BF7279a932b9fCA8F527Ef292083c5B87f#code) |
| `BalanceFuseSwapPositionsUniswapV3` | `0x9c84c1A708eB8FfE699d7c2a81eC00b028ac3aac` [View](https://basescan.org/address/0x9c84c1A708eB8FfE699d7c2a81eC00b028ac3aac#code) |
| `BalanceFuseSwapUniswapV3` | `0x5F169161227F92D6FBb691Ea1e4e89ea3fed24B3` [View](https://basescan.org/address/0x5F169161227F92D6FBb691Ea1e4e89ea3fed24B3#code) |
| `BalanceFuseUniswapV4` | `0x95c54602EA008E1f2568E7559C579d868F54a74a` [View](https://basescan.org/address/0x95c54602EA008E1f2568E7559C579d868F54a74a#code) |
| `BalanceFuseUniversalTokenSwapper` | `0x706ca1cA4EcE9CF23301D6AB35ce6fb7Cf25DA15` [View](https://basescan.org/address/0x706ca1cA4EcE9CF23301D6AB35ce6fb7Cf25DA15#code) |
| `BalanceFuseUniversalTokenSwapperV2` | `0x0A48e903d7502dCe596d3a101F9932Be39C2ccd0` [View](https://basescan.org/address/0x0A48e903d7502dCe596d3a101F9932Be39C2ccd0#code) |
| `BalanceFuseVeloraSwapper` | `0xE4a973828ee730A3fdb3a5D470263E54f97d9aDF` [View](https://basescan.org/address/0xE4a973828ee730A3fdb3a5D470263E54f97d9aDF#code) |
| `BatchFuseEulerV2` | `0x60CE35e58f6CEd1538c16A15FF7fF75B0538898F` [View](https://basescan.org/address/0x60CE35e58f6CEd1538c16A15FF7fF75B0538898F#code) |
| `BorrowFuseAaveV3` | `0x1Df60F2A046F3Dce8102427e091C1Ea99aE1d774` [View](https://basescan.org/address/0x1Df60F2A046F3Dce8102427e091C1Ea99aE1d774#code) |
| `BorrowFuseAaveV4` | `0x7F59b45ea6D504024567969446fE0f7713c31331` [View](https://basescan.org/address/0x7F59b45ea6D504024567969446fE0f7713c31331#code) |
| `BorrowFuseEulerV2` | `0x906496F0D4C733275F892b1a6fC92eD56639B379` [View](https://basescan.org/address/0x906496F0D4C733275F892b1a6fC92eD56639B379#code) |
| `BorrowFuseMoonwell` | `0x377a5B195E3C074d982BD7bAC66B48D4C3006353` [View](https://basescan.org/address/0x377a5B195E3C074d982BD7bAC66B48D4C3006353#code) |
| `BorrowFuseMorpho` | `0x35f44aD1D9F2773dA05F4664bf574C760bA47bf6` [View](https://basescan.org/address/0x35f44aD1D9F2773dA05F4664bf574C760bA47bf6#code) |
| `BurnRequestFeeFuse` | `0x8Aad082F04d04d1dB2e92160bAa630e31C22C073` [View](https://basescan.org/address/0x8Aad082F04d04d1dB2e92160bAa630e31C22C073#code) |
| `BurnRequestFeeFuseV2` | `0x7f80241a2b8dA1e11b96B5749991e9A9a40b62a9` [View](https://basescan.org/address/0x7f80241a2b8dA1e11b96B5749991e9A9a40b62a9#code) |
| `CLGaugeFuseAerodromeSlipstream` | `0x399599ac1807eb7F6eE6499a1EBc2BA68e01A21A` [View](https://basescan.org/address/0x399599ac1807eb7F6eE6499a1EBc2BA68e01A21A#code) |
| `ClaimFeesFuseAerodrome` | `0xF16899fC66c099481d9d140f4EC4bB8619e001dE` [View](https://basescan.org/address/0xF16899fC66c099481d9d140f4EC4bB8619e001dE#code) |
| `ClaimRewardsFuseCompoundV3` | `0x10de4b8aa7c363999769F8a8295F4F091a77DF4F` [View](https://basescan.org/address/0x10de4b8aa7c363999769F8a8295F4F091a77DF4F#code) |
| `ClaimRewardsFuseFluidInstadapp` | `0x4E3139528EBA9B85addf1b7E5c36002b7bE8c9B2` [View](https://basescan.org/address/0x4E3139528EBA9B85addf1b7E5c36002b7bE8c9B2#code) |
| `ClaimRewardsFuseFluidProof` | `0xB002337C59a4133e328D91ed82C5012472952c6f` [View](https://basescan.org/address/0xB002337C59a4133e328D91ed82C5012472952c6f#code) |
| `ClaimRewardsFuseMoonwell` | `0xd253C5C54248433C7879aC14Fb03201e008C5a1e` [View](https://basescan.org/address/0xd253C5C54248433C7879aC14Fb03201e008C5a1e#code) |
| `ClaimRewardsFuseMorpho` | `0x26C740247FC4E1462D4C36e90057cf0e168B3B2B` [View](https://basescan.org/address/0x26C740247FC4E1462D4C36e90057cf0e168B3B2B#code) |
| `ClaimRewardsGaugeFuseAerodrome` | `0x91ad48aE378D70586703cD2E525e96563039825e` [View](https://basescan.org/address/0x91ad48aE378D70586703cD2E525e96563039825e#code) |
| `ClaimRewardsGaugeFuseAerodromeSlipstream` | `0xD7B15C06CE4Cc807Ea0510B862407BB680C95344` [View](https://basescan.org/address/0xD7B15C06CE4Cc807Ea0510B862407BB680C95344#code) |
| `CollateralFuseAaveV4` | `0x30873e897e78947A6834dC784fc7C5a0AbD7b0Fc` [View](https://basescan.org/address/0x30873e897e78947A6834dC784fc7C5a0AbD7b0Fc#code) |
| `CollateralFuseEulerV2` | `0x12c479f8aB53D4884fc76F803dD24eb8B6D17a94` [View](https://basescan.org/address/0x12c479f8aB53D4884fc76F803dD24eb8B6D17a94#code) |
| `CollateralFuseMorpho` | `0xDE3FD3A25534471e92C5940d418B0582802b17B6` [View](https://basescan.org/address/0xDE3FD3A25534471e92C5940d418B0582802b17B6#code) |
| `CollectFuseAerodromeSlipstream` | `0x67442EDed8f704b4E1330219D96E6B20F4FB280a` [View](https://basescan.org/address/0x67442EDed8f704b4E1330219D96E6B20F4FB280a#code) |
| `CollectFuseUniswapV4` | `0xcd1C07BD9F1a0b746e549ea21B94299F648D8d85` [View](https://basescan.org/address/0xcd1C07BD9F1a0b746e549ea21B94299F648D8d85#code) |
| `CollectSwapFuseUniswapV3` | `0xf13D892786aE580D1B300d378a654553c2F226De` [View](https://basescan.org/address/0xf13D892786aE580D1B300d378a654553c2F226De#code) |
| `ConfigureInstantWithdrawalFuse` | `0xE37D4448Cc6BcFC934d80220D076c874ADaB1CCa` [View](https://basescan.org/address/0xE37D4448Cc6BcFC934d80220D076c874ADaB1CCa#code) |
| `ControllerFuseEulerV2` | `0x108c8cFB9e00681FfA1fa3b654937E8b3BCd2E64` [View](https://basescan.org/address/0x108c8cFB9e00681FfA1fa3b654937E8b3BCd2E64#code) |
| `EnableMarketFuseMoonwell` | `0xD62542Ef1ABFF0ac71A1b5666CB76801e81104Ef` [View](https://basescan.org/address/0xD62542Ef1ABFF0ac71A1b5666CB76801e81104Ef#code) |
| `ExternalStateBalanceFuse` | `0xCDEb32ACF766587b5Eac9dbfB875145ec05E3517` [View](https://basescan.org/address/0xCDEb32ACF766587b5Eac9dbfB875145ec05E3517#code) |
| `ExternalStateOperationFuse` | `0x01f05736B79C7abcFbeeCe76B1C27e54f7A07D03` [View](https://basescan.org/address/0x01f05736B79C7abcFbeeCe76B1C27e54f7A07D03#code) |
| `ExternalStateRescueFuse` | `0x0Dc6A02aD1f755Ab4543cd0D40B152bf4Cf1ED64` [View](https://basescan.org/address/0x0Dc6A02aD1f755Ab4543cd0D40B152bf4Cf1ED64#code) |
| `ExternalStateUnpauseFuse` | `0x1EE42996A2D3A076c904f046b3366263D6bDB5eE` [View](https://basescan.org/address/0x1EE42996A2D3A076c904f046b3366263D6bDB5eE#code) |
| `FlashloanFuseMorpho` | `0x20f305Ce4fC12F9171Fcd7C2fBcD7D11f6119265` [View](https://basescan.org/address/0x20f305Ce4fC12F9171Fcd7C2fBcD7D11f6119265#code) |
| `FusePendleRedeemPtAfterMaturity` | `0xE59e63565d1fD5186765EBE3302C24b72C6f2EeA` [View](https://basescan.org/address/0xE59e63565d1fD5186765EBE3302C24b72C6f2EeA#code) |
| `FusePendleSwapPt` | `0x3C715eE10C1cb2c565Fd13E35d81Df1C986eeF76` [View](https://basescan.org/address/0x3C715eE10C1cb2c565Fd13E35d81Df1C986eeF76#code) |
| `FuseRedeemFromRequestPlasmaVaultMarket1` | `0x07c547bcc5f7e66333C259B3f8938a4049aa44DF` [View](https://basescan.org/address/0x07c547bcc5f7e66333C259B3f8938a4049aa44DF#code) |
| `FuseRequestSharesPlasmaVaultMarket1` | `0xEf40141EA3263004D398136FF9EB75E5d6743C09` [View](https://basescan.org/address/0xEf40141EA3263004D398136FF9EB75E5d6743C09#code) |
| `FuseRequestSharesPlasmaVaultV2` | `0xE14a69438DAA58cA2dbf70b74e10626AA39c616b` [View](https://basescan.org/address/0xE14a69438DAA58cA2dbf70b74e10626AA39c616b#code) |
| `GaugeFuseAerodrome` | `0x4360119C77b464dea3E8f18D8274cadA8D8e04C8` [View](https://basescan.org/address/0x4360119C77b464dea3E8f18D8274cadA8D8e04C8#code) |
| `LiquidityFuseAerodrome` | `0x277fFc9D4905Ee60C447f9E7da944ebbbD36C275` [View](https://basescan.org/address/0x277fFc9D4905Ee60C447f9E7da944ebbbD36C275#code) |
| `MerklClaimFuse` | `0x310e6133a904761D717EE13D76E180E4EECf907A` [View](https://basescan.org/address/0x310e6133a904761D717EE13D76E180E4EECf907A#code) |
| `MerklClaimWrapperFuse` | `0xb1c12A239a72ee518A065dA79E62dAE97Cb21A5B` [View](https://basescan.org/address/0xb1c12A239a72ee518A065dA79E62dAE97Cb21A5B#code) |
| `MidasBalanceFuse` | `0x62EC84e9bbd97342a8493365Ecf7329f89EF7Ee4` [View](https://basescan.org/address/0x62EC84e9bbd97342a8493365Ecf7329f89EF7Ee4#code) |
| `MidasClaimFromExecutorFuse` | `0xefc57105d0595FC44E241E2aD7D8E9d20d6Fa5d5` [View](https://basescan.org/address/0xefc57105d0595FC44E241E2aD7D8E9d20d6Fa5d5#code) |
| `MidasRequestSupplyFuse` | `0xe83697362D91af8f505E3E693F2847A30CD81A8E` [View](https://basescan.org/address/0xe83697362D91af8f505E3E693F2847A30CD81A8E#code) |
| `MidasSupplyFuse` | `0xa0417653A69503D7Abd838cc601172720893f9f1` [View](https://basescan.org/address/0xa0417653A69503D7Abd838cc601172720893f9f1#code) |
| `ModifyPositionFuseUniswapV4` | `0x77D7a1896e2Cebe25b2BDe13280A858F1573F111` [View](https://basescan.org/address/0x77D7a1896e2Cebe25b2BDe13280A858F1573F111#code) |
| `ModifyPositionSwapFuseUniswapV3` | `0x3978b49f991949cA453601656EE97e8339f56da3` [View](https://basescan.org/address/0x3978b49f991949cA453601656EE97e8339f56da3#code) |
| `ModifyPossitionFuseAerodromeSlipstream` | `0xBb60dC9da146617A3E9101D47dc9326D6D3FaF30` [View](https://basescan.org/address/0xBb60dC9da146617A3E9101D47dc9326D6D3FaF30#code) |
| `NewPositionFuseAerodromeSlipstream` | `0xB6A36F64aa10FFC8B6220C2f47c06670c18bAc5d` [View](https://basescan.org/address/0xB6A36F64aa10FFC8B6220C2f47c06670c18bAc5d#code) |
| `NewPositionFuseUniswapV4` | `0x19B207dDeDD987d768AF903dB74ac5C649a3df08` [View](https://basescan.org/address/0x19B207dDeDD987d768AF903dB74ac5C649a3df08#code) |
| `NewPositionSwapFuseUniswapV3` | `0x08C0F62E19a66800EdD2e8eBfeE02EDc912D510a` [View](https://basescan.org/address/0x08C0F62E19a66800EdD2e8eBfeE02EDc912D510a#code) |
| `OdosSwapperFuse` | `0xC081477E9933Bf44B25607018f2573FdCA496E19` [View](https://basescan.org/address/0xC081477E9933Bf44B25607018f2573FdCA496E19#code) |
| `RepayWithATokensFuseAaveV3` | `0x8330D7e3a2690A3D69E6FD39c70691aBB62D27A4` [View](https://basescan.org/address/0x8330D7e3a2690A3D69E6FD39c70691aBB62D27A4#code) |
| `RequestFeeRefundFuse` | `0x00b6bdCf8fe1D43082Ce09eaEC4695ebf80c831B` [View](https://basescan.org/address/0x00b6bdCf8fe1D43082Ce09eaEC4695ebf80c831B#code) |
| `RewardEulerTokenClaimFuse` | `0xf61f502b01Aa184701d593AE3444E00781680789` [View](https://basescan.org/address/0xf61f502b01Aa184701d593AE3444E00781680789#code) |
| `SupplyFuseAaveV3` | `0x26fD6EF391E98C78CfCA27e00c3d15be4D941625` [View](https://basescan.org/address/0x26fD6EF391E98C78CfCA27e00c3d15be4D941625#code) |
| `SupplyFuseAaveV4` | `0xCd416C41a2AC597cB0DB4AA561cEF33553bCA3B0` [View](https://basescan.org/address/0xCd416C41a2AC597cB0DB4AA561cEF33553bCA3B0#code) |
| `SupplyFuseCompoundV3Usdc` | `0x42FBD4D8f578b902Ed9030BF9035A606dDECa26f` [View](https://basescan.org/address/0x42FBD4D8f578b902Ed9030BF9035A606dDECa26f#code) |
| `SupplyFuseCompoundV3WEth` | `0xD72Dd19C04362488a4143F43e407ec87A849b72b` [View](https://basescan.org/address/0xD72Dd19C04362488a4143F43e407ec87A849b72b#code) |
| `SupplyFuseErc4626Market1` | `0xc45d1676514fcB39BC3B9F74a08985242545FAAd` [View](https://basescan.org/address/0xc45d1676514fcB39BC3B9F74a08985242545FAAd#code) |
| `SupplyFuseErc4626Market10` | `0xf8Bc79A9B0B3cbc2C34822e6BE33c6aB0b398bb0` [View](https://basescan.org/address/0xf8Bc79A9B0B3cbc2C34822e6BE33c6aB0b398bb0#code) |
| `SupplyFuseErc4626Market11` | `0x60a657a9E14aFFd550fD52A0Dd064a1Bfe7a6B69` [View](https://basescan.org/address/0x60a657a9E14aFFd550fD52A0Dd064a1Bfe7a6B69#code) |
| `SupplyFuseErc4626Market12` | `0xf4826d42bA4b5a51F9eF224694a0456071BD5AFF` [View](https://basescan.org/address/0xf4826d42bA4b5a51F9eF224694a0456071BD5AFF#code) |
| `SupplyFuseErc4626Market13` | `0x65aC03D3c899B00E815d26d43746E55671Ff4D21` [View](https://basescan.org/address/0x65aC03D3c899B00E815d26d43746E55671Ff4D21#code) |
| `SupplyFuseErc4626Market14` | `0xbf3B3182ad09c79fF63c2623A3811F3B9652Be04` [View](https://basescan.org/address/0xbf3B3182ad09c79fF63c2623A3811F3B9652Be04#code) |
| `SupplyFuseErc4626Market2` | `0x872e1eF7aEf0f93a7b1268504AcdD8690321d4D4` [View](https://basescan.org/address/0x872e1eF7aEf0f93a7b1268504AcdD8690321d4D4#code) |
| `SupplyFuseErc4626Market3` | `0x3E7b814Ab88774b8c7070Bd86BD34d979a8C0dDE` [View](https://basescan.org/address/0x3E7b814Ab88774b8c7070Bd86BD34d979a8C0dDE#code) |
| `SupplyFuseErc4626Market4` | `0x0108FDaC9360F531fC208d56A02F88352FCFc434` [View](https://basescan.org/address/0x0108FDaC9360F531fC208d56A02F88352FCFc434#code) |
| `SupplyFuseErc4626Market5` | `0xCa79f613F189dF56bEe39f7993E16527CaDeff7f` [View](https://basescan.org/address/0xCa79f613F189dF56bEe39f7993E16527CaDeff7f#code) |
| `SupplyFuseErc4626Market6` | `0x2952D8badce956d384562bC894dA2F0DbC013505` [View](https://basescan.org/address/0x2952D8badce956d384562bC894dA2F0DbC013505#code) |
| `SupplyFuseErc4626Market7` | `0x18824Ccb0C3BD299c053Ce7b20232A54897eBa7f` [View](https://basescan.org/address/0x18824Ccb0C3BD299c053Ce7b20232A54897eBa7f#code) |
| `SupplyFuseErc4626Market8` | `0xb9fBD5230C8b7fb13C403aba9515EC853FdEE7F0` [View](https://basescan.org/address/0xb9fBD5230C8b7fb13C403aba9515EC853FdEE7F0#code) |
| `SupplyFuseErc4626Market9` | `0xdD6D29D3CE44d3F7Aa8836914eB7DB7F38C3EeB1` [View](https://basescan.org/address/0xdD6D29D3CE44d3F7Aa8836914eB7DB7F38C3EeB1#code) |
| `SupplyFuseEulerV2` | `0x598326fcEDE2C1B8E9023a20C18FFf6Dea5306A4` [View](https://basescan.org/address/0x598326fcEDE2C1B8E9023a20C18FFf6Dea5306A4#code) |
| `SupplyFuseFluidInstadappPoolFToken` | `0x15A1e2950dA9Ec0DA69a704b8940F01BdDdE86Ab` [View](https://basescan.org/address/0x15A1e2950dA9Ec0DA69a704b8940F01BdDdE86Ab#code) |
| `SupplyFuseFluidInstadappStakingRewardsFToken` | `0x977e318676158A7695cCFeB00eC18a68c29BF0EF` [View](https://basescan.org/address/0x977e318676158A7695cCFeB00eC18a68c29BF0EF#code) |
| `SupplyFuseMetaMorphoMarket0001` | `0x33Ed640Fc033A9BBE96c8469D1f32b106a4Ae8C9` [View](https://basescan.org/address/0x33Ed640Fc033A9BBE96c8469D1f32b106a4Ae8C9#code) |
| `SupplyFuseMoonwell` | `0xC4a62Bd86dB7dd61a875611b2220f9ab6e14FFbf` [View](https://basescan.org/address/0xC4a62Bd86dB7dd61a875611b2220f9ab6e14FFbf#code) |
| `SupplyFuseMorpho` | `0xae93EF3cf337b9599F0dfC12520c3C281637410F` [View](https://basescan.org/address/0xae93EF3cf337b9599F0dfC12520c3C281637410F#code) |
| `SupplyFuseMorphoLiquidityInMarkets` | `0xd4254b16d21205572e060A20CccDCFC616d5ab79` [View](https://basescan.org/address/0xd4254b16d21205572e060A20CccDCFC616d5ab79#code) |
| `SwapDeployFuseEulerV2` | `0x0Db8d3fD81900FF95ca25D7bc30a4DA1b289E670` [View](https://basescan.org/address/0x0Db8d3fD81900FF95ca25D7bc30a4DA1b289E670#code) |
| `SwapFuseUniswapV3` | `0x6C65F2155bb8730E1768558f2679eBB04d957145` [View](https://basescan.org/address/0x6C65F2155bb8730E1768558f2679eBB04d957145#code) |
| `SwapFuseUniversalTokenSwapper` | `0xdBc5f9962CE85749F1b3c51BA0473909229E3807` [View](https://basescan.org/address/0xdBc5f9962CE85749F1b3c51BA0473909229E3807#code) |
| `SwapFuseUniversalTokenSwapperEth` | `0x1DC6eC62bD4225Ec063049238CeF89635cdbff72` [View](https://basescan.org/address/0x1DC6eC62bD4225Ec063049238CeF89635cdbff72#code) |
| `SwapFuseUniversalTokenSwapperEthNoSlippage` | `0xC41ceE8409341187C5D5E9107df630D6CBcB7b8E` [View](https://basescan.org/address/0xC41ceE8409341187C5D5E9107df630D6CBcB7b8E#code) |
| `SwapFuseUniversalTokenSwapperEthNoSlippageV2` | `0x264Aa7A907c14B4da075af068283A8a7DD6fcDFe` [View](https://basescan.org/address/0x264Aa7A907c14B4da075af068283A8a7DD6fcDFe#code) |
| `SwapFuseUniversalTokenSwapperWithVerification` | `0x38Bd09C17EA88ceB2F7916BF07AF13C2D9F72370` [View](https://basescan.org/address/0x38Bd09C17EA88ceB2F7916BF07AF13C2D9F72370#code) |
| `SwapFuseUniversalTokenSwapperWithVerificationV2` | `0x4C3acDFdf187772B1fbbE2de99a0275082b03710` [View](https://basescan.org/address/0x4C3acDFdf187772B1fbbE2de99a0275082b03710#code) |
| `SwapReconfigureFuseEulerV2` | `0x11187bac7f13475F4ACe42FCeA72A4f3b9FddBF1` [View](https://basescan.org/address/0x11187bac7f13475F4ACe42FCeA72A4f3b9FddBF1#code) |
| `SwapRegistryFuseEulerV2` | `0x49b9a2f243ab72a51cE78C0215F4FF9708abF923` [View](https://basescan.org/address/0x49b9a2f243ab72a51cE78C0215F4FF9708abF923#code) |
| `UniversalReaderBalanceFuses` | `0xE33F6a15D382CeabB8f351320BF63EE2860E8203` [View](https://basescan.org/address/0xE33F6a15D382CeabB8f351320BF63EE2860E8203#code) |
| `UniversalTokenSwapperEthFuse` | `0x332AeB7102aD5F4D4B671067e7f60F5bEcC86eB8` [View](https://basescan.org/address/0x332AeB7102aD5F4D4B671067e7f60F5bEcC86eB8#code) |
| `UniversalTokenSwapperEthFuseV2` | `0xf026f9D4721aDf2aFba593D2528dd4c3083Ae04B` [View](https://basescan.org/address/0xf026f9D4721aDf2aFba593D2528dd4c3083Ae04B#code) |
| `UniversalTokenSwapperFuse` | `0x98F36e82AaC675d53a780E6CB46406548e7dF5f8` [View](https://basescan.org/address/0x98F36e82AaC675d53a780E6CB46406548e7dF5f8#code) |
| `UniversalTokenSwapperFuseV2` | `0x2902FA1C5cA409579dFeC3B7457f416Eb4De1a43` [View](https://basescan.org/address/0x2902FA1C5cA409579dFeC3B7457f416Eb4De1a43#code) |
| `VeloraSwapperFuse` | `0xc929259a052f091339d4533dB9844B900c56B588` [View](https://basescan.org/address/0xc929259a052f091339d4533dB9844B900c56B588#code) |

#### Base Older Fuses Versions

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `BalanceFuseAerodromeSlipstream` | `0xaff9bbbEa884EF4Db30e4db6a3f68D50E44E1188` [View](https://basescan.org/address/0xaff9bbbEa884EF4Db30e4db6a3f68D50E44E1188#code) |
| `BalanceFuseEulerV2` | `0xf8bB9A9051F6E94d097686544021e6dF17EA6CaF` [View](https://basescan.org/address/0xf8bB9A9051F6E94d097686544021e6dF17EA6CaF#code) |
| `BalanceFuseFlashLoanMorpho` | `0x1704D12204052d2a1F241d5D73f4bF0926800a5B` [View](https://basescan.org/address/0x1704D12204052d2a1F241d5D73f4bF0926800a5B#code) |
| `BorrowFuseEulerV2` | `0xFd5Ba41a7Ce38BC901308547dFCBAded2B682B11` [View](https://basescan.org/address/0xFd5Ba41a7Ce38BC901308547dFCBAded2B682B11#code) |
| `BorrowFuseMoonwell` | `0x8f6951795193C5AE825397ba35e940C5586e7b7D` [View](https://basescan.org/address/0x8f6951795193C5AE825397ba35e940C5586e7b7D#code) |
| `BurnRequestFeeFuseV2` | `0xCaBC40118e83236C751d9a3089e9b5Cf53ee4414` [View](https://basescan.org/address/0xCaBC40118e83236C751d9a3089e9b5Cf53ee4414#code) |
| `CLGaugeFuseAerodromeSlipstream` | `0x3d129395a55dfa3Fd03dF41694748Ef7fe6c13E4` [View](https://basescan.org/address/0x3d129395a55dfa3Fd03dF41694748Ef7fe6c13E4#code) |
| `ClaimRewardsGaugeFuseAerodromeSlipstream` | `0x52f288B352e8dC39777C3F41Dbd0474f4583B237` [View](https://basescan.org/address/0x52f288B352e8dC39777C3F41Dbd0474f4583B237#code) |
| `CollateralFuseEulerV2` | `0xF569a44710DEb64c8Dc9751D8595bb90962f7a67` [View](https://basescan.org/address/0xF569a44710DEb64c8Dc9751D8595bb90962f7a67#code) |
| `CollectFuseAerodromeSlipstream` | `0x414E852a854b21F8eF22DB560f2a7d8B50444A2e` [View](https://basescan.org/address/0x414E852a854b21F8eF22DB560f2a7d8B50444A2e#code) |
| `ControllerFuseEulerV2` | `0x0F86A5ECa11A0a2539Cc24eC27826C65Cc0094eD` [View](https://basescan.org/address/0x0F86A5ECa11A0a2539Cc24eC27826C65Cc0094eD#code) |
| `MidasBalanceFuse` | `0xB1951FaAc31F58830c514561c17b640355529ec0` [View](https://basescan.org/address/0xB1951FaAc31F58830c514561c17b640355529ec0#code) |
| `MidasRequestSupplyFuse` | `0x5077B42243e06FFD3fa239fD499b620c532F85B2` [View](https://basescan.org/address/0x5077B42243e06FFD3fa239fD499b620c532F85B2#code) |
| `MidasSupplyFuse` | `0x1f941BC36399b8E3471568523F22F4f4f918af01` [View](https://basescan.org/address/0x1f941BC36399b8E3471568523F22F4f4f918af01#code) |
| `ModifyPossitionFuseAerodromeSlipstream` | `0x81dd870620839a927d076Cbe40432cCAA3e53740` [View](https://basescan.org/address/0x81dd870620839a927d076Cbe40432cCAA3e53740#code) |
| `NewPositionFuseAerodromeSlipstream` | `0x4426a0A9acE4a784AbB0417B88bc9f3091aC210F` [View](https://basescan.org/address/0x4426a0A9acE4a784AbB0417B88bc9f3091aC210F#code) |
| `RequestFeeRefundFuse` | `0x87Ebf5F74fAb3fEbdD9Dff97E010974674D2E826` [View](https://basescan.org/address/0x87Ebf5F74fAb3fEbdD9Dff97E010974674D2E826#code) |
| `RequestFeeRefundFuse` | `0xa47Ba8FE6110AC337C3f71BE4aff802538aF0468` [View](https://basescan.org/address/0xa47Ba8FE6110AC337C3f71BE4aff802538aF0468#code) |
| `RewardEulerTokenClaimFuse` | `0x2627a9829b00816C5FC54196bFDfD1C8EC999540` [View](https://basescan.org/address/0x2627a9829b00816C5FC54196bFDfD1C8EC999540#code) |
| `SupplyFuseAaveV3` | `0x44dcB8A4c40FA9941d99F409b2948FE91B6C15d5` [View](https://basescan.org/address/0x44dcB8A4c40FA9941d99F409b2948FE91B6C15d5#code) |
| `SupplyFuseErc4626Market1` | `0xbe8ab5217F4f251E4A667650fc34a63035C231a8` [View](https://basescan.org/address/0xbe8ab5217F4f251E4A667650fc34a63035C231a8#code) |
| `SupplyFuseErc4626Market10` | `0xF4FB53B8831DD70b628F225Ab8BbAadC0A93E2dC` [View](https://basescan.org/address/0xF4FB53B8831DD70b628F225Ab8BbAadC0A93E2dC#code) |
| `SupplyFuseErc4626Market11` | `0x25c275CbFFb6539D81e00AFcdbFDbd962f5d3202` [View](https://basescan.org/address/0x25c275CbFFb6539D81e00AFcdbFDbd962f5d3202#code) |
| `SupplyFuseErc4626Market12` | `0x32df46Cff7e6Cab610ed6113D7A57F242d061D68` [View](https://basescan.org/address/0x32df46Cff7e6Cab610ed6113D7A57F242d061D68#code) |
| `SupplyFuseErc4626Market13` | `0x8598432cda45fd6dC836728d6B12f325f78b62b6` [View](https://basescan.org/address/0x8598432cda45fd6dC836728d6B12f325f78b62b6#code) |
| `SupplyFuseErc4626Market14` | `0xe1Cce1485F5A22D64b89D8E0ba2190Ca4e8f1eA2` [View](https://basescan.org/address/0xe1Cce1485F5A22D64b89D8E0ba2190Ca4e8f1eA2#code) |
| `SupplyFuseErc4626Market2` | `0xed5Ec535e6e6a3051105A8Ea2E8Bd178951A9EAc` [View](https://basescan.org/address/0xed5Ec535e6e6a3051105A8Ea2E8Bd178951A9EAc#code) |
| `SupplyFuseErc4626Market3` | `0xdA0711a0b1B1dD289c4D7C08704Dd1e4cceA80C1` [View](https://basescan.org/address/0xdA0711a0b1B1dD289c4D7C08704Dd1e4cceA80C1#code) |
| `SupplyFuseErc4626Market4` | `0xb187050408857FC2a57be0a5618e39b331425E77` [View](https://basescan.org/address/0xb187050408857FC2a57be0a5618e39b331425E77#code) |
| `SupplyFuseErc4626Market5` | `0x633d78849fb91a336077ff25aFC3c72c8f6a7045` [View](https://basescan.org/address/0x633d78849fb91a336077ff25aFC3c72c8f6a7045#code) |
| `SupplyFuseErc4626Market6` | `0xF3ce837D8eBA7332Ce16b698d8262247d6CB277D` [View](https://basescan.org/address/0xF3ce837D8eBA7332Ce16b698d8262247d6CB277D#code) |
| `SupplyFuseErc4626Market7` | `0x928c217E669d9F0F3fc08fB8AC322133a12E1F43` [View](https://basescan.org/address/0x928c217E669d9F0F3fc08fB8AC322133a12E1F43#code) |
| `SupplyFuseErc4626Market8` | `0x5b36e95AbfF98a476FBAeB3E2434deE3EB463F48` [View](https://basescan.org/address/0x5b36e95AbfF98a476FBAeB3E2434deE3EB463F48#code) |
| `SupplyFuseErc4626Market9` | `0xc3B44addfAe29fD170196C324bA0C233C870c77a` [View](https://basescan.org/address/0xc3B44addfAe29fD170196C324bA0C233C870c77a#code) |
| `SupplyFuseEulerV2` | `0x96901b9A10f2A7f856a97ff148c4Cf3A0077d1ab` [View](https://basescan.org/address/0x96901b9A10f2A7f856a97ff148c4Cf3A0077d1ab#code) |
| `SupplyFuseEulerV2` | `0xFa00806c871558ceF982DFc02D7a87e4Ad0ec0Fa` [View](https://basescan.org/address/0xFa00806c871558ceF982DFc02D7a87e4Ad0ec0Fa#code) |
| `SwapFuseUniversalTokenSwapper` | `0x4d9cbA074b00249D0a7d390Ff8f038dE3Ae23317` [View](https://basescan.org/address/0x4d9cbA074b00249D0a7d390Ff8f038dE3Ae23317#code) |

### Unichain Fuses

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `AsyncActionBalanceFuse` | `0xEFc74E95e7da92a6F26543919CC00f4c69c32Eaf` [View](https://uniscan.xyz/address/0xEFc74E95e7da92a6F26543919CC00f4c69c32Eaf#code) |
| `AsyncActionFuse` | `0x289435917147b67b0212D90Bc590B0388b5F0414` [View](https://uniscan.xyz/address/0x289435917147b67b0212D90Bc590B0388b5F0414#code) |
| `BalanceFuseBurnRequestFee` | `0x81E91F9c1aD45E9DAD18A78732ad290b4A5e890b` [View](https://uniscan.xyz/address/0x81E91F9c1aD45E9DAD18A78732ad290b4A5e890b#code) |
| `BalanceFuseErc20` | `0x8742A06bd12f72D5D58B00F593FDD0e455A19b9d` [View](https://uniscan.xyz/address/0x8742A06bd12f72D5D58B00F593FDD0e455A19b9d#code) |
| `BalanceFuseEulerV2` | `0x6402AC17506cacb2a917862A321EB9327e7bd81A` [View](https://uniscan.xyz/address/0x6402AC17506cacb2a917862A321EB9327e7bd81A#code) |
| `BalanceFuseFlashLoanMorpho` | `0x9Bc291B820A871001030A9ac76d31709f5B9E0aD` [View](https://uniscan.xyz/address/0x9Bc291B820A871001030A9ac76d31709f5B9E0aD#code) |
| `BalanceFuseMetaMorphoMarket0001` | `0xfCbf8d7eF18684F999EbfF0d5A83c1b6DA877870` [View](https://uniscan.xyz/address/0xfCbf8d7eF18684F999EbfF0d5A83c1b6DA877870#code) |
| `BalanceFuseMorpho` | `0x86653327f3E3e499e053261ec44D627AecEDfae8` [View](https://uniscan.xyz/address/0x86653327f3E3e499e053261ec44D627AecEDfae8#code) |
| `BalanceFuseMorphoLiquidityInMarkets` | `0x5D2D3ae7bd73645e42757b26430e8C8d4B0643C1` [View](https://uniscan.xyz/address/0x5D2D3ae7bd73645e42757b26430e8C8d4B0643C1#code) |
| `BalanceFuseOdosSwapper` | `0x19445479eAd1869edF6482a285DF42e5B69Dd618` [View](https://uniscan.xyz/address/0x19445479eAd1869edF6482a285DF42e5B69Dd618#code) |
| `BalanceFuseUniversalTokenSwapper` | `0x6Fb90c6Cb82Ae0848f221bc06f022E3FD71226AE` [View](https://uniscan.xyz/address/0x6Fb90c6Cb82Ae0848f221bc06f022E3FD71226AE#code) |
| `BalanceFuseUniversalTokenSwapperV2` | `0x48f5654Fec892B4Ba346ed8eb1a2e7F7653b74e5` [View](https://uniscan.xyz/address/0x48f5654Fec892B4Ba346ed8eb1a2e7F7653b74e5#code) |
| `BalanceFuseVeloraSwapper` | `0x475c1b17a3e7f1f320E1796a7F1f8C8c3e000597` [View](https://uniscan.xyz/address/0x475c1b17a3e7f1f320E1796a7F1f8C8c3e000597#code) |
| `BatchFuseEulerV2` | `0x4b41f3F06f4dF5FAF2437C889d63159c78Fd9386` [View](https://uniscan.xyz/address/0x4b41f3F06f4dF5FAF2437C889d63159c78Fd9386#code) |
| `BorrowFuseEulerV2` | `0xf5965cc67C566A4587F627Eba09Ef33EB6120fA4` [View](https://uniscan.xyz/address/0xf5965cc67C566A4587F627Eba09Ef33EB6120fA4#code) |
| `BorrowFuseMorpho` | `0x8A84b69aFCCAC94b5Fb0a4894D0fA016dB2CF020` [View](https://uniscan.xyz/address/0x8A84b69aFCCAC94b5Fb0a4894D0fA016dB2CF020#code) |
| `BurnRequestFeeFuse` | `0xa7C6120a16B6b5201a7e33FF4ee13C798c838FC8` [View](https://uniscan.xyz/address/0xa7C6120a16B6b5201a7e33FF4ee13C798c838FC8#code) |
| `BurnRequestFeeFuseV2` | `0x503BE9A0dD9C162576289C6d89CADC50dBB62B7B` [View](https://uniscan.xyz/address/0x503BE9A0dD9C162576289C6d89CADC50dBB62B7B#code) |
| `ClaimRewardsFuseMorpho` | `0xc073695aEDD12Fa885318A8b229D55120ce90325` [View](https://uniscan.xyz/address/0xc073695aEDD12Fa885318A8b229D55120ce90325#code) |
| `CollateralFuseEulerV2` | `0xc9dbe9B52Deef0DDC9b5e513Cc249604A5d29A82` [View](https://uniscan.xyz/address/0xc9dbe9B52Deef0DDC9b5e513Cc249604A5d29A82#code) |
| `CollateralFuseMorpho` | `0xFc3400A8B10c05DCB7394E51cF67E2189c48BFe8` [View](https://uniscan.xyz/address/0xFc3400A8B10c05DCB7394E51cF67E2189c48BFe8#code) |
| `ConfigureInstantWithdrawalFuse` | `0x31BF6Ce4553986243cdA4ae02F7693EB254B857E` [View](https://uniscan.xyz/address/0x31BF6Ce4553986243cdA4ae02F7693EB254B857E#code) |
| `ControllerFuseEulerV2` | `0xa32E128CA86e8116dF090c5287C21E08b2EaCAf0` [View](https://uniscan.xyz/address/0xa32E128CA86e8116dF090c5287C21E08b2EaCAf0#code) |
| `FlashloanFuseMorpho` | `0xc043d8F356cdD27e98af1A76918Ac18F828Ed8F4` [View](https://uniscan.xyz/address/0xc043d8F356cdD27e98af1A76918Ac18F828Ed8F4#code) |
| `FuseRequestSharesPlasmaVaultV2` | `0xE16C07c258A00e43f1Ec83207eC02752722fD702` [View](https://uniscan.xyz/address/0xE16C07c258A00e43f1Ec83207eC02752722fD702#code) |
| `OdosSwapperFuse` | `0x2fA73043a9819e587dc7E6102D87Cc0cBF4aBC6B` [View](https://uniscan.xyz/address/0x2fA73043a9819e587dc7E6102D87Cc0cBF4aBC6B#code) |
| `RequestFeeRefundFuse` | `0x27Da69CcC58F5B06E2039413940542f46363E5B6` [View](https://uniscan.xyz/address/0x27Da69CcC58F5B06E2039413940542f46363E5B6#code) |
| `RewardEulerTokenClaimFuse` | `0x5149395a94D9c31216797f6a0f22C6824866e45A` [View](https://uniscan.xyz/address/0x5149395a94D9c31216797f6a0f22C6824866e45A#code) |
| `SupplyFuseEulerV2` | `0xd57dc0080C1656Ae4Ad8Af5011A6F3e613d2b5Aa` [View](https://uniscan.xyz/address/0xd57dc0080C1656Ae4Ad8Af5011A6F3e613d2b5Aa#code) |
| `SupplyFuseMetaMorphoMarket0001` | `0x8D55edf480214fAa0f476512b68dFd876cf12683` [View](https://uniscan.xyz/address/0x8D55edf480214fAa0f476512b68dFd876cf12683#code) |
| `SupplyFuseMorpho` | `0xea13241E2D0EF964Ee616151e72d493496A568F5` [View](https://uniscan.xyz/address/0xea13241E2D0EF964Ee616151e72d493496A568F5#code) |
| `SupplyFuseMorphoLiquidityInMarkets` | `0x4F569890F7fd579e187Cb4bAF67a4FE30E9Ef9Bf` [View](https://uniscan.xyz/address/0x4F569890F7fd579e187Cb4bAF67a4FE30E9Ef9Bf#code) |
| `SwapDeployFuseEulerV2` | `0x36DE43348f00A078087A15f1Be826C6F4140285C` [View](https://uniscan.xyz/address/0x36DE43348f00A078087A15f1Be826C6F4140285C#code) |
| `SwapFuseUniversalTokenSwapper` | `0x6991332CC5AF5208871aC1483218C723542714C6` [View](https://uniscan.xyz/address/0x6991332CC5AF5208871aC1483218C723542714C6#code) |
| `SwapFuseUniversalTokenSwapperEth` | `0xf66aEF6C06dBC5dB4610f50a46668716B84b5629` [View](https://uniscan.xyz/address/0xf66aEF6C06dBC5dB4610f50a46668716B84b5629#code) |
| `SwapFuseUniversalTokenSwapperWithVerification` | `0x50f97E9DB639380C77BA3e4B3039E57649e527Ac` [View](https://uniscan.xyz/address/0x50f97E9DB639380C77BA3e4B3039E57649e527Ac#code) |
| `SwapFuseUniversalTokenSwapperWithVerificationV2` | `0x7F86Ddb92FFd8a80a918ED3553C6F6173626a87e` [View](https://uniscan.xyz/address/0x7F86Ddb92FFd8a80a918ED3553C6F6173626a87e#code) |
| `SwapReconfigureFuseEulerV2` | `0x3b29fAff3478e64a3d3D2DC70A58cb1140743E8D` [View](https://uniscan.xyz/address/0x3b29fAff3478e64a3d3D2DC70A58cb1140743E8D#code) |
| `SwapRegistryFuseEulerV2` | `0x7Cc4859945Cbf8Ec3151927d6bc0fBe79D23C9c5` [View](https://uniscan.xyz/address/0x7Cc4859945Cbf8Ec3151927d6bc0fBe79D23C9c5#code) |
| `UniversalReaderBalanceFuses` | `0x65fb961658b4D3D6Ca0A47b741C5D181C25c64f4` [View](https://uniscan.xyz/address/0x65fb961658b4D3D6Ca0A47b741C5D181C25c64f4#code) |
| `UniversalTokenSwapperEthFuse` | `0x2f944018c0CfE388Adc62c99E827504828dF1F31` [View](https://uniscan.xyz/address/0x2f944018c0CfE388Adc62c99E827504828dF1F31#code) |
| `UniversalTokenSwapperEthFuseV2` | `0x576196e47Fd1364C59400253D3187e67A6CB08cC` [View](https://uniscan.xyz/address/0x576196e47Fd1364C59400253D3187e67A6CB08cC#code) |
| `UniversalTokenSwapperFuse` | `0xB652a3f59660fE3606922e7e23F77cF64d4b940E` [View](https://uniscan.xyz/address/0xB652a3f59660fE3606922e7e23F77cF64d4b940E#code) |
| `UniversalTokenSwapperFuseV2` | `0xa9f8C4EDba6ceB896691AE2C38e8288B604C3865` [View](https://uniscan.xyz/address/0xa9f8C4EDba6ceB896691AE2C38e8288B604C3865#code) |
| `VeloraSwapperFuse` | `0xe31E121b2eFc321dBF3f1B4142c36C1acB336E3b` [View](https://uniscan.xyz/address/0xe31E121b2eFc321dBF3f1B4142c36C1acB336E3b#code) |

#### Unichain Older Fuses Versions

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `BalanceFuseMorpho` | `0x657B4cB830Ad0d7036a5D41a4C241bf7F444AEEe` [View](https://uniscan.xyz/address/0x657B4cB830Ad0d7036a5D41a4C241bf7F444AEEe#code) |
| `SupplyFuseEulerV2` | `0xBf8759c387b9C44aD304B0778c12437A520f93A1` [View](https://uniscan.xyz/address/0xBf8759c387b9C44aD304B0778c12437A520f93A1#code) |

### TAC Fuses

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `BalanceFuseBurnRequestFee` | `0x75ea3B63b469503A1948F23bd84917893C82E7fD` [View](https://explorer.tac.build/address/0x75ea3B63b469503A1948F23bd84917893C82E7fD#code) |
| `BalanceFuseErc20` | `0xCFE88D3812c02e331D6E62F2bA75006d207612b3` [View](https://explorer.tac.build/address/0xCFE88D3812c02e331D6E62F2bA75006d207612b3#code) |
| `BalanceFuseUniversalTokenSwapper` | `0x0E0350AbE7c47cEA27D8D8884F55C5904Eba08f8` [View](https://explorer.tac.build/address/0x0E0350AbE7c47cEA27D8D8884F55C5904Eba08f8#code) |
| `BurnRequestFeeFuse` | `0x13AefCeb3490e419F31AbA8997eF4b11e88AfFa4` [View](https://explorer.tac.build/address/0x13AefCeb3490e419F31AbA8997eF4b11e88AfFa4#code) |
| `ConfigureInstantWithdrawalFuse` | `0xb107373C8f67C97df1cee20bb3180719D95eA75b` [View](https://explorer.tac.build/address/0xb107373C8f67C97df1cee20bb3180719D95eA75b#code) |
| `SwapFuseUniversalTokenSwapper` | `0x81a4f4d9e70e6367a0509FE058efbeA2092e310e` [View](https://explorer.tac.build/address/0x81a4f4d9e70e6367a0509FE058efbeA2092e310e#code) |
| `TacStakingBalanceFuse` | `0x839C0475fd43690B61D935F0255C4f9B4a9e13f1` [View](https://explorer.tac.build/address/0x839C0475fd43690B61D935F0255C4f9B4a9e13f1#code) |
| `TacStakingDelegateFuse` | `0x457C6981b48C60099B2218C196071Cc2c60d0638` [View](https://explorer.tac.build/address/0x457C6981b48C60099B2218C196071Cc2c60d0638#code) |
| `TacStakingEmergencyFuse` | `0xaBdFC4f716227946ACbCB6d9089Ab8c4BDEDB7C7` [View](https://explorer.tac.build/address/0xaBdFC4f716227946ACbCB6d9089Ab8c4BDEDB7C7#code) |
| `TacStakingRedelegateFuse` | `0x7b499CE3B1babc150bdbc6F31E52200D6Cdb02E9` [View](https://explorer.tac.build/address/0x7b499CE3B1babc150bdbc6F31E52200D6Cdb02E9#code) |
| `UniversalReaderBalanceFuses` | `0xAbD1823440f718f2f5F8B549868600Ea7Fd5A72a` [View](https://explorer.tac.build/address/0xAbD1823440f718f2f5F8B549868600Ea7Fd5A72a#code) |

### Ink Fuses

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `AsyncActionBalanceFuse` | `0xA702f2438158A79aD74262e60536CA78c386C829` [View](https://explorer.inkonchain.com/address/0xA702f2438158A79aD74262e60536CA78c386C829#code) |
| `AsyncActionFuse` | `0xBD06e24A15D9fE7D0a023e45419F5e6e3635BB66` [View](https://explorer.inkonchain.com/address/0xBD06e24A15D9fE7D0a023e45419F5e6e3635BB66#code) |
| `BalanceFuseBurnRequestFee` | `0xF4Db8b9315B89Ca94Da07788faD2C942Af7F7b67` [View](https://explorer.inkonchain.com/address/0xF4Db8b9315B89Ca94Da07788faD2C942Af7F7b67#code) |
| `BalanceFuseErc20` | `0x3DAf55a976821680cB812330CbbDc82816EBe4C0` [View](https://explorer.inkonchain.com/address/0x3DAf55a976821680cB812330CbbDc82816EBe4C0#code) |
| `BalanceFuseUniversalTokenSwapper` | `0xE4F26Ad8d3f7f6d7d52C18f19eF066C884D60168` [View](https://explorer.inkonchain.com/address/0xE4F26Ad8d3f7f6d7d52C18f19eF066C884D60168#code) |
| `BalanceFuseUniversalTokenSwapperV2` | `0x87Ec6bBf61154C4ad6f3961d7faA7d855f1430Ce` [View](https://explorer.inkonchain.com/address/0x87Ec6bBf61154C4ad6f3961d7faA7d855f1430Ce#code) |
| `BalanceFuseVelodromeSuperchain` | `0x9eC558254A50c2658a2Eb5906EB2D384077bbF95` [View](https://explorer.inkonchain.com/address/0x9eC558254A50c2658a2Eb5906EB2D384077bbF95#code) |
| `BalanceFuseVelodromeSuperchainSlipstream` | `0x175D196Efed174AD74b247c2fA2c63AEDc5afE20` [View](https://explorer.inkonchain.com/address/0x175D196Efed174AD74b247c2fA2c63AEDc5afE20#code) |
| `BalanceFuseVeloraSwapper` | `0x91C37e3867d744997572620c03FC244E22738f11` [View](https://explorer.inkonchain.com/address/0x91C37e3867d744997572620c03FC244E22738f11#code) |
| `BurnRequestFeeFuse` | `0x38FfDFc14D17aBC9f996f22cc105F6B48D7Ce2a2` [View](https://explorer.inkonchain.com/address/0x38FfDFc14D17aBC9f996f22cc105F6B48D7Ce2a2#code) |
| `BurnRequestFeeFuseV2` | `0x4b74f3DE9391f49f64D863EA1c6545D88c391F31` [View](https://explorer.inkonchain.com/address/0x4b74f3DE9391f49f64D863EA1c6545D88c391F31#code) |
| `ClaimRewardsGaugeFuseVelodromeSuperchain` | `0xa5EF4Afb79A50b0F0069815729658F395A2C17a6` [View](https://explorer.inkonchain.com/address/0xa5EF4Afb79A50b0F0069815729658F395A2C17a6#code) |
| `ClaimRewardsGaugeFuseVelodromeSuperchainSlipstream` | `0xdE913c2438Aa7Ed5BeDc597bB79969c1e4374D30` [View](https://explorer.inkonchain.com/address/0xdE913c2438Aa7Ed5BeDc597bB79969c1e4374D30#code) |
| `CollectFuseVelodromeSuperchainSlipstream` | `0x86F88E616C43AEC2f9Bb3AfBf09dd4489E6D7c68` [View](https://explorer.inkonchain.com/address/0x86F88E616C43AEC2f9Bb3AfBf09dd4489E6D7c68#code) |
| `ConfigureInstantWithdrawalFuse` | `0x7E07BC6598f9cB30F5E932bF46270a21895Cd59a` [View](https://explorer.inkonchain.com/address/0x7E07BC6598f9cB30F5E932bF46270a21895Cd59a#code) |
| `FuseRequestSharesPlasmaVaultV2` | `0xcd1B89415d1cdd7e39C279C567f6BF9c61aD513C` [View](https://explorer.inkonchain.com/address/0xcd1B89415d1cdd7e39C279C567f6BF9c61aD513C#code) |
| `GaugeFuseVelodromeSuperchain` | `0x7c21eB05e02A908B61eB213eB1B4dbEA354444e5` [View](https://explorer.inkonchain.com/address/0x7c21eB05e02A908B61eB213eB1B4dbEA354444e5#code) |
| `LeafCLGaugeFuseVelodromeSuperchainSlipstream` | `0x0d500B505dE7667b9Fd0B0944796A5d1eEBe6C2e` [View](https://explorer.inkonchain.com/address/0x0d500B505dE7667b9Fd0B0944796A5d1eEBe6C2e#code) |
| `LiquidityFuseVelodromeSuperchain` | `0x497831DF4a422D1edcf0bb210E237AD41aFAE6E3` [View](https://explorer.inkonchain.com/address/0x497831DF4a422D1edcf0bb210E237AD41aFAE6E3#code) |
| `MerklClaimFuse` | `0xd0Fe56A032ED3fC37AA4c90a0856c4f1caC6b1D9` [View](https://explorer.inkonchain.com/address/0xd0Fe56A032ED3fC37AA4c90a0856c4f1caC6b1D9#code) |
| `ModifyPossitionFuseVelodromeSuperchainSlipstream` | `0x23B08f0013361A080b7B471D4c6dcC5E9B2E75ad` [View](https://explorer.inkonchain.com/address/0x23B08f0013361A080b7B471D4c6dcC5E9B2E75ad#code) |
| `NewPositionFuseVelodromeSuperchainSlipstream` | `0xF5e9B006E10815e870f0E96569a332EBE5338d26` [View](https://explorer.inkonchain.com/address/0xF5e9B006E10815e870f0E96569a332EBE5338d26#code) |
| `RequestFeeRefundFuse` | `0x6D325fA767B8d9eef0e1cB218881947Dab52f5E2` [View](https://explorer.inkonchain.com/address/0x6D325fA767B8d9eef0e1cB218881947Dab52f5E2#code) |
| `SwapFuseUniversalTokenSwapper` | `0xd50C735Ef23E4119134aA5e85076f6BfC44d8649` [View](https://explorer.inkonchain.com/address/0xd50C735Ef23E4119134aA5e85076f6BfC44d8649#code) |
| `SwapFuseUniversalTokenSwapperEth` | `0x20A50284b04B4AbEFdCfBfE95910A0A361a4A991` [View](https://explorer.inkonchain.com/address/0x20A50284b04B4AbEFdCfBfE95910A0A361a4A991#code) |
| `SwapFuseUniversalTokenSwapperWithVerification` | `0x143fA0BaA257d734eA70F7240995649Aa9cb43A8` [View](https://explorer.inkonchain.com/address/0x143fA0BaA257d734eA70F7240995649Aa9cb43A8#code) |
| `SwapFuseUniversalTokenSwapperWithVerificationV2` | `0x760EAc108c691a747082466b985F8116a7B0c66D` [View](https://explorer.inkonchain.com/address/0x760EAc108c691a747082466b985F8116a7B0c66D#code) |
| `UniversalReaderBalanceFuses` | `0x9Da21B83375041937C3D91cCA2cCb11E3e427FbB` [View](https://explorer.inkonchain.com/address/0x9Da21B83375041937C3D91cCA2cCb11E3e427FbB#code) |
| `UniversalTokenSwapperEthFuse` | `0xF428D8eF6FA03F0914b3E26B6Ec6732a7a8Ad8B5` [View](https://explorer.inkonchain.com/address/0xF428D8eF6FA03F0914b3E26B6Ec6732a7a8Ad8B5#code) |
| `UniversalTokenSwapperEthFuseV2` | `0xF52bD78504E30BADfC3Ad4B360334B427fb5cE14` [View](https://explorer.inkonchain.com/address/0xF52bD78504E30BADfC3Ad4B360334B427fb5cE14#code) |
| `UniversalTokenSwapperFuse` | `0x2A0E9b16E6aeC94B11947b72c3ddF5C8a1bD0464` [View](https://explorer.inkonchain.com/address/0x2A0E9b16E6aeC94B11947b72c3ddF5C8a1bD0464#code) |
| `UniversalTokenSwapperFuseV2` | `0xEBb066b1EA053c09b0A27F0BBF199029E9b7d9F9` [View](https://explorer.inkonchain.com/address/0xEBb066b1EA053c09b0A27F0BBF199029E9b7d9F9#code) |
| `VelodromeSuperchainBalanceFuse` | `0xd255d98CE8fdce515346c25b60291DBf52457EE1` [View](https://explorer.inkonchain.com/address/0xd255d98CE8fdce515346c25b60291DBf52457EE1#code) |
| `VelodromeSuperchainGaugeClaimFuse` | `0xD309D21BdD090B997BF99928d0dfc092Bbc07f70` [View](https://explorer.inkonchain.com/address/0xD309D21BdD090B997BF99928d0dfc092Bbc07f70#code) |
| `VelodromeSuperchainGaugeFuse` | `0x3688B96dED3662992902F5Ca794A5c5BEd4cd2eA` [View](https://explorer.inkonchain.com/address/0x3688B96dED3662992902F5Ca794A5c5BEd4cd2eA#code) |
| `VelodromeSuperchainLiquidityFuse` | `0xEAc973C278436dc23dEeF8a925F809A8ad977624` [View](https://explorer.inkonchain.com/address/0xEAc973C278436dc23dEeF8a925F809A8ad977624#code) |
| `VelodromeSuperchainSlipstreamBalanceFuse` | `0xDc2d9dA62f9c25e646A25B372a913E708b0b6f43` [View](https://explorer.inkonchain.com/address/0xDc2d9dA62f9c25e646A25B372a913E708b0b6f43#code) |
| `VelodromeSuperchainSlipstreamCollectFuse` | `0xf14aE70027340dDC46a3f426808F381DdCe0BfE4` [View](https://explorer.inkonchain.com/address/0xf14aE70027340dDC46a3f426808F381DdCe0BfE4#code) |
| `VelodromeSuperchainSlipstreamGaugeClaimFuse` | `0x56E626c5538402BF5A60e58A06fdF0D3D741FBaA` [View](https://explorer.inkonchain.com/address/0x56E626c5538402BF5A60e58A06fdF0D3D741FBaA#code) |
| `VelodromeSuperchainSlipstreamLeafCLGaugeFuse` | `0xF11627F3e45220BB6F0d1b6fd5e9C3610C377bd0` [View](https://explorer.inkonchain.com/address/0xF11627F3e45220BB6F0d1b6fd5e9C3610C377bd0#code) |
| `VelodromeSuperchainSlipstreamModifyPositionFuse` | `0xcA3e5E7ad17fD5eCF5C36B4c4C772A1A46B5e7cb` [View](https://explorer.inkonchain.com/address/0xcA3e5E7ad17fD5eCF5C36B4c4C772A1A46B5e7cb#code) |
| `VelodromeSuperchainSlipstreamNewPositionFuse` | `0x8B67350b0EDf00481e6EaBc46EfFcDbea75c76da` [View](https://explorer.inkonchain.com/address/0x8B67350b0EDf00481e6EaBc46EfFcDbea75c76da#code) |
| `VeloraSwapperFuse` | `0x6cf77fECF1BdeBE17E4841ba372bE11b037272A4` [View](https://explorer.inkonchain.com/address/0x6cf77fECF1BdeBE17E4841ba372bE11b037272A4#code) |

### Plasma Fuses

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `AaveV3CollateralFuse` | `0x9409c514C84D6625704B572F1B840E37a7562F4b` [View](https://plasmascan.to/address/0x9409c514C84D6625704B572F1B840E37a7562F4b/contract/9745/code) |
| `AaveV3WithPriceOracleMiddlewareBalanceFuse` | `0x85af64e5E3B40B4AA0aa876f6E4979C24aA689F2` [View](https://plasmascan.to/address/0x85af64e5E3B40B4AA0aa876f6E4979C24aA689F2/contract/9745/code) |
| `AsyncActionBalanceFuse` | `0x997a6a5EfAE5dA814022B6CD690268e5eC4ff187` [View](https://plasmascan.to/address/0x997a6a5EfAE5dA814022B6CD690268e5eC4ff187/contract/9745/code) |
| `AsyncActionFuse` | `0x1cF6A440Ed84A9f8368738778e915837dF73101B` [View](https://plasmascan.to/address/0x1cF6A440Ed84A9f8368738778e915837dF73101B/contract/9745/code) |
| `BalanceFuseBurnRequestFee` | `0x432318BC7632146717753C8C3349c196831b4903` [View](https://plasmascan.to/address/0x432318BC7632146717753C8C3349c196831b4903/contract/9745/code) |
| `BalanceFuseErc20` | `0x1d604b955C783fdB8306989079624063f974c36e` [View](https://plasmascan.to/address/0x1d604b955C783fdB8306989079624063f974c36e/contract/9745/code) |
| `BalanceFuseErc4626Market1` | `0x9952B443634080d5B4D14A79CAa6C9CE39fb30fc` [View](https://plasmascan.to/address/0x9952B443634080d5B4D14A79CAa6C9CE39fb30fc/contract/9745/code) |
| `BalanceFuseEulerV2` | `0xA8c95Ebe61Af91cf5254C26AFF668eBCa197e865` [View](https://plasmascan.to/address/0xA8c95Ebe61Af91cf5254C26AFF668eBCa197e865/contract/9745/code) |
| `BalanceFuseUniversalTokenSwapper` | `0xED6151F3A1435d84FfcC2eafa51E47392cdE7eB9` [View](https://plasmascan.to/address/0xED6151F3A1435d84FfcC2eafa51E47392cdE7eB9/contract/9745/code) |
| `BalanceFuseUniversalTokenSwapperV2` | `0xe7925d6077a51d60107A7f4BB19CCc3BcC0c43F2` [View](https://plasmascan.to/address/0xe7925d6077a51d60107A7f4BB19CCc3BcC0c43F2/contract/9745/code) |
| `BalanceFuseVeloraSwapper` | `0xb1789AC81c0EA9F1793517c730a3BC4D0608C8AF` [View](https://plasmascan.to/address/0xb1789AC81c0EA9F1793517c730a3BC4D0608C8AF/contract/9745/code) |
| `BatchFuseEulerV2` | `0x0F538451c4eCb75B1DD8f3Ba667A271A71900c97` [View](https://plasmascan.to/address/0x0F538451c4eCb75B1DD8f3Ba667A271A71900c97/contract/9745/code) |
| `BorrowFuseAaveV3` | `0xA072E8ff01fec4e09808968220bFF4DD2262e320` [View](https://plasmascan.to/address/0xA072E8ff01fec4e09808968220bFF4DD2262e320/contract/9745/code) |
| `BorrowFuseEulerV2` | `0x16a50d2CfBa4683002d933CD27167E009397aA8d` [View](https://plasmascan.to/address/0x16a50d2CfBa4683002d933CD27167E009397aA8d/contract/9745/code) |
| `BurnRequestFeeFuse` | `0x2C904561C53C1707598A8031D59CfcaAaA831c4E` [View](https://plasmascan.to/address/0x2C904561C53C1707598A8031D59CfcaAaA831c4E/contract/9745/code) |
| `BurnRequestFeeFuseV2` | `0x542dEeD8feD9f1a6F620eA089BdD70017Deb3Afd` [View](https://plasmascan.to/address/0x542dEeD8feD9f1a6F620eA089BdD70017Deb3Afd/contract/9745/code) |
| `CollateralFuseEulerV2` | `0x839e3935bD1Ed69E90a5C9A6Af5A86Aa6491cC5F` [View](https://plasmascan.to/address/0x839e3935bD1Ed69E90a5C9A6Af5A86Aa6491cC5F/contract/9745/code) |
| `ConfigureInstantWithdrawalFuse` | `0x876D692c16e9B9c02DDB1349980E159cB4fbAdEc` [View](https://plasmascan.to/address/0x876D692c16e9B9c02DDB1349980E159cB4fbAdEc/contract/9745/code) |
| `ControllerFuseEulerV2` | `0x83BCf7Fb4fA738a9C990c2DABC6ff2B575bdD49a` [View](https://plasmascan.to/address/0x83BCf7Fb4fA738a9C990c2DABC6ff2B575bdD49a/contract/9745/code) |
| `EnsoBalanceFuse` | `0x23d9f804C29e93484e2a78aae6cB0A2e5E3F75D1` [View](https://plasmascan.to/address/0x23d9f804C29e93484e2a78aae6cB0A2e5E3F75D1/contract/9745/code) |
| `EnsoFuse` | `0x48F3Ae36A9efaA7586A1d89E185A219732976833` [View](https://plasmascan.to/address/0x48F3Ae36A9efaA7586A1d89E185A219732976833/contract/9745/code) |
| `EnsoInitExecutorFuse` | `0x4ad1507Fa12b4216cB3F45aaF74741197bB4b230` [View](https://plasmascan.to/address/0x4ad1507Fa12b4216cB3F45aaF74741197bB4b230/contract/9745/code) |
| `FuseRequestSharesPlasmaVaultV2` | `0x46deE646fBad016bE1b44C34acEBc6302F1E658d` [View](https://plasmascan.to/address/0x46deE646fBad016bE1b44C34acEBc6302F1E658d/contract/9745/code) |
| `MerklClaimFuse` | `0xD9f2AE5a8E65D5e7965BA3b09Af5bA42F61bA11b` [View](https://plasmascan.to/address/0xD9f2AE5a8E65D5e7965BA3b09Af5bA42F61bA11b/contract/9745/code) |
| `RequestFeeRefundFuse` | `0x7Fca7063734b1B94D299529eDe16c00Ad7044e5a` [View](https://plasmascan.to/address/0x7Fca7063734b1B94D299529eDe16c00Ad7044e5a/contract/9745/code) |
| `RewardEulerTokenClaimFuse` | `0xc054015C8c5A15A875CccE983d92043a6FF53B8E` [View](https://plasmascan.to/address/0xc054015C8c5A15A875CccE983d92043a6FF53B8E/contract/9745/code) |
| `SupplyFuseAaveV3` | `0x9B64e01c16CbFfB0D42d89a5Df73B7f8909dff05` [View](https://plasmascan.to/address/0x9B64e01c16CbFfB0D42d89a5Df73B7f8909dff05/contract/9745/code) |
| `SupplyFuseErc4626Market1` | `0xF972cf440E7e9de6267FFc17DcECde44f05e7E20` [View](https://plasmascan.to/address/0xF972cf440E7e9de6267FFc17DcECde44f05e7E20/contract/9745/code) |
| `SupplyFuseEulerV2` | `0x7a15Fc5eCd4dbc038F23B488c634218aD1B74b4A` [View](https://plasmascan.to/address/0x7a15Fc5eCd4dbc038F23B488c634218aD1B74b4A/contract/9745/code) |
| `SwapDeployFuseEulerV2` | `0x917CD788957b758CfbdB3435d62f44eBD409415d` [View](https://plasmascan.to/address/0x917CD788957b758CfbdB3435d62f44eBD409415d/contract/9745/code) |
| `SwapFuseUniversalTokenSwapper` | `0xbDA9bF1300e2dB937997810612aaF4bD5628541F` [View](https://plasmascan.to/address/0xbDA9bF1300e2dB937997810612aaF4bD5628541F/contract/9745/code) |
| `SwapFuseUniversalTokenSwapperEth` | `0x34ca335f6E64eB56aB0206Ff58B010D8d1870D64` [View](https://plasmascan.to/address/0x34ca335f6E64eB56aB0206Ff58B010D8d1870D64/contract/9745/code) |
| `SwapFuseUniversalTokenSwapperWithVerification` | `0x0D8350c362A47f28A649003d26E425f5284A9f51` [View](https://plasmascan.to/address/0x0D8350c362A47f28A649003d26E425f5284A9f51/contract/9745/code) |
| `SwapFuseUniversalTokenSwapperWithVerificationV2` | `0x20F8Ae74EF07013919B371FdbC00CB9789eD3c82` [View](https://plasmascan.to/address/0x20F8Ae74EF07013919B371FdbC00CB9789eD3c82/contract/9745/code) |
| `SwapReconfigureFuseEulerV2` | `0xD167776D0a28DD6F8c772f466083a156DEf5f414` [View](https://plasmascan.to/address/0xD167776D0a28DD6F8c772f466083a156DEf5f414/contract/9745/code) |
| `SwapRegistryFuseEulerV2` | `0x3CfeEABE5c131530b786E12953ca80a80178301D` [View](https://plasmascan.to/address/0x3CfeEABE5c131530b786E12953ca80a80178301D/contract/9745/code) |
| `UniversalReaderBalanceFuses` | `0x221Dad9b50596700893753E4331289768CbF9C5F` [View](https://plasmascan.to/address/0x221Dad9b50596700893753E4331289768CbF9C5F/contract/9745/code) |
| `UniversalTokenSwapperEthFuse` | `0xf0E746C2B9EbcC6E8a64771cDCdf6777E28D1819` [View](https://plasmascan.to/address/0xf0E746C2B9EbcC6E8a64771cDCdf6777E28D1819/contract/9745/code) |
| `UniversalTokenSwapperEthFuseV2` | `0x94c2C043d22D7a8fBC1911c916478937c3596aBa` [View](https://plasmascan.to/address/0x94c2C043d22D7a8fBC1911c916478937c3596aBa/contract/9745/code) |
| `UniversalTokenSwapperFuse` | `0xcF0876B5CF768acB73159B20A46dd424C96Fde15` [View](https://plasmascan.to/address/0xcF0876B5CF768acB73159B20A46dd424C96Fde15/contract/9745/code) |
| `UniversalTokenSwapperFuseV2` | `0x419BDbb584f9Ed96795f5CDDCAd3320E251D4B9e` [View](https://plasmascan.to/address/0x419BDbb584f9Ed96795f5CDDCAd3320E251D4B9e/contract/9745/code) |
| `VeloraSwapperFuse` | `0x420b463DeF774c0a4292D3473a14AcC57233A37D` [View](https://plasmascan.to/address/0x420b463DeF774c0a4292D3473a14AcC57233A37D/contract/9745/code) |

#### Plasma Older Fuses Versions

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `SupplyFuseErc4626Market1` | `0xFb645f6581C57cc139F1af21026Ad0737F7338A2` [View](https://plasmascan.to/address/0xFb645f6581C57cc139F1af21026Ad0737F7338A2/contract/9745/code) |
| `SupplyFuseEulerV2` | `0xe0497Ffee6cdf82e87b011BF44090e4ec1269E70` [View](https://plasmascan.to/address/0xe0497Ffee6cdf82e87b011BF44090e4ec1269E70/contract/9745/code) |

### Avalanche Fuses

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `AaveV3WithPriceOracleMiddlewareBalanceFuse` | `0x563DFc4b7629364f0a992aaa4c87e87e95ce9fB0` [View](https://snowscan.xyz/address/0x563DFc4b7629364f0a992aaa4c87e87e95ce9fB0#code) |
| `AsyncActionBalanceFuse` | `0x489EfE72bcd37b9FFc9AF6e5874D5896cDa70b75` [View](https://snowscan.xyz/address/0x489EfE72bcd37b9FFc9AF6e5874D5896cDa70b75#code) |
| `AsyncActionFuse` | `0x9bb49D308edF068C4c667Dd9B4030EdFe298dfEd` [View](https://snowscan.xyz/address/0x9bb49D308edF068C4c667Dd9B4030EdFe298dfEd#code) |
| `BalanceFuseBurnRequestFee` | `0x630ca75385d20ac9dBdf9329E1a00504c4d50B02` [View](https://snowscan.xyz/address/0x630ca75385d20ac9dBdf9329E1a00504c4d50B02#code) |
| `BalanceFuseErc20` | `0x5127C36f68c3fb4Bf3f1c6C0e8d06fa0367148f1` [View](https://snowscan.xyz/address/0x5127C36f68c3fb4Bf3f1c6C0e8d06fa0367148f1#code) |
| `BalanceFuseErc4626Market1` | `0xC557cFecd78EaD2bA790ac266e54aC0FB0429Ae5` [View](https://snowscan.xyz/address/0xC557cFecd78EaD2bA790ac266e54aC0FB0429Ae5#code) |
| `BalanceFuseErc4626Market2` | `0x5860F54354c479F536cA0944448fea50caA48388` [View](https://snowscan.xyz/address/0x5860F54354c479F536cA0944448fea50caA48388#code) |
| `BalanceFuseErc4626Market3` | `0x4094282E2A288FbB1161e5247619cfeE19cb098f` [View](https://snowscan.xyz/address/0x4094282E2A288FbB1161e5247619cfeE19cb098f#code) |
| `BalanceFuseErc4626Market4` | `0x670Db58B0B0F7D9C2EFf41b27Ab32b635ACF3d1b` [View](https://snowscan.xyz/address/0x670Db58B0B0F7D9C2EFf41b27Ab32b635ACF3d1b#code) |
| `BalanceFuseErc4626Market5` | `0x51530294dB0eCCE8807fdFc2C008d6756f70Cc5E` [View](https://snowscan.xyz/address/0x51530294dB0eCCE8807fdFc2C008d6756f70Cc5E#code) |
| `BalanceFuseEulerV2` | `0x2426946D65939eF2C750425265Ef0ab60c1CcCD6` [View](https://snowscan.xyz/address/0x2426946D65939eF2C750425265Ef0ab60c1CcCD6#code) |
| `BalanceFuseOdosSwapper` | `0x7ee20e2a5b8f11E8E8139f0af5865a86700aC810` [View](https://snowscan.xyz/address/0x7ee20e2a5b8f11E8E8139f0af5865a86700aC810#code) |
| `BalanceFuseUniversalTokenSwapper` | `0xd2b20152ca1EAfdE72161891053E17e9f68Ca583` [View](https://snowscan.xyz/address/0xd2b20152ca1EAfdE72161891053E17e9f68Ca583#code) |
| `BalanceFuseUniversalTokenSwapperV2` | `0xD0557fCAad2741c1Dc76850E9839BbDC2dB68Df4` [View](https://snowscan.xyz/address/0xD0557fCAad2741c1Dc76850E9839BbDC2dB68Df4#code) |
| `BalanceFuseVeloraSwapper` | `0x69852A30AAbD24A572DE491292ACe016D6370346` [View](https://snowscan.xyz/address/0x69852A30AAbD24A572DE491292ACe016D6370346#code) |
| `BatchFuseEulerV2` | `0xC589A38893E7Fced79505055C305402B60d16201` [View](https://snowscan.xyz/address/0xC589A38893E7Fced79505055C305402B60d16201#code) |
| `BorrowFuseAaveV3` | `0x27049822E8F40D194Ac5A0b0107255Ec12cd4e82` [View](https://snowscan.xyz/address/0x27049822E8F40D194Ac5A0b0107255Ec12cd4e82#code) |
| `BorrowFuseEulerV2` | `0x9EC82D04221F3e402039f406A47e4BA444e2e9b7` [View](https://snowscan.xyz/address/0x9EC82D04221F3e402039f406A47e4BA444e2e9b7#code) |
| `BurnRequestFeeFuse` | `0x248df281F63a36683Dbc5EEcD4085c46fce62d99` [View](https://snowscan.xyz/address/0x248df281F63a36683Dbc5EEcD4085c46fce62d99#code) |
| `BurnRequestFeeFuseV2` | `0xd8785Bb9E1299bD8c84AD70BCeCa71CF720aE918` [View](https://snowscan.xyz/address/0xd8785Bb9E1299bD8c84AD70BCeCa71CF720aE918#code) |
| `CollateralFuseEulerV2` | `0x4a75987699917c5f09152b6A9217f6f6431e6E48` [View](https://snowscan.xyz/address/0x4a75987699917c5f09152b6A9217f6f6431e6E48#code) |
| `ConfigureInstantWithdrawalFuse` | `0x1F01Ee3c7fC894e6A1A80823Dd21f6Ba3B04db7d` [View](https://snowscan.xyz/address/0x1F01Ee3c7fC894e6A1A80823Dd21f6Ba3B04db7d#code) |
| `ControllerFuseEulerV2` | `0x8E906e5bB9Ca0CCd4a395AABe09b0F5cfB6A0c9a` [View](https://snowscan.xyz/address/0x8E906e5bB9Ca0CCd4a395AABe09b0F5cfB6A0c9a#code) |
| `FuseRequestSharesPlasmaVaultV2` | `0xe182c022427A308CffE7996cBE5dC455A6c253De` [View](https://snowscan.xyz/address/0xe182c022427A308CffE7996cBE5dC455A6c253De#code) |
| `MerklClaimFuse` | `0xA0649092B6010384556639b4DDA31C7Fff9Fa10e` [View](https://snowscan.xyz/address/0xA0649092B6010384556639b4DDA31C7Fff9Fa10e#code) |
| `OdosSwapperFuse` | `0xE0DF9D7124378D9a4a1B9714bA0D678BD02e7e44` [View](https://snowscan.xyz/address/0xE0DF9D7124378D9a4a1B9714bA0D678BD02e7e44#code) |
| `RequestFeeRefundFuse` | `0x7cE186B43405f6E1bfa963a509f5956E665F4CAB` [View](https://snowscan.xyz/address/0x7cE186B43405f6E1bfa963a509f5956E665F4CAB#code) |
| `RewardEulerTokenClaimFuse` | `0x1aD73a5959423400216d93c87171DDD8015046E2` [View](https://snowscan.xyz/address/0x1aD73a5959423400216d93c87171DDD8015046E2#code) |
| `SiloV2BalanceFuse` | `0xc4D09e234E725cCcb594C441b9eE64e3D6204c81` [View](https://snowscan.xyz/address/0xc4D09e234E725cCcb594C441b9eE64e3D6204c81#code) |
| `SiloV2BorrowFuse` | `0x05f9114c3F1975d62e32043eee01BA57c2Ad3f71` [View](https://snowscan.xyz/address/0x05f9114c3F1975d62e32043eee01BA57c2Ad3f71#code) |
| `SiloV2SupplyBorrowableCollateralFuse` | `0x86b7433372E9508f5C3906C8655cc2F6f5B5E3e6` [View](https://snowscan.xyz/address/0x86b7433372E9508f5C3906C8655cc2F6f5B5E3e6#code) |
| `SiloV2SupplyNonBorrowableCollateralFuse` | `0xe606e7307f22F7Dc1d902844d353F51fc57bA955` [View](https://snowscan.xyz/address/0xe606e7307f22F7Dc1d902844d353F51fc57bA955#code) |
| `SupplyFuseAaveV3` | `0x97e36bA4d86824738c83b91b7b983d36c75a1946` [View](https://snowscan.xyz/address/0x97e36bA4d86824738c83b91b7b983d36c75a1946#code) |
| `SupplyFuseErc4626Market1` | `0x8b3F83c8B1834B47aF0967c02F06d7e8b62c68A9` [View](https://snowscan.xyz/address/0x8b3F83c8B1834B47aF0967c02F06d7e8b62c68A9#code) |
| `SupplyFuseErc4626Market2` | `0x06c1b3995cE9712dCbe6483f8FBED1C9268CE4ea` [View](https://snowscan.xyz/address/0x06c1b3995cE9712dCbe6483f8FBED1C9268CE4ea#code) |
| `SupplyFuseErc4626Market3` | `0x63B6449484d48A130878492d86C617B1755A95F7` [View](https://snowscan.xyz/address/0x63B6449484d48A130878492d86C617B1755A95F7#code) |
| `SupplyFuseErc4626Market4` | `0xa6283B9B2c9271D17662C98a61dc085408E0eEe2` [View](https://snowscan.xyz/address/0xa6283B9B2c9271D17662C98a61dc085408E0eEe2#code) |
| `SupplyFuseErc4626Market5` | `0x24bAe8C6405d3cd3486562f11b865D95bD497D58` [View](https://snowscan.xyz/address/0x24bAe8C6405d3cd3486562f11b865D95bD497D58#code) |
| `SupplyFuseEulerV2` | `0x13466479fcdB6D49ee73547f8520dE36E2D95fE2` [View](https://snowscan.xyz/address/0x13466479fcdB6D49ee73547f8520dE36E2D95fE2#code) |
| `SwapDeployFuseEulerV2` | `0x74e3577348478602268AD5C7667f148AA07Fe226` [View](https://snowscan.xyz/address/0x74e3577348478602268AD5C7667f148AA07Fe226#code) |
| `SwapFuseUniversalTokenSwapper` | `0xA9daB41f304A64C5b81d504DaE30b4b41b68C80B` [View](https://snowscan.xyz/address/0xA9daB41f304A64C5b81d504DaE30b4b41b68C80B#code) |
| `SwapFuseUniversalTokenSwapperEth` | `0x4Bfde040f9325E5154c3984547945165544d4023` [View](https://snowscan.xyz/address/0x4Bfde040f9325E5154c3984547945165544d4023#code) |
| `SwapFuseUniversalTokenSwapperWithVerification` | `0x40527fEb6f2C7a209C35fa18f1e71d311aa5861D` [View](https://snowscan.xyz/address/0x40527fEb6f2C7a209C35fa18f1e71d311aa5861D#code) |
| `SwapFuseUniversalTokenSwapperWithVerificationV2` | `0x7bF509D7f857a450C903FeDfa286008Db366E584` [View](https://snowscan.xyz/address/0x7bF509D7f857a450C903FeDfa286008Db366E584#code) |
| `SwapReconfigureFuseEulerV2` | `0x76FaE7756C36b821Fa45AEd8c4Eb9D43828155B3` [View](https://snowscan.xyz/address/0x76FaE7756C36b821Fa45AEd8c4Eb9D43828155B3#code) |
| `SwapRegistryFuseEulerV2` | `0x518cCae6D6C659435D258Ae9b49AC4930c857818` [View](https://snowscan.xyz/address/0x518cCae6D6C659435D258Ae9b49AC4930c857818#code) |
| `UniversalReaderBalanceFuses` | `0x4F78F29Ac7078A2B6A0D73820DD2E88C90E3683e` [View](https://snowscan.xyz/address/0x4F78F29Ac7078A2B6A0D73820DD2E88C90E3683e#code) |
| `UniversalTokenSwapperEthFuse` | `0x14F6aCba7234ed664545cA44dFDf87556718B63b` [View](https://snowscan.xyz/address/0x14F6aCba7234ed664545cA44dFDf87556718B63b#code) |
| `UniversalTokenSwapperEthFuseV2` | `0x3D54755786820822e78Eb3c14b96D5b58CE6071A` [View](https://snowscan.xyz/address/0x3D54755786820822e78Eb3c14b96D5b58CE6071A#code) |
| `UniversalTokenSwapperFuse` | `0x55cae933FCCB8204ad5b6F9847b6a10Dd018871E` [View](https://snowscan.xyz/address/0x55cae933FCCB8204ad5b6F9847b6a10Dd018871E#code) |
| `UniversalTokenSwapperFuseV2` | `0x69A7C0e6F982a87463279a7D552d746A063857A0` [View](https://snowscan.xyz/address/0x69A7C0e6F982a87463279a7D552d746A063857A0#code) |
| `UpdateMarketsBalancesFuse` | `0x07CD709BA9F70890deE10935738FbE35c2CCbff1` [View](https://snowscan.xyz/address/0x07CD709BA9F70890deE10935738FbE35c2CCbff1#code) |
| `VeloraSwapperFuse` | `0xC10BD30e7bfFaa00Df9dfb296Caa19C6d517EFF8` [View](https://snowscan.xyz/address/0xC10BD30e7bfFaa00Df9dfb296Caa19C6d517EFF8#code) |
| `ZeroBalanceFuse` | `0x54De4C9Cd57d9bb6eB592D773b2Cd474E39556C7` [View](https://snowscan.xyz/address/0x54De4C9Cd57d9bb6eB592D773b2Cd474E39556C7#code) |

#### Avalanche Older Fuses Versions

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `SupplyFuseErc4626Market1` | `0x33DdEA6891550EB68b1FE9A5D76b95f70aF634d2` [View](https://snowscan.xyz/address/0x33DdEA6891550EB68b1FE9A5D76b95f70aF634d2#code) |
| `SupplyFuseErc4626Market2` | `0xb5F588e982174f3C15B8896bdAd7525794F560e0` [View](https://snowscan.xyz/address/0xb5F588e982174f3C15B8896bdAd7525794F560e0#code) |
| `SupplyFuseErc4626Market3` | `0xc83BE23f75452514b3c80DC07315B57231D4ff04` [View](https://snowscan.xyz/address/0xc83BE23f75452514b3c80DC07315B57231D4ff04#code) |
| `SupplyFuseErc4626Market4` | `0x3c1983F88b358949a90bA8a51E02A4E3f0E759ad` [View](https://snowscan.xyz/address/0x3c1983F88b358949a90bA8a51E02A4E3f0E759ad#code) |
| `SupplyFuseErc4626Market5` | `0x3D5757A8f9908208C2A728032F4085C62B39C6b0` [View](https://snowscan.xyz/address/0x3D5757A8f9908208C2A728032F4085C62B39C6b0#code) |
| `SupplyFuseEulerV2` | `0xdD02ad9A1d40FE1BA14812729db1272EF42A497F` [View](https://snowscan.xyz/address/0xdD02ad9A1d40FE1BA14812729db1272EF42A497F#code) |

### Katana Fuses

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `AsyncActionBalanceFuse` | `0x09737BFc32E3ab5Bc82494FdE6d7e1A2BFBcA218` [View](https://katanascan.com/address/0x09737BFc32E3ab5Bc82494FdE6d7e1A2BFBcA218#code) |
| `AsyncActionFuse` | `0x3Bd7f4A088Bb444f20ad599874a7C8Cf81a8f567` [View](https://katanascan.com/address/0x3Bd7f4A088Bb444f20ad599874a7C8Cf81a8f567#code) |
| `BalanceFuseBurnRequestFee` | `0xE3E28F04499470bAc1dAc842aEe424a185d14D42` [View](https://katanascan.com/address/0xE3E28F04499470bAc1dAc842aEe424a185d14D42#code) |
| `BalanceFuseErc20` | `0xb81C00eb71a3D629E6f7Ba66a26218c418D438b8` [View](https://katanascan.com/address/0xb81C00eb71a3D629E6f7Ba66a26218c418D438b8#code) |
| `BalanceFuseErc4626Market1` | `0x5F8696C110Ccb3686c8B209Fc61dcf40daf88167` [View](https://katanascan.com/address/0x5F8696C110Ccb3686c8B209Fc61dcf40daf88167#code) |
| `BalanceFuseErc4626Market2` | `0xDF45A0fD4200dE190A45FABCd7F7cD6150b4a0a5` [View](https://katanascan.com/address/0xDF45A0fD4200dE190A45FABCd7F7cD6150b4a0a5#code) |
| `BalanceFuseErc4626Market3` | `0xBf01D7770829ce4834b308633Cc412E0A12434F5` [View](https://katanascan.com/address/0xBf01D7770829ce4834b308633Cc412E0A12434F5#code) |
| `BalanceFuseErc4626Market4` | `0xf57dbdFa3064b87BC1D099432a2b39272b4d2Db2` [View](https://katanascan.com/address/0xf57dbdFa3064b87BC1D099432a2b39272b4d2Db2#code) |
| `BalanceFuseErc4626Market5` | `0x1660786a08b9cB0D50Cbb118a5A89A36D2E801d3` [View](https://katanascan.com/address/0x1660786a08b9cB0D50Cbb118a5A89A36D2E801d3#code) |
| `BalanceFuseFlashLoanMorpho` | `0xAEc739ECA23f98f9Ee561F218D0eCC5cCb4fd43C` [View](https://katanascan.com/address/0xAEc739ECA23f98f9Ee561F218D0eCC5cCb4fd43C#code) |
| `BalanceFuseMetaMorphoMarket0001` | `0xbE7Ee21e34B7175D797A3E9F33832E1439926f71` [View](https://katanascan.com/address/0xbE7Ee21e34B7175D797A3E9F33832E1439926f71#code) |
| `BalanceFuseMorpho` | `0x83790D83C23461cd22429276406C4f09DB885A85` [View](https://katanascan.com/address/0x83790D83C23461cd22429276406C4f09DB885A85#code) |
| `BalanceFuseMorphoLiquidityInMarkets` | `0x70Ed27aEE2dD509bC6BB067d8e2C61A1FE96eCa4` [View](https://katanascan.com/address/0x70Ed27aEE2dD509bC6BB067d8e2C61A1FE96eCa4#code) |
| `BalanceFuseUniversalTokenSwapper` | `0x96393AcF49769a8C2318635fd27ab69F9c92bD1c` [View](https://katanascan.com/address/0x96393AcF49769a8C2318635fd27ab69F9c92bD1c#code) |
| `BalanceFuseUniversalTokenSwapperV2` | `0x87dF04464459Bfb377aFB130aD3Fd98A0957C0b1` [View](https://katanascan.com/address/0x87dF04464459Bfb377aFB130aD3Fd98A0957C0b1#code) |
| `BorrowFuseMorpho` | `0x08095Aef82A5B33b5B478d254052618A5366cd78` [View](https://katanascan.com/address/0x08095Aef82A5B33b5B478d254052618A5366cd78#code) |
| `BurnRequestFeeFuse` | `0x44D368e85f419C59aC01b7270D234d8BF19Df36e` [View](https://katanascan.com/address/0x44D368e85f419C59aC01b7270D234d8BF19Df36e#code) |
| `BurnRequestFeeFuseV2` | `0xBd6f1B9408B52e1371594Ef70D58dA49385e130b` [View](https://katanascan.com/address/0xBd6f1B9408B52e1371594Ef70D58dA49385e130b#code) |
| `ClaimRewardsFuseMorpho` | `0x368C4D59d7432603A86999e4f77c43E7666813BE` [View](https://katanascan.com/address/0x368C4D59d7432603A86999e4f77c43E7666813BE#code) |
| `CollateralFuseMorpho` | `0xda9a20690a185DAA3b0fD198C6232234835B6929` [View](https://katanascan.com/address/0xda9a20690a185DAA3b0fD198C6232234835B6929#code) |
| `ConfigureInstantWithdrawalFuse` | `0x53803356a73a4625724B533d169957a08CFE8ff7` [View](https://katanascan.com/address/0x53803356a73a4625724B533d169957a08CFE8ff7#code) |
| `FlashloanFuseMorpho` | `0x4D9d1015F7a862D1b7690FFC0B16f3A4518a479e` [View](https://katanascan.com/address/0x4D9d1015F7a862D1b7690FFC0B16f3A4518a479e#code) |
| `FuseRedeemFromRequestPlasmaVaultMarket1` | `0x818917B635d0ba67bAF64939ed70947306f2f042` [View](https://katanascan.com/address/0x818917B635d0ba67bAF64939ed70947306f2f042#code) |
| `FuseRequestSharesPlasmaVaultMarket1` | `0x047806ae79e7C89a18e0F4AD98f8EDaCA27cd180` [View](https://katanascan.com/address/0x047806ae79e7C89a18e0F4AD98f8EDaCA27cd180#code) |
| `FuseRequestSharesPlasmaVaultV2` | `0xe0A80508dE0c9CED25E9EB8EFbA2e37C683Ad459` [View](https://katanascan.com/address/0xe0A80508dE0c9CED25E9EB8EFbA2e37C683Ad459#code) |
| `MerklClaimFuse` | `0xF4278e62a6B5A45E378e6692C7Aa9C7291E7ce36` [View](https://katanascan.com/address/0xF4278e62a6B5A45E378e6692C7Aa9C7291E7ce36#code) |
| `PlasmaVaultBalanceAssetsValidationFuse` | `0xA4C9BE8f5DC9024351c0F7F48D27344Cf37bb59f` [View](https://katanascan.com/address/0xA4C9BE8f5DC9024351c0F7F48D27344Cf37bb59f#code) |
| `RequestFeeRefundFuse` | `0x1584f53b30ff843A70A33B09363e26ddd26547A2` [View](https://katanascan.com/address/0x1584f53b30ff843A70A33B09363e26ddd26547A2#code) |
| `SupplyFuseErc4626Market1` | `0xb05770874500c7dC981AF26AFb95C7656e2545c5` [View](https://katanascan.com/address/0xb05770874500c7dC981AF26AFb95C7656e2545c5#code) |
| `SupplyFuseErc4626Market2` | `0x0CE24b8C95B360baABbBBc95090a120c33D56151` [View](https://katanascan.com/address/0x0CE24b8C95B360baABbBBc95090a120c33D56151#code) |
| `SupplyFuseErc4626Market3` | `0x7ecA2488f171B55238585049fB9eAd8f91038781` [View](https://katanascan.com/address/0x7ecA2488f171B55238585049fB9eAd8f91038781#code) |
| `SupplyFuseErc4626Market4` | `0x03eb6722d7b4fAeB5e5B2507D309542b39be746B` [View](https://katanascan.com/address/0x03eb6722d7b4fAeB5e5B2507D309542b39be746B#code) |
| `SupplyFuseErc4626Market5` | `0xf3891Ccb8801F76106d133401C2fF8b9cD299e65` [View](https://katanascan.com/address/0xf3891Ccb8801F76106d133401C2fF8b9cD299e65#code) |
| `SupplyFuseMetaMorphoMarket0001` | `0x15ae2B6E0e7591b29Cb701b9cfCd40Dd02b5569A` [View](https://katanascan.com/address/0x15ae2B6E0e7591b29Cb701b9cfCd40Dd02b5569A#code) |
| `SupplyFuseMorpho` | `0xC66c3F5cC5e1550A0Ff960c06D630A2FBB80E19d` [View](https://katanascan.com/address/0xC66c3F5cC5e1550A0Ff960c06D630A2FBB80E19d#code) |
| `SupplyFuseMorphoLiquidityInMarkets` | `0x1f657229ec2D261be7dCD63ca82abed334d1f28b` [View](https://katanascan.com/address/0x1f657229ec2D261be7dCD63ca82abed334d1f28b#code) |
| `SwapFuseUniversalTokenSwapperWithVerification` | `0xCB2a3868aE6271Bef43E785303e1c1A3fe3A6336` [View](https://katanascan.com/address/0xCB2a3868aE6271Bef43E785303e1c1A3fe3A6336#code) |
| `SwapFuseUniversalTokenSwapperWithVerificationV2` | `0x2DfaB8711c0f5B64Cb484794d6F84e9791F07045` [View](https://katanascan.com/address/0x2DfaB8711c0f5B64Cb484794d6F84e9791F07045#code) |
| `UniversalReaderBalanceFuses` | `0xaBa54310aF826DFE3153f78dB2eaa27eC2Be6758` [View](https://katanascan.com/address/0xaBa54310aF826DFE3153f78dB2eaa27eC2Be6758#code) |
| `UniversalTokenSwapperEthFuse` | `0xCC434EDD069E9f638765b21228C65d245B38E30A` [View](https://katanascan.com/address/0xCC434EDD069E9f638765b21228C65d245B38E30A#code) |
| `UniversalTokenSwapperEthFuseV2` | `0x48D837E769d66b1FeCe76B66A7560a5a749096bf` [View](https://katanascan.com/address/0x48D837E769d66b1FeCe76B66A7560a5a749096bf#code) |
| `UniversalTokenSwapperFuse` | `0x431b0520a01B5ECd516b99F8080aCb79FC7DA143` [View](https://katanascan.com/address/0x431b0520a01B5ECd516b99F8080aCb79FC7DA143#code) |
| `UniversalTokenSwapperFuseV2` | `0x2513bA6f5603217636973F130128fc0372084C1E` [View](https://katanascan.com/address/0x2513bA6f5603217636973F130128fc0372084C1E#code) |
| `UpdateMarketsBalancesFuse` | `0x5b97E7937755939Dba2fdc053068178DBF350c7b` [View](https://katanascan.com/address/0x5b97E7937755939Dba2fdc053068178DBF350c7b#code) |

#### Katana Older Fuses Versions

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `SupplyFuseErc4626Market1` | `0x20c21024716F43a0A51d71a2bD7F9f335E36Bd25` [View](https://katanascan.com/address/0x20c21024716F43a0A51d71a2bD7F9f335E36Bd25#code) |
| `SupplyFuseErc4626Market2` | `0xD05a7431546b1Bc16d9cC0974c382B093B96f5a0` [View](https://katanascan.com/address/0xD05a7431546b1Bc16d9cC0974c382B093B96f5a0#code) |
| `SupplyFuseErc4626Market3` | `0x31D2e3194f7CE240fD8809f9Ef804c7Ba972Dea6` [View](https://katanascan.com/address/0x31D2e3194f7CE240fD8809f9Ef804c7Ba972Dea6#code) |
| `SupplyFuseErc4626Market4` | `0x046F996a7015CEfCB19d309Cc1bc41D492CEC38F` [View](https://katanascan.com/address/0x046F996a7015CEfCB19d309Cc1bc41D492CEC38F#code) |
| `SupplyFuseErc4626Market5` | `0xe758510dc75171aFD74E3381dbC371A5A22702a9` [View](https://katanascan.com/address/0xe758510dc75171aFD74E3381dbC371A5A22702a9#code) |

### Botanix Fuses

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `AsyncActionBalanceFuse` | `0xAb573134382dB1D2fb35a6b90328bdf10F45eC41` [View](https://botanixscan.io/address/0xAb573134382dB1D2fb35a6b90328bdf10F45eC41/contract/3637/code) |
| `AsyncActionFuse` | `0xdD1672Aa9C8f493047D6Ef90Dd8BaeD84c9b0F86` [View](https://botanixscan.io/address/0xdD1672Aa9C8f493047D6Ef90Dd8BaeD84c9b0F86/contract/3637/code) |
| `BalanceFuseBurnRequestFee` | `0xbBDD2a10E84972409BF5430dea35571E18A462Ba` [View](https://botanixscan.io/address/0xbBDD2a10E84972409BF5430dea35571E18A462Ba/contract/3637/code) |
| `BalanceFuseErc20` | `0x4c8167bca33fA7eF513ABF55Eb30B13F840De064` [View](https://botanixscan.io/address/0x4c8167bca33fA7eF513ABF55Eb30B13F840De064/contract/3637/code) |
| `BalanceFuseErc4626Market1` | `0x43d30dA1CC25A6DEbBD008EA8b79DD936f859185` [View](https://botanixscan.io/address/0x43d30dA1CC25A6DEbBD008EA8b79DD936f859185/contract/3637/code) |
| `BalanceFuseErc4626Market2` | `0x338e453839247277911ACce77f4200d4c269EA28` [View](https://botanixscan.io/address/0x338e453839247277911ACce77f4200d4c269EA28/contract/3637/code) |
| `BalanceFuseErc4626Market3` | `0x264e5a5159AE8FAD6bCb6EE832D441b92C2FF908` [View](https://botanixscan.io/address/0x264e5a5159AE8FAD6bCb6EE832D441b92C2FF908/contract/3637/code) |
| `BalanceFuseErc4626Market4` | `0xa91272EA260304eBF71eEc5086234Bab667a4e56` [View](https://botanixscan.io/address/0xa91272EA260304eBF71eEc5086234Bab667a4e56/contract/3637/code) |
| `BalanceFuseErc4626Market5` | `0x7E0F00968566589d6DF5ce1b015E2F73302d2140` [View](https://botanixscan.io/address/0x7E0F00968566589d6DF5ce1b015E2F73302d2140/contract/3637/code) |
| `BalanceFuseFlashLoanMorpho` | `0xe6ea0436F2e0ea270F8F513828ddd5485908e62D` [View](https://botanixscan.io/address/0xe6ea0436F2e0ea270F8F513828ddd5485908e62D/contract/3637/code) |
| `BalanceFuseMetaMorphoMarket0001` | `0x9872bF54a1d8E00D5693764E59D5beBC5F84D4CD` [View](https://botanixscan.io/address/0x9872bF54a1d8E00D5693764E59D5beBC5F84D4CD/contract/3637/code) |
| `BalanceFuseMorpho` | `0xe64E5B5e3e21336a6BA5Cbb0484ca299ac529Bc3` [View](https://botanixscan.io/address/0xe64E5B5e3e21336a6BA5Cbb0484ca299ac529Bc3/contract/3637/code) |
| `BalanceFuseMorphoLiquidityInMarkets` | `0xbb1D27CBB4192A903F07c583AbC04ebFD5f51E71` [View](https://botanixscan.io/address/0xbb1D27CBB4192A903F07c583AbC04ebFD5f51E71/contract/3637/code) |
| `BalanceFuseUniversalTokenSwapper` | `0x1Df59000663348Cc2155e665ac78a158F29810A9` [View](https://botanixscan.io/address/0x1Df59000663348Cc2155e665ac78a158F29810A9/contract/3637/code) |
| `BorrowFuseMorpho` | `0x2C51935f78F46C5aC8E1E6F6EA15fD9f662Fbe7c` [View](https://botanixscan.io/address/0x2C51935f78F46C5aC8E1E6F6EA15fD9f662Fbe7c/contract/3637/code) |
| `BurnRequestFeeFuse` | `0x878116d5890C74a9AcDca5D4D3AF8f6959003b21` [View](https://botanixscan.io/address/0x878116d5890C74a9AcDca5D4D3AF8f6959003b21/contract/3637/code) |
| `BurnRequestFeeFuseV2` | `0x8b82de9FfFB6526C2ad0710697324159139949D1` [View](https://botanixscan.io/address/0x8b82de9FfFB6526C2ad0710697324159139949D1/contract/3637/code) |
| `ClaimRewardsFuseMorpho` | `0xadf30646746b897a0eC7a09064D2F0a10F14923D` [View](https://botanixscan.io/address/0xadf30646746b897a0eC7a09064D2F0a10F14923D/contract/3637/code) |
| `CollateralFuseMorpho` | `0x617e73ae5a042873189c33D8A8456A0121ee8609` [View](https://botanixscan.io/address/0x617e73ae5a042873189c33D8A8456A0121ee8609/contract/3637/code) |
| `ConfigureInstantWithdrawalFuse` | `0x5eb916290582f7F0520acF09F8302efaD4a9c8c9` [View](https://botanixscan.io/address/0x5eb916290582f7F0520acF09F8302efaD4a9c8c9/contract/3637/code) |
| `FlashloanFuseMorpho` | `0x7FaF1ca48a501F161BF613b0eb8EFE9052D96195` [View](https://botanixscan.io/address/0x7FaF1ca48a501F161BF613b0eb8EFE9052D96195/contract/3637/code) |
| `FuseRedeemFromRequestPlasmaVaultMarket1` | `0x9289A9e8726f674e6ae7137f6b17Ac6D3E7D1409` [View](https://botanixscan.io/address/0x9289A9e8726f674e6ae7137f6b17Ac6D3E7D1409/contract/3637/code) |
| `FuseRequestSharesPlasmaVaultMarket1` | `0xbBF6b36262540519Dd58639F08F508906B287C72` [View](https://botanixscan.io/address/0xbBF6b36262540519Dd58639F08F508906B287C72/contract/3637/code) |
| `FuseRequestSharesPlasmaVaultV2` | `0x0878d513fC242D24C47b3a7f45e6aABec3ceA727` [View](https://botanixscan.io/address/0x0878d513fC242D24C47b3a7f45e6aABec3ceA727/contract/3637/code) |
| `PlasmaVaultBalanceAssetsValidationFuse` | `0xca738256E210a0D6A760D448f8Df7de923C688c0` [View](https://botanixscan.io/address/0xca738256E210a0D6A760D448f8Df7de923C688c0/contract/3637/code) |
| `RequestFeeRefundFuse` | `0x72048498eDE292F041F541f202725afE18bec21A` [View](https://botanixscan.io/address/0x72048498eDE292F041F541f202725afE18bec21A/contract/3637/code) |
| `SupplyFuseErc4626Market1` | `0x83B631aB4A70F4d5b871FDcF4cd394C840C478e7` [View](https://botanixscan.io/address/0x83B631aB4A70F4d5b871FDcF4cd394C840C478e7/contract/3637/code) |
| `SupplyFuseErc4626Market2` | `0x53b2Bc613ef1fF7E3A787a77A71EAC05BB3F43C4` [View](https://botanixscan.io/address/0x53b2Bc613ef1fF7E3A787a77A71EAC05BB3F43C4/contract/3637/code) |
| `SupplyFuseErc4626Market3` | `0xb37af5920B04fd6B94eD76c871061E688326851e` [View](https://botanixscan.io/address/0xb37af5920B04fd6B94eD76c871061E688326851e/contract/3637/code) |
| `SupplyFuseErc4626Market4` | `0x13B6058F3f0cf7A8e00a7087EA0638C77AA350B8` [View](https://botanixscan.io/address/0x13B6058F3f0cf7A8e00a7087EA0638C77AA350B8/contract/3637/code) |
| `SupplyFuseErc4626Market5` | `0x5fc54B455240318EcaA6Bbb9f9f129073f67789d` [View](https://botanixscan.io/address/0x5fc54B455240318EcaA6Bbb9f9f129073f67789d/contract/3637/code) |
| `SupplyFuseMetaMorphoMarket0001` | `0xA931bE028Ca0c35f28E744D3644f9376d0e19907` [View](https://botanixscan.io/address/0xA931bE028Ca0c35f28E744D3644f9376d0e19907/contract/3637/code) |
| `SupplyFuseMorpho` | `0x09238A7dB62f9ce6AB3FEEfE1Ee9a89B13a45039` [View](https://botanixscan.io/address/0x09238A7dB62f9ce6AB3FEEfE1Ee9a89B13a45039/contract/3637/code) |
| `SupplyFuseMorphoLiquidityInMarkets` | `0xEe1407d7c9Ea6f355b0Cf37bCaCAF00AE3748093` [View](https://botanixscan.io/address/0xEe1407d7c9Ea6f355b0Cf37bCaCAF00AE3748093/contract/3637/code) |
| `SwapFuseUniversalTokenSwapperWithVerification` | `0x65B98A63e3EDF821562A948367b07464a6527025` [View](https://botanixscan.io/address/0x65B98A63e3EDF821562A948367b07464a6527025/contract/3637/code) |
| `UniversalReaderBalanceFuses` | `0x60770A8CC8E252314f3A88D6F7626Ca194466821` [View](https://botanixscan.io/address/0x60770A8CC8E252314f3A88D6F7626Ca194466821/contract/3637/code) |
| `UniversalTokenSwapperEthFuse` | `0x5a1B280E1bD15D63f639859eC7060e06f4201ecd` [View](https://botanixscan.io/address/0x5a1B280E1bD15D63f639859eC7060e06f4201ecd/contract/3637/code) |
| `UniversalTokenSwapperFuse` | `0x44971B16b4dDA3fdddaff03eb3D55CfeBEa8593c` [View](https://botanixscan.io/address/0x44971B16b4dDA3fdddaff03eb3D55CfeBEa8593c/contract/3637/code) |
| `UpdateMarketsBalancesFuse` | `0x82eB4A8fD471Aa402Bac68F7a9a042547FE0a738` [View](https://botanixscan.io/address/0x82eB4A8fD471Aa402Bac68F7a9a042547FE0a738/contract/3637/code) |

### HyperEVM Fuses

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `AsyncActionBalanceFuse` | `0x3f90c3d1b9EF83D65fc852bB0c33C85c6BD9414b` [View](https://hyperevmscan.io/address/0x3f90c3d1b9EF83D65fc852bB0c33C85c6BD9414b#code) |
| `BalanceFuseBurnRequestFee` | `0xb3F3f951c771Cd6cB1Aee4E4506b86aFB5225e68` [View](https://hyperevmscan.io/address/0xb3F3f951c771Cd6cB1Aee4E4506b86aFB5225e68#code) |
| `BalanceFuseErc20` | `0x57d317872297deC31B95d52EB1a889f0Bfe85c2F` [View](https://hyperevmscan.io/address/0x57d317872297deC31B95d52EB1a889f0Bfe85c2F#code) |
| `BalanceFuseErc4626Market1` | `0x0381B54618562B39c59A9cCDA86b24a5027f15E7` [View](https://hyperevmscan.io/address/0x0381B54618562B39c59A9cCDA86b24a5027f15E7#code) |
| `BalanceFuseErc4626Market2` | `0x20Ae5e2172A26E58A93BB24eAE1e2C35ad88D0cd` [View](https://hyperevmscan.io/address/0x20Ae5e2172A26E58A93BB24eAE1e2C35ad88D0cd#code) |
| `BalanceFuseErc4626Market3` | `0xEE595036F1C872178f24A25b758D54b9E6037003` [View](https://hyperevmscan.io/address/0xEE595036F1C872178f24A25b758D54b9E6037003#code) |
| `BalanceFuseErc4626Market4` | `0xf3De2cbD6B2db65E257a780a4935bf56E799204b` [View](https://hyperevmscan.io/address/0xf3De2cbD6B2db65E257a780a4935bf56E799204b#code) |
| `BalanceFuseErc4626Market5` | `0x297A7ecA79967b1e1f0Ff5c0f59E9149FBaCf0f6` [View](https://hyperevmscan.io/address/0x297A7ecA79967b1e1f0Ff5c0f59E9149FBaCf0f6#code) |
| `BalanceFuseFlashLoanMorpho` | `0x0c781CF422d9929f3B6dE1CB08e03075Fb698c93` [View](https://hyperevmscan.io/address/0x0c781CF422d9929f3B6dE1CB08e03075Fb698c93#code) |
| `BalanceFuseMetaMorphoMarket0001` | `0xec4bfC1Fe7BE9D26750f50C977eC7EC8e5Aa5Bb8` [View](https://hyperevmscan.io/address/0xec4bfC1Fe7BE9D26750f50C977eC7EC8e5Aa5Bb8#code) |
| `BalanceFuseMorpho` | `0x784f0b81AEE9baA7ED7730a7b6F8A92bF4106A7E` [View](https://hyperevmscan.io/address/0x784f0b81AEE9baA7ED7730a7b6F8A92bF4106A7E#code) |
| `BalanceFuseMorphoLiquidityInMarkets` | `0x45d73E38aBD6768293c7061813a0478e434a1844` [View](https://hyperevmscan.io/address/0x45d73E38aBD6768293c7061813a0478e434a1844#code) |
| `BalanceFuseUniversalTokenSwapper` | `0xa97D2B4D323C0Cdb5DdD62D04235ff9e0d8F9576` [View](https://hyperevmscan.io/address/0xa97D2B4D323C0Cdb5DdD62D04235ff9e0d8F9576#code) |
| `BalanceFuseUniversalTokenSwapperV2` | `0x139dc435B3023Afb75FB1ffD1064481e68Ccba19` [View](https://hyperevmscan.io/address/0x139dc435B3023Afb75FB1ffD1064481e68Ccba19#code) |
| `BorrowFuseMorpho` | `0x6D9dDb1c449E91A3FB83f67D6F56E3e8c0bfc21c` [View](https://hyperevmscan.io/address/0x6D9dDb1c449E91A3FB83f67D6F56E3e8c0bfc21c#code) |
| `BurnRequestFeeFuse` | `0xAa2D7a24ff3Dc251e044326ab35e976b352ED613` [View](https://hyperevmscan.io/address/0xAa2D7a24ff3Dc251e044326ab35e976b352ED613#code) |
| `BurnRequestFeeFuseV2` | `0xF86a1B468cd7A6BbAeDf78705DaE40DeDb1d0EAF` [View](https://hyperevmscan.io/address/0xF86a1B468cd7A6BbAeDf78705DaE40DeDb1d0EAF#code) |
| `ClaimRewardsFuseMorpho` | `0xF9Fe01A9Cbe2D3e89d4DAed065bcc408744986f7` [View](https://hyperevmscan.io/address/0xF9Fe01A9Cbe2D3e89d4DAed065bcc408744986f7#code) |
| `CollateralFuseMorpho` | `0x4f9930eDB751AA67191b4fdF1B9B1a7a4eEa392a` [View](https://hyperevmscan.io/address/0x4f9930eDB751AA67191b4fdF1B9B1a7a4eEa392a#code) |
| `ConfigureInstantWithdrawalFuse` | `0x0F2553e4460C2974746908cFDe472a7dC1311dBd` [View](https://hyperevmscan.io/address/0x0F2553e4460C2974746908cFDe472a7dC1311dBd#code) |
| `ExternalStateBalanceFuse` | `0x3E08042B8463028aAE02F3e23Ab9b96D3f2a1F91` [View](https://hyperevmscan.io/address/0x3E08042B8463028aAE02F3e23Ab9b96D3f2a1F91#code) |
| `ExternalStateOperationFuse` | `0x96b2cfE0bdD6d9C6BB6381ae81b92b57AE23E473` [View](https://hyperevmscan.io/address/0x96b2cfE0bdD6d9C6BB6381ae81b92b57AE23E473#code) |
| `ExternalStateRescueFuse` | `0x730c9fFD02D23bbeeD5F9f6ac695DA78AEDccea8` [View](https://hyperevmscan.io/address/0x730c9fFD02D23bbeeD5F9f6ac695DA78AEDccea8#code) |
| `ExternalStateUnpauseFuse` | `0xeeAEB82648a1E25d5484fb33ED7De86f209631e5` [View](https://hyperevmscan.io/address/0xeeAEB82648a1E25d5484fb33ED7De86f209631e5#code) |
| `FlashloanFuseMorpho` | `0x8a2975D8704Fd9F143bDDD05dc73a4e49EFB47f0` [View](https://hyperevmscan.io/address/0x8a2975D8704Fd9F143bDDD05dc73a4e49EFB47f0#code) |
| `FuseRedeemFromRequestPlasmaVaultMarket1` | `0x1E22C137997DaBd4452792516AcDFb402432eAa9` [View](https://hyperevmscan.io/address/0x1E22C137997DaBd4452792516AcDFb402432eAa9#code) |
| `FuseRequestSharesPlasmaVaultMarket1` | `0x0A6aFE06dA41F9D86767C296E5398C65CA3889A4` [View](https://hyperevmscan.io/address/0x0A6aFE06dA41F9D86767C296E5398C65CA3889A4#code) |
| `FuseRequestSharesPlasmaVaultV2` | `0xEA5CE8B0a7734E37285aB087b1a3c4Fef89C15b2` [View](https://hyperevmscan.io/address/0xEA5CE8B0a7734E37285aB087b1a3c4Fef89C15b2#code) |
| `PlasmaVaultBalanceAssetsValidationFuse` | `0x467ef84A334398E2EE41B9838582dBf37dd09673` [View](https://hyperevmscan.io/address/0x467ef84A334398E2EE41B9838582dBf37dd09673#code) |
| `RWABalanceFuse` | `0xbEBc308b954311d8Cb2F95DD8a583Ed7bbB3A9d4` [View](https://hyperevmscan.io/address/0xbEBc308b954311d8Cb2F95DD8a583Ed7bbB3A9d4#code) |
| `RWAOperationFuse` | `0xfaA377b5099267d8e36E2B1Ea288F82681D9bea4` [View](https://hyperevmscan.io/address/0xfaA377b5099267d8e36E2B1Ea288F82681D9bea4#code) |
| `RWARescueFuse` | `0x424A7dc1E631A9410AA6Dc35283503A5befCAA08` [View](https://hyperevmscan.io/address/0x424A7dc1E631A9410AA6Dc35283503A5befCAA08#code) |
| `RWAUnpauseFuse` | `0x534cA9A62C364969398487aF71922E7f51d32443` [View](https://hyperevmscan.io/address/0x534cA9A62C364969398487aF71922E7f51d32443#code) |
| `RequestFeeRefundFuse` | `0xF781acE9A5bf7883123aA4c11e57a9F68Ec3Df52` [View](https://hyperevmscan.io/address/0xF781acE9A5bf7883123aA4c11e57a9F68Ec3Df52#code) |
| `SupplyFuseErc4626Market1` | `0xaaE1253b81ffa5dA5e25bc1ade7A009D9488a2B5` [View](https://hyperevmscan.io/address/0xaaE1253b81ffa5dA5e25bc1ade7A009D9488a2B5#code) |
| `SupplyFuseErc4626Market2` | `0x052A6a2464F8079f778f52b4dCb311EA16B6B439` [View](https://hyperevmscan.io/address/0x052A6a2464F8079f778f52b4dCb311EA16B6B439#code) |
| `SupplyFuseErc4626Market3` | `0x23e1fd6F58546c69c9DBb4a46cC02504b69daa2E` [View](https://hyperevmscan.io/address/0x23e1fd6F58546c69c9DBb4a46cC02504b69daa2E#code) |
| `SupplyFuseErc4626Market4` | `0x778a9cFdBA586375912b069ded5d79Aea600B323` [View](https://hyperevmscan.io/address/0x778a9cFdBA586375912b069ded5d79Aea600B323#code) |
| `SupplyFuseErc4626Market5` | `0xb766Dd4Bb3B3B9219A1a9EaE5e6f32a52Df5141F` [View](https://hyperevmscan.io/address/0xb766Dd4Bb3B3B9219A1a9EaE5e6f32a52Df5141F#code) |
| `SupplyFuseMetaMorphoMarket0001` | `0xcd2aC71ab37435A070D0950e0aDe9C905b8D98e2` [View](https://hyperevmscan.io/address/0xcd2aC71ab37435A070D0950e0aDe9C905b8D98e2#code) |
| `SupplyFuseMorpho` | `0x0f04c4AF37dF8E6E0603741718bF55945B206cd8` [View](https://hyperevmscan.io/address/0x0f04c4AF37dF8E6E0603741718bF55945B206cd8#code) |
| `SupplyFuseMorphoLiquidityInMarkets` | `0xE03D314904296FE7e463AC958E0116819A88d3EE` [View](https://hyperevmscan.io/address/0xE03D314904296FE7e463AC958E0116819A88d3EE#code) |
| `SupplyFuseMorphoWithCallBackData` | `0xD1623eC815A66C57Bd1f4D78EDae68193F1Aa6E4` [View](https://hyperevmscan.io/address/0xD1623eC815A66C57Bd1f4D78EDae68193F1Aa6E4#code) |
| `UniversalReaderBalanceFuses` | `0x778f16cDeBf85C45F104486C7e7E239Fc1132A6d` [View](https://hyperevmscan.io/address/0x778f16cDeBf85C45F104486C7e7E239Fc1132A6d#code) |
| `UniversalTokenSwapperFuse` | `0xeCE04243Cce5f578dbcaA1B7f478701A233CB87d` [View](https://hyperevmscan.io/address/0xeCE04243Cce5f578dbcaA1B7f478701A233CB87d#code) |
| `UniversalTokenSwapperFuseV2` | `0xf7B343351bDD33E9Ec09f7ad4051887281779c69` [View](https://hyperevmscan.io/address/0xf7B343351bDD33E9Ec09f7ad4051887281779c69#code) |
| `UpdateMarketsBalancesFuse` | `0x280cC2e768cCEcd4ba11DfCC439c7Fe986d3C39b` [View](https://hyperevmscan.io/address/0x280cC2e768cCEcd4ba11DfCC439c7Fe986d3C39b#code) |

### Robinhood Fuses

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `AsyncActionBalanceFuse` | `0x913768BA51012B828b8C32aF824Ae1d556b470f6` [View](https://robinhoodchain.blockscout.com/address/0x913768BA51012B828b8C32aF824Ae1d556b470f6#code) |
| `AsyncActionFuse` | `0x77346d9e0bb05D9f948f5b4a36Af3f64D22334eC` [View](https://robinhoodchain.blockscout.com/address/0x77346d9e0bb05D9f948f5b4a36Af3f64D22334eC#code) |
| `BalanceFuseBurnRequestFee` | `0xFf28D69DF24d5957576461104b5521c447D863Ef` [View](https://robinhoodchain.blockscout.com/address/0xFf28D69DF24d5957576461104b5521c447D863Ef#code) |
| `BalanceFuseErc20` | `0xF043A3D1B4D37Af399dE2967005b2b99E90Be7e6` [View](https://robinhoodchain.blockscout.com/address/0xF043A3D1B4D37Af399dE2967005b2b99E90Be7e6#code) |
| `BalanceFuseErc4626Market1` | `0x6256A0B3896b68a2bF3eBC2171EB0A078a1074de` [View](https://robinhoodchain.blockscout.com/address/0x6256A0B3896b68a2bF3eBC2171EB0A078a1074de#code) |
| `BalanceFuseErc4626Market2` | `0x52477eDA037Cd4831370812C110F099a633B5da4` [View](https://robinhoodchain.blockscout.com/address/0x52477eDA037Cd4831370812C110F099a633B5da4#code) |
| `BalanceFuseErc4626Market3` | `0xCc88Bc6C36b2FF3C4E6aF94C022f4Cae107a029d` [View](https://robinhoodchain.blockscout.com/address/0xCc88Bc6C36b2FF3C4E6aF94C022f4Cae107a029d#code) |
| `BalanceFuseErc4626Market4` | `0x0D94aae4ce722991E07bC3B2bdE7a77D83bece69` [View](https://robinhoodchain.blockscout.com/address/0x0D94aae4ce722991E07bC3B2bdE7a77D83bece69#code) |
| `BalanceFuseErc4626Market5` | `0x1bEd1845f828f200B00B48E1Ec2614f50C84Bc8c` [View](https://robinhoodchain.blockscout.com/address/0x1bEd1845f828f200B00B48E1Ec2614f50C84Bc8c#code) |
| `BalanceFuseFlashLoanMorpho` | `0xFAfDFf147C0f885fD3aECC49dAa86F866ba6fa32` [View](https://robinhoodchain.blockscout.com/address/0xFAfDFf147C0f885fD3aECC49dAa86F866ba6fa32#code) |
| `BalanceFuseMetaMorphoMarket0001` | `0xD93E718CAEb6e719530Ba87d6d399837a439C7d7` [View](https://robinhoodchain.blockscout.com/address/0xD93E718CAEb6e719530Ba87d6d399837a439C7d7#code) |
| `BalanceFuseMorpho` | `0x037aE96AE03f275200C34e9790359E4e4846Ff24` [View](https://robinhoodchain.blockscout.com/address/0x037aE96AE03f275200C34e9790359E4e4846Ff24#code) |
| `BalanceFuseMorphoLiquidityInMarkets` | `0x7F9c39992cB15f994421718631fdd62c648C388B` [View](https://robinhoodchain.blockscout.com/address/0x7F9c39992cB15f994421718631fdd62c648C388B#code) |
| `BalanceFuseUniversalTokenSwapper` | `0xa094e4b79Bd55D8CcF3c18b9FF98c50d7A3e2D0F` [View](https://robinhoodchain.blockscout.com/address/0xa094e4b79Bd55D8CcF3c18b9FF98c50d7A3e2D0F#code) |
| `BalanceFuseUniversalTokenSwapperV2` | `0xD6B361578162C259c77281c6CF1500BB378a0857` [View](https://robinhoodchain.blockscout.com/address/0xD6B361578162C259c77281c6CF1500BB378a0857#code) |
| `BorrowFuseMorpho` | `0x2f54C5e1ce07B2ff11F4D3ff3226f98559541807` [View](https://robinhoodchain.blockscout.com/address/0x2f54C5e1ce07B2ff11F4D3ff3226f98559541807#code) |
| `BurnRequestFeeFuse` | `0xA4f285473f97f404Cbb4675406bcacc8c59Ae4Eb` [View](https://robinhoodchain.blockscout.com/address/0xA4f285473f97f404Cbb4675406bcacc8c59Ae4Eb#code) |
| `BurnRequestFeeFuseV2` | `0x4806712017A1Ab1aDa62DfBE49adEF01300298cd` [View](https://robinhoodchain.blockscout.com/address/0x4806712017A1Ab1aDa62DfBE49adEF01300298cd#code) |
| `ClaimRewardsFuseMorpho` | `0xdcfa32CCEDE9FAec6127508be2F1f8E619F0d089` [View](https://robinhoodchain.blockscout.com/address/0xdcfa32CCEDE9FAec6127508be2F1f8E619F0d089#code) |
| `CollateralFuseMorpho` | `0x4AB22a4EEB6efc3946AA9bbc5Df0748b1Bf6D24E` [View](https://robinhoodchain.blockscout.com/address/0x4AB22a4EEB6efc3946AA9bbc5Df0748b1Bf6D24E#code) |
| `ConfigureInstantWithdrawalFuse` | `0x7Cc36332d6B79a9B1576bbc153e19fE0066c9621` [View](https://robinhoodchain.blockscout.com/address/0x7Cc36332d6B79a9B1576bbc153e19fE0066c9621#code) |
| `FlashloanFuseMorpho` | `0x6B1F2B6B5cD12b0f93955b7D7394194b31024398` [View](https://robinhoodchain.blockscout.com/address/0x6B1F2B6B5cD12b0f93955b7D7394194b31024398#code) |
| `FuseRedeemFromRequestPlasmaVaultMarket1` | `0x834f9835c6F29EB55C10AEAA8c7AE8FeF069C8A6` [View](https://robinhoodchain.blockscout.com/address/0x834f9835c6F29EB55C10AEAA8c7AE8FeF069C8A6#code) |
| `FuseRequestSharesPlasmaVaultMarket1` | `0x4F830d35864Fe9e1De679Ee69fb02dba1CC0ed6A` [View](https://robinhoodchain.blockscout.com/address/0x4F830d35864Fe9e1De679Ee69fb02dba1CC0ed6A#code) |
| `FuseRequestSharesPlasmaVaultV2` | `0x131F37bcBB5B211ecc5327b139e835B72847093C` [View](https://robinhoodchain.blockscout.com/address/0x131F37bcBB5B211ecc5327b139e835B72847093C#code) |
| `PlasmaVaultBalanceAssetsValidationFuse` | `0xAcd51DA8640C3eEe8b2FB8c00928e8977Cb71Fa8` [View](https://robinhoodchain.blockscout.com/address/0xAcd51DA8640C3eEe8b2FB8c00928e8977Cb71Fa8#code) |
| `RequestFeeRefundFuse` | `0xB43Dbb95cFE90CE750309348ccb5Ed80fD463701` [View](https://robinhoodchain.blockscout.com/address/0xB43Dbb95cFE90CE750309348ccb5Ed80fD463701#code) |
| `SupplyFuseErc4626Market1` | `0x8862B33f492b0Eb69C76A4FcEbbBF0590074BF66` [View](https://robinhoodchain.blockscout.com/address/0x8862B33f492b0Eb69C76A4FcEbbBF0590074BF66#code) |
| `SupplyFuseErc4626Market2` | `0x6CA93Fd89109D56FfAE0417151Bf51093C64448b` [View](https://robinhoodchain.blockscout.com/address/0x6CA93Fd89109D56FfAE0417151Bf51093C64448b#code) |
| `SupplyFuseErc4626Market3` | `0x529335c8e34313169093a5ecaAa1188d81561660` [View](https://robinhoodchain.blockscout.com/address/0x529335c8e34313169093a5ecaAa1188d81561660#code) |
| `SupplyFuseErc4626Market4` | `0xFD18a06a0c12d13f01fC2c9200a8113C6f5b8eF2` [View](https://robinhoodchain.blockscout.com/address/0xFD18a06a0c12d13f01fC2c9200a8113C6f5b8eF2#code) |
| `SupplyFuseErc4626Market5` | `0x5A8154b51422C4c2432E4B23C0FCF5b7Ca3af202` [View](https://robinhoodchain.blockscout.com/address/0x5A8154b51422C4c2432E4B23C0FCF5b7Ca3af202#code) |
| `SupplyFuseMetaMorphoMarket0001` | `0x80F3E6769Dfac33768B59C60454770Ee7eCde793` [View](https://robinhoodchain.blockscout.com/address/0x80F3E6769Dfac33768B59C60454770Ee7eCde793#code) |
| `SupplyFuseMorpho` | `0xd644142F2F8be91C9F44E30420c2cF135Be75D96` [View](https://robinhoodchain.blockscout.com/address/0xd644142F2F8be91C9F44E30420c2cF135Be75D96#code) |
| `SupplyFuseMorphoLiquidityInMarkets` | `0x26D6b52B51458C8f62f88227ad1d05EE9359a680` [View](https://robinhoodchain.blockscout.com/address/0x26D6b52B51458C8f62f88227ad1d05EE9359a680#code) |
| `SupplyFuseMorphoWithCallBackData` | `0x087B036cCf530eFA01295Af746B6bC2f767dDb9C` [View](https://robinhoodchain.blockscout.com/address/0x087B036cCf530eFA01295Af746B6bC2f767dDb9C#code) |
| `SwapFuseUniversalTokenSwapperWithVerification` | `0x73c0F7ee56AFC5D3B89B2f38C8244BCaAA40C1d4` [View](https://robinhoodchain.blockscout.com/address/0x73c0F7ee56AFC5D3B89B2f38C8244BCaAA40C1d4#code) |
| `SwapFuseUniversalTokenSwapperWithVerificationV2` | `0x0C5CC41D4B188e356FcD3743F758487Cd7C6259A` [View](https://robinhoodchain.blockscout.com/address/0x0C5CC41D4B188e356FcD3743F758487Cd7C6259A#code) |
| `UniversalReaderBalanceFuses` | `0xb9136b4fd17C26677B3A7E7F4A4c1ad47d0F3Cb9` [View](https://robinhoodchain.blockscout.com/address/0xb9136b4fd17C26677B3A7E7F4A4c1ad47d0F3Cb9#code) |
| `UniversalTokenSwapperEthFuse` | `0xf7037eeBEDaFA5a03e52133b49Ab8d2F87eA0355` [View](https://robinhoodchain.blockscout.com/address/0xf7037eeBEDaFA5a03e52133b49Ab8d2F87eA0355#code) |
| `UniversalTokenSwapperEthFuseV2` | `0x5C06d98425A7F2b0896Dc301FaB6A07076A6B88b` [View](https://robinhoodchain.blockscout.com/address/0x5C06d98425A7F2b0896Dc301FaB6A07076A6B88b#code) |
| `UniversalTokenSwapperFuse` | `0x9C04C5352BB17493be52f84c1Ed30E57492f1c5b` [View](https://robinhoodchain.blockscout.com/address/0x9C04C5352BB17493be52f84c1Ed30E57492f1c5b#code) |
| `UniversalTokenSwapperFuseV2` | `0x7d249a3e409e2cd8e783661dA115aBc0b529Aa64` [View](https://robinhoodchain.blockscout.com/address/0x7d249a3e409e2cd8e783661dA115aBc0b529Aa64#code) |
| `UpdateMarketsBalancesFuse` | `0x25fBb7124dCf00434510787B332F8634533c94AA` [View](https://robinhoodchain.blockscout.com/address/0x25fBb7124dCf00434510787B332F8634533c94AA#code) |

### Monad Fuses

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `AaveV3CollateralFuse` | `0x87Ae650f3823227B10A5273939c8e94362f1Bb49` [View](https://monadscan.com/address/0x87Ae650f3823227B10A5273939c8e94362f1Bb49#code) |
| `AaveV3WithPriceOracleMiddlewareBalanceFuse` | `0x651371Cd077aFdaFb0F954fa5Db1563Aa2e0e81A` [View](https://monadscan.com/address/0x651371Cd077aFdaFb0F954fa5Db1563Aa2e0e81A#code) |
| `AsyncActionBalanceFuse` | `0x8fb894eDa39DDf145e80Abcac4c4553273D37383` [View](https://monadscan.com/address/0x8fb894eDa39DDf145e80Abcac4c4553273D37383#code) |
| `AsyncActionFuse` | `0x261e27ee82e3903FcfDF1058ae66b1f514f43fF5` [View](https://monadscan.com/address/0x261e27ee82e3903FcfDF1058ae66b1f514f43fF5#code) |
| `BalanceFuseBurnRequestFee` | `0x1F36Ec1fa7c9b15130d7810f8A8977A1920c155b` [View](https://monadscan.com/address/0x1F36Ec1fa7c9b15130d7810f8A8977A1920c155b#code) |
| `BalanceFuseErc20` | `0xD384dFc6b63Cf4617e5954364aeA67cBADA5d8F7` [View](https://monadscan.com/address/0xD384dFc6b63Cf4617e5954364aeA67cBADA5d8F7#code) |
| `BalanceFuseErc4626Market1` | `0x43003Bff3242b26FBE880942896f597873F8B71B` [View](https://monadscan.com/address/0x43003Bff3242b26FBE880942896f597873F8B71B#code) |
| `BalanceFuseErc4626Market2` | `0x62804a5361F1F2E01C019d110AF3F4479B7D82C9` [View](https://monadscan.com/address/0x62804a5361F1F2E01C019d110AF3F4479B7D82C9#code) |
| `BalanceFuseErc4626Market3` | `0x74B0f0eb4F85E01bB2904dBc53da80639884aCF6` [View](https://monadscan.com/address/0x74B0f0eb4F85E01bB2904dBc53da80639884aCF6#code) |
| `BalanceFuseErc4626Market4` | `0x6b79d8E22d51646e47674940E25C0a3E7C22666a` [View](https://monadscan.com/address/0x6b79d8E22d51646e47674940E25C0a3E7C22666a#code) |
| `BalanceFuseErc4626Market5` | `0xdccA01dD7D90F60af0E283562d6c65D58923Fa16` [View](https://monadscan.com/address/0xdccA01dD7D90F60af0E283562d6c65D58923Fa16#code) |
| `BalanceFuseEulerV2` | `0x78c4E2Dd229E4b1C485A3983e3C46B84C128034c` [View](https://monadscan.com/address/0x78c4E2Dd229E4b1C485A3983e3C46B84C128034c#code) |
| `BalanceFuseFlashLoanMorpho` | `0x12eB847107d1560578a8B38Bd3D393F9fcb598cF` [View](https://monadscan.com/address/0x12eB847107d1560578a8B38Bd3D393F9fcb598cF#code) |
| `BalanceFuseMetaMorphoMarket0001` | `0x3B2fcF855444bCA9031298F34acF2321E1807fB2` [View](https://monadscan.com/address/0x3B2fcF855444bCA9031298F34acF2321E1807fB2#code) |
| `BalanceFuseMorpho` | `0x4217d1A8795E5CF8B716cEe85d775Bfb93A31092` [View](https://monadscan.com/address/0x4217d1A8795E5CF8B716cEe85d775Bfb93A31092#code) |
| `BalanceFuseMorphoLiquidityInMarkets` | `0xDb88b217dce1c69cfb961c04Cdb1872Eaf1aD7a9` [View](https://monadscan.com/address/0xDb88b217dce1c69cfb961c04Cdb1872Eaf1aD7a9#code) |
| `BalanceFuseSwapPositionsUniswapV3` | `0x056Ab00643dF4BEB8826112A920088AcA828FAa9` [View](https://monadscan.com/address/0x056Ab00643dF4BEB8826112A920088AcA828FAa9#code) |
| `BalanceFuseSwapUniswapV2` | `0x110BfC0F62998B948ad8f760227C4DBC8e9EA801` [View](https://monadscan.com/address/0x110BfC0F62998B948ad8f760227C4DBC8e9EA801#code) |
| `BalanceFuseSwapUniswapV3` | `0x04e54bb6929A05039369A6b232d73B323f87C58a` [View](https://monadscan.com/address/0x04e54bb6929A05039369A6b232d73B323f87C58a#code) |
| `BalanceFuseUniswapV4` | `0x8a4aF18230FbA41344f317d884E457A25f710cb9` [View](https://monadscan.com/address/0x8a4aF18230FbA41344f317d884E457A25f710cb9#code) |
| `BalanceFuseUniversalTokenSwapper` | `0xE947DCc1AdE1C2B42Fc873B06183D4964CC99F24` [View](https://monadscan.com/address/0xE947DCc1AdE1C2B42Fc873B06183D4964CC99F24#code) |
| `BalanceFuseUniversalTokenSwapperV2` | `0x4c79BBaCbeF071675fB223Bfc67AcA14A0109fCA` [View](https://monadscan.com/address/0x4c79BBaCbeF071675fB223Bfc67AcA14A0109fCA#code) |
| `BorrowFuseAaveV3` | `0xc540Aaa399e7c12B33969596D6deE2B39D11e65C` [View](https://monadscan.com/address/0xc540Aaa399e7c12B33969596D6deE2B39D11e65C#code) |
| `BorrowFuseEulerV2` | `0x7536b7124fEfF160504b6cBD0E412C51C1B32f31` [View](https://monadscan.com/address/0x7536b7124fEfF160504b6cBD0E412C51C1B32f31#code) |
| `BorrowFuseMorpho` | `0xb762A44839957096ae83091fcaf38249D9950feB` [View](https://monadscan.com/address/0xb762A44839957096ae83091fcaf38249D9950feB#code) |
| `BurnRequestFeeFuse` | `0x2f4fEdF9E81336b91f2484729760DeD751ae8986` [View](https://monadscan.com/address/0x2f4fEdF9E81336b91f2484729760DeD751ae8986#code) |
| `BurnRequestFeeFuseV2` | `0x3c74f4878e4A6a05c6d1c59EE028803e0013F47c` [View](https://monadscan.com/address/0x3c74f4878e4A6a05c6d1c59EE028803e0013F47c#code) |
| `ClaimRewardsFuseMorpho` | `0x5ce38AaDb48c68f0EbE8aF26F9ba2ef460e2608d` [View](https://monadscan.com/address/0x5ce38AaDb48c68f0EbE8aF26F9ba2ef460e2608d#code) |
| `CollateralFuseEulerV2` | `0x8025a01df1C32358EEFd5c9D8546679b7000a59A` [View](https://monadscan.com/address/0x8025a01df1C32358EEFd5c9D8546679b7000a59A#code) |
| `CollateralFuseMorpho` | `0xd4C839FEc976E3894aC74eDf046C59A3974e5b89` [View](https://monadscan.com/address/0xd4C839FEc976E3894aC74eDf046C59A3974e5b89#code) |
| `CollectFuseUniswapV4` | `0x7dF034513006549C4C02Ea463AEb295736B2E7b1` [View](https://monadscan.com/address/0x7dF034513006549C4C02Ea463AEb295736B2E7b1#code) |
| `CollectSwapFuseUniswapV3` | `0x6611efab4b190a30e09B2Aa139A709ab915D34ED` [View](https://monadscan.com/address/0x6611efab4b190a30e09B2Aa139A709ab915D34ED#code) |
| `ConfigureInstantWithdrawalFuse` | `0x481577CA11b4e19840FEBb5BC699C7637BE400A9` [View](https://monadscan.com/address/0x481577CA11b4e19840FEBb5BC699C7637BE400A9#code) |
| `ControllerFuseEulerV2` | `0x4b2E3cE10A36Dd900Bf78B7FB54D31b7689a0F56` [View](https://monadscan.com/address/0x4b2E3cE10A36Dd900Bf78B7FB54D31b7689a0F56#code) |
| `EulerV2BatchFuse` | `0xcF6b356A15Ad5004310388dE2b54A4C851880b7d` [View](https://monadscan.com/address/0xcF6b356A15Ad5004310388dE2b54A4C851880b7d#code) |
| `FlashloanFuseMorpho` | `0x5964Dd57bEc7CaCcfd896E4e0189B26303D7A22c` [View](https://monadscan.com/address/0x5964Dd57bEc7CaCcfd896E4e0189B26303D7A22c#code) |
| `FuseRedeemFromRequestPlasmaVaultMarket1` | `0x5700Fa07ba21F88d4c7341ED7b04bF59bC038233` [View](https://monadscan.com/address/0x5700Fa07ba21F88d4c7341ED7b04bF59bC038233#code) |
| `FuseRequestSharesPlasmaVaultMarket1` | `0x3db2A1ba8DFb1fD76733e256Ffa6Fc6721E10916` [View](https://monadscan.com/address/0x3db2A1ba8DFb1fD76733e256Ffa6Fc6721E10916#code) |
| `FuseRequestSharesPlasmaVaultV2` | `0x502F3BFBF5De0C0F35fEab7E5A75C96D2728dF61` [View](https://monadscan.com/address/0x502F3BFBF5De0C0F35fEab7E5A75C96D2728dF61#code) |
| `MerklClaimFuse` | `0x0f0f8ec542820f54e117fe1Bf0Fe8e7624833354` [View](https://monadscan.com/address/0x0f0f8ec542820f54e117fe1Bf0Fe8e7624833354#code) |
| `MerklClaimWrapperFuse` | `0x8023C149d2B9fd750Db1583F69DE87566Ed77C03` [View](https://monadscan.com/address/0x8023C149d2B9fd750Db1583F69DE87566Ed77C03#code) |
| `ModifyPositionFuseUniswapV4` | `0x3E51Df675BF38D42Bd90F106ea529E9f38613903` [View](https://monadscan.com/address/0x3E51Df675BF38D42Bd90F106ea529E9f38613903#code) |
| `ModifyPositionSwapFuseUniswapV3` | `0x6504f8518000b60E7F74F34B1943b3E7f66627CD` [View](https://monadscan.com/address/0x6504f8518000b60E7F74F34B1943b3E7f66627CD#code) |
| `NewPositionFuseUniswapV4` | `0x8B9633534B491C1C1c56Ce43BF76210E5BB7c4A8` [View](https://monadscan.com/address/0x8B9633534B491C1C1c56Ce43BF76210E5BB7c4A8#code) |
| `NewPositionSwapFuseUniswapV3` | `0x332DBe52130235b8F89c06eE643FfF548C6a2814` [View](https://monadscan.com/address/0x332DBe52130235b8F89c06eE643FfF548C6a2814#code) |
| `PlasmaVaultBalanceAssetsValidationFuse` | `0x6017FB335BBFC6969b7C09641826D10A924fCb3A` [View](https://monadscan.com/address/0x6017FB335BBFC6969b7C09641826D10A924fCb3A#code) |
| `RequestFeeRefundFuse` | `0x4319C991F24A3e09a810FAB8f20fB14cBe30eE6e` [View](https://monadscan.com/address/0x4319C991F24A3e09a810FAB8f20fB14cBe30eE6e#code) |
| `SupplyFuseAaveV3` | `0x028BAF1142727ea0242b3AEd7873026B9E105581` [View](https://monadscan.com/address/0x028BAF1142727ea0242b3AEd7873026B9E105581#code) |
| `SupplyFuseErc4626Market1` | `0x488c020D13A5c5710042353a0B29eF673809C982` [View](https://monadscan.com/address/0x488c020D13A5c5710042353a0B29eF673809C982#code) |
| `SupplyFuseErc4626Market2` | `0xB318945117B8146c2BC987B4bB3bf284feE8dC50` [View](https://monadscan.com/address/0xB318945117B8146c2BC987B4bB3bf284feE8dC50#code) |
| `SupplyFuseErc4626Market3` | `0xcEfa8A3178e991346e33f5EAdbD44bCaC0a3FD8E` [View](https://monadscan.com/address/0xcEfa8A3178e991346e33f5EAdbD44bCaC0a3FD8E#code) |
| `SupplyFuseErc4626Market4` | `0xD927e8966B8ed2993655dA943D17C033BfE0A259` [View](https://monadscan.com/address/0xD927e8966B8ed2993655dA943D17C033BfE0A259#code) |
| `SupplyFuseErc4626Market5` | `0xc78D53F07dbAc99B43aD6C672679005bE6d41a37` [View](https://monadscan.com/address/0xc78D53F07dbAc99B43aD6C672679005bE6d41a37#code) |
| `SupplyFuseEulerV2` | `0x490C268925022f695579f27374A3fb699A60d49F` [View](https://monadscan.com/address/0x490C268925022f695579f27374A3fb699A60d49F#code) |
| `SupplyFuseMetaMorphoMarket0001` | `0xAcFD752599983C521915cA381dB584005B088841` [View](https://monadscan.com/address/0xAcFD752599983C521915cA381dB584005B088841#code) |
| `SupplyFuseMorpho` | `0x6005b2591E07485AD8BfCFAf3FFd831894cD96f6` [View](https://monadscan.com/address/0x6005b2591E07485AD8BfCFAf3FFd831894cD96f6#code) |
| `SupplyFuseMorphoLiquidityInMarkets` | `0x49c76367313EDa3EE49a1Adeb4Ecb06EDF48A100` [View](https://monadscan.com/address/0x49c76367313EDa3EE49a1Adeb4Ecb06EDF48A100#code) |
| `SupplyFuseMorphoWithCallBackData` | `0x4216702551a068ea4F1BE9C17dc37783648127f8` [View](https://monadscan.com/address/0x4216702551a068ea4F1BE9C17dc37783648127f8#code) |
| `SwapFuseUniswapV2` | `0x24F12cc9bd955c9EEA9BE19549703b519e56e6A5` [View](https://monadscan.com/address/0x24F12cc9bd955c9EEA9BE19549703b519e56e6A5#code) |
| `SwapFuseUniswapV3` | `0xF966b486bFd31d3009bCB3D0599BDD418f669411` [View](https://monadscan.com/address/0xF966b486bFd31d3009bCB3D0599BDD418f669411#code) |
| `SwapFuseUniversalTokenSwapperWithVerification` | `0x9293b5C183800Ed764fe5026933432Ad3E7CC4ca` [View](https://monadscan.com/address/0x9293b5C183800Ed764fe5026933432Ad3E7CC4ca#code) |
| `SwapFuseUniversalTokenSwapperWithVerificationV2` | `0x71DEfaE422AA32fA65a2026D368B472529Ee888a` [View](https://monadscan.com/address/0x71DEfaE422AA32fA65a2026D368B472529Ee888a#code) |
| `UniversalReaderBalanceFuses` | `0xf198bA08DA9fec0D73aECBDf93389aC6F98eec8B` [View](https://monadscan.com/address/0xf198bA08DA9fec0D73aECBDf93389aC6F98eec8B#code) |
| `UniversalTokenSwapperEthFuse` | `0x122f84c2d25CDEEEf5383BdA62F14d22983aD818` [View](https://monadscan.com/address/0x122f84c2d25CDEEEf5383BdA62F14d22983aD818#code) |
| `UniversalTokenSwapperEthFuseV2` | `0xb22c4a76b03E178CF1981b36cF74599DF983Bde1` [View](https://monadscan.com/address/0xb22c4a76b03E178CF1981b36cF74599DF983Bde1#code) |
| `UniversalTokenSwapperFuse` | `0xCfc643d02c67649613A743851d72CC5FE7041998` [View](https://monadscan.com/address/0xCfc643d02c67649613A743851d72CC5FE7041998#code) |
| `UniversalTokenSwapperFuseV2` | `0xB968799bA0DA0CF983241ED010f7d4A754E521F0` [View](https://monadscan.com/address/0xB968799bA0DA0CF983241ED010f7d4A754E521F0#code) |
| `UpdateMarketsBalancesFuse` | `0x472d3e6CDE215f117FaF5ed1220066E862972FE0` [View](https://monadscan.com/address/0x472d3e6CDE215f117FaF5ed1220066E862972FE0#code) |

### Flare Fuses

| Fuse Name | Address / View in Explorer |
|-----------|---------------------------|
| `AsyncActionBalanceFuse` | `0xc348DdcaE334B2D50337E0A0C95D0040580aD552` [View](https://flare-explorer.flare.network/address/0xc348DdcaE334B2D50337E0A0C95D0040580aD552#code) |
| `AsyncActionFuse` | `0x37C43Dd9fFC784A4bf8c57A7E5e29E71cd09F8C5` [View](https://flare-explorer.flare.network/address/0x37C43Dd9fFC784A4bf8c57A7E5e29E71cd09F8C5#code) |
| `BalanceFuseBurnRequestFee` | `0x27420Cef63C69DF58252Ca896Bb264BBF4698360` [View](https://flare-explorer.flare.network/address/0x27420Cef63C69DF58252Ca896Bb264BBF4698360#code) |
| `BalanceFuseErc20` | `0x27C26dbAdDFf5308b4369A9476566c22F7A45994` [View](https://flare-explorer.flare.network/address/0x27C26dbAdDFf5308b4369A9476566c22F7A45994#code) |
| `BalanceFuseErc4626Market1` | `0x2c5e2189003Ee35F6eB0B8bB4b2C093a835eF647` [View](https://flare-explorer.flare.network/address/0x2c5e2189003Ee35F6eB0B8bB4b2C093a835eF647#code) |
| `BalanceFuseErc4626Market2` | `0x243D740ac38b8a97952A09fC83Ab3d6F5705b713` [View](https://flare-explorer.flare.network/address/0x243D740ac38b8a97952A09fC83Ab3d6F5705b713#code) |
| `BalanceFuseErc4626Market3` | `0x5E8D93dDed136301B05B3390F1ca2C14a952aDC4` [View](https://flare-explorer.flare.network/address/0x5E8D93dDed136301B05B3390F1ca2C14a952aDC4#code) |
| `BalanceFuseErc4626Market4` | `0xC0866722bC431Db3586b3F104bC768E4EdE37Ed4` [View](https://flare-explorer.flare.network/address/0xC0866722bC431Db3586b3F104bC768E4EdE37Ed4#code) |
| `BalanceFuseErc4626Market5` | `0x2b22017a7480335e1C707b97c4afc953c7a4078D` [View](https://flare-explorer.flare.network/address/0x2b22017a7480335e1C707b97c4afc953c7a4078D#code) |
| `BalanceFuseFlashLoanMorpho` | `0x7669F7AA22955BaA9cb66EDbe4EaA0C2cd62714d` [View](https://flare-explorer.flare.network/address/0x7669F7AA22955BaA9cb66EDbe4EaA0C2cd62714d#code) |
| `BalanceFuseMetaMorphoMarket0001` | `0x2C5B4B07c2b2aE5A95559EAA69B73083D28375e4` [View](https://flare-explorer.flare.network/address/0x2C5B4B07c2b2aE5A95559EAA69B73083D28375e4#code) |
| `BalanceFuseMorpho` | `0x980542CB07FD9A804A356351DB4A4925A84cA313` [View](https://flare-explorer.flare.network/address/0x980542CB07FD9A804A356351DB4A4925A84cA313#code) |
| `BalanceFuseMorphoLiquidityInMarkets` | `0x28B23ce402CE6153347bAF9c6AC6b84169E46152` [View](https://flare-explorer.flare.network/address/0x28B23ce402CE6153347bAF9c6AC6b84169E46152#code) |
| `BalanceFuseUniversalTokenSwapper` | `0xBb4b49EDFF2D3fa312bE38B5271f0eA4425DB357` [View](https://flare-explorer.flare.network/address/0xBb4b49EDFF2D3fa312bE38B5271f0eA4425DB357#code) |
| `BalanceFuseUniversalTokenSwapperV2` | `0xc63B2410F69364aBA608f8318a9afD98A4f8D8bf` [View](https://flare-explorer.flare.network/address/0xc63B2410F69364aBA608f8318a9afD98A4f8D8bf#code) |
| `BorrowFuseMorpho` | `0x2d4D1ccF5Fd62DF6E0D1F4db4959858D6202fBbb` [View](https://flare-explorer.flare.network/address/0x2d4D1ccF5Fd62DF6E0D1F4db4959858D6202fBbb#code) |
| `BurnRequestFeeFuse` | `0x88221B8f842D1EA67c4Fbe0802e13E8A2e8245ba` [View](https://flare-explorer.flare.network/address/0x88221B8f842D1EA67c4Fbe0802e13E8A2e8245ba#code) |
| `BurnRequestFeeFuseV2` | `0xFb19b576Abf8E3149D358b88c9faC053Edc9fE87` [View](https://flare-explorer.flare.network/address/0xFb19b576Abf8E3149D358b88c9faC053Edc9fE87#code) |
| `ClaimRewardsFuseMorpho` | `0xF8FCe359844F888Bad742fE60723D4CB91bA6108` [View](https://flare-explorer.flare.network/address/0xF8FCe359844F888Bad742fE60723D4CB91bA6108#code) |
| `CollateralFuseMorpho` | `0xd982725A9FB6a641899c88DAdfC3aA139bA6f936` [View](https://flare-explorer.flare.network/address/0xd982725A9FB6a641899c88DAdfC3aA139bA6f936#code) |
| `ConfigureInstantWithdrawalFuse` | `0xB3e36A4893FdFA400a0Fa3a5EE583Ca9C77fB743` [View](https://flare-explorer.flare.network/address/0xB3e36A4893FdFA400a0Fa3a5EE583Ca9C77fB743#code) |
| `FlashloanFuseMorpho` | `0xBBe546FBbDA60d5BAa4222f02f8de24633435179` [View](https://flare-explorer.flare.network/address/0xBBe546FBbDA60d5BAa4222f02f8de24633435179#code) |
| `FuseRedeemFromRequestPlasmaVaultMarket1` | `0x8633b12137DE43CB69a2DB3A926207639DA33245` [View](https://flare-explorer.flare.network/address/0x8633b12137DE43CB69a2DB3A926207639DA33245#code) |
| `FuseRequestSharesPlasmaVaultMarket1` | `0x292f8b2BA264cdEa6E1C5843B1511Ac59767a7be` [View](https://flare-explorer.flare.network/address/0x292f8b2BA264cdEa6E1C5843B1511Ac59767a7be#code) |
| `FuseRequestSharesPlasmaVaultV2` | `0xaB6d45B6545237E653a0613D447e8a0064C69280` [View](https://flare-explorer.flare.network/address/0xaB6d45B6545237E653a0613D447e8a0064C69280#code) |
| `MerklClaimFuse` | `0xA7C0fCd97a945F37EE379Bb360B2e433Fb31b897` [View](https://flare-explorer.flare.network/address/0xA7C0fCd97a945F37EE379Bb360B2e433Fb31b897#code) |
| `MerklClaimWrapperFuse` | `0x66152b2b3F2e7e6e7FA7d4EC6eDe51B4723F49D8` [View](https://flare-explorer.flare.network/address/0x66152b2b3F2e7e6e7FA7d4EC6eDe51B4723F49D8#code) |
| `PlasmaVaultBalanceAssetsValidationFuse` | `0x852cd083d0954618ca82f4fBD5e6B22558F3D4B6` [View](https://flare-explorer.flare.network/address/0x852cd083d0954618ca82f4fBD5e6B22558F3D4B6#code) |
| `RequestFeeRefundFuse` | `0xEFDC16302E786830049DDbf95F875539e8Dd1a96` [View](https://flare-explorer.flare.network/address/0xEFDC16302E786830049DDbf95F875539e8Dd1a96#code) |
| `SupplyFuseErc4626Market1` | `0x91b210ca3293358d6341313E78e56CC98E37a507` [View](https://flare-explorer.flare.network/address/0x91b210ca3293358d6341313E78e56CC98E37a507#code) |
| `SupplyFuseErc4626Market2` | `0xdf006DCA1A93C1783e6F9c4cF2f0420507acF1fD` [View](https://flare-explorer.flare.network/address/0xdf006DCA1A93C1783e6F9c4cF2f0420507acF1fD#code) |
| `SupplyFuseErc4626Market3` | `0x155923E4d97B53DECC92cD8F660143b4B3E664A6` [View](https://flare-explorer.flare.network/address/0x155923E4d97B53DECC92cD8F660143b4B3E664A6#code) |
| `SupplyFuseErc4626Market4` | `0x0110d00aC63eDAF651413b2879e86f4e7e17d976` [View](https://flare-explorer.flare.network/address/0x0110d00aC63eDAF651413b2879e86f4e7e17d976#code) |
| `SupplyFuseErc4626Market5` | `0x4335B2fD255a72E13c4f08551132c0482c044272` [View](https://flare-explorer.flare.network/address/0x4335B2fD255a72E13c4f08551132c0482c044272#code) |
| `SupplyFuseMetaMorphoMarket0001` | `0xb70f54bE36f11ead01094ECbA90F7FF25Ab0cFE9` [View](https://flare-explorer.flare.network/address/0xb70f54bE36f11ead01094ECbA90F7FF25Ab0cFE9#code) |
| `SupplyFuseMorpho` | `0x6A389EF816FF6cF2Da4936C7B1C0694a9397eDb9` [View](https://flare-explorer.flare.network/address/0x6A389EF816FF6cF2Da4936C7B1C0694a9397eDb9#code) |
| `SupplyFuseMorphoLiquidityInMarkets` | `0xAe075bEE32Ef8b4De7aC0f06c9F75032B52805E5` [View](https://flare-explorer.flare.network/address/0xAe075bEE32Ef8b4De7aC0f06c9F75032B52805E5#code) |
| `SupplyFuseMorphoWithCallBackData` | `0x261308b4ae1Cd6b4007D95c14f8D43A14B57678e` [View](https://flare-explorer.flare.network/address/0x261308b4ae1Cd6b4007D95c14f8D43A14B57678e#code) |
| `SwapFuseUniversalTokenSwapperWithVerification` | `0x32b981612936aF1A1e1D7373fDeD90295D764288` [View](https://flare-explorer.flare.network/address/0x32b981612936aF1A1e1D7373fDeD90295D764288#code) |
| `SwapFuseUniversalTokenSwapperWithVerificationV2` | `0xDE0C33702a634c0ffBBf5e796760EC2508194783` [View](https://flare-explorer.flare.network/address/0xDE0C33702a634c0ffBBf5e796760EC2508194783#code) |
| `UniversalReaderBalanceFuses` | `0x3d0DE656703A700FAB2E51135309bb2BfA13b57b` [View](https://flare-explorer.flare.network/address/0x3d0DE656703A700FAB2E51135309bb2BfA13b57b#code) |
| `UniversalTokenSwapperEthFuse` | `0xbf523818d62ABdF607760C8B7FE5bB1307Da99af` [View](https://flare-explorer.flare.network/address/0xbf523818d62ABdF607760C8B7FE5bB1307Da99af#code) |
| `UniversalTokenSwapperEthFuseV2` | `0x49cE74Bb9B7efBc095448E83AD732E7ae11d13e9` [View](https://flare-explorer.flare.network/address/0x49cE74Bb9B7efBc095448E83AD732E7ae11d13e9#code) |
| `UniversalTokenSwapperFuse` | `0xD70dfe24667Fa0773D8B460cD4Dc452Ff20ab80F` [View](https://flare-explorer.flare.network/address/0xD70dfe24667Fa0773D8B460cD4Dc452Ff20ab80F#code) |
| `UniversalTokenSwapperFuseV2` | `0xf3c63eBe9E2080B73f1C1edcf78EFb5278F31F59` [View](https://flare-explorer.flare.network/address/0xf3c63eBe9E2080B73f1C1edcf78EFb5278F31F59#code) |
| `UpdateMarketsBalancesFuse` | `0xB3C476fC7Df5200A346Ca626d0908662C199Ac1E` [View](https://flare-explorer.flare.network/address/0xB3C476fC7Df5200A346Ca626d0908662C199Ac1E#code) |

## PreHooks List

*Last updated: 2026-09-28 18:54:01 UTC*

### Ethereum PreHooks

| PreHook Name | Address / View in Explorer |
|-----------|---------------------------|
| `ExchangeRateValidatorPreHook` | `0xEF23ea0EC8cb31aa78E8D4F59771f24b84706199` [View](https://etherscan.io/address/0xEF23ea0EC8cb31aa78E8D4F59771f24b84706199#code) |
| `ExternalStatePausePreHook` | `0xBA4d84ef0A568001ED92C7B5C163b41236281e29` [View](https://etherscan.io/address/0xBA4d84ef0A568001ED92C7B5C163b41236281e29#code) |
| `PreHookPauseFunction` | `0x7846BeD0b55048dB0e6A5388B89E92f091984D59` [View](https://etherscan.io/address/0x7846BeD0b55048dB0e6A5388B89E92f091984D59#code) |
| `PreHookUpdateBalancesIgnoreDust` | `0x0CF053385492FeF81e538F849E1e5308bEFC1A5C` [View](https://etherscan.io/address/0x0CF053385492FeF81e538F849E1e5308bEFC1A5C#code) |

### Arbitrum PreHooks

| PreHook Name | Address / View in Explorer |
|-----------|---------------------------|
| `ExchangeRateValidatorPreHook` | `0x923a6A7f0AEBbf2381d88ad5402AD0312b30AaD0` [View](https://arbiscan.io/address/0x923a6A7f0AEBbf2381d88ad5402AD0312b30AaD0#code) |
| `ExternalStatePausePreHook` | `0x8EDc731d45C7188E612C1ffca11057fcf41C5d55` [View](https://arbiscan.io/address/0x8EDc731d45C7188E612C1ffca11057fcf41C5d55#code) |
| `PreHookPauseFunction` | `0x2635f5AB58E64690974533F1903378a9B3cA1C9f` [View](https://arbiscan.io/address/0x2635f5AB58E64690974533F1903378a9B3cA1C9f#code) |

### Base PreHooks

| PreHook Name | Address / View in Explorer |
|-----------|---------------------------|
| `ExchangeRateValidatorPreHook` | `0xa959454ed4e72fC23E2c406F17509AEd98ae75Ee` [View](https://basescan.org/address/0xa959454ed4e72fC23E2c406F17509AEd98ae75Ee#code) |
| `ExternalStatePausePreHook` | `0x3F0e3133791FD0424B490039Bb7aD7a16C699Ca8` [View](https://basescan.org/address/0x3F0e3133791FD0424B490039Bb7aD7a16C699Ca8#code) |
| `PreHookPauseFunction` | `0x10e64e5F2f2BD098F31849B48d0BA1B92331cE88` [View](https://basescan.org/address/0x10e64e5F2f2BD098F31849B48d0BA1B92331cE88#code) |
| `PreHookUpdateBalances` | `0x7f9179DC81cd0dBE6488eCD192cf37d2B9530F0C` [View](https://basescan.org/address/0x7f9179DC81cd0dBE6488eCD192cf37d2B9530F0C#code) |

#### Base Older PreHooks Versions

| PreHook Name | Address / View in Explorer |
|-----------|---------------------------|
| `PreHookUpdateBalances` | `0x34dA86DB286E6F0a17471198E329e1429cf5297F` [View](https://basescan.org/address/0x34dA86DB286E6F0a17471198E329e1429cf5297F#code) |

### Unichain PreHooks

| PreHook Name | Address / View in Explorer |
|-----------|---------------------------|
| `ExchangeRateValidatorPreHook` | `0x1dd5E12641d8DD893E425CbFb6F9449C5b7D7C9d` [View](https://uniscan.xyz/address/0x1dd5E12641d8DD893E425CbFb6F9449C5b7D7C9d#code) |
| `PreHookPauseFunction` | `0x76fA5832f36F488084E5889CAda081F9D34dF3Fc` [View](https://uniscan.xyz/address/0x76fA5832f36F488084E5889CAda081F9D34dF3Fc#code) |
| `PreHookUpdateBalancesIgnoreDust` | `0xE9c3c5878Df61688894BBB92dBa6916Aed323976` [View](https://uniscan.xyz/address/0xE9c3c5878Df61688894BBB92dBa6916Aed323976#code) |

### TAC PreHooks

| PreHook Name | Address / View in Explorer |
|-----------|---------------------------|
| `PreHookPauseFunction` | `0x97cAA1a25a1c37a8b748E53DDe48fc44C18E7e2B` [View](https://explorer.tac.build/address/0x97cAA1a25a1c37a8b748E53DDe48fc44C18E7e2B#code) |
| `PreHookUpdateBalancesIgnoreDust` | `0x8D37Bea911CD0a79842f4B0f46dA805AeD23FF29` [View](https://explorer.tac.build/address/0x8D37Bea911CD0a79842f4B0f46dA805AeD23FF29#code) |

### Ink PreHooks

| PreHook Name | Address / View in Explorer |
|-----------|---------------------------|
| `ExchangeRateValidatorPreHook` | `0xbB558010F93F714B6Ffe86a24744e192845b6f5b` [View](https://explorer.inkonchain.com/address/0xbB558010F93F714B6Ffe86a24744e192845b6f5b#code) |
| `PreHookPauseFunction` | `0x7B9Ca73aC9afB4119D4823e9b0E906B1abe5d16C` [View](https://explorer.inkonchain.com/address/0x7B9Ca73aC9afB4119D4823e9b0E906B1abe5d16C#code) |
| `PreHookUpdateBalancesIgnoreDust` | `0x1d802E8B2AdC589E6d390692B56606a7F09B0Dc1` [View](https://explorer.inkonchain.com/address/0x1d802E8B2AdC589E6d390692B56606a7F09B0Dc1#code) |

### Plasma PreHooks

| PreHook Name | Address / View in Explorer |
|-----------|---------------------------|
| `ExchangeRateValidatorPreHook` | `0xCc5227224B59F61B362d2A11886c8B3b933d3596` [View](https://plasmascan.to/address/0xCc5227224B59F61B362d2A11886c8B3b933d3596#code) |
| `PreHookPauseFunction` | `0x86162A4Ae8d831Cf0296C7d5E67510826da405F6` [View](https://plasmascan.to/address/0x86162A4Ae8d831Cf0296C7d5E67510826da405F6#code) |
| `PreHookUpdateBalancesIgnoreDust` | `0x8F3d71872930532dc04bA37244c5EA5222b85Ca0` [View](https://plasmascan.to/address/0x8F3d71872930532dc04bA37244c5EA5222b85Ca0#code) |

### Avalanche PreHooks

| PreHook Name | Address / View in Explorer |
|-----------|---------------------------|
| `ExchangeRateValidatorPreHook` | `0x21e309535084Effe9C985199660C374c59df2F5b` [View](https://snowscan.xyz/address/0x21e309535084Effe9C985199660C374c59df2F5b#code) |
| `PreHookPauseFunction` | `0x9f07A105cCbc9E65Aa0eA064E8cF765E5967B5dc` [View](https://snowscan.xyz/address/0x9f07A105cCbc9E65Aa0eA064E8cF765E5967B5dc#code) |
| `PreHookUpdateBalancesIgnoreDust` | `0x8f2E9d878D68b9E174E3EA53E5151602F1e702A4` [View](https://snowscan.xyz/address/0x8f2E9d878D68b9E174E3EA53E5151602F1e702A4#code) |

### Katana PreHooks

| PreHook Name | Address / View in Explorer |
|-----------|---------------------------|
| `ExchangeRateValidatorPreHook` | `0xC8f1D01CfaF2Fb95be8d65Eba40e2F7914AF45bc` [View](https://katanascan.com/address/0xC8f1D01CfaF2Fb95be8d65Eba40e2F7914AF45bc#code) |
| `PreHookPauseFunction` | `0x4fACfaEdb6632848150f7D057AdAcB63f08de9E6` [View](https://katanascan.com/address/0x4fACfaEdb6632848150f7D057AdAcB63f08de9E6#code) |
| `PreHookUpdateBalancesIgnoreDust` | `0x647ad8Cc72D3Ad8b0A2AA1D11b64e0B00eA91DCa` [View](https://katanascan.com/address/0x647ad8Cc72D3Ad8b0A2AA1D11b64e0B00eA91DCa#code) |

### Botanix PreHooks

| PreHook Name | Address / View in Explorer |
|-----------|---------------------------|
| `ExchangeRateValidatorPreHook` | `0x2d71762F9ccD9A5b4D41769122C0dD1A8735559c` [View](https://botanixscan.io/address/0x2d71762F9ccD9A5b4D41769122C0dD1A8735559c#code) |
| `PreHookPauseFunction` | `0xa2571d0aD5a50306E29549E347EBE61a88b6B91e` [View](https://botanixscan.io/address/0xa2571d0aD5a50306E29549E347EBE61a88b6B91e#code) |
| `PreHookUpdateBalancesIgnoreDust` | `0x95814408A3A0522e0de98b90F62F67Dc1d62deE1` [View](https://botanixscan.io/address/0x95814408A3A0522e0de98b90F62F67Dc1d62deE1#code) |

### HyperEVM PreHooks

| PreHook Name | Address / View in Explorer |
|-----------|---------------------------|
| `ExchangeRateValidatorPreHook` | `0xD95d0Da878A3E5F1dFDbe0622A2FF0816286b986` [View](https://hyperevmscan.io/address/0xD95d0Da878A3E5F1dFDbe0622A2FF0816286b986#code) |
| `ExternalStatePausePreHook` | `0xE948331A9A2d26E4092cA30849f983d3Af3abc06` [View](https://hyperevmscan.io/address/0xE948331A9A2d26E4092cA30849f983d3Af3abc06#code) |
| `PreHookPauseFunction` | `0x9f340D4165231A62081616F5F5Ee25d49eF42C07` [View](https://hyperevmscan.io/address/0x9f340D4165231A62081616F5F5Ee25d49eF42C07#code) |
| `PreHookUpdateBalancesIgnoreDust` | `0x404513a7D7382bEEF1101d62d6d2484eDe64e6f4` [View](https://hyperevmscan.io/address/0x404513a7D7382bEEF1101d62d6d2484eDe64e6f4#code) |
| `RWAPausePreHook` | `0x2bd3E192e76cd784252d3505181a79a3aeaa4Ce4` [View](https://hyperevmscan.io/address/0x2bd3E192e76cd784252d3505181a79a3aeaa4Ce4#code) |

### Robinhood PreHooks

| PreHook Name | Address / View in Explorer |
|-----------|---------------------------|
| `ExchangeRateValidatorPreHook` | `0xA9D7d453B02eB2DC40E0fE6FE1041aaF2384D1F2` [View](https://robinhoodchain.blockscout.com/address/0xA9D7d453B02eB2DC40E0fE6FE1041aaF2384D1F2#code) |
| `PreHookPauseFunction` | `0x5F30b26a041e44748078b6A20Bb142696e1236fc` [View](https://robinhoodchain.blockscout.com/address/0x5F30b26a041e44748078b6A20Bb142696e1236fc#code) |
| `PreHookUpdateBalancesIgnoreDust` | `0x22f2408949180345e6b1A30f77Acf178A72BFB87` [View](https://robinhoodchain.blockscout.com/address/0x22f2408949180345e6b1A30f77Acf178A72BFB87#code) |

### Monad PreHooks

| PreHook Name | Address / View in Explorer |
|-----------|---------------------------|
| `ExchangeRateValidatorPreHook` | `0xb7193D84d07ae593268CF93241679bDDEA5f1735` [View](https://monadscan.com/address/0xb7193D84d07ae593268CF93241679bDDEA5f1735#code) |
| `PreHookPauseFunction` | `0x2d5cFA588F6d14cB6DABAAE72B9AC39977ED8852` [View](https://monadscan.com/address/0x2d5cFA588F6d14cB6DABAAE72B9AC39977ED8852#code) |
| `PreHookUpdateBalancesIgnoreDust` | `0xb1ed081BC17BB61508fE115ec39827324A1BaA38` [View](https://monadscan.com/address/0xb1ed081BC17BB61508fE115ec39827324A1BaA38#code) |

### Flare PreHooks

| PreHook Name | Address / View in Explorer |
|-----------|---------------------------|
| `ExchangeRateValidatorPreHook` | `0xCa9a01e322ad87d94ffb60e545238D62A72EeA40` [View](https://flare-explorer.flare.network/address/0xCa9a01e322ad87d94ffb60e545238D62A72EeA40#code) |
| `PreHookPauseFunction` | `0x31324f455929CA8B8Fe47a39dA34E530279c5FCe` [View](https://flare-explorer.flare.network/address/0x31324f455929CA8B8Fe47a39dA34E530279c5FCe#code) |
| `PreHookUpdateBalancesIgnoreDust` | `0x1517809E3cAF00bd1DcBA3963f9F4C6F8c1338f6` [View](https://flare-explorer.flare.network/address/0x1517809E3cAF00bd1DcBA3963f9F4C6F8c1338f6#code) |

## Price Oracles List

*Last updated: 2026-09-28 19:33:31 UTC*

### Ethereum Price Oracles

| Price Oracle Name | Address / View in Explorer |
|-----------|---------------------------|
| `PriceOracleMiddlewareUsdProxy` | `0x6c25876346A48De3457312cB6D50020504413b5D` [View](https://etherscan.io/address/0x6c25876346A48De3457312cB6D50020504413b5D#code) |
| `PriceOracleMiddlewareUsdWithRolesProxy` | `0xC9F32d65a278b012371858fD3cdE315B12d664c6` [View](https://etherscan.io/address/0xC9F32d65a278b012371858fD3cdE315B12d664c6#code) |
| `ReservoirPriceOracleMiddlewareWithRolesProxy` | `0x5992DC71F8BfE2bA8b682a4AdCcbaf868A5c59EA` [View](https://etherscan.io/address/0x5992DC71F8BfE2bA8b682a4AdCcbaf868A5c59EA#code) |

#### Price Feeds for `PriceOracleMiddlewareUsdProxy`

##### Version 2025-01-16 - `0x6c25876346A48De3457312cB6D50020504413b5D` [View](https://etherscan.io/address/0x6c25876346A48De3457312cB6D50020504413b5D#code)

| Asset | Source / View in Explorer |
|-------|---------------|
| **rUSD** `0x09D4214C03D01F49544C0448DBE3A27f768F2b34` | `0x02b2F2809ce74563cb4b2ecA1ADaFB188E4Ed8D7` [View](https://etherscan.io/address/0x02b2F2809ce74563cb4b2ecA1ADaFB188E4Ed8D7) |
| **srUSD** `0x738d1115B90efa71AE468F1287fc864775e23a31` | `0x810625fCB9b9819a02a135DE1172b468ad673FD8` [View](https://etherscan.io/address/0x810625fCB9b9819a02a135DE1172b468ad673FD8) |

##### Version 2024-09-29 - `0xB7018C15279E0f5990613cc00A91b6032066f2f7` [View](https://etherscan.io/address/0xB7018C15279E0f5990613cc00A91b6032066f2f7#code)

| Asset | Source / View in Explorer |
|-------|---------------|
| **USDT** `0xdAC17F958D2ee523a2206206994597C13D831ec7` | `0x3E7d1eAB13ad0104d2750B8863b489D65364e32D` [View](https://etherscan.io/address/0x3E7d1eAB13ad0104d2750B8863b489D65364e32D) |
| **USDC** `0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48` | `0x8fFfFfd4AfB6115b954Bd326cbe7B4BA576818f6` [View](https://etherscan.io/address/0x8fFfFfd4AfB6115b954Bd326cbe7B4BA576818f6) |
| **sDAI** `0x83F20F44975D03b1b09e64809B757c47f942BEeA` | `0x974672fa995917FEC4A5C9db32784D36c370805d` [View](https://etherscan.io/address/0x974672fa995917FEC4A5C9db32784D36c370805d) |
| **PT-sUSDE-27MAR2025** `0xE00bd3Df25fb187d6ABBB620b3dfd19839947b81` | `0xD7Aa529Ce055A1f745a40c1EEa98CcB9B90e61cf` [View](https://etherscan.io/address/0xD7Aa529Ce055A1f745a40c1EEa98CcB9B90e61cf) |
| **PT-sUSDE-26DEC2024** `0xEe9085fC268F6727d5D4293dBABccF901ffDCC29` | `0xD7Aa529Ce055A1f745a40c1EEa98CcB9B90e61cf` [View](https://etherscan.io/address/0xD7Aa529Ce055A1f745a40c1EEa98CcB9B90e61cf) |
| **WBTC** `0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599` | `0x106f9537Dd66423E6674e85CA187B43055B59fe9` [View](https://etherscan.io/address/0x106f9537Dd66423E6674e85CA187B43055B59fe9) |
| **wstETH** `0x7f39C581F595B53c5cb19bD0b3f8dA6c935E2Ca0` | `0x4329e2178D41D058Cf2808c11436A9e83BC5D8b0` [View](https://etherscan.io/address/0x4329e2178D41D058Cf2808c11436A9e83BC5D8b0) |
| **PT-USD0++-27MAR2025** `0x5BaE9a5D67d1CA5b09B14c91935f635CFBF3b685` | `0xD7Aa529Ce055A1f745a40c1EEa98CcB9B90e61cf` [View](https://etherscan.io/address/0xD7Aa529Ce055A1f745a40c1EEa98CcB9B90e61cf) |
| **PT-sUSDE-27FEB2025** `0x386AE941D4262B0Ee96354499dF2ab8442734EC0` | `0xD7Aa529Ce055A1f745a40c1EEa98CcB9B90e61cf` [View](https://etherscan.io/address/0xD7Aa529Ce055A1f745a40c1EEa98CcB9B90e61cf) |
| **rUSD** `0x09D4214C03D01F49544C0448DBE3A27f768F2b34` | `0x02b2F2809ce74563cb4b2ecA1ADaFB188E4Ed8D7` [View](https://etherscan.io/address/0x02b2F2809ce74563cb4b2ecA1ADaFB188E4Ed8D7) |
| **srUSD** `0x738d1115B90efa71AE468F1287fc864775e23a31` | `0x810625fCB9b9819a02a135DE1172b468ad673FD8` [View](https://etherscan.io/address/0x810625fCB9b9819a02a135DE1172b468ad673FD8) |
| **PT-sUSDE-29MAY2025** `0xb7de5dFCb74d25c2f21841fbd6230355C50d9308` | `0xD7Aa529Ce055A1f745a40c1EEa98CcB9B90e61cf` [View](https://etherscan.io/address/0xD7Aa529Ce055A1f745a40c1EEa98CcB9B90e61cf) |
| **ETH+** `0xE72B141DF173b999AE7c1aDcbF60Cc9833Ce56a8` | `0xD529f458Bc879Be231E36eC62968416C07580199` [View](https://etherscan.io/address/0xD529f458Bc879Be231E36eC62968416C07580199) |
| **WETH** `0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2` | `0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419` [View](https://etherscan.io/address/0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419) |
| **wsrUSD** `0xd3fD63209FA2D55B07A0f6db36C2f43900be3094` | `0xf137329A9851203C9B2e39794172DD5Da4D66d8d` [View](https://etherscan.io/address/0xf137329A9851203C9B2e39794172DD5Da4D66d8d) |

#### Price Feeds for `PriceOracleMiddlewareUsdWithRolesProxy`

##### Version 2025-03-25 - `0xC9F32d65a278b012371858fD3cdE315B12d664c6` [View](https://etherscan.io/address/0xC9F32d65a278b012371858fD3cdE315B12d664c6#code)

| Asset | Source / View in Explorer |
|-------|---------------|
| **WETH** `0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2` | `0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419` [View](https://etherscan.io/address/0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419) |
| **ETH+** `0xE72B141DF173b999AE7c1aDcbF60Cc9833Ce56a8` | `0xD529f458Bc879Be231E36eC62968416C07580199` [View](https://etherscan.io/address/0xD529f458Bc879Be231E36eC62968416C07580199) |
| **srUSD** `0x738d1115B90efa71AE468F1287fc864775e23a31` | `0x810625fCB9b9819a02a135DE1172b468ad673FD8` [View](https://etherscan.io/address/0x810625fCB9b9819a02a135DE1172b468ad673FD8) |
| **rUSD** `0x09D4214C03D01F49544C0448DBE3A27f768F2b34` | `0x02b2F2809ce74563cb4b2ecA1ADaFB188E4Ed8D7` [View](https://etherscan.io/address/0x02b2F2809ce74563cb4b2ecA1ADaFB188E4Ed8D7) |
| **wstETH** `0x7f39C581F595B53c5cb19bD0b3f8dA6c935E2Ca0` | `0x4329e2178D41D058Cf2808c11436A9e83BC5D8b0` [View](https://etherscan.io/address/0x4329e2178D41D058Cf2808c11436A9e83BC5D8b0) |
| **WBTC** `0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599` | `0x106f9537Dd66423E6674e85CA187B43055B59fe9` [View](https://etherscan.io/address/0x106f9537Dd66423E6674e85CA187B43055B59fe9) |
| **sDAI** `0x83F20F44975D03b1b09e64809B757c47f942BEeA` | `0x974672fa995917FEC4A5C9db32784D36c370805d` [View](https://etherscan.io/address/0x974672fa995917FEC4A5C9db32784D36c370805d) |
| **USDC** `0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48` | `0x8fFfFfd4AfB6115b954Bd326cbe7B4BA576818f6` [View](https://etherscan.io/address/0x8fFfFfd4AfB6115b954Bd326cbe7B4BA576818f6) |
| **USDT** `0xdAC17F958D2ee523a2206206994597C13D831ec7` | `0x3E7d1eAB13ad0104d2750B8863b489D65364e32D` [View](https://etherscan.io/address/0x3E7d1eAB13ad0104d2750B8863b489D65364e32D) |
| **lvlUSD** `0x7C1156E515aA1A2E851674120074968C905aAF37` | `0x8fFfFfd4AfB6115b954Bd326cbe7B4BA576818f6` [View](https://etherscan.io/address/0x8fFfFfd4AfB6115b954Bd326cbe7B4BA576818f6) |
| **PT-lvlUSD-29MAY2025** `0x9BcA74F805AB0a22DDD0886dB0942199a0feBa71` | `0x5D902B950cCcdEC3d74885f0c1bEcfbCA11673e8` [View](https://etherscan.io/address/0x5D902B950cCcdEC3d74885f0c1bEcfbCA11673e8) |
| **PT-eUSDE-29MAY2025** `0x50D2C7992b802Eef16c04FeADAB310f31866a545` | `0x9f59e34f4C7808e0F0403bd6dcc51525DB89041c` [View](https://etherscan.io/address/0x9f59e34f4C7808e0F0403bd6dcc51525DB89041c) |
| **USDO** `0x8238884Ec9668Ef77B90C6dfF4D1a9F4F4823BFe` | `0x02b2F2809ce74563cb4b2ecA1ADaFB188E4Ed8D7` [View](https://etherscan.io/address/0x02b2F2809ce74563cb4b2ecA1ADaFB188E4Ed8D7) |
| **PT-RUSD-31JUL2025** `0xf736acF34FF7Cd9B3565b73a1f15E652859bF322` | `0x4bb25F8a46602D00C4250c2f08459d98D4894f51` [View](https://etherscan.io/address/0x4bb25F8a46602D00C4250c2f08459d98D4894f51) |
| **PT-syrupUSDC-28AUG2025** `0xCcE7D12f683c6dAe700154f0BAdf779C0bA1F89A` | `0xB37E44046eE563DAF324A7022263c4d69802E118` [View](https://etherscan.io/address/0xB37E44046eE563DAF324A7022263c4d69802E118) |
| **PT-sUSDE-29MAY2025** `0xb7de5dFCb74d25c2f21841fbd6230355C50d9308` | `0xF3aa22c75d75d11FcbE62C5f0821279793B8C296` [View](https://etherscan.io/address/0xF3aa22c75d75d11FcbE62C5f0821279793B8C296) |
| **PT-sUSDE-31JUL2025** `0x3b3fB9C57858EF816833dC91565EFcd85D96f634` | `0xdbb67Ce78f4B20466BbbCC3FF02409E40dbAf0A6` [View](https://etherscan.io/address/0xdbb67Ce78f4B20466BbbCC3FF02409E40dbAf0A6) |
| **PT-wstUSR-25SEP2025** `0x23E60d1488525bf4685f53b3aa8E676c30321066` | `0xeA6F7F4eceFC73B13345Ede73772D7f884D637ff` [View](https://etherscan.io/address/0xeA6F7F4eceFC73B13345Ede73772D7f884D637ff) |
| **PT-cUSDO-19JUN2025** `0x933B9FfEE0Ad3Ef8E4DBb52688ea905826D73755` | `0xbE7E88B52C79C6B0e507d43D9b6Ad6992187779c` [View](https://etherscan.io/address/0xbE7E88B52C79C6B0e507d43D9b6Ad6992187779c) |
| **sUSDf** `0xc8CF6D7991f15525488b2A83Df53468D682Ba4B0` | `0xdbFFc30F3b95B8CA5BaB3e6C139076feA47f89b3` [View](https://etherscan.io/address/0xdbFFc30F3b95B8CA5BaB3e6C139076feA47f89b3) |
| **PT-sUSDE-25SEP2025** `0x9F56094C450763769BA0EA9Fe2876070c0fD5F77` | `0x2dA0Bbff13Af521f21b092B9161b92e3172373e4` [View](https://etherscan.io/address/0x2dA0Bbff13Af521f21b092B9161b92e3172373e4) |
| **PT-lvlUSD-25SEP2025** `0x207F7205fd6c4b602Fa792C8b2B60e6006D4a0b8` | `0x3Cb11512948D476E8930964D7Ed08bC155f101E2` [View](https://etherscan.io/address/0x3Cb11512948D476E8930964D7Ed08bC155f101E2) |
| **PT-USDS-14AUG2025** `0xFfEc096c087C13Cc268497B89A613cACE4DF9A48` | `0xc5B457325e6bEE5E32FCd00dCFCcf657e1f30B4C` [View](https://etherscan.io/address/0xc5B457325e6bEE5E32FCd00dCFCcf657e1f30B4C) |
| **BOLD** `0x6440f144b7e50D6a8439336510312d2F54beB01D` | `0x596cDF5D33486b035e8482688c638E7dcAf25a7b` [View](https://etherscan.io/address/0x596cDF5D33486b035e8482688c638E7dcAf25a7b) |
| **sBOLD** `0x50Bd66D59911F5e086Ec87aE43C811e0D059DD11` | `0x3c3F08A0cE5dC1608D7E11167C60244E16922D93` [View](https://etherscan.io/address/0x3c3F08A0cE5dC1608D7E11167C60244E16922D93) |
| **PT-sBOLD-27NOV2025** `0x66526197a4BAf496D97e1004e43c2C374Fb7d2E7` | `0xa0f108184a8c461640fE8349a2FD36e3c6cd3E77` [View](https://etherscan.io/address/0xa0f108184a8c461640fE8349a2FD36e3c6cd3E77) |
| **PT-pUSDe-16OCT2025** `0xF3f491e5608f8B8a6Fd9E9d66a4a4036d7FD282C` | `0x9cB88d61976701Ad9cB00722fa1bD8c27eeC8539` [View](https://etherscan.io/address/0x9cB88d61976701Ad9cB00722fa1bD8c27eeC8539) |
| **wsrUSD** `0xd3fD63209FA2D55B07A0f6db36C2f43900be3094` | `0xf137329A9851203C9B2e39794172DD5Da4D66d8d` [View](https://etherscan.io/address/0xf137329A9851203C9B2e39794172DD5Da4D66d8d) |

#### Price Feeds for `ReservoirPriceOracleMiddlewareWithRolesProxy`

##### Version 2026-04-10 - `0x5992DC71F8BfE2bA8b682a4AdCcbaf868A5c59EA` [View](https://etherscan.io/address/0x5992DC71F8BfE2bA8b682a4AdCcbaf868A5c59EA#code)

| Asset | Source / View in Explorer |
|-------|---------------|
| **rUSD** `0x09D4214C03D01F49544C0448DBE3A27f768F2b34` | `0x8fFfFfd4AfB6115b954Bd326cbe7B4BA576818f6` [View](https://etherscan.io/address/0x8fFfFfd4AfB6115b954Bd326cbe7B4BA576818f6) |
| **srUSD** `0x738d1115B90efa71AE468F1287fc864775e23a31` | `0x810625fCB9b9819a02a135DE1172b468ad673FD8` [View](https://etherscan.io/address/0x810625fCB9b9819a02a135DE1172b468ad673FD8) |
| **USDC** `0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48` | `0x8fFfFfd4AfB6115b954Bd326cbe7B4BA576818f6` [View](https://etherscan.io/address/0x8fFfFfd4AfB6115b954Bd326cbe7B4BA576818f6) |
| **wsrUSD** `0xd3fD63209FA2D55B07A0f6db36C2f43900be3094` | `0xf137329A9851203C9B2e39794172DD5Da4D66d8d` [View](https://etherscan.io/address/0xf137329A9851203C9B2e39794172DD5Da4D66d8d) |


### Arbitrum Price Oracles

| Price Oracle Name | Address / View in Explorer |
|-----------|---------------------------|
| `PriceOracleMiddlewareUsdProxy` | `0x9838c0d15b439816D25d5fD1AEbd259EeddB66B4` [View](https://arbiscan.io/address/0x9838c0d15b439816D25d5fD1AEbd259EeddB66B4#code) |
| `PriceOracleMiddlewareUsdWithRolesProxy` | `0xd19D0C917844b996B09c48A9FF622177Af219C79` [View](https://arbiscan.io/address/0xd19D0C917844b996B09c48A9FF622177Af219C79#code) |

#### Price Feeds for `PriceOracleMiddlewareUsdProxy`

##### Version 2024-09-11 - `0x9838c0d15b439816D25d5fD1AEbd259EeddB66B4` [View](https://arbiscan.io/address/0x9838c0d15b439816D25d5fD1AEbd259EeddB66B4#code)

| Asset | Source / View in Explorer |
|-------|---------------|
| **USDC** `0xaf88d065e77c8cC2239327C5EDb3A432268e5831` | `0x50834F3163758fcC1Df9973b6e91f0F0F0434aD3` [View](https://arbiscan.io/address/0x50834F3163758fcC1Df9973b6e91f0F0F0434aD3) |
| **USD₮0** `0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9` | `0x3f3f5dF88dC9F13eac63DF89EC16ef6e7E25DdE7` [View](https://arbiscan.io/address/0x3f3f5dF88dC9F13eac63DF89EC16ef6e7E25DdE7) |

##### Version 2024-09-03 - `0xF9d7F359875E21b3A74BEd7Db40348f5393AF758` [View](https://arbiscan.io/address/0xF9d7F359875E21b3A74BEd7Db40348f5393AF758#code)

| Asset | Source / View in Explorer |
|-------|---------------|
| **USDC** `0xaf88d065e77c8cC2239327C5EDb3A432268e5831` | `0x50834F3163758fcC1Df9973b6e91f0F0F0434aD3` [View](https://arbiscan.io/address/0x50834F3163758fcC1Df9973b6e91f0F0F0434aD3) |
| **USD₮0** `0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9` | `0x3f3f5dF88dC9F13eac63DF89EC16ef6e7E25DdE7` [View](https://arbiscan.io/address/0x3f3f5dF88dC9F13eac63DF89EC16ef6e7E25DdE7) |
| **USDC** `0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8` | `0x50834F3163758fcC1Df9973b6e91f0F0F0434aD3` [View](https://arbiscan.io/address/0x50834F3163758fcC1Df9973b6e91f0F0F0434aD3) |
| **DAI** `0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1` | `0xc5C8E77B397E531B8EC06BFb0048328B30E9eCfB` [View](https://arbiscan.io/address/0xc5C8E77B397E531B8EC06BFb0048328B30E9eCfB) |
| **WETH** `0x82aF49447D8a07e3bd95BD0d56f35241523fBab1` | `0xA2829e6EB0c464dCa8cc04FA397AC2a0a367c7C0` [View](https://arbiscan.io/address/0xA2829e6EB0c464dCa8cc04FA397AC2a0a367c7C0) |
| **ETHx** `0xED65C5085a18Fa160Af0313E60dcc7905E944Dc7` | `0xAa03F54E803d26465107d252C29bF4ff8497C72d` [View](https://arbiscan.io/address/0xAa03F54E803d26465107d252C29bF4ff8497C72d) |
| **rsETH** `0x4186BFC76E2E237523CBC30FD220FE055156b41F` | `0x4676705Ea193b70d523D4f09d0eCCa08742b8493` [View](https://arbiscan.io/address/0x4676705Ea193b70d523D4f09d0eCCa08742b8493) |
| **wstETH** `0x5979D7b546E38E414F7E9822514be443A4800529` | `0xDc2AE617d91536005Fb4E303150BA0eb2A045511` [View](https://arbiscan.io/address/0xDc2AE617d91536005Fb4E303150BA0eb2A045511) |
| **weETH** `0x35751007a407ca6FEFfE80b3cB397736D2cf4dbe` | `0x36A027f551231f6805A7aC4E601ca747a63f3C31` [View](https://arbiscan.io/address/0x36A027f551231f6805A7aC4E601ca747a63f3C31) |
| **WBTC** `0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f` | `0xd0C7101eACbB49F3deCcCc166d238410D6D46d57` [View](https://arbiscan.io/address/0xd0C7101eACbB49F3deCcCc166d238410D6D46d57) |
| **sUSDe** `0x211Cc4DD073734dA055fbF44a2b4667d5E5fE5d2` | `0xd29b4C381f0Ff86F7683904712DF1Dc22a66e757` [View](https://arbiscan.io/address/0xd29b4C381f0Ff86F7683904712DF1Dc22a66e757) |
| **USDe** `0x5d3a1Ff2b6BAb83b63cd9AD0787074081a52ef34` | `0x1b81760c6Fe66230c3E03968b1fc723475977DA3` [View](https://arbiscan.io/address/0x1b81760c6Fe66230c3E03968b1fc723475977DA3) |
| **syrupUSDC** `0x41CA7586cC1311807B4605fBB748a3B8862b42b5` | `0x11FceDd695637a8c6F11D2cC6E9438d28880b1E9` [View](https://arbiscan.io/address/0x11FceDd695637a8c6F11D2cC6E9438d28880b1E9) |

#### Price Feeds for `PriceOracleMiddlewareUsdWithRolesProxy`

##### Version 2025-03-25 - `0xd19D0C917844b996B09c48A9FF622177Af219C79` [View](https://arbiscan.io/address/0xd19D0C917844b996B09c48A9FF622177Af219C79#code)

| Asset | Source / View in Explorer |
|-------|---------------|
| **USDC** `0xaf88d065e77c8cC2239327C5EDb3A432268e5831` | `0x50834F3163758fcC1Df9973b6e91f0F0F0434aD3` [View](https://arbiscan.io/address/0x50834F3163758fcC1Df9973b6e91f0F0F0434aD3) |
| **crvUSD** `0x498Bf2B1e120FeD3ad3D42EA2165E9b73f99C1e5` | `0x0a32255dd4BB6177C994bAAc73E0606fDD568f66` [View](https://arbiscan.io/address/0x0a32255dd4BB6177C994bAAc73E0606fDD568f66) |
| **wstETH** `0x5979D7b546E38E414F7E9822514be443A4800529` | `0x328bC24EBbCaA109907F4a209265E34c1B113455` [View](https://arbiscan.io/address/0x328bC24EBbCaA109907F4a209265E34c1B113455) |
| **WETH** `0x82aF49447D8a07e3bd95BD0d56f35241523fBab1` | `0x639Fe6ab55C921f74e7fac1ee960C0B6293ba612` [View](https://arbiscan.io/address/0x639Fe6ab55C921f74e7fac1ee960C0B6293ba612) |
| **WBTC** `0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f` | `0x6ce185860a4963106506C203335A2910413708e9` [View](https://arbiscan.io/address/0x6ce185860a4963106506C203335A2910413708e9) |


### Base Price Oracles

| Price Oracle Name | Address / View in Explorer |
|-----------|---------------------------|
| `PriceOracleMiddlewareUsdProxy` | `0x1C55a415550ba8B5675175fa384E7e2D1Dd85B82` [View](https://basescan.org/address/0x1C55a415550ba8B5675175fa384E7e2D1Dd85B82#code) |
| `PriceOracleMiddlewareUsdWithRolesProxy` | `0x56FFd1794E20bF04AC4D4B0992B83184cFCa9E9C` [View](https://basescan.org/address/0x56FFd1794E20bF04AC4D4B0992B83184cFCa9E9C#code) |
| `PriceOracleMiddlewareWithRolesForIporWstETHProxy` | `0x0B2Eb332c5B38F13f0c2D0b1039E0302F985Be09` [View](https://basescan.org/address/0x0B2Eb332c5B38F13f0c2D0b1039E0302F985Be09#code) |

#### Price Feeds for `PriceOracleMiddlewareUsdProxy`

##### Version 2025-01-14 - `0x1C55a415550ba8B5675175fa384E7e2D1Dd85B82` [View](https://basescan.org/address/0x1C55a415550ba8B5675175fa384E7e2D1Dd85B82#code)

| Asset | Source / View in Explorer |
|-------|---------------|
| **DEGEN** `0x4ed4E862860beD51a9570b96d89aF5E1B0Efefed` | `0x1dBdb06e14606d34b51BD723bD2334004757e8b4` [View](https://basescan.org/address/0x1dBdb06e14606d34b51BD723bD2334004757e8b4) |
| **AERO** `0x940181a94A35A4569E4529A3CDfB74e38FD98631` | `0x136a2098b994959651091fED13FAC20B0d41B899` [View](https://basescan.org/address/0x136a2098b994959651091fED13FAC20B0d41B899) |
| **PEPE** `0x52b492a33E447Cdb854c7FC19F1e57E8BfA1777D` | `0x3563Db856798d52fB393EE809f050499C9AE2fF0` [View](https://basescan.org/address/0x3563Db856798d52fB393EE809f050499C9AE2fF0) |
| **USDC** `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913` | `0xF3783A124541A0Cce9eF089B590A8Efb10231e8F` [View](https://basescan.org/address/0xF3783A124541A0Cce9eF089B590A8Efb10231e8F) |
| **cbBTC** `0xcbB7C0000aB88B473b1f5aFd9ef808440eed33Bf` | `0x0071943e25A44B74A17A7f1c2d01264DCF50E060` [View](https://basescan.org/address/0x0071943e25A44B74A17A7f1c2d01264DCF50E060) |
| **WETH** `0x4200000000000000000000000000000000000006` | `0xb7266e94518aC8C067aB0457042a5817F032b2Cf` [View](https://basescan.org/address/0xb7266e94518aC8C067aB0457042a5817F032b2Cf) |

##### Version 2024-11-08 - `0x41883F367ab187B1C676A4A4767758916A6a01Fa` [View](https://basescan.org/address/0x41883F367ab187B1C676A4A4767758916A6a01Fa#code)

| Asset | Source / View in Explorer |
|-------|---------------|
| **USDC** `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913` | `0x7e860098F58bBFC8648a4311b374B1D669a2bc6B` [View](https://basescan.org/address/0x7e860098F58bBFC8648a4311b374B1D669a2bc6B) |
| **WETH** `0x4200000000000000000000000000000000000006` | `0x71041dddad3595F9CEd3DcCFBe3D1F4b0a16Bb70` [View](https://basescan.org/address/0x71041dddad3595F9CEd3DcCFBe3D1F4b0a16Bb70) |
| **cbBTC** `0xcbB7C0000aB88B473b1f5aFd9ef808440eed33Bf` | `0x64c911996D3c6aC71f9b455B1E8E7266BcbD848F` [View](https://basescan.org/address/0x64c911996D3c6aC71f9b455B1E8E7266BcbD848F) |
| **cbETH** `0x2Ae3F1Ec7F1F5012CFEab0185bfc7aa3cf0DEc22` | `0xd7818272B9e248357d13057AAb0B417aF31E817d` [View](https://basescan.org/address/0xd7818272B9e248357d13057AAb0B417aF31E817d) |
| **wstETH** `0xc1CBa3fCea344f92D9239c08C0568f6F2F0ee452` | `0xf9fDE8340A348277B62f81Ab7C6d83fDC2C3A145` [View](https://basescan.org/address/0xf9fDE8340A348277B62f81Ab7C6d83fDC2C3A145) |
| **EURC** `0x60a3E35Cc302bFA44Cb288Bc5a4F316Fdb1adb42` | `0xDAe398520e2B67cd3f27aeF9Cf14D93D927f8250` [View](https://basescan.org/address/0xDAe398520e2B67cd3f27aeF9Cf14D93D927f8250) |
| **ezETH** `0x2416092f143378750bb29b79eD961ab195CcEea5` | `0x5F3ebbF5873B9Ce40C97E8E96a130639d079F4bC` [View](https://basescan.org/address/0x5F3ebbF5873B9Ce40C97E8E96a130639d079F4bC) |
| **wrsETH** `0xEDfa23602D0EC14714057867A78d01e94176BEA0` | `0xF1eBda1bAC6F51b50669D1930EaeFa8E7883214d` [View](https://basescan.org/address/0xF1eBda1bAC6F51b50669D1930EaeFa8E7883214d) |
| **weETH** `0x04C0599Ae5A44757c0af6F9eC3b93da8976c150A` | `0x0Cad80485AFaf04b87e435E46dEcc5F36B5ba23F` [View](https://basescan.org/address/0x0Cad80485AFaf04b87e435E46dEcc5F36B5ba23F) |
| **rETH** `0xB6fe221Fe9EeF5aBa221c348bA20A1Bf5e73624c` | `0xd7b19766A839b8A7BCB4E98310Be87B78D1046bA` [View](https://basescan.org/address/0xd7b19766A839b8A7BCB4E98310Be87B78D1046bA) |

##### Version 2024-10-29 - `0xa9ae6bF914DB9e8A297Ca2ecD05AE094b8BAd407` [View](https://basescan.org/address/0xa9ae6bF914DB9e8A297Ca2ecD05AE094b8BAd407#code)

| Asset | Source / View in Explorer |
|-------|---------------|
| **WETH** `0x4200000000000000000000000000000000000006` | `0x71041dddad3595F9CEd3DcCFBe3D1F4b0a16Bb70` [View](https://basescan.org/address/0x71041dddad3595F9CEd3DcCFBe3D1F4b0a16Bb70) |
| **USDC** `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913` | `0x7e860098F58bBFC8648a4311b374B1D669a2bc6B` [View](https://basescan.org/address/0x7e860098F58bBFC8648a4311b374B1D669a2bc6B) |
| **USDT** `0xfde4C96c8593536E31F229EA8f37b2ADa2699bb2` | `0xf19d560eB8d2ADf07BD6D13ed03e1D11215721F9` [View](https://basescan.org/address/0xf19d560eB8d2ADf07BD6D13ed03e1D11215721F9) |
| **wstETH** `0xc1CBa3fCea344f92D9239c08C0568f6F2F0ee452` | `0xf9fDE8340A348277B62f81Ab7C6d83fDC2C3A145` [View](https://basescan.org/address/0xf9fDE8340A348277B62f81Ab7C6d83fDC2C3A145) |
| **cbBTC** `0xcbB7C0000aB88B473b1f5aFd9ef808440eed33Bf` | `0x07DA0E54543a844a80ABE69c8A12F22B3aA59f9D` [View](https://basescan.org/address/0x07DA0E54543a844a80ABE69c8A12F22B3aA59f9D) |
| **cbETH** `0x2Ae3F1Ec7F1F5012CFEab0185bfc7aa3cf0DEc22` | `0xd7818272B9e248357d13057AAb0B417aF31E817d` [View](https://basescan.org/address/0xd7818272B9e248357d13057AAb0B417aF31E817d) |

#### Price Feeds for `PriceOracleMiddlewareUsdWithRolesProxy`

##### Version 2025-06-04 - `0x56FFd1794E20bF04AC4D4B0992B83184cFCa9E9C` [View](https://basescan.org/address/0x56FFd1794E20bF04AC4D4B0992B83184cFCa9E9C#code)

No price feeds found for this version.

##### Version 2025-03-25 - `0x6d908194a5a1005C374203Fc1baF396c7dbC8E99` [View](https://basescan.org/address/0x6d908194a5a1005C374203Fc1baF396c7dbC8E99#code)

No price feeds found for this version.

##### Version 2025-03-25 - `0xD9b73Af0b29Cbaf88F01384EA1fB5ADcb608bed0` [View](https://basescan.org/address/0xD9b73Af0b29Cbaf88F01384EA1fB5ADcb608bed0#code)

| Asset | Source / View in Explorer |
|-------|---------------|
| **USDC** `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913` | `0x7e860098F58bBFC8648a4311b374B1D669a2bc6B` [View](https://basescan.org/address/0x7e860098F58bBFC8648a4311b374B1D669a2bc6B) |
| **WETH** `0x4200000000000000000000000000000000000006` | `0x71041dddad3595F9CEd3DcCFBe3D1F4b0a16Bb70` [View](https://basescan.org/address/0x71041dddad3595F9CEd3DcCFBe3D1F4b0a16Bb70) |
| **cbBTC** `0xcbB7C0000aB88B473b1f5aFd9ef808440eed33Bf` | `0x64c911996D3c6aC71f9b455B1E8E7266BcbD848F` [View](https://basescan.org/address/0x64c911996D3c6aC71f9b455B1E8E7266BcbD848F) |
| **cbETH** `0x2Ae3F1Ec7F1F5012CFEab0185bfc7aa3cf0DEc22` | `0xd7818272B9e248357d13057AAb0B417aF31E817d` [View](https://basescan.org/address/0xd7818272B9e248357d13057AAb0B417aF31E817d) |
| **wstETH** `0xc1CBa3fCea344f92D9239c08C0568f6F2F0ee452` | `0xf9fDE8340A348277B62f81Ab7C6d83fDC2C3A145` [View](https://basescan.org/address/0xf9fDE8340A348277B62f81Ab7C6d83fDC2C3A145) |
| **EURC** `0x60a3E35Cc302bFA44Cb288Bc5a4F316Fdb1adb42` | `0xDAe398520e2B67cd3f27aeF9Cf14D93D927f8250` [View](https://basescan.org/address/0xDAe398520e2B67cd3f27aeF9Cf14D93D927f8250) |
| **ezETH** `0x2416092f143378750bb29b79eD961ab195CcEea5` | `0x5F3ebbF5873B9Ce40C97E8E96a130639d079F4bC` [View](https://basescan.org/address/0x5F3ebbF5873B9Ce40C97E8E96a130639d079F4bC) |
| **wrsETH** `0xEDfa23602D0EC14714057867A78d01e94176BEA0` | `0xF1eBda1bAC6F51b50669D1930EaeFa8E7883214d` [View](https://basescan.org/address/0xF1eBda1bAC6F51b50669D1930EaeFa8E7883214d) |
| **weETH** `0x04C0599Ae5A44757c0af6F9eC3b93da8976c150A` | `0x0Cad80485AFaf04b87e435E46dEcc5F36B5ba23F` [View](https://basescan.org/address/0x0Cad80485AFaf04b87e435E46dEcc5F36B5ba23F) |
| **rETH** `0xB6fe221Fe9EeF5aBa221c348bA20A1Bf5e73624c` | `0xd7b19766A839b8A7BCB4E98310Be87B78D1046bA` [View](https://basescan.org/address/0xd7b19766A839b8A7BCB4E98310Be87B78D1046bA) |
| **LINK** `0x88Fb150BDc53A65fe94Dea0c9BA0a6dAf8C6e196` | `0x17CAb8FE31E32f08326e5E27412894e49B0f9D65` [View](https://basescan.org/address/0x17CAb8FE31E32f08326e5E27412894e49B0f9D65) |
| **VIRTUAL** `0x0b3e328455c4059EEb9e3f84b5543F74E24e7E1b` | `0xEaf310161c9eF7c813A14f8FEF6Fb271434019F7` [View](https://basescan.org/address/0xEaf310161c9eF7c813A14f8FEF6Fb271434019F7) |
| **AERO** `0x940181a94A35A4569E4529A3CDfB74e38FD98631` | `0x4EC5970fC728C5f65ba413992CD5fF6FD70fcfF0` [View](https://basescan.org/address/0x4EC5970fC728C5f65ba413992CD5fF6FD70fcfF0) |
| **MORPHO** `0xBAa5CC21fd487B8Fcc2F632f3F4E8D37262a0842` | `0xe95e258bb6615d47515Fc849f8542dA651f12bF6` [View](https://basescan.org/address/0xe95e258bb6615d47515Fc849f8542dA651f12bF6) |
| **ZRO** `0x6985884C4392D348587B19cb9eAAf157F13271cd` | `0xdc31a4CCfCA039BeC6222e20BE7770E12581bfEB` [View](https://basescan.org/address/0xdc31a4CCfCA039BeC6222e20BE7770E12581bfEB) |

#### Price Feeds for `PriceOracleMiddlewareWithRolesForIporWstETHProxy`

##### Version 2026-03-02 - `0x0B2Eb332c5B38F13f0c2D0b1039E0302F985Be09` [View](https://basescan.org/address/0x0B2Eb332c5B38F13f0c2D0b1039E0302F985Be09#code)

| Asset | Source / View in Explorer |
|-------|---------------|
| **wstETH** `0xc1CBa3fCea344f92D9239c08C0568f6F2F0ee452` | `0x5a7417E197b61133061fd1aEe5676fE436Cd4b5f` [View](https://basescan.org/address/0x5a7417E197b61133061fd1aEe5676fE436Cd4b5f) |
| **WETH** `0x4200000000000000000000000000000000000006` | `0x71041dddad3595F9CEd3DcCFBe3D1F4b0a16Bb70` [View](https://basescan.org/address/0x71041dddad3595F9CEd3DcCFBe3D1F4b0a16Bb70) |
| **aBasWETH** `0xD4a0e0b9149BCee3C920d2E00b5dE09138fd8bb7` | `0x71041dddad3595F9CEd3DcCFBe3D1F4b0a16Bb70` [View](https://basescan.org/address/0x71041dddad3595F9CEd3DcCFBe3D1F4b0a16Bb70) |


### Unichain Price Oracles

| Price Oracle Name | Address / View in Explorer |
|-----------|---------------------------|
| `PriceOracleMiddlewareUsdWithRolesProxy` | `0x272978Db64B8B37B0832586c0BFEBe1BE66AA93d` [View](https://uniscan.xyz/address/0x272978Db64B8B37B0832586c0BFEBe1BE66AA93d#code) |

#### Price Feeds for `PriceOracleMiddlewareUsdWithRolesProxy`

##### Version 2025-05-30 - `0x272978Db64B8B37B0832586c0BFEBe1BE66AA93d` [View](https://uniscan.xyz/address/0x272978Db64B8B37B0832586c0BFEBe1BE66AA93d#code)

| Asset | Source / View in Explorer |
|-------|---------------|
| **WETH** `0x4200000000000000000000000000000000000006` | `0xe8D9FbC10e00ecc9f0694617075fDAF657a76FB2` [View](https://uniscan.xyz/address/0xe8D9FbC10e00ecc9f0694617075fDAF657a76FB2) |
| **wstETH** `0xc02fE7317D4eb8753a02c35fe019786854A92001` | `0x2C410477FA03360537224E6255789Ed6857D0fdF` [View](https://uniscan.xyz/address/0x2C410477FA03360537224E6255789Ed6857D0fdF) |
| **weETH** `0x7DCC39B4d1C53CB31e1aBc0e358b43987FEF80f7` | `0x06F05AeaADaB7127f61DC39F53789b80CdEE88c3` [View](https://uniscan.xyz/address/0x06F05AeaADaB7127f61DC39F53789b80CdEE88c3) |
| **rsETH** `0xc3eACf0612346366Db554C991D7858716db09f58` | `0x85C4F855Bc0609D2584405819EdAEa3aDAbfE97D` [View](https://uniscan.xyz/address/0x85C4F855Bc0609D2584405819EdAEa3aDAbfE97D) |


### TAC Price Oracles

| Price Oracle Name | Address / View in Explorer |
|-----------|---------------------------|
| `PriceOracleMiddlewareUsdWithRolesProxy` | `0x4521a59ecB7F9FC4718714DE354c86f6afF6aa6f` [View](https://explorer.tac.build/address/0x4521a59ecB7F9FC4718714DE354c86f6afF6aa6f#code) |

#### Price Feeds for `PriceOracleMiddlewareUsdWithRolesProxy`

##### Version 2025-07-03 - `0x4521a59ecB7F9FC4718714DE354c86f6afF6aa6f` [View](https://explorer.tac.build/address/0x4521a59ecB7F9FC4718714DE354c86f6afF6aa6f#code)

No price feeds found for this version.


### Ink Price Oracles

| Price Oracle Name | Address / View in Explorer |
|-----------|---------------------------|
| `PriceOracleMiddlewareUsdWithRolesProxy` | `0xC2a698A69904306a7eF90012d7C58fE02E0BC3C5` [View](https://explorer.inkonchain.com/address/0xC2a698A69904306a7eF90012d7C58fE02E0BC3C5#code) |

#### Price Feeds for `PriceOracleMiddlewareUsdWithRolesProxy`

##### Version 2025-07-15 - `0xC2a698A69904306a7eF90012d7C58fE02E0BC3C5` [View](https://explorer.inkonchain.com/address/0xC2a698A69904306a7eF90012d7C58fE02E0BC3C5#code)

No price feeds found for this version.


### Plasma Price Oracles

| Price Oracle Name | Address / View in Explorer |
|-----------|---------------------------|
| `PriceOracleMiddlewareUsdWithRolesProxy` | `0x7c51664D41809c28D9aee3c2332b0d3eD16e92d5` [View](https://plasmascan.to/address/0x7c51664D41809c28D9aee3c2332b0d3eD16e92d5#code) |

#### Price Feeds for `PriceOracleMiddlewareUsdWithRolesProxy`

##### Version 2025-09-26 - `0x7c51664D41809c28D9aee3c2332b0d3eD16e92d5` [View](https://plasmascan.to/address/0x7c51664D41809c28D9aee3c2332b0d3eD16e92d5#code)

No price feeds found for this version.


### Avalanche Price Oracles

| Price Oracle Name | Address / View in Explorer |
|-----------|---------------------------|
| `PriceOracleMiddlewareUsdWithRolesProxy` | `0xa2aD49b19e2f85cCA553C86aDB8D3d7cA1Cae3B8` [View](https://snowscan.xyz/address/0xa2aD49b19e2f85cCA553C86aDB8D3d7cA1Cae3B8#code) |

#### Price Feeds for `PriceOracleMiddlewareUsdWithRolesProxy`

##### Version 2025-10-01 - `0xa2aD49b19e2f85cCA553C86aDB8D3d7cA1Cae3B8` [View](https://snowscan.xyz/address/0xa2aD49b19e2f85cCA553C86aDB8D3d7cA1Cae3B8#code)

No price feeds found for this version.


### Katana Price Oracles

| Price Oracle Name | Address / View in Explorer |
|-----------|---------------------------|
| `PriceOracleMiddlewareUsdWithRolesProxy` | `0x700BAD7fA21147fC341Ef0706cce53253eD15494` [View](https://katanascan.com/address/0x700BAD7fA21147fC341Ef0706cce53253eD15494#code) |

#### Price Feeds for `PriceOracleMiddlewareUsdWithRolesProxy`

##### Version 2026-02-06 - `0x700BAD7fA21147fC341Ef0706cce53253eD15494` [View](https://katanascan.com/address/0x700BAD7fA21147fC341Ef0706cce53253eD15494#code)

No price feeds found for this version.


### Botanix Price Oracles

| Price Oracle Name | Address / View in Explorer |
|-----------|---------------------------|
| `PriceOracleMiddlewareUsdWithRolesProxy` | `0x79729c68179F1F89F90b6b12c05eF2cB30D33D5b` [View](https://botanixscan.io/address/0x79729c68179F1F89F90b6b12c05eF2cB30D33D5b#code) |

#### Price Feeds for `PriceOracleMiddlewareUsdWithRolesProxy`

##### Version 2026-04-30 - `0x79729c68179F1F89F90b6b12c05eF2cB30D33D5b` [View](https://botanixscan.io/address/0x79729c68179F1F89F90b6b12c05eF2cB30D33D5b#code)

No price feeds found for this version.


### HyperEVM Price Oracles

| Price Oracle Name | Address / View in Explorer |
|-----------|---------------------------|
| `PriceOracleMiddlewareUsdWithRolesProxy` | `0x4d4C8363460A67029d76Ea1597202758cf43Ec37` [View](https://hyperevmscan.io/address/0x4d4C8363460A67029d76Ea1597202758cf43Ec37#code) |

#### Price Feeds for `PriceOracleMiddlewareUsdWithRolesProxy`

##### Version 2026-07-09 - `0x4d4C8363460A67029d76Ea1597202758cf43Ec37` [View](https://hyperevmscan.io/address/0x4d4C8363460A67029d76Ea1597202758cf43Ec37#code)

No price feeds found for this version.


### Robinhood Price Oracles

| Price Oracle Name | Address / View in Explorer |
|-----------|---------------------------|
| `PriceOracleMiddlewareUsdWithRolesProxy` | `0x9DD4F8195b95eb2283c5737bd16b35b4fC3B9554` [View](https://robinhoodchain.blockscout.com/address/0x9DD4F8195b95eb2283c5737bd16b35b4fC3B9554#code) |

#### Price Feeds for `PriceOracleMiddlewareUsdWithRolesProxy`

##### Version 2026-07-09 - `0x9DD4F8195b95eb2283c5737bd16b35b4fC3B9554` [View](https://robinhoodchain.blockscout.com/address/0x9DD4F8195b95eb2283c5737bd16b35b4fC3B9554#code)

No price feeds found for this version.


### Monad Price Oracles

| Price Oracle Name | Address / View in Explorer |
|-----------|---------------------------|
| `PriceOracleMiddlewareUsdWithRolesProxy` | `0x7EC9719c40453a160D6Efa532e383AEBF90eA18B` [View](https://monadscan.com/address/0x7EC9719c40453a160D6Efa532e383AEBF90eA18B#code) |

#### Price Feeds for `PriceOracleMiddlewareUsdWithRolesProxy`

##### Version 2026-08-19 - `0x7EC9719c40453a160D6Efa532e383AEBF90eA18B` [View](https://monadscan.com/address/0x7EC9719c40453a160D6Efa532e383AEBF90eA18B#code)

No price feeds found for this version.


### Flare Price Oracles

| Price Oracle Name | Address / View in Explorer |
|-----------|---------------------------|
| `PriceOracleMiddlewareUsdWithRolesProxy` | `0x0C40f544FaD53000D42505c7d4Ed0015Cd1749fA` [View](https://flare-explorer.flare.network/address/0x0C40f544FaD53000D42505c7d4Ed0015Cd1749fA#code) |

#### Price Feeds for `PriceOracleMiddlewareUsdWithRolesProxy`

##### Version 2026-08-27 - `0x0C40f544FaD53000D42505c7d4Ed0015Cd1749fA` [View](https://flare-explorer.flare.network/address/0x0C40f544FaD53000D42505c7d4Ed0015Cd1749fA#code)

No price feeds found for this version.
