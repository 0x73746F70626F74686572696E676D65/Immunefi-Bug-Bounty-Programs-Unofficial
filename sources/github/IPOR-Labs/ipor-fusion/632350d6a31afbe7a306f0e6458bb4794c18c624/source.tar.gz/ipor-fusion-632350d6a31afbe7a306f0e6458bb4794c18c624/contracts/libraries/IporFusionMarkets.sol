// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.30;

/// @title Predefined markets used in the IPOR Fusion protocol
/// @notice For documentation purposes: When new markets are added by authorized property of PlasmaVault during runtime, they should be added and described here as well.
library IporFusionMarkets {
    /// @dev AAVE V3 market
    uint256 public constant AAVE_V3 = 1;

    /// @dev Compound V3 market USDC
    uint256 public constant COMPOUND_V3_USDC = 2;

    /// @dev Gearbox V3 market
    uint256 public constant GEARBOX_POOL_V3 = 3;
    /// @dev if this marketId is added to the PlasmaVault, one need add dependence graph with balance of GEARBOX_POOL_V3
    uint256 public constant GEARBOX_FARM_DTOKEN_V3 = 4;

    /// @dev Fluid Instadapp market
    uint256 public constant FLUID_INSTADAPP_POOL = 5;
    uint256 public constant FLUID_INSTADAPP_STAKING = 6;

    uint256 public constant ERC20_VAULT_BALANCE = 7;

    /// @dev if this marketId is added to the PlasmaVault, one need add dependence graph with balance of ERC20_VAULT_BALANCE
    uint256 public constant UNISWAP_SWAP_V3_POSITIONS = 8;

    /// @dev Uniswap market
    /// @dev if this marketId is added to the PlasmaVault, one need add dependence graph with balance of ERC20_VAULT_BALANCE
    uint256 public constant UNISWAP_SWAP_V2 = 9;
    /// @dev if this marketId is added to the PlasmaVault, one need add dependence graph with balance of ERC20_VAULT_BALANCE
    uint256 public constant UNISWAP_SWAP_V3 = 10;

    /// @dev Euler market
    uint256 public constant EULER_V2 = 11;

    /// @dev universal token swapper, one need add dependence graph with balance of ERC20_VAULT_BALANCE
    uint256 public constant UNIVERSAL_TOKEN_SWAPPER = 12;

    /// @dev Universal token swapper V2, one need add dependence graph with balance of ERC20_VAULT_BALANCE
    /// @dev Substrate type: UniversalTokenSwapperSubstrateType (Token, Target or Slippage)
    /// @dev Substrate layout (bytes32): [0:1] type (1 byte) | [1:32] data (31 bytes) - see UniversalTokenSwapperSubstrateLib
    /// @dev Substrate values:
    ///      - Token: Allowed token addresses for swapping - tokenIn, tokenOut and dust-check tokens
    ///        (encoded with UniversalTokenSwapperSubstrateLib.encodeTokenSubstrate)
    ///      - Target: Allowed DEX/target addresses that can be called during a swap
    ///        (encoded with UniversalTokenSwapperSubstrateLib.encodeTargetSubstrate)
    ///      - Slippage: Custom slippage limit in WAD, uint248, 1e18 = 100%
    ///        (encoded with UniversalTokenSwapperSubstrateLib.encodeSlippageSubstrate)
    uint256 public constant UNIVERSAL_TOKEN_SWAPPER_V2 = 12_02;

    /// @dev Compound V3 market USDT
    uint256 public constant COMPOUND_V3_USDT = 13;

    /// @dev Morpho market
    uint256 public constant MORPHO = 14;

    /// @dev Spark market
    uint256 public constant SPARK = 15;

    /// @dev Curve market
    uint256 public constant CURVE_POOL = 16;
    uint256 public constant CURVE_LP_GAUGE = 17;

    uint256 public constant RAMSES_V2_POSITIONS = 18;

    /// @dev Morpho flash loan market, one need add dependence graph with balance of ERC20_VAULT_BALANCE
    uint256 public constant MORPHO_FLASH_LOAN = 19;

    /// @dev AAVE V3 lido market
    uint256 public constant AAVE_V3_LIDO = 20;

    /// @dev Moonwell market
    uint256 public constant MOONWELL = 21;

    /// @dev Morpho rewards market
    uint256 public constant MORPHO_REWARDS = 22;

    /// @dev Pendle market
    uint256 public constant PENDLE = 23;

    /// @dev Fluid rewards market
    uint256 public constant FLUID_REWARDS = 24;

    /// @dev Curve gauge ERC4626 market
    uint256 public constant CURVE_GAUGE_ERC4626 = 25;

    /// @dev Compound V3 market WETH
    uint256 public constant COMPOUND_V3_WETH = 26;

    uint256 public constant HARVEST_HARD_WORK = 27;

    /// @dev TAC staking market
    uint256 public constant TAC_STAKING = 28;

    /// @dev Liquity V2 market
    uint256 public constant LIQUITY_V2 = 29;

    uint256 public constant AERODROME = 30;

    /// @dev Velodrome Superchain market
    uint256 public constant VELODROME_SUPERCHAIN = 31;

    /// @dev Velodrome Superchain Slipstream market
    /// @dev Substrate type: VelodromeSuperchainSlipstreamSubstrate
    uint256 public constant VELODROME_SUPERCHAIN_SLIPSTREAM = 32;

    /// @dev Velodrome Superchain Slipstream market
    /// @dev Substrate type: AerodromeSlipstreamSubstrate
    uint256 public constant AREODROME_SLIPSTREAM = 33;

    /// @dev StakeDaoV2 market
    /// @dev Substrate type: address
    /// @dev Substrate values: address of the Stake DAO Reward Vault contract
    uint256 public constant STAKE_DAO_V2 = 34;

    /// @dev Silo Finance V2 market
    /// @dev Substrate type: address
    /// @dev Substrate values: address of the Silo Config contract
    uint256 public constant SILO_V2 = 35;

    /// @dev Balancer market
    /// @dev Substrate type: BalancerSubstrate (pool or gauge addresses)
    /// @dev Substrate values: Balancer pool or gauge addresses
    /// @dev Supports both Balancer pools and liquidity gauges for LP token management
    uint256 public constant BALANCER = 36;

    /// @dev Yield Basis LT market
    /// @dev Substrate type: address
    /// @dev Substrate values: Yield Basis LT tokens addresses
    uint256 public constant YIELD_BASIS_LT = 37;

    /// @dev Enso Finance market
    /// @dev Substrate type: EnsoSubstrate
    /// @dev Substrate values: Encoded combination of target address and function selector
    /// @dev Example substrate encoding:
    ///      - For token transfers: EnsoSubstrateLib.encode(Substrate({
    ///          target_: USDC,
    ///          functionSelector_: ERC20.transfer.selector
    ///        }))
    ///      - For swaps: EnsoSubstrateLib.encode(Substrate({
    ///          target_: swapTarget,
    ///          functionSelector_: ISwap.swap.selector
    ///        }))
    /// @dev Used for executing Enso Finance operations via EnsoExecutor contract
    /// @dev Supports token transfers, swaps and other operations defined in DelegateEnsoShortcuts

    uint256 public constant ENSO = 38;

    /// @dev Ebisu market
    /// @dev Substrate type: EbisuZapperSubstrate

    uint256 public constant EBISU = 39;

    /// @dev Async Action market
    /// @dev Substrate type: AsyncActionFuseSubstrate
    /// @dev Substrate values: Three types of substrates are supported:
    ///      - ALLOWED_AMOUNT_TO_OUTSIDE: Limits on asset amounts that can be transferred to AsyncExecutor
    ///        Encoded as: AsyncActionFuseLib.encodeAsyncActionFuseSubstrate(AsyncActionFuseSubstrate({
    ///          substrateType: AsyncActionFuseSubstrateType.ALLOWED_AMOUNT_TO_OUTSIDE,
    ///          data: AsyncActionFuseLib.encodeAllowedAmountToOutside(AllowedAmountToOutside({
    ///            asset: tokenAddress,
    ///            amount: maxAmount (uint88, max 2^88 - 1)
    ///          }))
    ///        }))
    ///      - ALLOWED_TARGETS: Permitted target addresses and function selectors for execution
    ///        Encoded as: AsyncActionFuseLib.encodeAsyncActionFuseSubstrate(AsyncActionFuseSubstrate({
    ///          substrateType: AsyncActionFuseSubstrateType.ALLOWED_TARGETS,
    ///          data: AsyncActionFuseLib.encodeAllowedTargets(AllowedTargets({
    ///            target: contractAddress,
    ///            selector: functionSelector
    ///          }))
    ///        }))
    ///      - ALLOWED_EXIT_SLIPPAGE: Maximum slippage threshold for balance validation (18-decimal fixed-point, 1e18 = 100%)
    ///        Encoded as: AsyncActionFuseLib.encodeAsyncActionFuseSubstrate(AsyncActionFuseSubstrate({
    ///          substrateType: AsyncActionFuseSubstrateType.ALLOWED_EXIT_SLIPPAGE,
    ///          data: AsyncActionFuseLib.encodeAllowedSlippage(AllowedSlippage({
    ///            slippage: slippageValue (uint248, max 2^248 - 1)
    ///          }))
    ///        }))
    /// @dev Used for executing asynchronous multi-step operations via AsyncExecutor contract
    /// @dev Validates token transfers and target/selector combinations against granted substrates before execution
    /// @dev Supports batch execution of multiple calls with ETH value forwarding
    uint256 public constant ASYNC_ACTION = 40;

    /// @dev Morpho liquidity in markets market
    uint256 public constant MORPHO_LIQUIDITY_IN_MARKETS = 41;

    /// @dev Odos Swapper market for optimized token swapping via Odos Smart Order Routing V3
    /// @dev Substrate type: OdosSubstrateType (Token or Slippage)
    /// @dev Substrate values:
    ///      - Token: Allowed token addresses for swapping (encoded with OdosSubstrateLib.encodeTokenSubstrate)
    ///      - Slippage: Custom slippage limit in WAD (encoded with OdosSubstrateLib.encodeSlippageSubstrate)
    /// @dev Used for executing Odos swaps via OdosSwapExecutor contract
    uint256 public constant ODOS_SWAPPER = 42;

    /// @dev Velora Swapper market for optimized token swapping via Velora/ParaSwap Augustus v6.2
    /// @dev Substrate type: VeloraSubstrateType (Token or Slippage)
    /// @dev Substrate values:
    ///      - Token: Allowed token addresses for swapping (encoded with VeloraSubstrateLib.encodeTokenSubstrate)
    ///      - Slippage: Custom slippage limit in WAD (encoded with VeloraSubstrateLib.encodeSlippageSubstrate)
    /// @dev Used for executing Velora swaps via VeloraSwapExecutor contract
    uint256 public constant VELORA_SWAPPER = 43;

    /// @dev SparkLend market (Aave V3 fork) - supply/borrow lending on Ethereum mainnet
    /// @dev Integrated via Aave V3 fuses pointed at SparkLend's PoolAddressesProvider
    ///      (0x02C3eA4e34C0cBd694D2adFa2c690EECbC1793eE, Ethereum mainnet):
    ///      - Supply:     AaveV3SupplyFuse
    ///      - Borrow:     AaveV3BorrowFuse
    ///      - Collateral: AaveV3CollateralFuse (toggles asset as collateral / eMode)
    ///      - Balance:    AaveV3WithPriceOracleMiddlewareBalanceFuse (net = aToken supply - debt, priced via PriceOracleMiddleware)
    /// @dev Substrates: underlying ERC20 asset addresses listed on SparkLend (e.g. DAI, USDC, USDS, WETH, wstETH).
    ///      Each asset to be supplied, borrowed or used as collateral must be granted as a substrate for this market.
    uint256 public constant SPARK_LEND = 44;

    /// @dev Midas RWA market (mTBILL, mBASIS)
    /// @dev Substrate type: MidasSubstrateType (M_TOKEN, DEPOSIT_VAULT, REDEMPTION_VAULT, INSTANT_REDEMPTION_VAULT, ASSET)
    /// @dev Substrate values: Encoded combination of type flag and address (see MidasSubstrateLib)
    uint256 public constant MIDAS = 45;

    /// @dev Napier market
    uint256 public constant NAPIER = 46;

    /// @dev Dolomite market
    /// @dev Substrate type: DolomiteSubstrate (asset, subAccountId, canBorrow)
    /// @dev Substrate values: Encoded combination of asset address, sub-account ID, and borrow permission
    uint256 public constant DOLOMITE = 47;

    /// @dev Sky LitePSM market - converts USDC to yield-bearing sUSDS via LitePSMWrapper (zero-fee USDC<->USDS conversion + sUSDS ERC4626 deposit)
    /// @dev Balance fuse: ZeroBalanceFuse (this market holds no assets directly; sUSDS balance tracked on a separate market via Erc4626BalanceFuse)
    /// @dev Substrates: none
    uint256 public constant LITE_PSM = 48;

    /// @dev Aave V4 Hub & Spoke market (one market for every Spoke; no E-Mode in Aave V4)
    /// @dev Substrate type: AaveV4SubstrateType.Reserve - one substrate per Aave V4 reserve the vault may use
    /// @dev Substrate value: AaveV4SubstrateLib.encodeReserve(spoke, reserveId, isCollateral, canBorrow)
    ///      bytes32 layout: [255..248] type = 0x01 | [247..88] spoke address | [87..56] reserveId (uint32)
    ///                      | [55..48] flags (bit0 isCollateral, bit1 canBorrow) | [47..0] zero
    ///      - any grant for (spoke, reserveId): supply, withdraw, repay, disable collateral
    ///      - isCollateral: reserve may be enabled as collateral (AaveV4CollateralFuse)
    ///      - canBorrow: reserve may be borrowed (AaveV4BorrowFuse)
    ///      - instant withdraw only from reserves granted without isCollateral
    ///      The same underlying can be listed twice on one Spoke (e.g. USDC via Prime and Core hubs on Bluechip),
    ///      which is why the reserve id - not the asset - identifies the market.
    uint256 public constant AAVE_V4 = 49;

    /// @dev External State market — generic integration family for off-chain strategies
    ///      operated under custodian dual-approval. One vault hosts at most one External State
    ///      integration via this fuse family
    ///      (see ExternalStateExecutorStorageLib.ExternalStateMultipleMarketsNotSupported).
    ///
    /// @dev Balance fuse: ExternalStateBalanceFuse (reads cached per-balance-account values from
    ///      ExternalStateExecutor; no on-chain price oracle for the off-chain leg — values are
    ///      written by 2-of-N custodians via propose/confirm).
    ///
    /// @dev Substrate types (encoded via ExternalStateSubstrateLib; first byte = type tag):
    ///      - ASSET                — ERC20 token transferred from vault into the executor on enter
    ///                               and from executor back to vault on exit (e.g. USDC, USDT).
    ///      - BALANCE_ACCOUNT      — off-chain account whose underlying balance is tracked
    ///                               (e.g. a custodian sub-account holding T-Bills).
    ///      - CUSTODIAN            — EOA / multisig authorized to propose or confirm balance updates.
    ///      - TARGET               — contract address that ExternalStateOperationFuse is allowed to call
    ///                               from the executor context (e.g. an issuer's mint/redeem router).
    ///      - STALENESS_MAX        — maximum age (seconds) of the oldest balance update before the
    ///                               pre-hook blocks user operations.
    ///      - BIG_CHANGE_BPS       — basis-points threshold; a custodian confirm that moves total
    ///                               balance by more than this trips the pre-hook pause flag.
    ///      - DUST_THRESHOLD       — maximum residual executor balance (as percent of one base token,
    ///                               100 = one whole token) tolerated during propose / confirm.
    ///      - MIN_UPDATE_INTERVAL  — minimum seconds between successive confirms for the same
    ///                               balance account.
    ///
    /// @dev Example configuration for a USDC-backed T-Bill strategy:
    ///      one ASSET (USDC), two CUSTODIAN multisigs (proposer + confirmer), three BALANCE_ACCOUNT
    ///      addresses (one per custody sub-account), one TARGET (issuer's mint contract), plus the
    ///      four singleton parameters (STALENESS_MAX, BIG_CHANGE_BPS, DUST_THRESHOLD, MIN_UPDATE_INTERVAL).
    uint256 public constant EXTERNAL_STATE = 50;

    /// @dev Reservoir Agua Global Carry Vault market (aguaUSDCgc).
    ///      Synchronous 4626-compliant deposit, asynchronous (request -> complete) exit with an
    ///      optional fee-charging early-redemption path. Substrate types are encoded via
    ///      AguaSubstrateLib: VAULT (the Agua vault, which is also its own share token) and
    ///      ASSET (the allowed deposit/redemption asset, e.g. USDC).
    uint256 public constant AGUA_GLOBAL_CARRY = 51;

    /// @dev Term Finance market - fixed-rate, fixed-term repo (lender AND borrower sides)
    /// @dev Substrate type: TYPE-byte encoded bytes32 via `TermFinanceSubstrateLib`
    /// @dev Substrate values:
    ///      - TYPE 0x00 SERVICER: `TermRepoServicer` proxy addresses (upper byte = 0x00,
    ///        backward-compatible with raw `addressToBytes32(servicer)` from lender side)
    ///      - TYPE 0x01 COLLATERAL_TOKEN: ERC20 collateral token addresses accepted by a
    ///        borrower's TermRepoCollateralManager (upper byte = 0x01)
    /// @dev Balance fuse: TermFinanceBalanceFuse with signed-int aggregation across 5 legs:
    ///      held repo tokens (+), pending offers (+), pending bids (+), locked collateral (+),
    ///      debt PV (-). No external self-call is used (under delegatecall `address(this)` is
    ///      the vault, so `try this.fn(...)` would hit the vault fallback); instead each foreign
    ///      Term Finance read is wrapped in its own per-call try/catch, degrading an UNTRACKED
    ///      servicer leg to 0 on revert. A TRACKED leg re-raises (`*PriceZeroForTracked`,
    ///      `*DebtReadFailedForTrackedServicer`, `*DebtRateFailedForTrackedServicer`) to freeze
    ///      share math. Per-leg saturation at MAX_VALUE_PER_LEG = 1e36 USD-WAD.
    /// @dev if this marketId is added to the PlasmaVault, one need add dependence graph with
    ///      balance of ERC20_VAULT_BALANCE — purchase tokens (USDC/WETH) are returned to the
    ///      vault on `RedeemFuse.enter`, `OfferFuse.exit` (pre-reveal cancel), `BidFuse.exit`
    ///      (unlock bid), `CollateralFuse.exit` (unlock collateral), and on bid clearing
    ///      (loan disbursement); the vault's ERC20 balance must be re-evaluated atomically
    ///      with TERM_FINANCE on every action that exits the position.
    uint256 public constant TERM_FINANCE = 52;

    /// @dev Uniswap V4 concentrated liquidity positions market
    /// @dev Substrates (two-level whitelist, see UniswapV4SubstrateLib):
    ///      - PoolId (raw bytes32, keccak256(abi.encode(PoolKey))) — transitively whitelists the
    ///        pool's hook address, fee tier and tick spacing (all part of the PoolKey)
    ///      - token addresses (substrate-as-asset) for both pool currencies, required for
    ///        price-oracle valuation and asset distribution protection
    /// @dev Native-currency pools (currency0 == address(0)) are not supported; use WETH pools
    uint256 public constant UNISWAP_V4 = 53;

    /// @dev Polygon sPOL unstake market (Ethereum mainnet) — values POL pending in the sPOLController
    ///      unstake cooldown queue (~80 checkpoints / ~3 days, driven by the Polygon StakeManager).
    /// @dev Market ID is intentionally out of sequence: both mainnet fuses were deployed with
    ///      MARKET_ID = 424243 (0x67933) baked in as an immutable, so this constant must match the deployments.
    /// @dev Fuses (Ethereum mainnet deployments):
    ///      - SPOLUnstakeFuse (enter = sellSPOL, exit = withdrawPOL): 0xF7379E4D945B2CAA89630d4F81a7A3863629Fd02
    ///      - SPOLBalanceFuse (balance fuse of this market):          0x69A206f638019e3a419CF3408991df9E87538949
    /// @dev External protocol (github.com/0xPolygon/sPOL-contracts, Ethereum mainnet):
    ///      - sPOLController (substrate of this market):                0xEaadA411F2600570796c341552b9869DA708a28B
    ///      - sPOL token:                                               0x3B790d651e950497c7723D47B24E6f61534f7969
    ///      - POL token:                                                0x455e53CBB86018Ac2B8092FdCd39d8444aFFC3F6
    ///      - Polygon StakeManagerProxy (epoch / withdrawalDelay = 80): 0x5e3Ef299fDDf15eAa0432E6e66473ace8c13D908
    /// @dev Substrate type: address
    /// @dev Substrate values: sPOLController addresses the vault is allowed to unstake through
    /// @dev Balance fuse semantics: sums ALL open unstake nonces of the vault on the controller
    ///      (in-cooldown + matured-but-unclaimed, via controller.getUserOpenNonces(vault)), priced with
    ///      PriceOracleMiddleware using controller.polToken(). Queued amounts are FIXED at sellSPOL time
    ///      (convertSPOLtoPOL at the sell-time rate) — later exchange-rate changes do not reprice the queue.
    /// @dev Required configuration:
    ///      - SPOLBalanceFuse as the balance fuse of this market, sPOLController granted as substrate;
    ///      - sPOL granted as substrate of ERC20_VAULT_BALANCE (the vault wallet holds sPOL before unstaking);
    ///      - dependency graph: this market -> ERC20_VAULT_BALANCE (enter burns wallet sPOL and creates the
    ///        pending claim atomically, so both markets must re-evaluate in the same execute);
    ///      - POL and sPOL price sources configured in the vault's PriceOracleMiddleware.
    /// @dev Exit semantics: the controller reverts with NoOpenNonces(vault) on an empty queue and with
    ///      NoNoncesReady(vault) when nothing has matured — call SPOLUnstakeFuse.exit only when a claim is
    ///      known to be withdrawable. Claims are FIFO and stop at the first non-matured nonce.
    /// @dev SECURITY — permissionless claim / stale-balance window: sPOLController.withdrawPOL(address) is
    ///      callable by ANYONE on behalf of the vault (POL always goes to the vault, never the caller),
    ///      bypassing SPOLUnstakeFuse.exit. Such a claim moves POL into the vault wallet (counted in
    ///      totalAssets immediately) while this market keeps reporting the already-paid claim until
    ///      updateMarketsBalances([SPOL_UNSTAKE]) runs — during that window totalAssets and the share price
    ///      are INFLATED by the full claimed amount, so depositors overpay and redeemers extract value from
    ///      the remaining holders. Because the trigger is permissionless, the vault cannot control when the
    ///      window opens. REQUIRED mitigation on production vaults: UpdateBalancesPreHook wired to the
    ///      deposit/mint/withdraw/redeem selectors so balances are refreshed before any share pricing;
    ///      additionally the protocol keeper should pair withdrawPOL claims with updateMarketsBalances in
    ///      the same transaction bundle.
    uint256 public constant SPOL_UNSTAKE = 424_243;

    /// @dev Market 1 for ERC4626 Vault
    uint256 public constant ERC4626_0001 = 100_001;

    /// @dev Market 2 for ERC4626 Vault
    uint256 public constant ERC4626_0002 = 100_002;

    /// @dev Market 3 for ERC4626 Vaultś
    uint256 public constant ERC4626_0003 = 100_003;

    /// @dev Market 4 for ERC4626 Vault
    uint256 public constant ERC4626_0004 = 100_004;

    /// @dev Market 5 for ERC4626 Vault
    uint256 public constant ERC4626_0005 = 100_005;

    /// @dev Market 6 for ERC4626 Vault
    uint256 public constant ERC4626_0006 = 100_006;

    /// @dev Market 7 for ERC4626 Vault
    uint256 public constant ERC4626_0007 = 100_007;

    /// @dev Market 8 for ERC4626 Vault
    uint256 public constant ERC4626_0008 = 100_008;

    /// @dev Market 9 for ERC4626 Vault
    uint256 public constant ERC4626_0009 = 100_009;

    /// @dev Market 10 for ERC4626 Vault
    uint256 public constant ERC4626_0010 = 100_010;

    /// @dev Market 11 for ERC4626 Vault
    uint256 public constant ERC4626_0011 = 100_011;

    /// @dev Market 12 for ERC4626 Vault
    uint256 public constant ERC4626_0012 = 100_012;

    /// @dev Market 13 for ERC4626 Vault
    uint256 public constant ERC4626_0013 = 100_013;

    /// @dev Market 14 for ERC4626 Vault
    uint256 public constant ERC4626_0014 = 100_014;

    /// @dev Market 15 for ERC4626 Vault
    uint256 public constant ERC4626_0015 = 100_015;

    /// @dev Market 16 for ERC4626 Vault
    uint256 public constant ERC4626_0016 = 100_016;

    /// @dev Market 17 for ERC4626 Vault
    uint256 public constant ERC4626_0017 = 100_017;

    /// @dev Market 18 for ERC4626 Vault
    uint256 public constant ERC4626_0018 = 100_018;

    /// @dev Market 19 for ERC4626 Vault
    uint256 public constant ERC4626_0019 = 100_019;

    /// @dev Market 20 for ERC4626 Vault
    uint256 public constant ERC4626_0020 = 100_020;

    /// @dev Meta Morpho Market 1
    uint256 public constant META_MORPHO_0001 = 200_001;

    /// @dev Meta Morpho Market 2
    uint256 public constant META_MORPHO_0002 = 200_002;

    /// @dev Meta Morpho Market 3
    uint256 public constant META_MORPHO_0003 = 200_003;

    /// @dev Meta Morpho Market 4
    uint256 public constant META_MORPHO_0004 = 200_004;

    /// @dev Meta Morpho Market 5
    uint256 public constant META_MORPHO_0005 = 200_005;

    /// @dev Meta Morpho Market 6
    uint256 public constant META_MORPHO_0006 = 200_006;

    /// @dev Meta Morpho Market 7
    uint256 public constant META_MORPHO_0007 = 200_007;

    /// @dev Meta Morpho Market 8
    uint256 public constant META_MORPHO_0008 = 200_008;

    /// @dev Meta Morpho Market 9
    uint256 public constant META_MORPHO_0009 = 200_009;

    /// @dev Meta Morpho Market 10
    uint256 public constant META_MORPHO_0010 = 200_010;

    /// @dev Merkl rewards market - gates which received reward tokens MerklClaimWrapperFuse may forward
    /// @dev Substrate type: substrate-as-asset (the final reward token addresses granted to this market)
    /// @dev Substrate values: reward token addresses allowed to be forwarded to the RewardsClaimManager
    uint256 public constant MERKL = type(uint256).max - 3;

    /// @dev Exchange Rate Limiter market for pre-hook execution
    /// @dev Substrate type: bytes32 packed ExchangeRateLimiterConfig (see ExchangeRateLimiterConfigLib)
    /// @dev Substrate values:
    /// @dev  - PREHOOKS/POSTHOOKS: Hook { hookAddress, index } packed into bytes31 and wrapped into bytes32 with HookType
    /// @dev  - VALIDATOR: ValidatorData { exchangeRate, threshold } packed into bytes31 and wrapped into bytes32 with HookType
    /// @dev Threshold is expressed in 1e18 precision, where 1e18 = 100%
    /// @dev Used by ExchangeRateLimiterPreHook to orchestrate pre/post hooks and validate exchange rate drift
    uint256 public constant EXCHANGE_RATE_VALIDATOR = type(uint256).max - 2;

    /// @dev Special market ID used to validate balances of substrates (assets) defined in this market.
    /// @dev This market ID is used only for balance validation purposes and does not represent an actual market.
    uint256 public constant ASSETS_BALANCE_VALIDATION = type(uint256).max - 1;

    /// @dev Market used in cases where the fuse does not require maintaining any balance and there are no dependent balances.
    uint256 public constant ZERO_BALANCE_MARKET = type(uint256).max;
}
