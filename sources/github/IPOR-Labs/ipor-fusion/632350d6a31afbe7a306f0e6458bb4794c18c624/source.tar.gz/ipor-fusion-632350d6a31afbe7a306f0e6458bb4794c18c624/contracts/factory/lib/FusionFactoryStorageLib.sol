// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.30;

/**
 * @title Fusion Factory Storage Library
 * @notice Library managing storage layout and access for the FusionFactory system using ERC-7201 namespaced storage pattern
 * @dev This library is a core component of the FusionFactory system that:
 * 1. Defines and manages all storage structures using ERC-7201 namespaced storage pattern
 * 2. Provides storage access functions for FusionFactory.sol
 * 3. Ensures storage safety for the upgradeable factory system
 *
 * Storage Components:
 * - Factory addresses (rewards, fee, withdraw, context, price, plasma vault, access)
 * - Price oracle middleware
 * - Fee configuration (DAO management and performance fees)
 * - Burn request fee configuration
 * - Registry of PlasmaVaults produced by this factory (provenance only)
 *
 * Security Considerations:
 * - Uses ERC-7201 namespaced storage pattern to prevent storage collisions
 * - Each storage struct has a unique namespace derived from its purpose
 * - Critical for maintaining storage integrity in upgradeable contracts
 * - Storage slots are carefully chosen and must not be modified
 */
library FusionFactoryStorageLib {
    struct BaseAddresses {
        address plasmaVaultCoreBase;
        address accessManagerBase;
        address priceManagerBase;
        address withdrawManagerBase;
        address rewardsManagerBase;
        address contextManagerBase;
    }
    struct FactoryAddresses {
        address accessManagerFactory;
        address plasmaVaultFactory;
        address feeManagerFactory;
        address withdrawManagerFactory;
        address rewardsManagerFactory;
        address contextManagerFactory;
        address priceManagerFactory;
    }

    /// @notice Fee package structure for vault creation
    /// @param managementFee Management fee with 2 decimals (10000 = 100%)
    /// @param performanceFee Performance fee with 2 decimals (10000 = 100%)
    /// @param feeRecipient Address that receives the fees
    struct FeePackage {
        uint256 managementFee;
        uint256 performanceFee;
        address feeRecipient;
    }

    struct AddressType {
        address value;
    }

    struct Uint256Type {
        uint256 value;
    }

    struct AddressArrayType {
        address[] value;
    }

    /// @dev ERC-7201 namespaced storage struct for DAO fee packages
    struct DaoFeePackagesStorage {
        FeePackage[] packages;
    }

    /// @dev ERC-7201 namespaced storage struct for business client fee packages
    struct BusinessClientFeePackagesStorage {
        mapping(address => FeePackage[]) clientPackages;
    }

    /// @dev ERC-7201 namespaced storage struct for PlasmaVaults produced by this factory
    struct FusionVaultsStorage {
        mapping(address vault => bool isFusionVault) vaults;
    }

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.FusionFactoryVersion")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant FUSION_FACTORY_VERSION =
        0x12d32eeb1bff59ce950917bf8e830c4c4200d70d78bc80ef73671dd3e0c72000;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.FusionFactoryIndex")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant FUSION_FACTORY_INDEX = 0x7c54bb33443ce94044aec2970018125c202903e78abecda9a8871f0a2e085400;

    /// @dev DEPRECATED — slot reserved, do not reuse
    /// keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.PlasmaVaultAdminArray")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant PLASMA_VAULT_ADMIN_ARRAY =
        0x09e657bd0ea9e1ace5b99e5e8bb556174727dbd9076ea35b667e7736f1584000;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.PlasmaVaultFactoryAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant PLASMA_VAULT_FACTORY_ADDRESS =
        0xe03d6bb506e833b55bb7e35e66d871fd1486b3efc6bb02b49fae15b9d0247c00;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.AccessManagerFactoryAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant ACCESS_MANAGER_FACTORY_ADDRESS =
        0xc4010ca65378f19e44b7504e0cbdfa0cf4c6c98dc078f9636d3e6f447548f800;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.FeeManagerFactoryAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant FEE_MANAGER_FACTORY_ADDRESS =
        0x721d35383ddb7c0788c39a71ec2b671094a2dff039cf875075cb2cc19150ee00;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.RewardsManagerFactoryAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant REWARDS_MANAGER_FACTORY_ADDRESS =
        0x876e1f4e6bf0084ef05fd36552de50d6a3381705e29281ddedec7e73a391a100;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.WithdrawManagerFactoryAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant WITHDRAW_MANAGER_FACTORY_ADDRESS =
        0xedd99766ca1e8c3d62993721acdaaf42a25e38027fea50866095b850992fdc00;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.ContextManagerFactoryAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant CONTEXT_MANAGER_FACTORY_ADDRESS =
        0x33ff6c98f150f6340aa139cf0a40783e1ff0404e5958622d928ebe5534456a00;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.PriceManagerFactoryAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant PRICE_MANAGER_FACTORY_ADDRESS =
        0xd7a02eb1d0bb68108f76123da75aaeb1a46f41df9f533c7662e3a619ec932800;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.PlasmaVaultBaseAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant PLASMA_VAULT_BASE_ADDRESS =
        0x184318af1b1e15812549d3991019d6e84064e321b012fca8ea3de5c3da16db00;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.PriceOracleMiddlewareAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant PRICE_ORACLE_MIDDLEWARE_ADDRESS =
        0x6fbe74bad032cccb3ef5e7d7be660790fda329f96cf9462b85accc6e1d7d4100;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.BurnRequestFeeBalanceFuseAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant BURNR_REQUEST_FEE_BALANCE_FUSE_ADDRESS =
        0xa0dc2f24541d4bbdc49c383a8746cd6256371b67d8afc882e3ce7e04f721df00;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.BurnRequestFeeFuseAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant BURN_REQUEST_FEE_FUSE_ADDRESS =
        0xf011e505a711b4f906e6e0cfcd988c477cb335d6eb81d8284628276cae32ab00;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.FeePackages")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant DAO_FEE_PACKAGES_STORAGE_SLOT =
        0x59feb9265c4719d36ddde95dfd6b130deb8154e067cc891498b39e0bd8956900;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.BusinessClientFeePackages")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant BUSINESS_CLIENT_FEE_PACKAGES_STORAGE_SLOT =
        0xe0e5362dddc0800f01413c3ddfe63a5811a144af374a6c011371f2d4ecdf8d00;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.FusionVaults")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant FUSION_VAULTS_STORAGE_SLOT =
        0xd8f986f99805409cbb90b99bdf93bd9819d8b8f9dd5c2456ffaf840ff9eb8900;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.WithdrawWindowInSeconds")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant WITHDRAW_WINDOW_IN_SECONDS =
        0x95f9ecba121b4f2a2786b729864c46a5066694903a7462f772cd92093beb0500;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.VestingPeriodInSeconds")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant VESTING_PERIOD_IN_SECONDS =
        0xe7de166eee522f429c14923fb385ff49d6c65d576ad910fc76c16800f269be00;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.AccessManagerBaseAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant ACCESS_MANAGER_BASE_ADDRESS =
        0xdee5af15cbb5c7d3f575c81c43b164c912e2cacae09ac95ab04460973550ec00;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.WithdrawManagerBaseAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant WITHDRAW_MANAGER_BASE_ADDRESS =
        0x71c920154481896f4e6224fa3f403d92b902534a39efd0adf8948440a29f6900;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.RewardsManagerBaseAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant REWARDS_MANAGER_BASE_ADDRESS =
        0x7947c1b14a70a26b8ee1c91656f600b5c452629fc225e1bd435f2d73da810600;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.ContextManagerBaseAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant CONTEXT_MANAGER_BASE_ADDRESS =
        0x327c4805778da4e3703f4a6907d698c910c93cbbedf6f536be61f90d407ed600;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.PriceManagerBaseAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant PRICE_MANAGER_BASE_ADDRESS =
        0x5e1e7003d30cfb3abdb5e35688c765a955b6455e91670898a8e5c73d9c677000;

    /// @dev keccak256(abi.encode(uint256(keccak256("io.ipor.fusion.factory.PlasmaVaultCoreBaseAddress")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant PLASMA_VAULT_CORE_BASE_ADDRESS =
        0x64580ae806e62df65aec7b569ca88d764fcb6a37f8b0f20662030e6001952700;

    function getFactoryAddresses() internal view returns (FactoryAddresses memory) {
        return
            FactoryAddresses({
                accessManagerFactory: _getAccessManagerFactoryAddressSlot().value,
                plasmaVaultFactory: _getPlasmaVaultFactoryAddressSlot().value,
                feeManagerFactory: _getFeeManagerFactoryAddressSlot().value,
                withdrawManagerFactory: _getWithdrawManagerFactoryAddressSlot().value,
                rewardsManagerFactory: _getRewardsManagerFactoryAddressSlot().value,
                contextManagerFactory: _getContextManagerFactoryAddressSlot().value,
                priceManagerFactory: _getPriceManagerFactoryAddressSlot().value
            });
    }

    function getBaseAddresses() internal view returns (BaseAddresses memory) {
        return
            BaseAddresses({
                plasmaVaultCoreBase: _getPlasmaVaultCoreBaseAddressSlot().value,
                accessManagerBase: _getAccessManagerBaseAddressSlot().value,
                priceManagerBase: _getPriceManagerBaseAddressSlot().value,
                withdrawManagerBase: _getWithdrawManagerBaseAddressSlot().value,
                rewardsManagerBase: _getRewardsManagerBaseAddressSlot().value,
                contextManagerBase: _getContextManagerBaseAddressSlot().value
            });
    }

    function getFusionFactoryVersion() internal view returns (uint256) {
        return _getFusionFactoryVersionSlot().value;
    }

    function getFusionFactoryIndex() internal view returns (uint256) {
        return _getFusionFactoryIndexSlot().value;
    }

    function getPlasmaVaultBaseAddress() internal view returns (address) {
        return _getPlasmaVaultBaseAddressSlot().value;
    }

    function getPriceOracleMiddleware() internal view returns (address) {
        return _getPriceOracleMiddlewareSlot().value;
    }

    function getBurnRequestFeeBalanceFuseAddress() internal view returns (address) {
        return _getBurnRequestFeeBalanceFuseAddressSlot().value;
    }

    function getBurnRequestFeeFuseAddress() internal view returns (address) {
        return _getBurnRequestFeeFuseAddressSlot().value;
    }

    function getWithdrawWindowInSeconds() internal view returns (uint256) {
        return _getWithdrawWindowInSecondsSlot().value;
    }

    function getVestingPeriodInSeconds() internal view returns (uint256) {
        return _getVestingPeriodInSecondsSlot().value;
    }

    function getAccessManagerBaseAddress() internal view returns (address) {
        return _getAccessManagerBaseAddressSlot().value;
    }

    function getWithdrawManagerBaseAddress() internal view returns (address) {
        return _getWithdrawManagerBaseAddressSlot().value;
    }

    function getRewardsManagerBaseAddress() internal view returns (address) {
        return _getRewardsManagerBaseAddressSlot().value;
    }

    function getContextManagerBaseAddress() internal view returns (address) {
        return _getContextManagerBaseAddressSlot().value;
    }

    function getPriceManagerBaseAddress() internal view returns (address) {
        return _getPriceManagerBaseAddressSlot().value;
    }

    function getPlasmaVaultCoreBaseAddress() internal view returns (address) {
        return _getPlasmaVaultCoreBaseAddressSlot().value;
    }

    function setFusionFactoryVersion(uint256 value) internal {
        _getFusionFactoryVersionSlot().value = value;
    }

    function setFusionFactoryIndex(uint256 value) internal {
        _getFusionFactoryIndexSlot().value = value;
    }

    function setPlasmaVaultFactoryAddress(address value) internal {
        _getPlasmaVaultFactoryAddressSlot().value = value;
    }

    function setAccessManagerFactoryAddress(address value) internal {
        _getAccessManagerFactoryAddressSlot().value = value;
    }

    function setFeeManagerFactoryAddress(address value) internal {
        _getFeeManagerFactoryAddressSlot().value = value;
    }

    function setWithdrawManagerFactoryAddress(address value) internal {
        _getWithdrawManagerFactoryAddressSlot().value = value;
    }

    function setRewardsManagerFactoryAddress(address value) internal {
        _getRewardsManagerFactoryAddressSlot().value = value;
    }

    function setContextManagerFactoryAddress(address value) internal {
        _getContextManagerFactoryAddressSlot().value = value;
    }

    function setPriceManagerFactoryAddress(address value) internal {
        _getPriceManagerFactoryAddressSlot().value = value;
    }

    function setPlasmaVaultBaseAddress(address value) internal {
        _getPlasmaVaultBaseAddressSlot().value = value;
    }

    function setPriceOracleMiddlewareAddress(address value) internal {
        _getPriceOracleMiddlewareSlot().value = value;
    }

    function setBurnRequestFeeBalanceFuseAddress(address value) internal {
        _getBurnRequestFeeBalanceFuseAddressSlot().value = value;
    }

    function setBurnRequestFeeFuseAddress(address value) internal {
        _getBurnRequestFeeFuseAddressSlot().value = value;
    }

    function setWithdrawWindowInSeconds(uint256 value) internal {
        _getWithdrawWindowInSecondsSlot().value = value;
    }

    function setVestingPeriodInSeconds(uint256 value) internal {
        _getVestingPeriodInSecondsSlot().value = value;
    }

    function setAccessManagerBaseAddress(address value) internal {
        _getAccessManagerBaseAddressSlot().value = value;
    }

    function setWithdrawManagerBaseAddress(address value) internal {
        _getWithdrawManagerBaseAddressSlot().value = value;
    }

    function setRewardsManagerBaseAddress(address value) internal {
        _getRewardsManagerBaseAddressSlot().value = value;
    }

    function setContextManagerBaseAddress(address value) internal {
        _getContextManagerBaseAddressSlot().value = value;
    }

    function setPriceManagerBaseAddress(address value) internal {
        _getPriceManagerBaseAddressSlot().value = value;
    }

    function setPlasmaVaultCoreBaseAddress(address value) internal {
        _getPlasmaVaultCoreBaseAddressSlot().value = value;
    }

    function _getAccessManagerBaseAddressSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := ACCESS_MANAGER_BASE_ADDRESS
        }
    }

    function _getWithdrawManagerBaseAddressSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := WITHDRAW_MANAGER_BASE_ADDRESS
        }
    }

    function _getRewardsManagerBaseAddressSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := REWARDS_MANAGER_BASE_ADDRESS
        }
    }

    function _getContextManagerBaseAddressSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := CONTEXT_MANAGER_BASE_ADDRESS
        }
    }

    function _getPriceManagerBaseAddressSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := PRICE_MANAGER_BASE_ADDRESS
        }
    }

    function _getFusionFactoryVersionSlot() private pure returns (Uint256Type storage $) {
        assembly {
            $.slot := FUSION_FACTORY_VERSION
        }
    }

    function _getFusionFactoryIndexSlot() private pure returns (Uint256Type storage $) {
        assembly {
            $.slot := FUSION_FACTORY_INDEX
        }
    }

    function _getPlasmaVaultFactoryAddressSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := PLASMA_VAULT_FACTORY_ADDRESS
        }
    }

    function _getAccessManagerFactoryAddressSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := ACCESS_MANAGER_FACTORY_ADDRESS
        }
    }

    function _getFeeManagerFactoryAddressSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := FEE_MANAGER_FACTORY_ADDRESS
        }
    }

    function _getRewardsManagerFactoryAddressSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := REWARDS_MANAGER_FACTORY_ADDRESS
        }
    }

    function _getWithdrawManagerFactoryAddressSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := WITHDRAW_MANAGER_FACTORY_ADDRESS
        }
    }

    function _getContextManagerFactoryAddressSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := CONTEXT_MANAGER_FACTORY_ADDRESS
        }
    }

    function _getPriceManagerFactoryAddressSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := PRICE_MANAGER_FACTORY_ADDRESS
        }
    }

    function _getPlasmaVaultBaseAddressSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := PLASMA_VAULT_BASE_ADDRESS
        }
    }

    function _getPriceOracleMiddlewareSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := PRICE_ORACLE_MIDDLEWARE_ADDRESS
        }
    }

    function _getBurnRequestFeeBalanceFuseAddressSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := BURNR_REQUEST_FEE_BALANCE_FUSE_ADDRESS
        }
    }

    function _getBurnRequestFeeFuseAddressSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := BURN_REQUEST_FEE_FUSE_ADDRESS
        }
    }

    function _getWithdrawWindowInSecondsSlot() private pure returns (Uint256Type storage $) {
        assembly {
            $.slot := WITHDRAW_WINDOW_IN_SECONDS
        }
    }

    function _getVestingPeriodInSecondsSlot() private pure returns (Uint256Type storage $) {
        assembly {
            $.slot := VESTING_PERIOD_IN_SECONDS
        }
    }

    function _getPlasmaVaultCoreBaseAddressSlot() private pure returns (AddressType storage $) {
        assembly {
            $.slot := PLASMA_VAULT_CORE_BASE_ADDRESS
        }
    }

    // ============ DAO Fee Packages Storage Functions ============

    function _getDaoFeePackagesStorageSlot() private pure returns (DaoFeePackagesStorage storage $) {
        assembly {
            $.slot := DAO_FEE_PACKAGES_STORAGE_SLOT
        }
    }

    /// @notice Returns all DAO fee packages
    /// @return Array of DAO fee packages
    function getDaoFeePackages() internal view returns (FeePackage[] memory) {
        return _getDaoFeePackagesStorageSlot().packages;
    }

    /// @notice Returns a specific DAO fee package by index
    /// @param index_ Index of the DAO fee package
    /// @return DAO fee package at the specified index
    function getDaoFeePackage(uint256 index_) internal view returns (FeePackage memory) {
        return _getDaoFeePackagesStorageSlot().packages[index_];
    }

    /// @notice Returns the number of DAO fee packages
    /// @return Number of DAO fee packages
    function getDaoFeePackagesLength() internal view returns (uint256) {
        return _getDaoFeePackagesStorageSlot().packages.length;
    }

    /// @notice Sets DAO fee packages (replaces entire array)
    /// @param packages_ Array of DAO fee packages to set
    function setDaoFeePackages(FeePackage[] memory packages_) internal {
        delete _getDaoFeePackagesStorageSlot().packages;
        FeePackage[] storage storagePackages = _getDaoFeePackagesStorageSlot().packages;
        uint256 length = packages_.length;
        for (uint256 i; i < length; ++i) {
            storagePackages.push(packages_[i]);
        }
    }

    // ============ Business Client Fee Packages Storage Functions ============

    function _getBusinessClientFeePackagesStorageSlot()
        private
        pure
        returns (BusinessClientFeePackagesStorage storage $)
    {
        assembly {
            $.slot := BUSINESS_CLIENT_FEE_PACKAGES_STORAGE_SLOT
        }
    }

    /// @notice Returns all fee packages for a specific business client
    /// @param client_ Address of the business client
    /// @return Array of fee packages for the client
    function getBusinessClientFeePackages(address client_) internal view returns (FeePackage[] memory) {
        return _getBusinessClientFeePackagesStorageSlot().clientPackages[client_];
    }

    /// @notice Returns a specific fee package for a business client by index
    /// @param client_ Address of the business client
    /// @param index_ Index of the fee package
    /// @return Fee package at the specified index
    function getBusinessClientFeePackage(address client_, uint256 index_) internal view returns (FeePackage memory) {
        return _getBusinessClientFeePackagesStorageSlot().clientPackages[client_][index_];
    }

    /// @notice Returns the number of fee packages for a specific business client
    /// @param client_ Address of the business client
    /// @return Number of fee packages
    function getBusinessClientFeePackagesLength(address client_) internal view returns (uint256) {
        return _getBusinessClientFeePackagesStorageSlot().clientPackages[client_].length;
    }

    /// @notice Sets fee packages for a specific business client (replaces entire array)
    /// @param client_ Address of the business client
    /// @param packages_ Array of fee packages to set
    function setBusinessClientFeePackages(address client_, FeePackage[] memory packages_) internal {
        delete _getBusinessClientFeePackagesStorageSlot().clientPackages[client_];
        FeePackage[] storage storagePackages = _getBusinessClientFeePackagesStorageSlot().clientPackages[client_];
        uint256 length = packages_.length;
        for (uint256 i; i < length; ++i) {
            storagePackages.push(packages_[i]);
        }
    }

    /// @notice Removes all fee packages for a specific business client
    /// @param client_ Address of the business client
    function removeBusinessClientFeePackages(address client_) internal {
        delete _getBusinessClientFeePackagesStorageSlot().clientPackages[client_];
    }

    // ============ Fusion Vaults Storage Functions ============

    function _getFusionVaultsStorageSlot() private pure returns (FusionVaultsStorage storage $) {
        assembly {
            $.slot := FUSION_VAULTS_STORAGE_SLOT
        }
    }

    /// @notice Returns whether a PlasmaVault was recorded as produced by this factory
    /// @dev Provenance only, not endorsement. Registry integrity relies on the factory and base addresses
    /// configured by MAINTENANCE_MANAGER_ROLE at the time of creation and on implementation upgrades authorized
    /// by DEFAULT_ADMIN_ROLE.
    /// @param vault_ Address to check
    /// @return True if the vault was recorded during a successful clone
    function isFusionVault(address vault_) internal view returns (bool) {
        return _getFusionVaultsStorageSlot().vaults[vault_];
    }

    /// @notice Records a PlasmaVault as produced by this factory
    /// @dev One-way write: entries are permanent and there is intentionally no unset operation
    /// @param vault_ Address of the PlasmaVault to record
    function setFusionVault(address vault_) internal {
        _getFusionVaultsStorageSlot().vaults[vault_] = true;
    }
}
