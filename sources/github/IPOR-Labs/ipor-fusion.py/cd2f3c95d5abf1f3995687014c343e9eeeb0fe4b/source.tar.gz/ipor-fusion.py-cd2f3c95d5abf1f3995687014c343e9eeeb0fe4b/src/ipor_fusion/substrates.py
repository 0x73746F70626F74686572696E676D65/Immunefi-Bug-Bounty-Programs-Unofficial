"""Public per-market decoding of PlasmaVault bytes32 market substrates.

Each Fusion market stores its substrate grants as raw ``bytes32`` values whose
internal layout is market-specific (plain padded address, typed structs,
Morpho market ids, ...). This module is the canonical decoder registry used by
the CLI/MCP rendering and importable by external services (e.g. the fusion
registry) via :func:`decode_substrate` (re-exported from :mod:`ipor_fusion`).

Encodings are sourced from the Solidity fuse libraries in the ipor-fusion
contracts repo; every non-trivial decoder cites its library.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field

from eth_utils import keccak

from ipor_fusion.market_ids import IporFusionMarkets


@dataclass
class SubstrateInfo:
    address: str = ""
    raw_hex: str = ""
    type_label: str = ""
    is_error: bool = False
    extra: dict[str, str] = field(default_factory=dict)


# ── per-market substrate decoders ────────────────────────────────────────────
#
# Bit layout "type<<160": 11 zero bytes + 1 type byte + 20 address bytes
#   hex: [22 zeros][2 type chars][40 address chars]
#
# Bit layout "type<<248": 1 type byte + 11 zero bytes + 20 address bytes
#   hex: [2 type chars][22 zeros][40 address chars]
#   Slippage variant: [2 type chars][62 value chars]


def _decode_type_lshift160(hex_str: str, types: dict[int, str]) -> SubstrateInfo:
    """Decode type<<160 | address (Ebisu, Midas, Balancer, Velodrome)."""
    type_byte = int(hex_str[22:24], 16)
    addr = f"0x{hex_str[24:]}"
    label = types.get(type_byte, f"type={type_byte}")
    return SubstrateInfo(address=addr, type_label=label)


def _decode_type_lshift248(hex_str: str, types: dict[int, str]) -> SubstrateInfo:
    """Decode type<<248 | address_or_value (Odos, Velora, UTS, Aave V4)."""
    type_byte = int(hex_str[0:2], 16)
    if (label := types.get(type_byte, f"type={type_byte}")) == "Slippage":
        value = int(hex_str[2:], 16)
        return SubstrateInfo(
            raw_hex=f"0x{hex_str}", type_label=label, extra={"slippage": str(value)}
        )
    addr = f"0x{hex_str[24:]}"
    return SubstrateInfo(address=addr, type_label=label)


def _decode_plain_address(hex_str: str) -> SubstrateInfo:
    """Decode zero-padded address: 12 zero bytes + 20 address bytes."""
    return SubstrateInfo(address=f"0x{hex_str[24:]}")


def _decode_morpho(hex_str: str) -> SubstrateInfo:
    """Raw bytes32 Morpho market ID — no structure."""
    return SubstrateInfo(raw_hex=f"0x{hex_str}", type_label="morpho_market_id")


def _decode_uniswap_v4(hex_str: str) -> SubstrateInfo:
    """Uniswap V4 two-level whitelist (UniswapV4SubstrateLib.sol): a PoolId
    (raw bytes32, keccak256(abi.encode(PoolKey)) — carries the hook, fee tier
    and tick spacing, unrecoverable offline) or a pool currency granted as
    substrate-as-asset (12 zero bytes + address)."""
    if hex_str[:24] == "0" * 24:
        return SubstrateInfo(address=f"0x{hex_str[24:]}", type_label="uniswap_v4_token")
    return SubstrateInfo(raw_hex=f"0x{hex_str}", type_label="uniswap_v4_pool_id")


def _decode_enso(hex_str: str) -> SubstrateInfo:
    """Decode address<<96 | selector<<64 (Enso)."""
    addr = f"0x{hex_str[0:40]}"
    selector = f"0x{hex_str[40:48]}"
    return SubstrateInfo(
        address=addr, type_label="ENSO_TARGET", extra={"selector": selector}
    )


def _decode_dolomite(hex_str: str) -> SubstrateInfo:
    """Decode asset<<96 | subAccountId<<88 | canBorrow<<80 (Dolomite)."""
    addr = f"0x{hex_str[0:40]}"
    sub_account_id = int(hex_str[40:42], 16)
    can_borrow = (int(hex_str[42:44], 16) & 0x01) == 1
    return SubstrateInfo(
        address=addr,
        type_label="DOLOMITE_ASSET",
        extra={"sub_account_id": str(sub_account_id), "can_borrow": str(can_borrow)},
    )


def _decode_aave_v4(hex_str: str) -> SubstrateInfo:
    """Decode type<<248 | spoke<<88 | reserveId<<56 | flags<<48 (Aave V4).

    Source: AaveV4SubstrateLib.sol — type flag 1 = Reserve; the spoke address
    is left-aligned right after the type byte (bits 247..88), followed by a
    uint32 reserveId and a flags byte (bit0 isCollateral, bit1 canBorrow);
    bits 47..0 are reserved. The (spoke, reserveId) pair — not an asset
    address — identifies the market in Aave V4's Hub & Spoke design, so the
    generic type<<248 helper (address in the low 20 bytes) rendered these as
    garbage addresses.
    """
    type_byte = int(hex_str[0:2], 16)
    if type_byte != 1:
        label = "Undefined" if type_byte == 0 else f"type={type_byte}"
        return SubstrateInfo(raw_hex=f"0x{hex_str}", type_label=label)
    flags = int(hex_str[50:52], 16)
    return SubstrateInfo(
        address=f"0x{hex_str[2:42]}",
        type_label="AAVE_V4_RESERVE",
        extra={
            "reserve_id": str(int(hex_str[42:50], 16)),
            "is_collateral": str((flags & 0x01) == 1),
            "can_borrow": str((flags & 0x02) == 2),
        },
    )


def _decode_euler_v2(hex_str: str) -> SubstrateInfo:
    """Decode eulerVault<<96 | isCollateral<<88 | canBorrow<<80 | subAccounts<<72.

    Source: EulerFuseLib.substrateToBytes32 — address occupies the high 20 bytes
    (left-aligned), followed by three 1-byte flags. Decoding via the generic
    plain-address path silently produces a malformed address (last 20 bytes are
    flag bytes + zero padding).
    """
    addr = f"0x{hex_str[0:40]}"
    is_collateral = (int(hex_str[40:42], 16) & 0x01) == 1
    can_borrow = (int(hex_str[42:44], 16) & 0x01) == 1
    sub_account = f"0x{hex_str[44:46]}"
    return SubstrateInfo(
        address=addr,
        type_label="EULER_VAULT",
        extra={
            "is_collateral": str(is_collateral),
            "can_borrow": str(can_borrow),
            "sub_account": sub_account,
        },
    )


def _decode_async_action(hex_str: str) -> SubstrateInfo:
    """Decode AsyncActionFuse typed substrates.

    Source: AsyncActionFuseLib.sol — layout [substrateType 1 byte | data 31 bytes]:
    - ALLOWED_AMOUNT_TO_OUTSIDE (0): data = asset<<88 | uint88 amount, so the
      asset address sits directly after the type byte and the cap amount (in
      token decimals) is baked into the substrate key itself.
    - ALLOWED_TARGETS (1): data = target<<32 | bytes4 selector (7 high bytes
      of the data are zero).
    - ALLOWED_EXIT_SLIPPAGE (2): data = uint248 slippage, WAD (1e18 = 100%).
    """
    type_byte = int(hex_str[0:2], 16)
    if type_byte == 0:
        return SubstrateInfo(
            address=f"0x{hex_str[2:42]}",
            type_label="ALLOWED_AMOUNT_TO_OUTSIDE",
            extra={"amount": str(int(hex_str[42:64], 16))},
        )
    if type_byte == 1:
        return SubstrateInfo(
            address=f"0x{hex_str[16:56]}",
            type_label="ALLOWED_TARGETS",
            extra={"selector": f"0x{hex_str[56:64]}"},
        )
    if type_byte == 2:
        return SubstrateInfo(
            raw_hex=f"0x{hex_str}",
            type_label="ALLOWED_EXIT_SLIPPAGE",
            extra={"slippage": str(int(hex_str[2:64], 16))},
        )
    return SubstrateInfo(raw_hex=f"0x{hex_str}", type_label=f"type={type_byte}")


_EXTERNAL_STATE_ADDRESS_TYPES = {1: "ASSET", 3: "CUSTODIAN", 4: "BALANCE_ACCOUNT"}
# Scalar guards carry their unit in the extra key, since the four types share
# one payload shape but not one unit.
_EXTERNAL_STATE_SCALAR_TYPES = {
    5: ("STALENESS_MAX", "seconds"),
    6: ("BIG_CHANGE_BPS", "bps"),
    7: ("DUST_THRESHOLD", "percent"),
    8: ("MIN_UPDATE_INTERVAL", "seconds"),
}


def _decode_external_state(hex_str: str) -> SubstrateInfo:
    """Decode ExternalState typed substrates.

    Source: ExternalStateSubstrateLib.sol — layout [substrateType 1 byte |
    payload 31 bytes]:
    - ASSET (1), CUSTODIAN (3), BALANCE_ACCOUNT (4): payload = address in the
      low 20 bytes.
    - TARGET (2): payload = selector<<160 | target, so the 4-byte selector sits
      above the address (the 7 high payload bytes are zero). Note this is the
      mirror image of the async-action TARGET layout, where the selector is
      below the address.
    - STALENESS_MAX (5), BIG_CHANGE_BPS (6), DUST_THRESHOLD (7),
      MIN_UPDATE_INTERVAL (8): payload = uint248 scalar. The extra key names
      the unit -- ``seconds``, ``bps`` or ``percent`` (of one token) -- since
      the four types share a payload shape but not a unit.
    - UNDEFINED (0), the enum's invalid member, and any tag above 8 stay raw.
    """
    type_byte = int(hex_str[0:2], 16)
    if type_byte == 0:
        return SubstrateInfo(raw_hex=f"0x{hex_str}", type_label="UNDEFINED")
    if label := _EXTERNAL_STATE_ADDRESS_TYPES.get(type_byte):
        return SubstrateInfo(address=f"0x{hex_str[24:]}", type_label=label)
    if type_byte == 2:
        return SubstrateInfo(
            address=f"0x{hex_str[24:]}",
            type_label="TARGET",
            extra={"selector": f"0x{hex_str[16:24]}"},
        )
    if scalar := _EXTERNAL_STATE_SCALAR_TYPES.get(type_byte):
        label, unit = scalar
        return SubstrateInfo(
            raw_hex=f"0x{hex_str}",
            type_label=label,
            extra={unit: str(int(hex_str[2:], 16))},
        )
    return SubstrateInfo(raw_hex=f"0x{hex_str}", type_label=f"type={type_byte}")


_CROSSCHAIN_TYPES = {0: "UNDEFINED", 1: "EXECUTOR", 2: "REMOTE_VAULT"}


def _decode_crosschain(hex_str: str) -> SubstrateInfo:
    """Decode type<<248 | chainId<<160 | address (Crosschain market).

    Source: CrosschainSubstrateLib.sol -- EXECUTOR (1) is an executor on the
    vault's own chain (chain id slot zero); REMOTE_VAULT (2) is a remote
    PlasmaVault bound to the 88-bit destination chain id in bits 247..160, so
    the same vault address granted for another chain is a different grant.
    Non-canonical chain slots decode as errors because no fuse can match them.
    """
    type_byte = int(hex_str[0:2], 16)
    label = _CROSSCHAIN_TYPES.get(type_byte, f"type={type_byte}")
    if type_byte not in (1, 2):
        return SubstrateInfo(raw_hex=f"0x{hex_str}", type_label=label)
    chain_id = int(hex_str[2:24], 16)
    if (type_byte == 1 and chain_id != 0) or (type_byte == 2 and chain_id == 0):
        return SubstrateInfo(
            raw_hex=f"0x{hex_str}",
            type_label=label,
            is_error=True,
            extra={"chain_id": str(chain_id)},
        )
    info = SubstrateInfo(address=f"0x{hex_str[24:]}", type_label=label)
    if type_byte == 2:
        info.extra = {"chain_id": str(chain_id)}
    return info


# Market ID → decoder function.  Markets not listed here get raw hex output.
_SUBSTRATE_DECODERS: dict[int, Callable[[str], SubstrateInfo]] = {}


def _register_markets(
    market_ids: list[int], decoder: Callable[[str], SubstrateInfo]
) -> None:
    for mid in market_ids:
        _SUBSTRATE_DECODERS[mid] = decoder


# plain address (zero-padded) — most markets
_register_markets(
    [
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10,
        13,
        15,
        16,
        17,
        18,
        19,  # MORPHO_FLASH_LOAN — flash-loanable tokens (isSubstrateAsAssetGranted)
        20,
        21,
        23,
        24,
        25,
        26,
        27,
        28,
        29,
        30,
        33,
        34,
        35,
        37,
        44,  # SPARK_LEND — reuses AaveV3SupplyFuse (isSubstrateAsAssetGranted)
        46,  # NAPIER — isSubstrateAsAssetGranted, plain asset addresses
        *range(100_001, 100_021),  # ERC4626_0001 .. ERC4626_0020
    ],
    _decode_plain_address,
)
# Morpho markets — raw bytes32 market ids. MORPHO_FLASH_LOAN (19) is NOT one:
# MorphoFlashLoanFuse gates the loan token via isSubstrateAsAssetGranted, and
# every live market-19 substrate is the zero-padded address form (registry
# census 2026-09-03: 111 of 111 rows on Ethereum, Base and Arbitrum)
_register_markets([14, 22, 41], _decode_morpho)
# Ebisu
_register_markets(
    [39],
    lambda h: _decode_type_lshift160(h, {0: "UNDEFINED", 1: "ZAPPER", 2: "REGISTRY"}),
)
# Midas
_register_markets(
    [45],
    lambda h: _decode_type_lshift160(
        h,
        {
            0: "UNDEFINED",
            1: "M_TOKEN",
            2: "DEPOSIT_VAULT",
            3: "REDEMPTION_VAULT",
            4: "INSTANT_REDEMPTION_VAULT",
            5: "ASSET",
        },
    ),
)
# Balancer
_register_markets(
    [36],
    lambda h: _decode_type_lshift160(
        h, {0: "UNDEFINED", 1: "GAUGE", 2: "POOL", 3: "TOKEN"}
    ),
)
# Velodrome Superchain Slipstream
_register_markets(
    [32],
    lambda h: _decode_type_lshift160(h, {0: "UNDEFINED", 1: "Gauge", 2: "Pool"}),
)
# Aave V4 (id 49 per IporFusionMarkets.sol) — typed Reserve substrates per
# AaveV4SubstrateLib.sol; an earlier draft enum (Asset/Spoke, address in the
# low bytes) shipped here and decoded live substrates to garbage addresses
_register_markets([49], _decode_aave_v4)
# Odos
_register_markets(
    [42],
    lambda h: _decode_type_lshift248(h, {0: "Unknown", 1: "Token", 2: "Slippage"}),
)
# Velora
_register_markets(
    [43],
    lambda h: _decode_type_lshift248(h, {0: "Unknown", 1: "Token", 2: "Slippage"}),
)
# Universal Token Swapper — UniversalTokenSwapperSubstrateLib.sol, shared by
# UNIVERSAL_TOKEN_SWAPPER (12) and UNIVERSAL_TOKEN_SWAPPER_V2 (1202): the V2
# market granted exactly this layout live (weETH Enhanced Yield, Ethereum
# 0x2775e695…, 10 rows) and decoded as no_decoder while only 12 was registered
_register_markets(
    [12, 1202],
    lambda h: _decode_type_lshift248(
        h, {0: "Unknown", 1: "Token", 2: "Target", 3: "Slippage"}
    ),
)
# Enso
_register_markets([38], _decode_enso)
# Dolomite (id 47 per IporFusionMarkets.sol)
_register_markets([47], _decode_dolomite)
# Euler V2 (eulerVault<<96 | isCollateral<<88 | canBorrow<<80 | subAccounts<<72)
_register_markets([11], _decode_euler_v2)
# Async Action (typed: amount-to-outside / target+selector / exit slippage)
_register_markets([40], _decode_async_action)
# External State (typed: asset / target+selector / custodian / balance account
# / four uint248 guards). RWA (50) is the deprecated alias of EXTERNAL_STATE.
_register_markets([50], _decode_external_state)
# Uniswap V4 (id 53 per IporFusionMarkets.sol): PoolId or pool currency.
# TERM_FINANCE (52) stays unregistered on purpose — its substrate library is
# not mirrored here yet, and no_decoder(TERM_FINANCE) is the honest answer.
# SPOL_UNSTAKE (424243) likewise: SPOLUnstakeFuse is not in the public
# contracts repo, so its substrate grant check cannot be verified — the market
# doc says the sPOLController address, but no_decoder until the fuse is mirrored
_register_markets([53], _decode_uniswap_v4)
# Crosschain (id 54 on the contracts' crosschain branch): EXECUTOR /
# REMOTE_VAULT typed substrates per CrosschainSubstrateLib.sol. The mainnet
# POC vault (Ethereum 0x0Aa75BfD…) granted the same layout under the
# keccak-derived market id its fuses were built with, so that id decodes too.
_register_markets(
    [
        54,
        int.from_bytes(keccak(text="IPOR_FUSION_CROSSCHAIN_USDC_POC_V1"), "big"),
    ],
    _decode_crosschain,
)


def _build_market_lookup() -> dict[int, str]:
    aliases = IporFusionMarkets._DEPRECATED_ALIASES
    lookup: dict[int, str] = {}
    for name in dir(IporFusionMarkets):
        if name.startswith("_") or name in aliases:
            continue
        val = getattr(IporFusionMarkets, name)
        if isinstance(val, int):
            lookup[val] = name
    return lookup


_MARKET_LOOKUP: dict[int, str] = _build_market_lookup()


def market_name(market_id: int) -> str:
    return _MARKET_LOOKUP.get(market_id, "UNKNOWN")


_UINT256_MAX = 2**256 - 1


def format_market_label(market_id: int) -> str:
    """Render a market id as ``NAME (id)`` for display.

    Special-cases the ``uint256.max`` sentinel used by burn-fee fuses
    (ZERO_BALANCE_MARKET) — printing the full 78-digit number is noisy.
    """
    if market_id == _UINT256_MAX:
        name = market_name(market_id)
        return f"{name} (uint256.max)" if name != "UNKNOWN" else "uint256.max"
    label = market_name(market_id)
    return f"{label} ({market_id})" if label != "UNKNOWN" else str(market_id)


def decode_substrate(raw: bytes | str, market_id: int | None = None) -> SubstrateInfo:
    """Decode one bytes32 substrate in the context of ``market_id``.

    ``raw`` is the 32-byte value either as ``bytes`` or as a hex string
    (``0x``-prefixed or bare). Anything that is not exactly 32 bytes comes
    back as ``is_error=True``; a market without a registered decoder comes
    back raw with a ``no_decoder(NAME)`` label — never a guessed address.
    """
    if isinstance(raw, str):
        try:
            raw = bytes.fromhex(raw.removeprefix("0x"))
        except ValueError:
            return SubstrateInfo(raw_hex=raw, is_error=True)
    hex_str = raw.hex()
    if len(hex_str) != 64:
        return SubstrateInfo(raw_hex=f"0x{hex_str}", is_error=True)

    if market_id is not None:
        if decoder := _SUBSTRATE_DECODERS.get(market_id):
            return decoder(hex_str)
        # Known-length but no decoder — show raw with warning
        return SubstrateInfo(
            raw_hex=f"0x{hex_str}",
            type_label=f"no_decoder({market_name(market_id)})",
        )

    # No market context — show raw hex
    return SubstrateInfo(raw_hex=f"0x{hex_str}")
