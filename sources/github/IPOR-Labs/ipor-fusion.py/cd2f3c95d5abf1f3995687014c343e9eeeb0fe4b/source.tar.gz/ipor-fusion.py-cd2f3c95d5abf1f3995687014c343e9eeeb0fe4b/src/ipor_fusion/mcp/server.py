"""MCP server exposing IPOR Fusion CLI as tools for Claude Code.

Calls the ipor_fusion SDK directly — no CLI subprocess.
Configuration is loaded from the shared CLI config (~/.config/ipor-fusion/).
"""

from typing import Annotated, Literal

from mcp.server.fastmcp import FastMCP
from pydantic import Field
from web3 import Web3

from ipor_fusion.about import package_version, read_changelog, repository_url
from ipor_fusion.chains import CHAIN_NAMES, ensure_supported_chain
from ipor_fusion.cli.config_store import (
    FusionConfig,
    VaultEntry,
    load_config,
    mask_provider_url,
    save_config,
)
from ipor_fusion.cli.market_cmd import _build_json as _build_morpho_blue_json
from ipor_fusion.cli.market_cmd import _meta_morpho_json
from ipor_fusion.cli.morpho_api import (
    PUBLIC_ALLOCATOR_ADDRESSES,
    MorphoApiError,
    fetch_market,
    fetch_vault,
)
from ipor_fusion.cli.vault_cmd import (
    _build_json_output,
)
from ipor_fusion.cli.vault_fetcher import (
    _fetch_deployment_info,
    _fetch_vault_data,
)
from ipor_fusion.config.roles import Roles
from ipor_fusion.core.access import resolve_access_manager
from ipor_fusion.core.context import Web3Context
from ipor_fusion.core.plasma_vault import PlasmaVault
from ipor_fusion.mcp.guide import register_guide
from ipor_fusion.mcp.models import (
    ActionResult,
    ChangelogEntryModel,
    ConfigShowResponse,
    MetaMorphoVaultResponse,
    MorphoBlueMarketResponse,
    OracleMappingResponse,
    RoleAccountsResponse,
    ServerInfoResponse,
    VaultInfoResponse,
    VaultListEntry,
)
from ipor_fusion.readers.morpho import MorphoReader, morpho_blue_address
from ipor_fusion.readers.oracle_mapping import build_oracle_mapping
from ipor_fusion.types import MorphoBlueMarketId

mcp = FastMCP(
    "ipor-fusion",
    instructions=(
        "Inspection and configuration tools for IPOR Fusion Plasma Vaults. "
        "Start with config_show / vault_list; vault_info is the "
        "comprehensive per-vault summary. Read the fusion://invariants "
        "resource before writing code that deploys or configures a vault."
    ),
    website_url=repository_url() or None,
)
# FastMCP exposes no version kwarg; left unset, the initialize handshake
# reports the mcp library's version as serverInfo.version.
mcp._mcp_server.version = package_version()
register_guide(mcp)


# ---------------------------------------------------------------------------
# Resolution helpers
# ---------------------------------------------------------------------------


def _resolve_provider(cfg: FusionConfig, chain_id: int) -> str:
    if provider_url := cfg.providers.get(str(chain_id)):
        return provider_url
    raise ValueError(
        f"No provider for chain {chain_id}. Use config_set_provider to configure one."
    )


def _resolve_chain_id(cfg: FusionConfig, vault_address: str, chain_id: int) -> int:
    if chain_id:
        return chain_id
    entry = next(
        (v for v in cfg.vaults if v.address.lower() == vault_address.lower()),
        None,
    )
    if entry:
        return entry.chain_id
    if len(cfg.providers) == 1:
        return int(next(iter(cfg.providers)))
    raise ValueError(
        "Cannot auto-detect chain ID. Use chain_id parameter or save the vault first."
    )


def _build_ctx(
    cfg: FusionConfig, chain_id: int, block_number: int = 0
) -> tuple[Web3Context, int | None]:
    provider_url = _resolve_provider(cfg, chain_id)
    ctx = Web3Context.from_url(provider_url)
    effective_block = block_number if block_number else None
    if effective_block is not None:
        ctx.default_block = effective_block
    return ctx, effective_block


# ---------------------------------------------------------------------------
# Server tools
# ---------------------------------------------------------------------------


# Named after the server rather than the data — a deliberate break from the
# kebab-to-snake naming parity the other tools keep with the CLI, whose sibling
# command is `fusion changelog`. The initialize handshake never reaches the
# model, so a tool is the only reliable answer to "which server is this", and
# version/repository ride along with the changelog.
@mcp.tool()
def server_info(
    changelog_since: Annotated[
        str,
        Field(
            description="Return every release newer than this version, e.g. "
            "'3.1.0'. Expects a version, not a date. Default returns only the "
            "running version's entry."
        ),
    ] = "",
) -> ServerInfoResponse:
    """Identify this MCP server and report what changed in its releases."""
    return ServerInfoResponse(
        name=mcp.name,
        version=package_version(),
        repository=repository_url(),
        changelog=[
            ChangelogEntryModel.from_entry(entry)
            for entry in read_changelog(changelog_since)
        ],
    )


# ---------------------------------------------------------------------------
# Vault tools
# ---------------------------------------------------------------------------


@mcp.tool()
def vault_info(
    vault_address: str,
    chain_id: int = 0,
    block_number: int = 0,
) -> VaultInfoResponse:
    """Get full on-chain state of a Plasma Vault — the comprehensive summary.

    Returns a structured VaultInfoResponse — see model field descriptions
    for the complete output schema (assets, balance fuses, fees, withdraw
    manager, reconciliation, lending health, substrates, role accounts,
    etc.).

    Args:
        vault_address: Vault address (required).
        chain_id: Chain ID (auto-detected if 0).
        block_number: Block number (latest if 0).
    """
    cfg = load_config()
    chain_id = _resolve_chain_id(cfg, vault_address, chain_id)
    # Fail fast (before any RPC) on chains the vault tooling can't handle;
    # UnsupportedChainError doubles as ValueError so FastMCP surfaces it.
    ensure_supported_chain(chain_id)
    ctx, effective_block = _build_ctx(cfg, chain_id, block_number)
    checksum = Web3.to_checksum_address(vault_address)

    # Cheap single-call probe: raises the typed ContractNotFoundError /
    # NotPlasmaVaultError ("not a vault" in both revert and empty-return
    # flavors) before the expensive fetch. The fetch itself stays catch-free:
    # once the probe passes, any later failure is a real error on a real
    # vault and must stay loud.
    resolve_access_manager(ctx, checksum)

    plasma_vault = PlasmaVault(ctx, checksum)
    data = _fetch_vault_data(ctx, plasma_vault, effective_block, chain_id=chain_id)

    api_key = cfg.etherscan_api_key
    chain_label = CHAIN_NAMES.get(chain_id, str(chain_id))
    (
        data.deployment_block,
        data.deployment_timestamp,
        data.deployment_error,
    ) = _fetch_deployment_info(ctx, chain_id, vault_address, api_key)

    result = _build_json_output(
        ctx, plasma_vault, data, vault_address, chain_id, chain_label, api_key
    )
    return VaultInfoResponse.model_validate(result)


# Static mirror of Roles member names: pyright rejects a dynamically built
# enum in annotations, so the drift guard lives in test_mcp_server.py.
RoleName = Literal[
    "ADMIN_ROLE",
    "OWNER_ROLE",
    "GUARDIAN_ROLE",
    "TECH_PLASMA_VAULT_ROLE",
    "IPOR_DAO_ROLE",
    "TECH_CONTEXT_MANAGER_ROLE",
    "TECH_WITHDRAW_MANAGER_ROLE",
    "TECH_VAULT_TRANSFER_SHARES_ROLE",
    "ATOMIST_ROLE",
    "ALPHA_ROLE",
    "FUSE_MANAGER_ROLE",
    "PRE_HOOKS_MANAGER_ROLE",
    "TECH_PERFORMANCE_FEE_MANAGER_ROLE",
    "TECH_MANAGEMENT_FEE_MANAGER_ROLE",
    "CLAIM_REWARDS_ROLE",
    "TECH_REWARDS_CLAIM_MANAGER_ROLE",
    "TRANSFER_REWARDS_ROLE",
    "WHITELIST_ROLE",
    "CONFIG_INSTANT_WITHDRAWAL_FUSES_ROLE",
    "WITHDRAW_MANAGER_REQUEST_FEE_ROLE",
    "WITHDRAW_MANAGER_WITHDRAW_FEE_ROLE",
    "UPDATE_MARKETS_BALANCES_ROLE",
    "UPDATE_REWARDS_BALANCE_ROLE",
    "PRICE_ORACLE_MIDDLEWARE_MANAGER_ROLE",
    "PUBLIC_ROLE",
]


@mcp.tool()
def vault_role_accounts(
    vault_address: Annotated[str, Field(description="Plasma Vault address.")],
    role: Annotated[
        RoleName | None,
        Field(description="Role to filter by; omit to list all roles."),
    ] = None,
    chain_id: Annotated[int, Field(description="Chain ID (auto-detected if 0).")] = 0,
    block_number: Annotated[int, Field(description="Block number (latest if 0).")] = 0,
) -> RoleAccountsResponse:
    """List confirmed role holders on a Plasma Vault's AccessManager.

    TECH_* roles are held by protocol contracts, not EOAs.
    Cost: scans RoleGranted logs + one hasRole read per unique
    (role, account) pair; can be slow on vaults with many grants and
    needs a provider that serves broad eth_getLogs queries.
    """
    cfg = load_config()
    role_id = None if role is None else Roles.resolve(role)
    chain_id = _resolve_chain_id(cfg, vault_address, chain_id)
    # The RoleGranted scan needs broad eth_getLogs — fail fast (before any
    # RPC) on chains the vault tooling is not validated on.
    ensure_supported_chain(chain_id)
    ctx, _ = _build_ctx(cfg, chain_id, block_number)
    checksum = Web3.to_checksum_address(vault_address)

    access_manager = resolve_access_manager(ctx, checksum)
    accounts = (
        access_manager.get_all_role_accounts()
        if role_id is None
        else access_manager.get_accounts_with_role(role_id)
    )
    return RoleAccountsResponse.from_role_accounts(
        accounts,
        vault=checksum,
        access_manager=access_manager.address,
        chain_id=chain_id,
        role_filter=Roles.get_name(role_id) if role_id is not None else None,
    )


@mcp.tool()
def vault_oracle_mapping(
    vault_address: Annotated[str, Field(description="Plasma Vault address.")],
    chain_id: Annotated[int, Field(description="Chain ID (auto-detected if 0).")] = 0,
    block_number: Annotated[int, Field(description="Block number (latest if 0).")] = 0,
) -> OracleMappingResponse:
    """Map how a Plasma Vault prices every configured asset at a block.

    For each asset the vault's price oracle knows about, resolves the source
    price feed, classifies its type by on-chain interface probing, reads the
    effective price, and recursively resolves feeds that derive their price
    from another asset. Unknown feeds are reported as partial, never dropped.

    Source types: DualCrossReferencePriceFeed (X/USD composed from an X/Y and
    a Y/USD component feed, both reported in source_detail),
    ChainlinkAggregator (leaf feed confirmed by the full AggregatorV3Interface
    — latestRoundData, decimals, description, version — with sane metadata),
    chainlink_style (leaf that merely answers latestRoundData, or whose
    evidence is contradicted: synthetic zero roundId/updatedAt, empty
    description, a foreign getter answering; still resolved, but verify the
    address yourself if identity matters), ERC4626PriceFeed (share→asset
    rate, recurses on the underlying), CollateralTokenOnMorphoMarketPriceFeed
    (recurses on the loan token), middleware_fallback (no per-vault source;
    priced by the oracle's underlying global middleware, followed as a
    dependency when discoverable), custom_unknown (partial). Classification is
    heuristic interface probing: it grades on-chain evidence and cannot prove
    a contract's identity or operator.

    Every aggregator-compatible read reports description() and the full
    latestRoundData round in source_detail (description, round_id, answer,
    decimals, started_at, started_at_utc, updated_at, updated_at_utc,
    answered_in_round); Chainlink-tier leaves add aggregator and phase_id
    (proxy-deployment evidence; null when unanswered). Raw values only — no
    staleness judgment is made (composed feeds may return synthetic zero
    timestamps; their *_utc twins are null then, while the raw ints keep
    fidelity), and description is null when the feed does not implement it.
    Use the description to confirm a feed's units before trusting its
    answer. Registry-resolved fallback
    prices carry no per-feed metadata — the registry picks the aggregator
    internally; its address is included, so agents can call getFeed on
    demand.

    Node status: resolved (own feed explained and every dependency resolved),
    partially_resolved (own feed explained, but some descendant is not
    resolved), or partial (the node's own resolution is incomplete — see
    reason). The unresolved array lists partial nodes only; demoted parents
    self-describe. The mapping-level status rolls up the roots: resolved
    (every root resolved; vacuously for zero assets), unresolved (every
    root partial — total failure), else partially_resolved.

    Assets are enumerated via getConfiguredAssets() when the oracle exposes
    it, else by replaying AssetPriceSourceUpdated logs (asset_source:
    'events'). Historical blocks require an archive node.
    """
    if block_number < 0:
        raise ValueError("block_number must be >= 0")
    cfg = load_config()
    chain_id = _resolve_chain_id(cfg, vault_address, chain_id)
    # The asset-source event replay scans logs from block 0 — fail fast
    # (before any RPC) on chains the vault tooling is not validated on.
    ensure_supported_chain(chain_id)
    ctx, _ = _build_ctx(cfg, chain_id, block_number)
    checksum = Web3.to_checksum_address(vault_address)

    # The event-replay fallback and the output both need a concrete block
    # number, so resolve "latest" up front and pin the context to it.
    effective_block = block_number if block_number else ctx.web3.eth.block_number
    ctx.default_block = effective_block

    resolve_access_manager(ctx, checksum)

    mapping = build_oracle_mapping(ctx, checksum, effective_block)
    return OracleMappingResponse.from_mapping(mapping)


@mcp.tool()
def vault_list() -> list[VaultListEntry]:
    """List all saved Plasma Vaults with their chain, label, and address."""
    cfg = load_config()
    return [
        VaultListEntry(
            address=v.address,
            label=v.label,
            chain=CHAIN_NAMES.get(v.chain_id, str(v.chain_id)),
            chain_id=v.chain_id,
        )
        for v in cfg.vaults
    ]


@mcp.tool()
def vault_add(
    address: str,
    label: str = "",
    chain_id: int = 0,
) -> ActionResult:
    """Save a Plasma Vault to the local config.

    Args:
        address: Vault address (required).
        label: Human-readable label (fetched from on-chain name() if empty).
        chain_id: Chain ID (auto-detected when only one provider configured).
    """
    cfg = load_config()

    if not chain_id:
        if len(cfg.providers) == 1:
            chain_id = int(next(iter(cfg.providers)))
        else:
            raise ValueError(
                "Cannot auto-detect chain ID — multiple providers configured. "
                "Provide chain_id."
            )

    if not label:
        provider_url = _resolve_provider(cfg, chain_id)
        ctx = Web3Context.from_url(provider_url)
        checksum = Web3.to_checksum_address(address)
        try:
            label = PlasmaVault(ctx, checksum).name().call()
        except Exception:
            label = checksum

    for vault_entry in cfg.vaults:
        if vault_entry.address.lower() == address.lower():
            vault_entry.label = label
            vault_entry.chain_id = chain_id
            save_config(cfg)
            return ActionResult(message=f"Vault {label} ({address}) updated.")

    cfg.vaults.append(VaultEntry(address=address, label=label, chain_id=chain_id))
    save_config(cfg)
    return ActionResult(message=f"Vault {label} ({address}) added.")


@mcp.tool()
def vault_remove(address: str) -> ActionResult:
    """Remove a Plasma Vault from the local config.

    Args:
        address: Vault address to remove.
    """
    cfg = load_config()
    before = len(cfg.vaults)
    cfg.vaults = [v for v in cfg.vaults if v.address.lower() != address.lower()]
    if len(cfg.vaults) == before:
        return ActionResult(message="Vault not found.")
    save_config(cfg)
    return ActionResult(message="Vault removed.")


# ---------------------------------------------------------------------------
# Config tools
# ---------------------------------------------------------------------------


@mcp.tool()
def config_show() -> ConfigShowResponse:
    """Show current fusion CLI configuration.

    Provider URLs are masked to scheme and host: the stored value may carry an
    API key in its path or query string.
    """
    cfg = load_config()
    return ConfigShowResponse(
        providers={
            chain_id: mask_provider_url(url) for chain_id, url in cfg.providers.items()
        },
        vaults=[
            VaultListEntry(
                address=v.address,
                label=v.label,
                chain=CHAIN_NAMES.get(v.chain_id, str(v.chain_id)),
                chain_id=v.chain_id,
            )
            for v in cfg.vaults
        ],
        etherscan_api_key="***" if cfg.etherscan_api_key else None,
    )


@mcp.tool()
def config_set_provider(url: str, chain_id: int = 0) -> ActionResult:
    """Set RPC provider URL for a chain.

    Args:
        url: RPC provider URL.
        chain_id: Chain ID (auto-detected via eth_chainId if 0).
    """
    if not chain_id:
        web3 = Web3(Web3.HTTPProvider(url))
        chain_id = web3.eth.chain_id

    cfg = load_config()
    cfg.providers[str(chain_id)] = url
    save_config(cfg)
    return ActionResult(message=f"Provider for chain {chain_id} set.")


@mcp.tool()
def config_set_etherscan_key(api_key: str) -> ActionResult:
    """Set Etherscan API key (works for all chains via Etherscan V2).

    Args:
        api_key: Etherscan API key.
    """
    cfg = load_config()
    cfg.etherscan_api_key = api_key
    save_config(cfg)
    return ActionResult(message="Etherscan API key set.")


# ---------------------------------------------------------------------------
# Market tools
# ---------------------------------------------------------------------------


@mcp.tool()
def market_morpho_blue(
    market_id: str,
    chain_id: int,
    block_number: int = 0,
    no_api: bool = False,
) -> MorphoBlueMarketResponse:
    """Inspect a Morpho Blue market by its 32-byte market ID.

    Returns market parameters, on-chain state + APYs (via IRM `borrowRateView`),
    and — unless `no_api` is set — the MetaMorpho vaults supplying this market
    along with their PublicAllocator flow caps and admin addresses.

    Returned JSON fields:
        market_id, chain_id, public_allocator
        market_params: { loan_token, collateral_token, oracle, irm, lltv }
        state: { total_supply_assets, total_supply_shares, total_borrow_assets,
                 total_borrow_shares, liquidity_assets, fee_wad, last_update }
        rates: { rate_per_second_wad, utilization, borrow_apy, supply_apy }
        loan_asset / collateral_asset: { address, symbol, decimals } (when API used)
        vaults: list of supplying vaults with public_allocator_config flow caps
        api_error: string if Morpho API call failed (state still returned)

    Args:
        market_id: 32-byte market ID (0x-prefixed hex or 64 raw hex chars).
        chain_id: EVM chain ID (1 = Ethereum, 8453 = Base, ...).
        block_number: Block number for on-chain reads (latest if 0).
        no_api: Skip Morpho API call (no vault discovery / PublicAllocator info).
    """
    raw = market_id.strip().removeprefix("0x").removeprefix("0X").lower()
    if len(raw) != 64 or not all(c in "0123456789abcdef" for c in raw):
        raise ValueError(
            f"invalid Morpho market ID (expected 32-byte hex): {market_id}"
        )

    cfg = load_config()
    ctx, _ = _build_ctx(cfg, chain_id, block_number)
    reader = MorphoReader(ctx, morpho_blue_address(chain_id))
    mid = MorphoBlueMarketId(raw)
    params, state = reader.require_market(mid)
    rates = reader.rates_from(state, params)

    api_market = None
    api_error: str | None = None
    if not no_api:
        try:
            api_market = fetch_market(raw, chain_id)
        except MorphoApiError as exc:
            api_error = str(exc)

    public_allocator = PUBLIC_ALLOCATOR_ADDRESSES.get(chain_id)
    payload = _build_morpho_blue_json(
        raw, chain_id, params, state, rates, api_market, api_error, public_allocator
    )
    return MorphoBlueMarketResponse.model_validate(payload)


@mcp.tool()
def market_meta_morpho(
    vault_address: str,
    chain_id: int,
) -> MetaMorphoVaultResponse:
    """Inspect a MetaMorpho V1 or Morpho Vault V2 by address (Morpho API).

    Auto-detects vault version. Returns roles (owner/curator/allocators/sentinels),
    fees, adapters (V2) or supply allocations (V1), and per-market caps with
    remaining headroom — useful for deciding whether liquidity can be pushed
    into a Morpho Blue market via reallocate.

    Returned JSON fields (shape depends on `version`):
        version: "v1" or "v2"
        chain_id, address, name, symbol
        asset: { address, symbol, decimals }
        total_assets
        owner, curator, allocators
        v2 only: idle_assets, liquidity, share_price, max_apy, performance_fee,
                 performance_fee_recipient, management_fee, management_fee_recipient,
                 sentinels, liquidity_adapter, adapters, caps
        v1 only: fee_wad, guardian, fee_recipient, public_allocator, allocations

    Args:
        vault_address: MetaMorpho V1 or Vault V2 address.
        chain_id: EVM chain ID.
    """
    try:
        info = fetch_vault(vault_address, chain_id)
    except MorphoApiError as exc:
        raise ValueError(str(exc)) from exc
    payload = _meta_morpho_json(info, chain_id)
    return MetaMorphoVaultResponse.model_validate(payload)


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
