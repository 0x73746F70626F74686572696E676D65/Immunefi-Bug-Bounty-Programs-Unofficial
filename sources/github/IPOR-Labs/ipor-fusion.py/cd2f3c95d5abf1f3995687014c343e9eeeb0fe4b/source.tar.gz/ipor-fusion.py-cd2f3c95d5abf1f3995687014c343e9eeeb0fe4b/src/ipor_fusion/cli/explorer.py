from __future__ import annotations

import json
import threading
import time
from urllib.parse import urlencode
from urllib.request import urlopen

from ipor_fusion.cli.config_store import load_contract_cache, update_contract_cache

ETHERSCAN_V2_URL = "https://api.etherscan.io/v2/api"

SUPPORTED_CHAINS = {1, 42161, 8453, 10, 137, 56, 43114, 250}

_MAX_RETRIES = 3
_RETRY_DELAY = 1.0


class _RateLimiter:
    def __init__(self, calls_per_second: float = 2.5):
        self._min_interval = 1.0 / calls_per_second
        self._lock = threading.Lock()
        self._last_call = 0.0

    def wait(self) -> None:
        with self._lock:
            now = time.monotonic()
            if (elapsed := now - self._last_call) < self._min_interval:
                time.sleep(self._min_interval - elapsed)
            self._last_call = time.monotonic()


_etherscan_limiter = _RateLimiter(2.5)


def get_contract_name(chain_id: int, address: str, api_key: str | None = None) -> str:
    cache = load_contract_cache()
    cache_key = f"{chain_id}:{address}"

    if cached := cache.get(cache_key):
        return cached

    if name := _fetch_contract_name(chain_id, address, api_key):
        update_contract_cache(cache_key, name)
        return name
    return ""


def get_deployment_tx(
    chain_id: int, address: str, api_key: str | None = None
) -> tuple[str | None, str | None]:
    """Return ``(tx_hash, error)`` for a contract deployment.

    ``error`` is a short machine-readable code when ``tx_hash`` is None and the
    failure has a known cause; ``None`` means either success or a benign empty
    result (e.g. Etherscan responded with "No data found").
    """
    return _fetch_contract_creation_tx(chain_id, address, api_key)


def _fetch_contract_creation_tx(
    chain_id: int, address: str, api_key: str | None = None
) -> tuple[str | None, str | None]:
    if chain_id not in SUPPORTED_CHAINS:
        return None, "chain-not-supported"
    if not api_key:
        return None, "no-api-key"

    params: dict[str, str] = {
        "chainid": str(chain_id),
        "module": "contract",
        "action": "getcontractcreation",
        "contractaddresses": address,
        "apikey": api_key,
    }

    url = f"{ETHERSCAN_V2_URL}?{urlencode(params)}"
    last_error: str | None = "fetch-failed"
    for attempt in range(_MAX_RETRIES):
        _etherscan_limiter.wait()
        try:
            with urlopen(url, timeout=10) as resp:  # noqa: S310
                data = json.loads(resp.read().decode())
            if data.get("status") == "1" and data.get("result"):
                return data["result"][0].get("txHash"), None  # type: ignore[no-any-return]
            result_text = str(data.get("result", "")).lower()
            if "free api access is not supported" in result_text:
                return None, "etherscan-paid-tier-required"
            if "rate limit" in result_text:
                last_error = "rate-limited"
                time.sleep(_RETRY_DELAY * (attempt + 1))
                continue
            # status=0 with "No data found" — benign, no error
            last_error = None
        except (OSError, json.JSONDecodeError, KeyError, IndexError):
            last_error = "fetch-failed"
        break
    return None, last_error


def _fetch_getsourcecode(
    chain_id: int, address: str, api_key: str | None = None
) -> dict[str, str] | None:
    if chain_id not in SUPPORTED_CHAINS:
        return None
    if not api_key:
        return None

    params: dict[str, str] = {
        "chainid": str(chain_id),
        "module": "contract",
        "action": "getsourcecode",
        "address": address,
        "apikey": api_key,
    }

    url = f"{ETHERSCAN_V2_URL}?{urlencode(params)}"
    for attempt in range(_MAX_RETRIES):
        _etherscan_limiter.wait()
        try:
            with urlopen(url, timeout=10) as resp:  # noqa: S310
                data = json.loads(resp.read().decode())
            if data.get("status") == "1" and data.get("result"):
                return data["result"][0]  # type: ignore[no-any-return]
            if "rate limit" in str(data.get("result", "")).lower():
                time.sleep(_RETRY_DELAY * (attempt + 1))
                continue
        except (OSError, json.JSONDecodeError, KeyError, IndexError):
            pass
        break
    return None


def _fetch_contract_name(
    chain_id: int, address: str, api_key: str | None = None
) -> str | None:
    result = _fetch_getsourcecode(chain_id, address, api_key)
    if result is None:
        return None
    return result.get("ContractName") or None
