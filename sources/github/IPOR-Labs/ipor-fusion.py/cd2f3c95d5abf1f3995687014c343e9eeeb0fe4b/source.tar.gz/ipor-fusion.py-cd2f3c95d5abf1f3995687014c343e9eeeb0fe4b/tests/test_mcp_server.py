"""Tests for the MCP server tool definitions (direct SDK import)."""

import asyncio
import importlib.metadata
from unittest.mock import MagicMock, patch

import pytest
from web3 import Web3

from ipor_fusion import (
    DOCS,
    ChangelogEntry,
    ContractNotFoundError,
    NotPlasmaVaultError,
    RoleAccount,
    Roles,
    UnsupportedChainError,
)
from ipor_fusion.cli.morpho_api import (
    MorphoApiError,
    MorphoApiMarket,
    VaultAllocation,
    VaultFlowCap,
    VaultV1Info,
    VaultV1MarketAllocation,
    VaultV2Adapter,
    VaultV2Cap,
    VaultV2Info,
)
from ipor_fusion.errors import MorphoMarketNotFoundError
from ipor_fusion.guide import RESOURCES
from ipor_fusion.mcp.models import (
    FeesSection,
    OracleNodeModel,
    WithdrawManagerDetails,
)
from ipor_fusion.mcp.server import (
    config_set_etherscan_key,
    config_set_provider,
    config_show,
    market_meta_morpho,
    market_morpho_blue,
    mcp,
    server_info,
    vault_add,
    vault_info,
    vault_list,
    vault_oracle_mapping,
    vault_remove,
    vault_role_accounts,
)
from ipor_fusion.readers import oracle_mapping
from ipor_fusion.readers.morpho import (
    MorphoMarket,
    MorphoMarketParams,
    MorphoMarketRates,
)
from ipor_fusion.readers.oracle_mapping import (
    OracleAsset,
    OracleMapping,
    OracleNode,
    OraclePrice,
)
from ipor_fusion.types import Period, RoleId


def _empty_config():
    from ipor_fusion.cli.config_store import FusionConfig

    return FusionConfig()


def _config_with_provider():
    from ipor_fusion.cli.config_store import FusionConfig

    return FusionConfig(providers={"1": "https://rpc.example.com"})


def _config_with_provider_for(chain_id: int):
    from ipor_fusion.cli.config_store import FusionConfig

    return FusionConfig(providers={str(chain_id): "https://rpc.example.com"})


def _config_with_keyed_provider():
    from ipor_fusion.cli.config_store import FusionConfig

    return FusionConfig(providers={"1": "https://rpc.example.com/v2/SECRETKEY"})


def _config_with_vault():
    from ipor_fusion.cli.config_store import FusionConfig, VaultEntry

    return FusionConfig(
        providers={"1": "https://rpc.example.com"},
        vaults=[VaultEntry(address="0xABC", label="Test", chain_id=1)],
    )


class TestServerMetadata:
    def test_handshake_reports_package_version(self):
        opts = mcp._mcp_server.create_initialization_options()
        assert opts.server_version == importlib.metadata.version("ipor-fusion")

    def test_handshake_carries_instructions_and_website_url(self):
        opts = mcp._mcp_server.create_initialization_options()
        assert opts.instructions
        assert opts.website_url == "https://github.com/IPOR-Labs/ipor-fusion.py"


class TestGuide:
    def test_handshake_points_at_the_invariants(self):
        opts = mcp._mcp_server.create_initialization_options()
        assert "fusion://invariants" in (opts.instructions or "")

    def test_serves_every_guide_document_as_a_resource(self):
        listed = {str(r.uri): r for r in asyncio.run(mcp.list_resources())}
        assert set(listed) == {doc.uri for doc in RESOURCES}
        for doc in RESOURCES:
            assert listed[doc.uri].description == doc.description
            assert listed[doc.uri].mimeType == "text/markdown"
            (content,) = asyncio.run(mcp.read_resource(doc.uri))
            assert content.content == doc.text

    def test_lists_the_guide_prompts_with_their_arguments(self):
        prompts = {p.name: p for p in asyncio.run(mcp.list_prompts())}
        assert set(prompts) == {
            "quickstart",
            "deploy_vault",
            "analyze_vault",
            "trace_oracle_pricing",
            "explain_fuse",
        }
        for prompt in prompts.values():
            assert prompt.description and "\n" not in prompt.description
        arguments = {
            name: {a.name: a.required for a in (p.arguments or [])}
            for name, p in prompts.items()
        }
        assert arguments["quickstart"] == {}
        assert arguments["deploy_vault"] == {
            "chain_id": True,
            "asset": True,
            "market": False,
        }
        assert arguments["analyze_vault"] == {"chain_id": True, "vault_address": True}
        assert arguments["trace_oracle_pricing"] == {
            "chain_id": True,
            "vault_address": True,
            "asset": False,
        }
        assert arguments["explain_fuse"] == {"chain_id": True, "fuse": True}

    def test_quickstart_names_the_read_write_split(self):
        result = asyncio.run(mcp.get_prompt("quickstart"))
        (message,) = result.messages
        text = message.content.text  # type: ignore[union-attr]
        assert message.role == "user"
        assert "fusion://invariants" in text
        assert "fusion://quickstart" in text
        assert "read-only" in text
        assert "pip install ipor-fusion" in text

    def test_deploy_prompt_sends_the_agent_to_the_quickstart(self):
        result = asyncio.run(
            mcp.get_prompt("deploy_vault", {"chain_id": "42161", "asset": "USDC"})
        )
        text = result.messages[0].content.text  # type: ignore[union-attr]
        assert "fusion://quickstart" in text and "fusion://invariants" in text
        assert "chain 42161" in text and "USDC" in text and "AAVE_V3" in text
        assert "IporFusionFactoryProxy" in text
        assert "convert_to_public_vault" in text

    def test_prompts_carry_their_arguments_into_the_text(self):
        args = {"chain_id": "8453", "vault_address": "0xVault"}
        result = asyncio.run(mcp.get_prompt("analyze_vault", args))
        text = result.messages[0].content.text  # type: ignore[union-attr]
        assert "vault_info" in text
        assert "chain_id=8453" in text and "vault_address=0xVault" in text

        result = asyncio.run(
            mcp.get_prompt("trace_oracle_pricing", {**args, "asset": "0xAsset"})
        )
        text = result.messages[0].content.text  # type: ignore[union-attr]
        assert "vault_oracle_mapping" in text
        # The asset narrows what the answer covers, but it is never handed to
        # the tool: `vault_oracle_mapping` takes vault_address, chain_id and
        # block_number only, and an invented argument fails schema validation.
        assert "0xAsset" in text
        assert "asset=0xAsset" not in text

        result = asyncio.run(mcp.get_prompt("trace_oracle_pricing", args))
        every_asset = result.messages[0].content.text  # type: ignore[union-attr]
        assert "every configured asset" in every_asset
        assert "0xAsset" not in every_asset

        result = asyncio.run(
            mcp.get_prompt(
                "explain_fuse", {"chain_id": "8453", "fuse": "SupplyFuseAaveV3"}
            )
        )
        text = result.messages[0].content.text  # type: ignore[union-attr]
        assert "SupplyFuseAaveV3" in text and "AaveV3SupplyFuse" in text


class TestServerInfo:
    def test_reports_the_server_name(self):
        # Version and repository are covered by the agreement test below,
        # which chains to the handshake tests' literals.
        assert server_info().name == "ipor-fusion"

    def test_handshake_and_tool_agree_on_version_and_repository(self):
        # Two channels, one source: the handshake the client reads and the
        # tool the model calls must report the same facts. They encode an
        # unknown repository differently on purpose — the tool returns "" to
        # keep its response shape flat, the handshake gets None because an
        # empty websiteUrl would advertise a link to nowhere — so normalize
        # before comparing.
        opts = mcp._mcp_server.create_initialization_options()
        result = server_info()
        assert result.version == opts.server_version
        assert result.repository == (opts.website_url or "")

    def test_default_returns_only_the_running_version(self):
        result = server_info()
        assert [entry.version for entry in result.changelog] == [result.version]

    @patch("ipor_fusion.mcp.server.read_changelog", return_value=[])
    def test_changelog_since_is_passed_through(self, read):
        server_info(changelog_since="3.1.0")
        read.assert_called_once_with("3.1.0")

    @patch(
        "ipor_fusion.mcp.server.read_changelog",
        return_value=[
            ChangelogEntry("3.5.0", "2026-07-30", "### Bug Fixes\n\n- **sdk**: Fix"),
            ChangelogEntry("3.4.1", None, ""),
        ],
    )
    def test_maps_entries_including_a_dateless_empty_release(self, _read):
        changelog = server_info().changelog
        assert [(e.version, e.date, e.notes) for e in changelog] == [
            ("3.5.0", "2026-07-30", "### Bug Fixes\n\n- **sdk**: Fix"),
            ("3.4.1", None, ""),
        ]


class TestConfigShow:
    @patch("ipor_fusion.mcp.server.load_config", return_value=_empty_config())
    def test_empty_config(self, _):
        result = config_show()
        assert result.providers == {}
        assert result.vaults == []
        assert result.etherscan_api_key is None

    @patch("ipor_fusion.mcp.server.load_config", return_value=_config_with_vault())
    def test_config_with_vault(self, _):
        result = config_show()
        assert len(result.vaults) == 1
        assert result.vaults[0].address == "0xABC"

    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_keyed_provider(),
    )
    def test_provider_url_is_masked(self, _):
        result = config_show()
        assert result.providers == {"1": "https://rpc.example.com"}


class TestConfigSetProvider:
    @patch("ipor_fusion.mcp.server.save_config")
    @patch("ipor_fusion.mcp.server.load_config", return_value=_empty_config())
    def test_with_chain_id(self, mock_load, mock_save):
        result = config_set_provider(url="https://rpc.example.com", chain_id=1)
        assert "chain 1" in result.message.lower()
        saved_cfg = mock_save.call_args[0][0]
        assert saved_cfg.providers["1"] == "https://rpc.example.com"

    @patch("ipor_fusion.mcp.server.Web3")
    @patch("ipor_fusion.mcp.server.save_config")
    @patch("ipor_fusion.mcp.server.load_config", return_value=_empty_config())
    def test_auto_detect_chain_id(self, mock_load, mock_save, mock_web3):
        mock_instance = MagicMock()
        mock_instance.eth.chain_id = 42161
        mock_web3.return_value = mock_instance
        mock_web3.HTTPProvider = MagicMock()

        result = config_set_provider(url="https://rpc.example.com")
        assert "42161" in result.message
        saved_cfg = mock_save.call_args[0][0]
        assert saved_cfg.providers["42161"] == "https://rpc.example.com"


class TestConfigSetEtherscanKey:
    @patch("ipor_fusion.mcp.server.save_config")
    @patch("ipor_fusion.mcp.server.load_config", return_value=_empty_config())
    def test_sets_key(self, mock_load, mock_save):
        result = config_set_etherscan_key(api_key="ABC123")
        assert "set" in result.message.lower()
        saved_cfg = mock_save.call_args[0][0]
        assert saved_cfg.etherscan_api_key == "ABC123"


class TestVaultList:
    @patch("ipor_fusion.mcp.server.load_config", return_value=_empty_config())
    def test_empty(self, _):
        result = vault_list()
        assert result == []

    @patch("ipor_fusion.mcp.server.load_config", return_value=_config_with_vault())
    def test_with_vault(self, _):
        result = vault_list()
        assert len(result) == 1
        assert result[0].address == "0xABC"
        assert result[0].label == "Test"
        assert result[0].chain_id == 1


class TestVaultAdd:
    @patch("ipor_fusion.mcp.server.save_config")
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_add_with_label_and_chain(self, mock_load, mock_save):
        result = vault_add(address="0xDEF", label="New Vault", chain_id=1)
        assert "added" in result.message.lower()
        saved_cfg = mock_save.call_args[0][0]
        assert any(v.address == "0xDEF" for v in saved_cfg.vaults)

    @patch("ipor_fusion.mcp.server.save_config")
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_vault(),
    )
    def test_update_existing(self, mock_load, mock_save):
        result = vault_add(address="0xABC", label="Updated", chain_id=1)
        assert "updated" in result.message.lower()
        saved_cfg = mock_save.call_args[0][0]
        assert len(saved_cfg.vaults) == 1
        assert saved_cfg.vaults[0].label == "Updated"


class TestVaultRemove:
    @patch("ipor_fusion.mcp.server.save_config")
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_vault(),
    )
    def test_remove_existing(self, mock_load, mock_save):
        result = vault_remove(address="0xABC")
        assert "removed" in result.message.lower()
        saved_cfg = mock_save.call_args[0][0]
        assert len(saved_cfg.vaults) == 0

    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_vault(),
    )
    def test_remove_missing(self, _):
        result = vault_remove(address="0xNONEXISTENT")
        assert "not found" in result.message.lower()


# ── vault_role_accounts ───────────────────────────────────────────────


VAULT_ADDR = "0x" + "22" * 20


def _role_account(role_id: int, account: str, delay: int = 0) -> RoleAccount:
    return RoleAccount(
        account=account,  # type: ignore[arg-type]
        role_id=RoleId(role_id),
        is_member=True,
        execution_delay=Period(delay),
    )


def _mock_manager(accounts: list[RoleAccount]) -> MagicMock:
    manager = MagicMock()
    manager.address = "0xAM"
    manager.get_all_role_accounts.return_value = accounts
    manager.get_accounts_with_role.return_value = accounts
    return manager


class TestVaultRoleAccounts:
    @patch("ipor_fusion.mcp.server.resolve_access_manager")
    @patch("ipor_fusion.mcp.server._build_ctx", return_value=(MagicMock(), None))
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_all_roles(self, _load, _ctx, mock_resolve):
        manager = _mock_manager(
            [_role_account(100, "0xBBBB"), _role_account(1, "0xaaaa", delay=60)]
        )
        mock_resolve.return_value = manager

        result = vault_role_accounts(vault_address=VAULT_ADDR)

        manager.get_all_role_accounts.assert_called_once()
        manager.get_accounts_with_role.assert_not_called()
        assert result.role_filter is None
        assert result.access_manager == "0xAM"
        assert result.chain_id == 1  # single-provider fallback
        assert [
            (e.account, e.role_id, e.role_name, e.execution_delay)
            for e in result.accounts
        ] == [
            ("0xaaaa", 1, "OWNER_ROLE", 60),
            ("0xBBBB", 100, "ATOMIST_ROLE", 0),
        ]

    @patch("ipor_fusion.mcp.server.resolve_access_manager")
    @patch("ipor_fusion.mcp.server._build_ctx", return_value=(MagicMock(), None))
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_filtered_by_normalized_name(self, _load, _ctx, mock_resolve):
        manager = _mock_manager([_role_account(100, "0xBBBB")])
        mock_resolve.return_value = manager

        result = vault_role_accounts(vault_address=VAULT_ADDR, role="atomist")

        manager.get_accounts_with_role.assert_called_once_with(100)
        manager.get_all_role_accounts.assert_not_called()
        assert result.role_filter == "ATOMIST_ROLE"

    @patch("ipor_fusion.mcp.server._build_ctx")
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_unknown_role_fails_before_rpc(self, _load, mock_ctx):
        with pytest.raises(ValueError, match="Valid: ADMIN_ROLE"):
            vault_role_accounts(vault_address=VAULT_ADDR, role="archbishop")
        mock_ctx.assert_not_called()

    @patch(
        "ipor_fusion.mcp.server.resolve_access_manager",
        side_effect=NotPlasmaVaultError("not a vault"),
    )
    @patch("ipor_fusion.mcp.server._build_ctx", return_value=(MagicMock(), None))
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_guard_errors_propagate(self, _load, _ctx, _resolve):
        with pytest.raises(NotPlasmaVaultError, match="not a vault"):
            vault_role_accounts(vault_address=VAULT_ADDR)

    @patch("ipor_fusion.mcp.server._build_ctx")
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_unsupported_chain_fails_before_rpc(self, _load, mock_ctx):
        with pytest.raises(UnsupportedChainError, match=r"chain 10 \(optimism\)"):
            vault_role_accounts(vault_address=VAULT_ADDR, chain_id=10)
        mock_ctx.assert_not_called()

    def test_role_arg_schema_enum_matches_roles(self):
        # Guards drift between the static RoleName Literal (advertised as a
        # schema enum) and the Roles IntEnum.
        tools = asyncio.run(mcp.list_tools())
        tool = next(t for t in tools if t.name == "vault_role_accounts")
        role_prop = tool.inputSchema["properties"]["role"]
        enum_values = next(alt["enum"] for alt in role_prop["anyOf"] if "enum" in alt)
        assert set(enum_values) == {r.name for r in Roles}


# ── vault_oracle_mapping ──────────────────────────────────────────────


def _oracle_node() -> OracleNode:
    return OracleNode(
        asset="0xUSDC",  # type: ignore[arg-type]
        symbol="USDC",
        decimals=6,
        source="0xFEED",  # type: ignore[arg-type]
        price=OraclePrice(
            raw="99980000",
            decimals=8,
            normalized_wad=str(99_980_000 * 10**10),
        ),
        source_type="ChainlinkAggregator",
        path=["USDC", "Chainlink feed"],
        status="resolved",
    )


def _oracle_mapping(block_number: int = 123) -> OracleMapping:
    return OracleMapping(
        vault=VAULT_ADDR,  # type: ignore[arg-type]
        vault_name="Reservoir",
        asset=OracleAsset(
            address="0xUSDC",  # type: ignore[arg-type]
            symbol="USDC",
            decimals=6,
        ),
        price_oracle="0xORACLE",  # type: ignore[arg-type]
        block_number=block_number,
        asset_source="getConfiguredAssets",
        status="resolved",
        configured_assets=[_oracle_node()],
        unresolved=[],
    )


def _oracle_ctx(latest_block: int = 777) -> MagicMock:
    ctx = MagicMock()
    ctx.web3.eth.block_number = latest_block
    ctx.default_block = "latest"
    return ctx


class TestVaultOracleMapping:
    @patch("ipor_fusion.mcp.server.build_oracle_mapping")
    @patch("ipor_fusion.mcp.server.resolve_access_manager")
    @patch("ipor_fusion.mcp.server._build_ctx")
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_latest_block_resolved_and_pinned(
        self, _load, mock_build_ctx, _resolve, mock_build
    ):
        ctx = _oracle_ctx(latest_block=777)
        mock_build_ctx.return_value = (ctx, None)
        mock_build.return_value = _oracle_mapping(block_number=777)

        result = vault_oracle_mapping(vault_address=VAULT_ADDR)

        # latest resolved to a number, passed to the SDK, and pinned on the ctx
        assert mock_build.call_args.args[2] == 777
        assert ctx.default_block == 777
        assert result.block_number == 777
        assert result.vault_name == "Reservoir"
        assert result.asset_source == "getConfiguredAssets"
        assert [n.symbol for n in result.configured_assets] == ["USDC"]
        assert result.unresolved == []

    @patch("ipor_fusion.mcp.server.build_oracle_mapping")
    @patch("ipor_fusion.mcp.server.resolve_access_manager")
    @patch("ipor_fusion.mcp.server._build_ctx")
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_explicit_block_passed_and_pinned(
        self, _load, mock_build_ctx, _resolve, mock_build
    ):
        ctx = _oracle_ctx()
        mock_build_ctx.return_value = (ctx, 500)
        mock_build.return_value = _oracle_mapping(block_number=500)

        vault_oracle_mapping(vault_address=VAULT_ADDR, block_number=500)

        assert mock_build.call_args.args[2] == 500
        assert ctx.default_block == 500

    @patch("ipor_fusion.mcp.server._build_ctx")
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_negative_block_rejected_before_rpc(self, _load, mock_build_ctx):
        with pytest.raises(ValueError, match="block_number must be >= 0"):
            vault_oracle_mapping(vault_address=VAULT_ADDR, block_number=-1)
        mock_build_ctx.assert_not_called()

    @patch("ipor_fusion.mcp.server.build_oracle_mapping")
    @patch(
        "ipor_fusion.mcp.server.resolve_access_manager",
        side_effect=NotPlasmaVaultError("not a vault"),
    )
    @patch("ipor_fusion.mcp.server._build_ctx")
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_guard_errors_propagate_before_build(
        self, _load, mock_build_ctx, _resolve, mock_build
    ):
        mock_build_ctx.return_value = (_oracle_ctx(), None)

        with pytest.raises(NotPlasmaVaultError, match="not a vault"):
            vault_oracle_mapping(vault_address=VAULT_ADDR)
        mock_build.assert_not_called()

    @patch("ipor_fusion.mcp.server._build_ctx")
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_unsupported_chain_fails_before_rpc(self, _load, mock_build_ctx):
        with pytest.raises(UnsupportedChainError, match=r"chain 10 \(optimism\)"):
            vault_oracle_mapping(vault_address=VAULT_ADDR, chain_id=10)
        mock_build_ctx.assert_not_called()

    def test_tool_registered(self):
        tools = asyncio.run(mcp.list_tools())
        assert "vault_oracle_mapping" in {t.name for t in tools}

    def test_every_source_type_documented(self):
        # Tripwire for the "Adding a feed type" checklist: every TYPE_* value
        # must appear verbatim in the model's source_type description and the
        # tool docstring — the two LLM-facing doc surfaces.
        values = [
            value
            for name, value in vars(oracle_mapping).items()
            if name.startswith("TYPE_")
        ]
        assert len(values) >= 7  # sanity: the type set as of this writing

        field_description = OracleNodeModel.model_fields["source_type"].description
        assert field_description is not None
        tool_doc = vault_oracle_mapping.__doc__
        assert tool_doc is not None
        for value in values:
            assert value in field_description, value
            assert value in tool_doc, value


# Mirrors of the constants in test_mcp_models.py, where their rationale is
# written out. Duplicated rather than shared across test modules, but not
# silently: both files parametrize over DOCS and assert against these, so a
# block or cross-reference added to one alone fails in the other.
_MODEL_BY_BLOCK = {
    "fees": FeesSection,
    "withdraw_manager_details": WithdrawManagerDetails,
}
_CROSS_REFERENCES = {("withdraw_manager_details", "fees")}


class TestVaultInfoGuards:
    @patch(
        "ipor_fusion.mcp.server.resolve_access_manager",
        side_effect=ContractNotFoundError("No contract found at 0x22... on chain 1."),
    )
    @patch("ipor_fusion.mcp.server._build_ctx", return_value=(MagicMock(), None))
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_no_contract_raises_typed(self, _load, _ctx, mock_resolve):
        with pytest.raises(ContractNotFoundError, match="No contract found"):
            vault_info(vault_address=VAULT_ADDR, chain_id=1)
        # The probe receives the checksummed address.
        mock_resolve.assert_called_once()
        assert mock_resolve.call_args.args[1] == Web3.to_checksum_address(VAULT_ADDR)

    @patch(
        "ipor_fusion.mcp.server.resolve_access_manager",
        side_effect=NotPlasmaVaultError("does not appear to be a Plasma Vault"),
    )
    @patch("ipor_fusion.mcp.server._build_ctx", return_value=(MagicMock(), None))
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_not_a_vault_raises_typed(self, _load, _ctx, _resolve):
        with pytest.raises(NotPlasmaVaultError, match="does not appear"):
            vault_info(vault_address=VAULT_ADDR, chain_id=1)

    @patch(
        "ipor_fusion.mcp.server._fetch_vault_data",
        side_effect=RuntimeError("some sub-call failed"),
    )
    @patch("ipor_fusion.mcp.server.resolve_access_manager")
    @patch("ipor_fusion.mcp.server._build_ctx", return_value=(MagicMock(), None))
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_other_fetch_errors_propagate(self, _load, _ctx, _resolve, _fetch):
        with pytest.raises(RuntimeError, match="some sub-call failed"):
            vault_info(vault_address=VAULT_ADDR, chain_id=1)

    @patch("ipor_fusion.mcp.server._build_ctx")
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_unsupported_chain_fails_before_rpc(self, _load, mock_build_ctx):
        with pytest.raises(UnsupportedChainError, match=r"chain 10 \(optimism\)"):
            vault_info(vault_address=VAULT_ADDR, chain_id=10)
        mock_build_ctx.assert_not_called()

    @pytest.mark.parametrize("block", sorted(DOCS))
    def test_output_schema_publishes_field_docs(self, block):
        # Typing the fee and withdraw blocks only buys anything if FastMCP
        # actually publishes their descriptions. A lossy serialization path
        # would leave the models right and the clients back where they were:
        # an object with no documentation. TestFieldDocsWiring in
        # test_mcp_models.py guards the models themselves.
        tools = asyncio.run(mcp.list_tools())
        tool = next(t for t in tools if t.name == "vault_info")
        assert tool.outputSchema is not None
        model = _MODEL_BY_BLOCK[block]
        properties = tool.outputSchema["$defs"][model.__name__]["properties"]
        skipped = set()
        for key, text in DOCS[block].items():
            if key not in properties:
                skipped.add((block, key))
                continue
            assert properties[key]["description"] == text, f"{model.__name__}.{key}"
        # Only the pinned cross-references may be missing; anything else means
        # a documented property was dropped on the way to the client, which an
        # unpinned skip would turn into a pass.
        assert skipped == {c for c in _CROSS_REFERENCES if c[0] == block}


# ── market tools ──────────────────────────────────────────────────────


_MARKET_ID = "ad656d430bb3d8c1469bf45c8ad4ebae1b04be04757c69fa424eec78d7b3f4dc"
_LOAN = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"
_COLLAT = "0xD2af830E8CBdFed6CC11Bab697bB25496ed6FA62"
_ORACLE = "0x7C65985C35181D51eF7571FA40211B57659B7d80"
_IRM = "0x870Ac11D48B15db9a138Cf899d20F13F79Ba00BC"
_VAULT = "0xf9bDdD4A9b3a45F980E11Fdde96E16364DDBec49"


def _stub_reader_instance():
    reader = MagicMock()
    params = MorphoMarketParams(
        loan_token=_LOAN,
        collateral_token=_COLLAT,
        oracle=_ORACLE,
        irm=_IRM,
        lltv=915 * 10**15,
    )
    market = MorphoMarket(
        total_supply_assets=1_008_277,
        total_supply_shares=1_008_277_000_000,
        total_borrow_assets=908_170,
        total_borrow_shares=908_170_000_000,
        last_update=1700000000,
        fee=0,
    )
    reader.require_market.return_value = (params, market)
    reader.rates_from.return_value = MorphoMarketRates(
        rate_per_second_wad=10**9,
        utilization=0.9,
        borrow_apy=0.032,
        supply_apy=0.029,
    )
    return reader


def _api_market():
    return MorphoApiMarket(
        market_id="0x" + _MARKET_ID,
        lltv=915 * 10**15,
        loan_token=_LOAN,
        loan_symbol="USDC",
        loan_decimals=6,
        collateral_token=_COLLAT,
        collateral_symbol="WOUSD",
        collateral_decimals=18,
        oracle=_ORACLE,
        irm=_IRM,
        supply_assets=1_008_277,
        borrow_assets=908_170,
        liquidity_assets=100_107,
        utilization=0.9,
        supply_apy=0.029,
        borrow_apy=0.032,
        fee_wad=0,
        timestamp=1700000000,
        vaults=[
            VaultAllocation(
                vault_address=_VAULT,
                vault_name="Yearn OG USDC",
                vault_symbol="ymvOG-USDC",
                asset_symbol="USDC",
                asset_decimals=6,
                total_assets=2_000_000_000,
                supply_assets=0,
                supply_cap=1_500_000_000_000,
                allocators=[_VAULT],
                flow_cap=VaultFlowCap(
                    fee_wei=10**15,
                    max_in=750_000_000_000,
                    max_out=250_000_000_000,
                    admin=_VAULT,
                ),
            )
        ],
    )


class TestMarketMorphoBlue:
    @patch("ipor_fusion.mcp.server.fetch_market")
    @patch("ipor_fusion.mcp.server.MorphoReader")
    @patch("ipor_fusion.mcp.server.Web3Context")
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_returns_market_state_and_vaults(
        self, _load, mock_ctx_cls, mock_reader_cls, mock_fetch
    ):
        mock_ctx_cls.from_url.return_value = MagicMock()
        mock_reader_cls.return_value = _stub_reader_instance()
        mock_fetch.return_value = _api_market()

        result = market_morpho_blue(market_id=_MARKET_ID, chain_id=1)

        assert result.market_id == "0x" + _MARKET_ID
        assert result.chain_id == 1
        assert result.public_allocator is not None  # singleton on Ethereum
        assert result.market_params.loan_token == _LOAN
        assert result.market_params.lltv == str(915 * 10**15)
        assert result.state.liquidity_assets == "100107"
        assert result.rates.utilization == 0.9
        assert result.api_error is None
        assert result.loan_asset is not None
        assert result.loan_asset.symbol == "USDC"
        assert result.vaults is not None and len(result.vaults) == 1
        vault = result.vaults[0]
        assert vault.public_allocator_config is not None
        assert vault.public_allocator_config.max_in == "750000000000"

    @patch("ipor_fusion.mcp.server.fetch_market")
    @patch("ipor_fusion.mcp.server.MorphoReader")
    @patch("ipor_fusion.mcp.server.Web3Context")
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_no_api_skips_fetch(self, _load, mock_ctx_cls, mock_reader_cls, mock_fetch):
        mock_ctx_cls.from_url.return_value = MagicMock()
        mock_reader_cls.return_value = _stub_reader_instance()

        result = market_morpho_blue(market_id=_MARKET_ID, chain_id=1, no_api=True)

        assert mock_fetch.call_count == 0
        assert result.vaults is None
        assert result.loan_asset is None
        assert result.api_error is None

    @patch("ipor_fusion.mcp.server.fetch_market", side_effect=MorphoApiError("down"))
    @patch("ipor_fusion.mcp.server.MorphoReader")
    @patch("ipor_fusion.mcp.server.Web3Context")
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_api_error_surfaces_in_response(
        self, _load, mock_ctx_cls, mock_reader_cls, _fetch
    ):
        mock_ctx_cls.from_url.return_value = MagicMock()
        mock_reader_cls.return_value = _stub_reader_instance()

        result = market_morpho_blue(market_id=_MARKET_ID, chain_id=1)

        assert result.api_error == "down"
        assert result.vaults is None  # API didn't populate
        # On-chain rates still returned
        assert result.rates.utilization == 0.9

    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_invalid_market_id_rejected(self, _load):
        try:
            market_morpho_blue(market_id="0xdead", chain_id=1)
        except ValueError as exc:
            assert "invalid Morpho market ID" in str(exc)
        else:
            raise AssertionError("expected ValueError")

    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_empty_config(),
    )
    def test_missing_provider_errors(self, _load):
        try:
            market_morpho_blue(market_id=_MARKET_ID, chain_id=1)
        except ValueError as exc:
            assert "No provider for chain" in str(exc)
        else:
            raise AssertionError("expected ValueError")

    @patch("ipor_fusion.mcp.server.MorphoReader")
    @patch("ipor_fusion.mcp.server.Web3Context")
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider_for(137),
    )
    def test_chain_without_morpho_deployment_rejected(
        self, _load, mock_ctx_cls, mock_reader_cls
    ):
        """A provider alone is not enough — Morpho Blue must be deployed there."""
        mock_ctx_cls.from_url.return_value = MagicMock()

        with pytest.raises(UnsupportedChainError, match=r"chain 137 \(polygon\)"):
            market_morpho_blue(market_id=_MARKET_ID, chain_id=137)

        mock_reader_cls.assert_not_called()

    @patch("ipor_fusion.mcp.server.MorphoReader")
    @patch("ipor_fusion.mcp.server.Web3Context")
    @patch(
        "ipor_fusion.mcp.server.load_config",
        return_value=_config_with_provider(),
    )
    def test_unknown_market_id_surfaces_not_found(
        self, _load, mock_ctx_cls, mock_reader_cls
    ):
        mock_ctx_cls.from_url.return_value = MagicMock()
        reader = _stub_reader_instance()
        reader.require_market.side_effect = MorphoMarketNotFoundError("no such market")
        mock_reader_cls.return_value = reader

        with pytest.raises(MorphoMarketNotFoundError, match="no such market"):
            market_morpho_blue(market_id=_MARKET_ID, chain_id=1)


def _v1_info():
    return VaultV1Info(
        address=_VAULT,
        name="Test V1",
        symbol="tv1",
        asset_address=_LOAN,
        asset_symbol="USDC",
        asset_decimals=6,
        total_assets=1_000_000_000,
        fee_wad=10**17,
        owner="0x" + "1" * 40,
        curator="0x" + "2" * 40,
        guardian="0x" + "3" * 40,
        fee_recipient="0x" + "4" * 40,
        allocators=[_VAULT],
        allocations=[
            VaultV1MarketAllocation(
                market_id="0x" + _MARKET_ID,
                lltv=915 * 10**15,
                loan_symbol="USDC",
                loan_decimals=6,
                collateral_symbol="WOUSD",
                market_supply_assets=1_000,
                market_borrow_assets=500,
                market_supply_apy=0.03,
                supply_assets=0,
                supply_cap=1_500_000_000_000,
            )
        ],
        public_allocator=VaultFlowCap(fee_wei=0, max_in=0, max_out=0, admin=_VAULT),
        public_allocator_flow_caps={"0x" + _MARKET_ID: (750_000_000_000, 0)},
    )


def _v2_info():
    cap = VaultV2Cap(
        cap_id="0xcap0",
        cap_type="MarketV1",
        id_data="0x",
        absolute_cap=1_500_000_000_000,
        relative_cap_wad=10**18,
        allocation=57,
        market_id="0x" + _MARKET_ID,
        loan_token=_LOAN,
        collateral_token=_COLLAT,
        oracle=_ORACLE,
        irm=_IRM,
        lltv=915 * 10**15,
    )
    adapter = VaultV2Adapter(
        address="0x" + "5" * 40,
        adapter_type="MorphoMarketV1",
        assets=100,
        inner_vault=None,
    )
    return VaultV2Info(
        address=_VAULT,
        name="Yearn OG USDC",
        symbol="yOG-USDC-V2",
        asset_address=_LOAN,
        asset_symbol="USDC",
        asset_decimals=6,
        total_assets=857_498_945_341,
        idle_assets=0,
        liquidity=844_616_692_135,
        share_price=1.018620,
        max_apy=1.71,
        performance_fee=0.0,
        performance_fee_recipient="0x" + "0" * 40,
        management_fee=0.0,
        management_fee_recipient="0x" + "0" * 40,
        owner="0x" + "1" * 40,
        curator="0x" + "2" * 40,
        allocators=["0x" + "3" * 40],
        sentinels=[],
        liquidity_adapter=adapter,
        adapters=[adapter],
        caps=[cap],
    )


class TestMarketMetaMorpho:
    @patch("ipor_fusion.mcp.server.fetch_vault", return_value=_v2_info())
    def test_returns_v2_vault(self, _fetch):
        result = market_meta_morpho(vault_address=_VAULT, chain_id=1)
        assert result.version == "v2"
        assert result.name == "Yearn OG USDC"
        assert result.caps is not None and len(result.caps) == 1
        assert result.caps[0]["loan_token"] == _LOAN
        # v1-only fields should be None
        assert result.fee_wad is None
        assert result.allocations is None

    @patch("ipor_fusion.mcp.server.fetch_vault", return_value=_v1_info())
    def test_returns_v1_vault(self, _fetch):
        result = market_meta_morpho(vault_address=_VAULT, chain_id=1)
        assert result.version == "v1"
        assert result.name == "Test V1"
        assert result.fee_wad == str(10**17)
        assert result.allocations is not None and len(result.allocations) == 1
        # v2-only fields should be None
        assert result.caps is None
        assert result.adapters is None

    @patch(
        "ipor_fusion.mcp.server.fetch_vault",
        side_effect=MorphoApiError("not found"),
    )
    def test_unknown_vault_errors(self, _fetch):
        try:
            market_meta_morpho(vault_address=_VAULT, chain_id=1)
        except ValueError as exc:
            assert "not found" in str(exc)
        else:
            raise AssertionError("expected ValueError")
