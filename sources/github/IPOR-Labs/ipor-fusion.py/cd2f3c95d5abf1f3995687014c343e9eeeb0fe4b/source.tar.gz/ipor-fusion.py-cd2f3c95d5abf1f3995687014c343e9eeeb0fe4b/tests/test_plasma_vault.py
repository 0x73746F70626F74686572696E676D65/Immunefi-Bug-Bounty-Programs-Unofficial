"""Unit tests for PlasmaVault — mock Web3Context, verify encoding and decoding."""

from unittest.mock import MagicMock

from eth_abi import encode
from eth_utils import function_signature_to_4byte_selector
from web3 import Web3
from web3.types import Timestamp

from ipor_fusion.core.plasma_vault import (
    ManagementFeeData,
    PerformanceFeeData,
    PlasmaVault,
)
from ipor_fusion.fuses.base import ZERO_ADDRESS, FuseAction
from ipor_fusion.types import Amount, Decimals, Fee, MarketId, Shares

VAULT_ADDR = Web3.to_checksum_address("0x1111111111111111111111111111111111111111")
USER_ADDR = Web3.to_checksum_address("0xaAaAaAaaAaAaAaaAaAAAAAAAAaaaAaAaAaaAaaAa")
TOKEN_ADDR = Web3.to_checksum_address("0xbBbBBBBbbBBBbbbBbbBbbbbBBbBbbbbBbBbbBBbB")
FUSE_ADDR = Web3.to_checksum_address("0xCcCCccccCCCCcCCCCCCcCcCccCcCCCcCcccccccC")
FUSE_ADDR_2 = Web3.to_checksum_address("0xdDdDddDdDdddDDddDDddDDDDdDdDDdDDdDDDDDDd")
ACCESS_MANAGER = Web3.to_checksum_address("0x3333333333333333333333333333333333333333")
REWARDS_MANAGER = Web3.to_checksum_address("0x4444444444444444444444444444444444444444")
PRICE_ORACLE = Web3.to_checksum_address("0x5555555555555555555555555555555555555555")
WITHDRAW_MANAGER = Web3.to_checksum_address(
    "0x6666666666666666666666666666666666666666"
)
FEE_ACCOUNT = Web3.to_checksum_address("0x7777777777777777777777777777777777777777")


def _make_vault() -> tuple[PlasmaVault, MagicMock]:
    ctx = MagicMock()
    vault = PlasmaVault(ctx, VAULT_ADDR)
    return vault, ctx


class TestPlasmaVaultSendMethods:
    """Methods that delegate to _send (write transactions)."""

    def test_execute(self):
        vault, ctx = _make_vault()
        ctx.send.return_value = {"status": 1}
        action = FuseAction(fuse=FUSE_ADDR, data=b"\x01\x02\x03")

        result = vault.execute([action]).send()

        assert result == {"status": 1}
        ctx.send.assert_called_once()

    def test_deposit(self):
        vault, ctx = _make_vault()
        ctx.send.return_value = {"status": 1}

        result = vault.deposit(Amount(1000), USER_ADDR).send()

        assert result == {"status": 1}
        ctx.send.assert_called_once()

    def test_mint(self):
        vault, ctx = _make_vault()
        ctx.send.return_value = {"status": 1}

        result = vault.mint(Shares(500), USER_ADDR).send()

        assert result == {"status": 1}
        ctx.send.assert_called_once()

    def test_withdraw(self):
        vault, ctx = _make_vault()
        ctx.send.return_value = {"status": 1}

        result = vault.withdraw(Amount(2000), USER_ADDR, USER_ADDR).send()

        assert result == {"status": 1}
        ctx.send.assert_called_once()

    def test_redeem(self):
        vault, ctx = _make_vault()
        ctx.send.return_value = {"status": 1}

        result = vault.redeem(Shares(300), USER_ADDR, USER_ADDR).send()

        assert result == {"status": 1}
        ctx.send.assert_called_once()

    def test_redeem_from_request(self):
        vault, ctx = _make_vault()
        ctx.send.return_value = {"status": 1}

        result = vault.redeem_from_request(Shares(100), USER_ADDR, USER_ADDR).send()

        assert result == {"status": 1}
        ctx.send.assert_called_once()

    def test_add_fuses(self):
        vault, ctx = _make_vault()
        ctx.send.return_value = {"status": 1}
        fuses = [FUSE_ADDR, FUSE_ADDR_2]

        result = vault.add_fuses(fuses).send()

        assert result == {"status": 1}
        ctx.send.assert_called_once()
        sent_to, _ = ctx.send.call_args[0]
        assert sent_to == VAULT_ADDR

    def test_update_dependency_balance_graphs(self):
        vault, ctx = _make_vault()
        ctx.send.return_value = {"status": 1}

        result = vault.update_dependency_balance_graphs(
            [MarketId(1202), MarketId(41)], [[MarketId(7)], [MarketId(7)]]
        ).send()

        assert result == {"status": 1}
        ctx.send.assert_called_once()
        sent_to, sent_data = ctx.send.call_args[0]
        assert sent_to == VAULT_ADDR
        selector = Web3.keccak(
            text="updateDependencyBalanceGraphs(uint256[],uint256[][])"
        )[:4]
        assert sent_data == selector + encode(
            ["uint256[]", "uint256[][]"], [[1202, 41], [[7], [7]]]
        )

    def test_update_dependency_balance_graphs_empty(self):
        vault, ctx = _make_vault()
        ctx.send.return_value = {"status": 1}

        result = vault.update_dependency_balance_graphs([], []).send()

        assert result == {"status": 1}
        ctx.send.assert_called_once()
        sent_to, sent_data = ctx.send.call_args[0]
        assert sent_to == VAULT_ADDR
        selector = Web3.keccak(
            text="updateDependencyBalanceGraphs(uint256[],uint256[][])"
        )[:4]
        assert sent_data == selector + encode(["uint256[]", "uint256[][]"], [[], []])

    def test_update_callback_handler(self):
        vault, ctx = _make_vault()
        ctx.send.return_value = {"status": 1}
        selector = bytes.fromhex("150b7a02")

        result = vault.update_callback_handler(FUSE_ADDR, TOKEN_ADDR, selector).send()

        assert result == {"status": 1}
        sent_to, sent_data = ctx.send.call_args[0]
        assert sent_to == VAULT_ADDR
        expected_selector = Web3.keccak(
            text="updateCallbackHandler(address,address,bytes4)"
        )[:4]
        assert sent_data == expected_selector + encode(
            ["address", "address", "bytes4"], [FUSE_ADDR, TOKEN_ADDR, selector]
        )

    def test_update_callback_handler_rejects_invalid_selector(self):
        vault, _ = _make_vault()

        for selector in (b"", b"\x01\x02\x03", b"\x01\x02\x03\x04\x05"):
            try:
                vault.update_callback_handler(FUSE_ADDR, TOKEN_ADDR, selector)
            except ValueError as error:
                assert "selector must be exactly 4 bytes" in str(error)
            else:
                raise AssertionError(f"accepted invalid selector {selector!r}")

        try:
            vault.update_callback_handler(  # type: ignore[arg-type]
                FUSE_ADDR, TOKEN_ADDR, "0x150b7a02"
            )
        except TypeError as error:
            assert str(error) == "selector must be bytes-like"
        else:
            raise AssertionError("accepted a string selector")

    def test_set_total_supply_cap(self):
        vault, ctx = _make_vault()
        ctx.send.return_value = {"status": 1}

        result = vault.set_total_supply_cap(Amount(500_000)).send()

        assert result == {"status": 1}
        ctx.send.assert_called_once()

    def test_convert_to_public_vault(self):
        """No-args setter: calldata is exactly the 4-byte selector."""
        vault, ctx = _make_vault()
        ctx.send.return_value = {"status": 1}

        call = vault.convert_to_public_vault()
        # Selector-only, no args → 4 bytes total.
        assert len(call.calldata) == 4
        assert (
            call.calldata.hex() == Web3.keccak(text="convertToPublicVault()")[:4].hex()
        )

        result = call.send()
        assert result == {"status": 1}
        ctx.send.assert_called_once()
        sent_to, sent_data = ctx.send.call_args[0]
        assert sent_to == VAULT_ADDR
        assert sent_data == call.calldata

    def test_transfer(self):
        vault, ctx = _make_vault()
        ctx.send.return_value = {"status": 1}

        result = vault.transfer(USER_ADDR, Amount(750)).send()

        assert result == {"status": 1}
        ctx.send.assert_called_once()

    def test_approve(self):
        vault, ctx = _make_vault()
        ctx.send.return_value = {"status": 1}

        result = vault.approve(USER_ADDR, Amount(999)).send()

        assert result == {"status": 1}
        ctx.send.assert_called_once()

    def test_transfer_from(self):
        vault, ctx = _make_vault()
        ctx.send.return_value = {"status": 1}

        result = vault.transfer_from(FUSE_ADDR, USER_ADDR, Amount(400)).send()

        assert result == {"status": 1}
        ctx.send.assert_called_once()


class TestPlasmaVaultCallMethods:
    """Methods that delegate to _call (read-only)."""

    def test_underlying_asset_address(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["address"], [TOKEN_ADDR])

        result = vault.underlying_asset_address().call()

        assert result == TOKEN_ADDR

    def test_get_access_manager_address(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["address"], [ACCESS_MANAGER])

        result = vault.get_access_manager_address().call()

        assert result == ACCESS_MANAGER

    def test_get_rewards_claim_manager_address(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["address"], [REWARDS_MANAGER])

        result = vault.get_rewards_claim_manager_address().call()

        assert result == REWARDS_MANAGER

    def test_get_price_oracle_middleware_address(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["address"], [PRICE_ORACLE])

        result = vault.get_price_oracle_middleware_address().call()

        assert result == PRICE_ORACLE

    def test_get_fuses(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["address[]"], [[FUSE_ADDR, FUSE_ADDR_2]])

        result = vault.get_fuses().call()

        assert result == [FUSE_ADDR, FUSE_ADDR_2]

    def test_get_fuses_empty(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["address[]"], [[]])

        result = vault.get_fuses().call()

        assert result == []

    def test_get_instant_withdrawal_fuses(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["address[]"], [[FUSE_ADDR]])

        result = vault.get_instant_withdrawal_fuses().call()

        assert result == [FUSE_ADDR]

    def test_get_instant_withdrawal_fuses_params(self):
        vault, ctx = _make_vault()
        param1 = b"\x01" * 32
        param2 = b"\x02" * 32
        ctx.call.return_value = encode(["bytes32[]"], [[param1, param2]])

        result = vault.get_instant_withdrawal_fuses_params(FUSE_ADDR, 0).call()

        assert len(result) == 2
        assert result[0] == param1
        assert result[1] == param2

    def test_get_market_substrates(self):
        vault, ctx = _make_vault()
        sub1 = b"\xaa" * 32
        sub2 = b"\xbb" * 32
        ctx.call.return_value = encode(["bytes32[]"], [[sub1, sub2]])

        result = vault.get_market_substrates(MarketId(42)).call()

        assert len(result) == 2
        assert result[0] == sub1
        assert result[1] == sub2

    def test_decimals(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["uint256"], [18])

        result = vault.decimals().call()

        assert result == Decimals(18)

    def test_total_assets(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["uint256"], [1_000_000])

        result = vault.total_assets().call()

        assert result == Amount(1_000_000)

    def test_total_assets_in_market(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["uint256"], [500_000])

        result = vault.total_assets_in_market(MarketId(7)).call()

        assert result == Amount(500_000)

    def test_balance_of(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["uint256"], [42_000])

        result = vault.balance_of(USER_ADDR).call()

        assert result == Amount(42_000)

    def test_get_total_supply_cap(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["uint256"], [10_000_000])

        result = vault.get_total_supply_cap().call()

        assert result == Amount(10_000_000)

    def test_max_withdraw(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["uint256"], [5_000])

        result = vault.max_withdraw(USER_ADDR).call()

        assert result == Amount(5_000)

    def test_convert_to_shares(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["uint256"], [999])

        result = vault.convert_to_shares(Amount(1000)).call()

        assert result == Shares(999)

    def test_convert_to_assets(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["uint256"], [1001])

        result = vault.convert_to_assets(Shares(1000)).call()

        assert result == Amount(1001)


def _balance_fuse_logs(added: list[dict], removed: list[dict]) -> list[dict]:
    """Tag each log with its event's topic0, as the single OR-filtered
    eth_getLogs behind `get_balance_fuses` returns them."""
    added_topic = Web3.keccak(text="BalanceFuseAdded(uint256,address)")
    removed_topic = Web3.keccak(text="BalanceFuseRemoved(uint256,address)")
    return [{**log, "topics": [added_topic]} for log in added] + [
        {**log, "topics": [removed_topic]} for log in removed
    ]


class TestPlasmaVaultEventDecoding:
    """Methods that decode log events."""

    def test_get_balance_fuses(self):
        vault, ctx = _make_vault()
        added = [
            {
                "data": encode(["uint256", "address"], [1, FUSE_ADDR]),
                "blockNumber": 10,
                "logIndex": 0,
            },
            {
                "data": encode(["uint256", "address"], [2, FUSE_ADDR_2]),
                "blockNumber": 11,
                "logIndex": 0,
            },
        ]
        ctx.get_logs.return_value = _balance_fuse_logs(added, [])

        result = vault.get_balance_fuses()

        assert len(result) == 2
        by_market = {bf.market_id: bf.fuse for bf in result}
        assert by_market == {1: FUSE_ADDR, 2: FUSE_ADDR_2}

    def test_get_balance_fuses_nets_removed_entries(self):
        vault, ctx = _make_vault()
        added = [
            {
                "data": encode(["uint256", "address"], [1, FUSE_ADDR]),
                "blockNumber": 10,
                "logIndex": 0,
            },
            {
                "data": encode(["uint256", "address"], [2, FUSE_ADDR_2]),
                "blockNumber": 11,
                "logIndex": 0,
            },
        ]
        removed = [
            {
                "data": encode(["uint256", "address"], [1, FUSE_ADDR]),
                "blockNumber": 12,
                "logIndex": 0,
            }
        ]
        ctx.get_logs.return_value = _balance_fuse_logs(added, removed)

        result = vault.get_balance_fuses()

        assert len(result) == 1
        assert result[0].market_id == 2
        assert result[0].fuse == FUSE_ADDR_2

    def test_get_balance_fuses_deduplicates_per_market(self):
        vault, ctx = _make_vault()
        added = [
            {
                "data": encode(["uint256", "address"], [1, FUSE_ADDR]),
                "blockNumber": 10,
                "logIndex": 0,
            },
            {
                "data": encode(["uint256", "address"], [1, FUSE_ADDR_2]),
                "blockNumber": 20,
                "logIndex": 0,
            },
        ]
        ctx.get_logs.return_value = _balance_fuse_logs(added, [])

        result = vault.get_balance_fuses()

        assert len(result) == 1
        assert result[0].market_id == 1
        assert result[0].fuse == FUSE_ADDR_2

    def test_get_balance_fuses_picks_latest_on_unsorted_added(self):
        """Provider may return logs out of order; chronological replay must win."""
        vault, ctx = _make_vault()
        added = [
            {
                "data": encode(["uint256", "address"], [1, FUSE_ADDR_2]),
                "blockNumber": 20,
                "logIndex": 0,
            },
            {
                "data": encode(["uint256", "address"], [1, FUSE_ADDR]),
                "blockNumber": 10,
                "logIndex": 0,
            },
        ]
        ctx.get_logs.return_value = _balance_fuse_logs(added, [])

        result = vault.get_balance_fuses()

        assert len(result) == 1
        assert result[0].market_id == 1
        assert result[0].fuse == FUSE_ADDR_2

    def test_get_balance_fuses_readded_after_removal(self):
        """Add -> Remove -> Add of the same fuse must result in active fuse."""
        vault, ctx = _make_vault()
        added = [
            {
                "data": encode(["uint256", "address"], [1, FUSE_ADDR]),
                "blockNumber": 10,
                "logIndex": 0,
            },
            {
                "data": encode(["uint256", "address"], [1, FUSE_ADDR]),
                "blockNumber": 30,
                "logIndex": 0,
            },
        ]
        removed = [
            {
                "data": encode(["uint256", "address"], [1, FUSE_ADDR]),
                "blockNumber": 20,
                "logIndex": 0,
            }
        ]
        ctx.get_logs.return_value = _balance_fuse_logs(added, removed)

        result = vault.get_balance_fuses()

        assert len(result) == 1
        assert result[0].market_id == 1
        assert result[0].fuse == FUSE_ADDR

    def test_get_balance_fuses_same_block_logindex_tiebreak(self):
        """Events in the same block are ordered by logIndex."""
        vault, ctx = _make_vault()
        added = [
            {
                "data": encode(["uint256", "address"], [1, FUSE_ADDR_2]),
                "blockNumber": 10,
                "logIndex": 2,
            },
            {
                "data": encode(["uint256", "address"], [1, FUSE_ADDR]),
                "blockNumber": 10,
                "logIndex": 1,
            },
        ]
        ctx.get_logs.return_value = _balance_fuse_logs(added, [])

        result = vault.get_balance_fuses()

        assert len(result) == 1
        assert result[0].fuse == FUSE_ADDR_2

    def test_get_balance_fuses_reads_both_events_in_one_query(self):
        vault, ctx = _make_vault()
        ctx.get_logs.return_value = []

        vault.get_balance_fuses()

        ctx.get_logs.assert_called_once()
        (topic0_alternatives,) = ctx.get_logs.call_args.kwargs["topics"]
        assert topic0_alternatives == [
            Web3.keccak(text="BalanceFuseAdded(uint256,address)").to_0x_hex(),
            Web3.keccak(text="BalanceFuseRemoved(uint256,address)").to_0x_hex(),
        ]

    def test_get_balance_fuses_empty(self):
        vault, ctx = _make_vault()
        ctx.get_logs.return_value = _balance_fuse_logs([], [])

        result = vault.get_balance_fuses()

        assert not result

    def test_withdraw_manager_address_returns_latest(self):
        vault, ctx = _make_vault()
        old_addr = Web3.to_checksum_address(
            "0x7777777777777777777777777777777777777777"
        )
        event1_data = encode(["address"], [old_addr])
        event2_data = encode(["address"], [WITHDRAW_MANAGER])
        ctx.get_logs.return_value = [
            {"data": event1_data, "blockNumber": 100},
            {"data": event2_data, "blockNumber": 200},
        ]

        result = vault.withdraw_manager_address()

        assert result == WITHDRAW_MANAGER

    def test_withdraw_manager_address_no_events(self):
        vault, ctx = _make_vault()
        ctx.get_logs.return_value = []

        result = vault.withdraw_manager_address()

        assert result is None

    def test_withdraw_manager_address_single_event(self):
        vault, ctx = _make_vault()
        event_data = encode(["address"], [WITHDRAW_MANAGER])
        ctx.get_logs.return_value = [
            {"data": event_data, "blockNumber": 50},
        ]

        result = vault.withdraw_manager_address()

        assert result == WITHDRAW_MANAGER

    def test_withdraw_manager_address_zero_address_means_unset(self):
        # Legacy vaults emit WithdrawManagerChanged(address(0)) at init;
        # the zero address must not be reported as a queryable manager.
        vault, ctx = _make_vault()
        event_data = encode(["address"], [ZERO_ADDRESS])
        ctx.get_logs.return_value = [
            {"data": event_data, "blockNumber": 50},
        ]

        result = vault.withdraw_manager_address()

        assert result is None


class TestPlasmaVaultFeeData:
    """Governance fee-data getters (structs decoded to dataclasses)."""

    def test_get_performance_fee_data(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["(address,uint16)"], [(FEE_ACCOUNT, 1000)])

        result = vault.get_performance_fee_data().call()

        assert result == PerformanceFeeData(
            fee_account=FEE_ACCOUNT, fee_in_percentage=Fee(1000)
        )

    def test_get_management_fee_data(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(
            ["(address,uint16,uint32)"], [(FEE_ACCOUNT, 100, 1_750_000_000)]
        )

        result = vault.get_management_fee_data().call()

        assert result == ManagementFeeData(
            fee_account=FEE_ACCOUNT,
            fee_in_percentage=Fee(100),
            last_update_timestamp=Timestamp(1_750_000_000),
        )

    def test_get_unrealized_management_fee(self):
        vault, ctx = _make_vault()
        ctx.call.return_value = encode(["uint256"], [123_456])

        result = vault.get_unrealized_management_fee().call()

        assert result == Amount(123_456)

    def test_selectors(self):
        encoder = PlasmaVault.encoder()
        for call, signature in [
            (encoder.get_performance_fee_data(), "getPerformanceFeeData()"),
            (encoder.get_management_fee_data(), "getManagementFeeData()"),
            (
                encoder.get_unrealized_management_fee(),
                "getUnrealizedManagementFee()",
            ),
        ]:
            assert call.calldata == function_signature_to_4byte_selector(signature), (
                signature
            )
