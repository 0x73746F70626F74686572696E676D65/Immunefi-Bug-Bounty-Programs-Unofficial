"""Unit tests for fuse encoding — pure functions, no Docker or blockchain needed."""

import pytest
from eth_abi import decode
from eth_abi.packed import encode_packed
from eth_utils import function_signature_to_4byte_selector
from web3 import Web3

from ipor_fusion.core.contract import _parse_param_types
from ipor_fusion.fuses.aave_v3 import AaveV3BorrowFuse, AaveV3SupplyFuse
from ipor_fusion.fuses.async_action import AsyncActionFuse, AsyncActionSubstrates
from ipor_fusion.fuses.base import ZERO_ADDRESS, FuseAction
from ipor_fusion.fuses.compound_v3 import CompoundV3SupplyFuse
from ipor_fusion.fuses.erc4626 import ERC4626SupplyFuse
from ipor_fusion.fuses.euler_v2 import (
    EulerSwapDynamicParams,
    EulerSwapInitialState,
    EulerSwapStaticParams,
    EulerV2BatchFuse,
    EulerV2BatchItem,
    EulerV2BorrowFuse,
    EulerV2CollateralFuse,
    EulerV2ControllerFuse,
    EulerV2SupplyFuse,
    EulerV2SwapDeployFuse,
    EulerV2SwapReconfigureFuse,
    EulerV2SwapRegistryFuse,
    euler_substrate,
)
from ipor_fusion.fuses.external_state import (
    ExternalStateOperationFuse,
    ExternalStateSubstrates,
)
from ipor_fusion.fuses.fluid_instadapp import (
    FluidInstadappStakingFuse,
    FluidInstadappSupplyFuse,
)
from ipor_fusion.fuses.gearbox_v3 import GearboxStakeFuse, GearboxSupplyFuse
from ipor_fusion.fuses.merkl import MerklClaimWrapperFuse
from ipor_fusion.fuses.morpho import (
    MorphoBorrowFuse,
    MorphoClaimFuse,
    MorphoCollateralFuse,
    MorphoFlashLoanFuse,
    MorphoSupplyFuse,
)
from ipor_fusion.fuses.ramses_v2 import (
    RamsesClaimFuse,
    RamsesV2CollectFuse,
    RamsesV2ModifyPositionFuse,
    RamsesV2NewPositionFuse,
)
from ipor_fusion.fuses.uniswap_v3 import (
    UniswapV3CollectFuse,
    UniswapV3ModifyPositionFuse,
    UniswapV3NewPositionFuse,
    UniswapV3SwapFuse,
)
from ipor_fusion.fuses.universal import (
    UniversalTokenSwapperAbi,
    UniversalTokenSwapperFuse,
    UniversalTokenSwapperSubstrates,
)
from ipor_fusion.substrates import decode_substrate
from ipor_fusion.types import MAX_UINT256

# Deterministic test addresses
FUSE_ADDR = Web3.to_checksum_address("0x1111111111111111111111111111111111111111")
FUSE_ADDR_2 = Web3.to_checksum_address("0x2222222222222222222222222222222222222222")
TOKEN_A = Web3.to_checksum_address("0xaAaAaAaaAaAaAaaAaAAAAAAAAaaaAaAaAaaAaaAa")
TOKEN_B = Web3.to_checksum_address("0xbBbBBBBbbBBBbbbBbbBbbbbBBbBbbbbBbBbbBBbB")
VAULT_ADDR = Web3.to_checksum_address("0xCcCCccccCCCCcCCCCCCcCcCccCcCCCcCcccccccC")

# Lowercase versions for comparing against eth_abi.decode output
TOKEN_A_LOW = str(TOKEN_A).lower()
TOKEN_B_LOW = str(TOKEN_B).lower()
VAULT_ADDR_LOW = str(VAULT_ADDR).lower()
FUSE_ADDR_LOW = str(FUSE_ADDR).lower()
FUSE_ADDR_2_LOW = str(FUSE_ADDR_2).lower()

MARKET_ID = "a" * 64  # 32-byte hex string without 0x prefix


def _selector(sig: str) -> bytes:
    return function_signature_to_4byte_selector(sig)


# ── FuseAction ──────────────────────────────────────────────────────────


class TestFuseAction:
    def test_encode_roundtrip(self):
        action = FuseAction(fuse=FUSE_ADDR, data=b"\x01\x02\x03")
        encoded = action.encode()
        (addr, data) = decode(["address", "bytes"], encoded)
        assert addr.lower() == FUSE_ADDR_LOW
        assert data == b"\x01\x02\x03"

    def test_frozen(self):
        action = FuseAction(fuse=FUSE_ADDR, data=b"\x00")
        with pytest.raises(AttributeError):
            action.fuse = TOKEN_A  # type: ignore[misc]

    def test_str_repr(self):
        action = FuseAction(fuse=FUSE_ADDR, data=b"\xab" * 20)
        s = str(action)
        assert FUSE_ADDR in s
        assert "0x" in s


# ── Fuse base class ────────────────────────────────────────────────────


class TestFuseBase:
    def test_address_required(self):
        with pytest.raises(ValueError, match="required"):
            AaveV3SupplyFuse("")  # type: ignore[arg-type]

    def test_address_property(self):
        fuse = AaveV3SupplyFuse(FUSE_ADDR)
        assert fuse.address == FUSE_ADDR


# ── AaveV3 ──────────────────────────────────────────────────────────────


class TestAaveV3SupplyFuse:
    def test_supply_selector_and_payload(self):
        fuse = AaveV3SupplyFuse(FUSE_ADDR)
        action = fuse.supply(asset=TOKEN_A, amount=1000, e_mode=1)

        assert action.fuse == FUSE_ADDR
        assert action.data[:4] == _selector("enter((address,uint256,uint256))")
        (addr, amount, e_mode) = decode(
            ["address", "uint256", "uint256"], action.data[4:]
        )
        assert addr.lower() == TOKEN_A_LOW
        assert amount == 1000
        assert e_mode == 1

    def test_supply_default_emode(self):
        action = AaveV3SupplyFuse(FUSE_ADDR).supply(asset=TOKEN_A, amount=500)
        (_, _, e_mode) = decode(["address", "uint256", "uint256"], action.data[4:])
        assert e_mode == 0

    def test_withdraw(self):
        action = AaveV3SupplyFuse(FUSE_ADDR).withdraw(asset=TOKEN_A, amount=999)
        assert action.data[:4] == _selector("exit((address,uint256))")
        (addr, amount) = decode(["address", "uint256"], action.data[4:])
        assert addr.lower() == TOKEN_A_LOW
        assert amount == 999


class TestAaveV3BorrowFuse:
    def test_borrow(self):
        action = AaveV3BorrowFuse(FUSE_ADDR).borrow(asset=TOKEN_A, amount=5000)
        assert action.data[:4] == _selector("enter((address,uint256))")
        (addr, amount) = decode(["address", "uint256"], action.data[4:])
        assert addr.lower() == TOKEN_A_LOW
        assert amount == 5000

    def test_repay(self):
        action = AaveV3BorrowFuse(FUSE_ADDR).repay(asset=TOKEN_B, amount=3000)
        assert action.data[:4] == _selector("exit((address,uint256))")
        (addr, amount) = decode(["address", "uint256"], action.data[4:])
        assert addr.lower() == TOKEN_B_LOW
        assert amount == 3000


# ── Morpho ──────────────────────────────────────────────────────────────


class TestMorphoSupplyFuse:
    def test_supply(self):
        action = MorphoSupplyFuse(FUSE_ADDR).supply(market_id=MARKET_ID, amount=10_000)
        assert action.data[:4] == _selector("enter((bytes32,uint256))")
        (mid, amount) = decode(["bytes32", "uint256"], action.data[4:])
        assert mid == bytes.fromhex(MARKET_ID)
        assert amount == 10_000

    def test_withdraw(self):
        action = MorphoSupplyFuse(FUSE_ADDR).withdraw(market_id=MARKET_ID, amount=7_000)
        assert action.data[:4] == _selector("exit((bytes32,uint256))")
        (mid, amount) = decode(["bytes32", "uint256"], action.data[4:])
        assert mid == bytes.fromhex(MARKET_ID)
        assert amount == 7_000


class TestMorphoCollateralFuse:
    def test_supply_collateral(self):
        action = MorphoCollateralFuse(FUSE_ADDR).supply_collateral(
            market_id=MARKET_ID, amount=500
        )
        assert action.data[:4] == _selector("enter((bytes32,uint256))")
        (mid, amount) = decode(["bytes32", "uint256"], action.data[4:])
        assert mid == bytes.fromhex(MARKET_ID)
        assert amount == 500

    def test_withdraw_collateral(self):
        action = MorphoCollateralFuse(FUSE_ADDR).withdraw_collateral(
            market_id=MARKET_ID, amount=300
        )
        assert action.data[:4] == _selector("exit((bytes32,uint256))")


class TestMorphoBorrowFuse:
    def test_borrow_appends_zero(self):
        action = MorphoBorrowFuse(FUSE_ADDR).borrow(market_id=MARKET_ID, amount=2000)
        assert action.data[:4] == _selector("enter((bytes32,uint256,uint256))")
        (mid, amount, zero) = decode(["bytes32", "uint256", "uint256"], action.data[4:])
        assert mid == bytes.fromhex(MARKET_ID)
        assert amount == 2000
        assert zero == 0

    def test_repay_appends_zero(self):
        action = MorphoBorrowFuse(FUSE_ADDR).repay(market_id=MARKET_ID, amount=1500)
        assert action.data[:4] == _selector("exit((bytes32,uint256,uint256))")
        (_, _, zero) = decode(["bytes32", "uint256", "uint256"], action.data[4:])
        assert zero == 0


class TestMorphoFlashLoanFuse:
    def test_flash_loan_encodes_nested_actions(self):
        inner1 = FuseAction(fuse=FUSE_ADDR, data=b"\x01\x02")
        inner2 = FuseAction(fuse=FUSE_ADDR_2, data=b"\x03\x04")
        action = MorphoFlashLoanFuse(FUSE_ADDR).flash_loan(
            asset=TOKEN_A, amount=50_000, actions=[inner1, inner2]
        )

        assert action.fuse == FUSE_ADDR
        assert action.data[:4] == _selector("enter((address,uint256,bytes))")

        (decoded_tuple,) = decode(["(address,uint256,bytes)"], action.data[4:])
        asset, amount, inner_bytes = decoded_tuple
        assert asset.lower() == TOKEN_A_LOW
        assert amount == 50_000

        # inner_bytes should be ABI-encoded (address,bytes)[]
        (decoded_actions,) = decode(["(address,bytes)[]"], inner_bytes)
        assert len(decoded_actions) == 2
        assert decoded_actions[0][0].lower() == FUSE_ADDR_LOW
        assert decoded_actions[0][1] == b"\x01\x02"
        assert decoded_actions[1][0].lower() == FUSE_ADDR_2_LOW
        assert decoded_actions[1][1] == b"\x03\x04"

    def test_flash_loan_empty_actions(self):
        action = MorphoFlashLoanFuse(FUSE_ADDR).flash_loan(
            asset=TOKEN_A, amount=100, actions=[]
        )
        (decoded_tuple,) = decode(["(address,uint256,bytes)"], action.data[4:])
        (decoded_actions,) = decode(["(address,bytes)[]"], decoded_tuple[2])
        assert len(decoded_actions) == 0


class TestMorphoClaimFuse:
    def test_claim_with_proofs(self):
        proof = [
            "0x" + "ab" * 32,
            "0x" + "cd" * 32,
        ]
        action = MorphoClaimFuse(FUSE_ADDR).claim(
            universal_rewards_distributor=TOKEN_A,
            rewards_token=TOKEN_B,
            claimable=9999,
            proof=proof,
        )
        assert action.data[:4] == _selector("claim(address,address,uint256,bytes32[])")
        (dist, token, claimable, proofs) = decode(
            ["address", "address", "uint256", "bytes32[]"], action.data[4:]
        )
        assert dist.lower() == TOKEN_A_LOW
        assert token.lower() == TOKEN_B_LOW
        assert claimable == 9999
        assert len(proofs) == 2
        assert proofs[0] == bytes.fromhex("ab" * 32)
        assert proofs[1] == bytes.fromhex("cd" * 32)

    def test_claim_proof_without_0x_prefix(self):
        proof = ["ab" * 32]
        action = MorphoClaimFuse(FUSE_ADDR).claim(
            universal_rewards_distributor=TOKEN_A,
            rewards_token=TOKEN_B,
            claimable=1,
            proof=proof,
        )
        (_, _, _, proofs) = decode(
            ["address", "address", "uint256", "bytes32[]"], action.data[4:]
        )
        assert proofs[0] == bytes.fromhex("ab" * 32)


# ── Merkl ───────────────────────────────────────────────────────────────


class TestMerklClaimWrapperFuse:
    def test_claim_encodes_all_arrays(self):
        proof = ["0x" + "ab" * 32, "cd" * 32]  # with and without 0x prefix
        action = MerklClaimWrapperFuse(FUSE_ADDR).claim(
            tokens=[TOKEN_A],
            amounts=[123],
            proofs=[proof],
            received_tokens=[TOKEN_B, VAULT_ADDR],
        )
        assert action.fuse == FUSE_ADDR
        assert action.data[:4] == _selector(
            "claim(address[],uint256[],bytes32[][],address[])"
        )
        (tokens, amounts, proofs, received) = decode(
            ["address[]", "uint256[]", "bytes32[][]", "address[]"], action.data[4:]
        )
        assert [t.lower() for t in tokens] == [TOKEN_A_LOW]
        assert list(amounts) == [123]
        assert len(proofs) == 1
        assert proofs[0][0] == bytes.fromhex("ab" * 32)
        assert proofs[0][1] == bytes.fromhex("cd" * 32)
        assert [r.lower() for r in received] == [TOKEN_B_LOW, VAULT_ADDR_LOW]

    def test_claim_rejects_mismatched_lengths(self):
        with pytest.raises(ValueError, match="equal lengths"):
            MerklClaimWrapperFuse(FUSE_ADDR).claim(
                tokens=[TOKEN_A],
                amounts=[],
                proofs=[[]],
                received_tokens=[TOKEN_B],
            )

    def test_claim_rejects_empty_tokens(self):
        with pytest.raises(ValueError, match="tokens must not be empty"):
            MerklClaimWrapperFuse(FUSE_ADDR).claim(
                tokens=[],
                amounts=[],
                proofs=[],
                received_tokens=[TOKEN_B],
            )

    def test_claim_rejects_empty_received_tokens(self):
        with pytest.raises(ValueError, match="received_tokens must not be empty"):
            MerklClaimWrapperFuse(FUSE_ADDR).claim(
                tokens=[TOKEN_A],
                amounts=[1],
                proofs=[[]],
                received_tokens=[],
            )

    def test_claim_rejects_zero_address_received_token(self):
        with pytest.raises(ValueError, match=r"received_tokens\[0\]"):
            MerklClaimWrapperFuse(FUSE_ADDR).claim(
                tokens=[TOKEN_A],
                amounts=[1],
                proofs=[[]],
                received_tokens=[ZERO_ADDRESS],
            )

    def test_claim_rejects_zero_address_token(self):
        with pytest.raises(ValueError, match=r"tokens\[0\]"):
            MerklClaimWrapperFuse(FUSE_ADDR).claim(
                tokens=[ZERO_ADDRESS],
                amounts=[1],
                proofs=[[]],
                received_tokens=[TOKEN_B],
            )

    def test_claim_rejects_non_positive_amount(self):
        with pytest.raises(ValueError, match=r"amounts\[0\]"):
            MerklClaimWrapperFuse(FUSE_ADDR).claim(
                tokens=[TOKEN_A],
                amounts=[0],
                proofs=[[]],
                received_tokens=[TOKEN_B],
            )


# ── CompoundV3 ──────────────────────────────────────────────────────────


class TestCompoundV3SupplyFuse:
    def test_supply(self):
        action = CompoundV3SupplyFuse(FUSE_ADDR).supply(asset=TOKEN_A, amount=4000)
        assert action.data[:4] == _selector("enter((address,uint256))")
        (addr, amount) = decode(["address", "uint256"], action.data[4:])
        assert addr.lower() == TOKEN_A_LOW
        assert amount == 4000

    def test_withdraw(self):
        action = CompoundV3SupplyFuse(FUSE_ADDR).withdraw(asset=TOKEN_B, amount=2000)
        assert action.data[:4] == _selector("exit((address,uint256))")


# ── ERC4626 ─────────────────────────────────────────────────────────────


class TestERC4626SupplyFuse:
    def test_supply(self):
        action = ERC4626SupplyFuse(FUSE_ADDR).supply(
            vault_address=VAULT_ADDR, amount=8000
        )
        assert action.data[:4] == _selector("enter((address,uint256))")
        (addr, amount) = decode(["address", "uint256"], action.data[4:])
        assert addr.lower() == VAULT_ADDR_LOW
        assert amount == 8000

    def test_withdraw(self):
        action = ERC4626SupplyFuse(FUSE_ADDR).withdraw(
            vault_address=VAULT_ADDR, amount=6000
        )
        assert action.data[:4] == _selector("exit((address,uint256))")


# ── Uniswap V3 ─────────────────────────────────────────────────────────


class TestUniswapV3SwapFuse:
    def test_swap_encodes_packed_path(self):
        action = UniswapV3SwapFuse(FUSE_ADDR).swap(
            token_in=TOKEN_A,
            token_out=TOKEN_B,
            fee=3000,
            amount_in=10_000,
            min_amount_out=9_000,
        )
        assert action.data[:4] == _selector("enter((uint256,uint256,bytes))")
        (decoded_tuple,) = decode(["(uint256,uint256,bytes)"], action.data[4:])
        amount_in, min_out, path = decoded_tuple
        assert amount_in == 10_000
        assert min_out == 9_000

        expected_path = encode_packed(
            ["address", "uint24", "address"], [TOKEN_A, 3000, TOKEN_B]
        )
        assert path == expected_path


class TestUniswapV3NewPositionFuse:
    def test_new_position(self):
        fuse = UniswapV3NewPositionFuse(FUSE_ADDR)
        action = fuse.new_position(
            token0=TOKEN_A,
            token1=TOKEN_B,
            fee=500,
            tick_lower=-100,
            tick_upper=100,
            amount0_desired=1000,
            amount1_desired=2000,
            amount0_min=900,
            amount1_min=1800,
            deadline=99999,
        )
        assert action.data[:4] == _selector(
            "enter((address,address,uint24,int24,int24,uint256,uint256,uint256,uint256,uint256))"
        )
        (decoded_tuple,) = decode(
            [
                "(address,address,uint24,int24,int24,uint256,uint256,uint256,uint256,uint256)"
            ],
            action.data[4:],
        )
        assert decoded_tuple[0].lower() == TOKEN_A_LOW
        assert decoded_tuple[1].lower() == TOKEN_B_LOW
        assert decoded_tuple[2] == 500
        assert decoded_tuple[3] == -100
        assert decoded_tuple[4] == 100
        assert decoded_tuple[5] == 1000

    def test_close_position(self):
        action = UniswapV3NewPositionFuse(FUSE_ADDR).close_position([42, 99])
        assert action.data[:4] == _selector("exit((uint256[]))")
        (decoded_tuple,) = decode(["(uint256[])"], action.data[4:])
        assert list(decoded_tuple[0]) == [42, 99]


class TestUniswapV3ModifyPositionFuse:
    def test_increase_liquidity(self):
        action = UniswapV3ModifyPositionFuse(FUSE_ADDR).increase_liquidity(
            token0=TOKEN_A,
            token1=TOKEN_B,
            token_id=7,
            amount0_desired=1000,
            amount1_desired=2000,
            amount0_min=900,
            amount1_min=1800,
            deadline=99999,
        )
        assert action.data[:4] == _selector(
            "enter((address,address,uint256,uint256,uint256,uint256,uint256,uint256))"
        )

    def test_decrease_liquidity(self):
        action = UniswapV3ModifyPositionFuse(FUSE_ADDR).decrease_liquidity(
            token_id=5, liquidity=500, amount0_min=100, amount1_min=200, deadline=88888
        )
        assert action.data[:4] == _selector(
            "exit((uint256,uint128,uint256,uint256,uint256))"
        )
        (decoded_tuple,) = decode(
            ["(uint256,uint128,uint256,uint256,uint256)"], action.data[4:]
        )
        assert decoded_tuple[0] == 5
        assert decoded_tuple[1] == 500
        assert decoded_tuple[2] == 100


class TestUniswapV3CollectFuse:
    def test_collect(self):
        action = UniswapV3CollectFuse(FUSE_ADDR).collect([1, 2, 3])
        assert action.data[:4] == _selector("enter((uint256[]))")
        (decoded_tuple,) = decode(["(uint256[])"], action.data[4:])
        assert list(decoded_tuple[0]) == [1, 2, 3]


# ── Ramses V2 ──────────────────────────────────────────────────────────


class TestRamsesV2NewPositionFuse:
    def test_new_position_has_ve_ram_token_id(self):
        action = RamsesV2NewPositionFuse(FUSE_ADDR).new_position(
            token0=TOKEN_A,
            token1=TOKEN_B,
            fee=500,
            tick_lower=-100,
            tick_upper=100,
            amount0_desired=1000,
            amount1_desired=2000,
            amount0_min=900,
            amount1_min=1800,
            deadline=99999,
            ve_ram_token_id=42,
        )
        assert action.data[:4] == _selector(
            "enter((address,address,uint24,int24,int24,uint256,uint256,uint256,uint256,uint256,uint256))"
        )
        (decoded_tuple,) = decode(
            [
                "(address,address,uint24,int24,int24,uint256,uint256,uint256,uint256,uint256,uint256)"
            ],
            action.data[4:],
        )
        assert decoded_tuple[10] == 42  # ve_ram_token_id

    def test_close_position(self):
        action = RamsesV2NewPositionFuse(FUSE_ADDR).close_position([10])
        assert action.data[:4] == _selector("exit((uint256[]))")


class TestRamsesV2ModifyPositionFuse:
    def test_increase_liquidity(self):
        action = RamsesV2ModifyPositionFuse(FUSE_ADDR).increase_liquidity(
            token0=TOKEN_A,
            token1=TOKEN_B,
            token_id=7,
            amount0_desired=1000,
            amount1_desired=2000,
            amount0_min=900,
            amount1_min=1800,
            deadline=99999,
        )
        assert action.data[:4] == _selector(
            "enter((address,address,uint256,uint256,uint256,uint256,uint256,uint256))"
        )

    def test_decrease_liquidity(self):
        action = RamsesV2ModifyPositionFuse(FUSE_ADDR).decrease_liquidity(
            token_id=3, liquidity=400, amount0_min=50, amount1_min=60, deadline=77777
        )
        assert action.data[:4] == _selector(
            "exit((uint256,uint128,uint256,uint256,uint256))"
        )


class TestRamsesV2CollectFuse:
    def test_collect(self):
        action = RamsesV2CollectFuse(FUSE_ADDR).collect([5, 6])
        assert action.data[:4] == _selector("enter((uint256[]))")


class TestRamsesClaimFuse:
    def test_claim(self):
        rewards = [[str(TOKEN_A), str(TOKEN_B)], [str(TOKEN_A)]]
        action = RamsesClaimFuse(FUSE_ADDR).claim(
            token_ids=[1, 2], token_rewards=rewards
        )
        assert action.data[:4] == _selector("claim(uint256[],address[][])")
        (ids, token_rewards) = decode(["uint256[]", "address[][]"], action.data[4:])
        assert list(ids) == [1, 2]
        assert len(token_rewards) == 2

    def test_claim_rejects_empty_token_ids(self):
        with pytest.raises(ValueError, match="token_ids"):
            RamsesClaimFuse(FUSE_ADDR).claim(
                token_ids=[], token_rewards=[[str(TOKEN_A)]]
            )

    def test_claim_rejects_empty_token_rewards(self):
        with pytest.raises(ValueError, match="token_rewards"):
            RamsesClaimFuse(FUSE_ADDR).claim(token_ids=[1], token_rewards=[])

    def test_claim_rejects_mismatched_lengths(self):
        with pytest.raises(ValueError, match="same length"):
            RamsesClaimFuse(FUSE_ADDR).claim(
                token_ids=[1, 2], token_rewards=[[str(TOKEN_A)]]
            )


# ── Gearbox V3 ─────────────────────────────────────────────────────────

STAKING_FUSE = Web3.to_checksum_address("0x3333333333333333333333333333333333333333")
STAKING_CONTRACT = Web3.to_checksum_address(
    "0x4444444444444444444444444444444444444444"
)
STAKING_FUSE_LOW = str(STAKING_FUSE).lower()
STAKING_CONTRACT_LOW = str(STAKING_CONTRACT).lower()


class TestGearboxSupplyFuse:
    def setup_method(self):
        self.fuse = GearboxSupplyFuse(FUSE_ADDR)

    def test_supply_returns_single_action(self):
        action = self.fuse.supply(vault_address=VAULT_ADDR, amount=5000)
        assert action.fuse == FUSE_ADDR

    def test_supply_encoding(self):
        action = self.fuse.supply(vault_address=VAULT_ADDR, amount=5000)
        assert action.data[:4] == _selector("enter((address,uint256))")
        (addr, amount) = decode(["address", "uint256"], action.data[4:])
        assert addr.lower() == VAULT_ADDR_LOW
        assert amount == 5000

    def test_withdraw_returns_single_action(self):
        action = self.fuse.withdraw(vault_address=VAULT_ADDR, amount=3000)
        assert action.fuse == FUSE_ADDR

    def test_withdraw_encoding(self):
        action = self.fuse.withdraw(vault_address=VAULT_ADDR, amount=3000)
        assert action.data[:4] == _selector("exit((address,uint256))")
        (addr, amount) = decode(["address", "uint256"], action.data[4:])
        assert addr.lower() == VAULT_ADDR_LOW
        assert amount == 3000


class TestGearboxStakeFuse:
    def test_stake(self):
        fuse = GearboxStakeFuse(FUSE_ADDR, TOKEN_A)
        action = fuse.stake()
        assert action.data[:4] == _selector("enter((uint256,address))")
        (amount, token) = decode(["uint256", "address"], action.data[4:])
        assert amount == MAX_UINT256
        assert token.lower() == TOKEN_A_LOW

    def test_unstake(self):
        fuse = GearboxStakeFuse(FUSE_ADDR, TOKEN_A)
        action = fuse.unstake(7777)
        assert action.data[:4] == _selector("exit((uint256,address))")
        (amount, token) = decode(["uint256", "address"], action.data[4:])
        assert amount == 7777
        assert token.lower() == TOKEN_A_LOW


# ── FluidInstadapp ─────────────────────────────────────────────────────


class TestFluidInstadappSupplyFuse:
    def setup_method(self):
        self.fuse = FluidInstadappSupplyFuse(FUSE_ADDR)

    def test_supply_encoding(self):
        action = self.fuse.supply(vault_address=VAULT_ADDR, amount=2000)
        assert action.fuse == FUSE_ADDR
        (addr, amount) = decode(["address", "uint256"], action.data[4:])
        assert addr.lower() == VAULT_ADDR_LOW
        assert amount == 2000

    def test_withdraw_encoding(self):
        action = self.fuse.withdraw(vault_address=VAULT_ADDR, amount=1000)
        assert action.fuse == FUSE_ADDR
        (addr, amount) = decode(["address", "uint256"], action.data[4:])
        assert addr.lower() == VAULT_ADDR_LOW
        assert amount == 1000


class TestFluidInstadappStakingFuse:
    def setup_method(self):
        self.fuse = FluidInstadappStakingFuse(
            fuse_address=STAKING_FUSE,
            staking_address=STAKING_CONTRACT,
        )

    def test_stake_encoding(self):
        action = self.fuse.stake()
        assert action.fuse == STAKING_FUSE
        (amount, contract) = decode(["uint256", "address"], action.data[4:])
        assert amount == MAX_UINT256
        assert contract.lower() == STAKING_CONTRACT_LOW

    def test_unstake_encoding(self):
        action = self.fuse.unstake(1000)
        assert action.fuse == STAKING_FUSE
        (amount, contract) = decode(["uint256", "address"], action.data[4:])
        assert amount == 1000
        assert contract.lower() == STAKING_CONTRACT_LOW


# ── UniversalTokenSwapper ──────────────────────────────────────────────


class TestUniversalTokenSwapperSubstrates:
    """Mirror of UniversalTokenSwapperSubstrateLib.sol: tag << 248 | payload."""

    def test_token(self):
        encoded = UniversalTokenSwapperSubstrates.token(TOKEN_A)
        assert len(encoded) == 32
        assert int.from_bytes(encoded, "big") == (1 << 248) | int(TOKEN_A, 16)

    def test_target(self):
        encoded = UniversalTokenSwapperSubstrates.target(TOKEN_B)
        assert int.from_bytes(encoded, "big") == (2 << 248) | int(TOKEN_B, 16)

    def test_slippage(self):
        encoded = UniversalTokenSwapperSubstrates.slippage(10**16)
        assert int.from_bytes(encoded, "big") == (3 << 248) | 10**16

    def test_slippage_out_of_range(self):
        with pytest.raises(ValueError, match="out of range"):
            UniversalTokenSwapperSubstrates.slippage(1 << 248)
        with pytest.raises(ValueError, match="out of range"):
            UniversalTokenSwapperSubstrates.slippage(-1)

    def test_malformed_address(self):
        with pytest.raises(ValueError, match="20-byte"):
            UniversalTokenSwapperSubstrates.token("0x1234")  # type: ignore[arg-type]

    @pytest.mark.parametrize("spelling", [ZERO_ADDRESS, "0" * 40])
    def test_zero_address_rejected(self, spelling):
        # Mirrors UniversalTokenSwapperSubstrateLibZeroAddress on-chain. The
        # error names the field, so a guard wired to the wrong one would show.
        with pytest.raises(ValueError, match="token must not be zero address"):
            UniversalTokenSwapperSubstrates.token(spelling)  # type: ignore[arg-type]
        with pytest.raises(ValueError, match="target must not be zero address"):
            UniversalTokenSwapperSubstrates.target(spelling)  # type: ignore[arg-type]


class TestUniversalTokenSwapperFuse:
    def test_swap(self):
        targets = [TOKEN_A, TOKEN_B]
        data = [b"\xaa\xbb", b"\xcc\xdd"]
        action = UniversalTokenSwapperFuse(FUSE_ADDR).swap(
            token_in=TOKEN_A,
            token_out=TOKEN_B,
            amount_in=5000,
            targets=targets,
            data=data,
        )
        assert action.data[:4] == _selector(
            "enter((address,address,uint256,(address[],bytes[])))"
        )
        (decoded_tuple,) = decode(
            ["(address,address,uint256,(address[],bytes[]))"], action.data[4:]
        )
        assert decoded_tuple[0].lower() == TOKEN_A_LOW
        assert decoded_tuple[1].lower() == TOKEN_B_LOW
        assert decoded_tuple[2] == 5000
        assert decoded_tuple[3][0][0].lower() == TOKEN_A_LOW
        assert decoded_tuple[3][0][1].lower() == TOKEN_B_LOW
        assert decoded_tuple[3][1][0] == b"\xaa\xbb"

    def test_swap_empty_targets(self):
        action = UniversalTokenSwapperFuse(FUSE_ADDR).swap(
            token_in=TOKEN_A, token_out=TOKEN_B, amount_in=100, targets=[], data=[]
        )
        (decoded_tuple,) = decode(
            ["(address,address,uint256,(address[],bytes[]))"], action.data[4:]
        )
        assert len(decoded_tuple[3][0]) == 0
        assert len(decoded_tuple[3][1]) == 0

    def test_swap_min_amount_out_abi(self):
        action = UniversalTokenSwapperFuse(
            FUSE_ADDR, abi=UniversalTokenSwapperAbi.MIN_AMOUNT_OUT
        ).swap(
            token_in=TOKEN_A,
            token_out=TOKEN_B,
            amount_in=5000,
            targets=[TOKEN_A],
            data=[b"\xaa\xbb"],
            min_amount_out=4900,
        )
        assert action.data[:4] == _selector(
            "enter((address,address,uint256,uint256,(address[],bytes[])))"
        )
        (decoded_tuple,) = decode(
            ["(address,address,uint256,uint256,(address[],bytes[]))"], action.data[4:]
        )
        assert decoded_tuple[0].lower() == TOKEN_A_LOW
        assert decoded_tuple[1].lower() == TOKEN_B_LOW
        assert decoded_tuple[2] == 5000
        assert decoded_tuple[3] == 4900
        assert decoded_tuple[4][1][0] == b"\xaa\xbb"

    def test_swap_min_amount_out_zero_allowed(self):
        action = UniversalTokenSwapperFuse(
            FUSE_ADDR, abi=UniversalTokenSwapperAbi.MIN_AMOUNT_OUT
        ).swap(
            token_in=TOKEN_A,
            token_out=TOKEN_B,
            amount_in=100,
            targets=[],
            data=[],
            min_amount_out=0,
        )
        (decoded_tuple,) = decode(
            ["(address,address,uint256,uint256,(address[],bytes[]))"], action.data[4:]
        )
        assert decoded_tuple[3] == 0

    def test_swap_min_amount_out_negative_rejected(self):
        with pytest.raises(ValueError, match="min_amount_out"):
            UniversalTokenSwapperFuse(
                FUSE_ADDR, abi=UniversalTokenSwapperAbi.MIN_AMOUNT_OUT
            ).swap(
                token_in=TOKEN_A,
                token_out=TOKEN_B,
                amount_in=100,
                targets=[],
                data=[],
                min_amount_out=-1,
            )

    def test_legacy_abi_rejects_min_amount_out(self):
        with pytest.raises(ValueError, match="min_amount_out"):
            UniversalTokenSwapperFuse(FUSE_ADDR).swap(
                token_in=TOKEN_A,
                token_out=TOKEN_B,
                amount_in=100,
                targets=[],
                data=[],
                min_amount_out=1,
            )

    def test_min_amount_out_abi_requires_min_amount_out(self):
        with pytest.raises(ValueError, match="min_amount_out"):
            UniversalTokenSwapperFuse(
                FUSE_ADDR, abi=UniversalTokenSwapperAbi.MIN_AMOUNT_OUT
            ).swap(
                token_in=TOKEN_A,
                token_out=TOKEN_B,
                amount_in=100,
                targets=[],
                data=[],
            )

    def test_eq_distinguishes_abi(self):
        legacy = UniversalTokenSwapperFuse(FUSE_ADDR)
        modern = UniversalTokenSwapperFuse(
            FUSE_ADDR, abi=UniversalTokenSwapperAbi.MIN_AMOUNT_OUT
        )
        assert legacy != modern
        assert hash(legacy) != hash(modern)
        assert legacy == UniversalTokenSwapperFuse(FUSE_ADDR)


# ── Input Validation ──────────────────────────────────────────────────

ZERO_ADDR = Web3.to_checksum_address(ZERO_ADDRESS)


class TestAmountValidation:
    """Amount=0 and amount<0 must raise ValueError across fuse types."""

    @pytest.mark.parametrize("bad_amount", [0, -1])
    def test_aave_supply_rejects_bad_amount(self, bad_amount):
        with pytest.raises(ValueError, match="amount"):
            AaveV3SupplyFuse(FUSE_ADDR).supply(asset=TOKEN_A, amount=bad_amount)

    @pytest.mark.parametrize("bad_amount", [0, -1])
    def test_aave_borrow_rejects_bad_amount(self, bad_amount):
        with pytest.raises(ValueError, match="amount"):
            AaveV3BorrowFuse(FUSE_ADDR).borrow(asset=TOKEN_A, amount=bad_amount)

    @pytest.mark.parametrize("bad_amount", [0, -1])
    def test_morpho_supply_rejects_bad_amount(self, bad_amount):
        with pytest.raises(ValueError, match="amount"):
            MorphoSupplyFuse(FUSE_ADDR).supply(market_id=MARKET_ID, amount=bad_amount)

    @pytest.mark.parametrize("bad_amount", [0, -1])
    def test_compound_supply_rejects_bad_amount(self, bad_amount):
        with pytest.raises(ValueError, match="amount"):
            CompoundV3SupplyFuse(FUSE_ADDR).supply(asset=TOKEN_A, amount=bad_amount)

    @pytest.mark.parametrize("bad_amount", [0, -1])
    def test_erc4626_supply_rejects_bad_amount(self, bad_amount):
        with pytest.raises(ValueError, match="amount"):
            ERC4626SupplyFuse(FUSE_ADDR).supply(
                vault_address=VAULT_ADDR, amount=bad_amount
            )

    @pytest.mark.parametrize("bad_amount", [0, -1])
    def test_uniswap_swap_rejects_bad_amount(self, bad_amount):
        with pytest.raises(ValueError, match="amount_in"):
            UniswapV3SwapFuse(FUSE_ADDR).swap(
                token_in=TOKEN_A,
                token_out=TOKEN_B,
                fee=3000,
                amount_in=bad_amount,
                min_amount_out=0,
            )

    @pytest.mark.parametrize("bad_amount", [0, -1])
    def test_unstake_rejects_bad_amount(self, bad_amount):
        with pytest.raises(ValueError, match="amount"):
            GearboxStakeFuse(FUSE_ADDR, TOKEN_A).unstake(bad_amount)

    @pytest.mark.parametrize("bad_amount", [0, -1])
    def test_decrease_liquidity_rejects_bad_liquidity(self, bad_amount):
        with pytest.raises(ValueError, match="liquidity"):
            UniswapV3ModifyPositionFuse(FUSE_ADDR).decrease_liquidity(
                token_id=1,
                liquidity=bad_amount,
                amount0_min=0,
                amount1_min=0,
                deadline=99,
            )

    @pytest.mark.parametrize("bad_amount", [0, -1])
    def test_morpho_claim_rejects_bad_claimable(self, bad_amount):
        with pytest.raises(ValueError, match="claimable"):
            MorphoClaimFuse(FUSE_ADDR).claim(
                universal_rewards_distributor=TOKEN_A,
                rewards_token=TOKEN_B,
                claimable=bad_amount,
                proof=[],
            )


class TestAddressValidation:
    """Zero address must raise ValueError across fuse types."""

    def test_aave_supply_rejects_zero_address(self):
        with pytest.raises(ValueError, match="asset"):
            AaveV3SupplyFuse(FUSE_ADDR).supply(asset=ZERO_ADDR, amount=1000)

    def test_compound_supply_rejects_zero_address(self):
        with pytest.raises(ValueError, match="asset"):
            CompoundV3SupplyFuse(FUSE_ADDR).supply(asset=ZERO_ADDR, amount=1000)

    def test_erc4626_supply_rejects_zero_address(self):
        with pytest.raises(ValueError, match="vault_address"):
            ERC4626SupplyFuse(FUSE_ADDR).supply(vault_address=ZERO_ADDR, amount=1000)

    def test_uniswap_swap_rejects_zero_token_in(self):
        with pytest.raises(ValueError, match="token_in"):
            UniswapV3SwapFuse(FUSE_ADDR).swap(
                token_in=ZERO_ADDR,
                token_out=TOKEN_B,
                fee=3000,
                amount_in=100,
                min_amount_out=0,
            )

    def test_uniswap_swap_rejects_zero_token_out(self):
        with pytest.raises(ValueError, match="token_out"):
            UniswapV3SwapFuse(FUSE_ADDR).swap(
                token_in=TOKEN_A,
                token_out=ZERO_ADDR,
                fee=3000,
                amount_in=100,
                min_amount_out=0,
            )

    def test_universal_swap_rejects_zero_token_in(self):
        with pytest.raises(ValueError, match="token_in"):
            UniversalTokenSwapperFuse(FUSE_ADDR).swap(
                token_in=ZERO_ADDR,
                token_out=TOKEN_B,
                amount_in=100,
                targets=[],
                data=[],
            )

    def test_morpho_flash_loan_rejects_zero_asset(self):
        with pytest.raises(ValueError, match="asset"):
            MorphoFlashLoanFuse(FUSE_ADDR).flash_loan(
                asset=ZERO_ADDR, amount=100, actions=[]
            )

    def test_morpho_claim_rejects_zero_distributor(self):
        with pytest.raises(ValueError, match="universal_rewards_distributor"):
            MorphoClaimFuse(FUSE_ADDR).claim(
                universal_rewards_distributor=ZERO_ADDR,
                rewards_token=TOKEN_B,
                claimable=100,
                proof=[],
            )

    def test_morpho_claim_rejects_zero_rewards_token(self):
        with pytest.raises(ValueError, match="rewards_token"):
            MorphoClaimFuse(FUSE_ADDR).claim(
                universal_rewards_distributor=TOKEN_A,
                rewards_token=ZERO_ADDR,
                claimable=100,
                proof=[],
            )

    def test_aave_borrow_rejects_zero_asset(self):
        with pytest.raises(ValueError, match="asset"):
            AaveV3BorrowFuse(FUSE_ADDR).borrow(asset=ZERO_ADDR, amount=1000)


class TestSlippageParamsAllowZero:
    """min_amount_out and amount_min params must accept zero (slippage tolerance)."""

    def test_uniswap_swap_allows_zero_min_amount_out(self):
        action = UniswapV3SwapFuse(FUSE_ADDR).swap(
            token_in=TOKEN_A,
            token_out=TOKEN_B,
            fee=3000,
            amount_in=100,
            min_amount_out=0,
        )
        assert action.fuse == FUSE_ADDR

    def test_new_position_allows_zero_amount_min(self):
        action = UniswapV3NewPositionFuse(FUSE_ADDR).new_position(
            token0=TOKEN_A,
            token1=TOKEN_B,
            fee=500,
            tick_lower=-100,
            tick_upper=100,
            amount0_desired=1000,
            amount1_desired=2000,
            amount0_min=0,
            amount1_min=0,
            deadline=99999,
        )
        assert action.fuse == FUSE_ADDR

    def test_decrease_liquidity_allows_zero_amount_min(self):
        action = UniswapV3ModifyPositionFuse(FUSE_ADDR).decrease_liquidity(
            token_id=1, liquidity=500, amount0_min=0, amount1_min=0, deadline=99
        )
        assert action.fuse == FUSE_ADDR


class TestFuseConstructorValidation:
    """Fuse constructor must reject zero and empty addresses."""

    @pytest.mark.parametrize("spelling", [ZERO_ADDR, "0" * 40])
    def test_zero_address_rejected(self, spelling):
        # Prefixed and un-prefixed name the same address; both must be caught.
        with pytest.raises(ValueError, match="zero address"):
            AaveV3SupplyFuse(spelling)

    def test_none_address_rejected(self):
        with pytest.raises(ValueError):
            AaveV3SupplyFuse(None)  # type: ignore[arg-type]


class TestListParameterValidation:
    """Empty token_ids lists must raise ValueError."""

    def test_uniswap_close_position_rejects_empty_list(self):
        with pytest.raises(ValueError, match="token_ids"):
            UniswapV3NewPositionFuse(FUSE_ADDR).close_position([])

    def test_uniswap_collect_rejects_empty_list(self):
        with pytest.raises(ValueError, match="token_ids"):
            UniswapV3CollectFuse(FUSE_ADDR).collect([])

    def test_ramses_close_position_rejects_empty_list(self):
        with pytest.raises(ValueError, match="token_ids"):
            RamsesV2NewPositionFuse(FUSE_ADDR).close_position([])

    def test_ramses_collect_rejects_empty_list(self):
        with pytest.raises(ValueError, match="token_ids"):
            RamsesV2CollectFuse(FUSE_ADDR).collect([])


class TestTokenIdValidation:
    """Negative token_id must raise ValueError."""

    def test_uniswap_decrease_liquidity_rejects_negative_token_id(self):
        with pytest.raises(ValueError, match="token_id"):
            UniswapV3ModifyPositionFuse(FUSE_ADDR).decrease_liquidity(
                token_id=-1, liquidity=500, amount0_min=0, amount1_min=0, deadline=99
            )

    def test_uniswap_increase_liquidity_rejects_negative_token_id(self):
        with pytest.raises(ValueError, match="token_id"):
            UniswapV3ModifyPositionFuse(FUSE_ADDR).increase_liquidity(
                token0=TOKEN_A,
                token1=TOKEN_B,
                token_id=-1,
                amount0_desired=1000,
                amount1_desired=2000,
                amount0_min=0,
                amount1_min=0,
                deadline=99999,
            )

    def test_ramses_decrease_liquidity_rejects_negative_token_id(self):
        with pytest.raises(ValueError, match="token_id"):
            RamsesV2ModifyPositionFuse(FUSE_ADDR).decrease_liquidity(
                token_id=-1, liquidity=400, amount0_min=0, amount1_min=0, deadline=99
            )

    def test_ramses_increase_liquidity_rejects_negative_token_id(self):
        with pytest.raises(ValueError, match="token_id"):
            RamsesV2ModifyPositionFuse(FUSE_ADDR).increase_liquidity(
                token0=TOKEN_A,
                token1=TOKEN_B,
                token_id=-1,
                amount0_desired=1000,
                amount1_desired=2000,
                amount0_min=0,
                amount1_min=0,
                deadline=99999,
            )

    def test_uniswap_decrease_liquidity_allows_zero_token_id(self):
        action = UniswapV3ModifyPositionFuse(FUSE_ADDR).decrease_liquidity(
            token_id=0, liquidity=500, amount0_min=0, amount1_min=0, deadline=99
        )
        assert action.fuse == FUSE_ADDR


class TestUniversalSwapEdgeCases:
    """Mismatched targets/data lengths must raise ValueError."""

    def test_mismatched_targets_data_lengths(self):
        with pytest.raises(ValueError, match="same length"):
            UniversalTokenSwapperFuse(FUSE_ADDR).swap(
                token_in=TOKEN_A,
                token_out=TOKEN_B,
                amount_in=100,
                targets=[TOKEN_A],
                data=[],
            )

    def test_mismatched_data_longer_than_targets(self):
        with pytest.raises(ValueError, match="same length"):
            UniversalTokenSwapperFuse(FUSE_ADDR).swap(
                token_in=TOKEN_A,
                token_out=TOKEN_B,
                amount_in=100,
                targets=[],
                data=[b"\xaa"],
            )


# ── _parse_param_types ────────────────────────────────────────────────


class TestParseParamTypes:
    def test_simple_types(self):
        assert _parse_param_types("transfer(address,uint256)") == [
            "address",
            "uint256",
        ]

    def test_empty_params(self):
        assert not _parse_param_types("doSomething()")

    def test_single_param(self):
        assert _parse_param_types("foo(uint256)") == ["uint256"]

    def test_nested_tuple(self):
        assert _parse_param_types("enter((address,uint256))") == ["(address,uint256)"]

    def test_tuple_array(self):
        assert _parse_param_types("execute((address,bytes)[])") == ["(address,bytes)[]"]

    def test_multiple_params_with_tuple(self):
        assert _parse_param_types("foo(uint256,(address,uint256),bool)") == [
            "uint256",
            "(address,uint256)",
            "bool",
        ]

    def test_deeply_nested_tuple(self):
        assert _parse_param_types("enter((address,uint256,(uint256,address)))") == [
            "(address,uint256,(uint256,address))"
        ]

    def test_multiple_tuples(self):
        assert _parse_param_types("foo((uint256,address),(bool,bytes))") == [
            "(uint256,address)",
            "(bool,bytes)",
        ]


# ── Euler V2 ──────────────────────────────────────────────────────────


class TestEulerSubstrate:
    def test_packs_layout(self):
        # eulerVault<<96 | isCollateral<<88 | canBorrow<<80 | subAccounts<<72
        packed = euler_substrate(
            euler_vault=TOKEN_A, is_collateral=True, can_borrow=False, sub_account=0x01
        )
        assert len(packed) == 32
        assert packed[:20].hex() == TOKEN_A_LOW[2:]
        assert packed[20] == 1  # isCollateral
        assert packed[21] == 0  # canBorrow
        assert packed[22] == 1  # subAccount

    def test_rejects_out_of_range_sub_account(self):
        with pytest.raises(ValueError):
            euler_substrate(
                euler_vault=TOKEN_A,
                is_collateral=True,
                can_borrow=True,
                sub_account=256,
            )


class TestEulerV2SupplyFuse:
    def test_supply(self):
        action = EulerV2SupplyFuse(FUSE_ADDR).supply(
            euler_vault=TOKEN_A, max_amount=1000, sub_account=0x01
        )
        assert action.data[:4] == _selector("enter((address,uint256,bytes1))")
        (vault, amount, sub) = decode(["address", "uint256", "bytes1"], action.data[4:])
        assert vault.lower() == TOKEN_A_LOW
        assert amount == 1000
        assert sub == b"\x01"

    def test_withdraw(self):
        action = EulerV2SupplyFuse(FUSE_ADDR).withdraw(
            euler_vault=TOKEN_A, max_amount=500, sub_account=0x02
        )
        assert action.data[:4] == _selector("exit((address,uint256,bytes1))")
        (vault, amount, sub) = decode(["address", "uint256", "bytes1"], action.data[4:])
        assert vault.lower() == TOKEN_A_LOW
        assert amount == 500
        assert sub == b"\x02"

    def test_supply_rejects_zero_vault(self):
        with pytest.raises(ValueError):
            EulerV2SupplyFuse(FUSE_ADDR).supply(
                euler_vault=ZERO_ADDRESS, max_amount=1, sub_account=0x01
            )


def _static_params() -> EulerSwapStaticParams:
    return EulerSwapStaticParams(
        supply_vault0=TOKEN_A,
        supply_vault1=TOKEN_B,
        borrow_vault0=TOKEN_A,
        borrow_vault1=TOKEN_B,
        euler_account=VAULT_ADDR,
        fee_recipient=Web3.to_checksum_address(ZERO_ADDRESS),
    )


def _dynamic_params() -> EulerSwapDynamicParams:
    return EulerSwapDynamicParams(
        equilibrium_reserve0=5,
        equilibrium_reserve1=6,
        min_reserve0=0,
        min_reserve1=0,
        price_x=10**18,
        price_y=10**18,
        concentration_x=1,
        concentration_y=2,
        fee0=3,
        fee1=4,
        expiration=0,
        swap_hooked_operations=0,
        swap_hook=Web3.to_checksum_address(ZERO_ADDRESS),
    )


class TestEulerV2SwapDeployFuse:
    _ENTER = (
        "enter("
        "((address,address,address,address,address,address),"
        "(uint112,uint112,uint112,uint112,uint80,uint80,uint64,uint64,"
        "uint64,uint64,uint40,uint8,address),"
        "(uint112,uint112),bytes32,address,bytes1))"
    )

    def test_deploy(self):
        salt = (1234).to_bytes(32, "big")
        action = EulerV2SwapDeployFuse(FUSE_ADDR).deploy(
            static_params=_static_params(),
            dynamic_params=_dynamic_params(),
            initial_state=EulerSwapInitialState(reserve0=5, reserve1=6),
            salt=salt,
            predicted_pool=TOKEN_A,
            sub_account=0x01,
        )
        assert action.data[:4] == _selector(self._ENTER)
        (decoded,) = decode(
            [
                "((address,address,address,address,address,address),"
                "(uint112,uint112,uint112,uint112,uint80,uint80,uint64,uint64,"
                "uint64,uint64,uint40,uint8,address),"
                "(uint112,uint112),bytes32,address,bytes1)"
            ],
            action.data[4:],
        )
        static, _, init, decoded_salt, pool, sub = decoded
        assert static[0].lower() == TOKEN_A_LOW
        assert init == (5, 6)
        assert decoded_salt == salt
        assert pool.lower() == TOKEN_A_LOW
        assert sub == b"\x01"

    def test_deploy_rejects_bad_salt_length(self):
        with pytest.raises(ValueError):
            EulerV2SwapDeployFuse(FUSE_ADDR).deploy(
                static_params=_static_params(),
                dynamic_params=_dynamic_params(),
                initial_state=EulerSwapInitialState(reserve0=5, reserve1=6),
                salt=b"\x00" * 16,
                predicted_pool=TOKEN_A,
                sub_account=0x01,
            )

    def test_decommission(self):
        action = EulerV2SwapDeployFuse(FUSE_ADDR).decommission(
            pool=TOKEN_B, sub_account=0x03
        )
        assert action.data[:4] == _selector("exit((address,bytes1))")
        (pool, sub) = decode(["address", "bytes1"], action.data[4:])
        assert pool.lower() == TOKEN_B_LOW
        assert sub == b"\x03"


class TestEulerV2SwapReconfigureFuse:
    _ENTER = (
        "enter("
        "(address,bytes1,"
        "(uint112,uint112,uint112,uint112,uint80,uint80,uint64,uint64,"
        "uint64,uint64,uint40,uint8,address),"
        "(uint112,uint112)))"
    )

    def test_reconfigure(self):
        action = EulerV2SwapReconfigureFuse(FUSE_ADDR).reconfigure(
            pool=TOKEN_A,
            sub_account=0x01,
            dynamic_params=_dynamic_params(),
            initial_state=EulerSwapInitialState(reserve0=7, reserve1=8),
        )
        assert action.data[:4] == _selector(self._ENTER)
        (decoded,) = decode(
            [
                "(address,bytes1,"
                "(uint112,uint112,uint112,uint112,uint80,uint80,uint64,uint64,"
                "uint64,uint64,uint40,uint8,address),"
                "(uint112,uint112))"
            ],
            action.data[4:],
        )
        pool, sub, dyn, init = decoded
        assert pool.lower() == TOKEN_A_LOW
        assert sub == b"\x01"
        assert dyn[8] == 3  # fee0 (from _dynamic_params)
        assert init == (7, 8)

    def test_reconfigure_rejects_zero_pool(self):
        with pytest.raises(ValueError):
            EulerV2SwapReconfigureFuse(FUSE_ADDR).reconfigure(
                pool=ZERO_ADDRESS,
                sub_account=0x01,
                dynamic_params=_dynamic_params(),
                initial_state=EulerSwapInitialState(reserve0=1, reserve1=2),
            )


class TestEulerV2SwapRegistryFuse:
    def test_register(self):
        action = EulerV2SwapRegistryFuse(FUSE_ADDR).register(
            pool=TOKEN_A, sub_account=0x01
        )
        assert action.data[:4] == _selector("enter((address,bytes1))")
        (pool, sub) = decode(["address", "bytes1"], action.data[4:])
        assert pool.lower() == TOKEN_A_LOW
        assert sub == b"\x01"

    def test_unregister(self):
        action = EulerV2SwapRegistryFuse(FUSE_ADDR).unregister(
            pool=TOKEN_B, sub_account=0x02
        )
        assert action.data[:4] == _selector("exit((address,bytes1))")
        (pool, sub) = decode(["address", "bytes1"], action.data[4:])
        assert pool.lower() == TOKEN_B_LOW
        assert sub == b"\x02"

    def test_register_rejects_zero_pool(self):
        with pytest.raises(ValueError):
            EulerV2SwapRegistryFuse(FUSE_ADDR).register(
                pool=ZERO_ADDRESS, sub_account=0x01
            )


class TestEulerV2BatchFuse:
    _ENTER = "enter(((address,bytes1,bytes)[],address[],address[]))"

    def test_batch(self):
        items = [
            EulerV2BatchItem(
                target_contract=TOKEN_A, on_behalf_of_account=0x00, data=b"\x11\x22"
            ),
            EulerV2BatchItem(
                target_contract=TOKEN_B, on_behalf_of_account=0x01, data=b"\x33"
            ),
        ]
        action = EulerV2BatchFuse(FUSE_ADDR).batch(
            items=items,
            assets_for_approvals=[TOKEN_A],
            euler_vaults_for_approvals=[TOKEN_B],
        )
        assert action.data[:4] == _selector(self._ENTER)
        (decoded,) = decode(
            ["((address,bytes1,bytes)[],address[],address[])"], action.data[4:]
        )
        batch_items, assets, vaults = decoded
        assert len(batch_items) == 2
        assert batch_items[0][0].lower() == TOKEN_A_LOW
        assert batch_items[0][1] == b"\x00"
        assert batch_items[0][2] == b"\x11\x22"
        assert batch_items[1][1] == b"\x01"
        assert [a.lower() for a in assets] == [TOKEN_A_LOW]
        assert [v.lower() for v in vaults] == [TOKEN_B_LOW]

    def test_batch_defaults_empty_approvals(self):
        action = EulerV2BatchFuse(FUSE_ADDR).batch(
            items=[
                EulerV2BatchItem(
                    target_contract=TOKEN_A, on_behalf_of_account=0, data=b""
                )
            ]
        )
        (decoded,) = decode(
            ["((address,bytes1,bytes)[],address[],address[])"], action.data[4:]
        )
        _, assets, vaults = decoded
        assert len(assets) == 0
        assert len(vaults) == 0

    def test_batch_rejects_empty_items(self):
        with pytest.raises(ValueError):
            EulerV2BatchFuse(FUSE_ADDR).batch(items=[])

    def test_batch_rejects_approval_length_mismatch(self):
        with pytest.raises(ValueError):
            EulerV2BatchFuse(FUSE_ADDR).batch(
                items=[
                    EulerV2BatchItem(
                        target_contract=TOKEN_A, on_behalf_of_account=0, data=b""
                    )
                ],
                assets_for_approvals=[TOKEN_A],
                euler_vaults_for_approvals=[],
            )


class TestEulerV2CollateralFuse:
    def test_enable_collateral(self):
        action = EulerV2CollateralFuse(FUSE_ADDR).enable_collateral(
            euler_vault=TOKEN_A, sub_account=0x01
        )
        assert action.data[:4] == _selector("enter((address,bytes1))")
        (vault, sub) = decode(["address", "bytes1"], action.data[4:])
        assert vault.lower() == TOKEN_A_LOW
        assert sub == b"\x01"

    def test_disable_collateral(self):
        action = EulerV2CollateralFuse(FUSE_ADDR).disable_collateral(
            euler_vault=TOKEN_B, sub_account=0x02
        )
        assert action.data[:4] == _selector("exit((address,bytes1))")
        (vault, sub) = decode(["address", "bytes1"], action.data[4:])
        assert vault.lower() == TOKEN_B_LOW
        assert sub == b"\x02"

    def test_rejects_zero_vault(self):
        with pytest.raises(ValueError):
            EulerV2CollateralFuse(FUSE_ADDR).enable_collateral(
                euler_vault=ZERO_ADDRESS, sub_account=0x01
            )


class TestEulerV2ControllerFuse:
    def test_enable_controller(self):
        action = EulerV2ControllerFuse(FUSE_ADDR).enable_controller(
            euler_vault=TOKEN_A, sub_account=0x01
        )
        assert action.data[:4] == _selector("enter((address,bytes1))")
        (vault, sub) = decode(["address", "bytes1"], action.data[4:])
        assert vault.lower() == TOKEN_A_LOW
        assert sub == b"\x01"

    def test_disable_controller(self):
        action = EulerV2ControllerFuse(FUSE_ADDR).disable_controller(
            euler_vault=TOKEN_A, sub_account=0x03
        )
        assert action.data[:4] == _selector("exit((address,bytes1))")
        (_, sub) = decode(["address", "bytes1"], action.data[4:])
        assert sub == b"\x03"

    def test_rejects_zero_vault(self):
        with pytest.raises(ValueError):
            EulerV2ControllerFuse(FUSE_ADDR).enable_controller(
                euler_vault=ZERO_ADDRESS, sub_account=0x01
            )


class TestEulerV2BorrowFuse:
    def test_borrow(self):
        action = EulerV2BorrowFuse(FUSE_ADDR).borrow(
            euler_vault=TOKEN_A, asset_amount=1234, sub_account=0x01
        )
        assert action.data[:4] == _selector("enter((address,uint256,bytes1))")
        (vault, amount, sub) = decode(["address", "uint256", "bytes1"], action.data[4:])
        assert vault.lower() == TOKEN_A_LOW
        assert amount == 1234
        assert sub == b"\x01"

    def test_repay(self):
        action = EulerV2BorrowFuse(FUSE_ADDR).repay(
            euler_vault=TOKEN_B, max_asset_amount=MAX_UINT256, sub_account=0x02
        )
        assert action.data[:4] == _selector("exit((address,uint256,bytes1))")
        (vault, amount, sub) = decode(["address", "uint256", "bytes1"], action.data[4:])
        assert vault.lower() == TOKEN_B_LOW
        assert amount == MAX_UINT256
        assert sub == b"\x02"

    def test_rejects_zero_vault(self):
        with pytest.raises(ValueError):
            EulerV2BorrowFuse(FUSE_ADDR).borrow(
                euler_vault=ZERO_ADDRESS, asset_amount=1, sub_account=0x01
            )


# ── ExternalState (market 50) ───────────────────────────────────────────


class TestExternalStateOperationFuse:
    _TUPLE = "(address,uint256,address,(address,bytes)[])"

    def test_enter_selector_and_roundtrip(self):
        actions = [(TOKEN_B, b"\xde\xad\xbe\xef")]
        action = ExternalStateOperationFuse(FUSE_ADDR).enter(
            asset=TOKEN_A, amount=1_000_000, balance_account=VAULT_ADDR, actions=actions
        )
        assert action.fuse == FUSE_ADDR
        assert action.data[:4] == _selector(f"enter({self._TUPLE})")

        ((asset, amount, ba, decoded_actions),) = decode([self._TUPLE], action.data[4:])
        assert asset.lower() == TOKEN_A_LOW
        assert amount == 1_000_000
        assert ba.lower() == VAULT_ADDR_LOW
        assert len(decoded_actions) == 1
        assert decoded_actions[0][0].lower() == TOKEN_B_LOW
        assert decoded_actions[0][1] == b"\xde\xad\xbe\xef"

    def test_exit_selector_and_multiple_actions(self):
        actions = [(TOKEN_A, b"\x01"), (TOKEN_B, b"\x02\x03")]
        action = ExternalStateOperationFuse(FUSE_ADDR).exit(
            asset=TOKEN_A, amount=42, balance_account=VAULT_ADDR, actions=actions
        )
        assert action.data[:4] == _selector(f"exit({self._TUPLE})")
        ((_, _, _, decoded_actions),) = decode([self._TUPLE], action.data[4:])
        assert [payload for _, payload in decoded_actions] == [
            b"\x01",
            b"\x02\x03",
        ]

    def test_actions_only_enter_allows_zero_asset_and_empty_actions(self):
        # amount == 0 is a valid "actions-only" call; asset may be the zero address.
        action = ExternalStateOperationFuse(FUSE_ADDR).enter(
            asset=ZERO_ADDRESS, amount=0, balance_account=VAULT_ADDR, actions=[]
        )
        ((asset, amount, _, decoded_actions),) = decode([self._TUPLE], action.data[4:])
        assert amount == 0
        assert int(asset, 16) == 0
        assert len(decoded_actions) == 0

    def test_negative_amount_rejected(self):
        with pytest.raises(ValueError, match="must not be negative"):
            ExternalStateOperationFuse(FUSE_ADDR).enter(
                asset=TOKEN_A, amount=-1, balance_account=VAULT_ADDR, actions=[]
            )

    def test_zero_balance_account_rejected(self):
        with pytest.raises(ValueError, match="balance_account"):
            ExternalStateOperationFuse(FUSE_ADDR).enter(
                asset=TOKEN_A, amount=1, balance_account=ZERO_ADDRESS, actions=[]
            )

    def test_zero_asset_rejected_when_amount_positive(self):
        with pytest.raises(ValueError, match="asset"):
            ExternalStateOperationFuse(FUSE_ADDR).enter(
                asset=ZERO_ADDRESS, amount=1, balance_account=VAULT_ADDR, actions=[]
            )

    def test_zero_action_target_rejected(self):
        with pytest.raises(ValueError, match=r"actions\[0\]"):
            ExternalStateOperationFuse(FUSE_ADDR).exit(
                asset=TOKEN_A,
                amount=1,
                balance_account=VAULT_ADDR,
                actions=[(ZERO_ADDRESS, b"\x00")],
            )

    def test_create_executor_is_bare_selector(self):
        action = ExternalStateOperationFuse(FUSE_ADDR).create_executor()
        assert action.fuse == FUSE_ADDR
        assert action.data == _selector("createExecutor()")


# ── AsyncAction (market 40) ─────────────────────────────────────────────


class TestAsyncActionFuse:
    _ENTER = "(address,uint256,address[],bytes[],uint256[],address[])"
    _EXIT = "(address[],bytes[])"

    def test_enter_selector_and_defaults(self):
        action = AsyncActionFuse(FUSE_ADDR).enter(
            token_out=TOKEN_A,
            amount_out=1000,
            targets=[TOKEN_B],
            call_datas=[b"\xaa\xbb"],
        )
        assert action.fuse == FUSE_ADDR
        assert action.data[:4] == _selector(f"enter({self._ENTER})")
        ((tok, amt, targets, cds, eths, dust),) = decode([self._ENTER], action.data[4:])
        assert tok.lower() == TOKEN_A_LOW
        assert amt == 1000
        assert [t.lower() for t in targets] == [TOKEN_B_LOW]
        assert list(cds) == [b"\xaa\xbb"]
        assert list(eths) == [0]  # default zeros, one per target
        assert list(dust) == []  # default empty

    def test_enter_explicit_eth_and_dust(self):
        action = AsyncActionFuse(FUSE_ADDR).enter(
            token_out=TOKEN_A,
            amount_out=5,
            targets=[TOKEN_B, VAULT_ADDR],
            call_datas=[b"\x01", b"\x02"],
            eth_amounts=[7, 8],
            tokens_dust_to_check=[TOKEN_A],
        )
        ((_, _, _, _, eths, dust),) = decode([self._ENTER], action.data[4:])
        assert list(eths) == [7, 8]
        assert [d.lower() for d in dust] == [TOKEN_A_LOW]

    def test_enter_rejects_mismatched_targets_calldatas(self):
        with pytest.raises(ValueError, match="same length"):
            AsyncActionFuse(FUSE_ADDR).enter(
                token_out=TOKEN_A, amount_out=1, targets=[TOKEN_B], call_datas=[]
            )

    def test_enter_rejects_mismatched_eth_amounts(self):
        with pytest.raises(ValueError, match="eth_amounts"):
            AsyncActionFuse(FUSE_ADDR).enter(
                token_out=TOKEN_A,
                amount_out=1,
                targets=[TOKEN_B],
                call_datas=[b"\x01"],
                eth_amounts=[1, 2],
            )

    def test_enter_rejects_zero_token_out(self):
        with pytest.raises(ValueError, match="token_out"):
            AsyncActionFuse(FUSE_ADDR).enter(
                token_out=ZERO_ADDRESS, amount_out=1, targets=[], call_datas=[]
            )

    def test_enter_rejects_negative_amount(self):
        with pytest.raises(ValueError, match="must not be negative"):
            AsyncActionFuse(FUSE_ADDR).enter(
                token_out=TOKEN_A, amount_out=-1, targets=[], call_datas=[]
            )

    def test_enter_actions_only_zero_amount(self):
        # amount_out == 0 is a documented actions-only enter.
        action = AsyncActionFuse(FUSE_ADDR).enter(
            token_out=TOKEN_A, amount_out=0, targets=[TOKEN_B], call_datas=[b"\x01"]
        )
        ((_, amt, _, _, _, _),) = decode([self._ENTER], action.data[4:])
        assert amt == 0

    def test_enter_fund_only_empty_targets(self):
        # Fund the executor with a real amount but run no actions.
        action = AsyncActionFuse(FUSE_ADDR).enter(
            token_out=TOKEN_A, amount_out=1000, targets=[], call_datas=[]
        )
        ((tok, amt, targets, cds, eths, dust),) = decode([self._ENTER], action.data[4:])
        assert tok.lower() == TOKEN_A_LOW
        assert amt == 1000
        assert len(targets) == 0
        assert len(cds) == 0
        assert len(eths) == 0
        assert len(dust) == 0

    def test_enter_rejects_zero_target(self):
        with pytest.raises(ValueError, match=r"targets\[0\]"):
            AsyncActionFuse(FUSE_ADDR).enter(
                token_out=TOKEN_A,
                amount_out=1,
                targets=[ZERO_ADDRESS],
                call_datas=[b"\x01"],
            )

    def test_enter_rejects_negative_eth_amount(self):
        with pytest.raises(ValueError, match=r"eth_amounts\[0\]"):
            AsyncActionFuse(FUSE_ADDR).enter(
                token_out=TOKEN_A,
                amount_out=1,
                targets=[TOKEN_B],
                call_datas=[b"\x01"],
                eth_amounts=[-1],
            )

    def test_transfer_out_builds_single_transfer(self):
        action = AsyncActionFuse(FUSE_ADDR).transfer_out(
            token_out=TOKEN_A, amount_out=500, destination=VAULT_ADDR
        )
        assert action.fuse == FUSE_ADDR
        assert action.data[:4] == _selector(f"enter({self._ENTER})")
        ((tok, amt, targets, cds, eths, _),) = decode([self._ENTER], action.data[4:])
        assert tok.lower() == TOKEN_A_LOW
        assert amt == 500
        assert [t.lower() for t in targets] == [TOKEN_A_LOW]  # target is token_out
        assert cds[0][:4] == _selector("transfer(address,uint256)")
        (dest, transferred) = decode(["address", "uint256"], cds[0][4:])
        assert dest.lower() == VAULT_ADDR_LOW
        assert transferred == 500
        assert list(eths) == [0]

    def test_transfer_out_rejects_zero_amount(self):
        with pytest.raises(ValueError, match="amount_out"):
            AsyncActionFuse(FUSE_ADDR).transfer_out(
                token_out=TOKEN_A, amount_out=0, destination=VAULT_ADDR
            )

    def test_transfer_out_rejects_zero_destination(self):
        with pytest.raises(ValueError, match="destination"):
            AsyncActionFuse(FUSE_ADDR).transfer_out(
                token_out=TOKEN_A, amount_out=1, destination=ZERO_ADDRESS
            )

    def test_transfer_out_many_sums_and_splits(self):
        action = AsyncActionFuse(FUSE_ADDR).transfer_out_many(
            token_out=TOKEN_A, transfers=[(VAULT_ADDR, 100), (TOKEN_B, 250)]
        )
        assert action.fuse == FUSE_ADDR
        assert action.data[:4] == _selector(f"enter({self._ENTER})")
        ((_, amt, targets, cds, _, _),) = decode([self._ENTER], action.data[4:])
        assert amt == 350  # funded with the sum
        assert [t.lower() for t in targets] == [TOKEN_A_LOW, TOKEN_A_LOW]
        (d0, a0) = decode(["address", "uint256"], cds[0][4:])
        (d1, a1) = decode(["address", "uint256"], cds[1][4:])
        assert (d0.lower(), a0) == (VAULT_ADDR_LOW, 100)
        assert (d1.lower(), a1) == (TOKEN_B_LOW, 250)

    def test_transfer_out_many_rejects_empty(self):
        with pytest.raises(ValueError, match="transfers"):
            AsyncActionFuse(FUSE_ADDR).transfer_out_many(
                token_out=TOKEN_A, transfers=[]
            )

    def test_transfer_out_many_rejects_zero_amount(self):
        with pytest.raises(ValueError, match=r"transfers\[1\]"):
            AsyncActionFuse(FUSE_ADDR).transfer_out_many(
                token_out=TOKEN_A, transfers=[(VAULT_ADDR, 100), (TOKEN_B, 0)]
            )

    def test_transfer_out_many_rejects_zero_destination(self):
        with pytest.raises(ValueError, match=r"transfers\[1\]\.destination"):
            AsyncActionFuse(FUSE_ADDR).transfer_out_many(
                token_out=TOKEN_A, transfers=[(VAULT_ADDR, 100), (ZERO_ADDRESS, 50)]
            )

    def test_exit_default_balanceof_carrier(self):
        action = AsyncActionFuse(FUSE_ADDR).exit(assets=[TOKEN_A, TOKEN_B])
        assert action.data[:4] == _selector(f"exit({self._EXIT})")
        ((assets, fetch),) = decode([self._EXIT], action.data[4:])
        assert [a.lower() for a in assets] == [TOKEN_A_LOW, TOKEN_B_LOW]
        balance_of = _selector("balanceOf(address)")
        assert list(fetch) == [balance_of, balance_of]

    def test_exit_explicit_fetch(self):
        action = AsyncActionFuse(FUSE_ADDR).exit(
            assets=[TOKEN_A], fetch_call_datas=[b"\xde\xad\xbe\xef"]
        )
        ((_, fetch),) = decode([self._EXIT], action.data[4:])
        assert list(fetch) == [b"\xde\xad\xbe\xef"]

    def test_exit_rejects_mismatched_fetch(self):
        with pytest.raises(ValueError, match="fetch_call_datas"):
            AsyncActionFuse(FUSE_ADDR).exit(
                assets=[TOKEN_A, TOKEN_B], fetch_call_datas=[b"\x01"]
            )

    def test_exit_empty_assets(self):
        action = AsyncActionFuse(FUSE_ADDR).exit(assets=[])
        ((assets, fetch),) = decode([self._EXIT], action.data[4:])
        assert len(assets) == 0
        assert len(fetch) == 0


class TestAsyncActionSubstrates:
    """Mirror of AsyncActionFuseLib.sol: type << 248 | payload."""

    def test_allowed_amount_to_outside_layout(self):
        encoded = AsyncActionSubstrates.allowed_amount_to_outside(TOKEN_A, 1_000_000)
        assert len(encoded) == 32
        assert (
            int.from_bytes(encoded, "big")
            == (0 << 248) | (int(TOKEN_A, 16) << 88) | 1_000_000
        )
        # round-trip through the real decoder (offset-sensitive layout)
        info = decode_substrate(encoded, market_id=40)
        assert info.type_label == "ALLOWED_AMOUNT_TO_OUTSIDE"
        assert info.address.lower() == TOKEN_A_LOW
        assert info.extra["amount"] == "1000000"

    def test_target_layout(self):
        selector = _selector("transfer(address,uint256)")
        encoded = AsyncActionSubstrates.target(TOKEN_B, selector)
        assert len(encoded) == 32
        assert int.from_bytes(encoded, "big") == (1 << 248) | (
            int(TOKEN_B, 16) << 32
        ) | int.from_bytes(selector, "big")
        info = decode_substrate(encoded, market_id=40)
        assert info.type_label == "ALLOWED_TARGETS"
        assert info.address.lower() == TOKEN_B_LOW
        assert info.extra["selector"] == "0x" + selector.hex()

    def test_exit_slippage_layout(self):
        encoded = AsyncActionSubstrates.exit_slippage(5 * 10**16)  # 5%
        assert len(encoded) == 32
        assert int.from_bytes(encoded, "big") == (2 << 248) | (5 * 10**16)
        info = decode_substrate(encoded, market_id=40)
        assert info.type_label == "ALLOWED_EXIT_SLIPPAGE"
        assert info.extra["slippage"] == str(5 * 10**16)

    @pytest.mark.parametrize("amount", [0, (1 << 88) - 1])
    def test_amount_boundary_encodes(self, amount):
        # 0 and the uint88 max both encode and round-trip.
        encoded = AsyncActionSubstrates.allowed_amount_to_outside(TOKEN_A, amount)
        assert len(encoded) == 32
        info = decode_substrate(encoded, market_id=40)
        assert info.extra["amount"] == str(amount)

    @pytest.mark.parametrize("wad", [0, (1 << 248) - 1])
    def test_slippage_boundary_encodes(self, wad):
        # 0 and the uint248 max both encode within the field.
        encoded = AsyncActionSubstrates.exit_slippage(wad)
        assert len(encoded) == 32
        assert int.from_bytes(encoded, "big") == (2 << 248) | wad

    def test_amount_out_of_uint88_range(self):
        with pytest.raises(ValueError, match="uint88"):
            AsyncActionSubstrates.allowed_amount_to_outside(TOKEN_A, 1 << 88)
        with pytest.raises(ValueError, match="uint88"):
            AsyncActionSubstrates.allowed_amount_to_outside(TOKEN_A, -1)

    def test_slippage_out_of_range(self):
        with pytest.raises(ValueError, match="out of range"):
            AsyncActionSubstrates.exit_slippage(1 << 248)
        with pytest.raises(ValueError, match="out of range"):
            AsyncActionSubstrates.exit_slippage(-1)

    def test_target_bad_selector_length(self):
        with pytest.raises(ValueError, match="4 bytes"):
            AsyncActionSubstrates.target(TOKEN_B, b"\x01\x02\x03")  # too short
        with pytest.raises(ValueError, match="4 bytes"):
            AsyncActionSubstrates.target(TOKEN_B, b"\x01\x02\x03\x04\x05")  # too long

    def test_malformed_address(self):
        with pytest.raises(ValueError, match="20-byte"):
            AsyncActionSubstrates.allowed_amount_to_outside("0x1234", 1)  # type: ignore[arg-type]
        with pytest.raises(ValueError, match="20-byte"):
            AsyncActionSubstrates.target(
                "0x1234", _selector("transfer(address,uint256)")
            )  # type: ignore[arg-type]

    def test_zero_address_accepted(self):
        """AsyncActionFuseLib.sol has no zero-address check, so these encoders
        mirror it and accept one -- unlike the external-state and
        universal-token-swapper markets. Pinned so that harmonizing the three
        has to be a deliberate decision rather than a silent drift."""
        encoded = AsyncActionSubstrates.allowed_amount_to_outside(ZERO_ADDRESS, 1)
        assert int.from_bytes(encoded, "big") == 1  # tag 0, zero asset, amount 1

        selector = _selector("transfer(address,uint256)")
        encoded = AsyncActionSubstrates.target(ZERO_ADDRESS, selector)
        assert int.from_bytes(encoded, "big") == (1 << 248) | int.from_bytes(
            selector, "big"
        )


class TestExternalStateSubstrates:
    """Mirror of ExternalStateSubstrateLib.sol: type << 248 | payload."""

    @pytest.mark.parametrize(
        ("encoder", "tag", "label"),
        [
            (ExternalStateSubstrates.asset, 1, "ASSET"),
            (ExternalStateSubstrates.custodian, 3, "CUSTODIAN"),
            (ExternalStateSubstrates.balance_account, 4, "BALANCE_ACCOUNT"),
        ],
    )
    def test_address_substrate_layout(self, encoder, tag, label):
        encoded = encoder(TOKEN_A)
        assert len(encoded) == 32
        assert int.from_bytes(encoded, "big") == (tag << 248) | int(TOKEN_A, 16)
        info = decode_substrate(encoded, market_id=50)
        assert info.type_label == label
        assert info.address.lower() == TOKEN_A_LOW

    def test_target_layout(self):
        selector = _selector("transfer(address,uint256)")
        encoded = ExternalStateSubstrates.target(TOKEN_B, selector)
        assert len(encoded) == 32
        # The selector sits ABOVE the address here, unlike market 40's TARGET.
        assert int.from_bytes(encoded, "big") == (2 << 248) | (
            int.from_bytes(selector, "big") << 160
        ) | int(TOKEN_B, 16)
        info = decode_substrate(encoded, market_id=50)
        assert info.type_label == "TARGET"
        assert info.address.lower() == TOKEN_B_LOW
        assert info.extra["selector"] == "0x" + selector.hex()

    # Each guard decodes under its own unit key, not a shared "value".
    _SCALAR_GUARDS = [
        (ExternalStateSubstrates.staleness_max, 5, "STALENESS_MAX", "seconds"),
        (ExternalStateSubstrates.big_change_bps, 6, "BIG_CHANGE_BPS", "bps"),
        (ExternalStateSubstrates.dust_threshold, 7, "DUST_THRESHOLD", "percent"),
        (
            ExternalStateSubstrates.min_update_interval,
            8,
            "MIN_UPDATE_INTERVAL",
            "seconds",
        ),
    ]

    @pytest.mark.parametrize(("encoder", "tag", "label", "unit"), _SCALAR_GUARDS)
    def test_scalar_substrate_layout(self, encoder, tag, label, unit):
        encoded = encoder(3600)
        assert len(encoded) == 32
        assert int.from_bytes(encoded, "big") == (tag << 248) | 3600
        info = decode_substrate(encoded, market_id=50)
        assert info.type_label == label
        assert info.extra == {unit: "3600"}

    @pytest.mark.parametrize(("encoder", "tag", "label", "unit"), _SCALAR_GUARDS)
    def test_scalar_upper_boundary_encodes(self, encoder, tag, label, unit):
        # The uint248 max encodes within the payload field for every guard.
        value = (1 << 248) - 1
        encoded = encoder(value)
        assert int.from_bytes(encoded, "big") == (tag << 248) | value
        info = decode_substrate(encoded, market_id=50)
        assert info.type_label == label
        assert info.extra == {unit: str(value)}

    @pytest.mark.parametrize(
        ("encoder", "tag", "unit"),
        [
            (ExternalStateSubstrates.dust_threshold, 7, "percent"),
            (ExternalStateSubstrates.min_update_interval, 8, "seconds"),
        ],
    )
    def test_optional_guards_accept_zero(self, encoder, tag, unit):
        # Zero is meaningful for these two: no dust allowed, no minimum delay.
        encoded = encoder(0)
        assert int.from_bytes(encoded, "big") == tag << 248
        assert decode_substrate(encoded, market_id=50).extra == {unit: "0"}

    @pytest.mark.parametrize(
        "encoder",
        [ExternalStateSubstrates.staleness_max, ExternalStateSubstrates.big_change_bps],
    )
    def test_mandatory_singletons_reject_zero(self, encoder):
        # The executor's cache rebuild reads a zero singleton as unset and
        # reverts with ExternalStateMandatorySingletonMissing, so a zero grant
        # can never be part of a working configuration.
        with pytest.raises(ValueError, match="must not be zero"):
            encoder(0)

    @pytest.mark.parametrize(
        "encoder",
        [
            ExternalStateSubstrates.staleness_max,
            ExternalStateSubstrates.big_change_bps,
            ExternalStateSubstrates.dust_threshold,
            ExternalStateSubstrates.min_update_interval,
        ],
    )
    def test_scalar_out_of_range(self, encoder):
        with pytest.raises(ValueError, match="out of range"):
            encoder(1 << 248)
        with pytest.raises(ValueError, match="out of range"):
            encoder(-1)

    def test_target_bad_selector_length(self):
        with pytest.raises(ValueError, match="4 bytes"):
            ExternalStateSubstrates.target(TOKEN_B, b"\x01\x02\x03")
        with pytest.raises(ValueError, match="4 bytes"):
            ExternalStateSubstrates.target(TOKEN_B, b"\x01\x02\x03\x04\x05")

    # Every public entry point that takes an address, so a future refactor
    # special-casing one of them cannot slip past the guard tests.
    # Paired with the field name each encoder's error must carry.
    _ADDRESS_ENCODERS = [
        (ExternalStateSubstrates.asset, "asset"),
        (ExternalStateSubstrates.custodian, "custodian"),
        (ExternalStateSubstrates.balance_account, "balance_account"),
        (
            lambda address: ExternalStateSubstrates.target(
                address, _selector("transfer(address,uint256)")
            ),
            "target",
        ),
    ]
    _ADDRESS_ENCODER_IDS = ["asset", "custodian", "balance_account", "target"]

    @pytest.mark.parametrize(
        ("encoder", "field"), _ADDRESS_ENCODERS, ids=_ADDRESS_ENCODER_IDS
    )
    @pytest.mark.parametrize("spelling", [ZERO_ADDRESS, "0" * 40])
    def test_zero_address_rejected(self, encoder, field, spelling):
        # Mirrors ExternalStateErrors.ExternalStateZeroAddress on-chain. The
        # bare spelling matters: config files and CSV exports drop the 0x, and
        # a text-only guard would encode a live-looking grant for address 0.
        # Matching the field name catches an encoder wired to the wrong one.
        with pytest.raises(ValueError, match=f"{field} must not be zero address"):
            encoder(spelling)

    @pytest.mark.parametrize(
        "encoder", [e for e, _ in _ADDRESS_ENCODERS], ids=_ADDRESS_ENCODER_IDS
    )
    def test_malformed_address(self, encoder):
        # The packer raises here, and its message names the address, not the
        # field -- so there is nothing field-specific to assert.
        with pytest.raises(ValueError, match="20-byte"):
            encoder("0x1234")
