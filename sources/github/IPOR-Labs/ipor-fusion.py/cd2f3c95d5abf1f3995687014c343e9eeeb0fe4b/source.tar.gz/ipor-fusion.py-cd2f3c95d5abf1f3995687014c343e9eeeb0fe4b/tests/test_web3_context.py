# pyright: reportAttributeAccessIssue=false
"""Unit tests for Web3Context — mock Web3 calls, no network required."""

from unittest.mock import MagicMock, patch

import pytest
from hexbytes import HexBytes
from web3 import Web3
from web3.providers.rpc import HTTPProvider

from ipor_fusion.core.context import Web3Context
from ipor_fusion.core.contract import Call
from ipor_fusion.errors import TransactionError
from ipor_fusion.types import ChainId

ADDR = Web3.to_checksum_address("0x1111111111111111111111111111111111111111")
TO_ADDR = Web3.to_checksum_address("0x2222222222222222222222222222222222222222")

# A valid Ethereum private key (32 bytes, hex-encoded)
PRIVATE_KEY = "0x" + "ab" * 32


def _make_ctx(
    signer=None,
    private_key=None,
    gas_multiplier=1.25,
):
    """Build a Web3Context with a mocked Web3 instance."""
    web3 = MagicMock(spec=Web3)
    web3.eth = MagicMock()
    return Web3Context(
        web3=web3,
        chain_id=ChainId(1),
        signer=signer,
        private_key=private_key,
        gas_multiplier=gas_multiplier,
    )


# ── Constructor branches ────────────────────────────────────────────────


class TestConstructor:
    def test_signer_from_explicit_address(self):
        ctx = _make_ctx(signer=ADDR)
        assert ctx.signer == ADDR

    def test_signer_from_private_key(self):
        ctx = _make_ctx(private_key=PRIVATE_KEY)
        assert ctx.signer is not None
        # The derived address should be a valid checksum address
        assert Web3.is_checksum_address(ctx.signer)

    def test_no_signer_when_neither_provided(self):
        ctx = _make_ctx()
        assert ctx.signer is None

    def test_properties(self):
        ctx = _make_ctx(signer=ADDR)
        assert ctx.chain_id == ChainId(1)
        assert ctx.web3 is not None


# ── from_url ────────────────────────────────────────────────────────────


class TestFromUrl:
    @patch("ipor_fusion.core.context.Web3")
    def test_from_url_creates_context(self, mock_web3_cls):
        mock_provider = MagicMock()
        mock_web3_cls.HTTPProvider.return_value = mock_provider

        mock_web3_instance = MagicMock()
        mock_web3_instance.eth.chain_id = 42161
        mock_web3_cls.return_value = mock_web3_instance

        # to_checksum_address is used when private_key is set
        mock_web3_cls.to_checksum_address = Web3.to_checksum_address

        ctx = Web3Context.from_url(
            "http://localhost:8545",
            private_key=PRIVATE_KEY,
            gas_multiplier=1.5,
        )

        mock_web3_cls.HTTPProvider.assert_called_once_with(
            "http://localhost:8545",
            request_kwargs={"timeout": Web3Context.DEFAULT_RPC_TIMEOUT_S},
        )
        mock_web3_cls.assert_called_once_with(mock_provider)
        assert ctx.chain_id == ChainId(42161)
        assert ctx.signer is not None

    @patch("ipor_fusion.core.context.Web3")
    def test_from_url_without_private_key(self, mock_web3_cls):
        mock_web3_instance = MagicMock()
        mock_web3_instance.eth.chain_id = 1
        mock_web3_cls.return_value = mock_web3_instance

        ctx = Web3Context.from_url("http://localhost:8545")

        assert ctx.signer is None

    @patch("ipor_fusion.core.context.Web3")
    def test_from_url_passes_custom_request_timeout(self, mock_web3_cls):
        mock_web3_instance = MagicMock()
        mock_web3_instance.eth.chain_id = 1
        mock_web3_cls.return_value = mock_web3_instance

        Web3Context.from_url("http://localhost:8545", request_timeout_s=10.0)

        mock_web3_cls.HTTPProvider.assert_called_once_with(
            "http://localhost:8545", request_kwargs={"timeout": 10.0}
        )

    def test_reads_do_not_refetch_the_chain_id(self):
        """web3's validation middleware re-fetches eth_chainId around every
        eth_call, tripling the round trips of each read; from_url drops it."""
        methods: list[str] = []

        def make_request(_provider, method, _params):
            methods.append(method)
            result = "0x1" if method == "eth_chainId" else "0x" + "00" * 32
            return {"jsonrpc": "2.0", "id": 1, "result": result}

        with patch.object(HTTPProvider, "make_request", make_request):
            ctx = Web3Context.from_url("http://localhost:8545")
            target = Web3.to_checksum_address("0x" + "11" * 20)
            ctx.call(target, b"\x12\x34\x56\x78")
            ctx.call(target, b"\x12\x34\x56\x78")

        assert methods == ["eth_chainId", "eth_call", "eth_call"]


# ── send ────────────────────────────────────────────────────────────────


class TestSend:
    def test_send_raises_without_private_key(self):
        ctx = _make_ctx()
        with pytest.raises(ValueError, match="Private key required"):
            ctx.send(TO_ADDR, b"\x01\x02")

    def test_send_raises_with_signer_but_no_key(self):
        """Signer set explicitly but no private key — send should still fail."""
        ctx = _make_ctx(signer=ADDR)
        with pytest.raises(ValueError, match="Private key required"):
            ctx.send(TO_ADDR, b"\x01\x02")

    def test_send_success(self):
        ctx = _make_ctx(signer=ADDR, private_key=PRIVATE_KEY)
        web3 = ctx.web3

        # Mock chain of calls in send
        web3.eth.get_transaction_count.return_value = 5
        web3.eth.gas_price = 20_000_000_000
        web3.eth.get_block.return_value = {"baseFeePerGas": 15_000_000_000}
        web3.eth.estimate_gas.return_value = 21000

        signed = MagicMock()
        signed.raw_transaction = b"\xf8"
        web3.eth.account.sign_transaction.return_value = signed

        tx_hash = HexBytes(b"\xaa" * 32)
        web3.eth.send_raw_transaction.return_value = tx_hash
        web3.eth.wait_for_transaction_receipt.return_value = {"status": 1}

        receipt = ctx.send(TO_ADDR, b"\x01\x02")
        assert receipt["status"] == 1
        web3.eth.send_raw_transaction.assert_called_once_with(b"\xf8")


# ── maxFeePerGas construction ────────────────────────────────────────────


GWEI = 1_000_000_000


def _build_tx(ctx, *, gas_price, block):
    """Drive build_transaction with stubbed nonce/gas_price/block/gas."""
    web3 = ctx.web3
    web3.eth.get_transaction_count.return_value = 0
    web3.eth.gas_price = gas_price
    web3.eth.get_block.return_value = block
    web3.eth.estimate_gas.return_value = 21000
    return ctx.build_transaction(TO_ADDR, b"\x01\x02")


class TestMaxFeePerGas:
    def test_eip1559_ceiling_uses_base_fee_headroom(self):
        ctx = _make_ctx(signer=ADDR)
        tx = _build_tx(ctx, gas_price=20 * GWEI, block={"baseFeePerGas": 15 * GWEI})

        # priority = min(2 gwei default, gas_price // 10 = 2 gwei) = 2 gwei
        # ceiling = base_fee * 2 + priority
        assert tx["maxPriorityFeePerGas"] == 2 * GWEI
        assert tx["maxFeePerGas"] == 15 * GWEI * 2 + 2 * GWEI

    def test_priority_fee_folded_into_ceiling_is_capped(self):
        ctx = _make_ctx(signer=ADDR)
        # gas_price // 10 (10 gwei) exceeds the 2 gwei cap, so the priority fee
        # in the ceiling must be the cap, not the raw gas_price // 10.
        tx = _build_tx(ctx, gas_price=100 * GWEI, block={"baseFeePerGas": 15 * GWEI})

        cap = Web3Context.DEFAULT_TRANSACTION_MAX_PRIORITY_FEE
        assert tx["maxPriorityFeePerGas"] == cap
        assert tx["maxFeePerGas"] == 15 * GWEI * 2 + cap

    def test_zero_base_fee_still_takes_the_eip1559_branch(self):
        ctx = _make_ctx(signer=ADDR)
        # base_fee 0 is falsy but not None: the branch keys on `is None`, so a
        # zero base fee collapses the ceiling to just the priority fee.
        tx = _build_tx(ctx, gas_price=20 * GWEI, block={"baseFeePerGas": 0})

        assert tx["maxFeePerGas"] == tx["maxPriorityFeePerGas"]

    def test_falls_back_to_gas_price_margin_without_base_fee(self):
        ctx = _make_ctx(signer=ADDR)
        # A pre-EIP-1559 block carries no baseFeePerGas key.
        tx = _build_tx(ctx, gas_price=20 * GWEI, block={})

        assert tx["maxFeePerGas"] == 20 * GWEI + (20 * GWEI * 25 // 100)

    def test_ceiling_clears_a_base_fee_that_the_old_formula_would_miss(self):
        # Regression guard: on Arbitrum-like fees the pre-fix ceiling
        # (gas_price + 25%) fell below a base fee that ticked up before
        # broadcast; the base-fee-relative ceiling clears it.
        ctx = _make_ctx(signer=ADDR)
        gas_price = 10_000_000  # 0.01 gwei, Arbitrum floor at read time
        tx = _build_tx(ctx, gas_price=gas_price, block={"baseFeePerGas": gas_price})

        bumped_base_fee = 15_000_000  # +50% by broadcast time
        old_ceiling = gas_price + gas_price * 25 // 100
        priority = gas_price // 10  # below the 2 gwei cap at this gas price
        assert old_ceiling < bumped_base_fee  # would have been rejected
        assert tx["maxFeePerGas"] == gas_price * 2 + priority  # exact new ceiling
        assert tx["maxFeePerGas"] >= bumped_base_fee  # now clears it


# ── _handle_receipt ─────────────────────────────────────────────────────


class TestHandleReceipt:
    def test_successful_receipt_returned(self):
        ctx = _make_ctx(signer=ADDR)
        receipt = {"status": 1, "blockNumber": 100}
        result = ctx._handle_receipt(HexBytes(b"\xaa" * 32), receipt)
        assert result is receipt

    @patch("ipor_fusion.core.context.get_revert_reason")
    def test_failed_receipt_raises_transaction_error(self, mock_get_reason):
        ctx = _make_ctx(signer=ADDR)
        mock_get_reason.return_value = 'Error("Insufficient balance")'

        tx_hash = HexBytes(b"\xbb" * 32)
        receipt = {"status": 0, "blockNumber": 100}

        with pytest.raises(TransactionError) as exc_info:
            ctx._handle_receipt(tx_hash, receipt)

        assert exc_info.value.tx_hash == tx_hash.hex()
        assert exc_info.value.revert_reason == 'Error("Insufficient balance")'
        mock_get_reason.assert_called_once_with(ctx.web3, tx_hash, receipt)

    @patch("ipor_fusion.core.context.get_revert_reason")
    def test_failed_receipt_with_no_revert_reason(self, mock_get_reason):
        ctx = _make_ctx(signer=ADDR)
        mock_get_reason.return_value = None

        tx_hash = HexBytes(b"\xcc" * 32)
        receipt = {"status": 0, "blockNumber": 100}

        with pytest.raises(TransactionError):
            ctx._handle_receipt(tx_hash, receipt)


# ── send with failed receipt ────────────────────────────────────────────


class TestSendFailedReceipt:
    @patch("ipor_fusion.core.context.get_revert_reason")
    def test_send_raises_on_failed_transaction(self, mock_get_reason):
        mock_get_reason.return_value = "execution reverted"

        ctx = _make_ctx(signer=ADDR, private_key=PRIVATE_KEY)
        web3 = ctx.web3

        web3.eth.get_transaction_count.return_value = 0
        web3.eth.gas_price = 10_000_000_000
        web3.eth.get_block.return_value = {"baseFeePerGas": 8_000_000_000}
        web3.eth.estimate_gas.return_value = 21000

        signed = MagicMock()
        signed.raw_transaction = b"\xf8"
        web3.eth.account.sign_transaction.return_value = signed

        tx_hash = HexBytes(b"\xdd" * 32)
        web3.eth.send_raw_transaction.return_value = tx_hash
        web3.eth.wait_for_transaction_receipt.return_value = {
            "status": 0,
            "blockNumber": 42,
        }

        with pytest.raises(TransactionError):
            ctx.send(TO_ADDR, b"\x01")


class TestGetStorageAt:
    def test_delegates_with_default_block(self):
        ctx = _make_ctx()
        slot_value = HexBytes(b"\x00" * 31 + b"\x2a")
        ctx.web3.eth.get_storage_at.return_value = slot_value

        result = ctx.get_storage_at(ADDR, 0x1234)

        assert result == slot_value
        ctx.web3.eth.get_storage_at.assert_called_once_with(
            ADDR, 0x1234, block_identifier="latest"
        )

    def test_honors_explicit_block(self):
        ctx = _make_ctx()
        ctx.web3.eth.get_storage_at.return_value = HexBytes(b"\x00" * 32)

        ctx.get_storage_at(ADDR, 7, block=123)

        ctx.web3.eth.get_storage_at.assert_called_once_with(
            ADDR, 7, block_identifier=123
        )


# ── build_transaction / estimate_gas preview (item 4) ───────────────────────


class TestPreview:
    def test_build_transaction_returns_tx_without_sending(self):
        ctx = _make_ctx(signer=ADDR)
        web3 = ctx.web3
        web3.eth.get_transaction_count.return_value = 7
        web3.eth.gas_price = 20 * GWEI
        web3.eth.get_block.return_value = {"baseFeePerGas": 15 * GWEI}
        web3.eth.estimate_gas.return_value = 21000

        tx = ctx.build_transaction(TO_ADDR, b"\x01\x02")

        # Same dict send() would submit — including the base-fee-relative ceiling.
        assert tx["to"] == TO_ADDR
        assert tx["from"] == ADDR
        assert tx["nonce"] == 7
        assert tx["maxFeePerGas"] == 15 * GWEI * 2 + 2 * GWEI
        assert tx["gas"] == int(1.25 * 21000)
        # from/to/data reach estimate_gas intact (0x-prefixed calldata).
        web3.eth.estimate_gas.assert_called_once_with(
            {"to": TO_ADDR, "from": ADDR, "data": "0x0102"}
        )
        web3.eth.send_raw_transaction.assert_not_called()

    def test_build_transaction_requires_signer(self):
        ctx = _make_ctx()  # no signer
        with pytest.raises(ValueError, match="Signer required"):
            ctx.build_transaction(TO_ADDR, b"\x01\x02")

    def test_build_transaction_propagates_revert(self):
        # Gas estimation executes the call, so a would-revert tx raises here too.
        # The earlier fee reads need real values for the path to reach it.
        ctx = _make_ctx(signer=ADDR)
        web3 = ctx.web3
        web3.eth.get_transaction_count.return_value = 0
        web3.eth.gas_price = 20 * GWEI
        web3.eth.get_block.return_value = {"baseFeePerGas": 15 * GWEI}
        web3.eth.estimate_gas.side_effect = ValueError("execution reverted")
        with pytest.raises(ValueError, match="execution reverted"):
            ctx.build_transaction(TO_ADDR, b"\x01\x02")

    def test_estimate_gas_applies_multiplier(self):
        # A non-default multiplier proves the value is read from the ctx rather
        # than hardcoded.
        ctx = _make_ctx(signer=ADDR, gas_multiplier=2.0)
        ctx.web3.eth.estimate_gas.return_value = 21000

        assert ctx.estimate_gas(TO_ADDR, b"\x01\x02") == int(2.0 * 21000)
        ctx.web3.eth.estimate_gas.assert_called_once_with(
            {"to": TO_ADDR, "from": ADDR, "data": "0x0102"}
        )
        # The cheap path skips the nonce / base-fee reads build_transaction makes.
        ctx.web3.eth.get_transaction_count.assert_not_called()
        ctx.web3.eth.get_block.assert_not_called()
        ctx.web3.eth.send_raw_transaction.assert_not_called()

    def test_estimate_gas_requires_signer(self):
        ctx = _make_ctx()  # no signer
        with pytest.raises(ValueError, match="Signer required"):
            ctx.estimate_gas(TO_ADDR, b"\x01\x02")

    def test_estimate_gas_propagates_revert(self):
        # A would-revert tx surfaces the underlying revert rather than a number.
        ctx = _make_ctx(signer=ADDR)
        ctx.web3.eth.estimate_gas.side_effect = ValueError("execution reverted")
        with pytest.raises(ValueError, match="execution reverted"):
            ctx.estimate_gas(TO_ADDR, b"\x01\x02")


class TestCallPreviewDelegation:
    def test_estimate_gas_delegates_to_ctx(self):
        ctx = MagicMock(spec=Web3Context)
        ctx.estimate_gas.return_value = 12345
        call = Call(to=TO_ADDR, data=b"\x01\x02", ctx=ctx)

        assert call.estimate_gas() == 12345
        ctx.estimate_gas.assert_called_once_with(TO_ADDR, b"\x01\x02")

    def test_build_transaction_delegates_to_ctx(self):
        ctx = MagicMock(spec=Web3Context)
        sentinel = {"gas": 1}
        ctx.build_transaction.return_value = sentinel
        call = Call(to=TO_ADDR, data=b"\x03", ctx=ctx)

        assert call.build_transaction() is sentinel
        ctx.build_transaction.assert_called_once_with(TO_ADDR, b"\x03")
