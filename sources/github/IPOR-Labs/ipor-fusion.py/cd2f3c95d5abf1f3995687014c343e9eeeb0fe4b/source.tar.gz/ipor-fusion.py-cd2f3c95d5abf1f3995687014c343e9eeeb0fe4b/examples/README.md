# Vault examples

Canonical, runnable examples for working with IPOR Fusion vaults -- building and
configuring one from scratch, and one-shot operations on a vault (supply, withdraw,
claim, rebalance, inspect). They exist so a developer -- or a coding agent -- can
learn a real workflow from a single readable file, without reverse-engineering the
test suite.

They preview and simulate through `eth_simulateV1`; they never sign or broadcast a
transaction.

## Which example to start with

- [`simple_aave_v3_supply_base.py`](simple_aave_v3_supply_base.py) -- start
  here. Creates a vault on Base, bootstraps its roles, wires a single market
  (Aave V3 supply fuse + balance fuse), grants only the USDC substrate, verifies
  oracle coverage, deposits, and runs one alpha-driven supply.
- [`advanced_euler_v2_credit_market_base.py`](advanced_euler_v2_credit_market_base.py) --
  continue here. Composes four Euler V2 functional fuses (supply, collateral,
  controller, borrow) with the Euler balance fuse, grants two narrow typed
  substrates on one sub-account (cbETH usable as collateral, WETH as a borrow),
  and runs the full credit lifecycle: supply collateral, enable collateral and
  controller, borrow WETH, repay, then unwind (controller before collateral) and
  withdraw the collateral, reading the outstanding debt from the eVault's
  `debtOf` to confirm the position fully closed.
- [`advanced_euler_v2_looping_arbitrum.py`](advanced_euler_v2_looping_arbitrum.py) --
  builds a WBTC-denominated vault on Arbitrum and opens (but does not unwind) a
  leveraged Euler V2 position in one Morpho flash-loan callback: supply WBTC,
  borrow USDC, swap the USDC back to WBTC, and repay the flash loan. It demonstrates
  the four Euler functional fuses, typed swapper substrates and callback-handler
  configuration.
- [`external_state_margin_leg_base.py`](external_state_margin_leg_base.py) -- a
  vault whose capital leaves the chain. Wires the external-state market (50) with
  its operation and balance fuses, grants the typed substrates that market needs
  (asset, one permitted call, a balance account, two custodians, four guards),
  parks USDC at an off-chain venue through the per-vault executor, has two
  custodians propose and confirm the off-venue value so the NAV reflects it,
  brings the margin home and releases it for a user's scheduled withdrawal, then
  demonstrates the executor rejecting a confirmation that does not match its
  proposal.
- [`crosschain_ccip_usdc_arbitrum_hyperevm.py`](crosschain_ccip_usdc_arbitrum_hyperevm.py) --
  a vault whose capital works on another chain. Opens a `CrosschainLane` on a
  live Arbitrum hub vault whose executor has a dispatcher on HyperEVM, then
  drives the whole lifecycle over CCIP: supply USDC to the spoke, have a
  proposer and an approver attest the dispatcher's balance into the hub NAV,
  DEPOSIT into and REDEEM from the spoke vault by command, re-attest, recall
  the idle to the hub and claim it back into the vault. Both chains run under
  `eth_simulateV1` and `CrosschainSimulator` relays each CCIP message between
  them, so it needs an Arbitrum and a HyperEVM archive RPC.

## Prerequisites

- The `ipor-fusion` package installed (or this repo's dev environment).
- An RPC URL per chain the example uses (Base, Arbitrum, HyperEVM) from an
  **archive node that implements `eth_simulateV1`** (Alchemy and other
  geth/reth-based providers do).

## Environment variables

- `BASE_PROVIDER_URL` (required) -- your Base archive RPC endpoint. Never commit it or
  share it; it embeds your provider key.
- `ARBITRUM_PROVIDER_URL` (required by the Arbitrum and crosschain examples) --
  your Arbitrum archive RPC endpoint. Never commit it or share it.
- `HYPEREVM_PROVIDER_URL` (required by the crosschain example) -- your HyperEVM
  archive RPC endpoint. Never commit it or share it.

## Running

The shell snippets here assume a POSIX shell (bash or zsh); translate `export`
for others (`set -x VAR val` in fish, `$env:VAR = "val"` in PowerShell).

```bash
export BASE_PROVIDER_URL="https://base-mainnet.g.alchemy.com/v2/YOUR_KEY"
uv run python examples/simple_aave_v3_supply_base.py
```

The default run previews the deployment, prints the unsigned creation calldata
and an ordered transaction plan, executes the whole flow through `eth_simulateV1`
-- one batch, except where an example says otherwise -- and asserts the final
state. It signs and broadcasts nothing.

### Inspecting the calldata

Each example exposes pure builder functions (for instance
`unsigned_clone_calldata()` and `build_supply_action()`) that need no provider,
so you can import an example and inspect the exact bytes it would send. The
default run also logs the unsigned `clone(...)` creation calldata.

### Going to production

These examples only simulate; they never broadcast. To submit a flow on-chain, take
the `.calldata` each builder produces and sign it with your own signer -- a multisig,
hardware wallet, or key-management service. (`Call.send()` performs a direct send from a
configured signer, but a production deployment should not sign with a hot key.) Always
review production configuration independently before using it with real funds.

## Conventions

Every example follows a fixed set of conventions -- one-shot and simulation-only,
self-contained in a single file, with provenance-verified addresses, a deterministic
pinned block, fail-loud assertions, import-safety, and CI coverage. If you are
**writing or editing** an example, read [CONTRIBUTING.md](CONTRIBUTING.md) for the full
rules and the golden-standard structure.

## Scope

Each example is one-shot -- run it once, it performs its task and exits -- and narrow:
one coherent workflow, not a bundle of production concerns (fees, governance,
multi-market strategies). Long-running bots (loops, schedulers, watchers that poll and
act) live in
[`ipor-fusion-alpha-example`](https://github.com/IPOR-Labs/ipor-fusion-alpha-example),
not here. Always review production configuration independently before using it with
real funds. (Writing an example? The full scope rules are in
[CONTRIBUTING.md](CONTRIBUTING.md).)

## See also

- [Python SDK README](../README.md) -- install, quickstart, architecture.
- [ipor-fusion-alpha-example](https://github.com/IPOR-Labs/ipor-fusion-alpha-example) -- a runnable
  alpha-bot template for *long-running* vault operation (a loop/scheduler that watches and acts).
  One-shot actions -- including operations like withdraw or claim -- live here; a continuously
  running bot lives there.
- [IPOR deployments and ABIs](https://github.com/IPOR-Labs/ipor-abi) -- the
  source of provenance for every address used here.
- [IPOR Fusion documentation](https://docs.ipor.io/ipor-fusion/fusion-introduction)
  -- concepts referenced by the examples: access management, substrates, and the
  price oracle middleware.
