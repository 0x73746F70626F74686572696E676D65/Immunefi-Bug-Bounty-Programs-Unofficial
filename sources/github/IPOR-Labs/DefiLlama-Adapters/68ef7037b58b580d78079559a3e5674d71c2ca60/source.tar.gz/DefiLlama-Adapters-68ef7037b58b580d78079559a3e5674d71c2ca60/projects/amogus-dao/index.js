const { ohmTvl } = require("../helper/ohm")

const sus = "0x43f673dEDE1A30399E7b9b600AD78193dB00D895";
const amogusStaking = "0xc387d28A373c7683132bebaf8683F70fc6b52Aa5";
const treasury = "0xD8635772d8Fd5fc448f025Ed500e1674F67C91c7";
const treasuryTokens = [
    ["0x130966628846bfd36ff31a822705796e8cb8c18d", false], // MIM
    ["0x96a89c2bec139d518533251229ee3853fdb89430", true], // SUS-MIM JLP
]

module.exports = {
    ...ohmTvl(treasury, treasuryTokens, "avax", amogusStaking, sus, undefined, undefined, false)
}