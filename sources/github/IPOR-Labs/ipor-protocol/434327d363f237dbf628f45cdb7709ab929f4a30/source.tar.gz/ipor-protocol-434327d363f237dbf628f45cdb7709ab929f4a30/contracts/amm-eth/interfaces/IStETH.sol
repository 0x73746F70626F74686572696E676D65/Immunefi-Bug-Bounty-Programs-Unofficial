// SPDX-FileCopyrightText: 2021 Lido <info@lido.fi>
// SPDX-License-Identifier: GPL-3.0
pragma solidity 0.8.26;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";

/// @title Interface of the StETH contract.
interface IStETH is IERC20 {
    function submit(address _referral) external payable returns (uint256);
}
