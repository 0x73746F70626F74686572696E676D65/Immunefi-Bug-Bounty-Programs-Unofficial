import { Popover, PopoverDisclosure, usePopoverStore, useStoreState } from '@ariakit/react'
import { useVirtualizer } from '@tanstack/react-virtual'
import { matchSorter } from 'match-sorter'
import { useDeferredValue, useEffect, useId, useMemo, useRef, useState } from 'react'
import { Icon } from '~/components/Icon'
import type { MultiSelectOption } from '~/components/Select/types'
import { LoadingSpinner } from './LoadingSpinner'

interface AriakitVirtualizedMultiSelectProps {
	label: string
	options: ReadonlyArray<MultiSelectOption>
	selectedValues: string[]
	onChange: (values: string[]) => void
	placeholder?: string
	isLoading?: boolean
	className?: string
	maxSelections?: number
	renderIcon?: (option: MultiSelectOption) => string | null
	onSearchChange?: (value: string) => void
}

export function AriakitVirtualizedMultiSelect({
	label,
	options,
	selectedValues,
	onChange,
	placeholder = 'Select...',
	isLoading = false,
	className = '',
	maxSelections = 100,
	renderIcon,
	onSearchChange
}: AriakitVirtualizedMultiSelectProps) {
	const [search, setSearch] = useState('')
	const deferredSearch = useDeferredValue(search)
	const listRef = useRef<HTMLDivElement | null>(null)
	const popover = usePopoverStore({ placement: 'bottom-start' })
	const isPopoverOpen = useStoreState(popover, 'open')
	const disclosureId = useId()

	const filteredOptions = useMemo(() => {
		if (!deferredSearch) return options
		return matchSorter(options, deferredSearch, { keys: ['label', 'value'] })
	}, [options, deferredSearch])

	const virtualizer = useVirtualizer({
		count: filteredOptions.length,
		getScrollElement: () => listRef.current,
		estimateSize: () => 40,
		overscan: 5
	})

	useEffect(() => {
		if (!isPopoverOpen) {
			setSearch('')
		}
	}, [isPopoverOpen])

	const buttonLabel =
		selectedValues.length === 0
			? placeholder
			: selectedValues.length === 1
				? options.find((opt) => opt.value === selectedValues[0])?.label || selectedValues[0]
				: `${selectedValues.length} selected`

	const toggleValue = (value: string) => {
		if (selectedValues.includes(value)) {
			onChange(selectedValues.filter((v) => v !== value))
		} else {
			if (selectedValues.length < maxSelections) {
				onChange([...selectedValues, value])
			}
		}
	}

	const handleSearchChange = (value: string) => {
		setSearch(value)
		if (isPopoverOpen) {
			virtualizer.measure()
			if (value) {
				virtualizer.scrollToIndex(0, { align: 'start' })
			}
		}
		onSearchChange?.(value)
	}

	const clearAll = () => {
		onChange([])
		handleSearchChange('')
	}

	const isMaxReached = selectedValues.length >= maxSelections

	return (
		<div className={className}>
			<label htmlFor={disclosureId} className="mb-1 block text-[11px] font-medium pro-text2">
				{label}
				{selectedValues.length > 0 && (
					<span className="ml-1 text-xs pro-text3">
						({selectedValues.length}
						{maxSelections < 100 && `/${maxSelections}`})
					</span>
				)}
			</label>
			{isLoading ? (
				<div className="flex h-9 items-center justify-center rounded-md border border-(--form-control-border) bg-(--bg-input)">
					<LoadingSpinner size="sm" />
				</div>
			) : (
				<>
					<PopoverDisclosure
						id={disclosureId}
						store={popover}
						className="flex w-full items-center justify-between rounded-md border border-(--form-control-border) bg-(--bg-input) px-2.5 py-1.5 text-xs transition-colors hover:border-(--primary)/40 focus:border-(--primary) focus:ring-1 focus:ring-(--primary) focus:outline-hidden"
					>
						<span className={`truncate ${selectedValues.length > 0 ? 'pro-text1' : 'pro-text3'}`}>{buttonLabel}</span>
						<Icon name="chevron-down" width={12} height={12} className="ml-2 shrink-0 opacity-70" />
					</PopoverDisclosure>
					<Popover
						store={popover}
						modal={false}
						portal={true}
						flip={false}
						gutter={4}
						className="z-50 rounded-md border border-(--cards-border) bg-(--cards-bg) shadow-xl"
						style={{ width: 'var(--popover-anchor-width)' }}
					>
						<div className="p-2">
							<div className="relative mb-2">
								<Icon
									name="search"
									width={12}
									height={12}
									className="absolute top-1/2 left-2.5 -translate-y-1/2 text-(--text-tertiary)"
								/>
								<input
									value={search}
									onChange={(e) => handleSearchChange(e.target.value)}
									placeholder="Search..."
									className="w-full rounded-md border border-(--form-control-border) bg-(--bg-input) py-1.5 pr-2.5 pl-7 text-xs transition-colors focus:border-(--primary) focus:ring-1 focus:ring-(--primary) focus:outline-hidden"
								/>
							</div>
							<div
								ref={listRef}
								className="thin-scrollbar max-h-[280px] overflow-y-auto rounded-md border border-(--cards-border) bg-(--cards-bg-alt)/30"
							>
								{filteredOptions.length === 0 ? (
									<div className="px-3 py-2 text-center text-xs pro-text3">No results found.</div>
								) : (
									<div
										key={`virtual-${filteredOptions.length}`}
										style={{
											height: `${virtualizer.getTotalSize()}px`,
											width: '100%',
											position: 'relative'
										}}
									>
										{virtualizer.getVirtualItems().map((virtualRow) => {
											const option = filteredOptions[virtualRow.index]
											if (!option) return null
											const isActive = selectedValues.includes(option.value)
											const isDisabled = option.disabled || (!isActive && isMaxReached)
											const iconUrl = renderIcon ? renderIcon(option) : option.logo
											return (
												<button
													key={option.value}
													onClick={() => {
														if (!isDisabled) {
															toggleValue(option.value)
														}
													}}
													disabled={isDisabled}
													className={`flex w-full items-center justify-between rounded-md px-2.5 py-2 text-left text-xs transition-colors ${
														isDisabled
															? 'cursor-not-allowed pro-text3 opacity-50'
															: isActive
																? 'bg-(--primary)/10 font-semibold text-(--primary)'
																: 'pro-text2 hover:bg-(--cards-bg-alt) hover:pro-text1'
													}`}
													style={{
														position: 'absolute',
														top: 0,
														left: '4px',
														width: 'calc(100% - 8px)',
														height: `${virtualRow.size}px`,
														transform: `translateY(${virtualRow.start}px)`
													}}
												>
													<div className={`flex min-w-0 items-center gap-2 ${option.isChild ? 'pl-4' : ''}`}>
														{iconUrl && (
															<img
																src={iconUrl}
																alt={option.label}
																width={20}
																height={20}
																className={`h-5 w-5 shrink-0 rounded-full object-cover ring-1 ring-(--cards-border) ${
																	option.isChild ? 'opacity-70' : ''
																}`}
															/>
														)}
														<div className="flex min-w-0 flex-col gap-0.5">
															<span className={`truncate ${option.isChild ? 'text-(--text-secondary)' : ''}`}>
																{option.label}
															</span>
															{option.isChild && (
																<span className="text-[10px] leading-none text-(--text-tertiary)">Child protocol</span>
															)}
														</div>
													</div>
													{isActive && (
														<Icon name="check" width={14} height={14} className="ml-2 shrink-0 text-(--primary)" />
													)}
												</button>
											)
										})}
									</div>
								)}
							</div>
							{selectedValues.length > 0 && (
								<div className="mt-2 flex items-center justify-between rounded-md border border-(--cards-border) bg-(--cards-bg-alt)/40 px-2.5 py-2">
									<div className="flex items-center gap-2">
										<div className="flex h-5 w-5 items-center justify-center rounded-full bg-(--primary)/15">
											<Icon name="check" width={10} height={10} className="text-(--primary)" />
										</div>
										<span className="text-[11px] font-medium text-(--text-secondary)">
											{selectedValues.length} selected
										</span>
									</div>
									<button
										type="button"
										onClick={clearAll}
										className="text-[11px] font-medium text-(--text-tertiary) transition-colors hover:text-(--primary)"
									>
										Clear All
									</button>
								</div>
							)}
						</div>
					</Popover>
				</>
			)}
		</div>
	)
}
