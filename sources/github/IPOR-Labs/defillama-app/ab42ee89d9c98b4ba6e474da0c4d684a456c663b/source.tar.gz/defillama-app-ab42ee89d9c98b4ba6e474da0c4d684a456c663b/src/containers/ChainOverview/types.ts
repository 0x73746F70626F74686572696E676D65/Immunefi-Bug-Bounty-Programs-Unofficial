import type { RawRaise } from '~/containers/Raises/api.types'
import { TVL_SETTINGS } from '~/contexts/LocalStorage'
import type { IChainMetadata } from '~/utils/metadata/types'
import type { ChainChartLabels } from './constants'

export interface IChainOverviewData {
	chain: string
	metadata: IChainMetadata
	protocols: Array<IProtocol>
	tvlChart: Array<[number, number]>
	/** Pre-computed TVL values to avoid client-side iteration */
	tvlChartSummary: {
		totalValueUSD: number | null
		tvlPrevDay: number | null
		valueChange24hUSD: number | null
		change24h: number | null
	}
	extraTvlCharts: {
		staking: Record<string, number>
		borrowed: Record<string, number>
		pool2: Record<string, number>
		vesting: Record<string, number>
		offers: Record<string, number>
		doublecounted: Record<string, number>
		liquidstaking: Record<string, number>
		dcAndLsOverlap: Record<string, number>
	}
	chainTokenInfo: {
		gecko_id: string | null
		token_symbol: string | null
		current_price: string | null
		market_cap: string | null
		fully_diluted_valuation: string | null
	} | null
	stablecoins: {
		mcap: number | null
		change7dUsd: number | null
		change7d: string | null
		topToken: { symbol: string; mcap: number }
		dominance: string | null
		mcapChartData: Array<[number, number]> | null
	} | null
	chainFees: {
		total24h: number | null
		feesGenerated24h: number | null
		topProtocolsChart: Array<[string, number, string]> | null
		totalREV24h: number | null
	}
	chainRevenue: { total24h: number | null }
	chainIncentives: {
		emissions24h: number | null
		emissions7d: number | null
		emissions30d: number | null
	}
	appRevenue: { total24h: number | null }
	appFees: { total24h: number | null }
	dexs: {
		total24h: number | null
		total7d: number | null
		change_7dover7d: number | null
		dexsDominance: number | null
		chart: Array<[number, number]> | null
	}
	perps: { total24h: number | null; total7d: number | null; change_7dover7d: number | null }
	users: { activeUsers: number | null; newUsers: number | null; transactions: number | null }
	inflows: { netInflows: number | null } | null
	treasury: { tvl: number | null; tokenBreakdowns: Record<string, number> | null } | null
	chainRaises: Array<RawRaise> | null
	chainAssets: IFormattedChainAsset | null
	devMetrics: null
	nfts: { total24h: number | null }
	etfs: Array<[number, number]> | null
	allChains: Array<{ label: string; to: string }>
	unlocks: {
		chart: Array<{ date: number; total: number; breakdown: Array<{ token: string; value: number; pct: string }> }>
		total14d: number
	} | null
	tvlAndFeesOptions: Array<{ name: string; key: string }>
	charts: ChainChartLabels[]
	description: string
	keywords: string
	isDataAvailable: boolean
	datInflows: {
		chart: Array<[number, number]>
		total30d: number
	} | null
	chainStablecoins: Array<{ name: string; url: string; symbol: string | null }> | null
	entityQuestions?: string[]
}

export interface ILiteChart {
	tvl: Array<[string, number]>
	staking: Array<[string, number]>
	borrowed: Array<[string, number]>
	pool2: Array<[string, number]>
	vesting: Array<[string, number]>
	offers: Array<[string, number]>
	doublecounted: Array<[string, number]>
	liquidstaking: Array<[string, number]>
	dcAndLsOverlap: Array<[string, number]>
}

export interface ILiteProtocol {
	category: string
	tags?: Array<string>
	chains: Array<string>
	mcap: number | null
	name: string
	symbol: string
	logo: string
	url: string
	referralUrl?: string
	tvl: number
	tvlPrevDay: number
	tvlPrevWeek: number
	tvlPrevMonth: number
	chainTvls: Record<
		(typeof TVL_SETTINGS)[keyof typeof TVL_SETTINGS],
		{
			tvl: number
			tvlPrevDay: number
			tvlPrevWeek: number
			tvlPrevMonth: number
		}
	>
	defillamaId: string
	governanceID?: Array<string>
	geckoId?: string
	parentProtocol?: string
	oracles?: Array<string>
	oraclesByChain?: Record<string, Array<string>>
	forkedFrom?: Array<string>
	listedAt?: number
	deprecated?: boolean
}

export interface ILiteParentProtocol {
	id: string
	name: string
	url: string
	description: string
	logo: string
	chains: Array<string>
	gecko_id: string
	cmcId: string
	treasury: string
	twitter: string
	governanceID: Array<string>
	wrongLiquidity: boolean
	github: Array<string>
	mcap: number
}

export type TVL_TYPES = (typeof TVL_SETTINGS)[keyof typeof TVL_SETTINGS] | 'default' | 'excludeParent'

export interface IChildProtocol {
	name: string
	slug: string
	category: string | null
	tvl: Record<TVL_TYPES, { tvl: number; tvlPrevDay: number; tvlPrevWeek: number; tvlPrevMonth: number }> | null
	tvlChange: { change1d: number | null; change7d: number | null; change1m: number | null } | null
	chains: Array<string>
	mcap: number | null
	mcaptvl: number | null
	strikeTvl: boolean
	fees?: {
		total24h: number | null
		total7d: number | null
		total30d: number | null
		total1y: number | null
		monthlyAverage1y: number | null
		totalAllTime: number | null
		pf: number | null
	}
	revenue?: {
		total24h: number | null
		total7d: number | null
		total30d: number | null
		total1y: number | null
		monthlyAverage1y: number | null
		totalAllTime: number | null
		ps: number | null
	}
	holdersRevenue?: {
		total24h: number | null
		total7d: number | null
		total30d: number | null
		total1y: number | null
		monthlyAverage1y: number | null
		totalAllTime: number | null
	}
	dexs?: {
		total24h: number | null
		total7d: number | null
		totalAllTime: number | null
		change_7dover7d: number | null
	}
	emissions?: {
		total24h: number | null
		total7d: number | null
		total30d: number | null
		total1y: number | null
		monthlyAverage1y: number | null
		totalAllTime: number | null
	}
	deprecated?: boolean
}

export interface IProtocol extends IChildProtocol {
	childProtocols?: Array<IChildProtocol>
}

export interface IFormattedChainAsset {
	canonical?: {
		total: number
		breakdown: Record<string, number>
	}
	ownTokens?: {
		total: number
		breakdown: Record<string, number>
	}
	native?: {
		total: number
		breakdown: Record<string, number>
	}
	thirdParty?: {
		total: number
		breakdown: Record<string, number>
	}
	total: {
		total: number
		breakdown: Record<string, number>
	}
}
