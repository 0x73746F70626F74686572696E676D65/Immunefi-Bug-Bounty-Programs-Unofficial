import { useRouter } from 'next/router'
import { useMemo } from 'react'
import { Icon } from '~/components/Icon'
import { BasicLink } from '~/components/Link'
import { LoadingSkeleton } from '~/components/LoadingSkeleton'
import { Select } from '~/components/Select/Select'
import { pushShallowQuery } from '~/utils/routerQuery'
import { useDashboardDiscovery } from '../hooks/useDashboardDiscovery'
import { DashboardBrowse } from './DashboardBrowse'
import { DashboardCard } from './DashboardCard'
import { DashboardSearch } from './DashboardSearch'

const SUGGESTED_TAGS = ['DeFi', 'NFT', 'Analytics', 'DEX', 'Lending', 'L2']

const viewModes = ['grid', 'list'] as const
type ViewMode = (typeof viewModes)[number]
const DEFAULT_PAGE_LIMIT = 20
const itemsPerPageOptions = [
	{ key: '20', name: '20' },
	{ key: '40', name: '40' },
	{ key: '100', name: '100' }
] as const
const sortOptions = [
	{ key: 'popular', name: 'Most Popular' },
	{ key: 'recent', name: 'Recently Created' },
	{ key: 'likes', name: 'Most Liked' },
	{ key: 'trending', name: 'Trending' }
] as const
type SortOption = (typeof sortOptions)[number]
const timeFrameOptions = [
	{ key: '1d', name: 'Last 24 hours' },
	{ key: '7d', name: 'Last 7 days' },
	{ key: '30d', name: 'Last 30 days' }
] as const
type TimeFrameOption = (typeof timeFrameOptions)[number]

export function DashboardDiscovery() {
	const router = useRouter()
	const { view, tag, sortBy, query, page, limit, timeFrame } = router.query
	const pushProQuery = (updates: Record<string, string | number | string[] | undefined>) =>
		pushShallowQuery(router, updates, '/pro')

	const {
		isBrowseMode,
		viewMode,
		selectedTags,
		selectedSortBy,
		selectedTimeFrame,
		searchQuery,
		selectedPage,
		itemsPerPage
	} = useMemo(() => {
		const viewMode = typeof view === 'string' && viewModes.includes(view as ViewMode) ? (view as ViewMode) : 'grid'
		const selectedTags = tag ? (typeof tag === 'string' ? [tag] : tag) : []
		const selectedSortBy =
			typeof sortBy === 'string'
				? (sortOptions.find((option) => option.key === sortBy) ?? sortOptions[0])
				: sortOptions[0]
		const selectedTimeFrame =
			typeof timeFrame === 'string'
				? (timeFrameOptions.find((option) => option.key === timeFrame) ?? timeFrameOptions[1])
				: timeFrameOptions[1]
		const searchQuery = typeof query === 'string' ? query : ''
		const selectedPage = typeof page === 'string' && !Number.isNaN(Number(page)) ? parseInt(page) : 1

		let itemsPerPage = DEFAULT_PAGE_LIMIT
		if (typeof limit === 'string' && !Number.isNaN(Number(limit))) {
			const parsed = parseInt(limit, 10)
			if (itemsPerPageOptions.some((option) => option.key === parsed.toString())) {
				itemsPerPage = parsed
			}
		}

		const isBrowseMode = !query && !tag && !sortBy && !page

		return {
			isBrowseMode,
			viewMode,
			selectedTags,
			selectedSortBy,
			selectedTimeFrame,
			searchQuery,
			selectedPage,
			itemsPerPage
		}
	}, [view, tag, sortBy, query, page, limit, timeFrame])

	const { dashboards, isLoading, totalPages, totalItems } = useDashboardDiscovery({
		query: searchQuery,
		tags: selectedTags,
		visibility: 'public',
		sortBy: selectedSortBy.key as 'popular' | 'recent' | 'likes' | 'trending',
		timeFrame: selectedSortBy.key === 'trending' ? (selectedTimeFrame.key as '1d' | '7d' | '30d') : undefined,
		page: selectedPage,
		limit: itemsPerPage
	})

	const handleTagClick = (tag: string) => {
		if (router.query.tag && router.query.tag.includes(tag)) {
			return
		}

		// remove page from query
		const { tag: currentTag } = router.query

		const existingTags = currentTag ? (Array.isArray(currentTag) ? currentTag : [currentTag]) : []

		pushProQuery({
			page: undefined,
			tag: [...existingTags, tag]
		})
	}

	const handleItemsPerPageChange = (value: string) => {
		const newItemsPerPage = parseInt(value, 10)
		pushProQuery({ page: undefined, limit: newItemsPerPage })
	}

	const pagesToShow = useMemo(() => {
		let pages: number[]
		if (selectedPage === 1) {
			pages = [1, 2, 3]
		} else if (selectedPage === totalPages) {
			pages = [totalPages - 2, totalPages - 1, totalPages]
		} else {
			pages = [selectedPage - 1, selectedPage, selectedPage + 1]
		}
		return pages.filter((page) => page > 0 && page <= totalPages)
	}, [totalPages, selectedPage])

	const toPageQueryValue = (targetPage: number) => (targetPage === 1 ? undefined : targetPage)

	return (
		<>
			<div className="flex flex-col gap-1">
				{!isBrowseMode && (
					<nav className="flex items-center gap-1 text-sm">
						<button
							onClick={() => {
								router.push(
									{
										pathname: '/pro',
										query: { tab: 'discover' }
									},
									undefined,
									{ shallow: true }
								)
							}}
							className="text-(--old-blue) hover:underline"
						>
							Discover
						</button>
						<Icon name="chevron-right" height={14} width={14} className="text-(--text-label)" />
						<span className="text-(--text-label)">
							{selectedSortBy.name}
							{selectedSortBy.key === 'trending' ? ` (${selectedTimeFrame.name})` : ''}
						</span>
					</nav>
				)}

				<div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
					<DashboardSearch defaultValue={searchQuery} />

					{!isBrowseMode && (
						<div className="ml-auto flex flex-wrap items-center gap-4">
							<Select
								allValues={itemsPerPageOptions}
								selectedValues={itemsPerPage.toString()}
								setSelectedValues={handleItemsPerPageChange}
								label={
									<>
										<span className="text-(--text-label)">Items per page:</span>
										<span className="overflow-hidden text-ellipsis whitespace-nowrap">{itemsPerPage}</span>
									</>
								}
								labelType="none"
								triggerProps={{
									className:
										'flex items-center justify-between gap-1 rounded-md border border-(--form-control-border) px-2 py-1.5'
								}}
								aria-label="Items per page"
							/>
							<Select
								allValues={sortOptions}
								selectedValues={selectedSortBy.key}
								setSelectedValues={(value) => {
									const updates: Record<string, string | number | string[] | undefined> = {
										page: undefined,
										sortBy: value as SortOption['key']
									}
									if (value === 'trending') {
										updates.timeFrame = '7d'
									}
									pushProQuery(updates)
								}}
								label={
									<>
										<span className="text-(--text-label)">Sort by:</span>
										<span className="overflow-hidden text-ellipsis whitespace-nowrap">{selectedSortBy.name}</span>
									</>
								}
								labelType="none"
								triggerProps={{
									className:
										'flex items-center justify-between gap-1 rounded-md border border-(--form-control-border) px-2 py-1.5'
								}}
								aria-label="Sort by"
							/>
							{selectedSortBy.key === 'trending' && (
								<Select
									allValues={timeFrameOptions}
									selectedValues={selectedTimeFrame.key}
									setSelectedValues={(value) => {
										pushProQuery({
											page: undefined,
											timeFrame: value as TimeFrameOption['key']
										})
									}}
									label={
										<>
											<span className="text-(--text-label)">Time:</span>
											<span className="overflow-hidden text-ellipsis whitespace-nowrap">{selectedTimeFrame.name}</span>
										</>
									}
									labelType="none"
									triggerProps={{
										className:
											'flex items-center justify-between gap-1 rounded-md border border-(--form-control-border) px-2 py-1.5'
									}}
									aria-label="Time frame"
								/>
							)}

							<div className="flex items-center rounded-md border border-(--form-control-border) bg-(--cards-bg)">
								<button
									onClick={() => {
										pushProQuery({ view: 'grid' })
									}}
									data-active={viewMode === 'grid'}
									className="rounded-l-md border-r border-(--form-control-border) p-2 text-(--text-label) transition-colors duration-150 data-[active=false]:hover:bg-(--bg-hover) data-[active=true]:bg-(--old-blue) data-[active=true]:text-white"
								>
									<Icon name="layout-grid" height={16} width={16} />
									<span className="sr-only">View as grid</span>
								</button>
								<button
									onClick={() => {
										pushProQuery({ view: 'list' })
									}}
									data-active={viewMode === 'list'}
									className="rounded-r-md p-2 text-(--text-label) transition-colors duration-150 data-[active=false]:hover:bg-(--bg-hover) data-[active=true]:bg-(--old-blue) data-[active=true]:text-white"
								>
									<Icon name="menu" height={16} width={16} />
									<span className="sr-only">View as list</span>
								</button>
							</div>
						</div>
					)}
				</div>

				{selectedTags.length > 0 && (
					<div className="mt-2 flex items-center gap-3 text-xs">
						<h2 className="font-medium text-(--text-label)">Active filters:</h2>
						<div className="flex flex-wrap gap-2">
							{selectedTags.map((tag) => (
								<button
									key={`pro-dashboard-tag-${tag}`}
									onClick={() => {
										const { tag: currentTag } = router.query
										let nextTag: string[] | undefined
										if (Array.isArray(currentTag)) {
											const filteredTags = currentTag.filter((t) => t !== tag)
											nextTag = filteredTags.length > 0 ? filteredTags : undefined
										} else if (currentTag === tag) {
											nextTag = undefined
										} else {
											return
										}
										pushProQuery({ tag: nextTag })
									}}
									className="flex items-center gap-1.5 rounded-full bg-(--old-blue)/15 px-2.5 py-1 text-xs font-medium text-(--old-blue) transition-all duration-150 hover:scale-105 hover:bg-(--old-blue) hover:text-white"
								>
									<span>{tag}</span>
									<Icon name="x" height={12} width={12} />
									<span className="sr-only">Remove {tag} filter</span>
								</button>
							))}
						</div>
						<button
							onClick={() => {
								pushProQuery({ tag: undefined })
							}}
							className="font-medium text-(--text-label) underline-offset-2 transition-colors hover:text-(--error) hover:underline"
						>
							Clear all
						</button>
					</div>
				)}
			</div>

			{isBrowseMode ? (
				<DashboardBrowse onTagClick={handleTagClick} />
			) : isLoading ? (
				<>
					<p className="-mb-2 text-xs text-(--text-label)">Loading dashboards…</p>
					<LoadingSkeleton viewMode={viewMode} items={DEFAULT_PAGE_LIMIT} />
				</>
			) : dashboards.length === 0 ? (
				<div className="flex flex-1 flex-col items-center justify-center gap-4 rounded-lg border border-(--cards-border) bg-(--cards-bg) px-6 py-16">
					<div className="flex h-20 w-20 items-center justify-center rounded-full bg-(--bg-hover)">
						<Icon name="search" height={40} width={40} className="text-(--text-label)" />
					</div>

					<div className="flex flex-col items-center gap-1.5">
						<h1 className="text-center text-2xl font-bold">No Dashboards Found</h1>
						<p className="max-w-md text-center text-(--text-label)">
							{searchQuery || selectedTags.length > 0
								? "We couldn't find any dashboards matching your search. Try different keywords or explore popular tags below."
								: 'Be the first to share a public dashboard with the community!'}
						</p>
					</div>

					{(searchQuery || selectedTags.length > 0) && (
						<div className="flex flex-col items-center gap-3">
							<p className="text-sm font-medium text-(--text-label)">Try these popular tags:</p>
							<div className="flex flex-wrap justify-center gap-2">
								{SUGGESTED_TAGS.map((tag) => (
									<button
										key={tag}
										onClick={() => handleTagClick(tag)}
										className="rounded-full border border-(--switch-border) bg-(--cards-bg) px-3 py-1.5 text-sm font-medium text-(--text-form) transition-all duration-150 hover:scale-105 hover:border-transparent hover:bg-(--link-active-bg) hover:text-white"
									>
										{tag}
									</button>
								))}
							</div>
						</div>
					)}

					<div className="mt-2 flex items-center gap-3">
						<div className="h-px w-12 bg-(--cards-border)" />
						<span className="text-xs text-(--text-label)">or</span>
						<div className="h-px w-12 bg-(--cards-border)" />
					</div>

					<BasicLink
						href="/pro?tab=dashboard"
						className="flex items-center gap-2 rounded-md bg-(--old-blue) px-4 py-2.5 text-sm font-semibold text-white transition-opacity hover:opacity-90"
					>
						<Icon name="plus" height={16} width={16} />
						Create Your First Dashboard
					</BasicLink>
				</div>
			) : (
				<>
					<p className="-mb-2 text-xs text-(--text-label)">
						Showing {dashboards.length} of {totalItems} dashboards
					</p>

					<div
						className={
							viewMode === 'grid' ? 'grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4' : 'space-y-4'
						}
					>
						{dashboards.map((dashboard) => (
							<DashboardCard key={dashboard.id} dashboard={dashboard} onTagClick={handleTagClick} viewMode={viewMode} />
						))}
					</div>

					{totalPages > 1 && (
						<div className="flex flex-col items-center gap-4">
							<div className="flex flex-nowrap items-center justify-center gap-2 overflow-x-auto">
								<button
									onClick={() => {
										const targetPage = 1
										pushProQuery({ page: toPageQueryValue(targetPage) })
									}}
									disabled={selectedPage < 3}
									className="h-[32px] min-w-[32px] rounded-md px-2 py-1.5 text-(--text-label) transition-colors hover:bg-(--btn-bg) disabled:hidden"
								>
									<Icon name="chevrons-left" height={16} width={16} />
								</button>
								<button
									onClick={() => {
										const targetPage = Math.max(1, selectedPage - 1)
										pushProQuery({ page: toPageQueryValue(targetPage) })
									}}
									disabled={selectedPage === 1}
									className="h-[32px] min-w-[32px] rounded-md px-2 py-1.5 text-(--text-label) transition-colors hover:bg-(--btn-bg) disabled:hidden"
								>
									<Icon name="chevron-left" height={16} width={16} />
								</button>
								{pagesToShow.map((pageNum) => {
									const isActive = selectedPage === pageNum
									return (
										<button
											key={`page-to-navigate-to-${pageNum}`}
											onClick={() => {
												const targetPage = pageNum
												pushProQuery({ page: toPageQueryValue(targetPage) })
											}}
											data-active={isActive}
											className="h-[32px] min-w-[32px] shrink-0 rounded-md px-2 py-1.5 transition-colors hover:bg-(--btn-bg) data-[active=true]:bg-(--old-blue) data-[active=true]:text-white"
										>
											{pageNum}
										</button>
									)
								})}
								<button
									onClick={() => {
										const targetPage = Math.min(totalPages, selectedPage + 1)
										pushProQuery({ page: toPageQueryValue(targetPage) })
									}}
									disabled={selectedPage === totalPages}
									className="h-[32px] min-w-[32px] rounded-md px-2 py-1.5 text-(--text-label) transition-colors hover:bg-(--btn-bg) disabled:hidden"
								>
									<Icon name="chevron-right" height={16} width={16} />
								</button>
								<button
									onClick={() => {
										const targetPage = totalPages
										pushProQuery({ page: toPageQueryValue(targetPage) })
									}}
									disabled={selectedPage > totalPages - 2}
									className="h-[32px] min-w-[32px] rounded-md px-2 py-1.5 text-(--text-label) transition-colors hover:bg-(--btn-bg) disabled:hidden"
								>
									<Icon name="chevrons-right" height={16} width={16} />
								</button>
							</div>
							<p className="text-xs text-(--text-label)">
								Page {selectedPage} of {totalPages}
							</p>
						</div>
					)}
				</>
			)}
		</>
	)
}
