import { useQuery } from '@tanstack/react-query'
import { lazy, Suspense, useMemo } from 'react'
import type { IBarChartProps, IChartProps, IPieChartProps } from '~/components/ECharts/types'
import { Icon } from '~/components/Icon'
import { LocalLoader } from '~/components/Loaders'
import { Tooltip } from '~/components/Tooltip'
const dashboardBlue = '#326abd'
import {
	formatProtocolV1TvlsByChain,
	useFetchProtocolV1AddlChartsData
} from '~/containers/ProtocolOverview/protocolV1AddlChartsData'
import { useLocalStorageSettingsManager } from '~/contexts/LocalStorage'
import ProtocolCharts from '../../services/ProtocolCharts'
import { AriakitSelect } from '../AriakitSelect'
import { AriakitVirtualizedSelect, type VirtualizedSelectOption } from '../AriakitVirtualizedSelect'

const AreaChart = lazy(() => import('~/components/ECharts/AreaChart')) as React.FC<IChartProps>
const BarChart = lazy(() => import('~/components/ECharts/BarChart')) as React.FC<IBarChartProps>
const PieChart = lazy(() => import('~/components/ECharts/PieChart')) as React.FC<IPieChartProps>

interface AdvancedTvlChartTabProps {
	selectedAdvancedTvlProtocol: string | null
	selectedAdvancedTvlProtocolName: string | null
	selectedAdvancedTvlChartType: string
	onSelectedAdvancedTvlProtocolChange: (protocol: string | null) => void
	onSelectedAdvancedTvlProtocolNameChange: (name: string | null) => void
	onSelectedAdvancedTvlChartTypeChange: (chartType: string) => void
	protocolOptions: VirtualizedSelectOption[]
	protocolsLoading: boolean
}

const ADVANCED_TVL_CHART_TYPES = [
	{ value: 'tvl', label: 'TVL' },
	{ value: 'chainsTvl', label: 'TVL by Chains' },
	{ value: 'tokenValuesUsd', label: 'Token Values (USD)' },
	{ value: 'tokensPie', label: 'Tokens Breakdown' },
	{ value: 'tokenBalances', label: 'Token Balances (Raw)' },
	{ value: 'usdInflows', label: 'USD Inflows' },
	{ value: 'tokenInflows', label: 'Inflows by Token' }
]

const chartOptions = {
	grid: {
		left: 12,
		bottom: 68,
		top: 12,
		right: 12,
		outerBoundsMode: 'same',
		outerBoundsContain: 'axisLabel'
	}
}

const inflowsChartOptions = {
	overrides: {
		inflow: true
	}
}

const TVL_STACKS = ['TVL']
const EMPTY_HALLMARKS: [number, string][] = []
const EMPTY_CHART_DATA: any[] = []
const EMPTY_STACKS: string[] = []
const EMPTY_ADDL_DATA: {
	tokensUnique?: string[]
	tokenBreakdownUSD?: any[]
	tokenBreakdownPieChart?: any[]
	tokenBreakdown?: any[]
	usdInflows?: any[]
	tokenInflows?: any[]
} = {}

export function AdvancedTvlChartTab({
	selectedAdvancedTvlProtocol,
	selectedAdvancedTvlProtocolName,
	selectedAdvancedTvlChartType,
	onSelectedAdvancedTvlProtocolChange,
	onSelectedAdvancedTvlProtocolNameChange,
	onSelectedAdvancedTvlChartTypeChange,
	protocolOptions,
	protocolsLoading
}: AdvancedTvlChartTabProps) {
	const [extraTvlsEnabled] = useLocalStorageSettingsManager('tvl_fees')
	const filteredProtocolOptions = protocolOptions

	const { data: basicTvlData, isLoading: isBasicTvlLoading } = useQuery({
		queryKey: ['pro-dashboard', 'advanced-tvl-preview-basic', selectedAdvancedTvlProtocol],
		queryFn: () => ProtocolCharts.tvl(selectedAdvancedTvlProtocol!),
		enabled: !!selectedAdvancedTvlProtocol && selectedAdvancedTvlChartType === 'tvl',
		staleTime: 60 * 60 * 1000
	})

	const {
		data: addlData,
		historicalChainTvls,
		isLoading: isAddlLoading
	} = useFetchProtocolV1AddlChartsData(selectedAdvancedTvlProtocol || '')

	const { chainsSplit, chainsUnique } = useMemo(() => {
		if (!historicalChainTvls) return { chainsSplit: null, chainsUnique: [] }
		const chainsSplit = formatProtocolV1TvlsByChain({ historicalChainTvls, extraTvlsEnabled })
		const lastEntry = chainsSplit[chainsSplit.length - 1] ?? {}
		const chainsUnique: string[] = []
		for (const key in lastEntry) {
			if (!Object.prototype.hasOwnProperty.call(lastEntry, key)) continue
			if (key !== 'date') chainsUnique.push(key)
		}
		return { chainsSplit, chainsUnique }
	}, [historicalChainTvls, extraTvlsEnabled])

	const { tokensUnique, tokenBreakdownUSD, tokenBreakdownPieChart, tokenBreakdown, usdInflows, tokenInflows } =
		addlData ?? EMPTY_ADDL_DATA
	const resolvedTokensUnique = tokensUnique ?? EMPTY_STACKS
	const resolvedTokenBreakdownUSD = tokenBreakdownUSD ?? EMPTY_CHART_DATA
	const resolvedTokenBreakdownPieChart = tokenBreakdownPieChart ?? EMPTY_CHART_DATA
	const resolvedTokenBreakdown = tokenBreakdown ?? EMPTY_CHART_DATA
	const resolvedUsdInflows = usdInflows ?? EMPTY_CHART_DATA
	const resolvedTokenInflows = tokenInflows ?? EMPTY_CHART_DATA
	const resolvedChainsSplit = chainsSplit ?? EMPTY_CHART_DATA

	const availableChartTypes = useMemo(() => {
		const available = new Set<string>(['tvl'])

		if (chainsSplit && chainsUnique?.length > 1) {
			available.add('chainsTvl')
		}
		if (tokenBreakdownUSD?.length > 1 && tokensUnique?.length > 0) {
			available.add('tokenValuesUsd')
		}
		if (tokenBreakdownPieChart?.length > 0) {
			available.add('tokensPie')
		}
		if (tokenBreakdown?.length > 1 && tokensUnique?.length > 0) {
			available.add('tokenBalances')
		}
		if (usdInflows?.length > 0) {
			available.add('usdInflows')
		}
		if (tokenInflows?.length > 0 && tokensUnique?.length > 0) {
			available.add('tokenInflows')
		}

		return available
	}, [
		chainsSplit,
		chainsUnique,
		tokenBreakdownUSD,
		tokenBreakdownPieChart,
		tokenBreakdown,
		tokensUnique,
		usdInflows,
		tokenInflows
	])

	const chartTypeOptions = useMemo(() => {
		return ADVANCED_TVL_CHART_TYPES.map((type) => ({
			...type,
			disabled: !availableChartTypes.has(type.value)
		}))
	}, [availableChartTypes])

	const isLoading = selectedAdvancedTvlChartType === 'tvl' ? isBasicTvlLoading : isAddlLoading

	const handleProtocolChange = (option: VirtualizedSelectOption) => {
		onSelectedAdvancedTvlProtocolChange(option.value)
		onSelectedAdvancedTvlProtocolNameChange(option.label)
		onSelectedAdvancedTvlChartTypeChange('tvl')
	}

	const chartTypeLabel = ADVANCED_TVL_CHART_TYPES.find((t) => t.value === selectedAdvancedTvlChartType)?.label || ''

	const chartContent = (() => {
		if (isLoading) {
			return (
				<div className="flex h-[320px] items-center justify-center">
					<LocalLoader />
				</div>
			)
		}

		switch (selectedAdvancedTvlChartType) {
			case 'tvl': {
				const tvlData = basicTvlData ? basicTvlData.map(([ts, val]) => ({ date: ts, TVL: val })) : EMPTY_CHART_DATA
				return (
					<Suspense
						fallback={
							<div className="flex h-[320px] items-center justify-center">
								<LocalLoader />
							</div>
						}
					>
						<AreaChart
							title=""
							chartData={tvlData}
							stacks={TVL_STACKS}
							valueSymbol="$"
							hideDefaultLegend={true}
							hallmarks={EMPTY_HALLMARKS}
							color={dashboardBlue}
							chartOptions={chartOptions}
						/>
					</Suspense>
				)
			}
			case 'chainsTvl':
				return (
					<Suspense
						fallback={
							<div className="flex h-[320px] items-center justify-center">
								<LocalLoader />
							</div>
						}
					>
						<AreaChart
							title=""
							chartData={resolvedChainsSplit}
							stacks={chainsUnique}
							valueSymbol="$"
							hideDefaultLegend={true}
							hideGradient={true}
							chartOptions={chartOptions}
						/>
					</Suspense>
				)
			case 'tokenValuesUsd':
				return (
					<Suspense
						fallback={
							<div className="flex h-[320px] items-center justify-center">
								<LocalLoader />
							</div>
						}
					>
						<AreaChart
							title=""
							chartData={resolvedTokenBreakdownUSD}
							stacks={resolvedTokensUnique}
							valueSymbol="$"
							hideDefaultLegend={true}
							hideGradient={true}
							chartOptions={chartOptions}
						/>
					</Suspense>
				)
			case 'tokensPie':
				return (
					<Suspense
						fallback={
							<div className="flex h-[320px] items-center justify-center">
								<LocalLoader />
							</div>
						}
					>
						<PieChart chartData={resolvedTokenBreakdownPieChart} />
					</Suspense>
				)
			case 'tokenBalances':
				return (
					<Suspense
						fallback={
							<div className="flex h-[320px] items-center justify-center">
								<LocalLoader />
							</div>
						}
					>
						<AreaChart
							title=""
							chartData={resolvedTokenBreakdown}
							stacks={resolvedTokensUnique}
							hideDefaultLegend={true}
							hideGradient={true}
							chartOptions={chartOptions}
						/>
					</Suspense>
				)
			case 'usdInflows':
				return (
					<Suspense
						fallback={
							<div className="flex h-[320px] items-center justify-center">
								<LocalLoader />
							</div>
						}
					>
						<BarChart
							chartData={resolvedUsdInflows}
							color={dashboardBlue}
							title=""
							chartOptions={inflowsChartOptions}
						/>
					</Suspense>
				)
			case 'tokenInflows':
				return (
					<Suspense
						fallback={
							<div className="flex h-[320px] items-center justify-center">
								<LocalLoader />
							</div>
						}
					>
						<BarChart
							chartData={resolvedTokenInflows}
							title=""
							hideDefaultLegend={true}
							customLegendName="Token"
							customLegendOptions={resolvedTokensUnique}
							chartOptions={inflowsChartOptions}
						/>
					</Suspense>
				)
			default:
				return null
		}
	})()

	const hasProtocolSelection = selectedAdvancedTvlProtocol && selectedAdvancedTvlProtocolName

	return (
		<div className="flex flex-col gap-4">
			<div className="space-y-3">
				<AriakitVirtualizedSelect
					label="Protocol"
					options={filteredProtocolOptions}
					selectedValue={selectedAdvancedTvlProtocol || ''}
					onChange={handleProtocolChange}
					placeholder="Select protocol..."
					isLoading={protocolsLoading}
				/>

				<Tooltip content={!hasProtocolSelection ? 'Select protocol first' : null} className="w-full">
					<div className={`w-full ${!hasProtocolSelection ? 'pointer-events-none opacity-50' : ''}`}>
						<AriakitSelect
							label="Chart Type"
							options={chartTypeOptions}
							selectedValue={selectedAdvancedTvlChartType}
							onChange={(option) => onSelectedAdvancedTvlChartTypeChange(option.value)}
							placeholder="Select chart type..."
						/>
					</div>
				</Tooltip>

				{hasProtocolSelection && isAddlLoading && (
					<div className="text-xs pro-text3">Loading available chart types...</div>
				)}

				{hasProtocolSelection && !isAddlLoading && (
					<div className="text-xs pro-text3">
						<p>
							Available charts: <span className="font-semibold pro-text1">{availableChartTypes.size}</span>
						</p>
					</div>
				)}
			</div>

			<div className="overflow-hidden rounded-lg border pro-border">
				<div className="border-b border-(--cards-border) px-3 py-2 text-xs font-medium pro-text2">Preview</div>

				{hasProtocolSelection ? (
					<div className="bg-(--cards-bg) p-3">
						<div className="mb-3">
							<h3 className="mb-1 text-sm font-semibold pro-text1">
								{selectedAdvancedTvlProtocolName} - {chartTypeLabel}
							</h3>
							<p className="text-xs pro-text2">Advanced TVL Chart</p>
						</div>

						<div className="h-[320px]">{chartContent}</div>
					</div>
				) : (
					<div className="flex h-[320px] items-center justify-center text-center pro-text3">
						<div>
							<Icon name="trending-up" height={32} width={32} className="mx-auto mb-1" />
							<div className="text-xs">Select a protocol to see available TVL charts</div>
						</div>
					</div>
				)}
			</div>
		</div>
	)
}
