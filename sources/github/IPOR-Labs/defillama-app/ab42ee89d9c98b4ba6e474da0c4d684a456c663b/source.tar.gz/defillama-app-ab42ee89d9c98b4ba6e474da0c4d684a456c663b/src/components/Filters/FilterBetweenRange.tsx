import * as Ariakit from '@ariakit/react'
import clsx from 'clsx'
import type { InputHTMLAttributes, ReactNode } from 'react'
import { Icon } from '~/components/Icon'
import { NestedMenu } from '~/components/NestedMenu'
import type { FormSubmitHandler } from '~/types/forms'

interface IFilterBetweenRange {
	name: string
	trigger: ReactNode
	onSubmit: FormSubmitHandler
	onClear: () => void
	nestedMenu?: boolean
	min: number | string | null
	max: number | string | null
	variant?: 'primary' | 'secondary'
	triggerClassName?: string
	placement?: Ariakit.PopoverStoreProps['placement']
	minLabel?: string
	maxLabel?: string
	minInputProps?: InputHTMLAttributes<HTMLInputElement>
	maxInputProps?: InputHTMLAttributes<HTMLInputElement>
}

const baseClasses = 'flex items-center justify-between gap-2 py-1.5 text-xs rounded-md cursor-pointer flex-nowrap'

const variantClasses = {
	primary:
		'px-2 relative border border-(--form-control-border) text-(--text-form) hover:bg-(--link-hover-bg) focus-visible:bg-(--link-hover-bg) font-medium',
	secondary: 'px-3 bg-(--btn-bg) hover:bg-(--btn-hover-bg) focus-visible:bg-(--btn-hover-bg) text-(--text-primary)'
} as const

export function FilterBetweenRange({
	name: _name,
	trigger,
	onSubmit: handleSubmit,
	onClear,
	nestedMenu,
	min,
	max,
	variant = 'primary',
	triggerClassName,
	placement = 'bottom-end',
	minLabel = 'Min',
	maxLabel = 'Max',
	minInputProps,
	maxInputProps
}: IFilterBetweenRange) {
	const popover = Ariakit.usePopoverStore({
		placement
	})

	if (nestedMenu) {
		return (
			<NestedMenu label={trigger} render={<button type="button" />} menuPortal>
				<Form
					onSubmit={handleSubmit}
					onClear={onClear}
					min={min}
					max={max}
					minLabel={minLabel}
					maxLabel={maxLabel}
					minInputProps={minInputProps}
					maxInputProps={maxInputProps}
				/>
			</NestedMenu>
		)
	}

	return (
		<Ariakit.PopoverProvider store={popover}>
			<Ariakit.PopoverDisclosure className={clsx(baseClasses, variantClasses[variant], triggerClassName)}>
				{trigger}
				<Ariakit.PopoverDisclosureArrow className="h-3 w-3 shrink-0" />
			</Ariakit.PopoverDisclosure>

			<Ariakit.Popover
				unmountOnHide
				hideOnInteractOutside
				gutter={6}
				overflowPadding={16} // distance from the boundary edges
				wrapperProps={{
					className: 'max-sm:fixed! max-sm:bottom-0! max-sm:top-[unset]! max-sm:transform-none! max-sm:w-full!'
				}}
				className="z-10 flex min-w-[180px] flex-col overflow-auto overscroll-contain rounded-md border border-[hsl(204,20%,88%)] bg-(--bg-main) max-sm:h-[calc(100dvh-80px)] max-sm:drawer max-sm:rounded-b-none sm:max-h-[min(400px,60dvh)] lg:max-h-(--popover-available-height) dark:border-[hsl(204,3%,32%)]"
			>
				<Ariakit.PopoverDismiss className="ml-auto p-2 opacity-50 sm:hidden">
					<Icon name="x" className="h-5 w-5" />
				</Ariakit.PopoverDismiss>

				<div className="mx-auto w-full sm:w-[260px]">
					<Form
						min={min}
						max={max}
						onSubmit={(e) => {
							handleSubmit(e)
							popover.hide()
						}}
						onClear={() => {
							onClear()
							popover.hide()
						}}
						minLabel={minLabel}
						maxLabel={maxLabel}
						minInputProps={minInputProps}
						maxInputProps={maxInputProps}
					/>
				</div>
			</Ariakit.Popover>
		</Ariakit.PopoverProvider>
	)
}

function Form({
	onSubmit,
	onClear,
	min,
	max,
	minLabel,
	maxLabel,
	minInputProps,
	maxInputProps
}: {
	onSubmit: FormSubmitHandler
	onClear: () => void
	min: number | string | null
	max: number | string | null
	minLabel: string
	maxLabel: string
	minInputProps?: InputHTMLAttributes<HTMLInputElement>
	maxInputProps?: InputHTMLAttributes<HTMLInputElement>
}) {
	return (
		<form onSubmit={onSubmit} onReset={onClear} className="flex flex-col gap-3 p-3">
			<label className="flex flex-col gap-1">
				<span>{minLabel}</span>
				<input
					type="number"
					name="min"
					className="h-9 w-full rounded-md border border-(--form-control-border) bg-white px-3 py-1 text-black disabled:opacity-50 dark:bg-black dark:text-white"
					defaultValue={min ?? ''}
					{...minInputProps}
				/>
			</label>
			<label className="flex flex-col gap-1">
				<span>{maxLabel}</span>
				<input
					type="number"
					name="max"
					className="h-9 w-full rounded-md border border-(--form-control-border) bg-white px-3 py-1 text-black disabled:opacity-50 dark:bg-black dark:text-white"
					defaultValue={max ?? ''}
					{...maxInputProps}
				/>
			</label>

			<div className="mt-3 flex flex-col-reverse gap-2 sm:flex-row">
				<button
					type="reset"
					className="inline-flex h-9 w-full items-center justify-center rounded-md bg-black/5 px-4 text-sm font-medium whitespace-nowrap hover:bg-black/10 disabled:opacity-50 dark:bg-white/10 dark:text-white dark:hover:bg-white/20 dark:focus-visible:bg-white/20"
				>
					Clear
				</button>
				<button
					type="submit"
					className="inline-flex h-9 w-full items-center justify-center rounded-md bg-(--link-active-bg) px-4 text-sm font-medium whitespace-nowrap text-white disabled:opacity-50"
				>
					Apply Filter
				</button>
			</div>
		</form>
	)
}
