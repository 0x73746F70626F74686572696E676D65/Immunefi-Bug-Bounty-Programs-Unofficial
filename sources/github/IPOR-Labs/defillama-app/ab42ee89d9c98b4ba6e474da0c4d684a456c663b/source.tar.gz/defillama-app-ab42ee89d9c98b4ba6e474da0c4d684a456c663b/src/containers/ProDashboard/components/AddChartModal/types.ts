import type { ChartConfig, DashboardItemConfig, MetricAggregator, MetricChartType } from '../../types'
import type { UnifiedTableFocusSection } from '../UnifiedTable/types'

export interface AddChartModalProps {
	isOpen: boolean
	onClose: () => void
	editItem?: DashboardItemConfig | null
	initialUnifiedFocusSection?: UnifiedTableFocusSection
}

export type MainTabType = 'charts' | 'metric' | 'table' | 'text' | 'builder' | 'llamaai'
export type ChartModeType = 'manual' | 'builder'
export type ChartTabType =
	| 'chain'
	| 'protocol'
	| 'yields'
	| 'stablecoins'
	| 'advanced-tvl'
	| 'borrowed'
	| 'income-statement'
	| 'unlocks'
export type ManualChartViewMode = 'cards' | 'form'
export type CombinedTableType =
	| 'protocols'
	| 'cex'
	| 'stablecoins'
	| 'revenue'
	| 'holders-revenue'
	| 'earnings'
	| 'fees'
	| 'token-usage'
	| 'yields'
	| 'aggregators'
	| 'perps'
	| 'options'
	| 'dexs'
	| 'bridge-aggregators'
	| 'trending-contracts'
	| 'chains'

export interface ChartBuilderConfig {
	metric:
		| 'tvl'
		| 'fees'
		| 'revenue'
		| 'volume'
		| 'perps'
		| 'open-interest'
		| 'options-notional'
		| 'options-premium'
		| 'bridge-aggregators'
		| 'dex-aggregators'
		| 'perps-aggregators'
		| 'user-fees'
		| 'holders-revenue'
		| 'protocol-revenue'
		| 'supply-side-revenue'
		| 'stablecoins'
		| 'chain-fees'
		| 'chain-revenue'
	mode: 'chains' | 'protocol'
	filterMode?: 'include' | 'exclude'
	chainFilterMode?: 'include' | 'exclude'
	categoryFilterMode?: 'include' | 'exclude'
	chainCategoryFilterMode?: 'include' | 'exclude'
	protocolCategoryFilterMode?: 'include' | 'exclude'
	protocol?: string
	chains: string[]
	chainCategories?: string[]
	protocolCategories?: string[]
	categories: string[]
	groupBy: 'protocol'
	limit: number
	chartType: 'stackedBar' | 'stackedArea' | 'line' | 'treemap'
	treemapValue?: 'latest' | 'sum7d' | 'sum30d'
	displayAs: 'timeSeries' | 'percentage'
	hideOthers?: boolean
	groupByParent?: boolean
	additionalFilters?: Record<string, any>
	seriesColors?: Record<string, string>
}

export interface ModalState {
	selectedMainTab: MainTabType
	selectedChartTab: ChartTabType
	chartMode: ChartModeType
	composerItems: ChartConfig[]
	selectedChain: string | null
	selectedChains: string[]
	selectedProtocols: string[]
	selectedProtocol: string | null
	selectedChartType: string
	selectedChartTypes: string[]
	unifiedChartName: string
	chartCreationMode: 'separate' | 'combined'
	textTitle: string
	textContent: string
	selectedTableType: CombinedTableType
	selectedDatasetChain: string | null
	selectedDatasetTimeframe: string | null
	selectedTokens: string[]
	includeCex: boolean
	chartBuilderName: string
	chartBuilder: ChartBuilderConfig
	metricSubjectType: 'chain' | 'protocol'
	metricChain: string | null
	metricProtocol: string | null
	metricType: string
	metricAggregator: MetricAggregator
	metricWindow: '7d' | '30d' | '90d' | '365d' | 'ytd' | '3y' | 'all'
	metricLabel: string
	metricChartType: MetricChartType
	selectedYieldPool: { configID: string; name: string; project: string; chain: string } | null
	selectedYieldChartType: string
	selectedYieldChains: string[]
	selectedYieldProjects: string[]
	selectedYieldCategories: string[]
	selectedYieldTokens: string[]
	minTvl: number | null
	maxTvl: number | null
	selectedStablecoinChain: string
	selectedStablecoinChartType: string
	stablecoinMode: 'chain' | 'asset'
	selectedStablecoinAsset: string | null
	selectedStablecoinAssetId: string | null
	selectedStablecoinAssetChartType: string
	selectedAdvancedTvlProtocol: string | null
	selectedAdvancedTvlProtocolName: string | null
	selectedAdvancedTvlChartType: string
	selectedBorrowedProtocol: string | null
	selectedBorrowedProtocolName: string | null
	selectedBorrowedChartType: string
	selectedIncomeStatementProtocol: string | null
	selectedIncomeStatementProtocolName: string | null
	selectedLlamaAIChart: { id: string; title: string } | null
	selectedUnlocksProtocol: string | null
	selectedUnlocksProtocolName: string | null
	selectedUnlocksChartType: 'total' | 'schedule' | 'allocation' | 'locked-unlocked'
}

// oxlint-disable-next-line no-unused-vars
interface ModalActions {
	setSelectedMainTab: (tab: MainTabType) => void
	setSelectedChartTab: (tab: ChartTabType) => void
	setChartMode: (mode: ChartModeType) => void
	setComposerItems: React.Dispatch<React.SetStateAction<ChartConfig[]>>
	setSelectedChain: (chain: string | null) => void
	setSelectedChains: (chains: string[]) => void // New action for multi-chain selection
	setSelectedProtocols: (protocols: string[]) => void
	setSelectedProtocol: (protocol: string | null) => void
	setSelectedChartType: (type: string) => void
	setSelectedChartTypes: (types: string[]) => void
	setUnifiedChartName: (name: string) => void
	setChartCreationMode: (mode: 'separate' | 'combined') => void
	setTextTitle: (title: string) => void
	setTextContent: (content: string) => void
	setSelectedTableType: (type: CombinedTableType) => void
	setSelectedDatasetChain: (chain: string | null) => void
	setSelectedDatasetTimeframe: (timeframe: string | null) => void
	setSelectedTokens: (tokens: string[]) => void
	setIncludeCex: (include: boolean) => void
	setChartBuilderName: (name: string) => void
	handleChainChange: (option: any) => void
	handleChainsChange: (values: string[]) => void // New handler for multi-chain selection
	handleProtocolChange: (option: any) => void
	handleDatasetChainChange: (value: string | null) => void
	handleTokensChange: (tokens: string[]) => void
	handleAddToComposer: (typesToAdd?: string[], options?: { entity?: string; mode?: 'chain' | 'protocol' }) => void
	handleRemoveFromComposer: (id: string) => void
	handleUpdateComposerItemColor: (id: string, color: string) => void
	handleBulkChartTypeChange: (nextType: string) => void
	handleMainTabChange: (tab: MainTabType) => void
	handleSubmit: () => void
	handleChartTabChange: (tab: ChartTabType) => void
	setChartBuilder: React.Dispatch<React.SetStateAction<ChartBuilderConfig>>
	updateChartBuilder: (updates: Partial<ChartBuilderConfig>) => void
	setMetricSubjectType: (t: 'chain' | 'protocol') => void
	setMetricChain: (v: string | null) => void
	setMetricProtocol: (v: string | null) => void
	setMetricType: (t: string) => void
	setMetricAggregator: (a: MetricAggregator) => void
	setMetricWindow: (w: '7d' | '30d' | '90d' | '365d' | 'ytd' | '3y' | 'all') => void
	setMetricLabel: (s: string) => void
	setMetricChartType: (v: MetricChartType) => void
	setSelectedYieldPool: (pool: { configID: string; name: string; project: string; chain: string } | null) => void
	setSelectedYieldChartType: (chartType: string) => void
	setSelectedYieldChains: (chains: string[]) => void
	setSelectedYieldProjects: (projects: string[]) => void
	setSelectedYieldCategories: (categories: string[]) => void
	setSelectedYieldTokens: (tokens: string[]) => void
	setMinTvl: (tvl: number | null) => void
	setMaxTvl: (tvl: number | null) => void
	setSelectedStablecoinChain: (chain: string) => void
	setSelectedStablecoinChartType: (chartType: string) => void
	setStablecoinMode: (mode: 'chain' | 'asset') => void
	setSelectedStablecoinAsset: (asset: string | null) => void
	setSelectedStablecoinAssetId: (id: string | null) => void
	setSelectedStablecoinAssetChartType: (chartType: string) => void
	setSelectedAdvancedTvlProtocol: (protocol: string | null) => void
	setSelectedAdvancedTvlProtocolName: (name: string | null) => void
	setSelectedAdvancedTvlChartType: (chartType: string) => void
	setSelectedBorrowedProtocol: (protocol: string | null) => void
	setSelectedBorrowedProtocolName: (name: string | null) => void
	setSelectedBorrowedChartType: (chartType: string) => void
	setSelectedIncomeStatementProtocol: (protocol: string | null) => void
	setSelectedIncomeStatementProtocolName: (name: string | null) => void
	setSelectedLlamaAIChart: (chart: { id: string; title: string } | null) => void
	setSelectedUnlocksProtocol: (protocol: string | null) => void
	setSelectedUnlocksProtocolName: (name: string | null) => void
	setSelectedUnlocksChartType: (type: 'total' | 'schedule' | 'allocation' | 'locked-unlocked') => void
}
