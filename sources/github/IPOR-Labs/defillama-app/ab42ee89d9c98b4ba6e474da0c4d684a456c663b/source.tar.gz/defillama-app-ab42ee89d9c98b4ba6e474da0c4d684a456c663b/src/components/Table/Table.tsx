import { flexRender, type Row, type RowData, type Table } from '@tanstack/react-table'
import { type VirtualItem, useWindowVirtualizer } from '@tanstack/react-virtual'
import { useRouter } from 'next/router'
import * as React from 'react'
import { useEffect, useEffectEvent, useRef, useState } from 'react'
import toast from 'react-hot-toast'
import { Icon } from '~/components/Icon'
import { SortIcon } from '~/components/Table/SortIcon'
import { useMedia } from '~/hooks/useMedia'
import { Tooltip } from '../Tooltip'

interface ITableProps<T extends RowData = any> {
	instance: Table<T>
	skipVirtualization?: boolean
	rowSize?: number
	columnResizeMode?: 'onChange' | 'onEnd'
	stripedBg?: boolean
	style?: React.CSSProperties
	compact?: boolean
	useStickyHeader?: boolean
	scrollMargin?: number
}

const isGroupingColumn = (columnId?: string) => typeof columnId === 'string' && columnId.startsWith('__group_')

interface TableRowProps {
	row: Row<any>
	index: number
	virtualRow?: VirtualItem
	gridTemplateColumns: string
	totalTableWidth: number
	skipVirtualization?: boolean
	scrollMargin: number
	subRowOrdinalById: Map<string, number>
	firstColumnId: string | undefined
	stripedBg: boolean
	isChainPage: boolean
	compact: boolean
}

function TableRow({
	row: rowToRender,
	index: i,
	virtualRow,
	gridTemplateColumns,
	totalTableWidth,
	skipVirtualization,
	scrollMargin,
	subRowOrdinalById,
	firstColumnId,
	stripedBg,
	isChainPage,
	compact
}: TableRowProps) {
	const trStyle: React.CSSProperties = {
		display: 'grid',
		gridTemplateColumns,
		minWidth: `${totalTableWidth}px`,
		...(skipVirtualization || !virtualRow
			? { position: 'relative' }
			: {
					position: 'absolute',
					top: 0,
					left: 0,
					width: '100%',
					height: `${virtualRow.size}px`,
					opacity: rowToRender.original.disabled ? 0.3 : 1,
					transform: `translateY(${virtualRow.start - scrollMargin}px)`
				})
	}

	return (
		<React.Fragment>
			<div
				style={{
					...trStyle,
					...(rowToRender.depth > 0
						? {
								['--vf-subrow-index' as string]: `"${subRowOrdinalById.get(rowToRender.id) ?? rowToRender.index + 1}"`
							}
						: null)
				}}
				data-depth={rowToRender.depth}
				className="vf-row"
			>
				{rowToRender
					.getVisibleCells()
					.filter((cell) => !cell.column.columnDef.meta?.hidden)
					.map((cell) => {
						const textAlign = cell.column.columnDef.meta?.align ?? 'start'
						const isSticky = cell.column.id === firstColumnId
						return (
							<div
								key={cell.id}
								data-lighter={stripedBg && i % 2 === 0}
								data-chainpage={isChainPage}
								className={`overflow-hidden border-t border-r border-(--divider) p-3 text-ellipsis whitespace-nowrap ${
									compact ? 'flex items-center border-t-black/10 border-r-transparent px-5 dark:border-t-white/10' : ''
								}`}
								style={{
									textAlign,
									justifyContent: compact
										? textAlign === 'center'
											? 'center'
											: textAlign === 'end'
												? 'flex-end'
												: 'flex-start'
										: undefined,
									position: isSticky ? 'sticky' : undefined,
									left: isSticky ? 0 : undefined,
									zIndex: isSticky ? 1 : undefined,
									background: isSticky ? 'var(--cards-bg)' : undefined
								}}
							>
								{flexRender(cell.column.columnDef.cell, cell.getContext())}
							</div>
						)
					})}
			</div>
		</React.Fragment>
	)
}

export function VirtualTable({
	instance,
	skipVirtualization,
	columnResizeMode: _columnResizeMode,
	rowSize,
	stripedBg = false,
	compact = false,
	useStickyHeader = true,
	scrollMargin,
	...props
}: ITableProps) {
	const router = useRouter()
	const isSmallScreen = useMedia('(max-width: 768px)')
	const tableContainerRef = useRef<HTMLTableSectionElement>(null)
	const { rows } = instance.getRowModel()

	const subRowOrdinalById = React.useMemo(() => {
		const ordById = new Map<string, number>()
		const perParent = new Map<string, number>()

		for (const r of rows) {
			if (r.depth > 0) {
				const parentId =
					r.getParentRow?.()?.id ?? (typeof r.id === 'string' ? r.id.split('.').slice(0, -1).join('.') : String(r.id))
				const next = (perParent.get(parentId) ?? 0) + 1
				perParent.set(parentId, next)
				ordById.set(r.id, next)
			}
		}

		return ordById
	}, [rows])

	const [containerOffset, setContainerOffset] = useState(0)
	useEffect(() => {
		if (tableContainerRef.current) {
			setContainerOffset(tableContainerRef.current.offsetTop)
		}
	}, [])

	const rowVirtualizer = useWindowVirtualizer({
		count: rows.length,
		estimateSize: () => rowSize || 50,
		overscan: 5,
		scrollMargin: scrollMargin ?? containerOffset
	})
	const virtualItems = rowVirtualizer.getVirtualItems()
	const tableHeaderRef = useRef<HTMLDivElement>(null)
	const stickyScrollbarRef = useRef<HTMLDivElement>(null)
	const stickyScrollbarContentRef = useRef<HTMLDivElement>(null)
	const firstColumn = instance.getVisibleLeafColumns()[0]
	const firstColumnId = firstColumn?.id
	//const firstColumnWidth = firstColumn?.getSize() || 240
	const totalTableWidth = instance.getTotalSize()
	const isChainPage =
		router.pathname === '/' || router.pathname.startsWith('/chain') || router.pathname.startsWith('/protocols')

	const visibleLeafColumns = instance.getVisibleLeafColumns().filter((column) => !isGroupingColumn(column.id))
	const gridTemplateColumns =
		visibleLeafColumns.map((column) => `minmax(${column.getSize() ?? 100}px, 1fr)`).join(' ') || '1fr'

	const hasNoVisibleColumns = visibleLeafColumns.length === 0

	// useEffectEvent for keyboard handler - reads skipVirtualization without re-subscribing
	const onKeyDown = useEffectEvent((e: KeyboardEvent) => {
		if (!skipVirtualization && (e.ctrlKey || e.metaKey) && e.code === 'KeyF') {
			toast.error("Native browser search isn't well supported, please use search boxes / ctrl-k / cmd-k instead", {
				id: 'native-search-warn',
				icon: <Icon name="alert-triangle" color="red" height={16} width={16} style={{ flexShrink: 0 }} />
			})
		}
	})

	useEffect(() => {
		window.addEventListener('keydown', onKeyDown)
		return () => window.removeEventListener('keydown', onKeyDown)
	}, [])

	// useEffectEvent for scroll/resize - always reads latest props without re-subscribing
	const onScrollOrResize = useEffectEvent(() => {
		if (!useStickyHeader) return

		const tableWrapperEl = document.getElementById('table-wrapper')
		const tableHeaderDuplicate = document.getElementById('table-header-dup')

		if (
			!skipVirtualization &&
			tableHeaderRef.current &&
			tableWrapperEl &&
			tableWrapperEl.getBoundingClientRect().top <= 20 &&
			tableHeaderDuplicate
		) {
			// Batch DOM reads first
			const scrollLeft = tableWrapperEl.scrollLeft
			const offsetWidth = tableWrapperEl.offsetWidth
			const headerHeight = instance.getHeaderGroups().length * 45

			// Batch DOM writes using cssText for single reflow
			tableHeaderRef.current.style.cssText = `
				display: flex;
				flex-direction: column;
				z-index: 10;
				position: fixed;
				top: 0px;
				width: ${offsetWidth}px;
				overflow-x: overlay;
			`
			tableHeaderDuplicate.style.cssText = `height: ${headerHeight}px;`
			tableHeaderRef.current.scrollLeft = scrollLeft
		} else if (tableHeaderRef.current) {
			const offsetWidth = tableWrapperEl?.offsetWidth || 0
			// Batch DOM writes using cssText for single reflow
			tableHeaderRef.current.style.cssText = `
				display: flex;
				flex-direction: column;
				z-index: 10;
				position: relative;
				width: ${offsetWidth}px;
				overflow-x: initial;
			`
			if (tableHeaderDuplicate) {
				tableHeaderDuplicate.style.cssText = 'height: 0px;'
			}
		}
	})

	// useEffectEvent for table scroll - reads skipVirtualization without re-subscribing
	const onTableScroll = useEffectEvent((tableWrapperEl: HTMLElement, isMobile: boolean) => {
		const scrollLeft = tableWrapperEl.scrollLeft

		// Sync header horizontal scroll
		if (tableHeaderRef.current) {
			if (!skipVirtualization) {
				tableHeaderRef.current.scrollLeft = scrollLeft
			} else {
				tableHeaderRef.current.scrollLeft = 0
			}
		}

		// Sync sticky scrollbar (desktop only)
		if (!isMobile && stickyScrollbarRef.current) {
			stickyScrollbarRef.current.scrollLeft = scrollLeft
		}
	})

	// Consolidated scroll/resize handlers with RAF optimization
	useEffect(() => {
		const tableWrapperEl = document.getElementById('table-wrapper')
		if (!tableWrapperEl) return

		const isMobile = isSmallScreen || 'ontouchstart' in window
		const stickyScrollbar = stickyScrollbarRef.current // Capture ref value for cleanup
		let scrollRaf: number | null = null
		let resizeTimeout: ReturnType<typeof setTimeout>
		let windowScrollRaf: number | null = null

		// Handle table wrapper scroll (horizontal sync)
		const handleTableScroll = () => {
			if (scrollRaf) return // Already scheduled

			scrollRaf = requestAnimationFrame(() => {
				scrollRaf = null
				onTableScroll(tableWrapperEl, isMobile)
			})
		}

		// Handle window scroll (sticky header + sticky scrollbar visibility)
		const handleWindowScroll = () => {
			if (windowScrollRaf) return // Already scheduled

			windowScrollRaf = requestAnimationFrame(() => {
				windowScrollRaf = null

				// Update sticky header
				onScrollOrResize()

				// Update sticky scrollbar visibility (desktop only)
				if (!isMobile && stickyScrollbarRef.current && stickyScrollbarContentRef.current) {
					const tableRect = tableWrapperEl.getBoundingClientRect()
					const hasHorizontalScroll = tableWrapperEl.scrollWidth > tableWrapperEl.clientWidth
					const isTableAboveViewport = tableRect.bottom > window.innerHeight
					const isTableBelowViewport = tableRect.top > window.innerHeight

					if (hasHorizontalScroll && isTableAboveViewport && !isTableBelowViewport) {
						// Batch DOM reads first
						const scrollbarWidth = tableWrapperEl.offsetWidth
						const scrollbarLeft = tableRect.left
						const contentWidth = tableWrapperEl.scrollWidth

						// Batch DOM writes using cssText for single reflow
						stickyScrollbarRef.current.style.cssText = `
							position: fixed;
							bottom: 0;
							height: 12px;
							overflow-x: auto;
							overflow-y: hidden;
							z-index: 999;
							background-color: var(--cards-bg);
							display: block;
							width: ${scrollbarWidth}px;
							left: ${scrollbarLeft}px;
						`
						stickyScrollbarContentRef.current.style.cssText = `height: 1px; width: ${contentWidth}px;`
					} else {
						stickyScrollbarRef.current.style.cssText = `
							position: fixed;
							bottom: 0;
							height: 12px;
							overflow-x: auto;
							overflow-y: hidden;
							z-index: 999;
							background-color: var(--cards-bg);
							display: none;
						`
					}
				}
			})
		}

		// Handle resize with debounce
		const handleResize = () => {
			clearTimeout(resizeTimeout)
			resizeTimeout = setTimeout(() => {
				onScrollOrResize()
				handleWindowScroll() // Update sticky scrollbar on resize
			}, 100) // Increased to 100ms for better performance
		}

		// Handle sticky scrollbar scroll (desktop only)
		const handleStickyScroll = () => {
			if (!isMobile && stickyScrollbarRef.current) {
				tableWrapperEl.scrollLeft = stickyScrollbarRef.current.scrollLeft
			}
		}

		// Add event listeners with passive flag for better performance
		tableWrapperEl.addEventListener('scroll', handleTableScroll, { passive: true })
		window.addEventListener('scroll', handleWindowScroll, { passive: true })
		window.addEventListener('resize', handleResize, { passive: true })

		if (!isMobile && stickyScrollbar) {
			stickyScrollbar.addEventListener('scroll', handleStickyScroll, { passive: true })
			// Initial update for sticky scrollbar
			handleWindowScroll()
		}

		return () => {
			if (scrollRaf) cancelAnimationFrame(scrollRaf)
			if (windowScrollRaf) cancelAnimationFrame(windowScrollRaf)
			clearTimeout(resizeTimeout)

			tableWrapperEl.removeEventListener('scroll', handleTableScroll)
			window.removeEventListener('scroll', handleWindowScroll)
			window.removeEventListener('resize', handleResize)

			if (!isMobile && stickyScrollbar) {
				stickyScrollbar.removeEventListener('scroll', handleStickyScroll)
			}
		}
	}, [totalTableWidth, rows.length, isSmallScreen])

	if (hasNoVisibleColumns) {
		return (
			<div className="flex min-h-[400px] flex-col items-center justify-center gap-4 rounded-md bg-(--cards-bg) p-8 text-center">
				<Icon name="eye-off" height={48} width={48} className="text-(--text-tertiary)" />
				<div className="flex flex-col gap-2">
					<h3 className="text-lg font-semibold text-(--text-primary)">No columns selected</h3>
					<p className="text-sm text-(--text-secondary)">
						Please select at least one column from the Columns menu to view the table data.
					</p>
				</div>
			</div>
		)
	}

	const rowScrollMargin = rowVirtualizer.options.scrollMargin

	return (
		<div
			{...props}
			ref={tableContainerRef}
			id="table-wrapper"
			className="relative isolate thin-scrollbar w-full overflow-auto rounded-md bg-(--cards-bg)"
			style={{ maxWidth: '100%', WebkitOverflowScrolling: 'touch' }}
		>
			<div ref={tableHeaderRef} id="table-header" style={{ display: 'flex', flexDirection: 'column', zIndex: 10 }}>
				{instance.getHeaderGroups().map((headerGroup) => {
					const headers = headerGroup.headers.filter((header) => !header.column.columnDef.meta?.hidden)
					if (!headers.length) {
						return null
					}
					return (
						<div
							key={headerGroup.id}
							style={{ display: 'grid', gridTemplateColumns, minWidth: `${totalTableWidth}px` }}
						>
							{headers.map((header) => {
								const meta = header.column.columnDef.meta
								const value = flexRender(header.column.columnDef.header, header.getContext())
								const isSticky = header.column.id === firstColumnId //first column is sticky

								return (
									<div
										key={header.id}
										data-chainpage={isChainPage}
										data-align={meta?.align ?? 'start'}
										style={{
											gridColumn: `span ${header.colSpan}`,
											position: isSticky ? 'sticky' : undefined,
											left: isSticky ? 0 : undefined,
											zIndex: isSticky ? 10 : undefined,
											background: 'var(--cards-bg)'
										}}
										className={`overflow-hidden border-t border-r border-(--divider) p-3 text-ellipsis whitespace-nowrap last:border-r-0 ${
											compact
												? 'flex min-h-[50px] items-center border-t-black/10 border-r-transparent px-5 dark:border-t-white/10'
												: ''
										}`}
									>
										<span
											className="relative flex w-full flex-nowrap items-center justify-start gap-1 font-medium *:whitespace-nowrap data-[align=center]:justify-center data-[align=end]:justify-end"
											data-align={
												meta?.align ??
												(headerGroup.depth === 0 && instance.getHeaderGroups().length > 1 ? 'center' : 'start')
											}
										>
											{header.isPlaceholder ? null : (
												<HeaderWithTooltip
													content={meta?.headerHelperText}
													onClick={
														header.column.getCanSort()
															? () => React.startTransition(() => header.column.toggleSorting())
															: null
													}
												>
													{value}
													{header.column.getCanSort() && <SortIcon dir={header.column.getIsSorted()} />}
												</HeaderWithTooltip>
											)}
										</span>
									</div>
								)
							})}
						</div>
					)
				})}
			</div>

			<div id="table-header-dup"></div>

			<div
				className="vf-row-counter"
				style={
					skipVirtualization
						? { ['--vf-row-offset' as string]: '0' }
						: {
								height: `${rowVirtualizer.getTotalSize()}px`,
								width: '100%',
								position: 'relative',
								['--vf-row-offset' as string]: `${virtualItems?.[0]?.index ?? 0}`
							}
				}
			>
				{skipVirtualization
					? rows.map((row, i) => (
							<TableRow
								key={row.id}
								row={row}
								index={i}
								gridTemplateColumns={gridTemplateColumns}
								totalTableWidth={totalTableWidth}
								skipVirtualization={skipVirtualization}
								scrollMargin={rowScrollMargin}
								subRowOrdinalById={subRowOrdinalById}
								firstColumnId={firstColumnId}
								stripedBg={stripedBg}
								isChainPage={isChainPage}
								compact={compact}
							/>
						))
					: virtualItems.map((virtualRow) => (
							<TableRow
								key={rows[virtualRow.index].id}
								row={rows[virtualRow.index]}
								index={virtualRow.index}
								virtualRow={virtualRow}
								gridTemplateColumns={gridTemplateColumns}
								totalTableWidth={totalTableWidth}
								scrollMargin={rowScrollMargin}
								subRowOrdinalById={subRowOrdinalById}
								firstColumnId={firstColumnId}
								stripedBg={stripedBg}
								isChainPage={isChainPage}
								compact={compact}
							/>
						))}
			</div>

			{/* Sticky horizontal scrollbar */}
			<div
				ref={stickyScrollbarRef}
				className="thin-scrollbar"
				style={{
					position: 'fixed',
					bottom: 0,
					height: '12px',
					overflowX: 'auto',
					overflowY: 'hidden',
					zIndex: 999,
					display: 'none',
					backgroundColor: 'var(--cards-bg)'
				}}
			>
				<div ref={stickyScrollbarContentRef} style={{ height: '1px' }} />
			</div>
		</div>
	)
}

const HeaderWithTooltip = ({
	children,
	content,
	onClick
}: {
	children: React.ReactNode
	content?: string
	onClick: (() => void) | null
}) => {
	if (onClick) {
		if (!content)
			return (
				<button onClick={onClick} className="flex items-center gap-1">
					{children}
				</button>
			)
		return (
			<Tooltip
				content={content}
				className="underline decoration-dotted"
				render={<button className="flex items-center gap-1" />}
				onClick={onClick}
			>
				{children}
			</Tooltip>
		)
	}
	if (!content) return children
	return (
		<Tooltip content={content} className="underline decoration-dotted">
			{children}
		</Tooltip>
	)
}
