import { useMemo } from 'react'
import { preparePieChartData } from '~/components/ECharts/formatters'
import { capitalizeFirstLetter, getPercentChange, getPrevVolumeFromChart, keepNeededProperties, slug } from '~/utils'

interface ITokenData {
	usdValue: number
	amount: number
	symbol: string
	decimals: number
}

interface IDailyBridgeStats {
	date: number
	totalTokensDeposited: {
		[token: string]: ITokenData
	}
	totalTokensWithdrawn: {
		[token: string]: ITokenData
	}
	totalAddressDeposited: {
		[address: string]: {
			usdValue: number
			txs: number
		}
	}
	totalAddressWithdrawn: {
		[address: string]: {
			usdValue: number
			txs: number
		}
	}
	name?: string
}

const bridgePropertiesToKeep = [
	'displayName',
	'name',
	'symbol',
	'icon',
	'chains',
	'lastDailyVolume',
	'dayBeforeLastVolume',
	'weeklyVolume',
	'monthlyVolume',
	'txsPrevDay',
	'change_1d',
	'change_7d',
	'change_1m'
]

export const formatBridgesData = ({
	chain = '',
	bridges = [],
	chartDataByBridge = [],
	bridgeNameToChartDataIndex = {},
	bridgeProps = [...bridgePropertiesToKeep]
}) => {
	let filteredBridges = [...bridges]

	if (chain) {
		const sluggedChain = slug(chain)
		filteredBridges = filteredBridges.filter(({ chains = [] }) => chains.some((c) => slug(c) === sluggedChain))
	}

	filteredBridges = filteredBridges.map((bridge) => {
		const chartIndex = bridgeNameToChartDataIndex[bridge.displayName]
		const chart = chartDataByBridge[chartIndex] ?? null

		if (chain) {
			let dayTotalVolume, weekTotalVolume, monthTotalVolume
			dayTotalVolume = weekTotalVolume = monthTotalVolume = 0
			// start from i = 1 to exclude current day
			for (let i = 1; i < 31; i++) {
				const dailyVolume = getPrevVolumeFromChart(chart, i)
				if (i < 2) {
					dayTotalVolume += dailyVolume
				}
				if (i < 8) {
					weekTotalVolume += dailyVolume
				}
				monthTotalVolume += dailyVolume
			}
			bridge.lastDailyVolume = dayTotalVolume ?? null
			bridge.dayBeforeLastVolume = getPrevVolumeFromChart(chart, 2) ?? null
			bridge.weeklyVolume = weekTotalVolume ?? null
			bridge.monthlyVolume = monthTotalVolume ?? null
			bridge.last24hVolume = dayTotalVolume ?? null
		}

		bridge.change_1d = getPercentChange(bridge.lastDailyVolume, bridge.dayBeforeLastVolume)
		bridge.txsPrevDay = getPrevVolumeFromChart(chart, 0, true) ?? null
		// layerzero has 24h delay in the data
		if (bridge.name === 'layerzero' && bridge.txsPrevDay < 1000) {
			bridge.txsPrevDay = getPrevVolumeFromChart(chart, 1, true) ?? null
		}
		bridge.lastDailyVolume = bridge.last24hVolume

		return keepNeededProperties(bridge, bridgeProps)
	})
	const messagingProtocols = ['layerzero', 'wormhole', 'circle', 'hyperlane', 'ccip', 'hyperbridge']
	const regularBridges = filteredBridges.filter((bridge) => !messagingProtocols.includes(bridge.name?.toLowerCase()))
	const messagingProtocolsBridges = filteredBridges.filter((bridge) =>
		messagingProtocols.includes(bridge.name?.toLowerCase())
	)

	const sortedRegularBridges = regularBridges.sort((a, b) => b.lastDailyVolume - a.lastDailyVolume)
	const sortedMessagingProtocols = messagingProtocolsBridges.sort((a, b) => b.lastDailyVolume - a.lastDailyVolume)

	return {
		bridges: sortedRegularBridges,
		messagingProtocols: sortedMessagingProtocols
	}
}

export const formatChainsData = ({
	chains = [],
	chartDataByChain = [],
	chainToChartDataIndex = {},
	prevDayDataByChain = [] as IDailyBridgeStats[],
	netflowsDataDay = null,
	netflowsDataWeek = null
}) => {
	let filteredChains = [...chains]

	filteredChains = filteredChains.map((chain) => {
		const name = chain.name
		const chartIndex = chainToChartDataIndex[name]
		const charts = chartDataByChain[chartIndex] ?? null

		const prevDayData =
			prevDayDataByChain?.find(({ name }) => {
				return name === chain.name
			}) ?? null
		const prevDayChart = charts?.[charts.length - 1]
		const totalTokensDeposited = prevDayData?.totalTokensDeposited
		const totalTokensWithdrawn = prevDayData?.totalTokensWithdrawn

		let prevDayUsdDeposits, prevDayUsdWithdrawals, prevDayNetFlow
		if (netflowsDataDay && Array.isArray(netflowsDataDay)) {
			const chainNetflowDay = netflowsDataDay.find(
				(item) => item.chain && item.chain.toLowerCase() === name.toLowerCase()
			)
			if (chainNetflowDay) {
				prevDayUsdDeposits =
					chainNetflowDay.deposited_usd !== undefined ? Number(chainNetflowDay.deposited_usd) : prevDayChart?.depositUSD
				prevDayUsdWithdrawals =
					chainNetflowDay.withdrawn_usd !== undefined
						? Number(chainNetflowDay.withdrawn_usd)
						: prevDayChart?.withdrawUSD
				prevDayNetFlow =
					chainNetflowDay.net_flow !== undefined
						? Number(chainNetflowDay.net_flow)
						: prevDayUsdDeposits - prevDayUsdWithdrawals
			} else {
				prevDayUsdDeposits = prevDayChart?.depositUSD
				prevDayUsdWithdrawals = prevDayChart?.withdrawUSD
				prevDayNetFlow = prevDayUsdDeposits - prevDayUsdWithdrawals
			}
		} else {
			prevDayUsdDeposits = prevDayChart?.depositUSD
			prevDayUsdWithdrawals = prevDayChart?.withdrawUSD
			prevDayNetFlow = prevDayUsdDeposits - prevDayUsdWithdrawals
		}

		let prevWeekUsdDeposits, prevWeekUsdWithdrawals, prevWeekNetFlow
		if (netflowsDataWeek && Array.isArray(netflowsDataWeek)) {
			const chainNetflowWeek = netflowsDataWeek.find(
				(item) => item.chain && item.chain.toLowerCase() === name.toLowerCase()
			)
			if (chainNetflowWeek) {
				prevWeekUsdDeposits = chainNetflowWeek.deposited_usd !== undefined ? Number(chainNetflowWeek.deposited_usd) : 0
				prevWeekUsdWithdrawals =
					chainNetflowWeek.withdrawn_usd !== undefined ? Number(chainNetflowWeek.withdrawn_usd) : 0
				prevWeekNetFlow =
					chainNetflowWeek.net_flow !== undefined
						? Number(chainNetflowWeek.net_flow)
						: prevWeekUsdWithdrawals - prevWeekUsdDeposits
			} else {
				const prevWeekCharts = chartDataByChain[chartIndex].slice(-8, -1)
				prevWeekUsdDeposits = 0
				prevWeekUsdWithdrawals = 0
				for (const chart of prevWeekCharts) {
					prevWeekUsdDeposits += chart.depositUSD
					prevWeekUsdWithdrawals += chart.withdrawUSD
				}
				prevWeekNetFlow = prevWeekUsdWithdrawals - prevWeekUsdDeposits
			}
		} else {
			const prevWeekCharts = chartDataByChain[chartIndex].slice(-8, -1)
			prevWeekUsdDeposits = 0
			prevWeekUsdWithdrawals = 0
			for (const chart of prevWeekCharts) {
				prevWeekUsdDeposits += chart.depositUSD
				prevWeekUsdWithdrawals += chart.withdrawUSD
			}
			prevWeekNetFlow = prevWeekUsdWithdrawals - prevWeekUsdDeposits
		}

		let topTokenDepositedSymbol = null,
			topTokenWithdrawnSymbol = null,
			topTokenDepositedUsd = 0,
			topTokenWithdrawnUsd = 0
		let hasDeposited = false
		if (totalTokensDeposited) {
			for (const _ in totalTokensDeposited) {
				hasDeposited = true
				break
			}
		}
		if (totalTokensDeposited && hasDeposited) {
			let topKey = ''
			let topUsd = -Infinity
			for (const key in totalTokensDeposited) {
				if (totalTokensDeposited[key].usdValue > topUsd) {
					topUsd = totalTokensDeposited[key].usdValue
					topKey = key
				}
			}
			if (topKey) {
				topTokenDepositedSymbol = totalTokensDeposited[topKey].symbol
				topTokenDepositedUsd = totalTokensDeposited[topKey].usdValue
			}
		}
		let hasWithdrawn = false
		if (totalTokensWithdrawn) {
			for (const _ in totalTokensWithdrawn) {
				hasWithdrawn = true
				break
			}
		}
		if (totalTokensWithdrawn && hasWithdrawn) {
			let topKey = ''
			let topUsd = -Infinity
			for (const key in totalTokensWithdrawn) {
				if (totalTokensWithdrawn[key].usdValue > topUsd) {
					topUsd = totalTokensWithdrawn[key].usdValue
					topKey = key
				}
			}
			if (topKey) {
				topTokenWithdrawnSymbol = totalTokensWithdrawn[topKey].symbol
				topTokenWithdrawnUsd = totalTokensWithdrawn[topKey].usdValue
			}
		}

		return {
			name: name,
			prevDayUsdDeposits: prevDayUsdDeposits ?? 0,
			prevDayUsdWithdrawals: prevDayUsdWithdrawals ?? 0,
			prevWeekUsdDeposits: prevWeekUsdDeposits ?? 0,
			prevWeekUsdWithdrawals: prevWeekUsdWithdrawals ?? 0,
			topTokenDepositedSymbol: topTokenDepositedSymbol,
			topTokenDepositedUsd: topTokenDepositedUsd,
			topTokenWithdrawnSymbol: topTokenWithdrawnSymbol,
			topTokenWithdrawnUsd: topTokenWithdrawnUsd,
			prevDayNetFlow: prevDayNetFlow ?? 0,
			prevWeekNetFlow: prevWeekNetFlow ?? 0
		}
	})
	return filteredChains
}

const groupTokensBySymbol = (tokens: { [token: string]: ITokenData }) => {
	const group = {}
	for (const token in tokens) {
		const symbol = tokens[token].symbol || 'Unknown'
		group[symbol] = (group[symbol] ?? 0) + (tokens[token].usdValue || 0)
	}
	return group
}

export const useBuildBridgeChartData = (bridgeStatsCurrentDay: IDailyBridgeStats) => {
	const { tokenDeposits, tokenWithdrawals } = useMemo(() => {
		const tokensDeposited = bridgeStatsCurrentDay?.totalTokensDeposited
		const tokensWithdrawn = bridgeStatsCurrentDay?.totalTokensWithdrawn
		let tokenDeposits = [],
			tokenWithdrawals = []
		if (tokensDeposited && tokensWithdrawn) {
			const uniqueTokenDeposits = groupTokensBySymbol(tokensDeposited)

			tokenDeposits = preparePieChartData({
				data: uniqueTokenDeposits,
				limit: 10
			})

			const uniqueTokenWithdrawals = groupTokensBySymbol(tokensWithdrawn)

			tokenWithdrawals = preparePieChartData({
				data: uniqueTokenWithdrawals,
				limit: 10
			})
		}

		return { tokenDeposits, tokenWithdrawals }
	}, [bridgeStatsCurrentDay])
	return { tokenDeposits, tokenWithdrawals }
}

const blockExplorersTxs = {
	ethereum: ['https://etherscan.io/tx/', 'Etherscan'],
	bsc: ['https://bscscan.com/tx/', 'Bscscan'],
	xdai: ['https://gnosisscan.io/tx/', 'GnosisScan'],
	avax: ['https://snowtrace.io/tx/', 'Snowtrace'],
	fantom: ['https://ftmscan.com/tx/', 'FTMscan'],
	heco: ['https://hecoinfo.com/tx/', 'HecoInfo'],
	polygon: ['https://polygonscan.com/tx/', 'PolygonScan'],
	solana: ['https://solscan.io/tx/', 'Solscan'],
	arbitrum: ['https://arbiscan.io/tx/', 'Arbiscan'],
	optimism: ['https://optimistic.etherscan.io/tx/', 'Optimism Explorer'],
	aurora: ['https://aurorascan.dev/tx/', 'AuroraScan'],
	celo: ['https://explorer.celo.org/mainnet/tx/', 'Celo Explorer'],
	klaytn: ['https://scope.klaytn.com/tx/, Klaytn Scope']
}

const blockExplorersAddresses = {
	ethereum: ['https://etherscan.io/address/', 'Etherscan'],
	bsc: ['https://bscscan.com/address/', 'Bscscan'],
	xdai: ['https://gnosisscan.io/address/', 'GnosisScan'],
	avax: ['https://snowtrace.io/address/', 'Snowtrace'],
	fantom: ['https://ftmscan.com/address/', 'FTMscan'],
	heco: ['https://hecoinfo.com/address/', 'HecoInfo'],
	polygon: ['https://polygonscan.com/address/', 'PolygonScan'],
	solana: ['https://solscan.io/address/', 'Solscan'],
	arbitrum: ['https://arbiscan.io/address/', 'Arbiscan'],
	optimism: ['https://optimistic.etherscan.io/address/', 'Optimism Explorer'],
	aurora: ['https://aurorascan.dev/address/', 'AuroraScan'],
	celo: ['https://explorer.celo.org/mainnet/address/', 'Celo Explorer'],
	klaytn: ['https://scope.klaytn.com/account/, Klaytn Scope']
}

export const getBlockExplorerForTx = (txHash: string = '') => {
	let blockExplorerLink, blockExplorerName
	if (txHash?.includes(':')) {
		const [chain, chainHash] = txHash.split(':')
		const explorer = blockExplorersTxs[chain]
		if (explorer !== undefined) {
			blockExplorerLink = explorer[0] + chainHash
			blockExplorerName = explorer[1]
		}
	} else {
		if (typeof txHash === 'string' && txHash !== '') {
			blockExplorerLink = 'https://etherscan.io/tx/' + txHash
			blockExplorerName = 'Etherscan'
		}
	}

	return {
		blockExplorerLink,
		blockExplorerName
	}
}

export const getBlockExplorerForAddress = (txHash: string = '') => {
	let blockExplorerLink, blockExplorerName, chainName
	if (txHash?.includes(':')) {
		const [chain, chainHash] = txHash.split(':')
		const explorer = blockExplorersAddresses[chain]
		if (explorer !== undefined) {
			blockExplorerLink = explorer[0] + chainHash
			blockExplorerName = explorer[1]
		}
		chainName = chain
			? chain
					.split('_')
					.map((x) => capitalizeFirstLetter(x))
					.join(' ')
			: 'Ethereum'
	} else {
		if (typeof txHash === 'string' && txHash !== '') {
			blockExplorerLink = 'https://etherscan.io/address/' + txHash
			blockExplorerName = 'Etherscan'
			chainName = 'Ethereum'
		}
	}

	return {
		blockExplorerLink,
		blockExplorerName,
		chainName
	}
}
