import { preparePieChartData } from '~/components/ECharts/formatters'
import type { IMultiSeriesChart2Props, MultiSeriesChart2Dataset } from '~/components/ECharts/types'
import {
	BRIDGEDAYSTATS_API,
	BRIDGELARGETX_API,
	BRIDGES_API,
	BRIDGEVOLUME_API,
	CONFIG_API,
	NETFLOWS_API
} from '~/constants'
import { CHART_COLORS } from '~/constants/colors'
import { chainIconUrl, getNDistinctColors, slug, tokenIconUrl } from '~/utils'
import { fetchJson } from '~/utils/async'
import { formatBridgesData, formatChainsData } from './utils'

export const getBridges = () =>
	fetchJson(BRIDGES_API + '?includeChains=true').then(({ bridges, chains }) => ({
		bridges,
		chains
	}))

const getChainVolumeData = async (chain: string, chainCoingeckoIds) => {
	if (chain) {
		if (chainCoingeckoIds[chain]) {
			for (let i = 0; i < 5; i++) {
				try {
					const chart = await fetchJson(`${BRIDGEVOLUME_API}/${chain}`)
					const formattedChart = chart.map((chart) => {
						// This is confusing, stats from the endpoint use "deposit" to mean deposit in bridge contract,
						// i.e., a withdrawal from the chain. Will eventually change that.
						return {
							date: chart.date,
							Deposits: chart.depositUSD,
							Withdrawals: -chart.withdrawUSD
						}
					})
					return formattedChart
				} catch {}
			}
			throw new Error(`${BRIDGEVOLUME_API}/${chain} is broken`)
		} else return null
	} else {
		const chart = await fetchJson(BRIDGEVOLUME_API + '/all')
		const formattedChart = chart.map((chart) => {
			return {
				date: chart.date,
				volume: (chart.withdrawUSD + chart.depositUSD) / 2,
				txs: chart.depositTxs + chart.withdrawTxs
			}
		})
		return formattedChart
	}
}

const getLargeTransactionsData = async (chain: string, startTimestamp: number, endTimestamp: number) => {
	for (let i = 0; i < 5; i++) {
		try {
			if (chain) {
				return await fetchJson(
					`${BRIDGELARGETX_API}/${chain}?starttimestamp=${startTimestamp}&endtimestamp=${endTimestamp}`
				)
			} else {
				return await fetchJson(`${BRIDGELARGETX_API}/all?starttimestamp=${startTimestamp}&endtimestamp=${endTimestamp}`)
			}
		} catch {}
	}
	return []
}

export async function getBridgeOverviewPageData(chain) {
	const [{ bridges, chains }, { chainCoingeckoIds }] = await Promise.all([getBridges(), fetchJson(CONFIG_API)])

	let chartDataByBridge = []
	let bridgeNames: string[] = []
	let bridgeNameToChartDataIndex: object = {}
	chartDataByBridge = await Promise.all(
		bridges.map(async (elem, i) => {
			bridgeNames.push(elem.displayName)
			bridgeNameToChartDataIndex[elem.displayName] = i
			for (let i = 0; i < 5; i++) {
				try {
					let charts = []
					if (!chain) {
						charts = await fetchJson(`${BRIDGEVOLUME_API}/all?id=${elem.id}`)
					} else {
						charts = await fetchJson(`${BRIDGEVOLUME_API}/${chain}?id=${elem.id}`)
					}
					// can format differently here if needed
					let formattedCharts
					if (!chain) {
						formattedCharts = charts.map((chart) => {
							return {
								date: chart.date,
								volume: (chart.withdrawUSD + chart.depositUSD) / 2,
								txs: chart.depositTxs + chart.withdrawTxs
							}
						})
					} else {
						formattedCharts = charts.map((chart) => {
							return {
								date: chart.date,
								volume: (chart.withdrawUSD + chart.depositUSD) / 2,
								txs: chart.depositTxs + chart.withdrawTxs
							}
						})
					}
					return formattedCharts
				} catch {}
			}
			return []
		})
	)

	// order of chains will update every 24 hrs, can consider changing metric sorted by here
	const chainList = await chains
		.sort((a, b) => {
			return b.lastDailyVolume - a.lastDailyVolume
		})
		.map((chain) => chain.name)

	const chainVolumePromise = getChainVolumeData(chain, chainCoingeckoIds)

	const currentTimestamp = Math.floor(new Date().getTime() / 1000 / 3600) * 3600
	// 25 hours behind current time, gives 1 hour for BRIDGEDAYSTATS to update, may change this
	const prevDayTimestamp = currentTimestamp
	const bridgeStatsPromise = chain
		? (async () => {
				let bridgeStatsCurrentDay = {}
				for (let i = 0; i < 5; i++) {
					try {
						bridgeStatsCurrentDay = await fetchJson(`${BRIDGEDAYSTATS_API}/${prevDayTimestamp}/${chain}`)
						// can format differently here if needed
					} catch {}
				}
				return bridgeStatsCurrentDay
			})()
		: Promise.resolve({})

	const numberOfDaysForLargeTx = chain ? 7 : 1
	const secondsInDay = 3600 * 24
	const largeTxsPromise = getLargeTransactionsData(
		chain,
		currentTimestamp - numberOfDaysForLargeTx * secondsInDay,
		currentTimestamp
	)

	const [chainVolumeData, bridgeStatsCurrentDay, unformattedLargeTxsData] = await Promise.all([
		chainVolumePromise,
		bridgeStatsPromise,
		largeTxsPromise
	])
	const largeTxsData = Array.isArray(unformattedLargeTxsData)
		? unformattedLargeTxsData.map((transaction) => {
				const { token, symbol, isDeposit, chain: txChain } = transaction
				const symbolAndTokenForExplorer = `${symbol}#${token}`
				let correctedIsDeposit = isDeposit
				if (chain) {
					correctedIsDeposit = chain.toLowerCase() === txChain.toLowerCase() ? isDeposit : !isDeposit
				}
				return { ...transaction, isDeposit: correctedIsDeposit, symbol: symbolAndTokenForExplorer }
			})
		: []

	const { bridges: filteredBridges, messagingProtocols } = formatBridgesData({
		bridges,
		chartDataByBridge,
		bridgeNameToChartDataIndex,
		chain
	})

	return {
		chains: chainList,
		filteredBridges,
		messagingProtocols,
		bridgeNames,
		bridgeNameToChartDataIndex,
		chartDataByBridge,
		chainVolumeData: chainVolumeData ?? [],
		bridgeStatsCurrentDay,
		largeTxsData,
		chain: chain ?? 'All'
	}
}

export async function getBridgeChainsPageData() {
	const { chains } = await getBridges()

	let chartDataByChain = []
	let chainToChartDataIndex: object = {}
	chartDataByChain = await Promise.all(
		chains.map(async (chain, i) => {
			chainToChartDataIndex[chain.name] = i
			for (let i = 0; i < 5; i++) {
				try {
					const charts = await fetchJson(`${BRIDGEVOLUME_API}/${chain.name}`)
					return charts
				} catch {}
			}
			return []
		})
	)

	let chartData: Record<string, Record<string, number>> = {}

	for (let i = 0; i < chains.length; i++) {
		const chain = chains[i]
		const charts = chartDataByChain[i]
		for (const chart of charts) {
			const date = chart.date
			const netFlow = chart.depositUSD - chart.withdrawUSD
			chartData[date] = chartData[date] || {}
			chartData[date][chain.name] = netFlow
		}
	}

	// order of chains will update every 24 hrs, can consider changing metric sorted by here
	const chainList = await chains
		.sort((a, b) => {
			return b.volumePrevDay - a.volumePrevDay
		})
		.map((chain) => chain.name)

	const currentTimestamp = Math.floor(new Date().getTime() / 1000 / 3600) * 3600
	// 25 hours behind current time, gives 1 hour for BRIDGEDAYSTATS to update, may change this
	const prevDayTimestamp = currentTimestamp - 86400 - 3600

	let netflowsDataDay = null
	let netflowsDataWeek = null
	try {
		;[netflowsDataDay, netflowsDataWeek] = await Promise.all([
			fetchJson(`${NETFLOWS_API}/day`).catch(() => null),
			fetchJson(`${NETFLOWS_API}/week`).catch(() => null)
		])
	} catch (e) {
		console.log('Failed to fetch netflows data:', e)
	}

	let prevDayDataByChain = []
	prevDayDataByChain = (
		await Promise.all(
			chains.map(async (chain) => {
				for (let i = 0; i < 5; i++) {
					try {
						const charts = await fetchJson(`${BRIDGEDAYSTATS_API}/${prevDayTimestamp}/${chain.name}`)
						return { ...charts, name: chain.name }
					} catch {}
				}
				//throw new Error(`${BRIDGEDAYSTATS_API}/${prevDayTimestamp}/${chain.name} is broken`)
			})
		)
	).filter((t) => t !== undefined)

	const filteredChains = formatChainsData({
		chains,
		chartDataByChain,
		chainToChartDataIndex,
		prevDayDataByChain,
		netflowsDataDay,
		netflowsDataWeek
	})

	const chartRows: Array<{ date: number; [key: string]: number }> = []
	for (const date in chartData) {
		chartRows.push({ date: Number(date), ...chartData[date] })
	}

	const chart = buildBridgeChainsMultiSeriesChart({ chartRows, chains: chainList })

	return {
		allChains: chainList,
		tableData: filteredChains,
		chart
	}
}

function buildBridgeChainsMultiSeriesChart({
	chartRows,
	chains
}: {
	chartRows: Array<{ date: number; [key: string]: number }>
	chains: string[]
}): {
	dataset: MultiSeriesChart2Dataset
	charts: NonNullable<IMultiSeriesChart2Props['charts']>
} {
	const source = (chartRows ?? [])
		.map((row) => {
			const { date, ...rest } = row
			return {
				timestamp: date * 1e3,
				...rest
			}
		})
		.filter((row) => Number.isFinite(Number(row.timestamp)))
		.toSorted((a, b) => Number(a.timestamp) - Number(b.timestamp))

	const dimensions = ['timestamp', ...(chains ?? [])]

	const charts = (chains ?? []).map((name, i) => ({
		type: 'bar' as const,
		name,
		encode: { x: 'timestamp', y: name },
		// Use per-series stacks so selected chains render as clustered bars (not stacked).
		stack: name,
		color: CHART_COLORS[i % CHART_COLORS.length],
		large: true
	}))

	return {
		dataset: { source, dimensions } satisfies MultiSeriesChart2Dataset,
		charts
	}
}

// oxlint-disable-next-line no-unused-vars
async function getBridgePageData(bridge: string) {
	const { bridges } = await getBridges()
	const bridgeData = bridges.filter((obj) => slug(obj.displayName) === slug(bridge))[0]

	const { id, chains, icon, displayName } = bridgeData
	const defaultChain = chains[0]
	const [iconType, iconName] = icon.split(':')
	const logo = iconType === 'chain' ? chainIconUrl(iconName) : tokenIconUrl(iconName)

	let bridgeChartDataByChain = []
	let chainToChartDataIndex: object = {}
	bridgeChartDataByChain = await Promise.all(
		chains.map(async (chain, i) => {
			chainToChartDataIndex[chain] = i
			for (let i = 0; i < 5; i++) {
				try {
					const charts = await fetchJson(`${BRIDGEVOLUME_API}/${chain}?id=${id}`)
					return charts
				} catch {}
			}
			return []
		})
	)

	const currentTimestamp = Math.floor(new Date().getTime() / 1000 / 3600) * 3600
	// 25 hours behind current time, gives 1 hour for BRIDGEDAYSTATS to update, may change this
	const prevDayTimestamp = currentTimestamp - 86400 - 3600
	let prevDayDataByChain = []
	prevDayDataByChain = await Promise.all(
		chains.map(async (chain) => {
			for (let i = 0; i < 5; i++) {
				try {
					const charts = await fetchJson(`${BRIDGEDAYSTATS_API}/${prevDayTimestamp}/${chain}?id=${id}`)
					// can format differently here if needed
					return charts
				} catch {}
			}
			return []
		})
	)

	return {
		displayName,
		logo,
		chains,
		defaultChain,
		chainToChartDataIndex,
		bridgeChartDataByChain,
		prevDayDataByChain
	}
}

export async function getBridgePageDatanew(bridge: string) {
	// fetch list of all bridges
	const { bridges } = await getBridges()

	// find data of bridge
	const bridgeData = bridges.find((obj) => slug(obj.displayName) === slug(bridge) || slug(obj.slug) === slug(bridge))

	if (!bridgeData) {
		return null
	}

	const { id, chains, icon, displayName, destinationChain } = bridgeData

	const [iconType, iconName] = icon.split(':')
	// get logo based on icon type (chain or protocol)
	const logo = iconType === 'chain' ? chainIconUrl(iconName) : tokenIconUrl(iconName)

	const volumeDataByChain = {}

	const volume = await Promise.all(
		chains.map(async (chain) => {
			for (let i = 0; i < 5; i++) {
				try {
					const charts = await fetchJson(`${BRIDGEVOLUME_API}/${chain}?id=${id}`)
					return charts
				} catch {}
			}

			throw new Error(`${BRIDGEVOLUME_API}/${chain} is broken`)
		})
	)

	const volumeOnAllChains: {
		[date: number]: {
			date: number
			Deposited: number
			Withdrawn: number
		}
	} = {}

	for (let index = 0; index < volume.length; index++) {
		const chainVolume = volume[index]
		const chartData = []

		for (const item of chainVolume) {
			const date = Number(item.date)
			chartData.push({ date, Deposited: item.depositUSD, Withdrawn: -item.withdrawUSD })

			if (!volumeOnAllChains[date]) {
				volumeOnAllChains[date] = { date, Deposited: 0, Withdrawn: 0 }
			}

			volumeOnAllChains[date] = {
				date,
				Deposited: volumeOnAllChains[date].Deposited + (item.depositUSD || 0),
				Withdrawn: volumeOnAllChains[date].Withdrawn - (item.withdrawUSD || 0)
			}
		}

		volumeDataByChain[chains[index]] = chartData
	}

	volumeDataByChain['All Chains'] =
		destinationChain !== 'false' ? (volumeDataByChain?.[destinationChain] ?? []) : Object.values(volumeOnAllChains)

	const currentTimestamp = Math.floor(new Date().getTime() / 1000 / 3600) * 3600
	// 25 hours behind current time, gives 1 hour for BRIDGEDAYSTATS to update, may change this
	const prevDayTimestamp = currentTimestamp - 86400 - 3600

	const statsOnPrevDay = await Promise.all(
		chains.map(async (chain) => {
			for (let i = 0; i < 5; i++) {
				try {
					const charts = await fetchJson(`${BRIDGEDAYSTATS_API}/${prevDayTimestamp}/${chain}?id=${id}`)
					// can format differently here if needed
					return charts
				} catch {}
			}
			throw new Error(`${BRIDGEDAYSTATS_API}/${prevDayTimestamp}/${chain} is broken`)
		})
	)

	const prevDayDataByChain = {}

	for (let index = 0; index < statsOnPrevDay.length; index++) {
		const data = statsOnPrevDay[index]
		prevDayDataByChain['All Chains'] = {
			date: Math.max(prevDayDataByChain['All Chains']?.date ?? 0, data.date),
			totalTokensDeposited: {
				...(prevDayDataByChain['All Chains']?.totalTokensDeposited ?? {}),
				...data.totalTokensDeposited
			},
			totalTokensWithdrawn: {
				...(prevDayDataByChain['All Chains']?.totalTokensWithdrawn ?? {}),
				...data.totalTokensWithdrawn
			},
			totalAddressDeposited: {
				...(prevDayDataByChain['All Chains']?.totalAddressDeposited ?? {}),
				...data.totalAddressDeposited
			},
			totalAddressWithdrawn: {
				...(prevDayDataByChain['All Chains']?.totalAddressWithdrawn ?? {}),
				...data.totalAddressWithdrawn
			}
		}

		prevDayDataByChain[chains[index]] = data
	}

	if (destinationChain !== 'false') {
		prevDayDataByChain[destinationChain] = prevDayDataByChain['All Chains']
	}

	const chainsList = ['All Chains', ...chains, destinationChain !== false ? destinationChain : null].filter(
		(chain) => chain
	)

	const tableDataByChain = {}
	for (const currentChain of chainsList) {
		const prevDayData = prevDayDataByChain[currentChain]
		let tokensTableData = [],
			addressesTableData = [],
			tokenDeposits = [],
			tokenWithdrawals = [],
			tokenColor = {}
		if (prevDayData) {
			const totalTokensDeposited = prevDayData.totalTokensDeposited
			const totalTokensWithdrawn = prevDayData.totalTokensWithdrawn
			let tokensTableUnformatted = {}
			Object.entries(totalTokensDeposited).map(([token, tokenData]: [string, { symbol: string; usdValue: number }]) => {
				const symbol = tokenData.symbol == null || tokenData.symbol === '' ? 'unknown' : tokenData.symbol
				const usdValue = tokenData.usdValue
				const key = `${symbol}#${token}`
				tokensTableUnformatted[key] = tokensTableUnformatted[key] || {}
				tokensTableUnformatted[key].deposited = (tokensTableUnformatted[key].deposited ?? 0) + usdValue
				tokensTableUnformatted[key].volume = (tokensTableUnformatted[key].volume ?? 0) + usdValue
				// ensure there are no undefined values for deposited/withdrawn so table can be sorted
				tokensTableUnformatted[key].withdrawn = 0
			})
			Object.entries(totalTokensWithdrawn).map(([token, tokenData]: [string, { symbol: string; usdValue: number }]) => {
				const symbol = tokenData.symbol == null || tokenData.symbol === '' ? 'unknown' : tokenData.symbol
				const usdValue = tokenData.usdValue ?? 0
				const key = `${symbol}#${token}`
				tokensTableUnformatted[key] = tokensTableUnformatted[key] || {}
				tokensTableUnformatted[key].withdrawn = (tokensTableUnformatted[key].withdrawn ?? 0) + usdValue
				tokensTableUnformatted[key].volume = (tokensTableUnformatted[key].volume ?? 0) + usdValue
				if (!tokensTableUnformatted[key].deposited) {
					tokensTableUnformatted[key].deposited = 0
				}
			})

			tokensTableData = Object.entries(tokensTableUnformatted)
				.filter(([, volumeData]: [string, any]) => {
					return volumeData.volume !== 0
				})
				.map((entry: [string, object]) => {
					return { symbol: entry[0], ...entry[1] }
				})

			let fullTokenDeposits: { name: string; value: number }[] = []
			for (const key in totalTokensDeposited) {
				const tokenData = totalTokensDeposited[key] as { symbol: string; usdValue: number }
				fullTokenDeposits.push({ name: tokenData.symbol, value: tokenData.usdValue })
			}
			let fullTokenWithdrawals: { name: string; value: number }[] = []
			for (const key in totalTokensWithdrawn) {
				const tokenData = totalTokensWithdrawn[key] as { symbol: string; usdValue: number }
				fullTokenWithdrawals.push({ name: tokenData.symbol, value: tokenData.usdValue })
			}

			if (currentChain === 'All Chains') {
				// Use for..in instead of Object.values() and Set for deduplication
				const symbolToDeposits = new Map<string, number>()
				for (const key in totalTokensDeposited) {
					const tokenData = totalTokensDeposited[key] as { symbol: string; usdValue: number }
					const existing = symbolToDeposits.get(tokenData.symbol) ?? 0
					symbolToDeposits.set(tokenData.symbol, existing + tokenData.usdValue)
				}
				fullTokenDeposits = []
				for (const [symbol, value] of symbolToDeposits) {
					fullTokenDeposits.push({ name: symbol, value })
				}

				const symbolToWithdrawals = new Map<string, number>()
				for (const key in totalTokensWithdrawn) {
					const tokenData = totalTokensWithdrawn[key] as { symbol: string; usdValue: number }
					const existing = symbolToWithdrawals.get(tokenData.symbol) ?? 0
					symbolToWithdrawals.set(tokenData.symbol, existing + tokenData.usdValue)
				}
				fullTokenWithdrawals = []
				for (const [symbol, value] of symbolToWithdrawals) {
					fullTokenWithdrawals.push({ name: symbol, value })
				}
			}

			tokenDeposits = preparePieChartData({
				data: fullTokenDeposits,
				limit: 15
			})
			tokenWithdrawals = preparePieChartData({
				data: fullTokenWithdrawals,
				limit: 15
			})

			const colors = getNDistinctColors(tokenDeposits.length + tokenWithdrawals.length)

			tokenColor = Object.fromEntries(
				[...tokenDeposits, ...tokenWithdrawals, 'Others'].map((token, i) => {
					return typeof token === 'string' ? ['-', colors[i] ?? '#AAAAAA'] : [token.name, colors[i] ?? '#AAAAAA']
				})
			)
			const totalAddressesDeposited = prevDayData.totalAddressDeposited
			const totalAddressesWithdrawn = prevDayData.totalAddressWithdrawn
			let addressesTableUnformatted = {}
			for (const address in totalAddressesDeposited) {
				const addressData = totalAddressesDeposited[address] as { txs: number; deposited: number; usdValue: number }
				const txs = addressData.txs
				const usdValue = addressData.usdValue
				addressesTableUnformatted[address] = addressesTableUnformatted[address] || {}
				addressesTableUnformatted[address].deposited = (addressesTableUnformatted[address].deposited ?? 0) + usdValue
				addressesTableUnformatted[address].txs = (addressesTableUnformatted[address].txs ?? 0) + txs
			}
			for (const address in totalAddressesWithdrawn) {
				const addressData = totalAddressesWithdrawn[address] as { txs: number; deposited: number; usdValue: number }
				const txs = addressData.txs
				const usdValue = addressData.usdValue
				addressesTableUnformatted[address] = addressesTableUnformatted[address] || {}
				addressesTableUnformatted[address].withdrawn = (addressesTableUnformatted[address].withdrawn ?? 0) + usdValue
				addressesTableUnformatted[address].txs = (addressesTableUnformatted[address].txs ?? 0) + txs
			}
			addressesTableData = Object.entries(addressesTableUnformatted)
				.filter(([, addressData]: [string, any]) => {
					return addressData.txs !== 0
				})
				.map((entry: [string, object]) => {
					return { address: entry[0], deposited: 0, withdrawn: 0, ...entry[1] }
				})
		}

		tableDataByChain[currentChain] = {
			tokensTableData,
			addressesTableData,
			tokenDeposits,
			tokenWithdrawals,
			tokenColor
		}
	}

	return {
		displayName,
		logo,
		chains: ['All Chains', ...chains],
		defaultChain: 'All Chains',
		volumeDataByChain,
		tableDataByChain,
		config: bridgeData
	}
}
