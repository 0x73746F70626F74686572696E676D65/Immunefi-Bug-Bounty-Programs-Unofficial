import dayjs from 'dayjs'
import { TreemapChart as EChartTreemap } from 'echarts/charts'
import { TitleComponent, ToolboxComponent, TooltipComponent } from 'echarts/components'
import * as echarts from 'echarts/core'
import { CanvasRenderer } from 'echarts/renderers'
import { startTransition, useEffect, useId, useMemo, useRef, useState } from 'react'
import { TagGroup } from '~/components/TagGroup'
import { useDarkModeManager } from '~/contexts/LocalStorage'
import { useChartResize } from '~/hooks/useChartResize'
import { formattedNum, tokenIconUrl } from '~/utils'

echarts.use([TitleComponent, TooltipComponent, ToolboxComponent, EChartTreemap, CanvasRenderer])

interface UnlocksTreemapProps {
	unlocksData: {
		[date: string]: {
			totalValue: number
			events: Array<{
				protocol: string
				value: number
				details: string
				unlockType: string
			}>
		}
	}
	height?: string
	filterYear?: number
}

interface YearData {
	children: {
		[month: string]: {
			protocols: {
				[protocol: string]: number
			}
			value: number
		}
	}
	value: number
}

type YearDataMap = {
	[year: string]: YearData
}

const TIME_VIEWS = ['Month', 'Current Year', 'All Years'] as const
type TimeView = (typeof TIME_VIEWS)[number]

export default function UnlocksTreemapChart({ unlocksData, height = '600px', filterYear }: UnlocksTreemapProps) {
	const id = useId()
	const [isDark] = useDarkModeManager()
	const [timeView, setTimeView] = useState<TimeView>('Current Year')
	const [selectedDate, setSelectedDate] = useState(() => dayjs())
	const chartRef = useRef<echarts.ECharts | null>(null)

	// Stable resize listener - never re-attaches when dependencies change
	useChartResize(chartRef)

	const currentYear = filterYear ?? dayjs().year()

	const protocolLabel = (protocol: string, value: number, iconUrl: string) => ({
		show: true,
		formatter: `{icon|}\n{name|${protocol}}\n{value|${formattedNum(value, true)}}`,
		position: 'inside' as const,
		color: '#fff',
		rich: {
			icon: {
				height: 22,
				width: 22,
				align: 'center' as const,
				backgroundColor: { image: iconUrl },
				lineHeight: 26
			},
			name: {
				fontSize: 12,
				fontWeight: 600,
				color: '#fff',
				align: 'center' as const,
				lineHeight: 16,
				padding: [2, 0, 0, 0]
			},
			value: {
				fontSize: 11,
				fontWeight: 500,
				color: 'rgba(255, 255, 255, 0.85)',
				align: 'center' as const,
				lineHeight: 14
			}
		}
	})

	const chartDataTree = useMemo(() => {
		const treeData = []
		const yearData: YearDataMap = {}

		for (const dateStr in unlocksData) {
			const dailyData = unlocksData[dateStr]
			const date = dayjs(dateStr)
			const year = date.year()
			const monthIndex = date.month()
			const monthName = date.format('MMMM')

			if (timeView === 'Month') {
				if (monthIndex !== selectedDate.month() || year !== selectedDate.year()) continue
			} else if (timeView === 'Current Year') {
				if (year !== currentYear) continue
			} else if (timeView === 'All Years') {
				if (year < currentYear) continue
			}

			if (!yearData[year]) {
				yearData[year] = {
					children: {},
					value: 0
				}
			}

			if (!yearData[year].children[monthName]) {
				yearData[year].children[monthName] = {
					protocols: {},
					value: 0
				}
			}

			for (const event of dailyData.events) {
				if (!yearData[year].children[monthName].protocols[event.protocol]) {
					yearData[year].children[monthName].protocols[event.protocol] = 0
				}

				yearData[year].children[monthName].protocols[event.protocol] += event.value
				yearData[year].children[monthName].value += event.value
				yearData[year].value += event.value
			}
		}

		if (timeView === 'Month') {
			const targetYear = selectedDate.year()
			const targetMonthName = selectedDate.format('MMMM')
			if (yearData[targetYear] && yearData[targetYear].children[targetMonthName]) {
				const monthInfo = yearData[targetYear].children[targetMonthName]
				const protocolsData = Object.entries(monthInfo.protocols)
					.map(([protocol, value]) => {
						const iconUrl = tokenIconUrl(protocol)
						return {
							name: protocol,
							value: value,
							iconUrl: iconUrl,
							label: protocolLabel(protocol, value, iconUrl)
						}
					})
					.toSorted((a, b) => b.value - a.value)
				return protocolsData
			} else {
				return []
			}
		}

		if (timeView === 'Current Year' && yearData[currentYear]) {
			const currentYearData = yearData[currentYear]

			return Object.entries(currentYearData.children)
				.map(([month, monthInfo]) => {
					const monthNode: any = {
						name: month,
						value: monthInfo.value,
						children: [],
						upperLabel: {
							show: true,
							formatter: `${month} - ${formattedNum(monthInfo.value, true)}`,
							color: isDark ? '#ffffff' : '#000000',
							fontSize: 13,
							fontWeight: 600
						}
					}

					for (const protocol in monthInfo.protocols) {
						const value = monthInfo.protocols[protocol]
						const iconUrl = tokenIconUrl(protocol)
						monthNode.children.push({
							name: protocol,
							value: value,
							iconUrl: iconUrl,
							label: protocolLabel(protocol, value, iconUrl)
						})
					}

					monthNode.children = monthNode.children.toSorted((a, b) => b.value - a.value)
					return monthNode
				})
				.toSorted((a, b) => b.value - a.value)
		}

		if (timeView === 'All Years') {
			for (const year in yearData) {
				const yearInfo = yearData[year]
				const yearNode: any = {
					name: year,
					value: yearInfo.value,
					children: [],
					upperLabel: {
						show: true,
						formatter: `${year} - ${formattedNum(yearInfo.value, true)}`,
						color: isDark ? '#ffffff' : '#000000',
						fontSize: 14,
						fontWeight: 700
					}
				}

				for (const month in yearInfo.children) {
					const monthInfo = yearInfo.children[month]
					const monthNode: any = {
						name: month,
						value: monthInfo.value,
						children: [],
						upperLabel: {
							show: true,
							formatter: `${month} - ${formattedNum(monthInfo.value, true)}`,
							color: isDark ? '#ffffff' : '#000000',
							fontSize: 12,
							fontWeight: 600
						}
					}

					for (const protocol in monthInfo.protocols) {
						const value = monthInfo.protocols[protocol]
						const iconUrl = tokenIconUrl(protocol)
						monthNode.children.push({
							name: protocol,
							value: value,
							iconUrl: iconUrl,
							label: protocolLabel(protocol, value, iconUrl)
						})
					}

					monthNode.children = monthNode.children.toSorted((a, b) => b.value - a.value)
					yearNode.children.push(monthNode)
				}

				yearNode.children = yearNode.children.toSorted((a, b) => b.value - a.value)
				treeData.push(yearNode)
			}

			treeData.sort((a, b) => Number(a.name) - Number(b.name))
			return treeData
		}

		return []
	}, [unlocksData, currentYear, timeView, isDark, selectedDate])

	useEffect(() => {
		const el = document.getElementById(id)
		if (!el) return
		const instance = echarts.getInstanceByDom(el) || echarts.init(el)
		chartRef.current = instance

		const option = {
			title: {
				textStyle: {
					fontFamily: 'sans-serif',
					fontWeight: 600,
					color: isDark ? 'rgba(255, 255, 255, 1)' : 'rgba(0, 0, 0, 1)'
				}
			},
			tooltip: {
				formatter: (info: any) => {
					const { data, treePathInfo } = info
					const { name, value, iconUrl } = data
					const pathNames = treePathInfo.map((item) => item.name).slice(0, -1)

					let pathDisplay = pathNames.join(' > ')
					if (timeView === 'Month' && !pathNames.length) {
						pathDisplay = ''
					} else if (pathDisplay) {
						pathDisplay += ' > '
					}

					let content = `<div style="font-size: 12px; line-height: 1.5; padding: 4px;">`
					if (iconUrl) {
						content += `<img src="${iconUrl}" style="width: 18px; height: 18px; vertical-align: middle; margin-right: 6px; border-radius: 50%;" /> `
					}
					content += `<strong style="font-weight: 600;">${pathDisplay}${name}</strong><br/>`
					content += `<span style="opacity: 0.85;">Value:</span> <strong style="font-weight: 600;">${formattedNum(value, true)}</strong>`
					content += `</div>`
					return content
				},
				backgroundColor: isDark ? 'rgba(30, 30, 30, 0.95)' : 'rgba(255, 255, 255, 0.95)',
				borderColor: isDark ? 'rgba(255, 255, 255, 0.15)' : 'rgba(0, 0, 0, 0.15)',
				borderWidth: 1,
				textStyle: {
					color: isDark ? '#ffffff' : '#000000'
				}
			},
			toolbox: {
				feature: {
					restore: {
						title: 'Reset'
					}
				},
				iconStyle: {
					borderColor: isDark ? 'rgba(255, 255, 255, 0.6)' : 'rgba(0, 0, 0, 0.6)'
				},
				emphasis: {
					iconStyle: {
						borderColor: isDark ? '#ffffff' : '#000000'
					}
				},
				right: 8,
				top: 8
			},
			series: [
				{
					name: 'Token Unlocks',
					type: 'treemap',
					visibleMin: 300,
					data: chartDataTree,
					leafDepth: 2,
					roam: true,
					left: 0,
					top: 0,
					right: 0,
					bottom: 0,
					label: {
						show: true,
						rich: {}
					},
					upperLabel: {
						show: true,
						height: 28,
						color: isDark ? '#ffffff' : '#000000',
						fontSize: 13,
						fontWeight: 600,
						textShadowBlur: 2,
						textShadowColor: isDark ? 'rgba(0, 0, 0, 0.8)' : 'rgba(255, 255, 255, 0.8)'
					},
					itemStyle: {
						borderColor: isDark ? '#555555' : '#d0d0d0',
						borderWidth: 2,
						gapWidth: 2
					},
					levels: [
						{
							itemStyle: {
								borderColor: isDark ? '#777777' : '#999999',
								borderWidth: 0,
								gapWidth: 2
							},
							upperLabel: {
								show: false
							}
						},
						{
							itemStyle: {
								borderWidth: 2,
								gapWidth: 2,
								borderColorSaturation: 0.6
							},
							upperLabel: {
								show: true,
								height: 26,
								color: isDark ? '#ffffff' : '#000000',
								fontSize: 12,
								fontWeight: 600
							},
							emphasis: {
								itemStyle: {
									borderColor: isDark ? '#ffffff' : '#000000',
									borderWidth: 3
								}
							}
						},
						{
							colorSaturation: [0.4, 0.75],
							itemStyle: {
								borderWidth: 2,
								gapWidth: 1,
								borderColorSaturation: 0.65
							},
							emphasis: {
								itemStyle: {
									borderWidth: 3,
									shadowBlur: 8,
									shadowColor: isDark ? 'rgba(255, 255, 255, 0.3)' : 'rgba(0, 0, 0, 0.3)'
								}
							}
						}
					],
					breadcrumb: {
						itemStyle: {
							color: isDark ? 'rgba(255, 255, 255, 0.2)' : 'rgba(0, 0, 0, 0.12)',
							borderColor: isDark ? 'rgba(255, 255, 255, 0.3)' : 'rgba(0, 0, 0, 0.2)',
							borderWidth: 1,
							textStyle: {
								fontFamily: 'sans-serif',
								fontWeight: 500,
								color: isDark ? 'rgba(255, 255, 255, 0.95)' : 'rgba(0, 0, 0, 0.95)'
							}
						},
						emphasis: {
							itemStyle: {
								color: isDark ? 'rgba(255, 255, 255, 0.35)' : 'rgba(0, 0, 0, 0.25)',
								borderColor: isDark ? 'rgba(255, 255, 255, 0.5)' : 'rgba(0, 0, 0, 0.4)'
							},
							textStyle: {
								color: isDark ? '#ffffff' : '#000000'
							}
						}
					}
				}
			]
		}

		instance.setOption(option)

		return () => {
			chartRef.current = null
			instance.dispose()
		}
	}, [id, chartDataTree, isDark, timeView, selectedDate])

	const goToPrevMonth = () => setSelectedDate((d) => d.subtract(1, 'month'))
	const goToNextMonth = () => setSelectedDate((d) => d.add(1, 'month'))

	return (
		<div className="flex flex-col gap-3">
			<div className="flex flex-wrap items-center justify-end gap-3">
				{timeView === 'Month' ? (
					<div className="order-1 flex items-center gap-2 md:order-0">
						<button
							onClick={goToPrevMonth}
							className="rounded-md p-1.5 text-(--text-secondary) hover:bg-(--link-hover-bg)"
							aria-label="Previous Month"
						>
							←
						</button>
						<span className="w-28 text-center text-sm font-medium">{selectedDate.format('MMMM YYYY')}</span>
						<button
							onClick={goToNextMonth}
							className="rounded-md p-1.5 text-(--text-secondary) hover:bg-(--link-hover-bg)"
							aria-label="Next Month"
						>
							→
						</button>
					</div>
				) : null}

				<TagGroup
					selectedValue={timeView}
					setValue={(period) => startTransition(() => setTimeView(period as TimeView))}
					values={TIME_VIEWS}
				/>
			</div>

			<div id={id} style={{ width: '100%', height: height }} />
		</div>
	)
}
