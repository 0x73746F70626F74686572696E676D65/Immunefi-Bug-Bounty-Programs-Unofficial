import { SankeyChart as ESankeyChart } from 'echarts/charts'
import { GraphicComponent, GridComponent, TitleComponent, TooltipComponent } from 'echarts/components'
import * as echarts from 'echarts/core'
import { CanvasRenderer } from 'echarts/renderers'
import { useCallback, useEffect, useId, useMemo, useRef } from 'react'
import { ChartPngExportButton } from '~/components/ButtonStyled/ChartPngExportButton'
import { useDarkModeManager } from '~/contexts/LocalStorage'
import { useChartImageExport } from '~/hooks/useChartImageExport'
import { useChartResize } from '~/hooks/useChartResize'
import { useMedia } from '~/hooks/useMedia'
import { abbreviateNumber } from '~/utils'
import { ChartContainer } from '../ChartContainer'
import { ChartHeader } from '../ChartHeader'
import { formatTooltipValue } from '../formatters'
import type { ISankeyChartProps } from '../types'

echarts.use([CanvasRenderer, ESankeyChart, TooltipComponent, TitleComponent, GridComponent, GraphicComponent])

export default function SankeyChart({
	height = '500px',
	nodes,
	links,
	title,
	valueSymbol = '$',
	nodeColors,
	nodeAlign = 'justify',
	orient = 'horizontal',
	onReady,
	enableImageExport = false,
	imageExportFilename,
	imageExportTitle,
	...props
}: ISankeyChartProps) {
	const id = useId()
	const [isDark] = useDarkModeManager()
	const isSmall = useMedia(`(max-width: 37.5rem)`)
	const { chartInstance: exportChartInstance, handleChartReady } = useChartImageExport()
	const exportFilename = imageExportFilename || (title ? title.replace(/\s+/g, '-').toLowerCase() : 'sankey-chart')
	const exportTitle = imageExportTitle || title
	const chartRef = useRef<echarts.ECharts | null>(null)
	const formatSankeyValue = useCallback(
		(value: number): string => {
			return abbreviateNumber(value, 2, valueSymbol) ?? formatTooltipValue(value, valueSymbol)
		},
		[valueSymbol]
	)

	// Stable resize listener - never re-attaches when dependencies change
	useChartResize(chartRef)

	// Create maps for node metadata (descriptions, display values, and percentage labels)
	const nodeMetadata = useMemo(() => {
		const descriptions: Record<string, string> = {}
		const displayValues: Record<string, number | string> = {}
		const percentageLabels: Record<string, string> = {}
		for (const node of nodes) {
			if (node.description) {
				descriptions[node.name] = node.description
			}
			if (node.displayValue !== undefined) {
				displayValues[node.name] = node.displayValue
			}
			if (node.percentageLabel) {
				percentageLabels[node.name] = node.percentageLabel
			}
		}
		return { descriptions, displayValues, percentageLabels }
	}, [nodes])

	const series = useMemo(() => {
		const nodeData = nodes.map((node) => ({
			name: node.name,
			itemStyle: {
				color: nodeColors?.[node.name] ?? node.color ?? undefined
			},
			...(node.depth !== undefined ? { depth: node.depth } : {})
		}))

		return {
			type: 'sankey',
			layout: 'none',
			nodeAlign,
			orient,
			emphasis: {
				focus: 'adjacency'
			},
			nodeGap: 24,
			nodeWidth: 16,
			lineStyle: {
				color: 'gradient',
				curveness: 0.5,
				opacity: 0.4
			},
			label: {
				show: true,
				position: orient === 'horizontal' ? 'right' : 'bottom',
				fontFamily: 'sans-serif',
				fontSize: 14,
				color: isDark ? 'rgba(255, 255, 255, 0.9)' : 'rgba(0, 0, 0, 0.9)',
				formatter: (params: any) => {
					// Use displayValue if provided, otherwise use calculated value
					const displayValue = nodeMetadata.displayValues[params.name]
					const formattedValue =
						displayValue !== undefined
							? typeof displayValue === 'string'
								? displayValue
								: formatSankeyValue(displayValue)
							: formatSankeyValue(params.value)

					// Add percentage label if provided
					const percentageLabel = nodeMetadata.percentageLabels[params.name]
					const valueWithPercent = percentageLabel ? `${formattedValue} (${percentageLabel})` : formattedValue

					const description = nodeMetadata.descriptions[params.name]
					if (description && !isSmall) {
						// Truncate description to ~50 chars for display under label
						const truncatedDesc = description.length > 50 ? description.slice(0, 47) + '...' : description
						return `{name|${params.name}: ${valueWithPercent}}\n{desc|${truncatedDesc}}`
					}
					return `${params.name}: ${valueWithPercent}`
				},
				rich: {
					name: {
						fontSize: 14,
						fontWeight: 'normal',
						color: isDark ? 'rgba(255, 255, 255, 0.9)' : 'rgba(0, 0, 0, 0.9)'
					},
					desc: {
						fontSize: 10,
						color: isDark ? 'rgba(255, 255, 255, 0.5)' : 'rgba(0, 0, 0, 0.5)'
					}
				}
			},
			data: nodeData,
			links: links.map((link) => ({
				source: link.source,
				target: link.target,
				value: link.value,
				lineStyle: link.color ? { color: link.color } : undefined
			}))
		}
	}, [nodes, links, nodeColors, nodeAlign, orient, isDark, isSmall, formatSankeyValue, nodeMetadata])

	useEffect(() => {
		const el = document.getElementById(id)
		if (!el) return
		const instance = echarts.getInstanceByDom(el) || echarts.init(el)
		chartRef.current = instance

		const graphic = {
			type: 'image',
			z: 0,
			style: {
				image: isDark ? '/assets/defillama-light-neutral.webp' : '/assets/defillama-dark-neutral.webp',
				height: 40,
				opacity: 0.3
			},
			left: isSmall ? '35%' : '40%',
			top: '50%'
		}

		instance.setOption({
			graphic,
			tooltip: {
				trigger: 'item',
				triggerOn: 'mousemove',
				confine: true,
				backgroundColor: isDark ? 'rgba(0, 0, 0, 0.9)' : 'rgba(255, 255, 255, 0.9)',
				borderColor: isDark ? 'rgba(255, 255, 255, 0.2)' : 'rgba(0, 0, 0, 0.2)',
				textStyle: {
					color: isDark ? 'rgba(255, 255, 255, 1)' : 'rgba(0, 0, 0, 1)'
				},
				formatter: (params: any) => {
					if (params.dataType === 'edge') {
						return `${params.data.source} → ${params.data.target}<br/>${formatSankeyValue(params.data.value)}`
					}
					// Use displayValue if provided for tooltip value
					const displayValue = nodeMetadata.displayValues[params.name]
					const valueToShow =
						displayValue !== undefined
							? typeof displayValue === 'string'
								? displayValue
								: formatSankeyValue(displayValue)
							: formatSankeyValue(params.value)
					// Add percentage label if provided
					const percentageLabel = nodeMetadata.percentageLabels[params.name]
					const valueWithPercent = percentageLabel ? `${valueToShow} (${percentageLabel})` : valueToShow
					const description = nodeMetadata.descriptions[params.name]
					if (description) {
						return `<strong>${params.name}</strong><br/>${valueWithPercent}<br/><span style="color: ${isDark ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.7)'}; font-size: 11px;">${description}</span>`
					}
					return `${params.name}<br/>${valueWithPercent}`
				}
			},
			series
		})

		handleChartReady(instance)
		onReady?.(instance)

		return () => {
			chartRef.current = null
			instance.dispose()
			handleChartReady(null)
			onReady?.(null)
		}
	}, [id, series, isDark, title, valueSymbol, isSmall, handleChartReady, onReady, nodeMetadata, formatSankeyValue])

	return (
		<ChartContainer
			id={id}
			chartClassName=""
			chartStyle={{ height }}
			header={
				title || enableImageExport ? (
					<ChartHeader
						title={title}
						className="mb-2 flex items-center justify-end gap-2"
						exportButtons={
							enableImageExport ? (
								<ChartPngExportButton
									chartInstance={exportChartInstance}
									filename={exportFilename}
									title={exportTitle}
								/>
							) : null
						}
					/>
				) : null
			}
			{...props}
		/>
	)
}
