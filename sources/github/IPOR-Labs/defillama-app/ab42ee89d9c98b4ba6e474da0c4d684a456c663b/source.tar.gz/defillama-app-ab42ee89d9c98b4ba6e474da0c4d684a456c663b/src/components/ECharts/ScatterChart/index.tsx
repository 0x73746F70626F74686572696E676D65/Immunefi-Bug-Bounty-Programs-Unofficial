import { ScatterChart as EChartScatter } from 'echarts/charts'
import {
	AxisPointerComponent,
	BrushComponent,
	DataZoomComponent,
	GraphicComponent,
	GridComponent,
	LegendComponent,
	TitleComponent,
	ToolboxComponent,
	TooltipComponent
} from 'echarts/components'
import * as echarts from 'echarts/core'
import { CanvasRenderer } from 'echarts/renderers'
import { useEffect, useId, useRef } from 'react'
import { useDarkModeManager } from '~/contexts/LocalStorage'
import { useChartResize } from '~/hooks/useChartResize'
import { formattedNum } from '~/utils'
import type { IScatterChartProps } from '../types'

echarts.use([
	CanvasRenderer,
	EChartScatter,
	TooltipComponent,
	ToolboxComponent,
	TitleComponent,
	GridComponent,
	GraphicComponent,
	AxisPointerComponent,
	BrushComponent,
	LegendComponent,
	DataZoomComponent
])

const getEntityIcon = (type: string, slug: string) => {
	if (type === 'chain') return `https://icons.llamao.fi/icons/chains/rsz_${slug}?w=48&h=48`
	return `https://icons.llamao.fi/icons/protocols/${slug}?w=48&h=48`
}

export default function ScatterChart({
	chartData,
	title,
	xAxisLabel,
	yAxisLabel,
	valueSymbol = '',
	height = '600px',
	tooltipFormatter,
	showLabels = false,
	entityType = 'protocol'
}: IScatterChartProps) {
	const id = useId()

	const [isDark] = useDarkModeManager()
	const chartRef = useRef<echarts.ECharts | null>(null)

	// Stable resize listener - never re-attaches when dependencies change
	useChartResize(chartRef)

	useEffect(() => {
		const el = document.getElementById(id)
		if (!el) return
		const instance = echarts.getInstanceByDom(el) || echarts.init(el)
		chartRef.current = instance

		let series = []
		const isYieldData = chartData.length > 0 && chartData[0].projectName !== undefined

		const labelConfig = showLabels
			? {
					show: true,
					position: 'right' as const,
					formatter: (params: any) => params.value?.[2] || '',
					fontSize: 10,
					color: isDark ? 'rgba(255, 255, 255, 0.8)' : 'rgba(0, 0, 0, 0.8)'
				}
			: undefined

		if (isYieldData) {
			const projectNames = [...new Set(chartData.map((p) => p.projectName))]
			for (const project of projectNames) {
				series.push({
					name: project,
					type: 'scatter',
					symbols: 5,
					large: true,
					emphasis: {
						focus: 'series'
					},
					label: labelConfig,
					data: chartData
						.filter((p) => p.projectName === project)
						.map((p) => [p.sigma, p.mu, p.count, p.symbol, p.pool, p.tvlUsd, p.apy, p.chain])
				})
			}
		} else {
			const dataWithSymbols = showLabels
				? chartData.map((point: any) => ({
						value: point,
						symbol: `image://${getEntityIcon(entityType, point[3] || '')}`,
						symbolSize: 20
					}))
				: chartData

			series = [
				{
					name: title || 'Data',
					type: 'scatter',
					symbolSize: showLabels ? 20 : 8,
					emphasis: {
						focus: 'series'
					},
					label: labelConfig,
					data: dataWithSymbols
				}
			]
		}

		const yieldTooltipFormatter = (params) => {
			if (params.value.length > 1) {
				return (
					'Symbol: ' +
					params.value[3] +
					'<br/>' +
					'Pool: ' +
					params.value[4] +
					'<br/>' +
					'TVL: ' +
					formattedNum(params.value[5], true) +
					'<br/>' +
					'APY Spot: ' +
					params.value[6].toFixed(2) +
					'%' +
					'<br/>' +
					'Chain: ' +
					params.value[7] +
					'<br/>' +
					'Project: ' +
					params.seriesName +
					'<br/>' +
					'APY Geometric Average: ' +
					params.value[1].toFixed(2) +
					'%' +
					'<br/>' +
					'APY Standard Deviation: ' +
					params.value[0].toFixed(2) +
					'%' +
					'<br/>' +
					'Nb of collected daily datapoints: ' +
					params.value[2]
				)
			} else {
				return params.seriesName + ' :<br/>' + params.name + ' : ' + params.value.toFixed(5) + 'mean '
			}
		}

		const genericTooltipFormatter = (params) => {
			if (params.value && params.value.length >= 2) {
				const xValue = params.value[0]
				const yValue = params.value[1]
				const entityName = params.value[2]
				const formatValue = (val) => {
					if (valueSymbol === '$') return formattedNum(val, true)
					if (valueSymbol === '%') return val.toFixed(2) + '%'
					return formattedNum(val)
				}
				let tooltip = ''
				if (entityName) {
					tooltip += `<strong>${entityName}</strong><br/>`
				}
				tooltip += `${xAxisLabel || 'X'}: ${formatValue(xValue)}<br/>`
				tooltip += `${yAxisLabel || 'Y'}: ${formatValue(yValue)}`
				return tooltip
			}
			return ''
		}

		const effectiveTooltipFormatter =
			tooltipFormatter || (isYieldData ? yieldTooltipFormatter : genericTooltipFormatter)

		const option = {
			title: {
				text: title || 'APY Average vs Volatility',
				textStyle: {
					fontFamily: 'sans-serif',
					fontWeight: 600,
					color: isDark ? 'rgba(255, 255, 255, 1)' : 'rgba(0, 0, 0, 1)'
				}
			},
			grid: {
				right: 12,
				bottom: 12,
				left: 12,
				outerBoundsMode: 'same'
			},
			tooltip: {
				showDelay: 0,
				confine: true,
				formatter: effectiveTooltipFormatter,
				axisPointer: {
					show: true,
					type: 'cross',
					lineStyle: {
						type: 'dashed',
						width: 1
					}
				}
			},
			toolbox: {
				feature: {
					dataZoom: {},
					restore: {}
				}
			},
			xAxis: [
				{
					type: 'value',
					scale: true,
					name: xAxisLabel || 'APY Standard Deviation',
					nameLocation: 'middle',
					nameTextStyle: {
						fontFamily: 'sans-serif',
						fontSize: 14,
						fontWeight: 500
					},
					axisLabel: {
						formatter: '{value}',
						color: isDark ? 'rgba(255, 255, 255, 1)' : 'rgba(0, 0, 0, 1)',
						inside: true
					},
					splitLine: {
						lineStyle: {
							color: '#a1a1aa',
							opacity: 0.1
						}
					}
				}
			],
			yAxis: [
				{
					type: 'value',
					scale: true,
					name: yAxisLabel || 'APY Geometric Average',
					nameLocation: 'middle',
					nameTextStyle: {
						fontFamily: 'sans-serif',
						fontSize: 14,
						fontWeight: 500
					},
					axisLabel: {
						formatter: '{value}',
						color: isDark ? 'rgba(255, 255, 255, 1)' : 'rgba(0, 0, 0, 1)',
						inside: true
					},
					splitLine: {
						lineStyle: {
							color: '#a1a1aa',
							opacity: 0.1
						}
					}
				}
			],
			dataZoom: [
				{
					type: 'inside',
					start: 0,
					end: 100,
					filterMode: 'none'
				}
			],
			labelLayout: { hideOverlap: true },
			series: series
		}

		instance.setOption(option)

		return () => {
			chartRef.current = null
			instance.dispose()
		}
	}, [id, chartData, isDark, tooltipFormatter, xAxisLabel, yAxisLabel, valueSymbol, title, showLabels, entityType])

	return (
		<div>
			<div id={id} className="h-[360px]" style={height ? { height } : undefined} />
		</div>
	)
}
