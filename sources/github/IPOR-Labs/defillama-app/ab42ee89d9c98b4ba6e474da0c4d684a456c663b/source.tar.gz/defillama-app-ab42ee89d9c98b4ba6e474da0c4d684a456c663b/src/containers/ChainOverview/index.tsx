import { lazy, Suspense } from 'react'
import { EntityQuestionsStrip } from '~/components/EntityQuestionsStrip'
import { Icon } from '~/components/Icon'
import { RowLinksWithDropdown } from '~/components/RowLinksWithDropdown'
import { TokenLogo } from '~/components/TokenLogo'
import { chainIconUrl, slug } from '~/utils'
import { SmolStats } from './SmolStats'
import { Stats } from './Stats'
import type { IChainOverviewData } from './types'

const Table = lazy(() => import('./Table').then((m) => ({ default: m.ChainProtocolsTable })))

export function ChainOverview(props: IChainOverviewData) {
	return (
		<>
			<RowLinksWithDropdown links={props.allChains} activeLink={props.metadata.name} />
			{props.metadata.name !== 'All' && (
				<EntityQuestionsStrip
					questions={props.entityQuestions || []}
					entitySlug={slug(props.metadata.name)}
					entityType="chain"
					entityName={props.metadata.name}
				/>
			)}
			{props.isDataAvailable ? (
				<>
					<Stats {...props} />
					<SmolStats {...props} />
				</>
			) : (
				<>
					<div className="flex flex-1 flex-col gap-10 rounded-md border border-(--cards-border) bg-(--cards-bg) p-2">
						<h1 className="flex flex-nowrap items-center gap-2">
							<TokenLogo logo={chainIconUrl(props.metadata.name)} size={24} />
							<span className="text-xl font-semibold">{props.metadata.name}</span>
						</h1>
						<p className="my-auto py-10 text-center text-sm text-(--text-form)">
							We don't track any protocols with TVL, Fees, Revenue or Volume on this chain
						</p>
					</div>
				</>
			)}
			{props.metadata.name === 'All' ? (
				<div className="relative isolate flex thin-scrollbar shrink-0 flex-nowrap items-center gap-1 overflow-x-auto overflow-y-hidden">
					{linksToOtherLlamaApps.map((app) => (
						<a
							target="_blank"
							rel="noreferrer noopener"
							href={app.href}
							key={`llama-app-${app.href}`}
							className="relative flex max-h-[64px] w-full max-w-[70vw] min-w-[270px] flex-1 items-center gap-2.5 overflow-hidden rounded-lg border border-(--cards-bg) bg-(--cards-bg) p-2.5"
						>
							{app.background}
							<>{app.icon}</>
							<span className="flex flex-1 flex-col gap-0.5">
								<span className="col-span-1 row-span-1 overflow-hidden text-sm font-semibold text-ellipsis whitespace-nowrap">
									{app.name}
								</span>
								{app.description === '' ? null : (
									<span className="col-span-1 row-span-1 overflow-hidden text-sm font-light text-ellipsis whitespace-nowrap">
										{app.description}
									</span>
								)}
							</span>
							<Icon name="arrow-up-right-2" className="h-6 w-6 shrink-0" />
						</a>
					))}
				</div>
			) : null}
			{props.protocols.length > 0 ? (
				<Suspense
					fallback={
						<div
							style={{ minHeight: `${props.protocols.length * 50 + 200}px` }}
							className="rounded-md border border-(--cards-border) bg-(--cards-bg)"
						/>
					}
				>
					<Table protocols={props.protocols} />
				</Suspense>
			) : null}
		</>
	)
}

const linksToOtherLlamaApps = [
	{
		name: 'LlamaSearch',
		description: 'Find official links to projects',
		href: 'https://search.defillama.com',
		icon: (
			<img
				src="/assets/llamasearch.svg"
				loading="lazy"
				alt=""
				height={44}
				width={39.28}
				className="z-10 object-contain"
			/>
		),
		background: <span className="llama-app-background" />
	},
	{
		name: 'LlamaSwap',
		description: 'No fees DEX aggregator',
		href: 'https://swap.defillama.com',
		icon: (
			<img src="/assets/llamaswap.svg" loading="lazy" alt="" height={44} width={44} className="z-10 object-contain" />
		),
		background: <span className="llama-app-background" />
	},
	{
		name: 'LlamaFeed',
		description: 'The ultimate crypto feed',
		href: 'https://llamafeed.io/',
		icon: (
			<img src="/assets/llamafeed.svg" loading="lazy" alt="" height={44} width={44} className="z-10 object-contain" />
		),
		background: <span className="llama-app-background" />
	},
	{
		name: 'DefiLlama API',
		description: 'Access to all our data',
		href: 'https://defillama.com/pro-api/docs',
		icon: (
			<img src="/assets/llamaswap.svg" loading="lazy" alt="" height={44} width={44} className="z-10 object-contain" />
		),
		background: <span className="llama-app-background" />
	},
	{
		name: '2025 DeFi Report',
		description: '',
		href: 'https://assets.dlnews.com/dlresearch/State-of-DeFi-2025.pdf',
		icon: (
			<svg width={44} height={44}>
				<use href={`/assets/dlresearch.svg#dlresearch-logo`} />
			</svg>
		),
		background: <span className="llama-app-background" />
	},
	{
		name: 'DLNews',
		description: '',
		href: 'https://www.dlnews.com',
		icon: (
			<svg width={44} height={44}>
				<use href={`/assets/dlnews-smol.svg#dlnews-logo`} />
			</svg>
		),
		background: <span className="llama-app-background" />
	},
	{
		name: 'DL Research',
		description: '',
		href: 'https://www.dlnews.com/research',
		icon: (
			<svg width={44} height={44}>
				<use href={`/assets/dlresearch.svg#dlresearch-logo`} />
			</svg>
		),
		background: <span className="llama-app-background" />
	}
]
