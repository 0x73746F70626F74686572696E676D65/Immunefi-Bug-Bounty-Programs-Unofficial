import { type Dispatch, type RefObject, type SetStateAction, useEffect, useRef, useState } from 'react'
import { Icon } from '~/components/Icon'
import { Tooltip } from '~/components/Tooltip'
import { useMedia } from '~/hooks/useMedia'
import type { FormSubmitEvent } from '~/types/forms'
import { useEntityCombobox } from '../hooks/useEntityCombobox'
import { useImageUpload, fileToBase64 } from '../hooks/useImageUpload'
import { setInputSize, syncHighlightScroll } from '../utils/scrollUtils'
import { highlightWord } from '../utils/textUtils'
import { EntityComboboxPopover } from './input/EntityCombobox'
import { DragOverlay, ImageUpload, ImageUploadButton } from './input/ImageUpload'
import { InputTextarea } from './input/InputTextarea'
import { ModeToggle, type ResearchUsage } from './input/ModeToggle'
import { SubmitButton } from './input/SubmitButton'

function revokeImageUrls(images: Array<{ url: string }>) {
	for (let i = 0; i < images.length; i++) {
		URL.revokeObjectURL(images[i].url)
	}
}

interface PromptInputProps {
	handleSubmit: (
		prompt: string,
		preResolvedEntities?: Array<{ term: string; slug: string }>,
		images?: Array<{ data: string; mimeType: string; filename?: string }>
	) => void
	promptInputRef: RefObject<HTMLTextAreaElement>
	isPending: boolean
	handleStopRequest?: () => void
	isStreaming?: boolean
	placeholder: string
	restoreRequest?: {
		key: number
		text: string
		entities?: Array<{ term: string; slug: string }>
	} | null
	isResearchMode: boolean
	setIsResearchMode: Dispatch<SetStateAction<boolean>>
	researchUsage?: ResearchUsage | null
	droppedFiles?: File[] | null
	clearDroppedFiles?: () => void
	externalDragging?: boolean
	onOpenAlerts?: () => void
}

const trackSubmit = () => {
	if (typeof window !== 'undefined' && (window as any).umami) {
		;(window as any).umami.track('llamaai-prompt-submit')
	}
}

export function PromptInput({
	handleSubmit,
	promptInputRef,
	isPending,
	handleStopRequest,
	isStreaming,
	placeholder,
	restoreRequest,
	isResearchMode,
	setIsResearchMode,
	researchUsage,
	droppedFiles,
	clearDroppedFiles,
	externalDragging,
	onOpenAlerts
}: PromptInputProps) {
	const [value, setValue] = useState('')
	const highlightRef = useRef<HTMLDivElement>(null)

	// Image upload handling
	const imageUpload = useImageUpload({ droppedFiles, clearDroppedFiles })

	// Entity combobox handling
	const entityCombobox = useEntityCombobox({
		promptInputRef,
		highlightRef,
		setValue
	})

	// Mobile placeholder handling
	const isMobile = useMedia('(max-width: 640px)')
	const mobilePlaceholder = placeholder.replace('Type @ to add a protocol, chain or stablecoin', '')
	const finalPlaceholder = isMobile ? mobilePlaceholder : placeholder

	// Handle restore request (e.g., failed submission retry)
	useEffect(() => {
		if (!restoreRequest) return
		const textarea = promptInputRef.current
		if (!textarea) return
		if (textarea.value.trim().length > 0) return

		let cancelled = false
		const { text, entities } = restoreRequest

		entityCombobox.restoreEntities(entities)
		entityCombobox.setIsProgrammaticUpdate(true)
		textarea.value = text
		queueMicrotask(() => {
			if (cancelled) return
			setValue(text)
		})
		setInputSize(promptInputRef, highlightRef)

		if (highlightRef.current) {
			highlightRef.current.innerHTML = highlightWord(text, Array.from(entityCombobox.entitiesRef.current))
		}

		entityCombobox.clearSearch()

		return () => {
			cancelled = true
		}
	}, [restoreRequest, entityCombobox, promptInputRef])

	// Focus input after external drop
	useEffect(() => {
		if (droppedFiles && droppedFiles.length > 0) {
			promptInputRef.current?.focus()
		}
	}, [droppedFiles, promptInputRef])

	const resetInput = (shouldRevoke = true) => {
		setValue('')
		imageUpload.clearImages(shouldRevoke)
		entityCombobox.resetCombobox()
		const textarea = promptInputRef.current
		if (textarea) {
			textarea.value = ''
			textarea.style.height = ''
		}
		if (highlightRef.current) {
			highlightRef.current.innerHTML = ''
			highlightRef.current.textContent = ''
			highlightRef.current.style.height = ''
		}
	}

	const submitForm = async (promptValue: string) => {
		trackSubmit()
		const finalEntities = entityCombobox.getFinalEntities()
		const imagesToSend = [...imageUpload.selectedImages]
		const hasImages = imagesToSend.length > 0

		resetInput(!hasImages)

		if (hasImages) {
			const processAndSubmitImages = async () => {
				const imagePromises: Promise<{ data: string; mimeType: string; filename: string }>[] = []
				for (let i = 0; i < imagesToSend.length; i++) {
					const file = imagesToSend[i].file
					imagePromises.push(
						fileToBase64(file).then((data) => ({
							data,
							mimeType: file.type,
							filename: file.name
						}))
					)
				}
				const images = await Promise.all(imagePromises)
				await handleSubmit(promptValue, finalEntities, images)
			}
			try {
				await processAndSubmitImages()
			} catch (error) {
				console.error('Submission failed', error)
			}
			revokeImageUrls(imagesToSend)
		} else {
			handleSubmit(promptValue, finalEntities)
		}
	}

	const handleKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
		// First let entity combobox handle the event
		entityCombobox.handleKeyDown(event)
		if (event.defaultPrevented) return

		// Handle enter for submission
		if (event.key === 'Enter' && !event.shiftKey && !entityCombobox.hasRenderedItems) {
			event.preventDefault()
			if (isStreaming) return
			const promptValue = promptInputRef.current?.value ?? ''
			submitForm(promptValue)
		}
	}

	const handleChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
		if (promptInputRef.current) {
			setInputSize(promptInputRef, highlightRef)
		}
		entityCombobox.handleChange(event.target.value)
	}

	const handleScroll = () => {
		syncHighlightScroll(promptInputRef, highlightRef)
		entityCombobox.handleScroll()
	}

	const handleFormSubmit = (e: FormSubmitEvent) => {
		e.preventDefault()
		const form = e.currentTarget
		const promptValue = (form.elements.namedItem('prompt') as HTMLTextAreaElement | null)?.value ?? ''
		submitForm(promptValue)
	}

	const handleFormClick = (e: React.MouseEvent<HTMLFormElement>) => {
		const target = e.target as HTMLElement
		if (!target.closest('button')) {
			promptInputRef.current?.focus()
		}
	}

	return (
		<form
			className="relative flex w-full flex-col gap-4 rounded-lg border border-[#e6e6e6] bg-(--app-bg) p-4 has-[textarea:focus]:border-(--old-blue) dark:border-[#222324]"
			onDragEnter={imageUpload.handleDragEnter}
			onDragLeave={imageUpload.handleDragLeave}
			onDragOver={(e) => e.preventDefault()}
			onDrop={imageUpload.handleDrop}
			onSubmit={handleFormSubmit}
			onClick={handleFormClick}
		>
			<DragOverlay isDragging={imageUpload.isDragging} externalDragging={externalDragging} />

			<ImageUpload
				selectedImages={imageUpload.selectedImages}
				previewImage={imageUpload.previewImage}
				setPreviewImage={imageUpload.setPreviewImage}
				removeImage={imageUpload.removeImage}
				fileInputRef={imageUpload.fileInputRef}
				handleImageSelect={imageUpload.handleImageSelect}
			/>

			<InputTextarea
				combobox={entityCombobox.combobox}
				promptInputRef={promptInputRef}
				highlightRef={highlightRef}
				value={value}
				placeholder={finalPlaceholder}
				isPending={isPending}
				isStreaming={isStreaming}
				onScroll={handleScroll}
				onChange={handleChange}
				onKeyDown={handleKeyDown}
				onPaste={imageUpload.handlePaste}
				onCompositionStart={entityCombobox.handleCompositionStart}
				onCompositionEnd={entityCombobox.handleCompositionEnd}
			/>

			<EntityComboboxPopover
				combobox={entityCombobox.combobox}
				promptInputRef={promptInputRef}
				matches={entityCombobox.matches}
				hasMatches={entityCombobox.hasMatches}
				isTriggerOnly={entityCombobox.isTriggerOnly}
				isLoading={entityCombobox.isLoading}
				isFetching={entityCombobox.isFetching}
				onItemClick={entityCombobox.selectEntity}
			/>

			<div className="flex flex-wrap items-center justify-between gap-4 p-0">
				<div className="flex items-center gap-2">
					<ModeToggle
						isResearchMode={isResearchMode}
						setIsResearchMode={setIsResearchMode}
						researchUsage={researchUsage}
					/>
					{onOpenAlerts && (
						<Tooltip
							content="Manage Alerts"
							render={<button type="button" onClick={onOpenAlerts} />}
							className="flex h-7 w-7 items-center justify-center rounded-md bg-amber-500/12 text-amber-500 hover:bg-amber-500 hover:text-white"
						>
							<Icon name="calendar-plus" height={14} width={14} />
							<span className="sr-only">Manage Alerts</span>
						</Tooltip>
					)}
				</div>
				<div className="flex items-center gap-2">
					<ImageUploadButton onClick={imageUpload.openFilePicker} />
					<SubmitButton
						isStreaming={isStreaming}
						isPending={isPending}
						hasValue={value.trim().length > 0}
						onStop={handleStopRequest}
					/>
				</div>
			</div>
		</form>
	)
}
