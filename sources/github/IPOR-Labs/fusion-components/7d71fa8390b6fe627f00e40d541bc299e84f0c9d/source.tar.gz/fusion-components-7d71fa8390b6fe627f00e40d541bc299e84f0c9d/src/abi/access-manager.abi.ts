import { type Abi } from 'viem';

export const accessManagerAbi = [
  {
    type: 'constructor',
    inputs: [
      {
        name: 'initialAdmin_',
        type: 'address',
        internalType: 'address',
      },
    ],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'ADMIN_ROLE',
    inputs: [],
    outputs: [
      {
        name: '',
        type: 'uint64',
        internalType: 'uint64',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'PUBLIC_ROLE',
    inputs: [],
    outputs: [
      {
        name: '',
        type: 'uint64',
        internalType: 'uint64',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'canCall',
    inputs: [
      {
        name: 'caller',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'target',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'selector',
        type: 'bytes4',
        internalType: 'bytes4',
      },
    ],
    outputs: [
      {
        name: 'immediate',
        type: 'bool',
        internalType: 'bool',
      },
      {
        name: 'delay',
        type: 'uint32',
        internalType: 'uint32',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'canCallAndUpdate',
    inputs: [
      {
        name: 'caller_',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'target_',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'selector_',
        type: 'bytes4',
        internalType: 'bytes4',
      },
    ],
    outputs: [
      {
        name: 'immediate',
        type: 'bool',
        internalType: 'bool',
      },
      {
        name: 'delay',
        type: 'uint32',
        internalType: 'uint32',
      },
    ],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'cancel',
    inputs: [
      {
        name: 'caller',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'target',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'data',
        type: 'bytes',
        internalType: 'bytes',
      },
    ],
    outputs: [
      {
        name: '',
        type: 'uint32',
        internalType: 'uint32',
      },
    ],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'consumeScheduledOp',
    inputs: [
      {
        name: 'caller',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'data',
        type: 'bytes',
        internalType: 'bytes',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'convertToPublicVault',
    inputs: [
      {
        name: 'vault_',
        type: 'address',
        internalType: 'address',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'enableTransferShares',
    inputs: [
      {
        name: 'vault_',
        type: 'address',
        internalType: 'address',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'execute',
    inputs: [
      {
        name: 'target',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'data',
        type: 'bytes',
        internalType: 'bytes',
      },
    ],
    outputs: [
      {
        name: '',
        type: 'uint32',
        internalType: 'uint32',
      },
    ],
    stateMutability: 'payable',
  },
  {
    type: 'function',
    name: 'expiration',
    inputs: [],
    outputs: [
      {
        name: '',
        type: 'uint32',
        internalType: 'uint32',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getAccess',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        internalType: 'uint64',
      },
      {
        name: 'account',
        type: 'address',
        internalType: 'address',
      },
    ],
    outputs: [
      {
        name: 'since',
        type: 'uint48',
        internalType: 'uint48',
      },
      {
        name: 'currentDelay',
        type: 'uint32',
        internalType: 'uint32',
      },
      {
        name: 'pendingDelay',
        type: 'uint32',
        internalType: 'uint32',
      },
      {
        name: 'effect',
        type: 'uint48',
        internalType: 'uint48',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getAccountLockTime',
    inputs: [
      {
        name: 'account_',
        type: 'address',
        internalType: 'address',
      },
    ],
    outputs: [
      {
        name: '',
        type: 'uint256',
        internalType: 'uint256',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getMinimalExecutionDelayForRole',
    inputs: [
      {
        name: 'roleId_',
        type: 'uint64',
        internalType: 'uint64',
      },
    ],
    outputs: [
      {
        name: '',
        type: 'uint256',
        internalType: 'uint256',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getNonce',
    inputs: [
      {
        name: 'id',
        type: 'bytes32',
        internalType: 'bytes32',
      },
    ],
    outputs: [
      {
        name: '',
        type: 'uint32',
        internalType: 'uint32',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getRedemptionDelay',
    inputs: [],
    outputs: [
      {
        name: '',
        type: 'uint256',
        internalType: 'uint256',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getRoleAdmin',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        internalType: 'uint64',
      },
    ],
    outputs: [
      {
        name: '',
        type: 'uint64',
        internalType: 'uint64',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getRoleGrantDelay',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        internalType: 'uint64',
      },
    ],
    outputs: [
      {
        name: '',
        type: 'uint32',
        internalType: 'uint32',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getRoleGuardian',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        internalType: 'uint64',
      },
    ],
    outputs: [
      {
        name: '',
        type: 'uint64',
        internalType: 'uint64',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getSchedule',
    inputs: [
      {
        name: 'id',
        type: 'bytes32',
        internalType: 'bytes32',
      },
    ],
    outputs: [
      {
        name: '',
        type: 'uint48',
        internalType: 'uint48',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getTargetAdminDelay',
    inputs: [
      {
        name: 'target',
        type: 'address',
        internalType: 'address',
      },
    ],
    outputs: [
      {
        name: '',
        type: 'uint32',
        internalType: 'uint32',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getTargetFunctionRole',
    inputs: [
      {
        name: 'target',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'selector',
        type: 'bytes4',
        internalType: 'bytes4',
      },
    ],
    outputs: [
      {
        name: '',
        type: 'uint64',
        internalType: 'uint64',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'grantRole',
    inputs: [
      {
        name: 'roleId_',
        type: 'uint64',
        internalType: 'uint64',
      },
      {
        name: 'account_',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'executionDelay_',
        type: 'uint32',
        internalType: 'uint32',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'hasRole',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        internalType: 'uint64',
      },
      {
        name: 'account',
        type: 'address',
        internalType: 'address',
      },
    ],
    outputs: [
      {
        name: 'isMember',
        type: 'bool',
        internalType: 'bool',
      },
      {
        name: 'executionDelay',
        type: 'uint32',
        internalType: 'uint32',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'hashOperation',
    inputs: [
      {
        name: 'caller',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'target',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'data',
        type: 'bytes',
        internalType: 'bytes',
      },
    ],
    outputs: [
      {
        name: '',
        type: 'bytes32',
        internalType: 'bytes32',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'initialize',
    inputs: [
      {
        name: 'initialData_',
        type: 'tuple',
        internalType: 'struct InitializationData',
        components: [
          {
            name: 'roleToFunctions',
            type: 'tuple[]',
            internalType: 'struct RoleToFunction[]',
            components: [
              {
                name: 'target',
                type: 'address',
                internalType: 'address',
              },
              {
                name: 'roleId',
                type: 'uint64',
                internalType: 'uint64',
              },
              {
                name: 'functionSelector',
                type: 'bytes4',
                internalType: 'bytes4',
              },
              {
                name: 'minimalExecutionDelay',
                type: 'uint256',
                internalType: 'uint256',
              },
            ],
          },
          {
            name: 'accountToRoles',
            type: 'tuple[]',
            internalType: 'struct AccountToRole[]',
            components: [
              {
                name: 'roleId',
                type: 'uint64',
                internalType: 'uint64',
              },
              {
                name: 'account',
                type: 'address',
                internalType: 'address',
              },
              {
                name: 'executionDelay',
                type: 'uint32',
                internalType: 'uint32',
              },
            ],
          },
          {
            name: 'adminRoles',
            type: 'tuple[]',
            internalType: 'struct AdminRole[]',
            components: [
              {
                name: 'roleId',
                type: 'uint64',
                internalType: 'uint64',
              },
              {
                name: 'adminRoleId',
                type: 'uint64',
                internalType: 'uint64',
              },
            ],
          },
          {
            name: 'redemptionDelay',
            type: 'uint256',
            internalType: 'uint256',
          },
        ],
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'isConsumingScheduledOp',
    inputs: [],
    outputs: [
      {
        name: '',
        type: 'bytes4',
        internalType: 'bytes4',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'isTargetClosed',
    inputs: [
      {
        name: 'target',
        type: 'address',
        internalType: 'address',
      },
    ],
    outputs: [
      {
        name: '',
        type: 'bool',
        internalType: 'bool',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'labelRole',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        internalType: 'uint64',
      },
      {
        name: 'label',
        type: 'string',
        internalType: 'string',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'minSetback',
    inputs: [],
    outputs: [
      {
        name: '',
        type: 'uint32',
        internalType: 'uint32',
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'multicall',
    inputs: [
      {
        name: 'data',
        type: 'bytes[]',
        internalType: 'bytes[]',
      },
    ],
    outputs: [
      {
        name: 'results',
        type: 'bytes[]',
        internalType: 'bytes[]',
      },
    ],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'renounceRole',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        internalType: 'uint64',
      },
      {
        name: 'callerConfirmation',
        type: 'address',
        internalType: 'address',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'revokeRole',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        internalType: 'uint64',
      },
      {
        name: 'account',
        type: 'address',
        internalType: 'address',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'schedule',
    inputs: [
      {
        name: 'target',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'data',
        type: 'bytes',
        internalType: 'bytes',
      },
      {
        name: 'when',
        type: 'uint48',
        internalType: 'uint48',
      },
    ],
    outputs: [
      {
        name: 'operationId',
        type: 'bytes32',
        internalType: 'bytes32',
      },
      {
        name: 'nonce',
        type: 'uint32',
        internalType: 'uint32',
      },
    ],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'setGrantDelay',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        internalType: 'uint64',
      },
      {
        name: 'newDelay',
        type: 'uint32',
        internalType: 'uint32',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'setMinimalExecutionDelaysForRoles',
    inputs: [
      {
        name: 'rolesIds_',
        type: 'uint64[]',
        internalType: 'uint64[]',
      },
      {
        name: 'delays_',
        type: 'uint256[]',
        internalType: 'uint256[]',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'setRedemptionDelay',
    inputs: [
      {
        name: 'delay_',
        type: 'uint256',
        internalType: 'uint256',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'setRoleAdmin',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        internalType: 'uint64',
      },
      {
        name: 'admin',
        type: 'uint64',
        internalType: 'uint64',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'setRoleGuardian',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        internalType: 'uint64',
      },
      {
        name: 'guardian',
        type: 'uint64',
        internalType: 'uint64',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'setTargetAdminDelay',
    inputs: [
      {
        name: 'target',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'newDelay',
        type: 'uint32',
        internalType: 'uint32',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'setTargetClosed',
    inputs: [
      {
        name: 'target',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'closed',
        type: 'bool',
        internalType: 'bool',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'setTargetFunctionRole',
    inputs: [
      {
        name: 'target',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'selectors',
        type: 'bytes4[]',
        internalType: 'bytes4[]',
      },
      {
        name: 'roleId',
        type: 'uint64',
        internalType: 'uint64',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'updateAuthority',
    inputs: [
      {
        name: 'target',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'newAuthority',
        type: 'address',
        internalType: 'address',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'updateTargetClosed',
    inputs: [
      {
        name: 'target_',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'closed_',
        type: 'bool',
        internalType: 'bool',
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'event',
    name: 'IporFusionAccessManagerInitialized',
    inputs: [],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'MinimalExecutionDelayForRoleUpdated',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        indexed: false,
        internalType: 'uint64',
      },
      {
        name: 'delay',
        type: 'uint256',
        indexed: false,
        internalType: 'uint256',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'OperationCanceled',
    inputs: [
      {
        name: 'operationId',
        type: 'bytes32',
        indexed: true,
        internalType: 'bytes32',
      },
      {
        name: 'nonce',
        type: 'uint32',
        indexed: true,
        internalType: 'uint32',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'OperationExecuted',
    inputs: [
      {
        name: 'operationId',
        type: 'bytes32',
        indexed: true,
        internalType: 'bytes32',
      },
      {
        name: 'nonce',
        type: 'uint32',
        indexed: true,
        internalType: 'uint32',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'OperationScheduled',
    inputs: [
      {
        name: 'operationId',
        type: 'bytes32',
        indexed: true,
        internalType: 'bytes32',
      },
      {
        name: 'nonce',
        type: 'uint32',
        indexed: true,
        internalType: 'uint32',
      },
      {
        name: 'schedule',
        type: 'uint48',
        indexed: false,
        internalType: 'uint48',
      },
      {
        name: 'caller',
        type: 'address',
        indexed: false,
        internalType: 'address',
      },
      {
        name: 'target',
        type: 'address',
        indexed: false,
        internalType: 'address',
      },
      {
        name: 'data',
        type: 'bytes',
        indexed: false,
        internalType: 'bytes',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'RedemptionDelayForAccountUpdated',
    inputs: [
      {
        name: 'account',
        type: 'address',
        indexed: false,
        internalType: 'address',
      },
      {
        name: 'redemptionDelay',
        type: 'uint256',
        indexed: false,
        internalType: 'uint256',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'RedemptionDelayUpdated',
    inputs: [
      {
        name: 'redemptionDelay',
        type: 'uint256',
        indexed: false,
        internalType: 'uint256',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'RoleAdminChanged',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        indexed: true,
        internalType: 'uint64',
      },
      {
        name: 'admin',
        type: 'uint64',
        indexed: true,
        internalType: 'uint64',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'RoleGrantDelayChanged',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        indexed: true,
        internalType: 'uint64',
      },
      {
        name: 'delay',
        type: 'uint32',
        indexed: false,
        internalType: 'uint32',
      },
      {
        name: 'since',
        type: 'uint48',
        indexed: false,
        internalType: 'uint48',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'RoleGranted',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        indexed: true,
        internalType: 'uint64',
      },
      {
        name: 'account',
        type: 'address',
        indexed: true,
        internalType: 'address',
      },
      {
        name: 'delay',
        type: 'uint32',
        indexed: false,
        internalType: 'uint32',
      },
      {
        name: 'since',
        type: 'uint48',
        indexed: false,
        internalType: 'uint48',
      },
      {
        name: 'newMember',
        type: 'bool',
        indexed: false,
        internalType: 'bool',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'RoleGuardianChanged',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        indexed: true,
        internalType: 'uint64',
      },
      {
        name: 'guardian',
        type: 'uint64',
        indexed: true,
        internalType: 'uint64',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'RoleLabel',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        indexed: true,
        internalType: 'uint64',
      },
      {
        name: 'label',
        type: 'string',
        indexed: false,
        internalType: 'string',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'RoleRevoked',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        indexed: true,
        internalType: 'uint64',
      },
      {
        name: 'account',
        type: 'address',
        indexed: true,
        internalType: 'address',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'TargetAdminDelayUpdated',
    inputs: [
      {
        name: 'target',
        type: 'address',
        indexed: true,
        internalType: 'address',
      },
      {
        name: 'delay',
        type: 'uint32',
        indexed: false,
        internalType: 'uint32',
      },
      {
        name: 'since',
        type: 'uint48',
        indexed: false,
        internalType: 'uint48',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'TargetClosed',
    inputs: [
      {
        name: 'target',
        type: 'address',
        indexed: true,
        internalType: 'address',
      },
      {
        name: 'closed',
        type: 'bool',
        indexed: false,
        internalType: 'bool',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'TargetFunctionRoleUpdated',
    inputs: [
      {
        name: 'target',
        type: 'address',
        indexed: true,
        internalType: 'address',
      },
      {
        name: 'selector',
        type: 'bytes4',
        indexed: false,
        internalType: 'bytes4',
      },
      {
        name: 'roleId',
        type: 'uint64',
        indexed: true,
        internalType: 'uint64',
      },
    ],
    anonymous: false,
  },
  {
    type: 'error',
    name: 'AccessManagedUnauthorized',
    inputs: [
      {
        name: 'caller',
        type: 'address',
        internalType: 'address',
      },
    ],
  },
  {
    type: 'error',
    name: 'AccessManagerAlreadyScheduled',
    inputs: [
      {
        name: 'operationId',
        type: 'bytes32',
        internalType: 'bytes32',
      },
    ],
  },
  {
    type: 'error',
    name: 'AccessManagerBadConfirmation',
    inputs: [],
  },
  {
    type: 'error',
    name: 'AccessManagerExpired',
    inputs: [
      {
        name: 'operationId',
        type: 'bytes32',
        internalType: 'bytes32',
      },
    ],
  },
  {
    type: 'error',
    name: 'AccessManagerInvalidInitialAdmin',
    inputs: [
      {
        name: 'initialAdmin',
        type: 'address',
        internalType: 'address',
      },
    ],
  },
  {
    type: 'error',
    name: 'AccessManagerLockedAccount',
    inputs: [
      {
        name: 'account',
        type: 'address',
        internalType: 'address',
      },
    ],
  },
  {
    type: 'error',
    name: 'AccessManagerLockedRole',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        internalType: 'uint64',
      },
    ],
  },
  {
    type: 'error',
    name: 'AccessManagerNotReady',
    inputs: [
      {
        name: 'operationId',
        type: 'bytes32',
        internalType: 'bytes32',
      },
    ],
  },
  {
    type: 'error',
    name: 'AccessManagerNotScheduled',
    inputs: [
      {
        name: 'operationId',
        type: 'bytes32',
        internalType: 'bytes32',
      },
    ],
  },
  {
    type: 'error',
    name: 'AccessManagerUnauthorizedAccount',
    inputs: [
      {
        name: 'msgsender',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'roleId',
        type: 'uint64',
        internalType: 'uint64',
      },
    ],
  },
  {
    type: 'error',
    name: 'AccessManagerUnauthorizedCall',
    inputs: [
      {
        name: 'caller',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'target',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'selector',
        type: 'bytes4',
        internalType: 'bytes4',
      },
    ],
  },
  {
    type: 'error',
    name: 'AccessManagerUnauthorizedCancel',
    inputs: [
      {
        name: 'msgsender',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'caller',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'target',
        type: 'address',
        internalType: 'address',
      },
      {
        name: 'selector',
        type: 'bytes4',
        internalType: 'bytes4',
      },
    ],
  },
  {
    type: 'error',
    name: 'AccessManagerUnauthorizedConsume',
    inputs: [
      {
        name: 'target',
        type: 'address',
        internalType: 'address',
      },
    ],
  },
  {
    type: 'error',
    name: 'AccountIsLocked',
    inputs: [
      {
        name: 'unlockTime',
        type: 'uint256',
        internalType: 'uint256',
      },
    ],
  },
  {
    type: 'error',
    name: 'AddressEmptyCode',
    inputs: [
      {
        name: 'target',
        type: 'address',
        internalType: 'address',
      },
    ],
  },
  {
    type: 'error',
    name: 'AddressInsufficientBalance',
    inputs: [
      {
        name: 'account',
        type: 'address',
        internalType: 'address',
      },
    ],
  },
  {
    type: 'error',
    name: 'AlreadyInitialized',
    inputs: [],
  },
  {
    type: 'error',
    name: 'FailedInnerCall',
    inputs: [],
  },
  {
    type: 'error',
    name: 'SafeCastOverflowedUintDowncast',
    inputs: [
      {
        name: 'bits',
        type: 'uint8',
        internalType: 'uint8',
      },
      {
        name: 'value',
        type: 'uint256',
        internalType: 'uint256',
      },
    ],
  },
  {
    type: 'error',
    name: 'TooShortExecutionDelayForRole',
    inputs: [
      {
        name: 'roleId',
        type: 'uint64',
        internalType: 'uint64',
      },
      {
        name: 'executionDelay',
        type: 'uint32',
        internalType: 'uint32',
      },
    ],
  },
] as const satisfies Abi;
