import type { Abi } from "viem";

export const withdrawManagerAbi = [
  {
    type: 'constructor',
    inputs: [
      { name: 'accessManager_', type: 'address', internalType: 'address' },
    ],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'authority',
    inputs: [],
    outputs: [{ name: '', type: 'address', internalType: 'address' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'canWithdrawFromRequest',
    inputs: [
      { name: 'account_', type: 'address', internalType: 'address' },
      { name: 'shares_', type: 'uint256', internalType: 'uint256' },
    ],
    outputs: [{ name: '', type: 'bool', internalType: 'bool' }],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'canWithdrawFromUnallocated',
    inputs: [{ name: 'shares_', type: 'uint256', internalType: 'uint256' }],
    outputs: [{ name: '', type: 'uint256', internalType: 'uint256' }],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'clearContext',
    inputs: [],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'getLastReleaseFundsTimestamp',
    inputs: [],
    outputs: [{ name: '', type: 'uint256', internalType: 'uint256' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getPlasmaVaultAddress',
    inputs: [],
    outputs: [{ name: '', type: 'address', internalType: 'address' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getRequestFee',
    inputs: [],
    outputs: [{ name: '', type: 'uint256', internalType: 'uint256' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getSharesToRelease',
    inputs: [],
    outputs: [{ name: '', type: 'uint256', internalType: 'uint256' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getWithdrawFee',
    inputs: [],
    outputs: [{ name: '', type: 'uint256', internalType: 'uint256' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getWithdrawWindow',
    inputs: [],
    outputs: [{ name: '', type: 'uint256', internalType: 'uint256' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'isConsumingScheduledOp',
    inputs: [],
    outputs: [{ name: '', type: 'bytes4', internalType: 'bytes4' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'releaseFunds',
    inputs: [
      { name: 'timestamp_', type: 'uint256', internalType: 'uint256' },
      { name: 'sharesToRelease_', type: 'uint256', internalType: 'uint256' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'requestInfo',
    inputs: [{ name: 'account_', type: 'address', internalType: 'address' }],
    outputs: [
      {
        name: '',
        type: 'tuple',
        internalType: 'struct WithdrawRequestInfo',
        components: [
          { name: 'shares', type: 'uint256', internalType: 'uint256' },
          {
            name: 'endWithdrawWindowTimestamp',
            type: 'uint256',
            internalType: 'uint256',
          },
          { name: 'canWithdraw', type: 'bool', internalType: 'bool' },
          {
            name: 'withdrawWindowInSeconds',
            type: 'uint256',
            internalType: 'uint256',
          },
        ],
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'requestShares',
    inputs: [{ name: 'shares_', type: 'uint256', internalType: 'uint256' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'setAuthority',
    inputs: [
      { name: 'newAuthority', type: 'address', internalType: 'address' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'setupContext',
    inputs: [{ name: 'sender_', type: 'address', internalType: 'address' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'updatePlasmaVaultAddress',
    inputs: [
      { name: 'plasmaVaultAddress_', type: 'address', internalType: 'address' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'updateRequestFee',
    inputs: [{ name: 'fee_', type: 'uint256', internalType: 'uint256' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'updateWithdrawFee',
    inputs: [{ name: 'fee_', type: 'uint256', internalType: 'uint256' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'updateWithdrawWindow',
    inputs: [{ name: 'window_', type: 'uint256', internalType: 'uint256' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'event',
    name: 'AuthorityUpdated',
    inputs: [
      {
        name: 'authority',
        type: 'address',
        indexed: false,
        internalType: 'address',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'ContextCleared',
    inputs: [
      {
        name: 'sender_',
        type: 'address',
        indexed: true,
        internalType: 'address',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'ContextSet',
    inputs: [
      {
        name: 'sender_',
        type: 'address',
        indexed: true,
        internalType: 'address',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'Initialized',
    inputs: [
      {
        name: 'version',
        type: 'uint64',
        indexed: false,
        internalType: 'uint64',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'PlasmaVaultAddressUpdated',
    inputs: [
      {
        name: 'plasmaVaultAddress',
        type: 'address',
        indexed: false,
        internalType: 'address',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'ReleaseFundsUpdated',
    inputs: [
      {
        name: 'releaseTimestamp',
        type: 'uint32',
        indexed: false,
        internalType: 'uint32',
      },
      {
        name: 'sharesToRelease',
        type: 'uint128',
        indexed: false,
        internalType: 'uint128',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'RequestFeeUpdated',
    inputs: [
      { name: 'fee', type: 'uint256', indexed: false, internalType: 'uint256' },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'WithdrawFeeUpdated',
    inputs: [
      { name: 'fee', type: 'uint256', indexed: false, internalType: 'uint256' },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'WithdrawRequestUpdated',
    inputs: [
      {
        name: 'account',
        type: 'address',
        indexed: false,
        internalType: 'address',
      },
      {
        name: 'amount',
        type: 'uint256',
        indexed: false,
        internalType: 'uint256',
      },
      {
        name: 'endWithdrawWindow',
        type: 'uint32',
        indexed: false,
        internalType: 'uint32',
      },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'WithdrawWindowLengthUpdated',
    inputs: [
      {
        name: 'withdrawWindowLength',
        type: 'uint256',
        indexed: false,
        internalType: 'uint256',
      },
    ],
    anonymous: false,
  },
  {
    type: 'error',
    name: 'AccessManagedInvalidAuthority',
    inputs: [{ name: 'authority', type: 'address', internalType: 'address' }],
  },
  {
    type: 'error',
    name: 'AccessManagedRequiredDelay',
    inputs: [
      { name: 'caller', type: 'address', internalType: 'address' },
      { name: 'delay', type: 'uint32', internalType: 'uint32' },
    ],
  },
  {
    type: 'error',
    name: 'AccessManagedUnauthorized',
    inputs: [{ name: 'caller', type: 'address', internalType: 'address' }],
  },
  { type: 'error', name: 'ContextAlreadySet', inputs: [] },
  { type: 'error', name: 'ContextNotSet', inputs: [] },
  { type: 'error', name: 'InvalidInitialization', inputs: [] },
  { type: 'error', name: 'MathOverflowedMulDiv', inputs: [] },
  { type: 'error', name: 'NotInitializing', inputs: [] },
  { type: 'error', name: 'PlasmaVaultAddressCannotBeZero', inputs: [] },
  {
    type: 'error',
    name: 'SafeCastOverflowedUintDowncast',
    inputs: [
      { name: 'bits', type: 'uint8', internalType: 'uint8' },
      { name: 'value', type: 'uint256', internalType: 'uint256' },
    ],
  },
  { type: 'error', name: 'UnauthorizedSender', inputs: [] },
  {
    type: 'error',
    name: 'WithdrawManagerInvalidFee',
    inputs: [{ name: 'fee', type: 'uint256', internalType: 'uint256' }],
  },
  {
    type: 'error',
    name: 'WithdrawManagerInvalidSharesToRelease',
    inputs: [
      { name: 'sharesToRelease', type: 'uint256', internalType: 'uint256' },
      { name: 'shares', type: 'uint256', internalType: 'uint256' },
      {
        name: 'plasmaVaultBalanceOfUnallocatedShares',
        type: 'uint256',
        internalType: 'uint256',
      },
    ],
  },
  {
    type: 'error',
    name: 'WithdrawManagerInvalidSharesToRelease',
    inputs: [{ name: 'amount_', type: 'uint256', internalType: 'uint256' }],
  },
  {
    type: 'error',
    name: 'WithdrawManagerInvalidTimestamp',
    inputs: [{ name: 'timestamp', type: 'uint256', internalType: 'uint256' }],
  },
  {
    type: 'error',
    name: 'WithdrawManagerInvalidTimestamp',
    inputs: [
      {
        name: 'lastReleaseFundsTimestamp',
        type: 'uint256',
        internalType: 'uint256',
      },
      {
        name: 'newReleaseFundsTimestamp',
        type: 'uint256',
        internalType: 'uint256',
      },
    ],
  },
  { type: 'error', name: 'WithdrawManagerZeroShares', inputs: [] },
  { type: 'error', name: 'WithdrawWindowLengthCannotBeZero', inputs: [] },
] as const satisfies Abi;
