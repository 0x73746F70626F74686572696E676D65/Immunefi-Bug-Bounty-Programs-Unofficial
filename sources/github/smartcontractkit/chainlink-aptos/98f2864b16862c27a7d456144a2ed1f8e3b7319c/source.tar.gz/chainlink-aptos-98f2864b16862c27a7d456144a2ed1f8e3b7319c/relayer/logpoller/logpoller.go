package logpoller

import (
	"bytes"
	"context"
	"fmt"
	"sync"
	"time"

	"github.com/patrickmn/go-cache"

	"github.com/aptos-labs/aptos-go-sdk"

	"github.com/smartcontractkit/chainlink-common/pkg/logger"
	"github.com/smartcontractkit/chainlink-common/pkg/sqlutil"
	commonutils "github.com/smartcontractkit/chainlink-common/pkg/utils"

	"github.com/smartcontractkit/chainlink-aptos/relayer/chainreader/db"
	"github.com/smartcontractkit/chainlink-aptos/relayer/types"
	aptos0 "github.com/smartcontractkit/chainlink-common/pkg/types/aptos"
)

// eventStore is the narrow DB interface used by syncEvent. The concrete type
// *db.DBStore satisfies it; unit tests substitute a fake implementation.
type eventStore interface {
	GetLatestEventMeta(ctx context.Context, eventAccountAddress, eventHandle, eventFieldName string) (offset, txVersion uint64, found bool, err error)
	InsertEvents(ctx context.Context, records []db.EventRecord) error
}

// OldestLedgerVersionProvider exposes the most recently captured
// X-APTOS-LEDGER-OLDEST-VERSION response header. The chain wires a
// HeaderCapturingRoundTripper into the Aptos node's *http.Client and implements this
// interface so syncEvent can detect pruning on the non-empty events path (HTTP 200 +
// events whose tx_version < oldest_ledger_version). Returns (value, true) when a valid
// header has been captured; (0, false) when unavailable (syncEvent falls back to Info()).
type OldestLedgerVersionProvider interface {
	LastOldestLedgerVersion() (uint64, bool)
}

type moduleInfo struct {
	name         string
	address      aptos.AccountAddress
	eventConfigs map[string]*aptos0.ContractReaderEvent
	refCount     int
}

type AptosLogPoller struct {
	lggr      logger.Logger
	dbStore   *db.DBStore
	evStore   eventStore // narrow interface used by syncEvent; set to dbStore by default
	config    *Config
	getClient func() (aptos.AptosRpcClient, error)
	chainInfo types.ChainInfo

	// oldestLedgerVersionProvider, when set, exposes the X-APTOS-LEDGER-OLDEST-VERSION
	// response header captured by the chain's HeaderCapturingRoundTripper. Used by
	// syncEvent to detect pruning on the non-empty events path. Optional: when nil,
	// syncEvent falls back to an Info() call. Set via SetOldestLedgerVersionProvider.
	oldestLedgerVersionProvider OldestLedgerVersionProvider

	mu      sync.RWMutex
	modules map[string]*moduleInfo

	// warned tracks per-handle pruned/gap warning state. Key = handleKey(eventHandle, eventFieldName).
	// Value = time the warning was first raised. The CR does NOT halt on missing events; this
	// state drives the aptos_log_poller_pruned_warning_active gauge (paging signal for the NOP)
	// and rate-limits warning logs. Auto-clears when a subsequent sync succeeds past the pruned
	// range (see syncEvent auto-recovery). HealthReport stays healthy.
	warned map[string]time.Time

	// cache
	resourceCache            *cache.Cache
	blockCache               *cache.Cache
	eventAccountAddressCache *cache.Cache
	cacheCleanupInterval     time.Duration

	starter        commonutils.StartStopOnce
	eventCtxCancel context.CancelFunc
	txCtxCancel    context.CancelFunc
}

// handleKey builds the composite key used to track per-handle warning state.
func handleKey(eventHandle, eventFieldName string) string {
	return eventHandle + "::" + eventFieldName
}

// markWarned records that a handle is in a pruned/gap warning state. Returns true if this
// is a new warning (first transition into the warned state for this handle), false if the
// handle was already warned. The first-warned time is preserved across repeated calls so
// the NOP can see how long the condition has persisted. Caller must hold l.mu.
func (l *AptosLogPoller) markWarned(key string) bool {
	if l.warned == nil {
		l.warned = make(map[string]time.Time)
	}
	if _, already := l.warned[key]; already {
		return false
	}
	l.warned[key] = time.Now()
	return true
}

// isWarned reports whether a handle is currently in a pruned/gap warning state.
// Caller must hold l.mu (at least RLock).
func (l *AptosLogPoller) isWarned(key string) bool {
	_, ok := l.warned[key]
	return ok
}

// clearWarned removes a handle from the warned state (auto-recovery). Returns true if the
// handle was warned and is now cleared. Caller must hold l.mu.
func (l *AptosLogPoller) clearWarned(key string) bool {
	if _, ok := l.warned[key]; ok {
		delete(l.warned, key)
		return true
	}
	return false
}

func NewLogPoller(lggr logger.Logger, chainInfo types.ChainInfo, getClient func() (aptos.AptosRpcClient, error), ds sqlutil.DataSource, cfg *Config) (*AptosLogPoller, error) {
	if cfg == nil {
		tmp := DefaultConfigSet
		cfg = &tmp
	}

	dbStore := db.NewDBStore(ds, lggr)

	defaultTTL := 15 * time.Minute
	cleanupInterval := 30 * time.Minute

	return &AptosLogPoller{
		lggr:      logger.Named(lggr, "AptosLogPoller"),
		dbStore:   dbStore,
		evStore:   dbStore,
		config:    cfg,
		getClient: getClient,
		chainInfo: chainInfo,

		modules: make(map[string]*moduleInfo),
		warned:  make(map[string]time.Time),

		resourceCache:            cache.New(defaultTTL, cleanupInterval),
		blockCache:               cache.New(defaultTTL, cleanupInterval),
		eventAccountAddressCache: cache.New(defaultTTL, cleanupInterval),
		cacheCleanupInterval:     cleanupInterval,
	}, nil
}

func (l *AptosLogPoller) Start(ctx context.Context) error {
	return l.starter.StartOnce(l.Name(), func() error {
		if l.dbStore != nil {
			var syncEventCtx context.Context
			syncEventCtx, l.eventCtxCancel = context.WithCancel(context.Background())
			go l.startEventPolling(syncEventCtx)

			if *l.config.TXPollerDisabled {
				l.lggr.Info("Skipping transaction polling as TXPollerDisabled is set to true")
				return nil
			}

			var syncTxCtx context.Context
			syncTxCtx, l.txCtxCancel = context.WithCancel(context.Background())
			go l.startTxPolling(syncTxCtx)
		}

		return nil
	})
}

func (l *AptosLogPoller) Close() error {
	return l.starter.StopOnce(l.Name(), func() error {
		if l.eventCtxCancel != nil {
			l.eventCtxCancel()
		}

		if l.txCtxCancel != nil {
			l.txCtxCancel()
		}

		return nil
	})
}

func (l *AptosLogPoller) RegisterModule(ctx context.Context, moduleKey string, address aptos.AccountAddress, name string, eventConfigs map[string]*aptos0.ContractReaderEvent) error {
	l.mu.Lock()
	defer l.mu.Unlock()

	info, exists := l.modules[moduleKey]
	if exists {
		if !bytes.Equal(info.address[:], address[:]) {
			return fmt.Errorf("module %s already registered with different address", moduleKey)
		}

		info.refCount++
		l.lggr.Debugw("Incrementing ref count for module", "moduleKey", moduleKey, "newRefCount", info.refCount)
		return nil
	}

	l.lggr.Infow("Registering new module", "moduleKey", moduleKey, "address", address.String())
	l.modules[moduleKey] = &moduleInfo{
		name:         name,
		address:      address,
		eventConfigs: eventConfigs,
		refCount:     1,
	}

	return nil
}

func (l *AptosLogPoller) UnregisterModule(ctx context.Context, moduleKey string) error {
	l.mu.Lock()
	defer l.mu.Unlock()

	info, exists := l.modules[moduleKey]
	if !exists {
		return fmt.Errorf("module %s not registered", moduleKey)
	}

	info.refCount--
	l.lggr.Debugw("Decremented ref count for module", "moduleKey", moduleKey, "newRefCount", info.refCount)

	if info.refCount <= 0 {
		l.lggr.Infow("Removing module from logpoller", "moduleKey", moduleKey)
		delete(l.modules, moduleKey)
	}

	return nil
}

func (l *AptosLogPoller) Name() string {
	return l.lggr.Name()
}

func (l *AptosLogPoller) Ready() error {
	return l.starter.Ready()
}

func (l *AptosLogPoller) HealthReport() map[string]error {
	return map[string]error{l.Name(): l.starter.Healthy()}
}

// SetOldestLedgerVersionProvider wires the X-APTOS-LEDGER-OLDEST-VERSION header provider
// (backed by the chain's HeaderCapturingRoundTripper). Must be called before Start.
// When unset, syncEvent falls back to an Info() call for non-empty pruned detection.
func (l *AptosLogPoller) SetOldestLedgerVersionProvider(p OldestLedgerVersionProvider) {
	l.oldestLedgerVersionProvider = p
}

func (l *AptosLogPoller) getEventAccountAddress(cacheKey string) (aptos.AccountAddress, bool) {
	if value, found := l.eventAccountAddressCache.Get(cacheKey); found {
		return value.(aptos.AccountAddress), true
	}
	return aptos.AccountAddress{}, false
}

func (l *AptosLogPoller) setEventAccountAddress(cacheKey string, address aptos.AccountAddress) {
	l.eventAccountAddressCache.Set(cacheKey, address, cache.NoExpiration)
	l.lggr.Debugw("Cached event account address", "key", cacheKey, "address", address.String())
}

func (l *AptosLogPoller) getEventConfig(moduleKey, eventKey string) (aptos.AccountAddress, string, *aptos0.ContractReaderEvent, error) {
	l.mu.RLock()
	defer l.mu.RUnlock()

	moduleInfo, exists := l.modules[moduleKey]
	if !exists {
		return aptos.AccountAddress{}, "", nil, fmt.Errorf("module %s not registered", moduleKey)
	}

	eventConfig, exists := moduleInfo.eventConfigs[eventKey]
	if !exists {
		return aptos.AccountAddress{}, "", nil, fmt.Errorf("event %s not configured for module %s", eventKey, moduleKey)
	}

	eventAccountAddress, err := l.computeEventAccountAddress(moduleInfo.address, eventConfig)
	if err != nil {
		return aptos.AccountAddress{}, "", nil, fmt.Errorf("failed to compute event account address: %w", err)
	}

	eventHandle := moduleInfo.address.String() + "::" + moduleInfo.name + "::" + eventConfig.EventHandleStructName
	return eventAccountAddress, eventHandle, eventConfig, nil
}

func (l *AptosLogPoller) GetChainInfo() types.ChainInfo {
	return l.chainInfo
}
