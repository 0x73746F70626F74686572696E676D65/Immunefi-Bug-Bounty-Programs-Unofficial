#[test_only]
module regulated_token_pool::upgrade_v2 {
    use std::account::{Self};

    use regulated_token_pool::regulated_token_pool;

    fun init_module(publisher: &signer) {
        // register the pool on deployment, because in the case of object code deployment,
        // this is the only time we have a signer ref to @regulated_token_pool.

        // create an Account on the object for event handles.
        account::create_account_if_does_not_exist(@regulated_token_pool);

        // If the contract has already been deployed with V1 and needs to be upgraded to V2,
        // create a new module and pass in `publisher` from `fun init_module(publisher: &signer)`
        regulated_token_pool::register_v2_callbacks(publisher);
    }

    #[test_only]
    public fun test_init_module(publisher: &signer) {
        init_module(publisher);
    }
}
