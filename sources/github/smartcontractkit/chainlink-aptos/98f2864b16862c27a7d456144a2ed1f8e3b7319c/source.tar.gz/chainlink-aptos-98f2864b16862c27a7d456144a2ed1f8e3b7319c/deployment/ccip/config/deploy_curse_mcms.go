package config

import (
	"fmt"

	mcmstypes "github.com/smartcontractkit/mcms/types"

	cldf "github.com/smartcontractkit/chainlink-deployments-framework/deployment"
	cldfproposalutils "github.com/smartcontractkit/chainlink-deployments-framework/engine/cld/mcms/proposalutils"
)

// DeployCurseMCMSConfig holds per-chain configuration for deploying and
// configuring a CurseMCMS contract on Aptos chains.
type DeployCurseMCMSConfig struct {
	CurseMCMSConfigPerChain    map[uint64]cldfproposalutils.MCMSWithTimelockConfig
	MCMSTimelockConfigPerChain map[uint64]cldfproposalutils.TimelockConfig
	// ReplaceExisting allows this changeset to take datastore keys that are already
	// recorded, as an intentional redeploy of CurseMCMS does. Without it, an occupied key
	// is an error raised before anything is deployed.
	ReplaceExisting bool
}

func (c DeployCurseMCMSConfig) Validate() error {
	for cs, cfg := range c.CurseMCMSConfigPerChain {
		if err := cldf.IsValidChainSelector(cs); err != nil {
			return fmt.Errorf("invalid chain selector: %d - %w", cs, err)
		}
		for _, mcmsCfg := range []mcmstypes.Config{cfg.Bypasser, cfg.Canceller, cfg.Proposer} {
			if err := mcmsCfg.Validate(); err != nil {
				return fmt.Errorf("invalid MCMS config for chain %d: %w", cs, err)
			}
		}
	}
	return nil
}
