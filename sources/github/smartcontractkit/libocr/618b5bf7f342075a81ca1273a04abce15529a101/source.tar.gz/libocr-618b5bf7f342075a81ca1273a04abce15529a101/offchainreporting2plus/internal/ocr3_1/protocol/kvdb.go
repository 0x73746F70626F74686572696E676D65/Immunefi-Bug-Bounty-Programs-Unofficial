package protocol

import (
	"github.com/smartcontractkit/libocr/commontypes"
	"github.com/smartcontractkit/libocr/internal/jmt"
	"github.com/smartcontractkit/libocr/internal/util"
	"github.com/smartcontractkit/libocr/offchainreporting2plus/ocr3_1types"
	"github.com/smartcontractkit/libocr/offchainreporting2plus/types"
)

type KeyValueDatabaseReadTransaction interface {
	// The only read part of the interface that the plugin might see. The rest
	// of the methods might only be called by protocol code.
	ocr3_1types.KeyValueStateReader
	KeyValueDatabaseSemanticRead
	Discard()
}

type KeyValueDatabaseSemanticRead interface {
	// ReadHighestCommittedSeqNr returns the sequence number of which the state the transaction
	// represents. Really read from the database here, no cached values allowed.
	ReadHighestCommittedSeqNr() (uint64, error)
	ReadLowestPersistedSeqNr() (uint64, error)

	ReadAttestedStateTransitionBlock(seqNr uint64) (AttestedStateTransitionBlock, error)
	ReadAttestedStateTransitionBlocks(minSeqNr uint64, maxItems int) (blocks []AttestedStateTransitionBlock, more bool, err error)

	ExistsUnattestedStateTransitionBlock(seqNr uint64, stateTransitionInputsDigest StateTransitionInputsDigest) (bool, error)
	ReadUnattestedStateTransitionBlock(seqNr uint64, stateTransitionInputsDigest StateTransitionInputsDigest) (*StateTransitionBlock, error)

	// ReadRootVersions returns up to maxItems version numbers of tree roots at or
	// above minRootVersion, in ascending order. Intended for tooling/inspection.
	ReadRootVersions(minRootVersion jmt.Version, maxItems int) (versions []jmt.Version, more bool, err error)

	ReadTreeSyncStatus() (TreeSyncStatus, error)
	// ReadTreeSyncChunk retrieves a chunk of undigested key-value pairs in the
	// range [startIndex, requestEndInclIndex] of the key digest space. It
	// returns a maximally sized chunk that fully covers the range [startIndex,
	// endInclIndex], where endInclIndex <= requestEndInclIndex, such that the
	// chunk respects the protocol.MaxTreeSyncChunkKeys and
	// protocol.MaxTreeSyncChunkKeysPlusValuesLength limits. It also includes in
	// boundingLeaves the subrange proof, proving inclusion of key-values in the
	// range [startIndex, endInclIndex] without omissions.
	ReadTreeSyncChunk(
		toSeqNr uint64,
		startIndex jmt.Digest,
		requestEndInclIndex jmt.Digest,
		maxCumulativeKeysPlusValuesBytes int,
	) (
		endInclIndex jmt.Digest,
		boundingLeaves []jmt.BoundingLeaf,
		keyValues []KeyValuePair,
		err error,
	)
	// ReadBlobPayload returns the payload of the blob if it exists in full and
	// the blob has not expired. If the blob existed at some point but has since
	// expired, it returns an error. If the blob never existed, it returns nil.
	// If only some chunks are present, it returns an error.
	ReadBlobPayload(BlobDigest) ([]byte, error)
	ReadBlobMeta(BlobDigest) (*BlobMeta, error)
	ReadBlobDigestExpirySeqNrs(minBlobDigest BlobDigest, maxItems int) (_ []BlobDigestExpirySeqNr, more bool, _ error)
	ReadBlobQuotaStats(blobQuotaStatsType BlobQuotaStatsType, submitter commontypes.OracleID) (BlobQuotaStats, error)
	ReadBlobChunk(BlobDigest, uint64) ([]byte, error)
	ReadStaleBlobIndex(maxStaleSinceSeqNr uint64, limit int) ([]StaleBlob, error)
	ExistsStaleBlobIndex(StaleBlob) (bool, error)

	ReadReportsPlusPrecursor(seqNr uint64, reportsPlusPrecursorDigest ReportsPlusPrecursorDigest) (*ocr3_1types.ReportsPlusPrecursor, error)

	jmt.RootReader
	jmt.NodeReader

	ReadPrevInstanceGenesisStateTransitionBlock() (*GenesisStateTransitionBlock, error)
}

type KeyValueDatabaseReadWriteTransaction interface {
	KeyValueDatabaseReadTransaction
	// The only write part of the interface that the plugin might see. The rest
	// of the methods might only be called by protocol code.
	ocr3_1types.KeyValueStateReadWriter
	KeyValueDatabaseSemanticWrite
	// Commit writes the new highest committed sequence number to the magic key
	// (if the transaction is _not_ unchecked) and commits the transaction to
	// the key value store, then discards the transaction.
	Commit() error
}

type VerifyAndWriteTreeSyncChunkResult int

const (
	_ VerifyAndWriteTreeSyncChunkResult = iota
	VerifyAndWriteTreeSyncChunkResultOkNeedMore
	VerifyAndWriteTreeSyncChunkResultOkComplete
	VerifyAndWriteTreeSyncChunkResultByzantine
	VerifyAndWriteTreeSyncChunkResultUnrelatedError
)

type KeyValueDatabaseSemanticWrite interface {
	// GetWriteSet returns a slice the KeyValuePair entries that
	// have been written in this transaction. If the value of a key has been
	// deleted, it the value is mapped to nil.
	GetWriteSet() ([]KeyValuePairWithDeletions, error)

	// CloseWriteSet returns the state root, writes it to the KV store
	// and closes the transaction for writing: any future attempts for Writes or Deletes
	// on this transaction will fail.
	CloseWriteSet() (StateRootDigest, error)

	// ApplyWriteSet applies the write set to the transaction and returns the
	// state root digest. Useful for reproposals and state synchronization. Only
	// works on checked transactions where the postSeqNr is specified at
	// creation.
	ApplyWriteSet(writeSet []KeyValuePairWithDeletions) (StateRootDigest, error)

	WriteAttestedStateTransitionBlock(seqNr uint64, block AttestedStateTransitionBlock) error
	DeleteAttestedStateTransitionBlocks(maxSeqNrToDelete uint64, maxItems int) (done bool, err error)

	WriteUnattestedStateTransitionBlock(seqNr uint64, stateTransitionInputsDigest StateTransitionInputsDigest, stb StateTransitionBlock) error
	DeleteUnattestedStateTransitionBlocks(maxSeqNrToDelete uint64, maxItems int) (done bool, err error)

	// WriteHighestCommittedSeqNr writes the given sequence number to the magic
	// key. It is called before Commit on checked transactions.
	WriteHighestCommittedSeqNr(seqNr uint64) error
	WriteLowestPersistedSeqNr(seqNr uint64) error
	// VerifyAndWriteTreeSyncChunk first verifies that the keyValues are fully
	// and without omissions included in the key digest range of [startIndex,
	// endInclIndex]. It also verifies that endInclIndex is in the range of
	// [startIndex, requestEndInclIndex], and that keyValues is non-empty unless
	// requestEndInclIndex == endInclIndex. Only after doing all the above, it
	// writes all keyValues into the tree and flat representation.
	VerifyAndWriteTreeSyncChunk(
		targetRootDigest StateRootDigest,
		targetSeqNr uint64,
		startIndex jmt.Digest,
		requestEndInclIndex jmt.Digest,
		endInclIndex jmt.Digest,
		boundingLeaves []jmt.BoundingLeaf,
		keyValues []KeyValuePair,
	) (VerifyAndWriteTreeSyncChunkResult, error)

	WriteTreeSyncStatus(state TreeSyncStatus) error
	WriteBlobMeta(BlobDigest, BlobMeta) error
	DeleteBlobMeta(BlobDigest) error
	WriteBlobQuotaStats(blobQuotaStatsType BlobQuotaStatsType, submitter commontypes.OracleID, blobQuotaStats BlobQuotaStats) error
	WriteBlobChunk(BlobDigest, uint64, []byte) error
	DeleteBlobChunk(BlobDigest, uint64) error
	WriteStaleBlobIndex(StaleBlob) error
	DeleteStaleBlobIndex(StaleBlob) error

	WriteReportsPlusPrecursor(seqNr uint64, reportsPlusPrecursorDigest ReportsPlusPrecursorDigest, reportsPlusPrecursor ocr3_1types.ReportsPlusPrecursor) error
	DeleteReportsPlusPrecursors(minSeqNrToKeep uint64, maxItems int) (done bool, err error)

	jmt.RootWriter
	DeleteRoots(minVersionToKeep jmt.Version, maxItems int) (done bool, err error)

	jmt.NodeWriter
	jmt.StaleNodeWriter
	DeleteStaleNodes(maxStaleSinceVersion jmt.Version, maxItems int) (done bool, err error)

	DestructiveDestroyForTreeSync(n int) (done bool, err error)

	WritePrevInstanceGenesisStateTransitionBlock(genesisStateTransitionBlock GenesisStateTransitionBlock) error
}

type BlobMeta struct {
	PayloadLength uint64
	ChunkHaves    []bool
	ChunkDigests  []BlobChunkDigest
	ExpirySeqNr   uint64
	Submitter     commontypes.OracleID
}

type BlobQuotaStatsType string

const (
	BlobQuotaStatsTypeReaped   BlobQuotaStatsType = "reaped"
	BlobQuotaStatsTypeAppended BlobQuotaStatsType = "appended"
)

type BlobQuotaStats struct {
	Count                   uint64
	CumulativePayloadLength uint64
}

func (b BlobQuotaStats) Add(other BlobQuotaStats) (BlobQuotaStats, bool) {
	sumCount := b.Count + other.Count
	if sumCount < b.Count {
		return BlobQuotaStats{}, false
	}
	sumCumulativePayloadLength := b.CumulativePayloadLength + other.CumulativePayloadLength
	if sumCumulativePayloadLength < b.CumulativePayloadLength {
		return BlobQuotaStats{}, false
	}
	return BlobQuotaStats{
		sumCount,
		sumCumulativePayloadLength,
	}, true
}

func (b BlobQuotaStats) SaturatingSub(other BlobQuotaStats) BlobQuotaStats {
	return BlobQuotaStats{
		util.SaturatingSub(b.Count, other.Count),
		util.SaturatingSub(b.CumulativePayloadLength, other.CumulativePayloadLength),
	}
}

func (b BlobQuotaStats) Sub(other BlobQuotaStats) (BlobQuotaStats, bool) {
	diffCount := b.Count - other.Count
	if diffCount > b.Count {
		return BlobQuotaStats{}, false
	}
	diffCumulativePayloadLength := b.CumulativePayloadLength - other.CumulativePayloadLength
	if diffCumulativePayloadLength > b.CumulativePayloadLength {
		return BlobQuotaStats{}, false
	}
	return BlobQuotaStats{
		diffCount,
		diffCumulativePayloadLength,
	}, true
}

func (b BlobQuotaStats) Exceeds(limit BlobQuotaStats) bool {
	if b.Count > limit.Count {
		return true
	}
	if b.CumulativePayloadLength > limit.CumulativePayloadLength {
		return true
	}
	return false
}

type StaleBlob struct {
	StaleSinceSeqNr uint64
	BlobDigest      BlobDigest
}

// BlobDigestExpirySeqNr is a projection of a [BlobMeta] entry that pairs a
// blob's digest with its expiry sequence number. It is intentionally distinct
// from [StaleBlob], which is keyed on the sequence number after which a blob
// became stale.
type BlobDigestExpirySeqNr struct {
	BlobDigest  BlobDigest
	ExpirySeqNr uint64
}

type KeyValueDatabase interface {
	// Must error if the key value store is not ready to apply state transition
	// for the given sequence number. Must update the highest committed sequence
	// number magic key upon commit. Convenience method for synchronization
	// between outcome generation & state sync.
	NewSerializedReadWriteTransaction(postSeqNr uint64) (KeyValueDatabaseReadWriteTransaction, error)
	// Must error if the key value store is not ready to apply state transition
	// for the given sequence number. Convenience method for synchronization
	// between outcome generation & state sync.
	NewReadTransaction(postSeqNr uint64) (KeyValueDatabaseReadTransaction, error)

	// Unchecked transactions are useful when you don't care that the
	// transaction state represents the kv state as of some particular sequence
	// number, mostly when writing auxiliary data to the kv store. Unchecked
	// transactions do not update the highest committed sequence number magic
	// key upon commit, as would checked transactions.
	NewSerializedReadWriteTransactionUnchecked() (KeyValueDatabaseReadWriteTransaction, error)
	// Unserialized transactions are guaranteed to commit.
	// The protocol should make sure that there are no conflicts across potentially concurrent unserialized transactions,
	// and if two unserialized transactions could actually have conflicts the protocol ensures that the are
	// never opened concurrently.
	NewUnserializedReadWriteTransactionUnchecked() (KeyValueDatabaseReadWriteTransaction, error)
	// Unchecked transactions are useful when you don't care that the
	// transaction state represents the kv state as of some particular sequence
	// number, mostly when reading auxiliary data from the kv store.
	NewReadTransactionUnchecked() (KeyValueDatabaseReadTransaction, error)

	// Deprecated: Kept for convenience/small diff, consider using
	// [KeyValueDatabaseSemanticRead.ReadHighestCommittedSeqNr] instead.
	HighestCommittedSeqNr() (uint64, error)
	Close() error
}

type KeyValueDatabaseFactory interface {
	NewKeyValueDatabase(configDigest types.ConfigDigest) (KeyValueDatabase, error)
}
