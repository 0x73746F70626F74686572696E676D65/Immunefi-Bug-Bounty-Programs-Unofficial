package protocol

import (
	"context"
	"crypto/rand"
	"fmt"
	"math"
	"math/big"
	"runtime"
	"sort"
	"sync"
	"time"

	"github.com/smartcontractkit/libocr/commontypes"
	"github.com/smartcontractkit/libocr/internal/loghelper"
	"github.com/smartcontractkit/libocr/offchainreporting2plus/internal/common"
	"github.com/smartcontractkit/libocr/offchainreporting2plus/internal/common/scheduler"
	"github.com/smartcontractkit/libocr/offchainreporting2plus/internal/config/ocr3_1config"
	"github.com/smartcontractkit/libocr/offchainreporting2plus/ocr3_1types"
	"github.com/smartcontractkit/libocr/offchainreporting2plus/ocr3types"
	"github.com/smartcontractkit/libocr/offchainreporting2plus/types"
	"github.com/smartcontractkit/libocr/subprocesses"
)

func RunReportAttestation[RI any](
	ctx context.Context,

	chNetToReportAttestation <-chan MessageToReportAttestationWithSender[RI],
	chOutcomeGenerationToReportAttestation <-chan EventToReportAttestation[RI],
	chReportAttestationToStateSync chan<- EventToStateSync[RI],
	chReportAttestationToTransmission chan<- EventToTransmission[RI],
	config ocr3_1config.SharedConfig,
	contractTransmitter ocr3types.ContractTransmitter[RI],
	kvDb KeyValueDatabase,
	logger loghelper.LoggerWithContext,
	netSender NetworkSender[RI],
	onchainKeyring ocr3types.OnchainKeyring2[RI],
	reportingPlugin ocr3_1types.ReportingPlugin[RI],
) {
	sched := scheduler.NewScheduler[EventMissingReportsPlusPrecursor[RI]]()
	defer sched.Close()

	newReportAttestationState(ctx, chNetToReportAttestation,
		chOutcomeGenerationToReportAttestation,
		chReportAttestationToStateSync, chReportAttestationToTransmission,
		config, contractTransmitter, kvDb, logger, netSender, onchainKeyring,
		reportingPlugin, sched).run()
}

const expiryMinRounds int = 10
const expiryDuration = 1 * time.Minute
const expiryMaxRounds int = 50

const lookaheadMinRounds int = 4
const lookaheadDuration = 30 * time.Second
const lookaheadMaxRounds int = 10

const maxReportsPlusPrecursorsToReapInOneGo = 100_000

type reportAttestationState[RI any] struct {
	ctx  context.Context
	subs subprocesses.Subprocesses

	chNetToReportAttestation               <-chan MessageToReportAttestationWithSender[RI]
	chOutcomeGenerationToReportAttestation <-chan EventToReportAttestation[RI]
	chReportAttestationToStateSync         chan<- EventToStateSync[RI]
	chReportAttestationToTransmission      chan<- EventToTransmission[RI]
	config                                 ocr3_1config.SharedConfig
	contractTransmitter                    ocr3types.ContractTransmitter[RI]
	kvDb                                   KeyValueDatabase
	logger                                 loghelper.LoggerWithContext
	netSender                              NetworkSender[RI]
	onchainKeyring                         ocr3types.OnchainKeyring2[RI]
	reportingPlugin                        ocr3_1types.ReportingPlugin[RI]

	scheduler    *scheduler.Scheduler[EventMissingReportsPlusPrecursor[RI]]
	chLocalEvent chan EventComputedReports[RI]
	// reap() is used to prevent unbounded state growth of rounds.

	rounds map[uint64]*round[RI]

	// Highest sequence number for which we know a certified commit exists.
	// This is used for determining the window of rounds we keep in memory.
	// Computed as select_largest(f+1, highestReportSignaturesSeqNr).
	highWaterMark                uint64
	highestReportSignaturesSeqNr []uint64
}

type round[RI any] struct {
	ctx                                 context.Context                   // should always be initialized when a round[RI] is initiated
	ctxCancel                           context.CancelFunc                // should always be initialized when a round[RI] is initiated
	certifiedReportsPlusPrecursorDigest *ReportsPlusPrecursorDigest       // only stores ReportsPlusPrecursorDigest when supplied as committed by outgen, or from f+1 matching MessageReportSignatures
	certifiedReportsPlusPrecursor       *ocr3_1types.ReportsPlusPrecursor // only stores ReportsPlusPrecursor when it is the valid preimage of certifiedReportsPlusPrecursorDigest
	reportsPlus                         *[]ocr3types.ReportPlus[RI]       // cache result of ReportingPlugin.Reports(seqNr, certifiedReportsPlusPrecursor)
	oracles                             []oracle                          // always initialized to be of length n
	startedFetch                        bool
	successfullyCheckedKV               bool
	complete                            bool
}

// oracle contains information about interactions with oracles (self & others)
type oracle struct {
	signatures                 [][]byte
	reportsPlusPrecursorDigest *ReportsPlusPrecursorDigest
	sentSignatures             bool
	validSignatures            *bool
	weRequested                bool
	theyServiced               bool
	weServiced                 bool
}

func (repatt *reportAttestationState[RI]) run() {
	repatt.logger.Info("ReportAttestation: running", nil)

	for {
		select {
		case ev := <-repatt.chLocalEvent:
			ev.processReportAttestation(repatt)
		case msg := <-repatt.chNetToReportAttestation:
			msg.msg.processReportAttestation(repatt, msg.sender)
		case ev := <-repatt.chOutcomeGenerationToReportAttestation:
			ev.processReportAttestation(repatt)
		case ev := <-repatt.scheduler.Scheduled():
			ev.processReportAttestation(repatt)
		case <-repatt.ctx.Done():
		}

		// ensure prompt exit
		select {
		case <-repatt.ctx.Done():
			repatt.logger.Info("ReportAttestation: winding down", nil)
			repatt.subs.Wait()
			repatt.scheduler.Close()
			repatt.logger.Info("ReportAttestation: exiting", nil)
			return
		default:
		}
	}
}

func (repatt *reportAttestationState[RI]) eventNewCertifiedCommit(ev EventNewCertifiedCommit[RI]) {
	seqNr := ev.SeqNr

	if _, ok := repatt.rounds[seqNr]; !ok {
		ctx, cancel := context.WithCancel(repatt.ctx)
		repatt.rounds[seqNr] = &round[RI]{
			ctx,
			cancel,
			nil,
			nil,
			nil,
			make([]oracle, repatt.config.N()),
			false,
			false,
			false,
		}
	}

	if repatt.rounds[seqNr].certifiedReportsPlusPrecursorDigest == nil {
		repatt.rounds[seqNr].certifiedReportsPlusPrecursorDigest = &ev.ReportsPlusPrecursorDigest
	}
	if repatt.rounds[seqNr].certifiedReportsPlusPrecursor == nil {
		repatt.rounds[seqNr].successfullyCheckedKV = false
	}

	repatt.tryComplete(seqNr)
}

func (repatt *reportAttestationState[RI]) messageReportSignatures(
	msg MessageReportSignatures[RI],
	sender commontypes.OracleID,
) {
	repatt.logger.Debug("received MessageReportSignatures", commontypes.LogFields{
		"sender":   sender,
		"msgSeqNr": msg.SeqNr,
	})

	repatt.tryReap(msg.SeqNr, sender)

	if repatt.isBeyondExpiry(msg.SeqNr) {
		repatt.logger.Debug("dropping MessageReportSignatures for expired seqNr", commontypes.LogFields{
			"msgSeqNr": msg.SeqNr,
			"sender":   sender,
		})
		return
	}

	if repatt.isBeyondLookahead(msg.SeqNr) {
		repatt.logger.Debug("dropping MessageReportSignatures for seqNr beyond lookahead", commontypes.LogFields{
			"msgSeqNr": msg.SeqNr,
			"sender":   sender,
		})
		return
	}

	if _, ok := repatt.rounds[msg.SeqNr]; !ok {
		ctx, cancel := context.WithCancel(repatt.ctx)
		repatt.rounds[msg.SeqNr] = &round[RI]{
			ctx,
			cancel,
			nil,
			nil,
			nil,
			make([]oracle, repatt.config.N()),
			false,
			false,
			false,
		}
	}

	if repatt.rounds[msg.SeqNr].oracles[sender].sentSignatures {
		repatt.logger.Debug("dropping MessageReportSignatures with duplicate signature", commontypes.LogFields{
			"msgSeqNr": msg.SeqNr,
			"sender":   sender,
		})
		return
	}

	repatt.rounds[msg.SeqNr].oracles[sender].signatures = msg.ReportSignatures
	repatt.rounds[msg.SeqNr].oracles[sender].reportsPlusPrecursorDigest = &msg.ReportsPlusPrecursorDigest
	repatt.rounds[msg.SeqNr].oracles[sender].sentSignatures = true

	repatt.tryComplete(msg.SeqNr)
}

func (repatt *reportAttestationState[RI]) eventMissingReportsPlusPrecursor(ev EventMissingReportsPlusPrecursor[RI]) {
	repatt.logger.Debug("received EventMissingReportsPlusPrecursor", commontypes.LogFields{
		"msgSeqNr": ev.SeqNr,
	})

	if repatt.rounds[ev.SeqNr] == nil {
		repatt.logger.Debug("dropping EventMissingReportsPlusPrecursor for unknown seqNr", commontypes.LogFields{
			"evSeqNr":       ev.SeqNr,
			"highWaterMark": repatt.highWaterMark,
			"expiryRounds":  repatt.expiryRounds(),
		})
		return
	}

	if repatt.rounds[ev.SeqNr].certifiedReportsPlusPrecursor != nil {
		repatt.logger.Debug("dropping EventMissingReportsPlusPrecursor, already have ReportsPlusPrecursor", commontypes.LogFields{
			"evSeqNr": ev.SeqNr,
		})
		return
	}

	if repatt.tryReadReportsPlusPrecursor(ev.SeqNr) {
		return
	}

	repatt.tryRequestReportsPlusPrecursor(ev.SeqNr)
}

func (repatt *reportAttestationState[RI]) messageReportsPlusPrecursorRequest(msg MessageReportsPlusPrecursorRequest[RI], sender commontypes.OracleID) {
	repatt.logger.Debug("received MessageReportsPlusPrecursorRequest", commontypes.LogFields{
		"sender":   sender,
		"msgSeqNr": msg.SeqNr,
	})

	if repatt.rounds[msg.SeqNr] == nil {
		repatt.logger.Debug("dropping MessageReportsPlusPrecursorRequest for unknown seqNr", commontypes.LogFields{
			"msgSeqNr":      msg.SeqNr,
			"sender":        sender,
			"highWaterMark": repatt.highWaterMark,
			"expiryRounds":  repatt.expiryRounds(),
		})
		return
	}

	if repatt.rounds[msg.SeqNr].certifiedReportsPlusPrecursor == nil {
		repatt.logger.Debug("dropping MessageReportsPlusPrecursorRequest for seqNr with unknown certified reports plus precursor", commontypes.LogFields{
			"msgSeqNr": msg.SeqNr,
			"sender":   sender,
		})
		return
	}

	if repatt.rounds[msg.SeqNr].oracles[sender].weServiced {
		repatt.logger.Warn("dropping duplicate MessageReportsPlusPrecursorRequest", commontypes.LogFields{
			"msgSeqNr": msg.SeqNr,
			"sender":   sender,
		})
		return
	}

	repatt.rounds[msg.SeqNr].oracles[sender].weServiced = true

	repatt.logger.Debug("sending MessageReportsPlusPrecursor", commontypes.LogFields{
		"msgSeqNr": msg.SeqNr,
		"to":       sender,
	})
	repatt.netSender.SendTo(MessageReportsPlusPrecursor[RI]{
		msg.RequestHandle,
		msg.SeqNr,
		*repatt.rounds[msg.SeqNr].certifiedReportsPlusPrecursor,
	}, sender)
}

func (repatt *reportAttestationState[RI]) messageReportsPlusPrecursor(msg MessageReportsPlusPrecursor[RI], sender commontypes.OracleID) {
	repatt.logger.Debug("received MessageReportsPlusPrecursor", commontypes.LogFields{
		"sender":   sender,
		"msgSeqNr": msg.SeqNr,
	})
	if repatt.rounds[msg.SeqNr] == nil {
		repatt.logger.Warn("dropping MessageReportsPlusPrecursor for unknown seqNr", commontypes.LogFields{
			"msgSeqNr":      msg.SeqNr,
			"sender":        sender,
			"highWaterMark": repatt.highWaterMark,
			"expiryRounds":  repatt.expiryRounds(),
		})
		return
	}

	oracle := &repatt.rounds[msg.SeqNr].oracles[sender]
	if !(oracle.weRequested && !oracle.theyServiced) {
		repatt.logger.Warn("dropping unexpected MessageReportsPlusPrecursor", commontypes.LogFields{
			"msgSeqNr":     msg.SeqNr,
			"sender":       sender,
			"weRequested":  oracle.weRequested,
			"theyServiced": oracle.theyServiced,
		})
		return
	}

	oracle.theyServiced = true

	if repatt.rounds[msg.SeqNr].certifiedReportsPlusPrecursor != nil {
		repatt.logger.Debug("dropping redundant MessageReportsPlusPrecursor", commontypes.LogFields{
			"msgSeqNr": msg.SeqNr,
			"sender":   sender,
		})
		return
	}

	expectedReportsPlusPrecursorDigest := *repatt.rounds[msg.SeqNr].certifiedReportsPlusPrecursorDigest
	actualReportsPlusPrecursorDigest := MakeReportsPlusPrecursorDigest(
		repatt.config.ConfigDigest,
		msg.SeqNr,
		msg.ReportsPlusPrecursor,
	)

	if expectedReportsPlusPrecursorDigest != actualReportsPlusPrecursorDigest {
		repatt.logger.Warn("dropping MessageReportsPlusPrecursor with mismatching digest", commontypes.LogFields{
			"msgSeqNr":                           msg.SeqNr,
			"sender":                             sender,
			"expectedReportsPlusPrecursorDigest": expectedReportsPlusPrecursorDigest,
			"actualReportsPlusPrecursorDigest":   actualReportsPlusPrecursorDigest,
		})
		return
	}

	repatt.logger.Debug("received valid MessageReportsPlusPrecursor", commontypes.LogFields{
		"msgSeqNr": msg.SeqNr,
		"sender":   sender,
	})

	repatt.receivedCertifiedReportsPlusPrecursor(msg.SeqNr, msg.ReportsPlusPrecursor)
}

func (repatt *reportAttestationState[RI]) tryRequestReportsPlusPrecursor(seqNr uint64) {
	candidates := make([]commontypes.OracleID, 0, repatt.config.N())
	for oracleID, oracle := range repatt.rounds[seqNr].oracles {
		// avoid duplicate requests
		if oracle.weRequested {
			continue
		}
		// avoid requesting from oracles that haven't sent MessageReportSignatures
		if !oracle.sentSignatures {
			continue
		}
		candidates = append(candidates, commontypes.OracleID(oracleID))
	}

	if len(candidates) == 0 {

		return
	}

	randomIndex, err := rand.Int(rand.Reader, big.NewInt(int64(len(candidates))))
	if err != nil {
		repatt.logger.Critical("unexpected error returned by rand.Int", commontypes.LogFields{
			"error": err,
		})
		return
	}
	randomCandidate := candidates[int(randomIndex.Int64())]
	repatt.rounds[seqNr].oracles[randomCandidate].weRequested = true
	repatt.logger.Debug("sending MessageReportsPlusPrecursorRequest", commontypes.LogFields{
		"seqNr": seqNr,
		"to":    randomCandidate,
	})
	repatt.netSender.SendTo(MessageReportsPlusPrecursorRequest[RI]{
		types.EmptyRequestHandleForOutboundRequest,
		seqNr,
	}, randomCandidate)
	repatt.scheduler.ScheduleDelay(EventMissingReportsPlusPrecursor[RI]{seqNr}, repatt.config.GetDeltaReportsPlusPrecursorRequest())
}

func (repatt *reportAttestationState[RI]) tryComplete(seqNr uint64) {
	if repatt.rounds[seqNr].complete {
		repatt.logger.Debug("cannot complete, already completed", commontypes.LogFields{
			"seqNr": seqNr,
		})
		return
	}

	if repatt.rounds[seqNr].certifiedReportsPlusPrecursorDigest == nil {
		// check if we received sufficient MessageReportSignatures of which f+1 have matching ReportsPlusPrecursorDigest

		oraclesThatSentReportsPlusPrecursorDigest := make(map[ReportsPlusPrecursorDigest]int)
		maxOraclesThatSentReportsPlusPrecursorDigest := 0
		for _, oracle := range repatt.rounds[seqNr].oracles {
			if !oracle.sentSignatures {
				continue
			}
			rppd := *oracle.reportsPlusPrecursorDigest
			oraclesThatSentReportsPlusPrecursorDigest[rppd]++
			maxOraclesThatSentReportsPlusPrecursorDigest = max(
				maxOraclesThatSentReportsPlusPrecursorDigest,
				oraclesThatSentReportsPlusPrecursorDigest[rppd],
			)
			if oraclesThatSentReportsPlusPrecursorDigest[rppd] > repatt.config.F {
				repatt.rounds[seqNr].certifiedReportsPlusPrecursorDigest = &rppd
				break
			}
		}

		if maxOraclesThatSentReportsPlusPrecursorDigest <= repatt.config.F {
			repatt.logger.Debug("cannot complete, missing certified ReportsPlusPrecursorDigest and signatures", commontypes.LogFields{
				"maxOraclesThatSentReportsPlusPrecursorDigest": maxOraclesThatSentReportsPlusPrecursorDigest,
				"seqNr":     seqNr,
				"threshold": repatt.config.F + 1,
			})
			return
		} else {
			// We found the certified ReportsPlusPrecursorDigest through f+1
			// MessageReportSignatures, which means that we did not find out
			// through EventNewCertifiedCommit of outcome generation
			select {
			case repatt.chReportAttestationToStateSync <- EventStateSyncRequest[RI]{seqNr}:
			case <-repatt.ctx.Done():
			}
		}
	}

	if repatt.rounds[seqNr].certifiedReportsPlusPrecursorDigest != nil && repatt.rounds[seqNr].certifiedReportsPlusPrecursor == nil {
		if repatt.tryReadReportsPlusPrecursor(seqNr) {
			return
		}

		if !repatt.rounds[seqNr].startedFetch {
			repatt.logger.Debug("we have received the certified ReportsPlusPrecursorDigest but we are still missing ReportsPlusPrecursor", commontypes.LogFields{
				"seqNr": seqNr,
			})
			repatt.rounds[seqNr].startedFetch = true
			repatt.scheduler.ScheduleDelay(EventMissingReportsPlusPrecursor[RI]{seqNr}, repatt.config.GetDeltaReportsPlusPrecursorRequest())
		}
		return
	}

	if repatt.rounds[seqNr].reportsPlus == nil {
		repatt.logger.Debug("cannot complete, reportsPlus not computed yet", commontypes.LogFields{
			"seqNr": seqNr,
		})
		return
	}

	reportsPlus := *repatt.rounds[seqNr].reportsPlus

	goodSigs := 0
	var aossPerReport [][]types.AttributedOnchainSignature = make([][]types.AttributedOnchainSignature, len(reportsPlus))
	for oracleID := range repatt.rounds[seqNr].oracles {
		oracle := &repatt.rounds[seqNr].oracles[oracleID]
		if !oracle.sentSignatures {
			continue
		}
		if oracle.validSignatures == nil {
			validSignatures := repatt.verifySignatures(
				repatt.config.OracleIdentities[oracleID].OnchainPublicKey,
				seqNr,
				reportsPlus,
				oracle.signatures,
			)
			oracle.validSignatures = &validSignatures
			if !validSignatures {
				// Other less common causes include actually invalid signatures.
				repatt.logger.Warn("report signatures failed to verify. This is commonly caused by non-determinism in the ReportingPlugin", commontypes.LogFields{
					"sender":        oracleID,
					"seqNr":         seqNr,
					"signaturesLen": len(oracle.signatures),
					"reportsLen":    len(reportsPlus),
				})
			}
		}
		if oracle.validSignatures != nil && *oracle.validSignatures {
			goodSigs++

			for i := range reportsPlus {
				aossPerReport[i] = append(aossPerReport[i], types.AttributedOnchainSignature{
					oracle.signatures[i],
					commontypes.OracleID(oracleID),
				})
			}
		}
		if goodSigs > repatt.config.F {
			break
		}
	}

	if goodSigs <= repatt.config.F {
		repatt.logger.Debug("cannot complete, insufficient number of signatures", commontypes.LogFields{
			"seqNr":     seqNr,
			"goodSigs":  goodSigs,
			"threshold": repatt.config.F + 1,
		})
		return
	}

	repatt.rounds[seqNr].complete = true

	repatt.logger.Debug("sending attested reports to transmission protocol", commontypes.LogFields{
		"seqNr":   seqNr,
		"reports": len(reportsPlus),
	})

	for i := range reportsPlus {
		select {
		case repatt.chReportAttestationToTransmission <- EventAttestedReport[RI]{
			seqNr,
			i,
			AttestedReportMany[RI]{
				reportsPlus[i].ReportWithInfo,
				aossPerReport[i],
			},
			reportsPlus[i].TransmissionScheduleOverride,
		}:
		case <-repatt.ctx.Done():
		}
	}
}

func (repatt *reportAttestationState[RI]) verifySignatures(publicKey types.OnchainPublicKey, seqNr uint64, reportsPlus []ocr3types.ReportPlus[RI], signatures [][]byte) bool {
	if len(reportsPlus) != len(signatures) {
		return false
	}

	n := runtime.GOMAXPROCS(0)
	if (len(reportsPlus)+3)/4 < n {
		n = (len(reportsPlus) + 3) / 4
	}

	var wg sync.WaitGroup
	wg.Add(n)

	var mutex sync.Mutex
	allValid := true

	for k := 0; k < n; k++ {
		go func() {
			defer wg.Done()
			for i := k; i < len(reportsPlus); i += n {
				mutex.Lock()
				allValidCopy := allValid
				mutex.Unlock()

				if !allValidCopy {
					return
				}

				if !repatt.onchainKeyring.Verify(publicKey, repatt.config.ConfigDigest, seqNr, reportsPlus[i].ReportWithInfo, signatures[i]) {
					mutex.Lock()
					allValid = false
					mutex.Unlock()
					return
				}
			}
		}()
	}

	wg.Wait()

	return allValid
}

func (repatt *reportAttestationState[RI]) receivedCertifiedReportsPlusPrecursor(seqNr uint64, reportsPlusPrecursor ocr3_1types.ReportsPlusPrecursor) {
	if repatt.rounds[seqNr] != nil && repatt.rounds[seqNr].certifiedReportsPlusPrecursor != nil {
		repatt.logger.Debug("dropping redundant certified ReportsPlusPrecursor", commontypes.LogFields{
			"seqNr": seqNr,
		})
		return
	}

	if _, ok := repatt.rounds[seqNr]; !ok {
		ctx, cancel := context.WithCancel(repatt.ctx)
		repatt.rounds[seqNr] = &round[RI]{
			ctx,
			cancel,
			nil,
			nil,
			nil,
			make([]oracle, repatt.config.N()),
			false,
			false,
			false,
		}
	}

	repatt.rounds[seqNr].certifiedReportsPlusPrecursor = &reportsPlusPrecursor

	{
		ctx := repatt.rounds[seqNr].ctx
		repatt.subs.Go(func() {
			repatt.backgroundComputeReports(ctx, seqNr, reportsPlusPrecursor)
		})
	}
}

func (repatt *reportAttestationState[RI]) backgroundComputeReports(ctx context.Context, seqNr uint64, certifiedReportsPlusPrecursor ocr3_1types.ReportsPlusPrecursor) {
	reportsPlus, ok := common.CallPluginFromBackground(
		ctx,
		repatt.logger,
		commontypes.LogFields{"seqNr": seqNr},
		"Reports",
		0, // Reports is a pure function and should finish "instantly"
		func(ctx context.Context) ([]ocr3types.ReportPlus[RI], error) {
			return repatt.reportingPlugin.Reports(ctx, seqNr, certifiedReportsPlusPrecursor)
		},
	)
	if !ok {
		return
	}

	repatt.logger.Debug("successfully invoked ReportingPlugin.Reports", commontypes.LogFields{
		"seqNr":   seqNr,
		"reports": len(reportsPlus),
	})

	select {
	case repatt.chLocalEvent <- EventComputedReports[RI]{seqNr, reportsPlus}:
	case <-ctx.Done():
		return
	}
}

func (repatt *reportAttestationState[RI]) eventComputedReports(ev EventComputedReports[RI]) {
	if repatt.rounds[ev.SeqNr] == nil {
		repatt.logger.Debug("dropping EventComputedReports for unknown seqNr", commontypes.LogFields{
			"evSeqNr":       ev.SeqNr,
			"highWaterMark": repatt.highWaterMark,
			"expiryRounds":  repatt.expiryRounds(),
		})
		return
	}

	if len(ev.ReportsPlus) == 0 {
		repatt.logger.Info("ReportingPlugin.Reports returned no reports", commontypes.LogFields{
			"seqNr": ev.SeqNr,
		})
	}

	repatt.rounds[ev.SeqNr].reportsPlus = &ev.ReportsPlus

	var sigs [][]byte
	for i, reportPlus := range ev.ReportsPlus {
		sig, err := repatt.onchainKeyring.Sign(repatt.config.ConfigDigest, ev.SeqNr, reportPlus.ReportWithInfo)
		if err != nil {
			repatt.logger.Error("error while signing report", commontypes.LogFields{
				"evSeqNr": ev.SeqNr,
				"index":   i,
				"error":   err,
			})
			return
		}
		sigs = append(sigs, sig)
	}

	repatt.logger.Debug("broadcasting MessageReportSignatures", commontypes.LogFields{
		"evSeqNr": ev.SeqNr,
	})

	reportsPlusPrecursorDigest := *repatt.rounds[ev.SeqNr].certifiedReportsPlusPrecursorDigest

	repatt.netSender.Broadcast(MessageReportSignatures[RI]{
		ev.SeqNr,
		sigs,
		reportsPlusPrecursorDigest,
	})

	// no need to call tryComplete since receipt of our own MessageReportSignatures will do so
}

func (repatt *reportAttestationState[RI]) tryReadReportsPlusPrecursor(seqNr uint64) bool {
	if repatt.rounds[seqNr] == nil || repatt.rounds[seqNr].certifiedReportsPlusPrecursor != nil {
		return false
	}

	if !repatt.rounds[seqNr].successfullyCheckedKV {
		reportsPlusPrecursor, err := repatt.readReportsPlusPrecursor(seqNr, *repatt.rounds[seqNr].certifiedReportsPlusPrecursorDigest)
		if err != nil {
			repatt.logger.Warn("error reading ReportsPlusPrecursor from kv", commontypes.LogFields{
				"seqNr": seqNr,
				"error": err,
			})
			return false
		}

		repatt.rounds[seqNr].successfullyCheckedKV = true
		if reportsPlusPrecursor != nil {
			repatt.receivedCertifiedReportsPlusPrecursor(seqNr, *reportsPlusPrecursor)
			return true
		} else {
			repatt.logger.Warn("did not find ReportsPlusPrecursor in kv", commontypes.LogFields{
				"seqNr":                      seqNr,
				"reportsPlusPrecursorDigest": *repatt.rounds[seqNr].certifiedReportsPlusPrecursorDigest,
			})
		}
	}
	return false
}

func (repatt *reportAttestationState[RI]) readReportsPlusPrecursor(seqNr uint64, reportsPlusPrecursorDigest ReportsPlusPrecursorDigest) (*ocr3_1types.ReportsPlusPrecursor, error) {
	tx, err := repatt.kvDb.NewReadTransactionUnchecked()
	if err != nil {
		return nil, fmt.Errorf("error creating read transaction: %w", err)
	}
	defer tx.Discard()
	reportsPlusPrecursor, err := tx.ReadReportsPlusPrecursor(seqNr, reportsPlusPrecursorDigest)
	if err != nil {
		return nil, fmt.Errorf("error reading reports plus precursor: %w", err)
	}
	return reportsPlusPrecursor, nil
}

// reap expired rounds if there is a new high water mark
func (repatt *reportAttestationState[RI]) tryReap(seqNr uint64, sender commontypes.OracleID) {
	if repatt.highestReportSignaturesSeqNr[sender] >= seqNr {
		return
	}

	repatt.highestReportSignaturesSeqNr[sender] = seqNr

	var newHighWaterMark uint64
	{
		highestReportSignaturesSeqNr := append([]uint64{}, repatt.highestReportSignaturesSeqNr...)
		sort.Slice(highestReportSignaturesSeqNr, func(i, j int) bool {
			return highestReportSignaturesSeqNr[i] > highestReportSignaturesSeqNr[j]
		})
		newHighWaterMark = highestReportSignaturesSeqNr[repatt.config.F] // (f+1)th largest seqNr
	}

	if repatt.highWaterMark >= newHighWaterMark {
		return
	}

	repatt.highWaterMark = newHighWaterMark // (f+1)th largest seqNr
	repatt.reap()
}

func (repatt *reportAttestationState[RI]) minUnexpiredSeqNr() uint64 {
	expiry := uint64(repatt.expiryRounds())
	if repatt.highWaterMark <= expiry {
		return 0
	}
	return repatt.highWaterMark - expiry
}

func (repatt *reportAttestationState[RI]) isBeyondExpiry(seqNr uint64) bool {
	return seqNr < repatt.minUnexpiredSeqNr()
}

func (repatt *reportAttestationState[RI]) isBeyondLookahead(seqNr uint64) bool {
	lookahead := uint64(repatt.lookaheadRounds())
	if seqNr <= lookahead {
		return false
	}
	return repatt.highWaterMark < seqNr-lookahead
}

// reap expired entries from repatt.rounds to prevent unbounded state growth
func (repatt *reportAttestationState[RI]) reap() {
	maxActiveRoundCount := repatt.expiryRounds() + repatt.lookaheadRounds()
	// only reap if more than ~ a third of the rounds can potentially be discarded
	if 3*len(repatt.rounds) <= 4*maxActiveRoundCount {
		return
	}

	beforeRounds := len(repatt.rounds)

	// A long time ago in a galaxy far, far away, Go used to leak memory when
	// repeatedly adding and deleting from the same map without ever exceeding
	// some maximum length. Fortunately, this is no longer the case
	// https://go-review.googlesource.com/c/go/+/25049/
	for seqNr := range repatt.rounds {
		if repatt.isBeyondExpiry(seqNr) {
			repatt.rounds[seqNr].ctxCancel()
			delete(repatt.rounds, seqNr)
		}
	}

	{
		minUnexpiredSeqNr := repatt.minUnexpiredSeqNr()
		repatt.subs.Go(func() {
			repatt.backgroundReapReportsPlusPrecursors(minUnexpiredSeqNr)
		})
	}

	repatt.logger.Debug("reaped expired rounds", commontypes.LogFields{
		"before":        beforeRounds,
		"after":         len(repatt.rounds),
		"highWaterMark": repatt.highWaterMark,
	})
}

func (repatt *reportAttestationState[RI]) backgroundReapReportsPlusPrecursors(minUnexpiredSeqNr uint64) {
	done := false
	for !done {
		var err error
		done, err = repatt.reapReportsPlusPrecursors(minUnexpiredSeqNr)
		if err != nil {
			repatt.logger.Warn("failed to reap reportsPlusPrecursors", commontypes.LogFields{
				"error": err,
			})
			return
		}
	}
	repatt.logger.Debug("successfully reaped reportsPlusPrecursors", commontypes.LogFields{
		"minUnexpiredSeqNr": minUnexpiredSeqNr,
	})
}

func (repatt *reportAttestationState[RI]) reapReportsPlusPrecursors(minUnexpiredSeqNr uint64) (done bool, err error) {
	tx, err := repatt.kvDb.NewUnserializedReadWriteTransactionUnchecked()
	if err != nil {
		return false, fmt.Errorf("failed to create transaction: %w", err)
	}
	defer tx.Discard()

	done, err = tx.DeleteReportsPlusPrecursors(minUnexpiredSeqNr, maxReportsPlusPrecursorsToReapInOneGo)
	if err != nil {
		return false, err
	}

	err = tx.Commit()
	if err != nil {
		return false, fmt.Errorf("failed to commit: %w", err)
	}
	return done, err
}

// The age (denoted in rounds) after which a report is considered expired and
// will automatically be dropped
func (repatt *reportAttestationState[RI]) expiryRounds() int {
	return repatt.roundWindowSize(expiryMinRounds, expiryMaxRounds, expiryDuration)
}

// The lookahead (denoted in rounds) after which a report is considered too far in the future and
// will automatically be dropped
func (repatt *reportAttestationState[RI]) lookaheadRounds() int {
	return repatt.roundWindowSize(lookaheadMinRounds, lookaheadMaxRounds, lookaheadDuration)
}

func (repatt *reportAttestationState[RI]) roundWindowSize(minWindowSize int, maxWindowSize int, windowDuration time.Duration) int {
	// number of rounds in a window of duration expirationAgeDuration
	size := math.Ceil(windowDuration.Seconds() / repatt.config.MinRoundInterval().Seconds())

	if size < float64(minWindowSize) {
		size = float64(minWindowSize)
	}
	if math.IsNaN(size) || size > float64(maxWindowSize) {
		size = float64(maxWindowSize)
	}

	return int(math.Ceil(size))
}

func newReportAttestationState[RI any](
	ctx context.Context,

	chNetToReportAttestation <-chan MessageToReportAttestationWithSender[RI],
	chOutcomeGenerationToReportAttestation <-chan EventToReportAttestation[RI],
	chReportAttestationToStateSync chan<- EventToStateSync[RI],
	chReportAttestationToTransmission chan<- EventToTransmission[RI],
	config ocr3_1config.SharedConfig,
	contractTransmitter ocr3types.ContractTransmitter[RI],
	kvDb KeyValueDatabase,
	logger loghelper.LoggerWithContext,
	netSender NetworkSender[RI],
	onchainKeyring ocr3types.OnchainKeyring2[RI],
	reportingPlugin ocr3_1types.ReportingPlugin[RI],
	sched *scheduler.Scheduler[EventMissingReportsPlusPrecursor[RI]],
) *reportAttestationState[RI] {
	return &reportAttestationState[RI]{
		ctx,
		subprocesses.Subprocesses{},

		chNetToReportAttestation,
		chOutcomeGenerationToReportAttestation,
		chReportAttestationToStateSync,
		chReportAttestationToTransmission,
		config,
		contractTransmitter,
		kvDb,
		logger.MakeUpdated(commontypes.LogFields{"proto": "repatt"}),
		netSender,
		onchainKeyring,
		reportingPlugin,

		sched,
		make(chan EventComputedReports[RI]),
		map[uint64]*round[RI]{},
		0,
		make([]uint64, config.N()),
	}
}
