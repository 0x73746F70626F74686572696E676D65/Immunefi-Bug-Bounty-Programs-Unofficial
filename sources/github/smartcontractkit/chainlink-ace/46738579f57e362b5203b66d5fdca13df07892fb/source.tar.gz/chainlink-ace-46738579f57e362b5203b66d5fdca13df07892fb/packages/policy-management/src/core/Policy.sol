// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.20;

import {IPolicy} from "../interfaces/IPolicy.sol";
import {IPolicyEngine} from "../interfaces/IPolicyEngine.sol";
import {IERC165} from "@openzeppelin/contracts/utils/introspection/IERC165.sol";
import {OwnableUpgradeable} from "@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol";
import {ERC165Upgradeable} from "@openzeppelin/contracts-upgradeable/utils/introspection/ERC165Upgradeable.sol";
import {UUPSUpgradeable} from "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";

abstract contract Policy is UUPSUpgradeable, OwnableUpgradeable, ERC165Upgradeable, IPolicy {
  error Unauthorized();
  error InvalidParameters(string reason);
  error PolicyAlreadyBound(address subject);

  /// @custom:storage-location erc7201:chainlink.ace.Policy
  struct PolicyStorage {
    address policyEngine;
  }

  // keccak256(abi.encode(uint256(keccak256("chainlink.ace.Policy")) - 1)) &
  // ~bytes32(uint256(0xff))
  // solhint-disable-next-line const-name-snakecase
  bytes32 private constant PolicyStorageLocation = 0x88b18ed68be9f5af7a0aa0e9a55256b17a6bcc168c9c257d2c5556789ebee900;

  function _getPolicyStorage() private pure returns (PolicyStorage storage $) {
    // solhint-disable-next-line no-inline-assembly
    assembly {
      $.slot := PolicyStorageLocation
    }
  }

  modifier onlyPolicyEngine() {
    if (msg.sender != _getPolicyStorage().policyEngine) {
      revert Unauthorized();
    }
    _;
  }

  /**
   * @notice Initializes the policy contract.
   * @dev This function MUST be called immediately after deployment (or via proxy initializer),
   * setting up the policy with the address of the policy engine, initial ownership, and
   * any configuration parameters required by the policy.
   * @param policyEngine The address of the policy engine that will invoke this policy.
   * @param initialOwner The address that will be assigned as the initial owner of the policy contract.
   * @param configParams Arbitrary encoded configuration parameters to initialize the policy logic.
   */
  function initialize(
    address policyEngine,
    address initialOwner,
    bytes calldata configParams
  )
    public
    virtual
    initializer
  {
    __Policy_init(policyEngine, initialOwner);
    configure(configParams);
  }

  // solhint-disable-next-line no-empty-blocks
  function configure(bytes calldata parameters) internal virtual onlyInitializing {}

  function __Policy_init(address policyEngine, address initialOwner) internal onlyInitializing {
    __Policy_init_unchained(policyEngine);
    __Ownable_init(initialOwner);
    __ERC165_init();
  }

  function __Policy_init_unchained(address policyEngine) internal onlyInitializing {
    _getPolicyStorage().policyEngine = policyEngine;
  }

  // Authorize contract upgrades to only the owner
  // solhint-disable-next-line no-empty-blocks
  function _authorizeUpgrade(address) internal override onlyOwner {}

  /// @inheritdoc IPolicy
  // solhint-disable-next-line no-empty-blocks
  function onInstall(
    address, /*subject*/
    bytes4 /*selector*/
  )
    public
    virtual
    override
    onlyPolicyEngine
  {}

  /// @inheritdoc IPolicy
  // solhint-disable-next-line no-empty-blocks
  function onUninstall(
    address, /*subject*/
    bytes4 /*selector*/
  )
    public
    virtual
    override
    onlyPolicyEngine
  {}

  /**
   * @notice Authorize a selector as a configuration selector, allowed to be called by the PolicyEngine.
   * By default no selectors are allowed. Each policy contract should define its configuration selectors
   * by overriding this function and return true only for configuration function selectors.
   */
  function authorizeConfigSelector(
    bytes4 /*selector*/
  )
    public
    pure
    virtual
    returns (bool)
  {
    return false;
  }

  function run(
    address caller,
    address subject,
    bytes4 selector,
    bytes[] calldata parameters,
    bytes calldata context
  )
    public
    view
    virtual
    override
    returns (IPolicyEngine.PolicyResult);

  function postRun(
    address, /*caller*/
    address, /*subject*/
    bytes4, /*selector*/
    bytes[] calldata, /*parameters*/
    bytes calldata /*context*/
  )
    public
    virtual
    override
    onlyPolicyEngine
    // solhint-disable-next-line no-empty-blocks

  {}

  /**
   * @dev See {ERC165-supportsInterface}.
   */
  function supportsInterface(bytes4 interfaceId)
    public
    view
    virtual
    override(ERC165Upgradeable, IERC165)
    returns (bool)
  {
    return interfaceId == type(IPolicy).interfaceId || super.supportsInterface(interfaceId);
  }
}
