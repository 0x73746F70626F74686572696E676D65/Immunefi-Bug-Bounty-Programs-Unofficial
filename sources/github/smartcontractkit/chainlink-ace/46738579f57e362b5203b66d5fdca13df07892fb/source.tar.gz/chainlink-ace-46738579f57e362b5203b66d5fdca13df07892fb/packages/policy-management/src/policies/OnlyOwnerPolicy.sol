// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.20;

import {IPolicyEngine} from "../interfaces/IPolicyEngine.sol";
import {Policy} from "../core/Policy.sol";

/**
 * @title OnlyOwnerPolicy
 * @notice A policy that only allows the policy owner to call the method, similar to `Ownable` from OpenZeppelin.
 */
contract OnlyOwnerPolicy is Policy {
  string public constant override typeAndVersion = "OnlyOwnerPolicy 1.1.1";

  // disabling initializers on the implementation contract itself
  /// @custom:oz-upgrades-unsafe-allow constructor
  constructor() {
    _disableInitializers();
  }

  function run(
    address caller,
    address, /*subject*/
    bytes4, /*selector*/
    bytes[] calldata parameters,
    bytes calldata /*context*/
  )
    public
    view
    override
    returns (IPolicyEngine.PolicyResult)
  {
    // expected parameters: none
    // solhint-disable-next-line gas-custom-errors
    if (parameters.length != 0) {
      revert InvalidParameters("expected 0 parameters");
    }

    if (caller != owner()) {
      revert IPolicyEngine.PolicyRejected("caller is not the policy owner");
    }
    return IPolicyEngine.PolicyResult.Continue;
  }
}
