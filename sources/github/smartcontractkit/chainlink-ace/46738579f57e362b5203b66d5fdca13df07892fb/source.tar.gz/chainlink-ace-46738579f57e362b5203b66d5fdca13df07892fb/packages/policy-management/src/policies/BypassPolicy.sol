// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.20;

import {IPolicyEngine} from "../interfaces/IPolicyEngine.sol";
import {Policy} from "../core/Policy.sol";

/**
 * @title BypassPolicy
 * @notice A policy that permits method calls if all of the addresses are on an allowlist, overriding and bypassing any
 * subsequent policies in the chain.
 */
contract BypassPolicy is Policy {
  string public constant override typeAndVersion = "BypassPolicy 1.1.1";

  /**
   * @notice Emitted when an address is added to the bypass list.
   * @param account The address that was added to the bypass list.
   */
  event AddressAllowed(address indexed account);

  /**
   * @notice Emitted when an address is removed from the bypass list.
   * @param account The address that was removed from the bypass list.
   */
  event AddressDisallowed(address indexed account);

  /// @custom:storage-location erc7201:chainlink.ace.BypassPolicy
  struct BypassPolicyStorage {
    /// @notice If the address is on this list, method calls will always be allowed.
    mapping(address account => bool isAllowed) allowList;
  }

  // keccak256(abi.encode(uint256(keccak256("chainlink.ace.BypassPolicy")) - 1)) & ~bytes32(uint256(0xff))
  bytes32 private constant BypassPolicyStorageLocation =
    0x813bf0d2fec0f79acde423921d4b30ec3fa5f750ddd7c4ef51c8d6f81af7aa00;

  function _getBypassPolicyStorage() private pure returns (BypassPolicyStorage storage $) {
    assembly {
      $.slot := BypassPolicyStorageLocation
    }
  }

  // disabling initializers on the implementation contract itself
  /// @custom:oz-upgrades-unsafe-allow constructor
  constructor() {
    _disableInitializers();
  }

  /**
   * @notice Authorize the following configuration functions:
   * - allowAddress
   * - disallowAddress
   */
  function authorizeConfigSelector(bytes4 selector) public pure override returns (bool) {
    return (selector == this.allowAddress.selector || selector == this.disallowAddress.selector);
  }

  /**
   * @notice Adds the account to the bypass list.
   * @dev Throws if the account is already in the bypass list.
   * @param account The address to add to the bypass list.
   */
  function allowAddress(address account) public onlyOwner {
    BypassPolicyStorage storage $ = _getBypassPolicyStorage();
    require(!$.allowList[account], "Account already in bypass list");
    $.allowList[account] = true;
    emit AddressAllowed(account);
  }

  /**
   * @notice Removes the account from the bypass list.
   * @dev Throws if the account is not in the bypass list.
   * @param account The address to remove from the bypass list.
   */
  function disallowAddress(address account) public onlyOwner {
    BypassPolicyStorage storage $ = _getBypassPolicyStorage();
    require($.allowList[account], "Account not in bypass list");
    $.allowList[account] = false;
    emit AddressDisallowed(account);
  }

  /**
   * @notice Checks if the account is on the bypass list.
   * @param account The address to check.
   * @return addressAllowed if the account is on the bypass list, false otherwise.
   */
  function addressAllowed(address account) public view returns (bool) {
    BypassPolicyStorage storage $ = _getBypassPolicyStorage();
    return $.allowList[account];
  }

  /**
   * @notice Function to be called by the policy engine to check if execution is allowed.
   * @param parameters encoded policy parameters.
   *        [account(address),...] List of addresses to check for present on the bypass list.
   * @return result The result of the policy check.
   */
  function run(
    address, /*caller*/
    address, /*subject*/
    bytes4, /*selector*/
    bytes[] calldata parameters, /*parameters*/
    bytes calldata /*context*/
  )
    public
    view
    override
    returns (IPolicyEngine.PolicyResult)
  {
    if (parameters.length < 1) {
      revert InvalidParameters("expected at least 1 parameter");
    }
    // Gas optimization: load storage reference once
    BypassPolicyStorage storage $ = _getBypassPolicyStorage();
    for (uint256 i = 0; i < parameters.length; i++) {
      address account = abi.decode(parameters[i], (address));
      if (!$.allowList[account]) {
        return IPolicyEngine.PolicyResult.Continue;
      }
    }
    return IPolicyEngine.PolicyResult.Allowed;
  }
}
