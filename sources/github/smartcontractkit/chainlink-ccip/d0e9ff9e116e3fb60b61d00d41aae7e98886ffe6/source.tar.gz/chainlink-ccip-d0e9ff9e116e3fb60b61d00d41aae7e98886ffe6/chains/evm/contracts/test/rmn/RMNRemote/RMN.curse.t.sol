// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.24;

import {RMN} from "../../../rmn/RMN.sol";
import {RMNRemoteSetup} from "./RMNSetup.t.sol";
import {AuthorizedCallers} from "@chainlink/contracts/src/v0.8/shared/access/AuthorizedCallers.sol";

contract RMNRemote_curse is RMNRemoteSetup {
  function test_curse() public {
    vm.expectEmit();
    emit RMN.Cursed(s_curseSubjects);

    s_rmn.curse(s_curseSubjects);

    assertEq(abi.encode(s_rmn.getCursedSubjects()), abi.encode(s_curseSubjects));
    assertTrue(s_rmn.isCursed(CURSE_SUBJ_1));
    assertTrue(s_rmn.isCursed(CURSE_SUBJ_2));
    // Should not have cursed a random subject
    assertFalse(s_rmn.isCursed(bytes16(keccak256("subject 3"))));
  }

  function test_curse_ByOwner_WhenCurseAdminsExist() public {
    address curseAdmin = makeAddr("curseAdmin");
    address[] memory adds = new address[](1);
    adds[0] = curseAdmin;
    s_rmn.applyAuthorizedCallerUpdates(
      AuthorizedCallers.AuthorizedCallerArgs({addedCallers: adds, removedCallers: new address[](0)})
    );

    vm.expectEmit();
    emit RMN.Cursed(s_curseSubjects);
    s_rmn.curse(s_curseSubjects);

    assertTrue(s_rmn.isCursed(CURSE_SUBJ_1));
    assertTrue(s_rmn.isCursed(CURSE_SUBJ_2));
  }

  function test_curse_ByCurseAdmin() public {
    address curseAdmin = makeAddr("curseAdmin");
    address[] memory adds = new address[](1);
    adds[0] = curseAdmin;
    s_rmn.applyAuthorizedCallerUpdates(
      AuthorizedCallers.AuthorizedCallerArgs({addedCallers: adds, removedCallers: new address[](0)})
    );

    vm.stopPrank();
    vm.prank(curseAdmin);
    vm.expectEmit();
    emit RMN.Cursed(s_curseSubjects);
    s_rmn.curse(s_curseSubjects);

    assertTrue(s_rmn.isCursed(CURSE_SUBJ_1));
    assertTrue(s_rmn.isCursed(CURSE_SUBJ_2));
  }

  function test_curse_ByNewlyAddedCurseAdmin() public {
    address newAdmin = makeAddr("newAdmin");
    address[] memory adds = new address[](1);
    adds[0] = newAdmin;
    s_rmn.applyAuthorizedCallerUpdates(
      AuthorizedCallers.AuthorizedCallerArgs({addedCallers: adds, removedCallers: new address[](0)})
    );

    vm.stopPrank();
    vm.prank(newAdmin);
    vm.expectEmit();
    emit RMN.Cursed(s_curseSubjects);
    s_rmn.curse(s_curseSubjects);

    assertTrue(s_rmn.isCursed(CURSE_SUBJ_1));
    assertTrue(s_rmn.isCursed(CURSE_SUBJ_2));
  }

  function test_curse_SkipsAlreadyCursedSubjects_AppliesRemainingInBatch() public {
    s_rmn.curse(CURSE_SUBJ_1);

    bytes16[] memory batch = new bytes16[](3);
    batch[0] = CURSE_SUBJ_1;
    batch[1] = CURSE_SUBJ_2;
    batch[2] = CURSE_SUBJ_1;

    bytes16[] memory expectedEmit = new bytes16[](1);
    expectedEmit[0] = CURSE_SUBJ_2;

    vm.expectEmit();
    emit RMN.Cursed(expectedEmit);
    s_rmn.curse(batch);

    assertTrue(s_rmn.isCursed(CURSE_SUBJ_1));
    assertTrue(s_rmn.isCursed(CURSE_SUBJ_2));
  }

  function test_curse_NoEventWhenAllSubjectsAlreadyCursed() public {
    s_rmn.curse(s_curseSubjects);

    vm.recordLogs();
    s_rmn.curse(s_curseSubjects);
    assertEq(vm.getRecordedLogs().length, 0);
  }

  function test_RevertWhen_curse_calledByNonOwner() public {
    vm.stopPrank();
    vm.prank(STRANGER);
    vm.expectRevert(abi.encodeWithSelector(AuthorizedCallers.UnauthorizedCaller.selector, STRANGER));
    s_rmn.curse(s_curseSubjects);
  }

  function test_RevertWhen_curse_calledByRemovedCurseAdmin() public {
    address curseAdmin = makeAddr("curseAdmin");
    address[] memory adds = new address[](1);
    adds[0] = curseAdmin;
    s_rmn.applyAuthorizedCallerUpdates(
      AuthorizedCallers.AuthorizedCallerArgs({addedCallers: adds, removedCallers: new address[](0)})
    );
    address[] memory toRemove = new address[](1);
    toRemove[0] = curseAdmin;
    s_rmn.applyAuthorizedCallerUpdates(
      AuthorizedCallers.AuthorizedCallerArgs({addedCallers: new address[](0), removedCallers: toRemove})
    );

    vm.stopPrank();
    vm.prank(curseAdmin);
    vm.expectRevert(abi.encodeWithSelector(AuthorizedCallers.UnauthorizedCaller.selector, curseAdmin));
    s_rmn.curse(s_curseSubjects);
  }
}
