// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.24;

import {Client} from "../../../libraries/Client.sol";
import {ExtraArgsCodec} from "../../../libraries/ExtraArgsCodec.sol";
import {FinalityCodec} from "../../../libraries/FinalityCodec.sol";
import {MessageV1Codec} from "../../../libraries/MessageV1Codec.sol";
import {OnRamp} from "../../../onRamp/OnRamp.sol";
import {TokenSetup} from "../../TokenSetup.t.sol";
import {FeeQuoterFeeSetup} from "../../feeQuoter/FeeQuoterSetup.t.sol";
import {OnRampHelper} from "../../helpers/OnRampHelper.sol";
import {MockExecutor} from "../../mocks/MockExecutor.sol";
import {MockVerifier} from "../../mocks/MockVerifier.sol";

import {IERC20Metadata} from "@openzeppelin/contracts@5.3.0/token/ERC20/extensions/IERC20Metadata.sol";

contract OnRampSetup is FeeQuoterFeeSetup, TokenSetup {
  address internal constant FEE_AGGREGATOR = 0xa33CDB32eAEce34F6affEfF4899cef45744EDea3;
  uint16 internal constant MESSAGE_NETWORK_FEE_USD_CENTS = 1_00; // $1.00
  uint16 internal constant TOKEN_NETWORK_FEE_USD_CENTS = 2_00; // $2.00
  uint32 internal constant POOL_FEE_USD_CENTS = 100; // $1.00
  uint32 internal constant POOL_GAS_OVERHEAD = 50000;
  uint32 internal constant POOL_BYTES_OVERHEAD = 128;
  uint32 internal constant MAX_USD_CENTS_PER_MESSAGE = 10_000; // $100.00

  uint32 internal constant FEE_QUOTER_FEE_USD_CENTS = 50; // $0.50
  uint32 internal constant FEE_QUOTER_GAS_OVERHEAD = 30000;
  uint32 internal constant FEE_QUOTER_BYTES_OVERHEAD = 64;

  uint32 internal constant VERIFIER_FEE_USD_CENTS = 200; // $2.00
  uint32 internal constant VERIFIER_GAS = 100000;
  uint32 internal constant VERIFIER_BYTES = 256;

  OnRampHelper internal s_onRamp;
  address internal s_offRampOnRemoteChain = makeAddr("OffRampRemote");

  address internal s_defaultCCV;
  address internal s_defaultExecutor;

  mapping(address token => bytes extraData) internal s_extraDataByToken;

  struct EventData {
    ExtraArgsCodec.GenericExtraArgsV3 resolvedExtraArgs;
    OnRamp.Receipt[] receipts;
    uint32 executionGasLimit;
  }

  function setUp() public virtual override(FeeQuoterFeeSetup, TokenSetup) {
    super.setUp();

    s_onRamp = new OnRampHelper(
      OnRamp.StaticConfig({
        chainSelector: SOURCE_CHAIN_SELECTOR,
        rmnRemote: s_mockRMNRemote,
        maxUSDCentsPerMessage: MAX_USD_CENTS_PER_MESSAGE,
        tokenAdminRegistry: address(s_tokenAdminRegistry)
      }),
      OnRamp.DynamicConfig({
        feeQuoter: address(s_feeQuoter), reentrancyGuardEntered: false, feeAggregator: FEE_AGGREGATOR
      })
    );
    s_defaultCCV = address(new MockVerifier(""));
    s_defaultExecutor = address(new MockExecutor());

    address[] memory defaultCCVs = new address[](1);
    defaultCCVs[0] = s_defaultCCV;

    OnRamp.DestChainConfigArgs[] memory destChainConfigArgs = new OnRamp.DestChainConfigArgs[](1);
    destChainConfigArgs[0] = OnRamp.DestChainConfigArgs({
      destChainSelector: DEST_CHAIN_SELECTOR,
      router: s_sourceRouter,
      addressBytesLength: EVM_ADDRESS_LENGTH,
      messageNetworkFeeUSDCents: MESSAGE_NETWORK_FEE_USD_CENTS,
      tokenNetworkFeeUSDCents: TOKEN_NETWORK_FEE_USD_CENTS,
      tokenReceiverAllowed: false,
      baseExecutionGasCost: BASE_EXEC_GAS_COST,
      laneMandatedCCVs: new address[](0),
      defaultCCVs: defaultCCVs,
      defaultExecutor: s_defaultExecutor,
      offRamp: abi.encodePacked(address(s_offRampOnRemoteChain))
    });

    s_onRamp.applyDestChainConfigUpdates(destChainConfigArgs);
  }

  function _evmMessageToEvent(
    Client.EVM2AnyMessage memory message,
    uint64 destChainSelector,
    uint64 msgNum,
    address originalSender
  )
    internal
    view
    returns (
      bytes32 messageId,
      bytes memory encodedMessage,
      OnRamp.Receipt[] memory receipts,
      bytes[] memory verifierBlobs
    )
  {
    OnRamp.DestChainConfig memory destChainConfig = s_onRamp.getDestChainConfig(DEST_CHAIN_SELECTOR);

    EventData memory eventData;
    eventData.resolvedExtraArgs = s_onRamp.parseExtraArgsWithDefaults(
      destChainSelector,
      destChainConfig,
      message.extraArgs,
      (message.data.length == 0 && message.tokenAmounts.length > 0)
    );

    address[] memory poolRequiredCCVs = new address[](0);
    if (message.tokenAmounts.length != 0) {
      poolRequiredCCVs = s_onRamp.getCCVsForPool(
        destChainSelector,
        message.tokenAmounts[0].token,
        message.tokenAmounts[0].amount,
        eventData.resolvedExtraArgs.requestedFinalityConfig,
        eventData.resolvedExtraArgs.tokenArgs
      );
    }
    (eventData.resolvedExtraArgs.ccvs, eventData.resolvedExtraArgs.ccvArgs) = s_onRamp.mergeCCVLists(
      eventData.resolvedExtraArgs.ccvs,
      eventData.resolvedExtraArgs.ccvArgs,
      destChainConfig.laneMandatedCCVs,
      poolRequiredCCVs
    );

    uint16 networkFeeUSDCents = message.tokenAmounts.length == 0
      ? destChainConfig.messageNetworkFeeUSDCents
      : destChainConfig.tokenNetworkFeeUSDCents;
    (eventData.receipts, eventData.executionGasLimit,) =
      s_onRamp.getReceipts(destChainSelector, networkFeeUSDCents, message, eventData.resolvedExtraArgs);

    MessageV1Codec.MessageV1 memory messageV1 = MessageV1Codec.MessageV1({
      sourceChainSelector: SOURCE_CHAIN_SELECTOR,
      destChainSelector: destChainSelector,
      messageNumber: msgNum,
      executionGasLimit: eventData.executionGasLimit,
      ccipReceiveGasLimit: GAS_LIMIT,
      finality: FinalityCodec.WAIT_FOR_FINALITY_FLAG,
      ccvAndExecutorHash: MessageV1Codec._computeCCVAndExecutorHash(
        eventData.resolvedExtraArgs.ccvs, eventData.resolvedExtraArgs.executor
      ),
      onRampAddress: abi.encode(address(s_onRamp)),
      offRampAddress: destChainConfig.offRamp,
      sender: abi.encode(originalSender),
      receiver: abi.encodePacked(abi.decode(message.receiver, (address))),
      destBlob: "",
      tokenTransfer: new MessageV1Codec.TokenTransferV1[](message.tokenAmounts.length),
      data: message.data
    });

    // Populate token transfers

    _populateTokenTransfers(messageV1, message);

    // `getReceipts` uses `msg.sender` as the issuer for the network-fee receipt.
    // Since this helper calls it directly (not through the router), override the issuer to reflect the router address.
    eventData.receipts[eventData.receipts.length - 1].issuer = address(s_sourceRouter);

    receipts = eventData.receipts;

    return (
      keccak256(MessageV1Codec._encodeMessageV1(messageV1)),
      MessageV1Codec._encodeMessageV1(messageV1),
      receipts,
      new bytes[](eventData.resolvedExtraArgs.ccvs.length)
    );
  }

  // Helper function to create GenericExtraArgsV3 struct.
  function _createV3ExtraArgs(
    address[] memory ccvAddresses,
    bytes[] memory ccvArgs
  ) internal pure returns (ExtraArgsCodec.GenericExtraArgsV3 memory) {
    return ExtraArgsCodec.GenericExtraArgsV3({
      ccvs: ccvAddresses,
      ccvArgs: ccvArgs,
      gasLimit: GAS_LIMIT,
      requestedFinalityConfig: FinalityCodec._encodeBlockDepth(12),
      executor: address(0), // No executor specified.
      executorArgs: "",
      tokenReceiver: "",
      tokenArgs: ""
    });
  }

  // Helper function to assert that two CCV arrays are equal (using parallel address and bytes arrays).
  function _assertCCVArraysEqual(
    address[] memory actualAddresses,
    bytes[] memory actualArgs,
    address[] memory expectedAddresses,
    bytes[] memory expectedArgs
  ) internal pure {
    assertEq(actualAddresses.length, expectedAddresses.length, "CCV address arrays have different lengths");
    assertEq(actualArgs.length, expectedArgs.length, "CCV args arrays have different lengths");
    assertEq(actualAddresses.length, actualArgs.length, "CCV addresses and args have different lengths");

    for (uint256 i = 0; i < actualAddresses.length; ++i) {
      assertEq(
        actualAddresses[i], expectedAddresses[i], string.concat("CCV address mismatch at index ", vm.toString(i))
      );
      assertEq(actualArgs[i], expectedArgs[i], string.concat("CCV args mismatch at index ", vm.toString(i)));
    }
  }

  // Helper to populate token transfers.
  function _populateTokenTransfers(
    MessageV1Codec.MessageV1 memory messageV1,
    Client.EVM2AnyMessage memory message
  ) internal view {
    for (uint256 i = 0; i < message.tokenAmounts.length; ++i) {
      address token = message.tokenAmounts[i].token;
      messageV1.tokenTransfer[i] = MessageV1Codec.TokenTransferV1({
        amount: message.tokenAmounts[i].amount,
        sourcePoolAddress: abi.encode(s_sourcePoolByToken[token]),
        sourceTokenAddress: abi.encode(token),
        destTokenAddress: abi.encodePacked(s_destTokenBySourceToken[token]),
        tokenReceiver: abi.encodePacked(abi.decode(message.receiver, (address))),
        extraData: s_extraDataByToken[token].length != 0
          ? s_extraDataByToken[token]
          : abi.encode(IERC20Metadata(token).decimals())
      });
    }
  }
}
