// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ICrossChainVerifierResolver} from "../../interfaces/ICrossChainVerifierResolver.sol";
import {ICrossChainVerifierV1} from "../../interfaces/ICrossChainVerifierV1.sol";

import {Client} from "../../libraries/Client.sol";
import {MessageV1Codec} from "../../libraries/MessageV1Codec.sol";

import {IERC165} from "@openzeppelin/contracts@5.3.0/utils/introspection/IERC165.sol";

contract MockVerifier is ICrossChainVerifierResolver, ICrossChainVerifierV1 {
  bytes private s_verifierResult;

  constructor(
    bytes memory verifierResult
  ) {
    s_verifierResult = verifierResult;
  }

  function supportsInterface(
    bytes4 interfaceId
  ) external pure returns (bool) {
    return interfaceId == type(ICrossChainVerifierV1).interfaceId || interfaceId == type(IERC165).interfaceId;
  }

  function forwardToVerifier(
    MessageV1Codec.MessageV1 calldata,
    bytes32,
    address,
    uint256,
    bytes calldata
  ) external view returns (bytes memory) {
    return s_verifierResult;
  }

  function getFee(
    uint64, // destChainSelector
    Client.EVM2AnyMessage memory, // message
    bytes memory, // extraArgs
    bytes4 // requestedFinalityConfig
  ) external pure returns (uint16 feeUSDCents, uint32 gasForVerification, uint32 payloadSizeBytes) {
    return (0, 0, 0);
  }

  function verifyMessage(
    MessageV1Codec.MessageV1 memory, // message
    bytes32 messageId, // messageId
    bytes memory verifierResults // verifierResults
  ) external {}

  function getStorageLocations() external pure override returns (string[] memory storageLocations) {
    storageLocations = new string[](1);
    storageLocations[0] = "mock://ccv";
    return storageLocations;
  }

  function getInboundImplementation(
    bytes calldata // verifierResults
  ) external view returns (address) {
    return address(this);
  }

  function getOutboundImplementation(
    uint64, // destChainSelector
    bytes memory // extraArgs
  ) external view returns (address) {
    return address(this);
  }
}
