// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.24;

import {IPoolV2} from "../../../interfaces/IPoolV2.sol";
import {AdvancedPoolHooks} from "../../../pools/AdvancedPoolHooks.sol";
import {AdvancedPoolHooksSetup} from "./AdvancedPoolHooksSetup.t.sol";

contract AdvancedPoolHooks_getRequiredCCVsOutbound is AdvancedPoolHooksSetup {
  function test_getRequiredCCVs_Outbound_BaseCCVs() public {
    address[] memory outboundCCVs = new address[](1);
    outboundCCVs[0] = makeAddr("outboundCCV1");

    AdvancedPoolHooks.CCVConfigArg[] memory configArgs = new AdvancedPoolHooks.CCVConfigArg[](1);
    configArgs[0] = AdvancedPoolHooks.CCVConfigArg({
      remoteChainSelector: DEST_CHAIN_SELECTOR,
      outboundCCVs: outboundCCVs,
      thresholdOutboundCCVs: new address[](0),
      inboundCCVs: new address[](0),
      thresholdInboundCCVs: new address[](0)
    });

    s_advancedPoolHooks.applyCCVConfigUpdates(configArgs);

    // Test with amount below threshold, should return only base CCVs.
    address[] memory storedOutbound =
      s_tokenPool.getRequiredCCVs(address(s_token), DEST_CHAIN_SELECTOR, 100, 0, "", IPoolV2.MessageDirection.Outbound);

    assertEq(storedOutbound.length, outboundCCVs.length);
    assertEq(storedOutbound[0], outboundCCVs[0]);
  }

  function test_getRequiredCCVs_Outbound_WithThresholdOutboundCCVs() public {
    address[] memory outboundCCVs = new address[](1);
    outboundCCVs[0] = makeAddr("outboundCCV1");

    address[] memory thresholdOutboundCCVs = new address[](1);
    thresholdOutboundCCVs[0] = makeAddr("thresholdOutboundCCV1");

    AdvancedPoolHooks.CCVConfigArg[] memory configArgs = new AdvancedPoolHooks.CCVConfigArg[](1);
    configArgs[0] = AdvancedPoolHooks.CCVConfigArg({
      remoteChainSelector: DEST_CHAIN_SELECTOR,
      outboundCCVs: outboundCCVs,
      thresholdOutboundCCVs: thresholdOutboundCCVs,
      inboundCCVs: new address[](0),
      thresholdInboundCCVs: new address[](0)
    });

    s_advancedPoolHooks.applyCCVConfigUpdates(configArgs);

    // Threshold is set in AdvancedPoolHooks constructor as CCV_THRESHOLD_AMOUNT

    // Test with amount below threshold, should return only base CCVs.
    address[] memory storedOutboundBelow = s_tokenPool.getRequiredCCVs(
      address(s_token), DEST_CHAIN_SELECTOR, CCV_THRESHOLD_AMOUNT - 500, 0, "", IPoolV2.MessageDirection.Outbound
    );
    assertEq(storedOutboundBelow.length, 1);
    assertEq(storedOutboundBelow[0], outboundCCVs[0]);

    // Test with amount above threshold, should return base + additional CCVs.
    address[] memory storedOutboundAbove = s_tokenPool.getRequiredCCVs(
      address(s_token), DEST_CHAIN_SELECTOR, CCV_THRESHOLD_AMOUNT + 500, 0, "", IPoolV2.MessageDirection.Outbound
    );
    assertEq(storedOutboundAbove.length, 2);
    assertEq(storedOutboundAbove[0], outboundCCVs[0]);
    assertEq(storedOutboundAbove[1], thresholdOutboundCCVs[0]);
  }

  function test_getRequiredCCVs_Outbound_NoAdditionalCCVs() public {
    address[] memory outboundCCVs = new address[](1);
    outboundCCVs[0] = makeAddr("outboundCCV1");

    AdvancedPoolHooks.CCVConfigArg[] memory configArgs = new AdvancedPoolHooks.CCVConfigArg[](1);
    configArgs[0] = AdvancedPoolHooks.CCVConfigArg({
      remoteChainSelector: DEST_CHAIN_SELECTOR,
      outboundCCVs: outboundCCVs,
      thresholdOutboundCCVs: new address[](0),
      inboundCCVs: new address[](0),
      thresholdInboundCCVs: new address[](0)
    });

    s_advancedPoolHooks.applyCCVConfigUpdates(configArgs);

    // Threshold is set in AdvancedPoolHooks constructor

    // Test with amount above threshold but no additional CCVs, should return only base CCVs.
    address[] memory storedOutbound = s_tokenPool.getRequiredCCVs(
      address(s_token), DEST_CHAIN_SELECTOR, CCV_THRESHOLD_AMOUNT + 500, 0, "", IPoolV2.MessageDirection.Outbound
    );
    assertEq(storedOutbound.length, 1);
    assertEq(storedOutbound[0], outboundCCVs[0]);
  }

  function test_getRequiredCCVs_Inbound_BaseCCVs() public {
    address[] memory inboundCCVs = new address[](1);
    inboundCCVs[0] = makeAddr("inboundCCV1");

    AdvancedPoolHooks.CCVConfigArg[] memory configArgs = new AdvancedPoolHooks.CCVConfigArg[](1);
    configArgs[0] = AdvancedPoolHooks.CCVConfigArg({
      remoteChainSelector: DEST_CHAIN_SELECTOR,
      outboundCCVs: new address[](0),
      thresholdOutboundCCVs: new address[](0),
      inboundCCVs: inboundCCVs,
      thresholdInboundCCVs: new address[](0)
    });

    s_advancedPoolHooks.applyCCVConfigUpdates(configArgs);

    // Test with amount below threshold, should return only base CCVs.
    address[] memory storedInbound =
      s_tokenPool.getRequiredCCVs(address(s_token), DEST_CHAIN_SELECTOR, 100, 0, "", IPoolV2.MessageDirection.Inbound);

    assertEq(storedInbound.length, inboundCCVs.length);
    assertEq(storedInbound[0], inboundCCVs[0]);
  }

  function test_getRequiredCCVs_Inbound_WithThresholdInboundCCVs() public {
    address[] memory inboundCCVs = new address[](1);
    inboundCCVs[0] = makeAddr("inboundCCV1");

    address[] memory thresholdInboundCCVs = new address[](1);
    thresholdInboundCCVs[0] = makeAddr("thresholdInboundCCV1");

    AdvancedPoolHooks.CCVConfigArg[] memory configArgs = new AdvancedPoolHooks.CCVConfigArg[](1);
    configArgs[0] = AdvancedPoolHooks.CCVConfigArg({
      remoteChainSelector: DEST_CHAIN_SELECTOR,
      outboundCCVs: new address[](0),
      thresholdOutboundCCVs: new address[](0),
      inboundCCVs: inboundCCVs,
      thresholdInboundCCVs: thresholdInboundCCVs
    });

    s_advancedPoolHooks.applyCCVConfigUpdates(configArgs);

    // Threshold is set in AdvancedPoolHooks constructor

    // Test with amount below threshold, should return only base CCVs.
    address[] memory storedInboundBelow = s_tokenPool.getRequiredCCVs(
      address(s_token), DEST_CHAIN_SELECTOR, CCV_THRESHOLD_AMOUNT - 500, 0, "", IPoolV2.MessageDirection.Inbound
    );
    assertEq(storedInboundBelow.length, 1);
    assertEq(storedInboundBelow[0], inboundCCVs[0]);

    // Test with amount above threshold, should return base + additional CCVs.
    address[] memory storedInboundAbove = s_tokenPool.getRequiredCCVs(
      address(s_token), DEST_CHAIN_SELECTOR, CCV_THRESHOLD_AMOUNT + 500, 0, "", IPoolV2.MessageDirection.Inbound
    );
    assertEq(storedInboundAbove.length, 2);
    assertEq(storedInboundAbove[0], inboundCCVs[0]);
    assertEq(storedInboundAbove[1], thresholdInboundCCVs[0]);
  }

  function test_getRequiredCCVs_Inbound_NoAdditionalCCVs() public {
    address[] memory inboundCCVs = new address[](1);
    inboundCCVs[0] = makeAddr("inboundCCV1");

    AdvancedPoolHooks.CCVConfigArg[] memory configArgs = new AdvancedPoolHooks.CCVConfigArg[](1);
    configArgs[0] = AdvancedPoolHooks.CCVConfigArg({
      remoteChainSelector: DEST_CHAIN_SELECTOR,
      outboundCCVs: new address[](0),
      thresholdOutboundCCVs: new address[](0),
      inboundCCVs: inboundCCVs,
      thresholdInboundCCVs: new address[](0)
    });

    s_advancedPoolHooks.applyCCVConfigUpdates(configArgs);

    // Threshold is set in AdvancedPoolHooks constructor

    // Test with amount above threshold but no additional CCVs, should return only base CCVs.
    address[] memory storedInbound = s_tokenPool.getRequiredCCVs(
      address(s_token), DEST_CHAIN_SELECTOR, CCV_THRESHOLD_AMOUNT + 500, 0, "", IPoolV2.MessageDirection.Inbound
    );
    assertEq(storedInbound.length, 1);
    assertEq(storedInbound[0], inboundCCVs[0]);
  }
}
