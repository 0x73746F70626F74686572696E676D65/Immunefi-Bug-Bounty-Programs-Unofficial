// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.24;

import {IRouter} from "../../../interfaces/IRouter.sol";

import {FinalityCodec} from "../../../libraries/FinalityCodec.sol";

import {Pool} from "../../../libraries/Pool.sol";
import {RateLimiter} from "../../../libraries/RateLimiter.sol";
import {TokenPool} from "../../../pools/TokenPool.sol";
import {AdvancedPoolHooksSetup} from "../AdvancedPoolHooks/AdvancedPoolHooksSetup.t.sol";

contract TokenPool_validateReleaseOrMint is AdvancedPoolHooksSetup {
  uint256 internal constant AMOUNT = 100e18;

  function test_validateReleaseOrMint() public {
    Pool.ReleaseOrMintInV1 memory releaseOrMintIn = _buildReleaseOrMintIn(AMOUNT);

    vm.expectEmit();
    emit TokenPool.InboundRateLimitConsumed(DEST_CHAIN_SELECTOR, address(s_token), AMOUNT);

    vm.startPrank(s_allowedOffRamp);
    uint256 localAmount =
      s_tokenPool.validateReleaseOrMint(releaseOrMintIn, AMOUNT, FinalityCodec.WAIT_FOR_FINALITY_FLAG);

    assertEq(localAmount, AMOUNT);
  }

  function test_validateReleaseOrMint_WithFtfRequestedAndFinalityOnlyConfig() public {
    // Pool explicitly disallows FTF for the *local* chain, which does not affect remote chains. When we then send a
    // message with a block depth of 1, it should *not* revert. The dest pool trusts the source pool and always
    // processes the message. Since the source pool has checked the msg finality against its local chain, the dest pool
    // does not need to do any finality checks.
    s_tokenPool.setAllowedFinalityConfig(FinalityCodec.WAIT_FOR_FINALITY_FLAG);

    Pool.ReleaseOrMintInV1 memory releaseOrMintIn = _buildReleaseOrMintIn(AMOUNT);

    vm.startPrank(s_allowedOffRamp);
    s_tokenPool.validateReleaseOrMint(releaseOrMintIn, AMOUNT, FinalityCodec._encodeBlockDepth(1));
  }

  /// @notice When fast finality is requested but no custom bucket is configured,
  /// the fallback consumes from the default inbound bucket.
  function test_validateReleaseOrMint_NonZeroFinality_FallsBackToDefaultBucket() public {
    // Allow depth-2 FTF on this pool so the inbound finality check passes.
    s_tokenPool.setAllowedFinalityConfig(FinalityCodec._encodeBlockDepth(2));

    Pool.ReleaseOrMintInV1 memory releaseOrMintIn = _buildReleaseOrMintIn(AMOUNT);

    vm.expectEmit();
    emit TokenPool.InboundRateLimitConsumed(DEST_CHAIN_SELECTOR, address(s_token), AMOUNT);

    vm.startPrank(s_allowedOffRamp);
    uint256 localAmount = s_tokenPool.validateReleaseOrMint(releaseOrMintIn, AMOUNT, FinalityCodec._encodeBlockDepth(2));

    assertEq(localAmount, AMOUNT);
  }

  /// @notice When a custom inbound bucket IS configured, the custom event is emitted instead.
  function test_validateReleaseOrMint_NonZeroFinality_UsesCustomBucketWhenConfigured() public {
    // Allow depth-2 FTF on this pool so the inbound finality check passes.
    s_tokenPool.setAllowedFinalityConfig(FinalityCodec._encodeBlockDepth(2));

    RateLimiter.Config memory customInbound = RateLimiter.Config({isEnabled: true, capacity: 1e24, rate: 1e24});
    TokenPool.RateLimitConfigArgs[] memory args = new TokenPool.RateLimitConfigArgs[](1);
    args[0] = TokenPool.RateLimitConfigArgs({
      remoteChainSelector: DEST_CHAIN_SELECTOR,
      fastFinality: true,
      outboundRateLimiterConfig: RateLimiter.Config({isEnabled: true, capacity: 1e24, rate: 1e24}),
      inboundRateLimiterConfig: customInbound
    });
    s_tokenPool.setRateLimitConfig(args);

    Pool.ReleaseOrMintInV1 memory releaseOrMintIn = _buildReleaseOrMintIn(AMOUNT);

    vm.expectEmit();
    emit TokenPool.FastFinalityInboundRateLimitConsumed(DEST_CHAIN_SELECTOR, address(s_token), AMOUNT);

    vm.startPrank(s_allowedOffRamp);
    uint256 localAmount = s_tokenPool.validateReleaseOrMint(releaseOrMintIn, AMOUNT, FinalityCodec._encodeBlockDepth(2));

    assertEq(localAmount, AMOUNT);
  }

  function test_validateReleaseOrMint_RateLimitLocalAmount() public {
    Pool.ReleaseOrMintInV1 memory releaseOrMintIn = _buildReleaseOrMintIn(AMOUNT);

    // Pretend the local amount is 10x the source amount and assert the rate limit is applied on the local amount.
    uint256 localAmount = AMOUNT * 10;

    vm.expectEmit();
    emit TokenPool.InboundRateLimitConsumed({
      remoteChainSelector: releaseOrMintIn.remoteChainSelector, token: releaseOrMintIn.localToken, amount: localAmount
    });

    vm.startPrank(s_allowedOffRamp);
    s_tokenPool.validateReleaseOrMint(releaseOrMintIn, localAmount, FinalityCodec.WAIT_FOR_FINALITY_FLAG);
  }

  function test_validateReleaseOrMint_InvalidToken() public {
    address wrongToken = address(0x456);

    Pool.ReleaseOrMintInV1 memory releaseOrMintIn = _buildReleaseOrMintIn(AMOUNT);
    releaseOrMintIn.localToken = wrongToken; // Invalid token address.

    vm.expectRevert(abi.encodeWithSelector(TokenPool.InvalidToken.selector, wrongToken));
    s_tokenPool.validateReleaseOrMint(releaseOrMintIn, AMOUNT, FinalityCodec.WAIT_FOR_FINALITY_FLAG);
  }

  function test_validateReleaseOrMint_CursedByRMN() public {
    Pool.ReleaseOrMintInV1 memory releaseOrMintIn = _buildReleaseOrMintIn(AMOUNT);

    // Mock RMN to be cursed
    vm.mockCall(
      address(s_mockRMNRemote),
      abi.encodeWithSignature("isCursed(bytes16)", bytes16(uint128(DEST_CHAIN_SELECTOR))),
      abi.encode(true)
    );

    vm.expectRevert(TokenPool.CursedByRMN.selector);
    s_tokenPool.validateReleaseOrMint(releaseOrMintIn, AMOUNT, FinalityCodec.WAIT_FOR_FINALITY_FLAG);
  }

  function test_validateReleaseOrMint_InvalidOffRamp() public {
    Pool.ReleaseOrMintInV1 memory releaseOrMintIn = _buildReleaseOrMintIn(AMOUNT);

    // Mock router to return false for isOffRamp
    vm.mockCall(
      address(s_sourceRouter),
      abi.encodeWithSelector(IRouter.isOffRamp.selector, DEST_CHAIN_SELECTOR, s_allowedOffRamp),
      abi.encode(false)
    );

    vm.expectRevert(abi.encodeWithSelector(TokenPool.CallerIsNotARampOnRouter.selector, s_allowedOffRamp));
    vm.startPrank(s_allowedOffRamp);
    s_tokenPool.validateReleaseOrMint(releaseOrMintIn, AMOUNT, FinalityCodec.WAIT_FOR_FINALITY_FLAG);
  }

  function test_validateReleaseOrMint_InvalidSourcePool() public {
    address invalidPool = address(0x789);

    Pool.ReleaseOrMintInV1 memory releaseOrMintIn = _buildReleaseOrMintIn(AMOUNT);
    releaseOrMintIn.sourcePoolAddress = abi.encode(invalidPool);

    vm.expectRevert(abi.encodeWithSelector(TokenPool.InvalidSourcePoolAddress.selector, abi.encode(invalidPool)));
    vm.startPrank(s_allowedOffRamp);
    s_tokenPool.validateReleaseOrMint(releaseOrMintIn, AMOUNT, FinalityCodec.WAIT_FOR_FINALITY_FLAG);
  }

  function _buildReleaseOrMintIn(
    uint256 amount
  ) internal view returns (Pool.ReleaseOrMintInV1 memory) {
    return Pool.ReleaseOrMintInV1({
      originalSender: abi.encode(OWNER),
      remoteChainSelector: DEST_CHAIN_SELECTOR,
      receiver: OWNER,
      sourceDenominatedAmount: amount,
      localToken: address(s_token),
      sourcePoolAddress: abi.encode(s_initialRemotePool),
      sourcePoolData: abi.encode(uint256(DEFAULT_TOKEN_DECIMALS)),
      offchainTokenData: ""
    });
  }
}
