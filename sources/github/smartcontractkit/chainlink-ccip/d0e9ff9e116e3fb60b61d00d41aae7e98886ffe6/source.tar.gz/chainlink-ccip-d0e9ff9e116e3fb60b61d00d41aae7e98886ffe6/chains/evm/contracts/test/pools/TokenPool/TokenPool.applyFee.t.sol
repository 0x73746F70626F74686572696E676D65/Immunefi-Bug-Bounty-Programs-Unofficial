// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.24;

import {IPoolV2} from "../../../interfaces/IPoolV2.sol";
import {FinalityCodec} from "../../../libraries/FinalityCodec.sol";

import {Pool} from "../../../libraries/Pool.sol";
import {TokenPool} from "../../../pools/TokenPool.sol";
import {AdvancedPoolHooksSetup} from "../AdvancedPoolHooks/AdvancedPoolHooksSetup.t.sol";

contract TokenPool_applyFee is AdvancedPoolHooksSetup {
  function test_applyFee_CustomFinality() public {
    bytes4 minFinality = FinalityCodec._encodeBlockDepth(5);
    uint16 finalityTransferFeeBps = 100;
    uint16 fastFinalityTransferFeeBps = 500;
    uint256 amount = 1_000e18;
    s_tokenPool.setAllowedFinalityConfig(minFinality);
    TokenPool.TokenTransferFeeConfigArgs[] memory feeConfigArgs = new TokenPool.TokenTransferFeeConfigArgs[](1);
    feeConfigArgs[0] = TokenPool.TokenTransferFeeConfigArgs({
      destChainSelector: DEST_CHAIN_SELECTOR,
      tokenTransferFeeConfig: IPoolV2.TokenTransferFeeConfig({
        destGasOverhead: 50_000,
        destBytesOverhead: Pool.CCIP_LOCK_OR_BURN_V1_RET_BYTES,
        finalityFeeUSDCents: 0,
        fastFinalityFeeUSDCents: 0,
        finalityTransferFeeBps: finalityTransferFeeBps,
        fastFinalityTransferFeeBps: fastFinalityTransferFeeBps,
        isEnabled: true
      })
    });
    s_tokenPool.applyTokenTransferFeeConfigUpdates(feeConfigArgs, new uint64[](0));

    Pool.LockOrBurnInV1 memory lockOrBurnIn = Pool.LockOrBurnInV1({
      originalSender: s_sender,
      receiver: s_receiver,
      amount: amount,
      remoteChainSelector: DEST_CHAIN_SELECTOR,
      localToken: address(s_token)
    });

    uint256 amountAfterFee = s_tokenPool.applyFee(lockOrBurnIn, minFinality);
    assertEq(amountAfterFee, amount - ((amount * fastFinalityTransferFeeBps) / BPS_DIVIDER));
  }

  function test_applyFee_DefaultFinality() public {
    uint16 finalityTransferFeeBps = 250; // 2.5%
    uint256 amount = 1_000e18;

    vm.startPrank(OWNER);
    TokenPool.TokenTransferFeeConfigArgs[] memory feeConfigArgs = new TokenPool.TokenTransferFeeConfigArgs[](1);
    feeConfigArgs[0] = TokenPool.TokenTransferFeeConfigArgs({
      destChainSelector: DEST_CHAIN_SELECTOR,
      tokenTransferFeeConfig: IPoolV2.TokenTransferFeeConfig({
        destGasOverhead: 50_000,
        destBytesOverhead: Pool.CCIP_LOCK_OR_BURN_V1_RET_BYTES,
        finalityFeeUSDCents: 0,
        fastFinalityFeeUSDCents: 0,
        finalityTransferFeeBps: finalityTransferFeeBps,
        fastFinalityTransferFeeBps: 0,
        isEnabled: true
      })
    });
    s_tokenPool.applyTokenTransferFeeConfigUpdates(feeConfigArgs, new uint64[](0));

    Pool.LockOrBurnInV1 memory lockOrBurnIn = Pool.LockOrBurnInV1({
      originalSender: s_sender,
      receiver: s_receiver,
      amount: amount,
      remoteChainSelector: DEST_CHAIN_SELECTOR,
      localToken: address(s_token)
    });

    uint256 amountAfterFee = s_tokenPool.applyFee(lockOrBurnIn, FinalityCodec.WAIT_FOR_FINALITY_FLAG);
    assertEq(amountAfterFee, amount - ((amount * finalityTransferFeeBps) / BPS_DIVIDER));
  }

  /// @notice Bps fees round down, so transfers small enough that the fee rounds to zero must still succeed and
  /// forward the full amount. Documents that dust transfers, e.g. of low decimal tokens like USDC, pay no bps fee.
  function test_applyFee_RoundsFeeDownToZeroOnDustAmounts() public {
    uint16 finalityTransferFeeBps = 250; // 2.5%
    // With 250 bps, any amount below 40 smallest units rounds the fee down to zero.
    uint256 amount = 39;

    vm.startPrank(OWNER);
    TokenPool.TokenTransferFeeConfigArgs[] memory feeConfigArgs = new TokenPool.TokenTransferFeeConfigArgs[](1);
    feeConfigArgs[0] = TokenPool.TokenTransferFeeConfigArgs({
      destChainSelector: DEST_CHAIN_SELECTOR,
      tokenTransferFeeConfig: IPoolV2.TokenTransferFeeConfig({
        destGasOverhead: 50_000,
        destBytesOverhead: Pool.CCIP_LOCK_OR_BURN_V1_RET_BYTES,
        finalityFeeUSDCents: 0,
        fastFinalityFeeUSDCents: 0,
        finalityTransferFeeBps: finalityTransferFeeBps,
        fastFinalityTransferFeeBps: 0,
        isEnabled: true
      })
    });
    s_tokenPool.applyTokenTransferFeeConfigUpdates(feeConfigArgs, new uint64[](0));

    Pool.LockOrBurnInV1 memory lockOrBurnIn = Pool.LockOrBurnInV1({
      originalSender: s_sender,
      receiver: s_receiver,
      amount: amount,
      remoteChainSelector: DEST_CHAIN_SELECTOR,
      localToken: address(s_token)
    });

    uint256 amountAfterFee = s_tokenPool.applyFee(lockOrBurnIn, FinalityCodec.WAIT_FOR_FINALITY_FLAG);
    assertEq(amountAfterFee, amount);
  }
}
