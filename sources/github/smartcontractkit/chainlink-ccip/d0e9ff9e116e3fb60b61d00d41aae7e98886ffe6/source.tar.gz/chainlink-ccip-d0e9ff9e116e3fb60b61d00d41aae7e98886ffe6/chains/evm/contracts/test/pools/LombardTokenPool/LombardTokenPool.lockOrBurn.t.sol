// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.24;

import {IPoolV2} from "../../../interfaces/IPoolV2.sol";
import {IBridgeV2} from "../../../interfaces/lombard/IBridgeV2.sol";

import {Pool} from "../../../libraries/Pool.sol";
import {LombardTokenPool} from "../../../pools/Lombard/LombardTokenPool.sol";
import {TokenPool} from "../../../pools/TokenPool.sol";
import {LombardTokenPoolHelper} from "../../helpers/LombardTokenPoolHelper.sol";
import {IERC20Metadata} from "@openzeppelin/contracts@5.3.0/token/ERC20/extensions/IERC20Metadata.sol";

import {MockLombardAdapter} from "../../mocks/MockLombardAdapter.sol";
import {LombardTokenPoolSetup} from "./LombardTokenPoolSetup.t.sol";

contract LombardTokenPool_lockOrBurn is LombardTokenPoolSetup {
  bytes32 internal constant L_CHAIN_ID = bytes32("LCHAIN");
  bytes32 internal constant REMOTE_ADAPTER = bytes32("REMOTE_ADAPTER");

  function setUp() public virtual override {
    super.setUp();
    vm.startPrank(s_allowedOnRamp);
  }

  function test_lockOrBurn_V2_ForwardsToVerifier() public {
    uint256 amount = 1e18;
    deal(address(s_token), address(s_pool), amount);

    (Pool.LockOrBurnOutV1 memory out, uint256 destAmount) = s_pool.lockOrBurn(
      Pool.LockOrBurnInV1({
        receiver: abi.encodePacked(s_receiver),
        remoteChainSelector: DEST_CHAIN_SELECTOR,
        originalSender: OWNER,
        amount: amount,
        localToken: address(s_token)
      }),
      0,
      ""
    );

    assertEq(destAmount, amount);
    assertEq(out.destTokenAddress, abi.encode(s_remoteToken));
    assertEq(out.destPoolData, abi.encode(uint8(DEFAULT_TOKEN_DECIMALS)));
    assertEq(s_token.balanceOf(s_verifierResolver.getOutboundImplementation(DEST_CHAIN_SELECTOR, "")), amount);
    assertEq(s_token.balanceOf(address(s_pool)), 0);
  }

  function test_lockOrBurn_V2_RetainsBpsFeeInPool() public {
    uint16 finalityTransferFeeBps = 1000; // 10%.
    uint256 amount = 1e18;
    uint256 expectedFee = (amount * finalityTransferFeeBps) / 10_000;
    uint256 expectedDestAmount = amount - expectedFee;

    changePrank(OWNER);
    TokenPool.TokenTransferFeeConfigArgs[] memory feeConfigArgs = new TokenPool.TokenTransferFeeConfigArgs[](1);
    feeConfigArgs[0] = TokenPool.TokenTransferFeeConfigArgs({
      destChainSelector: DEST_CHAIN_SELECTOR,
      tokenTransferFeeConfig: IPoolV2.TokenTransferFeeConfig({
        destGasOverhead: 50_000,
        destBytesOverhead: 0,
        finalityFeeUSDCents: 0,
        fastFinalityFeeUSDCents: 0,
        finalityTransferFeeBps: finalityTransferFeeBps,
        fastFinalityTransferFeeBps: finalityTransferFeeBps,
        isEnabled: true
      })
    });
    s_pool.applyTokenTransferFeeConfigUpdates(feeConfigArgs, new uint64[](0));
    changePrank(s_allowedOnRamp);

    deal(address(s_token), address(s_pool), amount);

    (, uint256 destAmount) = s_pool.lockOrBurn(
      Pool.LockOrBurnInV1({
        receiver: abi.encodePacked(s_receiver),
        remoteChainSelector: DEST_CHAIN_SELECTOR,
        originalSender: OWNER,
        amount: amount,
        localToken: address(s_token)
      }),
      0,
      ""
    );

    address verifierImpl = s_verifierResolver.getOutboundImplementation(DEST_CHAIN_SELECTOR, "");
    assertEq(destAmount, expectedDestAmount);
    assertEq(s_token.balanceOf(verifierImpl), expectedDestAmount, "Verifier should only receive the post-fee amount");
    assertEq(s_token.balanceOf(address(s_pool)), expectedFee, "Pool should retain the bps fee");
  }

  function test_lockOrBurn_V1() public {
    uint256 amount = 1e18;
    deal(address(s_token), address(s_pool), amount);

    _configurePathAndBridgeRemoteToken(bytes32(uint256(uint160(s_remoteToken))), bytes32(0));

    vm.expectCall(
      address(s_bridge),
      abi.encodeCall(
        IBridgeV2.deposit,
        (
          L_CHAIN_ID,
          address(s_token),
          OWNER,
          bytes32(uint256(uint160(s_receiver))),
          amount,
          bytes32(uint256(uint160(s_remotePool)))
        )
      )
    );

    vm.expectEmit();
    emit TokenPool.LockedOrBurned({
      remoteChainSelector: DEST_CHAIN_SELECTOR, token: address(s_token), sender: OWNER, amount: amount
    });

    Pool.LockOrBurnOutV1 memory out = s_pool.lockOrBurn(
      Pool.LockOrBurnInV1({
        receiver: abi.encode(s_receiver),
        remoteChainSelector: DEST_CHAIN_SELECTOR,
        originalSender: OWNER,
        amount: amount,
        localToken: address(s_token)
      })
    );

    assertEq(out.destTokenAddress, abi.encode(s_remoteToken));
    assertEq(s_token.balanceOf(address(s_bridge)), amount);
  }

  function test_lockOrBurn_V1_UsesAdapterWhenConfigured() public {
    address tokenAdapter = address(new MockLombardAdapter(address(s_bridge), address(s_token)));
    uint256 amount = 1e18;

    changePrank(OWNER);
    LombardTokenPoolHelper adapterPool = new LombardTokenPoolHelper(
      IERC20Metadata(address(s_token)),
      address(s_verifierResolver),
      s_bridge,
      tokenAdapter,
      address(0),
      address(s_mockRMNRemote),
      address(s_sourceRouter),
      DEFAULT_TOKEN_DECIMALS
    );
    _applyChainUpdates(address(adapterPool));

    bytes32 destToken = bytes32(uint256(uint160(s_initialRemoteToken)));
    adapterPool.setPath(DEST_CHAIN_SELECTOR, L_CHAIN_ID, abi.encode(s_initialRemotePool), bytes32(0));
    s_bridge.setAllowedDestinationToken(L_CHAIN_ID, tokenAdapter, destToken);
    changePrank(s_allowedOnRamp);

    deal(address(s_token), address(adapterPool), amount);

    vm.expectCall(
      address(s_bridge),
      abi.encodeCall(
        IBridgeV2.deposit,
        (
          L_CHAIN_ID,
          tokenAdapter,
          OWNER,
          bytes32(uint256(uint160(s_adapterReceiver))),
          amount,
          bytes32(uint256(uint160(s_initialRemotePool)))
        )
      )
    );

    vm.expectEmit();
    emit TokenPool.LockedOrBurned({
      remoteChainSelector: DEST_CHAIN_SELECTOR, token: address(s_token), sender: OWNER, amount: amount
    });

    Pool.LockOrBurnOutV1 memory out = adapterPool.lockOrBurn(
      Pool.LockOrBurnInV1({
        receiver: abi.encode(s_adapterReceiver),
        remoteChainSelector: DEST_CHAIN_SELECTOR,
        originalSender: OWNER,
        amount: amount,
        localToken: address(s_token)
      })
    );

    assertEq(out.destTokenAddress, abi.encode(s_initialRemoteToken));
    assertEq(s_token.balanceOf(address(s_bridge)), amount);
  }

  function test_lockOrBurn_V2_RevertWhen_OutboundImplementationNotFoundForVerifier() public {
    uint256 amount = 1e18;
    deal(address(s_token), address(s_pool), amount);
    vm.mockCall(
      address(s_verifierResolver),
      abi.encodeCall(s_verifierResolver.getOutboundImplementation, (DEST_CHAIN_SELECTOR, "")),
      abi.encode(address(0))
    );

    vm.expectRevert(LombardTokenPool.OutboundImplementationNotFoundForVerifier.selector);
    s_pool.lockOrBurn(
      Pool.LockOrBurnInV1({
        receiver: abi.encodePacked(s_receiver),
        remoteChainSelector: DEST_CHAIN_SELECTOR,
        originalSender: OWNER,
        amount: amount,
        localToken: address(s_token)
      }),
      0,
      ""
    );
  }

  function test_lockOrBurn_V1_RevertWhen_PathNotExist() public {
    vm.expectRevert(abi.encodeWithSelector(LombardTokenPool.PathNotExist.selector, DEST_CHAIN_SELECTOR));
    s_pool.lockOrBurn(
      Pool.LockOrBurnInV1({
        receiver: abi.encodePacked(s_releaseRecipient),
        remoteChainSelector: DEST_CHAIN_SELECTOR,
        originalSender: OWNER,
        amount: 1e18,
        localToken: address(s_token)
      })
    );
  }

  function test_lockOrBurn_V1_RevertWhen_InvalidReceiver() public {
    _configurePathAndBridgeRemoteToken(bytes32(uint256(uint160(s_remoteToken))), bytes32(0));

    vm.expectRevert(abi.encodeWithSelector(LombardTokenPool.InvalidReceiver.selector, hex"1234"));
    s_pool.lockOrBurn(
      Pool.LockOrBurnInV1({
        receiver: hex"1234",
        remoteChainSelector: DEST_CHAIN_SELECTOR,
        originalSender: OWNER,
        amount: 1e18,
        localToken: address(s_token)
      })
    );
  }

  function test_lockOrBurn_V1_RevertWhen_RemoteTokenOrAdapterMismatch() public {
    _configurePathAndBridgeRemoteToken(bytes32("differentToken"), bytes32(0));

    vm.expectRevert(
      abi.encodeWithSelector(
        LombardTokenPool.RemoteTokenOrAdapterMismatch.selector,
        bytes32("differentToken"),
        bytes32(uint256(uint160(s_remoteToken))),
        bytes32(0)
      )
    );
    s_pool.lockOrBurn(
      Pool.LockOrBurnInV1({
        receiver: abi.encode(s_receiver),
        remoteChainSelector: DEST_CHAIN_SELECTOR,
        originalSender: OWNER,
        amount: 1e18,
        localToken: address(s_token)
      })
    );
  }

  function test_lockOrBurn_V1_AllowsRemoteAdapterTokenMatch() public {
    _configurePathAndBridgeRemoteToken(REMOTE_ADAPTER, REMOTE_ADAPTER);

    uint256 amount = 1e18;
    deal(address(s_token), address(s_pool), amount);

    Pool.LockOrBurnOutV1 memory out = s_pool.lockOrBurn(
      Pool.LockOrBurnInV1({
        receiver: abi.encode(s_receiver),
        remoteChainSelector: DEST_CHAIN_SELECTOR,
        originalSender: OWNER,
        amount: amount,
        localToken: address(s_token)
      })
    );

    assertEq(out.destTokenAddress, abi.encode(s_remoteToken));
    assertEq(s_token.balanceOf(address(s_bridge)), amount);
  }

  function _configurePathAndBridgeRemoteToken(
    bytes32 remoteTokenId,
    bytes32 remoteAdapter
  ) internal {
    changePrank(OWNER);
    s_pool.setPath(DEST_CHAIN_SELECTOR, L_CHAIN_ID, abi.encode(s_remotePool), remoteAdapter);
    s_bridge.setAllowedDestinationToken(L_CHAIN_ID, address(s_token), remoteTokenId);
    changePrank(s_allowedOnRamp);
  }
}
