// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.24;

import {ERC20LockBox} from "../../../pools/ERC20LockBox.sol";
import {BaseERC20} from "../../../tokens/BaseERC20.sol";
import {CrossChainToken} from "../../../tokens/CrossChainToken.sol";
import {BaseTest} from "../../BaseTest.t.sol";
import {AuthorizedCallers} from "@chainlink/contracts/src/v0.8/shared/access/AuthorizedCallers.sol";

import {IERC20} from "@openzeppelin/contracts@5.3.0/token/ERC20/IERC20.sol";

contract ERC20LockBoxSetup is BaseTest {
  IERC20 internal s_token;
  ERC20LockBox internal s_erc20LockBox;
  address internal s_allowedCaller = makeAddr("allowed_caller");
  address internal s_recipient = makeAddr("recipient");

  function setUp() public virtual override {
    super.setUp();
    s_token = IERC20(
      address(
        new CrossChainToken(
          BaseERC20.ConstructorParams({
            name: "LINK",
            symbol: "LNK",
            decimals: 18,
            maxSupply: 0,
            preMint: 0,
            preMintRecipient: address(0),
            ccipAdmin: OWNER
          }),
          OWNER,
          OWNER
        )
      )
    );
    deal(address(s_token), OWNER, type(uint256).max);
    deal(address(s_token), s_allowedCaller, type(uint256).max);

    // Deploy the ERC20 lock box (unsiloed selector = 0).
    s_erc20LockBox = new ERC20LockBox(address(s_token));

    // Configure the allowed caller.
    address[] memory callers = new address[](1);
    callers[0] = s_allowedCaller;
    s_erc20LockBox.applyAuthorizedCallerUpdates(
      AuthorizedCallers.AuthorizedCallerArgs({addedCallers: callers, removedCallers: new address[](0)})
    );
  }

  function _depositTokens(
    uint256 amount
  ) internal {
    vm.startPrank(s_allowedCaller);
    s_token.approve(address(s_erc20LockBox), amount);
    s_erc20LockBox.deposit(address(s_token), 0, amount);
    vm.stopPrank();
  }
}
