// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.24;

import {FinalityCodec} from "../../../libraries/FinalityCodec.sol";
import {TokenPool} from "../../../pools/TokenPool.sol";
import {TokenPoolHelper} from "../../helpers/TokenPoolHelper.sol";
import {TokenPoolSetup} from "./TokenPoolSetup.t.sol";

import {IERC20} from "@openzeppelin/contracts@5.3.0/token/ERC20/IERC20.sol";
import {IERC20Metadata} from "@openzeppelin/contracts@5.3.0/token/ERC20/extensions/IERC20Metadata.sol";

contract TokenPool_constructor is TokenPoolSetup {
  function test_constructor() public view {
    assertEq(address(s_token), address(s_tokenPool.getToken()));
    assertEq(address(s_mockRMNRemote), s_tokenPool.getRmnProxy());
    (address router, address rateLimitAdmin, address feeAggregator) = s_tokenPool.getDynamicConfig();
    assertEq(address(s_sourceRouter), router);
    assertEq(FinalityCodec.WAIT_FOR_FINALITY_FLAG, s_tokenPool.getAllowedFinalityConfig());
    assertEq(address(0), rateLimitAdmin);
    assertEq(address(0), feeAggregator);
    assertEq(DEFAULT_TOKEN_DECIMALS, s_tokenPool.getTokenDecimals());
  }

  function test_constructor_DecimalCallFails() public {
    uint8 decimals = 255;

    vm.mockCallRevert(address(s_token), abi.encodeWithSelector(IERC20Metadata.decimals.selector), "decimals fails");

    s_tokenPool = new TokenPoolHelper(s_token, decimals, address(0), address(s_mockRMNRemote), address(s_sourceRouter));

    assertEq(s_tokenPool.getTokenDecimals(), decimals);
  }

  // Reverts

  function test_RevertWhen_constructorWhen_ZeroAddressNotAllowed() public {
    vm.expectRevert(TokenPool.ZeroAddressInvalid.selector);

    s_tokenPool = new TokenPoolHelper(
      IERC20(address(0)), DEFAULT_TOKEN_DECIMALS, address(0), address(s_mockRMNRemote), address(s_sourceRouter)
    );
  }

  function test_RevertWhen_constructorWhen_InvalidDecimalArgs() public {
    uint8 invalidDecimals = DEFAULT_TOKEN_DECIMALS + 1;

    vm.expectRevert(
      abi.encodeWithSelector(TokenPool.InvalidDecimalArgs.selector, invalidDecimals, DEFAULT_TOKEN_DECIMALS)
    );

    s_tokenPool =
      new TokenPoolHelper(s_token, invalidDecimals, address(0), address(s_mockRMNRemote), address(s_sourceRouter));
  }
}
