# Token Pool Invariants

## 1. Pool Types

- **INV-POOL-1**: All pool types implement the same protocol-level interface. The pool mechanism (lock/release, burn/mint, or variants) is an implementation detail transparent to the OnRamp and OffRamp.
- **INV-POOL-2**: Lock-release pools move tokens into a lockbox and withdraw from a lockbox. They never hold customer funds.
- **INV-POOL-3**: Burn-mint pools destroy tokens on the source chain and create tokens on the destination chain.

---

## 2. Access Control

- **INV-POOL-4**: Only the OnRamp (resolved via the router for the remote chain) may call `lockOrBurn`. The pool verifies the caller's identity against a protocol-provided reference (e.g., router lookup, allowlist, or ticket-based authorization). Caller identity must not rely solely on the caller's self-assertion.
- **INV-POOL-5**: Only the OffRamp may call `releaseOrMint`. The pool verifies the caller's identity against a protocol-provided reference. If a ticket-based pattern is used, the ticket must bind the instrument/token, the pool, the amount, and the message identity — not just the caller party.
- **INV-POOL-6**: The remote chain must be configured on the pool before any `lockOrBurn` or `releaseOrMint` call. Unconfigured chains are rejected.

---

## 3. V1 vs V2 Interface

- **INV-POOL-7**: V1 pools support `lockOrBurn` and `releaseOrMint` without finality or fee parameters. The full token amount is locked/burned and released/minted. V1 is legacy, relevant for v1 CCIP chains migrating to v2.
- **INV-POOL-8**: V2 pools extend V1 with: `getFee`, `getTokenTransferFeeConfig`, `getRequiredCCVs`, and finality-aware `lockOrBurn`/`releaseOrMint` (receiving `requestedFinalityConfig` and `tokenArgs`). Allowed-finality is enforced on outbound `lockOrBurn` and `getFee`; the default TokenPool implementation inbound `releaseOrMint` uses `requestedFinalityConfig` for rate-limit bucket selection only. It effectively delegates finality enforcement to the source-chain pool. Other pool implementations can explicitly check on the destination chain as well; the interface must support this.
- **INV-POOL-9**: V1 pools cannot support FTF or custom token args. See FINALITY_INVARIANTS.md (**INV-FIN-SRC-4**, **INV-FIN-POOL-3**).

---

## 4. Fee Deduction (V2)

- **INV-POOL-10**: If a non-zero bps fee is set, the V2 pools deduct a proportional fee from the token amount before lock/burn: `destTokenAmount = amount - (amount * feeBps / 10000)`. The fee stays in the pool.
- **INV-POOL-11**: The fee rate (`feeBps`) depends on finality: `defaultBlockConfirmationsTransferFeeBps` for finalized transfers, `customBlockConfirmationsTransferFeeBps` for FTF. See FINALITY_INVARIANTS.md for details.
- **INV-POOL-12**: All `feeBps` values (default and custom block confirmations) must be less than 10,000 (100%). Validated at config time.
- **INV-POOL-13**: When fee config is not enabled for a remote chain, `feeBps` defaults to `0` and no fee is deducted.

See FEE_INVARIANTS.md (section 3) for how pool fee quoting integrates with the OnRamp and FeeQuoter fallback.

---

## 5. Decimal Handling

- **INV-POOL-14**: Pools encode their local token decimals into `sourcePoolData` (as part of the `lockOrBurn` return). On the destination, this is used to convert the source-denominated amount to the local token's decimals.
- **INV-POOL-15**: If `sourcePoolData` is empty, the destination pool assumes the source token has the same decimals as the local token.
- **INV-POOL-16**: If `sourcePoolData` is present, it must be exactly 32 bytes encoding a `uint8` decimal value.
- **INV-POOL-17**: When converting from higher to lower decimals, the amount is divided and rounds down. Dust is lost.
- **INV-POOL-18**: When converting from lower to higher decimals, the amount is multiplied. If the multiplication overflows, the transfer reverts.
- **INV-POOL-17a**: On inbound (`releaseOrMint`), decimal conversion from source-chain denomination to local denomination must happen **before** the rate limiter consumes capacity. The rate limiter must enforce its capacity against the local-denomination amount, not the raw source-chain amount.

---

## 6. destBytesOverhead

- **INV-POOL-19**: `destBytesOverhead` is the data availability byte budget attributed to the token transfer for fee calculation.
- **INV-POOL-20**: The minimum `destBytesOverhead` is 32 bytes (the size of a standard `sourcePoolData` encoding).
- **INV-POOL-21**: If `destPoolData` returned by `lockOrBurn` exceeds `destBytesOverhead`, the OnRamp reverts. Pools returning larger data must have a correspondingly larger `destBytesOverhead` configured.

---

## 7. Rate Limiting

### 7.1 Token Bucket Mechanism

- **INV-RL-1**: Rate limiting uses a token bucket: each bucket has `capacity` (maximum tokens), `rate` (tokens refilled per second), and `tokens` (current available tokens).
- **INV-RL-2**: On each consumption, the bucket first refills based on elapsed time: `tokens = min(capacity, tokens + elapsedSeconds * rate)`.
- **INV-RL-3**: If the requested amount exceeds available `tokens`, the transfer reverts.
- **INV-RL-4**: If the bucket is disabled or the requested amount is zero, no consumption occurs.

### 7.2 Inbound vs Outbound

- **INV-RL-5**: Pools maintain separate rate limit buckets for outbound (`lockOrBurn`) and inbound (`releaseOrMint`) per remote chain.
- **INV-RL-6**: FTF transfers may use additional separate rate limit buckets. See FINALITY_INVARIANTS.md (**INV-FIN-POOL-4**, **INV-FIN-POOL-5**).

### 7.3 Configuration

- **INV-RL-7**: Rate limiter configuration is per-remote-chain. Each remote chain can have its own outbound and inbound bucket parameters.
- **INV-RL-8**: When a bucket is enabled, `rate` must not exceed `capacity`.
- **INV-RL-9**: When a bucket is disabled, both `rate` and `capacity` must be zero. This means the rate limits are turned off, allowing any transfer size to go through.
- **INV-RL-10**: Rate limit configuration can be updated by the contract owner or a designated rate limit admin.
- **INV-RL-11**: When rate limiter configuration is updated, the current token count must not increase beyond what time-based refill would naturally produce. A config update must reset the bucket to full capacity.

---

## 8. Pool Configuration

- **INV-PCFG-1**: Remote chains are added and removed via chain update operations. Adding a chain requires a non-empty `remoteTokenAddress`. Removing a chain clears all associated configuration including rate limiters.
- **INV-PCFG-2**: Remote pool addresses are added and removed individually. See ENCODING_INVARIANTS.md (section 3) for encoding format and validation requirements.
- **INV-PCFG-3**: Pool configuration updates (chain adds/removes, remote pool adds/removes) are restricted to the contract owner.

---

## 9. Source Pool Validation (Inbound)

- **INV-PVAL-1**: On `releaseOrMint`, the pool validates that `sourcePoolAddress` (from the inbound message) matches one of the configured remote pool addresses for the source chain. Unrecognized source pools are rejected.
- **INV-PVAL-2**: On inbound token release, if a ticket or voucher mechanism is used for authorization, the ticket must be validated against:
  - The instrument/token being released (`ticket.instrumentId == pool.instrumentId`)
  - The pool performing the release (`ticket.poolId == this pool`)
  - The message that created the ticket (`ticket.messageId` matches)
  Cross-instrument redemption must be impossible.

