// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.24;

import {RouterSetup} from "./RouterSetup.t.sol";

contract Router_constructor is RouterSetup {
  function test_Constructor() public view {
    assertEq("Router 1.2.0", s_router.typeAndVersion());
    assertEq(OWNER, s_router.owner());
  }
}
