// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.24;

import {IRouter} from "../../../interfaces/IRouter.sol";
import {IMessageTransmitter} from "../../../pools/USDC/interfaces/IMessageTransmitter.sol";

import {CCTPVerifier} from "../../../ccvs/CCTPVerifier.sol";
import {BaseVerifier} from "../../../ccvs/components/BaseVerifier.sol";
import {MessageV1Codec} from "../../../libraries/MessageV1Codec.sol";
import {CCTPHelper} from "../../helpers/CCTPHelper.sol";
import {MockE2EUSDCTransmitterCCTPV2} from "../../mocks/MockE2EUSDCTransmitterCCTPV2.sol";
import {MockTokenMinter} from "../../mocks/MockTokenMinter.sol";
import {CCTPVerifierSetup} from "./CCTPVerifierSetup.t.sol";

contract CCTPVerifier_verifyMessage is CCTPVerifierSetup {
  CCTPHelper.CCTPMessage internal s_baseCCTPMessage;
  address internal constant OFFRAMP = address(0x001001001001);

  function setUp() public virtual override {
    super.setUp();

    // Mock the offRamp check.
    vm.mockCall(address(s_router), abi.encodeCall(IRouter.isOffRamp, (DEST_CHAIN_SELECTOR, OFFRAMP)), abi.encode(true));

    s_baseCCTPMessage = CCTPHelper.CCTPMessage({
      header: CCTPHelper.CCTPMessageHeader({
        version: 1,
        sourceDomain: REMOTE_DOMAIN_IDENTIFIER,
        destinationDomain: LOCAL_DOMAIN_IDENTIFIER,
        nonce: bytes32(0),
        sender: bytes32(0),
        recipient: bytes32(abi.encode(s_mockTokenMessenger)),
        destinationCaller: bytes32(abi.encode(s_messageTransmitterProxy)),
        minFinalityThreshold: CCTP_STANDARD_FINALITY_THRESHOLD,
        finalityThresholdExecuted: CCTP_STANDARD_FINALITY_THRESHOLD
      }),
      body: CCTPHelper.CCTPMessageBody({
        version: 1,
        burnToken: bytes32(abi.encode(s_USDCToken)),
        mintRecipient: bytes32(abi.encode(s_tokenReceiverAddress)),
        amount: TRANSFER_AMOUNT,
        messageSender: ALLOWED_CALLER_ON_SOURCE,
        maxFee: 1e6, // 1 USDC
        feeExecuted: 0,
        expirationBlock: block.number + 1000
      }),
      hookData: CCTPHelper.CCTPMessageHookData({verifierVersion: s_cctpVerifier.versionTag(), messageId: bytes32(0)})
    });

    // Set the domain for the source chain.
    CCTPVerifier.SetDomainArgs[] memory domainUpdates = new CCTPVerifier.SetDomainArgs[](1);
    domainUpdates[0] = CCTPVerifier.SetDomainArgs({
      allowedCallerOnDest: ALLOWED_CALLER_ON_DEST,
      allowedCallerOnSource: ALLOWED_CALLER_ON_SOURCE,
      mintRecipientOnDest: bytes32(0),
      domainIdentifier: REMOTE_DOMAIN_IDENTIFIER,
      chainSelector: DEST_CHAIN_SELECTOR,
      enabled: true
    });
    s_cctpVerifier.setDomains(domainUpdates);

    vm.startPrank(OFFRAMP);
  }

  function test_verifyMessage() public {
    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      address(s_USDCToken),
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );

    s_baseCCTPMessage.hookData.messageId = messageHash;
    bytes memory verifierResults = _createVerifierResults(s_cctpVerifier.versionTag(), s_baseCCTPMessage);

    // Ensure that the mint recipient has no tokens yet.
    assertEq(s_USDCToken.balanceOf(s_tokenReceiverAddress), 0);

    vm.expectEmit();
    emit MockE2EUSDCTransmitterCCTPV2.MessageReceived(CCTPHelper._encodeCCTPMessage(s_baseCCTPMessage), new bytes(65));

    s_cctpVerifier.verifyMessage(message, messageHash, verifierResults);

    // Ensure that the mint recipient received the tokens.
    // Mock transmitter always just mints 1 token.
    assertEq(s_USDCToken.balanceOf(s_tokenReceiverAddress), 1);
  }

  function test_verifyMessage_ResolvesLocalMinterThroughTokenMessenger() public {
    // The token messenger's owner can replace the local minter. Move the canonical burn token mapping from the
    // minter the verifier saw at deployment to a newly rotated minter: verification must resolve through the new
    // minter, a stale cached reference would no longer resolve the burn token.
    MockTokenMinter newMinter = new MockTokenMinter();
    newMinter.setLocalToken(REMOTE_DOMAIN_IDENTIFIER, bytes32(abi.encode(s_USDCToken)), address(s_USDCToken));
    s_mockTokenMessenger.i_tokenMinter()
      .setLocalToken(REMOTE_DOMAIN_IDENTIFIER, bytes32(abi.encode(s_USDCToken)), address(0));
    vm.mockCall(
      address(s_mockTokenMessenger),
      abi.encodeCall(s_mockTokenMessenger.localMinter, ()),
      abi.encode(address(newMinter))
    );

    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      address(s_USDCToken),
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );

    s_baseCCTPMessage.hookData.messageId = messageHash;
    bytes memory verifierResults = _createVerifierResults(s_cctpVerifier.versionTag(), s_baseCCTPMessage);

    s_cctpVerifier.verifyMessage(message, messageHash, verifierResults);

    // Mock transmitter always just mints 1 token.
    assertEq(s_USDCToken.balanceOf(s_tokenReceiverAddress), 1);
  }

  function test_verifyMessage_RevertWhen_CursedByRMN() public {
    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      address(s_USDCToken),
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );

    // verifyMessage checks curse status using message.sourceChainSelector.
    _setMockRMNChainCurse(message.sourceChainSelector, true);

    vm.expectRevert(abi.encodeWithSelector(BaseVerifier.CursedByRMN.selector, message.sourceChainSelector));
    s_cctpVerifier.verifyMessage(message, messageHash, "");
  }

  function test_verifyMessage_RevertWhen_InvalidTokenTransferLength() public {
    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      address(s_USDCToken),
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );

    // We expect exactly one token transfer per message.
    message.tokenTransfer = new MessageV1Codec.TokenTransferV1[](0);

    vm.expectRevert(abi.encodeWithSelector(CCTPVerifier.InvalidTokenTransferLength.selector, 0));
    s_cctpVerifier.verifyMessage(message, messageHash, "");
  }

  function test_verifyMessage_RevertWhen_InvalidToken() public {
    address invalidDestToken = makeAddr("invalidDestToken");
    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      invalidDestToken,
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );

    vm.expectRevert(abi.encodeWithSelector(CCTPVerifier.InvalidToken.selector, abi.encodePacked(invalidDestToken)));
    s_cctpVerifier.verifyMessage(message, messageHash, "");
  }

  function test_verifyMessage_RevertWhen_InvalidVerifierResults() public {
    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      address(s_USDCToken),
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );

    vm.expectRevert(abi.encodeWithSelector(CCTPVerifier.InvalidVerifierResults.selector));
    s_cctpVerifier.verifyMessage(message, messageHash, "");
  }

  function test_verifyMessage_RevertWhen_InvalidCCVVersion_VersionPrefix() public {
    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      address(s_USDCToken),
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );
    bytes4 invalidVersion = bytes4(uint32(0x01020304));

    s_baseCCTPMessage.hookData.verifierVersion = invalidVersion;
    bytes memory verifierResults = _createVerifierResults(invalidVersion, s_baseCCTPMessage);

    vm.expectRevert(
      abi.encodeWithSelector(CCTPVerifier.InvalidCCVVersion.selector, s_cctpVerifier.versionTag(), invalidVersion)
    );
    s_cctpVerifier.verifyMessage(message, messageHash, verifierResults);
  }

  function test_verifyMessage_RevertWhen_InvalidCCVVersion_AttestedVersion() public {
    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      address(s_USDCToken),
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );
    bytes4 invalidVersion = bytes4(uint32(0x01020304));

    s_baseCCTPMessage.hookData.verifierVersion = invalidVersion;
    bytes memory verifierResults = _createVerifierResults(s_cctpVerifier.versionTag(), s_baseCCTPMessage);

    vm.expectRevert(
      abi.encodeWithSelector(CCTPVerifier.InvalidCCVVersion.selector, s_cctpVerifier.versionTag(), invalidVersion)
    );
    s_cctpVerifier.verifyMessage(message, messageHash, verifierResults);
  }

  function test_verifyMessage_RevertWhen_InvalidMessageId() public {
    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      address(s_USDCToken),
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );

    bytes memory verifierResults = _createVerifierResults(s_cctpVerifier.versionTag(), s_baseCCTPMessage);

    vm.expectRevert(abi.encodeWithSelector(CCTPVerifier.InvalidMessageId.selector, messageHash, bytes32(0)));
    s_cctpVerifier.verifyMessage(message, messageHash, verifierResults);
  }

  function test_verifyMessage_RevertWhen_UnknownDomain() public {
    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      address(s_USDCToken),
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );

    s_baseCCTPMessage.hookData.messageId = messageHash;
    bytes memory verifierResults = _createVerifierResults(s_cctpVerifier.versionTag(), s_baseCCTPMessage);

    // Disable domain.
    CCTPVerifier.SetDomainArgs[] memory domainUpdates = new CCTPVerifier.SetDomainArgs[](1);
    domainUpdates[0] = CCTPVerifier.SetDomainArgs({
      allowedCallerOnDest: ALLOWED_CALLER_ON_DEST,
      allowedCallerOnSource: ALLOWED_CALLER_ON_SOURCE,
      mintRecipientOnDest: bytes32(0),
      domainIdentifier: REMOTE_DOMAIN_IDENTIFIER,
      chainSelector: DEST_CHAIN_SELECTOR,
      enabled: false
    });

    vm.startPrank(OWNER);
    s_cctpVerifier.setDomains(domainUpdates);
    vm.startPrank(OFFRAMP);

    vm.expectRevert(abi.encodeWithSelector(CCTPVerifier.UnknownDomain.selector, DEST_CHAIN_SELECTOR));
    s_cctpVerifier.verifyMessage(message, messageHash, verifierResults);
  }

  function test_verifyMessage_RevertWhen_InvalidSourceDomain() public {
    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      address(s_USDCToken),
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );

    s_baseCCTPMessage.hookData.messageId = messageHash;
    uint32 wrongSourceDomain = 7777;
    s_baseCCTPMessage.header.sourceDomain = wrongSourceDomain;
    bytes memory verifierResults = _createVerifierResults(s_cctpVerifier.versionTag(), s_baseCCTPMessage);

    vm.expectRevert(
      abi.encodeWithSelector(CCTPVerifier.InvalidSourceDomain.selector, REMOTE_DOMAIN_IDENTIFIER, wrongSourceDomain)
    );
    s_cctpVerifier.verifyMessage(message, messageHash, verifierResults);
  }

  function test_verifyMessage_RevertWhen_InvalidBurnToken() public {
    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      address(s_USDCToken),
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );

    s_baseCCTPMessage.hookData.messageId = messageHash;
    // Circle's canonical mapping has no entry for this burnToken, so it resolves to address(0).
    bytes32 unmappedBurnToken = bytes32(abi.encode(makeAddr("unmappedBurnToken")));
    s_baseCCTPMessage.body.burnToken = unmappedBurnToken;
    bytes memory verifierResults = _createVerifierResults(s_cctpVerifier.versionTag(), s_baseCCTPMessage);

    vm.expectRevert(abi.encodeWithSelector(CCTPVerifier.InvalidBurnToken.selector, address(s_USDCToken), address(0)));
    s_cctpVerifier.verifyMessage(message, messageHash, verifierResults);
  }

  function test_verifyMessage_RevertWhen_InvalidRecipient() public {
    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      address(s_USDCToken),
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );

    s_baseCCTPMessage.hookData.messageId = messageHash;
    bytes32 wrongRecipient = bytes32(abi.encode(makeAddr("wrongRecipient")));
    s_baseCCTPMessage.header.recipient = wrongRecipient;
    bytes memory verifierResults = _createVerifierResults(s_cctpVerifier.versionTag(), s_baseCCTPMessage);

    vm.expectRevert(
      abi.encodeWithSelector(
        CCTPVerifier.InvalidRecipient.selector, bytes32(abi.encode(s_mockTokenMessenger)), wrongRecipient
      )
    );
    s_cctpVerifier.verifyMessage(message, messageHash, verifierResults);
  }

  function test_verifyMessage_RevertWhen_InvalidBurnMessageBodyVersion() public {
    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      address(s_USDCToken),
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );

    s_baseCCTPMessage.hookData.messageId = messageHash;
    s_baseCCTPMessage.body.version = 0;
    bytes memory verifierResults = _createVerifierResults(s_cctpVerifier.versionTag(), s_baseCCTPMessage);

    vm.expectRevert(abi.encodeWithSelector(CCTPVerifier.InvalidBurnMessageBodyVersion.selector, 1, 0));
    s_cctpVerifier.verifyMessage(message, messageHash, verifierResults);
  }

  function test_verifyMessage_RevertWhen_InvalidMessageSender() public {
    bytes32 invalidMessageSender = keccak256("invalidMessageSender");
    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      address(s_USDCToken),
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );

    s_baseCCTPMessage.hookData.messageId = messageHash;
    s_baseCCTPMessage.body.messageSender = invalidMessageSender;
    bytes memory verifierResults = _createVerifierResults(s_cctpVerifier.versionTag(), s_baseCCTPMessage);

    vm.expectRevert(
      abi.encodeWithSelector(CCTPVerifier.InvalidMessageSender.selector, ALLOWED_CALLER_ON_SOURCE, invalidMessageSender)
    );
    s_cctpVerifier.verifyMessage(message, messageHash, verifierResults);
  }

  function test_verifyMessage_RevertWhen_ReceiveMessageCallFailed() public {
    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      address(s_USDCToken),
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );

    s_baseCCTPMessage.hookData.messageId = messageHash;
    bytes memory verifierResults = _createVerifierResults(s_cctpVerifier.versionTag(), s_baseCCTPMessage);

    vm.mockCall(
      address(s_mockMessageTransmitter),
      abi.encodeWithSelector(IMessageTransmitter.receiveMessage.selector),
      abi.encode(false)
    );
    vm.expectRevert(abi.encodeWithSelector(CCTPVerifier.ReceiveMessageCallFailed.selector));
    s_cctpVerifier.verifyMessage(message, messageHash, verifierResults);
  }

  function test_verifyMessage_RevertWhen_CallerIsNotOffRamp() public {
    address invalidCaller = makeAddr("invalidCaller");

    // Mock the router to return false for isOffRamp with the invalid caller. If we don't mock the call reverts because
    // it's not a real router.
    vm.mockCall(
      address(s_router), abi.encodeCall(IRouter.isOffRamp, (DEST_CHAIN_SELECTOR, invalidCaller)), abi.encode(false)
    );

    (MessageV1Codec.MessageV1 memory message, bytes32 messageHash) = _createCCIPMessage(
      DEST_CHAIN_SELECTOR,
      SOURCE_CHAIN_SELECTOR,
      CCIP_FAST_FINALITY_THRESHOLD,
      address(s_USDCToken),
      TRANSFER_AMOUNT,
      s_tokenReceiver
    );

    vm.stopPrank();
    vm.startPrank(invalidCaller);

    vm.expectRevert(abi.encodeWithSelector(BaseVerifier.CallerIsNotARampOnRouter.selector, invalidCaller));
    s_cctpVerifier.verifyMessage(message, messageHash, "");
  }
}
