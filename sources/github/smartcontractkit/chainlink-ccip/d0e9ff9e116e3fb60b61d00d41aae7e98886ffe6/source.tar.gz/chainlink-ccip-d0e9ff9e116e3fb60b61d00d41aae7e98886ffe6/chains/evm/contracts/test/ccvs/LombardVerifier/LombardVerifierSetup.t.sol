// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.24;

import {IRouter} from "../../../interfaces/IRouter.sol";
import {IBridgeV3} from "../../../interfaces/lombard/IBridgeV3.sol";

import {LombardVerifier} from "../../../ccvs/LombardVerifier.sol";
import {BaseVerifier} from "../../../ccvs/components/BaseVerifier.sol";
import {FinalityCodec} from "../../../libraries/FinalityCodec.sol";
import {Internal} from "../../../libraries/Internal.sol";
import {MessageV1Codec} from "../../../libraries/MessageV1Codec.sol";
import {BaseERC20} from "../../../tokens/BaseERC20.sol";
import {CrossChainToken} from "../../../tokens/CrossChainToken.sol";
import {MockLombardBridge} from "../../mocks/MockLombardBridge.sol";
import {MockLombardMailbox} from "../../mocks/MockLombardMailbox.sol";
import {BaseVerifierSetup} from "../components/BaseVerifier/BaseVerifierSetup.t.sol";

contract LombardVerifierSetup is BaseVerifierSetup {
  bytes4 internal constant VERSION_TAG_V2_0_0 = bytes4(keccak256("LombardVerifier 2.0.0"));
  uint8 internal constant LOMBARD_VERSION = 2;

  LombardVerifier internal s_lombardVerifier;
  MockLombardBridge internal s_mockBridge;
  MockLombardMailbox internal s_mockMailbox;
  CrossChainToken internal s_testToken;

  bytes32 internal constant LOMBARD_CHAIN_ID = bytes32(uint256(10000));
  bytes32 internal constant ALLOWED_CALLER = bytes32(uint256(0x123456));
  bytes32 internal constant REMOTE_BRIDGE_SENDER = bytes32(uint256(0x999999));
  uint256 internal constant TRANSFER_AMOUNT = 1e18;
  address internal s_destToken = makeAddr("destToken");

  function setUp() public virtual override {
    super.setUp();

    s_mockBridge = new MockLombardBridge();
    s_mockMailbox = MockLombardMailbox(s_mockBridge.s_mailbox());
    // Set default execution result matching the version tag format.
    s_mockMailbox.setMessageId(abi.encodePacked(VERSION_TAG_V2_0_0, bytes32(0)));

    s_lombardVerifier = new LombardVerifier(
      LombardVerifier.DynamicConfig({feeAggregator: FEE_AGGREGATOR}),
      IBridgeV3(address(s_mockBridge)),
      s_storageLocations,
      address(s_mockRMNRemote),
      VERSION_TAG_V2_0_0
    );

    // Deploy test token and add it as a supported token.
    s_testToken = new CrossChainToken(
      BaseERC20.ConstructorParams({
        name: "Test Token",
        symbol: "TEST",
        decimals: 18,
        maxSupply: 0,
        preMint: 0,
        preMintRecipient: address(0),
        ccipAdmin: OWNER
      }),
      OWNER,
      OWNER
    );
    deal(address(s_testToken), address(s_lombardVerifier), TRANSFER_AMOUNT);
    LombardVerifier.SupportedTokenArgs[] memory tokensToAdd = new LombardVerifier.SupportedTokenArgs[](1);
    tokensToAdd[0] = LombardVerifier.SupportedTokenArgs({localToken: address(s_testToken), localAdapter: address(0)});
    s_lombardVerifier.updateSupportedTokens(new address[](0), tokensToAdd);
    s_mockBridge.setAllowedDestinationToken(LOMBARD_CHAIN_ID, address(s_testToken), bytes32(abi.encode(s_destToken)));

    // Set up remote chain config with the router.
    BaseVerifier.RemoteChainConfigArgs[] memory remoteChainConfigs = new BaseVerifier.RemoteChainConfigArgs[](2);
    remoteChainConfigs[0] = _getRemoteChainConfig(s_router, DEST_CHAIN_SELECTOR, false);
    remoteChainConfigs[1] = _getRemoteChainConfig(s_router, SOURCE_CHAIN_SELECTOR, false);
    s_lombardVerifier.applyRemoteChainConfigUpdates(remoteChainConfigs);

    // Set the path for the destination chain.
    s_lombardVerifier.setPath(
      DEST_CHAIN_SELECTOR, LOMBARD_CHAIN_ID, abi.encodePacked(ALLOWED_CALLER), abi.encodePacked(REMOTE_BRIDGE_SENDER)
    );
    // Set the path for the source chain, so that incoming messages from it can be validated in verifyMessage tests.
    s_lombardVerifier.setPath(
      SOURCE_CHAIN_SELECTOR, LOMBARD_CHAIN_ID, abi.encodePacked(ALLOWED_CALLER), abi.encodePacked(REMOTE_BRIDGE_SENDER)
    );

    // Mock the router to return true for the valid offRamp.
    vm.mockCall(
      address(s_router), abi.encodeCall(IRouter.isOffRamp, (DEST_CHAIN_SELECTOR, s_offRamp)), abi.encode(true)
    );

    // Mock the router to return the valid onRamp.
    vm.mockCall(address(s_router), abi.encodeCall(IRouter.getOnRamp, (DEST_CHAIN_SELECTOR)), abi.encode(s_onRamp));
    vm.mockCall(
      address(s_router), abi.encodeCall(IRouter.isOffRamp, (SOURCE_CHAIN_SELECTOR, s_offRamp)), abi.encode(true)
    );
  }

  function _createForwardMessage(
    address sourceToken,
    address receiver
  ) internal returns (MessageV1Codec.MessageV1 memory, bytes32) {
    MessageV1Codec.TokenTransferV1[] memory tokenTransfer = new MessageV1Codec.TokenTransferV1[](1);
    tokenTransfer[0] = MessageV1Codec.TokenTransferV1({
      amount: TRANSFER_AMOUNT,
      sourcePoolAddress: abi.encode(makeAddr("sourcePool")),
      sourceTokenAddress: abi.encode(sourceToken),
      destTokenAddress: abi.encodePacked(s_destToken),
      tokenReceiver: abi.encodePacked(receiver),
      extraData: ""
    });

    MessageV1Codec.MessageV1 memory message = MessageV1Codec.MessageV1({
      sourceChainSelector: SOURCE_CHAIN_SELECTOR,
      destChainSelector: DEST_CHAIN_SELECTOR,
      messageNumber: 1,
      executionGasLimit: GAS_LIMIT * 2,
      ccipReceiveGasLimit: GAS_LIMIT,
      finality: FinalityCodec.WAIT_FOR_FINALITY_FLAG,
      ccvAndExecutorHash: bytes32(0),
      onRampAddress: abi.encode(s_onRamp),
      offRampAddress: abi.encodePacked(s_offRamp),
      sender: abi.encode(OWNER),
      receiver: abi.encodePacked(receiver),
      destBlob: "",
      tokenTransfer: tokenTransfer,
      data: ""
    });

    bytes32 messageId = keccak256(MessageV1Codec._encodeMessageV1(message));
    return (message, messageId);
  }

  /// @notice Generates a valid rawPayload for use in verifyMessage tests.
  /// @dev The rawPayload structure matches what Lombard bridge expects:
  /// [version (4 bytes)][abi.encode(destinationChain, nonce, sender, recipient, destinationCaller, msgBody)]
  /// where msgBody layout (read by assembly in _validatePayload):
  ///   byte 0:       version (1 byte)
  ///   bytes 1..32:  token (32 bytes)
  ///   bytes 33..64: sender (32 bytes)
  ///   bytes 65..96: recipient (32 bytes)
  ///   bytes 97..128: amount (32 bytes)
  ///   bytes 129..164: optionalMessage (36 bytes: versionTag + messageId)
  /// @param destToken The destination token address.
  /// @param sender The sender address.
  /// @param tokenReceiver The token receiver address.
  /// @param amount The amount to transfer.
  /// @param messageId The message ID.
  /// @return rawPayload The encoded payload, with destinationCaller set to the LombardVerifier under test.
  function _generateValidRawPayload(
    bytes memory destToken,
    bytes memory sender,
    bytes memory tokenReceiver,
    uint256 amount,
    bytes32 messageId
  ) internal view returns (bytes memory) {
    return _generateRawPayload(destToken, sender, tokenReceiver, amount, address(s_lombardVerifier), messageId);
  }

  /// @notice Generates a rawPayload with an explicit destinationCaller. The envelope sender and recipient default to
  /// REMOTE_BRIDGE_SENDER and the mock bridge address (valid values).
  function _generateRawPayload(
    bytes memory destToken,
    bytes memory sender,
    bytes memory tokenReceiver,
    uint256 amount,
    address destinationCaller,
    bytes32 messageId
  ) internal view returns (bytes memory) {
    return
      _generateRawPayload(destToken, sender, tokenReceiver, amount, destinationCaller, REMOTE_BRIDGE_SENDER, messageId);
  }

  /// @notice Generates a rawPayload with an explicit destinationCaller and envelope sender, for tests that need to
  /// exercise an invalid remote bridge sender. The recipient defaults to the mock bridge address (a valid value).
  function _generateRawPayload(
    bytes memory destToken,
    bytes memory sender,
    bytes memory tokenReceiver,
    uint256 amount,
    address destinationCaller,
    bytes32 envelopeSender,
    bytes32 messageId
  ) internal view returns (bytes memory) {
    return _generateRawPayload(
      destToken, sender, tokenReceiver, amount, destinationCaller, envelopeSender, address(s_mockBridge), messageId
    );
  }

  /// @notice Generates a rawPayload with a fully explicit destinationCaller, envelope sender, and recipient, for
  /// tests that need to exercise an invalid recipient.
  function _generateRawPayload(
    bytes memory destToken,
    bytes memory sender,
    bytes memory tokenReceiver,
    uint256 amount,
    address destinationCaller,
    bytes32 envelopeSender,
    address recipient,
    bytes32 messageId
  ) internal pure returns (bytes memory) {
    bytes memory msgBody = abi.encodePacked(
      LOMBARD_VERSION,
      Internal._leftPadBytesToBytes32(destToken),
      Internal._leftPadBytesToBytes32(sender),
      Internal._leftPadBytesToBytes32(tokenReceiver),
      bytes32(amount),
      VERSION_TAG_V2_0_0,
      messageId
    );

    // Encode the full payload structure
    bytes memory encodedData = abi.encode(
      bytes32(LOMBARD_CHAIN_ID), // destinationChain
      uint256(1), // nonce
      envelopeSender, // sender
      recipient,
      destinationCaller,
      msgBody
    );

    // Prepend version tag (4 bytes)
    return abi.encodePacked(bytes4(0x01000000), encodedData);
  }
}
