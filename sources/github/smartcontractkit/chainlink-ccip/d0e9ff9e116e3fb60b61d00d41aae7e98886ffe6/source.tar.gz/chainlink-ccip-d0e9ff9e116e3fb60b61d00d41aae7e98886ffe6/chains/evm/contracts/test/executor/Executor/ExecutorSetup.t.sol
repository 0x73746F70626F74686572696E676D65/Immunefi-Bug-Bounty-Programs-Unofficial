// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.24;

import {Executor} from "../../../executor/Executor.sol";
import {FinalityCodec} from "../../../libraries/FinalityCodec.sol";
import {BaseTest} from "../../BaseTest.t.sol";

import {BaseERC20} from "../../../tokens/BaseERC20.sol";
import {CrossChainToken} from "../../../tokens/CrossChainToken.sol";

contract ExecutorSetup is BaseTest {
  address internal constant INITIAL_CCV = address(121212);
  address internal constant FEE_AGGREGATOR = address(999999);
  uint8 internal constant INITIAL_MAX_CCVS = 1;
  uint16 internal constant DEFAULT_EXEC_FEE_USD_CENTS = 89;
  bytes4 internal s_minFinalityConfig = FinalityCodec._encodeBlockDepth(50);

  uint8 internal constant EVM_ADDRESS_LENGTH = 20;

  Executor internal s_executor;
  address internal s_sourceFeeToken;

  function setUp() public virtual override {
    super.setUp();

    Executor.DynamicConfig memory dynamicConfig = Executor.DynamicConfig({
      feeAggregator: FEE_AGGREGATOR, allowedFinalityConfig: s_minFinalityConfig, ccvAllowlistEnabled: true
    });

    s_executor = new Executor(INITIAL_MAX_CCVS, dynamicConfig);
    s_sourceFeeToken = address(
      new CrossChainToken(
        BaseERC20.ConstructorParams({
          name: "test",
          symbol: "test",
          decimals: 18,
          maxSupply: 0,
          preMint: 0,
          preMintRecipient: address(0),
          ccipAdmin: OWNER
        }),
        OWNER,
        OWNER
      )
    );

    address[] memory ccvs = new address[](1);
    ccvs[0] = INITIAL_CCV;
    s_executor.applyAllowedCCVUpdates(new address[](0), ccvs, true);

    Executor.RemoteChainConfigArgs[] memory remoteChains = new Executor.RemoteChainConfigArgs[](1);
    remoteChains[0].destChainSelector = DEST_CHAIN_SELECTOR;
    remoteChains[0].config = Executor.RemoteChainConfig({usdCentsFee: DEFAULT_EXEC_FEE_USD_CENTS, enabled: true});

    s_executor.applyDestChainUpdates(new uint64[](0), remoteChains);
  }
}
