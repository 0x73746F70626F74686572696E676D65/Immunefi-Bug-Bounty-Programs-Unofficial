// SPDX-License-Identifier: Apache-2.0
/*
 * Copyright (c) 2022, Circle Internet Financial Limited.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
pragma solidity ^0.8.0;

interface ITokenMinter {
  /// @notice Returns the local token address associated with the given remote domain and remote token, as configured
  /// by Circle's canonical remote-to-local token mapping.
  /// @param remoteDomain Remote domain the token comes from.
  /// @param remoteToken Address of the token on the remote domain, as bytes32.
  /// @return Local token address, or address(0) if the remote token is not supported.
  function getLocalToken(
    uint32 remoteDomain,
    bytes32 remoteToken
  ) external view returns (address);
}
