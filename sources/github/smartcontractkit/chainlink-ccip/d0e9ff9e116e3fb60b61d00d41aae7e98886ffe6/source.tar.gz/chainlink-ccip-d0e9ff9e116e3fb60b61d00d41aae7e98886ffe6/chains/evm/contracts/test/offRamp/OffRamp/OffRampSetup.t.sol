// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.24;

import {IAny2EVMMessageReceiver} from "../../../interfaces/IAny2EVMMessageReceiver.sol";
import {IAny2EVMMessageReceiverV2} from "../../../interfaces/IAny2EVMMessageReceiverV2.sol";

import {IERC165} from "@openzeppelin/contracts@5.3.0/utils/introspection/IERC165.sol";

import {FinalityCodec} from "../../../libraries/FinalityCodec.sol";
import {OffRamp} from "../../../offRamp/OffRamp.sol";
import {BaseTest} from "../../BaseTest.t.sol";
import {OffRampHelper} from "../../helpers/OffRampHelper.sol";

contract OffRampSetup is BaseTest {
  OffRampHelper internal s_offRamp;
  address internal s_defaultCCV;
  address internal s_tokenAdminRegistry;

  bytes internal s_onRamp;

  function setUp() public virtual override {
    BaseTest.setUp();

    s_defaultCCV = makeAddr("defaultCCV");
    s_tokenAdminRegistry = makeAddr("tokenAdminRegistry");
    s_onRamp = abi.encode(makeAddr("onRamp"));

    s_offRamp = new OffRampHelper(
      OffRamp.StaticConfig({
        localChainSelector: DEST_CHAIN_SELECTOR,
        gasForCallExactCheck: GAS_FOR_CALL_EXACT_CHECK,
        rmnRemote: s_mockRMNRemote,
        tokenAdminRegistry: s_tokenAdminRegistry,
        maxGasBufferToUpdateState: DEFAULT_MAX_GAS_BUFFER_TO_UPDATE_STATE
      })
    );

    address[] memory defaultCCVs = new address[](1);
    defaultCCVs[0] = s_defaultCCV;

    _applySourceConfig(s_onRamp, true, defaultCCVs, new address[](0));
  }

  function _applySourceConfig(
    bytes memory onRamp,
    bool isEnabled,
    address[] memory defaultCCVs,
    address[] memory laneMandatedCCVs
  ) internal {
    bytes[] memory onRamps = new bytes[](1);
    onRamps[0] = onRamp;

    OffRamp.SourceChainConfigArgs[] memory updates = new OffRamp.SourceChainConfigArgs[](1);
    updates[0] = OffRamp.SourceChainConfigArgs({
      router: s_destRouter,
      sourceChainSelector: SOURCE_CHAIN_SELECTOR,
      isEnabled: isEnabled,
      onRamps: onRamps,
      defaultCCVs: defaultCCVs,
      laneMandatedCCVs: laneMandatedCCVs
    });
    s_offRamp.applySourceChainConfigUpdates(updates);
  }

  /// @notice Sets up a receiver address to mock getCCVsAndFinalityConfig responses and interface support.
  /// @param receiver The receiver address to set up.
  /// @param sourceChainSelector The source chain selector for getCCVsAndFinalityConfig mock.
  /// @param requiredCCVs Array of required CCV addresses.
  /// @param optionalCCVs Array of optional CCV addresses.
  /// @param optionalThreshold Threshold for optional CCVs.
  function _setGetCCVsReturnData(
    address receiver,
    uint64 sourceChainSelector,
    address[] memory requiredCCVs,
    address[] memory optionalCCVs,
    uint8 optionalThreshold
  ) internal {
    // If receiver has no code, etch minimal bytecode.
    if (receiver.code.length == 0) {
      // Simple bytecode that just returns without reverting.
      // PUSH1 0x00 (offset), PUSH1 0x00 (length), RETURN (returns empty data).
      vm.etch(receiver, hex"60006000f3");
    }

    // Mock supportsInterface to return true for IERC165 interface.
    vm.mockCall(receiver, abi.encodeCall(IERC165.supportsInterface, (type(IERC165).interfaceId)), abi.encode(true));

    // Mock supportsInterface to return true for IAny2EVMMessageReceiver (V1 - used for isTokenOnlyTransfer check).
    vm.mockCall(
      receiver, abi.encodeCall(IERC165.supportsInterface, (type(IAny2EVMMessageReceiver).interfaceId)), abi.encode(true)
    );

    // Mock supportsInterface to return true for IAny2EVMMessageReceiverV2.
    vm.mockCall(
      receiver,
      abi.encodeCall(IERC165.supportsInterface, (type(IAny2EVMMessageReceiverV2).interfaceId)),
      abi.encode(true)
    );

    // Mock getCCVsAndFinalityConfig function.
    vm.mockCall(
      receiver,
      abi.encodeWithSelector(IAny2EVMMessageReceiverV2.getCCVsAndFinalityConfig.selector, sourceChainSelector),
      abi.encode(requiredCCVs, optionalCCVs, optionalThreshold, FinalityCodec.WAIT_FOR_FINALITY_FLAG)
    );
  }

  /// @notice Convenience function to set up a receiver that returns empty CCVs (falls back to defaults).
  /// @param receiver The receiver address to set up.
  /// @param sourceChainSelector The source chain selector for getCCVsAndFinalityConfig mock.
  function _setGetCCVsReturnData(
    address receiver,
    uint64 sourceChainSelector
  ) internal {
    _setGetCCVsReturnData(receiver, sourceChainSelector, new address[](0), new address[](0), 0);
  }
}
