// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.24;

import {Pool} from "../../../libraries/Pool.sol";
import {TokenPool} from "../../../pools/TokenPool.sol";
import {LockReleaseTokenPoolSetup} from "./LockReleaseTokenPoolSetup.t.sol";

contract LockReleaseTokenPool_releaseOrMint is LockReleaseTokenPoolSetup {
  function setUp() public virtual override {
    LockReleaseTokenPoolSetup.setUp();

    bytes[] memory remotePoolAddresses = new bytes[](1);
    remotePoolAddresses[0] = abi.encode(s_sourcePoolAddress);

    TokenPool.ChainUpdate[] memory chainUpdate = new TokenPool.ChainUpdate[](1);
    chainUpdate[0] = TokenPool.ChainUpdate({
      remoteChainSelector: SOURCE_CHAIN_SELECTOR,
      remotePoolAddresses: remotePoolAddresses,
      remoteTokenAddress: abi.encode(address(2)),
      outboundRateLimiterConfig: _getOutboundRateLimiterConfig(),
      inboundRateLimiterConfig: _getInboundRateLimiterConfig()
    });

    s_lockReleaseTokenPool.applyChainUpdates(new uint64[](0), chainUpdate);
    s_lockReleaseTokenPoolWithAllowList.applyChainUpdates(new uint64[](0), chainUpdate);
  }

  function test_releaseOrMint() public {
    vm.startPrank(s_allowedOffRamp);

    uint256 amount = 100;
    deal(address(s_token), address(s_lockBox), amount);

    vm.expectEmit();
    emit TokenPool.InboundRateLimitConsumed({
      remoteChainSelector: SOURCE_CHAIN_SELECTOR, token: address(s_token), amount: amount
    });

    vm.expectEmit();
    emit TokenPool.ReleasedOrMinted({
      remoteChainSelector: SOURCE_CHAIN_SELECTOR,
      token: address(s_token),
      sender: s_allowedOffRamp,
      recipient: OWNER,
      amount: amount
    });

    s_lockReleaseTokenPool.releaseOrMint(
      Pool.ReleaseOrMintInV1({
        originalSender: bytes(""),
        receiver: OWNER,
        sourceDenominatedAmount: amount,
        localToken: address(s_token),
        remoteChainSelector: SOURCE_CHAIN_SELECTOR,
        sourcePoolAddress: abi.encode(s_sourcePoolAddress),
        sourcePoolData: "",
        offchainTokenData: ""
      })
    );
  }

  function test_releaseOrMintV2() public {
    uint256 amount = 100e18;
    address recipient = makeAddr("recipient");

    // Fund lockBox.
    deal(address(s_token), address(s_lockBox), amount);

    vm.startPrank(s_allowedOffRamp);

    Pool.ReleaseOrMintOutV1 memory output = s_lockReleaseTokenPool.releaseOrMint(
      Pool.ReleaseOrMintInV1({
        originalSender: bytes(""),
        receiver: recipient,
        sourceDenominatedAmount: amount,
        localToken: address(s_token),
        remoteChainSelector: SOURCE_CHAIN_SELECTOR,
        sourcePoolAddress: abi.encode(s_sourcePoolAddress),
        sourcePoolData: "",
        offchainTokenData: ""
      }),
      0
    );

    assertEq(output.destinationAmount, amount);
    assertEq(s_token.balanceOf(recipient), amount);
  }

  function testFuzz_releaseOrMint(
    address recipient,
    uint256 amount
  ) public {
    // Since the owner already has tokens this would break the checks.
    vm.assume(recipient != OWNER);
    vm.assume(recipient != address(0));
    vm.assume(recipient != address(s_token));
    amount = bound(amount, 1, _getInboundRateLimiterConfig().capacity);

    // Makes sure the lockBox always has enough funds.
    deal(address(s_token), address(s_lockBox), amount);
    vm.startPrank(s_allowedOffRamp);

    // Amount is bounded to capacity, so it should always succeed.
    vm.expectEmit();
    emit TokenPool.InboundRateLimitConsumed({
      remoteChainSelector: SOURCE_CHAIN_SELECTOR, token: address(s_token), amount: amount
    });

    vm.expectEmit();
    emit TokenPool.ReleasedOrMinted({
      remoteChainSelector: SOURCE_CHAIN_SELECTOR,
      token: address(s_token),
      sender: s_allowedOffRamp,
      recipient: recipient,
      amount: amount
    });

    s_lockReleaseTokenPool.releaseOrMint(
      Pool.ReleaseOrMintInV1({
        originalSender: bytes(""),
        receiver: recipient,
        sourceDenominatedAmount: amount,
        localToken: address(s_token),
        remoteChainSelector: SOURCE_CHAIN_SELECTOR,
        sourcePoolAddress: abi.encode(s_sourcePoolAddress),
        sourcePoolData: "",
        offchainTokenData: ""
      })
    );
  }

  function test_releaseOrMint_RevertWhen_ChainNotAllowed() public {
    uint64[] memory chainsToRemove = new uint64[](1);
    chainsToRemove[0] = SOURCE_CHAIN_SELECTOR;

    s_lockReleaseTokenPool.applyChainUpdates(chainsToRemove, new TokenPool.ChainUpdate[](0));

    vm.startPrank(s_allowedOffRamp);

    vm.expectRevert(abi.encodeWithSelector(TokenPool.ChainNotAllowed.selector, SOURCE_CHAIN_SELECTOR));
    s_lockReleaseTokenPool.releaseOrMint(
      Pool.ReleaseOrMintInV1({
        originalSender: bytes(""),
        receiver: OWNER,
        sourceDenominatedAmount: 1e5,
        localToken: address(s_token),
        remoteChainSelector: SOURCE_CHAIN_SELECTOR,
        sourcePoolAddress: abi.encode(s_sourcePoolAddress),
        sourcePoolData: "",
        offchainTokenData: ""
      })
    );
  }

  function test_releaseOrMint_RevertWhen_CursedByRMN_PoolMintNotHealthy() public {
    // Should not mint tokens if cursed.
    vm.mockCall(address(s_mockRMNRemote), abi.encodeWithSignature("isCursed(bytes16)"), abi.encode(true));
    uint256 before = s_token.balanceOf(OWNER);
    vm.startPrank(s_allowedOffRamp);
    vm.expectRevert(TokenPool.CursedByRMN.selector);
    s_lockReleaseTokenPool.releaseOrMint(
      Pool.ReleaseOrMintInV1({
        originalSender: bytes(""),
        receiver: OWNER,
        sourceDenominatedAmount: 1e5,
        localToken: address(s_token),
        remoteChainSelector: SOURCE_CHAIN_SELECTOR,
        sourcePoolAddress: _generateSourceTokenData().sourcePoolAddress,
        sourcePoolData: _generateSourceTokenData().extraData,
        offchainTokenData: ""
      })
    );

    assertEq(s_token.balanceOf(OWNER), before);
  }
}
