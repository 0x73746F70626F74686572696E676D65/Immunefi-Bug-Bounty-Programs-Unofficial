// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.24;

import {ERC20LockBox} from "../../../pools/ERC20LockBox.sol";
import {ERC20LockBoxSetup} from "./ERC20LockBoxSetup.t.sol";
import {AuthorizedCallers} from "@chainlink/contracts/src/v0.8/shared/access/AuthorizedCallers.sol";

contract ERC20LockBox_withdraw is ERC20LockBoxSetup {
  function testFuzz_withdraw(
    uint256 amount
  ) public {
    vm.assume(amount != 0);
    amount = bound(amount, 1, type(uint256).max / 2);

    _depositTokens(amount);

    uint256 recipientBalanceBefore = s_token.balanceOf(s_recipient);
    uint256 lockBoxBalanceBefore = s_token.balanceOf(address(s_erc20LockBox));

    vm.startPrank(s_allowedCaller);

    vm.expectEmit();
    emit ERC20LockBox.Withdrawal(address(s_token), s_recipient, amount);

    s_erc20LockBox.withdraw(address(s_token), 0, amount, s_recipient);

    // Verify balances
    assertEq(s_token.balanceOf(s_recipient), recipientBalanceBefore + amount);
    assertEq(s_token.balanceOf(address(s_erc20LockBox)), lockBoxBalanceBefore - amount);
  }

  function test_withdraw_MultipleWithdrawals() public {
    uint256 amount1 = 1000e18;
    uint256 amount2 = 2000e18;

    _depositTokens(amount1);
    _depositTokens(amount2);

    uint256 recipientBalanceBefore = s_token.balanceOf(s_recipient);

    vm.startPrank(s_allowedCaller);

    // Withdraw from first chain selector
    vm.expectEmit();
    emit ERC20LockBox.Withdrawal(address(s_token), s_recipient, amount1);
    s_erc20LockBox.withdraw(address(s_token), 0, amount1, s_recipient);

    // Withdraw from second chain selector
    vm.expectEmit();
    emit ERC20LockBox.Withdrawal(address(s_token), s_recipient, amount2);
    s_erc20LockBox.withdraw(address(s_token), 0, amount2, s_recipient);

    // Verify final balances
    assertEq(s_token.balanceOf(s_recipient), recipientBalanceBefore + amount1 + amount2);
    assertEq(s_token.balanceOf(address(s_erc20LockBox)), 0);
  }

  function test_withdraw_PartialAmount() public {
    uint256 depositAmount = 1000e18;
    uint256 withdrawAmount = 300e18;

    _depositTokens(depositAmount);

    uint256 recipientBalanceBefore = s_token.balanceOf(s_recipient);
    uint256 expectedRemainingBalance = depositAmount - withdrawAmount;

    vm.startPrank(s_allowedCaller);

    vm.expectEmit();
    emit ERC20LockBox.Withdrawal(address(s_token), s_recipient, withdrawAmount);

    s_erc20LockBox.withdraw(address(s_token), 0, withdrawAmount, s_recipient);

    assertEq(s_token.balanceOf(s_recipient), recipientBalanceBefore + withdrawAmount);
    assertEq(s_token.balanceOf(address(s_erc20LockBox)), expectedRemainingBalance);
  }

  function test_withdraw_uint256_max() public {
    uint256 depositAmount = 1000e18;

    _depositTokens(depositAmount);

    uint256 recipientBalanceBefore = s_token.balanceOf(s_recipient);

    vm.startPrank(s_allowedCaller);

    // Emits the balance, not max uint256.
    vm.expectEmit();
    emit ERC20LockBox.Withdrawal(address(s_token), s_recipient, depositAmount);

    s_erc20LockBox.withdraw(address(s_token), 0, type(uint256).max, s_recipient);

    assertEq(s_token.balanceOf(s_recipient), recipientBalanceBefore + depositAmount);
    assertEq(s_token.balanceOf(address(s_erc20LockBox)), 0);
  }

  function test_withdraw_EventEmission() public {
    uint256 amount = 1000e18;
    _depositTokens(amount);

    vm.startPrank(s_allowedCaller);

    vm.expectEmit();
    emit ERC20LockBox.Withdrawal(address(s_token), s_recipient, amount);

    s_erc20LockBox.withdraw(address(s_token), 0, amount, s_recipient);
  }

  function test_withdraw_ToDifferentRecipients() public {
    uint256 amount = 1000e18;
    address recipient1 = makeAddr("recipient1");
    address recipient2 = makeAddr("recipient2");

    _depositTokens(amount * 2);

    vm.startPrank(s_allowedCaller);

    // Withdraw to first recipient
    vm.expectEmit();
    emit ERC20LockBox.Withdrawal(address(s_token), recipient1, amount);
    s_erc20LockBox.withdraw(address(s_token), 0, amount, recipient1);

    // Withdraw to second recipient
    vm.expectEmit();
    emit ERC20LockBox.Withdrawal(address(s_token), recipient2, amount);
    s_erc20LockBox.withdraw(address(s_token), 0, amount, recipient2);

    // Verify both recipients received tokens
    assertEq(s_token.balanceOf(recipient1), amount);
    assertEq(s_token.balanceOf(recipient2), amount);
  }

  // ================================================================
  // │                        Revert Tests                          │
  // ================================================================

  function test_withdraw_RevertWhen_Unauthorized() public {
    uint256 amount = 1000e18;
    _depositTokens(amount);

    vm.startPrank(STRANGER);
    vm.expectRevert(abi.encodeWithSelector(AuthorizedCallers.UnauthorizedCaller.selector, STRANGER));

    s_erc20LockBox.withdraw(address(s_token), 0, amount, s_recipient);
  }

  function test_withdraw_RevertWhen_RecipientCannotBeZeroAddress() public {
    uint256 amount = 1000e18;
    _depositTokens(amount);

    vm.startPrank(s_allowedCaller);
    vm.expectRevert(ERC20LockBox.RecipientCannotBeZeroAddress.selector);

    s_erc20LockBox.withdraw(address(s_token), 0, amount, address(0));
  }

  function test_withdraw_RevertWhen_TokenAmountCannotBeZero() public {
    uint256 amount = 1000e18;
    _depositTokens(amount);

    vm.startPrank(s_allowedCaller);
    vm.expectRevert(ERC20LockBox.TokenAmountCannotBeZero.selector);

    s_erc20LockBox.withdraw(address(s_token), 0, 0, s_recipient);
  }

  function test_withdraw_RevertWhen_InsufficientBalance() public {
    uint256 depositAmount = 1000e18;
    uint256 withdrawAmount = 1500e18;

    _depositTokens(depositAmount);

    vm.startPrank(s_allowedCaller);
    vm.expectRevert(abi.encodeWithSelector(ERC20LockBox.InsufficientBalance.selector, withdrawAmount, depositAmount));

    s_erc20LockBox.withdraw(address(s_token), 0, withdrawAmount, s_recipient);
  }
}
