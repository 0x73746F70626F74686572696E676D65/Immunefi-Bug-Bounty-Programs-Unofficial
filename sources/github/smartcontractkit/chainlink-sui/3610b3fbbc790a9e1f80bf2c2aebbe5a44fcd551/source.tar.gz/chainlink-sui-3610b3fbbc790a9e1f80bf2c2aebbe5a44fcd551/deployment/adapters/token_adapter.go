package adapters

import (
	"encoding/hex"
	"errors"
	"fmt"
	"math/big"
	"strings"

	semver "github.com/Masterminds/semver/v3"
	chainsel "github.com/smartcontractkit/chain-selectors"
	mcmstypes "github.com/smartcontractkit/mcms/types"

	cldf_chain "github.com/smartcontractkit/chainlink-deployments-framework/chain"
	cldfsui "github.com/smartcontractkit/chainlink-deployments-framework/chain/sui"
	"github.com/smartcontractkit/chainlink-deployments-framework/datastore"
	"github.com/smartcontractkit/chainlink-deployments-framework/deployment"
	cldf_ops "github.com/smartcontractkit/chainlink-deployments-framework/operations"

	tokensapi "github.com/smartcontractkit/chainlink-ccip/deployment/tokens"
	cciputils "github.com/smartcontractkit/chainlink-ccip/deployment/utils"
	"github.com/smartcontractkit/chainlink-ccip/deployment/utils/sequences"

	"github.com/smartcontractkit/chainlink-sui/bindings/bind"
	module_burn_mint_token_pool "github.com/smartcontractkit/chainlink-sui/bindings/generated/ccip/ccip_token_pools/burn_mint_token_pool"
	module_lock_release_token_pool "github.com/smartcontractkit/chainlink-sui/bindings/generated/ccip/ccip_token_pools/lock_release_token_pool"
	module_managed_token_pool "github.com/smartcontractkit/chainlink-sui/bindings/generated/ccip/ccip_token_pools/managed_token_pool"
	suideploy "github.com/smartcontractkit/chainlink-sui/deployment"
	sui_ops "github.com/smartcontractkit/chainlink-sui/deployment/ops"
	burnminttokenpoolops "github.com/smartcontractkit/chainlink-sui/deployment/ops/ccip_burn_mint_token_pool"
	lockreleasetokenpoolops "github.com/smartcontractkit/chainlink-sui/deployment/ops/ccip_lock_release_token_pool"
	managedtokenpoolops "github.com/smartcontractkit/chainlink-sui/deployment/ops/ccip_managed_token_pool"
	coin_ops "github.com/smartcontractkit/chainlink-sui/deployment/ops/coin"
	suideployutils "github.com/smartcontractkit/chainlink-sui/deployment/utils"
)

var (
	_ tokensapi.TokenAdapter     = &SuiTokenAdapter{}
	_ tokensapi.TokenRefResolver = &SuiTokenAdapter{}
)

// SuiTokenAdapter implements tokensapi.TokenAdapter and tokensapi.TokenRefResolver for
// Sui CCIP token pools.
//
// Addressing model: on Sui a token is identified by its coin type string
// (0x<package>::<module>::<STRUCT>) and a token pool by its Move package ID (a hex object
// id). The generic TokenAdapter abstraction is address-string based, so this adapter maps:
//   - token AddressRef.Address  -> coin type string
//   - pool  AddressRef.Address  -> pool package id; Qualifier -> token identity
//
// Sui pool state and owner-cap objects are resolved by their explicit token qualifier. Labels
// are retained as display metadata only.
//
// Sequence methods run in MCMS proposal mode: the Sui ops are invoked with Signer=nil so
// they return a TransactionCall, which is bridged into OnChainOutput.BatchOps for the
// generic changesets to assemble MCMS proposals. Methods that publish packages or execute
// reads are the exception.
type SuiTokenAdapter struct{}

// ================================================================
// === Trivial methods                                           ===
// ================================================================

// AddressRefToBytes serializes a Sui AddressRef to bytes. Pool package ids and object ids
// are hex; coin type strings contain "::" and are returned as their raw UTF-8 bytes so the
// coin type round-trips through DeriveTokenDecimals.
func (a *SuiTokenAdapter) AddressRefToBytes(ref datastore.AddressRef) ([]byte, error) {
	if ref.Address == "" {
		return nil, fmt.Errorf("address ref has empty address")
	}
	if strings.Contains(ref.Address, "::") {
		return []byte(ref.Address), nil
	}
	return suideploy.StrToBytes(ref.Address)
}

// DeriveTokenPoolCounterpart returns the token pool bytes unchanged. Sui token pools are
// objects addressed directly; there is no PDA-style derivation from the token like Solana.
func (a *SuiTokenAdapter) DeriveTokenPoolCounterpart(_ deployment.Environment, _ uint64, tokenPool []byte, _ []byte) ([]byte, error) {
	return tokenPool, nil
}

// MigrateLockReleasePoolLiquiditySequence is not supported on Sui. The lockbox-based v2.0
// liquidity migration is an EVM-only flow; nil signals no support.
func (a *SuiTokenAdapter) MigrateLockReleasePoolLiquiditySequence() *cldf_ops.Sequence[tokensapi.MigrateLockReleasePoolLiquidityInput, sequences.OnChainOutput, cldf_chain.BlockChains] {
	return nil
}

// DeployTokenVerify validates a Sui token deployment input. Sui has no fixed decimal cap
// equivalent to EVM's 18 and the deployment is verified on-chain by the publish transaction,
// so this is a no-op for now, mirroring the Solana adapter.
func (a *SuiTokenAdapter) DeployTokenVerify(_ deployment.Environment, _ tokensapi.DeployTokenInput) error {
	return nil
}

// ================================================================
// === Medium methods                                            ===
// ================================================================

// DeriveTokenDecimals reads the token decimals from on-chain coin metadata. The token
// bytes carry the Sui coin type string (see AddressRefToBytes).
func (a *SuiTokenAdapter) DeriveTokenDecimals(e deployment.Environment, chainSelector uint64, _ datastore.AddressRef, token []byte) (uint8, error) {
	chain, ok := e.BlockChains.SuiChains()[chainSelector]
	if !ok {
		return 0, fmt.Errorf("sui chain with selector %d not found", chainSelector)
	}
	coinType := string(token)
	if coinType == "" {
		return 0, fmt.Errorf("token bytes are empty; expected the sui coin type string")
	}
	report, err := cldf_ops.ExecuteOperation(e.OperationsBundle, coin_ops.GetCoinSymbolOp, suiDeps(chain), coinType)
	if err != nil {
		return 0, fmt.Errorf("failed to fetch coin metadata for type %s: %w", coinType, err)
	}
	if report.Output.Decimals < 0 || report.Output.Decimals > 255 {
		return 0, fmt.Errorf("invalid decimals %d for coin type %s", report.Output.Decimals, coinType)
	}
	return uint8(report.Output.Decimals), nil
}

// SetTokenPoolRateLimits sets the default-lane rate limits on a Sui token pool as an MCMS
// proposal. Sui pools have a single bucket per remote lane, so fastFinality buckets are
// not supported and only the default bucket is applied. A missing default bucket means no
// rate-limit update for this lane and the sequence no-ops.
func (a *SuiTokenAdapter) SetTokenPoolRateLimits() *cldf_ops.Sequence[tokensapi.TPRLRemotes, sequences.OnChainOutput, cldf_chain.BlockChains] {
	return cldf_ops.NewSequence(
		"sui-adapter:set-token-pool-rate-limits",
		&suideploy.Version1_0_0,
		"Set rate limits on a Sui token pool as an MCMS proposal",
		func(b cldf_ops.Bundle, chains cldf_chain.BlockChains, input tokensapi.TPRLRemotes) (sequences.OnChainOutput, error) {
			rl, ok := input.GetBucketForFinality(false)
			if !ok {
				b.Logger.Warnf("skipping rate limiter config for token pool (%s) on chain %d since no default bucket was provided", input.TokenPoolRef.Address, input.ChainSelector)
				return sequences.OnChainOutput{}, nil
			}

			chain, ok := chains.SuiChains()[input.ChainSelector]
			if !ok {
				return sequences.OnChainOutput{}, fmt.Errorf("sui chain with selector %d not found", input.ChainSelector)
			}
			coinType, _, err := resolveSuiCoinType(input.ExistingDataStore, input.ChainSelector, input.TokenRef)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("resolve sui token ref on chain %d: %w", input.ChainSelector, err)
			}
			qualifier, err := suiTokenQualifier(input.TokenPoolRef)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("failed to resolve token qualifier: %w", err)
			}
			stateObjID, ownerCapID, err := resolveSuiPoolObjects(input.ExistingDataStore, input.ChainSelector, input.TokenPoolRef.Type, qualifier)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("failed to resolve sui pool objects: %w", err)
			}

			obCap, err := bigToU64(rl.OutboundRateLimiterConfig.Capacity)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("outbound capacity: %w", err)
			}
			obRate, err := bigToU64(rl.OutboundRateLimiterConfig.Rate)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("outbound rate: %w", err)
			}
			ibCap, err := bigToU64(rl.InboundRateLimiterConfig.Capacity)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("inbound capacity: %w", err)
			}
			ibRate, err := bigToU64(rl.InboundRateLimiterConfig.Rate)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("inbound rate: %w", err)
			}

			deps := suiDeps(chain)
			remote := input.RemoteChainSelector
			var call sui_ops.TransactionCall
			switch input.TokenPoolRef.Type {
			case datastore.ContractType(suideploy.SuiBnMTokenPoolType):
				r, err := cldf_ops.ExecuteOperation(b, burnminttokenpoolops.BurnMintTokenPoolSetChainRateLimiterOp, deps, burnminttokenpoolops.BurnMintTokenPoolSetChainRateLimiterInput{
					BurnMintPackageId:    input.TokenPoolRef.Address,
					CoinObjectTypeArg:    coinType,
					StateObjectId:        stateObjID,
					OwnerCap:             ownerCapID,
					RemoteChainSelectors: []uint64{remote},
					OutboundIsEnableds:   []bool{rl.OutboundRateLimiterConfig.IsEnabled},
					OutboundCapacities:   []uint64{obCap},
					OutboundRates:        []uint64{obRate},
					InboundIsEnableds:    []bool{rl.InboundRateLimiterConfig.IsEnabled},
					InboundCapacities:    []uint64{ibCap},
					InboundRates:         []uint64{ibRate},
				})
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to set rate limits on burn-mint pool: %w", err)
				}
				call = r.Output.Call
			case datastore.ContractType(suideploy.SuiManagedTokenPoolType):
				r, err := cldf_ops.ExecuteOperation(b, managedtokenpoolops.ManagedTokenPoolSetChainRateLimiterOp, deps, managedtokenpoolops.ManagedTokenPoolSetChainRateLimiterInput{
					ManagedTokenPoolPackageId: input.TokenPoolRef.Address,
					CoinObjectTypeArg:         coinType,
					StateObjectId:             stateObjID,
					OwnerCap:                  ownerCapID,
					RemoteChainSelectors:      []uint64{remote},
					OutboundIsEnableds:        []bool{rl.OutboundRateLimiterConfig.IsEnabled},
					OutboundCapacities:        []uint64{obCap},
					OutboundRates:             []uint64{obRate},
					InboundIsEnableds:         []bool{rl.InboundRateLimiterConfig.IsEnabled},
					InboundCapacities:         []uint64{ibCap},
					InboundRates:              []uint64{ibRate},
				})
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to set rate limits on managed pool: %w", err)
				}
				call = r.Output.Call
			case datastore.ContractType(suideploy.SuiLnRTokenPoolType):
				r, err := cldf_ops.ExecuteOperation(b, lockreleasetokenpoolops.LockReleaseTokenPoolSetChainRateLimiterOp, deps, lockreleasetokenpoolops.LockReleaseTokenPoolSetChainRateLimiterInput{
					LockReleasePackageId: input.TokenPoolRef.Address,
					CoinObjectTypeArg:    coinType,
					StateObjectId:        stateObjID,
					OwnerCap:             ownerCapID,
					RemoteChainSelectors: []uint64{remote},
					OutboundIsEnableds:   []bool{rl.OutboundRateLimiterConfig.IsEnabled},
					OutboundCapacities:   []uint64{obCap},
					OutboundRates:        []uint64{obRate},
					InboundIsEnableds:    []bool{rl.InboundRateLimiterConfig.IsEnabled},
					InboundCapacities:    []uint64{ibCap},
					InboundRates:         []uint64{ibRate},
				})
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to set rate limits on lock-release pool: %w", err)
				}
				call = r.Output.Call
			default:
				return sequences.OnChainOutput{}, fmt.Errorf("unsupported sui token pool type %s for SetTokenPoolRateLimits", input.TokenPoolRef.Type)
			}
			return batchOpFromCall(input.ChainSelector, call)
		},
	)
}

// UpdateAuthorities returns ownership step 2 of 3 as an MCMS proposal: the MCMS timelock
// calls accept_ownership on the pool, which asserts ctx.sender() == pending_transfer.to == MCMS.
//
// The full Sui pool→MCMS ownership flow is EOA/MCMS/EOA:
//  1. EOA transfer_ownership(To: MCMS) — performed by DeployTokenPoolForToken at deploy time,
//     setting a pending (not-yet-accepted) transfer.
//  2. MCMS accept_ownership — this method, returned as an MCMS proposal (Signer=nil → Call).
//  3. EOA execute_ownership_transfer_to_mcms — consumes the OwnerCap and registers the MCMS
//     entrypoint; run EOA-direct via the Sui cs_mcms_execute_ownership_transfer changeset
//     after this accept proposal lands. ownable::execute_ownership_transfer_to_mcms asserts
//     pending_transfer.is_some() (ENoPendingTransfer) and pending_transfer.accepted
//     (ETransferNotAccepted), so it cannot run before steps 1-2.
//
// OnChainOutput.BatchOps can only carry MCMS proposals, so only step 2 belongs here.
func (a *SuiTokenAdapter) UpdateAuthorities() *cldf_ops.Sequence[tokensapi.UpdateAuthoritiesInput, sequences.OnChainOutput, *deployment.Environment] {
	return cldf_ops.NewSequence(
		"sui-adapter:update-authorities",
		&suideploy.Version1_0_0,
		"Propose MCMS accept_ownership of a Sui token pool (ownership step 2 of 3)",
		func(b cldf_ops.Bundle, e *deployment.Environment, input tokensapi.UpdateAuthoritiesInput) (sequences.OnChainOutput, error) {
			chain, ok := e.BlockChains.SuiChains()[input.ChainSelector]
			if !ok {
				return sequences.OnChainOutput{}, fmt.Errorf("sui chain with selector %d not found", input.ChainSelector)
			}
			coinType, _, err := resolveSuiCoinType(e.DataStore, input.ChainSelector, input.TokenRef)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("resolve sui token ref on chain %d: %w", input.ChainSelector, err)
			}
			qualifier, err := suiTokenQualifier(input.TokenPoolRef)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("failed to resolve token qualifier: %w", err)
			}
			stateObjID, _, err := resolveSuiPoolObjects(e.DataStore, input.ChainSelector, input.TokenPoolRef.Type, qualifier)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("failed to resolve sui pool objects: %w", err)
			}

			deps := suiDeps(chain)
			typeArgs := []string{coinType}
			var call sui_ops.TransactionCall
			switch input.TokenPoolRef.Type {
			case datastore.ContractType(suideploy.SuiBnMTokenPoolType):
				r, err := cldf_ops.ExecuteOperation(b, burnminttokenpoolops.AcceptOwnershipBurnMintTokenPoolOp, deps, burnminttokenpoolops.AcceptOwnershipBurnMintTokenPoolInput{
					BurnMintTokenPoolPackageId: input.TokenPoolRef.Address,
					TypeArgs:                   typeArgs,
					StateObjectId:              stateObjID,
				})
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to propose accept_ownership for burn-mint pool: %w", err)
				}
				call = r.Output.Call
			case datastore.ContractType(suideploy.SuiManagedTokenPoolType):
				r, err := cldf_ops.ExecuteOperation(b, managedtokenpoolops.AcceptOwnershipManagedTokenPoolOp, deps, managedtokenpoolops.AcceptOwnershipManagedTokenPoolInput{
					ManagedTokenPoolPackageId: input.TokenPoolRef.Address,
					TypeArgs:                  typeArgs,
					StateObjectId:             stateObjID,
				})
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to propose accept_ownership for managed pool: %w", err)
				}
				call = r.Output.Call
			case datastore.ContractType(suideploy.SuiLnRTokenPoolType):
				r, err := cldf_ops.ExecuteOperation(b, lockreleasetokenpoolops.AcceptOwnershipLockReleaseTokenPoolOp, deps, lockreleasetokenpoolops.AcceptOwnershipLockReleaseTokenPoolInput{
					LockReleaseTokenPoolPackageId: input.TokenPoolRef.Address,
					TypeArgs:                      typeArgs,
					StateObjectId:                 stateObjID,
				})
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to propose accept_ownership for lock-release pool: %w", err)
				}
				call = r.Output.Call
			default:
				return sequences.OnChainOutput{}, fmt.Errorf("unsupported sui token pool type %s for UpdateAuthorities", input.TokenPoolRef.Type)
			}
			return batchOpFromCall(input.ChainSelector, call)
		},
	)
}

// ================================================================
// === TokenRefResolver                                          ===
// ================================================================

// ResolveTokenPoolRef resolves a Sui pool package id to its datastore AddressRef. The
// package id is looked up in the datastore to recover the pool contract type and token identity.
// The returned ref carries the token's semantic qualifier so downstream adapter methods can
// resolve the pool's state and owner-cap objects without using the pool address as a key.
func (a *SuiTokenAdapter) ResolveTokenPoolRef(_ cldf_ops.Bundle, _ cldf_chain.BlockChains, ds datastore.DataStore, chainSelector uint64, address string) (datastore.AddressRef, error) {
	refs := findRefsByAddress(ds, chainSelector, address)
	if len(refs) == 0 {
		return datastore.AddressRef{}, fmt.Errorf("no sui address ref found for %s on chain %d", address, chainSelector)
	}
	for _, r := range refs {
		if !isSuiPoolType(r.Type) {
			continue
		}
		if _, err := suiTokenQualifier(r); err != nil {
			return datastore.AddressRef{}, fmt.Errorf("invalid qualifier for sui token pool ref %s on chain %d: %w", address, chainSelector, err)
		}
		return r, nil
	}
	return datastore.AddressRef{}, fmt.Errorf("address %s on chain %d is not a recognized sui token pool type", address, chainSelector)
}

// ResolveTokenRef resolves a Sui token reference to an AddressRef. The address may be either
// a bare package id or the full coin type string 0x<package>::<module>::<STRUCT>. A bare id is
// resolved against the datastore, deriving the full coin type from the matching coin ref's
// coinType= label and preserving that ref's explicit qualifier, so no on-chain call is needed.
// A full coin type is used verbatim, with the qualifier obtained from on-chain coin metadata.
// The returned Address always holds the full coin type (the canonical token identifier), and
// the Qualifier is the normalized token symbol (TokenQualifier) used to key token-scoped rows
// in the datastore. A token ref without a qualifier cannot be safely keyed, so it is returned
// as an error rather than silently producing a singleton-qualified token ref.
func (a *SuiTokenAdapter) ResolveTokenRef(b cldf_ops.Bundle, chains cldf_chain.BlockChains, ds datastore.DataStore, chainSelector uint64, address string) (datastore.AddressRef, error) {
	if address == "" {
		return datastore.AddressRef{}, fmt.Errorf("sui token ref has empty address on chain %d", chainSelector)
	}
	if !strings.Contains(address, "::") {
		pkgID := normalizeSuiAddr(address)
		coinRef, ok := coinRefByAddress(ds, chainSelector, pkgID)
		if !ok {
			return datastore.AddressRef{}, fmt.Errorf("no sui coin package ref with a coinType= label found for address %s on chain %d", pkgID, chainSelector)
		}
		coinType, ok := coinTypeFromRef(coinRef)
		if !ok {
			return datastore.AddressRef{}, fmt.Errorf("sui coin package ref at address %s on chain %d carries no coinType= label", pkgID, chainSelector)
		}
		qualifier, err := suiTokenQualifier(coinRef)
		if err != nil {
			return datastore.AddressRef{}, fmt.Errorf("resolve qualifier for coin package %s on chain %d: %w", pkgID, chainSelector, err)
		}
		return datastore.AddressRef{
			ChainSelector: chainSelector,
			Type:          suiTokenType(coinType),
			Address:       coinType,
			Qualifier:     qualifier,
			Version:       semver.MustParse("1.0.0"),
			Labels:        coinRef.Labels,
		}, nil
	}
	coinType := normalizeCoinType(address)
	chain, ok := chains.SuiChains()[chainSelector]
	if !ok {
		return datastore.AddressRef{}, fmt.Errorf("sui chain with selector %d not found", chainSelector)
	}
	report, err := cldf_ops.ExecuteOperation(b, coin_ops.GetCoinSymbolOp, suiDeps(chain), coinType)
	if err != nil {
		return datastore.AddressRef{}, fmt.Errorf("failed to fetch coin metadata for %s on chain %d: %w", coinType, chainSelector, err)
	}
	if report.Output.Symbol == "" {
		return datastore.AddressRef{}, fmt.Errorf("coin metadata for %s on chain %d has an empty symbol", coinType, chainSelector)
	}
	return datastore.AddressRef{
		ChainSelector: chainSelector,
		Type:          suiTokenType(coinType),
		Address:       coinType,
		Qualifier:     suideploy.TokenQualifier(report.Output.Symbol),
		Version:       semver.MustParse("1.0.0"),
		Labels:        datastore.NewLabelSet(report.Output.Symbol),
	}, nil
}

// ================================================================
// === Stubs: not yet implemented                                ===
// ================================================================

// ConfigureTokenForTransfersSequence configures a Sui token pool for cross-chain transfers
// as an MCMS proposal. Per remote chain it applies the chain config (remote token + remote
// pool) and the default-lane rate limits, mirroring the Sui ConfigureBurnMintTokenPool flow.
// Sui has no router SetPool and the existing Sui configure flow does not register the pool in
// the TokenAdminRegistry, so this sequence only sets per-remote chain config + rate limits.
func (a *SuiTokenAdapter) ConfigureTokenForTransfersSequence() *cldf_ops.Sequence[tokensapi.ConfigureTokenForTransfersInput, sequences.OnChainOutput, cldf_chain.BlockChains] {
	return cldf_ops.NewSequence(
		"sui-adapter:configure-token-for-transfers",
		&suideploy.Version1_0_0,
		"Configure a Sui token pool for cross-chain transfers as an MCMS proposal",
		func(b cldf_ops.Bundle, chains cldf_chain.BlockChains, input tokensapi.ConfigureTokenForTransfersInput) (sequences.OnChainOutput, error) {
			chain, ok := chains.SuiChains()[input.ChainSelector]
			if !ok {
				return sequences.OnChainOutput{}, fmt.Errorf("sui chain with selector %d not found", input.ChainSelector)
			}
			coinType, _, err := resolveSuiCoinType(input.ExistingDataStore, input.ChainSelector, input.TokenRef)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("resolve sui token ref on chain %d: %w", input.ChainSelector, err)
			}
			pkgID := input.TokenPoolAddress
			if pkgID == "" {
				return sequences.OnChainOutput{}, fmt.Errorf("token pool address is empty on chain %d", input.ChainSelector)
			}
			poolType, err := suiPoolTypeFromStr(input.PoolType)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("unsupported sui pool type %q on chain %d: %w", input.PoolType, input.ChainSelector, err)
			}
			qualifier, err := suiTokenQualifier(input.TokenRef)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("failed to resolve token qualifier: %w", err)
			}
			stateObjID, ownerCapID, err := resolveSuiPoolObjects(input.ExistingDataStore, input.ChainSelector, poolType, qualifier)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("failed to resolve sui pool objects: %w", err)
			}
			localDecimals, err := suiDecimals(b, chain, coinType)
			if err != nil {
				return sequences.OnChainOutput{}, err
			}

			// Configure-before-own: while the deployer still owns the pool, run the
			// OwnerCap-gated config entrypoints directly. A bundled MCMS config op would
			// abort because token_expansion never registers the package with mcms_registry;
			// only step 3 execute_ownership_transfer does. MCMS-owned pools fall back to collect.
			deployerAddr, err := chain.Signer.GetAddress()
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("failed to get deployer address on chain %d: %w", input.ChainSelector, err)
			}
			owner, err := suiPoolOwner(b, chain, poolType, pkgID, coinType, stateObjID)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("failed to read pool owner on chain %d: %w", input.ChainSelector, err)
			}
			eoDirect := suiAddrEqual(owner, deployerAddr)
			var deps sui_ops.OpTxDeps
			if eoDirect {
				deps = suiDepsExec(chain)
			} else {
				deps = suiDeps(chain)
			}
			batchOps := make([]mcmstypes.BatchOperation, 0)
			for remoteSelector, rc := range input.RemoteChains {
				if err := rc.Validate(); err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("remote chain config for selector %d: %w", remoteSelector, err)
				}
				remoteTokenHex := "0x" + hex.EncodeToString(rc.RemoteToken)
				remotePoolHex := "0x" + hex.EncodeToString(rc.RemotePool)

				calls := make([]sui_ops.TransactionCall, 0, 2)
				switch poolType {
				case datastore.ContractType(suideploy.SuiBnMTokenPoolType):
					r, err := cldf_ops.ExecuteOperation(b, burnminttokenpoolops.BurnMintTokenPoolApplyChainUpdatesOp, deps, burnminttokenpoolops.BurnMintTokenPoolApplyChainUpdatesInput{
						BurnMintPackageId:         pkgID,
						CoinObjectTypeArg:         coinType,
						StateObjectId:             stateObjID,
						OwnerCap:                  ownerCapID,
						RemoteChainSelectorsToAdd: []uint64{remoteSelector},
						RemotePoolAddressesToAdd:  [][]string{{remotePoolHex}},
						RemoteTokenAddressesToAdd: []string{remoteTokenHex},
					})
					if err != nil {
						return sequences.OnChainOutput{}, fmt.Errorf("apply chain updates for remote %d: %w", remoteSelector, err)
					}
					calls = append(calls, r.Output.Call)
				case datastore.ContractType(suideploy.SuiManagedTokenPoolType):
					r, err := cldf_ops.ExecuteOperation(b, managedtokenpoolops.ManagedTokenPoolApplyChainUpdatesOp, deps, managedtokenpoolops.ManagedTokenPoolApplyChainUpdatesInput{
						ManagedTokenPoolPackageId: pkgID,
						CoinObjectTypeArg:         coinType,
						StateObjectId:             stateObjID,
						OwnerCap:                  ownerCapID,
						RemoteChainSelectorsToAdd: []uint64{remoteSelector},
						RemotePoolAddressesToAdd:  [][]string{{remotePoolHex}},
						RemoteTokenAddressesToAdd: []string{remoteTokenHex},
					})
					if err != nil {
						return sequences.OnChainOutput{}, fmt.Errorf("apply chain updates for remote %d: %w", remoteSelector, err)
					}
					calls = append(calls, r.Output.Call)
				case datastore.ContractType(suideploy.SuiLnRTokenPoolType):
					r, err := cldf_ops.ExecuteOperation(b, lockreleasetokenpoolops.LockReleaseTokenPoolApplyChainUpdatesOp, deps, lockreleasetokenpoolops.LockReleaseTokenPoolApplyChainUpdatesInput{
						LockReleasePackageId:      pkgID,
						CoinObjectTypeArg:         coinType,
						StateObjectId:             stateObjID,
						OwnerCap:                  ownerCapID,
						RemoteChainSelectorsToAdd: []uint64{remoteSelector},
						RemotePoolAddressesToAdd:  [][]string{{remotePoolHex}},
						RemoteTokenAddressesToAdd: []string{remoteTokenHex},
					})
					if err != nil {
						return sequences.OnChainOutput{}, fmt.Errorf("apply chain updates for remote %d: %w", remoteSelector, err)
					}
					calls = append(calls, r.Output.Call)
				default:
					return sequences.OnChainOutput{}, fmt.Errorf("unsupported sui token pool type %s for ConfigureTokenForTransfers", poolType)
				}

				obBucket, obOk := rc.GetOutboundRateLimitBuckets().DefaultBucket()
				ibBucket, ibOk := rc.GetInboundRateLimitBuckets().DefaultBucket()
				switch {
				case obOk && ibOk:
					obRL, ibRL := tokensapi.GenerateTPRLConfigs(obBucket.RateLimit, ibBucket.RateLimit, localDecimals, rc.RemoteDecimals, chainsel.FamilySui, semver.MustParse("1.6.0"), string(poolType))
					rlCall, err := suiSetChainRateLimitCall(b, deps, poolType, pkgID, coinType, stateObjID, ownerCapID, remoteSelector, obRL, ibRL)
					if err != nil {
						return sequences.OnChainOutput{}, err
					}
					calls = append(calls, rlCall)
				case !obOk && !ibOk:
					// No rate-limit update for this remote; keep the chain-config call already in calls.
				default:
					return sequences.OnChainOutput{}, fmt.Errorf("default outbound and inbound rate limits must both be specified or both omitted for remote %d", remoteSelector)
				}

				// EOA-direct mode already executed the ops on-chain; skip collecting their
				// Calls into batchOps. Tx digests surface via ExecutionReports.
				if !eoDirect {
					out, err := batchOpFromCalls(input.ChainSelector, calls)
					if err != nil {
						return sequences.OnChainOutput{}, err
					}
					batchOps = append(batchOps, out.BatchOps...)
				}
			}
			return sequences.OnChainOutput{BatchOps: batchOps}, nil
		},
	)
}

// suiSetChainRateLimitCall builds the SetChainRateLimiter TransactionCall for one remote
// chain, converting the decimal-scaled configs to the u64 on-chain representation.
func suiSetChainRateLimitCall(
	b cldf_ops.Bundle,
	deps sui_ops.OpTxDeps,
	poolType datastore.ContractType,
	pkgID, coinType, stateObjID, ownerCapID string,
	remoteSelector uint64,
	obRL, ibRL tokensapi.RateLimiterConfig,
) (sui_ops.TransactionCall, error) {
	obCap, err := bigToU64(obRL.Capacity)
	if err != nil {
		return sui_ops.TransactionCall{}, fmt.Errorf("outbound capacity: %w", err)
	}
	obRate, err := bigToU64(obRL.Rate)
	if err != nil {
		return sui_ops.TransactionCall{}, fmt.Errorf("outbound rate: %w", err)
	}
	ibCap, err := bigToU64(ibRL.Capacity)
	if err != nil {
		return sui_ops.TransactionCall{}, fmt.Errorf("inbound capacity: %w", err)
	}
	ibRate, err := bigToU64(ibRL.Rate)
	if err != nil {
		return sui_ops.TransactionCall{}, fmt.Errorf("inbound rate: %w", err)
	}
	remotes := []uint64{remoteSelector}
	switch poolType {
	case datastore.ContractType(suideploy.SuiBnMTokenPoolType):
		r, err := cldf_ops.ExecuteOperation(b, burnminttokenpoolops.BurnMintTokenPoolSetChainRateLimiterOp, deps, burnminttokenpoolops.BurnMintTokenPoolSetChainRateLimiterInput{
			BurnMintPackageId:    pkgID,
			CoinObjectTypeArg:    coinType,
			StateObjectId:        stateObjID,
			OwnerCap:             ownerCapID,
			RemoteChainSelectors: remotes,
			OutboundIsEnableds:   []bool{obRL.IsEnabled},
			OutboundCapacities:   []uint64{obCap},
			OutboundRates:        []uint64{obRate},
			InboundIsEnableds:    []bool{ibRL.IsEnabled},
			InboundCapacities:    []uint64{ibCap},
			InboundRates:         []uint64{ibRate},
		})
		if err != nil {
			return sui_ops.TransactionCall{}, fmt.Errorf("set rate limits: %w", err)
		}
		return r.Output.Call, nil
	case datastore.ContractType(suideploy.SuiManagedTokenPoolType):
		r, err := cldf_ops.ExecuteOperation(b, managedtokenpoolops.ManagedTokenPoolSetChainRateLimiterOp, deps, managedtokenpoolops.ManagedTokenPoolSetChainRateLimiterInput{
			ManagedTokenPoolPackageId: pkgID,
			CoinObjectTypeArg:         coinType,
			StateObjectId:             stateObjID,
			OwnerCap:                  ownerCapID,
			RemoteChainSelectors:      remotes,
			OutboundIsEnableds:        []bool{obRL.IsEnabled},
			OutboundCapacities:        []uint64{obCap},
			OutboundRates:             []uint64{obRate},
			InboundIsEnableds:         []bool{ibRL.IsEnabled},
			InboundCapacities:         []uint64{ibCap},
			InboundRates:              []uint64{ibRate},
		})
		if err != nil {
			return sui_ops.TransactionCall{}, fmt.Errorf("set rate limits: %w", err)
		}
		return r.Output.Call, nil
	case datastore.ContractType(suideploy.SuiLnRTokenPoolType):
		r, err := cldf_ops.ExecuteOperation(b, lockreleasetokenpoolops.LockReleaseTokenPoolSetChainRateLimiterOp, deps, lockreleasetokenpoolops.LockReleaseTokenPoolSetChainRateLimiterInput{
			LockReleasePackageId: pkgID,
			CoinObjectTypeArg:    coinType,
			StateObjectId:        stateObjID,
			OwnerCap:             ownerCapID,
			RemoteChainSelectors: remotes,
			OutboundIsEnableds:   []bool{obRL.IsEnabled},
			OutboundCapacities:   []uint64{obCap},
			OutboundRates:        []uint64{obRate},
			InboundIsEnableds:    []bool{ibRL.IsEnabled},
			InboundCapacities:    []uint64{ibCap},
			InboundRates:         []uint64{ibRate},
		})
		if err != nil {
			return sui_ops.TransactionCall{}, fmt.Errorf("set rate limits: %w", err)
		}
		return r.Output.Call, nil
	default:
		return sui_ops.TransactionCall{}, fmt.Errorf("unsupported sui token pool type %s for rate limits", poolType)
	}
}

// DeriveTokenAddress derives the Sui coin type from the explicitly qualified coin package ref.
// It is a fallback used when the caller does not provide a token ref; the primary path threads
// the coin type through the token ref. The package's module::STRUCT suffix is stored separately
// as a coinType= label.
func (a *SuiTokenAdapter) DeriveTokenAddress(e deployment.Environment, chainSelector uint64, poolRef datastore.AddressRef) (string, error) {
	qualifier, err := suiTokenQualifier(poolRef)
	if err != nil {
		return "", err
	}
	return deriveSuiCoinType(e.DataStore, chainSelector, qualifier)
}

// ManualRegistration is a no-op on Sui. Unlike EVM/Solana, a Sui token pool self-registers
// in the TokenAdminRegistry during pool initialization: the Move `initialize` (burn-mint) and
// `initialize_with_managed_token` (managed) functions call `token_admin_registry::register_pool`
// themselves. DeployTokenPoolForToken triggers that init, so by the time a pool exists it is
// already registered. Calling register_pool again would abort with ETokenAlreadyRegistered, so
// this sequence logs and returns an empty output rather than re-registering. A nil return would
// crash the generic ManualRegistration changeset, so a no-op sequence is returned instead.
func (a *SuiTokenAdapter) ManualRegistration() *cldf_ops.Sequence[tokensapi.ManualRegistrationSequenceInput, sequences.OnChainOutput, cldf_chain.BlockChains] {
	return cldf_ops.NewSequence(
		"sui-adapter:manual-registration",
		&suideploy.Version1_0_0,
		"No-op: Sui pools self-register in the TokenAdminRegistry during initialization",
		func(b cldf_ops.Bundle, _ cldf_chain.BlockChains, input tokensapi.ManualRegistrationSequenceInput) (sequences.OnChainOutput, error) {
			b.Logger.Infow("Sui ManualRegistration is a no-op: token pools self-register in the TokenAdminRegistry during pool initialization",
				"chainSelector", input.ChainSelector, "tokenPoolRef", input.TokenPoolRef.Address)
			return sequences.OnChainOutput{}, nil
		},
	)
}

// DeployToken is not supported for Sui through the generic token adapter. Sui token
// deployment publishes a fixed-kind Move package (managed token or BnM token) whose deploy op
// takes only MCMS config, not the symbol/decimals/supply/pre-mint/senders that the generic
// DeployTokenInput carries; the token identity is determined by the published package, so the
// generic input does not map cleanly. Sui tokens are deployed via the Sui-specific token deploy
// changesets instead. This returns a sequence that errors so a misconfigured Sui chain fails
// with a clear message rather than nil-panicking the generic flow (which calls it unguarded).
func (a *SuiTokenAdapter) DeployToken() *cldf_ops.Sequence[tokensapi.DeployTokenInput, sequences.OnChainOutput, cldf_chain.BlockChains] {
	return cldf_ops.NewSequence(
		"sui-adapter:deploy-token",
		&suideploy.Version1_0_0,
		"Not supported: Sui tokens are deployed via the Sui-specific token deploy changesets",
		func(_ cldf_ops.Bundle, _ cldf_chain.BlockChains, _ tokensapi.DeployTokenInput) (sequences.OnChainOutput, error) {
			return sequences.OnChainOutput{}, fmt.Errorf("DeployToken is not supported for Sui via the generic token adapter; deploy Sui tokens with the Sui-specific token deploy changesets")
		},
	)
}

// DeployTokenPoolForToken deploys and initializes a Sui token pool for an existing token.
// It publishes a Move package, initializes the pool, and transfers pool ownership to MCMS
// (ownership step 1), so it executes directly with the chain signer (not as an MCMS proposal)
// and returns the deployed pool's AddressRefs.
//
// PoolType accepts the Sui short form ("bnm"/"managed"/"lnr"), the Sui contract-type string
// ("SuiBnMTokenPool"/"SuiManagedTokenPool"/"SuiLnRTokenPool"), or the generic cross-family
// contract-type strings used by EVM/Solana ("BurnMintTokenPool"/"LockReleaseTokenPool"). The
// generic names let a single token_expansion YAML use one poolType across families. The token's
// coin type comes from TokenRef.Address, the qualifier is taken explicitly from TokenRef.Qualifier,
// and the display symbol is taken from its labels. CCIP/MCMS state is resolved from the datastore.
// The display symbol is used only for labels on the newly returned refs. For managed pools, the
// minter-cap ref held by the chain signer is used.
//
// After initialize this calls transfer_ownership(To: MCMS) EOA-direct, setting a pending
// transfer that UpdateAuthorities' accept_ownership MCMS proposal (step 2) then accepts. The
// final execute_ownership_transfer_to_mcms (step 3) is EOA-direct and handled by the Sui
// cs_mcms_execute_ownership_transfer changeset after the accept proposal lands.
func (a *SuiTokenAdapter) DeployTokenPoolForToken() *cldf_ops.Sequence[tokensapi.DeployTokenPoolInput, sequences.OnChainOutput, cldf_chain.BlockChains] {
	return cldf_ops.NewSequence(
		"sui-adapter:deploy-token-pool-for-token",
		&suideploy.Version1_0_0,
		"Deploy and initialize a Sui token pool for an existing token (direct execution)",
		func(b cldf_ops.Bundle, chains cldf_chain.BlockChains, input tokensapi.DeployTokenPoolInput) (sequences.OnChainOutput, error) {
			chain, ok := chains.SuiChains()[input.ChainSelector]
			if !ok {
				return sequences.OnChainOutput{}, fmt.Errorf("sui chain with selector %d not found", input.ChainSelector)
			}
			if input.TokenRef == nil {
				return sequences.OnChainOutput{}, fmt.Errorf("token ref is required to deploy a sui token pool")
			}
			coinType, _, err := resolveSuiCoinType(input.ExistingDataStore, input.ChainSelector, *input.TokenRef)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("resolve sui token ref on chain %d: %w", input.ChainSelector, err)
			}
			qualifier, err := suiTokenQualifier(*input.TokenRef)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("failed to resolve token qualifier: %w", err)
			}
			symbol, err := tokenDisplaySymbol(*input.TokenRef)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("failed to resolve token display symbol: %w", err)
			}
			if coinType == "" || symbol == "" {
				return sequences.OnChainOutput{}, fmt.Errorf("token ref must carry the coin type and display symbol on chain %d", input.ChainSelector)
			}
			poolType, err := suiPoolTypeFromStr(input.PoolType)
			if err != nil {
				return sequences.OnChainOutput{}, err
			}
			ds := input.ExistingDataStore
			ccipPkg := firstRefAddress(findRefsByType(ds, input.ChainSelector, datastore.ContractType(suideploy.SuiCCIPType)))
			if ccipPkg == "" {
				return sequences.OnChainOutput{}, fmt.Errorf("CCIP package not found on chain %d", input.ChainSelector)
			}
			ccipObjRef := firstRefAddress(findRefsByType(ds, input.ChainSelector, datastore.ContractType(suideploy.SuiCCIPObjectRefType)))
			if ccipObjRef == "" {
				return sequences.OnChainOutput{}, fmt.Errorf("CCIP object ref not found on chain %d", input.ChainSelector)
			}
			mcmsPkg, ok := findRefByQualifier(findRefsByType(ds, input.ChainSelector, datastore.ContractType(suideploy.SuiMcmsPackageIDType)), suideploy.CLLCCIPQualifier)
			if !ok {
				return sequences.OnChainOutput{}, fmt.Errorf("normal (non-fastcurse) MCMS package not found on chain %d", input.ChainSelector)
			}
			fastMcmsPkg, ok := findRefByQualifier(findRefsByType(ds, input.ChainSelector, datastore.ContractType(suideploy.SuiMcmsPackageIDType)), suideploy.RMNMCMSQualifier)
			if !ok {
				return sequences.OnChainOutput{}, fmt.Errorf("fastcurse MCMS package not found on chain %d", input.ChainSelector)
			}
			deployer, err := chain.Signer.GetAddress()
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("failed to get deployer address: %w", err)
			}
			admin := input.RateLimitAdmin
			if admin == "" {
				admin = deployer
			}
			deps := suiDepsExec(chain)
			// Managed-token deploys do not persist CoinMetadata to the datastore (only BnM
			// does), so read the CoinMetadata object id on-chain by coin type as the single
			// reliable source for both pool kinds.
			coinMetaReport, err := cldf_ops.ExecuteOperation(b, coin_ops.GetCoinSymbolOp, deps, coinType)
			if err != nil {
				return sequences.OnChainOutput{}, fmt.Errorf("failed to fetch coin metadata for type %s on chain %d: %w", coinType, input.ChainSelector, err)
			}
			coinMeta := coinMetaReport.Output.Id
			if coinMeta == "" {
				return sequences.OnChainOutput{}, fmt.Errorf("coin metadata object id not found for type %s on chain %d", coinType, input.ChainSelector)
			}
			var addresses []datastore.AddressRef
			switch poolType {
			case datastore.ContractType(suideploy.SuiBnMTokenPoolType):
				treasuryCap, err := findTokenRefAddress(findRefsByType(ds, input.ChainSelector, datastore.ContractType(suideploy.SuiManagedTokenTreasuryCapIDType)), qualifier)
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to resolve BnM treasury cap for symbol %s: %w", symbol, err)
				}
				if treasuryCap == "" {
					return sequences.OnChainOutput{}, fmt.Errorf("BnM token treasury cap not found for symbol %s on chain %d", symbol, input.ChainSelector)
				}
				deployReport, err := cldf_ops.ExecuteOperation(b, burnminttokenpoolops.DeployCCIPBurnMintTokenPoolOp, deps, burnminttokenpoolops.BurnMintTokenPoolDeployInput{
					CCIPPackageId:    ccipPkg,
					MCMSAddress:      mcmsPkg.Address,
					FastMcmsAddress:  fastMcmsPkg.Address,
					MCMSOwnerAddress: deployer,
				})
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to deploy burn-mint token pool: %w", err)
				}
				poolPkg := deployReport.Output.PackageId
				initReport, err := cldf_ops.ExecuteOperation(b, burnminttokenpoolops.BurnMintTokenPoolInitializeOp, deps, burnminttokenpoolops.BurnMintTokenPoolInitializeInput{
					BurnMintPackageId:      poolPkg,
					OwnerCapObjectId:       deployReport.Output.Objects.OwnerCapObjectId,
					CoinObjectTypeArg:      coinType,
					StateObjectId:          ccipObjRef,
					CoinMetadataObjectId:   coinMeta,
					TreasuryCapObjectId:    treasuryCap,
					TokenPoolAdministrator: admin,
				})
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to initialize burn-mint token pool: %w", err)
				}
				// Ownership step 1 of 3: transfer pool ownership to MCMS (EOA-direct). Sets a pending
				// transfer that UpdateAuthorities' accept_ownership proposal (step 2) then accepts.
				if _, err := cldf_ops.ExecuteOperation(b, burnminttokenpoolops.TransferOwnershipBurnMintTokenPoolOp, deps, burnminttokenpoolops.TransferOwnershipBurnMintTokenPoolInput{
					BurnMintTokenPoolPackageId: poolPkg,
					TypeArgs:                   []string{coinType},
					StateObjectId:              initReport.Output.Objects.StateObjectId,
					OwnerCapObjectId:           deployReport.Output.Objects.OwnerCapObjectId,
					To:                         mcmsPkg.Address,
				}); err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to transfer burn-mint pool ownership to MCMS: %w", err)
				}
				addresses = appendSuiPoolAddresses(addresses, input.ChainSelector, poolType, symbol, qualifier, poolPkg, initReport.Output.Objects.StateObjectId, deployReport.Output.Objects.OwnerCapObjectId, deployReport.Output.Objects.UpgradeCapObjectId)
			case datastore.ContractType(suideploy.SuiManagedTokenPoolType):
				managedPkg, err := findTokenRefAddress(findRefsByType(ds, input.ChainSelector, datastore.ContractType(suideploy.SuiManagedTokenPackageIDType)), qualifier)
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to resolve managed token package for symbol %s: %w", symbol, err)
				}
				mtState, err := findTokenRefAddress(findRefsByType(ds, input.ChainSelector, datastore.ContractType(suideploy.SuiManagedTokenStateObjectID)), qualifier)
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to resolve managed token state for symbol %s: %w", symbol, err)
				}
				mtOwnerCap, err := findTokenRefAddress(findRefsByType(ds, input.ChainSelector, datastore.ContractType(suideploy.SuiManagedTokenOwnerCapObjectID)), qualifier)
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to resolve managed token owner cap for symbol %s: %w", symbol, err)
				}
				mintCap, err := findMinterCapAddress(findRefsByType(ds, input.ChainSelector, datastore.ContractType(suideploy.SuiManagedTokenMinterCapID)), suideploy.MinterCapQualifier(qualifier, deployer))
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to resolve managed token minter cap for symbol %s and holder %s: %w", symbol, deployer, err)
				}
				if managedPkg == "" || mtState == "" || mtOwnerCap == "" || mintCap == "" {
					return sequences.OnChainOutput{}, fmt.Errorf("managed token state objects not found for symbol %s on chain %d", symbol, input.ChainSelector)
				}
				deployReport, err := cldf_ops.ExecuteOperation(b, managedtokenpoolops.DeployCCIPManagedTokenPoolOp, deps, managedtokenpoolops.ManagedTokenPoolDeployInput{
					CCIPPackageId:         ccipPkg,
					ManagedTokenPackageId: managedPkg,
					MCMSAddress:           mcmsPkg.Address,
					FastMcmsAddress:       fastMcmsPkg.Address,
					MCMSOwnerAddress:      deployer,
				})
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to deploy managed token pool: %w", err)
				}
				poolPkg := deployReport.Output.PackageId
				initReport, err := cldf_ops.ExecuteOperation(b, managedtokenpoolops.ManagedTokenPoolInitializeOp, deps, managedtokenpoolops.ManagedTokenPoolInitializeInput{
					ManagedTokenPoolPackageId: poolPkg,
					OwnerCapObjectId:          deployReport.Output.Objects.OwnerCapObjectId,
					CoinObjectTypeArg:         coinType,
					CCIPObjectRefObjectId:     ccipObjRef,
					ManagedTokenStateObjectId: mtState,
					ManagedTokenOwnerCapId:    mtOwnerCap,
					CoinMetadataObjectId:      coinMeta,
					MintCapObjectId:           mintCap,
					TokenPoolAdministrator:    admin,
				})
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to initialize managed token pool: %w", err)
				}
				// Ownership step 1 of 3: transfer pool ownership to MCMS (EOA-direct). Sets a pending
				// transfer that UpdateAuthorities' accept_ownership proposal (step 2) then accepts.
				if _, err := cldf_ops.ExecuteOperation(b, managedtokenpoolops.TransferOwnershipManagedTokenPoolOp, deps, managedtokenpoolops.TransferOwnershipManagedTokenPoolInput{
					ManagedTokenPoolPackageId: poolPkg,
					TypeArgs:                  []string{coinType},
					StateObjectId:             initReport.Output.Objects.StateObjectId,
					OwnerCapObjectId:          deployReport.Output.Objects.OwnerCapObjectId,
					To:                        mcmsPkg.Address,
				}); err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to transfer managed pool ownership to MCMS: %w", err)
				}
				addresses = appendSuiPoolAddresses(addresses, input.ChainSelector, poolType, symbol, qualifier, poolPkg, initReport.Output.Objects.StateObjectId, deployReport.Output.Objects.OwnerCapObjectId, deployReport.Output.Objects.UpgradeCapObjectId)
			case datastore.ContractType(suideploy.SuiLnRTokenPoolType):
				treasuryCap, err := findTokenRefAddress(findRefsByType(ds, input.ChainSelector, datastore.ContractType(suideploy.SuiLnRTokenTreasuryCapIDType)), qualifier)
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to resolve LnR treasury cap for symbol %s: %w", symbol, err)
				}
				if treasuryCap == "" {
					return sequences.OnChainOutput{}, fmt.Errorf("token treasury cap not found for symbol %s on chain %d", symbol, input.ChainSelector)
				}
				deployReport, err := cldf_ops.ExecuteOperation(b, lockreleasetokenpoolops.DeployCCIPLockReleaseTokenPoolOp, deps, lockreleasetokenpoolops.LockReleaseTokenPoolDeployInput{
					CCIPPackageId:    ccipPkg,
					MCMSAddress:      mcmsPkg.Address,
					FastMcmsAddress:  fastMcmsPkg.Address,
					MCMSOwnerAddress: deployer,
				})
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to deploy lock-release token pool: %w", err)
				}
				poolPkg := deployReport.Output.PackageId
				initReport, err := cldf_ops.ExecuteOperation(b, lockreleasetokenpoolops.LockReleaseTokenPoolInitializeOp, deps, lockreleasetokenpoolops.LockReleaseTokenPoolInitializeInput{
					LockReleasePackageId:   poolPkg,
					OwnerCapObjectId:       deployReport.Output.Objects.OwnerCapObjectId,
					CoinObjectTypeArg:      coinType,
					StateObjectId:          ccipObjRef,
					CoinMetadataObjectId:   coinMeta,
					TreasuryCapObjectId:    treasuryCap,
					TokenPoolAdministrator: admin,
					Rebalancer:             deployer,
				})
				if err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to initialize lock-release token pool: %w", err)
				}
				// Ownership step 1 of 3: transfer pool ownership to MCMS (EOA-direct). Sets a pending
				// transfer that UpdateAuthorities' accept_ownership proposal (step 2) then accepts.
				if _, err := cldf_ops.ExecuteOperation(b, lockreleasetokenpoolops.TransferOwnershipLockReleaseTokenPoolOp, deps, lockreleasetokenpoolops.TransferOwnershipLockReleaseTokenPoolInput{
					LockReleaseTokenPoolPackageId: poolPkg,
					TypeArgs:                      []string{coinType},
					StateObjectId:                 initReport.Output.Objects.StateObjectId,
					OwnerCapObjectId:              deployReport.Output.Objects.OwnerCapObjectId,
					To:                            mcmsPkg.Address,
				}); err != nil {
					return sequences.OnChainOutput{}, fmt.Errorf("failed to transfer lock-release pool ownership to MCMS: %w", err)
				}
				addresses = appendSuiPoolAddresses(addresses, input.ChainSelector, poolType, symbol, qualifier, poolPkg, initReport.Output.Objects.StateObjectId, deployReport.Output.Objects.OwnerCapObjectId, deployReport.Output.Objects.UpgradeCapObjectId)
			default:
				return sequences.OnChainOutput{}, fmt.Errorf("unsupported sui pool type %s for DeployTokenPoolForToken", poolType)
			}
			return sequences.OnChainOutput{Addresses: addresses}, nil
		},
	)
}

// ================================================================
// === Helpers                                                   ===
// ================================================================

// suiDeps builds OpTxDeps in proposal mode: Signer is nil so ops return a TransactionCall
// instead of executing. Reads (coin metadata) also work with a nil signer.
func suiDeps(chain cldfsui.Chain) sui_ops.OpTxDeps {
	gas := uint64(400_000_000)
	return sui_ops.OpTxDeps{
		Client: chain.Client,
		Signer: nil,
		GetCallOpts: func() *bind.CallOpts {
			return &bind.CallOpts{WaitForExecution: true, GasBudget: &gas}
		},
		SuiRPC: chain.URL,
	}
}

// suiDepsExec builds OpTxDeps for direct execution with the chain signer. Used by deploy/init
// ops that publish packages and must execute immediately rather than via MCMS.
func suiDepsExec(chain cldfsui.Chain) sui_ops.OpTxDeps {
	gas := uint64(400_000_000)
	return sui_ops.OpTxDeps{
		Client: chain.Client,
		Signer: chain.Signer,
		GetCallOpts: func() *bind.CallOpts {
			return &bind.CallOpts{WaitForExecution: true, GasBudget: &gas}
		},
		SuiRPC: chain.URL,
	}
}

// suiPoolOwner reads the pool's ownable owner on-chain via DevInspect to decide
// configure-before-own: a deployer-owned pool can run OwnerCap-gated config directly.
func suiPoolOwner(b cldf_ops.Bundle, chain cldfsui.Chain, poolType datastore.ContractType,
	pkgID, coinType, stateObjID string,
) (string, error) {
	opts := &bind.CallOpts{Signer: chain.Signer}
	state := bind.Object{Id: stateObjID}
	typeArgs := []string{coinType}
	switch poolType {
	case datastore.ContractType(suideploy.SuiBnMTokenPoolType):
		contract, err := module_burn_mint_token_pool.NewBurnMintTokenPool(pkgID, chain.Client)
		if err != nil {
			return "", fmt.Errorf("failed to create burn-mint token pool contract: %w", err)
		}
		return contract.DevInspect().Owner(b.GetContext(), opts, typeArgs, state)
	case datastore.ContractType(suideploy.SuiManagedTokenPoolType):
		contract, err := module_managed_token_pool.NewManagedTokenPool(pkgID, chain.Client)
		if err != nil {
			return "", fmt.Errorf("failed to create managed token pool contract: %w", err)
		}
		return contract.DevInspect().Owner(b.GetContext(), opts, typeArgs, state)
	case datastore.ContractType(suideploy.SuiLnRTokenPoolType):
		contract, err := module_lock_release_token_pool.NewLockReleaseTokenPool(pkgID, chain.Client)
		if err != nil {
			return "", fmt.Errorf("failed to create lock-release token pool contract: %w", err)
		}
		return contract.DevInspect().Owner(b.GetContext(), opts, typeArgs, state)
	default:
		return "", fmt.Errorf("unsupported sui token pool type %s for owner read", poolType)
	}
}

// suiAddrEqual compares two Sui addresses after normalizing to lowercase with a 0x prefix.
func suiAddrEqual(a, b string) bool {
	return normalizeSuiAddr(a) == normalizeSuiAddr(b)
}

func normalizeSuiAddr(s string) string {
	s = strings.TrimSpace(s)
	s = strings.ToLower(s)
	if s != "" && !strings.HasPrefix(s, "0x") {
		s = "0x" + s
	}
	return s
}

// suiPoolTypeFromStr maps a PoolType string to a Sui pool contract type, accepting both the
// Sui short form ("bnm"/"managed"/"lnr") and the contract-type string.
func suiPoolTypeFromStr(s string) (datastore.ContractType, error) {
	switch s {
	case "bnm", string(suideploy.SuiBnMTokenPoolType), string(cciputils.BurnMintTokenPool):
		return datastore.ContractType(suideploy.SuiBnMTokenPoolType), nil
	case "managed", string(suideploy.SuiManagedTokenPoolType):
		return datastore.ContractType(suideploy.SuiManagedTokenPoolType), nil
	case "lnr", string(suideploy.SuiLnRTokenPoolType), string(cciputils.LockReleaseTokenPool):
		return datastore.ContractType(suideploy.SuiLnRTokenPoolType), nil
	default:
		return "", fmt.Errorf("unsupported sui pool type %q", s)
	}
}

// firstRefAddress returns the address of the first ref in a slice, or empty if there are none.
func firstRefAddress(refs []datastore.AddressRef) string {
	if len(refs) == 0 {
		return ""
	}
	return refs[0].Address
}

// refAddress returns the address of a found ref, or empty if ok is false.
func refAddress(ref datastore.AddressRef, ok bool) string {
	if !ok {
		return ""
	}
	return ref.Address
}

// appendSuiPoolAddresses builds the AddressRefs for a freshly deployed pool (package, state,
// owner cap, upgrade cap) keyed by the token qualifier, matching the refs saved by the Sui
// DeployTPAndConfigure changeset.
func appendSuiPoolAddresses(in []datastore.AddressRef, selector uint64, poolType datastore.ContractType, symbol, qualifier, poolPkg, stateObjID, ownerCapID, upgradeCapID string) []datastore.AddressRef {
	var stateType, ownerType, upgradeType datastore.ContractType
	switch poolType {
	case datastore.ContractType(suideploy.SuiBnMTokenPoolType):
		stateType = datastore.ContractType(suideploy.SuiBnMTokenPoolStateType)
		ownerType = datastore.ContractType(suideploy.SuiBnMTokenPoolOwnerCapObjectIDType)
		upgradeType = datastore.ContractType(suideploy.SuiBnMTokenPoolUpgradeCapObjectIDType)
	case datastore.ContractType(suideploy.SuiManagedTokenPoolType):
		stateType = datastore.ContractType(suideploy.SuiManagedTokenPoolStateType)
		ownerType = datastore.ContractType(suideploy.SuiManagedTokenPoolOwnerCapObjectIDType)
		upgradeType = datastore.ContractType(suideploy.SuiManagedTokenPoolUpgradeCapObjectIDType)
	case datastore.ContractType(suideploy.SuiLnRTokenPoolType):
		stateType = datastore.ContractType(suideploy.SuiLnRTokenPoolStateType)
		ownerType = datastore.ContractType(suideploy.SuiLnRTokenPoolOwnerCapObjectIDType)
		upgradeType = datastore.ContractType(suideploy.SuiLnRTokenPoolUpgradeCapObjectIDType)
	}
	version := semver.MustParse("1.0.0")
	return append(in,
		datastore.AddressRef{ChainSelector: selector, Type: poolType, Address: poolPkg, Version: version, Qualifier: qualifier, Labels: datastore.NewLabelSet(symbol)},
		datastore.AddressRef{ChainSelector: selector, Type: stateType, Address: stateObjID, Version: version, Qualifier: qualifier, Labels: datastore.NewLabelSet(symbol)},
		datastore.AddressRef{ChainSelector: selector, Type: ownerType, Address: ownerCapID, Version: version, Qualifier: qualifier, Labels: datastore.NewLabelSet(symbol)},
		datastore.AddressRef{ChainSelector: selector, Type: upgradeType, Address: upgradeCapID, Version: version, Qualifier: qualifier, Labels: datastore.NewLabelSet(symbol)},
	)
}

// batchOpFromCall bridges a Sui TransactionCall into an OnChainOutput carrying a single
// MCMS BatchOperation, matching the pattern used by the Sui RMN curse/uncurse sequences.
func batchOpFromCall(chainSelector uint64, call sui_ops.TransactionCall) (sequences.OnChainOutput, error) {
	tx, err := suideployutils.TransactionCallToMCMSTransaction(call)
	if err != nil {
		return sequences.OnChainOutput{}, fmt.Errorf("failed to convert sui call to mcms transaction: %w", err)
	}
	return sequences.OnChainOutput{
		BatchOps: []mcmstypes.BatchOperation{{
			ChainSelector: mcmstypes.ChainSelector(chainSelector),
			Transactions:  []mcmstypes.Transaction{tx},
		}},
	}, nil
}

// batchOpFromCalls bridges one or more Sui TransactionCalls into a single MCMS BatchOperation
// with ordered transactions. Returns an empty output when there are no calls.
func batchOpFromCalls(chainSelector uint64, calls []sui_ops.TransactionCall) (sequences.OnChainOutput, error) {
	if len(calls) == 0 {
		return sequences.OnChainOutput{}, nil
	}
	txs := make([]mcmstypes.Transaction, 0, len(calls))
	for _, c := range calls {
		tx, err := suideployutils.TransactionCallToMCMSTransaction(c)
		if err != nil {
			return sequences.OnChainOutput{}, fmt.Errorf("failed to convert sui call to mcms transaction: %w", err)
		}
		txs = append(txs, tx)
	}
	return sequences.OnChainOutput{
		BatchOps: []mcmstypes.BatchOperation{{
			ChainSelector: mcmstypes.ChainSelector(chainSelector),
			Transactions:  txs,
		}},
	}, nil
}

// suiDecimals reads token decimals from on-chain coin metadata for a coin type.
func suiDecimals(b cldf_ops.Bundle, chain cldfsui.Chain, coinType string) (uint8, error) {
	report, err := cldf_ops.ExecuteOperation(b, coin_ops.GetCoinSymbolOp, suiDeps(chain), coinType)
	if err != nil {
		return 0, fmt.Errorf("failed to fetch coin metadata for type %s: %w", coinType, err)
	}
	if report.Output.Decimals < 0 || report.Output.Decimals > 255 {
		return 0, fmt.Errorf("invalid decimals %d for coin type %s", report.Output.Decimals, coinType)
	}
	return uint8(report.Output.Decimals), nil
}

// deriveSuiCoinType builds the coin type for a token symbol by locating the token's coin package
// ref in the datastore. The matched ref carries a coinType= label that is either the coin's
// module::STRUCT suffix (joined to the ref's own package id) or, for a managed-token wrapper, the
// full underlying coin type (used verbatim). The ref is matched by symbol label plus the coinType
// label, independent of the contract type it is filed under, so every token — BnM, LINK, or any
// newly added coin behind a BurnMint or Managed pool — derives through the same path. The
// package ref is selected by its explicit qualifier; the coinType= label supplies only the
// module::STRUCT metadata needed to reconstruct the coin type.
func deriveSuiCoinType(ds datastore.DataStore, selector uint64, qualifier string) (string, error) {
	if qualifier == "" {
		return "", errors.New("token qualifier is required to derive the sui coin type")
	}
	if ds == nil {
		return "", fmt.Errorf("could not derive sui coin type for qualifier %s on chain %d: datastore is nil", qualifier, selector)
	}
	for _, ref := range ds.Addresses().Filter(datastore.AddressRefByChainSelector(selector)) {
		if ref.Labels.Contains(suideploy.SupersededLabel) {
			continue
		}
		if ref.Qualifier != qualifier {
			continue
		}
		if coinType, ok := coinTypeFromRef(ref); ok {
			return coinType, nil
		}
	}
	return "", fmt.Errorf("could not derive sui coin type for qualifier %s on chain %d: no coin package ref carrying a coinType= label found for that qualifier", qualifier, selector)
}

// resolveSuiCoinType resolves a token ref's coin type for the op methods. The ref
// address is either a bare coin package id (the simple form operators write in CLOPS YAML) or
// the full coin type string 0x<pkg>::<module>::<STRUCT> (the in-memory ResolveAdapterAndRefs
// ref, or a legacy YAML). For a bare id the coin type is rebuilt from the coin package ref's
// coinType= label in the datastore, so tokens are disambiguated by address without ever placing
// the long coin-type string in the address field. The token qualifier must already be present on
// the input ref; labels are not used as a fallback.
func resolveSuiCoinType(ds datastore.DataStore, selector uint64, ref datastore.AddressRef) (coinType, tokenQualifier string, err error) {
	if ref.Address == "" {
		return "", "", fmt.Errorf("sui token ref has empty address on chain %d", selector)
	}
	qualifier, err := suiTokenQualifier(ref)
	if err != nil {
		return "", "", err
	}
	if strings.Contains(ref.Address, "::") {
		coinType = normalizeCoinType(ref.Address)
		return coinType, qualifier, nil
	}
	pkgID := normalizeSuiAddr(ref.Address)
	coinRef, ok := coinRefByAddress(ds, selector, pkgID)
	if !ok {
		return "", "", fmt.Errorf("no sui coin package ref with a coinType= label found for address %s on chain %d", pkgID, selector)
	}
	coinType, ok = coinTypeFromRef(coinRef)
	if !ok {
		return "", "", fmt.Errorf("sui coin package ref at address %s on chain %d carries no coinType= label", pkgID, selector)
	}
	return coinType, qualifier, nil
}

// coinRefByAddress returns the first ref at the given address that carries a coinType= label,
// i.e. the coin package ref whose module::STRUCT suffix lets the adapter rebuild the coin type.
func coinRefByAddress(ds datastore.DataStore, selector uint64, address string) (datastore.AddressRef, bool) {
	for _, r := range findRefsByAddress(ds, selector, address) {
		if coinTypeSuffixFromLabels(r) != "" {
			return r, true
		}
	}
	return datastore.AddressRef{}, false
}

func findRefsByType(ds datastore.DataStore, selector uint64, contractType datastore.ContractType) []datastore.AddressRef {
	if ds == nil {
		return nil
	}
	return activeSuiRefs(ds.Addresses().Filter(
		datastore.AddressRefByChainSelector(selector),
		datastore.AddressRefByType(contractType),
	))
}

func findRefsByAddress(ds datastore.DataStore, selector uint64, address string) []datastore.AddressRef {
	if ds == nil {
		return nil
	}
	return activeSuiRefs(ds.Addresses().Filter(
		datastore.AddressRefByChainSelector(selector),
		datastore.AddressRefByAddress(address),
	))
}

func activeSuiRefs(refs []datastore.AddressRef) []datastore.AddressRef {
	active := make([]datastore.AddressRef, 0, len(refs))
	for _, ref := range refs {
		if ref.Labels.Contains(suideploy.SupersededLabel) {
			continue
		}
		active = append(active, ref)
	}
	return active
}

func findRefByQualifier(refs []datastore.AddressRef, qualifier string) (datastore.AddressRef, bool) {
	for _, r := range refs {
		if r.Qualifier == qualifier {
			return r, true
		}
	}
	return datastore.AddressRef{}, false
}

// findTokenRef resolves a token-scoped row by its explicit semantic qualifier.
func findTokenRef(refs []datastore.AddressRef, qualifier string) (datastore.AddressRef, error) {
	if ref, ok := findRefByQualifier(refs, qualifier); ok {
		return ref, nil
	}
	return datastore.AddressRef{}, nil
}

func findTokenRefAddress(refs []datastore.AddressRef, qualifier string) (string, error) {
	ref, err := findTokenRef(refs, qualifier)
	if err != nil {
		return "", err
	}
	return ref.Address, nil
}

func findMinterCapAddress(refs []datastore.AddressRef, qualifier string) (string, error) {
	if ref, ok := findRefByQualifier(refs, qualifier); ok {
		return ref.Address, nil
	}
	return "", nil
}

// resolveSuiPoolObjects returns the pool's state object id and owner-cap object id by resolving
// their explicit token qualifier.
func resolveSuiPoolObjects(ds datastore.DataStore, selector uint64, poolType datastore.ContractType, qualifier string) (stateObjID, ownerCapID string, err error) {
	if qualifier == "" {
		return "", "", errors.New("pool ref has no token qualifier; cannot resolve sui pool state and owner-cap")
	}
	stateType, ownerType, err := poolObjectTypes(poolType)
	if err != nil {
		return "", "", err
	}
	stateRef, err := findTokenRef(findRefsByType(ds, selector, stateType), qualifier)
	if err != nil {
		return "", "", fmt.Errorf("failed to resolve pool state for qualifier %s: %w", qualifier, err)
	}
	if stateRef.Address == "" {
		return "", "", fmt.Errorf("no sui pool state ref for qualifier %s (type %s) on chain %d", qualifier, stateType, selector)
	}
	ownerRef, err := findTokenRef(findRefsByType(ds, selector, ownerType), qualifier)
	if err != nil {
		return "", "", fmt.Errorf("failed to resolve pool owner cap for qualifier %s: %w", qualifier, err)
	}
	if ownerRef.Address == "" {
		return "", "", fmt.Errorf("no sui pool owner-cap ref for qualifier %s (type %s) on chain %d", qualifier, ownerType, selector)
	}
	return stateRef.Address, ownerRef.Address, nil
}

func poolObjectTypes(poolType datastore.ContractType) (stateType, ownerType datastore.ContractType, err error) {
	switch poolType {
	case datastore.ContractType(suideploy.SuiBnMTokenPoolType):
		return datastore.ContractType(suideploy.SuiBnMTokenPoolStateType), datastore.ContractType(suideploy.SuiBnMTokenPoolOwnerCapObjectIDType), nil
	case datastore.ContractType(suideploy.SuiManagedTokenPoolType):
		return datastore.ContractType(suideploy.SuiManagedTokenPoolStateType), datastore.ContractType(suideploy.SuiManagedTokenPoolOwnerCapObjectIDType), nil
	case datastore.ContractType(suideploy.SuiLnRTokenPoolType):
		return datastore.ContractType(suideploy.SuiLnRTokenPoolStateType), datastore.ContractType(suideploy.SuiLnRTokenPoolOwnerCapObjectIDType), nil
	default:
		return "", "", fmt.Errorf("unsupported sui token pool type %s", poolType)
	}
}

func isSuiPoolType(t datastore.ContractType) bool {
	switch t {
	case datastore.ContractType(suideploy.SuiBnMTokenPoolType),
		datastore.ContractType(suideploy.SuiManagedTokenPoolType),
		datastore.ContractType(suideploy.SuiLnRTokenPoolType):
		return true
	}
	return false
}

// symbolFromLabels returns the display symbol metadata, ignoring coin type annotations. It is
// never used to construct or resolve a datastore qualifier.
func symbolFromLabels(r datastore.AddressRef) (string, error) {
	var symbols []string
	for _, l := range r.Labels.List() {
		if l == "" || strings.HasPrefix(l, suiCoinTypeLabelPrefix) {
			continue
		}
		symbols = append(symbols, l)
	}
	switch len(symbols) {
	case 0:
		return "", nil
	case 1:
		return symbols[0], nil
	default:
		return "", fmt.Errorf("multiple token symbol labels: %s", strings.Join(symbols, ", "))
	}
}

func tokenDisplaySymbol(ref datastore.AddressRef) (string, error) {
	symbol, err := symbolFromLabels(ref)
	if err != nil {
		return "", err
	}
	if symbol == "" {
		return "", errors.New("token ref has no display symbol label")
	}
	return symbol, nil
}

// suiTokenQualifier returns the explicit qualifier stored on a token or pool ref. Address-derived
// qualifiers are rejected because they are not token identity.
func suiTokenQualifier(ref datastore.AddressRef) (string, error) {
	if ref.Qualifier == "" {
		return "", errors.New("token ref has no qualifier")
	}
	if ref.Address != "" && suideploy.QualifierContainsSuiAddress(ref.Qualifier, ref.Address) {
		return "", fmt.Errorf("qualifier %q is derived from the ref address %q", ref.Qualifier, ref.Address)
	}
	return ref.Qualifier, nil
}

// suiCoinTypeLabelPrefix marks a label carrying a coin package's module::STRUCT suffix. The coin
// deploy changesets add it so deriveSuiCoinType can build the correct coin type for tokens whose
// suffix is not one of the hardcoded BnM/LINK fallbacks.
const suiCoinTypeLabelPrefix = "coinType="

// coinTypeSuffixFromLabels returns the module::STRUCT suffix stored in a coinType= label on the
// ref, or "" when no such label is set.
func coinTypeSuffixFromLabels(r datastore.AddressRef) string {
	for _, l := range r.Labels.List() {
		if after, ok := strings.CutPrefix(l, suiCoinTypeLabelPrefix); ok {
			return after
		}
	}
	return ""
}

// coinTypeFromRef rebuilds the full coin type from a ref's coinType= label. The label holds either
// the module::STRUCT suffix for a coin minted by that ref's own package, or the full coin type
// 0x<pkg>::<module>::STRUCT for a managed-token wrapper whose underlying coin lives at a different
// package. A full type, detected by a 0x prefix, is used verbatim so the wrapper package id can
// stand in for the underlying coin in a token ref; a suffix is joined to the ref's own address.
// Returns false when the ref carries no coinType= label.
func coinTypeFromRef(ref datastore.AddressRef) (string, bool) {
	suffix := coinTypeSuffixFromLabels(ref)
	if suffix == "" {
		return "", false
	}
	if strings.HasPrefix(suffix, "0x") {
		return normalizeCoinType(suffix), true
	}
	return normalizeSuiAddr(ref.Address) + "::" + suffix, true
}

// suiTokenType maps a coin type to a datastore contract type on a best-effort basis. CCIP
// burn-mint test tokens on Sui are managed coins, so non-LINK coins default to the managed
// token type.
func suiTokenType(coinType string) datastore.ContractType {
	switch {
	case strings.Contains(coinType, "::link::"):
		return datastore.ContractType(suideploy.SuiLinkTokenType)
	case strings.Contains(coinType, "::ccip_lock_release_token::"):
		return datastore.ContractType(suideploy.SuiLnRTokenType)
	default:
		return datastore.ContractType(suideploy.SuiManagedTokenType)
	}
}

func normalizeCoinType(s string) string {
	if strings.HasPrefix(s, "0x") {
		return s
	}
	return "0x" + s
}

func bigToU64(x *big.Int) (uint64, error) {
	if x == nil {
		return 0, nil
	}
	if !x.IsUint64() {
		return 0, fmt.Errorf("value %s does not fit in uint64", x.String())
	}
	return x.Uint64(), nil
}
