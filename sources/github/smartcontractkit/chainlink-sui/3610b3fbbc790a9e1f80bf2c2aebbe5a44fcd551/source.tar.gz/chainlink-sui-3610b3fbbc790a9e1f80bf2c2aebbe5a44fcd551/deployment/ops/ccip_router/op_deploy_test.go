//go:build integration

package routerops

import (
	"context"
	"testing"

	"github.com/smartcontractkit/chainlink-common/pkg/logger"

	cld_ops "github.com/smartcontractkit/chainlink-deployments-framework/operations"

	"github.com/stretchr/testify/require"

	"github.com/smartcontractkit/chainlink-sui/bindings/bind"
	"github.com/smartcontractkit/chainlink-sui/bindings/tests/testenv"
	sui_ops "github.com/smartcontractkit/chainlink-sui/deployment/ops"
	mcms_ops "github.com/smartcontractkit/chainlink-sui/deployment/ops/mcms"
)

func TestDeployAndInitSeq(t *testing.T) {
	t.Parallel()
	signer, client := testenv.SetupEnvironment(t)

	deps := sui_ops.OpTxDeps{
		Client: client,
		Signer: signer,
		GetCallOpts: func() *bind.CallOpts {
			b := uint64(400_000_000)
			return &bind.CallOpts{
				WaitForExecution: true,
				GasBudget:        &b,
			}
		},
	}

	reporter := cld_ops.NewMemoryReporter()
	bundle := cld_ops.NewBundle(
		context.Background,
		logger.Test(t),
		reporter,
	)

	signerAddress, err := signer.GetAddress()
	require.NoError(t, err, "failed to get signer address")

	reportMCMs, err := cld_ops.ExecuteOperation(bundle, mcms_ops.DeployMCMSOp, deps, cld_ops.EmptyInput{})
	require.NoError(t, err, "failed to deploy MCMS Package")

	// Deploy Router
	reportRouter, err := cld_ops.ExecuteOperation(bundle, DeployCCIPRouterOp, deps, DeployCCIPRouterInput{
		McmsPackageId: reportMCMs.Output.PackageId,
		McmsOwner:     signerAddress,
	})
	require.NoError(t, err, "failed to deploy CCIP Router")

	// Test SetOnRamps operation
	_, err = cld_ops.ExecuteOperation(bundle, SetOnRampsOp, deps, SetOnRampsInput{
		RouterPackageId:     reportRouter.Output.PackageId,
		RouterStateObjectId: reportRouter.Output.Objects.RouterStateObjectId,
		OwnerCapObjectId:    reportRouter.Output.Objects.OwnerCapObjectId,
		DestChainSelectors:  []uint64{5009297550715157269, 6433500567565415381}, // ETH and AVAX chain selectors
		OnRampAddresses:     []string{"0x1111111111111111111111111111111111111111", "0x2222222222222222222222222222222222222222"},
	})
	require.NoError(t, err, "failed to set on-ramps")
}
