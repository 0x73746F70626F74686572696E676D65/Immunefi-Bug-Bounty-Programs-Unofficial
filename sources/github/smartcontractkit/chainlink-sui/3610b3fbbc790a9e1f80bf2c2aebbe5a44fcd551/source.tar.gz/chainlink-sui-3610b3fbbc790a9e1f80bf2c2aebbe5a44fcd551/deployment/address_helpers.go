package deployment

import (
	"errors"
	"fmt"

	fdatastore "github.com/smartcontractkit/chainlink-deployments-framework/datastore"
	cldf "github.com/smartcontractkit/chainlink-deployments-framework/deployment"
)

// SaveSuiAddress writes a single Sui contract address to both the legacy address
// book and the datastore, deriving identical metadata from one TypeAndVersion so
// the two stores cannot drift. The datastore AddressRef copies the address-book
// labels (token symbol, "fastcurse") so LoadOnchainStatesui reconstructs the same
// TypeAndVersion.
//
// The caller that knows the semantic qualifier provides it explicitly: it is never derived
// from the contract's own address and never derived from the label list or its order.
// Build it with the constructors in qualifiers.go TokenQualifier for token-scoped types,
// MinterCapQualifier for holder-scoped capability objects, MCMSInstance.DatastoreQualifier
// for the MCMS instances, ChainSingletonQualifier for the rest.
// The address-book labels are still copied onto the ref so the Sui loader
// reconstructs the same TypeAndVersion.
func SaveSuiAddress(
	ab *cldf.AddressBookMap,
	ds fdatastore.MutableAddressRefStore,
	chainSelector uint64,
	address string,
	tv cldf.TypeAndVersion,
	qualifier string,
) error {
	// Canonical spelling, so one object cannot enter the registries as 0xab and 0x000…ab.
	if canonical, ok := canonicalSuiAddress(address); ok {
		address = canonical
	}
	if QualifierContainsSuiAddress(qualifier, address) {
		return fmt.Errorf(
			"qualifier %q for %s contains the address being written: a qualifier must identify the instance in domain terms, not by its own address",
			qualifier, tv.Type,
		)
	}
	version := tv.Version
	ref := fdatastore.AddressRef{
		ChainSelector: chainSelector,
		Address:       address,
		Type:          fdatastore.ContractType(tv.Type),
		Version:       &version,
		Qualifier:     qualifier,
		Labels:        fdatastore.NewLabelSet(tv.Labels.List()...),
	}
	planned := PlannedRef{Type: tv.Type, Qualifier: qualifier, Version: &version}
	if _, err := ds.Get(ref.Key()); err != nil && !errors.Is(err, fdatastore.ErrAddressRefNotFound) {
		return fmt.Errorf("check datastore before saving %s: %w", describe(planned), err)
	} else if err == nil {
		return fmt.Errorf(
			"this changeset already wrote a %s: two objects cannot share one (chain, type, version, qualifier), so one of them needs a distinct qualifier: %w",
			describe(planned), fdatastore.ErrAddressRefExists,
		)
	}

	if err := ab.Save(chainSelector, address, tv); err != nil {
		return fmt.Errorf("save to address book: %w", err)
	}
	// Add, not Upsert: within one changeset run, writing the same key twice is always a bug —
	// there is no redeploy interpretation available, because both writes belong to the same
	// deployment. Upsert would drop the first ref and report success, leaving an object on
	// chain that the registry never mentions. Conflicts with rows written by *previous* runs
	// are a different question and cannot be seen from here (this store is fresh, and the
	// merge into the environment datastore happens after the changeset returns) — those are
	// checked upfront by ValidateNoDatastoreConflicts.
	if err := ds.Add(ref); err != nil {
		rollback := cldf.NewMemoryAddressBook()
		if rollbackErr := rollback.Save(chainSelector, address, tv); rollbackErr != nil {
			return fmt.Errorf("save to datastore: %w; prepare address-book rollback: %v", err, rollbackErr)
		}
		if rollbackErr := ab.Remove(rollback); rollbackErr != nil {
			return fmt.Errorf("save to datastore: %w; roll back address-book write: %v", err, rollbackErr)
		}
		if errors.Is(err, fdatastore.ErrAddressRefExists) {
			return fmt.Errorf(
				"this changeset already wrote a %s: two objects cannot share one (chain, type, version, qualifier), so one of them needs a distinct qualifier: %w",
				describe(planned), err,
			)
		}
		return fmt.Errorf("save to datastore: %w", err)
	}
	return nil
}
