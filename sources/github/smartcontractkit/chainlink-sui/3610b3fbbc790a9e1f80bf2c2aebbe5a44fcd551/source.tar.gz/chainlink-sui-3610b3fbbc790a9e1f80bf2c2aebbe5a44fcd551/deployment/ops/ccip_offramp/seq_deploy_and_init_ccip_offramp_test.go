//go:build integration

package offrampops

import (
	"context"
	"encoding/hex"
	"strings"
	"testing"

	"github.com/smartcontractkit/chainlink-common/pkg/logger"

	cld_ops "github.com/smartcontractkit/chainlink-deployments-framework/operations"

	"github.com/smartcontractkit/chainlink-sui/bindings/bind"
	"github.com/smartcontractkit/chainlink-sui/bindings/tests/testenv"
	sui_ops "github.com/smartcontractkit/chainlink-sui/deployment/ops"
	ccip_ops "github.com/smartcontractkit/chainlink-sui/deployment/ops/ccip"
	linkops "github.com/smartcontractkit/chainlink-sui/deployment/ops/link"
	"github.com/stretchr/testify/require"
)

func TestDeployAndInitCCIPOfframpSeq(t *testing.T) {
	t.Parallel()

	signer, client := testenv.SetupEnvironment(t)

	// create 4 additional signers + transmitters
	signerAddresses := make([]string, 0, 4) // Preallocate slice with capacity
	signerAddrBytes := make([][]byte, 0, 4)

	for range 4 {
		additionalSigner, _ := testenv.CreateTestAccount(t)

		signerAddress, err := additionalSigner.GetAddress()
		require.NoError(t, err)
		signerAddresses = append(signerAddresses, signerAddress)

		addrHex := strings.TrimPrefix(signerAddress, "0x")

		addrBytes, err := hex.DecodeString(addrHex)
		require.NoError(t, err)
		signerAddrBytes = append(signerAddrBytes, addrBytes)
	}

	deps := sui_ops.OpTxDeps{
		Client: client,
		Signer: signer,
		GetCallOpts: func() *bind.CallOpts {
			b := uint64(1_000_000_000)
			return &bind.CallOpts{
				WaitForExecution: true,
				GasBudget:        &b,
			}
		},
	}

	reporter := cld_ops.NewMemoryReporter()
	bundle := cld_ops.NewBundle(
		context.Background,
		logger.Test(t),
		reporter,
	)

	inputCCIP, err := ccip_ops.DeployCCIPDependencyPackages(bundle, deps)
	require.NoError(t, err, "failed to deploy CCIP dependency packages")

	reportCCIP, err := cld_ops.ExecuteOperation(bundle, ccip_ops.DeployCCIPOp, deps, inputCCIP)
	require.NoError(t, err, "failed to deploy CCIP Package")

	// Deploy LINK
	linkReport, err := cld_ops.ExecuteOperation(bundle, linkops.DeployLINKOp, deps, cld_ops.EmptyInput{})
	require.NoError(t, err, "failed to deploy LINK token")

	// Initialize upgrade registry (required by fee quoter and other CCIP functions)
	upgradeRegistryInput := ccip_ops.InitUpgradeRegistryInput{
		CCIPPackageId:    reportCCIP.Output.PackageId,
		StateObjectId:    reportCCIP.Output.Objects.CCIPObjectRefObjectId,
		OwnerCapObjectId: reportCCIP.Output.Objects.OwnerCapObjectId,
	}
	_, err = cld_ops.ExecuteOperation(bundle, ccip_ops.UpgradeRegistryInitializeOp, deps, upgradeRegistryInput)
	require.NoError(t, err, "failed to initialize Upgrade Registry")

	// Initialize feeQuoter
	feeQuoterInit := ccip_ops.InitFeeQuoterInput{
		CCIPPackageId:                 reportCCIP.Output.PackageId,
		StateObjectId:                 reportCCIP.Output.Objects.CCIPObjectRefObjectId,
		OwnerCapObjectId:              reportCCIP.Output.Objects.OwnerCapObjectId,
		MaxFeeJuelsPerMsg:             "100000000",
		LinkTokenCoinMetadataObjectId: linkReport.Output.Objects.CoinMetadataObjectId,
		TokenPriceStalenessThreshold:  60,
	}

	reportFeeQuoterInit, err := cld_ops.ExecuteOperation(bundle, ccip_ops.FeeQuoterInitializeOp, deps, feeQuoterInit)
	require.NoError(t, err, "failed to initialize Fee Quoter Package")

	// Run OffRamp Sequence
	seqOffRampInput := DeployAndInitCCIPOffRampSeqInput{
		CCIPObjectRefId: reportCCIP.Output.Objects.CCIPObjectRefObjectId,
		DeployCCIPOffRampInput: DeployCCIPOffRampInput{
			CCIPPackageId:     reportCCIP.Output.PackageId,
			MCMSPackageId:     inputCCIP.McmsPackageId,
			FastMcmsPackageId: inputCCIP.FastMcmsPackageId,
		},
		InitializeOffRampInput: InitializeOffRampInput{
			DestTransferCapId:                     reportCCIP.Output.Objects.DestTransferCapObjectId,
			FeeQuoterCapId:                        reportFeeQuoterInit.Output.Objects.FeeQuoterCapObjectId,
			ChainSelector:                         2,
			PremissionExecThresholdSeconds:        10,
			SourceChainSelectors:                  []uint64{1},
			SourceChainsIsEnabled:                 []bool{true},
			SourceChainsIsRMNVerificationDisabled: []bool{true},
			SourceChainsOnRamp:                    [][]byte{{0x01}},
		},
		ExecutionOCR3Config: SetOCR3ConfigInput{
			OffRampPackageId: "", // Will be set by the sequence
			OffRampStateId:   "", // Will be set by the sequence
			CCIPObjectRefId:  "", // Will be set by the sequence - REQUIRED for new function signature
			OwnerCapObjectId: "", // Will be set by the sequence
			ConfigDigest: []byte{
				0x00, 0x0A, 0x2F, 0x1F, 0x37, 0xB0, 0x33, 0xCC,
				0xC4, 0x42, 0x8A, 0xB6, 0x5C, 0x35, 0x39, 0xC9,
				0x31, 0x5D, 0xBF, 0x88, 0x2D, 0x4B, 0xAB, 0x13,
				0xF1, 0xE7, 0xEF, 0xE7, 0xB3, 0xDD, 0xDC, 0x36,
			},
			OCRPluginType:                  byte(1),
			BigF:                           byte(1),
			IsSignatureVerificationEnabled: false,
			Signers:                        signerAddrBytes,
			Transmitters:                   signerAddresses,
		},
	}

	seqResult, err := cld_ops.ExecuteSequence(bundle, DeployAndInitCCIPOffRampSequence, deps, seqOffRampInput)
	require.NoError(t, err, "failed to deploy CCIP OffRamp Package")

	// Set OCR3 Execution Config after sequence completes
	executionConfig := seqOffRampInput.ExecutionOCR3Config
	executionConfig.OffRampPackageId = seqResult.Output.CCIPOffRampPackageId
	executionConfig.OffRampStateId = seqResult.Output.Objects.StateObjectId
	executionConfig.OwnerCapObjectId = seqResult.Output.Objects.OwnerCapId
	executionConfig.CCIPObjectRefId = reportCCIP.Output.Objects.CCIPObjectRefObjectId

	_, err = cld_ops.ExecuteOperation(bundle, SetOCR3ConfigOp, deps, executionConfig)
	require.NoError(t, err, "failed to set OCR3 execution config")
}
