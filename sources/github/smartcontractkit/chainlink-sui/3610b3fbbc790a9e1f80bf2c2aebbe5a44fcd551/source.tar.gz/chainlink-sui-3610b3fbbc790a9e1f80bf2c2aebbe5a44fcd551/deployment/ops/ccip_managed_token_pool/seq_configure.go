package managedtokenpoolops

import (
	"github.com/Masterminds/semver/v3"

	cld_ops "github.com/smartcontractkit/chainlink-deployments-framework/operations"

	sui_ops "github.com/smartcontractkit/chainlink-sui/deployment/ops"
)

type ConfigureManagedTokenPoolObjects struct {
	OwnerCapObjectId string
	StateObjectId    string
}

type ConfigureManagedTokenPoolOutput struct {
	TokenSymbol string
	Objects     DeployManagedTokenPoolObjects
	Reports     []cld_ops.Report[any, any]
}

type ConfigureManagedTokenPoolInput struct {
	ManagedTokenPoolDeployInput
	// init
	TokenPoolPkgID         string
	TokenPoolStateObjectID string
	TokenOwnerCapID        string
	CoinObjectTypeArg      string

	// apply chain updates
	RemoteChainSelectorsToRemove []uint64
	RemoteChainSelectorsToAdd    []uint64
	RemotePoolAddressesToAdd     [][]string
	RemoteTokenAddressesToAdd    []string
	// set chain rate limiter configs
	RemoteChainSelectors []uint64
	OutboundIsEnableds   []bool
	OutboundCapacities   []uint64
	OutboundRates        []uint64
	InboundIsEnableds    []bool
	InboundCapacities    []uint64
	InboundRates         []uint64
}

var ConfigureManagedTokenPoolSequence = cld_ops.NewSequence(
	"sui-deploy-managed-token-pool-seq",
	semver.MustParse("0.1.0"),
	"Deploys and sets initial managed token pool configuration",
	func(env cld_ops.Bundle, deps sui_ops.OpTxDeps, input ConfigureManagedTokenPoolInput) (ConfigureManagedTokenPoolOutput, error) {

		seqReports := make([]cld_ops.Report[any, any], 0)
		report, err := cld_ops.ExecuteOperation(
			env,
			ManagedTokenPoolApplyChainUpdatesOp,
			deps,
			ManagedTokenPoolApplyChainUpdatesInput{
				ManagedTokenPoolPackageId:    input.TokenPoolPkgID,
				CoinObjectTypeArg:            input.CoinObjectTypeArg,
				StateObjectId:                input.TokenPoolStateObjectID,
				OwnerCap:                     input.TokenOwnerCapID,
				RemoteChainSelectorsToRemove: input.RemoteChainSelectorsToRemove,
				RemoteChainSelectorsToAdd:    input.RemoteChainSelectorsToAdd,
				RemotePoolAddressesToAdd:     input.RemotePoolAddressesToAdd,
				RemoteTokenAddressesToAdd:    input.RemoteTokenAddressesToAdd,
			},
		)
		if err != nil {
			return ConfigureManagedTokenPoolOutput{}, err
		}
		seqReports = append(seqReports, report.ToGenericReport())

		report2, err := cld_ops.ExecuteOperation(
			env,
			ManagedTokenPoolSetChainRateLimiterOp,
			deps,
			ManagedTokenPoolSetChainRateLimiterInput{
				ManagedTokenPoolPackageId: input.TokenPoolPkgID,
				CoinObjectTypeArg:         input.CoinObjectTypeArg,
				StateObjectId:             input.TokenPoolStateObjectID,
				OwnerCap:                  input.TokenOwnerCapID,
				RemoteChainSelectors:      input.RemoteChainSelectors,
				OutboundIsEnableds:        input.OutboundIsEnableds,
				OutboundCapacities:        input.OutboundCapacities,
				OutboundRates:             input.OutboundRates,
				InboundIsEnableds:         input.InboundIsEnableds,
				InboundCapacities:         input.InboundCapacities,
				InboundRates:              input.InboundRates,
			},
		)
		if err != nil {
			return ConfigureManagedTokenPoolOutput{}, err
		}
		seqReports = append(seqReports, report2.ToGenericReport())

		return ConfigureManagedTokenPoolOutput{
			Objects: DeployManagedTokenPoolObjects{
				OwnerCapObjectId: input.TokenOwnerCapID,
				StateObjectId:    input.TokenPoolStateObjectID,
			},
			Reports: seqReports,
		}, nil
	},
)
