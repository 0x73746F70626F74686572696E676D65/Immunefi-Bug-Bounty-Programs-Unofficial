// Code generated - DO NOT EDIT.
// This file is a generated binding and any manual changes will be lost.

package module_mock_eth_token

import (
	"context"
	"fmt"
	"math/big"

	"github.com/block-vision/sui-go-sdk/models"

	"github.com/smartcontractkit/chainlink-sui/bindings/bind"
	"github.com/smartcontractkit/chainlink-sui/relayer/client"
)

var (
	_ = big.NewInt
)

const FunctionInfo = `[{"package":"mock_eth_token","module":"mock_eth_token","name":"mint","parameters":[{"name":"treasury_cap","type":"TreasuryCap<MOCK_ETH_TOKEN>"},{"name":"amount","type":"u64"}]},{"package":"mock_eth_token","module":"mock_eth_token","name":"mint_and_transfer","parameters":[{"name":"treasury_cap","type":"TreasuryCap<MOCK_ETH_TOKEN>"},{"name":"amount","type":"u64"},{"name":"recipient","type":"address"}]}]`

type IMockEthToken interface {
	MintAndTransfer(ctx context.Context, opts *bind.CallOpts, treasuryCap bind.Object, amount uint64, recipient string) (*models.SuiTransactionBlockResponse, error)
	Mint(ctx context.Context, opts *bind.CallOpts, treasuryCap bind.Object, amount uint64) (*models.SuiTransactionBlockResponse, error)
	DevInspect() IMockEthTokenDevInspect
	Encoder() MockEthTokenEncoder
	Bound() bind.IBoundContract
}

type IMockEthTokenDevInspect interface {
}

type MockEthTokenEncoder interface {
	MintAndTransfer(treasuryCap bind.Object, amount uint64, recipient string) (*bind.EncodedCall, error)
	MintAndTransferWithArgs(args ...any) (*bind.EncodedCall, error)
	Mint(treasuryCap bind.Object, amount uint64) (*bind.EncodedCall, error)
	MintWithArgs(args ...any) (*bind.EncodedCall, error)
}

type MockEthTokenContract struct {
	*bind.BoundContract
	mockEthTokenEncoder
	devInspect *MockEthTokenDevInspect
}

type MockEthTokenDevInspect struct {
	contract *MockEthTokenContract
}

var _ IMockEthToken = (*MockEthTokenContract)(nil)
var _ IMockEthTokenDevInspect = (*MockEthTokenDevInspect)(nil)

func NewMockEthToken(packageID string, chainClient client.BindingsClient) (IMockEthToken, error) {
	contract, err := bind.NewBoundContract(packageID, "mock_eth_token", "mock_eth_token", chainClient)
	if err != nil {
		return nil, err
	}

	c := &MockEthTokenContract{
		BoundContract:       contract,
		mockEthTokenEncoder: mockEthTokenEncoder{BoundContract: contract},
	}
	c.devInspect = &MockEthTokenDevInspect{contract: c}
	return c, nil
}

func (c *MockEthTokenContract) Bound() bind.IBoundContract {
	return c.BoundContract
}

func (c *MockEthTokenContract) Encoder() MockEthTokenEncoder {
	return c.mockEthTokenEncoder
}

func (c *MockEthTokenContract) DevInspect() IMockEthTokenDevInspect {
	return c.devInspect
}

type MOCK_ETH_TOKEN struct {
}

// MintAndTransfer executes the mint_and_transfer Move function.
func (c *MockEthTokenContract) MintAndTransfer(ctx context.Context, opts *bind.CallOpts, treasuryCap bind.Object, amount uint64, recipient string) (*models.SuiTransactionBlockResponse, error) {
	encoded, err := c.mockEthTokenEncoder.MintAndTransfer(treasuryCap, amount, recipient)
	if err != nil {
		return nil, fmt.Errorf("failed to encode function call: %w", err)
	}

	return c.ExecuteTransaction(ctx, opts, encoded)
}

// Mint executes the mint Move function.
func (c *MockEthTokenContract) Mint(ctx context.Context, opts *bind.CallOpts, treasuryCap bind.Object, amount uint64) (*models.SuiTransactionBlockResponse, error) {
	encoded, err := c.mockEthTokenEncoder.Mint(treasuryCap, amount)
	if err != nil {
		return nil, fmt.Errorf("failed to encode function call: %w", err)
	}

	return c.ExecuteTransaction(ctx, opts, encoded)
}

type mockEthTokenEncoder struct {
	*bind.BoundContract
}

// MintAndTransfer encodes a call to the mint_and_transfer Move function.
func (c mockEthTokenEncoder) MintAndTransfer(treasuryCap bind.Object, amount uint64, recipient string) (*bind.EncodedCall, error) {
	typeArgsList := []string{}
	typeParamsList := []string{}
	return c.EncodeCallArgsWithGenerics("mint_and_transfer", typeArgsList, typeParamsList, []string{
		"&mut TreasuryCap<MOCK_ETH_TOKEN>",
		"u64",
		"address",
	}, []any{
		treasuryCap,
		amount,
		recipient,
	}, nil)
}

// MintAndTransferWithArgs encodes a call to the mint_and_transfer Move function using arbitrary arguments.
// This method allows passing both regular values and transaction.Argument values for PTB chaining.
func (c mockEthTokenEncoder) MintAndTransferWithArgs(args ...any) (*bind.EncodedCall, error) {
	expectedParams := []string{
		"&mut TreasuryCap<MOCK_ETH_TOKEN>",
		"u64",
		"address",
	}

	if len(args) != len(expectedParams) {
		return nil, fmt.Errorf("expected %d arguments, got %d", len(expectedParams), len(args))
	}
	typeArgsList := []string{}
	typeParamsList := []string{}
	return c.EncodeCallArgsWithGenerics("mint_and_transfer", typeArgsList, typeParamsList, expectedParams, args, nil)
}

// Mint encodes a call to the mint Move function.
func (c mockEthTokenEncoder) Mint(treasuryCap bind.Object, amount uint64) (*bind.EncodedCall, error) {
	typeArgsList := []string{}
	typeParamsList := []string{}
	return c.EncodeCallArgsWithGenerics("mint", typeArgsList, typeParamsList, []string{
		"&mut TreasuryCap<MOCK_ETH_TOKEN>",
		"u64",
	}, []any{
		treasuryCap,
		amount,
	}, nil)
}

// MintWithArgs encodes a call to the mint Move function using arbitrary arguments.
// This method allows passing both regular values and transaction.Argument values for PTB chaining.
func (c mockEthTokenEncoder) MintWithArgs(args ...any) (*bind.EncodedCall, error) {
	expectedParams := []string{
		"&mut TreasuryCap<MOCK_ETH_TOKEN>",
		"u64",
	}

	if len(args) != len(expectedParams) {
		return nil, fmt.Errorf("expected %d arguments, got %d", len(expectedParams), len(args))
	}
	typeArgsList := []string{}
	typeParamsList := []string{}
	return c.EncodeCallArgsWithGenerics("mint", typeArgsList, typeParamsList, expectedParams, args, nil)
}
