package mocklinktoken

import (
	"context"

	"github.com/block-vision/sui-go-sdk/models"
	"github.com/smartcontractkit/chainlink-sui/relayer/client"

	"github.com/smartcontractkit/chainlink-sui/bindings/bind"
	module_mock_link_token "github.com/smartcontractkit/chainlink-sui/bindings/generated/ccip/mock_link_token/mock_link_token"
	"github.com/smartcontractkit/chainlink-sui/contracts"
)

type MockLinkToken interface {
	Address() string
	MockLinkToken() module_mock_link_token.IMockLinkToken
}

var _ MockLinkToken = MockLinkTokenPackage{}

type MockLinkTokenPackage struct {
	address string

	mockLinkToken module_mock_link_token.IMockLinkToken
}

func (p MockLinkTokenPackage) Address() string {
	return p.address
}

func (p MockLinkTokenPackage) MockLinkToken() module_mock_link_token.IMockLinkToken {
	return p.mockLinkToken
}

func NewMockLinkToken(address string, chainClient client.BindingsClient) (MockLinkToken, error) {
	pkgObjectId, err := bind.ToSuiAddress(address)
	if err != nil {
		return nil, err
	}

	mockLinkTokenContract, err := module_mock_link_token.NewMockLinkToken(address, chainClient)
	if err != nil {
		return nil, err
	}

	return MockLinkTokenPackage{
		address:       pkgObjectId,
		mockLinkToken: mockLinkTokenContract,
	}, nil
}

func PublishMockLinkToken(ctx context.Context, opts *bind.CallOpts, chainClient client.BindingsClient, suiRPC string) (MockLinkToken, *models.SuiTransactionBlockResponse, error) {
	signerAddr, err := opts.Signer.GetAddress()
	if err != nil {
		return nil, nil, err
	}

	artifact, err := bind.CompilePackage(contracts.MockLinkToken, map[string]string{
		"mock_link_token": "0x0",
		"signer":          signerAddr,
	}, false, suiRPC)
	if err != nil {
		return nil, nil, err
	}

	//nolint:revive // var-naming: generated bindings keep packageId naming
	packageId, tx, err := bind.PublishPackage(ctx, opts, chainClient, bind.PublishRequest{
		CompiledModules: artifact.Modules,
		Dependencies:    artifact.Dependencies,
	})
	if err != nil {
		return nil, nil, err
	}

	contract, err := NewMockLinkToken(packageId, chainClient)
	if err != nil {
		return nil, nil, err
	}

	return contract, tx, nil
}
