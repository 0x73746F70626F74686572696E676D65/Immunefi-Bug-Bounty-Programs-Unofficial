package managedtokenpool

import (
	"context"

	"github.com/block-vision/sui-go-sdk/models"
	"github.com/smartcontractkit/chainlink-sui/relayer/client"

	"github.com/smartcontractkit/chainlink-sui/bindings/bind"
	module_managed_token_pool "github.com/smartcontractkit/chainlink-sui/bindings/generated/ccip/ccip_token_pools/managed_token_pool"
	"github.com/smartcontractkit/chainlink-sui/contracts"
)

type ManagedTokenPool interface {
	Address() string
}

var _ ManagedTokenPool = CCIPManagedTokenPoolPackage{}

type CCIPManagedTokenPoolPackage struct {
	address string

	tokenPool module_managed_token_pool.IManagedTokenPool
}

func (p CCIPManagedTokenPoolPackage) Address() string {
	return p.address
}

func NewCCIPManagedTokenPool(address string, chainClient client.BindingsClient) (ManagedTokenPool, error) {
	tokenPoolContract, err := module_managed_token_pool.NewManagedTokenPool(address, chainClient)
	if err != nil {
		return nil, err
	}

	packageId, err := bind.ToSuiAddress(address)
	if err != nil {
		return nil, err
	}

	return CCIPManagedTokenPoolPackage{
		address:   packageId,
		tokenPool: tokenPoolContract,
	}, nil
}

func PublishCCIPManagedTokenPool(
	ctx context.Context,
	opts *bind.CallOpts,
	chainClient client.BindingsClient,
	ccipAddress,
	managedTokenAddress,
	mcmsAddress,
	fastMcmsAddress,
	mcmsOwnerAddress, suiRPC string) (ManagedTokenPool, *models.SuiTransactionBlockResponse, error) {
	signerAddr, err := opts.Signer.GetAddress()
	if err != nil {
		return nil, nil, err
	}

	artifact, err := bind.CompilePackage(contracts.ManagedTokenPool, map[string]string{
		"ccip":               ccipAddress,
		"managed_token_pool": "0x0",
		"managed_token":      managedTokenAddress,
		"mcms":               mcmsAddress,
		"fast_mcms":          fastMcmsAddress,
		"mcms_owner":         mcmsOwnerAddress,
		"signer":             signerAddr,
	}, false, suiRPC)
	if err != nil {
		return nil, nil, err
	}

	//nolint:revive // var-naming: generated bindings keep packageId naming
	packageId, tx, err := bind.PublishPackage(ctx, opts, chainClient, bind.PublishRequest{
		CompiledModules: artifact.Modules,
		Dependencies:    artifact.Dependencies,
	})
	if err != nil {
		return nil, nil, err
	}

	contract, err := NewCCIPManagedTokenPool(packageId, chainClient)
	if err != nil {
		return nil, nil, err
	}

	return contract, tx, nil
}
