package test

import (
	"context"
	"log"

	"github.com/block-vision/sui-go-sdk/models"
	"github.com/smartcontractkit/chainlink-sui/relayer/client"

	"github.com/smartcontractkit/chainlink-sui/bindings/bind"
	modulecomplex "github.com/smartcontractkit/chainlink-sui/bindings/generated/test/complex"
	modulecounter "github.com/smartcontractkit/chainlink-sui/bindings/generated/test/counter"
	module_generics "github.com/smartcontractkit/chainlink-sui/bindings/generated/test/generics"
	"github.com/smartcontractkit/chainlink-sui/contracts"
)

type Test interface {
	Address() string
	Counter() modulecounter.ICounter
	Complex() modulecomplex.IComplex
	Generics() module_generics.IGenerics
}

var _ Test = TestPackage{}

type TestPackage struct {
	address string

	counter   modulecounter.ICounter
	complex   modulecomplex.IComplex
	generics  module_generics.IGenerics
	PackageId string
}

func (p TestPackage) Address() string {
	return p.address
}

func (p TestPackage) Counter() modulecounter.ICounter {
	return p.counter
}

func (p TestPackage) Complex() modulecomplex.IComplex {
	return p.complex
}

func (p TestPackage) Generics() module_generics.IGenerics {
	return p.generics
}

func NewTest(address string, chainClient client.BindingsClient) (Test, error) {
	counterContract, err := modulecounter.NewCounter(address, chainClient)
	if err != nil {
		return nil, err
	}

	complexContract, err := modulecomplex.NewComplex(address, chainClient)
	if err != nil {
		return nil, err
	}

	genericsContract, err := module_generics.NewGenerics(address, chainClient)
	if err != nil {
		return nil, err
	}

	return TestPackage{
		address:   address,
		counter:   counterContract,
		complex:   complexContract,
		generics:  genericsContract,
		PackageId: address,
	}, nil
}

func PublishTest(ctx context.Context, opts *bind.CallOpts, chainClient client.BindingsClient, testSecondary, suiRPC string) (Test, *models.SuiTransactionBlockResponse, error) {
	signerAddr, err := opts.Signer.GetAddress()
	if err != nil {
		return nil, nil, err
	}

	artifact, err := bind.CompilePackage(contracts.Test, map[string]string{
		"test":           "0x0",
		"test_secondary": testSecondary,
		"signer":         signerAddr,
	}, false, suiRPC)
	if err != nil {
		return nil, nil, err
	}

	artifact.Dependencies = append(artifact.Dependencies, testSecondary)

	//nolint:revive // var-naming: generated bindings keep packageId naming
	packageId, tx, err := bind.PublishPackage(ctx, opts, chainClient, bind.PublishRequest{
		CompiledModules: artifact.Modules,
		Dependencies:    artifact.Dependencies,
	})
	if err != nil {
		return nil, nil, err
	}
	log.Printf("successfully published test package")
	contract, err := NewTest(packageId, chainClient)
	if err != nil {
		return nil, nil, err
	}

	return contract, tx, nil
}

func PublishTestSecondary(ctx context.Context, opts *bind.CallOpts, chainClient client.BindingsClient, suiRPC string) (Test, *models.SuiTransactionBlockResponse, error) {
	signerAddr, err := opts.Signer.GetAddress()
	if err != nil {
		return nil, nil, err
	}

	artifact, err := bind.CompilePackage(contracts.TestSecondary, map[string]string{
		"test_secondary": "0x0",

		"signer": signerAddr,
	}, false, suiRPC)
	if err != nil {
		return nil, nil, err
	}

	//nolint:revive // var-naming: generated bindings keep packageId naming
	packageId, tx, err := bind.PublishPackage(ctx, opts, chainClient, bind.PublishRequest{
		CompiledModules: artifact.Modules,
		Dependencies:    artifact.Dependencies,
	})
	if err != nil {
		return nil, nil, err
	}
	log.Printf("successfully published test secondary package")
	contract, err := NewTest(packageId, chainClient)
	if err != nil {
		return nil, nil, err
	}

	return contract, tx, nil
}
