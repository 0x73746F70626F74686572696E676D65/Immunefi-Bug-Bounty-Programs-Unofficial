/// Reference receiver for tests and documentation. Not for production.
///
/// Implements the singleton tail-argument pattern for V1 destination execution.
/// Tail slots: shared `Clock` at `@0x6` and the single `CCIPReceiverState`
/// from `init`. See `contracts/ccip/docs/receiver-integration-guide.md`.
///
/// WARNING: registration ordering is the sender's responsibility. The OffRamp
/// populates and delivers an Any2SuiMessage only when this package is
/// registered in the receiver registry at execution time. If a message
/// carrying data or a gas limit arrives while this package is not registered,
/// the OffRamp skips the receiver callback yet still marks the execution
/// SUCCESS, which makes the message terminal with no retry. A token leg in
/// the same message completes independently, so assets can be released without
/// the receiver-side application logic ever running. Register the receiver
/// before any messages are sent to it; re-registering after a message has
/// landed does not retroactively execute it.
module ccip_dummy_receiver::dummy_receiver;

use ccip::client;
use ccip::offramp_state_helper as osh;
use ccip::publisher_wrapper;
use ccip::receiver_registry;
use ccip::state_object::CCIPObjectRef;
use std::string::{Self, String};
use sui::clock::Clock;
use sui::coin::Coin;
use sui::dynamic_field as df;
use sui::event;
use sui::package::{Self, Publisher};
use sui::transfer::Receiving;

const EMessageIdMismatch: u64 = 0;

/// One-time witness for package publish. Consumed in `init`.
public struct DUMMY_RECEIVER has drop {}

/// Admin capability for registration and coin receive helpers.
/// Stored by the deployer; not passed to `ccip_receive`.
public struct OwnerCap has key, store {
    id: UID,
    receiver_address: address,
}

public struct ReceivedMessage has copy, drop {
    message_id: vector<u8>,
    source_chain_selector: u64,
    sender: vector<u8>,
    data: vector<u8>,
    dest_token_transfer_length: u64,
    dest_token_amounts: vector<TokenAmount>,
}

/// Singleton delivery state. Created once in `init`; `has key` only so this
/// module retains transfer and share control.
public struct CCIPReceiverState has key {
    id: UID,
    counter: u64,
    message_id: vector<u8>,
    source_chain_selector: u64,
    sender: vector<u8>,
    data: vector<u8>,
    message_receiver: address,
    token_receiver: address,
    dest_token_transfer_length: u64,
    dest_token_amounts: vector<TokenAmount>,
}

/// Type proof for `receiver_registry` and `consume_any2sui_message`.
public struct DummyReceiverProof has drop {}

public struct PublisherKey has copy, drop, store {}

public struct TokenAmount has copy, drop, store {
    token: address,
    amount: u256,
}

public fun type_and_version(): String {
    string::utf8(b"DummyReceiver 1.6.0")
}

/// Sole constructor for `CCIPReceiverState`.
fun init(otw: DUMMY_RECEIVER, ctx: &mut TxContext) {
    let state = CCIPReceiverState {
        id: object::new(ctx),
        counter: 0,
        message_id: vector[],
        source_chain_selector: 0,
        sender: vector[],
        data: vector[],
        message_receiver: @0x0,
        token_receiver: @0x0,
        dest_token_transfer_length: 0,
        dest_token_amounts: vector[],
    };

    let mut owner_cap = OwnerCap {
        id: object::new(ctx),
        receiver_address: object::id_to_address(object::borrow_id(&state)),
    };

    let publisher = package::claim(otw, ctx);
    df::add(&mut owner_cap.id, PublisherKey {}, publisher);

    transfer::share_object(state);
    transfer::transfer(owner_cap, ctx.sender());
}

/// Registers this package in the OffRamp receiver registry.
///
/// WARNING: must be called before any messages are sent to this receiver. The
/// OffRamp checks registration at execution time; an unregistered receiver
/// causes the message to be marked SUCCESS without running the callback and
/// with no retry. See the module doc for the full consequence, including the
/// token-leg behavior.
public fun register_receiver(owner_cap: &OwnerCap, ref: &mut CCIPObjectRef) {
    let publisher: &Publisher = df::borrow(&owner_cap.id, PublisherKey {});
    let publisher_wrapper = publisher_wrapper::create(publisher, DummyReceiverProof {});
    receiver_registry::register_receiver(ref, publisher_wrapper, DummyReceiverProof {});
}

public fun get_counter(state: &CCIPReceiverState): u64 {
    state.counter
}

public fun get_dest_token_amounts(state: &CCIPReceiverState): vector<TokenAmount> {
    state.dest_token_amounts
}

public fun get_token_receiver(state: &CCIPReceiverState): address {
    state.token_receiver
}

public fun get_token_amount_token(token_amount: &TokenAmount): address {
    token_amount.token
}

public fun get_token_amount_amount(token_amount: &TokenAmount): u256 {
    token_amount.amount
}

/// Accepts coins sent to the shared state object via transfer-to-object.
public fun receive_and_send_coin<T>(
    state: &mut CCIPReceiverState,
    _: &OwnerCap,
    coin_receiving: Receiving<Coin<T>>,
    recipient: address,
) {
    let c = transfer::public_receive<Coin<T>>(&mut state.id, coin_receiving);
    transfer::public_transfer(c, recipient);
}

public fun receive_coin<T>(
    state: &mut CCIPReceiverState,
    _: &OwnerCap,
    coin_receiving: Receiving<Coin<T>>,
): Coin<T> {
    transfer::public_receive<Coin<T>>(&mut state.id, coin_receiving)
}

// DO NOT USE THIS FUNCTION IN PRODUCTION. IT IS ONLY FOR TESTING PURPOSES.
public fun receive_and_send_coin_no_owner_cap<T>(
    state: &mut CCIPReceiverState,
    coin_receiving: Receiving<Coin<T>>,
    recipient: address,
) {
    let c = transfer::public_receive<Coin<T>>(&mut state.id, coin_receiving);
    transfer::public_transfer(c, recipient);
}

// DO NOT USE THIS FUNCTION IN PRODUCTION. IT IS ONLY FOR TESTING PURPOSES.
public fun receive_coin_no_owner_cap<T>(
    state: &mut CCIPReceiverState,
    coin_receiving: Receiving<Coin<T>>,
): Coin<T> {
    transfer::public_receive<Coin<T>>(&mut state.id, coin_receiving)
}

/// CCIP entrypoint. Both tail types are singletons so manual executors cannot
/// substitute an alternate object of the same type.
public fun ccip_receive(
    expected_message_id: vector<u8>,
    ref: &CCIPObjectRef,
    message: client::Any2SuiMessage,
    clock: &Clock,
    state: &mut CCIPReceiverState,
) {
    clock; // read-only tail slot example; use `clock.timestamp_ms()` when needed

    let (
        message_id,
        source_chain_selector,
        sender,
        data,
        message_receiver,
        token_receiver,
        dest_token_amounts,
    ) = osh::consume_any2sui_message(ref, message, DummyReceiverProof {});

    assert!(message_id == expected_message_id, EMessageIdMismatch);

    state.counter = state.counter + 1;
    state.message_id = message_id;
    state.source_chain_selector = source_chain_selector;
    state.sender = sender;
    state.data = data;
    state.message_receiver = message_receiver;
    state.token_receiver = token_receiver;
    state.dest_token_transfer_length = dest_token_amounts.length() as u64;
    state.dest_token_amounts = vector[];

    let mut i = 0;
    while (i < state.dest_token_transfer_length) {
        let (token, amount) = client::get_token_and_amount(&dest_token_amounts[i]);
        state.dest_token_amounts.push_back(TokenAmount { token, amount });
        i = i + 1;
    };

    event::emit(ReceivedMessage {
        message_id,
        source_chain_selector,
        sender,
        data,
        dest_token_transfer_length: state.dest_token_transfer_length,
        dest_token_amounts: state.dest_token_amounts,
    });
}
