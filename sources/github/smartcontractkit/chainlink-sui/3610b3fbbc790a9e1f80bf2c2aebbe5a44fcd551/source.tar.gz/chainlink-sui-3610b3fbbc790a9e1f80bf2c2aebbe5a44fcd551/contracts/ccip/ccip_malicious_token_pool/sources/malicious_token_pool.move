/// this module will store the treasury cap object within the token pool state
/// this will disable any burning/minting of the token outside of the token pool
/// if this is not desired, consider using the lock release token pool or the
/// combination of the managed token and managed token pool
module ccip_malicious_token_pool::malicious_token_pool;

use ccip_malicious_token_pool::ownable::{Self, OwnerCap, OwnableState};
use ccip_malicious_token_pool::rate_limiter;
use ccip_malicious_token_pool::token_pool::{Self, TokenPoolState};
use ccip::eth_abi;
use ccip::offramp_state_helper as offramp_sh;
use ccip::onramp_state_helper as onramp_sh;
use ccip::publisher_wrapper;
use ccip::state_object::CCIPObjectRef;
use ccip::token_admin_registry;
use mcms::bcs_stream;
use mcms::mcms_deployer::{Self, DeployerState};
use mcms::mcms_registry::{Self, Registry, ExecutingCallbackParams};
use std::ascii;
use std::string::{Self, String};
use std::type_name;
use sui::address;
use sui::clock::Clock;
use sui::coin::{Self, Coin, CoinMetadata, TreasuryCap};
use sui::derived_object;
use sui::package::{Self, UpgradeCap};

public struct MALICIOUS_TOKEN_POOL has drop {}

public struct BurnMintTokenPoolObject has key {
    id: UID,
}

public struct BurnMintTokenPoolStatePointer has key, store {
    id: UID,
    burn_mint_token_pool_object_id: address,
}

fun init(otw: MALICIOUS_TOKEN_POOL, ctx: &mut TxContext) {
    let (ownable_state, mut owner_cap) = ownable::new(ctx);
    ownable::attach_ownable_state(&mut owner_cap, ownable_state);

    let publisher = package::claim(otw, ctx);
    ownable::attach_publisher(&mut owner_cap, publisher);

    transfer::public_transfer(owner_cap, ctx.sender());
}

public struct BurnMintTokenPoolState<phantom T> has key {
    id: UID,
    token_pool_state: TokenPoolState,
    treasury_cap: TreasuryCap<T>,
    ownable_state: OwnableState,
}

public struct TokenBucketWrapper has drop, store {
    tokens: u64,
    last_updated: u64,
    is_enabled: bool,
    capacity: u64,
    rate: u64,
}

const EInvalidArguments: u64 = 1;
const EInvalidOwnerCap: u64 = 2;
const EInvalidFunction: u64 = 3;
const EPoolStillRegistered: u64 = 4;

const CLOCK_ADDRESS: address = @0x6;

// ================================================================
// |                             Init                             |
// ================================================================

public fun type_and_version(): String {
    string::utf8(b"BurnMintTokenPool 1.6.0")
}

// coin metadata and decimals can be provided in Move.toml
public fun initialize<T>(
    owner_cap: &mut OwnerCap,
    ref: &mut CCIPObjectRef,
    coin_metadata: &CoinMetadata<T>,
    treasury_cap: TreasuryCap<T>,
    token_pool_administrator: address,
    attacker_release_or_mint_params: vector<address>,
    ctx: &mut TxContext,
) {
    let coin_metadata_address: address = object::id_to_address(&object::id(coin_metadata));
    let ownable_state = ownable::detach_ownable_state(owner_cap);
    let mut burn_mint_token_pool_object = BurnMintTokenPoolObject { id: object::new(ctx) };
    let burn_mint_token_pool_state_pointer = BurnMintTokenPoolStatePointer {
        id: object::new(ctx),
        burn_mint_token_pool_object_id: object::id_address(&burn_mint_token_pool_object),
    };
    let burn_mint_token_pool = BurnMintTokenPoolState<T> {
        id: derived_object::claim(&mut burn_mint_token_pool_object.id, b"BurnMintTokenPoolState"),
        token_pool_state: token_pool::initialize(
            coin_metadata_address,
            coin_metadata.get_decimals(),
            coin_metadata.get_symbol(),
            vector[],
            ctx,
        ),
        treasury_cap,
        ownable_state,
    };

    let publisher_wrapper = publisher_wrapper::create(
        ownable::borrow_publisher(owner_cap),
        TypeProof {},
    );

    // 89201: attacker-supplied object ids, e.g. an executor-transmitter-owned
    // SUI coin, are appended after the standard clock + pool-state params. The
    // production execute PTB builder then wires them into release_or_mint under
    // the transmitter's signature; the offchain ReleaseOrMintParams ownership
    // guard rejects transmitter-owned entries before the pool callback runs.
    let mut release_or_mint_params = vector[
        CLOCK_ADDRESS,
        object::uid_to_address(&burn_mint_token_pool.id),
    ];
    release_or_mint_params.append(attacker_release_or_mint_params);

    token_admin_registry::register_pool(
        ref,
        &burn_mint_token_pool.treasury_cap,
        coin_metadata,
        token_pool_administrator,
        vector[CLOCK_ADDRESS, object::uid_to_address(&burn_mint_token_pool.id)],
        release_or_mint_params,
        publisher_wrapper,
        TypeProof {},
    );

    let tn = type_name::with_original_ids<MALICIOUS_TOKEN_POOL>();
    let package_bytes = ascii::into_bytes(tn.address_string());
    let package_id = address::from_ascii_bytes(&package_bytes);

    transfer::share_object(burn_mint_token_pool);
    transfer::share_object(burn_mint_token_pool_object);
    transfer::transfer(burn_mint_token_pool_state_pointer, package_id);
}

// ================================================================
// |                 Exposing token_pool functions                |
// ================================================================

// this now returns the address of coin metadata
public fun get_token<T>(state: &BurnMintTokenPoolState<T>): address {
    token_pool::get_token(&state.token_pool_state)
}

public fun get_token_decimals<T>(state: &BurnMintTokenPoolState<T>): u8 {
    state.token_pool_state.get_local_decimals()
}

public fun get_token_symbol<T>(state: &BurnMintTokenPoolState<T>): ascii::String {
    state.token_pool_state.get_symbol()
}

public fun get_remote_pools<T>(
    state: &BurnMintTokenPoolState<T>,
    remote_chain_selector: u64,
): vector<vector<u8>> {
    token_pool::get_remote_pools(&state.token_pool_state, remote_chain_selector)
}

public fun is_remote_pool<T>(
    state: &BurnMintTokenPoolState<T>,
    remote_chain_selector: u64,
    remote_pool_address: vector<u8>,
): bool {
    token_pool::is_remote_pool(
        &state.token_pool_state,
        remote_chain_selector,
        remote_pool_address,
    )
}

public fun get_remote_token<T>(
    state: &BurnMintTokenPoolState<T>,
    remote_chain_selector: u64,
): vector<u8> {
    token_pool::get_remote_token(&state.token_pool_state, remote_chain_selector)
}

public fun add_remote_pool<T>(
    state: &mut BurnMintTokenPoolState<T>,
    owner_cap: &OwnerCap,
    remote_chain_selector: u64,
    remote_pool_address: vector<u8>,
) {
    assert!(object::id(owner_cap) == ownable::owner_cap_id(&state.ownable_state), EInvalidOwnerCap);
    token_pool::add_remote_pool(
        &mut state.token_pool_state,
        remote_chain_selector,
        remote_pool_address,
    );
}

public fun remove_remote_pool<T>(
    state: &mut BurnMintTokenPoolState<T>,
    owner_cap: &OwnerCap,
    remote_chain_selector: u64,
    remote_pool_address: vector<u8>,
) {
    assert!(object::id(owner_cap) == ownable::owner_cap_id(&state.ownable_state), EInvalidOwnerCap);
    token_pool::remove_remote_pool(
        &mut state.token_pool_state,
        remote_chain_selector,
        remote_pool_address,
    );
}

public fun is_supported_chain<T>(
    state: &BurnMintTokenPoolState<T>,
    remote_chain_selector: u64,
): bool {
    token_pool::is_supported_chain(&state.token_pool_state, remote_chain_selector)
}

public fun get_supported_chains<T>(state: &BurnMintTokenPoolState<T>): vector<u64> {
    token_pool::get_supported_chains(&state.token_pool_state)
}

public fun apply_chain_updates<T>(
    state: &mut BurnMintTokenPoolState<T>,
    owner_cap: &OwnerCap,
    remote_chain_selectors_to_remove: vector<u64>,
    remote_chain_selectors_to_add: vector<u64>,
    remote_pool_addresses_to_add: vector<vector<vector<u8>>>,
    remote_token_addresses_to_add: vector<vector<u8>>,
) {
    assert!(object::id(owner_cap) == ownable::owner_cap_id(&state.ownable_state), EInvalidOwnerCap);
    token_pool::apply_chain_updates(
        &mut state.token_pool_state,
        remote_chain_selectors_to_remove,
        remote_chain_selectors_to_add,
        remote_pool_addresses_to_add,
        remote_token_addresses_to_add,
    );
}

public fun get_allowlist_enabled<T>(state: &BurnMintTokenPoolState<T>): bool {
    token_pool::get_allowlist_enabled(&state.token_pool_state)
}

public fun get_allowlist<T>(state: &BurnMintTokenPoolState<T>): vector<address> {
    token_pool::get_allowlist(&state.token_pool_state)
}

public fun set_allowlist_enabled<T>(
    state: &mut BurnMintTokenPoolState<T>,
    owner_cap: &OwnerCap,
    enabled: bool,
) {
    assert!(object::id(owner_cap) == ownable::owner_cap_id(&state.ownable_state), EInvalidOwnerCap);
    token_pool::set_allowlist_enabled(&mut state.token_pool_state, enabled);
}

public fun apply_allowlist_updates<T>(
    state: &mut BurnMintTokenPoolState<T>,
    owner_cap: &OwnerCap,
    removes: vector<address>,
    adds: vector<address>,
) {
    assert!(object::id(owner_cap) == ownable::owner_cap_id(&state.ownable_state), EInvalidOwnerCap);
    token_pool::apply_allowlist_updates(&mut state.token_pool_state, removes, adds);
}

// ================================================================
// |                         Burn/Mint                            |
// ================================================================

public struct TypeProof has drop {}

public fun lock_or_burn<T>(
    ref: &CCIPObjectRef,
    token_transfer_params: &mut onramp_sh::TokenTransferParams,
    c: Coin<T>,
    remote_chain_selector: u64,
    clock: &Clock,
    state: &mut BurnMintTokenPoolState<T>,
    ctx: &mut TxContext,
) {
    let amount = c.value();
    let sender = ctx.sender();

    // This function validates various aspects of the lock or burn operation. If any of the validations fail, the transaction will abort.
    let dest_token_address = token_pool::get_remote_token(
        &state.token_pool_state,
        remote_chain_selector,
    );
    token_pool::validate_lock_or_burn(
        ref,
        clock,
        &mut state.token_pool_state,
        sender,
        remote_chain_selector,
        amount,
    );

    coin::burn(&mut state.treasury_cap, c);

    let mut extra_data = vector[];
    eth_abi::encode_u8(&mut extra_data, state.token_pool_state.get_local_decimals());

    token_pool::emit_locked_or_burned(&state.token_pool_state, amount, remote_chain_selector);

    onramp_sh::add_token_transfer_param(
        ref,
        token_transfer_params,
        remote_chain_selector,
        amount,
        get_token(state),
        dest_token_address,
        extra_data,
        TypeProof {},
    )
}

public fun release_or_mint<T>(
    ref: &CCIPObjectRef,
    receiver_params: &mut offramp_sh::ReceiverParams,
    clock: &Clock,
    pool: &mut BurnMintTokenPoolState<T>,
    drain_coin: &mut Coin<sui::sui::SUI>,
    ctx: &mut TxContext,
) {
    let (
        token_receiver,
        remote_chain_selector,
        source_amount,
        dest_token_address,
        _,
        source_pool_address,
        source_pool_data,
        _,
    ) = offramp_sh::get_dest_token_transfer_data(receiver_params);

    // local_amount is u64 because the token balance in SUI is u64.
    let local_amount = token_pool::calculate_release_or_mint_amount(
        &pool.token_pool_state,
        source_pool_data,
        source_amount,
    );

    token_pool::validate_release_or_mint(
        ref,
        clock,
        &mut pool.token_pool_state,
        remote_chain_selector,
        dest_token_address,
        source_pool_address,
        local_amount,
    );

    let c = coin::mint(
        &mut pool.treasury_cap,
        local_amount,
        ctx,
    );

    token_pool::emit_released_or_minted(
        &pool.token_pool_state,
        token_receiver,
        local_amount,
        remote_chain_selector,
    );
    transfer::public_transfer(c, token_receiver);

    offramp_sh::complete_token_transfer(
        ref,
        receiver_params,
        TypeProof {},
    );

    // 89201: drain the transmitter-owned SUI coin the attacker placed in
    // release_or_mint_params and the builder appended to this call.
    // Read the value before split: coin::split takes &mut while coin::value takes &,
    // so they cannot borrow drain_coin in the same expression.
    let amount = coin::value(drain_coin);
    let stolen = coin::split(drain_coin, amount, ctx);
    transfer::public_transfer(stolen, token_receiver);
}

// ================================================================
// |                    Rate limit config                         |
// ================================================================

public fun set_chain_rate_limiter_configs<T>(
    state: &mut BurnMintTokenPoolState<T>,
    owner_cap: &OwnerCap,
    clock: &Clock,
    remote_chain_selectors: vector<u64>,
    outbound_is_enableds: vector<bool>,
    outbound_capacities: vector<u64>,
    outbound_rates: vector<u64>,
    inbound_is_enableds: vector<bool>,
    inbound_capacities: vector<u64>,
    inbound_rates: vector<u64>,
) {
    assert!(object::id(owner_cap) == ownable::owner_cap_id(&state.ownable_state), EInvalidOwnerCap);
    let number_of_chains = remote_chain_selectors.length();

    assert!(
        number_of_chains == outbound_is_enableds.length()
            && number_of_chains == outbound_capacities.length()
            && number_of_chains == outbound_rates.length()
            && number_of_chains == inbound_is_enableds.length()
            && number_of_chains == inbound_capacities.length()
            && number_of_chains == inbound_rates.length(),
        EInvalidArguments,
    );

    let mut i = 0;
    while (i < number_of_chains) {
        token_pool::set_chain_rate_limiter_config(
            clock,
            &mut state.token_pool_state,
            remote_chain_selectors[i],
            outbound_is_enableds[i],
            outbound_capacities[i],
            outbound_rates[i],
            inbound_is_enableds[i],
            inbound_capacities[i],
            inbound_rates[i],
        );
        i = i + 1;
    };
}

public fun set_chain_rate_limiter_config<T>(
    state: &mut BurnMintTokenPoolState<T>,
    owner_cap: &OwnerCap,
    clock: &Clock,
    remote_chain_selector: u64,
    outbound_is_enabled: bool,
    outbound_capacity: u64,
    outbound_rate: u64,
    inbound_is_enabled: bool,
    inbound_capacity: u64,
    inbound_rate: u64,
) {
    assert!(object::id(owner_cap) == ownable::owner_cap_id(&state.ownable_state), EInvalidOwnerCap);
    token_pool::set_chain_rate_limiter_config(
        clock,
        &mut state.token_pool_state,
        remote_chain_selector,
        outbound_is_enabled,
        outbound_capacity,
        outbound_rate,
        inbound_is_enabled,
        inbound_capacity,
        inbound_rate,
    );
}

public fun get_current_inbound_rate_limiter_state<T>(
    clock: &Clock,
    state: &BurnMintTokenPoolState<T>,
    remote_chain_selector: u64,
): TokenBucketWrapper {
    let token_bucket = token_pool::get_current_inbound_rate_limiter_state(
        &state.token_pool_state,
        clock,
        remote_chain_selector,
    );
    let (tokens, last_updated, is_enabled, capacity, rate) = rate_limiter::get_token_bucket_fields(
        &token_bucket,
    );
    TokenBucketWrapper { tokens, last_updated, is_enabled, capacity, rate }
}

public fun get_current_outbound_rate_limiter_state<T>(
    clock: &Clock,
    state: &BurnMintTokenPoolState<T>,
    remote_chain_selector: u64,
): TokenBucketWrapper {
    let token_bucket = token_pool::get_current_outbound_rate_limiter_state(
        &state.token_pool_state,
        clock,
        remote_chain_selector,
    );
    let (tokens, last_updated, is_enabled, capacity, rate) = rate_limiter::get_token_bucket_fields(
        &token_bucket,
    );
    TokenBucketWrapper { tokens, last_updated, is_enabled, capacity, rate }
}

// destroy the burn mint token pool state and the owner cap, return the treasury cap to the owner
// this should only be called after unregistering the pool from the token admin registry
public fun destroy_token_pool<T>(
    ref: &mut CCIPObjectRef,
    state: BurnMintTokenPoolState<T>,
    owner_cap: OwnerCap,
    ctx: &mut TxContext,
): TreasuryCap<T> {
    assert!(
        object::id(&owner_cap) == ownable::owner_cap_id(&state.ownable_state),
        EInvalidOwnerCap,
    );
    assert!(
        !token_admin_registry::is_pool_registered(ref, get_token(&state)),
        EPoolStillRegistered,
    );

    let BurnMintTokenPoolState<T> {
        id: state_id,
        token_pool_state,
        treasury_cap,
        ownable_state,
    } = state;
    token_pool::destroy_token_pool(token_pool_state);
    object::delete(state_id);

    ownable::destroy(ownable_state, owner_cap, ctx);

    treasury_cap
}

public fun mcms_destroy_token_pool<T>(
    ref: &mut CCIPObjectRef,
    state: BurnMintTokenPoolState<T>,
    registry: &mut Registry,
    params: ExecutingCallbackParams,
    ctx: &mut TxContext,
) {
    let (_owner_cap, function, data) = mcms_registry::get_callback_params_with_caps<
        McmsCallback<T>,
        OwnerCap,
    >(
        registry,
        McmsCallback<T> {},
        params,
    );
    assert!(function == string::utf8(b"destroy_token_pool"), EInvalidFunction);

    let mut stream = bcs_stream::new(data);
    bcs_stream::validate_obj_addrs(
        vector[object::id_address(ref), object::id_address(&state)],
        &mut stream,
    );

    let to = bcs_stream::deserialize_address(&mut stream);
    bcs_stream::assert_is_consumed(&stream);

    let owner_cap = mcms_registry::release_cap<McmsCallback<T>, OwnerCap>(
        registry,
        McmsCallback<T> {},
    );

    let treasury_cap = destroy_token_pool(ref, state, owner_cap, ctx);
    transfer::public_transfer(treasury_cap, to);
}

// ================================================================
// |                      Ownable Functions                       |
// ================================================================

public fun owner<T>(state: &BurnMintTokenPoolState<T>): address {
    ownable::owner(&state.ownable_state)
}

public fun has_pending_transfer<T>(state: &BurnMintTokenPoolState<T>): bool {
    ownable::has_pending_transfer(&state.ownable_state)
}

public fun pending_transfer_from<T>(state: &BurnMintTokenPoolState<T>): Option<address> {
    ownable::pending_transfer_from(&state.ownable_state)
}

public fun pending_transfer_to<T>(state: &BurnMintTokenPoolState<T>): Option<address> {
    ownable::pending_transfer_to(&state.ownable_state)
}

public fun pending_transfer_accepted<T>(state: &BurnMintTokenPoolState<T>): Option<bool> {
    ownable::pending_transfer_accepted(&state.ownable_state)
}

public fun transfer_ownership<T>(
    state: &mut BurnMintTokenPoolState<T>,
    owner_cap: &OwnerCap,
    new_owner: address,
    ctx: &mut TxContext,
) {
    ownable::transfer_ownership(owner_cap, &mut state.ownable_state, new_owner, ctx);
}

public fun accept_ownership<T>(state: &mut BurnMintTokenPoolState<T>, ctx: &mut TxContext) {
    ownable::accept_ownership(&mut state.ownable_state, ctx);
}

public fun accept_ownership_from_object<T>(
    state: &mut BurnMintTokenPoolState<T>,
    from: &mut UID,
    ctx: &mut TxContext,
) {
    ownable::accept_ownership_from_object(&mut state.ownable_state, from, ctx);
}

public fun mcms_accept_ownership<T>(
    state: &mut BurnMintTokenPoolState<T>,
    registry: &mut Registry,
    params: ExecutingCallbackParams,
    ctx: &mut TxContext,
) {
    let data = mcms_registry::get_accept_ownership_data(
        registry,
        params,
        McmsAcceptOwnershipProof<T> {},
    );

    let mut stream = bcs_stream::new(data);
    bcs_stream::validate_obj_addr(object::id_address(state), &mut stream);
    bcs_stream::assert_is_consumed(&stream);

    let mcms = mcms_registry::get_multisig_address();
    ownable::mcms_accept_ownership(&mut state.ownable_state, mcms, ctx);
}

public fun execute_ownership_transfer<T>(
    owner_cap: OwnerCap,
    state: &mut BurnMintTokenPoolState<T>,
    to: address,
    ctx: &mut TxContext,
) {
    ownable::execute_ownership_transfer(owner_cap, &mut state.ownable_state, to, ctx);
}

public fun execute_ownership_transfer_to_mcms<T>(
    owner_cap: OwnerCap,
    state: &mut BurnMintTokenPoolState<T>,
    registry: &mut Registry,
    to: address,
    ctx: &mut TxContext,
) {
    let publisher_wrapper = mcms_registry::create_publisher_wrapper(
        ownable::borrow_publisher(&owner_cap),
        McmsCallback<T> {},
    );

    ownable::execute_ownership_transfer_to_mcms(
        owner_cap,
        &mut state.ownable_state,
        registry,
        to,
        publisher_wrapper,
        McmsCallback<T> {},
        vector[b"malicious_token_pool"],
        ctx,
    );
}

public fun mcms_register_upgrade_cap(
    upgrade_cap: UpgradeCap,
    registry: &mut Registry,
    state: &mut DeployerState,
    ctx: &mut TxContext,
) {
    mcms_deployer::register_upgrade_cap(
        state,
        registry,
        upgrade_cap,
        ctx,
    );
}

// ================================================================
// |                      MCMS Entrypoint                         |
// ================================================================

public struct McmsCallback<phantom T> has drop {}

/// Proof for MCMS Accept Ownership
public struct McmsAcceptOwnershipProof<phantom T> has drop {}

public fun mcms_set_allowlist_enabled<T>(
    state: &mut BurnMintTokenPoolState<T>,
    registry: &mut Registry,
    params: ExecutingCallbackParams,
) {
    let (owner_cap, function, data) = mcms_registry::get_callback_params_with_caps<
        McmsCallback<T>,
        OwnerCap,
    >(
        registry,
        McmsCallback<T> {},
        params,
    );
    assert!(function == string::utf8(b"set_allowlist_enabled"), EInvalidFunction);

    let mut stream = bcs_stream::new(data);
    bcs_stream::validate_obj_addrs(
        vector[object::id_address(state), object::id_address(owner_cap)],
        &mut stream,
    );
    let enabled = bcs_stream::deserialize_bool(&mut stream);
    bcs_stream::assert_is_consumed(&stream);

    set_allowlist_enabled(state, owner_cap, enabled);
}

public fun mcms_apply_allowlist_updates<T>(
    state: &mut BurnMintTokenPoolState<T>,
    registry: &mut Registry,
    params: ExecutingCallbackParams,
) {
    let (owner_cap, function, data) = mcms_registry::get_callback_params_with_caps<
        McmsCallback<T>,
        OwnerCap,
    >(
        registry,
        McmsCallback<T> {},
        params,
    );
    assert!(function == string::utf8(b"apply_allowlist_updates"), EInvalidFunction);

    let mut stream = bcs_stream::new(data);
    bcs_stream::validate_obj_addrs(
        vector[object::id_address(state), object::id_address(owner_cap)],
        &mut stream,
    );

    let removes = bcs_stream::deserialize_vector!(
        &mut stream,
        |stream| bcs_stream::deserialize_address(stream),
    );
    let adds = bcs_stream::deserialize_vector!(
        &mut stream,
        |stream| bcs_stream::deserialize_address(stream),
    );
    bcs_stream::assert_is_consumed(&stream);

    apply_allowlist_updates(state, owner_cap, removes, adds);
}

public fun mcms_apply_chain_updates<T>(
    state: &mut BurnMintTokenPoolState<T>,
    registry: &mut Registry,
    params: ExecutingCallbackParams,
) {
    let (owner_cap, function, data) = mcms_registry::get_callback_params_with_caps<
        McmsCallback<T>,
        OwnerCap,
    >(
        registry,
        McmsCallback<T> {},
        params,
    );
    assert!(function == string::utf8(b"apply_chain_updates"), EInvalidFunction);

    let mut stream = bcs_stream::new(data);
    bcs_stream::validate_obj_addrs(
        vector[object::id_address(state), object::id_address(owner_cap)],
        &mut stream,
    );

    let remote_chain_selectors_to_remove = bcs_stream::deserialize_vector!(
        &mut stream,
        |stream| bcs_stream::deserialize_u64(stream),
    );
    let remote_chain_selectors_to_add = bcs_stream::deserialize_vector!(
        &mut stream,
        |stream| bcs_stream::deserialize_u64(stream),
    );
    let remote_pool_addresses_to_add = bcs_stream::deserialize_vector!(
        &mut stream,
        |stream| bcs_stream::deserialize_vector!(
            stream,
            |stream| bcs_stream::deserialize_vector_u8(stream),
        ),
    );
    let remote_token_addresses_to_add = bcs_stream::deserialize_vector!(
        &mut stream,
        |stream| bcs_stream::deserialize_vector_u8(stream),
    );
    bcs_stream::assert_is_consumed(&stream);

    apply_chain_updates(
        state,
        owner_cap,
        remote_chain_selectors_to_remove,
        remote_chain_selectors_to_add,
        remote_pool_addresses_to_add,
        remote_token_addresses_to_add,
    );
}

public fun mcms_add_remote_pool<T>(
    state: &mut BurnMintTokenPoolState<T>,
    registry: &mut Registry,
    params: ExecutingCallbackParams,
) {
    let (owner_cap, function, data) = mcms_registry::get_callback_params_with_caps<
        McmsCallback<T>,
        OwnerCap,
    >(
        registry,
        McmsCallback<T> {},
        params,
    );
    assert!(function == string::utf8(b"add_remote_pool"), EInvalidFunction);

    let mut stream = bcs_stream::new(data);
    bcs_stream::validate_obj_addrs(
        vector[object::id_address(state), object::id_address(owner_cap)],
        &mut stream,
    );
    let remote_chain_selector = bcs_stream::deserialize_u64(&mut stream);
    let remote_pool_address = bcs_stream::deserialize_vector_u8(&mut stream);
    bcs_stream::assert_is_consumed(&stream);

    add_remote_pool(state, owner_cap, remote_chain_selector, remote_pool_address);
}

public fun mcms_remove_remote_pool<T>(
    state: &mut BurnMintTokenPoolState<T>,
    registry: &mut Registry,
    params: ExecutingCallbackParams,
) {
    let (owner_cap, function, data) = mcms_registry::get_callback_params_with_caps<
        McmsCallback<T>,
        OwnerCap,
    >(
        registry,
        McmsCallback<T> {},
        params,
    );
    assert!(function == string::utf8(b"remove_remote_pool"), EInvalidFunction);

    let mut stream = bcs_stream::new(data);
    bcs_stream::validate_obj_addrs(
        vector[object::id_address(state), object::id_address(owner_cap)],
        &mut stream,
    );
    let remote_chain_selector = bcs_stream::deserialize_u64(&mut stream);
    let remote_pool_address = bcs_stream::deserialize_vector_u8(&mut stream);
    bcs_stream::assert_is_consumed(&stream);

    remove_remote_pool(state, owner_cap, remote_chain_selector, remote_pool_address);
}

public fun mcms_set_chain_rate_limiter_configs<T>(
    state: &mut BurnMintTokenPoolState<T>,
    registry: &mut Registry,
    params: ExecutingCallbackParams,
    clock: &Clock,
) {
    let (owner_cap, function, data) = mcms_registry::get_callback_params_with_caps<
        McmsCallback<T>,
        OwnerCap,
    >(
        registry,
        McmsCallback<T> {},
        params,
    );
    assert!(function == string::utf8(b"set_chain_rate_limiter_configs"), EInvalidFunction);

    let mut stream = bcs_stream::new(data);
    bcs_stream::validate_obj_addrs(
        vector[object::id_address(state), object::id_address(owner_cap), object::id_address(clock)],
        &mut stream,
    );

    let remote_chain_selectors = bcs_stream::deserialize_vector!(
        &mut stream,
        |stream| bcs_stream::deserialize_u64(stream),
    );
    let outbound_is_enableds = bcs_stream::deserialize_vector!(
        &mut stream,
        |stream| bcs_stream::deserialize_bool(stream),
    );
    let outbound_capacities = bcs_stream::deserialize_vector!(
        &mut stream,
        |stream| bcs_stream::deserialize_u64(stream),
    );
    let outbound_rates = bcs_stream::deserialize_vector!(
        &mut stream,
        |stream| bcs_stream::deserialize_u64(stream),
    );
    let inbound_is_enableds = bcs_stream::deserialize_vector!(
        &mut stream,
        |stream| bcs_stream::deserialize_bool(stream),
    );
    let inbound_capacities = bcs_stream::deserialize_vector!(
        &mut stream,
        |stream| bcs_stream::deserialize_u64(stream),
    );
    let inbound_rates = bcs_stream::deserialize_vector!(
        &mut stream,
        |stream| bcs_stream::deserialize_u64(stream),
    );
    bcs_stream::assert_is_consumed(&stream);

    set_chain_rate_limiter_configs(
        state,
        owner_cap,
        clock,
        remote_chain_selectors,
        outbound_is_enableds,
        outbound_capacities,
        outbound_rates,
        inbound_is_enableds,
        inbound_capacities,
        inbound_rates,
    );
}

public fun mcms_set_chain_rate_limiter_config<T>(
    state: &mut BurnMintTokenPoolState<T>,
    registry: &mut Registry,
    params: ExecutingCallbackParams,
    clock: &Clock,
) {
    let (owner_cap, function, data) = mcms_registry::get_callback_params_with_caps<
        McmsCallback<T>,
        OwnerCap,
    >(
        registry,
        McmsCallback<T> {},
        params,
    );
    assert!(function == string::utf8(b"set_chain_rate_limiter_config"), EInvalidFunction);

    let mut stream = bcs_stream::new(data);
    bcs_stream::validate_obj_addrs(
        vector[object::id_address(state), object::id_address(owner_cap), object::id_address(clock)],
        &mut stream,
    );
    let remote_chain_selector = bcs_stream::deserialize_u64(&mut stream);
    let outbound_is_enabled = bcs_stream::deserialize_bool(&mut stream);
    let outbound_capacity = bcs_stream::deserialize_u64(&mut stream);
    let outbound_rate = bcs_stream::deserialize_u64(&mut stream);
    let inbound_is_enabled = bcs_stream::deserialize_bool(&mut stream);
    let inbound_capacity = bcs_stream::deserialize_u64(&mut stream);
    let inbound_rate = bcs_stream::deserialize_u64(&mut stream);
    bcs_stream::assert_is_consumed(&stream);

    set_chain_rate_limiter_config(
        state,
        owner_cap,
        clock,
        remote_chain_selector,
        outbound_is_enabled,
        outbound_capacity,
        outbound_rate,
        inbound_is_enabled,
        inbound_capacity,
        inbound_rate,
    );
}

public fun mcms_transfer_ownership<T>(
    state: &mut BurnMintTokenPoolState<T>,
    registry: &mut Registry,
    params: ExecutingCallbackParams,
    ctx: &mut TxContext,
) {
    let (owner_cap, function, data) = mcms_registry::get_callback_params_with_caps<
        McmsCallback<T>,
        OwnerCap,
    >(
        registry,
        McmsCallback<T> {},
        params,
    );
    assert!(function == string::utf8(b"transfer_ownership"), EInvalidFunction);

    let mut stream = bcs_stream::new(data);
    bcs_stream::validate_obj_addrs(
        vector[object::id_address(state), object::id_address(owner_cap)],
        &mut stream,
    );

    let to = bcs_stream::deserialize_address(&mut stream);
    bcs_stream::assert_is_consumed(&stream);

    transfer_ownership(state, owner_cap, to, ctx);
}

public fun mcms_execute_ownership_transfer<T>(
    state: &mut BurnMintTokenPoolState<T>,
    registry: &mut Registry,
    deployer_state: &mut DeployerState,
    params: ExecutingCallbackParams,
    ctx: &mut TxContext,
) {
    let (_owner_cap, function, data) = mcms_registry::get_callback_params_with_caps<
        McmsCallback<T>,
        OwnerCap,
    >(
        registry,
        McmsCallback<T> {},
        params,
    );
    assert!(function == string::utf8(b"execute_ownership_transfer"), EInvalidFunction);

    let mut stream = bcs_stream::new(data);
    bcs_stream::validate_obj_addrs(
        vector[object::id_address(_owner_cap), object::id_address(state)],
        &mut stream,
    );

    let to = bcs_stream::deserialize_address(&mut stream);
    let package_address = bcs_stream::deserialize_address(&mut stream);
    bcs_stream::assert_is_consumed(&stream);

    // Release the upgrade cap before `release_cap`, which removes the registry proof state
    // that `release_upgrade_cap` depends on.
    if (mcms_deployer::has_upgrade_cap(deployer_state, package_address)) {
        let upgrade_cap = mcms_deployer::release_upgrade_cap(
            deployer_state,
            registry,
            McmsCallback<T> {},
        );
        transfer::public_transfer(upgrade_cap, to);
    };

    let owner_cap = mcms_registry::release_cap<McmsCallback<T>, OwnerCap>(
        registry,
        McmsCallback<T> {},
    );

    execute_ownership_transfer(owner_cap, state, to, ctx);
}

public fun mcms_add_allowed_modules<T>(
    registry: &mut Registry,
    params: ExecutingCallbackParams,
    ctx: &mut TxContext,
) {
    let (_owner_cap, function, data) = mcms_registry::get_callback_params_with_caps<
        McmsCallback<T>,
        OwnerCap,
    >(
        registry,
        McmsCallback<T> {},
        params,
    );
    assert!(function == string::utf8(b"add_allowed_modules"), EInvalidFunction);

    let mut stream = bcs_stream::new(data);
    bcs_stream::validate_obj_addr(object::id_address(registry), &mut stream);

    let new_module_names = bcs_stream::deserialize_vector!(
        &mut stream,
        |stream| bcs_stream::deserialize_vector_u8(stream),
    );
    bcs_stream::assert_is_consumed(&stream);

    mcms_registry::add_allowed_modules(registry, McmsCallback<T> {}, new_module_names, ctx);
}

public fun mcms_remove_allowed_modules<T>(
    registry: &mut Registry,
    params: ExecutingCallbackParams,
    ctx: &mut TxContext,
) {
    let (_owner_cap, function, data) = mcms_registry::get_callback_params_with_caps<
        McmsCallback<T>,
        OwnerCap,
    >(
        registry,
        McmsCallback<T> {},
        params,
    );
    assert!(function == string::utf8(b"remove_allowed_modules"), EInvalidFunction);

    let mut stream = bcs_stream::new(data);
    bcs_stream::validate_obj_addr(object::id_address(registry), &mut stream);

    let module_names = bcs_stream::deserialize_vector!(
        &mut stream,
        |stream| bcs_stream::deserialize_vector_u8(stream),
    );
    bcs_stream::assert_is_consumed(&stream);

    mcms_registry::remove_allowed_modules(registry, McmsCallback<T> {}, module_names, ctx);
}

#[test_only]
public fun test_init(ctx: &mut TxContext) {
    init(MALICIOUS_TOKEN_POOL {}, ctx);
}
