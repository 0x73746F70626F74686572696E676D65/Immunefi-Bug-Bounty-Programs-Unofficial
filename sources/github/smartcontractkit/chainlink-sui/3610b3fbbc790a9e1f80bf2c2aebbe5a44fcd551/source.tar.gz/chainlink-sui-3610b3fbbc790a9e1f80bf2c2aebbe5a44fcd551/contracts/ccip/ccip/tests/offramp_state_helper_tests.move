#[test_only]
module ccip::offramp_state_helper_tests;

use ccip::client;
use ccip::offramp_state_helper::{Self, DestTransferCap};
use ccip::ownable::OwnerCap;
use ccip::publisher_wrapper;
use ccip::receiver_registry;
use ccip::state_object::{Self, CCIPObjectRef};
use ccip::token_admin_registry as registry;
use ccip::upgrade_registry;
use std::ascii;
use std::string;
use std::type_name;
use sui::coin;
use sui::package;
use sui::test_scenario::{Self as ts, Scenario};

public struct OFFRAMP_STATE_HELPER_TESTS has drop {}

public struct TestTypeProof has drop {}
public struct TestToken has drop {}

const OWNER: address = @0x1000;
const RECEIVER_ADDRESS: address = @0x2000;
const TOKEN_ADDRESS_1: address =
    @0x1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b;
const TOKEN_POOL_ADDRESS_1: address =
    @0xdeeb7a4662eec9f2f3def03fb937a663dddaa2e215b8078a284d026b7946c270;
const SOURCE_CHAIN_SELECTOR: u64 = 1000;
const SOURCE_AMOUNT_18_DEC: u256 = 1_000_000_000_000_000_000;

fun setup_test(): (Scenario, OwnerCap, CCIPObjectRef, DestTransferCap) {
    let mut scenario = ts::begin(OWNER);
    let ctx = scenario.ctx();

    state_object::test_init(ctx);

    // Advance to next transaction to retrieve the created objects
    scenario.next_tx(OWNER);

    // Retrieve the OwnerCap that was transferred to the sender
    let owner_cap = scenario.take_from_sender<OwnerCap>();

    // Retrieve the shared CCIPObjectRef
    let mut ref = scenario.take_shared<CCIPObjectRef>();

    upgrade_registry::initialize(&mut ref, &owner_cap, scenario.ctx());

    // Initialize token admin registry
    registry::initialize(&mut ref, &owner_cap, scenario.ctx());
    registry::initialize_local_decimals(&mut ref, &owner_cap, scenario.ctx());

    // Initialize receiver registry
    receiver_registry::initialize(&mut ref, &owner_cap, scenario.ctx());

    // Create offramp state helper and get dest transfer cap
    offramp_state_helper::test_init(scenario.ctx());

    scenario.next_tx(OWNER);
    let dest_cap = scenario.take_from_sender<DestTransferCap>();

    (scenario, owner_cap, ref, dest_cap)
}

fun cleanup_test(
    scenario: Scenario,
    owner_cap: OwnerCap,
    ref: CCIPObjectRef,
    dest_cap: DestTransferCap,
) {
    // Return the owner cap back to the sender instead of destroying it
    ts::return_to_sender(&scenario, owner_cap);
    // Return the shared object back to the scenario instead of destroying it
    ts::return_shared(ref);
    transfer::public_transfer(dest_cap, @0x0);
    ts::end(scenario);
}

#[test]
public fun test_create_receiver_params() {
    let (scenario, owner_cap, ref, dest_cap) = setup_test();

    // Test creating receiver params
    let receiver_params = offramp_state_helper::create_receiver_params(
        &dest_cap,
        SOURCE_CHAIN_SELECTOR,
    );
    let source_chain = offramp_state_helper::get_source_chain_selector(&receiver_params);
    assert!(source_chain == SOURCE_CHAIN_SELECTOR);

    // Clean up
    offramp_state_helper::deconstruct_receiver_params(&dest_cap, receiver_params);

    cleanup_test(scenario, owner_cap, ref, dest_cap);
}

#[test]
public fun test_get_source_chain_selector() {
    let (scenario, owner_cap, ref, dest_cap) = setup_test();

    let different_chain = 2000;
    let receiver_params = offramp_state_helper::create_receiver_params(&dest_cap, different_chain);
    let source_chain = offramp_state_helper::get_source_chain_selector(&receiver_params);
    assert!(source_chain == different_chain);

    offramp_state_helper::deconstruct_receiver_params(&dest_cap, receiver_params);
    cleanup_test(scenario, owner_cap, ref, dest_cap);
}

#[test]
public fun test_add_dest_token_transfer() {
    let (scenario, owner_cap, ref, dest_cap) = setup_test();

    let mut receiver_params = offramp_state_helper::create_receiver_params(
        &dest_cap,
        SOURCE_CHAIN_SELECTOR,
    );

    // Add a destination token transfer
    offramp_state_helper::add_dest_token_transfer(
        &dest_cap,
        &mut receiver_params,
        RECEIVER_ADDRESS,
        SOURCE_CHAIN_SELECTOR, // remote_chain_selector
        1000, // source_amount
        TOKEN_ADDRESS_1,
        TOKEN_POOL_ADDRESS_1,
        b"source_pool_address",
        b"source_pool_data",
        b"offchain_data",
    );

    // Verify the token transfer was added
    let (
        receiver,
        source_amount,
        dest_token_address,
        source_pool_address,
        source_pool_data,
        offchain_data,
    ) = offramp_state_helper::get_token_param_data(&receiver_params);

    assert!(receiver == RECEIVER_ADDRESS);
    assert!(source_amount == 1000);
    assert!(dest_token_address == TOKEN_ADDRESS_1);
    assert!(source_pool_address == b"source_pool_address");
    assert!(source_pool_data == b"source_pool_data");
    assert!(offchain_data == b"offchain_data");

    // This will fail but we need to call it to consume receiver_params
    offramp_state_helper::deconstruct_receiver_params_with_message_for_test(
        &dest_cap,
        @0x0,
        receiver_params,
    );

    cleanup_test(scenario, owner_cap, ref, dest_cap);
}

#[test]
public fun test_populate_message() {
    let (scenario, owner_cap, ref, dest_cap) = setup_test();

    let mut receiver_params = offramp_state_helper::create_receiver_params(
        &dest_cap,
        SOURCE_CHAIN_SELECTOR,
    );

    // Create a test message
    let test_message = client::new_any2sui_message(
        b"message_id_32_bytes_long_test_msg",
        SOURCE_CHAIN_SELECTOR,
        b"sender_address",
        b"test_data",
        @0x5432,
        @0x12345,
        vector[], // token_amounts
    );

    // Populate the message
    offramp_state_helper::populate_message(&dest_cap, &mut receiver_params, test_message);

    // We need to consume the receiver_params with a message
    // Use the new test function that can handle populated messages
    offramp_state_helper::deconstruct_receiver_params_with_message_for_test(
        &dest_cap,
        @0x5432,
        receiver_params,
    );

    cleanup_test(scenario, owner_cap, ref, dest_cap);
}

#[test]
public fun test_complete_token_transfer() {
    let (mut scenario, owner_cap, mut ref, dest_cap) = setup_test();

    // Register a token in the token admin registry
    registry::register_pool_as_owner_v2(
        &owner_cap,
        &mut ref,
        TOKEN_ADDRESS_1,
        TOKEN_POOL_ADDRESS_1,
        string::utf8(b"test_pool"),
        ascii::string(b"TestType"),
        OWNER,
        type_name::into_string(type_name::with_defining_ids<TestTypeProof>()),
        vector<address>[], // lock_or_burn_params
        vector<address>[], // release_or_mint_params
        9, // local_decimals
        scenario.ctx(),
    );

    let mut receiver_params = offramp_state_helper::create_receiver_params(
        &dest_cap,
        SOURCE_CHAIN_SELECTOR,
    );

    // Add a destination token transfer
    offramp_state_helper::add_dest_token_transfer(
        &dest_cap,
        &mut receiver_params,
        RECEIVER_ADDRESS,
        SOURCE_CHAIN_SELECTOR, // remote_chain_selector
        1000,
        TOKEN_ADDRESS_1,
        TOKEN_POOL_ADDRESS_1,
        b"source_pool_address",
        b"source_pool_data",
        b"offchain_data",
    );

    // Create a test coin to transfer
    let test_coin = coin::mint_for_testing<TestToken>(500, scenario.ctx());

    // Complete the token transfer
    offramp_state_helper::complete_token_transfer(
        &ref,
        &mut receiver_params,
        TestTypeProof {},
    );

    // Destroy the unused test_coin
    coin::burn_for_testing(test_coin);

    // Clean up - the receiver_params should have completed transfers
    offramp_state_helper::deconstruct_receiver_params(&dest_cap, receiver_params);

    cleanup_test(scenario, owner_cap, ref, dest_cap);
}

#[test]
public fun test_extract_any2sui_message() {
    let (mut scenario, owner_cap, mut ref, dest_cap) = setup_test();

    // Register a receiver
    let publisher = package::test_claim(OFFRAMP_STATE_HELPER_TESTS {}, scenario.ctx());
    let publisher_wrapper = publisher_wrapper::create(&publisher, TestTypeProof {});
    receiver_registry::register_receiver(
        &mut ref,
        publisher_wrapper,
        TestTypeProof {},
    );
    package::burn_publisher(publisher);

    let mut receiver_params = offramp_state_helper::create_receiver_params(
        &dest_cap,
        SOURCE_CHAIN_SELECTOR,
    );

    // Create and populate a message
    let test_message = client::new_any2sui_message(
        b"message_id_32_bytes_long_test_msg",
        SOURCE_CHAIN_SELECTOR,
        b"sender_address",
        b"test_data",
        @0x5432,
        @0x12345,
        vector[],
    );
    offramp_state_helper::populate_message(&dest_cap, &mut receiver_params, test_message);

    // Since we can't destructure ReceiverParams outside its module, we'll just test that
    // the message was populated by trying to consume it via the offramp helper
    // Use the new test function that can handle populated messages
    offramp_state_helper::deconstruct_receiver_params_with_message_for_test(
        &dest_cap,
        @0x5432,
        receiver_params,
    );

    cleanup_test(scenario, owner_cap, ref, dest_cap);
}

#[test]
public fun test_deconstruct_receiver_params_empty() {
    let (scenario, owner_cap, ref, dest_cap) = setup_test();

    // Create empty receiver params
    let receiver_params = offramp_state_helper::create_receiver_params(
        &dest_cap,
        SOURCE_CHAIN_SELECTOR,
    );

    // Should succeed with no token transfers and no message
    offramp_state_helper::deconstruct_receiver_params(&dest_cap, receiver_params);

    cleanup_test(scenario, owner_cap, ref, dest_cap);
}

#[test]
#[expected_failure(abort_code = offramp_state_helper::ETokenTransferAlreadyExists)]
public fun test_add_multiple_dest_token_transfers_should_fail() {
    let (scenario, owner_cap, ref, dest_cap) = setup_test();

    let mut receiver_params = offramp_state_helper::create_receiver_params(
        &dest_cap,
        SOURCE_CHAIN_SELECTOR,
    );

    // Add first token transfer
    offramp_state_helper::add_dest_token_transfer(
        &dest_cap,
        &mut receiver_params,
        RECEIVER_ADDRESS,
        SOURCE_CHAIN_SELECTOR,
        1000,
        TOKEN_ADDRESS_1,
        TOKEN_POOL_ADDRESS_1,
        b"source_pool_1",
        b"pool_data_1",
        b"offchain_1",
    );

    // This should fail with ETokenTransferAlreadyExists because only one token transfer is allowed
    offramp_state_helper::add_dest_token_transfer(
        &dest_cap,
        &mut receiver_params,
        RECEIVER_ADDRESS,
        SOURCE_CHAIN_SELECTOR,
        2000,
        TOKEN_ADDRESS_1,
        TOKEN_POOL_ADDRESS_1,
        b"source_pool_2",
        b"pool_data_2",
        b"offchain_2",
    );

    // The following code won't be reached due to the expected failure above
    offramp_state_helper::deconstruct_receiver_params_with_message_for_test(
        &dest_cap,
        @0x5432,
        receiver_params,
    );
    cleanup_test(scenario, owner_cap, ref, dest_cap);
}

#[test]
#[expected_failure(abort_code = offramp_state_helper::ETokenTransferDoesNotExist)]
public fun test_get_token_param_data_when_empty() {
    let (scenario, owner_cap, ref, dest_cap) = setup_test();

    // Create empty receiver params (no token transfer added)
    let receiver_params = offramp_state_helper::create_receiver_params(
        &dest_cap,
        SOURCE_CHAIN_SELECTOR,
    );

    // This should fail with ETokenTransferDoesNotExist because no token transfer was added
    let (
        _receiver,
        _source_amount,
        _dest_token_address,
        _source_pool_address,
        _source_pool_data,
        _offchain_data,
    ) = offramp_state_helper::get_token_param_data(&receiver_params);

    // The following code won't be reached due to the expected failure above
    offramp_state_helper::deconstruct_receiver_params(&dest_cap, receiver_params);
    cleanup_test(scenario, owner_cap, ref, dest_cap);
}

#[test]
#[expected_failure(abort_code = offramp_state_helper::ETokenTransferAlreadyCompleted)]
public fun test_complete_token_transfer_twice_should_fail() {
    let (mut scenario, owner_cap, mut ref, dest_cap) = setup_test();

    // Register a token in the token admin registry
    registry::register_pool_as_owner_v2(
        &owner_cap,
        &mut ref,
        TOKEN_ADDRESS_1,
        TOKEN_POOL_ADDRESS_1,
        string::utf8(b"test_pool"),
        ascii::string(b"TestType"),
        OWNER,
        type_name::into_string(type_name::with_defining_ids<TestTypeProof>()),
        vector<address>[], // lock_or_burn_params
        vector<address>[], // release_or_mint_params
        9, // local_decimals
        scenario.ctx(),
    );

    let mut receiver_params = offramp_state_helper::create_receiver_params(
        &dest_cap,
        SOURCE_CHAIN_SELECTOR,
    );

    // Add a destination token transfer
    offramp_state_helper::add_dest_token_transfer(
        &dest_cap,
        &mut receiver_params,
        RECEIVER_ADDRESS,
        SOURCE_CHAIN_SELECTOR,
        1000,
        TOKEN_ADDRESS_1,
        TOKEN_POOL_ADDRESS_1,
        b"source_pool_address",
        b"source_pool_data",
        b"offchain_data",
    );

    // Complete the token transfer first time (should succeed)
    offramp_state_helper::complete_token_transfer(
        &ref,
        &mut receiver_params,
        TestTypeProof {},
    );

    // This should fail with ETokenTransferAlreadyCompleted because transfer is already completed
    offramp_state_helper::complete_token_transfer(
        &ref,
        &mut receiver_params,
        TestTypeProof {},
    );

    // The following code won't be reached due to the expected failure above
    offramp_state_helper::deconstruct_receiver_params(&dest_cap, receiver_params);
    cleanup_test(scenario, owner_cap, ref, dest_cap);
}

fun populate_token_message_receiver_params(
    dest_cap: &DestTransferCap,
    receiver_params: &mut offramp_state_helper::ReceiverParams,
) {
    // ABI-encoded u256(18) = remote decimals
    let source_pool_data =
        x"0000000000000000000000000000000000000000000000000000000000000012";

    offramp_state_helper::add_dest_token_transfer(
        dest_cap,
        receiver_params,
        RECEIVER_ADDRESS,
        SOURCE_CHAIN_SELECTOR,
        SOURCE_AMOUNT_18_DEC,
        TOKEN_ADDRESS_1,
        TOKEN_POOL_ADDRESS_1,
        b"source_pool_address",
        source_pool_data,
        b"offchain_data",
    );

    let dest_token_amounts = client::new_dest_token_amounts(
        vector[TOKEN_ADDRESS_1],
        vector[SOURCE_AMOUNT_18_DEC],
    );
    let test_message = client::new_any2sui_message(
        b"message_id_32_bytes_long_test_msg",
        SOURCE_CHAIN_SELECTOR,
        b"sender_address",
        b"test_data",
        @0x5432,
        @0x12345,
        dest_token_amounts,
    );
    offramp_state_helper::populate_message(dest_cap, receiver_params, test_message);
}

#[test]
#[expected_failure(abort_code = offramp_state_helper::ETokenTransferNotCompleted)]
public fun test_extract_before_complete_on_token_message_path() {
    let (scenario, owner_cap, ref, dest_cap) = setup_test();

    let mut receiver_params = offramp_state_helper::create_receiver_params(
        &dest_cap,
        SOURCE_CHAIN_SELECTOR,
    );
    populate_token_message_receiver_params(&dest_cap, &mut receiver_params);

    let message = offramp_state_helper::extract_any2sui_message(&mut receiver_params);
    client::consume_any2sui_message(message, @0x5432);

    offramp_state_helper::deconstruct_receiver_params(&dest_cap, receiver_params);
    cleanup_test(scenario, owner_cap, ref, dest_cap);
}

#[test]
public fun test_message_only_extract_unaffected_by_guard() {
    let (scenario, owner_cap, ref, dest_cap) = setup_test();

    let mut receiver_params = offramp_state_helper::create_receiver_params(
        &dest_cap,
        SOURCE_CHAIN_SELECTOR,
    );

    let test_message = client::new_any2sui_message(
        b"message_id_32_bytes_long_test_msg",
        SOURCE_CHAIN_SELECTOR,
        b"sender_address",
        b"test_data",
        @0x5432,
        @0x12345,
        vector[],
    );
    offramp_state_helper::populate_message(&dest_cap, &mut receiver_params, test_message);

    let message = offramp_state_helper::extract_any2sui_message(&mut receiver_params);
    client::consume_any2sui_message(message, @0x5432);

    offramp_state_helper::deconstruct_receiver_params(&dest_cap, receiver_params);
    cleanup_test(scenario, owner_cap, ref, dest_cap);
}

#[test]
public fun test_extract_token_message_after_complete_succeeds() {
    let (mut scenario, owner_cap, mut ref, dest_cap) = setup_test();

    registry::register_pool_as_owner_v2(
        &owner_cap,
        &mut ref,
        TOKEN_ADDRESS_1,
        TOKEN_POOL_ADDRESS_1,
        string::utf8(b"test_pool"),
        ascii::string(b"TestType"),
        OWNER,
        type_name::into_string(type_name::with_defining_ids<TestTypeProof>()),
        vector<address>[],
        vector<address>[],
        9, // local_decimals
        scenario.ctx(),
    );

    let mut receiver_params = offramp_state_helper::create_receiver_params(
        &dest_cap,
        SOURCE_CHAIN_SELECTOR,
    );
    populate_token_message_receiver_params(&dest_cap, &mut receiver_params);

    offramp_state_helper::complete_token_transfer(
        &ref,
        &mut receiver_params,
        TestTypeProof {},
    );

    let message = offramp_state_helper::extract_any2sui_message(&mut receiver_params);
    let (_, _, _, _, _, _, dest_token_amounts) = client::consume_any2sui_message(message, @0x5432);
    // After fix: amount is recomputed from 18-dec to 9-dec
    assert!(client::get_amount(&dest_token_amounts[0]) == 1_000_000_000);

    offramp_state_helper::deconstruct_receiver_params(&dest_cap, receiver_params);
    cleanup_test(scenario, owner_cap, ref, dest_cap);
}

#[test]
public fun test_new_dest_transfer_cap() {
    let (mut scenario, owner_cap, ref, dest_cap) = setup_test();

    // Create a new DestTransferCap using the new_dest_transfer_cap function
    let new_dest_cap = offramp_state_helper::new_dest_transfer_cap(
        &ref,
        &owner_cap,
        scenario.ctx(),
    );

    // Use the new DestTransferCap to create receiver params
    let mut receiver_params = offramp_state_helper::create_receiver_params(
        &new_dest_cap,
        SOURCE_CHAIN_SELECTOR,
    );

    // Use the new cap to add a token transfer
    offramp_state_helper::add_dest_token_transfer(
        &new_dest_cap,
        &mut receiver_params,
        RECEIVER_ADDRESS,
        SOURCE_CHAIN_SELECTOR,
        5000, // source_amount
        TOKEN_ADDRESS_1,
        TOKEN_POOL_ADDRESS_1,
        b"new_source_pool",
        b"new_pool_data",
        b"new_offchain_data",
    );

    // Verify the token transfer data
    let (
        receiver,
        source_amount,
        dest_token_address,
        source_pool_address,
        source_pool_data,
        offchain_data,
    ) = offramp_state_helper::get_token_param_data(&receiver_params);

    assert!(receiver == RECEIVER_ADDRESS);
    assert!(source_amount == 5000);
    assert!(dest_token_address == TOKEN_ADDRESS_1);
    assert!(source_pool_address == b"new_source_pool");
    assert!(source_pool_data == b"new_pool_data");
    assert!(offchain_data == b"new_offchain_data");

    // Clean up with the new cap
    offramp_state_helper::deconstruct_receiver_params_with_message_for_test(
        &new_dest_cap,
        @0x5432,
        receiver_params,
    );

    // Transfer both caps to address 0x0 for cleanup
    transfer::public_transfer(new_dest_cap, @0x0);
    cleanup_test(scenario, owner_cap, ref, dest_cap);
}
