import React from 'react'

import { gql } from '@apollo/client'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { prism } from 'react-syntax-highlighter/dist/esm/styles/prism'

import Button from '@mui/material/Button'
import Chip from '@mui/material/Chip'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import Accordion from '@mui/material/Accordion'
import AccordionSummary from '@mui/material/AccordionSummary'
import AccordionDetails from '@mui/material/AccordionDetails'
import { Theme } from '@mui/material/styles'
import { WithStyles } from 'src/utils/withStyles'
import { withStyles } from 'src/utils/withStyles'
import { createStyles } from 'src/utils/withStyles'
import Typography from '@mui/material/Typography'

import { ConfirmationDialog } from 'src/components/Dialogs/ConfirmationDialog'
import {
  EditJobSpecDialog,
  Props as EditJobSpecDialogProps,
} from './EditJobSpecDialog'
import { SpecStatus } from 'src/types/generated/graphql'
import { TimeAgo } from 'src/components/TimeAgo'

export const JOB_PROPOSAL__SPECS_FIELDS = gql`
  fragment JobProposal_SpecsFields on JobProposalSpec {
    id
    definition
    status
    version
    createdAt
  }
`

const styles = (theme: Theme) => {
  return createStyles({
    versionText: {
      marginRight: theme.spacing(2),
    },
    proposedAtContainer: {
      flex: 1,
      textAlign: 'right',
    },
    expansionPanelDetails: {
      display: 'block',
    },
    actions: {
      display: 'flex',
      marginBottom: theme.spacing(2),
    },
    editContainer: {
      flex: 1,
    },
    actionsContainer: {
      flex: 1,
      textAlign: 'right',
    },
  })
}

interface Props extends WithStyles<typeof styles> {
  specs: ReadonlyArray<JobProposal_SpecsFields>
  proposal: JobProposalPayloadFields
  onApprove: (specID: string) => void
  onReject: (specID: string) => void
  onCancel: (specID: string) => void
  onUpdateSpec: EditJobSpecDialogProps['onSubmit']
}

interface ConfirmationDialogArgs {
  action: 'reject' | 'approve' | 'approvePrevious' | 'cancel'
  id: string
}

const confirmationDialogText = {
  approve: {
    title: 'Approve Job Proposal',
    body: 'Approving this job proposal will start running a new job. WARNING: If a job using the same contract address already exists, it will be deleted before running the new one.',
  },
  approvePrevious: {
    title: 'Approve Previous Version of Job Proposal',
    body: (
      <div>
        <p>
          ⚠️ You have selected a job spec version that is not the most recent
          one.
        </p>
        <p>
          Approving this job proposal will start running a new job with the old
          spec version.
        </p>
        <p>
          WARNING: If a job using the same contract address already exists, it
          will be deleted before running the new one.
        </p>
      </div>
    ),
  },
  cancel: {
    title: 'Cancel Job Proposal',
    body: 'Cancelling this job proposal will delete the running job. Are you sure you want to cancel this job proposal?',
  },
  reject: {
    title: 'Reject Job Proposal',
    body: 'Are you sure you want to reject this job proposal?',
  },
}

export const SpecsView = withStyles(styles)(({
  classes,
  onApprove,
  onCancel,
  onReject,
  onUpdateSpec,
  specs,
  proposal,
}: Props) => {
  const [confirmationDialog, setConfirmationDialog] =
    React.useState<ConfirmationDialogArgs | null>(null)
  const [isEditing, setIsEditing] = React.useState(false)

  const openConfirmationDialog = (
    action: ConfirmationDialogArgs['action'],
    id: string,
  ) => {
    setConfirmationDialog({ action, id })
  }

  const latestSpec = React.useMemo(() => {
    return specs.reduce((max, spec) =>
      max.version > spec.version ? max : spec,
    )
  }, [specs])

  const sortedSpecs = React.useMemo(() => {
    const sorted = [...specs]

    return sorted.sort((a, b) => b.version - a.version)
  }, [specs])

  const approvableCancelledJobSpecs = sortedSpecs
    .filter((spec) => spec.status === 'CANCELLED')
    .slice(0, 2)
    .map((spec) => spec.id)

  const renderActions = (
    status: SpecStatus,
    specID: string,
    proposal: JobProposalPayloadFields,
  ) => {
    switch (status) {
      case 'PENDING':
        return (
          <>
            <Button
              variant="text"
              color="secondary"
              onClick={() => openConfirmationDialog('reject', specID)}
            >
              Reject
            </Button>

            {latestSpec.id === specID &&
              proposal.status !== 'DELETED' &&
              proposal.status !== 'REVOKED' && (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => openConfirmationDialog('approve', specID)}
                >
                  Approve
                </Button>
              )}

            {latestSpec.id === specID &&
              proposal.status === 'DELETED' &&
              proposal.pendingUpdate && (
                <>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={() => openConfirmationDialog('cancel', specID)}
                  >
                    Cancel
                  </Button>

                  <Typography color="error">
                    This proposal was deleted. Cancel the spec to delete any
                    running jobs
                  </Typography>
                </>
              )}
          </>
        )
      case 'APPROVED':
        return (
          <>
            <Button
              variant="contained"
              onClick={() => openConfirmationDialog('cancel', specID)}
            >
              Cancel
            </Button>

            {proposal.status === 'DELETED' && proposal.pendingUpdate && (
              <Typography color="error">
                This proposal was deleted. Cancel the spec to delete any running
                jobs
              </Typography>
            )}
          </>
        )
      case 'CANCELLED':
        if (
          approvableCancelledJobSpecs.includes(specID) &&
          proposal.status !== 'DELETED' &&
          proposal.status !== 'REVOKED'
        ) {
          return (
            <Button
              variant="contained"
              color="primary"
              onClick={() =>
                openConfirmationDialog(
                  specID === latestSpec.id ? 'approve' : 'approvePrevious',
                  specID,
                )
              }
            >
              Approve
            </Button>
          )
        }

        return null
      default:
        return null
    }
  }

  return (
    <div>
      {sortedSpecs.map((spec, idx) => (
        <Accordion
          defaultExpanded={idx === 0}
          key={idx}
          data-testid="expansion-panel"
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography className={classes.versionText}>
              Version {spec.version}
            </Typography>
            <Chip
              label={spec.status}
              color={spec.status === 'APPROVED' ? 'primary' : 'default'}
              variant={
                spec.status === 'REJECTED' || spec.status === 'CANCELLED'
                  ? 'outlined'
                  : 'filled'
              }
            />
            <div className={classes.proposedAtContainer}>
              <Typography>
                Proposed <TimeAgo tooltip>{spec.createdAt}</TimeAgo>
              </Typography>
            </div>
          </AccordionSummary>
          <AccordionDetails className={classes.expansionPanelDetails}>
            <div className={classes.actions}>
              <div className={classes.editContainer}>
                {idx === 0 &&
                  (spec.status === 'PENDING' || spec.status === 'CANCELLED') &&
                  proposal.status !== 'DELETED' &&
                  proposal.status !== 'REVOKED' && (
                    <Button
                      variant="contained"
                      onClick={() => setIsEditing(true)}
                    >
                      Edit
                    </Button>
                  )}
              </div>
              <div className={classes.actionsContainer}>
                {renderActions(spec.status, spec.id, proposal)}
              </div>
            </div>

            <SyntaxHighlighter
              language="toml"
              style={prism}
              data-testid="codeblock"
            >
              {spec.definition}
            </SyntaxHighlighter>
          </AccordionDetails>
        </Accordion>
      ))}

      <ConfirmationDialog
        open={confirmationDialog != null}
        title={
          confirmationDialog
            ? confirmationDialogText[confirmationDialog.action].title
            : ''
        }
        body={
          confirmationDialog
            ? confirmationDialogText[confirmationDialog.action].body
            : ''
        }
        onConfirm={() => {
          if (confirmationDialog) {
            switch (confirmationDialog.action) {
              case 'approve':
              case 'approvePrevious':
                onApprove(confirmationDialog.id)

                break
              case 'cancel':
                onCancel(confirmationDialog.id)

                break
              case 'reject':
                onReject(confirmationDialog.id)

                break
              default:
              // NOOP
            }

            setConfirmationDialog(null)
          }
        }}
        cancelButtonText="Cancel"
        onCancel={() => setConfirmationDialog(null)}
      />

      <EditJobSpecDialog
        open={isEditing}
        onClose={() => setIsEditing(false)}
        initialValues={{
          definition: latestSpec.definition,
          id: latestSpec.id,
        }}
        onSubmit={onUpdateSpec}
      />
    </div>
  )
})
