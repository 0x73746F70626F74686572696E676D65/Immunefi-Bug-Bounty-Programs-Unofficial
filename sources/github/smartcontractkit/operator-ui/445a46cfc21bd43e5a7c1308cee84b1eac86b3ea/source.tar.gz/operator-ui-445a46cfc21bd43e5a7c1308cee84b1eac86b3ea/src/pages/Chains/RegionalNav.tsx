import React from 'react'
import { connect } from 'react-redux'
import { Chain, Resource } from 'core/store/models'
import { localizedTimestamp, TimeAgo } from 'components/TimeAgo'
import { useLocation } from 'react-router-dom'
import Card from '@mui/material/Card'
import Grid from '@mui/material/Grid'
import List from '@mui/material/List'
import ListItem from '@mui/material/ListItem'
import { Theme } from '@mui/material/styles'
import { WithStyles } from 'src/utils/withStyles'
import { withStyles } from 'src/utils/withStyles'
import { createStyles } from 'src/utils/withStyles'
import Typography from '@mui/material/Typography'
import classNames from 'classnames'
import Link from 'components/Link'

const styles = (theme: Theme) =>
  createStyles({
    container: {
      backgroundColor: theme.palette.background.paper,
      padding: theme.spacing(5),
      paddingBottom: 0,
    },
    mainRow: {
      marginBottom: theme.spacing(2),
    },
    actions: {
      textAlign: 'right',
    },
    regionalNavButton: {
      marginLeft: theme.spacing(1),
      marginRight: theme.spacing(1),
    },
    horizontalNav: {
      paddingBottom: 0,
    },
    horizontalNavItem: {
      display: 'inline',
      paddingLeft: 0,
      paddingRight: 0,
    },
    horizontalNavLink: {
      padding: `${theme.spacing(4)} ${theme.spacing(4)}`,
      textDecoration: 'none',
      display: 'inline-block',
      borderBottom: 'solid 1px',
      borderBottomColor: theme.palette.background.paper,
      '&:hover': {
        borderBottomColor: theme.palette.primary.main,
      },
    },
    activeNavLink: {
      color: theme.palette.primary.main,
      borderBottomColor: theme.palette.primary.main,
    },
    chainId: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
    },
    badgePadding: {
      paddingLeft: theme.spacing(2),
      paddingRight: theme.spacing(2),
      marginLeft: theme.spacing(-2),
      marginRight: theme.spacing(-2),
      lineHeight: '1rem',
    },
    dialogPaper: {
      minHeight: '260px',
      maxHeight: '260px',
      minWidth: '670px',
      maxWidth: '670px',
      overflow: 'hidden',
      borderRadius: theme.spacing(3),
    },
    warningText: {
      fontWeight: 500,
      marginLeft: theme.spacing(3),
      marginTop: theme.spacing(3),
      marginBottom: theme.spacing(1),
    },
    closeButton: {
      marginRight: theme.spacing(3),
      marginTop: theme.spacing(3),
    },
    infoText: {
      fontSize: theme.spacing(2),
      fontWeight: 450,
      marginLeft: theme.spacing(6),
    },
    modalTextarea: {
      marginLeft: theme.spacing(2),
    },
    modalContent: {
      width: 'inherit',
    },
    runJobButton: {
      marginBottom: theme.spacing(3),
    },
    runJobModalContent: {
      overflow: 'hidden',
    },
  })

export type ChainResource = Resource<Chain>

interface Props extends WithStyles<typeof styles> {
  chainId: string
  network: string
  chain?: ChainResource
}

const RegionalNavComponent = ({ classes, chainId, network, chain }: Props) => {
  const location = useLocation()
  const navOverridesActive = location.pathname.endsWith('/config-overrides')
  const editActive = location.pathname.endsWith('/edit')
  const navNodesActive = !navOverridesActive && !editActive

  return (
    <>
      <Card className={classes.container}>
        <Grid container spacing={0}>
          <Grid item xs={12}>
            <Grid
              container
              spacing={0}
              alignItems="center"
              className={classes.mainRow}
            >
              <Grid item xs={12}>
                {chain && (
                  <Typography
                    variant="h5"
                    color="secondary"
                    className={classes.chainId}
                  >
                    Chain {chain.id || chainId}
                  </Typography>
                )}
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={12}>
            {chain?.attributes.createdAt && (
              <Typography variant="subtitle2" color="textSecondary">
                Created{' '}
                <TimeAgo tooltip={false}>{chain.attributes.createdAt}</TimeAgo>{' '}
                ({localizedTimestamp(chain.attributes.createdAt)})
              </Typography>
            )}
          </Grid>
          <Grid item xs={12}>
            <List className={classes.horizontalNav}>
              <ListItem className={classes.horizontalNavItem}>
                <Link
                  href={`/chains/${network}/${chainId}`}
                  className={classNames(
                    classes.horizontalNavLink,
                    navNodesActive && classes.activeNavLink,
                  )}
                >
                  Nodes
                </Link>
              </ListItem>
            </List>
          </Grid>
        </Grid>
      </Card>
    </>
  )
}

export const ConnectedRegionalNav = connect(null, {})(RegionalNavComponent)

export default withStyles(styles)(ConnectedRegionalNav)
