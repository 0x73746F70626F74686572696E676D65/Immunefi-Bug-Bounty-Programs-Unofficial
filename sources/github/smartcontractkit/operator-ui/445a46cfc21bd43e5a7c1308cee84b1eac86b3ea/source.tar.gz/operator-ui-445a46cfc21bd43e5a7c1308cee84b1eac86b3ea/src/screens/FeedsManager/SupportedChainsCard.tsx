import React from 'react'

import { gql, useMutation } from '@apollo/client'
import { useDispatch } from 'react-redux'

import Card from '@mui/material/Card'
import CardHeader from '@mui/material/CardHeader'
import Chip from '@mui/material/Chip'
import Grid from '@mui/material/Grid'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import Accordion from '@mui/material/Accordion'
import AccordionSummary from '@mui/material/AccordionSummary'
import AccordionDetails from '@mui/material/AccordionDetails'
import IconButton from '@mui/material/IconButton'
import ListItemIcon from '@mui/material/ListItemIcon'
import ListItemText from '@mui/material/ListItemText'
import Menu from '@mui/material/Menu'
import MenuItem from '@mui/material/MenuItem'
import MoreVertIcon from '@mui/icons-material/MoreVert'
import AddBoxIcon from '@mui/icons-material/AddBox'
import { Theme } from '@mui/material/styles'
import { WithStyles } from 'src/utils/withStyles'
import { withStyles } from 'src/utils/withStyles'
import { createStyles } from 'src/utils/withStyles'
import Typography from '@mui/material/Typography'

import { notifySuccessMsg, notifyErrorMsg } from 'actionCreators'
import { FormValues } from 'src/components/Form/ChainConfigurationForm'
import {
  DetailsCardItemTitle,
  DetailsCardItemValue,
} from 'src/components/Cards/DetailsCard'
import { NewSupportedChainDialog } from './NewSupportedChainDialog'
import { useMutationErrorHandler } from 'src/hooks/useMutationErrorHandler'
import Button from 'src/components/Button'
import { EditSupportedChainDialog } from './EditSupportedChainDialog'
import { FEEDS_MANAGER_WITH_PROPOSALS_QUERY } from 'src/hooks/queries/useFeedsManagerWithProposalsQuery'

export const CREATE_FEEDS_MANAGER_CHAIN_CONFIG_MUTATION = gql`
  mutation CreateFeedsManagerChainConfig(
    $input: CreateFeedsManagerChainConfigInput!
  ) {
    createFeedsManagerChainConfig(input: $input) {
      ... on CreateFeedsManagerChainConfigSuccess {
        chainConfig {
          id
        }
      }
      ... on NotFoundError {
        message
        code
      }
      ... on InputErrors {
        errors {
          path
          message
          code
        }
      }
    }
  }
`

export const DELETE_FEEDS_MANAGER_CHAIN_CONFIG_MUTATION = gql`
  mutation DeleteFeedsManagerChainConfig($id: ID!) {
    deleteFeedsManagerChainConfig(id: $id) {
      ... on DeleteFeedsManagerChainConfigSuccess {
        chainConfig {
          id
        }
      }
      ... on NotFoundError {
        message
        code
      }
    }
  }
`

export const UPDATE_FEEDS_MANAGER_CHAIN_CONFIG_MUTATION = gql`
  mutation UpdateFeedsManagerChainConfig(
    $id: ID!
    $input: UpdateFeedsManagerChainConfigInput!
  ) {
    updateFeedsManagerChainConfig(id: $id, input: $input) {
      __typename
      ... on UpdateFeedsManagerChainConfigSuccess {
        chainConfig {
          id
        }
      }
      ... on NotFoundError {
        message
        code
      }
      ... on InputErrors {
        errors {
          path
          message
          code
        }
      }
    }
  }
`

const styles = (theme: Theme) => {
  return createStyles({
    card: {
      marginBottom: theme.spacing(2),
    },
    panel: {
      borderBottom: `1px solid ${theme.palette.divider}`,
    },
    panelExpanded: {
      margin: 0,
    },
    chip: {
      marginRight: theme.spacing(2),
    },
    title: {
      fontSize: theme.typography.body2.fontSize,
      fontWeight: theme.typography.body2.fontWeight,
      color: theme.typography.body2.color,
    },
    panelDetails: {
      display: 'block',
    },
    jobTypeContainer: {
      borderLeft: `2px solid ${theme.palette.primary.main}`,
      marginLeft: -8,
      paddingLeft: 8,
    },
    panelDetailsActions: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: theme.spacing(2),
    },
  })
}

const renderBootstrap = (
  cfg:
    | FeedsManager_ChainConfigFields['ocr2JobConfig']
    | FeedsManager_ChainConfigFields['ocr1JobConfig'],
) => (
  <>
    <Grid item xs={12} md={5}>
      <DetailsCardItemTitle title="Multiaddr" />
      <DetailsCardItemValue value={cfg.multiaddr} />
    </Grid>

    {cfg.__typename === 'OCR2JobConfig' && (
      <Grid item xs={12} md={5}>
        <DetailsCardItemTitle title="P2P Peer ID" />
        <DetailsCardItemValue value={cfg.p2pPeerID} />
      </Grid>
    )}
  </>
)

const renderOracle = (
  cfg:
    | FeedsManager_ChainConfigFields['ocr2JobConfig']
    | FeedsManager_ChainConfigFields['ocr1JobConfig'],
) => (
  <>
    <Grid item xs={12} md={5}>
      <DetailsCardItemTitle title="P2P Peer ID" />
      <DetailsCardItemValue value={cfg.p2pPeerID} />
    </Grid>
    <Grid item xs={12} md={5}>
      <DetailsCardItemTitle title="OCR Key ID" />
      <DetailsCardItemValue value={cfg.keyBundleID} />
    </Grid>
  </>
)

interface Props extends WithStyles<typeof styles> {
  mgrID: string
  cfgs: ReadonlyArray<FeedsManager_ChainConfigFields>
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const jobTypeRowStyles = (theme: Theme) => {
  return createStyles({
    jobTypeContainer: {
      borderLeft: `2px solid ${theme.palette.primary.main}`,
      marginLeft: -8,
      paddingLeft: 8,
    },
  })
}

interface FluxMonitorJobTypeRowProps extends WithStyles<
  typeof jobTypeRowStyles
> {
  cfg: FeedsManager_ChainConfigFields['fluxMonitorJobConfig']
}

const FluxMonitorJobTypeRow = withStyles(styles)(({
  cfg,
  classes,
}: FluxMonitorJobTypeRowProps) => {
  if (!cfg.enabled) {
    return null
  }

  return (
    <Grid item xs={12} md={12}>
      <div className={classes.jobTypeContainer}>
        <DetailsCardItemTitle title="Job Type" />
        <DetailsCardItemValue value="Flux Monitor" />
      </div>
    </Grid>
  )
})

interface OCRJobTypeRowProps extends WithStyles<typeof jobTypeRowStyles> {
  cfg: FeedsManager_ChainConfigFields['ocr1JobConfig']
}

const OCRJobTypeRow = withStyles(styles)(({
  cfg,
  classes,
}: OCRJobTypeRowProps) => {
  if (!cfg.enabled) {
    return null
  }

  return (
    <>
      <Grid item xs={12} md={2}>
        <div className={classes.jobTypeContainer}>
          <DetailsCardItemTitle title="Job Type" />
          <DetailsCardItemValue
            value={`OCR ${cfg.isBootstrap ? '(Bootstrap)' : ''}`}
          />
        </div>
      </Grid>

      {cfg.isBootstrap ? renderBootstrap(cfg) : renderOracle(cfg)}
    </>
  )
})

interface OCR2JobTypeRowProps extends WithStyles<typeof jobTypeRowStyles> {
  cfg: FeedsManager_ChainConfigFields['ocr2JobConfig']
}

const OCR2JobTypeRow = withStyles(styles)(({
  cfg,
  classes,
}: OCR2JobTypeRowProps) => {
  if (!cfg.enabled) {
    return null
  }

  return (
    <>
      <Grid item xs={12} md={2}>
        <div className={classes.jobTypeContainer}>
          <DetailsCardItemTitle title="Job Type" />
          <DetailsCardItemValue
            value={`OCR2 ${cfg.isBootstrap ? '(Bootstrap)' : ''}`}
          />
        </div>
      </Grid>

      {cfg.isBootstrap ? renderBootstrap(cfg) : renderOracle(cfg)}
    </>
  )
})

export const SupportedChainsCard = withStyles(styles)(({
  classes,
  cfgs,
  mgrID,
}: Props) => {
  const dispatch = useDispatch()
  const { handleMutationError } = useMutationErrorHandler()
  const [newDialogOpen, setNewDialogOpen] = React.useState(false)
  const [editCfg, setEditCfg] =
    React.useState<FeedsManager_ChainConfigFields | null>(null)
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null)

  const handleMenuOpen = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget)
  }

  const handleMenuClose = () => {
    setAnchorEl(null)
  }

  const handleEditDialogOpen = (cfg: FeedsManager_ChainConfigFields) => {
    setEditCfg(cfg)
  }

  const handleEditDialogClose = () => {
    setEditCfg(null)
  }

  const isEditDialogOpen = () => editCfg !== null

  const [createChainConfig] = useMutation<
    CreateFeedsManagerChainConfig,
    CreateFeedsManagerChainConfigVariables
  >(CREATE_FEEDS_MANAGER_CHAIN_CONFIG_MUTATION, {
    refetchQueries: [FEEDS_MANAGER_WITH_PROPOSALS_QUERY],
  })

  const [deleteChainConfig] = useMutation<
    DeleteFeedsManagerChainConfig,
    DeleteFeedsManagerChainConfigVariables
  >(DELETE_FEEDS_MANAGER_CHAIN_CONFIG_MUTATION, {
    refetchQueries: [FEEDS_MANAGER_WITH_PROPOSALS_QUERY],
  })

  const [updateChainConfig] = useMutation<
    UpdateFeedsManagerChainConfig,
    UpdateFeedsManagerChainConfigVariables
  >(UPDATE_FEEDS_MANAGER_CHAIN_CONFIG_MUTATION, {
    refetchQueries: [FEEDS_MANAGER_WITH_PROPOSALS_QUERY],
  })

  const handleCreateSubmit = async (values: FormValues) => {
    try {
      const result = await createChainConfig({
        variables: {
          input: {
            feedsManagerID: mgrID,
            chainID: values.chainID,
            chainType: values.chainType,
            accountAddr: values.accountAddr,
            adminAddr: values.adminAddr,
            accountAddrPubKey: values.accountAddrPubKey,
            fluxMonitorEnabled: values.fluxMonitorEnabled,
            ocr1Enabled: values.ocr1Enabled,
            ocr1IsBootstrap: values.ocr1IsBootstrap,
            ocr1Multiaddr:
              values.ocr1Multiaddr !== '' ? values.ocr1Multiaddr : null,
            ocr1P2PPeerID:
              values.ocr1P2PPeerID !== '' ? values.ocr1P2PPeerID : null,
            ocr1KeyBundleID:
              values.ocr1KeyBundleID != '' ? values.ocr1KeyBundleID : null,
            ocr2Enabled: values.ocr2Enabled,
            ocr2IsBootstrap: values.ocr2IsBootstrap,
            ocr2Multiaddr:
              values.ocr2Multiaddr !== '' ? values.ocr2Multiaddr : null,
            ocr2P2PPeerID:
              values.ocr2P2PPeerID !== '' ? values.ocr2P2PPeerID : null,
            ocr2KeyBundleID:
              values.ocr2KeyBundleID != '' ? values.ocr2KeyBundleID : null,
            ocr2Plugins: `{"commit":${values.ocr2CommitPluginEnabled},"execute":${values.ocr2ExecutePluginEnabled},"median":${values.ocr2MedianPluginEnabled},"mercury":${values.ocr2MercuryPluginEnabled},"rebalancer":${values.ocr2RebalancerPluginEnabled}}`,
            ocr2ForwarderAddress:
              values.ocr2ForwarderAddress !== ''
                ? values.ocr2ForwarderAddress
                : null,
          },
        },
      })

      const payload = result.data?.createFeedsManagerChainConfig
      switch (payload?.__typename) {
        case 'CreateFeedsManagerChainConfigSuccess':
          dispatch(notifySuccessMsg('Added new supported chain'))

          break
        case 'NotFoundError':
          dispatch(notifyErrorMsg(payload.message))

          break
      }
    } catch (e) {
      handleMutationError(e)
    }
  }

  const handleDelete = async (id: string) => {
    try {
      const result = await deleteChainConfig({
        variables: { id },
      })

      const payload = result.data?.deleteFeedsManagerChainConfig
      switch (payload?.__typename) {
        case 'DeleteFeedsManagerChainConfigSuccess':
          dispatch(notifySuccessMsg('Deleted supported chain'))

          break
        case 'NotFoundError':
          dispatch(notifyErrorMsg(payload.message))

          break
      }
    } catch (e) {
      handleMutationError(e)
    }
  }

  const handleUpdateSubmit = async (values: FormValues) => {
    if (!editCfg) {
      return
    }

    try {
      const result = await updateChainConfig({
        variables: {
          id: editCfg.id,
          input: {
            accountAddr: values.accountAddr,
            adminAddr: values.adminAddr,
            accountAddrPubKey: values.accountAddrPubKey,
            fluxMonitorEnabled: values.fluxMonitorEnabled,
            ocr1Enabled: values.ocr1Enabled,
            ocr1IsBootstrap: values.ocr1IsBootstrap,
            ocr1Multiaddr:
              values.ocr1Multiaddr !== '' ? values.ocr1Multiaddr : null,
            ocr1P2PPeerID:
              values.ocr1P2PPeerID !== '' ? values.ocr1P2PPeerID : null,
            ocr1KeyBundleID:
              values.ocr1KeyBundleID != '' ? values.ocr1KeyBundleID : null,
            ocr2Enabled: values.ocr2Enabled,
            ocr2IsBootstrap: values.ocr2IsBootstrap,
            ocr2Multiaddr:
              values.ocr2Multiaddr !== '' ? values.ocr2Multiaddr : null,
            ocr2P2PPeerID:
              values.ocr2P2PPeerID !== '' ? values.ocr2P2PPeerID : null,
            ocr2KeyBundleID:
              values.ocr2KeyBundleID != '' ? values.ocr2KeyBundleID : null,
            ocr2Plugins: `{"commit":${values.ocr2CommitPluginEnabled},"execute":${values.ocr2ExecutePluginEnabled},"median":${values.ocr2MedianPluginEnabled},"mercury":${values.ocr2MercuryPluginEnabled},"rebalancer":${values.ocr2RebalancerPluginEnabled}}`,
            ocr2ForwarderAddress:
              values.ocr2ForwarderAddress !== ''
                ? values.ocr2ForwarderAddress
                : null,
          },
        },
      })

      const payload = result.data?.updateFeedsManagerChainConfig
      switch (payload?.__typename) {
        case 'UpdateFeedsManagerChainConfigSuccess':
          handleMenuClose()

          dispatch(notifySuccessMsg('Updated supported chain'))

          break
        case 'NotFoundError':
          dispatch(notifyErrorMsg(payload.message))

          break
      }
    } catch (e) {
      handleMutationError(e)
    }
  }

  return (
    <Card className={classes.card}>
      <CardHeader
        title="Supported Chains"
        classes={{
          title: classes.title,
        }}
        action={
          <>
            <IconButton
              onClick={handleMenuOpen}
              aria-label="open-menu"
              size="large"
            >
              <MoreVertIcon />
            </IconButton>

            <Menu
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={handleMenuClose}
            >
              <MenuItem
                onClick={() => {
                  setNewDialogOpen(true)
                  handleMenuClose()
                }}
              >
                <ListItemIcon>
                  <AddBoxIcon />
                </ListItemIcon>
                <ListItemText>New</ListItemText>
              </MenuItem>
            </Menu>
          </>
        }
      />
      {cfgs.map((cfg) => (
        <Accordion
          key={cfg.id}
          defaultExpanded={false}
          classes={{
            root: classes.panel,
            expanded: classes.panelExpanded,
          }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Chip
              label={cfg.chainType}
              color="primary"
              className={classes.chip}
            />
            <Typography style={{ lineHeight: '30px' }}>
              Chain ID: {cfg.chainID}
            </Typography>
          </AccordionSummary>
          <AccordionDetails className={classes.panelDetails}>
            <Grid container spacing={5}>
              <Grid item xs={12}>
                <Grid container>
                  <Grid item xs={12} sm={6}>
                    <DetailsCardItemTitle title="Account Address" />
                    <DetailsCardItemValue value={cfg.accountAddr} />
                  </Grid>
                  {(cfg.chainID === 'SN_MAIN' ||
                    cfg.chainID === 'SN_SEPOLIA') && (
                    <Grid item xs={12} sm={6}>
                      <DetailsCardItemTitle title="Account Address Public Key" />
                      <DetailsCardItemValue value={cfg.accountAddrPubKey} />
                    </Grid>
                  )}
                  {cfg.chainType === 'APTOS' && (
                    <Grid item xs={12} sm={6}>
                      <DetailsCardItemTitle title="Account Public Key" />
                      <DetailsCardItemValue value={cfg.accountAddrPubKey} />
                    </Grid>
                  )}
                  {cfg.chainType === 'SUI' && (
                    <Grid item xs={12} sm={6}>
                      <DetailsCardItemTitle title="Account Public Key" />
                      <DetailsCardItemValue value={cfg.accountAddrPubKey} />
                    </Grid>
                  )}
                  <Grid item xs={12} sm={6}>
                    <DetailsCardItemTitle title="Admin Address" />
                    <DetailsCardItemValue value={cfg.adminAddr} />
                  </Grid>

                  <FluxMonitorJobTypeRow cfg={cfg.fluxMonitorJobConfig} />
                  <OCRJobTypeRow cfg={cfg.ocr1JobConfig} />
                  <OCR2JobTypeRow cfg={cfg.ocr2JobConfig} />
                </Grid>
              </Grid>

              <Grid item xs={12}>
                <div className={classes.panelDetailsActions}>
                  <Button onClick={() => handleEditDialogOpen(cfg)}>
                    Edit
                  </Button>
                  <Button onClick={() => handleDelete(cfg.id)} variant="danger">
                    Delete
                  </Button>
                </div>
              </Grid>
            </Grid>
          </AccordionDetails>
        </Accordion>
      ))}
      {newDialogOpen && (
        <NewSupportedChainDialog
          open={newDialogOpen}
          onClose={() => setNewDialogOpen(false)}
          onSubmit={handleCreateSubmit}
        />
      )}
      {isEditDialogOpen() && (
        <EditSupportedChainDialog
          cfg={editCfg}
          open={isEditDialogOpen()}
          onClose={handleEditDialogClose}
          onSubmit={handleUpdateSubmit}
        />
      )}
    </Card>
  )
})
