import React from 'react'

import { useHistory } from 'react-router-dom'
import { gql } from '@apollo/client'

import Card from '@mui/material/Card'
import Grid from '@mui/material/Grid'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'

import Content from 'src/components/Content'
import { Loading } from 'src/components/Feedback/Loading'
import { PageHeader } from 'src/components/PageHeader'
import { TransactionRow } from './TransactionRow'
import { TablePagination } from '@mui/material'

export const ETH_TRANSACTIONS_PAYLOAD__RESULTS_FIELDS = gql`
  fragment EthTransactionsPayload_ResultsFields on EthTransaction {
    chain {
      id
      network
    }
    from
    hash
    to
    nonce
    sentAt
  }
`

export interface Props {
  data?: FetchEthTransactions
  loading: boolean
  page: number
  pageSize: number
}

export const TransactionsView: React.FC<Props> = ({
  data,
  loading,
  page,
  pageSize,
}) => {
  const history = useHistory()

  return (
    <Content>
      <Grid container>
        <Grid item xs={12}>
          <PageHeader title="Transactions" />
        </Grid>

        {loading && <Loading />}

        {data && (
          <Grid item xs={12}>
            <Card>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Txn Hash</TableCell>
                    <TableCell>Chain ID</TableCell>
                    <TableCell>From</TableCell>
                    <TableCell>To</TableCell>
                    <TableCell>Nonce</TableCell>
                    <TableCell>Block</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data?.ethTransactions.results.length === 0 && (
                    <TableRow>
                      <TableCell component="th" scope="row" colSpan={6}>
                        You haven’t created any transactions yet
                      </TableCell>
                    </TableRow>
                  )}

                  {data?.ethTransactions.results.map((tx, idx) => (
                    <TransactionRow tx={tx} key={idx} />
                  ))}
                </TableBody>
              </Table>
              <TablePagination
                component="div"
                count={data.ethTransactions.metadata.total}
                rowsPerPage={pageSize}
                rowsPerPageOptions={[10, 25, 50, 100]}
                page={page - 1}
                onPageChange={(_, p) => {
                  history.push(`/transactions?page=${p + 1}&per=${pageSize}`)
                }}
                onRowsPerPageChange={(e) => {
                  history.push(
                    `/transactions?page=${page}&per=${parseInt(
                      e.target.value,
                      10,
                    )}`,
                  )
                }}
                backIconButtonProps={{ 'aria-label': 'prev-page' }}
                nextIconButtonProps={{ 'aria-label': 'next-page' }}
              />
            </Card>
          </Grid>
        )}
      </Grid>
    </Content>
  )
}
