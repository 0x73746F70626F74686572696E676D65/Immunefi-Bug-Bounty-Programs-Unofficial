import React from 'react'
import { gql } from '@apollo/client'
import { useHistory } from 'react-router-dom'

import Card from '@mui/material/Card'
import Grid from '@mui/material/Grid'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableHead from '@mui/material/TableHead'
import TablePagination from '@mui/material/TablePagination'
import TableRow from '@mui/material/TableRow'

import BaseLink from 'components/BaseLink'
import { BridgeRow } from './BridgeRow'
import Button from 'components/Button'
import Content from 'components/Content'
import { PageHeader } from 'src/components/PageHeader'

export const BRIDGES_PAYLOAD__RESULTS_FIELDS = gql`
  fragment BridgesPayload_ResultsFields on Bridge {
    id
    name
    url
    confirmations
    minimumContractPayment
    useConnectionManager
  }
`

export interface Props {
  bridges: ReadonlyArray<BridgesPayload_ResultsFields>
  page: number
  pageSize: number
  total: number
}

export const BridgesView: React.FC<Props> = ({
  bridges,
  page,
  pageSize,
  total,
}) => {
  const history = useHistory()

  return (
    <Content>
      <Grid container>
        <Grid item xs={12}>
          <PageHeader
            title="Bridges"
            actions={
              <Button
                variant="secondary"
                component={BaseLink}
                href={'/bridges/new'}
              >
                New Bridge
              </Button>
            }
          />
        </Grid>

        <Grid item xs={12}>
          <Card>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Name</TableCell>
                  <TableCell>URL</TableCell>
                  <TableCell>Default Confirmations</TableCell>
                  <TableCell>Minimum Contract Payment</TableCell>
                  <TableCell>Use gRPC transport</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {bridges.map((bridge) => (
                  <BridgeRow bridge={bridge} key={bridge.name} />
                ))}
              </TableBody>
            </Table>
            <TablePagination
              component="div"
              count={total}
              rowsPerPage={pageSize}
              rowsPerPageOptions={[pageSize]}
              page={page - 1}
              onPageChange={(_, p) => {
                history.push(`/bridges?page=${p + 1}&per=${pageSize}`)
              }}
              onRowsPerPageChange={() => {}} /* handler required by component, so make it a no-op */
              backIconButtonProps={{ 'aria-label': 'prev-page' }}
              nextIconButtonProps={{ 'aria-label': 'next-page' }}
            />
          </Card>
        </Grid>
      </Grid>
    </Content>
  )
}
