declare module 'graphlib-dot'
