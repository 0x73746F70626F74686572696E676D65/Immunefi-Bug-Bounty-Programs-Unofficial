package capabilities

import (
	"context"
	"encoding/hex"
	"errors"
	"maps"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/smartcontractkit/chainlink-common/pkg/contexts"
	"github.com/smartcontractkit/chainlink-protos/cre/go/values"
)

func Test_CapabilityInfo(t *testing.T) {
	ci, err := NewCapabilityInfo(
		"capability-id@1.0.0",
		CapabilityTypeAction,
		"This is a mock capability that doesn't do anything.",
	)
	require.NoError(t, err)

	gotCi, err := ci.Info(t.Context())
	require.NoError(t, err)
	require.Equal(t, "1.0.0", ci.Version())
	assert.Equal(t, ci, gotCi)

	ci, err = NewCapabilityInfo(
		// add build metadata and sha
		"capability-id@1.0.0+build.1234.sha-5678",
		CapabilityTypeAction,
		"This is a mock capability that doesn't do anything.",
	)
	require.NoError(t, err)

	gotCi, err = ci.Info(t.Context())
	require.NoError(t, err)
	require.Equal(t, "1.0.0+build.1234.sha-5678", ci.Version())
	assert.Equal(t, ci, gotCi)

	// prerelease
	ci, err = NewCapabilityInfo(
		"capability-id@1.0.0-beta",
		CapabilityTypeAction,
		"This is a mock capability that doesn't do anything.",
	)
	require.NoError(t, err)

	gotCi, err = ci.Info(t.Context())
	require.NoError(t, err)
	require.Equal(t, "1.0.0-beta", ci.Version())
	assert.Equal(t, ci, gotCi)
}

func Test_CapabilityInfo_Invalid(t *testing.T) {
	_, err := NewCapabilityInfo(
		"capability-id@2.0.0",
		CapabilityTypeUnknown,
		"This is a mock capability that doesn't do anything.",
	)
	assert.ErrorContains(t, err, "invalid capability type")

	_, err = NewCapabilityInfo(
		"&!!!",
		CapabilityTypeAction,
		"This is a mock capability that doesn't do anything.",
	)
	assert.ErrorContains(t, err, "invalid id")

	_, err = NewCapabilityInfo(
		"mock-capability@v1.0.0",
		CapabilityTypeAction,
		"This is a mock capability that doesn't do anything.",
	)
	assert.ErrorContains(t, err, "invalid id")

	_, err = NewCapabilityInfo(
		"mock-capability@1.0",
		CapabilityTypeAction,
		"This is a mock capability that doesn't do anything.",
	)
	assert.ErrorContains(t, err, "invalid id")

	_, err = NewCapabilityInfo(
		"mock-capability@1",
		CapabilityTypeAction,
		"This is a mock capability that doesn't do anything.",
	)

	assert.ErrorContains(t, err, "invalid id")
	_, err = NewCapabilityInfo(
		strings.Repeat("n", 256),
		CapabilityTypeAction,
		"This is a mock capability that doesn't do anything.",
	)
	assert.ErrorContains(t, err, "exceeds max length 128")
}

type mockCapabilityWithExecute struct {
	Executable
	CapabilityInfo
	ExecuteFn func(ctx context.Context, req CapabilityRequest) (CapabilityResponse, error)
}

func (m *mockCapabilityWithExecute) Execute(ctx context.Context, req CapabilityRequest) (CapabilityResponse, error) {
	return m.ExecuteFn(ctx, req)
}

func Test_ExecuteSyncReturnValue(t *testing.T) {
	v := map[string]any{"hello": "world"}
	mcwe := &mockCapabilityWithExecute{
		ExecuteFn: func(ctx context.Context, req CapabilityRequest) (CapabilityResponse, error) {
			val, err := values.NewMap(v)
			if err != nil {
				return CapabilityResponse{}, err
			}

			return CapabilityResponse{Value: val}, nil
		},
	}
	req := CapabilityRequest{}
	resp, err := mcwe.Execute(t.Context(), req)

	require.NoError(t, err)
	unwrappedValue, err := resp.Value.Unwrap()
	require.NoError(t, err)
	assert.Equal(t, v, unwrappedValue)
}

func Test_ExecuteSyncCapabilitySetupErrors(t *testing.T) {
	expectedErr := errors.New("something went wrong during setup")
	mcwe := &mockCapabilityWithExecute{
		ExecuteFn: func(ctx context.Context, req CapabilityRequest) (CapabilityResponse, error) {
			return CapabilityResponse{}, expectedErr
		},
	}
	req := CapabilityRequest{}
	_, err := mcwe.Execute(t.Context(), req)
	assert.ErrorContains(t, err, expectedErr.Error())
}

func Test_MustNewCapabilityInfo(t *testing.T) {
	assert.Panics(t, func() {
		MustNewCapabilityInfo(
			"capability-id",
			CapabilityTypeAction,
			"This is a mock capability that doesn't do anything.",
		)
	})
}

func Test_RemoteExecutableConfig_ApplyDefaults(t *testing.T) {
	rec := &RemoteExecutableConfig{}
	rec.ApplyDefaults()

	assert.Equal(t, DefaultExecutableRequestTimeout, rec.RequestTimeout)
	assert.Equal(t, DefaultServerMaxParallelRequests, rec.ServerMaxParallelRequests)
}

func TestParseID(t *testing.T) {
	for _, tc := range []struct {
		id      string
		name    string
		labels  map[string]string
		version string
	}{
		{id: "foo", name: "foo"},
		{id: "foo@1.0.0", name: "foo", version: "1.0.0"},
		{id: "foo:k_v@1.0.0", name: "foo", labels: map[string]string{"k": "v"}, version: "1.0.0"},
		{id: "foo:k_v:k2_v2:k3@1.0.0", name: "foo", labels: map[string]string{"k": "v", "k2": "v2", "k3": ""}, version: "1.0.0"},
		//TODO more
	} {
		t.Run(tc.id, func(t *testing.T) {
			if tc.labels == nil {
				tc.labels = map[string]string{}
			}

			name, labels, version := ParseID(tc.id)
			assert.Equal(t, tc.name, name)
			assert.Equal(t, tc.labels, maps.Collect(labels))
			assert.Equal(t, tc.version, version)
		})
	}
}

func TestChainSelectorLabel(t *testing.T) {
	for _, tc := range []struct {
		id     string
		cs     *uint64
		errMsg string
	}{
		{"none@v1.0.0", nil, ""},
		{"kv:ChainSelector_1@v1.0.0", new(uint64(1)), ""},
		{"kk:ChainSelector:1@v1.0.0", new(uint64(1)), ""},
		{"kv-others:k_v:ChainSelector_1@v1.0.0", new(uint64(1)), ""},
		{"kk-others:k_v:ChainSelector:1@v1.0.0", new(uint64(1)), ""},

		{"kv:ChainSelector_foo@v1.0.0", new(uint64(1)), "invalid chain selector"},
		{"kk:ChainSelector:bar@v1.0.0", new(uint64(1)), "invalid chain selector"},
	} {
		t.Run(tc.id, func(t *testing.T) {
			_, labels, _ := ParseID(tc.id)
			cs, err := ChainSelectorLabel(labels)
			if tc.errMsg != "" {
				require.ErrorContains(t, err, tc.errMsg)
			} else {
				require.Equal(t, tc.cs, cs)
			}
		})
	}
}

func TestRequestMetadata_ContextWithCRE(t *testing.T) {
	ctx := t.Context()
	require.Empty(t, contexts.CREValue(ctx).Org)

	// set it
	ctx = contexts.WithCRE(ctx, contexts.CRE{Org: "org-id"})
	require.Equal(t, "org-id", contexts.CREValue(ctx).Org)

	// preserve org when RequestMetadata.OrgID is unset
	md := RequestMetadata{WorkflowOwner: "owner-id", WorkflowID: "workflow-id"}
	ctx = md.ContextWithCRE(ctx)
	require.Equal(t, "org-id", contexts.CREValue(ctx).Org)

	// OrgID from metadata replaces context org when set
	ctx = contexts.WithCRE(t.Context(), contexts.CRE{Org: "old-org"})
	md = RequestMetadata{WorkflowOwner: "o", WorkflowID: "w", OrgID: "new-org"}
	ctx = md.ContextWithCRE(ctx)
	require.Equal(t, "new-org", contexts.CREValue(ctx).Org)

	// OrgID propagates when ctx had no org
	ctx = md.ContextWithCRE(t.Context())
	require.Equal(t, "new-org", contexts.CREValue(ctx).Org)
	require.Equal(t, "o", contexts.CREValue(ctx).Owner)
	require.Equal(t, "w", contexts.CREValue(ctx).Workflow)
}

func TestRegistrationMetadata_ContextWithCRE(t *testing.T) {
	ctx := t.Context()
	require.Empty(t, contexts.CREValue(ctx).Org)

	// set it
	ctx = contexts.WithCRE(ctx, contexts.CRE{Org: "org-id"})
	require.Equal(t, "org-id", contexts.CREValue(ctx).Org)

	// preserve it
	md := RegistrationMetadata{WorkflowOwner: "owner-id", WorkflowID: "workflow-id"}
	ctx = md.ContextWithCRE(ctx)
	require.Equal(t, "org-id", contexts.CREValue(ctx).Org)
}

func testResponseMetadata(spendUnit, spendValue string) ResponseMetadata {
	return ResponseMetadata{
		Metering: []MeteringNodeDetail{{SpendUnit: spendUnit, SpendValue: spendValue}},
	}
}

func TestResponseToReportData(t *testing.T) {
	t.Run("deterministic golden digest", func(t *testing.T) {
		// SHA3-256 over domain "CapabilityResponseReportData:v1" plus length-prefixed fields.
		want, err := hex.DecodeString("5d39c100ecf57f83b095cc9e129e0be24809e208af97a40e6447932749272a50")
		require.NoError(t, err)
		require.Len(t, want, 32)

		got, err := ResponseToReportData(
			"wf-exec",
			"ref-1",
			[]byte("payload"),
			testResponseMetadata("unit", "42"),
		)
		require.NoError(t, err)
		assert.Equal(t, want, got[:])
	})

	t.Run("same inputs yield same hash", func(t *testing.T) {
		md := testResponseMetadata("u", "1")
		a, err := ResponseToReportData("wf", "ref", []byte("p"), md)
		require.NoError(t, err)
		b, err := ResponseToReportData("wf", "ref", []byte("p"), md)
		require.NoError(t, err)
		assert.Equal(t, a, b)
	})

	t.Run("nil payload matches empty payload", func(t *testing.T) {
		md := testResponseMetadata("u", "v")
		a, err := ResponseToReportData("w", "r", nil, md)
		require.NoError(t, err)
		b, err := ResponseToReportData("w", "r", []byte{}, md)
		require.NoError(t, err)
		assert.Equal(t, a, b)
	})

	t.Run("each field affects the digest", func(t *testing.T) {
		base, err := ResponseToReportData(
			"workflow-exec-id",
			"reference-id",
			[]byte{0x01, 0x02},
			testResponseMetadata("spend-unit", "spend-value"),
		)
		require.NoError(t, err)

		other, err := ResponseToReportData(
			"other-workflow",
			"reference-id",
			[]byte{0x01, 0x02},
			testResponseMetadata("spend-unit", "spend-value"),
		)
		require.NoError(t, err)
		assert.NotEqual(t, base, other)

		other, err = ResponseToReportData(
			"workflow-exec-id",
			"other-ref",
			[]byte{0x01, 0x02},
			testResponseMetadata("spend-unit", "spend-value"),
		)
		require.NoError(t, err)
		assert.NotEqual(t, base, other)

		other, err = ResponseToReportData(
			"workflow-exec-id",
			"reference-id",
			[]byte{0x01},
			testResponseMetadata("spend-unit", "spend-value"),
		)
		require.NoError(t, err)
		assert.NotEqual(t, base, other)

		other, err = ResponseToReportData(
			"workflow-exec-id",
			"reference-id",
			[]byte{0x01, 0x02},
			testResponseMetadata("other-unit", "spend-value"),
		)
		require.NoError(t, err)
		assert.NotEqual(t, base, other)

		other, err = ResponseToReportData(
			"workflow-exec-id",
			"reference-id",
			[]byte{0x01, 0x02},
			testResponseMetadata("spend-unit", "other-value"),
		)
		require.NoError(t, err)
		assert.NotEqual(t, base, other)
	})

	t.Run("metering must contain exactly one entry", func(t *testing.T) {
		_, err := ResponseToReportData("w", "r", nil, ResponseMetadata{})
		require.ErrorContains(t, err, "failed to extract metering from metadata: unexpected number of metering records received from peer 12D3KooW9pNAk8aiBuGVQtWRdbkLmo5qVL3e2h5UxbN2Nz9ttwiw: got 0, want 1")

		_, err = ResponseToReportData("w", "r", nil, ResponseMetadata{
			Metering: []MeteringNodeDetail{
				{SpendUnit: "a", SpendValue: "1"},
				{SpendUnit: "b", SpendValue: "2"},
			},
		})
		require.ErrorContains(t, err, "failed to extract metering from metadata: unexpected number of metering records received from peer 12D3KooW9pNAk8aiBuGVQtWRdbkLmo5qVL3e2h5UxbN2Nz9ttwiw: got 2, want 1")
	})
}
