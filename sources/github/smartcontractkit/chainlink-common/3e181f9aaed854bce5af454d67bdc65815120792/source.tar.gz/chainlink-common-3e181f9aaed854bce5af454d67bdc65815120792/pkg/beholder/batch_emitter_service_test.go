package beholder_test

import (
	"context"
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/attribute"
	sdkmetric "go.opentelemetry.io/otel/sdk/metric"
	"go.opentelemetry.io/otel/sdk/metric/metricdata"
	"go.uber.org/zap"
	"go.uber.org/zap/zaptest/observer"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"

	"github.com/smartcontractkit/chainlink-common/pkg/beholder"
	"github.com/smartcontractkit/chainlink-common/pkg/chipingress"
	"github.com/smartcontractkit/chainlink-common/pkg/chipingress/batch"
	"github.com/smartcontractkit/chainlink-common/pkg/chipingress/mocks"
	"github.com/smartcontractkit/chainlink-common/pkg/logger"
)

func newTestConfig() beholder.Config {
	return beholder.Config{
		ChipIngressBufferSize:         10,
		ChipIngressMaxBatchSize:       5,
		ChipIngressMaxConcurrentSends: 3,
		ChipIngressSendInterval:       50 * time.Millisecond,
		ChipIngressSendTimeout:        5 * time.Second,
		ChipIngressDrainTimeout:       5 * time.Second,
		ChipIngressMaxGRPCRequestSize: 1024 * 1024,
	}
}

// successfulPublishResponse returns a PublishResponse with a generous tail of successful results.
// The batch client's partial-delivery callback path dispatches per event from resp.Results, so a
// mock returning (nil, nil) would nil-deref, and one returning no results would fail callbacks with
// a synthetic RESULTS_MISMATCH. A real server returns one result per event; the extra entries here
// are ignored, and a nil result entry is treated as success.
func successfulPublishResponse() *chipingress.PublishResponse {
	return &chipingress.PublishResponse{Results: make([]*chipingress.PublishResult, 100)}
}

func TestNewChipIngressBatchEmitterService(t *testing.T) {
	t.Run("happy path", func(t *testing.T) {
		clientMock := mocks.NewClient(t)
		clientMock.EXPECT().Close().Return(nil).Maybe()
		emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, newTestConfig(), logger.Test(t))
		require.NoError(t, err)
		assert.NotNil(t, emitter)
	})

	t.Run("returns error when client is nil", func(t *testing.T) {
		emitter, err := beholder.NewChipIngressBatchEmitterService(nil, newTestConfig(), logger.Test(t))
		assert.Error(t, err)
		assert.Nil(t, emitter)
	})
}

func TestChipIngressBatchEmitterService_Emit(t *testing.T) {
	t.Run("returns error when domain/entity missing", func(t *testing.T) {
		clientMock := mocks.NewClient(t)
		clientMock.EXPECT().Close().Return(nil).Maybe()
		emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, newTestConfig(), logger.Test(t))
		require.NoError(t, err)
		require.NoError(t, emitter.Start(t.Context()))
		defer emitter.Close() //nolint:errcheck

		err = emitter.Emit(t.Context(), []byte("test"), "bad_key", "bad_value")
		assert.Error(t, err)
	})

	t.Run("events are batched and sent via PublishBatch", func(t *testing.T) {
		clientMock := mocks.NewClient(t)
		clientMock.EXPECT().Close().Return(nil).Maybe()

		var mu sync.Mutex
		var receivedBatches []*chipingress.CloudEventBatch
		clientMock.
			On("PublishBatch", mock.Anything, mock.Anything).
			Run(func(args mock.Arguments) {
				mu.Lock()
				defer mu.Unlock()
				batch := args.Get(1).(*chipingress.CloudEventBatch)
				receivedBatches = append(receivedBatches, batch)
			}).
			Return(successfulPublishResponse(), nil)

		cfg := newTestConfig()
		cfg.ChipIngressSendInterval = 50 * time.Millisecond

		emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, cfg, logger.Test(t))
		require.NoError(t, err)
		require.NoError(t, emitter.Start(t.Context()))

		for range 3 {
			err = emitter.Emit(t.Context(), []byte("body"),
				beholder.AttrKeyDomain, "platform",
				beholder.AttrKeyEntity, "TestEvent",
			)
			require.NoError(t, err)
		}

		assert.Eventually(t, func() bool {
			mu.Lock()
			defer mu.Unlock()
			return len(receivedBatches) > 0
		}, 2*time.Second, 10*time.Millisecond)

		require.NoError(t, emitter.Close())

		mu.Lock()
		defer mu.Unlock()

		totalEvents := 0
		for _, batch := range receivedBatches {
			totalEvents += len(batch.Events)
		}
		assert.Equal(t, 3, totalEvents)
	})
}

func TestChipIngressBatchEmitterService_CloudEventFormat(t *testing.T) {
	clientMock := mocks.NewClient(t)
	clientMock.EXPECT().Close().Return(nil).Maybe()

	var mu sync.Mutex
	var receivedBatch *chipingress.CloudEventBatch
	clientMock.
		On("PublishBatch", mock.Anything, mock.Anything).
		Run(func(args mock.Arguments) {
			mu.Lock()
			defer mu.Unlock()
			receivedBatch = args.Get(1).(*chipingress.CloudEventBatch)
		}).
		Return(successfulPublishResponse(), nil)

	cfg := newTestConfig()
	cfg.ChipIngressSendInterval = 50 * time.Millisecond

	emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, cfg, logger.Test(t))
	require.NoError(t, err)
	require.NoError(t, emitter.Start(t.Context()))

	err = emitter.Emit(t.Context(), []byte("test-payload"),
		beholder.AttrKeyDomain, "my-domain",
		beholder.AttrKeyEntity, "my-entity",
	)
	require.NoError(t, err)

	assert.Eventually(t, func() bool {
		mu.Lock()
		defer mu.Unlock()
		return receivedBatch != nil
	}, 2*time.Second, 10*time.Millisecond)

	require.NoError(t, emitter.Close())

	mu.Lock()
	defer mu.Unlock()
	require.Len(t, receivedBatch.Events, 1)

	event := receivedBatch.Events[0]
	assert.Equal(t, "my-domain", event.Source)
	assert.Equal(t, "my-entity", event.Type)
	assert.NotEmpty(t, event.Id)
}

func TestChipIngressBatchEmitterService_PublishBatchError(t *testing.T) {
	clientMock := mocks.NewClient(t)
	clientMock.EXPECT().Close().Return(nil).Maybe()

	var mu sync.Mutex
	callCount := 0
	clientMock.
		On("PublishBatch", mock.Anything, mock.Anything).
		Run(func(_ mock.Arguments) {
			mu.Lock()
			defer mu.Unlock()
			callCount++
		}).
		Return(nil, assert.AnError)

	cfg := newTestConfig()
	cfg.ChipIngressSendInterval = 50 * time.Millisecond

	emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, cfg, logger.Test(t))
	require.NoError(t, err)
	require.NoError(t, emitter.Start(t.Context()))

	for range 3 {
		err = emitter.Emit(t.Context(), []byte("body"),
			beholder.AttrKeyDomain, "platform",
			beholder.AttrKeyEntity, "TestEvent",
		)
		require.NoError(t, err)
	}

	assert.Eventually(t, func() bool {
		mu.Lock()
		defer mu.Unlock()
		return callCount > 0
	}, 2*time.Second, 10*time.Millisecond)

	require.NoError(t, emitter.Close())
}

func TestChipIngressBatchEmitterService_ContextCancellation(t *testing.T) {
	clientMock := mocks.NewClient(t)
	clientMock.EXPECT().Close().Return(nil).Maybe()
	clientMock.
		On("PublishBatch", mock.Anything, mock.Anything).
		Return(successfulPublishResponse(), nil).
		Maybe()

	cfg := newTestConfig()
	cfg.ChipIngressBufferSize = 1
	cfg.ChipIngressSendInterval = 10 * time.Second

	emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, cfg, logger.Test(t))
	require.NoError(t, err)
	require.NoError(t, emitter.Start(t.Context()))
	defer emitter.Close() //nolint:errcheck

	ctx, cancel := context.WithCancel(t.Context())
	cancel()

	err = emitter.Emit(ctx, []byte("should-fail"),
		beholder.AttrKeyDomain, "platform",
		beholder.AttrKeyEntity, "TestEvent",
	)
	assert.ErrorIs(t, err, context.Canceled)
}

func TestChipIngressBatchEmitterService_DefaultConfig(t *testing.T) {
	clientMock := mocks.NewClient(t)
	clientMock.EXPECT().Close().Return(nil).Maybe()

	var mu sync.Mutex
	var receivedBatch *chipingress.CloudEventBatch
	clientMock.
		On("PublishBatch", mock.Anything, mock.Anything).
		Run(func(args mock.Arguments) {
			mu.Lock()
			defer mu.Unlock()
			receivedBatch = args.Get(1).(*chipingress.CloudEventBatch)
		}).
		Return(successfulPublishResponse(), nil)

	emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, beholder.Config{}, logger.Test(t))
	require.NoError(t, err)
	require.NoError(t, emitter.Start(t.Context()))

	err = emitter.Emit(t.Context(), []byte("body"),
		beholder.AttrKeyDomain, "platform",
		beholder.AttrKeyEntity, "TestEvent",
	)
	require.NoError(t, err)

	assert.Eventually(t, func() bool {
		mu.Lock()
		defer mu.Unlock()
		return receivedBatch != nil
	}, 3*time.Second, 50*time.Millisecond)

	require.NoError(t, emitter.Close())

	mu.Lock()
	defer mu.Unlock()
	require.Len(t, receivedBatch.Events, 1)
}

func TestChipIngressBatchEmitterService_EmitAfterClose(t *testing.T) {
	clientMock := mocks.NewClient(t)
	clientMock.EXPECT().Close().Return(nil).Maybe()
	clientMock.
		On("PublishBatch", mock.Anything, mock.Anything).
		Return(successfulPublishResponse(), nil).
		Maybe()

	emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, newTestConfig(), logger.Test(t))
	require.NoError(t, err)
	require.NoError(t, emitter.Start(t.Context()))
	require.NoError(t, emitter.Close())

	err = emitter.Emit(t.Context(), []byte("body"),
		beholder.AttrKeyDomain, "platform",
		beholder.AttrKeyEntity, "TestEvent",
	)
	assert.Error(t, err)
}

func TestChipIngressBatchEmitterService_EmitWithCallback(t *testing.T) {
	t.Run("callback receives nil on success", func(t *testing.T) {
		clientMock := mocks.NewClient(t)
		clientMock.EXPECT().Close().Return(nil).Maybe()
		clientMock.
			On("PublishBatch", mock.Anything, mock.Anything).
			Return(successfulPublishResponse(), nil)

		cfg := newTestConfig()
		cfg.ChipIngressSendInterval = 50 * time.Millisecond

		emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, cfg, logger.Test(t))
		require.NoError(t, err)
		require.NoError(t, emitter.Start(t.Context()))

		done := make(chan error, 1)
		err = emitter.EmitWithCallback(t.Context(), []byte("body"), func(sendErr error) {
			done <- sendErr
		},
			beholder.AttrKeyDomain, "platform",
			beholder.AttrKeyEntity, "TestEvent",
		)
		require.NoError(t, err)

		select {
		case sendErr := <-done:
			assert.NoError(t, sendErr)
		case <-time.After(3 * time.Second):
			t.Fatal("callback was not invoked within timeout")
		}

		require.NoError(t, emitter.Close())
	})

	t.Run("callback receives error on PublishBatch failure", func(t *testing.T) {
		clientMock := mocks.NewClient(t)
		clientMock.EXPECT().Close().Return(nil).Maybe()
		clientMock.
			On("PublishBatch", mock.Anything, mock.Anything).
			Return(nil, assert.AnError)

		cfg := newTestConfig()
		cfg.ChipIngressSendInterval = 50 * time.Millisecond

		emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, cfg, logger.Test(t))
		require.NoError(t, err)
		require.NoError(t, emitter.Start(t.Context()))

		done := make(chan error, 1)
		err = emitter.EmitWithCallback(t.Context(), []byte("body"), func(sendErr error) {
			done <- sendErr
		},
			beholder.AttrKeyDomain, "platform",
			beholder.AttrKeyEntity, "TestEvent",
		)
		require.NoError(t, err)

		select {
		case sendErr := <-done:
			assert.Error(t, sendErr)
		case <-time.After(3 * time.Second):
			t.Fatal("callback was not invoked within timeout")
		}

		require.NoError(t, emitter.Close())
	})

	t.Run("callback receives error when buffer is full", func(t *testing.T) {
		lggr, observed := logger.TestObserved(t, zap.InfoLevel)

		clientMock := mocks.NewClient(t)
		clientMock.EXPECT().Close().Return(nil).Maybe()

		sendBlocked := make(chan struct{})
		firstCallSignal := make(chan struct{}, 1)
		clientMock.
			On("PublishBatch", mock.Anything, mock.Anything).
			Run(func(_ mock.Arguments) {
				select {
				case firstCallSignal <- struct{}{}:
				default:
				}
				<-sendBlocked
			}).
			Return(successfulPublishResponse(), nil).
			Maybe()

		cfg := newTestConfig()
		cfg.ChipIngressBufferSize = 2
		cfg.ChipIngressMaxBatchSize = 1
		cfg.ChipIngressMaxConcurrentSends = 1
		cfg.ChipIngressSendInterval = 50 * time.Millisecond
		cfg.ChipIngressDrainTimeout = 200 * time.Millisecond

		emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, cfg, lggr)
		require.NoError(t, err)
		require.NoError(t, emitter.Start(t.Context()))
		defer close(sendBlocked)
		defer emitter.Close() //nolint:errcheck

		err = emitter.Emit(t.Context(), []byte("body"),
			beholder.AttrKeyDomain, "platform",
			beholder.AttrKeyEntity, "TestEvent",
		)
		require.NoError(t, err)

		<-firstCallSignal
		time.Sleep(100 * time.Millisecond)

		for range 10 {
			_ = emitter.Emit(t.Context(), []byte("filler"),
				beholder.AttrKeyDomain, "platform",
				beholder.AttrKeyEntity, "TestEvent",
			)
		}

		dropped := make(chan error, 1)
		err = emitter.EmitWithCallback(t.Context(), []byte("overflow"), func(sendErr error) {
			dropped <- sendErr
		},
			beholder.AttrKeyDomain, "platform",
			beholder.AttrKeyEntity, "TestEvent",
		)
		assert.NoError(t, err)

		select {
		case dropErr := <-dropped:
			assert.Error(t, dropErr)
		case <-time.After(time.Second):
			t.Fatal("callback was not invoked for dropped event")
		}

		logs := observed.FilterMessage("failed to queue message for chip ingress")
		require.GreaterOrEqual(t, logs.Len(), 1, "expected error log for queue failure")
		entry := logs.All()[0]
		assert.Equal(t, zap.ErrorLevel, entry.Level)
		fieldMap := logFieldMap(entry)
		assert.Contains(t, fieldMap, "error")
		assert.Equal(t, "platform", fieldMap["domain"])
		assert.Equal(t, "TestEvent", fieldMap["entity"])
	})

	t.Run("nil callback behaves like Emit", func(t *testing.T) {
		clientMock := mocks.NewClient(t)
		clientMock.EXPECT().Close().Return(nil).Maybe()
		clientMock.
			On("PublishBatch", mock.Anything, mock.Anything).
			Return(successfulPublishResponse(), nil).
			Maybe()

		cfg := newTestConfig()
		cfg.ChipIngressSendInterval = 50 * time.Millisecond

		emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, cfg, logger.Test(t))
		require.NoError(t, err)
		require.NoError(t, emitter.Start(t.Context()))

		err = emitter.EmitWithCallback(t.Context(), []byte("body"), nil,
			beholder.AttrKeyDomain, "platform",
			beholder.AttrKeyEntity, "TestEvent",
		)
		assert.NoError(t, err)

		require.NoError(t, emitter.Close())
	})
}

func TestChipIngressBatchEmitterService_PartialDeliveryError(t *testing.T) {
	t.Run("does not log on per-event PublishError, only records the metric", func(t *testing.T) {
		lggr, observed := logger.TestObserved(t, zap.InfoLevel)

		clientMock := mocks.NewClient(t)
		clientMock.EXPECT().Close().Return(nil).Maybe()

		partialResp := &chipingress.PublishResponse{
			Results: []*chipingress.PublishResult{
				{
					Error: &chipingress.PublishError{
						ErrorCode: chipingress.PublishErrorCode(1), // VALIDATION_FAILED
						Reason:    "schema not found",
					},
				},
			},
		}
		done := make(chan struct{})
		clientMock.
			On("PublishBatch", mock.Anything, mock.Anything).
			Return(partialResp, nil).
			Run(func(_ mock.Arguments) { close(done) }).
			Once()

		cfg := newTestConfig()
		cfg.ChipIngressMaxBatchSize = 1
		cfg.ChipIngressSendInterval = time.Second

		emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, cfg, lggr)
		require.NoError(t, err)
		require.NoError(t, emitter.Start(t.Context()))

		err = emitter.Emit(t.Context(), []byte("body"),
			beholder.AttrKeyDomain, "platform",
			beholder.AttrKeyEntity, "TestEvent",
		)
		require.NoError(t, err)

		select {
		case <-done:
		case <-time.After(3 * time.Second):
			t.Fatal("timeout waiting for publish")
		}
		require.NoError(t, emitter.Close())

		// Partial delivery is intentionally not logged (see dropMetricAttrsFor / emitInternal):
		// it's a per-event, often persistent condition that would otherwise spam logs at
		// fleet-wide volume. The events_dropped metric (error_code) is the intended signal;
		// see the "records events_dropped" subtest below.
		logs := observed.FilterMessage("failed to emit to chip ingress")
		assert.Zero(t, logs.Len(), "partial delivery drops must not be logged")
	})

	t.Run("records events_dropped with the PublishError code", func(t *testing.T) {
		reader, restore := useEmitterTestMeterProvider(t)
		defer restore()

		clientMock := mocks.NewClient(t)
		clientMock.EXPECT().Close().Return(nil).Maybe()

		partialResp := &chipingress.PublishResponse{
			Results: []*chipingress.PublishResult{
				{
					Error: &chipingress.PublishError{
						ErrorCode: chipingress.PublishErrorCode(1),
						Reason:    "encode error",
					},
				},
			},
		}
		done := make(chan struct{})
		clientMock.
			On("PublishBatch", mock.Anything, mock.Anything).
			Return(partialResp, nil).
			Run(func(_ mock.Arguments) { close(done) }).
			Once()

		cfg := newTestConfig()
		cfg.ChipIngressMaxBatchSize = 1
		cfg.ChipIngressSendInterval = time.Second

		emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, cfg, logger.Test(t))
		require.NoError(t, err)
		require.NoError(t, emitter.Start(t.Context()))

		err = emitter.Emit(t.Context(), []byte("body"),
			beholder.AttrKeyDomain, "platform",
			beholder.AttrKeyEntity, "PartialEvent",
		)
		require.NoError(t, err)

		select {
		case <-done:
		case <-time.After(3 * time.Second):
			t.Fatal("timeout waiting for publish")
		}
		require.NoError(t, emitter.Close())

		rm := collectEmitterMetrics(t, reader)
		metric := mustEmitterMetric(t, rm, "chip_ingress.events_dropped")
		sum, ok := metric.Data.(metricdata.Sum[int64])
		require.True(t, ok)
		dp := mustEmitterInt64SumPoint(t, sum, "domain", "platform", "entity", "PartialEvent")
		assert.True(t, hasEmitterStringAttr(dp.Attributes, "error_code", "PUBLISH_ERROR_CODE_VALIDATION_FAILED"))
		assert.True(t, hasEmitterStringAttr(dp.Attributes, "client_name", batch.ClientNameBeholder))
		assert.GreaterOrEqual(t, dp.Value, int64(1))
	})
}

func TestChipIngressBatchEmitterService_RPCError(t *testing.T) {
	t.Run("records events_dropped with error_code on RPC failure", func(t *testing.T) {
		reader, restore := useEmitterTestMeterProvider(t)
		defer restore()

		clientMock := mocks.NewClient(t)
		clientMock.EXPECT().Close().Return(nil).Maybe()

		done := make(chan struct{})
		clientMock.
			On("PublishBatch", mock.Anything, mock.Anything).
			Return(nil, status.Error(codes.Internal, "failed to publish events")).
			Run(func(_ mock.Arguments) { close(done) }).
			Once()

		cfg := newTestConfig()
		cfg.ChipIngressMaxBatchSize = 1
		cfg.ChipIngressSendInterval = time.Second

		emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, cfg, logger.Test(t))
		require.NoError(t, err)
		require.NoError(t, emitter.Start(t.Context()))

		err = emitter.Emit(t.Context(), []byte("body"),
			beholder.AttrKeyDomain, "platform",
			beholder.AttrKeyEntity, "RPCDropEvent",
		)
		require.NoError(t, err)

		select {
		case <-done:
		case <-time.After(3 * time.Second):
			t.Fatal("timeout waiting for publish")
		}
		require.NoError(t, emitter.Close())

		rm := collectEmitterMetrics(t, reader)
		metric := mustEmitterMetric(t, rm, "chip_ingress.events_dropped")
		sum, ok := metric.Data.(metricdata.Sum[int64])
		require.True(t, ok)
		dp := mustEmitterInt64SumPoint(t, sum, "domain", "platform", "entity", "RPCDropEvent")
		assert.True(t, hasEmitterStringAttr(dp.Attributes, "error_code", "Internal"))
		assert.True(t, hasEmitterStringAttr(dp.Attributes, "client_name", batch.ClientNameBeholder))
		assert.GreaterOrEqual(t, dp.Value, int64(1))
		// error_reason is free-form server/gRPC text and must never be a metric attribute -
		// it would create unbounded cardinality. It's still available on the log line.
		assert.False(t, hasEmitterStringAttr(dp.Attributes, "error_reason", "failed to publish events"))
	})
}

func TestChipIngressBatchEmitterService_Metrics(t *testing.T) {
	t.Run("records events_sent on successful publish", func(t *testing.T) {
		reader, restore := useEmitterTestMeterProvider(t)
		defer restore()

		clientMock := mocks.NewClient(t)
		clientMock.EXPECT().Close().Return(nil).Maybe()
		done := make(chan struct{})
		clientMock.
			On("PublishBatch", mock.Anything, mock.Anything).
			Return(successfulPublishResponse(), nil).
			Run(func(_ mock.Arguments) { close(done) }).
			Once()

		cfg := newTestConfig()
		cfg.ChipIngressMaxBatchSize = 1
		cfg.ChipIngressSendInterval = time.Second
		emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, cfg, logger.Test(t))
		require.NoError(t, err)
		require.NoError(t, emitter.Start(t.Context()))

		err = emitter.Emit(t.Context(), []byte("body"),
			beholder.AttrKeyDomain, "platform",
			beholder.AttrKeyEntity, "MetricEvent",
		)
		require.NoError(t, err)

		select {
		case <-done:
		case <-time.After(time.Second):
			t.Fatal("timeout waiting for publish")
		}
		require.NoError(t, emitter.Close())

		rm := collectEmitterMetrics(t, reader)
		metric := mustEmitterMetric(t, rm, "chip_ingress.events_sent")
		sum, ok := metric.Data.(metricdata.Sum[int64])
		require.True(t, ok)
		dp := mustEmitterInt64SumPoint(t, sum, "domain", "platform", "entity", "MetricEvent")
		assert.True(t, hasEmitterStringAttr(dp.Attributes, "client_name", batch.ClientNameBeholder))
		assert.GreaterOrEqual(t, dp.Value, int64(1))
	})

	t.Run("records events_dropped on publish error", func(t *testing.T) {
		reader, restore := useEmitterTestMeterProvider(t)
		defer restore()

		lggr, observed := logger.TestObserved(t, zap.InfoLevel)

		clientMock := mocks.NewClient(t)
		clientMock.EXPECT().Close().Return(nil).Maybe()
		done := make(chan struct{})
		clientMock.
			On("PublishBatch", mock.Anything, mock.Anything).
			Return(nil, status.Error(codes.DeadlineExceeded, "context deadline exceeded")).
			Run(func(_ mock.Arguments) { close(done) }).
			Once()

		cfg := newTestConfig()
		cfg.ChipIngressMaxBatchSize = 1
		cfg.ChipIngressSendInterval = time.Second
		emitter, err := beholder.NewChipIngressBatchEmitterService(clientMock, cfg, lggr)
		require.NoError(t, err)
		require.NoError(t, emitter.Start(t.Context()))

		err = emitter.Emit(t.Context(), []byte("body"),
			beholder.AttrKeyDomain, "platform",
			beholder.AttrKeyEntity, "MetricDropEvent",
		)
		require.NoError(t, err)

		select {
		case <-done:
		case <-time.After(time.Second):
			t.Fatal("timeout waiting for publish")
		}
		require.NoError(t, emitter.Close())

		rm := collectEmitterMetrics(t, reader)
		metric := mustEmitterMetric(t, rm, "chip_ingress.events_dropped")
		sum, ok := metric.Data.(metricdata.Sum[int64])
		require.True(t, ok)
		dp := mustEmitterInt64SumPoint(t, sum, "domain", "platform", "entity", "MetricDropEvent")
		assert.True(t, hasEmitterStringAttr(dp.Attributes, "error_code", "DeadlineExceeded"))
		assert.True(t, hasEmitterStringAttr(dp.Attributes, "client_name", batch.ClientNameBeholder))
		assert.GreaterOrEqual(t, dp.Value, int64(1))

		logs := observed.FilterMessage("failed to emit to chip ingress")
		require.GreaterOrEqual(t, logs.Len(), 1, "expected error log for publish failure")
		entry := logs.All()[0]
		assert.Equal(t, zap.ErrorLevel, entry.Level)
		fieldMap := logFieldMap(entry)
		assert.Contains(t, fieldMap, "error")
		assert.Equal(t, "DeadlineExceeded", fieldMap["error_code"])
		assert.Equal(t, "platform", fieldMap["domain"])
		assert.Equal(t, "MetricDropEvent", fieldMap["entity"])
	})
}

func logFieldMap(entry observer.LoggedEntry) map[string]string {
	m := make(map[string]string)
	for _, f := range entry.Context {
		if f.Interface != nil {
			m[f.Key] = fmt.Sprintf("%v", f.Interface)
		} else if f.String != "" {
			m[f.Key] = f.String
		}
	}
	return m
}

func BenchmarkChipIngressBatchEmitterService_Emit(b *testing.B) {
	cfg := beholder.Config{
		ChipIngressBufferSize:         uint(b.N + 10),
		ChipIngressMaxBatchSize:       uint(b.N + 1),
		ChipIngressMaxConcurrentSends: 1,
		ChipIngressSendInterval:       time.Hour,
		ChipIngressSendTimeout:        5 * time.Second,
		ChipIngressDrainTimeout:       5 * time.Second,
		ChipIngressMaxGRPCRequestSize: 1024 * 1024,
	}
	emitter, err := beholder.NewChipIngressBatchEmitterService(&chipingress.NoopClient{}, cfg, logger.Test(b))
	if err != nil {
		b.Fatal(err)
	}
	if err := emitter.Start(b.Context()); err != nil {
		b.Fatal(err)
	}
	defer func() { _ = emitter.Close() }()

	payload := []byte("benchmark-payload")
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if err := emitter.Emit(b.Context(), payload,
			beholder.AttrKeyDomain, "bench",
			beholder.AttrKeyEntity, "BenchmarkEvent",
		); err != nil {
			b.Fatal(err)
		}
	}
}

func useEmitterTestMeterProvider(t *testing.T) (*sdkmetric.ManualReader, func()) {
	t.Helper()
	prev := otel.GetMeterProvider()
	reader := sdkmetric.NewManualReader()
	provider := sdkmetric.NewMeterProvider(sdkmetric.WithReader(reader))
	otel.SetMeterProvider(provider)
	return reader, func() {
		require.NoError(t, provider.Shutdown(t.Context()))
		otel.SetMeterProvider(prev)
	}
}

func collectEmitterMetrics(t *testing.T, reader *sdkmetric.ManualReader) metricdata.ResourceMetrics {
	t.Helper()
	var rm metricdata.ResourceMetrics
	require.NoError(t, reader.Collect(t.Context(), &rm))
	return rm
}

func mustEmitterMetric(t *testing.T, rm metricdata.ResourceMetrics, name string) metricdata.Metrics {
	t.Helper()
	for _, sm := range rm.ScopeMetrics {
		for _, metric := range sm.Metrics {
			if metric.Name == name {
				return metric
			}
		}
	}
	t.Fatalf("metric %q not found", name)
	return metricdata.Metrics{}
}

func mustEmitterInt64SumPoint(t *testing.T, sum metricdata.Sum[int64], k1, v1, k2, v2 string) metricdata.DataPoint[int64] {
	t.Helper()
	for _, dp := range sum.DataPoints {
		if hasEmitterStringAttr(dp.Attributes, k1, v1) && hasEmitterStringAttr(dp.Attributes, k2, v2) {
			return dp
		}
	}
	t.Fatalf("sum datapoint not found for attrs %s=%s,%s=%s", k1, v1, k2, v2)
	return metricdata.DataPoint[int64]{}
}

func hasEmitterStringAttr(set attribute.Set, key, want string) bool {
	for _, kv := range set.ToSlice() {
		if string(kv.Key) == key {
			return kv.Value.AsString() == want
		}
	}
	return false
}
