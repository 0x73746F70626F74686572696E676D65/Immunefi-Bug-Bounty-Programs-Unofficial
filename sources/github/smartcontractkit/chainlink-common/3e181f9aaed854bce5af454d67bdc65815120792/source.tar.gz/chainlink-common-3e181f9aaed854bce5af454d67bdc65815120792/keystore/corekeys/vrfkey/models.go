package vrfkey

import (
	"bytes"
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"os"
	"time"

	"github.com/ethereum/go-ethereum/accounts/keystore"

	"github.com/smartcontractkit/chainlink-common/keystore/corekeys/vrfkey/secp256k1"
	"github.com/smartcontractkit/chainlink-common/keystore/internal/atomicfile"
)

// EncryptedVRFKey contains encrypted private key to be serialized to DB
//
// We could re-use geth's key handling, here, but this makes it much harder to
// misuse VRF proving keys as ethereum keys or vice versa.
type EncryptedVRFKey struct {
	PublicKey secp256k1.PublicKey
	VRFKey    gethKeyStruct `json:"vrf_key"`
	CreatedAt time.Time     `json:"-"`
	UpdatedAt time.Time     `json:"-"`
	DeletedAt *time.Time    `json:"-"`
}

// JSON returns the JSON representation of e, or errors
func (e *EncryptedVRFKey) JSON() ([]byte, error) {
	keyJSON, err := json.Marshal(e)
	if err != nil {
		return nil, fmt.Errorf("could not marshal encrypted key to JSON: %w", err)
	}
	return keyJSON, nil
}

// WriteToDisk writes the JSON representation of e to given file path, and
// ensures the file has appropriate access permissions
func (e *EncryptedVRFKey) WriteToDisk(path string) error {
	keyJSON, err := e.JSON()
	if err != nil {
		return fmt.Errorf("while marshaling key to save to %s: %w", path, err)
	}
	userReadWriteOtherNoAccess := os.FileMode(0600)
	return atomicfile.WriteFile(path, bytes.NewReader(keyJSON), userReadWriteOtherNoAccess)
}

// Copied from go-ethereum/accounts/keystore/key.go's encryptedKeyJSONV3
type gethKeyStruct struct {
	Address string              `json:"address"`
	Crypto  keystore.CryptoJSON `json:"crypto"`
	Version int                 `json:"version"`
}

func (k gethKeyStruct) Value() (driver.Value, error) {
	return json.Marshal(&k)
}

func (k *gethKeyStruct) Scan(value any) error {
	var toUnmarshal []byte
	switch s := value.(type) {
	case []byte:
		toUnmarshal = s
	case string:
		toUnmarshal = []byte(s)
	default:
		return fmt.Errorf("scan failure: unable to convert %+v of type %T to gethKeyStruct", value, value)
	}
	return json.Unmarshal(toUnmarshal, k)
}
