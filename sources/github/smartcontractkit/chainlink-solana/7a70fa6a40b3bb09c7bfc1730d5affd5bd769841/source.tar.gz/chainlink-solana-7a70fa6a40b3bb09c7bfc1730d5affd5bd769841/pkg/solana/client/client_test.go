//go:build !race

// TestClient_SendTxDuplicates_Integration runs out of funds sometimes...

package client

import (
	"fmt"
	"math/rand"
	"net/http"
	"net/http/httptest"
	"sync"
	"testing"
	"time"

	"github.com/gagliardetto/solana-go"
	"github.com/gagliardetto/solana-go/programs/system"
	"github.com/gagliardetto/solana-go/rpc"
	"github.com/google/uuid"
	"github.com/prometheus/client_golang/prometheus"
	io_prometheus_client "github.com/prometheus/client_model/go"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/smartcontractkit/chainlink-common/pkg/logger"
	"github.com/smartcontractkit/chainlink-framework/metrics"
	mn "github.com/smartcontractkit/chainlink-framework/multinode"

	"github.com/smartcontractkit/chainlink-solana/pkg/solana/config"
	solanatesting "github.com/smartcontractkit/chainlink-solana/pkg/solana/testing"
)

func TestClient_Reader_Integration(t *testing.T) {
	ctx := t.Context()
	url := solanatesting.SetupLocalSolNode(t)
	privKey, err := solana.NewRandomPrivateKey()
	require.NoError(t, err)
	pubKey := privKey.PublicKey()
	solanatesting.FundTestAccounts(t, []solana.PublicKey{pubKey}, url)

	requestTimeout := 5 * time.Second
	lggr := logger.Test(t)
	cfg := config.NewDefault()

	c, err := NewClient(url, cfg, requestTimeout, lggr)
	require.NoError(t, err)

	// check balance
	bal, err := c.Balance(ctx, pubKey)
	assert.NoError(t, err)
	assert.Equal(t, 100*solana.LAMPORTS_PER_SOL, bal) // once funds get sent to the system program it should be unrecoverable (so this number should remain > 0)

	// check SlotHeight
	slot0, err := c.SlotHeight(ctx)
	assert.NoError(t, err)
	assert.Greater(t, slot0, uint64(0))
	time.Sleep(time.Second)
	slot1, err := c.SlotHeight(ctx)
	assert.NoError(t, err)
	assert.Greater(t, slot1, slot0)

	// fetch recent blockhash
	hash, err := c.LatestBlockhash(ctx)
	assert.NoError(t, err)
	assert.NotEqual(t, hash.Value.Blockhash, solana.Hash{}) // not an empty hash

	// GetFeeForMessage (transfer to self, successful)
	tx, err := solana.NewTransaction(
		[]solana.Instruction{
			system.NewTransferInstruction(
				1,
				pubKey,
				pubKey,
			).Build(),
		},
		hash.Value.Blockhash,
		solana.TransactionPayer(pubKey),
	)
	assert.NoError(t, err)

	fee, err := c.GetFeeForMessage(ctx, tx.Message.ToBase64())
	assert.NoError(t, err)
	assert.Equal(t, uint64(5000), fee)

	// get account info (also tested inside contract_test)
	res, err := c.GetAccountInfoWithOpts(ctx, solana.PublicKey{}, &rpc.GetAccountInfoOpts{Commitment: rpc.CommitmentFinalized})
	assert.NoError(t, err)
	assert.Equal(t, uint64(1), res.Value.Lamports)
	assert.Equal(t, "NativeLoader1111111111111111111111111111111", res.Value.Owner.String())

	// get block + check for nonzero values
	block, err := c.GetLatestBlock(ctx)
	require.NoError(t, err)
	assert.NotEqual(t, solana.Hash{}, block.Blockhash)
	assert.NotEqual(t, uint64(0), block.ParentSlot)
	assert.NotEqual(t, uint64(0), block.ParentSlot)

	// GetBlock
	// Test fetching a valid block
	block, err = c.GetBlock(ctx, slot0)
	assert.NoError(t, err)
	assert.NotNil(t, block)
	assert.Equal(t, slot0, block.ParentSlot+1)
	assert.NotEqual(t, solana.Hash{}, block.Blockhash)

	// Test fetching a block with an invalid future slot
	futureSlot := slot0 + 1000000
	block, err = c.GetBlock(ctx, futureSlot)
	assert.Error(t, err)
	assert.Nil(t, block)

	// GetBlocksWithLimit
	// Define the limit of blocks to fetch and calculate the start slot
	limit := uint64(10)
	startSlot := slot0 - limit + 1

	// Fetch blocks with limit
	blocksResult, err := c.GetBlocksWithLimit(ctx, startSlot, limit)
	assert.NoError(t, err)
	assert.NotNil(t, blocksResult)

	// Verify that the slots returned are within the expected range
	for _, slot := range *blocksResult {
		assert.GreaterOrEqual(t, slot, startSlot)
		assert.LessOrEqual(t, slot, slot0)
	}

	// GetLatestBlockHeight
	// Test fetching the latest block height
	blockHeight, err := c.GetLatestBlockHeight(ctx)
	require.NoError(t, err)
	require.Greater(t, blockHeight, uint64(0), "Block height should be greater than 0")
}

func TestClient_Reader_ChainID(t *testing.T) {
	ctx := t.Context()
	genesisHashes := []string{
		DevnetGenesisHash,  // devnet
		TestnetGenesisHash, // testnet
		MainnetGenesisHash, // mainnet
		"GH7ome3EiwEr7tu9JuTh2dpYWBJK3z69Xm1ZE3MEE6JC", // localnet (random)
	}
	hashCounter := 0

	mockServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		out := fmt.Sprintf(`{"jsonrpc":"2.0","result":"%s","id":1}`, genesisHashes[hashCounter])
		hashCounter++
		_, err := w.Write([]byte(out))
		require.NoError(t, err)
	}))
	defer mockServer.Close()

	requestTimeout := 5 * time.Second
	lggr := logger.Test(t)
	cfg := config.NewDefault()
	c, err := NewClient(mockServer.URL, cfg, requestTimeout, lggr)
	require.NoError(t, err)

	// get chain ID based on gensis hash
	for _, hash := range genesisHashes {
		network, err := c.ChainID(ctx)
		assert.NoError(t, err)
		if network == "localnet" {
			continue
		}
		assert.Equal(t, mn.StringID(hash), network)
	}
}

func TestClient_Writer_Integration(t *testing.T) {
	url := solanatesting.SetupLocalSolNode(t)
	privKey, err := solana.NewRandomPrivateKey()
	require.NoError(t, err)
	pubKey := privKey.PublicKey()
	solanatesting.FundTestAccounts(t, []solana.PublicKey{pubKey}, url)

	requestTimeout := 5 * time.Second
	lggr := logger.Test(t)
	cfg := config.NewDefault()

	ctx := t.Context()
	c, err := NewClient(url, cfg, requestTimeout, lggr)
	require.NoError(t, err)

	// create + sign transaction
	createTx := func(to solana.PublicKey) *solana.Transaction {
		hash, hashErr := c.LatestBlockhash(ctx)
		assert.NoError(t, hashErr)

		tx, txErr := solana.NewTransaction(
			[]solana.Instruction{
				system.NewTransferInstruction(
					1,
					pubKey,
					to,
				).Build(),
			},
			hash.Value.Blockhash,
			solana.TransactionPayer(pubKey),
		)
		assert.NoError(t, txErr)
		_, signErr := tx.Sign(
			func(key solana.PublicKey) *solana.PrivateKey {
				if pubKey.Equals(key) {
					return &privKey
				}
				return nil
			},
		)
		assert.NoError(t, signErr)
		return tx
	}

	// simulate successful transcation
	txSuccess := createTx(pubKey)
	simSuccess, err := c.SimulateTx(ctx, txSuccess, nil)
	assert.NoError(t, err)
	assert.Nil(t, simSuccess.Err)
	assert.Equal(t, 0, len(simSuccess.Accounts)) // default option, no accounts requested

	// simulate successful transcation with custom options
	simCustom, err := c.SimulateTx(ctx, txSuccess, &rpc.SimulateTransactionOpts{
		Commitment: c.commitment,
		Accounts: &rpc.SimulateTransactionAccountsOpts{
			Encoding:  solana.EncodingBase64,
			Addresses: txSuccess.Message.AccountKeys, // request data for accounts in the tx
		},
	})
	assert.NoError(t, err)
	assert.Equal(t, len(txSuccess.Message.AccountKeys), len(simCustom.Accounts)) // data should be returned for the accounts in the tx

	// simulate failed transaction
	txFail := createTx(solana.MustPublicKeyFromBase58("11111111111111111111111111111111"))
	simFail, err := c.SimulateTx(ctx, txFail, nil)
	assert.NoError(t, err)
	assert.NotNil(t, simFail.Err)

	// send successful + failed tx to get tx signatures
	sigSuccess, err := c.SendTx(ctx, txSuccess)
	assert.NoError(t, err)

	sigFail, err := c.SendTx(ctx, txFail)
	assert.NoError(t, err)

	// check signature statuses
	// try waiting for tx to execute - reduce flakiness
	require.Eventually(t, func() bool {
		res, statusErr := c.SignatureStatuses(ctx, []solana.Signature{sigSuccess, sigFail})
		require.NoError(t, statusErr)
		require.Equal(t, 2, len(res))
		if res[0] == nil || res[1] == nil {
			return false
		}
		require.Nil(t, res[0].Err)
		require.NotNil(t, res[1].Err)
		return true
	}, 5*time.Second, 500*time.Millisecond)

	getTxResult, err := c.GetTransaction(ctx, sigSuccess)
	assert.NoError(t, err)
	assert.NotNil(t, getTxResult)

	sigs, err := c.GetSignaturesForAddressWithOpts(ctx, pubKey, nil)
	assert.NoError(t, err)
	requiredSigs := map[solana.Signature]bool{
		sigSuccess: false,
		sigFail:    false,
	}
	for _, sig := range sigs {
		if _, required := requiredSigs[sig.Signature]; required {
			requiredSigs[sig.Signature] = true
		}
	}
	require.True(t, requiredSigs[sigSuccess] && requiredSigs[sigFail])
}

func TestClient_GetBlocks(t *testing.T) {
	url := solanatesting.SetupLocalSolNode(t)

	requestTimeout := 5 * time.Second
	lggr := logger.Test(t)
	cfg := config.NewDefault()

	ctx := t.Context()
	c, err := NewClient(url, cfg, requestTimeout, lggr)
	require.NoError(t, err)

	// Verify we can retrieve blocks
	startSlot := uint64(1)
	endSlot := uint64(10)
	require.Eventually(t,
		func() bool {
			blocks, err := c.GetBlocks(ctx, startSlot, &endSlot)
			require.NoError(t, err) // don't mask error within false
			return len(blocks) >= 2 // slots != blocks (expect multiple blocks for 10 slots)
		},
		requestTimeout, 500*time.Millisecond)
}

func TestClient_GetLatestBlockHeight(t *testing.T) {
	t.Parallel()

	ctx := t.Context()
	url := solanatesting.SetupLocalSolNode(t)
	requestTimeout := 5 * time.Second
	lggr := logger.Test(t)
	cfg := config.NewDefault()

	// Initialize the client
	c, err := NewClient(url, cfg, requestTimeout, lggr)
	require.NoError(t, err)

	// Get the latest block height
	blockHeight, err := c.GetLatestBlockHeight(ctx)
	require.NoError(t, err)
	require.Greater(t, blockHeight, uint64(0), "Block height should be greater than 0")

	// Wait until the block height increases
	require.Eventually(t, func() bool {
		newBlockHeight, err := c.GetLatestBlockHeight(ctx)
		require.NoError(t, err)
		return newBlockHeight > blockHeight
	}, 10*time.Second, 1*time.Second, "Block height should eventually increase")
}

func TestClient_SendTxDuplicates_Integration(t *testing.T) {
	ctx := t.Context()
	// set up environment
	url := solanatesting.SetupLocalSolNode(t)
	privKey, err := solana.NewRandomPrivateKey()
	require.NoError(t, err)
	pubKey := privKey.PublicKey()
	solanatesting.FundTestAccounts(t, []solana.PublicKey{pubKey}, url)

	// create client
	requestTimeout := 5 * time.Second
	lggr := logger.Test(t)
	cfg := config.NewDefault()
	c, err := NewClient(url, cfg, requestTimeout, lggr)
	require.NoError(t, err)

	// fetch recent blockhash
	hash, err := c.LatestBlockhash(ctx)
	assert.NoError(t, err)

	initBal, err := c.Balance(ctx, pubKey)
	assert.NoError(t, err)

	// create + sign tx
	// tx sends tokens to self
	tx, err := solana.NewTransaction(
		[]solana.Instruction{
			system.NewTransferInstruction(
				1,
				pubKey,
				pubKey,
			).Build(),
		},
		hash.Value.Blockhash,
		solana.TransactionPayer(pubKey),
	)
	assert.NoError(t, err)
	_, err = tx.Sign(
		func(key solana.PublicKey) *solana.PrivateKey {
			if pubKey.Equals(key) {
				return &privKey
			}
			return nil
		},
	)
	assert.NoError(t, err)

	// send 5 of the same transcation
	n := 5
	sigs := make([]solana.Signature, n)
	var wg sync.WaitGroup
	wg.Add(5)
	for i := 0; i < n; i++ {
		go func(i int) {
			time.Sleep(time.Duration(rand.Intn(500)) * time.Millisecond) // randomly submit txs
			sig, sendErr := c.SendTx(ctx, tx)
			assert.NoError(t, sendErr)
			sigs[i] = sig
			wg.Done()
		}(i)
	}
	wg.Wait()

	// expect one single transaction hash
	for i := 1; i < n; i++ {
		assert.Equal(t, sigs[0], sigs[i])
	}

	// try waiting for tx to execute - reduce flakiness
	require.Eventually(t, func() bool {
		res, statusErr := c.SignatureStatuses(ctx, []solana.Signature{sigs[0]})
		require.NoError(t, statusErr)
		require.Equal(t, 1, len(res))
		if res[0] == nil {
			return false
		}
		return res[0].ConfirmationStatus == rpc.ConfirmationStatusConfirmed || res[0].ConfirmationStatus == rpc.ConfirmationStatusFinalized
	}, 5*time.Second, 500*time.Millisecond)

	// expect one sender has only sent one tx
	// original balance - current bal = 5000 lamports (tx fee)
	endBal, err := c.Balance(ctx, pubKey)
	assert.NoError(t, err)
	assert.Equal(t, uint64(5_000), initBal-endBal)
}

func TestClientLatency(t *testing.T) {
	c := Client{}
	v := 100
	n := t.Name() + uuid.NewString()
	f := func() {
		done := c.latency(n)
		defer done(nil)
		time.Sleep(time.Duration(v) * time.Millisecond)
	}
	f()

	labels := prometheus.Labels{
		"chainFamily": metrics.Solana,
		"chainID":     c.chainID,
		"rpcUrl":      metrics.SanitizeRPCURL(c.url),
		"isSendOnly":  "false",
		"success":     "true",
		"rpcCallName": n,
	}

	metric, err := metrics.RPCCallLatency.GetMetricWith(labels)
	require.NoError(t, err)
	hist, ok := metric.(prometheus.Histogram)
	require.True(t, ok)

	// Collect histogram metric
	ch := make(chan prometheus.Metric, 1)
	hist.Collect(ch)
	m := <-ch
	dto := &io_prometheus_client.Metric{}
	err = m.Write(dto)
	require.NoError(t, err)

	count := dto.GetHistogram().GetSampleCount()
	sum := dto.GetHistogram().GetSampleSum()
	avg := sum / float64(count)

	// Check within expected range
	expected := float64((time.Duration(v) * time.Millisecond).Nanoseconds())
	assert.GreaterOrEqual(t, avg, expected)
	assert.LessOrEqual(t, avg, expected*1.05)
}
