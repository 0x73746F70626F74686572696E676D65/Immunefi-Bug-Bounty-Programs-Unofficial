package solana

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"math/big"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gagliardetto/solana-go"
	"github.com/gagliardetto/solana-go/rpc"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/smartcontractkit/chainlink-common/pkg/logger"

	"github.com/smartcontractkit/chainlink-solana/pkg/solana/client"
	"github.com/smartcontractkit/chainlink-solana/pkg/solana/config"
)

var mockTransmission = []byte{
	96, 179, 69, 66, 128, 129, 73, 117, 2, 0, 42, 195,
	51, 245, 109, 152, 157, 191, 52, 252, 122, 195, 60, 136,
	46, 95, 164, 123, 7, 132, 62, 133, 183, 255, 55, 14,
	134, 167, 4, 188, 130, 218, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 153, 56, 154, 99, 168, 217, 60, 195, 166, 70,
	52, 237, 80, 50, 218, 93, 164, 123, 170, 66, 255, 168,
	40, 27, 40, 194, 147, 199, 20, 178, 51, 196, 69, 84,
	72, 47, 66, 84, 67, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 18, 128, 56, 1, 0, 13,
	0, 0, 0, 30, 3, 0, 0, 0, 1, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 64, 0, 0, 0,
	0, 0, 0, 0, 83, 43, 91, 97, 0, 0, 0, 0,
	14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 58, 0, 0, 0,
	0, 0, 0, 0, 83, 43, 91, 97, 0, 0, 0, 0,
	12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 61, 0, 0, 0,
	0, 0, 0, 0, 83, 43, 91, 97, 0, 0, 0, 0,
	13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
}

var (
	expectedTime = uint32(1633364819)
	expectedAns  = big.NewInt(14).String()
)

type mockRequest struct {
	Method  string
	Params  []json.RawMessage
	ID      string
	JSONRPC string
}

func testStateResponse() []byte {
	value := base64.StdEncoding.EncodeToString(mockState.Raw)
	res := fmt.Sprintf(`{"jsonrpc":"2.0","result":{"context": {"slot":1},"value": {"data":["%s","base64"],"executable": false,"lamports": 1000000000,"owner": "11111111111111111111111111111111","rentEpoch":2}},"id":1}`, value)
	return []byte(res)
}

func testTransmissionsResponse(t *testing.T, body []byte, sub uint64) []byte {
	// parse message
	var msg mockRequest
	err := json.Unmarshal(body, &msg)
	require.NoError(t, err)
	var opts rpc.GetAccountInfoOpts
	err = json.Unmarshal(msg.Params[1], &opts)
	require.NoError(t, err)

	// create response
	mock := mockTransmission
	value := base64.StdEncoding.EncodeToString(mock[*opts.DataSlice.Offset : *opts.DataSlice.Offset+*opts.DataSlice.Length-sub])
	res := fmt.Sprintf(`{"jsonrpc":"2.0","result":{"context": {"slot":1},"value": {"data":["%s","base64"],"executable": false,"lamports": 1000000000,"owner": "11111111111111111111111111111111","rentEpoch":2}},"id":1}`, value)
	return []byte(res)
}

func testSetupReader(t *testing.T, endpoint string) client.Reader {
	lggr := logger.Test(t)
	cfg := config.NewDefault()
	client, err := client.NewClient(endpoint, cfg, 1*time.Second, lggr)
	require.NoError(t, err)
	return client
}

func TestGetState(t *testing.T) {
	mockServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, err := w.Write(testStateResponse())
		require.NoError(t, err)
	}))
	defer mockServer.Close()

	reader := testSetupReader(t, mockServer.URL)
	getReader := func() (client.AccountReader, error) { return reader, nil }
	// happy path does not error (actual state decoding handled in types_test)
	_, _, err := GetState(t.Context(), getReader, solana.PublicKey{}, "")
	require.NoError(t, err)
}

func TestGetLatestTransmission(t *testing.T) {
	// each GetLatestTransmission submits two API requests
	// 0 + 0: everything passes
	// 1 (+ 0): return too short cursor (fail on first API request)
	// 0 + 1: return too short transmission
	// 0 + 0: everything passes (v1 config)
	offsets := []uint64{0, 0, 1, 0, 1, 0, 0}
	i := 0
	mockServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var sub = offsets[i]   // change offset depending on when called
		defer func() { i++ }() // increment

		// read message
		body, err := io.ReadAll(r.Body)
		require.NoError(t, err)

		_, err = w.Write(testTransmissionsResponse(t, body, sub))
		require.NoError(t, err)
	}))
	defer mockServer.Close()

	reader := testSetupReader(t, mockServer.URL)
	getReader := func() (client.AccountReader, error) { return reader, nil }
	a, _, err := GetLatestTransmission(t.Context(), getReader, solana.PublicKey{}, "")
	assert.NoError(t, err)
	assert.Equal(t, expectedTime, a.Timestamp)
	assert.Equal(t, expectedAns, a.Data.String())

	// fail if returned transmission header is too short
	_, _, err = GetLatestTransmission(t.Context(), getReader, solana.PublicKey{}, "")
	assert.Error(t, err)

	// fail if returned transmission is too short
	_, _, err = GetLatestTransmission(t.Context(), getReader, solana.PublicKey{}, "")
	assert.Error(t, err)
}

func TestCache(t *testing.T) {
	ctx := t.Context()
	mockServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// create response
		body, err := io.ReadAll(r.Body)
		require.NoError(t, err)

		// state query
		if bytes.Contains(body, []byte("11111111111111111111111111111111")) {
			// Drop error, client may cancel ctx.
			w.Write(testStateResponse()) //nolint:errcheck
			return
		}

		// transmissions query
		// Drop error, client may cancel ctx.
		w.Write(testTransmissionsResponse(t, body, 0)) //nolint:errcheck
	}))

	reader := testSetupReader(t, mockServer.URL)
	getAccountReader := func() (client.AccountReader, error) { return reader, nil }

	lggr := logger.Test(t)
	stateCache := NewStateCache(
		solana.MustPublicKeyFromBase58("11111111111111111111111111111111"),
		"test-chain-id",
		config.NewDefault(),
		getAccountReader,
		lggr,
	)
	require.NoError(t, stateCache.Start(ctx))
	require.NoError(t, stateCache.Close())
	require.NoError(t, stateCache.Fetch(ctx))
	state, err := stateCache.Read()
	require.NoError(t, err)
	assert.Equal(t, "GADeYvXjPwZP7ds1yDY9VFp12bNjdxT1YyksMvFGK9xn", state.Transmissions.String())
	assert.True(t, !stateCache.Timestamp().IsZero())

	transmissionsCache := NewTransmissionsCache(
		solana.MustPublicKeyFromBase58("11111111111111111111111111111112"),
		"test-chain-id",
		config.NewDefault(),
		getAccountReader,
		lggr,
	)
	require.NoError(t, transmissionsCache.Start(ctx))
	require.NoError(t, transmissionsCache.Close())

	require.NoError(t, transmissionsCache.Fetch(ctx))
	answer, err := transmissionsCache.Read()
	assert.NoError(t, err)
	assert.Equal(t, expectedTime, answer.Timestamp)
	assert.Equal(t, expectedAns, answer.Data.String())
	mockServer.Close()
}

func TestNilPointerHandling(t *testing.T) {
	passFirst := false
	mockServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var data []byte
		if passFirst {
			// successful transmissions query
			body, err := io.ReadAll(r.Body)
			require.NoError(t, err)
			data = testTransmissionsResponse(t, body, 0)
			passFirst = false
		} else {
			// bad payload missing data
			data = []byte(`{"jsonrpc":"2.0","result":{"context": {"slot":1},"value": {"executable": false,"lamports": 1000000000,"owner": "11111111111111111111111111111111","rentEpoch":2}},"id":1}`)
		}
		_, err := w.Write(data)
		require.NoError(t, err)
	}))
	defer mockServer.Close()

	errString := "nil pointer returned in "

	reader := testSetupReader(t, mockServer.URL)
	getReader := func() (client.AccountReader, error) { return reader, nil }

	// fail on get state query
	_, _, err := GetState(t.Context(), getReader, solana.PublicKey{}, "")
	assert.EqualError(t, err, errString+"GetState.GetAccountInfoWithOpts")

	// fail on transmissions header query
	_, _, err = GetLatestTransmission(t.Context(), getReader, solana.PublicKey{}, "")
	assert.EqualError(t, err, errString+"GetLatestTransmission.GetAccountInfoWithOpts.Header")

	passFirst = true // allow proper response for header query, fail on transmission
	_, _, err = GetLatestTransmission(t.Context(), getReader, solana.PublicKey{}, "")
	assert.EqualError(t, err, errString+"GetLatestTransmission.GetAccountInfoWithOpts.Transmission")
}
