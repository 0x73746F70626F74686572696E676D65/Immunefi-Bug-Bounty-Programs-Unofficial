#![allow(deprecated)] // anchor-lang 0.31 #[program] macro uses AccountInfo::realloc
use anchor_lang::prelude::*;

declare_id!("J1zQwrBNBngz26jRPNWsUSZMHJwBwpkoDitXRV95LdK4");

pub mod event;

#[program]
pub mod log_read_test {
    use super::*;

    pub fn create_log(_ctx: Context<Initialization>, value: u64) -> Result<()> {
        emit!(event::TestEvent {
            str_val: "Hello, World!".to_string(),
            u64_value: value,
        });

        Ok(())
    }

    pub fn create_truncated_log(_ctx: Context<Initialization>, value: u64) -> Result<()> {
        for _i in 0..100 {
            msg!("Filler message to take up log space: 00000000000000000000000000000000000000000000000000000000000000000000");
        }
        emit!(event::TestEvent {
            str_val: "Hello, World!".to_string(),
            u64_value: value,
        });

        Ok(())
    }

    pub fn create_log_cpi(ctx: Context<CreateLogCpi>, value: u64) -> Result<()> {
        emit_cpi!(event::TestEvent {
            str_val: "Hello, CPI!".to_string(),
            u64_value: value,
        });
        Ok(())
    }
}

#[derive(Accounts)]
pub struct Initialization<'info> {
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[event_cpi]
#[derive(Accounts)]
pub struct CreateLogCpi<'info> {
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}
