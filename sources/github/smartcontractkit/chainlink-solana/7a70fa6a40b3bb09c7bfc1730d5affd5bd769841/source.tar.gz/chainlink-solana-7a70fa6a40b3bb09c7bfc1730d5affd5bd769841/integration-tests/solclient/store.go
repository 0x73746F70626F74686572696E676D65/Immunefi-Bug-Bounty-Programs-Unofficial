package solclient

import (
	"context"

	"github.com/gagliardetto/solana-go"
	"github.com/gagliardetto/solana-go/rpc"

	"github.com/smartcontractkit/chainlink-solana/contracts/generated/store"
	relaySol "github.com/smartcontractkit/chainlink-solana/pkg/solana"
	"github.com/smartcontractkit/chainlink-solana/pkg/solana/client"
)

type Store struct {
	Client        *Client
	Store         *solana.Wallet
	Feed          *solana.Wallet
	Owner         *solana.Wallet
	ProgramWallet *solana.Wallet
}

func (m *Store) GetLatestRoundData() (uint64, uint64, uint64, error) {
	getReader := func() (client.AccountReader, error) { return m.Client.RPC, nil }
	a, _, err := relaySol.GetLatestTransmission(context.Background(), getReader, m.Feed.PublicKey(), rpc.CommitmentConfirmed)
	if err != nil {
		return 0, 0, 0, err
	}
	return a.Data.Uint64(), uint64(a.Timestamp), 0, nil
}

func (m *Store) TransmissionsAddress() string {
	return m.Feed.PublicKey().String()
}

func (m *Store) SetValidatorConfig(flaggingThreshold uint32) error {
	payer := m.Client.DefaultWallet
	validatorInstr, err := store.NewSetValidatorConfigInstruction(
		flaggingThreshold,
		m.Feed.PublicKey(),
		m.Owner.PublicKey(),
		m.Owner.PublicKey(),
	)
	if err != nil {
		return err
	}
	err = m.Client.TXAsync(
		"Set validator config",
		[]solana.Instruction{validatorInstr},
		func(key solana.PublicKey) *solana.PrivateKey {
			if key.Equals(m.Owner.PublicKey()) {
				return &m.Owner.PrivateKey
			}
			if key.Equals(payer.PublicKey()) {
				return &payer.PrivateKey
			}
			return nil
		},
		payer.PublicKey(),
	)
	if err != nil {
		return err
	}
	return nil
}

func (m *Store) SetWriter(writerAuthority string) error {
	payer := m.Client.DefaultWallet
	writerAuthPubKey, err := solana.PublicKeyFromBase58(writerAuthority)
	if err != nil {
		return nil
	}
	setWriterInstr, err := store.NewSetWriterInstruction(
		writerAuthPubKey,
		m.Feed.PublicKey(),
		m.Owner.PublicKey(),
		m.Owner.PublicKey(),
	)
	if err != nil {
		return err
	}
	err = m.Client.TXAsync(
		"Set writer",
		[]solana.Instruction{setWriterInstr},
		func(key solana.PublicKey) *solana.PrivateKey {
			if key.Equals(m.Owner.PublicKey()) {
				return &m.Owner.PrivateKey
			}
			if key.Equals(m.Feed.PublicKey()) {
				return &m.Feed.PrivateKey
			}
			if key.Equals(payer.PublicKey()) {
				return &payer.PrivateKey
			}
			return nil
		},
		payer.PublicKey(),
	)
	if err != nil {
		return err
	}
	return nil
}

func (m *Store) ProgramAddress() string {
	return m.ProgramWallet.PublicKey().String()
}

func (m *Store) Address() string {
	return m.Store.PublicKey().String()
}
