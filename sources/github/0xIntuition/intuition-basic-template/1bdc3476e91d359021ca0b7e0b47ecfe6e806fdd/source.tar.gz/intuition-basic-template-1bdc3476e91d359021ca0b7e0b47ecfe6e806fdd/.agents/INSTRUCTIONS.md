# intuition-basic-template

## Project Type
Vite + React 19 SPA - Intuition protocol explorer template

## Commands
- `bun dev` - start dev server
- `bun run build` - production build
- `bun preview` - preview production build

## Architecture
Single page app with tabbed sections. Each tab maps to one MultiVault function category.
All protocol interactions go through `src/lib/protocol.ts`.

## Key Rules
- All on-chain interactions use `@0xintuition/protocol` — this is the only Intuition package in this template
- Resolve contract addresses with `getMultiVaultAddressFromChainId()` — never hardcode them
- Always parse events after write transactions
- Always get atom/triple cost before creation (payable functions)
- Deposit defaults: `curveId = 1n`, `minShares = 0n`
- Chain config: import `intuitionTestnet` from `@0xintuition/protocol`
