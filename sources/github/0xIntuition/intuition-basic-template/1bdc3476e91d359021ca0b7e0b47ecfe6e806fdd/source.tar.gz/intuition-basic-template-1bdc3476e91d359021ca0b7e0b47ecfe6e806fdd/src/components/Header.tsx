import { ConnectButton } from '@rainbow-me/rainbowkit'

type HeaderProps = {
  isConnected: boolean
}

export function Header({ isConnected }: HeaderProps) {
  return (
    <section className="flex flex-col gap-6 rounded-2xl border bg-background p-6 shadow-sm">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div className="space-y-3">
          <p className="text-sm font-medium uppercase tracking-[0.2em] text-muted-foreground">
            Intuition Basic Template
          </p>
          <div className="space-y-2">
            <h1 className="text-3xl font-semibold tracking-tight sm:text-4xl">
              MultiVault protocol explorer
            </h1>
            <p className="max-w-3xl text-sm text-muted-foreground sm:text-base">
              This template maps the Intuition MultiVault contract to a
              reusable form and result system so developers can trace each read
              and write call from UI input to decoded protocol output.
            </p>
          </div>
        </div>

        <div className="flex flex-col items-start gap-3 lg:items-end">
          <ConnectButton />
          <p className="text-sm text-muted-foreground">
            {isConnected
              ? 'Wallet connected. Protocol panels can submit transactions.'
              : 'Connect a wallet to unlock the protocol form panels.'}
          </p>
        </div>
      </div>
    </section>
  )
}
