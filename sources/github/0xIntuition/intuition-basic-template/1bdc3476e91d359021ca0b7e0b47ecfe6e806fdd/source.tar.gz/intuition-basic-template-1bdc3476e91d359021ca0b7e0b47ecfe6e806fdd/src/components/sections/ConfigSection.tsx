import { useChainId, usePublicClient } from 'wagmi'

import { FormPanel } from '@/components/FormPanel'
import {
  entryFeeAmount,
  exitFeeAmount,
  getAssetLabel,
  getGeneralConfig,
  getReadConfig,
  protocolFeeAmount,
} from '@/lib/protocol'

type ConfigSectionProps = {
  disabled?: boolean
}

export function ConfigSection({ disabled = false }: ConfigSectionProps) {
  const chainId = useChainId()
  const publicClient = usePublicClient()

  return (
    <div className="space-y-6">
      <FormPanel
        description="Read the global MultiVault general config struct."
        disabled={disabled}
        fields={[]}
        onSubmit={async () => {
          if (!publicClient) {
            throw new Error('A public client is required to read general config.')
          }

          return getGeneralConfig(getReadConfig(chainId, publicClient))
        }}
        resultType="config"
        submitLabel="Read config"
        title="multiVaultGetGeneralConfig"
      />

      <FormPanel
        description="Calculate the entry fee amount for an asset value."
        disabled={disabled}
        fields={[
          {
            name: 'assets',
            label: getAssetLabel(chainId),
            placeholder: '1000000000000000000',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient) {
            throw new Error('A public client is required to read the entry fee amount.')
          }

          return entryFeeAmount(getReadConfig(chainId, publicClient), {
            assets: values.assets,
          })
        }}
        resultType="read"
        submitLabel="Calculate fee"
        title="multiVaultEntryFeeAmount"
      />

      <FormPanel
        description="Calculate the exit fee amount for an asset value."
        disabled={disabled}
        fields={[
          {
            name: 'assets',
            label: getAssetLabel(chainId),
            placeholder: '1000000000000000000',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient) {
            throw new Error('A public client is required to read the exit fee amount.')
          }

          return exitFeeAmount(getReadConfig(chainId, publicClient), {
            assets: values.assets,
          })
        }}
        resultType="read"
        submitLabel="Calculate fee"
        title="multiVaultExitFeeAmount"
      />

      <FormPanel
        description="Calculate the protocol fee amount for an asset value."
        disabled={disabled}
        fields={[
          {
            name: 'assets',
            label: getAssetLabel(chainId),
            placeholder: '1000000000000000000',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient) {
            throw new Error('A public client is required to read the protocol fee amount.')
          }

          return protocolFeeAmount(getReadConfig(chainId, publicClient), {
            assets: values.assets,
          })
        }}
        resultType="read"
        submitLabel="Calculate fee"
        title="multiVaultProtocolFeeAmount"
      />
    </div>
  )
}
