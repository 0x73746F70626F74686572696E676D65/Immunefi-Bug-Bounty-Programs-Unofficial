import { useChainId, usePublicClient, useWalletClient } from 'wagmi'

import { FormPanel } from '@/components/FormPanel'
import {
  convertToAssets,
  convertToShares,
  currentSharePrice,
  getAssetLabel,
  getReadConfig,
  getShares,
  getVault,
} from '@/lib/protocol'

type VaultSectionProps = {
  disabled?: boolean
}

export function VaultSection({ disabled = false }: VaultSectionProps) {
  const chainId = useChainId()
  const publicClient = usePublicClient()
  const { data: walletClient } = useWalletClient()
  const connectedAddress = walletClient?.account?.address ?? ''

  return (
    <div className="space-y-6">
      <FormPanel
        description="Read the vault tuple for a term ID and curve ID."
        disabled={disabled}
        fields={[
          {
            name: 'termId',
            label: 'Term ID',
            placeholder: '0x...',
          },
          {
            name: 'curveId',
            label: 'Curve ID',
            defaultValue: '1',
            placeholder: '1',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient) {
            throw new Error('A public client is required to read vault state.')
          }

          return getVault(getReadConfig(chainId, publicClient), {
            termId: values.termId,
            curveId: values.curveId,
          })
        }}
        resultType="read"
        submitLabel="Read vault"
        title="multiVaultGetVault"
      />

      <FormPanel
        description="Read the share balance for an account in a vault."
        disabled={disabled}
        fields={[
          {
            name: 'account',
            label: 'Account',
            defaultValue: connectedAddress,
            placeholder: '0x...',
          },
          {
            name: 'termId',
            label: 'Term ID',
            placeholder: '0x...',
          },
          {
            name: 'curveId',
            label: 'Curve ID',
            defaultValue: '1',
            placeholder: '1',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient) {
            throw new Error('A public client is required to read shares.')
          }

          return getShares(getReadConfig(chainId, publicClient), {
            account: values.account,
            termId: values.termId,
            curveId: values.curveId,
          })
        }}
        resultType="read"
        submitLabel="Read shares"
        title="multiVaultGetShares"
      />

      <FormPanel
        description="Read the current share price for a vault."
        disabled={disabled}
        fields={[
          {
            name: 'termId',
            label: 'Term ID',
            placeholder: '0x...',
          },
          {
            name: 'curveId',
            label: 'Curve ID',
            defaultValue: '1',
            placeholder: '1',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient) {
            throw new Error('A public client is required to read share price.')
          }

          return currentSharePrice(getReadConfig(chainId, publicClient), {
            termId: values.termId,
            curveId: values.curveId,
          })
        }}
        resultType="read"
        submitLabel="Read price"
        title="multiVaultCurrentSharePrice"
      />

      <FormPanel
        description="Convert a share amount into assets using the current vault math."
        disabled={disabled}
        fields={[
          {
            name: 'termId',
            label: 'Term ID',
            placeholder: '0x...',
          },
          {
            name: 'shares',
            label: 'Shares',
            placeholder: '1000000000000000000',
          },
          {
            name: 'curveId',
            label: 'Curve ID',
            defaultValue: '1',
            placeholder: '1',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient) {
            throw new Error('A public client is required to convert shares to assets.')
          }

          return convertToAssets(getReadConfig(chainId, publicClient), {
            termId: values.termId,
            shares: values.shares,
            curveId: values.curveId,
          })
        }}
        resultType="read"
        submitLabel="Convert to assets"
        title="multiVaultConvertToAssets"
      />

      <FormPanel
        description="Convert an asset amount into shares using the current vault math."
        disabled={disabled}
        fields={[
          {
            name: 'termId',
            label: 'Term ID',
            placeholder: '0x...',
          },
          {
            name: 'assets',
            label: getAssetLabel(chainId),
            placeholder: '1000000000000000000',
          },
          {
            name: 'curveId',
            label: 'Curve ID',
            defaultValue: '1',
            placeholder: '1',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient) {
            throw new Error('A public client is required to convert assets to shares.')
          }

          return convertToShares(getReadConfig(chainId, publicClient), {
            termId: values.termId,
            assets: values.assets,
            curveId: values.curveId,
          })
        }}
        resultType="read"
        submitLabel="Convert to shares"
        title="multiVaultConvertToShares"
      />
    </div>
  )
}
