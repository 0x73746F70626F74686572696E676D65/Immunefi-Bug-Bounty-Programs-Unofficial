import { useChainId, usePublicClient, useWalletClient } from 'wagmi'

import { FormPanel } from '@/components/FormPanel'
import {
  createAtoms,
  getAssetLabel,
  getAtom,
  getAtomConfig,
  getAtomCost,
  getReadConfig,
  getWriteConfig,
  isTermCreated,
  previewAtomCreate,
} from '@/lib/protocol'

type AtomsSectionProps = {
  disabled?: boolean
}

export function AtomsSection({ disabled = false }: AtomsSectionProps) {
  const chainId = useChainId()
  const publicClient = usePublicClient()
  const { data: walletClient } = useWalletClient()

  return (
    <div className="space-y-6">
      <FormPanel
        description="Create one or more atoms. The helper layer fetches the current atom cost, encodes each text value with toHex(...), submits the payable transaction, and parses AtomCreated events."
        disabled={disabled}
        fields={[
          {
            name: 'atomData',
            label: 'Atom Text',
            placeholder: 'hello world',
            description:
              'Use commas or new lines to create multiple atoms in one transaction.',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient || !walletClient) {
            throw new Error('Connect a wallet before creating atoms.')
          }

          return createAtoms(
            getReadConfig(chainId, publicClient),
            getWriteConfig(chainId, publicClient, walletClient),
            {
              atomData: values.atomData,
            },
          )
        }}
        resultType="tx"
        submitLabel="Create atoms"
        title="multiVaultCreateAtoms"
      />

      <FormPanel
        description="Read the stored bytes for an atom ID and decode the bytes back into a string when possible."
        disabled={disabled}
        fields={[
          {
            name: 'atomId',
            label: 'Atom ID',
            placeholder: '0x...',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient) {
            throw new Error('A public client is required to read atom data.')
          }

          return getAtom(getReadConfig(chainId, publicClient), {
            atomId: values.atomId,
          })
        }}
        resultType="read"
        submitLabel="Read atom"
        title="multiVaultGetAtom"
      />

      <FormPanel
        description="Check whether an atom or triple term ID has already been created onchain."
        disabled={disabled}
        fields={[
          {
            name: 'termId',
            label: 'Term ID',
            placeholder: '0x...',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient) {
            throw new Error('A public client is required to check term existence.')
          }

          return isTermCreated(getReadConfig(chainId, publicClient), {
            termId: values.termId,
          })
        }}
        resultType="read"
        submitLabel="Check term"
        title="multiVaultIsTermCreated"
      />

      <FormPanel
        description="Read the current atom creation cost directly from the MultiVault contract."
        disabled={disabled}
        fields={[]}
        onSubmit={async () => {
          if (!publicClient) {
            throw new Error('A public client is required to read atom cost.')
          }

          return getAtomCost(getReadConfig(chainId, publicClient))
        }}
        resultType="read"
        submitLabel="Read cost"
        title="multiVaultGetAtomCost"
      />

      <FormPanel
        description="Read the current atom config tuple exposed by the protocol package."
        disabled={disabled}
        fields={[]}
        onSubmit={async () => {
          if (!publicClient) {
            throw new Error('A public client is required to read atom config.')
          }

          return getAtomConfig(getReadConfig(chainId, publicClient))
        }}
        resultType="config"
        submitLabel="Read config"
        title="multiVaultGetAtomConfig"
      />

      <FormPanel
        description="Preview the result of creating an atom for a specific term ID and asset amount. The underlying protocol helper uses a wallet-aware read, so a connected account is required."
        disabled={disabled}
        fields={[
          {
            name: 'termId',
            label: 'Term ID',
            placeholder: '0x...',
          },
          {
            name: 'assets',
            label: getAssetLabel(chainId),
            placeholder: '1000000000000000000',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient || !walletClient) {
            throw new Error('Connect a wallet before previewing atom creation.')
          }

          return previewAtomCreate(
            getWriteConfig(chainId, publicClient, walletClient),
            {
              termId: values.termId,
              assets: values.assets,
            },
          )
        }}
        resultType="read"
        submitLabel="Preview create"
        title="multiVaultPreviewAtomCreate"
      />
    </div>
  )
}
