import { useChainId, usePublicClient, useWalletClient } from 'wagmi'

import { FormPanel } from '@/components/FormPanel'
import {
  createTriples,
  getInverseTripleId,
  getReadConfig,
  getTriple,
  getTripleConfig,
  getTripleCost,
  getWriteConfig,
  isCounterTriple,
  isTriple,
} from '@/lib/protocol'

type TriplesSectionProps = {
  disabled?: boolean
}

export function TriplesSection({ disabled = false }: TriplesSectionProps) {
  const chainId = useChainId()
  const publicClient = usePublicClient()
  const { data: walletClient } = useWalletClient()

  return (
    <div className="space-y-6">
      <FormPanel
        description="Create one or more triples from subject, predicate, and object term IDs. The helper layer fetches the triple cost, calculates the payable value, and parses TripleCreated events after submission."
        disabled={disabled}
        fields={[
          {
            name: 'subjectIds',
            label: 'Subject IDs',
            placeholder: '0x...',
            description:
              'Use commas or new lines to submit multiple subject IDs.',
          },
          {
            name: 'predicateIds',
            label: 'Predicate IDs',
            placeholder: '0x...',
            description:
              'Must have the same number of items as the subject list.',
          },
          {
            name: 'objectIds',
            label: 'Object IDs',
            placeholder: '0x...',
            description:
              'Must have the same number of items as the subject list.',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient || !walletClient) {
            throw new Error('Connect a wallet before creating triples.')
          }

          return createTriples(
            getReadConfig(chainId, publicClient),
            getWriteConfig(chainId, publicClient, walletClient),
            {
              subjectIds: values.subjectIds,
              predicateIds: values.predicateIds,
              objectIds: values.objectIds,
            },
          )
        }}
        resultType="tx"
        submitLabel="Create triples"
        title="multiVaultCreateTriples"
      />

      <FormPanel
        description="Read the subject, predicate, and object IDs stored for a triple."
        disabled={disabled}
        fields={[
          {
            name: 'tripleId',
            label: 'Triple ID',
            placeholder: '0x...',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient) {
            throw new Error('A public client is required to read triple data.')
          }

          return getTriple(getReadConfig(chainId, publicClient), {
            tripleId: values.tripleId,
          })
        }}
        resultType="read"
        submitLabel="Read triple"
        title="multiVaultGetTriple"
      />

      <FormPanel
        description="Check whether a term ID represents a triple."
        disabled={disabled}
        fields={[
          {
            name: 'tripleId',
            label: 'Triple ID',
            placeholder: '0x...',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient) {
            throw new Error('A public client is required to check triple type.')
          }

          return isTriple(getReadConfig(chainId, publicClient), {
            tripleId: values.tripleId,
          })
        }}
        resultType="read"
        submitLabel="Check triple"
        title="multiVaultIsTriple"
      />

      <FormPanel
        description="Read the current triple creation cost directly from the MultiVault contract."
        disabled={disabled}
        fields={[]}
        onSubmit={async () => {
          if (!publicClient) {
            throw new Error('A public client is required to read triple cost.')
          }

          return getTripleCost(getReadConfig(chainId, publicClient))
        }}
        resultType="read"
        submitLabel="Read cost"
        title="multiVaultGetTripleCost"
      />

      <FormPanel
        description="Read the current triple config tuple exposed by the protocol package."
        disabled={disabled}
        fields={[]}
        onSubmit={async () => {
          if (!publicClient) {
            throw new Error('A public client is required to read triple config.')
          }

          return getTripleConfig(getReadConfig(chainId, publicClient))
        }}
        resultType="config"
        submitLabel="Read config"
        title="multiVaultGetTripleConfig"
      />

      <FormPanel
        description="Read the inverse triple ID for a given triple term ID."
        disabled={disabled}
        fields={[
          {
            name: 'tripleId',
            label: 'Triple ID',
            placeholder: '0x...',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient) {
            throw new Error('A public client is required to read the inverse triple ID.')
          }

          return getInverseTripleId(getReadConfig(chainId, publicClient), {
            tripleId: values.tripleId,
          })
        }}
        resultType="read"
        submitLabel="Read inverse"
        title="multiVaultGetInverseTripleId"
      />

      <FormPanel
        description="Check whether a triple is marked as a counter triple."
        disabled={disabled}
        fields={[
          {
            name: 'tripleId',
            label: 'Triple ID',
            placeholder: '0x...',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient) {
            throw new Error('A public client is required to check counter triple state.')
          }

          return isCounterTriple(getReadConfig(chainId, publicClient), {
            tripleId: values.tripleId,
          })
        }}
        resultType="read"
        submitLabel="Check counter"
        title="multiVaultIsCounterTriple"
      />
    </div>
  )
}
