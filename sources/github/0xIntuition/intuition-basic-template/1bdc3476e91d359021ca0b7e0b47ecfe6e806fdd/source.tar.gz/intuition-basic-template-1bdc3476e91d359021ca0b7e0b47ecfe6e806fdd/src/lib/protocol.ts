import {
  eventParseAtomCreated,
  eventParseDeposited,
  eventParseRedeemed,
  eventParseTripleCreated,
  getMultiVaultAddressFromChainId,
  multiVaultConvertToAssets,
  multiVaultConvertToShares,
  multiVaultCreateAtoms,
  multiVaultCreateTriples,
  multiVaultCurrentSharePrice,
  multiVaultDeposit,
  multiVaultDepositBatch,
  multiVaultEntryFeeAmount,
  multiVaultExitFeeAmount,
  multiVaultGetAtom,
  multiVaultGetAtomConfig,
  multiVaultGetAtomCost,
  multiVaultGetGeneralConfig,
  multiVaultGetInverseTripleId,
  multiVaultGetShares,
  multiVaultGetTriple,
  multiVaultGetTripleConfig,
  multiVaultGetTripleCost,
  multiVaultGetVault,
  multiVaultIsCounterTriple,
  multiVaultIsTermCreated,
  multiVaultIsTriple,
  multiVaultMaxRedeem,
  multiVaultPreviewAtomCreate,
  multiVaultPreviewDeposit,
  multiVaultPreviewRedeem,
  multiVaultProtocolFeeAmount,
  multiVaultRedeem,
  multiVaultRedeemBatch,
  type ReadConfig,
  type WriteConfig,
} from '@0xintuition/protocol'
import {
  type Address,
  type Hex,
  type PublicClient,
  type WalletClient,
  fromHex,
  getAddress,
  isAddress,
  toHex,
} from 'viem'

export const EXPLORER_BASE_URL = 'https://testnet.explorer.intuition.systems'

/** Returns the native token symbol for the connected chain. */
export function getTokenSymbol(chainId: number): string {
  return chainId === 1155 ? 'TRUST' : 'tTRUST'
}

/** Label for asset/amount input fields, chain-aware. */
export function getAssetLabel(chainId: number): string {
  return `Amount in wei (1 ${getTokenSymbol(chainId)} = 10¹⁸)`
}

/** Label for batch asset/amount input fields, chain-aware. */
export function getAssetsLabel(chainId: number): string {
  return `Amounts in wei (1 ${getTokenSymbol(chainId)} = 10¹⁸)`
}
export const DEFAULT_CURVE_ID = 1n
export const DEFAULT_MIN_SHARES = 0n
export const DEFAULT_MIN_ASSETS = 0n

type PrimitiveResult = string | boolean | null

export type ResultValue =
  | PrimitiveResult
  | ResultValue[]
  | { [key: string]: ResultValue }

export type ReadResult = {
  [key: string]: ResultValue
}

export type FormattedEvent = {
  name: string
  values: ReadResult
}

export type TransactionResult = {
  txHash: Hex
  explorerUrl: string
  events: FormattedEvent[]
}

export type CreateAtomsInput = {
  atomData: string
}

export type GetAtomInput = {
  atomId: string
}

export type IsTermCreatedInput = {
  termId: string
}

export type PreviewAtomCreateInput = {
  termId: string
  assets: string
}

export type CreateTriplesInput = {
  subjectIds: string
  predicateIds: string
  objectIds: string
}

export type GetTripleInput = {
  tripleId: string
}

export type TripleIdInput = {
  tripleId: string
}

export type DepositInput = {
  termId: string
  assets: string
  receiver?: string
  curveId?: string
  minShares?: string
}

export type DepositBatchInput = {
  termIds: string
  assets: string
  receiver?: string
  curveIds?: string
  minShares?: string
}

export type PreviewDepositInput = {
  termId: string
  assets: string
  curveId?: string
}

export type RedeemInput = {
  termId: string
  shares: string
  receiver?: string
  curveId?: string
  minAssets?: string
}

export type RedeemBatchInput = {
  termIds: string
  shares: string
  receiver?: string
  curveIds?: string
  minAssets?: string
}

export type PreviewRedeemInput = {
  termId: string
  shares: string
  curveId?: string
}

export type MaxRedeemInput = {
  sender: string
  termId: string
  curveId?: string
}

export type VaultInput = {
  termId: string
  curveId?: string
}

export type SharesInput = {
  account: string
  termId: string
  curveId?: string
}

export type ConvertToAssetsInput = {
  termId: string
  shares: string
  curveId?: string
}

export type ConvertToSharesInput = {
  termId: string
  assets: string
  curveId?: string
}

export type FeeAmountInput = {
  assets: string
}

// Wagmi hooks expose viem clients. The protocol package expects the same
// clients bundled into a light config object with the resolved MultiVault
// contract address.
export function getReadConfig(
  chainId: number,
  publicClient: PublicClient,
): ReadConfig {
  return {
    address: getMultiVaultAddressFromChainId(chainId),
    publicClient,
  }
}

export function getWriteConfig(
  chainId: number,
  publicClient: PublicClient,
  walletClient: WalletClient,
): WriteConfig {
  return {
    address: getMultiVaultAddressFromChainId(chainId),
    publicClient,
    walletClient,
  }
}

export function getExplorerTransactionUrl(txHash: Hex) {
  return `${EXPLORER_BASE_URL}/tx/${txHash}`
}

function getConnectedAccount(walletClient: WalletClient) {
  if (!walletClient.account) {
    throw new Error('A connected wallet account is required for this action.')
  }

  return walletClient.account
}

function parseRequiredString(value: string | undefined, fieldName: string) {
  const trimmed = value?.trim()

  if (!trimmed) {
    throw new Error(`${fieldName} is required.`)
  }

  return trimmed
}

function parseAddressInput(value: string | undefined, fieldName: string): Address {
  const trimmed = parseRequiredString(value, fieldName)

  if (!isAddress(trimmed)) {
    throw new Error(`${fieldName} must be a valid EVM address.`)
  }

  return getAddress(trimmed)
}

function parseReceiverInput(
  value: string | undefined,
  walletClient: WalletClient,
): Address {
  if (!value?.trim()) {
    return getConnectedAccount(walletClient).address
  }

  return parseAddressInput(value, 'Receiver')
}

function parseBytes32Input(value: string | undefined, fieldName: string): Hex {
  const trimmed = parseRequiredString(value, fieldName)

  if (!/^0x[0-9a-fA-F]{64}$/.test(trimmed)) {
    throw new Error(`${fieldName} must be a 32-byte hex value.`)
  }

  return trimmed as Hex
}

function parseBigIntInput(
  value: string | undefined,
  fieldName: string,
  defaultValue?: bigint,
): bigint {
  const trimmed = value?.trim()

  if (!trimmed) {
    if (defaultValue !== undefined) {
      return defaultValue
    }

    throw new Error(`${fieldName} is required.`)
  }

  try {
    return BigInt(trimmed)
  } catch {
    throw new Error(`${fieldName} must be a bigint-compatible integer string.`)
  }
}

function splitDelimitedInput(value: string | undefined, fieldName: string) {
  const trimmed = parseRequiredString(value, fieldName)

  return trimmed
    .split(/[\n,]+/)
    .map((entry) => entry.trim())
    .filter(Boolean)
}

function parseBytes32List(value: string | undefined, fieldName: string) {
  return splitDelimitedInput(value, fieldName).map((entry, index) =>
    parseBytes32Input(entry, `${fieldName} #${index + 1}`),
  )
}

function parseBigIntList(
  value: string | undefined,
  fieldName: string,
  fallbackLength?: number,
  defaultValue?: bigint,
) {
  if (!value?.trim()) {
    if (fallbackLength === undefined || defaultValue === undefined) {
      throw new Error(`${fieldName} is required.`)
    }

    return Array.from({ length: fallbackLength }, () => defaultValue)
  }

  return splitDelimitedInput(value, fieldName).map((entry, index) =>
    parseBigIntInput(entry, `${fieldName} #${index + 1}`),
  )
}

function assertMatchingLengths(
  label: string,
  expectedLength: number,
  actualLength: number,
) {
  if (expectedLength !== actualLength) {
    throw new Error(
      `${label} length mismatch. Expected ${expectedLength} items but received ${actualLength}.`,
    )
  }
}

function sumBigInts(values: bigint[]) {
  return values.reduce((total, value) => total + value, 0n)
}

function encodeAtomData(text: string) {
  const normalized = parseRequiredString(text, 'Atom data')

  return toHex(normalized)
}

function decodeAtomData(hexValue: Hex) {
  try {
    return fromHex(hexValue, 'string').replace(/\0+$/g, '')
  } catch {
    return null
  }
}

function serializeValue(value: unknown): ResultValue {
  if (
    value === null ||
    typeof value === 'string' ||
    typeof value === 'boolean'
  ) {
    return value
  }

  if (typeof value === 'bigint') {
    return value.toString()
  }

  if (Array.isArray(value)) {
    return value.map((entry) => serializeValue(entry))
  }

  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value).map(([key, entry]) => [key, serializeValue(entry)]),
    )
  }

  return String(value)
}

function formatReadRecord(record: Record<string, unknown>): ReadResult {
  return Object.fromEntries(
    Object.entries(record).map(([key, value]) => [key, serializeValue(value)]),
  )
}

function formatParsedEvents(
  eventName: string,
  events: Array<{ args?: Record<string, unknown> }>,
) {
  return events.map((event) => {
    const values = formatReadRecord(event.args ?? {})

    if (eventName === 'AtomCreated' && typeof values.atomData === 'string') {
      values.atomDataText = decodeAtomData(values.atomData as Hex)
    }

    return {
      name: eventName,
      values,
    }
  })
}

async function buildTransactionResult(
  txHash: Hex,
  eventName: FormattedEvent['name'],
  loadEvents: () => Promise<Array<{ args?: Record<string, unknown> }>>,
): Promise<TransactionResult> {
  return {
    txHash,
    explorerUrl: getExplorerTransactionUrl(txHash),
    events: formatParsedEvents(eventName, await loadEvents()),
  }
}

// ---------------------------------------------------------------------------
// Atoms
// ---------------------------------------------------------------------------

export async function createAtoms(
  readConfig: ReadConfig,
  writeConfig: WriteConfig,
  input: CreateAtomsInput,
) {
  const texts = splitDelimitedInput(input.atomData, 'Atom data')
  const encodedAtoms = texts.map((text) => encodeAtomData(text))
  const atomCost = await multiVaultGetAtomCost(readConfig)
  const assets = encodedAtoms.map(() => atomCost)
  const txHash = await multiVaultCreateAtoms(writeConfig, {
    args: [encodedAtoms, assets],
    value: sumBigInts(assets),
  })

  return await buildTransactionResult(txHash, 'AtomCreated', async () =>
    eventParseAtomCreated(readConfig.publicClient, txHash),
  )
}

export async function getAtom(readConfig: ReadConfig, input: GetAtomInput) {
  const atomId = parseBytes32Input(input.atomId, 'Atom ID')
  const atomData = await multiVaultGetAtom(readConfig, { args: [atomId] })

  return formatReadRecord({
    atomId,
    atomData,
    atomDataText: decodeAtomData(atomData as Hex),
  })
}

export async function isTermCreated(
  readConfig: ReadConfig,
  input: IsTermCreatedInput,
) {
  const termId = parseBytes32Input(input.termId, 'Term ID')
  const isCreated = await multiVaultIsTermCreated(readConfig, { args: [termId] })

  return formatReadRecord({ termId, isCreated })
}

export async function getAtomCost(readConfig: ReadConfig) {
  const atomCost = await multiVaultGetAtomCost(readConfig)

  return formatReadRecord({ atomCost })
}

export async function getAtomConfig(readConfig: ReadConfig) {
  const config = await multiVaultGetAtomConfig(readConfig)

  return formatReadRecord(config as Record<string, unknown>)
}

// The protocol package types preview helpers against WriteConfig because the
// read call includes the connected account for consistency with wallet-aware UIs.
export async function previewAtomCreate(
  writeConfig: WriteConfig,
  input: PreviewAtomCreateInput,
) {
  getConnectedAccount(writeConfig.walletClient)

  const termId = parseBytes32Input(input.termId, 'Term ID')
  const assets = parseBigIntInput(input.assets, 'Assets')
  const [shares, assetsAfterFixedFees, assetsAfterFees] =
    await multiVaultPreviewAtomCreate(writeConfig, {
      args: [termId, assets],
    })

  return formatReadRecord({
    termId,
    assets,
    shares,
    assetsAfterFixedFees,
    assetsAfterFees,
  })
}

// ---------------------------------------------------------------------------
// Triples
// ---------------------------------------------------------------------------

export async function createTriples(
  readConfig: ReadConfig,
  writeConfig: WriteConfig,
  input: CreateTriplesInput,
) {
  const subjectIds = parseBytes32List(input.subjectIds, 'Subject IDs')
  const predicateIds = parseBytes32List(input.predicateIds, 'Predicate IDs')
  const objectIds = parseBytes32List(input.objectIds, 'Object IDs')

  assertMatchingLengths('Predicate IDs', subjectIds.length, predicateIds.length)
  assertMatchingLengths('Object IDs', subjectIds.length, objectIds.length)

  const tripleCost = await multiVaultGetTripleCost(readConfig)
  const assets = subjectIds.map(() => tripleCost)
  const txHash = await multiVaultCreateTriples(writeConfig, {
    args: [subjectIds, predicateIds, objectIds, assets],
    value: sumBigInts(assets),
  })

  return await buildTransactionResult(txHash, 'TripleCreated', async () =>
    eventParseTripleCreated(readConfig.publicClient, txHash),
  )
}

export async function getTriple(readConfig: ReadConfig, input: GetTripleInput) {
  const tripleId = parseBytes32Input(input.tripleId, 'Triple ID')
  const [subjectId, predicateId, objectId] = await multiVaultGetTriple(
    readConfig,
    { args: [tripleId] },
  )

  return formatReadRecord({
    tripleId,
    subjectId,
    predicateId,
    objectId,
  })
}

export async function isTriple(readConfig: ReadConfig, input: TripleIdInput) {
  const tripleId = parseBytes32Input(input.tripleId, 'Triple ID')
  const result = await multiVaultIsTriple(readConfig, { args: [tripleId] })

  return formatReadRecord({
    tripleId,
    isTriple: result,
  })
}

export async function getTripleCost(readConfig: ReadConfig) {
  const tripleCost = await multiVaultGetTripleCost(readConfig)

  return formatReadRecord({ tripleCost })
}

export async function getTripleConfig(readConfig: ReadConfig) {
  const config = await multiVaultGetTripleConfig(readConfig)

  return formatReadRecord(config as Record<string, unknown>)
}

export async function getInverseTripleId(
  readConfig: ReadConfig,
  input: TripleIdInput,
) {
  const tripleId = parseBytes32Input(input.tripleId, 'Triple ID')
  const inverseTripleId = await multiVaultGetInverseTripleId(readConfig, {
    args: [tripleId],
  })

  return formatReadRecord({
    tripleId,
    inverseTripleId,
  })
}

export async function isCounterTriple(
  readConfig: ReadConfig,
  input: TripleIdInput,
) {
  const tripleId = parseBytes32Input(input.tripleId, 'Triple ID')
  const result = await multiVaultIsCounterTriple(readConfig, {
    args: [tripleId],
  })

  return formatReadRecord({
    tripleId,
    isCounterTriple: result,
  })
}

// ---------------------------------------------------------------------------
// Deposits
// ---------------------------------------------------------------------------

export async function deposit(
  writeConfig: WriteConfig,
  input: DepositInput,
) {
  const receiver = parseReceiverInput(input.receiver, writeConfig.walletClient)
  const termId = parseBytes32Input(input.termId, 'Term ID')
  const curveId = parseBigIntInput(input.curveId, 'Curve ID', DEFAULT_CURVE_ID)
  const assets = parseBigIntInput(input.assets, 'Assets')
  const minShares = parseBigIntInput(
    input.minShares,
    'Minimum shares',
    DEFAULT_MIN_SHARES,
  )
  const txHash = await multiVaultDeposit(writeConfig, {
    args: [receiver, termId, curveId, minShares],
    value: assets,
  })

  return await buildTransactionResult(txHash, 'Deposited', async () =>
    eventParseDeposited(writeConfig.publicClient, txHash),
  )
}

export async function depositBatch(
  writeConfig: WriteConfig,
  input: DepositBatchInput,
) {
  const receiver = parseReceiverInput(input.receiver, writeConfig.walletClient)
  const termIds = parseBytes32List(input.termIds, 'Term IDs')
  const assets = parseBigIntList(input.assets, 'Assets')
  const curveIds = parseBigIntList(
    input.curveIds,
    'Curve IDs',
    termIds.length,
    DEFAULT_CURVE_ID,
  )
  const minShares = parseBigIntList(
    input.minShares,
    'Minimum shares',
    termIds.length,
    DEFAULT_MIN_SHARES,
  )

  assertMatchingLengths('Assets', termIds.length, assets.length)
  assertMatchingLengths('Curve IDs', termIds.length, curveIds.length)
  assertMatchingLengths('Minimum shares', termIds.length, minShares.length)

  const txHash = await multiVaultDepositBatch(writeConfig, {
    args: [receiver, termIds, curveIds, assets, minShares],
    value: sumBigInts(assets),
  })

  return await buildTransactionResult(txHash, 'Deposited', async () =>
    eventParseDeposited(writeConfig.publicClient, txHash),
  )
}

export async function previewDeposit(
  writeConfig: WriteConfig,
  input: PreviewDepositInput,
) {
  getConnectedAccount(writeConfig.walletClient)

  const termId = parseBytes32Input(input.termId, 'Term ID')
  const curveId = parseBigIntInput(input.curveId, 'Curve ID', DEFAULT_CURVE_ID)
  const assets = parseBigIntInput(input.assets, 'Assets')
  const [shares, assetsAfterFees] = await multiVaultPreviewDeposit(writeConfig, {
    args: [termId, curveId, assets],
  })

  return formatReadRecord({
    termId,
    curveId,
    assets,
    shares,
    assetsAfterFees,
  })
}

// ---------------------------------------------------------------------------
// Redemptions
// ---------------------------------------------------------------------------

export async function redeem(
  writeConfig: WriteConfig,
  input: RedeemInput,
) {
  const receiver = parseReceiverInput(input.receiver, writeConfig.walletClient)
  const termId = parseBytes32Input(input.termId, 'Term ID')
  const curveId = parseBigIntInput(input.curveId, 'Curve ID', DEFAULT_CURVE_ID)
  const shares = parseBigIntInput(input.shares, 'Shares')
  const minAssets = parseBigIntInput(
    input.minAssets,
    'Minimum assets',
    DEFAULT_MIN_ASSETS,
  )
  const txHash = await multiVaultRedeem(writeConfig, {
    args: [receiver, termId, curveId, shares, minAssets],
  })

  return await buildTransactionResult(txHash, 'Redeemed', async () =>
    eventParseRedeemed(writeConfig.publicClient, txHash),
  )
}

export async function redeemBatch(
  writeConfig: WriteConfig,
  input: RedeemBatchInput,
) {
  const receiver = parseReceiverInput(input.receiver, writeConfig.walletClient)
  const termIds = parseBytes32List(input.termIds, 'Term IDs')
  const shares = parseBigIntList(input.shares, 'Shares')
  const curveIds = parseBigIntList(
    input.curveIds,
    'Curve IDs',
    termIds.length,
    DEFAULT_CURVE_ID,
  )
  const minAssets = parseBigIntList(
    input.minAssets,
    'Minimum assets',
    termIds.length,
    DEFAULT_MIN_ASSETS,
  )

  assertMatchingLengths('Shares', termIds.length, shares.length)
  assertMatchingLengths('Curve IDs', termIds.length, curveIds.length)
  assertMatchingLengths('Minimum assets', termIds.length, minAssets.length)

  const txHash = await multiVaultRedeemBatch(writeConfig, {
    args: [receiver, termIds, curveIds, shares, minAssets],
  })

  return await buildTransactionResult(txHash, 'Redeemed', async () =>
    eventParseRedeemed(writeConfig.publicClient, txHash),
  )
}

export async function previewRedeem(
  writeConfig: WriteConfig,
  input: PreviewRedeemInput,
) {
  getConnectedAccount(writeConfig.walletClient)

  const termId = parseBytes32Input(input.termId, 'Term ID')
  const curveId = parseBigIntInput(input.curveId, 'Curve ID', DEFAULT_CURVE_ID)
  const shares = parseBigIntInput(input.shares, 'Shares')
  const [assetsAfterFees, sharesUsed] = await multiVaultPreviewRedeem(
    writeConfig,
    {
      args: [termId, curveId, shares],
    },
  )

  return formatReadRecord({
    termId,
    curveId,
    shares,
    assetsAfterFees,
    sharesUsed,
  })
}

export async function maxRedeem(
  readConfig: ReadConfig,
  input: MaxRedeemInput,
) {
  const sender = parseAddressInput(input.sender, 'Sender')
  const termId = parseBytes32Input(input.termId, 'Term ID')
  const curveId = parseBigIntInput(input.curveId, 'Curve ID', DEFAULT_CURVE_ID)
  const maxRedeemShares = await multiVaultMaxRedeem(readConfig, {
    args: [sender, termId, curveId],
  })

  return formatReadRecord({
    sender,
    termId,
    curveId,
    maxRedeemShares,
  })
}

// ---------------------------------------------------------------------------
// Vault state
// ---------------------------------------------------------------------------

export async function getVault(readConfig: ReadConfig, input: VaultInput) {
  const termId = parseBytes32Input(input.termId, 'Term ID')
  const curveId = parseBigIntInput(input.curveId, 'Curve ID', DEFAULT_CURVE_ID)
  const [totalShares, totalAssets] = await multiVaultGetVault(readConfig, {
    args: [termId, curveId],
  })

  return formatReadRecord({
    termId,
    curveId,
    totalShares,
    totalAssets,
  })
}

export async function getShares(readConfig: ReadConfig, input: SharesInput) {
  const account = parseAddressInput(input.account, 'Account')
  const termId = parseBytes32Input(input.termId, 'Term ID')
  const curveId = parseBigIntInput(input.curveId, 'Curve ID', DEFAULT_CURVE_ID)
  const shares = await multiVaultGetShares(readConfig, {
    args: [account, termId, curveId],
  })

  return formatReadRecord({
    account,
    termId,
    curveId,
    shares,
  })
}

export async function currentSharePrice(
  readConfig: ReadConfig,
  input: VaultInput,
) {
  const termId = parseBytes32Input(input.termId, 'Term ID')
  const curveId = parseBigIntInput(input.curveId, 'Curve ID', DEFAULT_CURVE_ID)
  const sharePrice = await multiVaultCurrentSharePrice(readConfig, {
    args: [termId, curveId],
  })

  return formatReadRecord({
    termId,
    curveId,
    sharePrice,
  })
}

export async function convertToAssets(
  readConfig: ReadConfig,
  input: ConvertToAssetsInput,
) {
  const termId = parseBytes32Input(input.termId, 'Term ID')
  const curveId = parseBigIntInput(input.curveId, 'Curve ID', DEFAULT_CURVE_ID)
  const shares = parseBigIntInput(input.shares, 'Shares')
  const assets = await multiVaultConvertToAssets(readConfig, {
    args: [termId, curveId, shares],
  })

  return formatReadRecord({
    termId,
    curveId,
    shares,
    assets,
  })
}

export async function convertToShares(
  readConfig: ReadConfig,
  input: ConvertToSharesInput,
) {
  const termId = parseBytes32Input(input.termId, 'Term ID')
  const curveId = parseBigIntInput(input.curveId, 'Curve ID', DEFAULT_CURVE_ID)
  const assets = parseBigIntInput(input.assets, 'Assets')
  const shares = await multiVaultConvertToShares(readConfig, {
    args: [termId, curveId, assets],
  })

  return formatReadRecord({
    termId,
    curveId,
    assets,
    shares,
  })
}

// ---------------------------------------------------------------------------
// Protocol config
// ---------------------------------------------------------------------------

export async function getGeneralConfig(readConfig: ReadConfig) {
  const config = await multiVaultGetGeneralConfig(readConfig)

  return formatReadRecord(config as Record<string, unknown>)
}

export async function entryFeeAmount(
  readConfig: ReadConfig,
  input: FeeAmountInput,
) {
  const assets = parseBigIntInput(input.assets, 'Assets')
  const feeAmount = await multiVaultEntryFeeAmount(readConfig, {
    args: [assets],
  })

  return formatReadRecord({
    assets,
    feeAmount,
  })
}

export async function exitFeeAmount(
  readConfig: ReadConfig,
  input: FeeAmountInput,
) {
  const assets = parseBigIntInput(input.assets, 'Assets')
  const feeAmount = await multiVaultExitFeeAmount(readConfig, {
    args: [assets],
  })

  return formatReadRecord({
    assets,
    feeAmount,
  })
}

export async function protocolFeeAmount(
  readConfig: ReadConfig,
  input: FeeAmountInput,
) {
  const assets = parseBigIntInput(input.assets, 'Assets')
  const feeAmount = await multiVaultProtocolFeeAmount(readConfig, {
    args: [assets],
  })

  return formatReadRecord({
    assets,
    feeAmount,
  })
}
