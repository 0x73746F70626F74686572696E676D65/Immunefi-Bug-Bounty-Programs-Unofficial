import { useAccount } from 'wagmi'

import { Header } from '@/components/Header'
import { AtomsSection } from '@/components/sections/AtomsSection'
import { ConfigSection } from '@/components/sections/ConfigSection'
import { DepositsSection } from '@/components/sections/DepositsSection'
import { RedeemSection } from '@/components/sections/RedeemSection'
import { TriplesSection } from '@/components/sections/TriplesSection'
import { VaultSection } from '@/components/sections/VaultSection'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

const sections = [
  {
    id: 'atoms',
    label: 'Atoms',
  },
  {
    id: 'triples',
    label: 'Triples',
  },
  {
    id: 'deposits',
    label: 'Deposits',
  },
  {
    id: 'redemptions',
    label: 'Redemptions',
  },
  {
    id: 'vault-state',
    label: 'Vault State',
  },
  {
    id: 'protocol-config',
    label: 'Protocol Config',
  },
] as const

function App() {
  const { isConnected } = useAccount()

  return (
    <main className="min-h-screen bg-muted/30">
      <div className="mx-auto flex min-h-screen w-full max-w-7xl flex-col gap-8 px-4 py-8 sm:px-6 lg:px-8">
        <section className="space-y-6 rounded-2xl border bg-background p-6 shadow-sm">
          <Header isConnected={isConnected} />

          <Separator />

          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <Card>
              <CardHeader>
                <CardDescription>Sections</CardDescription>
                <CardTitle>6 tabs</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                Atoms, Triples, Deposits, Redemptions, Vault State, and
                Protocol Config.
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardDescription>Teaching Scope</CardDescription>
                <CardTitle>24 protocol panels</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                Each panel wraps one exported MultiVault helper from
                <code className="ml-1 rounded bg-muted px-1.5 py-0.5 text-xs">
                  @0xintuition/protocol
                </code>
                .
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardDescription>Wallet Gate</CardDescription>
                <CardTitle>{isConnected ? 'Unlocked' : 'Connect to enable'}</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                Every form panel is wallet-gated — connect a wallet to
                interact with the protocol.
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardDescription>Network</CardDescription>
                <CardTitle>Intuition Testnet</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                Chain config comes directly from
                <code className="ml-1 rounded bg-muted px-1.5 py-0.5 text-xs">
                  intuitionTestnet
                </code>
                .
              </CardContent>
            </Card>
          </div>
        </section>

        <Tabs defaultValue={sections[0].id} className="flex flex-1 flex-col gap-6">
          <TabsList className="h-auto w-full flex-wrap justify-start gap-2 rounded-2xl border bg-background p-2">
            {sections.map((section) => (
              <TabsTrigger
                key={section.id}
                value={section.id}
                className="rounded-xl px-4 py-2"
              >
                {section.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {sections.map((section) => (
            <TabsContent key={section.id} value={section.id} className="mt-0">
              {section.id === 'atoms' ? <AtomsSection disabled={!isConnected} /> : null}
              {section.id === 'triples' ? (
                <TriplesSection disabled={!isConnected} />
              ) : null}
              {section.id === 'deposits' ? (
                <DepositsSection disabled={!isConnected} />
              ) : null}
              {section.id === 'redemptions' ? (
                <RedeemSection disabled={!isConnected} />
              ) : null}
              {section.id === 'vault-state' ? <VaultSection disabled={!isConnected} /> : null}
              {section.id === 'protocol-config' ? (
                <ConfigSection disabled={!isConnected} />
              ) : null}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </main>
  )
}

export default App
