import { intuitionTestnet } from '@0xintuition/protocol'
import { getDefaultConfig } from '@rainbow-me/rainbowkit'

// A placeholder project ID keeps local builds working until the template user
// adds their own WalletConnect project ID in .env.
const projectId =
  import.meta.env.VITE_WALLETCONNECT_PROJECT_ID ?? 'demo-walletconnect-project-id'

export const config = getDefaultConfig({
  appName: 'Intuition Basic Template',
  projectId,
  chains: [intuitionTestnet],
})
