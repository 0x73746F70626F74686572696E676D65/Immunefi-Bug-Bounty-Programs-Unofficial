import { useEffect, useState } from 'react'

import { ResultDisplay } from '@/components/ResultDisplay'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import type { ReadResult, TransactionResult } from '@/lib/protocol'

export type FormField = {
  name: string
  label: string
  type?: 'text' | 'number'
  placeholder?: string
  defaultValue?: string
  description?: string
}

type FormPanelProps = {
  title: string
  description: string
  fields: FormField[]
  onSubmit: (
    values: Record<string, string>,
  ) => Promise<ReadResult | TransactionResult>
  resultType: 'tx' | 'read' | 'config'
  disabled?: boolean
  submitLabel?: string
}

function buildInitialValues(fields: FormField[]) {
  return Object.fromEntries(
    fields.map((field) => [field.name, field.defaultValue ?? '']),
  )
}

export function FormPanel({
  title,
  description,
  fields,
  onSubmit,
  resultType,
  disabled = false,
  submitLabel = 'Run',
}: FormPanelProps) {
  const fieldsSignature = fields
    .map((field) => `${field.name}:${field.defaultValue ?? ''}`)
    .join('|')
  const [values, setValues] = useState<Record<string, string>>(
    buildInitialValues(fields),
  )
  const [result, setResult] = useState<ReadResult | TransactionResult | null>(
    null,
  )
  const [error, setError] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    setValues(buildInitialValues(fields))
  }, [fieldsSignature])

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setIsSubmitting(true)
    setError(null)

    try {
      const nextResult = await onSubmit(values)
      setResult(nextResult)
    } catch (submitError) {
      const message =
        submitError instanceof Error
          ? submitError.message
          : 'The protocol request failed.'

      setError(message)
      setResult(null)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <form className="space-y-4" onSubmit={handleSubmit}>
          <div className="grid gap-4">
            {fields.map((field) => (
              <div key={field.name} className="space-y-2">
                <Label htmlFor={`${title}-${field.name}`}>{field.label}</Label>
                <Input
                  autoComplete="off"
                  disabled={disabled || isSubmitting}
                  id={`${title}-${field.name}`}
                  inputMode={field.type === 'number' ? 'numeric' : undefined}
                  onChange={(event) =>
                    setValues((current) => ({
                      ...current,
                      [field.name]: event.target.value,
                    }))
                  }
                  placeholder={field.placeholder}
                  type="text"
                  value={values[field.name] ?? ''}
                />
                {field.description ? (
                  <p className="text-xs text-muted-foreground">
                    {field.description}
                  </p>
                ) : null}
              </div>
            ))}
          </div>

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-xs text-muted-foreground">
              {disabled
                ? 'Connect a wallet to enable this panel.'
                : 'Inputs are passed to the protocol helper layer in src/lib/protocol.ts.'}
            </p>

            <Button disabled={disabled || isSubmitting} type="submit">
              {isSubmitting ? 'Running…' : submitLabel}
            </Button>
          </div>
        </form>

        {error ? (
          <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive">
            {error}
          </div>
        ) : null}

        <ResultDisplay result={result} resultType={resultType} />
      </CardContent>
    </Card>
  )
}
