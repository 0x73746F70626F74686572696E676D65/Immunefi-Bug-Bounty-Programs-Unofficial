import { useChainId, usePublicClient, useWalletClient } from 'wagmi'

import { FormPanel } from '@/components/FormPanel'
import {
  deposit,
  depositBatch,
  getAssetLabel,
  getAssetsLabel,
  getWriteConfig,
  previewDeposit,
} from '@/lib/protocol'

type DepositsSectionProps = {
  disabled?: boolean
}

export function DepositsSection({ disabled = false }: DepositsSectionProps) {
  const chainId = useChainId()
  const publicClient = usePublicClient()
  const { data: walletClient } = useWalletClient()

  return (
    <div className="space-y-6">
      <FormPanel
        description="Deposit assets into a single vault. Receiver defaults to the connected wallet, curveId defaults to 1 (LinearCurve), minShares defaults to 0, and the helper parses Deposited events."
        disabled={disabled}
        fields={[
          {
            name: 'termId',
            label: 'Term ID',
            placeholder: '0x...',
          },
          {
            name: 'assets',
            label: getAssetLabel(chainId),
            placeholder: '1000000000000000000',
          },
          {
            name: 'receiver',
            label: 'Receiver',
            placeholder: '0x...',
            description:
              'Optional. Leave blank to use the connected wallet address.',
          },
          {
            name: 'curveId',
            label: 'Curve ID',
            defaultValue: '1',
            placeholder: '1',
          },
          {
            name: 'minShares',
            label: 'Minimum Shares',
            defaultValue: '0',
            placeholder: '0',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient || !walletClient) {
            throw new Error('Connect a wallet before depositing.')
          }

          return deposit(getWriteConfig(chainId, publicClient, walletClient), {
            termId: values.termId,
            assets: values.assets,
            receiver: values.receiver,
            curveId: values.curveId,
            minShares: values.minShares,
          })
        }}
        resultType="tx"
        submitLabel="Deposit"
        title="multiVaultDeposit"
      />

      <FormPanel
        description="Deposit into multiple vaults in a single transaction. Term IDs and asset values are required arrays; curve IDs and minShares arrays are optional and default to 1 and 0 respectively."
        disabled={disabled}
        fields={[
          {
            name: 'termIds',
            label: 'Term IDs',
            placeholder: '0x..., 0x...',
            description:
              'Use commas or new lines. Each entry represents one vault.',
          },
          {
            name: 'assets',
            label: getAssetsLabel(chainId),
            placeholder: '1000000000000000000, 2000000000000000000',
          },
          {
            name: 'receiver',
            label: 'Receiver',
            placeholder: '0x...',
            description:
              'Optional. Leave blank to use the connected wallet address.',
          },
          {
            name: 'curveIds',
            label: 'Curve IDs',
            placeholder: '1, 1',
            description:
              'Optional. Leave blank to use curveId = 1 for every term.',
          },
          {
            name: 'minShares',
            label: 'Minimum Shares',
            placeholder: '0, 0',
            description:
              'Optional. Leave blank to use minShares = 0 for every term.',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient || !walletClient) {
            throw new Error('Connect a wallet before submitting a batch deposit.')
          }

          return depositBatch(getWriteConfig(chainId, publicClient, walletClient), {
            termIds: values.termIds,
            assets: values.assets,
            receiver: values.receiver,
            curveIds: values.curveIds,
            minShares: values.minShares,
          })
        }}
        resultType="tx"
        submitLabel="Deposit batch"
        title="multiVaultDepositBatch"
      />

      <FormPanel
        description="Preview the share output for a deposit before sending a transaction."
        disabled={disabled}
        fields={[
          {
            name: 'termId',
            label: 'Term ID',
            placeholder: '0x...',
          },
          {
            name: 'assets',
            label: getAssetLabel(chainId),
            placeholder: '1000000000000000000',
          },
          {
            name: 'curveId',
            label: 'Curve ID',
            defaultValue: '1',
            placeholder: '1',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient || !walletClient) {
            throw new Error('Connect a wallet before previewing a deposit.')
          }

          return previewDeposit(getWriteConfig(chainId, publicClient, walletClient), {
            termId: values.termId,
            assets: values.assets,
            curveId: values.curveId,
          })
        }}
        resultType="read"
        submitLabel="Preview deposit"
        title="multiVaultPreviewDeposit"
      />
    </div>
  )
}
