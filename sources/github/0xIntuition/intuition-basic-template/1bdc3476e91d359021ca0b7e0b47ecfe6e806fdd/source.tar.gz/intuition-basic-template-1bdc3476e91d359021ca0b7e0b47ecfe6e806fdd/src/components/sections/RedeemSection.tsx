import { useChainId, usePublicClient, useWalletClient } from 'wagmi'

import { FormPanel } from '@/components/FormPanel'
import {
  getReadConfig,
  getWriteConfig,
  maxRedeem,
  previewRedeem,
  redeem,
  redeemBatch,
} from '@/lib/protocol'

type RedeemSectionProps = {
  disabled?: boolean
}

export function RedeemSection({ disabled = false }: RedeemSectionProps) {
  const chainId = useChainId()
  const publicClient = usePublicClient()
  const { data: walletClient } = useWalletClient()
  const connectedAddress = walletClient?.account?.address ?? ''

  return (
    <div className="space-y-6">
      <FormPanel
        description="Redeem shares from a single vault. Receiver defaults to the connected wallet, curveId defaults to 1, minAssets defaults to 0, and the helper parses Redeemed events."
        disabled={disabled}
        fields={[
          {
            name: 'termId',
            label: 'Term ID',
            placeholder: '0x...',
          },
          {
            name: 'shares',
            label: 'Shares',
            placeholder: '1000000000000000000',
          },
          {
            name: 'receiver',
            label: 'Receiver',
            placeholder: '0x...',
            description:
              'Optional. Leave blank to use the connected wallet address.',
          },
          {
            name: 'curveId',
            label: 'Curve ID',
            defaultValue: '1',
            placeholder: '1',
          },
          {
            name: 'minAssets',
            label: 'Minimum Assets',
            defaultValue: '0',
            placeholder: '0',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient || !walletClient) {
            throw new Error('Connect a wallet before redeeming.')
          }

          return redeem(getWriteConfig(chainId, publicClient, walletClient), {
            termId: values.termId,
            shares: values.shares,
            receiver: values.receiver,
            curveId: values.curveId,
            minAssets: values.minAssets,
          })
        }}
        resultType="tx"
        submitLabel="Redeem"
        title="multiVaultRedeem"
      />

      <FormPanel
        description="Redeem shares from multiple vaults in a single transaction. Term IDs and share values are required arrays; curve IDs and minAssets arrays are optional and default to 1 and 0 respectively."
        disabled={disabled}
        fields={[
          {
            name: 'termIds',
            label: 'Term IDs',
            placeholder: '0x..., 0x...',
            description:
              'Use commas or new lines. Each entry represents one vault.',
          },
          {
            name: 'shares',
            label: 'Shares',
            placeholder: '1000000000000000000, 2000000000000000000',
          },
          {
            name: 'receiver',
            label: 'Receiver',
            placeholder: '0x...',
            description:
              'Optional. Leave blank to use the connected wallet address.',
          },
          {
            name: 'curveIds',
            label: 'Curve IDs',
            placeholder: '1, 1',
            description:
              'Optional. Leave blank to use curveId = 1 for every term.',
          },
          {
            name: 'minAssets',
            label: 'Minimum Assets',
            placeholder: '0, 0',
            description:
              'Optional. Leave blank to use minAssets = 0 for every term.',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient || !walletClient) {
            throw new Error('Connect a wallet before submitting a batch redeem.')
          }

          return redeemBatch(getWriteConfig(chainId, publicClient, walletClient), {
            termIds: values.termIds,
            shares: values.shares,
            receiver: values.receiver,
            curveIds: values.curveIds,
            minAssets: values.minAssets,
          })
        }}
        resultType="tx"
        submitLabel="Redeem batch"
        title="multiVaultRedeemBatch"
      />

      <FormPanel
        description="Preview the assets you would receive for a given share redemption."
        disabled={disabled}
        fields={[
          {
            name: 'termId',
            label: 'Term ID',
            placeholder: '0x...',
          },
          {
            name: 'shares',
            label: 'Shares',
            placeholder: '1000000000000000000',
          },
          {
            name: 'curveId',
            label: 'Curve ID',
            defaultValue: '1',
            placeholder: '1',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient || !walletClient) {
            throw new Error('Connect a wallet before previewing a redemption.')
          }

          return previewRedeem(getWriteConfig(chainId, publicClient, walletClient), {
            termId: values.termId,
            shares: values.shares,
            curveId: values.curveId,
          })
        }}
        resultType="read"
        submitLabel="Preview redeem"
        title="multiVaultPreviewRedeem"
      />

      <FormPanel
        description="Read the maximum redeemable shares for an account and vault."
        disabled={disabled}
        fields={[
          {
            name: 'sender',
            label: 'Sender',
            defaultValue: connectedAddress,
            placeholder: '0x...',
          },
          {
            name: 'termId',
            label: 'Term ID',
            placeholder: '0x...',
          },
          {
            name: 'curveId',
            label: 'Curve ID',
            defaultValue: '1',
            placeholder: '1',
          },
        ]}
        onSubmit={async (values) => {
          if (!publicClient) {
            throw new Error('A public client is required to read max redeem.')
          }

          return maxRedeem(getReadConfig(chainId, publicClient), {
            sender: values.sender,
            termId: values.termId,
            curveId: values.curveId,
          })
        }}
        resultType="read"
        submitLabel="Read max redeem"
        title="multiVaultMaxRedeem"
      />
    </div>
  )
}
