import type { ReadResult, ResultValue, TransactionResult } from '@/lib/protocol'

type ResultDisplayProps = {
  result: ReadResult | TransactionResult | null
  resultType: 'tx' | 'read' | 'config'
}

type ResultRow = {
  key: string
  value: string
}

function formatValue(value: ResultValue): string {
  if (value === null) {
    return 'null'
  }

  if (typeof value === 'string' || typeof value === 'boolean') {
    return String(value)
  }

  if (Array.isArray(value) || typeof value === 'object') {
    return JSON.stringify(value, null, 2)
  }

  return String(value)
}

function flattenRecord(record: ReadResult, prefix = ''): ResultRow[] {
  return Object.entries(record).flatMap(([key, value]) => {
    const rowKey = prefix ? `${prefix}.${key}` : key

    if (
      value &&
      typeof value === 'object' &&
      !Array.isArray(value)
    ) {
      return flattenRecord(value as ReadResult, rowKey)
    }

    return [{ key: rowKey, value: formatValue(value) }]
  })
}

function ResultTable({ rows }: { rows: ResultRow[] }) {
  if (!rows.length) {
    return (
      <p className="text-sm text-muted-foreground">
        The operation completed, but there were no fields to render.
      </p>
    )
  }

  return (
    <div className="overflow-hidden rounded-xl border">
      <table className="w-full text-left text-sm">
        <tbody>
          {rows.map((row) => (
            <tr key={row.key} className="border-b last:border-b-0">
              <th className="w-1/3 bg-muted/40 px-3 py-2 font-medium text-foreground">
                {row.key}
              </th>
              <td className="px-3 py-2">
                <pre className="whitespace-pre-wrap break-all font-mono text-xs">
                  {row.value}
                </pre>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export function ResultDisplay({ result, resultType }: ResultDisplayProps) {
  if (!result) {
    return (
      <p className="text-sm text-muted-foreground">
        Submit the form to inspect the protocol response here.
      </p>
    )
  }

  if (resultType === 'tx') {
    const txResult = result as TransactionResult

    return (
      <div className="space-y-4">
        <div className="rounded-xl border bg-muted/30 p-4">
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-muted-foreground">
            Transaction
          </p>
          <p className="mt-2 break-all font-mono text-sm">{txResult.txHash}</p>
          <a
            className="mt-3 inline-flex text-sm font-medium text-primary underline-offset-4 hover:underline"
            href={txResult.explorerUrl}
            rel="noreferrer"
            target="_blank"
          >
            View on Intuition explorer
          </a>
        </div>

        <div className="space-y-3">
          {txResult.events.map((event, index) => (
            <div key={`${event.name}-${index}`} className="space-y-2">
              <p className="text-sm font-medium">
                {event.name} #{index + 1}
              </p>
              <ResultTable rows={flattenRecord(event.values)} />
            </div>
          ))}
        </div>
      </div>
    )
  }

  return <ResultTable rows={flattenRecord(result as ReadResult)} />
}
