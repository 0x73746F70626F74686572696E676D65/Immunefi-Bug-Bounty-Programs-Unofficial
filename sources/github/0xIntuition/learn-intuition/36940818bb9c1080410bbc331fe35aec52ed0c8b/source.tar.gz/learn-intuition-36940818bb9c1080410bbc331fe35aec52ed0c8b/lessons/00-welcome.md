═══════════════════════════════════════════════════════════════
LESSON 00: Welcome to Learn Intuition
═══════════════════════════════════════════════════════════════

## What if you could teach a computer to understand the world?

Not through millions of training examples. Not through complicated rules.
Through something much simpler: **a shared dictionary and a way to make claims about reality.**

That's what the Intuition protocol does. And this course will teach you how it works — from the inside out.

## What Is This Course?

Learn Intuition is an interactive course that runs inside Claude Code. You're not reading a textbook — you're having a conversation with an instructor (me!) who will guide you through the protocol step by step.

Each lesson follows a simple pattern:
1. **A hook** — why this matters
2. **The concept** — what it is
3. **How it works** — the mechanics
4. **Try it** — hands-on exercises

## What You'll Learn

### Part 1: Understanding the Knowledge Graph (This Part)
You'll build a mental model of Intuition's three primitives:
- **Atoms** — universal identifiers for anything
- **Triples** — structured claims that connect atoms
- **Signals** — economic conviction expressed through staking

By the end of Part 1, you'll understand what the knowledge graph is, how it's structured, and why the economic model makes it work.

### Part 2: Building with the Protocol
You'll write code that interacts with the protocol:
- Set up the protocol package and connect to testnet
- Create atoms and triples programmatically
- Query the knowledge graph with on-chain reads and GraphQL
- Read vault state and signal data

### Part 3: Building Real Applications
You'll go from course to real-world:
- Navigate the Intuition ecosystem independently
- Set up your project for AI-assisted development
- Capstone project: build a real Intuition app

## How to Navigate

| Command | What it does |
|---------|-------------|
| `/learn` | Show course dashboard |
| `/learn next` | Start the next lesson |
| `/learn progress` | View your progress stats |
| `/learn reset` | Reset progress and start over |
| `/learn 00`-`11` | Jump to a specific lesson |

You can pause anytime — your progress is saved automatically. Come back and type `/learn` to pick up where you left off.

## Try It

Before we dive into the protocol, let's make sure everything is set up:

1. **Check your dashboard**: Type `/learn` to see the course overview. You should see all 12 lessons listed.

2. **Explore the Portal**: Open https://portal.intuition.systems in your browser. This is the human-friendly interface to Intuition's knowledge graph. Take a minute to click around — you'll see atoms, triples, and staking activity. Don't worry if it doesn't all make sense yet. It will.

3. **Ready?** When you're set, type `/learn next` to start Lesson 01: What is Intuition?

Welcome aboard. Let's build some knowledge.
