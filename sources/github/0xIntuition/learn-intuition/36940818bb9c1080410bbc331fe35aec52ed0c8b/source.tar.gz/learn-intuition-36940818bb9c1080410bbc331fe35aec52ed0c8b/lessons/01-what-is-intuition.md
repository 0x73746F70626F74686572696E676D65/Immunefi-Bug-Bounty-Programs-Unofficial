═══════════════════════════════════════════════════════════════
LESSON 01: What is Intuition?
═══════════════════════════════════════════════════════════════

## The Problem: Knowledge is Trapped

Think about everything you know — about people, projects, tools, ideas. Now think about where that knowledge lives:
- Some is in your head
- Some is in private databases (LinkedIn, GitHub, Google)
- Some is scattered across docs, chats, and emails

None of it is **connected**. None of it is **verifiable**. And none of it **belongs to you**.

When LinkedIn says "Alice knows TypeScript" — who decided that? Can you trust it? Can you build on it? Can Alice take that claim with her if she leaves LinkedIn?

**Intuition solves this.** It creates a shared, open, economically-incentivized knowledge graph where anyone can make claims about reality — and the community decides what's true through staking.

## The Vision: A Global Knowledge Graph

Imagine a single graph that contains structured knowledge about everything:
- People and their skills
- Projects and their contributors
- Contracts and their safety
- Ideas and their relationships

Not owned by any company. Not controlled by any committee. Built by everyone, curated by economic incentives, and readable by humans and machines alike.

That's Intuition.

## Three Primitives

The entire protocol is built from just three concepts. That's it. Three primitives that compose into arbitrarily complex knowledge:

### 1. Atoms — "The Words"
Unique identifiers for anything. Think of them as entries in a global dictionary.
- An atom for "TypeScript"
- An atom for "Alice"
- An atom for "knows"

### 2. Triples — "The Sentences"
Structured claims that connect three atoms: [Subject] — [Predicate] — [Object]
- `[Alice] — [knows] — [TypeScript]`
- `[Ethereum] — [created by] — [Vitalik]`

### 3. Signals — "The Conviction"
Economic weight expressed by staking tokens on atoms and triples.
- Stake on an atom = "I think this identifier matters"
- Stake FOR a triple = "I believe this claim is true"
- Stake AGAINST a triple = "I think this claim is false"

That's the whole model. Everything else — vaults, bonding curves, fees, the knowledge graph itself — emerges from these three primitives composing together.

## Why It Matters

### For Developers
You can build applications on top of a shared knowledge layer instead of maintaining your own siloed database. Query the graph, contribute to it, and build on what others have created.

### For AI Agents
Agents need structured, verifiable knowledge to make decisions. Intuition provides exactly that — a machine-readable graph with economic signals about what's trustworthy.

### For Everyone
Your knowledge, reputation, and attestations become portable, verifiable, and owned by you. No platform lock-in. No central authority deciding what's true.

## The Stack

```
┌─────────────────────────────────┐
│  Applications (Portal, dApps)   │
├─────────────────────────────────┤
│  SDK / GraphQL API              │
├─────────────────────────────────┤
│  MultiVault Contract            │
│  (atoms, triples, vaults)       │
├─────────────────────────────────┤
│  Intuition L3 (Base + Orbit)    │
├─────────────────────────────────┤
│  Ethereum Security              │
└─────────────────────────────────┘
```

Everything lives on-chain. The MultiVault smart contract is the single entry point for creating atoms, triples, and managing vaults. An indexer watches for events and feeds a GraphQL API. Applications like the Portal read from the API and write through the contract.

## Quick Reference

| Concept | What It Is | Analogy |
|---------|-----------|---------|
| Atom | Unique identifier for anything | A word in a dictionary |
| Triple | Structured claim (S-P-O) | A sentence made from words |
| Signal | Economic conviction via staking | A bet on what's true |
| Knowledge Graph | Network of atoms + triples + signals | A weighted web of knowledge |
| MultiVault | Core smart contract | The engine room |
| Portal | Web interface | The front door |

## Try It

1. **Map the mental model**: In your own words, explain Intuition to an imaginary colleague. Use the three primitives. Can you explain each one in a single sentence?

2. **Find atoms in the wild**: Open the Portal (https://portal.intuition.systems) and search for a concept you care about — a programming language, a person, a project. What atoms exist for it? Do any have staking activity?

3. **Think in triples**: Pick three things you know to be true (e.g., "Python is a programming language", "Vitalik created Ethereum", "React uses JSX"). Write each as a triple in [Subject]-[Predicate]-[Object] format. Notice how you need atoms for each component.

4. **Conviction question**: If you could stake tokens on one claim right now — something you're confident is true and important — what would it be? Write it as a triple.

When you've worked through these, type `/learn next` for Lesson 02: Atoms & Identifiers.
