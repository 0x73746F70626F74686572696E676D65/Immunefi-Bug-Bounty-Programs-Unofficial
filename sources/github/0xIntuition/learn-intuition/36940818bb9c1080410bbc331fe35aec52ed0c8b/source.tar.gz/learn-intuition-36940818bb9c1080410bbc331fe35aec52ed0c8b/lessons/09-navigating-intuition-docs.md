===============================================================
LESSON 09: Navigating the Intuition Ecosystem
===============================================================

## You know the protocol. Now learn to find answers yourself.

In Parts 1 and 2, you built understanding from curated lessons and pre-selected reference materials. But real builders don't learn from courses — they learn from docs, source code, and experimentation.

This lesson teaches you how to navigate Intuition's ecosystem so you can answer your own questions, find patterns, and build with confidence beyond what any course can cover.

## The Documentation Landscape

Intuition's docs live at https://docs.intuition.systems and cover:

| Section | What's There | When to Use |
|---------|-------------|-------------|
| **Quick Start** | Network details, faucet, deployments | Starting a new project |
| **Core Concepts** | Architecture, primitives, economics | Understanding the "why" |
| **Developer Tools** | Protocol package, GraphQL API, smart contracts | Building and integrating |
| **Tutorials** | Reputation, curated lists, attestations, fraud detection | Learning patterns |
| **Resources** | FAQ, glossary, community links | Quick reference |

### AI-Friendly Documentation

The docs also publish machine-readable formats following the **llms.txt standard** — a convention for making documentation consumable by AI. If you're using an AI assistant, it can fetch these to answer protocol questions accurately instead of guessing.

## Where to Find What

Different questions call for different sources. Knowing where to look is the real skill:

| Question | Best Source | Why |
|----------|-----------|-----|
| "How does X work conceptually?" | Docs → Core Concepts | Authoritative explanations |
| "What's the function signature for Y?" | Protocol package source or docs | Exact API details |
| "What does atom Z look like?" | Portal (`portal.intuition.systems`) | Live data, visual exploration |
| "What atoms exist for 'TypeScript'?" | GraphQL API | Programmatic, searchable |
| "What's the current atom creation cost?" | `multiVaultGetAtomCost(readConfig)` | On-chain, always accurate |
| "Show me example code for X" | Docs → Tutorials | Worked examples with context |
| "What contract address do I use?" | `getMultiVaultAddressFromChainId(chainId)` | Programmatic, chain-aware |
| "What's happening on the graph right now?" | Testnet Portal | Real-time activity feed |

### The Key Insight

**Docs explain intent. On-chain data shows reality.**

The docs tell you how things are *designed to work*. The protocol package and GraphQL show you how they *actually work right now*. When they diverge, trust the chain.

This is why Part 2 taught you both on-chain reads (protocol package) and indexed reads (GraphQL). In practice, you'll use the docs to understand a concept, then verify with live data:

```
"How do atom creation costs work?"
  → Read the docs for the concept
  → Call multiVaultGetAtomCost(readConfig) for the current value
  → Cross-reference if needed
```

## The GitHub Ecosystem

Intuition's code lives at https://github.com/0xIntuition. Key repos to know:

| Repo | What's There | When to Use |
|------|-------------|-------------|
| **protocol** | Smart contracts (MultiVault, bonding curves) | Understanding what's on-chain |
| **docs** | Documentation source | Contributing or checking freshness |
| **agent-skills** | AI agent skills for protocol interaction | Building AI-augmented apps |

When the docs don't have what you need, the source code is the ultimate reference. The protocol package's TypeScript source shows you exactly what every function does.

## The Portal as a Learning Tool

The Portal at https://portal.intuition.systems is more than a UI — it's a research tool:

- **Search** to find atoms and triples by text
- **Inspect atoms** to see their vault state, creator, and data
- **Inspect triples** to see FOR/AGAINST conviction ratios
- **Browse activity** to see what's being created and staked on
- **Explore curated lists** to see the "has tag" pattern in action

The testnet Portal (https://testnet.portal.intuition.systems) mirrors the same functionality for the testnet chain. Use it to verify your Part 2 exercises — anything you created on-chain should be visible there.

## The GraphQL Explorer

The GraphQL endpoint (`https://testnet.intuition.sh/v1/graphql`) is also explorable directly. You can use any GraphQL client (like Insomnia, Hoppscotch, or the built-in GraphiQL if available) to:

- Explore the schema interactively
- Test queries before putting them in code
- Discover available fields and relationships

This is especially useful when you need data that the docs don't cover — you can browse the schema to find what's queryable.

## Building Your Research Workflow

When you hit a question the course didn't cover, here's a systematic approach:

```
1. Check the docs first
   → Search or browse for the concept
   
2. Try it on-chain
   → Use your Part 2 setup to query live data
   → multiVaultGet* functions for contract state
   → GraphQL for indexed/searchable data

3. Look at the Portal
   → Visual confirmation of what you found
   → Real examples of atoms, triples, and staking

4. Read the source
   → Protocol package source for function details
   → Smart contract source for on-chain logic

5. Ask the community
   → Discord for discussion and help
   → GitHub issues for bugs or feature questions
```

## The Tutorials

The docs include 6+ full tutorials that go deeper than this course on specific patterns:

- **Reputation Systems** — Using triples and conviction to build reputation
- **Curated Lists** — The "has tag" pattern you learned in Lesson 07
- **Attestations** — Structured claims with on-chain evidence
- **Fraud Detection** — Using the graph for risk analysis
- **Prediction Markets** — Markets built on triple conviction

Each tutorial is a complete building pattern. When you're ready to build something specific, these are your starting points.

## Quick Reference

```
Docs:             https://docs.intuition.systems
Portal:           https://portal.intuition.systems
Testnet Portal:   https://testnet.portal.intuition.systems
GraphQL:          https://testnet.intuition.sh/v1/graphql
Faucet:           https://testnet.hub.intuition.systems/
GitHub:           https://github.com/0xIntuition
Discord:          https://discord.gg/RgBenkX4mx
```

## Try It

1. **Navigate the docs**: Go to https://docs.intuition.systems and find the answer to: "What happens when you try to create an atom that already exists?" Don't search — browse the sections to find it. Which section was it in?

2. **Docs vs live data**: Look up the current atom creation cost in two ways: (a) find the answer in the docs and (b) use `multiVaultGetAtomCost` from your Part 2 setup. Do they match? Which one would you trust if they didn't?

3. **Portal exploration**: Go to the testnet Portal and find the most-staked atom. What is it? What does the TVL tell you about community conviction?

4. **Ask the right source**: For each question, decide which source you'd use:
   - "What predicates are most commonly used?" → _____
   - "How do exit fees work?" → _____
   - "Does an atom for 'Rust' exist on testnet?" → _____
   - "What's the architecture of the indexer?" → _____

5. **Explore a tutorial**: Pick one tutorial from the docs that interests you (reputation, curated lists, fraud detection). Read through it. What atoms and triples would you need? Could you build it with what you've learned?

---

You now know where to find answers to any Intuition question. Next, you'll learn how to set up your project so AI can help you build effectively — through context engineering.

Type `/learn next` for Lesson 10: Context Engineering for Intuition, or `/learn` for the dashboard.
