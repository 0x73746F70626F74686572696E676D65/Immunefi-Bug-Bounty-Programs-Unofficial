===============================================================
LESSON 08: Querying the Graph
===============================================================

## The knowledge graph is only as useful as your ability to read it.

You can create atoms and triples all day, but the real power comes from *querying* — finding patterns, reading conviction scores, discovering what the community has built. This is where the knowledge graph becomes a tool.

Every function in this lesson works read-only. No wallet, no tokens, no cost.

## Two Read Layers

Intuition gives you two complementary ways to read the graph:

| Layer | What It Is | Best For |
|-------|-----------|----------|
| **Protocol package** (on-chain reads) | Direct contract queries via `multiVaultGet*` | Real-time vault state, costs, existence checks |
| **GraphQL** (indexed reads) | Indexed data with search, labels, metadata | Search, lists, positions, rich metadata |

Think of it like a database: the protocol package is reading directly from the blockchain (always authoritative, always current), while GraphQL gives you indexed views with text search, labels, and aggregations.

You'll use both in real applications. Let's start with on-chain reads and then add GraphQL.

## On-Chain Reads: The Protocol Package

These functions query the MultiVault contract directly. They're always accurate and up-to-date.

### Reading Atoms

```typescript
import {
  multiVaultIsTermCreated,
  multiVaultGetAtom,
} from '@0xintuition/protocol'
import { fromHex, type Hex } from 'viem'
import { readConfig } from './setup'

// Check if a term exists
const exists = await multiVaultIsTermCreated(readConfig, { args: [termId] })
console.log('Term exists:', exists)

// Read the raw atom data
if (exists) {
  const atomData = await multiVaultGetAtom(readConfig, { args: [termId] })
  const decoded = fromHex(atomData as Hex, 'string')
  console.log('Atom data:', decoded)
}
```

### Reading Triples

```typescript
import {
  multiVaultGetTriple,
  multiVaultIsTriple,
  multiVaultGetInverseTripleId,
} from '@0xintuition/protocol'

// Get a triple's components
const [subjectId, predicateId, objectId] = await multiVaultGetTriple(readConfig, {
  args: [tripleTermId],
})

// Check if a term is a triple
const isTriple = await multiVaultIsTriple(readConfig, { args: [tripleTermId] })

// Get the AGAINST (inverse) triple ID
const inverseId = await multiVaultGetInverseTripleId(readConfig, { args: [tripleTermId] })
```

### Reading Vault State (Conviction Data)

This is where signals come alive — you can read the actual staking data for any atom or triple:

```typescript
import {
  multiVaultGetVault,
  multiVaultGetShares,
  multiVaultCurrentSharePrice,
} from '@0xintuition/protocol'
import { formatEther } from 'viem'

const curveId = 1n  // default bonding curve

// Read vault totals (TVL)
const [totalShares, totalAssets] = await multiVaultGetVault(readConfig, {
  args: [termId, curveId],
})
console.log('Total staked:', formatEther(totalAssets), 'tTRUST')
console.log('Total shares:', totalShares)

// Read a specific account's position
const myShares = await multiVaultGetShares(readConfig, {
  args: [walletAddress, termId, curveId],
})
console.log('My shares:', myShares)

// Get the current share price
const price = await multiVaultCurrentSharePrice(readConfig, {
  args: [termId, curveId],
})
console.log('Share price:', price)
```

For triples, read both the FOR and AGAINST vaults:

```typescript
import { calculateCounterTripleId } from '@0xintuition/protocol'

// FOR vault — people who agree with the triple
const [forShares, forAssets] = await multiVaultGetVault(readConfig, {
  args: [tripleTermId, curveId],
})

// AGAINST vault — people who disagree
const counterTripleId = calculateCounterTripleId(tripleTermId)
const [againstShares, againstAssets] = await multiVaultGetVault(readConfig, {
  args: [counterTripleId, curveId],
})

console.log('FOR:', formatEther(forAssets), 'tTRUST')
console.log('AGAINST:', formatEther(againstAssets), 'tTRUST')

// Simple conviction ratio
const forAmount = Number(formatEther(forAssets))
const againstAmount = Number(formatEther(againstAssets))
const total = forAmount + againstAmount
if (total > 0) {
  console.log(`Conviction: ${((forAmount / total) * 100).toFixed(1)}% FOR`)
}
```

### Deposit and Redeem Previews

Before staking, you can preview what you'd receive:

```typescript
import {
  multiVaultPreviewDeposit,
  multiVaultPreviewRedeem,
} from '@0xintuition/protocol'
import { parseEther } from 'viem'

// Preview: how many shares for a deposit of 0.01 tTRUST?
const depositAmount = parseEther('0.01')
const [shares, assetsAfterFees] = await multiVaultPreviewDeposit(writeConfig, {
  args: [termId, curveId, depositAmount],
})
console.log('Deposit', formatEther(depositAmount), '→', shares, 'shares')
console.log('After fees:', formatEther(assetsAfterFees))

// Preview: how many assets for redeeming 100 shares?
const sharesToRedeem = 100n
const [assetsBack, sharesUsed] = await multiVaultPreviewRedeem(writeConfig, {
  args: [termId, curveId, sharesToRedeem],
})
console.log('Redeem', sharesToRedeem, 'shares →', formatEther(assetsBack), 'tTRUST')
```

### Protocol Configuration

Read the protocol's economics:

```typescript
import {
  multiVaultGetAtomCost,
  multiVaultGetTripleCost,
  multiVaultGetAtomConfig,
  multiVaultGetTripleConfig,
  multiVaultGetGeneralConfig,
  multiVaultEntryFeeAmount,
  multiVaultExitFeeAmount,
} from '@0xintuition/protocol'
import { formatEther, parseEther } from 'viem'

// Creation costs
const atomCost = await multiVaultGetAtomCost(readConfig)
const tripleCost = await multiVaultGetTripleCost(readConfig)
console.log('Atom cost:', formatEther(atomCost), 'tTRUST')
console.log('Triple cost:', formatEther(tripleCost), 'tTRUST')

// Fee amounts for a 1 tTRUST deposit
const amount = parseEther('1')
const entryFee = await multiVaultEntryFeeAmount(readConfig, { args: [amount] })
const exitFee = await multiVaultExitFeeAmount(readConfig, { args: [amount] })
console.log('Entry fee on 1 tTRUST:', formatEther(entryFee))
console.log('Exit fee on 1 tTRUST:', formatEther(exitFee))

// Full config objects
const generalConfig = await multiVaultGetGeneralConfig(readConfig)
const atomConfig = await multiVaultGetAtomConfig(readConfig)
const tripleConfig = await multiVaultGetTripleConfig(readConfig)
```

## GraphQL: The Indexed Read Layer

On-chain reads give you raw contract data, but some things are much easier with an indexed database: text search, labels, positions across vaults, sorted results. That's what GraphQL provides.

### Setting Up a Client

```typescript
const GRAPHQL_ENDPOINT = 'https://testnet.intuition.sh/v1/graphql'

async function queryGraphql<T>(
  query: string,
  variables?: Record<string, unknown>
): Promise<T> {
  const response = await fetch(GRAPHQL_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables }),
  })
  const json = await response.json()
  return json.data as T
}
```

This is a simple fetch-based client. For production apps, use `graphql-request` or a similar library.

### Searching Atoms

Text search across the knowledge graph — something you can't do with on-chain reads alone:

```typescript
const SEARCH_ATOMS = `
  query SearchAtoms($search: String!, $limit: Int = 8) {
    atoms(
      where: { _or: [
        { label: { _ilike: $search } },
        { data: { _ilike: $search } }
      ]}
      limit: $limit
      order_by: { block_timestamp: desc }
    ) {
      term_id
      label
      data
      creator { label id }
      vault { total_shares total_assets current_share_price }
    }
  }
`

const results = await queryGraphql<{ atoms: any[] }>(SEARCH_ATOMS, {
  search: '%ethereum%',  // % is the wildcard for _ilike
  limit: 10,
})

console.log('Search results for "ethereum":')
for (const atom of results.atoms) {
  console.log(`  [${atom.term_id}] ${atom.label ?? atom.data}`)
  if (atom.vault?.total_assets) {
    console.log(`    TVL: ${atom.vault.total_assets}`)
  }
}
```

### Getting a Single Atom with Metadata

```typescript
const GET_ATOM = `
  query GetAtom($termId: String!) {
    atom(term_id: $termId) {
      term_id
      label
      data
      creator { label id }
      vault { total_shares total_assets current_share_price }
    }
  }
`

const { atom } = await queryGraphql<{ atom: any }>(GET_ATOM, {
  termId: '0x...',  // a real term ID
})

if (atom) {
  console.log('Label:', atom.label)
  console.log('Data:', atom.data)
  console.log('Creator:', atom.creator?.label ?? atom.creator?.id)
}
```

### Curated Lists (The "has tag" Pattern)

Curated lists in Intuition use triples with the "has tag" predicate. The pattern is:

```
[item] -[has_tag]-> [list]
```

You can query all items in a list:

```typescript
const GET_LIST_ITEMS = `
  query GetListItems($listId: String!, $predicateId: String!) {
    triples(
      where: {
        object_id: { _eq: $listId }
        predicate_id: { _eq: $predicateId }
      }
    ) {
      term_id
      subject { term_id label }
      predicate { term_id label }
      object { term_id label }
      vault { total_shares total_assets }
      counter_vault { total_shares total_assets }
    }
  }
`
```

This is how the Intuition Portal displays curated lists — it's a GraphQL query over triples filtered by predicate.

### User Positions

See what a user has staked on across the graph:

```typescript
const GET_USER_POSITIONS = `
  query GetUserPositions($address: String!) {
    positions(where: { account_id: { _eq: $address } }) {
      term_id
      shares
      atom { term_id label }
      triple {
        term_id
        subject { label }
        predicate { label }
        object { label }
      }
    }
  }
`

const { positions } = await queryGraphql<{ positions: any[] }>(
  GET_USER_POSITIONS,
  { address: '0x...' }
)

for (const pos of positions) {
  if (pos.atom) {
    console.log(`Atom: ${pos.atom.label} — ${pos.shares} shares`)
  }
  if (pos.triple) {
    const t = pos.triple
    console.log(`Triple: [${t.subject.label}]-[${t.predicate.label}]-[${t.object.label}] — ${pos.shares} shares`)
  }
}
```

## When to Use Each Layer

| Need | Use |
|------|-----|
| "Does this atom exist?" | `multiVaultIsTermCreated` (on-chain) |
| "What's the current vault TVL?" | `multiVaultGetVault` (on-chain) |
| "How many shares would I get?" | `multiVaultPreviewDeposit` (on-chain) |
| "Search for atoms about X" | GraphQL `atoms` query with `_ilike` |
| "Show all items in a list" | GraphQL `triples` query filtered by predicate |
| "Show my positions across all vaults" | GraphQL `positions` query |
| "Get atom label and creator name" | GraphQL `atom` query (on-chain only has raw hex) |

**Rule of thumb:** Use on-chain reads for authoritative state (costs, balances, existence). Use GraphQL for discovery, search, and human-readable metadata.

## Building an Explorer Script

Let's combine both layers into a useful exploration tool:

```typescript
import {
  multiVaultGetVault,
  multiVaultIsTermCreated,
} from '@0xintuition/protocol'
import { formatEther, type Hex } from 'viem'
import { readConfig } from './setup'

const GRAPHQL_ENDPOINT = 'https://testnet.intuition.sh/v1/graphql'
const curveId = 1n

async function queryGraphql<T>(query: string, variables?: Record<string, unknown>): Promise<T> {
  const response = await fetch(GRAPHQL_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables }),
  })
  const json = await response.json()
  return json.data as T
}

async function exploreGraph(topic: string) {
  console.log(`\n=== Exploring: "${topic}" ===\n`)

  // Step 1: Search via GraphQL (indexed, has labels)
  const { atoms } = await queryGraphql<{ atoms: any[] }>(`
    query($search: String!) {
      atoms(
        where: { _or: [
          { label: { _ilike: $search } },
          { data: { _ilike: $search } }
        ]}
        limit: 5
        order_by: { block_timestamp: desc }
      ) { term_id label data }
    }
  `, { search: `%${topic}%` })

  if (!atoms.length) {
    console.log('No atoms found.')
    return
  }

  // Step 2: For each result, read vault state on-chain (authoritative)
  for (const atom of atoms) {
    const termId = atom.term_id as Hex
    const [totalShares, totalAssets] = await multiVaultGetVault(readConfig, {
      args: [termId, curveId],
    })

    console.log(`[${atom.label ?? atom.data}]`)
    console.log(`  Term ID: ${termId.slice(0, 18)}...`)
    console.log(`  TVL: ${formatEther(totalAssets)} tTRUST (${totalShares} shares)`)
  }
}

await exploreGraph('TypeScript')
await exploreGraph('ethereum')
```

This script uses GraphQL for discovery (search by name) and on-chain reads for authoritative data (vault state). That's the pattern real Intuition applications follow.

## Key Concepts

| Concept | Detail |
|---------|--------|
| `multiVaultIsTermCreated` | Check if an atom or triple exists on-chain |
| `multiVaultGetAtom` | Read raw atom data by term ID |
| `multiVaultGetTriple` | Read a triple's subject, predicate, object |
| `multiVaultGetVault` | Read vault totals (shares + assets = TVL) |
| `multiVaultGetShares` | Read a specific account's shares in a vault |
| `multiVaultCurrentSharePrice` | Current price per share in a vault |
| `multiVaultPreviewDeposit` | Preview shares received for a deposit |
| `multiVaultPreviewRedeem` | Preview assets received for a redemption |
| `multiVaultEntryFeeAmount` | Calculate the entry fee for an amount |
| GraphQL `atoms` query | Search atoms by label/data with metadata |
| GraphQL `triples` query | Query triples with subject/predicate/object labels |
| GraphQL `positions` query | Get a user's positions across all vaults |

## Quick Reference

```
On-chain reads:
  Exists?           multiVaultIsTermCreated(readConfig, { args: [termId] })
  Atom data:        multiVaultGetAtom(readConfig, { args: [termId] })
  Triple components: multiVaultGetTriple(readConfig, { args: [tripleId] })
  Vault TVL:        multiVaultGetVault(readConfig, { args: [termId, curveId] })
  My shares:        multiVaultGetShares(readConfig, { args: [account, termId, curveId] })
  Share price:      multiVaultCurrentSharePrice(readConfig, { args: [termId, curveId] })
  Preview deposit:  multiVaultPreviewDeposit(writeConfig, { args: [termId, curveId, amount] })
  Preview redeem:   multiVaultPreviewRedeem(writeConfig, { args: [termId, curveId, shares] })

GraphQL:
  Endpoint:         https://testnet.intuition.sh/v1/graphql
  Search atoms:     atoms(where: { label: { _ilike: "%query%" } })
  Get atom:         atom(term_id: "0x...")
  List items:       triples(where: { predicate_id: { _eq: "..." }, object_id: { _eq: "..." } })
  User positions:   positions(where: { account_id: { _eq: "0x..." } })
```

## Try It

1. **Read vault state**: Pick an atom you know exists (from your Lesson 06 exercises or by searching) and read its vault state with `multiVaultGetVault`. What do the shares and assets numbers tell you?

2. **Compare FOR/AGAINST**: Find a triple and read both its FOR vault and AGAINST vault. Calculate the conviction ratio. What does it tell you about community consensus?

3. **Search with GraphQL**: Write a GraphQL query to search for atoms matching a topic you're interested in. How do the results compare to what you'd get from on-chain reads alone?

4. **Build the explorer**: Take the `exploreGraph` script and extend it. Add: triple search results, FOR/AGAINST conviction ratios for triples, and user position lookups.

5. **Preview economics**: Use `multiVaultPreviewDeposit` to see how many shares you'd get for different deposit amounts on the same vault. Notice how the bonding curve affects the share price — larger vaults give fewer shares per token.

6. **Read protocol config**: Use `multiVaultGetAtomCost`, `multiVaultGetTripleCost`, and `multiVaultEntryFeeAmount` to understand the protocol's economics. How does this connect to what you learned in Lesson 04?

---

**Congratulations!** You've completed Part 2: Building with the Protocol. You can now:
- Set up a project and connect to Intuition
- Calculate deterministic IDs for atoms and triples
- Create atoms and triples on-chain
- Read vault state, conviction data, and share prices
- Query the graph with both on-chain reads and GraphQL
- Preview deposits and understand protocol economics

You've gone from understanding concepts (Part 1) to writing working code (Part 2). Part 3 will take you from course to real-world — navigating the ecosystem, setting up your project for AI-assisted development, and building a real application.

Type `/learn progress` to see your stats, or `/learn` for the dashboard.
