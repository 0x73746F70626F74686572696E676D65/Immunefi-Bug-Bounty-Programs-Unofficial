===============================================================
LESSON 05: Setting Up the Protocol
===============================================================

## You understand the concepts. Now let's write code.

In Part 1, you learned what atoms, triples, and signals are — and why they matter. But understanding a protocol and *building on it* are different things. This lesson bridges that gap.

By the end of this lesson, you'll have a working TypeScript project that talks to Intuition's knowledge graph. You'll make your first real protocol call and see live on-chain data.

## Why a Protocol Package?

You could interact with Intuition's MultiVault contract by manually encoding ABI calls. But the `@0xintuition/protocol` package gives you:

- **Type-safe functions** for every MultiVault operation
- **Deterministic ID calculation** (offline, no gas needed)
- **Event parsers** to extract structured results from transactions
- **Chain configuration** with RPC URLs, explorer links, and contract addresses
- **Batch operations** for creating multiple atoms or triples at once

The protocol package is built on **viem** (a modern Ethereum library) and gives you direct access to every MultiVault function — no abstractions hiding what's happening on-chain.

## What You'll Build

A Bun + TypeScript project with two capabilities:

1. **Read-only access** (publicClient) — query the graph, calculate IDs, read costs. Free, no wallet needed.
2. **Write access** (walletClient) — create atoms, triples, stake. Needs testnet tokens.

Every exercise in this lesson works with just the read-only setup. Write access is optional for learners who want the full experience.

## Before You Start

You'll need a JavaScript runtime to follow along. We use **Bun** in this course, but Node.js works too.

| Tool | Check | Install |
|------|-------|---------|
| Bun | `bun --version` | `curl -fsSL https://bun.sh/install \| bash` |
| Node (alternative) | `node --version` | https://nodejs.org |

If you just want to read along and understand the patterns without running code, that's fine too — you can always come back and build later.

## Step 1: Project Setup with Bun

Create a new project and install dependencies:

```bash
mkdir intuition-explorer
cd intuition-explorer
bun init -y
bun add @0xintuition/protocol viem
```

This gives you:
- `package.json` with the protocol package and viem
- `tsconfig.json` (Bun's default TypeScript config)
- An `index.ts` entry point

## Step 2: Creating a Public Client (Read-Only)

The public client connects to Intuition's network and lets you read data — no wallet, no tokens, no cost.

Create a file called `setup.ts`:

```typescript
import {
  getMultiVaultAddressFromChainId,
  intuitionTestnet,
  type ReadConfig,
} from '@0xintuition/protocol'
import { createPublicClient, http } from 'viem'

// Create a read-only client connected to Intuition testnet
export const publicClient = createPublicClient({
  chain: intuitionTestnet,
  transport: http(),
})

// Read config — used by all protocol read functions
export const readConfig: ReadConfig = {
  address: getMultiVaultAddressFromChainId(intuitionTestnet.id),
  publicClient,
}

console.log('Connected to:', intuitionTestnet.name)
console.log('Chain ID:', intuitionTestnet.id)
console.log('MultiVault:', readConfig.address)
console.log('RPC:', intuitionTestnet.rpcUrls.default.http[0])
```

Run it:

```bash
bun run setup.ts
```

You should see:

```
Connected to: Intuition Testnet
Chain ID: 13579
MultiVault: 0x2Ece8D4dEdcB9918A398528f3fa4688b1d2CAB91
RPC: https://testnet.rpc.intuition.systems/http
```

### What Just Happened?

- `intuitionTestnet` is a viem chain definition that knows Intuition's RPC URL, chain ID, native token (tTRUST), and explorer
- `createPublicClient` creates a read-only connection — it can query the blockchain but can't sign transactions
- `getMultiVaultAddressFromChainId` resolves the correct MultiVault contract address for your chain — no hardcoding needed
- `ReadConfig` bundles the contract address and client together — every protocol read function takes this as its first argument

## Step 3: Your First Protocol Call

Now let's read real data from the contract. Create `first-read.ts`:

```typescript
import { multiVaultGetAtomCost, multiVaultGetTripleCost } from '@0xintuition/protocol'
import { formatEther } from 'viem'
import { readConfig } from './setup'

// Read the current cost to create an atom
const atomCost = await multiVaultGetAtomCost(readConfig)
console.log('Atom creation cost:', formatEther(atomCost), 'tTRUST')

// Read the current cost to create a triple
const tripleCost = await multiVaultGetTripleCost(readConfig)
console.log('Triple creation cost:', formatEther(tripleCost), 'tTRUST')
```

Run it:

```bash
bun run first-read.ts
```

You just queried the MultiVault contract directly and got live protocol data. These costs tell you the minimum amount of tTRUST needed to create atoms and triples.

## Step 4: Calculate an Atom ID (Offline)

One of the protocol package's most useful features works without any network at all. Create `calculate-id.ts`:

```typescript
import { calculateAtomId } from '@0xintuition/protocol'
import { toHex } from 'viem'

// Calculate the deterministic ID for a string
const tsId = calculateAtomId(toHex('TypeScript'))
console.log('Atom ID for "TypeScript":', tsId)

// Same input always gives the same output
const tsId2 = calculateAtomId(toHex('TypeScript'))
console.log('Same input, same result:', tsId === tsId2) // true

// Different inputs give different IDs
const rustId = calculateAtomId(toHex('Rust'))
console.log('Atom ID for "Rust":', rustId)
console.log('Different:', tsId !== rustId) // true
```

This demonstrates the **deterministic addressing** you learned about in Lesson 02. The ID is a keccak256 hash of the atom data combined with a salt. Anyone, anywhere, computing the ID for "TypeScript" will get the same result.

## Step 5: Check If a Term Exists

You can check whether an atom or triple has been created on-chain. Create `check-term.ts`:

```typescript
import { multiVaultIsTermCreated, calculateAtomId } from '@0xintuition/protocol'
import { toHex } from 'viem'
import { readConfig } from './setup'

// Calculate what the term ID would be for "Ethereum"
const termId = calculateAtomId(toHex('Ethereum'))

// Check if it exists on-chain
const exists = await multiVaultIsTermCreated(readConfig, { args: [termId] })
console.log('Does "Ethereum" exist as an atom?', exists)
```

This combines offline ID calculation with an on-chain read — a common pattern you'll use throughout your Intuition work.

## Optional: Wallet Setup for Write Operations

If you want to create atoms, triples, and stake on the testnet, you'll need:

1. **A wallet private key** (for signing transactions)
2. **Testnet tTRUST tokens** (for paying creation costs)

### Generate or Use a Test Wallet

If you have an existing wallet, export its private key. If you need a fresh one for testing:

```typescript
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts'

const privateKey = generatePrivateKey()
const account = privateKeyToAccount(privateKey)
console.log('Address:', account.address)
console.log('Private key:', privateKey)
// Save this — you'll need it for testnet operations
```

### Get Testnet Tokens

Visit the Intuition testnet faucet at https://testnet.hub.intuition.systems/ to claim 0.1 $tTRUST daily for your wallet address.

### Add Write Config to setup.ts

```typescript
import {
  getMultiVaultAddressFromChainId,
  intuitionTestnet,
  type WriteConfig,
} from '@0xintuition/protocol'
import { createWalletClient } from 'viem'
import { privateKeyToAccount } from 'viem/accounts'

// Add to your existing setup.ts:
const account = privateKeyToAccount(process.env.PRIVATE_KEY as `0x${string}`)

export const walletClient = createWalletClient({
  account,
  chain: intuitionTestnet,
  transport: http(),
})

export const writeConfig: WriteConfig = {
  address: getMultiVaultAddressFromChainId(intuitionTestnet.id),
  publicClient,
  walletClient,
}
```

Then run scripts with:

```bash
PRIVATE_KEY=0xyour_key_here bun run script.ts
```

**Security note:** Never commit private keys to source control. Use environment variables or a `.env` file (add `.env` to `.gitignore`).

## Key Concepts

| Concept | What It Does |
|---------|-------------|
| `intuitionTestnet` | Chain config: RPC, chain ID, native token, explorer |
| `getMultiVaultAddressFromChainId` | Resolves the MultiVault address for a given chain ID |
| `publicClient` | Read-only connection to the blockchain |
| `walletClient` | Wallet-connected client for signing transactions |
| `ReadConfig` | `{ address, publicClient }` — for read operations |
| `WriteConfig` | `{ address, publicClient, walletClient }` — for write operations |
| `multiVaultGetAtomCost` | Reads the current cost to create an atom |
| `multiVaultGetTripleCost` | Reads the current cost to create a triple |
| `calculateAtomId` | Computes a deterministic atom ID (offline) |
| `multiVaultIsTermCreated` | Checks if an atom or triple exists on-chain |

## Quick Reference

```
Project setup:      bun init -y && bun add @0xintuition/protocol viem
Package:            @0xintuition/protocol
Chain:              intuitionTestnet (chain ID 13579)
Address helper:     getMultiVaultAddressFromChainId(chainId)
Read config:        { address, publicClient }
Write config:       { address, publicClient, walletClient }
Native token:       tTRUST (testnet) / TRUST (mainnet)
Explorer:           https://testnet.explorer.intuition.systems
```

## Try It

1. **Set up your project**: Create a new Bun project, install the protocol package, and verify you can connect to Intuition testnet. Print the chain name, chain ID, MultiVault address, and RPC URL.

2. **Read protocol costs**: Use `multiVaultGetAtomCost` and `multiVaultGetTripleCost` to read the current creation costs. Format them with `formatEther` to see human-readable values.

3. **Calculate atom IDs**: Pick three concepts that matter to you (a language, a tool, a person) and calculate their atom IDs using `calculateAtomId`. Notice they're deterministic — run it twice and verify the same inputs give the same outputs.

4. **Check term existence**: Calculate the atom ID for something that probably exists on-chain (like "Ethereum") and use `multiVaultIsTermCreated` to check. Then try something obscure — does it exist?

### Go Further (Testnet)

5. **Set up a wallet**: Generate or use an existing wallet, get testnet tokens, and create a `writeConfig`. Verify your setup by reading your wallet's tTRUST balance using `publicClient.getBalance({ address: account.address })`.

---

You've got a working protocol setup. In the next lesson, you'll use it to create atoms — turning concepts into on-chain identifiers.

Type `/learn next` for Lesson 06: Creating Atoms, or `/learn` for the dashboard.
