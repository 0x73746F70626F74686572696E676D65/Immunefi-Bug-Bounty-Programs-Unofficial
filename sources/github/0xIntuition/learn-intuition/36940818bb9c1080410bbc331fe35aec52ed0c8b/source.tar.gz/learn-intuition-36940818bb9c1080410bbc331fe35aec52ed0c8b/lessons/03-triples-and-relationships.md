═══════════════════════════════════════════════════════════════
LESSON 03: Triples & Relationships
═══════════════════════════════════════════════════════════════

## Words are useless without sentences.

A dictionary full of words and no grammar produces nothing. You need a way to combine words into statements — claims about the world that carry meaning.

That's what triples do. If atoms are the words, **triples are the sentences.** They connect atoms into structured claims that form the edges of the knowledge graph.

## What Are Triples?

A triple is a statement that connects exactly three atoms in a specific structure:

```
[Subject] — [Predicate] — [Object]
```

- **Subject**: The thing being described (an atom)
- **Predicate**: The relationship or attribute (also an atom)
- **Object**: The value or target (also an atom)

Every component is an atom ID. The triple itself is also given an ID and can be referenced just like an atom.

### Examples

```
[Alice]       — [knows]        — [TypeScript]
[Ethereum]    — [created by]   — [Vitalik]
[Contract X]  — [is safe]      — [true]
[Bob]         — [works at]     — [Uniswap]
[React]       — [is a]         — [JavaScript Framework]
```

Each of these is a claim. Notice that:
- The same atom (`Alice`) can appear in many triples as subject, predicate, or object
- Predicates like `knows`, `created by`, `is safe` are themselves atoms
- Every claim is structured and machine-readable

## Why This Structure?

### It's a Standard: RDF

The Subject-Predicate-Object format is the same structure used in **RDF (Resource Description Framework)** — a W3C standard for semantic web data. This isn't an arbitrary choice. It means:

- Intuition data is compatible with decades of semantic web tooling
- Graph databases, SPARQL queries, and linked data principles all apply
- Knowledge can flow between Intuition and other RDF-based systems

### It's Composable

Because every component is just an atom ID, and triples themselves get IDs, you can build complex structures from simple ones:

```
Triple 1: [Alice] — [has skill] — [TypeScript]
Triple 2: [Bob]   — [endorses]  — [Triple 1]
```

Triple 2 says: "Bob endorses the claim that Alice has skill TypeScript." This is a **nested triple** — a triple where one component is itself a triple.

This enables arbitrarily complex claims:
- Meta-claims (claims about claims)
- Endorsements and counter-claims
- Multi-layered attestations

### It's a Graph

Triples naturally form a **directed graph**:
- **Atoms are nodes**
- **Triples are directed edges** from subject → object, labeled by predicate

```
     knows          created by
Alice ────→ TypeScript    Ethereum ────→ Vitalik
  │                          │
  │ works at                 │ is a
  ↓                          ↓
Uniswap                 Blockchain
```

This graph structure enables powerful queries:
- "Find everything Alice knows" → follow all edges from Alice with predicate `knows`
- "Who created Ethereum?" → find triples with subject `Ethereum` and predicate `created by`
- "What does everyone say about Contract X?" → find all triples with subject `Contract X`

## Creating Triples

When you create a triple, the MultiVault contract:

1. Verifies all three atom IDs exist
2. Creates the triple record with a unique triple ID
3. Creates **two vaults** for the triple: FOR and AGAINST
4. Emits an event for the indexer

The two vaults are critical — they enable disagreement. For any claim like `[Contract X] [is safe] [true]`, people can stake in the FOR vault (affirming) or the AGAINST vault (disputing). We'll cover this in Lesson 04.

## The Knowledge Graph Emerges

As people create atoms and connect them with triples, a knowledge graph naturally emerges. No central planner designs it. No schema must be agreed upon in advance. The graph grows organically as participants contribute structured knowledge.

This is fundamentally different from traditional databases:
- **No fixed schema**: New predicates (relationship types) can be created as atoms at any time
- **No central authority**: Anyone can add atoms and triples
- **Self-curating**: Economic incentives drive convergence on quality
- **Machine-readable**: Every piece of data has a structured, queryable format

## Token-Curated Data Structures

Just as atoms compete to be canonical identifiers, triples compete to be canonical claims. The TCR mechanism works the same way:

- Multiple triples can express similar claims
- Community stakes on the ones they consider valid
- Higher TVL = stronger consensus
- Creators earn fees from well-used triples

This creates organic, incentive-driven structuring of knowledge — the community converges on useful data patterns through economic participation.

## Quick Reference

| Property | Detail |
|----------|--------|
| **Format** | [Subject Atom] — [Predicate Atom] — [Object Atom] |
| **Standard** | RDF-compatible semantic triples |
| **Components** | Three atom IDs |
| **Nesting** | Triples can be used as atoms in other triples |
| **Vaults** | Each triple gets two: FOR and AGAINST |
| **Graph** | Atoms = nodes, triples = directed edges |
| **Creation** | Permissionless — anyone can create triples from existing atoms |
| **Curation** | TCR — staking determines canonical claims |

## Try It

1. **Build a mini-graph**: Pick a topic you know well (a technology, a team, a project). Create 5 atoms and connect them with at least 4 triples. Draw it out — atoms as circles, triples as arrows. You've just designed a knowledge graph.

2. **Predicate design**: Predicates are the verbs of the knowledge graph. List 10 useful predicates for a professional network (e.g., `knows`, `works at`, `has skill`, `endorses`). Which ones would be most useful across many different subjects?

3. **Spot nested triples**: Can you think of a claim that requires nesting? For example, "Alice endorses the claim that Bob knows Solidity." Write it as nested triples. How many atoms and triples do you need?

4. **Explore the graph**: On the Portal (https://portal.intuition.systems), find a triple and trace its connections. Click on the subject atom — what other triples is it part of? You're traversing the knowledge graph.

5. **Counter-claims**: Think of a claim that reasonable people disagree about. Write it as a triple. Now think: how would the FOR and AGAINST vaults capture this disagreement? What does it mean if FOR has 10x more TVL than AGAINST?

When you're ready, type `/learn next` for Lesson 04: Signals & Conviction.
