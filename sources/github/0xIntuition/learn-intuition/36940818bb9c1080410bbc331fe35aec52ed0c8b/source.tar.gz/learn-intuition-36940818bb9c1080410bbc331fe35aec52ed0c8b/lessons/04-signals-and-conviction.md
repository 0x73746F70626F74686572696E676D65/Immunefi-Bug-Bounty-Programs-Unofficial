═══════════════════════════════════════════════════════════════
LESSON 04: Signals & Conviction
═══════════════════════════════════════════════════════════════

## Knowledge without conviction is just data.

You can fill a graph with atoms and triples all day. But how do you know which claims are trustworthy? Which identifiers are canonical? Which facts matter?

That's the job of **Signals** — the economic layer that turns a static knowledge graph into a living, weighted intelligence system.

## The Core Idea: Staking as Speech

In Intuition, you express conviction by putting tokens where your mouth is. When you **stake** tokens on an atom or triple, you're making an economic statement:

- Staking on an atom: *"I believe this identifier is relevant and important."*
- Staking FOR a triple: *"I believe this claim is true."*
- Staking AGAINST a triple: *"I believe this claim is false."*

This isn't just a vote. It's an **economic commitment**. You're risking real value to back your belief. And the system rewards you if you're right (if others agree and stake alongside you).

## How Staking Works

### Vaults

Every atom and triple has associated **vaults** — smart contracts that hold staked tokens.

| Primitive | Vaults | What Staking Means |
|-----------|--------|-------------------|
| **Atom** | 1 vault | "This identifier is relevant" |
| **Triple** | 2 vaults (FOR + AGAINST) | FOR: "This claim is true" / AGAINST: "This claim is false" |

When you deposit tokens into a vault, you receive **vault shares** — tokens representing your proportional ownership of that vault.

### The Deposit Flow

```
You deposit 10 TRUST
    → Bonding curve calculates share price
    → You receive X vault shares
    → Your shares represent ownership of the vault
    → Vault's TVL increases by ~10 TRUST (minus entry fees)
```

### The Redemption Flow

```
You burn X vault shares
    → Bonding curve calculates token value
    → You receive Y TRUST back (minus exit fees)
    → Vault's TVL decreases
```

## Bonding Curves: Early Bird Economics

This is where it gets interesting. Vault share prices follow a **bonding curve**:

```
share price = k × total_supply^n    (simplified model)
```

This is a simplified representation — the protocol supports multiple curve types (Linear, OffsetProgressive) via a BondingCurveRegistry. The key insight is the same across all of them: **the more people stake, the higher the price goes.**

### What This Means

| Scenario | Share Price | What Happens |
|----------|-----------|-------------|
| You're first to stake on an atom | Very low | You get many shares for your tokens |
| You stake after 10 others | Higher | You get fewer shares per token |
| You stake after 1000 others | Much higher | Premium price for popular content |

### Why This Matters

1. **Early discovery is rewarded**: If you identify an important atom or truthful triple before others do, you get shares at a discount. When more people stake later (pushing up the price), your shares are worth more.

2. **Perpetual prediction markets**: Every atom and triple becomes a mini market for information relevance and truth. The price signal tells you what the community thinks.

3. **Skin in the game**: Because staking has real cost, signals are meaningful. It's not a free like-button — it's a backed conviction.

### Example: Staking on an Atom

Let's trace through a scenario:

1. **Alice stakes 10 TRUST** on atom `[TypeScript]` (first staker)
   - Share price: ~0.1 TRUST/share
   - Alice gets: ~100 shares
   - Vault TVL: ~10 TRUST

2. **Bob stakes 10 TRUST** on the same atom
   - Share price: ~0.2 TRUST/share (doubled because of Alice's stake)
   - Bob gets: ~50 shares
   - Vault TVL: ~20 TRUST

3. **Charlie stakes 10 TRUST**
   - Share price: ~0.3 TRUST/share
   - Charlie gets: ~33 shares
   - Vault TVL: ~30 TRUST

Now Alice's 100 shares are worth ~16.4 TRUST (up from her 10 TRUST investment). She was rewarded for staking early on something the community values.

## Triple Signals: FOR vs AGAINST

For triples, the two-vault system creates a fascinating dynamic:

```
Triple: [Contract X] — [is safe] — [true]

FOR Vault:  15,000 TRUST staked (87 stakers)
AGAINST:     2,500 TRUST staked (12 stakers)
```

This tells you:
- The community mostly agrees Contract X is safe
- There's meaningful disagreement (not unanimous)
- 87 people have backed their belief with real tokens
- The FOR/AGAINST ratio (6:1) quantifies consensus strength

### Reading the Signal

| FOR vs AGAINST | Interpretation |
|---------------|---------------|
| FOR >> AGAINST | Strong consensus: claim is widely accepted |
| FOR ≈ AGAINST | Contested: genuine disagreement |
| AGAINST >> FOR | Strong disagreement: claim is widely disputed |
| Both low TVL | Low attention: claim hasn't attracted conviction yet |

## Types of Signal

### Explicit Signal
Direct, intentional staking. This is the primary signal type in Intuition:
- Depositing tokens into vaults
- Taking FOR/AGAINST positions on triples
- These are on-chain, verifiable, and economic

### Implicit Signal
Indirect indicators that emerge from usage:
- How often an atom is referenced in triples
- Query frequency on the API
- Inclusion in applications

### Transitive Signal
Trust that flows through the graph:
- If you trust Alice, and Alice endorses Bob, you extend some trust to Bob
- This creates a web of trust that can be computed from the graph structure

## Fee Economics

Every staking operation involves fees that incentivize the ecosystem:

| Fee | Who Pays | Who Benefits | Purpose |
|-----|---------|-------------|---------|
| **Entry fee** | Depositor | Protocol + existing stakers | Cost of joining |
| **Exit fee** | Redeemer | Protocol + remaining stakers | Prevents gaming |
| **Protocol fee** | Various | Protocol treasury | Sustainability |
| **Creator fee** | Interactors | Atom/triple creator | Rewards quality creation |

**Creator fees** are the key incentive loop: if you create a high-quality atom that many people stake on, you earn ongoing fees. This directly incentivizes contributing useful knowledge to the graph.

## TVL: The Trust Metric

**Total Value Locked (TVL)** is the bottom line:

- Atom TVL = total tokens staked on that atom = community confidence in that identifier
- Triple FOR TVL = total tokens affirming the claim
- Triple AGAINST TVL = total tokens disputing the claim

TVL is what makes the Token-Curated Graph work. It's the mechanism through which the community collectively curates canonical identifiers and validates claims.

## Quick Reference

| Concept | Detail |
|---------|--------|
| **Staking** | Deposit tokens → receive vault shares |
| **Redemption** | Burn shares → receive tokens (minus fees) |
| **Atom vaults** | 1 per atom (signal relevance) |
| **Triple vaults** | 2 per triple (FOR + AGAINST) |
| **Bonding curve** | Share price increases with supply |
| **TVL** | Total Value Locked — primary conviction metric |
| **Early staker advantage** | Lower share price = more shares per token |
| **Creator fees** | Ongoing rewards for atom/triple creators |

## Try It

1. **Think like an early staker**: Browse the Portal (https://portal.intuition.systems) and find an atom with relatively low TVL that you think is important. If you could stake on it, would you? What's your thesis for why it will attract more stakers?

2. **Read a contested triple**: Find a triple on the Portal where both FOR and AGAINST have meaningful TVL. What's the claim? What's the FOR/AGAINST ratio? What does that tell you about community consensus?

3. **Design a staking scenario**: Imagine you have 100 TRUST to allocate across 5 atoms and 3 triples. How would you distribute it? What's your strategy — spread thin for diversification, or concentrate on your highest-conviction beliefs?

4. **Creator incentives**: If you wanted to create an atom that would earn the most creator fees over time, what would you create? What makes an atom "high quality" enough that many people would stake on it?

5. **The big picture**: You now know all three primitives. Describe in your own words how atoms, triples, and signals work together to create a self-curating knowledge graph. What role does each play?

---

**Congratulations!** You've completed Part 1: Understanding the Knowledge Graph. You now understand the three primitives that make Intuition work: Atoms (identifiers), Triples (relationships), and Signals (conviction).

Part 2 will take you from understanding to building — you'll write code that creates atoms, builds triples, queries the graph, and reads conviction data using the Intuition protocol package.

Type `/learn progress` to see your stats, or `/learn next` for Lesson 05: Setting Up the Protocol.
