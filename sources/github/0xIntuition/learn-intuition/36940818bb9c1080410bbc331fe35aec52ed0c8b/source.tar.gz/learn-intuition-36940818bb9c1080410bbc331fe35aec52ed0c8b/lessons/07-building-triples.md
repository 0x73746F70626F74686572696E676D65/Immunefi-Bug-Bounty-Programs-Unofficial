===============================================================
LESSON 07: Building Triples
===============================================================

## Atoms are words. Triples are sentences.

You can fill a database with identifiers, but they don't mean anything until you connect them. Triples are how you express relationships in the knowledge graph — and they're where things get interesting.

In Lesson 03 you designed triples on paper: `[Alice] — [knows] — [TypeScript]`. Now you'll build them in code.

## The Structure, in Code

A triple connects three atoms by their term IDs:

```
[Subject Term ID] — [Predicate Term ID] — [Object Term ID]
```

Every component is an atom. The predicate is an atom too — "knows", "is", "has tag" are all atoms in the graph, just like "TypeScript" or "Alice."

This means creating a triple is a four-step process:

```
1. Ensure the subject atom exists
2. Ensure the predicate atom exists
3. Ensure the object atom exists
4. Create the triple connecting them
```

(Or if you're planning ahead, batch-create all the atoms first, then create the triples.)

## Calculating Triple IDs (Offline)

Just like atoms, triples have deterministic IDs you can compute locally:

```typescript
import { calculateAtomId, calculateTripleId } from '@0xintuition/protocol'
import { toHex } from 'viem'

// First, calculate the atom IDs
const subjectId = calculateAtomId(toHex('Alice'))
const predicateId = calculateAtomId(toHex('knows'))
const objectId = calculateAtomId(toHex('TypeScript'))

// Then calculate the triple ID
const tripleId = calculateTripleId(subjectId, predicateId, objectId)
console.log('Triple [Alice]-[knows]-[TypeScript]:', tripleId)
```

The triple ID is computed from a `TRIPLE_SALT` combined with the three atom IDs, then hashed with keccak256. Same inputs, same output, always.

### Designing on Paper, Verifying in Code

Here's a powerful workflow: design your knowledge graph on paper, then calculate all the IDs before touching the blockchain:

```typescript
import { calculateAtomId, calculateTripleId } from '@0xintuition/protocol'
import { toHex } from 'viem'

// Your knowledge graph design
const statements = [
  ['Alice', 'knows', 'TypeScript'],
  ['Alice', 'knows', 'Rust'],
  ['TypeScript', 'is', 'Programming Language'],
  ['Rust', 'is', 'Programming Language'],
]

for (const [s, p, o] of statements) {
  const sId = calculateAtomId(toHex(s))
  const pId = calculateAtomId(toHex(p))
  const oId = calculateAtomId(toHex(o))
  const tId = calculateTripleId(sId, pId, oId)

  console.log(`[${s}]-[${p}]-[${o}]`)
  console.log(`  Triple ID: ${tId.slice(0, 18)}...`)
}
```

## Counter-Triples: The AGAINST Side

Every triple has two sides — a concept unique to Intuition. From Lesson 04, you know triples have two vaults: FOR and AGAINST.

The **counter-triple** represents the AGAINST position. It has its own ID, derived from the original triple ID:

```typescript
import { calculateCounterTripleId } from '@0xintuition/protocol'

const tripleId = calculateTripleId(subjectId, predicateId, objectId)
const counterTripleId = calculateCounterTripleId(tripleId)

console.log('FOR vault uses:', tripleId)
console.log('AGAINST vault uses:', counterTripleId)
```

When someone stakes FOR the triple `[Contract X]-[is safe]-[true]`, they deposit into the vault keyed by `tripleId`. When someone stakes AGAINST, they deposit into the vault keyed by `counterTripleId`.

You can also look up the inverse triple on-chain:

```typescript
import { multiVaultGetInverseTripleId, multiVaultIsCounterTriple } from '@0xintuition/protocol'

// Get the inverse (AGAINST) triple ID from the contract
const inverseId = await multiVaultGetInverseTripleId(readConfig, { args: [tripleId] })

// Check if a given term ID is a counter-triple
const isCounter = await multiVaultIsCounterTriple(readConfig, { args: [someTermId] })
```

## Common Predicates

The Intuition ecosystem uses some standard predicates. These are just atoms — but they've become conventions:

| Predicate | Meaning | Example |
|-----------|---------|---------|
| `is` | Categorical classification | `[TypeScript]-[is]-[Programming Language]` |
| `has tag` | Tagging / labeling | `[My Project]-[has tag]-[open source]` |
| `contains` | Membership / composition | `[Intuition]-[contains]-[MultiVault]` |
| `related` | General association | `[Ethereum]-[related]-[Solidity]` |
| `url` | Linking to a URL | `[My Project]-[url]-[https://...]` |
| `linked account` | Connecting identities | `[Alice]-[linked account]-[0xAbc...]` |

You can create any predicate you want — these are just the common ones. The "has tag" predicate is especially important — it's used by the Portal for **curated lists**.

## Creating Triples On-Chain

Creating a triple follows the same four-step write flow as atoms:

```
1. Get cost       → multiVaultGetTripleCost(readConfig)
2. Prepare IDs    → term IDs for subject, predicate, object
3. Submit tx      → multiVaultCreateTriples(writeConfig, { args, value })
4. Parse events   → eventParseTripleCreated(publicClient, txHash)
```

### Step by Step

```typescript
import {
  multiVaultCreateTriples,
  multiVaultGetTripleCost,
  eventParseTripleCreated,
} from '@0xintuition/protocol'
import { publicClient, readConfig, writeConfig } from './setup'

// 1. Get the triple creation cost
const tripleCost = await multiVaultGetTripleCost(readConfig)

// 2. You need the term IDs of atoms that already exist on-chain
//    (These are the Hex term IDs from when the atoms were created)
const subjectTermId = '0x...'  // Alice's term ID
const predicateTermId = '0x...' // "knows" term ID
const objectTermId = '0x...'   // TypeScript's term ID

// 3. Submit the transaction
const txHash = await multiVaultCreateTriples(writeConfig, {
  args: [
    [subjectTermId],    // subject term IDs
    [predicateTermId],  // predicate term IDs
    [objectTermId],     // object term IDs
    [tripleCost],       // deposit per triple
  ],
  value: tripleCost,
})

// 4. Parse the TripleCreated event
const [event] = await eventParseTripleCreated(publicClient, txHash)

console.log('Triple created!')
console.log('  TX Hash:', txHash)
console.log('  Term ID:', event.args.termId)
console.log('  Subject:', event.args.subjectId)
console.log('  Predicate:', event.args.predicateId)
console.log('  Object:', event.args.objectId)
```

### The args Format

The `args` array uses parallel arrays for batch compatibility:

```typescript
args: [
  [subjectId1, subjectId2, ...],   // subjects
  [predicateId1, predicateId2, ...], // predicates
  [objectId1, objectId2, ...],      // objects
  [deposit1, deposit2, ...],        // deposits
]
```

Even for a single triple, each component is wrapped in an array.

## Batch Triple Creation

Create multiple triples in one transaction — same function, just bigger arrays:

```typescript
const tripleCost = await multiVaultGetTripleCost(readConfig)

// Create two triples:
// [Alice]-[knows]-[TypeScript]
// [Alice]-[knows]-[Rust]
const txHash = await multiVaultCreateTriples(writeConfig, {
  args: [
    [aliceId, aliceId],         // subjects
    [knowsId, knowsId],         // predicates
    [tsId, rustId],             // objects
    [tripleCost, tripleCost],   // deposits
  ],
  value: tripleCost * 2n,       // total value for all triples
})

const events = await eventParseTripleCreated(publicClient, txHash)
console.log(`Created ${events.length} triples in one transaction`)
```

## The Triple Creation Flow

When you create a triple on-chain:

```
1. Protocol sends a transaction to MultiVault.createTriples()
   - Passes: subjects[], predicates[], objects[], deposits[]
   - Sends: total cost as msg.value
2. MultiVault:
   a. Verifies all referenced atoms exist
   b. Computes the deterministic triple ID
   c. Checks for duplicates (same S-P-O = same triple)
   d. Creates FOR vault (keyed by tripleId)
   e. Creates AGAINST vault (keyed by counterTripleId)
   f. Emits a TripleCreated event
3. Event parser extracts the structured result
```

The cost covers: protocol fee + atom deposit fractions + your deposit.

## Verifying Triples On-Chain

After creating a triple, you can read its data back from the contract:

```typescript
import {
  multiVaultGetTriple,
  multiVaultIsTriple,
  multiVaultGetVault,
} from '@0xintuition/protocol'

// Read a triple's components
const [subjectId, predicateId, objectId] = await multiVaultGetTriple(readConfig, {
  args: [tripleTermId],
})
console.log('Subject:', subjectId, 'Predicate:', predicateId, 'Object:', objectId)

// Check if a term ID is a triple
const isTriple = await multiVaultIsTriple(readConfig, { args: [tripleTermId] })
console.log('Is triple:', isTriple)

// Read the FOR vault state
const curveId = 1n
const [forShares, forAssets] = await multiVaultGetVault(readConfig, {
  args: [tripleTermId, curveId],
})
console.log('FOR vault:', { shares: forShares, assets: forAssets })

// Read the AGAINST vault state
const counterTripleId = calculateCounterTripleId(tripleTermId)
const [againstShares, againstAssets] = await multiVaultGetVault(readConfig, {
  args: [counterTripleId, curveId],
})
console.log('AGAINST vault:', { shares: againstShares, assets: againstAssets })
```

You can also view triples on the Portal: `https://portal.intuition.systems`

## Key Concepts

| Concept | Detail |
|---------|--------|
| `calculateTripleId(s, p, o)` | Deterministic triple ID from three atom term IDs (Hex) |
| `calculateCounterTripleId(tripleId)` | The AGAINST vault ID for a triple |
| `multiVaultGetTripleCost(readConfig)` | Current cost to create a triple |
| `multiVaultCreateTriples(writeConfig, { args, value })` | Create one or more triples on-chain |
| `eventParseTripleCreated(publicClient, txHash)` | Parse TripleCreated events from a transaction |
| `multiVaultGetTriple(readConfig, { args })` | Read a triple's subject, predicate, object |
| `multiVaultIsTriple(readConfig, { args })` | Check if a term ID is a triple |
| `multiVaultGetInverseTripleId(readConfig, { args })` | Get the AGAINST triple ID on-chain |
| `multiVaultGetVault(readConfig, { args })` | Read vault state (shares, assets) |

## Quick Reference

```
Calculate ID:       calculateTripleId(subjectId, predicateId, objectId)
Counter ID:         calculateCounterTripleId(tripleId)
Get cost:           multiVaultGetTripleCost(readConfig)
Create:             multiVaultCreateTriples(writeConfig, { args: [subjects, predicates, objects, deposits], value })
Parse events:       eventParseTripleCreated(publicClient, txHash)
Read triple:        multiVaultGetTriple(readConfig, { args: [tripleId] })
Check if triple:    multiVaultIsTriple(readConfig, { args: [termId] })
Inverse ID:         multiVaultGetInverseTripleId(readConfig, { args: [tripleId] })
Vault state:        multiVaultGetVault(readConfig, { args: [termId, curveId] })
```

## Try It

1. **Design a mini knowledge graph**: Pick a domain (your skills, a project, a team) and write out 5+ triples on paper in `[S]-[P]-[O]` format. Think carefully about which predicates to use.

2. **Calculate all the IDs**: For each unique atom in your graph, calculate its atom ID. Then calculate the triple ID for each triple. Store everything in a data structure:

```typescript
const graph = {
  atoms: { 'Alice': atomId1, 'knows': atomId2, ... },
  triples: [
    { s: 'Alice', p: 'knows', o: 'TypeScript', id: tripleId1 },
    ...
  ]
}
```

3. **Calculate counter-triple IDs**: For each triple, also calculate the counter-triple ID. In what scenario would someone stake AGAINST each of your triples?

4. **Check existence**: Use `multiVaultIsTermCreated` to check which of your atoms exist on-chain. Use `multiVaultIsTriple` to check if any of your designed triples already exist.

### Go Further (Testnet)

5. **Create a triple**: Pick one of your designed triples, ensure the atoms exist (create them if needed from Lesson 06), then create the triple using `multiVaultCreateTriples`. Parse the event and inspect all the fields.

6. **Read it back**: After creating a triple, use `multiVaultGetTriple` to read its components back from the contract. Then read the FOR and AGAINST vault state with `multiVaultGetVault`.

7. **Batch create**: Create 3+ triples in a single transaction. Compare gas cost and confirmation time to creating them individually.

---

You can now create both atoms and triples — the nodes and edges of the knowledge graph. In the next lesson, you'll learn to query the graph and explore what others have built.

Type `/learn next` for Lesson 08: Querying the Graph, or `/learn` for the dashboard.
