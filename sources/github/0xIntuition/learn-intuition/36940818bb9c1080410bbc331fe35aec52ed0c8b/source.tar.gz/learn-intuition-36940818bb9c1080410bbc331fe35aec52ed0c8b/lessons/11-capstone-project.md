===============================================================
LESSON 11: Capstone Project
===============================================================

## Time to build something real.

You've learned the protocol (Part 1), written working code (Part 2), and understand the tooling ecosystem (Part 3). Now you'll combine everything by building a real Intuition application.

This isn't an exercise — it's a project. You'll scaffold an app from a template, integrate with the protocol, and deploy to testnet. When you're done, you'll have something you built that talks to the real knowledge graph.

## Choose Your Path

Pick the tier that matches your comfort level:

### Tier 1: Basic — Atom Explorer (Single Page App)

**What you'll build:** A single-page Vite + React app that creates atoms and reads from the knowledge graph.

**What it covers:**
- Wagmi for wallet connection
- The simulate → execute → parse events pattern
- Atom creation (string atoms)
- Reading atom data from the protocol
- Depositing into atom vaults

**Scope:** ~15 files, 7 runtime dependencies. One page, one flow. You'll understand how a frontend talks to the MultiVault contract.

**Best for:** Learners who want to see the protocol come alive in a UI. If you're comfortable with React basics and want a focused, achievable project.

### Tier 2: Advanced — Curated Lists (Multi-Page App)

**What you'll build:** A multi-page React Router 7 app with authentication, triple creation, signal display, and GraphQL reads.

**What it covers:**
- Everything in Tier 1, plus:
- SIWE (Sign-In with Ethereum) authentication
- Triple creation and display
- FOR/AGAINST signal visualization
- GraphQL as the read layer
- Curated list patterns from the knowledge graph

**Scope:** ~25-30 files, ~14 runtime dependencies. Multiple pages, richer interactions. You'll understand how to build a full Intuition-integrated application.

**Best for:** Learners who finished Tier 1 or have React Router / fullstack experience. This is closer to what a production Intuition app looks like.

## Before You Build

The capstone is a real project — you'll need a working environment. Make sure you have:

| Prerequisite | Check | Where to Get It |
|-------------|-------|-----------------|
| Bun | `bun --version` | `curl -fsSL https://bun.sh/install \| bash` |
| A wallet (MetaMask, etc.) | — | https://metamask.io |
| Testnet tokens ($tTRUST) | Check wallet balance | https://testnet.hub.intuition.systems/ |

If you're missing anything, set it up now — the build steps below assume everything is ready.

## The Build Process

Regardless of tier, you'll follow this workflow:

### Step 1: Scaffold the Project

Use the Intuition template for your chosen tier. The templates come pre-configured with:
- Chain configuration (testnet by default)
- MultiVault contract integration via `@0xintuition/protocol`
- Basic UI structure

```bash
# Tier 1
bunx degit 0xintuition/intuition-basic-template my-intuition-app

# Tier 2
bunx degit 0xintuition/intuition-advanced-template my-intuition-app
```

### Step 2: Set Up Your Environment

1. Install dependencies: `bun install`
2. Get testnet tokens from the faucet: https://testnet.hub.intuition.systems/
3. Configure your wallet (the template README has specific steps)
4. Run the dev server: `bun dev`

### Step 3: Explore What's There

Before you change anything, understand the template:
- Read the README — it explains the architecture
- Look at the chain configuration — notice `getMultiVaultAddressFromChainId` and `intuitionTestnet`
- Find the protocol integration file (`lib/protocol.ts`) — this is where all MultiVault interactions live
- Trace the write flow: user action → get cost → submit tx → parse events → UI update

### Step 4: Build Your Feature

This is where you make it yours. Ideas:

**Tier 1 extensions:**
- Add a search interface using GraphQL atom search
- Display atom vault TVL alongside atom data
- Add batch atom creation
- Show atom creation history

**Tier 2 extensions:**
- Build a custom curated list for a topic you care about
- Add a "conviction leaderboard" showing highest-TVL atoms
- Implement a triple explorer with FOR/AGAINST visualization
- Create an attestation workflow (create atoms → connect with triples → stake)

### Step 5: Use Your Tools

This is the capstone — use everything you learned:

- **Protocol knowledge (Part 1):** You understand atoms, triples, and signals. Your UI should reflect that understanding — label things correctly, show conviction data meaningfully.

- **Protocol skills (Part 2):** You know the write flow (`multiVaultCreateAtoms`, `multiVaultCreateTriples`, event parsers) and read patterns (`multiVaultGet*`, GraphQL). Use them in your app's data layer.

- **Ecosystem navigation (Lesson 09):** When you hit a question the template doesn't answer, check the docs. Browse the tutorials for patterns you can adapt.

- **Context engineering (Lesson 10):** Write a context file for your project. Include chain details, protocol patterns, and conventions. Watch how much better AI helps you when it has the right context.

## What You're Demonstrating

Your capstone shows you can:

| Capability | Where You Learned It | How It Shows Up |
|-----------|---------------------|-----------------|
| Protocol concepts | Part 1 (Lessons 01-04) | Correct use of atoms, triples, signals in UI |
| Protocol integration | Part 2 (Lessons 05-08) | Working code that reads and writes to the graph |
| Ecosystem navigation | Lesson 09 | You found answers to template questions independently |
| Context engineering | Lesson 10 | Your project has a context file with protocol patterns |
| End-to-end building | This lesson | A working app on testnet |

## Reflection: What You Built

When your app works, take a step back:

1. **What atoms did you create?** They're on-chain now — permanent entries in the knowledge graph.

2. **What triples connect them?** You contributed structured claims to a shared, global data layer.

3. **What did the AI help with?** Context engineering meant you weren't working alone. The AI had the right protocol context because you engineered it.

4. **What would you build next?** The knowledge graph is open. Anyone can create atoms, build triples, stake on claims. What corner of the graph would you want to grow?

## Going Further

Your capstone is a starting point, not an endpoint:

- **Mainnet**: Switch from testnet to mainnet (chain ID 1155, different MultiVault address). Real $TRUST, real stakes.
- **Contribute to the graph**: Create atoms for a domain you care about. Build the canonical identifiers. Be the early staker.
- **Explore the ecosystem**: Check out the tutorials in the docs (reputation systems, fraud detection, prediction markets). Each one is a building pattern you can adopt.
- **Build with AI**: Use the patterns from Lesson 10 to set up any new Intuition project for effective AI-assisted development.

---

**Congratulations.** You started this course wondering what a decentralized knowledge graph is. Now you can build on one.

You understand the primitives (atoms, triples, signals), you can write code that creates and queries them, you know how to navigate the ecosystem and give AI the context it needs, and you've built a working application.

The knowledge graph grows one atom at a time. Go add yours.

Type `/learn progress` to see your final stats, or `/learn` for the dashboard.
