═══════════════════════════════════════════════════════════════
LESSON 02: Atoms & Identifiers
═══════════════════════════════════════════════════════════════

## What if every concept had a permanent address?

Your home has an address. Websites have URLs. But what about "TypeScript"? Or "trust"? Or you?

In the physical world, we reference things by name — but names are ambiguous. There are thousands of people named "Alice." There are multiple things called "React." When you say "Python," do you mean the programming language or the snake?

Atoms solve this. **Every atom is a unique, permanent, deterministic identifier** for a concept, entity, or piece of data. Once created, it exists forever on-chain, and anyone can reference it.

## What Are Atoms?

Atoms are the foundational building blocks of Intuition's knowledge graph — the words in the global dictionary. Each atom represents one thing and one thing only.

An atom can represent:
- **People**: `Alice`, `Vitalik`, a specific wallet address
- **Organizations**: `Ethereum Foundation`, `Uniswap`, a DAO
- **Concepts**: `TypeScript`, `trust`, `decentralization`
- **Documents**: An IPFS hash, a research paper, a smart contract
- **Anything else**: Dates, categories, URLs, skills

The key insight: atoms don't store the *thing itself* — they store a **unique reference** to it. Like how a URL doesn't contain a webpage, but points to one.

## How Atoms Work

### The Three Components

Every atom has three parts:

| Component | What It Is | Example |
|-----------|-----------|---------|
| **Atom ID** | Unique numeric identifier, derived from the data | `42` |
| **Atom Data** | The actual content (URI, text, JSON, IPFS hash) | `"TypeScript"` or `ipfs://Qm...` |
| **Atom Wallet** | A smart contract wallet the atom owns | `0x7f3a...` |

Plus a **vault** for staking (we'll cover that in Lesson 04).

### Deterministic IDs

This is the clever part. An atom's ID is **deterministically derived** from its data by hashing:

```
atomData = "TypeScript"
atomId = hash(atomData) → 4827
```

This means:
- **No duplicates**: If someone already created an atom for "TypeScript," you can't create another one. Same data = same hash = same ID.
- **Verifiable**: Anyone can independently confirm that atom 4827 represents "TypeScript" by hashing the data themselves.
- **Discoverable**: If you know the data, you can find the atom. No need to search.

### Under the Hood: ERC-1155

Atoms are minted as **ERC-1155 tokens** on the MultiVault contract. ERC-1155 is a multi-token standard that lets one contract manage many different token types. Each atom is a unique token type within the MultiVault.

This means atoms are real on-chain assets with all the properties of tokens — they can be tracked, verified, and referenced by any smart contract or application.

## Atom Data: What Goes Inside?

Atom data can be anything, but common patterns include:

| Pattern | Example | When to Use |
|---------|---------|-------------|
| Simple text | `"TypeScript"` | Concepts, categories, predicates |
| URI | `https://example.com/profile` | Linking to external resources |
| IPFS hash | `ipfs://QmXnnyuf...` | Immutable content references |
| JSON | `{"name": "Alice", "type": "person"}` | Structured metadata |
| DID | `did:ethr:0x3b0bc5...` | Decentralized identity |

The data can be stored off-chain (IPFS, Arweave) with the atom containing a pointer, or it can be simple on-chain text. The protocol doesn't enforce a specific format — it's flexible by design.

## Atom Wallets: Atoms Have Agency

Here's something unique: **every atom has its own smart contract wallet.** This means an atom can:
- Own other tokens and assets
- Interact with smart contracts
- Accumulate fees from interactions

The wallet is controlled by the **Atom Warden** — a specialized contract that manages atom wallet operations. This gives atoms a form of agency: the atom for "Ethereum Foundation" could theoretically hold assets, receive payments, or participate in governance.

## The Token-Curated Registry

Since anyone can create atoms permissionlessly, multiple atoms might represent the same concept. How does the system converge on a canonical one?

**Through economics.** The atom with the most staking activity (highest TVL) becomes the de facto standard. This is a Token-Curated Registry (TCR):

1. Alice creates atom A for "TypeScript" with good metadata
2. Bob creates atom B for "TypeScript" with minimal data
3. Community stakes on atom A because it's better structured
4. Atom A accumulates higher TVL → becomes canonical
5. Alice earns creator fees from the staking activity

No committee decides. The market decides. And everyone is incentivized to converge on the best identifiers.

## Quick Reference

| Property | Detail |
|----------|--------|
| **Standard** | ERC-1155 multi-token |
| **ID generation** | Deterministic hash of atomData |
| **Data types** | Text, URI, JSON, IPFS, DID, anything |
| **Uniqueness** | Enforced — same data cannot produce two atoms |
| **Wallet** | Each atom has its own smart contract wallet |
| **Vault** | Each atom has a staking vault (covered in Lesson 04) |
| **Creation** | Permissionless — anyone can create atoms |
| **Curation** | Token-Curated Registry — community stakes on canonical identifiers |

## Try It

1. **Design three atoms**: Think of three things you'd want to create atoms for — one person, one concept, and one organization. What atomData would each contain? Would you use simple text, a URI, or JSON?

2. **Spot the duplicate problem**: Go to the Portal (https://portal.intuition.systems) and search for a common concept like "Ethereum" or "Bitcoin." Are there multiple atoms? Which one has the highest TVL? That's the TCR in action.

3. **Think about atom data**: If you were creating the canonical atom for yourself, what data would you include? A name? A DID? A link to your profile? Think about what makes an atom useful for others to reference.

4. **Atom as building block**: Write down three claims about the world (as sentences). Now identify every atom you'd need to express those claims. How many atoms overlap between the three claims? This is the composability in action — atoms get reused across triples.

When you're ready, type `/learn next` for Lesson 03: Triples & Relationships.
