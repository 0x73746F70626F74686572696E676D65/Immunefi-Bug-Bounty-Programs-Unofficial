===============================================================
LESSON 06: Creating Atoms
===============================================================

## Every node in the knowledge graph starts as an atom.

In Lesson 02, you learned that atoms are unique identifiers for anything — a person, a concept, a contract. Now you'll create them with code.

Here's the twist: you can do a surprising amount *without writing to the blockchain*. Calculating atom IDs, verifying determinism, understanding data encoding — all of this works locally. Creating on-chain is the final step.

## Two Layers of Working with Atoms

| Layer | What You Do | Network Needed? | Cost? |
|-------|------------|-----------------|-------|
| **Calculate** | Compute deterministic atom IDs from data | No | Free |
| **Create** | Write atoms to the blockchain | Yes | Atom cost + deposit |

This lesson covers both. All exercises in "Try It" work at the calculate layer. The "Go Further" section takes you on-chain.

## Calculating Atom IDs

Remember from Lesson 02: atom IDs are deterministic. The same data always produces the same ID, anywhere in the world.

```typescript
import { calculateAtomId } from '@0xintuition/protocol'
import { toHex } from 'viem'

// The atom ID for "TypeScript" — always the same
const id = calculateAtomId(toHex('TypeScript'))
```

Under the hood, `calculateAtomId` does:

```
1. Takes your data as hex bytes
2. Hashes it with keccak256
3. Combines with ATOM_SALT (a fixed constant)
4. Hashes again with keccak256
5. Returns the final hash as the atom ID
```

This means:
- **No duplicates**: Two people creating "TypeScript" get the same atom
- **Predictable**: You can know an atom's ID before it exists on-chain
- **Verifiable**: Anyone can independently compute and verify an atom's ID

### Try It Locally

```typescript
import { calculateAtomId } from '@0xintuition/protocol'
import { toHex } from 'viem'

const concepts = ['TypeScript', 'Rust', 'Python', 'Solidity', 'Bun']

for (const concept of concepts) {
  const id = calculateAtomId(toHex(concept))
  console.log(`"${concept}" → ${id.slice(0, 18)}...`)
}
```

Notice: each concept gets a unique, deterministic ID. These IDs will be the same whether you run this on your laptop, a server in Tokyo, or an agent in the cloud.

## Atom Data Encoding

Atoms store data as raw bytes on-chain. The protocol accepts any hex-encoded data, but the most common pattern is encoding a UTF-8 string:

```typescript
import { toHex, fromHex } from 'viem'

// Encode: string → hex bytes
const encoded = toHex('TypeScript')
// '0x54797065536372697074'

// Decode: hex bytes → string
const decoded = fromHex(encoded, 'string')
// 'TypeScript'
```

### Common Data Patterns

| Pattern | Data Stored | Example |
|---------|------------|---------|
| **String** | UTF-8 text as hex | `toHex('TypeScript')` |
| **Ethereum Address** | 20-byte address as hex | `'0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045'` |
| **IPFS URI** | IPFS link as hex | `toHex('ipfs://Qm...')` |
| **URL** | Any URL as hex | `toHex('https://example.com')` |

String atoms are the most common — they're used for concepts, labels, predicates, and most knowledge graph nodes.

## The Write Flow: Creating Atoms On-Chain

Creating an atom follows the four-step write flow you'll see throughout the protocol:

```
1. Get cost       → multiVaultGetAtomCost(readConfig)
2. Encode data    → toHex('TypeScript')
3. Submit tx      → multiVaultCreateAtoms(writeConfig, { args, value })
4. Parse events   → eventParseAtomCreated(publicClient, txHash)
```

### Step by Step

```typescript
import {
  multiVaultCreateAtoms,
  multiVaultGetAtomCost,
  eventParseAtomCreated,
} from '@0xintuition/protocol'
import { toHex, fromHex } from 'viem'
import { publicClient, readConfig, writeConfig } from './setup'

// 1. Get the current atom creation cost
const atomCost = await multiVaultGetAtomCost(readConfig)

// 2. Encode your atom data as hex
const atomData = toHex('TypeScript')

// 3. Submit the transaction
//    args are arrays — the protocol supports batch creation
const txHash = await multiVaultCreateAtoms(writeConfig, {
  args: [[atomData], [atomCost]],
  value: atomCost,
})

// 4. Parse the AtomCreated event from the transaction receipt
const [event] = await eventParseAtomCreated(publicClient, txHash)

console.log('Atom created!')
console.log('  TX Hash:', txHash)
console.log('  Term ID:', event.args.termId)
console.log('  Creator:', event.args.creator)
console.log('  Data:', fromHex(event.args.atomData, 'string'))
console.log('  Atom Wallet:', event.args.atomWallet)
```

### What Happens On-Chain

When MultiVault processes `createAtoms()`:

1. Hex-encodes and hashes the data to generate a deterministic term ID
2. Checks if this atom already exists (if so, reverts)
3. Mints an ERC-1155 token for the atom
4. Creates a smart contract wallet for the atom
5. Creates a vault for staking on the atom
6. Emits an `AtomCreated` event with the term ID, creator, data, and wallet address

The cost covers: protocol fee + atom wallet initial deposit + your optional extra deposit.

## Batch Creation

Creating atoms one at a time is fine for learning, but real applications often need batch operations. The protocol supports this natively — `multiVaultCreateAtoms` already takes arrays:

```typescript
const atoms = ['TypeScript', 'Rust', 'Python']
const encodedAtoms = atoms.map(text => toHex(text))
const costs = encodedAtoms.map(() => atomCost)
const totalCost = costs.reduce((sum, c) => sum + c, 0n)

const txHash = await multiVaultCreateAtoms(writeConfig, {
  args: [encodedAtoms, costs],
  value: totalCost,
})

// Parse all creation events from the single transaction
const events = await eventParseAtomCreated(publicClient, txHash)

console.log(`Created ${events.length} atoms in one transaction:`)
for (const event of events) {
  const text = fromHex(event.args.atomData, 'string')
  console.log(`  [${event.args.termId}] ${text}`)
}
```

Batch creation is:
- **Cheaper**: One transaction instead of many (saves gas)
- **Atomic**: All atoms are created or none are (no partial state)
- **Faster**: One confirmation instead of waiting for each

## Verifying Atoms On-Chain

After creating an atom, you can verify it exists using the on-chain read functions:

```typescript
import {
  multiVaultIsTermCreated,
  multiVaultGetAtom,
} from '@0xintuition/protocol'
import { fromHex, type Hex } from 'viem'

// Check if a term exists
const exists = await multiVaultIsTermCreated(readConfig, { args: [termId] })
console.log('Exists on-chain:', exists)

// Read the raw atom data
const atomData = await multiVaultGetAtom(readConfig, { args: [termId] })
const decoded = fromHex(atomData as Hex, 'string')
console.log('Atom data:', decoded)
```

You can also view atoms on the Portal: `https://portal.intuition.systems`

Or on the block explorer: `https://testnet.explorer.intuition.systems`

## Key Concepts

| Concept | Detail |
|---------|--------|
| `calculateAtomId(hex)` | Deterministic ID from data — works offline |
| `toHex(string)` | Encode string to hex bytes (required for atom data) |
| `fromHex(hex, 'string')` | Decode hex bytes back to string |
| `multiVaultGetAtomCost(readConfig)` | Read the current atom creation cost |
| `multiVaultCreateAtoms(writeConfig, { args, value })` | Create one or more atoms on-chain |
| `eventParseAtomCreated(publicClient, txHash)` | Parse AtomCreated events from a transaction |
| `multiVaultIsTermCreated(readConfig, { args })` | Check if an atom exists on-chain |
| `multiVaultGetAtom(readConfig, { args })` | Read an atom's raw data by term ID |

## Quick Reference

```
Calculate ID:       calculateAtomId(toHex('my concept'))
Check existence:    multiVaultIsTermCreated(readConfig, { args: [termId] })
Read atom data:     multiVaultGetAtom(readConfig, { args: [termId] })
Get cost:           multiVaultGetAtomCost(readConfig)
Create (single):    multiVaultCreateAtoms(writeConfig, { args: [[data], [cost]], value: cost })
Create (batch):     multiVaultCreateAtoms(writeConfig, { args: [dataArray, costArray], value: total })
Parse events:       eventParseAtomCreated(publicClient, txHash)
```

## Try It

1. **Calculate IDs for a mini knowledge graph**: Think of a small domain you know well (programming languages, your team, a project). List 5-8 concepts and calculate their atom IDs. Store them in an object for reference:

```typescript
const concepts = ['TypeScript', 'JavaScript', 'Rust', 'Programming Language', 'compiled', 'interpreted']
const ids: Record<string, string> = {}
for (const c of concepts) {
  ids[c] = calculateAtomId(toHex(c))
}
```

2. **Verify determinism**: Run your calculation script twice. Do you get the same IDs both times? What happens if you change the capitalization ("typescript" vs "TypeScript")?

3. **Explore encoding**: Use `toHex` to encode different kinds of data — strings, URLs, an Ethereum address. Then decode them back with `fromHex`. What does the hex look like for each?

4. **Check existence**: Calculate the atom ID for something that probably exists on-chain (like "Ethereum") and use `multiVaultIsTermCreated` to check. Then try something obscure — does it exist?

### Go Further (Testnet)

5. **Create your first atom**: Follow the four-step write flow to create a concept that matters to you. Parse the `AtomCreated` event and inspect every field. Check the transaction on the explorer.

6. **Batch create**: Create 3-5 related concepts in a single batch transaction. Parse all the events. Compare how one transaction created multiple atoms.

7. **Read it back**: After creating atoms, use `multiVaultGetAtom` to read the data back from the contract. Decode it with `fromHex` — does it match what you sent?

---

You can now create atoms — the building blocks of the knowledge graph. Next, you'll connect them with triples to express relationships and meaning.

Type `/learn next` for Lesson 07: Building Triples, or `/learn` for the dashboard.
