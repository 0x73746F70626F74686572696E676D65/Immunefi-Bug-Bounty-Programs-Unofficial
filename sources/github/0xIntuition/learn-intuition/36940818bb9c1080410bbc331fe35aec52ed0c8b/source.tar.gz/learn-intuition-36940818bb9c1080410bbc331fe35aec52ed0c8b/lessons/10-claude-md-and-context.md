===============================================================
LESSON 10: Context Engineering for Intuition
===============================================================

## The most important file in an AI-augmented project isn't code.

You've been learning the Intuition protocol with AI assistance throughout this course. But have you noticed how the AI *already knows* about atoms, triples, and the protocol without you explaining from scratch every time?

That's not magic. It's **context engineering** — the practice of giving AI the right information at the right time so it can help you effectively. And the primary tool for this is a project context file.

## What is a Project Context File?

Many AI-assisted development tools support a project-level context file (like CLAUDE.md for Claude Code, or similar conventions in other tools). This file lives in your project root and is read at the start of every conversation. It's your project's onboarding document for AI — the equivalent of sitting down with a new team member and saying "here's what you need to know."

This course has one. You've been benefiting from it the whole time.

### What Goes in a Context File

| Section | Purpose | Example |
|---------|---------|---------|
| **Project identity** | What this project is, in one paragraph | "An app that creates curated lists on the Intuition knowledge graph" |
| **Stack and dependencies** | Technical choices the AI needs to know | "Bun, TypeScript, @0xintuition/protocol, React Router 7" |
| **Key concepts** | Domain knowledge the AI needs | "Atoms are identifiers, Triples are S-P-O claims, term IDs are bytes32" |
| **Code conventions** | How code should look | "Use getReadConfig/getWriteConfig helpers, write flow pattern for creates" |
| **Key URLs and addresses** | Where to find things | Contract addresses, GraphQL endpoint, docs links |
| **Rules** | What to do and not do | "Never hardcode addresses — use getMultiVaultAddressFromChainId" |

### What Doesn't Belong

- Full API reference (too large — link to docs or use reference files instead)
- Implementation details that change every commit (put those in code comments)
- Generic coding style rules (use a linter config instead)

## The Key Insight

**Context > features.** A mediocre AI with perfect context outperforms a brilliant AI with none. When your AI assistant knows:
- What chain you're on (testnet, chain ID 13579)
- What package you use (`@0xintuition/protocol`)
- What the write flow looks like (cost → encode → submit → parse events)
- Where the GraphQL endpoint is (`https://testnet.intuition.sh/v1/graphql`)

...it can generate correct code on the first try instead of hallucinating function signatures or using the wrong network.

## Anatomy of This Project's Context

Let's look at the CLAUDE.md you've been using throughout this course. Open it:

```bash
cat CLAUDE.md
```

Notice the structure:

1. **What This Is** — one paragraph positioning the project
2. **Your Role** — behavioral guidance (course instructor)
3. **Project Structure** — directory layout so the AI knows where to find things
4. **Quick Reference** — the three primitives, summarized
5. **Key URLs** — docs, Portal, Discord, GitHub
6. **Teaching Rules** — behavioral guidelines
7. **Code Conventions** — runtime, language, package, chain details
8. **Protocol Teaching Context** — for Part 2, which reference files to read

This isn't a coincidence — it's deliberately structured so the AI can teach Intuition accurately across sessions.

## Writing a Context File for an Intuition Project

If you're building an app on Intuition, here's what your context file should include. These patterns come from real Intuition applications:

### Essential Sections

```markdown
# My Intuition App

## What This Is
A [type of app] that uses the Intuition knowledge graph to [purpose].

## Stack
- Runtime: Bun
- Framework: [React / React Router 7 / CLI / etc.]
- Protocol: @0xintuition/protocol
- Chain: Intuition testnet (ID 13579)
- GraphQL: https://testnet.intuition.sh/v1/graphql

## Config Helpers
Use these helpers to build configs — never hardcode the MultiVault address:

getReadConfig(chainId, publicClient) → ReadConfig
getWriteConfig(chainId, publicClient, walletClient) → WriteConfig

Both use getMultiVaultAddressFromChainId internally.

## Write Flow Pattern
Every create operation follows the same pattern:
1. Get cost → multiVaultGetAtomCost / multiVaultGetTripleCost
2. Encode data → toHex for atoms, term IDs for triples
3. Submit tx → multiVaultCreateAtoms / multiVaultCreateTriples
4. Parse events → eventParseAtomCreated / eventParseTripleCreated

## Read Patterns
- On-chain reads (real-time, authoritative): multiVaultGet* functions
- Indexed reads (search, labels, positions): GraphQL queries
- Preview operations: multiVaultPreviewDeposit, multiVaultPreviewRedeem

## Key Constants
- Default curve ID: 1n
- Default min shares: 0n (no slippage protection)
- Token: tTRUST (testnet) / TRUST (mainnet), 18 decimals
- Term IDs are bytes32 hex values

## References
- Docs: https://docs.intuition.systems
- Portal: https://portal.intuition.systems
- Faucet: https://testnet.hub.intuition.systems/
```

### Why These Sections Matter

Each section solves a specific failure mode:

| Section | Prevents |
|---------|----------|
| Stack + package | AI importing wrong package (`sdk` vs `protocol`) |
| Config helpers | Hardcoded addresses that break across chains |
| Write flow | AI inventing convenience functions that don't exist |
| Read patterns | AI using on-chain reads for search (wrong layer) |
| Key constants | Wrong types (string vs bigint), wrong curve IDs |
| References | AI hallucinating URLs or contract addresses |

### For Apps with Authentication

If your app uses SIWE (Sign-In with Ethereum) or other auth patterns, add:

```markdown
## Authentication
- SIWE flow: connect wallet → sign message → verify server-side → JWT cookie
- Protected routes require valid session
- Wallet connection uses Wagmi hooks (useAccount, useConnect)
```

### For Apps with Curated Lists

If you're building with the curated list pattern:

```markdown
## Curated Lists Pattern
Lists use triples: [item] -[has_tag]-> [list]
- Predicate: "has_tag" atom (get the term ID first)
- Adding to list = creating a triple
- Removing = no on-chain delete, but you can stake AGAINST
- Query list items via GraphQL: triples where predicate_id = has_tag AND object_id = list
```

## Testing Your Context

How do you know if your context file is good enough? Three tests:

1. **The cold start test**: Start a new AI session in your project. Ask a domain-specific question ("How do I create an atom?") without any other context. Does it answer using the right package and patterns?

2. **The code generation test**: Ask for a function that creates an atom. Does it use `@0xintuition/protocol`, the write flow pattern, and the correct config types? If it hallucinates a function name, your context is missing something.

3. **The new teammate test**: If a developer who'd never seen your project read only the context file, could they understand what the project does, what conventions to follow, and where to find things?

## Context as Living Documentation

Context files should evolve with your project. Common triggers to update:

- **Switching chains** (testnet → mainnet): Update chain IDs, contract addresses, token references
- **Adding new patterns** (e.g., batch deposits): Document the pattern so AI uses it consistently
- **Discovering gotchas**: When you debug a non-obvious issue, add it to prevent repeats

The goal isn't comprehensive documentation — it's the *minimum context* that prevents the AI from making wrong assumptions.

## Quick Reference

```
Context file:         Project root (e.g., CLAUDE.md)
Key sections:         Identity, stack, conventions, patterns, constants, references
Update triggers:      Chain switch, new pattern, discovered gotcha
Tests:                Cold start, code generation, new teammate
```

## Try It

1. **Read the source**: Open this project's `CLAUDE.md` and read it. What sections does it have? How does each section help the AI teach you accurately?

2. **Spot the context**: Think about your experience in this course. Can you identify moments where AI answers were shaped by the context file? (Hint: every time it correctly used protocol terminology, referenced the Portal, or knew which reference files to check.)

3. **Write your own**: Draft a context file for a simple Intuition app — a CLI that creates atoms and queries the graph. Include: project identity, stack, config helpers, write flow, read patterns, and references. Keep it under 40 lines.

4. **The cold start test**: If you're using an AI-assisted editor, start a new session in this project. Ask: "What are the three primitives of the Intuition protocol?" The context file is why the AI can answer correctly without you explaining.

5. **Extend for your use case**: Take the template from this lesson and customize it for something you'd actually build. What patterns are specific to your app? What gotchas would you document?

---

You now understand how to set up your project for effective AI-assisted development. Next, you'll put everything together — protocol knowledge, building skills, and project context — to build a real Intuition application.

Type `/learn next` for Lesson 11: Capstone Project, or `/learn` for the dashboard.
