# Intuition Primitives — Reference

> Curated from Intuition docs for course accuracy. Source: https://docs.intuition.systems

## The Three Primitives

Intuition's knowledge graph is built from three composable primitives:

### 1. Atoms — The Words

Atoms are unique decentralized identifiers for any entity, concept, or piece of data. They are the fundamental building blocks — the "words" in Intuition's global dictionary.

**What they represent:**
- People (user identities, profiles)
- Organizations (companies, DAOs, projects)
- Addresses (wallets, smart contracts)
- Documents (files, articles, research papers)
- Concepts (ideas, skills, categories)
- Anything that needs a persistent, unique identifier

**Technical details:**
- ERC-1155 multi-token standard
- Unique ID is deterministically derived from atomData (same data = same ID, no duplicates)
- Each atom has: Atom ID, Atom Data (arbitrary — URI, text, JSON), Smart Contract Wallet
- Three components: Atom Data, Atom Wallet (smart contract wallet for the atom itself), Atom Vault (staking vault)

**Key property: Deterministic addressing.** Because atom IDs are derived from their data via hashing, anyone can independently verify an atom's identity. Two people creating an atom for "TypeScript" will reference the same atom.

### 2. Triples — The Sentences

Triples connect three atoms to express relationships in [Subject]-[Predicate]-[Object] format. If atoms are words, triples are the sentences we construct from them.

**Structure:**
```
[Subject Atom] — [Predicate Atom] — [Object Atom]
```

**Examples:**
- `[Alice] — [knows] — [Bob]`
- `[TypeScript] — [is a] — [Programming Language]`
- `[Vitalik] — [created] — [Ethereum]`
- `[Contract A] — [is safe] — [true]`

**Technical details:**
- RDF-compatible semantic triples (machine-readable)
- Each component is an Atom ID (not free-form text)
- Triples can be nested: a triple can be used as an atom in another triple
  - Example: `[Alice] [endorses] [[Bob has skill TypeScript]]`
- Form a directed graph: atoms = nodes, triples = directed edges (subject → object, labeled by predicate)

**Key property: Composability.** Because triples reference atoms by ID, and triples can themselves become atoms, you can build arbitrarily complex knowledge structures.

### 3. Signals — The Conviction

Signals represent trust, confidence, or relevance assigned to atoms and triples through staking. They transform static data into a dynamic, weighted intelligence layer.

**How staking works:**
- Deposit tokens into a vault → receive vault shares
- Atoms have **one vault** (signal relevance)
- Triples have **two vaults**: FOR (affirm the claim) and AGAINST (reject the claim)
- Bonding curve pricing: early stakers get better prices, later stakers pay more

**Signal types:**
- **Explicit**: Intentional staking, voting, attestations
- **Implicit**: Usage patterns, query frequency, inclusion in other triples
- **Transitive**: Trust passed through relationship networks

**Key property: Bonding curves create perpetual prediction markets.** The more people stake on an atom or triple, the higher the price goes, creating economic incentive to discover important information early.

## How They Compose

```
Atoms (identifiers)
  ↓ combine into
Triples (relationships)
  ↓ weighted by
Signals (conviction)
  = Knowledge Graph
```

The result is a decentralized knowledge graph where:
- Anyone can create atoms (new words in the dictionary)
- Anyone can create triples (new sentences from those words)
- Anyone can stake on atoms/triples (express conviction about what matters)
- Economic incentives align with quality and truth
