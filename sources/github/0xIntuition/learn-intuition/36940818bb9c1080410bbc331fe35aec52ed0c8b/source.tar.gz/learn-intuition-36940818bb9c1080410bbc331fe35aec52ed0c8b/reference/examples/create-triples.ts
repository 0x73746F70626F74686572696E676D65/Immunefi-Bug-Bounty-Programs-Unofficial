/**
 * Intuition Protocol — Creating Triples
 *
 * Demonstrates the write flow:
 * 1. Get cost (multiVaultGetTripleCost)
 * 2. Submit transaction (multiVaultCreateTriples) with term IDs
 * 3. Parse events (eventParseTripleCreated)
 *
 * Also shows: offline ID calculation, counter-triples, inverse lookups
 */

import {
  calculateAtomId,
  calculateCounterTripleId,
  calculateTripleId,
  eventParseTripleCreated,
  multiVaultCreateTriples,
  multiVaultGetInverseTripleId,
  multiVaultGetTriple,
  multiVaultGetTripleCost,
  multiVaultIsTriple,
} from '@0xintuition/protocol'
import { toHex } from 'viem'
import { publicClient, readConfig, writeConfig } from './setup'

// ─── 1. Calculate Triple ID (Offline) ──────────────────────────────
// First, calculate the atom IDs for subject, predicate, object

const subjectId = calculateAtomId(toHex('Alice'))
const predicateId = calculateAtomId(toHex('knows'))
const objectId = calculateAtomId(toHex('TypeScript'))

// Then calculate the triple ID
const tripleId = calculateTripleId(subjectId, predicateId, objectId)
console.log('Triple ID for [Alice]-[knows]-[TypeScript]:', tripleId)

// ─── 2. Counter Triple ID ──────────────────────────────────────────
// Every triple has a "counter" — the AGAINST side

const counterTripleId = calculateCounterTripleId(tripleId)
console.log('Counter triple ID (AGAINST):', counterTripleId)

// The FOR vault uses the tripleId, AGAINST vault uses the counterTripleId

// ─── 3. Check Triple Cost ──────────────────────────────────────────

const tripleCost = await multiVaultGetTripleCost(readConfig)
console.log('Current triple creation cost:', tripleCost, 'wei')

// ─── 4. Create a Triple (Testnet) ──────────────────────────────────
// Requires writeConfig AND the atoms must already exist on-chain
// The args are parallel arrays: subjects[], predicates[], objects[], deposits[]

if (writeConfig) {
  // NOTE: these must be the term IDs of atoms that already exist on-chain
  const txHash = await multiVaultCreateTriples(writeConfig, {
    args: [
      [subjectId],    // subject term IDs
      [predicateId],  // predicate term IDs
      [objectId],     // object term IDs
      [tripleCost],   // deposit per triple
    ],
    value: tripleCost,
  })

  const [event] = await eventParseTripleCreated(publicClient, txHash)

  console.log('Triple created!')
  console.log('  TX Hash:', txHash)
  console.log('  Term ID:', event.args.termId)
  console.log('  Subject:', event.args.subjectId)
  console.log('  Predicate:', event.args.predicateId)
  console.log('  Object:', event.args.objectId)
}

// ─── 5. Batch Create Triples ───────────────────────────────────────

if (writeConfig) {
  const txHash = await multiVaultCreateTriples(writeConfig, {
    args: [
      [subjectId, subjectId],      // subject for each triple
      [predicateId, predicateId],  // predicate for each triple
      [objectId, objectId],        // object for each triple
      [tripleCost, tripleCost],    // deposit for each
    ],
    value: tripleCost * 2n,
  })

  const events = await eventParseTripleCreated(publicClient, txHash)
  console.log(`Batch created ${events.length} triples`)
}

// ─── 6. Read Triple Data On-Chain ──────────────────────────────────
// These are on-chain reads — they query the MultiVault contract directly

// Get a triple's components
const [s, p, o] = await multiVaultGetTriple(readConfig, { args: [tripleId] })
console.log('Triple components:', { subject: s, predicate: p, object: o })

// Check if a term ID is a triple
const isTriple = await multiVaultIsTriple(readConfig, { args: [tripleId] })
console.log('Is triple:', isTriple)

// Get the inverse (AGAINST) triple ID on-chain
const inverseId = await multiVaultGetInverseTripleId(readConfig, { args: [tripleId] })
console.log('Inverse triple ID:', inverseId)

// ─── Common Predefined Predicates ──────────────────────────────────
// These are common predicates used in the Intuition ecosystem:
//
// "is"             — categorical classification
// "has tag"        — tagging / labeling (used for curated lists)
// "contains"       — membership / composition
// "related"        — general association
// "url"            — linking to a URL
// "linked account" — connecting identities
//
// To use them, first find their term IDs on-chain or create them as atoms.
