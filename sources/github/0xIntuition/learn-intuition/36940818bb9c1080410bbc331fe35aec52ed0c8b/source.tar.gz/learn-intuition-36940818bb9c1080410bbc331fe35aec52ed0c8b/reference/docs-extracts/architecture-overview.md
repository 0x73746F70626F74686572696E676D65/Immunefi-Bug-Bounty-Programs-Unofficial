# Intuition Architecture — Reference

> Curated from Intuition docs for course accuracy. Source: https://docs.intuition.systems

## Protocol Architecture

### Network Layer

Intuition is a **Layer 3 (L3)** blockchain built on Base using Arbitrum Orbit technology:
- Base (L2) provides Ethereum security
- Intuition L3 provides fast, cheap transactions optimized for knowledge graph operations
- AnyTrust DA (data availability) for trust-minimized data
- Native token: **TRUST** ($TRUST on mainnet, $tTRUST on testnet)

### Core Contract: MultiVault

The **MultiVault** is the central smart contract that manages everything:
- Creates and stores atoms
- Creates and stores triples
- Manages all vaults (deposits, withdrawals)
- Tracks fees and rewards
- Acts as the registry and vault factory

All protocol interactions go through the MultiVault.

### Data Flow

```
User Action → MultiVault Contract → State Change
                                   → Event Emitted
                                   → Indexer Picks Up
                                   → GraphQL API Updated
                                   → Portal/Apps Reflect Change
```

1. **Creation**: User creates atom or triple via MultiVault
2. **Indexing**: Events are picked up by the indexer
3. **Query**: GraphQL API provides read access to the knowledge graph
4. **Display**: Portal and apps query the API to show data

### Access Patterns

| Method | Use Case | Package |
|--------|----------|---------|
| Protocol package | Low-level contract calls (create, stake, query on-chain) | `@0xintuition/protocol` |
| SDK | High-level TypeScript API with React hooks | `@0xintuition/sdk` |
| GraphQL API | Read-only queries for atoms, triples, signals | API endpoint |
| Portal | Human-friendly web interface for exploring the graph | https://portal.intuition.systems |

### Atom Creation Flow

1. User submits atom data (URI, text, JSON, etc.)
2. MultiVault hashes the data to generate a deterministic atom ID
3. ERC-1155 token minted for the atom
4. Smart contract wallet created for the atom
5. Vault created for staking on the atom
6. Event emitted, indexer updates GraphQL

### Triple Creation Flow

1. User specifies three atom IDs: subject, predicate, object
2. MultiVault creates the triple record
3. Two vaults created: FOR and AGAINST
4. Event emitted, indexer updates GraphQL

### Vault Operations Flow

1. **Deposit**: User sends tokens → MultiVault calculates shares via bonding curve → shares minted to user
2. **Redeem**: User burns shares → MultiVault calculates token amount (minus fees) → tokens sent to user

## Key Technical Concepts

### Deterministic Atom IDs
Same atomData → same atom ID. This prevents duplicates and enables anyone to reference the same atom independently.

### ERC-1155 Multi-Token
Atoms are ERC-1155 tokens, enabling batch operations and standard token interfaces. Multiple atom types coexist in one contract.

### Atom Wallets
Each atom has its own smart contract wallet (controlled by the Atom Warden). This means atoms can own assets and interact with other contracts — they have agency.

### Vault Shares
When you stake, you receive vault shares proportional to your deposit and the current bonding curve price. Shares represent:
- Proportional ownership of the vault's total assets
- Claim on future fee distributions
- Voting weight / signal strength

### Multiple Bonding Curve Types

The protocol supports multiple bonding curve implementations via a **BondingCurveRegistry**:
- **LinearCurve**: Simple linear price progression
- **OffsetProgressiveCurve**: Progressive curve with an offset for different price dynamics

Each vault operation (deposit, redeem) requires a `curveId` parameter specifying which curve to use. The default curve ID can be queried from the protocol config.

### Additional Contracts

Beyond the MultiVault, the protocol includes:
- **AtomWarden**: Controls atom wallet interactions
- **AtomWalletFactory / AtomWalletBeacon**: Infrastructure for creating atom wallets
- **BondingCurveRegistry**: Manages available bonding curve types
- **EntryPoint**: ERC-4337 account abstraction support for gasless transactions

### MCP Server

The **Intuition MCP Server** provides AI agent integration via the Model Context Protocol:
- HTTP stream server for AI tool use
- Tools: `search_atoms`, `get_account_info`, `search_lists`, `get_following`, `get_followers`, `search_account_ids`
- Supports Streamable HTTP and SSE transports
- Enables AI agents to query the knowledge graph directly
