# Intuition Economics — Reference

> Curated from Intuition docs for course accuracy. Source: https://docs.intuition.systems

## Economic Model

Intuition uses a **Token-Curated Graph (TCG)** — economic incentives align token staking with knowledge quality and relevance.

## Bonding Curves

The price of vault shares follows a bonding curve. The protocol supports multiple curve types via a **BondingCurveRegistry**:

- **LinearCurve**: `price = k * supply` — simple linear progression
- **OffsetProgressiveCurve**: Progressive curve with offset for different price dynamics

The classic model:

```
price = k * supply^n
```

Where `k` and `n` are constants, and `supply` is the current total shares.

**What this means in practice:**
- **First staker** gets the most shares per token deposited
- **Later stakers** pay progressively more per share
- **Early discovery is rewarded** — if you stake on an atom early and it becomes popular, your shares are worth more
- **Creates a perpetual prediction market** for information relevance

Each vault operation requires a `curveId` parameter. The default curve ID (typically `1` on mainnet) can be queried once per session via `getBondingCurveConfig()`.

### Example

1. Alice stakes 10 TRUST on atom `[Ethereum]` when no one else has → gets 100 shares at 0.1 TRUST/share
2. Bob stakes 10 TRUST later when the curve has moved → gets 50 shares at 0.2 TRUST/share
3. The atom now has 20 TRUST total and 150 total shares
4. Alice's 100 shares are now worth more than her original 10 TRUST investment

## Vaults

### Atom Vaults
- Each atom has **one vault**
- Staking signals "I believe this atom is relevant/important"
- TVL (Total Value Locked) = measure of community conviction

### Triple Vaults
- Each triple has **two vaults**: FOR and AGAINST
- **FOR vault**: "I affirm this claim is true/valid"
- **AGAINST vault**: "I reject this claim / it's false"
- The balance between FOR and AGAINST TVL represents community consensus

### Vault Shares
- Depositing tokens → receive shares (proportional to bonding curve price)
- Redeeming shares → receive tokens back (minus exit fees)
- Share value increases as more tokens are deposited (bonding curve)
- Shares represent fractional ownership of the vault

## Fee Structure

| Fee Type | When Charged | Who Benefits |
|----------|-------------|-------------|
| **Entry Fee** | When depositing into a vault | Protocol + existing stakers |
| **Exit Fee** | When redeeming from a vault | Protocol + remaining stakers |
| **Protocol Fee** | On various operations | Protocol treasury |
| **Creator Fee** | When others interact with your atom/triple | Original creator |

**Creator fees** are a key incentive: if you create a high-quality atom that many people stake on, you earn fees from their interactions. This incentivizes creating useful, well-structured knowledge.

## Token-Curated Registry (TCR)

Because the system is permissionless, multiple atoms may represent the same concept. The TCR mechanism resolves this:

1. Anyone can create atoms for "TypeScript"
2. The community stakes on the one they consider canonical
3. The atom with the highest TVL becomes the de facto standard
4. Creator of the winning atom earns ongoing fees

This creates **organic, incentive-driven standardization** — the community converges on canonical identifiers through economic participation rather than committee decisions.

## Total Value Locked (TVL)

TVL is the primary measure of conviction in the system:

- **Atom TVL**: How much the community values this identifier
- **Triple FOR TVL**: Strength of agreement with the claim
- **Triple AGAINST TVL**: Strength of disagreement
- **Net consensus**: FOR TVL vs AGAINST TVL ratio

High TVL on an atom suggests it's a widely-accepted canonical identifier. High TVL on a triple's FOR vault suggests strong community agreement with the claim.

## Wrapped Trust & Voting Escrow

### Wrapped Trust (wTRUST)
Staked positions can be tokenized as **Wrapped Trust** — ERC-20 tokens representing vault shares. This enables:
- Transferring staked positions between wallets
- Using staked positions as collateral
- Trading positions on DEXs

### Voting Escrow (veTRUST)
The **TrustBonding** contract introduces a voting escrow mechanism (based on Curve's veCRV model):
- Lock wTRUST for a period → receive veTRUST
- veTRUST represents governance weight and rewards eligibility
- Operations: `create_lock`, `increase_amount`, `increase_unlock_time`, `withdraw`
- Epoch-based rewards and emissions via SatelliteEmissionsController

## Economic Summary

The genius of the model: **every interaction with the knowledge graph has an economic dimension.** Creating atoms, staking on triples, and redeeming positions all generate fees that flow to creators, stakers, and the protocol. This aligns everyone's incentives with building a high-quality, well-curated knowledge graph.
