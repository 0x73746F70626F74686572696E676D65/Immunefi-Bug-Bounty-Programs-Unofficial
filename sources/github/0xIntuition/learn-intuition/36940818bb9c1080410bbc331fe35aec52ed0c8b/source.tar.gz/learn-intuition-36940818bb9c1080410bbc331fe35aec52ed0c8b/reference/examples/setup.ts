/**
 * Intuition Protocol — Client Setup
 *
 * Two configurations:
 * 1. Read-only (publicClient) — free, no wallet needed
 * 2. Full access (publicClient + walletClient) — needs testnet tokens
 */

import {
  getMultiVaultAddressFromChainId,
  intuitionTestnet,
  type ReadConfig,
  type WriteConfig,
} from '@0xintuition/protocol'
import {
  createPublicClient,
  createWalletClient,
  http,
} from 'viem'
import { privateKeyToAccount } from 'viem/accounts'

// ─── 1. Read-Only Client (No Wallet Needed) ────────────────────────
export const publicClient = createPublicClient({
  chain: intuitionTestnet,
  transport: http(),
})

export const readConfig: ReadConfig = {
  address: getMultiVaultAddressFromChainId(intuitionTestnet.id),
  publicClient,
}

// ─── 2. Full Access Client (Wallet Required) ───────────────────────
// Only needed for write operations (creating atoms, triples, depositing)
// Set PRIVATE_KEY in your environment — NEVER commit it to source control

const account = process.env.PRIVATE_KEY
  ? privateKeyToAccount(process.env.PRIVATE_KEY as `0x${string}`)
  : undefined

export const walletClient = account
  ? createWalletClient({
      account,
      chain: intuitionTestnet,
      transport: http(),
    })
  : undefined

export const writeConfig: WriteConfig | undefined =
  walletClient && account
    ? {
        address: getMultiVaultAddressFromChainId(intuitionTestnet.id),
        publicClient,
        walletClient,
      }
    : undefined
