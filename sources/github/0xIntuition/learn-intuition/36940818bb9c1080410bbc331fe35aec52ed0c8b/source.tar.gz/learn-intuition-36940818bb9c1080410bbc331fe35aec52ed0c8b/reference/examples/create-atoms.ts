/**
 * Intuition Protocol — Creating Atoms
 *
 * Demonstrates the write flow:
 * 1. Get cost (multiVaultGetAtomCost)
 * 2. Encode data (toHex)
 * 3. Submit transaction (multiVaultCreateAtoms)
 * 4. Parse events (eventParseAtomCreated)
 *
 * Also shows: offline ID calculation, batch creation
 */

import {
  calculateAtomId,
  eventParseAtomCreated,
  multiVaultCreateAtoms,
  multiVaultGetAtomCost,
} from '@0xintuition/protocol'
import { fromHex, toHex } from 'viem'
import { publicClient, readConfig, writeConfig } from './setup'

// ─── 1. Calculate Atom ID (Offline) ────────────────────────────────
// This works without any network connection — it's pure hashing.

const atomId = calculateAtomId(toHex('TypeScript'))
console.log('Calculated atom ID for "TypeScript":', atomId)

// Same input always produces the same ID (deterministic)
const sameId = calculateAtomId(toHex('TypeScript'))
console.log('Same input, same ID:', atomId === sameId) // true

// Different input produces different ID
const differentId = calculateAtomId(toHex('Rust'))
console.log('Different input, different ID:', atomId !== differentId) // true

// ─── 2. Check Atom Cost ────────────────────────────────────────────

const atomCost = await multiVaultGetAtomCost(readConfig)
console.log('Current atom creation cost:', atomCost, 'wei')

// ─── 3. Create a Single Atom (Testnet) ─────────────────────────────
// Requires writeConfig (wallet + testnet tokens)

if (writeConfig) {
  // Encode the string as hex bytes
  const atomData = toHex('TypeScript')

  // Submit the transaction
  const txHash = await multiVaultCreateAtoms(writeConfig, {
    args: [[atomData], [atomCost]],
    value: atomCost,
  })

  // Parse the event to get the result
  const [event] = await eventParseAtomCreated(publicClient, txHash)

  console.log('Atom created!')
  console.log('  TX Hash:', txHash)
  console.log('  Term ID:', event.args.termId)
  console.log('  Creator:', event.args.creator)
  console.log('  Atom Data:', fromHex(event.args.atomData, 'string'))
}

// ─── 4. Batch Create Atoms ─────────────────────────────────────────
// Create multiple atoms in one transaction

if (writeConfig) {
  const atoms = ['TypeScript', 'Rust', 'Python']
  const encodedAtoms = atoms.map(text => toHex(text))
  const costs = encodedAtoms.map(() => atomCost)
  const totalCost = costs.reduce((sum, c) => sum + c, 0n)

  const txHash = await multiVaultCreateAtoms(writeConfig, {
    args: [encodedAtoms, costs],
    value: totalCost,
  })

  const events = await eventParseAtomCreated(publicClient, txHash)

  console.log(`Batch created ${events.length} atoms:`)
  for (const event of events) {
    const text = fromHex(event.args.atomData, 'string')
    console.log(`  [${event.args.termId}] ${text}`)
  }
}
