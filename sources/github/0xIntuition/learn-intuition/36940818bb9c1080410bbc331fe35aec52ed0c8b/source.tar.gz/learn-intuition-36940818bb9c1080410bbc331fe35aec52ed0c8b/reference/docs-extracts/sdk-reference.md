# Intuition Protocol Package — Quick Reference

> Reference for `@0xintuition/protocol` v2.0.2. Source: protocol package + template implementations.

## Installation

```bash
bun add @0xintuition/protocol viem
```

The protocol package provides all the functions you need to interact with Intuition's MultiVault contract directly — chain config, read/write helpers, and event parsers.

## Chain Configuration

```ts
import { intuitionTestnet } from '@0xintuition/protocol'
```

| Property | Testnet | Mainnet |
|----------|---------|---------|
| Chain ID | 13579 | 1155 |
| Name | Intuition Testnet | Intuition |
| Native Token | tTRUST (18 decimals) | TRUST (18 decimals) |
| RPC (HTTP) | `https://testnet.rpc.intuition.systems/http` | `https://rpc.intuition.systems/http` |
| RPC (WS) | `wss://testnet.rpc.intuition.systems/ws` | `wss://rpc.intuition.systems/ws` |
| Explorer | `https://testnet.explorer.intuition.systems` | `https://explorer.intuition.systems` |
| MultiVault | `0x2Ece8D4dEdcB9918A398528f3fa4688b1d2CAB91` | `0x6E35cF57A41fA15eA0EaE9C33e751b01A784Fe7e` |

### MultiVault Address Helper

```ts
import { getMultiVaultAddressFromChainId } from '@0xintuition/protocol'

const address = getMultiVaultAddressFromChainId(13579) // testnet
const address = getMultiVaultAddressFromChainId(1155)  // mainnet
```

## Key Types

```ts
import { type ReadConfig, type WriteConfig } from '@0xintuition/protocol'

// Read-only operations (queries, reading costs)
type ReadConfig = {
  address: Address       // MultiVault contract address
  publicClient: PublicClient
}

// Write operations (creating atoms, triples, depositing)
type WriteConfig = {
  address: Address       // MultiVault contract address
  walletClient: WalletClient
  publicClient: PublicClient
}
```

### Building Configs

The recommended pattern (used in both Intuition templates):

```ts
import { getMultiVaultAddressFromChainId, type ReadConfig, type WriteConfig } from '@0xintuition/protocol'

function getReadConfig(chainId: number, publicClient: PublicClient): ReadConfig {
  return {
    address: getMultiVaultAddressFromChainId(chainId),
    publicClient,
  }
}

function getWriteConfig(chainId: number, publicClient: PublicClient, walletClient: WalletClient): WriteConfig {
  return {
    address: getMultiVaultAddressFromChainId(chainId),
    publicClient,
    walletClient,
  }
}
```

For a standalone script, you can also hardcode the address:

```ts
const MULTIVAULT_ADDRESS: Address = '0x2Ece8D4dEdcB9918A398528f3fa4688b1d2CAB91'

const readConfig: ReadConfig = {
  address: MULTIVAULT_ADDRESS,
  publicClient,
}
```

## Read Operations (Free, No Wallet)

### Cost Queries

```ts
import { multiVaultGetAtomCost, multiVaultGetTripleCost } from '@0xintuition/protocol'

const atomCost = await multiVaultGetAtomCost(readConfig)     // bigint (wei)
const tripleCost = await multiVaultGetTripleCost(readConfig)  // bigint (wei)
```

### Atom Reads

```ts
import { multiVaultGetAtom, multiVaultIsTermCreated } from '@0xintuition/protocol'

// Check if a term (atom or triple) exists on-chain
const exists = await multiVaultIsTermCreated(readConfig, { args: [termId] })
// Returns: boolean

// Get an atom's raw data by its term ID
const atomData = await multiVaultGetAtom(readConfig, { args: [termId] })
// Returns: Hex (the raw bytes stored for this atom)
```

### Triple Reads

```ts
import {
  multiVaultGetTriple,
  multiVaultIsTriple,
  multiVaultGetInverseTripleId,
  multiVaultIsCounterTriple,
} from '@0xintuition/protocol'

// Get a triple's components
const [subjectId, predicateId, objectId] = await multiVaultGetTriple(readConfig, { args: [tripleId] })

// Check if a term ID is a triple
const isTriple = await multiVaultIsTriple(readConfig, { args: [termId] })

// Get the inverse (AGAINST) triple ID
const inverseId = await multiVaultGetInverseTripleId(readConfig, { args: [tripleId] })

// Check if a term ID is a counter-triple (the AGAINST side)
const isCounter = await multiVaultIsCounterTriple(readConfig, { args: [termId] })
```

### Vault Reads

```ts
import {
  multiVaultGetVault,
  multiVaultGetShares,
  multiVaultCurrentSharePrice,
  multiVaultConvertToAssets,
  multiVaultConvertToShares,
  multiVaultMaxRedeem,
} from '@0xintuition/protocol'

// Get vault totals (TVL)
const [totalShares, totalAssets] = await multiVaultGetVault(readConfig, {
  args: [termId, curveId],
})

// Get a specific account's shares in a vault
const shares = await multiVaultGetShares(readConfig, {
  args: [accountAddress, termId, curveId],
})

// Get the current share price
const price = await multiVaultCurrentSharePrice(readConfig, {
  args: [termId, curveId],
})

// Convert between shares and assets
const assets = await multiVaultConvertToAssets(readConfig, {
  args: [termId, curveId, shares],
})
const shares = await multiVaultConvertToShares(readConfig, {
  args: [termId, curveId, assets],
})

// Check max redeemable shares for an account
const maxShares = await multiVaultMaxRedeem(readConfig, {
  args: [sender, termId, curveId],
})
```

### Preview Operations

```ts
import {
  multiVaultPreviewDeposit,
  multiVaultPreviewRedeem,
  multiVaultPreviewAtomCreate,
} from '@0xintuition/protocol'

// Preview a deposit — see shares you'd receive
const [shares, assetsAfterFees] = await multiVaultPreviewDeposit(writeConfig, {
  args: [termId, curveId, assets],
})

// Preview a redemption — see assets you'd get back
const [assetsAfterFees, sharesUsed] = await multiVaultPreviewRedeem(writeConfig, {
  args: [termId, curveId, shares],
})

// Preview atom creation — see vault state after creation
const [shares, assetsAfterFixedFees, assetsAfterFees] = await multiVaultPreviewAtomCreate(writeConfig, {
  args: [termId, assets],
})
```

### Fee Queries

```ts
import {
  multiVaultEntryFeeAmount,
  multiVaultExitFeeAmount,
  multiVaultProtocolFeeAmount,
} from '@0xintuition/protocol'

const entryFee = await multiVaultEntryFeeAmount(readConfig, { args: [assets] })
const exitFee = await multiVaultExitFeeAmount(readConfig, { args: [assets] })
const protocolFee = await multiVaultProtocolFeeAmount(readConfig, { args: [assets] })
```

### Config Queries

```ts
import {
  multiVaultGetAtomConfig,
  multiVaultGetTripleConfig,
  multiVaultGetGeneralConfig,
} from '@0xintuition/protocol'

const atomConfig = await multiVaultGetAtomConfig(readConfig)
const tripleConfig = await multiVaultGetTripleConfig(readConfig)
const generalConfig = await multiVaultGetGeneralConfig(readConfig)
```

## Write Operations (Require Wallet + Tokens)

All write operations return a transaction hash (`Hex`). Use event parsers to extract structured results.

### Creating Atoms

```ts
import { multiVaultCreateAtoms, multiVaultGetAtomCost } from '@0xintuition/protocol'
import { toHex } from 'viem'

// 1. Get the cost
const atomCost = await multiVaultGetAtomCost(readConfig)

// 2. Encode atom data as hex
const atomData = toHex('TypeScript')

// 3. Submit the transaction
const txHash = await multiVaultCreateAtoms(writeConfig, {
  args: [[atomData], [atomCost]],  // arrays — supports batch
  value: atomCost,                  // total value sent
})
```

**Batch creation** — create multiple atoms in one transaction:

```ts
const atoms = ['TypeScript', 'Rust', 'Python']
const encodedAtoms = atoms.map(text => toHex(text))
const costs = encodedAtoms.map(() => atomCost)
const totalCost = costs.reduce((sum, c) => sum + c, 0n)

const txHash = await multiVaultCreateAtoms(writeConfig, {
  args: [encodedAtoms, costs],
  value: totalCost,
})
```

### Creating Triples

```ts
import { multiVaultCreateTriples, multiVaultGetTripleCost } from '@0xintuition/protocol'

// 1. Get the cost
const tripleCost = await multiVaultGetTripleCost(readConfig)

// 2. Submit with subject, predicate, object term IDs
const txHash = await multiVaultCreateTriples(writeConfig, {
  args: [
    [subjectTermId],    // subject term IDs (Hex[])
    [predicateTermId],  // predicate term IDs (Hex[])
    [objectTermId],     // object term IDs (Hex[])
    [tripleCost],       // deposit per triple (bigint[])
  ],
  value: tripleCost,
})
```

**Batch creation:**

```ts
const txHash = await multiVaultCreateTriples(writeConfig, {
  args: [
    [subject1, subject2],
    [predicate1, predicate2],
    [object1, object2],
    [tripleCost, tripleCost],
  ],
  value: tripleCost * 2n,
})
```

### Depositing (Staking)

```ts
import { multiVaultDeposit, multiVaultDepositBatch } from '@0xintuition/protocol'

// Single deposit
const txHash = await multiVaultDeposit(writeConfig, {
  args: [receiver, termId, curveId, minShares],
  value: depositAmount,
})

// Batch deposit across multiple vaults
const txHash = await multiVaultDepositBatch(writeConfig, {
  args: [receiver, termIds, curveIds, amounts, minSharesArray],
  value: totalAmount,
})
```

### Redeeming (Unstaking)

```ts
import { multiVaultRedeem, multiVaultRedeemBatch } from '@0xintuition/protocol'

// Single redeem
const txHash = await multiVaultRedeem(writeConfig, {
  args: [receiver, termId, curveId, shares, minAssets],
})

// Batch redeem
const txHash = await multiVaultRedeemBatch(writeConfig, {
  args: [receiver, termIds, curveIds, sharesArray, minAssetsArray],
})
```

## Event Parsers

After a write transaction, use event parsers to extract structured results from the transaction receipt.

```ts
import {
  eventParseAtomCreated,
  eventParseTripleCreated,
  eventParseDeposited,
  eventParseRedeemed,
} from '@0xintuition/protocol'

// Parse atom creation events
const events = await eventParseAtomCreated(publicClient, txHash)
// Returns: Array<{ args: { creator, termId, atomData, atomWallet } }>

// Parse triple creation events
const events = await eventParseTripleCreated(publicClient, txHash)
// Returns: Array<{ args: { creator, termId, subjectId, predicateId, objectId } }>

// Parse deposit events
const events = await eventParseDeposited(publicClient, txHash)
// Returns: Array<{ args: { sender, receiver, termId, curveId, assets, shares, assetsAfterFees } }>

// Parse redeem events
const events = await eventParseRedeemed(publicClient, txHash)
// Returns: Array<{ args: { sender, receiver, termId, curveId, shares, assetsAfterFees } }>
```

### The Write Flow Pattern

Every write operation follows the same pattern:

```
1. Get cost       → multiVaultGetAtomCost / multiVaultGetTripleCost
2. Encode data    → toHex('string') for atoms, term IDs for triples
3. Submit tx      → multiVaultCreateAtoms / multiVaultCreateTriples / multiVaultDeposit
4. Parse events   → eventParseAtomCreated / eventParseTripleCreated / eventParseDeposited
```

## GraphQL — The Read Layer

For rich queries (search, lists, positions, metadata), use the Intuition GraphQL API. The protocol package handles on-chain reads; GraphQL handles indexed/aggregated data.

### Endpoint

```
Testnet: https://testnet.intuition.sh/v1/graphql
Mainnet: https://intuition.sh/v1/graphql
```

### Client Setup

```ts
import { GraphQLClient } from 'graphql-request'

const graphqlClient = new GraphQLClient('https://testnet.intuition.sh/v1/graphql')
```

### Common Queries

```graphql
# Search atoms by label or data
query SearchAtoms($search: String!, $limit: Int = 8) {
  atoms(
    where: { _or: [
      { label: { _ilike: $search } },
      { data: { _ilike: $search } },
      { term_id: { _eq: $search } }
    ]}
    limit: $limit
    order_by: { block_timestamp: desc }
  ) {
    term_id
    label
    data
    block_timestamp
    creator { label id }
    vault { total_shares total_assets current_share_price }
  }
}

# Get a single atom by term ID
query GetAtom($termId: String!) {
  atom(term_id: $termId) {
    term_id
    label
    data
    creator { label id }
    vault { total_shares total_assets current_share_price }
  }
}

# Get items in a curated list (triples with a specific predicate)
query GetListItems($listId: String!, $predicateId: String!) {
  triples(
    where: {
      subject_id: { _eq: $listId }
      predicate_id: { _eq: $predicateId }
    }
  ) {
    term_id
    subject { term_id label }
    predicate { term_id label }
    object { term_id label }
    vault { total_shares total_assets }
    counter_vault { total_shares total_assets }
  }
}

# Get a user's positions across vaults
query GetUserPositions($address: String!) {
  positions(where: { account_id: { _eq: $address } }) {
    term_id
    shares
    atom { term_id label }
    triple { term_id subject { label } predicate { label } object { label } }
  }
}
```

### When to Use Each Layer

| Need | Use |
|------|-----|
| Create atoms, triples, deposit, redeem | Protocol package (on-chain writes) |
| Read costs, vault state, share prices | Protocol package (on-chain reads) |
| Search atoms/triples by text | GraphQL |
| List items, curated lists | GraphQL |
| User positions, history | GraphQL |
| Atom/triple metadata with labels | GraphQL |

The two layers complement each other: the protocol package gives you direct contract access (real-time, authoritative), while GraphQL gives you indexed, queryable views of the same data with richer metadata.

## Common Constants

```ts
const DEFAULT_CURVE_ID = 1n       // Default bonding curve
const DEFAULT_MIN_SHARES = 0n     // No minimum shares on deposit
const DEFAULT_MIN_ASSETS = 0n     // No minimum assets on redeem
```

## Quick Reference

```
Package:            @0xintuition/protocol
Chain export:       intuitionTestnet (chain ID 13579)
Address helper:     getMultiVaultAddressFromChainId(chainId)
Read config:        { address, publicClient }
Write config:       { address, publicClient, walletClient }
Native token:       tTRUST (testnet) / TRUST (mainnet)
GraphQL (testnet):  https://testnet.intuition.sh/v1/graphql
Explorer:           https://testnet.explorer.intuition.systems
```
