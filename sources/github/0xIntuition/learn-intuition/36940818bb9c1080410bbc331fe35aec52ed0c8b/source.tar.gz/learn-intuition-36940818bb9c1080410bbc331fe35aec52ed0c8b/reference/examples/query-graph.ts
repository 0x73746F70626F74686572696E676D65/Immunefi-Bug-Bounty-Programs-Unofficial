/**
 * Intuition Protocol — Querying the Knowledge Graph
 *
 * Two complementary read layers:
 * 1. On-chain reads (multiVaultGet*) — direct contract queries, real-time
 * 2. GraphQL — indexed data with search, labels, metadata, positions
 *
 * On-chain reads are free (no wallet needed). GraphQL queries are also free.
 */

import {
  multiVaultGetAtom,
  multiVaultGetAtomCost,
  multiVaultGetTriple,
  multiVaultGetTripleCost,
  multiVaultGetVault,
  multiVaultCurrentSharePrice,
  multiVaultPreviewDeposit,
  multiVaultIsTermCreated,
} from '@0xintuition/protocol'
import { fromHex, type Hex } from 'viem'
import { readConfig } from './setup'

// ─── 1. On-Chain Reads (Protocol Package) ──────────────────────────
// Direct contract queries — authoritative, real-time

// Read protocol costs
const atomCost = await multiVaultGetAtomCost(readConfig)
const tripleCost = await multiVaultGetTripleCost(readConfig)
console.log('Protocol costs:', { atomCost, tripleCost })

// Check if a term exists
const termId = '0x...' as Hex // replace with a real term ID
const exists = await multiVaultIsTermCreated(readConfig, { args: [termId] })
console.log('Term exists:', exists)

// Read atom data
if (exists) {
  const atomData = await multiVaultGetAtom(readConfig, { args: [termId] })
  const decoded = fromHex(atomData as Hex, 'string')
  console.log('Atom data:', decoded)
}

// Read vault state (TVL, shares)
const curveId = 1n
const [totalShares, totalAssets] = await multiVaultGetVault(readConfig, {
  args: [termId, curveId],
})
console.log('Vault state:', { totalShares, totalAssets })

// Get current share price
const price = await multiVaultCurrentSharePrice(readConfig, {
  args: [termId, curveId],
})
console.log('Share price:', price)

// ─── 2. GraphQL Queries (Indexed Data) ─────────────────────────────
// For search, lists, positions, and metadata — use the GraphQL API

const GRAPHQL_ENDPOINT = 'https://testnet.intuition.sh/v1/graphql'

// Simple fetch-based GraphQL client
async function queryGraphql<T>(query: string, variables?: Record<string, unknown>): Promise<T> {
  const response = await fetch(GRAPHQL_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables }),
  })
  const json = await response.json()
  return json.data as T
}

// ─── 2a. Search Atoms ──────────────────────────────────────────────

const SEARCH_ATOMS = `
  query SearchAtoms($search: String!, $limit: Int = 8) {
    atoms(
      where: { _or: [
        { label: { _ilike: $search } },
        { data: { _ilike: $search } }
      ]}
      limit: $limit
      order_by: { block_timestamp: desc }
    ) {
      term_id
      label
      data
      creator { label id }
      vault { total_shares total_assets current_share_price }
    }
  }
`

type SearchResult = {
  atoms: Array<{
    term_id: string
    label: string | null
    data: string
    creator: { label: string | null; id: string }
    vault: { total_shares: string; total_assets: string; current_share_price: string }
  }>
}

const searchResults = await queryGraphql<SearchResult>(SEARCH_ATOMS, {
  search: '%ethereum%',
  limit: 5,
})

console.log('Search results for "ethereum":')
for (const atom of searchResults.atoms) {
  console.log(`  [${atom.term_id}] ${atom.label ?? atom.data}`)
}

// ─── 2b. Get a Single Atom ─────────────────────────────────────────

const GET_ATOM = `
  query GetAtom($termId: String!) {
    atom(term_id: $termId) {
      term_id
      label
      data
      creator { label id }
      vault { total_shares total_assets current_share_price }
    }
  }
`

// ─── 2c. Get User Positions ────────────────────────────────────────

const GET_USER_POSITIONS = `
  query GetUserPositions($address: String!) {
    positions(where: { account_id: { _eq: $address } }) {
      term_id
      shares
      atom { term_id label }
      triple {
        term_id
        subject { label }
        predicate { label }
        object { label }
      }
    }
  }
`

// ─── 2d. Get Curated List Items ────────────────────────────────────
// Curated lists use the "has tag" predicate pattern:
// [item] -[has_tag]-> [list]

const GET_LIST_ITEMS = `
  query GetListItems($listId: String!, $predicateId: String!) {
    triples(
      where: {
        object_id: { _eq: $listId }
        predicate_id: { _eq: $predicateId }
      }
    ) {
      term_id
      subject { term_id label }
      predicate { term_id label }
      object { term_id label }
      vault { total_shares total_assets }
      counter_vault { total_shares total_assets }
    }
  }
`

// ─── 3. When to Use Each Layer ─────────────────────────────────────
//
// Protocol package (on-chain reads):
//   - Costs: multiVaultGetAtomCost, multiVaultGetTripleCost
//   - Vault state: multiVaultGetVault, multiVaultGetShares
//   - Share prices: multiVaultCurrentSharePrice
//   - Previews: multiVaultPreviewDeposit, multiVaultPreviewRedeem
//   - Raw data: multiVaultGetAtom, multiVaultGetTriple
//   - Existence: multiVaultIsTermCreated, multiVaultIsTriple
//
// GraphQL (indexed reads):
//   - Search: text search across atoms/triples
//   - Lists: curated lists, list items
//   - Positions: user's positions across vaults
//   - Metadata: labels, creator info, timestamps
//   - Aggregations: sorted by TVL, activity, etc.
