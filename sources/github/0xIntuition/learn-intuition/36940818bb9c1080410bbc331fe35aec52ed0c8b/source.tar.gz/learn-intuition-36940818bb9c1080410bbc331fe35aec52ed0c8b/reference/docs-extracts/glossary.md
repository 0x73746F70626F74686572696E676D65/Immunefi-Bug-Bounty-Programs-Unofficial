# Intuition Glossary — Reference

> Curated from Intuition docs for course accuracy. Source: https://docs.intuition.systems

## Core Primitives

| Term | Definition |
|------|-----------|
| **Atom** | A unique decentralized identifier for any entity, concept, or piece of data. The fundamental building block of the knowledge graph. |
| **Triple** | A structured statement connecting three atoms in [Subject]-[Predicate]-[Object] format. The fundamental unit of claims. |
| **Signal** | The weight of trust or conviction expressed through staking on atoms or triples. |

## Triple Components

| Term | Definition |
|------|-----------|
| **Subject** | The first component of a triple — the entity being described. |
| **Predicate** | The middle component — the relationship connecting subject to object. |
| **Object** | The third component — what is being claimed about the subject. |
| **Nested Triple** | A triple that uses another triple as one of its components, enabling multi-layered claims. |
| **Counter-Triple** | A triple that opposes another triple (e.g., [X] [is safe] [false] vs [X] [is safe] [true]). |

## Staking & Vaults

| Term | Definition |
|------|-----------|
| **Vault** | An on-chain smart contract holding staked assets for a specific atom or triple. |
| **Vault Shares** | Tokens representing proportional ownership in a vault's assets. Issued on deposit, burned on redemption. |
| **Vault ID** | The unique identifier for a vault, derived from the corresponding atom or triple ID. |
| **Deposit** | Staking tokens into a vault to signal support. Returns vault shares. |
| **Redemption** | Withdrawing staked tokens by burning vault shares. Subject to exit fees. |
| **TVL (Total Value Locked)** | The total amount staked in a vault. Primary measure of conviction. |
| **Bonding Curve** | Mathematical function determining vault share price based on supply. More stakers = higher price. |

## Economics

| Term | Definition |
|------|-----------|
| **Token-Curated Graph (TCG)** | Intuition's economic model where token staking curates and validates knowledge. |
| **Creator Fee** | Fee paid to the creator of an atom or triple when others interact with it. |
| **Entry Fee** | Fee charged when depositing into a vault. |
| **Exit Fee** | Fee charged when redeeming from a vault. |
| **Protocol Fee** | Fee collected by the protocol on various operations. |
| **Wrapped Trust** | ERC-20 tokens representing staked vault positions, making them transferable. |

## Network & Technical

| Term | Definition |
|------|-----------|
| **TRUST** | The native token of Intuition Network. $TRUST (mainnet), $tTRUST (testnet). |
| **MultiVault** | The core smart contract managing all atoms, triples, and vaults. Central registry and vault factory. |
| **Atom Wallet** | A smart contract wallet associated with each atom, giving it agency to own assets. |
| **Atom Data** | The arbitrary data stored in an atom (URI, text, JSON, IPFS hash, etc.). |
| **DID (Decentralized Identifier)** | W3C standard for decentralized identities. Atoms can serve as DIDs. |
| **Knowledge Graph** | The interconnected network of atoms (nodes) and triples (edges) forming Intuition's data layer. |
| **Layer 3 (L3)** | Intuition's blockchain layer, built on Base using Arbitrum Orbit. |
| **RDF** | Resource Description Framework — W3C standard for semantic data. Intuition triples are RDF-compatible. |
| **Attestation** | A verifiable claim made on-chain using triples, supported or opposed through signals. |
| **BondingCurveRegistry** | Contract managing available bonding curve types (Linear, OffsetProgressive). |
| **TrustBonding** | Contract for locking wTRUST into veTRUST (voting escrow). |
| **veTRUST** | Vote-escrowed TRUST — governance weight earned by locking wTRUST. |
| **MCP Server** | Model Context Protocol server enabling AI agents to query the knowledge graph. |
| **Portal** | Web interface for exploring the knowledge graph at `portal.intuition.systems`. |
| **Faucet** | Testnet token dispenser at `testnet.hub.intuition.systems` (0.1 $tTRUST daily). |

## Signal Types

| Term | Definition |
|------|-----------|
| **Explicit Signal** | Intentional actions: voting, staking, signed attestations. |
| **Implicit Signal** | Indirect indicators: query frequency, usage patterns, inclusion in triples. |
| **Transitive Signal** | Trust passed through relationship networks (A trusts B, B trusts C → A extends trust to C). |
