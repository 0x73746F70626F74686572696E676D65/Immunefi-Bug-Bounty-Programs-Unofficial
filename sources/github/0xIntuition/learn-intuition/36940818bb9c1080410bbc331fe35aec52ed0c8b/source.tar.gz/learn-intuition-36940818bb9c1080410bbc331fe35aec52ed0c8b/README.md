# Learn Intuition

An interactive course that teaches the [Intuition](https://intuition.systems) protocol inside [Claude Code](https://claude.ai/claude-code).

## What You'll Learn

**Part 1: Understanding the Knowledge Graph** (Lessons 00-04)
- What Intuition is and why it matters
- Atoms — universal decentralized identifiers
- Triples — semantic relationships that form the knowledge graph
- Signals — staking, conviction, and bonding curves

**Part 2: Building with the Protocol** (Lessons 05-08)
- Protocol package setup and testnet connection
- Creating atoms and triples programmatically
- Querying the knowledge graph (on-chain + GraphQL)
- Reading vault state and signal data

**Part 3: Building Real Applications** (Lessons 09-11)
- Navigating the Intuition ecosystem
- Context engineering for AI-assisted development
- Capstone project: build a real Intuition app from tiered templates

## Getting Started

1. Install [Claude Code](https://claude.ai/claude-code) if you haven't already
2. Clone this repo and navigate to it:
   ```bash
   git clone <repo-url>
   cd learn-intuition
   ```
3. Start Claude Code:
   ```bash
   claude
   ```
4. Run the course:
   ```
   /learn
   ```

## Commands

| Command | What it does |
|---------|-------------|
| `/learn` | Show course dashboard |
| `/learn next` | Start the next lesson |
| `/learn progress` | View your progress stats |
| `/learn reset` | Reset progress to start over |
| `/learn 00`-`11` | Jump to a specific lesson |

## Inspired By

[learn-claude-code](https://github.com/delbaoliveira/learn-claude-code) by Delba de Oliveira — an 11-lesson interactive course that teaches Claude Code by building a game inside it. We took that model and applied it to teaching a web3 protocol.

## About Intuition

[Intuition](https://intuition.systems) is a protocol for creating a decentralized knowledge graph. It uses three primitives — Atoms, Triples, and Signals — to let anyone create, connect, and stake on structured knowledge on-chain.

- [Docs](https://docs.intuition.systems)
- [Portal](https://portal.intuition.systems)
- [Discord](https://discord.gg/RgBenkX4mx)
