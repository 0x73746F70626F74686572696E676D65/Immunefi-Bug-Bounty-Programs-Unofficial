import type { Skill, Vault, TrustSignal, SafetySignal, SafetyStatus, Triple, TripleVaultData } from '~/types'
import { TRUST_TIER_THRESHOLDS } from '~/types'
import { findPlatformById } from './platforms'
import { findCapabilityById } from './capabilities'
import { formatWeiToEth, safeSharePrice } from '~/lib/vault-utils'

/**
 * Helper: Create skill vault with FOR/AGAINST dynamics
 */
function createSkillVault(
  termId: string,
  forCount: number,
  againstCount: number,
  forEth: number,
  againstEth: number
): Vault {
  const ONE = 10n ** 18n
  const totalAssets = BigInt(Math.floor((forEth + againstEth) * 1e18))
  const totalShares = BigInt(forCount + againstCount) * ONE
  const currentSharePrice = totalAssets > 0n && totalShares > 0n
    ? ((totalAssets * ONE) / totalShares).toString()
    : ONE.toString()

  return {
    term_id: termId,
    curve_id: '0xcurve_linear',
    total_shares: totalShares.toString(),
    current_share_price: currentSharePrice,
    total_assets: totalAssets.toString(),
    market_cap: totalAssets.toString(),
    position_count: forCount + againstCount,
  }
}

/**
 * Helper: Create safety signal from FOR/AGAINST ratio
 */
function createSafetySignal(
  forCount: number,
  againstCount: number,
  forEth: number,
  againstEth: number,
  flagReason?: string
): SafetySignal {
  const totalEth = forEth + againstEth
  const safetyRatio = totalEth > 0 ? forEth / totalEth : 0

  let status: SafetyStatus = 'unverified'
  if (againstEth > forEth) {
    status = 'flagged'
  } else if (forEth > 0) {
    status = 'verified'
  }

  return {
    status,
    forCount,
    againstCount,
    forStake: forEth.toFixed(4),
    againstStake: againstEth.toFixed(4),
    safetyRatio,
    flagReason,
  }
}

/**
 * Helper: Compute trust signal from vault and all vaults for percentile
 */
function createTrustSignal(vault: Vault, allVaults: Vault[]): TrustSignal {
  const totalAssets = BigInt(vault.total_assets)

  const countBelow = allVaults.filter(v => BigInt(v.total_assets) < totalAssets).length
  const percentile = Math.round((countBelow / allVaults.length) * 100)

  let tier: 'platinum' | 'gold' | 'silver' | 'bronze' | 'unranked' = 'unranked'
  if (percentile >= TRUST_TIER_THRESHOLDS.platinum) tier = 'platinum'
  else if (percentile >= TRUST_TIER_THRESHOLDS.gold) tier = 'gold'
  else if (percentile >= TRUST_TIER_THRESHOLDS.silver) tier = 'silver'
  else if (percentile >= TRUST_TIER_THRESHOLDS.bronze) tier = 'bronze'

  const totalStaked = formatWeiToEth(vault.total_assets)
  const sharePrice = formatWeiToEth(safeSharePrice(vault), 6)
  const marketCap = formatWeiToEth(vault.market_cap)

  return {
    stakerCount: vault.position_count,
    totalStaked,
    sharePrice,
    tier,
    percentile,
    marketCap,
  }
}

/**
 * Helper: Create has-capability triple
 */
function createMockTripleVault(): TripleVaultData {
  const forAssets = Math.floor(Math.random() * 900 + 100) * 1e15
  const againstAssets = Math.floor(Math.random() * 200) * 1e15
  return {
    forVault: {
      total_assets: String(forAssets),
      position_count: Math.floor(Math.random() * 15) + 1,
      current_share_price: String(1e18 + Math.floor(Math.random() * 1e17)),
    },
    againstVault: againstAssets > 0
      ? {
          total_assets: String(againstAssets),
          position_count: Math.floor(Math.random() * 5) + 1,
          current_share_price: String(1e18 + Math.floor(Math.random() * 5e16)),
        }
      : undefined,
  }
}

function createProvidesCapabilityTriple(skillId: string, skillName: string, capabilityId: string): Triple {
  const capability = findCapabilityById(capabilityId)
  if (!capability) throw new Error(`Capability ${capabilityId} not found`)

  return {
    term_id: `${skillId}_has_cap_${capabilityId}`,
    counter_term_id: `${capabilityId}_has_cap_${skillId}_counter`,
    subject: { term_id: skillId, label: skillName, type: 'Skill' },
    predicate: { term_id: '0xpred_has_capability', label: 'has-capability', type: 'Thing' },
    object: { term_id: capabilityId, label: capability.name, type: 'Capability' },
    created_at: new Date().toISOString(),
    creator_id: '0xsystem',
    vault: createMockTripleVault(),
  }
}

/**
 * MOCK_SKILLS — 18 skills across 5 platforms with pathological cases
 */

const skillDataList = [
  // MCP Skills (7)
  {
    id: '0xskill_001',
    name: 'Filesystem MCP',
    description: 'Read and write files through Model Context Protocol',
    platformId: 'mcp',
    capabilityIds: ['file-management'],
    permissions: ['filesystem'],
    forCount: 120,
    againstCount: 5,
    forEth: 45,
    againstEth: 1.2,
    version: '1.3.0',
    author: 'Anthropic',
    installUri: 'npx @modelcontextprotocol/server-filesystem',
  },
  {
    id: '0xskill_002',
    name: 'Web Fetch MCP',
    description: 'HTTP requests and web scraping via MCP',
    platformId: 'mcp',
    capabilityIds: ['web-search', 'api-integration'],
    permissions: ['network'],
    forCount: 98,
    againstCount: 3,
    forEth: 38,
    againstEth: 0.8,
    version: '1.2.1',
    author: 'Anthropic',
    installUri: 'npx @modelcontextprotocol/server-fetch',
  },
  {
    id: '0xskill_003',
    name: 'Database MCP',
    description: 'Execute SQL queries through MCP interface',
    platformId: 'mcp',
    capabilityIds: ['database-ops'],
    permissions: ['network', 'env'],
    forCount: 76,
    againstCount: 2,
    forEth: 28,
    againstEth: 0.5,
    version: '2.0.0',
    author: 'Anthropic',
    installUri: 'npx @modelcontextprotocol/server-postgres',
  },
  {
    id: '0xskill_004',
    name: 'Git MCP',
    description: 'Git operations via Model Context Protocol',
    platformId: 'mcp',
    capabilityIds: ['code-generation', 'file-management'],
    permissions: ['filesystem', 'network'],
    forCount: 142,
    againstCount: 8,
    forEth: 52,
    againstEth: 2.1,
    version: '1.1.0',
    author: 'MCP Community',
    installUri: 'npx @modelcontextprotocol/server-git',
  },
  {
    id: '0xskill_005',
    name: 'Slack MCP',
    description: 'Send and read Slack messages via MCP',
    platformId: 'mcp',
    capabilityIds: ['api-integration'],
    permissions: ['network', 'env'],
    forCount: 65,
    againstCount: 1,
    forEth: 22,
    againstEth: 0.3,
    version: '1.0.2',
    author: 'MCP Community',
    installUri: 'npx @modelcontextprotocol/server-slack',
  },
  {
    id: '0xskill_006',
    name: 'Shell Execute MCP',
    description: 'Execute arbitrary shell commands (dangerous)',
    platformId: 'mcp',
    capabilityIds: ['system-monitoring', 'deployment'],
    permissions: ['filesystem', 'network', 'env', 'exec'],
    forCount: 30,
    againstCount: 85,
    forEth: 12,
    againstEth: 62,
    flagReason: 'Dangerous permissions: arbitrary command execution. High risk of system compromise.',
    version: '0.9.0',
    author: 'Unknown',
    installUri: 'npx shell-execute-mcp',
  },
  {
    id: '0xskill_007',
    name: 'Crypto Wallet MCP',
    description: 'Manage crypto wallets and sign transactions',
    platformId: 'mcp',
    capabilityIds: ['wallet-management'],
    permissions: ['network', 'env'],
    forCount: 42,
    againstCount: 18,
    forEth: 18,
    againstEth: 8,
    version: '1.2.0',
    author: 'Web3 Labs',
    installUri: 'npx @web3labs/wallet-mcp',
  },

  // Claude Code Skills (5)
  {
    id: '0xskill_008',
    name: 'Code Review Skill',
    description: 'Automated code review with best practices',
    platformId: 'claude-code',
    capabilityIds: ['code-review'],
    permissions: ['filesystem'],
    forCount: 88,
    againstCount: 2,
    forEth: 34,
    againstEth: 0.6,
    version: '2.1.0',
    author: 'Anthropic',
  },
  {
    id: '0xskill_009',
    name: 'Deploy Pipeline',
    description: 'CI/CD deployment automation',
    platformId: 'claude-code',
    capabilityIds: ['deployment'],
    permissions: ['filesystem', 'network', 'exec'],
    forCount: 71,
    againstCount: 5,
    forEth: 26,
    againstEth: 1.5,
    version: '1.5.3',
    author: 'DevOps Team',
  },
  {
    id: '0xskill_010',
    name: 'Test Runner',
    description: 'Execute test suites and generate coverage reports',
    platformId: 'claude-code',
    capabilityIds: ['code-generation'],
    permissions: ['filesystem', 'exec'],
    forCount: 95,
    againstCount: 3,
    forEth: 38,
    againstEth: 0.9,
    version: '3.0.1',
    author: 'Testing Guild',
  },
  {
    id: '0xskill_011',
    name: 'PR Creator',
    description: 'Automated pull request creation and management',
    platformId: 'claude-code',
    capabilityIds: ['code-review', 'api-integration'],
    permissions: ['filesystem', 'network'],
    forCount: 103,
    againstCount: 4,
    forEth: 41,
    againstEth: 1.2,
    version: '1.8.0',
    author: 'GitHub Tools',
  },
  {
    id: '0xskill_012',
    name: 'Commit Helper',
    description: 'Generate conventional commit messages',
    platformId: 'claude-code',
    capabilityIds: ['code-generation'],
    permissions: ['filesystem'],
    forCount: 67,
    againstCount: 1,
    forEth: 24,
    againstEth: 0.3,
    version: '1.3.2',
    author: 'Git Tools',
  },

  // OpenClaw Skills (3)
  {
    id: '0xskill_013',
    name: 'Market Analyzer',
    description: 'DeFi market analysis and arbitrage detection',
    platformId: 'openclaw',
    capabilityIds: ['data-analysis', 'defi-protocols'],
    permissions: ['network'],
    forCount: 54,
    againstCount: 2,
    forEth: 19,
    againstEth: 0.6,
    version: '2.3.0',
    author: 'ClawdBot Team',
    installUri: 'https://openclaw.xyz/skills/market-analyzer',
  },
  {
    id: '0xskill_014',
    name: 'NFT Minter',
    description: 'Automated NFT minting and collection management',
    platformId: 'openclaw',
    capabilityIds: ['nft-analysis'],
    permissions: ['network', 'wallet'],
    forCount: 12,
    againstCount: 48,
    forEth: 4.5,
    againstEth: 38,
    flagReason: 'Multiple scam reports. Unauthorized wallet access. Collection rug-pulls linked to this tool.',
    version: '1.0.5',
    author: 'Anonymous',
    installUri: 'https://openclaw.xyz/skills/nft-minter',
  },
  {
    id: '0xskill_015',
    name: 'Token Scanner',
    description: 'Real-time token launch and liquidity tracking',
    platformId: 'openclaw',
    capabilityIds: ['onchain-data'],
    permissions: ['network'],
    forCount: 0,
    againstCount: 0,
    forEth: 0,
    againstEth: 0,
    version: '0.1.0',
    author: 'Scanner Labs',
    installUri: 'https://openclaw.xyz/skills/token-scanner',
  },

  // OpenAI Skills (2)
  {
    id: '0xskill_016',
    name: 'Web Browser Tool',
    description: 'Browse and interact with web pages',
    platformId: 'openai',
    capabilityIds: ['web-search'],
    permissions: ['network'],
    forCount: 156,
    againstCount: 7,
    forEth: 58,
    againstEth: 2.1,
    version: '1.0.0',
    author: 'OpenAI',
  },
  {
    id: '0xskill_017',
    name: 'Code Interpreter',
    description: 'Execute Python code in sandboxed environment',
    platformId: 'openai',
    capabilityIds: ['data-analysis', 'code-generation'],
    permissions: ['sandbox'],
    forCount: 198,
    againstCount: 5,
    forEth: 72,
    againstEth: 1.5,
    version: '2.0.0',
    author: 'OpenAI',
  },

  // Custom Skills (1)
  {
    id: '0xskill_018',
    name: 'Private API Bridge',
    description: 'Connect to proprietary internal APIs',
    platformId: 'custom',
    capabilityIds: ['api-integration'],
    permissions: ['network', 'env', 'auth'],
    forCount: 2,
    againstCount: 0,
    forEth: 0.8,
    againstEth: 0,
    version: '1.0.0',
    author: 'Enterprise Team',
  },
]

// Step 1: Create vaults for all skills
const allSkillVaults = skillDataList.map(data =>
  createSkillVault(data.id, data.forCount, data.againstCount, data.forEth, data.againstEth)
)

// Step 2: Create full Skill objects with trust signals, safety signals, and triples
export const MOCK_SKILLS: Skill[] = skillDataList.map((data, index) => {
  const vault = allSkillVaults[index]
  const trustSignal = createTrustSignal(vault, allSkillVaults)
  const safetySignal = createSafetySignal(
    data.forCount,
    data.againstCount,
    data.forEth,
    data.againstEth,
    data.flagReason
  )

  const platform = findPlatformById(data.platformId)
  if (!platform) throw new Error(`Platform ${data.platformId} not found`)

  const capabilities = data.capabilityIds
    .map(id => findCapabilityById(id))
    .filter(c => c !== undefined)

  // Create has-capability triples (permissions are metadata-only, not triples)
  const providesCapabilityTriples = data.capabilityIds.map(capId =>
    createProvidesCapabilityTriple(data.id, data.name, capId)
  )

  const createdAt = data.id === '0xskill_015' // Token Scanner is brand new
    ? new Date().toISOString()
    : new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000).toISOString()

  return {
    id: data.id,
    metadata: {
      name: data.name,
      description: data.description,
      version: data.version,
      author: data.author,
      installUri: data.installUri,
      permissions: data.permissions,
      createdAt,
    },
    platform,
    capabilities,
    vault,
    trustSignal,
    safetySignal,
    triples: [...providesCapabilityTriples],
  }
})

/**
 * Helper functions for querying skill relationships
 */

export function getSkillsForAgent(_agentId: string, agentTriples: Triple[]): Skill[] {
  const skillIds = agentTriples
    .filter(t => t.predicate.label === 'uses')
    .map(t => t.object.term_id)

  return MOCK_SKILLS.filter(skill => skillIds.includes(skill.id))
}

export function getAgentsForSkill(_skillId: string): string[] {
  // This will be populated from agents.ts after cross-referencing
  // For now, return empty array
  return []
}

export function getRelationships(entityId: string, predicateId?: string): Triple[] {
  const skill = MOCK_SKILLS.find(s => s.id === entityId)
  if (!skill) return []

  if (predicateId) {
    return skill.triples.filter(t => t.predicate.label === predicateId)
  }

  return skill.triples
}
