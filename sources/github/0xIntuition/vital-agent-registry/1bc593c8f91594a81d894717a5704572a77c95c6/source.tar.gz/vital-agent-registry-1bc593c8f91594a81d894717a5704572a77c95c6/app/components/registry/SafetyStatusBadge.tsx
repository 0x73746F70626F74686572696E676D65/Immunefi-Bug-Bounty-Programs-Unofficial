import type { SafetyStatus } from '~/types'
import { cn } from '~/lib/utils'
import { ShieldAlert } from 'lucide-react'

interface SafetyStatusBadgeProps {
  status: SafetyStatus
  flagReason?: string
  size?: 'sm' | 'md'
  className?: string
}

const statusConfig: Record<SafetyStatus, { bg: string; text: string; label: string }> = {
  verified: {
    bg: 'hsl(142 71% 45%)',
    text: 'hsl(142 71% 45%)',
    label: 'Verified',
  },
  unverified: {
    bg: 'hsl(38 92% 50%)',
    text: 'hsl(38 92% 50%)',
    label: 'Unverified',
  },
  flagged: {
    bg: 'hsl(0 84% 60%)',
    text: 'hsl(0 84% 60%)',
    label: 'Flagged',
  },
}

export function SafetyStatusBadge({
  status,
  flagReason,
  size = 'md',
  className
}: SafetyStatusBadgeProps) {
  const config = statusConfig[status]
  const isFlagged = status === 'flagged'

  const sizeClasses = size === 'sm'
    ? 'text-[10px] px-1.5 py-0.5'
    : 'text-xs px-2 py-0.5'

  const iconSize = size === 'sm' ? 10 : 12

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-[var(--radius-badge)] font-medium uppercase tracking-wider',
        sizeClasses,
        isFlagged && 'animate-pulse',
        className,
      )}
      style={{
        backgroundColor: `color-mix(in srgb, ${config.bg} 15%, transparent)`,
        color: config.text,
        border: isFlagged ? `1px solid ${config.text}` : undefined,
      }}
      title={flagReason || undefined}
    >
      {isFlagged && <ShieldAlert size={iconSize} />}
      {config.label}
    </span>
  )
}
