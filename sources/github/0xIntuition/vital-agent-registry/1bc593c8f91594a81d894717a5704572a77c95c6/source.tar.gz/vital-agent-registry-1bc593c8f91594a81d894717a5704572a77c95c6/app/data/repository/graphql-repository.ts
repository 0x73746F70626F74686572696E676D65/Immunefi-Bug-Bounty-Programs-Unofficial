import type {
  RegistryRepository,
  SearchOptions,
  ListOptions,
  MatchOptions,
  PaginatedResult,
  Agent,
  AgentCard,
  AgentMetadata,
  Skill,
  SkillMetadata,
  Capability,
  PredicateDefinition,
  Platform,
  TrustSignal,
  SortField,
  Vault,
  EntityType,
} from '~/types'
import { TRUST_TIER_ORDER } from '~/types'
import { serverGraphqlRequest } from '~/lib/graphql/client'
import {
  mapAtomToAgent,
  mapAtomToSkill,
  type GraphQLAgentsResponse,
  type GraphQLSkillsResponse,
  type GraphQLSearchResponse,
  type GraphQLSkillsForAgentResponse,
  type GraphQLAtom,
  type GraphQLVault,
} from '~/lib/graphql/mappers'
import { sanitizeWeiString } from '~/lib/vault-utils'

/** Static platform fallback for cold start (before bootstrap creates on-chain atoms) */
const STATIC_PLATFORMS: Platform[] = [
  { id: 'mcp', name: 'Model Context Protocol', description: 'Model Context Protocol standard for AI tool connectivity' },
  { id: 'claude-code', name: 'Claude Code Skills', description: 'Custom skills for Claude Code CLI' },
  { id: 'openclaw', name: 'OpenClaw', description: 'Open marketplace for AI agent tools' },
  { id: 'openai', name: 'OpenAI Functions', description: 'Function calling and tools for OpenAI models' },
  { id: 'x402', name: 'x402', description: 'HTTP 402-based micropayment protocol for AI services' },
  { id: 'custom', name: 'Custom', description: 'Custom or proprietary skill integration' },
]

/** Sanitize all BigInt string fields from a GraphQL vault response */
function sanitizeGraphQLVault(vault: GraphQLVault): Vault {
  return {
    term_id: vault.term_id,
    curve_id: vault.curve_id,
    total_shares: sanitizeWeiString(vault.total_shares),
    current_share_price: sanitizeWeiString(vault.current_share_price),
    total_assets: sanitizeWeiString(vault.total_assets),
    market_cap: sanitizeWeiString(vault.market_cap),
    position_count: vault.position_count ?? 0,
  }
}

// Import queries (will be read from .graphql files)
const GET_REGISTRY_AGENTS = `
  query GetRegistryAgents($limit: Int, $offset: Int, $orderBy: [atoms_order_by!]) {
    total: atoms_aggregate(
      where: {
        as_subject_triples: {
          predicate: { label: { _eq: "is" } }
          object: { label: { _eq: "Agent" } }
        }
      }
    ) {
      aggregate { count }
    }
    atoms(
      where: {
        as_subject_triples: {
          predicate: { label: { _eq: "is" } }
          object: { label: { _eq: "Agent" } }
        }
      }
      limit: $limit
      offset: $offset
      order_by: $orderBy
    ) {
      term_id label image cached_image { url safe } type data created_at
      creator { id label image cached_image { url safe } }
      value {
        thing { name description image cached_image { url safe } url }
        json_object { name: data(path: "name") description: data(path: "description") }
      }
      term {
        total_market_cap
        positions_aggregate { aggregate { count } }
        vaults(order_by: { curve_id: asc }) {
          term_id curve_id current_share_price total_shares total_assets position_count market_cap
        }
      }
      as_subject_triples(
        where: {
          predicate: {
            label: { _in: ["has-capability", "uses", "has-metadata", "created-by"] }
          }
        }
      ) {
        term_id
        predicate { term_id label }
        object {
          term_id label image cached_image { url safe } type data
          value {
            thing { name description image url }
            json_object { name: data(path: "name") description: data(path: "description") }
          }
        }
      }
    }
  }
`

const GET_REGISTRY_AGENT = `
  query GetRegistryAgent($termId: String!) {
    atom(term_id: $termId) {
      term_id label image cached_image { url safe } type data created_at updated_at
      creator { id label image cached_image { url safe } }
      value {
        thing { name description image cached_image { url safe } url }
        json_object { name: data(path: "name") description: data(path: "description") }
      }
      term {
        total_market_cap
        positions_aggregate { aggregate { count } }
        vaults(order_by: { curve_id: asc }) {
          term_id curve_id current_share_price total_shares total_assets position_count market_cap
        }
      }
      as_subject_triples {
        term_id counter_term_id
        predicate { term_id label }
        object {
          term_id label image cached_image { url safe } type data
          value {
            thing { name description image url }
            json_object { name: data(path: "name") description: data(path: "description") }
          }
        }
        term {
          vaults(order_by: { curve_id: asc }) {
            term_id curve_id current_share_price total_shares total_assets position_count market_cap
          }
        }
      }
    }
  }
`

const SEARCH_AGENTS = `
  query SearchAgents($searchTerm: String!, $limit: Int) {
    atoms(
      where: {
        _and: [
          { _or: [{ label: { _ilike: $searchTerm } }, { data: { _ilike: $searchTerm } }] }
          {
            as_subject_triples: {
              predicate: { label: { _eq: "is" } }
              object: { label: { _eq: "Agent" } }
            }
          }
        ]
      }
      limit: $limit
      order_by: [{ term: { total_market_cap: desc_nulls_last } }]
    ) {
      term_id label image cached_image { url safe } type data created_at
      value { thing { name description image url } }
      term {
        total_market_cap
        vaults(order_by: { curve_id: asc }) {
          term_id curve_id current_share_price total_shares total_assets position_count market_cap
        }
      }
      as_subject_triples(
        where: { predicate: { label: { _in: ["has-capability", "uses"] } } }
      ) {
        predicate { term_id label }
        object { term_id label image type }
      }
    }
  }
`

interface GraphQLRepositoryConfig {
  apiUrl: string
  chain: 'testnet' | 'mainnet' | 'local'
}

/**
 * Cache entry with TTL
 */
interface CacheEntry<T> {
  data: T
  expiresAt: number
}

const CACHE_TTL_MS = 5 * 60 * 1000 // 5 minutes

/**
 * Query to get has-metadata triples for an entity with vault data
 */
const GET_METADATA_TRIPLES = `
  query GetMetadataTriples($subjectId: String!, $predicateLabel: String!) {
    triples(
      where: {
        subject_id: { _eq: $subjectId }
        predicate: { label: { _eq: $predicateLabel } }
      }
      order_by: { created_at: desc }
    ) {
      term_id
      created_at
      object {
        term_id
        label
        image
        cached_image { url safe }
        type
        data
        created_at
        updated_at
        value {
          thing { name description image url }
          json_object { name: data(path: "name") description: data(path: "description") }
        }
        term {
          vaults(order_by: { curve_id: asc }) {
            term_id
            curve_id
            current_share_price
            total_shares
            total_assets
            position_count
            market_cap
          }
        }
      }
    }
  }
`

export class GraphQLRegistryRepository implements RegistryRepository {
  private apiUrl: string
  private chain: 'testnet' | 'mainnet' | 'local'
  private metadataCache: Map<string, CacheEntry<AgentMetadata | SkillMetadata | null>> = new Map()

  constructor(config: GraphQLRepositoryConfig) {
    this.apiUrl = config.apiUrl
    this.chain = config.chain
  }

  // --- Agent methods ---

  async findAgent(id: string): Promise<Agent | null> {
    const response = await serverGraphqlRequest<{ atom: GraphQLAtom | null }>(
      this.apiUrl,
      GET_REGISTRY_AGENT,
      { termId: id },
    )

    if (!response.atom) return null

    // Get all agent vaults for trust calculation
    const allVaults = await this.getAllAgentVaults()
    return mapAtomToAgent(response.atom, allVaults)
  }

  async searchAgents(query: string, options?: SearchOptions): Promise<Agent[]> {
    const searchTerm = `%${query}%`
    const limit = options?.limit ?? 20

    const response = await serverGraphqlRequest<GraphQLSearchResponse>(
      this.apiUrl,
      SEARCH_AGENTS,
      { searchTerm, limit },
    )

    const allVaults = await this.getAllAgentVaults()
    let agents = response.atoms.map((atom) => mapAtomToAgent(atom, allVaults))

    // Apply filters
    agents = this.applyAgentFilters(agents, options)

    // Apply sorting
    agents = this.sortAgents(agents, options?.sortBy ?? 'trust')

    return agents
  }

  async listAgents(options?: ListOptions): Promise<PaginatedResult<Agent>> {
    const limit = options?.limit ?? 20
    const offset = options?.offset ?? 0
    const orderBy = this.buildOrderBy(options?.sortBy ?? 'trust')

    const response = await serverGraphqlRequest<GraphQLAgentsResponse>(
      this.apiUrl,
      GET_REGISTRY_AGENTS,
      { limit, offset, orderBy },
    )

    const allVaults = await this.getAllAgentVaults()
    let agents = response.atoms.map((atom) => mapAtomToAgent(atom, allVaults))

    // Apply filters
    agents = this.applyAgentFilters(agents, options)

    // Apply sorting
    agents = this.sortAgents(agents, options?.sortBy ?? 'trust')

    const total = response.total.aggregate.count
    return {
      items: agents,
      total,
      hasMore: offset + limit < total,
    }
  }

  async matchAgentCapabilities(
    required: string[],
    options?: MatchOptions,
  ): Promise<Agent[]> {
    const matchAll = options?.matchAll ?? true

    // Get all agents
    const response = await serverGraphqlRequest<GraphQLAgentsResponse>(
      this.apiUrl,
      GET_REGISTRY_AGENTS,
      { limit: 1000, offset: 0 },
    )

    const allVaults = await this.getAllAgentVaults()
    const agents = response.atoms.map((atom) => mapAtomToAgent(atom, allVaults))

    // Filter by capability match
    let filtered = agents.filter((agent) => {
      const agentCapIds = agent.capabilities.map((c) => c.id)
      if (matchAll) {
        return required.every((req) => agentCapIds.includes(req))
      }
      return required.some((req) => agentCapIds.includes(req))
    })

    // Filter by trust tier if provided
    if (options?.minTrustTier) {
      const minTierLevel = TRUST_TIER_ORDER[options.minTrustTier]
      filtered = filtered.filter(
        (a) => TRUST_TIER_ORDER[a.trustSignal.tier] >= minTierLevel,
      )
    }

    // Sort by match score (number of matching caps) then trust
    filtered.sort((a, b) => {
      const aMatches = a.capabilities.filter((c) => required.includes(c.id)).length
      const bMatches = b.capabilities.filter((c) => required.includes(c.id)).length
      if (aMatches !== bMatches) return bMatches - aMatches
      return b.trustSignal.percentile - a.trustSignal.percentile
    })

    return filtered.slice(0, options?.limit ?? filtered.length)
  }

  async getAgentCard(id: string): Promise<AgentCard | null> {
    const agent = await this.findAgent(id)
    if (!agent) return null
    if (!agent.metadata.endpoint) return null

    // Build A2A-compliant agent card
    return {
      id: agent.id,
      name: agent.metadata.name,
      description: agent.metadata.description,
      url: agent.metadata.endpoint || '',
      provider: agent.metadata.provider || { name: 'Unknown' },
      version: agent.metadata.version,
      capabilities: {
        streaming: false,
        pushNotifications: false,
        extendedAgentCard: true,
      },
      skills: agent.capabilities.map((cap) => ({
        id: cap.id,
        name: cap.name,
        description: cap.description,
        inputModes: ['text/plain'],
        outputModes: ['text/plain'],
      })),
      securitySchemes: {
        unauthenticated: {
          type: 'http',
          description: 'No additional authentication required for discovery endpoints',
        },
      },
      security: [{ unauthenticated: [] }],
      interfaces: [
        {
          protocol: 'http',
          url: agent.metadata.endpoint,
        },
      ],
      defaultInputModes: ['text/plain', 'application/json'],
      defaultOutputModes: ['text/plain', 'application/json'],
      extensions: [
        {
          uri: 'https://registry.intuition.systems/extensions/intuition',
          atomId: agent.id,
          vaultTermId: agent.vault.term_id,
          trustTier: agent.trustSignal.tier,
          registryUrl: 'https://registry.intuition.systems',
          chainId: this.chain === 'local' ? 31337 : this.chain === 'testnet' ? 13579 : 1155,
        },
      ],
    }
  }

  async getAgentTrust(id: string): Promise<TrustSignal | null> {
    const agent = await this.findAgent(id)
    return agent?.trustSignal ?? null
  }

  // --- Skill methods ---

  async findSkill(id: string): Promise<Skill | null> {
    const GET_SKILL = `
      query GetRegistrySkill($termId: String!) {
        atom(term_id: $termId) {
          term_id label image cached_image { url safe } type data created_at updated_at
          creator { id label image }
          value {
            thing { name description image cached_image { url safe } url }
            json_object { name: data(path: "name") description: data(path: "description") }
          }
          term {
            total_market_cap
            positions_aggregate { aggregate { count } }
            vaults(order_by: { curve_id: asc }) {
              term_id curve_id current_share_price total_shares total_assets position_count market_cap
            }
          }
          as_subject_triples {
            term_id counter_term_id
            predicate { term_id label }
            object {
              term_id label image cached_image { url safe } type data
              value {
                thing { name description image url }
                json_object { name: data(path: "name") description: data(path: "description") }
              }
            }
            term {
              vaults(order_by: { curve_id: asc }) {
                term_id curve_id current_share_price total_shares total_assets position_count market_cap
              }
            }
          }
        }
      }
    `

    const response = await serverGraphqlRequest<{ atom: GraphQLAtom | null }>(
      this.apiUrl,
      GET_SKILL,
      { termId: id },
    )

    if (!response.atom) return null

    const allVaults = await this.getAllSkillVaults()
    return mapAtomToSkill(response.atom, allVaults)
  }

  async searchSkills(query: string, options?: SearchOptions): Promise<Skill[]> {
    const SEARCH_SKILLS = `
      query SearchSkills($searchTerm: String!, $limit: Int) {
        atoms(
          where: {
            _and: [
              { _or: [{ label: { _ilike: $searchTerm } }, { data: { _ilike: $searchTerm } }] }
              {
                as_subject_triples: {
                  predicate: { label: { _eq: "is" } }
                  object: { label: { _eq: "Skill" } }
                }
              }
            ]
          }
          limit: $limit
          order_by: [{ term: { total_market_cap: desc_nulls_last } }]
        ) {
          term_id label image cached_image { url safe } type data created_at
          value { thing { name description image url } }
          term {
            total_market_cap
            vaults(order_by: { curve_id: asc }) {
              term_id curve_id current_share_price total_shares total_assets position_count market_cap
            }
          }
          as_subject_triples(
            where: { predicate: { label: { _in: ["has-capability"] } } }
          ) {
            term_id counter_term_id
            predicate { term_id label }
            object { term_id label image type }
            term {
              vaults(order_by: { curve_id: asc }) {
                term_id curve_id total_assets position_count
              }
            }
          }
        }
      }
    `

    const searchTerm = `%${query}%`
    const limit = options?.limit ?? 20

    const response = await serverGraphqlRequest<GraphQLSearchResponse>(
      this.apiUrl,
      SEARCH_SKILLS,
      { searchTerm, limit },
    )

    const allVaults = await this.getAllSkillVaults()
    let skills = response.atoms.map((atom) => mapAtomToSkill(atom, allVaults))

    // Apply filters
    skills = this.applySkillFilters(skills, options)

    // Apply sorting
    skills = this.sortSkills(skills, options?.sortBy ?? 'trust')

    return skills
  }

  async listSkills(options?: ListOptions): Promise<PaginatedResult<Skill>> {
    const GET_SKILLS = `
      query GetRegistrySkills($limit: Int, $offset: Int, $orderBy: [atoms_order_by!]) {
        total: atoms_aggregate(
          where: {
            as_subject_triples: {
              predicate: { label: { _eq: "is" } }
              object: { label: { _eq: "Skill" } }
            }
          }
        ) {
          aggregate { count }
        }
        atoms(
          where: {
            as_subject_triples: {
              predicate: { label: { _eq: "is" } }
              object: { label: { _eq: "Skill" } }
            }
          }
          limit: $limit
          offset: $offset
          order_by: $orderBy
        ) {
          term_id label image cached_image { url safe } type data created_at updated_at
          creator { id label image }
          value {
            thing { name description image cached_image { url safe } url }
            json_object { name: data(path: "name") description: data(path: "description") }
          }
          term {
            total_market_cap
            positions_aggregate { aggregate { count } }
            vaults(order_by: { curve_id: asc }) {
              term_id curve_id current_share_price total_shares total_assets position_count market_cap
            }
          }
          as_subject_triples(
            where: {
              predicate: {
                label: { _in: ["has-capability"] }
              }
            }
          ) {
            term_id counter_term_id
            predicate { term_id label }
            object {
              term_id label image cached_image { url safe } type data
              value {
                thing { name description image url }
                json_object { name: data(path: "name") description: data(path: "description") }
              }
            }
            term {
              vaults(order_by: { curve_id: asc }) {
                term_id curve_id current_share_price total_shares total_assets position_count market_cap
              }
            }
          }
        }
      }
    `

    const limit = options?.limit ?? 20
    const offset = options?.offset ?? 0
    const orderBy = this.buildOrderBy(options?.sortBy ?? 'trust')

    const response = await serverGraphqlRequest<GraphQLSkillsResponse>(
      this.apiUrl,
      GET_SKILLS,
      { limit, offset, orderBy },
    )

    const allVaults = await this.getAllSkillVaults()
    let skills = response.atoms.map((atom) => mapAtomToSkill(atom, allVaults))

    // Apply filters
    skills = this.applySkillFilters(skills, options)

    // Apply sorting
    skills = this.sortSkills(skills, options?.sortBy ?? 'trust')

    const total = response.total.aggregate.count
    return {
      items: skills,
      total,
      hasMore: offset + limit < total,
    }
  }

  async getSkillsByPlatform(platformId: string): Promise<Skill[]> {
    // v3: Platform is in metadata JSON, not a triple.
    // Fetch all skills and filter by metadata-derived platform.
    const result = await this.listSkills({ limit: 1000 })
    return result.items.filter((s) => s.platform.id === platformId)
  }

  async getSkillsForAgent(agentId: string): Promise<Skill[]> {
    const GET_AGENT_SKILLS = `
      query GetSkillsForAgent($agentId: String!) {
        triples(
          where: {
            subject_id: { _eq: $agentId }
            predicate: { label: { _eq: "uses" } }
          }
        ) {
          object {
            term_id label image cached_image { url safe } type data created_at
            value { thing { name description image url } }
            term {
              total_market_cap
              vaults(order_by: { curve_id: asc }) {
                term_id curve_id current_share_price total_shares total_assets position_count market_cap
              }
            }
            as_subject_triples(
              where: {
                predicate: { label: { _in: ["has-capability"] } }
              }
            ) {
              term_id counter_term_id
              predicate { term_id label }
              object { term_id label image type }
              term {
                vaults(order_by: { curve_id: asc }) {
                  term_id curve_id total_assets position_count
                }
              }
            }
          }
        }
      }
    `

    const response = await serverGraphqlRequest<GraphQLSkillsForAgentResponse>(
      this.apiUrl,
      GET_AGENT_SKILLS,
      { agentId },
    )

    const allVaults = await this.getAllSkillVaults()
    return response.triples.map((triple) => mapAtomToSkill(triple.object, allVaults))
  }

  async getSkillTrust(id: string): Promise<TrustSignal | null> {
    const skill = await this.findSkill(id)
    return skill?.trustSignal ?? null
  }

  // --- Metadata resolution ---

  async resolveCurrentMetadata(
    entityType: EntityType,
    entityId: string,
  ): Promise<AgentMetadata | SkillMetadata | null> {
    const cacheKey = `${entityType}:${entityId}`

    // Check cache first
    const cached = this.metadataCache.get(cacheKey)
    if (cached && cached.expiresAt > Date.now()) {
      return cached.data
    }

    // Determine the predicate label based on entity type
    const predicateLabel = entityType === 'agent' ? 'has-metadata' : 'has-metadata'

    try {
      const response = await serverGraphqlRequest<{
        triples: Array<{
          term_id: string
          created_at: string
          object: GraphQLAtom
        }>
      }>(
        this.apiUrl,
        GET_METADATA_TRIPLES,
        { subjectId: entityId, predicateLabel },
      )

      const triples = response.triples

      if (!triples || triples.length === 0) {
        // No metadata found - cache null
        this.metadataCache.set(cacheKey, {
          data: null,
          expiresAt: Date.now() + CACHE_TTL_MS,
        })
        return null
      }

      // Get FOR vault balances for each metadata atom
      const metadataWithStake = triples.map((triple) => {
        const metadata = extractMetadataFromAtom(triple.object, entityType)
        const vault = extractMetadataVault(triple.object)
        const forStake = vault?.curve_id === '1'
          ? BigInt(vault.total_assets || '0')
          : 0n

        return {
          metadata,
          triple,
          forStake,
          createdAt: triple.created_at,
        }
      })

      // Find metadata with highest FOR stake
      let currentMetadata = metadataWithStake.reduce<{
        metadata: AgentMetadata | SkillMetadata
        forStake: bigint
        createdAt: string
      } | null>((best, current) => {
        if (!best) {
          return current.forStake > 0n ? current : null
        }
        if (current.forStake > best.forStake) {
          return current
        }
        return best
      }, null)

      // Fallback to most recent if no stakes
      if (!currentMetadata) {
        // Sort by created_at descending
        const sorted = [...metadataWithStake].sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
        )
        currentMetadata = sorted[0] || null
      }

      const result = currentMetadata?.metadata ?? null

      // Cache the result
      this.metadataCache.set(cacheKey, {
        data: result,
        expiresAt: Date.now() + CACHE_TTL_MS,
      })

      return result
    } catch (error) {
      console.error('Failed to resolve current metadata:', error)
      return null
    }
  }

  // --- Shared metadata ---

  async listCapabilities(): Promise<Capability[]> {
    const GET_CAPABILITIES = `
      query GetCapabilities {
        atoms(
          where: {
            as_subject_triples: {
              predicate: { label: { _eq: "is" } }
              object: { label: { _eq: "Capability" } }
            }
          }
          order_by: [{ label: asc }]
        ) {
          term_id label data
          value {
            thing { name description }
            json_object { name: data(path: "name") description: data(path: "description") }
          }
        }
      }
    `

    const response = await serverGraphqlRequest<GraphQLSearchResponse>(
      this.apiUrl,
      GET_CAPABILITIES,
      {},
    )

    return response.atoms.map((atom) => {
      const parsedData = atom.data ? tryParseJSON(atom.data) : null
      return {
        id: atom.term_id,
        name: atom.value?.thing?.name || atom.value?.json_object?.name || atom.label,
        category: (parsedData?.category as string) || 'automation',
        description:
          atom.value?.thing?.description ||
          atom.value?.json_object?.description ||
          (parsedData?.description as string) ||
          '',
      }
    })
  }

  async listPredicates(): Promise<PredicateDefinition[]> {
    // Return canonical predicates (hard-coded for now, can be fetched from protocol later)
    return [
      {
        id: 'is',
        label: 'is',
        description: 'Entity type classification',
        subjectTypes: ['Agent', 'Skill'],
        objectTypes: ['Agent', 'Skill'],
      },
      {
        id: 'has-capability',
        label: 'has-capability',
        description: 'Entity has a capability',
        subjectTypes: ['Agent', 'Skill'],
        objectTypes: ['Capability'],
      },
      {
        id: 'uses',
        label: 'uses',
        description: 'Agent uses a skill',
        subjectTypes: ['Agent'],
        objectTypes: ['Skill'],
      },
      {
        id: 'has-metadata',
        label: 'has-metadata',
        description: 'Entity has versioned metadata',
        subjectTypes: ['Agent', 'Skill'],
        objectTypes: ['Thing'],
      },
      {
        id: 'created-by',
        label: 'created-by',
        description: 'Entity creator attribution',
        subjectTypes: ['Agent', 'Skill'],
        objectTypes: ['Person', 'Organization'],
      },
    ]
  }

  async listPlatforms(): Promise<Platform[]> {
    const GET_PLATFORMS = `
      query GetPlatforms {
        atoms(
          where: {
            as_subject_triples: {
              predicate: { label: { _eq: "is" } }
              object: { label: { _eq: "Platform" } }
            }
          }
          order_by: [{ label: asc }]
        ) {
          term_id label data image cached_image { url safe }
          value {
            thing { name description image url }
            json_object { name: data(path: "name") description: data(path: "description") }
          }
        }
      }
    `

    const response = await serverGraphqlRequest<GraphQLSearchResponse>(
      this.apiUrl,
      GET_PLATFORMS,
      {},
    )

    const platforms = response.atoms.map((atom) => {
      const parsedData = atom.data ? tryParseJSON(atom.data) : null
      return {
        id: (atom.label.toLowerCase() as Platform['id']) || 'custom',
        name: atom.value?.thing?.name || atom.value?.json_object?.name || atom.label,
        description:
          atom.value?.thing?.description ||
          atom.value?.json_object?.description ||
          (parsedData?.description as string) ||
          '',
        icon: atom.value?.thing?.image || atom.cached_image?.url || atom.image || undefined,
        url: atom.value?.thing?.url || (parsedData?.url as string) || undefined,
      }
    })

    // Cold start fallback: return static platforms if none bootstrapped yet
    if (platforms.length === 0) {
      return STATIC_PLATFORMS
    }

    return platforms
  }

  // --- Private helper methods ---

  private async getAllAgentVaults(): Promise<Vault[]> {
    const response = await serverGraphqlRequest<GraphQLAgentsResponse>(
      this.apiUrl,
      GET_REGISTRY_AGENTS,
      { limit: 10000, offset: 0 },
    )

    return response.atoms
      .map((atom) => {
        const vault = atom.term?.vaults?.find((v) => v.curve_id === '1') || atom.term?.vaults?.[0]
        return vault ? sanitizeGraphQLVault(vault) : null
      })
      .filter((v): v is Vault => v !== null)
  }

  private async getAllSkillVaults(): Promise<Vault[]> {
    // Similar to getAllAgentVaults but for skills
    const GET_ALL_SKILLS = `
      query GetAllSkills {
        atoms(
          where: {
            as_subject_triples: {
              predicate: { label: { _eq: "is" } }
              object: { label: { _eq: "Skill" } }
            }
          }
          limit: 10000
        ) {
          term_id
          term {
            vaults(order_by: { curve_id: asc }) {
              term_id curve_id current_share_price total_shares total_assets position_count market_cap
            }
          }
        }
      }
    `

    const response = await serverGraphqlRequest<GraphQLSearchResponse>(
      this.apiUrl,
      GET_ALL_SKILLS,
      {},
    )

    return response.atoms
      .map((atom) => {
        const vault = atom.term?.vaults?.find((v) => v.curve_id === '1') || atom.term?.vaults?.[0]
        return vault ? sanitizeGraphQLVault(vault) : null
      })
      .filter((v): v is Vault => v !== null)
  }

  private applyAgentFilters(agents: Agent[], options?: ListOptions | SearchOptions): Agent[] {
    let filtered = agents

    // Type guard for ListOptions
    const isListOptions = (opts: ListOptions | SearchOptions): opts is ListOptions => {
      return 'capability' in opts || 'trustTier' in opts
    }

    if (options && isListOptions(options)) {
      if (options.capability) {
        filtered = filtered.filter((a) => a.capabilities.some((c) => c.id === options.capability))
      }

      if (options.trustTier) {
        filtered = filtered.filter((a) => a.trustSignal.tier === options.trustTier)
      }
    }

    // SearchOptions has minTrustTier instead of trustTier
    if (options && 'minTrustTier' in options && options.minTrustTier) {
      const minTierLevel = TRUST_TIER_ORDER[options.minTrustTier]
      filtered = filtered.filter((a) => TRUST_TIER_ORDER[a.trustSignal.tier] >= minTierLevel)
    }

    // SearchOptions has capabilities array
    if (options && 'capabilities' in options && options.capabilities && options.capabilities.length > 0) {
      filtered = filtered.filter((a) =>
        options.capabilities!.some((reqCap) => a.capabilities.some((c) => c.id === reqCap)),
      )
    }

    return filtered
  }

  private applySkillFilters(skills: Skill[], options?: ListOptions | SearchOptions): Skill[] {
    let filtered = skills

    if (options?.platformId) {
      filtered = filtered.filter((s) => s.platform.id === options.platformId)
    }

    // Type guard for ListOptions
    const isListOptions = (opts: ListOptions | SearchOptions): opts is ListOptions => {
      return 'capability' in opts || 'trustTier' in opts
    }

    if (options && isListOptions(options)) {
      if (options.capability) {
        filtered = filtered.filter((s) => s.capabilities.some((c) => c.id === options.capability))
      }

      if (options.trustTier) {
        filtered = filtered.filter((s) => s.trustSignal.tier === options.trustTier)
      }
    }

    // SearchOptions has capabilities array
    if (options && 'capabilities' in options && options.capabilities && options.capabilities.length > 0) {
      filtered = filtered.filter((s) =>
        options.capabilities!.some((reqCap) => s.capabilities.some((c) => c.id === reqCap)),
      )
    }

    return filtered
  }

  private sortAgents(agents: Agent[], sortBy: SortField): Agent[] {
    const sorted = [...agents]

    switch (sortBy) {
      case 'trust':
        sorted.sort((a, b) => b.trustSignal.percentile - a.trustSignal.percentile)
        break
      case 'name':
        sorted.sort((a, b) => a.metadata.name.localeCompare(b.metadata.name))
        break
      case 'recent':
        sorted.sort(
          (a, b) =>
            new Date(b.metadata.createdAt).getTime() - new Date(a.metadata.createdAt).getTime(),
        )
        break
      case 'stakers':
        sorted.sort((a, b) => b.trustSignal.stakerCount - a.trustSignal.stakerCount)
        break
      default:
        // Default to trust
        sorted.sort((a, b) => b.trustSignal.percentile - a.trustSignal.percentile)
    }

    return sorted
  }

  private sortSkills(skills: Skill[], sortBy: SortField): Skill[] {
    const sorted = [...skills]

    switch (sortBy) {
      case 'trust':
        sorted.sort((a, b) => b.trustSignal.percentile - a.trustSignal.percentile)
        break
      case 'name':
        sorted.sort((a, b) => a.metadata.name.localeCompare(b.metadata.name))
        break
      case 'recent':
        sorted.sort(
          (a, b) =>
            new Date(b.metadata.createdAt).getTime() - new Date(a.metadata.createdAt).getTime(),
        )
        break
      case 'stakers':
        sorted.sort((a, b) => b.trustSignal.stakerCount - a.trustSignal.stakerCount)
        break
      case 'safety':
        sorted.sort((a, b) => b.safetySignal.safetyRatio - a.safetySignal.safetyRatio)
        break
      default:
        sorted.sort((a, b) => b.trustSignal.percentile - a.trustSignal.percentile)
    }

    return sorted
  }

  private buildOrderBy(sortBy: SortField): Record<string, unknown>[] {
    switch (sortBy) {
      case 'trust':
        return [{ term: { total_market_cap: 'desc_nulls_last' } }]
      case 'name':
        return [{ label: 'asc' }]
      case 'recent':
        return [{ created_at: 'desc' }]
      case 'stakers':
        return [{ term: { positions_aggregate: { count: 'desc' } } }]
      default:
        return [{ term: { total_market_cap: 'desc_nulls_last' } }]
    }
  }
}

/**
 * Try to parse JSON, return null on failure.
 */
function tryParseJSON(json: string): Record<string, unknown> | null {
  try {
    return JSON.parse(json)
  } catch {
    return null
  }
}

/**
 * Extract metadata from a GraphQL atom for the given entity type.
 */
function extractMetadataFromAtom(
  atom: GraphQLAtom,
  entityType: EntityType,
): AgentMetadata | SkillMetadata {
  const thing = atom.value?.thing
  const jsonObject = atom.value?.json_object

  // Try to parse JSON from data field
  let parsedData: Record<string, unknown> | null = null
  if (atom.data) {
    parsedData = tryParseJSON(atom.data)
  }

  const name = thing?.name || jsonObject?.name || (parsedData?.name as string) || atom.label
  const description =
    thing?.description ||
    jsonObject?.description ||
    (parsedData?.description as string) ||
    ''
  const image = thing?.image || atom.cached_image?.url || atom.image || undefined

  const createdAt = atom.created_at || new Date().toISOString()
  const updatedAt = atom.updated_at || undefined

  if (entityType === 'agent') {
    const version = (parsedData?.version as string) || '1.0.0'
    const model = (parsedData?.model as string) || undefined
    const endpoint = (parsedData?.endpoint as string) || undefined
    const metadataUri = (parsedData?.metadataUri as string) ||
      (parsedData?.metadata_uri as string) ||
      (typeof thing?.url === 'string' && thing.url.startsWith('ipfs://') ? thing.url : undefined) ||
      undefined
    const tags = (parsedData?.tags as string[]) || []
    const provider = parsedData?.provider
      ? {
          name: (parsedData.provider as Record<string, unknown>).name as string,
          url: (parsedData.provider as Record<string, unknown>).url as string | undefined,
        }
      : undefined
    const longDescription = (parsedData?.longDescription as string) || undefined

    return {
      name,
      description,
      longDescription,
      image,
      version,
      model,
      endpoint,
      metadataUri,
      provider,
      tags,
      createdAt,
      lastActiveAt: updatedAt,
    }
  } else {
    // Skill metadata
    const version = (parsedData?.version as string) || '1.0.0'
    const author = (parsedData?.author as string) || undefined
    const installUri = (parsedData?.installUri as string) ||
      (parsedData?.install_uri as string) ||
      (typeof thing?.url === 'string' ? thing.url : undefined)
    const metadataUri = (parsedData?.metadataUri as string) ||
      (parsedData?.metadata_uri as string) ||
      undefined
    const permissions = (parsedData?.permissions as string[]) || []
    const longDescription = (parsedData?.longDescription as string) ||
      (parsedData?.long_description as string) ||
      undefined

    return {
      name,
      description,
      longDescription,
      image,
      version,
      author,
      installUri,
      metadataUri,
      permissions,
      createdAt,
      updatedAt,
    }
  }
}

/**
 * Extract FOR vault from a metadata atom.
 * Returns the vault with curve_id = '1' (FOR vault), or first vault if not found.
 */
function extractMetadataVault(atom: GraphQLAtom): GraphQLVault | null {
  const vaults = atom.term?.vaults
  if (!vaults || vaults.length === 0) return null

  // Prefer curve_id 1 (FOR vault), otherwise take first
  return vaults.find((v) => v.curve_id === '1') || vaults[0]
}
