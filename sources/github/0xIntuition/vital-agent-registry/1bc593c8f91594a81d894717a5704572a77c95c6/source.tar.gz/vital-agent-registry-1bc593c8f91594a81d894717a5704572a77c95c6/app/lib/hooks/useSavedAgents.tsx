import { createContext, useContext, useState, useCallback } from 'react'
import type { ReactNode } from 'react'

interface SavedAgentsContextValue {
  savedIds: Set<string>
  toggleAgent: (id: string) => void
  isAgentSaved: (id: string) => boolean
}

const SavedAgentsContext = createContext<SavedAgentsContextValue | null>(null)

export function SavedAgentsProvider({ children }: { children: ReactNode }) {
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set())

  const toggleAgent = useCallback((id: string) => {
    setSavedIds((prev) => {
      const next = new Set(prev)
      if (next.has(id)) {
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
  }, [])

  const isAgentSaved = useCallback((id: string) => savedIds.has(id), [savedIds])

  return (
    <SavedAgentsContext.Provider value={{ savedIds, toggleAgent, isAgentSaved }}>
      {children}
    </SavedAgentsContext.Provider>
  )
}

export function useSavedAgents() {
  const ctx = useContext(SavedAgentsContext)
  if (!ctx) throw new Error('useSavedAgents must be used within SavedAgentsProvider')
  return ctx
}
