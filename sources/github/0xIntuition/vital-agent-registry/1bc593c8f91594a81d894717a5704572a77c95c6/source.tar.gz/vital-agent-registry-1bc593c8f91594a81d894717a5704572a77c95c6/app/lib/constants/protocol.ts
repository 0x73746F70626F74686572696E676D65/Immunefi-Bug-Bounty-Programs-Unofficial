/**
 * Protocol constants for the Intuition Agent Registry v3.
 * These term_ids will be populated by the bootstrap script.
 *
 * v3 Model: 5 core predicates (Option C versioning)
 * - is: Universal stakeable claim (FOR/AGAINST)
 * - has-capability: Entity possesses this capability
 * - uses: Agent uses this tool/skill
 * - has-metadata: Entity has this metadata (versioned)
 * - created-by: Entity was created by this agent/user
 */

/** Predicate atom term_ids (populated by bootstrap) */
export const PREDICATES = {
  IS: '0x_placeholder_is',
  HAS_CAPABILITY: '0x_placeholder_has_capability',
  USES: '0x_placeholder_uses',
  HAS_METADATA: '0x_placeholder_has_metadata',
  CREATED_BY: '0x_placeholder_created_by',
} as const

/** Type atom term_ids (populated by bootstrap) */
export const TYPE_ATOMS = {
  AGENT_TYPE: '0x_placeholder_agent_type',
  SKILL_TYPE: '0x_placeholder_skill_type',
  SAFE: '0x_placeholder_safe',
} as const

/** MultiVault contract addresses */
export const CONTRACTS = {
  MULTIVAULT_TESTNET: '0xB92EA1B47E4ABD0a520E9138BB59dBd1bC6C475B',
  MULTIVAULT_MAINNET: '0x6E35cF57A41fA15eA0EaE9C33e751b01A784Fe7e',
  // Local Anvil deployment - use getContractAddress() for runtime resolution
  MULTIVAULT_LOCAL: '0xc3e53F4d16Ae77Db1c982e75a937B9f60FE63690',
} as const

/** Supported network identifiers */
export type NetworkId = 'local' | 'testnet' | 'mainnet'

/** Get contract address for a given network */
export function getContractAddress(network: NetworkId): `0x${string}` {
  switch (network) {
    case 'testnet':
      return CONTRACTS.MULTIVAULT_TESTNET
    case 'mainnet':
      return CONTRACTS.MULTIVAULT_MAINNET
    case 'local':
      // On client side, just return the default local address
      // Server-side can override via env var
      if (typeof window !== 'undefined') {
        return CONTRACTS.MULTIVAULT_LOCAL
      }
      return (process.env.LOCAL_MULTIVAULT_ADDRESS || CONTRACTS.MULTIVAULT_LOCAL) as `0x${string}`
  }
}

/** Chain configurations */
export const CHAINS = {
  LOCAL: { chainId: 31337, name: 'Intuition Local', rpcUrl: 'http://localhost:8545' },
  TESTNET: { chainId: 13579, name: 'Intuition Testnet', rpcUrl: 'https://testnet.rpc.intuition.systems/' },
  MAINNET: { chainId: 1155, name: 'Intuition Mainnet', rpcUrl: 'https://mainnet.rpc.intuition.systems/' },
} as const

/** Get chain configuration for a given network */
export function getChainConfig(network: NetworkId) {
  switch (network) {
    case 'local': return CHAINS.LOCAL
    case 'testnet': return CHAINS.TESTNET
    case 'mainnet': return CHAINS.MAINNET
  }
}

/** Get RPC URL for a given network */
export function getRpcUrl(network: NetworkId): string {
  return getChainConfig(network).rpcUrl
}

/** JSON @type values for IPFS metadata */
export const METADATA_TYPES = {
  AGENT: 'Agent',
  SKILL: 'Skill',
  CAPABILITY: 'Capability',
} as const

/** Namespaces for identity atoms (v3 pattern) */
export const NAMESPACES = {
  AGENT: 'intuition-agent',
  SKILL: 'intuition-skill',
} as const
