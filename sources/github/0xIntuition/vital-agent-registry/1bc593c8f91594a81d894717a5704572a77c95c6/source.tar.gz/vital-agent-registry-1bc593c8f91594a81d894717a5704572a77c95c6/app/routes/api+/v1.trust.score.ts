import type { ActionFunctionArgs, LoaderFunctionArgs } from 'react-router'
import { handleOptions, parseJsonBody, jsonResponse, errorResponse } from '~/lib/api/types'
import { trustScoreSchema } from '~/lib/api/validation'
import { getTrustModel, listTrustModels } from '~/lib/trust-model/models'
import { scoreCandidates } from '~/lib/trust-model/evaluator'
import { buildQueryHash } from '~/lib/evidence/schema'
import { saveEvidenceBundle } from '~/lib/evidence/store'

export async function loader({ request }: LoaderFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes
  return jsonResponse({
    availableModels: listTrustModels().map((model) => ({
      modelId: model.modelId,
      version: model.version,
      domain: model.domain,
    })),
  })
}

export async function action({ request }: ActionFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const parsed = await parseJsonBody(request, trustScoreSchema)
  if ('error' in parsed) return parsed.error

  const input = parsed.data
  const model = getTrustModel(input.modelId, input.version)
  if (!model) {
    return errorResponse('Trust model not found', 'NOT_FOUND', 404, {
      modelId: input.modelId,
      version: input.version,
    })
  }

  const snapshotTimestamp =
    input.snapshotTimestamp ?? new Date('1970-01-01T00:00:00.000Z').toISOString()
  const queryHash = buildQueryHash({
    modelId: input.modelId,
    version: input.version,
    snapshotId: input.snapshotId,
    snapshotTimestamp,
    candidates: input.candidates.map((candidate) => ({
      id: candidate.id,
      inputs: candidate.inputs,
      claimIds: candidate.claimIds,
      traversalPath: candidate.traversalPath,
      vaultSnapshots: candidate.vaultSnapshots,
    })),
  })

  const scored = scoreCandidates(model, input.candidates.map((candidate) => ({
    id: candidate.id,
    inputs: candidate.inputs,
  })))

  const generatedAt = snapshotTimestamp
  const results = scored.map((entry) => {
    const candidate = input.candidates.find((item) => item.id === entry.candidateId)!
    const bundle = saveEvidenceBundle({
      candidateId: entry.candidateId,
      modelId: input.modelId,
      modelVersion: input.version,
      claimIds: candidate.claimIds,
      traversalPath: candidate.traversalPath,
      vaultSnapshots: candidate.vaultSnapshots,
      score: entry.normalizedScore,
      confidence: entry.confidence,
      queryHash,
      snapshotId: input.snapshotId,
      snapshotTimestamp,
      generatedAt,
      ttlSeconds: input.ttlSeconds,
      expiresAt: new Date(Date.parse(generatedAt) + input.ttlSeconds * 1000).toISOString(),
    })

    return {
      candidateId: entry.candidateId,
      score: entry.normalizedScore,
      confidence: entry.confidence,
      evidenceId: bundle.id,
    }
  })

  return jsonResponse({
    modelId: input.modelId,
    version: input.version,
    snapshotId: input.snapshotId,
    snapshotTimestamp,
    queryHash,
    results,
  })
}
