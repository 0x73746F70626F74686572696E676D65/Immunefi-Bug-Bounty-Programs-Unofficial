import { describe, it, expect, beforeAll, vi } from 'vitest'
import type { RegistryRepository } from '~/types'
import { MockRegistryRepository } from '../mock-repository'
import { GraphQLRegistryRepository } from '../graphql-repository'
import { MOCK_AGENTS } from '../../agents'
import { MOCK_SKILLS } from '../../skills'
import { CAPABILITIES } from '../../capabilities'
import { PREDICATES } from '../../predicates'
import { PLATFORMS } from '../../platforms'
import { serverGraphqlRequest } from '~/lib/graphql/client'

vi.mock('~/lib/graphql/client', () => ({
  serverGraphqlRequest: vi.fn(),
}))

/**
 * Helper to create mock data for testing
 */
function getMockData() {
  return {
    agents: MOCK_AGENTS,
    skills: MOCK_SKILLS,
    capabilities: CAPABILITIES,
    predicates: PREDICATES,
    platforms: PLATFORMS,
  }
}

function toGraphqlAgentAtom(agent: any) {
  return {
    term_id: agent.id,
    label: agent.metadata.name,
    image: agent.metadata.image ?? null,
    cached_image: agent.metadata.image ? { url: agent.metadata.image, safe: true } : null,
    type: 'Agent',
    data: JSON.stringify({
      description: agent.metadata.description,
      version: agent.metadata.version,
      model: agent.metadata.model,
      endpoint: agent.metadata.endpoint,
      provider: agent.metadata.provider,
      tags: agent.metadata.tags ?? [],
    }),
    created_at: agent.metadata.createdAt,
    updated_at: agent.metadata.lastActiveAt ?? null,
    creator: null,
    value: {
      thing: {
        name: agent.metadata.name,
        description: agent.metadata.description,
        image: agent.metadata.image ?? null,
        url: agent.metadata.endpoint ?? null,
      },
    },
    term: {
      total_market_cap: agent.vault.market_cap,
      positions_aggregate: { aggregate: { count: agent.vault.position_count } },
      vaults: [
        {
          term_id: agent.vault.term_id,
          curve_id: '1',
          current_share_price: agent.vault.current_share_price,
          total_shares: agent.vault.total_shares,
          total_assets: agent.vault.total_assets,
          position_count: agent.vault.position_count,
          market_cap: agent.vault.market_cap,
        },
      ],
    },
    as_subject_triples: (agent.triples ?? []).map((triple: any) => ({
      term_id: triple.term_id,
      counter_term_id: triple.counter_term_id ?? null,
      predicate: {
        term_id: triple.predicate.term_id,
        label: triple.predicate.label,
      },
      object: {
        term_id: triple.object.term_id,
        label: triple.object.label,
        image: triple.object.image ?? null,
        cached_image: null,
        type: triple.object.type ?? null,
        data: null,
        value: {
          thing: {
            name: triple.object.label,
            description: triple.object.label,
            image: triple.object.image ?? null,
            url: null,
          },
        },
      },
      term: null,
    })),
  }
}

function toGraphqlSkillAtom(skill: any) {
  const forVault = {
    term_id: skill.vault.term_id,
    curve_id: '1',
    current_share_price: skill.vault.current_share_price,
    total_shares: skill.vault.total_shares,
    total_assets: skill.vault.total_assets,
    position_count: skill.vault.position_count,
    market_cap: skill.vault.market_cap,
  }
  const againstVault = {
    term_id: `${skill.id}_against`,
    curve_id: '0',
    current_share_price: skill.vault.current_share_price,
    total_shares: skill.vault.total_shares,
    total_assets: String(
      Math.floor(Number(skill.safetySignal.againstStake || '0') * 1_000_000_000_000_000_000),
    ),
    position_count: skill.safetySignal.againstCount ?? 0,
    market_cap: String(
      Math.floor(Number(skill.safetySignal.againstStake || '0') * 1_000_000_000_000_000_000),
    ),
  }

  const triples = [
    ...(skill.capabilities ?? []).map((cap: any) => ({
      term_id: `${skill.id}_has_cap_${cap.id}`,
      counter_term_id: `${cap.id}_has_cap_${skill.id}`,
      predicate: { term_id: '0xpred_has_capability', label: 'has-capability' },
      object: {
        term_id: cap.id,
        label: cap.name,
        image: null,
        cached_image: null,
        type: 'Capability',
        data: JSON.stringify({ category: cap.category, description: cap.description }),
        value: {
          thing: {
            name: cap.name,
            description: cap.description,
            image: null,
            url: null,
          },
        },
      },
      term: { vaults: [againstVault] },
    })),
  ]

  return {
    term_id: skill.id,
    label: skill.metadata.name,
    image: skill.metadata.image ?? null,
    cached_image: skill.metadata.image ? { url: skill.metadata.image, safe: true } : null,
    type: 'Skill',
    data: JSON.stringify({
      description: skill.metadata.description,
      version: skill.metadata.version,
      author: skill.metadata.author,
      installUri: skill.metadata.installUri,
      permissions: skill.metadata.permissions ?? [],
      longDescription: skill.metadata.longDescription,
    }),
    created_at: skill.metadata.createdAt,
    updated_at: skill.metadata.updatedAt ?? null,
    creator: null,
    value: {
      thing: {
        name: skill.metadata.name,
        description: skill.metadata.description,
        image: skill.metadata.image ?? null,
        url: skill.metadata.installUri ?? null,
      },
    },
    term: {
      total_market_cap: skill.vault.market_cap,
      positions_aggregate: { aggregate: { count: skill.vault.position_count } },
      vaults: [forVault],
    },
    as_subject_triples: triples,
  }
}

function toGraphqlCapabilityAtom(capability: any) {
  return {
    term_id: capability.id,
    label: capability.name,
    data: JSON.stringify({
      category: capability.category,
      description: capability.description,
    }),
    value: {
      thing: {
        name: capability.name,
        description: capability.description,
      },
    },
  }
}

function toGraphqlPlatformAtom(platform: any) {
  return {
    term_id: platform.id,
    label: platform.name,
    image: platform.icon ?? null,
    cached_image: null,
    data: JSON.stringify({ description: platform.description, url: platform.url ?? null }),
    value: {
      thing: {
        name: platform.name,
        description: platform.description,
        image: platform.icon ?? null,
        url: platform.url ?? null,
      },
    },
  }
}

function installGraphqlRequestMock() {
  const agentAtoms = MOCK_AGENTS.map(toGraphqlAgentAtom)
  const skillAtoms = MOCK_SKILLS.map(toGraphqlSkillAtom)
  const capabilityAtoms = CAPABILITIES.map(toGraphqlCapabilityAtom)
  const platformAtoms = PLATFORMS.map(toGraphqlPlatformAtom)

  vi.mocked(serverGraphqlRequest).mockImplementation(async (_apiUrl: string, query: string, variables?: unknown) => {
    const vars = (variables ?? {}) as Record<string, any>
    if (query.includes('query GetRegistryAgent(')) {
      return { atom: agentAtoms.find((atom) => atom.term_id === vars.termId) ?? null } as any
    }
    if (query.includes('query SearchAgents(')) {
      const search = String(vars.searchTerm ?? '').replace(/%/g, '').toLowerCase()
      const limit = vars.limit ?? 20
      const atoms = agentAtoms
        .filter((atom) => {
          const haystack = `${atom.label} ${atom.data ?? ''}`.toLowerCase()
          return haystack.includes(search)
        })
        .slice(0, limit)
      return { atoms } as any
    }
    if (query.includes('query GetRegistryAgents(')) {
      const limit = vars.limit ?? 20
      const offset = vars.offset ?? 0
      return {
        total: { aggregate: { count: agentAtoms.length } },
        atoms: agentAtoms.slice(offset, offset + limit),
      } as any
    }
    if (query.includes('query GetRegistrySkill(')) {
      return { atom: skillAtoms.find((atom) => atom.term_id === vars.termId) ?? null } as any
    }
    if (query.includes('query SearchSkills(')) {
      const search = String(vars.searchTerm ?? '').replace(/%/g, '').toLowerCase()
      const limit = vars.limit ?? 20
      const atoms = skillAtoms
        .filter((atom) => {
          const haystack = `${atom.label} ${atom.data ?? ''}`.toLowerCase()
          return haystack.includes(search)
        })
        .slice(0, limit)
      return { atoms } as any
    }
    if (query.includes('query GetRegistrySkills(')) {
      const limit = vars.limit ?? 20
      const offset = vars.offset ?? 0
      return {
        total: { aggregate: { count: skillAtoms.length } },
        atoms: skillAtoms.slice(offset, offset + limit),
      } as any
    }
    if (query.includes('query GetAllSkills')) {
      return {
        atoms: skillAtoms.map((atom) => ({
          term_id: atom.term_id,
          term: atom.term,
        })),
      } as any
    }
    if (query.includes('query GetSkillsForAgent(')) {
      const agent = agentAtoms.find((atom) => atom.term_id === vars.agentId)
      const skillIds = (agent?.as_subject_triples ?? [])
        .filter((triple: any) => triple.predicate.label === 'uses')
        .map((triple: any) => triple.object.term_id)
      return {
        triples: skillIds
          .map((id: string) => skillAtoms.find((atom) => atom.term_id === id))
          .filter(Boolean)
          .map((object: any) => ({ object })),
      } as any
    }
    if (query.includes('query GetCapabilities')) {
      return { atoms: capabilityAtoms } as any
    }
    if (query.includes('query GetPlatforms')) {
      return { atoms: platformAtoms } as any
    }
    throw new Error(`Unhandled GraphQL query in conformance mock: ${query.slice(0, 80)}`)
  })
}

/**
 * Shared conformance test suite that validates any RegistryRepository implementation
 * behaves identically. Run this against both Mock and GraphQL implementations.
 *
 * This ensures adapter contract compliance across all implementations.
 */
function runConformanceTests(getRepo: () => RegistryRepository) {
  describe('listAgents', () => {
    it('should return paginated results', async () => {
      const repo = getRepo()
      const result = await repo.listAgents({ limit: 5 })
      expect(result.items).toHaveLength(5)
      expect(result.total).toBeGreaterThan(0)
      expect(typeof result.hasMore).toBe('boolean')
    })

    it('should respect limit parameter', async () => {
      const repo = getRepo()
      const result = await repo.listAgents({ limit: 3 })
      expect(result.items.length).toBeLessThanOrEqual(3)
    })

    it('should return agents with required fields', async () => {
      const repo = getRepo()
      const result = await repo.listAgents({ limit: 1 })
      const agent = result.items[0]
      expect(agent).toBeDefined()
      expect(agent.id).toBeTruthy()
      expect(agent.metadata.name).toBeTruthy()
      expect(agent.metadata.description).toBeTruthy()
      expect(agent.vault).toBeDefined()
      expect(agent.trustSignal).toBeDefined()
      expect(agent.trustSignal.tier).toBeDefined()
    })

    it('should filter by capability', async () => {
      const repo = getRepo()
      // Get an agent with known capabilities
      const all = await repo.listAgents({ limit: 50 })
      if (all.items.length === 0) return
      const capId = all.items[0].capabilities[0]?.id
      if (!capId) return
      const filtered = await repo.listAgents({ capability: capId, limit: 50 })
      expect(filtered.items.every(a => a.capabilities.some(c => c.id === capId))).toBe(true)
    })

    it('should filter by trust tier', async () => {
      const repo = getRepo()
      const result = await repo.listAgents({ trustTier: 'gold', limit: 50 })
      expect(result.items.every(a => a.trustSignal.tier === 'gold')).toBe(true)
    })

    it('should sort by trust descending', async () => {
      const repo = getRepo()
      const result = await repo.listAgents({ sortBy: 'trust', limit: 20 })
      for (let i = 1; i < result.items.length; i++) {
        expect(result.items[i - 1].trustSignal.percentile).toBeGreaterThanOrEqual(
          result.items[i].trustSignal.percentile
        )
      }
    })

    it('should sort by name ascending', async () => {
      const repo = getRepo()
      const result = await repo.listAgents({ sortBy: 'name', limit: 20 })
      for (let i = 1; i < result.items.length; i++) {
        expect(result.items[i - 1].metadata.name.localeCompare(result.items[i].metadata.name)).toBeLessThanOrEqual(0)
      }
    })

    it('should sort by stakers descending', async () => {
      const repo = getRepo()
      const result = await repo.listAgents({ sortBy: 'stakers', limit: 20 })
      for (let i = 1; i < result.items.length; i++) {
        expect(result.items[i - 1].trustSignal.stakerCount).toBeGreaterThanOrEqual(
          result.items[i].trustSignal.stakerCount
        )
      }
    })

    it('should handle offset for pagination', async () => {
      const repo = getRepo()
      const page1 = await repo.listAgents({ limit: 5, offset: 0 })
      const page2 = await repo.listAgents({ limit: 5, offset: 5 })
      if (page2.items.length > 0) {
        expect(page1.items[0].id).not.toBe(page2.items[0].id)
      }
    })

    it('should calculate hasMore correctly', async () => {
      const repo = getRepo()
      const result = await repo.listAgents({ limit: 100 })
      if (result.total > 100) {
        expect(result.hasMore).toBe(true)
      } else {
        expect(result.hasMore).toBe(false)
      }
    })
  })

  describe('listSkills', () => {
    it('should return paginated results', async () => {
      const repo = getRepo()
      const result = await repo.listSkills({ limit: 5 })
      expect(result.items).toHaveLength(5)
      expect(result.total).toBeGreaterThan(0)
      expect(typeof result.hasMore).toBe('boolean')
    })

    it('should return skills with required fields including safety signal', async () => {
      const repo = getRepo()
      const result = await repo.listSkills({ limit: 1 })
      const skill = result.items[0]
      expect(skill).toBeDefined()
      expect(skill.id).toBeTruthy()
      expect(skill.metadata.name).toBeTruthy()
      expect(skill.platform).toBeDefined()
      expect(skill.safetySignal).toBeDefined()
      expect(skill.safetySignal.status).toBeDefined()
      expect(typeof skill.safetySignal.forCount).toBe('number')
      expect(typeof skill.safetySignal.safetyRatio).toBe('number')
    })

    it('should filter by platform', async () => {
      const repo = getRepo()
      const all = await repo.listSkills({ limit: 50 })
      if (all.items.length === 0) return
      const platformId = all.items[0].platform.id
      const filtered = await repo.listSkills({ platformId, limit: 50 })
      expect(filtered.items.every(s => s.platform.id === platformId)).toBe(true)
    })

    it('should filter by capability', async () => {
      const repo = getRepo()
      const all = await repo.listSkills({ limit: 50 })
      if (all.items.length === 0) return
      const capId = all.items[0].capabilities[0]?.id
      if (!capId) return
      const filtered = await repo.listSkills({ capability: capId, limit: 50 })
      expect(filtered.items.every(s => s.capabilities.some(c => c.id === capId))).toBe(true)
    })

    it('should sort by safety descending', async () => {
      const repo = getRepo()
      const result = await repo.listSkills({ sortBy: 'safety', limit: 20 })
      for (let i = 1; i < result.items.length; i++) {
        expect(result.items[i - 1].safetySignal.safetyRatio).toBeGreaterThanOrEqual(
          result.items[i].safetySignal.safetyRatio
        )
      }
    })
  })

  describe('findAgent', () => {
    it('should return agent by ID', async () => {
      const repo = getRepo()
      const list = await repo.listAgents({ limit: 1 })
      if (list.items.length === 0) return
      const id = list.items[0].id
      const agent = await repo.findAgent(id)
      expect(agent).not.toBeNull()
      expect(agent!.id).toBe(id)
    })

    it('should return null for non-existent ID', async () => {
      const repo = getRepo()
      const agent = await repo.findAgent('0xnonexistent')
      expect(agent).toBeNull()
    })
  })

  describe('findSkill', () => {
    it('should return skill by ID', async () => {
      const repo = getRepo()
      const list = await repo.listSkills({ limit: 1 })
      if (list.items.length === 0) return
      const id = list.items[0].id
      const skill = await repo.findSkill(id)
      expect(skill).not.toBeNull()
      expect(skill!.id).toBe(id)
    })

    it('should return null for non-existent ID', async () => {
      const repo = getRepo()
      const skill = await repo.findSkill('0xnonexistent')
      expect(skill).toBeNull()
    })
  })

  describe('searchAgents', () => {
    it('should find agents by name', async () => {
      const repo = getRepo()
      const all = await repo.listAgents({ limit: 1 })
      if (all.items.length === 0) return
      const name = all.items[0].metadata.name.split(' ')[0]
      const results = await repo.searchAgents(name)
      expect(results.length).toBeGreaterThan(0)
      expect(results.some(a => a.metadata.name.toLowerCase().includes(name.toLowerCase()))).toBe(true)
    })

    it('should return empty array for non-existent query', async () => {
      const repo = getRepo()
      const results = await repo.searchAgents('zzz_nonexistent_query_xyz')
      expect(results).toEqual([])
    })

    it('should be case-insensitive', async () => {
      const repo = getRepo()
      const all = await repo.listAgents({ limit: 1 })
      if (all.items.length === 0) return
      const name = all.items[0].metadata.name.split(' ')[0]
      const lowerResults = await repo.searchAgents(name.toLowerCase())
      const upperResults = await repo.searchAgents(name.toUpperCase())
      expect(lowerResults.length).toBe(upperResults.length)
    })

    it('should search in description', async () => {
      const repo = getRepo()
      const all = await repo.listAgents({ limit: 10 })
      if (all.items.length === 0) return
      // Find an agent with a unique word in description
      const agent = all.items.find(a => a.metadata.description.length > 20)
      if (!agent) return
      const word = agent.metadata.description.split(' ')[1]
      const results = await repo.searchAgents(word)
      expect(results.some(a => a.id === agent.id)).toBe(true)
    })

    it('should respect limit option', async () => {
      const repo = getRepo()
      const results = await repo.searchAgents('agent', { limit: 3 })
      expect(results.length).toBeLessThanOrEqual(3)
    })

    it('should filter by capability in search', async () => {
      const repo = getRepo()
      const all = await repo.listAgents({ limit: 50 })
      if (all.items.length === 0) return
      const capId = all.items[0].capabilities[0]?.id
      if (!capId) return
      const results = await repo.searchAgents('', { capabilities: [capId] })
      expect(results.every(a => a.capabilities.some(c => c.id === capId))).toBe(true)
    })
  })

  describe('searchSkills', () => {
    it('should find skills by name', async () => {
      const repo = getRepo()
      const all = await repo.listSkills({ limit: 1 })
      if (all.items.length === 0) return
      const name = all.items[0].metadata.name.split(' ')[0]
      const results = await repo.searchSkills(name)
      expect(results.length).toBeGreaterThan(0)
      expect(results.some(s => s.metadata.name.toLowerCase().includes(name.toLowerCase()))).toBe(true)
    })

    it('should return empty array for non-existent query', async () => {
      const repo = getRepo()
      const results = await repo.searchSkills('zzz_nonexistent_query_xyz')
      expect(results).toEqual([])
    })

    it('should be case-insensitive', async () => {
      const repo = getRepo()
      const all = await repo.listSkills({ limit: 1 })
      if (all.items.length === 0) return
      const name = all.items[0].metadata.name.split(' ')[0]
      const lowerResults = await repo.searchSkills(name.toLowerCase())
      const upperResults = await repo.searchSkills(name.toUpperCase())
      expect(lowerResults.length).toBe(upperResults.length)
    })
  })

  describe('matchAgentCapabilities', () => {
    it('should match agents with required capabilities (AND)', async () => {
      const repo = getRepo()
      const all = await repo.listAgents({ limit: 50 })
      if (all.items.length === 0) return
      // Find an agent with at least 2 capabilities
      const agent = all.items.find(a => a.capabilities.length >= 2)
      if (!agent) return
      const required = agent.capabilities.slice(0, 2).map(c => c.id)
      const results = await repo.matchAgentCapabilities(required, { matchAll: true })
      expect(results.length).toBeGreaterThan(0)
      expect(results.every(a => required.every(req => a.capabilities.some(c => c.id === req)))).toBe(true)
    })

    it('should match agents with any capability (OR)', async () => {
      const repo = getRepo()
      const all = await repo.listAgents({ limit: 50 })
      if (all.items.length === 0) return
      const cap1 = all.items[0]?.capabilities[0]?.id
      const cap2 = all.items[1]?.capabilities[0]?.id
      if (!cap1 || !cap2) return
      const results = await repo.matchAgentCapabilities([cap1, cap2], { matchAll: false })
      expect(results.length).toBeGreaterThan(0)
      expect(results.every(a => a.capabilities.some(c => c.id === cap1 || c.id === cap2))).toBe(true)
    })

    it('should return empty for impossible capability combo', async () => {
      const repo = getRepo()
      const results = await repo.matchAgentCapabilities(['nonexistent-cap-1', 'nonexistent-cap-2'], { matchAll: true })
      expect(results).toEqual([])
    })

    it('should filter by minTrustTier', async () => {
      const repo = getRepo()
      const all = await repo.listAgents({ limit: 50 })
      if (all.items.length === 0) return
      const capId = all.items[0].capabilities[0]?.id
      if (!capId) return
      const results = await repo.matchAgentCapabilities([capId], { minTrustTier: 'gold' })
      expect(results.every(a => {
        const tierOrder = { platinum: 5, gold: 4, silver: 3, bronze: 2, unranked: 1 }
        return tierOrder[a.trustSignal.tier] >= tierOrder.gold
      })).toBe(true)
    })

    it('should respect limit option', async () => {
      const repo = getRepo()
      const all = await repo.listAgents({ limit: 50 })
      if (all.items.length === 0) return
      const capId = all.items[0].capabilities[0]?.id
      if (!capId) return
      const results = await repo.matchAgentCapabilities([capId], { limit: 3 })
      expect(results.length).toBeLessThanOrEqual(3)
    })
  })

  describe('getAgentTrust', () => {
    it('should return trust signal for existing agent', async () => {
      const repo = getRepo()
      const agents = await repo.listAgents({ limit: 1 })
      if (agents.items.length === 0) return
      const trust = await repo.getAgentTrust(agents.items[0].id)
      expect(trust).not.toBeNull()
      expect(trust!.tier).toBeDefined()
      expect(trust!.percentile).toBeGreaterThanOrEqual(0)
      expect(trust!.percentile).toBeLessThanOrEqual(100)
    })

    it('should return null for non-existent agent', async () => {
      const repo = getRepo()
      const trust = await repo.getAgentTrust('0xnonexistent')
      expect(trust).toBeNull()
    })
  })

  describe('getSkillTrust', () => {
    it('should return trust signal for existing skill', async () => {
      const repo = getRepo()
      const skills = await repo.listSkills({ limit: 1 })
      if (skills.items.length === 0) return
      const trust = await repo.getSkillTrust(skills.items[0].id)
      expect(trust).not.toBeNull()
      expect(trust!.tier).toBeDefined()
    })

    it('should return null for non-existent skill', async () => {
      const repo = getRepo()
      const trust = await repo.getSkillTrust('0xnonexistent')
      expect(trust).toBeNull()
    })
  })

  describe('getAgentCard', () => {
    it('should return agent card for agent with A2A data', async () => {
      const repo = getRepo()
      const agents = await repo.listAgents({ limit: 50 })
      const agentWithCard = agents.items.find((a) => Boolean(a.metadata.endpoint))
      if (!agentWithCard) return
      const card = await repo.getAgentCard(agentWithCard.id)
      expect(card).not.toBeNull()
      expect(card!.id).toBe(agentWithCard.id)
    })

    it('should return null for agent without A2A data', async () => {
      const repo = getRepo()
      const agents = await repo.listAgents({ limit: 50 })
      const agentWithoutCard = agents.items.find((a) => !a.metadata.endpoint)
      if (!agentWithoutCard) return
      const card = await repo.getAgentCard(agentWithoutCard.id)
      expect(card).toBeNull()
    })

    it('should return null for non-existent agent', async () => {
      const repo = getRepo()
      const card = await repo.getAgentCard('0xnonexistent')
      expect(card).toBeNull()
    })
  })

  describe('getSkillsByPlatform', () => {
    it('should return array (may be empty in v3 — belongs-to removed)', async () => {
      const repo = getRepo()
      const all = await repo.listSkills({ limit: 1 })
      if (all.items.length === 0) return
      const platformId = all.items[0].platform.id
      const skills = await repo.getSkillsByPlatform(platformId)
      expect(Array.isArray(skills)).toBe(true)
      // If results returned, they should all be from the same platform
      if (skills.length > 0) {
        expect(skills.every(s => s.platform.id === platformId)).toBe(true)
      }
    })

    it('should return empty array for non-existent platform', async () => {
      const repo = getRepo()
      const skills = await repo.getSkillsByPlatform('nonexistent-platform')
      expect(skills).toEqual([])
    })
  })

  describe('getSkillsForAgent', () => {
    it('should return skills for agent that uses skills', async () => {
      const repo = getRepo()
      const all = await repo.listAgents({ limit: 50 })
      const agentWithSkills = all.items.find(a =>
        a.triples.some(t => t.predicate.label === 'uses')
      )
      if (!agentWithSkills) return
      const skills = await repo.getSkillsForAgent(agentWithSkills.id)
      expect(skills.length).toBeGreaterThan(0)
    })

    it('should return empty array for agent with no skills', async () => {
      const repo = getRepo()
      const all = await repo.listAgents({ limit: 50 })
      const agentWithoutSkills = all.items.find(a =>
        !a.triples.some(t => t.predicate.label === 'uses')
      )
      if (!agentWithoutSkills) return
      const skills = await repo.getSkillsForAgent(agentWithoutSkills.id)
      expect(skills).toEqual([])
    })

    it('should return empty array for non-existent agent', async () => {
      const repo = getRepo()
      const skills = await repo.getSkillsForAgent('0xnonexistent')
      expect(skills).toEqual([])
    })
  })

  describe('listCapabilities', () => {
    it('should return non-empty array', async () => {
      const repo = getRepo()
      const capabilities = await repo.listCapabilities()
      expect(capabilities.length).toBeGreaterThan(0)
    })

    it('should return capabilities with name and description', async () => {
      const repo = getRepo()
      const capabilities = await repo.listCapabilities()
      expect(capabilities.every(c => c.name && c.description)).toBe(true)
    })
  })

  describe('listPlatforms', () => {
    it('should return non-empty array', async () => {
      const repo = getRepo()
      const platforms = await repo.listPlatforms()
      expect(platforms.length).toBeGreaterThan(0)
    })

    it('should return platforms with id and name', async () => {
      const repo = getRepo()
      const platforms = await repo.listPlatforms()
      expect(platforms.every(p => p.id && p.name)).toBe(true)
    })
  })

  describe('listPredicates', () => {
    it('should return non-empty array', async () => {
      const repo = getRepo()
      const predicates = await repo.listPredicates()
      expect(predicates.length).toBeGreaterThan(0)
    })

    it('should return predicates with label and description', async () => {
      const repo = getRepo()
      const predicates = await repo.listPredicates()
      expect(predicates.every(p => p.label && p.description)).toBe(true)
    })
  })

  describe('type shapes', () => {
    it('agent vault should have BigInt-compatible string fields', async () => {
      const repo = getRepo()
      const result = await repo.listAgents({ limit: 1 })
      if (result.items.length === 0) return
      const vault = result.items[0].vault
      expect(typeof vault.total_shares).toBe('string')
      expect(typeof vault.current_share_price).toBe('string')
      expect(typeof vault.total_assets).toBe('string')
      expect(typeof vault.market_cap).toBe('string')
      expect(typeof vault.position_count).toBe('number')
      // Verify they're parseable as BigInt
      expect(() => BigInt(vault.total_shares)).not.toThrow()
      expect(() => BigInt(vault.current_share_price)).not.toThrow()
      expect(() => BigInt(vault.total_assets)).not.toThrow()
    })

    it('skill safety signal should have correct shape', async () => {
      const repo = getRepo()
      const result = await repo.listSkills({ limit: 1 })
      if (result.items.length === 0) return
      const safety = result.items[0].safetySignal
      expect(typeof safety.status).toBe('string')
      expect(['verified', 'flagged', 'unverified']).toContain(safety.status)
      expect(typeof safety.forCount).toBe('number')
      expect(typeof safety.againstCount).toBe('number')
      expect(typeof safety.forStake).toBe('string')
      expect(typeof safety.againstStake).toBe('string')
      expect(typeof safety.safetyRatio).toBe('number')
      expect(safety.safetyRatio).toBeGreaterThanOrEqual(0)
      expect(safety.safetyRatio).toBeLessThanOrEqual(1)
    })

    it('agent trust signal should have correct shape', async () => {
      const repo = getRepo()
      const result = await repo.listAgents({ limit: 1 })
      if (result.items.length === 0) return
      const trust = result.items[0].trustSignal
      expect(typeof trust.stakerCount).toBe('number')
      expect(typeof trust.totalStaked).toBe('string')
      expect(typeof trust.sharePrice).toBe('string')
      expect(typeof trust.tier).toBe('string')
      expect(['platinum', 'gold', 'silver', 'bronze', 'unranked']).toContain(trust.tier)
      expect(typeof trust.percentile).toBe('number')
      expect(trust.percentile).toBeGreaterThanOrEqual(0)
      expect(trust.percentile).toBeLessThanOrEqual(100)
      expect(typeof trust.marketCap).toBe('string')
    })

    it('agent metadata should have correct shape', async () => {
      const repo = getRepo()
      const result = await repo.listAgents({ limit: 1 })
      if (result.items.length === 0) return
      const meta = result.items[0].metadata
      expect(typeof meta.name).toBe('string')
      expect(typeof meta.description).toBe('string')
      expect(typeof meta.version).toBe('string')
      expect(typeof meta.createdAt).toBe('string')
    })

    it('skill metadata should have correct shape', async () => {
      const repo = getRepo()
      const result = await repo.listSkills({ limit: 1 })
      if (result.items.length === 0) return
      const meta = result.items[0].metadata
      expect(typeof meta.name).toBe('string')
      expect(typeof meta.description).toBe('string')
      expect(typeof meta.version).toBe('string')
      expect(Array.isArray(meta.permissions)).toBe(true)
      expect(typeof meta.createdAt).toBe('string')
    })
  })
}

// Run conformance tests against MockRegistryRepository
describe('MockRegistryRepository Conformance', () => {
  let repo: RegistryRepository

  beforeAll(() => {
    repo = new MockRegistryRepository(getMockData())
  })

  runConformanceTests(() => repo)
})

// Placeholder for GraphQLRegistryRepository conformance tests
describe('GraphQLRegistryRepository Conformance', () => {
  let repo: RegistryRepository

  beforeAll(() => {
    installGraphqlRequestMock()
    repo = new GraphQLRegistryRepository({
      apiUrl: 'http://localhost:8080/v1/graphql',
      chain: 'testnet',
    })
  })

  runConformanceTests(() => repo)
})
