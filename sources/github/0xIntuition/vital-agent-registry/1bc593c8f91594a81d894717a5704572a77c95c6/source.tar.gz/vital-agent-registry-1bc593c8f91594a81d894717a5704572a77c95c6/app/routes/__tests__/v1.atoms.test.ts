import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const mocks = vi.hoisted(() => ({
  getAtomCost: vi.fn(),
  createAtoms: vi.fn(),
  getAtomByUri: vi.fn(),
  getMinimumDeposit: vi.fn(),
  deriveAtomTermId: vi.fn(),
  getLocalWriteContext: vi.fn(),
  createLocalWriteClients: vi.fn(),
  assertRemoteWriteAllowed: vi.fn(),
  isRegistrationRateLimitEnabled: vi.fn(),
  registrationLimiter: { check: vi.fn(), reset: vi.fn() },
  getClientIP: vi.fn(),
}))

vi.mock('~/.server/multivault', () => ({
  getAtomCost: mocks.getAtomCost,
  createAtoms: mocks.createAtoms,
  getAtomByUri: mocks.getAtomByUri,
  getMinimumDeposit: mocks.getMinimumDeposit,
}))

vi.mock('~/lib/calldata', () => ({
  deriveAtomTermId: mocks.deriveAtomTermId,
}))

vi.mock('viem', () => ({
  encodeFunctionData: vi.fn(() => '0xcalldata'),
  parseEventLogs: vi.fn(() => []),
  toHex: vi.fn((s: string) => `0x${Buffer.from(s).toString('hex')}`),
  createPublicClient: vi.fn(() => ({})),
  http: vi.fn(() => ({})),
}))

vi.mock('~/.server/local-write', () => ({
  createLocalWriteClients: mocks.createLocalWriteClients,
  getLocalWriteContext: mocks.getLocalWriteContext,
}))

vi.mock('~/.server/remote-write-guard', () => ({
  assertRemoteWriteAllowed: mocks.assertRemoteWriteAllowed,
  RemoteWriteGuardError: class RemoteWriteGuardError extends Error {
    code: string
    profile: string
    target: string
    action: string
    constructor(message: string, code: string, profile: string, target: string, action: string) {
      super(message)
      this.code = code
      this.profile = profile
      this.target = target
      this.action = action
    }
  },
}))

vi.mock('~/lib/abis/multivault', () => ({
  multivaultAbi: [],
}))

vi.mock('~/lib/rate-limit', () => ({
  registrationLimiter: mocks.registrationLimiter,
  getClientIP: mocks.getClientIP,
  isRegistrationRateLimitEnabled: mocks.isRegistrationRateLimitEnabled,
}))

describe('POST /api/v1/atoms (prepare mode)', () => {
  const baseEnv = { ...process.env }
  const termId1 = '0x1111111111111111111111111111111111111111111111111111111111111111'
  const termId2 = '0x2222222222222222222222222222222222222222222222222222222222222222'

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = {
      ...baseEnv,
      CHAIN: 'testnet',
      ALLOW_REMOTE_WRITES: '1',
      REGISTRY_WRITE_PROFILE: 'shared',
    }
    mocks.getAtomCost.mockResolvedValue(10n)
    mocks.deriveAtomTermId.mockImplementation((data: string) => {
      if (data === 'atom-one') return termId1
      return termId2
    })
    mocks.isRegistrationRateLimitEnabled.mockReturnValue(false)
  })

  afterEach(() => {
    process.env = { ...baseEnv }
  })

  it('should return atoms with derived term IDs for valid body', async () => {
    const { action } = await import('../api+/v1.atoms')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/atoms', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          atomData: ['atom-one', 'atom-two'],
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.atoms).toHaveLength(2)
    expect(body.data.atoms[0]).toEqual({ data: 'atom-one', termId: termId1 })
    expect(body.data.atoms[1]).toEqual({ data: 'atom-two', termId: termId2 })
    expect(body.data.calldata).toBe('0xcalldata')
    expect(body.data.estimatedCost).toBeDefined()
    expect(body.data.contractAddress).toBeDefined()
    expect(body.data.chainId).toBeDefined()
  })

  it('should return validation error when atomData is empty', async () => {
    const { action } = await import('../api+/v1.atoms')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/atoms', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          atomData: [],
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(400)
    const body = await response.json()
    expect(body.code).toBe('VALIDATION_ERROR')
  })

  it('should return parse error for invalid JSON body', async () => {
    const { action } = await import('../api+/v1.atoms')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/atoms', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: '{ invalid json',
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(400)
    const body = await response.json()
    expect(body.code).toBe('PARSE_ERROR')
  })
})

describe('POST /api/v1/atoms?execute=true', () => {
  const baseEnv = { ...process.env }
  const termId1 = '0x1111111111111111111111111111111111111111111111111111111111111111'
  const termId2 = '0x2222222222222222222222222222222222222222222222222222222222222222'
  const existingTermId = '0x3333333333333333333333333333333333333333333333333333333333333333'

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = {
      ...baseEnv,
      CHAIN: 'testnet',
      REGISTRY_API_KEY: 'test-key',
    }
    mocks.getAtomCost.mockResolvedValue(10n)
    mocks.deriveAtomTermId.mockReturnValue(termId1)
    mocks.createAtoms.mockResolvedValue({ hash: '0xatomhash', atomCount: 2 })
    mocks.getMinimumDeposit.mockResolvedValue(1n)
    mocks.getAtomByUri.mockResolvedValue(null)
    mocks.isRegistrationRateLimitEnabled.mockReturnValue(false)

    mocks.getLocalWriteContext.mockReturnValue({
      contractAddress: '0xcontract',
      rpcUrl: 'http://localhost:8545',
    })
    mocks.createLocalWriteClients.mockResolvedValue({
      publicClient: {
        waitForTransactionReceipt: vi.fn().mockResolvedValue({ logs: [] }),
      },
      walletClient: {
        account: { address: '0xwalletaddress' },
      },
    })
  })

  afterEach(() => {
    process.env = { ...baseEnv }
  })

  it('should create atoms and return execution results', async () => {
    const { action } = await import('../api+/v1.atoms')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/atoms?execute=true', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': 'test-key' },
        body: JSON.stringify({
          atomData: ['new-atom-one', 'new-atom-two'],
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.execution).toBeDefined()
    expect(body.data.execution.mode).toBe('local')
    expect(body.data.execution.executed).toBe(true)
    expect(body.data.execution.txHash).toBe('0xatomhash')
    expect(body.data.execution.createdCount).toBe(2)
    expect(body.data.execution.account).toBe('0xwalletaddress')
  })

  it('should skip existing atoms for idempotent creation', async () => {
    mocks.getAtomByUri.mockImplementation(async (_pc: unknown, _addr: unknown, data: string) => {
      if (data === 'existing-atom') return existingTermId
      return null
    })
    mocks.deriveAtomTermId.mockReturnValue(termId2)
    mocks.createAtoms.mockResolvedValue({ hash: '0xatomhash', atomCount: 1 })

    const { action } = await import('../api+/v1.atoms')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/atoms?execute=true', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': 'test-key' },
        body: JSON.stringify({
          atomData: ['existing-atom', 'new-atom'],
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.execution.createdCount).toBe(1)
    expect(body.data.execution.skippedCount).toBe(1)
    // Verify the resolved atoms list includes both
    const existedAtom = body.data.atoms.find(
      (a: { data: string }) => a.data === 'existing-atom',
    )
    expect(existedAtom).toBeDefined()
    expect(existedAtom.alreadyExisted).toBe(true)
    expect(existedAtom.termId).toBe(existingTermId)
  })

  it('should not call assertRemoteWriteAllowed in execute mode', async () => {
    const { action } = await import('../api+/v1.atoms')
    await action({
      request: new Request('http://localhost:4101/api/v1/atoms?execute=true', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': 'test-key' },
        body: JSON.stringify({
          atomData: ['test-atom'],
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(mocks.assertRemoteWriteAllowed).not.toHaveBeenCalled()
  })
})

describe('POST /api/v1/atoms rate limiting', () => {
  const baseEnv = { ...process.env }

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = {
      ...baseEnv,
      CHAIN: 'testnet',
      ALLOW_REMOTE_WRITES: '1',
      REGISTRY_WRITE_PROFILE: 'shared',
    }
    mocks.getAtomCost.mockResolvedValue(10n)
    mocks.deriveAtomTermId.mockReturnValue(
      '0x1111111111111111111111111111111111111111111111111111111111111111',
    )
  })

  afterEach(() => {
    process.env = { ...baseEnv }
  })

  it('should return 429 when rate limit is exceeded', async () => {
    mocks.isRegistrationRateLimitEnabled.mockReturnValue(true)
    mocks.getClientIP.mockReturnValue('192.168.1.1')
    mocks.registrationLimiter.check.mockReturnValue({
      allowed: false,
      resetAt: Date.now() + 60000,
    })

    const { action } = await import('../api+/v1.atoms')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/atoms', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          atomData: ['rate-limited-atom'],
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(429)
    const body = await response.json()
    expect(body.code).toBe('RATE_LIMITED')
    expect(body.retryAfter).toBeGreaterThan(0)
  })
})

describe('GET /api/v1/atoms', () => {
  it('should return endpoint guidance', async () => {
    const { loader } = await import('../api+/v1.atoms')
    const response = await loader({
      request: new Request('http://localhost:4101/api/v1/atoms', {
        method: 'GET',
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.message).toContain('/api/v1/atoms/search')
    expect(body.data.endpoints.search).toBe('/api/v1/atoms/search')
    expect(body.data.endpoints.byId).toBe('/api/v1/atoms/:id')
  })
})
