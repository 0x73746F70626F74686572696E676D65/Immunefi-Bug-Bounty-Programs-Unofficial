import { describe, it, expect } from 'vitest'
import type { LoaderFunctionArgs } from 'react-router'
import { loader } from '../api+/v1.recipes'

function createLoaderArgs(url: string, params: Record<string, string> = {}): LoaderFunctionArgs {
  return {
    request: new Request(url),
    params,
    context: {},
    unstable_pattern: undefined as unknown as string,
  } as LoaderFunctionArgs
}

describe('GET /api/v1/recipes', () => {
  it('returns all recipes', async () => {
    const response = await loader(createLoaderArgs('http://localhost/api/v1/recipes'))

    expect(response.status).toBe(200)

    const json = await response.json()
    expect(json.data).toBeInstanceOf(Array)
    expect(json.data.length).toBeGreaterThan(0)
  })

  it('filters recipes by tag', async () => {
    const response = await loader(createLoaderArgs('http://localhost/api/v1/recipes?tag=discovery'))

    expect(response.status).toBe(200)

    const json = await response.json()
    expect(json.data).toBeInstanceOf(Array)
    expect(json.data.length).toBeGreaterThan(0)

    // All returned recipes should have the discovery tag
    json.data.forEach((recipe: { tags: string[] }) => {
      expect(recipe.tags).toContain('discovery')
    })
  })

  it('returns empty array for non-existent tag', async () => {
    const response = await loader(createLoaderArgs('http://localhost/api/v1/recipes?tag=nonexistent'))

    expect(response.status).toBe(200)

    const json = await response.json()
    expect(json.data).toEqual([])
  })

  it('each recipe has required fields', async () => {
    const response = await loader(createLoaderArgs('http://localhost/api/v1/recipes'))

    const json = await response.json()

    json.data.forEach((recipe: unknown) => {
      expect(recipe).toHaveProperty('id')
      expect(recipe).toHaveProperty('name')
      expect(recipe).toHaveProperty('description')
      expect(recipe).toHaveProperty('steps')
      expect(recipe).toHaveProperty('tags')

      const r = recipe as { id: string; name: string; description: string; steps: unknown[]; tags: string[] }
      expect(typeof r.id).toBe('string')
      expect(typeof r.name).toBe('string')
      expect(typeof r.description).toBe('string')
      expect(Array.isArray(r.steps)).toBe(true)
      expect(Array.isArray(r.tags)).toBe(true)
      expect(r.steps.length).toBeGreaterThan(0)
    })
  })

  it('each step has required fields', async () => {
    const response = await loader(createLoaderArgs('http://localhost/api/v1/recipes'))

    const json = await response.json()

    json.data.forEach((recipe: { steps: unknown[] }) => {
      recipe.steps.forEach((step: unknown) => {
        expect(step).toHaveProperty('method')
        expect(step).toHaveProperty('endpoint')
        expect(step).toHaveProperty('expectedResponse')

        const s = step as { method: string; endpoint: string; expectedResponse: string }
        expect(typeof s.method).toBe('string')
        expect(['GET', 'POST', 'PUT', 'DELETE', 'PATCH']).toContain(s.method)
        expect(typeof s.endpoint).toBe('string')
        expect(s.endpoint).toMatch(/^\/api\/v1\//)
        expect(typeof s.expectedResponse).toBe('string')
      })
    })
  })

  it('parameters have correct structure when present', async () => {
    const response = await loader(createLoaderArgs('http://localhost/api/v1/recipes'))

    const json = await response.json()

    json.data.forEach((recipe: { steps: { parameters?: Record<string, unknown> }[] }) => {
      recipe.steps.forEach((step) => {
        if (step.parameters) {
          Object.values(step.parameters).forEach((param: unknown) => {
            expect(param).toHaveProperty('type')
            expect(param).toHaveProperty('required')
            expect(param).toHaveProperty('description')

            const p = param as { type: string; required: boolean; description: string }
            expect(typeof p.type).toBe('string')
            expect(typeof p.required).toBe('boolean')
            expect(typeof p.description).toBe('string')
          })
        }
      })
    })
  })

  it('response is valid JSON with correct content type', async () => {
    const response = await loader(createLoaderArgs('http://localhost/api/v1/recipes'))

    expect(response.headers.get('Content-Type')).toBe('application/json')

    const json = await response.json()
    expect(json).toHaveProperty('data')
  })

  it('handles OPTIONS request for CORS', async () => {
    const response = await loader({
      request: new Request('http://localhost/api/v1/recipes', { method: 'OPTIONS' }),
      params: {},
      context: {},
      unstable_pattern: undefined as unknown as string,
    } as LoaderFunctionArgs)

    expect(response.status).toBe(204)
    expect(response.headers.get('Access-Control-Allow-Origin')).toBe('*')
    expect(response.headers.get('Access-Control-Allow-Methods')).toContain('GET')
  })

  it('includes core recipes', async () => {
    const response = await loader(createLoaderArgs('http://localhost/api/v1/recipes'))

    const json = await response.json()
    const recipeIds = json.data.map((r: { id: string }) => r.id)

    expect(recipeIds).toContain('discovery')
    expect(recipeIds).toContain('delegation')
    expect(recipeIds).toContain('safety-verification')
    expect(recipeIds).toContain('contextual-trust')
    expect(recipeIds).toContain('agent-registration')
    expect(recipeIds).toContain('onboarding-check')
  })

  it('discovery recipe has correct structure', async () => {
    const response = await loader(createLoaderArgs('http://localhost/api/v1/recipes'))

    const json = await response.json()
    const discovery = json.data.find((r: { id: string }) => r.id === 'discovery')

    expect(discovery).toBeDefined()
    expect(discovery.steps.length).toBe(1)
    expect(discovery.steps[0].method).toBe('POST')
    expect(discovery.steps[0].endpoint).toBe('/api/v1/agents/match')
    expect(discovery.steps[0].parameters).toHaveProperty('capabilities')
    expect(discovery.steps[0].parameters?.capabilities.required).toBe(true)
  })

  it('delegation recipe has multiple steps', async () => {
    const response = await loader(createLoaderArgs('http://localhost/api/v1/recipes'))

    const json = await response.json()
    const delegation = json.data.find((r: { id: string }) => r.id === 'delegation')

    expect(delegation).toBeDefined()
    expect(delegation.steps.length).toBe(2)
    expect(delegation.steps[0].endpoint).toBe('/api/v1/agents/:id/trust')
    expect(delegation.steps[1].endpoint).toBe('/api/v1/agents/:id/card')
  })

  it('all recipes have unique ids', async () => {
    const response = await loader(createLoaderArgs('http://localhost/api/v1/recipes'))

    const json = await response.json()
    const ids = json.data.map((r: { id: string }) => r.id)
    const uniqueIds = new Set(ids)

    expect(ids.length).toBe(uniqueIds.size)
  })

  it('all recipes have at least one tag', async () => {
    const response = await loader(createLoaderArgs('http://localhost/api/v1/recipes'))

    const json = await response.json()

    json.data.forEach((recipe: { tags: string[] }) => {
      expect(recipe.tags.length).toBeGreaterThan(0)
    })
  })
})
