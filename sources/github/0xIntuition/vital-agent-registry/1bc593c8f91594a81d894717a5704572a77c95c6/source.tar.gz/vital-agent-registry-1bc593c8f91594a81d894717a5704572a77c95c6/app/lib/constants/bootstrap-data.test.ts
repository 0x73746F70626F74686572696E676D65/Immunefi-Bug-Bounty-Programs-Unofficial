import { describe, expect, it } from 'vitest';
import {
  PREDICATE_ATOMS,
  TYPE_ATOM_DEFINITIONS,
  CAPABILITY_ATOMS,
  PLATFORM_ATOMS,
  getAllFoundationAtoms,
} from './bootstrap-data';
import { isValidCapabilityName } from '../capabilities';

describe('bootstrap-data', () => {
  describe('PREDICATE_ATOMS', () => {
    it('should have unique names', () => {
      const names = PREDICATE_ATOMS.map((a) => a.name);
      const uniqueNames = new Set(names);
      expect(uniqueNames.size).toBe(names.length);
    });

    it('should have non-empty descriptions', () => {
      for (const atom of PREDICATE_ATOMS) {
        expect(atom.description).toBeTruthy();
        expect(atom.description.length).toBeGreaterThan(0);
      }
    });

    it('should have kebab-case names', () => {
      for (const atom of PREDICATE_ATOMS) {
        expect(isValidCapabilityName(atom.name)).toBe(true);
      }
    });
  });

  describe('TYPE_ATOM_DEFINITIONS', () => {
    it('should have unique names', () => {
      const names = TYPE_ATOM_DEFINITIONS.map((a) => a.name);
      const uniqueNames = new Set(names);
      expect(uniqueNames.size).toBe(names.length);
    });

    it('should have non-empty descriptions', () => {
      for (const atom of TYPE_ATOM_DEFINITIONS) {
        expect(atom.description).toBeTruthy();
        expect(atom.description.length).toBeGreaterThan(0);
      }
    });

    it('should have PascalCase names', () => {
      for (const atom of TYPE_ATOM_DEFINITIONS) {
        // Type atoms should be PascalCase (start with uppercase)
        expect(atom.name[0]).toBe(atom.name[0].toUpperCase());
        // Should not contain hyphens
        expect(atom.name).not.toContain('-');
      }
    });
  });

  describe('CAPABILITY_ATOMS', () => {
    it('should have unique names', () => {
      const names = CAPABILITY_ATOMS.map((a) => a.name);
      const uniqueNames = new Set(names);
      expect(uniqueNames.size).toBe(names.length);
    });

    it('should have non-empty descriptions', () => {
      for (const atom of CAPABILITY_ATOMS) {
        expect(atom.description).toBeTruthy();
        expect(atom.description.length).toBeGreaterThan(0);
      }
    });

    it('should have kebab-case names', () => {
      for (const atom of CAPABILITY_ATOMS) {
        expect(isValidCapabilityName(atom.name)).toBe(true);
      }
    });
  });

  describe('getAllFoundationAtoms', () => {
    it('should return all foundation atoms', () => {
      const all = getAllFoundationAtoms();
      const expected =
        PREDICATE_ATOMS.length +
        TYPE_ATOM_DEFINITIONS.length +
        CAPABILITY_ATOMS.length +
        PLATFORM_ATOMS.length;

      expect(all.length).toBe(expected);
    });

    it('should have correct category assignments', () => {
      const all = getAllFoundationAtoms();

      const predicates = all.filter((a): boolean => a.category === 'predicate');
      const types = all.filter((a): boolean => a.category === 'type');
      const capabilities = all.filter((a): boolean => a.category === 'capability');
      const platforms = all.filter((a): boolean => a.category === 'platform');

      expect(predicates.length).toBe(PREDICATE_ATOMS.length);
      expect(types.length).toBe(TYPE_ATOM_DEFINITIONS.length);
      expect(capabilities.length).toBe(CAPABILITY_ATOMS.length);
      expect(platforms.length).toBe(PLATFORM_ATOMS.length);
    });

    it('should have unique names across all categories', () => {
      const all = getAllFoundationAtoms();
      const names = all.map((a) => a.name);
      const uniqueNames = new Set(names);
      expect(uniqueNames.size).toBe(names.length);
    });

    it('should have valid structure for each atom', () => {
      const all = getAllFoundationAtoms();

      for (const atom of all) {
        expect(atom).toHaveProperty('name');
        expect(atom).toHaveProperty('description');
        expect(atom).toHaveProperty('category');

        expect(typeof atom.name).toBe('string');
        expect(typeof atom.description).toBe('string');
        expect(['predicate', 'type', 'capability', 'platform'] as const).toContain(
          atom.category
        );

        expect(atom.name.length).toBeGreaterThan(0);
        expect(atom.description.length).toBeGreaterThan(0);
      }
    });
  });

  describe('cross-category uniqueness', () => {
    it('should have no duplicate names across all atom types', () => {
      const allNames = [
        ...PREDICATE_ATOMS.map((a) => a.name),
        ...TYPE_ATOM_DEFINITIONS.map((a) => a.name),
        ...CAPABILITY_ATOMS.map((a) => a.name),
        ...PLATFORM_ATOMS.map((a) => a.name),
      ];

      const uniqueNames = new Set(allNames);
      expect(uniqueNames.size).toBe(allNames.length);
    });
  });
});
