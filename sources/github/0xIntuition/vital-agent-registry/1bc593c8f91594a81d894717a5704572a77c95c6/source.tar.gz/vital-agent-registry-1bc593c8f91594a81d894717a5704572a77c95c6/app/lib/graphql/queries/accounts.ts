export const GET_ACCOUNT = `
  query GetAccount($id: String!) {
    account(id: $id) {
      id
      atom_id
      label
      image
      cached_image { url safe }
      type
      positions(
        order_by: [{ shares: desc }]
        limit: 20
      ) {
        id
        shares
        account_id
        term_id
      }
    }
  }
`

export const GET_ACCOUNT_WITH_ATOMS = `
  query GetAccountWithAtoms($id: String!, $limit: Int, $offset: Int) {
    account(id: $id) {
      id
      atom_id
      label
      image
      cached_image { url safe }
      type
    }
    atoms(
      where: { creator_id: { _eq: $id } }
      limit: $limit
      offset: $offset
      order_by: [{ created_at: desc }]
    ) {
      term_id
      label
      image
      cached_image { url safe }
      type
      created_at
      data
      creator {
        id
        label
        image
      }
      value {
        person { name image url }
        thing { name image url }
        organization { name image url }
        json_object {
          description: data(path: "description")
        }
      }
      term {
        vaults(order_by: { curve_id: asc }) {
          total_assets
          position_count
          market_cap
        }
      }
    }
  }
`
