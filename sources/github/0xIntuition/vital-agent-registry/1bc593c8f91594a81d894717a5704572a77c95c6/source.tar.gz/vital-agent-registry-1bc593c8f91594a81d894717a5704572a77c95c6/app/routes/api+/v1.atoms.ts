import type { ActionFunctionArgs, LoaderFunctionArgs } from 'react-router'
import { encodeFunctionData, parseEventLogs, toHex, createPublicClient, http } from 'viem'
import { handleOptions, parseJsonBody, jsonResponse, errorResponse, corsHeaders } from '~/lib/api/types'
import { createAtomsSchema } from '~/lib/api/validation'
import { deriveAtomTermId } from '~/lib/calldata'
import { getAtomCost, createAtoms, getAtomByUri, getMinimumDeposit } from '~/.server/multivault'
import { multivaultAbi } from '~/lib/abis/multivault'
import { getContractAddress, getRpcUrl, getChainConfig } from '~/lib/constants/protocol'
import type { NetworkId } from '~/lib/constants/protocol'
import { requireExecuteAuth } from '~/.server/execute-auth'
import { assertRemoteWriteAllowed, RemoteWriteGuardError } from '~/.server/remote-write-guard'
import { createLocalWriteClients, getLocalWriteContext } from '~/.server/local-write'
import { registrationLimiter, getClientIP, isRegistrationRateLimitEnabled } from '~/lib/rate-limit'

/**
 * GET /api/v1/atoms
 *
 * Returns guidance on atom lookup endpoints.
 */
export async function loader({ request }: LoaderFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  return jsonResponse({
    message: 'Use /api/v1/atoms/search to search atoms or /api/v1/atoms/:id to look up a specific atom.',
    endpoints: {
      search: '/api/v1/atoms/search',
      byId: '/api/v1/atoms/:id',
    },
  })
}

/**
 * POST /api/v1/atoms
 *
 * Create generic atoms on-chain.
 *
 * Dual mode:
 * - Default (prepare): Returns derived term IDs + unsigned calldata for client signing.
 *   Requires ALLOW_REMOTE_WRITES=1 (remote-write guard).
 * - ?execute=true: Executes on local chain directly using server-side wallet.
 *
 * Idempotent: atoms that already exist on-chain are skipped.
 */
export async function action({ request }: ActionFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes
  const url = new URL(request.url)
  const execute = url.searchParams.get('execute') === 'true'

  if (execute) {
    const auth = requireExecuteAuth(request)
    if (!auth.authorized) return auth.response
  }

  // Rate limit check (SEC-08)
  if (isRegistrationRateLimitEnabled()) {
    const ip = getClientIP(request)
    const limit = registrationLimiter.check(ip)
    if (!limit.allowed) {
      return new Response(
        JSON.stringify({
          error: 'Too many requests',
          code: 'RATE_LIMITED',
          retryAfter: Math.ceil((limit.resetAt - Date.now()) / 1000),
        }),
        {
          status: 429,
          headers: {
            ...corsHeaders(),
            'Content-Type': 'application/json',
            'Retry-After': String(Math.ceil((limit.resetAt - Date.now()) / 1000)),
          },
        }
      )
    }
  }

  // Parse and validate request body
  const parsed = await parseJsonBody(request, createAtomsSchema)
  if ('error' in parsed) return parsed.error

  const { atomData, depositPerAtom } = parsed.data

  try {
    if (!execute) {
      assertRemoteWriteAllowed({
        action: 'prepare atom creation',
        target: 'chain',
      })
    }

    // Derive term IDs for each atom data string
    const atoms = atomData.map((data) => ({
      data,
      termId: deriveAtomTermId(data),
    }))

    // Get chain config and costs
    const chain = (process.env.CHAIN as NetworkId) || 'testnet'
    const contractAddress = getContractAddress(chain)
    const rpcUrl = getRpcUrl(chain)

    const publicClient = createPublicClient({
      transport: http(rpcUrl),
    })

    const atomCost = await getAtomCost(publicClient, contractAddress)
    const deposit = depositPerAtom ? BigInt(depositPerAtom) : 0n
    const costPerAtom = atomCost + deposit
    const estimatedCost = costPerAtom * BigInt(atomData.length)

    // Encode calldata for batch createAtoms
    const atomDataBytes = atomData.map((data) => toHex(data))
    const deposits = atomData.map(() => deposit)

    const calldata = encodeFunctionData({
      abi: multivaultAbi,
      functionName: 'createAtoms',
      args: [atomDataBytes, deposits],
    })

    const response = {
      atoms,
      calldata,
      estimatedCost: estimatedCost.toString(),
      contractAddress,
      chainId: getChainConfig(chain).chainId,
    }

    if (!execute) {
      return jsonResponse(response)
    }

    // Execute mode: create atoms on local chain
    const context = getLocalWriteContext()
    const { publicClient: localPublicClient, walletClient } = await createLocalWriteClients(context)
    const minimumDeposit = await getMinimumDeposit(localPublicClient, context.contractAddress)

    // Check which atoms already exist (idempotent)
    const existenceChecks = await Promise.all(
      atomData.map(async (data) => {
        const existing = await getAtomByUri(localPublicClient, context.contractAddress, data)
        return { data, existing }
      })
    )

    const newAtomData = existenceChecks.filter((check) => !check.existing).map((check) => check.data)
    const alreadyExisted = existenceChecks
      .filter((check) => check.existing)
      .map((check) => ({
        data: check.data,
        termId: check.existing,
      }))

    let execution: {
      txHash: `0x${string}` | null
      createdCount: number
      createdAtoms: Array<{ data: string; termId: `0x${string}` }>
    } = {
      txHash: null,
      createdCount: 0,
      createdAtoms: [],
    }

    if (newAtomData.length > 0) {
      const result = await createAtoms(
        localPublicClient,
        walletClient,
        context.contractAddress,
        newAtomData,
        minimumDeposit,
      )

      const receipt = await localPublicClient.waitForTransactionReceipt({ hash: result.hash })
      const atomCreatedLogs = parseEventLogs({
        abi: multivaultAbi,
        logs: receipt.logs,
        eventName: 'AtomCreated',
      })

      const createdTermIds = atomCreatedLogs.map((log) => log.args?.termId as `0x${string}`)

      execution = {
        txHash: result.hash,
        createdCount: newAtomData.length,
        createdAtoms: newAtomData.map((data, i) => ({
          data,
          termId: createdTermIds[i] ?? deriveAtomTermId(data),
        })),
      }
    }

    // Build resolved atoms list combining existing + newly created
    const resolvedAtoms = [
      ...alreadyExisted.map((a) => ({
        data: a.data,
        termId: a.termId,
        alreadyExisted: true,
      })),
      ...execution.createdAtoms.map((a) => ({
        data: a.data,
        termId: a.termId,
        alreadyExisted: false,
      })),
    ]

    return jsonResponse({
      ...response,
      atoms: resolvedAtoms,
      execution: {
        mode: 'local',
        executed: true,
        account: walletClient.account?.address ?? null,
        txHash: execution.txHash,
        createdCount: execution.createdCount,
        skippedCount: alreadyExisted.length,
      },
    })
  } catch (error) {
    if (error instanceof RemoteWriteGuardError) {
      return errorResponse(
        'Remote writes are blocked by default in local-safe mode',
        error.code,
        403,
        {
          message: error.message,
          requiredOverride: 'ALLOW_REMOTE_WRITES=1 and REGISTRY_WRITE_PROFILE=shared',
          profile: error.profile,
          target: error.target,
          action: error.action,
        }
      )
    }
    return errorResponse('Atom creation failed', 'INTERNAL_ERROR', 500, {
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
}
