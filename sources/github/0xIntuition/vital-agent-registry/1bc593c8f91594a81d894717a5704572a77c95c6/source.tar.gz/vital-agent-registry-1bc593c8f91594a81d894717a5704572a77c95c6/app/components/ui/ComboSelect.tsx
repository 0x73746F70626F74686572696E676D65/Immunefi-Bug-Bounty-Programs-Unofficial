import { useState, useRef, useEffect, useCallback } from 'react'

export interface ComboOption {
  value: string
  label: string
  group?: string
  description?: string
}

interface ComboSelectProps {
  options: ComboOption[]
  value: string
  onChange: (value: string) => void
  placeholder?: string
  allowCustom?: boolean
  disabled?: boolean
  groupBy?: boolean
  id?: string
  className?: string
}

const INPUT =
  'w-full bg-app-input border border-app-line rounded-lg px-3 py-2.5 text-ink-default font-mono text-sm placeholder:text-ink-faint focus:border-[hsl(var(--accent))] focus:outline-none transition-colors disabled:opacity-50'

export function ComboSelect({
  options,
  value,
  onChange,
  placeholder = 'Select or type...',
  allowCustom = false,
  disabled = false,
  groupBy = false,
  id,
  className,
}: ComboSelectProps) {
  const [query, setQuery] = useState(value)
  const [open, setOpen] = useState(false)
  const [activeIndex, setActiveIndex] = useState(-1)
  const containerRef = useRef<HTMLDivElement>(null)
  const listRef = useRef<HTMLUListElement>(null)

  // Sync query when value changes externally
  useEffect(() => {
    setQuery(value)
  }, [value])

  const filtered = options.filter(
    (o) =>
      o.label.toLowerCase().includes(query.toLowerCase()) ||
      o.value.toLowerCase().includes(query.toLowerCase()),
  )

  const showCustomOption =
    allowCustom &&
    query.trim().length > 0 &&
    !options.some((o) => o.value === query.trim() || o.label.toLowerCase() === query.trim().toLowerCase())

  const totalItems = filtered.length + (showCustomOption ? 1 : 0)

  // Group by group field if requested
  const groups: Record<string, ComboOption[]> = {}
  if (groupBy) {
    for (const opt of filtered) {
      const g = opt.group ?? ''
      groups[g] = groups[g] ?? []
      groups[g].push(opt)
    }
  }

  const flatItems: Array<ComboOption | { custom: true; label: string; value: string }> = [
    ...filtered,
    ...(showCustomOption
      ? [{ custom: true as const, label: `Use custom: "${query.trim()}"`, value: query.trim() }]
      : []),
  ]

  function selectItem(val: string) {
    onChange(val)
    setQuery(val)
    setOpen(false)
    setActiveIndex(-1)
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (!open && (e.key === 'ArrowDown' || e.key === 'Enter')) {
      setOpen(true)
      return
    }

    if (e.key === 'Escape') {
      setOpen(false)
      setActiveIndex(-1)
      return
    }

    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setActiveIndex((i) => Math.min(i + 1, totalItems - 1))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setActiveIndex((i) => Math.max(i - 1, 0))
    } else if (e.key === 'Enter' && activeIndex >= 0) {
      e.preventDefault()
      const item = flatItems[activeIndex]
      if (item) selectItem(item.value)
    }
  }

  // Scroll active item into view
  useEffect(() => {
    if (activeIndex >= 0 && listRef.current) {
      const item = listRef.current.children[activeIndex] as HTMLElement | undefined
      item?.scrollIntoView({ block: 'nearest' })
    }
  }, [activeIndex])

  // Close on outside click
  const handleOutsideClick = useCallback((e: MouseEvent) => {
    if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
      setOpen(false)
      setActiveIndex(-1)
    }
  }, [])

  useEffect(() => {
    document.addEventListener('mousedown', handleOutsideClick)
    return () => document.removeEventListener('mousedown', handleOutsideClick)
  }, [handleOutsideClick])

  function renderOptions() {
    if (!groupBy || Object.keys(groups).length === 0) {
      return flatItems.map((item, i) => (
        <li
          key={item.value}
          role="option"
          aria-selected={i === activeIndex}
          onMouseDown={() => selectItem(item.value)}
          onMouseEnter={() => setActiveIndex(i)}
          className={`px-3 py-2 font-mono text-xs cursor-pointer transition-colors ${
            i === activeIndex
              ? 'bg-[hsl(var(--accent))/0.12] text-[hsl(var(--accent-faint))]'
              : 'text-ink-default hover:bg-app-button'
          } ${'custom' in item ? 'italic text-ink-dull' : ''}`}
        >
          {item.label}
        </li>
      ))
    }

    const rendered: React.ReactNode[] = []
    let flatIdx = 0
    for (const [group, opts] of Object.entries(groups)) {
      rendered.push(
        <li
          key={`group-${group}`}
          className="px-3 pt-2 pb-1 font-mono text-[9px] uppercase tracking-[0.12em] text-ink-faint pointer-events-none"
        >
          {group}
        </li>,
      )
      for (const opt of opts) {
        const idx = flatIdx
        rendered.push(
          <li
            key={opt.value}
            role="option"
            aria-selected={idx === activeIndex}
            onMouseDown={() => selectItem(opt.value)}
            onMouseEnter={() => setActiveIndex(idx)}
            className={`px-3 py-2 font-mono text-xs cursor-pointer transition-colors ${
              idx === activeIndex
                ? 'bg-[hsl(var(--accent))/0.12] text-[hsl(var(--accent-faint))]'
                : 'text-ink-default hover:bg-app-button'
            }`}
          >
            {opt.label}
          </li>,
        )
        flatIdx++
      }
    }
    if (showCustomOption) {
      const customItem = flatItems[flatItems.length - 1]
      rendered.push(
        <li
          key="custom"
          role="option"
          aria-selected={flatIdx === activeIndex}
          onMouseDown={() => selectItem(customItem.value)}
          onMouseEnter={() => setActiveIndex(flatIdx)}
          className={`px-3 py-2 font-mono text-xs italic cursor-pointer transition-colors ${
            flatIdx === activeIndex
              ? 'bg-[hsl(var(--accent))/0.12] text-[hsl(var(--accent-faint))]'
              : 'text-ink-dull hover:bg-app-button'
          }`}
        >
          {customItem.label}
        </li>,
      )
    }
    return rendered
  }

  return (
    <div ref={containerRef} className={`relative ${className ?? ''}`}>
      <input
        id={id}
        type="text"
        value={query}
        onChange={(e) => {
          setQuery(e.target.value)
          setOpen(true)
          setActiveIndex(-1)
          // If empty, clear value
          if (!e.target.value) onChange('')
        }}
        onFocus={() => setOpen(true)}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        disabled={disabled}
        autoComplete="off"
        role="combobox"
        aria-expanded={open}
        aria-autocomplete="list"
        className={INPUT}
      />
      {open && flatItems.length > 0 && (
        <ul
          ref={listRef}
          role="listbox"
          className="absolute z-50 mt-1 w-full max-h-52 overflow-y-auto rounded-lg border border-app-line bg-app-input shadow-lg py-1"
        >
          {renderOptions()}
        </ul>
      )}
    </div>
  )
}
