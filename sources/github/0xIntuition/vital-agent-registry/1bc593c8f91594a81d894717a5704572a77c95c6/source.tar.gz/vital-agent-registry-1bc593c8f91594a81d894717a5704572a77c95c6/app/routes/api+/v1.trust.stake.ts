import type { ActionFunctionArgs } from 'react-router'
import { parseEther } from 'viem'
import { requireExecuteAuth } from '~/.server/execute-auth'
import { errorResponse, handleOptions, jsonResponse, parseJsonBody, corsHeaders } from '~/lib/api/types'
import { trustStakeSchema } from '~/lib/api/validation'
import { createLocalWriteClients, getLocalWriteContext } from '~/.server/local-write'
import { registrationLimiter, getClientIP, isRegistrationRateLimitEnabled } from '~/lib/rate-limit'
import { depositToTerm } from '~/.server/multivault'

export async function action({ request }: ActionFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const auth = requireExecuteAuth(request)
  if (!auth.authorized) return auth.response

  // Rate limit check
  if (isRegistrationRateLimitEnabled()) {
    const ip = getClientIP(request)
    const limit = registrationLimiter.check(ip)
    if (!limit.allowed) {
      return new Response(
        JSON.stringify({
          error: 'Too many requests',
          code: 'RATE_LIMITED',
          retryAfter: Math.ceil((limit.resetAt - Date.now()) / 1000),
        }),
        {
          status: 429,
          headers: {
            ...corsHeaders(),
            'Content-Type': 'application/json',
            'Retry-After': String(Math.ceil((limit.resetAt - Date.now()) / 1000)),
          },
        }
      )
    }
  }

  const parsed = await parseJsonBody(request, trustStakeSchema)
  if ('error' in parsed) return parsed.error

  const { termId, amountWei, amountEth, curveId, direction, minShares } = parsed.data

  // direction maps: 'for' -> curveId 0, 'against' -> curveId 1
  // Explicit curveId takes precedence over direction
  const resolvedCurveId = curveId !== undefined
    ? BigInt(curveId)
    : direction === 'for' ? 0n
    : direction === 'against' ? 1n
    : 0n

  try {
    const context = getLocalWriteContext()
    const { publicClient, walletClient } = await createLocalWriteClients(context)
    const assets = amountWei ? BigInt(amountWei) : parseEther(amountEth!)

    const result = await depositToTerm(publicClient, walletClient, context.contractAddress, {
      termId: termId as `0x${string}`,
      assets,
      curveId: resolvedCurveId,
      minShares: minShares ? BigInt(minShares) : 0n,
    })

    await publicClient.waitForTransactionReceipt({ hash: result.hash })

    return jsonResponse({
      executed: true,
      mode: 'local',
      account: walletClient.account?.address ?? null,
      contractAddress: context.contractAddress,
      termId,
      assetsWei: assets.toString(),
      curveId: result.curveId.toString(),
      direction: result.curveId === 0n ? 'for' : result.curveId === 1n ? 'against' : null,
      txHash: result.hash,
    })
  } catch (error) {
    return errorResponse('Stake transaction failed', 'STAKE_FAILED', 500, {
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
}
