import { describe, expect, it } from 'vitest';
import { SEED_AGENTS, SEED_SKILLS } from './seed-data';
import { AgentMetadataSchema } from '../schemas/agent-metadata';
import { SkillMetadataSchema } from '../schemas/skill-metadata';
import { CAPABILITY_ATOMS } from './bootstrap-data';
import { isValidCapabilityName } from '../capabilities';

describe('seed-data', () => {
  describe('SEED_SKILLS', () => {
    it('should have valid metadata that passes SkillMetadataSchema', () => {
      for (const skill of SEED_SKILLS) {
        const result = SkillMetadataSchema.safeParse(skill.metadata);
        if (!result.success) {
          console.error(
            `Validation failed for skill: ${skill.metadata.name}`,
            result.error
          );
        }
        expect(result.success).toBe(true);
      }
    });

    it('should have unique names', () => {
      const names = SEED_SKILLS.map((s) => s.metadata.name);
      const uniqueNames = new Set(names);
      expect(uniqueNames.size).toBe(names.length);
    });

    it('should reference valid capabilities from CAPABILITY_ATOMS', () => {
      const validCapabilities = new Set<string>(
        CAPABILITY_ATOMS.map((c) => c.name)
      );

      for (const skill of SEED_SKILLS) {
        for (const capability of skill.capabilities) {
          expect(validCapabilities.has(capability)).toBe(true);
        }
      }
    });

    it('should have valid capability names (kebab-case)', () => {
      for (const skill of SEED_SKILLS) {
        for (const capability of skill.capabilities) {
          expect(isValidCapabilityName(capability)).toBe(true);
        }
      }
    });

    it('should have non-empty capability arrays', () => {
      for (const skill of SEED_SKILLS) {
        // Most skills should have at least one capability
        // (but we allow empty arrays for very generic skills)
        expect(Array.isArray(skill.capabilities)).toBe(true);
      }
    });

    it('should have valid semver versions', () => {
      const semverRegex =
        /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$/;

      for (const skill of SEED_SKILLS) {
        expect(semverRegex.test(skill.metadata.version)).toBe(true);
      }
    });

    it('should have descriptions within character limits', () => {
      for (const skill of SEED_SKILLS) {
        expect(skill.metadata.description.length).toBeGreaterThan(0);
        expect(skill.metadata.description.length).toBeLessThanOrEqual(500);
      }
    });

    it('should have names within character limits', () => {
      for (const skill of SEED_SKILLS) {
        expect(skill.metadata.name.length).toBeGreaterThan(0);
        expect(skill.metadata.name.length).toBeLessThanOrEqual(100);
      }
    });
  });

  describe('SEED_AGENTS', () => {
    it('should have valid metadata that passes AgentMetadataSchema', () => {
      for (const agent of SEED_AGENTS) {
        const result = AgentMetadataSchema.safeParse(agent.metadata);
        if (!result.success) {
          console.error(
            `Validation failed for agent: ${agent.metadata.name}`,
            result.error
          );
        }
        expect(result.success).toBe(true);
      }
    });

    it('should have unique names', () => {
      const names = SEED_AGENTS.map((a) => a.metadata.name);
      const uniqueNames = new Set(names);
      expect(uniqueNames.size).toBe(names.length);
    });

    it('should reference valid capabilities from CAPABILITY_ATOMS', () => {
      const validCapabilities = new Set<string>(
        CAPABILITY_ATOMS.map((c) => c.name)
      );

      for (const agent of SEED_AGENTS) {
        for (const capability of agent.capabilities) {
          expect(validCapabilities.has(capability)).toBe(true);
        }
      }
    });

    it('should reference valid skills from SEED_SKILLS', () => {
      const validSkills = new Set(SEED_SKILLS.map((s) => s.metadata.name));

      for (const agent of SEED_AGENTS) {
        for (const skill of agent.skills) {
          expect(validSkills.has(skill)).toBe(true);
        }
      }
    });

    it('should have valid capability names (kebab-case)', () => {
      for (const agent of SEED_AGENTS) {
        for (const capability of agent.capabilities) {
          expect(isValidCapabilityName(capability)).toBe(true);
        }
      }
    });

    it('should have at least one capability', () => {
      for (const agent of SEED_AGENTS) {
        expect(agent.capabilities.length).toBeGreaterThan(0);
      }
    });

    it('should have valid semver versions', () => {
      const semverRegex =
        /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$/;

      for (const agent of SEED_AGENTS) {
        expect(semverRegex.test(agent.metadata.version)).toBe(true);
      }
    });

    it('should have descriptions within character limits', () => {
      for (const agent of SEED_AGENTS) {
        expect(agent.metadata.description.length).toBeGreaterThan(0);
        expect(agent.metadata.description.length).toBeLessThanOrEqual(500);
      }
    });

    it('should have names within character limits', () => {
      for (const agent of SEED_AGENTS) {
        expect(agent.metadata.name.length).toBeGreaterThan(0);
        expect(agent.metadata.name.length).toBeLessThanOrEqual(100);
      }
    });

    it('should have capabilities array with max 10 items if present', () => {
      for (const agent of SEED_AGENTS) {
        if (agent.capabilities) {
          expect(agent.capabilities.length).toBeLessThanOrEqual(10);
        }
      }
    });

    it('should have valid model identifiers', () => {
      for (const agent of SEED_AGENTS) {
        if (agent.metadata.model) {
          expect(agent.metadata.model.length).toBeGreaterThan(0);
        }
      }
    });
  });

  describe('seed data consistency', () => {
    it('should have more agents than skills (typical registry)', () => {
      // This is just a sanity check - not a hard requirement
      expect(SEED_AGENTS.length).toBeGreaterThan(0);
      expect(SEED_SKILLS.length).toBeGreaterThan(0);
    });

    it('should have agents that use at least some of the skills', () => {
      const usedSkills = new Set(
        SEED_AGENTS.flatMap((agent) => agent.skills)
      );

      // At least half of the skills should be used by agents
      expect(usedSkills.size).toBeGreaterThan(0);
    });

    it('should have diverse capability coverage', () => {
      const agentCapabilities = new Set(
        SEED_AGENTS.flatMap((agent) => agent.capabilities)
      );
      const skillCapabilities = new Set(
        SEED_SKILLS.flatMap((skill) => skill.capabilities)
      );

      // Should have at least 6 different capabilities (v3 bootstrap set)
      const allUsedCapabilities = new Set([
        ...agentCapabilities,
        ...skillCapabilities,
      ]);
      expect(allUsedCapabilities.size).toBeGreaterThanOrEqual(6);
    });

    it('should have diverse skill platforms', () => {
      const platforms = new Set(
        SEED_SKILLS.map((skill) => skill.metadata.platform)
      );

      // Should have at least 3 different platforms
      expect(platforms.size).toBeGreaterThanOrEqual(3);
    });
  });
});
