import { describe, it, expect } from 'vitest';
import {
  stringToBytes32,
  bytes32ToString,
  isBytes32,
  stringArrayToBytes32Array,
  bytes32ArrayToStringArray,
  ensureBytes32,
  ensureString,
} from '../id-conversion';

describe('id-conversion', () => {
  describe('stringToBytes32', () => {
    it('should convert decimal string to bytes32', () => {
      const result = stringToBytes32('123');
      expect(result).toMatch(/^0x[0-9a-f]{64}$/);
      expect(result).toBe(
        '0x000000000000000000000000000000000000000000000000000000000000007b'
      );
    });

    it('should convert hex string to bytes32', () => {
      const result = stringToBytes32('0x7b');
      expect(result).toBe(
        '0x000000000000000000000000000000000000000000000000000000000000007b'
      );
    });

    it('should pad short hex strings', () => {
      const result = stringToBytes32('0x1');
      expect(result).toBe(
        '0x0000000000000000000000000000000000000000000000000000000000000001'
      );
    });

    it('should handle large numbers', () => {
      const result = stringToBytes32('999999999999999999');
      expect(result).toMatch(/^0x[0-9a-f]{64}$/);
    });

    it('should throw on empty string', () => {
      expect(() => stringToBytes32('')).toThrow('ID cannot be empty');
    });

    it('should handle already padded bytes32', () => {
      const padded =
        '0x000000000000000000000000000000000000000000000000000000000000007b';
      const result = stringToBytes32(padded);
      expect(result).toBe(padded);
    });
  });

  describe('bytes32ToString', () => {
    it('should convert bytes32 to decimal string', () => {
      const bytes =
        '0x000000000000000000000000000000000000000000000000000000000000007b' as const;
      const result = bytes32ToString(bytes);
      expect(result).toBe('123');
    });

    it('should handle zero value', () => {
      const bytes =
        '0x0000000000000000000000000000000000000000000000000000000000000000' as const;
      const result = bytes32ToString(bytes);
      expect(result).toBe('0');
    });

    it('should handle large values', () => {
      const bytes =
        '0x0000000000000000000000000000000000000000000000000de0b6b3a7640000' as const;
      const result = bytes32ToString(bytes);
      expect(BigInt(result)).toBe(1000000000000000000n);
    });

    it('should throw on invalid hex', () => {
      expect(() => bytes32ToString('not-hex' as any)).toThrow('Invalid bytes32 value');
    });

    it('should throw on empty string', () => {
      expect(() => bytes32ToString('' as any)).toThrow('Invalid bytes32 value');
    });
  });

  describe('isBytes32', () => {
    it('should return true for valid bytes32', () => {
      const valid =
        '0x000000000000000000000000000000000000000000000000000000000000007b';
      expect(isBytes32(valid)).toBe(true);
    });

    it('should return false for short hex', () => {
      expect(isBytes32('0x7b')).toBe(false);
    });

    it('should return false for non-hex', () => {
      expect(isBytes32('123')).toBe(false);
    });

    it('should return false for hex without 0x prefix', () => {
      const withoutPrefix =
        '000000000000000000000000000000000000000000000000000000000000007b';
      expect(isBytes32(withoutPrefix)).toBe(false);
    });

    it('should return false for too long hex', () => {
      const tooLong =
        '0x000000000000000000000000000000000000000000000000000000000000007b00';
      expect(isBytes32(tooLong)).toBe(false);
    });
  });

  describe('stringArrayToBytes32Array', () => {
    it('should convert array of strings to bytes32 array', () => {
      const input = ['123', '456', '0x789'];
      const result = stringArrayToBytes32Array(input);
      expect(result).toHaveLength(3);
      expect(result[0]).toBe(
        '0x000000000000000000000000000000000000000000000000000000000000007b'
      );
      expect(result[1]).toBe(
        '0x00000000000000000000000000000000000000000000000000000000000001c8'
      );
      expect(result[2]).toBe(
        '0x0000000000000000000000000000000000000000000000000000000000000789'
      );
    });

    it('should handle empty array', () => {
      const result = stringArrayToBytes32Array([]);
      expect(result).toEqual([]);
    });
  });

  describe('bytes32ArrayToStringArray', () => {
    it('should convert array of bytes32 to strings', () => {
      const input = [
        '0x000000000000000000000000000000000000000000000000000000000000007b' as const,
        '0x00000000000000000000000000000000000000000000000000000000000001c8' as const,
      ];
      const result = bytes32ArrayToStringArray(input);
      expect(result).toEqual(['123', '456']);
    });

    it('should handle empty array', () => {
      const result = bytes32ArrayToStringArray([]);
      expect(result).toEqual([]);
    });
  });

  describe('ensureBytes32', () => {
    it('should return bytes32 unchanged', () => {
      const bytes =
        '0x000000000000000000000000000000000000000000000000000000000000007b';
      const result = ensureBytes32(bytes);
      expect(result).toBe(bytes);
    });

    it('should convert decimal string to bytes32', () => {
      const result = ensureBytes32('123');
      expect(result).toBe(
        '0x000000000000000000000000000000000000000000000000000000000000007b'
      );
    });
  });

  describe('ensureString', () => {
    it('should convert bytes32 to string', () => {
      const bytes =
        '0x000000000000000000000000000000000000000000000000000000000000007b';
      const result = ensureString(bytes);
      expect(result).toBe('123');
    });

    it('should return non-bytes32 unchanged', () => {
      const result = ensureString('123');
      expect(result).toBe('123');
    });
  });

  describe('round-trip conversion', () => {
    it('should preserve value through string -> bytes32 -> string', () => {
      const original = '123456789';
      const bytes = stringToBytes32(original);
      const back = bytes32ToString(bytes);
      expect(back).toBe(original);
    });

    it('should preserve numeric value through bytes32 -> string -> bytes32', () => {
      const original =
        '0x000000000000000000000000000000000000000000000000000000075bcd15' as const;
      const str = bytes32ToString(original);
      const back = stringToBytes32(str);
      // Values should be numerically equal even if padding differs slightly
      expect(BigInt(back)).toBe(BigInt(original));
    });
  });
});
