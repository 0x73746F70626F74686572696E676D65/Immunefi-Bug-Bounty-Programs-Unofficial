import { useAccount } from 'wagmi'
import type { Triple } from '~/types/triple'
import { cn } from '~/lib/utils'
import { StakePopover } from '~/components/staking/StakePopover'

// ── Constants ─────────────────────────────────────────────────────

const GREEN = '#22c55e'
const RED = '#ef4444'

// ── Props ─────────────────────────────────────────────────────────

export interface EntityStakeInlineProps {
  /** The term ID (atom ID) of the entity to stake on */
  termId: string
  /** Entity name shown in the prompt: "DO YOU TRUST {label}?" */
  label?: string
  className?: string
  onStakeSuccess?: (txHash: string) => void
}

// ── Component ─────────────────────────────────────────────────────

export function EntityStakeInline({ termId, label, className, onStakeSuccess }: EntityStakeInlineProps) {
  const { isConnected } = useAccount()
  const displayName = label?.toUpperCase() ?? 'THIS ENTITY'

  // Synthetic triple for entity-level staking.
  // Uses the atom's own termId as both the triple term_id and all atom refs,
  // with 'is' as the predicate — this lets StakePopover call deposit() on this atom's vault.
  const entityTriple: Triple = {
    term_id: termId,
    counter_term_id: '',
    subject: { term_id: termId, label: label ?? 'Entity', type: 'Unknown' },
    predicate: { term_id: '', label: 'is', type: 'Unknown' },
    object: { term_id: termId, label: label ?? 'Entity', type: 'Unknown' },
    created_at: new Date().toISOString(),
    creator_id: '',
  }

  return (
    <div className={cn('mt-4 pt-4 border-t border-app-line', className)}>
      <div className="flex items-center justify-between gap-3">
        {/* Prompt */}
        {!isConnected ? (
          <span className="font-mono text-xs tracking-widest uppercase text-ink-faint">
            CONNECT WALLET TO STAKE
          </span>
        ) : (
          <span className="font-mono text-xs tracking-widest uppercase">
            <span style={{ color: '#9d9db5' }}>DO YOU TRUST </span>
            <span style={{ color: 'hsl(282 70% 56%)', fontWeight: 900 }}>{displayName}</span>
            <span style={{ color: '#9d9db5' }}>?</span>
          </span>
        )}

        {/* VOUCH / DENY — each opens StakePopover with direction pre-selected */}
        {isConnected && (
          <div className="flex items-center gap-2 flex-shrink-0">
            <StakePopover
              triple={entityTriple}
              presetDirection="for"
              contextLabel={label}
              onStakeSuccess={onStakeSuccess}
              trigger={
                <button
                  type="button"
                  className="flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 font-mono text-[11px] font-bold tracking-widest transition-all"
                  style={{
                    border: `1px solid ${GREEN}4d`,
                    background: `${GREEN}1a`,
                    color: GREEN,
                  }}
                  onMouseEnter={(e) => {
                    const el = e.currentTarget as HTMLButtonElement
                    el.style.background = `${GREEN}26`
                    el.style.boxShadow = `0 0 10px ${GREEN}20`
                  }}
                  onMouseLeave={(e) => {
                    const el = e.currentTarget as HTMLButtonElement
                    el.style.background = `${GREEN}1a`
                    el.style.boxShadow = 'none'
                  }}
                >
                  <span>▲</span> VOUCH
                </button>
              }
            />

            <StakePopover
              triple={entityTriple}
              presetDirection="against"
              contextLabel={label}
              onStakeSuccess={onStakeSuccess}
              trigger={
                <button
                  type="button"
                  className="flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 font-mono text-[11px] font-bold tracking-widest transition-all"
                  style={{
                    border: `1px solid ${RED}4d`,
                    background: `${RED}1a`,
                    color: RED,
                  }}
                  onMouseEnter={(e) => {
                    const el = e.currentTarget as HTMLButtonElement
                    el.style.background = `${RED}26`
                    el.style.boxShadow = `0 0 10px ${RED}20`
                  }}
                  onMouseLeave={(e) => {
                    const el = e.currentTarget as HTMLButtonElement
                    el.style.background = `${RED}1a`
                    el.style.boxShadow = 'none'
                  }}
                >
                  <span>▼</span> DENY
                </button>
              }
            />
          </div>
        )}
      </div>
    </div>
  )
}
