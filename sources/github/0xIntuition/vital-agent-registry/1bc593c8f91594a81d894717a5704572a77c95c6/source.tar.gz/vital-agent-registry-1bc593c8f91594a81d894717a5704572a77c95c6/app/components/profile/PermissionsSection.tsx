import { cn } from '~/lib/utils'
import { findPermissionById, getPermissionRiskColor } from '~/data/permissions'
import type { RiskLevel } from '~/data/permissions'

interface PermissionsSectionProps {
  permissions: string[]
  className?: string
}

function RiskBadge({ risk }: { risk: RiskLevel }) {
  const color = getPermissionRiskColor(risk)
  return (
    <span
      style={{
        fontFamily: 'monospace',
        fontSize: 8,
        fontWeight: 700,
        letterSpacing: '0.06em',
        textTransform: 'uppercase',
        color,
        background: `${color}18`,
        border: `1px solid ${color}40`,
        borderRadius: 3,
        padding: '1px 4px',
      }}
    >
      {risk}
    </span>
  )
}

export function PermissionsSection({ permissions, className }: PermissionsSectionProps) {
  if (permissions.length === 0) return null

  return (
    <div
      className={cn(
        'rounded-[var(--radius-card)] border border-border shadow-[var(--shadow-card)] overflow-hidden',
        className,
      )}
      style={{ background: '#0a0a12' }}
    >
      <div
        style={{
          padding: '9px 16px 7px',
          borderBottom: '1px solid #1e1e2e',
          fontFamily: 'monospace',
          fontSize: 9,
          fontWeight: 700,
          letterSpacing: '0.12em',
          textTransform: 'uppercase',
          color: '#4a4a60',
        }}
      >
        PERMISSIONS ({permissions.length})
      </div>

      <div style={{ padding: '10px 16px', display: 'flex', flexDirection: 'column', gap: 6 }}>
        {permissions.map((permId) => {
          const known = findPermissionById(permId)
          const label = known?.label ?? permId
          const risk = known?.risk ?? 'medium'

          return (
            <div
              key={permId}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '6px 10px',
                borderRadius: 6,
                border: '1px solid #1e1e2e',
                background: '#0e0e16',
              }}
            >
              <span
                style={{
                  fontFamily: 'monospace',
                  fontSize: 11,
                  fontWeight: 700,
                  color: '#e0e0e8',
                  letterSpacing: '0.04em',
                  textTransform: 'uppercase',
                }}
              >
                {label}
              </span>
              <RiskBadge risk={risk} />
            </div>
          )
        })}

        <div
          style={{
            fontFamily: 'monospace',
            fontSize: 8,
            color: '#4a4a60',
            letterSpacing: '0.06em',
            paddingTop: 4,
          }}
        >
          PERMISSIONS ARE INFORMATIONAL — STAKE ON CAPABILITIES TO SIGNAL TRUST
        </div>
      </div>
    </div>
  )
}
