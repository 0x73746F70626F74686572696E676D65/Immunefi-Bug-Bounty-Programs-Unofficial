import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const mocks = vi.hoisted(() => ({
  serverGraphqlRequest: vi.fn(),
}))

vi.mock('~/lib/graphql/client', () => ({
  serverGraphqlRequest: mocks.serverGraphqlRequest,
}))

describe('GET /api/v1/atoms/:id', () => {
  const baseEnv = { ...process.env }
  const termId = '0x1111111111111111111111111111111111111111111111111111111111111111'

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = { ...baseEnv }
  })

  afterEach(() => {
    process.env = { ...baseEnv }
  })

  it('should return atom data when found', async () => {
    const atomData = {
      term_id: termId,
      label: 'Test Atom',
      type: 'Thing',
      data: 'test-atom-data',
      creator: { id: '0xabc', label: 'Creator' },
    }
    mocks.serverGraphqlRequest.mockResolvedValue({ atom: atomData })

    const { loader } = await import('../api+/v1.atoms.$id')
    const response = await loader({
      request: new Request(`http://localhost:4101/api/v1/atoms/${termId}`, {
        method: 'GET',
      }),
      params: { id: termId },
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.term_id).toBe(termId)
    expect(body.data.label).toBe('Test Atom')
    expect(body.data.type).toBe('Thing')
  })

  it('should return 404 when atom is not found', async () => {
    mocks.serverGraphqlRequest.mockResolvedValue({ atom: null })

    const { loader } = await import('../api+/v1.atoms.$id')
    const response = await loader({
      request: new Request(`http://localhost:4101/api/v1/atoms/${termId}`, {
        method: 'GET',
      }),
      params: { id: termId },
      context: {},
    } as never)

    expect(response.status).toBe(404)
    const body = await response.json()
    expect(body.code).toBe('NOT_FOUND')
  })

  it('should return 400 for invalid term ID format', async () => {
    const invalidId = '0xinvalid'

    const { loader } = await import('../api+/v1.atoms.$id')
    const response = await loader({
      request: new Request(`http://localhost:4101/api/v1/atoms/${invalidId}`, {
        method: 'GET',
      }),
      params: { id: invalidId },
      context: {},
    } as never)

    expect(response.status).toBe(400)
    const body = await response.json()
    expect(body.code).toBe('INVALID_ID')
  })

  it('should return 404 when GraphQL is unavailable', async () => {
    mocks.serverGraphqlRequest.mockRejectedValue(new Error('Connection refused'))

    const { loader } = await import('../api+/v1.atoms.$id')
    const response = await loader({
      request: new Request(`http://localhost:4101/api/v1/atoms/${termId}`, {
        method: 'GET',
      }),
      params: { id: termId },
      context: {},
    } as never)

    expect(response.status).toBe(404)
    const body = await response.json()
    expect(body.code).toBe('NOT_FOUND')
  })
})

describe('GET /api/v1/atoms/search', () => {
  const baseEnv = { ...process.env }

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = { ...baseEnv }
  })

  afterEach(() => {
    process.env = { ...baseEnv }
  })

  it('should return search results for valid query', async () => {
    const atoms = [
      { term_id: '0x1111111111111111111111111111111111111111111111111111111111111111', label: 'Web Scraping', type: 'Thing' },
      { term_id: '0x2222222222222222222222222222222222222222222222222222222222222222', label: 'Web Search', type: 'Thing' },
    ]
    mocks.serverGraphqlRequest.mockResolvedValue({ atoms })

    const { loader } = await import('../api+/v1.atoms.search')
    const response = await loader({
      request: new Request('http://localhost:4101/api/v1/atoms/search?q=web', {
        method: 'GET',
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data).toHaveLength(2)
    expect(body.data[0].label).toBe('Web Scraping')
    expect(body.meta.total).toBe(2)
  })

  it('should return empty results when GraphQL fails', async () => {
    mocks.serverGraphqlRequest.mockRejectedValue(new Error('Connection refused'))

    const { loader } = await import('../api+/v1.atoms.search')
    const response = await loader({
      request: new Request('http://localhost:4101/api/v1/atoms/search?q=anything', {
        method: 'GET',
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data).toEqual([])
    expect(body.meta.total).toBe(0)
  })

  it('should return validation error when q param is missing', async () => {
    const { loader } = await import('../api+/v1.atoms.search')
    const response = await loader({
      request: new Request('http://localhost:4101/api/v1/atoms/search', {
        method: 'GET',
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(400)
    const body = await response.json()
    expect(body.code).toBe('VALIDATION_ERROR')
  })

  it('should pass type filter to GraphQL query when provided', async () => {
    mocks.serverGraphqlRequest.mockResolvedValue({ atoms: [] })

    const { loader } = await import('../api+/v1.atoms.search')
    await loader({
      request: new Request('http://localhost:4101/api/v1/atoms/search?q=agent&type=Agent', {
        method: 'GET',
      }),
      params: {},
      context: {},
    } as never)

    expect(mocks.serverGraphqlRequest).toHaveBeenCalledWith(
      expect.any(String),
      expect.any(String),
      expect.objectContaining({ type: 'Agent', searchTerm: '%agent%' }),
    )
  })
})
