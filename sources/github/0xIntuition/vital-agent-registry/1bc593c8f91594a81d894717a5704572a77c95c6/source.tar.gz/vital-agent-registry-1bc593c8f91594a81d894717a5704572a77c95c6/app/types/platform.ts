/**
 * PlatformId — known skill ecosystem identifiers
 */
export type PlatformId = 'mcp' | 'claude-code' | 'openclaw' | 'openai' | 'x402' | 'custom'

/**
 * Platform — a skill ecosystem
 *
 * Platforms are represented as Atoms on-chain per locked decision #17.
 * This enables platform-based filtering and trust signals at the platform level.
 */
export interface Platform {
  /** Unique identifier slug (e.g. "mcp", "claude-code", "openclaw") */
  id: PlatformId
  /** Human-readable name */
  name: string
  /** Platform description */
  description: string
  /** Icon URL */
  icon?: string
  /** Platform homepage */
  url?: string
}
