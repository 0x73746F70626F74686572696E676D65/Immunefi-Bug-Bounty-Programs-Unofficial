export const GET_POSITIONS_FOR_VAULT = `
  query GetPositionsForVault(
    $termId: String!
    $limit: Int
    $offset: Int
  ) {
    positions(
      where: { term_id: { _eq: $termId } }
      limit: $limit
      offset: $offset
      order_by: [{ shares: desc }]
    ) {
      id
      shares
      account_id
      account {
        id
        atom_id
        label
        image
        cached_image { url safe }
        type
      }
    }
  }
`
