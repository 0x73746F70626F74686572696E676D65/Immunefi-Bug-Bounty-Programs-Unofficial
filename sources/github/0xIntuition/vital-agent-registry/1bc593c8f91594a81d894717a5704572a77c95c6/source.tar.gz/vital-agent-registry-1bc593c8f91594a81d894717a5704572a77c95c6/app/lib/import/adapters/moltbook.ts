import type { AgentImportFields, ImportError } from '../types'

interface MoltbookApiResponse {
  name?: string
  username?: string
  description?: string
  bio?: string
  endpoint?: string
  model?: string
  provider?: string
  providerUrl?: string
  avatar?: string
  image?: string
  capabilities?: string[]
  tags?: string[]
}

function parseMoltbookResponse(data: MoltbookApiResponse, slug: string): AgentImportFields {
  return {
    type: 'agent',
    name: data.name ?? data.username ?? slug,
    description: data.description ?? data.bio,
    endpoint: data.endpoint,
    model: data.model,
    providerName: data.provider,
    providerUrl: data.providerUrl,
    image: data.avatar ?? data.image,
    capabilities: data.capabilities ?? data.tags,
  }
}

function extractMetaTag(html: string, property: string): string | undefined {
  const match =
    html.match(
      new RegExp(
        `<meta[^>]+(?:property|name)=["']${property}["'][^>]+content=["']([^"']+)["']`,
        'i',
      ),
    ) ??
    html.match(
      new RegExp(
        `<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']${property}["']`,
        'i',
      ),
    )
  return match?.[1]
}

function parseMoltbookHtml(html: string, slug: string): AgentImportFields {
  return {
    type: 'agent',
    name: extractMetaTag(html, 'og:title') ?? slug,
    description:
      extractMetaTag(html, 'og:description') ?? extractMetaTag(html, 'description'),
    image: extractMetaTag(html, 'og:image'),
  }
}

export async function fetchMoltbookAgent(slug: string): Promise<AgentImportFields> {
  // Try JSON API first
  try {
    const apiUrl = `https://moltbook.com/api/users/${slug}`
    const response = await fetch(apiUrl, {
      headers: { Accept: 'application/json', 'User-Agent': 'IntuitionRegistry/1.0' },
      signal: AbortSignal.timeout(8000),
    })

    if (response.ok) {
      const data = (await response.json()) as MoltbookApiResponse
      return parseMoltbookResponse(data, slug)
    }
  } catch {
    // Fall through to HTML scraping
  }

  // Fall back to HTML meta tags
  const pageUrl = `https://moltbook.com/u/${slug}`
  const response = await fetch(pageUrl, {
    headers: { 'User-Agent': 'IntuitionRegistry/1.0' },
    signal: AbortSignal.timeout(8000),
  })

  if (!response.ok) {
    const err: ImportError = {
      code: response.status === 404 ? 'NOT_FOUND' : 'FETCH_FAILED',
      message: `Moltbook returned ${response.status} for user "${slug}"`,
    }
    throw err
  }

  const html = await response.text()
  return parseMoltbookHtml(html, slug)
}
