import { useState, useRef, useEffect } from 'react'
import type { TrustTier } from '~/types/vault'

interface TrustTierTooltipProps {
  tier: TrustTier
  percentile: number
  children: React.ReactNode // the badge element
}

/**
 * Tier explanation text for each trust tier
 */
const TIER_EXPLANATIONS: Record<TrustTier, string> = {
  platinum: 'Top 10% — Highest trust among all registered agents',
  gold: 'Top 25% — Well-established with significant backing',
  silver: 'Top 50% — Growing trust from the community',
  bronze: 'Top 75% — Emerging agent with initial backing',
  unranked: 'Below minimum threshold for trust ranking',
}

/**
 * TrustTierTooltip — show tier explanation on hover/tap
 *
 * Wraps a trust tier badge and shows a tooltip with:
 * - Tier name and meaning
 * - Percentile value
 * - Formula breakdown
 *
 * Accessible: Uses aria-describedby to link badge to tooltip content.
 * Dismisses on click outside or mouse leave.
 */
export function TrustTierTooltip({ tier, percentile, children }: TrustTierTooltipProps) {
  const [isOpen, setIsOpen] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)
  const tooltipId = useRef(`trust-tooltip-${Math.random().toString(36).slice(2, 9)}`)

  // Close on click outside
  useEffect(() => {
    if (!isOpen) return

    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [isOpen])

  const handleToggle = () => {
    setIsOpen((prev) => !prev)
  }

  const handleMouseEnter = () => {
    setIsOpen(true)
  }

  const handleMouseLeave = () => {
    setIsOpen(false)
  }

  return (
    <div
      ref={containerRef}
      className="relative inline-block"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {/* Badge (wrapped children) */}
      <div
        onClick={handleToggle}
        aria-describedby={isOpen ? tooltipId.current : undefined}
        className="cursor-help"
      >
        {children}
      </div>

      {/* Tooltip */}
      {isOpen && (
        <div
          id={tooltipId.current}
          role="tooltip"
          className="absolute z-50 w-64 p-3 mt-2 bg-neutral-900 text-white text-sm rounded-lg shadow-lg left-0 top-full"
        >
          {/* Arrow */}
          <div className="absolute -top-1 left-4 w-2 h-2 bg-neutral-900 transform rotate-45" />

          {/* Tier Name & Explanation */}
          <div className="mb-2">
            <div className="font-semibold capitalize mb-1">
              {tier} Tier
            </div>
            <div className="text-neutral-300 text-xs">
              {TIER_EXPLANATIONS[tier]}
            </div>
          </div>

          {/* Percentile */}
          <div className="mb-2 text-xs text-neutral-400">
            <span className="font-medium text-white">{percentile}th</span> percentile
          </div>

          {/* Formula Breakdown */}
          <div className="pt-2 border-t border-neutral-700">
            <div className="text-xs text-neutral-400 leading-relaxed">
              <div className="font-medium text-white mb-1">Score Formula:</div>
              <div>0.4 × TVL rank</div>
              <div>0.4 × staker rank</div>
              <div>0.2 × share price rank</div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
