import { useState, useMemo } from 'react'
import { useLoaderData, useNavigate } from 'react-router'
import { createRepository } from '~/data'
import { RegistryLayout } from '~/components/layout/RegistryLayout'
import { TrustTierBadge } from '~/components/registry/TrustTierBadge'
import type { Agent } from '~/types/agent'
import type { Skill } from '~/types/skill'
import { generateAvatar } from '~/lib/avatar'

export function meta() {
  return [
    { title: 'Leaderboard — Intuition' },
    { name: 'description', content: 'Top agents and skills ranked by trust signal on Intuition.' },
  ]
}

type EntityType = 'all' | 'agents' | 'skills'

interface RankedItem {
  type: 'agent' | 'skill'
  id: string
  name: string
  description: string
  score: number
  tier: Agent['trustSignal']['tier']
  stakerCount: number
  totalStaked: string
}

export async function loader() {
  const repo = createRepository()
  const [agentResult, skillResult] = await Promise.all([
    repo.listAgents({ limit: 100 }),
    repo.listSkills({ limit: 100 }),
  ])
  return {
    agents: agentResult.items,
    skills: skillResult.items,
  }
}

function toRankedItem(entity: Agent | Skill, type: 'agent' | 'skill'): RankedItem {
  return {
    type,
    id: entity.id,
    name: entity.metadata.name,
    description: entity.metadata.description,
    score: Math.round(entity.trustSignal.percentile),
    tier: entity.trustSignal.tier,
    stakerCount: entity.trustSignal.stakerCount,
    totalStaked: entity.trustSignal.totalStaked,
  }
}

// ── Tier color map ──────────────────────────────────────────────────────────

const TIER_COLORS: Record<string, string> = {
  platinum: '#6366f1',
  gold: '#eab308',
  silver: '#94a3b8',
  bronze: '#cd7c2f',
  unranked: '#525252',
}

function tierColor(tier: string): string {
  return TIER_COLORS[tier] ?? TIER_COLORS.unranked
}

// ── Mini trust bar ──────────────────────────────────────────────────────────

function TrustBar({ score }: { score: number }) {
  const color =
    score >= 80 ? '#22c55e'
    : score >= 50 ? '#eab308'
    : '#ef4444'

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      <div
        style={{
          width: 56,
          height: 4,
          background: '#1e1e2e',
          borderRadius: 2,
          overflow: 'hidden',
          flexShrink: 0,
        }}
      >
        <div
          style={{
            height: '100%',
            width: `${score}%`,
            background: color,
            boxShadow: `0 0 6px ${color}60`,
            borderRadius: 2,
          }}
        />
      </div>
      <span
        style={{
          fontFamily: 'monospace',
          fontSize: 11,
          fontWeight: 700,
          color,
          letterSpacing: '-0.02em',
          minWidth: 26,
          textAlign: 'right',
        }}
      >
        {score}
      </span>
    </div>
  )
}

// ── Rank medal badge ────────────────────────────────────────────────────────

const MEDAL_BG: Record<1 | 2 | 3, string> = {
  1: '#eab308',
  2: '#94a3b8',
  3: '#cd7c2f',
}

const MEDAL_TEXT: Record<1 | 2 | 3, string> = {
  1: '#000',
  2: '#000',
  3: '#fff',
}

// ── PodiumCard ──────────────────────────────────────────────────────────────

function PodiumCard({
  item,
  rank,
  onClick,
}: {
  item: RankedItem
  rank: 1 | 2 | 3
  onClick: () => void
}) {
  const medalBg = MEDAL_BG[rank]
  const medalText = MEDAL_TEXT[rank]
  const isFirst = rank === 1
  const color = tierColor(item.tier)
  const avatarSrc = generateAvatar(item.id, 48)

  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        position: 'relative',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: '20px 12px 16px',
        borderRadius: 12,
        background: isFirst ? '#0e0e1a' : '#0a0a12',
        border: `1px solid ${isFirst ? `${color}50` : '#1e1e2e'}`,
        cursor: 'pointer',
        transition: 'transform 0.15s, border-color 0.15s',
        minHeight: isFirst ? 200 : 168,
        ...(isFirst && {
          animation: 'glow-pulse 2s ease-in-out infinite',
        }),
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = 'scale(1.025)'
        e.currentTarget.style.borderColor = `${color}80`
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = 'scale(1)'
        e.currentTarget.style.borderColor = isFirst ? `${color}50` : '#1e1e2e'
      }}
    >
      {/* Rank badge */}
      <div
        style={{
          position: 'absolute',
          top: -12,
          width: 24,
          height: 24,
          borderRadius: '50%',
          background: medalBg,
          color: medalText,
          fontFamily: 'monospace',
          fontSize: 11,
          fontWeight: 900,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          ...(isFirst && { boxShadow: `0 0 12px ${medalBg}80` }),
        }}
      >
        {rank}
      </div>

      {/* Avatar */}
      <img
        src={avatarSrc}
        alt={item.name}
        width={isFirst ? 48 : 40}
        height={isFirst ? 48 : 40}
        style={{
          borderRadius: '50%',
          marginBottom: 10,
          ...(isFirst && {
            boxShadow: `0 0 16px ${color}50`,
            border: `1.5px solid ${color}60`,
          }),
        }}
      />

      {/* Name */}
      <p
        style={{
          fontFamily: 'monospace',
          fontSize: isFirst ? 12 : 11,
          fontWeight: 700,
          color: '#e0e0e8',
          letterSpacing: '0.03em',
          textAlign: 'center',
          maxWidth: '100%',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
          marginBottom: 4,
        }}
      >
        {item.name}
      </p>

      {/* Score */}
      <p
        style={{
          fontFamily: 'monospace',
          fontSize: isFirst ? 28 : 22,
          fontWeight: 900,
          color,
          letterSpacing: '-0.04em',
          lineHeight: 1,
          marginBottom: 6,
          ...(isFirst && { textShadow: `0 0 12px ${color}80` }),
        }}
      >
        {item.score}
      </p>

      {/* Tier badge */}
      <TrustTierBadge tier={item.tier} size="sm" />

      {/* Type tag */}
      <span
        style={{
          marginTop: 6,
          fontFamily: 'monospace',
          fontSize: 9,
          letterSpacing: '0.12em',
          textTransform: 'uppercase',
          color: item.type === 'agent' ? 'hsl(282,70%,56%)' : '#22c55e',
          background: item.type === 'agent' ? 'hsl(282,70%,56%,0.1)' : '#22c55e1a',
          padding: '2px 6px',
          borderRadius: 4,
        }}
      >
        {item.type}
      </span>
    </button>
  )
}

// ── StatsBar ────────────────────────────────────────────────────────────────

function StatsBar({ items }: { items: RankedItem[] }) {
  const totalStakers = items.reduce((sum, item) => sum + item.stakerCount, 0)
  const agentCount = items.filter((i) => i.type === 'agent').length
  const skillCount = items.filter((i) => i.type === 'skill').length
  const topScore = items[0]?.score ?? 0

  const stats = [
    { label: 'ENTITIES', value: String(items.length) },
    { label: 'AGENTS', value: String(agentCount) },
    { label: 'SKILLS', value: String(skillCount) },
    { label: 'STAKERS', value: String(totalStakers) },
    { label: 'TOP SCORE', value: String(topScore) },
  ]

  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: `repeat(${stats.length}, 1fr)`,
        gap: 1,
        background: '#1e1e2e',
        borderRadius: 10,
        overflow: 'hidden',
        border: '1px solid #1e1e2e',
      }}
    >
      {stats.map(({ label, value }) => (
        <div
          key={label}
          style={{
            background: '#0a0a12',
            padding: '10px 14px',
            display: 'flex',
            flexDirection: 'column',
            gap: 3,
          }}
        >
          <span
            style={{
              fontFamily: 'monospace',
              fontSize: 8,
              letterSpacing: '0.14em',
              textTransform: 'uppercase',
              color: '#4a4a60',
            }}
          >
            {label}
          </span>
          <span
            style={{
              fontFamily: 'monospace',
              fontSize: 18,
              fontWeight: 900,
              color: '#e0e0e8',
              letterSpacing: '-0.03em',
              lineHeight: 1,
            }}
          >
            {value}
          </span>
        </div>
      ))}
    </div>
  )
}

// ── Main page ───────────────────────────────────────────────────────────────

export default function LeaderboardPage() {
  const { agents, skills } = useLoaderData<typeof loader>()
  const navigate = useNavigate()
  const [tab, setTab] = useState<EntityType>('all')

  const ranked = useMemo(() => {
    let items: RankedItem[] = []

    if (tab === 'all' || tab === 'agents') {
      items = items.concat(agents.map(a => toRankedItem(a, 'agent')))
    }
    if (tab === 'all' || tab === 'skills') {
      items = items.concat(skills.map(s => toRankedItem(s, 'skill')))
    }

    items.sort((a, b) => b.score - a.score)
    return items
  }, [agents, skills, tab])

  const podium = ranked.slice(0, 3)
  const table = ranked.slice(3)

  const goToDetail = (item: RankedItem) => {
    navigate(item.type === 'agent' ? `/agents/${item.id}` : `/skills/${item.id}`)
  }

  const tabs: { value: EntityType; label: string; count: number }[] = [
    { value: 'all', label: 'ALL', count: agents.length + skills.length },
    { value: 'agents', label: 'AGENTS', count: agents.length },
    { value: 'skills', label: 'SKILLS', count: skills.length },
  ]

  return (
    <RegistryLayout
      header={
        <div className="space-y-4 py-4">
          <div className="flex flex-col gap-1">
            <h1
              style={{
                fontFamily: 'monospace',
                fontSize: 20,
                fontWeight: 900,
                letterSpacing: '0.06em',
                textTransform: 'uppercase',
                color: '#e0e0e8',
              }}
            >
              LEADERBOARD
            </h1>
            <p
              style={{
                fontFamily: 'monospace',
                fontSize: 10,
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                color: '#4a4a60',
              }}
            >
              RANKED BY TRUST SIGNAL
            </p>
          </div>

          {/* Tab segmented control */}
          <div
            style={{
              display: 'flex',
              gap: 2,
              padding: 3,
              borderRadius: 10,
              background: '#0a0a12',
              border: '1px solid #1e1e2e',
            }}
          >
            {tabs.map(({ value, label, count }) => {
              const isActive = tab === value
              return (
                <button
                  key={value}
                  type="button"
                  onClick={() => setTab(value)}
                  style={{
                    flex: 1,
                    padding: '7px 12px',
                    borderRadius: 7,
                    border: 'none',
                    background: isActive ? 'hsl(282,70%,56%,0.15)' : 'transparent',
                    color: isActive ? 'hsl(282,70%,70%)' : '#4a4a60',
                    fontFamily: 'monospace',
                    fontSize: 10,
                    fontWeight: 700,
                    letterSpacing: '0.1em',
                    cursor: 'pointer',
                    transition: 'background 0.15s, color 0.15s',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 6,
                    ...(isActive && { boxShadow: '0 0 0 1px hsl(282,70%,56%,0.3)' }),
                  }}
                >
                  {label}
                  <span
                    style={{
                      fontSize: 9,
                      color: isActive ? 'hsl(282,70%,56%)' : '#4a4a60',
                      letterSpacing: '0',
                    }}
                  >
                    ({count})
                  </span>
                </button>
              )
            })}
          </div>
        </div>
      }
    >
      <div className="space-y-5 py-6">

        {/* Podium */}
        {podium.length >= 3 ? (
          <div className="grid grid-cols-3 items-end gap-3 px-2">
            {/* 2nd place — left */}
            <PodiumCard item={podium[1]} rank={2} onClick={() => goToDetail(podium[1])} />
            {/* 1st place — center */}
            <PodiumCard item={podium[0]} rank={1} onClick={() => goToDetail(podium[0])} />
            {/* 3rd place — right */}
            <PodiumCard item={podium[2]} rank={3} onClick={() => goToDetail(podium[2])} />
          </div>
        ) : (
          <div className="grid grid-cols-3 items-end gap-3 px-2">
            {podium.map((item, i) => (
              <PodiumCard
                key={item.id}
                item={item}
                rank={(i + 1) as 1 | 2 | 3}
                onClick={() => goToDetail(item)}
              />
            ))}
          </div>
        )}

        {/* Stats bar */}
        <StatsBar items={ranked} />

        {/* Ranked table — 4th place and below */}
        {table.length > 0 && (
          <div
            style={{
              borderRadius: 12,
              background: '#0a0a12',
              border: '1px solid #1e1e2e',
              overflow: 'hidden',
            }}
          >
            {/* Table header */}
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: '44px 1fr 72px 110px 52px 80px',
                padding: '8px 16px',
                borderBottom: '1px solid #1e1e2e',
                background: '#06060e',
              }}
            >
              {['#', 'NAME', 'TYPE', 'TRUST', 'STAKERS', 'STAKED'].map((col) => (
                <span
                  key={col}
                  style={{
                    fontFamily: 'monospace',
                    fontSize: 8,
                    fontWeight: 700,
                    letterSpacing: '0.14em',
                    textTransform: 'uppercase',
                    color: '#4a4a60',
                    ...(col !== '#' && col !== 'NAME' ? { textAlign: 'right' as const } : {}),
                  }}
                >
                  {col}
                </span>
              ))}
            </div>

            {/* Table rows */}
            {table.map((item, i) => {
              const rank = i + 4
              const avatarSrc = generateAvatar(item.id, 32)
              const tierCol = tierColor(item.tier)

              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => goToDetail(item)}
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '44px 1fr 72px 110px 52px 80px',
                    padding: '10px 16px',
                    width: '100%',
                    border: 'none',
                    borderBottom: '1px solid #1e1e2e',
                    background: i % 2 === 0 ? '#0a0a12' : '#080810',
                    cursor: 'pointer',
                    textAlign: 'left',
                    transition: 'background 0.12s',
                    alignItems: 'center',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = '#14141f'
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = i % 2 === 0 ? '#0a0a12' : '#080810'
                  }}
                >
                  {/* Rank */}
                  <span
                    style={{
                      fontFamily: 'monospace',
                      fontSize: 12,
                      fontWeight: 700,
                      color: '#2a2a40',
                    }}
                  >
                    {rank}
                  </span>

                  {/* Name + avatar */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
                    <img
                      src={avatarSrc}
                      alt={item.name}
                      width={24}
                      height={24}
                      style={{
                        borderRadius: '50%',
                        flexShrink: 0,
                        border: `1px solid ${tierCol}40`,
                      }}
                    />
                    <div style={{ minWidth: 0 }}>
                      <div
                        style={{
                          fontFamily: 'monospace',
                          fontSize: 11,
                          fontWeight: 700,
                          color: '#e0e0e8',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap',
                          letterSpacing: '0.02em',
                        }}
                      >
                        {item.name}
                      </div>
                      <TrustTierBadge tier={item.tier} size="sm" />
                    </div>
                  </div>

                  {/* Type badge */}
                  <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <span
                      style={{
                        fontFamily: 'monospace',
                        fontSize: 8,
                        fontWeight: 700,
                        letterSpacing: '0.1em',
                        textTransform: 'uppercase',
                        color: item.type === 'agent' ? 'hsl(282,70%,60%)' : '#22c55e',
                        background: item.type === 'agent' ? 'hsl(282,70%,56%,0.12)' : '#22c55e18',
                        border: `1px solid ${item.type === 'agent' ? 'hsl(282,70%,56%,0.25)' : '#22c55e30'}`,
                        padding: '2px 5px',
                        borderRadius: 4,
                      }}
                    >
                      {item.type}
                    </span>
                  </div>

                  {/* Trust score + bar */}
                  <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <TrustBar score={item.score} />
                  </div>

                  {/* Stakers */}
                  <span
                    style={{
                      fontFamily: 'monospace',
                      fontSize: 11,
                      color: '#4a4a60',
                      textAlign: 'right',
                    }}
                  >
                    {item.stakerCount}
                  </span>

                  {/* Staked */}
                  <span
                    style={{
                      fontFamily: 'monospace',
                      fontSize: 10,
                      color: '#4a4a60',
                      textAlign: 'right',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {item.totalStaked}
                  </span>
                </button>
              )
            })}
          </div>
        )}

        {ranked.length === 0 && (
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '64px 0',
              gap: 8,
            }}
          >
            <p
              style={{
                fontFamily: 'monospace',
                fontSize: 11,
                fontWeight: 700,
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                color: '#4a4a60',
              }}
            >
              NO ENTITIES FOUND
            </p>
            <p
              style={{
                fontFamily: 'monospace',
                fontSize: 9,
                letterSpacing: '0.08em',
                color: '#2a2a40',
                textTransform: 'uppercase',
              }}
            >
              REGISTER AGENTS OR SKILLS TO POPULATE THE LEADERBOARD
            </p>
          </div>
        )}
      </div>
    </RegistryLayout>
  )
}
