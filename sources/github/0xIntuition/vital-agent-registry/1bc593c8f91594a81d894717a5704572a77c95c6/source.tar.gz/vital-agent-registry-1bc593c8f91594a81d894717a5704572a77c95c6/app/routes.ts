import { flatRoutes } from '@react-router/fs-routes'
import { route, type RouteConfig } from '@react-router/dev/routes'

export default (async () => {
  const fileRoutes = await flatRoutes({
    ignoredRouteFiles: ['**/api+/**', '**/[.]well-known+/**'],
  })

  const machineRoutes = [
    route('.well-known/agent.json', 'routes/[.]well-known+/agent[.]json.ts'),
    route('api/graphql', 'routes/api+/graphql.ts'),
    route('api/v1/agents', 'routes/api+/v1.agents.ts'),
    route('api/v1/agents/register', 'routes/api+/v1.agents.register.ts'),
    route('api/v1/agents/match', 'routes/api+/v1.agents.match.ts'),
    route('api/v1/agents/:id', 'routes/api+/v1.agents.$id.ts'),
    route('api/v1/agents/:id/card', 'routes/api+/v1.agents.$id.card.ts'),
    route('api/v1/agents/:id/trust', 'routes/api+/v1.agents.$id.trust.ts'),
    route('api/v1/agents/:id/erc8004', 'routes/api+/v1.agents.$id.erc8004.ts'),
    route('api/v1/skills', 'routes/api+/v1.skills.ts'),
    route('api/v1/skills/register', 'routes/api+/v1.skills.register.ts'),
    route('api/v1/skills/verify', 'routes/api+/v1.skills.verify.ts'),
    route('api/v1/skills/:id', 'routes/api+/v1.skills.$id.ts'),
    route('api/v1/skills/:id/safety', 'routes/api+/v1.skills.$id.safety.ts'),
    route('api/v1/skills/:id/agents', 'routes/api+/v1.skills.$id.agents.ts'),
    route('api/v1/capabilities', 'routes/api+/v1.capabilities.ts'),
    route('api/v1/platforms', 'routes/api+/v1.platforms.ts'),
    route('api/v1/predicates', 'routes/api+/v1.predicates.ts'),
    route('api/v1/recipes', 'routes/api+/v1.recipes.ts'),
    route('api/v1/trust/score', 'routes/api+/v1.trust.score.ts'),
    route('api/v1/trust/stake', 'routes/api+/v1.trust.stake.ts'),
    route('api/v1/evidence/:id', 'routes/api+/v1.evidence.$id.ts'),
    route('api/v1/context/query', 'routes/api+/v1.context.query.ts'),
    route('api/v1/metadata/update', 'routes/api+/v1.metadata.update.ts'),
    route(
      'api/v1/onboarding/agents/:id/readiness',
      'routes/api+/v1.onboarding.agents.$id.readiness.ts',
    ),
    route('api/v1/onboarding/wallet-plan', 'routes/api+/v1.onboarding.wallet-plan.ts'),
    route('api/v1/onboarding/funding-plan', 'routes/api+/v1.onboarding.funding-plan.ts'),
  ]

  return [...fileRoutes, ...machineRoutes]
})() satisfies RouteConfig
