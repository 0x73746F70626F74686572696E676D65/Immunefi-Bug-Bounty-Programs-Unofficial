import { useEffect, useRef, useState, useMemo, useCallback } from 'react'
import {
  forceSimulation,
  forceManyBody,
  forceLink,
  forceCenter,
  forceCollide,
  type SimulationNodeDatum,
  type SimulationLinkDatum,
} from 'd3-force'
import type { Agent } from '~/types/agent'
import type { Skill } from '~/types/skill'
import type { TrustTier } from '~/types/vault'
import type { SafetyStatus } from '~/types/skill'
import { useViewMode } from '~/lib/providers/view-mode'

interface TrustGraphProps {
  agents: Agent[]
  skills: Skill[]
  focusEntityId?: string  // For 1-hop filtering (used in Plan 06-02)
  onNodeClick?: (entityId: string, entityType: 'agent' | 'skill') => void
  className?: string
  compact?: boolean  // For profile-embedded use (smaller, no labels)
}

interface GraphNode extends SimulationNodeDatum {
  id: string
  name: string
  entityType: 'agent' | 'skill'
  trustTier: TrustTier
  trustPercentile: number
  stakerCount: number
  image?: string
  // Skill-specific
  safetyStatus?: SafetyStatus
  platformName?: string
}

interface GraphLink extends SimulationLinkDatum<GraphNode> {
  source: string | GraphNode
  target: string | GraphNode
  predicate: string
}

const TIER_COLORS: Record<TrustTier, string> = {
  platinum: 'var(--brand, #6366f1)',
  gold: '#eab308',
  silver: '#94a3b8',
  bronze: '#cd7c2f',
  unranked: '#525252',
}

const SAFETY_COLORS: Record<SafetyStatus, string> = {
  verified: '#22c55e',
  unverified: '#94a3b8',
  flagged: '#ef4444',
}

/**
 * Extract relationships from triple data on agents and skills
 * Only include edges where both source AND target exist in current node set
 */
function buildRelationshipsFromTriples(
  agents: Agent[],
  skills: Skill[],
): { source: string; target: string; predicate: string }[] {
  const relationships: { source: string; target: string; predicate: string }[] = []
  const entityIds = new Set([
    ...agents.map(a => a.id),
    ...skills.map(s => s.id),
  ])

  // Process agent triples
  for (const agent of agents) {
    for (const triple of agent.triples) {
      // Only include if both entities are in our current set
      if (entityIds.has(triple.subject.term_id) && entityIds.has(triple.object.term_id)) {
        relationships.push({
          source: triple.subject.term_id,
          target: triple.object.term_id,
          predicate: triple.predicate.label,
        })
      }
    }
  }

  // Process skill triples
  for (const skill of skills) {
    for (const triple of skill.triples) {
      // Only include if both entities are in our current set
      if (entityIds.has(triple.subject.term_id) && entityIds.has(triple.object.term_id)) {
        relationships.push({
          source: triple.subject.term_id,
          target: triple.object.term_id,
          predicate: triple.predicate.label,
        })
      }
    }
  }

  return relationships
}

/**
 * Filter graph to show only entities 1-hop away from focus
 */
function filterGraphData(
  agents: Agent[],
  skills: Skill[],
  relationships: { source: string; target: string; predicate: string }[],
  focusEntityId?: string,
): { nodes: GraphNode[]; links: GraphLink[] } {
  // Build all nodes
  const allNodes: GraphNode[] = [
    ...agents.map((agent) => ({
      id: agent.id,
      name: agent.metadata.name,
      entityType: 'agent' as const,
      trustTier: agent.trustSignal.tier,
      trustPercentile: agent.trustSignal.percentile,
      stakerCount: agent.trustSignal.stakerCount,
      image: agent.metadata.image,
    })),
    ...skills.map((skill) => ({
      id: skill.id,
      name: skill.metadata.name,
      entityType: 'skill' as const,
      trustTier: skill.trustSignal.tier,
      trustPercentile: skill.trustSignal.percentile,
      stakerCount: skill.trustSignal.stakerCount,
      image: skill.metadata.image,
      safetyStatus: skill.safetySignal.status,
      platformName: skill.platform.name,
    })),
  ]

  // If no focus, return everything
  if (!focusEntityId) {
    const links: GraphLink[] = relationships.map((rel) => ({
      source: rel.source,
      target: rel.target,
      predicate: rel.predicate,
    }))
    return { nodes: allNodes, links }
  }

  // Filter to 1-hop neighbors
  const connectedIds = new Set<string>([focusEntityId])
  for (const rel of relationships) {
    if (rel.source === focusEntityId) {
      connectedIds.add(rel.target)
    }
    if (rel.target === focusEntityId) {
      connectedIds.add(rel.source)
    }
  }

  const nodes = allNodes.filter((node) => connectedIds.has(node.id))
  const links: GraphLink[] = relationships
    .filter((rel) => connectedIds.has(rel.source) && connectedIds.has(rel.target))
    .map((rel) => ({
      source: rel.source,
      target: rel.target,
      predicate: rel.predicate,
    }))

  return { nodes, links }
}

function getNodeRadius(trustPercentile: number, compact?: boolean): number {
  const base = compact ? 6 : 8
  const scale = compact ? 12 : 16
  return base + (trustPercentile / 100) * scale
}

/**
 * Get edge color based on predicate category
 */
function getEdgeColor(predicate: string, isAgentView: boolean): string {
  if (isAgentView) {
    return 'hsl(120 80% 40%)'
  }

  // Agent-Agent predicates
  if (predicate.includes('delegates-to') || predicate.includes('depends-on')) {
    return 'var(--brand, #6366f1)'
  }
  // Agent-Skill predicates
  if (predicate.includes('uses-skill') || predicate.includes('has-used')) {
    return '#22c55e'
  }
  // Shared predicates (compatible-with, recommends)
  return '#94a3b8'
}

export function TrustGraph({
  agents,
  skills,
  focusEntityId,
  onNodeClick,
  className,
  compact = false,
}: TrustGraphProps) {
  const svgRef = useRef<SVGSVGElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [dimensions, setDimensions] = useState({ width: 800, height: 600 })
  const [simulationNodes, setSimulationNodes] = useState<GraphNode[]>([])
  const [hoveredNode, setHoveredNode] = useState<GraphNode | null>(null)
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 })
  const { isAgentView } = useViewMode()

  // Pan/zoom state
  const [transform, setTransform] = useState({ x: 0, y: 0, scale: 1 })
  const isPanningRef = useRef(false)
  const panStartRef = useRef({ x: 0, y: 0 })

  // Build relationships from triple data (memoized)
  const relationships = useMemo(
    () => buildRelationshipsFromTriples(agents, skills),
    [agents, skills]
  )

  // Filter graph data (memoized)
  const { nodes: graphNodes, links: graphLinks } = useMemo(
    () => filterGraphData(agents, skills, relationships, focusEntityId),
    [agents, skills, relationships, focusEntityId]
  )

  // Observe container size
  useEffect(() => {
    const observer = new ResizeObserver((entries) => {
      const entry = entries[0]
      if (entry) {
        const { width, height } = entry.contentRect
        setDimensions({ width: width || 800, height: height || 600 })
      }
    })

    if (containerRef.current) {
      observer.observe(containerRef.current)
    }

    return () => observer.disconnect()
  }, [])

  // Auto-fit logic — computes transform to fit all settled nodes within the canvas
  const fitToView = useCallback(() => {
    if (!simulationNodes.length) return

    const padding = 60
    let minX = Infinity
    let maxX = -Infinity
    let minY = Infinity
    let maxY = -Infinity

    for (const node of simulationNodes) {
      if (node.x == null || node.y == null) continue
      const r = getNodeRadius(node.trustPercentile, compact)
      minX = Math.min(minX, node.x - r)
      maxX = Math.max(maxX, node.x + r)
      minY = Math.min(minY, node.y - r)
      maxY = Math.max(maxY, node.y + r)
    }

    if (!isFinite(minX)) return

    const contentWidth = maxX - minX
    const contentHeight = maxY - minY
    const scaleX = (dimensions.width - padding * 2) / contentWidth
    const scaleY = (dimensions.height - padding * 2) / contentHeight
    const scale = Math.min(scaleX, scaleY, 1.5)

    const centerX = (minX + maxX) / 2
    const centerY = (minY + maxY) / 2
    const x = dimensions.width / 2 - centerX * scale
    const y = dimensions.height / 2 - centerY * scale

    setTransform({ x, y, scale })
  }, [simulationNodes, dimensions, compact])

  // Run d3 force simulation
  useEffect(() => {
    if (!graphNodes.length) return

    const simulation = forceSimulation<GraphNode>(graphNodes)
      .force('charge', forceManyBody().strength(-300))
      .force(
        'link',
        forceLink<GraphNode, GraphLink>(graphLinks)
          .id((d) => d.id)
          .distance(80),
      )
      .force('center', forceCenter(dimensions.width / 2, dimensions.height / 2))
      .force('collide', forceCollide().radius((d) => getNodeRadius((d as GraphNode).trustPercentile, compact) + 10))
      .alphaDecay(0.02)
      .velocityDecay(0.3)

    simulation.on('tick', () => {
      setSimulationNodes([...graphNodes])
    })

    simulation.on('end', () => {
      // Auto-fit after simulation settles — compute directly from graphNodes
      // (simulationNodes state may lag one render behind)
      const padding = 60
      let minX = Infinity
      let maxX = -Infinity
      let minY = Infinity
      let maxY = -Infinity

      for (const node of graphNodes) {
        if (node.x == null || node.y == null) continue
        const r = getNodeRadius(node.trustPercentile, compact)
        minX = Math.min(minX, node.x - r)
        maxX = Math.max(maxX, node.x + r)
        minY = Math.min(minY, node.y - r)
        maxY = Math.max(maxY, node.y + r)
      }

      if (!isFinite(minX)) return

      const contentWidth = maxX - minX
      const contentHeight = maxY - minY
      const scaleX = (dimensions.width - padding * 2) / contentWidth
      const scaleY = (dimensions.height - padding * 2) / contentHeight
      const scale = Math.min(scaleX, scaleY, 1.5)

      const centerX = (minX + maxX) / 2
      const centerY = (minY + maxY) / 2
      const x = dimensions.width / 2 - centerX * scale
      const y = dimensions.height / 2 - centerY * scale

      setTransform({ x, y, scale })
    })

    return () => {
      simulation.stop()
    }
  }, [graphNodes, graphLinks, dimensions, compact])

  // Zoom toward cursor position
  const handleWheel = (e: React.WheelEvent<SVGSVGElement>) => {
    e.preventDefault()

    const rect = svgRef.current?.getBoundingClientRect()
    if (!rect) return

    const cursorX = e.clientX - rect.left
    const cursorY = e.clientY - rect.top

    const zoomFactor = e.deltaY < 0 ? 1.1 : 0.9

    setTransform((prev) => {
      const newScale = Math.min(Math.max(prev.scale * zoomFactor, 0.1), 5)
      // Zoom toward cursor: shift origin so cursor position stays fixed in graph space
      const scaleDelta = newScale / prev.scale
      const newX = cursorX - scaleDelta * (cursorX - prev.x)
      const newY = cursorY - scaleDelta * (cursorY - prev.y)
      return { x: newX, y: newY, scale: newScale }
    })
  }

  const handlePointerDown = (e: React.PointerEvent<SVGSVGElement>) => {
    // Only start panning on left-click on the SVG background (not on nodes)
    if (e.button !== 0) return
    isPanningRef.current = true
    panStartRef.current = { x: e.clientX - transform.x, y: e.clientY - transform.y }
    ;(e.currentTarget as SVGSVGElement).setPointerCapture(e.pointerId)
  }

  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    // Always update tooltip position
    setMousePos({ x: e.clientX, y: e.clientY })

    if (!isPanningRef.current) return
    setTransform((prev) => ({
      ...prev,
      x: e.clientX - panStartRef.current.x,
      y: e.clientY - panStartRef.current.y,
    }))
  }

  const handlePointerUp = () => {
    isPanningRef.current = false
  }

  // Grid pattern for agent view
  const gridPattern = isAgentView ? (
    <defs>
      <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
        <path d="M 20 0 L 0 0 0 20" fill="none" stroke="hsl(120 80% 40% / 0.1)" strokeWidth="0.5"/>
      </pattern>
    </defs>
  ) : null

  return (
    <div ref={containerRef} className={className} style={{ position: 'relative' }}>
      <svg
        ref={svgRef}
        width={dimensions.width}
        height={dimensions.height}
        onWheel={handleWheel}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        style={{
          display: 'block',
          background: isAgentView ? 'hsl(120 20% 5%)' : undefined,
          cursor: 'grab',
        }}
      >
        {gridPattern}

        <g transform={`translate(${transform.x}, ${transform.y}) scale(${transform.scale})`}>
          {isAgentView && (
            <rect
              width={dimensions.width}
              height={dimensions.height}
              fill="url(#grid)"
            />
          )}

          {/* Edges */}
          {graphLinks.map((link, i) => {
            const source = simulationNodes.find((n) => n.id === (typeof link.source === 'string' ? link.source : link.source.id))
            const target = simulationNodes.find((n) => n.id === (typeof link.target === 'string' ? link.target : link.target.id))

            if (!source?.x || !source?.y || !target?.x || !target?.y) return null

            const edgeColor = getEdgeColor(link.predicate, isAgentView)

            return (
              <line
                key={`link-${i}`}
                x1={source.x}
                y1={source.y}
                x2={target.x}
                y2={target.y}
                stroke={edgeColor}
                strokeOpacity={0.4}
                strokeWidth={1}
              >
                <title>{link.predicate}</title>
              </line>
            )
          })}

          {/* Nodes */}
          {simulationNodes.map((node) => {
            if (!node.x || !node.y) return null

            const radius = getNodeRadius(node.trustPercentile, compact)

            // Agent view colors
            if (isAgentView) {
              if (node.entityType === 'agent') {
                // Agents: circles with phosphor green
                return (
                  <g key={node.id}>
                    <circle
                      cx={node.x}
                      cy={node.y}
                      r={radius}
                      fill="hsl(120 20% 10%)"
                      stroke="hsl(120 100% 69%)"
                      strokeWidth={2}
                      style={{ cursor: 'pointer' }}
                      onClick={() => onNodeClick?.(node.id, node.entityType)}
                      onMouseEnter={() => setHoveredNode(node)}
                      onMouseLeave={() => setHoveredNode(null)}
                    />
                    {node.image && (
                      <image
                        href={node.image}
                        x={node.x - radius * 0.7}
                        y={node.y - radius * 0.7}
                        width={radius * 1.4}
                        height={radius * 1.4}
                        clipPath={`circle(${radius * 0.7}px at ${radius * 0.7}px ${radius * 0.7}px)`}
                        style={{ pointerEvents: 'none', opacity: 0.5 }}
                      />
                    )}
                    {!compact && (
                      <text
                        x={node.x}
                        y={node.y + radius + 12}
                        textAnchor="middle"
                        fill="hsl(120 100% 69%)"
                        fontSize="10"
                        fontFamily="monospace"
                        style={{ pointerEvents: 'none' }}
                      >
                        {node.name.length > 15 ? node.name.substring(0, 15) + '...' : node.name}
                      </text>
                    )}
                  </g>
                )
              } else {
                // Skills: rounded rectangles with phosphor green
                const rectWidth = radius * 2
                const rectHeight = radius * 1.5
                return (
                  <g key={node.id}>
                    <rect
                      x={node.x - rectWidth / 2}
                      y={node.y - rectHeight / 2}
                      width={rectWidth}
                      height={rectHeight}
                      rx={4}
                      fill="hsl(120 20% 10%)"
                      stroke="hsl(120 100% 69%)"
                      strokeWidth={2}
                      style={{ cursor: 'pointer' }}
                      onClick={() => onNodeClick?.(node.id, node.entityType)}
                      onMouseEnter={() => setHoveredNode(node)}
                      onMouseLeave={() => setHoveredNode(null)}
                    />
                    {node.image && (
                      <image
                        href={node.image}
                        x={node.x - radius * 0.5}
                        y={node.y - radius * 0.5}
                        width={radius}
                        height={radius}
                        style={{ pointerEvents: 'none', opacity: 0.5 }}
                      />
                    )}
                    {!compact && (
                      <text
                        x={node.x}
                        y={node.y + rectHeight / 2 + 12}
                        textAnchor="middle"
                        fill="hsl(120 100% 69%)"
                        fontSize="10"
                        fontFamily="monospace"
                        style={{ pointerEvents: 'none' }}
                      >
                        {node.name.length > 15 ? node.name.substring(0, 15) + '...' : node.name}
                      </text>
                    )}
                  </g>
                )
              }
            }

            // Human view colors
            if (node.entityType === 'agent') {
              const color = TIER_COLORS[node.trustTier]
              return (
                <g key={node.id}>
                  <circle
                    cx={node.x}
                    cy={node.y}
                    r={radius}
                    fill={color}
                    stroke="var(--background, #000)"
                    strokeWidth={2}
                    style={{ cursor: 'pointer' }}
                    onClick={() => onNodeClick?.(node.id, node.entityType)}
                    onMouseEnter={() => setHoveredNode(node)}
                    onMouseLeave={() => setHoveredNode(null)}
                  />
                  {node.image && (
                    <image
                      href={node.image}
                      x={node.x - radius * 0.7}
                      y={node.y - radius * 0.7}
                      width={radius * 1.4}
                      height={radius * 1.4}
                      clipPath={`circle(${radius * 0.7}px at ${radius * 0.7}px ${radius * 0.7}px)`}
                      style={{ pointerEvents: 'none', opacity: 0.9 }}
                    />
                  )}
                </g>
              )
            } else {
              // Skills: rounded rectangles with safety color
              const color = SAFETY_COLORS[node.safetyStatus || 'unverified']
              const rectWidth = radius * 2
              const rectHeight = radius * 1.5
              return (
                <g key={node.id}>
                  <rect
                    x={node.x - rectWidth / 2}
                    y={node.y - rectHeight / 2}
                    width={rectWidth}
                    height={rectHeight}
                    rx={4}
                    fill={color}
                    stroke="var(--background, #000)"
                    strokeWidth={2}
                    style={{ cursor: 'pointer' }}
                    onClick={() => onNodeClick?.(node.id, node.entityType)}
                    onMouseEnter={() => setHoveredNode(node)}
                    onMouseLeave={() => setHoveredNode(null)}
                  />
                  {node.image && (
                    <image
                      href={node.image}
                      x={node.x - radius * 0.5}
                      y={node.y - radius * 0.5}
                      width={radius}
                      height={radius}
                      style={{ pointerEvents: 'none', opacity: 0.9 }}
                    />
                  )}
                </g>
              )
            }
          })}
        </g>
      </svg>

      {/* Fit to View button */}
      <button
        type="button"
        onClick={fitToView}
        className="absolute bottom-3 right-3 px-2 py-1 text-xs font-mono rounded bg-background/80 border border-border hover:bg-muted backdrop-blur-sm"
      >
        Fit
      </button>

      {/* Tooltip */}
      {hoveredNode && (
        <div
          className={`pointer-events-none fixed z-50 rounded-lg border px-3 py-2 shadow-lg backdrop-blur-sm ${
            isAgentView
              ? 'border-[hsl(120_100%_69%)] bg-[hsl(120_20%_10%)] font-mono text-[hsl(120_100%_69%)]'
              : 'border-border bg-background/95 text-foreground'
          }`}
          style={{
            left: mousePos.x + 12,
            top: mousePos.y + 12,
          }}
        >
          <p className={`text-sm font-semibold ${isAgentView ? 'text-[hsl(120_100%_69%)]' : ''}`}>
            {hoveredNode.name}
          </p>
          <p className={`text-xs capitalize ${isAgentView ? 'text-[hsl(120_80%_60%)]' : 'text-muted-foreground'}`}>
            {hoveredNode.entityType === 'agent' ? 'Agent' : `Skill (${hoveredNode.platformName})`} • {hoveredNode.trustTier} • {hoveredNode.stakerCount} stakers
          </p>
          {hoveredNode.safetyStatus && (
            <p className={`text-xs ${isAgentView ? 'text-[hsl(120_80%_60%)]' : 'text-muted-foreground'}`}>
              Safety: {hoveredNode.safetyStatus}
            </p>
          )}
        </div>
      )}
    </div>
  )
}
