# Metadata Standards Mapping

This file is the schema source-of-truth crosswalk for `RDL-015`.

## Agent Metadata (`AgentMetadataSchema`)

- `@type`: Intuition atom type discriminator (`Agent`)
- `name`, `description`, `version`: aligned with A2A Agent Card identity/version semantics
- `endpoint`: maps to A2A `url`/interface endpoint usage
- `provider`: maps to A2A `provider`
- `defaultInputModes`, `defaultOutputModes`: maps to A2A default mode fields
- `tags`, `model`, `image`: Intuition registry extensions for discovery/presentation

## Skill Metadata (`SkillMetadataSchema`)

- `@type`: Intuition atom type discriminator (`Skill`)
- `name`, `description`, `version`: reusable capability identity fields
- `platform`: constrained interoperability surface (`mcp`, `claude-code`, `openclaw`, `openai`, `other`)
- `installUri`: installation binding for platform runtime
  - `mcp` requires `mcp://` or `npx ...`
  - other platforms accept `http(s)`, `npm:`, or `npx ...`
- `permissions`: declared runtime permissions for policy checks
- `author`, `longDescription`, `image`: registry extension metadata

## Validation Policy

- Required/optional field constraints are enforced with Zod.
- Invalid enum/type/length values must produce actionable field-level errors.
- Schemas are used prior to IPFS upload and treated as the write-time contract.
