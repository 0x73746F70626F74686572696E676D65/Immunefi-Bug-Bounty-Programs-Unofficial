import type { LoaderFunctionArgs } from 'react-router'
import { createRepository } from '~/data/repository/provider'
import { handleOptions, jsonResponse, errorResponse } from '~/lib/api/types'

export async function loader({ request, params }: LoaderFunctionArgs) {
  const optionsResponse = handleOptions(request)
  if (optionsResponse) return optionsResponse

  const { id } = params
  if (!id) {
    return errorResponse('Skill ID is required', 'MISSING_ID', 400)
  }

  const repo = createRepository()
  const skill = await repo.findSkill(id)

  if (!skill) {
    return errorResponse('Skill not found', 'NOT_FOUND', 404)
  }

  return jsonResponse(skill)
}
