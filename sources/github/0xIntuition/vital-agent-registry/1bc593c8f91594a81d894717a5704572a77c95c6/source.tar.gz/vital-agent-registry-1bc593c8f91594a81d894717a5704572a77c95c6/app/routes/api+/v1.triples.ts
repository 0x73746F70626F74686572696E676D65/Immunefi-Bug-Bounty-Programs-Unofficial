import type { ActionFunctionArgs, LoaderFunctionArgs } from 'react-router'
import { parseEventLogs } from 'viem'
import { handleOptions, parseJsonBody, parseQueryParams, jsonResponse, errorResponse, corsHeaders } from '~/lib/api/types'
import { createTriplesSchema, queryTriplesSchema } from '~/lib/api/validation'
import { encodeCreateTriplesCalldata } from '~/lib/calldata'
import { getTripleCost, createTriples, getMinimumDeposit } from '~/.server/multivault'
import { multivaultAbi } from '~/lib/abis/multivault'
import { getContractAddress, getChainConfig } from '~/lib/constants/protocol'
import type { NetworkId } from '~/lib/constants/protocol'
import { requireExecuteAuth } from '~/.server/execute-auth'
import { assertRemoteWriteAllowed, RemoteWriteGuardError } from '~/.server/remote-write-guard'
import { createLocalWriteClients, getLocalWriteContext } from '~/.server/local-write'
import { registrationLimiter, getClientIP, isRegistrationRateLimitEnabled } from '~/lib/rate-limit'
import { serverGraphqlRequest } from '~/lib/graphql/client'

const GET_TRIPLES_QUERY = `
  query GetTriples($where: triples_bool_exp!, $limit: Int, $offset: Int) {
    total: triples_aggregate(where: $where) {
      aggregate { count }
    }
    triples(where: $where, limit: $limit, offset: $offset, order_by: [{ created_at: desc }]) {
      term_id
      counter_term_id
      created_at
      subject { term_id label image type }
      predicate { term_id label image type }
      object { term_id label image type data }
      term {
        total_market_cap
        positions_aggregate { aggregate { count } }
        vaults(order_by: { curve_id: asc }) {
          term_id curve_id current_share_price total_shares total_assets position_count market_cap
        }
      }
      creator { id label image }
    }
  }
`

/**
 * POST /api/v1/triples
 *
 * Creates triples on the MultiVault contract.
 *
 * Dual mode:
 * - Prepare (default): Returns unsigned calldata for client-side signing
 * - Execute (?execute=true): Signs and sends via local wallet
 */
export async function action({ request }: ActionFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const url = new URL(request.url)
  const execute = url.searchParams.get('execute') === 'true'

  if (execute) {
    const auth = requireExecuteAuth(request)
    if (!auth.authorized) return auth.response
  }

  // Rate limit check (SEC-08)
  if (isRegistrationRateLimitEnabled()) {
    const ip = getClientIP(request)
    const limit = registrationLimiter.check(ip)
    if (!limit.allowed) {
      return new Response(
        JSON.stringify({
          error: 'Too many requests',
          code: 'RATE_LIMITED',
          retryAfter: Math.ceil((limit.resetAt - Date.now()) / 1000),
        }),
        {
          status: 429,
          headers: {
            ...corsHeaders(),
            'Content-Type': 'application/json',
            'Retry-After': String(Math.ceil((limit.resetAt - Date.now()) / 1000)),
          },
        }
      )
    }
  }

  // Parse and validate request body
  const parsed = await parseJsonBody(request, createTriplesSchema)
  if ('error' in parsed) return parsed.error

  const { triples, depositPerTriple } = parsed.data

  try {
    if (!execute) {
      // Prepare mode: return unsigned calldata
      assertRemoteWriteAllowed({
        action: 'prepare triple creation',
        target: 'chain',
      })

      const chain = (process.env.CHAIN as NetworkId) || 'testnet'
      const contractAddress = getContractAddress(chain)
      const { createPublicClient, http } = await import('viem')
      const { getRpcUrl } = await import('~/lib/constants/protocol')
      const rpcUrl = getRpcUrl(chain)

      const publicClient = createPublicClient({
        transport: http(rpcUrl),
      })

      const tripleCost = await getTripleCost(publicClient, contractAddress)
      const deposit = depositPerTriple ? BigInt(depositPerTriple) : 0n
      const calldata = encodeCreateTriplesCalldata(triples, deposit)

      return jsonResponse({
        triples,
        calldata,
        estimatedCost: (tripleCost * BigInt(triples.length)).toString(),
        contractAddress,
        chainId: getChainConfig(chain).chainId,
      })
    }

    // Execute mode: sign and send via local wallet
    const context = getLocalWriteContext()
    const { publicClient, walletClient } = await createLocalWriteClients(context)
    const minimumDeposit = await getMinimumDeposit(publicClient, context.contractAddress)
    const deposit = depositPerTriple ? BigInt(depositPerTriple) : minimumDeposit

    const result = await createTriples(
      publicClient,
      walletClient,
      context.contractAddress,
      triples,
      deposit,
    )

    const receipt = await publicClient.waitForTransactionReceipt({ hash: result.hash })
    const tripleCreatedLogs = parseEventLogs({
      abi: multivaultAbi,
      logs: receipt.logs,
      eventName: 'TripleCreated',
    })

    const createdTriples = tripleCreatedLogs.map((log) => ({
      termId: log.args?.termId as `0x${string}` | undefined,
    }))

    return jsonResponse({
      triples,
      execution: {
        mode: 'local',
        executed: true,
        account: walletClient.account?.address ?? null,
        contractAddress: context.contractAddress,
        txHash: result.hash,
        tripleCount: result.tripleCount,
        createdTriples,
      },
    })
  } catch (error) {
    if (error instanceof RemoteWriteGuardError) {
      return errorResponse(
        'Remote writes are blocked by default in local-safe mode',
        error.code,
        403,
        {
          message: error.message,
          requiredOverride: 'ALLOW_REMOTE_WRITES=1 and REGISTRY_WRITE_PROFILE=shared',
          profile: error.profile,
          target: error.target,
          action: error.action,
        }
      )
    }
    return errorResponse('Triple creation failed', 'INTERNAL_ERROR', 500, {
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
}

/**
 * GET /api/v1/triples
 *
 * Query triples by subject, predicate, and/or object.
 * At least one filter parameter is required.
 */
export async function loader({ request }: LoaderFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const parsed = parseQueryParams(request, queryTriplesSchema)
  if ('error' in parsed) return parsed.error

  const { subjectId, predicateId, objectId, limit, offset } = parsed.data

  try {
    // Build dynamic where clause from provided filters
    const where: Record<string, { _eq: string }> = {}
    if (subjectId) where.subject_id = { _eq: subjectId }
    if (predicateId) where.predicate_id = { _eq: predicateId }
    if (objectId) where.object_id = { _eq: objectId }

    const graphqlUrl = process.env.GRAPHQL_API_URL_PRIVATE || 'http://localhost:8080/v1/graphql'

    interface TriplesQueryResult {
      total: { aggregate: { count: number } }
      triples: Array<{
        term_id: string
        counter_term_id: string
        created_at: string
        subject: { term_id: string; label: string; image: string | null; type: string }
        predicate: { term_id: string; label: string; image: string | null; type: string }
        object: { term_id: string; label: string; image: string | null; type: string; data: string | null }
        term: {
          total_market_cap: string
          positions_aggregate: { aggregate: { count: number } }
          vaults: Array<{
            term_id: string
            curve_id: number
            current_share_price: string
            total_shares: string
            total_assets: string
            position_count: number
            market_cap: string
          }>
        }
        creator: { id: string; label: string; image: string | null }
      }>
    }

    const data = await serverGraphqlRequest<TriplesQueryResult>(
      graphqlUrl,
      GET_TRIPLES_QUERY,
      { where, limit, offset },
    )

    const total = data.total?.aggregate?.count ?? 0

    return jsonResponse(data.triples, { total, limit, offset })
  } catch {
    // GraphQL failure: return empty results rather than error
    return jsonResponse([], { total: 0, limit, offset })
  }
}
