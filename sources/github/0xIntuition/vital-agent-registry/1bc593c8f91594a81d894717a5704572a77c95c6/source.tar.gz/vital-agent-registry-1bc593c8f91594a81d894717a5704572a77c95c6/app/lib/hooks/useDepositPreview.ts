import { parseEther } from 'viem'
import { useReadContract } from 'wagmi'
import { multivaultAbi } from '~/lib/abis/multivault'
import { ensureBytes32 } from '~/lib/id-conversion'
import { getContractAddress } from '~/lib/constants/protocol'
import type { NetworkId } from '~/lib/constants/protocol'

interface UseDepositPreviewOptions {
  termId: string
  /** 0n = FOR, 1n = AGAINST */
  curveId: bigint
  /** ETH amount as string (e.g., "0.01") */
  amount: string
  network: NetworkId
  enabled?: boolean
}

/**
 * Read-only hook for previewing deposit fees and shares via `previewDeposit`.
 *
 * Returns the shares received, assets after fees, and total fees for a given
 * deposit amount and curve direction.
 */
export function useDepositPreview({
  termId,
  curveId,
  amount,
  network,
  enabled = true,
}: UseDepositPreviewOptions) {
  const contractAddress = getContractAddress(network) as `0x${string}`
  const assets = amount && parseFloat(amount) > 0 ? parseEther(amount) : 0n

  const { data, isLoading } = useReadContract({
    address: contractAddress,
    abi: multivaultAbi,
    functionName: 'previewDeposit',
    args: [ensureBytes32(termId), curveId, assets],
    query: { enabled: enabled && assets > 0n },
  })

  // previewDeposit returns readonly [shares: bigint, assetsAfterFees: bigint]
  const result = data as readonly [bigint, bigint] | undefined
  const shares = result?.[0] ?? 0n
  const assetsAfterFees = result?.[1] ?? 0n
  const fees = assets > 0n ? assets - assetsAfterFees : 0n

  return { shares, assetsAfterFees, fees, isLoading }
}
