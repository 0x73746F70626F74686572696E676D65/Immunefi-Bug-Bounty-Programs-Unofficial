import { Skeleton } from '~/components/ui/Skeleton'

/**
 * CardSkeleton — loading skeleton matching AgentCard/SkillCard dimensions
 */
export function CardSkeleton() {
  return (
    <div className="rounded-[var(--radius-card)] border border-border bg-card p-4">
      {/* Header row: avatar + title + badge */}
      <div className="flex items-start gap-3">
        <Skeleton className="h-10 w-10 rounded-full" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-4 w-3/5" />
          <Skeleton className="h-3 w-2/5" />
        </div>
        <Skeleton className="h-5 w-16 rounded-full" />
      </div>

      {/* Description */}
      <div className="mt-4 space-y-2">
        <Skeleton className="h-3 w-full" />
        <Skeleton className="h-3 w-4/5" />
      </div>

      {/* Capabilities */}
      <div className="mt-4 flex flex-wrap gap-2">
        <Skeleton className="h-5 w-16 rounded-full" />
        <Skeleton className="h-5 w-20 rounded-full" />
        <Skeleton className="h-5 w-14 rounded-full" />
      </div>

      {/* Bottom metrics */}
      <div className="mt-4">
        <Skeleton className="h-3 w-2/5" />
      </div>
    </div>
  )
}

/**
 * GridSkeleton — 6 card skeletons in responsive grid
 */
export function GridSkeleton() {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <CardSkeleton key={i} />
      ))}
    </div>
  )
}
