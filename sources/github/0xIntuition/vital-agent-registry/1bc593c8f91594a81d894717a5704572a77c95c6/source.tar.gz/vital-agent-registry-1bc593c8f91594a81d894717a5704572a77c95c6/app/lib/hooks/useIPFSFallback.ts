import { useEffect, useState } from 'react'

interface IPFSFallbackResult<T> {
  data: T | null
  isLoading: boolean
  isStale: boolean // true when using cached fallback
  error: Error | null
}

interface IPFSFallbackOptions {
  timeoutMs?: number
}

/**
 * In-memory LRU cache for resolved IPFS data (session-scoped).
 * Max 200 entries to prevent unbounded memory growth.
 */
const IPFS_CACHE_MAX_SIZE = 200
const ipfsCache = new Map<string, unknown>()

/** Evicts oldest entries when cache exceeds max size. */
function ipfsCacheSet(key: string, value: unknown) {
  if (ipfsCache.size >= IPFS_CACHE_MAX_SIZE) {
    // Delete the first (oldest) entry
    const oldest = ipfsCache.keys().next().value
    if (oldest !== undefined) ipfsCache.delete(oldest)
  }
  ipfsCache.set(key, value)
}

/**
 * useIPFSFallback — fetch from IPFS with fallback to cached indexer data
 *
 * Attempts to resolve IPFS URI via gateway with timeout. On failure or timeout,
 * falls back to cachedData and marks result as stale.
 *
 * Cache: Successful IPFS fetches are cached in memory for the session.
 *
 * @param ipfsUri - IPFS URI (e.g., ipfs://Qm...)
 * @param cachedData - Fallback data from indexer
 * @param options - Timeout configuration (default: 5000ms)
 * @returns IPFSFallbackResult with data, loading, stale, and error states
 *
 * @example
 * const { data, isLoading, isStale } = useIPFSFallback(
 *   agent.metadata_uri,
 *   agent.cached_metadata,
 *   { timeoutMs: 3000 }
 * )
 */
export function useIPFSFallback<T>(
  ipfsUri: string | undefined,
  cachedData: T | undefined,
  options?: IPFSFallbackOptions,
): IPFSFallbackResult<T> {
  const timeoutMs = options?.timeoutMs ?? 5000

  const [data, setData] = useState<T | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isStale, setIsStale] = useState(false)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    // No URI provided, use cached data immediately
    if (!ipfsUri) {
      setData((cachedData ?? null) as T | null)
      setIsStale(!!cachedData)
      setIsLoading(false)
      return
    }

    // Check in-memory cache first
    if (ipfsCache.has(ipfsUri)) {
      setData(ipfsCache.get(ipfsUri) as T)
      setIsStale(false)
      setIsLoading(false)
      return
    }

    // Fetch from IPFS gateway
    setIsLoading(true)
    setError(null)

    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs)

    // Convert ipfs:// to https gateway URL
    const gatewayUrl = ipfsUri.replace('ipfs://', 'https://ipfs.io/ipfs/')

    fetch(gatewayUrl, { signal: controller.signal })
      .then((res) => {
        clearTimeout(timeoutId)
        if (!res.ok) throw new Error(`IPFS fetch failed: ${res.status}`)
        return res.json()
      })
      .then((fetchedData: T) => {
        // Cache successful fetch
        ipfsCacheSet(ipfsUri, fetchedData)
        setData(fetchedData)
        setIsStale(false)
        setIsLoading(false)
      })
      .catch((err: Error) => {
        clearTimeout(timeoutId)
        // On error or timeout, fall back to cached data
        if (cachedData) {
          setData(cachedData)
          setIsStale(true)
          setError(err)
        } else {
          setData(null)
          setIsStale(false)
          setError(err)
        }
        setIsLoading(false)
      })

    return () => {
      clearTimeout(timeoutId)
      controller.abort()
    }
  }, [ipfsUri, cachedData, timeoutMs])

  return { data, isLoading, isStale, error }
}
