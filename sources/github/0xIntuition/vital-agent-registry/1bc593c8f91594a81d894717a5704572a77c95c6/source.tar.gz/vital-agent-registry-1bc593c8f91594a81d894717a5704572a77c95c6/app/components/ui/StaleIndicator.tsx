interface StaleIndicatorProps {
  isStale: boolean
  message?: string // default: "Metadata may be stale"
}

/**
 * StaleIndicator — small badge shown when using cached fallback data
 *
 * Appears next to entities when IPFS metadata fetch failed and
 * we're displaying cached indexer data instead.
 *
 * Visual: amber/yellow badge with warning icon.
 */
export function StaleIndicator({ isStale, message = 'Metadata may be stale' }: StaleIndicatorProps) {
  if (!isStale) return null

  return (
    <div
      className="inline-flex items-center gap-1 px-2 py-1 bg-amber-500/10 text-amber-400 text-xs rounded-md border border-amber-500/20"
      role="status"
      aria-label={message}
      title={message}
    >
      <svg
        className="w-3 h-3"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        strokeWidth={2}
        aria-hidden="true"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
        />
      </svg>
      <span className="sr-only">{message}</span>
      <span aria-hidden="true">Stale</span>
    </div>
  )
}
