/**
 * Fee calculation utilities for Intuition protocol vault operations.
 *
 * All fee calculations use BigInt arithmetic to avoid precision loss.
 * Fee rates are expressed in basis points (1 basis point = 0.01%).
 * Default fee denominator is 10000n, meaning:
 * - 50 = 0.50%
 * - 100 = 1.00%
 * - 125 = 1.25%
 *
 * Entry fees include both base and atom fees.
 * Exit fees include only the base fee.
 *
 * @module fees
 */

/**
 * Fee configuration for protocol operations.
 */
export interface FeeConfig {
  /** Base entry fee rate in basis points (applies to all deposits) */
  entryFee: bigint;
  /** Exit fee rate in basis points (applies to all withdrawals) */
  exitFee: bigint;
  /** Protocol fee rate in basis points (collected on various operations) */
  protocolFee: bigint;
  /** Denominator for fee calculations (default: 10000n for basis points) */
  feeDenominator: bigint;
  /** Fixed cost in wei to create a new atom */
  atomCost: bigint;
  /** Fixed cost in wei to create a new triple */
  tripleCost: bigint;
}

/**
 * Default fee denominator for basis point calculations.
 * 10000 basis points = 100%
 */
export const DEFAULT_FEE_DENOMINATOR = 10000n;

/**
 * Calculates the total entry fee for a deposit.
 *
 * Entry fee includes both base fee and atom fee:
 * `totalFee = depositAmount * (baseFeeRate + atomFeeRate) / feeDenominator`
 *
 * @param depositAmount - Amount being deposited (in wei)
 * @param baseFeeRate - Base fee rate in basis points
 * @param atomFeeRate - Atom fee rate in basis points
 * @param feeDenominator - Denominator for fee calculation (default: 10000n)
 * @returns Total entry fee in wei
 *
 * @example
 * ```typescript
 * // 1 ETH deposit with 0.5% base fee and 1.25% atom fee = 1.75% total
 * const fee = calculateEntryFee(
 *   1000000000000000000n, // 1 ETH
 *   50n,   // 0.5%
 *   125n,  // 1.25%
 *   10000n
 * );
 * // fee = 17500000000000000n (0.0175 ETH)
 * ```
 */
export function calculateEntryFee(
  depositAmount: bigint,
  baseFeeRate: bigint,
  atomFeeRate: bigint,
  feeDenominator: bigint = DEFAULT_FEE_DENOMINATOR
): bigint {
  const totalFeeRate = baseFeeRate + atomFeeRate;
  return (depositAmount * totalFeeRate) / feeDenominator;
}

/**
 * Calculates the exit fee for a withdrawal.
 *
 * Exit fee includes only the base fee (no atom fee):
 * `exitFee = withdrawAmount * baseFeeRate / feeDenominator`
 *
 * @param withdrawAmount - Amount being withdrawn (in wei)
 * @param baseFeeRate - Base fee rate in basis points
 * @param feeDenominator - Denominator for fee calculation (default: 10000n)
 * @returns Exit fee in wei
 *
 * @example
 * ```typescript
 * // 1 ETH withdrawal with 0.5% base fee
 * const fee = calculateExitFee(
 *   1000000000000000000n, // 1 ETH
 *   50n,   // 0.5%
 *   10000n
 * );
 * // fee = 5000000000000000n (0.005 ETH)
 * ```
 */
export function calculateExitFee(
  withdrawAmount: bigint,
  baseFeeRate: bigint,
  feeDenominator: bigint = DEFAULT_FEE_DENOMINATOR
): bigint {
  return (withdrawAmount * baseFeeRate) / feeDenominator;
}

/**
 * Calculates the total cost to create a new atom including initial deposit.
 *
 * Total cost = atom creation cost + initial deposit amount.
 * This is the total amount the user must pay upfront.
 *
 * @param atomCost - Fixed cost to create the atom (in wei)
 * @param initialDeposit - Initial deposit amount for the atom's vault (in wei)
 * @returns Total cost in wei
 *
 * @example
 * ```typescript
 * const totalCost = calculateAtomCost(
 *   10000000000000000n,  // 0.01 ETH atom cost
 *   100000000000000000n  // 0.1 ETH initial deposit
 * );
 * // totalCost = 110000000000000000n (0.11 ETH)
 * ```
 */
export function calculateAtomCost(
  atomCost: bigint,
  initialDeposit: bigint
): bigint {
  return atomCost + initialDeposit;
}

/**
 * Calculates the total cost to create a new triple including deposit.
 *
 * Total cost = triple creation cost + deposit amount.
 * This is the total amount the user must pay upfront.
 *
 * @param tripleCost - Fixed cost to create the triple (in wei)
 * @param depositAmount - Deposit amount for the triple's vault (in wei)
 * @returns Total cost in wei
 *
 * @example
 * ```typescript
 * const totalCost = calculateTripleCost(
 *   10000000000000000n,  // 0.01 ETH triple cost
 *   50000000000000000n   // 0.05 ETH deposit
 * );
 * // totalCost = 60000000000000000n (0.06 ETH)
 * ```
 */
export function calculateTripleCost(
  tripleCost: bigint,
  depositAmount: bigint
): bigint {
  return tripleCost + depositAmount;
}
