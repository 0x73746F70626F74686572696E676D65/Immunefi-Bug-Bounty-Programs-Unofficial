import { performance } from 'node:perf_hooks'
import { describe, expect, it } from 'vitest'
import {
  MINIMUM_AGENTS_FOR_RANKING,
  assignTrustTier,
  computeTrustSignal,
} from '../trust'
import { computeSafetySignal, deriveSafetyStatus } from '../safety'
import type { Vault } from '~/types'

function makeVault(
  termId: string,
  totalAssetsWei: string,
  stakerCount: number,
  sharePriceWei = '1000000000000000000',
): Vault {
  return {
    term_id: termId,
    curve_id: '1',
    total_shares: stakerCount === 0 ? '0' : '1000000000000000000',
    current_share_price: sharePriceWei,
    total_assets: totalAssetsWei,
    market_cap: totalAssetsWei,
    position_count: stakerCount,
  }
}

describe('trust + safety computation verification', () => {
  it('trust tiers match threshold boundaries at 25/50/75/90', () => {
    expect(assignTrustTier(24, 1, MINIMUM_AGENTS_FOR_RANKING)).toBe('unranked')
    expect(assignTrustTier(25, 1, MINIMUM_AGENTS_FOR_RANKING)).toBe('bronze')
    expect(assignTrustTier(49, 1, MINIMUM_AGENTS_FOR_RANKING)).toBe('bronze')
    expect(assignTrustTier(50, 1, MINIMUM_AGENTS_FOR_RANKING)).toBe('silver')
    expect(assignTrustTier(74, 1, MINIMUM_AGENTS_FOR_RANKING)).toBe('silver')
    expect(assignTrustTier(75, 1, MINIMUM_AGENTS_FOR_RANKING)).toBe('gold')
    expect(assignTrustTier(89, 1, MINIMUM_AGENTS_FOR_RANKING)).toBe('gold')
    expect(assignTrustTier(90, 1, MINIMUM_AGENTS_FOR_RANKING)).toBe('platinum')
  })

  it('safety status maps >0.8, >0.5, <=0.5 correctly', () => {
    expect(deriveSafetyStatus('81', '19')).toBe('verified')
    expect(deriveSafetyStatus('80', '20')).toBe('unverified')
    expect(deriveSafetyStatus('51', '49')).toBe('unverified')
    expect(deriveSafetyStatus('50', '50')).toBe('flagged')
    expect(deriveSafetyStatus('0', '100')).toBe('flagged')
  })

  it('covers zero-stake and single-entity edge cases', () => {
    expect(deriveSafetyStatus('0', '0')).toBe('unverified')

    const singleVault = makeVault('0x1', '1000000000000000000', 10)
    const singleSignal = computeTrustSignal(singleVault, [singleVault])
    expect(singleSignal.tier).toBe('unranked')

    const zeroStakeVault = makeVault('0x2', '1000000000000000000', 0)
    const mixedSignal = computeTrustSignal(zeroStakeVault, [
      zeroStakeVault,
      makeVault('0x3', '2000000000000000000', 2),
      makeVault('0x4', '3000000000000000000', 3),
    ])
    expect(mixedSignal.tier).toBe('unranked')
  })

  it('computes safety signal ratios deterministically', () => {
    const signal = computeSafetySignal(8, 2, '800', '200')
    expect(signal.status).toBe('unverified')
    expect(signal.safetyRatio).toBe(0.8)
    expect(signal.forCount).toBe(8)
    expect(signal.againstCount).toBe(2)
  })

  it('benchmark guard: trust+safety computations remain fast locally', () => {
    const vaults = Array.from({ length: 500 }, (_, i) =>
      makeVault(`0x${i}`, `${(i + 1) * 1000000000000000}`, (i % 50) + 1),
    )

    const start = performance.now()
    for (let i = 0; i < 500; i += 1) {
      computeTrustSignal(vaults[i % vaults.length], vaults)
      computeSafetySignal(10, 2, '1000', '200')
    }
    const elapsedMs = performance.now() - start

    expect(elapsedMs).toBeLessThan(500)
  })
})
