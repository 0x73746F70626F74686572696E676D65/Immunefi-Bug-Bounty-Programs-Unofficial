export const GET_ATOMS = `
  query GetAtoms(
    $where: atoms_bool_exp
    $orderBy: [atoms_order_by!]
    $limit: Int
    $offset: Int
  ) {
    total: atoms_aggregate(where: $where) {
      aggregate {
        count
      }
    }
    atoms(where: $where, order_by: $orderBy, limit: $limit, offset: $offset) {
      term_id
      label
      wallet_id
      image
      cached_image {
        url
        safe
      }
      type
      created_at
      data
      creator {
        id
        atom_id
        label
        image
        cached_image {
          url
          safe
        }
        type
      }
      value {
        person {
          name
          image
          cached_image { url safe }
          url
        }
        thing {
          name
          image
          cached_image { url safe }
          url
        }
        organization {
          name
          image
          url
        }
        account {
          id
          label
          image
          cached_image { url safe }
        }
        json_object {
          description: data(path: "description")
        }
      }
      term {
        total_market_cap
        positions_aggregate {
          aggregate {
            count
          }
        }
        vaults(order_by: { curve_id: asc }) {
          term_id
          curve_id
          current_share_price
          total_shares
          total_assets
          position_count
          market_cap
        }
      }
    }
  }
`

export const GET_ATOM_DETAIL = `
  query GetAtomDetail($termId: String!) {
    atom(term_id: $termId) {
      term_id
      label
      wallet_id
      image
      cached_image {
        url
        safe
      }
      type
      created_at
      updated_at
      data
      creator {
        id
        atom_id
        label
        image
        cached_image { url safe }
        type
      }
      value {
        person {
          name
          image
          cached_image { url safe }
          url
        }
        thing {
          name
          image
          cached_image { url safe }
          url
        }
        organization {
          name
          image
          url
        }
        account {
          id
          label
          image
          cached_image { url safe }
        }
        json_object {
          description: data(path: "description")
        }
      }
      term {
        total_market_cap
        positions_aggregate {
          aggregate {
            count
          }
        }
        vaults(order_by: { curve_id: asc }) {
          term_id
          curve_id
          current_share_price
          total_shares
          total_assets
          position_count
          market_cap
        }
      }
      as_subject_triples {
        term_id
        predicate {
          term_id
          label
          image
          cached_image { url safe }
        }
        object {
          term_id
          label
          image
          cached_image { url safe }
          type
          data
          value {
            person { name image url }
            thing { name image url }
            organization { name image url }
          }
        }
      }
    }
  }
`

export const SEARCH_ATOMS = `
  query SearchAtoms($searchTerm: String!, $limit: Int, $offset: Int) {
    atoms(
      where: {
        _or: [
          { label: { _ilike: $searchTerm } }
          { data: { _ilike: $searchTerm } }
        ]
      }
      limit: $limit
      offset: $offset
      order_by: [{ term: { vaults_aggregate: { sum: { total_assets: desc } } } }]
    ) {
      term_id
      label
      image
      cached_image {
        url
        safe
      }
      type
      data
      creator {
        id
        label
        image
      }
      term {
        vaults(order_by: { curve_id: asc }) {
          total_assets
          position_count
          market_cap
        }
      }
    }
  }
`
