import { useState, useEffect } from 'react'
import * as Collapsible from '@radix-ui/react-collapsible'
import type { Skill, Agent } from '~/types'
import { cn } from '~/lib/utils'
import { Badge } from '../ui/Badge'
import { AgentCard } from '../registry/AgentCard'
import { useRepository } from '~/data'

interface SkillCapabilityZoneProps {
  skill: Skill
  className?: string
}

export function SkillCapabilityZone({ skill, className }: SkillCapabilityZoneProps) {
  const { capabilities } = skill
  const [isOpen, setIsOpen] = useState(true)
  const [usedByAgents, setUsedByAgents] = useState<Agent[]>([])
  const repository = useRepository()

  useEffect(() => {
    // Find agents that use this skill (via uses-skill triple pointing to this skill)
    const fetchAgents = async () => {
      try {
        // Search all agents and filter by triples
        const allAgents = await repository.searchAgents('', {})
        const agentsThatUseThisSkill = allAgents.filter((agent) =>
          agent.triples.some(
            (triple) =>
              triple.predicate.label === 'uses-skill' &&
              triple.object?.term_id === skill.id,
          ),
        )
        setUsedByAgents(agentsThatUseThisSkill)
      } catch (error) {
        console.error('Failed to fetch agents using this skill:', error)
      }
    }

    fetchAgents()
  }, [skill.id, repository])

  return (
    <div className={cn('rounded-lg border border-border bg-card p-6', className)}>
      <Collapsible.Root open={isOpen} onOpenChange={setIsOpen}>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-card-foreground">Capabilities</h2>
          <Collapsible.Trigger asChild>
            <button
              type="button"
              className="text-muted-foreground hover:text-foreground transition-colors"
              aria-label={isOpen ? 'Collapse' : 'Expand'}
            >
              <svg
                className={cn('w-5 h-5 transition-transform', isOpen && 'rotate-180')}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M19 9l-7 7-7-7"
                />
              </svg>
            </button>
          </Collapsible.Trigger>
        </div>

        <Collapsible.Content>
          <div className="space-y-6">
            {/* What This Skill Provides */}
            <div>
              <h3 className="text-sm font-medium text-card-foreground mb-3">
                What This Skill Provides
              </h3>
              {capabilities.length > 0 ? (
                <div className="space-y-3">
                  {capabilities.map((cap) => (
                    <div key={cap.id} className="flex items-start gap-2">
                      <Badge label={cap.name} />
                      {cap.description && (
                        <span className="text-sm text-muted-foreground flex-1">
                          {cap.description}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No capabilities specified</p>
              )}
            </div>

            {/* Used By Agents */}
            <div>
              <h3 className="text-sm font-medium text-card-foreground mb-3">
                Used By Agents
                <span className="ml-2 text-xs text-muted-foreground font-normal">
                  ({usedByAgents.length})
                </span>
              </h3>
              {usedByAgents.length > 0 ? (
                <div className="grid gap-3">
                  {usedByAgents.map((agent) => (
                    <AgentCard key={agent.id} agent={agent} />
                  ))}
                </div>
              ) : (
                <div className="p-4 rounded-lg bg-muted/50 border border-border text-center">
                  <p className="text-sm text-muted-foreground">
                    No registered agents use this skill yet
                  </p>
                </div>
              )}
            </div>
          </div>
        </Collapsible.Content>
      </Collapsible.Root>
    </div>
  )
}
