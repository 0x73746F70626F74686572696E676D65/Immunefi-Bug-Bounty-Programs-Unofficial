# Trust Model Artifacts

This module defines first-class trust model artifacts for deterministic scoring.

## Artifact Contract

Each artifact must include:

- `modelId`
- `version` (semver)
- `author`
- `domain`
- `inputs`
- `formulaSpec` (declarative only)
- `normalization`
- `outputSemantics`
- `compatibility`
- optional `extensions`

## Versioning And Compatibility Policy

- Versioning follows semver (`MAJOR.MINOR.PATCH`).
- `PATCH` changes must preserve output semantics and input contract.
- `MINOR` changes may add optional inputs or extension fields without breaking existing consumers.
- `MAJOR` changes may alter required inputs, formula behavior, or output meaning.
- `compatibility.minCompatibleVersion` communicates the lowest model version that can safely consume equivalent input payloads.
- `compatibility.breaking=true` must be set whenever a change requires consumer migration.

## Determinism Rules

- Artifacts are validated via `trustModelArtifactSchema`.
- Canonical serialization is generated with stable key ordering.
- Model digests are SHA-256 of canonical artifacts.
- Equivalent JSON objects with different field ordering must produce identical digests.

## Extension Namespace Strategy

- Non-standard fields must go under `extensions`.
- Extension keys must be reverse-DNS namespaces (for example `org.motherdao`).
- Extension payloads are namespaced and ignored by base evaluators unless explicitly supported.
