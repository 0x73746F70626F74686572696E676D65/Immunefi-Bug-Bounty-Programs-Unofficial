/**
 * IPFS metadata schemas for Agent Registry entities.
 *
 * This module exports Zod schemas for validating agent and skill metadata
 * stored on IPFS. All metadata must conform to these schemas before being
 * uploaded.
 */

export {
  AgentMetadataSchema,
  type AgentMetadata,
} from './agent-metadata';

export {
  SkillMetadataSchema,
  SkillPlatform,
  type SkillMetadataPayload,
  type SkillPlatformType,
} from './skill-metadata';
