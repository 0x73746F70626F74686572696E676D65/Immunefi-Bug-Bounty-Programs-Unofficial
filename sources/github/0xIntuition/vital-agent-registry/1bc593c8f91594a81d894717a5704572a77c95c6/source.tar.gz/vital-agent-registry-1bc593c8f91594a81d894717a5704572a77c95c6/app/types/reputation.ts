export type ReputationTrend = 'improving' | 'stable' | 'declining'

export interface DomainScore {
  domain: string
  taskCount: number
  successRate: number
  avgQuality: number
  vaultTvl?: string
}

export interface ReputationProfile {
  totalTasks: number
  successRate: number
  avgQuality: number
  domainScores: DomainScore[]
  recentTrend: ReputationTrend
  compositeScore: number
}
