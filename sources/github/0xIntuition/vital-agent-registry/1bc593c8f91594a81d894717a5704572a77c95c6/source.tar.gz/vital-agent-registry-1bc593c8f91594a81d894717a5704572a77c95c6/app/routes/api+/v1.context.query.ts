import type { ActionFunctionArgs, LoaderFunctionArgs } from 'react-router'
import { handleOptions, parseJsonBody, jsonResponse, errorResponse } from '~/lib/api/types'
import {
  CANONICAL_CONTEXT_PREDICATES,
  contextQuerySchema,
  evaluateContextQuery,
  assertCanonicalContextClaims,
} from '~/lib/context-query'

export async function loader({ request }: LoaderFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes
  return jsonResponse({
    canonicalPredicates: CANONICAL_CONTEXT_PREDICATES,
    notes: 'Use POST to evaluate base + context layers.',
  })
}

export async function action({ request }: ActionFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const parsed = await parseJsonBody(request, contextQuerySchema)
  if ('error' in parsed) return parsed.error

  const validity = assertCanonicalContextClaims(parsed.data.contextClaims)
  if (!validity.ok) {
    return errorResponse(
      'Context claims violate canonical predicate requirements',
      validity.reason,
      400,
      {
        canonicalPredicates: CANONICAL_CONTEXT_PREDICATES,
        ...validity,
      },
    )
  }

  const layers = evaluateContextQuery(parsed.data)
  return jsonResponse({
    canonicalPredicates: CANONICAL_CONTEXT_PREDICATES,
    ...layers,
  })
}
