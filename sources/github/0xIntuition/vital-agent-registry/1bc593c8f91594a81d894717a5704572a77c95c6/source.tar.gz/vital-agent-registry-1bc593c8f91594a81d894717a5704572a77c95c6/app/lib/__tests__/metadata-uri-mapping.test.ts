import { describe, expect, it } from 'vitest'
import { mapAtomToAgent } from '~/lib/graphql/mappers/atom-to-agent'
import { mapAtomToSkill } from '~/lib/graphql/mappers/atom-to-skill'
import type { GraphQLAtom } from '~/lib/graphql/mappers/types'
import type { Vault } from '~/types'

function baseVault(termId: string): Vault {
  return {
    term_id: termId,
    curve_id: '1',
    current_share_price: '1000000000000000000',
    total_shares: '1000000000000000000',
    total_assets: '1000000000000000000',
    market_cap: '1000000000000000000',
    position_count: 1,
  }
}

describe('metadata uri mapping', () => {
  it('maps agent metadataUri from ipfs thing.url', () => {
    const atom: GraphQLAtom = {
      term_id: '0xagent',
      label: 'Agent Atom',
      value: {
        thing: {
          name: 'Agent',
          description: 'Agent desc',
          url: 'ipfs://bafy-agent-meta',
        },
      },
      term: {
        vaults: [baseVault('0xagent-vault')],
      },
      as_subject_triples: [],
    }

    const agent = mapAtomToAgent(atom, [baseVault('0xagent-vault')])
    expect(agent.metadata.metadataUri).toBe('ipfs://bafy-agent-meta')
  })

  it('maps skill metadataUri from metadata_uri json field', () => {
    const atom: GraphQLAtom = {
      term_id: '0xskill',
      label: 'Skill Atom',
      data: JSON.stringify({
        description: 'Skill desc',
        version: '1.0.0',
        platform: 'mcp',
        metadata_uri: 'ipfs://bafy-skill-meta',
      }),
      value: {
        thing: {
          name: 'Skill',
          description: 'Skill desc',
        },
      },
      term: {
        vaults: [baseVault('0xskill-vault')],
      },
      as_subject_triples: [],
    }

    const skill = mapAtomToSkill(atom, [baseVault('0xskill-vault')])
    expect(skill.metadata.metadataUri).toBe('ipfs://bafy-skill-meta')
  })
})
