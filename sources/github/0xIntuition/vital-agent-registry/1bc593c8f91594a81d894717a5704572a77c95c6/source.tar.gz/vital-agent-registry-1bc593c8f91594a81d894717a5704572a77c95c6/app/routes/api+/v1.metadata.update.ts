import type { ActionFunctionArgs } from 'react-router'
import { createPublicClient, http, parseEventLogs } from 'viem'
import { handleOptions, parseJsonBody, jsonResponse, errorResponse, corsHeaders } from '~/lib/api/types'
import { metadataUpdateSchema } from '~/lib/api/validation'
import {
  uploadAgentMetadata,
  uploadSkillMetadata,
  IpfsUploadError,
} from '~/.server/ipfs'
import { createLocalWriteClients, getLocalWriteContext } from '~/.server/local-write'
import {
  encodeCreateAtomCalldata,
  encodeCreateTriplesCalldata,
  deriveAtomTermId,
} from '~/lib/calldata'
import { getAtomCost, getTripleCost, createAtoms, createTriples, getAtomByUri, getMinimumDeposit } from '~/.server/multivault'
import { multivaultAbi } from '~/lib/abis/multivault'
import { requireExecuteAuth } from '~/.server/execute-auth'
import { assertRemoteWriteAllowed, RemoteWriteGuardError } from '~/.server/remote-write-guard'
import { registrationLimiter, getClientIP, isRegistrationRateLimitEnabled } from '~/lib/rate-limit'
import { getContractAddress, getRpcUrl, getChainConfig } from '~/lib/constants/protocol'
import type { NetworkId } from '~/lib/constants/protocol'
import { getPredicates } from '~/.server/term-ids'

function isResolvedTermId(value: string | undefined): value is `0x${string}` {
  return Boolean(value && /^0x[0-9a-fA-F]{64}$/.test(value) && !value.startsWith('0x_placeholder_'))
}

export async function action({ request }: ActionFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const url = new URL(request.url)
  const execute = url.searchParams.get('execute') === 'true'

  if (execute) {
    const auth = requireExecuteAuth(request)
    if (!auth.authorized) return auth.response
  }

  // Rate limit check
  if (isRegistrationRateLimitEnabled()) {
    const ip = getClientIP(request)
    const limit = registrationLimiter.check(ip)
    if (!limit.allowed) {
      return new Response(
        JSON.stringify({
          error: 'Too many requests',
          code: 'RATE_LIMITED',
          retryAfter: Math.ceil((limit.resetAt - Date.now()) / 1000),
        }),
        {
          status: 429,
          headers: {
            ...corsHeaders(),
            'Content-Type': 'application/json',
            'Retry-After': String(Math.ceil((limit.resetAt - Date.now()) / 1000)),
          },
        }
      )
    }
  }

  const parsed = await parseJsonBody(request, metadataUpdateSchema)
  if ('error' in parsed) return parsed.error

  const payload = parsed.data
  const chain = (process.env.CHAIN as NetworkId) || 'testnet'
  const contractAddress = getContractAddress(chain)
  const rpcUrl = getRpcUrl(chain)

  try {
    const PREDICATES = getPredicates()

    if (!execute) {
      assertRemoteWriteAllowed({
        action: `prepare ${payload.entityType} metadata update`,
        target: 'ipfs + chain',
      })
    }

    const ipfsUri =
      payload.entityType === 'agent'
        ? await uploadAgentMetadata(payload.metadata)
        : await uploadSkillMetadata(payload.metadata)
    const metadataTermId = deriveAtomTermId(ipfsUri)

    const hasMetadataPredicateTermId =
      payload.hasMetadataPredicateTermId ?? PREDICATES.HAS_METADATA
    if (!isResolvedTermId(hasMetadataPredicateTermId)) {
      return errorResponse(
        'has-metadata predicate term id is required and must be resolved',
        'HAS_METADATA_TERM_ID_REQUIRED',
        400,
      )
    }

    const atomCalldata = encodeCreateAtomCalldata(ipfsUri, 0n)
    const tripleCalldata = encodeCreateTriplesCalldata(
      [
        {
          subjectId: payload.entityTermId,
          predicateId: hasMetadataPredicateTermId,
          objectId: metadataTermId,
        },
      ],
      0n,
    )

    const publicClient = createPublicClient({
      transport: http(rpcUrl),
    })
    const atomCost = await getAtomCost(publicClient, contractAddress)
    const tripleCost = await getTripleCost(publicClient, contractAddress)

    const response = {
      baseTermId: payload.entityTermId,
      metadataTermId,
      ipfsUri,
      contractAddress,
      chainId: getChainConfig(chain).chainId,
      transactions: [
        {
          signatureIndex: 1,
          kind: 'createAtoms',
          to: contractAddress,
          data: atomCalldata,
          value: atomCost.toString(),
        },
        {
          signatureIndex: 2,
          kind: 'createTriples',
          to: contractAddress,
          data: tripleCalldata,
          value: tripleCost.toString(),
          tripleCount: 1,
        },
      ],
      signaturePlan: {
        requiredSignatures: 2,
        baseIdentityPreserved: true,
      },
      latestMetadataResolver: {
        predicateTermId: hasMetadataPredicateTermId,
        sort: ['blockNumber desc', 'logIndex desc'],
      },
      history: {
        inspectable: true,
        relation: 'has-metadata',
      },
    }

    if (!execute) {
      return jsonResponse(response)
    }

    // Execute mode: create atom + triple on local chain
    const context = getLocalWriteContext()
    const { publicClient: localPublicClient, walletClient } = await createLocalWriteClients(context)
    const minimumDeposit = await getMinimumDeposit(localPublicClient, context.contractAddress)

    // Check for existing metadata atom
    const existingMetadataTermId = await getAtomByUri(
      localPublicClient,
      context.contractAddress,
      ipfsUri,
    )

    let atomExecution: { hash: `0x${string}`; atomCount: number } | null = null
    let resolvedMetadataTermId: `0x${string}` | null = existingMetadataTermId

    if (!existingMetadataTermId) {
      atomExecution = await createAtoms(
        localPublicClient,
        walletClient,
        context.contractAddress,
        [ipfsUri],
        minimumDeposit,
      )
      const atomReceipt = await localPublicClient.waitForTransactionReceipt({ hash: atomExecution.hash })
      const atomCreatedLogs = parseEventLogs({
        abi: multivaultAbi,
        logs: atomReceipt.logs,
        eventName: 'AtomCreated',
      })
      if (atomCreatedLogs[0]?.args?.termId) {
        resolvedMetadataTermId = atomCreatedLogs[0].args.termId as `0x${string}`
      }
    }

    // Fallback: resolve by URI
    if (!resolvedMetadataTermId) {
      resolvedMetadataTermId = await getAtomByUri(
        localPublicClient,
        context.contractAddress,
        ipfsUri,
      )
    }

    const finalMetadataTermId = resolvedMetadataTermId ?? metadataTermId

    // Create has-metadata triple
    let tripleExecution: { hash: `0x${string}`; tripleCount: number } | null = null
    const tripleData = [{
      subjectId: payload.entityTermId as `0x${string}`,
      predicateId: hasMetadataPredicateTermId,
      objectId: finalMetadataTermId,
    }]

    tripleExecution = await createTriples(
      localPublicClient,
      walletClient,
      context.contractAddress,
      tripleData,
      minimumDeposit,
    )
    await localPublicClient.waitForTransactionReceipt({ hash: tripleExecution.hash })

    return jsonResponse({
      ...response,
      metadataTermId: finalMetadataTermId,
      execution: {
        mode: 'local',
        executed: true,
        account: walletClient.account?.address ?? null,
        atomTxHash: atomExecution?.hash ?? null,
        metadataAlreadyExisted: Boolean(existingMetadataTermId),
        existingMetadataTermId,
        resolvedMetadataTermId,
        tripleTxHash: tripleExecution?.hash ?? null,
      },
    })
  } catch (error) {
    if (error instanceof RemoteWriteGuardError) {
      return errorResponse(
        'Remote writes are blocked by default in local-safe mode',
        error.code,
        403,
        {
          message: error.message,
          requiredOverride: 'ALLOW_REMOTE_WRITES=1 and REGISTRY_WRITE_PROFILE=shared',
          profile: error.profile,
          target: error.target,
          action: error.action,
        },
      )
    }
    if (error instanceof IpfsUploadError) {
      if (error.category === 'validation') {
        return errorResponse('Metadata validation failed', 'VALIDATION_ERROR', 400, {
          category: error.category,
          message: error.message,
        })
      }
      if (error.category === 'upstream') {
        return errorResponse('IPFS upstream failure', 'UPSTREAM_IPFS_ERROR', 502, {
          category: error.category,
          message: error.message,
        })
      }
      return errorResponse('IPFS internal failure', 'INTERNAL_IPFS_ERROR', 500, {
        category: error.category,
        message: error.message,
      })
    }
    return errorResponse('Metadata update preparation failed', 'INTERNAL_ERROR', 500, {
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
}
