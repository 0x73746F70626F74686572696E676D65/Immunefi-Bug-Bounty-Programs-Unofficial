import { z } from 'zod'

export interface ApiResponse<T> {
  data: T
  meta?: PaginationMeta
}

export interface PaginationMeta {
  total: number
  limit: number
  offset: number
}

export interface ApiError {
  error: string
  code: string
  details?: unknown
}

export function jsonResponse<T>(data: T, meta?: PaginationMeta, status = 200): Response {
  const body: ApiResponse<T> = { data, ...(meta && { meta }) }
  return new Response(JSON.stringify(body), {
    status,
    headers: corsHeaders({ 'Content-Type': 'application/json' }),
  })
}

export function errorResponse(error: string, code: string, status: number, details?: unknown): Response {
  const body: ApiError = { error, code, ...(details !== undefined && { details }) }
  return new Response(JSON.stringify(body), {
    status,
    headers: corsHeaders({ 'Content-Type': 'application/json' }),
  })
}

export function corsHeaders(extra: Record<string, string> = {}): Record<string, string> {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    ...extra,
  }
}

export function handleOptions(request: Request): Response | null {
  if (request.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders() })
  }
  return null
}

export async function parseJsonBody<T>(
  request: Request,
  schema: z.ZodSchema<T>,
): Promise<{ data: T } | { error: Response }> {
  let body: unknown
  try {
    body = await request.json()
  } catch {
    return { error: errorResponse('Invalid JSON body', 'PARSE_ERROR', 400) }
  }
  const parsed = schema.safeParse(body)
  if (!parsed.success) {
    return { error: errorResponse('Invalid request body', 'VALIDATION_ERROR', 400, parsed.error.flatten().fieldErrors) }
  }
  return { data: parsed.data }
}

export function parseQueryParams<T>(
  request: Request,
  schema: z.ZodSchema<T>,
): { data: T } | { error: Response } {
  const url = new URL(request.url)
  const raw = Object.fromEntries(url.searchParams)
  const parsed = schema.safeParse(raw)
  if (!parsed.success) {
    return { error: errorResponse('Invalid query parameters', 'VALIDATION_ERROR', 400, parsed.error.flatten().fieldErrors) }
  }
  return { data: parsed.data }
}
