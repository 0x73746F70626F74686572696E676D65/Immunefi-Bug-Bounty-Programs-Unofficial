import { describe, expect, it, vi } from 'vitest';
import { pollForAtom } from './indexer-poll';

describe('pollForAtom', () => {
  it('should return true immediately if atom found on first check', async () => {
    const checkFn = vi.fn().mockResolvedValue(true);

    const result = await pollForAtom('0x123', checkFn, {
      initialDelayMs: 100,
      maxRetries: 3,
    });

    expect(result).toBe(true);
    expect(checkFn).toHaveBeenCalledTimes(1);
    expect(checkFn).toHaveBeenCalledWith('0x123');
  });

  it('should retry with exponential backoff until found', async () => {
    const checkFn = vi
      .fn()
      .mockResolvedValueOnce(false)
      .mockResolvedValueOnce(false)
      .mockResolvedValueOnce(true);

    const startTime = Date.now();
    const result = await pollForAtom('0x123', checkFn, {
      initialDelayMs: 100,
      maxDelayMs: 10000,
      maxRetries: 5,
    });
    const duration = Date.now() - startTime;

    expect(result).toBe(true);
    expect(checkFn).toHaveBeenCalledTimes(3);
    // First attempt immediate, second after 100ms, third after 200ms
    // Total should be around 300ms
    expect(duration).toBeGreaterThanOrEqual(300);
    expect(duration).toBeLessThan(500);
  });

  it('should return false after max retries exceeded', async () => {
    const checkFn = vi.fn().mockResolvedValue(false);

    const result = await pollForAtom('0x123', checkFn, {
      initialDelayMs: 10,
      maxRetries: 3,
    });

    expect(result).toBe(false);
    // Initial check + 3 retries = 4 total
    expect(checkFn).toHaveBeenCalledTimes(4);
  });

  it('should call onProgress callback for each attempt', async () => {
    const checkFn = vi
      .fn()
      .mockResolvedValueOnce(false)
      .mockResolvedValueOnce(false)
      .mockResolvedValueOnce(true);

    const onProgress = vi.fn();

    await pollForAtom('0x123', checkFn, {
      initialDelayMs: 10,
      maxRetries: 5,
      onProgress,
    });

    // Should be called for each attempt that returns (including final success)
    expect(onProgress).toHaveBeenCalledTimes(3);
    expect(onProgress).toHaveBeenNthCalledWith(1, 1);
    expect(onProgress).toHaveBeenNthCalledWith(2, 2);
    expect(onProgress).toHaveBeenNthCalledWith(3, 3);
  });

  it('should cap delay at maxDelayMs', async () => {
    const checkFn = vi
      .fn()
      .mockResolvedValueOnce(false)
      .mockResolvedValueOnce(false)
      .mockResolvedValueOnce(false)
      .mockResolvedValueOnce(true);

    const startTime = Date.now();
    const result = await pollForAtom('0x123', checkFn, {
      initialDelayMs: 100,
      maxDelayMs: 150,
      maxRetries: 5,
    });
    const duration = Date.now() - startTime;

    expect(result).toBe(true);
    // Delays: 100ms, 150ms (capped from 200), 150ms (capped from 400)
    // Total should be around 400ms
    expect(duration).toBeGreaterThanOrEqual(400);
    expect(duration).toBeLessThan(600);
  });

  it('should use default options when not provided', async () => {
    const checkFn = vi.fn().mockResolvedValue(true);

    const result = await pollForAtom('0x123', checkFn);

    expect(result).toBe(true);
    expect(checkFn).toHaveBeenCalledTimes(1);
  });

  it('should handle checkFn errors', async () => {
    const checkFn = vi.fn().mockRejectedValue(new Error('Network error'));

    await expect(
      pollForAtom('0x123', checkFn, {
        initialDelayMs: 10,
        maxRetries: 2,
      })
    ).rejects.toThrow('Network error');
  });

  it('should handle checkFn that throws on some attempts', async () => {
    const checkFn = vi
      .fn()
      .mockResolvedValueOnce(false)
      .mockRejectedValueOnce(new Error('Temporary error'))
      .mockResolvedValueOnce(true);

    await expect(
      pollForAtom('0x123', checkFn, {
        initialDelayMs: 10,
        maxRetries: 5,
      })
    ).rejects.toThrow('Temporary error');
  });
});
