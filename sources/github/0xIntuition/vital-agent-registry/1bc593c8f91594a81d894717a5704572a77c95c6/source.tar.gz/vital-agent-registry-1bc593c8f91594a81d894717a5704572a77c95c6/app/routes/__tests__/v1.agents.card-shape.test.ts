import { describe, expect, it, vi } from 'vitest'
import type { LoaderFunctionArgs } from 'react-router'

const getAgentCard = vi.fn()

vi.mock('~/data/repository/provider', () => ({
  createRepository: () => ({
    getAgentCard,
  }),
}))

function makeArgs(agentId: string): LoaderFunctionArgs {
  return {
    request: new Request(`https://registry.local/api/v1/agents/${agentId}/card`),
    params: { id: agentId },
    context: {},
  } as unknown as LoaderFunctionArgs
}

describe('GET /api/v1/agents/:id/card', () => {
  it('returns required A2A fields used by endpoints', async () => {
    getAgentCard.mockResolvedValueOnce({
      id: '0xagent',
      name: 'Agent',
      description: 'Agent description',
      url: 'https://agent.example',
      provider: { name: 'Provider' },
      version: '1.0.0',
      skills: [
        {
          id: 'skill-1',
          name: 'Skill',
          description: 'Skill description',
        },
      ],
      defaultInputModes: ['text/plain'],
      defaultOutputModes: ['application/json'],
    })

    const { loader } = await import('../api+/v1.agents.$id.card')
    const response = await loader(makeArgs('0xagent'))
    expect(response.status).toBe(200)

    const payload = await response.json()
    const card = payload.data
    expect(card.id).toBeTruthy()
    expect(card.name).toBeTruthy()
    expect(card.description).toBeTruthy()
    expect(card.url).toBeTruthy()
    expect(card.provider?.name).toBeTruthy()
    expect(card.version).toBeTruthy()
    expect(Array.isArray(card.skills)).toBe(true)
    expect(Array.isArray(card.defaultInputModes)).toBe(true)
    expect(Array.isArray(card.defaultOutputModes)).toBe(true)
  })
})
