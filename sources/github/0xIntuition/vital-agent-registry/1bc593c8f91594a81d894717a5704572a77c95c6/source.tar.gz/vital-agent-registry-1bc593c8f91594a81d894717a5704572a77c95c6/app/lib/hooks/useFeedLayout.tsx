import { createContext, useContext, useState, useCallback } from 'react'
import type { ReactNode } from 'react'

export type FeedLayout = 'list' | 'carousel' | 'grid'

interface FeedLayoutContextValue {
  layout: FeedLayout
  setLayout: (layout: FeedLayout) => void
  cycleLayout: () => void
}

const FeedLayoutContext = createContext<FeedLayoutContextValue | null>(null)

const STORAGE_KEY = 'agent-feed-layout'
const DEFAULT_LAYOUT: FeedLayout = 'list'

const CYCLE_ORDER: FeedLayout[] = ['list', 'carousel', 'grid']

function getInitialLayout(): FeedLayout {
  if (typeof window === 'undefined') return DEFAULT_LAYOUT
  const stored = localStorage.getItem(STORAGE_KEY)
  if (stored === 'list' || stored === 'carousel' || stored === 'grid') {
    return stored
  }
  return DEFAULT_LAYOUT
}

export function FeedLayoutProvider({ children }: { children: ReactNode }) {
  const [layout, setLayoutState] = useState<FeedLayout>(getInitialLayout)

  const setLayout = useCallback((next: FeedLayout) => {
    setLayoutState(next)
    localStorage.setItem(STORAGE_KEY, next)
  }, [])

  const cycleLayout = useCallback(() => {
    setLayoutState((prev) => {
      const idx = CYCLE_ORDER.indexOf(prev)
      const next = CYCLE_ORDER[(idx + 1) % CYCLE_ORDER.length]
      localStorage.setItem(STORAGE_KEY, next)
      return next
    })
  }, [])

  return (
    <FeedLayoutContext.Provider value={{ layout, setLayout, cycleLayout }}>
      {children}
    </FeedLayoutContext.Provider>
  )
}

export function useFeedLayout() {
  const ctx = useContext(FeedLayoutContext)
  if (!ctx) throw new Error('useFeedLayout must be used within FeedLayoutProvider')
  return ctx
}
