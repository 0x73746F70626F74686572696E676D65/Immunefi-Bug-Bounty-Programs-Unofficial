import type { PublicClient, WalletClient, Hash } from 'viem';
import { toHex } from 'viem';
import { multivaultAbi } from '~/lib/abis/multivault';
import { stringToBytes32 } from '~/lib/id-conversion';

const legacyAtomAbi = [
  {
    type: 'function',
    name: 'createAtom',
    stateMutability: 'payable',
    inputs: [{ name: 'atomUri', type: 'bytes' }],
    outputs: [{ name: '', type: 'uint256' }],
  },
] as const;

const legacyDepositAtomAbi = [
  {
    type: 'function',
    name: 'depositAtom',
    stateMutability: 'payable',
    inputs: [
      { name: 'receiver', type: 'address' },
      { name: 'id', type: 'uint256' },
    ],
    outputs: [{ name: '', type: 'uint256' }],
  },
] as const;

/**
 * Gets the fixed cost (in wei) to create a single atom.
 *
 * This is the protocol fee charged for creating an atom, separate from
 * the initial deposit amount. The total cost is atomCost + depositAmount.
 *
 * @param client - Configured viem PublicClient
 * @param contractAddress - MultiVault contract address
 * @returns Atom creation cost in wei
 *
 * @example
 * ```typescript
 * const cost = await getAtomCost(publicClient, CONTRACTS.MULTIVAULT_TESTNET);
 * // cost = 10000000000000000n (0.01 ETH on testnet)
 * ```
 */
export async function getAtomCost(
  client: PublicClient,
  contractAddress: `0x${string}`
): Promise<bigint> {
  return await client.readContract({
    address: contractAddress,
    abi: multivaultAbi,
    functionName: 'getAtomCost',
  });
}

/**
 * Gets the fixed cost (in wei) to create a single triple.
 *
 * This is the protocol fee charged for creating a triple, separate from
 * the deposit amount. The total cost is tripleCost + depositAmount.
 *
 * @param client - Configured viem PublicClient
 * @param contractAddress - MultiVault contract address
 * @returns Triple creation cost in wei
 *
 * @example
 * ```typescript
 * const cost = await getTripleCost(publicClient, CONTRACTS.MULTIVAULT_TESTNET);
 * // cost = 10000000000000000n (0.01 ETH on testnet)
 * ```
 */
export async function getTripleCost(
  client: PublicClient,
  contractAddress: `0x${string}`
): Promise<bigint> {
  return await client.readContract({
    address: contractAddress,
    abi: multivaultAbi,
    functionName: 'getTripleCost',
  });
}

export async function getMinimumDeposit(
  client: PublicClient,
  contractAddress: `0x${string}`
): Promise<bigint> {
  const readConfig = async (fn: 'generalConfig' | 'getGeneralConfig') =>
    client.readContract({
      address: contractAddress,
      abi: multivaultAbi,
      functionName: fn,
    });

  // Support both deployed protocol variants.
  const config = await readConfig('generalConfig').catch(async () => readConfig('getGeneralConfig'));

  if (Array.isArray(config) && config.length >= 5) {
    // Support both layouts:
    // - Legacy EthMultiVault: index 3 = minDeposit
    // - Current MultiVault: index 3 = trustBonding (address), index 4 = minDeposit
    const fourth = config[3] as unknown;
    const isAddress =
      typeof fourth === 'string' &&
      fourth.startsWith('0x') &&
      fourth.length === 42;
    return BigInt((isAddress ? config[4] : config[3]) as bigint | number | string);
  }

  const maybeConfig = config as { minDeposit?: bigint | number | string };
  if (maybeConfig.minDeposit !== undefined) {
    return BigInt(maybeConfig.minDeposit);
  }

  return 1n;
}

/**
 * Gets the atom by its IPFS URI.
 *
 * Returns the term_id (as bytes32) if the atom exists, or null if it doesn't.
 * This is useful for checking if an atom already exists before creating it.
 *
 * @param client - Configured viem PublicClient
 * @param contractAddress - MultiVault contract address
 * @param uri - The IPFS URI of the atom (e.g., "ipfs://QmX...")
 * @returns The term_id (bytes32) if atom exists, null otherwise
 *
 * @example
 * ```typescript
 * const termId = await getAtomByUri(publicClient, CONTRACTS.MULTIVAULT_TESTNET, "ipfs://QmX...");
 * if (!termId) {
 *   console.log("Atom does not exist");
 * }
 * ```
 */
export async function getAtomByUri(
  client: PublicClient,
  contractAddress: `0x${string}`,
  uri: string
): Promise<`0x${string}` | null> {
  try {
    // Convert URI to bytes and compute atomId
    const atomData = toHex(uri); // SEC-05: Use viem's toHex
    const atomId = await client.readContract({
      address: contractAddress,
      abi: multivaultAbi,
      functionName: 'calculateAtomId',
      args: [atomData],
    });

    // Check if atom exists
    const exists = await client.readContract({
      address: contractAddress,
      abi: multivaultAbi,
      functionName: 'isTermCreated',
      args: [atomId],
    });

    return exists ? atomId : null;
  } catch {
    // Some local contract variants can revert on calculateAtomId for external calls.
    // Fall back to "unknown" and allow create path to proceed.
    return null;
  }
}

/**
 * Creates multiple atoms in a single transaction.
 *
 * Each atom requires:
 * - IPFS URI (atomData)
 * - Initial deposit amount
 * - Protocol atom creation fee
 *
 * Total msg.value = sum of (atomCost + depositPerAtom) for all atoms.
 *
 * @param publicClient - For reading contract state
 * @param walletClient - For signing/sending transaction
 * @param contractAddress - MultiVault contract address
 * @param atomDataList - Array of IPFS URIs for the atoms
 * @param depositPerAtom - Amount (in wei) to deposit into each atom's vault
 * @returns Transaction hash and count of atoms created
 *
 * @example
 * ```typescript
 * const { hash, atomCount } = await createAtoms(
 *   publicClient,
 *   walletClient,
 *   CONTRACTS.MULTIVAULT_TESTNET,
 *   ["ipfs://QmX...", "ipfs://QmY..."],
 *   parseEther("0.1")  // 0.1 ETH deposit per atom
 * );
 * console.log(`Created ${atomCount} atoms. Hash: ${hash}`);
 * ```
 */
export async function createAtoms(
  publicClient: PublicClient,
  walletClient: WalletClient,
  contractAddress: `0x${string}`,
  atomDataList: string[],
  depositPerAtom: bigint
): Promise<{ hash: Hash; atomCount: number; createdTermIds?: `0x${string}`[] }> {
  if (!walletClient.account) {
    throw new Error('Wallet client must have an account');
  }

  // Get atom creation cost from contract
  const atomCost = await getAtomCost(publicClient, contractAddress);

  // Encode each URI to hex bytes (SEC-05: Use viem's toHex, not raw concatenation)
  const atomDataBytes = atomDataList.map((uri) => toHex(uri));

  // Local protocol runtimes commonly expect assets-per-atom to include base atom cost.
  const assetsPerAtom = atomCost + depositPerAtom;
  const totalValue = assetsPerAtom * BigInt(atomDataList.length);

  // Prepare arrays for contract call
  const deposits = atomDataList.map(() => assetsPerAtom);

  // Execute transaction. Some local stacks still expose legacy createAtom(bytes).
  let hash: Hash;
  try {
    hash = await walletClient.writeContract({
      address: contractAddress,
      abi: multivaultAbi,
      functionName: 'createAtoms',
      args: [atomDataBytes, deposits],
      value: totalValue,
      account: walletClient.account,
      chain: walletClient.chain,
    });
  } catch (error) {
    if (atomDataBytes.length !== 1) throw error;

    // Legacy fallback: create a single atom with adaptive value sizing.
    let candidateValue = assetsPerAtom;
    const step = atomCost > 0n ? atomCost : depositPerAtom > 0n ? depositPerAtom : 10n ** 15n;
    let lastError: unknown = error;

    for (let i = 0; i < 5; i += 1) {
      try {
        const { request, result } = await publicClient.simulateContract({
          address: contractAddress,
          abi: legacyAtomAbi,
          functionName: 'createAtom',
          args: [atomDataBytes[0]],
          value: candidateValue,
          account: walletClient.account,
        });
        hash = await walletClient.writeContract(request);
        const legacyTermId =
          typeof result === 'bigint'
            ? (toHex(result, { size: 32 }) as `0x${string}`)
            : null;
        return {
          hash,
          atomCount: 1,
          createdTermIds: legacyTermId ? [legacyTermId] : undefined,
        };
      } catch (legacyError) {
        lastError = legacyError;
        candidateValue += step;
      }
    }

    throw lastError;
  }

  return {
    hash,
    atomCount: atomDataList.length,
  };
}

/**
 * Creates multiple triples in a single transaction.
 *
 * Each triple requires:
 * - subjectId, predicateId, objectId (all as decimal string or hex bytes32)
 * - Deposit amount
 * - Protocol triple creation fee
 *
 * Total msg.value = sum of (tripleCost + depositPerTriple) for all triples.
 *
 * @param publicClient - For reading contract state
 * @param walletClient - For signing/sending transaction
 * @param contractAddress - MultiVault contract address
 * @param triples - Array of triple definitions (subjectId, predicateId, objectId as strings)
 * @param depositPerTriple - Amount (in wei) to deposit into each triple's vault
 * @returns Transaction hash and count of triples created
 *
 * @example
 * ```typescript
 * const { hash, tripleCount } = await createTriples(
 *   publicClient,
 *   walletClient,
 *   CONTRACTS.MULTIVAULT_TESTNET,
 *   [
 *     { subjectId: "123", predicateId: "456", objectId: "789" },
 *     { subjectId: "111", predicateId: "456", objectId: "222" },
 *   ],
 *   parseEther("0.05")  // 0.05 ETH deposit per triple
 * );
 * console.log(`Created ${tripleCount} triples. Hash: ${hash}`);
 * ```
 */
export async function createTriples(
  publicClient: PublicClient,
  walletClient: WalletClient,
  contractAddress: `0x${string}`,
  triples: Array<{ subjectId: string; predicateId: string; objectId: string }>,
  depositPerTriple: bigint
): Promise<{ hash: Hash; tripleCount: number }> {
  if (!walletClient.account) {
    throw new Error('Wallet client must have an account');
  }

  // Get triple creation cost from contract
  const tripleCost = await getTripleCost(publicClient, contractAddress);

  // Convert string IDs to bytes32 (SEC-05: Use viem utilities)
  const subjectIds = triples.map((t) => stringToBytes32(t.subjectId));
  const predicateIds = triples.map((t) => stringToBytes32(t.predicateId));
  const objectIds = triples.map((t) => stringToBytes32(t.objectId));

  // Local protocol runtimes commonly expect assets-per-triple to include base triple cost.
  const assetsPerTriple = tripleCost + depositPerTriple;
  const totalValue = assetsPerTriple * BigInt(triples.length);

  // Prepare arrays for contract call
  const deposits = triples.map(() => assetsPerTriple);

  // Execute transaction
  const hash = await walletClient.writeContract({
    address: contractAddress,
    abi: multivaultAbi,
    functionName: 'createTriples',
    args: [subjectIds, predicateIds, objectIds, deposits],
    value: totalValue,
    account: walletClient.account,
    chain: walletClient.chain,
  });

  return {
    hash,
    tripleCount: triples.length,
  };
}

export async function depositToTerm(
  publicClient: PublicClient,
  walletClient: WalletClient,
  contractAddress: `0x${string}`,
  params: {
    termId: `0x${string}`;
    assets: bigint;
    receiver?: `0x${string}`;
    curveId?: bigint;
    minShares?: bigint;
  }
): Promise<{ hash: Hash; curveId: bigint; assets: bigint }> {
  if (!walletClient.account) {
    throw new Error('Wallet client must have an account');
  }

  const minimumDeposit = await getMinimumDeposit(publicClient, contractAddress);
  const assets = params.assets < minimumDeposit ? minimumDeposit : params.assets;
  const curveIds =
    params.curveId !== undefined
      ? [params.curveId]
      : [1n, 0n];
  const receiver = params.receiver ?? walletClient.account.address;
  const minShares = params.minShares ?? 0n;

  let lastError: unknown = null;
  for (const curveId of curveIds) {
    try {
      const { request } = await publicClient.simulateContract({
        address: contractAddress,
        abi: multivaultAbi,
        functionName: 'deposit',
        args: [receiver, params.termId, curveId, minShares],
        value: assets,
        account: walletClient.account.address,
        chain: walletClient.chain,
      });
      const hash = await walletClient.writeContract(request);

      return { hash, curveId, assets };
    } catch (error) {
      lastError = error;
    }
  }

  // Legacy EthMultiVault fallback: depositAtom(address,uint256) payable.
  try {
    const legacyId = BigInt(params.termId);
    const { request } = await publicClient.simulateContract({
      address: contractAddress,
      abi: legacyDepositAtomAbi,
      functionName: 'depositAtom',
      args: [receiver, legacyId],
      value: assets,
      account: walletClient.account.address,
      chain: walletClient.chain,
    });
    const hash = await walletClient.writeContract(request);
    return { hash, curveId: params.curveId ?? 0n, assets };
  } catch (legacyError) {
    throw legacyError ?? lastError;
  }
}
