import { describe, expect, it } from 'vitest';
import {
  calculateEntryFee,
  calculateExitFee,
  calculateAtomCost,
  calculateTripleCost,
  DEFAULT_FEE_DENOMINATOR,
} from './fees';

describe('calculateEntryFee', () => {
  it('should calculate entry fee with base and atom fees', () => {
    // 1 ETH deposit with 0.5% base fee (50) and 1.25% atom fee (125) = 1.75% total
    const depositAmount = 1000000000000000000n; // 1 ETH
    const baseFeeRate = 50n; // 0.5%
    const atomFeeRate = 125n; // 1.25%

    const fee = calculateEntryFee(
      depositAmount,
      baseFeeRate,
      atomFeeRate,
      DEFAULT_FEE_DENOMINATOR
    );

    expect(fee).toBe(17500000000000000n); // 0.0175 ETH
  });

  it('should handle zero fees', () => {
    const depositAmount = 1000000000000000000n;
    const fee = calculateEntryFee(depositAmount, 0n, 0n, DEFAULT_FEE_DENOMINATOR);
    expect(fee).toBe(0n);
  });

  it('should handle zero deposit', () => {
    const fee = calculateEntryFee(0n, 50n, 125n, DEFAULT_FEE_DENOMINATOR);
    expect(fee).toBe(0n);
  });

  it('should use custom fee denominator', () => {
    const depositAmount = 1000000000000000000n;
    const baseFeeRate = 1n;
    const atomFeeRate = 2n;
    const feeDenominator = 100n; // 1% per unit

    const fee = calculateEntryFee(
      depositAmount,
      baseFeeRate,
      atomFeeRate,
      feeDenominator
    );

    expect(fee).toBe(30000000000000000n); // 3% of 1 ETH
  });

  it('should handle large amounts without overflow', () => {
    const depositAmount = 1000000000000000000000000n; // 1M ETH
    const fee = calculateEntryFee(depositAmount, 50n, 125n, DEFAULT_FEE_DENOMINATOR);
    expect(fee).toBe(17500000000000000000000n); // 17,500 ETH
  });
});

describe('calculateExitFee', () => {
  it('should calculate exit fee with only base fee', () => {
    // 1 ETH withdrawal with 0.5% base fee (50)
    const withdrawAmount = 1000000000000000000n; // 1 ETH
    const baseFeeRate = 50n; // 0.5%

    const fee = calculateExitFee(withdrawAmount, baseFeeRate, DEFAULT_FEE_DENOMINATOR);

    expect(fee).toBe(5000000000000000n); // 0.005 ETH
  });

  it('should handle zero fee', () => {
    const withdrawAmount = 1000000000000000000n;
    const fee = calculateExitFee(withdrawAmount, 0n, DEFAULT_FEE_DENOMINATOR);
    expect(fee).toBe(0n);
  });

  it('should handle zero withdrawal', () => {
    const fee = calculateExitFee(0n, 50n, DEFAULT_FEE_DENOMINATOR);
    expect(fee).toBe(0n);
  });

  it('should use custom fee denominator', () => {
    const withdrawAmount = 1000000000000000000n;
    const baseFeeRate = 5n;
    const feeDenominator = 100n; // 1% per unit

    const fee = calculateExitFee(withdrawAmount, baseFeeRate, feeDenominator);

    expect(fee).toBe(50000000000000000n); // 5% of 1 ETH
  });
});

describe('calculateAtomCost', () => {
  it('should calculate total cost for atom creation', () => {
    const atomCost = 10000000000000000n; // 0.01 ETH
    const initialDeposit = 100000000000000000n; // 0.1 ETH

    const totalCost = calculateAtomCost(atomCost, initialDeposit);

    expect(totalCost).toBe(110000000000000000n); // 0.11 ETH
  });

  it('should handle zero atom cost', () => {
    const initialDeposit = 100000000000000000n;
    const totalCost = calculateAtomCost(0n, initialDeposit);
    expect(totalCost).toBe(initialDeposit);
  });

  it('should handle zero initial deposit', () => {
    const atomCost = 10000000000000000n;
    const totalCost = calculateAtomCost(atomCost, 0n);
    expect(totalCost).toBe(atomCost);
  });

  it('should handle both zero', () => {
    const totalCost = calculateAtomCost(0n, 0n);
    expect(totalCost).toBe(0n);
  });
});

describe('calculateTripleCost', () => {
  it('should calculate total cost for triple creation', () => {
    const tripleCost = 10000000000000000n; // 0.01 ETH
    const depositAmount = 50000000000000000n; // 0.05 ETH

    const totalCost = calculateTripleCost(tripleCost, depositAmount);

    expect(totalCost).toBe(60000000000000000n); // 0.06 ETH
  });

  it('should handle zero triple cost', () => {
    const depositAmount = 50000000000000000n;
    const totalCost = calculateTripleCost(0n, depositAmount);
    expect(totalCost).toBe(depositAmount);
  });

  it('should handle zero deposit', () => {
    const tripleCost = 10000000000000000n;
    const totalCost = calculateTripleCost(tripleCost, 0n);
    expect(totalCost).toBe(tripleCost);
  });

  it('should handle both zero', () => {
    const totalCost = calculateTripleCost(0n, 0n);
    expect(totalCost).toBe(0n);
  });
});
