import { z } from 'zod';

/**
 * Supported protocols for agent reachability.
 * v3: Graph handles capabilities/skills, metadata is reachability only.
 */
export const AgentProtocol = z.enum(['a2a', 'mcp', 'http', 'websocket']);

/**
 * Authentication types for agent access.
 */
export const AuthType = z.enum(['none', 'apiKey', 'oauth2', 'jwt']);

/**
 * Zod schema for Agent IPFS metadata (v3).
 *
 * v3 Model: Metadata is purely "how to reach and use me."
 * The graph handles: capabilities (has-capability), tools (uses), trust (vault staking),
 * version history (has-metadata chain), relationships (is claims).
 *
 * @example
 * ```typescript
 * const metadata = {
 *   "@type": "Agent",
 *   name: "research-assistant",
 *   description: "Analyzes research papers and synthesizes findings",
 *   version: "2.1.0",
 *   // Reachability
 *   endpoint: "https://api.example.com/agent",
 *   protocol: "a2a",
 *   auth: { type: "apiKey", description: "X-API-Key header" },
 *   // I/O contract
 *   inputModes: ["text/plain", "application/json"],
 *   outputModes: ["text/plain", "text/markdown"],
 *   // Context
 *   model: "claude-opus-4-6",
 *   provider: { name: "Anthropic" }
 * };
 *
 * AgentMetadataSchema.parse(metadata);
 * ```
 */
export const AgentMetadataSchema = z.object({
  /**
   * Type discriminator for agent metadata.
   * Must be the literal string "Agent".
   */
  '@type': z.literal('Agent'),

  /**
   * Machine identifier for the agent (kebab-case recommended).
   * Used as the stable identity anchor.
   */
  name: z.string().trim().min(1, 'name is required').max(100, 'name must be <= 100 chars'),

  /**
   * Natural language description (agents are LLMs, they read this).
   */
  description: z
    .string()
    .trim()
    .min(1, 'description is required')
    .max(500, 'description must be <= 500 chars'),

  /**
   * Semantic version of this metadata version.
   * Must follow semver format (e.g., "1.0.0", "2.1.3-beta").
   */
  version: z.string().regex(
    /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$/,
    'Must be valid semver format'
  ),

  // ========== REACHABILITY ==========
  /**
   * How to connect to this agent.
   */
  endpoint: z.string().url().optional(),

  /**
   * What protocol the agent speaks.
   */
  protocol: AgentProtocol.optional(),

  /**
   * Authentication requirements for access.
   */
  auth: z.object({
    type: AuthType,
    description: z.string().trim().max(200).optional(),
    // For apiKey: where to put the key (header, query param, etc.)
    // For oauth2: authorization URL
    // For jwt: expected claims
  }).optional(),

  // ========== I/O CONTRACT ==========
  /**
   * Supported input MIME types or mode identifiers.
   */
  inputModes: z.array(z.string().trim().min(1)).max(10).optional(),

  /**
   * Supported output MIME types or mode identifiers.
   */
  outputModes: z.array(z.string().trim().min(1)).max(10).optional(),

  // ========== CONTEXT (non-graph, informational) ==========
  /**
   * Model identifier (e.g., "claude-opus-4-6", "gpt-4").
   */
  model: z.string().trim().min(1).max(120).optional(),

  /**
   * Provider information.
   */
  provider: z.object({
    name: z.string().trim().min(1).max(120),
    url: z.string().url().optional(),
  }).optional(),

  /**
   * Optional URL to an image representing the agent.
   */
  image: z.string().url().optional(),

  /**
   * Capabilities this agent provides (bootstrap set).
   * Stored in metadata for convenience; graph relationships handle capability claims.
   */
  capabilities: z.array(z.string().trim().min(1)).max(10).optional(),
});

/**
 * TypeScript type inferred from the Agent metadata schema.
 */
export type AgentMetadata = z.infer<typeof AgentMetadataSchema>;

/**
 * TypeScript type for agent protocols.
 */
export type AgentProtocolType = z.infer<typeof AgentProtocol>;

/**
 * TypeScript type for auth types.
 */
export type AuthTypeValue = z.infer<typeof AuthType>;
