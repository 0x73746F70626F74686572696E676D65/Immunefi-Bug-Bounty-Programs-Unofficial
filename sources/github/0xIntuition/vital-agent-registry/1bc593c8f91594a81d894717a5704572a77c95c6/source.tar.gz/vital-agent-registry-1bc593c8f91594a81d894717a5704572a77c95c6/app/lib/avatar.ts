/**
 * Deterministic SVG avatar generator for the agent registry.
 *
 * Generates a unique geometric identicon from any string seed with a
 * neon console / cyberpunk aesthetic: dark background, glowing accent cell,
 * symmetric 5×5 grid pattern.
 */

/** Eight curated neon hues that read clearly on dark backgrounds. */
const PALETTE = [
  'hsl(282, 70%, 56%)', // brand purple
  'hsl(190, 85%, 55%)', // cyan
  'hsl(325, 80%, 60%)', // magenta
  'hsl(142, 71%, 45%)', // green  (matches app gain color)
  'hsl(45,  90%, 55%)', // amber
  'hsl(220, 80%, 60%)', // blue
  'hsl(0,   84%, 60%)', // red
  'hsl(260, 75%, 65%)', // violet
] as const

/**
 * djb2 hash — fast, deterministic, good bit distribution.
 * Returns an unsigned 32-bit integer.
 */
function djb2(input: string): number {
  let hash = 5381
  for (let i = 0; i < input.length; i++) {
    // Equivalent to: hash * 33 ^ char
    hash = (Math.imul(hash, 33) ^ input.charCodeAt(i)) >>> 0
  }
  return hash
}

/**
 * Build a seeded pseudo-random number generator from the hash so we can
 * draw multiple independent values from a single seed without bit exhaustion.
 *
 * Uses a simple 32-bit xorshift.
 */
function makeRng(seed: number) {
  let state = seed === 0 ? 1 : seed
  return function next(): number {
    state ^= state << 13
    state ^= state >> 17
    state ^= state << 5
    state = state >>> 0 // keep unsigned
    return state / 0x100000000 // normalise to [0, 1)
  }
}

/**
 * Generate a deterministic SVG avatar for an entity.
 *
 * @param seed - Unique identifier (agent ID, skill ID, wallet address, …)
 * @param size - SVG viewBox dimension in px (default 64)
 * @returns `data:image/svg+xml;base64,…` URI suitable for `<img src>`
 */
export function generateAvatar(seed: string, size = 64): string {
  const hash = djb2(seed)
  const rng = makeRng(hash)

  // Pick accent color from palette
  const colorIndex = Math.floor(rng() * PALETTE.length)
  const accent = PALETTE[colorIndex]

  // --- Build 5×5 grid, mirrored horizontally for symmetry ---
  // We only need to decide columns 0-2; columns 3 and 4 mirror 1 and 0.
  const COLS = 5
  const ROWS = 5
  const filled: boolean[][] = Array.from({ length: ROWS }, () => Array(COLS).fill(false))

  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col <= 2; col++) {
      const on = rng() > 0.45 // ~55% fill probability
      filled[row][col] = on
      filled[row][COLS - 1 - col] = on // mirror
    }
  }

  // --- Layout constants ---
  const padding = size * 0.12 // 12% inset from circle edge
  const gridSize = size - padding * 2
  const cellSize = gridSize / COLS
  const cellPad = cellSize * 0.1 // inner padding per cell

  // Build SVG rectangles for filled cells
  const cells: string[] = []
  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      if (!filled[row][col]) continue
      const x = padding + col * cellSize + cellPad
      const y = padding + row * cellSize + cellPad
      const w = cellSize - cellPad * 2
      const h = cellSize - cellPad * 2
      const rx = w * 0.18 // slight corner rounding
      cells.push(
        `<rect x="${x.toFixed(2)}" y="${y.toFixed(2)}" width="${w.toFixed(2)}" height="${h.toFixed(2)}" rx="${rx.toFixed(2)}" fill="${accent}" opacity="0.92"/>`,
      )
    }
  }

  // Glow filter — one subtle drop shadow in the accent hue
  const filterId = 'g'
  const glowSvg = `<filter id="${filterId}" x="-50%" y="-50%" width="200%" height="200%"><feDropShadow dx="0" dy="0" stdDeviation="1.5" flood-color="${accent}" flood-opacity="0.7"/></filter>`

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" width="${size}" height="${size}"><defs>${glowSvg}</defs><circle cx="${size / 2}" cy="${size / 2}" r="${size / 2}" fill="hsl(240,14%,10%)"/><g filter="url(#${filterId})">${cells.join('')}</g></svg>`

  // Encode as base64 data URI
  const b64 = btoa(unescape(encodeURIComponent(svg)))
  return `data:image/svg+xml;base64,${b64}`
}
