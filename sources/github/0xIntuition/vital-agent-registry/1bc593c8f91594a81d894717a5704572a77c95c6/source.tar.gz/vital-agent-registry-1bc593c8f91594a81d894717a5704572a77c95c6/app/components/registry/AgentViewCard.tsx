import { Link } from 'react-router'
import type { Agent, Skill } from '~/types'
import { cn } from '~/lib/utils'


// ============================================================================
// Agent View Cards — Matrix/Terminal Aesthetic
// ============================================================================

interface AgentViewAgentCardProps {
  agent: Agent
  className?: string
}

/**
 * AgentViewAgentCard — Terminal-style agent card with signal bars and ASCII tier badges
 */
export function AgentViewAgentCard({ agent, className }: AgentViewAgentCardProps) {
  const { metadata, trustSignal, capabilities, triples } = agent

  // Tier badge mapping
  const tierBadge: Record<string, string> = {
    platinum: '[PLAT]',
    gold: '[GOLD]',
    silver: '[SILV]',
    bronze: '[BRNZ]',
    unranked: '[----]',
  }

  // Tier color mapping
  const tierColor: Record<string, string> = {
    platinum: 'text-[hsl(200_100%_70%)]', // cyan
    gold: 'text-[hsl(45_100%_60%)]', // gold
    silver: 'text-[hsl(0_0%_70%)]', // silver
    bronze: 'text-[hsl(30_60%_50%)]', // bronze
    unranked: 'text-[hsl(0_0%_40%)]', // dark gray
  }

  // Signal strength bars based on trust percentile
  const percentile = trustSignal.percentile
  const barCount = Math.ceil(percentile / 20) // 0-20%: 1 bar, 20-40%: 2 bars, etc.
  const signalBars = Array.from({ length: 5 }, (_, i) => i < barCount)

  // Top capabilities (max 4)
  const topCapabilities = capabilities.slice(0, 4)
  const remainingCount = capabilities.length - 4

  // Count skills
  const skillCount = triples.filter(t => t.predicate.label === 'uses-skill').length

  // TVL is already formatted in TrustSignal.totalStaked
  const tvlEth = trustSignal.totalStaked

  return (
    <Link
      to={`/agents/${agent.id}`}
      className={cn(
        'block border border-[hsl(142_71%_45%)] bg-[hsl(0_0%_5%)] p-4 font-mono text-sm transition-all',
        'hover:shadow-[0_0_8px_hsl(142_71%_45%/0.4)] focus-visible:shadow-[0_0_8px_hsl(142_71%_45%/0.4)] focus-visible:outline-none',
        className,
      )}
    >
      {/* Top line: name + tier badge */}
      <div className="flex items-center justify-between gap-2 mb-2">
        <span className="text-[hsl(142_71%_60%)] font-bold truncate">{metadata.name}</span>
        <span className={cn('text-xs', tierColor[trustSignal.tier])}>
          {tierBadge[trustSignal.tier]}
        </span>
      </div>

      {/* Signal strength bars */}
      <div className="flex items-center gap-1 mb-3">
        <span className="text-xs text-[hsl(142_71%_45%)] mr-2">TRUST</span>
        {signalBars.map((filled, i) => (
          <div
            key={i}
            className={cn(
              'h-3 w-4 border border-[hsl(142_71%_45%)]',
              filled ? 'bg-[hsl(142_71%_45%)]' : 'bg-transparent'
            )}
          />
        ))}
        <span className="text-xs text-[hsl(142_71%_45%)] ml-2">
          {percentile.toFixed(0)}%
        </span>
      </div>

      {/* Capabilities */}
      {topCapabilities.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-3">
          {topCapabilities.map(cap => (
            <span
              key={cap.id}
              className="text-xs px-1.5 py-0.5 bg-[hsl(142_71%_45%/0.2)] text-[hsl(142_71%_60%)] border border-[hsl(142_71%_45%/0.4)]"
            >
              {cap.name.toLowerCase()}
            </span>
          ))}
          {remainingCount > 0 && (
            <span className="text-xs px-1.5 py-0.5 text-[hsl(142_71%_45%)]">
              +{remainingCount}
            </span>
          )}
        </div>
      )}

      {/* Bottom metrics */}
      <div className="flex items-center gap-3 text-xs text-[hsl(142_71%_45%/0.7)]">
        <span>STAKERS: {trustSignal.stakerCount}</span>
        <span>|</span>
        <span>TVL: {tvlEth}</span>
        <span>|</span>
        <span>SKILLS: {skillCount}</span>
      </div>
    </Link>
  )
}

// ============================================================================

interface AgentViewSkillCardProps {
  skill: Skill
  className?: string
}

/**
 * AgentViewSkillCard — Terminal-style skill card with safety indicators and FOR/AGAINST bars
 */
export function AgentViewSkillCard({ skill, className }: AgentViewSkillCardProps) {
  const { metadata, platform, safetySignal, capabilities } = skill

  // Platform badge mapping
  const platformBadge: Record<string, string> = {
    mcp: '[MCP]',
    'claude-code': '[CLAUDE]',
    'oclaw-platform': '[OCLAW]',
  }

  // Safety status badge and color
  const safetyBadge: Record<string, string> = {
    verified: '[SAFE]',
    unverified: '[UNKN]',
    flagged: '[WARN]',
  }

  const safetyColor: Record<string, string> = {
    verified: 'text-[hsl(142_71%_60%)]',
    unverified: 'text-[hsl(50_100%_50%)]',
    flagged: 'text-[hsl(0_84%_60%)]',
  }

  const isFlagged = safetySignal.status === 'flagged'

  // Safety ratio for visual bar (0-1, where 1 = 100% FOR)
  const safetyRatio = safetySignal.safetyRatio
  const forWidth = safetyRatio * 100
  const againstWidth = (1 - safetyRatio) * 100

  // Format stakes
  const forStakeEth = safetySignal.forStake
  const againstStakeEth = safetySignal.againstStake

  return (
    <Link
      to={`/skills/${skill.id}`}
      className={cn(
        'block border bg-[hsl(0_0%_5%)] p-4 font-mono text-sm transition-all',
        'hover:shadow-[0_0_8px_hsl(142_71%_45%/0.4)] focus-visible:shadow-[0_0_8px_hsl(142_71%_45%/0.4)] focus-visible:outline-none',
        isFlagged
          ? 'border-[hsl(0_84%_60%)] shadow-[0_0_4px_hsl(0_84%_60%/0.3)]'
          : 'border-[hsl(142_71%_45%)]',
        className,
      )}
    >
      {/* Top line: name + platform */}
      <div className="flex items-center justify-between gap-2 mb-2">
        <span className="text-[hsl(142_71%_60%)] font-bold truncate">{metadata.name}</span>
        <span className="text-xs text-[hsl(142_71%_45%)]">
          {platformBadge[platform.id] || `[${platform.id.toUpperCase()}]`}
        </span>
      </div>

      {/* Safety status indicator */}
      <div className="flex items-center gap-2 mb-3">
        <span className="text-xs text-[hsl(142_71%_45%)]">STATUS</span>
        <span className={cn('text-xs font-bold', safetyColor[safetySignal.status])}>
          {safetyBadge[safetySignal.status]}
        </span>
      </div>

      {/* Safety ratio bar (FOR green / AGAINST red) */}
      <div className="mb-3">
        <div className="h-2 flex border border-[hsl(142_71%_45%/0.4)] overflow-hidden">
          <div
            className="bg-[hsl(142_71%_45%)]"
            style={{ width: `${forWidth}%` }}
          />
          <div
            className="bg-[hsl(0_84%_60%)]"
            style={{ width: `${againstWidth}%` }}
          />
        </div>
      </div>

      {/* Capabilities */}
      {capabilities.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-3">
          {capabilities.map(cap => (
            <span
              key={cap.id}
              className="text-xs px-1.5 py-0.5 bg-[hsl(142_71%_45%/0.2)] text-[hsl(142_71%_60%)] border border-[hsl(142_71%_45%/0.4)]"
            >
              {cap.name.toLowerCase()}
            </span>
          ))}
        </div>
      )}

      {/* FOR/AGAINST stakes */}
      <div className="flex items-center gap-2 text-xs">
        <span className="text-[hsl(142_71%_60%)]">
          FOR: {forStakeEth}
        </span>
        <span className="text-[hsl(142_71%_45%/0.7)]">|</span>
        <span className="text-[hsl(0_84%_60%)]">
          AGAINST: {againstStakeEth}
        </span>
      </div>
    </Link>
  )
}
