import { createHash } from 'node:crypto'
import { z } from 'zod'
import { stableStringify } from '~/lib/trust-model/artifact'

export const evidenceVaultSnapshotSchema = z.object({
  termId: z.string().min(1),
  marketCapWei: z.string().regex(/^\d+$/),
  stakerCount: z.number().int().nonnegative(),
  sharePriceWei: z.string().regex(/^\d+$/),
})

export const evidenceBundleSchema = z.object({
  id: z.string().min(1),
  candidateId: z.string().min(1),
  modelId: z.string().min(1),
  modelVersion: z.string().regex(/^\d+\.\d+\.\d+$/),
  claimIds: z.array(z.string()).default([]),
  traversalPath: z.array(z.string()).default([]),
  vaultSnapshots: z.array(evidenceVaultSnapshotSchema).default([]),
  score: z.number(),
  confidence: z.number(),
  queryHash: z.string().regex(/^[a-f0-9]{64}$/),
  snapshotId: z.string().min(1),
  snapshotTimestamp: z.string().datetime(),
  generatedAt: z.string().datetime(),
  ttlSeconds: z.number().int().positive(),
  expiresAt: z.string().datetime(),
})

export type EvidenceBundle = z.infer<typeof evidenceBundleSchema>

export function buildEvidenceId(payload: Omit<EvidenceBundle, 'id'>): string {
  const canonical = stableStringify(payload)
  return createHash('sha256').update(canonical).digest('hex')
}

export function buildQueryHash(input: unknown): string {
  return createHash('sha256').update(stableStringify(input)).digest('hex')
}
