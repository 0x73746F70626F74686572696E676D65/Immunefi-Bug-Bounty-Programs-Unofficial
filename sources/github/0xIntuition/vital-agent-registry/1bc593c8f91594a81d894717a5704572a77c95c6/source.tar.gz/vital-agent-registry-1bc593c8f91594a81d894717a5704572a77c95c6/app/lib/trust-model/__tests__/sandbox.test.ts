import { describe, expect, it } from 'vitest'
import { scoreCandidates } from '../evaluator'
import type { TrustModelArtifact } from '../artifact'

const BASE_MODEL: TrustModelArtifact = {
  modelId: 'com.intuition.trust.test',
  version: '1.0.0',
  author: 'test-suite',
  domain: 'agent-discovery',
  inputs: [
    {
      key: 'market_cap',
      source: 'vault',
      type: 'number',
      required: true,
      description: 'Market cap value',
    },
    {
      key: 'staker_count',
      source: 'vault',
      type: 'number',
      required: true,
      description: 'Number of stakers',
    },
  ],
  formulaSpec: {
    language: 'trust-formula-v1',
    root: {
      op: 'weighted_sum',
      terms: [
        { weight: 0.5, value: { op: 'input', key: 'market_cap' } },
        { weight: 0.5, value: { op: 'input', key: 'staker_count' } },
      ],
    },
  },
  normalization: {
    method: 'none',
  },
  outputSemantics: {
    scoreRange: { min: 0, max: 100 },
    confidenceRange: { min: 0, max: 1 },
    interpretation: 'Higher score indicates stronger trust',
  },
  compatibility: {
    breaking: false,
  },
}

describe('trust model sandbox', () => {
  describe('normal evaluation', () => {
    it('passes through correct results', () => {
      const candidates = [
        { id: 'agent-1', inputs: { market_cap: 1000, staker_count: 50 } },
        { id: 'agent-2', inputs: { market_cap: 2000, staker_count: 100 } },
      ]

      const results = scoreCandidates(BASE_MODEL, candidates)

      expect(results).toHaveLength(2)
      expect(results[0].rawScore).toBe(525)
      expect(results[1].rawScore).toBe(1050)
      expect(results[0].confidence).toBe(1)
      expect(results[1].confidence).toBe(1)
    })

    it('handles all operation types correctly', () => {
      const model: TrustModelArtifact = {
        ...BASE_MODEL,
        inputs: [
          { key: 'a', source: 'vault', type: 'number', required: true, description: 'Input A' },
          { key: 'b', source: 'vault', type: 'number', required: true, description: 'Input B' },
        ],
        formulaSpec: {
          language: 'trust-formula-v1',
          root: {
            op: 'add',
            args: [
              { op: 'mul', args: [{ op: 'input', key: 'a' }, { op: 'const', value: 2 }] },
              {
                op: 'clamp',
                value: { op: 'input', key: 'b' },
                min: 0,
                max: 10,
              },
            ],
          },
        },
      }

      const results = scoreCandidates(model, [{ id: 'test', inputs: { a: 5, b: 15 } }])

      expect(results[0].rawScore).toBe(20)
    })
  })

  describe('recursion depth limit', () => {
    it('throws error when nesting exceeds max depth', () => {
      let deepNode: Record<string, unknown> = { op: 'const', value: 1 }
      for (let i = 0; i < 25; i++) {
        deepNode = { op: 'add', args: [deepNode, { op: 'const', value: 1 }] }
      }

      const model: TrustModelArtifact = {
        ...BASE_MODEL,
        inputs: [],
        formulaSpec: {
          language: 'trust-formula-v1',
          root: deepNode,
        },
      }

      expect(() => scoreCandidates(model, [{ id: 'test', inputs: {} }])).toThrow(
        /Recursion depth limit exceeded/,
      )
    })

    it('allows evaluation within depth limit', () => {
      let deepNode: Record<string, unknown> = { op: 'const', value: 1 }
      for (let i = 0; i < 15; i++) {
        deepNode = { op: 'add', args: [deepNode, { op: 'const', value: 1 }] }
      }

      const model: TrustModelArtifact = {
        ...BASE_MODEL,
        inputs: [],
        formulaSpec: {
          language: 'trust-formula-v1',
          root: deepNode,
        },
      }

      const results = scoreCandidates(model, [{ id: 'test', inputs: {} }])
      expect(results[0].rawScore).toBe(16)
    })
  })

  describe('operation budget limit', () => {
    it('throws error when operations exceed budget', () => {
      const manyOps = { op: 'const', value: 1 }
      const terms = []
      for (let i = 0; i < 1100; i++) {
        terms.push({ weight: 1, value: manyOps })
      }

      const model: TrustModelArtifact = {
        ...BASE_MODEL,
        inputs: [],
        formulaSpec: {
          language: 'trust-formula-v1',
          root: {
            op: 'weighted_sum',
            terms,
          },
        },
      }

      expect(() => scoreCandidates(model, [{ id: 'test', inputs: {} }])).toThrow(
        /Operation budget exceeded/,
      )
    })

    it('allows evaluation within operation budget', () => {
      const manyOps = { op: 'const', value: 1 }
      const terms = []
      for (let i = 0; i < 500; i++) {
        terms.push({ weight: 1, value: manyOps })
      }

      const model: TrustModelArtifact = {
        ...BASE_MODEL,
        inputs: [],
        formulaSpec: {
          language: 'trust-formula-v1',
          root: {
            op: 'weighted_sum',
            terms,
          },
        },
      }

      const results = scoreCandidates(model, [{ id: 'test', inputs: {} }])
      expect(results[0].rawScore).toBe(500)
    })
  })

  describe('division by zero protection', () => {
    it('returns 0 when dividing by zero', () => {
      const model: TrustModelArtifact = {
        ...BASE_MODEL,
        inputs: [
          { key: 'a', source: 'vault', type: 'number', required: true, description: 'Numerator' },
        ],
        formulaSpec: {
          language: 'trust-formula-v1',
          root: {
            op: 'div',
            args: [{ op: 'input', key: 'a' }, { op: 'const', value: 0 }],
          },
        },
      }

      const results = scoreCandidates(model, [{ id: 'test', inputs: { a: 100 } }])
      expect(results[0].rawScore).toBe(0)
    })

    it('handles multiple divisions with zero', () => {
      const model: TrustModelArtifact = {
        ...BASE_MODEL,
        inputs: [
          { key: 'a', source: 'vault', type: 'number', required: true, description: 'Value' },
        ],
        formulaSpec: {
          language: 'trust-formula-v1',
          root: {
            op: 'div',
            args: [
              { op: 'input', key: 'a' },
              { op: 'const', value: 2 },
              { op: 'const', value: 0 },
            ],
          },
        },
      }

      const results = scoreCandidates(model, [{ id: 'test', inputs: { a: 100 } }])
      expect(results[0].rawScore).toBe(0)
    })
  })

  describe('NaN and Infinity clamping', () => {
    it('clamps NaN to 0', () => {
      const model: TrustModelArtifact = {
        ...BASE_MODEL,
        inputs: [],
        formulaSpec: {
          language: 'trust-formula-v1',
          root: {
            op: 'div',
            args: [{ op: 'const', value: 0 }, { op: 'const', value: 0 }],
          },
        },
      }

      const results = scoreCandidates(model, [{ id: 'test', inputs: {} }])
      expect(results[0].rawScore).toBe(0)
    })

    it('clamps Infinity to 0', () => {
      const model: TrustModelArtifact = {
        ...BASE_MODEL,
        inputs: [],
        formulaSpec: {
          language: 'trust-formula-v1',
          root: {
            op: 'mul',
            args: [{ op: 'const', value: Number.MAX_VALUE }, { op: 'const', value: 2 }],
          },
        },
      }

      const results = scoreCandidates(model, [{ id: 'test', inputs: {} }])
      expect(results[0].rawScore).toBe(0)
    })

    it('clamps -Infinity to 0', () => {
      const model: TrustModelArtifact = {
        ...BASE_MODEL,
        inputs: [],
        formulaSpec: {
          language: 'trust-formula-v1',
          root: {
            op: 'mul',
            args: [{ op: 'const', value: -Number.MAX_VALUE }, { op: 'const', value: 2 }],
          },
        },
      }

      const results = scoreCandidates(model, [{ id: 'test', inputs: {} }])
      expect(results[0].rawScore).toBe(0)
    })
  })

  describe('input validation', () => {
    it('rejects unknown input keys', () => {
      const candidates = [
        {
          id: 'agent-1',
          inputs: {
            market_cap: 1000,
            staker_count: 50,
            unknown_field: 999,
          },
        },
      ]

      expect(() => scoreCandidates(BASE_MODEL, candidates)).toThrow(
        /Unknown input key: unknown_field/,
      )
    })

    it('allows only declared inputs', () => {
      const candidates = [
        {
          id: 'agent-1',
          inputs: {
            market_cap: 1000,
            staker_count: 50,
          },
        },
      ]

      const results = scoreCandidates(BASE_MODEL, candidates)
      expect(results[0].rawScore).toBe(525)
    })

    it('rejects multiple unknown keys', () => {
      const candidates = [
        {
          id: 'agent-1',
          inputs: {
            market_cap: 1000,
            staker_count: 50,
            bad_key_1: 1,
            bad_key_2: 2,
          },
        },
      ]

      expect(() => scoreCandidates(BASE_MODEL, candidates)).toThrow(/Unknown input key/)
    })
  })

  describe('fuzzed payload with script injection', () => {
    it('rejects script in string input keys', () => {
      const candidates = [
        {
          id: 'agent-1',
          inputs: {
            market_cap: 1000,
            staker_count: 50,
            '<script>alert("xss")</script>': 'malicious',
          },
        },
      ]

      expect(() => scoreCandidates(BASE_MODEL, candidates)).toThrow(/Unknown input key/)
    })

    it('safely handles script in input values', () => {
      const model: TrustModelArtifact = {
        ...BASE_MODEL,
        inputs: [
          {
            key: 'name',
            source: 'candidate',
            type: 'string',
            required: false,
            description: 'Agent name',
          },
          {
            key: 'score',
            source: 'vault',
            type: 'number',
            required: true,
            description: 'Score',
          },
        ],
        formulaSpec: {
          language: 'trust-formula-v1',
          root: { op: 'input', key: 'score' },
        },
      }

      const candidates = [
        {
          id: 'agent-1',
          inputs: {
            name: '<script>alert("xss")</script>',
            score: 100,
          },
        },
      ]

      const results = scoreCandidates(model, candidates)
      expect(results[0].rawScore).toBe(100)
      expect(results[0].resolvedInputs.name).toBe('<script>alert("xss")</script>')
    })

    it('handles malformed nested objects in inputs', () => {
      const candidates = [
        {
          id: 'agent-1',
          inputs: {
            market_cap: { toString: () => '1000' },
            staker_count: 50,
          },
        },
      ]

      const results = scoreCandidates(BASE_MODEL, candidates)
      expect(results[0].rawScore).toBe(25)
    })

    it('safely converts arrays to numbers', () => {
      const model: TrustModelArtifact = {
        ...BASE_MODEL,
        inputs: [
          {
            key: 'values',
            source: 'vault',
            type: 'array:number',
            required: true,
            description: 'Array of values',
          },
        ],
        formulaSpec: {
          language: 'trust-formula-v1',
          root: { op: 'input', key: 'values' },
        },
      }

      const candidates = [
        {
          id: 'agent-1',
          inputs: {
            values: [10, 20, 30],
          },
        },
      ]

      const results = scoreCandidates(model, candidates)
      expect(results[0].rawScore).toBe(20)
    })
  })

  describe('custom sandbox limits', () => {
    it('respects custom depth limit', () => {
      let deepNode: Record<string, unknown> = { op: 'const', value: 1 }
      for (let i = 0; i < 6; i++) {
        deepNode = { op: 'add', args: [deepNode, { op: 'const', value: 1 }] }
      }

      const model: TrustModelArtifact = {
        ...BASE_MODEL,
        inputs: [],
        formulaSpec: {
          language: 'trust-formula-v1',
          root: deepNode,
        },
      }

      expect(() =>
        scoreCandidates(model, [{ id: 'test', inputs: {} }], { maxDepth: 5, maxOperations: 1000 }),
      ).toThrow(/Recursion depth limit exceeded/)
    })

    it('respects custom operation limit', () => {
      const terms = []
      for (let i = 0; i < 150; i++) {
        terms.push({ weight: 1, value: { op: 'const', value: 1 } })
      }

      const model: TrustModelArtifact = {
        ...BASE_MODEL,
        inputs: [],
        formulaSpec: {
          language: 'trust-formula-v1',
          root: {
            op: 'weighted_sum',
            terms,
          },
        },
      }

      expect(() =>
        scoreCandidates(model, [{ id: 'test', inputs: {} }], { maxDepth: 20, maxOperations: 100 }),
      ).toThrow(/Operation budget exceeded/)
    })
  })
})
