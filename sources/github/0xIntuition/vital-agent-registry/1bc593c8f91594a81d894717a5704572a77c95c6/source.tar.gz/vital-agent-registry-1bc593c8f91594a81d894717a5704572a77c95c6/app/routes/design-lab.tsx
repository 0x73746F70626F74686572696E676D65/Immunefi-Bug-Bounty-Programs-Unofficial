/**
 * Design Lab — Side Panel UX Sub-Variations (E1–E5)
 *
 * Temporary route for visual review of 5 sub-variations of the Side Panel layout.
 * All 5 share: identity header with PERMANENT entity trust widget, split capability
 * list (left) + staking detail panel (right).
 *
 * Remove this file before production.
 */

import { useState } from 'react'

// ── Design tokens ─────────────────────────────────────────────────

const GREEN = '#22c55e'
const RED = '#ef4444'
const YELLOW = '#eab308'
const PURPLE = '#a78bfa'

const BG = '#0a0a0f'
const CARD_BG = '#12121a'
const BORDER = '#1e1e2e'
const TEXT = '#e0e0e8'
const TEXT_MUTED = '#8b8ba0'
const TEXT_FAINT = '#4a4a60'

// ── Conviction tiers ──────────────────────────────────────────────

const TIERS = [
  { amount: '0.01', label: 'NUDGE' },
  { amount: '0.05', label: 'SIGNAL' },
  { amount: '0.25', label: 'STRONG' },
  { amount: '1.00', label: 'CONVICTION' },
] as const

// ── Variant switcher ──────────────────────────────────────────────

const VARIANTS = [
  { id: 'terminal', label: 'E1: Terminal Command' },
  { id: 'neon-dashboard', label: 'E2: Neon Dashboard' },
  { id: 'question-forward', label: 'E3: Question Forward' },
  { id: 'status-board', label: 'E4: Status Board' },
  { id: 'prediction-market', label: 'E5: Prediction Market' },
] as const

type VariantId = (typeof VARIANTS)[number]['id']

// ── Mock data ─────────────────────────────────────────────────────

interface MockCapability {
  id: string
  name: string
  description: string
  trustPct: number
  forVault: { total_assets: number; position_count: number; current_share_price: number }
  againstVault: { total_assets: number; position_count: number; current_share_price: number }
}

const MOCK_CAPABILITIES: MockCapability[] = [
  {
    id: 'code-generation',
    name: 'code-generation',
    description: 'Generate production-ready code across multiple languages',
    trustPct: 92,
    forVault: { total_assets: 1.85, position_count: 21, current_share_price: 1.042 },
    againstVault: { total_assets: 0.16, position_count: 3, current_share_price: 0.98 },
  },
  {
    id: 'data-analysis',
    name: 'data-analysis',
    description: 'Query and transform datasets with statistical precision',
    trustPct: 41,
    forVault: { total_assets: 0.34, position_count: 6, current_share_price: 0.97 },
    againstVault: { total_assets: 0.48, position_count: 9, current_share_price: 1.012 },
  },
  {
    id: 'visualization',
    name: 'visualization',
    description: 'Create interactive charts, graphs, and dashboards',
    trustPct: 78,
    forVault: { total_assets: 1.10, position_count: 15, current_share_price: 1.028 },
    againstVault: { total_assets: 0.31, position_count: 5, current_share_price: 0.99 },
  },
  {
    id: 'collaborative-coding',
    name: 'collaborative-coding',
    description: 'Multi-agent pair programming and code review',
    trustPct: 64,
    forVault: { total_assets: 0.72, position_count: 10, current_share_price: 1.015 },
    againstVault: { total_assets: 0.41, position_count: 7, current_share_price: 1.002 },
  },
  {
    id: 'natural-language',
    name: 'natural-language',
    description: 'Process, understand, and generate natural language',
    trustPct: 87,
    forVault: { total_assets: 1.42, position_count: 18, current_share_price: 1.038 },
    againstVault: { total_assets: 0.21, position_count: 4, current_share_price: 0.985 },
  },
]

const MOCK_AGENT = {
  id: '0xmock',
  name: 'data-pilot',
  version: 'v1.0.0',
  description: 'Data analysis and pipeline agent. Specializes in querying, transforming, and visualizing large datasets.',
  trustPct: 76,
  forVault: { total_assets: 5.81, position_count: 76, current_share_price: 1.034 },
  againstVault: { total_assets: 1.67, position_count: 22, current_share_price: 1.008 },
}

// ── Helpers ───────────────────────────────────────────────────────

function trustColor(pct: number): string {
  if (pct >= 70) return GREEN
  if (pct >= 40) return YELLOW
  return RED
}

function trustLabel(pct: number): 'VERIFIED' | 'UNVERIFIED' | 'FLAGGED' {
  if (pct >= 80) return 'VERIFIED'
  if (pct >= 50) return 'UNVERIFIED'
  return 'FLAGGED'
}

// ── Staking state ─────────────────────────────────────────────────

type StakeStep = 'idle' | 'tiers' | 'confirmed'
type Direction = 'vouch' | 'deny'

interface StakingState {
  step: StakeStep
  direction: Direction | null
  tier: string | null
}

function useStaking(id: string) {
  const [state, setState] = useState<StakingState>({ step: 'idle', direction: null, tier: null })

  const start = (dir: Direction) => setState({ step: 'tiers', direction: dir, tier: null })

  const selectTier = (tier: string) => {
    setState((s) => ({ ...s, tier, step: 'confirmed' }))
    setTimeout(() => setState({ step: 'idle', direction: null, tier: null }), 1500)
  }

  const reset = () => setState({ step: 'idle', direction: null, tier: null })

  return { id, state, start, selectTier, reset }
}

// ── Shared sub-components ─────────────────────────────────────────

function TrustRing({ percent, size }: { percent: number; size: number }) {
  const r = (size - 5) / 2
  const circ = 2 * Math.PI * r
  const offset = circ - (percent / 100) * circ
  const color = trustColor(percent)
  const cx = size / 2
  const cy = size / 2
  return (
    <svg width={size} height={size} style={{ flexShrink: 0 }}>
      <circle cx={cx} cy={cy} r={r} fill="none" stroke={BORDER} strokeWidth={3.5} />
      <circle
        cx={cx} cy={cy} r={r} fill="none"
        stroke={color} strokeWidth={3.5}
        strokeDasharray={circ} strokeDashoffset={offset}
        strokeLinecap="round"
        transform={`rotate(-90 ${cx} ${cy})`}
        style={{ transition: 'stroke-dashoffset 0.5s ease', filter: `drop-shadow(0 0 4px ${color}80)` }}
      />
    </svg>
  )
}

function TrustBar({ percent }: { percent: number }) {
  const color = trustColor(percent)
  return (
    <div style={{ width: '100%', height: 4, borderRadius: 2, background: BORDER, overflow: 'hidden', position: 'relative' }}>
      <div style={{ position: 'absolute', left: 0, top: 0, height: '100%', width: `${percent}%`, background: color, transition: 'width 0.4s ease', boxShadow: `0 0 6px ${color}60` }} />
      <div style={{ position: 'absolute', right: 0, top: 0, height: '100%', width: `${100 - percent}%`, background: `${RED}30` }} />
    </div>
  )
}

function StatusDot({ percent }: { percent: number }) {
  const color = trustColor(percent)
  return (
    <div style={{
      width: 9, height: 9, borderRadius: '50%', background: color, flexShrink: 0,
      boxShadow: `0 0 8px ${color}60`,
    }} />
  )
}

function ConvictionTiers({ direction, onSelect }: { direction: Direction; onSelect: (tier: string) => void }) {
  const color = direction === 'vouch' ? GREEN : RED
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5 }}>
      {TIERS.map((t) => (
        <button
          key={t.amount}
          type="button"
          onClick={() => onSelect(t.amount)}
          style={{
            padding: '7px 4px', borderRadius: 6,
            border: `1px solid ${color}45`, background: `${color}12`,
            color, fontFamily: 'monospace', fontSize: 10, fontWeight: 700,
            cursor: 'pointer', display: 'flex', flexDirection: 'column',
            alignItems: 'center', gap: 2, transition: 'background 0.12s',
          }}
          onMouseEnter={(e) => { e.currentTarget.style.background = `${color}25` }}
          onMouseLeave={(e) => { e.currentTarget.style.background = `${color}12` }}
        >
          <span style={{ fontSize: 11, fontWeight: 900 }}>{t.amount}</span>
          <span style={{ fontSize: 8, opacity: 0.65, letterSpacing: '0.04em' }}>{t.label}</span>
        </button>
      ))}
    </div>
  )
}

// ── Confirmed flash ───────────────────────────────────────────────

function ConfirmedFlash({ direction, tier }: { direction: Direction; tier: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: GREEN, fontFamily: 'monospace', fontSize: 11, fontWeight: 700, letterSpacing: '0.05em' }}>
      <span style={{ fontSize: 14 }}>✓</span>
      <span>CONFIRMED — {direction.toUpperCase()} {tier} TRUST</span>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════
// E1: TERMINAL COMMAND
// ══════════════════════════════════════════════════════════════════

function E1EntityTrust() {
  const { state, start, selectTier, reset } = useStaking('entity')
  const [tierOpen, setTierOpen] = useState(false)

  const handleStart = (dir: Direction) => {
    start(dir)
    setTierOpen(true)
  }

  const handleSelect = (tier: string) => {
    selectTier(tier)
    setTimeout(() => setTierOpen(false), 1600)
  }

  const handleReset = () => {
    reset()
    setTierOpen(false)
  }

  return (
    <div style={{
      background: '#0d0d14',
      border: `1px solid ${BORDER}`,
      borderRadius: 8,
      padding: '10px 14px',
      fontFamily: 'monospace',
    }}>
      {state.step === 'confirmed' ? (
        <ConfirmedFlash direction={state.direction!} tier={state.tier!} />
      ) : (
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ color: GREEN, fontSize: 13, fontWeight: 700 }}>$</span>
          <span style={{ color: TEXT, fontSize: 12, fontWeight: 700, letterSpacing: '0.04em' }}>
            DO YOU TRUST <span style={{ color: PURPLE }}>{MOCK_AGENT.name.toUpperCase()}</span>?
          </span>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
            <button
              type="button"
              onClick={() => handleStart('vouch')}
              style={{
                padding: '4px 12px', borderRadius: 5,
                border: `1px solid ${GREEN}50`, background: `${GREEN}14`,
                color: GREEN, fontFamily: 'monospace', fontSize: 10, fontWeight: 700,
                cursor: 'pointer', letterSpacing: '0.06em',
                display: 'flex', alignItems: 'center', gap: 4,
              }}
            >
              <span style={{ fontSize: 11 }}>▲</span> VOUCH
            </button>
            <button
              type="button"
              onClick={() => handleStart('deny')}
              style={{
                padding: '4px 12px', borderRadius: 5,
                border: `1px solid ${RED}50`, background: `${RED}14`,
                color: RED, fontFamily: 'monospace', fontSize: 10, fontWeight: 700,
                cursor: 'pointer', letterSpacing: '0.06em',
                display: 'flex', alignItems: 'center', gap: 4,
              }}
            >
              <span style={{ fontSize: 11 }}>▼</span> DENY
            </button>
          </div>
        </div>
      )}
      {tierOpen && state.step === 'tiers' && (
        <div style={{ marginTop: 10, paddingTop: 10, borderTop: `1px solid ${BORDER}` }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
            <span style={{ color: state.direction === 'vouch' ? GREEN : RED, fontFamily: 'monospace', fontSize: 10, fontWeight: 700, letterSpacing: '0.06em' }}>
              CONVICTION TIER:
            </span>
            <button type="button" onClick={handleReset} style={{ marginLeft: 'auto', background: 'none', border: 'none', color: TEXT_MUTED, cursor: 'pointer', fontSize: 12 }}>✕</button>
          </div>
          <ConvictionTiers direction={state.direction!} onSelect={handleSelect} />
        </div>
      )}
    </div>
  )
}

function E1CapRow({ cap, isSelected, onSelect }: { cap: MockCapability; isSelected: boolean; onSelect: () => void }) {
  const color = trustColor(cap.trustPct)
  const dotChar = cap.trustPct >= 70 ? '●' : cap.trustPct >= 40 ? '◐' : '○'
  const totalStakers = cap.forVault.position_count + cap.againstVault.position_count
  const barFilled = Math.round(cap.trustPct / 10)
  const barStr = '█'.repeat(barFilled) + '░'.repeat(10 - barFilled)

  return (
    <button
      type="button"
      onClick={onSelect}
      style={{
        display: 'flex', alignItems: 'center', gap: 10,
        width: '100%', padding: '9px 14px',
        background: isSelected ? `${color}0e` : 'transparent',
        border: 'none',
        borderLeft: `2px solid ${isSelected ? color : 'transparent'}`,
        borderBottom: `1px solid ${BORDER}`,
        cursor: 'pointer', textAlign: 'left',
        transition: 'background 0.1s',
        fontFamily: 'monospace',
      }}
      onMouseEnter={(e) => { if (!isSelected) e.currentTarget.style.background = '#ffffff05' }}
      onMouseLeave={(e) => { if (!isSelected) e.currentTarget.style.background = 'transparent' }}
    >
      <span style={{ fontSize: 12, color, flexShrink: 0, lineHeight: 1 }}>{dotChar}</span>
      <span style={{ flex: 1, fontSize: 11, fontWeight: 700, color: isSelected ? color : TEXT, letterSpacing: '0.04em', textTransform: 'uppercase' }}>
        {cap.name}
      </span>
      <span style={{ fontSize: 11, fontWeight: 800, color, minWidth: 34, textAlign: 'right' }}>
        {cap.trustPct}%
      </span>
      <span style={{ fontSize: 10, color: TEXT_FAINT, letterSpacing: '0.02em', minWidth: 80, textAlign: 'right' }}>
        {barStr}
      </span>
      <span style={{ fontSize: 9, color: TEXT_MUTED, minWidth: 60, textAlign: 'right' }}>
        {totalStakers} stakers
      </span>
    </button>
  )
}

function E1Panel({ cap }: { cap: MockCapability }) {
  const { state, start, selectTier, reset } = useStaking(`panel-${cap.id}`)
  const color = trustColor(cap.trustPct)
  const totalAssets = (cap.forVault.total_assets + cap.againstVault.total_assets).toFixed(2)

  return (
    <div key={cap.id} style={{ height: '100%', display: 'flex', flexDirection: 'column', gap: 12, animation: 'slideInRight 0.18s ease' }}>
      <style>{`@keyframes slideInRight { from { opacity:0; transform:translateX(8px) } to { opacity:1; transform:translateX(0) } }`}</style>
      <div>
        <div style={{ fontFamily: 'monospace', fontSize: 9, color: TEXT_FAINT, letterSpacing: '0.1em', marginBottom: 4 }}>CAPABILITY CLAIM</div>
        <div style={{ fontFamily: 'monospace', fontSize: 14, fontWeight: 900, color, letterSpacing: '0.04em', textTransform: 'uppercase' }}>
          HAS {cap.name.toUpperCase()}?
        </div>
        <div style={{ fontFamily: 'monospace', fontSize: 10, color: TEXT_MUTED, marginTop: 4 }}>{cap.description}</div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <TrustRing percent={cap.trustPct} size={52} />
        <div>
          <div style={{ fontFamily: 'monospace', fontSize: 32, fontWeight: 900, color, lineHeight: 1, letterSpacing: '-0.03em' }}>{cap.trustPct}%</div>
          <div style={{ fontFamily: 'monospace', fontSize: 9, color: TEXT_MUTED, letterSpacing: '0.04em', marginTop: 2 }}>{trustLabel(cap.trustPct)}</div>
        </div>
      </div>

      <TrustBar percent={cap.trustPct} />
      <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'monospace', fontSize: 9 }}>
        <span style={{ color: GREEN }}>FOR {cap.forVault.total_assets} TRUST ({cap.forVault.position_count})</span>
        <span style={{ color: RED }}>AGAINST {cap.againstVault.total_assets} TRUST ({cap.againstVault.position_count})</span>
      </div>
      <div style={{ fontFamily: 'monospace', fontSize: 9, color: TEXT_FAINT }}>VOL {totalAssets} TRUST</div>

      <div style={{ borderTop: `1px solid ${BORDER}`, paddingTop: 10 }}>
        {state.step === 'confirmed' ? (
          <ConfirmedFlash direction={state.direction!} tier={state.tier!} />
        ) : state.step === 'tiers' ? (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
              <span style={{ fontFamily: 'monospace', fontSize: 10, color: state.direction === 'vouch' ? GREEN : RED, fontWeight: 700 }}>
                {state.direction?.toUpperCase()} CONVICTION:
              </span>
              <button type="button" onClick={reset} style={{ marginLeft: 'auto', background: 'none', border: 'none', color: TEXT_MUTED, cursor: 'pointer', fontSize: 12 }}>✕</button>
            </div>
            <ConvictionTiers direction={state.direction!} onSelect={selectTier} />
          </div>
        ) : (
          <div style={{ display: 'flex', gap: 8 }}>
            <button type="button" onClick={() => start('vouch')} style={{ flex: 1, padding: '7px', borderRadius: 6, border: `1px solid ${GREEN}45`, background: `${GREEN}10`, color: GREEN, fontFamily: 'monospace', fontSize: 11, fontWeight: 700, cursor: 'pointer', letterSpacing: '0.04em' }}>
              ▲ VOUCH
            </button>
            <button type="button" onClick={() => start('deny')} style={{ flex: 1, padding: '7px', borderRadius: 6, border: `1px solid ${RED}45`, background: `${RED}10`, color: RED, fontFamily: 'monospace', fontSize: 11, fontWeight: 700, cursor: 'pointer', letterSpacing: '0.04em' }}>
              ▼ DENY
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

function VariationE1() {
  const [selectedId, setSelectedId] = useState<string>('code-generation')
  const selectedCap = MOCK_CAPABILITIES.find((c) => c.id === selectedId)!

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
      {/* Identity */}
      <div style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: '10px 10px 0 0', borderBottom: 'none', padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 40, height: 40, borderRadius: '50%', background: `${PURPLE}20`, border: `2px solid ${PURPLE}50`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'monospace', fontSize: 18, fontWeight: 800, color: PURPLE, flexShrink: 0 }}>D</div>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontFamily: 'monospace', fontSize: 16, fontWeight: 800, color: TEXT }}>{MOCK_AGENT.name}</span>
              <span style={{ fontFamily: 'monospace', fontSize: 9, color: PURPLE, background: `${PURPLE}18`, padding: '2px 5px', borderRadius: 4 }}>{MOCK_AGENT.version}</span>
            </div>
            <p style={{ fontFamily: 'monospace', fontSize: 10, color: TEXT_MUTED, margin: 0, marginTop: 2 }}>{MOCK_AGENT.description}</p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
            <TrustRing percent={MOCK_AGENT.trustPct} size={32} />
            <span style={{ fontFamily: 'monospace', fontSize: 14, fontWeight: 800, color: trustColor(MOCK_AGENT.trustPct) }}>{MOCK_AGENT.trustPct}%</span>
          </div>
        </div>
        {/* Entity trust prompt — always visible */}
        <E1EntityTrust />
      </div>

      {/* Split panel */}
      <div style={{ display: 'flex', background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: '0 0 10px 10px', minHeight: 360, overflow: 'hidden' }}>
        {/* Left: capability list */}
        <div style={{ flex: '0 0 60%', borderRight: `1px solid ${BORDER}` }}>
          <div style={{ fontFamily: 'monospace', fontSize: 8, fontWeight: 700, color: TEXT_FAINT, letterSpacing: '0.12em', padding: '9px 14px 7px', borderBottom: `1px solid ${BORDER}`, textTransform: 'uppercase' }}>
            CAPABILITIES — SELECT TO STAKE
          </div>
          {MOCK_CAPABILITIES.map((cap) => (
            <E1CapRow key={cap.id} cap={cap} isSelected={cap.id === selectedId} onSelect={() => setSelectedId(cap.id)} />
          ))}
        </div>
        {/* Right: panel */}
        <div style={{ flex: 1, padding: '14px 16px' }}>
          <E1Panel cap={selectedCap} />
        </div>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════
// E2: NEON DASHBOARD
// ══════════════════════════════════════════════════════════════════

function E2EntityTrust() {
  const { state, start, selectTier } = useStaking('entity-e2')
  const color = trustColor(MOCK_AGENT.trustPct)

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6, flexShrink: 0 }}>
      <div style={{ fontFamily: 'monospace', fontSize: 8, color: TEXT_FAINT, letterSpacing: '0.1em', textTransform: 'uppercase', textAlign: 'center' }}>TRUST?</div>
      <div style={{ position: 'relative', width: 44, height: 44 }}>
        <TrustRing percent={MOCK_AGENT.trustPct} size={44} />
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'monospace', fontSize: 11, fontWeight: 800, color }}>
          {MOCK_AGENT.trustPct}%
        </div>
      </div>
      {state.step === 'confirmed' ? (
        <div style={{ fontFamily: 'monospace', fontSize: 9, color: GREEN, fontWeight: 700 }}>✓ {state.tier}</div>
      ) : state.step === 'tiers' ? (
        <div style={{ width: 120 }}>
          <ConvictionTiers direction={state.direction!} onSelect={selectTier} />
        </div>
      ) : (
        <div style={{ display: 'flex', gap: 5 }}>
          <button type="button" onClick={() => start('vouch')} style={{
            padding: '3px 9px', borderRadius: 4, border: `1px solid ${GREEN}55`,
            background: `${GREEN}12`, color: GREEN, fontFamily: 'monospace', fontSize: 9,
            fontWeight: 700, cursor: 'pointer', letterSpacing: '0.04em',
            boxShadow: `0 0 6px ${GREEN}20`,
          }}>V</button>
          <button type="button" onClick={() => start('deny')} style={{
            padding: '3px 9px', borderRadius: 4, border: `1px solid ${RED}55`,
            background: `${RED}12`, color: RED, fontFamily: 'monospace', fontSize: 9,
            fontWeight: 700, cursor: 'pointer', letterSpacing: '0.04em',
            boxShadow: `0 0 6px ${RED}20`,
          }}>D</button>
        </div>
      )}
    </div>
  )
}

function E2CapCard({ cap, isSelected, onSelect }: { cap: MockCapability; isSelected: boolean; onSelect: () => void }) {
  const color = trustColor(cap.trustPct)
  const totalStakers = cap.forVault.position_count + cap.againstVault.position_count

  return (
    <button
      type="button"
      onClick={onSelect}
      style={{
        display: 'flex', alignItems: 'center', gap: 12,
        width: '100%', padding: '10px 14px',
        background: isSelected ? `${color}0c` : 'transparent',
        border: 'none',
        borderLeft: `2px solid ${isSelected ? color : 'transparent'}`,
        borderBottom: `1px solid ${BORDER}`,
        cursor: 'pointer', textAlign: 'left',
        boxShadow: isSelected ? `inset 0 0 20px ${color}06` : 'none',
        transition: 'all 0.12s',
      }}
      onMouseEnter={(e) => { if (!isSelected) { e.currentTarget.style.background = '#ffffff04'; e.currentTarget.style.borderLeftColor = `${color}40` } }}
      onMouseLeave={(e) => { if (!isSelected) { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.borderLeftColor = 'transparent' } }}
    >
      {/* Neon dot */}
      <div style={{ width: 10, height: 10, borderRadius: '50%', background: color, flexShrink: 0, boxShadow: `0 0 8px ${color}80, 0 0 16px ${color}30` }} />

      {/* Name + description */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: 'monospace', fontSize: 11, fontWeight: 700, color: isSelected ? color : TEXT, letterSpacing: '0.04em', textTransform: 'uppercase' }}>
          {cap.name}
        </div>
        <div style={{ fontFamily: 'monospace', fontSize: 9, color: TEXT_MUTED, marginTop: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {cap.description}
        </div>
      </div>

      {/* Right: % + stakers */}
      <div style={{ textAlign: 'right', flexShrink: 0 }}>
        <div style={{ fontFamily: 'monospace', fontSize: 15, fontWeight: 900, color, letterSpacing: '-0.02em' }}>{cap.trustPct}%</div>
        <div style={{ fontFamily: 'monospace', fontSize: 8, color: TEXT_FAINT, marginTop: 2 }}>{totalStakers} stakers</div>
      </div>
    </button>
  )
}

function E2Panel({ cap }: { cap: MockCapability }) {
  const { state, start, selectTier, reset } = useStaking(`panel-e2-${cap.id}`)
  const color = trustColor(cap.trustPct)

  return (
    <div key={cap.id} style={{ display: 'flex', flexDirection: 'column', gap: 14, animation: 'slideInRight 0.18s ease' }}>
      <div>
        <div style={{ fontFamily: 'monospace', fontSize: 8, color: TEXT_FAINT, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 4 }}>CLAIM</div>
        <div style={{ fontFamily: 'monospace', fontSize: 15, fontWeight: 900, color, textTransform: 'uppercase', letterSpacing: '0.03em', lineHeight: 1.2 }}>
          HAS {cap.name.toUpperCase()}?
        </div>
      </div>

      {/* Ring + % */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
        <div style={{ position: 'relative' }}>
          <TrustRing percent={cap.trustPct} size={64} />
          <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'monospace', fontSize: 16, fontWeight: 900, color }}>
            {cap.trustPct}%
          </div>
        </div>
        <div style={{ fontFamily: 'monospace', fontSize: 9, color: TEXT_MUTED, letterSpacing: '0.06em' }}>{trustLabel(cap.trustPct)}</div>
      </div>

      {/* For / against split */}
      <div>
        <TrustBar percent={cap.trustPct} />
        <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'monospace', fontSize: 8, marginTop: 5 }}>
          <span style={{ color: GREEN }}>FOR {cap.forVault.total_assets} TRUST</span>
          <span style={{ color: RED }}>AGAINST {cap.againstVault.total_assets} TRUST</span>
        </div>
      </div>

      {/* Actions */}
      <div style={{ borderTop: `1px solid ${BORDER}`, paddingTop: 10 }}>
        {state.step === 'confirmed' ? (
          <ConfirmedFlash direction={state.direction!} tier={state.tier!} />
        ) : state.step === 'tiers' ? (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
              <span style={{ fontFamily: 'monospace', fontSize: 10, color: state.direction === 'vouch' ? GREEN : RED, fontWeight: 700 }}>SELECT TIER</span>
              <button type="button" onClick={reset} style={{ marginLeft: 'auto', background: 'none', border: 'none', color: TEXT_MUTED, cursor: 'pointer', fontSize: 12 }}>✕</button>
            </div>
            <ConvictionTiers direction={state.direction!} onSelect={selectTier} />
          </div>
        ) : (
          <div style={{ display: 'flex', gap: 8 }}>
            <button type="button" onClick={() => start('vouch')} style={{ flex: 1, padding: '8px', borderRadius: 6, border: `1px solid ${GREEN}45`, background: `${GREEN}10`, color: GREEN, fontFamily: 'monospace', fontSize: 11, fontWeight: 700, cursor: 'pointer', boxShadow: `0 0 8px ${GREEN}15` }}>
              VOUCH
            </button>
            <button type="button" onClick={() => start('deny')} style={{ flex: 1, padding: '8px', borderRadius: 6, border: `1px solid ${RED}45`, background: `${RED}10`, color: RED, fontFamily: 'monospace', fontSize: 11, fontWeight: 700, cursor: 'pointer', boxShadow: `0 0 8px ${RED}15` }}>
              DENY
            </button>
          </div>
        )}
      </div>

      {/* Vault stats */}
      <div style={{ background: '#0d0d14', border: `1px solid ${BORDER}`, borderRadius: 6, padding: '8px 10px', display: 'flex', flexDirection: 'column', gap: 4 }}>
        <div style={{ fontFamily: 'monospace', fontSize: 8, color: TEXT_FAINT, letterSpacing: '0.1em', marginBottom: 4 }}>VAULT STATS</div>
        {[
          ['TVL', `${(cap.forVault.total_assets + cap.againstVault.total_assets).toFixed(2)} TRUST`],
          ['STAKERS', `${cap.forVault.position_count + cap.againstVault.position_count}`],
          ['SHARE PRICE', `${cap.forVault.current_share_price.toFixed(3)}`],
        ].map(([label, val]) => (
          <div key={label} style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'monospace', fontSize: 9 }}>
            <span style={{ color: TEXT_FAINT }}>{label}</span>
            <span style={{ color: TEXT_MUTED, fontWeight: 700 }}>{val}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

function VariationE2() {
  const [selectedId, setSelectedId] = useState<string>('code-generation')
  const selectedCap = MOCK_CAPABILITIES.find((c) => c.id === selectedId)!

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
      {/* Identity */}
      <div style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: '10px 10px 0 0', borderBottom: 'none', padding: '14px 16px', display: 'flex', alignItems: 'flex-start', gap: 12 }}>
        <div style={{ width: 40, height: 40, borderRadius: '50%', background: `${PURPLE}20`, border: `2px solid ${PURPLE}50`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'monospace', fontSize: 18, fontWeight: 800, color: PURPLE, flexShrink: 0 }}>D</div>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ fontFamily: 'monospace', fontSize: 16, fontWeight: 800, color: TEXT }}>{MOCK_AGENT.name}</span>
            <span style={{ fontFamily: 'monospace', fontSize: 9, color: PURPLE, background: `${PURPLE}18`, padding: '2px 5px', borderRadius: 4 }}>{MOCK_AGENT.version}</span>
          </div>
          <p style={{ fontFamily: 'monospace', fontSize: 10, color: TEXT_MUTED, margin: 0 }}>{MOCK_AGENT.description}</p>
        </div>
        {/* Compact trust widget top-right */}
        <E2EntityTrust />
      </div>

      {/* Split panel */}
      <div style={{ display: 'flex', background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: '0 0 10px 10px', minHeight: 360, overflow: 'hidden' }}>
        <div style={{ flex: '0 0 60%', borderRight: `1px solid ${BORDER}` }}>
          <div style={{ fontFamily: 'monospace', fontSize: 8, fontWeight: 700, color: TEXT_FAINT, letterSpacing: '0.12em', padding: '9px 14px 7px', borderBottom: `1px solid ${BORDER}`, textTransform: 'uppercase' }}>
            CAPABILITIES
          </div>
          {MOCK_CAPABILITIES.map((cap) => (
            <E2CapCard key={cap.id} cap={cap} isSelected={cap.id === selectedId} onSelect={() => setSelectedId(cap.id)} />
          ))}
        </div>
        <div style={{ flex: 1, padding: '14px 16px', overflowY: 'auto' }}>
          <E2Panel cap={selectedCap} />
        </div>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════
// E3: QUESTION FORWARD
// ══════════════════════════════════════════════════════════════════

function E3EntityTrust() {
  const { state, start, selectTier, reset } = useStaking('entity-e3')
  const color = trustColor(MOCK_AGENT.trustPct)

  return (
    <div style={{
      background: '#0d0d14',
      border: `1px solid ${BORDER}`,
      borderRadius: 10,
      padding: '16px 20px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 12,
      textAlign: 'center',
    }}>
      <div style={{
        fontFamily: 'monospace', fontSize: 16, fontWeight: 900, color: TEXT,
        letterSpacing: '0.04em', textTransform: 'uppercase',
        textShadow: `0 0 20px ${PURPLE}40`,
      }}>
        DO YOU TRUST <span style={{ color: PURPLE }}>{MOCK_AGENT.name.toUpperCase()}</span>?
      </div>

      <div style={{ position: 'relative', width: 64, height: 64 }}>
        <TrustRing percent={MOCK_AGENT.trustPct} size={64} />
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ fontFamily: 'monospace', fontSize: 14, fontWeight: 900, color }}>{MOCK_AGENT.trustPct}%</div>
        </div>
      </div>
      <div style={{ fontFamily: 'monospace', fontSize: 9, color: TEXT_MUTED, letterSpacing: '0.06em' }}>COMMUNITY CONSENSUS</div>

      {state.step === 'confirmed' ? (
        <ConfirmedFlash direction={state.direction!} tier={state.tier!} />
      ) : state.step === 'tiers' ? (
        <div style={{ width: '100%', maxWidth: 240 }}>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontFamily: 'monospace', fontSize: 10, color: state.direction === 'vouch' ? GREEN : RED, fontWeight: 700 }}>CONVICTION LEVEL:</span>
            <button type="button" onClick={reset} style={{ marginLeft: 'auto', background: 'none', border: 'none', color: TEXT_MUTED, cursor: 'pointer', fontSize: 12 }}>✕</button>
          </div>
          <ConvictionTiers direction={state.direction!} onSelect={selectTier} />
        </div>
      ) : (
        <div style={{ display: 'flex', gap: 10 }}>
          <button type="button" onClick={() => start('vouch')} style={{
            padding: '9px 24px', borderRadius: 7,
            border: `2px solid ${GREEN}55`, background: `${GREEN}10`,
            color: GREEN, fontFamily: 'monospace', fontSize: 12, fontWeight: 700,
            cursor: 'pointer', letterSpacing: '0.06em',
            boxShadow: `0 0 12px ${GREEN}20`,
          }}>══ VOUCH ══</button>
          <button type="button" onClick={() => start('deny')} style={{
            padding: '9px 24px', borderRadius: 7,
            border: `2px solid ${RED}55`, background: `${RED}10`,
            color: RED, fontFamily: 'monospace', fontSize: 12, fontWeight: 700,
            cursor: 'pointer', letterSpacing: '0.06em',
            boxShadow: `0 0 12px ${RED}20`,
          }}>══ DENY ══</button>
        </div>
      )}
    </div>
  )
}

function E3CapRow({ cap, isSelected, onSelect }: { cap: MockCapability; isSelected: boolean; onSelect: () => void }) {
  const color = trustColor(cap.trustPct)
  return (
    <button
      type="button"
      onClick={onSelect}
      style={{
        display: 'flex', alignItems: 'center', gap: 10,
        width: '100%', padding: '8px 14px',
        background: isSelected ? `${color}0c` : 'transparent',
        border: 'none',
        borderLeft: `2px solid ${isSelected ? color : 'transparent'}`,
        borderBottom: `1px solid ${BORDER}`,
        cursor: 'pointer', textAlign: 'left', transition: 'all 0.1s',
      }}
      onMouseEnter={(e) => { if (!isSelected) e.currentTarget.style.background = '#ffffff05' }}
      onMouseLeave={(e) => { if (!isSelected) e.currentTarget.style.background = 'transparent' }}
    >
      <StatusDot percent={cap.trustPct} />
      <span style={{ flex: 1, fontFamily: 'monospace', fontSize: 11, fontWeight: 700, color: isSelected ? color : TEXT, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
        {cap.name}
      </span>
      <span style={{ fontFamily: 'monospace', fontSize: 12, fontWeight: 800, color }}>{cap.trustPct}%</span>
    </button>
  )
}

function E3Panel({ cap }: { cap: MockCapability }) {
  const { state, start, selectTier, reset } = useStaking(`panel-e3-${cap.id}`)
  const color = trustColor(cap.trustPct)

  return (
    <div key={cap.id} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, textAlign: 'center', animation: 'slideInRight 0.18s ease' }}>
      <div>
        <div style={{ fontFamily: 'monospace', fontSize: 8, color: TEXT_FAINT, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 6 }}>CAPABILITY CLAIM</div>
        <div style={{ fontFamily: 'monospace', fontSize: 14, fontWeight: 900, color: TEXT, textTransform: 'uppercase', letterSpacing: '0.04em', lineHeight: 1.3 }}>
          DOES <span style={{ color: PURPLE }}>{MOCK_AGENT.name.toUpperCase()}</span> HAVE
        </div>
        <div style={{ fontFamily: 'monospace', fontSize: 14, fontWeight: 900, color, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          {cap.name.toUpperCase()}?
        </div>
      </div>

      <div style={{ position: 'relative', width: 60, height: 60 }}>
        <TrustRing percent={cap.trustPct} size={60} />
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ fontFamily: 'monospace', fontSize: 14, fontWeight: 900, color }}>{cap.trustPct}%</div>
        </div>
      </div>

      <TrustBar percent={cap.trustPct} />
      <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%', fontFamily: 'monospace', fontSize: 8 }}>
        <span style={{ color: GREEN }}>FOR {cap.forVault.total_assets} TRUST</span>
        <span style={{ color: RED }}>AGAINST {cap.againstVault.total_assets} TRUST</span>
      </div>

      <div style={{ width: '100%', borderTop: `1px solid ${BORDER}`, paddingTop: 10 }}>
        {state.step === 'confirmed' ? (
          <ConfirmedFlash direction={state.direction!} tier={state.tier!} />
        ) : state.step === 'tiers' ? (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
              <span style={{ fontFamily: 'monospace', fontSize: 10, color: state.direction === 'vouch' ? GREEN : RED, fontWeight: 700 }}>
                → {state.direction?.toUpperCase()} TIER:
              </span>
              <button type="button" onClick={reset} style={{ marginLeft: 'auto', background: 'none', border: 'none', color: TEXT_MUTED, cursor: 'pointer', fontSize: 12 }}>✕</button>
            </div>
            <ConvictionTiers direction={state.direction!} onSelect={selectTier} />
          </div>
        ) : (
          <div style={{ display: 'flex', gap: 8 }}>
            <button type="button" onClick={() => start('vouch')} style={{ flex: 1, padding: '8px', borderRadius: 6, border: `2px solid ${GREEN}50`, background: `${GREEN}10`, color: GREEN, fontFamily: 'monospace', fontSize: 11, fontWeight: 700, cursor: 'pointer' }}>══ VOUCH ══</button>
            <button type="button" onClick={() => start('deny')} style={{ flex: 1, padding: '8px', borderRadius: 6, border: `2px solid ${RED}50`, background: `${RED}10`, color: RED, fontFamily: 'monospace', fontSize: 11, fontWeight: 700, cursor: 'pointer' }}>══ DENY ══</button>
          </div>
        )}
      </div>
    </div>
  )
}

function VariationE3() {
  const [selectedId, setSelectedId] = useState<string>('code-generation')
  const selectedCap = MOCK_CAPABILITIES.find((c) => c.id === selectedId)!

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
      {/* Identity */}
      <div style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: '10px 10px 0 0', borderBottom: 'none', padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ width: 40, height: 40, borderRadius: '50%', background: `${PURPLE}20`, border: `2px solid ${PURPLE}50`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'monospace', fontSize: 18, fontWeight: 800, color: PURPLE, flexShrink: 0 }}>D</div>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontFamily: 'monospace', fontSize: 16, fontWeight: 800, color: TEXT }}>{MOCK_AGENT.name}</span>
            <span style={{ fontFamily: 'monospace', fontSize: 9, color: PURPLE, background: `${PURPLE}18`, padding: '2px 5px', borderRadius: 4 }}>{MOCK_AGENT.version}</span>
          </div>
          <p style={{ fontFamily: 'monospace', fontSize: 10, color: TEXT_MUTED, margin: '3px 0 0' }}>{MOCK_AGENT.description}</p>
        </div>
      </div>

      {/* Entity trust — prominent block, full-width, always visible */}
      <div style={{ borderLeft: `1px solid ${BORDER}`, borderRight: `1px solid ${BORDER}`, borderBottom: 'none', padding: '0 16px 14px' }}>
        <E3EntityTrust />
      </div>

      {/* Split panel */}
      <div style={{ display: 'flex', background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: '0 0 10px 10px', minHeight: 300, overflow: 'hidden' }}>
        <div style={{ flex: '0 0 55%', borderRight: `1px solid ${BORDER}` }}>
          <div style={{ fontFamily: 'monospace', fontSize: 8, fontWeight: 700, color: TEXT_FAINT, letterSpacing: '0.12em', padding: '9px 14px 7px', borderBottom: `1px solid ${BORDER}`, textTransform: 'uppercase' }}>
            CAPABILITIES
          </div>
          {MOCK_CAPABILITIES.map((cap) => (
            <E3CapRow key={cap.id} cap={cap} isSelected={cap.id === selectedId} onSelect={() => setSelectedId(cap.id)} />
          ))}
        </div>
        <div style={{ flex: 1, padding: '16px' }}>
          <E3Panel cap={selectedCap} />
        </div>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════
// E4: STATUS BOARD
// ══════════════════════════════════════════════════════════════════

function E4EntityTrust() {
  const { state, start, selectTier, reset } = useStaking('entity-e4')
  const [, setOpen] = useState(false)
  const color = trustColor(MOCK_AGENT.trustPct)
  const label = trustLabel(MOCK_AGENT.trustPct)

  const handleStart = (dir: Direction) => {
    start(dir)
    setOpen(false)
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4, flexShrink: 0 }}>
      {state.step === 'confirmed' ? (
        <div style={{ fontFamily: 'monospace', fontSize: 9, color: GREEN, fontWeight: 700 }}>✓ {state.tier} TRUST</div>
      ) : (
        <>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontFamily: 'monospace', fontSize: 9, color: TEXT_FAINT, letterSpacing: '0.08em' }}>TRUST STATUS:</span>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: color, boxShadow: `0 0 6px ${color}70`, flexShrink: 0 }} />
            <span style={{ fontFamily: 'monospace', fontSize: 9, color, fontWeight: 700, letterSpacing: '0.06em' }}>
              {label} ({MOCK_AGENT.trustPct}%)
            </span>
          </div>
          {state.step === 'tiers' ? (
            <div style={{ width: 160 }}>
              <ConvictionTiers direction={state.direction!} onSelect={selectTier} />
              <button type="button" onClick={reset} style={{ background: 'none', border: 'none', color: TEXT_MUTED, cursor: 'pointer', fontSize: 10, marginTop: 4 }}>cancel</button>
            </div>
          ) : (
            <div style={{ display: 'flex', gap: 8 }}>
              <button type="button" onClick={() => handleStart('vouch')} style={{ background: 'none', border: 'none', color: GREEN, fontFamily: 'monospace', fontSize: 10, fontWeight: 700, cursor: 'pointer', letterSpacing: '0.04em', textDecoration: 'underline', textUnderlineOffset: 3 }}>vouch</button>
              <button type="button" onClick={() => handleStart('deny')} style={{ background: 'none', border: 'none', color: RED, fontFamily: 'monospace', fontSize: 10, fontWeight: 700, cursor: 'pointer', letterSpacing: '0.04em', textDecoration: 'underline', textUnderlineOffset: 3 }}>deny</button>
            </div>
          )}
        </>
      )}
    </div>
  )
}

function E4CapRow({ cap, isSelected, index, onSelect }: { cap: MockCapability; isSelected: boolean; index: number; onSelect: () => void }) {
  const color = trustColor(cap.trustPct)
  const label = trustLabel(cap.trustPct)
  const barFilled = Math.round(cap.trustPct / 10)

  return (
    <button
      type="button"
      onClick={onSelect}
      style={{
        display: 'flex', alignItems: 'center', gap: 10,
        width: '100%', padding: '8px 14px',
        background: isSelected ? `${color}0c` : index % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.015)',
        border: 'none',
        borderLeft: `3px solid ${isSelected ? color : 'transparent'}`,
        borderBottom: `1px solid ${BORDER}`,
        cursor: 'pointer', textAlign: 'left', transition: 'all 0.1s',
      }}
      onMouseEnter={(e) => { if (!isSelected) e.currentTarget.style.background = '#ffffff07' }}
      onMouseLeave={(e) => { if (!isSelected) e.currentTarget.style.background = index % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.015)' }}
    >
      <div style={{ width: 8, height: 8, borderRadius: '50%', background: color, flexShrink: 0, boxShadow: `0 0 5px ${color}60` }} />
      <span style={{ flex: 1, fontFamily: 'monospace', fontSize: 11, fontWeight: 700, color: isSelected ? color : TEXT, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
        {cap.name}
      </span>
      <div style={{ display: 'flex', gap: 0 }}>
        {'█'.repeat(barFilled).split('').map((c, i) => (
          <span key={i} style={{ color, fontSize: 8, lineHeight: 1 }}>{c}</span>
        ))}
        {'░'.repeat(10 - barFilled).split('').map((c, i) => (
          <span key={i} style={{ color: TEXT_FAINT, fontSize: 8, lineHeight: 1 }}>{c}</span>
        ))}
      </div>
      <span style={{ fontFamily: 'monospace', fontSize: 9, color, fontWeight: 700, minWidth: 58, letterSpacing: '0.04em' }}>
        {label}
      </span>
      <span style={{ fontFamily: 'monospace', fontSize: 11, fontWeight: 800, color, minWidth: 34, textAlign: 'right' }}>
        {cap.trustPct}%
      </span>
    </button>
  )
}

function E4Panel({ cap }: { cap: MockCapability }) {
  const { state, start, selectTier, reset } = useStaking(`panel-e4-${cap.id}`)
  const color = trustColor(cap.trustPct)
  const label = trustLabel(cap.trustPct)
  const forTotal = cap.forVault.total_assets
  const againstTotal = cap.againstVault.total_assets
  const totalVol = forTotal + againstTotal

  const forBarW = Math.round((forTotal / totalVol) * 100)
  const forBars = '█'.repeat(Math.round(forBarW / 10))
  const againstBars = '█'.repeat(10 - Math.round(forBarW / 10))

  return (
    <div key={cap.id} style={{ display: 'flex', flexDirection: 'column', gap: 10, animation: 'slideInRight 0.18s ease' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{ width: 10, height: 10, borderRadius: '50%', background: color, boxShadow: `0 0 8px ${color}70`, flexShrink: 0 }} />
        <span style={{ fontFamily: 'monospace', fontSize: 11, fontWeight: 900, color, letterSpacing: '0.06em' }}>{label}</span>
      </div>
      <div style={{ fontFamily: 'monospace', fontSize: 12, fontWeight: 900, color: TEXT, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
        {cap.name}
      </div>
      <div style={{ fontFamily: 'monospace', fontSize: 9, color: TEXT_MUTED }}>{cap.description}</div>

      <div style={{ background: '#0d0d14', border: `1px solid ${BORDER}`, borderRadius: 6, padding: '8px 10px' }}>
        <div style={{ fontFamily: 'monospace', fontSize: 8, color: TEXT_FAINT, letterSpacing: '0.1em', marginBottom: 6 }}>STAKE BREAKDOWN</div>
        <div style={{ fontFamily: 'monospace', fontSize: 9, marginBottom: 4 }}>
          <span style={{ color: GREEN }}>{forBars}</span>{' '}
          <span style={{ color: TEXT }}>{forTotal} TRUST ({cap.forVault.position_count})</span>
        </div>
        <div style={{ fontFamily: 'monospace', fontSize: 9 }}>
          <span style={{ color: RED }}>{againstBars}</span>{' '}
          <span style={{ color: TEXT }}>{againstTotal} TRUST ({cap.againstVault.position_count})</span>
        </div>
      </div>

      <div style={{ borderTop: `1px solid ${BORDER}`, paddingTop: 10 }}>
        {state.step === 'confirmed' ? (
          <ConfirmedFlash direction={state.direction!} tier={state.tier!} />
        ) : state.step === 'tiers' ? (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
              <span style={{ fontFamily: 'monospace', fontSize: 10, color: state.direction === 'vouch' ? GREEN : RED, fontWeight: 700 }}>CONVICTION:</span>
              <button type="button" onClick={reset} style={{ marginLeft: 'auto', background: 'none', border: 'none', color: TEXT_MUTED, cursor: 'pointer', fontSize: 12 }}>✕</button>
            </div>
            <ConvictionTiers direction={state.direction!} onSelect={selectTier} />
          </div>
        ) : (
          <div style={{ display: 'flex', gap: 8 }}>
            <button type="button" onClick={() => start('vouch')} style={{ flex: 1, padding: '7px', borderRadius: 5, border: `1px solid ${GREEN}45`, background: `${GREEN}10`, color: GREEN, fontFamily: 'monospace', fontSize: 10, fontWeight: 700, cursor: 'pointer' }}>VOUCH</button>
            <button type="button" onClick={() => start('deny')} style={{ flex: 1, padding: '7px', borderRadius: 5, border: `1px solid ${RED}45`, background: `${RED}10`, color: RED, fontFamily: 'monospace', fontSize: 10, fontWeight: 700, cursor: 'pointer' }}>DENY</button>
          </div>
        )}
      </div>

      <div style={{ fontFamily: 'monospace', fontSize: 8, color: TEXT_FAINT, letterSpacing: '0.04em' }}>
        Last activity: 2 hours ago
      </div>
    </div>
  )
}

function VariationE4() {
  const [selectedId, setSelectedId] = useState<string>('code-generation')
  const selectedCap = MOCK_CAPABILITIES.find((c) => c.id === selectedId)!

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
      {/* Identity */}
      <div style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: '10px 10px 0 0', borderBottom: 'none', padding: '14px 16px', display: 'flex', alignItems: 'flex-start', gap: 12 }}>
        <div style={{ width: 40, height: 40, borderRadius: '50%', background: `${PURPLE}20`, border: `2px solid ${PURPLE}50`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'monospace', fontSize: 18, fontWeight: 800, color: PURPLE, flexShrink: 0 }}>D</div>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontFamily: 'monospace', fontSize: 16, fontWeight: 800, color: TEXT }}>{MOCK_AGENT.name}</span>
            <span style={{ fontFamily: 'monospace', fontSize: 9, color: PURPLE, background: `${PURPLE}18`, padding: '2px 5px', borderRadius: 4 }}>{MOCK_AGENT.version}</span>
          </div>
          <p style={{ fontFamily: 'monospace', fontSize: 10, color: TEXT_MUTED, margin: '3px 0 0' }}>{MOCK_AGENT.description}</p>
        </div>
        <E4EntityTrust />
      </div>

      {/* Split panel */}
      <div style={{ display: 'flex', background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: '0 0 10px 10px', minHeight: 360, overflow: 'hidden' }}>
        <div style={{ flex: '0 0 62%', borderRight: `1px solid ${BORDER}` }}>
          <div style={{ display: 'flex', gap: 0, fontFamily: 'monospace', fontSize: 8, fontWeight: 700, color: TEXT_FAINT, letterSpacing: '0.08em', textTransform: 'uppercase', padding: '8px 14px', borderBottom: `1px solid ${BORDER}` }}>
            <span style={{ flex: 1 }}>CAPABILITY</span>
            <span style={{ minWidth: 80, textAlign: 'center' }}>SCORE</span>
            <span style={{ minWidth: 70, textAlign: 'center' }}>STATUS</span>
            <span style={{ minWidth: 34, textAlign: 'right' }}>TRUST</span>
          </div>
          {MOCK_CAPABILITIES.map((cap, i) => (
            <E4CapRow key={cap.id} cap={cap} isSelected={cap.id === selectedId} index={i} onSelect={() => setSelectedId(cap.id)} />
          ))}
        </div>
        <div style={{ flex: 1, padding: '14px 16px' }}>
          <E4Panel cap={selectedCap} />
        </div>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════
// E5: PREDICTION MARKET
// ══════════════════════════════════════════════════════════════════

function E5EntityTrust() {
  const { state, start, selectTier } = useStaking('entity-e5')
  const color = trustColor(MOCK_AGENT.trustPct)
  const totalVol = MOCK_AGENT.forVault.total_assets + MOCK_AGENT.againstVault.total_assets

  return (
    <div style={{
      border: `1px solid ${BORDER}`,
      borderRadius: 7,
      padding: '8px 10px',
      background: '#0d0d14',
      fontFamily: 'monospace',
      flexShrink: 0,
      minWidth: 280,
    }}>
      {state.step === 'confirmed' ? (
        <ConfirmedFlash direction={state.direction!} tier={state.tier!} />
      ) : state.step === 'tiers' ? (
        <ConvictionTiers direction={state.direction!} onSelect={selectTier} />
      ) : (
        <>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 5 }}>
            <span style={{ fontSize: 10, fontWeight: 700, color: TEXT, letterSpacing: '0.04em', flex: 1 }}>
              DO YOU TRUST <span style={{ color: PURPLE }}>{MOCK_AGENT.name.toUpperCase()}</span>?
            </span>
            <span style={{ fontSize: 15, fontWeight: 900, color }}>{MOCK_AGENT.trustPct}%</span>
            <button type="button" onClick={() => start('vouch')} style={{ padding: '3px 8px', borderRadius: 4, border: `1px solid ${GREEN}50`, background: `${GREEN}12`, color: GREEN, fontFamily: 'monospace', fontSize: 9, fontWeight: 700, cursor: 'pointer' }}>V</button>
            <button type="button" onClick={() => start('deny')} style={{ padding: '3px 8px', borderRadius: 4, border: `1px solid ${RED}50`, background: `${RED}12`, color: RED, fontFamily: 'monospace', fontSize: 9, fontWeight: 700, cursor: 'pointer' }}>D</button>
          </div>
          <TrustBar percent={MOCK_AGENT.trustPct} />
          <div style={{ fontSize: 8, color: TEXT_FAINT, marginTop: 4 }}>{totalVol.toFixed(2)} TRUST vol.</div>
        </>
      )}
    </div>
  )
}

function E5CapRow({ cap, isSelected, onSelect }: { cap: MockCapability; isSelected: boolean; onSelect: () => void }) {
  const { state, start, selectTier, reset } = useStaking(`row-e5-${cap.id}`)
  const color = trustColor(cap.trustPct)
  const totalVol = (cap.forVault.total_assets + cap.againstVault.total_assets).toFixed(2)
  const [expandedInRow, setExpandedInRow] = useState(false)

  const handleStart = (dir: Direction, e: React.MouseEvent) => {
    e.stopPropagation()
    start(dir)
    setExpandedInRow(true)
  }

  const handleTier = (tier: string) => {
    selectTier(tier)
    setTimeout(() => setExpandedInRow(false), 1600)
  }

  return (
    <div
      style={{
        borderBottom: `1px solid ${BORDER}`,
        background: isSelected ? `${color}08` : 'transparent',
        borderLeft: `2px solid ${isSelected ? color : 'transparent'}`,
        transition: 'all 0.1s',
      }}
    >
      <button
        type="button"
        onClick={onSelect}
        style={{
          display: 'flex', alignItems: 'center', gap: 10,
          width: '100%', padding: '9px 14px',
          background: 'transparent', border: 'none',
          cursor: 'pointer', textAlign: 'left',
        }}
        onMouseEnter={(e) => { if (!isSelected) e.currentTarget.closest('div')!.style.background = '#ffffff04' }}
        onMouseLeave={(e) => { if (!isSelected) e.currentTarget.closest('div')!.style.background = 'transparent' }}
      >
        <StatusDot percent={cap.trustPct} />
        <span style={{ flex: 1, fontFamily: 'monospace', fontSize: 11, fontWeight: 700, color: isSelected ? color : TEXT, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          {cap.name}
        </span>
        <span style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 900, color, minWidth: 34, textAlign: 'right' }}>
          {cap.trustPct}%
        </span>

        {/* Inline V/D */}
        {state.step === 'confirmed' ? (
          <span style={{ fontFamily: 'monospace', fontSize: 9, color: GREEN, fontWeight: 700, minWidth: 60 }}>✓ {state.tier}</span>
        ) : (
          <div style={{ display: 'flex', gap: 4, marginLeft: 8 }} onClick={(e) => e.stopPropagation()}>
            <button type="button" onClick={(e) => handleStart('vouch', e)} style={{ padding: '2px 7px', borderRadius: 3, border: `1px solid ${GREEN}50`, background: `${GREEN}12`, color: GREEN, fontFamily: 'monospace', fontSize: 9, fontWeight: 700, cursor: 'pointer' }}>V</button>
            <button type="button" onClick={(e) => handleStart('deny', e)} style={{ padding: '2px 7px', borderRadius: 3, border: `1px solid ${RED}50`, background: `${RED}12`, color: RED, fontFamily: 'monospace', fontSize: 9, fontWeight: 700, cursor: 'pointer' }}>D</button>
          </div>
        )}

        <span style={{ fontFamily: 'monospace', fontSize: 9, color: TEXT_FAINT, minWidth: 50, textAlign: 'right' }}>{totalVol} TRUST</span>
      </button>

      {/* Inline tier expansion */}
      {expandedInRow && state.step === 'tiers' && (
        <div style={{ padding: '0 14px 10px', animation: 'varB-expand 0.18s ease both' }}>
          <style>{`@keyframes varB-expand { from { opacity:0; transform:translateY(-4px) } to { opacity:1; transform:translateY(0) } }`}</style>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: 6 }}>
            <span style={{ fontFamily: 'monospace', fontSize: 9, color: state.direction === 'vouch' ? GREEN : RED, fontWeight: 700 }}>TIER:</span>
            <button type="button" onClick={(e) => { e.stopPropagation(); reset(); setExpandedInRow(false) }} style={{ marginLeft: 'auto', background: 'none', border: 'none', color: TEXT_MUTED, cursor: 'pointer', fontSize: 11 }}>✕</button>
          </div>
          <ConvictionTiers direction={state.direction!} onSelect={handleTier} />
        </div>
      )}
    </div>
  )
}

function E5Panel({ cap }: { cap: MockCapability }) {
  const { state, start, selectTier, reset } = useStaking(`panel-e5-${cap.id}`)
  const color = trustColor(cap.trustPct)
  const totalVol = (cap.forVault.total_assets + cap.againstVault.total_assets).toFixed(2)

  return (
    <div key={cap.id} style={{ display: 'flex', flexDirection: 'column', gap: 12, animation: 'slideInRight 0.18s ease' }}>
      <div>
        <div style={{ fontFamily: 'monospace', fontSize: 8, color: TEXT_FAINT, letterSpacing: '0.1em', marginBottom: 4 }}>EXPANDED VIEW</div>
        <div style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 900, color, textTransform: 'uppercase', letterSpacing: '0.03em' }}>{cap.name}</div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ position: 'relative', width: 56, height: 56 }}>
          <TrustRing percent={cap.trustPct} size={56} />
          <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <span style={{ fontFamily: 'monospace', fontSize: 12, fontWeight: 900, color }}>{cap.trustPct}%</span>
          </div>
        </div>
        <div>
          <div style={{ fontFamily: 'monospace', fontSize: 9, color: GREEN }}>FOR {cap.forVault.total_assets} TRUST · {cap.forVault.position_count} stakers</div>
          <div style={{ fontFamily: 'monospace', fontSize: 9, color: RED, marginTop: 3 }}>AGAINST {cap.againstVault.total_assets} TRUST · {cap.againstVault.position_count} stakers</div>
        </div>
      </div>

      {/* Fake price history */}
      <div style={{ background: '#0d0d14', border: `1px solid ${BORDER}`, borderRadius: 6, padding: '8px 10px' }}>
        <div style={{ fontFamily: 'monospace', fontSize: 8, color: TEXT_FAINT, letterSpacing: '0.1em', marginBottom: 4 }}>PRICE HISTORY</div>
        <div style={{ fontFamily: 'monospace', fontSize: 9, color: TEXT_FAINT, letterSpacing: '0.04em' }}>
          ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─
        </div>
        <div style={{ fontFamily: 'monospace', fontSize: 8, color: TEXT_FAINT, marginTop: 2 }}>VOL {totalVol} TRUST · SHARE {cap.forVault.current_share_price.toFixed(3)}</div>
      </div>

      <div style={{ borderTop: `1px solid ${BORDER}`, paddingTop: 10 }}>
        {state.step === 'confirmed' ? (
          <ConfirmedFlash direction={state.direction!} tier={state.tier!} />
        ) : state.step === 'tiers' ? (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
              <span style={{ fontFamily: 'monospace', fontSize: 10, color: state.direction === 'vouch' ? GREEN : RED, fontWeight: 700 }}>TIER:</span>
              <button type="button" onClick={reset} style={{ marginLeft: 'auto', background: 'none', border: 'none', color: TEXT_MUTED, cursor: 'pointer', fontSize: 12 }}>✕</button>
            </div>
            <ConvictionTiers direction={state.direction!} onSelect={selectTier} />
          </div>
        ) : (
          <div style={{ display: 'flex', gap: 8 }}>
            <button type="button" onClick={() => start('vouch')} style={{ flex: 1, padding: '7px', borderRadius: 6, border: `1px solid ${GREEN}45`, background: `${GREEN}10`, color: GREEN, fontFamily: 'monospace', fontSize: 11, fontWeight: 700, cursor: 'pointer' }}>VOUCH</button>
            <button type="button" onClick={() => start('deny')} style={{ flex: 1, padding: '7px', borderRadius: 6, border: `1px solid ${RED}45`, background: `${RED}10`, color: RED, fontFamily: 'monospace', fontSize: 11, fontWeight: 700, cursor: 'pointer' }}>DENY</button>
          </div>
        )}
      </div>
    </div>
  )
}

function VariationE5() {
  const [selectedId, setSelectedId] = useState<string>('code-generation')
  const selectedCap = MOCK_CAPABILITIES.find((c) => c.id === selectedId)!

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
      {/* Identity */}
      <div style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: '10px 10px 0 0', borderBottom: 'none', padding: '14px 16px', display: 'flex', alignItems: 'flex-start', gap: 12, flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, flex: 1, minWidth: 260 }}>
          <div style={{ width: 40, height: 40, borderRadius: '50%', background: `${PURPLE}20`, border: `2px solid ${PURPLE}50`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'monospace', fontSize: 18, fontWeight: 800, color: PURPLE, flexShrink: 0 }}>D</div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontFamily: 'monospace', fontSize: 16, fontWeight: 800, color: TEXT }}>{MOCK_AGENT.name}</span>
              <span style={{ fontFamily: 'monospace', fontSize: 9, color: PURPLE, background: `${PURPLE}18`, padding: '2px 5px', borderRadius: 4 }}>{MOCK_AGENT.version}</span>
            </div>
            <p style={{ fontFamily: 'monospace', fontSize: 10, color: TEXT_MUTED, margin: '3px 0 0' }}>{MOCK_AGENT.description}</p>
          </div>
        </div>
        {/* Polymarket-style entity trust widget */}
        <E5EntityTrust />
      </div>

      {/* Split panel */}
      <div style={{ display: 'flex', background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: '0 0 10px 10px', minHeight: 360, overflow: 'hidden' }}>
        <div style={{ flex: '0 0 60%', borderRight: `1px solid ${BORDER}` }}>
          <div style={{ fontFamily: 'monospace', fontSize: 8, fontWeight: 700, color: TEXT_FAINT, letterSpacing: '0.12em', padding: '8px 14px', borderBottom: `1px solid ${BORDER}`, textTransform: 'uppercase' }}>
            CAPABILITIES — STAKE DIRECTLY FROM LIST
          </div>
          {MOCK_CAPABILITIES.map((cap) => (
            <E5CapRow key={cap.id} cap={cap} isSelected={cap.id === selectedId} onSelect={() => setSelectedId(cap.id)} />
          ))}
        </div>
        <div style={{ flex: 1, padding: '14px 16px' }}>
          <E5Panel cap={selectedCap} />
        </div>
      </div>
    </div>
  )
}

// ── Variant wrapper ───────────────────────────────────────────────

function VariantWrapper({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ background: BG, borderRadius: 14, padding: 20, border: `1px solid ${BORDER}`, minHeight: 480 }}>
      {children}
    </div>
  )
}

// ── Route ─────────────────────────────────────────────────────────

export function meta() {
  return [
    { title: 'Design Lab — Side Panel E1–E5' },
    { name: 'robots', content: 'noindex' },
  ]
}

export default function DesignLab() {
  const [activeVariant, setActiveVariant] = useState<VariantId>('terminal')

  return (
    <div style={{ minHeight: '100vh', background: '#07070f', padding: '36px 24px', fontFamily: 'monospace' }}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>

        {/* Header */}
        <div style={{ marginBottom: 28 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            <div style={{ padding: '2px 8px', borderRadius: 5, background: `${PURPLE}18`, border: `1px solid ${PURPLE}35`, fontFamily: 'monospace', fontSize: 10, fontWeight: 700, color: PURPLE, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
              Design Lab
            </div>
            <div style={{ padding: '2px 8px', borderRadius: 5, background: 'hsl(38 92% 50% / 0.1)', border: '1px solid hsl(38 92% 50% / 0.25)', fontFamily: 'monospace', fontSize: 10, fontWeight: 600, color: 'hsl(38 92% 50%)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
              Variation E — Side Panel Sub-Variations
            </div>
          </div>

          <h1 style={{ fontFamily: 'monospace', fontSize: 22, fontWeight: 800, color: TEXT, margin: '0 0 6px', letterSpacing: '-0.02em' }}>
            Side Panel — 5 Refinements
          </h1>
          <p style={{ fontFamily: 'monospace', fontSize: 11, color: TEXT_MUTED, margin: 0, lineHeight: 1.7 }}>
            All 5 variants: entity trust ALWAYS visible in header. Split panel: capability list left, stake detail right.
            Entity trust = vouch/deny on the agent itself. Capability staking = clicking a row loads right panel.
          </p>
        </div>

        {/* Variant switcher */}
        <div style={{ display: 'flex', gap: 6, marginBottom: 24, flexWrap: 'wrap' }}>
          {VARIANTS.map((v) => {
            const isActive = activeVariant === v.id
            return (
              <button
                key={v.id}
                type="button"
                onClick={() => setActiveVariant(v.id)}
                style={{
                  padding: '7px 14px', borderRadius: 7,
                  border: `1px solid ${isActive ? PURPLE : BORDER}`,
                  background: isActive ? `${PURPLE}18` : CARD_BG,
                  color: isActive ? PURPLE : TEXT_MUTED,
                  fontFamily: 'monospace', fontSize: 11, fontWeight: 700,
                  cursor: 'pointer', letterSpacing: '0.04em', transition: 'all 0.15s ease',
                  boxShadow: isActive ? `0 0 10px ${PURPLE}20` : 'none',
                }}
              >
                {v.label}
              </button>
            )
          })}
        </div>

        {/* Active variant */}
        <VariantWrapper>
          {activeVariant === 'terminal' && <VariationE1 />}
          {activeVariant === 'neon-dashboard' && <VariationE2 />}
          {activeVariant === 'question-forward' && <VariationE3 />}
          {activeVariant === 'status-board' && <VariationE4 />}
          {activeVariant === 'prediction-market' && <VariationE5 />}
        </VariantWrapper>

        {/* Notes */}
        <div style={{ marginTop: 28, padding: '14px 18px', background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, fontFamily: 'monospace', fontSize: 11, color: TEXT_MUTED, lineHeight: 1.8 }}>
          <div style={{ fontWeight: 700, color: TEXT, marginBottom: 8, fontSize: 12, letterSpacing: '0.04em' }}>VARIATION NOTES</div>
          <ul style={{ margin: 0, paddingLeft: 16, display: 'flex', flexDirection: 'column', gap: 4 }}>
            <li><strong style={{ color: TEXT }}>E1 — Terminal Command</strong>: $ prompt style entity trust. Capability list with ●/◐/○ dots + block bar. Monospace ASCII everywhere. Tier panel on right.</li>
            <li><strong style={{ color: TEXT }}>E2 — Neon Dashboard</strong>: Compact TrustRing top-right. Capability cards with neon glow dots + border-left accent. Large ring in detail panel. Vault stats block.</li>
            <li><strong style={{ color: TEXT }}>E3 — Question Forward</strong>: Full-width "DO YOU TRUST?" block with centered ring + neon outlined buttons. Minimal cap list. Right panel mirrors bold question style.</li>
            <li><strong style={{ color: TEXT }}>E4 — Status Board</strong>: Status indicator (VERIFIED/UNVERIFIED/FLAGGED) in header. Table-style cap list with bar scores. Stake breakdown with block chars. Text-link vouch/deny.</li>
            <li><strong style={{ color: TEXT }}>E5 — Prediction Market</strong>: Polymarket-style compact entity trust card. Inline V/D buttons on each cap row that expand tiers in-place. Right panel is optional detail.</li>
          </ul>
        </div>

      </div>
    </div>
  )
}
