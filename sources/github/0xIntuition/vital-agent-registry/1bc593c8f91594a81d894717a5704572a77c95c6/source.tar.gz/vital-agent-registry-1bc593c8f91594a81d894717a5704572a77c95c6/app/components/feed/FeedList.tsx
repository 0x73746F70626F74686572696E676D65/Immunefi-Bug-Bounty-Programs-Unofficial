import type { ReactNode } from 'react'

interface FeedListProps {
  children: ReactNode
}

export function FeedList({ children }: FeedListProps) {
  return (
    <div className="flex flex-col items-center gap-4 p-4">
      {children}
    </div>
  )
}
