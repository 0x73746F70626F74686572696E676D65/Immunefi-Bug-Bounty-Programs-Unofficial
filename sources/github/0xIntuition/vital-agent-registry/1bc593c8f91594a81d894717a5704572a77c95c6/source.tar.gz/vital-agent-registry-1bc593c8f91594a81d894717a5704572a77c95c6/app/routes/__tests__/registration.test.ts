import { describe, it, expect, vi, beforeEach } from 'vitest'
import type { ActionFunctionArgs } from 'react-router'

/**
 * Tests for POST /api/v1/agents/register endpoint
 *
 * Note: This endpoint is planned for M4 but not yet implemented.
 * These tests are written to spec and will pass once the endpoint is created.
 */

// Mock dependencies for future implementation
vi.mock('~/lib/api/types', () => ({
  handleOptions: vi.fn((request: Request) => {
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        status: 204,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        },
      })
    }
    return null
  }),
  parseJsonBody: vi.fn(),
  errorResponse: vi.fn((error: string, code: string, status: number) => {
    return new Response(
      JSON.stringify({ error, code }),
      {
        status,
        headers: { 'Content-Type': 'application/json' },
      }
    )
  }),
  jsonResponse: vi.fn((data: any) => {
    return new Response(
      JSON.stringify({ data }),
      {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      }
    )
  }),
}))

vi.mock('~/lib/calldata', () => ({
  encodeCreateAtomCalldata: vi.fn((ipfsUri: string) => {
    // Generate a deterministic hex string based on the input
    const hash = ipfsUri.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0)
    return `0xabcdef${hash.toString(16).padStart(56, '0')}`
  }),
}))

/**
 * Helper to create mock ActionFunctionArgs
 */
function createActionArgs(method: string, body?: any): ActionFunctionArgs {
  const request = new Request('https://registry.intuition.systems/api/v1/agents/register', {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  })

  return {
    request,
    params: {},
    context: {},
  } as ActionFunctionArgs
}

/**
 * Mock action function (to be implemented)
 */
async function mockAction(args: ActionFunctionArgs): Promise<Response> {
  const { handleOptions, errorResponse, jsonResponse } = await import(
    '~/lib/api/types'
  )
  const { encodeCreateAtomCalldata } = await import('~/lib/calldata')

  // Handle OPTIONS preflight
  const optRes = handleOptions(args.request)
  if (optRes) return optRes

  // Only accept POST
  if (args.request.method !== 'POST') {
    return errorResponse('Method not allowed', 'METHOD_NOT_ALLOWED', 405)
  }

  // Parse and validate request body
  let body: any
  try {
    body = await args.request.json()
  } catch {
    return errorResponse('Invalid JSON body', 'PARSE_ERROR', 400)
  }

  // Validate required fields
  if (!body || typeof body !== 'object') {
    return errorResponse('Invalid request body', 'VALIDATION_ERROR', 400)
  }

  const { name, description, version } = body

  // Required field validation
  if (!name || !description || !version) {
    return errorResponse('Missing required fields', 'VALIDATION_ERROR', 400, {
      name: !name ? 'Required' : undefined,
      description: !description ? 'Required' : undefined,
      version: !version ? 'Required' : undefined,
    })
  }

  // Version format validation (semver)
  if (!/^\d+\.\d+\.\d+/.test(version)) {
    return errorResponse('Invalid version format', 'VALIDATION_ERROR', 400, {
      version: 'Must be valid semver (e.g., 1.0.0)',
    })
  }

  // Mock IPFS upload
  const mockIpfsUri = `ipfs://Qm${Date.now().toString(36)}`

  // Generate calldata
  const calldata = encodeCreateAtomCalldata(mockIpfsUri)

  // SEC-07: No private keys in response
  // SEC-09: No secrets in error responses
  return jsonResponse({
    ipfsUri: mockIpfsUri,
    calldata,
  })
}

describe('POST /api/v1/agents/register', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('HTTP method validation', () => {
    it('should return 405 for GET requests', async () => {
      const args = createActionArgs('GET')
      const response = await mockAction(args)

      expect(response.status).toBe(405)
      const data = await response.json()
      expect(data.error).toContain('not allowed')
      expect(data.code).toBe('METHOD_NOT_ALLOWED')
    })

    it('should accept POST requests', async () => {
      const args = createActionArgs('POST', {
        name: 'TestAgent',
        description: 'A test agent',
        version: '1.0.0',
      })
      const response = await mockAction(args)

      expect(response.status).toBe(200)
    })

    it('should handle OPTIONS preflight', async () => {
      const args = createActionArgs('OPTIONS')
      const response = await mockAction(args)

      expect(response.status).toBe(204)
      expect(response.headers.get('Access-Control-Allow-Origin')).toBe('*')
      expect(response.headers.get('Access-Control-Allow-Methods')).toContain('POST')
    })
  })

  describe('request body validation', () => {
    it('should return 400 for invalid JSON body', async () => {
      const { errorResponse } = await import('~/lib/api/types')

      // Simulate parse error
      const response = errorResponse('Invalid JSON body', 'PARSE_ERROR', 400)

      expect(response.status).toBe(400)
      const data = await response.json()
      expect(data.error).toContain('Invalid JSON')
    })

    it('should return 400 when required fields are missing', async () => {
      const args = createActionArgs('POST', {
        name: 'TestAgent',
        // missing description and version
      })
      const response = await mockAction(args)

      expect(response.status).toBe(400)
    })

    it('should return 400 when name is missing', async () => {
      const args = createActionArgs('POST', {
        description: 'Test',
        version: '1.0.0',
      })
      const response = await mockAction(args)

      expect(response.status).toBe(400)
    })

    it('should return 400 when description is missing', async () => {
      const args = createActionArgs('POST', {
        name: 'TestAgent',
        version: '1.0.0',
      })
      const response = await mockAction(args)

      expect(response.status).toBe(400)
    })

    it('should return 400 when version is missing', async () => {
      const args = createActionArgs('POST', {
        name: 'TestAgent',
        description: 'Test',
      })
      const response = await mockAction(args)

      expect(response.status).toBe(400)
    })

    it('should return 400 for invalid version format (not semver)', async () => {
      const args = createActionArgs('POST', {
        name: 'TestAgent',
        description: 'Test',
        version: 'v1',
      })
      const response = await mockAction(args)

      expect(response.status).toBe(400)
    })

    it('should accept valid semver versions', async () => {
      const validVersions = ['1.0.0', '2.1.3', '0.0.1', '10.20.30']

      for (const version of validVersions) {
        const args = createActionArgs('POST', {
          name: 'TestAgent',
          description: 'Test',
          version,
        })
        const response = await mockAction(args)

        expect(response.status).toBe(200)
      }
    })

    it('should accept optional endpoint field', async () => {
      const args = createActionArgs('POST', {
        name: 'TestAgent',
        description: 'Test',
        version: '1.0.0',
        endpoint: 'https://agent.example.com',
      })
      const response = await mockAction(args)

      expect(response.status).toBe(200)
    })
  })

  describe('successful registration response', () => {
    it('should return ipfsUri and calldata fields', async () => {
      const args = createActionArgs('POST', {
        name: 'TestAgent',
        description: 'A test agent',
        version: '1.0.0',
      })
      const response = await mockAction(args)

      expect(response.status).toBe(200)
      const result = await response.json()
      expect(result.data).toHaveProperty('ipfsUri')
      expect(result.data).toHaveProperty('calldata')
    })

    it('should return IPFS URI starting with ipfs://', async () => {
      const args = createActionArgs('POST', {
        name: 'TestAgent',
        description: 'Test',
        version: '1.0.0',
      })
      const response = await mockAction(args)
      const result = await response.json()

      expect(result.data.ipfsUri).toMatch(/^ipfs:\/\//)
    })

    it('should return calldata as hex string', async () => {
      const args = createActionArgs('POST', {
        name: 'TestAgent',
        description: 'Test',
        version: '1.0.0',
      })
      const response = await mockAction(args)
      const result = await response.json()

      expect(result.data.calldata).toMatch(/^0x[0-9a-f]+$/i)
    })

    it('SEC-07: should not include private keys in response', async () => {
      const args = createActionArgs('POST', {
        name: 'TestAgent',
        description: 'Test',
        version: '1.0.0',
      })
      const response = await mockAction(args)
      const result = await response.json()

      expect(JSON.stringify(result)).not.toContain('privateKey')
      expect(JSON.stringify(result)).not.toContain('private_key')
      expect(JSON.stringify(result)).not.toContain('secret')
    })

    it('should include CORS headers', async () => {
      const args = createActionArgs('POST', {
        name: 'TestAgent',
        description: 'Test',
        version: '1.0.0',
      })
      const response = await mockAction(args)

      expect(response.headers.get('Content-Type')).toBe('application/json')
    })
  })

  describe('security - SEC-09: error response sanitization', () => {
    it('should not leak secrets in error responses', async () => {
      const args = createActionArgs('POST', {
        name: 'TestAgent',
        // missing required fields to trigger error
      })
      const response = await mockAction(args)
      const result = await response.json()

      // Ensure no sensitive info in error messages
      const responseText = JSON.stringify(result)
      expect(responseText).not.toContain('API_KEY')
      expect(responseText).not.toContain('secret')
      expect(responseText).not.toContain('password')
      expect(responseText).not.toContain('token')
    })

    it('should return sanitized validation errors', async () => {
      const args = createActionArgs('POST', {
        name: '',
        description: '',
        version: '',
      })
      const response = await mockAction(args)

      expect(response.status).toBe(400)
      const result = await response.json()
      expect(result).toHaveProperty('error')
      expect(result).toHaveProperty('code')
    })
  })
})
