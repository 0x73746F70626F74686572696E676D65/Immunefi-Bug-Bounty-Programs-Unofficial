import { Bookmark } from 'lucide-react'
import { useSavedEntities } from '~/lib/hooks/useSavedEntities'
import { cn } from '~/lib/utils'

interface SaveButtonProps {
  entityId: string
  entityType: 'agent' | 'skill'
  className?: string
}

export function SaveButton({ entityId, entityType, className }: SaveButtonProps) {
  const { toggle, isSaved } = useSavedEntities()
  const saved = isSaved(entityId)

  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation()
        e.preventDefault()
        toggle(entityId, entityType)
      }}
      className={cn(
        'p-1.5 rounded-md transition-colors',
        saved
          ? 'text-brand bg-brand/10 hover:bg-brand/20'
          : 'text-muted-foreground hover:text-foreground hover:bg-muted',
        className,
      )}
      title={saved ? 'Remove from saved' : 'Save'}
      aria-label={saved ? 'Remove from saved' : 'Save'}
    >
      <Bookmark className={cn('h-4 w-4', saved && 'fill-current')} />
    </button>
  )
}
