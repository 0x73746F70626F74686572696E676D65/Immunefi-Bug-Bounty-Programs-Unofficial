import { buildEvidenceId, evidenceBundleSchema, type EvidenceBundle } from './schema'

const evidenceStore = new Map<string, EvidenceBundle>()

export function saveEvidenceBundle(payload: Omit<EvidenceBundle, 'id'>): EvidenceBundle {
  const id = buildEvidenceId(payload)
  const bundle = evidenceBundleSchema.parse({ id, ...payload })
  evidenceStore.set(id, bundle)
  return bundle
}

export function getEvidenceBundle(id: string): EvidenceBundle | null {
  return evidenceStore.get(id) ?? null
}

export function clearEvidenceStore(): void {
  evidenceStore.clear()
}
