import type { Agent, AgentCard, AgentMetadata } from './agent'
import type { Skill, SkillMetadata } from './skill'
import type { Capability } from './capability'
import type { PredicateDefinition } from './predicate'
import type { Platform } from './platform'
import type { TrustSignal, TrustTier } from './vault'

/**
 * SortField — sorting options for entity queries
 */
export type SortField = 'trust' | 'name' | 'recent' | 'stakers' | 'safety'

/**
 * EntityType — types that can have metadata
 */
export type EntityType = 'agent' | 'skill'

/**
 * RegistryRepository — unified repository interface for agents AND skills
 *
 * This interface abstracts data access for both entity types.
 * Implementations can be mock (static data) or GraphQL (protocol queries).
 */
export interface RegistryRepository {
  // Agent methods

  /** Find a single agent by ID */
  findAgent(id: string): Promise<Agent | null>

  /** Search agents by text query */
  searchAgents(query: string, options?: SearchOptions): Promise<Agent[]>

  /** List agents with filtering and pagination */
  listAgents(options?: ListOptions): Promise<PaginatedResult<Agent>>

  /** Find agents matching required capabilities */
  matchAgentCapabilities(
    required: string[],
    options?: MatchOptions
  ): Promise<Agent[]>

  /** Get A2A agent card for an agent */
  getAgentCard(id: string): Promise<AgentCard | null>

  /** Get trust signal for an agent */
  getAgentTrust(id: string): Promise<TrustSignal | null>

  // Skill methods

  /** Find a single skill by ID */
  findSkill(id: string): Promise<Skill | null>

  /** Search skills by text query */
  searchSkills(query: string, options?: SearchOptions): Promise<Skill[]>

  /** List skills with filtering and pagination */
  listSkills(options?: ListOptions): Promise<PaginatedResult<Skill>>

  /** Get all skills for a specific platform */
  getSkillsByPlatform(platformId: string): Promise<Skill[]>

  /** Get skills used by a specific agent (via uses triples) */
  getSkillsForAgent(agentId: string): Promise<Skill[]>

  /** Get trust signal for a skill */
  getSkillTrust(id: string): Promise<TrustSignal | null>

  // Metadata resolution methods

  /** Resolve current metadata using trust-weighted resolution (highest FOR stake wins, fallback to recent) */
  resolveCurrentMetadata(
    entityType: EntityType,
    entityId: string
  ): Promise<AgentMetadata | SkillMetadata | null>

  // Shared metadata

  /** List all available capabilities */
  listCapabilities(): Promise<Capability[]>

  /** List all canonical predicates */
  listPredicates(): Promise<PredicateDefinition[]>

  /** List all platforms */
  listPlatforms(): Promise<Platform[]>
}

/**
 * SearchOptions — options for text-based search queries
 */
export interface SearchOptions {
  /** Filter by capability IDs */
  capabilities?: string[]
  /** Minimum trust tier (agents) */
  minTrustTier?: TrustTier
  /** Filter by platform ID (skills only) */
  platformId?: string
  /** Sort order */
  sortBy?: SortField
  /** Max results */
  limit?: number
  /** Offset for pagination */
  offset?: number
}

/**
 * ListOptions — options for listing entities with filters
 */
export interface ListOptions {
  /** Filter by capability */
  capability?: string
  /** Filter by trust tier */
  trustTier?: TrustTier
  /** Filter by platform (skills) */
  platformId?: string
  /** Sort order */
  sortBy?: SortField
  /** Max results (default 20) */
  limit?: number
  /** Offset for pagination */
  offset?: number
}

/**
 * MatchOptions — options for capability matching queries
 */
export interface MatchOptions {
  /** true = AND (all required), false = OR (any match). Default: true */
  matchAll?: boolean
  /** Minimum trust tier */
  minTrustTier?: TrustTier
  /** Max results */
  limit?: number
}

/**
 * PaginatedResult — paginated query results
 */
export interface PaginatedResult<T> {
  /** Result items */
  items: T[]
  /** Total count (for pagination UI) */
  total: number
  /** Whether more results exist */
  hasMore: boolean
}
