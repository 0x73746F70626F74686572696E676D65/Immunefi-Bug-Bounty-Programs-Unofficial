import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { PublicClient, WalletClient } from 'viem';
import { parseEther } from 'viem';
import { registerEntityStep1, registerEntityStep2 } from '../registration';
import * as ipfsModule from '../ipfs';
import * as multivaultModule from '../multivault';

// Mock dependencies
vi.mock('../ipfs');
vi.mock('../multivault');

const createMockPublicClient = (): PublicClient => {
  return {} as PublicClient;
};

const createMockWalletClient = (): WalletClient => {
  return {
    account: { address: '0x1234567890123456789012345678901234567890' } as any,
    chain: { id: 13579 } as any,
  } as WalletClient;
};

const TEST_CONTRACT_ADDRESS = '0xB92EA1B47E4ABD0a520E9138BB59dBd1bC6C475B' as const;

describe('registration', () => {
  let mockPublicClient: PublicClient;
  let mockWalletClient: WalletClient;

  beforeEach(() => {
    vi.resetAllMocks();
    mockPublicClient = createMockPublicClient();
    mockWalletClient = createMockWalletClient();
  });

  describe('registerEntityStep1', () => {
    it('should upload agent metadata and create atom', async () => {
      const mockIpfsUri = 'ipfs://QmTestAgent';
      const mockHash = '0xatomhash' as const;

      vi.spyOn(ipfsModule, 'uploadAgentMetadata').mockResolvedValue(mockIpfsUri);
      vi.spyOn(multivaultModule, 'createAtoms').mockResolvedValue({
        hash: mockHash,
        atomCount: 1,
      });

      const agentMetadata = {
        '@type': 'Agent' as const,
        name: 'Test Agent',
        description: 'A test agent',
        version: '1.0.0',
      };

      const result = await registerEntityStep1(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        agentMetadata,
        parseEther('0.1')
      );

      expect(result.ipfsUri).toBe(mockIpfsUri);
      expect(result.atomHash).toBe(mockHash);

      expect(ipfsModule.uploadAgentMetadata).toHaveBeenCalledWith(agentMetadata);
      expect(multivaultModule.createAtoms).toHaveBeenCalledWith(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        [mockIpfsUri],
        parseEther('0.1')
      );
    });

    it('should upload skill metadata and create atom', async () => {
      const mockIpfsUri = 'ipfs://QmTestSkill';
      const mockHash = '0xskillhash' as const;

      vi.spyOn(ipfsModule, 'uploadSkillMetadata').mockResolvedValue(mockIpfsUri);
      vi.spyOn(multivaultModule, 'createAtoms').mockResolvedValue({
        hash: mockHash,
        atomCount: 1,
      });

      const skillMetadata = {
        '@type': 'Skill' as const,
        name: 'Test Skill',
        description: 'A test skill',
        version: '2.0.0',
        platform: 'mcp' as const,
      };

      const result = await registerEntityStep1(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        skillMetadata,
        parseEther('0.1')
      );

      expect(result.ipfsUri).toBe(mockIpfsUri);
      expect(result.atomHash).toBe(mockHash);

      expect(ipfsModule.uploadSkillMetadata).toHaveBeenCalledWith(skillMetadata);
    });

    it('should propagate upload errors', async () => {
      vi.spyOn(ipfsModule, 'uploadAgentMetadata').mockRejectedValue(
        new Error('Upload failed')
      );

      const agentMetadata = {
        '@type': 'Agent' as const,
        name: 'Test',
        description: 'Test',
        version: '1.0.0',
      };

      await expect(
        registerEntityStep1(
          mockPublicClient,
          mockWalletClient,
          TEST_CONTRACT_ADDRESS,
          agentMetadata,
          parseEther('0.1')
        )
      ).rejects.toThrow('Upload failed');
    });

    it('should propagate atom creation errors', async () => {
      vi.spyOn(ipfsModule, 'uploadAgentMetadata').mockResolvedValue('ipfs://QmTest');
      vi.spyOn(multivaultModule, 'createAtoms').mockRejectedValue(
        new Error('Transaction failed')
      );

      const agentMetadata = {
        '@type': 'Agent' as const,
        name: 'Test',
        description: 'Test',
        version: '1.0.0',
      };

      await expect(
        registerEntityStep1(
          mockPublicClient,
          mockWalletClient,
          TEST_CONTRACT_ADDRESS,
          agentMetadata,
          parseEther('0.1')
        )
      ).rejects.toThrow('Transaction failed');
    });
  });

  describe('registerEntityStep2', () => {
    beforeEach(() => {
      // Mock PREDICATES import - v3 predicates
      vi.doMock('~/lib/constants/protocol', () => ({
        PREDICATES: {
          IS: '0x_is',
          HAS_CAPABILITY: '0x_has_capability',
          USES: '0x_uses',
          HAS_METADATA: '0x_has_metadata',
          CREATED_BY: '0x_created_by',
        },
      }));
    });

    it('should create IS_TYPE triple for agent', async () => {
      const mockHash = '0xtriplehash' as const;
      vi.spyOn(multivaultModule, 'createTriples').mockResolvedValue({
        hash: mockHash,
        tripleCount: 1,
      });

      const result = await registerEntityStep2(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        '123456', // entityTermId
        'Agent',
        {
          typeAtomId: 'agent_type_id',
        },
        parseEther('0.05')
      );

      expect(result.tripleHash).toBe(mockHash);
      expect(result.tripleCount).toBe(1);

      const triplesArg = (multivaultModule.createTriples as any).mock.calls[0][3];
      expect(triplesArg).toHaveLength(1);
      expect(triplesArg[0]).toMatchObject({
        subjectId: '123456',
        objectId: 'agent_type_id',
      });
    });

    it('should create HAS_CAPABILITY triples for agent', async () => {
      const mockHash = '0xtriplehash' as const;
      vi.spyOn(multivaultModule, 'createTriples').mockResolvedValue({
        hash: mockHash,
        tripleCount: 3,
      });

      await registerEntityStep2(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        '123456',
        'Agent',
        {
          typeAtomId: 'agent_type_id',
          capabilities: ['cap1', 'cap2'],
        },
        parseEther('0.05')
      );

      const triplesArg = (multivaultModule.createTriples as any).mock.calls[0][3];
      // IS_TYPE + 2 HAS_CAPABILITY
      expect(triplesArg).toHaveLength(3);

      const capTriples = triplesArg.filter((t: any) => t.objectId === 'cap1' || t.objectId === 'cap2');
      expect(capTriples).toHaveLength(2);
    });

    it('should create USES_SKILL triples for agent', async () => {
      const mockHash = '0xtriplehash' as const;
      vi.spyOn(multivaultModule, 'createTriples').mockResolvedValue({
        hash: mockHash,
        tripleCount: 3,
      });

      await registerEntityStep2(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        '123456',
        'Agent',
        {
          typeAtomId: 'agent_type_id',
          skills: ['skill1', 'skill2'],
        },
        parseEther('0.05')
      );

      const triplesArg = (multivaultModule.createTriples as any).mock.calls[0][3];
      // IS_TYPE + 2 USES_SKILL
      expect(triplesArg).toHaveLength(3);

      const skillTriples = triplesArg.filter((t: any) => t.objectId === 'skill1' || t.objectId === 'skill2');
      expect(skillTriples).toHaveLength(2);
    });

    it('should create PROVIDES_CAPABILITY triples for skill', async () => {
      const mockHash = '0xtriplehash' as const;
      vi.spyOn(multivaultModule, 'createTriples').mockResolvedValue({
        hash: mockHash,
        tripleCount: 2,
      });

      await registerEntityStep2(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        '789',
        'Skill',
        {
          typeAtomId: 'skill_type_id',
          capabilities: ['cap1'],
        },
        parseEther('0.05')
      );

      const triplesArg = (multivaultModule.createTriples as any).mock.calls[0][3];
      // IS_TYPE + 1 PROVIDES_CAPABILITY
      expect(triplesArg).toHaveLength(2);

      const capTriple = triplesArg.find((t: any) => t.objectId === 'cap1');
      expect(capTriple).toBeTruthy();
    });

    it('should create IS triple for skill with platform (platform in metadata)', async () => {
      const mockHash = '0xtriplehash' as const;
      vi.spyOn(multivaultModule, 'createTriples').mockResolvedValue({
        hash: mockHash,
        tripleCount: 1,
      });

      await registerEntityStep2(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        '789',
        'Skill',
        {
          typeAtomId: 'skill_type_id',
          platformId: 'mcp_platform_id',
        },
        parseEther('0.05')
      );

      const triplesArg = (multivaultModule.createTriples as any).mock.calls[0][3];
      // v3: Only IS triple - platform info is in metadata (IPFS), not a BELONGS_TO triple
      expect(triplesArg).toHaveLength(1);

      // Verify IS triple exists
      const isTriple = triplesArg.find((t: any) => t.predicateId === '0x_is');
      expect(isTriple).toBeTruthy();
      expect(isTriple.objectId).toBe('skill_type_id');
    });

    it('should create complex agent with all relationships', async () => {
      const mockHash = '0xtriplehash' as const;
      vi.spyOn(multivaultModule, 'createTriples').mockResolvedValue({
        hash: mockHash,
        tripleCount: 6,
      });

      await registerEntityStep2(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        '123',
        'Agent',
        {
          typeAtomId: 'agent_type',
          capabilities: ['cap1', 'cap2'],
          skills: ['skill1', 'skill2', 'skill3'],
        },
        parseEther('0.05')
      );

      const triplesArg = (multivaultModule.createTriples as any).mock.calls[0][3];
      // IS_TYPE + 2 capabilities + 3 skills = 6 triples
      expect(triplesArg).toHaveLength(6);
    });

    it('should handle entity with no optional relationships', async () => {
      const mockHash = '0xtriplehash' as const;
      vi.spyOn(multivaultModule, 'createTriples').mockResolvedValue({
        hash: mockHash,
        tripleCount: 1,
      });

      await registerEntityStep2(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        '123',
        'Agent',
        {
          typeAtomId: 'agent_type',
          // No capabilities or skills
        },
        parseEther('0.05')
      );

      const triplesArg = (multivaultModule.createTriples as any).mock.calls[0][3];
      // Only IS_TYPE triple
      expect(triplesArg).toHaveLength(1);
    });

    it('should propagate triple creation errors', async () => {
      vi.spyOn(multivaultModule, 'createTriples').mockRejectedValue(
        new Error('Triple creation failed')
      );

      await expect(
        registerEntityStep2(
          mockPublicClient,
          mockWalletClient,
          TEST_CONTRACT_ADDRESS,
          '123',
          'Agent',
          { typeAtomId: 'type' },
          parseEther('0.05')
        )
      ).rejects.toThrow('Triple creation failed');
    });
  });

  describe('two-step flow integration', () => {
    it('should complete full registration flow', async () => {
      // Step 1 mocks
      vi.spyOn(ipfsModule, 'uploadAgentMetadata').mockResolvedValue('ipfs://QmAgent');
      vi.spyOn(multivaultModule, 'createAtoms').mockResolvedValue({
        hash: '0xatomhash',
        atomCount: 1,
      });

      // Step 2 mocks
      vi.spyOn(multivaultModule, 'createTriples').mockResolvedValue({
        hash: '0xtriplehash',
        tripleCount: 2,
      });

      const agentMetadata = {
        '@type': 'Agent' as const,
        name: 'Full Flow Agent',
        description: 'Test',
        version: '1.0.0',
      };

      // Step 1: Upload + create atom
      const step1Result = await registerEntityStep1(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        agentMetadata,
        parseEther('0.1')
      );

      expect(step1Result.ipfsUri).toBe('ipfs://QmAgent');
      expect(step1Result.atomHash).toBe('0xatomhash');

      // Simulate indexer confirmation and getting termId
      const atomTermId = '123456789';

      // Step 2: Create relationships
      const step2Result = await registerEntityStep2(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        atomTermId,
        'Agent',
        {
          typeAtomId: 'agent_type',
          capabilities: ['cap1'],
        },
        parseEther('0.05')
      );

      expect(step2Result.tripleHash).toBe('0xtriplehash');
      expect(step2Result.tripleCount).toBe(2);
    });
  });
});
