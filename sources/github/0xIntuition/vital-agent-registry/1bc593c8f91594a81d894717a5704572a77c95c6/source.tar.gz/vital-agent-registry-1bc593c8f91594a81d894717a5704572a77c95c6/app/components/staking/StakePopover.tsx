import { useState, useEffect, useRef, useCallback } from 'react'
import { useAccount } from 'wagmi'
import { formatEther } from 'viem'
import type { Triple } from '~/types'
import type { NetworkId } from '~/lib/constants/protocol'
import { useStakeTransaction } from '~/lib/hooks/useStakeTransaction'
import { useDepositPreview } from '~/lib/hooks/useDepositPreview'
import { useTransactionToast } from '~/components/staking/TransactionToast'
import { formatWeiToEth } from '~/lib/vault-utils'
import { cn } from '~/lib/utils'

// ── Types ─────────────────────────────────────────────────────────

type Direction = 'support' | 'oppose'
type FlowStep = 'direction' | 'amount' | 'confirm' | 'pending' | 'done'

interface TierConfig {
  amount: string
  label: string
}

// ── Constants ─────────────────────────────────────────────────────

const TIERS: TierConfig[] = [
  { amount: '0.01', label: 'NUDGE' },
  { amount: '0.05', label: 'SIGNAL' },
  { amount: '0.25', label: 'STRONG' },
  { amount: '1.00', label: 'CONVICTION' },
]

const STEP_LABELS = ['DIRECTION', 'AMOUNT', 'CONFIRM'] as const
const STEP_INDICES: Record<FlowStep, number> = {
  direction: 0,
  amount: 1,
  confirm: 2,
  pending: 2,
  done: 3,
}

const GREEN = 'hsl(142 71% 45%)'
const RED = 'hsl(0 84% 60%)'

// ── Sub-components ────────────────────────────────────────────────

interface ProgressDotsProps {
  step: FlowStep
  direction: Direction
  /** When true, the DIRECTION step is always shown as already complete */
  directionPreset?: boolean
}

function ProgressDots({ step, direction, directionPreset }: ProgressDotsProps) {
  if (step === 'done') return null

  const accentColor = direction === 'support' ? GREEN : RED
  const stepIndex = STEP_INDICES[step]

  // When direction is preset, visually offset so step 0 (DIRECTION) always appears filled
  const effectiveIndex = directionPreset ? Math.max(stepIndex, 0) : stepIndex
  const isDotFilled = (i: number) =>
    directionPreset ? i <= effectiveIndex : i <= stepIndex
  const isLineFilled = (i: number) =>
    directionPreset ? i < effectiveIndex : i < stepIndex

  return (
    <div className="flex items-center mb-3">
      {STEP_LABELS.map((label, i) => (
        <div
          key={label}
          className="flex items-center"
          style={{ flex: i < STEP_LABELS.length - 1 ? 1 : 0 }}
        >
          <div className="flex flex-col items-center gap-[2px]">
            <div
              style={{
                width: i === stepIndex ? 8 : 7,
                height: i === stepIndex ? 8 : 7,
                borderRadius: '50%',
                background: isDotFilled(i) ? accentColor : 'hsl(var(--app-line))',
                transition: 'background 0.2s ease, box-shadow 0.2s ease',
                boxShadow: i === stepIndex ? `0 0 8px ${accentColor}` : 'none',
              }}
            />
            <span
              className="font-mono tracking-widest whitespace-nowrap"
              style={{
                fontSize: 9,
                color: isDotFilled(i) ? 'hsl(var(--ink-dull))' : 'hsl(var(--ink-faint))',
                letterSpacing: '0.08em',
              }}
            >
              {label}
            </span>
          </div>
          {i < STEP_LABELS.length - 1 && (
            <div
              style={{
                flex: 1,
                height: 1,
                background: isLineFilled(i) ? accentColor : 'hsl(var(--app-line))',
                margin: '0 4px',
                marginBottom: 14,
                transition: 'background 0.3s ease',
              }}
            />
          )}
        </div>
      ))}
    </div>
  )
}

// ── Step: Direction ───────────────────────────────────────────────

interface DirectionStepProps {
  onSelect: (dir: Direction) => void
  capabilityName?: string
}

function DirectionStep({ onSelect, capabilityName }: DirectionStepProps) {
  return (
    <div>
      {capabilityName && (
        <div className="font-mono text-[10px] tracking-widest uppercase text-ink-faint mb-2">
          HAS {capabilityName.toUpperCase()}?
        </div>
      )}
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => onSelect('support')}
          className="flex flex-1 items-center justify-center gap-1.5 rounded-lg px-3 py-2.5 font-mono text-xs font-bold tracking-widest transition-colors"
          style={{
            border: '1px solid hsl(142 71% 45% / 0.35)',
            background: 'hsl(142 71% 45% / 0.08)',
            color: GREEN,
          }}
        >
          <span className="text-sm">▲</span> VOUCH
        </button>
        <button
          type="button"
          onClick={() => onSelect('oppose')}
          className="flex flex-1 items-center justify-center gap-1.5 rounded-lg px-3 py-2.5 font-mono text-xs font-bold tracking-widest transition-colors"
          style={{
            border: '1px solid hsl(0 84% 60% / 0.35)',
            background: 'hsl(0 84% 60% / 0.08)',
            color: RED,
          }}
        >
          <span className="text-sm">▼</span> DENY
        </button>
      </div>
    </div>
  )
}

// ── Step: Amount ──────────────────────────────────────────────────

interface AmountStepProps {
  direction: Direction
  selectedAmount: string
  onSelect: (amount: string) => void
}

function AmountStep({ direction, selectedAmount, onSelect }: AmountStepProps) {
  const accentColor = direction === 'support' ? GREEN : RED

  return (
    <div className="flex gap-1.5">
      {TIERS.map((tier) => {
        const isSelected = selectedAmount === tier.amount
        return (
          <button
            key={tier.amount}
            type="button"
            onClick={() => onSelect(tier.amount)}
            className="flex flex-1 flex-col items-center gap-0.5 rounded-lg px-1 py-2 transition-all"
            style={{
              border: `1px solid ${isSelected ? accentColor : 'hsl(var(--app-line))'}`,
              background: isSelected ? `${accentColor}18` : 'hsl(var(--app-box-dark))',
              color: isSelected ? accentColor : 'hsl(var(--ink-default))',
            }}
          >
            <span className="font-mono text-xs font-bold">{tier.amount}</span>
            <span
              className="font-mono tracking-widest"
              style={{ fontSize: 8, color: 'hsl(var(--ink-faint))' }}
            >
              {tier.label}
            </span>
          </button>
        )
      })}
    </div>
  )
}

// ── Step: Confirm ─────────────────────────────────────────────────

interface ConfirmStepProps {
  direction: Direction
  amount: string
  capabilityName: string
  fees: bigint
  shares: bigint
  previewLoading: boolean
  isBusy: boolean
  onBack: () => void
  onConfirm: () => void
}

function ConfirmStep({
  direction,
  amount,
  capabilityName,
  fees,
  shares,
  previewLoading,
  isBusy,
  onBack,
  onConfirm,
}: ConfirmStepProps) {
  const accentColor = direction === 'support' ? GREEN : RED
  const dirLabel = direction === 'support' ? 'vouching' : 'denying'

  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 min-w-0">
        <div className="font-mono text-[10px] tracking-widest text-ink-faint mb-0.5">
          STAKING
        </div>
        <div
          className="font-mono text-lg font-bold leading-tight"
          style={{ color: accentColor }}
        >
          {amount} TRUST
        </div>
        <div className="font-mono text-[10px] text-ink-faint truncate">
          {dirLabel} · {capabilityName}
        </div>
        {/* Fee preview */}
        <div className="font-mono mt-1" style={{ fontSize: 10, color: 'hsl(var(--ink-faint))' }}>
          {previewLoading ? (
            <span className="animate-pulse">CALCULATING...</span>
          ) : shares > 0n ? (
            <span>
              FEE: {formatEther(fees)} TRUST · SHARES: {parseFloat(formatEther(shares)).toFixed(4)}
            </span>
          ) : null}
        </div>
      </div>

      <button
        type="button"
        onClick={onBack}
        disabled={isBusy}
        className="flex-shrink-0 rounded-lg border border-app-line bg-transparent px-2.5 py-2 font-mono text-xs text-ink-faint transition-colors hover:text-ink-dull disabled:opacity-50"
      >
        ←
      </button>

      <button
        type="button"
        onClick={onConfirm}
        disabled={isBusy}
        className="flex-shrink-0 rounded-lg px-3.5 py-2 font-mono text-xs font-bold text-white transition-colors disabled:opacity-50"
        style={{
          background: accentColor,
          boxShadow: `0 3px 12px ${accentColor}40`,
        }}
      >
        STAKE →
      </button>
    </div>
  )
}

// ── Step: Pending ─────────────────────────────────────────────────

interface PendingStepProps {
  awaitingWalletConfirmation: boolean
  awaitingOnChainConfirmation: boolean
  amount: string
  direction: Direction
}

function PendingStep({
  awaitingWalletConfirmation,
  awaitingOnChainConfirmation,
  amount,
  direction,
}: PendingStepProps) {
  const accentColor = direction === 'support' ? GREEN : RED
  const statusText = awaitingWalletConfirmation
    ? 'CONFIRM IN WALLET'
    : awaitingOnChainConfirmation
      ? 'AWAITING CHAIN...'
      : 'PROCESSING...'

  return (
    <div className="flex items-center gap-3 py-1">
      <div
        className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full"
        style={{
          background: `${accentColor}18`,
          border: `1.5px solid ${accentColor}60`,
        }}
      >
        <span
          className="font-mono text-sm animate-pulse"
          style={{ color: accentColor }}
        >
          ···
        </span>
      </div>
      <div className="flex-1 min-w-0">
        <div
          className="font-mono text-xs font-bold tracking-widest animate-pulse"
          style={{ color: accentColor }}
        >
          {statusText}
        </div>
        <div className="font-mono text-[10px] text-ink-faint mt-0.5">
          {amount} TRUST · {direction === 'support' ? 'VOUCH' : 'DENY'}
        </div>
      </div>
    </div>
  )
}

// ── Step: Done ────────────────────────────────────────────────────

interface DoneStepProps {
  txHash?: string
  amount: string
  network: NetworkId
  onClose: () => void
}

function DoneStep({ txHash, amount, network, onClose }: DoneStepProps) {
  const explorerBase =
    network === 'testnet'
      ? 'https://testnet.explorer.intuition.systems'
      : 'https://explorer.intuition.systems'

  return (
    <div className="flex items-center gap-3 py-1">
      <div
        className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full"
        style={{
          background: 'hsl(142 71% 45% / 0.15)',
          border: '1.5px solid hsl(142 71% 45% / 0.4)',
        }}
      >
        <span className="font-mono text-base" style={{ color: GREEN }}>✓</span>
      </div>
      <div className="flex-1 min-w-0">
        <div className="font-mono text-xs font-bold tracking-widest" style={{ color: GREEN }}>
          STAKED
        </div>
        <div className="font-mono text-[10px] text-ink-faint mt-0.5">
          {amount} TRUST ·{' '}
          {txHash && network !== 'local' ? (
            <a
              href={`${explorerBase}/tx/${txHash}`}
              target="_blank"
              rel="noopener noreferrer"
              className="underline"
              style={{ color: GREEN }}
            >
              VIEW TX
            </a>
          ) : (
            <span className="font-mono break-all">{txHash?.slice(0, 12)}...</span>
          )}
        </div>
      </div>
      <button
        type="button"
        onClick={onClose}
        className="flex-shrink-0 bg-transparent border-none font-mono text-xs text-ink-faint cursor-pointer p-0 hover:text-ink-dull transition-colors"
      >
        ✕
      </button>
    </div>
  )
}

// ── Vault Stats Bar ───────────────────────────────────────────────

interface VaultStatsProps {
  triple: Triple
}

function VaultStats({ triple }: VaultStatsProps) {
  if (!triple.vault) return null

  const forTvl = triple.vault.forVault
    ? formatWeiToEth(triple.vault.forVault.total_assets, 3)
    : '0'
  const againstTvl = triple.vault.againstVault
    ? formatWeiToEth(triple.vault.againstVault.total_assets, 3)
    : '0'
  const forStakers = triple.vault.forVault?.position_count ?? 0
  const againstStakers = triple.vault.againstVault?.position_count ?? 0

  return (
    <div
      className="mt-2.5 flex items-center gap-3 border-t border-app-line pt-2"
    >
      <div className="flex items-center gap-1 font-mono" style={{ fontSize: 9 }}>
        <div
          className="h-1.5 w-1.5 rounded-full"
          style={{ background: GREEN }}
        />
        <span className="text-ink-faint">
          FOR: {forTvl} TRUST ({forStakers})
        </span>
      </div>
      <div className="flex items-center gap-1 font-mono" style={{ fontSize: 9 }}>
        <div
          className="h-1.5 w-1.5 rounded-full"
          style={{ background: RED }}
        />
        <span className="text-ink-faint">
          AGAINST: {againstTvl} TRUST ({againstStakers})
        </span>
      </div>
    </div>
  )
}

// ── Main Component ────────────────────────────────────────────────

export interface StakePopoverProps {
  triple: Triple
  trigger: React.ReactNode
  className?: string
  /** Pre-select a direction, skipping the direction step entirely */
  presetDirection?: 'for' | 'against'
  /** Override the label shown in direction step and confirm step */
  contextLabel?: string
  onStakeSuccess?: (txHash: string) => void
}

export function StakePopover({
  triple,
  trigger,
  className,
  presetDirection,
  contextLabel,
  onStakeSuccess,
}: StakePopoverProps) {
  const { isConnected } = useAccount()
  const { addTransaction } = useTransactionToast()

  // Map preset direction to internal Direction type
  const initialDirection: Direction =
    presetDirection === 'against' ? 'oppose' : 'support'

  const [open, setOpen] = useState(false)
  // When presetDirection is provided, start at 'amount' — direction is already known
  const [step, setStep] = useState<FlowStep>(presetDirection ? 'amount' : 'direction')
  const [direction, setDirection] = useState<Direction>(initialDirection)
  const [selectedAmount, setSelectedAmount] = useState('')

  const wrapperRef = useRef<HTMLDivElement>(null)
  const successFired = useRef(false)

  const network: NetworkId =
    ((typeof window !== 'undefined' ? window.ENV?.CHAIN : undefined) as NetworkId) || 'testnet'

  const curveId = direction === 'support' ? 0n : 1n

  const {
    stake,
    txHash,
    receipt,
    awaitingWalletConfirmation,
    awaitingOnChainConfirmation,
    isError,
    error,
    reset: resetTx,
  } = useStakeTransaction({ termId: triple.term_id, network, curveId })

  const { shares, fees, isLoading: previewLoading } = useDepositPreview({
    termId: triple.term_id,
    curveId,
    amount: selectedAmount,
    network,
    enabled: isConnected && step === 'confirm' && parseFloat(selectedAmount) > 0,
  })

  const isSuccess = receipt?.status === 'success'
  const isBusy = awaitingWalletConfirmation || awaitingOnChainConfirmation

  // Transition to done on success — also dispatch toast
  useEffect(() => {
    if (isSuccess && txHash && !successFired.current) {
      successFired.current = true
      setStep('done')
      const entityName = (contextLabel ?? triple.object.label).toUpperCase()
      const dirLabel = direction === 'support' ? 'VOUCH' : 'DENY'
      addTransaction({
        hash: txHash,
        label: `${dirLabel} ${entityName}`,
        direction: direction === 'support' ? 'for' : 'against',
        amount: selectedAmount,
      })
      onStakeSuccess?.(txHash)
    }
  }, [isSuccess, txHash, direction, contextLabel, triple.object.label, selectedAmount, addTransaction, onStakeSuccess])

  // Transition to pending when tx submitted
  useEffect(() => {
    if ((awaitingWalletConfirmation || awaitingOnChainConfirmation) && step === 'confirm') {
      setStep('pending')
    }
  }, [awaitingWalletConfirmation, awaitingOnChainConfirmation, step])

  // Click outside to close
  useEffect(() => {
    if (!open) return

    const handleClickOutside = (e: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
        handleClose()
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [open])

  const handleClose = useCallback(() => {
    setOpen(false)
    // Reset to initial step based on whether direction is preset
    setStep(presetDirection ? 'amount' : 'direction')
    setDirection(initialDirection)
    setSelectedAmount('')
    resetTx()
    successFired.current = false
  }, [resetTx, presetDirection, initialDirection])

  const handleToggle = useCallback(() => {
    if (open) {
      handleClose()
    } else {
      setOpen(true)
    }
  }, [open, handleClose])

  const handleDirectionSelect = useCallback((dir: Direction) => {
    setDirection(dir)
    setStep('amount')
  }, [])

  const handleAmountSelect = useCallback((amount: string) => {
    setSelectedAmount(amount)
    setStep('confirm')
  }, [])

  const handleConfirm = useCallback(async () => {
    if (!selectedAmount || parseFloat(selectedAmount) <= 0) return
    successFired.current = false
    try {
      await stake(selectedAmount)
    } catch {
      // Error handled by hook state
    }
  }, [selectedAmount, stake])

  const handleError = useCallback(() => {
    resetTx()
    setStep('confirm')
  }, [resetTx])

  const capabilityName = contextLabel ?? triple.object.label

  return (
    <>
      {/* Keyframe animations — scoped to this component */}
      <style>{`
        @keyframes stake-popover-enter {
          from { opacity: 0; transform: translateX(-12px); }
          to   { opacity: 1; transform: translateX(0); }
        }
        @keyframes stake-popover-step {
          from { opacity: 0; transform: translateX(16px); }
          to   { opacity: 1; transform: translateX(0); }
        }
      `}</style>

      <div ref={wrapperRef} className={cn('relative inline-block', className)}>
        {/* Trigger element — click to open/close */}
        <div
          role="button"
          tabIndex={0}
          onClick={handleToggle}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault()
              handleToggle()
            }
          }}
          className="cursor-pointer"
          aria-expanded={open}
          aria-haspopup="true"
        >
          {trigger}
        </div>

        {/* Popover panel */}
        {open && (
          <div
            className="absolute left-0 z-50 rounded-xl border border-app-line bg-app-box"
            style={{
              top: 'calc(100% + 8px)',
              width: 300,
              padding: '10px 12px',
              boxShadow: '0 10px 36px rgba(0,0,0,0.35)',
              animation: 'stake-popover-enter 0.2s cubic-bezier(0.22, 1, 0.36, 1) both',
              transformOrigin: 'top left',
              overflow: 'hidden',
            }}
          >
            {/* Header row: progress dots + close */}
            <div className="flex items-start gap-1">
              <div className="flex-1 min-w-0">
                <ProgressDots step={step} direction={direction} directionPreset={!!presetDirection} />
              </div>
              {step !== 'done' && (
                <button
                  type="button"
                  onClick={handleClose}
                  className="mb-3 flex-shrink-0 bg-transparent border-none font-mono text-xs text-ink-faint cursor-pointer p-0 hover:text-ink-dull transition-colors"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Not connected state */}
            {!isConnected && step !== 'done' && (
              <p className="text-center font-mono text-[10px] tracking-widest text-ink-faint py-2">
                CONNECT WALLET TO STAKE
              </p>
            )}

            {/* Step content */}
            {isConnected && (
              <div
                key={step}
                style={{ animation: 'stake-popover-step 0.18s ease both' }}
              >
                {step === 'direction' && !presetDirection && (
                  <DirectionStep onSelect={handleDirectionSelect} capabilityName={capabilityName} />
                )}

                {step === 'amount' && (
                  <AmountStep
                    direction={direction}
                    selectedAmount={selectedAmount}
                    onSelect={handleAmountSelect}
                  />
                )}

                {step === 'confirm' && !isError && (
                  <ConfirmStep
                    direction={direction}
                    amount={selectedAmount}
                    capabilityName={capabilityName}
                    fees={fees}
                    shares={shares}
                    previewLoading={previewLoading}
                    isBusy={isBusy}
                    onBack={() => setStep('amount')}
                    onConfirm={handleConfirm}
                  />
                )}

                {step === 'confirm' && isError && (
                  <div className="flex items-center justify-between gap-2 py-1">
                    <div className="flex-1 min-w-0">
                      <div
                        className="font-mono text-xs font-bold tracking-widest"
                        style={{ color: RED }}
                      >
                        TX FAILED
                      </div>
                      <div className="font-mono text-[10px] text-ink-faint mt-0.5 truncate">
                        {error?.message?.includes('rejected')
                          ? 'REJECTED BY USER'
                          : 'TRANSACTION FAILED'}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={handleError}
                      className="flex-shrink-0 rounded-lg border font-mono text-xs font-bold tracking-widest px-2.5 py-1.5 transition-colors hover:bg-app-hover"
                      style={{
                        borderColor: RED,
                        color: RED,
                      }}
                    >
                      RETRY
                    </button>
                  </div>
                )}

                {step === 'pending' && (
                  <PendingStep
                    awaitingWalletConfirmation={awaitingWalletConfirmation}
                    awaitingOnChainConfirmation={awaitingOnChainConfirmation}
                    amount={selectedAmount}
                    direction={direction}
                  />
                )}

                {step === 'done' && (
                  <DoneStep
                    txHash={txHash}
                    amount={selectedAmount}
                    network={network}
                    onClose={handleClose}
                  />
                )}
              </div>
            )}

            {/* Vault stats — always visible when vault data exists */}
            {step !== 'done' && <VaultStats triple={triple} />}
          </div>
        )}
      </div>
    </>
  )
}
