import type { Agent, AgentMetadata, TrustSignal, Vault } from '~/types'

interface LocalAgentCacheRecord {
  id: string
  metadata: AgentMetadata
}

declare global {
  // eslint-disable-next-line no-var
  var __localAgentCache: Map<string, LocalAgentCacheRecord> | undefined
}

function getCache(): Map<string, LocalAgentCacheRecord> {
  if (!globalThis.__localAgentCache) {
    globalThis.__localAgentCache = new Map<string, LocalAgentCacheRecord>()
  }
  return globalThis.__localAgentCache
}

export function storeLocalAgent(record: LocalAgentCacheRecord) {
  getCache().set(record.id.toLowerCase(), record)
}

export function findLocalAgent(termId: string): Agent | null {
  const record = getCache().get(termId.toLowerCase())
  if (!record) return null
  return {
    id: record.id,
    metadata: record.metadata,
    capabilities: [],
    vault: emptyVault(record.id),
    trustSignal: emptyTrustSignal(),
    triples: [],
  }
}

function emptyVault(termId: string): Vault {
  return {
    term_id: termId,
    curve_id: '0',
    total_shares: '0',
    current_share_price: '0',
    total_assets: '0',
    market_cap: '0',
    position_count: 0,
  }
}

function emptyTrustSignal(): TrustSignal {
  return {
    stakerCount: 0,
    totalStaked: '0',
    sharePrice: '0',
    tier: 'unranked',
    percentile: 0,
    marketCap: '0',
  }
}
