import { useEffect } from 'react'
import { Layers, Square, Maximize2, Zap, BarChart3, Users } from 'lucide-react'
import { useCardVariant, type CardVariant } from '~/lib/hooks/useCardVariant'
import { useSkillCardStyle, type SkillCardStyle } from '~/lib/hooks/useSkillCardStyle'
import { cn } from '~/lib/utils'

const VARIANT_CONFIG: Record<CardVariant, { icon: typeof Layers; label: string }> = {
  default: { icon: Layers, label: 'Default' },
  compact: { icon: Square, label: 'Compact' },
  detailed: { icon: Maximize2, label: 'Detailed' },
}

const STYLE_CONFIG: Record<SkillCardStyle, { icon: typeof Zap; label: string }> = {
  claim: { icon: Zap, label: 'Claim' },
  score: { icon: BarChart3, label: 'Score' },
  adoption: { icon: Users, label: 'Adoption' },
}

export function DevVariantSwitcher() {
  const { variant, setVariant } = useCardVariant()
  const { style, setStyle } = useSkillCardStyle()

  useEffect(() => {
    function handleKeydown(e: KeyboardEvent) {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return
      if (!e.shiftKey) return
      // Shift+1/2/3 = card layout variant
      if (e.key === '!') setVariant('default')
      else if (e.key === '@') setVariant('compact')
      else if (e.key === '#') setVariant('detailed')
      // Shift+4/5/6 = skill card style
      else if (e.key === '$') setStyle('claim')
      else if (e.key === '%') setStyle('score')
      else if (e.key === '^') setStyle('adoption')
    }

    window.addEventListener('keydown', handleKeydown)
    return () => window.removeEventListener('keydown', handleKeydown)
  }, [setVariant, setStyle])

  if (!import.meta.env.DEV) return null

  return (
    <div className="fixed bottom-6 right-4 z-50 flex flex-col gap-1.5 rounded-xl bg-white/10 p-2 shadow-lg backdrop-blur-md">
      {/* Card layout row */}
      <div className="flex items-center gap-1">
        <span className="text-[10px] text-white/50 w-10">Layout</span>
        {(Object.keys(VARIANT_CONFIG) as CardVariant[]).map((v) => {
          const { icon: Icon, label } = VARIANT_CONFIG[v]
          return (
            <button
              key={v}
              type="button"
              onClick={() => setVariant(v)}
              className={cn(
                'flex items-center gap-1 rounded-md px-2 py-1 text-[10px] font-medium transition-colors',
                variant === v
                  ? 'bg-brand text-white'
                  : 'text-white/60 hover:bg-white/10 hover:text-white/80',
              )}
              title={`${label} (Shift+${v === 'default' ? '1' : v === 'compact' ? '2' : '3'})`}
            >
              <Icon className="h-3 w-3" />
              {label}
            </button>
          )
        })}
      </div>
      {/* Skill card style row */}
      <div className="flex items-center gap-1">
        <span className="text-[10px] text-white/50 w-10">Skill</span>
        {(Object.keys(STYLE_CONFIG) as SkillCardStyle[]).map((s) => {
          const { icon: Icon, label } = STYLE_CONFIG[s]
          return (
            <button
              key={s}
              type="button"
              onClick={() => setStyle(s)}
              className={cn(
                'flex items-center gap-1 rounded-md px-2 py-1 text-[10px] font-medium transition-colors',
                style === s
                  ? 'bg-brand text-white'
                  : 'text-white/60 hover:bg-white/10 hover:text-white/80',
              )}
              title={`${label} (Shift+${s === 'claim' ? '4' : s === 'score' ? '5' : '6'})`}
            >
              <Icon className="h-3 w-3" />
              {label}
            </button>
          )
        })}
      </div>
    </div>
  )
}
