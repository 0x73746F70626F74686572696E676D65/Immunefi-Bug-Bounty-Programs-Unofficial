import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react'

// ── Types ──────────────────────────────────────────────────────────────────

export interface PendingTransaction {
  id: string
  hash: string
  label: string
  direction: 'for' | 'against'
  amount: string
  status: 'pending' | 'confirmed' | 'failed'
  addedAt: number
}

interface TransactionToastContextType {
  addTransaction: (tx: Omit<PendingTransaction, 'id' | 'status' | 'addedAt'>) => void
  transactions: PendingTransaction[]
}

// ── Context ────────────────────────────────────────────────────────────────

const TransactionToastContext = createContext<TransactionToastContextType | null>(null)

export function useTransactionToast(): TransactionToastContextType {
  const ctx = useContext(TransactionToastContext)
  if (!ctx) {
    throw new Error('useTransactionToast must be used inside TransactionToastProvider')
  }
  return ctx
}

// ── Constants ──────────────────────────────────────────────────────────────

const GREEN = '#22c55e'
const RED = '#ef4444'

const MAX_VISIBLE = 3
const MOCK_PENDING_MS = 3000
const AUTO_DISMISS_MS = 4000
const CLEANUP_AFTER_MS = 10000

// ── Individual Toast Card ──────────────────────────────────────────────────

interface ToastCardProps {
  tx: PendingTransaction
  onDismiss: (id: string) => void
  exiting: boolean
}

function ToastCard({ tx, onDismiss, exiting }: ToastCardProps) {
  const color = tx.direction === 'for' ? GREEN : RED
  const isPending = tx.status === 'pending'
  const isConfirmed = tx.status === 'confirmed'
  const isFailed = tx.status === 'failed'

  const verbLabel = tx.direction === 'for' ? 'VOUCHING' : 'DENYING'
  const displayLabel = isPending ? verbLabel + ' ' + tx.label : tx.label

  return (
    <div
      onClick={() => onDismiss(tx.id)}
      style={{
        width: 280,
        background: '#12121a',
        border: `1px solid ${isPending ? color + '55' : '#1e1e2e'}`,
        borderRadius: 8,
        padding: '10px 12px',
        cursor: 'pointer',
        fontFamily: 'var(--font-mono, monospace)',
        boxShadow: isPending
          ? `0 0 12px ${color}30, 0 2px 8px rgba(0,0,0,0.5)`
          : '0 2px 8px rgba(0,0,0,0.5)',
        animation: exiting
          ? 'toast-slide-out 0.25s ease-in forwards'
          : 'toast-slide-in 0.25s ease-out both',
        position: 'relative',
        overflow: 'hidden',
        transition: 'border-color 0.3s',
      }}
    >
      {/* Pulsing border glow for pending */}
      {isPending && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            borderRadius: 8,
            border: `1px solid ${color}`,
            animation: 'toast-glow-pulse 1.4s ease-in-out infinite',
            pointerEvents: 'none',
          }}
        />
      )}

      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        {/* Direction dot / status icon */}
        <div
          style={{
            width: 8,
            height: 8,
            borderRadius: '50%',
            background: color,
            flexShrink: 0,
            animation: isPending ? 'toast-dot-pulse 1.4s ease-in-out infinite' : 'none',
          }}
        />

        {/* Main content */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div
            style={{
              fontSize: 11,
              letterSpacing: '0.1em',
              textTransform: 'uppercase',
              color: '#e0e0e8',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            }}
          >
            {displayLabel}
          </div>
          <div
            style={{
              fontSize: 10,
              color: '#6b6b80',
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              marginTop: 2,
            }}
          >
            {tx.amount} TRUST
          </div>
        </div>

        {/* Status indicator */}
        <div style={{ flexShrink: 0 }}>
          {isPending && (
            <span
              style={{
                fontSize: 14,
                color,
                display: 'inline-block',
                animation: 'toast-spin 1s linear infinite',
              }}
            >
              ◌
            </span>
          )}
          {isConfirmed && (
            <span style={{ fontSize: 14, color: GREEN }}>✓</span>
          )}
          {isFailed && (
            <span style={{ fontSize: 14, color: RED }}>✕</span>
          )}
        </div>
      </div>

      {/* Status text line */}
      <div
        style={{
          marginTop: 4,
          fontSize: 9,
          letterSpacing: '0.1em',
          textTransform: 'uppercase',
          color: isPending ? color + 'aa' : '#6b6b80',
        }}
      >
        {isPending && 'AWAITING CONFIRMATION'}
        {isConfirmed && 'CONFIRMED · CLICK TO DISMISS'}
        {isFailed && 'FAILED · CLICK TO DISMISS'}
      </div>
    </div>
  )
}

// ── Toast Stack UI ─────────────────────────────────────────────────────────

function TransactionToastStack({ transactions }: { transactions: PendingTransaction[] }) {
  const [exiting, setExiting] = useState<Set<string>>(new Set())

  const visible = transactions.slice(-MAX_VISIBLE).reverse()

  return (
    <>
      <style>{`
        @keyframes toast-slide-in {
          from { opacity: 0; transform: translateX(40px); }
          to   { opacity: 1; transform: translateX(0); }
        }
        @keyframes toast-slide-out {
          from { opacity: 1; transform: translateX(0); }
          to   { opacity: 0; transform: translateX(40px); }
        }
        @keyframes toast-glow-pulse {
          0%, 100% { opacity: 0.4; }
          50%       { opacity: 1; }
        }
        @keyframes toast-dot-pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50%       { opacity: 0.5; transform: scale(0.75); }
        }
        @keyframes toast-spin {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
      `}</style>

      <div
        style={{
          position: 'fixed',
          bottom: 16,
          right: 16,
          zIndex: 50,
          display: 'flex',
          flexDirection: 'column',
          gap: 8,
          pointerEvents: 'none',
        }}
      >
        {visible.map((tx) => (
          <div key={tx.id} style={{ pointerEvents: 'auto' }}>
            <ToastCard
              tx={tx}
              onDismiss={(id) => {
                setExiting((prev) => new Set([...prev, id]))
              }}
              exiting={exiting.has(tx.id)}
            />
          </div>
        ))}
      </div>
    </>
  )
}

// ── Provider ───────────────────────────────────────────────────────────────

export function TransactionToastProvider({ children }: { children: React.ReactNode }) {
  const [transactions, setTransactions] = useState<PendingTransaction[]>([])
  const timersRef = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map())

  // Schedule mock confirmation and cleanup
  const scheduleAutoAdvance = useCallback((id: string) => {
    // After MOCK_PENDING_MS, mark confirmed
    const confirmTimer = setTimeout(() => {
      setTransactions((prev) =>
        prev.map((tx) => (tx.id === id ? { ...tx, status: 'confirmed' } : tx)),
      )

      // After AUTO_DISMISS_MS from confirmed, begin cleanup
      const dismissTimer = setTimeout(() => {
        setTransactions((prev) => prev.filter((tx) => tx.id !== id))
        timersRef.current.delete(id)
      }, AUTO_DISMISS_MS)

      timersRef.current.set(id + '-dismiss', dismissTimer)
    }, MOCK_PENDING_MS)

    timersRef.current.set(id, confirmTimer)
  }, [])

  // Periodic cleanup: remove very old confirmed/failed transactions
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now()
      setTransactions((prev) =>
        prev.filter(
          (tx) =>
            tx.status === 'pending' ||
            now - tx.addedAt < CLEANUP_AFTER_MS,
        ),
      )
    }, 2000)
    return () => clearInterval(interval)
  }, [])

  // Clear all timers on unmount
  useEffect(() => {
    const timers = timersRef.current
    return () => {
      timers.forEach((timer) => clearTimeout(timer))
    }
  }, [])

  const addTransaction = useCallback(
    (tx: Omit<PendingTransaction, 'id' | 'status' | 'addedAt'>) => {
      const id = `tx-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
      const entry: PendingTransaction = {
        ...tx,
        id,
        status: 'pending',
        addedAt: Date.now(),
      }
      setTransactions((prev) => [...prev, entry])
      scheduleAutoAdvance(id)
    },
    [scheduleAutoAdvance],
  )

  return (
    <TransactionToastContext.Provider value={{ addTransaction, transactions }}>
      {children}
      <TransactionToastStack transactions={transactions} />
    </TransactionToastContext.Provider>
  )
}
