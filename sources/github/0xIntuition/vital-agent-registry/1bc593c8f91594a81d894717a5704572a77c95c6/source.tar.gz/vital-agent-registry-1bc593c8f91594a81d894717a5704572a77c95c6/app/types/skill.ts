import type { Capability } from './capability'
import type { Platform } from './platform'
import type { TrustSignal, Vault } from './vault'
import type { Triple } from './triple'

/**
 * SafetyStatus — skill safety classification
 *
 * Skills have distinct safety signals from agent trust tiers.
 * Safety is binary (safe/unsafe/unknown) rather than tiered.
 */
export type SafetyStatus = 'verified' | 'unverified' | 'flagged'

/**
 * Skill — a first-class tool/skill entity
 *
 * Skills are represented as Atoms on-chain. Each skill has:
 * - An identity (metadata)
 * - A platform it belongs to (MCP, Claude Code, etc.)
 * - Capabilities it provides
 * - A vault with FOR/AGAINST dynamics for safety signaling
 */
export interface Skill {
  /** Unique term_id (hex string, serves as atom ID) */
  id: string
  /** Rich metadata */
  metadata: SkillMetadata
  /** Platform this skill belongs to */
  platform: Platform
  /** Capabilities this skill has (via has-capability triples) */
  capabilities: Capability[]
  /** Vault for economic signaling (FOR = safe, AGAINST = flagged) */
  vault: Vault
  /** Derived trust signal */
  trustSignal: TrustSignal
  /** Safety signal derived from FOR/AGAINST vault ratio */
  safetySignal: SafetySignal
  /** Relationships where this skill is subject */
  triples: Triple[]
}

/**
 * SkillMetadata — descriptive information about a skill
 */
export interface SkillMetadata {
  /** Skill display name */
  name: string
  /** Short description */
  description: string
  /** Long description / README */
  longDescription?: string
  /** Icon URL */
  image?: string
  /** Skill version string */
  version: string
  /** Author name */
  author?: string
  /** Install URI (npm package, github URL, etc.) */
  installUri?: string
  /** Optional IPFS URI for canonical metadata payload */
  metadataUri?: string
  /** Permissions required (e.g. "filesystem", "network", "env") */
  permissions: string[]
  /** ISO timestamp - when registered */
  createdAt: string
  /** ISO timestamp - last updated */
  updatedAt?: string
}

/**
 * SafetySignal — safety metrics derived from vault FOR/AGAINST dynamics
 *
 * Skills use a FOR/AGAINST vault model:
 * - Staking FOR signals the skill is safe/trusted
 * - Staking AGAINST signals the skill is dangerous/malicious
 *
 * The ratio determines the safety status.
 */
export interface SafetySignal {
  /** Overall safety status */
  status: SafetyStatus
  /** Stakers FOR (attesting safety) */
  forCount: number
  /** Stakers AGAINST (flagging as dangerous) */
  againstCount: number
  /** Total staked FOR in ETH */
  forStake: string
  /** Total staked AGAINST in ETH */
  againstStake: string
  /** FOR / (FOR + AGAINST) ratio (0-1, higher = safer) */
  safetyRatio: number
  /** Reason if flagged */
  flagReason?: string
}
