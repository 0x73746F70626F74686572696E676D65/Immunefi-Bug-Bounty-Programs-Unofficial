import { z } from 'zod'

export const CANONICAL_CONTEXT_PREDICATES = [
  'in-context-of',
  'as-evaluated-by',
  'during-period',
] as const

export const canonicalContextPredicateSchema = z.enum(CANONICAL_CONTEXT_PREDICATES)

export const contextClaimSchema = z.object({
  subject: z.string().min(1),
  predicate: z.string().min(1),
  object: z.string().min(1),
})

export const contextQuerySchema = z.object({
  baseClaims: z.array(contextClaimSchema).default([]),
  contextClaims: z.array(contextClaimSchema).default([]),
})

export interface DiscrepancyMetric {
  score: number
  overlapCount: number
  baseOnlyCount: number
  contextOnlyCount: number
}

function signature(claim: z.infer<typeof contextClaimSchema>): string {
  return `${claim.subject}|${claim.predicate}|${claim.object}`
}

function round(value: number): number {
  return Math.round(value * 1_000_000) / 1_000_000
}

export function evaluateContextQuery(input: z.infer<typeof contextQuerySchema>) {
  const baseSet = new Set(input.baseClaims.map(signature))
  const contextSet = new Set(input.contextClaims.map(signature))

  const overlap = [...baseSet].filter((value) => contextSet.has(value))
  const baseOnly = [...baseSet].filter((value) => !contextSet.has(value))
  const contextOnly = [...contextSet].filter((value) => !baseSet.has(value))

  const denominator = Math.max(1, baseSet.size + contextOnly.length)
  const score = round((baseOnly.length + contextOnly.length) / denominator)

  const contextPredicateSet = new Set(
    input.contextClaims.map((claim) => claim.predicate),
  )

  return {
    baseLayer: {
      claims: input.baseClaims,
      count: input.baseClaims.length,
    },
    contextLayer: {
      claims: input.contextClaims,
      count: input.contextClaims.length,
      predicatesUsed: [...contextPredicateSet].sort((a, b) => a.localeCompare(b)),
    },
    discrepancy: {
      score,
      overlapCount: overlap.length,
      baseOnlyCount: baseOnly.length,
      contextOnlyCount: contextOnly.length,
    } satisfies DiscrepancyMetric,
  }
}

export function assertCanonicalContextClaims(
  contextClaims: Array<z.infer<typeof contextClaimSchema>>,
) {
  const invalid = contextClaims.filter(
    (claim) => !CANONICAL_CONTEXT_PREDICATES.includes(claim.predicate as any),
  )
  if (invalid.length > 0) {
    return {
      ok: false as const,
      reason: 'NON_CANONICAL_PREDICATE',
      invalidPredicates: [...new Set(invalid.map((claim) => claim.predicate))],
    }
  }

  const denseSubjects = new Map<string, Set<string>>()
  for (const claim of contextClaims) {
    const key = `${claim.subject}|${claim.object}`
    if (!denseSubjects.has(key)) denseSubjects.set(key, new Set())
    denseSubjects.get(key)!.add(claim.predicate)
  }

  const densePairs = [...denseSubjects.entries()]
    .filter(([, predicates]) => predicates.size > 1)
    .map(([pair, predicates]) => ({ pair, predicates: [...predicates].sort((a, b) => a.localeCompare(b)) }))

  if (densePairs.length > 0) {
    return {
      ok: false as const,
      reason: 'SEMANTIC_DENSITY_REJECTED',
      densePairs,
      guidance:
        'Use one canonical context predicate per (subject, object) edge; split extra semantics into additional claims.',
    }
  }

  return { ok: true as const }
}
