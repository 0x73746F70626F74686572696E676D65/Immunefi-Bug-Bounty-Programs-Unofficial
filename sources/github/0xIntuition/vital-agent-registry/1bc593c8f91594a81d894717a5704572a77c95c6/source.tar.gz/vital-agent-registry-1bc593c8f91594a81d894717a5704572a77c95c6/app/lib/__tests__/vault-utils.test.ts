import { describe, expect, it } from 'vitest'
import {
  DEFAULT_SHARE_PRICE,
  applyEntryFeeBps,
  applyExitFeeBps,
  compareBigIntStrings,
  computeFeeBps,
  formatWeiToEth,
  safeSharePrice,
} from '../vault-utils'
import type { Vault } from '~/types'

describe('vault-utils', () => {
  it('formats wei to ETH without precision loss for large values', () => {
    const large = '123456789012345678901234567890'
    const eth = formatWeiToEth(large, 6)
    expect(typeof eth).toBe('string')
    expect(eth).toMatch(/^\d+(\.\d+)?$/)
  })

  it('returns default share price for empty vault', () => {
    const vault: Vault = {
      term_id: '0x1',
      curve_id: '1',
      total_shares: '0',
      current_share_price: '0',
      total_assets: '0',
      market_cap: '0',
      position_count: 0,
    }
    expect(safeSharePrice(vault)).toBe(DEFAULT_SHARE_PRICE)
  })

  it('computes basis-point fees with BigInt math', () => {
    const fee = computeFeeBps('1000000000000000000', 250n) // 2.5%
    expect(fee).toBe('25000000000000000')
  })

  it('applies entry fee and preserves gross=fee+net identity', () => {
    const result = applyEntryFeeBps('1000000000000000000', 100n) // 1%
    const gross = BigInt(result.grossWei)
    const fee = BigInt(result.feeWei)
    const net = BigInt(result.netWei)
    expect(gross).toBe(fee + net)
  })

  it('applies exit fee and preserves gross=fee+payout identity', () => {
    const result = applyExitFeeBps('123000000000000000', 35n) // 0.35%
    const gross = BigInt(result.grossWei)
    const fee = BigInt(result.feeWei)
    const payout = BigInt(result.payoutWei)
    expect(gross).toBe(fee + payout)
  })

  it('compares BigInt strings deterministically', () => {
    expect(compareBigIntStrings('10', '20')).toBeLessThan(0)
    expect(compareBigIntStrings('20', '20')).toBe(0)
    expect(compareBigIntStrings('30', '20')).toBeGreaterThan(0)
  })
})
