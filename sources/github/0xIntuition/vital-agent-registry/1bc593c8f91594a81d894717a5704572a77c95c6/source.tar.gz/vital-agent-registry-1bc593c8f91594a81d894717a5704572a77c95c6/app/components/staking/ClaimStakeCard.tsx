import { useState, useEffect, useRef, useCallback } from 'react'
import { useAccount } from 'wagmi'
import { formatEther } from 'viem'
import { Loader2, CheckCircle2, AlertCircle, Wallet } from 'lucide-react'
import type { Triple } from '~/types'
import type { NetworkId } from '~/lib/constants/protocol'
import { useStakeTransaction } from '~/lib/hooks/useStakeTransaction'
import { useDepositPreview } from '~/lib/hooks/useDepositPreview'
import { formatWeiToEth } from '~/lib/vault-utils'
import { cn } from '~/lib/utils'

type Direction = 'for' | 'against'

type StakeState = 'idle' | 'confirming' | 'pending' | 'success' | 'error'

interface ClaimStakeCardProps {
  triple: Triple
  className?: string
  onStakeSuccess?: (txHash: string) => void
}

/**
 * Bridge-inspired staking card for individual triple claims.
 *
 * Supports FOR/AGAINST direction toggle, fee preview via previewDeposit,
 * and a state-machine CTA button.
 */
export function ClaimStakeCard({ triple, className, onStakeSuccess }: ClaimStakeCardProps) {
  const { isConnected } = useAccount()
  const [direction, setDirection] = useState<Direction>('for')
  const [amount, setAmount] = useState('')
  const [debouncedAmount, setDebouncedAmount] = useState('')

  const chain =
    ((typeof window !== 'undefined' ? window.ENV?.CHAIN : undefined) as NetworkId) || 'testnet'

  const curveId = direction === 'for' ? 0n : 1n

  const {
    stake,
    txHash,
    receipt,
    awaitingWalletConfirmation,
    awaitingOnChainConfirmation,
    isError,
    error,
    reset,
  } = useStakeTransaction({ termId: triple.term_id, network: chain, curveId })

  // Debounce amount for fee preview
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedAmount(amount), 400)
    return () => clearTimeout(timer)
  }, [amount])

  const { shares, fees, isLoading: previewLoading } = useDepositPreview({
    termId: triple.term_id,
    curveId,
    amount: debouncedAmount,
    network: chain,
    enabled: isConnected && parseFloat(debouncedAmount) > 0,
  })

  const isSuccess = receipt?.status === 'success'
  const isBusy = awaitingWalletConfirmation || awaitingOnChainConfirmation

  // Derive CTA state
  const stakeState: StakeState = isSuccess
    ? 'success'
    : isError
      ? 'error'
      : awaitingWalletConfirmation
        ? 'confirming'
        : awaitingOnChainConfirmation
          ? 'pending'
          : 'idle'

  // Fire callback on success
  const successFired = useRef(false)
  useEffect(() => {
    if (isSuccess && txHash && !successFired.current) {
      successFired.current = true
      onStakeSuccess?.(txHash)
    }
  }, [isSuccess, txHash, onStakeSuccess])

  const handleStake = useCallback(async () => {
    if (!amount || parseFloat(amount) <= 0) return
    successFired.current = false
    try {
      await stake(amount)
    } catch {
      // Error handled by hook
    }
  }, [amount, stake])

  const handleReset = useCallback(() => {
    reset()
    setAmount('')
    successFired.current = false
  }, [reset])

  // Vault stats from triple
  const forTvl = triple.vault?.forVault
    ? formatWeiToEth(triple.vault.forVault.total_assets, 3)
    : '0'
  const againstTvl = triple.vault?.againstVault
    ? formatWeiToEth(triple.vault.againstVault.total_assets, 3)
    : '0'
  const forStakers = triple.vault?.forVault?.position_count ?? 0
  const againstStakers = triple.vault?.againstVault?.position_count ?? 0

  const hasAmount = !!amount && parseFloat(amount) > 0

  return (
    <div
      className={cn(
        'relative overflow-hidden rounded-xl border border-app-line bg-app-box shadow-[var(--shadow-card)]',
        className,
      )}
    >
      {/* Glassmorphism overlay */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-white/[0.04] to-transparent" />

      <div className="relative space-y-4 p-4">
        {/* Claim header */}
        <div className="flex items-center gap-2 text-sm">
          <span className="rounded-md bg-brand/10 px-2 py-0.5 font-medium text-brand">
            {triple.subject.label}
          </span>
          <span className="text-ink-dull">{triple.predicate.label}</span>
          <span className="rounded-md bg-app-box-dark px-2 py-0.5 font-medium text-ink-default">
            {triple.object.label}
          </span>
        </div>

        {/* Vault stats row */}
        <div className="flex gap-4 text-xs">
          <div className="flex items-center gap-1.5">
            <div className="h-2 w-2 rounded-full bg-[hsl(142_71%_45%)]" />
            <span className="text-ink-dull">Support:</span>
            <span className="font-medium text-ink-default">{forTvl} TRUST</span>
            <span className="text-ink-faint">({forStakers})</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="h-2 w-2 rounded-full bg-[hsl(0_84%_60%)]" />
            <span className="text-ink-dull">Oppose:</span>
            <span className="font-medium text-ink-default">{againstTvl} TRUST</span>
            <span className="text-ink-faint">({againstStakers})</span>
          </div>
        </div>

        {!isConnected ? (
          <p className="text-center text-sm text-ink-dull">Connect wallet to stake on this claim</p>
        ) : stakeState === 'success' ? (
          <div className="space-y-3">
            <div className="flex items-center justify-center gap-2 text-[hsl(142_71%_45%)]">
              <CheckCircle2 className="h-5 w-5" />
              <span className="font-medium">Done</span>
            </div>
            {txHash && (
              <p className="text-center text-xs text-ink-faint font-mono break-all">
                {chain === 'local' ? (
                  txHash
                ) : (
                  <a
                    href={`${chain === 'testnet' ? 'https://testnet.explorer.intuition.systems' : 'https://explorer.intuition.systems'}/tx/${txHash}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline"
                  >
                    View transaction
                  </a>
                )}
              </p>
            )}
            <button
              type="button"
              onClick={handleReset}
              className="mx-auto block text-xs text-brand hover:underline"
            >
              Stake again
            </button>
          </div>
        ) : (
          <>
            {/* Direction toggle */}
            <div className="flex gap-1 rounded-lg bg-app-box-dark p-1">
              <button
                type="button"
                className={cn(
                  'flex-1 rounded-md px-3 py-2 text-sm font-medium transition-colors',
                  direction === 'for'
                    ? 'bg-[hsl(142_71%_45%/0.15)] text-[hsl(142_71%_45%)]'
                    : 'text-ink-dull hover:text-ink-default',
                )}
                onClick={() => setDirection('for')}
                disabled={isBusy}
              >
                Support
              </button>
              <button
                type="button"
                className={cn(
                  'flex-1 rounded-md px-3 py-2 text-sm font-medium transition-colors',
                  direction === 'against'
                    ? 'bg-[hsl(0_84%_60%/0.15)] text-[hsl(0_84%_60%)]'
                    : 'text-ink-dull hover:text-ink-default',
                )}
                onClick={() => setDirection('against')}
                disabled={isBusy}
              >
                Oppose
              </button>
            </div>

            {/* Amount input */}
            <div className="space-y-1">
              <input
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                disabled={isBusy}
                className="w-full bg-transparent text-center text-4xl font-semibold text-ink-default placeholder:text-ink-faint/40 border-none outline-none disabled:opacity-50"
                min="0"
                step="0.001"
              />
              <p className="text-center text-xs text-ink-dull">TRUST</p>
            </div>

            {/* Fee preview */}
            {hasAmount && (
              <div className="text-center text-xs text-ink-faint">
                {previewLoading ? (
                  <span className="animate-pulse">Calculating...</span>
                ) : shares > 0n ? (
                  <span>
                    You receive {formatEther(shares)} shares · Fee:{' '}
                    {formatEther(fees)} TRUST
                  </span>
                ) : null}
              </div>
            )}

            {/* CTA button */}
            <button
              type="button"
              onClick={handleStake}
              disabled={isBusy || !hasAmount}
              className={cn(
                'flex w-full items-center justify-center gap-2 rounded-lg px-4 py-3 text-sm font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-50',
                direction === 'for'
                  ? 'bg-[hsl(142_71%_45%)] text-white hover:bg-[hsl(142_71%_40%)]'
                  : 'bg-[hsl(0_84%_60%)] text-white hover:bg-[hsl(0_84%_55%)]',
              )}
            >
              {stakeState === 'confirming' ? (
                <>
                  <Wallet className="h-4 w-4 animate-pulse" />
                  Confirm in Wallet
                </>
              ) : stakeState === 'pending' ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Pending...
                </>
              ) : !hasAmount ? (
                'Enter Amount'
              ) : direction === 'for' ? (
                'Support'
              ) : (
                'Oppose'
              )}
            </button>

            {/* Error */}
            {stakeState === 'error' && (
              <div className="flex items-start gap-2 text-sm text-[hsl(0_84%_60%)]">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                <div>
                  <p>
                    {error?.message?.includes('rejected')
                      ? 'Transaction rejected'
                      : error?.message || 'Transaction failed'}
                  </p>
                  <button type="button" onClick={reset} className="mt-1 text-xs underline">
                    Try again
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}
