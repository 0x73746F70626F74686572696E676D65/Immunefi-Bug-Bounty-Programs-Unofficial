/**
 * Term ID computation and validation utilities.
 *
 * In the Intuition protocol, a `term_id` is a unique identifier for an atom
 * computed as the keccak256 hash of the atom's data. This ensures deterministic
 * IDs that can be computed off-chain before the atom is created on-chain.
 *
 * Format: `keccak256(abi.encodePacked(atomData))`
 *
 * NOTE: This implementation uses SHA-256 as a placeholder for keccak256.
 * Production code should use `keccak256` from viem or ethers for Ethereum
 * compatibility.
 *
 * @module term-id
 */

/**
 * Computes the term_id for an atom from its data string.
 *
 * The term_id is the keccak256 hash of the atom data bytes. This implementation
 * uses SHA-256 as a placeholder and should be replaced with keccak256 in production.
 *
 * @param atomData - The atom data string (typically an IPFS CID or URI)
 * @returns The term_id as a hex string with 0x prefix
 *
 * @example
 * ```typescript
 * const termId = await computeTermId("ipfs://QmX...");
 * // termId = "0x1234567890abcdef..."
 * ```
 *
 * @todo Replace SHA-256 with keccak256 from viem for production use:
 * ```typescript
 * import { keccak256, toBytes } from 'viem';
 * return keccak256(toBytes(atomData));
 * ```
 */
export async function computeTermId(atomData: string): Promise<string> {
  // TODO: Replace with keccak256 from viem in production
  // import { keccak256, toBytes } from 'viem';
  // return keccak256(toBytes(atomData));

  // Placeholder implementation using SHA-256
  const encoder = new TextEncoder();
  const data = encoder.encode(atomData);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
  return `0x${hashHex}`;
}

/**
 * Validates a term_id format.
 *
 * A valid term_id must:
 * - Start with "0x" prefix
 * - Contain exactly 64 hexadecimal characters (32 bytes)
 * - Only use characters 0-9, a-f, A-F
 *
 * @param id - The term_id string to validate
 * @returns True if the term_id is valid, false otherwise
 *
 * @example
 * ```typescript
 * isValidTermId("0x1234567890abcdef..."); // true (if 64 hex chars)
 * isValidTermId("1234567890abcdef...");   // false (no 0x prefix)
 * isValidTermId("0x123");                 // false (too short)
 * isValidTermId("0xGGGG...");             // false (invalid hex)
 * ```
 */
export function isValidTermId(id: string): boolean {
  // Must start with 0x and have exactly 64 hex characters after it
  return /^0x[0-9a-fA-F]{64}$/.test(id);
}
