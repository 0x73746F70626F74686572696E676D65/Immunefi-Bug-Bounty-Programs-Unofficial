import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const mocks = vi.hoisted(() => ({
  getTripleCost: vi.fn(),
  createTriples: vi.fn(),
  getMinimumDeposit: vi.fn(),
  encodeCreateTriplesCalldata: vi.fn(),
  createLocalWriteClients: vi.fn(),
  getLocalWriteContext: vi.fn(),
  assertRemoteWriteAllowed: vi.fn(),
  serverGraphqlRequest: vi.fn(),
  isRegistrationRateLimitEnabled: vi.fn(),
  getClientIP: vi.fn(),
  registrationLimiter: {
    check: vi.fn(),
  },
}))

vi.mock('~/.server/multivault', () => ({
  getTripleCost: mocks.getTripleCost,
  createTriples: mocks.createTriples,
  getMinimumDeposit: mocks.getMinimumDeposit,
}))

vi.mock('~/lib/calldata', () => ({
  encodeCreateTriplesCalldata: mocks.encodeCreateTriplesCalldata,
}))

vi.mock('~/.server/local-write', () => ({
  createLocalWriteClients: mocks.createLocalWriteClients,
  getLocalWriteContext: mocks.getLocalWriteContext,
}))

vi.mock('~/.server/remote-write-guard', () => ({
  assertRemoteWriteAllowed: mocks.assertRemoteWriteAllowed,
  RemoteWriteGuardError: class RemoteWriteGuardError extends Error {
    code = 'REMOTE_WRITE_BLOCKED'
    profile: string
    target: string
    action: string
    constructor(action: string, target: string, profile: string) {
      super(`Remote write blocked for "${action}" targeting "${target}".`)
      this.name = 'RemoteWriteGuardError'
      this.profile = profile
      this.target = target
      this.action = action
    }
  },
}))

vi.mock('~/lib/abis/multivault', () => ({
  multivaultAbi: [],
}))

vi.mock('viem', () => ({
  createPublicClient: vi.fn(() => ({})),
  http: vi.fn(() => ({})),
  parseEventLogs: vi.fn(() => []),
}))

vi.mock('~/lib/rate-limit', () => ({
  isRegistrationRateLimitEnabled: mocks.isRegistrationRateLimitEnabled,
  getClientIP: mocks.getClientIP,
  registrationLimiter: mocks.registrationLimiter,
}))

vi.mock('~/lib/graphql/client', () => ({
  serverGraphqlRequest: mocks.serverGraphqlRequest,
}))

vi.mock('~/lib/constants/protocol', () => ({
  getContractAddress: vi.fn(() => '0xcontract'),
  getChainConfig: vi.fn(() => ({ chainId: 13579 })),
  getRpcUrl: vi.fn(() => 'http://localhost:8545'),
}))

const SUBJECT_ID = '0x1111111111111111111111111111111111111111111111111111111111111111'
const PREDICATE_ID = '0x2222222222222222222222222222222222222222222222222222222222222222'
const OBJECT_ID = '0x3333333333333333333333333333333333333333333333333333333333333333'

describe('POST /api/v1/triples', () => {
  const baseEnv = { ...process.env }

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = {
      ...baseEnv,
      CHAIN: 'testnet',
      ALLOW_REMOTE_WRITES: '1',
      REGISTRY_WRITE_PROFILE: 'shared',
      REGISTRY_API_KEY: 'test-key',
    }
    mocks.isRegistrationRateLimitEnabled.mockReturnValue(false)
    mocks.getTripleCost.mockResolvedValue(25n)
    mocks.encodeCreateTriplesCalldata.mockReturnValue('0xbeadfeed')
  })

  afterEach(() => {
    process.env = { ...baseEnv }
  })

  function createPostRequest(
    body: unknown,
    params: string = '',
    extraHeaders: Record<string, string> = {},
  ) {
    return new Request(`http://localhost:4101/api/v1/triples${params}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', ...extraHeaders },
      body: JSON.stringify(body),
    })
  }

  it('should return calldata in prepare mode with valid triples', async () => {
    const { action } = await import('../api+/v1.triples')
    const response = await action({
      request: createPostRequest({
        triples: [
          { subjectId: SUBJECT_ID, predicateId: PREDICATE_ID, objectId: OBJECT_ID },
        ],
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.calldata).toBe('0xbeadfeed')
    expect(body.data.estimatedCost).toBe('25')
    expect(body.data.contractAddress).toBe('0xcontract')
    expect(body.data.chainId).toBe(13579)
    expect(body.data.triples).toHaveLength(1)
  })

  it('should return validation error for empty triples array', async () => {
    const { action } = await import('../api+/v1.triples')
    const response = await action({
      request: createPostRequest({ triples: [] }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(400)
    const body = await response.json()
    expect(body.code).toBe('VALIDATION_ERROR')
  })

  it('should return validation error for invalid term IDs', async () => {
    const { action } = await import('../api+/v1.triples')
    const response = await action({
      request: createPostRequest({
        triples: [
          { subjectId: 'not-a-term-id', predicateId: PREDICATE_ID, objectId: OBJECT_ID },
        ],
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(400)
    const body = await response.json()
    expect(body.code).toBe('VALIDATION_ERROR')
  })

  it('should execute triples on local chain with execute=true', async () => {
    mocks.getLocalWriteContext.mockReturnValue({
      contractAddress: '0xcontract',
      rpcUrl: 'http://localhost:8545',
    })
    mocks.createLocalWriteClients.mockResolvedValue({
      publicClient: {
        waitForTransactionReceipt: vi.fn().mockResolvedValue({ logs: [] }),
      },
      walletClient: {
        account: { address: '0xwalletaddress' },
      },
    })
    mocks.getMinimumDeposit.mockResolvedValue(1n)
    mocks.createTriples.mockResolvedValue({
      hash: '0xtriplehash',
      tripleCount: 1,
    })

    const { action } = await import('../api+/v1.triples')
    const response = await action({
      request: createPostRequest(
        {
          triples: [
            { subjectId: SUBJECT_ID, predicateId: PREDICATE_ID, objectId: OBJECT_ID },
          ],
        },
        '?execute=true',
        { 'x-api-key': 'test-key' },
      ),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.execution.mode).toBe('local')
    expect(body.data.execution.executed).toBe(true)
    expect(body.data.execution.txHash).toBe('0xtriplehash')
    expect(body.data.execution.tripleCount).toBe(1)
    expect(body.data.execution.account).toBe('0xwalletaddress')
  })

  it('should return 429 when rate limited', async () => {
    mocks.isRegistrationRateLimitEnabled.mockReturnValue(true)
    mocks.getClientIP.mockReturnValue('192.168.1.1')
    mocks.registrationLimiter.check.mockReturnValue({
      allowed: false,
      resetAt: Date.now() + 60_000,
    })

    const { action } = await import('../api+/v1.triples')
    const response = await action({
      request: createPostRequest({
        triples: [
          { subjectId: SUBJECT_ID, predicateId: PREDICATE_ID, objectId: OBJECT_ID },
        ],
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(429)
    const body = await response.json()
    expect(body.code).toBe('RATE_LIMITED')
    expect(body.retryAfter).toBeGreaterThan(0)
  })
})

describe('GET /api/v1/triples', () => {
  const baseEnv = { ...process.env }

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = { ...baseEnv }
  })

  afterEach(() => {
    process.env = { ...baseEnv }
  })

  function createGetRequest(params: string) {
    return new Request(`http://localhost:4101/api/v1/triples?${params}`)
  }

  it('should return triples filtered by subjectId', async () => {
    const mockTriples = [
      {
        term_id: '0xaaa',
        counter_term_id: '0xbbb',
        created_at: '2025-01-01T00:00:00Z',
        subject: { term_id: SUBJECT_ID, label: 'Agent', image: null, type: 'agent' },
        predicate: { term_id: PREDICATE_ID, label: 'has-capability', image: null, type: 'predicate' },
        object: { term_id: OBJECT_ID, label: 'search', image: null, type: 'capability', data: null },
        term: {
          total_market_cap: '1000',
          positions_aggregate: { aggregate: { count: 5 } },
          vaults: [],
        },
        creator: { id: '0xcreator', label: 'Creator', image: null },
      },
    ]
    mocks.serverGraphqlRequest.mockResolvedValue({
      total: { aggregate: { count: 1 } },
      triples: mockTriples,
    })

    const { loader } = await import('../api+/v1.triples')
    const response = await loader({
      request: createGetRequest(`subjectId=${SUBJECT_ID}`),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data).toHaveLength(1)
    expect(body.data[0].subject.term_id).toBe(SUBJECT_ID)
    expect(body.meta.total).toBe(1)
  })

  it('should return triples filtered by predicateId', async () => {
    mocks.serverGraphqlRequest.mockResolvedValue({
      total: { aggregate: { count: 2 } },
      triples: [
        { term_id: '0xaaa', predicate: { term_id: PREDICATE_ID } },
        { term_id: '0xbbb', predicate: { term_id: PREDICATE_ID } },
      ],
    })

    const { loader } = await import('../api+/v1.triples')
    const response = await loader({
      request: createGetRequest(`predicateId=${PREDICATE_ID}`),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data).toHaveLength(2)
    expect(body.meta.total).toBe(2)
  })

  it('should return validation error when no filters provided', async () => {
    const { loader } = await import('../api+/v1.triples')
    const response = await loader({
      request: new Request('http://localhost:4101/api/v1/triples'),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(400)
    const body = await response.json()
    expect(body.code).toBe('VALIDATION_ERROR')
  })

  it('should return empty array when GraphQL unavailable', async () => {
    mocks.serverGraphqlRequest.mockRejectedValue(new Error('Connection refused'))

    const { loader } = await import('../api+/v1.triples')
    const response = await loader({
      request: createGetRequest(`subjectId=${SUBJECT_ID}`),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data).toEqual([])
    expect(body.meta.total).toBe(0)
  })

  it('should accept multiple filters simultaneously', async () => {
    mocks.serverGraphqlRequest.mockResolvedValue({
      total: { aggregate: { count: 1 } },
      triples: [
        {
          term_id: '0xaaa',
          subject: { term_id: SUBJECT_ID },
          predicate: { term_id: PREDICATE_ID },
          object: { term_id: OBJECT_ID },
        },
      ],
    })

    const { loader } = await import('../api+/v1.triples')
    const response = await loader({
      request: createGetRequest(
        `subjectId=${SUBJECT_ID}&predicateId=${PREDICATE_ID}&objectId=${OBJECT_ID}`
      ),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data).toHaveLength(1)
    expect(mocks.serverGraphqlRequest).toHaveBeenCalledWith(
      expect.any(String),
      expect.any(String),
      expect.objectContaining({
        where: {
          subject_id: { _eq: SUBJECT_ID },
          predicate_id: { _eq: PREDICATE_ID },
          object_id: { _eq: OBJECT_ID },
        },
      }),
    )
  })
})
