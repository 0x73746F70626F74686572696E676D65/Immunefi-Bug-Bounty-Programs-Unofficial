import { createContext, useContext, useMemo, type ReactNode } from 'react'
import type { RegistryRepository } from '~/types'
import { MockRegistryRepository } from './mock-repository'
import { GraphQLRegistryRepository } from './graphql-repository'
import { MOCK_AGENTS } from '../agents'
import { MOCK_SKILLS } from '../skills'
import { CAPABILITIES } from '../capabilities'
import { PREDICATES } from '../predicates'
import { PLATFORMS } from '../platforms'

const RepositoryContext = createContext<RegistryRepository | undefined>(undefined)

interface RepositoryProviderProps {
  children: ReactNode
  /** Override repository implementation (for testing or future real adapter) */
  repository?: RegistryRepository
}

/**
 * Provides a RegistryRepository instance via React Context.
 * Uses MockRegistryRepository by default. Pass a custom repository prop
 * to swap implementations (e.g., for real GraphQL adapter).
 */
export function RepositoryProvider({
  children,
  repository,
}: RepositoryProviderProps) {
  const repo = useMemo(
    () =>
      repository ??
      new MockRegistryRepository({
        agents: MOCK_AGENTS,
        skills: MOCK_SKILLS,
        capabilities: CAPABILITIES,
        predicates: PREDICATES,
        platforms: PLATFORMS,
      }),
    [repository],
  )

  return (
    <RepositoryContext.Provider value={repo}>
      {children}
    </RepositoryContext.Provider>
  )
}

/**
 * Hook to access the RegistryRepository from context.
 * Must be called within a RepositoryProvider.
 * Throws if used outside provider.
 */
export function useRepository(): RegistryRepository {
  const context = useContext(RepositoryContext)
  if (!context) {
    throw new Error('useRepository must be used within a RepositoryProvider')
  }
  return context
}

/**
 * Create a standalone repository instance (for use in route loaders
 * where React hooks are not available).
 *
 * If GRAPHQL_API_URL_PRIVATE is set, uses GraphQL repository.
 * Otherwise falls back to mock repository.
 */
export function createRepository(): RegistryRepository {
  // process.env is only available server-side; on the client, fall back to mock
  const apiUrl = typeof process !== 'undefined'
    ? process.env.GRAPHQL_API_URL_PRIVATE
    : undefined
  const chain = (typeof process !== 'undefined'
    ? process.env.CHAIN as 'testnet' | 'mainnet' | 'local'
    : undefined) || 'testnet'

  if (apiUrl) {
    return new GraphQLRegistryRepository({ apiUrl, chain })
  }

  // Fallback to mock repository
  return new MockRegistryRepository({
    agents: MOCK_AGENTS,
    skills: MOCK_SKILLS,
    capabilities: CAPABILITIES,
    predicates: PREDICATES,
    platforms: PLATFORMS,
  })
}
