import { SearchX, Inbox } from 'lucide-react'

interface EmptyStateProps {
  query?: string
  hasFilters?: boolean
  onClearFilters?: () => void
  className?: string
}

/**
 * EmptyState — message when no results match filters/search
 */
export function EmptyState({
  query,
  hasFilters,
  onClearFilters,
  className = '',
}: EmptyStateProps) {
  const hasQueryOrFilters = Boolean(query || hasFilters)
  const Icon = hasQueryOrFilters ? SearchX : Inbox

  return (
    <div className={`flex flex-col items-center justify-center py-16 text-center ${className}`}>
      <Icon className="mb-4 h-16 w-16 text-muted-foreground" />
      <h2 className="text-lg font-semibold text-foreground">
        {hasQueryOrFilters ? 'No results found' : 'No agents or skills yet'}
      </h2>
      {query && (
        <p className="mt-2 text-sm text-muted-foreground">
          No results for "{query}"
        </p>
      )}
      {hasFilters && onClearFilters && (
        <div className="mt-4 flex flex-col items-center gap-2">
          <p className="text-sm text-muted-foreground">
            Try adjusting your filters
          </p>
          <button
            type="button"
            onClick={onClearFilters}
            className="rounded-full bg-brand px-4 py-2 text-sm font-medium text-white hover:bg-brand/90"
          >
            Clear filters
          </button>
        </div>
      )}
      {!hasQueryOrFilters && (
        <p className="mt-2 text-sm text-muted-foreground">
          Check back later for new agents and skills
        </p>
      )}
    </div>
  )
}
