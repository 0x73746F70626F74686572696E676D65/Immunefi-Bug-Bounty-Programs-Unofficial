import { useLoaderData, useNavigate } from 'react-router'
import type { Route } from './+types/agents.$agentId'
import { createRepository } from '~/data'
import { getIndexerLagBlocks } from '~/lib/indexer-lag.server'
import { RegistryLayout } from '~/components/layout/RegistryLayout'
import {
  AgentIdentityZone,
  AgentCapabilityZone,
  AgentSkillsZone,
  TrustZone,
  RelationshipZone,
  AgentViewIdentityZone,
  AgentViewTrustZone,
  AgentViewCapabilityZone,
  ApiResponsePreview,
} from '~/components/profile'
import { TrustGraph } from '~/components/graph/TrustGraph'
import { StaleBanner } from '~/components/ui/StaleBanner'
import { StaleIndicator } from '~/components/ui/StaleIndicator'
import { Badge } from '~/components/ui/Badge'
import { useViewMode } from '~/lib/providers/view-mode'
import { useIPFSFallback } from '~/lib/hooks/useIPFSFallback'
import { generateAvatar } from '~/lib/avatar'
import { ArrowLeft, Share2 } from 'lucide-react'
import { SaveButton } from '~/components/ui/SaveButton'

export function meta({ data }: Route.MetaArgs) {
  const name = data?.agent?.metadata?.name ?? 'Agent'
  return [
    { title: `${name} — Intuition` },
    { name: 'description', content: `Trust profile for ${name} on Intuition.` },
  ]
}

export async function loader({ params }: Route.LoaderArgs) {
  const { agentId } = params
  const repository = createRepository()
  const [agent, agentResult, skillResult, indexerLagBlocks] = await Promise.all([
    repository.findAgent(agentId),
    repository.listAgents({ limit: 100 }),
    repository.listSkills({ limit: 100 }),
    getIndexerLagBlocks(),
  ])

  return {
    agent,
    allAgents: agentResult.items,
    allSkills: skillResult.items,
    indexerLagBlocks,
  }
}

export default function AgentProfile() {
  const { agent, allAgents, allSkills, indexerLagBlocks } = useLoaderData<typeof loader>()
  const navigate = useNavigate()
  const { isAgentView } = useViewMode()
  const { isStale } = useIPFSFallback(
    agent?.metadata?.metadataUri,
    agent?.metadata,
    { timeoutMs: 3000 },
  )

  if (!agent) {
    return (
      <RegistryLayout>
        <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
          <h1 className="text-3xl font-bold text-card-foreground mb-2">
            Agent Not Found
          </h1>
          <p className="text-muted-foreground mb-6">
            The agent you're looking for doesn't exist or has been removed.
          </p>
          <button
            onClick={() => navigate('/')}
            className="px-4 py-2 rounded-lg bg-brand text-white hover:bg-brand/90 transition-colors"
          >
            Back to Registry
          </button>
        </div>
      </RegistryLayout>
    )
  }

  const handleShare = async () => {
    const url = window.location.href
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${agent.metadata.name} - Agent Registry`,
          text: agent.metadata.description,
          url,
        })
      } catch (error) {
        // User cancelled or share failed
        console.error('Share failed:', error)
      }
    } else {
      // Fallback: copy to clipboard
      try {
        await navigator.clipboard.writeText(url)
        // Could show a toast notification here
        alert('Link copied to clipboard!')
      } catch (error) {
        console.error('Copy failed:', error)
      }
    }
  }

  return (
    <RegistryLayout
      header={
        <div className="flex items-center justify-between py-4">
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <button
              onClick={() => navigate(-1)}
              className="flex items-center gap-2 text-ink-dull hover:text-ink-default transition-colors flex-shrink-0"
              aria-label="Go back"
            >
              <ArrowLeft className="h-5 w-5" />
              <span className="font-mono text-xs tracking-wider">Back</span>
            </button>
            <img
              src={agent.metadata.image ?? generateAvatar(agent.id)}
              alt={agent.metadata.name}
              className="w-10 h-10 rounded-full object-cover flex-shrink-0"
            />
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <h1 className="font-mono text-xl font-semibold text-ink-default truncate">
                {agent.metadata.name}
              </h1>
              {agent.metadata.version && (
                <Badge label={`v${agent.metadata.version}`} />
              )}
              <StaleIndicator isStale={isStale} />
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <SaveButton entityId={agent.id} entityType="agent" />
            <button
              onClick={handleShare}
              className="flex items-center gap-2 px-3 py-2 rounded-lg border border-app-line hover:bg-app-hover transition-colors font-mono text-xs tracking-wider"
              aria-label="Share agent"
            >
              <Share2 className="h-4 w-4" />
              Share
            </button>
          </div>
        </div>
      }
    >
      <div className="py-6 space-y-4">
        <StaleBanner chainHead={indexerLagBlocks} indexerHead={0} />
        {isAgentView ? (
          <>
            {/* Agent-view zones */}
            <AgentViewIdentityZone agent={agent} />
            <AgentViewCapabilityZone agent={agent} />

            {/* Skills Zone - simplified terminal list */}
            <div className="rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] p-4 font-mono text-sm">
              <div className="text-muted-foreground mb-4">=== SKILLS USED ===</div>
              {agent.triples
                .filter((t) => t.predicate.label === 'uses-skill')
                .map((triple, idx) => (
                  <div key={idx} className="text-foreground">
                    - {triple.object.label}
                  </div>
                ))}
              {agent.triples.filter((t) => t.predicate.label === 'uses-skill')
                .length === 0 && (
                <div className="text-muted-foreground italic">
                  NO_SKILLS_DECLARED
                </div>
              )}
            </div>

            <AgentViewTrustZone agent={agent} />

            {/* Relationships Zone - simplified terminal list */}
            <div className="rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] p-4 font-mono text-sm">
              <div className="text-muted-foreground mb-4">
                === RELATIONSHIPS ===
              </div>
              {agent.triples.map((triple, idx) => (
                <div key={idx} className="text-foreground mb-1">
                  <span className="text-muted-foreground">
                    [{triple.predicate.label}]
                  </span>{' '}
                  {triple.object.label}
                </div>
              ))}
              {agent.triples.length === 0 && (
                <div className="text-muted-foreground italic">
                  NO_RELATIONSHIPS
                </div>
              )}
            </div>

            {/* Trust Network - 1-hop neighborhood graph */}
            {agent.triples.length > 0 ? (
              <div className="rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] overflow-hidden">
                <div className="p-4 font-mono text-sm">
                  <div className="text-muted-foreground mb-2">=== TRUST NETWORK ===</div>
                  <div className="text-muted-foreground text-xs mb-4">1-HOP NEIGHBORHOOD GRAPH</div>
                </div>
                <div className="h-[350px]">
                  <TrustGraph
                    agents={allAgents}
                    skills={allSkills}
                    focusEntityId={agent.id}
                    onNodeClick={(id, type) => navigate(type === 'agent' ? `/agents/${id}` : `/skills/${id}`)}
                    compact
                    className="h-full w-full"
                  />
                </div>
              </div>
            ) : (
              <div className="rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] p-4 font-mono text-sm">
                <div className="text-muted-foreground mb-2">=== TRUST NETWORK ===</div>
                <div className="text-muted-foreground italic">NO_CONNECTIONS_FOUND</div>
              </div>
            )}

            {/* API Response Preview */}
            <ApiResponsePreview
              data={agent}
              endpoint={`/api/v1/agents/${agent.id}`}
            />
          </>
        ) : (
          <>
            {/* Human-view zones */}
            <AgentIdentityZone agent={agent} />
            <AgentCapabilityZone agent={agent} />
            <AgentSkillsZone agent={agent} />
            <TrustZone agent={agent} />
            <RelationshipZone agent={agent} />

            {/* Trust Network - 1-hop neighborhood graph */}
            {agent.triples.length > 0 ? (
              <section className="rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] overflow-hidden">
                <div className="p-4 border-b border-border">
                  <h2 className="font-mono text-xs tracking-widest uppercase text-ink-dull">Trust Network</h2>
                  <p className="font-mono text-xs text-ink-faint mt-1">
                    1-hop connections from this agent
                  </p>
                </div>
                <div className="h-[350px]">
                  <TrustGraph
                    agents={allAgents}
                    skills={allSkills}
                    focusEntityId={agent.id}
                    onNodeClick={(id, type) => navigate(type === 'agent' ? `/agents/${id}` : `/skills/${id}`)}
                    compact
                    className="h-full w-full"
                  />
                </div>
              </section>
            ) : (
              <section className="rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] p-4">
                <h2 className="font-mono text-xs tracking-widest uppercase text-ink-dull mb-2">Trust Network</h2>
                <p className="font-mono text-xs text-ink-faint">No connections found for this agent</p>
              </section>
            )}
          </>
        )}
      </div>
    </RegistryLayout>
  )
}
