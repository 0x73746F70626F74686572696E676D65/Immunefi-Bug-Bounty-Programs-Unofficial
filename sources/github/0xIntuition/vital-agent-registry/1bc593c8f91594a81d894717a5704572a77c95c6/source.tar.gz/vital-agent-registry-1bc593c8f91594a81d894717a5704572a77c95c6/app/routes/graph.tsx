import { useNavigate, useLoaderData } from 'react-router'
import { ArrowLeft } from 'lucide-react'
import { TrustGraph } from '~/components/graph/TrustGraph'
import { createRepository } from '~/data'
import { RegistryLayout } from '~/components/layout/RegistryLayout'
import { useViewMode } from '~/lib/providers/view-mode'

export function meta() {
  return [
    { title: 'Trust Graph — Intuition' },
    { name: 'description', content: 'Explore the trust graph of agents, skills, and their relationships.' },
  ]
}

export async function loader() {
  const repo = createRepository()
  const [agentResult, skillResult] = await Promise.all([
    repo.listAgents({ limit: 100 }),
    repo.listSkills({ limit: 100 }),
  ])
  return {
    agents: agentResult.items,
    skills: skillResult.items,
  }
}

export default function GraphPage() {
  const navigate = useNavigate()
  const { agents, skills } = useLoaderData<typeof loader>()
  const { isAgentView } = useViewMode()

  const totalNodes = agents.length + skills.length

  return (
    <RegistryLayout>
      <div className="flex h-full w-full flex-col">
        {/* Header */}
        <div className="flex items-center gap-3 border-b border-app-line bg-app-box-dark/80 px-4 py-3 backdrop-blur-md">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="flex h-9 w-9 items-center justify-center rounded-lg bg-app-button hover:bg-app-button-hover transition-colors"
            aria-label="Go back"
          >
            <ArrowLeft className="h-5 w-5 text-ink-default" />
          </button>
          <div>
            <h1 className={`text-sm font-semibold text-ink-default ${isAgentView ? 'font-mono' : ''}`}>
              {isAgentView ? '> TRUST_GRAPH' : 'Trust Graph'}
            </h1>
            <p className={`text-[10px] text-ink-dull ${isAgentView ? 'font-mono' : ''}`}>
              {isAgentView
                ? `> NODES: ${totalNodes} (${agents.length} agents, ${skills.length} skills) // LAYOUT: force-directed`
                : `${agents.length} agents, ${skills.length} skills · Force-directed layout`
              }
            </p>
          </div>
        </div>

        {/* Legend */}
        <div className={`border-b border-app-line bg-app-box/80 px-4 py-2 backdrop-blur ${isAgentView ? 'font-mono text-xs' : 'text-sm'}`}>
          <div className="flex flex-wrap items-center gap-4">
            {isAgentView ? (
              <>
                <div className="flex items-center gap-2">
                  <svg width="16" height="16">
                    <circle cx="8" cy="8" r="6" fill="hsl(120 20% 10%)" stroke="hsl(120 100% 69%)" strokeWidth="2" />
                  </svg>
                  <span className="text-[hsl(120_100%_69%)]">[AGENT]</span>
                </div>
                <div className="flex items-center gap-2">
                  <svg width="16" height="16">
                    <rect x="2" y="2" width="12" height="12" rx="2" fill="hsl(120 20% 10%)" stroke="hsl(120 100% 69%)" strokeWidth="2" />
                  </svg>
                  <span className="text-[hsl(120_100%_69%)]">[SKILL]</span>
                </div>
                <span className="text-[hsl(120_80%_60%)]">// Node size = trust percentile</span>
              </>
            ) : (
              <>
                <div className="flex items-center gap-2">
                  <svg width="16" height="16">
                    <circle cx="8" cy="8" r="6" fill="var(--brand, #6366f1)" stroke="currentColor" strokeWidth="1" />
                  </svg>
                  <span>Agent (colored by trust tier)</span>
                </div>
                <div className="flex items-center gap-2">
                  <svg width="16" height="16">
                    <rect x="2" y="4" width="12" height="8" rx="2" fill="#22c55e" stroke="currentColor" strokeWidth="1" />
                  </svg>
                  <span>Skill (colored by safety status)</span>
                </div>
                <span className="text-muted-foreground text-xs">• Node size indicates trust signal strength</span>
              </>
            )}
          </div>
        </div>

        {/* Graph Container */}
        <div className="flex-1 min-h-[60vh]">
          <TrustGraph
            agents={agents}
            skills={skills}
            onNodeClick={(id, entityType) => {
              if (entityType === 'agent') {
                navigate(`/agents/${id}`)
              } else {
                navigate(`/skills/${id}`)
              }
            }}
            className="h-full w-full"
          />
        </div>
      </div>
    </RegistryLayout>
  )
}
