/**
 * Capability — an ability an agent or skill can have
 *
 * Capabilities are represented as Atoms on-chain. They form the
 * basis for agent/skill discovery and matching.
 */
export interface Capability {
  /** Unique identifier (lowercase-hyphenated slug, e.g. "code-generation") */
  id: string
  /** Human-readable name */
  name: string
  /** Category slug (e.g. "ai", "web3", "research", "content", "automation") */
  category: string
  /** What this capability does */
  description: string
}

/**
 * CapabilityCategory — grouping for related capabilities
 */
export interface CapabilityCategory {
  /** Category identifier slug */
  id: string
  /** Human-readable name */
  name: string
  /** Category description */
  description: string
}
