import { useMemo } from 'react'

interface SparklineProps {
  data: number[]
  width?: number
  height?: number
  className?: string
}

export function Sparkline({ data, width = 48, height = 20, className }: SparklineProps) {
  const { points, fillPoints, isUp, gradientId } = useMemo(() => {
    if (data.length < 2) return { points: '', fillPoints: '', isUp: true, gradientId: '' }

    const min = Math.min(...data)
    const max = Math.max(...data)
    const range = max - min || 1
    const padding = 1

    const pts = data.map((value, i) => {
      const x = (i / (data.length - 1)) * (width - padding * 2) + padding
      const y = height - padding - ((value - min) / range) * (height - padding * 2)
      return `${x},${y}`
    })

    const id = `sparkline-${Math.random().toString(36).slice(2, 8)}`

    return {
      points: pts.join(' '),
      fillPoints: `${padding},${height - padding} ${pts.join(' ')} ${width - padding},${height - padding}`,
      isUp: data[data.length - 1] >= data[0],
      gradientId: id,
    }
  }, [data, width, height])

  if (data.length < 2) return null

  const color = isUp ? 'var(--color-gain)' : 'var(--color-loss)'

  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity={0.3} />
          <stop offset="100%" stopColor={color} stopOpacity={0} />
        </linearGradient>
      </defs>
      <polygon
        points={fillPoints}
        fill={`url(#${gradientId})`}
      />
      <polyline
        points={points}
        fill="none"
        stroke={color}
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}
