import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { describe, expect, it } from 'vitest'
import type { ActionFunctionArgs } from 'react-router'
import { action } from '../api+/v1.context.query'

function makeActionArgs(body: unknown): ActionFunctionArgs {
  return {
    request: new Request('https://registry.local/api/v1/context/query', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    }),
    params: {},
    context: {},
  } as ActionFunctionArgs
}

async function loadFixture(name: string) {
  const fixturePath = resolve(
    process.cwd(),
    'app/routes/__tests__/fixtures',
    name,
  )
  const raw = await readFile(fixturePath, 'utf8')
  return JSON.parse(raw) as unknown
}

describe('POST /api/v1/context/query', () => {
  it('returns base and nested context layers in one response', async () => {
    const fixture = await loadFixture('context-query.fixture.json')
    const response = await action(makeActionArgs(fixture))
    expect(response.status).toBe(200)
    const json = await response.json()

    expect(Array.isArray(json.data.baseLayer.claims)).toBe(true)
    expect(Array.isArray(json.data.contextLayer.claims)).toBe(true)
    expect(typeof json.data.discrepancy.score).toBe('number')
    expect(json.data.contextLayer.predicatesUsed).toEqual([
      'during-period',
      'in-context-of',
    ])
  })

  it('rejects non-canonical context predicates', async () => {
    const response = await action(makeActionArgs({
      baseClaims: [],
      contextClaims: [
        {
          subject: 'agent:planner',
          predicate: 'depends-on',
          object: 'agent:executor',
        },
      ],
    }))

    expect(response.status).toBe(400)
    const json = await response.json()
    expect(json.code).toBe('NON_CANONICAL_PREDICATE')
  })

  it('rejects semantically dense predicate patterns', async () => {
    const response = await action(makeActionArgs({
      baseClaims: [],
      contextClaims: [
        {
          subject: 'agent:planner',
          predicate: 'in-context-of',
          object: 'task:incident-response',
        },
        {
          subject: 'agent:planner',
          predicate: 'during-period',
          object: 'task:incident-response',
        },
      ],
    }))

    expect(response.status).toBe(400)
    const json = await response.json()
    expect(json.code).toBe('SEMANTIC_DENSITY_REJECTED')
    expect(typeof json.details.guidance).toBe('string')
  })
})
