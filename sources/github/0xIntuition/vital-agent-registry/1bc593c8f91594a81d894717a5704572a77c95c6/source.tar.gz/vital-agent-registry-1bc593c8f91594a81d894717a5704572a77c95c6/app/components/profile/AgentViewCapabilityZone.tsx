import type { Agent } from '~/types'
import { cn } from '~/lib/utils'

interface AgentViewCapabilityZoneProps {
  agent: Agent
  className?: string
}

export function AgentViewCapabilityZone({
  agent,
  className,
}: AgentViewCapabilityZoneProps) {
  return (
    <div
      className={cn(
        'rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] p-4 font-mono text-sm',
        className,
      )}
    >
      <div className="text-muted-foreground mb-4">=== CAPABILITIES ===</div>

      {/* Capability matrix grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
        {agent.capabilities.map((capability) => (
          <div
            key={capability.id}
            className="text-foreground border border-border/50 px-3 py-2 rounded"
          >
            [{capability.name}]
          </div>
        ))}
      </div>

      {agent.capabilities.length === 0 && (
        <div className="text-muted-foreground italic">
          NO_CAPABILITIES_DECLARED
        </div>
      )}
    </div>
  )
}
