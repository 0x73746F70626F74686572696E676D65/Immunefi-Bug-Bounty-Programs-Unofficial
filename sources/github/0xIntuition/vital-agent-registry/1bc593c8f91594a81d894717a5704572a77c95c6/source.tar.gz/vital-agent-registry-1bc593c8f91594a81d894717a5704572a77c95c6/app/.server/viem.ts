import { createPublicClient, createWalletClient, http, type Chain } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { CHAINS } from '~/lib/constants/protocol';

/**
 * Intuition Local Anvil chain definition for viem.
 * Chain ID: 31337 (Anvil default)
 * RPC: http://localhost:8545
 */
export const intuitionLocal: Chain = {
  id: 31337,
  name: 'Intuition Local',
  nativeCurrency: {
    decimals: 18,
    name: 'ETH',
    symbol: 'ETH',
  },
  rpcUrls: {
    default: {
      http: [process.env.LOCAL_CHAIN_RPC_URL || 'http://localhost:8545'],
    },
  },
  contracts: {
    multicall3: {
      address: '0xcA11bde05977b3631167028862bE2a173976CA11',
      blockCreated: 0,
    },
  },
};

/**
 * Intuition Testnet chain definition for viem.
 *
 * Chain ID: 13579
 * Native token: tTRUST
 */
export const intuitionTestnet: Chain = {
  id: 13579,
  name: 'Intuition Testnet',
  nativeCurrency: {
    decimals: 18,
    name: 'tTRUST',
    symbol: 'tTRUST',
  },
  rpcUrls: {
    default: {
      http: [CHAINS.TESTNET.rpcUrl],
    },
  },
  blockExplorers: {
    default: {
      name: 'Intuition Testnet Explorer',
      url: 'https://testnet.explorer.intuition.systems',
    },
  },
  contracts: {
    multicall3: {
      address: '0xcA11bde05977b3631167028862bE2a173976CA11',
      blockCreated: 0,
    },
  },
};

/**
 * Intuition Mainnet chain definition for viem.
 *
 * Chain ID: 1155
 * Native token: TRUST
 */
export const intuitionMainnet: Chain = {
  id: 1155,
  name: 'Intuition Mainnet',
  nativeCurrency: {
    decimals: 18,
    name: 'TRUST',
    symbol: 'TRUST',
  },
  rpcUrls: {
    default: {
      http: [CHAINS.MAINNET.rpcUrl],
    },
  },
  blockExplorers: {
    default: {
      name: 'Intuition Explorer',
      url: 'https://explorer.intuition.systems',
    },
  },
  contracts: {
    multicall3: {
      address: '0xcA11bde05977b3631167028862bE2a173976CA11',
      blockCreated: 0,
    },
  },
};

/**
 * Creates a public client for reading from the Intuition blockchain.
 *
 * Public clients are used for read-only operations like querying contract state,
 * fetching atom/triple data, and checking vault balances.
 *
 * @param chain - Which chain to connect to ('testnet' or 'mainnet')
 * @returns A configured viem PublicClient
 *
 * @example
 * ```typescript
 * const client = createRegistryPublicClient('testnet');
 * const atomCost = await client.readContract({
 *   address: CONTRACTS.MULTIVAULT_TESTNET,
 *   abi: multivaultAbi,
 *   functionName: 'getAtomCost',
 * });
 * ```
 */
export function createRegistryPublicClient(chain: 'testnet' | 'mainnet' | 'local' = 'testnet') {
  let chainConfig: Chain
  let rpcUrl: string

  switch (chain) {
    case 'local':
      chainConfig = intuitionLocal
      rpcUrl = process.env.LOCAL_CHAIN_RPC_URL || 'http://localhost:8545'
      break
    case 'testnet':
      chainConfig = intuitionTestnet
      rpcUrl = CHAINS.TESTNET.rpcUrl
      break
    case 'mainnet':
      chainConfig = intuitionMainnet
      rpcUrl = CHAINS.MAINNET.rpcUrl
      break
  }

  return createPublicClient({
    ...(chain !== 'local' ? { batch: { multicall: true } } : {}),
    chain: chainConfig,
    transport: http(rpcUrl),
  });
}

/**
 * Creates a wallet client for writing to the Intuition blockchain.
 *
 * Wallet clients are used for write operations like creating atoms/triples,
 * depositing into vaults, and other state-changing transactions.
 *
 * **Security**: This should only be used in server-side code (scripts, bootstrap).
 * Never expose private keys to the client bundle.
 *
 * @param privateKey - The private key for signing transactions (must start with 0x)
 * @param chain - Which chain to connect to ('testnet' or 'mainnet')
 * @returns A configured viem WalletClient
 *
 * @example
 * ```typescript
 * const privateKey = process.env.WALLET_PRIVATE_KEY as `0x${string}`;
 * const client = createRegistryWalletClient(privateKey, 'testnet');
 * const hash = await client.writeContract({
 *   address: CONTRACTS.MULTIVAULT_TESTNET,
 *   abi: multivaultAbi,
 *   functionName: 'createAtoms',
 *   args: [[atomData], [depositAmount]],
 *   value: totalCost,
 * });
 * ```
 */
export function createRegistryWalletClient(
  privateKey: `0x${string}`,
  chain: 'testnet' | 'mainnet' | 'local' = 'testnet'
) {
  let chainConfig: Chain
  let rpcUrl: string

  switch (chain) {
    case 'local':
      chainConfig = intuitionLocal
      rpcUrl = process.env.LOCAL_CHAIN_RPC_URL || 'http://localhost:8545'
      break
    case 'testnet':
      chainConfig = intuitionTestnet
      rpcUrl = CHAINS.TESTNET.rpcUrl
      break
    case 'mainnet':
      chainConfig = intuitionMainnet
      rpcUrl = CHAINS.MAINNET.rpcUrl
      break
  }
  const account = privateKeyToAccount(privateKey);

  return createWalletClient({
    account,
    chain: chainConfig,
    transport: http(rpcUrl),
  });
}
