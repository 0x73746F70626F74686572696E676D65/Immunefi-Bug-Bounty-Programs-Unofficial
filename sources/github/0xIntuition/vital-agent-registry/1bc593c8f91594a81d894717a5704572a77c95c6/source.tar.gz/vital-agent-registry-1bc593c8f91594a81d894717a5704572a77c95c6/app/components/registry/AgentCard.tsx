import { Link } from 'react-router'
import type { Agent } from '~/types'
import { cn } from '~/lib/utils'
import { formatCompact } from '~/lib/formatting'
import { getSecurityLevelLabel, getSecurityLevelBadgeColors } from '~/lib/security'
import { Card, CardHeader, CardContent, CardFooter } from '~/components/ui/card'
import { Tooltip } from '~/components/ui/tooltip'
import { TrustTierBadge } from './TrustTierBadge'
import { DomainScoreBadge } from './DomainScoreBadge'
import { Badge } from '~/components/ui/Badge'
import { SaveButton } from '~/components/ui/SaveButton'
import { useCardVariant } from '~/lib/hooks/useCardVariant'

interface AgentCardProps {
  agent: Agent
  className?: string
}

const TRUST_TIER_COLORS = {
  platinum: 'border-[hsl(185_80%_55%/0.5)] bg-[hsl(185_80%_55%/0.1)]',
  gold: 'border-[hsl(38_92%_50%/0.5)] bg-[hsl(38_92%_50%/0.1)]',
  silver: 'border-[hsl(210_10%_60%/0.5)] bg-[hsl(210_10%_60%/0.1)]',
  bronze: 'border-[hsl(25_60%_45%/0.5)] bg-[hsl(25_60%_45%/0.1)]',
  unranked: '',
} as const

export function AgentCard({ agent, className }: AgentCardProps) {
  const { variant } = useCardVariant()
  const { metadata, trustSignal, capabilities } = agent

  const avatarFallback = metadata.name.charAt(0).toUpperCase()
  const visibleCapabilities = capabilities.slice(0, 3)
  const remainingCount = Math.max(0, capabilities.length - 3)
  const tierAccent = TRUST_TIER_COLORS[trustSignal.tier]

  // Security level
  const securityLevel = agent.securityProfile?.level
  const securityBadgeColors = securityLevel ? getSecurityLevelBadgeColors(securityLevel) : null

  // Top 2 domain scores by quality
  const topDomainScores = agent.reputationProfile?.domainScores
    .slice()
    .sort((a, b) => b.avgQuality - a.avgQuality)
    .slice(0, 2) ?? []

  if (variant === 'compact') {
    return (
      <Link
        to={`/agents/${agent.id}`}
        className={cn(
          'block focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-2 focus-visible:outline-none rounded-[var(--radius-badge)]',
          className,
        )}
      >
        <div
          className={cn(
            'flex items-center gap-3 rounded-xl border border-app-line bg-app-box px-3 py-2 shadow-[var(--shadow-card)] transition-all hover:bg-app-box-light hover:shadow-[var(--shadow-card-hover)]',
            tierAccent,
          )}
        >
          {metadata.image ? (
            <img src={metadata.image} alt={metadata.name} width={24} height={24} className="h-6 w-6 flex-shrink-0 rounded-full object-cover" />
          ) : (
            <div className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-brand/20 text-xs font-bold text-brand">
              {avatarFallback}
            </div>
          )}
          <span className="min-w-0 flex-1 truncate text-sm font-medium text-card-foreground">
            {metadata.name}
          </span>
          <TrustTierBadge tier={trustSignal.tier} percentile={trustSignal.percentile} size="sm" />
          <span className="text-xs text-muted-foreground">{trustSignal.totalStaked} TRUST</span>
        </div>
      </Link>
    )
  }

  return (
    <Link
      to={`/agents/${agent.id}`}
      className={cn(
        'block focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-2 focus-visible:outline-none rounded-[var(--radius-card)]',
        className,
      )}
    >
      <Card
        className={cn(
          'relative flex h-full flex-col transition-all hover:bg-app-box-light hover:shadow-[var(--shadow-card-hover)]',
          tierAccent,
        )}
      >
        <SaveButton entityId={agent.id} entityType="agent" className="absolute top-3 right-3 z-10" />
        <CardHeader className="flex flex-row items-center gap-3 space-y-0">
          {metadata.image ? (
            <img
              src={metadata.image}
              alt={metadata.name}
              width={40}
              height={40}
              className="h-10 w-10 flex-shrink-0 rounded-full object-cover"
            />
          ) : (
            <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-brand/20 font-bold text-brand">
              {avatarFallback}
            </div>
          )}
          <div className="min-w-0 flex-1 space-y-1 overflow-hidden">
            <div className="truncate font-semibold leading-none text-card-foreground">
              {metadata.name}
            </div>
            {metadata.provider?.name && (
              <div className="truncate text-sm text-muted-foreground">
                {metadata.provider.name}
              </div>
            )}
          </div>
        </CardHeader>

        <CardContent className="flex flex-1 flex-col gap-3">
          {/* Trust + Security badges row */}
          <div className="flex flex-wrap items-center gap-1.5">
            <TrustTierBadge tier={trustSignal.tier} percentile={trustSignal.percentile} size="sm" />
            {securityLevel && securityBadgeColors && (
              <Badge variant="outline" className={cn('gap-1', securityBadgeColors)}>
                {getSecurityLevelLabel(securityLevel)}
              </Badge>
            )}
          </div>

          {/* Domain scores */}
          {topDomainScores.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {topDomainScores.map(score => (
                <DomainScoreBadge key={score.domain} score={score} />
              ))}
            </div>
          )}

          <p className="line-clamp-2 text-sm text-muted-foreground">
            {metadata.description || <span className="italic">No description provided</span>}
          </p>

          {capabilities.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {visibleCapabilities.map(cap => (
                <Badge key={cap.id} label={cap.name} />
              ))}
              {remainingCount > 0 && (
                <Tooltip
                  content={
                    <div className="max-w-xs space-y-1">
                      {capabilities.slice(3).map(cap => (
                        <div key={cap.id} className="text-xs">
                          {cap.name}
                        </div>
                      ))}
                    </div>
                  }
                >
                  <Badge
                    label={`+${remainingCount} more`}
                    className="cursor-help"
                  />
                </Tooltip>
              )}
            </div>
          )}

          {/* Detailed variant: show all capabilities + extra metrics */}
          {variant === 'detailed' && (
            <>
              {remainingCount > 0 && (
                <div className="flex flex-wrap gap-1.5 border-t border-border pt-2">
                  {capabilities.slice(3).map(cap => (
                    <Badge key={cap.id} label={cap.name} />
                  ))}
                </div>
              )}
              {agent.reputationProfile && (
                <div className="flex items-center gap-3 text-xs text-muted-foreground border-t border-border pt-2">
                  <span>Quality: {agent.reputationProfile.avgQuality}/100</span>
                  <span>&middot;</span>
                  <span>Tasks: {formatCompact(agent.reputationProfile.totalTasks)}</span>
                  <span>&middot;</span>
                  <span>Success: {Math.round(agent.reputationProfile.successRate * 100)}%</span>
                </div>
              )}
            </>
          )}
        </CardContent>

        <CardFooter className="text-xs text-muted-foreground">
          <span>{formatCompact(trustSignal.stakerCount)} stakers</span>
          <span className="mx-2">&middot;</span>
          <span>{trustSignal.totalStaked} TRUST</span>
        </CardFooter>
      </Card>
    </Link>
  )
}
