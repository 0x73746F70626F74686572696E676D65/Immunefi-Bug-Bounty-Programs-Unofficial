import { createHash } from 'node:crypto'
import { z } from 'zod'

const semverSchema = z.string().regex(/^\d+\.\d+\.\d+$/)
const namespaceKeySchema = z.string().regex(/^[a-z0-9]+(\.[a-z0-9-]+)+$/)

export const trustDomainSchema = z.enum([
  'agent-discovery',
  'safety',
  'execution-reliability',
  'economic-trust',
  'custom',
])

export const trustInputDeclarationSchema = z.object({
  key: z.string().min(1),
  source: z.enum(['candidate', 'graph', 'vault', 'policy', 'runtime', 'external']),
  type: z.enum(['number', 'boolean', 'string', 'array:number']),
  required: z.boolean().default(true),
  defaultValue: z.union([z.number(), z.boolean(), z.string(), z.array(z.number())]).optional(),
  description: z.string().min(1),
})

const formulaNodeSchema: z.ZodTypeAny = z.lazy(() =>
  z.union([
    z.object({
      op: z.enum(['const']),
      value: z.number(),
    }),
    z.object({
      op: z.enum(['input']),
      key: z.string().min(1),
    }),
    z.object({
      op: z.enum(['add', 'sub', 'mul', 'div', 'min', 'max']),
      args: z.array(formulaNodeSchema).min(2),
    }),
    z.object({
      op: z.enum(['weighted_sum']),
      terms: z.array(
        z.object({
          weight: z.number(),
          value: formulaNodeSchema,
        }),
      ).min(1),
    }),
    z.object({
      op: z.enum(['clamp']),
      value: formulaNodeSchema,
      min: z.number(),
      max: z.number(),
    }),
  ]),
)

export const trustFormulaSpecSchema = z.object({
  language: z.literal('trust-formula-v1'),
  root: formulaNodeSchema,
})

export const trustNormalizationSchema = z.object({
  method: z.enum(['none', 'minmax', 'zscore', 'rank-percentile']),
  clampMin: z.number().optional(),
  clampMax: z.number().optional(),
})

export const trustOutputSemanticsSchema = z.object({
  scoreRange: z.object({
    min: z.number(),
    max: z.number(),
  }),
  confidenceRange: z.object({
    min: z.number(),
    max: z.number(),
  }),
  interpretation: z.string().min(1),
})

export const trustModelArtifactSchema = z.object({
  modelId: z.string().min(1),
  version: semverSchema,
  author: z.string().min(1),
  domain: trustDomainSchema,
  inputs: z.array(trustInputDeclarationSchema).min(1),
  formulaSpec: trustFormulaSpecSchema,
  normalization: trustNormalizationSchema,
  outputSemantics: trustOutputSemanticsSchema,
  compatibility: z.object({
    minCompatibleVersion: semverSchema.optional(),
    breaking: z.boolean().default(false),
    notes: z.string().min(1).optional(),
  }),
  extensions: z.record(namespaceKeySchema, z.record(z.string(), z.unknown())).optional(),
}).superRefine((value, ctx) => {
  if (value.normalization.clampMin !== undefined &&
      value.normalization.clampMax !== undefined &&
      value.normalization.clampMin > value.normalization.clampMax) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'normalization clampMin must be <= clampMax',
      path: ['normalization', 'clampMin'],
    })
  }
  if (value.outputSemantics.scoreRange.min >= value.outputSemantics.scoreRange.max) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'outputSemantics scoreRange min must be < max',
      path: ['outputSemantics', 'scoreRange'],
    })
  }
  if (value.outputSemantics.confidenceRange.min >= value.outputSemantics.confidenceRange.max) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'outputSemantics confidenceRange min must be < max',
      path: ['outputSemantics', 'confidenceRange'],
    })
  }
})

export type TrustModelArtifact = z.infer<typeof trustModelArtifactSchema>

export function stableStringify(value: unknown): string {
  if (value === null || typeof value !== 'object') {
    return JSON.stringify(value)
  }
  if (Array.isArray(value)) {
    return `[${value.map((item) => stableStringify(item)).join(',')}]`
  }
  const entries = Object.entries(value).sort(([a], [b]) => a.localeCompare(b))
  return `{${entries
    .map(([key, val]) => `${JSON.stringify(key)}:${stableStringify(val)}`)
    .join(',')}}`
}

export function canonicalizeTrustModelArtifact(
  input: unknown,
): { artifact: TrustModelArtifact; canonical: string } {
  const artifact = trustModelArtifactSchema.parse(input)
  return {
    artifact,
    canonical: stableStringify(artifact),
  }
}

export function getTrustModelRef(artifact: TrustModelArtifact): string {
  return `${artifact.modelId}@${artifact.version}`
}

export function getTrustModelDigest(artifact: TrustModelArtifact): string {
  const canonical = stableStringify(artifact)
  return createHash('sha256').update(canonical).digest('hex')
}
