import type { TrustTier } from '~/types'
import { cn } from '~/lib/utils'
import { TrustTierTooltip } from '~/components/ui/TrustTierTooltip'

interface TrustTierBadgeProps {
  tier: TrustTier
  percentile?: number
  size?: 'sm' | 'md'
  className?: string
}

const tierColors: Record<TrustTier, { bg: string; text: string }> = {
  platinum: {
    bg: 'hsl(280 83% 58%)',
    text: 'hsl(280 83% 58%)',
  },
  gold: {
    bg: 'hsl(38 92% 50%)',
    text: 'hsl(38 92% 50%)',
  },
  silver: {
    bg: 'hsl(210 10% 60%)',
    text: 'hsl(210 10% 60%)',
  },
  bronze: {
    bg: 'hsl(25 60% 45%)',
    text: 'hsl(25 60% 45%)',
  },
  unranked: {
    bg: 'transparent',
    text: 'hsl(0 0% 40%)',
  },
}

const tierLabels: Record<TrustTier, string> = {
  platinum: 'Platinum',
  gold: 'Gold',
  silver: 'Silver',
  bronze: 'Bronze',
  unranked: 'Unranked',
}

export function TrustTierBadge({
  tier,
  percentile,
  size = 'md',
  className,
}: TrustTierBadgeProps) {
  const colors = tierColors[tier]
  const label = tierLabels[tier]

  const sizeClasses = size === 'sm'
    ? 'text-[10px] px-1.5 py-0.5'
    : 'text-xs px-2 py-0.5'

  const badge = (
    <span
      className={cn(
        'inline-flex items-center rounded-[var(--radius-badge)] font-medium uppercase tracking-wider',
        sizeClasses,
        className,
      )}
      style={{
        backgroundColor: tier === 'unranked' ? 'transparent' : `color-mix(in srgb, ${colors.bg} 15%, transparent)`,
        color: colors.text,
      }}
    >
      {label}
    </span>
  )

  if (typeof percentile === 'number') {
    return (
      <TrustTierTooltip tier={tier} percentile={percentile}>
        <span>{badge}</span>
      </TrustTierTooltip>
    )
  }

  return badge
}
