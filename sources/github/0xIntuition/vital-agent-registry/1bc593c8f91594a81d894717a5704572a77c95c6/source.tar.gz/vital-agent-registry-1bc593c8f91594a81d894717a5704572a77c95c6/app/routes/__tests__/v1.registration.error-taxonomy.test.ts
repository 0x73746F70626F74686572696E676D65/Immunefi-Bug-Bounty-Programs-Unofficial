import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
const mocks = vi.hoisted(() => ({
  uploadAgentMetadata: vi.fn(),
  uploadSkillMetadata: vi.fn(),
  getAtomCost: vi.fn(),
  getTripleCost: vi.fn(),
}))

vi.mock('~/.server/ipfs', async () => {
  const actual = await vi.importActual<typeof import('~/.server/ipfs')>('~/.server/ipfs')
  return {
    ...actual,
    uploadAgentMetadata: mocks.uploadAgentMetadata,
    uploadSkillMetadata: mocks.uploadSkillMetadata,
  }
})

vi.mock('~/.server/multivault', () => ({
  getAtomCost: mocks.getAtomCost,
  getTripleCost: mocks.getTripleCost,
  createAtoms: vi.fn(),
  createTriples: vi.fn(),
  getAtomByUri: vi.fn(),
  getMinimumDeposit: vi.fn(),
}))

vi.mock('~/lib/calldata', () => ({
  encodeCreateAtomCalldata: vi.fn(() => '0xdeadbeef'),
  encodeCreateTriplesCalldata: vi.fn(() => '0xbeadfeed'),
  deriveAtomTermId: vi.fn(() => '0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc'),
  deriveIdentityAtomTermId: vi.fn(() => '0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb'),
  encodeIdentityAtomData: vi.fn(() => '{"name":"test","namespace":"intuition-agent"}'),
}))

vi.mock('~/lib/abis/multivault', () => ({
  multivaultAbi: [],
}))

vi.mock('~/.server/remote-write-guard', () => ({
  assertRemoteWriteAllowed: vi.fn(),
  RemoteWriteGuardError: class RemoteWriteGuardError extends Error {
    code: string
    profile: string
    target: string
    action: string
    constructor(message: string, code: string, profile: string, target: string, action: string) {
      super(message)
      this.code = code
      this.profile = profile
      this.target = target
      this.action = action
    }
  },
}))

vi.mock('~/.server/local-write', () => ({
  createLocalWriteClients: vi.fn(),
  getLocalWriteContext: vi.fn(),
}))

vi.mock('~/.server/local-agent-cache', () => ({
  storeLocalAgent: vi.fn(),
}))

vi.mock('~/lib/rate-limit', () => ({
  registrationLimiter: { check: () => ({ allowed: true, resetAt: Date.now() + 60000 }) },
  getClientIP: vi.fn(() => '127.0.0.1'),
  isRegistrationRateLimitEnabled: vi.fn(() => false),
}))

vi.mock('viem', () => ({
  createPublicClient: vi.fn(() => ({})),
  http: vi.fn(() => ({})),
  parseEventLogs: vi.fn(() => []),
  toHex: vi.fn((str: string) => `0x${Buffer.from(str).toString('hex')}`),
  encodeFunctionData: vi.fn(() => '0xdeadbeef'),
  keccak256: vi.fn(() => '0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'),
  pad: vi.fn((val: string) => val as `0x${string}`),
}))

describe('registration error taxonomy', () => {
  const baseEnv = { ...process.env }

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = {
      ...baseEnv,
      CHAIN: 'testnet',
      ALLOW_REMOTE_WRITES: '1',
      REGISTRY_WRITE_PROFILE: 'shared',
    }
    mocks.getAtomCost.mockResolvedValue(123n)
    mocks.getTripleCost.mockResolvedValue(10n)
  })

  afterEach(() => {
    process.env = { ...baseEnv }
  })

  it('maps agent validation upload errors to 400', async () => {
    const { IpfsUploadError } = await vi.importActual<typeof import('~/.server/ipfs')>(
      '~/.server/ipfs',
    )
    mocks.uploadAgentMetadata.mockRejectedValueOnce(
      new IpfsUploadError('metadata payload exceeds 4096 bytes', 'validation'),
    )
    const { action } = await import('../api+/v1.agents.register')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/agents/register', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          name: 'Taxonomy Agent',
          description: 'Agent',
          version: '1.0.0',
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(400)
    const body = await response.json()
    expect(body.code).toBe('VALIDATION_ERROR')
  })

  it('maps skill upstream upload errors to 502', async () => {
    const { IpfsUploadError } = await vi.importActual<typeof import('~/.server/ipfs')>(
      '~/.server/ipfs',
    )
    mocks.uploadSkillMetadata.mockRejectedValueOnce(
      new IpfsUploadError('Pinata upload failed (503): unavailable', 'upstream'),
    )
    const { action } = await import('../api+/v1.skills.register')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/skills/register', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          name: 'Taxonomy Skill',
          description: 'Skill',
          version: '1.0.0',
          platform: 'mcp',
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(502)
    const body = await response.json()
    expect(body.code).toBe('UPSTREAM_IPFS_ERROR')
  })
})
