import { describe, expect, it } from 'vitest';
import { computeTermId, isValidTermId } from './term-id';

describe('computeTermId', () => {
  it('should compute a term_id from atom data', async () => {
    const atomData = 'ipfs://QmTest123';
    const termId = await computeTermId(atomData);

    expect(termId).toMatch(/^0x[0-9a-f]{64}$/);
  });

  it('should produce consistent hashes for the same input', async () => {
    const atomData = 'ipfs://QmTest123';
    const termId1 = await computeTermId(atomData);
    const termId2 = await computeTermId(atomData);

    expect(termId1).toBe(termId2);
  });

  it('should produce different hashes for different inputs', async () => {
    const termId1 = await computeTermId('ipfs://QmTest123');
    const termId2 = await computeTermId('ipfs://QmTest456');

    expect(termId1).not.toBe(termId2);
  });

  it('should handle empty strings', async () => {
    const termId = await computeTermId('');
    expect(termId).toMatch(/^0x[0-9a-f]{64}$/);
  });

  it('should handle unicode characters', async () => {
    const termId = await computeTermId('ipfs://Qm🚀💡');
    expect(termId).toMatch(/^0x[0-9a-f]{64}$/);
  });
});

describe('isValidTermId', () => {
  it('should accept valid term_ids', () => {
    const validId =
      '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef';
    expect(isValidTermId(validId)).toBe(true);
  });

  it('should accept term_ids with uppercase hex', () => {
    const validId =
      '0x1234567890ABCDEF1234567890ABCDEF1234567890ABCDEF1234567890ABCDEF';
    expect(isValidTermId(validId)).toBe(true);
  });

  it('should accept term_ids with mixed case', () => {
    const validId =
      '0x1234567890AbCdEf1234567890AbCdEf1234567890AbCdEf1234567890AbCdEf';
    expect(isValidTermId(validId)).toBe(true);
  });

  it('should reject term_ids without 0x prefix', () => {
    const invalidId =
      '1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef';
    expect(isValidTermId(invalidId)).toBe(false);
  });

  it('should reject term_ids that are too short', () => {
    const invalidId = '0x123';
    expect(isValidTermId(invalidId)).toBe(false);
  });

  it('should reject term_ids that are too long', () => {
    const invalidId =
      '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef00';
    expect(isValidTermId(invalidId)).toBe(false);
  });

  it('should reject term_ids with invalid hex characters', () => {
    const invalidId =
      '0xGGGG567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef';
    expect(isValidTermId(invalidId)).toBe(false);
  });

  it('should reject empty strings', () => {
    expect(isValidTermId('')).toBe(false);
  });

  it('should reject strings with special characters', () => {
    const invalidId =
      '0x1234567890abcdef@234567890abcdef1234567890abcdef1234567890abcdef';
    expect(isValidTermId(invalidId)).toBe(false);
  });
});
