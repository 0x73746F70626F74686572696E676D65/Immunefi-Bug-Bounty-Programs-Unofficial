import { useNavigate } from 'react-router'

interface NotFoundProps {
  message?: string
}

export function NotFound({ message = 'Not found' }: NotFoundProps) {
  const navigate = useNavigate()

  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-3 p-8 text-center">
      <p className="text-4xl font-bold text-foreground">404</p>
      <p className="text-lg font-semibold text-foreground">{message}</p>
      <button
        type="button"
        onClick={() => navigate('/')}
        className="mt-2 rounded-lg border border-app-line bg-app-button px-4 py-2 text-sm text-ink-dull transition-colors hover:bg-app-button-hover hover:text-ink-default"
      >
        Back to Registry
      </button>
    </div>
  )
}
