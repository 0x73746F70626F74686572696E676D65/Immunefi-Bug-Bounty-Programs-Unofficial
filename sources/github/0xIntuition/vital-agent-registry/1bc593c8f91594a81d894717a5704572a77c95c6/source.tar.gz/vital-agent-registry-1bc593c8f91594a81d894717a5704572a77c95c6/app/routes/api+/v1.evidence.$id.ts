import type { LoaderFunctionArgs } from 'react-router'
import { handleOptions, jsonResponse, errorResponse } from '~/lib/api/types'
import { getEvidenceBundle } from '~/lib/evidence/store'

export async function loader({ params, request }: LoaderFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const id = params.id
  if (!id) {
    return errorResponse('Evidence id is required', 'VALIDATION_ERROR', 400)
  }

  const bundle = getEvidenceBundle(id)
  if (!bundle) {
    return errorResponse('Evidence bundle not found', 'NOT_FOUND', 404)
  }

  if (Date.now() > Date.parse(bundle.expiresAt)) {
    return errorResponse('Evidence bundle expired', 'EVIDENCE_EXPIRED', 410, {
      expiresAt: bundle.expiresAt,
    })
  }

  return jsonResponse(bundle)
}
