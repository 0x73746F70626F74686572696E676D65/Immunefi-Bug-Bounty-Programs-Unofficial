import type { Variants } from 'motion/react'

export const routeDepth: Record<string, number> = {
  '/': 0,
  '/explore': 1,
  '/agent': 1,
  '/profile': 1,
  '/item': 2,
  '/saved': 0,
  '/me': 0,
}

export function getRouteDepth(pathname: string): number {
  // Match first path segment
  const segment = '/' + (pathname.split('/')[1] ?? '')
  return routeDepth[segment] ?? 0
}

export const slideUp: Variants = {
  initial: { y: '100%', opacity: 0 },
  animate: { y: 0, opacity: 1 },
  exit: { y: '100%', opacity: 0 },
}

export const slideRight: Variants = {
  initial: { x: '-30%', opacity: 0 },
  animate: { x: 0, opacity: 1 },
  exit: { x: '30%', opacity: 0 },
}

export const fadeIn: Variants = {
  initial: { opacity: 0 },
  animate: { opacity: 1 },
  exit: { opacity: 0 },
}
