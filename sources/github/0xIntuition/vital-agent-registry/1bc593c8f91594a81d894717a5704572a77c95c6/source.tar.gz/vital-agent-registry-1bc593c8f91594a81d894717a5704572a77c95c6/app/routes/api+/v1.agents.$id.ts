import { createRepository } from '~/data/repository/provider'
import { handleOptions, jsonResponse, errorResponse } from '~/lib/api/types'
import { findLocalAgent } from '~/.server/local-agent-cache'
import { serverGraphqlRequest } from '~/lib/graphql/client'
import { mapAtomToAgent } from '~/lib/graphql/mappers'
import type { GraphQLAtom } from '~/lib/graphql/mappers'
import type { LoaderFunctionArgs } from 'react-router'

const AGENT_TERM_ID_PATTERN = /^0x[0-9a-fA-F]{64}$/
const DEFAULT_LOCAL_GRAPHQL_URL = 'http://localhost:8080/v1/graphql'

const GET_AGENT_BY_TERM_ID = `
  query GetRegistryAgentByTermId($termId: String!) {
    atom(term_id: $termId) {
      term_id
      label
      image
      cached_image { url safe }
      type
      data
      created_at
      updated_at
      creator { id label image cached_image { url safe } }
      value {
        thing { name description image cached_image { url safe } url }
        json_object { description: data(path: "description") }
      }
      term {
        total_market_cap
        positions_aggregate { aggregate { count } }
        vaults(order_by: { curve_id: asc }) {
          term_id
          curve_id
          current_share_price
          total_shares
          total_assets
          position_count
          market_cap
        }
      }
      as_subject_triples {
        term_id
        predicate { term_id label }
        object {
          term_id
          label
          image
          cached_image { url safe }
          type
          data
          value {
            thing { name description image url }
            json_object { description: data(path: "description") }
          }
        }
      }
    }
  }
`

async function findAgentByTermIdBestEffort(termId: string) {
  if (!AGENT_TERM_ID_PATTERN.test(termId)) return null

  const apiUrl = process.env.GRAPHQL_API_URL_PRIVATE ?? DEFAULT_LOCAL_GRAPHQL_URL
  try {
    const response = await serverGraphqlRequest<{ atom: GraphQLAtom | null }>(
      apiUrl,
      GET_AGENT_BY_TERM_ID,
      { termId },
    )
    if (!response.atom) return null
    return mapAtomToAgent(response.atom, [])
  } catch {
    return null
  }
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const id = params.id!
  const repo = createRepository()
  let agent = await repo.findAgent(id)
  if (!agent) {
    agent = findLocalAgent(id)
  }
  if (!agent) {
    agent = await findAgentByTermIdBestEffort(id)
  }

  if (!agent) {
    return errorResponse('Agent not found', 'NOT_FOUND', 404)
  }

  return jsonResponse(agent)
}
