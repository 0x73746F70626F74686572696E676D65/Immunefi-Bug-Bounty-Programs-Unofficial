import { handleOptions, jsonResponse } from '~/lib/api/types'
import type { LoaderFunctionArgs } from 'react-router'

interface QueryRecipeParameter {
  type: string
  required: boolean
  description: string
}

interface QueryRecipeStep {
  method: string
  endpoint: string
  parameters?: Record<string, QueryRecipeParameter>
  expectedResponse: string
}

interface QueryRecipe {
  id: string
  name: string
  description: string
  steps: QueryRecipeStep[]
  tags: string[]
}

const RECIPES: QueryRecipe[] = [
  {
    id: 'discovery',
    name: 'Agent Discovery by Capability',
    description: 'Find agents that match specific capabilities using the match endpoint',
    steps: [
      {
        method: 'POST',
        endpoint: '/api/v1/agents/match',
        parameters: {
          capabilities: {
            type: 'string[]',
            required: true,
            description: 'Array of capability identifiers to match',
          },
          matchAll: {
            type: 'boolean',
            required: false,
            description: 'If true, agent must have all capabilities; if false, match any capability',
          },
        },
        expectedResponse: 'Array of agents matching the capability criteria with trust scores',
      },
    ],
    tags: ['discovery', 'search', 'capabilities'],
  },
  {
    id: 'delegation',
    name: 'Trust-Based Delegation',
    description: 'Evaluate agent trust before delegating tasks by fetching trust metrics and agent card',
    steps: [
      {
        method: 'GET',
        endpoint: '/api/v1/agents/:id/trust',
        parameters: {
          id: {
            type: 'string',
            required: true,
            description: 'Agent identifier (in URL path)',
          },
        },
        expectedResponse: 'Trust metrics including trust tier, safety score, and verification status',
      },
      {
        method: 'GET',
        endpoint: '/api/v1/agents/:id/card',
        parameters: {
          id: {
            type: 'string',
            required: true,
            description: 'Agent identifier (in URL path)',
          },
        },
        expectedResponse: 'Complete agent card with capabilities, connections, and metadata',
      },
    ],
    tags: ['delegation', 'trust', 'verification'],
  },
  {
    id: 'safety-verification',
    name: 'Skill Safety Verification',
    description: 'Verify safety of skills before use by checking trust signals',
    steps: [
      {
        method: 'POST',
        endpoint: '/api/v1/skills/verify',
        parameters: {
          skillIds: {
            type: 'string[]',
            required: true,
            description: 'Array of skill identifiers to verify',
          },
        },
        expectedResponse: 'Verification results for each skill including safety scores and flags',
      },
    ],
    tags: ['safety', 'verification', 'skills'],
  },
  {
    id: 'contextual-trust',
    name: 'Context-Scoped Trust Scoring',
    description: 'Get trust scores for candidate agents in a specific task context',
    steps: [
      {
        method: 'POST',
        endpoint: '/api/v1/trust/score',
        parameters: {
          modelId: {
            type: 'string',
            required: true,
            description: 'Trust model identifier for scoring algorithm',
          },
          candidates: {
            type: 'string[]',
            required: true,
            description: 'Array of agent identifiers to score',
          },
          version: {
            type: 'string',
            required: false,
            description: 'Trust model version (defaults to latest)',
          },
        },
        expectedResponse: 'Trust scores for each candidate with context-specific weights applied',
      },
    ],
    tags: ['trust', 'scoring', 'context'],
  },
  {
    id: 'agent-registration',
    name: 'Agent Registration',
    description: 'Register a new agent in the registry with metadata and capabilities',
    steps: [
      {
        method: 'POST',
        endpoint: '/api/v1/agents/register',
        parameters: {
          name: {
            type: 'string',
            required: true,
            description: 'Agent name',
          },
          description: {
            type: 'string',
            required: true,
            description: 'Agent description',
          },
          version: {
            type: 'string',
            required: true,
            description: 'Semantic version string',
          },
          platform: {
            type: 'string',
            required: true,
            description: 'Platform identifier (e.g., "mcp", "openai")',
          },
          capabilities: {
            type: 'string[]',
            required: false,
            description: 'Array of capability identifiers',
          },
          metadata: {
            type: 'object',
            required: false,
            description: 'Additional metadata key-value pairs',
          },
        },
        expectedResponse: 'Registered agent details including assigned vault ID and identity attestation',
      },
    ],
    tags: ['registration', 'onboarding', 'write'],
  },
  {
    id: 'onboarding-check',
    name: 'Agent Readiness Check',
    description: 'Check if an agent meets readiness criteria for production use',
    steps: [
      {
        method: 'GET',
        endpoint: '/api/v1/onboarding/agents/:id/readiness',
        parameters: {
          id: {
            type: 'string',
            required: true,
            description: 'Agent identifier (in URL path)',
          },
        },
        expectedResponse: 'Readiness status with checklist of requirements and their completion state',
      },
    ],
    tags: ['onboarding', 'verification', 'readiness'],
  },
  {
    id: 'generic-atom-creation',
    name: 'Generic Atom Creation',
    description: 'Create arbitrary atoms on-chain (not limited to agent/skill registration)',
    steps: [
      {
        method: 'GET',
        endpoint: '/api/v1/atoms/search',
        parameters: {
          q: {
            type: 'string',
            required: true,
            description: 'Search text to find existing atoms (check before creating duplicates)',
          },
        },
        expectedResponse: 'Array of matching atoms with term IDs and market cap data',
      },
      {
        method: 'POST',
        endpoint: '/api/v1/atoms',
        parameters: {
          atomData: {
            type: 'string[]',
            required: true,
            description: 'Array of atom data strings to create (1-20)',
          },
          depositPerAtom: {
            type: 'string',
            required: false,
            description: 'Wei amount to deposit per atom',
          },
        },
        expectedResponse: 'Atom term IDs and calldata (prepare mode) or execution results (execute mode)',
      },
    ],
    tags: ['atoms', 'creation', 'write'],
  },
  {
    id: 'triple-creation',
    name: 'Triple Creation & Query',
    description: 'Create relationship triples between atoms and query existing triples',
    steps: [
      {
        method: 'POST',
        endpoint: '/api/v1/triples',
        parameters: {
          triples: {
            type: 'object[]',
            required: true,
            description: 'Array of {subjectId, predicateId, objectId} with bytes32 term IDs',
          },
          depositPerTriple: {
            type: 'string',
            required: false,
            description: 'Wei amount to deposit per triple',
          },
        },
        expectedResponse: 'Triple calldata (prepare mode) or execution results with created triple term IDs',
      },
      {
        method: 'GET',
        endpoint: '/api/v1/triples',
        parameters: {
          subjectId: {
            type: 'string',
            required: false,
            description: 'Filter by subject atom term ID',
          },
          predicateId: {
            type: 'string',
            required: false,
            description: 'Filter by predicate atom term ID',
          },
          objectId: {
            type: 'string',
            required: false,
            description: 'Filter by object atom term ID',
          },
        },
        expectedResponse: 'Paginated array of triples with atom details and vault data',
      },
    ],
    tags: ['triples', 'relationships', 'query', 'write'],
  },
  {
    id: 'agent-lifecycle',
    name: 'Full Agent Lifecycle',
    description: 'Complete agent lifecycle: create capability, register, link, discover, and stake',
    steps: [
      {
        method: 'POST',
        endpoint: '/api/v1/atoms',
        parameters: {
          atomData: {
            type: 'string[]',
            required: true,
            description: 'Custom capability name(s) to create as atoms',
          },
        },
        expectedResponse: 'Created atom term IDs for capabilities',
      },
      {
        method: 'POST',
        endpoint: '/api/v1/agents/register',
        parameters: {
          name: {
            type: 'string',
            required: true,
            description: 'Agent name',
          },
          description: {
            type: 'string',
            required: true,
            description: 'Agent description',
          },
          version: {
            type: 'string',
            required: true,
            description: 'Semantic version',
          },
        },
        expectedResponse: 'Registered agent with identity atom term ID',
      },
      {
        method: 'POST',
        endpoint: '/api/v1/triples',
        parameters: {
          triples: {
            type: 'object[]',
            required: true,
            description: 'has-capability triples linking agent to capability atoms',
          },
        },
        expectedResponse: 'Created triple term IDs',
      },
      {
        method: 'GET',
        endpoint: '/api/v1/triples',
        parameters: {
          subjectId: {
            type: 'string',
            required: true,
            description: 'Agent identity atom term ID to verify relationships',
          },
        },
        expectedResponse: 'All triples where the agent is the subject',
      },
      {
        method: 'POST',
        endpoint: '/api/v1/trust/stake',
        parameters: {
          termId: {
            type: 'string',
            required: true,
            description: 'Triple or atom term ID to stake on',
          },
          amountEth: {
            type: 'string',
            required: true,
            description: 'ETH amount to stake',
          },
          direction: {
            type: 'string',
            required: false,
            description: '"for" or "against" (default: "for")',
          },
        },
        expectedResponse: 'Stake transaction result with curve ID and tx hash',
      },
    ],
    tags: ['lifecycle', 'registration', 'capabilities', 'staking', 'write'],
  },
]

export async function loader({ request }: LoaderFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const url = new URL(request.url)
  const tagFilter = url.searchParams.get('tag')

  let recipes = RECIPES

  if (tagFilter) {
    recipes = recipes.filter((recipe) => recipe.tags.includes(tagFilter))
  }

  return jsonResponse(recipes)
}
