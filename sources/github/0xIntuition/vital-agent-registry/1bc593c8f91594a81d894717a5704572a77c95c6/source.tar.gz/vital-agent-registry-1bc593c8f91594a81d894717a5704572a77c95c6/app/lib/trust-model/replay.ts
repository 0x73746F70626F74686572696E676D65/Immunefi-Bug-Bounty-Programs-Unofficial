interface ReplayResult {
  modelId: string
  version: string
  snapshotId: string
  queryHash: string
  results: Array<{
    candidateId: string
    score: number
    confidence: number
    evidenceId: string
  }>
}

export interface ReplayDiagnostics {
  ok: boolean
  mismatches: {
    snapshot: boolean
    model: boolean
    queryHash: boolean
    candidateScores: string[]
  }
  summary: string[]
}

function scoresByCandidate(
  result: ReplayResult,
): Map<string, { score: number; confidence: number }> {
  const map = new Map<string, { score: number; confidence: number }>()
  for (const item of result.results) {
    map.set(item.candidateId, {
      score: item.score,
      confidence: item.confidence,
    })
  }
  return map
}

export function compareReplayResults(
  baseline: ReplayResult,
  candidate: ReplayResult,
): ReplayDiagnostics {
  const snapshotMismatch = baseline.snapshotId !== candidate.snapshotId
  const modelMismatch =
    baseline.modelId !== candidate.modelId || baseline.version !== candidate.version
  const queryHashMismatch = baseline.queryHash !== candidate.queryHash

  const scoreMismatches: string[] = []
  const baselineScores = scoresByCandidate(baseline)
  const candidateScores = scoresByCandidate(candidate)
  const allIds = new Set([...baselineScores.keys(), ...candidateScores.keys()])

  for (const id of allIds) {
    const left = baselineScores.get(id)
    const right = candidateScores.get(id)
    if (!left || !right) {
      scoreMismatches.push(id)
      continue
    }
    if (left.score !== right.score || left.confidence !== right.confidence) {
      scoreMismatches.push(id)
    }
  }

  const summary: string[] = []
  if (snapshotMismatch) summary.push('snapshot mismatch')
  if (modelMismatch) summary.push('model mismatch')
  if (queryHashMismatch) summary.push('query-hash mismatch')
  if (scoreMismatches.length > 0) summary.push(`candidate score mismatch: ${scoreMismatches.join(',')}`)

  return {
    ok: summary.length === 0,
    mismatches: {
      snapshot: snapshotMismatch,
      model: modelMismatch,
      queryHash: queryHashMismatch,
      candidateScores: scoreMismatches,
    },
    summary,
  }
}
