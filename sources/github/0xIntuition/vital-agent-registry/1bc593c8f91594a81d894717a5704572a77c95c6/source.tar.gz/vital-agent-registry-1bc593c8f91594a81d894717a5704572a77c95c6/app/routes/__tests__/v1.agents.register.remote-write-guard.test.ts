import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const uploadAgentMetadata = vi.fn()
const getAtomCost = vi.fn()
const getTripleCost = vi.fn()
const getMinimumDeposit = vi.fn()

vi.mock('~/.server/ipfs', () => ({
  uploadAgentMetadata,
  IpfsUploadError: class IpfsUploadError extends Error {
    category: string
    constructor(message: string, category: string) {
      super(message)
      this.name = 'IpfsUploadError'
      this.category = category
    }
  },
}))

vi.mock('~/.server/multivault', () => ({
  getAtomCost,
  getTripleCost,
  createAtoms: vi.fn(),
  createTriples: vi.fn(),
  getAtomByUri: vi.fn(),
  getMinimumDeposit,
}))

vi.mock('~/.server/remote-write-guard', () => {
  class RemoteWriteGuardError extends Error {
    code = 'REMOTE_WRITE_BLOCKED'
    profile: string
    target: string
    action: string
    constructor(action: string, target: string, profile: string) {
      super(`Remote write blocked for "${action}" targeting "${target}".`)
      this.name = 'RemoteWriteGuardError'
      this.profile = profile
      this.target = target
      this.action = action
    }
  }
  return {
    assertRemoteWriteAllowed: vi.fn((params: { action: string; target: string; env?: Record<string, string | undefined> }) => {
      const env = process.env
      const allowRemoteWrites = env.ALLOW_REMOTE_WRITES
      const profile = env.REGISTRY_WRITE_PROFILE ?? 'local'

      if (allowRemoteWrites !== '1' && profile !== 'shared') {
        throw new RemoteWriteGuardError(params.action, params.target, profile)
      }
    }),
    RemoteWriteGuardError,
  }
})

vi.mock('~/.server/local-write', () => ({
  createLocalWriteClients: vi.fn(),
  getLocalWriteContext: vi.fn(),
}))

vi.mock('~/.server/local-agent-cache', () => ({
  storeLocalAgent: vi.fn(),
}))

vi.mock('~/lib/calldata', () => ({
  encodeCreateAtomCalldata: vi.fn(() => '0xdeadbeef'),
  encodeCreateTriplesCalldata: vi.fn(() => '0xbeadfeed'),
  deriveAtomTermId: vi.fn(() => '0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'),
  deriveIdentityAtomTermId: vi.fn(() => '0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'),
  encodeIdentityAtomData: vi.fn(() => '{"name":"test","namespace":"intuition-agent"}'),
}))

vi.mock('~/lib/abis/multivault', () => ({
  multivaultAbi: [],
}))

vi.mock('~/lib/rate-limit', () => ({
  isRegistrationRateLimitEnabled: vi.fn(() => false),
  getClientIP: vi.fn(() => '127.0.0.1'),
  registrationLimiter: {
    check: vi.fn(() => ({
      allowed: true,
      resetAt: Date.now() + 60_000,
    })),
  },
}))

vi.mock('~/.server/term-ids', () => ({
  getPredicates: vi.fn(() => ({
    IS: '0xeeee555555555555555555555555555555555555555555555555555555555555',
    HAS_CAPABILITY: '0xdddd444444444444444444444444444444444444444444444444444444444444',
    USES: '0x2222888888888888888888888888888888888888888888888888888888888888',
    HAS_METADATA: '0xffff666666666666666666666666666666666666666666666666666666666666',
    CREATED_BY: '0x1111777777777777777777777777777777777777777777777777777777777777',
  })),
  getTypeAtoms: vi.fn(() => ({
    AGENT_TYPE: '0x3333999999999999999999999999999999999999999999999999999999999999',
    SKILL_TYPE: '0x5555000000000000000000000000000000000000000000000000000000000000',
  })),
}))

vi.mock('~/lib/constants/protocol', () => ({
  getContractAddress: vi.fn(() => '0xcontract'),
  getChainConfig: vi.fn(() => ({ chainId: 13579 })),
  getRpcUrl: vi.fn(() => 'http://localhost:8545'),
  NAMESPACES: { AGENT: 'agent', SKILL: 'skill' },
}))

vi.mock('viem', () => ({
  createPublicClient: vi.fn(() => ({})),
  http: vi.fn(() => ({})),
  parseEventLogs: vi.fn(() => []),
  toHex: vi.fn((str: string) => `0x${Buffer.from(str).toString('hex')}`),
  encodeFunctionData: vi.fn(() => '0xdeadbeef'),
  keccak256: vi.fn(() => '0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'),
  pad: vi.fn((val: string) => val as `0x${string}`),
}))

describe('POST /api/v1/agents/register remote write guard', () => {
  const baseEnv = { ...process.env }

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = { ...baseEnv }
  })

  afterEach(() => {
    process.env = { ...baseEnv }
  })

  function createRequest() {
    return new Request('http://localhost:4101/api/v1/agents/register', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        name: 'Guard Test Agent',
        description: 'Checks local-safe mode',
        version: '1.0.0',
      }),
    })
  }

  it('blocks remote write preparation by default', async () => {
    process.env.CHAIN = 'testnet'
    delete process.env.ALLOW_REMOTE_WRITES
    delete process.env.REGISTRY_WRITE_PROFILE

    const { action } = await import('../api+/v1.agents.register')
    const response = await action({ request: createRequest(), params: {}, context: {} } as never)
    const body = await response.json()

    expect(response.status).toBe(403)
    expect(body.error).toContain('blocked')
    expect(body.code).toBe('REMOTE_WRITE_BLOCKED')
    expect(uploadAgentMetadata).not.toHaveBeenCalled()
  })

  it('allows remote write preparation with explicit override', async () => {
    process.env.CHAIN = 'testnet'
    process.env.ALLOW_REMOTE_WRITES = '1'
    process.env.REGISTRY_WRITE_PROFILE = 'shared'
    uploadAgentMetadata.mockResolvedValue('ipfs://QmGuardPass')
    getAtomCost.mockResolvedValue(123n)
    getTripleCost.mockResolvedValue(25n)
    getMinimumDeposit.mockResolvedValue(1n)

    const { action } = await import('../api+/v1.agents.register')
    const response = await action({ request: createRequest(), params: {}, context: {} } as never)
    const body = await response.json()

    expect(response.status).toBe(200)
    // v3: field renamed from ipfsUri to metadataIpfsUri
    expect(body.data.metadataIpfsUri).toBe('ipfs://QmGuardPass')
    expect(uploadAgentMetadata).toHaveBeenCalledTimes(1)
  })
})
