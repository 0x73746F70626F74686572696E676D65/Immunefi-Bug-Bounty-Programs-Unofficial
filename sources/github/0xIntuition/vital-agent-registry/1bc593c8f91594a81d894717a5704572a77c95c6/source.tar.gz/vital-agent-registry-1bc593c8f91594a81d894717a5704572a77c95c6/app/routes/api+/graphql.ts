import type { ActionFunctionArgs } from 'react-router'

const getGraphQLUrl = (): string => {
  return process.env.GRAPHQL_API_URL_PRIVATE as string
}

const isValidOrigin = (request: Request): boolean => {
  const origin = request.headers.get('origin') ?? ''
  const referer = request.headers.get('referer') ?? ''
  const host = request.headers.get('host') ?? ''

  const allowedDomains = (
    process.env.ALLOWED_DOMAINS ?? 'localhost'
  )
    .split(',')
    .map((d) => d.trim())

  if (process.env.NODE_ENV !== 'production') {
    allowedDomains.push('localhost', '127.0.0.1')
  }

  const getHostname = (url: string): string => {
    try {
      return new URL(url).hostname
    } catch {
      return url.replace(/^https?:\/\//, '').split('/')[0].split(':')[0]
    }
  }

  const originHost = getHostname(origin)
  const refererHost = getHostname(referer)
  const requestHost = host.split(':')[0]

  return (
    allowedDomains.some((d) => originHost === d) ||
    allowedDomains.some((d) => refererHost === d) ||
    allowedDomains.some((d) => requestHost === d)
  )
}

export const action = async ({ request }: ActionFunctionArgs) => {
  try {
    if (request.method !== 'POST') {
      return Response.json(
        { errors: [{ message: 'Method not allowed' }] },
        { status: 405 },
      )
    }

    const graphqlUrl = getGraphQLUrl()
    if (!graphqlUrl) {
      return Response.json(
        { errors: [{ message: 'GraphQL API not configured' }] },
        { status: 503 },
      )
    }

    if (!isValidOrigin(request)) {
      console.warn('[GRAPHQL-PROXY] Blocked request from unauthorized origin', {
        origin: request.headers.get('origin'),
      })
      return Response.json(
        { errors: [{ message: 'Unauthorized origin' }] },
        { status: 403 },
      )
    }

    const contentType = request.headers.get('content-type') ?? ''
    if (!contentType.includes('application/json')) {
      return Response.json(
        { errors: [{ message: 'Invalid content type' }] },
        { status: 400 },
      )
    }

    const body = await request.json()
    const { query, variables } = body

    if (!query || typeof query !== 'string') {
      return Response.json(
        { errors: [{ message: 'GraphQL query is required' }] },
        { status: 400 },
      )
    }

    // Block introspection queries in production
    const normalizedQuery = query.toLowerCase().replace(/\s+/g, ' ')
    if (process.env.NODE_ENV === 'production' && normalizedQuery.includes('__schema')) {
      return Response.json(
        { errors: [{ message: 'Introspection is disabled' }] },
        { status: 403 },
      )
    }

    // Block mutations -- this proxy is read-only
    if (normalizedQuery.trimStart().startsWith('mutation')) {
      return Response.json(
        { errors: [{ message: 'Mutations are not allowed through the proxy' }] },
        { status: 403 },
      )
    }

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    }

    if (process.env.GRAPHQL_API_BEARER_TOKEN) {
      headers.Authorization = `Bearer ${process.env.GRAPHQL_API_BEARER_TOKEN}`
    }

    const response = await fetch(graphqlUrl, {
      method: 'POST',
      headers,
      body: JSON.stringify({ query, variables: variables ?? {} }),
    })

    const data = await response.json()

    if (data.errors) {
      console.error('[GRAPHQL-PROXY] Backend errors:', {
        errors: data.errors,
        query: query.substring(0, 100),
      })
    }

    return Response.json(data, {
      status: response.status,
      headers: {
        'Content-Type': 'application/json',
        'Cache-Control': 'no-store, must-revalidate',
      },
    })
  } catch (error) {
    console.error('[GRAPHQL-PROXY] Error:', error)
    return Response.json(
      { errors: [{ message: 'Internal server error' }] },
      { status: 500 },
    )
  }
}
