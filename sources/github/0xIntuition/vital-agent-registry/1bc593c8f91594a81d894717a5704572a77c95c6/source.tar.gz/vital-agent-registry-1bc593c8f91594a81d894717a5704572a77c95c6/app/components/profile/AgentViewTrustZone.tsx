import type { Agent } from '~/types'
import { cn } from '~/lib/utils'
import { formatWeiToEth } from '~/lib/vault-utils'

interface AgentViewTrustZoneProps {
  agent: Agent
  className?: string
}

export function AgentViewTrustZone({
  agent,
  className,
}: AgentViewTrustZoneProps) {
  const { trustSignal, vault } = agent

  // ASCII signal bars based on tier
  const tierBars: Record<string, string> = {
    platinum: '█████',
    gold: '████░',
    silver: '███░░',
    bronze: '██░░░',
    unranked: '█░░░░',
  }

  const bars = tierBars[trustSignal.tier] || '░░░░░'
  const tierDisplay = trustSignal.tier.toUpperCase().padEnd(9)

  return (
    <div
      className={cn(
        'rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] p-4 font-mono text-sm',
        className,
      )}
    >
      <div className="text-muted-foreground mb-4">=== TRUST METRICS ===</div>

      {/* Trust tier with signal bars */}
      <div className="mb-4 text-base">
        <span className="text-muted-foreground">TIER: </span>
        <span className="text-foreground font-semibold">{tierDisplay}</span>
        <span className="text-[hsl(142_71%_45%)] ml-2">{bars}</span>
      </div>

      {/* Numeric metrics */}
      <div className="space-y-1">
        <div className="flex justify-between">
          <span className="text-muted-foreground">TVL:</span>
          <span className="text-foreground">
            {formatWeiToEth(vault.total_assets)} TRUST
          </span>
        </div>

        <div className="flex justify-between">
          <span className="text-muted-foreground">PERCENTILE:</span>
          <span className="text-foreground">
            {trustSignal.percentile}
            {trustSignal.percentile === 1
              ? 'st'
              : trustSignal.percentile === 2
                ? 'nd'
                : trustSignal.percentile === 3
                  ? 'rd'
                  : 'th'}
          </span>
        </div>

        <div className="flex justify-between">
          <span className="text-muted-foreground">STAKERS:</span>
          <span className="text-foreground">{trustSignal.stakerCount}</span>
        </div>

        <div className="flex justify-between">
          <span className="text-muted-foreground">SHARE_PRICE:</span>
          <span className="text-foreground">
            {formatWeiToEth(vault.current_share_price)} TRUST
          </span>
        </div>
      </div>
    </div>
  )
}
