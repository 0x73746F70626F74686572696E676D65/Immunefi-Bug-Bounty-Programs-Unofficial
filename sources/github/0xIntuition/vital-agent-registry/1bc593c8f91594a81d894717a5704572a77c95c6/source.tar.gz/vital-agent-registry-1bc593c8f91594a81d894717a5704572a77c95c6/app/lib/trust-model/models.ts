import {
  trustModelArtifactSchema,
  type TrustModelArtifact,
} from './artifact'

const DEFAULT_MODELS_RAW = [
  {
    modelId: 'com.intuition.trust.default',
    version: '1.0.0',
    author: 'registry-team',
    domain: 'agent-discovery',
    inputs: [
      {
        key: 'market_cap_wei',
        source: 'vault',
        type: 'number',
        required: true,
        description: 'Total market cap in wei',
      },
      {
        key: 'staker_count',
        source: 'vault',
        type: 'number',
        required: true,
        description: 'Unique staker count',
      },
      {
        key: 'share_price_wei',
        source: 'vault',
        type: 'number',
        required: false,
        defaultValue: 0,
        description: 'Current share price in wei',
      },
    ],
    formulaSpec: {
      language: 'trust-formula-v1',
      root: {
        op: 'weighted_sum',
        terms: [
          { weight: 0.5, value: { op: 'input', key: 'market_cap_wei' } },
          { weight: 0.3, value: { op: 'input', key: 'staker_count' } },
          { weight: 0.2, value: { op: 'input', key: 'share_price_wei' } },
        ],
      },
    },
    normalization: {
      method: 'rank-percentile',
      clampMin: 0,
      clampMax: 100,
    },
    outputSemantics: {
      scoreRange: { min: 0, max: 100 },
      confidenceRange: { min: 0, max: 1 },
      interpretation: 'Higher score indicates stronger trust signal',
    },
    compatibility: {
      minCompatibleVersion: '1.0.0',
      breaking: false,
      notes: 'Reference model for registry ranking',
    },
  },
  {
    modelId: 'com.intuition.trust.default',
    version: '1.1.0',
    author: 'registry-team',
    domain: 'agent-discovery',
    inputs: [
      {
        key: 'market_cap_wei',
        source: 'vault',
        type: 'number',
        required: true,
        description: 'Total market cap in wei',
      },
      {
        key: 'staker_count',
        source: 'vault',
        type: 'number',
        required: true,
        description: 'Unique staker count',
      },
      {
        key: 'share_price_wei',
        source: 'vault',
        type: 'number',
        required: false,
        defaultValue: 0,
        description: 'Current share price in wei',
      },
    ],
    formulaSpec: {
      language: 'trust-formula-v1',
      root: {
        op: 'weighted_sum',
        terms: [
          { weight: 0.2, value: { op: 'input', key: 'market_cap_wei' } },
          { weight: 0.6, value: { op: 'input', key: 'staker_count' } },
          { weight: 0.2, value: { op: 'input', key: 'share_price_wei' } },
        ],
      },
    },
    normalization: {
      method: 'minmax',
      clampMin: 0,
      clampMax: 100,
    },
    outputSemantics: {
      scoreRange: { min: 0, max: 100 },
      confidenceRange: { min: 0, max: 1 },
      interpretation: 'Stake-participation-weighted trust model',
    },
    compatibility: {
      minCompatibleVersion: '1.0.0',
      breaking: false,
      notes: 'Alternative weighting for model plurality tests',
    },
  },
  {
    modelId: 'com.intuition.trust.default',
    version: '2.0.0',
    author: 'registry-team',
    domain: 'agent-discovery',
    inputs: [
      {
        key: 'market_cap_wei',
        source: 'vault',
        type: 'number',
        required: true,
        description: 'Total market cap in wei',
      },
      {
        key: 'staker_count',
        source: 'vault',
        type: 'number',
        required: true,
        description: 'Unique staker count',
      },
      {
        key: 'share_price_wei',
        source: 'vault',
        type: 'number',
        required: false,
        defaultValue: 0,
        description: 'Current share price in wei',
      },
    ],
    formulaSpec: {
      language: 'trust-formula-v1',
      root: {
        op: 'add',
        args: [
          {
            op: 'mul',
            args: [
              { op: 'const', value: 0.4 },
              { op: 'input', key: 'market_cap_wei' },
            ],
          },
          {
            op: 'mul',
            args: [
              { op: 'const', value: 0.2 },
              { op: 'input', key: 'staker_count' },
            ],
          },
          {
            op: 'mul',
            args: [
              { op: 'const', value: 0.4 },
              { op: 'input', key: 'share_price_wei' },
            ],
          },
        ],
      },
    },
    normalization: {
      method: 'zscore',
      clampMin: 0,
      clampMax: 100,
    },
    outputSemantics: {
      scoreRange: { min: 0, max: 100 },
      confidenceRange: { min: 0, max: 1 },
      interpretation: 'Higher score indicates stronger trust signal',
    },
    compatibility: {
      minCompatibleVersion: '2.0.0',
      breaking: true,
      notes: 'Major model update with different weighting semantics',
    },
  },
] as const

const TRUST_MODELS: TrustModelArtifact[] = DEFAULT_MODELS_RAW.map((raw) =>
  trustModelArtifactSchema.parse(raw),
)

export function listTrustModels(): TrustModelArtifact[] {
  return TRUST_MODELS
}

export function getTrustModel(modelId: string, version: string): TrustModelArtifact | null {
  return TRUST_MODELS.find((model) => model.modelId === modelId && model.version === version) ?? null
}
