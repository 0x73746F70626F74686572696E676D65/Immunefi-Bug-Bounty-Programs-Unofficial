import { ThemeProvider as NextThemesProvider } from 'next-themes'
import type { ReactNode } from 'react'

interface ThemeProviderProps {
  children: ReactNode
  defaultTheme?: string
  storageKey?: string
}

export function ThemeProvider({
  children,
  defaultTheme = 'dark',
  storageKey = 'theme',
}: ThemeProviderProps) {
  return (
    <NextThemesProvider
      themes={['light', 'dark', 'agent']}
      attribute="data-theme"
      defaultTheme={defaultTheme}
      storageKey={storageKey}
      enableSystem={false}
    >
      {children}
    </NextThemesProvider>
  )
}
