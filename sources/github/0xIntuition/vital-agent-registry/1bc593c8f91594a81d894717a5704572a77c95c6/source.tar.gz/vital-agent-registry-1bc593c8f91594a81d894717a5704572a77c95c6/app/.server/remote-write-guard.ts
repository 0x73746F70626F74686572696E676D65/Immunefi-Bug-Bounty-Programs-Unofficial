export type WriteProfile = 'local' | 'shared'

const TRUE_VALUES = new Set(['1', 'true', 'yes', 'on'])

export class RemoteWriteGuardError extends Error {
  readonly code = 'REMOTE_WRITE_BLOCKED'
  readonly action: string
  readonly target: string
  readonly profile: WriteProfile

  constructor(action: string, target: string, profile: WriteProfile) {
    super(
      [
        `Remote write blocked for "${action}" targeting "${target}".`,
        'Local-safe defaults are active.',
        'Set ALLOW_REMOTE_WRITES=1 and REGISTRY_WRITE_PROFILE=shared to override intentionally.',
      ].join(' ')
    )
    this.name = 'RemoteWriteGuardError'
    this.action = action
    this.target = target
    this.profile = profile
  }
}

export function getWriteProfile(env: NodeJS.ProcessEnv = process.env): WriteProfile {
  const raw = (env.REGISTRY_WRITE_PROFILE ?? 'local').toLowerCase()
  return raw === 'shared' ? 'shared' : 'local'
}

export function isRemoteWriteOverrideEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  const raw = (env.ALLOW_REMOTE_WRITES ?? '').toLowerCase()
  return TRUE_VALUES.has(raw)
}

export function assertRemoteWriteAllowed(params: {
  action: string
  target: string
  env?: NodeJS.ProcessEnv
}) {
  const env = params.env ?? process.env
  if (isRemoteWriteOverrideEnabled(env)) return

  const profile = getWriteProfile(env)
  throw new RemoteWriteGuardError(params.action, params.target, profile)
}

