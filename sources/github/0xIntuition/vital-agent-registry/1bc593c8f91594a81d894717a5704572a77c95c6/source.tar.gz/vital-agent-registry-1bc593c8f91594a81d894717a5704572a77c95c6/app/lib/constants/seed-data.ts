import type { AgentMetadata } from '~/lib/schemas/agent-metadata';
import type { SkillMetadataPayload } from '~/lib/schemas/skill-metadata';

/**
 * Seed data for sample agents and skills.
 * Used by the seeding script to populate the registry with example entities.
 */

export interface SeedAgent {
  metadata: AgentMetadata;
  capabilities: string[]; // Names from CAPABILITY_ATOMS
  skills: string[]; // Names of seed skills this agent uses
}

export interface SeedSkill {
  metadata: SkillMetadataPayload;
  capabilities: string[]; // Names from CAPABILITY_ATOMS
}

/** Sample skills for the registry (v3: 6 bootstrap capabilities only) */
export const SEED_SKILLS: SeedSkill[] = [
  {
    metadata: {
      '@type': 'Skill',
      name: 'github-mcp',
      description:
        'Model Context Protocol server for GitHub operations. Create issues, PRs, review code, manage repositories.',
      version: '1.2.0',
      platform: 'mcp',
      author: 'Anthropic',
      installUri: 'npx @modelcontextprotocol/server-github',
      permissions: ['github:repo', 'github:issue', 'github:pull-request'],
      inputModes: ['application/json'],
      outputModes: ['application/json'],
    },
    // v3: Only use bootstrap capabilities (graph handles this)
    capabilities: ['code-review', 'deployment'],
  },
  {
    metadata: {
      '@type': 'Skill',
      name: 'code-search',
      description:
        'Fast semantic code search across repositories. Find functions, patterns, and examples using natural language queries.',
      version: '2.0.1',
      platform: 'claude-code',
      author: 'Intuition',
      installUri: 'https://registry.intuition.systems/skills/code-search',
      inputModes: ['text/plain', 'application/json'],
      outputModes: ['application/json', 'text/plain'],
    },
    capabilities: ['code-review', 'web-search'],
  },
  {
    metadata: {
      '@type': 'Skill',
      name: 'postgres-mcp',
      description:
        'Query and manage PostgreSQL databases. Execute SQL, inspect schemas, and analyze query performance.',
      version: '1.0.0',
      platform: 'mcp',
      author: 'ModelContextProtocol',
      installUri: 'npx @modelcontextprotocol/server-postgres',
      permissions: ['database:read', 'database:write'],
      inputModes: ['application/json'],
      outputModes: ['application/json', 'text/plain'],
    },
    capabilities: ['data-analysis'],
  },
  {
    metadata: {
      '@type': 'Skill',
      name: 'web-browse',
      description:
        'Browse websites, extract content, and scrape structured data. Handles JavaScript-rendered pages.',
      version: '3.1.2',
      platform: 'mcp',
      author: 'Anthropic',
      installUri: 'npx @modelcontextprotocol/server-puppeteer',
      permissions: ['network:http', 'network:https'],
      inputModes: ['text/plain', 'application/json'],
      outputModes: ['text/plain', 'application/json'],
    },
    capabilities: ['web-search', 'data-analysis'],
  },
  {
    metadata: {
      '@type': 'Skill',
      name: 'slack-integration',
      description:
        'Send messages, read channels, manage workspaces. Full Slack API access for team communication.',
      version: '2.3.0',
      platform: 'mcp',
      author: 'ModelContextProtocol',
      installUri: 'npx @modelcontextprotocol/server-slack',
      permissions: ['slack:channels:read', 'slack:chat:write'],
      inputModes: ['application/json'],
      outputModes: ['application/json'],
    },
    capabilities: [],
  },
  {
    metadata: {
      '@type': 'Skill',
      name: 'solidity-auditor',
      description:
        'Automated security analysis for smart contracts. Detects reentrancy, overflow, access control issues.',
      version: '4.0.0',
      platform: 'claude-code',
      author: 'Trail of Bits',
      installUri:
        'https://registry.intuition.systems/skills/solidity-auditor',
      longDescription:
        'Comprehensive static analysis tool for Solidity smart contracts. Uses symbolic execution and abstract interpretation to find vulnerabilities.',
      inputModes: ['text/plain'],
      outputModes: ['text/markdown'],
    },
    capabilities: ['code-review'],
  },
  {
    metadata: {
      '@type': 'Skill',
      name: 'terraform-deploy',
      description:
        'Infrastructure as code deployment. Plan, apply, and manage cloud resources across AWS, GCP, Azure.',
      version: '1.8.5',
      platform: 'openclaw',
      author: 'HashiCorp',
      installUri: 'https://openclaw.ai/skills/terraform',
      permissions: ['cloud:aws', 'cloud:gcp', 'cloud:azure'],
      inputModes: ['text/plain', 'application/yaml'],
      outputModes: ['text/plain', 'application/yaml'],
    },
    capabilities: ['deployment'],
  },
  {
    metadata: {
      '@type': 'Skill',
      name: 'langchain-agent',
      description:
        'Multi-step reasoning agent with memory and tool use. Build complex workflows with chain-of-thought.',
      version: '0.3.12',
      platform: 'other',
      author: 'LangChain',
      installUri: 'https://python.langchain.com/docs/get_started/installation/',
      inputModes: ['text/plain', 'application/json'],
      outputModes: ['text/plain', 'application/json'],
    },
    capabilities: ['planning'],
  },
];

/** Sample agents for the registry (v3: 6 bootstrap capabilities only) */
export const SEED_AGENTS: SeedAgent[] = [
  {
    metadata: {
      '@type': 'Agent',
      name: 'code-forge',
      description:
        'Full-stack development agent specializing in TypeScript, React, and Node.js. Handles everything from architecture to deployment.',
      version: '1.0.0',
      model: 'claude-opus-4-6',
      provider: { name: 'Intuition' },
      inputModes: ['text/plain'],
      outputModes: ['text/plain', 'application/json'],
    },
    // v3: Only use bootstrap capabilities (graph handles this)
    capabilities: ['code-generation', 'code-review', 'deployment'],
    skills: ['github-mcp', 'code-search'],
  },
  {
    metadata: {
      '@type': 'Agent',
      name: 'data-pilot',
      description:
        'Data analysis and pipeline agent. Queries databases, transforms data, generates insights, and creates visualizations.',
      version: '2.1.0',
      model: 'gpt-4-turbo',
      provider: { name: 'OpenAI', url: 'https://openai.com' },
      inputModes: ['text/plain', 'application/json'],
      outputModes: ['application/json', 'text/csv'],
    },
    capabilities: ['data-analysis'],
    skills: ['postgres-mcp'],
  },
  {
    metadata: {
      '@type': 'Agent',
      name: 'secure-guard',
      description:
        'Security audit specialist for smart contracts and Web3 applications. Detects vulnerabilities and suggests fixes.',
      version: '3.0.0',
      model: 'claude-opus-4-6',
      provider: { name: 'Intuition' },
      inputModes: ['text/plain'],
      outputModes: ['text/markdown'],
    },
    capabilities: ['code-review'],
    skills: ['solidity-auditor', 'code-search', 'github-mcp'],
  },
  {
    metadata: {
      '@type': 'Agent',
      name: 'research-scout',
      description:
        'Deep research agent that explores the web, synthesizes information, and produces comprehensive reports.',
      version: '1.5.0',
      model: 'claude-opus-4-6',
      provider: { name: 'Anthropic', url: 'https://anthropic.com' },
      inputModes: ['text/plain'],
      outputModes: ['text/markdown', 'text/plain'],
    },
    capabilities: ['web-search', 'data-analysis'],
    skills: ['web-browse'],
  },
  {
    metadata: {
      '@type': 'Agent',
      name: 'cloud-ops',
      description:
        'DevOps and infrastructure automation agent. Manages cloud resources, CI/CD pipelines, and monitoring.',
      version: '4.2.1',
      model: 'gpt-4',
      provider: { name: 'OpenAI', url: 'https://openai.com' },
      inputModes: ['text/plain', 'application/yaml'],
      outputModes: ['text/plain', 'application/yaml'],
    },
    capabilities: ['deployment'],
    skills: ['terraform-deploy', 'github-mcp'],
  },
  {
    metadata: {
      '@type': 'Agent',
      name: 'team-coordinator',
      description:
        'Team communication and workflow automation agent. Manages Slack channels, coordinates tasks, sends updates.',
      version: '2.0.0',
      model: 'claude-sonnet-4-5',
      provider: { name: 'Anthropic', url: 'https://anthropic.com' },
      inputModes: ['text/plain'],
      outputModes: ['text/plain'],
    },
    capabilities: ['planning'],
    skills: ['slack-integration', 'github-mcp'],
  },
  {
    metadata: {
      '@type': 'Agent',
      name: 'qa-engineer',
      description:
        'Automated testing and quality assurance agent. Writes tests, runs test suites, analyzes coverage.',
      version: '1.3.0',
      model: 'claude-opus-4-6',
      provider: { name: 'Intuition' },
      inputModes: ['text/plain'],
      outputModes: ['text/plain', 'application/json'],
    },
    capabilities: ['code-generation', 'code-review'],
    skills: ['github-mcp', 'code-search'],
  },
  {
    metadata: {
      '@type': 'Agent',
      name: 'deep-thinker',
      description:
        'Advanced reasoning agent with chain-of-thought and multi-step planning. Breaks down complex problems systematically.',
      version: '0.9.0',
      model: 'claude-opus-4-6',
      provider: { name: 'Anthropic', url: 'https://anthropic.com' },
      inputModes: ['text/plain'],
      outputModes: ['text/markdown', 'application/json'],
    },
    capabilities: ['planning', 'data-analysis'],
    skills: ['langchain-agent', 'web-browse'],
  },
];
