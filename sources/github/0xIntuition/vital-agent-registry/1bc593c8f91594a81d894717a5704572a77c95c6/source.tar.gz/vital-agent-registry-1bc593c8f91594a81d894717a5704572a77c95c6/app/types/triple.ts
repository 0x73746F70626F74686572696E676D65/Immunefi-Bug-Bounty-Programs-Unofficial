/**
 * AtomType — type identifier for atoms in the protocol
 *
 * Used to constrain predicate domain/range and provide type hints.
 */
export type AtomType =
  | 'Agent'
  | 'Skill'
  | 'Capability'
  | 'Category'
  | 'Platform'
  | 'Person'
  | 'Organization'
  | 'Thing'
  | 'Account'
  | 'Unknown'

/**
 * TripleAtomRef — minimal atom reference used inside triples
 *
 * Triples contain subject/predicate/object as atom references.
 * This is a lightweight representation for relationship data.
 */
export interface TripleAtomRef {
  /** Atom's term_id */
  term_id: string
  /** Human-readable label */
  label: string
  /** Avatar/icon URL */
  image?: string
  /** Atom type for filtering and constraints */
  type: AtomType
}

/**
 * TripleVaultData — vault economics for a triple's FOR/AGAINST vaults
 *
 * Each triple can have a FOR vault (curveId=0) and AGAINST vault (curveId=1)
 * for economic signaling on the claim.
 */
export interface TripleVaultData {
  /** FOR vault — curveId 0 */
  forVault: {
    total_assets: string
    position_count: number
    current_share_price: string
  }
  /** AGAINST vault — curveId 1 (may not exist for all triples) */
  againstVault?: {
    total_assets: string
    position_count: number
    current_share_price: string
  }
}

/**
 * Triple — semantic relationship (Subject-Predicate-Object)
 *
 * Triples encode all relationships in the registry:
 * - Entity is EntityType (type classification)
 * - Entity has-capability Capability
 * - Agent uses Skill
 * - Entity has-metadata MetadataAtom
 * - Entity created-by Creator
 */
export interface Triple {
  /** On-chain term ID for this triple */
  term_id: string
  /** Counter-triple term ID (for bidirectional relationships) */
  counter_term_id: string
  /** Subject atom reference */
  subject: TripleAtomRef
  /** Predicate atom reference */
  predicate: TripleAtomRef
  /** Object atom reference */
  object: TripleAtomRef
  /** ISO timestamp */
  created_at: string
  /** Creator account */
  creator_id: string
  /** Vault economics for this triple (populated when available) */
  vault?: TripleVaultData
}

/**
 * Predicate — typed predicate definition for relationship constraints
 *
 * Predicates define the valid semantic relationships in the registry.
 * Domain and range constraints ensure type safety for triples.
 */
export interface Predicate {
  /** Predicate atom's term_id */
  term_id: string
  /** Predicate slug (e.g., "has-capability") */
  slug: string
  /** Human-readable label */
  label: string
  /** Description of what this relationship means */
  description: string
  /** Valid subject atom types (domain constraints) */
  subjectTypes: AtomType[]
  /** Valid object atom types (range constraints) */
  objectTypes: AtomType[]
}
