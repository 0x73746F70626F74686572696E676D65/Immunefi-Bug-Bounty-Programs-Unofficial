import { createRepository } from './repository/provider'

// Convenience functions for backward compatibility with existing route imports.
// These create a one-off repository instance. For component usage, prefer useRepository() hook.

// Lazy singleton — avoids top-level process.env access on client import
let _repo: ReturnType<typeof createRepository> | null = null
function getRepo() {
  if (!_repo) _repo = createRepository()
  return _repo
}

export async function findAgentById(id: string) {
  return getRepo().findAgent(id)
}

export async function findSkillById(id: string) {
  return getRepo().findSkill(id)
}

export async function searchAgents(query: string) {
  return getRepo().searchAgents(query)
}

export async function searchSkills(query: string) {
  return getRepo().searchSkills(query)
}

export async function getSkillsForAgent(agentId: string) {
  return getRepo().getSkillsForAgent(agentId)
}
