/**
 * Known permission vocabulary for skill metadata display.
 * Permissions are informational (not stakeable claims).
 * Safety signaling happens via the skill's FOR/AGAINST vault.
 */

export type RiskLevel = 'low' | 'medium' | 'high' | 'critical'

export interface Permission {
  id: string
  label: string
  risk: RiskLevel
}

export const KNOWN_PERMISSIONS: readonly Permission[] = [
  { id: 'filesystem', label: 'Filesystem', risk: 'medium' },
  { id: 'network', label: 'Network', risk: 'low' },
  { id: 'env', label: 'Environment', risk: 'high' },
  { id: 'exec', label: 'Execution', risk: 'critical' },
  { id: 'sandbox', label: 'Sandbox', risk: 'low' },
  { id: 'auth', label: 'Authentication', risk: 'high' },
  { id: 'wallet', label: 'Wallet', risk: 'critical' },
] as const

export function findPermissionById(id: string): Permission | undefined {
  return KNOWN_PERMISSIONS.find((p) => p.id === id)
}

export function getPermissionRiskColor(risk: RiskLevel): string {
  switch (risk) {
    case 'low': return '#22c55e'
    case 'medium': return '#eab308'
    case 'high': return '#f97316'
    case 'critical': return '#ef4444'
  }
}
