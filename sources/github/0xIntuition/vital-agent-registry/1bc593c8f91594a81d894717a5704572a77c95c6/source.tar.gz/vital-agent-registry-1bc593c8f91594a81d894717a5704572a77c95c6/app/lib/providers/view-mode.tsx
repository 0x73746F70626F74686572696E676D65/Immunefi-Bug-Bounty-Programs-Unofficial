import { createContext, useContext } from 'react'
import type { ReactNode } from 'react'
import { useTheme } from 'next-themes'

export type ViewMode = 'human' | 'agent'

interface ViewModeContextValue {
  viewMode: ViewMode
  setViewMode: (mode: ViewMode) => void
  isAgentView: boolean
}

const ViewModeContext = createContext<ViewModeContextValue | undefined>(
  undefined
)

export function ViewModeProvider({ children }: { children: ReactNode }) {
  const { theme, setTheme } = useTheme()

  const isAgentView = theme === 'agent'
  const viewMode: ViewMode = isAgentView ? 'agent' : 'human'

  const setViewMode = (mode: ViewMode) => {
    if (mode === 'agent') {
      setTheme('agent')
    } else {
      setTheme('dark')
    }
  }

  return (
    <ViewModeContext.Provider value={{ viewMode, setViewMode, isAgentView }}>
      {children}
    </ViewModeContext.Provider>
  )
}

export function useViewMode() {
  const context = useContext(ViewModeContext)
  if (context === undefined) {
    throw new Error('useViewMode must be used within ViewModeProvider')
  }
  return context
}
