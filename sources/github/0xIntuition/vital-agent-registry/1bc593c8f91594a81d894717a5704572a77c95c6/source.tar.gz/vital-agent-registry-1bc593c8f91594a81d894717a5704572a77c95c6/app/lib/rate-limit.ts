/**
 * In-memory rate limiting for API endpoints.
 *
 * Tracks request counts per IP address within sliding time windows.
 * Automatically cleans up expired entries to prevent memory leaks.
 */

interface RateLimitConfig {
  /** Time window in milliseconds (default: 60000 = 1 minute) */
  windowMs: number;
  /** Maximum requests allowed per window (default: 10) */
  maxRequests: number;
}

interface RateLimitResult {
  /** Whether the request is allowed */
  allowed: boolean;
  /** Number of requests remaining in current window */
  remaining: number;
  /** Timestamp (ms) when the current window resets */
  resetAt: number;
}

interface RateLimitEntry {
  /** Current request count in this window */
  count: number;
  /** Timestamp (ms) when this window expires */
  resetAt: number;
}

function asBool(value: string | undefined): boolean {
  if (!value) return false
  const raw = value.toLowerCase()
  return raw === '1' || raw === 'true' || raw === 'yes' || raw === 'on'
}

/**
 * Creates a rate limiter instance with specified configuration.
 *
 * @example
 * ```typescript
 * const limiter = createRateLimiter({ windowMs: 60000, maxRequests: 10 });
 * const result = limiter.check('192.168.1.1');
 * if (!result.allowed) {
 *   console.log(`Rate limited. Try again in ${result.resetAt - Date.now()}ms`);
 * }
 * ```
 */
export function createRateLimiter(config?: Partial<RateLimitConfig>): {
  check(ip: string): RateLimitResult;
  reset(): void;
} {
  const { windowMs = 60000, maxRequests = 10 } = config || {};
  const store = new Map<string, RateLimitEntry>();

  /**
   * Removes expired entries from the store.
   * Called periodically to prevent unbounded memory growth.
   */
  function cleanup(): void {
    const now = Date.now();
    for (const [ip, entry] of store.entries()) {
      if (entry.resetAt <= now) {
        store.delete(ip);
      }
    }
  }

  /**
   * Checks if a request from the given IP is allowed.
   * Creates a new window if none exists or if the current window has expired.
   *
   * @param ip - Client IP address
   * @returns Rate limit result with allowed status, remaining count, and reset time
   */
  function check(ip: string): RateLimitResult {
    const now = Date.now();

    // Clean up expired entries (runs on every check for simplicity)
    cleanup();

    const existing = store.get(ip);

    // No entry or expired window - create new window
    if (!existing || existing.resetAt <= now) {
      const resetAt = now + windowMs;
      store.set(ip, { count: 1, resetAt });
      return {
        allowed: true,
        remaining: maxRequests - 1,
        resetAt,
      };
    }

    // Existing window - increment count
    existing.count += 1;
    const allowed = existing.count <= maxRequests;

    return {
      allowed,
      remaining: Math.max(0, maxRequests - existing.count),
      resetAt: existing.resetAt,
    };
  }

  /**
   * Resets all rate limit state.
   * Useful for testing or administrative overrides.
   */
  function reset(): void {
    store.clear();
  }

  return { check, reset };
}

/**
 * Extracts the client IP address from a request.
 * Checks common proxy headers before falling back to a default.
 *
 * @param request - HTTP request object
 * @returns Client IP address or '127.0.0.1' if not found
 *
 * @example
 * ```typescript
 * export async function action({ request }: ActionFunctionArgs) {
 *   const ip = getClientIP(request);
 *   const limit = registrationLimiter.check(ip);
 *   // ...
 * }
 * ```
 */
export function getClientIP(request: Request): string {
  // Check X-Forwarded-For (proxy/load balancer)
  const forwarded = request.headers.get('x-forwarded-for');
  if (forwarded) {
    // Take the first IP in the chain (original client)
    return forwarded.split(',')[0].trim();
  }

  // Check X-Real-IP (nginx proxy)
  const realIp = request.headers.get('x-real-ip');
  if (realIp) {
    return realIp;
  }

  // Fallback for local development
  return '127.0.0.1';
}

/**
 * Registration rate limit is disabled for local profile by default.
 *
 * Override knobs:
 * - `REGISTRATION_RATE_LIMIT_FORCE=1` => always enabled
 * - `DISABLE_REGISTRATION_RATE_LIMIT=1` => always disabled
 */
export function isRegistrationRateLimitEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  if (asBool(env.REGISTRATION_RATE_LIMIT_FORCE)) return true
  if (asBool(env.DISABLE_REGISTRATION_RATE_LIMIT)) return false

  const profile = (env.REGISTRY_WRITE_PROFILE ?? 'local').toLowerCase()
  if (profile === 'local') return false

  return true
}

/**
 * Default rate limiter for agent registration endpoint.
 * 10 requests per minute per IP.
 */
export const registrationLimiter = createRateLimiter({
  windowMs: 60000,
  maxRequests: 10,
});
