import type { Capability } from '~/types'

export const CAPABILITIES: Capability[] = [
  // AI & ML
  { id: 'code-generation', name: 'Code Generation', category: 'ai', description: 'Generates source code from natural language prompts' },
  { id: 'code-review', name: 'Code Review', category: 'ai', description: 'Analyzes code for bugs, style, and best practices' },
  { id: 'natural-language', name: 'Natural Language Processing', category: 'ai', description: 'Understands and generates human language' },
  { id: 'reasoning', name: 'Reasoning', category: 'ai', description: 'Multi-step logical reasoning and problem solving' },
  { id: 'tool-use', name: 'Tool Use', category: 'ai', description: 'Invokes external tools and APIs autonomously' },
  { id: 'planning', name: 'Planning', category: 'ai', description: 'Creates and executes multi-step plans' },
  { id: 'vision', name: 'Vision', category: 'ai', description: 'Processes and understands images' },
  { id: 'data-analysis', name: 'Data Analysis', category: 'ai', description: 'Analyzes datasets and generates insights' },
  { id: 'embeddings', name: 'Embeddings', category: 'ai', description: 'Generates vector embeddings for semantic search' },
  { id: 'image-generation', name: 'Image Generation', category: 'ai', description: 'Creates images from text descriptions' },
  { id: 'audio-processing', name: 'Audio Processing', category: 'ai', description: 'Transcribes, analyzes, and generates audio' },

  // Web3
  { id: 'smart-contracts', name: 'Smart Contracts', category: 'web3', description: 'Writes, deploys, and audits Solidity/Rust smart contracts' },
  { id: 'defi-protocols', name: 'DeFi Protocols', category: 'web3', description: 'Interacts with decentralized finance protocols for swaps, lending, and yield' },
  { id: 'onchain-data', name: 'On-chain Data', category: 'web3', description: 'Queries and indexes blockchain data across networks' },
  { id: 'wallet-management', name: 'Wallet Management', category: 'web3', description: 'Manages crypto wallets, signs transactions, and handles keys' },
  { id: 'nft-analysis', name: 'NFT Analysis', category: 'web3', description: 'Analyzes NFT collections, rarity, and market data' },
  { id: 'governance', name: 'Governance', category: 'web3', description: 'Participates in DAO governance proposals and voting' },
  { id: 'cross-chain', name: 'Cross-chain Operations', category: 'web3', description: 'Bridges assets and executes operations across multiple chains' },
  { id: 'token-analysis', name: 'Token Analysis', category: 'web3', description: 'Analyzes token metrics, liquidity, holder distribution, and price data' },

  // Research
  { id: 'web-search', name: 'Web Search', category: 'research', description: 'Searches the web for real-time information' },
  { id: 'document-analysis', name: 'Document Analysis', category: 'research', description: 'Reads and summarizes long documents and PDFs' },
  { id: 'fact-checking', name: 'Fact Checking', category: 'research', description: 'Verifies claims against authoritative sources' },
  { id: 'research', name: 'Research', category: 'research', description: 'Conducts multi-step investigations combining search, reading, and synthesis' },
  { id: 'knowledge-management', name: 'Knowledge Management', category: 'research', description: 'Organizes, stores, and retrieves structured knowledge across sessions' },

  // Content
  { id: 'content-writing', name: 'Content Writing', category: 'content', description: 'Writes articles, blog posts, and documentation' },
  { id: 'translation', name: 'Translation', category: 'content', description: 'Translates between languages' },
  { id: 'curation', name: 'Curation', category: 'content', description: 'Curates and ranks items by quality and relevance' },

  // Automation
  { id: 'workflow-orchestration', name: 'Workflow Orchestration', category: 'automation', description: 'Coordinates multi-step workflows across tools and services' },
  { id: 'task-scheduling', name: 'Task Scheduling', category: 'automation', description: 'Schedules and executes recurring or deferred tasks' },
  { id: 'file-management', name: 'File Management', category: 'automation', description: 'Reads, writes, transforms, and organizes files' },
  { id: 'system-monitoring', name: 'System Monitoring', category: 'automation', description: 'Monitors system health, logs, and performance metrics' },
  { id: 'deployment', name: 'Deployment', category: 'automation', description: 'Deploys applications and manages infrastructure' },
  { id: 'database-ops', name: 'Database Operations', category: 'automation', description: 'Manages database queries, schemas, and migrations' },
  { id: 'api-integration', name: 'API Integration', category: 'automation', description: 'Integrates with external APIs and webhook services' },

  // Development
  { id: 'debugging', name: 'Debugging', category: 'development', description: 'Diagnoses and fixes bugs using logs, stack traces, and codebase analysis' },
  { id: 'testing', name: 'Testing', category: 'development', description: 'Writes and runs unit, integration, and end-to-end tests' },
  { id: 'code-execution', name: 'Code Execution', category: 'development', description: 'Executes code in sandboxed environments and returns results' },
  { id: 'code-management', name: 'Code Management', category: 'development', description: 'Manages git operations, branches, PRs, and version control workflows' },
  { id: 'web-scraping', name: 'Web Scraping', category: 'development', description: 'Extracts structured data from web pages and APIs' },

  // Security
  { id: 'security-audit', name: 'Security Audit', category: 'security', description: 'Identifies vulnerabilities in code, contracts, and configurations' },
  { id: 'authentication', name: 'Authentication', category: 'security', description: 'Manages identity verification, OAuth, API keys, and access control' },
  { id: 'threat-detection', name: 'Threat Detection', category: 'security', description: 'Monitors for and alerts on security threats and anomalous behavior' },
  { id: 'input-validation', name: 'Input Validation', category: 'security', description: 'Validates, sanitizes, and enforces schemas on untrusted input' },

  // Communication
  { id: 'messaging', name: 'Messaging', category: 'communication', description: 'Sends and receives messages across platforms like Slack, Discord, and email' },
  { id: 'agent-delegation', name: 'Agent Delegation', category: 'communication', description: 'Delegates tasks to other agents and aggregates their results' },
  { id: 'human-in-the-loop', name: 'Human-in-the-Loop', category: 'communication', description: 'Requests human review, approval, or input at decision points' },
  { id: 'notification', name: 'Notification', category: 'communication', description: 'Pushes alerts and status updates to users or other systems' },
  { id: 'collaborative-coding', name: 'Collaborative Coding', category: 'communication', description: 'Pairs with humans or other agents on shared code in real time' },

  // Memory & Context
  { id: 'context-management', name: 'Context Management', category: 'memory', description: 'Maintains and retrieves conversation history and session state' },
  { id: 'long-term-memory', name: 'Long-term Memory', category: 'memory', description: 'Persists learned information across sessions and interactions' },
  { id: 'retrieval-augmentation', name: 'Retrieval Augmentation', category: 'memory', description: 'Retrieves relevant context from vector stores and knowledge bases' },
  { id: 'structured-output', name: 'Structured Output', category: 'memory', description: 'Generates responses in specified formats like JSON, XML, and schemas' },

  // Specialized
  { id: 'browser-automation', name: 'Browser Automation', category: 'specialized', description: 'Controls web browsers to navigate, click, fill forms, and extract data' },
  { id: 'data-transformation', name: 'Data Transformation', category: 'specialized', description: 'Converts data between formats, cleans datasets, and runs ETL pipelines' },
  { id: 'payment-processing', name: 'Payment Processing', category: 'specialized', description: 'Handles crypto and fiat payment flows, invoicing, and settlements' },
  { id: 'document-generation', name: 'Document Generation', category: 'specialized', description: 'Creates formatted reports, PDFs, spreadsheets, and presentations' },
]

export function getCapabilitiesByCategory(): Record<string, Capability[]> {
  const grouped: Record<string, Capability[]> = {}
  for (const cap of CAPABILITIES) {
    const list = grouped[cap.category] ?? []
    list.push(cap)
    grouped[cap.category] = list
  }
  return grouped
}

export function findCapabilityById(id: string): Capability | undefined {
  return CAPABILITIES.find((c) => c.id === id)
}
