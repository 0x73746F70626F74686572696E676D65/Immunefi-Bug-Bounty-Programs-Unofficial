import { useEffect, useState } from 'react'
import { Terminal, Eye } from 'lucide-react'
import { useViewMode } from '~/lib/providers/view-mode'

export function ViewModeToggle() {
  const { setViewMode, isAgentView } = useViewMode()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return <div className="h-8 w-8" />
  }

  return (
    <button
      type="button"
      onClick={() => setViewMode(isAgentView ? 'human' : 'agent')}
      className={`flex h-8 w-8 items-center justify-center rounded-full bg-muted text-muted-foreground transition-all hover:bg-border hover:text-foreground ${
        isAgentView
          ? 'shadow-[0_0_10px_hsl(120_100%_50%_/_0.3)] ring-1 ring-[hsl(120_100%_50%_/_0.4)]'
          : ''
      }`}
      aria-label={`Switch to ${isAgentView ? 'human' : 'agent'} view`}
    >
      {isAgentView ? <Terminal className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
    </button>
  )
}
