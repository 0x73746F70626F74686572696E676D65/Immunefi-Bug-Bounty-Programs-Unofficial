import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const mocks = vi.hoisted(() => ({
  uploadAgentMetadata: vi.fn(),
  uploadSkillMetadata: vi.fn(),
  getAtomCost: vi.fn(),
  getTripleCost: vi.fn(),
  getMinimumDeposit: vi.fn(),
  encodeCreateAtomCalldata: vi.fn(),
  encodeCreateTriplesCalldata: vi.fn(),
  deriveAtomTermId: vi.fn(),
  deriveIdentityAtomTermId: vi.fn(),
  encodeIdentityAtomData: vi.fn(),
}))

vi.mock('~/.server/ipfs', () => ({
  uploadAgentMetadata: mocks.uploadAgentMetadata,
  uploadSkillMetadata: mocks.uploadSkillMetadata,
  IpfsUploadError: class IpfsUploadError extends Error {
    category: string
    constructor(message: string, category: string) {
      super(message)
      this.name = 'IpfsUploadError'
      this.category = category
    }
  },
}))

vi.mock('~/.server/multivault', () => ({
  getAtomCost: mocks.getAtomCost,
  getTripleCost: mocks.getTripleCost,
  getMinimumDeposit: mocks.getMinimumDeposit,
  createAtoms: vi.fn(),
  createTriples: vi.fn(),
  getAtomByUri: vi.fn(),
}))

vi.mock('~/.server/remote-write-guard', () => ({
  assertRemoteWriteAllowed: vi.fn(),
  RemoteWriteGuardError: class RemoteWriteGuardError extends Error {
    code: string
    profile: string
    target: string
    action: string
    constructor(message: string, code: string, profile: string, target: string, action: string) {
      super(message)
      this.code = code
      this.profile = profile
      this.target = target
      this.action = action
    }
  },
}))

vi.mock('~/.server/local-write', () => ({
  createLocalWriteClients: vi.fn(),
  getLocalWriteContext: vi.fn(),
}))

vi.mock('~/.server/local-agent-cache', () => ({
  storeLocalAgent: vi.fn(),
}))

vi.mock('~/lib/calldata', () => ({
  encodeCreateAtomCalldata: mocks.encodeCreateAtomCalldata,
  encodeCreateTriplesCalldata: mocks.encodeCreateTriplesCalldata,
  deriveAtomTermId: mocks.deriveAtomTermId,
  deriveIdentityAtomTermId: mocks.deriveIdentityAtomTermId,
  encodeIdentityAtomData: mocks.encodeIdentityAtomData,
}))

vi.mock('~/lib/abis/multivault', () => ({
  multivaultAbi: [],
}))

vi.mock('~/lib/rate-limit', () => ({
  isRegistrationRateLimitEnabled: vi.fn(() => false),
  getClientIP: vi.fn(() => '127.0.0.1'),
  registrationLimiter: {
    check: vi.fn(() => ({
      allowed: true,
      resetAt: Date.now() + 60_000,
    })),
  },
}))

vi.mock('viem', () => ({
  createPublicClient: vi.fn(() => ({})),
  http: vi.fn(() => ({})),
  parseEventLogs: vi.fn(() => []),
  toHex: vi.fn((str: string) => `0x${Buffer.from(str).toString('hex')}`),
  encodeFunctionData: vi.fn(() => '0xdeadbeef'),
  keccak256: vi.fn(() => '0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'),
  pad: vi.fn((val: string) => val as `0x${string}`),
}))

vi.mock('~/.server/term-ids', () => ({
  getPredicates: vi.fn(() => ({
    IS: '0xeeee555555555555555555555555555555555555555555555555555555555555',
    HAS_CAPABILITY: '0xdddd444444444444444444444444444444444444444444444444444444444444',
    USES: '0x2222888888888888888888888888888888888888888888888888888888888888',
    HAS_METADATA: '0xffff666666666666666666666666666666666666666666666666666666666666',
    CREATED_BY: '0x_placeholder_created_by',
  })),
  getTypeAtoms: vi.fn(() => ({
    AGENT_TYPE: '0x3333999999999999999999999999999999999999999999999999999999999999',
    SKILL_TYPE: '0x5555000000000000000000000000000000000000000000000000000000000000',
  })),
}))

vi.mock('~/lib/constants/protocol', () => ({
  getContractAddress: vi.fn(() => '0xcontract'),
  getChainConfig: vi.fn(() => ({ chainId: 13579 })),
  getRpcUrl: vi.fn(() => 'http://localhost:8545'),
  NAMESPACES: { AGENT: 'agent', SKILL: 'skill' },
}))

describe('registration two-signature planning', () => {
  const baseEnv = { ...process.env }
  const termIdA = '0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
  const termIdB = '0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb'
  const termIdC = '0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc'

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = {
      ...baseEnv,
      CHAIN: 'testnet',
      ALLOW_REMOTE_WRITES: '1',
      REGISTRY_WRITE_PROFILE: 'shared',
    }
    mocks.getAtomCost.mockResolvedValue(100n)
    mocks.getTripleCost.mockResolvedValue(25n)
    mocks.getMinimumDeposit.mockResolvedValue(1n)
    mocks.encodeCreateAtomCalldata.mockReturnValue('0xdeadbeef')
    mocks.encodeCreateTriplesCalldata.mockReturnValue('0xbeadfeed')
    mocks.deriveAtomTermId.mockReturnValue(termIdA)
    mocks.deriveIdentityAtomTermId.mockReturnValue(termIdA)
    mocks.encodeIdentityAtomData.mockReturnValue('{"name":"test","namespace":"intuition-agent"}')
    mocks.uploadAgentMetadata.mockResolvedValue('ipfs://QmAgent')
    mocks.uploadSkillMetadata.mockResolvedValue('ipfs://QmSkill')
  })

  afterEach(() => {
    process.env = { ...baseEnv }
  })

  it('returns two signatures for agent registration when relationship context is provided', async () => {
    const { action } = await import('../api+/v1.agents.register')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/agents/register', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          name: 'Two Sig Agent',
          description: 'Agent',
          version: '1.0.0',
          relationshipContext: {
            typePredicateTermId: termIdB,
            typeObjectTermId: termIdC,
          },
          requireTwoSignatures: true,
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.signaturePlan.requiredSignatures).toBe(2)
    expect(body.data.transactions).toHaveLength(2)
    expect(body.data.transactions[1].kind).toBe('createTriples')
    expect(mocks.getTripleCost).toHaveBeenCalledTimes(1)
    expect(mocks.encodeCreateTriplesCalldata).toHaveBeenCalledTimes(1)
  })

  it('returns two-signature plan for skill registration with bootstrap term ids and no explicit relationship context', async () => {
    // With bootstrap term IDs available, has-metadata and is:Skill triples are auto-created.
    // requireTwoSignatures: true succeeds without explicit relationshipContext.
    const { action } = await import('../api+/v1.skills.register')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/skills/register', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          name: 'Strict Skill',
          description: 'Skill',
          version: '1.0.0',
          platform: 'mcp',
          requireTwoSignatures: true,
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.signaturePlan.requiredSignatures).toBe(2)
    expect(body.data.transactions).toHaveLength(2)
    expect(body.data.transactions[1].kind).toBe('createTriples')
  })

  it('includes created-by triple in two-signature plan when creator context is provided', async () => {
    const termIdD = '0xdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd'

    const { action } = await import('../api+/v1.agents.register')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/agents/register', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          name: 'Created By Agent',
          description: 'Agent with created-by',
          version: '1.0.0',
          relationshipContext: {
            typePredicateTermId: termIdB,
            typeObjectTermId: termIdC,
            createdByPredicateTermId: termIdA,
            creatorTermId: termIdD,
          },
          requireTwoSignatures: true,
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.signaturePlan.requiredSignatures).toBe(2)
    expect(body.data.transactions).toHaveLength(2)
    // Should have type triple + created-by triple = at least 2 triples
    const triplesArg = mocks.encodeCreateTriplesCalldata.mock.calls[0][0]
    expect(triplesArg.length).toBeGreaterThanOrEqual(2)
  })
})
