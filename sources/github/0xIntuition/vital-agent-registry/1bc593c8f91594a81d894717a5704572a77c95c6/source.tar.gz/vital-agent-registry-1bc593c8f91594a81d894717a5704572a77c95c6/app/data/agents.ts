import type { Agent, Vault, TrustSignal, TrustTier, Triple, TripleVaultData, SecurityProfile, ReputationProfile } from '~/types'
import { TRUST_TIER_THRESHOLDS } from '~/types'
import { CAPABILITIES, findCapabilityById } from './capabilities'
import { formatWeiToEth, safeSharePrice } from '~/lib/vault-utils'

/**
 * Mock security profiles keyed by agent ID.
 * Only agents with attestations get a profile.
 */
const SECURITY_PROFILES: Record<string, SecurityProfile> = {
  '0xagent_001': {
    score: 92, level: 'verified', attestations: [], positiveCount: 8, negativeCount: 0, hasCounterAttestations: false,
  },
  '0xagent_002': {
    score: 78, level: 'verified', attestations: [], positiveCount: 5, negativeCount: 0, hasCounterAttestations: false,
  },
  '0xagent_003': {
    score: 85, level: 'verified', attestations: [], positiveCount: 6, negativeCount: 0, hasCounterAttestations: false,
  },
  '0xagent_004': {
    score: 72, level: 'verified', attestations: [], positiveCount: 4, negativeCount: 0, hasCounterAttestations: false,
  },
  '0xagent_005': {
    score: 65, level: 'partially-verified', attestations: [], positiveCount: 3, negativeCount: 0, hasCounterAttestations: false,
  },
  '0xagent_006': {
    score: 70, level: 'verified', attestations: [], positiveCount: 4, negativeCount: 0, hasCounterAttestations: false,
  },
  '0xagent_007': {
    score: 88, level: 'verified', attestations: [], positiveCount: 7, negativeCount: 0, hasCounterAttestations: false,
  },
  '0xagent_008': {
    score: 55, level: 'partially-verified', attestations: [], positiveCount: 3, negativeCount: 0, hasCounterAttestations: false,
  },
  '0xagent_009': {
    score: 42, level: 'partially-verified', attestations: [], positiveCount: 2, negativeCount: 0, hasCounterAttestations: false,
  },
  '0xagent_015': {
    score: 30, level: 'unverified', attestations: [], positiveCount: 1, negativeCount: 0, hasCounterAttestations: false,
  },
  '0xagent_022': {
    score: 15, level: 'flagged', attestations: [], positiveCount: 0, negativeCount: 2, hasCounterAttestations: true,
  },
}

/**
 * Mock reputation profiles keyed by agent ID.
 * Only agents with task feedback get a profile.
 */
const REPUTATION_PROFILES: Record<string, ReputationProfile> = {
  '0xagent_001': {
    totalTasks: 1250, successRate: 0.96, avgQuality: 91, compositeScore: 94,
    recentTrend: 'stable',
    domainScores: [
      { domain: 'Code Generation', taskCount: 480, successRate: 0.97, avgQuality: 93 },
      { domain: 'Reasoning', taskCount: 340, successRate: 0.95, avgQuality: 92 },
      { domain: 'Planning', taskCount: 260, successRate: 0.94, avgQuality: 88 },
      { domain: 'Tool Use', taskCount: 170, successRate: 0.98, avgQuality: 90 },
    ],
  },
  '0xagent_002': {
    totalTasks: 980, successRate: 0.93, avgQuality: 87, compositeScore: 89,
    recentTrend: 'improving',
    domainScores: [
      { domain: 'Orchestration', taskCount: 350, successRate: 0.95, avgQuality: 89 },
      { domain: 'Code Generation', taskCount: 280, successRate: 0.91, avgQuality: 86 },
      { domain: 'Vision', taskCount: 200, successRate: 0.94, avgQuality: 88 },
    ],
  },
  '0xagent_003': {
    totalTasks: 820, successRate: 0.94, avgQuality: 90, compositeScore: 91,
    recentTrend: 'stable',
    domainScores: [
      { domain: 'Code Generation', taskCount: 520, successRate: 0.96, avgQuality: 94 },
      { domain: 'Code Review', taskCount: 180, successRate: 0.92, avgQuality: 88 },
      { domain: 'Data Analysis', taskCount: 120, successRate: 0.90, avgQuality: 85 },
    ],
  },
  '0xagent_004': {
    totalTasks: 650, successRate: 0.89, avgQuality: 83, compositeScore: 85,
    recentTrend: 'improving',
    domainScores: [
      { domain: 'Full-Stack Dev', taskCount: 300, successRate: 0.91, avgQuality: 85 },
      { domain: 'Deployment', taskCount: 200, successRate: 0.88, avgQuality: 82 },
      { domain: 'Code Review', taskCount: 150, successRate: 0.87, avgQuality: 80 },
    ],
  },
  '0xagent_005': {
    totalTasks: 540, successRate: 0.91, avgQuality: 86, compositeScore: 87,
    recentTrend: 'stable',
    domainScores: [
      { domain: 'Code Generation', taskCount: 320, successRate: 0.93, avgQuality: 88 },
      { domain: 'Code Review', taskCount: 220, successRate: 0.89, avgQuality: 84 },
    ],
  },
  '0xagent_006': {
    totalTasks: 410, successRate: 0.92, avgQuality: 85, compositeScore: 86,
    recentTrend: 'stable',
    domainScores: [
      { domain: 'DeFi Monitoring', taskCount: 220, successRate: 0.94, avgQuality: 88 },
      { domain: 'Smart Contracts', taskCount: 130, successRate: 0.90, avgQuality: 83 },
      { domain: 'On-chain Analysis', taskCount: 60, successRate: 0.88, avgQuality: 81 },
    ],
  },
  '0xagent_007': {
    totalTasks: 380, successRate: 0.95, avgQuality: 91, compositeScore: 92,
    recentTrend: 'improving',
    domainScores: [
      { domain: 'Security Audit', taskCount: 250, successRate: 0.96, avgQuality: 93 },
      { domain: 'Code Review', taskCount: 130, successRate: 0.93, avgQuality: 88 },
    ],
  },
  '0xagent_008': {
    totalTasks: 290, successRate: 0.88, avgQuality: 82, compositeScore: 83,
    recentTrend: 'declining',
    domainScores: [
      { domain: 'Research', taskCount: 180, successRate: 0.90, avgQuality: 84 },
      { domain: 'Fact Checking', taskCount: 110, successRate: 0.85, avgQuality: 79 },
    ],
  },
}

/**
 * Helper: Create a vault with realistic BigInt math
 */
function createVault(termId: string, stakerCount: number, tvlEth: number): Vault {
  const totalAssets = BigInt(Math.floor(tvlEth * 1e18))
  const ONE = 10n ** 18n
  const totalShares = BigInt(stakerCount) * ONE
  const currentSharePrice = totalAssets > 0n && totalShares > 0n
    ? ((totalAssets * ONE) / totalShares).toString()
    : ONE.toString()

  return {
    term_id: termId,
    curve_id: '0xcurve_linear',
    total_shares: totalShares.toString(),
    current_share_price: currentSharePrice,
    total_assets: totalAssets.toString(),
    market_cap: totalAssets.toString(),
    position_count: stakerCount,
  }
}

/**
 * Helper: Compute trust signal from vault and all vaults for percentile
 */
function createTrustSignal(vault: Vault, allVaults: Vault[]): TrustSignal {
  const totalAssets = BigInt(vault.total_assets)

  // Count how many vaults have less TVL
  const countBelow = allVaults.filter(v => BigInt(v.total_assets) < totalAssets).length
  const percentile = Math.round((countBelow / allVaults.length) * 100)

  // Determine tier
  let tier: TrustTier = 'unranked'
  if (percentile >= TRUST_TIER_THRESHOLDS.platinum) tier = 'platinum'
  else if (percentile >= TRUST_TIER_THRESHOLDS.gold) tier = 'gold'
  else if (percentile >= TRUST_TIER_THRESHOLDS.silver) tier = 'silver'
  else if (percentile >= TRUST_TIER_THRESHOLDS.bronze) tier = 'bronze'

  // Format as ETH strings using BigInt-safe helpers
  const totalStaked = formatWeiToEth(vault.total_assets)
  const sharePrice = formatWeiToEth(safeSharePrice(vault), 6)
  const marketCap = formatWeiToEth(vault.market_cap)

  return {
    stakerCount: vault.position_count,
    totalStaked,
    sharePrice,
    tier,
    percentile,
    marketCap,
  }
}

/**
 * Helper: Create has-capability triple
 */
function createMockTripleVault(): TripleVaultData {
  const forAssets = Math.floor(Math.random() * 900 + 100) * 1e15 // 0.1-1.0 ETH range
  const againstAssets = Math.floor(Math.random() * 200) * 1e15 // 0-0.2 ETH range
  return {
    forVault: {
      total_assets: String(forAssets),
      position_count: Math.floor(Math.random() * 15) + 1,
      current_share_price: String(1e18 + Math.floor(Math.random() * 1e17)),
    },
    againstVault: againstAssets > 0
      ? {
          total_assets: String(againstAssets),
          position_count: Math.floor(Math.random() * 5) + 1,
          current_share_price: String(1e18 + Math.floor(Math.random() * 5e16)),
        }
      : undefined,
  }
}

function createHasCapabilityTriple(agentId: string, agentName: string, capabilityId: string): Triple {
  const capability = findCapabilityById(capabilityId)
  if (!capability) throw new Error(`Capability ${capabilityId} not found`)

  return {
    term_id: `${agentId}_has_${capabilityId}`,
    counter_term_id: `${capabilityId}_has_${agentId}_counter`,
    subject: { term_id: agentId, label: agentName, type: 'Agent' },
    predicate: { term_id: '0xpred_has_capability', label: 'has-capability', type: 'Thing' },
    object: { term_id: capabilityId, label: capability.name, type: 'Capability' },
    created_at: new Date().toISOString(),
    creator_id: '0xsystem',
    vault: createMockTripleVault(),
  }
}

/**
 * Helper: Create uses triple
 */
function createUsesSkillTriple(agentId: string, agentName: string, skillId: string, skillName: string): Triple {
  return {
    term_id: `${agentId}_uses_${skillId}`,
    counter_term_id: `${skillId}_uses_${agentId}_counter`,
    subject: { term_id: agentId, label: agentName, type: 'Agent' },
    predicate: { term_id: '0xpred_uses', label: 'uses', type: 'Thing' },
    object: { term_id: skillId, label: skillName, type: 'Skill' },
    created_at: new Date().toISOString(),
    creator_id: '0xsystem',
    vault: createMockTripleVault(),
  }
}

/**
 * Helper: Create generic triple
 */
function createTriple(
  subjectId: string,
  subjectLabel: string,
  subjectType: 'Agent' | 'Skill' | 'Person' | 'Organization',
  predicateId: string,
  predicateLabel: string,
  objectId: string,
  objectLabel: string,
  objectType: 'Agent' | 'Skill' | 'Category' | 'Organization' | 'Person' | 'Capability'
): Triple {
  return {
    term_id: `${subjectId}_${predicateId}_${objectId}`,
    counter_term_id: `${objectId}_${predicateId}_${subjectId}_counter`,
    subject: { term_id: subjectId, label: subjectLabel, type: subjectType },
    predicate: { term_id: `0xpred_${predicateId.replace(/-/g, '_')}`, label: predicateLabel, type: 'Thing' },
    object: { term_id: objectId, label: objectLabel, type: objectType },
    created_at: new Date().toISOString(),
    creator_id: '0xsystem',
    vault: createMockTripleVault(),
  }
}

/**
 * MOCK_AGENTS — 25 AI agents spanning all trust tiers with pathological cases
 */

// Step 1: Create agent data with vaults (before trust signals)
const agentDataList = [
  // PLATINUM TIER (2-3 agents, high TVL)
  {
    id: '0xagent_001',
    name: 'Claude Opus Agent',
    description: 'Advanced reasoning agent powered by Claude Opus 4.6',
    tvl: 180,
    stakers: 520,
    capabilityIds: ['code-generation', 'reasoning', 'planning', 'tool-use', 'natural-language'],
    model: 'claude-opus-4-6',
    endpoint: 'https://api.anthropic.com/v1/agents/opus',
    provider: { name: 'Anthropic', url: 'https://anthropic.com' },
    tags: ['reasoning', 'planning', 'code'],
  },
  {
    id: '0xagent_002',
    name: 'GPT-4o Orchestrator',
    description: 'Multi-modal orchestration agent with vision and planning',
    tvl: 145,
    stakers: 430,
    capabilityIds: ['planning', 'code-generation', 'natural-language', 'vision', 'tool-use'],
    model: 'gpt-4o',
    endpoint: 'https://api.openai.com/v1/agents/orchestrator',
    provider: { name: 'OpenAI', url: 'https://openai.com' },
    tags: ['orchestration', 'multimodal', 'vision'],
  },
  {
    id: '0xagent_003',
    name: 'DeepMind AlphaCode Pro',
    description: 'State-of-the-art code generation and optimization',
    tvl: 98,
    stakers: 310,
    capabilityIds: ['code-generation', 'code-review', 'reasoning', 'data-analysis'],
    model: 'alphacode-pro',
    endpoint: 'https://api.deepmind.com/agents/alphacode',
    provider: { name: 'DeepMind', url: 'https://deepmind.com' },
    tags: ['code', 'optimization', 'competitive-programming'],
  },

  // GOLD TIER (4-5 agents, medium-high TVL)
  {
    id: '0xagent_004',
    name: 'Devin Code Agent',
    description: 'Full-stack software engineering agent with deployment capabilities',
    tvl: 42,
    stakers: 215,
    capabilityIds: ['code-generation', 'code-review', 'deployment', 'file-management', 'tool-use'],
    model: 'devin-v2',
    endpoint: 'https://api.cognition.ai/devin',
    provider: { name: 'Cognition AI', url: 'https://cognition.ai' },
    tags: ['fullstack', 'deployment', 'engineering'],
  },
  {
    id: '0xagent_005',
    name: 'Cursor AI',
    description: 'IDE-integrated code assistant with context awareness',
    tvl: 38,
    stakers: 190,
    capabilityIds: ['code-generation', 'code-review', 'natural-language', 'reasoning'],
    model: 'cursor-v0.29',
    provider: { name: 'Anysphere', url: 'https://cursor.sh' },
    tags: ['ide', 'code-assistant', 'context'],
  },
  {
    id: '0xagent_006',
    name: 'DeFi Sentinel',
    description: 'Blockchain monitoring and DeFi protocol interaction specialist',
    tvl: 31,
    stakers: 145,
    capabilityIds: ['defi-protocols', 'onchain-data', 'smart-contracts', 'wallet-management', 'data-analysis'],
    model: 'sentinel-v1',
    provider: { name: 'ChainGuard', url: 'https://chainguard.xyz' },
    tags: ['defi', 'blockchain', 'monitoring'],
  },
  {
    id: '0xagent_007',
    name: 'Security Auditor',
    description: 'Smart contract security analysis and vulnerability detection',
    tvl: 28,
    stakers: 132,
    capabilityIds: ['smart-contracts', 'code-review', 'reasoning', 'data-analysis'],
    model: 'auditor-v3',
    provider: { name: 'SecureChain Labs', url: 'https://securechain.dev' },
    tags: ['security', 'audit', 'smart-contracts'],
  },
  {
    id: '0xagent_008',
    name: 'Research Navigator',
    description: 'Academic research aggregation and synthesis',
    tvl: 23,
    stakers: 118,
    capabilityIds: ['web-search', 'document-analysis', 'fact-checking', 'data-analysis', 'natural-language'],
    model: 'navigator-v2',
    provider: { name: 'ResearchAI', url: 'https://researchai.io' },
    tags: ['research', 'academic', 'synthesis'],
  },

  // SILVER TIER (5-6 agents, medium TVL)
  {
    id: '0xagent_009',
    name: 'Content Forge',
    description: 'Multi-lingual content generation and localization',
    tvl: 14,
    stakers: 78,
    capabilityIds: ['content-writing', 'translation', 'natural-language'],
    model: 'forge-v1.5',
    provider: { name: 'ContentAI', url: 'https://contentai.co' },
    tags: ['content', 'writing', 'localization'],
  },
  {
    id: '0xagent_010',
    name: 'NFT Analyst',
    description: 'NFT collection analysis and rarity tracking',
    tvl: 11.5,
    stakers: 62,
    capabilityIds: ['nft-analysis', 'onchain-data', 'data-analysis', 'web-search'],
    model: 'nft-analyst-v2',
    provider: { name: 'NFTLabs', url: 'https://nftlabs.xyz' },
    tags: ['nft', 'rarity', 'collectibles'],
  },
  {
    id: '0xagent_011',
    name: 'Data Pipeline Agent',
    description: 'ETL and data transformation workflows',
    tvl: 9.8,
    stakers: 54,
    capabilityIds: ['database-ops', 'api-integration', 'system-monitoring', 'workflow-orchestration'],
    model: 'pipeline-v3',
    provider: { name: 'DataOps Inc', url: 'https://dataops.io' },
    tags: ['etl', 'data', 'pipeline'],
  },
  {
    id: '0xagent_012',
    name: 'Workflow Maestro',
    description: 'Cross-platform task automation and orchestration',
    tvl: 8.2,
    stakers: 47,
    capabilityIds: ['workflow-orchestration', 'task-scheduling', 'api-integration', 'tool-use'],
    model: 'maestro-v1',
    provider: { name: 'AutomationHub', url: 'https://automationhub.dev' },
    tags: ['automation', 'orchestration', 'workflows'],
  },
  {
    id: '0xagent_013',
    name: 'Vision Annotator',
    description: 'Image analysis and annotation for ML datasets',
    tvl: 7.1,
    stakers: 41,
    capabilityIds: ['vision', 'data-analysis', 'curation'],
    model: 'vision-annotator-v2',
    provider: { name: 'VisionML', url: 'https://visionml.ai' },
    tags: ['vision', 'annotation', 'ml-ops'],
  },
  {
    id: '0xagent_014',
    name: 'Legal Research Assistant',
    description: 'Legal document analysis and case law research',
    tvl: 6.3,
    stakers: 35,
    capabilityIds: ['document-analysis', 'web-search', 'fact-checking', 'natural-language'],
    model: 'legal-assistant-v1',
    provider: { name: 'LegalTech AI', url: 'https://legaltech.ai' },
    tags: ['legal', 'research', 'compliance'],
  },

  // BRONZE TIER (5-6 agents, low TVL)
  {
    id: '0xagent_015',
    name: 'Governance Oracle',
    description: 'DAO governance proposal analysis and voting',
    tvl: 3.8,
    stakers: 22,
    capabilityIds: ['governance', 'onchain-data', 'data-analysis'],
    model: 'governance-v1',
    provider: { name: 'DAOTools', url: 'https://daotools.xyz' },
    tags: ['dao', 'governance', 'voting'],
  },
  {
    id: '0xagent_016',
    name: 'Translation Agent',
    description: 'Real-time translation for 50+ languages',
    tvl: 2.9,
    stakers: 18,
    capabilityIds: ['translation', 'natural-language'],
    model: 'translator-v3',
    provider: { name: 'LinguaAI', url: 'https://linguaai.com' },
    tags: ['translation', 'localization', 'i18n'],
  },
  {
    id: '0xagent_017',
    name: 'Image Generator',
    description: 'Text-to-image generation using diffusion models',
    tvl: 2.4,
    stakers: 15,
    capabilityIds: ['image-generation', 'vision'],
    model: 'imagen-v2',
    provider: { name: 'GenerativeAI', url: 'https://generativeai.art' },
    tags: ['image', 'generation', 'diffusion'],
  },
  {
    id: '0xagent_018',
    name: 'Audio Transcriber',
    description: 'High-accuracy speech-to-text transcription',
    tvl: 1.8,
    stakers: 12,
    capabilityIds: ['audio-processing', 'natural-language'],
    model: 'transcriber-v4',
    provider: { name: 'AudioAI', url: 'https://audioai.io' },
    tags: ['audio', 'transcription', 'speech'],
  },
  {
    id: '0xagent_019',
    name: 'Sentiment Analyzer',
    description: 'Social media sentiment analysis and trend detection',
    tvl: 1.5,
    stakers: 10,
    capabilityIds: ['natural-language', 'data-analysis', 'web-search'],
    model: 'sentiment-v1',
    provider: { name: 'SocialAI', url: 'https://socialai.net' },
    tags: ['sentiment', 'social-media', 'trends'],
  },
  {
    id: '0xagent_020',
    name: 'Code Formatter',
    description: 'Multi-language code formatting and linting',
    tvl: 1.2,
    stakers: 8,
    capabilityIds: ['code-review', 'file-management'],
    model: 'formatter-v2',
    provider: { name: 'DevTools Inc', url: 'https://devtools.dev' },
    tags: ['formatting', 'linting', 'code-quality'],
  },

  // UNRANKED TIER (5-6 agents, very low/zero TVL) + PATHOLOGICAL CASES
  {
    id: '0xagent_021',
    name: 'Ghost Agent',
    description: '',
    tvl: 0,
    stakers: 0,
    capabilityIds: [],
    model: undefined,
    tags: [],
  },
  {
    id: '0xagent_022',
    name: 'Capability Hoarder',
    description: 'Agent claiming every capability without specialization',
    tvl: 0.1,
    stakers: 2,
    capabilityIds: CAPABILITIES.map(c => c.id), // All 30 capabilities
    model: 'hoarder-v0.1',
    tags: ['experimental', 'unproven', 'jack-of-all-trades'],
  },
  {
    id: '0xagent_023',
    name: 'Skeleton Agent',
    description: '',
    tvl: 0.05,
    stakers: 1,
    capabilityIds: ['natural-language'],
    model: 'skeleton-v0.1',
    tags: [],
  },
  {
    id: '0xagent_024',
    name: 'Brand New Agent',
    description: 'Just registered today, testing the registry',
    tvl: 0,
    stakers: 0,
    capabilityIds: ['code-generation', 'natural-language', 'reasoning'],
    model: 'new-v0.1',
    provider: { name: 'Indie Developer', url: 'https://github.com/indie-dev' },
    tags: ['new', 'experimental'],
  },
  {
    id: '0xagent_025',
    name: 'Legacy Agent v1',
    description: 'Deprecated agent from 2023, no longer maintained',
    tvl: 0.3,
    stakers: 4,
    capabilityIds: ['natural-language'],
    model: 'legacy-v1.0',
    provider: { name: 'Abandoned Project' },
    tags: ['deprecated', 'legacy', 'unmaintained'],
  },
]

// Step 2: Create vaults for all agents
const allVaults = agentDataList.map(data =>
  createVault(data.id, data.stakers, data.tvl)
)

// Step 3: Create full Agent objects with trust signals and triples
export const MOCK_AGENTS: Agent[] = agentDataList.map((data, index) => {
  const vault = allVaults[index]
  const trustSignal = createTrustSignal(vault, allVaults)

  // Get capability objects
  const capabilities = data.capabilityIds
    .map(id => findCapabilityById(id))
    .filter(c => c !== undefined)

  // Create has-capability triples
  const hasCapabilityTriples = data.capabilityIds.map(capId =>
    createHasCapabilityTriple(data.id, data.name, capId)
  )

  const createdAt = data.id === '0xagent_024'
    ? new Date().toISOString() // Brand New Agent created today
    : new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000).toISOString()

  const agent: Agent = {
    id: data.id,
    metadata: {
      name: data.name,
      description: data.description,
      version: '1.0.0',
      model: data.model,
      endpoint: data.endpoint,
      provider: data.provider,
      tags: data.tags,
      createdAt,
    },
    capabilities,
    vault,
    trustSignal,
    triples: hasCapabilityTriples,
  }

  // Attach optional profiles if present
  const securityProfile = SECURITY_PROFILES[data.id]
  if (securityProfile) agent.securityProfile = securityProfile

  const reputationProfile = REPUTATION_PROFILES[data.id]
  if (reputationProfile) agent.reputationProfile = reputationProfile

  return agent
})

// Step 4: Add cross-agent relationships (uses, delegates-to, etc.)
// These will be populated after skills are created in skills.ts
// For now, add some agent-to-agent relationships

// Add delegation relationships
MOCK_AGENTS[1].triples.push(
  createTriple('0xagent_002', 'GPT-4o Orchestrator', 'Agent', 'delegates-to', 'delegates-to', '0xagent_004', 'Devin Code Agent', 'Agent')
)
MOCK_AGENTS[1].triples.push(
  createTriple('0xagent_002', 'GPT-4o Orchestrator', 'Agent', 'delegates-to', 'delegates-to', '0xagent_006', 'DeFi Sentinel', 'Agent')
)

// Add depends-on relationships
MOCK_AGENTS[3].triples.push(
  createTriple('0xagent_004', 'Devin Code Agent', 'Agent', 'depends-on', 'depends-on', '0xagent_005', 'Cursor AI', 'Agent')
)

// Add compatible-with relationships
MOCK_AGENTS[0].triples.push(
  createTriple('0xagent_001', 'Claude Opus Agent', 'Agent', 'compatible-with', 'compatible-with', '0xagent_002', 'GPT-4o Orchestrator', 'Agent')
)
MOCK_AGENTS[4].triples.push(
  createTriple('0xagent_005', 'Cursor AI', 'Agent', 'compatible-with', 'compatible-with', '0xagent_004', 'Devin Code Agent', 'Agent')
)
MOCK_AGENTS[5].triples.push(
  createTriple('0xagent_006', 'DeFi Sentinel', 'Agent', 'compatible-with', 'compatible-with', '0xagent_015', 'Governance Oracle', 'Agent')
)

// Add recommends relationships
MOCK_AGENTS[0].triples.push(
  createTriple('0xagent_001', 'Claude Opus Agent', 'Agent', 'recommends', 'recommends', '0xagent_005', 'Cursor AI', 'Agent')
)
MOCK_AGENTS[6].triples.push(
  createTriple('0xagent_007', 'Security Auditor', 'Agent', 'recommends', 'recommends', '0xagent_006', 'DeFi Sentinel', 'Agent')
)

// Add is-version-of relationship
MOCK_AGENTS[24].triples.push(
  createTriple('0xagent_025', 'Legacy Agent v1', 'Agent', 'is-version-of', 'is-version-of', '0xagent_024', 'Brand New Agent', 'Agent')
)

// Add created-by relationships (to organizations)
MOCK_AGENTS[0].triples.push(
  createTriple('0xagent_001', 'Claude Opus Agent', 'Agent', 'created-by', 'created-by', '0xorg_anthropic', 'Anthropic', 'Organization')
)
MOCK_AGENTS[1].triples.push(
  createTriple('0xagent_002', 'GPT-4o Orchestrator', 'Agent', 'created-by', 'created-by', '0xorg_openai', 'OpenAI', 'Organization')
)
MOCK_AGENTS[2].triples.push(
  createTriple('0xagent_003', 'DeepMind AlphaCode Pro', 'Agent', 'created-by', 'created-by', '0xorg_deepmind', 'DeepMind', 'Organization')
)
MOCK_AGENTS[3].triples.push(
  createTriple('0xagent_004', 'Devin Code Agent', 'Agent', 'created-by', 'created-by', '0xorg_cognition', 'Cognition AI', 'Organization')
)
MOCK_AGENTS[23].triples.push(
  createTriple('0xagent_024', 'Brand New Agent', 'Agent', 'created-by', 'created-by', '0xperson_indie', 'Indie Developer', 'Person')
)

// Add uses relationships (agent -> skill)
// Claude Opus Agent uses: Filesystem MCP, Git MCP, Code Review Skill
MOCK_AGENTS[0].triples.push(
  createUsesSkillTriple('0xagent_001', 'Claude Opus Agent', '0xskill_001', 'Filesystem MCP')
)
MOCK_AGENTS[0].triples.push(
  createUsesSkillTriple('0xagent_001', 'Claude Opus Agent', '0xskill_004', 'Git MCP')
)
MOCK_AGENTS[0].triples.push(
  createUsesSkillTriple('0xagent_001', 'Claude Opus Agent', '0xskill_008', 'Code Review Skill')
)

// GPT-4o Orchestrator uses: Web Browser Tool, Code Interpreter
MOCK_AGENTS[1].triples.push(
  createUsesSkillTriple('0xagent_002', 'GPT-4o Orchestrator', '0xskill_016', 'Web Browser Tool')
)
MOCK_AGENTS[1].triples.push(
  createUsesSkillTriple('0xagent_002', 'GPT-4o Orchestrator', '0xskill_017', 'Code Interpreter')
)

// Devin Code Agent uses: Filesystem MCP, Git MCP, Deploy Pipeline, Test Runner
MOCK_AGENTS[3].triples.push(
  createUsesSkillTriple('0xagent_004', 'Devin Code Agent', '0xskill_001', 'Filesystem MCP')
)
MOCK_AGENTS[3].triples.push(
  createUsesSkillTriple('0xagent_004', 'Devin Code Agent', '0xskill_004', 'Git MCP')
)
MOCK_AGENTS[3].triples.push(
  createUsesSkillTriple('0xagent_004', 'Devin Code Agent', '0xskill_009', 'Deploy Pipeline')
)
MOCK_AGENTS[3].triples.push(
  createUsesSkillTriple('0xagent_004', 'Devin Code Agent', '0xskill_010', 'Test Runner')
)

// Cursor AI uses: Code Review Skill, Commit Helper
MOCK_AGENTS[4].triples.push(
  createUsesSkillTriple('0xagent_005', 'Cursor AI', '0xskill_008', 'Code Review Skill')
)
MOCK_AGENTS[4].triples.push(
  createUsesSkillTriple('0xagent_005', 'Cursor AI', '0xskill_012', 'Commit Helper')
)

// DeFi Sentinel uses: Crypto Wallet MCP, Market Analyzer
MOCK_AGENTS[5].triples.push(
  createUsesSkillTriple('0xagent_006', 'DeFi Sentinel', '0xskill_007', 'Crypto Wallet MCP')
)
MOCK_AGENTS[5].triples.push(
  createUsesSkillTriple('0xagent_006', 'DeFi Sentinel', '0xskill_013', 'Market Analyzer')
)

// Security Auditor uses: Shell Execute MCP (even though flagged - realistic)
MOCK_AGENTS[6].triples.push(
  createUsesSkillTriple('0xagent_007', 'Security Auditor', '0xskill_006', 'Shell Execute MCP')
)

// Research Navigator uses: Web Fetch MCP, Web Browser Tool
MOCK_AGENTS[7].triples.push(
  createUsesSkillTriple('0xagent_008', 'Research Navigator', '0xskill_002', 'Web Fetch MCP')
)
MOCK_AGENTS[7].triples.push(
  createUsesSkillTriple('0xagent_008', 'Research Navigator', '0xskill_016', 'Web Browser Tool')
)

// Data Pipeline Agent uses: Database MCP
MOCK_AGENTS[10].triples.push(
  createUsesSkillTriple('0xagent_011', 'Data Pipeline Agent', '0xskill_003', 'Database MCP')
)

// Add has-used relationships (usage records)
MOCK_AGENTS[1].triples.push(
  createTriple('0xagent_002', 'GPT-4o Orchestrator', 'Agent', 'has-used', 'has-used', '0xagent_004', 'Devin Code Agent', 'Agent')
)
MOCK_AGENTS[0].triples.push(
  createTriple('0xagent_001', 'Claude Opus Agent', 'Agent', 'has-used', 'has-used', '0xskill_001', 'Filesystem MCP', 'Skill')
)
MOCK_AGENTS[3].triples.push(
  createTriple('0xagent_004', 'Devin Code Agent', 'Agent', 'has-used', 'has-used', '0xskill_009', 'Deploy Pipeline', 'Skill')
)
