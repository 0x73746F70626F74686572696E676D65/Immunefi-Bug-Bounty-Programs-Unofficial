import type { LoaderFunctionArgs } from 'react-router'
import { createRepository } from '~/data/repository/provider'
import { handleOptions, jsonResponse } from '~/lib/api/types'

export async function loader({ request }: LoaderFunctionArgs) {
  const optionsResponse = handleOptions(request)
  if (optionsResponse) return optionsResponse

  const repo = createRepository()
  const predicates = await repo.listPredicates()

  return jsonResponse(predicates)
}
