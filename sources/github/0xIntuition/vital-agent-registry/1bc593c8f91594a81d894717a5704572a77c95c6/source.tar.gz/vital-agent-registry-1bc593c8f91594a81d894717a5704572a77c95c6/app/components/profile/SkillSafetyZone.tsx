import type { Skill } from '~/types'
import { cn } from '~/lib/utils'

// ── Constants ──────────────────────────────────────────────────────────────

const GREEN = '#22c55e'
const YELLOW = '#eab308'
const RED = '#ef4444'

// ── Helpers ────────────────────────────────────────────────────────────────

function safetyColor(ratio: number): string {
  if (ratio > 0.8) return GREEN
  if (ratio >= 0.5) return YELLOW
  return RED
}

function safetyLabel(ratio: number): string {
  if (ratio > 0.8) return 'VERIFIED'
  if (ratio >= 0.5) return 'UNVERIFIED'
  return 'FLAGGED'
}

function trustTierLabel(tier: string): string {
  return tier.toUpperCase()
}

function trustTierColor(tier: string): string {
  switch (tier.toLowerCase()) {
    case 'elite':
      return GREEN
    case 'established':
      return YELLOW
    case 'emerging':
      return '#a78bfa'
    default:
      return '#4a4a60'
  }
}

// ── SafetyRing ──────────────────────────────────────────────────────────────

interface SafetyRingProps {
  ratio: number
  size?: number
}

function SafetyRing({ ratio, size = 80 }: SafetyRingProps) {
  const color = safetyColor(ratio)
  const radius = (size - 8) / 2
  const circumference = 2 * Math.PI * radius
  const pct = ratio * 100
  const fill = (pct / 100) * circumference
  const label = `${Math.round(pct)}%`
  const fontSize = size <= 64 ? 13 : 16

  return (
    <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        {/* Track */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="#1e1e2e"
          strokeWidth={4}
        />
        {/* Fill */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={4}
          strokeDasharray={`${fill} ${circumference}`}
          strokeLinecap="round"
          style={{
            filter: `drop-shadow(0 0 3px ${color}80)`,
            transition: 'stroke-dasharray 0.4s ease',
          }}
        />
      </svg>
      <div
        style={{
          position: 'absolute',
          inset: 0,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontFamily: 'monospace',
          fontSize,
          fontWeight: 900,
          color,
          letterSpacing: '-0.02em',
        }}
      >
        {label}
      </div>
    </div>
  )
}

// ── ForAgainstBar ──────────────────────────────────────────────────────────

interface ForAgainstBarProps {
  forStake: number
  againstStake: number
}

function ForAgainstBar({ forStake, againstStake }: ForAgainstBarProps) {
  const total = forStake + againstStake
  const forPct = total > 0 ? (forStake / total) * 100 : 0
  const agPct = total > 0 ? (againstStake / total) * 100 : 0

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {/* FOR bar */}
      <div>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            fontFamily: 'monospace',
            fontSize: 9,
            marginBottom: 3,
          }}
        >
          <span style={{ color: '#4a4a60', letterSpacing: '0.08em' }}>FOR</span>
          <span style={{ color: GREEN, fontWeight: 700 }}>{forStake.toFixed(3)} TRUST</span>
        </div>
        <div style={{ height: 4, background: '#1e1e2e', borderRadius: 2, overflow: 'hidden' }}>
          <div
            style={{
              height: '100%',
              width: `${forPct}%`,
              background: GREEN,
              boxShadow: `0 0 6px ${GREEN}60`,
              borderRadius: 2,
              transition: 'width 0.4s ease',
            }}
          />
        </div>
      </div>

      {/* AGAINST bar */}
      <div>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            fontFamily: 'monospace',
            fontSize: 9,
            marginBottom: 3,
          }}
        >
          <span style={{ color: '#4a4a60', letterSpacing: '0.08em' }}>AGAINST</span>
          <span style={{ color: RED, fontWeight: 700 }}>{againstStake.toFixed(3)} TRUST</span>
        </div>
        <div style={{ height: 4, background: '#1e1e2e', borderRadius: 2, overflow: 'hidden' }}>
          <div
            style={{
              height: '100%',
              width: `${agPct}%`,
              background: RED,
              boxShadow: `0 0 6px ${RED}60`,
              borderRadius: 2,
              transition: 'width 0.4s ease',
            }}
          />
        </div>
      </div>
    </div>
  )
}

// ── MetricsRow ─────────────────────────────────────────────────────────────

interface MetricsRowProps {
  label: string
  value: string
  valueColor?: string
}

function MetricsRow({ label, value, valueColor = '#e0e0e8' }: MetricsRowProps) {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'space-between',
        fontFamily: 'monospace',
        fontSize: 10,
      }}
    >
      <span style={{ color: '#4a4a60' }}>{label}</span>
      <span style={{ color: valueColor, fontWeight: 700 }}>{value}</span>
    </div>
  )
}

// ── StatusDot ──────────────────────────────────────────────────────────────

interface StatusDotProps {
  color: string
  label: string
}

function StatusDot({ color, label }: StatusDotProps) {
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 5,
        fontFamily: 'monospace',
        fontSize: 10,
        fontWeight: 700,
        color,
      }}
    >
      <span
        style={{
          width: 6,
          height: 6,
          borderRadius: '50%',
          background: color,
          boxShadow: `0 0 5px ${color}80`,
          flexShrink: 0,
        }}
      />
      {label}
    </span>
  )
}

// ── VoucherRow ─────────────────────────────────────────────────────────────

interface VoucherRowProps {
  rank: number
  address: string
  amount: number
  maxAmount: number
}

function VoucherRow({ rank, address, amount, maxAmount }: VoucherRowProps) {
  const barPct = maxAmount > 0 ? (amount / maxAmount) * 100 : 0

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        fontFamily: 'monospace',
        fontSize: 10,
      }}
    >
      <span style={{ color: '#4a4a60', flexShrink: 0, width: 10 }}>{rank}.</span>
      <span style={{ color: '#6b6b80', flexShrink: 0, fontSize: 9 }}>{address}</span>
      <div style={{ flex: 1, height: 3, background: '#1e1e2e', borderRadius: 2, overflow: 'hidden' }}>
        <div
          style={{
            height: '100%',
            width: `${barPct}%`,
            background: GREEN,
            boxShadow: `0 0 4px ${GREEN}60`,
            borderRadius: 2,
          }}
        />
      </div>
      <span style={{ color: GREEN, fontWeight: 700, flexShrink: 0, fontSize: 9 }}>
        {amount.toFixed(2)} TRUST
      </span>
    </div>
  )
}

// ── Props ──────────────────────────────────────────────────────────────────

interface SkillSafetyZoneProps {
  skill: Skill
  className?: string
}

// ── Main Component ─────────────────────────────────────────────────────────

export function SkillSafetyZone({ skill, className }: SkillSafetyZoneProps) {
  const { safetySignal, trustSignal } = skill
  const isFlagged = safetySignal.status === 'flagged'

  const forStake = parseFloat(safetySignal.forStake) || 0
  const againstStake = parseFloat(safetySignal.againstStake) || 0
  const totalTvl = forStake + againstStake
  const safetyRatio = safetySignal.safetyRatio
  const safetyStatusColor = safetyColor(safetyRatio)
  const safetyStatusLabel = safetyLabel(safetyRatio)
  const tierColor = trustTierColor(trustSignal.tier)

  // Deterministic mock vouchers derived from skill id
  const idStr = skill.id.replace(/^0x/, '').padEnd(64, '0')
  const mockVouchers =
    safetySignal.forCount > 0
      ? [
          {
            address: `0x${idStr.slice(0, 4)}...${idStr.slice(-4)}`,
            amount: forStake * 0.4,
          },
          {
            address: `0x${idStr.slice(8, 12)}...${idStr.slice(-12, -8)}`,
            amount: forStake * 0.3,
          },
          {
            address: `0x${idStr.slice(16, 20)}...${idStr.slice(-20, -16)}`,
            amount: forStake * 0.2,
          },
        ]
      : []

  const maxVoucherAmount = mockVouchers.length > 0 ? mockVouchers[0].amount : 1

  return (
    <>
      <style>{`
        @keyframes safezone-fade-in {
          from { opacity: 0; }
          to   { opacity: 1; }
        }
      `}</style>

      <div
        className={cn(
          'rounded-[var(--radius-card)] border border-border shadow-[var(--shadow-card)] overflow-hidden',
          className,
        )}
        style={{ background: '#0a0a12' }}
      >
        {/* Header */}
        <div
          style={{
            padding: '9px 16px 7px',
            borderBottom: '1px solid #1e1e2e',
            fontFamily: 'monospace',
            fontSize: 9,
            fontWeight: 700,
            letterSpacing: '0.12em',
            textTransform: 'uppercase' as const,
            color: '#4a4a60',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <span>SAFETY SIGNALS</span>
          {isFlagged && (
            <span style={{ color: RED, letterSpacing: '0.08em' }}>▲ ALERT</span>
          )}
        </div>

        <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 16, animation: 'safezone-fade-in 0.18s ease both' }}>

          {/* Flagged warning banner */}
          {isFlagged && safetySignal.flagReason && (
            <div
              style={{
                padding: '10px 14px',
                background: `${RED}12`,
                border: `1px solid ${RED}33`,
                borderLeft: `3px solid ${RED}`,
                borderRadius: 6,
                display: 'flex',
                flexDirection: 'column' as const,
                gap: 4,
              }}
            >
              <div
                style={{
                  fontFamily: 'monospace',
                  fontSize: 10,
                  fontWeight: 700,
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase' as const,
                  color: RED,
                }}
              >
                FLAGGED: POTENTIALLY UNSAFE
              </div>
              <div style={{ fontFamily: 'monospace', fontSize: 10, color: '#c0c0cc' }}>
                {safetySignal.flagReason}
              </div>
              <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#6b6b80', letterSpacing: '0.04em' }}>
                USE AT YOUR OWN RISK. REVIEW SIGNALS BELOW BEFORE INSTALLING.
              </div>
            </div>
          )}

          {/* Main split: ring + metrics */}
          <div style={{ display: 'flex', gap: 16 }}>

            {/* Left column: Safety ring + for/against bars */}
            <div
              style={{
                flex: '0 0 auto',
                display: 'flex',
                flexDirection: 'column' as const,
                alignItems: 'center',
                gap: 12,
                padding: '12px 16px',
                background: '#0e0e16',
                border: '1px solid #1e1e2e',
                borderRadius: 8,
                minWidth: 160,
              }}
            >
              <div
                style={{
                  fontFamily: 'monospace',
                  fontSize: 9,
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase' as const,
                  color: '#4a4a60',
                  alignSelf: 'flex-start',
                }}
              >
                SAFETY RATIO
              </div>

              <SafetyRing ratio={safetyRatio} size={80} />

              <div
                style={{
                  fontFamily: 'monospace',
                  fontSize: 9,
                  letterSpacing: '0.1em',
                  textTransform: 'uppercase' as const,
                  color: safetyStatusColor,
                  fontWeight: 700,
                }}
              >
                {safetyStatusLabel}
              </div>

              <div style={{ width: '100%' }}>
                <ForAgainstBar forStake={forStake} againstStake={againstStake} />
              </div>
            </div>

            {/* Right column: Metrics grid */}
            <div
              style={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column' as const,
                gap: 6,
                padding: '12px 14px',
                background: '#0e0e16',
                border: '1px solid #1e1e2e',
                borderRadius: 8,
              }}
            >
              <div
                style={{
                  fontFamily: 'monospace',
                  fontSize: 9,
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase' as const,
                  color: '#4a4a60',
                  marginBottom: 4,
                }}
              >
                METRICS
              </div>

              <MetricsRow
                label="VOUCHERS"
                value={`${safetySignal.forCount}`}
                valueColor={GREEN}
              />
              <MetricsRow
                label="FLAGGERS"
                value={`${safetySignal.againstCount}`}
                valueColor={safetySignal.againstCount > 0 ? RED : '#e0e0e8'}
              />
              <MetricsRow
                label="FOR STAKE"
                value={`${forStake.toFixed(3)} TRUST`}
                valueColor={GREEN}
              />
              <MetricsRow
                label="AGAINST STAKE"
                value={`${againstStake.toFixed(3)} TRUST`}
                valueColor={againstStake > 0 ? RED : '#e0e0e8'}
              />
              <MetricsRow
                label="TOTAL TVL"
                value={`${totalTvl.toFixed(3)} TRUST`}
              />

              {/* Safety status */}
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  fontFamily: 'monospace',
                  fontSize: 10,
                  marginTop: 2,
                }}
              >
                <span style={{ color: '#4a4a60' }}>SAFETY</span>
                <StatusDot color={safetyStatusColor} label={safetyStatusLabel} />
              </div>

              {/* Trust tier */}
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  fontFamily: 'monospace',
                  fontSize: 10,
                }}
              >
                <span style={{ color: '#4a4a60' }}>TRUST TIER</span>
                <StatusDot color={tierColor} label={trustTierLabel(trustSignal.tier)} />
              </div>
            </div>
          </div>

          {/* Top Vouchers section */}
          {mockVouchers.length > 0 && (
            <div
              style={{
                padding: '12px 14px',
                background: '#0e0e16',
                border: '1px solid #1e1e2e',
                borderRadius: 8,
                display: 'flex',
                flexDirection: 'column' as const,
                gap: 8,
              }}
            >
              <div
                style={{
                  fontFamily: 'monospace',
                  fontSize: 9,
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase' as const,
                  color: '#4a4a60',
                  marginBottom: 2,
                }}
              >
                TOP VOUCHERS
              </div>
              {mockVouchers.map((voucher, i) => (
                <VoucherRow
                  key={voucher.address}
                  rank={i + 1}
                  address={voucher.address}
                  amount={voucher.amount}
                  maxAmount={maxVoucherAmount}
                />
              ))}
            </div>
          )}

          {/* Explanation text */}
          <div
            style={{
              fontFamily: 'monospace',
              fontSize: 10,
              color: '#6b6b80',
              lineHeight: 1.6,
              letterSpacing: '0.02em',
            }}
          >
            Safety signals are economic attestations from the community. Stake TRUST to{' '}
            <span style={{ color: GREEN }}>vouch</span> or{' '}
            <span style={{ color: RED }}>flag</span> a skill. A higher safety ratio indicates
            stronger community trust.
          </div>
        </div>
      </div>
    </>
  )
}
