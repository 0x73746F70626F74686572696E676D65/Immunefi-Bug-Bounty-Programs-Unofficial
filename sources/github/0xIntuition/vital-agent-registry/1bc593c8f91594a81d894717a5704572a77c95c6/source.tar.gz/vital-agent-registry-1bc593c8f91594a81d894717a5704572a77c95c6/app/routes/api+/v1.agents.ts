import { createRepository } from '~/data/repository/provider'
import { agentListSchema } from '~/lib/api/validation'
import { handleOptions, parseQueryParams, jsonResponse, errorResponse } from '~/lib/api/types'
import type { LoaderFunctionArgs } from 'react-router'

export async function loader({ request }: LoaderFunctionArgs) {
  try {
    const optRes = handleOptions(request)
    if (optRes) return optRes

    const parsed = parseQueryParams(request, agentListSchema)
    if ('error' in parsed) return parsed.error

    const { q, capability, trustTier, minTrustTier, sort, limit, offset } = parsed.data
    const repo = createRepository()

    // Use search if query provided, otherwise list
    if (q) {
      const agents = await repo.searchAgents(q, {
        capabilities: capability ? [capability] : undefined,
        minTrustTier: minTrustTier || trustTier,
        sortBy: sort,
        limit,
        offset,
      })
      return jsonResponse(agents, { total: agents.length, limit, offset })
    }

    const result = await repo.listAgents({
      capability,
      trustTier: minTrustTier || trustTier,
      sortBy: sort,
      limit,
      offset,
    })

    return jsonResponse(result.items, { total: result.total, limit, offset })
  } catch (error) {
    return errorResponse(
      'Failed to list agents',
      'INTERNAL_ERROR',
      500,
      { message: error instanceof Error ? error.message : 'Unknown error' },
    )
  }
}
