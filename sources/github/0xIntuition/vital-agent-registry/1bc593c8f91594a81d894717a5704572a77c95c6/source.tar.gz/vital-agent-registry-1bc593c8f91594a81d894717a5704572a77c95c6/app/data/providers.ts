import type { Provider } from '~/types'

export const PROVIDERS: Provider[] = [
  { id: 'anthropic', name: 'Anthropic', url: 'https://anthropic.com', description: 'AI safety company' },
  { id: 'openai', name: 'OpenAI', url: 'https://openai.com', description: 'AI research lab' },
  { id: 'google', name: 'Google DeepMind', url: 'https://deepmind.google', description: 'Google AI research division' },
  { id: 'meta', name: 'Meta', url: 'https://ai.meta.com', description: 'Open source AI models' },
  { id: 'mistral', name: 'Mistral AI', url: 'https://mistral.ai', description: 'European AI company' },
  { id: 'xai', name: 'xAI', url: 'https://x.ai', description: 'Elon Musk AI company' },
  { id: 'cohere', name: 'Cohere', url: 'https://cohere.com', description: 'Enterprise NLP platform' },
  { id: 'stability', name: 'Stability AI', url: 'https://stability.ai', description: 'Generative AI models' },
  { id: 'perplexity', name: 'Perplexity', url: 'https://perplexity.ai', description: 'Search-augmented AI' },
  { id: 'together', name: 'Together AI', url: 'https://together.ai', description: 'Open model hosting platform' },
  { id: 'groq', name: 'Groq', url: 'https://groq.com', description: 'Ultra-fast inference hardware' },
  { id: 'other', name: 'Other', description: 'Custom or unlisted provider' },
]

export function findProviderById(id: string): Provider | undefined {
  return PROVIDERS.find((p) => p.id === id)
}

export function getProviderUrl(id: string): string | undefined {
  return findProviderById(id)?.url
}

export function getProviderOptions(): Array<{ value: string; label: string }> {
  return PROVIDERS.map((p) => ({
    value: p.id,
    label: p.name,
  }))
}
