export const springs = {
	snappy: { stiffness: 400, damping: 30 },
	gentle: { stiffness: 200, damping: 25 },
	bouncy: { stiffness: 300, damping: 15 },
	stiff: { stiffness: 500, damping: 35 },
} as const satisfies Record<string, { stiffness: number; damping: number }>

export type SpringPreset = keyof typeof springs
