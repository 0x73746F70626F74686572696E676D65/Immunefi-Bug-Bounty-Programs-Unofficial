import type { ReactNode } from 'react'
import { Sidebar } from './Sidebar'
import { useSidebar } from '~/lib/hooks/useSidebar'

interface RegistryLayoutProps {
  children: ReactNode
  header?: ReactNode
}

/**
 * RegistryLayout — sidebar + main content shell
 *
 * Collapsible sidebar with spring-like transition.
 * Main content area scrolls independently.
 */
export function RegistryLayout({ children, header }: RegistryLayoutProps) {
  const { collapsed, toggle } = useSidebar()

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar collapsed={collapsed} onToggle={toggle} />
      <main
        className="flex-1 overflow-y-auto"
        style={{
          marginLeft: collapsed
            ? 'var(--sidebar-collapsed-width)'
            : 'var(--sidebar-width)',
          transition:
            'margin-left 300ms cubic-bezier(0.25, 0.46, 0.45, 0.94)',
        }}
      >
        {/* Skip to main content link (a11y) */}
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[100] focus:rounded focus:border focus:border-border focus:bg-background focus:px-4 focus:py-2 focus:text-foreground"
        >
          Skip to main content
        </a>

        {header && (
          <div className="sticky top-0 z-10 border-b border-app-line bg-app-box-dark/80 px-6 backdrop-blur-md">
            {header}
          </div>
        )}

        <div id="main-content" className="mx-auto max-w-6xl px-6 py-6">
          {children}
        </div>
      </main>
    </div>
  )
}
