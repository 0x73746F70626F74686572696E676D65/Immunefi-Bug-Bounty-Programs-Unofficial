import type { ActionFunctionArgs, LoaderFunctionArgs } from 'react-router'
import { handleOptions, parseJsonBody, jsonResponse, errorResponse } from '~/lib/api/types'
import { fundingPlanRequestSchema, buildOnboardingContract } from '~/lib/api/onboarding'

export async function loader({ request }: LoaderFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes
  return errorResponse('Method not allowed. Use POST for funding plan.', 'METHOD_NOT_ALLOWED', 405)
}

export async function action({ request }: ActionFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const parsed = await parseJsonBody(request, fundingPlanRequestSchema)
  if ('error' in parsed) return parsed.error

  const input = parsed.data
  const available = BigInt(input.availableFundsWei)
  const required = BigInt(input.requiredFundsWei)
  const recommended = BigInt(input.recommendedFundsWei)
  const budget = BigInt(input.sponsorBudgetWei)

  const effectiveRecommended = recommended > budget ? budget : recommended

  const contract = buildOnboardingContract({
    agentId: input.agentId,
    hasWallet: true,
    availableFundsWei: available,
    requiredFundsWei: required,
    isRegistered: false,
    isActive: false,
    indexerLagBlocks: 0,
    policyBlocked: input.policyBlocked,
  })

  if (input.policyBlocked) {
    return errorResponse(
      'Policy blocks funding plan generation for this agent',
      'POLICY_BLOCKED',
      403,
      { contract },
    )
  }

  if (budget < required) {
    return errorResponse(
      'Sponsor budget is below minimum runway',
      'BUDGET_CONSTRAINT',
      400,
      {
        contract,
        minimumRunwayWei: required.toString(),
        sponsorBudgetWei: budget.toString(),
      },
    )
  }

  return jsonResponse({
    contract,
    runway: {
      minimumWei: required.toString(),
      recommendedWei: effectiveRecommended.toString(),
      budgetCapped: recommended > budget,
    },
    budget: {
      sponsorBudgetWei: budget.toString(),
      availableFundsWei: available.toString(),
      additionalRequiredWei: available >= required ? '0' : (required - available).toString(),
    },
    assumptions: [
      'minimum runway maps to requiredFundsWei',
      'recommended runway is capped by sponsor budget',
      'no server-side key custody or signing',
    ],
  })
}
