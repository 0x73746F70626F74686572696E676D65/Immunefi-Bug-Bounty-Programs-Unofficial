import type { RegistryItem } from './RegistryGrid'
import { AgentViewAgentCard, AgentViewSkillCard } from './AgentViewCard'

interface AgentViewGridProps {
  items: RegistryItem[]
  className?: string
}

/**
 * AgentViewGrid — Matrix/terminal-style grid for agent view
 *
 * Renders agents and skills with terminal aesthetic, monospace font, signal bars.
 */
export function AgentViewGrid({ items, className = '' }: AgentViewGridProps) {
  return (
    <div className="space-y-4">
      {/* Terminal-style header */}
      <div className="font-mono text-sm text-[hsl(142_71%_45%)] border-b border-[hsl(142_71%_45%/0.3)] pb-2">
        <span>&gt; REGISTRY SCAN: {items.length} ENTITIES FOUND</span>
      </div>

      {/* Grid layout */}
      <div
        className={`grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 ${className}`}
      >
        {items.map((item) => {
          if (item.type === 'agent') {
            return <AgentViewAgentCard key={item.entity.id} agent={item.entity} />
          } else {
            return <AgentViewSkillCard key={item.entity.id} skill={item.entity} />
          }
        })}
      </div>
    </div>
  )
}
