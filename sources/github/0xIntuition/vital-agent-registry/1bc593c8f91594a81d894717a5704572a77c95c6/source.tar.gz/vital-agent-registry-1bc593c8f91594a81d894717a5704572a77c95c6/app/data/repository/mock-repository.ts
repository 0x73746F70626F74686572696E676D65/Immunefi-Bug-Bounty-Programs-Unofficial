import type {
  RegistryRepository,
  SearchOptions,
  ListOptions,
  MatchOptions,
  PaginatedResult,
  Agent,
  AgentCard,
  AgentMetadata,
  Skill,
  SkillMetadata,
  Capability,
  PredicateDefinition,
  Platform,
  TrustSignal,
  SortField,
  EntityType,
} from '~/types'
import { TRUST_TIER_ORDER } from '~/types'

interface MockData {
  agents: Agent[]
  skills: Skill[]
  capabilities: Capability[]
  predicates: PredicateDefinition[]
  platforms: Platform[]
}

export class MockRegistryRepository implements RegistryRepository {
  private agents: Agent[]
  private skills: Skill[]
  private capabilities: Capability[]
  private predicates: PredicateDefinition[]
  private platforms: Platform[]

  constructor(data: MockData) {
    this.agents = data.agents
    this.skills = data.skills
    this.capabilities = data.capabilities
    this.predicates = data.predicates
    this.platforms = data.platforms
  }

  // --- Agent methods ---

  async findAgent(id: string): Promise<Agent | null> {
    return this.agents.find((a) => a.id === id) ?? null
  }

  async searchAgents(query: string, options?: SearchOptions): Promise<Agent[]> {
    const lowerQuery = query.toLowerCase().trim()
    if (!lowerQuery) return this.applyAgentOptions(this.agents, options)

    let results = this.agents.filter((agent) => {
      const nameMatch = agent.metadata.name.toLowerCase().includes(lowerQuery)
      const descMatch = agent.metadata.description.toLowerCase().includes(lowerQuery)
      const capMatch = agent.capabilities.some((c) =>
        c.name.toLowerCase().includes(lowerQuery),
      )
      const tagMatch = agent.metadata.tags?.some((t) =>
        t.toLowerCase().includes(lowerQuery),
      ) ?? false
      return nameMatch || descMatch || capMatch || tagMatch
    })

    return this.applyAgentOptions(results, options)
  }

  async listAgents(options?: ListOptions): Promise<PaginatedResult<Agent>> {
    let filtered = [...this.agents]

    if (options?.capability) {
      filtered = filtered.filter((a) =>
        a.capabilities.some((c) => c.id === options.capability),
      )
    }
    if (options?.trustTier) {
      filtered = filtered.filter((a) => a.trustSignal.tier === options.trustTier)
    }

    const sorted = this.sortAgents(filtered, options?.sortBy ?? 'trust')
    const offset = options?.offset ?? 0
    const limit = options?.limit ?? 20
    const items = sorted.slice(offset, offset + limit)

    return {
      items,
      total: filtered.length,
      hasMore: offset + limit < filtered.length,
    }
  }

  async matchAgentCapabilities(
    required: string[],
    options?: MatchOptions,
  ): Promise<Agent[]> {
    const matchAll = options?.matchAll ?? true

    let results = this.agents.filter((agent) => {
      const agentCapIds = agent.capabilities.map((c) => c.id)
      if (matchAll) {
        return required.every((req) => agentCapIds.includes(req))
      }
      return required.some((req) => agentCapIds.includes(req))
    })

    if (options?.minTrustTier) {
      const minOrder = TRUST_TIER_ORDER[options.minTrustTier]
      results = results.filter(
        (a) => TRUST_TIER_ORDER[a.trustSignal.tier] >= minOrder,
      )
    }

    // Score by number of matching capabilities (desc), then trust (desc)
    results.sort((a, b) => {
      const aMatches = a.capabilities.filter((c) => required.includes(c.id)).length
      const bMatches = b.capabilities.filter((c) => required.includes(c.id)).length
      if (bMatches !== aMatches) return bMatches - aMatches
      return b.trustSignal.percentile - a.trustSignal.percentile
    })

    return options?.limit ? results.slice(0, options.limit) : results
  }

  async getAgentCard(id: string): Promise<AgentCard | null> {
    const agent = await this.findAgent(id)
    if (!agent) return null
    if (agent.agentCard) return agent.agentCard
    if (!agent.metadata.endpoint) return null

    return {
      id: agent.id,
      name: agent.metadata.name,
      description: agent.metadata.description,
      url: agent.metadata.endpoint,
      provider: agent.metadata.provider || { name: 'Unknown' },
      version: agent.metadata.version,
      capabilities: {
        streaming: false,
        pushNotifications: false,
        extendedAgentCard: true,
      },
      skills: agent.capabilities.map((cap) => ({
        id: cap.id,
        name: cap.name,
        description: cap.description,
        inputModes: ['text/plain'],
        outputModes: ['text/plain'],
      })),
      securitySchemes: {
        unauthenticated: {
          type: 'http',
          description: 'No additional authentication required for discovery endpoints',
        },
      },
      security: [{ unauthenticated: [] }],
      interfaces: [
        {
          protocol: 'http',
          url: agent.metadata.endpoint,
        },
      ],
      defaultInputModes: ['text/plain', 'application/json'],
      defaultOutputModes: ['text/plain', 'application/json'],
      extensions: [
        {
          uri: 'https://registry.intuition.systems/extensions/intuition',
          atomId: agent.id,
          vaultTermId: agent.vault.term_id,
          trustTier: agent.trustSignal.tier,
          registryUrl: 'https://registry.intuition.systems',
          chainId: 13579,
        },
      ],
    }
  }

  async getAgentTrust(id: string): Promise<TrustSignal | null> {
    const agent = await this.findAgent(id)
    return agent?.trustSignal ?? null
  }

  // --- Skill methods ---

  async findSkill(id: string): Promise<Skill | null> {
    return this.skills.find((s) => s.id === id) ?? null
  }

  async searchSkills(query: string, options?: SearchOptions): Promise<Skill[]> {
    const lowerQuery = query.toLowerCase().trim()
    if (!lowerQuery) return this.applySkillOptions(this.skills, options)

    let results = this.skills.filter((skill) => {
      const nameMatch = skill.metadata.name.toLowerCase().includes(lowerQuery)
      const descMatch = skill.metadata.description.toLowerCase().includes(lowerQuery)
      const capMatch = skill.capabilities.some((c) =>
        c.name.toLowerCase().includes(lowerQuery),
      )
      const platformMatch = skill.platform.name.toLowerCase().includes(lowerQuery)
      return nameMatch || descMatch || capMatch || platformMatch
    })

    return this.applySkillOptions(results, options)
  }

  async listSkills(options?: ListOptions): Promise<PaginatedResult<Skill>> {
    let filtered = [...this.skills]

    if (options?.capability) {
      filtered = filtered.filter((s) =>
        s.capabilities.some((c) => c.id === options.capability),
      )
    }
    if (options?.platformId) {
      filtered = filtered.filter((s) => s.platform.id === options.platformId)
    }
    if (options?.trustTier) {
      filtered = filtered.filter((s) => s.trustSignal.tier === options.trustTier)
    }

    const sorted = this.sortSkills(filtered, options?.sortBy ?? 'trust')
    const offset = options?.offset ?? 0
    const limit = options?.limit ?? 20
    const items = sorted.slice(offset, offset + limit)

    return {
      items,
      total: filtered.length,
      hasMore: offset + limit < filtered.length,
    }
  }

  async getSkillsByPlatform(platformId: string): Promise<Skill[]> {
    return this.skills.filter((s) => s.platform.id === platformId)
  }

  async getSkillsForAgent(agentId: string): Promise<Skill[]> {
    const agent = await this.findAgent(agentId)
    if (!agent) return []

    // Find uses triples from this agent
    const skillIds = agent.triples
      .filter((t) => t.predicate.label === 'uses')
      .map((t) => t.object.term_id)

    return this.skills.filter((s) => skillIds.includes(s.id))
  }

  async getSkillTrust(id: string): Promise<TrustSignal | null> {
    const skill = await this.findSkill(id)
    return skill?.trustSignal ?? null
  }

  // --- Metadata resolution ---

  async resolveCurrentMetadata(
    entityType: EntityType,
    entityId: string,
  ): Promise<AgentMetadata | SkillMetadata | null> {
    // In the mock repository, just return the metadata from the entity itself
    if (entityType === 'agent') {
      const agent = await this.findAgent(entityId)
      return agent?.metadata ?? null
    } else {
      const skill = await this.findSkill(entityId)
      return skill?.metadata ?? null
    }
  }

  // --- Shared metadata ---

  async listCapabilities(): Promise<Capability[]> {
    return this.capabilities
  }

  async listPredicates(): Promise<PredicateDefinition[]> {
    return this.predicates
  }

  async listPlatforms(): Promise<Platform[]> {
    return this.platforms
  }

  // --- Private helpers ---

  private applyAgentOptions(
    agents: Agent[],
    options?: SearchOptions,
  ): Agent[] {
    let filtered = [...agents]

    if (options?.capabilities?.length) {
      filtered = filtered.filter((a) =>
        options.capabilities!.some((capId) =>
          a.capabilities.some((c) => c.id === capId),
        ),
      )
    }
    if (options?.minTrustTier) {
      const minOrder = TRUST_TIER_ORDER[options.minTrustTier]
      filtered = filtered.filter(
        (a) => TRUST_TIER_ORDER[a.trustSignal.tier] >= minOrder,
      )
    }

    const sorted = this.sortAgents(filtered, options?.sortBy ?? 'trust')
    const offset = options?.offset ?? 0
    const limit = options?.limit ?? 20
    return sorted.slice(offset, offset + limit)
  }

  private applySkillOptions(
    skills: Skill[],
    options?: SearchOptions,
  ): Skill[] {
    let filtered = [...skills]

    if (options?.platformId) {
      filtered = filtered.filter((s) => s.platform.id === options.platformId)
    }
    if (options?.capabilities?.length) {
      filtered = filtered.filter((s) =>
        options.capabilities!.some((capId) =>
          s.capabilities.some((c) => c.id === capId),
        ),
      )
    }

    const sorted = this.sortSkills(filtered, options?.sortBy ?? 'trust')
    const offset = options?.offset ?? 0
    const limit = options?.limit ?? 20
    return sorted.slice(offset, offset + limit)
  }

  private sortAgents(agents: Agent[], sortBy: SortField): Agent[] {
    const sorted = [...agents]
    switch (sortBy) {
      case 'trust':
        return sorted.sort((a, b) => b.trustSignal.percentile - a.trustSignal.percentile)
      case 'name':
        return sorted.sort((a, b) => a.metadata.name.localeCompare(b.metadata.name))
      case 'recent':
        return sorted.sort((a, b) =>
          (b.metadata.createdAt ?? '').localeCompare(a.metadata.createdAt ?? ''),
        )
      case 'stakers':
        return sorted.sort((a, b) => b.trustSignal.stakerCount - a.trustSignal.stakerCount)
      case 'safety':
        return sorted.sort((a, b) => b.trustSignal.percentile - a.trustSignal.percentile)
      default:
        return sorted
    }
  }

  private sortSkills(skills: Skill[], sortBy: SortField): Skill[] {
    const sorted = [...skills]
    switch (sortBy) {
      case 'trust':
        return sorted.sort((a, b) => b.trustSignal.percentile - a.trustSignal.percentile)
      case 'name':
        return sorted.sort((a, b) => a.metadata.name.localeCompare(b.metadata.name))
      case 'recent':
        return sorted.sort((a, b) =>
          (b.metadata.createdAt ?? '').localeCompare(a.metadata.createdAt ?? ''),
        )
      case 'stakers':
        return sorted.sort((a, b) => b.trustSignal.stakerCount - a.trustSignal.stakerCount)
      case 'safety':
        return sorted.sort((a, b) => b.safetySignal.safetyRatio - a.safetySignal.safetyRatio)
      default:
        return sorted
    }
  }
}
