import { describe, it, expect } from 'vitest'
import { AgentMetadataSchema } from '~/lib/schemas/agent-metadata'

/**
 * Tests for AgentRegistrationForm validation logic.
 *
 * Since @testing-library/react is not installed, we test the Zod schema
 * validation that the form uses for inline validation. This covers the
 * critical business logic without requiring DOM rendering.
 */
describe('AgentRegistrationForm validation', () => {
  describe('required fields', () => {
    it('should reject empty name', () => {
      const result = AgentMetadataSchema.safeParse({
        '@type': 'Agent',
        name: '',
        description: 'A test agent',
        version: '1.0.0',
      })
      expect(result.success).toBe(false)
    })

    it('should reject empty description', () => {
      const result = AgentMetadataSchema.safeParse({
        '@type': 'Agent',
        name: 'TestAgent',
        description: '',
        version: '1.0.0',
      })
      expect(result.success).toBe(false)
    })

    it('should reject empty version', () => {
      const result = AgentMetadataSchema.safeParse({
        '@type': 'Agent',
        name: 'TestAgent',
        description: 'A test agent',
        version: '',
      })
      expect(result.success).toBe(false)
    })

    it('should reject missing @type', () => {
      const result = AgentMetadataSchema.safeParse({
        name: 'TestAgent',
        description: 'A test agent',
        version: '1.0.0',
      })
      expect(result.success).toBe(false)
    })

    it('should reject wrong @type', () => {
      const result = AgentMetadataSchema.safeParse({
        '@type': 'Skill',
        name: 'TestAgent',
        description: 'A test agent',
        version: '1.0.0',
      })
      expect(result.success).toBe(false)
    })
  })

  describe('field constraints', () => {
    it('should reject name longer than 100 chars', () => {
      const result = AgentMetadataSchema.safeParse({
        '@type': 'Agent',
        name: 'A'.repeat(101),
        description: 'A test agent',
        version: '1.0.0',
      })
      expect(result.success).toBe(false)
    })

    it('should reject description longer than 500 chars', () => {
      const result = AgentMetadataSchema.safeParse({
        '@type': 'Agent',
        name: 'TestAgent',
        description: 'A'.repeat(501),
        version: '1.0.0',
      })
      expect(result.success).toBe(false)
    })

    it('should reject invalid semver version', () => {
      const result = AgentMetadataSchema.safeParse({
        '@type': 'Agent',
        name: 'TestAgent',
        description: 'A test agent',
        version: 'not-semver',
      })
      expect(result.success).toBe(false)
    })

    it('should accept valid semver version', () => {
      const result = AgentMetadataSchema.safeParse({
        '@type': 'Agent',
        name: 'TestAgent',
        description: 'A test agent',
        version: '2.1.3',
      })
      expect(result.success).toBe(true)
    })

    it('should reject capabilities exceeding max count', () => {
      const result = AgentMetadataSchema.safeParse({
        '@type': 'Agent',
        name: 'TestAgent',
        description: 'A test agent',
        version: '1.0.0',
        capabilities: Array.from({ length: 11 }, (_, i) => `capability-${i}`),
      })
      expect(result.success).toBe(false)
    })
  })

  describe('optional fields', () => {
    it('should accept valid metadata with all optional fields', () => {
      const result = AgentMetadataSchema.safeParse({
        '@type': 'Agent',
        name: 'TestAgent',
        description: 'A test agent for code review',
        version: '1.0.0',
        image: 'https://example.com/icon.png',
        model: 'claude-opus-4-6',
        endpoint: 'https://api.example.com/agent',
        provider: { name: 'Anthropic', url: 'https://anthropic.com' },
        tags: ['code-review', 'testing'],
        defaultInputModes: ['text/plain', 'application/json'],
        defaultOutputModes: ['text/markdown'],
      })
      expect(result.success).toBe(true)
    })

    it('should accept minimal valid metadata (required only)', () => {
      const result = AgentMetadataSchema.safeParse({
        '@type': 'Agent',
        name: 'TestAgent',
        description: 'A test agent',
        version: '1.0.0',
      })
      expect(result.success).toBe(true)
    })

    it('should accept provider with name only', () => {
      const result = AgentMetadataSchema.safeParse({
        '@type': 'Agent',
        name: 'TestAgent',
        description: 'A test agent',
        version: '1.0.0',
        provider: { name: 'Anthropic' },
      })
      expect(result.success).toBe(true)
    })

    it('should reject invalid image URL', () => {
      const result = AgentMetadataSchema.safeParse({
        '@type': 'Agent',
        name: 'TestAgent',
        description: 'A test agent',
        version: '1.0.0',
        image: 'not-a-url',
      })
      expect(result.success).toBe(false)
    })

    it('should reject invalid endpoint URL', () => {
      const result = AgentMetadataSchema.safeParse({
        '@type': 'Agent',
        name: 'TestAgent',
        description: 'A test agent',
        version: '1.0.0',
        endpoint: 'not-a-url',
      })
      expect(result.success).toBe(false)
    })
  })

  describe('metadata building (tag parsing)', () => {
    it('should split comma-separated tags', () => {
      const rawTags = 'code-review, static-analysis, testing'
      const parsed = rawTags
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean)
      expect(parsed).toEqual(['code-review', 'static-analysis', 'testing'])
    })

    it('should handle empty tags string', () => {
      const rawTags = ''
      const parsed = rawTags
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean)
      expect(parsed).toEqual([])
    })

    it('should handle whitespace-only tags', () => {
      const rawTags = '  ,  , '
      const parsed = rawTags
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean)
      expect(parsed).toEqual([])
    })

    it('should trim individual tags', () => {
      const rawTags = '  code-review ,  testing  '
      const parsed = rawTags
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean)
      expect(parsed).toEqual(['code-review', 'testing'])
    })
  })

  describe('error extraction', () => {
    it('should provide field-level errors for nested provider', () => {
      const result = AgentMetadataSchema.safeParse({
        '@type': 'Agent',
        name: 'TestAgent',
        description: 'A test agent',
        version: '1.0.0',
        provider: { name: '', url: 'not-a-url' },
      })

      if (!result.success) {
        const paths = result.error.issues.map((i) => i.path.join('.'))
        // Should have error on provider.url for invalid URL
        expect(paths.some((p) => p.includes('provider'))).toBe(true)
      }
    })

    it('should provide descriptive messages for required fields', () => {
      const result = AgentMetadataSchema.safeParse({
        '@type': 'Agent',
        name: '',
        description: '',
        version: '',
      })

      expect(result.success).toBe(false)
      if (!result.success) {
        expect(result.error.issues.length).toBeGreaterThan(0)
        // Each issue should have a human-readable message
        for (const issue of result.error.issues) {
          expect(issue.message).toBeTruthy()
          expect(typeof issue.message).toBe('string')
        }
      }
    })
  })
})
