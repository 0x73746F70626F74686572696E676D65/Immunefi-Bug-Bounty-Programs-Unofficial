import type { Capability } from './capability'
import type { TrustSignal, Vault } from './vault'
import type { Triple } from './triple'
import type { SecurityProfile } from './security'
import type { ReputationProfile } from './reputation'

/**
 * Agent — a first-class AI agent entity
 *
 * Agents are represented as Atoms on-chain. Each agent has:
 * - An identity (metadata)
 * - Capabilities (what it can do)
 * - A vault (economic trust signal)
 * - Relationships (triples)
 */
export interface Agent {
  /** Unique term_id (hex string, serves as atom ID) */
  id: string
  /** Rich metadata */
  metadata: AgentMetadata
  /** Capabilities (via has-capability triples) */
  capabilities: Capability[]
  /** Vault for economic signaling */
  vault: Vault
  /** Derived trust signal */
  trustSignal: TrustSignal
  /** Relationships where this agent is subject */
  triples: Triple[]
  /** A2A Agent Card data */
  agentCard?: AgentCard
  /** ERC-8004 identity reference */
  erc8004?: ERC8004
  /** Security profile from attestations */
  securityProfile?: SecurityProfile
  /** Reputation profile from task feedback */
  reputationProfile?: ReputationProfile
}

/**
 * AgentMetadata — descriptive information about an agent
 */
export interface AgentMetadata {
  /** Agent display name */
  name: string
  /** Short description (1-2 sentences) */
  description: string
  /** Long description / README */
  longDescription?: string
  /** Avatar/logo URL */
  image?: string
  /** Agent version string (semver) */
  version: string
  /** LLM model used (e.g. "claude-opus-4-6", "gpt-4o") */
  model?: string
  /** Agent endpoint URL */
  endpoint?: string
  /** Optional IPFS URI for canonical metadata payload */
  metadataUri?: string
  /** Provider/creator information */
  provider?: AgentProvider
  /** Tags for discovery */
  tags?: string[]
  /** ISO timestamp - when registered */
  createdAt: string
  /** ISO timestamp - last activity */
  lastActiveAt?: string
}

/**
 * AgentProvider — creator/operator information
 */
export interface AgentProvider {
  /** Provider name */
  name: string
  /** Provider URL */
  url?: string
}

/**
 * A2A v0.3 Security Scheme
 */
export interface A2ASecurityScheme {
  type: 'apiKey' | 'http' | 'oauth2' | 'openIdConnect' | 'mutualTLS'
  description?: string
  // Additional fields depend on type
}

/**
 * A2A v0.3 Agent Interface
 */
export interface A2AAgentInterface {
  protocol: 'http' | 'grpc'
  url: string
}

/**
 * A2A v0.3 Agent Extension
 */
export interface A2AAgentExtension {
  uri: string
  [key: string]: unknown
}

/**
 * A2A v0.3 Agent Card Skill
 */
export interface A2AAgentSkill {
  id: string
  name: string
  description: string
  inputModes?: string[]
  outputModes?: string[]
}

/**
 * Intuition extension for A2A Agent Cards
 */
export interface IntuitionExtension {
  atomId: string
  vaultTermId: string
  trustTier: string
  registryUrl: string
  chainId: number
}

/**
 * AgentCard — A2A v0.3 compliant machine-readable discovery document
 *
 * Based on the A2A (Agent-to-Agent) specification v0.3.
 * This enables agents to discover and interact with each other.
 */
export interface AgentCard {
  /** Unique agent identifier (maps to atom term_id) */
  id: string
  /** Agent name */
  name: string
  /** Agent description */
  description: string
  /** Agent endpoint URL */
  url: string
  /** Provider information */
  provider: AgentProvider
  /** Protocol version (e.g., "0.3") */
  version: string
  /** Protocol-level capabilities (streaming, push notifications) */
  capabilities?: {
    streaming?: boolean
    pushNotifications?: boolean
    extendedAgentCard?: boolean
  }
  /** Discrete skills this agent offers */
  skills: A2AAgentSkill[]
  /** Security scheme definitions */
  securitySchemes?: Record<string, A2ASecurityScheme>
  /** Security requirements (which schemes apply) */
  security?: Record<string, string[]>[]
  /** Protocol bindings (HTTP, gRPC) */
  interfaces?: A2AAgentInterface[]
  /** Custom extensions (including Intuition) */
  extensions?: A2AAgentExtension[]
  /** JWS signature for card authenticity */
  signature?: string
  /** Supported input MIME types */
  defaultInputModes: string[]
  /** Supported output MIME types */
  defaultOutputModes: string[]
}

/**
 * ERC8004 — on-chain identity reference
 *
 * ERC-8004 is an emerging standard for agent identity on-chain.
 * This enables interoperability with existing standards.
 */
export interface ERC8004 {
  /** On-chain agent NFT ID (uint256 string) */
  agentId?: string
  /** Registry contract address */
  registryAddress?: string
  /** Chain ID */
  chainId?: number
  /** Agent URI (IPFS hash pointing to registration file) */
  agentURI: string
  /** Registration file URL */
  registrationFile: string
  /** Bound wallet address */
  agentWallet?: string
  /** Arbitrary on-chain metadata */
  metadata?: Record<string, string>
  /** Service endpoint bindings */
  services?: { name: string; endpoint: string; version?: string }[]
  /** Whether agent is active */
  active?: boolean
  /** Cross-chain registration references */
  registrations?: { agentId: string; agentRegistry: string }[]
  /** Trust models used */
  trustModels: string[]
  /** Registry-specific onboarding extension (INT-13) */
  onboarding?: ERC8004OnboardingExtension
}

/**
 * ERC-8004 onboarding metadata extension (INT-13).
 *
 * Extends the baseline ERC-8004 schema with registry-specific
 * onboarding pointers without breaking schema compatibility.
 */
export interface ERC8004OnboardingExtension {
  /** Wallet strategy used for this agent (EOA, delegated, multisig) */
  walletStrategy: 'eoa' | 'delegated-signer' | 'multisig' | 'unknown'
  /** Funding profile summary */
  fundingProfile: {
    /** Minimum wei required for first-run activity */
    minimumWei: string
    /** Recommended wei for comfortable operation */
    recommendedWei: string
    /** Expected transaction count for full registration */
    expectedTransactions: number
  }
  /** Trust model IDs this agent supports or has been evaluated against */
  supportedTrustModelIds: string[]
  /** Readiness endpoint for machine-actionable onboarding state */
  readinessEndpoint: string
}
