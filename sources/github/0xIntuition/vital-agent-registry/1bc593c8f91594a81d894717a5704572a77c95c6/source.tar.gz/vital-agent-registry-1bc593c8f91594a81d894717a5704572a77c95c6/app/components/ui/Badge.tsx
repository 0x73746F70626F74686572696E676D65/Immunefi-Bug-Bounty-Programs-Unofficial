import { useState } from 'react'
import type { ReactNode } from 'react'
import { cn } from '~/lib/utils'

type BadgeVariant = 'default' | 'outline' | 'secondary'

interface BadgeProps {
  label?: string
  children?: ReactNode
  color?: string
  variant?: BadgeVariant
  className?: string
  interactive?: boolean
}

export function Badge({
  label,
  children,
  color,
  variant = 'default',
  className,
  interactive,
}: BadgeProps) {
  const [hovered, setHovered] = useState(false)
  const content = children ?? label

  if (variant === 'outline') {
    return (
      <span
        className={cn(
          'inline-flex items-center rounded-[var(--radius-badge)] border px-2 py-0.5 text-[10px] font-medium',
          interactive && 'cursor-pointer transition-all duration-150',
          className,
        )}
      >
        {content}
        {interactive && <span className="ml-1 opacity-50">↕</span>}
      </span>
    )
  }

  if (variant === 'secondary') {
    return (
      <span
        className={cn(
          'inline-flex items-center rounded-[var(--radius-badge)] bg-muted px-2 py-0.5 text-[10px] font-medium text-muted-foreground',
          interactive && 'cursor-pointer transition-all duration-150',
          className,
        )}
      >
        {content}
        {interactive && <span className="ml-1 opacity-50">↕</span>}
      </span>
    )
  }

  const defaultColor = 'hsl(0 0% 60%)'
  const badgeColor = color || defaultColor

  return (
    <span
      className={cn(
        'inline-flex items-center rounded-[var(--radius-badge)] px-2 py-0.5 text-[10px] font-medium',
        interactive && 'cursor-pointer transition-all duration-150',
        className,
      )}
      style={{
        backgroundColor: `color-mix(in srgb, ${badgeColor} ${hovered ? '25%' : '15%'}, transparent)`,
        color: badgeColor,
        boxShadow:
          interactive && hovered
            ? `0 0 8px color-mix(in srgb, ${badgeColor} 20%, transparent)`
            : undefined,
      }}
      onMouseEnter={interactive ? () => setHovered(true) : undefined}
      onMouseLeave={interactive ? () => setHovered(false) : undefined}
    >
      {content}
      {interactive && <span className="ml-1 opacity-50">↕</span>}
    </span>
  )
}
