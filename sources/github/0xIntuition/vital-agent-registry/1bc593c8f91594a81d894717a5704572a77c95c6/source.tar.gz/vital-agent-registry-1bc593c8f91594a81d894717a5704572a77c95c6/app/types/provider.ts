export interface Provider {
  id: string
  name: string
  url?: string
  description?: string
}
