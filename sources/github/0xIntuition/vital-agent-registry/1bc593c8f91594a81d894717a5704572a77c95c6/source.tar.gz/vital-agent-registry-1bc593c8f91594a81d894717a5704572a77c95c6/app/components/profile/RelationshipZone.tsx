import { useState } from 'react'
import { Link } from 'react-router'
import * as Collapsible from '@radix-ui/react-collapsible'
import { ChevronDown } from 'lucide-react'
import type { Agent } from '~/types'
import { cn } from '~/lib/utils'

interface RelationshipZoneProps {
  agent: Agent
  className?: string
}

interface RelatedAgent {
  id: string
  name: string
  image?: string
  tier: string
}

export function RelationshipZone({ agent, className }: RelationshipZoneProps) {
  const [isOpen, setIsOpen] = useState(true)
  const { triples } = agent

  // Extract related agents by relationship type
  const getRelatedAgents = (predicateLabel: string): RelatedAgent[] => {
    return triples
      .filter(
        t =>
          t.predicate.label === predicateLabel &&
          t.object.type === 'Agent',
      )
      .map(t => ({
        id: t.object.term_id,
        name: t.object.label,
        image: t.object.image,
        tier: 'unknown', // We don't have tier info in the triple reference
      }))
  }

  const delegatesTo = getRelatedAgents('delegates-to')
  const dependsOn = getRelatedAgents('depends-on')
  const compatibleWith = getRelatedAgents('compatible-with')

  const hasRelationships =
    delegatesTo.length > 0 || dependsOn.length > 0 || compatibleWith.length > 0

  if (!hasRelationships) {
    return (
      <div
        className={cn(
          'rounded-[var(--radius-card)] border border-border bg-card p-4 shadow-[var(--shadow-card)]',
          className,
        )}
      >
        <h2 className="font-mono text-xs tracking-widest uppercase text-ink-dull mb-2">Relationships</h2>
        <p className="text-sm text-muted-foreground">
          No agent relationships registered.
        </p>
      </div>
    )
  }

  return (
    <Collapsible.Root
      open={isOpen}
      onOpenChange={setIsOpen}
      className={cn(
        'rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)]',
        className,
      )}
    >
      <Collapsible.Trigger className="flex w-full items-center justify-between p-4 hover:bg-muted/50 transition-colors">
        <h2 className="font-mono text-xs tracking-widest uppercase text-ink-dull">Relationships</h2>
        <ChevronDown
          className={cn(
            'h-5 w-5 text-muted-foreground transition-transform',
            isOpen && 'rotate-180',
          )}
        />
      </Collapsible.Trigger>

      <Collapsible.Content className="px-4 pb-4 space-y-4">
        {/* Delegates To */}
        {delegatesTo.length > 0 && (
          <div>
            <h3 className="font-mono text-[10px] tracking-widest uppercase text-ink-faint mb-2">
              Delegates To ({delegatesTo.length})
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {delegatesTo.map(relatedAgent => (
                <RelatedAgentCard key={relatedAgent.id} agent={relatedAgent} />
              ))}
            </div>
          </div>
        )}

        {/* Depends On */}
        {dependsOn.length > 0 && (
          <div>
            <h3 className="font-mono text-[10px] tracking-widest uppercase text-ink-faint mb-2">
              Depends On ({dependsOn.length})
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {dependsOn.map(relatedAgent => (
                <RelatedAgentCard key={relatedAgent.id} agent={relatedAgent} />
              ))}
            </div>
          </div>
        )}

        {/* Compatible With */}
        {compatibleWith.length > 0 && (
          <div>
            <h3 className="font-mono text-[10px] tracking-widest uppercase text-ink-faint mb-2">
              Compatible With ({compatibleWith.length})
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {compatibleWith.map(relatedAgent => (
                <RelatedAgentCard key={relatedAgent.id} agent={relatedAgent} />
              ))}
            </div>
          </div>
        )}
      </Collapsible.Content>
    </Collapsible.Root>
  )
}

function RelatedAgentCard({ agent }: { agent: RelatedAgent }) {
  const avatarFallback = agent.name.charAt(0).toUpperCase()

  return (
    <Link
      to={`/agents/${agent.id}`}
      className="flex items-center gap-3 p-2 rounded border border-border bg-card hover:bg-muted/50 transition-colors"
    >
      <div className="flex-shrink-0">
        {agent.image ? (
          <img
            src={agent.image}
            alt={agent.name}
            className="w-10 h-10 rounded-full object-cover"
          />
        ) : (
          <div className="w-10 h-10 rounded-full bg-brand/20 flex items-center justify-center text-brand font-bold text-sm">
            {avatarFallback}
          </div>
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div className="font-mono font-medium text-card-foreground truncate text-xs">
          {agent.name}
        </div>
        {/* Note: Trust tier not available in triple reference, could be fetched later */}
      </div>
    </Link>
  )
}
