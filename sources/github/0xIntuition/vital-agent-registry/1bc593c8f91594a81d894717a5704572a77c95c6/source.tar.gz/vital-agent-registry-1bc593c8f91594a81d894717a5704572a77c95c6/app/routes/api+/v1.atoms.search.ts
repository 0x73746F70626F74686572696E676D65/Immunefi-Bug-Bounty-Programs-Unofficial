import type { LoaderFunctionArgs } from 'react-router'
import { handleOptions, parseQueryParams, jsonResponse } from '~/lib/api/types'
import { searchAtomsSchema } from '~/lib/api/validation'
import { serverGraphqlRequest } from '~/lib/graphql/client'
import { SEARCH_ATOMS } from '~/lib/graphql/queries'

const DEFAULT_LOCAL_GRAPHQL_URL = 'http://localhost:8080/v1/graphql'

/**
 * GET /api/v1/atoms/search?q=...&type=...&limit=...&offset=...
 *
 * Search atoms by label/data text. Results sorted by total market cap
 * (most-staked first). Agents use this to find existing capability atoms
 * before creating duplicates.
 */
export async function loader({ request }: LoaderFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const parsed = parseQueryParams(request, searchAtomsSchema)
  if ('error' in parsed) return parsed.error

  const { q, type, limit, offset } = parsed.data
  const apiUrl = process.env.GRAPHQL_API_URL_PRIVATE ?? DEFAULT_LOCAL_GRAPHQL_URL

  // Build where clause with optional type filter
  const searchTerm = `%${q}%`

  const query = type ? SEARCH_ATOMS_WITH_TYPE : SEARCH_ATOMS
  const variables = type
    ? { searchTerm, type, limit, offset }
    : { searchTerm, limit, offset }

  try {
    const response = await serverGraphqlRequest<{ atoms: Record<string, unknown>[] }>(
      apiUrl,
      query,
      variables,
    )

    return jsonResponse(response.atoms ?? [], {
      total: response.atoms?.length ?? 0,
      limit,
      offset,
    })
  } catch {
    // GraphQL unavailable — return empty results
    return jsonResponse([], { total: 0, limit, offset })
  }
}

/**
 * Extended search query that filters by atom type.
 */
const SEARCH_ATOMS_WITH_TYPE = `
  query SearchAtomsWithType($searchTerm: String!, $type: String!, $limit: Int, $offset: Int) {
    atoms(
      where: {
        _and: [
          { type: { _eq: $type } }
          { _or: [
            { label: { _ilike: $searchTerm } }
            { data: { _ilike: $searchTerm } }
          ]}
        ]
      }
      limit: $limit
      offset: $offset
      order_by: [{ term: { vaults_aggregate: { sum: { total_assets: desc } } } }]
    ) {
      term_id
      label
      image
      cached_image { url safe }
      type
      data
      creator { id label image }
      term {
        vaults(order_by: { curve_id: asc }) {
          total_assets
          position_count
          market_cap
        }
      }
    }
  }
`
