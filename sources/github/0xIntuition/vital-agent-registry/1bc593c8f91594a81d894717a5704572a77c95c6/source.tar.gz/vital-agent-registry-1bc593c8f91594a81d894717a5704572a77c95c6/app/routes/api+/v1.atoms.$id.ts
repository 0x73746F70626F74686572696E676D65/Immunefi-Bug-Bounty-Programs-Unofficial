import type { LoaderFunctionArgs } from 'react-router'
import { handleOptions, jsonResponse, errorResponse } from '~/lib/api/types'
import { serverGraphqlRequest } from '~/lib/graphql/client'
import { GET_ATOM_DETAIL } from '~/lib/graphql/queries'

const TERM_ID_PATTERN = /^0x[0-9a-fA-F]{64}$/
const DEFAULT_LOCAL_GRAPHQL_URL = 'http://localhost:8080/v1/graphql'

/**
 * GET /api/v1/atoms/:id
 *
 * Look up any atom by term ID. Returns atom data, metadata, and
 * triples where this atom appears as subject (outgoing relationships).
 */
export async function loader({ params, request }: LoaderFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const id = params.id!
  if (!TERM_ID_PATTERN.test(id)) {
    return errorResponse('Invalid term ID format (expected bytes32 hex)', 'INVALID_ID', 400)
  }

  const apiUrl = process.env.GRAPHQL_API_URL_PRIVATE ?? DEFAULT_LOCAL_GRAPHQL_URL

  try {
    const response = await serverGraphqlRequest<{ atom: Record<string, unknown> | null }>(
      apiUrl,
      GET_ATOM_DETAIL,
      { termId: id },
    )

    if (!response.atom) {
      return errorResponse('Atom not found', 'NOT_FOUND', 404)
    }

    return jsonResponse(response.atom)
  } catch {
    return errorResponse('Atom not found (GraphQL unavailable)', 'NOT_FOUND', 404)
  }
}
