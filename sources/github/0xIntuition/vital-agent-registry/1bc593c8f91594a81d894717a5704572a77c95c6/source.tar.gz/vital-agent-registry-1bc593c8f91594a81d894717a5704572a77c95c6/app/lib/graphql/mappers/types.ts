/**
 * GraphQL response types for mappers.
 * These match the Hasura schema structure.
 */

export interface GraphQLAtom {
  term_id: string
  label: string
  image?: string | null
  cached_image?: {
    url?: string | null
    safe?: boolean | null
  } | null
  type?: string | null
  data?: string | null
  created_at?: string
  updated_at?: string | null
  creator?: {
    id?: string
    label?: string | null
    image?: string | null
  } | null
  value?: {
    thing?: {
      name?: string | null
      description?: string | null
      image?: string | null
      url?: string | null
    } | null
    person?: {
      name?: string | null
      image?: string | null
      url?: string | null
    } | null
    organization?: {
      name?: string | null
      image?: string | null
      url?: string | null
    } | null
    account?: {
      id?: string
      label?: string | null
      image?: string | null
    } | null
    json_object?: {
      name?: string | null
      description?: string | null
    } | null
  } | null
  term?: {
    total_market_cap?: string | null
    positions_aggregate?: {
      aggregate?: {
        count?: number | null
      } | null
    } | null
    vaults?: GraphQLVault[]
  } | null
  as_subject_triples?: GraphQLTriple[]
}

export interface GraphQLVault {
  term_id: string
  curve_id: string
  current_share_price: string
  total_shares: string
  total_assets: string
  position_count: number
  market_cap: string
}

export interface GraphQLTriple {
  term_id: string
  counter_term_id?: string | null
  predicate: {
    term_id: string
    label: string
  }
  object: {
    term_id: string
    label: string
    image?: string | null
    cached_image?: {
      url?: string | null
      safe?: boolean | null
    } | null
    type?: string | null
    data?: string | null
    value?: {
      thing?: {
        name?: string | null
        description?: string | null
        image?: string | null
        url?: string | null
      } | null
      json_object?: {
        name?: string | null
        description?: string | null
      } | null
    } | null
  }
  term?: {
    vaults?: GraphQLVault[]
  } | null
}

export interface GraphQLAgentsResponse {
  total: {
    aggregate: {
      count: number
    }
  }
  atoms: GraphQLAtom[]
}

export interface GraphQLSkillsResponse {
  total: {
    aggregate: {
      count: number
    }
  }
  atoms: GraphQLAtom[]
}

export interface GraphQLSearchResponse {
  atoms: GraphQLAtom[]
}

export interface GraphQLSkillsForAgentResponse {
  triples: Array<{
    object: GraphQLAtom
  }>
}
