export interface PollerOptions {
  maxRetries?: number
  initialDelayMs?: number
  maxDelayMs?: number
  factor?: number
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(resolve, ms)
  })
}

export async function pollWithBackoff<T>(
  fn: () => Promise<T | null>,
  options: PollerOptions = {},
): Promise<T | null> {
  const maxRetries = options.maxRetries ?? 6
  const initialDelayMs = options.initialDelayMs ?? 250
  const maxDelayMs = options.maxDelayMs ?? 5_000
  const factor = options.factor ?? 2

  let delayMs = initialDelayMs
  for (let attempt = 0; attempt <= maxRetries; attempt += 1) {
    const value = await fn()
    if (value !== null) return value
    if (attempt === maxRetries) break
    await delay(delayMs)
    delayMs = Math.min(maxDelayMs, Math.floor(delayMs * factor))
  }
  return null
}

export async function pollIndexerForTermId(
  graphqlUrl: string,
  termId: string,
  options: PollerOptions = {},
): Promise<boolean> {
  const query = `
    query PollTerm($termId: String!) {
      atom(term_id: $termId) {
        term_id
      }
    }
  `

  const result = await pollWithBackoff(async () => {
    const response = await fetch(graphqlUrl, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        query,
        variables: { termId },
      }),
    })
    if (!response.ok) return null
    const json = await response.json()
    return json?.data?.atom?.term_id ? true : null
  }, options)

  return result === true
}

export async function pollIndexerLagBlocks(
  graphqlUrl: string,
  options: PollerOptions = {},
): Promise<number | null> {
  const query = `
    query PollIndexerLag {
      indexer_status {
        lag_blocks
      }
    }
  `

  return pollWithBackoff(async () => {
    const response = await fetch(graphqlUrl, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ query }),
    })
    if (!response.ok) return null
    const json = await response.json()
    const lag = json?.data?.indexer_status?.lag_blocks
    return typeof lag === 'number' ? lag : null
  }, options)
}
