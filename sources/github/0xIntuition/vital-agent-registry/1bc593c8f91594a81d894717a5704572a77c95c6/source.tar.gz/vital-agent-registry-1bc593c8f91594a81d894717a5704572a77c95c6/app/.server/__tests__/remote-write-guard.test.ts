import { describe, it, expect } from 'vitest'
import {
  assertRemoteWriteAllowed,
  getWriteProfile,
  isRemoteWriteOverrideEnabled,
  RemoteWriteGuardError,
} from '../remote-write-guard'

describe('remote-write-guard', () => {
  it('defaults to local write profile', () => {
    expect(getWriteProfile({})).toBe('local')
  })

  it('detects override flag', () => {
    expect(isRemoteWriteOverrideEnabled({ ALLOW_REMOTE_WRITES: '1' })).toBe(true)
    expect(isRemoteWriteOverrideEnabled({ ALLOW_REMOTE_WRITES: 'true' })).toBe(true)
    expect(isRemoteWriteOverrideEnabled({ ALLOW_REMOTE_WRITES: '0' })).toBe(false)
  })

  it('blocks remote writes by default', () => {
    expect(() =>
      assertRemoteWriteAllowed({
        action: 'prepare registration',
        target: 'ipfs + chain',
        env: {},
      })
    ).toThrow(RemoteWriteGuardError)
  })

  it('allows remote writes when explicit override is enabled', () => {
    expect(() =>
      assertRemoteWriteAllowed({
        action: 'prepare registration',
        target: 'ipfs + chain',
        env: {
          ALLOW_REMOTE_WRITES: '1',
          REGISTRY_WRITE_PROFILE: 'shared',
        },
      })
    ).not.toThrow()
  })
})

