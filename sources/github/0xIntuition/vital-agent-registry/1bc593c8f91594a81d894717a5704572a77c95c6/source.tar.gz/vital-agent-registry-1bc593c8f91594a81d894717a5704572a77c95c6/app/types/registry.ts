/**
 * registry.ts - Backward compatibility barrel
 *
 * All types now live in dedicated files. Import from '~/types' instead.
 * This file preserves backward compatibility for any existing `import from '~/types/registry'` patterns.
 */

export type {
  Agent,
  AgentMetadata,
  AgentProvider,
  AgentCard,
  ERC8004,
} from './agent'

export type {
  Skill,
  SkillMetadata,
  SafetyStatus,
  SafetySignal,
} from './skill'

export type { Capability, CapabilityCategory } from './capability'

export type { PredicateDefinition } from './predicate'

export type { Platform, PlatformId } from './platform'

export type { Vault, Position, TrustSignal, TrustTier } from './vault'

export type { Triple, TripleAtomRef, AtomType, Predicate } from './triple'

export type {
  RegistryRepository,
  SearchOptions,
  ListOptions,
  MatchOptions,
  PaginatedResult,
  SortField,
} from './repository'
