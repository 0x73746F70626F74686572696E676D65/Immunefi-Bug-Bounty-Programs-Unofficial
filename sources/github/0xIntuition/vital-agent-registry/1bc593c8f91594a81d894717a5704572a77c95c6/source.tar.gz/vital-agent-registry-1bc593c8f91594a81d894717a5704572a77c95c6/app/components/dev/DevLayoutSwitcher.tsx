import { useEffect } from 'react'
import { Rows3, GalleryHorizontal, LayoutGrid, type LucideIcon } from 'lucide-react'
import { useFeedLayout, type FeedLayout } from '~/lib/hooks/useFeedLayout'

const LAYOUT_CONFIG: Record<FeedLayout, { icon: LucideIcon; label: string }> = {
  list: { icon: Rows3, label: 'List' },
  carousel: { icon: GalleryHorizontal, label: 'Carousel' },
  grid: { icon: LayoutGrid, label: 'Grid' },
}

export function DevLayoutSwitcher() {
  const { layout, setLayout, cycleLayout } = useFeedLayout()

  useEffect(() => {
    function handleKeydown(e: KeyboardEvent) {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return
      if (e.key === '1') setLayout('list')
      else if (e.key === '2') setLayout('carousel')
      else if (e.key === '3') setLayout('grid')
    }

    window.addEventListener('keydown', handleKeydown)
    return () => window.removeEventListener('keydown', handleKeydown)
  }, [setLayout])

  if (!import.meta.env.DEV) return null

  const { icon: Icon, label } = LAYOUT_CONFIG[layout]

  return (
    <button
      type="button"
      onClick={cycleLayout}
      className="fixed bottom-20 right-4 z-50 flex items-center gap-2 rounded-full bg-white/10 px-3 py-2 text-xs font-medium text-white/80 backdrop-blur-md shadow-lg transition-colors hover:bg-white/20"
      title={`${label} layout (1/2/3 to switch)`}
    >
      <Icon className="h-4 w-4" />
      <span>{label}</span>
    </button>
  )
}
