# Repository Performance Guardrails

## Scope
This guardrail suite tracks critical `RegistryRepository` paths used by agent workflows:
- list: `listAgents(limit=100)`
- search: `searchAgents("agent")`
- trust scoring: `computeTrustSignal` over 500 vault snapshots
- evidence retrieval: `getSkillsForAgent(agentId)`

## Fixture Profile
- Repository implementation: `MockRegistryRepository`
- Dataset seed:
  - `MOCK_AGENTS`
  - `MOCK_SKILLS`
  - `CAPABILITIES`
  - `PREDICATES`
  - `PLATFORMS`
- Trust scoring vault set: 500 deterministic synthetic vaults

## Method
- 7 iterations per path
- P95 computed from sorted per-iteration elapsed milliseconds
- Test fails when `p95 >= target`
- Failure output includes label, P95, target, and raw samples for diagnosis

## Current Targets
- `listAgents(limit=100)`: `< 250ms`
- `searchAgents("agent")`: `< 200ms`
- Trust scoring (500 vaults): `< 150ms`
- `getSkillsForAgent(agentId)`: `< 150ms`

## Assumptions
- Local test execution on a development workstation
- No external network calls in this suite
- Guardrails are regression detectors, not production SLA guarantees
