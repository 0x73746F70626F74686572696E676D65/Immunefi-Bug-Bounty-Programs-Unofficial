import { ExternalLink, Copy, CheckCircle2 } from 'lucide-react'
import { useState } from 'react'
import type { Skill } from '~/types'
import { cn } from '~/lib/utils'
import { useIPFSFallback } from '~/lib/hooks/useIPFSFallback'
import { EntityStakeInline } from '~/components/staking/EntityStakeInline'

interface SkillIdentityZoneProps {
  skill: Skill
  className?: string
}

export function SkillIdentityZone({ skill, className }: SkillIdentityZoneProps) {
  const { metadata } = skill
  const { data: resolvedMetadata } = useIPFSFallback(
    metadata.metadataUri,
    metadata,
    { timeoutMs: 3000 },
  )
  const activeMetadata = resolvedMetadata ?? metadata
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    if (activeMetadata.installUri) {
      await navigator.clipboard.writeText(activeMetadata.installUri)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <div className={cn('rounded-lg border border-border bg-card p-6', className)}>
      <div className="space-y-4">
        {/* Author */}
        {activeMetadata.author && (
          <div>
            <span className="text-sm text-muted-foreground">Author: </span>
            <span className="text-sm text-foreground">{activeMetadata.author}</span>
          </div>
        )}

        {/* Description */}
        <div>
          <p className="text-base text-foreground leading-relaxed">
            {activeMetadata.description}
          </p>
          {activeMetadata.longDescription && (
            <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
              {activeMetadata.longDescription}
            </p>
          )}
        </div>

        {/* Install URI */}
        {activeMetadata.installUri && (
          <div className="p-3 rounded-md bg-muted/50 border border-border">
            <div className="flex items-center justify-between gap-2">
              <div className="flex-1 min-w-0">
                <div className="text-xs text-muted-foreground mb-1">Install</div>
                <a
                  href={activeMetadata.installUri}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm font-mono text-brand hover:underline flex items-center gap-1.5 truncate"
                >
                  <span className="truncate">{activeMetadata.installUri}</span>
                  <ExternalLink className="w-3.5 h-3.5 flex-shrink-0" />
                </a>
              </div>
              <button
                type="button"
                onClick={handleCopy}
                className="p-2 rounded hover:bg-muted transition-colors flex-shrink-0"
                title="Copy install URI"
              >
                {copied ? (
                  <CheckCircle2 className="w-4 h-4 text-[hsl(142_71%_45%)]" />
                ) : (
                  <Copy className="w-4 h-4 text-muted-foreground" />
                )}
              </button>
            </div>
          </div>
        )}

        {/* Permissions */}
        {activeMetadata.permissions.length > 0 && (
          <div>
            <div className="text-sm font-medium text-card-foreground mb-2">
              Required Permissions
            </div>
            <div className="flex flex-wrap gap-2">
              {activeMetadata.permissions.map((perm) => (
                <span
                  key={perm}
                  className="px-2 py-1 text-xs font-mono bg-muted text-muted-foreground rounded border border-border"
                >
                  {perm}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Timestamps */}
        <div className="pt-3 border-t border-border text-xs text-muted-foreground space-y-1">
          <div>Created: {new Date(activeMetadata.createdAt).toLocaleDateString()}</div>
          {activeMetadata.updatedAt && (
            <div>Updated: {new Date(activeMetadata.updatedAt).toLocaleDateString()}</div>
          )}
        </div>

        {/* Entity-level staking */}
        <EntityStakeInline termId={skill.id} label={activeMetadata.name} />
      </div>
    </div>
  )
}
