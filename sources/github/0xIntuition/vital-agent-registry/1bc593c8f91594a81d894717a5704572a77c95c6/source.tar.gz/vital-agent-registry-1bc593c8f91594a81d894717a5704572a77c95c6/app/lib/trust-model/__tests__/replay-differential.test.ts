import { beforeEach, describe, expect, it } from 'vitest'
import type { ActionFunctionArgs, LoaderFunctionArgs } from 'react-router'
import { action as trustScoreAction } from '~/routes/api+/v1.trust.score'
import { loader as evidenceLoader } from '~/routes/api+/v1.evidence.$id'
import { clearEvidenceStore } from '~/lib/evidence/store'
import { compareReplayResults } from '../replay'

function makeActionArgs(body: unknown): ActionFunctionArgs {
  return {
    request: new Request('https://registry.local/api/v1/trust/score', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    }),
    params: {},
    context: {},
  } as ActionFunctionArgs
}

function makeLoaderArgs(id: string): LoaderFunctionArgs {
  return {
    request: new Request(`https://registry.local/api/v1/evidence/${id}`),
    params: { id },
    context: {},
  } as unknown as LoaderFunctionArgs
}

function requestForVersion(version: string, snapshotId = 'snapshot-replay-a') {
  const futureSnapshotTimestamp = new Date(Date.now() + 60 * 60 * 1000).toISOString()
  return {
    modelId: 'com.intuition.trust.default',
    version,
    snapshotId,
    snapshotTimestamp: futureSnapshotTimestamp,
    ttlSeconds: 3600,
    candidates: [
      {
        id: 'agent-a',
        inputs: {
          market_cap_wei: 1000,
          staker_count: 100,
          share_price_wei: 10,
        },
        claimIds: ['claim-1'],
        traversalPath: ['agent-a', 'has-capability', 'cap-1'],
        vaultSnapshots: [
          {
            termId: '0x01',
            marketCapWei: '1000',
            stakerCount: 100,
            sharePriceWei: '10',
          },
        ],
      },
      {
        id: 'agent-b',
        inputs: {
          market_cap_wei: 100,
          staker_count: 5,
          share_price_wei: 2,
        },
        claimIds: ['claim-2'],
        traversalPath: ['agent-b', 'has-capability', 'cap-2'],
        vaultSnapshots: [
          {
            termId: '0x02',
            marketCapWei: '100',
            stakerCount: 5,
            sharePriceWei: '2',
          },
        ],
      },
    ],
  }
}

describe('trust model replay + differential', () => {
  beforeEach(() => {
    clearEvidenceStore()
  })

  it('same model/version/snapshot yields identical output', async () => {
    const request = requestForVersion('1.0.0')
    const first = await trustScoreAction(makeActionArgs(request))
    const second = await trustScoreAction(makeActionArgs(request))
    const firstJson = await first.json()
    const secondJson = await second.json()
    expect(secondJson.data).toEqual(firstJson.data)
  })

  it('different models over same candidates produce distinct outputs', async () => {
    const v1 = await trustScoreAction(makeActionArgs(requestForVersion('1.0.0')))
    const v2 = await trustScoreAction(makeActionArgs(requestForVersion('2.0.0')))
    const v1Json = await v1.json()
    const v2Json = await v2.json()

    expect(v2Json.data.results).not.toEqual(v1Json.data.results)
  })

  it('evidence ids resolve for each scored result', async () => {
    const response = await trustScoreAction(makeActionArgs(requestForVersion('1.1.0')))
    const json = await response.json()

    for (const result of json.data.results) {
      const evidence = await evidenceLoader(makeLoaderArgs(result.evidenceId))
      expect(evidence.status).toBe(200)
    }
  })

  it('failure diagnostics isolate snapshot/model/query-hash mismatches', async () => {
    const baseline = await trustScoreAction(makeActionArgs(requestForVersion('1.0.0', 'snapshot-a')))
    const changed = await trustScoreAction(makeActionArgs(requestForVersion('2.0.0', 'snapshot-b')))
    const baselineJson = await baseline.json()
    const changedJson = await changed.json()

    const diagnostics = compareReplayResults(baselineJson.data, changedJson.data)
    expect(diagnostics.ok).toBe(false)
    expect(diagnostics.mismatches.snapshot).toBe(true)
    expect(diagnostics.mismatches.model).toBe(true)
    expect(diagnostics.mismatches.queryHash).toBe(true)
    expect(diagnostics.summary.some((entry) => entry.includes('snapshot mismatch'))).toBe(true)
    expect(diagnostics.summary.some((entry) => entry.includes('model mismatch'))).toBe(true)
    expect(diagnostics.summary.some((entry) => entry.includes('query-hash mismatch'))).toBe(true)
  })
})
