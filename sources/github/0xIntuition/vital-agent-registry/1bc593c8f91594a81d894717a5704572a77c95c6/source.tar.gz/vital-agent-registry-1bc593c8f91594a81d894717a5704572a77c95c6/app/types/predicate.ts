import type { AtomType } from './triple'

/**
 * PredicateDefinition — canonical semantic relationship type
 *
 * The registry uses 14 canonical predicates to encode all relationships.
 * This prevents fragmentation and enables consistent querying.
 */
export interface PredicateDefinition {
  /** Unique identifier slug */
  id: string
  /** Human-readable label */
  label: string
  /** What this relationship means */
  description: string
  /** Valid subject entity types */
  subjectTypes: AtomType[]
  /** Valid object entity types */
  objectTypes: AtomType[]
}
