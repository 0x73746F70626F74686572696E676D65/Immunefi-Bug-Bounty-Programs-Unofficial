import type { LoaderFunctionArgs } from 'react-router'
import { createRepository } from '~/data/repository/provider'
import { handleOptions, jsonResponse, errorResponse } from '~/lib/api/types'

export async function loader({ request, params }: LoaderFunctionArgs) {
  const optionsResponse = handleOptions(request)
  if (optionsResponse) return optionsResponse

  const { id } = params
  if (!id) {
    return errorResponse('Skill ID is required', 'MISSING_ID', 400)
  }

  const repo = createRepository()

  // Verify skill exists
  const skill = await repo.findSkill(id)
  if (!skill) {
    return errorResponse('Skill not found', 'NOT_FOUND', 404)
  }

  // Reverse lookup: find agents that use this skill
  // Agent has triples with predicate 'uses' and object term_id matching skill ID
  const allAgents = await repo.listAgents({ limit: 100 })
  const matchingAgents = allAgents.items.filter((agent) =>
    agent.triples.some(
      (triple) =>
        triple.predicate.label === 'uses' &&
        triple.object.term_id === id
    )
  )

  return jsonResponse(matchingAgents)
}
