import type { SortField } from '~/types/repository'

interface SortSelectProps {
  value: SortField
  onChange: (value: SortField) => void
  className?: string
}

/**
 * SortSelect — dropdown for sorting registry results
 */
export function SortSelect({ value, onChange, className = '' }: SortSelectProps) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <label htmlFor="sort-select" className="font-mono text-xs uppercase tracking-wider text-ink-dull">
        Sort by:
      </label>
      <select
        id="sort-select"
        value={value}
        onChange={(e) => onChange(e.target.value as SortField)}
        className="rounded-lg border border-app-line bg-app-input px-3 py-1.5 font-mono text-xs text-foreground focus:border-[hsl(var(--accent))] focus:outline-none focus:ring-1 focus:ring-[hsl(var(--accent)/0.3)]"
      >
        <option value="trust">Trust Level</option>
        <option value="name">Name (A-Z)</option>
        <option value="recent">Newest First</option>
        <option value="stakers">Most Depositors</option>
        <option value="safety">Safety Score</option>
      </select>
    </div>
  )
}
