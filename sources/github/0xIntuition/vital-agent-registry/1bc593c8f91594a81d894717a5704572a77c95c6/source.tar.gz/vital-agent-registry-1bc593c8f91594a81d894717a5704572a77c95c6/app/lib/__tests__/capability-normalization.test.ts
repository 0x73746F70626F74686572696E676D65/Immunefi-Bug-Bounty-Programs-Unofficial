import { describe, expect, it } from 'vitest'
import {
  normalizeCapabilityId,
  normalizeCapabilityIds,
} from '../capability-normalization'

describe('capability normalization', () => {
  it('normalizes individual capability ids', () => {
    expect(normalizeCapabilityId(' Code Review ')).toBe('code-review')
    expect(normalizeCapabilityId('codegen')).toBe('code-generation')
    expect(normalizeCapabilityId('web_search')).toBe('web-search')
  })

  it('normalizes lists and deduplicates', () => {
    const result = normalizeCapabilityIds([
      'Code Review',
      'code-review',
      'CODEGEN',
      'web_search',
      '',
    ])
    expect(result).toEqual(['code-review', 'code-generation', 'web-search'])
  })
})
