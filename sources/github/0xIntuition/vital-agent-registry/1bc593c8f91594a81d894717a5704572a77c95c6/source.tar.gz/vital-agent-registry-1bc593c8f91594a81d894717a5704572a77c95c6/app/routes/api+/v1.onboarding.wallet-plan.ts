import type { ActionFunctionArgs, LoaderFunctionArgs } from 'react-router'
import { handleOptions, parseJsonBody, jsonResponse, errorResponse } from '~/lib/api/types'
import { walletPlanRequestSchema, buildOnboardingContract } from '~/lib/api/onboarding'

export async function loader({ request }: LoaderFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes
  return errorResponse('Method not allowed. Use POST for wallet plan.', 'METHOD_NOT_ALLOWED', 405)
}

export async function action({ request }: ActionFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const parsed = await parseJsonBody(request, walletPlanRequestSchema)
  if ('error' in parsed) return parsed.error

  const input = parsed.data
  const contract = buildOnboardingContract({
    agentId: input.agentId,
    hasWallet: input.hasWallet,
    availableFundsWei: BigInt(input.availableFundsWei),
    requiredFundsWei: BigInt(input.requiredFundsWei),
    isRegistered: false,
    isActive: false,
    indexerLagBlocks: 0,
    policyBlocked: input.policyBlocked,
  })

  if (input.policyBlocked) {
    return errorResponse(
      'Policy blocks wallet bootstrap for this agent',
      'POLICY_BLOCKED',
      403,
      { contract },
    )
  }

  const walletAddress = input.hasWallet ? `agent:${input.agentId}` : null

  return jsonResponse({
    contract,
    chainId: input.chainId,
    policyProfile: input.policyProfile,
    walletAddress,
    unsignedTransactions: [
      {
        id: 'create-atom',
        description: 'Create agent atom for onboarding',
        to: 'MULTIVAULT_ADDRESS',
        data: '0x',
        valueWei: contract.diagnostics.requiredFundsWei,
      },
    ],
    estimatedTotalCostWei: contract.diagnostics.requiredFundsWei,
  })
}
