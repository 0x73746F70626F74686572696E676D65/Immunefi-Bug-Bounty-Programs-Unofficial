import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  pollIndexerForTermId,
  pollIndexerLagBlocks,
  pollWithBackoff,
} from '../indexer-poller'

describe('indexer poller', () => {
  afterEach(() => {
    vi.restoreAllMocks()
  })

  it('pollWithBackoff retries until success', async () => {
    let attempt = 0
    const value = await pollWithBackoff(async () => {
      attempt += 1
      return attempt >= 3 ? 'ok' : null
    }, {
      maxRetries: 4,
      initialDelayMs: 1,
      maxDelayMs: 2,
    })

    expect(value).toBe('ok')
    expect(attempt).toBe(3)
  })

  it('pollIndexerForTermId returns true when atom appears', async () => {
    const fetchMock = vi.fn()
      .mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: { atom: null } }),
      })
      .mockResolvedValueOnce({
        ok: true,
        json: async () => ({ data: { atom: { term_id: '0xabc' } } }),
      })
    vi.stubGlobal('fetch', fetchMock as any)

    const found = await pollIndexerForTermId('http://localhost:8080/v1/graphql', '0xabc', {
      maxRetries: 2,
      initialDelayMs: 1,
      maxDelayMs: 2,
    })

    expect(found).toBe(true)
    expect(fetchMock).toHaveBeenCalledTimes(2)
  })

  it('pollIndexerLagBlocks returns lag value when available', async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ data: { indexer_status: { lag_blocks: 7 } } }),
    })
    vi.stubGlobal('fetch', fetchMock as any)

    const lag = await pollIndexerLagBlocks('http://localhost:8080/v1/graphql', {
      maxRetries: 1,
      initialDelayMs: 1,
      maxDelayMs: 2,
    })

    expect(lag).toBe(7)
  })
})
