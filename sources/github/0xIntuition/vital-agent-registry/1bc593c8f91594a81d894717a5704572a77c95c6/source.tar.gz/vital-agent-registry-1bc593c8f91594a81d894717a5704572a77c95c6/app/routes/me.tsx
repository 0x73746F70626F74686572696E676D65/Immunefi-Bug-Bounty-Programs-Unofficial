import { useState } from 'react'
import { useLoaderData } from 'react-router'
import { useAccount, useWriteContract } from 'wagmi'
import { createPublicClient, http } from 'viem'
import { CONTRACTS, CHAINS } from '~/lib/constants/protocol'
import { RegistryLayout } from '~/components/layout/RegistryLayout'
import { AgentRegistrationForm } from '~/components/registration/AgentRegistrationForm'
import { SkillRegistrationForm } from '~/components/registration/SkillRegistrationForm'
import {
  TransactionProgress,
  type TransactionStep,
} from '~/components/registration/TransactionProgress'
import { getIndexerLagBlocks } from '~/lib/indexer-lag.server'
import { generateAvatar } from '~/lib/avatar'
import type { AgentMetadata } from '~/lib/schemas/agent-metadata'
import { SKILL_PLATFORM_OPTIONS, type SkillMetadataPayload } from '~/lib/schemas/skill-metadata'
import { multivaultAbi } from '~/lib/abis/multivault'
import type { AgentImportFields, SkillImportFields } from '~/lib/import/types'

export function meta() {
  return [
    { title: 'Register — Intuition' },
    {
      name: 'description',
      content: 'Register an agent or skill on the Intuition protocol.',
    },
  ]
}

type RegistrationKind = 'agent' | 'skill'

function createInitialSteps(): TransactionStep[] {
  return [
    {
      label: 'IPFS Upload',
      description: 'Upload and validate metadata payload',
      status: 'pending',
    },
    {
      label: 'Atom Creation',
      description: 'Wallet signature for atom creation transaction',
      status: 'pending',
    },
    {
      label: 'Triple Creation',
      description: 'Wallet signature for relationship triples',
      status: 'pending',
    },
  ]
}

export async function loader() {
  const indexerLagBlocks = await getIndexerLagBlocks()
  return { indexerLagBlocks }
}

export default function MyProfilePage() {
  const { indexerLagBlocks } = useLoaderData<typeof loader>()
  const { isConnected, address } = useAccount()
  const { writeContractAsync } = useWriteContract()
  const [kind, setKind] = useState<RegistrationKind>('agent')
  const [steps, setSteps] = useState<TransactionStep[]>(createInitialSteps())
  const [resultMessage, setResultMessage] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [lastResponseData, setLastResponseData] = useState<{
    transactions: Array<{
      signatureIndex: number
      kind: string
      to: string
      data: string
      value: string
    }>
  } | null>(null)

  // Import URL state
  const [importUrl, setImportUrl] = useState('')
  const [isImporting, setIsImporting] = useState(false)
  const [importError, setImportError] = useState<string | null>(null)
  const [agentInitialData, setAgentInitialData] = useState<Partial<AgentMetadata> | undefined>()
  const [skillInitialData, setSkillInitialData] = useState<Partial<SkillMetadataPayload> | undefined>()

  function resetProgress() {
    setSteps(createInitialSteps())
    setResultMessage(null)
    setLastResponseData(null)
  }

  const getContractAddr = (): `0x${string}` => {
    const chain = typeof window !== 'undefined' ? window.ENV?.CHAIN ?? 'testnet' : 'testnet'
    if (chain === 'local') return CONTRACTS.MULTIVAULT_LOCAL as `0x${string}`
    if (chain === 'mainnet') return CONTRACTS.MULTIVAULT_MAINNET as `0x${string}`
    return CONTRACTS.MULTIVAULT_TESTNET as `0x${string}`
  }
  const getRpcUrl = (): string => {
    const chain = typeof window !== 'undefined' ? window.ENV?.CHAIN ?? 'testnet' : 'testnet'
    if (chain === 'local') return CHAINS.LOCAL.rpcUrl
    if (chain === 'mainnet') return CHAINS.MAINNET.rpcUrl
    return CHAINS.TESTNET.rpcUrl
  }

  async function sendTransaction(
    tx: { to: string; data: string; value: string; kind: string },
    stepIndex: number,
  ): Promise<`0x${string}` | null> {
    if (!isConnected) {
      setStep(stepIndex, {
        status: 'rejected',
        error: 'Wallet not connected. Please connect your wallet first.',
      })
      return null
    }

    try {
      setStep(stepIndex, { status: 'in_progress', error: undefined })

      const hash = await (
        writeContractAsync as (config: {
          address: `0x${string}`
          abi: typeof multivaultAbi
          functionName: string
          data: `0x${string}`
          value: bigint
        }) => Promise<`0x${string}`>
      )({
        address: tx.to as `0x${string}`,
        abi: multivaultAbi,
        functionName:
          tx.kind === 'createAtoms' ? 'createAtoms' : 'createTriples',
        data: tx.data as `0x${string}`,
        value: BigInt(tx.value),
      })

      const publicClient = createPublicClient({
        transport: http(getRpcUrl()),
      })

      const receipt = await publicClient.waitForTransactionReceipt({ hash })

      if (receipt.status === 'success') {
        setStep(stepIndex, { status: 'confirmed', error: undefined })
        return hash
      } else {
        setStep(stepIndex, { status: 'failed', error: 'Transaction failed' })
        return null
      }
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : 'Transaction rejected'
      setStep(stepIndex, {
        status: 'rejected',
        error: errorMessage.includes('rejected')
          ? 'Wallet signature was rejected'
          : `Transaction error: ${errorMessage}`,
      })
      return null
    }
  }

  async function executeTransactions() {
    if (!lastResponseData?.transactions) return

    const contractAddress = getContractAddr()

    const atomTx = lastResponseData.transactions.find(
      (t) => t.kind === 'createAtoms',
    )
    if (atomTx) {
      const hash = await sendTransaction(
        { ...atomTx, to: atomTx.to || contractAddress },
        1,
      )
      if (!hash) return
    }

    const tripleTx = lastResponseData.transactions.find(
      (t) => t.kind === 'createTriples',
    )
    if (tripleTx) {
      const hash = await sendTransaction(
        { ...tripleTx, to: tripleTx.to || contractAddress },
        2,
      )
      if (!hash) return
    }

    setResultMessage('Registration completed successfully!')
  }

  function setStep(index: number, patch: Partial<TransactionStep>) {
    setSteps((prev) =>
      prev.map((step, i) => (i === index ? { ...step, ...patch } : step)),
    )
  }

  async function postRegistration(
    endpoint: string,
    metadata: AgentMetadata | SkillMetadataPayload,
  ): Promise<{
    transactions: Array<{
      signatureIndex: number
      kind: string
      to: string
      data: string
      value: string
    }>
  }> {
    const body = { ...metadata }
    delete (body as Record<string, unknown>)['@type']

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    })

    const payload = await response.json()
    if (!response.ok) {
      const retryAfter = payload.retryAfter
        ? ` (retry after ${payload.retryAfter}s)`
        : ''
      throw new Error(
        `${payload.error ?? 'Registration failed'} [${payload.code ?? response.status}]${retryAfter}`,
      )
    }

    return {
      transactions: payload.data?.transactions ?? [],
    }
  }

  function continueFromAtomStep() {
    if (!isConnected) {
      setStep(1, {
        status: 'rejected',
        error:
          'Wallet not connected. Please connect your wallet to sign transactions.',
      })
      return
    }
    executeTransactions()
  }

  async function handleAgentSubmit(metadata: AgentMetadata) {
    setIsSubmitting(true)
    setResultMessage(null)
    setSteps(createInitialSteps())
    setStep(0, { status: 'in_progress', error: undefined })

    try {
      const { transactions } = await postRegistration(
        '/api/v1/agents/register',
        metadata,
      )
      setLastResponseData({ transactions })
      setStep(0, { status: 'confirmed', error: undefined })
      setStep(1, { status: 'in_progress', error: undefined })
      continueFromAtomStep()
    } catch (error) {
      setStep(0, {
        status: 'failed',
        error: error instanceof Error ? error.message : 'Unknown error',
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  async function handleSkillSubmit(metadata: SkillMetadataPayload) {
    setIsSubmitting(true)
    setResultMessage(null)
    setSteps(createInitialSteps())
    setStep(0, { status: 'in_progress', error: undefined })

    try {
      const { transactions } = await postRegistration(
        '/api/v1/skills/register',
        metadata,
      )
      setLastResponseData({ transactions })
      setStep(0, { status: 'confirmed', error: undefined })
      setStep(1, { status: 'in_progress', error: undefined })
      continueFromAtomStep()
    } catch (error) {
      setStep(0, {
        status: 'failed',
        error: error instanceof Error ? error.message : 'Unknown error',
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  function handleRetry(stepIndex: number) {
    if (stepIndex === 1) {
      setStep(1, { status: 'in_progress', error: undefined })
      continueFromAtomStep()
      return
    }

    if (stepIndex === 2) {
      setStep(2, { status: 'in_progress', error: undefined })
      if (!isConnected) {
        setStep(2, {
          status: 'rejected',
          error:
            'Wallet not connected. Please connect your wallet to sign transactions.',
        })
        return
      }
      executeTransactions()
    }
  }

  async function handleImport() {
    if (!importUrl.trim()) return
    setIsImporting(true)
    setImportError(null)

    try {
      const response = await fetch('/api/v1/import', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ url: importUrl.trim() }),
      })

      const payload = await response.json()
      if (!response.ok) {
        setImportError(payload.error ?? 'Import failed')
        return
      }

      const fields = payload.data?.fields
      if (!fields) {
        setImportError('No data returned from import')
        return
      }

      if (fields.type === 'agent') {
        const agentFields = fields as AgentImportFields
        setKind('agent')
        setAgentInitialData({
          name: agentFields.name,
          description: agentFields.description,
          endpoint: agentFields.endpoint,
          model: agentFields.model,
          image: agentFields.image,
          capabilities: agentFields.capabilities,
          ...(agentFields.providerName || agentFields.providerUrl
            ? {
                provider: {
                  name: agentFields.providerName ?? '',
                  ...(agentFields.providerUrl && { url: agentFields.providerUrl }),
                },
              }
            : {}),
        })
        resetProgress()
      } else if (fields.type === 'skill') {
        const skillFields = fields as SkillImportFields
        setKind('skill')
        const validPlatforms: readonly string[] = SKILL_PLATFORM_OPTIONS
        const resolvedPlatform = skillFields.platform && validPlatforms.includes(skillFields.platform)
          ? (skillFields.platform as SkillMetadataPayload['platform'])
          : undefined
        setSkillInitialData({
          name: skillFields.name,
          description: skillFields.description,
          author: skillFields.author,
          installUri: skillFields.installUri,
          image: skillFields.image,
          ...(resolvedPlatform && { platform: resolvedPlatform }),
        })
        resetProgress()
      }

      setImportUrl('')
    } catch (error) {
      setImportError(error instanceof Error ? error.message : 'Import failed')
    } finally {
      setIsImporting(false)
    }
  }

  const hasProgress = steps.some((s) => s.status !== 'pending')

  return (
    <RegistryLayout
      header={
        <div className="space-y-4 py-4">
          <div className="flex flex-col gap-1">
            <h1
              style={{
                fontFamily: 'monospace',
                fontSize: 20,
                fontWeight: 900,
                letterSpacing: '0.06em',
                textTransform: 'uppercase',
                color: '#e0e0e8',
              }}
            >
              REGISTER
            </h1>
            <p
              style={{
                fontFamily: 'monospace',
                fontSize: 10,
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                color: '#4a4a60',
              }}
            >
              DEPLOY AN ENTITY TO THE INTUITION PROTOCOL
            </p>
          </div>

          {/* Entity type selector */}
          <div
            style={{
              display: 'flex',
              gap: 2,
              padding: 3,
              borderRadius: 10,
              background: '#0a0a12',
              border: '1px solid #1e1e2e',
            }}
          >
            {(['agent', 'skill'] as const).map((type) => {
              const isActive = kind === type
              return (
                <button
                  key={type}
                  type="button"
                  onClick={() => {
                    setKind(type)
                    resetProgress()
                  }}
                  style={{
                    flex: 1,
                    padding: '7px 12px',
                    borderRadius: 7,
                    border: 'none',
                    background: isActive
                      ? 'hsl(282,70%,56%,0.15)'
                      : 'transparent',
                    color: isActive ? 'hsl(282,70%,70%)' : '#4a4a60',
                    fontFamily: 'monospace',
                    fontSize: 10,
                    fontWeight: 700,
                    letterSpacing: '0.1em',
                    cursor: 'pointer',
                    transition: 'background 0.15s, color 0.15s',
                    textTransform: 'uppercase',
                    ...(isActive && {
                      boxShadow: '0 0 0 1px hsl(282,70%,56%,0.3)',
                    }),
                  }}
                >
                  {type}
                </button>
              )
            })}
          </div>
        </div>
      }
    >
      <div className="space-y-5 py-6">
        {/* Creator Identity — Moltbook-inspired pairing */}
        <div
          style={{
            borderRadius: 12,
            background: '#0a0a12',
            border: '1px solid #1e1e2e',
            padding: '16px 20px',
          }}
        >
          {isConnected && address ? (
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 16,
              }}
            >
              {/* Human side */}
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 10,
                  flex: 1,
                  minWidth: 0,
                }}
              >
                <img
                  src={generateAvatar(address, 40)}
                  alt="Your wallet"
                  width={40}
                  height={40}
                  style={{
                    borderRadius: '50%',
                    border: '1.5px solid hsl(282,70%,56%,0.4)',
                    flexShrink: 0,
                  }}
                />
                <div style={{ minWidth: 0 }}>
                  <div
                    style={{
                      fontFamily: 'monospace',
                      fontSize: 8,
                      letterSpacing: '0.14em',
                      textTransform: 'uppercase',
                      color: '#4a4a60',
                      marginBottom: 2,
                    }}
                  >
                    OPERATOR
                  </div>
                  <div
                    style={{
                      fontFamily: 'monospace',
                      fontSize: 12,
                      fontWeight: 700,
                      color: '#e0e0e8',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {address.slice(0, 6)}...{address.slice(-4)}
                  </div>
                </div>
              </div>

              {/* Arrow / link */}
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: 2,
                  flexShrink: 0,
                }}
              >
                <div
                  style={{
                    fontFamily: 'monospace',
                    fontSize: 7,
                    letterSpacing: '0.14em',
                    textTransform: 'uppercase',
                    color: 'hsl(282,70%,56%,0.6)',
                  }}
                >
                  CREATED-BY
                </div>
                <div
                  style={{
                    width: 48,
                    height: 1,
                    background:
                      'linear-gradient(90deg, hsl(282,70%,56%,0.1), hsl(282,70%,56%,0.5), hsl(282,70%,56%,0.1))',
                  }}
                />
                <div
                  style={{
                    fontFamily: 'monospace',
                    fontSize: 7,
                    letterSpacing: '0.1em',
                    color: '#2a2a40',
                  }}
                >
                  ON-CHAIN
                </div>
              </div>

              {/* Entity side */}
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 10,
                  flex: 1,
                  minWidth: 0,
                  justifyContent: 'flex-end',
                }}
              >
                <div style={{ minWidth: 0, textAlign: 'right' }}>
                  <div
                    style={{
                      fontFamily: 'monospace',
                      fontSize: 8,
                      letterSpacing: '0.14em',
                      textTransform: 'uppercase',
                      color: '#4a4a60',
                      marginBottom: 2,
                    }}
                  >
                    NEW {kind.toUpperCase()}
                  </div>
                  <div
                    style={{
                      fontFamily: 'monospace',
                      fontSize: 12,
                      fontWeight: 700,
                      color: '#e0e0e8',
                    }}
                  >
                    {kind === 'agent' ? 'Agent' : 'Skill'}
                  </div>
                </div>
                <div
                  style={{
                    width: 40,
                    height: 40,
                    borderRadius: '50%',
                    background: '#14141f',
                    border: `1.5px solid ${kind === 'agent' ? 'hsl(282,70%,56%,0.3)' : 'hsl(142,71%,45%,0.3)'}`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontFamily: 'monospace',
                    fontSize: 14,
                    fontWeight: 900,
                    color:
                      kind === 'agent'
                        ? 'hsl(282,70%,56%)'
                        : 'hsl(142,71%,45%)',
                    flexShrink: 0,
                  }}
                >
                  {kind === 'agent' ? 'A' : 'S'}
                </div>
              </div>
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '20px 0' }}>
              <div
                style={{
                  fontFamily: 'monospace',
                  fontSize: 11,
                  fontWeight: 700,
                  letterSpacing: '0.1em',
                  textTransform: 'uppercase',
                  color: '#4a4a60',
                  marginBottom: 8,
                }}
              >
                WALLET NOT CONNECTED
              </div>
              <div
                style={{
                  fontFamily: 'monospace',
                  fontSize: 10,
                  color: '#2a2a40',
                  letterSpacing: '0.06em',
                  maxWidth: 420,
                  margin: '0 auto',
                  lineHeight: 1.7,
                }}
              >
                Connect your wallet to register entities on the Intuition
                protocol. Your address serves as your on-chain identity — every
                agent and skill you create will be permanently linked via a
                created-by triple.
              </div>
            </div>
          )}
        </div>

        {/* Import from URL */}
        <div
          style={{
            borderRadius: 12,
            background: '#0a0a12',
            border: '1px solid #1e1e2e',
            padding: '16px 20px',
          }}
        >
          <div
            style={{
              fontFamily: 'monospace',
              fontSize: 8,
              letterSpacing: '0.14em',
              textTransform: 'uppercase',
              color: '#4a4a60',
              marginBottom: 12,
            }}
          >
            === IMPORT FROM URL ===
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
            <div style={{ flex: 1 }}>
              <input
                type="url"
                value={importUrl}
                onChange={(e) => {
                  setImportUrl(e.target.value)
                  setImportError(null)
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleImport()
                }}
                placeholder="https://moltbook.com/u/alice or https://clawhub.ai/skills/github-mcp"
                disabled={isImporting}
                style={{
                  width: '100%',
                  background: '#08080f',
                  border: importError ? '1px solid hsl(0,70%,50%)' : '1px solid #1e1e2e',
                  borderRadius: 8,
                  padding: '8px 12px',
                  fontFamily: 'monospace',
                  fontSize: 12,
                  color: '#e0e0e8',
                  outline: 'none',
                  opacity: isImporting ? 0.5 : 1,
                }}
              />
              {importError && (
                <p
                  style={{
                    marginTop: 6,
                    fontFamily: 'monospace',
                    fontSize: 10,
                    color: 'hsl(0,70%,50%)',
                    letterSpacing: '0.04em',
                  }}
                >
                  {importError}
                </p>
              )}
              <p
                style={{
                  marginTop: 6,
                  fontFamily: 'monospace',
                  fontSize: 9,
                  color: '#2a2a40',
                  letterSpacing: '0.06em',
                }}
              >
                Supported: moltbook.com/u/&#123;name&#125; → agent · clawhub.ai/skills/&#123;slug&#125; → skill
              </p>
            </div>
            <button
              type="button"
              onClick={handleImport}
              disabled={isImporting || !importUrl.trim()}
              style={{
                padding: '8px 16px',
                borderRadius: 8,
                border: '1px solid hsl(282,70%,56%,0.3)',
                background: isImporting ? '#14141f' : 'hsl(282,70%,56%,0.1)',
                color: isImporting ? '#4a4a60' : 'hsl(282,70%,70%)',
                fontFamily: 'monospace',
                fontSize: 10,
                fontWeight: 700,
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                cursor: isImporting || !importUrl.trim() ? 'not-allowed' : 'pointer',
                whiteSpace: 'nowrap',
                transition: 'background 0.15s, color 0.15s',
                opacity: !importUrl.trim() ? 0.4 : 1,
              }}
            >
              {isImporting ? 'IMPORTING...' : 'IMPORT'}
            </button>
          </div>
        </div>

        {/* Status bar — indexer + wallet + reset */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            flexWrap: 'wrap',
          }}
        >
          <span
            style={{
              fontFamily: 'monospace',
              fontSize: 9,
              letterSpacing: '0.1em',
              color: '#2a2a40',
              textTransform: 'uppercase',
            }}
          >
            INDEXER_LAG: {indexerLagBlocks} BLOCKS
          </span>
          <span
            style={{
              fontFamily: 'monospace',
              fontSize: 9,
              letterSpacing: '0.1em',
              textTransform: 'uppercase',
              color: isConnected ? 'hsl(142,71%,45%)' : '#4a4a60',
            }}
          >
            WALLET:{' '}
            {isConnected
              ? `${address?.slice(0, 6)}...${address?.slice(-4)}`
              : 'DISCONNECTED'}
          </span>
          {hasProgress && (
            <button
              type="button"
              onClick={resetProgress}
              style={{
                fontFamily: 'monospace',
                fontSize: 9,
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                color: 'hsl(282,70%,56%)',
                cursor: 'pointer',
                background: 'none',
                border: 'none',
                padding: 0,
              }}
            >
              [RESET]
            </button>
          )}
        </div>

        {/* Registration Form */}
        <div
          style={{
            borderRadius: 12,
            background: '#0a0a12',
            border: '1px solid #1e1e2e',
            padding: '20px',
          }}
        >
          {kind === 'agent' ? (
            <AgentRegistrationForm
              onSubmit={handleAgentSubmit}
              isSubmitting={isSubmitting}
              initialData={agentInitialData}
            />
          ) : (
            <SkillRegistrationForm
              onSubmit={handleSkillSubmit}
              isSubmitting={isSubmitting}
              initialData={skillInitialData}
            />
          )}
        </div>

        {/* Transaction Log — only shown when a transaction has started */}
        {hasProgress && (
          <div
            style={{
              borderRadius: 12,
              background: '#0a0a12',
              border: '1px solid #1e1e2e',
              padding: '16px 20px',
            }}
          >
            <div
              style={{
                fontFamily: 'monospace',
                fontSize: 8,
                letterSpacing: '0.14em',
                textTransform: 'uppercase',
                color: '#4a4a60',
                marginBottom: 12,
              }}
            >
              === TRANSACTION LOG ===
            </div>
            <TransactionProgress steps={steps} onRetry={handleRetry} />
            {resultMessage && (
              <div
                style={{
                  marginTop: 12,
                  paddingTop: 12,
                  borderTop: '1px solid #1e1e2e',
                  fontFamily: 'monospace',
                  fontSize: 11,
                  color: 'hsl(142, 71%, 45%)',
                  fontWeight: 700,
                  letterSpacing: '0.06em',
                }}
              >
                {resultMessage}
              </div>
            )}
          </div>
        )}
      </div>
    </RegistryLayout>
  )
}
