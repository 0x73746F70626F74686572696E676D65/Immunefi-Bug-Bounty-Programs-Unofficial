import type { Model } from '~/types'

export const MODELS: Model[] = [
  // Anthropic
  { id: 'claude-opus-4-6', name: 'Claude Opus 4.6', providerId: 'anthropic', description: 'Most capable Claude model for complex tasks' },
  { id: 'claude-sonnet-4-6', name: 'Claude Sonnet 4.6', providerId: 'anthropic', description: 'Balanced performance and speed' },
  { id: 'claude-haiku-4-5', name: 'Claude Haiku 4.5', providerId: 'anthropic', description: 'Fast and cost-efficient' },

  // OpenAI
  { id: 'gpt-4o', name: 'GPT-4o', providerId: 'openai', description: 'Multimodal flagship model' },
  { id: 'gpt-4-turbo', name: 'GPT-4 Turbo', providerId: 'openai', description: 'High-capability model with large context' },
  { id: 'o1', name: 'o1', providerId: 'openai', description: 'Advanced reasoning model' },
  { id: 'o3-mini', name: 'o3-mini', providerId: 'openai', description: 'Fast reasoning model' },

  // Google
  { id: 'gemini-2.0-flash', name: 'Gemini 2.0 Flash', providerId: 'google', description: 'Fast multimodal model' },
  { id: 'gemini-1.5-pro', name: 'Gemini 1.5 Pro', providerId: 'google', description: 'Long context reasoning model' },

  // Meta
  { id: 'llama-3.1-405b', name: 'Llama 3.1 405B', providerId: 'meta', description: 'Largest open-source Llama model' },
  { id: 'llama-3.1-70b', name: 'Llama 3.1 70B', providerId: 'meta', description: 'Efficient open-source model' },

  // Mistral
  { id: 'mistral-large', name: 'Mistral Large', providerId: 'mistral', description: 'Top-tier Mistral reasoning model' },
  { id: 'mixtral-8x22b', name: 'Mixtral 8x22B', providerId: 'mistral', description: 'Mixture-of-experts model' },

  // xAI
  { id: 'grok-2', name: 'Grok 2', providerId: 'xai', description: 'Real-time information access model' },
]

export function findModelById(id: string): Model | undefined {
  return MODELS.find((m) => m.id === id)
}

export function getModelsByProvider(providerId: string): Model[] {
  return MODELS.filter((m) => m.providerId === providerId)
}

export function getModelOptions(): Array<{ value: string; label: string; group: string }> {
  return MODELS.map((m) => ({
    value: m.id,
    label: m.name,
    group: m.providerId,
  }))
}
