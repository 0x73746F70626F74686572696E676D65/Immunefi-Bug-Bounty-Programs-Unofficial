export type ImportSource = 'moltbook' | 'clawhub' | 'unknown'

export interface AgentImportFields {
  type: 'agent'
  name?: string
  description?: string
  endpoint?: string
  model?: string
  providerName?: string
  providerUrl?: string
  image?: string
  capabilities?: string[]
}

export interface SkillImportFields {
  type: 'skill'
  name?: string
  description?: string
  author?: string
  installUri?: string
  image?: string
  platform?: string
}

export type ImportFields = AgentImportFields | SkillImportFields

export interface ImportResult {
  source: ImportSource
  slug: string
  fields: ImportFields
}

export interface ImportError {
  code: 'UNSUPPORTED_URL' | 'FETCH_FAILED' | 'PARSE_FAILED' | 'NOT_FOUND'
  message: string
}
