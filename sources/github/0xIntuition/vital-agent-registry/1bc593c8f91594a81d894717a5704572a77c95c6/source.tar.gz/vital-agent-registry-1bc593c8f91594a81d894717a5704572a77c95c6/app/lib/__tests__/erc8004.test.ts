import { describe, it, expect } from 'vitest'
import { generateERC8004, generateOnboardingExtension } from '../erc8004'
import type { Agent } from '~/types'
import { CONTRACTS, CHAINS } from '~/lib/constants/protocol'

/**
 * Helper to create a mock Agent object for testing.
 */
function createMockAgent(overrides?: Partial<Agent>): Agent {
  return {
    id: '0xabcdef1234567890',
    metadata: {
      name: 'TestAgent',
      description: 'A test agent',
      version: '1.0.0',
      model: 'claude-opus-4-6',
      endpoint: 'https://agent.example.com',
      provider: { name: 'TestCo', url: 'https://testco.com' },
      tags: ['test'],
      createdAt: '2025-01-01T00:00:00Z',
    },
    capabilities: [
      {
        id: 'cap-1',
        name: 'code-execution',
        description: 'Execute code',
        category: 'development',
      },
    ],
    vault: {
      term_id: '0xvault123',
      curve_id: '0xcurve1',
      total_shares: '1000000000000000000',
      current_share_price: '1000000000000000000',
      total_assets: '5000000000000000000',
      market_cap: '5000000000000000000',
      position_count: 10,
    },
    trustSignal: {
      totalStaked: '5.0',
      stakerCount: 10,
      sharePrice: '1.0',
      percentile: 75,
      tier: 'gold',
      marketCap: '5.0',
    },
    triples: [],
    ...overrides,
  }
}

describe('erc8004', () => {
  describe('generateERC8004', () => {
    it('should return all required ERC-8004 fields', () => {
      const agent = createMockAgent()
      const result = generateERC8004(agent, 'testnet')

      expect(result).toHaveProperty('agentId')
      expect(result).toHaveProperty('registryAddress')
      expect(result).toHaveProperty('chainId')
      expect(result).toHaveProperty('agentURI')
      expect(result).toHaveProperty('agentWallet')
      expect(result).toHaveProperty('metadata')
      expect(result).toHaveProperty('services')
      expect(result).toHaveProperty('active')
      expect(result).toHaveProperty('registrations')
      expect(result).toHaveProperty('trustModels')
      expect(result).toHaveProperty('registrationFile')
    })

    it('should use correct MultiVault address for testnet chain', () => {
      const agent = createMockAgent()
      const result = generateERC8004(agent, 'testnet')

      expect(result.registryAddress).toBe(CONTRACTS.MULTIVAULT_TESTNET)
      expect(result.registryAddress).toBe('0xB92EA1B47E4ABD0a520E9138BB59dBd1bC6C475B')
    })

    it('should use correct MultiVault address for mainnet chain', () => {
      const agent = createMockAgent()
      const result = generateERC8004(agent, 'mainnet')

      expect(result.registryAddress).toBe(CONTRACTS.MULTIVAULT_MAINNET)
      expect(result.registryAddress).toBe('0x6E35cF57A41fA15eA0EaE9C33e751b01A784Fe7e')
    })

    it('should use correct chainId for testnet', () => {
      const agent = createMockAgent()
      const result = generateERC8004(agent, 'testnet')

      expect(result.chainId).toBe(CHAINS.TESTNET.chainId)
      expect(result.chainId).toBe(13579)
    })

    it('should use correct chainId for mainnet', () => {
      const agent = createMockAgent()
      const result = generateERC8004(agent, 'mainnet')

      expect(result.chainId).toBe(CHAINS.MAINNET.chainId)
      expect(result.chainId).toBe(1155)
    })

    it('should populate metadata from agent.metadata', () => {
      const agent = createMockAgent({
        metadata: {
          name: 'CustomAgent',
          description: 'Custom description',
          version: '2.0.0',
          model: 'gpt-4o',
          createdAt: '2025-01-01T00:00:00Z',
        },
      })
      const result = generateERC8004(agent, 'testnet')

      expect(result.metadata).toEqual({
        name: 'CustomAgent',
        description: 'Custom description',
        version: '2.0.0',
        model: 'gpt-4o',
      })
    })

    it('should include A2A service binding when agent has endpoint', () => {
      const agent = createMockAgent({
        metadata: {
          name: 'TestAgent',
          description: 'Test',
          version: '1.0.0',
          endpoint: 'https://my-agent.com/api',
          createdAt: '2025-01-01T00:00:00Z',
        },
      })
      const result = generateERC8004(agent, 'testnet')

      expect(result.services).toHaveLength(1)
      expect(result.services?.[0]).toEqual({
        name: 'a2a',
        endpoint: 'https://my-agent.com/api',
        version: '1.0.0',
      })
    })

    it('should return empty services array when agent has no endpoint', () => {
      const agent = createMockAgent({
        metadata: {
          name: 'TestAgent',
          description: 'Test',
          version: '1.0.0',
          endpoint: undefined,
          createdAt: '2025-01-01T00:00:00Z',
        },
      })
      const result = generateERC8004(agent, 'testnet')

      expect(result.services).toEqual([])
    })

    it('should set active field to true', () => {
      const agent = createMockAgent()
      const result = generateERC8004(agent, 'testnet')

      expect(result.active).toBe(true)
    })

    it('should include intuition-vault-staking in trustModels', () => {
      const agent = createMockAgent()
      const result = generateERC8004(agent, 'testnet')

      expect(result.trustModels).toContain('intuition-vault-staking')
    })

    it('should return empty registrations array for single-chain', () => {
      const agent = createMockAgent()
      const result = generateERC8004(agent, 'testnet')

      expect(result.registrations).toEqual([])
    })

    it('should include agent ID in registrationFile URL', () => {
      const agent = createMockAgent({ id: '0x123abc' })
      const result = generateERC8004(agent, 'testnet')

      expect(result.registrationFile).toContain('0x123abc')
      expect(result.registrationFile).toBe(
        'https://registry.intuition.systems/api/v1/agents/0x123abc/erc8004'
      )
    })

    it('should use IPFS image as agentURI when available', () => {
      const agent = createMockAgent({
        metadata: {
          name: 'TestAgent',
          description: 'Test',
          version: '1.0.0',
          image: 'ipfs://QmTestHash123',
          createdAt: '2025-01-01T00:00:00Z',
        },
      })
      const result = generateERC8004(agent, 'testnet')

      expect(result.agentURI).toBe('ipfs://QmTestHash123')
    })

    it('should fallback to agent ID for agentURI when no IPFS image', () => {
      const agent = createMockAgent({
        id: '0xfallback123',
        metadata: {
          name: 'TestAgent',
          description: 'Test',
          version: '1.0.0',
          createdAt: '2025-01-01T00:00:00Z',
        },
      })
      const result = generateERC8004(agent, 'testnet')

      expect(result.agentURI).toBe('ipfs://0xfallback123')
    })

    it('should populate agentId with agent.id', () => {
      const agent = createMockAgent({ id: '0xunique_agent_id' })
      const result = generateERC8004(agent, 'testnet')

      expect(result.agentId).toBe('0xunique_agent_id')
    })

    it('should handle agent with minimal metadata', () => {
      const agent = createMockAgent({
        metadata: {
          name: 'MinimalAgent',
          description: 'Minimal',
          version: '0.0.1',
          createdAt: '2025-01-01T00:00:00Z',
        },
      })
      const result = generateERC8004(agent, 'testnet')

      expect(result.metadata?.model).toBe('')
      expect(result.services).toEqual([])
    })

    it('should use provider URL for agentWallet when available', () => {
      const agent = createMockAgent({
        metadata: {
          name: 'Test',
          description: 'Test',
          version: '1.0.0',
          provider: { name: 'TestCo', url: 'https://testco.com' },
          createdAt: '2025-01-01T00:00:00Z',
        },
      })
      const result = generateERC8004(agent, 'testnet')

      expect(result.agentWallet).toBe('https://testco.com')
    })

    it('should handle missing provider', () => {
      const agent = createMockAgent({
        metadata: {
          name: 'Test',
          description: 'Test',
          version: '1.0.0',
          provider: undefined,
          createdAt: '2025-01-01T00:00:00Z',
        },
      })
      const result = generateERC8004(agent, 'testnet')

      expect(result.agentWallet).toBe('')
    })

    it('should not include onboarding by default', () => {
      const agent = createMockAgent()
      const result = generateERC8004(agent, 'testnet')

      expect(result.onboarding).toBeUndefined()
    })

    it('should not include onboarding when includeOnboarding is false', () => {
      const agent = createMockAgent()
      const result = generateERC8004(agent, 'testnet', { includeOnboarding: false })

      expect(result.onboarding).toBeUndefined()
    })

    it('should include onboarding extension when includeOnboarding is true', () => {
      const agent = createMockAgent()
      const result = generateERC8004(agent, 'testnet', { includeOnboarding: true })

      expect(result.onboarding).toBeDefined()
      expect(result.onboarding!.walletStrategy).toBe('eoa')
      expect(result.onboarding!.fundingProfile).toBeDefined()
      expect(result.onboarding!.supportedTrustModelIds).toContain('com.intuition.trust.default')
      expect(result.onboarding!.readinessEndpoint).toContain(agent.id)
    })
  })

  describe('generateOnboardingExtension', () => {
    it('should return correct wallet strategy', () => {
      const agent = createMockAgent()
      const ext = generateOnboardingExtension(agent, 'testnet')

      expect(ext.walletStrategy).toBe('eoa')
    })

    it('should return valid funding profile with BigInt-compatible wei strings', () => {
      const agent = createMockAgent()
      const ext = generateOnboardingExtension(agent, 'testnet')

      expect(() => BigInt(ext.fundingProfile.minimumWei)).not.toThrow()
      expect(() => BigInt(ext.fundingProfile.recommendedWei)).not.toThrow()
      expect(BigInt(ext.fundingProfile.minimumWei)).toBeGreaterThan(0n)
      expect(BigInt(ext.fundingProfile.recommendedWei)).toBeGreaterThan(BigInt(ext.fundingProfile.minimumWei))
      expect(ext.fundingProfile.expectedTransactions).toBeGreaterThan(0)
    })

    it('should use cheaper estimates for testnet', () => {
      const agent = createMockAgent()
      const testnetExt = generateOnboardingExtension(agent, 'testnet')
      const mainnetExt = generateOnboardingExtension(agent, 'mainnet')

      expect(BigInt(testnetExt.fundingProfile.minimumWei)).toBeLessThan(
        BigInt(mainnetExt.fundingProfile.minimumWei),
      )
    })

    it('should include supported trust model IDs', () => {
      const agent = createMockAgent()
      const ext = generateOnboardingExtension(agent, 'testnet')

      expect(ext.supportedTrustModelIds).toHaveLength(1)
      expect(ext.supportedTrustModelIds[0]).toBe('com.intuition.trust.default')
    })

    it('should include readiness endpoint with agent ID', () => {
      const agent = createMockAgent({ id: '0xmy_agent_id' })
      const ext = generateOnboardingExtension(agent, 'testnet')

      expect(ext.readinessEndpoint).toBe('/api/v1/onboarding/agents/0xmy_agent_id/readiness')
    })

    it('should return expected transaction count of 2', () => {
      const agent = createMockAgent()
      const ext = generateOnboardingExtension(agent, 'testnet')

      expect(ext.fundingProfile.expectedTransactions).toBe(2)
    })
  })
})
