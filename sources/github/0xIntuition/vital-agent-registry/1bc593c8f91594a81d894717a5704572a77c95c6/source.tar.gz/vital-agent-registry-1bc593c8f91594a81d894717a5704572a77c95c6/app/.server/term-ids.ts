import { readFileSync } from 'node:fs'
import { join } from 'node:path'

type TermIdMap = Record<string, `0x${string}`>

let _map: TermIdMap | undefined

function loadTermIdMap(): TermIdMap {
  if (_map) return _map

  const candidates = [
    join(process.cwd(), 'term-id-map.json'),
    join(process.cwd(), '..', '..', 'apps', 'agent-registry', 'term-id-map.json'),
  ]

  for (const candidate of candidates) {
    try {
      _map = JSON.parse(readFileSync(candidate, 'utf-8')) as TermIdMap
      return _map
    } catch {
      // try next candidate
    }
  }

  throw new Error(
    'term-id-map.json not found. Run bootstrap first:\n' +
    '  tsx scripts/bootstrap.ts --network=local'
  )
}

export function getPredicates() {
  const map = loadTermIdMap()
  return {
    IS:             map['is'],
    HAS_CAPABILITY: map['has-capability'],
    USES:           map['uses'],
    HAS_METADATA:   map['has-metadata'],
    CREATED_BY:     map['created-by'],
  } as const
}

export function getTypeAtoms() {
  const map = loadTermIdMap()
  return {
    AGENT_TYPE: map['Agent'],
    SKILL_TYPE: map['Skill'],
  } as const
}
