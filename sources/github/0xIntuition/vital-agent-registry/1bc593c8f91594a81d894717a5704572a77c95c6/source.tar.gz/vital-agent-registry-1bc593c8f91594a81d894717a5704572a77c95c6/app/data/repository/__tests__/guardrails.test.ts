import { describe, it } from 'vitest'
import { performance } from 'node:perf_hooks'
import type { Vault } from '~/types'
import { MockRegistryRepository } from '../mock-repository'
import { MOCK_AGENTS } from '../../agents'
import { MOCK_SKILLS } from '../../skills'
import { CAPABILITIES } from '../../capabilities'
import { PREDICATES } from '../../predicates'
import { PLATFORMS } from '../../platforms'
import { computeTrustSignalBatch } from '~/lib/trust'

function getMockData() {
  return {
    agents: MOCK_AGENTS,
    skills: MOCK_SKILLS,
    capabilities: CAPABILITIES,
    predicates: PREDICATES,
    platforms: PLATFORMS,
  }
}

function percentile95(values: number[]): number {
  const sorted = [...values].sort((a, b) => a - b)
  const index = Math.min(sorted.length - 1, Math.ceil(sorted.length * 0.95) - 1)
  return sorted[index]
}

async function benchmarkP95(
  label: string,
  iterations: number,
  targetMs: number,
  fn: () => Promise<void> | void,
) {
  const samples: number[] = []
  for (let i = 0; i < iterations; i += 1) {
    const start = performance.now()
    await fn()
    samples.push(performance.now() - start)
  }
  const p95 = percentile95(samples)
  if (p95 >= targetMs) {
    throw new Error(
      `${label} exceeded P95 target: p95=${p95.toFixed(2)}ms target=${targetMs}ms samples=${samples
        .map((value) => value.toFixed(2))
        .join(',')}`,
    )
  }
}

function createDeterministicVault(index: number): Vault {
  const one = 10n ** 18n
  const assets = BigInt((index + 1) * 10) * one
  const shares = BigInt((index + 1) * 5) * one
  const price = shares > 0n ? (assets * one) / shares : one
  return {
    term_id: `0xvault_${index.toString().padStart(4, '0')}`,
    curve_id: '0xcurve_linear',
    total_shares: shares.toString(),
    current_share_price: price.toString(),
    total_assets: assets.toString(),
    market_cap: assets.toString(),
    position_count: (index % 97) + 1,
  }
}

describe('Repository Performance Guardrails', () => {
  it('P95 list/search/scoring/evidence stay within guardrails', async () => {
    const repo = new MockRegistryRepository(getMockData())
    const vaults = Array.from({ length: 500 }, (_, i) => createDeterministicVault(i))

    await benchmarkP95('listAgents(limit=100)', 7, 250, async () => {
      await repo.listAgents({ limit: 100 })
    })

    await benchmarkP95('searchAgents(query=agent)', 7, 200, async () => {
      await repo.searchAgents('agent')
    })

    await benchmarkP95('trust scoring (500 vaults)', 7, 50, () => {
      computeTrustSignalBatch(vaults)
    })

    await benchmarkP95('evidence path getSkillsForAgent', 7, 150, async () => {
      const agents = await repo.listAgents({ limit: 1 })
      if (agents.items.length === 0) return
      await repo.getSkillsForAgent(agents.items[0].id)
    })
  })
})
