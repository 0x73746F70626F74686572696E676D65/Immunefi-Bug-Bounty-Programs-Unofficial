import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const mocks = vi.hoisted(() => ({
  requireExecuteAuth: vi.fn(),
  getLocalWriteContext: vi.fn(),
  createLocalWriteClients: vi.fn(),
  depositToTerm: vi.fn(),
}))

vi.mock('~/.server/execute-auth', () => ({
  requireExecuteAuth: mocks.requireExecuteAuth,
}))

vi.mock('~/.server/local-write', () => ({
  getLocalWriteContext: mocks.getLocalWriteContext,
  createLocalWriteClients: mocks.createLocalWriteClients,
}))

vi.mock('~/.server/multivault', () => ({
  depositToTerm: mocks.depositToTerm,
}))

vi.mock('viem', () => ({
  parseEther: vi.fn((v: string) => BigInt(Math.round(parseFloat(v) * 1e18))),
}))

const TERM_ID = '0x1111111111111111111111111111111111111111111111111111111111111111'

describe('POST /api/v1/trust/stake', () => {
  const baseEnv = { ...process.env }

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = { ...baseEnv, CHAIN: 'testnet' }
  })

  afterEach(() => {
    process.env = { ...baseEnv }
  })

  function createStakeRequest(body: unknown, extraHeaders: Record<string, string> = {}) {
    return new Request('http://localhost:4101/api/v1/trust/stake', {
      method: 'POST',
      headers: { 'content-type': 'application/json', ...extraHeaders },
      body: JSON.stringify(body),
    })
  }

  it('should return 401 without API key', async () => {
    mocks.requireExecuteAuth.mockReturnValue({
      authorized: false,
      response: Response.json(
        { error: 'Invalid or missing API key', code: 'UNAUTHORIZED' },
        { status: 401 },
      ),
    })

    const { action } = await import('../api+/v1.trust.stake')
    const response = await action({
      request: createStakeRequest({ termId: TERM_ID, amountEth: '0.01' }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(401)
    const body = await response.json()
    expect(body.code).toBe('UNAUTHORIZED')
  })

  it('should return 503 when REGISTRY_API_KEY not configured', async () => {
    mocks.requireExecuteAuth.mockReturnValue({
      authorized: false,
      response: Response.json(
        { error: 'Server-side execution not configured', code: 'EXECUTE_NOT_CONFIGURED' },
        { status: 503 },
      ),
    })

    const { action } = await import('../api+/v1.trust.stake')
    const response = await action({
      request: createStakeRequest({ termId: TERM_ID, amountEth: '0.01' }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(503)
    const body = await response.json()
    expect(body.code).toBe('EXECUTE_NOT_CONFIGURED')
  })

  it('should return 400 for invalid body (missing termId)', async () => {
    mocks.requireExecuteAuth.mockReturnValue({ authorized: true })

    const { action } = await import('../api+/v1.trust.stake')
    const response = await action({
      request: createStakeRequest({ amountEth: '0.01' }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(400)
    const body = await response.json()
    expect(body.code).toBe('VALIDATION_ERROR')
  })

  it('should return 400 for missing amount (no amountWei or amountEth)', async () => {
    mocks.requireExecuteAuth.mockReturnValue({ authorized: true })

    const { action } = await import('../api+/v1.trust.stake')
    const response = await action({
      request: createStakeRequest({ termId: TERM_ID }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(400)
    const body = await response.json()
    expect(body.code).toBe('VALIDATION_ERROR')
  })

  it('should successfully stake with valid input', async () => {
    mocks.requireExecuteAuth.mockReturnValue({ authorized: true })
    mocks.getLocalWriteContext.mockReturnValue({
      contractAddress: '0xcontract',
      rpcUrl: 'http://localhost:8545',
    })
    mocks.createLocalWriteClients.mockResolvedValue({
      publicClient: {
        waitForTransactionReceipt: vi.fn().mockResolvedValue({ logs: [] }),
      },
      walletClient: {
        account: { address: '0xwalletaddress' },
      },
    })
    mocks.depositToTerm.mockResolvedValue({
      hash: '0xstakehash',
      curveId: 0n,
      assets: 10000000000000000n,
    })

    const { action } = await import('../api+/v1.trust.stake')
    const response = await action({
      request: createStakeRequest(
        { termId: TERM_ID, amountEth: '0.01', direction: 'for' },
        { 'x-api-key': 'test-key' },
      ),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.executed).toBe(true)
    expect(body.data.mode).toBe('local')
    expect(body.data.txHash).toBe('0xstakehash')
    expect(body.data.termId).toBe(TERM_ID)
    expect(body.data.direction).toBe('for')
  })
})
