import { describe, it, expect } from 'vitest'
import type { Vault } from '~/types'
import { MockRegistryRepository } from '../mock-repository'
import { MOCK_AGENTS } from '../../agents'
import { MOCK_SKILLS } from '../../skills'
import { CAPABILITIES } from '../../capabilities'
import { PREDICATES } from '../../predicates'
import { PLATFORMS } from '../../platforms'
import { computeTrustSignalBatch } from '~/lib/trust'

/**
 * Helper to create mock data for testing
 */
function getMockData() {
  return {
    agents: MOCK_AGENTS,
    skills: MOCK_SKILLS,
    capabilities: CAPABILITIES,
    predicates: PREDICATES,
    platforms: PLATFORMS,
  }
}

/**
 * Helper to create a mock vault for performance testing
 */
function createMockVault(index: number): Vault {
  const ONE = 10n ** 18n
  const assets = BigInt(Math.floor(Math.random() * 1000)) * ONE
  const shares = BigInt(Math.floor(Math.random() * 500)) * ONE
  const price = shares > 0n ? (assets * ONE) / shares : ONE

  return {
    term_id: `0xvault_${index.toString().padStart(3, '0')}`,
    curve_id: '0xcurve_linear',
    total_shares: shares.toString(),
    current_share_price: price.toString(),
    total_assets: assets.toString(),
    market_cap: assets.toString(),
    position_count: Math.floor(Math.random() * 100),
  }
}

/**
 * Performance benchmarks for RegistryRepository implementation.
 *
 * These tests validate that performance requirements are met:
 * - PERF-04: Listing < 500ms for 100 agents
 * - PERF-05: Trust computation < 50ms for 500 agents
 * - PERF-06: Search < 200ms
 *
 * Note: Performance tests use mock repository. GraphQL performance
 * is tested separately when connected to testnet.
 */
describe('Performance Benchmarks', () => {
  describe('PERF-04: List operations', () => {
    it('should list 100 agents in < 500ms', async () => {
      const repo = new MockRegistryRepository(getMockData())
      const start = performance.now()
      await repo.listAgents({ limit: 100 })
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(500)
    })

    it('should list 100 skills in < 500ms', async () => {
      const repo = new MockRegistryRepository(getMockData())
      const start = performance.now()
      await repo.listSkills({ limit: 100 })
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(500)
    })

    it('should handle pagination efficiently', async () => {
      const repo = new MockRegistryRepository(getMockData())
      const start = performance.now()

      // Simulate paginating through 100 items (5 pages of 20)
      for (let i = 0; i < 5; i++) {
        await repo.listAgents({ limit: 20, offset: i * 20 })
      }

      const elapsed = performance.now() - start
      // Should complete 5 paginated calls in under 500ms total
      expect(elapsed).toBeLessThan(500)
    })
  })

  describe('PERF-05: Trust computation', () => {
    it('should compute trust for 500 vaults in < 50ms', () => {
      // Create 500 mock vaults with random data
      const vaults = Array.from({ length: 500 }, (_, i) => createMockVault(i))

      const start = performance.now()

      // Batch compute — O(n log n) via sort-once percentile maps
      const signals = computeTrustSignalBatch(vaults)

      const elapsed = performance.now() - start

      // O(n log n) batch computation — well within PERF-05 50ms target
      expect(elapsed).toBeLessThan(50)
      expect(signals.length).toBe(500)
    })

    it('should compute trust for 1000 vaults in < 100ms', () => {
      // Extended performance test with 1000 vaults
      const vaults = Array.from({ length: 1000 }, (_, i) => createMockVault(i))

      const start = performance.now()

      const signals = computeTrustSignalBatch(vaults)

      const elapsed = performance.now() - start

      // O(n log n) — comfortable headroom at 1000 vaults
      expect(elapsed).toBeLessThan(100)
      expect(signals.length).toBe(1000)
    })

    it('should handle percentile calculation efficiently', () => {
      // Test specific percentile calculation performance
      const vaults = Array.from({ length: 500 }, (_, i) => createMockVault(i))

      const start = performance.now()

      const signals = computeTrustSignalBatch(vaults)

      const elapsed = performance.now() - start

      // O(n log n) — 50ms budget per PERF-05
      expect(elapsed).toBeLessThan(50)
      expect(signals.length).toBe(500)
      expect(signals.every(s => s.percentile >= 0 && s.percentile <= 100)).toBe(true)
    })
  })

  describe('PERF-06: Search operations', () => {
    it('should search agents in < 200ms', async () => {
      const repo = new MockRegistryRepository(getMockData())
      const start = performance.now()
      await repo.searchAgents('agent')
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(200)
    })

    it('should search skills in < 200ms', async () => {
      const repo = new MockRegistryRepository(getMockData())
      const start = performance.now()
      await repo.searchSkills('skill')
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(200)
    })

    it('should handle complex search with filters in < 200ms', async () => {
      const repo = new MockRegistryRepository(getMockData())
      const capabilities = await repo.listCapabilities()
      const capId = capabilities[0].id

      const start = performance.now()
      await repo.searchAgents('agent', {
        capabilities: [capId],
        minTrustTier: 'bronze',
        sortBy: 'trust',
        limit: 20,
      })
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(200)
    })

    it('should handle case-insensitive search efficiently', async () => {
      const repo = new MockRegistryRepository(getMockData())

      const start = performance.now()

      // Perform multiple searches with different cases
      await repo.searchAgents('agent')
      await repo.searchAgents('AGENT')
      await repo.searchAgents('AgEnT')

      const elapsed = performance.now() - start

      // All three searches should complete quickly
      expect(elapsed).toBeLessThan(200)
    })
  })

  describe('PERF-07: Filtering operations', () => {
    it('should filter by capability in < 100ms', async () => {
      const repo = new MockRegistryRepository(getMockData())
      const capabilities = await repo.listCapabilities()
      const capId = capabilities[0].id

      const start = performance.now()
      await repo.listAgents({ capability: capId, limit: 50 })
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(100)
    })

    it('should filter by trust tier in < 100ms', async () => {
      const repo = new MockRegistryRepository(getMockData())

      const start = performance.now()
      await repo.listAgents({ trustTier: 'gold', limit: 50 })
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(100)
    })

    it('should filter skills by platform in < 100ms', async () => {
      const repo = new MockRegistryRepository(getMockData())
      const platforms = await repo.listPlatforms()
      const platformId = platforms[0].id

      const start = performance.now()
      await repo.listSkills({ platformId, limit: 50 })
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(100)
    })
  })

  describe('PERF-08: Sorting operations', () => {
    it('should sort by trust in < 100ms', async () => {
      const repo = new MockRegistryRepository(getMockData())

      const start = performance.now()
      await repo.listAgents({ sortBy: 'trust', limit: 50 })
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(100)
    })

    it('should sort by name in < 100ms', async () => {
      const repo = new MockRegistryRepository(getMockData())

      const start = performance.now()
      await repo.listAgents({ sortBy: 'name', limit: 50 })
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(100)
    })

    it('should sort by stakers in < 100ms', async () => {
      const repo = new MockRegistryRepository(getMockData())

      const start = performance.now()
      await repo.listAgents({ sortBy: 'stakers', limit: 50 })
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(100)
    })

    it('should sort skills by safety in < 100ms', async () => {
      const repo = new MockRegistryRepository(getMockData())

      const start = performance.now()
      await repo.listSkills({ sortBy: 'safety', limit: 50 })
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(100)
    })
  })

  describe('PERF-09: Capability matching', () => {
    it('should match capabilities (AND) in < 150ms', async () => {
      const repo = new MockRegistryRepository(getMockData())
      const capabilities = await repo.listCapabilities()
      const required = capabilities.slice(0, 3).map(c => c.id)

      const start = performance.now()
      await repo.matchAgentCapabilities(required, { matchAll: true })
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(150)
    })

    it('should match capabilities (OR) in < 150ms', async () => {
      const repo = new MockRegistryRepository(getMockData())
      const capabilities = await repo.listCapabilities()
      const required = capabilities.slice(0, 5).map(c => c.id)

      const start = performance.now()
      await repo.matchAgentCapabilities(required, { matchAll: false })
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(150)
    })
  })

  describe('PERF-10: Relationship queries', () => {
    it('should get skills for agent in < 100ms', async () => {
      const repo = new MockRegistryRepository(getMockData())
      const agents = await repo.listAgents({ limit: 1 })
      if (agents.items.length === 0) return

      const start = performance.now()
      await repo.getSkillsForAgent(agents.items[0].id)
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(100)
    })

    it('should get skills by platform in < 100ms', async () => {
      const repo = new MockRegistryRepository(getMockData())
      const platforms = await repo.listPlatforms()

      const start = performance.now()
      await repo.getSkillsByPlatform(platforms[0].id)
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(100)
    })
  })

  describe('PERF-11: Metadata queries', () => {
    it('should list capabilities in < 50ms', async () => {
      const repo = new MockRegistryRepository(getMockData())

      const start = performance.now()
      await repo.listCapabilities()
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(50)
    })

    it('should list platforms in < 50ms', async () => {
      const repo = new MockRegistryRepository(getMockData())

      const start = performance.now()
      await repo.listPlatforms()
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(50)
    })

    it('should list predicates in < 50ms', async () => {
      const repo = new MockRegistryRepository(getMockData())

      const start = performance.now()
      await repo.listPredicates()
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(50)
    })
  })

  describe('PERF-12: Trust signal queries', () => {
    it('should get agent trust in < 50ms', async () => {
      const repo = new MockRegistryRepository(getMockData())
      const agents = await repo.listAgents({ limit: 1 })
      if (agents.items.length === 0) return

      const start = performance.now()
      await repo.getAgentTrust(agents.items[0].id)
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(50)
    })

    it('should get skill trust in < 50ms', async () => {
      const repo = new MockRegistryRepository(getMockData())
      const skills = await repo.listSkills({ limit: 1 })
      if (skills.items.length === 0) return

      const start = performance.now()
      await repo.getSkillTrust(skills.items[0].id)
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(50)
    })

    it('should get agent card in < 50ms', async () => {
      const repo = new MockRegistryRepository(getMockData())
      const agents = await repo.listAgents({ limit: 1 })
      if (agents.items.length === 0) return

      const start = performance.now()
      await repo.getAgentCard(agents.items[0].id)
      const elapsed = performance.now() - start

      expect(elapsed).toBeLessThan(50)
    })
  })

  describe('PERF-13: Stress tests', () => {
    it('should handle 10 concurrent list requests efficiently', async () => {
      const repo = new MockRegistryRepository(getMockData())

      const start = performance.now()

      // Simulate 10 concurrent requests
      await Promise.all([
        repo.listAgents({ limit: 20 }),
        repo.listAgents({ limit: 20, offset: 20 }),
        repo.listAgents({ sortBy: 'trust', limit: 20 }),
        repo.listAgents({ sortBy: 'name', limit: 20 }),
        repo.listSkills({ limit: 20 }),
        repo.listSkills({ sortBy: 'safety', limit: 20 }),
        repo.searchAgents('agent'),
        repo.searchSkills('skill'),
        repo.listCapabilities(),
        repo.listPlatforms(),
      ])

      const elapsed = performance.now() - start

      // All 10 concurrent operations should complete quickly
      expect(elapsed).toBeLessThan(500)
    })

    it('should handle sequential pagination of entire dataset efficiently', async () => {
      const repo = new MockRegistryRepository(getMockData())
      const pageSize = 20

      const start = performance.now()

      let offset = 0
      let hasMore = true
      let pageCount = 0

      // Paginate through all agents
      while (hasMore && pageCount < 10) {
        const result = await repo.listAgents({ limit: pageSize, offset })
        hasMore = result.hasMore
        offset += pageSize
        pageCount++
      }

      const elapsed = performance.now() - start

      // Should be able to paginate through 200 items (10 pages) quickly
      expect(elapsed).toBeLessThan(500)
    })
  })
})
