import type { TrustTier } from './vault'

export type SecurityLevel =
  | 'verified'
  | 'partially-verified'
  | 'unverified'
  | 'flagged'

export interface SecurityAttestation {
  attestor: string
  attestorLabel: string
  attestorTrustTier: TrustTier
  subject: string
  type: 'attests-safe' | 'flagged-as-malicious' | 'audited-by' | 'sandboxed-by'
  confidence: number
  evidence?: string
  createdAt: string
  expiresAt?: string
}

export interface SecurityProfile {
  score: number
  level: SecurityLevel
  attestations: SecurityAttestation[]
  positiveCount: number
  negativeCount: number
  hasCounterAttestations: boolean
  lastAttestationAt?: string
}
