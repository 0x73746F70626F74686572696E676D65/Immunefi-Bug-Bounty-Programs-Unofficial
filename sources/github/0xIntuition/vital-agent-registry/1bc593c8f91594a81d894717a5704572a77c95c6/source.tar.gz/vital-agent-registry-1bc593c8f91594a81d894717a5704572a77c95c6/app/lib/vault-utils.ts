import type { Vault } from '~/types'

/**
 * Sanitize a numeric string from GraphQL/PostgreSQL into a valid BigInt string.
 * PostgreSQL `numeric` type may return decimal strings (e.g., "1000000000000000000.000000").
 * Wei values are always whole numbers, so we truncate the decimal portion.
 */
export function sanitizeWeiString(value: string | null | undefined): string {
  if (!value) return '0'
  const dotIndex = value.indexOf('.')
  const intPart = dotIndex >= 0 ? value.slice(0, dotIndex) : value
  return intPart || '0'
}

/**
 * Format a wei-denominated BigInt string to ETH display string.
 * Only call this at display boundaries, never in computation.
 *
 * Uses string-based BigInt conversion to avoid precision loss above 2^53 wei.
 * Safe for all vault amounts.
 *
 * @param weiString - BigInt string in wei units
 * @param decimals - Number of decimal places to show (default: 4)
 * @returns Formatted ETH string with trailing zeros stripped
 *
 * @example
 * formatWeiToEth('1000000000000000000') // '1'
 * formatWeiToEth('1234567890123456789', 6) // '1.234568'
 * formatWeiToEth('0') // '0'
 */
export function formatWeiToEth(weiString: string, decimals = 4): string {
  if (!weiString || weiString === '0') return '0'
  const wei = BigInt(sanitizeWeiString(weiString))
  const ETH_DECIMALS = 18n
  const divisor = 10n ** ETH_DECIMALS
  const intPart = wei / divisor
  const fracPart = wei % divisor
  if (fracPart === 0n) return intPart.toString()
  // Pad fractional part to 18 chars, then truncate to requested decimals
  const fracStr = fracPart.toString().padStart(Number(ETH_DECIMALS), '0').slice(0, decimals)
  // Strip trailing zeros
  const trimmed = fracStr.replace(/0+$/, '')
  return trimmed ? `${intPart}.${trimmed}` : intPart.toString()
}

/**
 * Parse an ETH number to wei BigInt string.
 * Used for creating mock data from human-readable ETH values.
 *
 * @param ethAmount - ETH amount as a number
 * @returns BigInt string in wei units
 *
 * @example
 * parseEthToWei(1) // '1000000000000000000'
 * parseEthToWei(0.5) // '500000000000000000'
 * parseEthToWei(0) // '0'
 */
export function parseEthToWei(ethAmount: number): string {
  return BigInt(Math.floor(ethAmount * 1e18)).toString()
}

/** Default share price for empty vaults (1 ETH in wei) */
export const DEFAULT_SHARE_PRICE = '1000000000000000000'

/**
 * Guard against empty vault — returns default share price when total_shares is 0.
 * Prevents division by zero and ensures meaningful trust signals for new entities.
 *
 * @param vault - Vault to check
 * @returns Share price in wei (BigInt string), defaults to 1 ETH if vault is empty
 *
 * @example
 * safeSharePrice({ ...vault, total_shares: '0' }) // '1000000000000000000' (1 ETH)
 * safeSharePrice({ ...vault, total_shares: '1000', current_share_price: '1500...' }) // '1500...'
 */
export function safeSharePrice(vault: Vault): string {
  if (!vault.total_shares || vault.total_shares === '0') {
    return DEFAULT_SHARE_PRICE
  }
  return vault.current_share_price
}

/**
 * Create a Vault object from human-readable inputs.
 * Handles all BigInt conversion internally.
 *
 * @param termId - The atom/triple term_id this vault belongs to
 * @param stakerCount - Number of unique stakers
 * @param tvlEth - Total value locked in ETH (human-readable number)
 * @returns Vault object with all BigInt fields as strings
 *
 * @example
 * createVault('0xabc...', 100, 50)
 * // Returns vault with 50 ETH TVL, 100 stakers, 0.5 ETH per share
 */
export function createVault(
  termId: string,
  stakerCount: number,
  tvlEth: number,
): Vault {
  const totalAssets = BigInt(Math.floor(tvlEth * 1e18))
  const totalShares = stakerCount > 0
    ? BigInt(stakerCount) * 10n ** 18n
    : 0n
  const sharePrice = totalShares > 0n
    ? (totalAssets * 10n ** 18n) / totalShares
    : 10n ** 18n

  return {
    term_id: termId,
    curve_id: '0xcurve_linear',
    total_shares: totalShares.toString(),
    current_share_price: sharePrice.toString(),
    total_assets: totalAssets.toString(),
    market_cap: totalAssets.toString(),
    position_count: stakerCount,
  }
}

/**
 * Create a vault for a skill with separate FOR and AGAINST economics.
 * The vault's total_assets represents the combined FOR + AGAINST stake.
 *
 * @param termId - The skill atom's term_id
 * @param forCount - Stakers attesting FOR (safe)
 * @param againstCount - Stakers attesting AGAINST (flagged)
 * @param forEth - Total ETH staked FOR
 * @param againstEth - Total ETH staked AGAINST
 * @returns Vault object representing combined FOR + AGAINST economics
 *
 * @example
 * createSkillVault('0xdef...', 80, 20, 40, 10)
 * // Returns vault with 50 ETH total TVL, 100 total stakers
 */
export function createSkillVault(
  termId: string,
  forCount: number,
  againstCount: number,
  forEth: number,
  againstEth: number,
): Vault {
  const totalEth = forEth + againstEth
  const totalStakers = forCount + againstCount
  return createVault(termId, totalStakers, totalEth)
}

/**
 * Compare two BigInt-string values.
 * Returns negative if a < b, zero if equal, positive if a > b.
 *
 * @param a - First BigInt string
 * @param b - Second BigInt string
 * @returns -1 if a < b, 0 if equal, 1 if a > b
 *
 * @example
 * compareBigIntStrings('100', '200') // -1
 * compareBigIntStrings('200', '200') // 0
 * compareBigIntStrings('300', '200') // 1
 */
export function compareBigIntStrings(a: string, b: string): number {
  const bigA = BigInt(sanitizeWeiString(a))
  const bigB = BigInt(sanitizeWeiString(b))
  if (bigA < bigB) return -1
  if (bigA > bigB) return 1
  return 0
}

const BPS_SCALE = 10_000n

/**
 * Compute a basis-point fee amount for a wei-denominated value.
 *
 * Uses integer math only.
 */
export function computeFeeBps(amountWei: string, feeBps: bigint): string {
  const amount = BigInt(sanitizeWeiString(amountWei))
  if (amount <= 0n || feeBps <= 0n) return '0'
  return ((amount * feeBps) / BPS_SCALE).toString()
}

/**
 * Apply entry fee and return net amount + fee.
 */
export function applyEntryFeeBps(amountWei: string, feeBps: bigint): {
  grossWei: string
  feeWei: string
  netWei: string
} {
  const gross = BigInt(sanitizeWeiString(amountWei))
  const fee = BigInt(computeFeeBps(amountWei, feeBps))
  const net = gross - fee
  return {
    grossWei: gross.toString(),
    feeWei: fee.toString(),
    netWei: (net >= 0n ? net : 0n).toString(),
  }
}

/**
 * Apply exit fee and return payout + fee.
 */
export function applyExitFeeBps(amountWei: string, feeBps: bigint): {
  grossWei: string
  feeWei: string
  payoutWei: string
} {
  const gross = BigInt(sanitizeWeiString(amountWei))
  const fee = BigInt(computeFeeBps(amountWei, feeBps))
  const payout = gross - fee
  return {
    grossWei: gross.toString(),
    feeWei: fee.toString(),
    payoutWei: (payout >= 0n ? payout : 0n).toString(),
  }
}
