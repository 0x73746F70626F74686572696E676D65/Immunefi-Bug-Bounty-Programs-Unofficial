/**
 * Indexer polling utilities with exponential backoff.
 *
 * After creating an atom on-chain, there's a delay before the indexer processes
 * the event and makes the atom queryable. These utilities provide robust polling
 * with exponential backoff to wait for indexer synchronization.
 *
 * @module indexer-poll
 */

/**
 * Configuration options for polling operations.
 */
export interface PollOptions {
  /**
   * Initial delay in milliseconds before the first retry.
   * @default 2000
   */
  initialDelayMs?: number;

  /**
   * Maximum delay in milliseconds between retries.
   * @default 30000
   */
  maxDelayMs?: number;

  /**
   * Maximum number of retry attempts before giving up.
   * @default 10
   */
  maxRetries?: number;

  /**
   * Optional callback invoked after each polling attempt.
   * Receives the current attempt number (1-indexed).
   */
  onProgress?: (attempt: number) => void;
}

/**
 * Default polling configuration.
 */
const DEFAULT_POLL_OPTIONS: Required<Omit<PollOptions, 'onProgress'>> = {
  initialDelayMs: 2000,
  maxDelayMs: 30000,
  maxRetries: 10,
};

/**
 * Delays execution for the specified number of milliseconds.
 *
 * @param ms - Milliseconds to delay
 * @returns Promise that resolves after the delay
 */
function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Calculates the delay for a given attempt using exponential backoff.
 *
 * Formula: `min(initialDelay * 2^attempt, maxDelay)`
 *
 * @param attempt - The current attempt number (0-indexed)
 * @param initialDelayMs - Initial delay in milliseconds
 * @param maxDelayMs - Maximum delay in milliseconds
 * @returns Delay in milliseconds for this attempt
 *
 * @example
 * ```typescript
 * calculateBackoffDelay(0, 2000, 30000);  // 2000ms
 * calculateBackoffDelay(1, 2000, 30000);  // 4000ms
 * calculateBackoffDelay(2, 2000, 30000);  // 8000ms
 * calculateBackoffDelay(5, 2000, 30000);  // 30000ms (capped)
 * ```
 */
function calculateBackoffDelay(
  attempt: number,
  initialDelayMs: number,
  maxDelayMs: number
): number {
  const exponentialDelay = initialDelayMs * Math.pow(2, attempt);
  return Math.min(exponentialDelay, maxDelayMs);
}

/**
 * Polls for an atom in the indexer with exponential backoff.
 *
 * Repeatedly checks if an atom with the given term_id exists in the indexer,
 * waiting with exponentially increasing delays between attempts. Returns true
 * if found, false if max retries exceeded.
 *
 * The checkFn parameter allows the caller to provide their own checking logic
 * (e.g., GraphQL query, REST API call) without coupling this module to specific
 * data access patterns.
 *
 * @param termId - The term_id of the atom to poll for
 * @param checkFn - Async function that returns true if the atom exists
 * @param options - Polling configuration options
 * @returns Promise resolving to true if found, false if timed out
 *
 * @example
 * ```typescript
 * // With GraphQL
 * const found = await pollForAtom(
 *   "0x1234...",
 *   async (id) => {
 *     const result = await graphql(query, { termId: id });
 *     return result.atom !== null;
 *   },
 *   {
 *     maxRetries: 15,
 *     onProgress: (attempt) => console.log(`Attempt ${attempt}...`)
 *   }
 * );
 *
 * if (found) {
 *   console.log("Atom indexed!");
 * } else {
 *   console.log("Timeout waiting for indexer");
 * }
 * ```
 */
export async function pollForAtom(
  termId: string,
  checkFn: (termId: string) => Promise<boolean>,
  options?: PollOptions
): Promise<boolean> {
  const {
    initialDelayMs = DEFAULT_POLL_OPTIONS.initialDelayMs,
    maxDelayMs = DEFAULT_POLL_OPTIONS.maxDelayMs,
    maxRetries = DEFAULT_POLL_OPTIONS.maxRetries,
    onProgress,
  } = options ?? {};

  // Initial check (attempt 0) - no delay
  onProgress?.(1);
  if (await checkFn(termId)) {
    return true;
  }

  // Retry with exponential backoff
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    const delayMs = calculateBackoffDelay(attempt, initialDelayMs, maxDelayMs);
    await delay(delayMs);

    onProgress?.(attempt + 2); // +2 because attempt 1 was the initial check

    if (await checkFn(termId)) {
      return true;
    }
  }

  // Max retries exceeded
  return false;
}
