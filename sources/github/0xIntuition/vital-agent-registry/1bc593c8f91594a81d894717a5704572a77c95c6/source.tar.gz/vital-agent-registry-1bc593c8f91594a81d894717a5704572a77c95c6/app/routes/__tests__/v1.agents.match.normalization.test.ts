import { beforeEach, describe, expect, it, vi } from 'vitest'
import type { ActionFunctionArgs } from 'react-router'

const matchAgentCapabilities = vi.fn()

vi.mock('~/data/repository/provider', () => ({
  createRepository: () => ({
    matchAgentCapabilities,
  }),
}))

function makeArgs(body: unknown): ActionFunctionArgs {
  return {
    request: new Request('https://registry.local/api/v1/agents/match', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    }),
    params: {},
    context: {},
  } as ActionFunctionArgs
}

describe('v1.agents.match capability normalization', () => {
  beforeEach(() => {
    matchAgentCapabilities.mockReset()
    matchAgentCapabilities.mockResolvedValue([])
  })

  it('normalizes required and preferred capabilities before repository query', async () => {
    const { action } = await import('../api+/v1.agents.match')

    const response = await action(makeArgs({
      requiredCapabilities: [' Code Review ', 'CODEGEN', 'code-review'],
      preferredCapabilities: ['web_search', 'Web Search'],
      matchAll: false,
      limit: 5,
    }))

    expect(response.status).toBe(200)
    expect(matchAgentCapabilities).toHaveBeenCalledWith(
      ['code-review', 'code-generation'],
      expect.objectContaining({
        matchAll: false,
        limit: 5,
      }),
    )
  })

  it('ranks by match score then trust when sort_by is default', async () => {
    matchAgentCapabilities.mockResolvedValueOnce([
      {
        id: 'agent-high-trust',
        capabilities: [{ id: 'code-review' }],
        trustSignal: { percentile: 95, stakerCount: 10 },
      },
      {
        id: 'agent-better-match',
        capabilities: [{ id: 'code-review' }, { id: 'web-search' }],
        trustSignal: { percentile: 10, stakerCount: 1 },
      },
    ])

    const { action } = await import('../api+/v1.agents.match')
    const response = await action(makeArgs({
      requiredCapabilities: ['code-review'],
      preferredCapabilities: ['web-search'],
      matchAll: false,
    }))

    expect(response.status).toBe(200)
    const payload = await response.json()
    expect(payload.data[0].id).toBe('agent-better-match')
    expect(payload.data[0].matchScore).toBeGreaterThan(payload.data[1].matchScore)
  })

  it('supports trust sorting when sortBy=trust is set', async () => {
    matchAgentCapabilities.mockResolvedValueOnce([
      {
        id: 'agent-mid-trust',
        capabilities: [{ id: 'code-review' }, { id: 'web-search' }],
        trustSignal: { percentile: 70, stakerCount: 10 },
      },
      {
        id: 'agent-top-trust',
        capabilities: [{ id: 'code-review' }],
        trustSignal: { percentile: 99, stakerCount: 2 },
      },
    ])

    const { action } = await import('../api+/v1.agents.match')
    const response = await action(makeArgs({
      requiredCapabilities: ['code-review'],
      preferredCapabilities: ['web-search'],
      sortBy: 'trust',
    }))

    expect(response.status).toBe(200)
    const payload = await response.json()
    expect(payload.data[0].id).toBe('agent-top-trust')
    expect(payload.data[0].trustSignal.percentile).toBeGreaterThan(
      payload.data[1].trustSignal.percentile,
    )
  })
})
