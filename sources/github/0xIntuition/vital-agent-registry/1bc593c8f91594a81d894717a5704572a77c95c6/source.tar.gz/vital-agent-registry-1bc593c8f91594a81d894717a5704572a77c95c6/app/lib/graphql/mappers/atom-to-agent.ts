import type { Agent, AgentMetadata, Capability, Triple, TripleVaultData, Vault, TrustSignal } from '~/types'
import { computeTrustSignal } from '~/lib/trust'
import { sanitizeWeiString } from '~/lib/vault-utils'
import type { GraphQLAtom } from './types'

/**
 * Map a GraphQL atom response to an Agent entity.
 * Extracts capabilities and skills from triples, builds vault and trust signal.
 *
 * @param atom - GraphQL atom response
 * @param allVaults - Array of all agent vaults for trust percentile calculation
 * @returns Agent entity
 */
export function mapAtomToAgent(atom: GraphQLAtom, allVaults: Vault[]): Agent {
  // Extract metadata from atom.value.thing or fallback to atom fields
  const metadata = extractAgentMetadata(atom)

  // Extract capabilities from has-capability triples
  const capabilities = extractCapabilities(atom)

  // Build vault from atom.term.vaults (curve_id 1 is FOR vault)
  const vault = extractVault(atom)

  // Compute trust signal
  const trustSignal = vault ? computeTrustSignal(vault, allVaults) : getEmptyTrustSignal()

  // Extract triples where this agent is subject
  const triples = extractTriples(atom)

  return {
    id: atom.term_id,
    metadata,
    capabilities,
    vault: vault ?? getEmptyVault(atom.term_id),
    trustSignal,
    triples,
  }
}

/**
 * Extract agent metadata from GraphQL atom.
 * Tries atom.value.thing first, then atom.data (JSON), then falls back to label.
 */
function extractAgentMetadata(atom: GraphQLAtom): AgentMetadata {
  const thing = atom.value?.thing
  const jsonObject = atom.value?.json_object

  // Try to parse JSON from data field if it exists
  let parsedData: Record<string, unknown> | null = null
  if (atom.data) {
    try {
      parsedData = JSON.parse(atom.data)
    } catch {
      // Ignore parse errors, use fallback values
    }
  }

  const name = thing?.name || jsonObject?.name || (parsedData?.name as string) || atom.label

  // Find has-metadata triple for richer metadata (description, version, etc.)
  const metadataTriple = atom.as_subject_triples?.find(
    (t) => t.predicate.label === 'has-metadata',
  )
  const metadataObj = metadataTriple?.object
  const metadataJsonObj = metadataObj?.value?.json_object
  let metadataParsed: Record<string, unknown> | null = null
  if (metadataObj?.data) {
    try {
      metadataParsed = JSON.parse(metadataObj.data)
    } catch {
      // IPFS URI or non-JSON data, ignore
    }
  }

  const description =
    thing?.description ||
    metadataJsonObj?.description ||
    jsonObject?.description ||
    (metadataParsed?.description as string) ||
    (parsedData?.description as string) ||
    ''
  const image = thing?.image || atom.cached_image?.url || atom.image || undefined
  const version = (metadataParsed?.version as string) || (parsedData?.version as string) || '1.0.0'
  const model = (metadataParsed?.model as string) || (parsedData?.model as string) || undefined
  const endpoint = (metadataParsed?.endpoint as string) || (parsedData?.endpoint as string) || undefined
  const metadataUriCandidate =
    (parsedData?.metadataUri as string) ||
    (parsedData?.metadata_uri as string) ||
    (typeof thing?.url === 'string' && thing.url.startsWith('ipfs://') ? thing.url : undefined) ||
    (typeof atom.label === 'string' && atom.label.startsWith('ipfs://') ? atom.label : undefined)
  const tags = (parsedData?.tags as string[]) || []

  const provider = parsedData?.provider
    ? {
        name: (parsedData.provider as Record<string, unknown>).name as string,
        url: (parsedData.provider as Record<string, unknown>).url as string | undefined,
      }
    : undefined

  return {
    name,
    description,
    longDescription: (parsedData?.longDescription as string) || undefined,
    image,
    version,
    model,
    endpoint,
    metadataUri: metadataUriCandidate,
    provider,
    tags,
    createdAt: atom.created_at || new Date().toISOString(),
    lastActiveAt: atom.updated_at || undefined,
  }
}

/**
 * Extract capabilities from has-capability triples.
 */
function extractCapabilities(atom: GraphQLAtom): Capability[] {
  if (!atom.as_subject_triples) return []

  return atom.as_subject_triples
    .filter((triple) => triple.predicate.label === 'has-capability')
    .map((triple) => {
      const obj = triple.object
      const objData = obj.data ? tryParseJSON(obj.data) : null
      return {
        id: obj.term_id,
        name: obj.value?.thing?.name || obj.value?.json_object?.name || obj.label,
        category: (objData?.category as string) || 'automation',
        description: obj.value?.thing?.description || obj.value?.json_object?.description || (objData?.description as string) || '',
      }
    })
}

/**
 * Extract vault from atom.term.vaults.
 * Returns the first vault with curve_id 1 (FOR vault), or the first vault if no curve_id 1.
 */
function extractVault(atom: GraphQLAtom): Vault | null {
  const vaults = atom.term?.vaults
  if (!vaults || vaults.length === 0) return null

  // Prefer curve_id 1 (FOR vault), otherwise take first
  const vault = vaults.find((v) => v.curve_id === '1') || vaults[0]

  return {
    term_id: vault.term_id,
    curve_id: vault.curve_id,
    total_shares: sanitizeWeiString(vault.total_shares),
    current_share_price: sanitizeWeiString(vault.current_share_price),
    total_assets: sanitizeWeiString(vault.total_assets),
    market_cap: sanitizeWeiString(vault.market_cap),
    position_count: vault.position_count ?? 0,
  }
}

/**
 * Extract triples where this atom is subject.
 */
function extractTriples(atom: GraphQLAtom): Triple[] {
  if (!atom.as_subject_triples) return []

  return atom.as_subject_triples.map((triple) => {
    const vaults = triple.term?.vaults
    let vault: TripleVaultData | undefined
    if (vaults && vaults.length > 0) {
      const forV = vaults.find((v) => v.curve_id === '0') || vaults[0]
      const againstV = vaults.find((v) => v.curve_id === '1')
      vault = {
        forVault: {
          total_assets: sanitizeWeiString(forV.total_assets),
          position_count: forV.position_count ?? 0,
          current_share_price: sanitizeWeiString(forV.current_share_price),
        },
        againstVault: againstV
          ? {
              total_assets: sanitizeWeiString(againstV.total_assets),
              position_count: againstV.position_count ?? 0,
              current_share_price: sanitizeWeiString(againstV.current_share_price),
            }
          : undefined,
      }
    }

    return {
      term_id: triple.term_id,
      counter_term_id: triple.counter_term_id || '',
      subject: {
        term_id: atom.term_id,
        label: atom.label,
        image: atom.cached_image?.url || atom.image || undefined,
        type: 'Agent',
      },
      predicate: {
        term_id: triple.predicate.term_id,
        label: triple.predicate.label,
        type: 'Unknown',
      },
      object: {
        term_id: triple.object.term_id,
        label: triple.object.value?.thing?.name || triple.object.value?.json_object?.name || triple.object.label,
        image: triple.object.cached_image?.url || triple.object.image || undefined,
        type: (triple.object.type as any) || 'Unknown',
      },
      created_at: atom.created_at || new Date().toISOString(),
      creator_id: atom.creator?.id || '',
      vault,
    }
  })
}

/**
 * Try to parse JSON, return null on failure.
 */
function tryParseJSON(json: string): Record<string, unknown> | null {
  try {
    return JSON.parse(json)
  } catch {
    return null
  }
}

/**
 * Empty trust signal for agents with no vault data.
 */
function getEmptyTrustSignal(): TrustSignal {
  return {
    stakerCount: 0,
    totalStaked: '0',
    sharePrice: '1',
    tier: 'unranked',
    percentile: 0,
    marketCap: '0',
  }
}

/**
 * Empty vault placeholder for agents with no vault.
 */
function getEmptyVault(termId: string): Vault {
  return {
    term_id: termId,
    curve_id: '1',
    total_shares: '0',
    current_share_price: '1000000000000000000',
    total_assets: '0',
    market_cap: '0',
    position_count: 0,
  }
}
