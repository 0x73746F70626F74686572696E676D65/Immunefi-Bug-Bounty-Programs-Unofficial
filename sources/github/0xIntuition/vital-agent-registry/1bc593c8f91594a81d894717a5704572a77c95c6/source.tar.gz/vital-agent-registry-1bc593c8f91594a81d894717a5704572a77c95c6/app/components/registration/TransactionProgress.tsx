export type StepStatus = 'pending' | 'in_progress' | 'confirmed' | 'failed' | 'rejected'

export interface TransactionStep {
  label: string
  description: string
  status: StepStatus
  txHash?: string
  error?: string
}

interface TransactionProgressProps {
  steps: TransactionStep[]
  onRetry?: (stepIndex: number) => void
}

const STATUS_PREFIX: Record<StepStatus, string> = {
  pending: '[ ]',
  in_progress: '[*]',
  confirmed: '[✓]',
  failed: '[✗]',
  rejected: '[✗]',
}

export function TransactionProgress({ steps, onRetry }: TransactionProgressProps) {
  return (
    <div
      className="font-mono text-sm space-y-3"
      role="region"
      aria-label="Transaction progress"
    >
      {steps.map((step, index) => {
        const prefix = STATUS_PREFIX[step.status]
        const isActive = step.status === 'in_progress'
        const isSuccess = step.status === 'confirmed'
        const isError = step.status === 'failed' || step.status === 'rejected'

        return (
          <div key={index} aria-current={isActive ? 'step' : undefined}>
            <div className="flex items-center gap-2">
              <span
                className={
                  isActive ? 'text-[hsl(var(--accent))]'
                  : isSuccess ? 'text-gain'
                  : isError ? 'text-loss'
                  : 'text-ink-faint'
                }
              >
                {prefix}
              </span>
              <span
                className={`uppercase tracking-[0.1em] text-xs font-bold ${
                  isActive ? 'text-[hsl(var(--accent))] animate-pulse'
                  : isSuccess ? 'text-gain'
                  : isError ? 'text-loss'
                  : 'text-ink-faint'
                }`}
              >
                {step.label}
              </span>
              {isActive && (
                <span className="text-ink-faint animate-pulse">...</span>
              )}
              {isSuccess && step.txHash && (
                <a
                  href={`https://basescan.org/tx/${step.txHash}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[hsl(var(--accent))] hover:underline text-[10px] tracking-wider"
                >
                  [VIEW TX]
                </a>
              )}
              {isError && onRetry && (
                <button
                  type="button"
                  onClick={() => onRetry(index)}
                  className="text-[hsl(var(--accent))] hover:underline text-[10px] tracking-wider cursor-pointer"
                  aria-label={`Retry ${step.label}`}
                >
                  [RETRY]
                </button>
              )}
            </div>
            <div className="ml-6 text-[10px] text-ink-faint tracking-wide">
              {step.description}
            </div>
            {isError && step.error && (
              <div className="ml-6 text-[10px] text-loss mt-0.5 tracking-wide" role="alert">
                ERROR: {step.error}
              </div>
            )}
          </div>
        )
      })}

      {/* Screen reader announcements */}
      <div className="sr-only" role="status" aria-live="polite" aria-atomic="true">
        {steps.find(s => s.status === 'in_progress') && (
          <span>Currently processing: {steps.find(s => s.status === 'in_progress')?.label}</span>
        )}
        {steps.find(s => s.status === 'confirmed') && (
          <span>Completed: {steps.find(s => s.status === 'confirmed')?.label}</span>
        )}
        {steps.find(s => s.status === 'failed' || s.status === 'rejected') && (
          <span>Error in: {steps.find(s => s.status === 'failed' || s.status === 'rejected')?.label}</span>
        )}
      </div>
    </div>
  )
}
