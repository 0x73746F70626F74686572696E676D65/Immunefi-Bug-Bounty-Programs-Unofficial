import type { PublicClient, WalletClient, Hash } from 'viem';
import type { AgentMetadata, SkillMetadataPayload } from '~/lib/schemas';
import { uploadAgentMetadata, uploadSkillMetadata } from './ipfs';
import { createAtoms, createTriples } from './multivault';

/**
 * Result of a complete entity registration (both steps).
 */
export interface RegistrationResult {
  /** IPFS URI of the uploaded metadata */
  ipfsUri: string;
  /** Transaction hash from atom creation */
  atomHash: Hash;
  /** Term ID of the created atom (known after indexer confirms) */
  atomTermId: string;
  /** Transaction hash from triple creation */
  tripleHash: Hash;
  /** Number of triples created */
  tripleCount: number;
}

/**
 * Result of step 1: metadata upload and atom creation.
 */
export interface Step1Result {
  /** IPFS URI of the uploaded metadata */
  ipfsUri: string;
  /** Transaction hash from atom creation */
  atomHash: Hash;
}

/**
 * Result of step 2: relationship triples creation.
 */
export interface Step2Result {
  /** Transaction hash from triple creation */
  tripleHash: Hash;
  /** Number of triples created */
  tripleCount: number;
}

/**
 * Step 1: Upload metadata to IPFS and create the entity atom.
 *
 * This is the first signature required from the user.
 * After this step, you must wait for the indexer to confirm the atom creation
 * and provide the atomTermId before proceeding to step 2.
 *
 * @param publicClient - For reading contract state
 * @param walletClient - For signing/sending transaction
 * @param contractAddress - MultiVault contract address
 * @param metadata - Agent or Skill metadata object
 * @param depositAmount - Amount (in wei) to deposit into the atom's vault
 * @returns IPFS URI and transaction hash
 *
 * @example
 * ```typescript
 * const { ipfsUri, atomHash } = await registerEntityStep1(
 *   publicClient,
 *   walletClient,
 *   CONTRACTS.MULTIVAULT_TESTNET,
 *   { "@type": "Agent", name: "MyAgent", ... },
 *   parseEther("0.1")
 * );
 * // Wait for indexer to confirm atomHash
 * // Then query indexer for atomTermId
 * ```
 */
export async function registerEntityStep1(
  publicClient: PublicClient,
  walletClient: WalletClient,
  contractAddress: `0x${string}`,
  metadata: AgentMetadata | SkillMetadataPayload,
  depositAmount: bigint
): Promise<Step1Result> {
  // Upload metadata to IPFS (includes Zod validation - SEC-06)
  const ipfsUri =
    metadata['@type'] === 'Agent'
      ? await uploadAgentMetadata(metadata)
      : await uploadSkillMetadata(metadata);

  // Create atom with IPFS URI
  const { hash: atomHash } = await createAtoms(
    publicClient,
    walletClient,
    contractAddress,
    [ipfsUri],
    depositAmount
  );

  return {
    ipfsUri,
    atomHash,
  };
}

/**
 * Step 2: Create all relationship triples for the entity.
 *
 * This is the second signature required from the user.
 * This step creates all the semantic relationships (triples) that describe
 * the entity's capabilities, skills, type, etc.
 *
 * For an Agent:
 * - Agent IS_TYPE Agent (typeAtomId)
 * - Agent HAS_CAPABILITY Capability1
 * - Agent HAS_CAPABILITY Capability2
 * - Agent USES_SKILL Skill1
 * - Agent USES_SKILL Skill2
 *
 * For a Skill:
 * - Skill IS_TYPE Skill (typeAtomId)
 * - Skill PROVIDES_CAPABILITY Capability1
 * - Skill BELONGS_TO Platform
 *
 * @param publicClient - For reading contract state
 * @param walletClient - For signing/sending transaction
 * @param contractAddress - MultiVault contract address
 * @param entityTermId - Term ID of the entity atom (from step 1 + indexer)
 * @param entityType - Whether this is an 'Agent' or 'Skill'
 * @param relationships - All relationship data needed for triples
 * @param depositPerTriple - Amount (in wei) to deposit into each triple's vault
 * @returns Transaction hash and triple count
 *
 * @example
 * ```typescript
 * const { tripleHash, tripleCount } = await registerEntityStep2(
 *   publicClient,
 *   walletClient,
 *   CONTRACTS.MULTIVAULT_TESTNET,
 *   "123456",  // atomTermId from indexer
 *   "Agent",
 *   {
 *     typeAtomId: PREDICATES.AGENT_TYPE,
 *     capabilities: ["cap1_term_id", "cap2_term_id"],
 *     skills: ["skill1_term_id"],
 *   },
 *   parseEther("0.05")
 * );
 * console.log(`Created ${tripleCount} triples`);
 * ```
 */
export async function registerEntityStep2(
  publicClient: PublicClient,
  walletClient: WalletClient,
  contractAddress: `0x${string}`,
  entityTermId: string,
  entityType: 'Agent' | 'Skill',
  relationships: {
    capabilities?: string[]; // Term IDs of capability atoms
    skills?: string[]; // Term IDs of skill atoms (for agents)
    typeAtomId: string; // Term ID of Agent or Skill type atom
    platformId?: string; // Term ID of platform atom (for skills)
  },
  depositPerTriple: bigint
): Promise<Step2Result> {
  const triples: Array<{ subjectId: string; predicateId: string; objectId: string }> = [];

  // Get predicate IDs from constants
  // Note: These will be populated by the bootstrap script
  // For now they are placeholders
  const { PREDICATES } = await import('~/lib/constants/protocol');

  // Add IS triple (every entity has type: [Entity] is [Agent/Skill])
  triples.push({
    subjectId: entityTermId,
    predicateId: PREDICATES.IS,
    objectId: relationships.typeAtomId,
  });

  // Add capability triples (both agents and skills use has-capability)
  if (relationships.capabilities && relationships.capabilities.length > 0) {
    for (const capabilityId of relationships.capabilities) {
      triples.push({
        subjectId: entityTermId,
        predicateId: PREDICATES.HAS_CAPABILITY,
        objectId: capabilityId,
      });
    }
  }

  // Add skill/tool triples (agents only)
  if (entityType === 'Agent' && relationships.skills && relationships.skills.length > 0) {
    for (const skillId of relationships.skills) {
      triples.push({
        subjectId: entityTermId,
        predicateId: PREDICATES.USES,
        objectId: skillId,
      });
    }
  }

  // v3: Platform info moved to metadata (skill installUri), no BELONGS_TO in graph

  // Create all triples in one transaction
  const { hash: tripleHash, tripleCount } = await createTriples(
    publicClient,
    walletClient,
    contractAddress,
    triples,
    depositPerTriple
  );

  return {
    tripleHash,
    tripleCount,
  };
}
