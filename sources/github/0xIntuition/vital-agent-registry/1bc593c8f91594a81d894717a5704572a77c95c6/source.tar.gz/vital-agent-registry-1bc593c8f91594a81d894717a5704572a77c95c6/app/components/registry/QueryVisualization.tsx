import { useState } from 'react'
import type { TrustTier, SafetyStatus } from '~/types'
import type { SortField } from '~/types/repository'
import { Copy, Check } from 'lucide-react'

interface QueryVisualizationProps {
  entityType: 'all' | 'agents' | 'skills'
  searchQuery: string
  filters: {
    capability: string | null
    trustTier: TrustTier | null
    platformId: string | null
    safetyStatus: SafetyStatus | null
  }
  sortBy: SortField
  resultCount: number
}

/**
 * QueryVisualization — Shows the equivalent API query for current filter state
 *
 * Updates in real-time as filters change. Provides a "view as API call" perspective
 * for agent consumers of the registry.
 */
export function QueryVisualization({
  entityType,
  searchQuery,
  filters,
  sortBy,
  resultCount,
}: QueryVisualizationProps) {
  const [copied, setCopied] = useState(false)

  // Build query params based on active filters
  const buildQueryParams = (forEntity: 'agents' | 'skills') => {
    const params: string[] = []

    // Search query
    if (searchQuery.trim()) {
      params.push(`q=${encodeURIComponent(searchQuery)}`)
    }

    // Capability filter
    if (filters.capability) {
      params.push(`capability=${filters.capability}`)
    }

    // Trust tier filter
    if (filters.trustTier) {
      params.push(`trustTier=${filters.trustTier}`)
    }

    // Platform filter (skills only)
    if (forEntity === 'skills' && filters.platformId) {
      params.push(`platformId=${filters.platformId}`)
    }

    // Safety status filter (skills only)
    if (forEntity === 'skills' && filters.safetyStatus) {
      params.push(`safetyStatus=${filters.safetyStatus}`)
    }

    // Sort
    params.push(`sort=${sortBy}`)

    return params.join('&')
  }

  // Build curl commands
  const buildCurlCommand = (forEntity: 'agents' | 'skills') => {
    const queryParams = buildQueryParams(forEntity)
    const url = `/api/v1/${forEntity}${queryParams ? `?${queryParams}` : ''}`
    return `curl -X GET "https://registry.intuition.systems${url}"`
  }

  // Determine which endpoints to show
  const showAgents = entityType === 'all' || entityType === 'agents'
  const showSkills = entityType === 'all' || entityType === 'skills'

  const agentQuery = showAgents ? buildQueryParams('agents') : null
  const skillQuery = showSkills ? buildQueryParams('skills') : null

  // Copy all queries to clipboard
  const handleCopy = async () => {
    const commands: string[] = []
    if (showAgents) commands.push(buildCurlCommand('agents'))
    if (showSkills) commands.push(buildCurlCommand('skills'))

    try {
      await navigator.clipboard.writeText(commands.join('\n\n'))
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error('Failed to copy:', err)
    }
  }

  return (
    <div className="border border-[hsl(142_71%_45%/0.3)] bg-[hsl(0_0%_5%)] font-mono text-sm">
      {/* Header bar */}
      <div className="flex items-center justify-between border-b border-[hsl(142_71%_45%/0.3)] px-4 py-2 bg-[hsl(0_0%_8%)]">
        <span className="text-[hsl(142_71%_45%)] font-bold">API QUERY</span>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 text-xs text-[hsl(142_71%_45%)] hover:text-[hsl(142_71%_60%)] transition-colors"
          title="Copy curl command"
        >
          {copied ? (
            <>
              <Check className="w-3 h-3" />
              <span>COPIED</span>
            </>
          ) : (
            <>
              <Copy className="w-3 h-3" />
              <span>COPY</span>
            </>
          )}
        </button>
      </div>

      {/* Query display */}
      <div className="p-4 space-y-4">
        {showAgents && (
          <div className="space-y-1">
            <div className="flex flex-wrap items-baseline gap-1">
              <span className="text-[hsl(50_100%_50%)]">GET</span>
              <span className="text-[hsl(142_71%_60%)]">/api/v1/agents</span>
              {agentQuery && (
                <>
                  <span className="text-[hsl(142_71%_45%)]">?</span>
                  <span className="text-[hsl(200_100%_70%)]">{agentQuery}</span>
                </>
              )}
            </div>
            {entityType === 'agents' && (
              <div className="text-[hsl(142_71%_45%/0.7)] text-xs">
                // =&gt; {resultCount} results
              </div>
            )}
          </div>
        )}

        {showSkills && (
          <div className="space-y-1">
            <div className="flex flex-wrap items-baseline gap-1">
              <span className="text-[hsl(50_100%_50%)]">GET</span>
              <span className="text-[hsl(142_71%_60%)]">/api/v1/skills</span>
              {skillQuery && (
                <>
                  <span className="text-[hsl(142_71%_45%)]">?</span>
                  <span className="text-[hsl(200_100%_70%)]">{skillQuery}</span>
                </>
              )}
            </div>
            {entityType === 'skills' && (
              <div className="text-[hsl(142_71%_45%/0.7)] text-xs">
                // =&gt; {resultCount} results
              </div>
            )}
          </div>
        )}

        {entityType === 'all' && (
          <div className="text-[hsl(142_71%_45%/0.7)] text-xs">
            // =&gt; {resultCount} total results
          </div>
        )}
      </div>
    </div>
  )
}
