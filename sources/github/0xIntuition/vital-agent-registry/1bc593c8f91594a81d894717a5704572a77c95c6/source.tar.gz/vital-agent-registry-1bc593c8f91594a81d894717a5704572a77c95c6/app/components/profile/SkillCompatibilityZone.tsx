import { useState, useEffect } from 'react'
import { Link } from 'react-router'
import * as Collapsible from '@radix-ui/react-collapsible'
import type { Skill } from '~/types'
import { cn } from '~/lib/utils'
import { PlatformBadge } from '../registry/PlatformBadge'
import { useRepository } from '~/data'

interface SkillCompatibilityZoneProps {
  skill: Skill
  className?: string
}

export function SkillCompatibilityZone({ skill, className }: SkillCompatibilityZoneProps) {
  const { platform, triples } = skill
  const [isOpen, setIsOpen] = useState(true)
  const [dependencies, setDependencies] = useState<Skill[]>([])
  const [versions, setVersions] = useState<Skill[]>([])
  const repository = useRepository()

  useEffect(() => {
    // Find dependencies (depends-on triples)
    const fetchDependencies = async () => {
      try {
        const dependsOnTriples = triples.filter(
          (t) => t.predicate.label === 'depends-on' && t.object.type === 'Skill',
        )
        const depIds = dependsOnTriples.map((t) => t.object.term_id)
        const deps = await Promise.all(
          depIds.map((id) => repository.findSkill(id)),
        )
        setDependencies(deps.filter(Boolean) as Skill[])
      } catch (error) {
        console.error('Failed to fetch dependencies:', error)
      }
    }

    // Find version history (is-version-of triples)
    const fetchVersions = async () => {
      try {
        const versionTriples = triples.filter(
          (t) => t.predicate.label === 'is-version-of' && t.object.type === 'Skill',
        )
        const versionIds = versionTriples.map((t) => t.object.term_id)
        const vers = await Promise.all(
          versionIds.map((id) => repository.findSkill(id)),
        )
        setVersions(vers.filter(Boolean) as Skill[])
      } catch (error) {
        console.error('Failed to fetch versions:', error)
      }
    }

    fetchDependencies()
    fetchVersions()
  }, [skill.id, triples, repository])

  // Extract additional platforms from triples (compatible-with predicate)
  const additionalPlatforms = triples
    .filter((t) => t.predicate.label === 'compatible-with' && t.object.type === 'Platform')
    .map((t) => t.object)

  return (
    <div className={cn('rounded-lg border border-border bg-card p-6', className)}>
      <Collapsible.Root open={isOpen} onOpenChange={setIsOpen}>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-card-foreground">Compatibility</h2>
          <Collapsible.Trigger asChild>
            <button
              type="button"
              className="text-muted-foreground hover:text-foreground transition-colors"
              aria-label={isOpen ? 'Collapse' : 'Expand'}
            >
              <svg
                className={cn('w-5 h-5 transition-transform', isOpen && 'rotate-180')}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M19 9l-7 7-7-7"
                />
              </svg>
            </button>
          </Collapsible.Trigger>
        </div>

        <Collapsible.Content>
          <div className="space-y-6">
            {/* Platform Compatibility */}
            <div>
              <h3 className="text-sm font-medium text-card-foreground mb-3">
                Platform Support
              </h3>
              <div className="flex flex-wrap gap-2">
                <PlatformBadge platform={platform} size="md" />
                {additionalPlatforms.map((plat) => (
                  <span
                    key={plat.term_id}
                    className="px-2 py-1 text-xs rounded bg-muted text-muted-foreground"
                  >
                    {plat.label}
                  </span>
                ))}
              </div>
            </div>

            {/* Dependencies */}
            {dependencies.length > 0 && (
              <div>
                <h3 className="text-sm font-medium text-card-foreground mb-3">
                  Dependencies
                  <span className="ml-2 text-xs text-muted-foreground font-normal">
                    ({dependencies.length})
                  </span>
                </h3>
                <div className="space-y-2">
                  {dependencies.map((dep) => (
                    <Link
                      key={dep.id}
                      to={`/skills/${dep.id}`}
                      className="block p-3 rounded-lg bg-muted/50 border border-border hover:bg-muted transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-card-foreground">
                            {dep.metadata.name}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            v{dep.metadata.version}
                          </div>
                        </div>
                        <PlatformBadge platform={dep.platform} size="sm" />
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* Version History */}
            {versions.length > 0 && (
              <div>
                <h3 className="text-sm font-medium text-card-foreground mb-3">
                  Version History
                </h3>
                <div className="space-y-2">
                  {versions.map((ver) => (
                    <Link
                      key={ver.id}
                      to={`/skills/${ver.id}`}
                      className="block p-3 rounded-lg bg-muted/50 border border-border hover:bg-muted transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-card-foreground">
                            {ver.metadata.name}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            v{ver.metadata.version} · {new Date(ver.metadata.createdAt).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* Empty State */}
            {dependencies.length === 0 && versions.length === 0 && (
              <div className="text-sm text-muted-foreground">
                No additional compatibility information available.
              </div>
            )}
          </div>
        </Collapsible.Content>
      </Collapsible.Root>
    </div>
  )
}
