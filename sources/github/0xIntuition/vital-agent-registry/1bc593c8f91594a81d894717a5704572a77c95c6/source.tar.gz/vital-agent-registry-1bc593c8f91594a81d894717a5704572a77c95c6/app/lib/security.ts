import type { SecurityLevel } from '~/types'

export function getSecurityLevelLabel(level: SecurityLevel): string {
  const labels: Record<SecurityLevel, string> = {
    verified: 'Verified',
    'partially-verified': 'Partially Verified',
    unverified: 'Unverified',
    flagged: 'Flagged',
  }
  return labels[level]
}

export function getSecurityLevelBadgeColors(level: SecurityLevel): string {
  const colors: Record<SecurityLevel, string> = {
    verified: 'border-[hsl(142_71%_45%/0.5)] bg-[hsl(142_71%_45%/0.1)] text-[hsl(142_71%_45%)]',
    'partially-verified': 'border-[hsl(38_92%_50%/0.5)] bg-[hsl(38_92%_50%/0.1)] text-[hsl(38_92%_50%)]',
    unverified: 'border-[hsl(0_0%_60%/0.5)] bg-[hsl(0_0%_60%/0.1)] text-[hsl(0_0%_60%)]',
    flagged: 'border-[hsl(0_84%_60%/0.5)] bg-[hsl(0_84%_60%/0.1)] text-[hsl(0_84%_60%)]',
  }
  return colors[level]
}
