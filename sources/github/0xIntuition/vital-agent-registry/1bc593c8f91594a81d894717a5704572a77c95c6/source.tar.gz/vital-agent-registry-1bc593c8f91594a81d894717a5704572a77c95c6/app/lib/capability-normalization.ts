const ALIAS_MAP: Record<string, string> = {
  codegen: 'code-generation',
  codereview: 'code-review',
  websearch: 'web-search',
}

function normalizeToken(value: string): string {
  return value
    .trim()
    .toLowerCase()
    .replace(/[_\s]+/g, '-')
    .replace(/[^a-z0-9-]/g, '')
}

export function normalizeCapabilityId(value: string): string {
  const normalized = normalizeToken(value)
  return ALIAS_MAP[normalized] ?? normalized
}

export function normalizeCapabilityIds(values: string[]): string[] {
  const normalized = values
    .map((value) => normalizeCapabilityId(value))
    .filter((value) => value.length > 0)
  return [...new Set(normalized)]
}
