import { createContext, useContext, useState, useCallback } from 'react'
import type { ReactNode } from 'react'

/**
 * Skill card style controls which data presentation the SkillCard uses:
 * - claim: FOR/AGAINST bar (current Portal-inspired design)
 * - score: Computed category scores as badges (like agent domain scores)
 * - adoption: Focus on usage metrics (stakers, ETH, platform)
 */
export type SkillCardStyle = 'claim' | 'score' | 'adoption'

interface SkillCardStyleContextValue {
  style: SkillCardStyle
  setStyle: (style: SkillCardStyle) => void
  cycleStyle: () => void
}

const SkillCardStyleContext = createContext<SkillCardStyleContextValue | null>(null)

const STORAGE_KEY = 'agent-registry-skill-card-style'
const DEFAULT_STYLE: SkillCardStyle = 'claim'

const CYCLE_ORDER: SkillCardStyle[] = ['claim', 'score', 'adoption']

function getInitialStyle(): SkillCardStyle {
  if (typeof window === 'undefined') return DEFAULT_STYLE
  const stored = localStorage.getItem(STORAGE_KEY)
  if (stored === 'claim' || stored === 'score' || stored === 'adoption') {
    return stored
  }
  return DEFAULT_STYLE
}

export function SkillCardStyleProvider({ children }: { children: ReactNode }) {
  const [style, setStyleState] = useState<SkillCardStyle>(getInitialStyle)

  const setStyle = useCallback((next: SkillCardStyle) => {
    setStyleState(next)
    localStorage.setItem(STORAGE_KEY, next)
  }, [])

  const cycleStyle = useCallback(() => {
    setStyleState((prev) => {
      const idx = CYCLE_ORDER.indexOf(prev)
      const next = CYCLE_ORDER[(idx + 1) % CYCLE_ORDER.length]
      localStorage.setItem(STORAGE_KEY, next)
      return next
    })
  }, [])

  return (
    <SkillCardStyleContext.Provider value={{ style, setStyle, cycleStyle }}>
      {children}
    </SkillCardStyleContext.Provider>
  )
}

export function useSkillCardStyle() {
  const ctx = useContext(SkillCardStyleContext)
  if (!ctx) throw new Error('useSkillCardStyle must be used within SkillCardStyleProvider')
  return ctx
}
