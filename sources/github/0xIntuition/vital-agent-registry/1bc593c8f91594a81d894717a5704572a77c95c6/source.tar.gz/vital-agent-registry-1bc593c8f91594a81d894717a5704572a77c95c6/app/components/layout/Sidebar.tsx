import { Link, useLocation } from 'react-router'
import {
  Home,
  Network,
  Plus,
  Bookmark,
  Trophy,
  Terminal,
  Sun,
  Moon,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react'
import { useTheme } from 'next-themes'
import { WalletButton } from '~/components/wallet/WalletButton'
import { cn } from '~/lib/utils'
import { useEffect, useState } from 'react'

interface SidebarProps {
  collapsed: boolean
  onToggle: () => void
}

const NAV_ITEMS = [
  { path: '/', icon: Home, label: 'Home' },
  { path: '/leaderboard', icon: Trophy, label: 'Leaderboard' },
  { path: '/graph', icon: Network, label: 'Graph' },
  { path: '/me', icon: Plus, label: 'Register' },
  { path: '/saved', icon: Bookmark, label: 'Saved' },
] as const

const THEME_OPTIONS = [
  { value: 'light', icon: Sun, label: 'Light' },
  { value: 'dark', icon: Moon, label: 'Dark' },
  { value: 'agent', icon: Terminal, label: 'Agent' },
] as const

export function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const location = useLocation()
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <aside
      aria-label="Main navigation"
      className={cn(
        'fixed left-0 top-0 z-40 flex h-screen flex-col border-r bg-sidebar-box border-sidebar-line transition-[width] duration-300',
        collapsed ? 'w-14' : 'w-56',
      )}
      style={{
        transitionTimingFunction: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
      }}
    >
      {/* Logo area */}
      <div className="flex h-14 items-center border-b border-sidebar-divider px-4">
        <Link
          to="/"
          className="flex items-center gap-2 text-sidebar-ink no-underline"
        >
          <div className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg bg-sidebar-selected font-mono text-xs font-bold text-sidebar-selected-ink">
            i
          </div>
          {!collapsed && (
            <span className="text-sm font-semibold tracking-tight text-sidebar-ink">
              Intuition
            </span>
          )}
        </Link>
      </div>

      {/* Nav section */}
      <nav className="flex-1 space-y-1 px-2 py-3">
        {NAV_ITEMS.map(({ path, icon: Icon, label }) => {
          const isActive =
            path === '/'
              ? location.pathname === '/'
              : location.pathname.startsWith(path)

          return (
            <Link
              key={path}
              to={path}
              aria-current={isActive ? 'page' : undefined}
              className={cn(
                'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium no-underline transition-colors',
                isActive
                  ? cn(
                      'bg-sidebar-selected text-sidebar-selected-ink',
                      !collapsed && 'border-l-2 border-l-[hsl(var(--accent))]',
                    )
                  : 'text-sidebar-ink-dull hover:bg-sidebar-button-hover hover:text-sidebar-ink',
                collapsed && 'justify-center px-0',
              )}
              title={collapsed ? label : undefined}
            >
              <Icon className="h-4 w-4 flex-shrink-0" />
              {!collapsed && <span>{label}</span>}
            </Link>
          )
        })}
      </nav>

      {/* Bottom controls */}
      <div className="space-y-2 border-t border-sidebar-divider px-2 py-3">
        {/* Three-mode theme toggle */}
        {mounted && (
          <div
            className={cn(
              'flex rounded-lg bg-sidebar-button p-0.5',
              collapsed ? 'flex-col' : 'flex-row',
            )}
          >
            {THEME_OPTIONS.map(({ value, icon: Icon, label }) => (
              <button
                key={value}
                type="button"
                onClick={() => setTheme(value)}
                className={cn(
                  'flex items-center justify-center rounded-md px-2 py-1.5 text-xs font-medium transition-colors',
                  theme === value
                    ? 'bg-sidebar-selected text-sidebar-selected-ink'
                    : 'text-sidebar-ink-dull hover:text-sidebar-ink',
                  !collapsed && 'flex-1 gap-1.5',
                  collapsed && 'h-8 w-full',
                )}
                title={label}
              >
                <Icon className="h-3.5 w-3.5 flex-shrink-0" />
                {!collapsed && <span>{label}</span>}
              </button>
            ))}
          </div>
        )}

        {/* Wallet */}
        {!collapsed && (
          <div className="px-1 py-1">
            <WalletButton />
          </div>
        )}

        {/* Collapse toggle */}
        <button
          type="button"
          onClick={onToggle}
          className={cn(
            'flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-sidebar-ink-faint transition-colors hover:bg-sidebar-button-hover hover:text-sidebar-ink',
            collapsed && 'justify-center px-0',
          )}
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? (
            <ChevronRight className="h-4 w-4 flex-shrink-0" />
          ) : (
            <ChevronLeft className="h-4 w-4 flex-shrink-0" />
          )}
          {!collapsed && <span>Collapse</span>}
        </button>
      </div>
    </aside>
  )
}
