import type { ActionFunctionArgs } from 'react-router'
import { handleOptions, parseJsonBody, jsonResponse, errorResponse, corsHeaders } from '~/lib/api/types'
import { registerSkillSchema } from '~/lib/api/validation'
import { uploadSkillMetadata, IpfsUploadError } from '~/.server/ipfs'
import { encodeCreateTriplesCalldata, deriveAtomTermId, deriveIdentityAtomTermId, encodeIdentityAtomData } from '~/lib/calldata'
import { getAtomCost, getTripleCost } from '~/.server/multivault'
import { createPublicClient, http, parseEventLogs } from 'viem'
import { NAMESPACES, getContractAddress, getRpcUrl, getChainConfig } from '~/lib/constants/protocol'
import type { NetworkId } from '~/lib/constants/protocol'
import { getPredicates, getTypeAtoms } from '~/.server/term-ids'
import { requireExecuteAuth } from '~/.server/execute-auth'
import { assertRemoteWriteAllowed, RemoteWriteGuardError } from '~/.server/remote-write-guard'
import { registrationLimiter, getClientIP, isRegistrationRateLimitEnabled } from '~/lib/rate-limit'
import { createLocalWriteClients, getLocalWriteContext } from '~/.server/local-write'
import { createAtoms, createTriples, getAtomByUri, getMinimumDeposit } from '~/.server/multivault'
import { multivaultAbi } from '~/lib/abis/multivault'

function isResolvedTermId(value: string | undefined): value is `0x${string}` {
  return Boolean(value && /^0x[0-9a-fA-F]{64}$/.test(value) && !value.startsWith('0x_placeholder_'))
}

/**
 * POST /api/v1/skills/register
 *
 * v3 Flow (two atoms):
 * 1. Create identity atom with minimal data: { name, namespace }
 * 2. Upload full metadata to IPFS
 * 3. Create metadata atom (from IPFS URI)
 * 4. Create triples:
 *    - has-metadata: identity -> metadata
 *    - is: identity -> Skill type
 *    - has-capability: identity -> capability
 */
export async function action({ request }: ActionFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes
  const url = new URL(request.url)
  const execute = url.searchParams.get('execute') === 'true'

  if (execute) {
    const auth = requireExecuteAuth(request)
    if (!auth.authorized) return auth.response
  }

  // Rate limit check
  if (isRegistrationRateLimitEnabled()) {
    const ip = getClientIP(request)
    const limit = registrationLimiter.check(ip)
    if (!limit.allowed) {
      return new Response(
        JSON.stringify({
          error: 'Too many requests',
          code: 'RATE_LIMITED',
          retryAfter: Math.ceil((limit.resetAt - Date.now()) / 1000),
        }),
        {
          status: 429,
          headers: {
            ...corsHeaders(),
            'Content-Type': 'application/json',
            'Retry-After': String(Math.ceil((limit.resetAt - Date.now()) / 1000)),
          },
        }
      )
    }
  }

  const parsed = await parseJsonBody(request, registerSkillSchema)
  if ('error' in parsed) return parsed.error

  const metadata = parsed.data
  const skillMetadata = {
    '@type': 'Skill' as const,
    ...metadata,
  }

  try {
    const PREDICATES = getPredicates()
    const TYPE_ATOMS = getTypeAtoms()

    if (!execute) {
      assertRemoteWriteAllowed({
        action: 'prepare skill registration',
        target: 'ipfs + chain',
      })
    }

    // v3: Step 1 - Create identity atom data (minimal JSON)
    const identityAtomTermId = deriveIdentityAtomTermId(metadata.name, NAMESPACES.SKILL)

    // v3: Step 2 - Upload full metadata to IPFS
    const metadataIpfsUri = await uploadSkillMetadata(skillMetadata)

    // v3: Step 3 - Create metadata atom term ID (from IPFS URI)
    const metadataAtomTermId = deriveAtomTermId(metadataIpfsUri)

    const chain = (process.env.CHAIN as NetworkId) || 'testnet'
    const contractAddress = getContractAddress(chain)
    const rpcUrl = getRpcUrl(chain)

    const publicClient = createPublicClient({
      transport: http(rpcUrl),
    })

    const atomCost = await getAtomCost(publicClient, contractAddress)
    const minimumDeposit = await getMinimumDeposit(publicClient, contractAddress)

    // v3: Step 4 - Create triples linking identity to metadata and type/capabilities
    const relationshipContext = metadata.relationshipContext ?? {}
    const hasMetadataPredicateTermId =
      relationshipContext.hasMetadataPredicateTermId ?? PREDICATES.HAS_METADATA
    const typePredicateTermId = relationshipContext.typePredicateTermId ?? PREDICATES.IS
    const typeObjectTermId = relationshipContext.typeObjectTermId ?? TYPE_ATOMS.SKILL_TYPE
    const hasCapabilityPredicateTermId =
      relationshipContext.hasCapabilityPredicateTermId ?? PREDICATES.HAS_CAPABILITY

    // v3: All triples relate to the identity atom
    const triples: Array<{ subjectId: `0x${string}`; predicateId: `0x${string}`; objectId: `0x${string}` }> = []

    // has-metadata triple: identity -> metadata atom
    if (isResolvedTermId(hasMetadataPredicateTermId)) {
      triples.push({
        subjectId: identityAtomTermId,
        predicateId: hasMetadataPredicateTermId,
        objectId: metadataAtomTermId,
      })
    }

    // Type triple: identity -> Skill type
    if (isResolvedTermId(typePredicateTermId) && isResolvedTermId(typeObjectTermId)) {
      triples.push({
        subjectId: identityAtomTermId,
        predicateId: typePredicateTermId,
        objectId: typeObjectTermId,
      })
    }

    // Capability triples
    if (isResolvedTermId(hasCapabilityPredicateTermId)) {
      for (const capabilityTermId of relationshipContext.capabilityTermIds ?? []) {
        triples.push({
          subjectId: identityAtomTermId,
          predicateId: hasCapabilityPredicateTermId,
          objectId: capabilityTermId as `0x${string}`,
        })
      }
    }

    // created-by triple: identity -> creator
    const createdByPredicateTermId = relationshipContext.createdByPredicateTermId ?? PREDICATES.CREATED_BY
    const creatorTermId = relationshipContext.creatorTermId
    if (isResolvedTermId(createdByPredicateTermId) && isResolvedTermId(creatorTermId)) {
      triples.push({
        subjectId: identityAtomTermId,
        predicateId: createdByPredicateTermId,
        objectId: creatorTermId,
      })
    }

    if (metadata.requireTwoSignatures && triples.length === 0) {
      return errorResponse(
        'Two-signature flow requires resolvable relationship term ids',
        'RELATIONSHIP_CONTEXT_REQUIRED',
        400,
      )
    }

    // v3: Two atoms in one transaction
    const { toHex, encodeFunctionData } = await import('viem')
    const identityAtomBytes = toHex(encodeIdentityAtomData(metadata.name, NAMESPACES.SKILL))
    const metadataAtomBytes = toHex(metadataIpfsUri)

    const createAtomsCalldata = encodeFunctionData({
      abi: multivaultAbi,
      functionName: 'createAtoms',
      args: [[identityAtomBytes, metadataAtomBytes], [minimumDeposit, minimumDeposit]],
    })

    const hasTripleTx = triples.length > 0
    const tripleCost = hasTripleTx ? await getTripleCost(publicClient, contractAddress) : 0n
    const tripleCalldata = hasTripleTx ? encodeCreateTriplesCalldata(triples, minimumDeposit) : null

    // Per-atom total = creation fee + minimum deposit
    const perAtomTotal = atomCost + minimumDeposit
    // Per-triple total = creation fee + minimum deposit
    const perTripleTotal = tripleCost + minimumDeposit

    const response = {
      // v3: Return both URIs and term IDs
      identityIpfsUri: null, // Identity atom uses inline JSON, not IPFS
      identityAtomTermId,
      metadataIpfsUri,
      metadataAtomTermId,
      calldata: createAtomsCalldata,
      estimatedAtomCost: (perAtomTotal * 2n).toString(), // Two atoms (creation + deposit each)
      estimatedTripleCost: (perTripleTotal * BigInt(triples.length)).toString(),
      contractAddress,
      chainId: getChainConfig(chain).chainId,
      transactions: [
        {
          signatureIndex: 1,
          kind: 'createAtoms',
          atomCount: 2,
          to: contractAddress,
          data: createAtomsCalldata,
          value: (perAtomTotal * 2n).toString(),
        },
        ...(hasTripleTx
          ? [
              {
                signatureIndex: 2,
                kind: 'createTriples',
                to: contractAddress,
                data: tripleCalldata,
                value: (perTripleTotal * BigInt(triples.length)).toString(),
                tripleCount: triples.length,
              },
            ]
          : []),
      ],
      signaturePlan: {
        requiredSignatures: hasTripleTx ? 2 : 1,
        hasTripleTransaction: hasTripleTx,
      },
      indexerConfirmation: {
        identityAtomTermId,
        metadataAtomTermId,
        graphqlUrl: null, // Internal URL -- clients should use /api/graphql proxy
        lagState: 'indexer-lagged',
        timeoutState: 'indexer-timeout',
        polling: {
          maxRetries: 8,
          initialDelayMs: 500,
          maxDelayMs: 5000,
        },
      },
    }

    if (!execute) {
      return jsonResponse(response)
    }

    const context = getLocalWriteContext()
    const { publicClient: localPublicClient, walletClient } = await createLocalWriteClients(context)
    const localMinimumDeposit = await getMinimumDeposit(localPublicClient, context.contractAddress)

    // v3: Check for existing atoms
    const identityAtomDataLocal = encodeIdentityAtomData(metadata.name, NAMESPACES.SKILL)
    const existingIdentityTermId = await getAtomByUri(
      localPublicClient,
      context.contractAddress,
      toHex(identityAtomDataLocal)
    )
    const existingMetadataTermId = await getAtomByUri(
      localPublicClient,
      context.contractAddress,
      metadataIpfsUri
    )

    let atomExecution: { hash: `0x${string}`; atomCount: number; createdTermIds?: `0x${string}`[] } | null = null
    let resolvedIdentityTermId: `0x${string}` | null = existingIdentityTermId
    let resolvedMetadataTermId: `0x${string}` | null = existingMetadataTermId

    if (!existingIdentityTermId || !existingMetadataTermId) {
      const atomsToCreate = []
      if (!existingIdentityTermId) {
        atomsToCreate.push(identityAtomDataLocal)
      } else {
        atomsToCreate.push('')
      }
      if (!existingMetadataTermId) {
        atomsToCreate.push(metadataIpfsUri)
      } else {
        atomsToCreate.push('')
      }

      const newAtomsToCreate = atomsToCreate.filter((a): a is string => a !== '')

      if (newAtomsToCreate.length > 0) {
        atomExecution = await createAtoms(
          localPublicClient,
          walletClient,
          context.contractAddress,
          newAtomsToCreate,
          localMinimumDeposit,
        )
        const atomReceipt = await localPublicClient.waitForTransactionReceipt({ hash: atomExecution.hash })
        const atomCreatedLogs = parseEventLogs({
          abi: multivaultAbi,
          logs: atomReceipt.logs,
          eventName: 'AtomCreated',
        })

        const createdTermIds = atomCreatedLogs.map((log) => log.args?.termId as `0x${string}`)
        let idx = 0
        if (!existingIdentityTermId && createdTermIds[idx]) {
          resolvedIdentityTermId = createdTermIds[idx]
          idx++
        }
        if (!existingMetadataTermId && createdTermIds[idx]) {
          resolvedMetadataTermId = createdTermIds[idx]
        }
      }
    }

    // Fallback: resolve term IDs by URI if not found
    if (!resolvedIdentityTermId) {
      resolvedIdentityTermId = await getAtomByUri(
        localPublicClient,
        context.contractAddress,
        toHex(identityAtomDataLocal)
      )
    }
    if (!resolvedMetadataTermId) {
      resolvedMetadataTermId = await getAtomByUri(
        localPublicClient,
        context.contractAddress,
        metadataIpfsUri
      )
    }

    let tripleExecution: { hash: `0x${string}`; tripleCount: number } | null = null
    // v3: Update triples to use resolved term IDs
    const finalTriples = triples.map((t) => {
      const remapped = { ...t }
      if (remapped.subjectId === identityAtomTermId) {
        remapped.subjectId = resolvedIdentityTermId ?? identityAtomTermId
      }
      if (remapped.objectId === metadataAtomTermId) {
        remapped.objectId = resolvedMetadataTermId ?? metadataAtomTermId
      }
      return remapped
    })

    // Execute mode: derive creator atom from wallet if not provided
    if (isResolvedTermId(createdByPredicateTermId) && !isResolvedTermId(creatorTermId)) {
      const creatorAddress = walletClient.account?.address
      if (creatorAddress) {
        let creatorAtomTermId = await getAtomByUri(
          localPublicClient,
          context.contractAddress,
          creatorAddress,
        )
        if (!creatorAtomTermId) {
          const creatorAtomExecution = await createAtoms(
            localPublicClient,
            walletClient,
            context.contractAddress,
            [creatorAddress],
            localMinimumDeposit,
          )
          await localPublicClient.waitForTransactionReceipt({ hash: creatorAtomExecution.hash })
          creatorAtomTermId = await getAtomByUri(
            localPublicClient,
            context.contractAddress,
            creatorAddress,
          )
        }
        if (creatorAtomTermId) {
          finalTriples.push({
            subjectId: resolvedIdentityTermId ?? identityAtomTermId,
            predicateId: createdByPredicateTermId,
            objectId: creatorAtomTermId,
          })
        }
      }
    }

    if (finalTriples.length > 0) {
      tripleExecution = await createTriples(
        localPublicClient,
        walletClient,
        context.contractAddress,
        finalTriples,
        localMinimumDeposit,
      )
      await localPublicClient.waitForTransactionReceipt({ hash: tripleExecution.hash })
    }

    const finalIdentityTermId = resolvedIdentityTermId ?? identityAtomTermId

    return jsonResponse({
      ...response,
      identityAtomTermId: finalIdentityTermId,
      metadataAtomTermId: resolvedMetadataTermId ?? metadataAtomTermId,
      execution: {
        mode: 'local',
        executed: true,
        account: walletClient.account?.address ?? null,
        atomTxHash: atomExecution?.hash ?? null,
        identityAlreadyExisted: Boolean(existingIdentityTermId),
        metadataAlreadyExisted: Boolean(existingMetadataTermId),
        existingIdentityTermId,
        existingMetadataTermId,
        resolvedIdentityTermId,
        resolvedMetadataTermId,
        tripleTxHash: tripleExecution?.hash ?? null,
      },
    })
  } catch (error) {
    if (error instanceof RemoteWriteGuardError) {
      return errorResponse(
        'Remote writes are blocked by default in local-safe mode',
        error.code,
        403,
        {
          message: error.message,
          requiredOverride: 'ALLOW_REMOTE_WRITES=1 and REGISTRY_WRITE_PROFILE=shared',
          profile: error.profile,
          target: error.target,
          action: error.action,
        }
      )
    }
    if (error instanceof IpfsUploadError) {
      if (error.category === 'validation') {
        return errorResponse('Metadata validation failed', 'VALIDATION_ERROR', 400, {
          category: error.category,
          message: error.message,
        })
      }
      if (error.category === 'upstream') {
        return errorResponse('IPFS upstream failure', 'UPSTREAM_IPFS_ERROR', 502, {
          category: error.category,
          message: error.message,
        })
      }
      return errorResponse('IPFS internal failure', 'INTERNAL_IPFS_ERROR', 500, {
        category: error.category,
        message: error.message,
      })
    }
    return errorResponse('Registration preparation failed', 'INTERNAL_ERROR', 500, {
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
}
