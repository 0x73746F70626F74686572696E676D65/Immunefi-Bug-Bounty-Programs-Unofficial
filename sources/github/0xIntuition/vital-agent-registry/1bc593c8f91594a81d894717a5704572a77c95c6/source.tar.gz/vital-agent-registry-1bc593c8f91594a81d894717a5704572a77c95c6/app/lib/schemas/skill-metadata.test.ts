import { describe, expect, it } from 'vitest';
import { SkillMetadataSchema, SkillPlatform } from './skill-metadata';

describe('SkillMetadataSchema', () => {
  it('validation matrix contains at least 5 valid and 5 invalid payloads', () => {
    const validPayloads = [
      {
        '@type': 'Skill' as const,
        name: 'Skill One',
        description: 'Valid payload 1',
        version: '1.0.0',
        platform: 'mcp' as const,
        installUri: 'mcp://install/one',
      },
      {
        '@type': 'Skill' as const,
        name: 'Skill Two',
        description: 'Valid payload 2',
        version: '1.0.1',
        platform: 'mcp' as const,
        installUri: 'npx @modelcontextprotocol/server-github',
      },
      {
        '@type': 'Skill' as const,
        name: 'Skill Three',
        description: 'Valid payload 3',
        version: '2.0.0',
        platform: 'openai' as const,
        installUri: 'https://example.com/install',
      },
      {
        '@type': 'Skill' as const,
        name: 'Skill Four',
        description: 'Valid payload 4',
        version: '2.1.0',
        platform: 'other' as const,
        installUri: 'npm:@example/skill',
      },
      {
        '@type': 'Skill' as const,
        name: 'Skill Five',
        description: 'Valid payload 5',
        version: '3.0.0',
        platform: 'claude-code' as const,
      },
    ];

    const invalidPayloads = [
      {
        '@type': 'Agent',
        name: 'Skill Bad 1',
        description: 'x',
        version: '1.0.0',
        platform: 'mcp',
      },
      {
        '@type': 'Skill' as const,
        name: '',
        description: 'x',
        version: '1.0.0',
        platform: 'mcp' as const,
      },
      {
        '@type': 'Skill' as const,
        name: 'Skill Bad 3',
        description: 'x',
        version: 'bad-version',
        platform: 'mcp' as const,
      },
      {
        '@type': 'Skill' as const,
        name: 'Skill Bad 4',
        description: 'x',
        version: '1.0.0',
        platform: 'invalid-platform',
      },
      {
        '@type': 'Skill' as const,
        name: 'Skill Bad 5',
        description: 'x',
        version: '1.0.0',
        platform: 'mcp' as const,
        installUri: 'https://example.com/install',
      },
    ];

    expect(validPayloads).toHaveLength(5);
    expect(invalidPayloads).toHaveLength(5);
    expect(validPayloads.every((payload) => SkillMetadataSchema.safeParse(payload).success)).toBe(true);
    expect(invalidPayloads.every((payload) => !SkillMetadataSchema.safeParse(payload).success)).toBe(true);
  });

  it('should validate valid skill metadata', () => {
    const validMetadata = {
      '@type': 'Skill' as const,
      name: 'GitHub Integration',
      description: 'Read and write GitHub issues, PRs, and code',
      version: '2.1.0',
      platform: 'mcp' as const,
    };

    const result = SkillMetadataSchema.safeParse(validMetadata);
    expect(result.success).toBe(true);
  });

  it('should reject invalid @type', () => {
    const invalidMetadata = {
      '@type': 'Agent',
      name: 'Test Skill',
      description: 'A test skill',
      version: '1.0.0',
      platform: 'mcp',
    };

    const result = SkillMetadataSchema.safeParse(invalidMetadata);
    expect(result.success).toBe(false);
  });

  it('should accept all valid platform values', () => {
    const platforms = ['mcp', 'claude-code', 'openclaw', 'openai', 'other'] as const;

    for (const platform of platforms) {
      const metadata = {
        '@type': 'Skill' as const,
        name: 'Test Skill',
        description: 'A test skill',
        version: '1.0.0',
        platform,
      };

      const result = SkillMetadataSchema.safeParse(metadata);
      expect(result.success).toBe(true);
    }
  });

  it('should reject invalid platform values', () => {
    const invalidMetadata = {
      '@type': 'Skill' as const,
      name: 'Test Skill',
      description: 'A test skill',
      version: '1.0.0',
      platform: 'invalid-platform',
    };

    const result = SkillMetadataSchema.safeParse(invalidMetadata);
    expect(result.success).toBe(false);
  });

  it('should reject name that is too long', () => {
    const invalidMetadata = {
      '@type': 'Skill' as const,
      name: 'a'.repeat(101),
      description: 'A test skill',
      version: '1.0.0',
      platform: 'mcp' as const,
    };

    const result = SkillMetadataSchema.safeParse(invalidMetadata);
    expect(result.success).toBe(false);
  });

  it('should reject description that is too long', () => {
    const invalidMetadata = {
      '@type': 'Skill' as const,
      name: 'Test Skill',
      description: 'a'.repeat(501),
      version: '1.0.0',
      platform: 'mcp' as const,
    };

    const result = SkillMetadataSchema.safeParse(invalidMetadata);
    expect(result.success).toBe(false);
  });

  it('should reject invalid semver', () => {
    const invalidMetadata = {
      '@type': 'Skill' as const,
      name: 'Test Skill',
      description: 'A test skill',
      version: 'not-a-version',
      platform: 'mcp' as const,
    };

    const result = SkillMetadataSchema.safeParse(invalidMetadata);
    expect(result.success).toBe(false);
  });

  it('should accept valid semver variations', () => {
    const versions = ['1.0.0', '2.1.3', '1.0.0-beta', '1.0.0-beta.1', '1.0.0+build123'];

    for (const version of versions) {
      const metadata = {
        '@type': 'Skill' as const,
        name: 'Test Skill',
        description: 'A test skill',
        version,
        platform: 'mcp' as const,
      };

      const result = SkillMetadataSchema.safeParse(metadata);
      expect(result.success).toBe(true);
    }
  });

  it('should accept optional fields', () => {
    const metadataWithOptionals = {
      '@type': 'Skill' as const,
      name: 'GitHub Integration',
      description: 'Read and write GitHub issues, PRs, and code',
      version: '2.1.0',
      platform: 'mcp' as const,
      image: 'https://example.com/icon.png',
      author: 'Acme Corp',
      installUri: 'mcp://install/github-mcp',
      permissions: ['github:repo', 'github:issue'],
      longDescription: 'Full-featured GitHub integration with support for...',
    };

    const result = SkillMetadataSchema.safeParse(metadataWithOptionals);
    expect(result.success).toBe(true);
  });

  it('should reject invalid URL formats for image', () => {
    const invalidMetadata = {
      '@type': 'Skill' as const,
      name: 'Test Skill',
      description: 'A test skill',
      version: '1.0.0',
      platform: 'mcp' as const,
      image: 'not-a-url',
    };

    const result = SkillMetadataSchema.safeParse(invalidMetadata);
    expect(result.success).toBe(false);
  });

  it('should accept various installUri formats', () => {
    const mcpMetadata = {
      '@type': 'Skill' as const,
      name: 'Test Skill MCP',
      description: 'A test skill',
      version: '1.0.0',
      platform: 'mcp' as const,
      installUri: 'mcp://install/github-mcp',
    };
    const openaiMetadata = {
      '@type': 'Skill' as const,
      name: 'Test Skill OpenAI',
      description: 'A test skill',
      version: '1.0.0',
      platform: 'openai' as const,
      installUri: 'https://example.com/install',
    };
    const otherMetadata = {
      '@type': 'Skill' as const,
      name: 'Test Skill Other',
      description: 'A test skill',
      version: '1.0.0',
      platform: 'other' as const,
      installUri: 'npm:@example/skill',
    };

    expect(SkillMetadataSchema.safeParse(mcpMetadata).success).toBe(true);
    expect(SkillMetadataSchema.safeParse(openaiMetadata).success).toBe(true);
    expect(SkillMetadataSchema.safeParse(otherMetadata).success).toBe(true);
  });

  it('should reject non-mcp installUri when platform is mcp', () => {
    const metadata = {
      '@type': 'Skill' as const,
      name: 'Test Skill',
      description: 'A test skill',
      version: '1.0.0',
      platform: 'mcp' as const,
      installUri: 'https://example.com/install',
    };

    const result = SkillMetadataSchema.safeParse(metadata);
    expect(result.success).toBe(false);
  });

  it('should reject unsupported installUri formats', () => {
    const metadata = {
      '@type': 'Skill' as const,
      name: 'Test Skill',
      description: 'A test skill',
      version: '1.0.0',
      platform: 'other' as const,
      installUri: 'ftp://example.com/install',
    };

    const result = SkillMetadataSchema.safeParse(metadata);
    expect(result.success).toBe(false);
  });

  it('should accept empty permissions array', () => {
    const metadata = {
      '@type': 'Skill' as const,
      name: 'Test Skill',
      description: 'A test skill',
      version: '1.0.0',
      platform: 'mcp' as const,
      permissions: [],
    };

    const result = SkillMetadataSchema.safeParse(metadata);
    expect(result.success).toBe(true);
  });
});

describe('SkillPlatform', () => {
  it('should parse valid platform values', () => {
    expect(SkillPlatform.safeParse('mcp').success).toBe(true);
    expect(SkillPlatform.safeParse('claude-code').success).toBe(true);
    expect(SkillPlatform.safeParse('openclaw').success).toBe(true);
    expect(SkillPlatform.safeParse('openai').success).toBe(true);
    expect(SkillPlatform.safeParse('other').success).toBe(true);
  });

  it('should reject invalid platform values', () => {
    expect(SkillPlatform.safeParse('invalid').success).toBe(false);
    expect(SkillPlatform.safeParse('MCP').success).toBe(false);
    expect(SkillPlatform.safeParse('').success).toBe(false);
  });
});
