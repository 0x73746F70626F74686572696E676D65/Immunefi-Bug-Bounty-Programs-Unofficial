import { pollIndexerLagBlocks } from '~/lib/indexer-poller'

export async function getIndexerLagBlocks(): Promise<number> {
  const graphqlUrl = process.env.GRAPHQL_API_URL_PRIVATE
  if (!graphqlUrl) return 0

  try {
    const lag = await pollIndexerLagBlocks(graphqlUrl, {
      maxRetries: 2,
      initialDelayMs: 100,
      maxDelayMs: 500,
    })
    return lag ?? 0
  } catch {
    return 0
  }
}
