/**
 * Foundation atoms for the Agent Registry v3.
 * These are created once by the bootstrap script and referenced by term_id thereafter.
 *
 * v3 Model: 5 core predicates (Option C versioning - base atom + metadata triples)
 *
 * Categories:
 * - Predicates (5): Core relationship types (is, has-capability, uses, has-metadata, created-by)
 * - Types (6): Agent, Skill, Prompt, Workflow, Tool, Dataset
 * - Capabilities (56): Comprehensive bootstrap set across 10 categories
 */

/** 5 Core Predicates — v3 reduced model */
export const PREDICATE_ATOMS = [
  { name: 'is', description: 'Universal stakeable claim (FOR/AGAINST)' },
  { name: 'has-capability', description: 'Entity possesses this capability' },
  { name: 'uses', description: 'Agent uses this tool/skill' },
  { name: 'has-metadata', description: 'Entity has this metadata (versioned)' },
  { name: 'created-by', description: 'Entity was created by this agent/user' },
] as const;

/** Type atoms — used in [Entity] is [TypeAtom] triples */
export const TYPE_ATOM_DEFINITIONS = [
  { name: 'Agent', description: 'Type atom for AI agents' },
  { name: 'Skill', description: 'Type atom for agent skills/tools' },
  { name: 'Prompt', description: 'Type atom for reusable prompt templates' },
  { name: 'Workflow', description: 'Type atom for multi-step automation workflows' },
  { name: 'Tool', description: 'Type atom for standalone developer tools' },
  { name: 'Dataset', description: 'Type atom for curated datasets and knowledge bases' },
] as const;

/**
 * Capability atoms — comprehensive bootstrap set.
 * 56 capabilities across 10 categories.
 *
 * Emergent growth: New capabilities created as atoms by anyone.
 * Synonym resolution via `is` claims: [code-gen] is [code-generation]
 *
 * Categories:
 *   ai (11)          — Core AI/ML primitives
 *   web3 (8)         — Blockchain and DeFi
 *   research (5)     — Information gathering and synthesis
 *   content (3)      — Writing and media
 *   automation (7)   — Workflow and infrastructure
 *   development (5)  — Software engineering lifecycle
 *   security (4)     — Audit, auth, and threat detection
 *   communication (5) — Messaging and collaboration
 *   memory (4)       — Context and knowledge persistence
 *   specialized (4)  — Cross-cutting specialized abilities
 */
export const CAPABILITY_ATOMS = [
  // --- AI & ML (11) ---
  { name: 'code-generation', description: 'Generate source code from natural language prompts' },
  { name: 'code-review', description: 'Review and analyze source code for bugs and best practices' },
  { name: 'natural-language', description: 'Understand and generate human language' },
  { name: 'reasoning', description: 'Multi-step logical reasoning and problem solving' },
  { name: 'tool-use', description: 'Invoke external tools and APIs autonomously' },
  { name: 'planning', description: 'Create and execute multi-step plans' },
  { name: 'vision', description: 'Process and understand images' },
  { name: 'data-analysis', description: 'Analyze datasets and generate insights' },
  { name: 'embeddings', description: 'Generate vector embeddings for semantic search' },
  { name: 'image-generation', description: 'Create images from text descriptions' },
  { name: 'audio-processing', description: 'Transcribe, analyze, and generate audio' },

  // --- Web3 (8) ---
  { name: 'smart-contracts', description: 'Write, deploy, and audit Solidity/Rust smart contracts' },
  { name: 'defi-protocols', description: 'Interact with decentralized finance protocols for swaps, lending, and yield' },
  { name: 'onchain-data', description: 'Query and index blockchain data across networks' },
  { name: 'wallet-management', description: 'Manage crypto wallets, sign transactions, and handle keys' },
  { name: 'nft-analysis', description: 'Analyze NFT collections, rarity, and market data' },
  { name: 'governance', description: 'Participate in DAO governance proposals and voting' },
  { name: 'cross-chain', description: 'Bridge assets and execute operations across multiple chains' },
  { name: 'token-analysis', description: 'Analyze token metrics, liquidity, holder distribution, and price data' },

  // --- Research (5) ---
  { name: 'web-search', description: 'Search the web for real-time information' },
  { name: 'document-analysis', description: 'Read and summarize long documents and PDFs' },
  { name: 'fact-checking', description: 'Verify claims against authoritative sources' },
  { name: 'research', description: 'Conduct multi-step investigations combining search, reading, and synthesis' },
  { name: 'knowledge-management', description: 'Organize, store, and retrieve structured knowledge across sessions' },

  // --- Content (3) ---
  { name: 'content-writing', description: 'Write articles, blog posts, and documentation' },
  { name: 'translation', description: 'Translate between languages' },
  { name: 'curation', description: 'Curate and rank items by quality and relevance' },

  // --- Automation (7) ---
  { name: 'workflow-orchestration', description: 'Coordinate multi-step workflows across tools and services' },
  { name: 'task-scheduling', description: 'Schedule and execute recurring or deferred tasks' },
  { name: 'file-management', description: 'Read, write, transform, and organize files' },
  { name: 'system-monitoring', description: 'Monitor system health, logs, and performance metrics' },
  { name: 'deployment', description: 'Deploy applications and manage infrastructure' },
  { name: 'database-ops', description: 'Manage database queries, schemas, and migrations' },
  { name: 'api-integration', description: 'Integrate with external APIs and webhook services' },

  // --- Development (5) ---
  { name: 'debugging', description: 'Diagnose and fix bugs using logs, stack traces, and codebase analysis' },
  { name: 'testing', description: 'Write and run unit, integration, and end-to-end tests' },
  { name: 'code-execution', description: 'Execute code in sandboxed environments and return results' },
  { name: 'code-management', description: 'Manage git operations, branches, PRs, and version control workflows' },
  { name: 'web-scraping', description: 'Extract structured data from web pages and APIs' },

  // --- Security (4) ---
  { name: 'security-audit', description: 'Identify vulnerabilities in code, contracts, and configurations' },
  { name: 'authentication', description: 'Manage identity verification, OAuth, API keys, and access control' },
  { name: 'threat-detection', description: 'Monitor for and alert on security threats and anomalous behavior' },
  { name: 'input-validation', description: 'Validate, sanitize, and enforce schemas on untrusted input' },

  // --- Communication (5) ---
  { name: 'messaging', description: 'Send and receive messages across platforms like Slack, Discord, and email' },
  { name: 'agent-delegation', description: 'Delegate tasks to other agents and aggregate their results' },
  { name: 'human-in-the-loop', description: 'Request human review, approval, or input at decision points' },
  { name: 'notification', description: 'Push alerts and status updates to users or other systems' },
  { name: 'collaborative-coding', description: 'Pair with humans or other agents on shared code in real time' },

  // --- Memory & Context (4) ---
  { name: 'context-management', description: 'Maintain and retrieve conversation history and session state' },
  { name: 'long-term-memory', description: 'Persist learned information across sessions and interactions' },
  { name: 'retrieval-augmentation', description: 'Retrieve relevant context from vector stores and knowledge bases' },
  { name: 'structured-output', description: 'Generate responses in specified formats like JSON, XML, and schemas' },

  // --- Specialized (4) ---
  { name: 'browser-automation', description: 'Control web browsers to navigate, click, fill forms, and extract data' },
  { name: 'data-transformation', description: 'Convert data between formats, clean datasets, and run ETL pipelines' },
  { name: 'payment-processing', description: 'Handle crypto and fiat payment flows, invoicing, and settlements' },
  { name: 'document-generation', description: 'Create formatted reports, PDFs, spreadsheets, and presentations' },
] as const;

/**
 * Platform atoms — skill platforms represented as Atoms on-chain.
 * Per locked decision #17: Platforms are Atoms, enabling future
 * [skill] is [MCP] triples and platform-based discovery.
 */
export const PLATFORM_ATOMS = [
  { name: 'MCP', description: 'Model Context Protocol standard for AI tool connectivity' },
  { name: 'Claude Code', description: 'Custom skills for Claude Code CLI' },
  { name: 'OpenClaw', description: 'Open marketplace for AI agent tools' },
  { name: 'OpenAI', description: 'Function calling and tools for OpenAI models' },
  { name: 'x402', description: 'HTTP 402-based micropayment protocol for AI services' },
  { name: 'Custom', description: 'Custom or proprietary skill integration' },
] as const;

/** All foundation atoms combined for the bootstrap script */
export interface FoundationAtom {
  category: 'predicate' | 'type' | 'capability' | 'platform';
  name: string;
  description: string;
}

export function getAllFoundationAtoms(): FoundationAtom[] {
  return [
    ...PREDICATE_ATOMS.map((a) => ({ ...a, category: 'predicate' as const })),
    ...TYPE_ATOM_DEFINITIONS.map((a) => ({ ...a, category: 'type' as const })),
    ...CAPABILITY_ATOMS.map((a) => ({ ...a, category: 'capability' as const })),
    ...PLATFORM_ATOMS.map((a) => ({ ...a, category: 'platform' as const })),
  ];
}
