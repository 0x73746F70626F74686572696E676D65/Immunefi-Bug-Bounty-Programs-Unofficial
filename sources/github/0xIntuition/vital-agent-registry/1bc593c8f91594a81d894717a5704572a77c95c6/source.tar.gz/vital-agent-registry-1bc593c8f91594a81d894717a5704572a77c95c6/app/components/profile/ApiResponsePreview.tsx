import { useState } from 'react'
import * as Collapsible from '@radix-ui/react-collapsible'
import { ChevronDown, Copy, Check } from 'lucide-react'
import type { Agent, Skill } from '~/types'
import { cn } from '~/lib/utils'

interface ApiResponsePreviewProps {
  data: Agent | Skill
  endpoint: string
  className?: string
}

export function ApiResponsePreview({
  data,
  endpoint,
  className,
}: ApiResponsePreviewProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [copied, setCopied] = useState(false)

  // Custom replacer to handle BigInt values
  const jsonReplacer = (_key: string, value: unknown) => {
    if (typeof value === 'bigint') {
      return value.toString()
    }
    return value
  }

  const rawJson = JSON.stringify(data, jsonReplacer, 2)

  // Manual syntax highlighting using regex
  const highlightJson = (json: string) => {
    return json
      .replace(
        /"([^"]+)":/g,
        '<span class="text-[hsl(188_83%_58%)]">"$1"</span>:',
      ) // Keys: cyan
      .replace(
        /: "([^"]*)"/g,
        ': <span class="text-[hsl(142_71%_45%)]">"$1"</span>',
      ) // String values: green
      .replace(
        /: (\d+\.?\d*)/g,
        ': <span class="text-[hsl(48_96%_53%)]">$1</span>',
      ) // Numbers: yellow
      .replace(
        /: (true|false|null)/g,
        ': <span class="text-[hsl(280_83%_58%)]">$1</span>',
      ) // Booleans/null: magenta
  }

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(rawJson)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      console.error('Failed to copy:', error)
    }
  }

  return (
    <Collapsible.Root
      open={isOpen}
      onOpenChange={setIsOpen}
      className={cn(
        'rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] font-mono text-sm',
        className,
      )}
    >
      <Collapsible.Trigger className="flex w-full items-center justify-between p-4 hover:bg-muted/50 transition-colors">
        <div className="flex items-center gap-2">
          <span className="text-muted-foreground">&gt;</span>
          <span className="text-foreground">API RESPONSE PREVIEW</span>
        </div>
        <ChevronDown
          className={cn(
            'h-5 w-5 text-muted-foreground transition-transform',
            isOpen && 'rotate-180',
          )}
        />
      </Collapsible.Trigger>

      <Collapsible.Content className="px-4 pb-4">
        {/* Endpoint info */}
        <div className="mb-3 pb-3 border-b border-border">
          <span className="text-[hsl(142_71%_45%)]">GET</span>{' '}
          <span className="text-foreground">{endpoint}</span>
        </div>

        {/* Copy button */}
        <div className="flex justify-end mb-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-2 px-3 py-1 rounded border border-border hover:bg-muted/50 transition-colors text-xs"
            aria-label="Copy JSON"
          >
            {copied ? (
              <>
                <Check className="h-3 w-3 text-[hsl(142_71%_45%)]" />
                <span className="text-[hsl(142_71%_45%)]">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="h-3 w-3" />
                <span>Copy</span>
              </>
            )}
          </button>
        </div>

        {/* JSON preview with syntax highlighting */}
        <div className="relative">
          <div
            className="bg-muted/30 rounded p-4 overflow-x-auto max-h-[400px] overflow-y-auto"
            dangerouslySetInnerHTML={{
              __html: `<pre>${highlightJson(rawJson)}</pre>`,
            }}
          />
        </div>
      </Collapsible.Content>
    </Collapsible.Root>
  )
}
