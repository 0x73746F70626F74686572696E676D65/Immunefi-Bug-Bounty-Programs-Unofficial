/**
 * Vault — economic signaling layer on top of an atom or triple
 *
 * Each agent and skill has a vault that serves as the trust signal mechanism.
 * Users stake ETH into vaults to signal trust, which creates economic weight.
 */
export interface Vault {
  /** References the atom/triple term_id */
  term_id: string
  /** Bonding curve identifier */
  curve_id: string
  /** Total shares outstanding (BigInt string) */
  total_shares: string
  /** Current price per share in wei (BigInt string) */
  current_share_price: string
  /** Total assets deposited in wei (BigInt string) */
  total_assets: string
  /** Market cap in wei (BigInt string) */
  market_cap: string
  /** Number of unique stakers */
  position_count: number
}

/**
 * Position — a user's stake in a vault
 */
export interface Position {
  /** Position ID */
  id: string
  /** Shares held (BigInt string) */
  shares: string
  /** Account that holds this position */
  account_id: string
  /** Account label for display */
  account_label?: string
}

/**
 * TrustSignal — derived trust metrics from vault economics
 *
 * Computed client-side from raw vault data. Trust signals are relative
 * measures (percentile, tier) rather than raw TVL which lacks context.
 */
export interface TrustSignal {
  /** Number of unique stakers */
  stakerCount: number
  /** Total value staked (formatted ETH string) */
  totalStaked: string
  /** Current share price (formatted ETH string) */
  sharePrice: string
  /** Relative trust tier */
  tier: TrustTier
  /** Percentile rank among all agents (0-100) */
  percentile: number
  /** Market cap (formatted ETH string) */
  marketCap: string
}

/**
 * TrustTier — relative trust ranking
 *
 * Derived from percentile thresholds. Shows trust signal strength
 * relative to other entities in the registry.
 */
export type TrustTier = 'platinum' | 'gold' | 'silver' | 'bronze' | 'unranked'

/**
 * Trust tier ordering for comparisons
 */
export const TRUST_TIER_ORDER: Record<TrustTier, number> = {
  platinum: 5,
  gold: 4,
  silver: 3,
  bronze: 2,
  unranked: 1,
}

/**
 * Percentile thresholds for trust tiers
 */
export const TRUST_TIER_THRESHOLDS = {
  platinum: 90,
  gold: 75,
  silver: 50,
  bronze: 25,
}
