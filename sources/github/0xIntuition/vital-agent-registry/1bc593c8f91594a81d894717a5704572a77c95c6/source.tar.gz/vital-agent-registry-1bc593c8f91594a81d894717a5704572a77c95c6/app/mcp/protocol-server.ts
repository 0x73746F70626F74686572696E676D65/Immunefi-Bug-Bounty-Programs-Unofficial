#!/usr/bin/env tsx
/**
 * Intuition Protocol MCP Server
 *
 * A stdio-transport MCP server that wraps the Intuition SDK + agent-registry API.
 * Provides Claude-compatible agents with tools to create atoms/triples,
 * stake, search, and interact with the Intuition protocol directly.
 *
 * Usage:
 *   tsx app/mcp/protocol-server.ts
 *
 * Or via package.json:
 *   pnpm mcp:protocol
 */

import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js'
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js'
import { z } from 'zod'

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const REGISTRY_BASE_URL = process.env.REGISTRY_BASE_URL || 'http://localhost:4101'

// ---------------------------------------------------------------------------
// Helper: call agent-registry REST API
// ---------------------------------------------------------------------------

async function registryFetch<T>(
  path: string,
  options: { method?: string; body?: unknown; params?: Record<string, string> } = {},
): Promise<T> {
  const url = new URL(path, REGISTRY_BASE_URL)
  if (options.params) {
    for (const [k, v] of Object.entries(options.params)) {
      if (v) url.searchParams.set(k, v)
    }
  }

  const headers: Record<string, string> = {}
  if (options.body) headers['Content-Type'] = 'application/json'

  // Include API key for execute endpoints
  const apiKey = process.env.REGISTRY_API_KEY
  if (apiKey) headers['x-api-key'] = apiKey

  const res = await fetch(url.toString(), {
    method: options.method ?? 'GET',
    headers: Object.keys(headers).length > 0 ? headers : undefined,
    body: options.body ? JSON.stringify(options.body) : undefined,
  })

  const json = await res.json()

  if (!res.ok) {
    const errorMsg = (json as { error?: string }).error ?? `HTTP ${res.status}`
    throw new Error(errorMsg)
  }

  return (json as { data: T }).data
}

// ---------------------------------------------------------------------------
// Server setup
// ---------------------------------------------------------------------------

const server = new McpServer({
  name: 'intuition-protocol',
  version: '1.0.0',
})

// ---------------------------------------------------------------------------
// Tool: create_atoms
// ---------------------------------------------------------------------------

server.tool(
  'create_atoms',
  'Create one or more atoms on the Intuition protocol. Each atom is a piece of data (string) that gets a permanent on-chain identity.',
  {
    atomData: z.array(z.string().min(1).max(10000)).min(1).max(20)
      .describe('Array of atom data strings to create'),
    depositPerAtom: z.string().regex(/^\d+$/).optional()
      .describe('Wei amount to deposit per atom (optional)'),
  },
  async ({ atomData, depositPerAtom }) => {
    const result = await registryFetch('/api/v1/atoms?execute=true', {
      method: 'POST',
      body: { atomData, depositPerAtom },
    })
    return { content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: create_triples
// ---------------------------------------------------------------------------

server.tool(
  'create_triples',
  'Create relationship triples on the Intuition protocol. Each triple is (subject, predicate, object) linking atoms together.',
  {
    triples: z.array(z.object({
      subjectId: z.string().describe('Subject atom term ID (bytes32 hex)'),
      predicateId: z.string().describe('Predicate atom term ID (bytes32 hex)'),
      objectId: z.string().describe('Object atom term ID (bytes32 hex)'),
    })).min(1).max(20).describe('Array of triples to create'),
    depositPerTriple: z.string().regex(/^\d+$/).optional()
      .describe('Wei amount to deposit per triple (optional)'),
  },
  async ({ triples, depositPerTriple }) => {
    const result = await registryFetch('/api/v1/triples?execute=true', {
      method: 'POST',
      body: { triples, depositPerTriple },
    })
    return { content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: stake
// ---------------------------------------------------------------------------

server.tool(
  'stake',
  'Deposit ETH to an atom or triple vault (for or against). Staking signals trust or distrust.',
  {
    termId: z.string().regex(/^0x[0-9a-fA-F]{64}$/).describe('Term ID of the atom or triple vault'),
    amountEth: z.string().describe('Amount in ETH (e.g., "0.01")'),
    direction: z.enum(['for', 'against']).optional().default('for')
      .describe('Stake direction: "for" (support) or "against" (dispute)'),
  },
  async ({ termId, amountEth, direction }) => {
    const result = await registryFetch('/api/v1/trust/stake', {
      method: 'POST',
      body: { termId, amountEth, direction },
    })
    return { content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: get_atom
// ---------------------------------------------------------------------------

server.tool(
  'get_atom',
  'Look up an atom by its term ID. Returns atom data, metadata, and outgoing relationships.',
  {
    termId: z.string().regex(/^0x[0-9a-fA-F]{64}$/).describe('Atom term ID (bytes32 hex)'),
  },
  async ({ termId }) => {
    const result = await registryFetch(`/api/v1/atoms/${termId}`)
    return { content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: search_atoms
// ---------------------------------------------------------------------------

server.tool(
  'search_atoms',
  'Search atoms by text query. Finds atoms matching label or data. Results sorted by stake amount (most-staked first).',
  {
    q: z.string().min(1).max(200).describe('Search query text'),
    type: z.string().optional().describe('Filter by atom type (e.g., "Thing", "Person")'),
    limit: z.number().min(1).max(100).optional().default(20).describe('Max results'),
  },
  async ({ q, type, limit }) => {
    const params: Record<string, string> = { q, limit: String(limit) }
    if (type) params.type = type
    const result = await registryFetch('/api/v1/atoms/search', { params })
    return { content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: get_triples
// ---------------------------------------------------------------------------

server.tool(
  'get_triples',
  'Query triples by subject, predicate, and/or object. At least one filter is required.',
  {
    subjectId: z.string().optional().describe('Filter by subject atom term ID'),
    predicateId: z.string().optional().describe('Filter by predicate atom term ID'),
    objectId: z.string().optional().describe('Filter by object atom term ID'),
    limit: z.number().min(1).max(100).optional().default(20).describe('Max results'),
    offset: z.number().min(0).optional().default(0).describe('Pagination offset'),
  },
  async ({ subjectId, predicateId, objectId, limit, offset }) => {
    const params: Record<string, string> = {
      limit: String(limit),
      offset: String(offset),
    }
    if (subjectId) params.subjectId = subjectId
    if (predicateId) params.predicateId = predicateId
    if (objectId) params.objectId = objectId
    const result = await registryFetch('/api/v1/triples', { params })
    return { content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: get_predicates
// ---------------------------------------------------------------------------

server.tool(
  'get_predicates',
  'List available predicates (relationship types) from the bootstrap term-id-map. Includes: is, has-capability, uses, has-metadata, created-by.',
  {},
  async () => {
    const { readFile } = await import('node:fs/promises')
    const { join } = await import('node:path')

    const candidates = [
      join(process.cwd(), 'term-id-map.json'),
      join(process.cwd(), 'apps', 'agent-registry', 'term-id-map.json'),
    ]

    let map: Record<string, string> = {}
    for (const candidate of candidates) {
      try {
        const content = await readFile(candidate, 'utf-8')
        map = JSON.parse(content)
        break
      } catch { /* try next */ }
    }

    const predicates = {
      is: map['is'] ?? null,
      'has-capability': map['has-capability'] ?? null,
      uses: map['uses'] ?? null,
      'has-metadata': map['has-metadata'] ?? null,
      'created-by': map['created-by'] ?? null,
    }

    return { content: [{ type: 'text' as const, text: JSON.stringify(predicates, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: get_capabilities
// ---------------------------------------------------------------------------

server.tool(
  'get_capabilities',
  'List registered capability atoms from the agent registry.',
  {
    limit: z.number().min(1).max(100).optional().default(50).describe('Max results'),
  },
  async ({ limit }) => {
    const result = await registryFetch('/api/v1/capabilities', {
      params: { limit: String(limit) },
    })
    return { content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: calculate_atom_id
// ---------------------------------------------------------------------------

server.tool(
  'calculate_atom_id',
  'Pre-compute the deterministic atom term ID from data (no chain call needed). Useful for checking if an atom already exists.',
  {
    data: z.string().min(1).describe('Atom data string to compute ID for'),
  },
  async ({ data }) => {
    const { deriveAtomTermId } = await import('~/lib/calldata')
    const termId = deriveAtomTermId(data)

    return { content: [{ type: 'text' as const, text: JSON.stringify({ data, termId }, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: calculate_triple_id
// ---------------------------------------------------------------------------

server.tool(
  'calculate_triple_id',
  'Pre-compute the deterministic triple term ID from subject, predicate, and object term IDs (no chain call needed).',
  {
    subjectId: z.string().describe('Subject atom term ID (bytes32 hex)'),
    predicateId: z.string().describe('Predicate atom term ID (bytes32 hex)'),
    objectId: z.string().describe('Object atom term ID (bytes32 hex)'),
  },
  async ({ subjectId, predicateId, objectId }) => {
    const { keccak256, encodePacked } = await import('viem')
    const termId = keccak256(
      encodePacked(
        ['bytes32', 'bytes32', 'bytes32'],
        [subjectId as `0x${string}`, predicateId as `0x${string}`, objectId as `0x${string}`],
      ),
    )

    return {
      content: [{
        type: 'text' as const,
        text: JSON.stringify({ subjectId, predicateId, objectId, termId }, null, 2),
      }],
    }
  },
)

// ---------------------------------------------------------------------------
// Tool: register_agent
// ---------------------------------------------------------------------------

server.tool(
  'register_agent',
  'Register a new agent in the Intuition protocol with metadata and on-chain identity.',
  {
    name: z.string().min(1).max(100).describe('Agent name'),
    description: z.string().min(1).max(500).describe('Agent description'),
    version: z.string().regex(/^\d+\.\d+\.\d+$/).describe('Semantic version (e.g., "1.0.0")'),
    model: z.string().optional().describe('AI model identifier'),
    endpoint: z.string().url().optional().describe('Agent endpoint URL'),
    tags: z.array(z.string()).max(10).optional().describe('Agent capability tags'),
  },
  async ({ name, description, version, model, endpoint, tags }) => {
    const result = await registryFetch('/api/v1/agents/register?execute=true', {
      method: 'POST',
      body: { name, description, version, model, endpoint, tags },
    })
    return { content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: discover_agents
// ---------------------------------------------------------------------------

server.tool(
  'discover_agents',
  'Find agents by capability requirements. Returns matching agents ranked by trust score.',
  {
    requiredCapabilities: z.array(z.string()).min(1).describe('Capabilities agents must have'),
    preferredCapabilities: z.array(z.string()).optional().describe('Nice-to-have capabilities'),
    matchAll: z.boolean().optional().default(true)
      .describe('If true, agent must have all required capabilities'),
    limit: z.number().min(1).max(100).optional().default(20).describe('Max results'),
  },
  async ({ requiredCapabilities, preferredCapabilities, matchAll, limit }) => {
    const result = await registryFetch('/api/v1/agents/match', {
      method: 'POST',
      body: {
        requiredCapabilities,
        preferredCapabilities,
        matchAll,
        limit,
      },
    })
    return { content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: register_skill
// ---------------------------------------------------------------------------

server.tool(
  'register_skill',
  'Register a new skill (tool/plugin) in the Intuition protocol with metadata and on-chain identity.',
  {
    name: z.string().min(1).max(100).describe('Skill name (kebab-case recommended)'),
    description: z.string().min(1).max(500).describe('Skill description'),
    version: z.string().regex(/^\d+\.\d+\.\d+$/).describe('Semantic version (e.g., "1.0.0")'),
    platform: z.enum(['mcp', 'claude-code', 'openclaw', 'openai', 'x402', 'other']).describe('Skill platform'),
    installUri: z.string().optional().describe('URI for installing the skill'),
    transport: z.enum(['stdio', 'sse', 'http', 'websocket']).optional().describe('Transport/connection type'),
    tags: z.array(z.string()).max(10).optional().describe('Skill capability tags'),
  },
  async ({ name, description, version, platform, installUri, transport, tags }) => {
    const result = await registryFetch('/api/v1/skills/register?execute=true', {
      method: 'POST',
      body: { name, description, version, platform, installUri, transport, tags },
    })
    return { content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: list_agents
// ---------------------------------------------------------------------------

server.tool(
  'list_agents',
  'List registered agents in the Intuition protocol, sorted by trust score.',
  {
    limit: z.number().min(1).max(100).optional().default(20).describe('Max results'),
    offset: z.number().min(0).optional().default(0).describe('Pagination offset'),
  },
  async ({ limit, offset }) => {
    const result = await registryFetch('/api/v1/agents', {
      params: { limit: String(limit), offset: String(offset) },
    })
    return { content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: get_agent
// ---------------------------------------------------------------------------

server.tool(
  'get_agent',
  'Get detailed information about a specific agent by ID or term ID.',
  {
    id: z.string().min(1).describe('Agent ID or term ID'),
  },
  async ({ id }) => {
    const result = await registryFetch(`/api/v1/agents/${id}`)
    return { content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: list_skills
// ---------------------------------------------------------------------------

server.tool(
  'list_skills',
  'List registered skills in the Intuition protocol.',
  {
    limit: z.number().min(1).max(100).optional().default(20).describe('Max results'),
    offset: z.number().min(0).optional().default(0).describe('Pagination offset'),
    platform: z.string().optional().describe('Filter by platform (mcp, claude-code, etc.)'),
  },
  async ({ limit, offset, platform }) => {
    const params: Record<string, string> = { limit: String(limit), offset: String(offset) }
    if (platform) params.platform = platform
    const result = await registryFetch('/api/v1/skills', { params })
    return { content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: get_skill
// ---------------------------------------------------------------------------

server.tool(
  'get_skill',
  'Get detailed information about a specific skill by ID.',
  {
    id: z.string().min(1).describe('Skill ID or term ID'),
  },
  async ({ id }) => {
    const result = await registryFetch(`/api/v1/skills/${id}`)
    return { content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: get_trust_score
// ---------------------------------------------------------------------------

server.tool(
  'get_trust_score',
  'Get the trust score and safety signal for an agent or skill by term ID.',
  {
    termId: z.string().regex(/^0x[0-9a-fA-F]{64}$/).describe('Term ID of the atom/triple to check'),
  },
  async ({ termId }) => {
    const result = await registryFetch('/api/v1/trust/score', {
      params: { termId },
    })
    return { content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Tool: update_metadata
// ---------------------------------------------------------------------------

server.tool(
  'update_metadata',
  'Update an entity\'s metadata by creating a new metadata atom and has-metadata triple. This creates a new version in the metadata chain.',
  {
    identityTermId: z.string().regex(/^0x[0-9a-fA-F]{64}$/).describe('Identity atom term ID of the entity'),
    entityType: z.enum(['agent', 'skill']).describe('Type of entity being updated'),
    metadata: z.record(z.string(), z.unknown()).describe('Updated metadata fields'),
  },
  async ({ identityTermId, entityType, metadata }) => {
    const result = await registryFetch('/api/v1/metadata/update?execute=true', {
      method: 'POST',
      body: { identityTermId, entityType, metadata },
    })
    return { content: [{ type: 'text' as const, text: JSON.stringify(result, null, 2) }] }
  },
)

// ---------------------------------------------------------------------------
// Start server
// ---------------------------------------------------------------------------

async function main() {
  const transport = new StdioServerTransport()
  await server.connect(transport)
}

main().catch((error) => {
  console.error('MCP server failed to start:', error)
  process.exit(1)
})
