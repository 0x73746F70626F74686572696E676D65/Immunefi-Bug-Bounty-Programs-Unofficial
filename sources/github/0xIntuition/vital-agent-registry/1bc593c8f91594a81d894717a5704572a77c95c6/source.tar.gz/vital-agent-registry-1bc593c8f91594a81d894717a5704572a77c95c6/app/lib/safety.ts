import type { SafetySignal, SafetyStatus } from '~/types'
import { formatWeiToEth, sanitizeWeiString } from './vault-utils'

/**
 * Derive safety status from FOR/AGAINST stake ratio.
 *
 * Rules (FUNC-31 updated thresholds):
 * - 'verified': Safety ratio > 0.8 (FOR stake dominates)
 * - 'unverified': Safety ratio > 0.5 but <= 0.8 (FOR stake leads but not strongly)
 * - 'flagged': Safety ratio <= 0.5 (AGAINST stake is significant)
 *
 * Safety ratio = FOR / (FOR + AGAINST)
 * Special case: If both stakes are 0, returns 'unverified'.
 *
 * @param forStakeWei - Total wei staked FOR (safe), as BigInt string
 * @param againstStakeWei - Total wei staked AGAINST (dangerous), as BigInt string
 * @returns SafetyStatus classification
 *
 * @example
 * deriveSafetyStatus('40000000000000000000', '10000000000000000000') // 'verified' (40/(40+10) = 0.8)
 * deriveSafetyStatus('30000000000000000000', '20000000000000000000') // 'unverified' (30/(30+20) = 0.6)
 * deriveSafetyStatus('20000000000000000000', '30000000000000000000') // 'flagged' (20/(20+30) = 0.4)
 * deriveSafetyStatus('0', '0') // 'unverified' (no stakes)
 */
export function deriveSafetyStatus(
  forStakeWei: string,
  againstStakeWei: string,
): SafetyStatus {
  const forStake = BigInt(sanitizeWeiString(forStakeWei))
  const againstStake = BigInt(sanitizeWeiString(againstStakeWei))
  const totalStake = forStake + againstStake

  if (totalStake === 0n) return 'unverified'

  // Compute ratio with 4 decimal precision: multiply by 10000, divide, then compare
  const ratioScaled = (forStake * 10000n) / totalStake

  if (ratioScaled > 8000n) return 'verified' // > 0.8
  if (ratioScaled > 5000n) return 'unverified' // > 0.5
  return 'flagged' // <= 0.5
}

/**
 * Compute a complete SafetySignal from FOR/AGAINST economics.
 *
 * Updated for FUNC-31: Uses BigInt wei values for precision, new threshold rules.
 * Safety ratio computed as FOR / (FOR + AGAINST) with 4 decimal precision.
 *
 * @param forCount - Number of stakers attesting FOR (safe)
 * @param againstCount - Number of stakers attesting AGAINST (dangerous)
 * @param forStakeWei - Total wei staked FOR, as BigInt string
 * @param againstStakeWei - Total wei staked AGAINST, as BigInt string
 * @param flagReason - Optional reason if flagged
 * @returns Complete SafetySignal with status, counts, formatted stakes, ratio
 *
 * @example
 * computeSafetySignal(80, 20, '40000000000000000000', '10000000000000000000')
 * // { status: 'verified', forCount: 80, againstCount: 20,
 * //   forStake: '40', againstStake: '10', safetyRatio: 0.8 }
 */
export function computeSafetySignal(
  forCount: number,
  againstCount: number,
  forStakeWei: string,
  againstStakeWei: string,
  flagReason?: string,
): SafetySignal {
  const forStake = BigInt(sanitizeWeiString(forStakeWei))
  const againstStake = BigInt(sanitizeWeiString(againstStakeWei))
  const totalStake = forStake + againstStake

  // Compute safety ratio with 4 decimal precision using BigInt
  let safetyRatio = 0
  if (totalStake > 0n) {
    const ratioScaled = (forStake * 10000n) / totalStake
    safetyRatio = Number(ratioScaled) / 10000
  }

  const status = deriveSafetyStatus(forStakeWei, againstStakeWei)

  return {
    status,
    forCount,
    againstCount,
    forStake: formatWeiToEth(forStakeWei, 4),
    againstStake: formatWeiToEth(againstStakeWei, 4),
    safetyRatio: parseFloat(safetyRatio.toFixed(4)),
    flagReason: status === 'flagged' ? flagReason : undefined,
  }
}
