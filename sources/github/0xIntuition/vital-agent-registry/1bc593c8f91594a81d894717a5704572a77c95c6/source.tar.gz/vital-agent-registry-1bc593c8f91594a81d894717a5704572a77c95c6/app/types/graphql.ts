/** Raw GraphQL response types matching the Hasura schema */

export interface GqlCachedImage {
  url: string
  safe: boolean
}

export interface GqlAtomValuePerson {
  name: string
  image: string | null
  cached_image: GqlCachedImage | null
  url: string | null
}

export interface GqlAtomValueThing {
  name: string
  image: string | null
  cached_image: GqlCachedImage | null
  url: string | null
}

export interface GqlAtomValueOrganization {
  name: string
  image: string | null
  url: string | null
}

export interface GqlAtomValueAccount {
  id: string
  label: string | null
  image: string | null
  cached_image: GqlCachedImage | null
}

export interface GqlJsonObject {
  description: string | null
}

export interface GqlAtomValue {
  person: GqlAtomValuePerson | null
  thing: GqlAtomValueThing | null
  organization: GqlAtomValueOrganization | null
  account: GqlAtomValueAccount | null
  json_object: GqlJsonObject | null
}

export interface GqlPosition {
  id: string
  shares: string
  account_id: string
  account: GqlAccount
}

export interface GqlUserPosition {
  shares: string
  account_id: string
}

export interface GqlVault {
  term_id: string
  curve_id: string
  current_share_price: string
  total_shares: string
  total_assets: string
  position_count: number
  market_cap: string
  userPosition: GqlUserPosition[]
}

export interface GqlTerm {
  total_market_cap: string | null
  positions_aggregate: {
    aggregate: {
      count: number
    }
  }
  vaults: GqlVault[]
}

export interface GqlAccount {
  id: string
  atom_id: string | null
  label: string | null
  image: string | null
  cached_image: GqlCachedImage | null
  type: string | null
}

export interface GqlAtom {
  term_id: string
  label: string | null
  wallet_id: string | null
  image: string | null
  cached_image: GqlCachedImage | null
  type: string | null
  created_at: string
  updated_at?: string
  data: string | null
  creator: GqlAccount
  value: GqlAtomValue | null
  term: GqlTerm
}

export interface GqlTriple {
  term_id: string
  counter_term_id: string
  created_at: string
  subject: GqlAtom
  predicate: GqlAtom
  object: GqlAtom
  term: GqlTerm
  counter_term: GqlTerm
  creator: GqlAccount
  positions_aggregate?: {
    aggregate: {
      count: number
    }
  }
}

export interface GqlAtomsResponse {
  total: {
    aggregate: {
      count: number
    }
  }
  atoms: GqlAtom[]
}

export interface GqlTriplesResponse {
  triples: GqlTriple[]
}

export interface GqlPositionsResponse {
  positions: GqlPosition[]
}

export interface GqlAccountResponse {
  account: GqlAccount & {
    positions: GqlPosition[]
    created_atoms: GqlAtom[]
  }
}
