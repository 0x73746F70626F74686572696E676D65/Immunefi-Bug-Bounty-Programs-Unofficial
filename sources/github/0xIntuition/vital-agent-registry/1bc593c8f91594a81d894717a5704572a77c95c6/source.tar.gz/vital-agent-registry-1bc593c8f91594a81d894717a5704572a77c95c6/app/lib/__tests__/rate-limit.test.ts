import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { createRateLimiter, getClientIP, isRegistrationRateLimitEnabled } from '../rate-limit';

describe('createRateLimiter', () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('allows requests within limit', () => {
    const limiter = createRateLimiter({ windowMs: 60000, maxRequests: 10 });

    // First 10 requests should be allowed
    for (let i = 0; i < 10; i++) {
      const result = limiter.check('192.168.1.1');
      expect(result.allowed).toBe(true);
      expect(result.remaining).toBe(10 - (i + 1));
    }
  });

  it('blocks requests exceeding limit', () => {
    const limiter = createRateLimiter({ windowMs: 60000, maxRequests: 3 });

    // First 3 requests allowed
    limiter.check('192.168.1.1');
    limiter.check('192.168.1.1');
    limiter.check('192.168.1.1');

    // 4th request blocked
    const result = limiter.check('192.168.1.1');
    expect(result.allowed).toBe(false);
    expect(result.remaining).toBe(0);
  });

  it('resets after window expires', () => {
    const limiter = createRateLimiter({ windowMs: 60000, maxRequests: 2 });

    // Exhaust limit
    limiter.check('192.168.1.1');
    limiter.check('192.168.1.1');

    // Next request blocked
    const blocked = limiter.check('192.168.1.1');
    expect(blocked.allowed).toBe(false);

    // Advance time past window
    vi.advanceTimersByTime(60001);

    // New window - request should be allowed
    const result = limiter.check('192.168.1.1');
    expect(result.allowed).toBe(true);
    expect(result.remaining).toBe(1);
  });

  it('tracks remaining count correctly', () => {
    const limiter = createRateLimiter({ windowMs: 60000, maxRequests: 5 });

    const r1 = limiter.check('192.168.1.1');
    expect(r1.remaining).toBe(4);

    const r2 = limiter.check('192.168.1.1');
    expect(r2.remaining).toBe(3);

    const r3 = limiter.check('192.168.1.1');
    expect(r3.remaining).toBe(2);
  });

  it('returns correct resetAt timestamp', () => {
    const now = Date.now();
    const limiter = createRateLimiter({ windowMs: 60000, maxRequests: 10 });

    const result = limiter.check('192.168.1.1');

    expect(result.resetAt).toBe(now + 60000);
  });

  it('handles multiple IPs independently', () => {
    const limiter = createRateLimiter({ windowMs: 60000, maxRequests: 2 });

    // IP 1: exhaust limit
    limiter.check('192.168.1.1');
    limiter.check('192.168.1.1');
    const blocked = limiter.check('192.168.1.1');
    expect(blocked.allowed).toBe(false);

    // IP 2: should have fresh limit
    const allowed = limiter.check('192.168.1.2');
    expect(allowed.allowed).toBe(true);
    expect(allowed.remaining).toBe(1);
  });

  it('cleanup removes expired entries', () => {
    const limiter = createRateLimiter({ windowMs: 60000, maxRequests: 10 });

    // Create entries for multiple IPs
    limiter.check('192.168.1.1');
    limiter.check('192.168.1.2');
    limiter.check('192.168.1.3');

    // Advance time to expire all entries
    vi.advanceTimersByTime(60001);

    // Trigger cleanup by checking a new IP
    limiter.check('192.168.1.4');

    // Old entries should be cleaned up (verify by checking they get fresh windows)
    const r1 = limiter.check('192.168.1.1');
    expect(r1.allowed).toBe(true);
    expect(r1.remaining).toBe(9); // Fresh window
  });

  it('reset clears all state', () => {
    const limiter = createRateLimiter({ windowMs: 60000, maxRequests: 2 });

    // Exhaust limit
    limiter.check('192.168.1.1');
    limiter.check('192.168.1.1');
    const blocked = limiter.check('192.168.1.1');
    expect(blocked.allowed).toBe(false);

    // Reset
    limiter.reset();

    // Should have fresh limit
    const result = limiter.check('192.168.1.1');
    expect(result.allowed).toBe(true);
    expect(result.remaining).toBe(1);
  });
});

describe('getClientIP', () => {
  it('extracts from x-forwarded-for', () => {
    const request = new Request('http://example.com', {
      headers: { 'x-forwarded-for': '203.0.113.1, 198.51.100.1' },
    });

    const ip = getClientIP(request);
    expect(ip).toBe('203.0.113.1');
  });

  it('extracts from x-real-ip', () => {
    const request = new Request('http://example.com', {
      headers: { 'x-real-ip': '203.0.113.5' },
    });

    const ip = getClientIP(request);
    expect(ip).toBe('203.0.113.5');
  });

  it('prefers x-forwarded-for over x-real-ip', () => {
    const request = new Request('http://example.com', {
      headers: {
        'x-forwarded-for': '203.0.113.1',
        'x-real-ip': '203.0.113.5',
      },
    });

    const ip = getClientIP(request);
    expect(ip).toBe('203.0.113.1');
  });

  it('falls back to 127.0.0.1', () => {
    const request = new Request('http://example.com');

    const ip = getClientIP(request);
    expect(ip).toBe('127.0.0.1');
  });
});

describe('isRegistrationRateLimitEnabled', () => {
  it('disables rate limit for local profile by default', () => {
    expect(isRegistrationRateLimitEnabled({ REGISTRY_WRITE_PROFILE: 'local' } as NodeJS.ProcessEnv)).toBe(false);
  });

  it('enables rate limit for shared profile', () => {
    expect(isRegistrationRateLimitEnabled({ REGISTRY_WRITE_PROFILE: 'shared' } as NodeJS.ProcessEnv)).toBe(true);
  });

  it('can force-enable in local profile', () => {
    expect(
      isRegistrationRateLimitEnabled({
        REGISTRY_WRITE_PROFILE: 'local',
        REGISTRATION_RATE_LIMIT_FORCE: '1',
      } as NodeJS.ProcessEnv),
    ).toBe(true);
  });

  it('can force-disable regardless of profile', () => {
    expect(
      isRegistrationRateLimitEnabled({
        REGISTRY_WRITE_PROFILE: 'shared',
        DISABLE_REGISTRATION_RATE_LIMIT: '1',
      } as NodeJS.ProcessEnv),
    ).toBe(false);
  });
});
