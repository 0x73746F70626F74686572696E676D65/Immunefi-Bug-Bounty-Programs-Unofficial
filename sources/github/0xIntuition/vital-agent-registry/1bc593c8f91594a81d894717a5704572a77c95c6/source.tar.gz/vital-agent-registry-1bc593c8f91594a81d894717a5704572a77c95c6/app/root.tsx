import {
  Links,
  Meta,
  Outlet,
  Scripts,
  ScrollRestoration,
  isRouteErrorResponse,
  useLoaderData,
} from 'react-router'
import type { Route } from './+types/root'
import { getPublicEnv } from '~/.server/env'
import { ThemeProvider } from '~/lib/providers/theme'
import { QueryProvider } from '~/lib/providers/query'
import { WalletProvider } from '~/lib/providers/wallet'
import { RepositoryProvider } from '~/data'
import { ViewModeProvider } from '~/lib/providers/view-mode'
import { CardVariantProvider } from '~/lib/hooks/useCardVariant'
import { SkillCardStyleProvider } from '~/lib/hooks/useSkillCardStyle'
import { TransactionToastProvider } from '~/components/staking/TransactionToast'
import stylesheet from '~/styles/globals.css?url'
import agentViewStylesheet from '~/styles/agent-view.css?url'
import rainbowkitStyles from '@rainbow-me/rainbowkit/styles.css?url'

export const links: Route.LinksFunction = () => [
  { rel: 'stylesheet', href: stylesheet },
  { rel: 'stylesheet', href: agentViewStylesheet },
  { rel: 'stylesheet', href: rainbowkitStyles },
  { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
  {
    rel: 'preconnect',
    href: 'https://fonts.gstatic.com',
    crossOrigin: 'anonymous',
  },
  {
    rel: 'stylesheet',
    href: 'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap',
  },
]

export async function loader() {
  return { env: getPublicEnv() }
}

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta charSet="utf-8" />
        <meta
          name="viewport"
          content="width=device-width, initial-scale=1, viewport-fit=cover"
        />
        <Meta />
        <Links />
        {/* Inline script to prevent flash of wrong theme */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                try {
                  var vm = localStorage.getItem('view-mode');
                  if (vm === 'agent' && localStorage.getItem('theme') !== 'agent') {
                    localStorage.setItem('theme', 'agent');
                    localStorage.removeItem('view-mode');
                  }
                  var theme = localStorage.getItem('theme') || 'dark';
                  document.documentElement.setAttribute('data-theme', theme);
                } catch (e) {}
              })();
            `,
          }}
        />
      </head>
      <body>
        {children}
        <ScrollRestoration />
        <Scripts />
      </body>
    </html>
  )
}

export default function App() {
  const { env } = useLoaderData<typeof loader>()

  return (
    <ThemeProvider defaultTheme="dark" storageKey="theme">
      <ViewModeProvider>
        <CardVariantProvider>
          <SkillCardStyleProvider>
            <WalletProvider chain={env.CHAIN} walletConnectProjectId={env.WALLET_CONNECT_PROJECT_ID}>
              <QueryProvider>
                <script
                  dangerouslySetInnerHTML={{
                    __html: `window.ENV = ${JSON.stringify(env)}`,
                  }}
                />
                <RepositoryProvider>
                  <TransactionToastProvider>
                    <Outlet />
                  </TransactionToastProvider>
                </RepositoryProvider>
              </QueryProvider>
            </WalletProvider>
          </SkillCardStyleProvider>
        </CardVariantProvider>
      </ViewModeProvider>
    </ThemeProvider>
  )
}

export function ErrorBoundary({ error }: Route.ErrorBoundaryProps) {
  let message = 'Oops!'
  let details = 'An unexpected error occurred.'
  let is404 = false

  if (isRouteErrorResponse(error)) {
    is404 = error.status === 404
    message = is404 ? '404' : `${error.status}`
    details = is404
      ? "The page you're looking for doesn't exist."
      : error.statusText || details
  } else if (error && error instanceof Error) {
    details = error.message
  }

  return (
    <main className="flex h-svh items-center justify-center bg-[hsl(230,8%,5%)] p-4">
      <div className="text-center">
        <p className="text-7xl font-bold text-[hsl(282,70%,56%)]">{message}</p>
        <p className="mt-3 text-lg text-[hsl(230,8%,65%)]">{details}</p>
        <a
          href="/"
          className="mt-6 inline-block rounded-lg bg-[hsl(282,70%,56%)] px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[hsl(282,70%,48%)]"
        >
          {is404 ? 'Back to Registry' : 'Reload'}
        </a>
      </div>
    </main>
  )
}
