import type { Agent } from '~/types'
import { cn } from '~/lib/utils'
import { useIPFSFallback } from '~/lib/hooks/useIPFSFallback'
import { StaleIndicator } from '~/components/ui/StaleIndicator'

interface AgentViewIdentityZoneProps {
  agent: Agent
  className?: string
}

export function AgentViewIdentityZone({
  agent,
  className,
}: AgentViewIdentityZoneProps) {
  const { metadata, agentCard, erc8004 } = agent
  const { data: resolvedMetadata, isStale } = useIPFSFallback(
    metadata.metadataUri,
    metadata,
    { timeoutMs: 3000 },
  )
  const activeMetadata = resolvedMetadata ?? metadata

  return (
    <div
      className={cn(
        'rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] p-4 font-mono text-sm',
        className,
      )}
    >
      <div className="text-muted-foreground mb-4">=== AGENT IDENTITY ===</div>

      <div className="space-y-1 mb-4">
        <div>
          <span className="text-muted-foreground">NAME:</span>{' '}
          <span className="text-foreground font-semibold">
            {activeMetadata.name}
          </span>
          <span className="ml-2 inline-block align-middle">
            <StaleIndicator isStale={isStale} />
          </span>
        </div>

        {activeMetadata.endpoint && (
          <div className="flex gap-2">
            <span className="text-muted-foreground flex-shrink-0">
              ENDPOINT:
            </span>
            <span className="text-foreground break-all">{activeMetadata.endpoint}</span>
          </div>
        )}

        {activeMetadata.model && (
          <div>
            <span className="text-muted-foreground">MODEL:</span>{' '}
            <span className="text-foreground">{activeMetadata.model}</span>
          </div>
        )}

        {activeMetadata.version && (
          <div>
            <span className="text-muted-foreground">VERSION:</span>{' '}
            <span className="text-foreground">{activeMetadata.version}</span>
          </div>
        )}

        {activeMetadata.provider?.name && (
          <div>
            <span className="text-muted-foreground">CREATOR:</span>{' '}
            <span className="text-foreground">{activeMetadata.provider.name}</span>
          </div>
        )}

        <div>
          <span className="text-muted-foreground">STATUS:</span>{' '}
          <span className="text-[hsl(142_71%_45%)]">ACTIVE</span>
        </div>
      </div>

      {/* Standards badges */}
      <div className="flex flex-wrap gap-3 mb-4">
        {agentCard && (
          <span className="text-[hsl(188_83%_58%)]">[A2A COMPATIBLE]</span>
        )}
        {erc8004 && (
          <span className="text-[hsl(188_83%_58%)]">[ERC-8004]</span>
        )}
      </div>

      {/* Description as quoted block */}
      {activeMetadata.description && (
        <div className="border-l-2 border-muted-foreground pl-3 text-muted-foreground italic">
          {activeMetadata.description}
        </div>
      )}

      {/* Tags */}
      {activeMetadata.tags && activeMetadata.tags.length > 0 && (
        <div className="mt-4">
          <span className="text-muted-foreground">TAGS:</span>{' '}
          <span className="text-foreground">
            [{activeMetadata.tags.join('] [')}]
          </span>
        </div>
      )}
    </div>
  )
}
