import { useState } from 'react'
import { AgentMetadataSchema, type AgentMetadata } from '~/lib/schemas/agent-metadata'
import { getCapabilitiesByCategory } from '~/data/capabilities'
import { getModelOptions, findModelById } from '~/data/models'
import { getProviderOptions, getProviderUrl, findProviderById } from '~/data/providers'
import { ComboSelect } from '~/components/ui/ComboSelect'
import type { ZodError } from 'zod'

interface AgentRegistrationFormProps {
  onSubmit: (metadata: AgentMetadata) => Promise<void>
  isSubmitting?: boolean
  initialData?: Partial<AgentMetadata>
}

interface FieldError {
  [field: string]: string | undefined
}

// Shared form styles
const INPUT =
  'w-full bg-app-input border border-app-line rounded-lg px-3 py-2.5 text-ink-default font-mono text-sm placeholder:text-ink-faint focus:border-[hsl(var(--accent))] focus:outline-none transition-colors disabled:opacity-50'
const INPUT_ERR =
  'w-full bg-app-input border border-loss rounded-lg px-3 py-2.5 text-ink-default font-mono text-sm placeholder:text-ink-faint focus:border-loss focus:outline-none transition-colors disabled:opacity-50'
const LABEL = 'block font-mono text-[10px] uppercase tracking-[0.14em] text-ink-dull mb-1.5'
const HINT = 'mt-1.5 font-mono text-[10px] text-ink-faint tracking-wide'
const ERR_MSG = 'mt-1 font-mono text-[10px] text-loss tracking-wide'
const SECTION =
  'font-mono text-[10px] uppercase tracking-[0.14em] text-ink-faint mb-4 pb-2 border-b border-app-line'

const MODEL_OPTIONS = getModelOptions()
const PROVIDER_OPTIONS = getProviderOptions()
const CAPABILITIES_BY_CATEGORY = getCapabilitiesByCategory()

export function AgentRegistrationForm({
  onSubmit,
  isSubmitting = false,
  initialData,
}: AgentRegistrationFormProps) {
  const [name, setName] = useState(initialData?.name ?? '')
  const [description, setDescription] = useState(initialData?.description ?? '')
  const [version, setVersion] = useState(initialData?.version ?? '')
  const [image, setImage] = useState(initialData?.image ?? '')
  const [model, setModel] = useState(initialData?.model ?? '')
  const [endpoint, setEndpoint] = useState(initialData?.endpoint ?? '')
  const [providerName, setProviderName] = useState(initialData?.provider?.name ?? '')
  const [providerUrl, setProviderUrl] = useState(initialData?.provider?.url ?? '')
  const [capabilities, setCapabilities] = useState<string[]>(initialData?.capabilities ?? [])
  const [inputModes, setInputModes] = useState(initialData?.inputModes?.join(', ') ?? '')
  const [outputModes, setOutputModes] = useState(initialData?.outputModes?.join(', ') ?? '')
  const [errors, setErrors] = useState<FieldError>({})

  function validateField(field?: keyof AgentMetadata): boolean {
    const metadata = buildMetadata()
    const result = AgentMetadataSchema.safeParse(metadata)

    if (result.success) {
      if (field) {
        setErrors((prev) => ({ ...prev, [field]: undefined }))
      } else {
        setErrors({})
      }
      return true
    }

    const fieldErrors: FieldError = {}
    const zodError = result.error as ZodError
    for (const issue of zodError.issues) {
      const path = issue.path.join('.')
      if (!field || path === field || path.startsWith(`${field}.`)) {
        fieldErrors[path] = issue.message
      }
    }

    if (field) {
      setErrors((prev) => ({ ...prev, ...fieldErrors }))
    } else {
      setErrors(fieldErrors)
    }

    return false
  }

  function buildMetadata(): AgentMetadata {
    const metadata: AgentMetadata = {
      '@type': 'Agent',
      name: name.trim(),
      description: description.trim(),
      version: version.trim(),
    }

    if (image.trim()) metadata.image = image.trim()
    if (model.trim()) metadata.model = model.trim()
    if (endpoint.trim()) metadata.endpoint = endpoint.trim()

    if (providerName.trim() || providerUrl.trim()) {
      metadata.provider = {
        name: providerName.trim(),
        ...(providerUrl.trim() && { url: providerUrl.trim() }),
      }
    }

    if (capabilities.length > 0) {
      metadata.capabilities = capabilities
    }

    if (inputModes.trim()) {
      metadata.inputModes = inputModes
        .split(',')
        .map((m) => m.trim())
        .filter(Boolean)
    }

    if (outputModes.trim()) {
      metadata.outputModes = outputModes
        .split(',')
        .map((m) => m.trim())
        .filter(Boolean)
    }

    return metadata
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!validateField()) return
    const metadata = buildMetadata()
    await onSubmit(metadata)
  }

  function toggleCapability(cap: string) {
    if (capabilities.includes(cap)) {
      setCapabilities(capabilities.filter((c) => c !== cap))
    } else {
      setCapabilities([...capabilities, cap])
    }
  }

  function handleModelChange(val: string) {
    setModel(val)
    // Auto-select provider when selecting a known model
    const knownModel = findModelById(val)
    if (knownModel) {
      const provider = findProviderById(knownModel.providerId)
      if (provider) {
        setProviderName(provider.name)
        setProviderUrl(provider.url ?? '')
      }
    }
  }

  function handleProviderChange(val: string) {
    // val is provider name (display label) or custom text
    const knownProvider = PROVIDER_OPTIONS.find(
      (p) => p.label === val || p.value === val,
    )
    if (knownProvider) {
      setProviderName(knownProvider.label)
      const url = getProviderUrl(knownProvider.value)
      if (url) setProviderUrl(url)
    } else {
      setProviderName(val)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* === IDENTITY === */}
      <div>
        <div className={SECTION}>=== IDENTITY ===</div>
        <div className="space-y-4">
          <div>
            <label htmlFor="agent-name" className={LABEL}>
              Name <span className="text-[hsl(var(--accent))]">*</span>
            </label>
            <input
              id="agent-name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              onBlur={() => validateField('name')}
              placeholder="research-assistant"
              className={errors.name ? INPUT_ERR : INPUT}
              aria-invalid={!!errors.name}
              aria-describedby={errors.name ? 'agent-name-error' : undefined}
              disabled={isSubmitting}
            />
            {errors.name && (
              <p id="agent-name-error" className={ERR_MSG}>
                {errors.name}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="agent-description" className={LABEL}>
              Description <span className="text-[hsl(var(--accent))]">*</span>
            </label>
            <textarea
              id="agent-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              onBlur={() => validateField('description')}
              rows={3}
              placeholder="Analyzes research papers and synthesizes findings"
              className={errors.description ? INPUT_ERR : INPUT}
              aria-invalid={!!errors.description}
              aria-describedby={
                errors.description ? 'agent-description-error' : undefined
              }
              disabled={isSubmitting}
            />
            {errors.description && (
              <p id="agent-description-error" className={ERR_MSG}>
                {errors.description}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="agent-version" className={LABEL}>
              Version <span className="text-[hsl(var(--accent))]">*</span>
            </label>
            <input
              id="agent-version"
              type="text"
              value={version}
              onChange={(e) => setVersion(e.target.value)}
              onBlur={() => validateField('version')}
              placeholder="1.0.0"
              className={errors.version ? INPUT_ERR : INPUT}
              aria-invalid={!!errors.version}
              aria-describedby={errors.version ? 'agent-version-error' : undefined}
              disabled={isSubmitting}
            />
            <p className={HINT}>Semver format (e.g., 1.0.0, 2.1.3-beta)</p>
            {errors.version && (
              <p id="agent-version-error" className={ERR_MSG}>
                {errors.version}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* === REACHABILITY === */}
      <div>
        <div className={SECTION}>=== REACHABILITY ===</div>
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="agent-endpoint" className={LABEL}>
                Endpoint
              </label>
              <input
                id="agent-endpoint"
                type="url"
                value={endpoint}
                onChange={(e) => setEndpoint(e.target.value)}
                onBlur={() => validateField('endpoint')}
                placeholder="https://api.example.com/agent"
                className={errors.endpoint ? INPUT_ERR : INPUT}
                aria-invalid={!!errors.endpoint}
                disabled={isSubmitting}
              />
              {errors.endpoint && (
                <p className={ERR_MSG}>{errors.endpoint}</p>
              )}
            </div>

            <div>
              <label htmlFor="agent-model" className={LABEL}>
                Model
              </label>
              <ComboSelect
                id="agent-model"
                options={MODEL_OPTIONS}
                value={model}
                onChange={handleModelChange}
                placeholder="claude-opus-4-6"
                allowCustom
                groupBy
                disabled={isSubmitting}
              />
              <p className={HINT}>Select or type a custom model ID</p>
            </div>
          </div>

          <div>
            <label htmlFor="agent-image" className={LABEL}>
              Avatar URL
            </label>
            <input
              id="agent-image"
              type="url"
              value={image}
              onChange={(e) => setImage(e.target.value)}
              onBlur={() => validateField('image')}
              placeholder="https://example.com/agent-icon.png"
              className={errors.image ? INPUT_ERR : INPUT}
              aria-invalid={!!errors.image}
              disabled={isSubmitting}
            />
            {errors.image && <p className={ERR_MSG}>{errors.image}</p>}
          </div>
        </div>
      </div>

      {/* === PROVIDER === */}
      <div>
        <div className={SECTION}>=== PROVIDER ===</div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="agent-provider-name" className={LABEL}>
              Name
            </label>
            <ComboSelect
              id="agent-provider-name"
              options={PROVIDER_OPTIONS}
              value={providerName}
              onChange={handleProviderChange}
              placeholder="Anthropic"
              allowCustom
              disabled={isSubmitting}
            />
            {errors['provider.name'] && (
              <p className={ERR_MSG}>{errors['provider.name']}</p>
            )}
          </div>

          <div>
            <label htmlFor="agent-provider-url" className={LABEL}>
              Website
            </label>
            <input
              id="agent-provider-url"
              type="url"
              value={providerUrl}
              onChange={(e) => setProviderUrl(e.target.value)}
              onBlur={() => validateField('provider')}
              placeholder="https://anthropic.com"
              className={errors['provider.url'] ? INPUT_ERR : INPUT}
              disabled={isSubmitting}
            />
            {errors['provider.url'] && (
              <p className={ERR_MSG}>{errors['provider.url']}</p>
            )}
          </div>
        </div>
      </div>

      {/* === CAPABILITIES === */}
      <div>
        <div className={SECTION}>=== CAPABILITIES ===</div>
        <div className="space-y-4">
          {Object.entries(CAPABILITIES_BY_CATEGORY).map(([category, caps]) => (
            <div key={category}>
              <div className="font-mono text-[9px] uppercase tracking-[0.12em] text-ink-faint mb-2">
                {category}
              </div>
              <div className="flex flex-wrap gap-2">
                {caps.map((cap) => {
                  const selected = capabilities.includes(cap.id)
                  return (
                    <button
                      key={cap.id}
                      type="button"
                      onClick={() => toggleCapability(cap.id)}
                      disabled={isSubmitting}
                      title={cap.description}
                      className={`px-3 py-1.5 rounded-lg font-mono text-xs tracking-wider transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                        selected
                          ? 'bg-[hsl(var(--accent))/0.15] text-[hsl(var(--accent-faint))] border border-[hsl(var(--accent))/0.3] shadow-[0_0_8px_hsl(var(--accent)/0.1)]'
                          : 'bg-app-button text-ink-dull border border-app-line hover:text-ink-default hover:border-[hsl(var(--accent))/0.2]'
                      }`}
                    >
                      {cap.name}
                    </button>
                  )
                })}
              </div>
            </div>
          ))}
        </div>
        <p className={`${HINT} mt-3`}>
          Select capabilities your agent provides ({capabilities.length} selected)
        </p>
      </div>

      {/* === I/O CONTRACT === */}
      <div>
        <div className={SECTION}>=== I/O CONTRACT ===</div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="agent-input-modes" className={LABEL}>
              Input Modes
            </label>
            <input
              id="agent-input-modes"
              type="text"
              value={inputModes}
              onChange={(e) => setInputModes(e.target.value)}
              placeholder="text/plain, application/json"
              className={INPUT}
              disabled={isSubmitting}
            />
          </div>
          <div>
            <label htmlFor="agent-output-modes" className={LABEL}>
              Output Modes
            </label>
            <input
              id="agent-output-modes"
              type="text"
              value={outputModes}
              onChange={(e) => setOutputModes(e.target.value)}
              placeholder="text/markdown"
              className={INPUT}
              disabled={isSubmitting}
            />
          </div>
        </div>
        <p className={HINT}>Comma-separated MIME types or mode identifiers</p>
      </div>

      {/* Submit */}
      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full py-3 rounded-lg bg-[hsl(var(--accent))] hover:bg-[hsl(var(--accent-deep))] text-white font-mono text-sm uppercase tracking-[0.1em] font-bold transition-colors disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
      >
        {isSubmitting ? 'DEPLOYING...' : 'DEPLOY AGENT'}
      </button>
    </form>
  )
}
