import { beforeEach, describe, expect, it } from 'vitest'
import type { ActionFunctionArgs, LoaderFunctionArgs } from 'react-router'
import { action as trustScoreAction } from '../api+/v1.trust.score'
import { loader as evidenceLoader } from '../api+/v1.evidence.$id'
import { clearEvidenceStore } from '~/lib/evidence/store'

function makeActionArgs(body: unknown): ActionFunctionArgs {
  return {
    request: new Request('https://registry.local/api/v1/trust/score', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    }),
    params: {},
    context: {},
  } as ActionFunctionArgs
}

function makeLoaderArgs(id: string): LoaderFunctionArgs {
  return {
    request: new Request(`https://registry.local/api/v1/evidence/${id}`),
    params: { id },
    context: {},
  } as unknown as LoaderFunctionArgs
}

const FUTURE_TIMESTAMP = new Date(Date.now() + 60 * 60 * 1000).toISOString()

const BASE_REQUEST = {
  modelId: 'com.intuition.trust.default',
  version: '1.0.0',
  snapshotId: 'snapshot-a',
  snapshotTimestamp: FUTURE_TIMESTAMP,
  ttlSeconds: 3600,
  candidates: [
    {
      id: 'agent-a',
      inputs: {
        market_cap_wei: 1000,
        staker_count: 100,
        share_price_wei: 10,
      },
      claimIds: ['claim-1'],
      traversalPath: ['agent-a', 'has-capability', 'cap-1'],
      vaultSnapshots: [
        {
          termId: '0x01',
          marketCapWei: '1000',
          stakerCount: 100,
          sharePriceWei: '10',
        },
      ],
    },
    {
      id: 'agent-b',
      inputs: {
        market_cap_wei: 100,
        staker_count: 5,
        share_price_wei: 2,
      },
      claimIds: [],
      traversalPath: [],
      vaultSnapshots: [],
    },
  ],
}

describe('trust score + evidence endpoints', () => {
  beforeEach(() => {
    clearEvidenceStore()
  })

  it('returns score, confidence, and evidence references', async () => {
    const response = await trustScoreAction(makeActionArgs(BASE_REQUEST))
    expect(response.status).toBe(200)
    const json = await response.json()

    expect(json.data.results).toHaveLength(2)
    expect(json.data.results[0]).toHaveProperty('score')
    expect(json.data.results[0]).toHaveProperty('confidence')
    expect(json.data.results[0]).toHaveProperty('evidenceId')
    expect(typeof json.data.queryHash).toBe('string')
  })

  it('is deterministic for identical snapshot inputs', async () => {
    const first = await trustScoreAction(makeActionArgs(BASE_REQUEST))
    const second = await trustScoreAction(makeActionArgs(BASE_REQUEST))

    const firstJson = await first.json()
    const secondJson = await second.json()

    expect(secondJson.data).toEqual(firstJson.data)
  })

  it('resolves evidence bundle by id', async () => {
    const response = await trustScoreAction(makeActionArgs(BASE_REQUEST))
    const scoreJson = await response.json()
    const evidenceId = scoreJson.data.results[0].evidenceId

    const evidenceResponse = await evidenceLoader(makeLoaderArgs(evidenceId))
    expect(evidenceResponse.status).toBe(200)
    const evidenceJson = await evidenceResponse.json()
    expect(evidenceJson.data.id).toBe(evidenceId)
    expect(evidenceJson.data.modelId).toBe('com.intuition.trust.default')
  })

  it('returns not-found for missing evidence id', async () => {
    const response = await evidenceLoader(makeLoaderArgs('missing'))
    expect(response.status).toBe(404)
    const json = await response.json()
    expect(json.code).toBe('NOT_FOUND')
  })

  it('returns expired when evidence TTL window has passed', async () => {
    const response = await trustScoreAction(makeActionArgs({
      ...BASE_REQUEST,
      ttlSeconds: 60,
      snapshotTimestamp: '2020-01-01T00:00:00.000Z',
    }))
    const scoreJson = await response.json()
    const evidenceId = scoreJson.data.results[0].evidenceId

    const evidenceResponse = await evidenceLoader(makeLoaderArgs(evidenceId))
    expect(evidenceResponse.status).toBe(410)
    const evidenceJson = await evidenceResponse.json()
    expect(evidenceJson.code).toBe('EVIDENCE_EXPIRED')
  })
})
