import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

describe('GET /api/v1/health', () => {
  const baseEnv = { ...process.env }

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = {
      ...baseEnv,
      CHAIN: 'testnet',
      DEPLOY_ENV: 'staging',
    }
  })

  afterEach(() => {
    process.env = { ...baseEnv }
    vi.restoreAllMocks()
  })

  function createGetRequest() {
    return new Request('http://localhost:4101/api/v1/health', { method: 'GET' })
  }

  it('should return 200 with healthy status when no external services configured', async () => {
    // Ensure no external services are configured
    delete process.env.GRAPHQL_API_URL_PRIVATE
    delete process.env.PINATA_JWT

    const { loader } = await import('../api+/v1.health')
    const response = await loader({
      request: createGetRequest(),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.status).toBe('healthy')
    expect(body.checks.server.status).toBe('ok')
    expect(body.checks.graphql.status).toBe('unconfigured')
    expect(body.checks.ipfs.status).toBe('unconfigured')
  })

  it('should return proper chain and env fields from process.env', async () => {
    delete process.env.GRAPHQL_API_URL_PRIVATE
    delete process.env.PINATA_JWT

    const { loader } = await import('../api+/v1.health')
    const response = await loader({
      request: createGetRequest(),
      params: {},
      context: {},
    } as never)

    const body = await response.json()
    expect(body.chain).toBe('testnet')
    expect(body.env).toBe('staging')
  })

  it('should include timestamp in response', async () => {
    delete process.env.GRAPHQL_API_URL_PRIVATE
    delete process.env.PINATA_JWT

    const { loader } = await import('../api+/v1.health')
    const response = await loader({
      request: createGetRequest(),
      params: {},
      context: {},
    } as never)

    const body = await response.json()
    expect(body.timestamp).toBeDefined()
    // Verify it's a valid ISO timestamp
    const parsed = new Date(body.timestamp)
    expect(parsed.getTime()).not.toBeNaN()
  })
})
