import { z } from 'zod';

/**
 * Supported skill platforms.
 * v3: Platform is in metadata (not graph) - installation info.
 */
export const SKILL_PLATFORM_OPTIONS = [
  'mcp',
  'claude-code',
  'openclaw',
  'openai',
  'x402',
  'other',
] as const;

export const SkillPlatform = z.enum(SKILL_PLATFORM_OPTIONS);

/**
 * Transport/connection type for skill invocation.
 * Tells agents HOW to connect after installing.
 */
export const SkillTransport = z.enum(['stdio', 'sse', 'http', 'websocket']);

/**
 * Zod schema for Skill IPFS metadata (v3).
 *
 * v3 Model: Metadata is purely "how to install and use me."
 * The graph handles: capabilities (has-capability), relationships (is claims),
 * version history (has-metadata chain).
 *
 * @example
 * ```typescript
 * const metadata = {
 *   "@type": "Skill",
 *   name: "github-mcp-server",
 *   description: "Read and write GitHub issues, PRs, and code",
 *   version: "1.3.0",
 *   // Installation (reachability)
 *   platform: "mcp",
 *   installUri: "npx @modelcontextprotocol/server-github",
 *   // I/O contract
 *   inputModes: ["application/json"],
 *   outputModes: ["application/json"],
 *   // Context (non-graph)
 *   author: "Anthropic",
 *   permissions: ["repo:read", "issues:write"]
 * };
 *
 * SkillMetadataSchema.parse(metadata);
 * ```
 */
export const SkillMetadataSchema = z.object({
  /**
   * Type discriminator for skill metadata.
   * Must be the literal string "Skill".
   */
  '@type': z.literal('Skill'),

  /**
   * Machine identifier for the skill (kebab-case recommended).
   */
  name: z.string().trim().min(1, 'name is required').max(100, 'name must be <= 100 chars'),

  /**
   * Natural language description.
   */
  description: z
    .string()
    .trim()
    .min(1, 'description is required')
    .max(500, 'description must be <= 500 chars'),

  /**
   * Semantic version of this metadata version.
   * Must follow semver format (e.g., "1.0.0", "2.1.3-beta").
   */
  version: z.string().regex(
    /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$/,
    'Must be valid semver format'
  ),

  // ========== INSTALLATION (reachability) ==========
  /**
   * Platform or protocol this skill is built for.
   */
  platform: SkillPlatform,

  /**
   * URI for installing the skill.
   * Format depends on platform (e.g., "mcp://install/...", "npx ...").
   */
  installUri: z.string().trim().min(1).max(256).optional(),

  /**
   * How an agent connects after installing.
   * - stdio: spawn a subprocess and communicate over stdin/stdout (most MCP servers)
   * - sse: connect to a Server-Sent Events stream
   * - http: call an HTTP endpoint directly
   * - websocket: open a persistent WebSocket connection
   */
  transport: SkillTransport.optional(),

  /**
   * Environment variables the agent must supply before invoking this skill.
   * Sourced from MCP registry environmentVariables field.
   */
  requiredEnvVars: z.array(z.object({
    name: z.string().trim().min(1).max(64),
    description: z.string().trim().max(256).optional(),
    isSecret: z.boolean().optional(),
  })).max(20).optional(),

  // ========== I/O CONTRACT ==========
  /**
   * Supported input MIME types or mode identifiers.
   */
  inputModes: z.array(z.string().trim().min(1)).max(10).optional(),

  /**
   * Supported output MIME types or mode identifiers.
   */
  outputModes: z.array(z.string().trim().min(1)).max(10).optional(),

  // ========== CONTEXT (non-graph, informational) ==========
  /**
   * Author name or organization.
   */
  author: z.string().trim().min(1).max(120).optional(),

  /**
   * Required permissions (format depends on platform).
   */
  permissions: z.array(z.string().trim().min(1).max(64)).max(50).optional(),

  /**
   * Optional URL to an image representing the skill.
   */
  image: z.string().url().optional(),

  /**
   * Optional extended description.
   */
  longDescription: z.string().trim().min(1).max(4000).optional(),
}).superRefine((value, ctx) => {
  if (value.installUri) {
    const isHttpLike = /^https?:\/\//.test(value.installUri)
    const isMcpLike = /^mcp:\/\//.test(value.installUri)
    const isNpmLike = /^npm:/.test(value.installUri) || /^npx /.test(value.installUri)
    if (!isHttpLike && !isMcpLike && !isNpmLike) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'installUri must be http(s), mcp://, npm:, or npx command format',
        path: ['installUri'],
      })
    }
    if (value.platform === 'mcp' && !isMcpLike && !isNpmLike) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'mcp platform requires installUri in mcp:// or npx format',
        path: ['installUri'],
      })
    }
  }
});

/**
 * TypeScript type inferred from the Skill metadata schema.
 */
export type SkillMetadataPayload = z.infer<typeof SkillMetadataSchema>;

/**
 * TypeScript type for skill platforms.
 */
export type SkillPlatformType = z.infer<typeof SkillPlatform>;

/**
 * TypeScript type for skill transport.
 */
export type SkillTransportType = z.infer<typeof SkillTransport>;
