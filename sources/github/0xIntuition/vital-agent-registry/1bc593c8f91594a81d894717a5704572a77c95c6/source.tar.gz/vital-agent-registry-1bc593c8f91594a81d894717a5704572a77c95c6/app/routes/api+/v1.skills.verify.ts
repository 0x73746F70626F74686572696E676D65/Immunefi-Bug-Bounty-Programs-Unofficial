import type { LoaderFunctionArgs, ActionFunctionArgs } from 'react-router'
import { createRepository } from '~/data/repository/provider'
import { batchVerifySchema } from '~/lib/api/validation'
import { handleOptions, parseJsonBody, jsonResponse, errorResponse } from '~/lib/api/types'

// GET returns 405
export async function loader({ request }: LoaderFunctionArgs) {
  const optionsResponse = handleOptions(request)
  if (optionsResponse) return optionsResponse

  return errorResponse(
    'Method not allowed. Use POST to verify skills.',
    'METHOD_NOT_ALLOWED',
    405
  )
}

// POST accepts { skill_ids: string[] }
export async function action({ request }: ActionFunctionArgs) {
  const optionsResponse = handleOptions(request)
  if (optionsResponse) return optionsResponse

  const parsed = await parseJsonBody(request, batchVerifySchema)
  if ('error' in parsed) return parsed.error

  const { skill_ids } = parsed.data
  const repo = createRepository()

  // Fetch all skills concurrently
  const results = await Promise.all(
    skill_ids.map(async (id) => {
      const skill = await repo.findSkill(id)
      if (!skill) {
        return {
          id,
          found: false,
          status: null,
          safetySignal: null,
        }
      }
      return {
        id,
        found: true,
        status: skill.safetySignal.status,
        safetySignal: skill.safetySignal,
      }
    })
  )

  return jsonResponse(results)
}
