import { useNavigate, useLoaderData } from 'react-router'
import type { Route } from './+types/skills.$skillId'
import { ArrowLeft, Share2, ShieldAlert } from 'lucide-react'
import { SaveButton } from '~/components/ui/SaveButton'
import { createRepository } from '~/data'
import { getIndexerLagBlocks } from '~/lib/indexer-lag.server'
import { RegistryLayout } from '~/components/layout/RegistryLayout'
import { NotFound } from '~/components/ui/NotFound'
import {
  SkillIdentityZone,
  SkillSafetyZone,
  SkillClaimsZone,
  PermissionsSection,
  AgentViewSafetyZone,
  ApiResponsePreview,
} from '~/components/profile'
import { TrustGraph } from '~/components/graph/TrustGraph'
import { PlatformBadge } from '~/components/registry/PlatformBadge'
import { StaleBanner } from '~/components/ui/StaleBanner'
import { StaleIndicator } from '~/components/ui/StaleIndicator'
import { useViewMode } from '~/lib/providers/view-mode'
import { useIPFSFallback } from '~/lib/hooks/useIPFSFallback'
import { Badge } from '~/components/ui/Badge'
import { generateAvatar } from '~/lib/avatar'
import type { Skill } from '~/types'

export function meta({ data }: Route.MetaArgs) {
  const name = data?.skill?.metadata?.name ?? 'Skill'
  return [
    { title: `${name} — Intuition` },
    { name: 'description', content: `Trust profile for ${name} on Intuition.` },
  ]
}

export async function loader({ params }: Route.LoaderArgs) {
  const { skillId } = params
  const repo = createRepository()
  const [skill, agentResult, skillResult, indexerLagBlocks] = await Promise.all([
    repo.findSkill(skillId),
    repo.listAgents({ limit: 100 }),
    repo.listSkills({ limit: 100 }),
    getIndexerLagBlocks(),
  ])
  return {
    skill,
    allAgents: agentResult.items,
    allSkills: skillResult.items,
    indexerLagBlocks,
  }
}

function SkillTerminalIdentity({ skill }: { skill: Skill }) {
  const { data: resolvedMetadata, isStale } = useIPFSFallback(
    skill.metadata.metadataUri,
    skill.metadata,
    { timeoutMs: 3000 },
  )
  const metadata = resolvedMetadata ?? skill.metadata

  return (
    <div className="rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] p-4 font-mono text-sm">
      <div className="text-muted-foreground mb-4">=== SKILL IDENTITY ===</div>

      <div className="space-y-1 mb-4">
        <div>
          <span className="text-muted-foreground">NAME:</span>{' '}
          <span className="text-foreground font-semibold">
            {metadata.name}
          </span>
          <span className="ml-2 inline-block align-middle">
            <StaleIndicator isStale={isStale} />
          </span>
        </div>

        <div>
          <span className="text-muted-foreground">PLATFORM:</span>{' '}
          <span className="text-foreground">[{skill.platform.name}]</span>
        </div>

        {metadata.version && (
          <div>
            <span className="text-muted-foreground">VERSION:</span>{' '}
            <span className="text-foreground">{metadata.version}</span>
          </div>
        )}

        {metadata.author && (
          <div>
            <span className="text-muted-foreground">AUTHOR:</span>{' '}
            <span className="text-foreground">{metadata.author}</span>
          </div>
        )}

        {metadata.installUri && (
          <div className="flex gap-2">
            <span className="text-muted-foreground flex-shrink-0">
              INSTALL_URI:
            </span>
            <span className="text-foreground break-all">
              {metadata.installUri}
            </span>
          </div>
        )}

        {metadata.permissions.length > 0 && (
          <div>
            <span className="text-muted-foreground">PERMISSIONS:</span>{' '}
            <span className="text-foreground">
              [{metadata.permissions.join(', ')}]
            </span>
          </div>
        )}
      </div>

      {/* Description as quoted block */}
      {metadata.description && (
        <div className="border-l-2 border-muted-foreground pl-3 text-muted-foreground italic">
          {metadata.description}
        </div>
      )}
    </div>
  )
}

export default function SkillProfilePage() {
  const navigate = useNavigate()
  const { skill, allAgents, allSkills, indexerLagBlocks } = useLoaderData<typeof loader>()
  const { isAgentView } = useViewMode()
  const { isStale } = useIPFSFallback(
    skill?.metadata?.metadataUri,
    skill?.metadata,
    { timeoutMs: 3000 },
  )

  if (!skill) {
    return (
      <RegistryLayout>
        <NotFound message="Skill not found" />
      </RegistryLayout>
    )
  }

  const isFlagged = skill.safetySignal.status === 'flagged'

  return (
    <RegistryLayout>
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <StaleBanner chainHead={indexerLagBlocks} indexerHead={0} />
        {/* Flagged Warning Banner - Top of Page */}
        {isFlagged && skill.safetySignal.flagReason && (
          <div
            className={
              isAgentView
                ? 'mb-6 p-4 rounded border-2 border-[hsl(0_84%_60%)] bg-[hsl(0_84%_60%)]/10 font-mono text-sm'
                : 'mb-6 p-4 rounded-lg border-l-4 border-l-[hsl(0_84%_60%)] bg-[hsl(0_84%_60%)]/10'
            }
          >
            {isAgentView ? (
              <div>
                <div className="text-[hsl(0_84%_60%)] font-bold text-lg mb-2 animate-pulse">
                  [!! WARNING: FLAGGED SKILL !!]
                </div>
                <div className="text-foreground mb-1">
                  <span className="text-muted-foreground">REASON:</span>{' '}
                  {skill.safetySignal.flagReason}
                </div>
                <div className="text-muted-foreground text-xs">
                  USE_AT_OWN_RISK - REVIEW_SAFETY_SIGNALS_BEFORE_INSTALL
                </div>
              </div>
            ) : (
              <div className="flex items-start gap-3">
                <ShieldAlert className="w-6 h-6 text-[hsl(0_84%_60%)] flex-shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-[hsl(0_84%_60%)] text-lg mb-2">
                    ⚠️ This skill has been flagged as potentially unsafe
                  </div>
                  <div className="text-base text-foreground mb-2">
                    <strong>Reason:</strong> {skill.safetySignal.flagReason}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Use at your own risk. Review safety signals below before
                    installing this skill.
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Sticky Header */}
        <div className="sticky top-0 z-20 flex items-center justify-between mb-6 pb-4 bg-app-box-dark/80 backdrop-blur-md border-b border-app-line">
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="flex h-10 w-10 items-center justify-center rounded-lg bg-app-button hover:bg-app-button-hover transition-colors flex-shrink-0"
              aria-label="Go back"
            >
              <ArrowLeft className="h-5 w-5 text-ink-default" />
            </button>
            <img
              src={skill.metadata.image ?? generateAvatar(skill.id)}
              alt={skill.metadata.name}
              className="w-10 h-10 rounded-lg object-cover flex-shrink-0"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="font-mono text-xl font-semibold text-foreground truncate">
                  {skill.metadata.name}
                </h1>
                {skill.metadata.version && (
                  <Badge label={`v${skill.metadata.version}`} />
                )}
                <StaleIndicator isStale={isStale} />
              </div>
              <div className="mt-0.5">
                <PlatformBadge platform={skill.platform} size="sm" />
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <SaveButton entityId={skill.id} entityType="skill" />
            <button
              type="button"
              onClick={() => {
                // Share functionality
                if (navigator.share) {
                  navigator.share({
                    title: skill.metadata.name,
                    text: skill.metadata.description,
                    url: window.location.href,
                  })
                } else {
                  navigator.clipboard.writeText(window.location.href)
                }
              }}
              className="flex h-10 w-10 items-center justify-center rounded-lg bg-app-button hover:bg-app-button-hover transition-colors"
              aria-label="Share"
            >
              <Share2 className="h-4 w-4 text-foreground" />
            </button>
          </div>
        </div>

        {/* 4-Zone Layout */}
        <div className="space-y-6">
          {isAgentView ? (
            <>
              {/* Agent-view zones */}
              <SkillTerminalIdentity skill={skill} />

              {/* Safety Dashboard - the security terminal */}
              <AgentViewSafetyZone skill={skill} />

              {/* Capabilities - terminal list */}
              <div className="rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] p-4 font-mono text-sm">
                <div className="text-muted-foreground mb-4">
                  === CAPABILITIES PROVIDED ===
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {skill.capabilities.map((cap) => (
                    <div
                      key={cap.id}
                      className="text-foreground border border-border/50 px-3 py-2 rounded"
                    >
                      [{cap.name}]
                    </div>
                  ))}
                </div>
                {skill.capabilities.length === 0 && (
                  <div className="text-muted-foreground italic">
                    NO_CAPABILITIES
                  </div>
                )}
              </div>

              {/* Compatibility - terminal list */}
              <div className="rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] p-4 font-mono text-sm">
                <div className="text-muted-foreground mb-4">
                  === COMPATIBILITY ===
                </div>
                <div>
                  <span className="text-muted-foreground">PLATFORM:</span>{' '}
                  <span className="text-foreground">
                    [{skill.platform.name}]
                  </span>
                </div>
                {skill.platform.url && (
                  <div className="mt-2 flex gap-2">
                    <span className="text-muted-foreground flex-shrink-0">
                      URL:
                    </span>
                    <span className="text-foreground break-all">
                      {skill.platform.url}
                    </span>
                  </div>
                )}
              </div>

              {/* Trust Network - 1-hop neighborhood graph */}
              {skill.triples.length > 0 ? (
                <div className="rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] overflow-hidden">
                  <div className="p-4 font-mono text-sm">
                    <div className="text-muted-foreground mb-2">=== TRUST NETWORK ===</div>
                    <div className="text-muted-foreground text-xs mb-4">1-HOP NEIGHBORHOOD GRAPH</div>
                  </div>
                  <div className="h-[350px]">
                    <TrustGraph
                      agents={allAgents}
                      skills={allSkills}
                      focusEntityId={skill.id}
                      onNodeClick={(id, type) => navigate(type === 'agent' ? `/agents/${id}` : `/skills/${id}`)}
                      compact
                      className="h-full w-full"
                    />
                  </div>
                </div>
              ) : (
                <div className="rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] p-4 font-mono text-sm">
                  <div className="text-muted-foreground mb-2">=== TRUST NETWORK ===</div>
                  <div className="text-muted-foreground italic">NO_CONNECTIONS_FOUND</div>
                </div>
              )}

              {/* API Response Preview */}
              <ApiResponsePreview
                data={skill}
                endpoint={`/api/v1/skills/${skill.id}`}
              />
            </>
          ) : (
            <>
              {/* Human-view zones */}
              <SkillIdentityZone skill={skill} />
              <SkillSafetyZone skill={skill} />
              <SkillClaimsZone skill={skill} />
              {skill.metadata.permissions.length > 0 && (
                <PermissionsSection permissions={skill.metadata.permissions} />
              )}

              {/* Trust Network - 1-hop neighborhood graph */}
              {skill.triples.length > 0 ? (
                <section className="rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] overflow-hidden">
                  <div className="p-4 border-b border-border">
                    <h2 className="font-mono text-xs tracking-widest uppercase text-ink-dull">Trust Network</h2>
                    <p className="font-mono text-xs text-ink-faint mt-1">
                      Agents and skills connected to this skill
                    </p>
                  </div>
                  <div className="h-[350px]">
                    <TrustGraph
                      agents={allAgents}
                      skills={allSkills}
                      focusEntityId={skill.id}
                      onNodeClick={(id, type) => navigate(type === 'agent' ? `/agents/${id}` : `/skills/${id}`)}
                      compact
                      className="h-full w-full"
                    />
                  </div>
                </section>
              ) : (
                <section className="rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] p-4">
                  <h2 className="font-mono text-xs tracking-widest uppercase text-ink-dull mb-2">Trust Network</h2>
                  <p className="font-mono text-xs text-ink-faint">No connections found for this skill</p>
                </section>
              )}
            </>
          )}
        </div>
      </div>
    </RegistryLayout>
  )
}
