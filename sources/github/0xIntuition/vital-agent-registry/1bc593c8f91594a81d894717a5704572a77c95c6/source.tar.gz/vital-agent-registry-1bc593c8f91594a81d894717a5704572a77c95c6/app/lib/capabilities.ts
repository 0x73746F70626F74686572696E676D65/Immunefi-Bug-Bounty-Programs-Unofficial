/**
 * Capability name normalization and validation utilities.
 *
 * Capabilities are normalized to a canonical kebab-case format for consistent
 * storage and comparison. This handles various input formats like spaces,
 * underscores, camelCase, and PascalCase.
 *
 * Normalized format:
 * - Lowercase letters and numbers
 * - Hyphens as word separators
 * - Must start with a letter
 * - No consecutive hyphens
 * - No trailing hyphens
 *
 * @module capabilities
 */

/**
 * Normalizes a capability name to canonical kebab-case format.
 *
 * Handles multiple input formats:
 * - Spaces: "Code Review" → "code-review"
 * - Underscores: "code_review" → "code-review"
 * - camelCase: "codeReview" → "code-review"
 * - PascalCase: "CodeReview" → "code-review"
 * - Mixed: "Code_ReviewAPI" → "code-review-api"
 *
 * @param name - The capability name to normalize
 * @returns Normalized capability name in kebab-case
 *
 * @example
 * ```typescript
 * normalizeCapabilityName("Code Review");        // "code-review"
 * normalizeCapabilityName("code_review");        // "code-review"
 * normalizeCapabilityName("codeReview");         // "code-review"
 * normalizeCapabilityName("CodeReview");         // "code-review"
 * normalizeCapabilityName("API_Integration");    // "api-integration"
 * normalizeCapabilityName("HTTPClient");         // "http-client"
 * ```
 */
export function normalizeCapabilityName(name: string): string {
  return (
    name
      // Insert hyphen before uppercase letters that follow lowercase or digits (camelCase)
      .replace(/([a-z0-9])([A-Z])/g, '$1-$2')
      // Insert hyphen before uppercase letters followed by lowercase (acronyms)
      .replace(/([A-Z]+)([A-Z][a-z])/g, '$1-$2')
      // Replace spaces and underscores with hyphens
      .replace(/[\s_]+/g, '-')
      // Convert to lowercase
      .toLowerCase()
      // Remove any consecutive hyphens
      .replace(/-+/g, '-')
      // Remove leading/trailing hyphens
      .replace(/^-+|-+$/g, '')
  );
}

/**
 * Validates a capability name against the canonical format.
 *
 * Valid format:
 * - Must start with a lowercase letter
 * - Can contain lowercase letters, numbers, and hyphens
 * - Cannot have consecutive hyphens
 * - Cannot end with a hyphen
 *
 * Pattern: `^[a-z][a-z0-9-]*$` with no consecutive hyphens
 *
 * @param name - The capability name to validate
 * @returns True if the name is valid, false otherwise
 *
 * @example
 * ```typescript
 * isValidCapabilityName("code-review");      // true
 * isValidCapabilityName("api-integration");  // true
 * isValidCapabilityName("http2");            // true
 * isValidCapabilityName("Code-Review");      // false (uppercase)
 * isValidCapabilityName("code_review");      // false (underscore)
 * isValidCapabilityName("-code-review");     // false (leading hyphen)
 * isValidCapabilityName("code--review");     // false (consecutive hyphens)
 * isValidCapabilityName("code-review-");     // false (trailing hyphen)
 * isValidCapabilityName("2code");            // false (starts with number)
 * ```
 */
export function isValidCapabilityName(name: string): boolean {
  // Check basic pattern: starts with letter, contains only lowercase/numbers/hyphens
  if (!/^[a-z][a-z0-9-]*$/.test(name)) {
    return false;
  }

  // Check for consecutive hyphens
  if (name.includes('--')) {
    return false;
  }

  // Check for trailing hyphen
  if (name.endsWith('-')) {
    return false;
  }

  return true;
}
