import type { Capability, Platform, TrustTier, SafetyStatus } from '~/types'

interface FilterPanelProps {
  capabilities: Capability[]
  platforms: Platform[]
  filters: {
    capability: string | null
    trustTier: TrustTier | null
    platformId: string | null
    safetyStatus: SafetyStatus | null
  }
  onFilterChange: (filters: FilterPanelProps['filters']) => void
  entityType: 'all' | 'agents' | 'skills'
  className?: string
}

/**
 * FilterPanel — context-aware filter dropdowns
 *
 * Platform and safety filters are hidden when viewing agents-only.
 */
export function FilterPanel({
  capabilities,
  platforms,
  filters,
  onFilterChange,
  entityType,
  className = '',
}: FilterPanelProps) {
  const hasActiveFilters = Object.values(filters).some(v => v !== null)
  const showPlatformFilter = entityType === 'all' || entityType === 'skills'
  const showSafetyFilter = entityType === 'all' || entityType === 'skills'

  // Group capabilities by category for organized dropdown
  const capsByCategory = capabilities.reduce((acc, cap) => {
    if (!acc[cap.category]) acc[cap.category] = []
    acc[cap.category].push(cap)
    return acc
  }, {} as Record<string, Capability[]>)

  const handleFilterChange = (key: keyof typeof filters, value: string | null) => {
    onFilterChange({ ...filters, [key]: value })
  }

  const clearAllFilters = () => {
    onFilterChange({
      capability: null,
      trustTier: null,
      platformId: null,
      safetyStatus: null,
    })
  }

  return (
    <div className={`flex flex-wrap items-center gap-2 ${className}`}>
      {/* Capability filter */}
      <select
        value={filters.capability || ''}
        onChange={(e) => handleFilterChange('capability', e.target.value || null)}
        className="rounded-lg border border-app-line bg-app-input px-3 py-1.5 font-mono text-xs uppercase tracking-wider text-foreground focus:border-[hsl(var(--accent))] focus:outline-none focus:ring-1 focus:ring-[hsl(var(--accent)/0.3)]"
      >
        <option value="">All capabilities</option>
        {Object.entries(capsByCategory).map(([category, caps]) => (
          <optgroup key={category} label={category}>
            {caps.map((cap) => (
              <option key={cap.id} value={cap.id}>
                {cap.name}
              </option>
            ))}
          </optgroup>
        ))}
      </select>

      {/* Trust tier filter */}
      <select
        value={filters.trustTier || ''}
        onChange={(e) => handleFilterChange('trustTier', (e.target.value || null) as TrustTier | null)}
        className="rounded-lg border border-app-line bg-app-input px-3 py-1.5 font-mono text-xs uppercase tracking-wider text-foreground focus:border-[hsl(var(--accent))] focus:outline-none focus:ring-1 focus:ring-[hsl(var(--accent)/0.3)]"
      >
        <option value="">All tiers</option>
        <option value="platinum">Platinum</option>
        <option value="gold">Gold</option>
        <option value="silver">Silver</option>
        <option value="bronze">Bronze</option>
        <option value="unranked">Unranked</option>
      </select>

      {/* Platform filter (skills only) */}
      {showPlatformFilter && (
        <select
          value={filters.platformId || ''}
          onChange={(e) => handleFilterChange('platformId', e.target.value || null)}
          className="rounded-lg border border-app-line bg-app-input px-3 py-1.5 font-mono text-xs uppercase tracking-wider text-foreground focus:border-[hsl(var(--accent))] focus:outline-none focus:ring-1 focus:ring-[hsl(var(--accent)/0.3)]"
        >
          <option value="">All platforms</option>
          {platforms.map((platform) => (
            <option key={platform.id} value={platform.id}>
              {platform.name}
            </option>
          ))}
        </select>
      )}

      {/* Safety status filter (skills only) */}
      {showSafetyFilter && (
        <select
          value={filters.safetyStatus || ''}
          onChange={(e) => handleFilterChange('safetyStatus', (e.target.value || null) as SafetyStatus | null)}
          className="rounded-lg border border-app-line bg-app-input px-3 py-1.5 font-mono text-xs uppercase tracking-wider text-foreground focus:border-[hsl(var(--accent))] focus:outline-none focus:ring-1 focus:ring-[hsl(var(--accent)/0.3)]"
        >
          <option value="">All statuses</option>
          <option value="verified">Verified</option>
          <option value="unverified">Unverified</option>
          <option value="flagged">Flagged</option>
        </select>
      )}

      {/* Clear filters button */}
      {hasActiveFilters && (
        <button
          type="button"
          onClick={clearAllFilters}
          className="rounded-lg border border-app-line bg-app-button px-3 py-1.5 font-mono text-xs uppercase tracking-wider text-foreground hover:bg-app-button-hover"
        >
          Clear filters
        </button>
      )}
    </div>
  )
}
