import { useState, useMemo } from 'react'
import { useLoaderData } from 'react-router'
import { createRepository } from '~/data'
import { getIndexerLagBlocks } from '~/lib/indexer-lag.server'
import type { TrustTier, SafetyStatus } from '~/types'
import type { SortField } from '~/types/repository'
import { RegistryLayout } from '~/components/layout/RegistryLayout'
import {
  SearchBar,
  FilterPanel,
  SortSelect,
  EntityTabs,
  RegistryGrid,
  EmptyState,
} from '~/components/registry'
import type { RegistryItem } from '~/components/registry'
import { AgentViewGrid } from '~/components/registry/AgentViewGrid'
import { QueryVisualization } from '~/components/registry/QueryVisualization'
import { useViewMode } from '~/lib/providers/view-mode'
import { ErrorBoundary } from '~/components/ui/ErrorBoundary'
import { StaleBanner } from '~/components/ui/StaleBanner'

export function meta() {
  return [
    { title: 'Agent Registry — Intuition' },
    { name: 'description', content: 'Discover and evaluate AI agents and skills with trust-weighted signals on Intuition.' },
  ]
}

export async function loader() {
  const repo = createRepository()
  const [agentResult, skillResult, capabilities, platforms, indexerLagBlocks] = await Promise.all([
    repo.listAgents({ limit: 50 }),
    repo.listSkills({ limit: 50 }),
    repo.listCapabilities(),
    repo.listPlatforms(),
    getIndexerLagBlocks(),
  ])
  return {
    agents: agentResult.items,
    skills: skillResult.items,
    capabilities,
    platforms,
    indexerLagBlocks,
  }
}

export default function RegistryHomePage() {
  const { agents, skills, capabilities, platforms, indexerLagBlocks } = useLoaderData<typeof loader>()
  const { isAgentView } = useViewMode()

  // Filter state
  const [entityType, setEntityType] = useState<'all' | 'agents' | 'skills'>('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [filters, setFilters] = useState<{
    capability: string | null
    trustTier: TrustTier | null
    platformId: string | null
    safetyStatus: SafetyStatus | null
  }>({
    capability: null,
    trustTier: null,
    platformId: null,
    safetyStatus: null,
  })
  const [sortBy, setSortBy] = useState<SortField>('trust')

  // Client-side filtering and sorting
  const filteredItems = useMemo(() => {
    // Step 1: Combine agents and skills into tagged items
    let items: RegistryItem[] = []

    if (entityType === 'all' || entityType === 'agents') {
      items = items.concat(agents.map(agent => ({ type: 'agent' as const, entity: agent })))
    }
    if (entityType === 'all' || entityType === 'skills') {
      items = items.concat(skills.map(skill => ({ type: 'skill' as const, entity: skill })))
    }

    // Step 2: Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase()
      items = items.filter(item => {
        const { entity } = item
        const nameMatch = entity.metadata.name.toLowerCase().includes(query)
        const descMatch = entity.metadata.description.toLowerCase().includes(query)
        const capMatch = entity.capabilities.some(cap =>
          cap.name.toLowerCase().includes(query)
        )
        return nameMatch || descMatch || capMatch
      })
    }

    // Step 3: Filter by capability
    if (filters.capability) {
      items = items.filter(item =>
        item.entity.capabilities.some(cap => cap.id === filters.capability)
      )
    }

    // Step 4: Filter by trust tier
    if (filters.trustTier) {
      items = items.filter(item =>
        item.entity.trustSignal.tier === filters.trustTier
      )
    }

    // Step 5: Filter by platform (skills only)
    if (filters.platformId) {
      items = items.filter(item => {
        if (item.type === 'skill') {
          return item.entity.platform.id === filters.platformId
        }
        return false
      })
    }

    // Step 6: Filter by safety status (skills only)
    if (filters.safetyStatus) {
      items = items.filter(item => {
        if (item.type === 'skill') {
          return item.entity.safetySignal.status === filters.safetyStatus
        }
        return false
      })
    }

    // Step 7: Sort
    items.sort((a, b) => {
      switch (sortBy) {
        case 'trust': {
          const aPercentile = a.entity.trustSignal.percentile
          const bPercentile = b.entity.trustSignal.percentile
          return bPercentile - aPercentile
        }
        case 'name':
          return a.entity.metadata.name.localeCompare(b.entity.metadata.name)
        case 'recent': {
          const aTime = new Date(a.entity.metadata.createdAt || 0).getTime()
          const bTime = new Date(b.entity.metadata.createdAt || 0).getTime()
          return bTime - aTime
        }
        case 'stakers': {
          const aCount = a.entity.trustSignal.stakerCount
          const bCount = b.entity.trustSignal.stakerCount
          return bCount - aCount
        }
        case 'safety': {
          // Skills first (have safety signals), then by safety ratio desc
          if (a.type === 'skill' && b.type !== 'skill') return -1
          if (a.type !== 'skill' && b.type === 'skill') return 1
          if (a.type === 'skill' && b.type === 'skill') {
            return b.entity.safetySignal.safetyRatio - a.entity.safetySignal.safetyRatio
          }
          return 0
        }
        default:
          return 0
      }
    })

    return items
  }, [agents, skills, entityType, searchQuery, filters, sortBy])

  // Counts for tabs
  const counts = useMemo(() => {
    const allCount = agents.length + skills.length
    return {
      all: allCount,
      agents: agents.length,
      skills: skills.length,
    }
  }, [agents, skills])

  // Helper to check if any filters are active
  const hasActiveFilters = Object.values(filters).some(value => value !== null)

  // Clear all filters
  const clearFilters = () => {
    setFilters({
      capability: null,
      trustTier: null,
      platformId: null,
      safetyStatus: null,
    })
    setSearchQuery('')
  }

  return (
    <RegistryLayout
      header={
        <div className="space-y-4 py-4">
          <div className="flex flex-col gap-1">
            <h1 className="font-mono text-2xl font-semibold text-foreground">Agent & Skill Registry</h1>
            <p className="font-mono text-xs text-ink-dull">
              Discover AI agents and skills with trust signals from the Intuition protocol
            </p>
          </div>
          <EntityTabs value={entityType} onChange={setEntityType} counts={counts} />
          <div className="rounded-xl bg-app-box-light p-4 space-y-3">
            <SearchBar value={searchQuery} onChange={setSearchQuery} />
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <FilterPanel
                capabilities={capabilities}
                platforms={platforms}
                filters={filters}
                onFilterChange={setFilters}
                entityType={entityType}
              />
              <SortSelect value={sortBy} onChange={setSortBy} />
            </div>
          </div>
        </div>
      }
    >
      <ErrorBoundary>
        <div className="space-y-4 py-6">
          <StaleBanner chainHead={indexerLagBlocks} indexerHead={0} />
          {filteredItems.length === 0 ? (
            <EmptyState
              query={searchQuery}
              hasFilters={hasActiveFilters}
              onClearFilters={clearFilters}
            />
          ) : isAgentView ? (
            <>
              <QueryVisualization
                entityType={entityType}
                searchQuery={searchQuery}
                filters={filters}
                sortBy={sortBy}
                resultCount={filteredItems.length}
              />
              <AgentViewGrid items={filteredItems} />
            </>
          ) : (
            <RegistryGrid items={filteredItems} />
          )}
        </div>
      </ErrorBoundary>
    </RegistryLayout>
  )
}
