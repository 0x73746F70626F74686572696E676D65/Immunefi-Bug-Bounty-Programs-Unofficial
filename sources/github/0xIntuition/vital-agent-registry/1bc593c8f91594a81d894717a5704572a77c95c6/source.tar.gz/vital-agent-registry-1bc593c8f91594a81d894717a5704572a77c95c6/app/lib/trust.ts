import type { Vault, TrustSignal, TrustTier } from '~/types'
import { TRUST_TIER_THRESHOLDS } from '~/types'
import { formatWeiToEth, safeSharePrice, sanitizeWeiString } from './vault-utils'

/**
 * Pre-sorted rank map for O(1) percentile lookups after O(n log n) sort.
 * Key = original array index, Value = percentile (0-100).
 */
type PercentileMap = Map<number, number>

/**
 * Minimum number of agents required for meaningful ranking.
 * Below this threshold, all agents are considered 'unranked'.
 */
export const MINIMUM_AGENTS_FOR_RANKING = 3

/**
 * Calculate percentile rank of a vault's TVL among all vaults.
 * Uses BigInt comparison for precision.
 * Handles ties: same TVL = same percentile (stable).
 *
 * @param vaultTotalAssets - Total assets in wei (BigInt string)
 * @param allTotalAssets - Array of all vault total_assets (BigInt strings)
 * @returns Percentile rank (0-100)
 *
 * @example
 * // Vault with 50 ETH among [10, 20, 30, 40, 50]
 * calculatePercentile('50000000000000000000', ['10...', '20...', '30...', '40...', '50...'])
 * // Returns 80 (4 out of 5 are below)
 */
export function calculatePercentile(
  vaultTotalAssets: string,
  allTotalAssets: string[],
): number {
  if (allTotalAssets.length === 0) return 0
  if (allTotalAssets.length === 1) return 100

  const target = BigInt(sanitizeWeiString(vaultTotalAssets))
  const countBelow = allTotalAssets.filter(
    (tvl) => BigInt(sanitizeWeiString(tvl)) < target,
  ).length

  return Math.round((countBelow / allTotalAssets.length) * 100)
}

/**
 * Calculate percentile rank of a vault's staker count among all vaults.
 * Handles ties: same count = same percentile (stable).
 *
 * @param count - Number of stakers
 * @param allCounts - Array of all vault position counts
 * @returns Percentile rank (0-100)
 *
 * @example
 * calculateCountPercentile(50, [10, 20, 30, 40, 50])
 * // Returns 80 (4 out of 5 are below)
 */
export function calculateCountPercentile(
  count: number,
  allCounts: number[],
): number {
  if (allCounts.length === 0) return 0
  if (allCounts.length === 1) return 100

  const countBelow = allCounts.filter((c) => c < count).length
  return Math.round((countBelow / allCounts.length) * 100)
}

/**
 * Calculate percentile rank of a vault's share price among all vaults.
 * Uses BigInt comparison for precision.
 * Handles ties: same price = same percentile (stable).
 *
 * @param price - Share price in wei (BigInt string)
 * @param allPrices - Array of all vault share prices (BigInt strings)
 * @returns Percentile rank (0-100)
 *
 * @example
 * calculatePricePercentile('1500000000000000000', ['1000...', '1200...', '1500...'])
 * // Returns 66 (2 out of 3 are below)
 */
export function calculatePricePercentile(
  price: string,
  allPrices: string[],
): number {
  if (allPrices.length === 0) return 0
  if (allPrices.length === 1) return 100

  const target = BigInt(sanitizeWeiString(price))
  const countBelow = allPrices.filter(
    (p) => BigInt(sanitizeWeiString(p)) < target,
  ).length

  return Math.round((countBelow / allPrices.length) * 100)
}

/**
 * Compute composite trust score from weighted percentiles.
 *
 * Formula: 0.4 * tvlPercentile + 0.4 * stakerPercentile + 0.2 * pricePercentile
 *
 * @param tvlPercentile - TVL percentile (0-100)
 * @param stakerPercentile - Staker count percentile (0-100)
 * @param pricePercentile - Share price percentile (0-100)
 * @returns Composite score (0-100)
 *
 * @example
 * computeCompositeScore(80, 60, 70)
 * // Returns 0.4 * 80 + 0.4 * 60 + 0.2 * 70 = 70
 */
export function computeCompositeScore(
  tvlPercentile: number,
  stakerPercentile: number,
  pricePercentile: number,
): number {
  return Math.round(
    0.4 * tvlPercentile + 0.4 * stakerPercentile + 0.2 * pricePercentile,
  )
}

/**
 * Assign trust tier from composite percentile using PROJECT.md thresholds:
 * - platinum: >= 90th percentile
 * - gold: >= 75th percentile
 * - silver: >= 50th percentile
 * - bronze: >= 25th percentile
 * - unranked: below 25th or insufficient data
 *
 * Additional rules:
 * - 0 stakers always maps to 'unranked' regardless of percentile
 * - Below MINIMUM_AGENTS_FOR_RANKING vaults, all are 'unranked'
 *
 * @param percentile - Composite percentile rank (0-100)
 * @param stakerCount - Number of unique stakers
 * @param totalVaults - Total number of vaults for ranking
 * @returns TrustTier classification
 *
 * @example
 * assignTrustTier(95, 100, 10) // 'platinum'
 * assignTrustTier(80, 50, 10) // 'gold'
 * assignTrustTier(50, 0, 10) // 'unranked' (0 stakers override)
 * assignTrustTier(95, 100, 2) // 'unranked' (insufficient vaults)
 */
export function assignTrustTier(
  percentile: number,
  stakerCount: number,
  totalVaults: number,
): TrustTier {
  if (stakerCount === 0) return 'unranked'
  if (totalVaults < MINIMUM_AGENTS_FOR_RANKING) return 'unranked'
  if (percentile >= TRUST_TIER_THRESHOLDS.platinum) return 'platinum'
  if (percentile >= TRUST_TIER_THRESHOLDS.gold) return 'gold'
  if (percentile >= TRUST_TIER_THRESHOLDS.silver) return 'silver'
  if (percentile >= TRUST_TIER_THRESHOLDS.bronze) return 'bronze'
  return 'unranked'
}

/**
 * Compute a complete TrustSignal from vault data and all-vaults context.
 * This is the primary entry point for trust computation.
 *
 * Uses composite weighted percentile formula:
 * trust = 0.4 * percentile(TVL) + 0.4 * percentile(stakers) + 0.2 * percentile(share_price)
 *
 * @param vault - The vault to compute trust signal for
 * @param allVaults - Array of all vaults for percentile calculation
 * @returns Complete TrustSignal with tier, composite percentile, and formatted values
 *
 * @example
 * const signal = computeTrustSignal(agentVault, allAgentVaults)
 * // signal.tier = 'gold', signal.percentile = 72 (composite), signal.totalStaked = '42.5'
 */
export function computeTrustSignal(
  vault: Vault,
  allVaults: Vault[],
): TrustSignal {
  // Extract arrays for percentile calculations
  const allTotalAssets = allVaults.map((v) => v.total_assets)
  const allCounts = allVaults.map((v) => v.position_count)
  const allPrices = allVaults.map((v) => safeSharePrice(v))

  // Calculate individual percentiles
  const tvlPercentile = calculatePercentile(vault.total_assets, allTotalAssets)
  const stakerPercentile = calculateCountPercentile(vault.position_count, allCounts)
  const pricePercentile = calculatePricePercentile(safeSharePrice(vault), allPrices)

  // Compute composite score
  const compositePercentile = computeCompositeScore(
    tvlPercentile,
    stakerPercentile,
    pricePercentile,
  )

  // Assign tier based on composite score
  const tier = assignTrustTier(compositePercentile, vault.position_count, allVaults.length)

  return {
    stakerCount: vault.position_count,
    totalStaked: formatWeiToEth(vault.total_assets),
    sharePrice: formatWeiToEth(safeSharePrice(vault)),
    tier,
    percentile: compositePercentile,
    marketCap: formatWeiToEth(vault.market_cap),
  }
}

/**
 * Build a percentile map from BigInt string values using sort-once approach.
 * O(n log n) sort + O(n) map construction.
 *
 * For tied values, all tied entries receive the same percentile
 * (based on the rank of the first occurrence).
 */
function buildBigIntPercentileMap(values: string[]): PercentileMap {
  if (values.length <= 1) {
    const map: PercentileMap = new Map()
    if (values.length === 1) map.set(0, 100)
    return map
  }

  const indexed = values.map((v, i) => ({ val: BigInt(sanitizeWeiString(v)), idx: i }))
  indexed.sort((a, b) => (a.val < b.val ? -1 : a.val > b.val ? 1 : 0))

  const map: PercentileMap = new Map()
  const len = values.length
  for (let rank = 0; rank < len; rank++) {
    // For ties, use the rank of the first occurrence
    let effectiveRank = rank
    if (rank > 0 && indexed[rank].val === indexed[rank - 1].val) {
      effectiveRank = map.get(indexed[rank - 1].idx)! * len / 100
      map.set(indexed[rank].idx, Math.round((effectiveRank / len) * 100))
    } else {
      map.set(indexed[rank].idx, Math.round((rank / len) * 100))
    }
  }
  return map
}

/**
 * Build a percentile map from number values using sort-once approach.
 */
function buildNumberPercentileMap(values: number[]): PercentileMap {
  if (values.length <= 1) {
    const map: PercentileMap = new Map()
    if (values.length === 1) map.set(0, 100)
    return map
  }

  const indexed = values.map((v, i) => ({ val: v, idx: i }))
  indexed.sort((a, b) => a.val - b.val)

  const map: PercentileMap = new Map()
  const len = values.length
  for (let rank = 0; rank < len; rank++) {
    if (rank > 0 && indexed[rank].val === indexed[rank - 1].val) {
      map.set(indexed[rank].idx, map.get(indexed[rank - 1].idx)!)
    } else {
      map.set(indexed[rank].idx, Math.round((rank / len) * 100))
    }
  }
  return map
}

/**
 * Compute trust signals for ALL vaults in batch. O(n log n) instead of O(n²).
 *
 * Sorts each metric array once to build percentile maps,
 * then computes each vault's trust signal in O(1) via map lookup.
 *
 * @param vaults - Array of all vaults to score
 * @returns Array of TrustSignals in same order as input vaults
 *
 * @example
 * const signals = computeTrustSignalBatch(allVaults)
 * // signals[i] is the trust signal for vaults[i]
 */
export function computeTrustSignalBatch(vaults: Vault[]): TrustSignal[] {
  if (vaults.length === 0) return []

  // Build percentile maps once — O(n log n) each
  const tvlMap = buildBigIntPercentileMap(vaults.map((v) => v.total_assets))
  const countMap = buildNumberPercentileMap(vaults.map((v) => v.position_count))
  const priceMap = buildBigIntPercentileMap(vaults.map((v) => safeSharePrice(v)))

  // Compute trust signals — O(1) per vault
  return vaults.map((vault, i) => {
    const tvlPercentile = tvlMap.get(i) ?? 0
    const stakerPercentile = countMap.get(i) ?? 0
    const pricePercentile = priceMap.get(i) ?? 0

    const compositePercentile = computeCompositeScore(
      tvlPercentile,
      stakerPercentile,
      pricePercentile,
    )

    const tier = assignTrustTier(compositePercentile, vault.position_count, vaults.length)

    return {
      stakerCount: vault.position_count,
      totalStaked: formatWeiToEth(vault.total_assets),
      sharePrice: formatWeiToEth(safeSharePrice(vault)),
      tier,
      percentile: compositePercentile,
      marketCap: formatWeiToEth(vault.market_cap),
    }
  })
}
