import type { Agent, Skill } from '~/types'
import { AgentCard } from './AgentCard'
import { SkillCard } from './SkillCard'
import { useCardVariant } from '~/lib/hooks/useCardVariant'

/**
 * RegistryItem — discriminated union for mixed agent/skill listings
 */
export type RegistryItem =
  | { type: 'agent'; entity: Agent }
  | { type: 'skill'; entity: Skill }

interface RegistryGridProps {
  items: RegistryItem[]
  className?: string
}

/**
 * RegistryGrid — responsive grid rendering AgentCards and SkillCards
 *
 * Layout adapts to card variant:
 * - default/detailed: 1 col mobile, 2 col tablet, 3 col desktop
 * - compact: single column list
 */
export function RegistryGrid({ items, className = '' }: RegistryGridProps) {
  const { variant } = useCardVariant()

  const gridClass = variant === 'compact'
    ? 'flex flex-col gap-2'
    : 'grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3'

  return (
    <div className={`${gridClass} ${className}`}>
      {items.map((item) => {
        if (item.type === 'agent') {
          return <AgentCard key={item.entity.id} agent={item.entity} />
        } else {
          return <SkillCard key={item.entity.id} skill={item.entity} />
        }
      })}
    </div>
  )
}
