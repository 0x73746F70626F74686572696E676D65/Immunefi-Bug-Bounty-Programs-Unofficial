import type { Skill } from '~/types'

export interface SkillScores {
  /** Safety score 0-100, derived from safetyRatio */
  safety: number
  /** Trust score 0-100, derived from trust tier percentile */
  trust: number
  /** Adoption score 0-100, derived from staker count (normalized) */
  adoption: number
  /** Overall composite score (weighted average) */
  composite: number
}

/**
 * Compute category scores from skill data.
 * Maps raw FOR/AGAINST data into 0-100 scores.
 */
export function computeSkillScores(skill: Skill): SkillScores {
  const { safetySignal, trustSignal } = skill

  // Safety: direct mapping from safetyRatio (0-1 -> 0-100)
  const safety = Math.round(safetySignal.safetyRatio * 100)

  // Trust: use percentile directly (already 0-100)
  const trust = trustSignal.percentile

  // Adoption: normalize staker count with diminishing returns
  // 100+ stakers = 100, uses sqrt curve
  const adoption = Math.min(100, Math.round(Math.sqrt(trustSignal.stakerCount / 100) * 100))

  // Composite: weighted average (safety 40%, trust 35%, adoption 25%)
  const composite = Math.round(safety * 0.4 + trust * 0.35 + adoption * 0.25)

  return { safety, trust, adoption, composite }
}

export function getScoreColor(score: number): string {
  if (score >= 80) return 'hsl(142 71% 45%)'
  if (score >= 60) return 'hsl(38 92% 50%)'
  return 'hsl(0 84% 60%)'
}

export function getScoreBadgeClasses(score: number): string {
  if (score >= 80) return 'border-[hsl(142_71%_45%/0.5)] bg-[hsl(142_71%_45%/0.1)] text-[hsl(142_71%_45%)]'
  if (score >= 60) return 'border-[hsl(38_92%_50%/0.5)] bg-[hsl(38_92%_50%/0.1)] text-[hsl(38_92%_50%)]'
  return 'border-[hsl(0_84%_60%/0.5)] bg-[hsl(0_84%_60%/0.1)] text-[hsl(0_84%_60%)]'
}
