import type { ActionFunctionArgs } from 'react-router'
import { handleOptions, parseJsonBody, jsonResponse, errorResponse } from '~/lib/api/types'
import { z } from 'zod'
import { detectSource } from '~/lib/import/detect-source'
import { fetchMoltbookAgent } from '~/lib/import/adapters/moltbook'
import { fetchClawhubSkill } from '~/lib/import/adapters/clawhub'
import type { ImportError } from '~/lib/import/types'

const ImportSchema = z.object({
  url: z.string().url('Must be a valid URL'),
})

/**
 * POST /api/v1/import
 *
 * Detects source from URL, fetches metadata, returns normalized import fields.
 * Used to prefill registration forms.
 */
export async function action({ request }: ActionFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const parsed = await parseJsonBody(request, ImportSchema)
  if ('error' in parsed) return parsed.error

  const { url } = parsed.data

  const detected = detectSource(url)
  if (!detected) {
    return errorResponse(
      'Unsupported URL. Supported sources: moltbook.com/u/{name}, clawhub.ai/skills/{slug}',
      'UNSUPPORTED_URL',
      422,
    )
  }

  try {
    if (detected.source === 'moltbook') {
      const fields = await fetchMoltbookAgent(detected.slug)
      return jsonResponse({ source: detected.source, slug: detected.slug, fields })
    }

    if (detected.source === 'clawhub') {
      const fields = await fetchClawhubSkill(detected.slug)
      return jsonResponse({ source: detected.source, slug: detected.slug, fields })
    }

    return errorResponse('Unknown source', 'UNSUPPORTED_URL', 422)
  } catch (err) {
    const importError = err as ImportError
    if (importError?.code === 'NOT_FOUND') {
      return errorResponse(importError.message, 'NOT_FOUND', 404)
    }
    if (importError?.code === 'FETCH_FAILED') {
      return errorResponse(importError.message, 'FETCH_FAILED', 502)
    }
    return errorResponse(
      'Failed to import from URL',
      'IMPORT_ERROR',
      500,
      { message: err instanceof Error ? err.message : 'Unknown error' },
    )
  }
}
