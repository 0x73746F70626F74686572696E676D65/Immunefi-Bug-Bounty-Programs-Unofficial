import type { ReactNode } from 'react'

interface FeedCarouselProps {
  children: ReactNode
}

export function FeedCarousel({ children }: FeedCarouselProps) {
  return (
    <div
      className="flex gap-4 overflow-x-auto snap-x snap-mandatory scroll-smooth px-[10%] py-4"
      style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
    >
      {children}
    </div>
  )
}
