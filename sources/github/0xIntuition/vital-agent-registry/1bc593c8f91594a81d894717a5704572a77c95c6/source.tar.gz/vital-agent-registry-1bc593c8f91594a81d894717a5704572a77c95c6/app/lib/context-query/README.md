# Nested Context Query

`POST /api/v1/context/query` evaluates base claims and context claims together.

## Canonical Context Predicates

- `in-context-of`
- `as-evaluated-by`
- `during-period`

## Semantic Density Rule

Semantically dense context edges are rejected.

Rejected pattern:
- Multiple canonical context predicates on the same `(subject, object)` edge.

Why:
- Dense edge packing makes context semantics ambiguous and less replayable.
- Splitting context dimensions into separate claims keeps evidence traversal deterministic.

Guideline:
- Use one canonical context predicate per edge.
- Add additional context as separate claims with distinct objects.
