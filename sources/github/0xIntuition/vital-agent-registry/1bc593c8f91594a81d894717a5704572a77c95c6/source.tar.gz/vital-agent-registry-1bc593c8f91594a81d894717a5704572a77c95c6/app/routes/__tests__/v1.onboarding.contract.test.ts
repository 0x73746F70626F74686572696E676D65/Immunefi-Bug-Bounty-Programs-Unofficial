import { describe, expect, it } from 'vitest'
import type { ActionFunctionArgs, LoaderFunctionArgs } from 'react-router'
import { onboardingContractSchema } from '~/lib/api/onboarding'
import { loader as readinessLoader } from '../api+/v1.onboarding.agents.$id.readiness'
import { action as walletPlanAction } from '../api+/v1.onboarding.wallet-plan'
import { action as fundingPlanAction } from '../api+/v1.onboarding.funding-plan'

function makeLoaderArgs(url: string, params: Record<string, string>): LoaderFunctionArgs {
  return {
    request: new Request(url),
    params,
    context: {},
  } as LoaderFunctionArgs
}

function makeActionArgs(url: string, body: unknown): ActionFunctionArgs {
  return {
    request: new Request(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    }),
    params: {},
    context: {},
  } as ActionFunctionArgs
}

describe('onboarding endpoints contract wiring', () => {
  it('readiness endpoint covers unknown state', async () => {
    const response = await readinessLoader(
      makeLoaderArgs(
        'https://registry.local/api/v1/onboarding/agents/agent-unknown/readiness?hasWallet=false&availableFundsWei=0&requiredFundsWei=10',
        { id: 'agent-unknown' },
      ),
    )
    const json = await response.json()
    expect(json.data.state).toBe('unknown')
    expect(json.data.failures.some((failure: any) => failure.code === 'missing-wallet')).toBe(true)
  })

  it('readiness endpoint covers planned state and policy-aware failure', async () => {
    const response = await readinessLoader(
      makeLoaderArgs(
        'https://registry.local/api/v1/onboarding/agents/agent-planned/readiness?hasWallet=true&availableFundsWei=100&requiredFundsWei=100&policyBlocked=true',
        { id: 'agent-planned' },
      ),
    )
    const json = await response.json()
    expect(json.data.state).toBe('planned')
    expect(json.data.failures.some((failure: any) => failure.code === 'policy-blocked')).toBe(true)
  })

  it('readiness endpoint covers funded state', async () => {
    const response = await readinessLoader(
      makeLoaderArgs(
        'https://registry.local/api/v1/onboarding/agents/agent-funded/readiness?hasWallet=true&availableFundsWei=100&requiredFundsWei=10&isRegistered=false',
        { id: 'agent-funded' },
      ),
    )
    const json = await response.json()
    expect(json.data.state).toBe('funded')
  })

  it('readiness endpoint returns onboarding contract shape', async () => {
    const response = await readinessLoader(
      makeLoaderArgs(
        'https://registry.local/api/v1/onboarding/agents/agent-a/readiness?hasWallet=true&availableFundsWei=100&requiredFundsWei=10&isRegistered=true&isActive=false&indexerLagBlocks=0&policyBlocked=false',
        { id: 'agent-a' },
      ),
    )

    expect(response.status).toBe(200)
    const json = await response.json()
    const parsed = onboardingContractSchema.safeParse(json.data)
    expect(parsed.success).toBe(true)
    if (parsed.success) {
      expect(parsed.data.state).toBe('registered')
    }
  })

  it('readiness endpoint covers active state and indexer lag diagnostics', async () => {
    const response = await readinessLoader(
      makeLoaderArgs(
        'https://registry.local/api/v1/onboarding/agents/agent-active/readiness?hasWallet=true&availableFundsWei=100&requiredFundsWei=10&isRegistered=true&isActive=true&indexerLagBlocks=4',
        { id: 'agent-active' },
      ),
    )
    const json = await response.json()
    expect(json.data.state).toBe('active')
    expect(json.data.diagnostics.indexerLagBlocks).toBe(4)
    expect(json.data.failures.some((failure: any) => failure.code === 'indexer-lagged')).toBe(true)
  })

  it('wallet-plan endpoint nests onboarding contract', async () => {
    const response = await walletPlanAction(
      makeActionArgs('https://registry.local/api/v1/onboarding/wallet-plan', {
        agentId: 'agent-b',
        chainId: 13579,
        policyProfile: 'standard',
        hasWallet: false,
        availableFundsWei: '0',
        requiredFundsWei: '100',
        policyBlocked: false,
      }),
    )

    expect(response.status).toBe(200)
    const json = await response.json()
    expect(onboardingContractSchema.safeParse(json.data.contract).success).toBe(true)
    expect(Array.isArray(json.data.unsignedTransactions)).toBe(true)
  })

  it('wallet-plan rejects unsupported policy/chain combinations', async () => {
    const response = await walletPlanAction(
      makeActionArgs('https://registry.local/api/v1/onboarding/wallet-plan', {
        agentId: 'agent-b',
        chainId: 1155,
        policyProfile: 'strict',
        hasWallet: true,
        availableFundsWei: '100',
        requiredFundsWei: '100',
        policyBlocked: false,
      }),
    )

    expect(response.status).toBe(400)
    const json = await response.json()
    expect(json.code).toBe('VALIDATION_ERROR')
  })

  it('wallet-plan enforces policy-blocked constraint', async () => {
    const response = await walletPlanAction(
      makeActionArgs('https://registry.local/api/v1/onboarding/wallet-plan', {
        agentId: 'agent-b',
        chainId: 13579,
        policyProfile: 'standard',
        hasWallet: true,
        availableFundsWei: '100',
        requiredFundsWei: '50',
        policyBlocked: true,
      }),
    )
    expect(response.status).toBe(403)
    const json = await response.json()
    expect(json.code).toBe('POLICY_BLOCKED')
  })

  it('funding-plan endpoint nests onboarding contract', async () => {
    const response = await fundingPlanAction(
      makeActionArgs('https://registry.local/api/v1/onboarding/funding-plan', {
        agentId: 'agent-c',
        availableFundsWei: '20',
        requiredFundsWei: '100',
        recommendedFundsWei: '250',
        policyBlocked: false,
        sponsorBudgetWei: '200',
      }),
    )

    expect(response.status).toBe(200)
    const json = await response.json()
    expect(onboardingContractSchema.safeParse(json.data.contract).success).toBe(true)
    expect(json.data.runway.budgetCapped).toBe(true)
  })

  it('funding-plan enforces budget constraints', async () => {
    const response = await fundingPlanAction(
      makeActionArgs('https://registry.local/api/v1/onboarding/funding-plan', {
        agentId: 'agent-c',
        availableFundsWei: '20',
        requiredFundsWei: '100',
        recommendedFundsWei: '200',
        policyBlocked: false,
        sponsorBudgetWei: '50',
      }),
    )
    expect(response.status).toBe(400)
    const json = await response.json()
    expect(json.code).toBe('BUDGET_CONSTRAINT')
  })

  it('funding-plan enforces policy-blocked edge case', async () => {
    const response = await fundingPlanAction(
      makeActionArgs('https://registry.local/api/v1/onboarding/funding-plan', {
        agentId: 'agent-c',
        availableFundsWei: '20',
        requiredFundsWei: '100',
        recommendedFundsWei: '200',
        policyBlocked: true,
        sponsorBudgetWei: '200',
      }),
    )
    expect(response.status).toBe(403)
    const json = await response.json()
    expect(json.code).toBe('POLICY_BLOCKED')
  })
})
