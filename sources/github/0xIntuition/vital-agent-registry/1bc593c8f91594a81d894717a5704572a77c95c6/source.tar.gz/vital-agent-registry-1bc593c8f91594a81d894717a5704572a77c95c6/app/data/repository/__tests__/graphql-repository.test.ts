import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { GraphQLRegistryRepository } from '../graphql-repository'
import type { GraphQLAgentsResponse, GraphQLSkillsResponse } from '~/lib/graphql/mappers'
import * as client from '~/lib/graphql/client'

// Mock the GraphQL client
vi.mock('~/lib/graphql/client', () => ({
  serverGraphqlRequest: vi.fn(),
}))

// Mock console.error to suppress error logging in tests
vi.spyOn(console, 'error').mockImplementation(() => {})

describe('GraphQLRegistryRepository', () => {
  let repository: GraphQLRegistryRepository
  const mockApiUrl = 'https://test-api.intuition.systems/graphql'

  beforeEach(() => {
    repository = new GraphQLRegistryRepository({
      apiUrl: mockApiUrl,
      chain: 'testnet',
    })
    vi.clearAllMocks()
  })

  describe('Agent methods', () => {
    it('should list agents and return paginated results', async () => {
      const mockResponse: GraphQLAgentsResponse = {
        total: { aggregate: { count: 2 } },
        atoms: [
          {
            term_id: '0xagent1',
            label: 'Test Agent 1',
            image: null,
            cached_image: null,
            type: 'Agent',
            data: JSON.stringify({
              description: 'A test agent',
              version: '1.0.0',
            }),
            created_at: '2025-01-01T00:00:00Z',
            creator: null,
            value: {
              thing: {
                name: 'Test Agent 1',
                description: 'A test agent',
                image: null,
                url: null,
              },
            },
            term: {
              total_market_cap: '1000000000000000000',
              positions_aggregate: { aggregate: { count: 10 } },
              vaults: [
                {
                  term_id: '0xvault1',
                  curve_id: '1',
                  current_share_price: '1000000000000000000',
                  total_shares: '10000000000000000000',
                  total_assets: '1000000000000000000',
                  position_count: 10,
                  market_cap: '1000000000000000000',
                },
              ],
            },
            as_subject_triples: [
              {
                term_id: '0xtriple1',
                predicate: { term_id: '0xpred1', label: 'has-capability' },
                object: {
                  term_id: '0xcap1',
                  label: 'Code Generation',
                  image: null,
                  type: 'Capability',
                  data: JSON.stringify({ category: 'ai', description: 'Generate code' }),
                  value: {
                    thing: {
                      name: 'Code Generation',
                      description: 'Generate code',
                      image: null,
                      url: null,
                    },
                  },
                },
              },
            ],
          },
        ],
      }

      vi.mocked(client.serverGraphqlRequest).mockResolvedValue(mockResponse)

      const result = await repository.listAgents({ limit: 1, offset: 0 })

      expect(result.items).toHaveLength(1)
      expect(result.total).toBe(2)
      expect(result.hasMore).toBe(true)
      expect(result.items[0].id).toBe('0xagent1')
      expect(result.items[0].metadata.name).toBe('Test Agent 1')
      expect(result.items[0].capabilities).toHaveLength(1)
      expect(result.items[0].trustSignal).toBeDefined()
    })

    it('should find a single agent by ID', async () => {
      const mockResponse = {
        atom: {
          term_id: '0xagent1',
          label: 'Test Agent',
          image: null,
          cached_image: null,
          type: 'Agent',
          data: JSON.stringify({ description: 'Test', version: '1.0.0' }),
          created_at: '2025-01-01T00:00:00Z',
          creator: null,
          value: {
            thing: {
              name: 'Test Agent',
              description: 'Test',
              image: null,
              url: null,
            },
          },
          term: {
            total_market_cap: '1000000000000000000',
            positions_aggregate: { aggregate: { count: 5 } },
            vaults: [
              {
                term_id: '0xvault1',
                curve_id: '1',
                current_share_price: '1000000000000000000',
                total_shares: '5000000000000000000',
                total_assets: '500000000000000000',
                position_count: 5,
                market_cap: '500000000000000000',
              },
            ],
          },
          as_subject_triples: [],
        },
      }

      // Mock both the single agent query and the all agents query (for trust calculation)
      vi.mocked(client.serverGraphqlRequest)
        .mockResolvedValueOnce(mockResponse) // findAgent call
        .mockResolvedValueOnce({
          total: { aggregate: { count: 10 } },
          atoms: Array(10).fill(mockResponse.atom),
        }) // getAllAgentVaults call

      const agent = await repository.findAgent('0xagent1')

      expect(agent).not.toBeNull()
      expect(agent?.id).toBe('0xagent1')
      expect(agent?.metadata.name).toBe('Test Agent')
      expect(agent?.trustSignal.stakerCount).toBe(5)
    })

    it('should return null when agent not found', async () => {
      vi.mocked(client.serverGraphqlRequest).mockResolvedValue({ atom: null })

      const agent = await repository.findAgent('0xnonexistent')

      expect(agent).toBeNull()
    })

    it('should search agents with query', async () => {
      const mockResponse = {
        atoms: [
          {
            term_id: '0xagent1',
            label: 'Code Agent',
            image: null,
            cached_image: null,
            type: 'Agent',
            data: null,
            created_at: '2025-01-01T00:00:00Z',
            value: {
              thing: {
                name: 'Code Agent',
                description: 'Generates code',
                image: null,
                url: null,
              },
            },
            term: {
              total_market_cap: '2000000000000000000',
              vaults: [
                {
                  term_id: '0xvault1',
                  curve_id: '1',
                  current_share_price: '1000000000000000000',
                  total_shares: '20000000000000000000',
                  total_assets: '2000000000000000000',
                  position_count: 20,
                  market_cap: '2000000000000000000',
                },
              ],
            },
            as_subject_triples: [],
          },
        ],
      }

      // Mock both search and getAllAgentVaults
      vi.mocked(client.serverGraphqlRequest)
        .mockResolvedValueOnce(mockResponse)
        .mockResolvedValueOnce({
          total: { aggregate: { count: 1 } },
          atoms: mockResponse.atoms,
        })

      const agents = await repository.searchAgents('code')

      expect(agents).toHaveLength(1)
      expect(agents[0].metadata.name).toBe('Code Agent')
    })

    it('should get agent card', async () => {
      const mockAgent = {
        atom: {
          term_id: '0xagent1',
          label: 'API Agent',
          image: null,
          cached_image: null,
          type: 'Agent',
          data: JSON.stringify({
            version: '2.0.0',
            endpoint: 'https://agent.example.com',
            provider: { name: 'Example Corp', url: 'https://example.com' },
          }),
          created_at: '2025-01-01T00:00:00Z',
          creator: null,
          value: {
            thing: {
              name: 'API Agent',
              description: 'An API-enabled agent',
              image: null,
              url: null,
            },
          },
          term: {
            total_market_cap: '1000000000000000000',
            positions_aggregate: { aggregate: { count: 15 } },
            vaults: [
              {
                term_id: '0xvault1',
                curve_id: '1',
                current_share_price: '1000000000000000000',
                total_shares: '15000000000000000000',
                total_assets: '1500000000000000000',
                position_count: 15,
                market_cap: '1500000000000000000',
              },
            ],
          },
          as_subject_triples: [
            {
              term_id: '0xtriple1',
              predicate: { term_id: '0xpred1', label: 'has-capability' },
              object: {
                term_id: '0xcap1',
                label: 'API Integration',
                image: null,
                type: 'Capability',
                data: JSON.stringify({ category: 'web3', description: 'API calls' }),
                value: {
                  thing: {
                    name: 'API Integration',
                    description: 'API calls',
                    image: null,
                    url: null,
                  },
                },
              },
            },
          ],
        },
      }

      vi.mocked(client.serverGraphqlRequest)
        .mockResolvedValueOnce(mockAgent)
        .mockResolvedValueOnce({
          total: { aggregate: { count: 1 } },
          atoms: [mockAgent.atom],
        })

      const card = await repository.getAgentCard('0xagent1')

      expect(card).not.toBeNull()
      expect(card?.id).toBe('0xagent1')
      expect(card?.name).toBe('API Agent')
      expect(card?.version).toBe('2.0.0')
      expect(card?.url).toBe('https://agent.example.com')
      expect(card?.provider.name).toBe('Example Corp')
      expect(card?.skills).toHaveLength(1)
      expect(card?.extensions).toHaveLength(1)
      expect(card?.extensions?.[0].atomId).toBe('0xagent1')
      expect(card?.securitySchemes).toBeDefined()
      expect(card?.security).toEqual([{ unauthenticated: [] }])
      expect(card?.interfaces).toEqual([
        { protocol: 'http', url: 'https://agent.example.com' },
      ])
    })
  })

  describe('Skill methods', () => {
    it('should list skills and return paginated results', async () => {
      const mockResponse: GraphQLSkillsResponse = {
        total: { aggregate: { count: 3 } },
        atoms: [
          {
            term_id: '0xskill1',
            label: 'Test Skill',
            image: null,
            cached_image: null,
            type: 'Skill',
            data: JSON.stringify({
              description: 'A test skill',
              version: '1.0.0',
              permissions: ['filesystem'],
            }),
            created_at: '2025-01-01T00:00:00Z',
            creator: null,
            value: {
              thing: {
                name: 'Test Skill',
                description: 'A test skill',
                image: null,
                url: null,
              },
            },
            term: {
              total_market_cap: '500000000000000000',
              positions_aggregate: { aggregate: { count: 8 } },
              vaults: [
                {
                  term_id: '0xvault1',
                  curve_id: '1',
                  current_share_price: '1000000000000000000',
                  total_shares: '8000000000000000000',
                  total_assets: '500000000000000000',
                  position_count: 8,
                  market_cap: '500000000000000000',
                },
              ],
            },
            as_subject_triples: [
              {
                term_id: '0xtriple1',
                counter_term_id: '0xcounter1',
                predicate: { term_id: '0xpred1', label: 'has-capability' },
                object: {
                  term_id: '0xcap1',
                  label: 'file-management',
                  image: null,
                  type: 'Capability',
                  data: JSON.stringify({ description: 'File management capability', category: 'automation' }),
                  value: {
                    thing: {
                      name: 'File Management',
                      description: 'File management capability',
                      image: null,
                      url: null,
                    },
                  },
                },
                term: {
                  vaults: [
                    {
                      term_id: '0xcounter1',
                      curve_id: '0',
                      current_share_price: '1000000000000000000',
                      total_shares: '2000000000000000000',
                      total_assets: '100000000000000000',
                      position_count: 2,
                      market_cap: '100000000000000000',
                    },
                  ],
                },
              },
            ],
          },
        ],
      }

      // Mock both list and getAllSkillVaults
      vi.mocked(client.serverGraphqlRequest)
        .mockResolvedValueOnce(mockResponse)
        .mockResolvedValueOnce({
          atoms: mockResponse.atoms,
        })

      const result = await repository.listSkills({ limit: 20, offset: 0 })

      expect(result.items).toHaveLength(1)
      expect(result.total).toBe(3)
      expect(result.items[0].id).toBe('0xskill1')
      expect(result.items[0].metadata.name).toBe('Test Skill')
      expect(result.items[0].platform.id).toBe('custom')
      expect(result.items[0].safetySignal).toBeDefined()
      expect(result.items[0].trustSignal).toBeDefined()
    })

    it('should find a single skill by ID', async () => {
      const mockSkill = {
        atom: {
          term_id: '0xskill1',
          label: 'File Manager',
          image: null,
          cached_image: null,
          type: 'Skill',
          data: JSON.stringify({
            description: 'Manage files',
            version: '1.0.0',
            permissions: ['filesystem'],
          }),
          created_at: '2025-01-01T00:00:00Z',
          creator: null,
          value: {
            thing: {
              name: 'File Manager',
              description: 'Manage files',
              image: null,
              url: null,
            },
          },
          term: {
            total_market_cap: '300000000000000000',
            positions_aggregate: { aggregate: { count: 5 } },
            vaults: [
              {
                term_id: '0xvault1',
                curve_id: '1',
                current_share_price: '1000000000000000000',
                total_shares: '5000000000000000000',
                total_assets: '300000000000000000',
                position_count: 5,
                market_cap: '300000000000000000',
              },
            ],
          },
          as_subject_triples: [],
        },
      }

      vi.mocked(client.serverGraphqlRequest)
        .mockResolvedValueOnce(mockSkill)
        .mockResolvedValueOnce({ atoms: [mockSkill.atom] })

      const skill = await repository.findSkill('0xskill1')

      expect(skill).not.toBeNull()
      expect(skill?.id).toBe('0xskill1')
      expect(skill?.metadata.name).toBe('File Manager')
      expect(skill?.metadata.permissions).toContain('filesystem')
    })

    it('should return null when skill not found', async () => {
      vi.mocked(client.serverGraphqlRequest).mockResolvedValue({ atom: null })

      const skill = await repository.findSkill('0xnonexistent')

      expect(skill).toBeNull()
    })
  })

  describe('Metadata methods', () => {
    it('should list capabilities', async () => {
      const mockResponse = {
        atoms: [
          {
            term_id: '0xcap1',
            label: 'Code Generation',
            data: JSON.stringify({ category: 'ai', description: 'Generate code' }),
            value: {
              thing: {
                name: 'Code Generation',
                description: 'Generate code',
              },
            },
          },
        ],
      }

      vi.mocked(client.serverGraphqlRequest).mockResolvedValue(mockResponse)

      const capabilities = await repository.listCapabilities()

      expect(capabilities).toHaveLength(1)
      expect(capabilities[0].name).toBe('Code Generation')
      expect(capabilities[0].category).toBe('ai')
    })

    it('should list predicates', async () => {
      const predicates = await repository.listPredicates()

      expect(predicates.length).toBeGreaterThan(0)
      expect(predicates[0]).toHaveProperty('id')
      expect(predicates[0]).toHaveProperty('label')
      expect(predicates[0]).toHaveProperty('description')
      expect(predicates[0]).toHaveProperty('subjectTypes')
      expect(predicates[0]).toHaveProperty('objectTypes')
    })

    it('should list platforms', async () => {
      const mockResponse = {
        atoms: [
          {
            term_id: '0xplatform1',
            label: 'MCP',
            data: JSON.stringify({ description: 'Model Context Protocol' }),
            image: null,
            cached_image: null,
            value: {
              thing: {
                name: 'MCP',
                description: 'Model Context Protocol',
                image: null,
                url: 'https://modelcontextprotocol.io',
              },
            },
          },
        ],
      }

      vi.mocked(client.serverGraphqlRequest).mockResolvedValue(mockResponse)

      const platforms = await repository.listPlatforms()

      expect(platforms).toHaveLength(1)
      expect(platforms[0].name).toBe('MCP')
      expect(platforms[0].description).toBe('Model Context Protocol')
    })
  })

  describe('Metadata resolution', () => {
    afterEach(() => {
      vi.clearAllMocks()
    })

    it('should resolve current metadata with highest FOR stake', async () => {
      const mockResponse = {
        triples: [
          {
            term_id: '0xtriple1',
            created_at: '2025-01-01T00:00:00Z',
            object: {
              term_id: '0xmeta1',
              label: 'ipfs://QmMetadata1',
              type: 'Metadata',
              data: JSON.stringify({
                name: 'Agent v1',
                description: 'First version',
                version: '1.0.0',
              }),
              created_at: '2025-01-01T00:00:00Z',
              value: {
                thing: { name: 'Agent v1', description: 'First version' },
              },
              term: {
                vaults: [
                  {
                    term_id: '0xvault1',
                    curve_id: '1',
                    current_share_price: '1000000000000000000',
                    total_shares: '1000000000000000000',
                    total_assets: '1000000000000000000',
                    position_count: 5,
                    market_cap: '1000000000000000000',
                  },
                ],
              },
            },
          },
          {
            term_id: '0xtriple2',
            created_at: '2025-01-02T00:00:00Z',
            object: {
              term_id: '0xmeta2',
              label: 'ipfs://QmMetadata2',
              type: 'Metadata',
              data: JSON.stringify({
                name: 'Agent v2',
                description: 'Second version with more trust',
                version: '2.0.0',
              }),
              created_at: '2025-01-02T00:00:00Z',
              value: {
                thing: { name: 'Agent v2', description: 'Second version with more trust' },
              },
              term: {
                vaults: [
                  {
                    term_id: '0xvault2',
                    curve_id: '1',
                    current_share_price: '1000000000000000000',
                    total_shares: '5000000000000000000',
                    total_assets: '5000000000000000000',
                    position_count: 25,
                    market_cap: '5000000000000000000',
                  },
                ],
              },
            },
          },
        ],
      }

      vi.mocked(client.serverGraphqlRequest).mockResolvedValue(mockResponse)

      const metadata = await repository.resolveCurrentMetadata('agent', '0xagent1')

      expect(metadata).not.toBeNull()
      expect(metadata?.name).toBe('Agent v2') // Higher stake wins
      expect(metadata?.version).toBe('2.0.0')
    })

    it('should fallback to most recent when no stakes', async () => {
      const mockResponse = {
        triples: [
          {
            term_id: '0xtriple1',
            created_at: '2025-01-01T00:00:00Z',
            object: {
              term_id: '0xmeta1',
              label: 'ipfs://QmMetadata1',
              type: 'Metadata',
              data: JSON.stringify({
                name: 'Agent v1',
                description: 'First version',
                version: '1.0.0',
              }),
              created_at: '2025-01-01T00:00:00Z',
              value: {
                thing: { name: 'Agent v1', description: 'First version' },
              },
              term: {
                vaults: [], // No vault = no stake
              },
            },
          },
          {
            term_id: '0xtriple2',
            created_at: '2025-01-03T00:00:00Z',
            object: {
              term_id: '0xmeta2',
              label: 'ipfs://QmMetadata2',
              type: 'Metadata',
              data: JSON.stringify({
                name: 'Agent v3',
                description: 'Third version - most recent',
                version: '3.0.0',
              }),
              created_at: '2025-01-03T00:00:00Z',
              value: {
                thing: { name: 'Agent v3', description: 'Third version - most recent' },
              },
              term: {
                vaults: [], // No vault = no stake
              },
            },
          },
          {
            term_id: '0xtriple3',
            created_at: '2025-01-02T00:00:00Z',
            object: {
              term_id: '0xmeta3',
              label: 'ipfs://QmMetadata3',
              type: 'Metadata',
              data: JSON.stringify({
                name: 'Agent v2',
                description: 'Second version',
                version: '2.0.0',
              }),
              created_at: '2025-01-02T00:00:00Z',
              value: {
                thing: { name: 'Agent v2', description: 'Second version' },
              },
              term: {
                vaults: [], // No vault = no stake
              },
            },
          },
        ],
      }

      vi.mocked(client.serverGraphqlRequest).mockResolvedValue(mockResponse)

      const metadata = await repository.resolveCurrentMetadata('agent', '0xagent1')

      expect(metadata).not.toBeNull()
      expect(metadata?.name).toBe('Agent v3') // Most recent wins
      expect(metadata?.version).toBe('3.0.0')
    })

    it('should return null when no metadata triples exist', async () => {
      const mockResponse = {
        triples: [],
      }

      vi.mocked(client.serverGraphqlRequest).mockResolvedValue(mockResponse)

      const metadata = await repository.resolveCurrentMetadata('agent', '0xagent1')

      expect(metadata).toBeNull()
    })

    it('should resolve skill metadata with trust weighting', async () => {
      const mockResponse = {
        triples: [
          {
            term_id: '0xtriple1',
            created_at: '2025-01-01T00:00:00Z',
            object: {
              term_id: '0xmeta1',
              label: 'ipfs://QmSkillMetadata1',
              type: 'Metadata',
              data: JSON.stringify({
                name: 'File Reader v1',
                description: 'Read files',
                version: '1.0.0',
                permissions: ['filesystem'],
              }),
              created_at: '2025-01-01T00:00:00Z',
              value: {
                thing: { name: 'File Reader v1', description: 'Read files' },
              },
              term: {
                vaults: [
                  {
                    term_id: '0xvault1',
                    curve_id: '1',
                    current_share_price: '1000000000000000000',
                    total_shares: '2000000000000000000',
                    total_assets: '2000000000000000000',
                    position_count: 10,
                    market_cap: '2000000000000000000',
                  },
                ],
              },
            },
          },
          {
            term_id: '0xtriple2',
            created_at: '2025-01-02T00:00:00Z',
            object: {
              term_id: '0xmeta2',
              label: 'ipfs://QmSkillMetadata2',
              type: 'Metadata',
              data: JSON.stringify({
                name: 'File Reader v2',
                description: 'Read files better',
                version: '2.0.0',
                permissions: ['filesystem', 'network'],
              }),
              created_at: '2025-01-02T00:00:00Z',
              value: {
                thing: { name: 'File Reader v2', description: 'Read files better' },
              },
              term: {
                vaults: [
                  {
                    term_id: '0xvault2',
                    curve_id: '1',
                    current_share_price: '1000000000000000000',
                    total_shares: '1000000000000000000',
                    total_assets: '1000000000000000000',
                    position_count: 5,
                    market_cap: '1000000000000000000',
                  },
                ],
              },
            },
          },
        ],
      }

      vi.mocked(client.serverGraphqlRequest).mockResolvedValue(mockResponse)

      const metadata = await repository.resolveCurrentMetadata('skill', '0xskill1')

      expect(metadata).not.toBeNull()
      expect(metadata?.name).toBe('File Reader v1') // Higher stake wins
      expect(metadata?.version).toBe('1.0.0')
    })

    it('should cache metadata results', async () => {
      const mockResponse = {
        triples: [
          {
            term_id: '0xtriple1',
            created_at: '2025-01-01T00:00:00Z',
            object: {
              term_id: '0xmeta1',
              label: 'ipfs://QmMetadata1',
              type: 'Metadata',
              data: JSON.stringify({
                name: 'Agent v1',
                description: 'First version',
                version: '1.0.0',
              }),
              created_at: '2025-01-01T00:00:00Z',
              value: {
                thing: { name: 'Agent v1', description: 'First version' },
              },
              term: {
                vaults: [
                  {
                    term_id: '0xvault1',
                    curve_id: '1',
                    current_share_price: '1000000000000000000',
                    total_shares: '1000000000000000000',
                    total_assets: '1000000000000000000',
                    position_count: 5,
                    market_cap: '1000000000000000000',
                  },
                ],
              },
            },
          },
        ],
      }

      vi.mocked(client.serverGraphqlRequest).mockResolvedValue(mockResponse)

      // First call - should hit GraphQL
      const metadata1 = await repository.resolveCurrentMetadata('agent', '0xagent1')
      expect(client.serverGraphqlRequest).toHaveBeenCalledTimes(1)
      expect(metadata1?.name).toBe('Agent v1')

      // Second call - should use cache
      const metadata2 = await repository.resolveCurrentMetadata('agent', '0xagent1')
      expect(client.serverGraphqlRequest).toHaveBeenCalledTimes(1) // Still 1, no new call
      expect(metadata2?.name).toBe('Agent v1')
    })

    it('should handle errors gracefully', async () => {
      vi.mocked(client.serverGraphqlRequest).mockRejectedValue(new Error('Network error'))

      const metadata = await repository.resolveCurrentMetadata('agent', '0xagent1')

      expect(metadata).toBeNull()
      expect(console.error).toHaveBeenCalled()
    })
  })
})
