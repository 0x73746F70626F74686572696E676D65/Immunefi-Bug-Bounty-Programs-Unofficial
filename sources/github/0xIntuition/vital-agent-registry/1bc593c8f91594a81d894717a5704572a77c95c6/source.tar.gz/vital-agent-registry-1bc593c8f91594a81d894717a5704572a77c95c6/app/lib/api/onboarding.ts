import { z } from 'zod'

export const onboardingStateSchema = z.enum([
  'unknown',
  'planned',
  'funded',
  'registered',
  'active',
])

export const onboardingFailureCodeSchema = z.enum([
  'missing-wallet',
  'insufficient-funds',
  'policy-blocked',
  'indexer-lagged',
])

export const onboardingFailureSchema = z.object({
  code: onboardingFailureCodeSchema,
  message: z.string().min(1),
  blocking: z.boolean().default(true),
  remediation: z.string().min(1),
})

export const onboardingDiagnosticsSchema = z.object({
  hasWallet: z.boolean(),
  availableFundsWei: z.string(),
  requiredFundsWei: z.string(),
  isRegistered: z.boolean(),
  isActive: z.boolean(),
  indexerLagBlocks: z.number().int().nonnegative(),
  policyBlocked: z.boolean(),
  checkedAt: z.string().datetime(),
})

export const onboardingContractSchema = z.object({
  agentId: z.string().min(1),
  state: onboardingStateSchema,
  failures: z.array(onboardingFailureSchema).default([]),
  remediationHints: z.array(z.string()).default([]),
  diagnostics: onboardingDiagnosticsSchema,
})

const queryBooleanSchema = z.preprocess((value) => {
  if (typeof value === 'boolean') return value
  if (typeof value === 'string') {
    const normalized = value.trim().toLowerCase()
    if (normalized === 'true' || normalized === '1') return true
    if (normalized === 'false' || normalized === '0') return false
  }
  return value
}, z.boolean())

export const readinessQuerySchema = z.object({
  hasWallet: queryBooleanSchema.optional().default(false),
  availableFundsWei: z.coerce.bigint().optional().default(0n),
  requiredFundsWei: z.coerce.bigint().optional().default(0n),
  isRegistered: queryBooleanSchema.optional().default(false),
  isActive: queryBooleanSchema.optional().default(false),
  indexerLagBlocks: z.coerce.number().int().nonnegative().optional(),
  policyBlocked: queryBooleanSchema.optional().default(false),
})

export const walletPlanRequestSchema = z.object({
  agentId: z.string().min(1),
  chainId: z.union([z.literal(13579), z.literal(1155)]),
  policyProfile: z.enum(['standard', 'strict']).default('standard'),
  hasWallet: z.boolean().default(false),
  availableFundsWei: z.string().regex(/^\d+$/).default('0'),
  requiredFundsWei: z.string().regex(/^\d+$/).default('0'),
  policyBlocked: z.boolean().default(false),
}).superRefine((value, ctx) => {
  if (value.chainId === 1155 && value.policyProfile === 'strict') {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'policyProfile "strict" is not supported on chain 1155',
      path: ['policyProfile'],
    })
  }
})

export const fundingPlanRequestSchema = z.object({
  agentId: z.string().min(1),
  availableFundsWei: z.string().regex(/^\d+$/).default('0'),
  requiredFundsWei: z.string().regex(/^\d+$/).default('0'),
  recommendedFundsWei: z.string().regex(/^\d+$/).default('0'),
  policyBlocked: z.boolean().default(false),
  sponsorBudgetWei: z.string().regex(/^\d+$/).default('0'),
})

function deriveState(args: {
  hasWallet: boolean
  hasEnoughFunds: boolean
  isRegistered: boolean
  isActive: boolean
  hasIndexerLag: boolean
  policyBlocked: boolean
}): z.infer<typeof onboardingStateSchema> {
  if (!args.hasWallet) return 'unknown'
  if (args.policyBlocked) return 'planned'
  if (!args.hasEnoughFunds) return 'planned'
  if (args.isActive) return 'active'
  if (args.isRegistered && !args.hasIndexerLag) return 'registered'
  if (args.isRegistered && args.hasIndexerLag) return 'registered'
  return 'funded'
}

export function buildOnboardingContract(input: {
  agentId: string
  hasWallet: boolean
  availableFundsWei: bigint
  requiredFundsWei: bigint
  isRegistered: boolean
  isActive: boolean
  indexerLagBlocks: number
  policyBlocked: boolean
}) {
  const failures: Array<z.infer<typeof onboardingFailureSchema>> = []

  if (!input.hasWallet) {
    failures.push({
      code: 'missing-wallet',
      message: 'Agent wallet is not configured',
      blocking: true,
      remediation: 'Create or assign a wallet before onboarding actions',
    })
  }

  if (input.availableFundsWei < input.requiredFundsWei) {
    failures.push({
      code: 'insufficient-funds',
      message: 'Available funds are below the required minimum',
      blocking: true,
      remediation: 'Fund the wallet to at least the minimum required runway',
    })
  }

  if (input.policyBlocked) {
    failures.push({
      code: 'policy-blocked',
      message: 'Policy currently blocks this onboarding operation',
      blocking: true,
      remediation: 'Adjust policy settings or request policy exception',
    })
  }

  if (input.indexerLagBlocks > 0) {
    failures.push({
      code: 'indexer-lagged',
      message: 'Indexer lag exceeds expected threshold',
      blocking: false,
      remediation: 'Retry after indexer catches up to the latest block',
    })
  }

  const state = deriveState({
    hasWallet: input.hasWallet,
    hasEnoughFunds: input.availableFundsWei >= input.requiredFundsWei,
    isRegistered: input.isRegistered,
    isActive: input.isActive,
    hasIndexerLag: input.indexerLagBlocks > 0,
    policyBlocked: input.policyBlocked,
  })

  const remediationHints = failures.map((failure) => failure.remediation)

  return onboardingContractSchema.parse({
    agentId: input.agentId,
    state,
    failures,
    remediationHints,
    diagnostics: {
      hasWallet: input.hasWallet,
      availableFundsWei: input.availableFundsWei.toString(),
      requiredFundsWei: input.requiredFundsWei.toString(),
      isRegistered: input.isRegistered,
      isActive: input.isActive,
      indexerLagBlocks: input.indexerLagBlocks,
      policyBlocked: input.policyBlocked,
      checkedAt: new Date().toISOString(),
    },
  })
}

export type OnboardingContract = z.infer<typeof onboardingContractSchema>
