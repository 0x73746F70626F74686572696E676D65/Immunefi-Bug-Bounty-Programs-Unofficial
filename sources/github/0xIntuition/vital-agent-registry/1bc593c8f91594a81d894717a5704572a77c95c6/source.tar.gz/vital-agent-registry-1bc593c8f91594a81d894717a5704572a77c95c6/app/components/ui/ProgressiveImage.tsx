import { useProgressiveImage } from '~/lib/hooks/useProgressiveImage'
import { cn } from '~/lib/utils'

interface ProgressiveImageProps {
  src: string
  alt: string
  className?: string
  width?: number
  height?: number
}

export function ProgressiveImage({ src, alt, className }: ProgressiveImageProps) {
  // Generate a tiny placeholder URL from the same seed
  const lowSrc = src.replace(/\/(\d+)\/(\d+)$/, '/60/80') + '?blur=5'
  const { src: currentSrc, isLoaded } = useProgressiveImage(lowSrc, src)

  return (
    <img
      src={currentSrc}
      alt={alt}
      className={cn(
        'transition-all duration-500 ease-out',
        isLoaded ? 'scale-100 blur-0' : 'scale-110 blur-sm',
        className,
      )}
      loading="lazy"
    />
  )
}
