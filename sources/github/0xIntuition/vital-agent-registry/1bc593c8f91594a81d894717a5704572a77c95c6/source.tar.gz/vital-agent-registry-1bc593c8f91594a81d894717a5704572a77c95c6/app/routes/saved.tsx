import { useMemo } from 'react'
import { useLoaderData } from 'react-router'
import { Bookmark } from 'lucide-react'
import { createRepository } from '~/data'
import { RegistryLayout } from '~/components/layout/RegistryLayout'
import { AgentCard } from '~/components/registry/AgentCard'
import { SkillCard } from '~/components/registry/SkillCard'
import { useSavedEntities } from '~/lib/hooks/useSavedEntities'

export function meta() {
  return [
    { title: 'Saved — Intuition' },
    { name: 'description', content: 'Your saved agents and skills.' },
  ]
}

export async function loader() {
  const repo = createRepository()
  const [agentResult, skillResult] = await Promise.all([
    repo.listAgents({ limit: 100 }),
    repo.listSkills({ limit: 100 }),
  ])
  return {
    agents: agentResult.items,
    skills: skillResult.items,
  }
}

export default function SavedPage() {
  const { agents, skills } = useLoaderData<typeof loader>()
  const { saved } = useSavedEntities()

  const savedAgents = useMemo(
    () => agents.filter(a => saved.some(s => s.id === a.id && s.type === 'agent')),
    [agents, saved],
  )

  const savedSkills = useMemo(
    () => skills.filter(sk => saved.some(s => s.id === sk.id && s.type === 'skill')),
    [skills, saved],
  )

  const isEmpty = savedAgents.length === 0 && savedSkills.length === 0

  return (
    <RegistryLayout
      header={
        <div className="py-4">
          <h1 className="text-2xl font-semibold text-foreground">Saved</h1>
          <p className="text-sm text-ink-dull">
            Your bookmarked agents and skills
          </p>
        </div>
      }
    >
      {isEmpty ? (
        <div className="flex min-h-[60vh] flex-col items-center justify-center gap-3 rounded-xl bg-app-box-light p-8 text-center">
          <Bookmark className="h-12 w-12 text-ink-faint" />
          <p className="text-lg font-semibold text-foreground">Nothing saved yet</p>
          <p className="text-sm text-muted-foreground">
            Bookmark agents and skills to find them here quickly.
          </p>
        </div>
      ) : (
        <div className="space-y-8 py-6">
          {savedAgents.length > 0 && (
            <section>
              <h2 className="mb-4 font-mono text-xs tracking-widest uppercase text-ink-dull">
                Agents ({savedAgents.length})
              </h2>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {savedAgents.map(agent => (
                  <AgentCard key={agent.id} agent={agent} />
                ))}
              </div>
            </section>
          )}

          {savedSkills.length > 0 && (
            <section>
              <h2 className="mb-4 font-mono text-xs tracking-widest uppercase text-ink-dull">
                Skills ({savedSkills.length})
              </h2>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {savedSkills.map(skill => (
                  <SkillCard key={skill.id} skill={skill} />
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </RegistryLayout>
  )
}
