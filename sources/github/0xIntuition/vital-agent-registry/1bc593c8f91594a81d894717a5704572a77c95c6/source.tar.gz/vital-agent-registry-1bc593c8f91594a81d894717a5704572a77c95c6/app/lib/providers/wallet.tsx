import { type ReactNode, useMemo } from 'react'
import { WagmiProvider } from 'wagmi'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { RainbowKitProvider, darkTheme } from '@rainbow-me/rainbowkit'
import { createWalletConfig } from '~/lib/config/wallet'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      refetchOnWindowFocus: false,
    },
  },
})

interface WalletProviderProps {
  children: ReactNode
  chain?: string
  walletConnectProjectId?: string
}

/**
 * Wallet provider that wraps the app with wagmi and RainbowKit.
 * Accepts chain and walletConnectProjectId to configure dynamically.
 */
export function WalletProvider({ children, chain, walletConnectProjectId }: WalletProviderProps) {
  const config = useMemo(
    () => createWalletConfig({ chain, walletConnectProjectId }),
    [chain, walletConnectProjectId],
  )

  return (
    <WagmiProvider config={config}>
      <QueryClientProvider client={queryClient}>
        <RainbowKitProvider
          theme={darkTheme({
            accentColor: '#6366f1',
            accentColorForeground: 'white',
            borderRadius: 'medium',
            fontStack: 'system',
          })}
          showRecentTransactions
        >
          {children}
        </RainbowKitProvider>
      </QueryClientProvider>
    </WagmiProvider>
  )
}

// Re-export wagmi hooks for convenience
export { useAccount, useDisconnect, useSignMessage, useWriteContract, useWaitForTransactionReceipt } from 'wagmi'
