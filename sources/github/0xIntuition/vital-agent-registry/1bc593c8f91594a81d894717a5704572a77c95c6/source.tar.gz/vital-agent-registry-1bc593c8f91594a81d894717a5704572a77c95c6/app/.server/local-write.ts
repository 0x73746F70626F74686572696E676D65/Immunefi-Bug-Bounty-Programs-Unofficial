import { createPublicClient, createWalletClient, defineChain, http } from 'viem'
import { privateKeyToAccount } from 'viem/accounts'
import { getWriteProfile } from './remote-write-guard'

const DEFAULT_LOCAL_RPC_URL = 'http://localhost:8545'
const DEFAULT_LOCAL_CHAIN_ID = 31337
const DEFAULT_LOCAL_MULTIVAULT_ADDRESS = '0xc3e53F4d16Ae77Db1c982e75a937B9f60FE63690'

export interface LocalWriteContext {
  chainId: number
  rpcUrl: string
  contractAddress: `0x${string}`
  privateKey?: `0x${string}`
  account?: `0x${string}`
}

export function getLocalWriteContext(env: NodeJS.ProcessEnv = process.env): LocalWriteContext {
  const profile = getWriteProfile(env)
  if (profile !== 'local') {
    throw new Error('Local execution is only allowed when REGISTRY_WRITE_PROFILE=local')
  }

  const chainIdRaw = env.LOCAL_CHAIN_ID ?? String(DEFAULT_LOCAL_CHAIN_ID)
  const chainId = Number(chainIdRaw)
  if (!Number.isInteger(chainId) || chainId <= 0) {
    throw new Error(`Invalid LOCAL_CHAIN_ID: ${chainIdRaw}`)
  }

  const rpcUrl = env.LOCAL_CHAIN_RPC_URL ?? DEFAULT_LOCAL_RPC_URL
  const contractAddress = (env.LOCAL_MULTIVAULT_ADDRESS ??
    DEFAULT_LOCAL_MULTIVAULT_ADDRESS) as `0x${string}`
  const privateKey = (env.LOCAL_WRITE_PRIVATE_KEY ?? env.PRIVATE_KEY) as `0x${string}` | undefined
  const account = env.LOCAL_WRITE_ACCOUNT as `0x${string}` | undefined

  return {
    chainId,
    rpcUrl,
    contractAddress,
    privateKey,
    account,
  }
}

export async function createLocalWriteClients(context: LocalWriteContext) {
  const chain = defineChain({
    id: context.chainId,
    name: `Intuition Local ${context.chainId}`,
    nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
    rpcUrls: { default: { http: [context.rpcUrl] } },
  })

  const publicClient = createPublicClient({
    chain,
    transport: http(context.rpcUrl),
  })

  const discoveredAccounts = context.privateKey || context.account
    ? null
    : await fetch(context.rpcUrl, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'eth_accounts', params: [] }),
    })
      .then((res) => res.json())
      .then((payload) => (Array.isArray(payload?.result) ? payload.result : []))
      .catch(() => [])

  const signer =
    context.privateKey
      ? privateKeyToAccount(context.privateKey)
      : context.account ?? (discoveredAccounts[0] as `0x${string}` | undefined)

  if (!signer) {
    throw new Error(
      'Local write signer not available. Set LOCAL_WRITE_PRIVATE_KEY, LOCAL_WRITE_ACCOUNT, or ensure eth_accounts returns at least one unlocked account.'
    )
  }

  const walletClient = createWalletClient({
    chain,
    account: signer,
    transport: http(context.rpcUrl),
  })

  return { account: signer, chain, publicClient, walletClient }
}
