import { describe, expect, it } from 'vitest'
import {
  canonicalizeTrustModelArtifact,
  getTrustModelDigest,
  getTrustModelRef,
  trustModelArtifactSchema,
} from '../artifact'

const BASE_MODEL = {
  modelId: 'com.intuition.trust.default',
  version: '1.0.0',
  author: 'registry-team',
  domain: 'agent-discovery',
  inputs: [
    {
      key: 'market_cap_wei',
      source: 'vault',
      type: 'number',
      required: true,
      description: 'Total market cap in wei',
    },
    {
      key: 'staker_count',
      source: 'vault',
      type: 'number',
      required: true,
      description: 'Unique staker count',
    },
  ],
  formulaSpec: {
    language: 'trust-formula-v1',
    root: {
      op: 'weighted_sum',
      terms: [
        { weight: 0.6, value: { op: 'input', key: 'market_cap_wei' } },
        { weight: 0.4, value: { op: 'input', key: 'staker_count' } },
      ],
    },
  },
  normalization: {
    method: 'rank-percentile',
    clampMin: 0,
    clampMax: 100,
  },
  outputSemantics: {
    scoreRange: { min: 0, max: 100 },
    confidenceRange: { min: 0, max: 1 },
    interpretation: 'Higher score indicates stronger trust signal',
  },
  compatibility: {
    minCompatibleVersion: '1.0.0',
    breaking: false,
    notes: 'Patch/minor changes keep backward compatibility',
  },
  extensions: {
    'org.motherdao': {
      profile: 'default',
    },
  },
} as const

describe('trust model artifact schema', () => {
  it('validates required fields and enum values', () => {
    const parsed = trustModelArtifactSchema.safeParse(BASE_MODEL)
    expect(parsed.success).toBe(true)
  })

  it('is deterministic for canonicalization and digest', () => {
    const first = canonicalizeTrustModelArtifact(BASE_MODEL)
    const second = canonicalizeTrustModelArtifact({
      ...BASE_MODEL,
      outputSemantics: {
        interpretation: 'Higher score indicates stronger trust signal',
        confidenceRange: { max: 1, min: 0 },
        scoreRange: { max: 100, min: 0 },
      },
    })

    expect(first.canonical).toBe(second.canonical)
    expect(getTrustModelDigest(first.artifact)).toBe(getTrustModelDigest(second.artifact))
  })

  it('generates stable model reference', () => {
    const parsed = trustModelArtifactSchema.parse(BASE_MODEL)
    expect(getTrustModelRef(parsed)).toBe('com.intuition.trust.default@1.0.0')
  })
})
