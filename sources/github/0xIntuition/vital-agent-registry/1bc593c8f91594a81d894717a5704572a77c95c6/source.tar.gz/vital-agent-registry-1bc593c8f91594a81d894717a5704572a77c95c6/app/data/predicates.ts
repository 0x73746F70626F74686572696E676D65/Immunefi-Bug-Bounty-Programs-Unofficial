import type { PredicateDefinition } from '~/types'

/**
 * v3 core predicates.
 * These are the 5 canonical predicates used in the v3 data model.
 */
export const PREDICATES: PredicateDefinition[] = [
  {
    id: 'is',
    label: 'is',
    description: 'Entity type classification',
    subjectTypes: ['Agent', 'Skill'],
    objectTypes: ['Agent', 'Skill'],
  },
  {
    id: 'has-capability',
    label: 'has-capability',
    description: 'Entity has a capability',
    subjectTypes: ['Agent', 'Skill'],
    objectTypes: ['Capability'],
  },
  {
    id: 'uses',
    label: 'uses',
    description: 'Agent uses a skill',
    subjectTypes: ['Agent'],
    objectTypes: ['Skill'],
  },
  {
    id: 'has-metadata',
    label: 'has-metadata',
    description: 'Entity has versioned metadata',
    subjectTypes: ['Agent', 'Skill'],
    objectTypes: ['Thing'],
  },
  {
    id: 'created-by',
    label: 'created-by',
    description: 'Entity creator attribution',
    subjectTypes: ['Agent', 'Skill'],
    objectTypes: ['Person', 'Organization'],
  },
]

export function findPredicateById(id: string): PredicateDefinition | undefined {
  return PREDICATES.find(p => p.id === id)
}
