import type { TrustModelArtifact } from './artifact'

type PrimitiveInput = number | boolean | string | number[]

interface CandidateInput {
  id: string
  inputs: Record<string, unknown>
}

interface ScoredCandidate {
  candidateId: string
  rawScore: number
  normalizedScore: number
  confidence: number
  resolvedInputs: Record<string, PrimitiveInput>
}

interface SandboxLimits {
  maxDepth: number
  maxOperations: number
}

const DEFAULT_SANDBOX_LIMITS: SandboxLimits = {
  maxDepth: 20,
  maxOperations: 1000,
}

class SandboxError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'SandboxError'
  }
}

function toNumber(value: unknown): number {
  if (typeof value === 'number') return Number.isFinite(value) ? value : 0
  if (typeof value === 'boolean') return value ? 1 : 0
  if (typeof value === 'string') {
    const parsed = Number(value)
    return Number.isFinite(parsed) ? parsed : 0
  }
  if (Array.isArray(value)) {
    const numbers = value.map((entry) => Number(entry)).filter((entry) => Number.isFinite(entry))
    if (numbers.length === 0) return 0
    return numbers.reduce((sum, entry) => sum + entry, 0) / numbers.length
  }
  return 0
}

function round(value: number): number {
  return Math.round(value * 1_000_000) / 1_000_000
}

function clampResult(value: number): number {
  if (!Number.isFinite(value)) return 0
  return value
}

interface EvaluationContext {
  depth: number
  operationCount: number
  limits: SandboxLimits
}

function evaluateNodeSandboxed(
  node: any,
  inputs: Record<string, PrimitiveInput>,
  context: EvaluationContext,
): number {
  if (context.depth > context.limits.maxDepth) {
    throw new SandboxError(`Recursion depth limit exceeded (max: ${context.limits.maxDepth})`)
  }

  if (context.operationCount > context.limits.maxOperations) {
    throw new SandboxError(`Operation budget exceeded (max: ${context.limits.maxOperations})`)
  }

  context.operationCount += 1
  const childContext = { ...context, depth: context.depth + 1 }

  switch (node.op) {
    case 'const':
      return toNumber(node.value)
    case 'input':
      return toNumber(inputs[node.key])
    case 'add':
      return clampResult(
        node.args.reduce(
          (sum: number, arg: any) => sum + evaluateNodeSandboxed(arg, inputs, childContext),
          0,
        ),
      )
    case 'sub':
      return clampResult(
        node.args.slice(1).reduce(
          (acc: number, arg: any) => acc - evaluateNodeSandboxed(arg, inputs, childContext),
          evaluateNodeSandboxed(node.args[0], inputs, childContext),
        ),
      )
    case 'mul':
      return clampResult(
        node.args.reduce(
          (product: number, arg: any) => product * evaluateNodeSandboxed(arg, inputs, childContext),
          1,
        ),
      )
    case 'div':
      return clampResult(
        node.args.slice(1).reduce((acc: number, arg: any) => {
          const divisor = evaluateNodeSandboxed(arg, inputs, childContext)
          if (divisor === 0) return 0
          return acc / divisor
        }, evaluateNodeSandboxed(node.args[0], inputs, childContext)),
      )
    case 'min':
      return clampResult(
        Math.min(...node.args.map((arg: any) => evaluateNodeSandboxed(arg, inputs, childContext))),
      )
    case 'max':
      return clampResult(
        Math.max(...node.args.map((arg: any) => evaluateNodeSandboxed(arg, inputs, childContext))),
      )
    case 'weighted_sum':
      return clampResult(
        node.terms.reduce(
          (sum: number, term: any) =>
            sum + toNumber(term.weight) * evaluateNodeSandboxed(term.value, inputs, childContext),
          0,
        ),
      )
    case 'clamp': {
      const value = evaluateNodeSandboxed(node.value, inputs, childContext)
      return Math.max(node.min, Math.min(node.max, value))
    }
    default:
      return 0
  }
}

function evaluateNode(
  node: any,
  inputs: Record<string, PrimitiveInput>,
  limits: SandboxLimits = DEFAULT_SANDBOX_LIMITS,
): number {
  const context: EvaluationContext = {
    depth: 0,
    operationCount: 0,
    limits,
  }

  const result = evaluateNodeSandboxed(node, inputs, context)
  return clampResult(result)
}

function normalizeScores(rawScores: number[], model: TrustModelArtifact): number[] {
  const method = model.normalization.method
  if (method === 'none') return rawScores.map(round)

  if (method === 'rank-percentile') {
    if (rawScores.length <= 1) return [100]
    const sorted = rawScores.map((value, index) => ({ value, index }))
      .sort((a, b) => a.value - b.value)
    const percentileByIndex: number[] = new Array(rawScores.length).fill(0)
    sorted.forEach((entry, rank) => {
      percentileByIndex[entry.index] = round((rank / (rawScores.length - 1)) * 100)
    })
    return percentileByIndex
  }

  if (method === 'minmax') {
    const min = Math.min(...rawScores)
    const max = Math.max(...rawScores)
    if (max === min) return rawScores.map(() => 0)
    return rawScores.map((value) => round(((value - min) / (max - min)) * 100))
  }

  if (method === 'zscore') {
    const mean = rawScores.reduce((sum, value) => sum + value, 0) / rawScores.length
    const variance =
      rawScores.reduce((sum, value) => sum + (value - mean) ** 2, 0) / rawScores.length
    const std = Math.sqrt(variance)
    if (std === 0) return rawScores.map(() => 0)
    return rawScores.map((value) => round((value - mean) / std))
  }

  return rawScores.map(round)
}

function applyClamp(scores: number[], model: TrustModelArtifact): number[] {
  const min = model.normalization.clampMin
  const max = model.normalization.clampMax
  return scores.map((score) => {
    let next = score
    if (typeof min === 'number') next = Math.max(min, next)
    if (typeof max === 'number') next = Math.min(max, next)
    return round(next)
  })
}

function resolveInputs(
  model: TrustModelArtifact,
  candidate: CandidateInput,
): { resolved: Record<string, PrimitiveInput>; confidence: number } {
  const declaredKeys = new Set(model.inputs.map((declaration) => declaration.key))
  const providedKeys = Object.keys(candidate.inputs)

  for (const key of providedKeys) {
    if (!declaredKeys.has(key)) {
      throw new SandboxError(`Unknown input key: ${key}. Only declared input keys are allowed.`)
    }
  }

  const resolved: Record<string, PrimitiveInput> = {}
  let requiredCount = 0
  let satisfiedRequiredCount = 0

  for (const declaration of model.inputs) {
    const raw = candidate.inputs[declaration.key]
    const hasInput = raw !== undefined && raw !== null
    const value = hasInput ? raw : declaration.defaultValue

    if (declaration.required) {
      requiredCount += 1
      if (hasInput || declaration.defaultValue !== undefined) {
        satisfiedRequiredCount += 1
      }
    }

    resolved[declaration.key] = value as PrimitiveInput
  }

  const confidence =
    requiredCount === 0 ? 1 : round(satisfiedRequiredCount / requiredCount)

  return { resolved, confidence }
}

export function scoreCandidates(
  model: TrustModelArtifact,
  candidates: CandidateInput[],
  limits: SandboxLimits = DEFAULT_SANDBOX_LIMITS,
): ScoredCandidate[] {
  const prepared = candidates.map((candidate) => {
    const resolved = resolveInputs(model, candidate)
    const rawScore = round(evaluateNode(model.formulaSpec.root, resolved.resolved, limits))
    return {
      candidateId: candidate.id,
      rawScore,
      confidence: resolved.confidence,
      resolvedInputs: resolved.resolved,
    }
  })

  const normalized = applyClamp(normalizeScores(
    prepared.map((entry) => entry.rawScore),
    model,
  ), model)

  return prepared.map((entry, index) => ({
    ...entry,
    normalizedScore: normalized[index],
  }))
}
