import { describe, it, expect, vi, beforeEach } from 'vitest'
import { loader } from '../api+/v1.agents.$id.erc8004'
import type { LoaderFunctionArgs } from 'react-router'
import type { Agent } from '~/types'

// Mock dependencies
vi.mock('~/data/repository/provider', () => ({
  createRepository: vi.fn(() => ({
    findAgent: vi.fn(),
  })),
}))

vi.mock('~/lib/erc8004', () => ({
  generateERC8004: vi.fn(),
}))

/**
 * Helper to create mock LoaderFunctionArgs
 */
function createLoaderArgs(agentId: string, method = 'GET') {
  return {
    request: new Request(
      `https://registry.intuition.systems/api/v1/agents/${agentId}/erc8004`,
      { method }
    ),
    params: { id: agentId },
    context: {},
  } as unknown as LoaderFunctionArgs
}

/**
 * Helper to create a minimal mock Agent
 */
function createMockAgent(id: string): Agent {
  return {
    id,
    metadata: {
      name: 'TestAgent',
      description: 'Test',
      version: '1.0.0',
      createdAt: '2025-01-01T00:00:00Z',
    },
    capabilities: [],
    vault: {
      term_id: '0xvault',
      curve_id: '0xcurve',
      total_shares: '1000000000000000000',
      current_share_price: '1000000000000000000',
      total_assets: '1000000000000000000',
      market_cap: '1000000000000000000',
      position_count: 0,
    },
    trustSignal: {
      totalStaked: '0',
      stakerCount: 0,
      sharePrice: '1.0',
      percentile: 0,
      tier: 'bronze',
      marketCap: '0',
    },
    triples: [],
  } as Agent
}

describe('ERC-8004 endpoint', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    // Set testnet as default chain
    process.env.CHAIN = 'testnet'
  })

  describe('GET /api/v1/agents/:id/erc8004', () => {
    it('should return ERC-8004 JSON for a valid agent ID', async () => {
      const { createRepository } = await import('~/data/repository/provider')
      const { generateERC8004 } = await import('~/lib/erc8004')
      const mockAgent = createMockAgent('0xtest123')
      const mockERC8004 = {
        agentId: '0xtest123',
        registryAddress: '0xB92EA1B47E4ABD0a520E9138BB59dBd1bC6C475B',
        chainId: 13579,
        agentURI: 'ipfs://QmTest',
        agentWallet: '',
        metadata: {
          name: 'TestAgent',
          description: 'Test',
          version: '1.0.0',
          model: '',
        },
        services: [],
        active: true,
        registrations: [],
        trustModels: ['intuition-vault-staking'],
        registrationFile: 'https://registry.intuition.systems/api/v1/agents/0xtest123/erc8004',
      }

      ;(createRepository as any).mockReturnValue({
        findAgent: vi.fn().mockResolvedValue(mockAgent),
      })
      ;(generateERC8004 as any).mockReturnValue(mockERC8004)

      const args = createLoaderArgs('0xtest123')
      const response = await loader(args)

      expect(response.status).toBe(200)
      const data = await response.json()
      expect(data.data).toEqual(mockERC8004)
    })

    it('should return 404 for non-existent agent', async () => {
      const { createRepository } = await import('~/data/repository/provider')

      ;(createRepository as any).mockReturnValue({
        findAgent: vi.fn().mockResolvedValue(null),
      })

      const args = createLoaderArgs('0xnonexistent')
      const response = await loader(args)

      expect(response.status).toBe(404)
      const data = await response.json()
      expect(data.error).toBe('Agent not found')
      expect(data.code).toBe('NOT_FOUND')
    })

    it('should handle OPTIONS preflight request', async () => {
      const args = createLoaderArgs('0xtest123', 'OPTIONS')
      const response = await loader(args)

      expect(response.status).toBe(204)
      expect(response.headers.get('Access-Control-Allow-Origin')).toBe('*')
      expect(response.headers.get('Access-Control-Allow-Methods')).toContain('GET')
      expect(response.headers.get('Access-Control-Allow-Headers')).toBeDefined()
    })

    it('should include CORS headers in response', async () => {
      const { createRepository } = await import('~/data/repository/provider')
      const { generateERC8004 } = await import('~/lib/erc8004')
      const mockAgent = createMockAgent('0xtest123')

      ;(createRepository as any).mockReturnValue({
        findAgent: vi.fn().mockResolvedValue(mockAgent),
      })
      ;(generateERC8004 as any).mockReturnValue({})

      const args = createLoaderArgs('0xtest123')
      const response = await loader(args)

      expect(response.headers.get('Access-Control-Allow-Origin')).toBe('*')
    })

    it('should include registryAddress field in response', async () => {
      const { createRepository } = await import('~/data/repository/provider')
      const { generateERC8004 } = await import('~/lib/erc8004')
      const mockAgent = createMockAgent('0xtest123')
      const mockERC8004 = {
        registryAddress: '0xB92EA1B47E4ABD0a520E9138BB59dBd1bC6C475B',
        chainId: 13579,
        agentURI: 'ipfs://QmTest',
        agentId: '0xtest123',
        agentWallet: '',
        metadata: { name: 'Test', description: 'Test', version: '1.0.0', model: '' },
        services: [],
        active: true,
        registrations: [],
        trustModels: ['intuition-vault-staking'],
        registrationFile: 'https://registry.intuition.systems/api/v1/agents/0xtest123/erc8004',
      }

      ;(createRepository as any).mockReturnValue({
        findAgent: vi.fn().mockResolvedValue(mockAgent),
      })
      ;(generateERC8004 as any).mockReturnValue(mockERC8004)

      const args = createLoaderArgs('0xtest123')
      const response = await loader(args)
      const data = await response.json()

      expect(data.data.registryAddress).toBe('0xB92EA1B47E4ABD0a520E9138BB59dBd1bC6C475B')
    })

    it('should include chainId field in response', async () => {
      const { createRepository } = await import('~/data/repository/provider')
      const { generateERC8004 } = await import('~/lib/erc8004')
      const mockAgent = createMockAgent('0xtest123')
      const mockERC8004 = {
        registryAddress: '0xB92EA1B47E4ABD0a520E9138BB59dBd1bC6C475B',
        chainId: 13579,
        agentURI: 'ipfs://QmTest',
        agentId: '0xtest123',
        agentWallet: '',
        metadata: { name: 'Test', description: 'Test', version: '1.0.0', model: '' },
        services: [],
        active: true,
        registrations: [],
        trustModels: ['intuition-vault-staking'],
        registrationFile: 'https://registry.intuition.systems/api/v1/agents/0xtest123/erc8004',
      }

      ;(createRepository as any).mockReturnValue({
        findAgent: vi.fn().mockResolvedValue(mockAgent),
      })
      ;(generateERC8004 as any).mockReturnValue(mockERC8004)

      const args = createLoaderArgs('0xtest123')
      const response = await loader(args)
      const data = await response.json()

      expect(data.data.chainId).toBe(13579)
    })

    it('should include agentURI field in response', async () => {
      const { createRepository } = await import('~/data/repository/provider')
      const { generateERC8004 } = await import('~/lib/erc8004')
      const mockAgent = createMockAgent('0xtest123')
      const mockERC8004 = {
        registryAddress: '0xB92EA1B47E4ABD0a520E9138BB59dBd1bC6C475B',
        chainId: 13579,
        agentURI: 'ipfs://QmTestHash',
        agentId: '0xtest123',
        agentWallet: '',
        metadata: { name: 'Test', description: 'Test', version: '1.0.0', model: '' },
        services: [],
        active: true,
        registrations: [],
        trustModels: ['intuition-vault-staking'],
        registrationFile: 'https://registry.intuition.systems/api/v1/agents/0xtest123/erc8004',
      }

      ;(createRepository as any).mockReturnValue({
        findAgent: vi.fn().mockResolvedValue(mockAgent),
      })
      ;(generateERC8004 as any).mockReturnValue(mockERC8004)

      const args = createLoaderArgs('0xtest123')
      const response = await loader(args)
      const data = await response.json()

      expect(data.data.agentURI).toBe('ipfs://QmTestHash')
    })

    it('should call generateERC8004 with correct chain from env', async () => {
      const { createRepository } = await import('~/data/repository/provider')
      const { generateERC8004 } = await import('~/lib/erc8004')
      const mockAgent = createMockAgent('0xtest123')

      process.env.CHAIN = 'mainnet'

      ;(createRepository as any).mockReturnValue({
        findAgent: vi.fn().mockResolvedValue(mockAgent),
      })
      ;(generateERC8004 as any).mockReturnValue({})

      const args = createLoaderArgs('0xtest123')
      await loader(args)

      expect(generateERC8004).toHaveBeenCalledWith(mockAgent, 'mainnet', { includeOnboarding: false })
    })

    it('should default to testnet when CHAIN env not set', async () => {
      const { createRepository } = await import('~/data/repository/provider')
      const { generateERC8004 } = await import('~/lib/erc8004')
      const mockAgent = createMockAgent('0xtest123')

      delete process.env.CHAIN

      ;(createRepository as any).mockReturnValue({
        findAgent: vi.fn().mockResolvedValue(mockAgent),
      })
      ;(generateERC8004 as any).mockReturnValue({})

      const args = createLoaderArgs('0xtest123')
      await loader(args)

      expect(generateERC8004).toHaveBeenCalledWith(mockAgent, 'testnet', { includeOnboarding: false })
    })

    it('should return JSON content type', async () => {
      const { createRepository } = await import('~/data/repository/provider')
      const { generateERC8004 } = await import('~/lib/erc8004')
      const mockAgent = createMockAgent('0xtest123')

      ;(createRepository as any).mockReturnValue({
        findAgent: vi.fn().mockResolvedValue(mockAgent),
      })
      ;(generateERC8004 as any).mockReturnValue({})

      const args = createLoaderArgs('0xtest123')
      const response = await loader(args)

      expect(response.headers.get('Content-Type')).toBe('application/json')
    })
  })
})
