import { useState, useEffect } from 'react'
import * as Collapsible from '@radix-ui/react-collapsible'
import { ChevronDown } from 'lucide-react'
import type { Agent, Skill } from '~/types'
import { cn } from '~/lib/utils'
import { SkillCard } from '~/components/registry/SkillCard'
import { useRepository } from '~/data'

interface AgentSkillsZoneProps {
  agent: Agent
  className?: string
}

export function AgentSkillsZone({ agent, className }: AgentSkillsZoneProps) {
  const [isOpen, setIsOpen] = useState(true)
  const [skills, setSkills] = useState<Skill[]>([])
  const [loading, setLoading] = useState(true)
  const repo = useRepository()

  useEffect(() => {
    const loadSkills = async () => {
      try {
        setLoading(true)
        const agentSkills = await repo.getSkillsForAgent(agent.id)
        setSkills(agentSkills)
      } catch (error) {
        console.error('Failed to load skills for agent:', error)
      } finally {
        setLoading(false)
      }
    }

    loadSkills()
  }, [agent.id, repo])

  return (
    <Collapsible.Root
      open={isOpen}
      onOpenChange={setIsOpen}
      className={cn(
        'rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)]',
        className,
      )}
    >
      <Collapsible.Trigger className="flex w-full items-center justify-between p-4 hover:bg-muted/50 transition-colors">
        <h2 className="font-mono text-xs tracking-widest uppercase text-ink-dull">
          Skills Used {!loading && `(${skills.length})`}
        </h2>
        <ChevronDown
          className={cn(
            'h-5 w-5 text-muted-foreground transition-transform',
            isOpen && 'rotate-180',
          )}
        />
      </Collapsible.Trigger>

      <Collapsible.Content className="px-4 pb-4">
        {loading ? (
          <div className="font-mono text-xs text-muted-foreground">Loading skills...</div>
        ) : skills.length === 0 ? (
          <div className="font-mono text-xs text-muted-foreground">
            This agent doesn't use any registered skills.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {skills.map(skill => (
              <SkillCard key={skill.id} skill={skill} />
            ))}
          </div>
        )}
      </Collapsible.Content>
    </Collapsible.Root>
  )
}
