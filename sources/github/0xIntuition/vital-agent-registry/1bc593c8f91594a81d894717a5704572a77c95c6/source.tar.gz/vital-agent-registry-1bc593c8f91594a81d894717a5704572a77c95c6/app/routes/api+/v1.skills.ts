import type { LoaderFunctionArgs } from 'react-router'
import { createRepository } from '~/data/repository/provider'
import { skillListSchema } from '~/lib/api/validation'
import { handleOptions, parseQueryParams, jsonResponse } from '~/lib/api/types'

export async function loader({ request }: LoaderFunctionArgs) {
  const optionsResponse = handleOptions(request)
  if (optionsResponse) return optionsResponse

  const parsed = parseQueryParams(request, skillListSchema)
  if ('error' in parsed) return parsed.error

  const { q, capability, platformId, safetyStatus, sort, limit, offset } = parsed.data
  const repo = createRepository()

  let items
  let total

  // Use search if query provided, otherwise list
  if (q) {
    const searchResults = await repo.searchSkills(q, {
      capabilities: capability ? [capability] : undefined,
      platformId,
      sortBy: sort,
      limit,
      offset,
    })
    items = searchResults
    total = searchResults.length
  } else {
    const result = await repo.listSkills({
      capability,
      platformId,
      sortBy: sort,
      limit,
      offset,
    })
    items = result.items
    total = result.total
  }

  // Apply post-filter for safetyStatus if provided
  // Repository doesn't have native safety filter, so we filter client-side
  if (safetyStatus) {
    items = items.filter((skill) => skill.safetySignal.status === safetyStatus)
    total = items.length
  }

  return jsonResponse(items, { total, limit, offset })
}
