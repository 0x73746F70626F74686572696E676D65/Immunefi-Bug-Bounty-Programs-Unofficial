import { describe, it, expect } from 'vitest'
import { MODELS, findModelById, getModelsByProvider, getModelOptions } from './models'

describe('MODELS', () => {
  it('should have unique IDs', () => {
    const ids = MODELS.map((m) => m.id)
    expect(new Set(ids).size).toBe(ids.length)
  })

  it('should have 14 models', () => {
    expect(MODELS).toHaveLength(14)
  })

  it('should reference valid provider IDs', () => {
    const validProviders = new Set(['anthropic', 'openai', 'google', 'meta', 'mistral', 'xai'])
    for (const model of MODELS) {
      expect(validProviders.has(model.providerId)).toBe(true)
    }
  })
})

describe('findModelById', () => {
  it('should return model for known id', () => {
    const model = findModelById('claude-opus-4-6')
    expect(model?.name).toBe('Claude Opus 4.6')
  })

  it('should return undefined for unknown id', () => {
    expect(findModelById('unknown-model')).toBeUndefined()
  })
})

describe('getModelsByProvider', () => {
  it('should return anthropic models', () => {
    const models = getModelsByProvider('anthropic')
    expect(models).toHaveLength(3)
    expect(models.every((m) => m.providerId === 'anthropic')).toBe(true)
  })

  it('should return empty array for unknown provider', () => {
    expect(getModelsByProvider('unknown')).toHaveLength(0)
  })
})

describe('getModelOptions', () => {
  it('should return options for all models', () => {
    const options = getModelOptions()
    expect(options).toHaveLength(MODELS.length)
    expect(options[0]).toHaveProperty('value')
    expect(options[0]).toHaveProperty('label')
    expect(options[0]).toHaveProperty('group')
  })
})
