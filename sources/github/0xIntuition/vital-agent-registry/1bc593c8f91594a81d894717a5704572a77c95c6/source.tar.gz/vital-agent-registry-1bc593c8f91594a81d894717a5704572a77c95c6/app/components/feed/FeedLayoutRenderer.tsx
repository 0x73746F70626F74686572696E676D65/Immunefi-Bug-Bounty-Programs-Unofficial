import { Children, type ReactNode } from 'react'
import { useFeedLayout } from '~/lib/hooks/useFeedLayout'
import { FeedList } from './FeedList'
import { FeedCarousel } from './FeedCarousel'

interface FeedLayoutRendererProps {
  children: ReactNode
}

function wrapChildren(children: ReactNode, layout: 'list' | 'carousel' | 'grid') {
  if (layout === 'grid') return children

  return Children.map(children, (child) => (
    <div
      className={
        layout === 'list'
          ? 'w-full max-w-sm'
          : 'min-w-[80%] snap-center shrink-0'
      }
    >
      {child}
    </div>
  ))
}

export function FeedLayoutRenderer({ children }: FeedLayoutRendererProps) {
  const { layout } = useFeedLayout()
  const wrapped = wrapChildren(children, layout)

  switch (layout) {
    case 'list':
      return <FeedList>{wrapped}</FeedList>
    case 'carousel':
      return <FeedCarousel>{wrapped}</FeedCarousel>
    case 'grid':
      return <div className="grid grid-cols-2 gap-3 p-3">{wrapped}</div>
  }
}

export function FeedLayoutSkeletonRenderer({ children }: FeedLayoutRendererProps) {
  const { layout } = useFeedLayout()
  const wrapped = wrapChildren(children, layout)

  switch (layout) {
    case 'list':
      return <FeedList>{wrapped}</FeedList>
    case 'carousel':
      return <FeedCarousel>{wrapped}</FeedCarousel>
    case 'grid':
      return <div className="grid grid-cols-2 gap-3 p-3">{wrapped}</div>
  }
}
