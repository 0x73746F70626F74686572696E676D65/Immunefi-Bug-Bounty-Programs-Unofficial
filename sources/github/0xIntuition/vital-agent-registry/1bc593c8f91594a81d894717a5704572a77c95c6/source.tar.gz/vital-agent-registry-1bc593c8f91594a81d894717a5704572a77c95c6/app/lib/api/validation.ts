import { z } from 'zod'

// TrustTier enum matching types/vault.ts
const trustTierEnum = z.enum(['platinum', 'gold', 'silver', 'bronze', 'unranked'])

// SafetyStatus enum matching types/skill.ts
const safetyStatusEnum = z.enum(['verified', 'unverified', 'flagged'])

export const agentListSchema = z.object({
  q: z.string().optional(),
  capability: z.string().optional(),
  trustTier: trustTierEnum.optional(),
  minTrustTier: trustTierEnum.optional(),
  sort: z.enum(['trust', 'name', 'recent', 'stakers', 'safety']).optional().default('trust'),
  limit: z.coerce.number().min(1).max(100).optional().default(20),
  offset: z.coerce.number().min(0).optional().default(0),
})

export type AgentListParams = z.infer<typeof agentListSchema>

export const skillListSchema = z.object({
  q: z.string().optional(),
  capability: z.string().optional(),
  platformId: z.string().optional(),
  safetyStatus: safetyStatusEnum.optional(),
  sort: z.enum(['trust', 'name', 'recent', 'safety']).optional().default('trust'),
  limit: z.coerce.number().min(1).max(100).optional().default(20),
  offset: z.coerce.number().min(0).optional().default(0),
})

export type SkillListParams = z.infer<typeof skillListSchema>

export const matchSchema = z.object({
  required_capabilities: z.array(z.string()).min(1).optional(),
  requiredCapabilities: z.array(z.string()).min(1).optional(),
  preferred_capabilities: z.array(z.string()).optional(),
  preferredCapabilities: z.array(z.string()).optional(),
  min_trust_tier: trustTierEnum.optional(),
  minTrustTier: trustTierEnum.optional(),
  match_all: z.boolean().optional(),
  matchAll: z.boolean().optional(),
  sort_by: z.enum(['trust', 'match_score', 'stakers']).optional(),
  sortBy: z.enum(['trust', 'match_score', 'stakers']).optional(),
  limit: z.number().min(1).max(100).optional(),
}).superRefine((value, ctx) => {
  const required = value.required_capabilities ?? value.requiredCapabilities
  if (!required || required.length === 0) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'required_capabilities (or requiredCapabilities) must contain at least one capability',
      path: ['required_capabilities'],
    })
  }
}).transform((value) => ({
  required_capabilities: value.required_capabilities ?? value.requiredCapabilities ?? [],
  preferred_capabilities: value.preferred_capabilities ?? value.preferredCapabilities ?? [],
  min_trust_tier: value.min_trust_tier ?? value.minTrustTier,
  match_all: value.match_all ?? value.matchAll ?? true,
  sort_by: value.sort_by ?? value.sortBy ?? 'match_score',
  limit: value.limit ?? 20,
}))

export type MatchParams = z.infer<typeof matchSchema>

export const batchVerifySchema = z.object({
  skill_ids: z.array(z.string()).min(1).max(50),
})

export type BatchVerifyParams = z.infer<typeof batchVerifySchema>

export const termIdSchema = z.string().regex(/^0x[0-9a-fA-F]{64}$/, 'must be a bytes32 term id')

const relationshipContextSchema = z.object({
  typePredicateTermId: termIdSchema.optional(),
  typeObjectTermId: termIdSchema.optional(),
  hasCapabilityPredicateTermId: termIdSchema.optional(),
  capabilityTermIds: z.array(termIdSchema).max(100).optional(),
  usesSkillPredicateTermId: termIdSchema.optional(),
  skillTermIds: z.array(termIdSchema).max(100).optional(),
  // v3: has-metadata predicate for linking identity to metadata atom
  hasMetadataPredicateTermId: termIdSchema.optional(),
  // v3: created-by predicate and creator atom
  createdByPredicateTermId: termIdSchema.optional(),
  creatorTermId: termIdSchema.optional(),
})

export const registerAgentSchema = z.object({
  name: z.string().min(1).max(100),
  description: z.string().min(1).max(500),
  version: z.string().regex(/^\d+\.\d+\.\d+$/),
  image: z.string().url().optional(),
  model: z.string().optional(),
  endpoint: z.string().url().optional(),
  provider: z
    .object({
      name: z.string(),
      url: z.string().url().optional(),
    })
    .optional(),
  tags: z.array(z.string()).max(10).optional(),
  defaultInputModes: z.array(z.string()).optional(),
  defaultOutputModes: z.array(z.string()).optional(),
  relationshipContext: relationshipContextSchema.optional(),
  requireTwoSignatures: z.boolean().optional().default(false),
})

export type RegisterAgentParams = z.infer<typeof registerAgentSchema>

export const registerSkillSchema = z.object({
  name: z.string().min(1).max(100),
  description: z.string().min(1).max(500),
  version: z.string().regex(/^\d+\.\d+\.\d+$/),
  platform: z.enum(['mcp', 'claude-code', 'openclaw', 'openai', 'x402', 'other']),
  image: z.string().url().optional(),
  author: z.string().optional(),
  installUri: z.string().optional(),
  permissions: z.array(z.string()).optional(),
  longDescription: z.string().optional(),
  relationshipContext: relationshipContextSchema.optional(),
  requireTwoSignatures: z.boolean().optional().default(false),
})

export type RegisterSkillParams = z.infer<typeof registerSkillSchema>

export const metadataUpdateSchema = z.object({
  entityTermId: termIdSchema,
  entityType: z.enum(['agent', 'skill']),
  requireTwoSignatures: z.boolean().optional().default(true),
  hasMetadataPredicateTermId: termIdSchema.optional(),
  metadata: z.record(z.string(), z.unknown()),
})

export type MetadataUpdateParams = z.infer<typeof metadataUpdateSchema>

export const trustScoreSchema = z.object({
  modelId: z.string().min(1),
  version: z.string().regex(/^\d+\.\d+\.\d+$/),
  snapshotId: z.string().min(1),
  snapshotTimestamp: z.string().datetime().optional(),
  ttlSeconds: z.number().int().min(60).max(86400).optional().default(3600),
  candidates: z.array(
    z.object({
      id: z.string().min(1),
      inputs: z.record(z.string(), z.unknown()),
      claimIds: z.array(z.string()).optional().default([]),
      traversalPath: z.array(z.string()).optional().default([]),
      vaultSnapshots: z.array(
        z.object({
          termId: z.string(),
          marketCapWei: z.string().regex(/^\d+$/),
          stakerCount: z.number().int().nonnegative(),
          sharePriceWei: z.string().regex(/^\d+$/),
        }),
      ).optional().default([]),
    }),
  ).min(1).max(100),
})

export type TrustScoreParams = z.infer<typeof trustScoreSchema>

export const trustStakeSchema = z
  .object({
    termId: termIdSchema,
    amountWei: z.string().regex(/^\d+$/).optional(),
    amountEth: z.string().regex(/^\d+(\.\d+)?$/).optional(),
    curveId: z.coerce.number().int().nonnegative().optional(),
    direction: z.enum(['for', 'against']).optional(),
    minShares: z.string().regex(/^\d+$/).optional(),
  })
  .superRefine((value, ctx) => {
    if (!value.amountWei && !value.amountEth) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['amountWei'],
        message: 'amountWei or amountEth is required',
      })
    }
  })

export type TrustStakeParams = z.infer<typeof trustStakeSchema>

// --- Generic atom/triple creation schemas ---

export const createAtomsSchema = z.object({
  atomData: z.array(z.string().min(1).max(10000)).min(1).max(20),
  depositPerAtom: z.string().regex(/^\d+$/).optional(),
})

export type CreateAtomsParams = z.infer<typeof createAtomsSchema>

export const createTriplesSchema = z.object({
  triples: z.array(z.object({
    subjectId: termIdSchema,
    predicateId: termIdSchema,
    objectId: termIdSchema,
  })).min(1).max(20),
  depositPerTriple: z.string().regex(/^\d+$/).optional(),
})

export type CreateTriplesParams = z.infer<typeof createTriplesSchema>

export const queryTriplesSchema = z.object({
  subjectId: termIdSchema.optional(),
  predicateId: termIdSchema.optional(),
  objectId: termIdSchema.optional(),
  limit: z.coerce.number().min(1).max(100).optional().default(20),
  offset: z.coerce.number().min(0).optional().default(0),
}).superRefine((value, ctx) => {
  if (!value.subjectId && !value.predicateId && !value.objectId) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'At least one of subjectId, predicateId, or objectId is required',
      path: ['subjectId'],
    })
  }
})

export type QueryTriplesParams = z.infer<typeof queryTriplesSchema>

export const searchAtomsSchema = z.object({
  q: z.string().min(1).max(200),
  type: z.string().optional(),
  limit: z.coerce.number().min(1).max(100).optional().default(20),
  offset: z.coerce.number().min(0).optional().default(0),
})

export type SearchAtomsParams = z.infer<typeof searchAtomsSchema>
