import { useState } from 'react'
import * as Collapsible from '@radix-ui/react-collapsible'
import { ChevronDown, TrendingUp } from 'lucide-react'
import type { Agent } from '~/types'
import { cn } from '~/lib/utils'
import { formatWeiToEth } from '~/lib/vault-utils'
import { TrustTierBadge } from '~/components/registry/TrustTierBadge'

interface TrustZoneProps {
  agent: Agent
  className?: string
}

export function TrustZone({ agent, className }: TrustZoneProps) {
  const [isOpen, setIsOpen] = useState(true)
  const { trustSignal, vault } = agent

  // Format vault values
  const tvlEth = formatWeiToEth(vault.total_assets)
  const sharePriceEth = formatWeiToEth(vault.current_share_price)
  const marketCapEth = formatWeiToEth(vault.market_cap)

  // Format percentile as ordinal (87th, 92nd, etc.)
  const getOrdinal = (n: number) => {
    const s = ['th', 'st', 'nd', 'rd']
    const v = n % 100
    return n + (s[(v - 20) % 10] || s[v] || s[0])
  }

  return (
    <Collapsible.Root
      open={isOpen}
      onOpenChange={setIsOpen}
      className={cn(
        'rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)]',
        className,
      )}
    >
      <Collapsible.Trigger className="flex w-full items-center justify-between p-4 hover:bg-muted/50 transition-colors">
        <h2 className="font-mono text-xs tracking-widest uppercase text-ink-dull">Trust Metrics</h2>
        <ChevronDown
          className={cn(
            'h-5 w-5 text-muted-foreground transition-transform',
            isOpen && 'rotate-180',
          )}
        />
      </Collapsible.Trigger>

      <Collapsible.Content className="px-4 pb-4">
        {/* Trust tier badge */}
        <div className="mb-4">
          <TrustTierBadge
            tier={trustSignal.tier}
            percentile={trustSignal.percentile}
            size="md"
          />
        </div>

        {/* Metrics grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <div>
            <div className="font-mono text-[10px] tracking-widest uppercase text-ink-faint mb-1">Total Staked</div>
            <div className="font-mono text-lg font-semibold text-card-foreground">
              {tvlEth} TRUST
            </div>
          </div>

          <div>
            <div className="font-mono text-[10px] tracking-widest uppercase text-ink-faint mb-1">Stakers</div>
            <div className="font-mono text-lg font-semibold text-card-foreground">
              {trustSignal.stakerCount.toLocaleString()}
            </div>
          </div>

          <div>
            <div className="font-mono text-[10px] tracking-widest uppercase text-ink-faint mb-1">Share Price</div>
            <div className="font-mono text-lg font-semibold text-card-foreground">
              {sharePriceEth} TRUST
            </div>
          </div>

          <div>
            <div className="font-mono text-[10px] tracking-widest uppercase text-ink-faint mb-1">Market Cap</div>
            <div className="font-mono text-lg font-semibold text-card-foreground">
              {marketCapEth} TRUST
            </div>
          </div>
        </div>

        {/* Percentile ranking */}
        <div className="flex items-center gap-2 p-3 rounded bg-muted/50">
          <TrendingUp className="h-5 w-5 text-brand" />
          <span className="font-mono text-xs text-card-foreground">
            Ranked in the <strong>{getOrdinal(trustSignal.percentile)}</strong> percentile
            among all agents
          </span>
        </div>

        {/* Sparkline placeholder - can be implemented later with price history */}
        {/* {vault.priceHistory && vault.priceHistory.length > 0 && (
          <div className="mt-4">
            <div className="text-xs text-muted-foreground mb-2">Price History</div>
            <div className="h-16 bg-muted/30 rounded flex items-center justify-center">
              <span className="text-xs text-muted-foreground">Sparkline coming soon</span>
            </div>
          </div>
        )} */}
      </Collapsible.Content>
    </Collapsible.Root>
  )
}
