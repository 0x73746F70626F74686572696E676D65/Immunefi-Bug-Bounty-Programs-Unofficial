import { useCallback } from 'react'
import { useWriteContract, useWaitForTransactionReceipt } from 'wagmi'

/**
 * Wraps wagmi's useWriteContract + useWaitForTransactionReceipt into a single
 * hook that exposes wallet-pending and on-chain-pending states.
 *
 * Mirrors Portal's useContractWriteAndWait pattern.
 */
export function useContractWriteAndWait() {
  const {
    writeContractAsync,
    data: txHash,
    isPending: awaitingWalletConfirmation,
    isError: isWriteError,
    error: writeError,
    reset: resetWrite,
  } = useWriteContract()

  const {
    data: receipt,
    isLoading: awaitingOnChainConfirmation,
    isError: isReceiptError,
    error: receiptError,
  } = useWaitForTransactionReceipt({ hash: txHash })

  const reset = useCallback(() => {
    resetWrite()
  }, [resetWrite])

  return {
    writeContractAsync,
    txHash,
    receipt,
    awaitingWalletConfirmation,
    awaitingOnChainConfirmation,
    isError: isWriteError || isReceiptError,
    error: writeError || receiptError,
    reset,
  }
}
