import { useEffect, useState } from 'react'

export function useProgressiveImage(lowSrc: string, highSrc: string) {
  const [src, setSrc] = useState(lowSrc)
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    const img = new Image()
    img.onload = () => {
      setSrc(highSrc)
      setIsLoaded(true)
    }
    img.src = highSrc
    return () => {
      img.onload = null
    }
  }, [highSrc])

  return { src, isLoaded }
}
