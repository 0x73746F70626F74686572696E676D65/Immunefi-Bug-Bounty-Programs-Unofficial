export interface Model {
  id: string
  name: string
  providerId: string
  description?: string
}
