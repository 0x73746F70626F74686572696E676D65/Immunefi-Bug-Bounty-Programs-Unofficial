export interface MetadataRevisionRecord {
  metadataTermId: string
  blockNumber: number
  logIndex: number
}

export function resolveLatestMetadataTermId(
  revisions: MetadataRevisionRecord[],
): string | null {
  if (revisions.length === 0) return null
  const sorted = [...revisions].sort((a, b) => {
    if (a.blockNumber !== b.blockNumber) return b.blockNumber - a.blockNumber
    return b.logIndex - a.logIndex
  })
  return sorted[0]?.metadataTermId ?? null
}
