import { useState, useEffect, useRef, useCallback } from 'react'
import { formatEther } from 'viem'
import { useAccount } from 'wagmi'
import type { Agent } from '~/types'
import type { Triple } from '~/types/triple'
import type { Capability } from '~/types/capability'
import { cn } from '~/lib/utils'
import { formatWeiToEth } from '~/lib/vault-utils'
import { useStakeTransaction } from '~/lib/hooks/useStakeTransaction'
import { useDepositPreview } from '~/lib/hooks/useDepositPreview'
import { useTransactionToast } from '~/components/staking/TransactionToast'
import type { NetworkId } from '~/lib/constants/protocol'

// ── Types ──────────────────────────────────────────────────────────────────

interface AgentCapabilityZoneProps {
  agent: Agent
  className?: string
}

type Direction = 'vouch' | 'deny'
type FlowStep = 'idle' | 'tiers' | 'confirm' | 'pending' | 'done'

// ── Constants ──────────────────────────────────────────────────────────────

const GREEN = '#22c55e'
const YELLOW = '#eab308'
const RED = '#ef4444'

const TIERS = [
  { amount: '0.01', label: 'NUDGE' },
  { amount: '0.05', label: 'SIGNAL' },
  { amount: '0.25', label: 'STRONG' },
  { amount: '1.00', label: 'CONVICTION' },
] as const

// ── Helpers ────────────────────────────────────────────────────────────────

function computeTrustPercent(triple: Triple | undefined): number | null {
  if (!triple?.vault) return null
  const { forVault, againstVault } = triple.vault
  const forAssets = BigInt(forVault.total_assets || '0')
  const againstAssets = againstVault ? BigInt(againstVault.total_assets || '0') : 0n
  const total = forAssets + againstAssets
  if (total === 0n) return null
  return Number((forAssets * 10000n) / total) / 100
}

function trustColor(pct: number | null): string {
  if (pct === null) return '#4a4a60'
  if (pct > 70) return GREEN
  if (pct >= 40) return YELLOW
  return RED
}

function trustGlow(pct: number | null): string {
  const c = trustColor(pct)
  const alpha = pct === null ? '40' : '66'
  return `0 0 6px ${c}${alpha}`
}

function trustLabel(pct: number | null): string {
  if (pct === null) return 'NO DATA'
  if (pct > 80) return 'VERIFIED'
  if (pct >= 50) return 'UNVERIFIED'
  return 'FLAGGED'
}

function getNetwork(): NetworkId {
  return (
    ((typeof window !== 'undefined' ? window.ENV?.CHAIN : undefined) as NetworkId) || 'testnet'
  )
}

// ── TrustRing ──────────────────────────────────────────────────────────────

interface TrustRingProps {
  pct: number | null
  size?: number
}

function TrustRing({ pct, size = 64 }: TrustRingProps) {
  const color = trustColor(pct)
  const radius = (size - 8) / 2
  const circumference = 2 * Math.PI * radius
  const fill = pct !== null ? (pct / 100) * circumference : 0
  const label = pct !== null ? `${Math.round(pct)}%` : '—'
  const fontSize = size <= 48 ? 11 : 16

  return (
    <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        {/* Track */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="#1e1e2e"
          strokeWidth={4}
        />
        {/* Fill */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={4}
          strokeDasharray={`${fill} ${circumference}`}
          strokeLinecap="round"
          style={{
            filter: `drop-shadow(0 0 3px ${color}80)`,
            transition: 'stroke-dasharray 0.4s ease',
          }}
        />
      </svg>
      <div
        style={{
          position: 'absolute',
          inset: 0,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontFamily: 'monospace',
          fontSize,
          fontWeight: 900,
          color,
          letterSpacing: '-0.02em',
        }}
      >
        {label}
      </div>
    </div>
  )
}

// ── VaultBars ──────────────────────────────────────────────────────────────

interface VaultBarsProps {
  triple: Triple
}

function VaultBars({ triple }: VaultBarsProps) {
  if (!triple.vault) return null

  const forAssets = BigInt(triple.vault.forVault.total_assets || '0')
  const againstAssets = BigInt(triple.vault.againstVault?.total_assets || '0')
  const total = forAssets + againstAssets

  const forPct = total > 0n ? Number((forAssets * 100n) / total) : 0
  const agPct = total > 0n ? Number((againstAssets * 100n) / total) : 0

  const forTrust = formatWeiToEth(triple.vault.forVault.total_assets, 3)
  const agTrust = formatWeiToEth(triple.vault.againstVault?.total_assets ?? '0', 3)

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {/* FOR bar */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'monospace', fontSize: 9, marginBottom: 3 }}>
          <span style={{ color: '#4a4a60', letterSpacing: '0.08em' }}>FOR</span>
          <span style={{ color: GREEN, fontWeight: 700 }}>{forTrust} TRUST</span>
        </div>
        <div style={{ height: 4, background: '#1e1e2e', borderRadius: 2, overflow: 'hidden' }}>
          <div
            style={{
              height: '100%',
              width: `${forPct}%`,
              background: GREEN,
              boxShadow: `0 0 6px ${GREEN}60`,
              borderRadius: 2,
              transition: 'width 0.4s ease',
            }}
          />
        </div>
      </div>

      {/* AGAINST bar */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'monospace', fontSize: 9, marginBottom: 3 }}>
          <span style={{ color: '#4a4a60', letterSpacing: '0.08em' }}>AGAINST</span>
          <span style={{ color: RED, fontWeight: 700 }}>{agTrust} TRUST</span>
        </div>
        <div style={{ height: 4, background: '#1e1e2e', borderRadius: 2, overflow: 'hidden' }}>
          <div
            style={{
              height: '100%',
              width: `${agPct}%`,
              background: RED,
              boxShadow: `0 0 6px ${RED}60`,
              borderRadius: 2,
              transition: 'width 0.4s ease',
            }}
          />
        </div>
      </div>
    </div>
  )
}

// ── VaultStatsBlock ────────────────────────────────────────────────────────

interface VaultStatsBlockProps {
  triple: Triple
}

function VaultStatsBlock({ triple }: VaultStatsBlockProps) {
  if (!triple.vault) return null

  const { forVault, againstVault } = triple.vault
  const totalTrust = formatWeiToEth(
    (BigInt(forVault.total_assets || '0') + BigInt(againstVault?.total_assets || '0')).toString(),
    3,
  )
  const totalStakers = forVault.position_count + (againstVault?.position_count ?? 0)
  const sharePrice = formatWeiToEth(forVault.current_share_price || '0', 4)

  const rows: [string, string][] = [
    ['TVL', `${totalTrust} TRUST`],
    ['STAKERS', `${totalStakers}`],
    ['SHARE PRICE', `${sharePrice}`],
  ]

  return (
    <div
      style={{
        borderTop: '1px solid #1e1e2e',
        paddingTop: 10,
        display: 'flex',
        flexDirection: 'column',
        gap: 4,
      }}
    >
      <div
        style={{
          fontFamily: 'monospace',
          fontSize: 9,
          letterSpacing: '0.12em',
          textTransform: 'uppercase',
          color: '#4a4a60',
          marginBottom: 4,
        }}
      >
        VAULT STATS
      </div>
      {rows.map(([label, value]) => (
        <div
          key={label}
          style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'monospace', fontSize: 10 }}
        >
          <span style={{ color: '#4a4a60' }}>{label}</span>
          <span style={{ color: '#e0e0e8', fontWeight: 700 }}>{value}</span>
        </div>
      ))}
    </div>
  )
}

// ── StakingPanel ───────────────────────────────────────────────────────────

interface StakingPanelProps {
  triple: Triple
  capabilityName: string
}

function StakingPanel({ triple, capabilityName }: StakingPanelProps) {
  const { isConnected } = useAccount()
  const { addTransaction } = useTransactionToast()

  const [step, setStep] = useState<FlowStep>('idle')
  const [direction, setDirection] = useState<Direction>('vouch')
  const [selectedAmount, setSelectedAmount] = useState('')
  const successFired = useRef(false)

  const network = getNetwork()
  const curveId = direction === 'vouch' ? 0n : 1n

  const {
    stake,
    txHash,
    receipt,
    awaitingWalletConfirmation,
    awaitingOnChainConfirmation,
    isError,
    error,
    reset: resetTx,
  } = useStakeTransaction({ termId: triple.term_id, network, curveId })

  const { shares, fees, isLoading: previewLoading } = useDepositPreview({
    termId: triple.term_id,
    curveId,
    amount: selectedAmount,
    network,
    enabled: isConnected && step === 'confirm' && parseFloat(selectedAmount) > 0,
  })

  const isSuccess = receipt?.status === 'success'
  const isBusy = awaitingWalletConfirmation || awaitingOnChainConfirmation
  const accentColor = direction === 'vouch' ? GREEN : RED

  // Transition to done + dispatch toast on success
  useEffect(() => {
    if (isSuccess && txHash && !successFired.current) {
      successFired.current = true
      setStep('done')
      const dirLabel = direction === 'vouch' ? 'VOUCH' : 'DENY'
      addTransaction({
        hash: txHash,
        label: `${dirLabel} ${capabilityName.toUpperCase()}`,
        direction: direction === 'vouch' ? 'for' : 'against',
        amount: selectedAmount,
      })
    }
  }, [isSuccess, txHash, direction, capabilityName, selectedAmount, addTransaction])

  // Transition to pending when tx submitted
  useEffect(() => {
    if ((awaitingWalletConfirmation || awaitingOnChainConfirmation) && step === 'confirm') {
      setStep('pending')
    }
  }, [awaitingWalletConfirmation, awaitingOnChainConfirmation, step])

  // Auto-reset to idle after done
  useEffect(() => {
    if (step !== 'done') return
    const timer = setTimeout(() => {
      handleReset()
    }, 2500)
    return () => clearTimeout(timer)
  }, [step])

  const handleReset = useCallback(() => {
    setStep('idle')
    setDirection('vouch')
    setSelectedAmount('')
    resetTx()
    successFired.current = false
  }, [resetTx])

  const handleDirectionClick = useCallback((dir: Direction) => {
    setDirection(dir)
    setStep('tiers')
  }, [])

  const handleTierSelect = useCallback((amount: string) => {
    setSelectedAmount(amount)
    setStep('confirm')
  }, [])

  const handleConfirm = useCallback(async () => {
    if (!selectedAmount || parseFloat(selectedAmount) <= 0) return
    successFired.current = false
    try {
      await stake(selectedAmount)
    } catch {
      // error handled by hook state
    }
  }, [selectedAmount, stake])

  const handleRetry = useCallback(() => {
    resetTx()
    setStep('confirm')
  }, [resetTx])

  const statusText = awaitingWalletConfirmation
    ? 'CONFIRM IN WALLET'
    : awaitingOnChainConfirmation
      ? 'AWAITING CHAIN...'
      : 'PROCESSING...'

  // Minimum height so panel doesn't shift layout on state changes
  const minHeight = 110

  return (
    <>
      <style>{`
        @keyframes capzone-slide-down {
          from { opacity: 0; transform: translateY(-8px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes capzone-fade-in {
          from { opacity: 0; }
          to   { opacity: 1; }
        }
        @keyframes capzone-step-enter {
          from { opacity: 0; transform: translateX(10px); }
          to   { opacity: 1; transform: translateX(0); }
        }
        @keyframes capzone-dots {
          0%, 80%, 100% { opacity: 0.2; }
          40%            { opacity: 1; }
        }
        .capzone-dots span:nth-child(1) { animation-delay: 0s; }
        .capzone-dots span:nth-child(2) { animation-delay: 0.15s; }
        .capzone-dots span:nth-child(3) { animation-delay: 0.3s; }
      `}</style>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, minHeight }}>
        {!isConnected && (
          <p style={{ fontFamily: 'monospace', fontSize: 10, letterSpacing: '0.08em', color: '#4a4a60', textAlign: 'center', paddingTop: 8 }}>
            CONNECT WALLET TO STAKE
          </p>
        )}

        {isConnected && (
          <div
            key={step}
            style={{ animation: 'capzone-step-enter 0.18s ease both' }}
          >
            {/* IDLE: vouch / deny buttons */}
            {step === 'idle' && (
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  type="button"
                  onClick={() => handleDirectionClick('vouch')}
                  style={{
                    flex: 1,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 6,
                    padding: '10px 0',
                    borderRadius: 8,
                    border: `1px solid ${GREEN}4d`,
                    background: `${GREEN}1a`,
                    color: GREEN,
                    fontFamily: 'monospace',
                    fontSize: 11,
                    fontWeight: 700,
                    letterSpacing: '0.1em',
                    textTransform: 'uppercase',
                    cursor: 'pointer',
                    transition: 'background 0.12s, box-shadow 0.12s',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = `${GREEN}26`
                    e.currentTarget.style.boxShadow = `0 0 10px ${GREEN}20`
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = `${GREEN}1a`
                    e.currentTarget.style.boxShadow = 'none'
                  }}
                >
                  <span>▲</span> VOUCH
                </button>
                <button
                  type="button"
                  onClick={() => handleDirectionClick('deny')}
                  style={{
                    flex: 1,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 6,
                    padding: '10px 0',
                    borderRadius: 8,
                    border: `1px solid ${RED}4d`,
                    background: `${RED}1a`,
                    color: RED,
                    fontFamily: 'monospace',
                    fontSize: 11,
                    fontWeight: 700,
                    letterSpacing: '0.1em',
                    textTransform: 'uppercase',
                    cursor: 'pointer',
                    transition: 'background 0.12s, box-shadow 0.12s',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = `${RED}26`
                    e.currentTarget.style.boxShadow = `0 0 10px ${RED}20`
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = `${RED}1a`
                    e.currentTarget.style.boxShadow = 'none'
                  }}
                >
                  <span>▼</span> DENY
                </button>
              </div>
            )}

            {/* TIERS: active direction + tier grid */}
            {step === 'tiers' && (
              <div style={{ animation: 'capzone-slide-down 0.2s ease-out both' }}>
                {/* Direction row: active filled, reset button */}
                <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
                  <div
                    style={{
                      flex: 1,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: 6,
                      padding: '8px 0',
                      borderRadius: 8,
                      border: `1px solid ${accentColor}66`,
                      background: `${accentColor}26`,
                      color: accentColor,
                      fontFamily: 'monospace',
                      fontSize: 11,
                      fontWeight: 700,
                      letterSpacing: '0.1em',
                      textTransform: 'uppercase',
                    }}
                  >
                    {direction === 'vouch' ? '▲ VOUCHING' : '▼ DENYING'}
                  </div>
                  <button
                    type="button"
                    onClick={handleReset}
                    style={{
                      flexShrink: 0,
                      padding: '8px 12px',
                      borderRadius: 8,
                      border: '1px solid #1e1e2e',
                      background: 'transparent',
                      color: '#4a4a60',
                      fontFamily: 'monospace',
                      fontSize: 11,
                      cursor: 'pointer',
                      transition: 'color 0.12s',
                    }}
                    onMouseEnter={(e) => { e.currentTarget.style.color = '#6b6b80' }}
                    onMouseLeave={(e) => { e.currentTarget.style.color = '#4a4a60' }}
                  >
                    ✕
                  </button>
                </div>

                {/* Tier buttons */}
                <div style={{ display: 'flex', gap: 6 }}>
                  {TIERS.map((tier) => (
                    <button
                      key={tier.amount}
                      type="button"
                      onClick={() => handleTierSelect(tier.amount)}
                      style={{
                        flex: 1,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        gap: 3,
                        padding: '8px 4px',
                        borderRadius: 6,
                        border: `1px solid #1e1e2e`,
                        background: '#0a0a12',
                        color: '#e0e0e8',
                        fontFamily: 'monospace',
                        cursor: 'pointer',
                        transition: 'border-color 0.12s, background 0.12s',
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.borderColor = `${accentColor}60`
                        e.currentTarget.style.background = `${accentColor}12`
                        ;(e.currentTarget.querySelector('.tier-amount') as HTMLElement).style.color = accentColor
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.borderColor = '#1e1e2e'
                        e.currentTarget.style.background = '#0a0a12'
                        ;(e.currentTarget.querySelector('.tier-amount') as HTMLElement).style.color = '#e0e0e8'
                      }}
                    >
                      <span
                        className="tier-amount"
                        style={{ fontSize: 11, fontWeight: 700, transition: 'color 0.12s' }}
                      >
                        {tier.amount}
                      </span>
                      <span style={{ fontSize: 8, color: '#4a4a60', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                        {tier.label}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* CONFIRM: summary + stake button */}
            {step === 'confirm' && !isError && (
              <div style={{ animation: 'capzone-fade-in 0.15s ease both' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  {/* Left: staking info */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontFamily: 'monospace', fontSize: 9, letterSpacing: '0.1em', color: '#4a4a60', textTransform: 'uppercase', marginBottom: 2 }}>
                      STAKING
                    </div>
                    <div style={{ fontFamily: 'monospace', fontSize: 17, fontWeight: 900, color: accentColor, lineHeight: 1 }}>
                      {selectedAmount} TRUST
                    </div>
                    <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#6b6b80', marginTop: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {direction === 'vouch' ? 'vouching' : 'denying'} · {capabilityName}
                    </div>
                    <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#4a4a60', marginTop: 4, minHeight: 14 }}>
                      {previewLoading ? (
                        <span style={{ animation: 'capzone-dots 1.4s ease-in-out infinite' }}>CALCULATING...</span>
                      ) : shares > 0n ? (
                        <span>FEE: {formatEther(fees)} TRUST · {parseFloat(formatEther(shares)).toFixed(4)} SHARES</span>
                      ) : null}
                    </div>
                  </div>

                  {/* Right: back + stake */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6, flexShrink: 0 }}>
                    <button
                      type="button"
                      onClick={() => setStep('tiers')}
                      disabled={isBusy}
                      style={{
                        padding: '7px 10px',
                        borderRadius: 6,
                        border: '1px solid #1e1e2e',
                        background: 'transparent',
                        color: '#6b6b80',
                        fontFamily: 'monospace',
                        fontSize: 11,
                        cursor: isBusy ? 'not-allowed' : 'pointer',
                        opacity: isBusy ? 0.4 : 1,
                        transition: 'color 0.12s',
                      }}
                    >
                      ←
                    </button>
                    <button
                      type="button"
                      onClick={handleConfirm}
                      disabled={isBusy}
                      style={{
                        padding: '7px 14px',
                        borderRadius: 6,
                        border: 'none',
                        background: accentColor,
                        color: '#fff',
                        fontFamily: 'monospace',
                        fontSize: 11,
                        fontWeight: 700,
                        letterSpacing: '0.08em',
                        cursor: isBusy ? 'not-allowed' : 'pointer',
                        opacity: isBusy ? 0.5 : 1,
                        boxShadow: `0 3px 12px ${accentColor}40`,
                        transition: 'opacity 0.12s',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      STAKE →
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* CONFIRM error state */}
            {step === 'confirm' && isError && (
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
                <div>
                  <div style={{ fontFamily: 'monospace', fontSize: 11, fontWeight: 700, color: RED, letterSpacing: '0.08em' }}>TX FAILED</div>
                  <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#6b6b80', marginTop: 2 }}>
                    {error?.message?.includes('rejected') ? 'REJECTED BY USER' : 'TRANSACTION FAILED'}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleRetry}
                  style={{
                    padding: '6px 12px',
                    borderRadius: 6,
                    border: `1px solid ${RED}66`,
                    background: 'transparent',
                    color: RED,
                    fontFamily: 'monospace',
                    fontSize: 10,
                    fontWeight: 700,
                    letterSpacing: '0.08em',
                    cursor: 'pointer',
                  }}
                >
                  RETRY
                </button>
              </div>
            )}

            {/* PENDING state */}
            {step === 'pending' && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '4px 0' }}>
                <div
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: '50%',
                    border: `1.5px solid ${accentColor}60`,
                    background: `${accentColor}18`,
                    flexShrink: 0,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    animation: 'capzone-dots 1.4s ease-in-out infinite',
                  }}
                >
                  <span style={{ fontFamily: 'monospace', fontSize: 14, color: accentColor }}>···</span>
                </div>
                <div>
                  <div
                    style={{
                      fontFamily: 'monospace',
                      fontSize: 10,
                      fontWeight: 700,
                      letterSpacing: '0.1em',
                      color: accentColor,
                      animation: 'capzone-dots 1.4s ease-in-out infinite',
                    }}
                  >
                    {statusText}
                  </div>
                  <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#6b6b80', marginTop: 2 }}>
                    {selectedAmount} TRUST · {direction === 'vouch' ? 'VOUCH' : 'DENY'}
                  </div>
                </div>
              </div>
            )}

            {/* DONE state */}
            {step === 'done' && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '4px 0', animation: 'capzone-fade-in 0.2s ease both' }}>
                <div
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: '50%',
                    border: `1.5px solid ${GREEN}60`,
                    background: `${GREEN}18`,
                    flexShrink: 0,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <span style={{ fontFamily: 'monospace', fontSize: 14, color: GREEN }}>✓</span>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: 'monospace', fontSize: 10, fontWeight: 700, letterSpacing: '0.1em', color: GREEN }}>STAKED</div>
                  <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#6b6b80', marginTop: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {selectedAmount} TRUST · {txHash ? `${txHash.slice(0, 10)}...` : ''}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </>
  )
}

// ── CapabilityCard ─────────────────────────────────────────────────────────

interface CapabilityCardProps {
  capability: Capability
  triple: Triple | undefined
  isSelected: boolean
  onSelect: () => void
}

function CapabilityCard({ capability, triple, isSelected, onSelect }: CapabilityCardProps) {
  const pct = computeTrustPercent(triple)
  const color = trustColor(pct)
  const glow = trustGlow(pct)
  const forCount = triple?.vault?.forVault.position_count ?? 0
  const againstCount = triple?.vault?.againstVault?.position_count ?? 0
  const totalStakers = forCount + againstCount

  return (
    <button
      type="button"
      onClick={onSelect}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        width: '100%',
        padding: '10px 16px',
        background: isSelected ? '#1a1a28' : 'transparent',
        border: 'none',
        borderLeft: `3px solid ${isSelected ? color : 'transparent'}`,
        borderBottom: '1px solid #1e1e2e',
        cursor: 'pointer',
        textAlign: 'left',
        boxShadow: isSelected ? `inset 0 0 24px ${color}08` : 'none',
        transition: 'background 0.12s, border-left-color 0.12s, box-shadow 0.12s',
      }}
      onMouseEnter={(e) => {
        if (!isSelected) {
          e.currentTarget.style.background = '#14141e'
          e.currentTarget.style.borderLeftColor = `${color}50`
        }
      }}
      onMouseLeave={(e) => {
        if (!isSelected) {
          e.currentTarget.style.background = 'transparent'
          e.currentTarget.style.borderLeftColor = 'transparent'
        }
      }}
    >
      {/* Status dot */}
      <div
        style={{
          width: 8,
          height: 8,
          borderRadius: '50%',
          background: color,
          flexShrink: 0,
          boxShadow: glow,
        }}
      />

      {/* Name + description */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          style={{
            fontFamily: 'monospace',
            fontSize: 11,
            fontWeight: 700,
            color: isSelected ? color : '#e0e0e8',
            letterSpacing: '0.04em',
            textTransform: 'uppercase',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            transition: 'color 0.12s',
          }}
        >
          {capability.name}
        </div>
        {capability.description && (
          <div
            style={{
              fontFamily: 'monospace',
              fontSize: 9,
              color: '#6b6b80',
              marginTop: 2,
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
            }}
          >
            {capability.description}
          </div>
        )}
      </div>

      {/* Trust % + stakers */}
      <div style={{ flexShrink: 0, textAlign: 'right' }}>
        <div
          style={{
            fontFamily: 'monospace',
            fontSize: 15,
            fontWeight: 900,
            color,
            letterSpacing: '-0.02em',
            lineHeight: 1,
          }}
        >
          {pct !== null ? `${Math.round(pct)}%` : '—'}
        </div>
        <div
          style={{
            fontFamily: 'monospace',
            fontSize: 8,
            color: '#4a4a60',
            marginTop: 2,
          }}
        >
          {totalStakers > 0 ? (
            <span>
              {forCount > 0 && <span style={{ color: `${GREEN}aa` }}>{forCount} ▲</span>}
              {forCount > 0 && againstCount > 0 && ' '}
              {againstCount > 0 && <span style={{ color: `${RED}aa` }}>{againstCount} ▼</span>}
            </span>
          ) : (
            '0 stakers'
          )}
        </div>
      </div>
    </button>
  )
}

// ── RightPanel ─────────────────────────────────────────────────────────────

interface RightPanelProps {
  capability: Capability
  triple: Triple | undefined
}

function RightPanel({ capability, triple }: RightPanelProps) {
  const pct = computeTrustPercent(triple)
  const color = trustColor(pct)
  const label = trustLabel(pct)

  return (
    <div
      key={capability.id}
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 14,
        animation: 'capzone-fade-in 0.18s ease both',
        padding: '14px 16px',
        height: '100%',
      }}
    >
      {/* Claim label + name */}
      <div>
        <div
          style={{
            fontFamily: 'monospace',
            fontSize: 9,
            letterSpacing: '0.12em',
            textTransform: 'uppercase',
            color: '#4a4a60',
            marginBottom: 4,
          }}
        >
          CLAIM
        </div>
        <div
          style={{
            fontFamily: 'monospace',
            fontSize: 14,
            fontWeight: 900,
            color,
            textTransform: 'uppercase',
            letterSpacing: '0.03em',
            lineHeight: 1.2,
          }}
        >
          HOW GOOD IS {capability.name.toUpperCase()}?
        </div>
      </div>

      {/* Trust ring + status */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
        <TrustRing pct={pct} size={64} />
        <div
          style={{
            fontFamily: 'monospace',
            fontSize: 9,
            letterSpacing: '0.08em',
            textTransform: 'uppercase',
            color: pct !== null ? color : '#4a4a60',
            fontWeight: 700,
          }}
        >
          {label}
        </div>
      </div>

      {/* Vault bars */}
      {triple ? (
        <VaultBars triple={triple} />
      ) : (
        <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#4a4a60', textAlign: 'center' }}>
          NO VAULT DATA
        </div>
      )}

      {/* Staking panel */}
      {triple ? (
        <div style={{ borderTop: '1px solid #1e1e2e', paddingTop: 12 }}>
          <StakingPanel triple={triple} capabilityName={capability.name} />
        </div>
      ) : (
        <div style={{ borderTop: '1px solid #1e1e2e', paddingTop: 12 }}>
          <p style={{ fontFamily: 'monospace', fontSize: 9, color: '#4a4a60', textAlign: 'center' }}>
            STAKING UNAVAILABLE
          </p>
        </div>
      )}

      {/* Vault stats */}
      {triple && <VaultStatsBlock triple={triple} />}
    </div>
  )
}

// ── Main Component ─────────────────────────────────────────────────────────

export function AgentCapabilityZone({ agent, className }: AgentCapabilityZoneProps) {
  const { capabilities, triples } = agent

  const findCapTriple = (capabilityId: string): Triple | undefined =>
    triples.find(
      (t) => t.predicate.label === 'has-capability' && t.object.term_id === capabilityId,
    )

  const [selectedId, setSelectedId] = useState<string | null>(
    capabilities.length > 0 ? capabilities[0].id : null,
  )

  const selectedCap = capabilities.find((c) => c.id === selectedId) ?? null

  if (capabilities.length === 0) {
    return (
      <div
        className={cn(
          'rounded-[var(--radius-card)] border border-border bg-card p-4 shadow-[var(--shadow-card)]',
          className,
        )}
      >
        <h2 className="font-mono text-xs tracking-widest uppercase text-ink-dull mb-2">
          Capabilities
        </h2>
        <p className="text-sm text-muted-foreground">No capabilities registered for this agent.</p>
      </div>
    )
  }

  return (
    <>
      <style>{`
        @keyframes capzone-fade-in {
          from { opacity: 0; }
          to   { opacity: 1; }
        }
        @keyframes capzone-slide-down {
          from { opacity: 0; transform: translateY(-8px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes capzone-step-enter {
          from { opacity: 0; transform: translateX(10px); }
          to   { opacity: 1; transform: translateX(0); }
        }
      `}</style>

      <div
        className={cn('rounded-[var(--radius-card)] border border-border shadow-[var(--shadow-card)] overflow-hidden', className)}
        style={{ background: '#0a0a12' }}
      >
        {/* Header */}
        <div
          style={{
            padding: '9px 16px 7px',
            borderBottom: '1px solid #1e1e2e',
            fontFamily: 'monospace',
            fontSize: 9,
            fontWeight: 700,
            letterSpacing: '0.12em',
            textTransform: 'uppercase',
            color: '#4a4a60',
          }}
        >
          CAPABILITIES ({capabilities.length})
        </div>

        {/* Split panel */}
        <div style={{ display: 'flex', minHeight: 360 }}>
          {/* Left: capability list (60%) */}
          <div
            style={{
              flex: '0 0 60%',
              borderRight: '1px solid #1e1e2e',
              background: '#0a0a12',
              overflowY: 'auto',
            }}
          >
            {capabilities.map((cap) => {
              const triple = findCapTriple(cap.id)
              return (
                <CapabilityCard
                  key={cap.id}
                  capability={cap}
                  triple={triple}
                  isSelected={cap.id === selectedId}
                  onSelect={() => setSelectedId(cap.id)}
                />
              )
            })}
          </div>

          {/* Right: detail + staking (40%) */}
          <div
            style={{
              flex: 1,
              background: '#0e0e16',
              overflowY: 'auto',
            }}
          >
            {selectedCap ? (
              <RightPanel
                key={selectedCap.id}
                capability={selectedCap}
                triple={findCapTriple(selectedCap.id)}
              />
            ) : (
              <div
                style={{
                  height: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontFamily: 'monospace',
                  fontSize: 10,
                  letterSpacing: '0.08em',
                  color: '#4a4a60',
                  textTransform: 'uppercase',
                }}
              >
                SELECT A CAPABILITY
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  )
}
