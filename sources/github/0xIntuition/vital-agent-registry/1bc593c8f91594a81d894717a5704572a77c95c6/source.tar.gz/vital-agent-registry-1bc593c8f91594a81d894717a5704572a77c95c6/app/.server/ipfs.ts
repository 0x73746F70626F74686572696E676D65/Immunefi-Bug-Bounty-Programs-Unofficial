import { AgentMetadataSchema } from '~/lib/schemas/agent-metadata';
import { SkillMetadataSchema } from '~/lib/schemas/skill-metadata';
import type { AgentMetadata } from '~/lib/schemas/agent-metadata';
import type { SkillMetadataPayload } from '~/lib/schemas/skill-metadata';
import { assertRemoteWriteAllowed, getWriteProfile } from './remote-write-guard';

export const MAX_METADATA_BYTES = 4096;

export class IpfsUploadError extends Error {
  category: 'validation' | 'upstream' | 'internal';
  constructor(
    message: string,
    category: 'validation' | 'upstream' | 'internal'
  ) {
    super(message);
    this.name = 'IpfsUploadError';
    this.category = category;
  }
}

/**
 * Uploads agent metadata to IPFS via Pinata.
 *
 * Validates metadata with Zod schema before upload (SEC-06).
 * Returns IPFS URI in the format: ipfs://{CID}
 *
 * @param metadata - The agent metadata object to upload
 * @returns IPFS URI string
 * @throws Error if validation fails or upload fails
 *
 * @example
 * ```typescript
 * const metadata = {
 *   "@type": "Agent",
 *   name: "Code Review Assistant",
 *   description: "AI-powered code reviewer",
 *   version: "1.0.0",
 * };
 * const ipfsUri = await uploadAgentMetadata(metadata);
 * // ipfsUri = "ipfs://QmX..."
 * ```
 */
export async function uploadAgentMetadata(metadata: unknown): Promise<string> {
  const parsed = AgentMetadataSchema.safeParse(metadata)
  if (!parsed.success) {
    const fields = parsed.error.flatten().fieldErrors
    throw new Error(
      `metadata validation failed for Agent: ${JSON.stringify(fields)}`,
    )
  }
  const validated = parsed.data
  return uploadJsonToIpfs(validated, `agent-${validated.name}`);
}

/**
 * Uploads skill metadata to IPFS via Pinata.
 *
 * Validates metadata with Zod schema before upload (SEC-06).
 * Returns IPFS URI in the format: ipfs://{CID}
 *
 * @param metadata - The skill metadata object to upload
 * @returns IPFS URI string
 * @throws Error if validation fails or upload fails
 *
 * @example
 * ```typescript
 * const metadata = {
 *   "@type": "Skill",
 *   name: "GitHub Integration",
 *   description: "Read and write GitHub data",
 *   version: "2.1.0",
 *   platform: "mcp",
 * };
 * const ipfsUri = await uploadSkillMetadata(metadata);
 * // ipfsUri = "ipfs://QmY..."
 * ```
 */
export async function uploadSkillMetadata(metadata: unknown): Promise<string> {
  const parsed = SkillMetadataSchema.safeParse(metadata)
  if (!parsed.success) {
    const fields = parsed.error.flatten().fieldErrors
    throw new Error(
      `metadata validation failed for Skill: ${JSON.stringify(fields)}`,
    )
  }
  const validated = parsed.data
  return uploadJsonToIpfs(validated, `skill-${validated.name}`);
}

/**
 * Internal: Uploads JSON data to IPFS via Pinata HTTP API.
 *
 * Uses Pinata's pinJSONToIPFS endpoint.
 * Requires PINATA_JWT environment variable.
 *
 * @param data - The JSON-serializable data to upload
 * @param name - A human-readable name for the pin (for Pinata dashboard)
 * @returns IPFS URI string
 * @throws Error if PINATA_JWT is not set or upload fails
 */
async function uploadJsonToIpfs(
  data: AgentMetadata | SkillMetadataPayload,
  name: string
): Promise<string> {
  const profile = getWriteProfile();
  if (profile === 'local') {
    const localUploadUrl = process.env.LOCAL_IPFS_UPLOAD_URL ?? 'http://localhost:3000/upload_json_to_ipfs';
    const localResponse = await fetch(localUploadUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!localResponse.ok) {
      const errorText = await localResponse.text();
      throw new IpfsUploadError(
        `Local IPFS upload failed (${localResponse.status}): ${errorText}`,
        'upstream',
      );
    }

    const localResult = await localResponse.json();
    if (!localResult?.Hash || typeof localResult.Hash !== 'string') {
      throw new IpfsUploadError('Local IPFS response missing Hash', 'upstream');
    }

    return `ipfs://${localResult.Hash}`;
  }

  assertRemoteWriteAllowed({
    action: `upload ${name} metadata to IPFS`,
    target: 'pinata',
  });

  const jwt = process.env.PINATA_JWT;
  if (!jwt) {
    throw new IpfsUploadError('PINATA_JWT environment variable is required', 'internal');
  }

  const payload = JSON.stringify(data);
  const payloadBytes = Buffer.byteLength(payload, 'utf8');
  if (payloadBytes > MAX_METADATA_BYTES) {
    throw new IpfsUploadError(
      `metadata payload exceeds ${MAX_METADATA_BYTES} bytes`,
      'validation',
    );
  }

  const response = await fetch('https://api.pinata.cloud/pinning/pinJSONToIPFS', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${jwt}`,
    },
    body: JSON.stringify({
      pinataContent: data,
      pinataMetadata: { name },
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new IpfsUploadError(
      `Pinata upload failed (${response.status}): ${errorText}`,
      'upstream',
    );
  }

  const result = await response.json();
  if (!result?.IpfsHash || typeof result.IpfsHash !== 'string') {
    throw new IpfsUploadError('Pinata response missing IpfsHash', 'upstream');
  }
  return `ipfs://${result.IpfsHash}`;
}
