import { describe, expect, it } from 'vitest';
import { normalizeCapabilityName, isValidCapabilityName } from './capabilities';

describe('normalizeCapabilityName', () => {
  it('should normalize space-separated names', () => {
    expect(normalizeCapabilityName('Code Review')).toBe('code-review');
    expect(normalizeCapabilityName('API Integration')).toBe('api-integration');
  });

  it('should normalize underscore-separated names', () => {
    expect(normalizeCapabilityName('code_review')).toBe('code-review');
    expect(normalizeCapabilityName('api_integration')).toBe('api-integration');
  });

  it('should normalize camelCase names', () => {
    expect(normalizeCapabilityName('codeReview')).toBe('code-review');
    expect(normalizeCapabilityName('apiIntegration')).toBe('api-integration');
  });

  it('should normalize PascalCase names', () => {
    expect(normalizeCapabilityName('CodeReview')).toBe('code-review');
    expect(normalizeCapabilityName('APIIntegration')).toBe('api-integration');
  });

  it('should handle acronyms correctly', () => {
    expect(normalizeCapabilityName('HTTPClient')).toBe('http-client');
    expect(normalizeCapabilityName('XMLParser')).toBe('xml-parser');
  });

  it('should handle mixed formats', () => {
    expect(normalizeCapabilityName('Code_ReviewAPI')).toBe('code-review-api');
    expect(normalizeCapabilityName('HTTP_ClientV2')).toBe('http-client-v2');
  });

  it('should remove consecutive hyphens', () => {
    expect(normalizeCapabilityName('code--review')).toBe('code-review');
    expect(normalizeCapabilityName('api---integration')).toBe('api-integration');
  });

  it('should remove leading and trailing hyphens', () => {
    expect(normalizeCapabilityName('-code-review')).toBe('code-review');
    expect(normalizeCapabilityName('code-review-')).toBe('code-review');
    expect(normalizeCapabilityName('-code-review-')).toBe('code-review');
  });

  it('should handle numbers', () => {
    expect(normalizeCapabilityName('http2')).toBe('http2');
    expect(normalizeCapabilityName('v8Engine')).toBe('v8-engine');
  });

  it('should handle already normalized names', () => {
    expect(normalizeCapabilityName('code-review')).toBe('code-review');
    expect(normalizeCapabilityName('api-integration')).toBe('api-integration');
  });
});

describe('isValidCapabilityName', () => {
  it('should accept valid capability names', () => {
    expect(isValidCapabilityName('code-review')).toBe(true);
    expect(isValidCapabilityName('api-integration')).toBe(true);
    expect(isValidCapabilityName('http2')).toBe(true);
    expect(isValidCapabilityName('v8-engine')).toBe(true);
  });

  it('should reject uppercase letters', () => {
    expect(isValidCapabilityName('Code-Review')).toBe(false);
    expect(isValidCapabilityName('code-Review')).toBe(false);
  });

  it('should reject underscores', () => {
    expect(isValidCapabilityName('code_review')).toBe(false);
  });

  it('should reject spaces', () => {
    expect(isValidCapabilityName('code review')).toBe(false);
  });

  it('should reject leading hyphens', () => {
    expect(isValidCapabilityName('-code-review')).toBe(false);
  });

  it('should reject trailing hyphens', () => {
    expect(isValidCapabilityName('code-review-')).toBe(false);
  });

  it('should reject consecutive hyphens', () => {
    expect(isValidCapabilityName('code--review')).toBe(false);
  });

  it('should reject names starting with numbers', () => {
    expect(isValidCapabilityName('2code')).toBe(false);
  });

  it('should accept names with numbers after letters', () => {
    expect(isValidCapabilityName('http2')).toBe(true);
    expect(isValidCapabilityName('v8-engine')).toBe(true);
  });

  it('should reject special characters', () => {
    expect(isValidCapabilityName('code@review')).toBe(false);
    expect(isValidCapabilityName('code.review')).toBe(false);
  });
});
