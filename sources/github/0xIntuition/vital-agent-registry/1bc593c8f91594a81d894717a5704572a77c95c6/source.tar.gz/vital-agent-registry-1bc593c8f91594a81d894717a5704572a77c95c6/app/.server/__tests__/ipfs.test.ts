import { describe, it, expect, beforeEach, vi } from 'vitest';
import { uploadAgentMetadata, uploadSkillMetadata } from '../ipfs';

// Mock fetch globally
global.fetch = vi.fn();

describe('ipfs', () => {
  beforeEach(() => {
    vi.resetAllMocks();
    // Set explicit remote-write override for positive path tests
    process.env.ALLOW_REMOTE_WRITES = '1';
    process.env.REGISTRY_WRITE_PROFILE = 'shared';
    // Set mock env var
    process.env.PINATA_JWT = 'test-jwt-token';
  });

  describe('uploadAgentMetadata', () => {
    it('should validate and upload agent metadata', async () => {
      const mockResponse = {
        IpfsHash: 'QmTestHash123',
      };

      (global.fetch as any).mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      });

      const metadata = {
        '@type': 'Agent' as const,
        name: 'Test Agent',
        description: 'A test agent',
        version: '1.0.0',
      };

      const result = await uploadAgentMetadata(metadata);

      expect(result).toBe('ipfs://QmTestHash123');
      expect(global.fetch).toHaveBeenCalledWith(
        'https://api.pinata.cloud/pinning/pinJSONToIPFS',
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            'Content-Type': 'application/json',
            Authorization: 'Bearer test-jwt-token',
          }),
        })
      );
    });

    it('should reject invalid agent metadata (missing required field)', async () => {
      const invalidMetadata = {
        '@type': 'Agent' as const,
        name: 'Test Agent',
        // missing description and version
      };

      await expect(uploadAgentMetadata(invalidMetadata)).rejects.toThrow();
    });

    it('should reject invalid agent metadata (wrong @type)', async () => {
      const invalidMetadata = {
        '@type': 'Skill' as const,
        name: 'Test',
        description: 'Test',
        version: '1.0.0',
      };

      await expect(uploadAgentMetadata(invalidMetadata)).rejects.toThrow();
    });

    it('should reject invalid agent metadata (invalid semver)', async () => {
      const invalidMetadata = {
        '@type': 'Agent' as const,
        name: 'Test Agent',
        description: 'A test agent',
        version: 'not-a-semver',
      };

      await expect(uploadAgentMetadata(invalidMetadata)).rejects.toThrow();
    });

    it('should throw if PINATA_JWT is not set', async () => {
      delete process.env.PINATA_JWT;

      const metadata = {
        '@type': 'Agent' as const,
        name: 'Test Agent',
        description: 'A test agent',
        version: '1.0.0',
      };

      await expect(uploadAgentMetadata(metadata)).rejects.toThrow(
        'PINATA_JWT environment variable is required'
      );
    });

    it('should block IPFS upload when remote-write override is not set', async () => {
      delete process.env.ALLOW_REMOTE_WRITES;
      process.env.REGISTRY_WRITE_PROFILE = 'shared';

      const metadata = {
        '@type': 'Agent' as const,
        name: 'Blocked Agent',
        description: 'Blocked in local-safe mode',
        version: '1.0.0',
      };

      await expect(uploadAgentMetadata(metadata)).rejects.toThrow('Remote write blocked');
    });

    it('should throw on upload failure', async () => {
      (global.fetch as any).mockResolvedValueOnce({
        ok: false,
        status: 500,
        text: async () => 'Internal Server Error',
      });

      const metadata = {
        '@type': 'Agent' as const,
        name: 'Test Agent',
        description: 'A test agent',
        version: '1.0.0',
      };

      await expect(uploadAgentMetadata(metadata)).rejects.toThrow('Pinata upload failed');
    });

    it('should reject oversized metadata payloads', async () => {
      const metadata = {
        '@type': 'Agent' as const,
        name: 'Oversized Agent',
        description: 'Size-check payload',
        version: '1.0.0',
        inputModes: Array.from({ length: 10 }, (_, i) => `mode-${i}-${'x'.repeat(450)}`),
        outputModes: Array.from({ length: 10 }, (_, i) => `out-${i}-${'y'.repeat(450)}`),
      };

      await expect(uploadAgentMetadata(metadata)).rejects.toThrow('exceeds');
    });
  });

  describe('uploadSkillMetadata', () => {
    it('should validate and upload skill metadata', async () => {
      const mockResponse = {
        IpfsHash: 'QmTestSkillHash',
      };

      (global.fetch as any).mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      });

      const metadata = {
        '@type': 'Skill' as const,
        name: 'Test Skill',
        description: 'A test skill',
        version: '2.0.0',
        platform: 'mcp' as const,
      };

      const result = await uploadSkillMetadata(metadata);

      expect(result).toBe('ipfs://QmTestSkillHash');
    });

    it('should reject invalid skill metadata (missing platform)', async () => {
      const invalidMetadata = {
        '@type': 'Skill' as const,
        name: 'Test Skill',
        description: 'A test skill',
        version: '1.0.0',
        // missing platform
      };

      await expect(uploadSkillMetadata(invalidMetadata)).rejects.toThrow();
    });

    it('should reject invalid skill metadata (invalid platform)', async () => {
      const invalidMetadata = {
        '@type': 'Skill' as const,
        name: 'Test Skill',
        description: 'A test skill',
        version: '1.0.0',
        platform: 'not-a-valid-platform',
      };

      await expect(uploadSkillMetadata(invalidMetadata as any)).rejects.toThrow();
    });

    it('should accept valid platform values', async () => {
      const mockResponse = { IpfsHash: 'QmTestHash' };
      (global.fetch as any).mockResolvedValue({
        ok: true,
        json: async () => mockResponse,
      });

      const platforms = ['mcp', 'claude-code', 'openclaw', 'openai', 'other'] as const;

      for (const platform of platforms) {
        const metadata = {
          '@type': 'Skill' as const,
          name: 'Test',
          description: 'Test',
          version: '1.0.0',
          platform,
        };

        await expect(uploadSkillMetadata(metadata)).resolves.toBeTruthy();
      }
    });

    it('should block skill upload when remote-write override is not set', async () => {
      delete process.env.ALLOW_REMOTE_WRITES;
      process.env.REGISTRY_WRITE_PROFILE = 'shared';

      const metadata = {
        '@type': 'Skill' as const,
        name: 'Blocked Skill',
        description: 'Blocked in local-safe mode',
        version: '1.0.0',
        platform: 'mcp' as const,
      };

      await expect(uploadSkillMetadata(metadata)).rejects.toThrow('Remote write blocked');
    });
  });

  describe('metadata name encoding', () => {
    it('should include metadata name in pinata request', async () => {
      const mockResponse = { IpfsHash: 'QmTest' };
      (global.fetch as any).mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      });

      const metadata = {
        '@type': 'Agent' as const,
        name: 'My Cool Agent',
        description: 'Test',
        version: '1.0.0',
      };

      await uploadAgentMetadata(metadata);

      const fetchCall = (global.fetch as any).mock.calls[0];
      const body = JSON.parse(fetchCall[1].body);

      expect(body.pinataMetadata.name).toBe('agent-My Cool Agent');
    });
  });
});
