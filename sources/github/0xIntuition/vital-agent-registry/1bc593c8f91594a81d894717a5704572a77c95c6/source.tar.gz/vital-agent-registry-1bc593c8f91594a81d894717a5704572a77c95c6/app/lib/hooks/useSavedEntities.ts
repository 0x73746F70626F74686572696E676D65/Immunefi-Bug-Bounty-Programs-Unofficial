import { useState, useCallback } from 'react'

const STORAGE_KEY = 'intuition-saved-entities'

interface SavedEntity {
  id: string
  type: 'agent' | 'skill'
  savedAt: number
}

export function useSavedEntities() {
  const [saved, setSaved] = useState<SavedEntity[]>(() => {
    if (typeof window === 'undefined') return []
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]')
    } catch {
      return []
    }
  })

  const toggle = useCallback((id: string, type: 'agent' | 'skill') => {
    setSaved(prev => {
      const exists = prev.find(s => s.id === id)
      const next = exists
        ? prev.filter(s => s.id !== id)
        : [...prev, { id, type, savedAt: Date.now() }]
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next))
      return next
    })
  }, [])

  const isSaved = useCallback((id: string) => saved.some(s => s.id === id), [saved])

  return { saved, toggle, isSaved }
}
