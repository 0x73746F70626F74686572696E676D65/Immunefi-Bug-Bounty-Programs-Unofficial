import { createRepository } from '~/data/repository/provider'
import { handleOptions, jsonResponse, errorResponse } from '~/lib/api/types'
import type { LoaderFunctionArgs } from 'react-router'

export async function loader({ params, request }: LoaderFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const repo = createRepository()
  const trust = await repo.getAgentTrust(params.id!)

  if (!trust) {
    return errorResponse('Agent not found', 'NOT_FOUND', 404)
  }

  return jsonResponse(trust)
}
