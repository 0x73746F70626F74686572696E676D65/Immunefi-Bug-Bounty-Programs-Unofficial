import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

describe('POST /api/graphql', () => {
  const baseEnv = { ...process.env }

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = {
      ...baseEnv,
      GRAPHQL_API_URL_PRIVATE: 'http://localhost:8080/v1/graphql',
      NODE_ENV: 'development',
    }
  })

  afterEach(() => {
    process.env = { ...baseEnv }
    vi.restoreAllMocks()
  })

  function createRequest(
    method: string,
    body?: unknown,
    extraHeaders: Record<string, string> = {},
  ) {
    const headers: Record<string, string> = { ...extraHeaders }
    if (body) headers['content-type'] = 'application/json'
    // In dev mode, localhost is always an allowed origin
    if (!headers.host) headers.host = 'localhost:4101'

    return new Request('http://localhost:4101/api/graphql', {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    })
  }

  it('should return 405 for non-POST requests', async () => {
    const { action } = await import('../api+/graphql')
    const response = await action({
      request: createRequest('GET'),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(405)
    const body = await response.json()
    expect(body.errors[0].message).toBe('Method not allowed')
  })

  it('should return 503 when GRAPHQL_API_URL_PRIVATE not set', async () => {
    delete process.env.GRAPHQL_API_URL_PRIVATE

    const { action } = await import('../api+/graphql')
    const response = await action({
      request: createRequest('POST', { query: '{ agents { id } }' }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(503)
    const body = await response.json()
    expect(body.errors[0].message).toBe('GraphQL API not configured')
  })

  it('should return 403 for unauthorized origin', async () => {
    // Set strict production-like config so localhost is not in allowed domains
    process.env.ALLOWED_DOMAINS = 'trusted.example.com'
    process.env.NODE_ENV = 'production'

    const { action } = await import('../api+/graphql')
    const response = await action({
      request: createRequest('POST', { query: '{ agents { id } }' }, {
        origin: 'http://evil.example.com',
        host: 'evil.example.com',
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(403)
    const body = await response.json()
    expect(body.errors[0].message).toBe('Unauthorized origin')
  })

  it('should return 400 for missing content-type', async () => {
    const { action } = await import('../api+/graphql')
    const response = await action({
      request: new Request('http://localhost:4101/api/graphql', {
        method: 'POST',
        headers: { host: 'localhost:4101' },
        body: JSON.stringify({ query: '{ agents { id } }' }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(400)
    const body = await response.json()
    expect(body.errors[0].message).toBe('Invalid content type')
  })

  it('should return 400 for missing query', async () => {
    const { action } = await import('../api+/graphql')
    const response = await action({
      request: createRequest('POST', { variables: {} }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(400)
    const body = await response.json()
    expect(body.errors[0].message).toBe('GraphQL query is required')
  })

  it('should return 403 for introspection query in production', async () => {
    process.env.NODE_ENV = 'production'
    process.env.ALLOWED_DOMAINS = 'localhost'

    const { action } = await import('../api+/graphql')
    const response = await action({
      request: createRequest('POST', { query: '{ __schema { types { name } } }' }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(403)
    const body = await response.json()
    expect(body.errors[0].message).toBe('Introspection is disabled')
  })

  it('should return 403 for mutation queries', async () => {
    const { action } = await import('../api+/graphql')
    const response = await action({
      request: createRequest('POST', { query: 'mutation { deleteAgent(id: "1") { id } }' }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(403)
    const body = await response.json()
    expect(body.errors[0].message).toBe('Mutations are not allowed through the proxy')
  })

  it('should successfully proxy valid query', async () => {
    const mockResponse = {
      data: { agents: [{ id: '1', name: 'TestAgent' }] },
    }

    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(
      new Response(JSON.stringify(mockResponse), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      }),
    )

    const { action } = await import('../api+/graphql')
    const response = await action({
      request: createRequest('POST', { query: '{ agents { id name } }' }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.agents).toHaveLength(1)
    expect(body.data.agents[0].name).toBe('TestAgent')

    // Verify fetch was called with the upstream URL
    expect(fetchSpy).toHaveBeenCalledWith(
      'http://localhost:8080/v1/graphql',
      expect.objectContaining({
        method: 'POST',
        body: expect.stringContaining('agents'),
      }),
    )
  })
})
