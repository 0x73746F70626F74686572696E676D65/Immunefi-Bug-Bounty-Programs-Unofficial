import type { Agent, ERC8004, ERC8004OnboardingExtension } from '~/types'
import { CONTRACTS, CHAINS } from '~/lib/constants/protocol'

/** Default trust model IDs supported by the registry */
const DEFAULT_TRUST_MODEL_IDS = [
  'com.intuition.trust.default',
]

/**
 * Generate ERC-8004 compliant registration file from Agent data.
 *
 * ERC-8004 is a standard for on-chain agent identity. This function
 * maps our Agent schema to the ERC-8004 format for interoperability.
 *
 * @param agent - Agent entity from repository
 * @param chain - 'testnet' or 'mainnet' (determines registry address and chainId)
 * @param options - Optional configuration
 * @param options.includeOnboarding - Whether to include onboarding extension (INT-13)
 * @returns ERC-8004 compliant registration object
 */
export function generateERC8004(
  agent: Agent,
  chain: 'testnet' | 'mainnet',
  options?: { includeOnboarding?: boolean },
): ERC8004 {
  const registryAddress =
    chain === 'testnet' ? CONTRACTS.MULTIVAULT_TESTNET : CONTRACTS.MULTIVAULT_MAINNET
  const chainId = chain === 'testnet' ? CHAINS.TESTNET.chainId : CHAINS.MAINNET.chainId

  // agentURI: IPFS CID if available, otherwise placeholder
  // In production, this would come from agent.metadata or agent data field
  const agentURI = agent.metadata.image?.startsWith('ipfs://')
    ? agent.metadata.image
    : `ipfs://${agent.id}`

  // agentWallet: We don't have wallet on the type, use provider URL as placeholder
  const agentWallet = agent.metadata.provider?.url || ''

  // Services: include A2A endpoint if agent has one
  const services: { name: string; endpoint: string; version?: string }[] = []
  if (agent.metadata.endpoint) {
    services.push({
      name: 'a2a',
      endpoint: agent.metadata.endpoint,
      version: agent.metadata.version,
    })
  }

  const result: ERC8004 = {
    agentId: agent.id,
    registryAddress,
    chainId,
    agentURI,
    agentWallet,
    metadata: {
      name: agent.metadata.name,
      description: agent.metadata.description,
      version: agent.metadata.version,
      model: agent.metadata.model || '',
    },
    services,
    active: true,
    registrations: [],
    trustModels: ['intuition-vault-staking'],
    registrationFile: `https://registry.intuition.systems/api/v1/agents/${agent.id}/erc8004`,
  }

  if (options?.includeOnboarding) {
    result.onboarding = generateOnboardingExtension(agent, chain)
  }

  return result
}

/**
 * Generate the onboarding metadata extension for ERC-8004 (INT-13).
 *
 * Includes wallet strategy, funding profile, and supported trust model IDs.
 * Does not break baseline schema compatibility — consumers that don't
 * understand the `onboarding` field simply ignore it.
 */
export function generateOnboardingExtension(
  agent: Agent,
  chain: 'testnet' | 'mainnet',
): ERC8004OnboardingExtension {
  // Estimate funding based on chain: testnet is cheaper
  const atomCostEstimate = chain === 'testnet' ? '300000000000000' : '500000000000000'
  const tripleCostEstimate = chain === 'testnet' ? '100000000000000' : '200000000000000'

  // Minimum: 1 atom + 3 triples (type + 2 relationships)
  const minWei = BigInt(atomCostEstimate) + BigInt(tripleCostEstimate) * 3n
  // Recommended: 1 atom + 10 triples + staking budget
  const recommendedWei = BigInt(atomCostEstimate) + BigInt(tripleCostEstimate) * 10n + BigInt('1000000000000000')

  return {
    walletStrategy: 'eoa',
    fundingProfile: {
      minimumWei: minWei.toString(),
      recommendedWei: recommendedWei.toString(),
      expectedTransactions: 2, // 1 createAtoms + 1 createTriples
    },
    supportedTrustModelIds: DEFAULT_TRUST_MODEL_IDS,
    readinessEndpoint: `/api/v1/onboarding/agents/${agent.id}/readiness`,
  }
}
