import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { describe, expect, it } from 'vitest'

const FILES_TO_CHECK = [
  'app/lib/trust.ts',
  'app/data/agents.ts',
  'app/data/skills.ts',
  'app/lib/vault-utils.ts',
]

const FORBIDDEN_PATTERNS = [
  /Number\(\s*totalAssets\s*\)/,
  /Number\(\s*\(\s*totalAssets/,
  /parseInt\(\s*vault\.(total_assets|total_shares|current_share_price|market_cap)/,
]

describe('vault math discipline', () => {
  it('avoids Number(BigInt)/parseInt on vault numeric fields', async () => {
    for (const relPath of FILES_TO_CHECK) {
      const content = await readFile(resolve(process.cwd(), relPath), 'utf8')
      for (const pattern of FORBIDDEN_PATTERNS) {
        expect(pattern.test(content), `forbidden pattern ${pattern} in ${relPath}`).toBe(false)
      }
    }
  })
})
