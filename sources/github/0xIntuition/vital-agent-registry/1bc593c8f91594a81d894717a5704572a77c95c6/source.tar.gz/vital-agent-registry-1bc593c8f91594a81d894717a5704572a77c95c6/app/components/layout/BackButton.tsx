import { useNavigate } from 'react-router'
import { motion } from 'motion/react'
import { ArrowLeft } from 'lucide-react'
import { springs } from '~/config/springs'

export function BackButton() {
  const navigate = useNavigate()

  return (
    <motion.button
      type="button"
      onClick={() => navigate(-1)}
      className="fixed left-3 top-3 z-50 flex h-9 w-9 items-center justify-center rounded-full bg-black/60 backdrop-blur-sm text-white"
      whileTap={{ scale: 0.9 }}
      transition={{ type: 'spring', ...springs.snappy }}
      aria-label="Go back"
    >
      <ArrowLeft className="h-5 w-5" />
    </motion.button>
  )
}
