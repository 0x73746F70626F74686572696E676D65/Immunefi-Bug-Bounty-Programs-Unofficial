import type { ImportSource } from './types'

interface DetectedSource {
  source: ImportSource
  slug: string
}

const MOLTBOOK_PATTERN = /^https?:\/\/(?:www\.)?moltbook\.com\/u\/([a-zA-Z0-9_-]+)/
const CLAWHUB_PATTERN = /^https?:\/\/(?:www\.)?clawhub\.ai\/skills\/([a-zA-Z0-9_-]+)/

export function detectSource(url: string): DetectedSource | null {
  const moltbookMatch = url.match(MOLTBOOK_PATTERN)
  if (moltbookMatch) {
    return { source: 'moltbook', slug: moltbookMatch[1] }
  }

  const clawhubMatch = url.match(CLAWHUB_PATTERN)
  if (clawhubMatch) {
    return { source: 'clawhub', slug: clawhubMatch[1] }
  }

  return null
}

export function extractMoltbookSlug(url: string): string | null {
  return url.match(MOLTBOOK_PATTERN)?.[1] ?? null
}

export function extractClawhubSlug(url: string): string | null {
  return url.match(CLAWHUB_PATTERN)?.[1] ?? null
}
