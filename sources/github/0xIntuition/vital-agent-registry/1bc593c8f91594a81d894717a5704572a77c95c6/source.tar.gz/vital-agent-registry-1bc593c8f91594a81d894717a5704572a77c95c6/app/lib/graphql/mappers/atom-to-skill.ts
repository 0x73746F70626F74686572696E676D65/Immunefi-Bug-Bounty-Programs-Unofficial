import type {
  Skill,
  SkillMetadata,
  Capability,
  Platform,
  Triple,
  TripleVaultData,
  Vault,
  TrustSignal,
  SafetySignal,
} from '~/types'
import { computeTrustSignal } from '~/lib/trust'
import { computeSafetySignal } from '~/lib/safety'
import { sanitizeWeiString } from '~/lib/vault-utils'
import type { GraphQLAtom } from './types'

/**
 * Map a GraphQL atom response to a Skill entity.
 * Extracts capabilities, platform, and safety signals from triples and vaults.
 *
 * @param atom - GraphQL atom response
 * @param allVaults - Array of all skill vaults for trust percentile calculation
 * @returns Skill entity
 */
export function mapAtomToSkill(atom: GraphQLAtom, allVaults: Vault[]): Skill {
  // Extract metadata
  const metadata = extractSkillMetadata(atom)

  // Extract capabilities from has-capability triples
  const capabilities = extractCapabilities(atom)

  // Platform info is in metadata in v3, not a triple
  const platform = extractPlatform(atom)

  // Build vault (FOR vault is curve_id 1)
  const forVault = extractVault(atom, '1')
  const againstVault = extractCounterVault(atom)

  // Compute trust signal
  const trustSignal = forVault ? computeTrustSignal(forVault, allVaults) : getEmptyTrustSignal()

  // Compute safety signal from FOR/AGAINST vault data
  const safetySignal = computeSafetyFromVaults(forVault, againstVault)

  // Extract triples
  const triples = extractTriples(atom)

  return {
    id: atom.term_id,
    metadata,
    platform,
    capabilities,
    vault: forVault ?? getEmptyVault(atom.term_id),
    trustSignal,
    safetySignal,
    triples,
  }
}

/**
 * Extract skill metadata from GraphQL atom.
 */
function extractSkillMetadata(atom: GraphQLAtom): SkillMetadata {
  const thing = atom.value?.thing
  const jsonObject = atom.value?.json_object

  let parsedData: Record<string, unknown> | null = null
  if (atom.data) {
    try {
      parsedData = JSON.parse(atom.data)
    } catch {
      // Ignore
    }
  }

  const name = thing?.name || jsonObject?.name || (parsedData?.name as string) || atom.label

  // Find has-metadata triple for richer metadata (description, version, etc.)
  const metadataTriple = atom.as_subject_triples?.find(
    (t) => t.predicate.label === 'has-metadata',
  )
  const metadataObj = metadataTriple?.object
  const metadataJsonObj = metadataObj?.value?.json_object
  let metadataParsed: Record<string, unknown> | null = null
  if (metadataObj?.data) {
    try {
      metadataParsed = JSON.parse(metadataObj.data)
    } catch {
      // IPFS URI or non-JSON data, ignore
    }
  }

  const description =
    thing?.description ||
    metadataJsonObj?.description ||
    jsonObject?.description ||
    (metadataParsed?.description as string) ||
    (parsedData?.description as string) ||
    ''
  const image = thing?.image || atom.cached_image?.url || atom.image || undefined
  const version = (metadataParsed?.version as string) || (parsedData?.version as string) || '1.0.0'
  const author = (metadataParsed?.author as string) || (parsedData?.author as string) || undefined
  const metadataUriCandidate =
    (parsedData?.metadataUri as string) ||
    (parsedData?.metadata_uri as string) ||
    (typeof thing?.url === 'string' && thing.url.startsWith('ipfs://') ? thing.url : undefined) ||
    (typeof atom.label === 'string' && atom.label.startsWith('ipfs://') ? atom.label : undefined)
  const installUri = (parsedData?.installUri as string) || (parsedData?.url as string) || undefined
  const permissions = (parsedData?.permissions as string[]) || []

  return {
    name,
    description,
    longDescription: (parsedData?.longDescription as string) || undefined,
    image,
    version,
    author,
    installUri,
    metadataUri: metadataUriCandidate,
    permissions,
    createdAt: atom.created_at || new Date().toISOString(),
    updatedAt: atom.updated_at || undefined,
  }
}

/**
 * Extract capabilities from has-capability triples.
 */
function extractCapabilities(atom: GraphQLAtom): Capability[] {
  if (!atom.as_subject_triples) return []

  return atom.as_subject_triples
    .filter((triple) => triple.predicate.label === 'has-capability')
    .map((triple) => {
      const obj = triple.object
      const objData = obj.data ? tryParseJSON(obj.data) : null
      return {
        id: obj.term_id,
        name: obj.value?.thing?.name || obj.value?.json_object?.name || obj.label,
        category: (objData?.category as string) || 'automation',
        description: obj.value?.thing?.description || obj.value?.json_object?.description || (objData?.description as string) || '',
      }
    })
}

/** Known platform ID lookup by name (case-insensitive) */
const PLATFORM_LOOKUP: Record<string, Platform> = {
  mcp: { id: 'mcp', name: 'Model Context Protocol', description: 'Model Context Protocol standard for AI tool connectivity' },
  'claude code': { id: 'claude-code', name: 'Claude Code Skills', description: 'Custom skills for Claude Code CLI' },
  'claude-code': { id: 'claude-code', name: 'Claude Code Skills', description: 'Custom skills for Claude Code CLI' },
  openclaw: { id: 'openclaw', name: 'OpenClaw', description: 'Open marketplace for AI agent tools' },
  openai: { id: 'openai', name: 'OpenAI Functions', description: 'Function calling and tools for OpenAI models' },
  x402: { id: 'x402', name: 'x402', description: 'HTTP 402-based micropayment protocol for AI services' },
}

const DEFAULT_PLATFORM: Platform = { id: 'custom', name: 'Custom', description: 'Custom or proprietary skill integration' }

/**
 * Extract platform from skill metadata JSON.
 * In v3, platform info is in metadata, not a triple.
 */
function extractPlatform(atom: GraphQLAtom): Platform {
  // Try atom.data first (direct JSON payload)
  const parsedData = atom.data ? tryParseJSON(atom.data) : null
  const platformStr = (parsedData?.platform as string) ?? (parsedData?.platformId as string)
  if (platformStr) {
    const match = PLATFORM_LOOKUP[platformStr.toLowerCase()]
    if (match) return match
  }

  // Try has-metadata triple's object data
  const metadataTriple = atom.as_subject_triples?.find(
    (t) => t.predicate.label === 'has-metadata',
  )
  if (metadataTriple?.object?.data) {
    const metaParsed = tryParseJSON(metadataTriple.object.data)
    const metaPlatform = (metaParsed?.platform as string) ?? (metaParsed?.platformId as string)
    if (metaPlatform) {
      const match = PLATFORM_LOOKUP[metaPlatform.toLowerCase()]
      if (match) return match
    }
  }

  return DEFAULT_PLATFORM
}

/**
 * Extract vault by curve_id.
 */
function extractVault(atom: GraphQLAtom, curveId: string): Vault | null {
  const vaults = atom.term?.vaults
  if (!vaults || vaults.length === 0) return null

  const vault = vaults.find((v) => v.curve_id === curveId) || vaults[0]

  return {
    term_id: vault.term_id,
    curve_id: vault.curve_id,
    total_shares: sanitizeWeiString(vault.total_shares),
    current_share_price: sanitizeWeiString(vault.current_share_price),
    total_assets: sanitizeWeiString(vault.total_assets),
    market_cap: sanitizeWeiString(vault.market_cap),
    position_count: vault.position_count ?? 0,
  }
}

/**
 * Extract AGAINST vault from counter triple vaults.
 * Skills have a counter_term_id on their triples — the AGAINST vault.
 */
function extractCounterVault(atom: GraphQLAtom): Vault | null {
  if (!atom.as_subject_triples) return null

  // Find a triple with counter_term_id and vaults
  for (const triple of atom.as_subject_triples) {
    if (triple.counter_term_id && triple.term?.vaults) {
      // Counter vault is curve_id 0 (AGAINST)
      const counterVault = triple.term.vaults.find((v) => v.curve_id === '0')
      if (counterVault) {
        return {
          term_id: counterVault.term_id,
          curve_id: counterVault.curve_id,
          total_shares: sanitizeWeiString(counterVault.total_shares),
          current_share_price: sanitizeWeiString(counterVault.current_share_price),
          total_assets: sanitizeWeiString(counterVault.total_assets),
          market_cap: sanitizeWeiString(counterVault.market_cap),
          position_count: counterVault.position_count ?? 0,
        }
      }
    }
  }

  return null
}

/**
 * Compute safety signal from FOR and AGAINST vault data.
 */
function computeSafetyFromVaults(forVault: Vault | null, againstVault: Vault | null): SafetySignal {
  const forStake = forVault?.total_assets || '0'
  const forCount = forVault?.position_count || 0
  const againstStake = againstVault?.total_assets || '0'
  const againstCount = againstVault?.position_count || 0

  return computeSafetySignal(forCount, againstCount, forStake, againstStake)
}

/**
 * Extract triples where this atom is subject.
 */
function extractTriples(atom: GraphQLAtom): Triple[] {
  if (!atom.as_subject_triples) return []

  return atom.as_subject_triples.map((triple) => {
    const vaults = triple.term?.vaults
    let vault: TripleVaultData | undefined
    if (vaults && vaults.length > 0) {
      const forV = vaults.find((v) => v.curve_id === '0') || vaults[0]
      const againstV = vaults.find((v) => v.curve_id === '1')
      vault = {
        forVault: {
          total_assets: sanitizeWeiString(forV.total_assets),
          position_count: forV.position_count ?? 0,
          current_share_price: sanitizeWeiString(forV.current_share_price),
        },
        againstVault: againstV
          ? {
              total_assets: sanitizeWeiString(againstV.total_assets),
              position_count: againstV.position_count ?? 0,
              current_share_price: sanitizeWeiString(againstV.current_share_price),
            }
          : undefined,
      }
    }

    return {
      term_id: triple.term_id,
      counter_term_id: triple.counter_term_id || '',
      subject: {
        term_id: atom.term_id,
        label: atom.label,
        image: atom.cached_image?.url || atom.image || undefined,
        type: 'Skill',
      },
      predicate: {
        term_id: triple.predicate.term_id,
        label: triple.predicate.label,
        type: 'Unknown',
      },
      object: {
        term_id: triple.object.term_id,
        label: triple.object.value?.thing?.name || triple.object.value?.json_object?.name || triple.object.label,
        image: triple.object.cached_image?.url || triple.object.image || undefined,
        type: (triple.object.type as any) || 'Unknown',
      },
      created_at: atom.created_at || new Date().toISOString(),
      creator_id: atom.creator?.id || '',
      vault,
    }
  })
}

/**
 * Try to parse JSON, return null on failure.
 */
function tryParseJSON(json: string): Record<string, unknown> | null {
  try {
    return JSON.parse(json)
  } catch {
    return null
  }
}

/**
 * Empty trust signal for skills with no vault data.
 */
function getEmptyTrustSignal(): TrustSignal {
  return {
    stakerCount: 0,
    totalStaked: '0',
    sharePrice: '1',
    tier: 'unranked',
    percentile: 0,
    marketCap: '0',
  }
}

/**
 * Empty vault placeholder.
 */
function getEmptyVault(termId: string): Vault {
  return {
    term_id: termId,
    curve_id: '1',
    total_shares: '0',
    current_share_price: '1000000000000000000',
    total_assets: '0',
    market_cap: '0',
    position_count: 0,
  }
}
