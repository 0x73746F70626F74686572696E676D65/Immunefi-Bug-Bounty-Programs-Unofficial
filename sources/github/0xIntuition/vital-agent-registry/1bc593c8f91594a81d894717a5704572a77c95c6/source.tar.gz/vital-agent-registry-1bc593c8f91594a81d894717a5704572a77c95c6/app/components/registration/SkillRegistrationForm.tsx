import { useState } from 'react'
import {
  SkillMetadataSchema,
  SKILL_PLATFORM_OPTIONS,
  type SkillMetadataPayload,
  type SkillPlatformType,
} from '~/lib/schemas/skill-metadata'
import { getProviderOptions } from '~/data/providers'
import { ComboSelect } from '~/components/ui/ComboSelect'
import type { ZodError } from 'zod'

interface SkillRegistrationFormProps {
  onSubmit: (metadata: SkillMetadataPayload) => Promise<void>
  isSubmitting?: boolean
  initialData?: Partial<SkillMetadataPayload>
}

interface FieldError {
  [field: string]: string | undefined
}

// Shared form styles
const INPUT =
  'w-full bg-app-input border border-app-line rounded-lg px-3 py-2.5 text-ink-default font-mono text-sm placeholder:text-ink-faint focus:border-[hsl(var(--accent))] focus:outline-none transition-colors disabled:opacity-50'
const INPUT_ERR =
  'w-full bg-app-input border border-loss rounded-lg px-3 py-2.5 text-ink-default font-mono text-sm placeholder:text-ink-faint focus:border-loss focus:outline-none transition-colors disabled:opacity-50'
const LABEL = 'block font-mono text-[10px] uppercase tracking-[0.14em] text-ink-dull mb-1.5'
const HINT = 'mt-1.5 font-mono text-[10px] text-ink-faint tracking-wide'
const ERR_MSG = 'mt-1 font-mono text-[10px] text-loss tracking-wide'
const SECTION =
  'font-mono text-[10px] uppercase tracking-[0.14em] text-ink-faint mb-4 pb-2 border-b border-app-line'

const AUTHOR_OPTIONS = getProviderOptions()

export function SkillRegistrationForm({
  onSubmit,
  isSubmitting = false,
  initialData,
}: SkillRegistrationFormProps) {
  const [name, setName] = useState(initialData?.name ?? '')
  const [description, setDescription] = useState(initialData?.description ?? '')
  const [version, setVersion] = useState(initialData?.version ?? '')
  const [platform, setPlatform] = useState<SkillPlatformType>(
    (initialData?.platform as SkillPlatformType) ?? 'mcp',
  )
  const [image, setImage] = useState(initialData?.image ?? '')
  const [author, setAuthor] = useState(initialData?.author ?? '')
  const [installUri, setInstallUri] = useState(initialData?.installUri ?? '')
  const [permissions, setPermissions] = useState(
    initialData?.permissions?.join(', ') ?? '',
  )
  const [longDescription, setLongDescription] = useState(
    initialData?.longDescription ?? '',
  )
  const [errors, setErrors] = useState<FieldError>({})

  function validateField(field?: keyof SkillMetadataPayload): boolean {
    const metadata = buildMetadata()
    const result = SkillMetadataSchema.safeParse(metadata)

    if (result.success) {
      if (field) {
        setErrors((prev) => ({ ...prev, [field]: undefined }))
      } else {
        setErrors({})
      }
      return true
    }

    const fieldErrors: FieldError = {}
    const zodError = result.error as ZodError
    for (const issue of zodError.issues) {
      const path = issue.path.join('.')
      if (!field || path === field) {
        fieldErrors[path] = issue.message
      }
    }

    if (field) {
      setErrors((prev) => ({ ...prev, ...fieldErrors }))
    } else {
      setErrors(fieldErrors)
    }

    return false
  }

  function buildMetadata(): SkillMetadataPayload {
    const metadata: SkillMetadataPayload = {
      '@type': 'Skill',
      name: name.trim(),
      description: description.trim(),
      version: version.trim(),
      platform,
    }

    if (image.trim()) metadata.image = image.trim()
    if (author.trim()) metadata.author = author.trim()
    if (installUri.trim()) metadata.installUri = installUri.trim()
    if (longDescription.trim()) metadata.longDescription = longDescription.trim()

    if (permissions.trim()) {
      metadata.permissions = permissions
        .split(',')
        .map((p) => p.trim())
        .filter(Boolean)
    }

    return metadata
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!validateField()) return
    const metadata = buildMetadata()
    await onSubmit(metadata)
  }

  function handleAuthorChange(val: string) {
    // val may be a provider label or custom text
    const known = AUTHOR_OPTIONS.find((o) => o.label === val || o.value === val)
    setAuthor(known ? known.label : val)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* === IDENTITY === */}
      <div>
        <div className={SECTION}>=== IDENTITY ===</div>
        <div className="space-y-4">
          <div>
            <label htmlFor="skill-name" className={LABEL}>
              Name <span className="text-[hsl(var(--accent))]">*</span>
            </label>
            <input
              id="skill-name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              onBlur={() => validateField('name')}
              placeholder="github-mcp-server"
              className={errors.name ? INPUT_ERR : INPUT}
              aria-invalid={!!errors.name}
              aria-describedby={errors.name ? 'skill-name-error' : undefined}
              disabled={isSubmitting}
            />
            {errors.name && (
              <p id="skill-name-error" className={ERR_MSG}>
                {errors.name}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="skill-description" className={LABEL}>
              Description <span className="text-[hsl(var(--accent))]">*</span>
            </label>
            <textarea
              id="skill-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              onBlur={() => validateField('description')}
              rows={3}
              placeholder="Read and write GitHub issues, PRs, and code"
              className={errors.description ? INPUT_ERR : INPUT}
              aria-invalid={!!errors.description}
              aria-describedby={
                errors.description ? 'skill-description-error' : undefined
              }
              disabled={isSubmitting}
            />
            {errors.description && (
              <p id="skill-description-error" className={ERR_MSG}>
                {errors.description}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="skill-version" className={LABEL}>
              Version <span className="text-[hsl(var(--accent))]">*</span>
            </label>
            <input
              id="skill-version"
              type="text"
              value={version}
              onChange={(e) => setVersion(e.target.value)}
              onBlur={() => validateField('version')}
              placeholder="1.0.0"
              className={errors.version ? INPUT_ERR : INPUT}
              aria-invalid={!!errors.version}
              aria-describedby={errors.version ? 'skill-version-error' : undefined}
              disabled={isSubmitting}
            />
            <p className={HINT}>Semver format (e.g., 1.0.0, 2.1.3-beta)</p>
            {errors.version && (
              <p id="skill-version-error" className={ERR_MSG}>
                {errors.version}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* === PLATFORM === */}
      <div>
        <div className={SECTION}>=== PLATFORM ===</div>
        <div className="flex flex-wrap gap-2">
          {SKILL_PLATFORM_OPTIONS.map((p) => {
            const selected = platform === p
            return (
              <button
                key={p}
                type="button"
                onClick={() => setPlatform(p)}
                disabled={isSubmitting}
                className={`px-3 py-1.5 rounded-lg font-mono text-xs tracking-wider transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                  selected
                    ? 'bg-[hsl(var(--accent))/0.15] text-[hsl(var(--accent-faint))] border border-[hsl(var(--accent))/0.3] shadow-[0_0_8px_hsl(var(--accent)/0.1)]'
                    : 'bg-app-button text-ink-dull border border-app-line hover:text-ink-default hover:border-[hsl(var(--accent))/0.2]'
                }`}
              >
                {p}
              </button>
            )
          })}
        </div>
        {errors.platform && <p className={ERR_MSG}>{errors.platform}</p>}
      </div>

      {/* === INSTALLATION === */}
      <div>
        <div className={SECTION}>=== INSTALLATION ===</div>
        <div className="space-y-4">
          <div>
            <label htmlFor="skill-install-uri" className={LABEL}>
              Install URI
            </label>
            <input
              id="skill-install-uri"
              type="text"
              value={installUri}
              onChange={(e) => setInstallUri(e.target.value)}
              onBlur={() => validateField('installUri')}
              placeholder="npx @modelcontextprotocol/server-github"
              className={errors.installUri ? INPUT_ERR : INPUT}
              disabled={isSubmitting}
            />
            <p className={HINT}>
              Platform-specific install command (npx, mcp://, or http)
            </p>
            {errors.installUri && (
              <p className={ERR_MSG}>{errors.installUri}</p>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="skill-author" className={LABEL}>
                Author
              </label>
              <ComboSelect
                id="skill-author"
                options={AUTHOR_OPTIONS}
                value={author}
                onChange={handleAuthorChange}
                placeholder="Anthropic"
                allowCustom
                disabled={isSubmitting}
              />
            </div>

            <div>
              <label htmlFor="skill-image" className={LABEL}>
                Avatar URL
              </label>
              <input
                id="skill-image"
                type="url"
                value={image}
                onChange={(e) => setImage(e.target.value)}
                onBlur={() => validateField('image')}
                placeholder="https://example.com/icon.png"
                className={errors.image ? INPUT_ERR : INPUT}
                disabled={isSubmitting}
              />
              {errors.image && <p className={ERR_MSG}>{errors.image}</p>}
            </div>
          </div>
        </div>
      </div>

      {/* === PERMISSIONS === */}
      <div>
        <div className={SECTION}>=== PERMISSIONS ===</div>
        <div>
          <label htmlFor="skill-permissions" className={LABEL}>
            Required Permissions
          </label>
          <input
            id="skill-permissions"
            type="text"
            value={permissions}
            onChange={(e) => setPermissions(e.target.value)}
            placeholder="repo:read, issues:write, pull_requests:read"
            className={INPUT}
            disabled={isSubmitting}
          />
          <p className={HINT}>Comma-separated permission identifiers</p>
        </div>
      </div>

      {/* === DETAILS === */}
      <div>
        <div className={SECTION}>=== DETAILS ===</div>
        <div>
          <label htmlFor="skill-long-description" className={LABEL}>
            Extended Description
          </label>
          <textarea
            id="skill-long-description"
            value={longDescription}
            onChange={(e) => setLongDescription(e.target.value)}
            rows={4}
            placeholder="Detailed description of what this skill does, how it works, and any important caveats..."
            className={INPUT}
            disabled={isSubmitting}
          />
          <p className={HINT}>Optional extended description with more detail</p>
        </div>
      </div>

      {/* Submit */}
      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full py-3 rounded-lg bg-[hsl(var(--accent))] hover:bg-[hsl(var(--accent-deep))] text-white font-mono text-sm uppercase tracking-[0.1em] font-bold transition-colors disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
      >
        {isSubmitting ? 'DEPLOYING...' : 'DEPLOY SKILL'}
      </button>
    </form>
  )
}
