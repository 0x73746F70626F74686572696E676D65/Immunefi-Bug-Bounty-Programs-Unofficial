import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { PublicClient, WalletClient } from 'viem';
import { parseEther } from 'viem';
import {
  getAtomCost,
  getTripleCost,
  getAtomByUri,
  createAtoms,
  createTriples,
} from '../multivault';

// Mock viem clients
const createMockPublicClient = (): PublicClient => {
  return {
    readContract: vi.fn(),
  } as unknown as PublicClient;
};

const createMockWalletClient = (): WalletClient => {
  return {
    account: { address: '0x1234567890123456789012345678901234567890' } as any,
    chain: { id: 13579, name: 'Intuition Testnet' } as any,
    writeContract: vi.fn(),
  } as unknown as WalletClient;
};

const TEST_CONTRACT_ADDRESS = '0xB92EA1B47E4ABD0a520E9138BB59dBd1bC6C475B' as const;

describe('multivault', () => {
  let mockPublicClient: PublicClient;
  let mockWalletClient: WalletClient;

  beforeEach(() => {
    vi.resetAllMocks();
    mockPublicClient = createMockPublicClient();
    mockWalletClient = createMockWalletClient();
  });

  describe('getAtomCost', () => {
    it('should fetch atom cost from contract', async () => {
      const expectedCost = parseEther('0.01');
      (mockPublicClient.readContract as any).mockResolvedValue(expectedCost);

      const cost = await getAtomCost(mockPublicClient, TEST_CONTRACT_ADDRESS);

      expect(cost).toBe(expectedCost);
      expect(mockPublicClient.readContract).toHaveBeenCalledWith({
        address: TEST_CONTRACT_ADDRESS,
        abi: expect.any(Array),
        functionName: 'getAtomCost',
      });
    });
  });

  describe('getTripleCost', () => {
    it('should fetch triple cost from contract', async () => {
      const expectedCost = parseEther('0.01');
      (mockPublicClient.readContract as any).mockResolvedValue(expectedCost);

      const cost = await getTripleCost(mockPublicClient, TEST_CONTRACT_ADDRESS);

      expect(cost).toBe(expectedCost);
      expect(mockPublicClient.readContract).toHaveBeenCalledWith({
        address: TEST_CONTRACT_ADDRESS,
        abi: expect.any(Array),
        functionName: 'getTripleCost',
      });
    });
  });

  describe('getAtomByUri', () => {
    it('should return term_id if atom exists', async () => {
      const mockAtomId =
        '0x1234567890123456789012345678901234567890123456789012345678901234' as const;
      (mockPublicClient.readContract as any)
        .mockResolvedValueOnce(mockAtomId) // calculateAtomId
        .mockResolvedValueOnce(true); // isTermCreated

      const result = await getAtomByUri(
        mockPublicClient,
        TEST_CONTRACT_ADDRESS,
        'ipfs://QmTest'
      );

      expect(result).toBe(mockAtomId);
      expect(mockPublicClient.readContract).toHaveBeenCalledTimes(2);
    });

    it('should return null if atom does not exist', async () => {
      const mockAtomId =
        '0x1234567890123456789012345678901234567890123456789012345678901234' as const;
      (mockPublicClient.readContract as any)
        .mockResolvedValueOnce(mockAtomId) // calculateAtomId
        .mockResolvedValueOnce(false); // isTermCreated

      const result = await getAtomByUri(
        mockPublicClient,
        TEST_CONTRACT_ADDRESS,
        'ipfs://QmTest'
      );

      expect(result).toBeNull();
    });

    it('should properly encode IPFS URI', async () => {
      const mockAtomId =
        '0x0000000000000000000000000000000000000000000000000000000000000000' as const;
      (mockPublicClient.readContract as any)
        .mockResolvedValueOnce(mockAtomId)
        .mockResolvedValueOnce(false);

      await getAtomByUri(mockPublicClient, TEST_CONTRACT_ADDRESS, 'ipfs://QmTest123');

      const firstCall = (mockPublicClient.readContract as any).mock.calls[0][0];
      // Verify the args contain hex-encoded data
      expect(firstCall.args[0]).toMatch(/^0x/);
      expect(firstCall.functionName).toBe('calculateAtomId');
    });
  });

  describe('createAtoms', () => {
    it('should create atoms with correct value calculation', async () => {
      const atomCost = parseEther('0.01');
      const depositAmount = parseEther('0.1');
      const mockHash = '0xabcdef' as const;

      (mockPublicClient.readContract as any).mockResolvedValue(atomCost);
      (mockWalletClient.writeContract as any).mockResolvedValue(mockHash);

      const result = await createAtoms(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        ['ipfs://QmTest1', 'ipfs://QmTest2'],
        depositAmount
      );

      expect(result.hash).toBe(mockHash);
      expect(result.atomCount).toBe(2);

      const writeCall = (mockWalletClient.writeContract as any).mock.calls[0][0];
      // Each atom costs atomCost + depositAmount
      const expectedValue = (atomCost + depositAmount) * 2n;
      expect(writeCall.value).toBe(expectedValue);
      expect(writeCall.functionName).toBe('createAtoms');
    });

    it('should encode IPFS URIs to hex bytes', async () => {
      const atomCost = parseEther('0.01');
      (mockPublicClient.readContract as any).mockResolvedValue(atomCost);
      (mockWalletClient.writeContract as any).mockResolvedValue('0xhash');

      await createAtoms(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        ['ipfs://QmTest'],
        parseEther('0.1')
      );

      const writeCall = (mockWalletClient.writeContract as any).mock.calls[0][0];
      const atomDataBytes = writeCall.args[0];

      // Check that data is hex-encoded (SEC-05)
      expect(Array.isArray(atomDataBytes)).toBe(true);
      expect(atomDataBytes[0]).toMatch(/^0x/);
    });

    it('should throw if wallet client has no account', async () => {
      const walletWithoutAccount = {
        ...mockWalletClient,
        account: undefined,
      } as WalletClient;

      await expect(
        createAtoms(
          mockPublicClient,
          walletWithoutAccount,
          TEST_CONTRACT_ADDRESS,
          ['ipfs://QmTest'],
          parseEther('0.1')
        )
      ).rejects.toThrow('Wallet client must have an account');
    });

    it('should handle single atom creation', async () => {
      const atomCost = parseEther('0.01');
      (mockPublicClient.readContract as any).mockResolvedValue(atomCost);
      (mockWalletClient.writeContract as any).mockResolvedValue('0xhash');

      const result = await createAtoms(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        ['ipfs://QmSingleAtom'],
        parseEther('0.5')
      );

      expect(result.atomCount).toBe(1);
    });
  });

  describe('createTriples', () => {
    it('should create triples with correct value calculation', async () => {
      const tripleCost = parseEther('0.01');
      const depositAmount = parseEther('0.05');
      const mockHash = '0xtriplehash' as const;

      (mockPublicClient.readContract as any).mockResolvedValue(tripleCost);
      (mockWalletClient.writeContract as any).mockResolvedValue(mockHash);

      const triples = [
        { subjectId: '123', predicateId: '456', objectId: '789' },
        { subjectId: '111', predicateId: '222', objectId: '333' },
      ];

      const result = await createTriples(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        triples,
        depositAmount
      );

      expect(result.hash).toBe(mockHash);
      expect(result.tripleCount).toBe(2);

      const writeCall = (mockWalletClient.writeContract as any).mock.calls[0][0];
      // Each triple costs tripleCost + depositAmount
      const expectedValue = (tripleCost + depositAmount) * 2n;
      expect(writeCall.value).toBe(expectedValue);
      expect(writeCall.functionName).toBe('createTriples');
    });

    it('should convert string IDs to bytes32', async () => {
      const tripleCost = parseEther('0.01');
      (mockPublicClient.readContract as any).mockResolvedValue(tripleCost);
      (mockWalletClient.writeContract as any).mockResolvedValue('0xhash');

      await createTriples(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        [{ subjectId: '123', predicateId: '456', objectId: '789' }],
        parseEther('0.05')
      );

      const writeCall = (mockWalletClient.writeContract as any).mock.calls[0][0];
      const [subjectIds, predicateIds, objectIds] = writeCall.args;

      // Should be converted to bytes32 format (66 chars: 0x + 64 hex)
      expect(subjectIds[0]).toMatch(/^0x[0-9a-f]{64}$/);
      expect(predicateIds[0]).toMatch(/^0x[0-9a-f]{64}$/);
      expect(objectIds[0]).toMatch(/^0x[0-9a-f]{64}$/);
    });

    it('should handle hex string IDs', async () => {
      const tripleCost = parseEther('0.01');
      (mockPublicClient.readContract as any).mockResolvedValue(tripleCost);
      (mockWalletClient.writeContract as any).mockResolvedValue('0xhash');

      await createTriples(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        [
          {
            subjectId: '0x7b',
            predicateId: '0x1c8',
            objectId: '0x315',
          },
        ],
        parseEther('0.05')
      );

      const writeCall = (mockWalletClient.writeContract as any).mock.calls[0][0];
      const [subjectIds] = writeCall.args;

      // Should be padded to 32 bytes
      expect(subjectIds[0]).toMatch(/^0x[0-9a-f]{64}$/);
    });

    it('should throw if wallet client has no account', async () => {
      const walletWithoutAccount = {
        ...mockWalletClient,
        account: undefined,
      } as WalletClient;

      await expect(
        createTriples(
          mockPublicClient,
          walletWithoutAccount,
          TEST_CONTRACT_ADDRESS,
          [{ subjectId: '1', predicateId: '2', objectId: '3' }],
          parseEther('0.05')
        )
      ).rejects.toThrow('Wallet client must have an account');
    });

    it('should handle many triples efficiently', async () => {
      const tripleCost = parseEther('0.01');
      (mockPublicClient.readContract as any).mockResolvedValue(tripleCost);
      (mockWalletClient.writeContract as any).mockResolvedValue('0xhash');

      const manyTriples = Array.from({ length: 10 }, (_, i) => ({
        subjectId: `${i}`,
        predicateId: `${i + 100}`,
        objectId: `${i + 200}`,
      }));

      const result = await createTriples(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        manyTriples,
        parseEther('0.01')
      );

      expect(result.tripleCount).toBe(10);
      // Should batch all in one transaction
      expect(mockWalletClient.writeContract).toHaveBeenCalledTimes(1);
    });
  });

  describe('fee calculation consistency', () => {
    it('should calculate total value correctly for atoms', async () => {
      const atomCost = parseEther('0.01');
      const depositAmount = parseEther('0.1');

      (mockPublicClient.readContract as any).mockResolvedValue(atomCost);
      (mockWalletClient.writeContract as any).mockResolvedValue('0xhash');

      await createAtoms(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        ['ipfs://A', 'ipfs://B', 'ipfs://C'],
        depositAmount
      );

      const writeCall = (mockWalletClient.writeContract as any).mock.calls[0][0];
      const expectedValue = (atomCost + depositAmount) * 3n;
      expect(writeCall.value).toBe(expectedValue);
    });

    it('should calculate total value correctly for triples', async () => {
      const tripleCost = parseEther('0.02');
      const depositAmount = parseEther('0.05');

      (mockPublicClient.readContract as any).mockResolvedValue(tripleCost);
      (mockWalletClient.writeContract as any).mockResolvedValue('0xhash');

      const triples = Array.from({ length: 5 }, (_, i) => ({
        subjectId: `${i}`,
        predicateId: `${i}`,
        objectId: `${i}`,
      }));

      await createTriples(
        mockPublicClient,
        mockWalletClient,
        TEST_CONTRACT_ADDRESS,
        triples,
        depositAmount
      );

      const writeCall = (mockWalletClient.writeContract as any).mock.calls[0][0];
      const expectedValue = (tripleCost + depositAmount) * 5n;
      expect(writeCall.value).toBe(expectedValue);
    });
  });
});
