import { useEffect, useState } from 'react'
import { useViewMode } from '~/lib/providers/view-mode'

export function PrototypeBanner() {
  const { isAgentView } = useViewMode()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  // Prevent hydration mismatch
  if (!mounted) {
    return (
      <div className="fixed left-0 right-0 top-0 z-50 h-6" />
    )
  }

  return (
    <div
      className={`fixed left-0 right-0 top-0 z-50 flex items-center justify-center border-b px-4 py-1 text-center backdrop-blur-sm ${
        isAgentView
          ? 'border-[hsl(120_30%_12%)] bg-[hsl(120_20%_5%_/_0.9)]'
          : 'border-border bg-muted/80'
      }`}
      style={{ height: '24px' }}
    >
      <p
        className={`font-mono text-[11px] font-medium uppercase tracking-wider ${
          isAgentView ? 'text-[hsl(120_100%_69%)]' : 'text-muted-foreground'
        }`}
      >
        {isAgentView ? '> PROTOTYPE // MOCK DATA ONLY' : 'PROTOTYPE — Mock Data Only'}
      </p>
    </div>
  )
}
