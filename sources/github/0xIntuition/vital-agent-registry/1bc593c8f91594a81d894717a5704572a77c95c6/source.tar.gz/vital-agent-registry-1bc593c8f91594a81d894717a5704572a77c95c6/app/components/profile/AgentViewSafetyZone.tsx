import type { Skill } from '~/types'
import { cn } from '~/lib/utils'


interface AgentViewSafetyZoneProps {
  skill: Skill
  className?: string
}

export function AgentViewSafetyZone({
  skill,
  className,
}: AgentViewSafetyZoneProps) {
  const { safetySignal } = skill

  // Calculate safety ratio
  const totalStake =
    Number(safetySignal.forStake) + Number(safetySignal.againstStake)
  const safetyRatio =
    totalStake > 0 ? Number(safetySignal.forStake) / totalStake : 0
  const forPercent = Math.round(safetyRatio * 100)
  const againstPercent = 100 - forPercent

  // Status indicator configuration
  const statusConfig = {
    verified: {
      label: '[SAFE]',
      color: 'text-[hsl(142_71%_45%)]',
      bgColor: 'bg-[hsl(142_71%_45%)]/20',
      borderColor: 'border-[hsl(142_71%_45%)]',
    },
    unverified: {
      label: '[UNVERIFIED]',
      color: 'text-[hsl(48_96%_53%)]',
      bgColor: 'bg-[hsl(48_96%_53%)]/20',
      borderColor: 'border-[hsl(48_96%_53%)]',
    },
    flagged: {
      label: '[!! FLAGGED !!]',
      color: 'text-[hsl(0_84%_60%)]',
      bgColor: 'bg-[hsl(0_84%_60%)]/20',
      borderColor: 'border-[hsl(0_84%_60%)]',
    },
  }

  const config = statusConfig[safetySignal.status]

  // Create visual bar (unicode blocks for proportional fill)
  const createBar = (percentage: number, maxBlocks = 16) => {
    const fullBlocks = Math.floor((percentage / 100) * maxBlocks)
    const remainder = ((percentage / 100) * maxBlocks) % 1
    let bar = '█'.repeat(fullBlocks)

    // Add partial block based on remainder
    if (remainder > 0.75) bar += '▊'
    else if (remainder > 0.5) bar += '▋'
    else if (remainder > 0.25) bar += '▌'
    else if (remainder > 0) bar += '▎'

    // Fill remaining with empty blocks
    const emptyBlocks = maxBlocks - bar.length
    bar += '░'.repeat(emptyBlocks)

    return bar
  }

  return (
    <div
      className={cn(
        'rounded-[var(--radius-card)] border-2 bg-card shadow-[var(--shadow-card)] p-4 font-mono text-sm',
        config.borderColor,
        safetySignal.status === 'flagged' && 'animate-pulse',
        className,
      )}
    >
      <div className="text-muted-foreground mb-4">
        === SAFETY ASSESSMENT ===
      </div>

      {/* Large status indicator */}
      <div
        className={cn(
          'text-center py-3 mb-4 rounded font-bold text-lg',
          config.bgColor,
          config.color,
        )}
      >
        {config.label}
      </div>

      {/* Threat-level metrics */}
      <div className="space-y-2">
        <div className="flex justify-between">
          <span className="text-muted-foreground">SAFETY_RATIO:</span>
          <span className="text-foreground font-semibold">
            {safetyRatio.toFixed(2)}
          </span>
        </div>

        {/* FOR stake with bar */}
        <div>
          <div className="flex justify-between mb-1">
            <span className="text-muted-foreground">FOR_STAKE:</span>
            <span className="text-[hsl(142_71%_45%)]">
              {safetySignal.forStake} TRUST ({forPercent}%)
            </span>
          </div>
          <div className="text-[hsl(142_71%_45%)]">
            {createBar(forPercent)}
          </div>
        </div>

        {/* AGAINST stake with bar */}
        <div>
          <div className="flex justify-between mb-1">
            <span className="text-muted-foreground">AGAINST_STAKE:</span>
            <span className="text-[hsl(0_84%_60%)]">
              {safetySignal.againstStake} TRUST ({againstPercent}
              %)
            </span>
          </div>
          <div className="text-[hsl(0_84%_60%)]">
            {createBar(againstPercent)}
          </div>
        </div>

        {/* Flag reason */}
        <div className="flex justify-between">
          <span className="text-muted-foreground">FLAG_REASON:</span>
          <span
            className={cn(
              'text-foreground',
              safetySignal.status === 'flagged' && 'text-[hsl(0_84%_60%)]',
            )}
          >
            {safetySignal.flagReason || 'NONE'}
          </span>
        </div>

        {/* Attestor counts */}
        <div className="flex justify-between">
          <span className="text-muted-foreground">ATTESTORS:</span>
          <span className="text-foreground">
            {safetySignal.forCount + safetySignal.againstCount} (
            {safetySignal.forCount} FOR / {safetySignal.againstCount} AGAINST)
          </span>
        </div>
      </div>
    </div>
  )
}
