import { describe, it, expect } from 'vitest'
import {
  deriveAtomTermId,
  encodeCreateAtomCalldata,
  encodeCreateTriplesCalldata,
} from '../calldata'

describe('calldata', () => {
  describe('encodeCreateAtomCalldata', () => {
    it('should return a hex string starting with 0x', () => {
      const result = encodeCreateAtomCalldata('ipfs://QmTest123')

      expect(result).toMatch(/^0x/)
    })

    it('should encode the function selector for createAtom', () => {
      const result = encodeCreateAtomCalldata('ipfs://QmTest123')

      // Function selector is the first 4 bytes (8 hex chars after 0x)
      expect(result.length).toBeGreaterThan(10)
    })

    it('should accept IPFS URI strings', () => {
      const ipfsUri = 'ipfs://QmSomeHash123456'
      const result = encodeCreateAtomCalldata(ipfsUri)

      expect(result).toMatch(/^0x[0-9a-f]+$/i)
    })

    it('should produce different calldata for different URIs', () => {
      const result1 = encodeCreateAtomCalldata('ipfs://QmHash1')
      const result2 = encodeCreateAtomCalldata('ipfs://QmHash2')

      expect(result1).not.toBe(result2)
    })

    it('should return a valid hex string', () => {
      const result = encodeCreateAtomCalldata('ipfs://QmAnotherHash')

      // Valid hex: 0x followed by hex characters
      expect(result).toMatch(/^0x[0-9a-f]+$/i)
    })

    it('should encode IPFS URIs consistently', () => {
      const uri = 'ipfs://QmConsistent'
      const result1 = encodeCreateAtomCalldata(uri)
      const result2 = encodeCreateAtomCalldata(uri)

      expect(result1).toBe(result2)
    })

    it('should handle long IPFS hashes', () => {
      const longUri = 'ipfs://QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG'
      const result = encodeCreateAtomCalldata(longUri)

      expect(result).toMatch(/^0x[0-9a-f]+$/i)
      expect(result.length).toBeGreaterThan(10)
    })

    it('should handle URIs with special characters', () => {
      const uri = 'ipfs://QmTest?arg=value'
      const result = encodeCreateAtomCalldata(uri)

      expect(result).toMatch(/^0x[0-9a-f]+$/i)
    })
  })

  describe('encodeCreateTriplesCalldata', () => {
    it('encodes createTriples calldata as hex', () => {
      const result = encodeCreateTriplesCalldata([
        {
          subjectId: '0x1111111111111111111111111111111111111111111111111111111111111111',
          predicateId: '0x2222222222222222222222222222222222222222222222222222222222222222',
          objectId: '0x3333333333333333333333333333333333333333333333333333333333333333',
        },
      ])

      expect(result).toMatch(/^0x[0-9a-f]+$/i)
    })

    it('throws when no triples are provided', () => {
      expect(() => encodeCreateTriplesCalldata([])).toThrow('at least one triple is required')
    })
  })

  describe('deriveAtomTermId', () => {
    it('returns deterministic bytes32 ids for the same URI', () => {
      const uri = 'ipfs://QmDeterministicAtom'
      const first = deriveAtomTermId(uri)
      const second = deriveAtomTermId(uri)

      expect(first).toBe(second)
      expect(first).toMatch(/^0x[0-9a-fA-F]{64}$/)
    })

    it('returns different ids for different URIs', () => {
      const first = deriveAtomTermId('ipfs://QmOne')
      const second = deriveAtomTermId('ipfs://QmTwo')
      expect(first).not.toBe(second)
    })
  })
})
