import { describe, expect, it, vi } from 'vitest'

const getIndexerLagBlocks = vi.fn()

vi.mock('~/lib/indexer-lag.server', () => ({
  getIndexerLagBlocks,
}))

describe('me loader', () => {
  it('sources indexer lag blocks from server diagnostics', async () => {
    getIndexerLagBlocks.mockResolvedValueOnce(14)
    const { loader } = await import('../me')
    await expect(loader()).resolves.toEqual({ indexerLagBlocks: 14 })
  })
})
