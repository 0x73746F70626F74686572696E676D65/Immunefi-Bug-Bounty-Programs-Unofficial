import { useRef } from 'react'
import { useLocation } from 'react-router'
import { getRouteDepth } from '~/config/transitions'

export type NavigationDirection = 'forward' | 'back'

export function useNavigationDirection(): NavigationDirection {
  const location = useLocation()
  const prevDepthRef = useRef(getRouteDepth(location.pathname))
  const currentDepth = getRouteDepth(location.pathname)
  const direction: NavigationDirection = currentDepth >= prevDepthRef.current ? 'forward' : 'back'
  prevDepthRef.current = currentDepth
  return direction
}
