/**
 * Server-only environment variables.
 * NEVER expose GRAPHQL_API_URL_PRIVATE to the client.
 */
export function getServerEnv() {
  return {
    GRAPHQL_API_URL_PRIVATE: process.env.GRAPHQL_API_URL_PRIVATE ?? '',
    REGISTRY_API_KEY: process.env.REGISTRY_API_KEY ?? '',
    ORIGIN_URL: process.env.ORIGIN_URL ?? '',
  }
}

/**
 * Public environment variables exposed to the client via window.ENV.
 */
export function getPublicEnv() {
  return {
    DEPLOY_ENV: process.env.DEPLOY_ENV ?? 'development',
    CHAIN: process.env.CHAIN ?? 'testnet',
    WALLET_CONNECT_PROJECT_ID: process.env.WALLET_CONNECT_PROJECT_ID ?? '',
  }
}

export type PublicEnv = ReturnType<typeof getPublicEnv>

declare global {
  interface Window {
    ENV: PublicEnv
  }
}
