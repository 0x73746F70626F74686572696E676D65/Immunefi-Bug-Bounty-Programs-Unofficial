import { createRepository } from '~/data/repository/provider'
import { matchSchema } from '~/lib/api/validation'
import { normalizeCapabilityIds } from '~/lib/capability-normalization'
import { handleOptions, parseJsonBody, jsonResponse, errorResponse } from '~/lib/api/types'
import type { Agent } from '~/types'
import type { LoaderFunctionArgs, ActionFunctionArgs } from 'react-router'

/**
 * Compute match score for an agent based on required and preferred capabilities.
 *
 * Scoring is intentionally in the route layer (not repository) because different
 * API consumers may want different scoring algorithms. For example, a chatbot
 * consumer might weight preferred capabilities differently than a workflow orchestrator.
 *
 * @param agent - Agent to score
 * @param required - Required capabilities
 * @param preferred - Preferred capabilities (optional)
 * @returns Match score 0-100
 */
function computeMatchScore(agent: Agent, required: string[], preferred: string[]): number {
  const agentCapIds = agent.capabilities.map((c) => c.id)
  const requiredHits = required.filter((cap) => agentCapIds.includes(cap)).length
  const preferredHits = preferred.filter((cap) => agentCapIds.includes(cap)).length

  // If no preferred, score purely on required match
  if (preferred.length === 0) {
    return Math.round((requiredHits / required.length) * 100)
  }

  // Otherwise weight: 70% required, 30% preferred
  const score = (requiredHits / required.length) * 0.7 + (preferredHits / preferred.length) * 0.3
  return Math.round(score * 100)
}

type MatchSort = 'match_score' | 'trust' | 'stakers'

function sortMatchedAgents(
  agents: Array<Agent & { matchScore: number }>,
  sortBy: MatchSort,
): Array<Agent & { matchScore: number }> {
  const sorted = [...agents]

  sorted.sort((a, b) => {
    if (sortBy === 'trust') {
      if (b.trustSignal.percentile !== a.trustSignal.percentile) {
        return b.trustSignal.percentile - a.trustSignal.percentile
      }
      return b.matchScore - a.matchScore
    }

    if (sortBy === 'stakers') {
      if (b.trustSignal.stakerCount !== a.trustSignal.stakerCount) {
        return b.trustSignal.stakerCount - a.trustSignal.stakerCount
      }
      if (b.matchScore !== a.matchScore) {
        return b.matchScore - a.matchScore
      }
      return b.trustSignal.percentile - a.trustSignal.percentile
    }

    if (b.matchScore !== a.matchScore) {
      return b.matchScore - a.matchScore
    }
    if (b.trustSignal.percentile !== a.trustSignal.percentile) {
      return b.trustSignal.percentile - a.trustSignal.percentile
    }
    return b.trustSignal.stakerCount - a.trustSignal.stakerCount
  })

  return sorted
}

export async function loader({ request }: LoaderFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  return errorResponse('Use POST for capability matching', 'METHOD_NOT_ALLOWED', 405)
}

export async function action({ request }: ActionFunctionArgs) {
  try {
    const optRes = handleOptions(request)
    if (optRes) return optRes

    const parsed = await parseJsonBody(request, matchSchema)
    if ('error' in parsed) return parsed.error

    const {
      required_capabilities,
      preferred_capabilities = [],
      min_trust_tier,
      match_all,
      sort_by,
      limit,
    } = parsed.data
    const requiredNormalized = normalizeCapabilityIds(required_capabilities)
    const preferredNormalized = normalizeCapabilityIds(preferred_capabilities)
    const repo = createRepository()

    // Get matching agents from repository (no scores yet)
    const agents = await repo.matchAgentCapabilities(requiredNormalized, {
      matchAll: match_all,
      minTrustTier: min_trust_tier,
      limit,
    })

    // Compute match scores in the route layer
    const scored = agents.map((agent) => ({
      ...agent,
      matchScore: computeMatchScore(agent, requiredNormalized, preferredNormalized),
    }))
    const ranked = sortMatchedAgents(scored, sort_by)

    return jsonResponse(ranked, { total: ranked.length, limit: limit ?? 20, offset: 0 })
  } catch (error) {
    return errorResponse(
      'Failed to match agents',
      'INTERNAL_ERROR',
      500,
      { message: error instanceof Error ? error.message : 'Unknown error' },
    )
  }
}
