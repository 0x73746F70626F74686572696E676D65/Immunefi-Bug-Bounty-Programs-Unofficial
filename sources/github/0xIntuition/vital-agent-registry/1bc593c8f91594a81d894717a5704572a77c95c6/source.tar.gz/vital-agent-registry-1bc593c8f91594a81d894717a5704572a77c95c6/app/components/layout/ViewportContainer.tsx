import { BottomNav } from './BottomNav'

interface ViewportContainerProps {
  children: React.ReactNode
  hideNav?: boolean
}

export function ViewportContainer({ children, hideNav }: ViewportContainerProps) {
  return (
    <div className="flex min-h-svh items-center justify-center bg-neutral-950">
      <div className="relative flex h-svh w-full max-w-[430px] flex-col overflow-hidden bg-background shadow-2xl md:h-[90svh] md:rounded-3xl md:border md:border-border">
        <div className="flex-1 overflow-y-auto overscroll-none">
          {children}
        </div>
        {!hideNav && <BottomNav />}
      </div>
    </div>
  )
}
