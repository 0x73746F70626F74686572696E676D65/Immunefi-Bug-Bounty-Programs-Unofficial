import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

// ---------------------------------------------------------------------------
// Shared mock declarations (vi.hoisted runs before vi.mock)
// ---------------------------------------------------------------------------
const mocks = vi.hoisted(() => ({
  // multivault
  getAtomCost: vi.fn(),
  createAtoms: vi.fn(),
  getAtomByUri: vi.fn(),
  getMinimumDeposit: vi.fn(),
  getTripleCost: vi.fn(),
  createTriples: vi.fn(),
  depositToTerm: vi.fn(),
  // calldata
  deriveAtomTermId: vi.fn(),
  encodeCreateTriplesCalldata: vi.fn(),
  deriveIdentityAtomTermId: vi.fn(),
  encodeIdentityAtomData: vi.fn(),
  encodeCreateIdentityAtomCalldata: vi.fn(),
  // local-write
  createLocalWriteClients: vi.fn(),
  getLocalWriteContext: vi.fn(),
  // remote-write-guard
  assertRemoteWriteAllowed: vi.fn(),
  // rate-limit
  isRegistrationRateLimitEnabled: vi.fn(),
  registrationLimiter: { check: vi.fn(), reset: vi.fn() },
  getClientIP: vi.fn(),
  // graphql
  serverGraphqlRequest: vi.fn(),
  // ipfs
  uploadAgentMetadata: vi.fn(),
  // term-ids
  getPredicates: vi.fn(),
  getTypeAtoms: vi.fn(),
  // local-agent-cache
  storeLocalAgent: vi.fn(),
  // repository
  createRepository: vi.fn(),
}))

// ---------------------------------------------------------------------------
// Module mocks
// ---------------------------------------------------------------------------
vi.mock('~/.server/multivault', () => ({
  getAtomCost: mocks.getAtomCost,
  createAtoms: mocks.createAtoms,
  getAtomByUri: mocks.getAtomByUri,
  getMinimumDeposit: mocks.getMinimumDeposit,
  getTripleCost: mocks.getTripleCost,
  createTriples: mocks.createTriples,
  depositToTerm: mocks.depositToTerm,
}))

vi.mock('~/lib/calldata', () => ({
  deriveAtomTermId: mocks.deriveAtomTermId,
  encodeCreateTriplesCalldata: mocks.encodeCreateTriplesCalldata,
  deriveIdentityAtomTermId: mocks.deriveIdentityAtomTermId,
  encodeIdentityAtomData: mocks.encodeIdentityAtomData,
  encodeCreateIdentityAtomCalldata: mocks.encodeCreateIdentityAtomCalldata,
}))

vi.mock('viem', () => ({
  encodeFunctionData: vi.fn(() => '0xcalldata'),
  parseEventLogs: vi.fn(() => []),
  toHex: vi.fn((s: string) => `0x${Buffer.from(s).toString('hex')}`),
  createPublicClient: vi.fn(() => ({})),
  http: vi.fn(() => ({})),
  parseEther: vi.fn((v: string) => BigInt(Math.floor(parseFloat(v) * 1e18))),
}))

vi.mock('~/.server/local-write', () => ({
  createLocalWriteClients: mocks.createLocalWriteClients,
  getLocalWriteContext: mocks.getLocalWriteContext,
}))

vi.mock('~/.server/remote-write-guard', () => ({
  assertRemoteWriteAllowed: mocks.assertRemoteWriteAllowed,
  RemoteWriteGuardError: class RemoteWriteGuardError extends Error {
    code: string
    profile: string
    target: string
    action: string
    constructor(message: string, code: string, profile: string, target: string, action: string) {
      super(message)
      this.code = code
      this.profile = profile
      this.target = target
      this.action = action
    }
  },
}))

vi.mock('~/lib/abis/multivault', () => ({
  multivaultAbi: [],
}))

vi.mock('~/lib/rate-limit', () => ({
  registrationLimiter: mocks.registrationLimiter,
  getClientIP: mocks.getClientIP,
  isRegistrationRateLimitEnabled: mocks.isRegistrationRateLimitEnabled,
}))

vi.mock('~/lib/graphql/client', () => ({
  serverGraphqlRequest: mocks.serverGraphqlRequest,
}))

vi.mock('~/lib/graphql/queries', () => ({
  GET_ATOM_DETAIL: 'mock_GET_ATOM_DETAIL',
  SEARCH_ATOMS: 'mock_SEARCH_ATOMS',
  GET_ATOMS: 'mock_GET_ATOMS',
  GET_TRIPLES_FOR_ATOM: 'mock_GET_TRIPLES_FOR_ATOM',
  GET_TRIPLES_ABOUT_ATOM: 'mock_GET_TRIPLES_ABOUT_ATOM',
  GET_POSITIONS_FOR_VAULT: 'mock_GET_POSITIONS_FOR_VAULT',
  GET_ACCOUNT: 'mock_GET_ACCOUNT',
  GET_ACCOUNT_WITH_ATOMS: 'mock_GET_ACCOUNT_WITH_ATOMS',
}))

vi.mock('~/lib/constants/protocol', () => ({
  getContractAddress: vi.fn(() => '0xcontract'),
  getChainConfig: vi.fn(() => ({ chainId: 13579 })),
  getRpcUrl: vi.fn(() => 'http://localhost:8545'),
  NAMESPACES: { AGENT: 'agent', SKILL: 'skill' },
}))

vi.mock('~/.server/ipfs', () => ({
  uploadAgentMetadata: mocks.uploadAgentMetadata,
  IpfsUploadError: class IpfsUploadError extends Error {
    category: string
    constructor(message: string, category: string) {
      super(message)
      this.name = 'IpfsUploadError'
      this.category = category
    }
  },
}))

vi.mock('~/.server/term-ids', () => ({
  getPredicates: mocks.getPredicates,
  getTypeAtoms: mocks.getTypeAtoms,
}))

vi.mock('~/.server/local-agent-cache', () => ({
  storeLocalAgent: mocks.storeLocalAgent,
}))

vi.mock('~/data/repository/provider', () => ({
  createRepository: mocks.createRepository,
}))

// ---------------------------------------------------------------------------
// Realistic term IDs (bytes32 hex)
// ---------------------------------------------------------------------------
const CAPABILITY_TERM_ID = '0xaaaa111111111111111111111111111111111111111111111111111111111111'
const AGENT_IDENTITY_TERM_ID = '0xbbbb222222222222222222222222222222222222222222222222222222222222'
const METADATA_TERM_ID = '0xcccc333333333333333333333333333333333333333333333333333333333333'
const HAS_CAPABILITY_PREDICATE = '0xdddd444444444444444444444444444444444444444444444444444444444444'
const IS_PREDICATE = '0xeeee555555555555555555555555555555555555555555555555555555555555'
const HAS_METADATA_PREDICATE = '0xffff666666666666666666666666666666666666666666666666666666666666'
const CREATED_BY_PREDICATE = '0x1111777777777777777777777777777777777777777777777777777777777777'
const USES_PREDICATE = '0x2222888888888888888888888888888888888888888888888888888888888888'
const AGENT_TYPE_TERM_ID = '0x3333999999999999999999999999999999999999999999999999999999999999'
const TRIPLE_TERM_ID = '0x4444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'

describe('Agent Lifecycle Integration', () => {
  const baseEnv = { ...process.env }

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = {
      ...baseEnv,
      CHAIN: 'testnet',
      REGISTRY_API_KEY: 'test-key',
    }
    mocks.isRegistrationRateLimitEnabled.mockReturnValue(false)

    // Shared local-write mocks
    mocks.getLocalWriteContext.mockReturnValue({
      contractAddress: '0xcontract',
      rpcUrl: 'http://localhost:8545',
    })
    mocks.createLocalWriteClients.mockResolvedValue({
      publicClient: {
        waitForTransactionReceipt: vi.fn().mockResolvedValue({ logs: [] }),
      },
      walletClient: {
        account: { address: '0xwalletaddress' },
      },
    })
    mocks.getMinimumDeposit.mockResolvedValue(1n)
    mocks.getAtomByUri.mockResolvedValue(null)

    // Atom route mocks
    mocks.getAtomCost.mockResolvedValue(10n)
    mocks.deriveAtomTermId.mockReturnValue(CAPABILITY_TERM_ID)
    mocks.createAtoms.mockResolvedValue({ hash: '0xatomhash', atomCount: 1 })

    // Triple route mocks
    mocks.getTripleCost.mockResolvedValue(25n)
    mocks.encodeCreateTriplesCalldata.mockReturnValue('0xtripledata')
    mocks.createTriples.mockResolvedValue({ hash: '0xtriplehash', tripleCount: 1 })

    // Registration mocks
    mocks.deriveIdentityAtomTermId.mockReturnValue(AGENT_IDENTITY_TERM_ID)
    mocks.encodeIdentityAtomData.mockReturnValue('{"name":"lifecycle-test-agent","namespace":"agent"}')
    mocks.uploadAgentMetadata.mockResolvedValue('ipfs://QmTestHash123')
    mocks.getPredicates.mockReturnValue({
      IS: IS_PREDICATE,
      HAS_CAPABILITY: HAS_CAPABILITY_PREDICATE,
      USES: USES_PREDICATE,
      HAS_METADATA: HAS_METADATA_PREDICATE,
      CREATED_BY: CREATED_BY_PREDICATE,
    })
    mocks.getTypeAtoms.mockReturnValue({
      AGENT_TYPE: AGENT_TYPE_TERM_ID,
      SKILL_TYPE: '0x5555000000000000000000000000000000000000000000000000000000000000',
    })

    // Stake mock
    mocks.depositToTerm.mockResolvedValue({
      hash: '0xstakehash',
      curveId: 0n,
      assets: 10000000000000000n,
    })
  })

  afterEach(() => {
    process.env = { ...baseEnv }
  })

  it('should complete full agent lifecycle', async () => {
    // Track state across steps
    let capabilityTermId: string
    let agentTermId: string
    let tripleTermId: string

    // -----------------------------------------------------------------------
    // Step 1: Create custom capability atom
    // POST /api/v1/atoms?execute=true
    // -----------------------------------------------------------------------
    {
      const { action } = await import('../api+/v1.atoms')
      const response = await action({
        request: new Request('http://localhost:4101/api/v1/atoms?execute=true', {
          method: 'POST',
          headers: { 'content-type': 'application/json', 'x-api-key': 'test-key' },
          body: JSON.stringify({ atomData: ['collaborative-coding'] }),
        }),
        params: {},
        context: {},
      } as never)

      expect(response.status).toBe(200)
      const body = await response.json()
      expect(body.data.execution.executed).toBe(true)
      capabilityTermId = body.data.atoms[0].termId
      expect(capabilityTermId).toBeDefined()
    }

    // -----------------------------------------------------------------------
    // Step 2: Register agent
    // POST /api/v1/agents/register?execute=true
    // -----------------------------------------------------------------------
    {
      // For registration execute mode, mock that identity atom gets created
      // (not yet on chain)
      mocks.getAtomByUri.mockResolvedValue(null)
      mocks.createAtoms.mockResolvedValue({ hash: '0xregatomhash', atomCount: 2 })
      // The deriveAtomTermId for the metadata IPFS URI
      mocks.deriveAtomTermId.mockReturnValue(METADATA_TERM_ID)

      const { action } = await import('../api+/v1.agents.register')
      const response = await action({
        request: new Request('http://localhost:4101/api/v1/agents/register?execute=true', {
          method: 'POST',
          headers: { 'content-type': 'application/json', 'x-api-key': 'test-key' },
          body: JSON.stringify({
            name: 'lifecycle-test-agent',
            description: 'Integration test agent',
            version: '1.0.0',
          }),
        }),
        params: {},
        context: {},
      } as never)

      expect(response.status).toBe(200)
      const body = await response.json()
      expect(body.data.execution.executed).toBe(true)
      agentTermId = body.data.identityAtomTermId
      expect(agentTermId).toBeDefined()
    }

    // -----------------------------------------------------------------------
    // Step 3: Create has-capability triple
    // POST /api/v1/triples?execute=true
    // -----------------------------------------------------------------------
    {
      mocks.createTriples.mockResolvedValue({ hash: '0xtriplehash', tripleCount: 1 })

      const { action } = await import('../api+/v1.triples')
      const response = await action({
        request: new Request('http://localhost:4101/api/v1/triples?execute=true', {
          method: 'POST',
          headers: { 'content-type': 'application/json', 'x-api-key': 'test-key' },
          body: JSON.stringify({
            triples: [{
              subjectId: agentTermId,
              predicateId: HAS_CAPABILITY_PREDICATE,
              objectId: capabilityTermId,
            }],
          }),
        }),
        params: {},
        context: {},
      } as never)

      expect(response.status).toBe(200)
      const body = await response.json()
      expect(body.data.execution.executed).toBe(true)
      expect(body.data.execution.txHash).toBe('0xtriplehash')
      // Save triple term ID for staking step
      tripleTermId = TRIPLE_TERM_ID
    }

    // -----------------------------------------------------------------------
    // Step 4: Query agent's triples
    // GET /api/v1/triples?subjectId=<agentTermId>
    // -----------------------------------------------------------------------
    {
      mocks.serverGraphqlRequest.mockResolvedValue({
        total: { aggregate: { count: 1 } },
        triples: [
          {
            term_id: TRIPLE_TERM_ID,
            counter_term_id: '0x0000000000000000000000000000000000000000000000000000000000000001',
            created_at: '2025-01-01T00:00:00Z',
            subject: { term_id: agentTermId, label: 'lifecycle-test-agent', image: null, type: 'agent' },
            predicate: { term_id: HAS_CAPABILITY_PREDICATE, label: 'has-capability', image: null, type: 'predicate' },
            object: { term_id: capabilityTermId, label: 'collaborative-coding', image: null, type: 'capability', data: null },
            term: {
              total_market_cap: '1000',
              positions_aggregate: { aggregate: { count: 1 } },
              vaults: [],
            },
            creator: { id: '0xwalletaddress', label: 'Creator', image: null },
          },
        ],
      })

      const { loader } = await import('../api+/v1.triples')
      const response = await loader({
        request: new Request(`http://localhost:4101/api/v1/triples?subjectId=${agentTermId}`),
        params: {},
        context: {},
      } as never)

      expect(response.status).toBe(200)
      const body = await response.json()
      expect(body.data).toHaveLength(1)
      expect(body.data[0].subject.term_id).toBe(agentTermId)
      expect(body.data[0].predicate.label).toBe('has-capability')
      expect(body.data[0].object.label).toBe('collaborative-coding')
    }

    // -----------------------------------------------------------------------
    // Step 5: Look up capability atom
    // GET /api/v1/atoms/<capabilityTermId>
    // -----------------------------------------------------------------------
    {
      mocks.serverGraphqlRequest.mockResolvedValue({
        atom: {
          term_id: capabilityTermId,
          label: 'collaborative-coding',
          image: null,
          type: 'capability',
          data: 'collaborative-coding',
          creator: { id: '0xwalletaddress', label: 'Creator', image: null },
        },
      })

      const { loader } = await import('../api+/v1.atoms.$id')
      const response = await loader({
        request: new Request(`http://localhost:4101/api/v1/atoms/${capabilityTermId}`),
        params: { id: capabilityTermId },
        context: {},
      } as never)

      expect(response.status).toBe(200)
      const body = await response.json()
      expect(body.data.term_id).toBe(capabilityTermId)
      expect(body.data.label).toBe('collaborative-coding')
    }

    // -----------------------------------------------------------------------
    // Step 6: Search atoms
    // GET /api/v1/atoms/search?q=collaborative
    // -----------------------------------------------------------------------
    {
      mocks.serverGraphqlRequest.mockResolvedValue({
        atoms: [
          {
            term_id: capabilityTermId,
            label: 'collaborative-coding',
            image: null,
            type: 'capability',
            data: 'collaborative-coding',
            creator: { id: '0xwalletaddress', label: 'Creator', image: null },
            term: { vaults: [] },
          },
        ],
      })

      const { loader } = await import('../api+/v1.atoms.search')
      const response = await loader({
        request: new Request('http://localhost:4101/api/v1/atoms/search?q=collaborative'),
        params: {},
        context: {},
      } as never)

      expect(response.status).toBe(200)
      const body = await response.json()
      expect(body.data.length).toBeGreaterThanOrEqual(1)
      expect(body.data[0].label).toBe('collaborative-coding')
    }

    // -----------------------------------------------------------------------
    // Step 7: Discover agent via agents list
    // GET /api/v1/agents?capability=collaborative-coding
    // -----------------------------------------------------------------------
    {
      const mockRepo = {
        listAgents: vi.fn().mockResolvedValue({
          items: [
            {
              id: agentTermId,
              name: 'lifecycle-test-agent',
              description: 'Integration test agent',
              capabilities: ['collaborative-coding'],
            },
          ],
          total: 1,
        }),
        searchAgents: vi.fn(),
      }
      mocks.createRepository.mockReturnValue(mockRepo)

      const { loader } = await import('../api+/v1.agents')
      const response = await loader({
        request: new Request('http://localhost:4101/api/v1/agents?capability=collaborative-coding'),
        params: {},
        context: {},
      } as never)

      expect(response.status).toBe(200)
      const body = await response.json()
      expect(body.data).toHaveLength(1)
      expect(body.data[0].name).toBe('lifecycle-test-agent')
    }

    // -----------------------------------------------------------------------
    // Step 8: Stake FOR a triple
    // POST /api/v1/trust/stake
    // -----------------------------------------------------------------------
    {
      const { action } = await import('../api+/v1.trust.stake')
      const response = await action({
        request: new Request('http://localhost:4101/api/v1/trust/stake', {
          method: 'POST',
          headers: { 'content-type': 'application/json', 'x-api-key': 'test-key' },
          body: JSON.stringify({
            termId: tripleTermId,
            amountEth: '0.01',
            direction: 'for',
          }),
        }),
        params: {},
        context: {},
      } as never)

      expect(response.status).toBe(200)
      const body = await response.json()
      expect(body.data.executed).toBe(true)
      expect(body.data.direction).toBe('for')
      expect(body.data.txHash).toBe('0xstakehash')
    }
  })
})
