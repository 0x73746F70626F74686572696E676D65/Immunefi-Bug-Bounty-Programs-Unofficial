import type { ActionFunctionArgs } from 'react-router'
import { handleOptions, parseJsonBody, jsonResponse, errorResponse, corsHeaders } from '~/lib/api/types'
import { registerAgentSchema } from '~/lib/api/validation'
import { uploadAgentMetadata, IpfsUploadError } from '~/.server/ipfs'
import { encodeCreateTriplesCalldata, deriveAtomTermId, deriveIdentityAtomTermId, encodeIdentityAtomData } from '~/lib/calldata'
import { getAtomCost, getTripleCost } from '~/.server/multivault'
import { createPublicClient, http, parseEventLogs } from 'viem'
import { NAMESPACES, getContractAddress, getRpcUrl, getChainConfig } from '~/lib/constants/protocol'
import type { NetworkId } from '~/lib/constants/protocol'
import { getPredicates, getTypeAtoms } from '~/.server/term-ids'
import { registrationLimiter, getClientIP, isRegistrationRateLimitEnabled } from '~/lib/rate-limit'
import { requireExecuteAuth } from '~/.server/execute-auth'
import { assertRemoteWriteAllowed, RemoteWriteGuardError } from '~/.server/remote-write-guard'
import { createLocalWriteClients, getLocalWriteContext } from '~/.server/local-write'
import { createAtoms, createTriples, getAtomByUri, getMinimumDeposit } from '~/.server/multivault'
import { storeLocalAgent } from '~/.server/local-agent-cache'
import { multivaultAbi } from '~/lib/abis/multivault'

function isResolvedTermId(value: string | undefined): value is `0x${string}` {
  return Boolean(value && /^0x[0-9a-fA-F]{64}$/.test(value) && !value.startsWith('0x_placeholder_'))
}

/**
 * POST /api/v1/agents/register
 *
 * Returns unsigned calldata for agent self-registration.
 * Does NOT sign or send transactions (SEC-07).
 *
 * v3 Flow (two atoms):
 * 1. Create identity atom with minimal data: { name, namespace }
 * 2. Upload full metadata to IPFS
 * 3. Create metadata atom (from IPFS URI)
 * 4. Create triples:
 *    - has-metadata: identity -> metadata
 *    - is: identity -> Agent type
 *    - has-capability: identity -> capability
 *    - uses: identity -> skill
 *
 * Client must then:
 * 1. Sign and send createAtoms transaction (2 atoms)
 * 2. Wait for indexer to confirm and get atomTermIds
 * 3. Create relationship triples (separate step)
 */
export async function action({ request }: ActionFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes
  const url = new URL(request.url)
  const execute = url.searchParams.get('execute') === 'true'

  if (execute) {
    const auth = requireExecuteAuth(request)
    if (!auth.authorized) return auth.response
  }

  // Rate limit check (SEC-08)
  if (isRegistrationRateLimitEnabled()) {
    const ip = getClientIP(request)
    const limit = registrationLimiter.check(ip)
    if (!limit.allowed) {
      return new Response(
        JSON.stringify({
          error: 'Too many requests',
          code: 'RATE_LIMITED',
          retryAfter: Math.ceil((limit.resetAt - Date.now()) / 1000),
        }),
        {
          status: 429,
          headers: {
            ...corsHeaders(),
            'Content-Type': 'application/json',
            'Retry-After': String(Math.ceil((limit.resetAt - Date.now()) / 1000)),
          },
        }
      )
    }
  }

  // Parse and validate request body
  const parsed = await parseJsonBody(request, registerAgentSchema)
  if ('error' in parsed) return parsed.error

  const metadata = parsed.data

  // v3: Convert to AgentMetadata schema format with new field names
  const agentMetadata = {
    '@type': 'Agent' as const,
    name: metadata.name,
    description: metadata.description,
    version: metadata.version,
    image: metadata.image,
    model: metadata.model,
    endpoint: metadata.endpoint,
    provider: metadata.provider,
    // v3: renamed fields - capabilities instead of tags, inputModes/outputModes instead of default*
    capabilities: metadata.tags,
    inputModes: metadata.defaultInputModes,
    outputModes: metadata.defaultOutputModes,
  }

  try {
    const PREDICATES = getPredicates()
    const TYPE_ATOMS = getTypeAtoms()

    if (!execute) {
      assertRemoteWriteAllowed({
        action: 'prepare agent registration',
        target: 'ipfs + chain',
      })
    }

    // v3: Step 1 - Create identity atom data (minimal JSON)
    const identityAtomTermId = deriveIdentityAtomTermId(metadata.name, NAMESPACES.AGENT)

    // v3: Step 2 - Upload full metadata to IPFS
    const metadataIpfsUri = await uploadAgentMetadata(agentMetadata)

    // v3: Step 3 - Create metadata atom term ID (from IPFS URI)
    const metadataAtomTermId = deriveAtomTermId(metadataIpfsUri)

    // Get costs
    const chain = (process.env.CHAIN as NetworkId) || 'testnet'
    const contractAddress = getContractAddress(chain)
    const rpcUrl = getRpcUrl(chain)

    const publicClient = createPublicClient({
      transport: http(rpcUrl),
    })

    const atomCost = await getAtomCost(publicClient, contractAddress)
    const minimumDeposit = await getMinimumDeposit(publicClient, contractAddress)

    // v3: Step 4 - Create triples linking identity to metadata and type/capabilities/skills
    const relationshipContext = metadata.relationshipContext ?? {}
    const hasMetadataPredicateTermId =
      relationshipContext.hasMetadataPredicateTermId ?? PREDICATES.HAS_METADATA
    const typePredicateTermId = relationshipContext.typePredicateTermId ?? PREDICATES.IS
    const typeObjectTermId = relationshipContext.typeObjectTermId ?? TYPE_ATOMS.AGENT_TYPE
    const hasCapabilityPredicateTermId =
      relationshipContext.hasCapabilityPredicateTermId ?? PREDICATES.HAS_CAPABILITY
    const usesSkillPredicateTermId =
      relationshipContext.usesSkillPredicateTermId ?? PREDICATES.USES

    // v3: All triples relate to the identity atom, not the metadata atom
    const triples: Array<{ subjectId: `0x${string}`; predicateId: `0x${string}`; objectId: `0x${string}` }> = []

    // has-metadata triple: identity -> metadata atom
    if (isResolvedTermId(hasMetadataPredicateTermId)) {
      triples.push({
        subjectId: identityAtomTermId,
        predicateId: hasMetadataPredicateTermId,
        objectId: metadataAtomTermId,
      })
    }

    // Type triple: identity -> Agent type
    if (isResolvedTermId(typePredicateTermId) && isResolvedTermId(typeObjectTermId)) {
      triples.push({
        subjectId: identityAtomTermId,
        predicateId: typePredicateTermId,
        objectId: typeObjectTermId,
      })
    }

    // Capability triples
    if (isResolvedTermId(hasCapabilityPredicateTermId)) {
      for (const capabilityTermId of relationshipContext.capabilityTermIds ?? []) {
        triples.push({
          subjectId: identityAtomTermId,
          predicateId: hasCapabilityPredicateTermId,
          objectId: capabilityTermId as `0x${string}`,
        })
      }
    }

    // Uses triples (agent uses skill)
    if (isResolvedTermId(usesSkillPredicateTermId)) {
      for (const skillTermId of relationshipContext.skillTermIds ?? []) {
        triples.push({
          subjectId: identityAtomTermId,
          predicateId: usesSkillPredicateTermId,
          objectId: skillTermId as `0x${string}`,
        })
      }
    }

    // created-by triple: identity -> creator
    const createdByPredicateTermId = relationshipContext.createdByPredicateTermId ?? PREDICATES.CREATED_BY
    const creatorTermId = relationshipContext.creatorTermId
    if (isResolvedTermId(createdByPredicateTermId) && isResolvedTermId(creatorTermId)) {
      triples.push({
        subjectId: identityAtomTermId,
        predicateId: createdByPredicateTermId,
        objectId: creatorTermId,
      })
    }

    if (metadata.requireTwoSignatures && triples.length === 0) {
      return errorResponse(
        'Two-signature flow requires resolvable relationship term ids',
        'RELATIONSHIP_CONTEXT_REQUIRED',
        400,
      )
    }

    // v3: Two atoms in one transaction
    // Encode both atom data: identity (JSON) and metadata (IPFS URI)
    const identityAtomData = encodeIdentityAtomData(metadata.name, NAMESPACES.AGENT)
    const { toHex } = await import('viem')
    const identityAtomBytes = toHex(identityAtomData)
    const metadataAtomBytes = toHex(metadataIpfsUri)

    const { encodeFunctionData } = await import('viem')
    const createAtomsCalldata = encodeFunctionData({
      abi: multivaultAbi,
      functionName: 'createAtoms',
      args: [[identityAtomBytes, metadataAtomBytes], [minimumDeposit, minimumDeposit]],
    })

    const hasTripleTx = triples.length > 0
    const tripleCost = hasTripleTx ? await getTripleCost(publicClient, contractAddress) : 0n
    const tripleCalldata = hasTripleTx ? encodeCreateTriplesCalldata(triples, minimumDeposit) : null

    // Per-atom total = creation fee + minimum deposit
    const perAtomTotal = atomCost + minimumDeposit
    // Per-triple total = creation fee + minimum deposit
    const perTripleTotal = tripleCost + minimumDeposit

    const response = {
      // v3: Return both URIs and term IDs
      identityIpfsUri: null, // Identity atom uses inline JSON, not IPFS
      identityAtomTermId,
      metadataIpfsUri,
      metadataAtomTermId,
      calldata: createAtomsCalldata,
      estimatedAtomCost: (perAtomTotal * 2n).toString(), // Two atoms (creation + deposit each)
      estimatedTripleCost: (perTripleTotal * BigInt(triples.length)).toString(),
      contractAddress,
      chainId: getChainConfig(chain).chainId,
      transactions: [
        {
          signatureIndex: 1,
          kind: 'createAtoms',
          atomCount: 2,
          to: contractAddress,
          data: createAtomsCalldata,
          value: (perAtomTotal * 2n).toString(),
        },
        ...(hasTripleTx
          ? [
              {
                signatureIndex: 2,
                kind: 'createTriples',
                to: contractAddress,
                data: tripleCalldata,
                value: (perTripleTotal * BigInt(triples.length)).toString(),
                tripleCount: triples.length,
              },
            ]
          : []),
      ],
      signaturePlan: {
        requiredSignatures: hasTripleTx ? 2 : 1,
        hasTripleTransaction: hasTripleTx,
      },
      indexerConfirmation: {
        identityAtomTermId,
        metadataAtomTermId,
        graphqlUrl: null, // Internal URL -- clients should use /api/graphql proxy
        lagState: 'indexer-lagged',
        timeoutState: 'indexer-timeout',
        polling: {
          maxRetries: 8,
          initialDelayMs: 500,
          maxDelayMs: 5000,
        },
      },
    }

    if (!execute) {
      return jsonResponse(response)
    }

    const context = getLocalWriteContext()
    const { publicClient: localPublicClient, walletClient } = await createLocalWriteClients(context)
    const localMinimumDeposit = await getMinimumDeposit(localPublicClient, context.contractAddress)

    // v3: Check for existing identity atom (by identity data)
    const { toHex: toHexLocal } = await import('viem')
    const identityAtomDataLocal = encodeIdentityAtomData(metadata.name, NAMESPACES.AGENT)
    const existingIdentityTermId = await getAtomByUri(
      localPublicClient,
      context.contractAddress,
      toHexLocal(identityAtomDataLocal)
    )

    // Check for existing metadata atom
    const existingMetadataTermId = await getAtomByUri(
      localPublicClient,
      context.contractAddress,
      metadataIpfsUri
    )

    let atomExecution: { hash: `0x${string}`; atomCount: number; createdTermIds?: `0x${string}`[] } | null = null
    let resolvedIdentityTermId: `0x${string}` | null = existingIdentityTermId
    let resolvedMetadataTermId: `0x${string}` | null = existingMetadataTermId

    if (!existingIdentityTermId || !existingMetadataTermId) {
      // Create both atoms in one transaction
      const atomsToCreate = []
      if (!existingIdentityTermId) {
        atomsToCreate.push(identityAtomDataLocal)
      } else {
        atomsToCreate.push('')
      }
      if (!existingMetadataTermId) {
        atomsToCreate.push(metadataIpfsUri)
      } else {
        atomsToCreate.push('')
      }

      // Filter out empty strings and create only missing atoms
      const newAtomsToCreate = atomsToCreate.filter((a): a is string => a !== '')

      if (newAtomsToCreate.length > 0) {
        atomExecution = await createAtoms(
          localPublicClient,
          walletClient,
          context.contractAddress,
          newAtomsToCreate,
          localMinimumDeposit,
        )
        const atomReceipt = await localPublicClient.waitForTransactionReceipt({ hash: atomExecution.hash })
        const atomCreatedLogs = parseEventLogs({
          abi: multivaultAbi,
          logs: atomReceipt.logs,
          eventName: 'AtomCreated',
        })

        // Map created term IDs to identity and metadata
        const createdTermIds = atomCreatedLogs.map((log) => log.args?.termId as `0x${string}`)
        let idx = 0
        if (!existingIdentityTermId && createdTermIds[idx]) {
          resolvedIdentityTermId = createdTermIds[idx]
          idx++
        }
        if (!existingMetadataTermId && createdTermIds[idx]) {
          resolvedMetadataTermId = createdTermIds[idx]
        }
      }
    }

    // Fallback: resolve term IDs by URI if not found
    if (!resolvedIdentityTermId) {
      resolvedIdentityTermId = await getAtomByUri(
        localPublicClient,
        context.contractAddress,
        toHexLocal(identityAtomDataLocal)
      )
    }
    if (!resolvedMetadataTermId) {
      resolvedMetadataTermId = await getAtomByUri(
        localPublicClient,
        context.contractAddress,
        metadataIpfsUri
      )
    }

    let tripleExecution: { hash: `0x${string}`; tripleCount: number } | null = null
    // v3: Update triples to use resolved term IDs
    const finalTriples = triples.map((t) => {
      const remapped = { ...t }
      if (remapped.subjectId === identityAtomTermId) {
        remapped.subjectId = resolvedIdentityTermId ?? identityAtomTermId
      }
      if (remapped.objectId === metadataAtomTermId) {
        remapped.objectId = resolvedMetadataTermId ?? metadataAtomTermId
      }
      return remapped
    })

    // Execute mode: derive creator atom from wallet if not provided
    if (isResolvedTermId(createdByPredicateTermId) && !isResolvedTermId(creatorTermId)) {
      const creatorAddress = walletClient.account?.address
      if (creatorAddress) {
        let creatorAtomTermId = await getAtomByUri(
          localPublicClient,
          context.contractAddress,
          creatorAddress,
        )
        if (!creatorAtomTermId) {
          const creatorAtomExecution = await createAtoms(
            localPublicClient,
            walletClient,
            context.contractAddress,
            [creatorAddress],
            localMinimumDeposit,
          )
          await localPublicClient.waitForTransactionReceipt({ hash: creatorAtomExecution.hash })
          creatorAtomTermId = await getAtomByUri(
            localPublicClient,
            context.contractAddress,
            creatorAddress,
          )
        }
        if (creatorAtomTermId) {
          finalTriples.push({
            subjectId: resolvedIdentityTermId ?? identityAtomTermId,
            predicateId: createdByPredicateTermId,
            objectId: creatorAtomTermId,
          })
        }
      }
    }

    if (finalTriples.length > 0) {
      tripleExecution = await createTriples(
        localPublicClient,
        walletClient,
        context.contractAddress,
        finalTriples,
        localMinimumDeposit,
      )
      await localPublicClient.waitForTransactionReceipt({ hash: tripleExecution.hash })
    }

    const finalIdentityTermId = resolvedIdentityTermId ?? identityAtomTermId
    storeLocalAgent({
      id: finalIdentityTermId,
      metadata: {
        name: agentMetadata.name,
        description: agentMetadata.description,
        image: agentMetadata.image,
        version: agentMetadata.version,
        model: agentMetadata.model,
        endpoint: agentMetadata.endpoint,
        provider: agentMetadata.provider,
        tags: agentMetadata.capabilities, // Note: capabilities from v3 schema maps to tags in legacy type
        metadataUri: metadataIpfsUri,
        createdAt: new Date().toISOString(),
      },
    })

    return jsonResponse({
      ...response,
      identityAtomTermId: finalIdentityTermId,
      metadataAtomTermId: resolvedMetadataTermId ?? metadataAtomTermId,
      execution: {
        mode: 'local',
        executed: true,
        account: walletClient.account?.address ?? null,
        atomTxHash: atomExecution?.hash ?? null,
        identityAlreadyExisted: Boolean(existingIdentityTermId),
        metadataAlreadyExisted: Boolean(existingMetadataTermId),
        existingIdentityTermId,
        existingMetadataTermId,
        resolvedIdentityTermId,
        resolvedMetadataTermId,
        tripleTxHash: tripleExecution?.hash ?? null,
      },
    })
  } catch (error) {
    if (error instanceof RemoteWriteGuardError) {
      return errorResponse(
        'Remote writes are blocked by default in local-safe mode',
        error.code,
        403,
        {
          message: error.message,
          requiredOverride: 'ALLOW_REMOTE_WRITES=1 and REGISTRY_WRITE_PROFILE=shared',
          profile: error.profile,
          target: error.target,
          action: error.action,
        }
      )
    }
    if (error instanceof IpfsUploadError) {
      if (error.category === 'validation') {
        return errorResponse('Metadata validation failed', 'VALIDATION_ERROR', 400, {
          category: error.category,
          message: error.message,
        })
      }
      if (error.category === 'upstream') {
        return errorResponse('IPFS upstream failure', 'UPSTREAM_IPFS_ERROR', 502, {
          category: error.category,
          message: error.message,
        })
      }
      return errorResponse('IPFS internal failure', 'INTERNAL_IPFS_ERROR', 500, {
        category: error.category,
        message: error.message,
      })
    }
    return errorResponse('Registration preparation failed', 'INTERNAL_ERROR', 500, {
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
}
