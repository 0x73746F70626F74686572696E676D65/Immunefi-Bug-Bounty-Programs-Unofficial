import { useAccount, useDisconnect } from 'wagmi'
import { ConnectButton } from '@rainbow-me/rainbowkit'
import { Wallet, LogOut, ChevronDown } from 'lucide-react'

/**
 * Wallet connection button with custom styling.
 * Shows connect button when not connected, account info when connected.
 */
export function WalletButton() {
  return (
    <ConnectButton.Custom>
      {({ account, chain, openAccountModal, openChainModal, openConnectModal, mounted }) => {
        const ready = mounted
        const connected = ready && account && chain

        return (
          <div
            {...(!ready && {
              'aria-hidden': true,
              style: {
                opacity: 0,
                pointerEvents: 'none',
                userSelect: 'none',
              },
            })}
            className="flex items-center gap-2"
          >
            {connected ? (
              <div className="flex flex-col gap-2">
                {/* Chain indicator */}
                <button
                  onClick={openChainModal}
                  className="flex items-center justify-between gap-1 rounded-md border border-border bg-background px-2 py-1.5 text-xs hover:bg-muted w-full"
                >
                  <span className="truncate">{chain?.name}</span>
                  <ChevronDown className="h-3 w-3 flex-shrink-0" />
                </button>

                {/* Account button */}
                <button
                  onClick={openAccountModal}
                  className="flex items-center gap-2 rounded-md border border-border bg-background px-3 py-1.5 text-xs hover:bg-muted w-full"
                >
                  <span className="font-mono truncate">
                    {account?.displayName}
                  </span>
                </button>

                {account?.displayBalance && (
                  <div className="font-mono text-[10px] text-muted-foreground text-center">
                    {account.displayBalance}
                  </div>
                )}

                {/* Disconnect button */}
                <DisconnectButton />
              </div>
            ) : (
              <button
                onClick={openConnectModal}
                className="flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
              >
                <Wallet className="h-4 w-4" />
                Connect Wallet
              </button>
            )}
          </div>
        )
      }}
    </ConnectButton.Custom>
  )
}

/**
 * Disconnect button component.
 */
function DisconnectButton() {
  const { disconnect } = useDisconnect()

  return (
    <button
      onClick={() => disconnect()}
      className="flex items-center justify-center gap-2 rounded-md border border-border bg-background px-2 py-1.5 text-xs hover:bg-muted w-full"
      title="Disconnect wallet"
    >
      <LogOut className="h-3 w-3" />
      <span className="font-mono">Disconnect</span>
    </button>
  )
}

/**
 * Hook to get current wallet address.
 * Returns null if not connected.
 */
export function useWalletAddress(): string | null {
  const { address, isConnected } = useAccount()
  return isConnected && address ? address : null
}

/**
 * Hook to check if wallet is connected.
 */
export function useIsWalletConnected(): boolean {
  const { isConnected } = useAccount()
  return isConnected
}
