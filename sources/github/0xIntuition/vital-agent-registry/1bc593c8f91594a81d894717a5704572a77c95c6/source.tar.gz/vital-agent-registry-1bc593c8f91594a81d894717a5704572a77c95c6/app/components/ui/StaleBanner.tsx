import { useState } from 'react'

interface StaleBannerProps {
  chainHead: number
  indexerHead: number
  threshold?: number // default: 10
}

/**
 * StaleBanner — non-blocking banner shown when indexer lags behind chain
 *
 * Calculates lag as `chainHead - indexerHead`. Only renders if lag > threshold.
 * User can dismiss for the session (component tracks dismiss state internally).
 *
 * Position: sticky top with low z-index to avoid blocking interactive elements.
 */
export function StaleBanner({ chainHead, indexerHead, threshold = 10 }: StaleBannerProps) {
  const [isDismissed, setIsDismissed] = useState(false)

  const lag = chainHead - indexerHead

  // Don't show if lag is within threshold or user dismissed
  if (lag <= threshold || isDismissed) {
    return null
  }

  return (
    <div
      role="alert"
      className="sticky top-0 z-10 bg-amber-50 border-b border-amber-200 px-4 py-3 flex items-center justify-between gap-4"
    >
      <div className="flex items-center gap-2 flex-1 min-w-0">
        <svg
          className="w-5 h-5 text-amber-600 flex-shrink-0"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={2}
          aria-hidden="true"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
          />
        </svg>
        <p className="text-sm text-amber-900">
          Data may be outdated. The indexer is <strong>{lag} blocks</strong> behind.
        </p>
      </div>

      <button
        onClick={() => setIsDismissed(true)}
        className="flex-shrink-0 text-amber-700 hover:text-amber-900 hover:bg-amber-100 p-1 rounded transition-colors"
        aria-label="Dismiss banner"
      >
        <svg
          className="w-5 h-5"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={2}
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M6 18L18 6M6 6l12 12"
          />
        </svg>
      </button>
    </div>
  )
}
