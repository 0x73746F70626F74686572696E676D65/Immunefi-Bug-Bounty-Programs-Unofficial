import { Link } from 'react-router'
import type { Skill } from '~/types'
import { cn } from '~/lib/utils'
import { formatCompact } from '~/lib/formatting'
import { computeSkillScores, getScoreBadgeClasses } from '~/lib/skill-scores'
import { Card, CardHeader, CardContent, CardFooter } from '~/components/ui/card'
import { SafetyStatusBadge } from './SafetyStatusBadge'
import { PlatformBadge } from './PlatformBadge'
import { Badge } from '~/components/ui/Badge'
import { SaveButton } from '~/components/ui/SaveButton'
import { useCardVariant } from '~/lib/hooks/useCardVariant'
import { useSkillCardStyle } from '~/lib/hooks/useSkillCardStyle'

interface SkillCardProps {
  skill: Skill
  className?: string
}

export function SkillCard({ skill, className }: SkillCardProps) {
  const { variant } = useCardVariant()
  const { style } = useSkillCardStyle()
  const { metadata, safetySignal } = skill
  const isFlagged = safetySignal.status === 'flagged'

  // Compact variant is the same across all styles
  if (variant === 'compact') {
    return (
      <Link
        to={`/skills/${skill.id}`}
        className={cn(
          'block focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-2 focus-visible:outline-none rounded-[var(--radius-badge)]',
          className,
        )}
      >
        <div
          className={cn(
            'flex items-center gap-3 rounded-xl border border-app-line bg-app-box px-3 py-2 shadow-[var(--shadow-card)] transition-all hover:bg-app-box-light hover:shadow-[var(--shadow-card-hover)]',
            isFlagged && 'border-l-2 border-l-[hsl(0_84%_60%)]',
          )}
        >
          <SkillAvatar image={metadata.image} name={metadata.name} size="sm" />
          <span className="min-w-0 flex-1 truncate text-sm font-medium text-card-foreground">
            {metadata.name}
          </span>
          {style === 'score' ? (
            <ScoreChip score={computeSkillScores(skill).composite} label="Score" />
          ) : (
            <SafetyStatusBadge status={safetySignal.status} flagReason={safetySignal.flagReason} size="sm" />
          )}
          <span className="text-xs text-muted-foreground">{skill.trustSignal.totalStaked} TRUST</span>
        </div>
      </Link>
    )
  }

  // Route to the correct style renderer
  if (style === 'score') {
    return <SkillCardScore skill={skill} variant={variant} className={className} />
  }
  if (style === 'adoption') {
    return <SkillCardAdoption skill={skill} variant={variant} className={className} />
  }
  return <SkillCardClaim skill={skill} variant={variant} className={className} />
}

// ─── Shared sub-components ───────────────────────────────────────────────────

function SkillAvatar({ image, name, size = 'md' }: { image?: string; name: string; size?: 'sm' | 'md' }) {
  const fallback = name.charAt(0).toUpperCase()
  const dims = size === 'sm' ? 'h-6 w-6' : 'h-10 w-10'
  const textSize = size === 'sm' ? 'text-xs' : 'text-sm'

  if (image) {
    return (
      <img
        src={image}
        alt={name}
        width={size === 'sm' ? 24 : 40}
        height={size === 'sm' ? 24 : 40}
        className={cn(dims, 'flex-shrink-0 rounded-full object-cover')}
      />
    )
  }

  return (
    <div className={cn(dims, textSize, 'flex flex-shrink-0 items-center justify-center rounded-full bg-muted font-bold text-muted-foreground')}>
      {fallback}
    </div>
  )
}

function ScoreChip({ score, label }: { score: number; label: string }) {
  const classes = getScoreBadgeClasses(score)
  return (
    <span className={cn('inline-flex items-center gap-1 rounded-[var(--radius-badge)] border px-2 py-0.5 text-[10px] font-medium', classes)}>
      <span>{label}</span>
      <span className="font-bold">{score}</span>
    </span>
  )
}

// ─── Style: Claim (current FOR/AGAINST design) ──────────────────────────────

function SkillCardClaim({ skill, variant, className }: { skill: Skill; variant: string; className?: string }) {
  const { metadata, platform, capabilities, safetySignal } = skill
  const isFlagged = safetySignal.status === 'flagged'
  const safetyRatio = safetySignal.safetyRatio

  return (
    <Link
      to={`/skills/${skill.id}`}
      className={cn(
        'block focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-2 focus-visible:outline-none rounded-[var(--radius-card)]',
        className,
      )}
    >
      <Card
        className={cn(
          'relative flex h-full flex-col transition-all hover:bg-app-box-light hover:shadow-[var(--shadow-card-hover)]',
          isFlagged && 'border-l-2 border-l-[hsl(0_84%_60%)]',
        )}
      >
        <SaveButton entityId={skill.id} entityType="skill" className="absolute top-3 right-3 z-10" />
        <CardHeader className="flex flex-row items-center gap-3 space-y-0">
          <SkillAvatar image={metadata.image} name={metadata.name} />
          <div className="min-w-0 flex-1 overflow-hidden">
            <div className="flex items-center justify-between gap-2">
              <div className="truncate font-semibold leading-none text-card-foreground">
                {metadata.name}
              </div>
              <SafetyStatusBadge
                status={safetySignal.status}
                flagReason={safetySignal.flagReason}
                size="sm"
              />
            </div>
            <div className="mt-1.5">
              <PlatformBadge platform={platform} size="sm" />
            </div>
          </div>
        </CardHeader>

        <CardContent className="flex flex-1 flex-col gap-3">
          <p className="line-clamp-2 text-sm text-muted-foreground">
            {metadata.description}
          </p>

          {capabilities.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {capabilities.map(cap => (
                <Badge key={cap.id} label={cap.name} />
              ))}
            </div>
          )}

          {/* FOR/AGAINST safety signal */}
          <div className="flex items-center gap-3 text-xs">
            <span className="text-[hsl(142_71%_45%)]">
              FOR: {safetySignal.forCount} ({safetySignal.forStake} TRUST)
            </span>
            <span className="text-muted-foreground">&middot;</span>
            <span className="text-[hsl(0_84%_60%)]">
              AGAINST: {safetySignal.againstCount} ({safetySignal.againstStake} TRUST)
            </span>
          </div>

          {/* Safety ratio bar */}
          <div className="flex items-center gap-2">
            <div className="h-1 flex-1 overflow-hidden rounded-full bg-[hsl(0_84%_60%)]">
              <div
                className="h-full bg-[hsl(142_71%_45%)]"
                style={{ width: `${safetyRatio * 100}%` }}
              />
            </div>
            <span className="font-mono text-xs text-muted-foreground">
              {safetyRatio.toFixed(2)}
            </span>
          </div>

          {/* Detailed variant: extra metrics */}
          {variant === 'detailed' && (
            <div className="flex items-center gap-3 text-xs text-muted-foreground border-t border-border pt-2">
              <span>Permissions: {metadata.permissions.length}</span>
              {metadata.author && (
                <>
                  <span>&middot;</span>
                  <span>by {metadata.author}</span>
                </>
              )}
            </div>
          )}
        </CardContent>

        <CardFooter className="text-xs text-muted-foreground">
          <span>{formatCompact(skill.trustSignal.stakerCount)} stakers</span>
          <span className="mx-2">&middot;</span>
          <span>{skill.trustSignal.totalStaked} TRUST</span>
        </CardFooter>
      </Card>
    </Link>
  )
}

// ─── Style: Score (computed category scores) ─────────────────────────────────

function SkillCardScore({ skill, variant, className }: { skill: Skill; variant: string; className?: string }) {
  const { metadata, platform, capabilities } = skill
  const isFlagged = skill.safetySignal.status === 'flagged'
  const scores = computeSkillScores(skill)

  return (
    <Link
      to={`/skills/${skill.id}`}
      className={cn(
        'block focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-2 focus-visible:outline-none rounded-[var(--radius-card)]',
        className,
      )}
    >
      <Card
        className={cn(
          'relative flex h-full flex-col transition-all hover:bg-app-box-light hover:shadow-[var(--shadow-card-hover)]',
          isFlagged && 'border-l-2 border-l-[hsl(0_84%_60%)]',
        )}
      >
        <SaveButton entityId={skill.id} entityType="skill" className="absolute top-3 right-3 z-10" />
        <CardHeader className="flex flex-row items-center gap-3 space-y-0">
          <SkillAvatar image={metadata.image} name={metadata.name} />
          <div className="min-w-0 flex-1 overflow-hidden">
            <div className="truncate font-semibold leading-none text-card-foreground">
              {metadata.name}
            </div>
            <div className="mt-1.5">
              <PlatformBadge platform={platform} size="sm" />
            </div>
          </div>
        </CardHeader>

        <CardContent className="flex flex-1 flex-col gap-3">
          {/* Category score badges */}
          <div className="flex flex-wrap gap-1.5">
            <ScoreChip score={scores.safety} label="Safety" />
            <ScoreChip score={scores.trust} label="Trust" />
            <ScoreChip score={scores.adoption} label="Adoption" />
          </div>

          <p className="line-clamp-2 text-sm text-muted-foreground">
            {metadata.description}
          </p>

          {capabilities.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {capabilities.slice(0, 3).map(cap => (
                <Badge key={cap.id} label={cap.name} />
              ))}
              {capabilities.length > 3 && (
                <Badge label={`+${capabilities.length - 3} more`} variant="secondary" />
              )}
            </div>
          )}

          {/* Detailed variant: full score breakdown */}
          {variant === 'detailed' && (
            <div className="border-t border-border pt-2 space-y-1.5">
              <ScoreBar label="Safety" score={scores.safety} />
              <ScoreBar label="Trust" score={scores.trust} />
              <ScoreBar label="Adoption" score={scores.adoption} />
              <div className="flex items-center justify-between text-xs text-muted-foreground pt-1">
                <span>Composite</span>
                <span className="font-mono font-bold">{scores.composite}</span>
              </div>
            </div>
          )}
        </CardContent>

        <CardFooter className="text-xs text-muted-foreground">
          <span>{formatCompact(skill.trustSignal.stakerCount)} stakers</span>
          <span className="mx-2">&middot;</span>
          <span>{skill.trustSignal.totalStaked} TRUST</span>
        </CardFooter>
      </Card>
    </Link>
  )
}

function ScoreBar({ label, score }: { label: string; score: number }) {
  const classes = getScoreBadgeClasses(score)
  const barColor = score >= 80
    ? 'bg-[hsl(142_71%_45%)]'
    : score >= 60
      ? 'bg-[hsl(38_92%_50%)]'
      : 'bg-[hsl(0_84%_60%)]'

  return (
    <div className="flex items-center gap-2">
      <span className="w-16 text-xs text-muted-foreground">{label}</span>
      <div className="h-1 flex-1 overflow-hidden rounded-full bg-app-box-light">
        <div className={cn('h-full rounded-full', barColor)} style={{ width: `${score}%` }} />
      </div>
      <span className={cn('font-mono text-[10px] font-bold w-6 text-right', classes.split(' ').pop())}>
        {score}
      </span>
    </div>
  )
}

// ─── Style: Adoption (usage metrics focus) ───────────────────────────────────

function SkillCardAdoption({ skill, variant, className }: { skill: Skill; variant: string; className?: string }) {
  const { metadata, platform, capabilities, trustSignal, safetySignal } = skill
  const isFlagged = safetySignal.status === 'flagged'
  const totalEth = parseFloat(trustSignal.totalStaked)

  // Adoption level label
  const adoptionLabel = trustSignal.stakerCount >= 100
    ? 'Widely Used'
    : trustSignal.stakerCount >= 50
      ? 'Popular'
      : trustSignal.stakerCount >= 20
        ? 'Growing'
        : 'Emerging'

  return (
    <Link
      to={`/skills/${skill.id}`}
      className={cn(
        'block focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-2 focus-visible:outline-none rounded-[var(--radius-card)]',
        className,
      )}
    >
      <Card
        className={cn(
          'relative flex h-full flex-col transition-all hover:bg-app-box-light hover:shadow-[var(--shadow-card-hover)]',
          isFlagged && 'border-l-2 border-l-[hsl(0_84%_60%)]',
        )}
      >
        <SaveButton entityId={skill.id} entityType="skill" className="absolute top-3 right-3 z-10" />
        <CardHeader className="flex flex-row items-center gap-3 space-y-0">
          <SkillAvatar image={metadata.image} name={metadata.name} />
          <div className="min-w-0 flex-1 overflow-hidden">
            <div className="flex items-center justify-between gap-2">
              <div className="truncate font-semibold leading-none text-card-foreground">
                {metadata.name}
              </div>
              <SafetyStatusBadge status={safetySignal.status} flagReason={safetySignal.flagReason} size="sm" />
            </div>
            <div className="mt-1.5 flex items-center gap-2">
              <PlatformBadge platform={platform} size="sm" />
              <Badge variant="secondary" label={adoptionLabel} />
            </div>
          </div>
        </CardHeader>

        <CardContent className="flex flex-1 flex-col gap-3">
          {/* Key metrics row */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="rounded-lg bg-app-box-light px-2 py-1.5">
              <div className="text-lg font-bold text-card-foreground leading-none">
                {formatCompact(trustSignal.stakerCount)}
              </div>
              <div className="text-[10px] text-muted-foreground mt-0.5">Stakers</div>
            </div>
            <div className="rounded-lg bg-app-box-light px-2 py-1.5">
              <div className="text-lg font-bold text-card-foreground leading-none">
                {totalEth < 1 ? totalEth.toFixed(2) : formatCompact(Math.round(totalEth))}
              </div>
              <div className="text-[10px] text-muted-foreground mt-0.5">TRUST</div>
            </div>
            <div className="rounded-lg bg-app-box-light px-2 py-1.5">
              <div className="text-lg font-bold text-card-foreground leading-none">
                {capabilities.length}
              </div>
              <div className="text-[10px] text-muted-foreground mt-0.5">Skills</div>
            </div>
          </div>

          <p className="line-clamp-2 text-sm text-muted-foreground">
            {metadata.description}
          </p>

          {capabilities.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {capabilities.slice(0, 4).map(cap => (
                <Badge key={cap.id} label={cap.name} />
              ))}
              {capabilities.length > 4 && (
                <Badge label={`+${capabilities.length - 4}`} variant="secondary" />
              )}
            </div>
          )}

          {/* Detailed variant: extra info */}
          {variant === 'detailed' && (
            <div className="flex items-center gap-3 text-xs text-muted-foreground border-t border-border pt-2">
              <span>v{metadata.version}</span>
              {metadata.author && (
                <>
                  <span>&middot;</span>
                  <span>by {metadata.author}</span>
                </>
              )}
              <span>&middot;</span>
              <span>{metadata.permissions.length} perms</span>
            </div>
          )}
        </CardContent>

        <CardFooter className="text-xs text-muted-foreground">
          <span>Share price: {trustSignal.sharePrice} TRUST</span>
          <span className="mx-2">&middot;</span>
          <span>Tier: {trustSignal.tier}</span>
        </CardFooter>
      </Card>
    </Link>
  )
}
