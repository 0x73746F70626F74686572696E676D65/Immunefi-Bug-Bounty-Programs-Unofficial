import type { LoaderFunctionArgs } from 'react-router'
import { corsHeaders } from '~/lib/api/types'

/**
 * GET /api/v1/health
 *
 * Basic health check endpoint for monitoring and deployment verification.
 */
export async function loader(_args: LoaderFunctionArgs) {
  const checks: Record<string, { status: string; detail?: string }> = {
    server: { status: 'ok' },
  }

  // Check GraphQL connectivity if configured
  const graphqlUrl = process.env.GRAPHQL_API_URL_PRIVATE
  if (graphqlUrl) {
    try {
      const res = await fetch(graphqlUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: '{ __typename }' }),
        signal: AbortSignal.timeout(3000),
      })
      checks.graphql = res.ok
        ? { status: 'ok' }
        : { status: 'degraded', detail: `HTTP ${res.status}` }
    } catch (e) {
      checks.graphql = { status: 'down', detail: e instanceof Error ? e.message : 'unreachable' }
    }
  } else {
    checks.graphql = { status: 'unconfigured' }
  }

  // Check IPFS (Pinata) connectivity
  const pinataJwt = process.env.PINATA_JWT
  if (pinataJwt) {
    try {
      const res = await fetch('https://api.pinata.cloud/data/testAuthentication', {
        headers: { Authorization: `Bearer ${pinataJwt}` },
        signal: AbortSignal.timeout(3000),
      })
      checks.ipfs = res.ok
        ? { status: 'ok' }
        : { status: 'degraded', detail: `HTTP ${res.status}` }
    } catch (e) {
      checks.ipfs = { status: 'down', detail: e instanceof Error ? e.message : 'unreachable' }
    }
  } else {
    checks.ipfs = { status: 'unconfigured' }
  }

  const allOk = Object.values(checks).every((c) => c.status === 'ok' || c.status === 'unconfigured')
  const status = allOk ? 'healthy' : 'degraded'

  return new Response(
    JSON.stringify({
      status,
      chain: process.env.CHAIN ?? 'unknown',
      env: process.env.DEPLOY_ENV ?? 'unknown',
      checks,
      timestamp: new Date().toISOString(),
    }),
    {
      status: allOk ? 200 : 503,
      headers: {
        ...corsHeaders(),
        'Content-Type': 'application/json',
        'Cache-Control': 'no-store',
      },
    }
  )
}
