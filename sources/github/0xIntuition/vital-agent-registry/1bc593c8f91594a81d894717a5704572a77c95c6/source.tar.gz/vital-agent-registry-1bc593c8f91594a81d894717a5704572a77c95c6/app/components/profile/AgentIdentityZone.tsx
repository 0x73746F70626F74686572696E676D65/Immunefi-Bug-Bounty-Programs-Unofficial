import { useState } from 'react'
import { ExternalLink } from 'lucide-react'
import type { Agent } from '~/types'
import { cn } from '~/lib/utils'
import { Badge } from '~/components/ui/Badge'
import { useIPFSFallback } from '~/lib/hooks/useIPFSFallback'
import { EntityStakeInline } from '~/components/staking/EntityStakeInline'

interface AgentIdentityZoneProps {
  agent: Agent
  className?: string
}

export function AgentIdentityZone({ agent, className }: AgentIdentityZoneProps) {
  const { metadata, agentCard, erc8004 } = agent
  const { data: resolvedMetadata } = useIPFSFallback(
    metadata.metadataUri,
    metadata,
    { timeoutMs: 3000 },
  )
  const activeMetadata = resolvedMetadata ?? metadata

  // Show more/less for long descriptions
  const [showFullDescription, setShowFullDescription] = useState(false)
  const shouldTruncateDescription = activeMetadata.description.length > 200

  return (
    <div
      className={cn(
        'rounded-[var(--radius-card)] border border-border bg-card shadow-[var(--shadow-card)] p-4',
        className,
      )}
    >
      {/* Provider + Standards */}
      {(activeMetadata.provider?.name || agentCard || erc8004) && (
        <div className="mb-4">
          {activeMetadata.provider?.name && (
            <p className="font-mono text-xs text-muted-foreground mb-2">
              by {activeMetadata.provider.name}
              {activeMetadata.provider.url && (
                <>
                  {' · '}
                  <a
                    href={activeMetadata.provider.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 hover:underline"
                  >
                    website
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </>
              )}
            </p>
          )}
          <div className="flex flex-wrap gap-2">
            {agentCard && (
              <Badge label="A2A Agent Card" color="hsl(142 71% 45%)" />
            )}
            {erc8004 && (
              <Badge label="ERC-8004" color="hsl(280 83% 58%)" />
            )}
          </div>
        </div>
      )}

      {/* Description */}
      <div className="mb-4">
        <p className={cn(
          'text-sm text-muted-foreground',
          shouldTruncateDescription && !showFullDescription && 'line-clamp-3',
        )}>
          {activeMetadata.description}
        </p>
        {shouldTruncateDescription && (
          <button
            onClick={() => setShowFullDescription(!showFullDescription)}
            className="text-sm text-brand hover:underline mt-1"
          >
            {showFullDescription ? 'Show less' : 'Show more'}
          </button>
        )}
      </div>

      {/* Details grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-xs">
        {activeMetadata.model && (
            <div>
              <span className="uppercase tracking-widest text-ink-faint">Model</span>{' '}
              <span className="text-card-foreground font-medium">{activeMetadata.model}</span>
            </div>
          )}

        {activeMetadata.endpoint && (
          <div>
            <span className="uppercase tracking-widest text-ink-faint">Endpoint</span>{' '}
            <a
              href={activeMetadata.endpoint}
              target="_blank"
              rel="noopener noreferrer"
              className="text-brand hover:underline inline-flex items-center gap-1"
            >
              {activeMetadata.endpoint}
              <ExternalLink className="h-3 w-3" />
            </a>
          </div>
        )}

        <div>
          <span className="uppercase tracking-widest text-ink-faint">Created</span>{' '}
          <span className="text-card-foreground font-medium">
            {new Date(activeMetadata.createdAt).toLocaleDateString()}
          </span>
        </div>

        {activeMetadata.lastActiveAt && (
          <div>
            <span className="uppercase tracking-widest text-ink-faint">Last Active</span>{' '}
            <span className="text-card-foreground font-medium">
              {new Date(activeMetadata.lastActiveAt).toLocaleDateString()}
            </span>
          </div>
        )}
      </div>

      {/* Tags */}
      {activeMetadata.tags && activeMetadata.tags.length > 0 && (
        <div className="mt-4">
          <span className="font-mono text-[10px] tracking-widest uppercase text-ink-faint mb-2 block">Tags</span>
          <div className="flex flex-wrap gap-1.5">
            {activeMetadata.tags.map(tag => (
              <Badge key={tag} label={tag} className="font-mono text-[10px] tracking-wider" />
            ))}
          </div>
        </div>
      )}

      {/* Entity-level staking */}
      <EntityStakeInline termId={agent.id} label={activeMetadata.name} />
    </div>
  )
}
