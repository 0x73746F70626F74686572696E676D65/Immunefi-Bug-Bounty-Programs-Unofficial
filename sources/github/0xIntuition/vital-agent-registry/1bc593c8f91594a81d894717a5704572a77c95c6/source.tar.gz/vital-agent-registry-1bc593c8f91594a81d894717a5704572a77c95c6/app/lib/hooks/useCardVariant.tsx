import { createContext, useContext, useState, useCallback } from 'react'
import type { ReactNode } from 'react'

export type CardVariant = 'default' | 'compact' | 'detailed'

interface CardVariantContextValue {
  variant: CardVariant
  setVariant: (variant: CardVariant) => void
  cycleVariant: () => void
}

const CardVariantContext = createContext<CardVariantContextValue | null>(null)

const STORAGE_KEY = 'agent-registry-card-variant'
const DEFAULT_VARIANT: CardVariant = 'default'

const CYCLE_ORDER: CardVariant[] = ['default', 'compact', 'detailed']

function getInitialVariant(): CardVariant {
  if (typeof window === 'undefined') return DEFAULT_VARIANT
  const stored = localStorage.getItem(STORAGE_KEY)
  if (stored === 'default' || stored === 'compact' || stored === 'detailed') {
    return stored
  }
  return DEFAULT_VARIANT
}

export function CardVariantProvider({ children }: { children: ReactNode }) {
  const [variant, setVariantState] = useState<CardVariant>(getInitialVariant)

  const setVariant = useCallback((next: CardVariant) => {
    setVariantState(next)
    localStorage.setItem(STORAGE_KEY, next)
  }, [])

  const cycleVariant = useCallback(() => {
    setVariantState((prev) => {
      const idx = CYCLE_ORDER.indexOf(prev)
      const next = CYCLE_ORDER[(idx + 1) % CYCLE_ORDER.length]
      localStorage.setItem(STORAGE_KEY, next)
      return next
    })
  }, [])

  return (
    <CardVariantContext.Provider value={{ variant, setVariant, cycleVariant }}>
      {children}
    </CardVariantContext.Provider>
  )
}

export function useCardVariant() {
  const ctx = useContext(CardVariantContext)
  if (!ctx) throw new Error('useCardVariant must be used within CardVariantProvider')
  return ctx
}
