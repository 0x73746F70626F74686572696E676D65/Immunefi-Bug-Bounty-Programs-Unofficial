export const GET_TRIPLES_FOR_ATOM = `
  query GetTriplesForAtom(
    $subjectId: String!
    $limit: Int
    $offset: Int
  ) {
    triples(
      where: { subject_id: { _eq: $subjectId } }
      limit: $limit
      offset: $offset
      order_by: [{ created_at: desc }]
    ) {
      term_id
      counter_term_id
      created_at
      subject {
        term_id
        label
        image
        cached_image { url safe }
        type
      }
      predicate {
        term_id
        label
        image
        cached_image { url safe }
        type
      }
      object {
        term_id
        label
        image
        cached_image { url safe }
        type
        data
        value {
          person { name image url }
          thing { name image url }
          organization { name image url }
          json_object {
            description: data(path: "description")
          }
        }
      }
      term {
        total_market_cap
        positions_aggregate {
          aggregate { count }
        }
        vaults(order_by: { curve_id: asc }) {
          term_id
          curve_id
          current_share_price
          total_shares
          total_assets
          position_count
          market_cap
        }
      }
      creator {
        id
        label
        image
        cached_image { url safe }
      }
    }
  }
`

export const GET_TRIPLES_ABOUT_ATOM = `
  query GetTriplesAboutAtom(
    $objectId: String!
    $limit: Int
    $offset: Int
  ) {
    triples(
      where: { object_id: { _eq: $objectId } }
      limit: $limit
      offset: $offset
      order_by: [{ created_at: desc }]
    ) {
      term_id
      counter_term_id
      created_at
      subject {
        term_id
        label
        image
        cached_image { url safe }
        type
      }
      predicate {
        term_id
        label
        image
        cached_image { url safe }
        type
      }
      object {
        term_id
        label
        image
        cached_image { url safe }
        type
      }
      term {
        total_market_cap
        positions_aggregate {
          aggregate { count }
        }
        vaults(order_by: { curve_id: asc }) {
          term_id
          curve_id
          total_assets
          position_count
          market_cap
        }
      }
      creator {
        id
        label
        image
      }
    }
  }
`
