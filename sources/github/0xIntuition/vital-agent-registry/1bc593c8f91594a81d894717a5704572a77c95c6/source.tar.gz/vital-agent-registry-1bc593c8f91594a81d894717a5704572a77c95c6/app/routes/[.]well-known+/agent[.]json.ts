import type { LoaderFunctionArgs } from 'react-router'
import { createRepository } from '~/data/repository/provider'
import { corsHeaders } from '~/lib/api/types'
import type { AgentCard } from '~/types'

/**
 * /.well-known/agent.json — A2A v0.3 Agent Discovery Endpoint
 *
 * Returns the registry's own Agent Card by default.
 * Optional ?id=<termId> param returns a specific agent's card.
 */
export async function loader({ request }: LoaderFunctionArgs) {
  try {
    const url = new URL(request.url)
    const origin = process.env.ORIGIN_URL || url.origin
    const id = url.searchParams.get('id')

    // If id provided, delegate to repository
    if (id) {
      const repo = createRepository()
      const card = await repo.getAgentCard(id)

      if (!card) {
        return new Response(JSON.stringify({ error: 'Agent not found', code: 'NOT_FOUND', id }), {
          status: 404,
          headers: corsHeaders({ 'Content-Type': 'application/json' }),
        })
      }

      return new Response(JSON.stringify(card), {
        status: 200,
        headers: corsHeaders({ 'Content-Type': 'application/json' }),
      })
    }

    // Default: return registry's own agent card
    const registryCard: AgentCard = {
      id: 'intuition-agent-registry',
      name: 'Intuition Agent Registry',
      description:
        'Decentralized registry for AI agents backed by the Intuition protocol trust layer',
      url: origin,
      provider: { name: 'Intuition', url: 'https://intuition.systems' },
      version: '2.0.0',
      capabilities: {
        streaming: false,
        pushNotifications: false,
        extendedAgentCard: true,
      },
      skills: [
        {
          id: 'discover-agents',
          name: 'Discover Agents',
          description:
            'Search and browse registered AI agents by capabilities, trust tier, and metadata',
          inputModes: ['application/json'],
          outputModes: ['application/json'],
        },
        {
          id: 'match-capabilities',
          name: 'Match Capabilities',
          description:
            'Find agents matching required capability sets, ranked by match score and trust',
          inputModes: ['application/json'],
          outputModes: ['application/json'],
        },
        {
          id: 'verify-trust',
          name: 'Verify Trust',
          description: 'Get trust signals and safety status for agents and skills',
          inputModes: ['application/json'],
          outputModes: ['application/json'],
        },
      ],
      securitySchemes: {
        unauthenticated: {
          type: 'http',
          description: 'No additional authentication required for registry discovery endpoints',
        },
      },
      security: [{ unauthenticated: [] }],
      interfaces: [
        {
          protocol: 'http',
          url: origin,
        },
      ],
      defaultInputModes: ['application/json'],
      defaultOutputModes: ['application/json'],
      extensions: [
        {
          uri: 'https://registry.intuition.systems/extensions/intuition',
          atomId: 'intuition-agent-registry',
          vaultTermId: '',
          trustTier: 'platinum',
          registryUrl: origin,
          chainId: 13579,
        },
      ],
    }

    return new Response(JSON.stringify(registryCard), {
      status: 200,
      headers: corsHeaders({ 'Content-Type': 'application/json' }),
    })
  } catch (error) {
    return new Response(
      JSON.stringify({
        error: 'Failed to generate agent card',
        code: 'INTERNAL_ERROR',
        details: {
          message: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
      {
        status: 500,
        headers: corsHeaders({ 'Content-Type': 'application/json' }),
      },
    )
  }
}
