import { describe, expect, it } from 'vitest'
import { resolveLatestMetadataTermId } from '../metadata-history'

describe('metadata-history', () => {
  it('returns null when no revisions exist', () => {
    expect(resolveLatestMetadataTermId([])).toBeNull()
  })

  it('returns latest revision by block then log index', () => {
    const latest = resolveLatestMetadataTermId([
      { metadataTermId: '0x1', blockNumber: 11, logIndex: 2 },
      { metadataTermId: '0x2', blockNumber: 12, logIndex: 1 },
      { metadataTermId: '0x3', blockNumber: 12, logIndex: 3 },
    ])
    expect(latest).toBe('0x3')
  })
})
