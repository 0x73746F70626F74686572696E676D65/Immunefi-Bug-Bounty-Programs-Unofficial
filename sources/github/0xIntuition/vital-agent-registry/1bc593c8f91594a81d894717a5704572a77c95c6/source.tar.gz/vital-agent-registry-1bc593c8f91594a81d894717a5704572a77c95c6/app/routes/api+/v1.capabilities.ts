import type { LoaderFunctionArgs } from 'react-router'
import { createRepository } from '~/data/repository/provider'
import { handleOptions, jsonResponse } from '~/lib/api/types'
import type { Capability } from '~/types'

export async function loader({ request }: LoaderFunctionArgs) {
  const optionsResponse = handleOptions(request)
  if (optionsResponse) return optionsResponse

  const url = new URL(request.url)
  const grouped = url.searchParams.get('grouped') === 'true'

  const repo = createRepository()
  const capabilities = await repo.listCapabilities()

  if (grouped) {
    // Group by category
    const grouped = capabilities.reduce((acc, cap) => {
      if (!acc[cap.category]) {
        acc[cap.category] = []
      }
      acc[cap.category].push(cap)
      return acc
    }, {} as Record<string, Capability[]>)
    return jsonResponse(grouped)
  }

  return jsonResponse(capabilities)
}
