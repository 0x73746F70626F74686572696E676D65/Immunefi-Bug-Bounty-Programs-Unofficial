import { isHex, pad } from 'viem';

/**
 * Type definitions for the MultiVault contract IDs
 */
export type TermId = `0x${string}`;
export type VaultId = TermId;
export type AtomId = TermId;
export type TripleId = TermId;

/**
 * Converts a string ID to bytes32 format.
 * Handles both hex strings and decimal strings.
 *
 * @param str - The ID string to convert (hex or decimal)
 * @returns The bytes32 formatted ID
 *
 * @example
 * ```typescript
 * stringToBytes32("123") // "0x000000000000000000000000000000000000000000000000000000000000007b"
 * stringToBytes32("0x7b") // "0x000000000000000000000000000000000000000000000000000000000000007b"
 * ```
 */
export function stringToBytes32(str: string): TermId {
  if (!str) {
    throw new Error('ID cannot be empty');
  }

  // If it's already a hex string, pad it to 32 bytes
  if (isHex(str)) {
    return pad(str as `0x${string}`) as TermId;
  }

  // If it's a decimal string, convert to hex first
  try {
    const hexValue = `0x${BigInt(str).toString(16)}` as `0x${string}`;
    return pad(hexValue) as TermId;
  } catch {
    // Non-numeric string (e.g. mock data IDs) — encode as utf8 hex bytes, truncate to 32 bytes
    const encoder = new TextEncoder();
    const bytes = encoder.encode(str);
    let hex = '0x';
    // Only take up to 32 bytes
    const maxBytes = Math.min(bytes.length, 32);
    for (let i = 0; i < maxBytes; i++) {
      hex += bytes[i].toString(16).padStart(2, '0');
    }
    return pad(hex as `0x${string}`, { dir: 'right' }) as TermId;
  }
}

/**
 * Converts bytes32 back to a decimal string for display/API calls.
 *
 * @param bytes - The bytes32 formatted ID
 * @returns The decimal string representation
 *
 * @example
 * ```typescript
 * bytes32ToString("0x000000000000000000000000000000000000000000000000000000000000007b") // "123"
 * ```
 */
export function bytes32ToString(bytes: TermId): string {
  if (!bytes || !isHex(bytes)) {
    throw new Error('Invalid bytes32 value');
  }

  return BigInt(bytes).toString();
}

/**
 * Checks if a value is already in bytes32 format.
 *
 * @param value - The value to check
 * @returns True if the value is a bytes32 string
 */
export function isBytes32(value: string): value is TermId {
  return isHex(value) && value.length === 66; // 0x + 64 hex chars
}

/**
 * Converts an array of string IDs to bytes32 format.
 *
 * @param ids - Array of ID strings to convert
 * @returns Array of bytes32 formatted IDs
 */
export function stringArrayToBytes32Array(ids: string[]): TermId[] {
  return ids.map(stringToBytes32);
}

/**
 * Converts an array of bytes32 IDs to string format.
 *
 * @param ids - Array of bytes32 formatted IDs
 * @returns Array of decimal string IDs
 */
export function bytes32ArrayToStringArray(ids: TermId[]): string[] {
  return ids.map(bytes32ToString);
}

/**
 * Safely handles ID conversion - if already bytes32, returns as-is, otherwise converts.
 *
 * @param id - The ID to ensure is bytes32 format
 * @returns The bytes32 formatted ID
 */
export function ensureBytes32(id: string): TermId {
  if (isBytes32(id)) {
    return id as TermId;
  }
  return stringToBytes32(id);
}

/**
 * Safely handles ID conversion to string - if hex, converts to decimal, otherwise returns as-is.
 *
 * @param id - The ID to ensure is string format
 * @returns The decimal string ID
 */
export function ensureString(id: string): string {
  if (isBytes32(id)) {
    return bytes32ToString(id as TermId);
  }
  return id;
}
