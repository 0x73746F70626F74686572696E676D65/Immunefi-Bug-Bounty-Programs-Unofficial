import { createRepository } from '~/data/repository/provider'
import { handleOptions, jsonResponse, errorResponse } from '~/lib/api/types'
import type { LoaderFunctionArgs } from 'react-router'

export async function loader({ params, request }: LoaderFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const repo = createRepository()
  const card = await repo.getAgentCard(params.id!)

  if (!card) {
    return errorResponse('Agent not found or has no A2A card', 'NOT_FOUND', 404)
  }

  return jsonResponse(card)
}
