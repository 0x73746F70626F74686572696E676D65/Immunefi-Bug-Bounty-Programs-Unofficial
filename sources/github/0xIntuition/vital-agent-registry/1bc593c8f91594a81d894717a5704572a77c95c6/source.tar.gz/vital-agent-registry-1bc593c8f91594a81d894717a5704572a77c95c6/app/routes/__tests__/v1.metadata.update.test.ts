import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const mocks = vi.hoisted(() => ({
  uploadAgentMetadata: vi.fn(),
  uploadSkillMetadata: vi.fn(),
  getAtomCost: vi.fn(),
  getTripleCost: vi.fn(),
  encodeCreateAtomCalldata: vi.fn(),
  encodeCreateTriplesCalldata: vi.fn(),
  deriveAtomTermId: vi.fn(),
  createAtoms: vi.fn(),
  createTriples: vi.fn(),
  getAtomByUri: vi.fn(),
  getMinimumDeposit: vi.fn(),
  getLocalWriteContext: vi.fn(),
  createLocalWriteClients: vi.fn(),
  assertRemoteWriteAllowed: vi.fn(),
}))

vi.mock('~/.server/ipfs', async () => {
  const actual = await vi.importActual<typeof import('~/.server/ipfs')>('~/.server/ipfs')
  return {
    ...actual,
    uploadAgentMetadata: mocks.uploadAgentMetadata,
    uploadSkillMetadata: mocks.uploadSkillMetadata,
  }
})

vi.mock('~/.server/multivault', () => ({
  getAtomCost: mocks.getAtomCost,
  getTripleCost: mocks.getTripleCost,
  createAtoms: mocks.createAtoms,
  createTriples: mocks.createTriples,
  getAtomByUri: mocks.getAtomByUri,
  getMinimumDeposit: mocks.getMinimumDeposit,
}))

vi.mock('~/lib/calldata', () => ({
  encodeCreateAtomCalldata: mocks.encodeCreateAtomCalldata,
  encodeCreateTriplesCalldata: mocks.encodeCreateTriplesCalldata,
  deriveAtomTermId: mocks.deriveAtomTermId,
}))

vi.mock('viem', () => ({
  createPublicClient: vi.fn(() => ({})),
  http: vi.fn(() => ({})),
  parseEventLogs: vi.fn(() => []),
}))

vi.mock('~/.server/local-write', () => ({
  createLocalWriteClients: mocks.createLocalWriteClients,
  getLocalWriteContext: mocks.getLocalWriteContext,
}))

vi.mock('~/.server/remote-write-guard', () => ({
  assertRemoteWriteAllowed: mocks.assertRemoteWriteAllowed,
  RemoteWriteGuardError: class RemoteWriteGuardError extends Error {
    code: string
    profile: string
    target: string
    action: string
    constructor(message: string, code: string, profile: string, target: string, action: string) {
      super(message)
      this.code = code
      this.profile = profile
      this.target = target
      this.action = action
    }
  },
}))

vi.mock('~/lib/abis/multivault', () => ({
  multivaultAbi: [],
}))

describe('POST /api/v1/metadata/update', () => {
  const baseEnv = { ...process.env }
  const entityTermId = '0x1111111111111111111111111111111111111111111111111111111111111111'
  const predicateTermId = '0x2222222222222222222222222222222222222222222222222222222222222222'
  const metadataTermId = '0x3333333333333333333333333333333333333333333333333333333333333333'

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = {
      ...baseEnv,
      CHAIN: 'testnet',
      ALLOW_REMOTE_WRITES: '1',
      REGISTRY_WRITE_PROFILE: 'shared',
    }
    mocks.uploadAgentMetadata.mockResolvedValue('ipfs://QmMeta')
    mocks.getAtomCost.mockResolvedValue(10n)
    mocks.getTripleCost.mockResolvedValue(5n)
    mocks.encodeCreateAtomCalldata.mockReturnValue('0xdeadbeef')
    mocks.encodeCreateTriplesCalldata.mockReturnValue('0xbeadfeed')
    mocks.deriveAtomTermId.mockReturnValue(metadataTermId)
  })

  afterEach(() => {
    process.env = { ...baseEnv }
  })

  it('returns two-signature metadata update plan preserving base identity', async () => {
    const { action } = await import('../api+/v1.metadata.update')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/metadata/update', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          entityTermId,
          entityType: 'agent',
          hasMetadataPredicateTermId: predicateTermId,
          metadata: {
            '@type': 'Agent',
            name: 'Updated Agent',
            description: 'Updated',
            version: '1.0.1',
          },
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.baseTermId).toBe(entityTermId)
    expect(body.data.metadataTermId).toBe(metadataTermId)
    expect(body.data.transactions).toHaveLength(2)
    expect(body.data.signaturePlan.requiredSignatures).toBe(2)
  })

  it('fails when has-metadata term id is unresolved', async () => {
    const { action } = await import('../api+/v1.metadata.update')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/metadata/update', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          entityTermId,
          entityType: 'agent',
          hasMetadataPredicateTermId: '0x_placeholder_has_metadata',
          metadata: {
            '@type': 'Agent',
            name: 'Updated Agent',
            description: 'Updated',
            version: '1.0.1',
          },
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(400)
    const body = await response.json()
    expect(body.code).toBe('VALIDATION_ERROR')
  })
})

describe('POST /api/v1/metadata/update?execute=true', () => {
  const baseEnv = { ...process.env }
  const entityTermId = '0x1111111111111111111111111111111111111111111111111111111111111111'
  const predicateTermId = '0x2222222222222222222222222222222222222222222222222222222222222222'
  const metadataTermId = '0x3333333333333333333333333333333333333333333333333333333333333333'
  const resolvedTermId = '0x4444444444444444444444444444444444444444444444444444444444444444'

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = {
      ...baseEnv,
      CHAIN: 'testnet',
      REGISTRY_API_KEY: 'test-key',
    }
    mocks.uploadAgentMetadata.mockResolvedValue('ipfs://QmMeta')
    mocks.getAtomCost.mockResolvedValue(10n)
    mocks.getTripleCost.mockResolvedValue(5n)
    mocks.encodeCreateAtomCalldata.mockReturnValue('0xdeadbeef')
    mocks.encodeCreateTriplesCalldata.mockReturnValue('0xbeadfeed')
    mocks.deriveAtomTermId.mockReturnValue(metadataTermId)
    mocks.createAtoms.mockResolvedValue({ hash: '0xatomhash', atomCount: 1 })
    mocks.createTriples.mockResolvedValue({ hash: '0xtriplehash', tripleCount: 1 })
    mocks.getMinimumDeposit.mockResolvedValue(1n)
    mocks.getAtomByUri.mockResolvedValue(null)

    // Setup local write mocks
    mocks.getLocalWriteContext.mockReturnValue({
      contractAddress: '0xcontract',
      rpcUrl: 'http://localhost:8545',
    })
    mocks.createLocalWriteClients.mockResolvedValue({
      publicClient: {
        waitForTransactionReceipt: vi.fn().mockResolvedValue({
          logs: [],
        }),
      },
      walletClient: {
        account: { address: '0xwalletaddress' },
      },
    })
  })

  afterEach(() => {
    process.env = { ...baseEnv }
  })

  it('creates metadata atom and triple in execute mode', async () => {
    const { action } = await import('../api+/v1.metadata.update')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/metadata/update?execute=true', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': 'test-key' },
        body: JSON.stringify({
          entityTermId,
          entityType: 'agent',
          hasMetadataPredicateTermId: predicateTermId,
          metadata: {
            '@type': 'Agent',
            name: 'Execute Agent',
            description: 'Execute mode test',
            version: '1.0.1',
          },
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.execution).toBeDefined()
    expect(body.data.execution.mode).toBe('local')
    expect(body.data.execution.executed).toBe(true)
    expect(body.data.execution.atomTxHash).toBe('0xatomhash')
    expect(body.data.execution.tripleTxHash).toBe('0xtriplehash')
  })

  it('skips atom creation when metadata atom already exists', async () => {
    mocks.getAtomByUri.mockResolvedValue(resolvedTermId)

    const { action } = await import('../api+/v1.metadata.update')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/metadata/update?execute=true', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': 'test-key' },
        body: JSON.stringify({
          entityTermId,
          entityType: 'agent',
          hasMetadataPredicateTermId: predicateTermId,
          metadata: {
            '@type': 'Agent',
            name: 'Idempotent Agent',
            description: 'Should skip atom creation',
            version: '1.0.1',
          },
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.execution.metadataAlreadyExisted).toBe(true)
    expect(body.data.execution.atomTxHash).toBeNull()
    expect(body.data.execution.tripleTxHash).toBe('0xtriplehash')
    expect(body.data.metadataTermId).toBe(resolvedTermId)
  })

  it('does not call assertRemoteWriteAllowed in execute mode', async () => {
    const { action } = await import('../api+/v1.metadata.update')
    await action({
      request: new Request('http://localhost:4101/api/v1/metadata/update?execute=true', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': 'test-key' },
        body: JSON.stringify({
          entityTermId,
          entityType: 'agent',
          hasMetadataPredicateTermId: predicateTermId,
          metadata: {
            '@type': 'Agent',
            name: 'No Guard Agent',
            description: 'Guard should be skipped',
            version: '1.0.1',
          },
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(mocks.assertRemoteWriteAllowed).not.toHaveBeenCalled()
  })
})
