import { createRegistryPublicClient } from './viem'
import { createLocalWriteClients, getLocalWriteContext } from './local-write'
import type { ReadConfig, WriteConfig } from '@0xintuition/sdk'

/**
 * Creates a ReadConfig for SDK operations that only need chain reads.
 *
 * Uses the local write context (REGISTRY_WRITE_PROFILE=local) to determine
 * contract address and RPC URL, then creates a public client.
 */
export function getReadConfig(env: NodeJS.ProcessEnv = process.env): ReadConfig {
  const context = getLocalWriteContext(env)
  const publicClient = createRegistryPublicClient('local')
  return { address: context.contractAddress, publicClient }
}

/**
 * Creates a WriteConfig for SDK operations that need chain writes.
 *
 * Returns both publicClient and walletClient from local write context.
 * Only works when REGISTRY_WRITE_PROFILE=local.
 */
export async function getWriteConfig(env: NodeJS.ProcessEnv = process.env): Promise<WriteConfig> {
  const context = getLocalWriteContext(env)
  const { publicClient, walletClient } = await createLocalWriteClients(context)
  return { address: context.contractAddress, publicClient, walletClient }
}
