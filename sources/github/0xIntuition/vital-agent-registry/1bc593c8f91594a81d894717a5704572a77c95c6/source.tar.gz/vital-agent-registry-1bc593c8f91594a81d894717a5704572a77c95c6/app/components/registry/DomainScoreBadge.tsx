import { cn } from '~/lib/utils'
import { Badge } from '~/components/ui/Badge'
import type { DomainScore } from '~/types'

interface DomainScoreBadgeProps {
  score: DomainScore
  size?: 'sm' | 'md'
}

function getScoreColors(avgQuality: number): string {
  if (avgQuality >= 80) return 'border-[hsl(142_71%_45%/0.5)] bg-[hsl(142_71%_45%/0.1)] text-[hsl(142_71%_45%)]'
  if (avgQuality >= 60) return 'border-[hsl(38_92%_50%/0.5)] bg-[hsl(38_92%_50%/0.1)] text-[hsl(38_92%_50%)]'
  return 'border-[hsl(0_84%_60%/0.5)] bg-[hsl(0_84%_60%/0.1)] text-[hsl(0_84%_60%)]'
}

export function DomainScoreBadge({ score, size = 'sm' }: DomainScoreBadgeProps) {
  const colorClass = getScoreColors(score.avgQuality)

  return (
    <Badge
      variant="outline"
      className={cn(
        'gap-1',
        colorClass,
        size === 'sm' ? 'text-[10px]' : 'text-xs',
      )}
    >
      <span>{score.domain}</span>
      <span className="font-bold">{score.avgQuality}</span>
    </Badge>
  )
}
