import { concat, encodeFunctionData, keccak256, pad, toHex } from 'viem'

/**
 * Salt used by the MultiVault v2 contract for atom ID derivation.
 * Matches: `bytes32 public constant ATOM_SALT = keccak256("ATOM_SALT");`
 */
const ATOM_SALT = keccak256(toHex('ATOM_SALT'))
import { multivaultAbi } from '~/lib/abis/multivault'

export interface TripleCalldataInput {
  subjectId: string
  predicateId: string
  objectId: string
}

function toBytes32TermId(value: string): `0x${string}` {
  return pad(value as `0x${string}`) as `0x${string}`
}

/**
 * Encodes identity atom data for the v3 pattern.
 *
 * The identity atom contains minimal data to serve as the permanent
 * anchor for an entity, with full metadata stored separately.
 *
 * @param name - The entity name (kebab-case recommended)
 * @param namespace - The namespace (e.g., "intuition-agent", "intuition-skill")
 * @returns JSON string of the identity data
 *
 * @example
 * ```typescript
 * const identityData = encodeIdentityAtomData("code-reviewer", "intuition-agent");
 * // Returns: '{"name":"code-reviewer","namespace":"intuition-agent"}'
 * ```
 */
export function encodeIdentityAtomData(
  name: string,
  namespace: string = 'intuition-agent'
): string {
  return JSON.stringify({ name, namespace })
}

/**
 * Encodes unsigned calldata for creating an identity atom on the MultiVault contract.
 *
 * The identity atom uses minimal JSON data containing only name and namespace.
 * This serves as the permanent anchor, with metadata linked via has-metadata triple.
 *
 * @param name - The entity name
 * @param namespace - The namespace (default: "intuition-agent")
 * @param depositAmount - Initial deposit amount in wei (default: 0)
 * @returns Encoded calldata (hex string starting with 0x)
 *
 * @example
 * ```typescript
 * const calldata = encodeCreateIdentityAtomCalldata("code-reviewer", "intuition-agent", 0n);
 * // Pass to wallet for user to sign
 * ```
 */
export function encodeCreateIdentityAtomCalldata(
  name: string,
  namespace: string = 'intuition-agent',
  depositAmount: bigint = 0n
): `0x${string}` {
  const identityData = encodeIdentityAtomData(name, namespace)
  const atomData = toHex(identityData)

  return encodeFunctionData({
    abi: multivaultAbi,
    functionName: 'createAtoms',
    args: [[atomData], [depositAmount]],
  })
}

/**
 * Derives the term ID for an identity atom from its name and namespace.
 *
 * @param name - The entity name
 * @param namespace - The namespace
 * @returns The derived term ID
 *
 * @example
 * ```typescript
 * const termId = deriveIdentityAtomTermId("code-reviewer", "intuition-agent");
 * ```
 */
export function deriveIdentityAtomTermId(name: string, namespace: string = 'intuition-agent'): `0x${string}` {
  const identityData = encodeIdentityAtomData(name, namespace)
  const dataHash = keccak256(toHex(identityData))
  return keccak256(concat([ATOM_SALT, dataHash]))
}

/**
 * Encodes unsigned calldata for creating an atom on the MultiVault contract.
 *
 * This generates the raw calldata that can be used with wallet_sendTransaction.
 * Does NOT sign or send the transaction (SEC-07).
 *
 * Note: createAtoms takes arrays, so we wrap the single URI in an array.
 * The assets array should have one entry per atom (0 for no initial deposit).
 *
 * @param ipfsUri - IPFS URI of the atom metadata (e.g., "ipfs://QmX...")
 * @param depositAmount - Initial deposit amount in wei (default: 0)
 * @returns Encoded calldata (hex string starting with 0x)
 *
 * @example
 * ```typescript
 * const calldata = encodeCreateAtomCalldata("ipfs://QmX...", 0n);
 * // Pass to wallet for user to sign
 * ```
 */
export function encodeCreateAtomCalldata(
  ipfsUri: string,
  depositAmount: bigint = 0n
): `0x${string}` {
  const atomData = toHex(ipfsUri)

  return encodeFunctionData({
    abi: multivaultAbi,
    functionName: 'createAtoms',
    args: [[atomData], [depositAmount]],
  })
}

export function encodeCreateTriplesCalldata(
  triples: TripleCalldataInput[],
  depositAmount: bigint = 0n,
): `0x${string}` {
  if (triples.length === 0) {
    throw new Error('at least one triple is required')
  }

  const subjectIds = triples.map((triple) => toBytes32TermId(triple.subjectId))
  const predicateIds = triples.map((triple) => toBytes32TermId(triple.predicateId))
  const objectIds = triples.map((triple) => toBytes32TermId(triple.objectId))
  const deposits = triples.map(() => depositAmount)

  return encodeFunctionData({
    abi: multivaultAbi,
    functionName: 'createTriples',
    args: [subjectIds, predicateIds, objectIds, deposits],
  })
}

export function deriveAtomTermId(ipfsUri: string): `0x${string}` {
  const dataHash = keccak256(toHex(ipfsUri))
  return keccak256(concat([ATOM_SALT, dataHash]))
}
