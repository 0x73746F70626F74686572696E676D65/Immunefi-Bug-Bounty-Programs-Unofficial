import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const mocks = vi.hoisted(() => ({
  uploadAgentMetadata: vi.fn(),
  uploadSkillMetadata: vi.fn(),
  getAtomCost: vi.fn(),
  getTripleCost: vi.fn(),
  getMinimumDeposit: vi.fn(),
  encodeCreateAtomCalldata: vi.fn(),
  encodeCreateTriplesCalldata: vi.fn(),
  deriveAtomTermId: vi.fn(),
  deriveIdentityAtomTermId: vi.fn(),
  encodeIdentityAtomData: vi.fn(),
}))

vi.mock('~/.server/ipfs', () => ({
  uploadAgentMetadata: mocks.uploadAgentMetadata,
  uploadSkillMetadata: mocks.uploadSkillMetadata,
  IpfsUploadError: class IpfsUploadError extends Error {
    category: string
    constructor(message: string, category: string) {
      super(message)
      this.name = 'IpfsUploadError'
      this.category = category
    }
  },
}))

vi.mock('~/.server/multivault', () => ({
  getAtomCost: mocks.getAtomCost,
  getTripleCost: mocks.getTripleCost,
  getMinimumDeposit: mocks.getMinimumDeposit,
  createAtoms: vi.fn(),
  createTriples: vi.fn(),
  getAtomByUri: vi.fn(),
}))

vi.mock('~/.server/remote-write-guard', () => ({
  assertRemoteWriteAllowed: vi.fn(),
  RemoteWriteGuardError: class RemoteWriteGuardError extends Error {
    code: string
    profile: string
    target: string
    action: string
    constructor(message: string, code: string, profile: string, target: string, action: string) {
      super(message)
      this.code = code
      this.profile = profile
      this.target = target
      this.action = action
    }
  },
}))

vi.mock('~/.server/local-write', () => ({
  createLocalWriteClients: vi.fn(),
  getLocalWriteContext: vi.fn(),
}))

vi.mock('~/.server/local-agent-cache', () => ({
  storeLocalAgent: vi.fn(),
}))

vi.mock('~/lib/calldata', () => ({
  encodeCreateAtomCalldata: mocks.encodeCreateAtomCalldata,
  encodeCreateTriplesCalldata: mocks.encodeCreateTriplesCalldata,
  deriveAtomTermId: mocks.deriveAtomTermId,
  deriveIdentityAtomTermId: mocks.deriveIdentityAtomTermId,
  encodeIdentityAtomData: mocks.encodeIdentityAtomData,
}))

vi.mock('~/lib/abis/multivault', () => ({
  multivaultAbi: [],
}))

vi.mock('~/lib/rate-limit', () => ({
  isRegistrationRateLimitEnabled: vi.fn(() => false),
  getClientIP: vi.fn(() => '127.0.0.1'),
  registrationLimiter: {
    check: vi.fn(() => ({
      allowed: true,
      resetAt: Date.now() + 60_000,
    })),
  },
}))

vi.mock('viem', () => ({
  createPublicClient: vi.fn(() => ({})),
  http: vi.fn(() => ({})),
  parseEventLogs: vi.fn(() => []),
  toHex: vi.fn((str: string) => `0x${Buffer.from(str).toString('hex')}`),
  encodeFunctionData: vi.fn(() => '0xdeadbeef'),
  keccak256: vi.fn(() => '0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'),
  pad: vi.fn((val: string) => val as `0x${string}`),
}))

vi.mock('~/.server/term-ids', () => ({
  getPredicates: vi.fn(() => ({
    IS: '0xeeee555555555555555555555555555555555555555555555555555555555555',
    HAS_CAPABILITY: '0xdddd444444444444444444444444444444444444444444444444444444444444',
    USES: '0x2222888888888888888888888888888888888888888888888888888888888888',
    HAS_METADATA: '0xffff666666666666666666666666666666666666666666666666666666666666',
    CREATED_BY: '0x_placeholder_created_by',
  })),
  getTypeAtoms: vi.fn(() => ({
    AGENT_TYPE: '0x3333999999999999999999999999999999999999999999999999999999999999',
    SKILL_TYPE: '0x5555000000000000000000000000000000000000000000000000000000000000',
  })),
}))

vi.mock('~/lib/constants/protocol', () => ({
  getContractAddress: vi.fn(() => '0xcontract'),
  getChainConfig: vi.fn(() => ({ chainId: 13579 })),
  getRpcUrl: vi.fn(() => 'http://localhost:8545'),
  NAMESPACES: { AGENT: 'agent', SKILL: 'skill' },
}))

describe('registration created-by triple', () => {
  const baseEnv = { ...process.env }
  const resolvedTermId = '0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
  const createdByPredicate = '0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb'
  const creatorTerm = '0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc'
  const typePredicate = '0xdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd'
  const typeObject = '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee'

  beforeEach(() => {
    vi.resetAllMocks()
    process.env = {
      ...baseEnv,
      CHAIN: 'testnet',
      ALLOW_REMOTE_WRITES: '1',
      REGISTRY_WRITE_PROFILE: 'shared',
    }
    mocks.getAtomCost.mockResolvedValue(100n)
    mocks.getTripleCost.mockResolvedValue(25n)
    mocks.getMinimumDeposit.mockResolvedValue(1n)
    mocks.encodeCreateAtomCalldata.mockReturnValue('0xdeadbeef')
    mocks.encodeCreateTriplesCalldata.mockReturnValue('0xbeadfeed')
    mocks.deriveAtomTermId.mockReturnValue(resolvedTermId)
    mocks.deriveIdentityAtomTermId.mockReturnValue(resolvedTermId)
    mocks.encodeIdentityAtomData.mockReturnValue('{"name":"test","namespace":"intuition-agent"}')
    mocks.uploadAgentMetadata.mockResolvedValue('ipfs://QmAgent')
    mocks.uploadSkillMetadata.mockResolvedValue('ipfs://QmSkill')
  })

  afterEach(() => {
    process.env = { ...baseEnv }
  })

  it('includes created-by triple when both predicate and creator term ids are resolved (agent)', async () => {
    const { action } = await import('../api+/v1.agents.register')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/agents/register', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          name: 'Creator Agent',
          description: 'Agent with creator',
          version: '1.0.0',
          relationshipContext: {
            typePredicateTermId: typePredicate,
            typeObjectTermId: typeObject,
            createdByPredicateTermId: createdByPredicate,
            creatorTermId: creatorTerm,
          },
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    // Should have createAtoms + createTriples transactions
    expect(body.data.transactions).toHaveLength(2)
    expect(body.data.signaturePlan.requiredSignatures).toBe(2)
    // Verify encodeCreateTriplesCalldata was called with triples including created-by
    const triplesArg = mocks.encodeCreateTriplesCalldata.mock.calls[0][0]
    const createdByTriple = triplesArg.find(
      (t: { predicateId: string }) => t.predicateId === createdByPredicate
    )
    expect(createdByTriple).toBeDefined()
    expect(createdByTriple.objectId).toBe(creatorTerm)
  })

  it('includes created-by triple when both predicate and creator term ids are resolved (skill)', async () => {
    const { action } = await import('../api+/v1.skills.register')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/skills/register', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          name: 'Creator Skill',
          description: 'Skill with creator',
          version: '1.0.0',
          platform: 'mcp',
          relationshipContext: {
            typePredicateTermId: typePredicate,
            typeObjectTermId: typeObject,
            createdByPredicateTermId: createdByPredicate,
            creatorTermId: creatorTerm,
          },
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.transactions).toHaveLength(2)
    const triplesArg = mocks.encodeCreateTriplesCalldata.mock.calls[0][0]
    const createdByTriple = triplesArg.find(
      (t: { predicateId: string }) => t.predicateId === createdByPredicate
    )
    expect(createdByTriple).toBeDefined()
    expect(createdByTriple.objectId).toBe(creatorTerm)
  })

  it('skips created-by triple when predicate is a placeholder', async () => {
    const { action } = await import('../api+/v1.agents.register')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/agents/register', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          name: 'No Creator Agent',
          description: 'Agent without created-by',
          version: '1.0.0',
          relationshipContext: {
            typePredicateTermId: typePredicate,
            typeObjectTermId: typeObject,
            // createdByPredicateTermId omitted — defaults to PREDICATES.CREATED_BY (placeholder)
            creatorTermId: creatorTerm,
          },
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.transactions).toHaveLength(2)
    // Should have type triple but not created-by
    const triplesArg = mocks.encodeCreateTriplesCalldata.mock.calls[0][0]
    const createdByTriple = triplesArg.find(
      (t: { predicateId: string }) => t.predicateId === createdByPredicate
    )
    expect(createdByTriple).toBeUndefined()
  })

  it('skips created-by triple when creatorTermId is missing', async () => {
    const { action } = await import('../api+/v1.agents.register')
    const response = await action({
      request: new Request('http://localhost:4101/api/v1/agents/register', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          name: 'No Creator Agent 2',
          description: 'Agent without creator term',
          version: '1.0.0',
          relationshipContext: {
            typePredicateTermId: typePredicate,
            typeObjectTermId: typeObject,
            createdByPredicateTermId: createdByPredicate,
            // no creatorTermId
          },
        }),
      }),
      params: {},
      context: {},
    } as never)

    expect(response.status).toBe(200)
    const body = await response.json()
    expect(body.data.transactions).toHaveLength(2)
    const triplesArg = mocks.encodeCreateTriplesCalldata.mock.calls[0][0]
    const createdByTriple = triplesArg.find(
      (t: { predicateId: string }) => t.predicateId === createdByPredicate
    )
    expect(createdByTriple).toBeUndefined()
  })
})
