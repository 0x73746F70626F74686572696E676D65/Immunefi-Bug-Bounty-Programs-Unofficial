import type { LoaderFunctionArgs } from 'react-router'
import { createRepository } from '~/data/repository/provider'
import { handleOptions, jsonResponse, errorResponse } from '~/lib/api/types'
import { generateERC8004 } from '~/lib/erc8004'

/**
 * GET /api/v1/agents/:id/erc8004
 *
 * Returns ERC-8004 compliant registration file for an agent.
 * Chain is determined by CHAIN env var (defaults to testnet).
 */
export async function loader({ params, request }: LoaderFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const repo = createRepository()
  const agent = await repo.findAgent(params.id!)

  if (!agent) {
    return errorResponse('Agent not found', 'NOT_FOUND', 404)
  }

  const chain = (process.env.CHAIN as 'testnet' | 'mainnet') || 'testnet'
  const url = new URL(request.url)
  const includeOnboarding = url.searchParams.get('onboarding') === 'true'
  const erc8004 = generateERC8004(agent, chain, { includeOnboarding })

  return jsonResponse(erc8004)
}
