import * as Tabs from '@radix-ui/react-tabs'

interface EntityTabsProps {
  value: 'all' | 'agents' | 'skills'
  onChange: (value: 'all' | 'agents' | 'skills') => void
  counts: {
    all: number
    agents: number
    skills: number
  }
  className?: string
}

/**
 * EntityTabs — tab switcher for All / Agents / Skills
 *
 * Uses Radix Tabs for accessible keyboard navigation.
 */
export function EntityTabs({ value, onChange, counts, className = '' }: EntityTabsProps) {
  return (
    <Tabs.Root value={value} onValueChange={(v) => onChange(v as 'all' | 'agents' | 'skills')}>
      <Tabs.List className={`flex w-full gap-2 overflow-x-auto md:w-auto ${className}`}>
        <Tabs.Trigger
          value="all"
          className="whitespace-nowrap border-b-2 px-4 py-2 font-mono text-xs tracking-wider uppercase transition-colors data-[state=active]:border-b-[hsl(var(--accent))] data-[state=active]:text-[hsl(var(--accent))] data-[state=inactive]:border-b-transparent data-[state=inactive]:text-ink-dull data-[state=inactive]:hover:text-ink-default"
        >
          All ({counts.all})
        </Tabs.Trigger>
        <Tabs.Trigger
          value="agents"
          className="whitespace-nowrap border-b-2 px-4 py-2 font-mono text-xs tracking-wider uppercase transition-colors data-[state=active]:border-b-[hsl(var(--accent))] data-[state=active]:text-[hsl(var(--accent))] data-[state=inactive]:border-b-transparent data-[state=inactive]:text-ink-dull data-[state=inactive]:hover:text-ink-default"
        >
          Agents ({counts.agents})
        </Tabs.Trigger>
        <Tabs.Trigger
          value="skills"
          className="whitespace-nowrap border-b-2 px-4 py-2 font-mono text-xs tracking-wider uppercase transition-colors data-[state=active]:border-b-[hsl(var(--accent))] data-[state=active]:text-[hsl(var(--accent))] data-[state=inactive]:border-b-transparent data-[state=inactive]:text-ink-dull data-[state=inactive]:hover:text-ink-default"
        >
          Skills ({counts.skills})
        </Tabs.Trigger>
      </Tabs.List>
    </Tabs.Root>
  )
}
