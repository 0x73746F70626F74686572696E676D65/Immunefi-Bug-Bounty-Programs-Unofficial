import { useCallback } from 'react'
import { parseEther } from 'viem'
import { useAccount } from 'wagmi'
import { useContractWriteAndWait } from './useContractWriteAndWait'
import { multivaultAbi } from '~/lib/abis/multivault'
import { ensureBytes32 } from '~/lib/id-conversion'
import { getContractAddress } from '~/lib/constants/protocol'
import type { NetworkId } from '~/lib/constants/protocol'

interface UseStakeTransactionOptions {
  termId: string
  network: NetworkId
  /** 0n = FOR (default), 1n = AGAINST */
  curveId?: bigint
}

/**
 * Hook for depositing ETH into a MultiVault atom vault.
 *
 * Calls `deposit(receiver, termId, curveId, minShares)` with:
 * - receiver = connected wallet address
 * - termId = bytes32-padded atom ID
 * - curveId = 0 for FOR, 1 for AGAINST
 * - minShares = 0 (accept any)
 */
export function useStakeTransaction({ termId, network, curveId = 0n }: UseStakeTransactionOptions) {
  const { address } = useAccount()
  const {
    writeContractAsync,
    txHash,
    receipt,
    awaitingWalletConfirmation,
    awaitingOnChainConfirmation,
    isError,
    error,
    reset,
  } = useContractWriteAndWait()

  const contractAddress = getContractAddress(network) as `0x${string}`

  const stake = useCallback(
    async (ethAmount: string) => {
      if (!address) throw new Error('Wallet not connected')

      const value = parseEther(ethAmount)

      await writeContractAsync({
        address: contractAddress,
        abi: multivaultAbi,
        functionName: 'deposit',
        args: [address, ensureBytes32(termId), curveId, 0n],
        value,
      })
    },
    [address, contractAddress, termId, curveId, writeContractAsync],
  )

  return {
    stake,
    txHash,
    receipt,
    awaitingWalletConfirmation,
    awaitingOnChainConfirmation,
    isError,
    error,
    reset,
  }
}
