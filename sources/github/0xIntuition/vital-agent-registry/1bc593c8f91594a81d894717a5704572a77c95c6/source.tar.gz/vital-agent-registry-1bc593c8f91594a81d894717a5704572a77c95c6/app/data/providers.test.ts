import { describe, it, expect } from 'vitest'
import { PROVIDERS, findProviderById, getProviderUrl, getProviderOptions } from './providers'

describe('PROVIDERS', () => {
  it('should have unique IDs', () => {
    const ids = PROVIDERS.map((p) => p.id)
    expect(new Set(ids).size).toBe(ids.length)
  })

  it('should include "other" provider', () => {
    const other = PROVIDERS.find((p) => p.id === 'other')
    expect(other).toBeDefined()
    expect(other?.name).toBe('Other')
  })

  it('should have 12 providers', () => {
    expect(PROVIDERS).toHaveLength(12)
  })
})

describe('findProviderById', () => {
  it('should return provider for known id', () => {
    const provider = findProviderById('anthropic')
    expect(provider?.name).toBe('Anthropic')
  })

  it('should return undefined for unknown id', () => {
    expect(findProviderById('unknown')).toBeUndefined()
  })
})

describe('getProviderUrl', () => {
  it('should return URL for known provider', () => {
    expect(getProviderUrl('anthropic')).toBe('https://anthropic.com')
  })

  it('should return undefined for other provider', () => {
    expect(getProviderUrl('other')).toBeUndefined()
  })

  it('should return undefined for unknown provider', () => {
    expect(getProviderUrl('unknown')).toBeUndefined()
  })
})

describe('getProviderOptions', () => {
  it('should return options for all providers', () => {
    const options = getProviderOptions()
    expect(options).toHaveLength(PROVIDERS.length)
    expect(options[0]).toHaveProperty('value')
    expect(options[0]).toHaveProperty('label')
  })
})
