import { Link, useLocation } from 'react-router'
import { Home, Compass, Bookmark, User, Network } from 'lucide-react'
import { cn } from '~/lib/utils'

const tabs = [
  { path: '/', icon: Home, label: 'Home' },
  { path: '/explore', icon: Compass, label: 'Explore' },
  { path: '/graph', icon: Network, label: 'Graph' },
  { path: '/saved', icon: Bookmark, label: 'Saved' },
  { path: '/me', icon: User, label: 'Profile' },
] as const

export function BottomNav() {
  const location = useLocation()

  // Hide on detail pages and explore mode
  const isDetailPage = location.pathname.startsWith('/agent/') ||
                        location.pathname.startsWith('/profile/') ||
                        location.pathname.startsWith('/explore/') ||
                        location.pathname.startsWith('/graph')

  if (isDetailPage) return null

  return (
    <nav className="border-t border-border bg-background/80 backdrop-blur-md">
      <div className="flex items-center justify-around px-2 py-2 pb-3">
        {tabs.map(({ path, icon: Icon, label }) => {
          const isActive = location.pathname === path ||
                          (path === '/explore' && location.pathname === '/explore')
          return (
            <Link
              key={path}
              to={path}
              className={cn(
                'flex flex-col items-center gap-0.5 px-3 py-1 no-underline transition-colors',
                isActive ? 'text-brand' : 'text-muted-foreground',
              )}
            >
              <Icon className="h-5 w-5" />
              <span className="text-[10px] font-medium">{label}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
