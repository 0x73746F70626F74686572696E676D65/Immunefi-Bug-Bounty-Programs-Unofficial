import { describe, expect, it, vi, beforeEach } from 'vitest'

const pollIndexerLagBlocks = vi.fn()

vi.mock('~/lib/indexer-poller', () => ({
  pollIndexerLagBlocks,
}))

describe('getIndexerLagBlocks', () => {
  const originalGraphqlUrl = process.env.GRAPHQL_API_URL_PRIVATE

  beforeEach(() => {
    pollIndexerLagBlocks.mockReset()
    process.env.GRAPHQL_API_URL_PRIVATE = originalGraphqlUrl
  })

  it('returns zero when private graphql url is missing', async () => {
    delete process.env.GRAPHQL_API_URL_PRIVATE
    const { getIndexerLagBlocks } = await import('~/lib/indexer-lag.server')
    await expect(getIndexerLagBlocks()).resolves.toBe(0)
    expect(pollIndexerLagBlocks).not.toHaveBeenCalled()
  })

  it('returns lag blocks when poller resolves a number', async () => {
    process.env.GRAPHQL_API_URL_PRIVATE = 'http://localhost:8080/v1/graphql'
    pollIndexerLagBlocks.mockResolvedValueOnce(12)
    const { getIndexerLagBlocks } = await import('~/lib/indexer-lag.server')
    await expect(getIndexerLagBlocks()).resolves.toBe(12)
  })

  it('returns zero when poller throws', async () => {
    process.env.GRAPHQL_API_URL_PRIVATE = 'http://localhost:8080/v1/graphql'
    pollIndexerLagBlocks.mockRejectedValueOnce(new Error('boom'))
    const { getIndexerLagBlocks } = await import('~/lib/indexer-lag.server')
    await expect(getIndexerLagBlocks()).resolves.toBe(0)
  })
})
