import { describe, expect, it } from 'vitest';
import { AgentMetadataSchema } from './agent-metadata';

describe('AgentMetadataSchema', () => {
  it('validation matrix contains at least 5 valid and 5 invalid payloads', () => {
    const validPayloads = [
      {
        '@type': 'Agent' as const,
        name: 'Agent One',
        description: 'Valid payload 1',
        version: '1.0.0',
      },
      {
        '@type': 'Agent' as const,
        name: 'Agent Two',
        description: 'Valid payload 2',
        version: '1.0.1-beta',
      },
      {
        '@type': 'Agent' as const,
        name: 'Agent Three',
        description: 'Valid payload 3',
        version: '2.0.0',
        capabilities: ['code-review', 'analysis'],
      },
      {
        '@type': 'Agent' as const,
        name: 'Agent Four',
        description: 'Valid payload 4',
        version: '2.1.0',
        provider: { name: 'Provider X', url: 'https://example.com' },
      },
      {
        '@type': 'Agent' as const,
        name: 'Agent Five',
        description: 'Valid payload 5',
        version: '3.0.0',
        defaultInputModes: ['text/plain'],
        defaultOutputModes: ['application/json'],
      },
    ];
    const invalidPayloads = [
      { '@type': 'Skill', name: 'a', description: 'b', version: '1.0.0' },
      { '@type': 'Agent' as const, name: '', description: 'b', version: '1.0.0' },
      { '@type': 'Agent' as const, name: 'a', description: '', version: '1.0.0' },
      { '@type': 'Agent' as const, name: 'a', description: 'b', version: 'invalid' },
      {
        '@type': 'Agent' as const,
        name: 'a',
        description: 'b',
        version: '1.0.0',
        capabilities: Array(11).fill('cap'),
      },
    ];

    expect(validPayloads).toHaveLength(5);
    expect(invalidPayloads).toHaveLength(5);
    expect(validPayloads.every((payload) => AgentMetadataSchema.safeParse(payload).success)).toBe(true);
    expect(invalidPayloads.every((payload) => !AgentMetadataSchema.safeParse(payload).success)).toBe(true);
  });

  it('should validate valid agent metadata', () => {
    const validMetadata = {
      '@type': 'Agent' as const,
      name: 'Test Agent',
      description: 'A test agent for validation',
      version: '1.0.0',
    };

    const result = AgentMetadataSchema.safeParse(validMetadata);
    expect(result.success).toBe(true);
  });

  it('should reject invalid @type', () => {
    const invalidMetadata = {
      '@type': 'Skill',
      name: 'Test Agent',
      description: 'A test agent',
      version: '1.0.0',
    };

    const result = AgentMetadataSchema.safeParse(invalidMetadata);
    expect(result.success).toBe(false);
  });

  it('should reject name that is too long', () => {
    const invalidMetadata = {
      '@type': 'Agent' as const,
      name: 'a'.repeat(101),
      description: 'A test agent',
      version: '1.0.0',
    };

    const result = AgentMetadataSchema.safeParse(invalidMetadata);
    expect(result.success).toBe(false);
  });

  it('should reject invalid semver', () => {
    const invalidMetadata = {
      '@type': 'Agent' as const,
      name: 'Test Agent',
      description: 'A test agent',
      version: 'not-a-version',
    };

    const result = AgentMetadataSchema.safeParse(invalidMetadata);
    expect(result.success).toBe(false);
  });

  it('should accept valid semver variations', () => {
    const versions = ['1.0.0', '2.1.3', '1.0.0-beta', '1.0.0-beta.1', '1.0.0+build123'];

    for (const version of versions) {
      const metadata = {
        '@type': 'Agent' as const,
        name: 'Test Agent',
        description: 'A test agent',
        version,
      };

      const result = AgentMetadataSchema.safeParse(metadata);
      expect(result.success).toBe(true);
    }
  });

  it('should accept optional fields', () => {
    const metadataWithOptionals = {
      '@type': 'Agent' as const,
      name: 'Test Agent',
      description: 'A test agent',
      version: '1.0.0',
      image: 'https://example.com/image.png',
      model: 'claude-opus-4',
      endpoint: 'https://api.example.com/agent',
      provider: {
        name: 'Anthropic',
        url: 'https://anthropic.com',
      },
      capabilities: ['code-review', 'analysis'],
      defaultInputModes: ['text/plain'],
      defaultOutputModes: ['text/markdown'],
    };

    const result = AgentMetadataSchema.safeParse(metadataWithOptionals);
    expect(result.success).toBe(true);
  });

  it('should reject more than 10 capabilities', () => {
    const invalidMetadata = {
      '@type': 'Agent' as const,
      name: 'Test Agent',
      description: 'A test agent',
      version: '1.0.0',
      capabilities: Array(11).fill('capability'),
    };

    const result = AgentMetadataSchema.safeParse(invalidMetadata);
    expect(result.success).toBe(false);
  });

  // Note: Duplicate capabilities are allowed at schema level - graph handles uniqueness

  it('should reject invalid URL formats', () => {
    const invalidMetadata = {
      '@type': 'Agent' as const,
      name: 'Test Agent',
      description: 'A test agent',
      version: '1.0.0',
      image: 'not-a-url',
    };

    const result = AgentMetadataSchema.safeParse(invalidMetadata);
    expect(result.success).toBe(false);
  });
});
