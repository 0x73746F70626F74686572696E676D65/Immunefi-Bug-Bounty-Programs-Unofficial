import type { Platform } from '~/types'

export const PLATFORMS: Platform[] = [
  {
    id: 'mcp',
    name: 'Model Context Protocol',
    description: 'Anthropic standard for connecting AI models to external tools and data sources',
    url: 'https://modelcontextprotocol.io',
  },
  {
    id: 'claude-code',
    name: 'Claude Code Skills',
    description: 'Custom slash commands and workflows for Claude Code CLI',
    url: 'https://claude.ai/code',
  },
  {
    id: 'openclaw',
    name: 'OpenClaw',
    description: 'Open marketplace for AI agent tools and skills with ClawdBot integration',
  },
  {
    id: 'openai',
    name: 'OpenAI Functions',
    description: 'Function calling and tool use for OpenAI models',
    url: 'https://platform.openai.com',
  },
  {
    id: 'custom',
    name: 'Custom Integration',
    description: 'Custom or proprietary skill integration',
  },
]

export function findPlatformById(id: string): Platform | undefined {
  return PLATFORMS.find(p => p.id === id)
}
