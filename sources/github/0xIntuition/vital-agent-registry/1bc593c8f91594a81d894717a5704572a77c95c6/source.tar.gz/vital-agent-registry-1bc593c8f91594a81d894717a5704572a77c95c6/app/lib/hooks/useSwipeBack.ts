import { useRef, useEffect } from 'react'
import { useNavigate } from 'react-router'

const EDGE_THRESHOLD = 20
const SWIPE_MIN_DISTANCE = 60

export function useSwipeBack() {
  const navigate = useNavigate()
  const touchStartX = useRef(0)
  const touchStartY = useRef(0)
  const isEdgeSwipe = useRef(false)

  useEffect(() => {
    function onTouchStart(e: TouchEvent) {
      const touch = e.touches[0]
      if (!touch) return
      touchStartX.current = touch.clientX
      touchStartY.current = touch.clientY
      isEdgeSwipe.current = touch.clientX <= EDGE_THRESHOLD
    }

    function onTouchEnd(e: TouchEvent) {
      if (!isEdgeSwipe.current) return
      const touch = e.changedTouches[0]
      if (!touch) return
      const dx = touch.clientX - touchStartX.current
      const dy = Math.abs(touch.clientY - touchStartY.current)
      if (dx > SWIPE_MIN_DISTANCE && dx > dy) {
        navigate(-1)
      }
      isEdgeSwipe.current = false
    }

    window.addEventListener('touchstart', onTouchStart, { passive: true })
    window.addEventListener('touchend', onTouchEnd, { passive: true })

    return () => {
      window.removeEventListener('touchstart', onTouchStart)
      window.removeEventListener('touchend', onTouchEnd)
    }
  }, [navigate])
}
