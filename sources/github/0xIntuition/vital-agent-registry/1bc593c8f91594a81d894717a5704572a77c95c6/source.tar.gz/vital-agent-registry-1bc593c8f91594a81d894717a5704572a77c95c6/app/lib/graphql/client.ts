/**
 * Get the GraphQL proxy URL based on execution context.
 * Server-side: absolute URL (fetch requires it)
 * Client-side: relative URL
 */
function getGraphQLUrl(): string {
  if (typeof window === 'undefined') {
    const origin = process.env.ORIGIN_URL || 'http://localhost:4101'
    return `${origin}/api/graphql`
  }
  return '/api/graphql'
}

/**
 * Execute a GraphQL query via the proxy route.
 * Used in loaders (server-side) and client-side queries.
 */
export async function graphqlRequest<TData, TVariables = Record<string, unknown>>(
  query: string,
  variables?: TVariables,
): Promise<TData> {
  const url = getGraphQLUrl()
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables }),
  })

  const contentType = res.headers.get('content-type')
  if (!contentType?.includes('application/json')) {
    throw new Error(
      `GraphQL request failed: Expected JSON but got ${contentType ?? 'unknown'}. Status: ${res.status}.`,
    )
  }

  const json = await res.json()

  if (json.errors && (!json.data || Object.keys(json.data).length === 0)) {
    const message = json.errors[0]?.message ?? 'Unknown GraphQL error'
    throw new Error(message)
  }

  return json.data as TData
}

/**
 * Direct server-side fetcher that bypasses the proxy.
 * Use this in loaders when you have the server env available.
 */
export async function serverGraphqlRequest<TData, TVariables = Record<string, unknown>>(
  apiUrl: string,
  query: string,
  variables?: TVariables,
): Promise<TData> {
  const res = await fetch(apiUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables: variables ?? {} }),
  })

  const contentType = res.headers.get('content-type')
  if (!contentType?.includes('application/json')) {
    throw new Error(
      `GraphQL request failed: Expected JSON but got ${contentType ?? 'unknown'}. Status: ${res.status}.`,
    )
  }

  const json = await res.json()

  if (json.errors && (!json.data || Object.keys(json.data).length === 0)) {
    const message = json.errors[0]?.message ?? 'Unknown GraphQL error'
    throw new Error(message)
  }

  return json.data as TData
}

/**
 * React Query compatible fetcher factory.
 * Returns a function that executes the query — suitable for queryFn.
 */
export function fetcher<TData, TVariables = Record<string, unknown>>(
  query: string,
  variables?: TVariables,
) {
  return () => graphqlRequest<TData, TVariables>(query, variables)
}
