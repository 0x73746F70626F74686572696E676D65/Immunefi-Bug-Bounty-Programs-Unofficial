import { describe, it, expect } from 'vitest'
import { detectSource, extractMoltbookSlug, extractClawhubSlug } from './detect-source'

describe('detectSource', () => {
  it('should detect moltbook user URL', () => {
    const result = detectSource('https://moltbook.com/u/alice')
    expect(result?.source).toBe('moltbook')
    expect(result?.slug).toBe('alice')
  })

  it('should detect moltbook URL with www', () => {
    const result = detectSource('https://www.moltbook.com/u/bob-smith')
    expect(result?.source).toBe('moltbook')
    expect(result?.slug).toBe('bob-smith')
  })

  it('should detect clawhub skill URL', () => {
    const result = detectSource('https://clawhub.ai/skills/github-mcp')
    expect(result?.source).toBe('clawhub')
    expect(result?.slug).toBe('github-mcp')
  })

  it('should detect clawhub URL with www', () => {
    const result = detectSource('https://www.clawhub.ai/skills/filesystem-tool')
    expect(result?.source).toBe('clawhub')
    expect(result?.slug).toBe('filesystem-tool')
  })

  it('should return null for unsupported URL', () => {
    expect(detectSource('https://example.com/user/alice')).toBeNull()
    expect(detectSource('https://github.com/alice')).toBeNull()
    expect(detectSource('not-a-url')).toBeNull()
  })

  it('should return null for empty string', () => {
    expect(detectSource('')).toBeNull()
  })
})

describe('extractMoltbookSlug', () => {
  it('should extract slug from moltbook URL', () => {
    expect(extractMoltbookSlug('https://moltbook.com/u/alice')).toBe('alice')
    expect(extractMoltbookSlug('https://moltbook.com/u/bob_smith_123')).toBe('bob_smith_123')
  })

  it('should return null for non-moltbook URL', () => {
    expect(extractMoltbookSlug('https://clawhub.ai/skills/foo')).toBeNull()
    expect(extractMoltbookSlug('')).toBeNull()
  })
})

describe('extractClawhubSlug', () => {
  it('should extract slug from clawhub URL', () => {
    expect(extractClawhubSlug('https://clawhub.ai/skills/github-mcp')).toBe('github-mcp')
    expect(extractClawhubSlug('https://clawhub.ai/skills/my_tool_2')).toBe('my_tool_2')
  })

  it('should return null for non-clawhub URL', () => {
    expect(extractClawhubSlug('https://moltbook.com/u/alice')).toBeNull()
    expect(extractClawhubSlug('')).toBeNull()
  })
})
