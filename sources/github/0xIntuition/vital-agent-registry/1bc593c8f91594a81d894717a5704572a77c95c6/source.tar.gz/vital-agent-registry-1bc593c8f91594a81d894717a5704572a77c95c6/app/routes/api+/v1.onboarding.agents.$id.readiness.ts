import type { LoaderFunctionArgs } from 'react-router'
import { handleOptions, parseQueryParams, jsonResponse } from '~/lib/api/types'
import { readinessQuerySchema, buildOnboardingContract } from '~/lib/api/onboarding'
import { pollIndexerLagBlocks } from '~/lib/indexer-poller'

export async function loader({ params, request }: LoaderFunctionArgs) {
  const optRes = handleOptions(request)
  if (optRes) return optRes

  const parsed = parseQueryParams(request, readinessQuerySchema)
  if ('error' in parsed) return parsed.error

  const agentId = params.id ?? 'unknown-agent'
  const data = parsed.data
  const indexerLagBlocks =
    data.indexerLagBlocks ??
    (process.env.GRAPHQL_API_URL_PRIVATE
      ? (await pollIndexerLagBlocks(process.env.GRAPHQL_API_URL_PRIVATE, {
          maxRetries: 2,
          initialDelayMs: 100,
          maxDelayMs: 500,
        })) ?? 0
      : 0)

  const contract = buildOnboardingContract({
    agentId,
    hasWallet: data.hasWallet,
    availableFundsWei: data.availableFundsWei,
    requiredFundsWei: data.requiredFundsWei,
    isRegistered: data.isRegistered,
    isActive: data.isActive,
    indexerLagBlocks,
    policyBlocked: data.policyBlocked,
  })

  return jsonResponse(contract)
}
