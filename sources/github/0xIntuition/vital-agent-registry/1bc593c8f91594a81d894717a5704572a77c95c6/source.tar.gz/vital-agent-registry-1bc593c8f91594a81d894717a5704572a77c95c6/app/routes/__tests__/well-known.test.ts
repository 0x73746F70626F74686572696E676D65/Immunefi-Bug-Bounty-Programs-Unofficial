import { describe, it, expect, vi, beforeEach } from 'vitest'
import { loader } from '../[.]well-known+/agent[.]json'
import type { LoaderFunctionArgs } from 'react-router'

// Mock the repository
vi.mock('~/data/repository/provider', () => ({
  createRepository: vi.fn(() => ({
    getAgentCard: vi.fn(),
  })),
}))

/**
 * Helper to create a mock Request object
 */
function createMockRequest(url: string, method = 'GET'): Request {
  return new Request(url, { method })
}

/**
 * Helper to create mock LoaderFunctionArgs
 */
function createLoaderArgs(url: string): LoaderFunctionArgs {
  return {
    request: createMockRequest(url),
    params: {},
    context: {},
    unstable_pattern: '',
  } as LoaderFunctionArgs
}

describe('well-known agent.json', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('loader - registry card (default)', () => {
    it('should return JSON response with Content-Type application/json', async () => {
      const args = createLoaderArgs('https://registry.intuition.systems/.well-known/agent.json')
      const response = await loader(args)

      expect(response.status).toBe(200)
      expect(response.headers.get('Content-Type')).toBe('application/json')
    })

    it('should return registry card with required A2A v0.3 fields', async () => {
      const args = createLoaderArgs('https://registry.intuition.systems/.well-known/agent.json')
      const response = await loader(args)
      const data = await response.json()

      // Required A2A v0.3 fields
      expect(data).toHaveProperty('id')
      expect(data).toHaveProperty('name')
      expect(data).toHaveProperty('description')
      expect(data).toHaveProperty('url')
      expect(data).toHaveProperty('provider')
      expect(data).toHaveProperty('version')
      expect(data).toHaveProperty('capabilities')
      expect(data).toHaveProperty('skills')
      expect(data).toHaveProperty('securitySchemes')
      expect(data).toHaveProperty('security')
      expect(data).toHaveProperty('interfaces')
      expect(data).toHaveProperty('defaultInputModes')
      expect(data).toHaveProperty('defaultOutputModes')
      expect(data).toHaveProperty('extensions')
    })

    it('should return registry card with Intuition extension', async () => {
      const args = createLoaderArgs('https://registry.intuition.systems/.well-known/agent.json')
      const response = await loader(args)
      const data = await response.json()

      expect(data.extensions).toBeDefined()
      expect(Array.isArray(data.extensions)).toBe(true)
      expect(data.extensions.length).toBeGreaterThan(0)

      const intuitionExt = data.extensions[0]
      expect(intuitionExt).toHaveProperty('uri')
      expect(intuitionExt.uri).toContain('intuition')
    })

    it('should return registry card with 3 skills', async () => {
      const args = createLoaderArgs('https://registry.intuition.systems/.well-known/agent.json')
      const response = await loader(args)
      const data = await response.json()

      expect(data.skills).toBeDefined()
      expect(Array.isArray(data.skills)).toBe(true)
      expect(data.skills).toHaveLength(3)
    })

    it('should include discover-agents skill', async () => {
      const args = createLoaderArgs('https://registry.intuition.systems/.well-known/agent.json')
      const response = await loader(args)
      const data = await response.json()

      const discoverSkill = data.skills.find((s: any) => s.id === 'discover-agents')
      expect(discoverSkill).toBeDefined()
      expect(discoverSkill.name).toBe('Discover Agents')
      expect(discoverSkill.description).toContain('Search and browse')
    })

    it('should include match-capabilities skill', async () => {
      const args = createLoaderArgs('https://registry.intuition.systems/.well-known/agent.json')
      const response = await loader(args)
      const data = await response.json()

      const matchSkill = data.skills.find((s: any) => s.id === 'match-capabilities')
      expect(matchSkill).toBeDefined()
      expect(matchSkill.name).toBe('Match Capabilities')
      expect(matchSkill.description).toContain('Find agents matching')
    })

    it('should include verify-trust skill', async () => {
      const args = createLoaderArgs('https://registry.intuition.systems/.well-known/agent.json')
      const response = await loader(args)
      const data = await response.json()

      const verifySkill = data.skills.find((s: any) => s.id === 'verify-trust')
      expect(verifySkill).toBeDefined()
      expect(verifySkill.name).toBe('Verify Trust')
      expect(verifySkill.description).toContain('trust signals')
    })

    it('should include CORS headers', async () => {
      const args = createLoaderArgs('https://registry.intuition.systems/.well-known/agent.json')
      const response = await loader(args)

      expect(response.headers.get('Access-Control-Allow-Origin')).toBe('*')
    })

    it('should have capabilities object', async () => {
      const args = createLoaderArgs('https://registry.intuition.systems/.well-known/agent.json')
      const response = await loader(args)
      const data = await response.json()

      expect(data.capabilities).toBeDefined()
      expect(typeof data.capabilities).toBe('object')
    })

    it('should expose security and interface fields for standards compliance', async () => {
      const args = createLoaderArgs('https://registry.intuition.systems/.well-known/agent.json')
      const response = await loader(args)
      const data = await response.json()

      expect(data.securitySchemes).toBeDefined()
      expect(data.security).toEqual([{ unauthenticated: [] }])
      expect(Array.isArray(data.interfaces)).toBe(true)
      expect(data.interfaces[0]).toMatchObject({
        protocol: 'http',
        url: 'https://registry.intuition.systems',
      })
    })

    it('should have provider with name and url', async () => {
      const args = createLoaderArgs('https://registry.intuition.systems/.well-known/agent.json')
      const response = await loader(args)
      const data = await response.json()

      expect(data.provider).toBeDefined()
      expect(data.provider.name).toBe('Intuition')
      expect(data.provider.url).toBe('https://intuition.systems')
    })
  })

  describe('loader - specific agent card (with ?id= param)', () => {
    it('should return specific agent card when id param is provided', async () => {
      const { createRepository } = await import('~/data/repository/provider')
      const mockGetAgentCard = vi.fn().mockResolvedValue({
        id: '0xtest123',
        name: 'TestAgent',
        description: 'A test agent',
        url: 'https://test.com',
        provider: { name: 'Test', url: 'https://test.com' },
        version: '1.0.0',
        skills: [],
        defaultInputModes: ['application/json'],
        defaultOutputModes: ['application/json'],
      })

      ;(createRepository as any).mockReturnValue({
        getAgentCard: mockGetAgentCard,
      })

      const args = createLoaderArgs(
        'https://registry.intuition.systems/.well-known/agent.json?id=0xtest123'
      )
      const response = await loader(args)
      const data = await response.json()

      expect(mockGetAgentCard).toHaveBeenCalledWith('0xtest123')
      expect(data.id).toBe('0xtest123')
      expect(data.name).toBe('TestAgent')
    })

    it('should return 404 when agent not found', async () => {
      const { createRepository } = await import('~/data/repository/provider')
      const mockGetAgentCard = vi.fn().mockResolvedValue(null)

      ;(createRepository as any).mockReturnValue({
        getAgentCard: mockGetAgentCard,
      })

      const args = createLoaderArgs(
        'https://registry.intuition.systems/.well-known/agent.json?id=0xnonexistent'
      )
      const response = await loader(args)

      expect(response.status).toBe(404)
      expect(response.headers.get('Content-Type')).toBe('application/json')
      expect(response.headers.get('Access-Control-Allow-Origin')).toBe('*')
      const data = await response.json()
      expect(data.error).toBe('Agent not found')
      expect(data.code).toBe('NOT_FOUND')
      expect(data.id).toBe('0xnonexistent')
    })

    it('should call repository with correct agent id', async () => {
      const { createRepository } = await import('~/data/repository/provider')
      const mockGetAgentCard = vi.fn().mockResolvedValue({
        id: '0xabc',
        name: 'Agent',
        description: 'Desc',
        url: 'https://test.com',
        provider: { name: 'Test', url: 'https://test.com' },
        version: '1.0.0',
        skills: [],
        defaultInputModes: ['application/json'],
        defaultOutputModes: ['application/json'],
      })

      ;(createRepository as any).mockReturnValue({
        getAgentCard: mockGetAgentCard,
      })

      const args = createLoaderArgs(
        'https://registry.intuition.systems/.well-known/agent.json?id=0xabc'
      )
      await loader(args)

      expect(mockGetAgentCard).toHaveBeenCalledWith('0xabc')
    })

    it('should handle id param with special characters', async () => {
      const { createRepository } = await import('~/data/repository/provider')
      const mockGetAgentCard = vi.fn().mockResolvedValue({
        id: '0xtest_123',
        name: 'Agent',
        description: 'Desc',
        url: 'https://test.com',
        provider: { name: 'Test', url: 'https://test.com' },
        version: '1.0.0',
        skills: [],
        defaultInputModes: ['application/json'],
        defaultOutputModes: ['application/json'],
      })

      ;(createRepository as any).mockReturnValue({
        getAgentCard: mockGetAgentCard,
      })

      const args = createLoaderArgs(
        'https://registry.intuition.systems/.well-known/agent.json?id=0xtest_123'
      )
      const response = await loader(args)

      expect(response.status).toBe(200)
      expect(mockGetAgentCard).toHaveBeenCalledWith('0xtest_123')
    })
  })

  describe('CORS and HTTP', () => {
    it('should include all required CORS headers', async () => {
      const args = createLoaderArgs('https://registry.intuition.systems/.well-known/agent.json')
      const response = await loader(args)

      expect(response.headers.get('Access-Control-Allow-Origin')).toBe('*')
      expect(response.headers.get('Access-Control-Allow-Methods')).toBeDefined()
      expect(response.headers.get('Access-Control-Allow-Headers')).toBeDefined()
    })
  })
})
