import { beforeEach, describe, expect, it } from 'vitest'
import type { ActionFunctionArgs } from 'react-router'
import { registrationLimiter } from '~/lib/rate-limit'

function makeArgs(ip: string): ActionFunctionArgs {
  return {
    request: new Request('http://localhost:4101/api/v1/agents/register', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-forwarded-for': ip,
      },
      body: JSON.stringify({
        name: 'Rate Limit Agent',
      }),
    }),
    params: {},
    context: {},
  } as ActionFunctionArgs
}

describe('POST /api/v1/agents/register rate limiting', () => {
  beforeEach(() => {
    process.env.REGISTRY_WRITE_PROFILE = 'shared'
    delete process.env.DISABLE_REGISTRATION_RATE_LIMIT
    delete process.env.REGISTRATION_RATE_LIMIT_FORCE
    registrationLimiter.reset()
  })

  it('returns 429 on the 11th request from the same IP', async () => {
    const { action } = await import('../api+/v1.agents.register')
    const ip = '203.0.113.10'

    for (let i = 0; i < 10; i += 1) {
      const response = await action(makeArgs(ip))
      expect([400, 403, 500]).toContain(response.status)
    }

    const limited = await action(makeArgs(ip))
    expect(limited.status).toBe(429)

    const payload = await limited.json()
    expect(payload.code).toBe('RATE_LIMITED')
    expect(typeof payload.retryAfter).toBe('number')
    expect(payload.retryAfter).toBeGreaterThan(0)
  })
})
