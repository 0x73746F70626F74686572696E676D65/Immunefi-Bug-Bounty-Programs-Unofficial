/**
 * Validates API key for server-side execution endpoints.
 * Required when ?execute=true -- these sign transactions with the server's PRIVATE_KEY.
 */
export function requireExecuteAuth(
  request: Request,
): { authorized: true } | { authorized: false; response: Response } {
  const apiKey =
    request.headers.get('x-api-key') ||
    request.headers.get('authorization')?.replace('Bearer ', '')
  const expectedKey = process.env.REGISTRY_API_KEY

  if (!expectedKey) {
    return {
      authorized: false,
      response: Response.json(
        {
          error: 'Server-side execution not configured',
          code: 'EXECUTE_NOT_CONFIGURED',
        },
        { status: 503 },
      ),
    }
  }

  if (!apiKey || apiKey !== expectedKey) {
    return {
      authorized: false,
      response: Response.json(
        { error: 'Invalid or missing API key', code: 'UNAUTHORIZED' },
        { status: 401 },
      ),
    }
  }

  return { authorized: true }
}
