// Core protocol types
export type { Vault, Position, TrustSignal, TrustTier } from './vault'
export { TRUST_TIER_ORDER, TRUST_TIER_THRESHOLDS } from './vault'
export type { Triple, TripleAtomRef, TripleVaultData, AtomType, Predicate } from './triple'

// Entity types
export type {
  Agent,
  AgentMetadata,
  AgentProvider,
  AgentCard,
  A2ASecurityScheme,
  A2AAgentInterface,
  A2AAgentExtension,
  A2AAgentSkill,
  IntuitionExtension,
  ERC8004,
  ERC8004OnboardingExtension,
} from './agent'

export type {
  Skill,
  SkillMetadata,
  SafetyStatus,
  SafetySignal,
} from './skill'

export type { Capability, CapabilityCategory } from './capability'

export type { SecurityLevel, SecurityProfile, SecurityAttestation } from './security'

export type { DomainScore, ReputationProfile, ReputationTrend } from './reputation'

export type { PredicateDefinition } from './predicate'

export type { Platform, PlatformId } from './platform'

export type { Model } from './model'
export type { Provider } from './provider'

// Repository
export type {
  RegistryRepository,
  SearchOptions,
  ListOptions,
  MatchOptions,
  PaginatedResult,
  SortField,
  EntityType,
} from './repository'
