import { getDefaultConfig } from '@rainbow-me/rainbowkit'
import { defineChain } from 'viem'
import { http } from 'wagmi'

/**
 * Intuition chain definitions.
 */
export const intuitionLocal = defineChain({
  id: 31337,
  name: 'Intuition Local',
  nativeCurrency: { decimals: 18, name: 'ETH', symbol: 'ETH' },
  rpcUrls: { default: { http: ['http://localhost:8545'] } },
})

export const intuitionTestnet = defineChain({
  id: 13579,
  name: 'Intuition Testnet',
  nativeCurrency: { decimals: 18, name: 'ETH', symbol: 'ETH' },
  rpcUrls: { default: { http: ['https://testnet.rpc.intuition.systems/'] } },
  blockExplorers: {
    default: { name: 'Blockscout', url: 'https://testnet.explorer.intuition.systems' },
  },
})

export const intuitionMainnet = defineChain({
  id: 1155,
  name: 'Intuition',
  nativeCurrency: { decimals: 18, name: 'ETH', symbol: 'ETH' },
  rpcUrls: { default: { http: ['https://mainnet.rpc.intuition.systems/'] } },
  blockExplorers: {
    default: { name: 'Blockscout', url: 'https://explorer.intuition.systems' },
  },
})

const CHAIN_MAP = {
  local: intuitionLocal,
  testnet: intuitionTestnet,
  mainnet: intuitionMainnet,
} as const

/**
 * Get the wallet chain definition for a given chain name.
 */
export function getWalletChain(chain: string) {
  return CHAIN_MAP[chain as keyof typeof CHAIN_MAP] ?? intuitionTestnet
}

/**
 * Create wallet config dynamically based on environment.
 */
export function createWalletConfig({
  chain = 'testnet',
  walletConnectProjectId = '',
}: {
  chain?: string
  walletConnectProjectId?: string
} = {}) {
  const walletChain = getWalletChain(chain)

  return getDefaultConfig({
    appName: 'Intuition Agent Registry',
    projectId: walletConnectProjectId || 'agent-registry-dev',
    chains: [walletChain],
    transports: {
      [walletChain.id]: http(),
    },
    ssr: true,
  })
}

/**
 * Static config for backwards compatibility (uses testnet defaults).
 * Prefer createWalletConfig() for dynamic configuration.
 */
export const walletConfig = createWalletConfig()

export type WalletConfig = ReturnType<typeof createWalletConfig>
