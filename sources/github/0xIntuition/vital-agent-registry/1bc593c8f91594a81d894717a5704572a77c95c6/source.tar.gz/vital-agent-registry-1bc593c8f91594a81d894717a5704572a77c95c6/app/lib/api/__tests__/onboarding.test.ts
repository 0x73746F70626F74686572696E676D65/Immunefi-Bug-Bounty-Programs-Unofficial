import { describe, expect, it } from 'vitest'
import {
  onboardingStateSchema,
  onboardingFailureCodeSchema,
  onboardingContractSchema,
  buildOnboardingContract,
  readinessQuerySchema,
} from '../onboarding'

describe('onboarding contract', () => {
  it('defines required state enum values', () => {
    expect(onboardingStateSchema.options).toEqual([
      'unknown',
      'planned',
      'funded',
      'registered',
      'active',
    ])
  })

  it('defines required failure enum values', () => {
    expect(onboardingFailureCodeSchema.options).toEqual([
      'missing-wallet',
      'insufficient-funds',
      'policy-blocked',
      'indexer-lagged',
    ])
  })

  it('builds unknown state with missing wallet failure', () => {
    const result = buildOnboardingContract({
      agentId: 'agent-1',
      hasWallet: false,
      availableFundsWei: 0n,
      requiredFundsWei: 10n,
      isRegistered: false,
      isActive: false,
      indexerLagBlocks: 0,
      policyBlocked: false,
    })

    expect(result.state).toBe('unknown')
    expect(result.failures.some((failure) => failure.code === 'missing-wallet')).toBe(true)
    expect(onboardingContractSchema.safeParse(result).success).toBe(true)
  })

  it('parses readiness query booleans deterministically', () => {
    const parsed = readinessQuerySchema.parse({
      hasWallet: 'true',
      isRegistered: 'false',
      isActive: '0',
      policyBlocked: '1',
      availableFundsWei: '100',
      requiredFundsWei: '50',
      indexerLagBlocks: '3',
    })

    expect(parsed.hasWallet).toBe(true)
    expect(parsed.isRegistered).toBe(false)
    expect(parsed.isActive).toBe(false)
    expect(parsed.policyBlocked).toBe(true)
    expect(parsed.availableFundsWei).toBe(100n)
    expect(parsed.requiredFundsWei).toBe(50n)
    expect(parsed.indexerLagBlocks).toBe(3)
  })
})
