import type { SkillImportFields, ImportError } from '../types'

interface ClawhubApiResponse {
  name?: string
  slug?: string
  description?: string
  author?: string
  installUri?: string
  install_uri?: string
  image?: string
  avatar?: string
  platform?: string
}

function parseClawhubResponse(data: ClawhubApiResponse, slug: string): SkillImportFields {
  return {
    type: 'skill',
    name: data.name ?? slug,
    description: data.description,
    author: data.author,
    installUri: data.installUri ?? data.install_uri,
    image: data.image ?? data.avatar,
    platform: data.platform ?? 'openclaw',
  }
}

function extractMetaTag(html: string, property: string): string | undefined {
  const match =
    html.match(
      new RegExp(
        `<meta[^>]+(?:property|name)=["']${property}["'][^>]+content=["']([^"']+)["']`,
        'i',
      ),
    ) ??
    html.match(
      new RegExp(
        `<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']${property}["']`,
        'i',
      ),
    )
  return match?.[1]
}

function parseClawhubHtml(html: string, slug: string): SkillImportFields {
  return {
    type: 'skill',
    name: extractMetaTag(html, 'og:title') ?? slug,
    description:
      extractMetaTag(html, 'og:description') ?? extractMetaTag(html, 'description'),
    image: extractMetaTag(html, 'og:image'),
    platform: 'openclaw',
  }
}

export async function fetchClawhubSkill(slug: string): Promise<SkillImportFields> {
  // Try JSON API first
  try {
    const apiUrl = `https://clawhub.ai/api/skills/${slug}`
    const response = await fetch(apiUrl, {
      headers: { Accept: 'application/json', 'User-Agent': 'IntuitionRegistry/1.0' },
      signal: AbortSignal.timeout(8000),
    })

    if (response.ok) {
      const data = (await response.json()) as ClawhubApiResponse
      return parseClawhubResponse(data, slug)
    }
  } catch {
    // Fall through to HTML scraping
  }

  // Fall back to HTML meta tags
  const pageUrl = `https://clawhub.ai/skills/${slug}`
  const response = await fetch(pageUrl, {
    headers: { 'User-Agent': 'IntuitionRegistry/1.0' },
    signal: AbortSignal.timeout(8000),
  })

  if (!response.ok) {
    const err: ImportError = {
      code: response.status === 404 ? 'NOT_FOUND' : 'FETCH_FAILED',
      message: `ClawHub returned ${response.status} for skill "${slug}"`,
    }
    throw err
  }

  const html = await response.text()
  return parseClawhubHtml(html, slug)
}
