import type { Platform } from '~/types'
import { cn } from '~/lib/utils'

interface PlatformBadgeProps {
  platform: Platform
  size?: 'sm' | 'md'
  className?: string
}

export function PlatformBadge({ platform, size = 'md', className }: PlatformBadgeProps) {
  const sizeClasses = size === 'sm'
    ? 'text-[10px] px-1.5 py-0.5'
    : 'text-xs px-2 py-0.5'

  return (
    <span
      className={cn(
        'inline-flex items-center rounded-[var(--radius-badge)] font-medium bg-muted text-muted-foreground',
        sizeClasses,
        className,
      )}
    >
      {platform.name}
    </span>
  )
}
