import type { CodegenConfig } from '@graphql-codegen/cli'

const config: CodegenConfig = {
  schema: 'schema.graphql',
  documents: ['app/lib/graphql/**/*.graphql'],
  generates: {
    'app/lib/graphql/generated/index.ts': {
      plugins: [
        'typescript',
        'typescript-operations',
        'typescript-graphql-request',
      ],
      config: {
        scalars: {
          bigint: 'string',
          numeric: 'string',
          timestamptz: 'string',
          uuid: 'string',
          jsonb: 'Record<string, unknown>',
        },
        avoidOptionals: false,
        enumsAsTypes: true,
        skipTypename: true,
        useTypeImports: true,
      },
    },
  },
}

export default config
