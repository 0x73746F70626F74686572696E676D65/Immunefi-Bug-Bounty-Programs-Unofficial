# Agent Registry - Local Development Guide

## Quick Start

### 1. Start Local Stack (Anvil + Indexer)

```bash
cd apps/agent-registry
bash scripts/local-stack.sh up
```

This starts:
- Anvil (local EVM chain at http://localhost:8545)
- PostgreSQL + Hasura (GraphQL at http://localhost:8080)
- Indexer service

Wait for all services to be healthy (check with `bash scripts/local-stack.sh health`).

### 2. Run Bootstrap + Seed

```bash
# In a new terminal:
cd apps/agent-registry
NETWORK=local PRIVATE_KEY=0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 \
  pnpm tsx scripts/local-bootstrap-and-seed.ts
```

This creates:
- Foundation atoms (5 predicates, 2 types, 6 capabilities)
- Sample agents and skills

### 3. Start Frontend (Optional)

```bash
cd apps/agent-registry
pnpm dev
# Open http://localhost:4101
```

---

## Available Scripts

### Local Stack
```bash
# Start everything
bash scripts/local-stack.sh up

# Check health
bash scripts/local-stack.sh health

# Stop everything
bash scripts/local-stack.sh down

# Restart with fresh state
bash scripts/local-stack.sh down && bash scripts/local-stack.sh up
```

### Bootstrap & Seed
```bash
# Combined bootstrap + seed
NETWORK=local PRIVATE_KEY=0x... pnpm tsx scripts/local-bootstrap-and-seed.ts

# Or separately:
NETWORK=local PRIVATE_KEY=0x... pnpm tsx scripts/bootstrap.ts
NETWORK=local PRIVATE_KEY=0x... pnpm tsx scripts/seed.ts
```

### Testing

```bash
# Run all e2e tests
NETWORK=local PRIVATE_KEY=0x... pnpm tsx scripts/local-e2e-orchestrator.ts

# Run multi-agent interaction test
NETWORK=local PRIVATE_KEY=0x... pnpm tsx scripts/multi-agent-interaction-test.ts

# Run unit tests
cd apps/agent-registry && pnpm test

# Run typecheck
cd apps/agent-registry && pnpm typecheck
```

---

## Agent Loop Commands

### Register a New Agent

```bash
curl -X POST http://localhost:4101/api/v1/agents/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "my-agent",
    "description": "A test agent",
    "version": "1.0.0",
    "capabilities": ["code-generation", "planning"]
  }'
```

### Query Agents by Capability

```bash
curl -X POST "http://localhost:4101/api/v1/agents/match" \
  -H "Content-Type: application/json" \
  -d '{"required": ["code-generation"]}'
```

### Get Agent Details

```bash
curl "http://localhost:4101/api/v1/agents/0x..."
```

### Get Trust Score

```bash
curl -X POST http://localhost:4101/api/v1/trust/score \
  -H "Content-Type: application/json" \
  -d '{"candidates": ["0x..."]}'
```

### Stake on Agent (FOR)

```bash
curl -X POST http://localhost:4101/api/v1/trust/stake \
  -H "Content-Type: application/json" \
  -d '{
    "entityId": "0x...",
    "direction": "for",
    "amount": "10000000000000000"
  }'
```

### Generic Protocol Primitives

```bash
# Search atoms by text
curl "http://localhost:4101/api/v1/atoms/search?q=coding&type=capability"

# Create an atom
curl -X POST http://localhost:4101/api/v1/atoms?execute=true \
  -H "Content-Type: application/json" \
  -d '{"atoms": [{"data": "my-new-concept"}]}'

# Create a triple
curl -X POST http://localhost:4101/api/v1/triples?execute=true \
  -H "Content-Type: application/json" \
  -d '{"triples": [{"subjectId": "0x...", "predicateId": "0x...", "objectId": "0x..."}]}'

# Get predicates (bootstrap term IDs)
curl "http://localhost:4101/api/v1/predicates"
```

---

## MCP Server

The registry exposes an MCP (Model Context Protocol) server that any MCP-compatible AI agent can use:

```bash
# Start the MCP server (stdio transport)
pnpm mcp:protocol
```

The MCP server wraps the REST API with 12 tools: `create_atoms`, `create_triples`, `stake`, `get_atom`, `search_atoms`, `get_triples`, `get_predicates`, `get_capabilities`, `calculate_atom_id`, `calculate_triple_id`, `register_agent`, `discover_agents`.

Set `REGISTRY_BASE_URL` to point at a running registry instance (default: `http://localhost:4101`).

---

## Testing with Agents

### Option 1: Direct API Calls

Create agents that call the API directly:

```typescript
// Example agent query
const response = await fetch('http://localhost:4101/api/v1/agents/match?capability=planning')
const agents = await response.json()
```

### Option 2: Using the Multi-Agent Test Script

```bash
NETWORK=local PRIVATE_KEY=0x... pnpm tsx scripts/multi-agent-interaction-test.ts
```

This script:
1. Registers 4 test agents
2. Tests capability discovery
3. Tests agent-to-agent task delegation
4. Tests staking flows
5. Generates report at `.artifacts/multi-agent-test-report.json`

---

## Architecture

### v3 Data Model

- **5 Predicates**: `is`, `has-capability`, `uses`, `has-metadata`, `created-by`
- **Identity Atom**: Permanent identity (contains `{name, namespace}`)
- **Metadata Atom**: Versioned metadata (IPFS URI)
- **has-metadata Triple**: Links identity → metadata

### Registration Flow

1. Create identity atom with minimal JSON
2. Upload full metadata to IPFS
3. Create metadata atom from IPFS URI
4. Create triples:
   - `has-metadata`: identity → metadata
   - `is`: identity → Agent/Skill type
   - `has-capability`: identity → capability
   - `uses`: agent → skill

### Trust-Weighted Resolution

- Query all `has-metadata` triples for an entity
- Get vault balances for each metadata version
- Return metadata with highest FOR stake

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `NETWORK` | `local` | Network: local, testnet, mainnet |
| `PRIVATE_KEY` | - | Wallet private key for transactions |
| `CHAIN` | `testnet` | Legacy chain config |
| `LOCAL_MULTIVAULT_ADDRESS` | `0x5F...` | MultiVault contract on local |
| `GRAPHQL_API_URL_PRIVATE` | `http://localhost:8080/v1/graphql` | GraphQL endpoint |

---

## Test Wallet

The default private key `0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80` is the Anvil default account - it comes pre-funded with 10000 ETH.

---

## Troubleshooting

### Services won't start
```bash
# Check if ports are in use
lsof -i :8545  # Anvil
lsof -i :8080   # Hasura

# Kill conflicting processes
kill <PID>
```

### Bootstrap fails
```bash
# Check Anvil is running
curl -X POST http://localhost:8545 -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}'
```

### Indexer not catching up
```bash
# Check indexer logs
bash scripts/local-stack.sh health

# Check GraphQL for atoms
curl -X POST http://localhost:8080/v1/graphql \
  -H "Content-Type: application/json" \
  -d '{"query":"{ atoms { id } }"}'
```

---

## For Claude Code Agents

To run from an agent:

```bash
cd /home/vital/projects/intuition/intuition-worktrees/agent-registry/apps/agent-registry

# Start local stack
bash scripts/local-stack.sh up

# Wait for health
sleep 30 && bash scripts/local-stack.sh health

# Run bootstrap + seed
NETWORK=local PRIVATE_KEY=0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 \
  pnpm tsx scripts/local-bootstrap-and-seed.ts

# Run e2e tests
NETWORK=local PRIVATE_KEY=0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 \
  pnpm tsx scripts/local-e2e-orchestrator.ts
```
