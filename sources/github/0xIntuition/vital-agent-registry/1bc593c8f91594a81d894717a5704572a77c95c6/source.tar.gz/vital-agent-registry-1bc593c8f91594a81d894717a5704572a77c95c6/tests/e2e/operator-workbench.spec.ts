import { expect, test } from '@playwright/test'

test.describe('Operator Workbench', () => {
  test('renders registration and trust UX surfaces', async ({ page }) => {
    await page.goto('/me')

    await expect(
      page.getByRole('heading', { name: 'Operator Workbench' }),
    ).toBeVisible()
    await expect(
      page.getByRole('heading', { name: 'Registration Progress' }),
    ).toBeVisible()
    await expect(
      page.getByRole('button', { name: 'Agent Registration' }),
    ).toBeVisible()
    await expect(
      page.getByRole('button', { name: 'Skill Registration' }),
    ).toBeVisible()
    await expect(
      page.getByRole('heading', { name: 'Trust Tier UX' }),
    ).toBeVisible()
  })
})
