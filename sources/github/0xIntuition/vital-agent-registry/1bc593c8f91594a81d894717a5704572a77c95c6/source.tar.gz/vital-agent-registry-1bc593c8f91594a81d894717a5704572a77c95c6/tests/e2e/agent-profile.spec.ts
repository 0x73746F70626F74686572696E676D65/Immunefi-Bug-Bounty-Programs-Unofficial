import { expect, test } from '@playwright/test'

test.describe('Agent Profile', () => {
  test('renders trust metrics and network sections', async ({ page }) => {
    await page.goto('/agents/0xagent_001')

    await expect(
      page.getByRole('banner').getByRole('heading', { name: 'Claude Opus Agent' }),
    ).toBeVisible()
    await expect(
      page.getByRole('button', { name: 'Share agent' }),
    ).toBeVisible()
    await expect(
      page.getByRole('heading', { name: 'Trust Metrics' }),
    ).toBeVisible()
    await expect(
      page.getByText(/Ranked in the/i),
    ).toBeVisible()
    await expect(
      page.getByRole('heading', { name: 'Trust Network' }),
    ).toBeVisible()
  })
})
