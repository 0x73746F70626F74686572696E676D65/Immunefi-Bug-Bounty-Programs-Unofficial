import { expect, test } from '@playwright/test'

test.describe('Skill Profile', () => {
  test('renders stale-aware identity and trust/safety surfaces', async ({
    page,
  }) => {
    await page.goto('/skills/0xskill_001')

    await expect(
      page.getByRole('main').getByRole('heading', { name: 'Filesystem MCP' }).first(),
    ).toBeVisible()
    await expect(
      page.getByRole('heading', { name: 'Identity' }),
    ).toBeVisible()
    await expect(
      page.getByRole('heading', { name: 'Safety Signals' }),
    ).toBeVisible()
    await expect(
      page.getByText(/Safety Status/i),
    ).toBeVisible()
    await expect(
      page.getByRole('heading', { name: 'Trust Network' }),
    ).toBeVisible()
  })
})
