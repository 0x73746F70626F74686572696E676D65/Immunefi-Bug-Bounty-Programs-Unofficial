import { createHash } from 'node:crypto'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const scriptDir = resolve(fileURLToPath(new URL('.', import.meta.url)))
export const workspaceRoot = resolve(scriptDir, '..')
export const outputDir = resolve(workspaceRoot, '.artifacts')
export const outputPath = resolve(outputDir, 'local-fixtures.snapshot.json')
export const metadataPath = resolve(outputDir, 'local-fixtures.metadata.json')
const fixtureVersion = 2

export function stableStringify(value) {
  if (value === null || typeof value !== 'object') {
    return JSON.stringify(value)
  }

  if (Array.isArray(value)) {
    return `[${value.map((item) => stableStringify(item)).join(',')}]`
  }

  const entries = Object.entries(value).sort(([a], [b]) => a.localeCompare(b))
  return `{${entries
    .map(([key, val]) => `${JSON.stringify(key)}:${stableStringify(val)}`)
    .join(',')}}`
}

export async function buildFixtureSnapshot() {
  const bootstrapRaw = await readFile(
    resolve(workspaceRoot, 'app/lib/constants/bootstrap-data.ts'),
    'utf8',
  )
  const seedRaw = await readFile(
    resolve(workspaceRoot, 'app/lib/constants/seed-data.ts'),
    'utf8',
  )
  const protocolRaw = await readFile(
    resolve(workspaceRoot, 'app/lib/constants/protocol.ts'),
    'utf8',
  )

  let termIdMapRaw = null
  try {
    termIdMapRaw = await readFile(resolve(workspaceRoot, 'term-id-map.json'), 'utf8')
  } catch {
    termIdMapRaw = null
  }

  const snapshot = {
    note: 'Deterministic fixture snapshot for local agent harness',
    normalized: {
      bootstrapSourceSha256: createHash('sha256').update(bootstrapRaw).digest('hex'),
      seedSourceSha256: createHash('sha256').update(seedRaw).digest('hex'),
      protocolSourceSha256: createHash('sha256').update(protocolRaw).digest('hex'),
      termIdMapSha256: termIdMapRaw
        ? createHash('sha256').update(termIdMapRaw).digest('hex')
        : null,
      fixtureVersion,
    },
  }

  const canonical = stableStringify(snapshot)
  const snapshotHash = createHash('sha256').update(canonical).digest('hex')
  const metadata = {
    snapshotHash,
    snapshotBytes: Buffer.byteLength(canonical, 'utf8'),
    fixtureVersion,
  }

  return { snapshot, canonical, snapshotHash, metadata }
}

export async function writeFixtureSnapshot() {
  const { canonical, snapshotHash, metadata } = await buildFixtureSnapshot()
  await mkdir(outputDir, { recursive: true })
  await writeFile(outputPath, `${canonical}\n`)
  await writeFile(metadataPath, `${JSON.stringify(metadata, null, 2)}\n`)
  return { snapshotHash }
}

export async function readFixtureFiles() {
  const snapshotRaw = await readFile(outputPath, 'utf8')
  const metadataRaw = await readFile(metadataPath, 'utf8')
  return {
    snapshotRaw: snapshotRaw.trim(),
    metadata: JSON.parse(metadataRaw),
  }
}
