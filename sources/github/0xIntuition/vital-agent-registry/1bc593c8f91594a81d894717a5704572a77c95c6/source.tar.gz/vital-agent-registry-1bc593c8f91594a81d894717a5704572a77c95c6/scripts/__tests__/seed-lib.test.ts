import { describe, expect, it } from 'vitest'
import {
  buildSeedCoverageReport,
  buildSeedProfile,
  mergeSeedData,
  validateSeedCoverage,
} from '../seed-lib.mjs'

describe('seed-lib', () => {
  it('builds scenario coverage for discover/create/match/evidence', () => {
    const report = buildSeedCoverageReport(
      [
        {
          metadata: { name: 'Agent One' },
          capabilities: ['code-review'],
          skills: ['Skill One'],
        },
      ],
      [
        {
          metadata: { name: 'Skill One' },
          capabilities: ['code-review'],
        },
      ],
    )

    expect(report.summary.agents).toBe(1)
    expect(report.summary.skills).toBe(1)
    expect(report.scenarioCoverage.match.agents).toBe(1)
    expect(report.scenarioCoverage.evidence.entities).toBeGreaterThan(0)
    expect(report.entityCoverage['agent:Agent One']).toContain('discover')
    expect(report.entityCoverage['agent:Agent One']).toContain('create')
    expect(report.entityCoverage['agent:Agent One']).toContain('match')
    expect(report.entityCoverage['agent:Agent One']).toContain('evidence')
  })

  it('builds deterministic profile slices', () => {
    const baseAgents = [
      { metadata: { name: 'A1' }, capabilities: ['code-review'], skills: ['S1'] },
      { metadata: { name: 'A2' }, capabilities: ['code-review'], skills: ['S1'] },
      { metadata: { name: 'A3' }, capabilities: ['code-review'], skills: ['S2'] },
      { metadata: { name: 'A4' }, capabilities: ['code-review'], skills: ['S2'] },
      { metadata: { name: 'A5' }, capabilities: ['code-review'], skills: ['S3'] },
    ]
    const baseSkills = [
      { metadata: { name: 'S1' }, capabilities: ['code-review'] },
      { metadata: { name: 'S2' }, capabilities: ['code-review'] },
      { metadata: { name: 'S3' }, capabilities: ['code-review'] },
      { metadata: { name: 'S4' }, capabilities: ['code-review'] },
      { metadata: { name: 'S5' }, capabilities: ['code-review'] },
    ]

    const small = buildSeedProfile('small', baseAgents, baseSkills)
    expect(small.agents).toHaveLength(4)
    expect(small.skills).toHaveLength(4)

    const adversarial = buildSeedProfile('adversarial', baseAgents, baseSkills)
    expect(adversarial.agents.length).toBeGreaterThan(small.agents.length)
    expect(
      adversarial.agents.some((agent: any) =>
        agent.metadata.name.includes('Adversarial'),
      ),
    ).toBe(true)
  })

  it('merges base and corpus datasets without duplicate names', () => {
    const merged = mergeSeedData(
      [{ metadata: { name: 'A1' }, capabilities: [], skills: [] }],
      [{ metadata: { name: 'S1' }, capabilities: [] }],
      [{ metadata: { name: 'A1' }, capabilities: ['x'], skills: [] }],
      [{ metadata: { name: 'S2' }, capabilities: [] }],
    )

    expect(merged.agents).toHaveLength(1)
    expect(merged.skills).toHaveLength(2)
  })

  it('validates profile coverage thresholds', () => {
    const coverage = {
      summary: {
        agents: 3,
        skills: 3,
        uniqueCapabilities: 3,
        agentsWithSkills: 2,
      },
    }
    const gate = validateSeedCoverage(coverage as any, 'small')
    expect(gate.pass).toBe(false)
    expect(gate.failures.length).toBeGreaterThan(0)
  })
})
