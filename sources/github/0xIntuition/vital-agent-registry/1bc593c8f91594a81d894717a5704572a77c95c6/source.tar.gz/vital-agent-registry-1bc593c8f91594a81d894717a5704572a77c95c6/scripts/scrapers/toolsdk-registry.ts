/**
 * ToolSDK Registry scraper — raw GitHub JSON (4,521+ servers).
 * URL: https://raw.githubusercontent.com/toolsdk-ai/toolsdk-mcp-registry/main/registry.json
 */

import type { Corpus, CorpusSkill } from './types'
import { inferCapabilities, slugify } from './utils'

interface ToolsdkEntry {
  name?: string
  description?: string
  version?: string
  author?: string
  homepage?: string
  install?: string
  categories?: string[]
  tags?: string[]
}

export async function fetchToolsdkRegistry(limit = 500): Promise<Corpus> {
  const url =
    'https://raw.githubusercontent.com/toolsdk-ai/toolsdk-mcp-registry/main/registry.json'
  console.log(`[toolsdk] Fetching ${url} (limit=${limit})...`)

  const res = await fetch(url, {
    headers: { Accept: 'application/json' },
    signal: AbortSignal.timeout(30_000),
  })

  if (!res.ok) {
    console.warn(`[toolsdk] HTTP ${res.status} — skipping`)
    return { agents: [], skills: [] }
  }

  const raw = await res.json()

  // Registry may be an array or an object with an array field
  const entries: ToolsdkEntry[] = Array.isArray(raw)
    ? raw
    : (raw.servers ?? raw.entries ?? raw.data ?? [])

  const capped = entries.slice(0, limit)
  console.log(`[toolsdk] Processing ${capped.length} / ${entries.length} entries`)

  const skills: CorpusSkill[] = capped
    .filter((e) => e.name)
    .map((entry) => {
      const category = (entry.categories?.[0] ?? entry.tags?.[0] ?? '').toLowerCase()
      const installUri = entry.install?.startsWith('npx ')
        ? entry.install
        : entry.install?.startsWith('npm:')
          ? entry.install
          : undefined

      return {
        metadata: {
          '@type': 'Skill',
          name: `mcp-${slugify(entry.name!)}`,
          description: (entry.description ?? 'MCP server from ToolSDK registry').slice(0, 500),
          version: entry.version ?? '0.1.0',
          platform: 'mcp',
          author: entry.author ?? 'Unknown',
          ...(installUri ? { installUri } : {}),
        },
        capabilities: inferCapabilities(entry.name ?? '', entry.description ?? '', category),
      }
    })

  return { agents: [], skills }
}
