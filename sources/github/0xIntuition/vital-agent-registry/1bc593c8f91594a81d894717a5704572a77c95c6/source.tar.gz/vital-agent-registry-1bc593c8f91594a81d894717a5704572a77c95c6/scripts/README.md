# Agent Registry Scripts

This directory contains deployment and seeding scripts for the Agent Registry.

## Scripts

### bootstrap.ts

Creates all foundation atoms on the blockchain. Must be run first before seeding.

**Foundation atoms include:**
- 5 core predicates (relationship types): `is`, `has-capability`, `uses`, `has-metadata`, `created-by`
- 3 type atoms (Agent, Skill, Safe)
- 29 capabilities (common agent/skill capabilities)
- 5 platforms (skill runtime environments)

**Usage:**
```bash
# Local (default when NETWORK=local)
NETWORK=local PRIVATE_KEY=0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 pnpm tsx scripts/bootstrap.ts

# Testnet
PRIVATE_KEY=0x... pnpm tsx scripts/bootstrap.ts --network=testnet

# Mainnet
PRIVATE_KEY=0x... pnpm tsx scripts/bootstrap.ts --network=mainnet
```

**Remote-write guard (`RDL-003`):**
```bash
# Default local-safe mode blocks remote writes (skipped for local network)
NETWORK=local PRIVATE_KEY=0x... pnpm tsx scripts/bootstrap.ts

# Intentional override for shared infra writes
REGISTRY_WRITE_PROFILE=shared ALLOW_REMOTE_WRITES=1 PRIVATE_KEY=0x... pnpm tsx scripts/bootstrap.ts --network=testnet
```

**Output:**
- Console logs showing created atoms
- `term-id-map.json` file with atom name → term_id mappings
- `./.artifacts/bootstrap-report.json` machine-readable runtime/economics report

**Idempotency:** Safe to re-run. Checks on-chain `isTermCreated(termId)` before creating.

**Optional flags:**
```bash
# Custom output paths
NETWORK=local PRIVATE_KEY=0x... pnpm tsx scripts/bootstrap.ts --term-id-map=./term-id-map.json --report=./.artifacts/bootstrap-report.json
```

### seed.ts

Creates sample agents and skills with full triple relationships.

**Requires:**
- Bootstrap script must have run first
- `term-id-map.json` must exist

**Usage:**
```bash
# Local (default when NETWORK=local)
NETWORK=local PRIVATE_KEY=0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 pnpm tsx scripts/seed.ts

# Testnet
PRIVATE_KEY=0x... pnpm tsx scripts/seed.ts --network=testnet

# Mainnet
PRIVATE_KEY=0x... pnpm tsx scripts/seed.ts --network=mainnet

# Custom term-id-map location
NETWORK=local PRIVATE_KEY=0x... pnpm tsx scripts/seed.ts --term-id-map=./custom-path.json

# Seed profile (small|medium|large|adversarial)
NETWORK=local PRIVATE_KEY=0x... pnpm tsx scripts/seed.ts --profile=large

# Merge curated corpus snapshot into profile dataset
NETWORK=local PRIVATE_KEY=0x... pnpm tsx scripts/seed.ts --profile=medium --corpus=./.artifacts/seed-corpus.snapshot.json
```

**Remote-write guard (`RDL-003`):**
```bash
# Default local-safe mode blocks remote writes (skipped for local network)
NETWORK=local PRIVATE_KEY=0x... pnpm tsx scripts/seed.ts

# Intentional override for shared infra writes
REGISTRY_WRITE_PROFILE=shared ALLOW_REMOTE_WRITES=1 PRIVATE_KEY=0x... pnpm tsx scripts/seed.ts --network=testnet
```

**Creates:**
- 10 sample skills across different platforms (profile dependent)
- 10 sample agents with diverse capabilities (profile dependent)
- Type triples: [Entity] is-type [Agent/Skill]
- Capability triples: [Entity] has-capability [Capability]
- Skill usage triples: [Agent] uses-skill [Skill]
- `.artifacts/seed-report.json` (runtime + economics)
- `.artifacts/seed-coverage.report.json` (discover/create/match/evidence coverage)
- Coverage gate validation by profile (`small|medium|large|adversarial`) to ensure enough local test entities for wallet+tx flows

**Optional flags:**
```bash
NETWORK=local PRIVATE_KEY=0x... pnpm tsx scripts/seed.ts --report=./.artifacts/seed-report.json --coverage-report=./.artifacts/seed-coverage.report.json
NETWORK=local PRIVATE_KEY=0x... pnpm tsx scripts/seed.ts --profile=adversarial --allow-coverage-failure
```

### import-corpus.mjs

Imports a curated corpus snapshot for deterministic local seeding.

**Purpose:**
- Keep test runs deterministic while allowing realistic tool/agent samples from external sources.
- Avoid live scraping dependency during test execution.

**Usage:**
```bash
# Normalize and snapshot a corpus JSON file
pnpm seed:corpus:import -- --input=./data/corpus.raw.json --source=motherdao-tools

# Custom output path
pnpm seed:corpus:import -- --input=./data/corpus.raw.json --output=./.artifacts/seed-corpus.snapshot.json --source=custom
```

**Expected input shape:**
```json
{
  "agents": [{ "metadata": { "name": "..." }, "capabilities": [], "skills": [] }],
  "skills": [{ "metadata": { "name": "..." }, "capabilities": [] }]
}
```

**Output:**
- `./.artifacts/seed-corpus.snapshot.json` with normalized agents/skills, provenance metadata, and deterministic hash logging.

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `PRIVATE_KEY` | Yes | Wallet private key (must start with `0x`) |
| `NETWORK` | No | `local` (default), `testnet`, or `mainnet` |
| `TERM_ID_MAP` | No | Path to term-id-map.json (seed.ts only) |
| `REGISTRY_WRITE_PROFILE` | No | `local` (default, safe) or `shared` |
| `ALLOW_REMOTE_WRITES` | No | Must be `1` to allow remote writes |
| `LOCAL_CHAIN_RPC_URL` | No | Local Anvil RPC URL (default: http://localhost:8545) |
| `LOCAL_MULTIVAULT_ADDRESS` | No | Local MultiVault contract address (default: 0x5FbDB2315678afecb367f032d93F642f64180aa3) |

## Deployment Workflow

1. Run bootstrap script to create foundation atoms
2. Copy term_ids from `term-id-map.json` to `app/lib/constants/protocol.ts`
3. Run seed script to populate with sample data
4. Verify entities in the registry UI

## Dependencies

These scripts depend on modules created by Agent A:
- `app/.server/viem.ts` - Viem client configuration
- `app/.server/multivault.ts` - Contract interaction functions
- `app/.server/ipfs.ts` - IPFS upload functions
- `app/lib/id-conversion.ts` - ID conversion utilities

**Note:** Scripts are excluded from TypeScript checking (`tsconfig.json`) since they depend on modules that may not exist during development.

### local-stack.sh

Coordinates a local-first stack bootstrap for registry development by reusing the backend infrastructure scripts in `repos/intuition-rs`.

**Commands:**
```bash
# Start local backend stack + generate deterministic fixture snapshot + health check
pnpm local:stack:up

# Regenerate deterministic fixture snapshot artifacts
pnpm local:fixtures

# Fail if fixture snapshot/metadata drift from deterministic inputs
pnpm fixtures:verify

# Print current GraphQL state fingerprint hash
pnpm local:state:fingerprint

# Health checks only (Hasura + GraphQL)
pnpm local:stack:health

# Assert stable term IDs + vault state across two clean reruns
pnpm local:stack:rerun-verify

# Stop local backend stack
pnpm local:stack:down
```

**What `up` does:**
1. Prebuilds missing backend images locally (unless `LOCAL_STACK_SKIP_IMAGE_BUILD=1`)
2. Builds `contract-deployer-2-0` image from local `repos/intuition-contracts-v2` when needed
3. Runs `cargo make start-local` in `repos/intuition-rs` (falls back to `scripts/start.sh local` when `cargo-make` is unavailable)
4. Generates `.artifacts/local-fixtures.snapshot.json`
5. Verifies Hasura and GraphQL health endpoints
6. Prints next step for running the app server in a separate terminal

**Deterministic fixture drift checks (`RDL-002`):**
- `pnpm local:fixtures` writes a canonical snapshot and metadata hash.
- `pnpm fixtures:verify` recomputes expected output and exits non-zero on drift.
- Hash inputs currently include:
  - `app/lib/constants/bootstrap-data.ts`
  - `app/lib/constants/seed-data.ts`
  - `app/lib/constants/protocol.ts`
  - `term-id-map.json` (when present)
- `pnpm local:stack:rerun-verify` performs two full clean cycles (`down` + `up`) and compares a GraphQL state fingerprint hash built from sorted atom/triple/vault rows and aggregate counts.
  - If `atom/triple/vault` roots are unavailable in the current Hasura profile, the fingerprint script falls back to hashing the available root field set plus `cached_images` rows.

**Docker credential helper fallback:**
- `local-stack.sh` defaults to an isolated Docker config (`LOCAL_STACK_USE_ISOLATED_DOCKER_CONFIG=1`) under `.artifacts/docker-config` to avoid host credential-helper failures during image builds.
- Set `LOCAL_STACK_USE_ISOLATED_DOCKER_CONFIG=0` to use your host Docker config.

**Troubleshooting missing GHCR images:**
If you see `ghcr.io/0xintuition/*:latest not found` or `denied`, run:
```bash
pnpm local:stack:up
```
The script now builds missing images locally using the `intuition-rs` Dockerfiles.
If `contract-deployer-2-0` fails during `npm install`, the script retries with a fallback Dockerfile that uses vendored dependencies or pnpm install.

If you need to skip auto-build behavior:
```bash
LOCAL_STACK_SKIP_IMAGE_BUILD=1 pnpm local:stack:up
```

**Requirements for local contract deployer image:**
- `repos/intuition-contracts-v2` must exist locally

**Notes:**
- This command does not start the React Router dev server; run `pnpm -C apps/agent-registry dev` separately.
- Requires Docker and curl.
- Endpoint overrides: `HASURA_HEALTH_URL`, `GRAPHQL_URL`.

### local-agent-harness.mjs

Runs the `RDL-004` local agent E2E harness against the running registry API.

**What it validates:**
- Deterministic fixture snapshot is present and matches current canonical inputs
- Three personas execute distinct workflows:
  - `scout`: discover agents, retrieve evidence (triples), read stake/trust signal
  - `builder`: discover capabilities, run create-registration flow, run capability match
  - `auditor`: discover skills, verify skill safety, verify stake-oriented sorting
- Workflow coverage gates: discover/create/stake/verify/match/evidence
- Machine-readable report written to `.artifacts/local-agent-harness.report.json`

**Usage:**
```bash
# Default local run
pnpm local:harness

# Strict mode (create must succeed, guarded 403 is treated as failure)
pnpm local:harness -- --strict-create

# Custom base URL and output report path
pnpm local:harness -- --base-url http://localhost:4101 --output /tmp/rdl004-report.json

# Emit single-line JSON to stdout (for CI log ingestion)
pnpm local:harness -- --json
```

### local-shared-parity.mjs

Runs the `RDL-005` parity suite to compare local GraphQL contract/indexer surfaces against a shared backend.

**What it validates:**
- Query root parity for registry-critical roots (`atom`, `atoms`, aggregates, `triple`, `vault`)
- Core type-field parity for `atom`, `triple`, `vault`
- Local-only/shared-only surface diff report
- Pass artifact for shared-write preflight gate

**Usage:**
```bash
# Compare local Hasura to shared backend and write report + pass artifact
pnpm local:parity -- --shared-url https://<shared-hasura>/v1/graphql

# Override local URL
pnpm local:parity -- --local-url http://localhost:8080/v1/graphql --shared-url https://<shared-hasura>/v1/graphql

# Emit JSON to stdout for CI
pnpm local:parity -- --shared-url https://<shared-hasura>/v1/graphql --json
```

**Artifacts:**
- `.artifacts/local-shared-parity.report.json`
- `.artifacts/local-shared-parity.pass.json` (only written on pass)

## Shared-Write Gate

`bootstrap.ts` and `seed.ts` now enforce a parity gate when `REGISTRY_WRITE_PROFILE=shared`.

- Gate checks `.artifacts/local-shared-parity.pass.json`
- Pass file must be `status: pass` and fresh (<= 24h old)
- To proceed after drift/staleness, re-run parity:
```bash
pnpm local:parity -- --shared-url https://<shared-hasura>/v1/graphql
```

**Emergency bypass (discouraged):**
```bash
BYPASS_PARITY_GATE=1 REGISTRY_WRITE_PROFILE=shared ALLOW_REMOTE_WRITES=1 ...
```

## Parity Failure Runbook

1. Run parity and inspect `.artifacts/local-shared-parity.report.json`.
2. Prioritize `comparison.contractMissingShared` for shared testnet compatibility breaks.

### local-wallet-bootstrap.mjs

Builds a local wallet readiness/funding report for deterministic test wallets.

**Why this exists:**
- Agent onboarding and transaction tests require wallets with enough balance.
- This script checks wallet balances on local RPC and reports deficits before running tx flows.

**Usage:**
```bash
# Default local chain check (http://localhost:8545), require 1 ETH per wallet
pnpm local:wallets:plan

# Custom required balance
pnpm local:wallets:plan -- --required-eth=2

# Custom RPC and output artifact
pnpm local:wallets:plan -- --rpc-url=http://localhost:8545 --output=./.artifacts/local-wallet-bootstrap.report.json
```

**Environment overrides:**
- `LOCAL_CHAIN_RPC_URL` (default `http://localhost:8545`)
- `LOCAL_TEST_WALLETS_JSON` (JSON array of `{id,label,privateKey}` entries)

**Artifact:**
- `.artifacts/local-wallet-bootstrap.report.json`

### local-wallet-fund.mjs

Funds underfunded local test wallets up to a required per-wallet ETH balance.

**Usage:**
```bash
# Fund wallets to 0.1 ETH each (from agent-001)
pnpm local:wallets:fund -- --required-eth=0.1

# Dry-run only (no transactions)
pnpm local:wallets:fund -- --required-eth=0.1 --dry-run

# Custom funding source and output
pnpm local:wallets:fund -- --required-eth=0.25 --from-id=agent-001 --output=./.artifacts/local-wallet-bootstrap.funding-report.json
```

**Environment overrides:**
- `LOCAL_CHAIN_RPC_URL` (default `http://localhost:8545`)
- `LOCAL_TEST_WALLETS_JSON` (JSON array of `{id,label,privateKey}` entries)

**Artifact:**
- `.artifacts/local-wallet-bootstrap.funding-report.json`

### local-execute-smoke.mjs

Runs a local execute-mode smoke test for the core write loop:
1. `POST /api/v1/agents/register?execute=true`
2. `POST /api/v1/trust/stake`
3. Optional readback polling via `GET /api/v1/agents/:id`

**Usage:**
```bash
# Default local smoke run (best-effort readback)
pnpm local:execute:smoke

# Strict readback mode (fails if readback does not appear within retry window)
pnpm local:execute:smoke -- --strict-readback

# Custom base URL, stake amount, and output artifact
pnpm local:execute:smoke -- --base-url http://localhost:4101 --stake-amount-eth 0.002 --output /tmp/local-execute-smoke.json

# Skip readback when validating chain writes only
pnpm local:execute:smoke -- --skip-readback --json
```

**Artifact:**
- `.artifacts/local-execute-smoke.report.json`

### local-execute-populate.mjs

Seeds local registry data by running execute-mode write loops repeatedly.

Each iteration runs:
1. `POST /api/v1/agents/register?execute=true`
2. `POST /api/v1/trust/stake`

This is useful for generating enough live data to test list/detail/match and frontend ranking behavior.

**Usage:**
```bash
# Create and stake 10 agents
pnpm local:execute:populate

# Seed 25 agents with larger stake
pnpm local:execute:populate -- --count 25 --stake-amount-eth 0.002

# Custom output artifact + JSON stdout
pnpm local:execute:populate -- --count 5 --output /tmp/local-populate.json --json
```

**Artifact:**
- `.artifacts/local-execute-populate.report.json`

### local-agent-test-prep.mjs

Orchestrates local test readiness for agent testing in one command:
1. Stack health check
2. Wallet funding
3. Execute-mode data population
4. Harness validation

**Usage:**
```bash
# Full local prep workflow
pnpm local:agent:test:prep

# Tune funding and seeded volume
pnpm local:agent:test:prep -- --required-eth 0.2 --populate-count 25 --populate-stake-eth 0.002

# Skip selected steps
pnpm local:agent:test:prep -- --skip-health --skip-harness
```

**Artifact:**
- `.artifacts/local-agent-test-prep.report.json`

### hard-checkpoint.mjs

Runs a release-readiness hard checkpoint and writes a machine-readable report.

**Usage:**
```bash
# Full checkpoint (typecheck + tests + stack health + local harness)
pnpm local:checkpoint

# Quick checkpoint (typecheck + tests only)
pnpm local:checkpoint -- --skip-health --skip-harness

# Include execute-write smoke (register execute + stake execute)
pnpm local:checkpoint -- --include-execute-smoke

# Emit single-line JSON
pnpm local:checkpoint -- --json
```

**Artifact:**
- `.artifacts/hard-checkpoint.report.json`

## Discovery Endpoint Contract (`RDL-028`)

`/.well-known/agent.json` is the machine discovery contract for both local and shared profiles.

- Local profile: `http://localhost:4101/.well-known/agent.json`
- Shared profile: `https://registry.intuition.systems/.well-known/agent.json`

Behavior:
- `GET /.well-known/agent.json` returns the registry card (`200`) with `Content-Type: application/json` and CORS headers.
- `GET /.well-known/agent.json?id=<termId>` returns the agent card (`200`) when the repository can resolve an A2A card.
- Unknown/missing card returns deterministic `404` payload:
  - `{ "error": "Agent not found", "code": "NOT_FOUND", "id": "<termId>" }`
3. If query roots are missing, verify shared Hasura metadata/migrations and backend profile.
4. If type fields are missing, diff local vs shared schema versions and apply the required migration set.
5. Re-run parity until `summary.status = pass` and pass artifact is refreshed.
6. Retry shared write operations (`bootstrap.ts`/`seed.ts`).
