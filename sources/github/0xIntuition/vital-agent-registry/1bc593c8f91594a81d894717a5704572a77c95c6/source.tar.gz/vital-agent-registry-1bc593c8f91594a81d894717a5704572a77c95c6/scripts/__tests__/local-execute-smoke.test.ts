import { describe, expect, it } from 'vitest'
import { parseArgs } from '../local-execute-smoke.mjs'

describe('local-execute-smoke', () => {
  it('parses defaults', () => {
    const args = parseArgs([])
    expect(args.baseUrl).toBe('http://localhost:4101')
    expect(args.timeoutMs).toBe(15_000)
    expect(args.stakeAmountEth).toBe('0.001')
    expect(args.readbackRetries).toBe(20)
    expect(args.readbackDelayMs).toBe(1000)
    expect(args.strictReadback).toBe(false)
    expect(args.skipReadback).toBe(false)
    expect(args.json).toBe(false)
    expect(args.output).toContain('.artifacts/local-execute-smoke.report.json')
  })

  it('parses override flags', () => {
    const args = parseArgs([
      '--base-url',
      'http://localhost:9999',
      '--timeout-ms',
      '5000',
      '--stake-amount-eth',
      '0.02',
      '--readback-retries',
      '7',
      '--readback-delay-ms',
      '250',
      '--strict-readback',
      '--skip-readback',
      '--json',
      '--output',
      '/tmp/smoke.json',
    ])

    expect(args.baseUrl).toBe('http://localhost:9999')
    expect(args.timeoutMs).toBe(5000)
    expect(args.stakeAmountEth).toBe('0.02')
    expect(args.readbackRetries).toBe(7)
    expect(args.readbackDelayMs).toBe(250)
    expect(args.strictReadback).toBe(true)
    expect(args.skipReadback).toBe(true)
    expect(args.json).toBe(true)
    expect(args.output).toBe('/tmp/smoke.json')
  })
})
