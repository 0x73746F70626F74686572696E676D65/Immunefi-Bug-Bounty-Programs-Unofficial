#!/usr/bin/env tsx
// @ts-nocheck - script runtime with env-dependent chain IO

import { mkdir, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import {
  createRegistryPublicClient,
  createRegistryWalletClient,
} from '../app/.server/viem'
import { createAtoms, getAtomCost } from '../app/.server/multivault'
import { getAllFoundationAtoms } from '../app/lib/constants/bootstrap-data'
import { CONTRACTS, getContractAddress } from '../app/lib/constants/protocol'
import { assertRemoteWriteAllowed } from '../app/.server/remote-write-guard'
import { assertSharedWriteParityGate } from './parity-gate'
import { pollIndexerForTermId } from '../app/lib/indexer-poller'
import { deriveAtomTermId } from '../app/lib/calldata'
import {
  partitionBootstrapEntries,
  summarizeByCategory,
  toStableTermIdMap,
} from './bootstrap-lib.mjs'
import { multivaultAbi } from '../app/lib/abis/multivault'

function parseArgs(argv: string[]) {
  const networkFlag = argv.find((arg) => arg.startsWith('--network='))
  const mapPathFlag = argv.find((arg) => arg.startsWith('--term-id-map='))
  const reportPathFlag = argv.find((arg) => arg.startsWith('--report='))
  return {
    network: networkFlag?.split('=')[1] || process.env.NETWORK || 'local',
    termIdMapPath: mapPathFlag?.split('=')[1] || './term-id-map.json',
    reportPath: reportPathFlag?.split('=')[1] || './.artifacts/bootstrap-report.json',
  }
}

function chunk<T>(values: T[], size: number): T[][] {
  const out: T[][] = []
  for (let i = 0; i < values.length; i += size) {
    out.push(values.slice(i, i + size))
  }
  return out
}

async function fetchExistingTermIds(
  publicClient: ReturnType<typeof createRegistryPublicClient>,
  contractAddress: `0x${string}`,
  termIds: `0x${string}`[],
) {
  const checks = await Promise.all(
    termIds.map(async (termId) => {
      try {
        const exists = await publicClient.readContract({
          address: contractAddress,
          abi: multivaultAbi,
          functionName: 'isTermCreated',
          args: [termId],
        })
        return exists ? termId : null
      } catch {
        return null
      }
    }),
  )
  return new Set(checks.filter(Boolean))
}

async function main() {
  const startedAt = new Date()
  const startedMs = Date.now()
  const args = parseArgs(process.argv.slice(2))

  if (args.network !== 'testnet' && args.network !== 'mainnet' && args.network !== 'local') {
    throw new Error(`Invalid network: ${args.network}. Must be 'testnet', 'mainnet', or 'local'`)
  }

  // Skip remote write guard for local network
  if (args.network !== 'local') {
    assertRemoteWriteAllowed({
      action: 'bootstrap foundation atoms',
      target: `chain:${args.network}`,
    })
    await assertSharedWriteParityGate({
      action: 'bootstrap foundation atoms',
    })
  }

  const privateKey = process.env.PRIVATE_KEY
  if (!privateKey) {
    throw new Error('PRIVATE_KEY environment variable is required')
  }

  const contractAddress = getContractAddress(args.network)

  const publicClient = createRegistryPublicClient(args.network)
  const walletClient = createRegistryWalletClient(privateKey, args.network)
  const [deployer] = await walletClient.getAddresses()

  console.log(`\n🚀 Bootstrap Script`)
  console.log(`Network: ${args.network}`)
  console.log(`Deployer: ${deployer}`)
  console.log(`MultiVault: ${contractAddress}\n`)

  const foundationAtoms = getAllFoundationAtoms()
  const foundationEntries = foundationAtoms.map((atom) => ({
    ...atom,
    termId: deriveAtomTermId(atom.name),
  }))
  const categoryTotals = summarizeByCategory(foundationEntries)

  console.log(`📋 Foundation atoms: ${foundationEntries.length}`)
  console.log(`   - Predicates: ${categoryTotals.predicate}`)
  console.log(`   - Types: ${categoryTotals.type}`)
  console.log(`   - Capabilities: ${categoryTotals.capability}`)
  console.log(`   - Platforms: ${categoryTotals.platform}\n`)

  const existingTermIds = await fetchExistingTermIds(
    publicClient,
    contractAddress,
    foundationEntries.map((entry) => entry.termId),
  )
  const plan = partitionBootstrapEntries(foundationEntries, existingTermIds)
  const planByCategory = summarizeByCategory(plan.toCreate)
  const skippedByCategory = summarizeByCategory(plan.existing)

  console.log(`🧪 Existing on-chain: ${plan.existing.length}`)
  console.log(`📝 To create: ${plan.toCreate.length}\n`)

  const transactions: Array<{
    category: string
    hash: string
    atomCount: number
    runtimeMs: number
  }> = []

  const failedByCategory = {
    predicate: 0,
    type: 0,
    capability: 0,
    platform: 0,
  }
  let createdCount = 0

  const grouped = {
    predicate: plan.toCreate.filter((entry) => entry.category === 'predicate'),
    type: plan.toCreate.filter((entry) => entry.category === 'type'),
    capability: plan.toCreate.filter((entry) => entry.category === 'capability'),
    platform: plan.toCreate.filter((entry) => entry.category === 'platform'),
  }

  for (const [category, entries] of Object.entries(grouped)) {
    if (entries.length === 0) continue

    for (const batch of chunk(entries, 25)) {
      const runtimeStart = Date.now()
      try {
        const result = await createAtoms(
          publicClient,
          walletClient,
          contractAddress,
          batch.map((entry) => entry.name),
          0n,
        )
        createdCount += batch.length
        transactions.push({
          category,
          hash: result.hash,
          atomCount: batch.length,
          runtimeMs: Date.now() - runtimeStart,
        })
        console.log(`✅ ${category} batch created (${batch.length}) tx=${result.hash}`)
      } catch (error) {
        failedByCategory[category as keyof typeof failedByCategory] += batch.length
        console.error(`❌ ${category} batch failed (${batch.length})`, error)
      }
    }

    const graphqlUrl = process.env.GRAPHQL_API_URL_PRIVATE
    const first = entries[0]
    if (graphqlUrl && first) {
      const indexed = await pollIndexerForTermId(graphqlUrl, first.termId, {
        maxRetries: 6,
        initialDelayMs: 300,
        maxDelayMs: 3000,
      })
      console.log(`   🔎 indexer visibility (${first.name}): ${indexed ? 'ok' : 'timeout'}`)
    }
  }

  const termIdMap = toStableTermIdMap(foundationEntries)
  const termIdMapPath = resolve(process.cwd(), args.termIdMapPath)
  await mkdir(resolve(termIdMapPath, '..'), { recursive: true }).catch(() => {})
  await writeFile(termIdMapPath, `${JSON.stringify(termIdMap, null, 2)}\n`)

  const atomCost = await getAtomCost(publicClient, contractAddress).catch(() => 0n)
  const finishedMs = Date.now()
  const report = {
    network: args.network,
    contractAddress,
    startedAt: startedAt.toISOString(),
    finishedAt: new Date(finishedMs).toISOString(),
    runtimeMs: finishedMs - startedMs,
    totals: {
      foundationAtoms: foundationEntries.length,
      existingLogicalAtoms: plan.existing.length,
      plannedCreates: plan.toCreate.length,
      created: createdCount,
      failed: Object.values(failedByCategory).reduce((sum, value) => sum + value, 0),
    },
    categories: {
      total: categoryTotals,
      planned: planByCategory,
      skippedExisting: skippedByCategory,
      failed: failedByCategory,
    },
    economics: {
      atomCostWei: atomCost.toString(),
      estimatedCreateValueWei: (atomCost * BigInt(createdCount)).toString(),
    },
    transactions,
  }

  const reportPath = resolve(process.cwd(), args.reportPath)
  await mkdir(resolve(reportPath, '..'), { recursive: true }).catch(() => {})
  await writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`)

  console.log(`\n📄 Term ID map: ${termIdMapPath}`)
  console.log(`📊 Bootstrap report: ${reportPath}`)
  console.log(
    `✅ Completed: created=${report.totals.created} skipped=${report.totals.existingLogicalAtoms} failed=${report.totals.failed}`,
  )
}

main().catch((error) => {
  console.error('❌ Bootstrap failed:', error)
  process.exit(1)
})
