#!/usr/bin/env node

import { mkdir, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { runSmoke } from './local-execute-smoke.mjs'

const DEFAULT_OUTPUT = '.artifacts/local-execute-populate.report.json'

export function parseArgs(argv) {
  const args = {
    count: 10,
    baseUrl: 'http://localhost:4101',
    timeoutMs: 15_000,
    stakeAmountEth: '0.001',
    output: DEFAULT_OUTPUT,
    json: false,
  }

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i]
    if (arg === '--') continue
    if (arg === '--count') {
      args.count = Number(argv[i + 1] || args.count)
      i += 1
      continue
    }
    if (arg === '--base-url') {
      args.baseUrl = argv[i + 1] || args.baseUrl
      i += 1
      continue
    }
    if (arg === '--timeout-ms') {
      args.timeoutMs = Number(argv[i + 1] || args.timeoutMs)
      i += 1
      continue
    }
    if (arg === '--stake-amount-eth') {
      args.stakeAmountEth = argv[i + 1] || args.stakeAmountEth
      i += 1
      continue
    }
    if (arg === '--output') {
      args.output = argv[i + 1] || args.output
      i += 1
      continue
    }
    if (arg === '--json') {
      args.json = true
    }
  }

  return args
}

export async function runPopulate(args) {
  const startedAt = new Date().toISOString()
  const runs = []

  for (let i = 0; i < args.count; i += 1) {
    const run = await runSmoke({
      baseUrl: args.baseUrl,
      timeoutMs: args.timeoutMs,
      stakeAmountEth: args.stakeAmountEth,
      readbackRetries: 1,
      readbackDelayMs: 1,
      strictReadback: false,
      skipReadback: true,
      output: '/dev/null',
      json: false,
    })
    runs.push({
      index: i + 1,
      status: run.status,
      checks: run.checks,
      context: run.context,
    })
  }

  const passed = runs.filter((run) => run.status === 'pass').length
  const failed = runs.length - passed

  return {
    status: failed === 0 ? 'pass' : passed > 0 ? 'partial' : 'fail',
    startedAt,
    completedAt: new Date().toISOString(),
    summary: {
      requested: args.count,
      passed,
      failed,
    },
    runs,
  }
}

async function main() {
  const args = parseArgs(process.argv.slice(2))
  const report = await runPopulate(args)

  const outputPath = resolve(args.output)
  await mkdir(dirname(outputPath), { recursive: true })
  await writeFile(outputPath, `${JSON.stringify(report, null, 2)}\n`, 'utf8')

  if (args.json) {
    process.stdout.write(`${JSON.stringify(report)}\n`)
  } else {
    process.stdout.write(
      `[local-execute-populate] status=${report.status} requested=${report.summary.requested} passed=${report.summary.passed} failed=${report.summary.failed}\n`,
    )
    process.stdout.write(`[local-execute-populate] report=${outputPath}\n`)
  }

  if (report.status === 'fail') {
    process.exitCode = 1
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main()
}
