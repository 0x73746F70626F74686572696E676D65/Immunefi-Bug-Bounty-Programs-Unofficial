/**
 * x402 Bazaar scraper — Coinbase CDP discovery API.
 * API: GET https://api.cdp.coinbase.com/platform/v2/x402/discovery/resources
 *
 * x402 is the pay-per-use HTTP payment protocol for AI agents.
 * No auth required for the discovery endpoint.
 */

import type { Corpus, CorpusSkill } from './types'
import { extractDomain, inferCapabilitiesFromX402Type, slugify, sleep } from './utils'

interface X402Resource {
  url?: string
  name?: string
  description?: string
  type?: string
  pricing?: {
    amount?: string
    currency?: string
    scheme?: string
  }
  input_schema?: unknown
  output_schema?: unknown
}

interface X402DiscoveryResponse {
  resources?: X402Resource[]
  next_offset?: number
  total?: number
}

export async function fetchX402Bazaar(pageLimit = 5): Promise<Corpus> {
  const baseUrl = 'https://api.cdp.coinbase.com/platform/v2/x402/discovery/resources'
  const pageSize = 100
  const allResources: X402Resource[] = []

  console.log(`[x402-bazaar] Fetching x402 discovery resources...`)

  for (let page = 0; page < pageLimit; page++) {
    const offset = page * pageSize
    const url = `${baseUrl}?limit=${pageSize}&offset=${offset}`

    try {
      const res = await fetch(url, {
        headers: { Accept: 'application/json' },
        signal: AbortSignal.timeout(15_000),
      })

      if (!res.ok) {
        if (page === 0) {
          console.warn(`[x402-bazaar] HTTP ${res.status} — endpoint may be unavailable`)
        }
        break
      }

      const data: X402DiscoveryResponse = await res.json()
      const resources = data.resources ?? []

      if (resources.length === 0) break

      allResources.push(...resources)
      console.log(`[x402-bazaar] Page ${page + 1}: got ${resources.length} resources`)

      // Stop if we got fewer results than requested (last page)
      if (resources.length < pageSize) break

      // Be polite between pages
      if (page < pageLimit - 1) await sleep(300)
    } catch (err) {
      if (page === 0) {
        console.warn(`[x402-bazaar] Fetch error: ${err instanceof Error ? err.message : err}`)
      }
      break
    }
  }

  console.log(`[x402-bazaar] Total resources: ${allResources.length}`)

  const skills: CorpusSkill[] = allResources
    .filter((r) => r.url)
    .map((resource) => {
      const domain = extractDomain(resource.url!)
      const name = resource.name ? slugify(resource.name) : slugify(domain)

      return {
        metadata: {
          '@type': 'Skill',
          name: `x402-${name}`,
          description: (
            resource.description ?? `x402 pay-per-use service at ${resource.url}`
          ).slice(0, 500),
          version: '1.0.0',
          platform: 'x402',
          author: domain,
          installUri: resource.url,
        },
        capabilities: inferCapabilitiesFromX402Type(resource.type ?? '', resource.description ?? ''),
      }
    })

  return { agents: [], skills }
}
