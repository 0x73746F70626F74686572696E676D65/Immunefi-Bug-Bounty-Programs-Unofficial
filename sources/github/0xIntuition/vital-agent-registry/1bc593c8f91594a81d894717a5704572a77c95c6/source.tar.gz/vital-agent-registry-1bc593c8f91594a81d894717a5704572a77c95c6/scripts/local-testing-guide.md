# Local Testing Guide

This guide explains how to set up a local development environment for the agent-registry with test data.

## Prerequisites

- Docker and Docker Compose
- Node.js and pnpm
- Access to `repos/intuition-contracts-v2` and `repos/intuition-rs` (via symlinks)

## Quick Start

```bash
# 1. Start the local stack (Anvil + Indexer + Hasura)
bash scripts/local-stack.sh up

# 2. In a new terminal, run bootstrap + seed
NETWORK=local PRIVATE_KEY=0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 pnpm tsx scripts/local-bootstrap-and-seed.ts

# 3. Start the frontend dev server
pnpm -C apps/agent-registry dev
```

## Step 1: Start the Local Stack

The local stack includes:
- **Anvil**: Local EVM chain (chain ID 31337)
- **PostgreSQL**: Database for indexed data
- **Hasura**: GraphQL engine
- **Indexer**: Consumer that indexes blockchain events

```bash
# Start all services
bash scripts/local-stack.sh up

# Check health
bash scripts/local-stack.sh health

# Stop all services
bash scripts/local-stack.sh down
```

### Environment Variables for Local Stack

| Variable | Default | Description |
|----------|---------|-------------|
| `LOCAL_CHAIN_RPC_URL` | http://localhost:8545 | Local Anvil RPC URL |
| `LOCAL_MULTIVAULT_ADDRESS` | 0x5FbDB2315678afecb367f032d93F642f64180aa3 | MultiVault contract address |
| `HASURA_HEALTH_URL` | http://localhost:8080/healthz | Hasura health check URL |
| `GRAPHQL_URL` | http://localhost:8080/v1/graphql | GraphQL endpoint |

### Troubleshooting Local Stack

**Port conflicts**: The script automatically cleans up common conflicting containers (database, hasura, etc.). If you have other services on ports 8545 or 8080, stop them first.

**Image build failures**: If GHCR images can't be pulled, the script will attempt to build them locally:
```bash
LOCAL_STACK_SKIP_IMAGE_BUILD=1 bash scripts/local-stack.sh up  # Skip auto-build
```

## Step 2: Run Bootstrap

Bootstrap creates foundation atoms on the local chain:

- **Predicates**: `is`, `has-capability`, `uses`, `has-metadata`, `created-by`
- **Types**: `Agent`, `Skill`, `Safe`
- **Capabilities**: 29 common capabilities (coding, reasoning, web3, etc.)
- **Platforms**: 5 skill runtime environments

```bash
# Run bootstrap (default network is now 'local')
NETWORK=local PRIVATE_KEY=0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 \
  pnpm tsx scripts/bootstrap.ts

# With custom output path
NETWORK=local PRIVATE_KEY=0x... pnpm tsx scripts/bootstrap.ts --term-id-map=./term-id-map.json
```

Output:
- `term-id-map.json`: Maps atom names to term IDs
- `.artifacts/bootstrap-report.json`: Runtime and economics report

## Step 3: Run Seed

Seed creates sample agents and skills with full triple relationships:

```bash
# Run seed (requires term-id-map.json from bootstrap)
NETWORK=local PRIVATE_KEY=0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 \
  pnpm tsx scripts/seed.ts

# With custom profile
NETWORK=local PRIVATE_KEY=0x... pnpm tsx scripts/seed.ts --profile=large
```

Profile options:
- `small`: 3 agents, 3 skills
- `medium` (default): 10 agents, 10 skills
- `large`: 25 agents, 25 skills

## Combined Bootstrap + Seed

For convenience, run both in one command:

```bash
NETWORK=local PRIVATE_KEY=0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 \
  pnpm tsx scripts/local-bootstrap-and-seed.ts
```

This script:
1. Runs bootstrap to create foundation atoms
2. Runs seed to create sample agents and skills
3. Generates `term-id-map.json`

## Default Wallet

The local Anvil chain comes pre-funded with the default account:

| Property | Value |
|----------|-------|
| Address | 0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266 |
| Private Key | 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 |

This is the same key used by the deployer when contracts are deployed.

## Verifying Setup

### Check GraphQL Data

```bash
# Query atoms
curl -X POST http://localhost:8080/v1/graphql \
  -H "Content-Type: application/json" \
  -d '{"query": "{ atoms(limit: 5) { id termId name } }"}'

# Query triples
curl -X POST http://localhost:8080/v1/graphql \
  -H "Content-Type: application/json" \
  -d '{"query": "{ triples(limit: 5) { id subjectId predicateId objectId } }"}'
```

### Check Local Stack Health

```bash
bash scripts/local-stack.sh health
```

## Common Issues

### "Invalid network: local"

The bootstrap/seed scripts need to be updated to support 'local'. If you see this error, ensure you've pulled the latest code changes.

### Contract address mismatch

If the contract address doesn't match, set it explicitly:

```bash
LOCAL_MULTIVAULT_ADDRESS=0xYourAddress NETWORK=local PRIVATE_KEY=0x... \
  pnpm tsx scripts/bootstrap.ts
```

### Indexer not catching up

The indexer may take a few seconds to process blocks. Check logs:

```bash
docker logs consumer --tail 50
```

## Network Configuration

| Network | Chain ID | RPC URL | MultiVault |
|----------|----------|---------|------------|
| local | 31337 | http://localhost:8545 | 0x5FbDB... |
| testnet | 13579 | https://testnet.rpc.intuition.systems/ | 0xB92EA... |
| mainnet | 1155 | https://mainnet.rpc.intuition.systems/ | 0x6E35c... |

## Next Steps

After setup:
1. Run `pnpm -C apps/agent-registry dev` to start the frontend
2. Open http://localhost:5173 (or the port shown)
3. Connect your wallet (import the default Anvil key above)
