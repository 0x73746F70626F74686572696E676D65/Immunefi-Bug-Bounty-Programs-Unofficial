#!/usr/bin/env tsx
// @ts-nocheck - script runtime with env-dependent chain IO

/**
 * Local E2E Orchestrator
 *
 * Comprehensive test orchestrator that runs all backend tests and logs results.
 *
 * Tests:
 * 1. Environment Setup - Check that local stack is running
 * 2. Bootstrap Test - Run bootstrap and verify foundation atoms created correctly
 * 3. Seed Test - Run seed and verify agents/skills created
 * 4. API Tests - Test various API endpoints
 * 5. GraphQL Tests - Query the indexer
 * 6. Staking Tests - Test staking flow
 * 7. Multi-Agent Tests - Run the multi-agent interaction test
 *
 * Usage:
 *   NETWORK=local PRIVATE_KEY=0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 \
 *     pnpm tsx scripts/local-e2e-orchestrator.ts
 *
 * Output:
 *   - Console: Clear progress with colors
 *   - .artifacts/e2e-test-results.json: Comprehensive test results
 */

import { mkdir, writeFile, readFile } from 'node:fs/promises'
import { resolve, dirname } from 'node:path'
import { spawn } from 'node:child_process'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)

// Try to load chalk, fall back to simple console if not available
let chalk: typeof import('chalk') | null = null
try {
  chalk = require('chalk')
} catch {
  // chalk not available, use simple console
}

// Colors (simple fallback)
const colors = {
  green: chalk?.green ?? ((s: string) => s),
  red: chalk?.red ?? ((s: string) => s),
  yellow: chalk?.yellow ?? ((s: string) => s),
  blue: chalk?.blue ?? ((s: string) => s),
  cyan: chalk?.cyan ?? ((s: string) => s),
  magenta: chalk?.magenta ?? ((s: string) => s),
  gray: chalk?.gray ?? ((s: string) => s),
  bold: chalk?.bold ?? ((s: string) => s),
  dim: chalk?.dim ?? ((s: string) => s),
}

// Configuration
const DEFAULT_BASE_URL = 'http://localhost:4101'
const DEFAULT_GRAPHQL_URL = 'http://localhost:8080/v1/graphql'
const DEFAULT_OUTPUT = '.artifacts/e2e-test-results.json'
const DEFAULT_TIMEOUT_MS = 120_000

// Interfaces
interface TestResult {
  name: string
  status: 'pass' | 'fail' | 'skip' | 'running'
  startTime: string
  endTime?: string
  durationMs?: number
  error?: string
  details?: Record<string, unknown>
}

interface E2EResults {
  generatedAt: string
  network: string
  baseUrl: string
  graphqlUrl: string
  overall: 'pass' | 'partial' | 'fail'
  totalTests: number
  passed: number
  failed: number
  skipped: number
  durationMs: number
  tests: TestResult[]
  summary: {
    environment: boolean
    bootstrap: boolean
    seed: boolean
    api: boolean
    graphql: boolean
    staking: boolean
    multiAgent: boolean
  }
  recommendations: string[]
}

// Test configuration
interface TestConfig {
  network: string
  baseUrl: string
  graphqlUrl: string
  privateKey: string
  outputPath: string
  skipBootstrap: boolean
  skipSeed: boolean
  skipApi: boolean
  skipGraphql: boolean
  skipStaking: boolean
  skipMultiAgent: boolean
  profile: string
}

// Helper functions
function parseArgs(argv: string[]): TestConfig {
  const networkFlag = argv.find((arg) => arg.startsWith('--network='))
  const baseUrlFlag = argv.find((arg) => arg.startsWith('--base-url='))
  const graphqlUrlFlag = argv.find((arg) => arg.startsWith('--graphql-url='))
  const privateKeyFlag = argv.find((arg) => arg.startsWith('--private-key='))
  const outputFlag = argv.find((arg) => arg.startsWith('--output='))
  const profileFlag = argv.find((arg) => arg.startsWith('--profile='))

  return {
    network: networkFlag?.split('=')[1] || process.env.NETWORK || 'local',
    baseUrl: baseUrlFlag?.split('=')[1] || process.env.BASE_URL || DEFAULT_BASE_URL,
    graphqlUrl: graphqlUrlFlag?.split('=')[1] || process.env.GRAPHQL_URL || DEFAULT_GRAPHQL_URL,
    privateKey: privateKeyFlag?.split('=')[1] || process.env.PRIVATE_KEY || '',
    outputPath: outputFlag?.split('=')[1] || DEFAULT_OUTPUT,
    skipBootstrap: argv.includes('--skip-bootstrap'),
    skipSeed: argv.includes('--skip-seed'),
    skipApi: argv.includes('--skip-api'),
    skipGraphql: argv.includes('--skip-graphql'),
    skipStaking: argv.includes('--skip-staking'),
    skipMultiAgent: argv.includes('--skip-multi-agent'),
    profile: profileFlag?.split('=')[1] || process.env.SEED_PROFILE || 'medium',
  }
}

function runCommand(
  command: string,
  args: string[],
  options: {
    env?: Record<string, string>
    timeout?: number
    cwd?: string
  } = {},
): Promise<{ success: boolean; output: string; exitCode: number }> {
  return new Promise((resolve) => {
    const output: string[] = []
    const child = spawn(command, args, {
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env, ...options.env },
      cwd: options.cwd || process.cwd(),
    })

    const timeout = setTimeout(() => {
      child.kill('SIGTERM')
      resolve({
        success: false,
        output: output.join('') + '\n[TIMEOUT]',
        exitCode: 124,
      })
    }, options.timeout || DEFAULT_TIMEOUT_MS)

    child.stdout?.on('data', (data) => {
      const str = data.toString()
      output.push(str)
      process.stdout.write(str)
    })

    child.stderr?.on('data', (data) => {
      const str = data.toString()
      output.push(str)
      process.stderr.write(str)
    })

    child.on('close', (code) => {
      clearTimeout(timeout)
      resolve({
        success: code === 0,
        output: output.join(''),
        exitCode: code ?? 1,
      })
    })

    child.on('error', (err) => {
      clearTimeout(timeout)
      output.push(err.message)
      resolve({
        success: false,
        output: output.join(''),
        exitCode: 1,
      })
    })
  })
}

async function checkHttpEndpoint(url: string, timeout = 5000): Promise<boolean> {
  try {
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), timeout)
    const response = await fetch(url, { method: 'HEAD', signal: controller.signal })
    clearTimeout(timeoutId)
    return response.ok
  } catch {
    return false
  }
}

async function checkStackRunning(config: TestConfig): Promise<boolean> {
  console.log(`\n${colors.cyan('='.repeat(60))}`)
  console.log(`${colors.cyan('Checking Local Stack...')}`)
  console.log(`${colors.cyan('='.repeat(60))}\n`)

  // Check various stack services
  const checks = [
    { name: 'Base Layer (Anvil)', url: 'http://localhost:8545', optional: false },
    { name: 'GraphQL (Hasura)', url: `${config.graphqlUrl}/healthz`, optional: true },
    { name: 'App Server', url: `${config.baseUrl}/`, optional: true },
  ]

  let allPassed = true
  for (const check of checks) {
    const isRunning = await checkHttpEndpoint(check.url)
    const status = isRunning
      ? colors.green('✓')
      : check.optional
        ? colors.yellow('⊗')
        : colors.red('✗')
    console.log(`  ${status} ${check.name}: ${check.url}`)
    if (!isRunning && !check.optional) {
      allPassed = false
    }
  }

  return allPassed
}

// Test implementations
async function runEnvironmentTest(config: TestConfig): Promise<TestResult> {
  const startTime = new Date()

  console.log(`\n${colors.cyan('='.repeat(60))}`)
  console.log(`${colors.cyan('TEST: Environment Setup')}`)
  console.log(`${colors.cyan('='.repeat(60))}\n`)

  // Check private key
  if (!config.privateKey) {
    return {
      name: 'Environment Setup',
      status: 'fail',
      startTime: startTime.toISOString(),
      endTime: new Date().toISOString(),
      error: 'PRIVATE_KEY environment variable is required',
    }
  }

  // Check network
  if (config.network !== 'local' && config.network !== 'testnet' && config.network !== 'mainnet') {
    return {
      name: 'Environment Setup',
      status: 'fail',
      startTime: startTime.toISOString(),
      endTime: new Date().toISOString(),
      error: `Invalid network: ${config.network}`,
    }
  }

  // Check stack
  const stackRunning = await checkStackRunning(config)
  if (!stackRunning) {
    return {
      name: 'Environment Setup',
      status: 'fail',
      startTime: startTime.toISOString(),
      endTime: new Date().toISOString(),
      error: 'Local stack is not running. Run: pnpm local:stack:up',
    }
  }

  console.log(`\n${colors.green('✓')} Environment setup passed`)

  return {
    name: 'Environment Setup',
    status: 'pass',
    startTime: startTime.toISOString(),
    endTime: new Date().toISOString(),
    durationMs: Date.now() - startTime.getTime(),
    details: {
      network: config.network,
      baseUrl: config.baseUrl,
      graphqlUrl: config.graphqlUrl,
    },
  }
}

async function runBootstrapTest(config: TestConfig): Promise<TestResult> {
  const startTime = new Date()

  console.log(`\n${colors.cyan('='.repeat(60))}`)
  console.log(`${colors.cyan('TEST: Bootstrap - Foundation Atoms')}`)
  console.log(`${colors.cyan('='.repeat(60))}\n`)

  const result = await runCommand(
    'pnpm',
    [
      'tsx',
      'scripts/bootstrap.ts',
      `--network=${config.network}`,
      '--term-id-map=./term-id-map.json',
      '--report=./.artifacts/bootstrap-report.json',
    ],
    {
      env: { PRIVATE_KEY: config.privateKey },
      timeout: 300_000,
    },
  )

  const endTime = new Date()
  const durationMs = endTime.getTime() - startTime.getTime()

  if (result.success) {
    console.log(`\n${colors.green('✓')} Bootstrap completed successfully`)

    // Try to read the report for details
    let details: Record<string, unknown> = {}
    try {
      const reportContent = await readFile('./.artifacts/bootstrap-report.json', 'utf-8')
      details = JSON.parse(reportContent)
    } catch {
      // Report might not exist
    }

    return {
      name: 'Bootstrap - Foundation Atoms',
      status: 'pass',
      startTime: startTime.toISOString(),
      endTime: endTime.toISOString(),
      durationMs,
      details,
    }
  }

  console.log(`\n${colors.red('✗')} Bootstrap failed`)
  return {
    name: 'Bootstrap - Foundation Atoms',
    status: 'fail',
    startTime: startTime.toISOString(),
    endTime: endTime.toISOString(),
    durationMs,
    error: result.output.slice(-1000), // Last 1000 chars
  }
}

async function runSeedTest(config: TestConfig): Promise<TestResult> {
  const startTime = new Date()

  console.log(`\n${colors.cyan('='.repeat(60))}`)
  console.log(`${colors.cyan('TEST: Seed - Agents & Skills')}`)
  console.log(`${colors.cyan('='.repeat(60))}\n`)

  const result = await runCommand(
    'pnpm',
    [
      'tsx',
      'scripts/seed.ts',
      `--network=${config.network}`,
      '--term-id-map=./term-id-map.json',
      `--profile=${config.profile}`,
      '--report=./.artifacts/seed-report.json',
      '--coverage-report=./.artifacts/seed-coverage.report.json',
    ],
    {
      env: { PRIVATE_KEY: config.privateKey },
      timeout: 300_000,
    },
  )

  const endTime = new Date()
  const durationMs = endTime.getTime() - startTime.getTime()

  if (result.success) {
    console.log(`\n${colors.green('✓')} Seed completed successfully`)

    // Try to read the report for details
    let details: Record<string, unknown> = {}
    try {
      const reportContent = await readFile('./.artifacts/seed-report.json', 'utf-8')
      details = JSON.parse(reportContent)
    } catch {
      // Report might not exist
    }

    return {
      name: 'Seed - Agents & Skills',
      status: 'pass',
      startTime: startTime.toISOString(),
      endTime: endTime.toISOString(),
      durationMs,
      details,
    }
  }

  console.log(`\n${colors.red('✗')} Seed failed`)
  return {
    name: 'Seed - Agents & Skills',
    status: 'fail',
    startTime: startTime.toISOString(),
    endTime: endTime.toISOString(),
    durationMs,
    error: result.output.slice(-1000),
  }
}

async function runApiTests(config: TestConfig): Promise<TestResult> {
  const startTime = new Date()

  console.log(`\n${colors.cyan('='.repeat(60))}`)
  console.log(`${colors.cyan('TEST: API Endpoints')}`)
  console.log(`${colors.cyan('='.repeat(60))}\n`)

  const tests: Array<{
    name: string
    url: string
    method?: string
    body?: object
  }> = [
    // Agent endpoints
    { name: 'List Agents', url: `${config.baseUrl}/api/v1/agents` },
    { name: 'Search Agents', url: `${config.baseUrl}/api/v1/agents?q=test` },
    // Skill endpoints
    { name: 'List Skills', url: `${config.baseUrl}/api/v1/skills` },
    // Capability endpoints
    { name: 'List Capabilities', url: `${config.baseUrl}/api/v1/capabilities` },
    // Platform endpoints
    { name: 'List Platforms', url: `${config.baseUrl}/api/v1/platforms` },
    // Predicate endpoints
    { name: 'List Predicates', url: `${config.baseUrl}/api/v1/predicates` },
  ]

  const results: Array<{ name: string; success: boolean; status?: number; error?: string }> = []

  for (const test of tests) {
    try {
      const response = await fetch(test.url, {
        method: test.method || 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
        body: test.body ? JSON.stringify(test.body) : undefined,
      })

      const success = response.ok || response.status === 404 // Some endpoints might return 404
      const statusIcon = success ? colors.green('✓') : colors.red('✗')
      console.log(`  ${statusIcon} ${test.name}: ${response.status}`)

      results.push({
        name: test.name,
        success,
        status: response.status,
      })
    } catch (error) {
      const statusIcon = colors.red('✗')
      console.log(`  ${statusIcon} ${test.name}: ${error instanceof Error ? error.message : 'Error'}`)
      results.push({
        name: test.name,
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      })
    }
  }

  const endTime = new Date()
  const durationMs = endTime.getTime() - startTime.getTime()
  const passed = results.filter((r) => r.success).length
  const failed = results.filter((r) => !r.success).length

  console.log(`\n${colors.gray(`API Tests: ${passed} passed, ${failed} failed`)}`)

  if (failed === 0) {
    return {
      name: 'API Endpoints',
      status: 'pass',
      startTime: startTime.toISOString(),
      endTime: endTime.toISOString(),
      durationMs,
      details: { results },
    }
  }

  return {
    name: 'API Endpoints',
    status: 'partial',
    startTime: startTime.toISOString(),
    endTime: endTime.toISOString(),
    durationMs,
    details: { results },
    error: `${failed} API tests failed`,
  }
}

async function runGraphqlTests(config: TestConfig): Promise<TestResult> {
  const startTime = new Date()

  console.log(`\n${colors.cyan('='.repeat(60))}`)
  console.log(`${colors.cyan('TEST: GraphQL Indexer Queries')}`)
  console.log(`${colors.cyan('='.repeat(60))}\n`)

  const queries = [
    {
      name: 'Query Atoms',
      query: `
        query {
          atoms(first: 5) {
            edges {
              node {
                id
                termId
              }
            }
          }
        }
      `,
    },
    {
      name: 'Query Triples',
      query: `
        query {
          triples(first: 5) {
            edges {
              node {
                id
                subjectId
                predicateId
                objectId
              }
            }
          }
        }
      `,
    },
    {
      name: 'Query Accounts',
      query: `
        query {
          accounts(first: 5) {
            edges {
              node {
                id
                address
              }
            }
          }
        }
      `,
    },
  ]

  const results: Array<{ name: string; success: boolean; error?: string }> = []

  for (const q of queries) {
    try {
      const response = await fetch(config.graphqlUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q.query }),
      })

      const json = await response.json()
      const success = !json.errors && response.ok

      const statusIcon = success ? colors.green('✓') : colors.red('✗')
      console.log(`  ${statusIcon} ${q.name}`)

      if (!success) {
        console.log(`      ${colors.dim(json.errors?.[0]?.message || 'Error')}`)
      }

      results.push({
        name: q.name,
        success,
        error: json.errors?.[0]?.message,
      })
    } catch (error) {
      const statusIcon = colors.red('✗')
      console.log(`  ${statusIcon} ${q.name}: ${error instanceof Error ? error.message : 'Error'}`)
      results.push({
        name: q.name,
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      })
    }
  }

  const endTime = new Date()
  const durationMs = endTime.getTime() - startTime.getTime()
  const passed = results.filter((r) => r.success).length
  const failed = results.filter((r) => !r.success).length

  console.log(`\n${colors.gray(`GraphQL Tests: ${passed} passed, ${failed} failed`)}`)

  if (failed === 0) {
    return {
      name: 'GraphQL Indexer Queries',
      status: 'pass',
      startTime: startTime.toISOString(),
      endTime: endTime.toISOString(),
      durationMs,
      details: { results },
    }
  }

  return {
    name: 'GraphQL Indexer Queries',
    status: 'partial',
    startTime: startTime.toISOString(),
    endTime: endTime.toISOString(),
    durationMs,
    details: { results },
    error: `${failed} GraphQL tests failed`,
  }
}

async function runStakingTests(config: TestConfig): Promise<TestResult> {
  const startTime = new Date()

  console.log(`\n${colors.cyan('='.repeat(60))}`)
  console.log(`${colors.cyan('TEST: Staking Flow')}`)
  console.log(`${colors.cyan('='.repeat(60))}\n`)

  // Note: Full staking tests require the multi-agent interaction test to be run first
  // as it creates agents to stake on. This is a simplified test that checks the endpoint exists.

  const trustEndpoints = [
    { name: 'Trust Score Endpoint', url: `${config.baseUrl}/api/v1/trust/score` },
  ]

  const results: Array<{ name: string; success: boolean; status?: number; error?: string }> = []

  for (const endpoint of trustEndpoints) {
    try {
      const response = await fetch(endpoint.url, { method: 'POST' })
      // We expect this to fail with 400/500 since we don't provide proper body
      // but we just want to check the endpoint exists
      const success = response.status < 500 // Any client error means endpoint exists
      const statusIcon = success ? colors.green('✓') : colors.red('✗')
      console.log(`  ${statusIcon} ${endpoint.name}: ${response.status}`)

      results.push({
        name: endpoint.name,
        success,
        status: response.status,
      })
    } catch (error) {
      const statusIcon = colors.red('✗')
      console.log(`  ${statusIcon} ${endpoint.name}: ${error instanceof Error ? error.message : 'Error'}`)
      results.push({
        name: endpoint.name,
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      })
    }
  }

  // Check for evidence endpoint as well
  try {
    const response = await fetch(`${config.baseUrl}/api/v1/evidence/test-agent-id`, { method: 'GET' })
    const success = response.status < 500
    const statusIcon = success ? colors.green('✓') : colors.red('✗')
    console.log(`  ${statusIcon} Evidence Endpoint: ${response.status}`)
    results.push({
      name: 'Evidence Endpoint',
      success,
      status: response.status,
    })
  } catch (error) {
    const statusIcon = colors.red('✗')
    console.log(`  ${statusIcon} Evidence Endpoint: ${error instanceof Error ? error.message : 'Error'}`)
    results.push({
      name: 'Evidence Endpoint',
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    })
  }

  const endTime = new Date()
  const durationMs = endTime.getTime() - startTime.getTime()
  const passed = results.filter((r) => r.success).length
  const failed = results.filter((r) => !r.success).length

  console.log(`\n${colors.gray(`Staking Tests: ${passed} passed, ${failed} failed`)}`)

  if (failed === 0) {
    return {
      name: 'Staking Flow',
      status: 'pass',
      startTime: startTime.toISOString(),
      endTime: endTime.toISOString(),
      durationMs,
      details: { results },
    }
  }

  return {
    name: 'Staking Flow',
    status: 'partial',
    startTime: startTime.toISOString(),
    endTime: endTime.toISOString(),
    durationMs,
    details: { results },
    error: `${failed} staking tests failed`,
  }
}

async function runMultiAgentTests(config: TestConfig): Promise<TestResult> {
  const startTime = new Date()

  console.log(`\n${colors.cyan('='.repeat(60))}`)
  console.log(`${colors.cyan('TEST: Multi-Agent Interaction')}`)
  console.log(`${colors.cyan('='.repeat(60))}\n`)

  const result = await runCommand(
    'pnpm',
    [
      'tsx',
      'scripts/multi-agent-interaction-test.ts',
      `--base-url=${config.baseUrl}`,
      '--output=./.artifacts/multi-agent-test-report.json',
    ],
    {
      timeout: 300_000,
    },
  )

  const endTime = new Date()
  const durationMs = endTime.getTime() - startTime.getTime()

  if (result.success) {
    console.log(`\n${colors.green('✓')} Multi-agent interaction tests completed`)

    // Try to read the report for details
    let details: Record<string, unknown> = {}
    try {
      const reportContent = await readFile('./.artifacts/multi-agent-test-report.json', 'utf-8')
      details = JSON.parse(reportContent)
    } catch {
      // Report might not exist
    }

    return {
      name: 'Multi-Agent Interaction',
      status: 'pass',
      startTime: startTime.toISOString(),
      endTime: endTime.toISOString(),
      durationMs,
      details,
    }
  }

  console.log(`\n${colors.red('✗')} Multi-agent interaction tests failed`)
  return {
    name: 'Multi-Agent Interaction',
    status: 'fail',
    startTime: startTime.toISOString(),
    endTime: endTime.toISOString(),
    durationMs,
    error: result.output.slice(-1000),
  }
}

// Main orchestrator
async function main() {
  const config = parseArgs(process.argv.slice(2))
  const startedAt = new Date()
  const startedMs = Date.now()

  // Banner
  console.log(`
${colors.magenta('╔════════════════════════════════════════════════════════════╗')}
${colors.magenta('║')}         ${colors.bold('Local E2E Test Orchestrator')}                   ${colors.magenta('║')}
${colors.magenta('║')}         ${colors.dim('Intuition Agent Registry')}                      ${colors.magenta('║')}
${colors.magenta('╚════════════════════════════════════════════════════════════╝')}
`)

  console.log(`${colors.gray('Configuration:')}`)
  console.log(`  ${colors.cyan('Network:')}     ${config.network}`)
  console.log(`  ${colors.cyan('Base URL:')}    ${config.baseUrl}`)
  console.log(`  ${colors.cyan('GraphQL URL:')} ${config.graphqlUrl}`)
  console.log(`  ${colors.cyan('Profile:')}     ${config.profile}`)
  console.log(`  ${colors.cyan('Started:')}     ${startedAt.toISOString()}`)
  console.log('')

  // Initialize results
  const results: E2EResults = {
    generatedAt: '',
    network: config.network,
    baseUrl: config.baseUrl,
    graphqlUrl: config.graphqlUrl,
    overall: 'fail',
    totalTests: 0,
    passed: 0,
    failed: 0,
    skipped: 0,
    durationMs: 0,
    tests: [],
    summary: {
      environment: false,
      bootstrap: false,
      seed: false,
      api: false,
      graphql: false,
      staking: false,
      multiAgent: false,
    },
    recommendations: [],
  }

  // Run tests in sequence
  const testFunctions: Array<{
    name: keyof E2EResults['summary']
    skip: boolean
    fn: (config: TestConfig) => Promise<TestResult>
  }> = [
    {
      name: 'environment',
      skip: false,
      fn: runEnvironmentTest,
    },
    {
      name: 'bootstrap',
      skip: config.skipBootstrap,
      fn: runBootstrapTest,
    },
    {
      name: 'seed',
      skip: config.skipSeed,
      fn: runSeedTest,
    },
    {
      name: 'api',
      skip: config.skipApi,
      fn: runApiTests,
    },
    {
      name: 'graphql',
      skip: config.skipGraphql,
      fn: runGraphqlTests,
    },
    {
      name: 'staking',
      skip: config.skipStaking,
      fn: runStakingTests,
    },
    {
      name: 'multiAgent',
      skip: config.skipMultiAgent,
      fn: runMultiAgentTests,
    },
  ]

  for (const test of testFunctions) {
    if (test.skip) {
      console.log(`\n${colors.yellow('⊗')} ${colors.yellow('Skipping:')} ${test.name}`)
      results.skipped++
      results.tests.push({
        name: test.name,
        status: 'skip',
        startTime: new Date().toISOString(),
        endTime: new Date().toISOString(),
      })
      continue
    }

    try {
      const result = await test.fn(config)
      results.tests.push(result)
      results.summary[test.name] = result.status === 'pass'

      if (result.status === 'pass') {
        results.passed++
      } else if (result.status === 'fail') {
        results.failed++
      } else if (result.status === 'skip') {
        results.skipped++
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error'
      console.error(`\n${colors.red('✗')} Test ${test.name} threw error: ${errorMessage}`)
      results.tests.push({
        name: test.name,
        status: 'fail',
        startTime: new Date().toISOString(),
        endTime: new Date().toISOString(),
        error: errorMessage,
      })
      results.failed++
      results.summary[test.name] = false
    }
  }

  // Calculate overall result
  results.totalTests = testFunctions.filter((t) => !t.skip).length
  results.durationMs = Date.now() - startedMs

  if (results.failed === 0 && results.passed === results.totalTests) {
    results.overall = 'pass'
  } else if (results.failed === results.totalTests) {
    results.overall = 'fail'
  } else {
    results.overall = 'partial'
  }

  // Generate recommendations
  if (!results.summary.environment) {
    results.recommendations.push('Ensure local stack is running: pnpm local:stack:up')
  }
  if (!results.summary.bootstrap) {
    results.recommendations.push('Check bootstrap script errors and retry')
  }
  if (!results.summary.seed) {
    results.recommendations.push('Check seed script errors - ensure bootstrap completed first')
  }
  if (!results.summary.api) {
    results.recommendations.push('Check API endpoint availability')
  }
  if (!results.summary.graphql) {
    results.recommendations.push('Check GraphQL indexer is running and has data')
  }
  if (!results.summary.staking) {
    results.recommendations.push('Check trust/scoring endpoints')
  }
  if (!results.summary.multiAgent) {
    results.recommendations.push('Check multi-agent test setup')
  }

  if (results.overall === 'pass') {
    results.recommendations.push('All tests passed! System is ready for use.')
  }

  // Save results
  results.generatedAt = new Date().toISOString()
  const outputPath = resolve(process.cwd(), config.outputPath)
  await mkdir(dirname(outputPath), { recursive: true }).catch(() => {})
  await writeFile(outputPath, `${JSON.stringify(results, null, 2)}\n`)

  // Print summary
  console.log(`
${colors.magenta('═'.repeat(60))}
${colors.magenta('TEST SUMMARY')}
${colors.magenta('═'.repeat(60))}
`)

  const statusIcon = (status: boolean) => status ? colors.green('✓') : colors.red('✗')
  console.log(`  ${statusIcon(results.summary.environment)} Environment Setup`)
  console.log(`  ${statusIcon(results.summary.bootstrap)} Bootstrap (Foundation Atoms)`)
  console.log(`  ${statusIcon(results.summary.seed)} Seed (Agents & Skills)`)
  console.log(`  ${statusIcon(results.summary.api)} API Endpoints`)
  console.log(`  ${statusIcon(results.summary.graphql)} GraphQL Indexer Queries`)
  console.log(`  ${statusIcon(results.summary.staking)} Staking Flow`)
  console.log(`  ${statusIcon(results.summary.multiAgent)} Multi-Agent Interaction`)

  console.log('')
  console.log(`  ${colors.gray('Total:')} ${results.totalTests}`)
  console.log(`  ${colors.green('Passed:')} ${results.passed}`)
  console.log(`  ${colors.red('Failed:')} ${results.failed}`)
  console.log(`  ${colors.yellow('Skipped:')} ${results.skipped}`)
  console.log(`  ${colors.gray('Duration:')} ${(results.durationMs / 1000).toFixed(1)}s`)
  console.log('')

  const overallIcon = results.overall === 'pass'
    ? colors.green('✓ PASSED')
    : results.overall === 'partial'
      ? colors.yellow('⊗ PARTIAL')
      : colors.red('✗ FAILED')
  console.log(`  ${colors.bold('Overall:')} ${overallIcon}`)
  console.log('')

  if (results.recommendations.length > 0) {
    console.log(`${colors.cyan('Recommendations:')}`)
    for (const rec of results.recommendations) {
      console.log(`  - ${rec}`)
    }
    console.log('')
  }

  console.log(`${colors.gray(`Results saved to: ${outputPath}`)}`)
  console.log('')

  // Exit with appropriate code
  if (results.overall === 'fail') {
    process.exit(1)
  }
}

main().catch((error) => {
  console.error(`\n${colors.red('✗ Orchestrator failed:')}`, error)
  process.exit(1)
})
