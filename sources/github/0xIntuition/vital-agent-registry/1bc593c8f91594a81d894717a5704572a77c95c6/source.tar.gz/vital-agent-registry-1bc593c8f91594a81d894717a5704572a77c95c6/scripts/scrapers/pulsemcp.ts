/**
 * PulseMCP HTML scraper.
 * URL: https://www.pulsemcp.com/servers
 *
 * Parses server cards from the listing page, paginating via next-page links.
 * Limit: top 200 by weekly visitors.
 * Requires: cheerio
 */

import * as cheerio from 'cheerio'
import type { Corpus, CorpusSkill } from './types'
import { inferCapabilities, slugify, sleep } from './utils'

const BASE_URL = 'https://www.pulsemcp.com'
const MAX_SKILLS = 200

async function fetchPage(url: string): Promise<string | null> {
  try {
    const res = await fetch(url, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (compatible; AgentRegistryBot/1.0; +https://intuition.systems)',
        Accept: 'text/html,application/xhtml+xml',
      },
      signal: AbortSignal.timeout(15_000),
    })
    if (!res.ok) {
      console.warn(`[pulsemcp] HTTP ${res.status} for ${url}`)
      return null
    }
    return res.text()
  } catch (err) {
    console.warn(`[pulsemcp] Fetch error: ${err instanceof Error ? err.message : err}`)
    return null
  }
}

function parseServerCards(html: string): CorpusSkill[] {
  const $ = cheerio.load(html)
  const skills: CorpusSkill[] = []

  // PulseMCP renders server cards - try multiple selectors to be resilient to markup changes
  const cardSelectors = [
    'article',
    '[class*="server-card"]',
    '[class*="ServerCard"]',
    '[class*="card"]',
    'li[class*="server"]',
  ]

  let cards = $('')
  for (const sel of cardSelectors) {
    cards = $(sel)
    if (cards.length > 0) break
  }

  cards.each((_, el) => {
    const $el = $(el)

    // Extract name — try heading tags, then link text
    const name =
      $el.find('h2, h3, h4').first().text().trim() ||
      $el.find('a[href*="/server"]').first().text().trim() ||
      $el.find('[class*="name"], [class*="title"]').first().text().trim()

    if (!name) return

    // Extract description
    const description =
      $el.find('p').first().text().trim() ||
      $el.find('[class*="description"], [class*="desc"]').first().text().trim() ||
      ''

    // Extract install command if present
    const installText =
      $el.find('code').first().text().trim() ||
      $el.find('[class*="install"], [class*="command"]').first().text().trim() ||
      ''

    const isNpm = installText.startsWith('npx ') || installText.startsWith('npm:')
    const installUri = isNpm ? installText : undefined

    skills.push({
      metadata: {
        '@type': 'Skill',
        name: `mcp-${slugify(name)}`,
        description: (description || `MCP server: ${name}`).slice(0, 500),
        version: '0.1.0',
        platform: 'mcp',
        author: 'Unknown',
        ...(installUri ? { installUri } : {}),
      },
      capabilities: inferCapabilities(name, description, 'mcp'),
    })
  })

  return skills
}

function extractNextPageUrl(html: string, currentUrl: string): string | null {
  const $ = cheerio.load(html)

  // Try rel="next" link
  const relNext = $('a[rel="next"]').attr('href')
  if (relNext) return relNext.startsWith('http') ? relNext : `${BASE_URL}${relNext}`

  // Try "Next" button / pagination link
  const nextLink = $('a:contains("Next"), a[aria-label*="Next"], [class*="pagination"] a:last-child')
    .first()
    .attr('href')
  if (nextLink && nextLink !== currentUrl) {
    return nextLink.startsWith('http') ? nextLink : `${BASE_URL}${nextLink}`
  }

  return null
}

export async function fetchPulseMcp(): Promise<Corpus> {
  console.log(`[pulsemcp] Scraping ${BASE_URL}/servers...`)

  const allSkills: CorpusSkill[] = []
  let currentUrl = `${BASE_URL}/servers`
  let page = 0

  while (currentUrl && allSkills.length < MAX_SKILLS) {
    if (page > 0) await sleep(1000) // Be polite between pages

    const html = await fetchPage(currentUrl)
    if (!html) break

    const pageSkills = parseServerCards(html)
    console.log(`[pulsemcp] Page ${page + 1}: ${pageSkills.length} servers`)

    if (pageSkills.length === 0) break

    allSkills.push(...pageSkills)

    const nextUrl = extractNextPageUrl(html, currentUrl)
    if (!nextUrl || nextUrl === currentUrl) break
    currentUrl = nextUrl
    page++
  }

  const capped = allSkills.slice(0, MAX_SKILLS)
  console.log(`[pulsemcp] Total: ${capped.length} servers`)

  return { agents: [], skills: capped }
}
