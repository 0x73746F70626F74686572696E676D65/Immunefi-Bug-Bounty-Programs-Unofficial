import { parseEther } from 'viem'

export const DEFAULT_LOCAL_TEST_WALLETS = [
  {
    id: 'agent-001',
    label: 'Local Agent 001',
    privateKey:
      '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80',
  },
  {
    id: 'agent-002',
    label: 'Local Agent 002',
    privateKey:
      '0x59c6995e998f97a5a0044966f094538f9dc9f5f2f0c6a4f7c5d7f8f9d8b7a6c5',
  },
  {
    id: 'agent-003',
    label: 'Local Agent 003',
    privateKey:
      '0x5de4111afa1a4b94908f83103e40f4ff266f3cfd89e75f02a65543a323f16f8d',
  },
]

function normalizeHexKey(privateKey) {
  if (typeof privateKey !== 'string') return null
  if (!privateKey.startsWith('0x')) return null
  if (privateKey.length !== 66) return null
  return privateKey
}

export function parseWalletConfig(rawJson) {
  if (!rawJson) return DEFAULT_LOCAL_TEST_WALLETS
  const parsed = JSON.parse(rawJson)
  if (!Array.isArray(parsed)) {
    throw new Error('LOCAL_TEST_WALLETS_JSON must be a JSON array')
  }
  const normalized = parsed.map((entry, index) => {
    const key = normalizeHexKey(entry?.privateKey)
    if (!key) {
      throw new Error(`Invalid privateKey at index ${index}`)
    }
    return {
      id: entry?.id || `wallet-${index + 1}`,
      label: entry?.label || `Wallet ${index + 1}`,
      privateKey: key,
    }
  })
  return normalized
}

export function parseRequiredWei(requiredEth) {
  const value = requiredEth ?? '1'
  try {
    return parseEther(value)
  } catch (error) {
    throw new Error(`Invalid --required-eth value: ${value}`)
  }
}

export function buildWalletFundingPlan({
  wallets,
  requiredWei,
  balancesByAddress,
}) {
  const details = wallets.map((wallet) => {
    const balanceWei = balancesByAddress[wallet.address] ?? 0n
    const deficitWei = balanceWei >= requiredWei ? 0n : requiredWei - balanceWei
    return {
      ...wallet,
      balanceWei: balanceWei.toString(),
      requiredWei: requiredWei.toString(),
      deficitWei: deficitWei.toString(),
      ready: deficitWei === 0n,
    }
  })

  return {
    generatedAt: new Date().toISOString(),
    requiredWei: requiredWei.toString(),
    walletCount: details.length,
    readyCount: details.filter((entry) => entry.ready).length,
    notReadyCount: details.filter((entry) => !entry.ready).length,
    totalDeficitWei: details
      .reduce((acc, entry) => acc + BigInt(entry.deficitWei), 0n)
      .toString(),
    wallets: details,
  }
}
