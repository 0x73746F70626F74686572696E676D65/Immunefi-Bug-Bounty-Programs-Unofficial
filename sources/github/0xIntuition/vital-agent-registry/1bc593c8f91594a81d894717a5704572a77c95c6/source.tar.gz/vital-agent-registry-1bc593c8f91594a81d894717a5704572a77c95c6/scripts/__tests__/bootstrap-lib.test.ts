import { describe, expect, it } from 'vitest'
import {
  partitionBootstrapEntries,
  summarizeByCategory,
  toStableTermIdMap,
} from '../bootstrap-lib.mjs'

describe('bootstrap-lib', () => {
  it('builds stable term-id maps sorted by name', () => {
    const map = toStableTermIdMap([
      { name: 'zeta', termId: '0x03' },
      { name: 'alpha', termId: '0x01' },
      { name: 'beta', termId: '0x02' },
    ])
    expect(Object.keys(map)).toEqual(['alpha', 'beta', 'zeta'])
  })

  it('partitions create-vs-existing entries by term id', () => {
    const entries = [
      { name: 'a', termId: '0x01' },
      { name: 'b', termId: '0x02' },
      { name: 'c', termId: '0x03' },
    ]
    const result = partitionBootstrapEntries(entries, new Set(['0x02']))
    expect(result.existing.map((entry) => entry.name)).toEqual(['b'])
    expect(result.toCreate.map((entry) => entry.name)).toEqual(['a', 'c'])
  })

  it('summarizes entry counts by category', () => {
    const summary = summarizeByCategory([
      { category: 'predicate' },
      { category: 'predicate' },
      { category: 'type' },
      { category: 'capability' },
      { category: 'platform' },
    ])
    expect(summary).toEqual({
      predicate: 2,
      type: 1,
      capability: 1,
      platform: 1,
    })
  })
})
