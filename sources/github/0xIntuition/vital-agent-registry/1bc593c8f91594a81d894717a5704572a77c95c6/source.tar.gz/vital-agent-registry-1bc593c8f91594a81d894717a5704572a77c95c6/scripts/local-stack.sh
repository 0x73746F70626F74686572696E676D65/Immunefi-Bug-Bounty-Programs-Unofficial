#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
INTUITION_RS_DIR="$(cd "$ROOT_DIR/../../repos/intuition-rs" && pwd)"
START_SCRIPT_LEGACY="$INTUITION_RS_DIR/scripts/start.sh"
STOP_SCRIPT_LEGACY="$INTUITION_RS_DIR/scripts/stop.sh"
START_SCRIPT_ROOT="$INTUITION_RS_DIR/start.sh"
STOP_SCRIPT_ROOT="$INTUITION_RS_DIR/stop.sh"
START_SCRIPT=""
STOP_SCRIPT=""
CONTRACTS_REPO_DIR="$(cd "$ROOT_DIR/../../repos/intuition-contracts-v2" && pwd)"
DOCKER_CONFIG_DIR="${ROOT_DIR}/.artifacts/docker-config"

HASURA_HEALTH_URL="${HASURA_HEALTH_URL:-http://localhost:8080/healthz}"
GRAPHQL_URL="${GRAPHQL_URL:-http://localhost:8080/v1/graphql}"
LOCAL_STACK_SKIP_IMAGE_BUILD="${LOCAL_STACK_SKIP_IMAGE_BUILD:-0}"
LOCAL_STACK_USE_ISOLATED_DOCKER_CONFIG="${LOCAL_STACK_USE_ISOLATED_DOCKER_CONFIG:-1}"
LOCAL_STACK_CLEAN_CONFLICTING_CONTAINERS="${LOCAL_STACK_CLEAN_CONFLICTING_CONTAINERS:-1}"
LOCAL_STACK_CLEAN_PORT_8545_CONFLICTS="${LOCAL_STACK_CLEAN_PORT_8545_CONFLICTS:-1}"
LOCAL_STACK_AUTO_RESET_DATABASE_VOLUME="${LOCAL_STACK_AUTO_RESET_DATABASE_VOLUME:-1}"
LOCAL_STACK_POSTGRES_COMPAT_TAG="${LOCAL_STACK_POSTGRES_COMPAT_TAG:-17}"
INTUITION_RS_ENV_FILE="${INTUITION_RS_DIR}/.env"
INTUITION_RS_ENV_SAMPLE_FILE="${INTUITION_RS_DIR}/.env.sample"

command_name="${1:-}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1"
    exit 1
  fi
}

setup_docker_config() {
  if [[ "$LOCAL_STACK_USE_ISOLATED_DOCKER_CONFIG" != "1" ]]; then
    return 0
  fi

  mkdir -p "$DOCKER_CONFIG_DIR"
  if [[ ! -f "$DOCKER_CONFIG_DIR/config.json" ]]; then
    cat >"$DOCKER_CONFIG_DIR/config.json" <<'EOF'
{"auths":{}}
EOF
  fi

  export DOCKER_CONFIG="$DOCKER_CONFIG_DIR"
}

ensure_intuition_rs_env() {
  if [[ ! -f "$INTUITION_RS_ENV_FILE" ]]; then
    if [[ -f "$INTUITION_RS_ENV_SAMPLE_FILE" ]]; then
      cp "$INTUITION_RS_ENV_SAMPLE_FILE" "$INTUITION_RS_ENV_FILE"
      echo "created $INTUITION_RS_ENV_FILE from .env.sample"
      return 0
    fi
    echo "missing intuition-rs .env and .env.sample:"
    echo "  $INTUITION_RS_ENV_FILE"
    echo "  $INTUITION_RS_ENV_SAMPLE_FILE"
    exit 1
  fi

  if [[ ! -f "$INTUITION_RS_ENV_SAMPLE_FILE" ]]; then
    return 0
  fi

  # Merge missing local defaults from .env.sample into existing .env
  # without overwriting user-provided values/secrets.
  local missing_count=0
  while IFS= read -r line || [[ -n "$line" ]]; do
    [[ -z "$line" ]] && continue
    [[ "$line" =~ ^[[:space:]]*# ]] && continue
    [[ "$line" != *=* ]] && continue

    local key="${line%%=*}"
    if ! grep -q "^${key}=" "$INTUITION_RS_ENV_FILE"; then
      echo "$line" >> "$INTUITION_RS_ENV_FILE"
      missing_count=$((missing_count + 1))
    fi
  done < "$INTUITION_RS_ENV_SAMPLE_FILE"

  if [[ "$missing_count" -gt 0 ]]; then
    echo "added $missing_count missing defaults to intuition-rs/.env from .env.sample"
  fi
}

check_scripts() {
  if [[ -x "$START_SCRIPT_ROOT" && -x "$STOP_SCRIPT_ROOT" ]]; then
    START_SCRIPT="$START_SCRIPT_ROOT"
    STOP_SCRIPT="$STOP_SCRIPT_ROOT"
    return 0
  fi

  if [[ -x "$START_SCRIPT_LEGACY" && -x "$STOP_SCRIPT_LEGACY" ]]; then
    START_SCRIPT="$START_SCRIPT_LEGACY"
    STOP_SCRIPT="$STOP_SCRIPT_LEGACY"
    return 0
  fi

  if has_cargo_make; then
    # Newer intuition-rs layouts may only support cargo make targets.
    return 0
  fi

  if [[ -z "$START_SCRIPT" || -z "$STOP_SCRIPT" ]]; then
    echo "intuition-rs start/stop scripts not found or not executable (and cargo make unavailable)."
    echo "tried:"
    echo "  $START_SCRIPT_ROOT"
    echo "  $STOP_SCRIPT_ROOT"
    echo "  $START_SCRIPT_LEGACY"
    echo "  $STOP_SCRIPT_LEGACY"
    exit 1
  fi
}

has_cargo_make() {
  command -v cargo >/dev/null 2>&1 && cargo make --version >/dev/null 2>&1
}

cargo_make_task_exists() {
  local task="$1"
  (
    cd "$INTUITION_RS_DIR"
    cargo make --list-all-steps 2>/dev/null | grep -q "^${task}[[:space:]]*-"
  )
}

has_image() {
  docker image inspect "$1" >/dev/null 2>&1
}

cleanup_conflicting_containers() {
  if [[ "$LOCAL_STACK_CLEAN_CONFLICTING_CONTAINERS" != "1" ]]; then
    return 0
  fi

  local containers=(
    database
    consumer-api
    decoded_consumer
    raw_consumer
    sqs
    api
    rpc-proxy
    safe-content
    graphql-engine
    ipfs
    histocrawler
    local-migrations
    indexer-migrations
    histoflux
    hasura-migrations
    prometheus
    geth
    integration-tests
  )

  local found=0
  for name in "${containers[@]}"; do
    if docker container inspect "$name" >/dev/null 2>&1; then
      if [[ "$found" -eq 0 ]]; then
        echo "cleaning conflicting local-stack containers"
        found=1
      fi
      docker rm -f "$name" >/dev/null 2>&1 || true
      echo "  removed: $name"
    fi
  done
}

cleanup_port_8545_conflicts() {
  if [[ "$LOCAL_STACK_CLEAN_PORT_8545_CONFLICTS" != "1" ]]; then
    return 0
  fi

  # intuition-rs geth needs host 8545. Remove known local chain containers that
  # commonly bind this port and block startup.
  local candidates=(reth anvil hardhat)
  local removed=0

  for name in "${candidates[@]}"; do
    if ! docker container inspect "$name" >/dev/null 2>&1; then
      continue
    fi

    local publishes
    publishes="$(docker container port "$name" 2>/dev/null || true)"
    if echo "$publishes" | grep -q '0.0.0.0:8545'; then
      if [[ "$removed" -eq 0 ]]; then
        echo "cleaning host port 8545 conflicts"
        removed=1
      fi
      docker rm -f "$name" >/dev/null 2>&1 || true
      echo "  removed: $name (host port 8545)"
    fi
  done
}

build_image_if_missing() {
  local image="$1"
  local build_cmd="$2"

  if has_image "$image"; then
    return 0
  fi

  echo "missing image: $image"
  if [[ "$LOCAL_STACK_SKIP_IMAGE_BUILD" == "1" ]]; then
    echo "auto-build disabled (LOCAL_STACK_SKIP_IMAGE_BUILD=1)."
    return 1
  fi

  echo "building image: $image"
  (cd "$INTUITION_RS_DIR" && bash -lc "$build_cmd")
}

ensure_postgres_compat_image() {
  local compat_image="postgres:${LOCAL_STACK_POSTGRES_COMPAT_TAG}"
  if ! has_image "$compat_image"; then
    echo "pulling postgres compatibility image: $compat_image"
    docker pull "$compat_image" >/dev/null
  fi

  # intuition-rs currently uses image: postgres (floating latest). Retag latest
  # to a known-compatible major so local startup remains stable.
  docker tag "$compat_image" postgres:latest
}

prepare_contract_deployer_context() {
  local target_dir="$INTUITION_RS_DIR/intuition-contracts-v2"

  if [[ ! -d "$CONTRACTS_REPO_DIR" ]]; then
    echo "missing contracts repo: $CONTRACTS_REPO_DIR"
    echo "clone it locally, then retry:"
    echo "  git clone https://github.com/0xIntuition/intuition-contracts-v2.git repos/intuition-contracts-v2"
    return 1
  fi

  if [[ ! -d "$CONTRACTS_REPO_DIR/lib/forge-std/src" ]]; then
    echo "initializing intuition-contracts-v2 submodules"
    (
      cd "$CONTRACTS_REPO_DIR"
      git submodule update --init --recursive
    )
  fi

  rm -rf "$target_dir"
  cp -R "$CONTRACTS_REPO_DIR" "$target_dir"
}

build_contract_deployer_fallback() {
  local fallback_dockerfile="/tmp/contract-deployer-fallback.Dockerfile"

  cat >"$fallback_dockerfile" <<'EOF'
FROM ubuntu:latest

RUN apt-get update && apt-get install -y \
    postgresql-client \
    jq \
    build-essential \
    git \
    curl \
    software-properties-common \
    libc6 \
    libstdc++6 \
    nodejs \
    npm \
    && rm -rf /var/lib/apt/lists/*

RUN curl -L https://foundry.paradigm.xyz | bash && \
    /root/.foundry/bin/foundryup

ENV PATH="/root/.foundry/bin:${PATH}"
WORKDIR /app

COPY intuition-contracts-v2 .

# Use vendored node_modules when available; otherwise install with pnpm to avoid npm resolver instability.
RUN if [ -d node_modules/@openzeppelin ]; then \
      echo "using vendored node_modules"; \
    else \
      npm install -g pnpm@9 && pnpm install --no-frozen-lockfile; \
    fi

RUN forge build

RUN echo '#!/bin/sh\n\
export DEPLOYER_LOCAL=0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80\n\
export BROADCASTING=1\n\
export ANVIL_ADMIN_ADDRESS=0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266\n\
export ANVIL_MULTI_VAULT_ROLE_MIGRATOR=0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266\n\
export TARGET_CHAIN_ID=31337\n\
export ANVIL_TRUST_TOKEN=0x000000000000000000000000000000000000dEaD\n\
OUTPUT0=$(forge script script/base/BaseEmissionsControllerDeploy.s.sol --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 --rpc-url http://reth:8545 --broadcast --optimizer-runs 200 2>&1)\n\
echo "$OUTPUT0"\n\
export ANVIL_BASE_EMISSIONS_CONTROLLER=$(echo "$OUTPUT0" | grep "BaseEmissionsController Proxy: " | sed -E "s/.*BaseEmissionsController Proxy: //")\n\
OUTPUT1=$(forge script script/intuition/MultiVaultMigrationModeDeploy.s.sol:MultiVaultMigrationModeDeploy --via-ir --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 --rpc-url http://reth:8545 --broadcast --optimizer-runs 200 2>&1)\n\
echo "$OUTPUT1"\n\
export ANVIL_MULTIVAULT_MIGRATION_MODE_IMPLEMENTATION=$(echo "$OUTPUT1" | grep "MultiVaultMigrationMode Implementation: " | sed -E "s/.*MultiVaultMigrationMode Implementation: //")\n\
OUTPUT2=$(forge script script/intuition/IntuitionDeployAndSetup.s.sol --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 --rpc-url http://reth:8545 --broadcast --optimizer-runs 200 2>&1)\n\
echo "$OUTPUT2"\n\
export ANVIL_MULTIVAULT_PROXY=$(echo "$OUTPUT2" | grep "MultiVault : " | sed -E "s/.*MultiVault : //")\n\
PGPASSWORD=$POSTGRES_PASSWORD psql -h database -U $POSTGRES_USER -d $POSTGRES_DB -p $POSTGRES_PORT -c "UPDATE histocrawler.app_config SET contract_address = '\''$ANVIL_MULTIVAULT_PROXY'\'', start_block = 0 WHERE indexer_schema = '\''local'\''"' > /app/deploy.sh && chmod +x /app/deploy.sh

RUN echo '#!/bin/sh\n\
forge script script/intuition/MultiVaultMigrationModeDeploy.s.sol:MultiVaultMigrationModeDeploy --rpc-url http://reth:8545 --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 --broadcast --optimizer-runs 200 --resume --verify --verifier blockscout --verifier-url http://host.docker.internal/api/\n\
forge script script/intuition/IntuitionDeployAndSetup.s.sol --rpc-url http://reth:8545 --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 --broadcast --optimizer-runs 200 --resume --verify --verifier blockscout --verifier-url http://host.docker.internal/api/\n\
\n' > /app/verify.sh && chmod +x /app/verify.sh

ENTRYPOINT ["/app/deploy.sh"]
EOF

  (
    cd "$INTUITION_RS_DIR" && \
      docker build \
        -f "$fallback_dockerfile" \
        -t ghcr.io/0xintuition/contract-deployer-2-0:latest \
        .
  )
}

prebuild_required_images() {
  require_cmd docker
  setup_docker_config

  build_image_if_missing \
    "ghcr.io/0xintuition/pgai:latest" \
    "docker build -t ghcr.io/0xintuition/pgai:latest -f apps/models/Dockerfile apps/models"

  build_image_if_missing \
    "ghcr.io/0xintuition/indexer-and-cache-migrations:latest" \
    "docker build -t ghcr.io/0xintuition/indexer-and-cache-migrations:latest -f infrastructure/indexer-and-cache-migrations/Dockerfile ."

  build_image_if_missing \
    "ghcr.io/0xintuition/hasura-migrations:latest" \
    "docker build -t ghcr.io/0xintuition/hasura-migrations:latest -f infrastructure/hasura/Dockerfile ."

  build_image_if_missing \
    "ghcr.io/0xintuition/local-migrations:latest" \
    "docker build -t ghcr.io/0xintuition/local-migrations:latest -f local/Dockerfile ."

  build_image_if_missing \
    "ghcr.io/0xintuition/consumer-api:latest" \
    "docker build -t ghcr.io/0xintuition/consumer-api:latest -f consumer-api/Dockerfile ."

  build_image_if_missing \
    "ghcr.io/0xintuition/consumer:latest" \
    "docker build -t ghcr.io/0xintuition/consumer:latest -f consumer/Dockerfile ."

  build_image_if_missing \
    "ghcr.io/0xintuition/rpc-proxy:latest" \
    "docker build -t ghcr.io/0xintuition/rpc-proxy:latest -f rpc-proxy/Dockerfile ."

  build_image_if_missing \
    "ghcr.io/0xintuition/histocrawler:latest" \
    "docker build -t ghcr.io/0xintuition/histocrawler:latest -f histocrawler/Dockerfile ."

  build_image_if_missing \
    "ghcr.io/0xintuition/histoflux:latest" \
    "docker build -t ghcr.io/0xintuition/histoflux:latest -f histoflux/Dockerfile ."

  build_image_if_missing \
    "ghcr.io/0xintuition/image-guard:latest" \
    "docker build -t ghcr.io/0xintuition/image-guard:latest -f image-guard/Dockerfile ."

  if ! has_image "ghcr.io/0xintuition/contract-deployer-2-0:latest"; then
    echo "missing image: ghcr.io/0xintuition/contract-deployer-2-0:latest"
    if [[ "$LOCAL_STACK_SKIP_IMAGE_BUILD" == "1" ]]; then
      echo "auto-build disabled (LOCAL_STACK_SKIP_IMAGE_BUILD=1)."
      return 1
    fi

    prepare_contract_deployer_context
    if ! (
      cd "$INTUITION_RS_DIR" && \
        docker build \
          -f integration-tests/contract-deployer-2-0/Dockerfile.copy \
          -t ghcr.io/0xintuition/contract-deployer-2-0:latest \
          .
    ); then
      echo "default contract-deployer build failed; retrying with fallback Dockerfile"
      build_contract_deployer_fallback
    fi
  fi
}

health_check() {
  require_cmd curl

  echo "checking hasura health endpoint: $HASURA_HEALTH_URL"
  curl --fail --silent --show-error "$HASURA_HEALTH_URL" >/dev/null

  echo "checking graphql endpoint: $GRAPHQL_URL"
  curl \
    --fail \
    --silent \
    --show-error \
    -H 'Content-Type: application/json' \
    -d '{"query":"query LocalStackHealth { __typename }"}' \
    "$GRAPHQL_URL" >/dev/null

  echo "local stack health: ok"
}

state_hash() {
  (
    cd "$ROOT_DIR"
    node scripts/local-state-fingerprint.mjs --hash-only
  )
}

start_intuition_rs_local() {
  if has_cargo_make; then
    if cargo_make_task_exists start-local; then
      (
        cd "$INTUITION_RS_DIR"
        cargo make start-local
      )
      return 0
    fi

    if cargo_make_task_exists start-docker-and-migrate; then
      (
        cd "$INTUITION_RS_DIR"
        cargo make start-docker-and-migrate
      )
      return 0
    fi

    if cargo_make_task_exists start-docker; then
      (
        cd "$INTUITION_RS_DIR"
        cargo make start-docker
      )
      return 0
    fi

    echo "no supported cargo make start task found in intuition-rs"
    return 1
  else
    (
      cd "$INTUITION_RS_DIR"
      "$START_SCRIPT" local
    )
  fi
}

stop_intuition_rs_local() {
  if has_cargo_make; then
    if cargo_make_task_exists stop; then
      (
        cd "$INTUITION_RS_DIR"
        cargo make stop
      )
      return 0
    fi

    (
      cd "$INTUITION_RS_DIR"
      docker compose down -v
    )
  else
    (
      cd "$INTUITION_RS_DIR"
      "$STOP_SCRIPT"
    )
  fi
}

database_volume_incompatibility_detected() {
  if ! docker container inspect database >/dev/null 2>&1; then
    return 1
  fi

  local db_status
  db_status="$(docker inspect database --format '{{.State.Status}} {{.State.ExitCode}} {{.State.Error}}' 2>/dev/null || true)"
  if ! echo "$db_status" | grep -q '^exited 1'; then
    return 1
  fi

  local db_logs
  db_logs="$(docker logs database --tail 200 2>&1 || true)"
  if echo "$db_logs" | grep -Eiq 'database files are incompatible|initialized by PostgreSQL version|PostgreSQL 18 and later|in 18\+, these Docker images|unused mount/volume'; then
    return 0
  fi

  return 1
}

reset_local_database_volume() {
  local removed=0
  local volume

  for volume in intuition-rs_database-data intuition_database-data; do
    if docker volume inspect "$volume" >/dev/null 2>&1; then
      docker volume rm "$volume" >/dev/null
      echo "  removed db volume: $volume"
      removed=1
    fi
  done

  if [[ "$removed" -eq 0 ]]; then
    echo "no known local db volume found to reset"
    return 1
  fi

  return 0
}

attempt_database_volume_recovery() {
  if [[ "$LOCAL_STACK_AUTO_RESET_DATABASE_VOLUME" != "1" ]]; then
    return 1
  fi

  if ! database_volume_incompatibility_detected; then
    return 1
  fi

  echo "detected postgres data layout incompatibility in local volume"
  echo "attempting local db volume reset and one startup retry"

  stop_intuition_rs_local >/dev/null 2>&1 || true
  reset_local_database_volume
}

up() {
  require_cmd docker
  require_cmd bash
  setup_docker_config
  ensure_intuition_rs_env
  check_scripts
  cleanup_conflicting_containers
  cleanup_port_8545_conflicts
  prebuild_required_images

  echo "starting intuition-rs local stack"
  ensure_postgres_compat_image
  if ! start_intuition_rs_local; then
    if attempt_database_volume_recovery; then
      start_intuition_rs_local
    else
      echo "local stack startup failed"
      exit 1
    fi
  fi

  echo "generating deterministic local fixtures"
  (
    cd "$ROOT_DIR"
    node scripts/local-fixtures.mjs
  )

  health_check

  echo "bootstrapping foundation atoms (term-id-map.json)"
  (
    cd "$ROOT_DIR"
    PRIVATE_KEY="${PRIVATE_KEY:-0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80}" \
      pnpm tsx scripts/bootstrap.ts --network=local
  )

  cat <<'EOM'
local stack is up.
next step (run in another terminal):
  pnpm -C apps/agent-registry dev
EOM
}

down() {
  require_cmd docker
  setup_docker_config
  check_scripts
  echo "stopping intuition-rs local stack"
  stop_intuition_rs_local
  echo "local stack stopped"
}

rerun_verify() {
  require_cmd node

  local hash_one
  local hash_two

  echo "rerun verify: cycle 1 (clean down/up + fingerprint)"
  down
  up
  hash_one="$(state_hash)"
  echo "rerun verify: cycle 1 hash: $hash_one"

  echo "rerun verify: cycle 2 (clean down/up + fingerprint)"
  down
  up
  hash_two="$(state_hash)"
  echo "rerun verify: cycle 2 hash: $hash_two"

  if [[ "$hash_one" != "$hash_two" ]]; then
    echo "rerun verify failed: state hash drift detected"
    echo "  cycle1: $hash_one"
    echo "  cycle2: $hash_two"
    exit 1
  fi

  echo "rerun verify: stable state across clean reruns"
}

case "$command_name" in
  up)
    up
    ;;
  down)
    down
    ;;
  health)
    health_check
    ;;
  rerun-verify)
    rerun_verify
    ;;
  *)
    cat <<'EOM'
usage:
  bash scripts/local-stack.sh up
  bash scripts/local-stack.sh down
  bash scripts/local-stack.sh health
  bash scripts/local-stack.sh rerun-verify
EOM
    exit 1
    ;;
esac
