#!/usr/bin/env tsx
// @ts-nocheck - script runtime with env-dependent chain IO

import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import {
  createRegistryPublicClient,
  createRegistryWalletClient,
} from '../app/.server/viem'
import {
  createAtoms,
  createTriples,
  getAtomCost,
  getTripleCost,
} from '../app/.server/multivault'
import { multivaultAbi } from '../app/lib/abis/multivault'
import {
  uploadAgentMetadata,
  uploadSkillMetadata,
} from '../app/.server/ipfs'
import { assertRemoteWriteAllowed } from '../app/.server/remote-write-guard'
import { assertSharedWriteParityGate } from './parity-gate'
import { SEED_AGENTS, SEED_SKILLS } from '../app/lib/constants/seed-data'
import { CONTRACTS, NAMESPACES, getContractAddress } from '../app/lib/constants/protocol'
import { pollIndexerForTermId } from '../app/lib/indexer-poller'
import { deriveAtomTermId, deriveIdentityAtomTermId, encodeIdentityAtomData } from '../app/lib/calldata'
import {
  buildSeedCoverageReport,
  buildSeedProfile,
  loadSeedCorpus,
  mergeSeedData,
  validateSeedCoverage,
} from './seed-lib.mjs'

interface TermIdMapping {
  [atomName: string]: string
}

function parseArgs(argv: string[]) {
  const networkFlag = argv.find((arg) => arg.startsWith('--network='))
  const termIdMapFlag = argv.find((arg) => arg.startsWith('--term-id-map='))
  const reportPathFlag = argv.find((arg) => arg.startsWith('--report='))
  const coveragePathFlag = argv.find((arg) => arg.startsWith('--coverage-report='))
  const profileFlag = argv.find((arg) => arg.startsWith('--profile='))
  const corpusFlag = argv.find((arg) => arg.startsWith('--corpus='))
  const allowCoverageFailure = argv.includes('--allow-coverage-failure')
  return {
    network: networkFlag?.split('=')[1] || process.env.NETWORK || 'local',
    termIdMapPath: termIdMapFlag?.split('=')[1] || process.env.TERM_ID_MAP || './term-id-map.json',
    reportPath: reportPathFlag?.split('=')[1] || './.artifacts/seed-report.json',
    coverageReportPath:
      coveragePathFlag?.split('=')[1] || './.artifacts/seed-coverage.report.json',
    profile: profileFlag?.split('=')[1] || process.env.SEED_PROFILE || 'medium',
    corpusPath: corpusFlag?.split('=')[1] || process.env.SEED_CORPUS || '',
    allowCoverageFailure,
  }
}

async function isAtomOnChain(
  client: any,
  contractAddress: `0x${string}`,
  termId: `0x${string}`,
): Promise<boolean> {
  try {
    return await client.readContract({
      address: contractAddress,
      abi: multivaultAbi,
      functionName: 'isAtom',
      args: [termId],
    })
  } catch {
    return false
  }
}

async function loadTermIdMap(path: string): Promise<TermIdMapping> {
  const content = await readFile(path, 'utf-8')
  return JSON.parse(content) as TermIdMapping
}

async function main() {
  const args = parseArgs(process.argv.slice(2))
  const startedMs = Date.now()

  if (args.network !== 'testnet' && args.network !== 'mainnet' && args.network !== 'local') {
    throw new Error(`Invalid network: ${args.network}. Must be 'testnet', 'mainnet', or 'local'`)
  }

  // Skip remote write guard for local network
  if (args.network !== 'local') {
    assertRemoteWriteAllowed({
      action: 'seed agents and skills',
      target: `chain:${args.network}`,
    })
    await assertSharedWriteParityGate({
      action: 'seed agents and skills',
    })
  }

  const privateKey = process.env.PRIVATE_KEY
  if (!privateKey) {
    throw new Error('PRIVATE_KEY environment variable is required')
  }

  const termIdMap = await loadTermIdMap(resolve(process.cwd(), args.termIdMapPath))
  const publicClient = createRegistryPublicClient(args.network)
  const walletClient = createRegistryWalletClient(privateKey, args.network)
  const contractAddress = getContractAddress(args.network)

  const profiled = buildSeedProfile(args.profile, SEED_AGENTS, SEED_SKILLS)
  const corpus = await loadSeedCorpus(args.corpusPath)
  const merged = mergeSeedData(
    profiled.agents,
    profiled.skills,
    corpus.agents,
    corpus.skills,
  )
  const seedAgents = merged.agents
  const seedSkills = merged.skills

  console.log(
    `🧪 Seed dataset profile=${args.profile} agents=${seedAgents.length} skills=${seedSkills.length}` +
      (args.corpusPath ? ` corpus=${args.corpusPath}` : ''),
  )

  const atomCost = await getAtomCost(publicClient, contractAddress).catch(() => 0n)
  const tripleCost = await getTripleCost(publicClient, contractAddress).catch(() => 0n)

  const createdSkillTermIds = new Map<string, `0x${string}`>()
  const createdAgentTermIds = new Map<string, `0x${string}`>()
  let createdSkillCount = 0
  let createdAgentCount = 0
  let createdTripleCount = 0

  for (const skill of seedSkills) {
    // v3: Step 1 - Create identity atom with minimal JSON (name + namespace)
    const skillName = skill.metadata.name
    const identityAtomData = encodeIdentityAtomData(skillName, NAMESPACES.SKILL)
    const identityTermId = deriveIdentityAtomTermId(skillName, NAMESPACES.SKILL)

    // v3: Step 2 - Upload full metadata to IPFS
    const ipfsUri = await uploadSkillMetadata(skill.metadata)
    const metadataTermId = deriveAtomTermId(ipfsUri)

    // v3: Step 3 - Create atoms that don't already exist (idempotent)
    const identityExists = await isAtomOnChain(publicClient, contractAddress, identityTermId)
    const metadataExists = await isAtomOnChain(publicClient, contractAddress, metadataTermId)
    const atomsToCreate = [
      ...(!identityExists ? [identityAtomData] : []),
      ...(!metadataExists ? [ipfsUri] : []),
    ]

    let atomTxHash: string | null = null
    if (atomsToCreate.length > 0) {
      const atomTx = await createAtoms(
        publicClient,
        walletClient,
        contractAddress,
        atomsToCreate,
        0n,
      )
      atomTxHash = atomTx.hash
      await publicClient.waitForTransactionReceipt({ hash: atomTx.hash })
    }
    createdSkillTermIds.set(skillName, identityTermId)
    createdSkillCount += 1

    // v3: Step 4 - Create triples linking identity to metadata, type, and capabilities
    const triples = []

    // has-metadata triple: identity -> metadata atom
    if (termIdMap['has-metadata']) {
      triples.push({
        subjectId: identityTermId,
        predicateId: termIdMap['has-metadata'],
        objectId: metadataTermId,
      })
    }

    // is-type triple: identity -> Skill type
    if (termIdMap['is'] && termIdMap['Skill']) {
      triples.push({
        subjectId: identityTermId,
        predicateId: termIdMap['is'],
        objectId: termIdMap['Skill'],
      })
    }

    // has-capability triples
    if (termIdMap['has-capability']) {
      for (const capability of skill.capabilities) {
        if (termIdMap[capability]) {
          triples.push({
            subjectId: identityTermId,
            predicateId: termIdMap['has-capability'],
            objectId: termIdMap[capability],
          })
        }
      }
    }

    if (triples.length > 0) {
      await createTriples(publicClient, walletClient, contractAddress, triples, 0n)
      createdTripleCount += triples.length
    }
    if (process.env.GRAPHQL_API_URL_PRIVATE) {
      const indexed = await pollIndexerForTermId(process.env.GRAPHQL_API_URL_PRIVATE, identityTermId, {
        maxRetries: 4,
        initialDelayMs: 250,
        maxDelayMs: 2000,
      })
      console.log(
        `✅ Skill ${skillName} atoms=${atomsToCreate.length > 0 ? 'created' : 'existed'} tx=${atomTxHash || 'skipped'} indexed=${indexed ? 'ok' : 'timeout'}`,
      )
    } else {
      console.log(`✅ Skill ${skillName} atoms=${atomsToCreate.length > 0 ? 'created' : 'existed'} tx=${atomTxHash || 'skipped'}`)
    }
  }

  for (const agent of seedAgents) {
    // v3: Step 1 - Create identity atom with minimal JSON (name + namespace)
    const agentName = agent.metadata.name
    const identityAtomData = encodeIdentityAtomData(agentName, NAMESPACES.AGENT)
    const identityTermId = deriveIdentityAtomTermId(agentName, NAMESPACES.AGENT)

    // v3: Step 2 - Upload full metadata to IPFS
    const ipfsUri = await uploadAgentMetadata(agent.metadata)
    const metadataTermId = deriveAtomTermId(ipfsUri)

    // v3: Step 3 - Create atoms that don't already exist (idempotent)
    const identityExists = await isAtomOnChain(publicClient, contractAddress, identityTermId)
    const metadataExists = await isAtomOnChain(publicClient, contractAddress, metadataTermId)
    const atomsToCreate = [
      ...(!identityExists ? [identityAtomData] : []),
      ...(!metadataExists ? [ipfsUri] : []),
    ]

    let atomTxHash: string | null = null
    if (atomsToCreate.length > 0) {
      const atomTx = await createAtoms(
        publicClient,
        walletClient,
        contractAddress,
        atomsToCreate,
        0n,
      )
      atomTxHash = atomTx.hash
      await publicClient.waitForTransactionReceipt({ hash: atomTx.hash })
    }
    createdAgentTermIds.set(agentName, identityTermId)
    createdAgentCount += 1

    // v3: Step 4 - Create triples linking identity to metadata, type, capabilities, and skills
    const triples = []

    // has-metadata triple: identity -> metadata atom
    if (termIdMap['has-metadata']) {
      triples.push({
        subjectId: identityTermId,
        predicateId: termIdMap['has-metadata'],
        objectId: metadataTermId,
      })
    }

    // is-type triple: identity -> Agent type
    if (termIdMap['is'] && termIdMap['Agent']) {
      triples.push({
        subjectId: identityTermId,
        predicateId: termIdMap['is'],
        objectId: termIdMap['Agent'],
      })
    }

    // has-capability triples
    if (termIdMap['has-capability']) {
      for (const capability of agent.capabilities) {
        if (termIdMap[capability]) {
          triples.push({
            subjectId: identityTermId,
            predicateId: termIdMap['has-capability'],
            objectId: termIdMap[capability],
          })
        }
      }
    }

    // uses-skill triples (agent uses skill)
    if (termIdMap['uses']) {
      for (const skillName of agent.skills) {
        const skillTermId = createdSkillTermIds.get(skillName)
        if (!skillTermId) continue
        triples.push({
          subjectId: identityTermId,
          predicateId: termIdMap['uses'],
          objectId: skillTermId,
        })
      }
    }

    if (triples.length > 0) {
      await createTriples(publicClient, walletClient, contractAddress, triples, 0n)
      createdTripleCount += triples.length
    }
    if (process.env.GRAPHQL_API_URL_PRIVATE) {
      const indexed = await pollIndexerForTermId(process.env.GRAPHQL_API_URL_PRIVATE, identityTermId, {
        maxRetries: 4,
        initialDelayMs: 250,
        maxDelayMs: 2000,
      })
      console.log(
        `✅ Agent ${agentName} atoms=${atomsToCreate.length > 0 ? 'created' : 'existed'} tx=${atomTxHash || 'skipped'} indexed=${indexed ? 'ok' : 'timeout'}`,
      )
    } else {
      console.log(`✅ Agent ${agentName} atoms=${atomsToCreate.length > 0 ? 'created' : 'existed'} tx=${atomTxHash || 'skipped'}`)
    }
  }

  const report = {
    network: args.network,
    contractAddress,
    generatedAt: new Date().toISOString(),
    runtimeMs: Date.now() - startedMs,
    totals: {
      agents: createdAgentCount,
      skills: createdSkillCount,
      // v3: 2 atoms per entity (identity + metadata)
      atoms: createdAgentCount * 2 + createdSkillCount * 2,
      triples: createdTripleCount,
    },
    economics: {
      atomCostWei: atomCost.toString(),
      tripleCostWei: tripleCost.toString(),
      // v3: 2 atoms per entity (identity + metadata)
      estimatedValueWei: (
        atomCost * 2n * BigInt(createdAgentCount + createdSkillCount) +
        tripleCost * BigInt(createdTripleCount)
      ).toString(),
    },
  }

  const coverage = buildSeedCoverageReport(seedAgents, seedSkills)
  const coverageGate = validateSeedCoverage(coverage, args.profile)
  coverage.coverageGate = coverageGate
  coverage.profile = args.profile
  coverage.corpus = args.corpusPath
    ? {
        path: args.corpusPath,
        source: corpus.metadata?.source || null,
        importedAt: corpus.metadata?.importedAt || null,
        hash: corpus.metadata?.hash || null,
      }
    : null

  const reportPath = resolve(process.cwd(), args.reportPath)
  const coveragePath = resolve(process.cwd(), args.coverageReportPath)
  await mkdir(resolve(reportPath, '..'), { recursive: true }).catch(() => {})
  await mkdir(resolve(coveragePath, '..'), { recursive: true }).catch(() => {})
  await writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`)
  await writeFile(coveragePath, `${JSON.stringify(coverage, null, 2)}\n`)

  if (!coverageGate.pass && !args.allowCoverageFailure) {
    throw new Error(
      `Coverage gate failed for profile=${args.profile}: ${coverageGate.failures.join('; ')}`,
    )
  }

  console.log(`\n📊 Seed report: ${reportPath}`)
  console.log(`🧪 Coverage report: ${coveragePath}`)
  if (coverageGate.pass) {
    console.log(`✅ Coverage gate passed for profile=${args.profile}`)
  } else {
    console.log(
      `⚠️ Coverage gate bypassed for profile=${args.profile}: ${coverageGate.failures.join('; ')}`,
    )
  }
  console.log(
    `✅ Seed completed agents=${report.totals.agents} skills=${report.totals.skills} atoms=${report.totals.atoms} triples=${report.totals.triples}`,
  )
}

main().catch((error) => {
  console.error('❌ Seeding failed:', error)
  process.exit(1)
})
