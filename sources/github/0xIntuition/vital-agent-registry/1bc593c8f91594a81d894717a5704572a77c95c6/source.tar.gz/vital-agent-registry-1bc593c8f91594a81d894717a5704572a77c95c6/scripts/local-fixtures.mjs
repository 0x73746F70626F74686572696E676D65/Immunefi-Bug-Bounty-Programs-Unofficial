#!/usr/bin/env node

import { metadataPath, outputPath, writeFixtureSnapshot } from './local-fixtures-lib.mjs'

writeFixtureSnapshot()
  .then(({ snapshotHash }) => {
    console.log(`fixture snapshot: ${outputPath}`)
    console.log(`fixture metadata: ${metadataPath}`)
    console.log(`snapshot hash: ${snapshotHash}`)
  })
  .catch((error) => {
  console.error('failed to generate local fixtures', error)
  process.exit(1)
})
