#!/usr/bin/env node

import { createHash } from 'node:crypto'
import { mkdir, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const DEFAULT_LOCAL_GRAPHQL_URL = process.env.LOCAL_GRAPHQL_URL || 'http://localhost:8080/v1/graphql'
const DEFAULT_SHARED_GRAPHQL_URL = process.env.SHARED_GRAPHQL_URL || ''
const DEFAULT_OUTPUT_PATH = resolve(process.cwd(), '.artifacts/local-shared-parity.report.json')
const DEFAULT_PASS_PATH = resolve(process.cwd(), '.artifacts/local-shared-parity.pass.json')

const CONTRACT = {
  queryRoots: [
    'atom',
    'atoms',
    'atom_aggregate',
    'triple',
    'triple_aggregate',
    'vault',
    'vault_aggregate',
  ],
  typeFields: {
    atom: [
      'term_id',
      'label',
      'type',
      'data',
      'created_at',
      'updated_at',
      'term',
      'value',
      'creator',
      'as_subject_triples',
    ],
    triple: [
      'term_id',
      'counter_term_id',
      'subject_id',
      'predicate_id',
      'object_id',
      'predicate',
      'object',
      'term',
    ],
    vault: [
      'term_id',
      'curve_id',
      'total_assets',
      'total_shares',
      'current_share_price',
      'position_count',
      'market_cap',
    ],
  },
}

function parseArgs(argv) {
  const args = {
    localUrl: DEFAULT_LOCAL_GRAPHQL_URL,
    sharedUrl: DEFAULT_SHARED_GRAPHQL_URL,
    output: DEFAULT_OUTPUT_PATH,
    passFile: DEFAULT_PASS_PATH,
    json: false,
  }

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i]
    if (arg === '--local-url') {
      args.localUrl = argv[i + 1] || DEFAULT_LOCAL_GRAPHQL_URL
      i += 1
      continue
    }
    if (arg === '--shared-url') {
      args.sharedUrl = argv[i + 1] || DEFAULT_SHARED_GRAPHQL_URL
      i += 1
      continue
    }
    if (arg === '--output') {
      args.output = argv[i + 1] || DEFAULT_OUTPUT_PATH
      i += 1
      continue
    }
    if (arg === '--pass-file') {
      args.passFile = argv[i + 1] || DEFAULT_PASS_PATH
      i += 1
      continue
    }
    if (arg === '--json') {
      args.json = true
    }
  }

  return args
}

function uniqSorted(values) {
  return [...new Set(values)].sort((a, b) => a.localeCompare(b))
}

function minus(a, b) {
  const right = new Set(b)
  return uniqSorted(a.filter((item) => !right.has(item)))
}

function stableStringify(value) {
  if (value === null || typeof value !== 'object') {
    return JSON.stringify(value)
  }
  if (Array.isArray(value)) {
    return `[${value.map((item) => stableStringify(item)).join(',')}]`
  }
  const entries = Object.entries(value).sort(([a], [b]) => a.localeCompare(b))
  return `{${entries.map(([k, v]) => `${JSON.stringify(k)}:${stableStringify(v)}`).join(',')}}`
}

async function requestGraphql(url, query, variables = {}) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ query, variables }),
  })

  if (!response.ok) {
    throw new Error(`request failed for ${url}: ${response.status} ${response.statusText}`)
  }

  const payload = await response.json()
  if (payload.errors?.length) {
    throw new Error(`graphql errors from ${url}: ${JSON.stringify(payload.errors)}`)
  }

  return payload.data
}

async function fetchSurface(url) {
  const rootData = await requestGraphql(
    url,
    `
      query IntrospectionRoots {
        __schema {
          queryType {
            fields {
              name
            }
          }
        }
      }
    `,
  )

  const queryRoots = uniqSorted((rootData?.__schema?.queryType?.fields || []).map((field) => field.name))

  const typeNames = Object.keys(CONTRACT.typeFields)
  const typeFields = {}
  for (const typeName of typeNames) {
    const typeData = await requestGraphql(
      url,
      `
        query IntrospectionType($name: String!) {
          __type(name: $name) {
            name
            fields {
              name
            }
          }
        }
      `,
      { name: typeName },
    )
    typeFields[typeName] = uniqSorted((typeData?.__type?.fields || []).map((field) => field.name))
  }

  return { url, queryRoots, typeFields }
}

function compareSurfaces(local, shared) {
  const contractMissingLocal = {
    queryRoots: minus(CONTRACT.queryRoots, local.queryRoots),
    typeFields: {},
  }
  const contractMissingShared = {
    queryRoots: minus(CONTRACT.queryRoots, shared.queryRoots),
    typeFields: {},
  }

  const surfaceDiff = {
    queryRootsOnlyLocal: minus(local.queryRoots, shared.queryRoots),
    queryRootsOnlyShared: minus(shared.queryRoots, local.queryRoots),
    typeFieldsOnlyLocal: {},
    typeFieldsOnlyShared: {},
  }

  for (const [typeName, requiredFields] of Object.entries(CONTRACT.typeFields)) {
    const localFields = local.typeFields[typeName] || []
    const sharedFields = shared.typeFields[typeName] || []
    contractMissingLocal.typeFields[typeName] = minus(requiredFields, localFields)
    contractMissingShared.typeFields[typeName] = minus(requiredFields, sharedFields)
    surfaceDiff.typeFieldsOnlyLocal[typeName] = minus(localFields, sharedFields)
    surfaceDiff.typeFieldsOnlyShared[typeName] = minus(sharedFields, localFields)
  }

  const hasContractMismatch =
    contractMissingLocal.queryRoots.length > 0 ||
    contractMissingShared.queryRoots.length > 0 ||
    Object.values(contractMissingLocal.typeFields).some((fields) => fields.length > 0) ||
    Object.values(contractMissingShared.typeFields).some((fields) => fields.length > 0)

  return {
    contractMissingLocal,
    contractMissingShared,
    surfaceDiff,
    hasContractMismatch,
  }
}

async function writeJson(path, value) {
  await mkdir(resolve(path, '..'), { recursive: true })
  await writeFile(path, `${JSON.stringify(value, null, 2)}\n`)
}

async function main() {
  const args = parseArgs(process.argv.slice(2))

  if (!args.sharedUrl) {
    console.error('missing shared GraphQL URL')
    console.error('set SHARED_GRAPHQL_URL or pass --shared-url')
    process.exit(1)
  }

  const [localSurface, sharedSurface] = await Promise.all([
    fetchSurface(args.localUrl),
    fetchSurface(args.sharedUrl),
  ])

  const comparison = compareSurfaces(localSurface, sharedSurface)
  const report = {
    generatedAt: new Date().toISOString(),
    contract: CONTRACT,
    local: localSurface,
    shared: sharedSurface,
    comparison,
    summary: {
      status: comparison.hasContractMismatch ? 'fail' : 'pass',
    },
  }

  await writeJson(args.output, report)

  if (!comparison.hasContractMismatch) {
    const digest = createHash('sha256').update(stableStringify(report)).digest('hex')
    await writeJson(args.passFile, {
      generatedAt: report.generatedAt,
      localUrl: args.localUrl,
      sharedUrl: args.sharedUrl,
      reportPath: args.output,
      reportSha256: digest,
      status: 'pass',
    })
  }

  if (args.json) {
    console.log(JSON.stringify(report))
  } else {
    console.log(`parity status: ${report.summary.status}`)
    console.log(`report: ${args.output}`)
    if (report.summary.status === 'pass') {
      console.log(`pass file: ${args.passFile}`)
    } else {
      console.log('contract mismatches detected between local and shared surfaces')
    }
  }

  if (report.summary.status !== 'pass') {
    process.exit(1)
  }
}

const isDirectRun =
  process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href

if (isDirectRun) {
  main().catch(async (error) => {
    const failureReport = {
      generatedAt: new Date().toISOString(),
      summary: { status: 'fail' },
      error: error instanceof Error ? error.message : 'unknown error',
    }
    const args = parseArgs(process.argv.slice(2))
    await writeJson(args.output, failureReport)
    console.error('failed to run local/shared parity suite')
    console.error(failureReport.error)
    process.exit(1)
  })
}

export { parseArgs, compareSurfaces, CONTRACT }
