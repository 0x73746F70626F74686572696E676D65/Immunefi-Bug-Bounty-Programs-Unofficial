import { describe, expect, it } from 'vitest'
import { parseArgs, assessCreateResult, collectCoverage } from '../local-agent-harness.mjs'

describe('local-agent-harness', () => {
  it('parses defaults', () => {
    const args = parseArgs([])
    expect(args.baseUrl).toBe('http://localhost:4101')
    expect(args.timeoutMs).toBe(10_000)
    expect(args.allowCreateBlocked).toBe(true)
    expect(args.json).toBe(false)
    expect(args.output).toContain('.artifacts/local-agent-harness.report.json')
  })

  it('parses strict create and custom output flags', () => {
    const args = parseArgs([
      '--base-url',
      'http://localhost:9999',
      '--timeout-ms',
      '2500',
      '--output',
      '/tmp/harness.json',
      '--strict-create',
      '--json',
    ])

    expect(args.baseUrl).toBe('http://localhost:9999')
    expect(args.timeoutMs).toBe(2500)
    expect(args.output).toBe('/tmp/harness.json')
    expect(args.allowCreateBlocked).toBe(false)
    expect(args.json).toBe(true)
  })

  it('treats guarded create response as pass when allowed', () => {
    const result = assessCreateResult(
      {
        status: 403,
        json: { code: 'REMOTE_WRITE_BLOCKED' },
        text: '',
      },
      true,
    )

    expect(result.status).toBe('pass')
    expect(result.id).toBe('create-registration')
  })

  it('fails guarded create response in strict mode', () => {
    const result = assessCreateResult(
      {
        status: 403,
        json: { code: 'REMOTE_WRITE_BLOCKED' },
        text: '',
      },
      false,
    )

    expect(result.status).toBe('fail')
    expect(result.id).toBe('create-registration')
  })

  it('collects full workflow coverage from passing checks', () => {
    const coverage = collectCoverage([
      {
        id: 'scout',
        checks: [
          { id: 'discover-agents', status: 'pass' },
          { id: 'stake-signal-readable', status: 'pass' },
          { id: 'evidence-fetch', status: 'pass' },
        ],
      },
      {
        id: 'builder',
        checks: [
          { id: 'create-registration', status: 'pass' },
          { id: 'match-capabilities', status: 'pass' },
        ],
      },
      {
        id: 'auditor',
        checks: [
          { id: 'discover-skills', status: 'pass' },
          { id: 'verify-skills', status: 'pass' },
          { id: 'verify-stake-ordering', status: 'pass' },
        ],
      },
    ])

    expect(coverage).toEqual({
      discover: true,
      create: true,
      stake: true,
      verify: true,
      match: true,
      evidence: true,
    })
  })
})
