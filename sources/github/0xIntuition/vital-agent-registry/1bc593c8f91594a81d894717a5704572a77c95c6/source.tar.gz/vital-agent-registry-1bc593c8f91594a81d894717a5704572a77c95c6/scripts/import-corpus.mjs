#!/usr/bin/env node

import { createHash } from 'node:crypto'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'

function parseArgs(argv) {
  const inputFlag = argv.find((arg) => arg.startsWith('--input='))
  const outputFlag = argv.find((arg) => arg.startsWith('--output='))
  const sourceFlag = argv.find((arg) => arg.startsWith('--source='))
  const input = inputFlag?.split('=')[1]
  if (!input) {
    throw new Error('Missing required --input=<path> argument')
  }
  return {
    inputPath: input,
    outputPath:
      outputFlag?.split('=')[1] || './.artifacts/seed-corpus.snapshot.json',
    source: sourceFlag?.split('=')[1] || 'external-corpus',
  }
}

function dedupeByName(items) {
  const seen = new Set()
  const deduped = []
  for (const item of items) {
    const name = item?.metadata?.name
    if (!name || seen.has(name)) continue
    seen.add(name)
    deduped.push(item)
  }
  return deduped
}

function normalizeSkill(skill) {
  const metadata = skill?.metadata || {}
  return {
    metadata: {
      '@type': 'Skill',
      name: metadata.name,
      description: metadata.description || 'Imported corpus skill',
      version: metadata.version || '0.1.0',
      platform: metadata.platform || 'other',
      author: metadata.author || 'Unknown',
      ...(metadata.installUri ? { installUri: metadata.installUri } : {}),
      ...(metadata.transport ? { transport: metadata.transport } : {}),
      ...(Array.isArray(metadata.requiredEnvVars) && metadata.requiredEnvVars.length > 0
        ? { requiredEnvVars: metadata.requiredEnvVars }
        : {}),
      ...(Array.isArray(metadata.inputModes) && metadata.inputModes.length > 0
        ? { inputModes: metadata.inputModes }
        : {}),
      ...(Array.isArray(metadata.outputModes) && metadata.outputModes.length > 0
        ? { outputModes: metadata.outputModes }
        : {}),
      ...(Array.isArray(metadata.permissions)
        ? { permissions: metadata.permissions }
        : {}),
      ...(metadata.longDescription ? { longDescription: metadata.longDescription } : {}),
    },
    capabilities: Array.isArray(skill?.capabilities) ? skill.capabilities : [],
  }
}

function normalizeAgent(agent) {
  const metadata = agent?.metadata || {}
  // Accept both inputModes (corpus) and defaultInputModes (A2A AgentCard legacy)
  const inputModes = metadata.inputModes ?? metadata.defaultInputModes
  const outputModes = metadata.outputModes ?? metadata.defaultOutputModes
  return {
    metadata: {
      '@type': 'Agent',
      name: metadata.name,
      description: metadata.description || 'Imported corpus agent',
      version: metadata.version || '0.1.0',
      ...(metadata.endpoint ? { endpoint: metadata.endpoint } : {}),
      ...(metadata.protocol ? { protocol: metadata.protocol } : {}),
      ...(metadata.model ? { model: metadata.model } : {}),
      ...(metadata.provider ? { provider: metadata.provider } : {}),
      ...(Array.isArray(inputModes) && inputModes.length > 0
        ? { inputModes }
        : {}),
      ...(Array.isArray(outputModes) && outputModes.length > 0
        ? { outputModes }
        : {}),
    },
    capabilities: Array.isArray(agent?.capabilities) ? agent.capabilities : [],
    skills: Array.isArray(agent?.skills) ? agent.skills : [],
  }
}

async function main() {
  const args = parseArgs(process.argv.slice(2))
  const inputRaw = await readFile(resolve(process.cwd(), args.inputPath), 'utf8')
  const parsed = JSON.parse(inputRaw)

  const agents = dedupeByName(
    (Array.isArray(parsed?.agents) ? parsed.agents : [])
      .filter((item) => item?.metadata?.name)
      .map(normalizeAgent),
  )
  const skills = dedupeByName(
    (Array.isArray(parsed?.skills) ? parsed.skills : [])
      .filter((item) => item?.metadata?.name)
      .map(normalizeSkill),
  )

  const snapshot = {
    source: args.source,
    importedAt: new Date().toISOString(),
    agents,
    skills,
  }
  const canonical = JSON.stringify(snapshot, null, 2)
  const hash = createHash('sha256').update(canonical).digest('hex')
  const output = resolve(process.cwd(), args.outputPath)
  await mkdir(resolve(output, '..'), { recursive: true })
  await writeFile(output, `${canonical}\n`)

  console.log(`corpus snapshot: ${output}`)
  console.log(`source: ${args.source}`)
  console.log(`agents: ${agents.length}`)
  console.log(`skills: ${skills.length}`)
  console.log(`snapshot hash: ${hash}`)
}

main().catch((error) => {
  console.error('failed to import corpus', error)
  process.exit(1)
})
