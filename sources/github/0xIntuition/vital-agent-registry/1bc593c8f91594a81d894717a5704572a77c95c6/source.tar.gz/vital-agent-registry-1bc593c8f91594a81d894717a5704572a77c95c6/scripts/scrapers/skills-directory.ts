/**
 * SkillsDirectory HTML scraper.
 * URL: https://skillsdirectory.com
 *
 * Scrapes category pages, parses skill cards.
 * Limit: top 100 per category.
 * Maps to platform: 'claude-code' (primarily SKILL.md skills).
 * Requires: cheerio
 */

import * as cheerio from 'cheerio'
import type { Corpus, CorpusSkill } from './types'
import { inferCapabilities, slugify, sleep } from './utils'

const BASE_URL = 'https://skillsdirectory.com'
const MAX_PER_CATEGORY = 100

// Known categories — try these pages directly
const CATEGORIES = [
  'development',
  'marketing',
  'research',
  'writing',
  'data',
  'productivity',
  'design',
  'analysis',
]

async function fetchPage(url: string): Promise<string | null> {
  try {
    const res = await fetch(url, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (compatible; AgentRegistryBot/1.0; +https://intuition.systems)',
        Accept: 'text/html,application/xhtml+xml',
      },
      signal: AbortSignal.timeout(15_000),
    })
    if (!res.ok) {
      console.warn(`[skills-directory] HTTP ${res.status} for ${url}`)
      return null
    }
    return res.text()
  } catch (err) {
    console.warn(`[skills-directory] Fetch error: ${err instanceof Error ? err.message : err}`)
    return null
  }
}

function parseSkillCards(html: string, category: string): CorpusSkill[] {
  const $ = cheerio.load(html)
  const skills: CorpusSkill[] = []

  // Try common card selectors
  const cardSelectors = [
    'article',
    '[class*="skill-card"]',
    '[class*="SkillCard"]',
    '[class*="card"]',
    'li[class*="skill"]',
    '.skill',
  ]

  let cards = $('')
  for (const sel of cardSelectors) {
    cards = $(sel)
    if (cards.length > 2) break
  }

  // If no specific cards found, try parsing list items or links
  if (cards.length === 0) {
    cards = $('main li, main a[href*="/skill"]')
  }

  cards.each((_, el) => {
    const $el = $(el)

    const name =
      $el.find('h2, h3, h4').first().text().trim() ||
      $el.find('[class*="name"], [class*="title"]').first().text().trim() ||
      $el.find('a').first().text().trim()

    if (!name || name.length < 2) return

    const description =
      $el.find('p').first().text().trim() ||
      $el.find('[class*="description"], [class*="desc"]').first().text().trim() ||
      `Claude Code skill for ${category}: ${name}`

    skills.push({
      metadata: {
        '@type': 'Skill',
        name: slugify(name),
        description: description.slice(0, 500),
        version: '1.0.0',
        platform: 'claude-code',
        author: 'Community',
      },
      capabilities: inferCapabilities(name, description, category),
    })
  })

  return skills
}

export async function fetchSkillsDirectory(): Promise<Corpus> {
  console.log(`[skills-directory] Scraping ${BASE_URL}...`)

  const allSkills: CorpusSkill[] = []

  // First, try the root page to discover category links
  const rootHtml = await fetchPage(BASE_URL)
  if (!rootHtml) {
    console.warn('[skills-directory] Could not fetch root page')
    return { agents: [], skills: [] }
  }

  // Extract category links from root
  const $ = cheerio.load(rootHtml)
  const discoveredCategories = new Set<string>(CATEGORIES)

  $('a[href*="/categor"], a[href*="/tag"], nav a').each((_, el) => {
    const href = $(el).attr('href') ?? ''
    const segment = href.split('/').filter(Boolean).pop()?.toLowerCase()
    if (segment && segment.length > 2 && segment.length < 30) {
      discoveredCategories.add(segment)
    }
  })

  // Try root page directly
  const rootSkills = parseSkillCards(rootHtml, 'general')
  allSkills.push(...rootSkills.slice(0, MAX_PER_CATEGORY))

  // Scrape each category page
  for (const category of Array.from(discoveredCategories).slice(0, 10)) {
    await sleep(800)

    const categoryUrls = [
      `${BASE_URL}/category/${category}`,
      `${BASE_URL}/${category}`,
      `${BASE_URL}/categories/${category}`,
    ]

    for (const url of categoryUrls) {
      const html = await fetchPage(url)
      if (!html) continue

      const skills = parseSkillCards(html, category)
      console.log(`[skills-directory] Category "${category}": ${skills.length} skills`)

      allSkills.push(...skills.slice(0, MAX_PER_CATEGORY))
      break // Stop trying URLs once one works
    }
  }

  console.log(`[skills-directory] Total: ${allSkills.length} skills`)
  return { agents: [], skills: allSkills }
}
