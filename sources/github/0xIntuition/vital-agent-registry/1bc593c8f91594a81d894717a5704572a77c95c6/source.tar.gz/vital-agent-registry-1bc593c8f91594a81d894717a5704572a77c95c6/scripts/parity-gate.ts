import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { getWriteProfile } from '../app/.server/remote-write-guard'

const DEFAULT_MAX_AGE_HOURS = 24
const DEFAULT_PASS_FILE = resolve(process.cwd(), '.artifacts/local-shared-parity.pass.json')

interface AssertParityGateOptions {
  action: string
  maxAgeHours?: number
}

interface ParityPassFile {
  generatedAt?: string
  status?: string
}

export async function assertSharedWriteParityGate(options: AssertParityGateOptions): Promise<void> {
  if (process.env.BYPASS_PARITY_GATE === '1') {
    return
  }

  const profile = getWriteProfile()
  if (profile !== 'shared') {
    return
  }

  const maxAgeHours = options.maxAgeHours ?? DEFAULT_MAX_AGE_HOURS
  let raw: string
  try {
    raw = await readFile(DEFAULT_PASS_FILE, 'utf8')
  } catch {
    throw new Error(
      [
        `parity gate blocked "${options.action}"`,
        `missing parity pass file: ${DEFAULT_PASS_FILE}`,
        'run: pnpm -C apps/agent-registry local:parity -- --shared-url <shared-graphql-url>',
      ].join('\n'),
    )
  }

  let parsed: ParityPassFile
  try {
    parsed = JSON.parse(raw) as ParityPassFile
  } catch {
    throw new Error(
      [
        `parity gate blocked "${options.action}"`,
        `invalid parity pass file: ${DEFAULT_PASS_FILE}`,
        're-run parity suite to refresh artifacts',
      ].join('\n'),
    )
  }

  if (parsed.status !== 'pass' || !parsed.generatedAt) {
    throw new Error(
      [
        `parity gate blocked "${options.action}"`,
        `parity pass file is not a passing result: ${DEFAULT_PASS_FILE}`,
        'run parity suite and ensure a pass result before shared writes',
      ].join('\n'),
    )
  }

  const generatedAtMs = Date.parse(parsed.generatedAt)
  if (Number.isNaN(generatedAtMs)) {
    throw new Error(
      [
        `parity gate blocked "${options.action}"`,
        `parity pass timestamp invalid in ${DEFAULT_PASS_FILE}`,
      ].join('\n'),
    )
  }

  const ageMs = Date.now() - generatedAtMs
  const maxAgeMs = maxAgeHours * 60 * 60 * 1000
  if (ageMs > maxAgeMs) {
    throw new Error(
      [
        `parity gate blocked "${options.action}"`,
        `parity result is stale (${Math.floor(ageMs / (60 * 1000))}m old > ${maxAgeHours}h max)`,
        're-run: pnpm -C apps/agent-registry local:parity -- --shared-url <shared-graphql-url>',
      ].join('\n'),
    )
  }
}
