export function toStableTermIdMap(entries) {
  const sorted = [...entries].sort((a, b) => a.name.localeCompare(b.name))
  return Object.fromEntries(sorted.map((entry) => [entry.name, entry.termId]))
}

export function partitionBootstrapEntries(entries, existsLookup) {
  const toCreate = []
  const existing = []

  for (const entry of entries) {
    if (existsLookup.has(entry.termId)) {
      existing.push(entry)
      continue
    }
    toCreate.push(entry)
  }

  return { toCreate, existing }
}

export function summarizeByCategory(entries) {
  const summary = {
    predicate: 0,
    type: 0,
    capability: 0,
    platform: 0,
  }
  for (const entry of entries) {
    summary[entry.category] += 1
  }
  return summary
}
