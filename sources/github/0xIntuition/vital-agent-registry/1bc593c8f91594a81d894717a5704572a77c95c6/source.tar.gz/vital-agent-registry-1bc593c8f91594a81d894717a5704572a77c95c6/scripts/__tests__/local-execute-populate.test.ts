import { describe, expect, it } from 'vitest'
import { parseArgs } from '../local-execute-populate.mjs'

describe('local-execute-populate', () => {
  it('parses defaults', () => {
    const args = parseArgs([])
    expect(args.count).toBe(10)
    expect(args.baseUrl).toBe('http://localhost:4101')
    expect(args.timeoutMs).toBe(15_000)
    expect(args.stakeAmountEth).toBe('0.001')
    expect(args.json).toBe(false)
    expect(args.output).toContain('.artifacts/local-execute-populate.report.json')
  })

  it('parses override flags', () => {
    const args = parseArgs([
      '--count',
      '3',
      '--base-url',
      'http://localhost:9999',
      '--timeout-ms',
      '5000',
      '--stake-amount-eth',
      '0.005',
      '--output',
      '/tmp/populate.json',
      '--json',
    ])

    expect(args.count).toBe(3)
    expect(args.baseUrl).toBe('http://localhost:9999')
    expect(args.timeoutMs).toBe(5000)
    expect(args.stakeAmountEth).toBe('0.005')
    expect(args.output).toBe('/tmp/populate.json')
    expect(args.json).toBe(true)
  })
})
