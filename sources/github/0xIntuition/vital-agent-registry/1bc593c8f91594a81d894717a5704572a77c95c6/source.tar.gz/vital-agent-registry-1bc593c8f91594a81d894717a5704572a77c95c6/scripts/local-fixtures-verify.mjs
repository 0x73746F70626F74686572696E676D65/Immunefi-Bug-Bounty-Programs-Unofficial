#!/usr/bin/env node

import { readFile } from 'node:fs/promises'
import {
  buildFixtureSnapshot,
  metadataPath,
  outputPath,
  readFixtureFiles,
} from './local-fixtures-lib.mjs'

async function verifyFixtures() {
  const expected = await buildFixtureSnapshot()
  let actual

  try {
    actual = await readFixtureFiles()
  } catch (error) {
    if (error && typeof error === 'object' && 'code' in error && error.code === 'ENOENT') {
      console.error('fixture files are missing')
      console.error(`expected: ${outputPath}`)
      console.error(`expected: ${metadataPath}`)
      console.error('run: pnpm -C apps/agent-registry local:fixtures')
      process.exit(1)
    }
    throw error
  }

  const drift = []

  if (actual.snapshotRaw !== expected.canonical) {
    drift.push('snapshot content differs from deterministic output')
  }

  if (actual.metadata?.snapshotHash !== expected.snapshotHash) {
    drift.push('snapshot hash mismatch')
  }

  if (actual.metadata?.snapshotBytes !== expected.metadata.snapshotBytes) {
    drift.push('snapshot byte length mismatch')
  }

  if (actual.metadata?.fixtureVersion !== expected.metadata.fixtureVersion) {
    drift.push('fixture version mismatch')
  }

  if (drift.length > 0) {
    console.error('fixture drift detected')
    for (const issue of drift) {
      console.error(`- ${issue}`)
    }
    console.error(`snapshot: ${outputPath}`)
    console.error(`metadata: ${metadataPath}`)
    console.error('refresh: pnpm -C apps/agent-registry local:fixtures')
    process.exit(1)
  }

  const metadataRaw = await readFile(metadataPath, 'utf8')
  console.log('fixture snapshot verification passed')
  console.log(`snapshot: ${outputPath}`)
  console.log(`metadata: ${metadataPath}`)
  console.log(`hash: ${expected.snapshotHash}`)
  console.log(`metadata bytes: ${Buffer.byteLength(metadataRaw, 'utf8')}`)
}

verifyFixtures().catch((error) => {
  console.error('failed to verify local fixtures', error)
  process.exit(1)
})
