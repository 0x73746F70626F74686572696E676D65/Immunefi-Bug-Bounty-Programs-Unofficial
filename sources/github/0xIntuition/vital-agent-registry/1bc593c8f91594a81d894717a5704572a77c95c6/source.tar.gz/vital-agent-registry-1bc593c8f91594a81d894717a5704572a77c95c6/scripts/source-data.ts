#!/usr/bin/env tsx
/**
 * Data sourcing script for the Agent Registry.
 *
 * Fetches agent/skill data from public sources and outputs a corpus JSON
 * file compatible with `scripts/import-corpus.mjs`.
 *
 * Usage:
 *   pnpm seed:source                          # original sources only (default)
 *   pnpm seed:source --sources=all            # all scrapers
 *   pnpm seed:source --sources=mcp-registry,x402-bazaar
 *   pnpm seed:source --sources=all --limit=100  # cap toolsdk entries
 *   pnpm seed:source --sources=all --dry-run    # print counts, don't write files
 *
 * Output:
 *   scripts/data/sourced-corpus.json          (aggregated)
 *   scripts/data/sources/<name>.json          (per-scraper, for debugging)
 */

import { mkdir, writeFile } from 'node:fs/promises'
import { resolve, dirname } from 'node:path'
import type { Corpus, CorpusAgent, CorpusSkill } from './scrapers/types'
import { fetchMcpRegistry } from './scrapers/mcp-registry'
import { fetchToolsdkRegistry } from './scrapers/toolsdk-registry'
import { fetchX402Bazaar } from './scrapers/x402-bazaar'
import { fetchGithubSkills } from './scrapers/github-skills'
import { fetchA2aAgents } from './scrapers/a2a-agents'
import { fetchPulseMcp } from './scrapers/pulsemcp'
import { fetchSkillsDirectory } from './scrapers/skills-directory'
import { inferCapabilities } from './scrapers/utils'

// Re-export types for backwards compat with any external consumers
export type { Corpus, CorpusAgent, CorpusSkill }

// ---------------------------------------------------------------------------
// CLI argument parsing
// ---------------------------------------------------------------------------

function parseArgs(argv: string[]): {
  sources: string[]
  limit: number
  dryRun: boolean
} {
  const sourcesFlag = argv.find((a) => a.startsWith('--sources='))
  const limitFlag = argv.find((a) => a.startsWith('--limit='))
  const dryRun = argv.includes('--dry-run')

  const sourcesRaw = sourcesFlag?.split('=')[1] ?? ''
  const sources = sourcesRaw === 'all'
    ? ['all']
    : sourcesRaw
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean)

  const limit = limitFlag ? parseInt(limitFlag.split('=')[1], 10) : 500

  return { sources, limit, dryRun }
}

// ---------------------------------------------------------------------------
// Source 1 (original): MCP Server Registry — GitHub README
// ---------------------------------------------------------------------------

interface ParsedMcpServer {
  name: string
  description: string
  repoUrl: string
  category: string
}


function parseMcpReadme(markdown: string): ParsedMcpServer[] {
  const servers: ParsedMcpServer[] = []
  const lines = markdown.split('\n')
  let currentCategory = 'uncategorized'

  for (const line of lines) {
    const headerMatch = line.match(/^#{2,3}\s+(.+)/)
    if (headerMatch) {
      currentCategory = headerMatch[1].trim().replace(/[^\w\s-]/g, '').trim()
      continue
    }

    const serverMatch = line.match(
      /^\s*[-*]\s+\*?\*?\[([^\]]+)\]\(([^)]+)\)\*?\*?\s*[-–—:]\s*(.+)/
    )
    if (serverMatch) {
      const [, name, repoUrl, description] = serverMatch
      if (name && repoUrl && description) {
        servers.push({
          name: name.trim(),
          description: description.trim(),
          repoUrl: repoUrl.trim(),
          category: currentCategory,
        })
      }
    }
  }

  return servers
}

function extractAuthor(repoUrl: string): string {
  const ghMatch = repoUrl.match(/github\.com\/([^/]+)/)
  return ghMatch?.[1] || 'Unknown'
}

function mcpServerToSkill(server: ParsedMcpServer): CorpusSkill {
  const isNpm = server.repoUrl.includes('npmjs.com') || server.name.startsWith('@')
  const installUri = isNpm ? `npx ${server.name}` : undefined

  return {
    metadata: {
      '@type': 'Skill',
      name: `mcp-${server.name.toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-')}`,
      description: server.description,
      version: '0.1.0',
      platform: 'mcp',
      author: extractAuthor(server.repoUrl),
      ...(installUri ? { installUri } : {}),
    },
    capabilities: inferCapabilities(server.name, server.description, server.category),
  }
}

async function fetchMcpServersFromReadme(): Promise<Corpus> {
  const url = 'https://raw.githubusercontent.com/modelcontextprotocol/servers/main/README.md'
  console.log(`[mcp-readme] Fetching ${url}...`)

  const response = await fetch(url)
  if (!response.ok) {
    console.warn(`[mcp-readme] Failed to fetch: ${response.status} ${response.statusText}`)
    return { agents: [], skills: [] }
  }

  const markdown = await response.text()
  const parsed = parseMcpReadme(markdown)
  console.log(`[mcp-readme] Parsed ${parsed.length} servers`)

  const limited = parsed.slice(0, 40)
  return { agents: [], skills: limited.map(mcpServerToSkill) }
}

// ---------------------------------------------------------------------------
// Source 2 (original): Claude Built-in Tools (static)
// ---------------------------------------------------------------------------

function getClaudeBuiltinSkills(): Corpus {
  return {
    agents: [],
    skills: [
      {
        metadata: {
          '@type': 'Skill',
          name: 'claude-web-search',
          description: 'Search the web for current information and return relevant results',
          version: '1.0.0',
          platform: 'claude-code',
          author: 'Anthropic',
        },
        capabilities: ['web-search', 'web-access'],
      },
      {
        metadata: {
          '@type': 'Skill',
          name: 'claude-code-execution',
          description: 'Execute code in a sandboxed environment and return results',
          version: '1.0.0',
          platform: 'claude-code',
          author: 'Anthropic',
        },
        capabilities: ['code-generation', 'code-execution'],
      },
      {
        metadata: {
          '@type': 'Skill',
          name: 'claude-file-editor',
          description: 'Read, write, and edit files in the local filesystem',
          version: '1.0.0',
          platform: 'claude-code',
          author: 'Anthropic',
        },
        capabilities: ['file-access'],
      },
      {
        metadata: {
          '@type': 'Skill',
          name: 'claude-bash',
          description: 'Execute bash commands in a terminal environment',
          version: '1.0.0',
          platform: 'claude-code',
          author: 'Anthropic',
        },
        capabilities: ['code-execution', 'file-access'],
      },
      {
        metadata: {
          '@type': 'Skill',
          name: 'claude-text-analysis',
          description: 'Analyze and summarize text documents, extract key information',
          version: '1.0.0',
          platform: 'claude-code',
          author: 'Anthropic',
        },
        capabilities: ['text-analysis', 'document-processing'],
      },
      {
        metadata: {
          '@type': 'Skill',
          name: 'claude-vision',
          description: 'Analyze images and screenshots, extract text and visual information',
          version: '1.0.0',
          platform: 'claude-code',
          author: 'Anthropic',
        },
        capabilities: ['image-processing', 'text-analysis'],
      },
    ],
  }
}

// ---------------------------------------------------------------------------
// Source 3 (original): Well-known AI Agents (static)
// ---------------------------------------------------------------------------

function getWellKnownAgents(): Corpus {
  return {
    agents: [
      {
        metadata: {
          '@type': 'Agent',
          name: 'Claude Code',
          description:
            'Agentic coding assistant that operates in the terminal, understands codebases, and edits files',
          version: '1.0.0',
          model: 'claude-sonnet-4-5-20250929',
          provider: 'Anthropic',
        },
        capabilities: ['code-generation', 'file-access', 'code-execution', 'version-control'],
        skills: ['claude-file-editor', 'claude-bash', 'claude-web-search'],
      },
      {
        metadata: {
          '@type': 'Agent',
          name: 'GitHub Copilot',
          description:
            'AI pair programmer that suggests code completions and helps with code generation',
          version: '1.0.0',
          model: 'gpt-4o',
          provider: 'GitHub',
        },
        capabilities: ['code-generation', 'code-completion'],
        skills: [],
      },
      {
        metadata: {
          '@type': 'Agent',
          name: 'Cursor',
          description: 'AI-powered code editor with chat, autocomplete, and multi-file editing',
          version: '1.0.0',
          model: 'claude-sonnet-4-5-20250929',
          provider: 'Anysphere',
        },
        capabilities: ['code-generation', 'file-access', 'code-completion'],
        skills: [],
      },
      {
        metadata: {
          '@type': 'Agent',
          name: 'Devin',
          description: 'Autonomous software engineering agent that plans, codes, and deploys',
          version: '1.0.0',
          provider: 'Cognition',
        },
        capabilities: ['code-generation', 'deployment', 'web-access', 'testing'],
        skills: [],
      },
      {
        metadata: {
          '@type': 'Agent',
          name: 'OpenHands',
          description:
            'Open-source platform for AI software developers with autonomous coding capabilities',
          version: '1.0.0',
          provider: 'All Hands AI',
        },
        capabilities: ['code-generation', 'file-access', 'code-execution', 'web-access'],
        skills: [],
      },
      {
        metadata: {
          '@type': 'Agent',
          name: 'SWE-agent',
          description: 'Language model agent for solving GitHub issues autonomously',
          version: '1.0.0',
          provider: 'Princeton NLP',
        },
        capabilities: ['code-generation', 'version-control', 'testing'],
        skills: [],
      },
      {
        metadata: {
          '@type': 'Agent',
          name: 'Aider',
          description: 'AI pair programming in your terminal with support for multiple LLMs',
          version: '1.0.0',
          provider: 'Paul Gauthier',
        },
        capabilities: ['code-generation', 'file-access', 'version-control'],
        skills: [],
      },
      {
        metadata: {
          '@type': 'Agent',
          name: 'Continue',
          description: 'Open-source AI code assistant that connects to any LLM and any IDE',
          version: '1.0.0',
          provider: 'Continue',
        },
        capabilities: ['code-generation', 'code-completion'],
        skills: [],
      },
    ],
    skills: [],
  }
}

// ---------------------------------------------------------------------------
// Source registry
// ---------------------------------------------------------------------------

type AsyncSourceFn = () => Promise<Corpus>
type SyncSourceFn = () => Corpus

type SourceFn = AsyncSourceFn | SyncSourceFn

const SOURCES: Record<string, SourceFn> = {
  'mcp-readme': fetchMcpServersFromReadme,
  'claude-builtins': getClaudeBuiltinSkills,
  'well-known-agents': getWellKnownAgents,
  'mcp-registry': fetchMcpRegistry,
  'toolsdk': () => fetchToolsdkRegistry(500),
  'x402-bazaar': fetchX402Bazaar,
  'github-skills': fetchGithubSkills,
  'a2a-agents': fetchA2aAgents,
  'pulsemcp': fetchPulseMcp,
  'skills-directory': fetchSkillsDirectory,
}

const DEFAULT_SOURCES = ['mcp-readme', 'claude-builtins', 'well-known-agents']

// ---------------------------------------------------------------------------
// Aggregation helpers
// ---------------------------------------------------------------------------

function dedupeByName<T extends { metadata: { name: string } }>(items: T[]): T[] {
  const seen = new Set<string>()
  return items.filter((item) => {
    if (seen.has(item.metadata.name)) return false
    seen.add(item.metadata.name)
    return true
  })
}

function mergeCorpora(corpora: Corpus[]): Corpus {
  const agents = dedupeByName(corpora.flatMap((c) => c.agents))
  const skills = dedupeByName(corpora.flatMap((c) => c.skills))
  return { agents, skills }
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  const args = process.argv.slice(2)
  const { sources: sourcesArg, limit, dryRun } = parseArgs(args)

  const selectedSourceKeys =
    sourcesArg.includes('all') || sourcesArg.length === 0
      ? sourcesArg.includes('all')
        ? Object.keys(SOURCES)
        : DEFAULT_SOURCES
      : sourcesArg

  // Update toolsdk limit if custom --limit= provided
  if (limit !== 500 && selectedSourceKeys.includes('toolsdk')) {
    SOURCES['toolsdk'] = () => fetchToolsdkRegistry(limit)
  }

  console.log(`Starting data sourcing pipeline...`)
  console.log(`Sources: ${selectedSourceKeys.join(', ')}\n`)

  const scriptDir = dirname(new URL(import.meta.url).pathname)
  const sourcesDir = resolve(scriptDir, 'data/sources')
  const outputPath = resolve(scriptDir, 'data/sourced-corpus.json')

  if (!dryRun) {
    await mkdir(sourcesDir, { recursive: true })
  }

  const corpora: Corpus[] = []

  for (const key of selectedSourceKeys) {
    const fn = SOURCES[key]
    if (!fn) {
      console.warn(`Unknown source: "${key}" — skipping`)
      continue
    }

    console.log(`\nRunning scraper: ${key}`)
    try {
      const corpus = await Promise.resolve(fn())
      corpora.push(corpus)

      console.log(`  agents: ${corpus.agents.length}, skills: ${corpus.skills.length}`)

      // Write per-source debug file
      if (!dryRun) {
        const sourcePath = resolve(sourcesDir, `${key}.json`)
        await writeFile(sourcePath, `${JSON.stringify(corpus, null, 2)}\n`)
      }
    } catch (err) {
      console.error(`  ERROR in ${key}: ${err instanceof Error ? err.message : err}`)
    }
  }

  const corpus = mergeCorpora(corpora)

  console.log('\n--- Aggregated Corpus ---')
  console.log(`Agents: ${corpus.agents.length}`)
  console.log(`Skills: ${corpus.skills.length}`)

  if (dryRun) {
    console.log('\n[dry-run] Not writing output files.')
    return
  }

  await writeFile(outputPath, `${JSON.stringify(corpus, null, 2)}\n`)

  console.log(`\nOutput: ${outputPath}`)
  console.log('Done.')
}

main().catch((error) => {
  console.error('Data sourcing failed:', error)
  process.exit(1)
})
