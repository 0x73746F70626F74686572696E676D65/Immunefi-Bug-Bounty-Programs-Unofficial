/**
 * A2A Agents scraper — curated seed list + AgentCard discovery.
 *
 * Attempts to fetch agent.json from well-known A2A agent endpoints.
 * Falls back to static metadata for agents that don't expose AgentCards.
 */

import type { Corpus, CorpusAgent } from './types'
import { inferCapabilities, sleep } from './utils'

interface AgentCard {
  name?: string
  description?: string
  version?: string
  url?: string
  skills?: Array<{ id?: string; name?: string; description?: string }>
  capabilities?: {
    streaming?: boolean
    pushNotifications?: boolean
    stateTransitionHistory?: boolean
  }
  defaultInputModes?: string[]
  defaultOutputModes?: string[]
}

interface SeedAgent {
  name: string
  description: string
  endpoint?: string
  provider?: string
  model?: string
  capabilities: string[]
}

const SEED_AGENTS: SeedAgent[] = [
  {
    name: 'claude-code',
    description: 'Agentic coding assistant that operates in the terminal, understands codebases, and edits files',
    provider: 'Anthropic',
    model: 'claude-sonnet-4-5-20250929',
    capabilities: ['code-generation', 'file-access', 'code-execution', 'version-control'],
  },
  {
    name: 'github-copilot',
    description: 'AI pair programmer integrated into GitHub with code suggestions and chat',
    provider: 'GitHub',
    model: 'gpt-4o',
    capabilities: ['code-generation', 'code-completion'],
  },
  {
    name: 'cursor',
    description: 'AI-powered code editor with chat, autocomplete, and multi-file editing',
    provider: 'Anysphere',
    model: 'claude-sonnet-4-5-20250929',
    capabilities: ['code-generation', 'file-access', 'code-completion'],
  },
  {
    name: 'devin',
    description: 'Autonomous software engineering agent that plans, codes, and deploys',
    endpoint: 'https://app.devin.ai',
    provider: 'Cognition',
    capabilities: ['code-generation', 'deployment', 'web-access', 'testing'],
  },
  {
    name: 'open-hands',
    description: 'Open-source AI software developer with autonomous coding capabilities',
    provider: 'All Hands AI',
    capabilities: ['code-generation', 'file-access', 'code-execution', 'web-access'],
  },
  {
    name: 'swe-agent',
    description: 'Language model agent for solving GitHub issues autonomously using SWE-bench',
    provider: 'Princeton NLP',
    capabilities: ['code-generation', 'version-control', 'testing'],
  },
  {
    name: 'aider',
    description: 'AI pair programming in your terminal with support for multiple LLMs',
    provider: 'Paul Gauthier',
    capabilities: ['code-generation', 'file-access', 'version-control'],
  },
  {
    name: 'continue',
    description: 'Open-source AI code assistant that connects to any LLM and any IDE',
    provider: 'Continue',
    capabilities: ['code-generation', 'code-completion'],
  },
  {
    name: 'codeium',
    description: 'AI-powered code acceleration toolkit for developers',
    provider: 'Codeium',
    capabilities: ['code-generation', 'code-completion'],
  },
  {
    name: 'tabnine',
    description: 'AI code completion and chat for professional developers',
    provider: 'Tabnine',
    capabilities: ['code-generation', 'code-completion'],
  },
  {
    name: 'gemini-adk-agent',
    description: 'Agent built with Google Gemini Agent Development Kit for task automation',
    endpoint: 'https://generativelanguage.googleapis.com',
    provider: 'Google',
    model: 'gemini-2.0-flash',
    capabilities: ['text-analysis', 'web-access', 'api-integration'],
  },
  {
    name: 'langchain-agent',
    description: 'Flexible agent framework supporting multiple LLMs with tool use and chain-of-thought reasoning',
    provider: 'LangChain',
    capabilities: ['text-analysis', 'web-search', 'api-integration', 'knowledge-management'],
  },
  {
    name: 'autogen-agent',
    description: 'Multi-agent conversation framework for complex task automation',
    provider: 'Microsoft',
    capabilities: ['code-generation', 'text-analysis', 'api-integration'],
  },
  {
    name: 'crewai-agent',
    description: 'Role-playing AI agent framework for collaborative multi-agent systems',
    provider: 'CrewAI',
    capabilities: ['text-analysis', 'web-search', 'code-generation'],
  },
  {
    name: 'agentgpt',
    description: 'Browser-based autonomous AI agent that completes goals with web access',
    endpoint: 'https://agentgpt.reworkd.ai',
    provider: 'Reworkd',
    capabilities: ['web-access', 'web-search', 'text-analysis'],
  },
  {
    name: 'superagent',
    description: 'Open-source framework for building AI agents with tool use and memory',
    endpoint: 'https://api.superagent.sh',
    provider: 'Superagent',
    capabilities: ['text-analysis', 'api-integration', 'knowledge-management', 'web-search'],
  },
  {
    name: 'fixie-ai',
    description: 'Cloud-hosted AI agents with web access and custom tool integration',
    endpoint: 'https://app.fixie.ai',
    provider: 'Fixie',
    capabilities: ['web-access', 'web-search', 'api-integration'],
  },
  {
    name: 'e2b-agent',
    description: 'Cloud sandbox runtime for AI agents to execute code safely',
    endpoint: 'https://api.e2b.dev',
    provider: 'E2B',
    capabilities: ['code-execution', 'file-access', 'deployment'],
  },
  {
    name: 'sweep-ai',
    description: 'AI junior developer that fixes bugs and implements features from GitHub issues',
    provider: 'Sweep',
    capabilities: ['code-generation', 'version-control', 'testing'],
  },
  {
    name: 'smol-developer',
    description: 'Human-centric, coherent whole program synthesis using GPT-4',
    provider: 'smol-ai',
    capabilities: ['code-generation', 'file-access'],
  },
]

async function tryFetchAgentCard(endpoint: string): Promise<AgentCard | null> {
  const wellKnownUrl = `${endpoint.replace(/\/$/, '')}/.well-known/agent.json`
  try {
    const res = await fetch(wellKnownUrl, {
      headers: { Accept: 'application/json' },
      signal: AbortSignal.timeout(5_000),
    })
    if (!res.ok) return null
    return await res.json()
  } catch {
    return null
  }
}

function agentCardToCorpusAgent(card: AgentCard, seed: SeedAgent): CorpusAgent {
  const capabilities = inferCapabilities(
    card.name ?? seed.name,
    card.description ?? seed.description,
    'agent',
  )

  return {
    metadata: {
      '@type': 'Agent',
      name: card.name ?? seed.name,
      description: (card.description ?? seed.description).slice(0, 500),
      version: card.version ?? '1.0.0',
      endpoint: card.url ?? seed.endpoint,
      protocol: 'a2a',
      model: seed.model,
      provider: seed.provider,
      ...(Array.isArray(card.defaultInputModes) && card.defaultInputModes.length > 0
        ? { inputModes: card.defaultInputModes }
        : {}),
      ...(Array.isArray(card.defaultOutputModes) && card.defaultOutputModes.length > 0
        ? { outputModes: card.defaultOutputModes }
        : {}),
    },
    capabilities,
    skills: (card.skills ?? []).map((s) => s.id ?? s.name ?? '').filter(Boolean),
  }
}

function seedToCorpusAgent(seed: SeedAgent): CorpusAgent {
  return {
    metadata: {
      '@type': 'Agent',
      name: seed.name,
      description: seed.description.slice(0, 500),
      version: '1.0.0',
      ...(seed.endpoint ? { endpoint: seed.endpoint } : {}),
      protocol: 'a2a',
      ...(seed.model ? { model: seed.model } : {}),
      ...(seed.provider ? { provider: seed.provider } : {}),
    },
    capabilities: seed.capabilities,
    skills: [],
  }
}

export async function fetchA2aAgents(): Promise<Corpus> {
  console.log(`[a2a-agents] Processing ${SEED_AGENTS.length} seed agents...`)

  const agents: CorpusAgent[] = []

  for (const seed of SEED_AGENTS) {
    if (seed.endpoint) {
      await sleep(200)
      const card = await tryFetchAgentCard(seed.endpoint)
      if (card) {
        console.log(`[a2a-agents] AgentCard found for ${seed.name}`)
        agents.push(agentCardToCorpusAgent(card, seed))
        continue
      }
    }
    agents.push(seedToCorpusAgent(seed))
  }

  // Also try to discover agents from the A2A samples repo
  try {
    const treeUrl =
      'https://api.github.com/repos/a2aproject/a2a-samples/git/trees/HEAD?recursive=0'
    const treeRes = await fetch(treeUrl, {
      headers: { Accept: 'application/vnd.github.v3+json' },
      signal: AbortSignal.timeout(8_000),
    })

    if (treeRes.ok) {
      const tree = await treeRes.json()
      const agentDirs: string[] = (tree.tree ?? [])
        .filter((item: GitHubTreeItem) => item.type === 'tree' && item.path && !item.path.includes('/'))
        .map((item: GitHubTreeItem) => item.path as string)
        .filter((p: string) => p.includes('agent') || p.includes('sample'))
        .slice(0, 10)

      console.log(`[a2a-agents] Found ${agentDirs.length} sample agent dirs in a2a-samples`)

      for (const dir of agentDirs) {
        const agentName = `a2a-sample-${dir}`
        if (agents.some((a) => a.metadata.name === agentName)) continue

        agents.push({
          metadata: {
            '@type': 'Agent',
            name: agentName,
            description: `A2A sample agent from the a2aproject/a2a-samples repository: ${dir}`,
            version: '0.1.0',
            protocol: 'a2a',
            provider: 'A2A Project',
          },
          capabilities: inferCapabilities(dir, 'a2a sample agent', 'agent'),
          skills: [],
        })
      }
    }
  } catch {
    // Not critical — seed agents are the main source
  }

  console.log(`[a2a-agents] Total: ${agents.length} agents`)
  return { agents, skills: [] }
}

interface GitHubTreeItem {
  path?: string
  type?: string
}
