import { describe, expect, it } from 'vitest'
import { parseArgs, buildPlan } from '../local-agent-test-prep.mjs'

describe('local-agent-test-prep', () => {
  it('parses defaults', () => {
    const args = parseArgs([])
    expect(args.requiredEth).toBe('0.1')
    expect(args.populateCount).toBe(10)
    expect(args.populateStakeEth).toBe('0.001')
    expect(args.skipHealth).toBe(false)
    expect(args.skipFund).toBe(false)
    expect(args.skipPopulate).toBe(false)
    expect(args.skipHarness).toBe(false)
    expect(args.json).toBe(false)
    expect(args.output).toContain('.artifacts/local-agent-test-prep.report.json')
  })

  it('parses overrides and skip flags', () => {
    const args = parseArgs([
      '--required-eth',
      '0.2',
      '--populate-count',
      '25',
      '--populate-stake-eth',
      '0.002',
      '--skip-health',
      '--skip-fund',
      '--skip-populate',
      '--skip-harness',
      '--output',
      '/tmp/prep.json',
      '--json',
    ])

    expect(args.requiredEth).toBe('0.2')
    expect(args.populateCount).toBe(25)
    expect(args.populateStakeEth).toBe('0.002')
    expect(args.skipHealth).toBe(true)
    expect(args.skipFund).toBe(true)
    expect(args.skipPopulate).toBe(true)
    expect(args.skipHarness).toBe(true)
    expect(args.output).toBe('/tmp/prep.json')
    expect(args.json).toBe(true)
  })

  it('builds default end-to-end prep plan', () => {
    const plan = buildPlan(parseArgs([]))
    expect(plan.map((item) => item.id)).toEqual([
      'local-stack-health',
      'local-wallet-fund',
      'local-execute-populate',
      'local-harness',
    ])
  })
})
