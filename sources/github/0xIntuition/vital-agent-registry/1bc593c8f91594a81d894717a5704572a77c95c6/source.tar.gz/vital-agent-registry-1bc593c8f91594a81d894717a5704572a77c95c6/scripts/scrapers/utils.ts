/**
 * Shared utilities for all scrapers.
 */

const capMap: Record<string, string[]> = {
  file: ['file-access'],
  filesystem: ['file-access'],
  database: ['data-retrieval'],
  sql: ['data-retrieval'],
  postgres: ['data-retrieval'],
  sqlite: ['data-retrieval'],
  search: ['web-search'],
  web: ['web-access'],
  fetch: ['web-access'],
  browser: ['web-access'],
  git: ['version-control'],
  github: ['version-control', 'code-management'],
  gitlab: ['version-control', 'code-management'],
  docker: ['containerization'],
  kubernetes: ['containerization'],
  slack: ['messaging'],
  discord: ['messaging'],
  email: ['messaging'],
  memory: ['knowledge-management'],
  knowledge: ['knowledge-management'],
  code: ['code-generation'],
  puppeteer: ['web-automation'],
  playwright: ['web-automation'],
  image: ['image-processing'],
  pdf: ['document-processing'],
  api: ['api-integration'],
  auth: ['authentication'],
  cloud: ['cloud-services'],
  aws: ['cloud-services'],
  gcp: ['cloud-services'],
  azure: ['cloud-services'],
  monitor: ['monitoring'],
  log: ['monitoring'],
  test: ['testing'],
  deploy: ['deployment'],
  ci: ['deployment'],
  payment: ['payments'],
  crypto: ['payments'],
  blockchain: ['web3'],
  nft: ['web3'],
  wallet: ['payments', 'web3'],
  data: ['data-retrieval'],
  analytic: ['analytics'],
  chart: ['analytics'],
  report: ['analytics'],
  nlp: ['text-analysis'],
  text: ['text-analysis'],
  audio: ['audio-processing'],
  video: ['video-processing'],
  calendar: ['productivity'],
  task: ['productivity'],
}

export function inferCapabilities(name: string, description: string, category: string): string[] {
  const caps: string[] = []
  const text = `${name} ${description} ${category}`.toLowerCase()

  for (const [keyword, mappedCaps] of Object.entries(capMap)) {
    if (text.includes(keyword)) {
      for (const cap of mappedCaps) {
        if (!caps.includes(cap)) caps.push(cap)
      }
    }
  }

  if (caps.length === 0) caps.push('general-tool')
  return caps
}

const x402TypeMap: Record<string, string[]> = {
  data: ['data-retrieval'],
  compute: ['code-execution'],
  storage: ['file-access'],
  ai: ['text-analysis', 'code-generation'],
  media: ['image-processing'],
  api: ['api-integration'],
  finance: ['payments'],
  identity: ['authentication'],
}

export function inferCapabilitiesFromX402Type(type: string, description: string): string[] {
  const caps: string[] = []
  const typeLower = (type ?? '').toLowerCase()
  const descLower = (description ?? '').toLowerCase()

  for (const [key, mappedCaps] of Object.entries(x402TypeMap)) {
    if (typeLower.includes(key) || descLower.includes(key)) {
      for (const cap of mappedCaps) {
        if (!caps.includes(cap)) caps.push(cap)
      }
    }
  }

  // x402 resources always have pay-per-use capability
  if (!caps.includes('pay-per-use')) caps.push('pay-per-use')

  if (caps.length === 1) caps.push('general-tool')
  return caps
}

export function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80)
}

export function extractGithubOwner(url: string): string {
  const match = url.match(/github\.com\/([^/]+)/)
  return match?.[1] ?? 'Unknown'
}

export function extractDomain(url: string): string {
  try {
    return new URL(url).hostname
  } catch {
    return 'Unknown'
  }
}

/**
 * Wraps an async factory function with a rate-limit delay.
 * Useful for HTML scrapers that need to be polite to servers.
 */
export function withRateLimit<T>(fn: () => Promise<T>, delayMs: number): () => Promise<T> {
  let lastCall = 0
  return async () => {
    const now = Date.now()
    const wait = Math.max(0, delayMs - (now - lastCall))
    if (wait > 0) await new Promise((resolve) => setTimeout(resolve, wait))
    lastCall = Date.now()
    return fn()
  }
}

/**
 * Sleep for a given number of milliseconds.
 */
export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}
