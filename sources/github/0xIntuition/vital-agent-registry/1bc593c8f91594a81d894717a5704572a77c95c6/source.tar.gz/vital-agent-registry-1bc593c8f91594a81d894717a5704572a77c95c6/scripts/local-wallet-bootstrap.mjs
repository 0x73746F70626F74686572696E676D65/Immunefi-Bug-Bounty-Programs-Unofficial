#!/usr/bin/env node

import { mkdir, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { createPublicClient, formatEther, http } from 'viem'
import { privateKeyToAccount } from 'viem/accounts'
import {
  buildWalletFundingPlan,
  parseRequiredWei,
  parseWalletConfig,
} from './wallet-bootstrap-lib.mjs'

function parseArgs(argv) {
  const rpcFlag = argv.find((arg) => arg.startsWith('--rpc-url='))
  const requiredEthFlag = argv.find((arg) => arg.startsWith('--required-eth='))
  const outputFlag = argv.find((arg) => arg.startsWith('--output='))
  return {
    rpcUrl:
      rpcFlag?.split('=')[1] ||
      process.env.LOCAL_CHAIN_RPC_URL ||
      'http://localhost:8545',
    requiredEth: requiredEthFlag?.split('=')[1] || '1',
    outputPath:
      outputFlag?.split('=')[1] ||
      './.artifacts/local-wallet-bootstrap.report.json',
  }
}

async function main() {
  const args = parseArgs(process.argv.slice(2))
  const requiredWei = parseRequiredWei(args.requiredEth)
  const walletDefs = parseWalletConfig(process.env.LOCAL_TEST_WALLETS_JSON)
  const wallets = walletDefs.map((wallet) => ({
    ...wallet,
    address: privateKeyToAccount(wallet.privateKey).address,
  }))

  const client = createPublicClient({
    transport: http(args.rpcUrl),
  })

  const balancesByAddress = {}
  for (const wallet of wallets) {
    const balance = await client.getBalance({ address: wallet.address })
    balancesByAddress[wallet.address] = balance
  }

  const report = buildWalletFundingPlan({
    wallets: wallets.map(({ privateKey, ...rest }) => rest),
    requiredWei,
    balancesByAddress,
  })

  report.rpcUrl = args.rpcUrl
  report.requiredEth = args.requiredEth
  report.wallets = report.wallets.map((entry) => ({
    ...entry,
    balanceEth: formatEther(BigInt(entry.balanceWei)),
    deficitEth: formatEther(BigInt(entry.deficitWei)),
  }))

  const outputPath = resolve(process.cwd(), args.outputPath)
  await mkdir(resolve(outputPath, '..'), { recursive: true })
  await writeFile(outputPath, `${JSON.stringify(report, null, 2)}\n`)

  console.log(`wallet readiness report: ${outputPath}`)
  console.log(`rpc: ${args.rpcUrl}`)
  console.log(
    `ready wallets: ${report.readyCount}/${report.walletCount} (required ${args.requiredEth} ETH each)`,
  )
  if (report.notReadyCount > 0) {
    console.log(
      `total deficit: ${formatEther(BigInt(report.totalDeficitWei))} ETH`,
    )
  }
}

main().catch((error) => {
  console.error('failed to build local wallet bootstrap report', error)
  process.exit(1)
})
