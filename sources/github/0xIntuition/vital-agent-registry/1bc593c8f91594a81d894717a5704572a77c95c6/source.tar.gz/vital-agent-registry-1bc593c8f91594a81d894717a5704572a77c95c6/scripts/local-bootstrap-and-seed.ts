#!/usr/bin/env tsx
// Combined bootstrap + seed script for local development
// Runs both scripts in sequence with proper error handling

import { spawn } from 'node:child_process'
import { resolve as resolvePath } from 'node:path'

interface ScriptResult {
  success: boolean
  exitCode: number
  output: string
}

function parseArgs(argv: string[]) {
  const networkFlag = argv.find((arg) => arg.startsWith('--network='))
  const privateKeyFlag = argv.find((arg) => arg.startsWith('--private-key='))
  const skipSeedFlag = argv.includes('--skip-seed')
  const skipBootstrapFlag = argv.includes('--skip-bootstrap')
  const profileFlag = argv.find((arg) => arg.startsWith('--profile='))

  return {
    network: networkFlag?.split('=')[1] || process.env.NETWORK || 'local',
    privateKey: privateKeyFlag?.split('=')[1] || process.env.PRIVATE_KEY || '',
    skipSeed: skipSeedFlag,
    skipBootstrap: skipBootstrapFlag,
    profile: profileFlag?.split('=')[1] || process.env.SEED_PROFILE || 'medium',
  }
}

function runScript(scriptPath: string, args: string[]): Promise<ScriptResult> {
  return new Promise((resolve) => {
    const output: string[] = []
    const child = spawn('pnpm', ['tsx', scriptPath, ...args], {
      stdio: ['pipe', 'pipe', 'pipe'],
      env: {
        ...process.env,
        // Ensure NETWORK is set for the child process
        NETWORK: args.includes('--network=local') ? 'local' : 'local',
      },
      cwd: resolvePath(process.cwd()),
    })

    child.stdout?.on('data', (data) => {
      const str = data.toString()
      output.push(str)
      process.stdout.write(str)
    })

    child.stderr?.on('data', (data) => {
      const str = data.toString()
      output.push(str)
      process.stderr.write(str)
    })

    child.on('close', (code) => {
      resolve({
        success: code === 0,
        exitCode: code ?? 1,
        output: output.join(''),
      })
    })

    child.on('error', (err) => {
      output.push(err.message)
      resolve({
        success: false,
        exitCode: 1,
        output: output.join(''),
      })
    })
  })
}

async function main() {
  const args = parseArgs(process.argv.slice(2))
  const startedAt = new Date()
  const startedMs = Date.now()

  console.log(`
╔════════════════════════════════════════════════════════════╗
║         Local Bootstrap + Seed Script                       ║
║         Intuition Agent Registry                            ║
╚════════════════════════════════════════════════════════════╝
`)

  console.log(`Network: ${args.network}`)
  console.log(`Profile: ${args.profile}`)
  console.log(`Timestamp: ${startedAt.toISOString()}\n`)

  // Validate private key
  const privateKey = args.privateKey || process.env.PRIVATE_KEY
  if (!privateKey) {
    console.error('Error: PRIVATE_KEY environment variable is required')
    console.error('Usage: PRIVATE_KEY=0x... pnpm tsx scripts/local-bootstrap-and-seed.ts')
    console.error('  (or use --private-key=0x...)')
    process.exit(1)
  }

  // Validate network
  if (args.network !== 'local' && args.network !== 'testnet' && args.network !== 'mainnet') {
    console.error(`Error: Invalid network: ${args.network}`)
    console.error('Supported networks: local, testnet, mainnet')
    process.exit(1)
  }

  const results: { bootstrap?: ScriptResult; seed?: ScriptResult } = {}

  // Step 1: Run Bootstrap
  if (!args.skipBootstrap) {
    console.log('\n' + '='.repeat(60))
    console.log('Step 1: Running Bootstrap')
    console.log('='.repeat(60) + '\n')

    const bootstrapArgs = [
      `--network=${args.network}`,
      `--term-id-map=./term-id-map.json`,
      `--report=./.artifacts/bootstrap-report.json`,
    ]

    // Set PRIVATE_KEY for bootstrap
    const env = { ...process.env, PRIVATE_KEY: privateKey }

    const bootstrapResult = await new Promise<ScriptResult>((resolve) => {
      const output: string[] = []
      const child = spawn('pnpm', ['tsx', 'scripts/bootstrap.ts', ...bootstrapArgs], {
        stdio: ['pipe', 'pipe', 'pipe'],
        env,
        cwd: resolvePath(process.cwd()),
      })

      child.stdout?.on('data', (data) => {
        const str = data.toString()
        output.push(str)
        process.stdout.write(str)
      })

      child.stderr?.on('data', (data) => {
        const str = data.toString()
        output.push(str)
        process.stderr.write(str)
      })

      child.on('close', (code) => {
        resolve({
          success: code === 0,
          exitCode: code ?? 1,
          output: output.join(''),
        })
      })

      child.on('error', (err) => {
        output.push(err.message)
        resolve({
          success: false,
          exitCode: 1,
          output: output.join(''),
        })
      })
    })

    results.bootstrap = bootstrapResult

    if (!bootstrapResult.success) {
      console.error('\n❌ Bootstrap failed with exit code:', bootstrapResult.exitCode)
      console.error('Cannot continue without successful bootstrap.')
      process.exit(1)
    }

    console.log('\n✅ Bootstrap completed successfully')
  }

  // Step 2: Run Seed
  if (!args.skipSeed) {
    console.log('\n' + '='.repeat(60))
    console.log('Step 2: Running Seed')
    console.log('='.repeat(60) + '\n')

    const seedArgs = [
      `--network=${args.network}`,
      `--term-id-map=./term-id-map.json`,
      `--profile=${args.profile}`,
      `--report=./.artifacts/seed-report.json`,
      `--coverage-report=./.artifacts/seed-coverage.report.json`,
    ]

    const env = { ...process.env, PRIVATE_KEY: privateKey }

    const seedResult = await new Promise<ScriptResult>((resolve) => {
      const output: string[] = []
      const child = spawn('pnpm', ['tsx', 'scripts/seed.ts', ...seedArgs], {
        stdio: ['pipe', 'pipe', 'pipe'],
        env,
        cwd: resolvePath(process.cwd()),
      })

      child.stdout?.on('data', (data) => {
        const str = data.toString()
        output.push(str)
        process.stdout.write(str)
      })

      child.stderr?.on('data', (data) => {
        const str = data.toString()
        output.push(str)
        process.stderr.write(str)
      })

      child.on('close', (code) => {
        resolve({
          success: code === 0,
          exitCode: code ?? 1,
          output: output.join(''),
        })
      })

      child.on('error', (err) => {
        output.push(err.message)
        resolve({
          success: false,
          exitCode: 1,
          output: output.join(''),
        })
      })
    })

    results.seed = seedResult

    if (!seedResult.success) {
      console.error('\n❌ Seed failed with exit code:', seedResult.exitCode)
      process.exit(1)
    }

    console.log('\n✅ Seed completed successfully')
  }

  // Summary
  const finishedMs = Date.now()
  const totalMs = finishedMs - startedMs
  const totalSeconds = Math.round(totalMs / 1000)

  console.log('\n' + '='.repeat(60))
  console.log('Summary')
  console.log('='.repeat(60))
  console.log(`Network: ${args.network}`)
  console.log(`Profile: ${args.profile}`)
  console.log(`Runtime: ${totalSeconds}s`)
  console.log('')

  if (results.bootstrap) {
    console.log(`Bootstrap: ${results.bootstrap.success ? '✅ SUCCESS' : '❌ FAILED'}`)
  }
  if (results.seed) {
    console.log(`Seed: ${results.seed.success ? '✅ SUCCESS' : '❌ FAILED'}`)
  }

  console.log('')
  console.log('Output files:')
  console.log('  - term-id-map.json')
  console.log('  - .artifacts/bootstrap-report.json')
  console.log('  - .artifacts/seed-report.json')
  console.log('  - .artifacts/seed-coverage.report.json')
  console.log('')
  console.log('🎉 Local bootstrap + seed complete!')
}

main().catch((error) => {
  console.error('\n❌ Combined script failed:', error)
  process.exit(1)
})
