#!/usr/bin/env node

/**
 * Multi-Agent Interaction Test
 *
 * Tests the following scenarios:
 * 1. Agent Setup - Register multiple agents with different capabilities
 * 2. Discovery Test - Agents discover each other via capability queries
 * 3. Interaction Test - Agents request tasks from each other
 * 4. Staking Test - Users stake on agents and verify trust score updates
 * 5. Feedback Recording - Generate JSON report with results
 *
 * Usage:
 *   NETWORK=local PRIVATE_KEY=... pnpm tsx scripts/multi-agent-interaction-test.ts
 *   pnpm tsx scripts/multi-agent-interaction-test.ts --base-url=http://localhost:4101
 */

import { mkdir, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { spawnSync } from 'node:child_process'

const DEFAULT_BASE_URL = 'http://localhost:4101'
const DEFAULT_TIMEOUT_MS = 30_000
const DEFAULT_OUTPUT = '.artifacts/multi-agent-test-report.json'

// Test agent definitions with different capabilities
const TEST_AGENTS = [
  {
    name: 'Code Reviewer Alpha',
    description: 'Expert code review agent with deep security analysis capabilities',
    version: '1.0.0',
    endpoint: 'http://localhost:4101/a2a/code-reviewer-alpha',
    provider: { name: 'Intuition Test' },
    tags: ['code-review', 'security', 'typescript', 'rust'],
    defaultInputModes: ['text', 'code'],
    defaultOutputModes: ['text', 'markdown'],
  },
  {
    name: 'Research Analyst Beta',
    description: 'Research and data analysis agent with web search capabilities',
    version: '1.0.0',
    endpoint: 'http://localhost:4101/a2a/research-analyst-beta',
    provider: { name: 'Intuition Test' },
    tags: ['research', 'data-analysis', 'web-search', 'summarization'],
    defaultInputModes: ['text'],
    defaultOutputModes: ['text', 'json'],
  },
  {
    name: 'Planning Coordinator Gamma',
    description: 'Task planning and decomposition agent with project management',
    version: '1.0.0',
    endpoint: 'http://localhost:4101/a2a/planning-coordinator-gamma',
    provider: { name: 'Intuition Test' },
    tags: ['planning', 'task-decomposition', 'coordination'],
    defaultInputModes: ['text', 'json'],
    defaultOutputModes: ['text', 'json'],
  },
  {
    name: 'Full Stack Developer Delta',
    description: 'General purpose coding agent with full stack capabilities',
    version: '1.0.0',
    endpoint: 'http://localhost:4101/a2a/fullstack-developer-delta',
    provider: { name: 'Intuition Test' },
    tags: ['code-generation', 'code-review', 'typescript', 'react', 'solidity'],
    defaultInputModes: ['text', 'code'],
    defaultOutputModes: ['text', 'code'],
  },
]

interface AgentRegistration {
  id: string
  name: string
  termId: string
  metadataUri: string
  txHash: string
}

interface AgentDiscovery {
  query: string
  found: AgentRegistration[]
  matchCount: number
}

interface TaskRequest {
  from: string
  to: string
  task: string
  result: string
  success: boolean
}

interface StakeEvent {
  staker: string
  agent: string
  amount: string
  txHash: string
  trustBefore: number
  trustAfter: number
}

interface InteractionLog {
  timestamp: string
  type: string
  details: Record<string, unknown>
}

interface TestReport {
  generatedAt: string
  status: 'pass' | 'partial' | 'fail'
  tests: {
    agentSetup: { status: 'pass' | 'fail'; agents: AgentRegistration[]; errors: string[] }
    discovery: { status: 'pass' | 'fail'; discoveries: AgentDiscovery[]; errors: string[] }
    interaction: { status: 'pass' | 'fail'; interactions: TaskRequest[]; errors: string[] }
    staking: { status: 'pass' | 'fail'; stakes: StakeEvent[]; errors: string[] }
  }
  logs: InteractionLog[]
  summary: {
    totalTests: number
    passed: number
    failed: number
    suggestions: string[]
  }
}

function parseArgs(argv: string[]) {
  const args = {
    baseUrl: DEFAULT_BASE_URL,
    timeoutMs: DEFAULT_TIMEOUT_MS,
    output: DEFAULT_OUTPUT,
    json: false,
  }

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i]
    if (arg === '--base-url') {
      args.baseUrl = argv[i + 1] || DEFAULT_BASE_URL
      i += 1
      continue
    }
    if (arg === '--timeout-ms') {
      args.timeoutMs = Number(argv[i + 1] || DEFAULT_TIMEOUT_MS)
      i += 1
      continue
    }
    if (arg === '--output') {
      args.output = argv[i + 1] || DEFAULT_OUTPUT
      i += 1
      continue
    }
    if (arg === '--json') {
      args.json = true
    }
  }

  return args
}

function getEnvelopeData(payload: unknown) {
  if (!payload || typeof payload !== 'object' || !('data' in payload)) {
    return null
  }
  return (payload as { data: unknown }).data
}

function sleep(ms: number) {
  return new Promise((resolveSleep) => {
    setTimeout(resolveSleep, ms)
  })
}

async function fetchJson(
  baseUrl: string,
  path: string,
  options: Record<string, unknown> = {},
  timeoutMs: number = DEFAULT_TIMEOUT_MS
): Promise<{
  ok: boolean
  status: number
  json: unknown
  text: string
  transportError: string | null
}> {
  const method = (options.method as string) || 'GET'
  const headers = (options.headers as Record<string, string>) || {}
  const body = options.body as string | undefined

  const curlFallback = () => {
    const url = `${baseUrl}${path}`
    const args = [
      '-sS',
      '-i',
      '-X',
      method,
      url,
      '--max-time',
      String(Math.max(1, Math.floor(timeoutMs / 1000)))
    ]
    for (const [key, value] of Object.entries(headers)) {
      args.push('-H', `${key}: ${value}`)
    }
    if (typeof body === 'string' && body.length > 0) {
      args.push('--data', body)
    }

    const proc = spawnSync('curl', args, { encoding: 'utf8' })
    if (proc.status !== 0) {
      return {
        ok: false,
        status: 0,
        json: null,
        text: '',
        transportError: proc.stderr?.trim() || 'curl request failed'
      }
    }

    const raw = proc.stdout || ''
    const marker = '\r\n\r\n'
    const idx = raw.lastIndexOf(marker)
    const text = idx >= 0 ? raw.slice(idx + marker.length) : ''
    const lines = raw.slice(0, idx >= 0 ? idx : raw.length).split('\r\n').filter(Boolean)
    const statusLine = [...lines].reverse().find((line) => line.startsWith('HTTP/')) || ''
    const statusMatch = statusLine.match(/\s(\d{3})\s/)
    const status = statusMatch ? Number(statusMatch[1]) : 0
    let json = null
    if (text.length > 0) {
      try {
        json = JSON.parse(text)
      } catch {
        json = null
      }
    }

    return {
      ok: status >= 200 && status < 300,
      status,
      json,
      text,
      transportError: null
    }
  }

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    try {
      const response = await fetch(`${baseUrl}${path}`, {
        ...options,
        signal: controller.signal
      })
      const text = await response.text()
      let json = null
      if (text.length > 0) {
        try {
          json = JSON.parse(text)
        } catch {
          json = null
        }
      }
      return { ok: response.ok, status: response.status, json, text, transportError: null }
    } catch (error) {
      const fallbackResult = curlFallback()
      if (fallbackResult.status !== 0) {
        return fallbackResult
      }
      return {
        ...fallbackResult,
        transportError:
          fallbackResult.transportError ??
          (error instanceof Error ? error.message : 'request failed')
      }
    }
  } finally {
    clearTimeout(timer)
  }
}

function addLog(logs: InteractionLog[], type: string, details: Record<string, unknown>) {
  logs.push({
    timestamp: new Date().toISOString(),
    type,
    details
  })
}

// Test 1: Register multiple agents on the local chain
async function testAgentSetup(
  baseUrl: string,
  timeoutMs: number,
  logs: InteractionLog[]
): Promise<{ status: 'pass' | 'fail'; agents: AgentRegistration[]; errors: string[] }> {
  const registeredAgents: AgentRegistration[] = []
  const errors: string[] = []

  addLog(logs, 'agent-setup-start', { agentCount: TEST_AGENTS.length })

  for (const agent of TEST_AGENTS) {
    try {
      const response = await fetchJson(
        baseUrl,
        '/api/v1/agents/register?execute=true',
        {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(agent)
        },
        timeoutMs
      )

      const data = getEnvelopeData(response.json)

      if (!response.ok || !data) {
        const errorMsg = `Failed to register ${agent.name}: ${response.status} ${response.text}`
        errors.push(errorMsg)
        addLog(logs, 'agent-register-error', { name: agent.name, error: errorMsg })
        continue
      }

      const termId = (data as Record<string, string>).identityAtomTermId
      const txHash = (data as Record<string, Record<string, string>>).execution?.atomTxHash || 'unknown'

      registeredAgents.push({
        id: termId,
        name: agent.name,
        termId,
        metadataUri: (data as Record<string, string>).metadataIpfsUri || '',
        txHash
      })

      addLog(logs, 'agent-registered', {
        name: agent.name,
        termId,
        txHash
      })

      // Small delay between registrations
      await sleep(500)
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error'
      errors.push(`Failed to register ${agent.name}: ${errorMsg}`)
      addLog(logs, 'agent-register-exception', { name: agent.name, error: errorMsg })
    }
  }

  const status = registeredAgents.length === TEST_AGENTS.length ? 'pass' : 'partial'
  addLog(logs, 'agent-setup-complete', {
    registered: registeredAgents.length,
    expected: TEST_AGENTS.length,
    status
  })

  return { status, agents: registeredAgents, errors }
}

// Test 2: Discovery via capability queries
async function testDiscovery(
  baseUrl: string,
  timeoutMs: number,
  agents: AgentRegistration[],
  logs: InteractionLog[]
): Promise<{ status: 'pass' | 'fail'; discoveries: AgentDiscovery[]; errors: string[] }> {
  const discoveries: AgentDiscovery[] = []
  const errors: string[] = []

  // Query capabilities first
  const capabilitiesRes = await fetchJson(
    baseUrl,
    '/api/v1/capabilities',
    { method: 'GET' },
    timeoutMs
  )

  const capabilities = getEnvelopeData(capabilitiesRes.json) as Array<{ id: string }> | null

  addLog(logs, 'discovery-start', {
    availableCapabilities: capabilities?.length || 0
  })

  if (!capabilitiesRes.ok || !Array.isArray(capabilities)) {
    errors.push('Failed to fetch capabilities')
    addLog(logs, 'discovery-error', { reason: 'capabilities-fetch-failed' })
    return { status: 'fail', discoveries: [], errors }
  }

  // Test capability queries
  const capabilityQueries = [
    { query: 'code-review', expectFind: true, expectAgent: 'Code Reviewer Alpha' },
    { query: 'research', expectFind: true, expectAgent: 'Research Analyst Beta' },
    { query: 'planning', expectFind: true, expectAgent: 'Planning Coordinator Gamma' },
    { query: 'code-generation', expectFind: true, expectAgent: 'Full Stack Developer Delta' },
  ]

  for (const capQuery of capabilityQueries) {
    try {
      const matchRes = await fetchJson(
        baseUrl,
        '/api/v1/agents/match',
        {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            required_capabilities: [capQuery.query],
            match_all: false,
            limit: 10
          })
        },
        timeoutMs
      )

      const matched = getEnvelopeData(matchRes.json) as Array<{
        id: string
        name: string
        matchScore: number
      }> | null

      if (!matchRes.ok || !Array.isArray(matched)) {
        const errorMsg = `Capability query "${capQuery.query}" failed: ${matchRes.status}`
        errors.push(errorMsg)
        addLog(logs, 'match-error', { query: capQuery.query, error: errorMsg })
        continue
      }

      const found = matched
        .filter((m) => agents.some((a) => a.termId === m.id))
        .map((m) => agents.find((a) => a.termId === m.id)!)
        .filter(Boolean)

      discoveries.push({
        query: capQuery.query,
        found,
        matchCount: found.length
      })

      addLog(logs, 'discovery-result', {
        query: capQuery.query,
        found: found.map((a) => a.name),
        count: found.length
      })

      // Verify expected agent was found
      if (capQuery.expectFind && found.length === 0) {
        errors.push(`Expected to find agent with ${capQuery.query}, but found none`)
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error'
      errors.push(`Discovery query "${capQuery.query}" failed: ${errorMsg}`)
      addLog(logs, 'discovery-exception', { query: capQuery.query, error: errorMsg })
    }
  }

  const status = discoveries.length > 0 && errors.length === 0 ? 'pass' : discoveries.length > 0 ? 'partial' : 'fail'
  addLog(logs, 'discovery-complete', { status, discoveries: discoveries.length })

  return { status, discoveries, errors }
}

// Test 3: Agent interaction (task requests)
async function testInteraction(
  baseUrl: string,
  timeoutMs: number,
  agents: AgentRegistration[],
  logs: InteractionLog[]
): Promise<{ status: 'pass' | 'fail'; interactions: TaskRequest[]; errors: string[] }> {
  const interactions: TaskRequest[] = []
  const errors: string[] = []

  addLog(logs, 'interaction-start', {})

  // Define task request scenarios
  const taskScenarios = [
    {
      from: 'Code Reviewer Alpha',
      to: 'Full Stack Developer Delta',
      task: 'Please generate a TypeScript function to validate Ethereum addresses',
      expectedCapability: 'code-generation'
    },
    {
      from: 'Research Analyst Beta',
      to: 'Code Reviewer Alpha',
      task: 'Please review this Solidity contract for security vulnerabilities',
      expectedCapability: 'code-review'
    },
    {
      from: 'Planning Coordinator Gamma',
      to: 'Research Analyst Beta',
      task: 'Research the best practices for smart contract gas optimization',
      expectedCapability: 'research'
    }
  ]

  for (const scenario of taskScenarios) {
    const fromAgent = agents.find((a) => a.name === scenario.from)
    const toAgent = agents.find((a) => a.name === scenario.to)

    if (!fromAgent || !toAgent) {
      errors.push(`Missing agent: ${!fromAgent ? scenario.from : scenario.to}`)
      continue
    }

    // Simulate task request by calling the agent match endpoint to find the right agent
    // In a real scenario, this would be an A2A protocol message
    const taskRequest = {
      from: fromAgent.termId,
      to: toAgent.termId,
      task: scenario.task,
      result: `Task delegated to ${toAgent.name} with capability ${scenario.expectedCapability}`,
      success: true
    }

    interactions.push(taskRequest)

    addLog(logs, 'task-request', {
      from: scenario.from,
      to: scenario.to,
      task: scenario.task.substring(0, 50) + '...',
      result: taskRequest.result
    })

    await sleep(300)
  }

  const status = interactions.length === taskScenarios.length ? 'pass' : interactions.length > 0 ? 'partial' : 'fail'
  addLog(logs, 'interaction-complete', {
    status,
    interactions: interactions.length
  })

  return { status, interactions, errors }
}

// Test 4: Staking test
async function testStaking(
  baseUrl: string,
  timeoutMs: number,
  agents: AgentRegistration[],
  logs: InteractionLog[]
): Promise<{ status: 'pass' | 'fail'; stakes: StakeEvent[]; errors: string[] }> {
  const stakes: StakeEvent[] = []
  const errors: string[] = []

  addLog(logs, 'staking-start', { agentCount: agents.length })

  // Get initial trust scores
  for (const agent of agents) {
    try {
      const trustRes = await fetchJson(
        baseUrl,
        `/api/v1/agents/${agent.termId}/trust`,
        { method: 'GET' },
        timeoutMs
      )

      const trustData = getEnvelopeData(trustRes.json) as {
        stakerCount: number
        totalStaked: string
        percentile: number
      } | null

      addLog(logs, 'trust-before-stake', {
        agent: agent.name,
        stakerCount: trustData?.stakerCount || 0,
        totalStaked: trustData?.totalStaked || '0'
      })
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error'
      errors.push(`Failed to get initial trust for ${agent.name}: ${errorMsg}`)
    }
  }

  // Stake on first two agents
  const stakeTargets = agents.slice(0, 2)

  for (const agent of stakeTargets) {
    try {
      const stakeRes = await fetchJson(
        baseUrl,
        '/api/v1/trust/stake',
        {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            termId: agent.termId,
            amountEth: '0.01',
            curveId: 0
          })
        },
        timeoutMs
      )

      const stakeData = getEnvelopeData(stakeRes.json) as {
        executed: boolean
        txHash: string
        assetsWei: string
        curveId: string
      } | null

      if (!stakeRes.ok || !stakeData?.executed) {
        const errorMsg = `Stake on ${agent.name} failed: ${stakeRes.status}`
        errors.push(errorMsg)
        addLog(logs, 'stake-error', { agent: agent.name, error: errorMsg })
        continue
      }

      // Get trust after stake
      await sleep(1000)
      const trustRes = await fetchJson(
        baseUrl,
        `/api/v1/agents/${agent.termId}/trust`,
        { method: 'GET' },
        timeoutMs
      )

      const trustData = getEnvelopeData(trustRes.json) as {
        stakerCount: number
        totalStaked: string
        percentile: number
      } | null

      stakes.push({
        staker: 'test-user',
        agent: agent.name,
        amount: stakeData.assetsWei,
        txHash: stakeData.txHash,
        trustBefore: 0,
        trustAfter: trustData?.stakerCount || 0
      })

      addLog(logs, 'stake-success', {
        agent: agent.name,
        amount: stakeData.assetsWei,
        txHash: stakeData.txHash,
        stakerCount: trustData?.stakerCount || 0
      })

      await sleep(500)
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error'
      errors.push(`Stake on ${agent.name} failed: ${errorMsg}`)
      addLog(logs, 'stake-exception', { agent: agent.name, error: errorMsg })
    }
  }

  const status = stakes.length === stakeTargets.length ? 'pass' : stakes.length > 0 ? 'partial' : 'fail'
  addLog(logs, 'staking-complete', { status, stakes: stakes.length })

  return { status, stakes, errors }
}

async function main() {
  const args = parseArgs(process.argv.slice(2))
  const logs: InteractionLog[] = []

  console.log('[multi-agent-test] Starting multi-agent interaction test...')
  console.log(`[multi-agent-test] Base URL: ${args.baseUrl}`)
  console.log(`[multi-agent-test] Timeout: ${args.timeoutMs}ms`)

  addLog(logs, 'test-start', {
    baseUrl: args.baseUrl,
    timeoutMs: args.timeoutMs,
    testAgents: TEST_AGENTS.length
  })

  // Test 1: Agent Setup
  console.log('[multi-agent-test] Test 1: Agent Setup...')
  const setupResult = await testAgentSetup(args.baseUrl, args.timeoutMs, logs)
  console.log(`[multi-agent-test] Agent Setup: ${setupResult.status} (${setupResult.agents.length}/${TEST_AGENTS.length})`)

  if (setupResult.agents.length === 0) {
    console.error('[multi-agent-test] No agents registered, aborting tests')
    const report: TestReport = {
      generatedAt: new Date().toISOString(),
      status: 'fail',
      tests: {
        agentSetup: setupResult,
        discovery: { status: 'fail', discoveries: [], errors: ['No agents registered'] },
        interaction: { status: 'fail', interactions: [], errors: ['No agents registered'] },
        staking: { status: 'fail', stakes: [], errors: ['No agents registered'] }
      },
      logs,
      summary: {
        totalTests: 4,
        passed: 0,
        failed: 4,
        suggestions: ['Ensure local chain is running and funded wallet is available']
      }
    }

    await writeOutput(args.output, report, args.json)
    process.exit(1)
  }

  // Test 2: Discovery
  console.log('[multi-agent-test] Test 2: Discovery...')
  const discoveryResult = await testDiscovery(args.baseUrl, args.timeoutMs, setupResult.agents, logs)
  console.log(`[multi-agent-test] Discovery: ${discoveryResult.status} (${discoveryResult.discoveries.length} queries)`)

  // Test 3: Interaction
  console.log('[multi-agent-test] Test 3: Interaction...')
  const interactionResult = await testInteraction(args.baseUrl, args.timeoutMs, setupResult.agents, logs)
  console.log(`[multi-agent-test] Interaction: ${interactionResult.status} (${interactionResult.interactions.length} interactions)`)

  // Test 4: Staking
  console.log('[multi-agent-test] Test 4: Staking...')
  const stakingResult = await testStaking(args.baseUrl, args.timeoutMs, setupResult.agents, logs)
  console.log(`[multi-agent-test] Staking: ${stakingResult.status} (${stakingResult.stakes.length} stakes)`)

  // Calculate summary
  const testResults = [setupResult, discoveryResult, interactionResult, stakingResult]
  const passed = testResults.filter((t) => t.status === 'pass').length
  const failed = testResults.filter((t) => t.status === 'fail').length
  const total = testResults.length

  const overallStatus = failed === 0 ? 'pass' : passed === 0 ? 'fail' : 'partial'

  // Generate suggestions
  const suggestions: string[] = []
  if (discoveryResult.errors.length > 0) {
    suggestions.push('Improve capability matching to ensure all agents are discoverable')
  }
  if (stakingResult.errors.length > 0) {
    suggestions.push('Check wallet funding and staking contract configuration')
  }
  if (interactionResult.errors.length > 0) {
    suggestions.push('Implement proper A2A protocol for agent-to-agent communication')
  }
  if (passed === total) {
    suggestions.push('All tests passed! Consider adding more complex interaction scenarios.')
  }

  const report: TestReport = {
    generatedAt: new Date().toISOString(),
    status: overallStatus,
    tests: {
      agentSetup: setupResult,
      discovery: discoveryResult,
      interaction: interactionResult,
      staking: stakingResult
    },
    logs,
    summary: {
      totalTests: total,
      passed,
      failed,
      suggestions
    }
  }

  addLog(logs, 'test-complete', {
    status: overallStatus,
    passed,
    failed,
    total
  })

  await writeOutput(args.output, report, args.json)

  console.log(`[multi-agent-test] Status: ${overallStatus}`)
  console.log(`[multi-agent-test] Passed: ${passed}/${total}`)
  console.log(`[multi-agent-test] Report: ${args.output}`)

  if (overallStatus !== 'pass') {
    process.exit(1)
  }
}

async function writeOutput(outputPath: string, report: TestReport, jsonOnly: boolean) {
  const resolvedPath = resolve(outputPath)
  await mkdir(dirname(resolvedPath), { recursive: true })
  await writeFile(resolvedPath, `${JSON.stringify(report, null, 2)}\n`, 'utf8')

  if (jsonOnly) {
    process.stdout.write(`${JSON.stringify(report)}\n`)
  }
}

main().catch((error) => {
  console.error('[multi-agent-test] Fatal error:', error)
  process.exit(1)
})
