import { describe, expect, it } from 'vitest'
import { parseArgs, buildPlan } from '../hard-checkpoint.mjs'

describe('hard-checkpoint', () => {
  it('parses default flags', () => {
    const args = parseArgs([])
    expect(args.output).toContain('.artifacts/hard-checkpoint.report.json')
    expect(args.skipHarness).toBe(false)
    expect(args.skipHealth).toBe(false)
    expect(args.includeExecuteSmoke).toBe(false)
    expect(args.json).toBe(false)
  })

  it('parses override flags', () => {
    const args = parseArgs([
      '--output',
      '/tmp/report.json',
      '--skip-harness',
      '--skip-health',
      '--include-execute-smoke',
      '--json',
    ])
    expect(args.output).toBe('/tmp/report.json')
    expect(args.skipHarness).toBe(true)
    expect(args.skipHealth).toBe(true)
    expect(args.includeExecuteSmoke).toBe(true)
    expect(args.json).toBe(true)
  })

  it('builds full checkpoint plan by default', () => {
    const plan = buildPlan(parseArgs([]))
    expect(plan.map((p) => p.id)).toEqual([
      'typecheck',
      'tests',
      'local-stack-health',
      'local-agent-harness',
    ])
  })

  it('supports quick mode via skip flags', () => {
    const plan = buildPlan(parseArgs(['--skip-harness', '--skip-health']))
    expect(plan.map((p) => p.id)).toEqual(['typecheck', 'tests'])
  })

  it('adds execute smoke when include flag is set', () => {
    const plan = buildPlan(parseArgs(['--include-execute-smoke']))
    expect(plan.map((p) => p.id)).toEqual([
      'typecheck',
      'tests',
      'local-stack-health',
      'local-agent-harness',
      'local-execute-smoke',
    ])
  })
})
