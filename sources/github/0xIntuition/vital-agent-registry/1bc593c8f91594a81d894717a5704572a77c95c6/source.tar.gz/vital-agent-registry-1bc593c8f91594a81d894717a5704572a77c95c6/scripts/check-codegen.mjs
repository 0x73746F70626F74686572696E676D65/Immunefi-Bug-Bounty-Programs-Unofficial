#!/usr/bin/env node

import { execSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'

const workspace = resolve(process.cwd())
const generatedPath = resolve(workspace, 'app/lib/graphql/generated/index.ts')

function run(cmd) {
  execSync(cmd, {
    cwd: workspace,
    stdio: 'inherit',
    env: process.env,
  })
}

async function main() {
  run('pnpm codegen')

  const generated = await readFile(generatedPath, 'utf8')
  const manualAnyPatchCount = (generated.match(/\bas any\b/g) || []).length
  if (manualAnyPatchCount > 0) {
    console.error(
      `codegen check failed: found ${manualAnyPatchCount} manual "as any" patches in generated types`,
    )
    process.exit(1)
  }

  const hash1 = createHash('sha256').update(generated).digest('hex')
  run('pnpm codegen')
  const regenerated = await readFile(generatedPath, 'utf8')
  const hash2 = createHash('sha256').update(regenerated).digest('hex')
  if (hash1 !== hash2) {
    console.error('codegen check failed: generation is non-deterministic across reruns')
    process.exit(1)
  }

  console.log('codegen check passed')
}

main().catch((error) => {
  console.error('codegen check failed')
  console.error(error instanceof Error ? error.message : String(error))
  process.exit(1)
})
