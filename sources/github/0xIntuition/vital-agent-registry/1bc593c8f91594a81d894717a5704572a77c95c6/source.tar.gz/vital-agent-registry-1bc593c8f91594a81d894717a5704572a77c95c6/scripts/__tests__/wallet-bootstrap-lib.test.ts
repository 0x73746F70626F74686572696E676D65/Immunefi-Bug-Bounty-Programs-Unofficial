import { describe, expect, it } from 'vitest'
import {
  buildWalletFundingPlan,
  parseRequiredWei,
  parseWalletConfig,
} from '../wallet-bootstrap-lib.mjs'

describe('wallet-bootstrap-lib', () => {
  it('parses required wei from eth string', () => {
    expect(parseRequiredWei('1').toString()).toBe('1000000000000000000')
    expect(parseRequiredWei('0.5').toString()).toBe('500000000000000000')
  })

  it('parses wallet config from env JSON', () => {
    const wallets = parseWalletConfig(
      JSON.stringify([
        {
          id: 'a',
          label: 'Agent A',
          privateKey:
            '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80',
        },
      ]),
    )

    expect(wallets).toHaveLength(1)
    expect(wallets[0].id).toBe('a')
  })

  it('builds funding plan with deficits', () => {
    const report = buildWalletFundingPlan({
      wallets: [
        { id: 'a', label: 'Agent A', address: '0x1' },
        { id: 'b', label: 'Agent B', address: '0x2' },
      ],
      requiredWei: 100n,
      balancesByAddress: {
        '0x1': 150n,
        '0x2': 20n,
      },
    })

    expect(report.readyCount).toBe(1)
    expect(report.notReadyCount).toBe(1)
    expect(report.totalDeficitWei).toBe('80')
    expect(report.wallets.find((w) => w.address === '0x2')?.ready).toBe(false)
  })
})
