import { createHash } from 'node:crypto'
import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'

const PROFILE_RULES = {
  small: {
    minAgents: 4,
    minSkills: 4,
    minUniqueCapabilities: 8,
    minAgentsWithSkills: 3,
  },
  medium: {
    minAgents: 8,
    minSkills: 8,
    minUniqueCapabilities: 12,
    minAgentsWithSkills: 6,
  },
  large: {
    minAgents: 24,
    minSkills: 16,
    minUniqueCapabilities: 18,
    minAgentsWithSkills: 18,
  },
  adversarial: {
    minAgents: 12,
    minSkills: 10,
    minUniqueCapabilities: 14,
    minAgentsWithSkills: 7,
  },
}

function clone(value) {
  return JSON.parse(JSON.stringify(value))
}

function dedupeByName(items) {
  const byName = new Map()
  for (const item of items) {
    const name = item?.metadata?.name
    if (!name || byName.has(name)) continue
    byName.set(name, item)
  }
  return [...byName.values()]
}

function mulberry32(seed) {
  let t = seed >>> 0
  return () => {
    t += 0x6d2b79f5
    let n = Math.imul(t ^ (t >>> 15), 1 | t)
    n ^= n + Math.imul(n ^ (n >>> 7), 61 | n)
    return ((n ^ (n >>> 14)) >>> 0) / 4294967296
  }
}

function stableHash(input) {
  return createHash('sha256').update(input).digest('hex')
}

function generateSyntheticSkills(baseSkills, count) {
  if (count <= baseSkills.length) return clone(baseSkills.slice(0, count))

  const skills = clone(baseSkills)
  const rand = mulberry32(0x8004)
  for (let i = baseSkills.length; i < count; i += 1) {
    const source = baseSkills[i % baseSkills.length]
    const index = i - baseSkills.length + 1
    const skill = clone(source)
    const suffix = `Synthetic-${index}`
    skill.metadata.name = `${source.metadata.name} ${suffix}`
    skill.metadata.version = `1.${(index % 9) + 1}.0`
    skill.metadata.description = `${source.metadata.description} [${suffix}]`
    skill.metadata.author = source.metadata.author || 'Intuition Synthetic'
    if (skill.metadata.installUri) {
      skill.metadata.installUri = `${skill.metadata.installUri}#${suffix.toLowerCase()}`
    }
    if (Array.isArray(skill.capabilities) && skill.capabilities.length > 1 && rand() > 0.5) {
      skill.capabilities = [...skill.capabilities].reverse()
    }
    skills.push(skill)
  }
  return skills
}

function generateSyntheticAgents(baseAgents, skillNames, count) {
  if (count <= baseAgents.length) return clone(baseAgents.slice(0, count))

  const agents = clone(baseAgents)
  const rand = mulberry32(0x13579)
  const availableSkills = skillNames.length > 0 ? skillNames : []
  for (let i = baseAgents.length; i < count; i += 1) {
    const source = baseAgents[i % baseAgents.length]
    const index = i - baseAgents.length + 1
    const agent = clone(source)
    const suffix = `Synthetic-${index}`
    agent.metadata.name = `${source.metadata.name} ${suffix}`
    agent.metadata.version = `1.${(index % 9) + 1}.0`
    agent.metadata.description = `${source.metadata.description} [${suffix}]`
    agent.metadata.provider = source.metadata.provider || { name: 'Intuition Synthetic' }
    if (Array.isArray(source.metadata.tags)) {
      agent.metadata.tags = [...source.metadata.tags, `synthetic-${index}`].slice(0, 10)
    }

    if (availableSkills.length > 0) {
      const skillCount = 1 + Math.floor(rand() * Math.min(3, availableSkills.length))
      const picks = new Set()
      while (picks.size < skillCount) {
        picks.add(availableSkills[Math.floor(rand() * availableSkills.length)])
      }
      agent.skills = [...picks]
    } else {
      agent.skills = []
    }
    agents.push(agent)
  }
  return agents
}

function buildAdversarialEntities(skillNames) {
  const agents = [
    {
      metadata: {
        '@type': 'Agent',
        name: 'Adversarial Capability Hoarder',
        description:
          'Edge-case agent with very broad capability claims and sparse skill bindings.',
        version: '0.1.0',
        model: 'edge-case-model',
        provider: { name: 'Intuition QA' },
        tags: ['adversarial', 'coverage', 'edge'],
        defaultInputModes: ['application/json'],
        defaultOutputModes: ['application/json'],
      },
      capabilities: [
        'code-generation',
        'code-review',
        'planning',
        'task-decomposition',
        'research',
        'web-search',
      ],
      skills: skillNames.slice(0, 1),
    },
    {
      metadata: {
        '@type': 'Agent',
        name: 'Adversarial Sparse Agent',
        description:
          'Edge-case agent with minimal metadata and no declared skills.',
        version: '0.1.0',
        provider: { name: 'Intuition QA' },
      },
      capabilities: ['summarization'],
      skills: [],
    },
  ]

  const skills = [
    {
      metadata: {
        '@type': 'Skill',
        name: 'Adversarial Trust Mirror',
        description:
          'Edge-case skill to stress trust and safety rendering paths.',
        version: '0.1.0',
        platform: 'other',
        author: 'Intuition QA',
      },
      capabilities: ['code-review', 'research'],
    },
    {
      metadata: {
        '@type': 'Skill',
        name: 'Adversarial Minimal Skill',
        description:
          'Edge-case skill with intentionally narrow surface area.',
        version: '0.1.0',
        platform: 'other',
        author: 'Intuition QA',
      },
      capabilities: ['documentation'],
    },
  ]

  return { agents, skills }
}

export function buildSeedProfile(profile, baseAgents, baseSkills) {
  const normalized = (profile || 'medium').toLowerCase()
  if (!PROFILE_RULES[normalized]) {
    throw new Error(
      `Unsupported seed profile "${profile}". Expected one of: ${Object.keys(PROFILE_RULES).join(', ')}`,
    )
  }

  if (normalized === 'small') {
    const skills = clone(baseSkills.slice(0, 4))
    const skillNames = new Set(skills.map((s) => s.metadata.name))
    const agents = clone(baseAgents.slice(0, 4)).map((agent) => ({
      ...agent,
      skills: (agent.skills || []).filter((name) => skillNames.has(name)),
    }))
    return { agents, skills }
  }

  if (normalized === 'medium') {
    const skills = clone(baseSkills.slice(0, Math.min(10, baseSkills.length)))
    const skillNames = new Set(skills.map((s) => s.metadata.name))
    const agents = clone(baseAgents.slice(0, Math.min(10, baseAgents.length))).map((agent) => ({
      ...agent,
      skills: (agent.skills || []).filter((name) => skillNames.has(name)),
    }))
    return { agents, skills }
  }

  if (normalized === 'large') {
    const skills = generateSyntheticSkills(baseSkills, 18)
    const agents = generateSyntheticAgents(
      baseAgents,
      skills.map((skill) => skill.metadata.name),
      28,
    )
    return { agents, skills }
  }

  const medium = buildSeedProfile('medium', baseAgents, baseSkills)
  const adversarial = buildAdversarialEntities(medium.skills.map((s) => s.metadata.name))
  return {
    agents: dedupeByName([...medium.agents, ...adversarial.agents]),
    skills: dedupeByName([...medium.skills, ...adversarial.skills]),
  }
}

export async function loadSeedCorpus(corpusPath) {
  if (!corpusPath) return { agents: [], skills: [], metadata: null }

  const raw = await readFile(resolve(process.cwd(), corpusPath), 'utf8')
  const parsed = JSON.parse(raw)
  const agents = Array.isArray(parsed?.agents) ? parsed.agents : []
  const skills = Array.isArray(parsed?.skills) ? parsed.skills : []
  const metadata = {
    source: parsed?.source || null,
    importedAt: parsed?.importedAt || null,
    hash: stableHash(raw),
  }
  return {
    agents: dedupeByName(clone(agents)),
    skills: dedupeByName(clone(skills)),
    metadata,
  }
}

export function mergeSeedData(baseAgents, baseSkills, corpusAgents, corpusSkills) {
  return {
    agents: dedupeByName([...clone(baseAgents), ...clone(corpusAgents || [])]),
    skills: dedupeByName([...clone(baseSkills), ...clone(corpusSkills || [])]),
  }
}

export function validateSeedCoverage(report, profile) {
  const rules = PROFILE_RULES[(profile || 'medium').toLowerCase()]
  if (!rules) {
    throw new Error(
      `Unsupported seed profile "${profile}" for coverage validation`,
    )
  }

  const failures = []
  if (report.summary.agents < rules.minAgents) {
    failures.push(
      `agents ${report.summary.agents} < required ${rules.minAgents}`,
    )
  }
  if (report.summary.skills < rules.minSkills) {
    failures.push(
      `skills ${report.summary.skills} < required ${rules.minSkills}`,
    )
  }
  if (report.summary.uniqueCapabilities < rules.minUniqueCapabilities) {
    failures.push(
      `uniqueCapabilities ${report.summary.uniqueCapabilities} < required ${rules.minUniqueCapabilities}`,
    )
  }
  if (report.summary.agentsWithSkills < rules.minAgentsWithSkills) {
    failures.push(
      `agentsWithSkills ${report.summary.agentsWithSkills} < required ${rules.minAgentsWithSkills}`,
    )
  }

  return {
    profile: (profile || 'medium').toLowerCase(),
    pass: failures.length === 0,
    failures,
    rules,
  }
}

export function buildSeedCoverageReport(seedAgents, seedSkills) {
  const entityCoverage = {}

  for (const skill of seedSkills) {
    const coverage = ['discover', 'create']
    if ((skill.capabilities?.length ?? 0) > 0) {
      coverage.push('match', 'evidence')
    }
    entityCoverage[`skill:${skill.metadata.name}`] = coverage
  }

  for (const agent of seedAgents) {
    const coverage = ['discover', 'create']
    if ((agent.capabilities?.length ?? 0) > 0) {
      coverage.push('match')
    }
    if ((agent.skills?.length ?? 0) > 0 || (agent.capabilities?.length ?? 0) > 0) {
      coverage.push('evidence')
    }
    entityCoverage[`agent:${agent.metadata.name}`] = coverage
  }

  const uniqueCapabilities = new Set([
    ...seedSkills.flatMap((skill) => skill.capabilities ?? []),
    ...seedAgents.flatMap((agent) => agent.capabilities ?? []),
  ])

  const summary = {
    agents: seedAgents.length,
    skills: seedSkills.length,
    uniqueCapabilities: uniqueCapabilities.size,
    agentsWithSkills: seedAgents.filter((agent) => (agent.skills?.length ?? 0) > 0).length,
    entitiesWithEvidence: Object.values(entityCoverage).filter((coverage) =>
      coverage.includes('evidence'),
    ).length,
  }

  const scenarioCoverage = {
    discover: {
      agents: seedAgents.length,
      skills: seedSkills.length,
    },
    create: {
      agents: seedAgents.length,
      skills: seedSkills.length,
    },
    match: {
      agents: seedAgents.filter((agent) => (agent.capabilities?.length ?? 0) > 0).length,
      skills: seedSkills.filter((skill) => (skill.capabilities?.length ?? 0) > 0).length,
    },
    evidence: {
      entities: summary.entitiesWithEvidence,
    },
  }

  return {
    generatedAt: new Date().toISOString(),
    summary,
    scenarioCoverage,
    entityCoverage,
  }
}
