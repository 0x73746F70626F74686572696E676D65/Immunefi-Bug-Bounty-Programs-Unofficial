/**
 * Shared corpus types for all scrapers.
 * These must remain compatible with import-corpus.mjs normalisation.
 */

export interface RequiredEnvVar {
  name: string
  description?: string
  isSecret?: boolean
}

export interface CorpusSkill {
  metadata: {
    '@type': 'Skill'
    name: string
    description: string
    version: string
    platform: string
    author: string
    installUri?: string
    transport?: string
    requiredEnvVars?: RequiredEnvVar[]
    inputModes?: string[]
    outputModes?: string[]
    permissions?: string[]
    longDescription?: string
  }
  capabilities: string[]
}

export interface CorpusAgent {
  metadata: {
    '@type': 'Agent'
    name: string
    description: string
    version: string
    endpoint?: string
    protocol?: string
    model?: string
    provider?: string
    inputModes?: string[]
    outputModes?: string[]
  }
  capabilities: string[]
  skills: string[]
}

export interface Corpus {
  agents: CorpusAgent[]
  skills: CorpusSkill[]
}
