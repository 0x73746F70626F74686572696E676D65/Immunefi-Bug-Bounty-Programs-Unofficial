#!/usr/bin/env node

import { spawnSync } from 'node:child_process'
import { mkdirSync, writeFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'

const DEFAULT_OUTPUT = '.artifacts/local-agent-test-prep.report.json'

export function parseArgs(argv) {
  const args = {
    output: DEFAULT_OUTPUT,
    requiredEth: '0.1',
    populateCount: 10,
    populateStakeEth: '0.001',
    skipHealth: false,
    skipFund: false,
    skipPopulate: false,
    skipHarness: false,
    requirePopulate: false,
    json: false,
  }

  for (let i = 0; i < argv.length; i += 1) {
    const value = argv[i]
    if (value === '--') continue
    if (value === '--output') {
      args.output = argv[i + 1] ?? args.output
      i += 1
      continue
    }
    if (value === '--required-eth') {
      args.requiredEth = argv[i + 1] ?? args.requiredEth
      i += 1
      continue
    }
    if (value === '--populate-count') {
      args.populateCount = Number(argv[i + 1] ?? args.populateCount)
      i += 1
      continue
    }
    if (value === '--populate-stake-eth') {
      args.populateStakeEth = argv[i + 1] ?? args.populateStakeEth
      i += 1
      continue
    }
    if (value === '--skip-health') {
      args.skipHealth = true
      continue
    }
    if (value === '--skip-fund') {
      args.skipFund = true
      continue
    }
    if (value === '--skip-populate') {
      args.skipPopulate = true
      continue
    }
    if (value === '--skip-harness') {
      args.skipHarness = true
      continue
    }
    if (value === '--require-populate') {
      args.requirePopulate = true
      continue
    }
    if (value === '--json') {
      args.json = true
    }
  }

  return args
}

export function buildPlan(args) {
  const checks = []

  if (!args.skipHealth) {
    checks.push({
      id: 'local-stack-health',
      cmd: 'pnpm',
      args: ['local:stack:health'],
      attempts: 5,
    })
  }

  if (!args.skipFund) {
    checks.push({
      id: 'local-wallet-fund',
      cmd: 'pnpm',
      args: ['local:wallets:fund', '--', `--required-eth=${args.requiredEth}`],
    })
  }

  if (!args.skipPopulate) {
    checks.push({
      id: 'local-execute-populate',
      cmd: 'pnpm',
      args: [
        'local:execute:populate',
        '--',
        `--count=${args.populateCount}`,
        `--stake-amount-eth=${args.populateStakeEth}`,
      ],
      softFail:
        !args.requirePopulate,
      softFailPatterns: [
        'The contract function "createAtoms" reverted',
        'INTERNAL_ERROR',
      ],
    })
  }

  if (!args.skipHarness) {
    checks.push({
      id: 'local-harness',
      cmd: 'pnpm',
      args: ['local:harness', '--', '--json', '--allow-create-rate-limited'],
    })
  }

  return checks
}

function runCheck(check) {
  const attempts = check.attempts ?? 1
  let proc = null
  for (let i = 0; i < attempts; i += 1) {
    proc = spawnSync(check.cmd, check.args, {
      stdio: 'pipe',
      encoding: 'utf8',
    })
    if (proc.status === 0) break
  }

  const ok = proc?.status === 0
  const tail = `${proc?.stderr ?? ''}\n${proc?.stdout ?? ''}`.trim().split('\n').slice(-3).join(' | ')
  const softFailed =
    !ok &&
    check.softFail === true &&
    Array.isArray(check.softFailPatterns) &&
    check.softFailPatterns.some((pattern) => `${proc?.stderr ?? ''}\n${proc?.stdout ?? ''}`.includes(pattern))

  return {
    id: check.id,
    command: [check.cmd, ...check.args].join(' '),
    status: ok || softFailed ? 'pass' : 'fail',
    detail: ok ? 'ok' : softFailed ? 'soft-fail tolerated in prep (use --require-populate to enforce)' : tail || 'command failed',
  }
}

export function runPrep(args) {
  const startedAt = new Date().toISOString()
  const plan = buildPlan(args)
  const checks = plan.map(runCheck)
  const failed = checks.filter((check) => check.status === 'fail').map((check) => check.id)

  return {
    status: failed.length === 0 ? 'pass' : 'fail',
    startedAt,
    completedAt: new Date().toISOString(),
    checks,
    failed,
  }
}

function main() {
  const args = parseArgs(process.argv.slice(2))
  const report = runPrep(args)
  const outputPath = resolve(args.output)
  mkdirSync(dirname(outputPath), { recursive: true })
  writeFileSync(outputPath, `${JSON.stringify(report, null, 2)}\n`)

  if (args.json) {
    process.stdout.write(`${JSON.stringify(report)}\n`)
  } else {
    process.stdout.write(
      `[local-agent-test-prep] status=${report.status} checks=${report.checks.length} failed=${report.failed.length}\n`,
    )
    process.stdout.write(`[local-agent-test-prep] report=${outputPath}\n`)
  }

  if (report.status !== 'pass') {
    process.exitCode = 1
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main()
}
