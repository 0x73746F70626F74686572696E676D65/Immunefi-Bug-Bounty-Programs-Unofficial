#!/usr/bin/env node

import { mkdir, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import {
  createPublicClient,
  createWalletClient,
  defineChain,
  formatEther,
  http,
  parseEther,
} from 'viem'
import { privateKeyToAccount } from 'viem/accounts'
import {
  buildWalletFundingPlan,
  parseRequiredWei,
  parseWalletConfig,
} from './wallet-bootstrap-lib.mjs'

function parseArgs(argv) {
  const rpcFlag = argv.find((arg) => arg.startsWith('--rpc-url='))
  const requiredEthFlag = argv.find((arg) => arg.startsWith('--required-eth='))
  const outputFlag = argv.find((arg) => arg.startsWith('--output='))
  const fromIdFlag = argv.find((arg) => arg.startsWith('--from-id='))
  const dryRun = argv.includes('--dry-run')
  const gasReserveEthFlag = argv.find((arg) => arg.startsWith('--gas-reserve-eth='))

  return {
    rpcUrl:
      rpcFlag?.split('=')[1] ||
      process.env.LOCAL_CHAIN_RPC_URL ||
      'http://localhost:8545',
    requiredEth: requiredEthFlag?.split('=')[1] || '1',
    fromId: fromIdFlag?.split('=')[1] || 'agent-001',
    gasReserveEth: gasReserveEthFlag?.split('=')[1] || '0.01',
    outputPath:
      outputFlag?.split('=')[1] ||
      './.artifacts/local-wallet-bootstrap.funding-report.json',
    dryRun,
  }
}

async function loadBalances(client, wallets) {
  const balancesByAddress = {}
  for (const wallet of wallets) {
    balancesByAddress[wallet.address] = await client.getBalance({
      address: wallet.address,
    })
  }
  return balancesByAddress
}

async function discoverRpcFunders(client) {
  try {
    const accounts = await client.request({
      method: 'eth_accounts',
      params: [],
    })
    if (!Array.isArray(accounts) || accounts.length === 0) {
      return []
    }

    const funders = []
    for (const account of accounts) {
      const address = account
      const balanceWei = await client.getBalance({ address })
      funders.push({ address, balanceWei })
    }

    funders.sort((a, b) => (a.balanceWei === b.balanceWei ? 0 : a.balanceWei > b.balanceWei ? -1 : 1))
    return funders
  } catch {
    return []
  }
}

async function main() {
  const args = parseArgs(process.argv.slice(2))
  const requiredWei = parseRequiredWei(args.requiredEth)
  const walletDefs = parseWalletConfig(process.env.LOCAL_TEST_WALLETS_JSON)
  const wallets = walletDefs.map((wallet) => ({
    ...wallet,
    account: privateKeyToAccount(wallet.privateKey),
  }))
  const walletsWithoutPrivateKey = wallets.map(({ privateKey, account, ...rest }) => ({
    ...rest,
    address: account.address,
  }))
  const chainId = Number(process.env.LOCAL_CHAIN_ID || 31337)
  const chain = defineChain({
    id: chainId,
    name: `Intuition Local ${chainId}`,
    nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
    rpcUrls: { default: { http: [args.rpcUrl] } },
  })

  const publicClient = createPublicClient({
    chain,
    transport: http(args.rpcUrl),
  })

  const initialBalances = await loadBalances(publicClient, walletsWithoutPrivateKey)
  const initialPlan = buildWalletFundingPlan({
    wallets: walletsWithoutPrivateKey,
    requiredWei,
    balancesByAddress: initialBalances,
  })

  const fromWallet = wallets.find((wallet) => wallet.id === args.fromId)
  if (!fromWallet) {
    throw new Error(`Funding wallet not found: ${args.fromId}`)
  }

  const fundTargets = initialPlan.wallets
    .filter((entry) => !entry.ready && entry.id !== args.fromId)
    .map((entry) => ({
      id: entry.id,
      address: entry.address,
      deficitWei: BigInt(entry.deficitWei),
    }))

  const totalFundingWei = fundTargets.reduce(
    (acc, target) => acc + target.deficitWei,
    0n,
  )
  const gasReserveWei = parseEther(args.gasReserveEth)
  const fromBalanceWei = initialBalances[fromWallet.account.address] ?? 0n
  const requiredFromBalanceWei = totalFundingWei + gasReserveWei

  let fundingAccount = fromWallet.account
  let fundingSource = { id: args.fromId, address: fromWallet.account.address, viaRpc: false }
  if (fromBalanceWei < requiredFromBalanceWei) {
    const rpcFunders = await discoverRpcFunders(publicClient)
    const fallback = rpcFunders.find((funder) => funder.balanceWei >= requiredFromBalanceWei)

    if (!fallback) {
      throw new Error(
        `Funding wallet ${args.fromId} has insufficient balance. Need ${formatEther(
          requiredFromBalanceWei,
        )} ETH, have ${formatEther(fromBalanceWei)} ETH.`,
      )
    }

    fundingAccount = fallback.address
    fundingSource = { id: 'rpc-funder', address: fallback.address, viaRpc: true }
  }

  const transfers = []
  if (!args.dryRun) {
    const walletClient = createWalletClient({
      chain,
      account: fundingAccount,
      transport: http(args.rpcUrl),
    })

    for (const target of fundTargets) {
      const hash = await walletClient.sendTransaction({
        account: fundingAccount,
        to: target.address,
        value: target.deficitWei,
      })
      await publicClient.waitForTransactionReceipt({ hash })
      transfers.push({
        id: target.id,
        to: target.address,
        valueWei: target.deficitWei.toString(),
        valueEth: formatEther(target.deficitWei),
        txHash: hash,
      })
    }
  }

  const finalBalances = await loadBalances(publicClient, walletsWithoutPrivateKey)
  const finalPlan = buildWalletFundingPlan({
    wallets: walletsWithoutPrivateKey,
    requiredWei,
    balancesByAddress: finalBalances,
  })

  const report = {
    generatedAt: new Date().toISOString(),
    rpcUrl: args.rpcUrl,
    requiredEth: args.requiredEth,
    requiredWei: requiredWei.toString(),
    fromId: args.fromId,
    fromAddress: fundingSource.address,
    fundingSource,
    dryRun: args.dryRun,
    totalFundingWei: totalFundingWei.toString(),
    totalFundingEth: formatEther(totalFundingWei),
    transfers,
    initial: initialPlan,
    final: finalPlan,
  }

  const outputPath = resolve(process.cwd(), args.outputPath)
  await mkdir(resolve(outputPath, '..'), { recursive: true })
  await writeFile(outputPath, `${JSON.stringify(report, null, 2)}\n`)

  console.log(`wallet funding report: ${outputPath}`)
  console.log(`rpc: ${args.rpcUrl}`)
  console.log(`from wallet: ${fundingSource.id} (${fundingSource.address})`)
  console.log(`required per wallet: ${args.requiredEth} ETH`)
  console.log(`transfers executed: ${transfers.length}${args.dryRun ? ' (dry-run)' : ''}`)
  console.log(
    `ready wallets after funding: ${report.final.readyCount}/${report.final.walletCount}`,
  )
}

main().catch((error) => {
  console.error('failed to fund local wallets', error)
  process.exit(1)
})
