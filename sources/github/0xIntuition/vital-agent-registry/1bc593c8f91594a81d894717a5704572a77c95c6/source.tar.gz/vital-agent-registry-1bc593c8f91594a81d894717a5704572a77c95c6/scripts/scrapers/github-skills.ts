/**
 * GitHub Skills scraper — Anthropic + HuggingFace SKILL.md repositories.
 * API: GitHub Contents API (60 req/hr unauthenticated, 5000 with GITHUB_TOKEN)
 *
 * Fetches top-level directories from known skill repos, reads SKILL.md for each.
 */

import type { Corpus, CorpusSkill } from './types'
import { inferCapabilities, slugify, sleep } from './utils'

interface GitHubTreeItem {
  path?: string
  type?: string
  url?: string
}

interface GitHubTreeResponse {
  tree?: GitHubTreeItem[]
}

interface GitHubContent {
  content?: string
  encoding?: string
}

const SKILL_REPOS = [
  { owner: 'anthropics', repo: 'skills', platform: 'claude-code' as const },
  { owner: 'huggingface', repo: 'skills', platform: 'claude-code' as const },
]

function getAuthHeaders(): Record<string, string> {
  const token = process.env.GITHUB_TOKEN
  return token ? { Authorization: `Bearer ${token}` } : {}
}

function parseSkillMd(content: string): { name?: string; description?: string } {
  const result: { name?: string; description?: string } = {}

  // Try YAML frontmatter
  const fmMatch = content.match(/^---\n([\s\S]*?)\n---/)
  if (fmMatch) {
    const fm = fmMatch[1]
    const nameMatch = fm.match(/^name:\s*(.+)$/m)
    const descMatch = fm.match(/^description:\s*(.+)$/m)
    if (nameMatch) result.name = nameMatch[1].trim().replace(/^["']|["']$/g, '')
    if (descMatch) result.description = descMatch[1].trim().replace(/^["']|["']$/g, '')
  }

  // Fall back to first H1
  if (!result.name) {
    const h1Match = content.match(/^#\s+(.+)$/m)
    if (h1Match) result.name = h1Match[1].trim()
  }

  // Fall back to first non-empty line after headers
  if (!result.description) {
    const lines = content.split('\n').filter((l) => l.trim() && !l.startsWith('#') && !l.startsWith('---'))
    if (lines[0]) result.description = lines[0].trim().slice(0, 200)
  }

  return result
}

async function fetchSkillsFromRepo(
  owner: string,
  repo: string,
  platform: 'claude-code',
): Promise<CorpusSkill[]> {
  const headers = {
    Accept: 'application/vnd.github.v3+json',
    ...getAuthHeaders(),
  }

  // Get the repo tree (top level)
  const treeUrl = `https://api.github.com/repos/${owner}/${repo}/git/trees/HEAD?recursive=0`
  const treeRes = await fetch(treeUrl, { headers, signal: AbortSignal.timeout(10_000) })

  if (!treeRes.ok) {
    console.warn(`[github-skills] ${owner}/${repo}: HTTP ${treeRes.status}`)
    return []
  }

  const treeData: GitHubTreeResponse = await treeRes.json()
  const dirs = (treeData.tree ?? []).filter((item) => item.type === 'tree' && item.path && !item.path.includes('/'))

  console.log(`[github-skills] ${owner}/${repo}: found ${dirs.length} skill directories`)

  const skills: CorpusSkill[] = []

  for (const dir of dirs.slice(0, 60)) {
    const skillName = dir.path!
    // Try fetching SKILL.md from the directory
    const skillMdUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${skillName}/SKILL.md`

    try {
      await sleep(100) // Stay within rate limits
      const mdRes = await fetch(skillMdUrl, { headers, signal: AbortSignal.timeout(8_000) })

      let name = skillName
      let description = `${platform} skill: ${skillName}`

      if (mdRes.ok) {
        const mdData: GitHubContent = await mdRes.json()
        if (mdData.content && mdData.encoding === 'base64') {
          const decoded = Buffer.from(mdData.content.replace(/\n/g, ''), 'base64').toString('utf8')
          const parsed = parseSkillMd(decoded)
          if (parsed.name) name = parsed.name
          if (parsed.description) description = parsed.description
        }
      }

      skills.push({
        metadata: {
          '@type': 'Skill',
          name: slugify(name),
          description: description.slice(0, 500),
          version: '1.0.0',
          platform,
          author: owner,
          installUri: `https://github.com/${owner}/${repo}/tree/main/${skillName}`,
        },
        capabilities: inferCapabilities(name, description, 'skill'),
      })
    } catch {
      // Skip individual skill fetch errors
    }
  }

  return skills
}

export async function fetchGithubSkills(): Promise<Corpus> {
  console.log(`[github-skills] Fetching skills from ${SKILL_REPOS.length} repositories...`)

  const allSkills: CorpusSkill[] = []

  for (const { owner, repo, platform } of SKILL_REPOS) {
    try {
      const skills = await fetchSkillsFromRepo(owner, repo, platform)
      allSkills.push(...skills)
      console.log(`[github-skills] ${owner}/${repo}: ${skills.length} skills`)
    } catch (err) {
      console.warn(`[github-skills] ${owner}/${repo} failed: ${err instanceof Error ? err.message : err}`)
    }
  }

  return { agents: [], skills: allSkills }
}
