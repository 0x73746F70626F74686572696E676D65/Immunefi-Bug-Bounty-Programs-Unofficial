#!/usr/bin/env node

import { createHash } from 'node:crypto'
import { writeFile } from 'node:fs/promises'
import { stableStringify } from './local-fixtures-lib.mjs'

const GRAPHQL_URL = process.env.GRAPHQL_URL || 'http://localhost:8080/v1/graphql'

function parseArgs(argv) {
  const args = { hashOnly: false, output: null, label: null }

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i]
    if (arg === '--hash-only') {
      args.hashOnly = true
      continue
    }
    if (arg === '--output') {
      args.output = argv[i + 1] || null
      i += 1
      continue
    }
    if (arg === '--label') {
      args.label = argv[i + 1] || null
      i += 1
    }
  }

  return args
}

async function queryFingerprintData() {
  const schemaResponse = await fetch(GRAPHQL_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      query: '{ __schema { queryType { fields { name } } } }',
    }),
  })

  if (!schemaResponse.ok) {
    throw new Error(
      `GraphQL introspection failed (${schemaResponse.status} ${schemaResponse.statusText})`,
    )
  }

  const schemaJson = await schemaResponse.json()
  if (schemaJson.errors?.length) {
    throw new Error(`GraphQL introspection errors: ${JSON.stringify(schemaJson.errors)}`)
  }

  const rootFields = (schemaJson.data?.__schema?.queryType?.fields || [])
    .map((field) => field.name)
    .sort()

  const hasRegistryRoots =
    rootFields.includes('atom') && rootFields.includes('triple') && rootFields.includes('vault')

  const query = hasRegistryRoots
    ? `
        query LocalStateFingerprint {
          atom_aggregate {
            aggregate {
              count
            }
          }
          triple_aggregate {
            aggregate {
              count
            }
          }
          vault_aggregate {
            aggregate {
              count
            }
          }
          atom(limit: 500, order_by: { term_id: asc }) {
            term_id
          }
          triple(limit: 500, order_by: { term_id: asc }) {
            term_id
            subject_id
            predicate_id
            object_id
          }
          vault(limit: 500, order_by: [{ term_id: asc }, { curve_id: asc }]) {
            term_id
            curve_id
            total_assets
            total_shares
            current_share_price
            position_count
            market_cap
          }
        }
      `
    : `
        query LocalStateFallbackFingerprint {
          cached_images(limit: 500, order_by: { original_url: asc }) {
            original_url
            url
            model
            safe
            score
            created_at
          }
        }
      `

  const response = await fetch(GRAPHQL_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ query }),
  })

  if (!response.ok) {
    throw new Error(`GraphQL request failed (${response.status} ${response.statusText})`)
  }

  const json = await response.json()
  if (json.errors?.length) {
    throw new Error(`GraphQL returned errors: ${JSON.stringify(json.errors)}`)
  }

  return {
    mode: hasRegistryRoots ? 'registry-roots' : 'fallback-roots',
    rootFields,
    data: json.data,
  }
}

async function main() {
  const { hashOnly, output, label } = parseArgs(process.argv.slice(2))
  const data = await queryFingerprintData()

  const canonical = stableStringify(data)
  const stateHash = createHash('sha256').update(canonical).digest('hex')

  if (hashOnly) {
    console.log(stateHash)
    return
  }

  const payload = {
    label,
    graphqlUrl: GRAPHQL_URL,
    stateHash,
    stateBytes: Buffer.byteLength(canonical, 'utf8'),
    data,
  }

  if (output) {
    await writeFile(output, `${JSON.stringify(payload, null, 2)}\n`)
  }

  console.log(`state hash: ${stateHash}`)
  if (output) {
    console.log(`output: ${output}`)
  }
}

main().catch((error) => {
  console.error('failed to compute local state fingerprint', error)
  process.exit(1)
})
