import { spawnSync } from 'node:child_process'
import { mkdirSync, writeFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'

const DEFAULT_OUTPUT = '.artifacts/hard-checkpoint.report.json'

export function parseArgs(argv) {
  const args = {
    output: DEFAULT_OUTPUT,
    skipHarness: false,
    skipHealth: false,
    includeExecuteSmoke: false,
    json: false,
  }

  for (let i = 0; i < argv.length; i += 1) {
    const value = argv[i]
    if (value === '--output') {
      args.output = argv[i + 1] ?? args.output
      i += 1
      continue
    }
    if (value === '--skip-harness') {
      args.skipHarness = true
      continue
    }
    if (value === '--skip-health') {
      args.skipHealth = true
      continue
    }
    if (value === '--include-execute-smoke') {
      args.includeExecuteSmoke = true
      continue
    }
    if (value === '--json') {
      args.json = true
    }
  }

  return args
}

export function runCheck(cmd, args) {
  const proc = spawnSync(cmd, args, {
    stdio: 'pipe',
    encoding: 'utf8',
  })

  return {
    ok: proc.status === 0,
    status: proc.status,
    stdout: proc.stdout ?? '',
    stderr: proc.stderr ?? '',
  }
}

function summarizeFailure(result) {
  const source = `${result.stderr}\n${result.stdout}`.trim()
  if (!source) return 'command failed with no output'
  return source.split('\n').slice(-3).join(' | ')
}

export function buildPlan(args) {
  const checks = [
    { id: 'typecheck', cmd: 'pnpm', args: ['typecheck'] },
    { id: 'tests', cmd: 'pnpm', args: ['test'] },
  ]

  if (!args.skipHealth) {
    checks.push({
      id: 'local-stack-health',
      cmd: 'pnpm',
      args: ['local:stack:health'],
    })
  }

  if (!args.skipHarness) {
    checks.push({
      id: 'local-agent-harness',
      cmd: 'pnpm',
      args: ['local:harness', '--', '--json'],
    })
  }

  if (args.includeExecuteSmoke) {
    checks.push({
      id: 'local-execute-smoke',
      cmd: 'pnpm',
      args: ['local:execute:smoke', '--', '--json', '--skip-readback'],
    })
  }

  return checks
}

export function runCheckpoint(args) {
  const startedAt = new Date().toISOString()
  const checks = buildPlan(args).map((check) => {
    const result = runCheck(check.cmd, check.args)
    return {
      id: check.id,
      command: [check.cmd, ...check.args].join(' '),
      status: result.ok ? 'pass' : 'fail',
      detail: result.ok ? 'ok' : summarizeFailure(result),
    }
  })

  const failed = checks.filter((check) => check.status === 'fail').map((check) => check.id)
  return {
    status: failed.length === 0 ? 'pass' : 'fail',
    startedAt,
    completedAt: new Date().toISOString(),
    checks,
    failed,
  }
}

function main() {
  const args = parseArgs(process.argv.slice(2))
  const report = runCheckpoint(args)

  const outputPath = resolve(args.output)
  mkdirSync(dirname(outputPath), { recursive: true })
  writeFileSync(outputPath, `${JSON.stringify(report, null, 2)}\n`)

  if (args.json) {
    process.stdout.write(`${JSON.stringify(report)}\n`)
  } else {
    process.stdout.write(
      `[hard-checkpoint] status=${report.status} checks=${report.checks.length} failed=${report.failed.length}\n`,
    )
    process.stdout.write(`[hard-checkpoint] report=${outputPath}\n`)
  }

  if (report.status !== 'pass') {
    process.exitCode = 1
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main()
}
