#!/usr/bin/env node

import { mkdir, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { spawnSync } from 'node:child_process'

const DEFAULT_BASE_URL = 'http://localhost:4101'
const DEFAULT_TIMEOUT_MS = 15_000
const DEFAULT_OUTPUT = '.artifacts/local-execute-smoke.report.json'
const DEFAULT_STAKE_AMOUNT_ETH = '0.001'
const DEFAULT_READBACK_RETRIES = 20
const DEFAULT_READBACK_DELAY_MS = 1000

export function parseArgs(argv) {
  const args = {
    baseUrl: DEFAULT_BASE_URL,
    timeoutMs: DEFAULT_TIMEOUT_MS,
    output: DEFAULT_OUTPUT,
    stakeAmountEth: DEFAULT_STAKE_AMOUNT_ETH,
    readbackRetries: DEFAULT_READBACK_RETRIES,
    readbackDelayMs: DEFAULT_READBACK_DELAY_MS,
    strictReadback: false,
    skipReadback: false,
    json: false,
  }

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i]
    if (arg === '--') {
      continue
    }
    if (arg === '--base-url') {
      args.baseUrl = argv[i + 1] || args.baseUrl
      i += 1
      continue
    }
    if (arg === '--timeout-ms') {
      args.timeoutMs = Number(argv[i + 1] || args.timeoutMs)
      i += 1
      continue
    }
    if (arg === '--output') {
      args.output = argv[i + 1] || args.output
      i += 1
      continue
    }
    if (arg === '--stake-amount-eth') {
      args.stakeAmountEth = argv[i + 1] || args.stakeAmountEth
      i += 1
      continue
    }
    if (arg === '--readback-retries') {
      args.readbackRetries = Number(argv[i + 1] || args.readbackRetries)
      i += 1
      continue
    }
    if (arg === '--readback-delay-ms') {
      args.readbackDelayMs = Number(argv[i + 1] || args.readbackDelayMs)
      i += 1
      continue
    }
    if (arg === '--strict-readback') {
      args.strictReadback = true
      continue
    }
    if (arg === '--skip-readback') {
      args.skipReadback = true
      continue
    }
    if (arg === '--json') {
      args.json = true
    }
  }

  return args
}

function getEnvelopeData(payload) {
  if (!payload || typeof payload !== 'object' || !('data' in payload)) {
    return null
  }
  return payload.data
}

function sleep(ms) {
  return new Promise((resolveSleep) => {
    setTimeout(resolveSleep, ms)
  })
}

async function fetchJson(baseUrl, path, options = {}, timeoutMs = DEFAULT_TIMEOUT_MS) {
  const method = options.method || 'GET'
  const headers = options.headers || {}
  const body = options.body

  const curlFallback = () => {
    const url = `${baseUrl}${path}`
    const args = ['-sS', '-i', '-X', method, url, '--max-time', String(Math.max(1, Math.floor(timeoutMs / 1000)))]
    for (const [key, value] of Object.entries(headers)) {
      args.push('-H', `${key}: ${value}`)
    }
    if (typeof body === 'string' && body.length > 0) {
      args.push('--data', body)
    }

    const proc = spawnSync('curl', args, { encoding: 'utf8' })
    if (proc.status !== 0) {
      return {
        ok: false,
        status: 0,
        json: null,
        text: '',
        transportError: proc.stderr?.trim() || 'curl request failed',
      }
    }

    const raw = proc.stdout || ''
    const marker = '\r\n\r\n'
    const idx = raw.lastIndexOf(marker)
    const head = idx >= 0 ? raw.slice(0, idx) : raw
    const text = idx >= 0 ? raw.slice(idx + marker.length) : ''
    const lines = head.split('\r\n').filter(Boolean)
    const statusLine = [...lines].reverse().find((line) => line.startsWith('HTTP/')) || ''
    const statusMatch = statusLine.match(/\s(\d{3})\s/)
    const status = statusMatch ? Number(statusMatch[1]) : 0
    let json = null
    if (text.length > 0) {
      try {
        json = JSON.parse(text)
      } catch {
        json = null
      }
    }

    return {
      ok: status >= 200 && status < 300,
      status,
      json,
      text,
      transportError: null,
    }
  }

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    try {
      const response = await fetch(`${baseUrl}${path}`, {
        ...options,
        signal: controller.signal,
      })
      const text = await response.text()
      let json = null
      if (text.length > 0) {
        try {
          json = JSON.parse(text)
        } catch {
          json = null
        }
      }
      return { ok: response.ok, status: response.status, json, text, transportError: null }
    } catch (error) {
      const fallbackResult = curlFallback()
      if (fallbackResult.status !== 0) {
        return fallbackResult
      }
      return {
        ...fallbackResult,
        transportError:
          fallbackResult.transportError ??
          (error instanceof Error ? error.message : 'request failed'),
      }
    }
  } finally {
    clearTimeout(timer)
  }
}

function makeAgentPayload() {
  const now = Date.now()
  const random = Math.floor(Math.random() * 1_000_000)
  return {
    name: `Local Execute Agent ${now}-${random}`,
    description: 'Local execute smoke for agent-first data flow',
    version: '0.1.0',
    endpoint: 'http://localhost:4101/a2a',
    provider: { name: 'Intuition' },
    tags: ['local', 'smoke', 'execute'],
    defaultInputModes: ['text'],
    defaultOutputModes: ['text'],
    requireTwoSignatures: false,
  }
}

async function registerWithRetry(args, payload, maxAttempts = 4) {
  let lastResponse = null
  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    const response = await fetchJson(
      args.baseUrl,
      '/api/v1/agents/register?execute=true',
      {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(payload),
      },
      args.timeoutMs,
    )
    lastResponse = response
    const code = response?.json?.code
    if (!(response.status === 429 && code === 'RATE_LIMITED')) {
      return response
    }

    const retryAfterSeconds = Number(response?.json?.retryAfter || 1)
    const waitMs = Math.max(250, Math.min(5000, retryAfterSeconds * 1000))
    await sleep(waitMs)
  }

  return lastResponse
}

export async function runSmoke(args) {
  const startedAt = new Date().toISOString()
  const checks = []
  const payload = makeAgentPayload()

  const registerResponse = await registerWithRetry(args, payload)

  const registerData = getEnvelopeData(registerResponse.json)
  if (!registerResponse.ok || !registerData) {
    checks.push({
      id: 'register-execute',
      status: 'fail',
      details: {
        status: registerResponse.status,
        transportError: registerResponse.transportError,
        response: registerResponse.json ?? registerResponse.text,
      },
    })
    return {
      status: 'fail',
      startedAt,
      completedAt: new Date().toISOString(),
      checks,
      context: { payloadName: payload.name },
    }
  }

  const atomTermId =
    registerData.atomTermId ??
    registerData.identityAtomTermId ??
    registerData.execution?.existingIdentityTermId ??
    registerData.execution?.resolvedIdentityTermId ??
    null
  const execution = registerData.execution ?? {}
  const registerPassed =
    typeof atomTermId === 'string' &&
    execution.executed === true &&
    (typeof execution.atomTxHash === 'string' || execution.atomAlreadyExisted === true)

  checks.push({
    id: 'register-execute',
    status: registerPassed ? 'pass' : 'fail',
    details: {
      atomTermId: atomTermId ?? null,
      account: execution.account ?? null,
      atomTxHash: execution.atomTxHash ?? null,
      atomAlreadyExisted: execution.atomAlreadyExisted ?? false,
      existingAtomTermId: execution.existingAtomTermId ?? null,
    },
  })

  if (!registerPassed) {
    return {
      status: 'fail',
      startedAt,
      completedAt: new Date().toISOString(),
      checks,
      context: { payloadName: payload.name, registerData },
    }
  }

  const stakeResponse = await fetchJson(
    args.baseUrl,
    '/api/v1/trust/stake',
    {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        termId: atomTermId,
        amountEth: args.stakeAmountEth,
      }),
    },
    args.timeoutMs,
  )

  const stakeData = getEnvelopeData(stakeResponse.json)
  const stakePassed =
    stakeResponse.ok &&
    Boolean(stakeData && stakeData.executed === true && typeof stakeData.txHash === 'string')

  checks.push({
    id: 'stake-execute',
    status: stakePassed ? 'pass' : 'fail',
    details: stakePassed
      ? {
          txHash: stakeData.txHash,
          assetsWei: stakeData.assetsWei,
          curveId: stakeData.curveId,
          account: stakeData.account,
        }
      : {
          status: stakeResponse.status,
          transportError: stakeResponse.transportError,
          response: stakeResponse.json ?? stakeResponse.text,
        },
  })

  if (!stakePassed || args.skipReadback) {
    const failed = checks.some((check) => check.status === 'fail')
    return {
      status: failed ? 'fail' : 'pass',
      startedAt,
      completedAt: new Date().toISOString(),
      checks,
      context: {
        payloadName: payload.name,
        atomTermId,
        skipReadback: args.skipReadback,
      },
    }
  }

  let readback = null
  for (let i = 0; i < args.readbackRetries; i += 1) {
    readback = await fetchJson(
      args.baseUrl,
      `/api/v1/agents/${atomTermId}`,
      { method: 'GET' },
      args.timeoutMs,
    )
    if (readback.ok) {
      break
    }
    await sleep(args.readbackDelayMs)
  }

  const readbackData = getEnvelopeData(readback?.json)
  const readbackPass = Boolean(readback?.ok && readbackData)
  const readbackStatus = readbackPass ? 'pass' : args.strictReadback ? 'fail' : 'warn'
  checks.push({
    id: 'agent-readback',
    status: readbackStatus,
    details: readbackPass
      ? {
          agentId: readbackData.id ?? atomTermId,
          name: readbackData.name ?? null,
          trustTier: readbackData.trustTier ?? null,
        }
      : {
          status: readback?.status ?? 0,
          transportError: readback?.transportError ?? null,
          response: readback?.json ?? readback?.text ?? null,
          retries: args.readbackRetries,
          note: 'Indexer lag can delay readback. Re-run or increase retries/delay.',
        },
  })

  const failed = checks.some((check) => check.status === 'fail')
  return {
    status: failed ? 'fail' : 'pass',
    startedAt,
    completedAt: new Date().toISOString(),
    checks,
    context: {
      payloadName: payload.name,
      atomTermId,
      readbackStrict: args.strictReadback,
    },
  }
}

async function main() {
  const args = parseArgs(process.argv.slice(2))
  const report = await runSmoke(args)

  const outputPath = resolve(args.output)
  await mkdir(dirname(outputPath), { recursive: true })
  await writeFile(outputPath, `${JSON.stringify(report, null, 2)}\n`, 'utf8')

  if (args.json) {
    process.stdout.write(`${JSON.stringify(report)}\n`)
  } else {
    process.stdout.write(
      `[local-execute-smoke] status=${report.status} checks=${report.checks.length}\n`,
    )
    process.stdout.write(`[local-execute-smoke] report=${outputPath}\n`)
  }

  if (report.status === 'fail') {
    process.exitCode = 1
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main()
}
