#!/usr/bin/env node

import { mkdir, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { buildFixtureSnapshot, outputDir, readFixtureFiles } from './local-fixtures-lib.mjs'

const DEFAULT_BASE_URL = 'http://localhost:4101'
const DEFAULT_TIMEOUT_MS = 10_000
const DEFAULT_OUTPUT_PATH = resolve(outputDir, 'local-agent-harness.report.json')

function parseArgs(argv) {
  const args = {
    baseUrl: DEFAULT_BASE_URL,
    timeoutMs: DEFAULT_TIMEOUT_MS,
    output: DEFAULT_OUTPUT_PATH,
    allowCreateBlocked: true,
    allowCreateRateLimited: false,
    json: false,
  }

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i]
    if (arg === '--base-url') {
      args.baseUrl = argv[i + 1] || DEFAULT_BASE_URL
      i += 1
      continue
    }
    if (arg === '--timeout-ms') {
      args.timeoutMs = Number(argv[i + 1] || DEFAULT_TIMEOUT_MS)
      i += 1
      continue
    }
    if (arg === '--output') {
      args.output = argv[i + 1] || DEFAULT_OUTPUT_PATH
      i += 1
      continue
    }
    if (arg === '--strict-create') {
      args.allowCreateBlocked = false
      continue
    }
    if (arg === '--allow-create-rate-limited') {
      args.allowCreateRateLimited = true
      continue
    }
    if (arg === '--json') {
      args.json = true
    }
  }

  return args
}

function pass(id, details = {}) {
  return { id, status: 'pass', details }
}

function fail(id, details = {}) {
  return { id, status: 'fail', details }
}

async function fetchJson(baseUrl, path, options, timeoutMs) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    try {
      const response = await fetch(`${baseUrl}${path}`, {
        ...options,
        signal: controller.signal,
      })
      const text = await response.text()
      let json = null
      if (text.length > 0) {
        try {
          json = JSON.parse(text)
        } catch {
          json = null
        }
      }
      return { ok: response.ok, status: response.status, json, text, transportError: null }
    } catch (error) {
      return {
        ok: false,
        status: 0,
        json: null,
        text: '',
        transportError: error instanceof Error ? error.message : 'request failed',
      }
    }
  } finally {
    clearTimeout(timer)
  }
}

async function verifyDeterministicFixtures() {
  const expected = await buildFixtureSnapshot()
  try {
    const actual = await readFixtureFiles()
    const issues = []

    if (actual.snapshotRaw !== expected.canonical) {
      issues.push('snapshot content differs from expected canonical fixture')
    }
    if (actual.metadata?.snapshotHash !== expected.snapshotHash) {
      issues.push('snapshot hash mismatch')
    }
    if (actual.metadata?.snapshotBytes !== expected.metadata.snapshotBytes) {
      issues.push('snapshot byte length mismatch')
    }
    if (actual.metadata?.fixtureVersion !== expected.metadata.fixtureVersion) {
      issues.push('fixture version mismatch')
    }

    if (issues.length > 0) {
      return {
        status: 'fail',
        hash: expected.snapshotHash,
        check: fail('fixtures-deterministic', {
          issues,
          refreshCommand: 'pnpm -C apps/agent-registry local:fixtures',
        }),
      }
    }

    return {
      status: 'pass',
      hash: expected.snapshotHash,
      check: pass('fixtures-deterministic', {
        snapshotHash: expected.snapshotHash,
      }),
    }
  } catch (error) {
    return {
      status: 'fail',
      hash: expected.snapshotHash,
      check: fail('fixtures-deterministic', {
        message: error instanceof Error ? error.message : 'unable to read fixture files',
        expectedFiles: ['.artifacts/local-fixtures.snapshot.json', '.artifacts/local-fixtures.metadata.json'],
        bootstrapCommand: 'pnpm -C apps/agent-registry local:fixtures',
      }),
    }
  }
}

function isApiEnvelope(value) {
  return Boolean(value && typeof value === 'object' && 'data' in value)
}

function getEnvelopeData(value) {
  if (!isApiEnvelope(value)) return null
  return value.data
}

function pickFirstAgentWithEvidence(agents) {
  return agents.find((agent) => Array.isArray(agent?.triples) && agent.triples.length > 0) || agents[0] || null
}

async function runScoutPersona(context) {
  const checks = []

  const list = await fetchJson(
    context.baseUrl,
    '/api/v1/agents?limit=20&sort=trust',
    { method: 'GET' },
    context.timeoutMs,
  )
  const agents = getEnvelopeData(list.json)
  if (!list.ok || !Array.isArray(agents) || agents.length === 0) {
    checks.push(
      fail('discover-agents', {
        status: list.status,
        transportError: list.transportError,
        response: list.json ?? list.text,
      }),
    )
    return { id: 'scout', status: 'fail', checks }
  }
  checks.push(pass('discover-agents', { count: agents.length }))

  const candidateId = agents[0]?.id
  if (!candidateId) {
    checks.push(fail('evidence-fetch', { reason: 'agent id missing from list response' }))
    return { id: 'scout', status: 'fail', checks }
  }

  const detail = await fetchJson(
    context.baseUrl,
    `/api/v1/agents/${candidateId}`,
    { method: 'GET' },
    context.timeoutMs,
  )
  const detailData = getEnvelopeData(detail.json)
  if (!detail.ok || !detailData) {
    checks.push(
      fail('evidence-fetch', {
        status: detail.status,
        transportError: detail.transportError,
        response: detail.json ?? detail.text,
      }),
    )
    return { id: 'scout', status: 'fail', checks }
  }

  const evidenceCount = Array.isArray(detailData.triples) ? detailData.triples.length : 0
  if (evidenceCount < 1) {
    checks.push(fail('evidence-fetch', { agentId: candidateId, evidenceCount }))
  } else {
    checks.push(pass('evidence-fetch', { agentId: candidateId, evidenceCount }))
  }

  const trust = await fetchJson(
    context.baseUrl,
    `/api/v1/agents/${candidateId}/trust`,
    { method: 'GET' },
    context.timeoutMs,
  )
  const trustData = getEnvelopeData(trust.json)
  if (!trust.ok || !trustData) {
    checks.push(
      fail('stake-signal-readable', {
        status: trust.status,
        transportError: trust.transportError,
        response: trust.json ?? trust.text,
      }),
    )
  } else if (
    typeof trustData.stakerCount !== 'number' ||
    typeof trustData.totalStaked !== 'string'
  ) {
    checks.push(fail('stake-signal-readable', { trustData }))
  } else {
    checks.push(
      pass('stake-signal-readable', {
        stakerCount: trustData.stakerCount,
        totalStaked: trustData.totalStaked,
      }),
    )
  }

  const status = checks.some((check) => check.status === 'fail') ? 'fail' : 'pass'
  return { id: 'scout', status, checks, selectedAgentId: candidateId }
}

function assessCreateResult(registerResponse, allowCreateBlocked, allowCreateRateLimited) {
  if (registerResponse.status === 200) {
    const payload = getEnvelopeData(registerResponse.json)
    const ipfsOk = typeof payload?.ipfsUri === 'string' && payload.ipfsUri.startsWith('ipfs://')
    const calldataOk = typeof payload?.calldata === 'string' && payload.calldata.startsWith('0x')
    const atomCostOk = typeof payload?.estimatedAtomCost === 'string'
    if (ipfsOk && calldataOk && atomCostOk) {
      return pass('create-registration', {
        mode: 'prepared',
        ipfsUri: payload.ipfsUri,
      })
    }
    return fail('create-registration', {
      reason: 'registration payload missing expected fields',
      payload,
    })
  }

  const code = registerResponse.json?.code
  if (
    allowCreateBlocked &&
    registerResponse.status === 403 &&
    code === 'REMOTE_WRITE_BLOCKED'
  ) {
    return pass('create-registration', {
      mode: 'guarded',
      status: registerResponse.status,
      code,
    })
  }

  if (
    allowCreateRateLimited &&
    registerResponse.status === 429 &&
    code === 'RATE_LIMITED'
  ) {
    return pass('create-registration', {
      mode: 'rate-limited',
      status: registerResponse.status,
      code,
    })
  }

  return fail('create-registration', {
    status: registerResponse.status,
    transportError: registerResponse.transportError,
    response: registerResponse.json ?? registerResponse.text,
    allowCreateBlocked,
    allowCreateRateLimited,
  })
}

async function runBuilderPersona(context) {
  const checks = []
  const capabilityList = await fetchJson(
    context.baseUrl,
    '/api/v1/capabilities',
    { method: 'GET' },
    context.timeoutMs,
  )
  const capabilities = getEnvelopeData(capabilityList.json)

  if (!capabilityList.ok || !Array.isArray(capabilities) || capabilities.length < 1) {
    checks.push(
      fail('discover-capabilities', {
        status: capabilityList.status,
        transportError: capabilityList.transportError,
        response: capabilityList.json ?? capabilityList.text,
      }),
    )
    return { id: 'builder', status: 'fail', checks }
  }
  checks.push(pass('discover-capabilities', { count: capabilities.length }))

  const registerResponse = await fetchJson(
    context.baseUrl,
    '/api/v1/agents/register',
    {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        name: 'Harness Builder Agent',
        description: 'Deterministic local harness persona for registration flow checks',
        version: '1.0.0',
        model: 'harness-v1',
        endpoint: 'https://example.invalid/harness-builder',
        provider: { name: 'local-harness' },
        tags: ['harness', 'local', 'builder'],
      }),
    },
    context.timeoutMs,
  )
  checks.push(
    assessCreateResult(
      registerResponse,
      context.allowCreateBlocked,
      context.allowCreateRateLimited,
    ),
  )

  const requiredCapability = capabilities[0]?.id
  if (!requiredCapability) {
    checks.push(fail('match-capabilities', { reason: 'no capability id available' }))
    return { id: 'builder', status: 'fail', checks }
  }

  const matchResponse = await fetchJson(
    context.baseUrl,
    '/api/v1/agents/match',
    {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        requiredCapabilities: [requiredCapability],
        matchAll: false,
        limit: 5,
      }),
    },
    context.timeoutMs,
  )
  const matched = getEnvelopeData(matchResponse.json)
  if (!matchResponse.ok || !Array.isArray(matched)) {
    checks.push(
      fail('match-capabilities', {
        status: matchResponse.status,
        transportError: matchResponse.transportError,
        response: matchResponse.json ?? matchResponse.text,
      }),
    )
  } else if (matched.length === 0) {
    checks.push(fail('match-capabilities', { requiredCapability, count: 0 }))
  } else {
    const top = matched[0]
    checks.push(
      pass('match-capabilities', {
        requiredCapability,
        count: matched.length,
        topMatchId: top.id,
        topMatchScore: top.matchScore,
      }),
    )
  }

  const status = checks.some((check) => check.status === 'fail') ? 'fail' : 'pass'
  return { id: 'builder', status, checks }
}

async function runAuditorPersona(context) {
  const checks = []
  const skillList = await fetchJson(
    context.baseUrl,
    '/api/v1/skills?limit=5&sort=trust',
    { method: 'GET' },
    context.timeoutMs,
  )
  const skills = getEnvelopeData(skillList.json)
  if (!skillList.ok || !Array.isArray(skills) || skills.length < 2) {
    checks.push(
      fail('discover-skills', {
        status: skillList.status,
        transportError: skillList.transportError,
        response: skillList.json ?? skillList.text,
      }),
    )
    return { id: 'auditor', status: 'fail', checks }
  }
  checks.push(pass('discover-skills', { count: skills.length }))

  const skillIds = skills.slice(0, 2).map((skill) => skill.id).filter(Boolean)
  const verify = await fetchJson(
    context.baseUrl,
    '/api/v1/skills/verify',
    {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ skill_ids: skillIds }),
    },
    context.timeoutMs,
  )
  const verifyResults = getEnvelopeData(verify.json)
  if (!verify.ok || !Array.isArray(verifyResults)) {
    checks.push(
      fail('verify-skills', {
        status: verify.status,
        transportError: verify.transportError,
        response: verify.json ?? verify.text,
      }),
    )
    return { id: 'auditor', status: 'fail', checks }
  }

  const verifyPass = verifyResults.every(
    (result) => result?.found === true && typeof result?.status === 'string',
  )
  if (!verifyPass) {
    checks.push(fail('verify-skills', { verifyResults }))
  } else {
    checks.push(
      pass('verify-skills', {
        verifiedSkillIds: verifyResults.map((result) => result.id),
      }),
    )
  }

  const agents = await fetchJson(
    context.baseUrl,
    '/api/v1/agents?limit=10&sort=stakers',
    { method: 'GET' },
    context.timeoutMs,
  )
  const agentList = getEnvelopeData(agents.json)
  if (!agents.ok || !Array.isArray(agentList) || agentList.length === 0) {
    checks.push(
      fail('verify-stake-ordering', {
        status: agents.status,
        transportError: agents.transportError,
        response: agents.json ?? agents.text,
      }),
    )
    return { id: 'auditor', status: 'fail', checks }
  }

  const ranked = agentList.every((agent) => typeof agent?.trustSignal?.stakerCount === 'number')
  if (!ranked) {
    checks.push(fail('verify-stake-ordering', { reason: 'staker count missing from one or more agents' }))
  } else {
    checks.push(pass('verify-stake-ordering', { topAgentId: agentList[0].id }))
  }

  const status = checks.some((check) => check.status === 'fail') ? 'fail' : 'pass'
  return { id: 'auditor', status, checks }
}

function collectCoverage(personas) {
  const checkIds = new Set()
  for (const persona of personas) {
    for (const check of persona.checks) {
      if (check.status === 'pass') checkIds.add(check.id)
    }
  }
  return {
    discover: checkIds.has('discover-agents') && checkIds.has('discover-skills'),
    create: checkIds.has('create-registration'),
    stake: checkIds.has('stake-signal-readable') && checkIds.has('verify-stake-ordering'),
    verify: checkIds.has('verify-skills'),
    match: checkIds.has('match-capabilities'),
    evidence: checkIds.has('evidence-fetch'),
  }
}

async function writeReport(outputPath, payload) {
  await mkdir(resolve(outputPath, '..'), { recursive: true })
  await writeFile(outputPath, `${JSON.stringify(payload, null, 2)}\n`)
}

async function main() {
  const args = parseArgs(process.argv.slice(2))

  const fixtureResult = await verifyDeterministicFixtures()
  const context = {
    baseUrl: args.baseUrl,
    timeoutMs: args.timeoutMs,
    allowCreateBlocked: args.allowCreateBlocked,
    allowCreateRateLimited: args.allowCreateRateLimited,
  }

  const personas = [
    await runScoutPersona(context),
    await runBuilderPersona(context),
    await runAuditorPersona(context),
  ]

  const allChecks = [
    fixtureResult.check,
    ...personas.flatMap((persona) => persona.checks),
  ]
  const failedChecks = allChecks.filter((check) => check.status === 'fail')
  const coverage = collectCoverage(personas)
  const coverageOk = Object.values(coverage).every(Boolean)

  const report = {
    harness: 'registry-local-agent-e2e',
    generatedAt: new Date().toISOString(),
    baseUrl: args.baseUrl,
    fixtureSnapshotHash: fixtureResult.hash,
    fixture: {
      status: fixtureResult.status,
      checkId: fixtureResult.check.id,
    },
    personas,
    coverage,
    summary: {
      status: failedChecks.length === 0 && coverageOk ? 'pass' : 'fail',
      failedChecks: failedChecks.length,
      passedChecks: allChecks.length - failedChecks.length,
      totalChecks: allChecks.length,
      coverageComplete: coverageOk,
    },
  }

  await writeReport(args.output, report)

  if (args.json) {
    console.log(JSON.stringify(report))
  } else {
    console.log(`agent harness status: ${report.summary.status}`)
    console.log(`checks: ${report.summary.passedChecks}/${report.summary.totalChecks} passed`)
    console.log(`coverage complete: ${report.summary.coverageComplete}`)
    console.log(`report: ${args.output}`)
    if (failedChecks.length > 0) {
      console.log('failed checks:')
      for (const check of failedChecks) {
        console.log(`- ${check.id}`)
      }
    }
  }

  if (report.summary.status !== 'pass') {
    process.exit(1)
  }
}

const isDirectRun =
  process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href

if (isDirectRun) {
  main().catch((error) => {
    console.error('local agent harness failed', error)
    process.exit(1)
  })
}

export { parseArgs, assessCreateResult, collectCoverage }
