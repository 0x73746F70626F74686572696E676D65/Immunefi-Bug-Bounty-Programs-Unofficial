/**
 * MCP Registry scraper — official REST API.
 * API: GET https://registry.modelcontextprotocol.io/v0/servers
 *
 * Response shape: { servers: Array<{ server: {...}, _meta: {...} }>, metadata: {...} }
 */

import type { Corpus, CorpusSkill, RequiredEnvVar } from './types'
import { extractGithubOwner, inferCapabilities, slugify } from './utils'

interface McpEnvVar {
  name?: string
  description?: string
  isSecret?: boolean
  format?: string
}

interface McpTransport {
  type?: string
}

interface McpPackage {
  registryType?: string
  identifier?: string
  version?: string
  transport?: McpTransport
  environmentVariables?: McpEnvVar[]
}

interface McpRegistryServer {
  name?: string
  description?: string
  repository?: { url?: string; source?: string }
  version?: string
  packages?: McpPackage[]
}

interface McpRegistryItem {
  server?: McpRegistryServer
  _meta?: unknown
}

interface McpRegistryResponse {
  servers?: McpRegistryItem[]
  metadata?: unknown
}

function normalizeTransport(raw: string | undefined): 'stdio' | 'sse' | 'http' | 'websocket' | undefined {
  switch (raw) {
    case 'stdio': return 'stdio'
    case 'sse': return 'sse'
    case 'http': return 'http'
    case 'websocket': return 'websocket'
    default: return undefined
  }
}

export async function fetchMcpRegistry(): Promise<Corpus> {
  const url = 'https://registry.modelcontextprotocol.io/v0/servers'
  console.log(`[mcp-registry] Fetching ${url}...`)

  const res = await fetch(url, {
    headers: { Accept: 'application/json' },
    signal: AbortSignal.timeout(15_000),
  })

  if (!res.ok) {
    console.warn(`[mcp-registry] HTTP ${res.status} — skipping`)
    return { agents: [], skills: [] }
  }

  const data: McpRegistryResponse = await res.json()
  const items = data.servers ?? []
  console.log(`[mcp-registry] Got ${items.length} servers`)

  const skills: CorpusSkill[] = items
    .filter((item) => item.server?.name)
    .map((item) => {
      const server = item.server!

      // Prefer npm package for install URI; fall back to first package
      const npmPkg = server.packages?.find((p) => p.registryType === 'npm')
      const firstPkg = server.packages?.[0]
      const primaryPkg = npmPkg ?? firstPkg

      const installUri = npmPkg?.identifier ? `npx ${npmPkg.identifier}` : undefined
      const transport = normalizeTransport(primaryPkg?.transport?.type)

      const repoUrl = server.repository?.url ?? ''
      const author = repoUrl ? extractGithubOwner(repoUrl) : 'Unknown'

      // server.name is like "ai.aliengiraffe/spotdb" — use the last path segment
      const nameParts = (server.name ?? '').split('/')
      const shortName = nameParts[nameParts.length - 1] ?? server.name ?? 'unknown'

      const rawEnvVars = primaryPkg?.environmentVariables ?? []
      const requiredEnvVars: RequiredEnvVar[] = rawEnvVars
        .filter((e) => e.name)
        .map((e) => ({
          name: e.name!,
          ...(e.description ? { description: e.description } : {}),
          ...(e.isSecret !== undefined ? { isSecret: e.isSecret } : {}),
        }))

      return {
        metadata: {
          '@type': 'Skill' as const,
          name: `mcp-${slugify(shortName)}`,
          description: (server.description ?? 'MCP server').slice(0, 500),
          version: server.version ?? npmPkg?.version ?? '0.1.0',
          platform: 'mcp',
          author,
          ...(installUri ? { installUri } : {}),
          ...(transport ? { transport } : {}),
          ...(requiredEnvVars.length > 0 ? { requiredEnvVars } : {}),
        },
        capabilities: inferCapabilities(shortName, server.description ?? '', ''),
      }
    })

  return { agents: [], skills }
}
