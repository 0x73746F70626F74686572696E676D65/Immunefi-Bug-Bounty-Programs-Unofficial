import { describe, expect, it } from 'vitest'
import { parseArgs, compareSurfaces, CONTRACT } from '../local-shared-parity.mjs'

describe('local-shared-parity', () => {
  it('parses default args', () => {
    const args = parseArgs([])
    expect(args.localUrl).toBe('http://localhost:8080/v1/graphql')
    expect(args.sharedUrl).toBe('')
    expect(args.output).toContain('.artifacts/local-shared-parity.report.json')
  })

  it('detects contract mismatches and diffs', () => {
    const local = {
      queryRoots: [...CONTRACT.queryRoots],
      typeFields: {
        atom: [...CONTRACT.typeFields.atom],
        triple: [...CONTRACT.typeFields.triple],
        vault: [...CONTRACT.typeFields.vault],
      },
    }
    const shared = {
      queryRoots: CONTRACT.queryRoots.filter((name) => name !== 'vault_aggregate'),
      typeFields: {
        atom: CONTRACT.typeFields.atom.filter((name) => name !== 'as_subject_triples'),
        triple: CONTRACT.typeFields.triple.filter((name) => name !== 'counter_term_id'),
        vault: CONTRACT.typeFields.vault,
      },
    }

    const result = compareSurfaces(local, shared)
    expect(result.hasContractMismatch).toBe(true)
    expect(result.contractMissingShared.queryRoots).toContain('vault_aggregate')
    expect(result.contractMissingShared.typeFields.atom).toContain('as_subject_triples')
    expect(result.contractMissingShared.typeFields.triple).toContain('counter_term_id')
    expect(result.surfaceDiff.queryRootsOnlyLocal).toContain('vault_aggregate')
  })

  it('passes when local and shared surfaces satisfy contract', () => {
    const local = {
      queryRoots: [...CONTRACT.queryRoots],
      typeFields: {
        atom: [...CONTRACT.typeFields.atom],
        triple: [...CONTRACT.typeFields.triple],
        vault: [...CONTRACT.typeFields.vault],
      },
    }
    const shared = {
      queryRoots: [...CONTRACT.queryRoots, 'custom_extra'],
      typeFields: {
        atom: [...CONTRACT.typeFields.atom, 'custom_atom_extra'],
        triple: [...CONTRACT.typeFields.triple],
        vault: [...CONTRACT.typeFields.vault],
      },
    }

    const result = compareSurfaces(local, shared)
    expect(result.hasContractMismatch).toBe(false)
    expect(result.contractMissingLocal.queryRoots).toEqual([])
    expect(result.contractMissingShared.queryRoots).toEqual([])
  })
})
