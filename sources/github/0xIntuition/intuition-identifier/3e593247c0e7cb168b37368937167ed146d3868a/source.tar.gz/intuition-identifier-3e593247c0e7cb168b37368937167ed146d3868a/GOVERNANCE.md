# Governance

This document describes how decisions about the Intuition Identifier specification are
made. The normative change process — what kinds of change are permitted at all — is
defined in [spec §9](./spec/09-registry-governance.md) and [spec §1.5](./spec/01-conformance.md);
this document describes who exercises it and how.

## Principles

1. **The spec serves implementers.** When a decision trades author convenience against
   implementer clarity, implementers win.
2. **Determinism is non-negotiable.** No change is accepted that makes derivation depend
   on network access, clocks, locale, configuration, or judgement — however useful it
   would be. Judgement belongs to the [equivalence layer](./spec/08-equivalence.md).
3. **The past is immutable; the future is open.** Ratified canonicalization rules are
   frozen forever ([the freeze rule](./spec/09-registry-governance.md)). Everything
   additive — new schemes, new entity types, new rungs, reorderings — is genuinely open
   for proposal by anyone.
4. **Decisions are recorded, including rejections.** Rejected scheme proposals are
   documented with their reasons ([spec §9.5](./spec/09-registry-governance.md)) so
   settled questions are not relitigated and newcomers can see the reasoning, not just
   the outcome.

## Roles

**Contributors** — anyone. Open issues and PRs, propose schemes and ladder changes,
implement the spec, review others' proposals. No permission needed.

**Maintainers** — merge rights on this repository. Responsible for review quality,
consistency of the specification as a whole, and version discipline. Maintainers are
listed in [`MAINTAINERS.md`](./MAINTAINERS.md).

**Editor** — one maintainer per release acts as editor: owns the changelog, assigns
version numbers per [spec §1.5](./spec/01-conformance.md), and cuts release tags.

Becoming a maintainer follows sustained, high-quality contribution — typically several
ratified proposals or a conforming implementation — and is decided by consensus of the
existing maintainers.

## How changes are decided

| Change | Process | Version impact |
| :-- | :-- | :-- |
| Editorial (no behavioural effect) | PR; one maintainer approval | PATCH |
| New scheme | PR per [spec §9.4](./spec/09-registry-governance.md); open review ≥ 14 days; two maintainer approvals | MINOR |
| New entity type or `gen1` recipe rung | PR; open review ≥ 14 days; two maintainer approvals | MINOR |
| Ladder reordering | PR; open review ≥ 14 days; two maintainer approvals | MINOR |
| Openness-tier reassignment (a registry's licensing changed) | PR with evidence of the licensing change; two maintainer approvals | MINOR |
| Scheme deprecation | PR per [spec §9.6](./spec/09-registry-governance.md); open review ≥ 30 days | MINOR |
| Grammar change ([spec §2](./spec/02-grammar.md)) | Requires a MAJOR release; maintainer consensus plus a public comment period ≥ 30 days | MAJOR |
| Editing a ratified canonicalization | **Not permitted.** Ship a versioned successor instead | — |

"Open review" means the PR stays open for at least the stated period with the proposal
complete, so implementers have a real chance to object. Silence is not consent for
normative changes: they need explicit approvals.

## Disagreement

Technical disagreement is resolved on the PR, in public, by argument against the
[design tenets](./spec/00-overview.md). If consensus does not emerge, maintainers decide
by simple majority; the losing position is recorded in the PR so it can be revisited
with new evidence. A rejected scheme goes into the rejected list with its reason — which
is a standing invitation to overturn the rejection by changing the underlying fact (for
example, a registry opening its licensing).

## Relationship to the Intuition protocol

This specification is developed in the open and is designed to be useful outside
Intuition. The Intuition protocol is its first and reference deployment, and 0xIntuition
currently stewards the repository. The long-term intent is for governance to be as
boring, predictable, and capture-resistant as the identifier space it governs: frozen
history, additive change, public reasoning.
