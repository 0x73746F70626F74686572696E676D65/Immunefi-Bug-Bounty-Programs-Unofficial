# `local-business` — Local business

| | |
| :-- | :-- |
| **Slug** | `local-business` |
| **Identifies** | One business at one place — the instance level. A restaurant, shop, or venue at a specific location, distinct from any [`brand`](./brand.md) or chain it belongs to. |
| **gen1 namespace** | `local-business` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T2 | [`wd`](../schemes/wd.md) from `sameAs` | A QID is known — rare; chains and landmark businesses only |
| 2 | C | — | [`gen1`](../schemes/gen1.md)`{name, geo7}` (tag `r2`) | Name plus coordinates are present |
| 3 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r4`) | Only a name is present |

## Notes

- **No open global registry of local businesses exists.** Proprietary place IDs were
  evaluated and rejected on licensing grounds — their terms prohibit exactly the storage
  and republication a public knowledge graph requires. So this type leans on `gen1`
  more than most.
- `geo7` is the **geohash precision-7 cell** (roughly 150 m square) of the venue's
  `latitude`/`longitude`, computed at intake. The cell size is the point: providers
  measuring the same venue tens of meters apart land in the same cell, so the identifier
  is stable under GPS jitter, while two same-name businesses across town land in
  different cells. Food-court neighbors in one cell are separated by `name`.
- The chain a business belongs to does **not** enter the identifier: a restaurant remains
  that restaurant regardless of which sign hangs on it — the scoped-identifier litmus
  test ([spec §5.5.1](../spec/05-identity-ladders.md)). Chain membership is a claim
  against the brand atom.
- Accepted failure modes: a relocation across cells or a rename produces a new Class C
  identifier; the equivalence layer joins old and new
  ([spec §8](../spec/08-equivalence.md)).
- The rung tags are `r2` and `r4` — non-contiguous, because tags are frozen recipe
  identifiers, not positions ([spec §6.4](../spec/06-gen1.md)).

## Open proposals

- The `geo7` recipe requires `latitude`/`longitude` fields on the entity type; without
  them rung 2 can never fire. Ensuring coordinate capture across sources is an open,
  contribution-welcome improvement.
