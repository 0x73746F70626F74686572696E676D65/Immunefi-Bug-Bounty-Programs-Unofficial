# `product` — Product

| | |
| :-- | :-- |
| **Slug** | `product` |
| **Identifies** | The product **model** — the thing on the shelf as a catalog concept, not any individual manufactured unit. |
| **gen1 namespace** | `product` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T1 | [`gtin`](../schemes/gtin.md) from the `gtin` field | A GTIN is present and its check digit validates |
| 2 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r2`) | A name is present |

## Notes

- GTIN unifies the UPC and EAN barcode families under one GS1-governed T1 scheme — the
  identifier printed on essentially every retail product, validatable offline by check
  digit.
- Two deliberate exclusions from the `gen1` recipe
  ([spec §5.6](../spec/05-identity-ladders.md)):
  - **Brand** — a related entity's name; brand linkage is a claim from the product atom
    to the [`brand`](./brand.md) atom.
  - **SKU / MPN** — brand-scoped codes that are only meaningful *with* the brand, so they
    cannot rescue the recipe once the brand is excluded. They remain useful descriptive
    fields and evidence.
- The cost is that rung 2 merges same-name products across brands — the honest Class C
  ambiguity, resolved by acquiring the GTIN.
