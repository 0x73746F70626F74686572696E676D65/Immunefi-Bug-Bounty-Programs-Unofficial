# `social-media-posting` — Social media posting

| | |
| :-- | :-- |
| **Slug** | `social-media-posting` |
| **Identifies** | One post — a single published posting, as distinct from the account that posted it. |
| **gen1 namespace** | `social-media-posting` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`url`](../schemes/url.md) from the `url` field | The post's permalink is known |
| 2 | C | — | [`gen1`](../schemes/gen1.md)`{textHash}` (tag `r2`) | The post's text is present |

## Notes

- The permalink is the natural anchor for a post and should almost always be available.
- Rung 2 hashes the **content, never embeds it**: `textHash` is
  `keccak16(NORM-1(text))`, computed before the recipe is assembled, so the post's full
  text never appears raw in an identifier or preimage — only 16 bytes of digest. It is a
  last resort: an identical repost (or a coordinated copy-paste) shares the identifier,
  which is the accurate Class C statement that the *text* is the same
  ([spec §6.1](../spec/06-gen1.md)).
- The author is a related entity: authorship is a claim from the post atom to the
  [`social-media-account`](./social-media-account.md) atom, never part of the identifier
  ([spec §5.6](../spec/05-identity-ladders.md)).
