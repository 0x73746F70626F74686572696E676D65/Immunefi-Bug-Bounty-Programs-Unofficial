# `ethereum-erc20` — ERC-20 token

| | |
| :-- | :-- |
| **Slug** | `ethereum-erc20` |
| **Identifies** | A token **asset on a chain** — the fungible asset as a whole, scoped to the chain where its contract is deployed. |
| **gen1 namespace** | — (no gen1 rung) |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`caip19`](../schemes/caip19.md) — `eip155:<chainId>/erc20:` + lowercase `address` | Chain ID and contract address are present |

## Notes

- Unlike an [EOA](./ethereum-account.md), a token is genuinely **per-chain**: USDC on
  mainnet and USDC on Base are different deployments with different addresses and
  different supplies, so the chain belongs inside the identifier — a clean pass of the
  scoped-identifier litmus test ([spec §5.5.1](../spec/05-identity-ladders.md)). Where
  bridged deployments represent "the same token", that is an equivalence-layer statement
  ([spec §8](../spec/08-equivalence.md)), not an identity assumption.
- **Asset vs contract.** The same deployment has two facets: the asset (this type,
  `caip19`) and the deployed contract
  ([`ethereum-smart-contract`](./ethereum-smart-contract.md), `caip10`). Their
  identifiers differ by design; a standing relationship claim can link the two atoms
  without merging them.
- Ticker symbols and token names are never identity — they are unenforced, duplicated,
  and actively spoofed.
