# `podcast-series` — Podcast series

| | |
| :-- | :-- |
| **Slug** | `podcast-series` |
| **Identifies** | The show at the **feed level** — the series a listener subscribes to, as distinct from its individual feed items ([`podcast-episode`](./podcast-episode.md)). |
| **gen1 namespace** | `podcast-series` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T2 | [`podcastguid`](../schemes/podcastguid.md) — declared `<podcast:guid>` tag, from the `podcastGuid` field | The publisher declares a GUID in the feed |
| 2 | A | T2 | [`podcastguid`](../schemes/podcastguid.md) — derived offline from the feed URL (fallback) | A feed URL is known but no GUID is declared |
| 3 | B | — | [`url`](../schemes/url.md) from the `url` field | A feed or official page URL is known |
| 4 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r3`) | Only a name is present |

## Notes

- Rungs 1 and 2 use the same scheme with different sources, and the order is the point.
  The **declared** `<podcast:guid>` is designed to survive feed migrations — the
  publisher carries it to the new host. The **derived** GUID (a deterministic UUID
  computed from the feed URL, per the Podcasting 2.0 convention) is bit-identical to
  what a declaring publisher would have gotten, but it forks when the feed moves, so it
  is strictly a fallback. When a migration does fork identifiers, the equivalence layer
  joins them ([spec §8](../spec/08-equivalence.md)).
- Derivation of the fallback GUID happens **offline** from the feed URL string — no
  network access, per the ladder rules ([spec §5.6](../spec/05-identity-ladders.md)).
- The host and network are related entities; series linkage from episodes is likewise a
  claim, not part of any identifier.
