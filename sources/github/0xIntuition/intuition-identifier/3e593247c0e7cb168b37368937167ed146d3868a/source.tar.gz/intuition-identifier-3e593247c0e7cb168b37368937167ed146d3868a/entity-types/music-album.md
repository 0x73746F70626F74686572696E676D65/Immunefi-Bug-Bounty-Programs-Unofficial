# `music-album` — Music album

| | |
| :-- | :-- |
| **Slug** | `music-album` |
| **Identifies** | The **release-group** — the album as a work. Not a specific pressing, edition, or regional release; those attach to the group through equivalence. |
| **gen1 namespace** | `music-album` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T2 | [`mbid`](../schemes/mbid.md) from `sameAs` | A MusicBrainz release-group ID is known |
| 2 | A | T2 | [`wd`](../schemes/wd.md) from `sameAs` | A Wikidata QID is known |
| 3 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r4`) | Only a title is present |

## Notes

- Music has a four-level stack — artist → release-group → release → recording — and this
  type is pinned to the **release-group** ([spec §5.5](../spec/05-identity-ladders.md)).
  The 1997 CD, the remaster, and the vinyl reissue of one album are releases; the album
  they all are is the release-group. MusicBrainz models this level directly, which is why
  `mbid` (with its `release-group:` type segment) leads the ladder.
- `byArtist` is deliberately excluded from the recipe: an artist is a related entity, and
  artist-credit formatting varies enough between sources ("Jay-Z", "JAY-Z", "Jay-Z feat.
  …") to fork the album's identifier
  ([spec §5.6](../spec/05-identity-ladders.md)). Artist linkage is a claim to the
  [`music-group`](./music-group.md) atom. The cost — same-title albums by different
  artists merging at rung 3 — is the standard Class C ambiguity, resolved by climbing.
