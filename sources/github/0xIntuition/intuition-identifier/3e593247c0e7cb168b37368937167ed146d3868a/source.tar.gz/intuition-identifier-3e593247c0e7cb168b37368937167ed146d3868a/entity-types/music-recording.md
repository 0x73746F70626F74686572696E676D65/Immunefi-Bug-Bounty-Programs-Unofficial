# `music-recording` — Music recording

| | |
| :-- | :-- |
| **Slug** | `music-recording` |
| **Identifies** | The **recording** — a specific recorded performance, the level ISRC identifies. The underlying composition is ISWC territory and would be a separate entity type if ever modeled. |
| **gen1 namespace** | `music-recording` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T1 | [`isrc`](../schemes/isrc.md) from the `isrc` field | An ISRC is present |
| 2 | A | T2 | [`mbid`](../schemes/mbid.md) from `sameAs` | A MusicBrainz recording ID is known |
| 3 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r3`) | Only a title is present |

## Notes

- `isrc` outranks `mbid` by precision, not by tier: the ISRC's entire job is naming
  recordings, and the identifier that identifies the entity type most precisely ranks
  higher within a class ([spec §3.5](../spec/03-identity-classes.md)).
- The studio recording, the live version, and the remix of one song are **different
  recordings** with different ISRCs — that is the abstraction level working, not a
  defect. Their common composition would be an [`iswc`](../schemes/iswc.md)-anchored
  work-level entity if that level is ever added.
- Two deliberate recipe exclusions:
  - `byArtist` — featured-credit and multi-artist formatting varies per source and would
    fork the identifier; artist linkage is a claim to the
    [`music-group`](./music-group.md) atom ([spec §5.6](../spec/05-identity-ladders.md)).
  - `inAlbum` — never identity in the first place: the same recording appears on the
    album, the compilation, and the greatest-hits release.
