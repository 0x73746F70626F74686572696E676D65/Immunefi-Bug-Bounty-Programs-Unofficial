# `web-site` — Web site

| | |
| :-- | :-- |
| **Slug** | `web-site` |
| **Identifies** | A site at the **origin** level — scheme plus host, with the path stripped. The site is the container; its pages are [`web-page`](./web-page.md) atoms. |
| **gen1 namespace** | — (no gen1 rung) |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`url`](../schemes/url.md) — the `url` field normalized to origin only | A URL on the site is known |

## Notes

- Whatever URL arrives — the homepage, a deep link, a URL with a path — the extraction
  reduces it to its **origin** (`https://example.com`) before `url` canonicalization.
  Every URL on a site therefore derives the same site identifier, which is exactly the
  abstraction-level pin: this type identifies the site, and letting a path leak into the
  value would silently mint page-level identity under a site-level type
  ([spec §5.5](../spec/05-identity-ladders.md)).
- A site and its pages are different abstraction levels and are never merged by
  equivalence; containment is a claim.
- Subdomains are distinct origins and therefore distinct sites by default. Where two
  origins are genuinely one site (`example.com` / `www.example.com`), the equivalence
  layer joins them ([spec §8](../spec/08-equivalence.md)).
