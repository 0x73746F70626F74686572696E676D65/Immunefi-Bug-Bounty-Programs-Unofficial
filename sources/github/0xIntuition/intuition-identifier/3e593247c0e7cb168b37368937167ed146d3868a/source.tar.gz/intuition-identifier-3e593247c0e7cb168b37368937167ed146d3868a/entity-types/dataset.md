# `dataset` — Dataset

| | |
| :-- | :-- |
| **Slug** | `dataset` |
| **Identifies** | A dataset as a published resource. Version lineage is out of identity scope — versions of one dataset relate through claims, not through the identifier. |
| **gen1 namespace** | `dataset` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T1 | [`doi`](../schemes/doi.md) from `sameAs` | A DOI is known |
| 2 | B | — | [`url`](../schemes/url.md) from the `url` field | A landing page URL is present |
| 3 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r3`) | A name is present |

## Notes

- Research datasets are heavily DOI-registered — Zenodo, figshare, and Dryad all mint
  DOIs on deposit — so rung 1 has unusually good coverage for scholarly data.
- The publishing repository and the dataset's creators are related entities and stay out
  of the recipe ([spec §5.6](../spec/05-identity-ladders.md)).
- Some repositories mint one DOI per version and a concept DOI for the whole series.
  Either is a legitimate Class A anchor; atoms minted from different DOIs of one dataset
  are joined by the equivalence layer ([spec §8](../spec/08-equivalence.md)).
