# `web-page` — Web page

| | |
| :-- | :-- |
| **Slug** | `web-page` |
| **Identifies** | A page at a canonical URL — one addressable document, as distinct from the site containing it ([`web-site`](./web-site.md)). |
| **gen1 namespace** | — (no gen1 rung) |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`url`](../schemes/url.md) from the `url` field | Always — the URL is the entity's required, defining field |

## Notes

- The one entity type whose identifier can never be missing: a web page without a URL is
  not a web page. The single rung always fires, so every `web-page` atom has a Class B
  natural key and no fallback is needed.
- **Canonical-URL discovery is enrichment, not canonicalization.** Following redirects
  and reading `rel=canonical` require network access, so they happen *before* derivation;
  the derivation itself applies only the offline, deterministic
  [`url`](../schemes/url.md) normalization
  ([spec §5.6](../spec/05-identity-ladders.md)). Two atoms minted from a page's tracking
  URL and its canonical URL are joined afterward by equivalence
  ([spec §8](../spec/08-equivalence.md)).
- Page **content** is not identity here — a page keeps its identity as its content
  changes. Content-addressed identity belongs to [`image`](./image.md)-style `hash`
  anchors.
