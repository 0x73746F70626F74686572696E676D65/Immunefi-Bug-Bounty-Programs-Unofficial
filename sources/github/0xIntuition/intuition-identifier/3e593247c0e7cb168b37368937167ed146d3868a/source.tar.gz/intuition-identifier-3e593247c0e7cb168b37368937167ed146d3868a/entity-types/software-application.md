# `software-application` — Software application

| | |
| :-- | :-- |
| **Slug** | `software-application` |
| **Identifies** | An end-user application — the product people run, as distinct from a code package ([`software`](./software.md)) or a store-distributed mobile app ([`mobile-application`](./mobile-application.md)). |
| **gen1 namespace** | `software-application` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`url`](../schemes/url.md) from the `url` field | The application's official page is known |
| 2 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r4`) | Only a name is present |

## Notes

- Applications as products have no registry of their own; the official site is the
  strongest anchor generally available today, and a name hash is the honest floor.
- The vendor is a related entity — vendor linkage is a claim to the
  [`company`](./company.md) atom, never recipe input
  ([spec §5.6](../spec/05-identity-ladders.md)).
- Identity is version-free: releases and editions relate to the application atom as
  claims.

## Open proposals

- This ladder is the registry's clearest candidate for strengthening: add
  [`purl`](../schemes/purl.md) and [`appid`](../schemes/appid.md) rungs **above** `url`,
  covering applications distributed as packages and applications with platform bundle
  IDs. Both schemes are already in the registry; the addition is a MINOR ladder change
  that invalidates nothing ([spec §9](../spec/09-registry-governance.md)). Contributions
  welcome.
