# `job-posting` — Job posting

| | |
| :-- | :-- |
| **Slug** | `job-posting` |
| **Identifies** | One posting — a specific listing as published, not the role, the team, or the employer. |
| **gen1 namespace** | `job-posting` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`url`](../schemes/url.md) from the `url` field | The posting's URL is known |
| 2 | C | — | [`gen1`](../schemes/gen1.md)`{title, datePosted}` (tag `r2`) | Title and posting date are present |
| 3 | C | — | [`gen1`](../schemes/gen1.md)`{title}` (tag `r3`) | Only a title is present |

## Notes

- The posting URL is the natural anchor: postings are born on the web and the listing
  page is the posting.
- The **hiring organization** is deliberately excluded from the recipes: an employer is a
  related entity, and its free-text name would fork the posting's identity
  ([spec §5.6](../spec/05-identity-ladders.md)). Employer linkage is a claim from the
  posting atom to the [`company`](./company.md) atom — with the striking consequence that
  every "Senior Engineer" posted on one day shares the rung 2 identifier. That is
  extremely ambiguous, and honestly so: the Class C identifier declares its own weakness
  rather than smuggling a relationship into the hash.
- `datePosted` is an intrinsic stable scalar of the posting event and separates reposts
  of the same title across time.
