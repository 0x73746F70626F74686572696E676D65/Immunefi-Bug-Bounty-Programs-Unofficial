# `ethereum-smart-contract` — Ethereum smart contract

| | |
| :-- | :-- |
| **Slug** | `ethereum-smart-contract` |
| **Identifies** | A deployed contract — one deployment at one address on one chain. |
| **gen1 namespace** | — (no gen1 rung) |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`caip10`](../schemes/caip10.md) — `eip155:<chainId>:` + lowercase `address` | Chain ID and address are present |

## Notes

- A contract is a deployment, and deployments are per-chain: the same source code
  deployed to mainnet and to an L2 yields two contracts with independent state. The
  chain ID therefore stays real here — unlike [`ethereum-account`](./ethereum-account.md),
  where the keypair is chain-agnostic and the chain is pinned to `eip155:1`.
- Addresses are lowercased; EIP-55 casing is presentation, not identity.
- An ERC-20 token and the contract implementing it are two facets of one deployment with
  deliberately different identifiers — [`caip19`](../schemes/caip19.md) for the asset,
  [`caip10`](../schemes/caip10.md) for the contract. A relationship claim links the two
  atoms; the equivalence layer never merges them
  ([spec §5.5](../spec/05-identity-ladders.md)).
- Proxy patterns mean one "protocol" may be many contract atoms (proxy, implementation,
  admin). Those relationships are claims — the identifier layer records deployments,
  not architectures.
