# `defined-term` — Defined term

| | |
| :-- | :-- |
| **Slug** | `defined-term` |
| **Identifies** | A term **within a term set** — a code or vocabulary entry whose meaning exists only relative to the set that defines it. |
| **gen1 namespace** | `defined-term` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`termset`](../schemes/termset.md) from `inDefinedTermSet` + `termCode` | Both the term set and the term code are present |
| 2 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r2`) | Only a name is present |

## Notes

- A defined term is the textbook case of a **legitimately scoped identifier**
  ([spec §5.5.1](../spec/05-identity-ladders.md)): the code `US-CA` means nothing outside
  ISO 3166-2; if the term set vanished, the term would not be identifiable as itself. So
  the set belongs *inside* the identifier, and the `termset` value is built from both — a
  hash of the normalized set reference plus the slugified term code.
- Rung 2 is a name-only hash and correspondingly weak: the same word defined in two
  vocabularies merges at this rung. That ambiguity is the honest Class C report
  ([spec §6.1](../spec/06-gen1.md)); climbing to rung 1 requires knowing the set.
