# `podcast-episode` — Podcast episode

| | |
| :-- | :-- |
| **Slug** | `podcast-episode` |
| **Identifies** | One **feed item** — a manifestation of the episode. The episode-as-work is the equivalence cluster over its feed items, exactly the book/edition pattern. |
| **gen1 namespace** | `podcast-episode` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`rssitem`](../schemes/rssitem.md) from `feedGuid` + `itemGuid` | Both the feed GUID and the item GUID are known |
| 2 | B | — | [`url`](../schemes/url.md) from the `url` field | An episode page URL is known |
| 3 | C | — | [`gen1`](../schemes/gen1.md)`{name, datePublished}` (tag `r3`) | Title and publication date are present |
| 4 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r4`) | Only a title is present |

## Notes

- Shows commonly run **multiple feeds** — ad-free premium, migrated hosts, mirrors. Each
  feed's item is a distinct manifestation atom; the episode-work is their cluster
  ([spec §5.5](../spec/05-identity-ladders.md), [§8](../spec/08-equivalence.md)).
  Candidate generation for that clustering is series-scoped.
- `rssitem` is the canonical **pass** of the scoped-identifier litmus test
  ([spec §5.5.1](../spec/05-identity-ladders.md)): an item GUID is a publisher-chosen
  string with no meaning outside its feed, so the feed GUID belongs inside the
  identifier. The value is the feed GUID plus `keccak16(NORM-1(itemGuid))` — item GUIDs
  are format-arbitrary (URN, URL, UUID) but byte-identical for every reader of the feed,
  so hashing normalizes format without harming determinism.
- The series **title** is deliberately excluded from the `gen1` recipes: a series is a
  related entity, and its free-text title would fork episode identity on every retitle
  ([spec §5.6](../spec/05-identity-ladders.md)). Series membership is a claim to the
  [`podcast-series`](./podcast-series.md) atom.
- The enclosure URL (the MP3's CDN address) is never an identity input — CDN URLs churn.
