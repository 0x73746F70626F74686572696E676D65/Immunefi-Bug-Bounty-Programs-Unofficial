# `company` — Company

| | |
| :-- | :-- |
| **Slug** | `company` |
| **Identifies** | A legal entity — the registered organization, distinct from its brands ([`brand`](./brand.md)) and its physical locations ([`local-business`](./local-business.md)). |
| **gen1 namespace** | `company` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T2 | [`wd`](../schemes/wd.md) from `sameAs` | A Wikidata QID is known |
| 2 | B | — | [`url`](../schemes/url.md) from the `url` field | The official website is known |
| 3 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r4`) | A name is present |

## Notes

- The commerce domain has four legitimate abstraction levels — company → brand → local
  business → premises — and this type is the top of that stack
  ([spec §5.5](../spec/05-identity-ladders.md)). The McDonald's corporation, the
  McDonald's brand, and a McDonald's franchise are three different atoms; name matches
  across levels are evidence of relationships, never of identity.
- The official domain is a strong natural key for a company: it is publicly claimed,
  singular in practice, and verifiable without any registry.
- Rung 3 hashes only the company's own name. Subsidiaries, parents, and ownership travel
  as claims between company atoms, not as identity input
  ([spec §5.6](../spec/05-identity-ladders.md)).
