# `music-group` — Music group

| | |
| :-- | :-- |
| **Slug** | `music-group` |
| **Identifies** | An artist or band's **public identity** — the performing persona, whether that is one legal person, several, or a stage name. |
| **gen1 namespace** | `music-group` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T1 | [`isni`](../schemes/isni.md) from `sameAs` | An ISNI is known — ISNI assigns IDs to bands and stage personas, not just legal persons |
| 2 | A | T2 | [`mbid`](../schemes/mbid.md) from `sameAs` | A MusicBrainz artist ID is known — e.g. `int:mbid:artist:056e4f3e-d505-4dad-8ec1-d04f521cbb56` for Daft Punk |
| 3 | A | T2 | [`wd`](../schemes/wd.md) from `sameAs` | A Wikidata QID is known |
| 4 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r4`) | Only a name is present |

## Notes

- This was a motivating hard case for the whole ladder design — "how do you identify a
  band?" — and the answer is that a standard exists: **ISNI covers performing identities**
  (Daft Punk has an ISNI), with MusicBrainz covering the long tail of working artists.
- The `mbid` value carries its entity type in-value (`artist:`), because MusicBrainz IDs
  are unique per entity type, not globally.
- Rung 4 is ambiguous by construction, and the canonical illustration of why that is
  correct: two bands named Nirvana **collide honestly**. The name-only atom identifies
  the name-level concept "Nirvana, understood as a music group"
  ([spec §6.1](../spec/06-gen1.md)). Disambiguation is enrichment upgrading each real
  band to its own Class A atom — never fabricating disambiguators (founding year, city,
  genre) into the hash, which would destroy determinism across sources
  ([spec §6.7](../spec/06-gen1.md)).
- Band membership and artist relationships are claims between atoms, not identity input
  ([spec §5.6](../spec/05-identity-ladders.md)).
