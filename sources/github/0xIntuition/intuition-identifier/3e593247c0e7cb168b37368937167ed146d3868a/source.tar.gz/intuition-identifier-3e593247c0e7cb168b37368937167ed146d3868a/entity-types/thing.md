# `thing` — Thing

| | |
| :-- | :-- |
| **Slug** | `thing` |
| **Identifies** | Anything not covered by a more specific entity type — the catch-all, and deliberately the weakest identity in the system. |
| **gen1 namespace** | `thing` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T2 | [`wd`](../schemes/wd.md) from `sameAs` | A Wikidata QID is known |
| 2 | B | — | [`url`](../schemes/url.md) from `sameAs` | A canonical page is known |
| 3 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r3`) | A name is present |

## Notes

- A catch-all that pretended to strong identity would be lying. A `thing` has, by
  definition, no domain-specific registry and no natural key beyond whatever `sameAs`
  happens to carry, so its floor is a bare name hash and its Class C identifier says so
  ([spec §3.2](../spec/03-identity-classes.md)).
- The right fix for a weakly identified `thing` is usually not a stronger rung here but a
  **more specific entity type** — reclassification puts the entity onto a ladder with
  real registries and natural keys.
- As everywhere, upgrades never mutate the existing atom: a later, stronger identifier is
  a new atom joined by equivalence ([spec §5.4](../spec/05-identity-ladders.md)).
