# `brand` — Brand

| | |
| :-- | :-- |
| **Slug** | `brand` |
| **Identifies** | A brand as a concept — the marketing identity, not the legal entity that owns it ([`company`](./company.md)) and not any physical outlet carrying it ([`local-business`](./local-business.md)). |
| **gen1 namespace** | `brand` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T2 | [`wd`](../schemes/wd.md) from `sameAs` | A Wikidata QID is known |
| 2 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r2`) | A name is present |

## Notes

- Brands are legal and marketing constructs with no registry of their own beyond
  Wikidata, so the ladder is short by nature.
- The owning company deliberately does **not** enter the identifier. Brand ownership is a
  relationship — brands are bought, sold, and licensed — and embedding a relationship in a
  permanent identifier turns every ownership change into a false statement
  ([spec §5.5.1](../spec/05-identity-ladders.md)). It travels as a claim between the brand
  atom and the company atom.
- A brand and its thousands of same-name outlets sit at different abstraction levels and
  must never be merged by the equivalence layer
  ([spec §5.5](../spec/05-identity-ladders.md)).
