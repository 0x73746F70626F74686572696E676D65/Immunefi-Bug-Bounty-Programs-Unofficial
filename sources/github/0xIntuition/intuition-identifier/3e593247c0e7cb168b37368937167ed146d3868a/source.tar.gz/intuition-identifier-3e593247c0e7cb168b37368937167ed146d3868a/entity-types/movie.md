# `movie` — Movie

| | |
| :-- | :-- |
| **Slug** | `movie` |
| **Identifies** | A film at the **work** level — releases, cuts, and encodings are manifestations ([`video-object`](./video-object.md)) or equivalence-layer concerns. |
| **gen1 namespace** | `movie` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T2 | [`wd`](../schemes/wd.md) from `sameAs` | A Wikidata QID is known — e.g. `int:wd:Q25188` for *Inception* |
| 2 | A | T2 | [`tmdb`](../schemes/tmdb.md) from `sameAs` | A TMDB movie ID is known |
| 3 | A | T3 | [`imdb`](../schemes/imdb.md) from `sameAs` | An IMDb title ID is known |
| 4 | C | — | [`gen1`](../schemes/gen1.md)`{name, yearPublished}` (tag `r4`) | Title and release year are present |
| 5 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r5`) | Only a title is present |

## Notes

- The registry order is the openness rule of
  [spec §3.3.1](../spec/03-identity-classes.md) at work: Wikidata (CC0, and
  cross-referencing the others) ranks first, TMDB (community registry with daily open ID
  exports) second, and IMDb — accurate but Amazon-owned and closed — last among the
  registries. T3 identifiers remain valuable as corroborating evidence; they are just not
  the preferred anchor.
- `yearPublished` is the **year component only** of `datePublished` ("2010-07-16" →
  "2010"). The year is in the recipe because remakes are pervasive — *Dune* (1984) and
  *Dune* (2021) are different films, not formatting variants of one title. Full dates
  would be too precise: sources disagree on premiere vs release day, and the year is the
  stable part. The worked derivation of rung `r4` is in
  [spec §6.5](../spec/06-gen1.md): `int:gen1:movie:r4:fb681afe7d438cad73ae90a70f1cc55a`.
- The director does not appear in any recipe — a related entity's name never enters an
  identifier ([spec §5.6](../spec/05-identity-ladders.md)); direction is a claim.

## Open proposals

- An [`eidr`](../schemes/eidr.md) rung. EIDR is the film industry's own DOI-based T1
  registry and belongs above `tmdb` on this ladder; it is in the scheme registry but not
  yet a rung. Adding it is a MINOR ladder change — exactly the kind of proposal
  [spec §9](../spec/09-registry-governance.md) invites.
