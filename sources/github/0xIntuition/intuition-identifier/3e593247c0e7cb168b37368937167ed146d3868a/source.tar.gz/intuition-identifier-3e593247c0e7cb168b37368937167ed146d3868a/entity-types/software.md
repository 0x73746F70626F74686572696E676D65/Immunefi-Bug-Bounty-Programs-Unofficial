# `software` — Software

| | |
| :-- | :-- |
| **Slug** | `software` |
| **Identifies** | The package or project, **version-free** — the library as an ongoing thing, not any release of it. End-user applications are [`software-application`](./software-application.md). |
| **gen1 namespace** | `software` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`purl`](../schemes/purl.md) from the `packageUrl` field | A package URL is known — e.g. `pkg:npm/lodash` |
| 2 | B | — | [`url`](../schemes/url.md) from the `codeRepository` field | A repository URL is known |
| 3 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r3`) | Only a name is present |

## Notes

- A `purl` (package URL) is an open specification whose ecosystem + name pair is a true
  natural key: npm enforces that exactly one package is `lodash`. Canonical `purl`
  values here are **version-stripped** — the abstraction level is the package, and
  versions relate to it as claims ([spec §5.5](../spec/05-identity-ladders.md)).
- The repository URL ranks below `purl` because repositories **migrate**: projects move
  hosts, organizations rename, forks confuse. It is a manifestation-style fallback, with
  migrations absorbed by the equivalence layer ([spec §8](../spec/08-equivalence.md)).
- Rung 3 merges every same-named project across ecosystems — the honest Class C floor.
  The maintainer and owning organization are related entities and travel as claims
  ([spec §5.6](../spec/05-identity-ladders.md)).
