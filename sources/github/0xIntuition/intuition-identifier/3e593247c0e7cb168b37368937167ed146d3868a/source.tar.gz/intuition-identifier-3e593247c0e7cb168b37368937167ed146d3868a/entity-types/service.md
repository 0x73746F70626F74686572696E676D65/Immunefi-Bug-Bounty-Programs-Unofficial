# `service` — Service

| | |
| :-- | :-- |
| **Slug** | `service` |
| **Identifies** | A service offering — the service as a marketed thing, distinct from the company providing it. |
| **gen1 namespace** | `service` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`url`](../schemes/url.md) from `sameAs` | An official page is known |
| 2 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r2`) | A name is present |

## Notes

- Services have no registry; the official page is the strongest available anchor.
- The **provider** is deliberately excluded from the recipe: a provider is a related
  entity, its name would fork the service's identity on every naming variant, and
  provider relationships change while identifiers cannot
  ([spec §5.6](../spec/05-identity-ladders.md)). Provider linkage is a claim from the
  service atom to the [`company`](./company.md) atom.
- Rung 2 merges same-name offerings across providers — the honest Class C report
  ([spec §6.1](../spec/06-gen1.md)), superseded when a canonical URL is learned.
