# `mobile-application` — Mobile application

| | |
| :-- | :-- |
| **Slug** | `mobile-application` |
| **Identifies** | A mobile app **per store ecosystem** — the iOS app and the Android app of one product are two atoms, related by claims. |
| **gen1 namespace** | `mobile-application` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`appid`](../schemes/appid.md) — lowercased `operatingSystem` + `:` + `bundleId` | The OS and the bundle ID / package name are known |
| 2 | B | — | [`url`](../schemes/url.md) from the `downloadUrl` field | A store listing URL is known |
| 3 | C | — | [`gen1`](../schemes/gen1.md)`{name, operatingSystem}` (tag `r3`) | Name and OS are present |

## Notes

- Bundle IDs and package names are **true natural keys**: the store enforces that exactly
  one app is `com.spotify.music`, and the ID is immutable for the app's life. The
  platform scope inside the value is legitimate — a bundle ID means nothing outside its
  store ecosystem, passing the scoped-identifier litmus test
  ([spec §5.5.1](../spec/05-identity-ladders.md)).
- The store URL is a weaker fallback (regional variants, listing churn), but the bundle
  ID is usually extractable from it at enrichment, upgrading future mints to rung 1.
- The rung 3 recipe includes `operatingSystem` because the type's abstraction level is
  per-ecosystem: "Spotify on iOS" and "Spotify on Android" must not merge at the hash
  level either. The cross-platform product, if modeled, is a
  [`software-application`](./software-application.md) atom linked by claims.
- The publisher is a related entity and stays out of the recipes
  ([spec §5.6](../spec/05-identity-ladders.md)).
