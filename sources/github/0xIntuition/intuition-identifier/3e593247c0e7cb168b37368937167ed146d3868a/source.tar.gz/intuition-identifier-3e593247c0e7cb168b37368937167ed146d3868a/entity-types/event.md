# `event` — Event

| | |
| :-- | :-- |
| **Slug** | `event` |
| **Identifies** | An event occurrence — one happening at one time, as opposed to the venue where it happens or the organization that runs it. |
| **gen1 namespace** | `event` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T2 | [`wd`](../schemes/wd.md) from `sameAs` | A QID is known — recurring or notable events |
| 2 | B | — | [`url`](../schemes/url.md) from `sameAs` | An official or ticketing page is known |
| 3 | C | — | [`gen1`](../schemes/gen1.md)`{name, startDate}` (tag `r3`) | Name and start date are present |
| 4 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r4`) | Only a name is present |

## Notes

- `startDate` earns its place in the rung 3 recipe because it is an **intrinsic stable
  scalar** of the occurrence itself — the same conference in different years is different
  events, not formatting variants of one name.
- The venue's name is deliberately excluded: a venue is a related entity, and its name in
  the hash would fork the event's identity on every naming variant
  ([spec §5.6](../spec/05-identity-ladders.md)). Venue linkage is a claim against the
  location atom.
- Rung 4 merges all same-name occurrences into one name-level atom — weak by design, and
  labeled as such by its Class C identifier ([spec §6.1](../spec/06-gen1.md)).
