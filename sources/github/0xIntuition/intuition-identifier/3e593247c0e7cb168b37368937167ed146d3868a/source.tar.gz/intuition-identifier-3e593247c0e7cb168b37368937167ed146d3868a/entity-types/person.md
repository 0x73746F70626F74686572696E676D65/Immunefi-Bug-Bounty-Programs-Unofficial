# `person` — Person

| | |
| :-- | :-- |
| **Slug** | `person` |
| **Identifies** | An individual human being — the person themselves, not a persona, account, or record about them. Accounts are [`social-media-account`](./social-media-account.md) atoms. |
| **gen1 namespace** | `person` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T1 | [`isni`](../schemes/isni.md) from `sameAs` | An ISNI is known — ISNI covers public identities, including pen names |
| 2 | A | T2 | [`wd`](../schemes/wd.md) from `sameAs` | A Wikidata QID is known |
| 3 | A | T2 | [`olid`](../schemes/olid.md) from `sameAs` | An OpenLibrary author ID (`OL…A`) is known |
| 4 | C | — | [`gen1`](../schemes/gen1.md)`{givenName, familyName}` (tag `r4`) | Both name parts are present |
| 5 | C | — | [`gen1`](../schemes/gen1.md)`{givenName}` (tag `r5`) | Only a single name is present — mononyms |

## Notes

- Rung 4 is **ambiguous by construction**: it merges every "John Smith" into one
  name-level atom. That is an honest report of what was known, not a defect
  ([spec §6.1](../spec/06-gen1.md)). Surfaces should flag Class C person atoms as
  unverified identity, and enrichment should upgrade aggressively to rungs 1–3.
- Rung 5 exists because mononyms are real: Rihanna, Sukarno, Teller. It fires only when
  `familyName` is genuinely absent — `gen1` rungs are all-or-nothing
  ([spec §5.2](../spec/05-identity-ladders.md)).
- The `olid` value carries its entity type in the identifier itself (the `A` suffix means
  author), so a person atom and a book atom can never collide through OpenLibrary IDs.
- **A person's date of birth never enters the identity hash**, even though it would
  disambiguate effectively. Personal data used solely as a disambiguator is prohibited
  ([spec §5.6](../spec/05-identity-ladders.md)); the resulting ambiguity is resolved by the
  equivalence layer ([spec §8](../spec/08-equivalence.md)) instead of by an immutable
  public record.
- Relationships — employer, works authored, accounts held — never enter the hash. They are
  claims against the related entity's own atom ([spec §5.6](../spec/05-identity-ladders.md)).
