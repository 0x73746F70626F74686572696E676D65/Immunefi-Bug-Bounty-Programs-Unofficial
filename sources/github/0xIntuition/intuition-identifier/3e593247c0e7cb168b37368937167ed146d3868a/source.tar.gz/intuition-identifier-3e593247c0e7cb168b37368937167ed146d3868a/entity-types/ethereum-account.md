# `ethereum-account` — Ethereum account

| | |
| :-- | :-- |
| **Slug** | `ethereum-account` |
| **Identifies** | An externally owned account — the **keypair**, which is one identity across every EVM chain. |
| **gen1 namespace** | — (no gen1 rung) |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`caip10`](../schemes/caip10.md) — `eip155:1:` + lowercase `address` | An address is present |

## Notes

- The chain reference is **pinned to `eip155:1`** (Ethereum mainnet), whatever chain the
  address was observed on. An EOA is one keypair: the same address controls the same
  account on mainnet, Base, Arbitrum, and every other EVM chain, so per-chain
  identifiers would mint many atoms for one identity. Mainnet is the fixed canonical
  home. Contracts and tokens, which genuinely differ per chain, keep real chain scoping —
  see [`ethereum-smart-contract`](./ethereum-smart-contract.md) and
  [`ethereum-erc20`](./ethereum-erc20.md).
- The address is **lowercased**: EIP-55 mixed casing is a checksum presentation, not
  identity.

  ```text
  int:caip10:eip155:1:0xd8da6bf26964af9d7eed9e03e53415d37aa96045
  ```

- ENS names are never identity: they are transferable and expirable, so `vitalik.eth`
  naming this address is a claim, resolved by enrichment before derivation.
