# `comment` — Comment

| | |
| :-- | :-- |
| **Slug** | `comment` |
| **Identifies** | One comment on one subject — a relational entity, like [`review`](./review.md), whose identity is a function of what it is attached to. |
| **gen1 namespace** | — (no gen1 rung) |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`url`](../schemes/url.md) from `sameAs` | The comment's permalink is known |

## Notes

- A comment is not a named thing; it is a piece of text attached to a subject on a
  platform. The permalink is the only observer-independent handle available today, so
  the ladder has one rung and a comment without a URL is honestly unidentifiable
  ([spec §5.2](../spec/05-identity-ladders.md)).
- The subject and the commenter are related entities and stay out of any identifier
  ([spec §5.6](../spec/05-identity-ladders.md)); those facts travel as claims.

## Open proposals

- As with [`review`](./review.md), a `gen1` recipe keyed on the subject's IID plus a
  content hash and creation date — `gen1{aboutIid, textHash, dateCreated}` — would cover
  permalink-less comments. It awaits IID-typed reference fields on the entity type.
  Contributions welcome; see the [index](./README.md#proposing-a-new-entity-type-or-ladder-change).
