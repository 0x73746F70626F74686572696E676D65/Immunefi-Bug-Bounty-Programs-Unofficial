# `video-object` — Video object

| | |
| :-- | :-- |
| **Slug** | `video-object` |
| **Identifies** | A video file or hosted video, byte-identity first — the manifestation level, not the film-as-work ([`movie`](./movie.md)). |
| **gen1 namespace** | `video-object` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`hash`](../schemes/hash.md) from the `contentHash` field | A digest of the content bytes is known |
| 2 | B | — | [`url`](../schemes/url.md) from the `contentUrl` field | A direct content URL is known |
| 3 | B | — | [`url`](../schemes/url.md) from `sameAs` | A platform watch page is known |
| 4 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r3`) | Only a title is present |

## Notes

- As with [`image`](./image.md), the content digest is the strongest possible anchor —
  intrinsic, registry-free, and offline-verifiable. Platform URLs are **manifestation
  fallbacks**: the same video is re-uploaded, mirrored, and re-encoded across platforms,
  and each manifestation atom joins the others through equivalence
  ([spec §8](../spec/08-equivalence.md)).
- `contentUrl` (the file) ranks above a `sameAs` watch page (the page about the file):
  the more direct handle on the bytes wins.
- A video object is not the creative work it manifests. A trailer upload, a full-film
  rip, and a clip are three video objects that all *relate* to one `movie` atom — those
  relations are claims, and the levels are never merged
  ([spec §5.5](../spec/05-identity-ladders.md)).
