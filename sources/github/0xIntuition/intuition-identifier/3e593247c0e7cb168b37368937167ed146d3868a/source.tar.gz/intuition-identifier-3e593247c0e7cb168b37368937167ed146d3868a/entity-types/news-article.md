# `news-article` — News article

| | |
| :-- | :-- |
| **Slug** | `news-article` |
| **Identifies** | A news story **as published** — URL-anchored. The canonical URL is the identity of a published news article. |
| **gen1 namespace** | `news-article` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`url`](../schemes/url.md) from the `url` field | The article's URL is present |
| 2 | B | — | [`url`](../schemes/url.md) from `sameAs` | A canonical URL is known via `sameAs` |
| 3 | C | — | [`gen1`](../schemes/gen1.md)`{headline, datePublished}` (tag `r2`) | Headline and publication date are present |
| 4 | C | — | [`gen1`](../schemes/gen1.md)`{headline}` (tag `r3`) | Only a headline is present |

## Notes

- Unlike [`article`](./article.md), no DOI rung: news stories are not DOI-registered.
  The publisher's canonical URL is the strongest identity a news article has.
- `datePublished` in the rung 3 recipe is an intrinsic stable scalar of the publication
  event, and it separates recurring headlines ("Markets fall on inflation fears") that a
  bare headline hash would merge.
- The publisher's name is a related entity's name and stays out of the recipe
  ([spec §5.6](../spec/05-identity-ladders.md)); publisher linkage is a claim against the
  company atom.
- Canonical-URL discovery (`rel=canonical`, redirect resolution) is an enrichment step
  performed **before** derivation, never inside canonicalization — derivation must stay
  offline-deterministic ([spec §5.6](../spec/05-identity-ladders.md)).
