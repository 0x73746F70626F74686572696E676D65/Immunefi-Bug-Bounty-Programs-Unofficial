# `tv-series` — TV series

| | |
| :-- | :-- |
| **Slug** | `tv-series` |
| **Identifies** | The series as a whole. Seasons and episodes are unmodeled levels — facts about them attach to the series atom as claims until types for those levels exist. |
| **gen1 namespace** | `tv-series` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T2 | [`wd`](../schemes/wd.md) from `sameAs` | A Wikidata QID is known |
| 2 | A | T2 | [`tmdb`](../schemes/tmdb.md) from `sameAs` | A TMDB TV ID is known |
| 3 | A | T3 | [`imdb`](../schemes/imdb.md) from `sameAs` | An IMDb title ID is known |
| 4 | C | — | [`gen1`](../schemes/gen1.md)`{name, startYear}` (tag `r4`) | Title and first-air year are present |
| 5 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r5`) | Only a title is present |

## Notes

- The registry ordering mirrors [`movie`](./movie.md): open data first
  ([spec §3.3.1](../spec/03-identity-classes.md)) — Wikidata, then TMDB, with the closed
  IMDb registry last despite its coverage.
- `startYear` is the year component of `startDate` ("2008-01-20" → "2008"). Title reuse
  across eras is common — *Battlestar Galactica* (1978) and (2004) are different series —
  and the first-air year is the stable disambiguator that survives source disagreement
  about exact premiere dates.
- The network and the creators are related entities and stay out of the recipes
  ([spec §5.6](../spec/05-identity-ladders.md)).

## Open proposals

- An [`eidr`](../schemes/eidr.md) rung, as for [`movie`](./movie.md) — EIDR registers
  series (and episodes) in a T1 open registry and belongs above `tmdb` here. Proposals
  welcome per [spec §9](../spec/09-registry-governance.md).
