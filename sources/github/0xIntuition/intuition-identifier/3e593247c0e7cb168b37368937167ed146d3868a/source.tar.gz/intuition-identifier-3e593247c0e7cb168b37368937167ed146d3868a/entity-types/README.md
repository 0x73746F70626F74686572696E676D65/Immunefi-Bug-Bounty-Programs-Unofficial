# Entity-type registry

Every entity type in the registry declares exactly one **identity ladder**: an ordered
list of identifier options, strongest first, that answers *given whatever facts we happen
to have about this thing, which identifier should it get?* Derivation mints with the
highest rung whose complete field set is available and valid, and Class C `gen1` hashes
are the honest floor when no registry or natural key applies. The normative rules —
selection, abstraction levels, and what ladders must never do — are in
[spec §5](../spec/05-identity-ladders.md).

Each document below records the ratified ladder, the abstraction level the type
identifies, and the reasoning behind the order and the deliberate exclusions.

## Registry

### Entity

| Type | Identifies | Strongest rung | gen1 fallback |
| :-- | :-- | :-- | :-: |
| [`person`](./person.md) | An individual human | [`isni`](../schemes/isni.md) | yes |
| [`company`](./company.md) | A legal entity | [`wd`](../schemes/wd.md) | yes |
| [`brand`](./brand.md) | A brand as a concept | [`wd`](../schemes/wd.md) | yes |
| [`local-business`](./local-business.md) | One business at one place | [`wd`](../schemes/wd.md) | yes |
| [`location`](./location.md) | A named place or coordinate point | [`wd`](../schemes/wd.md) | yes |
| [`event`](./event.md) | An event occurrence | [`wd`](../schemes/wd.md) | yes |
| [`thing`](./thing.md) | Anything not covered elsewhere | [`wd`](../schemes/wd.md) | yes |

### Creative work

| Type | Identifies | Strongest rung | gen1 fallback |
| :-- | :-- | :-- | :-: |
| [`book`](./book.md) | The work (ISBN names editions) | [`isbn`](../schemes/isbn.md) | yes |
| [`article`](./article.md) | An article | [`doi`](../schemes/doi.md) | yes |
| [`news-article`](./news-article.md) | A news story as published | [`url`](../schemes/url.md) | yes |
| [`dataset`](./dataset.md) | A dataset | [`doi`](../schemes/doi.md) | yes |
| [`defined-term`](./defined-term.md) | A term within a term set | [`termset`](../schemes/termset.md) | yes |
| [`review`](./review.md) | One review of one subject | [`url`](../schemes/url.md) | no |
| [`comment`](./comment.md) | One comment on one subject | [`url`](../schemes/url.md) | no |

### Media

| Type | Identifies | Strongest rung | gen1 fallback |
| :-- | :-- | :-- | :-: |
| [`image`](./image.md) | An image, byte-identity first | [`hash`](../schemes/hash.md) | yes |
| [`video-object`](./video-object.md) | A video, byte-identity first | [`hash`](../schemes/hash.md) | yes |
| [`movie`](./movie.md) | A film at the work level | [`wd`](../schemes/wd.md) | yes |
| [`tv-series`](./tv-series.md) | The series as a whole | [`wd`](../schemes/wd.md) | yes |
| [`music-group`](./music-group.md) | An artist/band public identity | [`isni`](../schemes/isni.md) | yes |
| [`music-album`](./music-album.md) | The release-group (album as work) | [`mbid`](../schemes/mbid.md) | yes |
| [`music-recording`](./music-recording.md) | The recording (ISRC level) | [`isrc`](../schemes/isrc.md) | yes |
| [`podcast-series`](./podcast-series.md) | The show, at the feed level | [`podcastguid`](../schemes/podcastguid.md) | yes |
| [`podcast-episode`](./podcast-episode.md) | One feed item (manifestation) | [`rssitem`](../schemes/rssitem.md) | yes |

### Product

| Type | Identifies | Strongest rung | gen1 fallback |
| :-- | :-- | :-- | :-: |
| [`product`](./product.md) | The product model, not units | [`gtin`](../schemes/gtin.md) | yes |
| [`service`](./service.md) | A service offering | [`url`](../schemes/url.md) | yes |

### Web

| Type | Identifies | Strongest rung | gen1 fallback |
| :-- | :-- | :-- | :-: |
| [`web-page`](./web-page.md) | A page at a canonical URL | [`url`](../schemes/url.md) | no |
| [`web-site`](./web-site.md) | A site, origin level | [`url`](../schemes/url.md) | no |
| [`job-posting`](./job-posting.md) | One posting | [`url`](../schemes/url.md) | yes |
| [`social-media-account`](./social-media-account.md) | An account on a platform | [`acct`](../schemes/acct.md) | no |
| [`social-media-posting`](./social-media-posting.md) | One post | [`url`](../schemes/url.md) | yes |

### Blockchain

| Type | Identifies | Strongest rung | gen1 fallback |
| :-- | :-- | :-- | :-: |
| [`ethereum-account`](./ethereum-account.md) | An EOA/keypair, pinned to `eip155:1` | [`caip10`](../schemes/caip10.md) | no |
| [`ethereum-erc20`](./ethereum-erc20.md) | A token asset on a chain | [`caip19`](../schemes/caip19.md) | no |
| [`ethereum-smart-contract`](./ethereum-smart-contract.md) | A deployed contract | [`caip10`](../schemes/caip10.md) | no |

### Software

| Type | Identifies | Strongest rung | gen1 fallback |
| :-- | :-- | :-- | :-: |
| [`software`](./software.md) | The package/project, version-free | [`purl`](../schemes/purl.md) | yes |
| [`software-application`](./software-application.md) | An end-user application | [`url`](../schemes/url.md) | yes |
| [`mobile-application`](./mobile-application.md) | A mobile app per store ecosystem | [`appid`](../schemes/appid.md) | yes |

## Withdrawn

| Type | Status |
| :-- | :-- |
| `aggregate-rating` | Withdrawn from identifier scope |

An aggregate rating ("4.6 stars from 2,381 reviews on platform X") has no identity of its
own: it is a *statement about* a subject, made by a provider, with values that change
daily. Modeling it as an entity forced the question "what identifies a rating?" — a
question with no good answer, because every candidate identifier was really the identity
of the subject, the provider, or the moment of observation. It was therefore **remodeled
as a claim**: subject —has aggregate rating→ provider atom, with the numeric values as
claim metadata. The identity problem dissolves rather than being solved, which is the
right outcome — the graph's native subject–predicate–object primitive was the correct
home all along. Individual [`review`](./review.md) atoms remain in scope.

## What this registry is not

This registry serves the *identity* layer: entity types namespace `gen1` hashes, declare
abstraction levels, and order ladders. It is **not a mandated ontology for consumers**.
A backend reading the graph may interpret atoms through schema.org, through this
registry's slugs, or through a type system of its own — and two backends may interpret
the same atom differently while still converging on it at the identity layer
([spec §7.7](../spec/07-representation-profiles.md)). Choosing an interpretation engine,
and deciding what an atom *means* inside your application, remains a developer decision
this specification deliberately leaves open.

## Proposing a new entity type or ladder change

Ladders are meant to improve. Several documents above carry an **Open proposals** section
naming known candidate improvements — an `eidr` rung for film and television, `purl` and
`appid` rungs for applications, subject-keyed `gen1` recipes for reviews and comments —
and each is an invitation to contribute.

- Process and requirements: [CONTRIBUTING](../CONTRIBUTING.md) and
  [spec §9 — registry governance](../spec/09-registry-governance.md).
- **Reordering rungs or adding a rung is a MINOR version change and never invalidates an
  existing identifier** ([spec §1.5.1](../spec/01-conformance.md)). Existing atoms keep
  their identifiers; new mints simply prefer the improved ladder, and the equivalence
  layer joins old and new ([spec §8](../spec/08-equivalence.md)).
- `gen1` recipe tags are **frozen at creation** ([spec §6.4](../spec/06-gen1.md)): a new
  recipe takes a fresh tag wherever it lands in the order, existing tags are never
  renumbered or reused, and tags in a ladder are therefore not positions and need not be
  contiguous.
