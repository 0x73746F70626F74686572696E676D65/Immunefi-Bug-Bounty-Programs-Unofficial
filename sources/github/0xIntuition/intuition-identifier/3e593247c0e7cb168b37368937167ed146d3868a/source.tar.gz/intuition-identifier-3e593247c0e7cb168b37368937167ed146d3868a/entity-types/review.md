# `review` — Review

| | |
| :-- | :-- |
| **Slug** | `review` |
| **Identifies** | One review of one subject — a relational entity whose identity is a function of what it is about, not a name it carries. |
| **gen1 namespace** | — (no gen1 rung) |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`url`](../schemes/url.md) from `sameAs` | The review's permalink is known |

## Notes

- A review has no standalone identity: it is (subject × author × platform), and the only
  observer-independent handle it carries today is its permalink. Hence the single-rung
  ladder — a review without a URL cannot currently be identified, and derivation
  legitimately returns nothing ([spec §5.2](../spec/05-identity-ladders.md)).
- The reviewed item and the review's author are related entities. Neither their names nor
  any rating value enters an identifier
  ([spec §5.6](../spec/05-identity-ladders.md)); they travel as claims. Aggregate ratings
  went further — the whole entity type was withdrawn and remodeled as a claim (see the
  [registry index](./README.md#withdrawn)).

## Open proposals

- A `gen1` recipe keyed on the **subject's IID** plus a hash of the review body —
  `gen1{itemReviewedIid, reviewBodyHash}` — would identify reviews without permalinks
  deterministically. It awaits IID-typed reference fields on the entity type, so that the
  subject enters the recipe as a resolved identifier rather than as a free-text name.
  Contributions welcome; see the [index](./README.md#proposing-a-new-entity-type-or-ladder-change).
