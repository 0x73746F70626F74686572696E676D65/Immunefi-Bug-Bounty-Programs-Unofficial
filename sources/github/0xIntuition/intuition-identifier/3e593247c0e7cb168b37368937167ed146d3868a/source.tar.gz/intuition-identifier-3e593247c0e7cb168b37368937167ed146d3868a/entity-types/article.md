# `article` — Article

| | |
| :-- | :-- |
| **Slug** | `article` |
| **Identifies** | An article — a self-contained written piece, academic or otherwise. News stories anchored to a publisher URL are the more specific [`news-article`](./news-article.md). |
| **gen1 namespace** | `article` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T1 | [`doi`](../schemes/doi.md) from the `url` field | The URL is a DOI (a `doi.org` link or DOI string) |
| 2 | B | — | [`url`](../schemes/url.md) from the `url` field | Any canonical URL is present |
| 3 | C | — | [`gen1`](../schemes/gen1.md)`{headline}` (tag `r3`) | A headline is present |

## Notes

- Rungs 1 and 2 read the **same field**. If the article's URL canonicalizes as a DOI,
  the stronger registered identifier is used; otherwise the same value falls through to
  the plain URL rung. This is the selection algorithm working as designed — an invalid
  or inapplicable value skips the rung, it never fails the derivation
  ([spec §5.2](../spec/05-identity-ladders.md)).
- Academic and formally published articles are heavily DOI-registered, which gives this
  type a T1 anchor whenever one exists.
- The `gen1` recipe hashes the headline only. The author and the publication are related
  entities and travel as claims ([spec §5.6](../spec/05-identity-ladders.md)).
