# `image` — Image

| | |
| :-- | :-- |
| **Slug** | `image` |
| **Identifies** | An image, byte-identity first: the content itself when a digest is available, falling back to where it is hosted. |
| **gen1 namespace** | `image` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`hash`](../schemes/hash.md) from the `contentHash` field | A digest of the content bytes is known |
| 2 | B | — | [`url`](../schemes/url.md) from the `url` field | A hosted URL is known |
| 3 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r3`) | Only a name is present |

## Notes

- A content digest is the perfect natural key for media: change one byte and it is
  provably a different file ([spec §3.2](../spec/03-identity-classes.md)). It is
  registry-free, offline-verifiable, and immune to hosting churn.
- The URL rung is a **manifestation fallback**, and deliberately second: CDN URLs churn,
  the same image lives at many addresses, and the same address can serve different bytes
  over time. Atoms minted from different manifestations of one image are joined by the
  equivalence layer ([spec §8](../spec/08-equivalence.md)).
- Rung 3 is a last resort — a name identifies almost nothing about an image — and its
  Class C identifier says so.
