# `location` — Location

| | |
| :-- | :-- |
| **Slug** | `location` |
| **Identifies** | A named place — a city, landmark, region — or a pure coordinate point. Not a business operating at a place; that is [`local-business`](./local-business.md). |
| **gen1 namespace** | `location` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T2 | [`wd`](../schemes/wd.md) from `sameAs` | A Wikidata QID is known |
| 2 | B | — | [`geo`](../schemes/geo.md) — geohash-8 of `latitude`/`longitude` | Coordinates are present |
| 3 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r3`) | A name is present |

## Notes

- Named places are exactly Wikidata's strength — cities, landmarks, and regions have
  excellent QID coverage, so rung 1 fires far more often here than for most types.
- Rung 2 is for **pure coordinate points**: a geohash-8 cell (≈38 m × 19 m) is an
  intrinsic natural key for a point on the Earth's surface — no registry assigns it, it
  falls out of where the point is ([spec §3.2](../spec/03-identity-classes.md)).
- Note the precision difference from `local-business`: a location point uses geohash-8,
  while a business venue's recipe uses a coarser geohash-7 cell to absorb measurement
  jitter across providers. A point is a point; a venue is a measurement.
