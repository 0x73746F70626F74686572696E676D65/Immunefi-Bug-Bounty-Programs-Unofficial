# `book` — Book

| | |
| :-- | :-- |
| **Slug** | `book` |
| **Identifies** | The **work** — the book as an abstract creative work. ISBN identifies editions; edition atoms attach to the work cluster through equivalence ([spec §5.5](../spec/05-identity-ladders.md)). |
| **gen1 namespace** | `book` |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | A | T1 | [`isbn`](../schemes/isbn.md) from the `isbn` field | An ISBN is present and its check digit validates |
| 2 | A | T2 | [`olid`](../schemes/olid.md) from `sameAs` | An OpenLibrary work or edition ID is known |
| 3 | A | T2 | [`wd`](../schemes/wd.md) from `sameAs` | A Wikidata QID is known |
| 4 | C | — | [`gen1`](../schemes/gen1.md)`{name}` (tag `r3`) | A title is present |

## Notes

- The abstraction stack is work → edition → physical copy, and this type identifies the
  **work**. An ISBN names one edition — `int:isbn:9780684832722` is a specific published
  form — so the policy is: mint the work atom with the best available edition ISBN as its
  primary identifier, and attach other editions to the same work cluster via equivalence
  claims ([spec §8](../spec/08-equivalence.md)).
- The author is deliberately **not** in the `gen1` recipe. Author name structure varies
  wildly between sources ("Davidson, J.D." vs "James Dale Davidson"), and any variant
  would fork the book's identifier. Authorship is a relationship, expressed as a claim
  from the book atom to the person atom ([spec §5.6](../spec/05-identity-ladders.md)).
  The cost is that rung 4 merges same-title books — an honest Class C ambiguity, resolved
  by climbing the ladder as facts improve.
- Pre-1970 books have no ISBN and fall through to `olid`, `wd`, or the title hash — see
  the [`isbn` scheme notes](../schemes/isbn.md).
