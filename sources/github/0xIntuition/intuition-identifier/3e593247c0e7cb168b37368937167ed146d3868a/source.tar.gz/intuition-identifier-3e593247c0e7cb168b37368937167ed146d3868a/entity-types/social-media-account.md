# `social-media-account` — Social media account

| | |
| :-- | :-- |
| **Slug** | `social-media-account` |
| **Identifies** | An account **on a platform**. The human or organization behind it is a separate atom ([`person`](./person.md), [`company`](./company.md)), linked by claims. |
| **gen1 namespace** | — (no gen1 rung) |
| **Status** | Ratified |

## Ladder

| Rung | Class | Tier | Identifier | Fires when |
| :-: | :-: | :-: | :-- | :-- |
| 1 | B | — | [`acct`](../schemes/acct.md) strong form — `platform` + `platformUserId` | The platform's immutable numeric/opaque user ID is known |
| 2 | B | — | [`acct`](../schemes/acct.md) weak form — `platform` + `@username` (casefolded) | Only the handle is known |

## Notes

- An account is scoped by its platform and passes the scoped-identifier litmus test
  ([spec §5.5.1](../spec/05-identity-ladders.md)): user ID `12345` means nothing outside
  the platform that assigned it, so the platform belongs inside the identifier.
- The two forms differ in what survives time. A **platform user ID** is immutable for the
  account's life. A **handle** can be renamed and — worse — recycled to a different
  account, so the weak form is a genuinely weaker statement: it identifies whoever holds
  the handle, not a fixed account. When both atoms exist for one account, equivalence
  joins them and the strong form anchors the cluster
  ([spec §8](../spec/08-equivalence.md)).
- The account is never the person. One person holds many accounts; one account can change
  hands. Account-to-owner linkage is a claim, and merging the levels would corrupt both
  ([spec §5.5](../spec/05-identity-ladders.md)).

## Open proposals

- The strong form requires `platformUserId` capture at intake — most scraped and
  user-submitted data carries only the handle. Widening user-ID capture (platform APIs
  expose it) is the single highest-leverage improvement for this type.
