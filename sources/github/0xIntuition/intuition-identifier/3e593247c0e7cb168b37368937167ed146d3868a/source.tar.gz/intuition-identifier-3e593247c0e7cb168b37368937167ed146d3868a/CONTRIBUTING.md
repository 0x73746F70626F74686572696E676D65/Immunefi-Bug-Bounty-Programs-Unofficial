# Contributing

Thank you for wanting to improve the Intuition Identifier specification. This document
covers the mechanics of contributing; [`GOVERNANCE.md`](./GOVERNANCE.md) covers how
decisions get made, and [spec §9](./spec/09-registry-governance.md) is the normative
change process the mechanics below implement.

## The ground rule

Before anything else, understand the one constraint that shapes every change here:

> **Ratified rules are frozen. Improvements are additive.**

Every identifier ever derived is a function of the rules that produced it, and in
Intuition's case the derived data is immutably on-chain. So a ratified scheme's
canonicalization is never edited — not even to fix a bug ([spec §9.3](./spec/09-registry-governance.md)).
A better rule ships as a new scheme or a new version (`gen1` → `gen2`), and the old and
new coexist, bridged by the equivalence layer.

This means contributions are never blocked by fear of breaking history. It also means
"small cleanup" PRs against ratified canonicalization rules will be declined regardless
of how correct they are — with an invitation to reframe them as a versioned successor.

## Ways to contribute

### 1. Report a spec defect

Ambiguity is a defect. If you implemented a rule and had to guess, or a test vector
disagrees with the prose, or two chapters seem to conflict — open an issue with the
**Spec defect** template. Include what you expected, what you found, and what you had to
decide alone. Editorial fixes that change no behaviour are PATCH releases and are merged
quickly.

### 2. Propose a new scheme

A scheme is a registered identifier namespace (`isbn`, `caip10`, …). To propose one:

1. Check [`schemes/README.md`](./schemes/README.md) — including the **rejected schemes**
   list, so settled questions are not relitigated ([spec §9.5](./spec/09-registry-governance.md)).
2. Confirm the candidate meets all three admission criteria
   ([spec §9.2](./spec/09-registry-governance.md)):
   - stable, never-recycled identifiers (or an intrinsic natural key);
   - no licensing terms restricting storage or republication of values;
   - a canonicalization implementable as a pure, offline function.
3. Copy [`schemes/TEMPLATE.md`](./schemes/TEMPLATE.md) to `schemes/<name>.md` and fill
   in every section — including **at least five test vectors, of which at least two are
   rejections**. Vectors are normative ([spec §1.4](./spec/01-conformance.md)).
4. State the ladder placement: which entity types gain a rung, and where, per the
   ordering rules of [spec §3.5](./spec/03-identity-classes.md).
5. Add the scheme to the index table in `schemes/README.md` and to
   [`registry.json`](./registry.json), and open a pull request.

Opening a **Scheme proposal** issue first, before writing the full document, is welcome
and often saves work — maintainers can flag admission problems early.

On merge, the scheme's rules are frozen and the registry version increments a MINOR
release.

### 3. Propose a ladder change or a new entity type

Ladders — which identifier an entity type prefers — are deliberately *not* frozen.
Reordering rungs or adding one is a MINOR change that only affects what a fresh mint
produces; it never invalidates an existing identifier
([spec §1.5.1](./spec/01-conformance.md)).

- For a change to an existing ladder, edit the relevant `entity-types/<slug>.md` and
  `registry.json`, and justify the new ordering against [spec §3.5](./spec/03-identity-classes.md).
- For a new entity type, add `entity-types/<slug>.md` declaring the slug, what it
  identifies (be precise about the abstraction level — [spec §5.5](./spec/05-identity-ladders.md)),
  and the full ladder.
- New `gen1` recipes receive the next unused tag for that entity type, and that tag is
  frozen forever ([spec §6.4](./spec/06-gen1.md)). Never renumber existing tags.
- Recipe fields must respect the exclusion rules of [spec §5.6](./spec/05-identity-ladders.md):
  no related-entity names, no observer-dependent values, no personal data as
  disambiguators, no network access.

Several ladders have documented gaps already waiting for an owner — see the **open
proposals** sections in [`entity-types/`](./entity-types/README.md).

### 4. Implement the spec

Independent implementations are the best review a specification can get. If you build
one — in any language, at any conformance class
([validator, canonicalizer, or deriver](./spec/01-conformance.md)) — open a PR adding it
to [`implementations.md`](./implementations.md). Every ambiguity you hit along the way
is a defect report we want.

## Pull request expectations

- One logical change per PR. A scheme proposal, a ladder change, and a typo fix are
  three PRs.
- Normative changes (anything with a MUST/SHOULD/MAY consequence) must say so in the PR
  description and state the version impact per [spec §1.5](./spec/01-conformance.md).
- Test vectors must be real and verified. If a reference implementation exists for the
  scheme, verify against it; if not, show your worked derivation in the PR. Never invent
  hash values.
- Keep the voice of the existing documents: plain, precise, and honest about
  limitations. A document that hides its weaknesses will be asked to state them.
- Update every place a change surfaces: the scheme or entity-type doc, the relevant
  README index, and `registry.json`.

## What happens to your PR

Review is public, on the PR. Maintainers check admission criteria, determinism, vector
correctness, and consistency with the rest of the specification. Ratification — the
point where rules freeze — is the merge of a normative PR plus a version tag, per
[`GOVERNANCE.md`](./GOVERNANCE.md).

## Licensing of contributions

By submitting a contribution you agree that it is licensed under the repository's
[MIT license](./LICENSE) and that you have the right to license it so. There is no CLA
to sign; the license itself is the whole agreement.

## Conduct

This project follows the [Contributor Covenant](./CODE_OF_CONDUCT.md). Arguments about
identifiers can get surprisingly heated; keep them about the identifiers.
