# `isrc` — International Standard Recording Code

| | |
| :-- | :-- |
| **Scheme** | `isrc` |
| **Identity class** | A — registered authority |
| **Openness tier** | T1 — open standard, format-validatable offline |
| **Scheme typing** | Unambiguous — always a recording |
| **Identifies** | One specific sound or music-video recording |
| **Authority** | IFPI (ISO 3901) |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

An ISRC names one **recording** — a specific fixed performance, as captured. It does not
name the underlying composition (that is [`iswc`](./iswc.md) territory), and it does not
name a release or product (a recording appears on many albums and singles under the same
ISRC; the physical or digital product carries a [`gtin`](./gtin.md)).

The [`music-recording`](../entity-types/music-recording.md) entity type identifies at
exactly this level, which is why `isrc` is its top rung.

## Admission criteria

1. **Stable, non-recycled identifiers** — ISRCs are embedded in masters and DDEX
   deliveries at assignment and are never reassigned; the system has operated under IFPI
   administration since 1989.
2. **No restrictive licensing** — ISRC values are open facts printed in credits and
   metadata feeds; storage and republication are unrestricted.
3. **Deterministic offline canonicalization** — the format is a fixed 12-character
   grammar, validatable with a single regular expression and no registry access.

## Canonical form

Twelve characters, uppercase, no separators: a two-letter country/allocation code, a
three-character alphanumeric registrant code, a two-digit year of reference, and a
five-digit designation code.

```text
int:isrc:USSM10007459
```

```abnf
isrc-value = 2 UPALPHA 3 upalnum 7 DIGIT
upalnum    = UPALPHA / DIGIT
```

## Canonicalization

1. Strip all hyphens, spaces, and dots from the input. Uppercase the result.
2. Accept the result if and only if it matches `^[A-Z]{2}[A-Z0-9]{3}[0-9]{7}$`.
3. Anything else is rejected.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `us-sm1-00-07459` | `USSM10007459` |
| `US-SM1-00-07459` | `USSM10007459` |
| `US SM1 00 07459` | `USSM10007459` |
| `USRC17607839` | `USRC17607839` |
| `USSM1000745` | **rejected** — 11 characters, not 12 |
| `1SSM10007459` | **rejected** — first two characters must be letters |
| `USSM1000745X` | **rejected** — designation block must be seven digits |

## Ladder placement

Rung 1 of [`music-recording`](../entity-types/music-recording.md), above
[`mbid`](./mbid.md): the ISRC identifies the recording itself, the more precise level
([spec §3.5](../spec/03-identity-classes.md), rule 3).

## Notes and limitations

- **P0 anchor-eligible** ([spec §7.2](../spec/07-representation-profiles.md)): Class A
  and unambiguously typed — an ISRC is always a recording.
- **No check digit.** Unlike ISBN or ISWC, a single-character typo yields another
  plausible ISRC. Offline validation is format-only; a well-formed wrong value passes.
- **The leading letters are allocation codes, not strictly countries.** Newer registrant
  allocations use codes like `QM` and `QZ` regardless of geography. The canonicalizer
  treats them as opaque.
- **Duplicate assignment happens in practice.** Distributors sometimes issue a new ISRC
  for an unchanged recording (remasters, re-deliveries). Two ISRCs for one recording is
  a cluster for the equivalence layer ([spec §8](../spec/08-equivalence.md)); the
  identifier layer does not detect it.
- The year field is two digits and rolls over; it is part of the opaque value, not
  parsed or interpreted.

## References

- ISO 3901:2019 — International Standard Recording Code
- [ISRC Handbook](https://isrc.ifpi.org/en/isrc-standard/handbook), IFPI
- [isrc.ifpi.org](https://isrc.ifpi.org/) — ISRC International Agency
