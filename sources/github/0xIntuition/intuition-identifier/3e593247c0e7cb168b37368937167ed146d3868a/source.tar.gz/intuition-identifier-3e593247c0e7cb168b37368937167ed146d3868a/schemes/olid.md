# `olid` — Open Library Identifier

| | |
| :-- | :-- |
| **Scheme** | `olid` |
| **Identity class** | A — registered authority |
| **Openness tier** | T2 — community registry, open data |
| **Scheme typing** | Unambiguous — the suffix letter carries the entity type |
| **Identifies** | One Open Library record: a work (`W`), an edition (`M`), or an author (`A`) |
| **Authority** | Open Library (Internet Archive) |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

An OLID names one **Open Library record**, and its final letter says which kind: `…W` a
work, `…M` an edition (a book as published — the [`isbn`](./isbn.md) level), `…A` an
author. The suffix does for `olid` what the type segment does for [`mbid`](./mbid.md):
it puts the entity type inside the value, so the scheme is unambiguously typed even
though it spans works, editions, and people.

Open Library matters to this registry chiefly for what ISBN cannot reach: works (not
editions) get first-class IDs, and pre-1970 books that predate ISBN have OLIDs.

## Admission criteria

1. **Stable, non-recycled identifiers** — OLIDs are assigned sequentially and never
   reassigned; merged records redirect rather than disappear. The registry has operated
   since 2008 under the Internet Archive.
2. **No restrictive licensing** — Open Library publishes full monthly data dumps openly;
   identifiers and records carry no storage or republication restrictions.
3. **Deterministic offline canonicalization** — URL stripping, case folding, and a shape
   check; no registry access.

## Canonical form

`OL`, one or more digits, and an uppercase type suffix: `W` (work), `M` (edition), or
`A` (author).

```text
int:olid:OL45804W
```

```abnf
olid-value = "OL" 1*DIGIT type
type       = %x57 / %x4D / %x41   ; "W" work / "M" edition / "A" author
```

## Canonicalization

1. Trim surrounding whitespace.
2. Strip one leading URL prefix matching
   `^https?://(www\.)?openlibrary\.org/(works|books|authors)/` (case-insensitive).
3. Strip everything from the first remaining `/` onward (Open Library URLs append a
   title slug after the ID).
4. Uppercase the result.
5. Accept only if the result matches `^OL[0-9]+[AMW]$`. Anything else is rejected.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `https://openlibrary.org/works/OL45804W` | `OL45804W` |
| `https://openlibrary.org/works/OL45804W/Fantastic_Mr_Fox` | `OL45804W` |
| `https://openlibrary.org/books/OL7353617M` | `OL7353617M` |
| `https://openlibrary.org/authors/OL23919A` | `OL23919A` |
| `ol45804w` | `OL45804W` |
| `OL45804X` | **rejected** — suffix must be `W`, `M`, or `A` |
| `OL45804` | **rejected** — missing the type suffix |

## Ladder placement

- Rung 2 of [`book`](../entity-types/book.md), below [`isbn`](./isbn.md) and above
  [`wd`](./wd.md) — work-level OLIDs cover books, including pre-ISBN ones, that no
  edition ISBN reaches.
- Rung 3 of [`person`](../entity-types/person.md) (author records, below
  [`isni`](./isni.md) and [`wd`](./wd.md)).

## Notes and limitations

- **P0 anchor-eligible** ([spec §7.2](../spec/07-representation-profiles.md)): Class A,
  and the suffix letter makes the scheme unambiguously typed.
- **The URL path segment and the suffix are not cross-checked.** The canonicalizer
  accepts any of the three path prefixes with any suffix; the suffix letter alone is
  authoritative for the type.
- **Community data quality.** Open Library records are bulk-imported and hand-edited;
  duplicate works and split authors are common. Duplicates are equivalence clusters
  ([spec §8](../spec/08-equivalence.md)); merged records' old OLIDs redirect and stay
  valid.
- **Work vs. edition mirrors `isbn`'s limitation in reverse.** An `…W` value names the
  work; each of its editions is a separate `…M` value (and usually an ISBN). Level
  bridging is the equivalence layer's job.

## References

- [Open Library developer documentation](https://openlibrary.org/developers/api), Internet Archive
- [Open Library data dumps](https://openlibrary.org/developers/dumps)
