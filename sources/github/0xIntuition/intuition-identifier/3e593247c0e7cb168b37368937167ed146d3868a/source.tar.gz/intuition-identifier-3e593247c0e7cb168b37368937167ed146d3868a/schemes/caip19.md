# `caip19` — Chain-agnostic asset identifier (CAIP-19)

| | |
| :-- | :-- |
| **Scheme** | `caip19` |
| **Identity class** | B — intrinsic natural key |
| **Openness tier** | — (Class B: no registry; offline-validatable by construction) |
| **Scheme typing** | Unambiguous — always an on-chain asset |
| **Identifies** | One on-chain asset: a token contract (or asset class) on one chain |
| **Authority** | The chain's own state — an asset is its chain plus its contract address, both fixed by deployment |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

A `caip19` value names one **asset on one chain**, in the CAIP-19 form
`<chain>/<asset-namespace>:<asset-reference>` — `eip155:1/erc20:0xa0b8…` is the USDC
token contract on Ethereum mainnet. The identified level is the asset *type*: the ERC-20
token as a class, or an NFT collection contract, not an individual balance or holder.

What it does *not* name: the deploying account or the contract-as-code (that is
[`caip10`](./caip10.md)), or the issuing organization (a separate atom). The same
"asset" bridged onto another chain is a different contract on a different chain and
therefore a different identifier — correctly so; bridged representations are joined by
the equivalence layer ([spec §8](../spec/08-equivalence.md)).

## Admission criteria

1. **Stable, non-recycled identifiers** — chain ID plus contract address is fixed at
   deployment and cannot be reassigned.
2. **No restrictive licensing** — asset identifiers are public chain data.
3. **Deterministic offline canonicalization** — shape validation and case folding
   require no chain access.

## Canonical form

```text
int:caip19:eip155:1/erc20:0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48
```

```abnf
caip19-value    = namespace ":" reference "/" asset-namespace ":" asset-reference
namespace       = 3*8( %x61-7A / DIGIT / "-" )
reference       = 1*32( ALPHA / DIGIT / "-" / "_" )
asset-namespace = 3*8( %x61-7A / DIGIT / "-" )     ; erc20, erc721, token, ...
asset-reference = 1*VCHAR                           ; namespace-defined
```

For `eip155` chains with a plain contract address as the asset reference, the address
is lowercase (EIP-55 casing is presentation, exactly as in [`caip10`](./caip10.md)).

## Canonicalization

1. Trim surrounding whitespace.
2. Match `^([-a-z0-9]{3,8}):([-_a-zA-Z0-9]{1,32})/([-a-z0-9]{3,8}):(.+)$`. Reject on
   failure.
3. **If the chain namespace is `eip155` and the asset reference is `0x` + exactly 40
   hex digits**: lowercase the asset reference.
4. **Otherwise**: pass the asset reference through byte-for-byte.
5. Reassemble `namespace:reference/asset-namespace:asset-reference`.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `eip155:1/erc20:0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48` | `eip155:1/erc20:0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48` |
| `eip155:1/erc20:0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48` | `eip155:1/erc20:0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48` |
| `eip155:1/erc721:0xBC4CA0EdA7647A8aB7C2061c2E118A18a936f13D` | `eip155:1/erc721:0xbc4ca0eda7647a8ab7c2061c2e118a18a936f13d` |
| `solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp/token:EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v` | `solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp/token:EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v` |
| `eip155:1:erc20:0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48` | **rejected** — colon where the chain/asset `/` separator belongs |
| `erc20:0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48` | **rejected** — no chain part |

## Ladder placement

Sole rung of [`ethereum-erc20`](../entity-types/ethereum-erc20.md). An ERC-20 token is
fully identified by its chain and contract address, so the ladder needs nothing else.

## Notes and limitations

- **Only bare 40-hex EVM asset references are case-folded.** A CAIP-19 value carrying a
  token-ID path (`…/erc721:0x…/1`) or any other non-plain-address reference passes
  through with its original casing, because folding an unknown grammar could corrupt
  it. Producers of such values are responsible for emitting a consistent form.
- **Non-EVM namespaces are shape-validated only**, as in `caip10`: a well-shaped but
  nonexistent asset reference is accepted. Existence checks require chain access, which
  canonicalization must not perform.
- **Bridged and wrapped assets fork, by design.** USDC on Ethereum and USDC on Base are
  different contracts on different chains and get different identifiers. "These are the
  same economic asset" is an attestable claim, not an identifier-layer fact.
- The value contains both colons and a slash; a parser splitting an IID on all colons
  will mis-handle it ([spec §2.3](../spec/02-grammar.md)).

## References

- [CAIP-19 — Asset Type and Asset ID Specification](https://chainagnostic.org/CAIPs/caip-19)
- [CAIP-2 — Blockchain ID Specification](https://chainagnostic.org/CAIPs/caip-2)
- [EIP-55 — Mixed-case checksum address encoding](https://eips.ethereum.org/EIPS/eip-55)
