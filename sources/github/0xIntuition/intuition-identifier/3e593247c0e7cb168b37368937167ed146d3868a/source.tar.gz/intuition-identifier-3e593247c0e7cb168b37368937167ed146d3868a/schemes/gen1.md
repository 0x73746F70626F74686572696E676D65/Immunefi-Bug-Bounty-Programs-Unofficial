# `gen1` — Derived identifier, generation 1

| | |
| :-- | :-- |
| **Scheme** | `gen1` |
| **Identity class** | C — derived |
| **Openness tier** | — (Class C: no registry; verifiable offline against its recipe fields) |
| **Scheme typing** | Unambiguous — the entity-type slug is in the value. **Never P0-eligible regardless** ([spec §7.2](../spec/07-representation-profiles.md)) |
| **Identifies** | The set of facts it was derived from — not, strictly, an entity |
| **Authority** | None. keccak-256 over NORM-1-normalized recipe fields, per [spec §6](../spec/06-gen1.md) |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

`gen1` is the fallback when no registry covers an entity and it has no natural key: a
hash over a small, frozen recipe of the entity's own attributes. Its limitation is the
first thing to know about it:

> **A `gen1` identifier does not identify an entity. It identifies the facts it was
> derived from.**

A `gen1` value derived from the name "Nirvana" identifies *the name-level concept
"Nirvana", understood as a music group* — every band by that name maps to it, and that
is the correct outcome, honestly labelled ([spec §0.3](../spec/00-overview.md),
tenet 2). `gen1` identifiers are expected to be superseded as stronger identifiers are
discovered, via the equivalence layer ([spec §8](../spec/08-equivalence.md)).

Although the value carries its entity type (unambiguous typing), a `gen1` IID is
**never** eligible for P0 anchoring: Class C atoms floor at profile P1, carrying the
recipe fields as preimage evidence, because a bare hash is neither verifiable nor
renderable. Typing and class are independent conditions and both must hold for P0.

## Admission criteria

1. **Stable, non-recycled identifiers** — the value is a pure function of frozen
   inputs: same facts, same identifier, forever. Nothing is assigned, so nothing can
   be recycled.
2. **No restrictive licensing** — the scheme hashes the minting party's own asserted
   facts.
3. **Deterministic offline canonicalization** — derivation is NORM-1 plus keccak-256,
   both pure and offline; validation is a shape check.

## Canonical form

```abnf
gen1-value = slug ":" "r" tag ":" hash16

slug   = 1*( %x61-7A / DIGIT / "-" )      ; the entity type's slug
tag    = %x31-39 *DIGIT                    ; stable rung tag, >= 1, no leading zero
hash16 = 32( DIGIT / %x61-66 )             ; first 16 bytes of keccak-256, lowercase hex
```

```text
int:gen1:movie:r4:fb681afe7d438cad73ae90a70f1cc55a
```

The slug namespaces the hash space per entity type; `r<N>` names the exact recipe
(field set) that was hashed, making the derivation inspectable from the identifier
alone; the hash is the first 16 bytes of keccak-256 over the preimage. The value
contains two colons — parsers split an IID on the first two colons only
([spec §2.3](../spec/02-grammar.md)).

**The derivation algorithm — recipe resolution, NORM-1 normalization, the exact
preimage JSON, hashing, and assembly — is defined normatively in
[spec §6](../spec/06-gen1.md)** and is not restated here. Rung tags are frozen recipe
identifiers, never ladder positions ([spec §6.4](../spec/06-gen1.md)).

## Canonicalization

`gen1` values are **built by derivation, never parsed from foreign input** — there is
no external notation to fold, so the canonicalizer is a strict shape validator with no
folding at all:

1. Trim surrounding whitespace.
2. Accept if and only if the result matches `^[a-z0-9-]+:r[1-9][0-9]*:[0-9a-f]{32}$`.

An uppercase slug or hash is rejected, not lowercased: a conforming deriver can never
produce one, so its appearance is evidence of corruption, and repairing it would mask
the defect.

## Test vectors

The accepted value below is the verified derivation of the `movie` rung `r4` recipe
(`{name, yearPublished}`) for *Inception* (2010), worked in full in
[spec §6.5](../spec/06-gen1.md).

| Input | Canonical value |
| :-- | :-- |
| `movie:r4:fb681afe7d438cad73ae90a70f1cc55a` | `movie:r4:fb681afe7d438cad73ae90a70f1cc55a` |
| `  movie:r4:fb681afe7d438cad73ae90a70f1cc55a  ` | `movie:r4:fb681afe7d438cad73ae90a70f1cc55a` |
| `movie:r0:fb681afe7d438cad73ae90a70f1cc55a` | **rejected** — rung tags start at 1 |
| `movie:r4:FB681AFE7D438CAD73AE90A70F1CC55A` | **rejected** — hash must be lowercase; no folding is applied |
| `movie:r4:fb681afe` | **rejected** — hash is not 32 hex chars |
| `Movie:r4:fb681afe7d438cad73ae90a70f1cc55a` | **rejected** — slug must be lowercase |

## Ladder placement

The bottom rung (or rungs — many ladders carry several `gen1` recipes of decreasing
strength) of nearly every entity type: [`person`](../entity-types/person.md),
[`company`](../entity-types/company.md), [`movie`](../entity-types/movie.md),
[`book`](../entity-types/book.md), [`music-group`](../entity-types/music-group.md),
[`event`](../entity-types/event.md), [`product`](../entity-types/product.md), and
onward. Within one ladder, the recipe using more identifying fields ranks higher
([spec §3.5](../spec/03-identity-classes.md)). The only entity types without `gen1`
rungs are those where no honest recipe exists — either because a natural key is always
present ([`ethereum-account`](../entity-types/ethereum-account.md),
[`web-page`](../entity-types/web-page.md)), or because nothing intrinsic to the entity
distinguishes it without referencing another entity
([`review`](../entity-types/review.md), [`comment`](../entity-types/comment.md),
[`social-media-account`](../entity-types/social-media-account.md)).

## Notes and limitations

- **Semantic collisions are intended.** Two entities sharing the recipe's facts share
  the identifier. Implementations MUST NOT "fix" this by appending counters, sources,
  or timestamps — that destroys determinism to conceal a limitation the scheme
  deliberately exposes ([spec §6.7](../spec/06-gen1.md)).
- **Mandatory P1.** A bare `gen1` string is unverifiable (no preimage evidence) and
  unrenderable (nothing to display). The recipe fields MUST travel in the atom payload
  ([spec §6.6](../spec/06-gen1.md)).
- **The canonicalizer cannot check the hash**, only its shape — verification means
  re-deriving from the P1 payload's recipe fields, which anyone can do offline.
- **Recipes hash intrinsic facts only.** Names of *related* entities (author, artist,
  brand) never enter a recipe — relationships are triples
  ([spec §0.3](../spec/00-overview.md), tenet 3).
- **Frozen end to end.** Preimage construction, keccak-256, 16-byte truncation, and
  the NORM-1 dependency will not change; an improved normalization ships as `gen2`
  alongside a `NORM-2`, coexisting with `gen1` and bridged by equivalence
  ([spec §6.8](../spec/06-gen1.md)).

## References

- [spec §6 — The `gen1` derived scheme](../spec/06-gen1.md) (normative algorithm)
- [spec §4 — NORM-1](../spec/04-normalization.md)
- [spec §7 — Representation profiles](../spec/07-representation-profiles.md) (the P1 floor)
- [RFC 8785 — JSON Canonicalization Scheme](https://www.rfc-editor.org/rfc/rfc8785) (string-escaping rules for the preimage)
