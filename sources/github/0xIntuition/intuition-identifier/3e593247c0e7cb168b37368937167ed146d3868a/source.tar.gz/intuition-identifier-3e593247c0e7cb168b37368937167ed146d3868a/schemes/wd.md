# `wd` — Wikidata item

| | |
| :-- | :-- |
| **Scheme** | `wd` |
| **Identity class** | A — registered authority |
| **Openness tier** | T2 — community registry, open data (CC0) |
| **Scheme typing** | Polymorphic — Wikidata covers every kind of thing |
| **Identifies** | One Wikidata item: any concept, person, work, place, or thing with a QID |
| **Authority** | Wikidata (Wikimedia Foundation) |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

A QID names one **Wikidata item** — a page in the world's largest open knowledge base,
which may describe a person, a film, a city, a chemical element, or an abstract concept.
Wikidata's breadth is exactly why the scheme is polymorphically typed
([spec §7.3](../spec/07-representation-profiles.md)): `Q42` alone does not say whether
it names a person, a book, or a place. It is also why `wd` appears on more ladders than
any other scheme — it is the universal cross-reference hub, linking out to most other
registries in this document set.

## Admission criteria

1. **Stable, non-recycled identifiers** — QIDs are assigned sequentially and never
   reassigned. Merged items leave permanent redirects; even deleted QIDs are never
   reissued.
2. **No restrictive licensing** — all Wikidata data, identifiers included, is published
   under CC0.
3. **Deterministic offline canonicalization** — prefix stripping, case folding, and a
   shape check; no registry access.

## Canonical form

An uppercase `Q` followed by digits with no leading zero.

```text
int:wd:Q42
```

```abnf
wd-value = %x51 nonzero *DIGIT   ; "Q" then a decimal number ≥ 1
nonzero  = %x31-39
```

## Canonicalization

1. Trim surrounding whitespace.
2. Strip one leading URL prefix matching
   `^https?://(www\.)?wikidata\.org/(wiki|entity)/` (case-insensitive).
3. Uppercase the result.
4. Accept only if the result matches `^Q[1-9][0-9]*$`. Anything else is rejected.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `https://www.wikidata.org/wiki/Q42` | `Q42` |
| `q42` | `Q42` |
| `https://wikidata.org/entity/Q25188` | `Q25188` |
| `Q25188` | `Q25188` |
| `Q042` | **rejected** — leading zero |
| `P31` | **rejected** — properties are not items |
| `42` | **rejected** — missing the `Q` prefix |

## Ladder placement

`wd` appears on more ladders than any other scheme, always sourced from `sameAs`:

- Rung 1 of [`company`](../entity-types/company.md),
  [`brand`](../entity-types/brand.md),
  [`local-business`](../entity-types/local-business.md),
  [`location`](../entity-types/location.md), [`event`](../entity-types/event.md),
  [`thing`](../entity-types/thing.md), [`movie`](../entity-types/movie.md), and
  [`tv-series`](../entity-types/tv-series.md).
- Rung 2 of [`person`](../entity-types/person.md) (below [`isni`](./isni.md)) and
  [`music-album`](../entity-types/music-album.md) (below [`mbid`](./mbid.md)).
- Rung 3 of [`book`](../entity-types/book.md) and
  [`music-group`](../entity-types/music-group.md).

On film and TV it ranks above both [`tmdb`](./tmdb.md) and [`imdb`](./imdb.md): CC0 and
cross-referencing both, per the openness ordering rule
([spec §3.3.1](../spec/03-identity-classes.md)).

## Notes and limitations

- **Not P0 anchor-eligible** ([spec §7.2](../spec/07-representation-profiles.md)):
  polymorphic typing floors atoms at P1, with `@type` in the payload.
- **Items merge.** Community editing routinely merges duplicate items; the losing QID
  becomes a redirect. Both QIDs remain valid names for the entity, and the equivalence
  layer joins them ([spec §8](../spec/08-equivalence.md)) — redirect resolution is
  enrichment, not canonicalization.
- **Item granularity is editorial.** Wikidata sometimes conflates work/edition or
  person/persona levels that this specification separates; a QID is evidence about
  whatever level its item happens to model.
- **Only items are admitted.** Properties (`P…`), lexemes (`L…`), and entity schemas are
  rejected; they name vocabulary, not entities.
- Deletion for spam/vandalism is possible, but a deleted QID is never reassigned, so a
  minted identifier can go dangling yet never becomes wrong.

## References

- [wikidata.org](https://www.wikidata.org/)
- [Wikibase data model — items](https://www.mediawiki.org/wiki/Wikibase/DataModel)
- [Wikidata copyright (CC0)](https://www.wikidata.org/wiki/Wikidata:Copyright)
