# `caip10` — Chain-agnostic account identifier (CAIP-10)

| | |
| :-- | :-- |
| **Scheme** | `caip10` |
| **Identity class** | B — intrinsic natural key |
| **Openness tier** | — (Class B: no registry; offline-validatable by construction) |
| **Scheme typing** | Polymorphic — an address may be an account or a contract ([spec §7.3](../spec/07-representation-profiles.md)) |
| **Identifies** | One blockchain account or deployed contract, on one chain |
| **Authority** | The chain's own cryptography — an address is derived from a keypair or a deployment transaction, and no institution can issue or revoke it |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

A `caip10` value names one **address on one chain**, in the CAIP-10 form
`<namespace>:<reference>:<address>` — for example `eip155:1:0x…` is an address on
Ethereum mainnet. The address is the entity: an externally owned account *is* its
keypair's address, and a contract *is* its deployment address.

The scheme is polymorphic because the value alone does not say whether the address is
an account or a contract; `caip10` atoms therefore floor at profile P1
([spec §7.2](../spec/07-representation-profiles.md)). What it does *not* name: a token
asset (that is [`caip19`](./caip19.md)), or the human behind an account (a separate
atom, linked by a triple).

## Admission criteria

1. **Stable, non-recycled identifiers** — an address is a function of a keypair or a
   deployment; it cannot be reassigned. (Contrast ENS names, which are transferable and
   were rejected as a scheme for exactly that reason.)
2. **No restrictive licensing** — addresses are public chain data.
3. **Deterministic offline canonicalization** — shape validation and case folding
   require no chain access.

## Canonical form

```text
int:caip10:eip155:1:0xd8da6bf26964af9d7eed9e03e53415d37aa96045
```

```abnf
caip10-value = namespace ":" reference ":" address
namespace    = 3*8( %x61-7A / DIGIT / "-" )        ; lowercase, per CAIP-2
reference    = 1*32( ALPHA / DIGIT / "-" / "_" )
address      = 1*VCHAR                              ; namespace-defined
```

For the `eip155` namespace the address is `0x` + 40 hex digits, **lowercase**. EIP-55
mixed-case checksumming is a presentation-layer aid, not identity: two casings of one
address are the same account, so the canonical form is the lowercase one.

Note the value itself contains colons; parsers split an IID on the first two colons
only ([spec §2.3](../spec/02-grammar.md)).

## Canonicalization

1. Trim surrounding whitespace.
2. Match `^([-a-z0-9]{3,8}):([-_a-zA-Z0-9]{1,32}):(.+)$`. Reject on failure (this
   enforces a lowercase namespace and a well-formed reference).
3. **If the namespace is `eip155`**: require the address to match `0x` + exactly 40 hex
   digits (any case); reject otherwise. Lowercase the address.
4. **Any other namespace**: pass the address through byte-for-byte. Case is significant
   in some namespaces (e.g. Solana's base58 addresses), so no folding is applied.
5. Reassemble `namespace:reference:address`.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `eip155:1:0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045` | `eip155:1:0xd8da6bf26964af9d7eed9e03e53415d37aa96045` |
| `eip155:1:0xd8da6bf26964af9d7eed9e03e53415d37aa96045` | `eip155:1:0xd8da6bf26964af9d7eed9e03e53415d37aa96045` |
| `eip155:8453:0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913` | `eip155:8453:0x833589fcd6edb6e08f4c7c32d4f71b54bda02913` |
| `solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp:7v91N7iZ9mNicL8WfG6cgSCKyRXydQjLh6UYBWwm6y1Q` | `solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp:7v91N7iZ9mNicL8WfG6cgSCKyRXydQjLh6UYBWwm6y1Q` |
| `eip155:1:0xd8da6bf2` | **rejected** — EVM address is not 40 hex digits |
| `0xd8da6bf26964af9d7eed9e03e53415d37aa96045` | **rejected** — bare address, no chain scoping |
| `EIP155:1:0xd8da6bf26964af9d7eed9e03e53415d37aa96045` | **rejected** — namespace must be lowercase |

## Ladder placement

- Sole rung of [`ethereum-account`](../entity-types/ethereum-account.md). An EOA is a
  chain-agnostic keypair — the same address controls funds on every EVM chain — so by
  convention the entity type pins `eip155:1` as the fixed chain reference, giving every
  EOA exactly one identifier rather than one per chain.
- Sole rung of
  [`ethereum-smart-contract`](../entity-types/ethereum-smart-contract.md), where the
  actual chain ID is used: a contract is a *deployment*, and the same bytecode on two
  chains is genuinely two entities.

## Notes and limitations

- **Non-EVM namespaces are shape-validated only.** The canonicalizer knows the address
  grammar of `eip155` and nothing else; a malformed Solana or Cosmos address of
  plausible shape will be accepted verbatim. Deep per-namespace validation would
  require freezing every chain's address rules into this scheme.
- **EIP-55 casing is discarded, deliberately.** The checksum protects against
  transcription errors at entry time; it carries no identity information. Validation
  against the checksum, where wanted, is enrichment.
- **Account vs contract is not decidable from the value** — hence polymorphic typing
  and the P1 floor. Deciding requires chain state, which canonicalization must not
  touch.
- **Multi-chain smart-contract wallets** (same address deployed on several chains)
  receive one identifier per chain. Whether those deployments are "one entity" is a
  claim for the equivalence layer, not the identifier.

## References

- [CAIP-10 — Account ID Specification](https://chainagnostic.org/CAIPs/caip-10)
- [CAIP-2 — Blockchain ID Specification](https://chainagnostic.org/CAIPs/caip-2)
- [EIP-55 — Mixed-case checksum address encoding](https://eips.ethereum.org/EIPS/eip-55)
