# `orcid` — Open Researcher and Contributor ID

| | |
| :-- | :-- |
| **Scheme** | `orcid` |
| **Identity class** | A — registered authority |
| **Openness tier** | T1 — open standard, offline-validatable |
| **Scheme typing** | Polymorphic — kept symmetric with `isni`, whose number space it shares |
| **Identifies** | One researcher's registered identity |
| **Authority** | ORCID, Inc. |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

An ORCID iD names one **researcher identity** — the record a researcher registers and
controls at orcid.org. It does not name any of the researcher's works (those carry
[`doi`](./doi.md) values), and it does not name an institution.

ORCID iDs are allocated from a reserved block of the ISNI number space and share its
grammar and checksum. The scheme is typed polymorphic for symmetry with
[`isni`](./isni.md): the two schemes validate the same shapes, and an ISNI-space value
may name a person or an organization, so neither scheme's bare value is allowed to imply
a type ([spec §7.3](../spec/07-representation-profiles.md)).

## Admission criteria

1. **Stable, non-recycled identifiers** — ORCID iDs are assigned once, never reassigned,
   and survive account deactivation; the registry has operated since 2012.
2. **No restrictive licensing** — ORCID publishes public record data under CC0; the
   identifiers themselves are open facts with no storage or republication restrictions.
3. **Deterministic offline canonicalization** — the ISO 7064 check character makes every
   value self-validating with no registry access.

## Canonical form

Sixteen characters, no separators: fifteen digits plus an ISO 7064 mod 11-2 check
character (`0`–`9` or `X`). Hyphens are stripped for consistency with the other
check-digit schemes, even though ORCID displays values hyphenated.

```text
int:orcid:0000000218250097
```

```abnf
orcid-value = 15 DIGIT check
check       = DIGIT / %x58       ; "X" when the checksum renders 10
```

## Canonicalization

Identical to [`isni`](./isni.md):

1. Strip all hyphens, spaces, and dots from the input. Uppercase the result (the check
   character may arrive as `x`).
2. Accept only if the result matches `^[0-9]{15}[0-9X]$`. Anything else — including
   `orcid.org` URLs — is rejected; extracting the value from a profile URL is
   enrichment, done before canonicalization.
3. Validate the ISO 7064 mod 11-2 check character over the first fifteen digits: start
   with `total = 0`; for each digit `d`, set `total = (total + d) × 2`; then
   `remainder = total mod 11` and `check = (12 − remainder) mod 11`, rendering 10 as
   `X`. The value is valid if and only if this equals the sixteenth character. Reject
   on failure.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `0000-0002-1825-0097` | `0000000218250097` |
| `0000000218250097` | `0000000218250097` |
| `0000-0002-9079-593X` | `000000029079593X` |
| `0000-0002-1825-0098` | **rejected** — check character fails |
| `https://orcid.org/0000-0002-1825-0097` | **rejected** — URLs are not canonicalized |
| `0000-0002-1825-009` | **rejected** — 15 characters, not 16 |

The first vector is ORCID's own documentation example (the fictional researcher Josiah
Carberry — a real, resolvable record maintained by ORCID for exactly this purpose).

## Ladder placement

Currently on **no ladder**. [`person`](../entity-types/person.md) leads with
[`isni`](./isni.md), which covers researchers and everyone else; a separate ORCID rung
has not been ratified. The scheme remains valid for direct minting and as corroborating
evidence, and adding it to `person` (or a future researcher-specific entity type) is an
open proposal.

## Notes and limitations

- **Not P0 anchor-eligible** ([spec §7.2](../spec/07-representation-profiles.md)):
  polymorphic typing floors atoms at P1, with `@type` in the payload.
- **One value, two schemes.** Because ORCID iDs sit inside the ISNI range, the same
  sixteen characters may be minted as `int:orcid:…` and `int:isni:…`. These are
  distinct IIDs joined by the equivalence layer
  ([spec §8](../spec/08-equivalence.md)); implementations should not assume one form.
- **Self-registered.** ORCID records are claimed by researchers themselves; duplicate
  registrations by one person occur and are resolved by ORCID's own deprecation
  mechanism, which points the deprecated iD at the surviving one — the deprecated value
  is never reassigned.
- The hyphenated display form `0000-0002-1825-0097` is presentation only.

## References

- [ORCID identifier structure](https://support.orcid.org/hc/en-us/articles/360006897674), ORCID, Inc.
- [orcid.org](https://orcid.org/)
- ISO/IEC 7064:2003 — check character systems (mod 11-2)
