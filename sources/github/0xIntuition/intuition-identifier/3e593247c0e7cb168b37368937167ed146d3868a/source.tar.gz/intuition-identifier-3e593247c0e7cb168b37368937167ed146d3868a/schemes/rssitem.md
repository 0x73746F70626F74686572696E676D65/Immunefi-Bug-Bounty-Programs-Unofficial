# `rssitem` — Feed item

| | |
| :-- | :-- |
| **Scheme** | `rssitem` |
| **Identity class** | B — intrinsic natural key |
| **Openness tier** | — (Class B: no registry; offline-validatable by construction) |
| **Scheme typing** | Unambiguous — always a feed item (podcast episode as published) |
| **Identifies** | One item within one feed: the feed's GUID plus a hash of the publisher's item GUID |
| **Authority** | The publisher's own item GUID, scoped by the Podcasting 2.0 feed GUID — both carried in the feed itself |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

An `rssitem` value names one **feed item** — a podcast episode *as it appears in a
specific feed*. This is manifestation-level identity: the episode-as-work is the
equivalence cluster over its feed items ([spec §8](../spec/08-equivalence.md)), because
the same recording can appear in multiple feeds (the original, a remaster feed, a
"best of" republication) with different item GUIDs.

Every RSS item carries a publisher-chosen `<guid>`. Its *format* is arbitrary — a URL,
a UUID, an internal path — but it is **byte-identical for every reader of the feed**:
format-arbitrary is not observer-arbitrary, which is what makes it a natural key rather
than a derived one. Scoping by the feed's GUID prevents two publishers who happen to
choose the same item GUID from colliding.

## Admission criteria

1. **Stable, non-recycled identifiers** — RSS convention (and podcast-directory
   practice) treats the item GUID as permanent; a changed GUID *is* a new item to every
   consumer, this scheme included. The feed GUID survives feed-URL migrations by
   design.
2. **No restrictive licensing** — feed and item GUIDs are open facts published in the
   feed.
3. **Deterministic offline canonicalization** — both the value construction (a keccak
   hash of a NORM-1'd string) and validation are pure and offline.

## Canonical form

`<feed-guid>:<hash16>` — the feed's lowercase Podcasting 2.0 GUID (a UUID, see
[`podcastguid`](./podcastguid.md)), a colon, and 32 lowercase hex characters:

```text
int:rssitem:917393e3-1b1e-5cef-ace4-edaa54e1f810:5cc51299e189a14f9c1aeb9029ee9a4b
```

```abnf
rssitem-value = feed-guid ":" hash16
feed-guid     = 8hexl "-" 4hexl "-" 4hexl "-" 4hexl "-" 12hexl   ; lowercase UUID
hexl          = DIGIT / %x61-66
hash16        = 32( DIGIT / %x61-66 )             ; first 16 bytes of keccak-256
```

### Value production

The value is **built upstream** by ladder machinery, from the feed's GUID and the raw
item GUID:

```text
value = lowercase(feedGuid) + ":" + keccak16(NORM-1(itemGuid))
```

where `keccak16` is the first 16 bytes of keccak-256, rendered as lowercase hex, and
`NORM-1` is the frozen normalization algorithm ([spec §4](../spec/04-normalization.md)).
The item GUID is hashed rather than embedded because its publisher-chosen format is
unbounded — arbitrary length, arbitrary characters — while an IID value must be short,
ASCII, and uniform ([spec §2.2](../spec/02-grammar.md)). Hashing buys a fixed-length,
charset-safe token at the cost of readability, which the P1 payload restores.

Example: item GUID `https://example.com/episodes/42` in feed
`917393e3-1b1e-5cef-ace4-edaa54e1f810` hashes to `5cc51299e189a14f9c1aeb9029ee9a4b`,
producing the canonical value shown above.

## Canonicalization

The canonicalizer **validates shape only** — it cannot reverse the hash or re-derive it
without the raw item GUID:

1. Trim surrounding whitespace and lowercase.
2. Match `^([0-9a-f-]{36}):([0-9a-f]{32})$`. Reject on failure.
3. Reject unless the first segment is a well-formed UUID (8-4-4-4-12 grouping).
4. Emit `feed-guid:hash16`.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `917393e3-1b1e-5cef-ace4-edaa54e1f810:5cc51299e189a14f9c1aeb9029ee9a4b` | `917393e3-1b1e-5cef-ace4-edaa54e1f810:5cc51299e189a14f9c1aeb9029ee9a4b` |
| `917393E3-1B1E-5CEF-ACE4-EDAA54E1F810:5CC51299E189A14F9C1AEB9029EE9A4B` | `917393e3-1b1e-5cef-ace4-edaa54e1f810:5cc51299e189a14f9c1aeb9029ee9a4b` |
| `917393e3-1b1e-5cef-ace4-edaa54e1f810` | **rejected** — no item-hash segment |
| `917393e3-1b1e-5cef-ace4-edaa54e1f810:abcd1234` | **rejected** — hash is not 32 hex chars |
| `917393e31b1e5ceface4edaa54e1f810aaaa:5cc51299e189a14f9c1aeb9029ee9a4b` | **rejected** — first segment is not a UUID |

## Ladder placement

Rung 1 of [`podcast-episode`](../entity-types/podcast-episode.md), above an episode-URL
fallback and `gen1` recipes over name (+ publication date).

## Notes and limitations

- **Manifestation, not work.** One episode syndicated into three feeds is three
  `rssitem` identifiers. Work-level convergence is deliberately left to equivalence,
  because "same episode" across feeds is a judgement, not a byte fact.
- **A changed item GUID forks identity.** Publishers occasionally regenerate GUIDs
  (feed-platform migrations are the usual cause); every downstream consumer — podcast
  apps included — sees new items, and so does this scheme. Accepted, since the
  alternative (identifying by title or audio) is strictly weaker.
- **The hash is one-way evidence.** A validator can confirm the value's shape offline
  but can only verify the hash against a claimed item GUID by recomputing
  `keccak16(NORM-1(itemGuid))` — which anyone holding the feed can do.
- **NORM-1 on the item GUID** folds case and whitespace before hashing; two feeds'
  byte-different but NORM-1-equal GUID renderings converge. GUIDs differing beyond
  presentation (per RSS best practice they should not) remain distinct.
- Feeds lacking a declared `<podcast:guid>` get one derived deterministically from the
  feed URL (see [`podcastguid`](./podcastguid.md)); the derivation is offline, so this
  scheme remains offline end-to-end.

## References

- [RSS 2.0 specification — `<guid>`](https://www.rssboard.org/rss-specification#ltguidgtSubelementOfLtitemgt)
- [Podcasting 2.0 `<podcast:guid>`](https://podcasting2.org/podcast-namespace/tags/guid) — the feed GUID
- [spec §4 — NORM-1](../spec/04-normalization.md) · [spec §8 — equivalence](../spec/08-equivalence.md)
