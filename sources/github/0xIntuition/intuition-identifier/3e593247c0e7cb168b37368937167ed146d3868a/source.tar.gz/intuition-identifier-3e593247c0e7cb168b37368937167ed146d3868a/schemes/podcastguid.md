# `podcastguid` — Podcasting 2.0 podcast GUID

| | |
| :-- | :-- |
| **Scheme** | `podcastguid` |
| **Identity class** | A — registered authority |
| **Openness tier** | T2 — community registry, open data |
| **Scheme typing** | Unambiguous — always a podcast (feed level) |
| **Identifies** | One podcast show, at the feed level |
| **Authority** | Podcasting 2.0 / Podcast Index (publisher-declared) |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

A podcast GUID names one **show** — the podcast as a whole, at the feed level. It does
not name an episode (episodes are feed items, identified by
[`rssitem`](./rssitem.md)), and it does not name the feed URL: the entire point of the
Podcasting 2.0 `<podcast:guid>` tag is that the GUID **survives feed migrations** while
URLs do not.

The authority here is lighter-weight than most Class A registries: the value is
declared by the publisher in the feed itself, under a convention specified by the
Podcasting 2.0 namespace and indexed by the openly licensed Podcast Index.

## Admission criteria

1. **Stable, non-recycled identifiers** — the namespace specifies that a show's GUID is
   minted once and carried unchanged across hosting moves and URL changes; UUIDs do not
   collide and are never reassigned.
2. **No restrictive licensing** — GUIDs are published in the feeds themselves, and the
   Podcast Index database is openly licensed; storage and republication are
   unrestricted.
3. **Deterministic offline canonicalization** — the value is a UUID shape check; and
   when a feed predates the tag, the GUID is *derivable* offline from the feed URL (see
   below), with no network access.

## Canonical form

A lowercase RFC 4122-shaped UUID.

```text
int:podcastguid:917393e3-1b1e-5cef-ace4-edaa54e1f810
```

```abnf
podcastguid-value = 8 lhex "-" 4 lhex "-" 4 lhex "-" 4 lhex "-" 12 lhex
lhex              = DIGIT / %x61-66   ; lowercase hex
```

## Canonicalization

1. Trim surrounding whitespace and lowercase the input.
2. Accept only if the result matches
   `^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$`. Anything else is
   rejected.

### Deriving the GUID from a feed URL

When a feed declares `<podcast:guid>`, that declared value is the identifier. When it
does not, the namespace defines the GUID as a deterministic function of the feed URL,
computable offline:

1. Trim the feed URL and strip its scheme — remove one leading match of
   `^[a-z][a-z0-9+.-]*://` (case-insensitive).
2. Strip all trailing slashes.
3. Compute the RFC 4122 **UUIDv5** (SHA-1, name-within-namespace) of the resulting
   string, using the Podcasting 2.0 namespace UUID
   `ead4c236-bf58-58c6-a2c6-a6b28d128cb6`.

Both verified derivations:

| Feed URL | Derived GUID |
| :-- | :-- |
| `https://mp3s.nashownotes.com/pc20rss.xml` | `917393e3-1b1e-5cef-ace4-edaa54e1f810` |
| `https://feeds.example.com/the-example-show.xml` | `f77016bc-fd74-5c94-893f-864deb06fc30` |

The first is the Podcasting 2.0 flagship feed used as the worked example in the
namespace documentation.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `917393e3-1b1e-5cef-ace4-edaa54e1f810` | `917393e3-1b1e-5cef-ace4-edaa54e1f810` |
| `917393E3-1B1E-5CEF-ACE4-EDAA54E1F810` | `917393e3-1b1e-5cef-ace4-edaa54e1f810` |
| `f77016bc-fd74-5c94-893f-864deb06fc30` | `f77016bc-fd74-5c94-893f-864deb06fc30` |
| `917393e31b1e5ceface4edaa54e1f810` | **rejected** — hyphens are required |
| `not-a-uuid` | **rejected** — not a UUID |

## Ladder placement

Rungs 1 and 2 of [`podcast-series`](../entity-types/podcast-series.md):

1. The **declared** `<podcast:guid>` from the feed — it survives migrations.
2. The **derived** UUIDv5 of the feed URL — a fallback that forks when a show changes
   hosts, which is exactly why it ranks below the declared form.

## Notes and limitations

- **P0 anchor-eligible** ([spec §7.2](../spec/07-representation-profiles.md)): Class A
  and unambiguously typed — a podcast GUID is always a show.
- **Derivation forks on migration.** A show that moved feeds before declaring a GUID
  has one derived GUID per historical URL. These are equivalence clusters
  ([spec §8](../spec/08-equivalence.md)); the declared GUID, once present, is the
  convergence point.
- **Any UUID shape is accepted, not only v5.** Publishers may declare arbitrary UUIDs;
  the canonicalizer checks RFC 4122 shape, not version bits. The version-5 structure is
  guaranteed only for derived values.
- **Publisher-declared means publisher-mutable.** A misbehaving publisher can change
  the tag; the namespace forbids it, and the Podcast Index treats the first-seen GUID
  as authoritative, but the guarantee is conventional rather than institutional —
  weaker than, say, GLEIF's.

## References

- [Podcasting 2.0 podcast namespace — `<podcast:guid>`](https://github.com/Podcastindex-org/podcast-namespace/blob/main/docs/tags/guid.md)
- [Podcast Index](https://podcastindex.org/)
- RFC 4122 — A Universally Unique IDentifier (UUID) URN Namespace (§4.3, name-based UUIDs)
