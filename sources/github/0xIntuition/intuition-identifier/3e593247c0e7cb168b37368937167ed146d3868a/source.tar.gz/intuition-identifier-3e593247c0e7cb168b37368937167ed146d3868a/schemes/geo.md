# `geo` — Geohash cell

| | |
| :-- | :-- |
| **Scheme** | `geo` |
| **Identity class** | B — intrinsic natural key |
| **Openness tier** | — (Class B: no registry; offline-validatable by construction) |
| **Scheme typing** | Polymorphic — a cell may be a location or a business's premises ([spec §7.3](../spec/07-representation-profiles.md)) |
| **Identifies** | One geohash cell of the Earth's surface |
| **Authority** | The geohash algorithm over WGS 84 coordinates — the cell is a pure function of position, assigned by geometry, not by anyone |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

A `geo` value names one **cell** of the standard geohash grid: a rectangle of the
Earth's surface whose size is determined by the string's length. By convention the
[`location`](../entity-types/location.md) ladder mints at **precision 8** (a cell of
roughly 38 m × 19 m), which is tight enough to distinguish adjacent buildings and loose
enough to absorb GPS jitter.

It names a cell, not a point and not a place-as-concept: "the Eiffel Tower" is a
`location` entity whose ladder *prefers* a Wikidata ID and falls back to the geohash of
its coordinates. And because a cell may equally be a park, an intersection, or a shop's
premises, the scheme is polymorphic and floors at profile P1.

Raw latitude/longitude pairs were rejected as a scheme: coordinates are *measured*, and
two sources never measure identically. Geohashing is the quantization that turns a
measurement into a discrete, matchable key.

## Admission criteria

1. **Stable, non-recycled identifiers** — the grid is fixed mathematics; a cell can
   neither move nor be reassigned.
2. **No restrictive licensing** — geohash is public domain; the values encode open
   geometric facts. (Contrast Google Place IDs, excluded precisely on licensing.)
3. **Deterministic offline canonicalization** — charset and length validation; encoding
   from coordinates is likewise a pure local computation.

## Canonical form

1–12 characters from the geohash base-32 alphabet, lowercase:

```text
int:geo:9q8yyk8y
```

```abnf
geo-value    = 1*12 geohash-char
geohash-char = %x30-39 / "b" / "c" / "d" / "e" / "f" / "g" / "h" / "j" /
               "k" / "m" / "n" / "p" / "q" / "r" / "s" / "t" / "u" / "v" /
               "w" / "x" / "y" / "z"
```

The alphabet is `0123456789bcdefghjkmnpqrstuvwxyz` — note that `a`, `i`, `l`, `o` are
**not** in it, which makes their presence a reliable sign of corrupted input.

## Canonicalization

1. Trim surrounding whitespace and lowercase.
2. Reject unless the result is 1–12 characters, every one drawn from the alphabet
   `0123456789bcdefghjkmnpqrstuvwxyz`.

Encoding coordinates *into* a geohash (done by ladder machinery, upstream of the
canonicalizer) is the standard algorithm: starting with the longitude interval
[−180, 180] and latitude interval [−90, 90], repeatedly bisect — alternating longitude
first, then latitude — emitting 1 for the upper half and 0 for the lower; every 5 bits
select one character from the alphabet, until the requested precision is reached.
Latitude must be in [−90, 90] and longitude in [−180, 180].

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `9q8yyk8y` | `9q8yyk8y` |
| `9Q8YYK8Y` | `9q8yyk8y` |
| `u4pruydqqvj` | `u4pruydqqvj` |
| `gbsuv` | `gbsuv` |
| `9q8yyk8a` | **rejected** — `a` is not in the geohash alphabet |
| `9q8yyk8y9q8yyk8y` | **rejected** — longer than 12 characters |

Encoding check: latitude 37.7749, longitude −122.4194 (San Francisco) at precision 8
encodes to `9q8yyk8y`.

## Ladder placement

- Rung 2 of [`location`](../entity-types/location.md), below `wd`, at **precision 8** —
  minted from the entity's declared coordinates.
- [`local-business`](../entity-types/local-business.md) does **not** mint `geo` values;
  its ladder uses a **precision-7** cell (~150 m) as a *field inside a `gen1` recipe*
  (name + cell), because a business is not a cell — the cell only disambiguates two
  branches of one chain.

## Notes and limitations

- **Boundary effects are inherent.** Quantization means two measurements of one place
  can straddle a cell edge and land in adjacent cells — the entrance and the loading
  dock of one building may hash apart. Neighboring-cell reconciliation is an
  equivalence-layer concern; the identifier layer never fuzzes.
- **A cell is not a place.** Multiple named places share a cell (a shop below an
  office), and a large place (a park, a city) spans many cells. This is why `wd`
  outranks `geo` on the `location` ladder and why the scheme is polymorphic.
- **Coordinate quality caps identifier quality.** Geocoding the same address with two
  providers can yield different cells. Choosing the best coordinates is enrichment,
  done before derivation.
- **Precision is convention, not validation.** The canonicalizer accepts any length 1–12;
  the precision-8 rule for locations lives in the ladder. A value of another length is
  a valid `geo` identifier for a coarser or finer cell.
- Not suitable for moving entities; a cell identifies where something *is*, which for a
  vehicle is not identity at all.

## References

- [Geohash](https://en.wikipedia.org/wiki/Geohash) — the original Niemeyer encoding
- [geohash.org](http://geohash.org/) — reference encoder
- [WGS 84](https://epsg.org/crs_4326/WGS-84.html) — the coordinate reference system assumed by the encoding
