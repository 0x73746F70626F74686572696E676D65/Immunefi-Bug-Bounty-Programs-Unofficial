# `tmdb` — The Movie Database identifier

| | |
| :-- | :-- |
| **Scheme** | `tmdb` |
| **Identity class** | A — registered authority |
| **Openness tier** | T2 — community registry, open data (daily ID exports) |
| **Scheme typing** | Polymorphic — the `person` segment spans classifications |
| **Identifies** | One TMDB record: a movie, a TV series, or a person |
| **Authority** | The Movie Database (TMDB) |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

A `tmdb` value names one **TMDB record**, with the kind carried in the value:
`movie:…`, `tv:…`, or `person:…`. The segment is mandatory because TMDB's numeric IDs
are unique only within each type — movie `27205` and person `27205` are different
records.

Unlike [`mbid`](./mbid.md) and [`olid`](./olid.md), the in-value segment does **not**
make the scheme unambiguously typed: the `person` segment covers individuals and acts
that this specification classifies differently (a person, a duo, a group), so knowing
the scheme and value still does not pin one entity type. The scheme was ratified
polymorphic for that reason ([spec §7.3](../spec/07-representation-profiles.md)).

## Admission criteria

1. **Stable, non-recycled identifiers** — TMDB IDs are permanent within their type;
   deleted records' IDs are not reassigned. The registry has been community-operated
   since 2008.
2. **No restrictive licensing** — TMDB publishes daily ID export files for all record
   types and an attribution-based API; storing and republishing identifiers is
   unrestricted.
3. **Deterministic offline canonicalization** — URL and slug stripping plus a segment
   whitelist; no registry access.

## Canonical form

The type segment, a colon, and the decimal record ID.

```text
int:tmdb:movie:27205
```

```abnf
tmdb-value  = entity-type ":" 1*DIGIT
entity-type = "movie" / "tv" / "person"
```

## Canonicalization

1. Trim surrounding whitespace and lowercase the input.
2. Strip one leading URL prefix matching `^https?://(www\.)?themoviedb\.org/`.
3. If the result matches `^([a-z]+/[0-9]+)-[^/]*$`, drop the hyphenated title slug,
   keeping only `<segment>/<digits>` (TMDB URLs read `movie/27205-inception`).
4. Match against `^([a-z]+)[/:]([0-9]+)$` — a segment, `/` or `:`, and a decimal ID.
   Reject if there is no match.
5. Reject unless the segment is one of `movie`, `tv`, `person`.
6. Emit `<segment>:<id>`.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `https://www.themoviedb.org/movie/27205-inception` | `movie:27205` |
| `movie/27205` | `movie:27205` |
| `movie:27205` | `movie:27205` |
| `https://www.themoviedb.org/tv/1396` | `tv:1396` |
| `person:6193` | `person:6193` |
| `season:1` | **rejected** — not a recognized segment |
| `27205` | **rejected** — missing the type segment |

## Ladder placement

Rung 2 of both [`movie`](../entity-types/movie.md) and
[`tv-series`](../entity-types/tv-series.md) — below [`wd`](./wd.md), above
[`imdb`](./imdb.md). The ordering is the openness rule
([spec §3.3.1](../spec/03-identity-classes.md)): TMDB's daily ID exports make it
independently verifiable in a way IMDb's closed dataset is not.

## Notes and limitations

- **Not P0 anchor-eligible** ([spec §7.2](../spec/07-representation-profiles.md)):
  polymorphic typing floors atoms at P1, with `@type` in the payload. This is the case
  worth reading twice — an in-value segment is necessary but not sufficient; the
  segments must also map one-to-one onto entity types, and `person` does not.
- **The segment whitelist is frozen.** TMDB also exposes seasons, episodes,
  collections, companies, and networks; admitting any of them is a registry change
  under [spec §9.4](../spec/09-registry-governance.md), not an edit here. `season:1`
  rejecting today is deliberate.
- **`tv` is series-level.** Season- and episode-level identity has no rung anywhere
  yet; the [`tv-series`](../entity-types/tv-series.md) type identifies the series only.
- **IDs are numeric and dense**, so a typo usually yields another live record. There is
  no check digit; cross-checking against a title is a data-quality concern above the
  identifier layer.

## References

- [TMDB API documentation](https://developer.themoviedb.org/docs)
- [TMDB daily ID exports](https://developer.themoviedb.org/docs/daily-id-exports)
