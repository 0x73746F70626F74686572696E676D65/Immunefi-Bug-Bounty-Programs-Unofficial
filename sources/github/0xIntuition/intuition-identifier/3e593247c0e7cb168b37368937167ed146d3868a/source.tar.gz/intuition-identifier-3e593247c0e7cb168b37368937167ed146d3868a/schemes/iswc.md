# `iswc` — International Standard Musical Work Code

| | |
| :-- | :-- |
| **Scheme** | `iswc` |
| **Identity class** | A — registered authority |
| **Openness tier** | T1 — open standard, offline-validatable |
| **Scheme typing** | Unambiguous — always a musical work |
| **Identifies** | One musical composition (the work, not any recording of it) |
| **Authority** | CISAC (ISO 15707) |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

An ISWC names one **musical work** — the composition as written, independent of any
performance. Every cover, remix, and live take of a song is a different recording
([`isrc`](./isrc.md)) of the same work (one `iswc`). The scheme does not name recordings,
releases, or sheet-music products.

## Admission criteria

1. **Stable, non-recycled identifiers** — ISWCs are assigned once by the ISWC
   International Agency network (CISAC) and never reassigned; the system has operated
   since 2001.
2. **No restrictive licensing** — ISWC values are open facts carried in rights metadata;
   storage and republication are unrestricted.
3. **Deterministic offline canonicalization** — the check digit makes every value
   self-validating with no registry access.

## Canonical form

The letter `T` followed by a nine-digit work number and one check digit, no separators.

```text
int:iswc:T0345246801
```

```abnf
iswc-value = %x54 9 DIGIT DIGIT   ; "T" + work number + check digit (must validate)
```

## Canonicalization

1. Strip all hyphens, spaces, and dots from the input. Uppercase the result.
2. Accept only if the result matches `^T[0-9]{10}$`. Anything else is rejected.
3. Validate the check digit: let `d1…d9` be the nine work-number digits and `d10` the
   final digit. Compute `sum = 1 + Σ (i × dᵢ)` for `i` from 1 to 9. The value is valid
   if and only if `(10 − (sum mod 10)) mod 10 = d10`. Reject on failure.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `T-034.524.680-1` | `T0345246801` |
| `T0345246801` | `T0345246801` |
| `t-034.524.680-1` | `T0345246801` |
| `T0345246800` | **rejected** — check digit fails |
| `T034524680` | **rejected** — nine digits after `T`, not ten |
| `0345246801` | **rejected** — missing the `T` prefix |

## Ladder placement

Currently on **no ladder**. The registry admits `iswc` and the identifier is valid for
direct minting and as equivalence evidence, but no ratified entity type identifies at
the composition level — [`music-recording`](../entity-types/music-recording.md)
deliberately stops at the recording. A future musical-work entity type would take
`iswc` as its top rung; proposing one is open.

## Notes and limitations

- **P0 anchor-eligible** ([spec §7.2](../spec/07-representation-profiles.md)): Class A
  and unambiguously typed — an ISWC is always a musical work.
- **Duplicates exist in the registry.** Societies have historically registered the same
  work more than once; agency-side merges leave multiple ISWCs pointing at one work.
  Work-level convergence is the equivalence layer's job
  ([spec §8](../spec/08-equivalence.md)).
- **Coverage is rights-driven.** Works outside collective rights management (much
  self-released music) often have no ISWC and fall through to lower rungs.
- The displayed form `T-034.524.680-1` is presentation only; the canonical value never
  carries separators.

## References

- ISO 15707:2001 — International Standard Musical Work Code
- [iswc.org](https://www.iswc.org/) — ISWC International Agency (CISAC)
- [ISWC format and check digit](https://www.iswc.org/faq), ISWC International Agency
