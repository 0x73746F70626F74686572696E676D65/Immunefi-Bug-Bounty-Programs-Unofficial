# `hash` — Content digest

| | |
| :-- | :-- |
| **Scheme** | `hash` |
| **Identity class** | B — intrinsic natural key |
| **Openness tier** | — (Class B: no registry; offline-validatable by construction) |
| **Scheme typing** | Polymorphic — a digest of any content type ([spec §7.3](../spec/07-representation-profiles.md)) |
| **Identifies** | One exact byte sequence — a file, image, or video as bytes |
| **Authority** | The hash function's collision resistance — the digest is the content, compressed to 32 bytes |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

A `hash` value names one **exact sequence of bytes**: the digest of a file's raw
content. Change one byte and the digest — provably — changes. This is byte-level
*manifestation* identity, the strongest identity a media file can have, and also the
narrowest: a re-encoded, resized, or re-compressed copy of the same picture is a
different byte sequence and therefore a different identifier. "These files show the
same work" is an equivalence-layer claim ([spec §8](../spec/08-equivalence.md)), never
an identifier-layer fact.

Because a digest reveals nothing about what kind of content it hashes, the scheme is
polymorphic and `hash` atoms floor at profile P1
([spec §7.2](../spec/07-representation-profiles.md)).

## Admission criteria

1. **Stable, non-recycled identifiers** — a digest is a pure function of the content;
   nothing assigns it and nothing can reassign it.
2. **No restrictive licensing** — a hash value carries no licensable content.
3. **Deterministic offline canonicalization** — validating the shape of a digest needs
   no network, and anyone holding the content can re-derive the digest to verify it.

## Canonical form

`<algorithm>:<64 lowercase hex digits>`, where the algorithm is one of the frozen set
**`sha256`**, **`keccak256`** — both 256-bit digests over the raw content bytes:

```text
int:hash:sha256:9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08
```

```abnf
hash-value = algorithm ":" 64HEXLC
algorithm  = "sha256" / "keccak256"
HEXLC      = DIGIT / %x61-66                ; 0-9, a-f
```

The two algorithms exist because the surrounding ecosystems disagree: `sha256` is the
universal file-digest standard; `keccak256` matches the Intuition toolchain and the
EVM. One piece of content therefore has up to two valid `hash` identifiers — one per
algorithm — joined by equivalence when both are minted.

## Canonicalization

1. Trim surrounding whitespace and lowercase the entire input.
2. Match `^([a-z0-9]+):(0x)?([0-9a-f]{64})$` — an algorithm label, an optional `0x`
   prefix (stripped), and exactly 64 hex digits. Reject on failure.
3. Reject any algorithm label other than `sha256` or `keccak256`. This set is frozen
   with the scheme; a new algorithm is a registry change, not an edit.
4. Emit `algorithm:digest` with the `0x` prefix removed.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `sha256:9F86D081884C7D659A2FEAA0C55AD015A3BF4F1B2B0B822CD15D6C15B0F00A08` | `sha256:9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08` |
| `sha256:0x9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08` | `sha256:9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08` |
| `sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | `sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `keccak256:c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470` | `keccak256:c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470` |
| `md5:d41d8cd98f00b204e9800998ecf8427e` | **rejected** — algorithm not in the frozen set |
| `sha256:9f86d081` | **rejected** — digest is not 64 hex digits |

## Ladder placement

Rung 1 of [`image`](../entity-types/image.md) and
[`video-object`](../entity-types/video-object.md) — byte-identity first, with `url` as
the mutable manifestation fallback and `gen1` below that.

## Notes and limitations

- **The canonicalizer validates shape, not truth.** Whether a digest actually
  corresponds to any content cannot be checked from the value alone; verification
  requires the content bytes, and anyone holding them can perform it offline. A
  fabricated but well-shaped digest will canonicalize.
- **A digest is opaque — publish context with it.** The hash names the bytes but
  cannot say where to fetch them. A minter who knows a fetch URL, a mirror, a MIME
  type, or the artifact's size SHOULD publish them as companion metadata at atom
  creation ([spec §7.8](../spec/07-representation-profiles.md)) — as metadata, never
  as identity input.
- **Byte identity is deliberately brittle.** Every transcode, crop, thumbnail, or
  metadata edit produces a new identifier. This is the scheme working as designed — it
  is why `hash` outranks `url` for media (the bytes cannot silently change under the
  identifier) and why work-level convergence belongs to equivalence.
- **Which bytes were hashed matters.** The digest is over the raw file as stored;
  hashing a decoded or normalized representation is a different (and unspecified)
  operation. Producers must hash the file bytes exactly as served.
- `md5` and `sha1` are excluded: both have practical collision attacks, which for an
  identity scheme is disqualifying, not merely inelegant.

## References

- [FIPS 180-4 — Secure Hash Standard (SHA-256)](https://csrc.nist.gov/pubs/fips/180-4/upd1/final)
- [The Keccak reference](https://keccak.team/keccak.html) — keccak-256 as used by Ethereum (pre-NIST-padding SHA-3 variant)
- [RFC 6920](https://www.rfc-editor.org/rfc/rfc6920) — naming things with hashes (design precedent)
