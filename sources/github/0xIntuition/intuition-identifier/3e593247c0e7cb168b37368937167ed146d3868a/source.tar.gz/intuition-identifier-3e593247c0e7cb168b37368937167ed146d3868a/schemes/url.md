# `url` — Canonical web address

| | |
| :-- | :-- |
| **Scheme** | `url` |
| **Identity class** | B — intrinsic natural key |
| **Openness tier** | — (Class B: no registry; offline-validatable by construction) |
| **Scheme typing** | Polymorphic — a URL can address anything ([spec §7.3](../spec/07-representation-profiles.md)) |
| **Identifies** | One web resource, at its canonical `https` address |
| **Authority** | Web architecture itself — DNS delegation plus RFC 3986/WHATWG URL syntax make the address the resource's natural key |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

A `url` value names one **web resource**: the page, document, or endpoint served at that
address. It does not name the work the page describes — a news article's `url` atom is
the story *as published at that address*, and a mirror of the same text at another
address is a different `url` identifier, joined (if at all) through the equivalence
layer ([spec §8](../spec/08-equivalence.md)).

Because a URL can address anything, the scheme is polymorphic: a bare `int:url:…` does
not imply an entity type, so `url` atoms floor at profile P1
([spec §7.2](../spec/07-representation-profiles.md)).

## Admission criteria

1. **Stable, non-recycled identifiers** — a URL is the resource's own address; no
   registry assigns or recycles it. Addresses do rot and content does move, which is a
   documented limitation, not a recycling of the identifier itself.
2. **No restrictive licensing** — URLs are open facts; storage and republication are
   unrestricted.
3. **Deterministic offline canonicalization** — the algorithm below is a pure function
   of the input string: no network access, no clock, no configuration.

## Canonical form

An `https` URL with lowercase host, no `www.` prefix, no default port, no fragment, no
tracking parameters, remaining query parameters sorted, and no trailing slashes:

```text
int:url:https://en.wikipedia.org/wiki/Brad_Pitt
```

The scheme part of a canonical value is always `https`, even when the input was `http`.

## Canonicalization

**Enrichment happens first, and never inside this algorithm.** Following redirects,
honouring `rel=canonical`, and folding AMP or mobile hosts (`m.`, `amp.`) onto their
desktop originals all require network access or page content, so they are enrichment
steps applied *before* canonicalization to produce a better input
([spec §0.3](../spec/00-overview.md), tenet 4). The canonicalizer itself is pure:

1. Trim surrounding whitespace and parse the input per the WHATWG URL Standard. Reject
   anything that does not parse.
2. Reject any URL whose scheme is not `http` or `https`.
3. Take the hostname, lowercased (the parser does this; internationalized names become
   punycode), and strip one leading `www.`.
4. Drop every query parameter whose key starts with `utm_`, or whose key is exactly one
   of: `fbclid`, `gclid`, `dclid`, `wbraid`, `gbraid`, `msclkid`, `twclid`, `ttclid`,
   `igshid`, `g_mp`, `spm`, `mkt_tok`, `mc_cid`, `ref`, `si`. This list is frozen with
   the scheme.
5. Sort the remaining parameters ascending by key (byte order), breaking ties by value,
   and re-serialize as `key=value` pairs joined by `&`, percent-encoding each key and
   value per RFC 3986 (spaces become `%20`, never `+`).
6. Take the path and strip **all** trailing slashes (the root path becomes empty).
7. Keep the port only if it is present and is neither `80` nor `443`; otherwise drop it.
8. Drop the fragment unconditionally.
9. Assemble: `https://` + host + [`:` port] + path + [`?` query].

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `http://www.Example.com/Articles/?b=2&a=1&utm_source=news#top` | `https://example.com/Articles?a=1&b=2` |
| `https://example.com/Articles?a=1&b=2` | `https://example.com/Articles?a=1&b=2` |
| `https://example.com:443/` | `https://example.com` |
| `http://example.com:80/a` | `https://example.com/a` |
| `https://example.com:8080/api` | `https://example.com:8080/api` |
| `https://open.spotify.com/episode/3dVYvWrhLdKg5Znpn1YG9o?si=ca38623922614db1` | `https://open.spotify.com/episode/3dVYvWrhLdKg5Znpn1YG9o` |
| `https://www.instagram.com/p/xyz/?igshid=MzRlODBiNWFlZA` | `https://instagram.com/p/xyz` |
| `https://example.com/product?msclkid=abc&wbraid=def&spm=a2g0o.detail&color=red` | `https://example.com/product?color=red` |
| `ftp://example.com/file` | **rejected** — scheme is not http/https |
| `not a url` | **rejected** — does not parse as a URL |

## Ladder placement

The most widely placed Class B scheme:

- Sole rung of [`web-page`](../entity-types/web-page.md) and (at origin level)
  [`web-site`](../entity-types/web-site.md).
- Leading rung of [`news-article`](../entity-types/news-article.md),
  [`job-posting`](../entity-types/job-posting.md),
  [`social-media-posting`](../entity-types/social-media-posting.md),
  [`software-application`](../entity-types/software-application.md),
  [`service`](../entity-types/service.md), [`review`](../entity-types/review.md), and
  [`comment`](../entity-types/comment.md).
- Fallback rung, below stronger schemes, on [`article`](../entity-types/article.md),
  [`company`](../entity-types/company.md), [`event`](../entity-types/event.md),
  [`thing`](../entity-types/thing.md), [`dataset`](../entity-types/dataset.md),
  [`image`](../entity-types/image.md), [`video-object`](../entity-types/video-object.md),
  [`podcast-series`](../entity-types/podcast-series.md),
  [`podcast-episode`](../entity-types/podcast-episode.md),
  [`software`](../entity-types/software.md), and
  [`mobile-application`](../entity-types/mobile-application.md).

## Notes and limitations

- **http/https folding assumes one resource.** Folding the scheme to `https` treats
  `http://…/x` and `https://…/x` as one page. A server that deliberately serves distinct
  resources at the same path on the two schemes will see them collide. This is rare on
  the modern web and is an accepted limitation.
- **Trailing-slash folding assumes one resource** for `/a` vs `/a/`, for the same
  reason, with the same (rare) failure mode.
- **The tracking-parameter list is frozen.** A newly invented tracking parameter will
  not be stripped; two shares of one page differing only by that parameter mint two
  identifiers until equivalence joins them. Extending the list is a canonicalization
  change and therefore a new scheme, never an edit.
- **Semantically empty parameters are kept.** The canonicalizer cannot know that
  `?page=1` equals the bare path, or that a session ID outside the frozen list is
  noise. Producing the cleanest possible input is enrichment's job.
- **Link rot is real.** A URL names an address, and content at an address changes or
  disappears. This is why `url` ranks below registry identifiers wherever both exist,
  and why byte-identity (`hash`) outranks it for media files.

## References

- [WHATWG URL Standard](https://url.spec.whatwg.org/) — the parsing model
- [RFC 3986](https://www.rfc-editor.org/rfc/rfc3986) — URI syntax and normalization
- [RFC 9110 §4.2.3](https://www.rfc-editor.org/rfc/rfc9110#section-4.2.3) — http/https default ports
