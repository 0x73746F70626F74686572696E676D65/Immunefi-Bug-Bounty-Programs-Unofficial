# `gtin` — Global Trade Item Number

| | |
| :-- | :-- |
| **Scheme** | `gtin` |
| **Identity class** | A — registered authority |
| **Openness tier** | T1 — open standard, offline-validatable |
| **Scheme typing** | Unambiguous — always a trade item |
| **Identifies** | One trade item: a product model at one packaging level |
| **Authority** | GS1 |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

A GTIN names one **trade item** — a product model as sold, at a specific packaging level.
It unifies the barcode families: UPC-A (GTIN-12), EAN-13 (GTIN-13), EAN-8 (GTIN-8), and
the 14-digit case/carton form (GTIN-14) are all one number space, and this scheme stores
them all in the zero-padded 14-digit form GS1 itself designates as the canonical storage
format.

A GTIN does not name an individual physical unit (no serial number), a brand, or a
company. The single unit and the six-pack of one product are different trade items with
different GTINs — by design.

## Admission criteria

1. **Stable, non-recycled identifiers** — GS1 company prefixes and item references are
   licensed and managed under GS1 rules; since 2019, GS1 policy is that GTINs are never
   reused, even for discontinued products.
2. **No restrictive licensing** — GTIN values are open facts printed on packaging
   worldwide; storage and republication are unrestricted.
3. **Deterministic offline canonicalization** — the GS1 mod-10 check digit makes every
   value self-validating with no registry access.

## Canonical form

Exactly 14 digits — the GTIN-14 storage form, zero-padded — with a valid GS1 check
digit.

```text
int:gtin:00036000291452
```

```abnf
gtin-value = 14 DIGIT            ; GS1 mod-10 check digit must validate
```

## Canonicalization

1. Strip all hyphens, spaces, and dots from the input.
2. Accept only if the result matches `^[0-9]{8}$|^[0-9]{12,14}$` — that is, exactly 8,
   12, 13, or 14 digits. Anything else is rejected (there is no 9-, 10-, or 11-digit
   GTIN).
3. Left-pad the result with `0` to 14 digits.
4. Validate the GS1 mod-10 check digit: compute it over the first 13 digits and compare
   with the 14th. Reject on failure.

The GS1 mod-10 check digit over a payload: from the rightmost payload digit leftward,
weight digits 3, 1, 3, 1, …; the check digit is `(10 − (sum mod 10)) mod 10`.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `036000291452` | `00036000291452` |
| `0 36000 29145 2` | `00036000291452` |
| `96385074` | `00000096385074` |
| `4006381333931` | `04006381333931` |
| `9780684832722` | `09780684832722` |
| `036000291453` | **rejected** — check digit fails |
| `123456789` | **rejected** — 9 digits is not a GTIN length |

## Ladder placement

Rung 1 of [`product`](../entity-types/product.md).

## Notes and limitations

- **P0 anchor-eligible** ([spec §7.2](../spec/07-representation-profiles.md)): Class A
  and unambiguously typed — a GTIN is always a trade item.
- **An ISBN-13 is a valid GTIN-13** (the "Bookland" prefixes 978/979). The same barcode
  digits canonicalize to `int:isbn:9780684832722` and `int:gtin:09780684832722` — two
  different IIDs at two different abstraction levels (edition vs. trade item). When both
  exist for one thing, the equivalence layer joins them
  ([spec §8](../spec/08-equivalence.md)).
- **Packaging levels fork identity on purpose.** GTIN-14's leading indicator digit
  distinguishes case quantities of one product; zero-padding a GTIN-12 never collides
  with a real indicator-prefixed GTIN-14 because the check digit is computed over the
  padded form.
- **Pre-2019 reuse.** GS1 rules once permitted reusing GTINs of discontinued products
  after a waiting period; rare historical collisions exist in old data and are a
  data-quality dispute for the layers above.

## References

- [GS1 General Specifications](https://www.gs1.org/standards/barcodes-epcrfid-id-keys/gs1-general-specifications)
- [GS1 GTIN Management Standard](https://www.gs1.org/1/gtinrules/) (the non-reuse rule)
- [GS1 check digit calculator](https://www.gs1.org/services/check-digit-calculator) (the mod-10 algorithm)
