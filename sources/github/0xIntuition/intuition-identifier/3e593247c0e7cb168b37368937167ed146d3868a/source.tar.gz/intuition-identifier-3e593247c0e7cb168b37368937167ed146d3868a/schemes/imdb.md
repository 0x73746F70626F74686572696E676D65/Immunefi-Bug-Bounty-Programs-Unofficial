# `imdb` — IMDb identifier

| | |
| :-- | :-- |
| **Scheme** | `imdb` |
| **Identity class** | A — registered authority |
| **Openness tier** | T3 — proprietary (closed dataset) |
| **Scheme typing** | Polymorphic — titles, people, companies, events, characters |
| **Identifies** | One IMDb record: a title, person, company, event, character, or news item |
| **Authority** | IMDb (Amazon) |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

An IMDb ID names one **IMDb record**. The two-letter prefix says which database it lives
in: `tt` titles, `nm` people, `co` companies, `ev` events, `ch` characters, `ni` news
items. The prefixes narrow but do not settle the entity type — `tt` alone spans films,
series, episodes, and video games — so the scheme is polymorphically typed
([spec §7.3](../spec/07-representation-profiles.md)).

IMDb is admitted despite being T3 because it is the most pervasive film/TV identifier in
the wild: decades of citations, reviews, and cross-references use it, and refusing it
would discard real evidence.

## Admission criteria

1. **Stable, non-recycled identifiers** — IMDb IDs have been stable across nearly three
   decades of site history; removed records' IDs are not reassigned. The stability
   guarantee is de-facto (vendor practice) rather than contractual, which is part of
   why the scheme sits at T3.
2. **No restrictive licensing** — the identifier values themselves are open facts,
   freely cited and stored; it is the descriptive dataset behind them that is closed.
3. **Deterministic offline canonicalization** — URL stripping, case folding, and a shape
   check; no registry access.

## Canonical form

Lowercase: a recognized two-letter prefix followed by at least six digits.

```text
int:imdb:tt1375666
```

```abnf
imdb-value = prefix 6*DIGIT
prefix     = "tt" / "nm" / "co" / "ev" / "ch" / "ni"
```

## Canonicalization

1. Trim surrounding whitespace.
2. Strip one leading URL prefix matching `^https?://(www\.)?imdb\.com/(title|name)/`
   (case-insensitive).
3. Strip everything from the first remaining `/` onward.
4. Lowercase the result.
5. Accept only if the result matches `^(tt|nm|co|ev|ch|ni)[0-9]{6,}$`. Anything else is
   rejected.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `https://www.imdb.com/title/tt1375666/` | `tt1375666` |
| `TT1375666` | `tt1375666` |
| `https://www.imdb.com/name/nm0000138/` | `nm0000138` |
| `tt1375666` | `tt1375666` |
| `tt123` | **rejected** — fewer than six digits |
| `xx1375666` | **rejected** — unrecognized prefix |

## Ladder placement

Rung 3 of both [`movie`](../entity-types/movie.md) and
[`tv-series`](../entity-types/tv-series.md) — below [`wd`](./wd.md) and
[`tmdb`](./tmdb.md). This is the openness ordering rule in action
([spec §3.3.1](../spec/03-identity-classes.md)): within Class A, T1/T2 schemes must rank
above T3. An IMDb ID is not less accurate than a TMDB ID; it is less verifiable by
third parties, because only Amazon can confirm what it points to.

## Notes and limitations

- **Not P0 anchor-eligible** ([spec §7.2](../spec/07-representation-profiles.md)):
  polymorphic typing floors atoms at P1, with `@type` in the payload.
- **T3 means corroboration, not anchor.** Prefer `wd`/`tmdb` for new mints; keep `imdb`
  as evidence joining the cluster through equivalence
  ([spec §8](../spec/08-equivalence.md)). A tier change (the dataset opening) would be
  handled under [spec §3.3.2](../spec/03-identity-classes.md) without touching this
  canonicalization.
- **URL extraction covers `/title/` and `/name/` only.** Company, event, and character
  IDs are accepted as bare values but their URL forms are not parsed; extraction there
  is enrichment.
- **`tt` conflates levels.** Films, series, and individual episodes all live under
  `tt…`; the identifier does not distinguish the series/episode levels that the entity
  types separate.
- The digit count is not fixed: older IDs are seven digits, newer ones eight or more.
  Leading zeros are significant (`nm0000138` ≠ `nm138`).

## References

- [IMDb](https://www.imdb.com/)
- [IMDb non-commercial datasets](https://developer.imdb.com/non-commercial-datasets/) (subset exports; the full dataset remains closed)
