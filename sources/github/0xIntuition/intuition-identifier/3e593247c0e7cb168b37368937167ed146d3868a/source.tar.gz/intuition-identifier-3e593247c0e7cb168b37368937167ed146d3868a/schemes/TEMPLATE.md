# `<scheme>` — <Full name>

> Copy this file to `schemes/<scheme>.md` when proposing a new scheme, fill in every
> section, and open a pull request. See [CONTRIBUTING.md](../CONTRIBUTING.md) and
> [spec §9.4](../spec/09-registry-governance.md) for the full admission process.
> Delete this block in your copy.

| | |
| :-- | :-- |
| **Scheme** | `<scheme>` |
| **Identity class** | A — registered authority · B — intrinsic natural key · C — derived |
| **Openness tier** | T1 / T2 / T3 (Class A only; write — otherwise) |
| **Scheme typing** | Unambiguous / Polymorphic ([spec §7.3](../spec/07-representation-profiles.md)) |
| **Identifies** | One sentence: what one value of this scheme names, at which abstraction level |
| **Authority** | The registry or standard that guarantees uniqueness (Class A), or the mechanism that makes the key natural (Class B) |
| **Status** | Proposed |

## What it identifies

Two or three sentences. Be precise about the abstraction level ([spec §5.5](../spec/05-identity-ladders.md)):
does one value name a work, an edition, an account, a deployment? What does it *not* name?

## Admission criteria

How the scheme satisfies each criterion of [spec §9.2](../spec/09-registry-governance.md):

1. **Stable, non-recycled identifiers** — …
2. **No restrictive licensing** — …
3. **Deterministic offline canonicalization** — …

## Canonical form

The exact shape of a canonical value, as ABNF or a precise grammar, with one labelled example:

```text
int:<scheme>:<canonical value>
```

## Canonicalization

The ordered, pure, offline algorithm mapping raw input to the canonical value or to
*rejection*. Number every step. No network access, no clock, no locale, no configuration
([spec §0.3](../spec/00-overview.md), tenet 4).

1. …
2. …

## Test vectors

Normative ([spec §1.4](../spec/01-conformance.md)). Minimum five vectors, including at
least two rejections. Every accepted vector must be reproducible by the reference
implementation once ratified.

| Input | Canonical value |
| :-- | :-- |
| `…` | `…` |
| `…` | **rejected** — reason |

## Ladder placement

Which entity types' ladders gain a rung, and where ([spec §3.5](../spec/03-identity-classes.md)
ordering rules apply). Name the affected files under [`entity-types/`](../entity-types/).

## Notes and limitations

Known weaknesses, ambiguities, or scope boundaries — stated plainly. A scheme document
that hides its limitations will be asked to add them in review.

## References

Links to the underlying standard, registry documentation, or protocol specification.
