# The scheme registry

The governed list of schemes that may appear in `int:<scheme>:<value>`. Each scheme has
a normative document defining its grammar, canonicalization algorithm, and test vectors.

The registry is **closed**: a well-formed IID bearing an unregistered scheme is not a
valid IID, and validators must reject it
([spec §1.3.1](../spec/01-conformance.md), [§9.1](../spec/09-registry-governance.md)).
Once ratified, a scheme's canonicalization rules are frozen forever
([the freeze rule](../spec/09-registry-governance.md)). New schemes are additive only.

To propose a scheme: check the admission criteria
([spec §9.2](../spec/09-registry-governance.md)) and the
[rejected list](#rejected-schemes) below, then copy [`TEMPLATE.md`](./TEMPLATE.md) and
follow [`CONTRIBUTING.md`](../CONTRIBUTING.md).

A machine-readable export of this registry is published as
[`registry.json`](../registry.json).

> **Grammar convention.** The ABNF blocks in scheme documents write repetition with a
> space (`13 DIGIT`) for readability, where strict [RFC 5234](https://www.rfc-editor.org/rfc/rfc5234)
> writes `13DIGIT`. Where any grammar is ambiguous, the numbered canonicalization steps
> and the test vectors are normative.

## Class A — registered authorities

An external registry assigns the identifier and guarantees uniqueness. Within Class A,
open schemes (T1/T2) rank above proprietary ones (T3) in every ladder
([spec §3.3.1](../spec/03-identity-classes.md)).

| Scheme | Tier | Typing | Identifies | Authority |
| :-- | :-: | :-- | :-- | :-- |
| [`isbn`](./isbn.md) | T1 | unambiguous | a book edition | International ISBN Agency |
| [`isrc`](./isrc.md) | T1 | unambiguous | a sound/video recording | IFPI |
| [`iswc`](./iswc.md) | T1 | unambiguous | a musical composition | CISAC |
| [`isni`](./isni.md) | T1 | polymorphic | a public identity — person, band, org | ISNI International Agency |
| [`orcid`](./orcid.md) | T1 | polymorphic | a researcher | ORCID, Inc. |
| [`lei`](./lei.md) | T1 | unambiguous | a legal entity | GLEIF (ISO 17442) |
| [`gtin`](./gtin.md) | T1 | unambiguous | a trade item (product model) | GS1 |
| [`doi`](./doi.md) | T1 | polymorphic | a registered digital object | International DOI Foundation |
| [`eidr`](./eidr.md) | T1 | unambiguous | a film or TV work | EIDR Association |
| [`wd`](./wd.md) | T2 | polymorphic | anything Wikidata covers | Wikidata |
| [`mbid`](./mbid.md) | T2 | unambiguous | a music entity, typed in-value | MusicBrainz |
| [`olid`](./olid.md) | T2 | unambiguous | a book work/edition or author | OpenLibrary |
| [`imdb`](./imdb.md) | T3 | polymorphic | a film, series, or person | IMDb |
| [`tmdb`](./tmdb.md) | T2 | polymorphic | a film, series, or person | The Movie Database |
| [`podcastguid`](./podcastguid.md) | T2 | unambiguous | a podcast feed (show) | Podcasting 2.0 |

## Class B — intrinsic natural keys

The entity contains its own unique, verifiable identity; no registry is needed or
possible. All Class B schemes are offline-validatable by construction.

| Scheme | Typing | Identifies | Natural key |
| :-- | :-- | :-- | :-- |
| [`url`](./url.md) | polymorphic | a web resource | the resource's address |
| [`caip10`](./caip10.md) | polymorphic | a blockchain account or contract | the keypair / deployment |
| [`caip19`](./caip19.md) | unambiguous | an on-chain asset | chain + contract |
| [`hash`](./hash.md) | polymorphic | content, by digest of its bytes | the content bytes |
| [`appid`](./appid.md) | unambiguous | a mobile app per store | platform-enforced bundle ID |
| [`purl`](./purl.md) | unambiguous | a software package, version-free | ecosystem + name |
| [`geo`](./geo.md) | polymorphic | a geohash cell of the Earth | coordinates, quantized |
| [`acct`](./acct.md) | unambiguous | a platform account | the platform's immutable user ID |
| [`rssitem`](./rssitem.md) | unambiguous | a podcast feed item | feed GUID + item GUID |
| [`termset`](./termset.md) | unambiguous | a term within a term set | term set + term code |

## Class C — derived

No authority and no natural key exists; a canonicalized subset of the entity's own
attributes is hashed. Explicitly weak, visibly so, and expected to be superseded.

| Scheme | Typing | Value form | Algorithm |
| :-- | :-- | :-- | :-- |
| [`gen1`](./gen1.md) | unambiguous | `<entity-type-slug>:r<N>:<hash16>` | [spec §6](../spec/06-gen1.md) |

## Scheme typing and P0 eligibility

A scheme is *unambiguously typed* when knowing scheme + value implies the entity's type,
and only Class A/B schemes with unambiguous typing may be minted as bare P0 anchors
([spec §7.2–7.3](../spec/07-representation-profiles.md)). `gen1` is unambiguously typed
(the slug travels in the value) but is never P0-eligible — Class C floors at P1.

## Rejected schemes

Recorded so settled questions are not relitigated
([spec §9.5](../spec/09-registry-governance.md)). A rejection can be overturned by
changing the underlying fact — for example, a registry opening its licensing.

| Candidate | Rejected because |
| :-- | :-- |
| Google Place ID | Licensing restricts storage and republication (criterion 2) |
| OpenStreetMap element IDs | Unstable — split, merged, and renumbered by ordinary editing (criterion 1) |
| ENS names | Transferable — identifies whoever currently controls it, not a fixed entity (criterion 1) |
| Raw latitude/longitude | Measured, not assigned — observer-dependent values; superseded by [`geo`](./geo.md) |
| ISTC | Effectively defunct; negligible coverage |
| Social handles as primary | Renamed and recycled (criterion 1); retained as the documented weak form of [`acct`](./acct.md) |
