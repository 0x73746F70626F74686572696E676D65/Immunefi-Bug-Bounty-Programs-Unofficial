# `eidr` — Entertainment Identifier Registry

| | |
| :-- | :-- |
| **Scheme** | `eidr` |
| **Identity class** | A — registered authority |
| **Openness tier** | T1 — open standard, format-validatable offline |
| **Scheme typing** | Unambiguous — always an audiovisual creation |
| **Identifies** | One audiovisual record: a film or TV work, or an edit/manifestation of one |
| **Authority** | EIDR Association (DOI registrant `10.5240`) |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

An EIDR content ID names one **audiovisual record** in the industry's shared registry —
a movie, a TV series, a season, an episode, or a specific edit or manifestation of one.
The registry is hierarchical (work → edit → manifestation), so two EIDR values may name
the same film at different levels; all of them are unambiguously audiovisual, which is
what the scheme's typing asserts. EIDR is built on the DOI system: every EIDR is a DOI
under the prefix `10.5240`.

## Admission criteria

1. **Stable, non-recycled identifiers** — EIDR inherits DOI persistence: IDs are never
   reassigned, and superseded records are aliased to their survivors rather than
   deleted. The registry has operated since 2010 and is the studio/distributor supply
   chain's shared ID.
2. **No restrictive licensing** — EIDR IDs are resolvable public facts; the association
   places no restrictions on storing or republishing the identifiers.
3. **Deterministic offline canonicalization** — fixed grammar: prefix, five 4-hex-digit
   groups, and a check character, validatable with a single pattern.

## Canonical form

Uppercase: `10.5240/`, five hyphen-separated groups of four hex digits, a hyphen, and
one check character.

```text
int:eidr:10.5240/1F2A-E1C5-680A-14C6-E76B-I
```

```abnf
eidr-value = "10.5240/" 5(4 HEXDIG "-") check
check      = DIGIT / UPALPHA     ; ISO 7064 mod 37,36 check character
HEXDIG     = DIGIT / %x41-46     ; 0-9 A-F, uppercase
```

## Canonicalization

1. Trim surrounding whitespace.
2. Strip one leading resolver prefix matching `^https?://(dx\.)?doi\.org/`
   (case-insensitive).
3. Uppercase the result (EIDR renders hex and the check character uppercase).
4. Accept only if the result matches
   `^10\.5240/[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-Z]$`.
   Anything else is rejected.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `10.5240/1F2A-E1C5-680A-14C6-E76B-I` | `10.5240/1F2A-E1C5-680A-14C6-E76B-I` |
| `https://doi.org/10.5240/1F2A-E1C5-680A-14C6-E76B-I` | `10.5240/1F2A-E1C5-680A-14C6-E76B-I` |
| `10.5240/1f2a-e1c5-680a-14c6-e76b-i` | `10.5240/1F2A-E1C5-680A-14C6-E76B-I` |
| `10.5240/1F2A-E1C5-680A-14C6-E76B` | **rejected** — missing check character |
| `10.5240/1F2A-E1C5-680A-14C6-E76G-I` | **rejected** — `G` is not a hex digit |
| `10.1000/182` | **rejected** — not the EIDR DOI prefix |

## Ladder placement

Currently on **no ladder**. The scheme is registered and its identifiers are valid, but
neither [`movie`](../entity-types/movie.md) nor
[`tv-series`](../entity-types/tv-series.md) presently carries an `eidr` rung — both run
[`wd`](./wd.md) → [`tmdb`](./tmdb.md) → [`imdb`](./imdb.md) → `gen1`. Adding `eidr` to
those ladders (as the industry-authoritative T1 rung) is an open proposal.

## Notes and limitations

- **P0 anchor-eligible** ([spec §7.2](../spec/07-representation-profiles.md)): Class A
  and unambiguously typed — an EIDR is always an audiovisual creation.
- **The check character is shape-checked, not recomputed.** EIDR's final character is an
  ISO 7064 mod 37,36 check over the suffix, but the frozen canonicalizer validates only
  its presence and character class. A transcription error confined to the check position
  is not caught offline; under the freeze rule
  ([spec §9.3](../spec/09-registry-governance.md)) adding the computation would be a new
  scheme.
- **Levels within the hierarchy are distinct IDs.** The abstract work and a specific
  edit carry different EIDRs; convergence to the work level is the equivalence layer's
  job ([spec §8](../spec/08-equivalence.md)).
- **DOI overlap.** The same identifier lowercased is a valid [`doi`](./doi.md) value.
  Prefer `eidr` for audiovisual entities; equivalence joins the forms when both exist.

## References

- [EIDR ID Format](https://www.eidr.org/documents/EIDR_ID_Format_v1.3.pdf), EIDR Association
- [eidr.org](https://www.eidr.org/)
- ISO 26324:2022 — Digital Object Identifier system (the underlying registry)
