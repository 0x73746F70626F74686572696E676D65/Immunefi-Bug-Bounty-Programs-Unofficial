# `lei` — Legal Entity Identifier

| | |
| :-- | :-- |
| **Scheme** | `lei` |
| **Identity class** | A — registered authority |
| **Openness tier** | T1 — open standard, offline-validatable |
| **Scheme typing** | Unambiguous — always a legal entity |
| **Identifies** | One legal entity (a company, fund, branch, or other registered organization) |
| **Authority** | GLEIF (ISO 17442) |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

An LEI names one **legal entity** — the registered organization itself, as recognized in
law. It does not name a brand, a product line, a website, or a corporate group: each
legally distinct subsidiary carries its own LEI, and the parent-child relationships
between them are relationship data, not identity.

## Admission criteria

1. **Stable, non-recycled identifiers** — LEIs are issued once per legal entity and
   never reassigned, under a G20-mandated system operated by GLEIF since 2014. A lapsed
   registration still identifies the same entity.
2. **No restrictive licensing** — GLEIF publishes the entire LEI dataset under CC0;
   storage and republication are unrestricted.
3. **Deterministic offline canonicalization** — the ISO 7064 mod 97-10 check digits make
   every value self-validating with no registry access.

## Canonical form

Twenty characters, uppercase: eighteen alphanumeric characters followed by two check
digits.

```text
int:lei:5493001KJTIIGC8Y1R12
```

```abnf
lei-value = 18 upalnum 2 DIGIT   ; ISO 7064 mod 97-10 must validate
upalnum   = UPALPHA / DIGIT
```

## Canonicalization

1. Strip all hyphens, spaces, and dots from the input. Uppercase the result.
2. Accept only if the result matches `^[A-Z0-9]{18}[0-9]{2}$`. Anything else is
   rejected.
3. Validate ISO 7064 mod 97-10 over the full twenty characters: process the string left
   to right, replacing each letter with its two-digit value (`A` = 10 … `Z` = 35) and
   keeping digits as-is; fold each resulting decimal digit `d` into a running remainder
   `r = (r × 10 + d) mod 97`, starting from `r = 0`. The value is valid if and only if
   the final remainder is 1. Reject on failure.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `5493001KJTIIGC8Y1R12` | `5493001KJTIIGC8Y1R12` |
| `5493001kjtiigc8y1r12` | `5493001KJTIIGC8Y1R12` |
| `HWUPKR0MPOU8FGXBT394` | `HWUPKR0MPOU8FGXBT394` |
| `5493001KJTIIGC8Y1R13` | **rejected** — mod 97-10 checksum fails |
| `5493001KJTIIGC8Y1R1` | **rejected** — 19 characters, not 20 |
| `5493001KJTIIGC8Y1RAB` | **rejected** — check positions must be digits |

## Ladder placement

Currently on **no ladder**. [`company`](../entity-types/company.md) presently rungs
[`wd`](./wd.md), then `url`, then `gen1`; adding `lei` at the top of `company` — where
it would be the most precise legal-entity identifier — is an open proposal. The scheme
remains valid for direct minting and as equivalence evidence.

## Notes and limitations

- **P0 anchor-eligible** ([spec §7.2](../spec/07-representation-profiles.md)): Class A
  and unambiguously typed — an LEI is always a legal entity.
- **Registration status is not identity.** An LEI whose annual renewal lapses is marked
  `LAPSED` in GLEIF data but keeps identifying the same entity forever. Entity events
  (mergers, dissolutions) are recorded against the LEI, never by reassigning it.
- **Coverage skews financial.** LEI issuance is driven by financial-reporting mandates;
  most small businesses and many large private companies have none and fall through to
  lower rungs.
- **Legal entity ≠ brand.** "Alphabet Inc." and "Google LLC" are different LEIs; the
  consumer-facing brand is a separate atom linked by triples.

## References

- ISO 17442:2020 — Legal Entity Identifier
- [LEI structure](https://www.gleif.org/en/about-lei/iso-17442-the-lei-code-structure), GLEIF
- [GLEIF data licensing (CC0)](https://www.gleif.org/en/meta/lei-data-terms-of-use)
