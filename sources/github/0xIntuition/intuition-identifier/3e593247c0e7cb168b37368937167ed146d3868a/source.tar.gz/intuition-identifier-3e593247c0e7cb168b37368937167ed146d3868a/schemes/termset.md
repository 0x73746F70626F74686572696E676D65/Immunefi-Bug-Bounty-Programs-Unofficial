# `termset` — Defined term within a term set

| | |
| :-- | :-- |
| **Scheme** | `termset` |
| **Identity class** | B — intrinsic natural key |
| **Openness tier** | — (Class B: no registry; offline-validatable by construction) |
| **Scheme typing** | Unambiguous — always a defined term |
| **Identifies** | One term inside one term set: a hash of the set plus the term's code |
| **Authority** | The term set's publisher — a glossary, taxonomy, or vocabulary guarantees one entry per term code within itself |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

A `termset` value names one **defined term** — an entry in a glossary, controlled
vocabulary, or taxonomy, mirroring schema.org's `DefinedTerm` /
`inDefinedTermSet` / `termCode` model. The identified level is the term *within its
set*: "merkle tree" as defined in one glossary is a different entity from "merkle tree"
as defined in another, because the definitions — the whole point of a defined term —
differ. The scoping hash makes that explicit.

What it does *not* name: the concept in the abstract (that is closer to `wd` territory)
or the term set itself (an entity of its own).

## Admission criteria

1. **Stable, non-recycled identifiers** — a term code is stable within a published
   vocabulary; publishers version vocabularies rather than reassign codes. The set
   scoping means one publisher's code churn cannot affect another's terms.
2. **No restrictive licensing** — term codes and set names are open facts.
3. **Deterministic offline canonicalization** — construction is NORM-1 plus a keccak
   hash and slugification; validation is a shape check. No network access anywhere.

## Canonical form

`<hash16>:<term-slug>` — 32 lowercase hex characters identifying the set, a colon, and
the slugified term code:

```text
int:termset:f3f11679d904850c042fafedbee6d3ec:merkle-tree
```

```abnf
termset-value = hash16 ":" term-slug
hash16        = 32( DIGIT / %x61-66 )                 ; keccak16 of NORM-1(term set)
term-slug     = ldigit *( ldigit / "-" )              ; no leading/trailing hyphen
ldigit        = %x61-7A / DIGIT
```

### Value production

The value is **built upstream** by ladder machinery from the entity's declared fields:

```text
set-hash  = keccak16(NORM-1(inDefinedTermSet))        ; the set's URL, or its name
term-slug = NORM-1(termCode), then every run of characters outside [a-z0-9]
            replaced by "-", then leading/trailing "-" stripped
value     = set-hash + ":" + term-slug
```

`keccak16` is the first 16 bytes of keccak-256 as lowercase hex; `NORM-1` is the frozen
normalization algorithm ([spec §4](../spec/04-normalization.md)). An empty slug after
stripping means the rung does not fire. The set is hashed because set designators are
arbitrary-length URLs or names; the term code is kept readable (as a slug) because it
is short, and readability aids debugging.

Example: set `https://example.com/glossary` hashes to
`f3f11679d904850c042fafedbee6d3ec`; term code `Merkle Tree` slugifies to
`merkle-tree`; together they form the canonical value shown above.

## Canonicalization

The canonicalizer **validates shape only** — it does not re-derive the set hash and
does not re-slugify:

1. Trim surrounding whitespace and lowercase.
2. Match `^([0-9a-f]{32}):([a-z0-9][a-z0-9-]*)$` — 32 hex characters, a colon, and a
   slug that starts with a letter or digit. Reject on failure.
3. Emit `hash16:term-slug`.

Note the slug grammar forbids a leading hyphen but the regex above alone does not
forbid a trailing one; conforming producers never emit one because the slugifier strips
both ends.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `f3f11679d904850c042fafedbee6d3ec:merkle-tree` | `f3f11679d904850c042fafedbee6d3ec:merkle-tree` |
| `F3F11679D904850C042FAFEDBEE6D3EC:Merkle-Tree` | `f3f11679d904850c042fafedbee6d3ec:merkle-tree` |
| `f3f11679d904850c042fafedbee6d3ec:-merkle` | **rejected** — slug starts with a hyphen |
| `merkle-tree` | **rejected** — no set-hash segment |
| `f3f11679d904850c042fafedbee6d3ec:merkle tree` | **rejected** — space in slug |
| `abcd:merkle-tree` | **rejected** — set hash is not 32 hex chars |

## Ladder placement

Rung 1 of [`defined-term`](../entity-types/defined-term.md), above a `gen1` recipe over
the term's name.

## Notes and limitations

- **Set designation must be consistent.** The set hash is over whatever string the
  source provides — ideally the set's URL, else its name. Two sources designating one
  set differently ("NIST Glossary" vs its URL) derive different set hashes and
  therefore different term identifiers, converging only via equivalence. Producers
  SHOULD prefer the set's canonical URL whenever one exists.
- **Slugification is lossy.** Distinct term codes can collapse onto one slug (`A/B`
  and `A B` both slugify to `a-b`). Within a well-run vocabulary such pairs are
  unlikely, and the set scoping confines any collision to a single set; the residual
  risk is accepted.
- **The set hash is one-way evidence.** Verifying it requires recomputing
  `keccak16(NORM-1(set))` from the claimed set designator carried in the P1 payload —
  offline, by anyone.
- **Per-set scoping is the honest level.** A cross-glossary "the concept" identifier
  would assert that two definitions mean the same thing, which is an attestable claim,
  not a derivable fact.

## References

- [schema.org DefinedTerm](https://schema.org/DefinedTerm) — the source model (`inDefinedTermSet`, `termCode`)
- [spec §4 — NORM-1](../spec/04-normalization.md)
- [The Keccak reference](https://keccak.team/keccak.html) — keccak-256, truncated to 16 bytes
