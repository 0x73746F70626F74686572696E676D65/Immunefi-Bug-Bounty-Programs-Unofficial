# `purl` — Package URL

| | |
| :-- | :-- |
| **Scheme** | `purl` |
| **Identity class** | B — intrinsic natural key |
| **Openness tier** | — (Class B: no registry; offline-validatable by construction) |
| **Scheme typing** | Unambiguous — always a software package |
| **Identifies** | One package: an ecosystem plus a name, version-free |
| **Authority** | The Package URL specification plus each ecosystem's own name uniqueness (npm, PyPI, crates.io, … each enforce one package per name) |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

A `purl` value names one **package**: `npm/react` is the React package on npm, across
all of its versions. The IID identifies the package, not a release — version lineage is
a different abstraction level ([spec §5.5](../spec/05-identity-ladders.md)), and pinning
identity to a version would mint a new entity for every patch release. Accordingly, the
canonicalizer strips any version, qualifier, or subpath from the input.

The same library published to two ecosystems is two identifiers (`npm/foo` and
`pypi/foo` are independently claimed names), joined at the project level by the
equivalence layer where warranted.

## Admission criteria

1. **Stable, non-recycled identifiers** — package names are effectively permanent in
   the major ecosystems; several (npm, crates.io) explicitly prohibit or heavily
   restrict name reuse after unpublishing. Residual reuse risk exists in smaller
   ecosystems and is noted below.
2. **No restrictive licensing** — the purl spec is Apache/MIT-licensed and package
   coordinates are open facts.
3. **Deterministic offline canonicalization** — prefix and version stripping plus
   casefolding, no registry access.

## Canonical form

A Package URL with the constant `pkg:` prefix dropped and everything from the version
onward removed, lowercased:

```text
int:purl:npm/react
```

```abnf
purl-value = type "/" name-part
type       = 1*( %x61-7A / DIGIT / "." / "+" / "-" )   ; npm, pypi, cargo, github, ...
name-part  = 1*( %x21-7E )                              ; may itself contain "/"
```

The `pkg:` prefix is dropped because it is constant — it carries no information inside
a scheme that is already named `purl`.

## Canonicalization

1. Trim surrounding whitespace.
2. Strip one leading `pkg:` prefix (case-insensitive), if present.
3. Truncate at the first `@`, `?`, or `#` — removing the version, qualifiers, and
   subpath in one cut. The IID identifies the package, not a release.
4. Reject unless the remainder matches `^[a-z0-9.+-]+\/[^\s]+$` case-insensitively: an
   ecosystem type, a slash, and a non-empty name part with no whitespace.
5. Lowercase the entire value.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `pkg:npm/react@18.2.0` | `npm/react` |
| `npm/react` | `npm/react` |
| `pkg:pypi/Django@4.2.1` | `pypi/django` |
| `pkg:github/anthropics/anthropic-sdk-typescript@v1?checksum=abc` | `github/anthropics/anthropic-sdk-typescript` |
| `react` | **rejected** — no ecosystem type |
| `pkg:npm/` | **rejected** — empty name |

## Ladder placement

Rung 1 of [`software`](../entity-types/software.md) — the purl (an open spec over
ecosystem-enforced names) ranks above the repository URL, which migrates when projects
move hosts, and above the `gen1` name recipe.

## Notes and limitations

- **Scoped and namespaced names must arrive purl-encoded.** In a spec-compliant purl,
  an npm scope's `@` is percent-encoded (`pkg:npm/%40angular/core@12.0.0`
  → `npm/%40angular/core`). A raw `npm/@angular/core` fed to this canonicalizer would
  be truncated at the `@` and rejected for its empty name — inputs are expected to be
  purls, not npm install strings.
- **Blanket lowercasing is stricter than the purl spec**, which makes case rules
  type-specific (npm and PyPI names are case-insensitive; a few ecosystems are not).
  Two packages in one ecosystem distinguished only by case would collide here. The
  major registries prohibit exactly such pairs, so the simplification is accepted.
- **Name reuse is ecosystem policy, not mathematics.** The stability guarantee is only
  as strong as the registry's unpublish/reclaim rules. The large ecosystems are strict;
  treat purls from lax ecosystems with correspondingly less confidence.
- **Version stripping is unconditional.** A consumer wanting release-level identity
  needs a different scheme; this one deliberately cannot express it.
- The name part may contain further slashes (`github/anthropics/anthropic-sdk-typescript`);
  parsers must not assume a single slash.

## References

- [Package URL specification](https://github.com/package-url/purl-spec)
- [purl type definitions](https://github.com/package-url/purl-spec/blob/master/PURL-TYPES.rst) — per-ecosystem name rules
- [npm package name guidelines](https://docs.npmjs.com/package-name-guidelines)
