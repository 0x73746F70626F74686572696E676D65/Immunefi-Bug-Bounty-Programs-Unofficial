# `mbid` — MusicBrainz Identifier

| | |
| :-- | :-- |
| **Scheme** | `mbid` |
| **Identity class** | A — registered authority |
| **Openness tier** | T2 — community registry, open data |
| **Scheme typing** | Unambiguous — the entity type is a segment of the value |
| **Identifies** | One MusicBrainz entity: an artist, recording, release, release group, work, or label |
| **Authority** | MusicBrainz (MetaBrainz Foundation) |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

An `mbid` value names one **MusicBrainz entity**, and says which kind in the value
itself: `artist:…`, `recording:…`, `release:…`, `release-group:…`, `work:…`, or
`label:…`. The type segment is mandatory because MusicBrainz guarantees UUID uniqueness
only **within** an entity type — the same UUID could in principle exist as both an
artist and a release. A bare UUID is therefore not an identifier in this scheme.

MusicBrainz models music at several levels; the segment selects the level: an artist
identity, a specific recording (the [`isrc`](./isrc.md) level), a release group (the
album as a work), a concrete release (one pressing), a composition (`work`, the
[`iswc`](./iswc.md) level), or a label.

## Admission criteria

1. **Stable, non-recycled identifiers** — MBIDs are permanent UUIDs; merged entities
   leave redirecting MBIDs that remain valid forever, and MBIDs are never reassigned.
   The database has operated since 2000.
2. **No restrictive licensing** — MusicBrainz core data, MBIDs included, is published
   under CC0 with full database dumps.
3. **Deterministic offline canonicalization** — segment whitelist plus UUID shape check;
   no registry access.

## Canonical form

The entity-type segment, a colon, and a lowercase RFC 4122-shaped UUID.

```text
int:mbid:artist:056e4f3e-d505-4dad-8ec1-d04f521cbb56
```

```abnf
mbid-value  = entity-type ":" uuid
entity-type = "artist" / "recording" / "release" / "release-group" / "work" / "label"
uuid        = 8 lhex "-" 4 lhex "-" 4 lhex "-" 4 lhex "-" 12 lhex
lhex        = DIGIT / %x61-66    ; lowercase hex
```

## Canonicalization

1. Trim surrounding whitespace and lowercase the input.
2. Match against
   `^(?:https?://musicbrainz\.org/)?([a-z-]+)[/:]([0-9a-f-]{36})$` — an optional
   `musicbrainz.org` URL prefix, an entity-type segment, `/` or `:`, and a 36-character
   candidate UUID. Reject if there is no match.
3. Reject unless the entity-type segment is one of `artist`, `recording`, `release`,
   `release-group`, `work`, `label`.
4. Reject unless the candidate matches the UUID shape
   `^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$`.
5. Emit `<entity-type>:<uuid>`.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `https://musicbrainz.org/artist/056e4f3e-d505-4dad-8ec1-d04f521cbb56` | `artist:056e4f3e-d505-4dad-8ec1-d04f521cbb56` |
| `artist:056e4f3e-d505-4dad-8ec1-d04f521cbb56` | `artist:056e4f3e-d505-4dad-8ec1-d04f521cbb56` |
| `ARTIST:056E4F3E-D505-4DAD-8EC1-D04F521CBB56` | `artist:056e4f3e-d505-4dad-8ec1-d04f521cbb56` |
| `artist/056e4f3e-d505-4dad-8ec1-d04f521cbb56` | `artist:056e4f3e-d505-4dad-8ec1-d04f521cbb56` |
| `056e4f3e-d505-4dad-8ec1-d04f521cbb56` | **rejected** — bare UUID, no entity-type segment |
| `song:056e4f3e-d505-4dad-8ec1-d04f521cbb56` | **rejected** — not a recognized entity type |
| `artist:056e4f3e-d505-4dad-8ec1` | **rejected** — not a full UUID |

## Ladder placement

- Rung 1 of [`music-album`](../entity-types/music-album.md) (`release-group` MBIDs are
  the album-as-work level).
- Rung 2 of [`music-group`](../entity-types/music-group.md), below
  [`isni`](./isni.md).
- Rung 2 of [`music-recording`](../entity-types/music-recording.md), below
  [`isrc`](./isrc.md), which names the recording itself more precisely
  ([spec §3.5](../spec/03-identity-classes.md), rule 3).

## Notes and limitations

- **P0 anchor-eligible** ([spec §7.2](../spec/07-representation-profiles.md)): Class A,
  and the in-value type segment makes the scheme unambiguously typed.
- **Merges leave multiple MBIDs per entity.** Community editing merges duplicates; old
  MBIDs redirect and remain valid. Two MBIDs for one artist is an equivalence cluster
  ([spec §8](../spec/08-equivalence.md)), not an error.
- **The segment whitelist is frozen.** MusicBrainz has further entity types (area,
  place, series, event, instrument); admitting them would be a registry change under
  [spec §9.4](../spec/09-registry-governance.md), not an edit to this scheme.
- **The ladder does not consume every segment.** `release` and `work` MBIDs are valid
  identifiers with no current ladder rung (no release-level or composition-level entity
  type is ratified); they remain usable for direct minting and as evidence.

## References

- [MusicBrainz Identifier](https://musicbrainz.org/doc/MusicBrainz_Identifier), MetaBrainz Foundation
- [MusicBrainz database licensing (CC0 core data)](https://metabrainz.org/datasets)
- RFC 4122 — A Universally Unique IDentifier (UUID) URN Namespace
