# `isni` — International Standard Name Identifier

| | |
| :-- | :-- |
| **Scheme** | `isni` |
| **Identity class** | A — registered authority |
| **Openness tier** | T1 — open standard, offline-validatable |
| **Scheme typing** | Polymorphic — persons, bands, personas, organizations |
| **Identifies** | One public identity: a person, stage persona, band, or organization |
| **Authority** | ISNI International Agency (ISO 27729) |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

An ISNI names one **public identity** — the named party that appears in creative and
commercial records. That party may be an individual human, a pseudonym or stage persona,
a band, or an organization. One human who publishes under two personas may hold two
ISNIs; this is the scheme working as designed. Because a bare value does not say which
kind of party it names, the scheme is polymorphically typed
([spec §7.3](../spec/07-representation-profiles.md)).

## Admission criteria

1. **Stable, non-recycled identifiers** — ISNIs are assigned once by the ISNI agency
   network and never reassigned; the registry has operated since 2011 and bridges most
   major library and rights databases.
2. **No restrictive licensing** — ISNI values are open facts published in library
   authority files; storage and republication are unrestricted.
3. **Deterministic offline canonicalization** — the ISO 7064 check character makes every
   value self-validating with no registry access.

## Canonical form

Sixteen characters, no separators: fifteen digits plus an ISO 7064 mod 11-2 check
character (`0`–`9` or `X`).

```text
int:isni:0000000121032683
```

```abnf
isni-value = 15 DIGIT check
check      = DIGIT / %x58        ; "X" when the checksum renders 10
```

## Canonicalization

1. Strip all hyphens, spaces, and dots from the input. Uppercase the result (the check
   character may arrive as `x`).
2. Accept only if the result matches `^[0-9]{15}[0-9X]$`. Anything else — including
   `isni.org` URLs — is rejected; extracting a value from a resolver URL is enrichment,
   done before canonicalization.
3. Validate the ISO 7064 mod 11-2 check character over the first fifteen digits: start
   with `total = 0`; for each digit `d`, set `total = (total + d) × 2`; then
   `remainder = total mod 11` and `check = (12 − remainder) mod 11`, rendering 10 as
   `X`. The value is valid if and only if this equals the sixteenth character. Reject
   on failure.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `0000000121032683` | `0000000121032683` |
| `0000 0001 2103 2683` | `0000000121032683` |
| `0000-0001-2103-2683` | `0000000121032683` |
| `000000012146438X` | `000000012146438X` |
| `0000000121032684` | **rejected** — check character fails |
| `000000012103268` | **rejected** — 15 characters, not 16 |
| `https://isni.org/isni/0000000121032683` | **rejected** — URLs are not canonicalized |

## Ladder placement

- Rung 1 of [`person`](../entity-types/person.md).
- Rung 1 of [`music-group`](../entity-types/music-group.md).

## Notes and limitations

- **Not P0 anchor-eligible** ([spec §7.2](../spec/07-representation-profiles.md)):
  polymorphic typing means a bare ISNI does not imply the entity's type. Atoms floor at
  P1, carrying `@type` in the payload.
- **ORCID overlap.** ORCID iDs are allocated from a reserved block of the ISNI number
  space, so a researcher's ORCID validates under this scheme's grammar too. `isni` and
  [`orcid`](./orcid.md) remain distinct schemes; when both forms of one identity are
  minted, the equivalence layer joins them ([spec §8](../spec/08-equivalence.md)).
- **Identity, not person.** Multiple ISNIs per human (personas) and one ISNI per band
  are by design; person-level convergence is equivalence-layer work.
- The displayed form `0000 0001 2103 2683` is presentation only; the canonical value
  never carries separators.

## References

- ISO 27729:2012 — International Standard Name Identifier
- [isni.org](https://isni.org/) — ISNI International Agency
- ISO/IEC 7064:2003 — check character systems (mod 11-2)
