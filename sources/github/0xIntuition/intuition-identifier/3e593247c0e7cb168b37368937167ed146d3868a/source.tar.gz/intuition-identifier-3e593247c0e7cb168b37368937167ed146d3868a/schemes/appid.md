# `appid` — Mobile application identifier

| | |
| :-- | :-- |
| **Scheme** | `appid` |
| **Identity class** | B — intrinsic natural key |
| **Openness tier** | — (Class B: no registry; offline-validatable by construction) |
| **Scheme typing** | Unambiguous — always a mobile application |
| **Identifies** | One app within one store ecosystem |
| **Authority** | Store-enforced uniqueness — Apple and Google each guarantee that a bundle ID / package name maps to exactly one app in their ecosystem |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

An `appid` value names one **app in one store ecosystem**: `ios:` plus an Apple bundle
identifier, or `android:` plus an Android package name. The identified level is the app,
not a version, build, or listing page.

The same product shipped on both platforms is **two identifiers** — `ios:com.spotify.client`
and `android:com.spotify.music` are separate technical artifacts with independently
assigned native IDs — joined at the product level by the equivalence layer
([spec §8](../spec/08-equivalence.md)). This is per-ecosystem scoping working as
designed, not a failure to deduplicate.

Class B status is honest here: the uniqueness guarantee comes from a platform vendor
rather than from mathematics, but the identifier is intrinsic to the artifact (it is
baked into the binary and immutable for the app's lifetime), there is no public registry
to query, and canonicalization is fully offline.

## Admission criteria

1. **Stable, non-recycled identifiers** — neither store permits changing an app's
   bundle ID / package name after first publication, and neither reassigns a published
   identifier to a different developer's app.
2. **No restrictive licensing** — bundle IDs and package names are open facts, visible
   in every store URL and on-device.
3. **Deterministic offline canonicalization** — casefolding and shape validation, no
   store access.

## Canonical form

`<store>:<native-id>`, where the store is one of the frozen set **`ios`**,
**`android`**, and the native ID is casefolded to lowercase:

```text
int:appid:android:com.spotify.music
```

```abnf
appid-value = store ":" bundle-id
store       = "ios" / "android"
bundle-id   = 1*( %x61-7A / DIGIT / "." / "_" / "-" )   ; lowercase
```

## Canonicalization

1. Trim surrounding whitespace.
2. Match `^([a-z]+):(.+)$` case-insensitively — a letters-only store label, a colon,
   and the rest. Reject on failure.
3. Lowercase the store label; reject unless it is exactly `ios` or `android`. The store
   set is frozen with the scheme.
4. Lowercase the native ID; reject unless it matches `^[a-z0-9._-]+$` after folding.
5. Emit `store:bundle-id`.

Casefolding is safe because both platforms treat identifier case as non-distinguishing
for uniqueness: neither store will host two apps whose IDs differ only by case.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `android:com.spotify.music` | `android:com.spotify.music` |
| `IOS:com.Apple.Music` | `ios:com.apple.music` |
| `ios:com.burbn.instagram` | `ios:com.burbn.instagram` |
| `windows:com.foo` | **rejected** — store not in the frozen set |
| `android:com spotify` | **rejected** — space in the native ID |
| `com.spotify.music` | **rejected** — no store prefix |

## Ladder placement

Rung 1 of [`mobile-application`](../entity-types/mobile-application.md), above a
store-URL fallback (`url`) and a `gen1` recipe over name + operating system.

## Notes and limitations

- **The store set is frozen at `ios` and `android`.** Desktop and console stores
  (Windows, Steam, …) are out of scope for this scheme; admitting one would change
  which inputs canonicalize and is therefore a governance action, not an edit
  ([spec §9.3](../spec/09-registry-governance.md)).
- **Per-ecosystem scoping is the identified level.** There is no cross-platform "the
  app" identifier in this scheme, deliberately: no intrinsic key exists at that level,
  and inventing one would be a derived (Class C) statement.
- **Numeric App Store IDs are not accepted.** Apple's numeric track IDs (`id324684580`)
  identify listings, are store-front-scoped in tooling, and are redundant with the
  bundle ID; the bundle ID is the identifier the artifact itself carries.
- **De-listing does not recycle.** An app removed from a store keeps its identifier;
  the value remains a stable name for the (now unavailable) app. However, Apple does
  allow a *developer who owns* a never-shipped bundle ID to delete and re-register it;
  for published apps — the only ones this scheme is minted for — IDs are permanent.

## References

- [Apple: CFBundleIdentifier](https://developer.apple.com/documentation/bundleresources/information_property_list/cfbundleidentifier)
- [Android: application ID / package name](https://developer.android.com/build/configure-app-module#set-application-id)
- Google Play policy: the package name is fixed once an app is published
