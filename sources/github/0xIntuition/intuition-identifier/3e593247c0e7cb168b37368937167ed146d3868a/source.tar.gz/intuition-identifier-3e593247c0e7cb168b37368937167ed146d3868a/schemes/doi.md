# `doi` — Digital Object Identifier

| | |
| :-- | :-- |
| **Scheme** | `doi` |
| **Identity class** | A — registered authority |
| **Openness tier** | T1 — open standard, offline-canonicalizable |
| **Scheme typing** | Polymorphic — articles, datasets, books, films (via EIDR), … |
| **Identifies** | One registered digital object, at whatever level its registrant chose |
| **Authority** | International DOI Foundation (ISO 26324) |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

A DOI names one **registered object** — whatever a registration agency's customer chose
to register: a journal article, a dataset, a book chapter, a preprint, a standard, or
(under the EIDR agency's `10.5240` prefix) a film. The abstraction level is the
registrant's choice, not the scheme's, which is why the scheme is polymorphically typed
([spec §7.3](../spec/07-representation-profiles.md)): a bare DOI does not say what kind
of thing it names.

## Admission criteria

1. **Stable, non-recycled identifiers** — DOIs are persistent by the system's founding
   contract: once registered, a DOI is never reassigned, and agencies commit to
   maintaining resolution. The system has operated since 2000.
2. **No restrictive licensing** — DOI values are open facts printed on every modern
   paper; storage and republication are unrestricted.
3. **Deterministic offline canonicalization** — prefix stripping, case folding, and a
   shape check; DOIs are defined case-insensitive, so lowercasing loses nothing.

## Canonical form

Lowercase, no resolver prefix: the directory indicator `10.`, a 4–9 digit registrant
prefix, `/`, and the registrant-chosen suffix.

```text
int:doi:10.48550/arxiv.1706.03762
```

```abnf
doi-value = "10." 4*9 DIGIT "/" 1*VCHAR   ; suffix: any non-whitespace characters
```

## Canonicalization

1. Trim surrounding whitespace.
2. Strip one leading resolver prefix matching `^https?://(dx\.)?doi\.org/`
   (case-insensitive).
3. Strip one leading `doi:` label (case-insensitive).
4. Lowercase the result (ISO 26324 defines DOIs as case-insensitive).
5. Accept only if the result matches `^10\.[0-9]{4,9}/\S+$`. Anything else is rejected.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `https://doi.org/10.48550/ARXIV.1706.03762` | `10.48550/arxiv.1706.03762` |
| `doi:10.1000/182` | `10.1000/182` |
| `10.1103/PhysRev.47.777` | `10.1103/physrev.47.777` |
| `http://dx.doi.org/10.1000/182` | `10.1000/182` |
| `10.48550` | **rejected** — no suffix |
| `10.123/abc` | **rejected** — registrant prefix must be 4–9 digits |
| `https://doi.org/` | **rejected** — empty after prefix stripping |

## Ladder placement

- Rung 1 of [`article`](../entity-types/article.md), sourced from the article's `url`
  field (a DOI pasted where a URL goes canonicalizes here first).
- Rung 1 of [`dataset`](../entity-types/dataset.md), sourced from `sameAs`.

## Notes and limitations

- **Not P0 anchor-eligible** ([spec §7.2](../spec/07-representation-profiles.md)):
  polymorphic typing floors atoms at P1, with `@type` in the payload.
- **No check digit.** The suffix is opaque; validation is shape-only, and a well-formed
  wrong value passes.
- **Percent-encoding can fork values.** The canonicalizer does not URL-decode: a DOI
  suffix copied out of an encoded URL (`%2F` for `/`, etc.) canonicalizes to a
  different string than the plain form. Decoding is enrichment, done before
  canonicalization.
- **EIDR overlap.** An EIDR is a DOI under prefix `10.5240` and will canonicalize here
  (lowercased). Film and TV should mint [`eidr`](./eidr.md) — uppercase, shape-checked
  — with equivalence joining the forms if both exist
  ([spec §8](../spec/08-equivalence.md)).
- **One work, many DOIs** (preprint vs. published version, mirrored datasets).
  Version-level identity is the registered granularity; work-level convergence is the
  equivalence layer's job.

## References

- ISO 26324:2022 — Digital Object Identifier system
- [DOI Handbook](https://www.doi.org/the-identifier/resources/handbook/), International DOI Foundation
- [Crossref DOI display guidelines](https://www.crossref.org/display-guidelines/) (resolver-URL presentation)
