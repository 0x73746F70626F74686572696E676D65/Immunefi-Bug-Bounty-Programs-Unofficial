# `isbn` — International Standard Book Number

| | |
| :-- | :-- |
| **Scheme** | `isbn` |
| **Identity class** | A — registered authority |
| **Openness tier** | T1 — open standard, offline-validatable |
| **Scheme typing** | Unambiguous — always a book edition |
| **Identifies** | One edition of a published book |
| **Authority** | International ISBN Agency (ISO 2108) |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

An ISBN names one **edition** — a specific published form of a book. The hardcover, the
paperback, and the ebook of one work each carry a different ISBN.

Note that the [`book`](../entity-types/book.md) entity type identifies the **work**, and
uses the best available edition ISBN as its primary identifier; other editions attach to
the same work cluster through the equivalence layer ([spec §5.5](../spec/05-identity-ladders.md),
[§8](../spec/08-equivalence.md)).

## Admission criteria

1. **Stable, non-recycled identifiers** — ISBNs are assigned once and never reassigned;
   the agency network has operated since 1970.
2. **No restrictive licensing** — ISBN values are open facts; storage and republication
   are unrestricted.
3. **Deterministic offline canonicalization** — the check digit makes every value
   self-validating with no registry access.

## Canonical form

A hyphen-free **ISBN-13**: exactly 13 digits with a valid GS1 check digit.

```text
int:isbn:9780684832722
```

```abnf
isbn-value = 13 DIGIT        ; GS1 mod-10 check digit must validate
```

ISBN-10 is never a canonical form: every ISBN-10 has an exact ISBN-13 equivalent, and
admitting both would give one edition two identifiers.

## Canonicalization

1. Strip all hyphens, spaces, and dots from the input. Uppercase the result (an ISBN-10
   check digit may be `x`).
2. **If the result matches `^[0-9]{9}[0-9X]$`** (ISBN-10):
   1. Validate the ISBN-10 check digit (mod-11, weights 10…2; remainder 10 renders as
      `X`). Reject on failure.
   2. Convert to ISBN-13: prefix the first nine digits with `978`, then append the GS1
      mod-10 check digit computed over those twelve digits.
3. **If the result matches `^[0-9]{13}$`** (ISBN-13): validate the GS1 mod-10 check
   digit. Reject on failure.
4. Anything else is rejected.

The GS1 mod-10 check digit over a payload: from the rightmost payload digit leftward,
weight digits 3, 1, 3, 1, …; the check digit is `(10 − (sum mod 10)) mod 10`.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `0-684-83272-0` | `9780684832722` |
| `978-0-684-83272-2` | `9780684832722` |
| `097522980X` | `9780975229804` |
| `9780684832722` | `9780684832722` |
| `9780684832720` | **rejected** — ISBN-13 check digit fails |
| `0684832721` | **rejected** — ISBN-10 check digit fails |
| `12345` | **rejected** — not 10 or 13 digits |

## Ladder placement

Rung 1 of [`book`](../entity-types/book.md).

## Notes and limitations

- **Pre-1970 books have no ISBN.** Older works fall through to `olid`, `wd`, or `gen1`
  rungs on the `book` ladder.
- **One work, many ISBNs.** This is the scheme working as designed — the edition is the
  identified level — but it means ISBN equality is not work equality. Work-level
  convergence is the equivalence layer's job.
- **Publisher misuse exists** (reused ISBNs for distinct titles, mostly self-publishing).
  The identifier layer does not detect this; it is a data-quality dispute handled above
  ([spec §8.5](../spec/08-equivalence.md)).
- A 979-prefixed ISBN-13 has no ISBN-10 form; step 2 only ever produces 978-prefixed
  values.

## References

- ISO 2108:2017 — International Standard Book Number
- [ISBN Users' Manual](https://www.isbn-international.org/content/isbn-users-manual), International ISBN Agency
- [GS1 check digit calculator](https://www.gs1.org/services/check-digit-calculator) (the mod-10 algorithm)
