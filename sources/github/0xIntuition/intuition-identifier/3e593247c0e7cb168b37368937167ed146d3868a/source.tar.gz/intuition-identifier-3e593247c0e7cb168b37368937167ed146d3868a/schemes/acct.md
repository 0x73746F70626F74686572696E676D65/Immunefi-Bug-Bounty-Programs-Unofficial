# `acct` — Platform account

| | |
| :-- | :-- |
| **Scheme** | `acct` |
| **Identity class** | B — intrinsic natural key |
| **Openness tier** | — (Class B: no registry; offline-validatable by construction) |
| **Scheme typing** | Unambiguous — always an account on a platform |
| **Identifies** | One account on one platform — strong form by immutable user ID, weak form by handle |
| **Authority** | Platform-enforced uniqueness — each platform guarantees one account per internal user ID |
| **Status** | Ratified · frozen under [spec §9.3](../spec/09-registry-governance.md) |

## What it identifies

An `acct` value names one **account on one platform**, in the spirit of RFC 7565's
`acct:` URI. The account is the entity; the human or organization behind it is a
separate atom, linked by a triple — one person operates many accounts, and some
accounts are operated by teams or bots.

The scheme has two forms with deliberately different strength:

- **Strong form** — `<platform>:<user-id>`: the platform's *immutable internal user
  ID* (`x:295218901`, `farcaster:3`). These survive renames and are never reassigned.
- **Weak form** — `<platform>:@<handle>`: the public handle, marked by `@` and folded
  with `NORM-1` ([spec §4](../spec/04-normalization.md)). Handles rename and get
  recycled — `github:@torvalds` names whoever holds that handle, historically not
  always the same account — so the weak form ranks a rung lower and exists only
  because the numeric ID is frequently unobtainable.

The platform prefix is a **governed lowercase slug** (`x`, `github`, `farcaster`,
`instagram`, …), maintained with the registry; it namespaces the value so IDs from
different platforms cannot collide.

## Admission criteria

1. **Stable, non-recycled identifiers** — true of the strong form by platform policy on
   every admitted platform. The weak form does not satisfy this criterion, is labelled
   accordingly (`@`), and ranks below the strong form; handles-as-primary was
   explicitly rejected.
2. **No restrictive licensing** — account identifiers are open facts.
3. **Deterministic offline canonicalization** — casefolding and shape validation, no
   platform access.

## Canonical form

```text
int:acct:x:295218901          (strong)
int:acct:github:@torvalds     (weak)
```

```abnf
acct-value = platform ":" ( user-id / "@" handle )
platform   = 1*( %x61-7A / DIGIT / "-" )     ; governed lowercase slug
user-id    = 1*VCHAR                          ; platform-native, case-preserved
handle     = 1*VCHAR                          ; NORM-1 folded
```

## Canonicalization

The composite value is **produced upstream**: ladder machinery builds
`platform + ":" + platformUserId` (strong) or `platform + ":@" + username` (weak) from
the entity's declared fields. The canonicalizer then validates and folds:

1. Trim surrounding whitespace.
2. Match `^([a-z0-9-]+):(@?)(.+)$` case-insensitively — a platform slug, an optional
   `@` marking the weak form, and the identifier. Reject on failure.
3. Lowercase the platform slug.
4. **Weak form** (`@` present): apply `NORM-1` to the handle — NFKC, punctuation
   folding, full case folding, trim, whitespace collapse.
5. **Strong form**: pass the user ID through byte-for-byte. Platform IDs may be
   case-sensitive; folding them would corrupt valid values
   ([spec §4.6](../spec/04-normalization.md)).
6. Reject if the resulting identifier is empty or contains whitespace.
7. Emit `platform:` + (`@` if weak) + identifier.

## Test vectors

| Input | Canonical value |
| :-- | :-- |
| `x:295218901` | `x:295218901` |
| `X:295218901` | `x:295218901` |
| `farcaster:3` | `farcaster:3` |
| `github:@Torvalds` | `github:@torvalds` |
| `GitHub:@Torvalds` | `github:@torvalds` |
| `x:has space` | **rejected** — whitespace in identifier |
| `torvalds` | **rejected** — no platform prefix |
| `x:` | **rejected** — empty identifier |

## Ladder placement

Rungs 1 (strong) and 2 (weak) of
[`social-media-account`](../entity-types/social-media-account.md) — the only two rungs;
an account with neither an ID nor a handle is not identifiable.

## Notes and limitations

- **The weak form is honestly weak.** A handle identifies whoever currently holds it.
  When a handle is recycled, old and new owners' data converge on one identifier until
  a strong-form identifier separates them. The visible `@` exists so consumers can see
  which guarantee they are getting; upgrading weak to strong is the standard ladder
  upgrade path ([spec §5.4](../spec/05-identity-ladders.md)).
- **Platform slugs are governed, not validated.** The canonicalizer accepts any
  well-shaped slug; an unregistered platform produces a value no conforming producer
  should mint. Slug admission (and renames like twitter→`x`) is a registry concern.
- **The identifier charset is loosely validated** — anything non-empty without
  whitespace passes, so a degenerate strong ID such as `x:@` (identifier `@`) shape-
  validates. Producing sensible native IDs is the upstream builder's responsibility.
- **NORM-1 can emit non-ASCII** (a handle like `@josé` folds but stays non-ASCII), and
  the IID grammar then rejects the value at the grammar layer
  ([spec §2.2](../spec/02-grammar.md)). Platforms whose handles are ASCII — the large
  majority — are unaffected.
- **One person ≠ one account.** Clustering a person's accounts is triple-and-
  equivalence territory, never an identifier merge.

## References

- [RFC 7565 — The 'acct' URI Scheme](https://www.rfc-editor.org/rfc/rfc7565) — the design inspiration
- [spec §4 — NORM-1](../spec/04-normalization.md), applied to the weak form's handle
- Platform ID documentation: [X user ID](https://developer.x.com/en/docs/x-api/users/lookup/introduction), [GitHub user ID](https://docs.github.com/en/rest/users), [Farcaster FID](https://docs.farcaster.xyz/learn/what-is-farcaster/accounts)
