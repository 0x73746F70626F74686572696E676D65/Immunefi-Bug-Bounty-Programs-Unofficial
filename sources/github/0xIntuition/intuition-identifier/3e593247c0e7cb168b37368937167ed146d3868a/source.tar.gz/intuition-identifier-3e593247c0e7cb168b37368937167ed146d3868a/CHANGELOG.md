# Changelog

All notable changes to the Intuition Identifier specification are recorded here.
Version semantics are defined in [spec §1.5](./spec/01-conformance.md): new schemes,
new recipe rungs, and ladder reorderings are MINOR; editorial clarifications are PATCH;
grammar changes are MAJOR; edits to ratified canonicalization rules are not permitted
([the freeze rule](./spec/09-registry-governance.md)).

## 0.1.0 — 2026-08-11

Initial public draft.

- The specification: grammar (`int:<scheme>:<value>`, byte-exact comparison), identity
  classes A/B/C with openness tiers T1/T2/T3, the frozen `NORM-1` normalization
  algorithm, identity ladders, the `gen1` derived scheme, representation profiles
  P0/P1/P2, the informative equivalence chapter, and registry governance — with the
  identity/interpretation boundary stated explicitly (§0.2, §7.7): the spec fixes
  which string names a thing, never what a consuming system makes of it.
- The abstract atom-creation model (§7.8): an atom is created from an identity
  payload plus an optional companion-metadata channel (URI entries — URLs,
  content-addressed references, inline strings). Metadata never enters identifier
  derivation and is never required for identity operations; atoms whose identifiers
  are opaque (`hash`, `gen1`, `rssitem`, `termset`, `geo`) should publish resolution
  context there. The MultiVault's URI array field is the reference transport.
- The scheme registry: 26 ratified schemes (15 Class A, 10 Class B, `gen1` as Class C),
  each with a normative document and executable test vectors; six rejected candidates
  recorded with reasons.
- The entity-type registry: 36 ratified identity ladders with frozen `gen1` recipe
  tags; `aggregate-rating` recorded as withdrawn (remodeled as a claim).
- `registry.json` and `test-vectors.json` machine-readable exports (regenerated from
  the normative markdown; all 170 vectors verified against the reference
  implementation), with CI (`scripts/check.mjs`) keeping registries, documents, site,
  and vectors in lockstep.
- The site (`docs/`): live `gen1` derivation and an IID inspector implementing the
  full validation pipeline client-side.
- Community scaffolding: contribution guide, governance, templates; everything
  licensed MIT.
