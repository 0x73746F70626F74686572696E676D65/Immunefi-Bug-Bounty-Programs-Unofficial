<!-- One logical change per PR. See CONTRIBUTING.md. -->

## What this changes

## Change type and version impact (spec §1.5)

- [ ] Editorial — no behavioural effect (PATCH)
- [ ] New scheme (MINOR) — full document from `schemes/TEMPLATE.md`, ≥ 5 verified vectors incl. ≥ 2 rejections, ladder placement stated, `schemes/README.md` + `registry.json` updated
- [ ] Ladder change / new entity type / new `gen1` recipe (MINOR) — `entity-types/` + `registry.json` updated; new recipe tags are next-unused and frozen
- [ ] Implementation listing (`implementations.md`)
- [ ] Site (`docs/`)
- [ ] Other:

## For normative changes

**Which MUST/SHOULD/MAY consequences change:**

**Test vectors verified how** (reference implementation run, or worked derivation shown below — never invented):

## Checklist

- [ ] No edit to any ratified canonicalization rule (freeze rule, spec §9.3)
- [ ] All links resolve; indexes updated where a change surfaces
- [ ] Voice matches the existing documents: plain, precise, limitations stated
