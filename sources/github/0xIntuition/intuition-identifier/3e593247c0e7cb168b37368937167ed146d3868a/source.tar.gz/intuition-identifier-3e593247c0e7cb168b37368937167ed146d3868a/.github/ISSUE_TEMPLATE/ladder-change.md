---
name: Ladder change / new entity type
about: Propose adding a rung, reordering a ladder, or adding an entity type
title: "[ladder] <entity type>: <change>"
labels: ladder-change
---

<!--
Ladders are deliberately NOT frozen: adding a rung or reordering is a MINOR change that
only affects what a fresh mint produces, and never invalidates an existing identifier
(spec §1.5.1). gen1 recipe tags, however, are frozen at creation (spec §6.4) — a new
recipe gets the next unused tag, and existing tags are never renumbered.
-->

## Entity type

Existing `entity-types/<slug>.md`, or the proposed new slug.

## Change

- [ ] Add a scheme rung
- [ ] Add a `gen1` recipe rung
- [ ] Reorder existing rungs
- [ ] New entity type

Describe the change and the resulting full ladder, strongest first.

## Justification

Why this ordering, against the rules of spec §3.5 (class A > B > C; T1/T2 above T3;
more precise identification above less; more fields above fewer).

For a `gen1` recipe: confirm every field passes spec §5.6 — no related-entity names, no
observer/time/source-dependent values, no personal data as disambiguators, no network
access, scalar fields only.

For a new entity type: what does it identify, at which abstraction level (spec §5.5),
and why is no existing type the right home?

## Evidence

What data motivates this? Coverage numbers, fork examples, or real entities that
currently land on a weaker rung than they could.
