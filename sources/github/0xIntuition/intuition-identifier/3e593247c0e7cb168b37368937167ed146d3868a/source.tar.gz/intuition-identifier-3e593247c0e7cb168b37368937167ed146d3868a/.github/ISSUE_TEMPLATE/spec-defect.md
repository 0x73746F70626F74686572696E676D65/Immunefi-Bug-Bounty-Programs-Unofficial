---
name: Spec defect
about: Report an ambiguity, contradiction, or vector/prose disagreement
title: "[defect] <short description>"
labels: spec-defect
---

<!--
Ambiguity is a defect. If you implemented a rule and had to guess, that guess is exactly
what we want reported. If a test vector and the prose of a scheme document disagree,
neither takes precedence (spec §1.4) — report it so intent can be re-established.
-->

## Where

Spec section / scheme document / entity-type document and line.

## What the spec says

Quote the relevant text (or the two passages that conflict).

## What is ambiguous or wrong

What did you expect, what did you find, and — if you were implementing — what did you
have to decide on your own?

## Suggested resolution (optional)

Note: if the defect is in a ratified canonicalization rule, the fix cannot be an
in-place edit (freeze rule, spec §9.3) — resolution will be an erratum documenting the
frozen behaviour, or a versioned successor.
