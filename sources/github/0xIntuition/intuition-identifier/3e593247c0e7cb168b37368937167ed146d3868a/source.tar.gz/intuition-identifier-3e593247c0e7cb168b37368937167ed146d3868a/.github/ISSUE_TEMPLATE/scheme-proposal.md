---
name: Scheme proposal
about: Propose a new identifier scheme for the registry
title: "[scheme] <proposed scheme name>"
labels: scheme-proposal
---

<!--
Before filing: check schemes/README.md — including the REJECTED list — so we don't
relitigate settled questions. The normative admission process is spec/09-registry-governance.md.
Filing this issue before writing the full document is encouraged: maintainers can flag
admission problems early and save you work.
-->

## Proposed scheme

**Name** (lowercase, `a-z0-9-`, ≤ 32 chars):

**What one value identifies** (one sentence, precise about abstraction level):

**Identity class**: A (registered authority) / B (intrinsic natural key)

**Openness tier** (Class A only): T1 / T2 / T3

**Scheme typing**: unambiguous / polymorphic — does knowing scheme + value imply the entity's type?

## Admission criteria (spec §9.2)

1. **Stable, non-recycled identifiers** — who guarantees stability, and is a value ever reassigned?

2. **No restrictive licensing** — can values legally be stored and republished in a public knowledge graph? Link the licensing terms.

3. **Deterministic offline canonicalization** — sketch the pure-function canonicalization. Any step that needs a network, a clock, or configuration disqualifies the scheme (that step may be legal as *enrichment*, before derivation).

## Why the existing registry is insufficient

Which entities currently fall through to weaker rungs that this scheme would identify?

## Example values

Three to five real raw inputs and their expected canonical forms.

## Proposed ladder placement

Which entity types gain a rung, and where (justify against spec §3.5 ordering).
