# Security policy

This repository contains a specification and a static site — there is no service to
attack and no dependency chain to poison. But specification defects can have security
consequences for systems that implement it: a canonicalization ambiguity can let two
implementations disagree about whether two identifiers match, and an attacker can turn
such a disagreement into spoofing, split-brain state, or a poisoned equivalence edge.

## Reporting

**Ambiguities with security consequences** — anything that could make two conforming
implementations disagree about identifier validity, equality, or derivation — may be
reported privately if you believe public disclosure would put implementers at risk:
use [GitHub private vulnerability reporting](https://github.com/0xIntuition/intuition-identifier/security/advisories/new)
on this repository. Otherwise, an ordinary
[spec-defect issue](https://github.com/0xIntuition/intuition-identifier/issues/new?template=spec-defect.md)
is preferred — this specification's defects are normally fixed in the open.

**Vulnerabilities in the reference implementation** (`@0xintuition/iid`) or other
Intuition software should be reported to the affected repository, not here.

## What to expect

- Acknowledgement within 7 days.
- Under the [freeze rule](./spec/09-registry-governance.md), a defect in a ratified
  canonicalization cannot be patched in place. Resolution takes the form of an erratum
  in [`implementation-notes.md`](./implementation-notes.md) documenting the frozen
  behaviour, guidance to implementers, and — where warranted — a versioned successor
  scheme.
- The trust and adversarial model for the identifier layer itself (squatting, false
  identifiers, poisoned equivalence edges) is documented in
  [spec §8.5](./spec/08-equivalence.md); those are protocol-layer concerns, not
  reportable defects in this specification.
