#!/usr/bin/env node
/**
 * Repository consistency checks (CI entry point). Zero dependencies.
 *
 *   node scripts/check.mjs
 *
 * 1. registry.json parses, and every ladder rung references a registered scheme.
 * 2. Every relative markdown link resolves to an existing file.
 * 3. test-vectors.json is a faithful re-extraction of the scheme documents.
 * 4. All test vectors pass against the site's ported canonicalizers
 *    (docs/index.html), keeping the site and the spec in lockstep.
 * 5. Registry counts agree everywhere they are claimed.
 *
 * These checks cannot replace verification against the reference
 * implementation (@0xintuition/iid) — new or changed vectors MUST be verified
 * against it before merge, per CONTRIBUTING.md.
 */
import { execFileSync } from 'node:child_process';
import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
let failures = 0;
const fail = (msg) => { failures++; console.error(`FAIL  ${msg}`); };
const ok = (msg) => console.log(`ok    ${msg}`);

/* 1 — registry.json */
const registry = JSON.parse(readFileSync(join(root, 'registry.json'), 'utf8'));
const schemeNames = Object.keys(registry.schemes);
for (const [slug, et] of Object.entries(registry.entityTypes)) {
  for (const rung of et.rungs ?? []) {
    if (rung.kind === 'scheme' && !registry.schemes[rung.scheme]) {
      fail(`registry.json: ${slug} references unregistered scheme "${rung.scheme}"`);
    }
  }
}
ok(`registry.json: ${schemeNames.length} schemes, ${Object.keys(registry.entityTypes).length} entity types, rung references valid`);

/* 2 — markdown links */
let links = 0, broken = 0;
const walk = (dir) => readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
  if (e.name.startsWith('.') || e.name === 'node_modules') return [];
  const p = join(dir, e.name);
  return e.isDirectory() ? walk(p) : p.endsWith('.md') ? [p] : [];
});
for (const file of walk(root)) {
  const text = readFileSync(file, 'utf8');
  // strip code spans/fences so regex-looking code is not mistaken for links
  const stripped = text.replace(/```[\s\S]*?```/g, '').replace(/`[^`\n]*`/g, '');
  for (const m of stripped.matchAll(/\]\(([^)#\s]+)(#[^)\s]*)?\)/g)) {
    const target = m[1];
    if (/^(https?:|mailto:)/.test(target)) continue;
    links++;
    if (!existsSync(resolve(dirname(file), target))) {
      broken++;
      fail(`${file}: broken link -> ${target}`);
    }
  }
}
if (!broken) ok(`markdown links: ${links} relative links resolve`);

/* 3 — test-vectors.json freshness */
try {
  execFileSync(process.execPath, [join(root, 'scripts/extract-vectors.mjs'), '--check'], { stdio: 'pipe' });
  ok('test-vectors.json: current with schemes/*.md');
} catch {
  fail('test-vectors.json is stale — run: node scripts/extract-vectors.mjs');
}

/* 4 — vectors vs the site's ported canonicalizers */
const html = readFileSync(join(root, 'docs/index.html'), 'utf8');
const script = html.match(/<script>\n([\s\S]*)\n<\/script>/)[1];
const require = createRequire(import.meta.url);
const mod = { exports: {} };
new Function('module', 'exports', 'require', script)(mod, mod.exports, require);
const { CANON, REGISTRY } = mod.exports;
const { vectors } = JSON.parse(readFileSync(join(root, 'test-vectors.json'), 'utf8'));
let vecFail = 0;
for (const v of vectors) {
  const got = CANON[v.scheme](v.input);
  const want = v.canonical ?? undefined;
  if (got !== want) {
    vecFail++;
    fail(`site canonicalizer ${v.scheme}(${JSON.stringify(v.input)}) = ${JSON.stringify(got)}, spec says ${JSON.stringify(want)}`);
  }
}
if (!vecFail) ok(`site canonicalizers: ${vectors.length}/${vectors.length} vectors pass`);

/* 5 — count agreement */
const schemeDocs = readdirSync(join(root, 'schemes')).filter((f) => f.endsWith('.md') && !['README.md', 'TEMPLATE.md'].includes(f));
const typeDocs = readdirSync(join(root, 'entity-types')).filter((f) => f.endsWith('.md') && f !== 'README.md');
const ratifiedTypes = Object.values(registry.entityTypes).filter((t) => t.status === 'ratified').length;
const checks = [
  [schemeDocs.length === schemeNames.length && schemeNames.length === Object.keys(REGISTRY).length, `scheme count: ${schemeDocs.length} docs = ${schemeNames.length} registry.json = ${Object.keys(REGISTRY).length} site`],
  [typeDocs.length === ratifiedTypes, `entity-type count: ${typeDocs.length} docs = ${ratifiedTypes} ratified in registry.json`],
  [html.includes(`<b>${schemeNames.length}</b>schemes`), `site stats: scheme count ${schemeNames.length}`],
  [html.includes(`<b>${ratifiedTypes}</b>entity types`), `site stats: entity-type count ${ratifiedTypes}`],
  [html.includes(`<b>${vectors.length}</b>verified test vectors`), `site stats: vector count ${vectors.length}`],
];
for (const [pass, msg] of checks) pass ? ok(msg) : fail(msg);

console.log(failures ? `\n${failures} check(s) failed` : '\nall checks passed');
process.exit(failures ? 1 : 0);
