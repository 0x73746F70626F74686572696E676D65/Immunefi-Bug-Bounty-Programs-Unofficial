#!/usr/bin/env node
/**
 * Regenerate test-vectors.json from the normative "Test vectors" tables in
 * schemes/*.md. The markdown documents are normative; this export is a
 * convenience for implementers and MUST be regenerated (never hand-edited)
 * when a scheme document changes.
 *
 *   node scripts/extract-vectors.mjs        # writes test-vectors.json
 *   node scripts/extract-vectors.mjs --check  # verifies the file is current
 */
import { readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const schemesDir = join(root, 'schemes');
const outPath = join(root, 'test-vectors.json');

/** Split one markdown table row into trimmed cells. */
function cells(row) {
  return row.replace(/^\|/, '').replace(/\|\s*$/, '').split(' | ').map((c) => c.trim());
}

/** Strip a single backtick wrapping; returns undefined if not code-formatted. */
function unquote(cell) {
  const m = cell.match(/^`(.+)`$/s);
  return m ? m[1] : undefined;
}

const vectors = [];
const files = readdirSync(schemesDir).filter((f) => f.endsWith('.md') && !['README.md', 'TEMPLATE.md'].includes(f)).sort();

for (const file of files) {
  const scheme = file.replace(/\.md$/, '');
  const text = readFileSync(join(schemesDir, file), 'utf8');
  const section = text.split(/^## Test vectors$/m)[1]?.split(/^## /m)[0];
  if (!section) throw new Error(`${file}: no "## Test vectors" section`);

  for (const line of section.split('\n')) {
    if (!line.startsWith('|') || /^\|\s*:?--/.test(line) || /^\|\s*Input\s*\|/i.test(line)) continue;
    const row = cells(line);
    if (row.length !== 2) throw new Error(`${file}: unexpected table row: ${line}`);
    const input = unquote(row[0]);
    if (input === undefined) throw new Error(`${file}: input cell is not code-formatted: ${line}`);
    if (/^\*\*rejected\*\*/.test(row[1])) {
      const reason = row[1].replace(/^\*\*rejected\*\*\s*(—|-)?\s*/, '');
      vectors.push({ scheme, input, canonical: null, reason });
    } else {
      const canonical = unquote(row[1]);
      if (canonical === undefined) throw new Error(`${file}: expected \`canonical\` or **rejected**: ${line}`);
      vectors.push({ scheme, input, canonical });
    }
  }
}

const payload = {
  description:
    'Machine-readable export of the normative test vectors in schemes/*.md. The markdown documents are normative; regenerate with scripts/extract-vectors.mjs, never hand-edit. canonical: null means the input MUST be rejected.',
  specVersion: JSON.parse(readFileSync(join(root, 'registry.json'), 'utf8')).specVersion,
  count: vectors.length,
  vectors,
};
const serialized = JSON.stringify(payload, null, 2) + '\n';

if (process.argv.includes('--check')) {
  const current = readFileSync(outPath, 'utf8');
  if (current !== serialized) {
    console.error('test-vectors.json is stale — run: node scripts/extract-vectors.mjs');
    process.exit(1);
  }
  console.log(`test-vectors.json is current (${vectors.length} vectors)`);
} else {
  writeFileSync(outPath, serialized);
  console.log(`wrote test-vectors.json: ${vectors.length} vectors across ${files.length} schemes`);
}
