# Implementation notes

This file records every known place where the reference implementation
([`@0xintuition/iid`](./implementations.md)) and this specification disagree. Per
[spec §1.4](./spec/01-conformance.md), such a disagreement is a defect: it is recorded
here — with both the specified behaviour and the current behaviour — rather than
silently repaired, because under the [freeze rule](./spec/09-registry-governance.md) a
ratified canonicalizer cannot be patched in place.

## Format

Each entry states:

- **Where** — the spec section and scheme affected.
- **Specified** — what the specification says.
- **Implemented** — what the reference implementation currently does.
- **Disposition** — how the divergence will be resolved (spec erratum, documented
  frozen behaviour, or a versioned successor scheme).

## Known divergences

None currently recorded.

The reference implementation's known deliberate scope boundaries (not divergences):

- **`url` percent-encoding normalization.** The registry document for
  [`url`](./schemes/url.md) describes percent-encoding normalization as performed by the
  WHATWG URL parser the reference implementation delegates to. Implementations in other
  languages must use a WHATWG-conformant URL parser to match its output byte-for-byte.
- **Ladder coverage.** Some ratified ladders have rungs that cannot fire until their
  source fields exist in upstream data (documented per entity type as open proposals).
  This is data availability, not a spec divergence.
