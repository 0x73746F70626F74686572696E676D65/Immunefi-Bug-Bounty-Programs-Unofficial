# Maintainers

| Name | GitHub | Role |
| :-- | :-- | :-- |
| Kames | [@kamescg](https://github.com/kamescg) | Maintainer, editor (v0.1.x) |

See [`GOVERNANCE.md`](./GOVERNANCE.md) for what maintainers do and how to become one.
