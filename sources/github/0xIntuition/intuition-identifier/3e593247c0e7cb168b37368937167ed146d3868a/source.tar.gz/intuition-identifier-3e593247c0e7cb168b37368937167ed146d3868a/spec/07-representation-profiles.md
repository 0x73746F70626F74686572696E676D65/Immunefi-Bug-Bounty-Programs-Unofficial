# 7. Representation profiles

---

## 7.1 The question profiles answer

An IID names an entity. A separate question is **how much data travels alongside it** in the atom that carries it.

Both extremes are wrong. Carrying nothing but the identifier makes weak identifiers unverifiable and unrenderable. Carrying a full descriptive payload makes atom data — and therefore the atom's on-chain ID — depend on how much a particular minter happened to know, which forks the atom for one entity across sources.

The resolution is that **an atom's payload should scale with the entity's ambiguity**. A strong, self-describing identifier needs nothing else. A weak derived identifier needs the evidence it was derived from.

Three profiles, all serializations of the same identity. The identity payload is also
not the only channel an atom has: creation may publish **companion metadata** alongside
it, outside identity entirely ([§7.8](#78-the-atom-creation-model-data-and-companion-metadata)).

## 7.2 The profiles

### P0 — anchor

Atom data is the **bare IID string**, nothing else.

```text
int:isbn:9780684832722
```

This yields a property that nothing else does:

```text
atomId = calculateAtomId(iid)
```

Identity becomes a pure function of the identifier. Two parties who derive the same IID mint *literally the same atom*, with zero coordination and no reliance on any indexer, projection, or off-chain agreement. Deduplication happens at the protocol layer, for free.

**Eligibility.** An IID MAY be minted as P0 only if **both** hold:

1. Its scheme is Class **A or B**. Class C never qualifies ([§6.6](./06-gen1.md)).
2. Its scheme is **unambiguously typed** ([§7.3](#73-scheme-typing)) — the identifier implies the entity's type on its own.

### P1 — identity context

Atom data is an object containing the type, the identifier, the identity-recipe fields, and any corroborating evidence.

```json
{
  "@context": "https://schema.org/",
  "@type": "Movie",
  "identifier": "int:gen1:movie:r4:fb681afe7d438cad73ae90a70f1cc55a",
  "name": "Inception",
  "yearPublished": "2010"
}
```

P1 is the **REQUIRED floor** for:

- **Class C identifiers** — the recipe fields are the hash's preimage evidence. Without them the identifier cannot be verified or re-derived, and there is nothing to display.
- **Polymorphically typed schemes** — a bare `int:wd:Q42` does not say whether Q42 is a person, a book, or a concept. The `@type` must live in the payload.

### P2 — enriched

Atom data is the full descriptive shape: P1 plus descriptions, images, dates, `sameAs` references, and any other schema.org properties the entity type declares.

```json
{
  "@context": "https://schema.org/",
  "@type": "Movie",
  "identifier": "int:wd:Q25188",
  "name": "Inception",
  "datePublished": "2010-07-16",
  "sameAs": [
    "https://www.imdb.com/title/tt1375666/",
    "https://www.themoviedb.org/movie/27205-inception",
    "https://www.wikidata.org/wiki/Q25188"
  ]
}
```

P2 is **opt-in**. Descriptive metadata belongs primarily to enrichment, claims, and open registries rather than to the identity payload — every field added to atom data is a field that can differ between two minters of the same entity, and each such difference is one more atom to reconcile later.

## 7.3 Scheme typing

A scheme is **unambiguously typed** if knowing an identifier's scheme and value is sufficient to know the entity's type. It is **polymorphic** otherwise.

| Typing | Schemes |
| :-- | :-- |
| **Unambiguous** | `isbn`, `isrc`, `iswc`, `lei`, `gtin`, `eidr`, `mbid`, `olid`, `podcastguid`, `caip19`, `appid`, `purl`, `acct`, `rssitem`, `termset`, `gen1` |
| **Polymorphic** | `isni`, `orcid`, `doi`, `wd`, `imdb`, `tmdb`, `url`, `caip10`, `hash`, `geo` |

Some schemes are unambiguous because their domain is narrow: an ISBN is always a book edition, an ISRC always a sound recording. Others carry the type inside the value: `mbid` values begin with an entity-type segment (`artist:`, `recording:`), `olid` values end with `W`/`M`/`A`, and `gen1` values begin with the entity type's slug.

The polymorphic cases are polymorphic for concrete reasons:

| Scheme | Why polymorphic |
| :-- | :-- |
| `wd` | Wikidata covers every kind of thing |
| `isni` / `orcid` | Assigned to persons *and* to bands and organizations |
| `doi` | Articles, datasets, and — via EIDR — films |
| `imdb` / `tmdb` | Values span films, series, and people |
| `url` | A URL can address anything |
| `caip10` | An address may be an account or a contract |
| `hash` | A digest of any content type |
| `geo` | A cell may be a location or a business's premises |

Note that `gen1` is unambiguously typed but still never P0-eligible — it fails the Class A/B requirement. Typing and class are independent conditions and both must hold.

## 7.4 Profiles and clustering

> **The same IID at any profile means one cluster.**

A P0 anchor for `int:isbn:9780684832722` and a P2 enriched atom carrying the same identifier are the same entity. The equivalence layer joins them with no claim required ([§8.2](./08-equivalence.md)).

Within such a cluster, two distinct roles are elected:

| Role | Which member | Used for |
| :-- | :-- | :-- |
| **Identity-canonical** | The P0 anchor, when one exists | The target of triples; the convergence point new claims attach to |
| **Display-canonical** | The richest attested member | What applications render by default |

Separating these matters. The anchor is the stable thing to point at — it never changes and is derivable by anyone. The display choice can improve over time as better-attested descriptions arrive, without ever moving the target that existing claims reference.

## 7.5 Requirements

1. An implementation MUST NOT mint P0 for a Class C identifier.
2. An implementation MUST NOT mint P0 for a polymorphically typed scheme.
3. An implementation MUST include the recipe fields when minting a Class C identifier.
4. Profiles are **additive**. Introducing or preferring a profile MUST NOT require re-minting anything that already exists.
5. An implementation consuming atoms MUST accept all three profiles for any entity type.
6. Companion metadata ([§7.8](#78-the-atom-creation-model-data-and-companion-metadata)) MUST NOT enter identifier derivation: no ladder rung and no `gen1` recipe field may reference it.
7. An implementation consuming atoms MUST NOT require companion metadata in order to validate, compare, or cluster — every identity operation works on the identity payload alone.
8. When minting an atom whose identifier is opaque ([§7.8.2](#782-opaque-identifiers-need-published-context)), an implementation SHOULD publish resolution context as companion metadata whenever it holds any.

## 7.6 Choosing a profile

Non-normative guidance:

- If the identifier is anchor-eligible and the goal is a stable point for claims to attach to — **P0**. It is the cheapest atom possible and the only one with protocol-level dedupe.
- If the identifier is Class C, or the scheme is polymorphic — **P1**. This is a floor, not a preference; it is the minimum that is verifiable and renderable.
- If the atom is the primary record for an entity and descriptive data must be on-chain rather than in enrichment — **P2**. Prefer to justify this case rather than default to it.

## 7.7 Payloads carry evidence, not interpretation

The P1 and P2 examples in this chapter use schema.org's `@context` and `@type`. That is
the convention of the reference deployment, and for good reason — it is the most widely
implemented open vocabulary — but its role in this specification is narrow: the payload
fields exist as **identity evidence** (the recipe fields that verify a `gen1` hash, the
`@type` that disambiguates a polymorphic scheme), not as a mandated ontology.

**Interpretation is the consumer's.** Once an atom exists, what a backend makes of it —
which vocabulary it maps the entity into, which type system it applies, how it
contextualizes, renders, and ranks — is entirely that backend's choice, and different
consumers of the same graph may legitimately choose differently. Two applications can
read the atom anchored by `int:isbn:9780684832722` through two unrelated schemas and
still converge on the same atom, attach claims to the same point, and interoperate at
the identity layer — because identity and interpretation are separate layers, and this
specification deliberately governs only the first.

This separation of concerns is the point. The identifier layer is strict, minimal, and
frozen so that everything above it — interpretation engines, ontologies, product
surfaces — can be modular, opinionated, and replaceable without ever fragmenting the
graph underneath.

## 7.8 The atom creation model: data and companion metadata

Everything above governs one thing: the atom's **identity payload** — the data field
from which identity derives. This section names the second channel that atom creation
carries, and draws the line between the two. The model is abstract and
transport-independent: it holds identically whether atoms live in a smart contract, a
TypeScript service, a database, or a file. What follows describes concepts, not any
particular contract's calldata.

### 7.8.1 The model

Creating an atom involves up to two inputs:

| Channel | Contents | Governed by |
| :-- | :-- | :-- |
| **Identity payload** (the data field) | The P0/P1/P2 serialization defined in this chapter, embedding exactly one IID | This specification — deterministic, minimal, frozen |
| **Companion metadata** (zero or more URI entries) | Context that does not belong in identity: where to fetch the referent, related artifacts, enrichment sources, provenance, human-readable notes | The minter — variable, additive, free-form |

A companion entry is a URI in the broad sense: a resolvable URL, a content-addressed
reference (`ipfs://…`), or an inline payload (a `data:` URI or plain string). The
channel is ordered but carries no identity semantics — it is a list of leads, not a
list of claims.

The division of labour is the same one this specification draws everywhere:

- The identity payload answers ***which thing is this?*** It must be byte-identical for
  two independent minters with the same facts, so it is minimal by design and admits
  nothing that varies by minter.
- Companion metadata answers ***where can I learn more?*** It legitimately varies by
  minter — two parties minting the same entity will know different sources, hold
  different artifacts, and publish different leads — so it MUST stay outside identity,
  where variance is harmless.

Three consequences, restated as requirements in [§7.5](#75-requirements): companion
metadata never enters identifier derivation; no identity operation — validation,
comparison, clustering — may require it; and two atoms carrying the same IID with
different companion metadata are the same entity, exactly as [§7.4](#74-profiles-and-clustering)
already provides. Whether a given transport hashes the companion channel into its own
record identifier is a protocol detail outside this specification; convergence survives
either way, because identity clustering keys on the embedded IID
([§8.2](./08-equivalence.md)).

### 7.8.2 Opaque identifiers need published context

Some canonical identifiers are **self-describing**: given the IID alone, a consumer can
locate or verify the referent. A `url` value is fetchable. An `isbn` resolves against
public registries. A `wd` QID is a lookup away.

Others are **opaque**: correct, deterministic, and yet a dead end without context.

| Scheme | What the identifier cannot tell you |
| :-- | :-- |
| [`hash`](../schemes/hash.md) | A digest is one-way. It verifies content you already hold; it cannot tell you what the bytes were or where to fetch them. |
| [`gen1`](../schemes/gen1.md) | The recipe fields (mandatory at P1) make the hash verifiable — but nothing says where the entity's fuller record lives. |
| [`rssitem`](../schemes/rssitem.md), [`termset`](../schemes/termset.md) | The embedded hash conceals the item GUID / term-set reference it was computed from. |
| [`geo`](../schemes/geo.md) | A cell decodes to coordinates, but nothing says what stands there. |

For such atoms, the identity payload is doing its whole job — naming — and cannot be
enlarged to also do resolution without violating minimality. Companion metadata is the
designed home for that context. A minter of a `hash` atom who knows a fetch URL, a
mirror, a MIME type, or the artifact's size SHOULD publish them as companion entries. A
minter of a `gen1` atom who knows the source record it was derived from SHOULD say so.
The rule of thumb: **if you hold context that a future consumer could not reconstruct
from the identifier, publish it — as metadata, never as identity.**

This is a SHOULD, not a MUST, deliberately: the minter with no context is still allowed
to mint (an honest bare name is better than no atom), and a consumer must treat missing
metadata as *unknown*, never as *invalid*.

### 7.8.3 The reference deployment

The Intuition MultiVault implements this model directly: atom creation accepts the atom
data — the identity payload, from which the atom ID derives — together with a **URI
array field** where creators publish companion metadata entries: URLs, content-addressed
references, or plain string payloads. That is one transport's rendering of the model.
An off-chain implementation with a `metadata` column, or another protocol with a
different field name, conforms just as well — the concepts, and the requirements in
[§7.5](#75-requirements), are what carry.

---

**Previous:** [6. The `gen1` scheme](./06-gen1.md) · **Next:** [8. Equivalence](./08-equivalence.md)
