# The Intuition Identifier (IID)

**A deterministic, canonical name for a real-world thing.**

Two people who have never met, working from the same facts, describing the same book —
should arrive at the same identifier for it, character for character, without
coordinating. That is the whole idea. This repository is the specification that makes it
true.

```text
int:isbn:9780684832722          a specific book edition
int:wd:Q25188                   the film Inception
int:caip10:eip155:1:0xd8da…     an Ethereum account
int:gen1:music-group:r4:8f3c…   a band we could only identify by name
```

An IID is an identifier you **compute** rather than **request**. Take the facts you have
about a thing, run them through the published procedure in this specification, and out
comes a string. Anyone else with the same facts gets the same string — no registry to
ask, no permission to seek, no coordination required. Where the facts are too thin to
distinguish two things, the identifier says so honestly instead of pretending precision.

This is the identity layer of the [Intuition](https://intuition.systems) protocol: it
defines how atoms — the entities of a shared, open knowledge graph — are named so that
contributions from independent parties converge instead of scattering. It is published
here, standalone and openly licensed, because the problem it solves is not unique to
Intuition. Any system that accepts descriptions of the world from more than one source
has it. This specification is our attempt at a rigorous, minimal, honest answer, and it
is offered to the open-source world as such.

One boundary is worth stating up front: this specification governs **identity, not
interpretation**. It fixes which string names a thing — never what a consuming system
should make of that thing. Which vocabulary an atom is mapped into, which type semantics
apply, how it is contextualized and rendered: those are choices each backend and
application makes for itself, through whatever interpretation engine it prefers, and
different consumers of the same graph can legitimately choose differently
([spec §7.7](./spec/07-representation-profiles.md)). The separation is deliberate — the
identifier layer stays strict, minimal, and frozen exactly so that everything above it
can stay modular and unopinionated. Deterministic building blocks for decentralized
coordination; meaning-making left free.

---

## Start here

**If you are new to all of this**, read [`explainer.md`](./explainer.md). It explains
what an IID is, why the obvious approaches fail, and why some identifiers are stronger
than others — with no code and no cryptography. It takes about ten minutes.

**If you are implementing against this spec**, read the [specification](./spec/00-overview.md)
in order. It is normative: it uses MUST/SHOULD/MAY in the RFC 2119 sense and is
versioned.

**If you need the exact rules for one identifier type** — how to canonicalize an ISBN,
what a valid CAIP-10 value looks like — go straight to the
[scheme registry](./schemes/README.md). Each of the 26 schemes has its own document with
a grammar, an ordered canonicalization algorithm, test vectors, and known limitations.

**If you want to know which identifier a given kind of thing should get**, see the
[entity-type registry](./entity-types/README.md) — the identity ladder for each of the
36 entity types.

**If you want to contribute** — propose a scheme, add a ladder rung, fix a defect —
start with [`CONTRIBUTING.md`](./CONTRIBUTING.md). There are
[open proposals](./entity-types/README.md) waiting for an owner.

## Reading paths

| You want to… | Read |
| :-- | :-- |
| Understand the concept | [`explainer.md`](./explainer.md) |
| Understand why IDs have strength classes | [`spec/03-identity-classes.md`](./spec/03-identity-classes.md) |
| Parse or compare an IID | [`spec/02-grammar.md`](./spec/02-grammar.md) |
| Normalize a string before hashing | [`spec/04-normalization.md`](./spec/04-normalization.md) |
| Pick which identifier to mint for an entity | [`spec/05-identity-ladders.md`](./spec/05-identity-ladders.md) |
| Derive an ID when no registry covers the thing | [`spec/06-gen1.md`](./spec/06-gen1.md) |
| Decide how much data an atom carries | [`spec/07-representation-profiles.md`](./spec/07-representation-profiles.md) |
| Understand what IIDs deliberately do *not* solve | [`spec/08-equivalence.md`](./spec/08-equivalence.md) |
| Add a new scheme to the registry | [`spec/09-registry-governance.md`](./spec/09-registry-governance.md) + [`CONTRIBUTING.md`](./CONTRIBUTING.md) |
| Look up one specific scheme | [`schemes/`](./schemes/README.md) |
| Look up one entity type's ladder | [`entity-types/`](./entity-types/README.md) |
| Consume the registry from code | [`registry.json`](./registry.json) |
| Run the vectors against your implementation | [`test-vectors.json`](./test-vectors.json) |
| Find an implementation | [`implementations.md`](./implementations.md) |
| See what changed between versions | [`CHANGELOG.md`](./CHANGELOG.md) |
| Know where code and spec currently disagree | [`implementation-notes.md`](./implementation-notes.md) |
| Report a security-sensitive ambiguity | [`SECURITY.md`](./SECURITY.md) |

## Specification contents

| Document | Contents |
| :-- | :-- |
| [00 — Overview](./spec/00-overview.md) | Purpose, scope, design tenets, and what an IID is not |
| [01 — Conformance](./spec/01-conformance.md) | Terminology, requirement levels, versioning, and stability guarantees |
| [02 — Grammar](./spec/02-grammar.md) | The identifier string: ABNF, parsing rules, comparison rules |
| [03 — Identity classes](./spec/03-identity-classes.md) | Classes A/B/C and openness tiers T1/T2/T3 — how identifier strength is ranked |
| [04 — Normalization (NORM-1)](./spec/04-normalization.md) | The frozen string-normalization algorithm |
| [05 — Identity ladders](./spec/05-identity-ladders.md) | How an entity's identifier is selected from available facts |
| [06 — The `gen1` scheme](./spec/06-gen1.md) | Deriving an identifier when no authority or natural key exists |
| [07 — Representation profiles](./spec/07-representation-profiles.md) | P0 / P1 / P2 — how much data travels with the identifier |
| [08 — Equivalence](./spec/08-equivalence.md) | The layer above IIDs: clustering, canonical election, trust |
| [09 — Registry governance](./spec/09-registry-governance.md) | Admission criteria, the freeze rule, and the change process |

## The 26 schemes

**Class A — registered authorities** (an external registry guarantees uniqueness)
[`isbn`](./schemes/isbn.md) · [`isrc`](./schemes/isrc.md) · [`iswc`](./schemes/iswc.md) · [`isni`](./schemes/isni.md) · [`orcid`](./schemes/orcid.md) · [`lei`](./schemes/lei.md) · [`gtin`](./schemes/gtin.md) · [`doi`](./schemes/doi.md) · [`eidr`](./schemes/eidr.md) · [`wd`](./schemes/wd.md) · [`mbid`](./schemes/mbid.md) · [`olid`](./schemes/olid.md) · [`imdb`](./schemes/imdb.md) · [`tmdb`](./schemes/tmdb.md) · [`podcastguid`](./schemes/podcastguid.md)

**Class B — intrinsic natural keys** (the thing carries its own identity)
[`url`](./schemes/url.md) · [`caip10`](./schemes/caip10.md) · [`caip19`](./schemes/caip19.md) · [`hash`](./schemes/hash.md) · [`appid`](./schemes/appid.md) · [`purl`](./schemes/purl.md) · [`geo`](./schemes/geo.md) · [`acct`](./schemes/acct.md) · [`rssitem`](./schemes/rssitem.md) · [`termset`](./schemes/termset.md)

**Class C — derived** (a hash of the few facts we actually have)
[`gen1`](./schemes/gen1.md)

## The site

[`docs/index.html`](./docs/index.html) is a self-contained single-page site for the
specification — the anatomy of an IID, the class system, the ladder, a live `gen1`
derivation playground, and an inspector that validates any IID (check digits included)
against the registry, all running client-side with no dependencies. Serve it with GitHub
Pages (Settings → Pages → deploy from `main`, `/docs` folder). The markdown spec is
normative; if the site and the spec disagree, the spec wins and the disagreement is a
bug worth reporting.

## Contributing

This specification is meant to be shaped by the people who use it. The most valuable
contributions, roughly in order of leverage:

1. **Implement it** in your language, and report every place the spec was ambiguous —
   ambiguity reports are spec defects and we treat them as such.
2. **Propose a scheme** for an identifier system we don't cover — there is a
   [template](./schemes/TEMPLATE.md) and a
   [governed admission process](./spec/09-registry-governance.md).
3. **Propose a ladder change** — a new rung, a reordering, a new entity type.
4. **Pick up an open proposal** — several ladders have known, documented gaps waiting
   for an owner; they are listed in the [entity-type registry](./entity-types/README.md).
5. **Improve the prose** — clarity fixes are PATCH releases and always welcome.

The one thing that is not open to contribution is the past: ratified canonicalization
rules are frozen forever ([the freeze rule](./spec/09-registry-governance.md)).
Improvements ship as new schemes and new versions, never as edits to what existing
identifiers mean.

See [`CONTRIBUTING.md`](./CONTRIBUTING.md) for the mechanics and
[`GOVERNANCE.md`](./GOVERNANCE.md) for how decisions are made.

## Status

**Version 0.1.0 — Draft.** The grammar, the class system, NORM-1, and the `gen1`
algorithm are stable and in production use within Intuition. Scheme canonicalization
rules are frozen under the [freeze rule](./spec/09-registry-governance.md). This
specification is published for review and adoption; it is not submitted to any standards
body.

## License

Everything in this repository — specification text, documentation, the site, and
all code — is licensed under [MIT](./LICENSE).
