# Implementations

Known implementations of this specification, by [conformance class](./spec/01-conformance.md).
To add yours, open a pull request — see [`CONTRIBUTING.md`](./CONTRIBUTING.md).

| Implementation | Language | Conformance | Role |
| :-- | :-- | :-- | :-- |
| [`@0xintuition/iid`](https://github.com/0xIntuition/intuition-v2/tree/main/intuition/iid) | TypeScript | Validator · canonicalizer · deriver | **Reference implementation.** Scheme canonicalizers, NORM-1, `gen1` derivation, parsing. Every test vector in this specification is executable against it. |
| [`@0xintuition/classifications`](https://github.com/0xIntuition/intuition-v2/tree/main/intuition/classifications) | TypeScript | Deriver | Declares each entity type's identity ladder and builds atom data for the Intuition protocol. |

Where the reference implementation and this specification currently disagree, the
disagreement is recorded in [`implementation-notes.md`](./implementation-notes.md) —
the spec states the intended rule, the note states what today's code does.

## Writing an implementation

Consuming IIDs is deliberately a lower bar than producing them: a useful
[conforming validator](./spec/01-conformance.md) needs only the
[grammar](./spec/02-grammar.md), the scheme registry, and each scheme's canonical-form
check. A [conforming canonicalizer](./spec/01-conformance.md) additionally implements
schemes' canonicalization algorithms and must match the published test vectors exactly.
A [conforming deriver](./spec/01-conformance.md) implements
[identity ladders](./spec/05-identity-ladders.md) and [`gen1`](./spec/06-gen1.md).

[`registry.json`](./registry.json) is a machine-readable export of the scheme and
entity-type registries, suitable for embedding in an implementation.
[`test-vectors.json`](./test-vectors.json) is the machine-readable export of every
normative test vector — run your canonicalizers against it directly (`canonical: null`
means the input MUST be rejected). Both are regenerated from the markdown documents,
which remain normative.

If the specification ever leaves you guessing, that is a defect in the specification —
please [report it](./CONTRIBUTING.md).
