"use client"

import * as React from "react"
import { z } from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { Controller, useFieldArray } from "react-hook-form"
import { useRouter } from "next/navigation"
import { useSession } from "next-auth/react"
import { Hand, X } from "lucide-react"

import { apiPost } from "@/lib/api/client"
import { parseApiError } from "@/lib/api/errors"
import { validateHandle } from "@/lib/handle"
import { userSettingsPath } from "@/lib/routes"
import { COUNTRIES } from "@/config/countries"
import { LANGUAGE_LIST as LANGUAGES } from "@/config/languages"
import { SKILL_LIST as SKILLS, TOOL_LIST as TOOLS } from "@/lib/attestations/definitions"

import { AvatarDropzone } from "@/components/common/avatar-dropzone"
import { HandleField } from "@/components/common/handle-field"
import { PageHeader } from "@/components/common/page-header"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Combobox,
  ComboboxCollection,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox"
import { Field, FieldDescription, FieldError, FieldLabel } from "@/components/ui/field"
import { Form, FormActions, FormField, fieldControlProps, useForm } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

// === SCHEMA ===

const OnboardingSchema = z.object({
  handle: z.string().trim().min(1, "Handle is required"),
  name: z.string().trim().min(1, "Name is required").max(80, "Name is too long"),
  headline: z.string().max(120, "Headline is too long"),
  bio: z.string().max(2000, "Bio is too long"),
  location: z.string(),
  links: z.array(
    z.object({ url: z.string().trim().max(2048, "Link is too long") })
  ).max(5, "Maximum 5 links"),
  languages: z.array(z.string()),
  skills: z.array(z.string()),
  tools: z.array(z.string().max(80, "Tool is too long")),
  image: z.string().url("Enter a valid image URL").optional().or(z.literal("")),
})

type OnboardingValues = z.infer<typeof OnboardingSchema>

type OnboardResponse = {
  user: {
    handle: string
  }
}

// === UTILITY FUNCTIONS ===

function optionalString(value: string | undefined | null): string | undefined {
  const v = String(value ?? "").trim()
  return v || undefined
}

function normalizeLinks(links: Array<{ url: string }>): string[] {
  return links
    .map((l) => l.url.trim())
    .filter(Boolean)
    .map((url) => (/^https?:\/\//i.test(url) ? url : `https://${url}`))
}

function normalizeStringArray(arr: string[]): string[] {
  return arr.map((s) => s.trim()).filter(Boolean)
}

function getCountryItems(): string[] {
  return COUNTRIES.map((c) => c.name)
}

function filterAvailableItems(allItems: readonly string[], selected: string[]): string[] {
  const selectedSet = new Set(selected.map((s) => s.toLowerCase()))
  return (allItems as string[]).filter((opt) => !selectedSet.has(opt.toLowerCase()))
}

// === CUSTOM HOOKS ===

function useLanguagesState() {
  const [languageOptions, setLanguageOptions] = React.useState<string[]>([...LANGUAGES])
  const [languageQuery, setLanguageQuery] = React.useState("")

  const addLanguageOption = React.useCallback((language: string) => {
    setLanguageOptions((prev) => {
      if (prev.some((l) => l.toLowerCase() === language.toLowerCase())) return prev
      return [language, ...prev]
    })
  }, [])

  return { languageOptions, languageQuery, setLanguageQuery, addLanguageOption }
}

function useToolsState() {
  const [toolOptions, setToolOptions] = React.useState<string[]>([...TOOLS])
  const [toolQuery, setToolQuery] = React.useState("")

  const addToolOption = React.useCallback((tool: string) => {
    setToolOptions((prev) => {
      if (prev.some((t) => t.toLowerCase() === tool.toLowerCase())) return prev
      return [tool, ...prev]
    })
  }, [])

  return { toolOptions, toolQuery, setToolQuery, addToolOption }
}

// === SUB-COMPONENTS ===

function ProfileSection({
  form,
  oauthImage,
}: {
  form: ReturnType<typeof useForm<OnboardingValues>>
  /** Raw OAuth image URL (e.g. Discord CDN) shown as fallback in the dropzone. */
  oauthImage: string | null
}) {
  const watchedName = form.watch("name")

  return (
    <Card>
      <CardHeader>
        <CardTitle>Profile</CardTitle>
        <CardDescription>Your public identity across communities.</CardDescription>
      </CardHeader>

      <CardContent className="flex flex-col gap-6">
        <Field data-slot="onboarding-avatar" name="image" invalid={!!form.formState.errors.image}>
          <FieldLabel>Avatar</FieldLabel>
          <FieldDescription>A photo or image that represents you across the platform. We&apos;ll use your OAuth photo by default.</FieldDescription>

          <div className="relative overflow-hidden rounded-xl border border-dashed border-border p-6">
            <AvatarDropzone
              value={form.watch("image") || oauthImage || null}
              alt="Avatar"
              className="flex flex-col items-center text-center"
              uploadType="user.avatar"
              maxSizeBytes={1 * 1024 * 1024}
              onChange={(url) => {
                form.clearErrors("root")
                form.setValue("image", url ?? "", { shouldDirty: true, shouldTouch: true })
              }}
              onError={(message) => {
                form.setError("root", { type: "server", message })
              }}
            />
          </div>

          {form.formState.errors.image?.message && (
            <FieldError>{String(form.formState.errors.image.message)}</FieldError>
          )}
        </Field>

        <FormField<OnboardingValues, "handle">
          name="handle"
          label="Handle"
          required
          description="Your username often used in social networks."
          render={({ id, field, fieldState }) => (
            <HandleField
              id={id}
              field={field}
              fieldState={fieldState}
              nameValue={watchedName}
              ownerType="USER"
            />
          )}
        />

        <FormField<OnboardingValues, "name">
          name="name"
          label="Name"
          required
          description="The name people know you by."
          render={({ id, field, fieldState }) => (
            <Input {...fieldControlProps(field, { id, invalid: fieldState.invalid })} value={field.value ?? ""} />
          )}
        />

        <FormField<OnboardingValues, "headline">
          name="headline"
          label="Headline"
          description="Short description shown under your name."
          render={({ id, field, fieldState }) => (
            <Input {...fieldControlProps(field, { id, invalid: fieldState.invalid })} value={field.value ?? ""} />
          )}
        />
      </CardContent>
    </Card>
  )
}

function AboutSection({
  form,
}: {
  form: ReturnType<typeof useForm<OnboardingValues>>
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>About</CardTitle>
        <CardDescription>Tell people a bit about yourself.</CardDescription>
      </CardHeader>

      <CardContent className="flex flex-col gap-6">
        <FormField<OnboardingValues, "bio">
          name="bio"
          label="Bio"
          description="Share your background, experience, and what drives you."
          render={({ id, field, fieldState }) => (
            <Textarea
              {...fieldControlProps(field, { id, invalid: fieldState.invalid })}
              value={String(field.value ?? "")}
              rows={5}
            />
          )}
        />
      </CardContent>
    </Card>
  )
}

function CountryLanguageSection({
  form,
  countryItems,
  languageOptions,
  languageQuery,
  onLanguageQueryChange,
  onAddLanguage,
}: {
  form: ReturnType<typeof useForm<OnboardingValues>>
  countryItems: string[]
  languageOptions: string[]
  languageQuery: string
  onLanguageQueryChange: (value: string) => void
  onAddLanguage: (language: string) => void
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Location & languages</CardTitle>
        <CardDescription>Where you&apos;re based and what languages you speak.</CardDescription>
      </CardHeader>

      <CardContent className="flex flex-col gap-6">
        <FormField<OnboardingValues, "location">
          name="location"
          label="Country"
          description="Where you're based."
          render={({ id, field, fieldState }) => (
            <div className="relative">
              <Combobox
                items={countryItems}
                value={field.value ? field.value : null}
                onValueChange={(value) => field.onChange(typeof value === "string" ? value : "")}
              >
                <ComboboxInput
                  id={id}
                  placeholder="Select a country"
                  aria-invalid={fieldState.invalid}
                  className="w-full"
                  showTrigger={!field.value}
                />

                <ComboboxContent className="bg-popover text-popover-foreground border border-border/60 shadow-lg rounded-2xl p-1">
                  <ComboboxEmpty className="px-3 py-2 text-sm text-muted-foreground">No countries found.</ComboboxEmpty>
                  <ComboboxList className="max-h-64 overflow-auto">
                    <ComboboxCollection>
                      {(item: string) => (
                        <ComboboxItem
                          key={item}
                          value={item}
                          className="data-[highlighted]:bg-accent/10 data-[highlighted]:text-primary flex items-center gap-2 rounded-xl px-3 py-2 text-sm"
                        >
                          <span className="flex-1">{item}</span>
                        </ComboboxItem>
                      )}
                    </ComboboxCollection>
                  </ComboboxList>
                </ComboboxContent>
              </Combobox>
              {field.value ? (
                <Button
                  className="absolute top-1/2 right-3 -translate-y-1/2 cursor-pointer bg-destructive/10 text-destructive hover:bg-destructive/20 h-5 px-2 py-0.5 text-xs font-medium"
                  onClick={() => field.onChange("")}
                >
                  Remove
                </Button>
              ) : null}
            </div>
          )}
        />

        <Field data-slot="onboarding-languages" name="languages" invalid={!!form.formState.errors.languages}>
          <FieldLabel>Languages</FieldLabel>
          <FieldDescription>Pick from suggestions or press Enter to add a custom language.</FieldDescription>

          <FormField<OnboardingValues, "languages">
            name="languages"
            render={({ id, field }) => {
              const selected: string[] = Array.isArray(field.value) ? field.value : []
              const items = filterAvailableItems(languageOptions, selected)

              function handleAddLanguage(language: string) {
                const v = language.trim()
                if (!v) return
                const lowerSelected = new Set(selected.map((s) => s.toLowerCase()))
                if (lowerSelected.has(v.toLowerCase())) return
                onAddLanguage(v)
                field.onChange([...selected, v])
                onLanguageQueryChange("")
              }

              return (
                <Combobox
                  items={items}
                  value={null}
                  inputValue={languageQuery}
                  onInputValueChange={(v) => onLanguageQueryChange(String(v ?? ""))}
                  onValueChange={(value) => {
                    if (typeof value !== "string" || !value) return
                    handleAddLanguage(value)
                  }}
                >
                  <ComboboxInput
                    id={id}
                    placeholder="Add a language…"
                    className="w-full"
                    showClear
                    showTrigger
                    onKeyDown={(e) => {
                      if (e.key !== "Enter") return
                      e.preventDefault()
                      handleAddLanguage(languageQuery)
                    }}
                  />

                  <ComboboxContent className="bg-popover text-popover-foreground border border-border/60 shadow-lg rounded-2xl p-1">
                    <ComboboxEmpty className="px-3 py-2 text-sm text-muted-foreground">
                      {languageQuery.trim()
                        ? <>Press Enter to add &ldquo;{languageQuery.trim()}&rdquo;.</>
                        : "All suggestions selected. Type to add a custom language."}
                    </ComboboxEmpty>
                    <ComboboxList className="max-h-64 overflow-auto">
                      <ComboboxCollection>
                        {(item: string) => (
                          <ComboboxItem
                            key={item}
                            value={item}
                            className="data-[highlighted]:bg-accent/10 data-[highlighted]:text-primary flex items-center gap-2 rounded-xl px-3 py-2 text-sm"
                          >
                            <span className="flex-1">{item}</span>
                          </ComboboxItem>
                        )}
                      </ComboboxCollection>
                    </ComboboxList>
                  </ComboboxContent>

                  {selected.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {selected.map((l) => (
                        <Badge
                          key={l}
                          variant="secondary"
                          className="cursor-pointer gap-1"
                          render={<button type="button" onClick={() => field.onChange(selected.filter((x) => x !== l))} />}
                        >
                          {l}
                          <X data-icon="inline-end" className="size-3 text-destructive" />
                        </Badge>
                      ))}
                    </div>
                  )}
                </Combobox>
              )
            }}
          />
        </Field>
      </CardContent>
    </Card>
  )
}

function LinksSection({
  form,
  links,
}: {
  form: ReturnType<typeof useForm<OnboardingValues>>
  links: ReturnType<typeof useFieldArray<OnboardingValues, "links">>
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Portfolio</CardTitle>
        <CardDescription>Share links to your website or public portfolio.</CardDescription>
      </CardHeader>

      <CardContent className="flex flex-col gap-6">
        <Field data-slot="onboarding-links" name="links" invalid={!!form.formState.errors.links}>
          <div className="flex flex-col gap-2">
            {links.fields.map((item, index) => (
              <div key={item.id} className="relative">
                <Controller
                  name={`links.${index}.url`}
                  control={form.control}
                  render={({ field: { ref: _ref, ...field }, fieldState }) => (
                    <Input
                      {...field}
                      value={field.value ?? ""}
                      placeholder="https://..."
                      aria-invalid={fieldState.invalid || undefined}
                      className="w-full pr-18"
                    />
                  )}
                />
                {(index > 0 || form.watch(`links.${index}.url`)) ? (
                  <Button
                    className="absolute top-1/2 right-3 -translate-y-1/2 cursor-pointer bg-destructive/10 text-destructive hover:bg-destructive/20 h-5 px-2 py-0.5 text-xs font-medium"
                    onClick={() => {
                      if (links.fields.length <= 1) {
                        links.replace([{ url: "" }])
                      } else {
                        links.remove(index)
                      }
                    }}
                  >
                    Remove
                  </Button>
                ) : null}
              </div>
            ))}

            {links.fields.length < 5 && (
              <Button
                type="button"
                onClick={() => links.append({ url: "" }, { shouldFocus: false })}
                className="self-start"
              >
                + Add another link
              </Button>
            )}
          </div>

          {typeof form.formState.errors.links?.message === "string" && (
            <FieldError>{form.formState.errors.links.message}</FieldError>
          )}
        </Field>
      </CardContent>
    </Card>
  )
}

function SkillsAndToolsSection({
  form,
  skillQuery,
  onSkillQueryChange,
  toolOptions,
  toolQuery,
  onToolQueryChange,
  onAddTool,
}: {
  form: ReturnType<typeof useForm<OnboardingValues>>
  skillQuery: string
  onSkillQueryChange: (value: string) => void
  toolOptions: string[]
  toolQuery: string
  onToolQueryChange: (value: string) => void
  onAddTool: (tool: string) => void
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Skills & tools</CardTitle>
        <CardDescription>What you&apos;re good at and what you work with.</CardDescription>
      </CardHeader>

      <CardContent className="flex flex-col gap-6">
        {/* Skills */}
        <Field data-slot="onboarding-skills" name="skills" invalid={!!form.formState.errors.skills}>
          <FieldLabel>Skills</FieldLabel>
          <FieldDescription>Pick from the list (type to filter). You can add multiple.</FieldDescription>

          <FormField<OnboardingValues, "skills">
            name="skills"
            render={({ id, field }) => {
              const selected: string[] = Array.isArray(field.value) ? field.value : []
              const items = filterAvailableItems(SKILLS, selected)

              return (
                <Combobox
                  items={items as unknown as string[]}
                  value={null}
                  inputValue={skillQuery}
                  onInputValueChange={(v) => onSkillQueryChange(String(v ?? ""))}
                  onValueChange={(value) => {
                    if (typeof value !== "string" || !value) return
                    field.onChange([...selected, value])
                    onSkillQueryChange("")
                  }}
                >
                  <ComboboxInput id={id} placeholder="Add a skill…" className="w-full" showClear showTrigger />

                  <ComboboxContent className="bg-popover text-popover-foreground border border-border/60 shadow-lg rounded-2xl p-1">
                    <ComboboxEmpty className="px-3 py-2 text-sm text-muted-foreground">
                      No skills found.
                    </ComboboxEmpty>
                    <ComboboxList className="max-h-64 overflow-auto">
                      <ComboboxCollection>
                        {(item: string) => (
                          <ComboboxItem
                            key={item}
                            value={item}
                            className="data-[highlighted]:bg-accent/10 data-[highlighted]:text-primary flex items-center gap-2 rounded-xl px-3 py-2 text-sm"
                          >
                            <span className="flex-1">{item}</span>
                          </ComboboxItem>
                        )}
                      </ComboboxCollection>
                    </ComboboxList>
                  </ComboboxContent>

                  {selected.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {selected.map((s) => (
                        <Badge
                          key={s}
                          variant="secondary"
                          className="cursor-pointer gap-1"
                          render={<button type="button" onClick={() => field.onChange(selected.filter((x) => x !== s))} />}
                        >
                          {s}
                          <X data-icon="inline-end" className="size-3 text-destructive" />
                        </Badge>
                      ))}
                    </div>
                  )}
                </Combobox>
              )
            }}
          />
        </Field>

        {/* Tools */}
        <Field data-slot="onboarding-tools" name="tools" invalid={!!form.formState.errors.tools}>
          <FieldLabel>Tools</FieldLabel>
          <FieldDescription>Pick from suggestions (type to filter) or press Enter to add a new tool.</FieldDescription>

          <FormField<OnboardingValues, "tools">
            name="tools"
            render={({ id, field }) => {
              const selected: string[] = Array.isArray(field.value) ? field.value : []
              const items = filterAvailableItems(toolOptions, selected)

              function handleAddTool(tool: string) {
                const v = tool.trim()
                if (!v) return
                const lowerSelected = new Set(selected.map((s) => s.toLowerCase()))
                if (lowerSelected.has(v.toLowerCase())) return
                onAddTool(v)
                field.onChange([...selected, v])
                onToolQueryChange("")
              }

              return (
                <Combobox
                  items={items}
                  value={null}
                  inputValue={toolQuery}
                  onInputValueChange={(v) => onToolQueryChange(String(v ?? ""))}
                  onValueChange={(value) => {
                    if (typeof value !== "string" || !value) return
                    handleAddTool(value)
                  }}
                >
                  <ComboboxInput
                    id={id}
                    placeholder="Add a tool…"
                    className="w-full"
                    showClear
                    showTrigger
                    onKeyDown={(e) => {
                      if (e.key !== "Enter") return
                      const expanded = (e.currentTarget as HTMLInputElement).getAttribute("aria-expanded")
                      if (expanded === "true") return
                      e.preventDefault()
                      handleAddTool(toolQuery)
                    }}
                  />

                  <ComboboxContent className="bg-popover text-popover-foreground border border-border/60 shadow-lg rounded-2xl p-1">
                    <ComboboxEmpty className="px-3 py-2 text-sm text-muted-foreground">
                      Press Enter to add &ldquo;{toolQuery.trim() || "…"}&rdquo;.
                    </ComboboxEmpty>
                    <ComboboxList className="max-h-64 overflow-auto">
                      <ComboboxCollection>
                        {(item: string) => (
                          <ComboboxItem
                            key={item}
                            value={item}
                            className="data-[highlighted]:bg-accent/10 data-[highlighted]:text-primary flex items-center gap-2 rounded-xl px-3 py-2 text-sm"
                          >
                            <span className="flex-1">{item}</span>
                          </ComboboxItem>
                        )}
                      </ComboboxCollection>
                    </ComboboxList>
                  </ComboboxContent>

                  {selected.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {selected.map((t) => (
                        <Badge
                          key={t}
                          variant="secondary"
                          className="cursor-pointer gap-1"
                          render={<button type="button" onClick={() => field.onChange(selected.filter((x) => x !== t))} />}
                        >
                          {t}
                          <X data-icon="inline-end" className="size-3 text-destructive" />
                        </Badge>
                      ))}
                    </div>
                  )}
                </Combobox>
              )
            }}
          />
        </Field>
      </CardContent>
    </Card>
  )
}

// === MAIN COMPONENT ===

export default function OnboardingPage() {
  const router = useRouter()
  const { data: session, update: updateSession } = useSession()

  const form = useForm<OnboardingValues>({
    resolver: zodResolver(OnboardingSchema),
    defaultValues: {
      handle: "",
      name: "",
      headline: "",
      bio: "",
      location: "",
      links: [{ url: "" }],
      languages: [],
      skills: [],
      tools: [],
      image: "",
    },
    mode: "onBlur",
  })

  const links = useFieldArray({ control: form.control, name: "links" })
  const { languageOptions, languageQuery, setLanguageQuery, addLanguageOption } = useLanguagesState()
  const [skillQuery, setSkillQuery] = React.useState("")
  const { toolOptions, toolQuery, setToolQuery, addToolOption } = useToolsState()

  const countryItems = React.useMemo(() => getCountryItems(), [])

  // Pre-populate form fields from the OAuth session so they're included on submit.
  const oauthHydratedRef = React.useRef(false)
  React.useEffect(() => {
    if (oauthHydratedRef.current || !session?.user) return
    oauthHydratedRef.current = true

    const image = session.user.image ?? null
    const name = session.user.name ?? null

    if (image && !form.getValues("image")) {
      form.setValue("image", image)
    }
    if (name && !form.getValues("name")) {
      form.setValue("name", name)
    }
  }, [session, form])

  async function onSubmit(values: OnboardingValues) {
    form.clearErrors("root")

    const handleRes = validateHandle(values.handle)
    if (!handleRes.ok) {
      form.setError("handle", {
        type: "validate",
        message: handleRes.error.issues?.[0]?.message || handleRes.error.message,
      })
      return
    }

    const payload = {
      handle: handleRes.value,
      name: optionalString(values.name)!,
      headline: optionalString(values.headline),
      bio: optionalString(values.bio),
      location: optionalString(values.location),
      links: normalizeLinks(values.links),
      languages: normalizeStringArray(values.languages),
      skills: normalizeStringArray(values.skills),
      tools: normalizeStringArray(values.tools),
      // Back-compat: older routes may still expect `tags`.
      tags: normalizeStringArray(values.tools),
      image: optionalString(values.image) ?? null,
    }

    const result = await apiPost<OnboardResponse>("/api/user/onboard", payload)

    if (result.ok) {
      try { sessionStorage.setItem("atlas-onboarded", "1") } catch {}
      const handle = result.value.user.handle
      // Refresh the NextAuth session so OnboardingGuard sees onboarded=true.
      // Pass handle + onboarded explicitly to avoid a race where the DB query
      // in the session callback hasn't picked up the freshly committed row yet.
      await updateSession({ handle, onboarded: true })
      router.replace(userSettingsPath(handle))
      return
    }

    const err = result.error
    const parsed = parseApiError(err)

    for (const [key, message] of Object.entries(parsed.fieldErrors)) {
      if (key in form.getValues()) {
        form.setError(key as keyof OnboardingValues, { type: "server", message })
      }
    }

    const conflictHandle =
      parsed.code === "HANDLE_CONFLICT" &&
      parsed.meta &&
      typeof parsed.meta === "object" &&
      "currentHandle" in parsed.meta
        ? String((parsed.meta as Record<string, unknown>).currentHandle)
        : null

    form.setError("root", {
      type: "server",
      message:
        parsed.formError ||
        (conflictHandle
          ? `You've already claimed @${conflictHandle}.`
          : "We couldn't finish onboarding. Try again."),
    })
  }

  const rootError = form.formState.errors.root?.message

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col mt-24 gap-6 pb-40">
      <Form form={form} onSubmit={onSubmit}>
        <PageHeader
          leading={
            <div className="flex size-12 items-center justify-center rounded-full border border-primary/15 bg-primary/10">
              <Hand className="size-6 text-primary" />
            </div>
          }
          title="Welcome aboard"
          description="Pick a handle and fill in a few profile details. You can change everything later."
          actions={
            <FormActions className="sm:align-center sm:justify-end">
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting ? "Saving…" : "Join"}
              </Button>
            </FormActions>
          }
        />

        {rootError ? (
          <Alert variant="destructive">
            <AlertDescription>{rootError}</AlertDescription>
          </Alert>
        ) : null}

        <ProfileSection form={form} oauthImage={session?.user?.image ?? null} />

        <AboutSection form={form} />

        <CountryLanguageSection
          form={form}
          countryItems={countryItems}
          languageOptions={languageOptions}
          languageQuery={languageQuery}
          onLanguageQueryChange={setLanguageQuery}
          onAddLanguage={addLanguageOption}
        />

        <LinksSection form={form} links={links} />

        <SkillsAndToolsSection
          form={form}
          skillQuery={skillQuery}
          onSkillQueryChange={setSkillQuery}
          toolOptions={toolOptions}
          toolQuery={toolQuery}
          onToolQueryChange={setToolQuery}
          onAddTool={addToolOption}
        />
      </Form>
    </div>
  )
}
