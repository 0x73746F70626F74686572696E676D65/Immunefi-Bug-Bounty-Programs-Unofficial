import {
  MembershipRole,
  MembershipStatus,
  Prisma,
  EventType,
} from "@prisma/client";
import type { NextRequest } from "next/server";
import { z } from "zod";

import { auth } from "@/lib/auth/session";
import { errJson, okJson } from "@/lib/api/server";
import { db } from "@/lib/db/client";
import { resolveCommunityIdFromHandle, resolveUserIdFromHandle } from "@/lib/handle-registry";
import { requireCsrf } from "@/lib/security/csrf";

export const runtime = "nodejs";

type SetMembershipStatusOk = {
  membership: {
    id: string;
    userId: string;
    communityId: string;
    status: MembershipStatus;
  };
  changed: boolean;
};

const SetMembershipStatusSchema = z
  .object({
    membershipId: z.string().trim().min(1).optional(),

    // Prefer ids; allow handles for user-facing flows.
    userId: z.string().trim().min(1).optional(),
    userHandle: z.string().trim().min(1).optional(),

    communityId: z.string().trim().min(1).optional(),
    communityHandle: z.string().trim().min(1).optional(),

    status: z.nativeEnum(MembershipStatus),
  })
  .refine(
    (v) =>
      Boolean(
        v.membershipId ||
          ((v.userId || v.userHandle) && (v.communityId || v.communityHandle)),
      ),
    {
      message: "membershipId or (user + community) is required",
      path: ["membershipId"],
    },
  );

export async function POST(req: NextRequest) {
  try {
    const session = await auth();
    const actorId = session?.user?.id;

    if (!actorId) {
      return errJson({ code: "UNAUTHORIZED", message: "Sign in required", status: 401 });
    }

    const csrf = await requireCsrf(req);
    if (csrf instanceof Response) return csrf;

    const raw = await req.json().catch(() => null);
    const parsed = SetMembershipStatusSchema.safeParse(raw);

    if (!parsed.success) {
      return errJson({
        code: "INVALID_REQUEST",
        message: "Invalid request",
        status: 400,
        issues: parsed.error.issues.map((iss) => ({
          path: iss.path.map((seg) => (typeof seg === "number" ? seg : String(seg))),
          message: iss.message,
        })),
      });
    }

    const input = parsed.data;
    const now = new Date();

    let userId = input.userId ?? null;
    let communityId = input.communityId ?? null;

    if (!input.membershipId) {
      if (!communityId && input.communityHandle) {
        const resolved = await resolveCommunityIdFromHandle(input.communityHandle);
        if (!resolved.ok) return errJson(resolved.error);
        communityId = resolved.value;
      }

      if (!userId && input.userHandle) {
        const resolved = await resolveUserIdFromHandle(input.userHandle);
        if (!resolved.ok) return errJson(resolved.error);
        userId = resolved.value;
      }
    }

    const targetUserId = input.membershipId ? null : userId;
    const targetCommunityId = input.membershipId ? null : communityId;

    if (!input.membershipId && (!targetUserId || !targetCommunityId)) {
      return errJson({ code: "INVALID_REQUEST", message: "Invalid request", status: 400 });
    }

    const result = await db.$transaction(async (tx) => {
      const membership = input.membershipId
        ? await tx.membership.findUnique({
            where: { id: input.membershipId },
            select: {
              id: true,
              userId: true,
              communityId: true,
              role: true,
              status: true,
              approvedAt: true,
            },
          })
        : await tx.membership.findUnique({
            where: {
              userId_communityId: {
                userId: targetUserId!,
                communityId: targetCommunityId!,
              },
            },
            select: {
              id: true,
              userId: true,
              communityId: true,
              role: true,
              status: true,
              approvedAt: true,
            },
          });

      if (!membership) {
        return { kind: "not_found" } as const;
      }

      const actorMembership = await tx.membership.findUnique({
        where: {
          userId_communityId: {
            userId: actorId,
            communityId: membership.communityId,
          },
        },
        select: { status: true, role: true },
      });

      if (!actorMembership || actorMembership.status !== MembershipStatus.APPROVED) {
        return { kind: "forbidden" } as const;
      }

      if (
        actorMembership.role !== MembershipRole.OWNER &&
        actorMembership.role !== MembershipRole.ADMIN
      ) {
        return { kind: "forbidden" } as const;
      }

      // Safety: do not allow banning the OWNER membership.
      if (input.status === MembershipStatus.BANNED && membership.role === MembershipRole.OWNER) {
        return { kind: "owner_ban_forbidden" } as const;
      }

      if (membership.status === input.status) {
        return { kind: "ok", membership, changed: false } as const;
      }

      const data: Prisma.MembershipUpdateInput = {
        status: input.status,
      };

      // Keep semantics minimal and schema-safe: only set approvedAt when approving.
      if (input.status === MembershipStatus.APPROVED && !membership.approvedAt) {
        data.approvedAt = now;
      }

      // Track who banned the member; clear on unban.
      if (input.status === MembershipStatus.BANNED) {
        data.bannedBy = { connect: { id: actorId } };
      } else if (membership.status === MembershipStatus.BANNED) {
        data.bannedBy = { disconnect: true };
      }

      const prevStatus = membership.status;

      const updated = await tx.membership.update({
        where: { id: membership.id },
        data,
        select: {
          id: true,
          userId: true,
          communityId: true,
          status: true,
        },
      });

      // Audit / preferences feed (best-effort): record a membership status change.
      // We resolve enum members defensively so this route won’t break if naming differs.
      const scoringTypes = EventType as unknown as Record<string, EventType>;

      const type =
        updated.status === MembershipStatus.BANNED
          ? (scoringTypes.MEMBERSHIP_BANNED ?? scoringTypes.BANNED)
          : prevStatus === MembershipStatus.BANNED && updated.status === MembershipStatus.APPROVED
            ? (scoringTypes.MEMBERSHIP_UNBANNED ?? scoringTypes.UNBANNED)
            : (scoringTypes.MEMBERSHIP_STATUS_CHANGED ?? scoringTypes.STATUS_CHANGED);

      if (type) {
        await tx.event.create({
          data: {
            communityId: updated.communityId,
            actorId,
            type,
            metadata: {
              subjectUserId: updated.userId,
              fromStatus: prevStatus,
              toStatus: updated.status,
            },
          },
          select: { id: true },
        });
      }

      return { kind: "ok", membership: updated, changed: true } as const;
    });

    if (result.kind === "not_found") {
      return errJson({ code: "NOT_FOUND", message: "Membership not found", status: 404 });
    }

    if (result.kind === "owner_ban_forbidden") {
      return errJson({ code: "FORBIDDEN", message: "You can't ban the owner.", status: 403 });
    }

    if (result.kind === "forbidden") {
      return errJson({ code: "FORBIDDEN", message: "Insufficient permissions", status: 403 });
    }

    return okJson<SetMembershipStatusOk>({
      membership: {
        id: result.membership.id,
        userId: result.membership.userId,
        communityId: result.membership.communityId,
        status: result.membership.status,
      },
      changed: result.changed,
    });
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2025") {
      return errJson({ code: "NOT_FOUND", message: "Membership not found", status: 404 });
    }

    return errJson({ code: "INTERNAL_ERROR", message: "Something went wrong", status: 500 });
  }
}
