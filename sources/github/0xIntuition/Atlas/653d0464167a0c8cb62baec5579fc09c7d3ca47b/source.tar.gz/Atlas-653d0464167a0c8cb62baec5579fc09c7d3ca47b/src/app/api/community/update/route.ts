import {
  CommunityConfigType,
  HandleOwnerType,
  MembershipStatus,
  Prisma,
  EventType,
} from "@prisma/client";
import type { NextRequest } from "next/server";

import { auth } from "@/lib/auth/session";
import { errJson, okJson } from "@/lib/api/server";
import { db } from "@/lib/db/client";
import { claimHandle, resolveHandleNameForOwner } from "@/lib/handle-registry";
import type { HandleProblem } from "@/lib/handle-registry";
import { hasPermission } from "@/lib/permissions";
import { deleteR2Object, extractR2Key } from "@/lib/r2";
import { requireCsrf } from "@/lib/security/csrf";
import { CommunityUpdateSchema } from "@/lib/validations";

export const runtime = "nodejs";

type UpdateCommunityOk = {
  community: {
    id: string;
    handle: string;
    name: string;
    description: string | null;
    avatarUrl: string | null;
    isMembershipOpen: boolean;
    isPublicDirectory: boolean;
    autoOrbitPlacement: boolean;
    membershipConfig: unknown | null;
    orbitConfig: unknown | null;
  };
};

const UpdateSchema = CommunityUpdateSchema.refine(
  (v) =>
    v.handle !== undefined ||
    v.name !== undefined ||
    v.description !== undefined ||
    v.avatarUrl !== undefined ||
    v.isMembershipOpen !== undefined ||
    v.isPublicDirectory !== undefined ||
    v.autoOrbitPlacement !== undefined ||
    v.membershipConfig !== undefined ||
    v.orbitConfig !== undefined,
  { message: "No updates provided", path: ["name"] },
);

function prismaJson(
  v: unknown | null | undefined,
): Prisma.InputJsonValue | Prisma.NullableJsonNullValueInput | undefined {
  // JSON fields: omit when undefined; represent SQL NULL with DbNull.
  if (v === undefined) return undefined;
  if (v === null) return Prisma.DbNull;
  return v as Prisma.InputJsonValue;
}

function revisionDbJson(v: unknown | null): Prisma.InputJsonValue | Prisma.NullableJsonNullValueInput {
  // For standalone revision rows, represent a cleared config as SQL NULL.
  if (v === null) return Prisma.DbNull;
  return v as Prisma.InputJsonValue;
}

export async function POST(req: NextRequest) {
  try {
    const session = await auth();
    const userId = session?.user?.id;

    if (!userId) {
      return errJson({ code: "UNAUTHORIZED", message: "Sign in required", status: 401 });
    }

    const csrf = await requireCsrf(req);
    if (csrf instanceof Response) return csrf;

    const raw = await req.json().catch(() => null);
    const parsed = await UpdateSchema.safeParseAsync(raw);

    if (!parsed.success) {
      return errJson({
        code: "INVALID_REQUEST",
        message: "Invalid request",
        status: 400,
        issues: parsed.error.issues.map((iss) => ({
          path: iss.path.map((seg) => (typeof seg === "number" ? seg : String(seg))),
          message: iss.message,
        })),
      });
    }

    const input = parsed.data;
    const now = new Date();

    const data: Prisma.CommunityUpdateInput = {};
    if (input.name !== undefined) data.name = input.name;
    if (input.description !== undefined) data.description = input.description;
    if (input.avatarUrl !== undefined) data.avatarUrl = input.avatarUrl;
    if (input.isMembershipOpen !== undefined) data.isMembershipOpen = input.isMembershipOpen;
    if (input.isPublicDirectory !== undefined) data.isPublicDirectory = input.isPublicDirectory;
    if (input.autoOrbitPlacement !== undefined) data.autoOrbitPlacement = input.autoOrbitPlacement;
    if (input.membershipConfig !== undefined) data.membershipConfig = prismaJson(input.membershipConfig);
    if (input.orbitConfig !== undefined) data.orbitConfig = prismaJson(input.orbitConfig);
    if (input.discordUrl !== undefined) data.discordUrl = input.discordUrl ?? null;
    if (input.xUrl !== undefined) data.xUrl = input.xUrl ?? null;
    if (input.telegramUrl !== undefined) data.telegramUrl = input.telegramUrl ?? null;
    if (input.githubUrl !== undefined) data.githubUrl = input.githubUrl ?? null;
    if (input.websiteUrl !== undefined) data.websiteUrl = input.websiteUrl ?? null;

    // Read old avatar URL before the transaction so we can clean up R2 after commit.
    const oldAvatarUrl =
      input.avatarUrl !== undefined
        ? (await db.community.findUnique({ where: { id: input.communityId }, select: { avatarUrl: true } }))?.avatarUrl ?? null
        : null;

    // Fetch community permissions for the hasPermission() check
    const communityPerms = await db.community.findUnique({
      where: { id: input.communityId },
      select: { permissions: true },
    });

    const txResult = await db.$transaction(async (tx) => {
      const membership = await tx.membership.findUnique({
        where: { userId_communityId: { userId, communityId: input.communityId } },
        select: { status: true, role: true },
      });

      if (!membership || membership.status !== MembershipStatus.APPROVED) {
        return { kind: "not_found" } as const;
      }

      if (!hasPermission(membership.role, "community.update", communityPerms?.permissions)) {
        return { kind: "forbidden" } as const;
      }

      // Claim handle before updating other fields — if this fails, the whole tx rolls back.
      if (input.handle !== undefined) {
        const claim = await claimHandle(tx, {
          ownerType: HandleOwnerType.COMMUNITY,
          ownerId: input.communityId,
          handle: input.handle,
        });
        if (!claim.ok) {
          return { kind: "handle_error", error: claim.error } as const;
        }
      }

      const community = await tx.community.update({
        where: { id: input.communityId },
        data,
        select: {
          id: true,
          name: true,
          description: true,
          avatarUrl: true,
          isMembershipOpen: true,
          isPublicDirectory: true,
          autoOrbitPlacement: true,
          membershipConfig: true,
          orbitConfig: true,
        },
      });

      // Config revision history (only when those fields are provided in the payload)
      if (input.membershipConfig !== undefined) {
        await tx.communityConfigRevision.create({
          data: {
            communityId: input.communityId,
            type: CommunityConfigType.MEMBERSHIP,
            config: revisionDbJson(input.membershipConfig),
            memberId: userId,
            note: "updated",
          },
          select: { id: true },
        });
      }

      if (input.orbitConfig !== undefined) {
        await tx.communityConfigRevision.create({
          data: {
            communityId: input.communityId,
            type: CommunityConfigType.ORBIT,
            config: revisionDbJson(input.orbitConfig),
            memberId: userId,
            note: "updated",
          },
          select: { id: true },
        });
      }

      // Emit COMMUNITY_UPDATED event for activity feed
      await tx.event.create({
        data: {
          communityId: input.communityId,
          actorId: userId,
          type: EventType.COMMUNITY_UPDATED,
          metadata: {
            fields: Object.keys(data),
          },
        },
      });

      const handleName = await resolveHandleNameForOwner(
        { ownerType: HandleOwnerType.COMMUNITY, ownerId: community.id },
        tx,
      );

      if (!handleName) {
        return { kind: "not_found" } as const;
      }

      return { kind: "ok", community, handleName } as const;
    });

    if (txResult.kind === "not_found") {
      return errJson({ code: "NOT_FOUND", message: "Community not found", status: 404 });
    }

    if (txResult.kind === "forbidden") {
      return errJson({ code: "FORBIDDEN", message: "Insufficient permissions", status: 403 });
    }

    if (txResult.kind === "handle_error") {
      const he = txResult.error;
      return errJson({
        code: he.code,
        message: he.message,
        status: he.status,
        issues: [{ path: ["handle"], message: he.message }],
        ...(he.meta ? { meta: he.meta } : {}),
      });
    }

    const updated = txResult.community;

    // Delete the specific old R2 avatar object when the URL changed (best-effort).
    if (oldAvatarUrl && oldAvatarUrl !== updated.avatarUrl) {
      const oldKey = extractR2Key(oldAvatarUrl);
      if (oldKey) {
        void deleteR2Object(oldKey).catch(() => {});
      }
    }

    return okJson<UpdateCommunityOk>({
      community: {
        id: updated.id,
        handle: txResult.handleName,
        name: updated.name,
        description: updated.description,
        avatarUrl: updated.avatarUrl,
        isMembershipOpen: updated.isMembershipOpen,
        isPublicDirectory: updated.isPublicDirectory,
        autoOrbitPlacement: updated.autoOrbitPlacement,
        membershipConfig: (updated.membershipConfig as unknown) ?? null,
        orbitConfig: (updated.orbitConfig as unknown) ?? null,
      },
    });
  } catch (e) {
    // Community was deleted between read and update.
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2025") {
      return errJson({ code: "NOT_FOUND", message: "Community not found", status: 404 });
    }

    return errJson({ code: "INTERNAL_ERROR", message: "Something went wrong", status: 500 });
  }
}