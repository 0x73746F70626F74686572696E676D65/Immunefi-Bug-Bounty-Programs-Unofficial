import { EventType } from "@prisma/client";
import { z } from "zod";

import { api, okJson, errJson } from "@/lib/api/server";
import { ATTESTATION_TYPES, type AttestationType, getAttributeById, isEndorsementType } from "@/lib/attestations/definitions";
import { db } from "@/lib/db/client";
import { emitEvent, recomputeScoresForAttestationPair } from "@/lib/scoring";

export const runtime = "nodejs";

const attestationTypeValues = Object.keys(ATTESTATION_TYPES) as [AttestationType, ...AttestationType[]];

const BodySchema = z.object({
  // Always use userId; handle is for UI convenience only
  toUserId: z.string().trim().min(1),

  // Attestation type from config
  type: z.enum(attestationTypeValues),

  // Optional confidence value (0-1)
  confidence: z.number().min(0).max(1).optional(),

  // Required for SKILL_ENDORSE — references AttributeId from definitions.ts
  attributeId: z.string().trim().min(1).optional(),

  // Where this attestation was initiated (e.g. "profile", "orbit")
  source: z.string().trim().min(1).max(50).optional(),

  // Stance: "for" (support) or "against" (oppose)
  stance: z.enum(["for", "against"]).optional(),
}).refine(
  (data) => !isEndorsementType(data.type) || !!data.attributeId,
  { message: "attributeId is required for endorsement attestations", path: ["attributeId"] },
);

type CreateAttestationOk = {
  attestation: {
    id: string;
  };
  /** True if an existing attestation was found and returned (no new one created) */
  alreadyExists: boolean;
};

export const POST = api(BodySchema, async (ctx) => {
  const { viewerId, json } = ctx;
  const { toUserId, type, confidence, attributeId, source, stance } = json;

  // Can't attest yourself
  if (toUserId === viewerId) {
    return errJson({
      code: "INVALID_REQUEST",
      message: "You can't attest yourself",
      status: 400,
    });
  }

  // Verify target user exists (include skills/tags for endorsement validation)
  const targetUser = await db.user.findUnique({
    where: { id: toUserId },
    select: { id: true, skills: true, tags: true },
  });

  if (!targetUser) {
    return errJson({
      code: "NOT_FOUND",
      message: "User not found",
      status: 404,
    });
  }

  // Validate endorsements: attributeId must exist, category must match type,
  // and target user must have the skill/tool listed on their profile.
  if (isEndorsementType(type)) {
    const attribute = getAttributeById(attributeId!);
    if (!attribute) {
      return errJson({
        code: "INVALID_REQUEST",
        message: "Invalid attribute ID",
        status: 400,
      });
    }

    // Enforce category alignment: SKILL_ENDORSE → skill, TOOL_ENDORSE → tool
    const expectedCategory = type === "SKILL_ENDORSE" ? "skill" : "tool";
    if (attribute.category !== expectedCategory) {
      return errJson({
        code: "INVALID_REQUEST",
        message: `Attribute "${attribute.label}" is a ${attribute.category}, not a ${expectedCategory}`,
        status: 400,
      });
    }

    const userAttributes = type === "SKILL_ENDORSE"
      ? (targetUser.skills || [])
      : (targetUser.tags || []);
    const hasAttribute = userAttributes.some(
      (label) => label.toLowerCase() === attribute.label.toLowerCase(),
    );
    if (!hasAttribute) {
      return errJson({
        code: "INVALID_REQUEST",
        message: `User does not have this ${expectedCategory} listed`,
        status: 400,
      });
    }
  }

  // Check for existing active attestation of the same type (+ attributeId for endorsements)
  const existing = await db.attestation.findFirst({
    where: {
      fromUserId: viewerId!,
      toUserId,
      type,
      attributeId: attributeId ?? null,
      revokedAt: null,
      supersededById: null,
    },
    select: { id: true, confidence: true },
  });

  // If already exists with same confidence, return idempotently
  if (existing) {
    const existingConfidence = existing.confidence ?? undefined;
    if (existingConfidence === confidence) {
      return okJson<CreateAttestationOk>({
        attestation: { id: existing.id },
        alreadyExists: true,
      });
    }

    // If confidence differs, supersede the existing attestation
    const created = await db.$transaction(async (tx) => {
      const replacement = await tx.attestation.create({
        data: {
          fromUserId: viewerId!,
          toUserId,
          type,
          confidence: confidence ?? null,
          attributeId: attributeId ?? null,
          source: source ?? null,
          stance: stance ?? "for",
        },
        select: { id: true },
      });

      await tx.attestation.update({
        where: { id: existing.id },
        data: { supersededById: replacement.id },
      });

      return replacement;
    });

    emitEvent({ fromUserId: viewerId!, toUserId, type: EventType.ATTESTED, metadata: { attestationType: type, source: source ?? null, stance: stance ?? "for" } });
    recomputeScoresForAttestationPair({ fromUserId: viewerId!, toUserId });

    return okJson<CreateAttestationOk>({
      attestation: { id: created.id },
      alreadyExists: false,
    });
  }

  // Create new attestation
  const attestation = await db.attestation.create({
    data: {
      fromUserId: viewerId!,
      toUserId,
      type,
      confidence: confidence ?? null,
      attributeId: attributeId ?? null,
      source: source ?? null,
      stance: stance ?? "for",
    },
    select: { id: true },
  });

  emitEvent({ fromUserId: viewerId!, toUserId, type: EventType.ATTESTED, metadata: { attestationType: type, source: source ?? null, stance: stance ?? "for" } });
  recomputeScoresForAttestationPair({ fromUserId: viewerId!, toUserId });

  return okJson<CreateAttestationOk>({
    attestation: { id: attestation.id },
    alreadyExists: false,
  });
}, { auth: "auth" });
