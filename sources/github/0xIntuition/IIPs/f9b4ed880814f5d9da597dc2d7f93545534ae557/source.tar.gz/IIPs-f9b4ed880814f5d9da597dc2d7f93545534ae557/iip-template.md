# IIP Template

| Field    | Value                                                                                           |
|----------|-------------------------------------------------------------------------------------------------|
| IIP      | `<IIP number>`                                                                                  |
| Title    | `<Title of the proposal>`                                                                       |
| Author   | `<Name and/or contact info of the author(s)>`                                                   |
| Status   | `<Draft \| Review \| Last Call \| Accepted \| Final \| Rejected \| Withdrawn>`                  |
| Category | `<Protocol \| Tooling \| Interface \| Application \| Process>`                                   |
| Created  | `<Date created, in YYYY-MM-DD format>`                                                          |
| Updated  | `<Date(s) updated, in YYYY-MM-DD format>`                                                       |
| Requires | `<IIP number(s) of any required dependencies>`                                                  |


## Summary

Provide a brief (one-paragraph) summary of the proposal. Clearly state the purpose, scope, and impact of the proposed change. This should allow the reader to quickly understand the core of the proposal without diving into details.

## Motivation

Explain the rationale behind the proposal and the problem it seeks to address. Detail why the change is necessary, what issues it resolves, and why it would benefit the Intuition ecosystem.

## Specification

Describe the proposed changes in technical detail. This section should cover every aspect of the change required for implementation, including protocol adjustments, data structures, interface specifications, and any dependencies on other IIPs.

Where applicable, use pseudocode, diagrams, or specific examples to clarify complex sections.

## Rationale

Discuss the design choices made in the proposal and why alternative options were not chosen. Explain how the proposal achieves its goals and any trade-offs made for this solution.

## Backwards Compatibility

Address any backward compatibility concerns, including potential impacts on existing systems and dApps. Describe how compatibility will be maintained or managed and any migration paths required.

## Test Cases

Provide test cases and scenarios to illustrate the correct functionality of the proposal. This section should include edge cases, expected outputs, and validation steps for both positive and negative test conditions.

## Implementation

(Optional) If possible, provide links to a reference implementation of the proposal. This might include code samples, proof of concept repositories, or details of pilot implementations.

## Security Considerations

Identify any security issues or concerns that might arise from implementing the proposal. Explain any potential vulnerabilities introduced and how they will be mitigated or monitored.

## Copyright

This document is licensed under the [Creative Commons CC0 1.0 Universal (CC0 1.0) Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/).
