# IIP Process Guide

This document outlines the process for creating, submitting, and advancing Intuition Improvement Proposals (IIPs). The process is designed to ensure thorough review and consensus-building around changes to the Intuition ecosystem.

## IIP Statuses

IIPs go through several status phases during their lifecycle:

- **Idea** - An idea that is pre-draft. This is not tracked within the IIP Repository.
- **Draft** - The first formally tracked stage of an IIP in development.
- **Review** - An IIP Author marks an IIP as ready for and requesting Peer Review.
- **Last Call** - This is the final review window for an IIP before moving to FINAL.
- **Final** - This IIP represents the final standard. A Final IIP exists in a state of finality and should only be updated to correct errata and add non-normative clarifications.
- **Stagnant** - Any IIP in DRAFT or REVIEW which has been inactive for a period of 6 months or greater.
- **Withdrawn** - The IIP Author(s) have withdrawn the proposed IIP.
- **Living** - A special status for IIPs that are designed to be continually updated and not reach a state of finality.

## Creating an IIP

1. **Review existing IIPs** to ensure your idea hasn't already been proposed.
2. **Discuss the idea** in community forums to gather initial feedback.
3. **Fork the IIP repository**.
4. **Use the standard IIP template** from `iip-template.md`.
5. **Name the file** using the format `iip-<number>.md` where `<number>` is the next available IIP number.

## Required Elements

Each IIP must include:

- **Preamble** - RFC 822 style headers containing metadata about the IIP
- **Abstract** - A short (~200 word) description of the technical issue being addressed
- **Motivation** - Clear explanation of why the existing protocol specification is inadequate
- **Specification** - Technical specification of the new feature
- **Rationale** - The reasoning behind design decisions
- **Backwards Compatibility** - Any compatibility issues that need to be considered
- **Reference Implementation** - Optional implementation of the IIP

## IIP Workflow

1. **Draft Stage**
   - Author submits PR with draft IIP
   - Editors review for format and completeness
   - If accepted, IIP is merged as Draft

2. **Review Stage**
   - Author marks IIP as ready for peer review
   - Community provides feedback
   - Author addresses feedback through IIP revisions

3. **Last Call Stage**
   - 14 day final review period
   - If significant issues are raised, IIP returns to Review
   - If no issues, moves to Final

4. **Final Stage**
   - No more changes allowed except errata
   - IIP becomes permanent part of the protocol

## Style Guide

- Write in clear, technical language
- Use RFC 2119 keywords: MUST, SHOULD, MAY
- Include examples and use cases
- Link to other relevant IIPs
- Keep mathematical formulae simple and well-explained

## IIP Editors

IIP editors are responsible for:

- Reviewing IIP formatting
- Assigning IIP numbers
- Helping authors follow the process
- Moving IIPs between statuses
- Providing feedback on IIP quality

## Resources

- [IIP Template](../iip-template.md)
- [IIP Discussion Forum](https://forum.intuition.systems)
- [GitHub Repository](https://github.com/intuition-systems/IIPs)

## License

All IIPs are released under the CC0 1.0 Universal license.
