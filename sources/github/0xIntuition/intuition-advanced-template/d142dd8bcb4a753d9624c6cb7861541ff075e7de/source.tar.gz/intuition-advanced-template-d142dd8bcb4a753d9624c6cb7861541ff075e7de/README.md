# intuition-advanced-template

Curated lists on the Intuition knowledge graph with Next.js App Router, GraphQL reads, protocol writes, and fully self-hosted SIWE auth.

[Intuition](https://www.docs.intuition.systems/docs) is a protocol for creating and relating knowledge on-chain. **Atoms** are pieces of data (a person, a concept, a URL). **Triples** are relationships between atoms (e.g., "Alice is-a Developer"). **Signals** are economic commitments — you stake tokens to express conviction about atoms or triples. **Lists** are curated collections built from triples. Learn more about [primitives](https://www.docs.intuition.systems/docs/intuition-concepts/primitives), the [GraphQL API](https://www.docs.intuition.systems/docs/category/-graphql-api), and the [protocol reference](https://www.docs.intuition.systems/docs/protocol/api-reference/multivault/atoms) in the Intuition docs.

> **For AI agents**: Give your agent this entire README. It contains the file map, code paths, and constraints your agent needs to understand and extend this template. Agent-specific rules live in `.agents/INSTRUCTIONS.md` and are symlinked to `CLAUDE.md`, `CODEX.md`, and `AGENTS.md` via [agentsync](https://github.com/dallay/agentsync) — your agent will pick them up automatically regardless of which tool you use.

## What this template does

- Browse featured curated lists from the Intuition knowledge graph.
- Open a list, see what items people have added, and add new items yourself.
- Signal your conviction by staking tokens on atoms or list items.
- Authenticate with Sign-In with Ethereum (SIWE) — fully self-hosted, no external auth API.

## Quick start

```bash
git clone <your-repo-url>
cd intuition-advanced-template
bun install
cp .env.example .env
bun dev
```

Open `http://localhost:3000`.

Build for production:

```bash
bun run build
```

Only two env vars are needed:

- `NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID` — get one at [cloud.walletconnect.com](https://cloud.walletconnect.com)
- `SIWE_JWT_SECRET` — generate with `openssl rand -hex 32`

Authentication is fully self-contained. The template handles Sign-In with Ethereum through its own API routes — no external auth service needed. `SIWE_JWT_SECRET` is the secret used to sign session cookies. Each developer generates their own.

GraphQL reads use the public Intuition testnet endpoint by default — no GraphQL env setup required.

## For AI agents

### Architecture summary

- Multi-page Next.js App Router app with server components for GraphQL reads.
- Server components query the public testnet endpoint directly through `queryGraphql()`.
- Client-side GraphQL search goes through `/api/graphql`.
- On-chain writes go through `@0xintuition/protocol` only.
- Wallet connection uses RainbowKit + wagmi on the client.
- Auth uses fully self-hosted SIWE — three API routes under `/api/auth/*`, no external auth service.

### Key file map

| Path | Purpose |
| --- | --- |
| `src/app/layout.tsx` | Root layout, metadata, cookie-backed auth bootstrap |
| `src/app/providers.tsx` | `WagmiProvider` → `QueryClientProvider` → `RainbowKitProvider` → `AuthProvider` → `TooltipProvider` |
| `src/lib/auth.ts` | JWT cookie parsing and verification for server components |
| `src/lib/siwe.ts` | `viem/siwe` helpers: parse, validate, verify SIWE messages |
| `src/app/api/auth/nonce/route.ts` | Issue signed nonce cookie and return nonce |
| `src/app/api/auth/verify/route.ts` | Validate SIWE message, verify signature, mint auth JWT |
| `src/app/api/auth/logout/route.ts` | Clear auth cookie |
| `src/app/api/graphql/route.ts` | Same-origin GraphQL proxy for browser queries |
| `src/lib/graphql/queries.ts` | Curated-list, atom, positions, and atom-search GraphQL documents |
| `src/lib/graphql/client.ts` | Browser proxy client + server GraphQL helper |
| `src/lib/protocol.ts` | `createAtom`, `createTriple`, `deposit`, `previewDeposit`, config helpers |
| `src/hooks/useCreate.ts` | Atom and triple write hook with wallet/confirming states |
| `src/hooks/useDeposit.ts` | Deposit + preview hook with transaction state |
| `src/hooks/useSiweAuth.ts` | Client-side SIWE auth hook |
| `src/config/lists.ts` | Curated list configuration and the shared `has_tag` predicate |
| `src/app/list/[id]/page.tsx` | List detail page composition |
| `src/components/AddToListForm.tsx` | Search existing atoms or create a new one, then create the membership triple |
| `src/components/DepositForm.tsx` | Preview + signal UI |

### Code paths

#### List browsing flow

`src/app/page.tsx`
loads `GET_CURATED_LISTS`
renders `ListCard`
links to `/list/[id]`

#### Adding to a list

`src/components/AddToListForm.tsx`
uses `SEARCH_ATOMS` for existing atoms or `useCreate().createAtom()` for new ones
then calls `useCreate().createTriple()`
which lands in `src/lib/protocol.ts`

#### Signaling flow

`src/components/DepositForm.tsx`
calls `useDeposit().preview()` and `useDeposit().deposit()`
which call `multiVaultPreviewDeposit` / `multiVaultDeposit` through `src/lib/protocol.ts`

#### Auth flow

`src/components/Header.tsx`
triggers `src/lib/providers/auth-provider.tsx`
which uses `src/hooks/useSiweAuth.ts`
which talks only to `/api/auth/nonce`, `/api/auth/verify`, and `/api/auth/logout`

### Protocol package imports

Use these from `@0xintuition/protocol`:

- `intuitionTestnet`
- `getMultiVaultAddressFromChainId`
- `multiVaultCreateAtoms`
- `multiVaultCreateTriples`
- `multiVaultDeposit`
- `multiVaultGetAtomCost`
- `multiVaultGetTripleCost`
- `multiVaultPreviewDeposit`
- `eventParseAtomCreated`
- `eventParseTripleCreated`
- `eventParseDeposited`

### Common modifications

- Replace the curated list atoms in `src/config/lists.ts`.
- Change the list-membership predicate if your app uses a different relationship.
- Expand the GraphQL documents in `src/lib/graphql/queries.ts` for richer list stats or search.
- Add route-specific auth gates with `getUserId()`.
- Swap the list/atom cards for your own branding without changing the protocol or auth layers.
- Add route-level loading UI by extending `src/app/loading.tsx` or adding segment-specific `loading.tsx` files.
- Support mainnet: add `intuitionMainnet` to `src/config/wagmi.ts` and continue using `getMultiVaultAddressFromChainId()` for address resolution.

## Environment variables

| Variable | Required | Description |
| --- | --- | --- |
| `NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID` | Yes | WalletConnect project ID used by RainbowKit |
| `SIWE_JWT_SECRET` | Yes for auth | Minimum 32-character secret used to sign and verify the auth JWT cookie. Generate with `openssl rand -hex 32` |

GraphQL reads use the [public Intuition testnet endpoint](https://testnet.intuition.sh/v1/graphql) by default — no configuration needed.

## Network info

### Testnet (default)

| Item | Value |
| --- | --- |
| Chain | Intuition Testnet |
| Chain ID | `13579` |
| Native Token | $tTRUST |
| Explorer | `https://testnet.explorer.intuition.systems` |
| GraphQL | `https://testnet.intuition.sh/v1/graphql` |
| Hub | `https://testnet.hub.intuition.systems` |
| Multivault address | Resolve with `getMultiVaultAddressFromChainId(intuitionTestnet.id)` |

#### Getting testnet tokens

Claim 0.1 $tTRUST daily from the [Intuition Testnet Hub](https://testnet.hub.intuition.systems). The hub also provides bridging and network tools.

### Mainnet

| Item | Value |
| --- | --- |
| Chain | Intuition Mainnet |
| Chain ID | `1155` |
| Native Token | $TRUST |
| Explorer | `https://explorer.intuition.systems` |
| GraphQL | `https://mainnet.intuition.sh/v1/graphql` |
| Hub | `https://hub.intuition.systems` |
| Multivault address | Resolve with `getMultiVaultAddressFromChainId(1155)` |

#### Getting mainnet tokens

Bridge $TRUST from Base Mainnet through the [Intuition Hub](https://hub.intuition.systems). TRUST is available as an ERC-20 on Base at `0x6cd905dF2Ed214b22e0d48FF17CD4200C1C6d8A3`.

## Try this with your agent

Copy any of these prompts into Claude, Codex, or your AI agent of choice. Give it this README for context.

- **"Add a new curated list to the home page."** Browse the [Intuition Explorer](https://testnet.explorer.intuition.systems) to find a list you like, grab its atom ID, and ask your agent to add it to the featured lists. Config change only — one file, one entry.

- **"Add a leaderboard page that ranks list items by how much people have staked on them."** This creates a new page showing which items in a list have the most community conviction. Adds a new route + nav link.

- **"Add a 'my activity' page that shows which lists I've contributed to."** After you've added items or staked on things, it'd be useful to see all your activity in one place. Adds a new route + GraphQL query.

- **"Switch this template to use Intuition Mainnet with real $TRUST tokens."** The template runs on testnet by default. This points it at mainnet (chain 1155) with the mainnet GraphQL endpoint. Touches config, protocol, and UI across ~10 files. See the Mainnet section above for network details — you'll need to bridge $TRUST from Base to get started.

## Agent instructions (agentsync)

This template uses [agentsync](https://github.com/dallay/agentsync) to maintain a single source of truth for AI agent rules across multiple tools.

```
.agents/
├── agentsync.toml      ← config: which tools get symlinks
└── INSTRUCTIONS.md      ← single source of truth for agent rules

CLAUDE.md → .agents/INSTRUCTIONS.md   (Claude Code)
CODEX.md  → .agents/INSTRUCTIONS.md   (OpenAI Codex)
AGENTS.md → .agents/INSTRUCTIONS.md   (Cursor)
```

**To update agent rules**: edit `.agents/INSTRUCTIONS.md`. All tools see the change immediately through symlinks.

**After a fresh clone**: run `bun run agents:apply` to recreate the symlinks. You can also run `bun run agents:status` to check their state.

## What's not included

- Custom product requirements or opinionated domain modeling beyond curated lists.
- Admin tooling, analytics, moderation, or production monitoring.
- Infinite explore views, rich atom subtype filters, or mutation invalidation layers.

This template has enough structure to ship an Intuition-integrated app quickly, but stays small enough for an AI agent to reshape safely.
