import {
  eventParseAtomCreated,
  eventParseDeposited,
  eventParseTripleCreated,
  getMultiVaultAddressFromChainId,
  intuitionTestnet,
  multiVaultCreateAtoms,
  multiVaultCreateTriples,
  multiVaultDeposit,
  multiVaultGetAtomCost,
  multiVaultGetTripleCost,
  multiVaultPreviewDeposit,
  type ReadConfig,
  type WriteConfig,
} from '@0xintuition/protocol'
import {
  fromHex,
  getAddress,
  isAddress,
  toHex,
  type Address,
  type Hex,
  type PublicClient,
  type WalletClient,
} from 'viem'

export const EXPLORER_BASE_URL = 'https://testnet.explorer.intuition.systems'
export const DEFAULT_CURVE_ID = 1n
export const DEFAULT_MIN_SHARES = 0n

export type ProtocolTransactionResult = {
  explorerUrl: string
  txHash: Hex
}

export type AtomWriteResult = ProtocolTransactionResult & {
  atomData: Hex
  atomDataText: string | null
  atomWallet: Address
  cost: bigint
  creator: Address
  termId: Hex
}

export type TripleWriteResult = ProtocolTransactionResult & {
  cost: bigint
  creator: Address
  objectId: Hex
  predicateId: Hex
  subjectId: Hex
  termId: Hex
}

export type DepositPreviewResult = {
  assets: bigint
  assetsAfterFees: bigint
  curveId: bigint
  shares: bigint
  termId: Hex
}

export type DepositWriteResult = ProtocolTransactionResult & DepositPreviewResult & {
  receiver: Address
  sender: Address
}

type BigIntInput = bigint | string | undefined

type BigIntOptions = {
  defaultValue?: bigint
  min?: bigint
}

type AtomCreatedEventArgs = {
  atomData: Hex
  atomWallet: Address
  creator: Address
  termId: Hex
}

type TripleCreatedEventArgs = {
  creator: Address
  objectId: Hex
  predicateId: Hex
  subjectId: Hex
  termId: Hex
}

type DepositedEventArgs = {
  assets: bigint
  assetsAfterFees: bigint
  curveId: bigint
  receiver: Address
  sender: Address
  shares: bigint
  termId: Hex
}

type TransactionLifecycleHandlers = {
  onTransactionSubmitted?: (
    transaction: ProtocolTransactionResult,
  ) => void | Promise<void>
}

export function getReadConfig(
  chainId: number,
  publicClient: PublicClient,
): ReadConfig {
  return {
    address: getMultiVaultAddressFromChainId(chainId),
    publicClient,
  }
}

export function getWriteConfig(
  chainId: number,
  publicClient: PublicClient,
  walletClient: WalletClient,
): WriteConfig {
  return {
    address: getMultiVaultAddressFromChainId(chainId),
    publicClient,
    walletClient,
  }
}

export function assertIntuitionTestnetChain(chainId: number) {
  if (chainId !== intuitionTestnet.id) {
    throw new Error(`Switch to ${intuitionTestnet.name} before submitting a transaction.`)
  }
}

export function getExplorerTransactionUrl(txHash: Hex) {
  return `${EXPLORER_BASE_URL}/tx/${txHash}`
}

function getProtocolTransactionResult(txHash: Hex): ProtocolTransactionResult {
  return {
    explorerUrl: getExplorerTransactionUrl(txHash),
    txHash,
  }
}

function toReadConfig(writeConfig: WriteConfig): ReadConfig {
  return {
    address: writeConfig.address,
    publicClient: writeConfig.publicClient,
  }
}

function parseRequiredString(value: string, fieldName: string) {
  const trimmed = value.trim()

  if (!trimmed) {
    throw new Error(`${fieldName} is required.`)
  }

  return trimmed
}

function parseBytes32(value: string, fieldName: string): Hex {
  const trimmed = parseRequiredString(value, fieldName)

  if (!/^0x[0-9a-fA-F]{64}$/.test(trimmed)) {
    throw new Error(`${fieldName} must be a 32-byte hex term ID.`)
  }

  return trimmed as Hex
}

function parseBigIntInput(
  value: BigIntInput,
  fieldName: string,
  options: BigIntOptions = {},
) {
  const resolvedValue =
    value === undefined || value === ''
      ? options.defaultValue
      : typeof value === 'bigint'
        ? value
        : (() => {
            try {
              return BigInt(parseRequiredString(value, fieldName))
            } catch {
              throw new Error(`${fieldName} must be a bigint-compatible integer string.`)
            }
          })()

  if (resolvedValue === undefined) {
    throw new Error(`${fieldName} is required.`)
  }

  if (options.min !== undefined && resolvedValue < options.min) {
    throw new Error(`${fieldName} must be at least ${options.min.toString()}.`)
  }

  return resolvedValue
}

function getConnectedAccount(walletClient: WalletClient) {
  const accountAddress = walletClient.account?.address

  if (!accountAddress) {
    throw new Error('Connect a wallet before submitting a transaction.')
  }

  return getAddress(accountAddress)
}

function parseReceiver(
  value: Address | string | undefined,
  walletClient: WalletClient,
) {
  if (!value) {
    return getConnectedAccount(walletClient)
  }

  if (!isAddress(value)) {
    throw new Error('Receiver must be a valid EVM address.')
  }

  return getAddress(value)
}

function decodeAtomData(hexValue: Hex) {
  try {
    return fromHex(hexValue, 'string').replace(/\0+$/g, '')
  } catch {
    return null
  }
}

function getEventArgs<TEventArgs extends Record<string, unknown>>(
  eventName: string,
  event: { args?: TEventArgs } | undefined,
) {
  if (!event?.args) {
    throw new Error(`Expected a ${eventName} event in the transaction receipt.`)
  }

  return event.args
}

export async function createAtom(
  writeConfig: WriteConfig,
  text: string,
  lifecycle: TransactionLifecycleHandlers = {},
) {
  const readConfig = toReadConfig(writeConfig)
  const atomCost = await multiVaultGetAtomCost(readConfig)

  // The protocol accepts raw bytes for atoms, so the template stores the
  // UTF-8 string directly instead of imposing a fixed 32-byte limit.
  const atomData = toHex(parseRequiredString(text, 'Atom content'))
  const txHash = await multiVaultCreateAtoms(writeConfig, {
    args: [[atomData], [atomCost]],
    value: atomCost,
  })
  const transaction = getProtocolTransactionResult(txHash)
  await lifecycle.onTransactionSubmitted?.(transaction)
  const [createdEvent] = await eventParseAtomCreated(writeConfig.publicClient, txHash)
  const args = getEventArgs<AtomCreatedEventArgs>('AtomCreated', createdEvent)

  return {
    atomData: args.atomData,
    atomDataText: decodeAtomData(args.atomData),
    atomWallet: args.atomWallet,
    cost: atomCost,
    creator: args.creator,
    explorerUrl: transaction.explorerUrl,
    termId: args.termId,
    txHash,
  } satisfies AtomWriteResult
}

export async function createTriple(
  writeConfig: WriteConfig,
  subjectId: string,
  predicateId: string,
  objectId: string,
  lifecycle: TransactionLifecycleHandlers = {},
) {
  const readConfig = toReadConfig(writeConfig)
  const tripleCost = await multiVaultGetTripleCost(readConfig)
  const txHash = await multiVaultCreateTriples(writeConfig, {
    args: [
      [parseBytes32(subjectId, 'Subject term ID')],
      [parseBytes32(predicateId, 'Predicate term ID')],
      [parseBytes32(objectId, 'Object term ID')],
      [tripleCost],
    ],
    value: tripleCost,
  })
  const transaction = getProtocolTransactionResult(txHash)
  await lifecycle.onTransactionSubmitted?.(transaction)
  const [createdEvent] = await eventParseTripleCreated(
    writeConfig.publicClient,
    txHash,
  )
  const args = getEventArgs<TripleCreatedEventArgs>('TripleCreated', createdEvent)

  return {
    cost: tripleCost,
    creator: args.creator,
    explorerUrl: transaction.explorerUrl,
    objectId: args.objectId,
    predicateId: args.predicateId,
    subjectId: args.subjectId,
    termId: args.termId,
    txHash,
  } satisfies TripleWriteResult
}

// The current protocol package types previewDeposit against WriteConfig
// because the underlying read can use the connected account context.
export async function previewDeposit(
  writeConfig: WriteConfig,
  termId: string,
  amount: BigIntInput,
  curveId: BigIntInput = DEFAULT_CURVE_ID,
) {
  getConnectedAccount(writeConfig.walletClient)

  const parsedTermId = parseBytes32(termId, 'Term ID')
  const parsedAmount = parseBigIntInput(amount, 'Amount', { min: 1n })
  const parsedCurveId = parseBigIntInput(curveId, 'Curve ID', {
    defaultValue: DEFAULT_CURVE_ID,
    min: 0n,
  })
  const [shares, assetsAfterFees] = await multiVaultPreviewDeposit(writeConfig, {
    args: [parsedTermId, parsedCurveId, parsedAmount],
  })

  return {
    assets: parsedAmount,
    assetsAfterFees,
    curveId: parsedCurveId,
    shares,
    termId: parsedTermId,
  } satisfies DepositPreviewResult
}

export async function deposit(
  writeConfig: WriteConfig,
  termId: string,
  amount: BigIntInput,
  options: {
    curveId?: BigIntInput
    minShares?: BigIntInput
    receiver?: Address | string
  } = {},
  lifecycle: TransactionLifecycleHandlers = {},
) {
  const receiver = parseReceiver(options.receiver, writeConfig.walletClient)
  const parsedTermId = parseBytes32(termId, 'Term ID')
  const parsedAmount = parseBigIntInput(amount, 'Amount', { min: 1n })
  const parsedCurveId = parseBigIntInput(options.curveId, 'Curve ID', {
    defaultValue: DEFAULT_CURVE_ID,
    min: 0n,
  })
  const parsedMinShares = parseBigIntInput(options.minShares, 'Minimum shares', {
    defaultValue: DEFAULT_MIN_SHARES,
    min: 0n,
  })
  const txHash = await multiVaultDeposit(writeConfig, {
    args: [receiver, parsedTermId, parsedCurveId, parsedMinShares],
    value: parsedAmount,
  })
  const transaction = getProtocolTransactionResult(txHash)
  await lifecycle.onTransactionSubmitted?.(transaction)
  const [depositedEvent] = await eventParseDeposited(writeConfig.publicClient, txHash)
  const args = getEventArgs<DepositedEventArgs>('Deposited', depositedEvent)

  return {
    assets: args.assets,
    assetsAfterFees: args.assetsAfterFees,
    curveId: args.curveId,
    explorerUrl: transaction.explorerUrl,
    receiver: args.receiver,
    sender: args.sender,
    shares: args.shares,
    termId: args.termId,
    txHash,
  } satisfies DepositWriteResult
}
