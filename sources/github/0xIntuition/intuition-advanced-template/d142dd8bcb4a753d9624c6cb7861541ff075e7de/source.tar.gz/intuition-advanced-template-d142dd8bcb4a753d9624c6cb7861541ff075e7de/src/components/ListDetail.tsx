import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { AddToListForm } from '@/components/AddToListForm'
import { ListItemRow } from '@/components/ListItemRow'
import { TAG_PREDICATE_ID } from '@/config/lists'
import { formatCount, formatTrustValue } from '@/lib/format'

import type { GraphqlListItem } from '@/lib/graphql/queries'

type ListDetailProps = {
  graphqlError: string | null
  graphqlReady: boolean
  items: GraphqlListItem[]
  list: {
    atomId: string
    description: string
    image: string | null
    itemCount: number | null
    marketCap: string | null
    name: string
    participants: number | null
  }
  onRefresh?: () => void | Promise<void>
}

export function ListDetail({
  graphqlError,
  graphqlReady,
  items,
  list,
  onRefresh,
}: ListDetailProps) {
  return (
    <div className="space-y-6">
      <section className="grid gap-4 xl:grid-cols-[1.35fr_1fr]">
        <Card className="overflow-hidden">
          <div className="aspect-[5/2] bg-muted">
            {list.image ? (
              <img
                alt={list.name}
                className="h-full w-full object-cover"
                loading="lazy"
                src={list.image}
              />
            ) : (
              <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
                No list image available
              </div>
            )}
          </div>
          <CardHeader>
            <CardTitle className="text-2xl">{list.name}</CardTitle>
            <CardDescription>{list.description}</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-3">
            <div>
              <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">
                Items
              </p>
              <p className="text-sm font-medium">
                {list.itemCount ?? items.length} entries
              </p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">
                Community stake
              </p>
              <p className="text-sm font-medium">{formatTrustValue(list.marketCap)}</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">
                Participants
              </p>
              <p className="text-sm font-medium">
                {formatCount(list.participants, 'participant')}
              </p>
            </div>
          </CardContent>
        </Card>

        <AddToListForm
          listId={list.atomId}
          listName={list.name}
          onSuccess={onRefresh}
          predicateId={TAG_PREDICATE_ID}
        />
      </section>

      {!graphqlReady ? (
        <Card className="border-amber-500/30 bg-amber-500/5">
          <CardHeader>
            <CardTitle className="text-lg">GraphQL data unavailable</CardTitle>
            <CardDescription>
              The page can still show write flows, but indexed list data could
              not be fetched.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">
            <p>{graphqlError}</p>
          </CardContent>
        </Card>
      ) : null}

      <section className="space-y-3">
        <div>
          <h2 className="text-xl font-semibold tracking-tight">List items</h2>
          <p className="text-sm text-muted-foreground">
            Each row is a triple where the subject atom points to this list via
            the shared tag predicate.
          </p>
        </div>

        {items.length > 0 ? (
          <div className="space-y-3">
            {items.map((item) => (
              <ListItemRow
                item={item}
                key={item.term_id}
                listName={list.name}
                onDeposited={onRefresh}
              />
            ))}
          </div>
        ) : (
          <Card className="border-dashed">
            <CardContent className="py-8 text-sm text-muted-foreground">
              No indexed items were returned for this list yet. Use the add form
              above to create a new membership triple.
            </CardContent>
          </Card>
        )}
      </section>
    </div>
  )
}
