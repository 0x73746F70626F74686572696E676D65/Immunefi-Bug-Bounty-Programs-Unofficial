import { NextResponse } from 'next/server'
import { generateSiweNonce } from 'viem/siwe'

import {
  getNonceCookieName,
  getNonceCookieOptions,
  issueNonceToken,
} from '@/lib/auth'

export async function GET() {
  try {
    const nonce = generateSiweNonce()
    const token = await issueNonceToken(nonce)
    const response = new NextResponse(nonce, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
      },
    })

    response.cookies.set(getNonceCookieName(), token, getNonceCookieOptions())

    return response
  } catch (error) {
    return new NextResponse(
      error instanceof Error
        ? error.message
        : 'SIWE authentication is not configured.',
      { status: 503 },
    )
  }
}
