import Link from 'next/link'

import { Badge } from '@/components/ui/badge'
import { buttonVariants } from '@/components/ui/button-variants'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { cn } from '@/lib/utils'
import { formatTrustValue, shortenHex } from '@/lib/format'

type PreviewItem = {
  label: string | null
  term_id: string
}

type ListCardProps = {
  list: {
    atomId: string
    description: string
    image: string | null
    itemCount: number | null
    marketCap: string | null
    name: string
    participants: number | null
    previewItems: PreviewItem[]
  }
}

export function ListCard({ list }: ListCardProps) {
  return (
    <Card className="overflow-hidden">
      <div className="aspect-[3/2] bg-muted">
        {list.image ? (
          <img
            alt={list.name}
            className="h-full w-full object-cover"
            loading="lazy"
            src={list.image}
          />
        ) : (
          <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
            No image
          </div>
        )}
      </div>
      <CardHeader>
        <CardTitle className="text-lg">{list.name}</CardTitle>
        <CardDescription>{list.description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap gap-2">
          <Badge variant="secondary">
            {list.itemCount === null ? 'Items pending' : `${list.itemCount} items`}
          </Badge>
          <Badge variant="outline">
            {list.participants === null
              ? 'Participants pending'
              : `${list.participants} participants`}
          </Badge>
        </div>

        <div className="space-y-2">
          <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
            Community stake
          </p>
          <p className="text-sm font-medium">{formatTrustValue(list.marketCap)}</p>
        </div>

        {list.previewItems.length > 0 ? (
          <div className="space-y-2">
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
              Preview items
            </p>
            <div className="space-y-1 text-sm text-muted-foreground">
              {list.previewItems.map((item) => (
                <p key={item.term_id}>
                  {item.label ?? shortenHex(item.term_id)}
                </p>
              ))}
            </div>
          </div>
        ) : null}

        <Link
          className={cn(buttonVariants({ className: 'w-full', variant: 'outline' }))}
          href={`/list/${list.atomId}`}
        >
          Open list
        </Link>
      </CardContent>
    </Card>
  )
}
