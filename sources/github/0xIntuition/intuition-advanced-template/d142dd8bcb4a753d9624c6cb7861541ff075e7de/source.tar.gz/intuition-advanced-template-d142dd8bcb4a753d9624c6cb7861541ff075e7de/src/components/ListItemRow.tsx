'use client'

import { TrendingUpIcon } from 'lucide-react'
import Link from 'next/link'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardHeader,
} from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { DepositForm } from '@/components/DepositForm'
import {
  formatCount,
  formatTermLabel,
  formatTrustValue,
  getSharePriceSuffix,
} from '@/lib/format'

import type { GraphqlListItem } from '@/lib/graphql/queries'

type ListItemRowProps = {
  item: GraphqlListItem
  listName: string
  onDeposited?: () => void | Promise<void>
}

export function ListItemRow({
  item,
  listName,
  onDeposited,
}: ListItemRowProps) {
  const subjectLabel = formatTermLabel(item.subject?.label, item.subject?.term_id)
  const primaryVault = item.term?.vaults[0] ?? null

  return (
    <Card>
      <CardHeader className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-lg font-semibold">
              <Link
                className="hover:text-primary hover:underline"
                href={`/atom/${item.subject?.term_id ?? item.term_id}`}
              >
                {subjectLabel}
              </Link>
            </h3>
            <Badge variant="secondary">{formatCount(primaryVault?.position_count, 'position')}</Badge>
          </div>
          <p className="text-sm text-muted-foreground">
            {subjectLabel} {formatTermLabel(item.predicate?.label, 'has tag')} {listName}
          </p>
          <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
            <Badge variant="outline">
              Market cap: {formatTrustValue(item.term?.total_market_cap)}
            </Badge>
            <Badge variant="outline">
              Share price: {formatTrustValue(primaryVault?.current_share_price, 4, getSharePriceSuffix())}
            </Badge>
          </div>
        </div>

        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <TrendingUpIcon className="size-4" />
              Signal
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Signal on list membership</DialogTitle>
              <DialogDescription>
                Deposit into the triple vault for {subjectLabel} in {listName}.
              </DialogDescription>
            </DialogHeader>
            <DepositForm
              onSuccess={onDeposited}
              submitLabel="Signal item"
              termId={item.term_id}
              title="Triple vault"
            />
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent className="flex flex-wrap gap-2 text-xs text-muted-foreground">
        <span>Triple term: {item.term_id}</span>
        <span>Counter term: {item.counter_term_id}</span>
      </CardContent>
    </Card>
  )
}
