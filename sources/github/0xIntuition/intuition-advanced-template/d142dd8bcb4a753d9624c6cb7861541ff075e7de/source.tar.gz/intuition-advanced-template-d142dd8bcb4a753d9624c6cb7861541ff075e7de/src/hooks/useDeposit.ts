import { useCallback, useState } from 'react'
import { BaseError } from 'viem'
import { useChainId, usePublicClient, useWalletClient } from 'wagmi'

import {
  assertIntuitionTestnetChain,
  deposit,
  getWriteConfig,
  previewDeposit,
  type DepositPreviewResult,
  type DepositWriteResult,
  type ProtocolTransactionResult,
} from '@/lib/protocol'
import { getTokenSymbol } from '@/lib/format'

type DepositInput = {
  amount: bigint | string
  curveId?: bigint | string
  minShares?: bigint | string
  receiver?: string
  termId: string
}

type PreviewDepositInput = {
  amount: bigint | string
  curveId?: bigint | string
  termId: string
}

export type DepositStatus =
  | 'idle'
  | 'waiting_wallet'
  | 'confirming'
  | 'success'
  | 'error'

function toUserFacingError(
  caughtError: unknown,
  fallbackMessage: string,
  chainId: number,
) {
  const message =
    caughtError instanceof BaseError
      ? caughtError.shortMessage
      : caughtError instanceof Error
        ? caughtError.message.split('\n')[0]?.trim()
        : ''

  if (!message) {
    return new Error(fallbackMessage)
  }

  if (/user rejected/i.test(message)) {
    return new Error('Transaction signature was rejected in the wallet.')
  }

  if (/insufficient funds/i.test(message)) {
    return new Error(
      `Wallet does not have enough ${getTokenSymbol(chainId)} to complete this transaction.`,
    )
  }

  if (/^0x[0-9a-f]+$/i.test(message)) {
    return new Error(fallbackMessage)
  }

  if (/execution reverted/i.test(message) && /0x[0-9a-f]{8,}/i.test(message)) {
    return new Error('Transaction reverted on-chain. Check the inputs and try again.')
  }

  return new Error(message)
}

export function useDeposit() {
  const chainId = useChainId()
  const publicClient = usePublicClient()
  const { data: walletClient } = useWalletClient()
  const [error, setError] = useState<Error | null>(null)
  const [isPreviewLoading, setIsPreviewLoading] = useState(false)
  const [previewResult, setPreviewResult] = useState<DepositPreviewResult | null>(
    null,
  )
  const [result, setResult] = useState<DepositWriteResult | null>(null)
  const [status, setStatus] = useState<DepositStatus>('idle')
  const [transaction, setTransaction] = useState<ProtocolTransactionResult | null>(
    null,
  )

  const preview = useCallback(
    async (input: PreviewDepositInput) => {
      setError(null)
      setIsPreviewLoading(true)
      setPreviewResult(null)

      try {
        if (!publicClient || !walletClient) {
          throw new Error('Connect a wallet before previewing a deposit.')
        }

        assertIntuitionTestnetChain(chainId)

        const writeConfig = getWriteConfig(chainId, publicClient, walletClient)
        const nextPreview = await previewDeposit(
          writeConfig,
          input.termId,
          input.amount,
          input.curveId,
        )

        setPreviewResult(nextPreview)
        return nextPreview
      } catch (caughtError) {
        const nextError = toUserFacingError(
          caughtError,
          'Unable to preview the deposit.',
          chainId,
        )

        setError(nextError)
        throw nextError
      } finally {
        setIsPreviewLoading(false)
      }
    },
    [chainId, publicClient, walletClient],
  )

  const depositMutation = useCallback(
    async (input: DepositInput) => {
      setError(null)
      setResult(null)
      setStatus('waiting_wallet')
      setTransaction(null)

      try {
        if (!publicClient || !walletClient) {
          throw new Error('Connect a wallet before depositing into a vault.')
        }

        assertIntuitionTestnetChain(chainId)

        const writeConfig = getWriteConfig(chainId, publicClient, walletClient)
        const onTransactionSubmitted = (nextTransaction: ProtocolTransactionResult) => {
          setStatus('confirming')
          setTransaction(nextTransaction)
        }
        const nextResult = await deposit(writeConfig, input.termId, input.amount, {
          curveId: input.curveId,
          minShares: input.minShares,
          receiver: input.receiver,
        }, {
          onTransactionSubmitted,
        })

        setStatus('success')
        setResult(nextResult)
        return nextResult
      } catch (caughtError) {
        const nextError = toUserFacingError(
          caughtError,
          'Unable to submit the signal transaction.',
          chainId,
        )

        setStatus('error')
        setError(nextError)
        throw nextError
      }
    },
    [chainId, publicClient, walletClient],
  )

  const reset = useCallback(() => {
    setError(null)
    setPreviewResult(null)
    setResult(null)
    setStatus('idle')
    setTransaction(null)
  }, [])

  const isAwaitingWallet = status === 'waiting_wallet'
  const isConfirming = status === 'confirming'

  return {
    deposit: depositMutation,
    error,
    isAwaitingWallet,
    isConfirming,
    isDepositing: isAwaitingWallet || isConfirming,
    isLoading: isAwaitingWallet || isConfirming || isPreviewLoading,
    isPreviewLoading,
    preview,
    previewResult,
    reset,
    result,
    status,
    transaction,
  }
}
