import Link from 'next/link'
import {
  ArrowRightIcon,
  DatabaseIcon,
  LockKeyholeIcon,
  PenToolIcon,
} from 'lucide-react'

import { ListCard } from '@/components/ListCard'
import { buttonVariants } from '@/components/ui/button-variants'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { CURATED_LISTS, TAG_PREDICATE_ID } from '@/config/lists'
import { queryGraphql } from '@/lib/graphql/client'
import {
  GET_CURATED_LISTS,
  type GetCuratedListsResponse,
  type GetCuratedListsVariables,
} from '@/lib/graphql/queries'

async function getHomePageData() {
  try {
    const data = await queryGraphql<
      GetCuratedListsResponse,
      GetCuratedListsVariables
    >(
      GET_CURATED_LISTS,
      {
        listIds: CURATED_LISTS.map((list) => list.atomId),
        predicateId: TAG_PREDICATE_ID,
      },
      'GetCuratedLists',
    )

    const featuredLists = CURATED_LISTS.map((list) => {
      const match = data.predicate_objects.find(
        (entry) => entry.object?.term_id === list.atomId,
      )

      return {
        ...list,
        itemCount: match?.triple_count ?? null,
        marketCap: match?.total_market_cap ?? null,
        participants: match?.total_position_count ?? null,
        previewItems:
          match?.triples
            .map((triple) => triple.subject)
            .filter((subject): subject is NonNullable<typeof subject> =>
              Boolean(subject),
            ) ?? [],
      }
    })

    return {
      featuredLists,
      graphqlError: null,
      graphqlReady: true,
    }
  } catch (error) {
    return {
      featuredLists: CURATED_LISTS.map((list) => ({
        ...list,
        itemCount: null,
        marketCap: null,
        participants: null,
        previewItems: [],
      })),
      graphqlError:
        error instanceof Error
          ? error.message
          : 'Failed to load list data from GraphQL.',
      graphqlReady: false,
    }
  }
}

export default async function HomePage() {
  const pageData = await getHomePageData()

  return (
    <div className="space-y-6">
      <section className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
        <Card className="border-primary/20 bg-gradient-to-br from-primary/5 via-background to-background">
          <CardHeader className="space-y-3">
            <CardTitle className="text-3xl tracking-tight">
              Curated lists as first-class graph objects.
            </CardTitle>
            <CardDescription className="max-w-2xl text-base">
              Browse curated lists, add items via atom or triple creation,
              and signal on membership claims — all through the Intuition
              protocol.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-3">
            <Link
              className={buttonVariants()}
              href="/create"
            >
              Explore create flows
              <ArrowRightIcon className="size-4" />
            </Link>
            <Link
              className={buttonVariants({ variant: 'outline' })}
              href="/positions"
            >
              Review positions page
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Implementation pillars</CardTitle>
            <CardDescription>
              Each page in this template maps to a specific teaching goal.
            </CardDescription>
          </CardHeader>
          <CardContent className="grid gap-3 text-sm">
            <div className="flex items-start gap-3">
              <DatabaseIcon className="mt-0.5 size-4 text-primary" />
              <div>
                <p className="font-medium">GraphQL for indexed reads</p>
                <p className="text-muted-foreground">
                  The featured lists below hydrate through the public
                  Intuition testnet GraphQL endpoint.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <PenToolIcon className="mt-0.5 size-4 text-primary" />
              <div>
                <p className="font-medium">Protocol writes only</p>
                <p className="text-muted-foreground">
                  Atom creation, triple creation, and deposits all go on-chain.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <LockKeyholeIcon className="mt-0.5 size-4 text-primary" />
              <div>
                <p className="font-medium">Self-hosted SIWE auth</p>
                <p className="text-muted-foreground">
                  Auth stays server-side so cookies remain same-origin.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {!pageData.graphqlReady ? (
        <Card className="border-amber-500/30 bg-amber-500/5">
          <CardHeader>
            <CardTitle className="text-lg">GraphQL data unavailable</CardTitle>
            <CardDescription>
              The page is falling back to seeded list metadata. By default this
              template uses the public Intuition testnet GraphQL endpoint and
              only needs an override if you want a different deployment.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">
            <p>{pageData.graphqlError}</p>
          </CardContent>
        </Card>
      ) : null}

      <section className="space-y-4">
        <div>
          <h2 className="text-xl font-semibold tracking-tight">Featured lists</h2>
          <p className="text-sm text-muted-foreground">
            These route links point at real list atoms on Intuition testnet.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {pageData.featuredLists.map((list) => (
            <ListCard key={list.atomId} list={list} />
          ))}
        </div>
      </section>
    </div>
  )
}
