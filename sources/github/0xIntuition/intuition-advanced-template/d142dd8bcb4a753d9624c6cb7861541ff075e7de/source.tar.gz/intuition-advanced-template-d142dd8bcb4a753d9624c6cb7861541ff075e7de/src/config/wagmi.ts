import { intuitionTestnet } from '@0xintuition/protocol'
import { getDefaultConfig } from '@rainbow-me/rainbowkit'
import { cookieStorage, createStorage, http } from 'wagmi'

export const walletConnectProjectId =
  process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID ??
  'template-walletconnect-project-id'

export const hasConfiguredWalletConnectProjectId =
  walletConnectProjectId !== 'template-walletconnect-project-id'

export const wagmiConfig = getDefaultConfig({
  appName: 'Intuition Advanced Template',
  appDescription: 'Curated lists on the Intuition knowledge graph',
  appUrl: 'https://github.com/0xIntuition/intuition-advanced-template',
  projectId: walletConnectProjectId,
  chains: [intuitionTestnet],
  ssr: true,
  storage: createStorage({
    storage: cookieStorage,
  }),
  transports: {
    [intuitionTestnet.id]: http(intuitionTestnet.rpcUrls.default.http[0]),
  },
})

export { intuitionTestnet }
