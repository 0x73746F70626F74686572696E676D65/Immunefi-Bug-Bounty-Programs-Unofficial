import { createPublicClient, custom } from 'viem'
import {
  parseSiweMessage,
  validateSiweMessage,
  verifySiweMessage,
} from 'viem/siwe'

export type ParsedSiwe = ReturnType<typeof parseSiweMessage>

const noRpcClient = createPublicClient({
  transport: custom({
    request: async () => {
      throw new Error('RPC not configured (EOA-only verification mode)')
    },
  }),
})

export function hasRequiredSiweFields(
  parsed: ParsedSiwe,
): parsed is ParsedSiwe & {
  address: `0x${string}`
  chainId: number
  nonce: string
  uri: string
  version: '1'
} {
  if (!parsed.address) return false
  if (!parsed.nonce) return false
  if (!parsed.uri) return false
  if (parsed.version !== '1') return false
  if (typeof parsed.chainId !== 'number' || !Number.isFinite(parsed.chainId)) {
    return false
  }

  return true
}

export function parseMessage(message: string) {
  return parseSiweMessage(message)
}

export function validateMessage(args: {
  parsed: ParsedSiwe
  expectedDomain?: string
}) {
  return validateSiweMessage({
    domain: args.expectedDomain,
    message: args.parsed,
  })
}

export async function verifyMessage(args: {
  message: string
  signature: `0x${string}`
  expectedDomain?: string
  expectedNonce?: string
}) {
  return verifySiweMessage(noRpcClient, {
    domain: args.expectedDomain,
    message: args.message,
    nonce: args.expectedNonce,
    signature: args.signature,
  })
}
