'use client'

import {
  CompassIcon,
  FolderPlusIcon,
  LayoutListIcon,
  WalletCardsIcon,
} from 'lucide-react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

import { Header } from '@/components/Header'
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarSeparator,
} from '@/components/ui/sidebar'
import { CURATED_LISTS } from '@/config/lists'

const primaryRoutes = [
  { href: '/', label: 'Featured Lists', icon: LayoutListIcon },
  { href: '/create', label: 'Create', icon: FolderPlusIcon },
  { href: '/positions', label: 'My Positions', icon: WalletCardsIcon },
]

const exampleList = CURATED_LISTS[0]

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()

  return (
    <SidebarProvider>
      <Sidebar collapsible="icon" variant="inset">
        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupLabel>Routes</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {primaryRoutes.map((route) => {
                  const isActive =
                    route.href === '/'
                      ? pathname === route.href
                      : pathname.startsWith(route.href)

                  return (
                    <SidebarMenuItem key={route.href}>
                      <SidebarMenuButton asChild isActive={isActive}>
                        <Link href={route.href}>
                          <route.icon className="size-4" />
                          <span>{route.label}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  )
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>

          <SidebarSeparator />

          <SidebarGroup>
            <SidebarGroupLabel>Examples</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <Link href={`/list/${exampleList.atomId}`}>
                      <CompassIcon className="size-4" />
                      <span>List detail</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <Link href={`/atom/${exampleList.atomId}`}>
                      <CompassIcon className="size-4" />
                      <span>Atom detail</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>

        <SidebarFooter>
          <div className="rounded-lg border bg-card p-3 text-xs text-muted-foreground">
            Next.js App Router, GraphQL reads, protocol writes, self-hosted
            SIWE auth.
          </div>
        </SidebarFooter>
      </Sidebar>

      <SidebarInset>
        <Header />
        <main className="flex-1 px-4 py-6 md:px-8">{children}</main>
      </SidebarInset>
    </SidebarProvider>
  )
}
