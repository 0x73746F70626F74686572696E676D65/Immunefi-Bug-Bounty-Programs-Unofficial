import { NextRequest, NextResponse } from 'next/server'

import {
  getAuthCookieName,
  getAuthCookieOptions,
  getNonceCookieName,
  getNonceCookieOptions,
  issueAuthToken,
  verifyNonceToken,
} from '@/lib/auth'
import {
  hasRequiredSiweFields,
  parseMessage,
  validateMessage,
  verifyMessage,
} from '@/lib/siwe'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => null)
    const message = body?.message
    const signature = body?.signature

    if (typeof message !== 'string' || typeof signature !== 'string') {
      return new NextResponse('invalid_request', { status: 400 })
    }

    const url = new URL(request.url)
    const expectedDomain = url.host
    const expectedUri = url.origin
    const parsed = parseMessage(message)
    const validFields = validateMessage({
      expectedDomain,
      parsed,
    })

    if (!validFields || !hasRequiredSiweFields(parsed)) {
      return new NextResponse('invalid_message', { status: 400 })
    }

    if (parsed.uri !== expectedUri) {
      return new NextResponse('invalid_uri', { status: 400 })
    }

    const nonceToken = request.cookies.get(getNonceCookieName())?.value
    if (!nonceToken) {
      return new NextResponse('nonce_expired', { status: 400 })
    }

    const expectedNonce = await verifyNonceToken(nonceToken)
    if (!expectedNonce) {
      return new NextResponse('nonce_expired', { status: 400 })
    }

    if (parsed.nonce !== expectedNonce) {
      return new NextResponse('nonce_mismatch', { status: 400 })
    }

    if (!signature.startsWith('0x')) {
      return new NextResponse('invalid_signature', { status: 400 })
    }

    const isValidSignature = await verifyMessage({
      expectedDomain,
      expectedNonce,
      message,
      signature: signature as `0x${string}`,
    })

    if (!isValidSignature) {
      return new NextResponse('invalid_signature', { status: 401 })
    }

    const token = await issueAuthToken(parsed.address, parsed.chainId)
    const response = NextResponse.json({
      address: parsed.address,
      chainId: parsed.chainId,
      ok: true,
    })

    response.cookies.set(getNonceCookieName(), '', getNonceCookieOptions(0))
    response.cookies.set(getAuthCookieName(), token, getAuthCookieOptions())

    return response
  } catch (error) {
    return new NextResponse(
      error instanceof Error
        ? error.message
        : 'SIWE authentication is not configured.',
      { status: 503 },
    )
  }
}
