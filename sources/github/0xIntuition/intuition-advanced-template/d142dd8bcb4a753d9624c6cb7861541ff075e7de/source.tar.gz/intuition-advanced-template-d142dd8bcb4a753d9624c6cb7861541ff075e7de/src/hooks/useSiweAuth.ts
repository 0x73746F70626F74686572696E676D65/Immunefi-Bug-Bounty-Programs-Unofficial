'use client'

import { createSiweMessage } from 'viem/siwe'
import { getAddress, isAddress } from 'viem'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useAccount, useSignMessage } from 'wagmi'

let globalSignInInProgress = false
let globalLastAutoAttemptKey: string | null = null

type UseSiweAuthOptions = {
  enabled?: boolean
  initialAuthenticatedAddress?: string | null
  onAuthFailure?: (error: Error) => void
  onAuthSuccess?: (address: string) => void
}

type UseSiweAuthResult = {
  authenticatedAddress: string | null
  error: Error | null
  hasIntentionallySignedOut: boolean
  isAuthenticated: boolean
  isSessionLoading: boolean
  isSigning: boolean
  signIn: () => Promise<boolean>
  signOut: () => Promise<void>
}

async function getSiweNonce() {
  const response = await fetch('/api/auth/nonce', {
    credentials: 'include',
  })

  if (!response.ok) {
    const errorText = await response.text().catch(() => '')
    throw new Error(errorText || 'Failed to fetch SIWE nonce.')
  }

  return response.text()
}

function buildSiweMessage(address: string, chainId: number, nonce: string) {
  const origin = window.location.origin
  const issuedAt = new Date()
  const expirationTime = new Date(issuedAt.getTime() + 10 * 60 * 1000)

  return createSiweMessage({
    address: address as `0x${string}`,
    chainId,
    domain: window.location.host,
    expirationTime,
    issuedAt,
    nonce,
    statement: 'Sign in with Ethereum to use the Intuition Advanced Template.',
    uri: origin,
    version: '1',
  })
}

async function verifySiweSignature(message: string, signature: string) {
  const response = await fetch('/api/auth/verify', {
    body: JSON.stringify({ message, signature }),
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
    },
    method: 'POST',
  })

  if (!response.ok) {
    const errorText = await response.text().catch(() => '')
    throw new Error(errorText || 'Failed to verify SIWE signature.')
  }

  const data = (await response.json()) as { address?: string; ok?: boolean }

  if (!data.ok || !data.address || !isAddress(data.address)) {
    throw new Error('The SIWE auth route returned an invalid address.')
  }

  return getAddress(data.address)
}

async function postSignOut() {
  await fetch('/api/auth/logout', {
    credentials: 'include',
    method: 'POST',
  })
}

export function useSiweAuth({
  enabled = true,
  initialAuthenticatedAddress,
  onAuthFailure,
  onAuthSuccess,
}: UseSiweAuthOptions = {}): UseSiweAuthResult {
  const { address, chainId, isConnected, status } = useAccount()
  const { signMessageAsync } = useSignMessage()
  const [authenticatedAddress, setAuthenticatedAddress] = useState<string | null>(
    initialAuthenticatedAddress ?? null,
  )
  const [error, setError] = useState<Error | null>(null)
  const [hasIntentionallySignedOut, setHasIntentionallySignedOut] =
    useState(false)
  const [isSessionLoading, setIsSessionLoading] = useState(true)
  const [isSigning, setIsSigning] = useState(false)
  const hasInitialized = useRef(false)

  useEffect(() => {
    if (hasInitialized.current) {
      setAuthenticatedAddress(initialAuthenticatedAddress ?? null)
      setIsSessionLoading(false)
      return
    }

    hasInitialized.current = true
    setAuthenticatedAddress(initialAuthenticatedAddress ?? null)
    setIsSessionLoading(false)
  }, [initialAuthenticatedAddress])

  useEffect(() => {
    if (
      authenticatedAddress &&
      address &&
      authenticatedAddress.toLowerCase() !== address.toLowerCase()
    ) {
      setAuthenticatedAddress(null)
      globalLastAutoAttemptKey = null
    }
  }, [address, authenticatedAddress])

  const signIn = useCallback(async () => {
    if (globalSignInInProgress) {
      return false
    }

    if (!address || !chainId || !isConnected) {
      return false
    }

    globalSignInInProgress = true
    setError(null)
    setIsSigning(true)

    try {
      const nonce = await getSiweNonce()
      const message = buildSiweMessage(address, chainId, nonce)
      const signature = await signMessageAsync({ message })
      const verifiedAddress = await verifySiweSignature(message, signature)

      setAuthenticatedAddress(verifiedAddress)
      setHasIntentionallySignedOut(false)
      onAuthSuccess?.(verifiedAddress)
      return true
    } catch (caughtError) {
      const authError =
        caughtError instanceof Error
          ? caughtError
          : new Error('Unknown SIWE authentication error.')

      setError(authError)
      onAuthFailure?.(authError)
      return false
    } finally {
      globalSignInInProgress = false
      setIsSigning(false)
    }
  }, [address, chainId, isConnected, onAuthFailure, onAuthSuccess, signMessageAsync])

  useEffect(() => {
    if (
      !enabled ||
      isSessionLoading ||
      status === 'reconnecting' ||
      !isConnected ||
      !address ||
      !chainId ||
      authenticatedAddress ||
      isSigning ||
      hasIntentionallySignedOut
    ) {
      return
    }

    const autoAttemptKey = `${address}:${chainId}`
    if (globalLastAutoAttemptKey === autoAttemptKey) {
      return
    }

    globalLastAutoAttemptKey = autoAttemptKey
    void signIn()
  }, [
    address,
    authenticatedAddress,
    chainId,
    enabled,
    hasIntentionallySignedOut,
    isConnected,
    isSessionLoading,
    isSigning,
    signIn,
    status,
  ])

  const signOut = useCallback(async () => {
    setHasIntentionallySignedOut(true)
    setAuthenticatedAddress(null)
    setError(null)
    globalLastAutoAttemptKey = null
    globalSignInInProgress = false
    await postSignOut()
  }, [])

  return useMemo(
    () => ({
      authenticatedAddress,
      error,
      hasIntentionallySignedOut,
      isAuthenticated: Boolean(authenticatedAddress),
      isSessionLoading,
      isSigning,
      signIn,
      signOut,
    }),
    [
      authenticatedAddress,
      error,
      hasIntentionallySignedOut,
      isSessionLoading,
      isSigning,
      signIn,
      signOut,
    ],
  )
}

export function getSiweErrorMessage(error: Error) {
  const message = error.message.toLowerCase()

  if (
    message.includes('user rejected') ||
    message.includes('user denied') ||
    message.includes('rejected')
  ) {
    return 'Signature request was rejected. Try again from the auth button.'
  }

  return error.message
}
