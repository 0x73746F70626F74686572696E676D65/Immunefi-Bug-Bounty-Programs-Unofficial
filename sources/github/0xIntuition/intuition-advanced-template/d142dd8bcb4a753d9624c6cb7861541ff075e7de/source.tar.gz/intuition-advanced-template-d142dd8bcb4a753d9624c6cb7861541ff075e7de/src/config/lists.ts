export type CuratedList = {
  name: string
  description: string
  atomId: string
  image: string
}

// Real list atoms from the Intuition testnet knowledge graph.
// These are intentionally hard-coded so downstream agents can start from
// concrete examples instead of guessing list term IDs.
export const CURATED_LISTS: CuratedList[] = [
  {
    name: 'Top Web3 Developer Tooling',
    description: 'Big brain toolbox',
    atomId:
      '0xd3abcb34a76429c0bf816689ca55ccd08cce86e094d7a34addf42c04c8a04981',
    image:
      'https://res.cloudinary.com/dfpwy9nyv/image/upload/v1724255696/remix/hqhkfavh5xvbh1w5wfep.png',
  },
  {
    name: 'Crypto Thought Leaders',
    description: 'The digital aristocracy',
    atomId:
      '0xa5abfa6b5f06fa0b0589ce8a7e000e0498d88e5a4924b3c32f57c6a9847d2dc7',
    image:
      'https://res.cloudinary.com/dfpwy9nyv/image/upload/v1724289389/remix/kppzwg9h3dmoewexoadi.png',
  },
  {
    name: 'Pro Crypto Politicians',
    description: 'The suits who like our coins',
    atomId:
      '0xdcfffc1160d5c8d7464481ca6a0d1debbe3f586f2a10a1e15a86947a5b13e3d7',
    image:
      'https://res.cloudinary.com/dfpwy9nyv/image/upload/v1724367553/remix/usanfpizqcrgwjolpdog.png',
  },
  {
    name: 'Anti Crypto Politicians',
    description: 'The suits who hate our coins',
    atomId:
      '0x1f833a20528cb4a770eff9dbbd64d6012a782d70e183b1da4eeee1a74bea2a81',
    image:
      'https://res.cloudinary.com/dfpwy9nyv/image/upload/v1724371008/remix/tg0nhu3e0sz2knjcbhri.png',
  },
]

// Intuition's canonical list-membership predicate:
// [item] has_tag [list]
export const TAG_PREDICATE_ID =
  '0x7ec36d201c842dc787b45cb5bb753bea4cf849be3908fb1b0a7d067c3c3cc1f5'

export function getCuratedListById(id: string) {
  return CURATED_LISTS.find((list) => list.atomId === id) ?? null
}
