import {
  ClientError,
  GraphQLClient,
  type RequestDocument,
  type RequestOptions,
  type Variables,
} from 'graphql-request'

const GRAPHQL_PROXY_PATH = '/api/graphql'
export const PUBLIC_GRAPHQL_API_URL = 'https://testnet.intuition.sh/v1/graphql'

const graphqlFetch: typeof fetch = async (input, init) => {
  const response = await fetch(input, {
    ...init,
    cache: 'no-store',
  })
  const contentType = response.headers.get('content-type')

  if (!contentType?.includes('application/json')) {
    const responseText = await response.text()
    const preview =
      responseText.length > 180 ? `${responseText.slice(0, 177)}...` : responseText

    throw new Error(
      `Expected a JSON GraphQL response but received ${contentType ?? 'unknown content'} (status ${response.status})${preview ? `: ${preview}` : '.'}`,
    )
  }

  return response
}

function createGraphqlClient(endpoint: string) {
  return new GraphQLClient(endpoint, {
    fetch: graphqlFetch,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
    },
  })
}

export const graphqlClient = createGraphqlClient(GRAPHQL_PROXY_PATH)

export function createServerGraphqlClient() {
  return createGraphqlClient(PUBLIC_GRAPHQL_API_URL)
}

function toGraphqlError(operationName: string, error: unknown) {
  if (error instanceof ClientError) {
    const graphqlMessage = error.response.errors?.[0]?.message

    if (graphqlMessage) {
      return new Error(`${operationName} failed: ${graphqlMessage}`)
    }

    return new Error(
      `${operationName} failed with status ${error.response.status}.`,
    )
  }

  if (error instanceof Error) {
    return new Error(`${operationName} failed: ${error.message}`)
  }

  return new Error(`${operationName} failed.`)
}

async function executeGraphql<TData, TVariables extends Variables>(
  client: GraphQLClient,
  document: RequestDocument,
  variables: TVariables,
  operationName: string,
) {
  try {
    return await client.request<TData, TVariables>({
      document,
      variables,
    } as unknown as RequestOptions<TVariables, TData>)
  } catch (error) {
    throw toGraphqlError(operationName, error)
  }
}

export async function requestGraphql<TData, TVariables extends Variables>(
  document: RequestDocument,
  variables: TVariables,
  operationName: string,
) {
  return executeGraphql<TData, TVariables>(
    graphqlClient,
    document,
    variables,
    operationName,
  )
}

export async function queryGraphql<TData, TVariables extends Variables>(
  document: RequestDocument,
  variables: TVariables,
  operationName: string,
) {
  const client = createServerGraphqlClient()

  return executeGraphql<TData, TVariables>(
    client,
    document,
    variables,
    operationName,
  )
}
