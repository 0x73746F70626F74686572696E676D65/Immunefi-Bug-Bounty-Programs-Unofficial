'use client'

import { AlertCircleIcon, WalletIcon } from 'lucide-react'
import { ConnectButton } from '@rainbow-me/rainbowkit'

import { Button } from '@/components/ui/button'
import { hasConfiguredWalletConnectProjectId } from '@/config/wagmi'

export function WalletConnectButton() {
  if (!hasConfiguredWalletConnectProjectId) {
    return (
      <span
        title="Set NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID in .env to enable wallet connections."
      >
        <Button
          aria-label="WalletConnect project ID required"
          className="gap-2"
          disabled
          size="sm"
          variant="outline"
        >
          <AlertCircleIcon className="size-4" />
          <WalletIcon className="size-4" />
        </Button>
      </span>
    )
  }

  return <ConnectButton chainStatus="icon" showBalance={false} />
}
