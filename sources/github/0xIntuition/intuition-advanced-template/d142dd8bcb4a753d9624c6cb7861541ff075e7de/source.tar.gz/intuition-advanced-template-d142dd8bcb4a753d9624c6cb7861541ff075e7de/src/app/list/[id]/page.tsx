import { ListDetail } from '@/components/ListDetail'
import { getCuratedListById, TAG_PREDICATE_ID } from '@/config/lists'
import { queryGraphql } from '@/lib/graphql/client'
import {
  GET_CURATED_LISTS,
  GET_LIST_ITEMS,
  type GetCuratedListsResponse,
  type GetCuratedListsVariables,
  type GetListItemsResponse,
  type GetListItemsVariables,
} from '@/lib/graphql/queries'

function buildFallbackList(id: string) {
  const curatedList = getCuratedListById(id)

  return {
    atomId: id,
    description:
      curatedList?.description ??
      'A curated list resolved through the shared has_tag predicate pattern.',
    image: curatedList?.image ?? null,
    name: curatedList?.name ?? 'Community list',
  }
}

async function getListPageData(id: string) {
  const fallbackList = buildFallbackList(id)

  try {
    const [summaryData, itemData] = await Promise.all([
      queryGraphql<GetCuratedListsResponse, GetCuratedListsVariables>(
        GET_CURATED_LISTS,
        {
          listIds: [id],
          predicateId: TAG_PREDICATE_ID,
        },
        'GetCuratedLists',
      ),
      queryGraphql<GetListItemsResponse, GetListItemsVariables>(
        GET_LIST_ITEMS,
        {
          listId: id,
          predicateId: TAG_PREDICATE_ID,
        },
        'GetListItems',
      ),
    ])

    const summary = summaryData.predicate_objects[0]

    return {
      graphqlError: null,
      graphqlReady: true,
      items: itemData.triples,
      list: {
        ...fallbackList,
        image: summary?.object?.image ?? fallbackList.image,
        itemCount: summary?.triple_count ?? itemData.triples.length,
        marketCap: summary?.total_market_cap ?? null,
        name: summary?.object?.label ?? fallbackList.name,
        participants: summary?.total_position_count ?? null,
      },
    }
  } catch (error) {
    return {
      graphqlError:
        error instanceof Error
          ? error.message
          : 'Failed to load list details from GraphQL.',
      graphqlReady: false,
      items: [],
      list: {
        ...fallbackList,
        itemCount: null,
        marketCap: null,
        participants: null,
      },
    }
  }
}

export default async function ListDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const pageData = await getListPageData(id)

  return (
    <ListDetail
      graphqlError={pageData.graphqlError}
      graphqlReady={pageData.graphqlReady}
      items={pageData.items}
      list={pageData.list}
    />
  )
}
