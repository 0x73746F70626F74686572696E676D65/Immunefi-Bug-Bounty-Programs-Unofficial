import Link from 'next/link'

import { Badge } from '@/components/ui/badge'
import { TableCell, TableRow } from '@/components/ui/table'
import {
  formatTermLabel,
  formatTrustValue,
  getSharePriceSuffix,
  shortenHex,
} from '@/lib/format'

import type { GraphqlPosition } from '@/lib/graphql/queries'

type PositionRowProps = {
  position: GraphqlPosition
}

export function PositionRow({ position }: PositionRowProps) {
  const atom = position.vault?.term?.atom
  const triple = position.vault?.term?.triple
  const isAtomPosition = Boolean(atom)
  const primaryLabel = atom
    ? formatTermLabel(atom.label, atom.term_id)
    : `${formatTermLabel(triple?.subject?.label, triple?.subject?.term_id)} - ${formatTermLabel(
        triple?.predicate?.label,
        triple?.predicate?.term_id,
      )} - ${formatTermLabel(triple?.object?.label, triple?.object?.term_id)}`
  const routeTarget = atom
    ? `/atom/${atom.term_id}`
    : triple?.object?.term_id
      ? `/list/${triple.object.term_id}`
      : null

  return (
    <TableRow>
      <TableCell className="whitespace-normal">
        <div className="space-y-1">
          <p className="font-medium">{primaryLabel}</p>
          <p className="text-xs text-muted-foreground">
            {atom ? atom.term_id : shortenHex(triple?.term_id ?? position.id)}
          </p>
        </div>
      </TableCell>
      <TableCell>
        <Badge variant={isAtomPosition ? 'secondary' : 'outline'}>
          {isAtomPosition ? 'Atom' : 'Triple'}
        </Badge>
      </TableCell>
      <TableCell>{formatTrustValue(position.shares, 4, '')}</TableCell>
      <TableCell>
        {formatTrustValue(position.vault?.current_share_price, 4, getSharePriceSuffix())}
      </TableCell>
      <TableCell>{formatTrustValue(position.vault?.term?.total_market_cap)}</TableCell>
      <TableCell>
        {routeTarget ? (
          <Link
            className="text-primary underline underline-offset-4"
            href={routeTarget}
          >
            Open
          </Link>
        ) : (
          <span className="text-muted-foreground">Unavailable</span>
        )}
      </TableCell>
    </TableRow>
  )
}
