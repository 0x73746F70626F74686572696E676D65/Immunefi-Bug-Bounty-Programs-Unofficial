import { gql } from 'graphql-request'

export type GraphqlVault = {
  current_share_price: string | null
  position_count: number | null
  term_id: string
  total_shares: string | null
}

export type GraphqlListSubject = {
  image: string | null
  label: string | null
  term_id: string
}

export type GraphqlListPreview = {
  object: {
    image: string | null
    label: string | null
    term_id: string
  } | null
  total_market_cap: string | null
  total_position_count: number | null
  triple_count: number | null
  triples: Array<{
    subject: GraphqlListSubject | null
  }>
}

export type GetCuratedListsResponse = {
  predicate_objects: GraphqlListPreview[]
}

export type GetCuratedListsVariables = {
  listIds: string[]
  predicateId: string
}

export const GET_CURATED_LISTS = gql`
  query GetCuratedLists($predicateId: String!, $listIds: [String!]) {
    predicate_objects(
      where: {
        predicate_id: { _eq: $predicateId }
        object_id: { _in: $listIds }
      }
      order_by: [{ total_market_cap: desc }]
    ) {
      triple_count
      total_market_cap
      total_position_count
      object {
        term_id
        label
        image
      }
      triples(limit: 4, order_by: { term: { total_market_cap: desc } }) {
        subject {
          term_id
          label
          image
        }
      }
    }
  }
`

export type GetListItemsResponse = {
  triples: Array<{
    counter_term_id: string
    object: {
      label: string | null
      term_id: string
    } | null
    predicate: {
      label: string | null
      term_id: string
    } | null
    subject: {
      image: string | null
      label: string | null
      term_id: string
    } | null
    term: {
      total_market_cap: string | null
      vaults: GraphqlVault[]
    } | null
    term_id: string
  }>
}

export type GraphqlListItem = GetListItemsResponse['triples'][number]

export type GetListItemsVariables = {
  listId: string
  predicateId: string
}

export const GET_LIST_ITEMS = gql`
  query GetListItems($listId: String!, $predicateId: String!) {
    triples(
      where: {
        object_id: { _eq: $listId }
        predicate_id: { _eq: $predicateId }
      }
      order_by: [{ term: { total_market_cap: desc } }]
    ) {
      term_id
      counter_term_id
      subject {
        term_id
        label
        image
      }
      predicate {
        term_id
        label
      }
      object {
        term_id
        label
      }
      term {
        total_market_cap
        vaults(where: { curve_id: { _eq: "1" } }, order_by: { curve_id: asc }) {
          term_id
          current_share_price
          position_count
          total_shares
        }
      }
    }
  }
`

export type GetAtomResponse = {
  atom: {
    image: string | null
    label: string | null
    term: {
      total_market_cap: string | null
      vaults: GraphqlVault[]
    } | null
    term_id: string
  } | null
}

export type GraphqlAtom = NonNullable<GetAtomResponse['atom']>

export type GetAtomVariables = {
  termId: string
}

export const GET_ATOM = gql`
  query GetAtom($termId: String!) {
    atom(term_id: $termId) {
      term_id
      label
      image
      term {
        total_market_cap
        vaults(where: { curve_id: { _eq: "1" } }, order_by: { curve_id: asc }) {
          term_id
          current_share_price
          position_count
          total_shares
        }
      }
    }
  }
`

export type GetUserPositionsResponse = {
  positions: Array<{
    id: string
    shares: string
    vault: {
      current_share_price: string | null
      term_id: string
      total_shares: string | null
      term: {
        total_market_cap: string | null
        atom: {
          image: string | null
          label: string | null
          term_id: string
        } | null
        triple: {
          object: {
            label: string | null
            term_id: string
          } | null
          predicate: {
            label: string | null
            term_id: string
          } | null
          subject: {
            image: string | null
            label: string | null
            term_id: string
          } | null
          term_id: string
        } | null
      } | null
    } | null
  }>
}

export type GraphqlPosition = GetUserPositionsResponse['positions'][number]

export type GetUserPositionsVariables = {
  address: string
}

export const GET_USER_POSITIONS = gql`
  query GetUserPositions($address: String!) {
    positions(where: { account_id: { _eq: $address } }) {
      id
      shares
      vault {
        term_id
        current_share_price
        total_shares
        term {
          total_market_cap
          atom {
            term_id
            label
            image
          }
          triple {
            term_id
            subject {
              term_id
              label
              image
            }
            predicate {
              term_id
              label
            }
            object {
              term_id
              label
            }
          }
        }
      }
    }
  }
`

export type SearchAtomsResponse = {
  atoms: Array<{
    image: string | null
    label: string | null
    term: {
      total_market_cap: string | null
    } | null
    term_id: string
  }>
}

export type SearchAtomsVariables = {
  limit?: number
  search: string
}

export const SEARCH_ATOMS = gql`
  query SearchAtoms($search: String!, $limit: Int = 8) {
    atoms(
      where: {
        _or: [
          { label: { _ilike: $search } }
          { data: { _ilike: $search } }
          { term_id: { _ilike: $search } }
        ]
      }
      limit: $limit
    ) {
      term_id
      label
      image
      term {
        total_market_cap
      }
    }
  }
`
