import { z } from 'zod'

export const bytes32TermIdSchema = z
  .string()
  .trim()
  .regex(/^0x[0-9a-fA-F]{64}$/, 'Must be a 32-byte hex term ID.')

export const weiAmountSchema = z
  .string()
  .trim()
  .min(1, 'Amount is required.')
  .regex(/^\d+$/, 'Use a whole-number wei amount.')

export const createAtomSchema = z.object({
  content: z.string().trim().min(1, 'Content is required.'),
})

export const createTripleSchema = z.object({
  objectId: bytes32TermIdSchema,
  predicateId: bytes32TermIdSchema,
  subjectId: bytes32TermIdSchema,
})

export const depositSchema = z.object({
  amount: weiAmountSchema,
  termId: bytes32TermIdSchema,
})

export const depositAmountFormSchema = depositSchema.pick({
  amount: true,
})

export const existingAtomSelectionSchema = z.object({
  termId: bytes32TermIdSchema,
})
