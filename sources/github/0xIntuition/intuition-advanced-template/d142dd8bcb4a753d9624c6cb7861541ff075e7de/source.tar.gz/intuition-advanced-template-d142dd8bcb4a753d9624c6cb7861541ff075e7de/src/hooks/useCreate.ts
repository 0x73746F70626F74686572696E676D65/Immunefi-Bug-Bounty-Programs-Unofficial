import { useCallback, useState } from 'react'
import { BaseError, type Hex } from 'viem'
import { useChainId, usePublicClient, useWalletClient } from 'wagmi'

import {
  assertIntuitionTestnetChain,
  createAtom,
  createTriple,
  getWriteConfig,
  type AtomWriteResult,
  type ProtocolTransactionResult,
  type TripleWriteResult,
} from '@/lib/protocol'
import { getTokenSymbol } from '@/lib/format'

export type CreateInput =
  | {
      text: string
      type: 'atom'
    }
  | {
      objectId: string
      predicateId: string
      subjectId: string
      type: 'triple'
    }

export type CreateResult = AtomWriteResult | TripleWriteResult
export type CreateStatus = 'idle' | 'waiting_wallet' | 'confirming' | 'success' | 'error'

function toUserFacingError(
  caughtError: unknown,
  fallbackMessage: string,
  chainId: number,
) {
  const message =
    caughtError instanceof BaseError
      ? caughtError.shortMessage
      : caughtError instanceof Error
        ? caughtError.message.split('\n')[0]?.trim()
        : ''

  if (!message) {
    return new Error(fallbackMessage)
  }

  if (/user rejected/i.test(message)) {
    return new Error('Transaction signature was rejected in the wallet.')
  }

  if (/insufficient funds/i.test(message)) {
    return new Error(
      `Wallet does not have enough ${getTokenSymbol(chainId)} to complete this transaction.`,
    )
  }

  if (/^0x[0-9a-f]+$/i.test(message)) {
    return new Error(fallbackMessage)
  }

  if (/execution reverted/i.test(message) && /0x[0-9a-f]{8,}/i.test(message)) {
    return new Error('Transaction reverted on-chain. Check the inputs and try again.')
  }

  return new Error(message)
}

export function useCreate() {
  const chainId = useChainId()
  const publicClient = usePublicClient()
  const { data: walletClient } = useWalletClient()
  const [error, setError] = useState<Error | null>(null)
  const [result, setResult] = useState<CreateResult | null>(null)
  const [status, setStatus] = useState<CreateStatus>('idle')
  const [transaction, setTransaction] = useState<ProtocolTransactionResult | null>(
    null,
  )

  const create = useCallback(
    async (input: CreateInput) => {
      setError(null)
      setResult(null)
      setStatus('waiting_wallet')
      setTransaction(null)

      try {
        if (!publicClient || !walletClient) {
          throw new Error('Connect a wallet before creating atoms or triples.')
        }

        assertIntuitionTestnetChain(chainId)

        const writeConfig = getWriteConfig(chainId, publicClient, walletClient)
        const onTransactionSubmitted = (nextTransaction: ProtocolTransactionResult) => {
          setStatus('confirming')
          setTransaction(nextTransaction)
        }
        const nextResult =
          input.type === 'atom'
            ? await createAtom(writeConfig, input.text, {
                onTransactionSubmitted,
              })
            : await createTriple(
                writeConfig,
                input.subjectId,
                input.predicateId,
                input.objectId,
                {
                  onTransactionSubmitted,
                },
              )

        setStatus('success')
        setResult(nextResult)
        return nextResult
      } catch (caughtError) {
        const nextError = toUserFacingError(
          caughtError,
          'Unable to submit the transaction.',
          chainId,
        )

        setStatus('error')
        setError(nextError)
        throw nextError
      }
    },
    [chainId, publicClient, walletClient],
  )

  const createAtomMutation = useCallback(
    async (text: string): Promise<AtomWriteResult> => {
      const nextResult = await create({ text, type: 'atom' })

      if (!('atomData' in nextResult)) {
        throw new Error('Expected an atom creation result.')
      }

      return nextResult
    },
    [create],
  )

  const createTripleMutation = useCallback(
    async (
      subjectId: string,
      predicateId: string,
      objectId: string,
    ): Promise<TripleWriteResult> => {
      const nextResult = await create({
        objectId,
        predicateId,
        subjectId,
        type: 'triple',
      })

      if ('atomData' in nextResult) {
        throw new Error('Expected a triple creation result.')
      }

      return nextResult
    },
    [create],
  )

  const reset = useCallback(() => {
    setError(null)
    setResult(null)
    setStatus('idle')
    setTransaction(null)
  }, [])

  const isAwaitingWallet = status === 'waiting_wallet'
  const isConfirming = status === 'confirming'

  return {
    create,
    createAtom: createAtomMutation,
    createTriple: createTripleMutation,
    error,
    isAwaitingWallet,
    isConfirming,
    isLoading: isAwaitingWallet || isConfirming,
    reset,
    result,
    status,
    transaction,
  }
}
