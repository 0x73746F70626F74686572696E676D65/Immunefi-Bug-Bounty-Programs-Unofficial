import { AtomCard } from '@/components/AtomCard'
import { DepositForm } from '@/components/DepositForm'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { getCuratedListById } from '@/config/lists'
import { queryGraphql } from '@/lib/graphql/client'
import {
  GET_ATOM,
  type GetAtomResponse,
  type GetAtomVariables,
} from '@/lib/graphql/queries'

async function getAtomPageData(id: string) {
  const curatedList = getCuratedListById(id)

  try {
    const data = await queryGraphql<GetAtomResponse, GetAtomVariables>(
      GET_ATOM,
      { termId: id },
      'GetAtom',
    )

    return {
      atom: {
        image: data.atom?.image ?? curatedList?.image ?? null,
        label: data.atom?.label ?? curatedList?.name ?? null,
        marketCap: data.atom?.term?.total_market_cap ?? null,
        positionCount: data.atom?.term?.vaults[0]?.position_count ?? null,
        sharePrice: data.atom?.term?.vaults[0]?.current_share_price ?? null,
        termId: id,
        totalShares: data.atom?.term?.vaults[0]?.total_shares ?? null,
      },
      graphqlError: data.atom ? null : 'No indexed atom data was returned.',
      graphqlReady: Boolean(data.atom),
    }
  } catch (error) {
    return {
      atom: {
        image: curatedList?.image ?? null,
        label: curatedList?.name ?? null,
        marketCap: null,
        positionCount: null,
        sharePrice: null,
        termId: id,
        totalShares: null,
      },
      graphqlError:
        error instanceof Error
          ? error.message
          : 'Failed to load atom details from GraphQL.',
      graphqlReady: false,
    }
  }
}

export default async function AtomDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const pageData = await getAtomPageData(id)

  return (
    <div className="space-y-6">
      {!pageData.graphqlReady ? (
        <Card className="border-amber-500/30 bg-amber-500/5">
          <CardHeader>
            <CardTitle className="text-lg">GraphQL data unavailable</CardTitle>
            <CardDescription>
              The on-chain signal form still works, but the indexed vault stats
              could not be loaded.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">
            <p>{pageData.graphqlError}</p>
          </CardContent>
        </Card>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-[1.2fr_1fr]">
        <AtomCard
          image={pageData.atom.image}
          label={pageData.atom.label}
          marketCap={pageData.atom.marketCap}
          positionCount={pageData.atom.positionCount}
          sharePrice={pageData.atom.sharePrice}
          termId={pageData.atom.termId}
          totalShares={pageData.atom.totalShares}
        />

        <Card>
          <CardHeader>
            <CardTitle>Signal on this atom</CardTitle>
            <CardDescription>
              Deposits go straight to the atom vault using the protocol helper
              and default bonding-curve settings.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <DepositForm submitLabel="Signal atom" termId={pageData.atom.termId} title="Atom vault" />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
