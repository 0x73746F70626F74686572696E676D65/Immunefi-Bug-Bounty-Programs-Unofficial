'use client'

import { Loader2Icon } from 'lucide-react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useRouter } from 'next/navigation'
import { useCallback } from 'react'
import { useForm } from 'react-hook-form'
import { toast } from 'sonner'
import { parseEther } from 'viem'
import { useChainId } from 'wagmi'
import { z } from 'zod'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import {
  formatTrustValue,
  getTokenAmountLabel,
  getTokenSymbol,
  shortenHex,
} from '@/lib/format'
import { useDeposit } from '@/hooks/useDeposit'

const trustAmountFormSchema = z.object({
  amount: z
    .string()
    .trim()
    .min(1, 'Amount is required.')
    .regex(/^\d*\.?\d+$/, 'Enter a valid number.'),
})

import type { DepositWriteResult } from '@/lib/protocol'

type DepositFormProps = {
  defaultAmount?: string
  description?: string
  onSuccess?: (result: DepositWriteResult) => void | Promise<void>
  submitLabel?: string
  termId: string
  title?: string
}

type DepositFormValues = z.infer<typeof trustAmountFormSchema>

type TransactionProgressProps = {
  isAwaitingWallet: boolean
  isConfirming: boolean
  transaction?: {
    explorerUrl: string
    txHash: string
  } | null
}

function TransactionProgress({
  isAwaitingWallet,
  isConfirming,
  transaction,
}: TransactionProgressProps) {
  if (!isAwaitingWallet && !isConfirming) {
    return null
  }

  return (
    <div className="flex items-start gap-3 rounded-lg border bg-muted/30 p-3 text-sm">
      <Loader2Icon className="mt-0.5 size-4 animate-spin text-primary" />
      <div className="space-y-1">
        <p className="font-medium">Signal transaction</p>
        <p className="text-muted-foreground">
          {isAwaitingWallet
            ? 'Waiting for wallet approval before submitting the signal.'
            : 'Confirming on-chain...'}
        </p>
        {transaction ? (
          <a
            className="text-primary underline underline-offset-4"
            href={transaction.explorerUrl}
            rel="noreferrer"
            target="_blank"
          >
            Tx {shortenHex(transaction.txHash)}
          </a>
        ) : null}
      </div>
    </div>
  )
}

export function DepositForm({
  defaultAmount = '',
  description,
  onSuccess,
  submitLabel = 'Signal',
  termId,
  title = 'Signal this vault',
}: DepositFormProps) {
  const chainId = useChainId()
  const router = useRouter()
  const depositState = useDeposit()
  const tokenSymbol = getTokenSymbol(chainId)
  const resolvedDescription =
    description ??
    `Enter a ${tokenSymbol} amount to preview the curve output before signaling.`
  const form = useForm<DepositFormValues>({
    defaultValues: {
      amount: defaultAmount,
    },
    mode: 'onChange',
    resolver: zodResolver(trustAmountFormSchema),
  })
  const formId = `deposit-${termId.slice(2, 10)}`

  const toWei = (amount: string) => parseEther(amount).toString()

  const handlePreview = useCallback(
    async (values: DepositFormValues) => {
      try {
        await depositState.preview({
          amount: toWei(values.amount),
          termId,
        })
        toast.success('Deposit preview refreshed.')
      } catch (error) {
        toast.error(
          error instanceof Error ? error.message : 'Failed to preview deposit.',
        )
      }
    },
    [depositState, termId],
  )

  const handleDeposit = useCallback(
    async (values: DepositFormValues) => {
      try {
        const result = await depositState.deposit({
          amount: toWei(values.amount),
          termId,
        })

        toast.success(`Signal confirmed: ${values.amount} ${tokenSymbol}`)
        router.refresh()
        await onSuccess?.(result)
      } catch (error) {
        toast.error(
          error instanceof Error ? error.message : 'Failed to deposit.',
        )
      }
    },
    [depositState, onSuccess, router, termId, tokenSymbol],
  )

  const errorMessage =
    form.formState.errors.amount?.message ?? depositState.error?.message ?? null

  return (
    <div className="space-y-4">
      <div className="space-y-1">
        <h3 className="text-sm font-semibold">{title}</h3>
        <p className="text-sm text-muted-foreground">{resolvedDescription}</p>
      </div>

      <form
        className="space-y-3"
        onSubmit={form.handleSubmit((values) => void handleDeposit(values))}
      >
        <div className="space-y-2">
          <Label htmlFor={`${formId}-amount`}>
            {getTokenAmountLabel(chainId)} <span className="text-destructive">*</span>
          </Label>
          <Input
            className={
              errorMessage ? 'border-destructive focus-visible:ring-destructive/20' : ''
            }
            id={`${formId}-amount`}
            inputMode="decimal"
            placeholder="0.01"
            {...form.register('amount')}
          />
          {errorMessage ? (
            <p className="text-sm font-medium text-destructive">{errorMessage}</p>
          ) : null}
        </div>

        <div className="flex flex-wrap gap-2">
          <Button
            className="gap-2"
            disabled={depositState.isLoading || !form.formState.isValid}
            onClick={() =>
              void form.handleSubmit((values) => handlePreview(values))()
            }
            type="button"
            variant="outline"
          >
            {depositState.isPreviewLoading ? 'Previewing...' : 'Preview'}
          </Button>
          <Button
            className="gap-2"
            disabled={depositState.isLoading || !form.formState.isValid}
            type="submit"
          >
            {depositState.isDepositing ? (
              <>
                <Loader2Icon className="size-4 animate-spin" />
                {depositState.isAwaitingWallet
                  ? 'Waiting for wallet...'
                  : 'Confirming on-chain...'}
              </>
            ) : (
              submitLabel
            )}
          </Button>
        </div>
      </form>

      <TransactionProgress
        isAwaitingWallet={depositState.isAwaitingWallet}
        isConfirming={depositState.isConfirming}
        transaction={depositState.transaction}
      />

      {depositState.previewResult ? (
        <div className="rounded-lg border bg-muted/30 p-3 text-sm">
          <p className="font-medium">Preview</p>
          <p className="mt-1 text-muted-foreground">
            Shares: {formatTrustValue(depositState.previewResult.shares, 4, '')}
          </p>
          <p className="text-muted-foreground">
            Assets after fees:{' '}
            {formatTrustValue(depositState.previewResult.assetsAfterFees, 2, tokenSymbol)}
          </p>
        </div>
      ) : null}

      {depositState.result ? (
        <>
          <Separator />
          <div className="space-y-1 rounded-lg border bg-primary/5 p-3 text-sm">
            <p className="font-medium">Last signal</p>
            <p className="text-muted-foreground">
              Shares received: {formatTrustValue(depositState.result.shares, 4, '')}
            </p>
            <p className="text-xs text-muted-foreground">
              Indexing note: list totals and position views refresh from
              GraphQL, so this signal can take a few seconds to appear.
            </p>
            <a
              className="text-primary underline underline-offset-4"
              href={depositState.result.explorerUrl}
              rel="noreferrer"
              target="_blank"
            >
              View transaction
            </a>
          </div>
        </>
      ) : null}
    </div>
  )
}
