import { NextRequest, NextResponse } from 'next/server'

import { PUBLIC_GRAPHQL_API_URL } from '@/lib/graphql/client'

export async function POST(request: NextRequest) {
  const body = await request.text()
  const response = await fetch(PUBLIC_GRAPHQL_API_URL, {
    body,
    headers: {
      'Content-Type': 'application/json',
    },
    method: 'POST',
  })

  const data = await response.json()

  return NextResponse.json(data, { status: response.status })
}
