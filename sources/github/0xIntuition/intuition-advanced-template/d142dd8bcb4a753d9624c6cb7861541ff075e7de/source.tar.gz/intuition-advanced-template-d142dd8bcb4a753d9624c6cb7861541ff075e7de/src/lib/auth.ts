import * as jose from 'jose'

const AUTH_COOKIE_NAME = 'auth'
const NONCE_COOKIE_NAME = 'siwe_nonce'
const AUTH_TTL_SECONDS = 60 * 60 * 24
const NONCE_TTL_SECONDS = 60 * 5

type CookieStoreLike = {
  get(name: string): { value: string } | undefined
}

function requireSiweJwtSecret() {
  const secret = process.env.SIWE_JWT_SECRET?.trim()

  if (!secret || secret.length < 32) {
    throw new Error(
      'SIWE_JWT_SECRET must be configured and at least 32 characters long.',
    )
  }

  return secret
}

function getJwtSecret() {
  return new TextEncoder().encode(requireSiweJwtSecret())
}

function isSecureCookie() {
  return process.env.NODE_ENV === 'production'
}

export function getAuthCookieName() {
  return AUTH_COOKIE_NAME
}

export function getNonceCookieName() {
  return NONCE_COOKIE_NAME
}

export function getAuthCookieOptions(maxAge = AUTH_TTL_SECONDS) {
  return {
    httpOnly: true,
    maxAge,
    path: '/',
    sameSite: 'lax' as const,
    secure: isSecureCookie(),
  }
}

export function getNonceCookieOptions(maxAge = NONCE_TTL_SECONDS) {
  return {
    httpOnly: true,
    maxAge,
    path: '/',
    sameSite: 'lax' as const,
    secure: isSecureCookie(),
  }
}

export async function issueNonceToken(nonce: string) {
  return new jose.SignJWT({ nonce })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(`${NONCE_TTL_SECONDS}s`)
    .sign(getJwtSecret())
}

export async function verifyNonceToken(token: string) {
  try {
    const { payload } = await jose.jwtVerify(token, getJwtSecret())
    return typeof payload.nonce === 'string' ? payload.nonce : null
  } catch {
    return null
  }
}

export async function issueAuthToken(address: string, chainId: number) {
  return new jose.SignJWT({
    chainId,
  })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setSubject(address)
    .setExpirationTime(`${AUTH_TTL_SECONDS}s`)
    .sign(getJwtSecret())
}

export async function verifyAuth(cookies: CookieStoreLike) {
  const token = cookies.get(AUTH_COOKIE_NAME)?.value
  if (!token) return null

  try {
    const { payload } = await jose.jwtVerify(token, getJwtSecret())
    return typeof payload.sub === 'string' ? payload.sub : null
  } catch {
    return null
  }
}

export async function getUserId(cookies: CookieStoreLike) {
  return verifyAuth(cookies)
}
