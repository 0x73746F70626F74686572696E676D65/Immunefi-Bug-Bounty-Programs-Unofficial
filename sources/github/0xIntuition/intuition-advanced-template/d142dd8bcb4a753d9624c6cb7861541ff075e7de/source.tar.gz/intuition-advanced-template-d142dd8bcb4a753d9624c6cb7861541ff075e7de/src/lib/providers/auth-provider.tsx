'use client'

import { createContext, useCallback, useContext, useMemo } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { useAccount, useDisconnect } from 'wagmi'

import { getSiweErrorMessage, useSiweAuth } from '@/hooks/useSiweAuth'

type AuthStatus =
  | 'idle'
  | 'connecting'
  | 'signing'
  | 'authenticated'
  | 'disconnecting'

export type AuthContextValue = {
  authenticatedAddress: string | null
  isAuthenticated: boolean
  isLoading: boolean
  isLoggingOut: boolean
  isReady: boolean
  status: AuthStatus
  connect: () => Promise<void>
  disconnect: () => Promise<void>
}

const defaultAuthContext: AuthContextValue = {
  authenticatedAddress: null,
  isAuthenticated: false,
  isLoading: false,
  isLoggingOut: false,
  isReady: false,
  status: 'idle',
  connect: async () => {},
  disconnect: async () => {},
}

const AuthContext = createContext<AuthContextValue>(defaultAuthContext)

export function AuthProvider({
  children,
  initialAuthenticatedAddress,
}: {
  children: React.ReactNode
  initialAuthenticatedAddress?: string | null
}) {
  const { isConnected, status: walletStatus } = useAccount()
  const { disconnect: wagmiDisconnect } = useDisconnect()
  const router = useRouter()

  const {
    authenticatedAddress,
    isAuthenticated,
    isSessionLoading,
    isSigning,
    signIn,
    signOut,
  } = useSiweAuth({
    initialAuthenticatedAddress,
    onAuthFailure(error) {
      toast.error(getSiweErrorMessage(error))
    },
    onAuthSuccess() {
      toast.success('Authenticated with SIWE.')
      router.refresh()
    },
  })

  const connect = useCallback(async () => {
    if (!isConnected) return
    await signIn()
  }, [isConnected, signIn])

  const disconnect = useCallback(async () => {
    try {
      await signOut()
      wagmiDisconnect()
      router.refresh()
      toast.success('Signed out.')
    } finally {
      // no-op
    }
  }, [router, signOut, wagmiDisconnect])

  const value = useMemo<AuthContextValue>(
    () => ({
      authenticatedAddress,
      connect,
      disconnect,
      isAuthenticated,
      isLoading: isSessionLoading || isSigning,
      isLoggingOut: false,
      isReady: walletStatus !== 'reconnecting',
      status: isAuthenticated
        ? 'authenticated'
        : isSigning
          ? 'signing'
          : isConnected
            ? 'connecting'
            : 'idle',
    }),
    [
      authenticatedAddress,
      connect,
      disconnect,
      isAuthenticated,
      isConnected,
      isSessionLoading,
      isSigning,
      walletStatus,
    ],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  return useContext(AuthContext)
}
