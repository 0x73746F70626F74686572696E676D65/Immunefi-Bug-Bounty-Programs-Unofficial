'use client'

import Link from 'next/link'

import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  formatCount,
  formatTermLabel,
  formatTrustValue,
  getSharePriceSuffix,
  getInitials,
  shortenHex,
} from '@/lib/format'

type AtomCardProps = {
  image?: string | null
  label?: string | null
  marketCap?: string | null
  positionCount?: number | null
  sharePrice?: string | null
  termId: string
  to?: string
  totalShares?: string | null
}

export function AtomCard({
  image,
  label,
  marketCap,
  positionCount,
  sharePrice,
  termId,
  to,
  totalShares,
}: AtomCardProps) {
  const title = formatTermLabel(label, shortenHex(termId))

  return (
    <Card className="h-full">
      <CardHeader className="gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="flex min-w-0 items-start gap-3">
          <Avatar size="lg">
            {image ? <AvatarImage alt={title} src={image} /> : null}
            <AvatarFallback>{getInitials(title)}</AvatarFallback>
          </Avatar>
          <div className="min-w-0 space-y-1">
            <CardTitle className="text-base">
              {to ? (
                <Link className="hover:text-primary hover:underline" href={to}>
                  {title}
                </Link>
              ) : (
                title
              )}
            </CardTitle>
            <p className="text-xs text-muted-foreground">{termId}</p>
          </div>
        </div>
        <Badge variant="secondary">
          {formatCount(positionCount, 'position')}
        </Badge>
      </CardHeader>
      <CardContent className="grid gap-3 text-sm sm:grid-cols-3">
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">
            Market cap
          </p>
          <p className="font-medium">{formatTrustValue(marketCap)}</p>
        </div>
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">
            Share price
          </p>
          <p className="font-medium">
            {formatTrustValue(sharePrice, 4, getSharePriceSuffix())}
          </p>
        </div>
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">
            Total shares
          </p>
          <p className="font-medium">
            {formatTrustValue(totalShares, 2, 'shares')}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
