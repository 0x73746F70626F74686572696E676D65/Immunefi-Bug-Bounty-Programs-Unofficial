'use client'

import {
  ListChecksIcon,
  PlusIcon,
  SparklesIcon,
  WalletIcon,
} from 'lucide-react'
import Link from 'next/link'
import dynamic from 'next/dynamic'
import { usePathname } from 'next/navigation'
import { useEffect, useState } from 'react'
import { useAccount } from 'wagmi'

import { Badge } from '@/components/ui/badge'
import { buttonVariants } from '@/components/ui/button-variants'
import { Button } from '@/components/ui/button'
import { SidebarTrigger } from '@/components/ui/sidebar'
import { cn } from '@/lib/utils'
import { useAuth } from '@/lib/providers/auth-provider'

const navigation = [
  { href: '/', label: 'Lists', icon: ListChecksIcon, end: true },
  { href: '/create', label: 'Create', icon: PlusIcon },
  { href: '/positions', label: 'Positions', icon: WalletIcon },
]

const WalletConnectButton = dynamic(
  () =>
    import('@/components/wallet-connect-button').then(
      (module) => module.WalletConnectButton,
    ),
  {
    ssr: false,
  },
)

export function Header() {
  const pathname = usePathname()
  const { isConnected } = useAccount()
  const [isMounted, setIsMounted] = useState(false)
  const {
    authenticatedAddress,
    connect,
    disconnect,
    isAuthenticated,
    isLoading,
    isLoggingOut,
    isReady,
    status,
  } = useAuth()

  const authLabel = isAuthenticated
    ? 'Authenticated'
    : status === 'signing'
      ? 'Signing'
      : isConnected
        ? 'Wallet connected'
        : 'Read-only'

  useEffect(() => {
    setIsMounted(true)
  }, [])

  return (
    <header className="sticky top-0 z-30 border-b bg-background/90 backdrop-blur">
      <div className="flex min-h-16 items-center gap-3 px-4 md:px-6">
        <SidebarTrigger
          aria-label="Toggle sidebar"
          className="size-9 shrink-0"
          variant="ghost"
        />

        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <Link
              className="inline-flex items-center gap-2 text-sm font-semibold tracking-tight"
              href="/"
            >
              <SparklesIcon className="size-4 text-primary" />
              Intuition Advanced Template
            </Link>
            <Badge variant="secondary">Curated lists</Badge>
          </div>
          <p className="hidden text-xs text-muted-foreground md:block">
            GraphQL reads, protocol writes, SIWE auth.
          </p>
        </div>

        <nav className="hidden items-center gap-1 md:flex">
          {navigation.map((item) => {
            const isActive = item.end
              ? pathname === item.href
              : pathname.startsWith(item.href)

            return (
              <Link
                className={cn(
                  buttonVariants({
                    size: 'sm',
                    variant: 'ghost',
                  }),
                  'inline-flex items-center gap-2',
                  isActive && 'bg-accent text-accent-foreground',
                )}
                href={item.href}
                key={item.href}
              >
                <item.icon className="size-4" />
                {item.label}
              </Link>
            )
          })}
        </nav>

        <div className="flex items-center gap-2">
          <Badge variant={isAuthenticated ? 'default' : 'outline'}>
            {authLabel}
          </Badge>
          {isAuthenticated && authenticatedAddress ? (
            <Badge variant="secondary">
              {`${authenticatedAddress.slice(0, 6)}...${authenticatedAddress.slice(-4)}`}
            </Badge>
          ) : null}
          <Button
            disabled={!isReady || isLoading || (!isConnected && !isAuthenticated)}
            onClick={isAuthenticated ? () => void disconnect() : () => void connect()}
            size="sm"
            variant={isAuthenticated ? 'outline' : 'default'}
          >
            {isLoggingOut
              ? 'Logging out...'
              : isAuthenticated
                ? 'Logout'
                : isConnected
                  ? 'Sign in'
                  : 'Authenticate'}
          </Button>
          {isMounted ? (
            <WalletConnectButton />
          ) : (
            <div className="h-10 w-10 rounded-lg border bg-muted/40" />
          )}
        </div>
      </div>
    </header>
  )
}
