'use client'

import Link from 'next/link'
import { Loader2Icon } from 'lucide-react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { toast } from 'sonner'
import { z } from 'zod'

import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useCreate } from '@/hooks/useCreate'
import { shortenHex } from '@/lib/format'
import { createAtomSchema, createTripleSchema } from '@/lib/validation'

type CreateAtomFormValues = z.infer<typeof createAtomSchema>
type CreateTripleFormValues = z.infer<typeof createTripleSchema>

function CreateTransactionProgress({
  isAwaitingWallet,
  isConfirming,
  transaction,
}: {
  isAwaitingWallet: boolean
  isConfirming: boolean
  transaction: { explorerUrl: string; txHash: string } | null
}) {
  if (!isAwaitingWallet && !isConfirming) {
    return null
  }

  return (
    <div className="flex items-start gap-3 rounded-lg border bg-muted/30 p-3 text-sm">
      <Loader2Icon className="mt-0.5 size-4 animate-spin text-primary" />
      <div className="space-y-1">
        <p className="font-medium">
          {isAwaitingWallet ? 'Waiting for wallet...' : 'Confirming on-chain...'}
        </p>
        <p className="text-muted-foreground">
          {isAwaitingWallet
            ? 'Approve the transaction in your wallet to continue.'
            : 'The transaction has been submitted and is waiting for confirmation.'}
        </p>
        {transaction ? (
          <a
            className="text-primary underline underline-offset-4"
            href={transaction.explorerUrl}
            rel="noreferrer"
            target="_blank"
          >
            Tx {shortenHex(transaction.txHash)}
          </a>
        ) : null}
      </div>
    </div>
  )
}

export default function CreatePage() {
  const atomCreate = useCreate()
  const tripleCreate = useCreate()
  const atomForm = useForm<CreateAtomFormValues>({
    defaultValues: {
      content: '',
    },
    mode: 'onChange',
    resolver: zodResolver(createAtomSchema),
  })
  const tripleForm = useForm<CreateTripleFormValues>({
    defaultValues: {
      objectId: '',
      predicateId: '',
      subjectId: '',
    },
    mode: 'onChange',
    resolver: zodResolver(createTripleSchema),
  })

  async function handleCreateAtom(values: CreateAtomFormValues) {
    try {
      await atomCreate.createAtom(values.content)
      atomForm.reset()
      toast.success('Atom created on-chain.')
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : 'Failed to create atom.',
      )
    }
  }

  async function handleCreateTriple(values: CreateTripleFormValues) {
    try {
      await tripleCreate.createTriple(
        values.subjectId,
        values.predicateId,
        values.objectId,
      )
      tripleForm.reset()
      toast.success('Triple created on-chain.')
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : 'Failed to create triple.',
      )
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Create atom</CardTitle>
          <CardDescription>
            Mint a new atom from free-form content. The protocol wrapper resolves
            cost and parses the resulting event for you.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <form
            className="space-y-4"
            onSubmit={atomForm.handleSubmit((values) => void handleCreateAtom(values))}
          >
            <div className="space-y-2">
              <Label htmlFor="atom-content">
                Content <span className="text-destructive">*</span>
              </Label>
              <Input
                className={
                  atomForm.formState.errors.content?.message
                    ? 'border-destructive focus-visible:ring-destructive/20'
                    : ''
                }
                id="atom-content"
                placeholder="Solidity, Base, Zero-knowledge proofs..."
                {...atomForm.register('content')}
              />
              {atomForm.formState.errors.content?.message ? (
                <p className="text-sm text-destructive">
                  {atomForm.formState.errors.content.message}
                </p>
              ) : null}
            </div>
            <Button
              className="w-full"
              disabled={atomCreate.isLoading || !atomForm.formState.isValid}
              type="submit"
            >
              {atomCreate.isLoading
                ? atomCreate.isAwaitingWallet
                  ? 'Waiting for wallet...'
                  : 'Confirming on-chain...'
                : 'Create atom'}
            </Button>
          </form>

          <CreateTransactionProgress
            isAwaitingWallet={atomCreate.isAwaitingWallet}
            isConfirming={atomCreate.isConfirming}
            transaction={atomCreate.transaction}
          />

          {atomCreate.result ? (
            <div className="rounded-lg border bg-primary/5 p-3 text-sm">
              <p className="font-medium">Last atom</p>
              <p className="text-muted-foreground">
                Term ID: {atomCreate.result.termId}
              </p>
              <div className="mt-2 flex flex-wrap gap-3">
                <Link
                  className="text-primary underline underline-offset-4"
                  href={`/atom/${atomCreate.result.termId}`}
                >
                  Open atom route
                </Link>
                <a
                  className="text-primary underline underline-offset-4"
                  href={atomCreate.result.explorerUrl}
                  rel="noreferrer"
                  target="_blank"
                >
                  View transaction
                </a>
              </div>
            </div>
          ) : null}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Create triple</CardTitle>
          <CardDescription>
            Submit a raw subject-predicate-object relationship for debugging,
            teaching, or one-off list tooling.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <form
            className="space-y-4"
            onSubmit={tripleForm.handleSubmit(
              (values) => void handleCreateTriple(values),
            )}
          >
            <div className="space-y-2">
              <Label htmlFor="subject-id">
                Subject term ID <span className="text-destructive">*</span>
              </Label>
              <Input
                className={
                  tripleForm.formState.errors.subjectId?.message
                    ? 'border-destructive focus-visible:ring-destructive/20'
                    : ''
                }
                id="subject-id"
                placeholder="0x..."
                {...tripleForm.register('subjectId')}
              />
              {tripleForm.formState.errors.subjectId?.message ? (
                <p className="text-sm text-destructive">
                  {tripleForm.formState.errors.subjectId.message}
                </p>
              ) : null}
            </div>
            <div className="space-y-2">
              <Label htmlFor="predicate-id">
                Predicate term ID <span className="text-destructive">*</span>
              </Label>
              <Input
                className={
                  tripleForm.formState.errors.predicateId?.message
                    ? 'border-destructive focus-visible:ring-destructive/20'
                    : ''
                }
                id="predicate-id"
                placeholder="0x..."
                {...tripleForm.register('predicateId')}
              />
              {tripleForm.formState.errors.predicateId?.message ? (
                <p className="text-sm text-destructive">
                  {tripleForm.formState.errors.predicateId.message}
                </p>
              ) : null}
            </div>
            <div className="space-y-2">
              <Label htmlFor="object-id">
                Object term ID <span className="text-destructive">*</span>
              </Label>
              <Input
                className={
                  tripleForm.formState.errors.objectId?.message
                    ? 'border-destructive focus-visible:ring-destructive/20'
                    : ''
                }
                id="object-id"
                placeholder="0x..."
                {...tripleForm.register('objectId')}
              />
              {tripleForm.formState.errors.objectId?.message ? (
                <p className="text-sm text-destructive">
                  {tripleForm.formState.errors.objectId.message}
                </p>
              ) : null}
            </div>
            <Button
              className="w-full"
              disabled={tripleCreate.isLoading || !tripleForm.formState.isValid}
              type="submit"
              variant="outline"
            >
              {tripleCreate.isLoading
                ? tripleCreate.isAwaitingWallet
                  ? 'Waiting for wallet...'
                  : 'Confirming on-chain...'
                : 'Create triple'}
            </Button>
          </form>

          <CreateTransactionProgress
            isAwaitingWallet={tripleCreate.isAwaitingWallet}
            isConfirming={tripleCreate.isConfirming}
            transaction={tripleCreate.transaction}
          />

          {tripleCreate.result ? (
            <div className="rounded-lg border bg-primary/5 p-3 text-sm">
              <p className="font-medium">Last triple</p>
              <p className="text-muted-foreground">
                Term ID: {tripleCreate.result.termId}
              </p>
              <p className="text-xs text-muted-foreground">
                Indexing note: newly created triples can take a few seconds to
                appear in GraphQL-backed list and positions views.
              </p>
              <a
                className="mt-2 inline-block text-primary underline underline-offset-4"
                href={tripleCreate.result.explorerUrl}
                rel="noreferrer"
                target="_blank"
              >
                View transaction
              </a>
            </div>
          ) : null}
        </CardContent>
      </Card>
    </div>
  )
}
