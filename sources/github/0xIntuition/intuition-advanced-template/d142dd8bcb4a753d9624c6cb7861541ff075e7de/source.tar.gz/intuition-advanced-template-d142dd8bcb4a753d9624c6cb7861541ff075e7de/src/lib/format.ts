import { intuitionMainnet, intuitionTestnet } from '@0xintuition/protocol'
import { formatEther } from 'viem'

type TrustValue = bigint | number | string | null | undefined

export function formatTermLabel(
  label: string | null | undefined,
  fallback = 'Untitled term',
) {
  const trimmed = label?.trim()

  return trimmed || fallback
}

export function shortenHex(value: string, leading = 6, trailing = 4) {
  if (value.length <= leading + trailing + 3) {
    return value
  }

  return `${value.slice(0, leading)}...${value.slice(-trailing)}`
}

export function getInitials(label: string | null | undefined) {
  const resolvedLabel = formatTermLabel(label, 'Term')

  return resolvedLabel
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? '')
    .join('')
}

export function formatCount(
  value: number | null | undefined,
  singularLabel: string,
  pluralLabel = `${singularLabel}s`,
) {
  if (value === null || value === undefined) {
    return 'Pending'
  }

  const label = value === 1 ? singularLabel : pluralLabel
  return `${value.toLocaleString()} ${label}`
}

export function getTokenSymbol(chainId: number = intuitionTestnet.id) {
  return chainId === intuitionMainnet.id ? 'TRUST' : 'tTRUST'
}

export function getSharePriceSuffix(chainId: number = intuitionTestnet.id) {
  return `${getTokenSymbol(chainId)} / share`
}

export function getTokenAmountLabel(chainId: number = intuitionTestnet.id) {
  return `Amount in ${getTokenSymbol(chainId)}`
}

export function formatTrustValue(
  value: TrustValue,
  maximumFractionDigits = 2,
  suffix = getTokenSymbol(),
) {
  if (value === null || value === undefined) {
    return 'Pending'
  }

  try {
    const bigintValue = typeof value === 'bigint' ? value : BigInt(value)
    const numericValue = Number(formatEther(bigintValue))

    if (!Number.isFinite(numericValue)) {
      return 'Pending'
    }

    const formatted = numericValue.toLocaleString(undefined, {
      maximumFractionDigits,
    })

    return suffix ? `${formatted} ${suffix}` : formatted
  } catch {
    return 'Pending'
  }
}
