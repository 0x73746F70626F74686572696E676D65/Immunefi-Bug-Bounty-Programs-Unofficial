import { cookies } from 'next/headers'

import { PositionRow } from '@/components/PositionRow'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { getUserId } from '@/lib/auth'
import { queryGraphql } from '@/lib/graphql/client'
import {
  GET_USER_POSITIONS,
  type GetUserPositionsResponse,
  type GetUserPositionsVariables,
} from '@/lib/graphql/queries'
import { shortenHex } from '@/lib/format'

async function getPositionsPageData() {
  const cookieStore = await cookies()
  const address = await getUserId(cookieStore)

  if (!address) {
    return {
      address: null,
      graphqlError: null,
      graphqlReady: false,
      positions: [],
    }
  }

  try {
    const data = await queryGraphql<
      GetUserPositionsResponse,
      GetUserPositionsVariables
    >(GET_USER_POSITIONS, { address }, 'GetUserPositions')

    return {
      address,
      graphqlError: null,
      graphqlReady: true,
      positions: data.positions,
    }
  } catch (error) {
    return {
      address,
      graphqlError:
        error instanceof Error
          ? error.message
          : 'Failed to load positions from GraphQL.',
      graphqlReady: false,
      positions: [],
    }
  }
}

export default async function PositionsPage() {
  const pageData = await getPositionsPageData()

  if (!pageData.address) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>My positions</CardTitle>
            <CardDescription>
              Sign in with your wallet to view your positions and signals.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>My positions</CardTitle>
          <CardDescription>
            Current authenticated account: {shortenHex(pageData.address)}
          </CardDescription>
        </CardHeader>
      </Card>

      {!pageData.graphqlReady ? (
        <Card className="border-amber-500/30 bg-amber-500/5">
          <CardHeader>
            <CardTitle className="text-lg">GraphQL data unavailable</CardTitle>
            <CardDescription>
              Your auth session is valid, but the indexed positions query could
              not be completed.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">
            <p>{pageData.graphqlError}</p>
          </CardContent>
        </Card>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>Signals across atoms and list memberships</CardTitle>
          <CardDescription>
            The table mixes direct atom positions and triple positions created by
            list curation flows.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {pageData.positions.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Term</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Shares</TableHead>
                  <TableHead>Share price</TableHead>
                  <TableHead>Market cap</TableHead>
                  <TableHead>Route</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pageData.positions.map((position) => (
                  <PositionRow key={position.id} position={position} />
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
              No indexed positions were returned for this account yet.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
