import type { Metadata } from 'next'
import { cookies } from 'next/headers'

import { AppShell } from '@/components/app-shell'
import { getUserId } from '@/lib/auth'

import { Providers } from './providers'
import './globals.css'

export const metadata: Metadata = {
  title: 'Intuition Advanced Template',
  description:
    'Curated lists on the Intuition knowledge graph with GraphQL reads, protocol writes, and SIWE auth.',
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  const cookieStore = await cookies()
  const initialAuthenticatedAddress = await getUserId(cookieStore)

  return (
    <html lang="en" suppressHydrationWarning>
      <body className="min-h-screen bg-background text-foreground antialiased">
        <Providers initialAuthenticatedAddress={initialAuthenticatedAddress}>
          <AppShell>{children}</AppShell>
        </Providers>
      </body>
    </html>
  )
}
