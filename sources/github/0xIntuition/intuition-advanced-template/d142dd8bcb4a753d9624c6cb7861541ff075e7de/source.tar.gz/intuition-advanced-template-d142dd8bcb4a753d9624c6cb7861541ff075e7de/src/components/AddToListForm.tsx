'use client'

import { Loader2Icon } from 'lucide-react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useQuery } from '@tanstack/react-query'
import { useRouter } from 'next/navigation'
import { useDeferredValue, useMemo, useState } from 'react'
import { useForm } from 'react-hook-form'
import { toast } from 'sonner'
import { z } from 'zod'

import { AtomCard } from '@/components/AtomCard'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { requestGraphql } from '@/lib/graphql/client'
import {
  SEARCH_ATOMS,
  type SearchAtomsResponse,
  type SearchAtomsVariables,
} from '@/lib/graphql/queries'
import { formatTermLabel, shortenHex } from '@/lib/format'
import {
  createAtomSchema,
  existingAtomSelectionSchema,
} from '@/lib/validation'
import { useCreate } from '@/hooks/useCreate'

import type { AtomWriteResult, TripleWriteResult } from '@/lib/protocol'

type AddToListFormProps = {
  listId: string
  listName: string
  onSuccess?: () => void | Promise<void>
  predicateId: string
}

type ExistingAtomFormValues = z.infer<typeof existingAtomSelectionSchema>
type NewAtomFormValues = z.infer<typeof createAtomSchema>
type SearchAtom = SearchAtomsResponse['atoms'][number]

type TransactionProgressProps = {
  isAwaitingWallet: boolean
  isConfirming: boolean
  label: string
  transaction?: {
    explorerUrl: string
    txHash: string
  } | null
}

function TransactionProgress({
  isAwaitingWallet,
  isConfirming,
  label,
  transaction,
}: TransactionProgressProps) {
  if (!isAwaitingWallet && !isConfirming) {
    return null
  }

  return (
    <div className="flex items-start gap-3 rounded-lg border bg-muted/30 p-3 text-sm">
      <Loader2Icon className="mt-0.5 size-4 animate-spin text-primary" />
      <div className="space-y-1">
        <p className="font-medium">{label}</p>
        <p className="text-muted-foreground">
          {isAwaitingWallet
            ? 'Waiting for wallet approval before submitting the transaction.'
            : 'Confirming on-chain...'}
        </p>
        {transaction ? (
          <a
            className="text-primary underline underline-offset-4"
            href={transaction.explorerUrl}
            rel="noreferrer"
            target="_blank"
          >
            Tx {shortenHex(transaction.txHash)}
          </a>
        ) : null}
      </div>
    </div>
  )
}

export function AddToListForm({
  listId,
  listName,
  onSuccess,
  predicateId,
}: AddToListFormProps) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<'existing' | 'new'>('existing')
  const [existingSearch, setExistingSearch] = useState('')
  const [selectedAtom, setSelectedAtom] = useState<SearchAtom | null>(null)
  const [existingResult, setExistingResult] = useState<TripleWriteResult | null>(
    null,
  )
  const [newResult, setNewResult] = useState<{
    atom: AtomWriteResult
    triple: TripleWriteResult
  } | null>(null)
  const deferredSearch = useDeferredValue(existingSearch)

  const existingTripleCreate = useCreate()
  const newAtomCreate = useCreate()
  const newTripleCreate = useCreate()
  const activeNewCreateState = newTripleCreate.isLoading
    ? newTripleCreate
    : newAtomCreate

  const existingForm = useForm<ExistingAtomFormValues>({
    defaultValues: {
      termId: '',
    },
    mode: 'onChange',
    resolver: zodResolver(existingAtomSelectionSchema),
  })
  const newForm = useForm<NewAtomFormValues>({
    defaultValues: {
      content: '',
    },
    mode: 'onChange',
    resolver: zodResolver(createAtomSchema),
  })

  const searchQuery = useQuery({
    enabled:
      activeTab === 'existing' && deferredSearch.trim().length > 1,
    queryFn: async () =>
      requestGraphql<SearchAtomsResponse, SearchAtomsVariables>(
        SEARCH_ATOMS,
        {
          limit: 8,
          search: `%${deferredSearch.trim()}%`,
        },
        'SearchAtoms',
      ),
    queryKey: ['search-atoms', deferredSearch.trim()],
  })

  const searchResults = useMemo(() => {
    const atoms = searchQuery.data?.atoms ?? []

    return atoms.slice().sort((left, right) => {
      const leftCap = BigInt(left.term?.total_market_cap ?? '0')
      const rightCap = BigInt(right.term?.total_market_cap ?? '0')

      if (leftCap === rightCap) {
        return formatTermLabel(left.label, left.term_id).localeCompare(
          formatTermLabel(right.label, right.term_id),
        )
      }

      return leftCap > rightCap ? -1 : 1
    })
  }, [searchQuery.data?.atoms])

  async function handleAddExisting(values: ExistingAtomFormValues) {
    try {
      const result = await existingTripleCreate.createTriple(
        values.termId,
        predicateId,
        listId,
      )

      setExistingResult(result)
      toast.success(`List membership created: ${shortenHex(result.termId)}`)
      router.refresh()
      await onSuccess?.()
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : 'Failed to add the selected atom to this list.',
      )
    }
  }

  async function handleCreateNew(values: NewAtomFormValues) {
    try {
      const atom = await newAtomCreate.createAtom(values.content)
      toast.success(`Atom created: ${shortenHex(atom.termId)}`)
      const triple = await newTripleCreate.createTriple(
        atom.termId,
        predicateId,
        listId,
      )

      setNewResult({ atom, triple })
      newForm.reset()
      toast.success(`List membership created: ${shortenHex(triple.termId)}`)
      router.refresh()
      await onSuccess?.()
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : 'Failed to create a new list item.',
      )
    }
  }

  const combinedError =
    existingTripleCreate.error?.message ??
    newAtomCreate.error?.message ??
    newTripleCreate.error?.message ??
    (searchQuery.error instanceof Error ? searchQuery.error.message : null)

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add an item</CardTitle>
        <CardDescription>
          Search for an existing atom or mint a new atom, then create the
          <code> has_tag </code>
          triple that adds it to {listName}.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Tabs
          onValueChange={(value) => setActiveTab(value as 'existing' | 'new')}
          value={activeTab}
        >
          <TabsList>
            <TabsTrigger value="existing">Use existing atom</TabsTrigger>
            <TabsTrigger value="new">Create new atom</TabsTrigger>
          </TabsList>

          <TabsContent className="space-y-4" value="existing">
            <form
              className="space-y-4"
              onSubmit={existingForm.handleSubmit(
                (values) => void handleAddExisting(values),
              )}
            >
              <div className="space-y-2">
                <Label htmlFor="existing-search">
                  Search atoms <span className="text-destructive">*</span>
                </Label>
                <Input
                  className={
                    existingForm.formState.errors.termId?.message
                      ? 'border-destructive focus-visible:ring-destructive/20'
                      : ''
                  }
                  id="existing-search"
                  onChange={(event) => setExistingSearch(event.target.value)}
                  placeholder="Search by label or paste a term ID"
                  value={existingSearch}
                />
                <p className="text-xs text-muted-foreground">
                  Type at least two characters to query the proxied GraphQL
                  endpoint.
                </p>
                {existingForm.formState.errors.termId?.message ? (
                  <p className="text-sm font-medium text-destructive">
                    {existingForm.formState.errors.termId.message}
                  </p>
                ) : null}
              </div>

              {searchQuery.isPending ? (
                <div className="rounded-lg border border-dashed p-3 text-sm text-muted-foreground">
                  Loading atom search results...
                </div>
              ) : null}

              {searchResults.length > 0 ? (
                <div className="grid gap-2">
                  {searchResults.map((atom) => {
                    const isSelected = selectedAtom?.term_id === atom.term_id

                    return (
                      <button
                        className={`rounded-lg border p-3 text-left transition-colors ${
                          isSelected
                            ? 'border-primary bg-primary/5'
                            : 'hover:border-primary/40 hover:bg-muted/50'
                        }`}
                        key={atom.term_id}
                        onClick={() => {
                          setSelectedAtom(atom)
                          existingForm.setValue('termId', atom.term_id, {
                            shouldDirty: true,
                            shouldValidate: true,
                          })
                        }}
                        type="button"
                      >
                        <div className="flex items-center justify-between gap-3">
                          <div className="space-y-1">
                            <p className="font-medium">
                              {formatTermLabel(atom.label, atom.term_id)}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {atom.term_id}
                            </p>
                          </div>
                          <Badge variant="outline">
                            {atom.term?.total_market_cap
                              ? 'Tracked'
                              : 'No stake yet'}
                          </Badge>
                        </div>
                      </button>
                    )
                  })}
                </div>
              ) : null}

              {deferredSearch.trim().length > 1 &&
              !searchQuery.isPending &&
              searchResults.length === 0 ? (
                <div className="rounded-lg border border-dashed p-3 text-sm text-muted-foreground">
                  No atoms matched this search. Switch to
                  <strong> Create new atom </strong>
                  if you want to mint the item first.
                </div>
              ) : null}

              {selectedAtom ? (
                <AtomCard
                  image={selectedAtom.image}
                  label={selectedAtom.label}
                  marketCap={selectedAtom.term?.total_market_cap ?? null}
                  termId={selectedAtom.term_id}
                  to={`/atom/${selectedAtom.term_id}`}
                />
              ) : null}

              <Button
                className="gap-2"
                disabled={
                  existingTripleCreate.isLoading ||
                  !existingForm.formState.isValid ||
                  !selectedAtom
                }
                type="submit"
              >
                {existingTripleCreate.isLoading ? (
                  <>
                    <Loader2Icon className="size-4 animate-spin" />
                    {existingTripleCreate.isAwaitingWallet
                      ? 'Waiting for wallet...'
                      : 'Confirming on-chain...'}
                  </>
                ) : (
                  'Add selected atom'
                )}
              </Button>
            </form>

            <TransactionProgress
              isAwaitingWallet={existingTripleCreate.isAwaitingWallet}
              isConfirming={existingTripleCreate.isConfirming}
              label="Adding item to the list"
              transaction={existingTripleCreate.transaction}
            />

            {existingResult ? (
              <div className="rounded-lg border bg-primary/5 p-3 text-sm">
                <p className="font-medium">Last list membership</p>
                <p className="text-muted-foreground">
                  Triple term: {existingResult.termId}
                </p>
                <p className="text-xs text-muted-foreground">
                  Indexing note: new list items can take a few seconds to appear
                  in GraphQL-backed views.
                </p>
                <a
                  className="text-primary underline underline-offset-4"
                  href={existingResult.explorerUrl}
                  rel="noreferrer"
                  target="_blank"
                >
                  View transaction
                </a>
              </div>
            ) : null}
          </TabsContent>

          <TabsContent className="space-y-4" value="new">
            <form
              className="space-y-4"
              onSubmit={newForm.handleSubmit((values) => void handleCreateNew(values))}
            >
              <div className="space-y-2">
                <Label htmlFor="new-atom-content">
                  Atom content <span className="text-destructive">*</span>
                </Label>
                <Input
                  className={
                    newForm.formState.errors.content?.message
                      ? 'border-destructive focus-visible:ring-destructive/20'
                      : ''
                  }
                  id="new-atom-content"
                  placeholder="Lens, Farcaster, Solidity, zk proofs..."
                  {...newForm.register('content')}
                />
                {newForm.formState.errors.content?.message ? (
                  <p className="text-sm font-medium text-destructive">
                    {newForm.formState.errors.content.message}
                  </p>
                ) : null}
              </div>

              <Button
                className="gap-2"
                disabled={
                  newAtomCreate.isLoading ||
                  newTripleCreate.isLoading ||
                  !newForm.formState.isValid
                }
                type="submit"
              >
                {newAtomCreate.isLoading || newTripleCreate.isLoading ? (
                  <>
                    <Loader2Icon className="size-4 animate-spin" />
                    {activeNewCreateState.isAwaitingWallet
                      ? 'Waiting for wallet...'
                      : 'Confirming on-chain...'}
                  </>
                ) : (
                  'Create atom and add to list'
                )}
              </Button>
            </form>

            <TransactionProgress
              isAwaitingWallet={newAtomCreate.isAwaitingWallet}
              isConfirming={newAtomCreate.isConfirming}
              label="Creating the new atom"
              transaction={newAtomCreate.transaction}
            />
            <TransactionProgress
              isAwaitingWallet={newTripleCreate.isAwaitingWallet}
              isConfirming={newTripleCreate.isConfirming}
              label="Adding the atom to the list"
              transaction={newTripleCreate.transaction}
            />

            {newResult ? (
              <div className="space-y-3 rounded-lg border bg-primary/5 p-3 text-sm">
                <div>
                  <p className="font-medium">Atom created</p>
                  <p className="text-muted-foreground">
                    Atom term: {newResult.atom.termId}
                  </p>
                  <a
                    className="text-primary underline underline-offset-4"
                    href={newResult.atom.explorerUrl}
                    rel="noreferrer"
                    target="_blank"
                  >
                    View atom transaction
                  </a>
                </div>
                <div>
                  <p className="font-medium">List membership created</p>
                  <p className="text-muted-foreground">
                    Triple term: {newResult.triple.termId}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Indexing note: the new item may take a few seconds to show
                    up in the list.
                  </p>
                  <a
                    className="text-primary underline underline-offset-4"
                    href={newResult.triple.explorerUrl}
                    rel="noreferrer"
                    target="_blank"
                  >
                    View triple transaction
                  </a>
                </div>
              </div>
            ) : null}
          </TabsContent>
        </Tabs>

        {combinedError ? (
          <p className="text-sm text-destructive">{combinedError}</p>
        ) : null}
      </CardContent>
    </Card>
  )
}
