# intuition-advanced-template

## Project Type
Next.js 16 App Router. Intuition curated-lists app template with GraphQL reads, protocol writes, and fully self-hosted SIWE auth.

## Commands
- `bun dev` — start the development server
- `bun run build` — create a production build
- `bun run lint` — run ESLint
- `bun run typecheck` — run TypeScript without emitting files
- `bun run agents:apply` — recreate agent instruction symlinks

## Architecture
Multi-page App Router app with server-rendered pages for indexed reads and client components for wallet-backed write flows.

- Reads: server pages call `queryGraphql()` and client search uses `requestGraphql()`
- Writes: `src/lib/protocol.ts` wraps `@0xintuition/protocol`
- Auth: `src/hooks/useSiweAuth.ts` + `src/app/api/auth/*`
- Layout shell: `src/app/layout.tsx`, `src/app/providers.tsx`, `src/components/app-shell.tsx`

## Key Rules
- All on-chain interactions use `@0xintuition/protocol` — this is the only Intuition package in this template
- Resolve contract addresses with `getMultiVaultAddressFromChainId()` — never hardcode them
- Import `intuitionTestnet` from `@0xintuition/protocol` for chain config
- Always parse events after write transactions
- Always get atom/triple cost before creation
- Writes go through the protocol package only
- Indexed reads go through GraphQL only — public Intuition testnet endpoint by default
- Auth stays inside the app through `/api/auth/*` routes — no external SIWE auth service
- Lists use the triple pattern: `[Item] has_tag [List]`
- `DepositForm` accepts human-readable `tTRUST` input and converts to wei with `parseEther()`

## Important Files
- `src/config/lists.ts` — curated list atoms + tag predicate
- `src/config/wagmi.ts` — Next.js wagmi config using `intuitionTestnet`
- `src/lib/graphql/queries.ts` — indexed read documents
- `src/lib/graphql/client.ts` — browser proxy client + server GraphQL helper
- `src/lib/protocol.ts` — protocol bridge
- `src/lib/auth.ts` — JWT cookie verification for server components
- `src/app/api/auth/nonce/route.ts` — issue signed nonce cookie
- `src/app/api/auth/verify/route.ts` — verify SIWE message and mint auth JWT
- `src/app/api/auth/logout/route.ts` — clear auth cookie
- `src/hooks/useCreate.ts` — atom/triple creation
- `src/hooks/useDeposit.ts` — deposit + preview
- `src/components/AddToListForm.tsx` — search/create atom, then add to list
- `src/components/DepositForm.tsx` — preview + signal UI
- `src/app/list/[id]/page.tsx` — list detail page
- `src/app/positions/page.tsx` — auth-aware positions page
