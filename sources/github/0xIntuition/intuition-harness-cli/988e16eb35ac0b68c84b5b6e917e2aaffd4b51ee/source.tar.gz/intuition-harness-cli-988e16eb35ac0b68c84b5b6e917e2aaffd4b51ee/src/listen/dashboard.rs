use anyhow::Result;
use ratatui::backend::TestBackend;
use ratatui::layout::{Constraint, Direction, Layout, Rect};
use ratatui::style::{Color, Modifier, Style};
use ratatui::text::{Line, Span, Text};
use ratatui::widgets::{Cell, List, ListItem, Paragraph, Row, Table, Wrap};
use ratatui::{Frame, Terminal};

use super::state::{ContextPressure, explicit_resume_id_label, explicit_resume_provider_label};
use super::{ActiveIssue, ListenDashboardData, ListenSessionDetail, SessionListView, SessionPhase};
use crate::session_runtime::{SummaryField, push_optional_summary_field};
use crate::tui::copy::{CopyPayload, CopyUiState, pane_copy_help};
use crate::tui::markdown::render_markdown;
use crate::tui::scroll::{clamp_offset, plain_text, wrapped_rows};
use crate::tui::spaced_list::spaced_list_item;
use crate::tui::theme::{Tone, badge, content_panel, empty_state, key_hints, panel, panel_title};

fn epoch_label(epoch_seconds: u64) -> String {
    chrono::DateTime::<chrono::Utc>::from_timestamp(epoch_seconds as i64, 0)
        .map(|timestamp| timestamp.to_rfc3339())
        .unwrap_or_else(|| epoch_seconds.to_string())
}

/// Which pane currently owns keyboard focus.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub(crate) enum FocusPane {
    #[default]
    Sessions,
    ActiveIssues,
}

impl FocusPane {
    pub(crate) fn toggle(self) -> Self {
        match self {
            Self::Sessions => Self::ActiveIssues,
            Self::ActiveIssues => Self::Sessions,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct SessionBrowserState {
    pub(crate) focus: FocusPane,
    pub(crate) view: SessionListView,
    pub(crate) selected_active: usize,
    pub(crate) selected_blocked: usize,
    pub(crate) selected_completed: usize,
    pub(crate) selected_active_issue: usize,
    pub(crate) detail_mode: bool,
    pub(crate) detail_scroll: u16,
    pub(crate) copy: CopyUiState,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum SessionBrowserAction {
    Up,
    Down,
    Tab,
    Left,
    Right,
    Enter,
    Pause,
    Back,
    PageUp,
    PageDown,
}

impl Default for SessionBrowserState {
    fn default() -> Self {
        Self {
            focus: FocusPane::default(),
            view: SessionListView::Active,
            selected_active: 0,
            selected_blocked: 0,
            selected_completed: 0,
            selected_active_issue: 0,
            detail_mode: false,
            detail_scroll: 0,
            copy: CopyUiState::default(),
        }
    }
}

impl SessionBrowserState {
    pub(crate) fn normalize(&mut self, data: &ListenDashboardData) {
        let active_len = data.sessions_for_view(SessionListView::Active).len();
        let blocked_len = data.sessions_for_view(SessionListView::Blocked).len();
        let completed_len = data.sessions_for_view(SessionListView::Completed).len();
        self.selected_active = clamp_index(self.selected_active, active_len);
        self.selected_blocked = clamp_index(self.selected_blocked, blocked_len);
        self.selected_completed = clamp_index(self.selected_completed, completed_len);
        self.selected_active_issue =
            clamp_index(self.selected_active_issue, data.active_issues.len());
        if !data.show_active_issues && matches!(self.focus, FocusPane::ActiveIssues) {
            self.focus = FocusPane::Sessions;
        }
        if self.detail_mode && self.has_no_detail_target(data) {
            self.detail_mode = false;
            self.detail_scroll = 0;
        }
    }

    fn has_no_detail_target(&self, data: &ListenDashboardData) -> bool {
        match self.focus {
            FocusPane::Sessions => self.selected_session(data).is_none(),
            FocusPane::ActiveIssues => self.selected_active_issue(data).is_none(),
        }
    }

    pub(crate) fn clamp_detail_scroll(
        &mut self,
        data: &ListenDashboardData,
        width: u16,
        height: u16,
    ) {
        let Some((viewport_height, content_rows)) =
            detail_scroll_metrics(data, self, width, height)
        else {
            self.detail_scroll = 0;
            return;
        };
        self.detail_scroll = clamp_offset(self.detail_scroll, viewport_height, content_rows);
    }

    pub(crate) fn select_previous(&mut self, data: &ListenDashboardData) {
        match self.focus {
            FocusPane::Sessions => match self.view {
                SessionListView::Active => {
                    self.selected_active = self.selected_active.saturating_sub(1);
                }
                SessionListView::Blocked => {
                    self.selected_blocked = self.selected_blocked.saturating_sub(1);
                }
                SessionListView::Completed => {
                    self.selected_completed = self.selected_completed.saturating_sub(1);
                }
            },
            FocusPane::ActiveIssues => {
                self.selected_active_issue = self.selected_active_issue.saturating_sub(1);
            }
        }
        self.detail_scroll = 0;
        self.normalize(data);
    }

    pub(crate) fn select_next(&mut self, data: &ListenDashboardData) {
        match self.focus {
            FocusPane::Sessions => match self.view {
                SessionListView::Active => {
                    self.selected_active = self.selected_active.saturating_add(1);
                }
                SessionListView::Blocked => {
                    self.selected_blocked = self.selected_blocked.saturating_add(1);
                }
                SessionListView::Completed => {
                    self.selected_completed = self.selected_completed.saturating_add(1);
                }
            },
            FocusPane::ActiveIssues => {
                self.selected_active_issue = self.selected_active_issue.saturating_add(1);
            }
        }
        self.detail_scroll = 0;
        self.normalize(data);
    }

    pub(crate) fn selected_session<'a>(
        &self,
        data: &'a ListenDashboardData,
    ) -> Option<&'a super::AgentSession> {
        let sessions = data.sessions_for_view(self.view);
        let index = match self.view {
            SessionListView::Active => self.selected_active,
            SessionListView::Blocked => self.selected_blocked,
            SessionListView::Completed => self.selected_completed,
        };
        sessions.get(index).copied()
    }

    pub(crate) fn selected_active_issue<'a>(
        &self,
        data: &'a ListenDashboardData,
    ) -> Option<&'a ActiveIssue> {
        data.active_issues.get(self.selected_active_issue)
    }

    pub(crate) fn apply_action(
        &mut self,
        data: &ListenDashboardData,
        action: SessionBrowserAction,
    ) {
        match action {
            SessionBrowserAction::Up => {
                if self.detail_mode {
                    self.detail_scroll = self.detail_scroll.saturating_sub(1);
                } else {
                    self.select_previous(data);
                }
            }
            SessionBrowserAction::Down => {
                if self.detail_mode {
                    self.detail_scroll = self.detail_scroll.saturating_add(1);
                } else {
                    self.select_next(data);
                }
            }
            SessionBrowserAction::Tab => {
                if data.show_active_issues {
                    self.focus = self.focus.toggle();
                    self.detail_mode = false;
                    self.detail_scroll = 0;
                } else {
                    self.view = self.view.toggle();
                    self.detail_scroll = 0;
                }
            }
            SessionBrowserAction::Left => {
                if matches!(self.focus, FocusPane::Sessions) {
                    self.view = match self.view {
                        SessionListView::Active => SessionListView::Completed,
                        SessionListView::Blocked => SessionListView::Active,
                        SessionListView::Completed => SessionListView::Blocked,
                    };
                }
                self.detail_scroll = 0;
            }
            SessionBrowserAction::Right => {
                if matches!(self.focus, FocusPane::Sessions) {
                    self.view = match self.view {
                        SessionListView::Active => SessionListView::Blocked,
                        SessionListView::Blocked => SessionListView::Completed,
                        SessionListView::Completed => SessionListView::Active,
                    };
                }
                self.detail_scroll = 0;
            }
            SessionBrowserAction::Enter => {
                if data.show_preview {
                    self.detail_mode = !self.detail_mode;
                    self.detail_scroll = 0;
                }
            }
            SessionBrowserAction::Pause => {}
            SessionBrowserAction::Back => {
                self.detail_mode = false;
                self.detail_scroll = 0;
            }
            SessionBrowserAction::PageUp => {
                self.detail_scroll = self.detail_scroll.saturating_sub(5);
            }
            SessionBrowserAction::PageDown => {
                self.detail_scroll = self.detail_scroll.saturating_add(5);
            }
        }
        self.normalize(data);
    }

    pub(crate) fn copy_payload(&self, data: &ListenDashboardData) -> CopyPayload {
        match self.focus {
            FocusPane::Sessions => {
                if self.detail_mode && data.show_preview {
                    if let Some(session) = self.selected_session(data) {
                        CopyPayload::from_text(
                            "Listen session detail",
                            session_detail_copy_text(
                                session,
                                data.detail_for_session(&session.issue_identifier),
                            ),
                        )
                    } else {
                        CopyPayload::new("Listen session detail", "No session selected.")
                    }
                } else {
                    CopyPayload::from_text("Listen sessions", session_list_copy_text(data, self))
                }
            }
            FocusPane::ActiveIssues => {
                if self.detail_mode && data.show_preview {
                    if let Some(issue) = self.selected_active_issue(data) {
                        CopyPayload::from_text(
                            "Listen active issue detail",
                            render_active_issue_detail_text(issue),
                        )
                    } else {
                        CopyPayload::new("Listen active issue detail", "No active issue selected.")
                    }
                } else {
                    CopyPayload::from_text(
                        "Listen active issues",
                        active_issue_list_copy_text(data, self),
                    )
                }
            }
        }
    }

    fn copy_help_text(&self, data: &ListenDashboardData) -> String {
        let base = match self.focus {
            FocusPane::Sessions if self.detail_mode && data.show_preview => {
                "Tab switches panes or views. Up/Down and PgUp/PgDn scroll the selected session detail."
            }
            FocusPane::Sessions => {
                "Tab switches panes or views. Up/Down moves the session list. Enter toggles detail for the selected session."
            }
            FocusPane::ActiveIssues if self.detail_mode && data.show_preview => {
                "Tab switches panes. Up/Down and PgUp/PgDn scroll the selected issue detail."
            }
            FocusPane::ActiveIssues => {
                "Tab switches panes. Up/Down moves the active issue list. Enter toggles detail for the selected issue."
            }
        };
        pane_copy_help(base)
    }
}

pub fn render_dashboard(data: &ListenDashboardData, width: u16, height: u16) -> Result<String> {
    render_dashboard_with_state(data, width, height, SessionBrowserState::default())
}

#[cfg(test)]
fn render_dashboard_with_view(
    data: &ListenDashboardData,
    width: u16,
    height: u16,
    view: SessionListView,
) -> Result<String> {
    let state = SessionBrowserState {
        view,
        ..SessionBrowserState::default()
    };
    render_dashboard_with_state(data, width, height, state)
}

pub(crate) fn render_dashboard_with_state(
    data: &ListenDashboardData,
    width: u16,
    height: u16,
    mut state: SessionBrowserState,
) -> Result<String> {
    let backend = TestBackend::new(width, height);
    let mut terminal = Terminal::new(backend)?;
    state.normalize(data);
    state.clamp_detail_scroll(data, width, height);
    terminal.draw(|frame| render(frame, data, &state))?;
    Ok(snapshot(terminal.backend()))
}

pub(crate) fn render(
    frame: &mut Frame<'_>,
    data: &ListenDashboardData,
    state: &SessionBrowserState,
) {
    let area = frame.area();
    let layout = dashboard_layout_metrics(area, data, state);
    let mut constraints = vec![Constraint::Length(layout.header_height), Constraint::Min(8)];
    if layout.active_issues_height > 0 {
        constraints.push(Constraint::Length(layout.active_issues_height));
    }
    if layout.footer_height > 0 {
        constraints.push(Constraint::Length(layout.footer_height));
    }
    let sections = Layout::default()
        .direction(Direction::Vertical)
        .constraints(constraints)
        .split(area);

    render_header(frame, data, sections[0]);
    render_sessions(frame, data, sections[1], state);

    let mut next_section = 2;
    if layout.active_issues_height > 0 {
        render_active_issues(frame, data, sections[next_section], state);
        next_section += 1;
    }
    if layout.footer_height > 0 && next_section < sections.len() {
        render_footer(frame, data, state, sections[next_section]);
    }

    state.copy.render_export_overlay(frame, frame.area());
}

fn render_header(frame: &mut Frame<'_>, data: &ListenDashboardData, area: Rect) {
    if area.width < 110 {
        let compact = Paragraph::new(Text::from(vec![
            Line::from(vec![
                badge("listen", Tone::Accent),
                Span::raw(" "),
                Span::raw(data.title.clone()),
            ]),
            Line::from(Span::styled(
                data.scope.clone(),
                Style::default()
                    .fg(Color::White)
                    .add_modifier(Modifier::BOLD),
            )),
            Line::from(vec![
                Span::styled("Watching: ", label_style()),
                Span::styled(data.watch_scope.clone(), value_style(Color::LightGreen)),
            ]),
            Line::from(Span::styled(
                data.cycle_summary.clone(),
                Style::default().fg(Color::Gray),
            )),
            runtime_line(
                "Execution agent",
                data.resolved_agent.as_deref().unwrap_or("unresolved"),
                Color::LightCyan,
            ),
            runtime_line("Agents", &data.runtime.agents, Color::Green),
            runtime_line("Throughput", &data.runtime.throughput, Color::Cyan),
            runtime_line("Runtime", &data.runtime.runtime, Color::Yellow),
            runtime_line("Tokens", &data.runtime.tokens, Color::Magenta),
            runtime_line("Rate Limits", &data.runtime.rate_limits, Color::LightBlue),
            runtime_line(
                "Linear status",
                &data.runtime.linear_status,
                linear_status_color(data.degraded.is_some()),
            ),
            runtime_line("Dashboard", &data.runtime.dashboard, Color::LightCyan),
            runtime_line(
                "Terminal refresh",
                &data.runtime.dashboard_refresh,
                Color::Yellow,
            ),
            runtime_line(
                "Linear refresh",
                &data.runtime.linear_refresh,
                Color::LightYellow,
            ),
            key_hints(&[
                ("Tab", "toggle view"),
                (
                    if data.vim_mode {
                        "←/→/h/l"
                    } else {
                        "←/→"
                    },
                    "switch tabs",
                ),
                ("p", "pause running"),
                ("r", "resume paused / retry blocked"),
                ("Ctrl+Y", "copy"),
                ("q", "exit"),
            ]),
        ]))
        .wrap(Wrap { trim: true })
        .block(panel(panel_title("Listen Status", false)));
        frame.render_widget(compact, area);
        return;
    }

    let direction = if area.width >= 110 {
        Direction::Horizontal
    } else {
        Direction::Vertical
    };
    let chunks = Layout::default()
        .direction(direction)
        .constraints(match direction {
            Direction::Horizontal => vec![Constraint::Percentage(36), Constraint::Percentage(64)],
            Direction::Vertical => vec![Constraint::Length(5), Constraint::Min(6)],
        })
        .split(area);

    let hero = Paragraph::new(Text::from(vec![
        Line::from(vec![
            badge("listen", Tone::Accent),
            Span::raw(" "),
            Span::raw(data.title.clone()),
        ]),
        Line::from(Span::styled(
            data.scope.clone(),
            Style::default()
                .fg(Color::White)
                .add_modifier(Modifier::BOLD),
        )),
        Line::from(vec![
            Span::styled("Watching: ", label_style()),
            Span::styled(data.watch_scope.clone(), value_style(Color::LightGreen)),
        ]),
        Line::from(Span::styled(
            data.cycle_summary.clone(),
            Style::default().fg(Color::Gray),
        )),
        Line::from(vec![
            Span::styled("State file: ", label_style()),
            Span::styled(data.state_file.clone(), value_style(Color::Green)),
        ]),
        key_hints(&[
            (
                "Tab",
                if data.show_active_issues {
                    "switch pane"
                } else {
                    "toggle view"
                },
            ),
            (
                if data.vim_mode {
                    "←/→/h/l"
                } else {
                    "←/→"
                },
                "switch views",
            ),
            ("p", "pause running"),
            ("r", "resume paused / retry blocked"),
            ("Ctrl+Y", "copy"),
            ("q", "exit"),
        ]),
    ]))
    .wrap(Wrap { trim: true })
    .block(panel(panel_title("Listen Status", false)));
    frame.render_widget(hero, chunks[0]);

    let runtime_lines = vec![
        runtime_line(
            "Execution agent",
            data.resolved_agent.as_deref().unwrap_or("unresolved"),
            Color::LightCyan,
        ),
        runtime_line("Agents", &data.runtime.agents, Color::Green),
        runtime_line("Throughput", &data.runtime.throughput, Color::Cyan),
        runtime_line("Runtime", &data.runtime.runtime, Color::Yellow),
        runtime_line("Tokens", &data.runtime.tokens, Color::Magenta),
        runtime_line("Rate Limits", &data.runtime.rate_limits, Color::LightBlue),
        runtime_line(
            "Linear status",
            &data.runtime.linear_status,
            linear_status_color(data.degraded.is_some()),
        ),
        runtime_line("Project", &data.runtime.project, Color::White),
        runtime_line("Watching", &data.watch_scope, Color::LightGreen),
        runtime_line("Dashboard", &data.runtime.dashboard, Color::LightCyan),
        runtime_line(
            "Terminal refresh",
            &data.runtime.dashboard_refresh,
            Color::Yellow,
        ),
        runtime_line(
            "Linear refresh",
            &data.runtime.linear_refresh,
            Color::LightYellow,
        ),
    ];
    let runtime = Paragraph::new(Text::from(runtime_lines))
        .wrap(Wrap { trim: true })
        .block(panel(panel_title("Runtime", false)));
    frame.render_widget(runtime, chunks[1]);
}

fn render_sessions(
    frame: &mut Frame<'_>,
    data: &ListenDashboardData,
    area: Rect,
    state: &SessionBrowserState,
) {
    let view = state.view;
    let counts = data.session_counts();
    let sessions = data.sessions_for_view(view);
    let is_focused = matches!(state.focus, FocusPane::Sessions);
    let block = panel(panel_title("Agent Sessions", is_focused));
    let inner = block.inner(area);
    frame.render_widget(block, area);

    if inner.width == 0 || inner.height == 0 {
        return;
    }

    let sections = Layout::default()
        .direction(Direction::Vertical)
        .constraints([Constraint::Length(2), Constraint::Min(0)])
        .split(inner);

    let tab_hint = if data.show_active_issues {
        "Tab pane"
    } else {
        "Tab view"
    };
    let nav_hint = if data.vim_mode {
        format!(
            "  {tab_hint}  ←/→/h/l views  ↑/↓/j/k select  Enter detail  p pause  r resume/retry"
        )
    } else {
        format!("  {tab_hint}  ←/→ views  ↑/↓ select  Enter detail  p pause  r resume/retry")
    };
    let controls = Paragraph::new(Line::from(vec![
        Span::styled("Views: ", label_style()),
        session_view_badge(SessionListView::Active, view, counts.active),
        Span::raw(" "),
        session_view_badge(SessionListView::Blocked, view, counts.blocked),
        Span::raw(" "),
        session_view_badge(SessionListView::Completed, view, counts.completed),
        Span::styled(nav_hint, Style::default().fg(Color::DarkGray)),
    ]))
    .wrap(Wrap { trim: true });
    frame.render_widget(controls, sections[0]);

    if sessions.is_empty() {
        let empty = Paragraph::new(match view {
            SessionListView::Active => empty_state(
                "No active agent sessions are currently tracked.",
                "New claimed tickets will appear here once workers start.",
            ),
            SessionListView::Blocked => empty_state(
                "No blocked agent sessions are currently tracked.",
                "Blocked workers will appear here when operator attention is required.",
            ),
            SessionListView::Completed => empty_state(
                "No completed agent sessions are currently tracked.",
                "Completed workers will move into this view after they exit.",
            ),
        })
        .wrap(Wrap { trim: true });
        frame.render_widget(empty, sections[1]);
        return;
    }

    let show_session_detail = state.detail_mode && is_focused && data.show_preview;
    let layout = if show_session_detail {
        if sections[1].width >= 150 {
            Layout::default()
                .direction(Direction::Horizontal)
                .constraints([Constraint::Percentage(58), Constraint::Percentage(42)])
                .split(sections[1])
        } else {
            Layout::default()
                .direction(Direction::Vertical)
                .constraints([Constraint::Length(10), Constraint::Min(0)])
                .split(sections[1])
        }
    } else {
        Layout::default()
            .direction(Direction::Horizontal)
            .constraints([Constraint::Min(0)])
            .split(sections[1])
    };

    render_session_table(frame, data, layout[0], view, sessions, state);

    if show_session_detail && layout.len() > 1 {
        if let Some(session) = state.selected_session(data) {
            render_session_detail(
                frame,
                session,
                data.detail_for_session(&session.issue_identifier),
                layout[1],
                clamp_detail_scroll_for_area(
                    session,
                    data.detail_for_session(&session.issue_identifier),
                    layout[1],
                    state.detail_scroll,
                ),
            );
        }
    }
}

fn render_active_issues(
    frame: &mut Frame<'_>,
    data: &ListenDashboardData,
    area: Rect,
    state: &SessionBrowserState,
) {
    let is_focused = matches!(state.focus, FocusPane::ActiveIssues);
    let block = panel(panel_title("In Progress Issues - All Users", is_focused));
    let inner = block.inner(area);
    frame.render_widget(block, area);

    if inner.width == 0 || inner.height == 0 {
        return;
    }

    if data.active_issues.is_empty() {
        let empty = Paragraph::new(empty_state(
            "No In Progress issues found.",
            "Issues moved to In Progress will appear here.",
        ))
        .wrap(Wrap { trim: true });
        frame.render_widget(empty, inner);
        return;
    }

    let show_detail = state.detail_mode && is_focused && data.show_preview;
    let layout = if show_detail {
        if inner.width >= 150 {
            Layout::default()
                .direction(Direction::Horizontal)
                .constraints([Constraint::Percentage(55), Constraint::Percentage(45)])
                .split(inner)
        } else {
            Layout::default()
                .direction(Direction::Vertical)
                .constraints([Constraint::Min(4), Constraint::Min(0)])
                .split(inner)
        }
    } else {
        Layout::default()
            .direction(Direction::Horizontal)
            .constraints([Constraint::Min(0)])
            .split(inner)
    };

    let selected_index = state.selected_active_issue;
    let max_title_len = if layout[0].width > 60 { 50 } else { 30 };
    let rows = data.active_issues.iter().enumerate().map(|(index, issue)| {
        Row::new(vec![
            Cell::from(if index == selected_index && is_focused {
                ">"
            } else {
                " "
            }),
            Cell::from(issue.identifier.clone()),
            Cell::from(issue.short_title(max_title_len)),
            Cell::from(issue.assignee_label().to_string()),
            Cell::from(issue.pr_label()),
        ])
    });
    let header = Row::new(vec![
        Cell::from(""),
        Cell::from("ID"),
        Cell::from("TITLE"),
        Cell::from("ASSIGNEE"),
        Cell::from("PR"),
    ])
    .style(
        Style::default()
            .fg(Color::Gray)
            .add_modifier(Modifier::BOLD),
    )
    .bottom_margin(1);
    let constraints = vec![
        Constraint::Length(2),
        Constraint::Length(9),
        Constraint::Min(20),
        Constraint::Length(16),
        Constraint::Length(4),
    ];
    let table = Table::new(rows, constraints)
        .header(header)
        .column_spacing(1);
    frame.render_widget(table, layout[0]);

    if show_detail && layout.len() > 1 {
        if let Some(issue) = state.selected_active_issue(data) {
            render_active_issue_detail(frame, issue, layout[1], state.detail_scroll);
        }
    }
}

fn render_active_issue_detail(frame: &mut Frame<'_>, issue: &ActiveIssue, area: Rect, scroll: u16) {
    let content = render_active_issue_detail_text(issue);
    let detail = Paragraph::new(content)
        .wrap(Wrap { trim: true })
        .scroll((scroll, 0))
        .block(content_panel(panel_title("Issue Detail", false)));
    frame.render_widget(detail, area);
}

fn render_active_issue_detail_text(issue: &ActiveIssue) -> Text<'static> {
    let mut lines = vec![
        Line::from(vec![
            Span::styled(
                format!("{} ", issue.identifier),
                Style::default()
                    .fg(Color::White)
                    .add_modifier(Modifier::BOLD),
            ),
            Span::styled(
                issue.state_name.clone(),
                Style::default()
                    .fg(Color::Green)
                    .add_modifier(Modifier::BOLD),
            ),
        ]),
        Line::from(Span::styled(
            issue.title.clone(),
            Style::default().fg(Color::Gray),
        )),
        Line::from(""),
        detail_line("Assignee", issue.assignee_label()),
        detail_line(
            "PR",
            if issue.has_open_pr {
                issue.pr_url.as_deref().unwrap_or("open")
            } else {
                "none"
            },
        ),
        detail_line("URL", &issue.url),
    ];

    if let Some(project) = issue.project.as_deref() {
        lines.push(detail_line("Project", project));
    }

    if let Some(description) = issue.description.as_deref() {
        lines.push(Line::from(""));
        lines.push(section_header("Description"));
        lines.extend(render_markdown(description, Style::default().fg(Color::White), &[]).lines);
    }

    lines.push(Line::from(""));
    lines.push(Line::from(Span::styled(
        "Esc/Backspace close detail. PgUp/PgDn scroll.",
        Style::default().fg(Color::DarkGray),
    )));

    Text::from(lines)
}

fn render_session_table(
    frame: &mut Frame<'_>,
    data: &ListenDashboardData,
    area: Rect,
    view: SessionListView,
    sessions: Vec<&super::AgentSession>,
    state: &SessionBrowserState,
) {
    let is_focused = matches!(state.focus, FocusPane::Sessions);
    let selected_index = match view {
        SessionListView::Active => state.selected_active,
        SessionListView::Blocked => state.selected_blocked,
        SessionListView::Completed => state.selected_completed,
    };
    let rows = sessions.into_iter().enumerate().map(|(index, session)| {
        let mut issue_lines = vec![Line::from(session.issue_identifier.clone())];
        if session.origin.is_execute() {
            issue_lines.push(Line::from(Span::styled(
                "execute-origin",
                Style::default().fg(Color::Yellow),
            )));
        }
        if let Some(backlog_issue_identifier) = session.backlog_issue_identifier.as_deref()
            && !backlog_issue_identifier.eq_ignore_ascii_case(&session.issue_identifier)
        {
            issue_lines.push(Line::from(Span::styled(
                format!("backlog {backlog_issue_identifier}"),
                Style::default().fg(Color::Gray),
            )));
        }
        Row::new(vec![
            Cell::from(if index == selected_index && is_focused {
                ">"
            } else {
                " "
            }),
            Cell::from(Text::from(issue_lines)),
            Cell::from(Span::styled(
                session.stage_label(),
                phase_style(session.phase),
            )),
            Cell::from(session.lifecycle_label()),
            Cell::from(session.exit_label().unwrap_or_else(|| "-".to_string())),
            Cell::from(session.pid_label()),
            Cell::from(session.age_label(data.runtime.current_epoch_seconds)),
            Cell::from(session.pull_request_label()),
            Cell::from(session.table_tokens_label()),
            Cell::from(session.latest_resume_provider_label()),
            Cell::from(session.session_label()),
            Cell::from(session.summary.clone()),
        ])
    });
    let header = Row::new(vec![
        Cell::from(""),
        Cell::from("ID"),
        Cell::from("PHASE"),
        Cell::from("STATE"),
        Cell::from("EXIT"),
        Cell::from("PID"),
        Cell::from("AGE"),
        Cell::from("PR"),
        Cell::from("TOKENS"),
        Cell::from("PROVIDER"),
        Cell::from("SESSION"),
        Cell::from("PROGRESS"),
    ])
    .style(
        Style::default()
            .fg(Color::Gray)
            .add_modifier(Modifier::BOLD),
    )
    .bottom_margin(1);
    let constraints = if area.width >= 175 {
        vec![
            Constraint::Length(2),
            Constraint::Length(10),
            Constraint::Length(13),
            Constraint::Length(10),
            Constraint::Length(14),
            Constraint::Length(8),
            Constraint::Length(10),
            Constraint::Length(12),
            Constraint::Length(12),
            Constraint::Length(8),
            Constraint::Length(13),
            Constraint::Min(34),
        ]
    } else {
        vec![
            Constraint::Length(2),
            Constraint::Length(9),
            Constraint::Length(12),
            Constraint::Length(10),
            Constraint::Length(12),
            Constraint::Length(8),
            Constraint::Length(9),
            Constraint::Length(10),
            Constraint::Length(9),
            Constraint::Length(8),
            Constraint::Length(13),
            Constraint::Min(18),
        ]
    };
    let table = Table::new(rows, constraints)
        .header(header)
        .column_spacing(1);
    frame.render_widget(table, area);
}

fn render_session_detail(
    frame: &mut Frame<'_>,
    session: &super::AgentSession,
    detail: Option<&ListenSessionDetail>,
    area: Rect,
    scroll: u16,
) {
    let content = match detail {
        Some(detail) => render_session_detail_text(session, detail),
        None => empty_state(
            "No structured detail artifact is available yet.",
            "The worker will populate session detail as soon as it refreshes this session.",
        ),
    };
    let detail = Paragraph::new(content)
        .wrap(Wrap { trim: true })
        .scroll((scroll, 0))
        .block(content_panel(panel_title("Selected Session", false)));
    frame.render_widget(detail, area);
}

fn detail_scroll_metrics(
    data: &ListenDashboardData,
    state: &SessionBrowserState,
    width: u16,
    height: u16,
) -> Option<(u16, usize)> {
    if !state.detail_mode {
        return None;
    }
    if matches!(state.focus, FocusPane::ActiveIssues) {
        return None;
    }
    let session = state.selected_session(data)?;
    let area = Rect::new(0, 0, width, height);
    let layout = dashboard_layout_metrics(area, data, state);
    let mut constraints = vec![Constraint::Length(layout.header_height), Constraint::Min(8)];
    if layout.active_issues_height > 0 {
        constraints.push(Constraint::Length(layout.active_issues_height));
    }
    if layout.footer_height > 0 {
        constraints.push(Constraint::Length(layout.footer_height));
    }
    let sections = Layout::default()
        .direction(Direction::Vertical)
        .constraints(constraints)
        .split(area);
    let sessions_block = panel(panel_title("Agent Sessions", false));
    let sessions_inner = sessions_block.inner(sections[1]);
    if sessions_inner.width == 0 || sessions_inner.height == 0 {
        return None;
    }
    let sessions_sections = Layout::default()
        .direction(Direction::Vertical)
        .constraints([Constraint::Length(2), Constraint::Min(0)])
        .split(sessions_inner);
    let detail_area = detail_panel_area(sessions_sections[1], state.detail_mode)?;
    let detail = data.detail_for_session(&session.issue_identifier);
    Some(detail_content_metrics(session, detail, detail_area))
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct DashboardLayoutMetrics {
    header_height: u16,
    active_issues_height: u16,
    footer_height: u16,
}

fn dashboard_layout_metrics(
    area: Rect,
    data: &ListenDashboardData,
    state: &SessionBrowserState,
) -> DashboardLayoutMetrics {
    let footer_height = if area.width >= 110 && area.height >= 30 {
        8
    } else {
        0
    };
    let header_height = if area.width >= 120 { 11 } else { 12 };
    let show_active_issues = data.show_active_issues && !data.active_issues.is_empty();
    let active_issue_detail =
        state.detail_mode && matches!(state.focus, FocusPane::ActiveIssues) && data.show_preview;
    let active_issues_height = if show_active_issues {
        let rows = data.active_issues.len() as u16;
        if active_issue_detail {
            (rows + 4).clamp(16, 24)
        } else {
            (rows + 4).min(16)
        }
    } else {
        0
    };
    DashboardLayoutMetrics {
        header_height,
        active_issues_height,
        footer_height,
    }
}

fn detail_panel_area(area: Rect, detail_mode: bool) -> Option<Rect> {
    if !detail_mode {
        return None;
    }
    let layout = if area.width >= 150 {
        Layout::default()
            .direction(Direction::Horizontal)
            .constraints([Constraint::Percentage(58), Constraint::Percentage(42)])
            .split(area)
    } else {
        Layout::default()
            .direction(Direction::Vertical)
            .constraints([Constraint::Length(10), Constraint::Min(0)])
            .split(area)
    };
    (layout.len() > 1).then_some(layout[1])
}

fn clamp_detail_scroll_for_area(
    session: &super::AgentSession,
    detail: Option<&ListenSessionDetail>,
    area: Rect,
    scroll: u16,
) -> u16 {
    let (viewport_height, content_rows) = detail_content_metrics(session, detail, area);
    clamp_offset(scroll, viewport_height, content_rows)
}

fn detail_content_metrics(
    session: &super::AgentSession,
    detail: Option<&ListenSessionDetail>,
    area: Rect,
) -> (u16, usize) {
    let inner = content_panel(panel_title("Selected Session", false)).inner(area);
    let content = match detail {
        Some(detail) => render_session_detail_text(session, detail),
        None => empty_state(
            "No structured detail artifact is available yet.",
            "The worker will populate session detail as soon as it refreshes this session.",
        ),
    };
    let content_rows = wrapped_rows(&plain_text(&content), inner.width.max(1));
    (inner.height.max(1), content_rows)
}

fn render_session_detail_text(
    session: &super::AgentSession,
    detail: &ListenSessionDetail,
) -> Text<'static> {
    let mut summary_fields = vec![
        SummaryField::new("Phase", session.stage_label()),
        SummaryField::new("Lifecycle", session.lifecycle_label().to_string()),
        SummaryField::new("Origin", session.origin_label().to_string()),
        SummaryField::new("Summary", detail.summary.clone()),
        SummaryField::new("Turns", detail.turns.unwrap_or(0).to_string()),
        SummaryField::new("Tokens", detail.tokens.display_compact()),
        SummaryField::new(
            "Context Pressure",
            ContextPressure::from_turn_history(
                &session.turn_history,
                detail.context_budget_tokens(),
            )
            .label(),
        ),
        SummaryField::new("PR", detail.pull_request.compact_label()),
        SummaryField::new(
            "Resume Provider",
            explicit_resume_provider_label(detail.latest_resume_handle.as_ref()),
        ),
        SummaryField::new(
            "Resume ID",
            explicit_resume_id_label(detail.latest_resume_handle.as_ref()),
        ),
    ];
    if let Some(exit) = session.exit_label() {
        summary_fields.push(SummaryField::new("Exit", exit));
    }
    if let Some(exit_detail) = session.exit_detail_label() {
        summary_fields.push(SummaryField::new("Exit Detail", exit_detail));
    }
    if let Some(url) = detail.pull_request.url.as_deref() {
        summary_fields.push(SummaryField::new("PR URL", url));
    } else if let Some(number) = detail.pull_request.number {
        summary_fields.push(SummaryField::new("PR Ref", format!("#{number}")));
    }
    if let Some(pending_sync) = detail.pending_linear_sync.as_ref() {
        summary_fields.push(SummaryField::new(
            "Pending Linear sync",
            pending_sync.operation_labels().join(", "),
        ));
        if let Some(failure) = pending_sync.last_failure.as_ref() {
            summary_fields.push(SummaryField::new(
                "Pending failure",
                format!("{} | {}", failure.kind.label(), failure.message),
            ));
        }
    }
    if let Some(timeout) = detail.last_timeout.as_ref() {
        summary_fields.push(SummaryField::new("Last timeout", timeout.summary_label()));
    }
    if let Some(failure) = detail.latest_stale_worker_failure.as_ref() {
        summary_fields.push(SummaryField::new(
            "Latest Stale Worker Failure",
            failure.operator_summary(),
        ));
        summary_fields.push(SummaryField::new(
            "Latest Stale Worker Observed",
            epoch_label(failure.observed_at_epoch_seconds),
        ));
    }
    push_optional_summary_field(
        &mut summary_fields,
        "Branch",
        detail.references.branch.clone(),
    );
    push_optional_summary_field(
        &mut summary_fields,
        "Workspace",
        detail.references.workspace_path.clone(),
    );
    push_optional_summary_field(
        &mut summary_fields,
        "Backlog",
        detail.references.backlog_path.clone(),
    );
    push_optional_summary_field(
        &mut summary_fields,
        "Brief",
        detail.references.brief_path.clone(),
    );
    push_optional_summary_field(
        &mut summary_fields,
        "Workpad",
        detail.references.workpad_comment_id.clone(),
    );
    push_optional_summary_field(
        &mut summary_fields,
        "Log",
        detail.references.log_path.clone(),
    );
    if let Some(verification) = detail.verification.as_ref() {
        summary_fields.push(SummaryField::new(
            "Verification",
            format!(
                "{} ({})",
                verification.summary,
                verification.compact_label()
            ),
        ));
    }
    push_optional_summary_field(
        &mut summary_fields,
        "Verification JSON",
        detail.references.verification_json_path.clone(),
    );
    push_optional_summary_field(
        &mut summary_fields,
        "Verification Markdown",
        detail.references.verification_markdown_path.clone(),
    );
    summary_fields.push(SummaryField::new(
        "Started",
        epoch_label(detail.started_at_epoch_seconds),
    ));
    summary_fields.push(SummaryField::new(
        "Elapsed Since Start",
        session.elapsed_since_start_label(detail.updated_at_epoch_seconds),
    ));
    summary_fields.push(SummaryField::new(
        "Recovery Attempts",
        format!(
            "{}/{}",
            detail.stale_worker_recovery_attempt_count,
            super::MAX_STALE_WORKER_RECOVERY_ATTEMPTS
        ),
    ));

    let mut lines = vec![
        Line::from(vec![
            Span::styled(
                format!("{} ", session.issue_identifier),
                Style::default()
                    .fg(Color::White)
                    .add_modifier(Modifier::BOLD),
            ),
            Span::styled(session.stage_label(), phase_style(session.phase)),
            Span::styled(
                format!(" | {}", session.lifecycle_label()),
                Style::default().fg(Color::Gray),
            ),
        ]),
        Line::from(Span::styled(
            session.issue_title.clone(),
            Style::default().fg(Color::Gray),
        )),
        Line::from(""),
    ];
    lines.extend(
        summary_fields
            .iter()
            .map(|field| detail_line(field.label, &field.value)),
    );
    if session.origin.is_execute() {
        lines.push(Line::from(""));
        lines.push(Line::from(Span::styled(
            format!(
                "This session was started by `{} agents execute`. Use R to resume/adopt or clear it to re-pick.",
                crate::branding::COMMAND_NAME
            ),
            Style::default().fg(Color::Yellow),
        )));
    }

    if let Some(blocked) = detail.blocked.as_ref() {
        lines.push(Line::from(""));
        lines.push(section_header("Block Detail"));
        lines.push(detail_line("Category", blocked.category_label()));
        lines.push(detail_line("Reason", &blocked.reason));
        lines.push(detail_line(
            "Retryable",
            if blocked.retryable { "yes" } else { "no" },
        ));
        lines.push(detail_line("Suggested action", blocked.suggested_action()));
    }

    if !detail.prompt_context.is_empty() {
        lines.push(Line::from(""));
        lines.push(section_header("Prompt Context"));
        for reference in &detail.prompt_context {
            lines.push(detail_bullet(&format!(
                "{}: {}",
                reference.label, reference.value
            )));
        }
    }

    if !detail.milestones.is_empty() {
        lines.push(Line::from(""));
        lines.push(section_header("Milestones"));
        for milestone in detail.milestones.iter().rev().take(5).rev() {
            let lifecycle_suffix = milestone
                .lifecycle
                .as_ref()
                .map(|lifecycle| format!(" | {}", lifecycle.outcome_label()))
                .unwrap_or_default();
            let pr_suffix = match milestone.pull_request_number {
                Some(number) => format!(" | {} #{number}", milestone.pull_request_status.label()),
                None if milestone.pull_request_status != super::PullRequestStatus::Unpublished => {
                    format!(" | {}", milestone.pull_request_status.label())
                }
                None => String::new(),
            };
            lines.push(detail_bullet(&format!(
                "{}{} · {}{}",
                milestone.phase.display_label(),
                lifecycle_suffix,
                milestone.summary,
                pr_suffix
            )));
        }
    }

    if !detail.log_excerpts.is_empty() {
        lines.push(Line::from(""));
        lines.push(section_header("Recent Log Excerpts"));
        for excerpt in &detail.log_excerpts {
            lines.push(detail_bullet(&format!(
                "L{} {}",
                excerpt.line_number, excerpt.text
            )));
        }
    }

    lines.push(Line::from(""));
    lines.push(Line::from(Span::styled(
        "Esc/Backspace close detail. PgUp/PgDn scroll.",
        Style::default().fg(Color::DarkGray),
    )));

    Text::from(lines)
}

fn render_footer(
    frame: &mut Frame<'_>,
    data: &ListenDashboardData,
    state: &SessionBrowserState,
    area: Rect,
) {
    let direction = if area.width >= 110 {
        Direction::Horizontal
    } else {
        Direction::Vertical
    };
    let chunks = Layout::default()
        .direction(direction)
        .constraints(match direction {
            Direction::Horizontal => vec![Constraint::Percentage(38), Constraint::Percentage(62)],
            Direction::Vertical => vec![Constraint::Length(3), Constraint::Min(3)],
        })
        .split(area);

    let pending_items = if data.pending_issues.is_empty() {
        vec![ListItem::new(Line::from(Span::styled(
            "No queued Todo tickets",
            Style::default().fg(Color::Gray),
        )))]
    } else {
        data.pending_issues
            .iter()
            .map(|issue| {
                let project = issue.project.as_deref().unwrap_or("No project");
                spaced_list_item(vec![
                    Line::from(vec![
                        Span::styled(
                            issue.identifier.clone(),
                            Style::default()
                                .fg(Color::White)
                                .add_modifier(Modifier::BOLD),
                        ),
                        Span::styled(
                            format!(" [{}]", issue.team_key),
                            Style::default().fg(Color::Cyan),
                        ),
                    ]),
                    Line::from(Span::styled(
                        format!("{project} · {}", issue.title),
                        Style::default().fg(Color::Gray),
                    )),
                ])
            })
            .collect::<Vec<_>>()
    };
    let pending = List::new(pending_items).block(panel(panel_title("Todo Queue", false)));
    frame.render_widget(pending, chunks[0]);

    let notes_body = if data.notes.is_empty() {
        "No daemon notes were recorded for this cycle.".to_string()
    } else {
        data.notes.join("\n")
    };
    let notes = Paragraph::new(format!(
        "{}\n\n{}",
        state
            .copy
            .status_text()
            .map(str::to_string)
            .unwrap_or_else(|| state.copy_help_text(data)),
        notes_body
    ))
    .wrap(Wrap { trim: true })
    .block(panel(panel_title("Notes", false)));
    frame.render_widget(notes, chunks[1]);
}

fn session_list_copy_text(
    data: &ListenDashboardData,
    state: &SessionBrowserState,
) -> Text<'static> {
    let sessions = data.sessions_for_view(state.view);
    let selected_identifier = state
        .selected_session(data)
        .map(|session| session.issue_identifier.as_str());
    let mut lines = vec![
        Line::from(format!("Listen sessions: {}", state.view.label())),
        Line::from(format!("Count: {}", sessions.len())),
        Line::from(""),
    ];
    if sessions.is_empty() {
        lines.push(Line::from("No sessions available."));
        return Text::from(lines);
    }

    for session in sessions {
        let selected = if Some(session.issue_identifier.as_str()) == selected_identifier {
            "> "
        } else {
            "  "
        };
        lines.push(Line::from(format!(
            "{selected}{} [{} | {}] {}",
            session.issue_identifier,
            session.stage_label(),
            session
                .exit_label()
                .unwrap_or_else(|| session.lifecycle_label().to_string()),
            session.issue_title
        )));
        lines.push(Line::from(format!(
            "    branch={} summary={}",
            session.branch.as_deref().unwrap_or("-"),
            session.summary
        )));
    }
    Text::from(lines)
}

fn active_issue_list_copy_text(
    data: &ListenDashboardData,
    state: &SessionBrowserState,
) -> Text<'static> {
    let selected_identifier = state
        .selected_active_issue(data)
        .map(|issue| issue.identifier.as_str());
    let mut lines = vec![
        Line::from("Listen active issues"),
        Line::from(format!("Count: {}", data.active_issues.len())),
        Line::from(""),
    ];
    if data.active_issues.is_empty() {
        lines.push(Line::from("No active issues available."));
        return Text::from(lines);
    }

    for issue in &data.active_issues {
        let selected = if Some(issue.identifier.as_str()) == selected_identifier {
            "> "
        } else {
            "  "
        };
        lines.push(Line::from(format!(
            "{selected}{} [{}] {}",
            issue.identifier, issue.team_key, issue.title
        )));
        lines.push(Line::from(format!(
            "    assignee={} state={} pr={} url={}",
            issue.assignee_label(),
            issue.state_name,
            issue.pr_label(),
            issue.url
        )));
    }
    Text::from(lines)
}

fn session_detail_copy_text(
    session: &super::AgentSession,
    detail: Option<&ListenSessionDetail>,
) -> Text<'static> {
    match detail {
        Some(detail) => render_session_detail_text(session, detail),
        None => Text::from(vec![
            Line::from(format!(
                "Session {} detail is not available yet.",
                session.issue_identifier
            )),
            Line::from("The worker will populate detail artifacts after the next refresh."),
        ]),
    }
}

fn runtime_line(label: &str, value: &str, color: Color) -> Line<'static> {
    Line::from(vec![
        Span::styled(format!("{label}: "), label_style()),
        Span::styled(value.to_string(), value_style(color)),
    ])
}

fn linear_status_color(is_degraded: bool) -> Color {
    if is_degraded {
        Color::LightRed
    } else {
        Color::LightGreen
    }
}

fn label_style() -> Style {
    Style::default()
        .fg(Color::Gray)
        .add_modifier(Modifier::BOLD)
}

fn value_style(color: Color) -> Style {
    Style::default().fg(color)
}

fn clamp_index(index: usize, len: usize) -> usize {
    if len == 0 {
        0
    } else {
        index.min(len.saturating_sub(1))
    }
}

fn detail_line(label: &str, value: &str) -> Line<'static> {
    Line::from(vec![
        Span::styled(format!("{label}: "), label_style()),
        Span::styled(value.to_string(), Style::default().fg(Color::White)),
    ])
}

fn detail_bullet(value: &str) -> Line<'static> {
    Line::from(vec![
        Span::styled("- ", Style::default().fg(Color::DarkGray)),
        Span::styled(value.to_string(), Style::default().fg(Color::White)),
    ])
}

fn section_header(label: &str) -> Line<'static> {
    Line::from(Span::styled(
        label.to_string(),
        Style::default()
            .fg(Color::Cyan)
            .add_modifier(Modifier::BOLD),
    ))
}

fn session_view_badge(
    candidate: SessionListView,
    active_view: SessionListView,
    count: usize,
) -> Span<'static> {
    let style = if candidate == active_view {
        Style::default()
            .fg(Color::Black)
            .bg(Color::Cyan)
            .add_modifier(Modifier::BOLD)
    } else {
        Style::default()
            .fg(Color::Gray)
            .add_modifier(Modifier::BOLD)
    };
    Span::styled(format!(" {} ({count}) ", candidate.label()), style)
}

fn phase_style(phase: SessionPhase) -> Style {
    match phase {
        SessionPhase::Claimed => Style::default().fg(Color::Yellow),
        SessionPhase::BriefReady => Style::default()
            .fg(Color::Green)
            .add_modifier(Modifier::BOLD),
        SessionPhase::Running => Style::default()
            .fg(Color::Green)
            .add_modifier(Modifier::BOLD),
        SessionPhase::Reviewing => Style::default()
            .fg(Color::Blue)
            .add_modifier(Modifier::BOLD),
        SessionPhase::FinalReview => Style::default()
            .fg(Color::Blue)
            .add_modifier(Modifier::BOLD),
        SessionPhase::Verifying => Style::default()
            .fg(Color::Magenta)
            .add_modifier(Modifier::BOLD),
        SessionPhase::Validating => Style::default()
            .fg(Color::LightMagenta)
            .add_modifier(Modifier::BOLD),
        SessionPhase::Publishing => Style::default()
            .fg(Color::Cyan)
            .add_modifier(Modifier::BOLD),
        SessionPhase::Paused => Style::default()
            .fg(Color::Yellow)
            .add_modifier(Modifier::BOLD),
        SessionPhase::Completed => Style::default()
            .fg(Color::Cyan)
            .add_modifier(Modifier::BOLD),
        SessionPhase::Blocked => Style::default().fg(Color::Red).add_modifier(Modifier::BOLD),
    }
}

fn snapshot(backend: &TestBackend) -> String {
    let buffer = backend.buffer();
    let mut lines = Vec::new();

    for y in 0..buffer.area.height {
        let mut line = String::new();
        for x in 0..buffer.area.width {
            line.push_str(buffer[(x, y)].symbol());
        }
        lines.push(line.trim_end().to_string());
    }

    lines.join("\n")
}

#[cfg(test)]
mod tests {
    use std::path::Path;

    use ratatui::style::Color;
    use ratatui::text::Line;

    use super::{
        FocusPane, SessionBrowserAction, SessionBrowserState, detail_scroll_metrics,
        linear_status_color, render_active_issue_detail_text, render_dashboard,
        render_dashboard_with_state, render_dashboard_with_view, render_session_detail_text,
    };
    use crate::listen::store::SessionMilestone;
    use crate::listen::{
        BlockedCategory, BlockedReason, DashboardRuntimeContext, ListenCycleData,
        PullRequestStatus, SessionListView, SessionPhase, StaleWorkerFailure, TokenUsage,
        TurnPromptMode, TurnTokenSnapshot, build_dashboard_data,
    };
    use crate::tui::scroll::clamp_offset;

    fn demo_cycle() -> ListenCycleData {
        ListenCycleData::demo(
            Path::new("."),
            format!(
                "{}/agents/sessions/listen-state.json",
                crate::branding::PROJECT_DIR
            ),
        )
    }

    #[test]
    fn linear_status_color_reflects_degraded_state() {
        assert_eq!(linear_status_color(false), Color::LightGreen);
        assert_eq!(linear_status_color(true), Color::LightRed);
    }

    #[test]
    fn snapshot_contains_runtime_summary_and_agent_columns() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let snapshot = render_dashboard(&data, 140, 36).expect("snapshot should render");

        assert!(snapshot.contains("Runtime"));
        assert!(snapshot.contains("Execution agent"));
        assert!(snapshot.contains("codex"));
        assert!(snapshot.contains("Agent Sessions"));
        assert!(snapshot.contains("Active (2)"));
        assert!(snapshot.contains("Completed (0)"));
        assert!(snapshot.contains("PROVIDER"));
        assert!(snapshot.contains("SESSION"));
        assert!(snapshot.contains("PROGRESS"));
        assert!(snapshot.contains("MET-13"));
    }

    #[test]
    fn compact_header_includes_resolved_execution_agent() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("claude".to_string()),
            },
        );

        let snapshot = render_dashboard(&data, 100, 36).expect("snapshot should render");

        assert!(snapshot.contains("Execution agent"));
        assert!(snapshot.contains("claude"));
    }

    #[test]
    fn completed_view_renders_only_completed_sessions() {
        let mut cycle = demo_cycle();
        let mut completed = cycle
            .sessions
            .first()
            .expect("demo cycle should include a session")
            .clone();
        completed.issue_identifier = "MET-99".to_string();
        completed.issue_title = "Completed ticket".to_string();
        completed.phase = SessionPhase::Completed;
        completed.summary = "Complete | moved to `Human Review`".to_string();
        cycle.sessions.push(completed);

        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let snapshot = render_dashboard_with_view(&data, 140, 36, SessionListView::Completed)
            .expect("completed snapshot should render");

        assert!(snapshot.contains("Completed (1)"));
        assert!(snapshot.contains("MET-99"));
        assert!(!snapshot.contains("MET-17"));
    }

    #[test]
    fn snapshot_keeps_unknown_tokens_and_compact_session_ids() {
        let mut cycle = demo_cycle();
        let session = cycle
            .sessions
            .first_mut()
            .expect("demo cycle should include a session");
        session.tokens = Default::default();
        session.summary = "Progress text stays clean".to_string();

        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let snapshot = render_dashboard(&data, 140, 36).expect("snapshot should render");

        assert!(snapshot.contains("n/a"));
        assert!(snapshot.contains("019c...e1bf2a"));
        assert!(snapshot.contains("Progress text stays clean"));
    }

    #[test]
    fn detail_snapshot_shows_full_resume_handle() {
        let data = build_dashboard_data(
            &demo_cycle(),
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let state = SessionBrowserState {
            detail_mode: true,
            ..SessionBrowserState::default()
        };
        let session = state
            .selected_session(&data)
            .expect("demo data should include a selected session");
        let detail = data
            .detail_for_session(&session.issue_identifier)
            .expect("demo data should include detail for the selected session");
        let text = render_session_detail_text(session, detail);
        let rendered = text
            .lines
            .iter()
            .map(Line::to_string)
            .collect::<Vec<_>>()
            .join("\n");

        assert!(rendered.contains("Resume Provider: codex"));
        assert!(
            rendered.contains(
                "019cedb4-2293-7651-b0b4-dfac4af6a640-019cedb4-229b-7453-825e-3e3da4e1bf2a"
            )
        );
    }

    #[test]
    fn snapshot_shows_explicit_runtime_and_session_token_breakdown() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let snapshot = render_dashboard(&data, 180, 36).expect("snapshot should render");

        assert!(snapshot.contains("Tokens"));
        assert!(snapshot.contains("in 17,995,071 | out 58,080 | total 18,053,151"));
        assert!(snapshot.contains("9,622,232"));
        assert!(!snapshot.contains("in 9,614,112 | out 8,120 | total 9,622,232"));
        assert!(snapshot.contains("draft #321"));
    }

    #[test]
    fn snapshot_keeps_stage_labels_readable_in_medium_width_layout() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let snapshot = render_dashboard(&data, 140, 36).expect("snapshot should render");

        assert!(snapshot.contains("Brief Ready"));
        assert!(snapshot.contains("draft #321"));
        assert!(snapshot.contains("9,622,232"));
        assert!(snapshot.contains("PROVIDER"));
        assert!(snapshot.contains("PHASE"));
        assert!(snapshot.contains("STATE"));
        assert!(snapshot.contains("EXIT"));
    }

    #[test]
    fn snapshot_surfaces_empty_completed_state_in_compact_layout() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let snapshot = render_dashboard_with_view(&data, 96, 28, SessionListView::Completed)
            .expect("completed snapshot should render");

        assert!(snapshot.contains("No completed agent sessions are currently tracked."));
    }

    #[test]
    fn snapshot_surfaces_vim_view_switch_hints_when_enabled() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: true,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let snapshot = render_dashboard(&data, 140, 36).expect("snapshot should render");

        assert!(snapshot.contains("←/→/h/l"));
    }

    #[test]
    fn render_once_surfaces_selected_session_detail_panel() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let snapshot = render_dashboard_with_state(
            &data,
            200,
            56,
            SessionBrowserState {
                detail_mode: true,
                ..SessionBrowserState::default()
            },
        )
        .expect("detail snapshot should render");

        assert!(snapshot.contains("Selected Session"));
        assert!(snapshot.contains("PR: draft #321"));
        assert!(snapshot.contains("Lifecycle: Active"));
    }

    #[test]
    fn render_once_detail_panel_surfaces_ready_pull_request_status() {
        let mut cycle = demo_cycle();
        let session = cycle
            .sessions
            .first_mut()
            .expect("demo data should include a session");
        session.pull_request.status = crate::listen::PullRequestStatus::Ready;
        let detail = cycle
            .session_details
            .get_mut(&session.issue_identifier)
            .expect("demo data should include detail for the selected session");
        detail.pull_request.status = crate::listen::PullRequestStatus::Ready;
        if let Some(milestone) = detail.milestones.last_mut() {
            milestone.pull_request_status = crate::listen::PullRequestStatus::Ready;
        }

        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let state = SessionBrowserState {
            detail_mode: true,
            ..SessionBrowserState::default()
        };
        let session = state
            .selected_session(&data)
            .expect("demo data should include a selected session");
        let detail = data
            .detail_for_session(&session.issue_identifier)
            .expect("demo data should include detail for the selected session");
        let text = render_session_detail_text(session, detail);
        let rendered = text
            .lines
            .iter()
            .map(Line::to_string)
            .collect::<Vec<_>>()
            .join("\n");

        assert!(rendered.contains("PR: ready #321"));
        assert!(
            rendered.contains(
                "Brief Ready · Brief ready | backlog MET-14 | worker active | ready #321"
            )
        );
    }

    #[test]
    fn detail_panel_surfaces_blocked_stage_and_block_detail() {
        let mut cycle = demo_cycle();
        let blocked =
            BlockedReason::new(BlockedCategory::Gate, "CI repair budget exhausted", false);
        let session = cycle
            .sessions
            .first_mut()
            .expect("demo data should include a session");
        session.phase = SessionPhase::Blocked;
        session.summary = blocked.summary_headline();
        session.blocked = Some(blocked.clone());

        let detail = cycle
            .session_details
            .get_mut(&session.issue_identifier)
            .expect("demo data should include detail for the selected session");
        detail.phase = SessionPhase::Blocked;
        detail.summary = blocked.summary_headline();
        detail.blocked = Some(blocked);

        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let state = SessionBrowserState {
            view: SessionListView::Blocked,
            detail_mode: true,
            ..SessionBrowserState::default()
        };
        let session = state
            .selected_session(&data)
            .expect("blocked view should include the selected session");
        let detail = data
            .detail_for_session(&session.issue_identifier)
            .expect("blocked session detail should be available");
        let rendered = render_session_detail_text(session, detail)
            .lines
            .iter()
            .map(Line::to_string)
            .collect::<Vec<_>>()
            .join("\n");

        assert!(rendered.contains("Gate Err"));
        assert!(rendered.contains("Block Detail"));
        assert!(rendered.contains("Category: Gate"));
        assert!(rendered.contains("Retryable: no"));
    }

    #[test]
    fn render_once_detail_scroll_reveals_log_excerpts() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );
        let snapshot = render_dashboard_with_state(
            &data,
            200,
            64,
            SessionBrowserState {
                detail_mode: true,
                detail_scroll: u16::MAX,
                ..SessionBrowserState::default()
            },
        )
        .expect("detail snapshot should render");

        assert!(snapshot.contains("Published draft PR #321 for review visibility"));
    }

    #[test]
    fn detail_scroll_is_clamped_to_visible_content() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );
        let mut state = SessionBrowserState {
            detail_mode: true,
            detail_scroll: u16::MAX,
            ..SessionBrowserState::default()
        };

        state.normalize(&data);
        state.clamp_detail_scroll(&data, 200, 56);

        let (viewport_height, content_rows) =
            detail_scroll_metrics(&data, &state, 200, 56).expect("detail metrics should exist");
        assert_eq!(
            state.detail_scroll,
            clamp_offset(u16::MAX, viewport_height, content_rows)
        );
    }

    #[test]
    fn selected_session_detail_text_mentions_backspace_close_alias() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let state = SessionBrowserState {
            detail_mode: true,
            ..SessionBrowserState::default()
        };
        let session = state
            .selected_session(&data)
            .expect("demo data should include a selected session");
        let detail = data
            .detail_for_session(&session.issue_identifier)
            .expect("demo data should include detail for the selected session");
        let text = render_session_detail_text(session, detail);
        let rendered = text
            .lines
            .iter()
            .map(Line::to_string)
            .collect::<Vec<_>>()
            .join("\n");

        assert!(rendered.contains("Esc/Backspace close detail. PgUp/PgDn scroll."));
    }

    #[test]
    fn selected_session_detail_text_shows_pull_request_url_without_number() {
        let mut cycle = demo_cycle();
        let session = cycle
            .sessions
            .first_mut()
            .expect("demo data should include a session");
        session.pull_request.number = None;
        let detail = cycle
            .session_details
            .get_mut(&session.issue_identifier)
            .expect("demo data should include detail for the selected session");
        detail.pull_request.number = None;
        detail.pull_request.url =
            Some("https://github.com/metastack-labs/metastack-cli/pull/321".to_string());

        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let state = SessionBrowserState {
            detail_mode: true,
            ..SessionBrowserState::default()
        };
        let session = state
            .selected_session(&data)
            .expect("demo data should include a selected session");
        let detail = data
            .detail_for_session(&session.issue_identifier)
            .expect("demo data should include detail for the selected session");
        let text = render_session_detail_text(session, detail);
        let rendered = text
            .lines
            .iter()
            .map(Line::to_string)
            .collect::<Vec<_>>()
            .join("\n");

        assert!(
            rendered.contains("PR URL: https://github.com/metastack-labs/metastack-cli/pull/321")
        );
    }

    #[test]
    fn selected_session_detail_text_shows_pull_request_ref_without_url() {
        let mut cycle = demo_cycle();
        let session = cycle
            .sessions
            .first_mut()
            .expect("demo data should include a session");
        session.pull_request.url = None;
        let detail = cycle
            .session_details
            .get_mut(&session.issue_identifier)
            .expect("demo data should include detail for the selected session");
        detail.pull_request.url = None;

        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let state = SessionBrowserState {
            detail_mode: true,
            ..SessionBrowserState::default()
        };
        let session = state
            .selected_session(&data)
            .expect("demo data should include a selected session");
        let detail = data
            .detail_for_session(&session.issue_identifier)
            .expect("demo data should include detail for the selected session");
        let text = render_session_detail_text(session, detail);
        let rendered = text
            .lines
            .iter()
            .map(Line::to_string)
            .collect::<Vec<_>>()
            .join("\n");

        assert!(rendered.contains("PR Ref: #321"));
        assert!(!rendered.contains("PR URL:"));
    }

    #[test]
    fn selected_session_detail_uses_session_turn_history_for_context_pressure() {
        let mut cycle = demo_cycle();
        let session = cycle
            .sessions
            .first_mut()
            .expect("demo data should include a session");
        session.turn_history = vec![TurnTokenSnapshot {
            turn: 1,
            prompt_mode: TurnPromptMode::FullPrompt,
            tokens: TokenUsage {
                input: Some(171_000),
                output: None,
            },
            captured_at_epoch_seconds: 1,
        }];
        let detail = cycle
            .session_details
            .get_mut(&session.issue_identifier)
            .expect("demo data should include detail for the selected session");
        detail.turn_history.clear();

        let rendered = render_session_detail_text(session, detail)
            .lines
            .iter()
            .map(Line::to_string)
            .collect::<Vec<_>>()
            .join("\n");

        assert!(rendered.contains("Context Pressure: critical"));
    }

    #[test]
    fn selected_session_detail_uses_overridden_context_budget_for_context_pressure() {
        let mut cycle = demo_cycle();
        let session = cycle
            .sessions
            .first_mut()
            .expect("demo data should include a session");
        session.turn_history = vec![TurnTokenSnapshot {
            turn: 1,
            prompt_mode: TurnPromptMode::FullPrompt,
            tokens: TokenUsage {
                input: Some(90_000),
                output: None,
            },
            captured_at_epoch_seconds: 1,
        }];
        let detail = cycle
            .session_details
            .get_mut(&session.issue_identifier)
            .expect("demo data should include detail for the selected session");
        detail.context_budget_tokens = Some(100_000);

        let rendered = render_session_detail_text(session, detail)
            .lines
            .iter()
            .map(Line::to_string)
            .collect::<Vec<_>>()
            .join("\n");

        assert!(rendered.contains("Context Pressure: high"));
    }

    #[test]
    fn snapshot_renders_active_issues_pane_with_demo_data() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let snapshot = render_dashboard(&data, 140, 48).expect("snapshot should render");

        assert!(snapshot.contains("In Progress Issues - All Users"));
        assert!(snapshot.contains("MET-22"));
        assert!(snapshot.contains("MET-25"));
        assert!(snapshot.contains("MET-30"));
        assert!(snapshot.contains("Alice Chen"));
        assert!(snapshot.contains("Bob Taylor"));
        assert!(snapshot.contains("unassigned"));
        assert!(snapshot.contains("PR"));
    }

    #[test]
    fn active_issues_pane_hidden_when_config_disabled() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: false,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let snapshot = render_dashboard(&data, 140, 48).expect("snapshot should render");

        assert!(!snapshot.contains("In Progress Issues - All Users"));
        assert!(snapshot.contains("Agent Sessions"));
    }

    #[test]
    fn tab_toggles_focus_between_sessions_and_active_issues() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let mut state = SessionBrowserState::default();
        assert_eq!(state.focus, FocusPane::Sessions);

        state.apply_action(&data, SessionBrowserAction::Tab);
        assert_eq!(state.focus, FocusPane::ActiveIssues);

        state.apply_action(&data, SessionBrowserAction::Tab);
        assert_eq!(state.focus, FocusPane::Sessions);
    }

    #[test]
    fn tab_toggles_session_view_when_active_issues_disabled() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: false,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let mut state = SessionBrowserState::default();
        assert_eq!(state.view, SessionListView::Active);

        state.apply_action(&data, SessionBrowserAction::Tab);
        assert_eq!(state.view, SessionListView::Blocked);
        assert_eq!(state.focus, FocusPane::Sessions);

        state.apply_action(&data, SessionBrowserAction::Tab);
        assert_eq!(state.view, SessionListView::Completed);
        assert_eq!(state.focus, FocusPane::Sessions);
    }

    #[test]
    fn active_issue_selection_navigates_with_up_down() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let mut state = SessionBrowserState {
            focus: FocusPane::ActiveIssues,
            ..SessionBrowserState::default()
        };
        assert_eq!(state.selected_active_issue, 0);

        state.apply_action(&data, SessionBrowserAction::Down);
        assert_eq!(state.selected_active_issue, 1);

        state.apply_action(&data, SessionBrowserAction::Down);
        assert_eq!(state.selected_active_issue, 2);

        state.apply_action(&data, SessionBrowserAction::Up);
        assert_eq!(state.selected_active_issue, 1);
    }

    #[test]
    fn active_issue_enter_opens_detail_when_preview_enabled() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let mut state = SessionBrowserState {
            focus: FocusPane::ActiveIssues,
            ..SessionBrowserState::default()
        };
        state.apply_action(&data, SessionBrowserAction::Enter);
        assert!(state.detail_mode);
    }

    #[test]
    fn active_issue_detail_pane_renders_description() {
        let cycle = demo_cycle();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: 1_773_568_249,
                now_epoch_seconds: 1_773_575_600,
                poll_interval_seconds: 7,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: 1,
                linear_refresh_seconds: 15,
                vim_mode: false,
                show_active_issues: true,
                show_preview: true,
                resolved_agent: Some("codex".to_string()),
            },
        );

        let snapshot = render_dashboard_with_state(
            &data,
            200,
            56,
            SessionBrowserState {
                focus: FocusPane::ActiveIssues,
                detail_mode: true,
                ..SessionBrowserState::default()
            },
        )
        .expect("active issue detail snapshot should render");

        assert!(snapshot.contains("Issue Detail"));
        assert!(snapshot.contains("MET-22"));
        assert!(snapshot.contains("Description"));
    }

    #[test]
    fn active_issue_detail_text_includes_pr_url_and_assignee() {
        use crate::listen::ActiveIssue;

        let issue = ActiveIssue {
            identifier: "MET-42".to_string(),
            title: "Test issue".to_string(),
            assignee: Some("Charlie".to_string()),
            state_name: "In Progress".to_string(),
            has_open_pr: true,
            pr_url: Some("https://github.com/org/repo/pull/99".to_string()),
            description: Some("A detailed description".to_string()),
            url: "https://linear.app/issues/MET-42".to_string(),
            team_key: "MET".to_string(),
            project: Some("MyProject".to_string()),
        };

        let text = render_active_issue_detail_text(&issue);
        let rendered = text
            .lines
            .iter()
            .map(Line::to_string)
            .collect::<Vec<_>>()
            .join("\n");

        assert!(rendered.contains("Assignee: Charlie"));
        assert!(rendered.contains("PR: https://github.com/org/repo/pull/99"));
        assert!(rendered.contains("Project: MyProject"));
        assert!(rendered.contains("A detailed description"));
    }

    #[test]
    fn active_issue_detail_text_handles_no_assignee_no_pr() {
        use crate::listen::ActiveIssue;

        let issue = ActiveIssue {
            identifier: "MET-43".to_string(),
            title: "Minimal issue".to_string(),
            assignee: None,
            state_name: "In Progress".to_string(),
            has_open_pr: false,
            pr_url: None,
            description: None,
            url: "https://linear.app/issues/MET-43".to_string(),
            team_key: "MET".to_string(),
            project: None,
        };

        let text = render_active_issue_detail_text(&issue);
        let rendered = text
            .lines
            .iter()
            .map(Line::to_string)
            .collect::<Vec<_>>()
            .join("\n");

        assert!(rendered.contains("Assignee: unassigned"));
        assert!(rendered.contains("PR: none"));
        assert!(!rendered.contains("Description"));
        assert!(!rendered.contains("Project:"));
    }

    #[test]
    fn session_detail_renders_ci_waiting_and_no_checks_milestones() {
        let mut cycle = demo_cycle();
        cycle.sessions[0].summary = "Complete | no GitHub checks configured".to_string();
        let detail = cycle
            .session_details
            .get_mut("MET-13")
            .expect("demo detail should exist");
        detail.summary = "Complete | no GitHub checks configured".to_string();
        detail.milestones.push(SessionMilestone {
            at_epoch_seconds: 1_773_575_620,
            phase: SessionPhase::Publishing,
            lifecycle: None,
            summary: "Publishing draft PR | waiting for GitHub CI 0/1 settled | 1s remaining"
                .to_string(),
            turns: Some(1),
            pull_request_status: PullRequestStatus::Draft,
            pull_request_number: Some(321),
        });
        detail.milestones.push(SessionMilestone {
            at_epoch_seconds: 1_773_575_621,
            phase: SessionPhase::Publishing,
            lifecycle: None,
            summary: "Publishing review-ready handoff | no GitHub checks configured".to_string(),
            turns: Some(1),
            pull_request_status: PullRequestStatus::Ready,
            pull_request_number: Some(321),
        });

        let rendered = render_session_detail_text(&cycle.sessions[0], detail)
            .lines
            .iter()
            .map(Line::to_string)
            .collect::<Vec<_>>()
            .join("\n");

        assert!(rendered.contains("waiting for GitHub CI 0/1 settled"));
        assert!(rendered.contains("no GitHub checks configured"));
    }

    #[test]
    fn session_detail_renders_stale_worker_recovery_metadata() {
        let mut cycle = demo_cycle();
        let session = cycle
            .sessions
            .first_mut()
            .expect("demo data should include a session");
        session.started_at_epoch_seconds = 1_773_568_000;

        let detail = cycle
            .session_details
            .get_mut(&session.issue_identifier)
            .expect("demo data should include detail for the selected session");
        detail.started_at_epoch_seconds = 1_773_568_000;
        detail.updated_at_epoch_seconds = 1_773_568_900;
        detail.stale_worker_recovery_attempt_count = 1;
        detail.latest_stale_worker_failure = Some(StaleWorkerFailure {
            pid: 42_424,
            observed_at_epoch_seconds: 1_773_568_450,
            last_persisted_phase: SessionPhase::Running,
            summary: "worker exited without a recorded completion".to_string(),
            classification: BlockedReason {
                category: BlockedCategory::Infra,
                reason: "worker died".to_string(),
                retryable: true,
            },
        });

        let rendered = render_session_detail_text(session, detail)
            .lines
            .iter()
            .map(Line::to_string)
            .collect::<Vec<_>>()
            .join("\n");

        assert!(rendered.contains("Elapsed Since Start:"));
        assert!(rendered.contains("Recovery Attempts: 1/2"));
        assert!(rendered.contains("Latest Stale Worker Failure: pid 42424"));
        assert!(rendered.contains("Latest Stale Worker Observed:"));
    }
}
