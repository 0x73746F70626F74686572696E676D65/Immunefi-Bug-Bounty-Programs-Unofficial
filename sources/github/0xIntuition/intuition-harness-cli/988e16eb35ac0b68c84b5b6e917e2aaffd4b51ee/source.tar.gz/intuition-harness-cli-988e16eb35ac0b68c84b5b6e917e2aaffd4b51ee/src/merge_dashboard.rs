use std::collections::BTreeSet;
use std::io::{self, IsTerminal};
use std::time::Duration;

use anyhow::{Result, bail};
use crossterm::event::{self, Event, KeyCode, KeyEventKind, MouseEvent};
use crossterm::execute;
use crossterm::terminal::{
    EnterAlternateScreen, LeaveAlternateScreen, disable_raw_mode, enable_raw_mode,
};
use ratatui::backend::{CrosstermBackend, TestBackend};
use ratatui::layout::{Constraint, Direction, Layout, Rect};
use ratatui::style::Style;
use ratatui::text::{Line, Span, Text};
use ratatui::widgets::{ListItem, ListState};
use ratatui::{Frame, Terminal};

use crate::tui::copy::{CopyPayload, CopyUiState, copy_overlay_viewport, pane_copy_help};
use crate::tui::keybindings::is_copy_key;
use crate::tui::markdown::render_markdown;
use crate::tui::scroll::{ScrollState, plain_text, scrollable_content_paragraph, wrapped_rows};
use crate::tui::spaced_list::{render_github_pr_row, spaced_list};
use crate::tui::theme::{
    Tone, badge, emphasis_style, empty_state, key_hints, label_style, muted_style, panel_title,
    paragraph,
};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MergeDashboardPullRequest {
    pub number: u64,
    pub title: String,
    pub author: String,
    pub head_ref: String,
    pub updated_at: String,
    pub url: String,
    pub body: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MergeDashboardData {
    pub title: String,
    pub repo_label: String,
    pub base_branch: String,
    pub pull_requests: Vec<MergeDashboardPullRequest>,
}

#[derive(Debug, Clone)]
pub struct MergeDashboardOptions {
    pub render_once: bool,
    pub width: u16,
    pub height: u16,
    pub actions: Vec<MergeDashboardAction>,
    pub vim_mode: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MergeDashboardAction {
    Up,
    Down,
    Tab,
    PageUp,
    PageDown,
    Home,
    End,
    Toggle,
    Enter,
    Back,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum MergeDashboardExit {
    Snapshot(String),
    Cancelled,
    Selected(Vec<u64>),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Focus {
    PullRequests,
    Preview,
    Confirm,
}

#[derive(Debug, Clone)]
struct MergeDashboardApp {
    data: MergeDashboardData,
    focus: Focus,
    pr_index: usize,
    preview_scroll: ScrollState,
    selected: BTreeSet<usize>,
    completed: Option<Vec<u64>>,
    copy: CopyUiState,
}

pub fn run_merge_dashboard(
    data: MergeDashboardData,
    options: MergeDashboardOptions,
) -> Result<MergeDashboardExit> {
    let _ = options.vim_mode;
    if options.render_once {
        return render_once(data, options).map(MergeDashboardExit::Snapshot);
    }

    if !io::stdout().is_terminal() {
        bail!(
            "the interactive merge dashboard requires a TTY; use `{cmd} merge --json` for discovery or `{cmd} merge --no-interactive --pull-request <NUMBER>` for scripted runs",
            cmd = crate::branding::COMMAND_NAME
        );
    }

    let mut stdout = io::stdout();
    enable_raw_mode()?;
    execute!(stdout, EnterAlternateScreen)?;
    let _cleanup = TerminalCleanup;

    let backend = CrosstermBackend::new(stdout);
    let mut terminal = Terminal::new(backend)?;
    let mut app = MergeDashboardApp::new(data);

    loop {
        terminal.draw(|frame| render_dashboard(frame, &app))?;

        if !event::poll(Duration::from_millis(250))? {
            continue;
        }

        match event::read()? {
            Event::Key(key) if key.kind == KeyEventKind::Press => {
                let size = terminal.size()?;
                if app.copy.export_active()
                    && app
                        .copy
                        .handle_export_key(key, copy_overlay_viewport(size.into()))
                {
                    continue;
                }
                if is_copy_key(key) {
                    app.copy.copy_payload(app.copy_payload());
                    continue;
                }
                let viewport = preview_viewport(size.into());
                let action = match key.code {
                    KeyCode::Char('q') => return Ok(MergeDashboardExit::Cancelled),
                    KeyCode::Up => Some(MergeDashboardAction::Up),
                    KeyCode::Down => Some(MergeDashboardAction::Down),
                    KeyCode::Tab => Some(MergeDashboardAction::Tab),
                    KeyCode::PageUp => Some(MergeDashboardAction::PageUp),
                    KeyCode::PageDown => Some(MergeDashboardAction::PageDown),
                    KeyCode::Home => Some(MergeDashboardAction::Home),
                    KeyCode::End => Some(MergeDashboardAction::End),
                    KeyCode::Char(' ') => Some(MergeDashboardAction::Toggle),
                    KeyCode::Enter => Some(MergeDashboardAction::Enter),
                    KeyCode::Esc | KeyCode::Backspace => Some(MergeDashboardAction::Back),
                    _ => None,
                };

                if let Some(action) = action
                    && let Some(selection) = app.apply_in_viewport(action, viewport)
                {
                    return Ok(MergeDashboardExit::Selected(selection));
                }
            }
            Event::Mouse(mouse) => {
                let size = terminal.size()?;
                if app.copy.export_active() {
                    let _ = app
                        .copy
                        .handle_export_mouse(mouse, copy_overlay_viewport(size.into()));
                } else {
                    let viewport = preview_viewport(size.into());
                    let _ = app.handle_mouse(mouse, viewport);
                }
            }
            _ => {}
        }
    }
}

fn render_once(data: MergeDashboardData, options: MergeDashboardOptions) -> Result<String> {
    let backend = TestBackend::new(options.width, options.height);
    let mut terminal = Terminal::new(backend)?;
    let mut app = MergeDashboardApp::new(data);
    let viewport = preview_viewport(Rect::new(0, 0, options.width, options.height));

    for action in options.actions {
        if let Some(selection) = app.apply_in_viewport(action, viewport) {
            app.completed = Some(selection);
            break;
        }
    }

    terminal.draw(|frame| render_dashboard(frame, &app))?;
    Ok(snapshot(terminal.backend()))
}

fn render_dashboard(frame: &mut Frame<'_>, app: &MergeDashboardApp) {
    let outer = Layout::default()
        .direction(Direction::Vertical)
        .constraints([Constraint::Length(7), Constraint::Min(0)])
        .split(frame.area());
    let body = Layout::default()
        .direction(Direction::Horizontal)
        .constraints([Constraint::Percentage(46), Constraint::Percentage(54)])
        .split(outer[1]);
    let sidebar = Layout::default()
        .direction(Direction::Vertical)
        .constraints([Constraint::Length(12), Constraint::Min(0)])
        .split(body[1]);

    let header = paragraph(
        Text::from(vec![
            Line::from(vec![
                app.status_badge(),
                Span::raw(" "),
                Span::styled(app.data.title.clone(), emphasis_style()),
            ]),
            Line::from(Span::styled(app.summary_line(), emphasis_style())),
            Line::from(vec![
                Span::styled("Repo ", label_style()),
                Span::raw(app.data.repo_label.clone()),
                Span::styled("  Base ", label_style()),
                Span::raw(app.data.base_branch.clone()),
            ]),
            Line::from(
                app.copy
                    .status_text()
                    .map(str::to_string)
                    .unwrap_or_else(|| {
                        pane_copy_help(
                            "Tab changes focus. Up/Down moves the queue, PgUp/PgDn/Home/End or the mouse wheel scroll the preview, and Space toggles selection.",
                        )
                    }),
            ),
            key_hints(&[
                ("Up/Down", "move/scroll"),
                ("Tab", "focus"),
                ("PgUp/PgDn", "scroll preview"),
                ("Wheel", "scroll preview"),
                ("Space", "select"),
                ("Ctrl+Y", "copy"),
                ("Enter", "advance"),
                ("Esc", "back"),
                ("q", "exit"),
            ]),
        ]),
        panel_title(format!("{} merge", crate::branding::COMMAND_NAME), false),
    );
    frame.render_widget(header, outer[0]);

    render_pr_list(frame, body[0], app);
    render_selection_summary(frame, sidebar[0], app);
    render_details(frame, sidebar[1], app);
    app.copy.render_export_overlay(frame, frame.area());
}

fn render_pr_list(frame: &mut Frame<'_>, area: Rect, app: &MergeDashboardApp) {
    let title = panel_title(
        format!("Pull Request Queue ({})", app.data.pull_requests.len()),
        app.focus == Focus::PullRequests,
    );
    let items = if app.data.pull_requests.is_empty() {
        vec![ListItem::new(empty_state(
            "No open pull requests are available for this repository.",
            "Open work on GitHub before launching a one-shot merge batch.",
        ))]
    } else {
        app.data
            .pull_requests
            .iter()
            .enumerate()
            .map(|(index, pr)| {
                let (state_label, tone) = if app.selected.contains(&index) {
                    ("selected", Tone::Accent)
                } else {
                    ("queued", Tone::Muted)
                };
                render_github_pr_row(
                    pr.number,
                    &pr.title,
                    badge(state_label, tone),
                    &[
                        ("Author", pr.author.clone()),
                        ("Branch", pr.head_ref.clone()),
                    ],
                    &format!("Updated {}", pr.updated_at),
                )
            })
            .collect::<Vec<_>>()
    };

    let mut state = ListState::default();
    state.select(Some(
        app.pr_index
            .min(app.data.pull_requests.len().saturating_sub(1)),
    ));
    let list_widget = spaced_list(items, title)
        .highlight_style(Style::default())
        .highlight_symbol(">> ");
    frame.render_stateful_widget(list_widget, area, &mut state);
}

fn render_selection_summary(frame: &mut Frame<'_>, area: Rect, app: &MergeDashboardApp) {
    let text = if let Some(status) = app.copy.status_text() {
        format!("{status}\n\n{}", pane_copy_help(&app.selection_text()))
    } else {
        pane_copy_help(&app.selection_text())
    };
    let summary = paragraph(
        text,
        panel_title("Selected Batch Review", app.focus == Focus::Confirm),
    );
    frame.render_widget(summary, area);
}

fn render_details(frame: &mut Frame<'_>, area: Rect, app: &MergeDashboardApp) {
    let details = scrollable_content_paragraph(
        app.detail_text(),
        panel_title("Focused PR Preview", app.focus == Focus::Preview),
        &app.preview_scroll,
    )
    .wrap(ratatui::widgets::Wrap { trim: false });
    frame.render_widget(details, area);
}

impl MergeDashboardApp {
    fn new(data: MergeDashboardData) -> Self {
        Self {
            data,
            focus: Focus::PullRequests,
            pr_index: 0,
            preview_scroll: ScrollState::default(),
            selected: BTreeSet::new(),
            completed: None,
            copy: CopyUiState::default(),
        }
    }

    fn apply_in_viewport(
        &mut self,
        action: MergeDashboardAction,
        preview_viewport: Rect,
    ) -> Option<Vec<u64>> {
        self.completed = None;

        match action {
            MergeDashboardAction::Up => {
                if self.focus == Focus::Preview {
                    self.scroll_preview_key(KeyCode::Up, preview_viewport);
                } else if self.focus == Focus::PullRequests {
                    self.move_selection(-1);
                }
            }
            MergeDashboardAction::Down => {
                if self.focus == Focus::Preview {
                    self.scroll_preview_key(KeyCode::Down, preview_viewport);
                } else if self.focus == Focus::PullRequests {
                    self.move_selection(1);
                }
            }
            MergeDashboardAction::Tab => {
                self.focus = match self.focus {
                    Focus::PullRequests => Focus::Preview,
                    Focus::Preview => Focus::PullRequests,
                    Focus::Confirm => Focus::Confirm,
                };
            }
            MergeDashboardAction::PageUp => {
                if self.focus == Focus::Preview {
                    self.scroll_preview_key(KeyCode::PageUp, preview_viewport);
                }
            }
            MergeDashboardAction::PageDown => {
                if self.focus == Focus::Preview {
                    self.scroll_preview_key(KeyCode::PageDown, preview_viewport);
                }
            }
            MergeDashboardAction::Home => {
                if self.focus == Focus::Preview {
                    self.scroll_preview_key(KeyCode::Home, preview_viewport);
                }
            }
            MergeDashboardAction::End => {
                if self.focus == Focus::Preview {
                    self.scroll_preview_key(KeyCode::End, preview_viewport);
                }
            }
            MergeDashboardAction::Toggle => {
                if self.focus == Focus::PullRequests
                    && !self.data.pull_requests.is_empty()
                    && !self.selected.insert(self.pr_index)
                {
                    self.selected.remove(&self.pr_index);
                }
            }
            MergeDashboardAction::Enter => match self.focus {
                Focus::PullRequests | Focus::Preview => {
                    if !self.selected.is_empty() {
                        self.focus = Focus::Confirm;
                    }
                }
                Focus::Confirm => {
                    let selection = self.selected_numbers();
                    self.completed = Some(selection.clone());
                    return Some(selection);
                }
            },
            MergeDashboardAction::Back => match self.focus {
                Focus::PullRequests => return Some(Vec::new()),
                Focus::Preview => self.focus = Focus::PullRequests,
                Focus::Confirm => self.focus = Focus::PullRequests,
            },
        }

        None
    }

    fn selected_numbers(&self) -> Vec<u64> {
        self.selected
            .iter()
            .filter_map(|index| self.data.pull_requests.get(*index))
            .map(|pr| pr.number)
            .collect()
    }

    fn copy_payload(&self) -> CopyPayload {
        match self.focus {
            Focus::PullRequests => {
                let text = self
                    .data
                    .pull_requests
                    .get(self.pr_index)
                    .map(|pr| {
                        format!(
                            "Focused PR: #{} {}\nAuthor: {}\nBranch: {}\nUpdated: {}",
                            pr.number, pr.title, pr.author, pr.head_ref, pr.updated_at
                        )
                    })
                    .unwrap_or_else(|| "No pull request is available.".to_string());
                CopyPayload::new("merge dashboard PR selection", text)
            }
            Focus::Preview => CopyPayload::from_text("merge dashboard preview", self.detail_text()),
            Focus::Confirm => {
                CopyPayload::new("merge dashboard batch summary", self.selection_text())
            }
        }
    }

    fn selected_prs(&self) -> Vec<&MergeDashboardPullRequest> {
        self.selected
            .iter()
            .filter_map(|index| self.data.pull_requests.get(*index))
            .collect()
    }

    fn status_badge(&self) -> Span<'static> {
        if let Some(selected) = &self.completed {
            if selected.is_empty() {
                return badge("canceled", Tone::Muted);
            }
            return badge("ready", Tone::Success);
        }

        if self.data.pull_requests.is_empty() {
            return badge("empty", Tone::Muted);
        }

        match self.focus {
            Focus::PullRequests if self.selected.is_empty() => badge("select", Tone::Info),
            Focus::PullRequests | Focus::Preview => badge("review", Tone::Accent),
            Focus::Confirm => badge("confirm", Tone::Success),
        }
    }

    fn summary_line(&self) -> String {
        if let Some(selected) = &self.completed {
            if selected.is_empty() {
                return "Merge canceled before a batch was launched.".to_string();
            }
            return format!(
                "One-shot batch ready: {} pull request(s) will be handed to the merge agent.",
                selected.len()
            );
        }

        match self.focus {
            Focus::PullRequests | Focus::Preview => {
                if self.data.pull_requests.is_empty() {
                    "The GitHub repository currently has no open pull requests.".to_string()
                } else if self.selected.is_empty() {
                    format!(
                        "{} open pull request(s) discovered for {}. Select one or more entries, then press Enter. Tab moves focus into the preview pane, where PgUp/PgDn/Home/End and the mouse wheel scroll long details.",
                        self.data.pull_requests.len(),
                        self.data.repo_label
                    )
                } else {
                    format!(
                        "{} pull request(s) selected. Press Enter to review the one-shot batch summary, or Tab to inspect the focused PR preview.",
                        self.selected.len()
                    )
                }
            }
            Focus::Confirm => format!(
                "Review the one-shot batch summary for {} before the merge run starts.",
                self.data.repo_label
            ),
        }
    }

    fn selection_text(&self) -> String {
        if self.data.pull_requests.is_empty() {
            return "No one-shot batch can be created until open pull requests exist on the repository."
                .to_string();
        }

        let selected = self.selected_prs();
        if selected.is_empty() {
            return format!(
                "Step 1 of 2: choose the pull requests to batch for `{}`.\n\nNothing is selected yet.\n\nSelect one or more entries on the left, then press Enter to review the launch summary.",
                self.data.repo_label,
            );
        }

        let mut lines = vec![
            format!(
                "Step 2 of 2: this is a one-shot batch targeting `{}`.",
                self.data.base_branch
            ),
            format!(
                "{} pull request(s) will be handed to the merge agent:",
                selected.len()
            ),
        ];

        for pr in selected {
            lines.push(format!("- #{} {} ({})", pr.number, pr.title, pr.head_ref));
        }

        if self.focus == Focus::Confirm {
            lines.push(String::new());
            lines.push(
                "Press Enter to start the merge run. Press Esc to return to the PR list without launching anything."
                    .to_string(),
            );
        } else {
            lines.push(String::new());
            lines.push(
                "Press Enter to review the final confirmation screen before the merge run starts."
                    .to_string(),
            );
        }

        lines.join("\n")
    }

    fn detail_text(&self) -> Text<'static> {
        let Some(pr) = self.data.pull_requests.get(self.pr_index) else {
            return Text::from(vec![
                Line::from(format!("Repository: {}", self.data.repo_label)),
                Line::from(format!("Base branch: {}", self.data.base_branch)),
                Line::from(""),
                Line::from("Open PR discovery is empty, so there is nothing to preview."),
                Line::from(""),
                Line::from(
                    "The planner preview will appear here once GitHub returns open pull requests.",
                ),
            ]);
        };

        let mut lines = vec![
            Line::from(format!("Repository: {}", self.data.repo_label)),
            Line::from(format!("Base branch: {}", self.data.base_branch)),
            Line::from(""),
            Line::from("Focused pull request"),
            Line::from(format!("#{} {}", pr.number, pr.title)),
            Line::from(format!("Author: {}", pr.author)),
            Line::from(format!("Head ref: {}", pr.head_ref)),
            Line::from(format!("Updated: {}", pr.updated_at)),
            Line::from(format!("URL: {}", pr.url)),
            Line::from(""),
            Line::from("Description"),
        ];
        let body = if pr.body.trim().is_empty() {
            "_No pull request description provided._"
        } else {
            pr.body.as_str()
        };
        lines.extend(render_markdown(body, muted_style(), &[]).lines);
        lines.extend([
            Line::from(""),
            Line::from("Planner handoff"),
            Line::from(
                "The merge planner receives every selected PR title, author, branch, timestamp, URL, and rendered PR body context before execution.",
            ),
        ]);

        Text::from(lines)
    }

    fn move_selection(&mut self, delta: isize) {
        let before = self.pr_index;
        shift_index(&mut self.pr_index, self.data.pull_requests.len(), delta);
        if self.pr_index != before {
            self.preview_scroll.reset();
        }
    }

    fn preview_content_rows(&self, width: u16) -> usize {
        wrapped_rows(&plain_text(&self.detail_text()), width.max(1))
    }

    fn scroll_preview_key(&mut self, key: KeyCode, viewport: Rect) {
        let _ = self.preview_scroll.apply_key_code_in_viewport(
            key,
            viewport,
            self.preview_content_rows(viewport.width.max(1)),
        );
    }

    fn handle_mouse(&mut self, mouse: MouseEvent, viewport: Rect) -> bool {
        if self.focus != Focus::Preview {
            return false;
        }

        self.preview_scroll.apply_mouse_in_viewport(
            mouse,
            viewport,
            self.preview_content_rows(viewport.width.max(1)),
        )
    }
}

fn shift_index(index: &mut usize, len: usize, delta: isize) {
    if len == 0 {
        *index = 0;
        return;
    }

    let mut next = *index as isize + delta;
    if next < 0 {
        next = len.saturating_sub(1) as isize;
    } else if next >= len as isize {
        next = 0;
    }
    *index = next as usize;
}

fn preview_viewport(area: Rect) -> Rect {
    let outer = Layout::default()
        .direction(Direction::Vertical)
        .constraints([Constraint::Length(7), Constraint::Min(0)])
        .split(area);
    let body = Layout::default()
        .direction(Direction::Horizontal)
        .constraints([Constraint::Percentage(46), Constraint::Percentage(54)])
        .split(outer[1]);
    let sidebar = Layout::default()
        .direction(Direction::Vertical)
        .constraints([Constraint::Length(12), Constraint::Min(0)])
        .split(body[1]);

    Rect::new(
        sidebar[1].x.saturating_add(1),
        sidebar[1].y.saturating_add(1),
        sidebar[1].width.saturating_sub(2).max(1),
        sidebar[1].height.saturating_sub(2).max(1),
    )
}

fn snapshot(backend: &TestBackend) -> String {
    let buffer = backend.buffer();
    let mut lines = Vec::new();

    for y in 0..buffer.area.height {
        let mut line = String::new();
        for x in 0..buffer.area.width {
            line.push_str(buffer[(x, y)].symbol());
        }
        lines.push(line.trim_end().to_string());
    }

    lines.join("\n")
}

struct TerminalCleanup;

impl Drop for TerminalCleanup {
    fn drop(&mut self) {
        let _ = disable_raw_mode();
        let mut stdout = io::stdout();
        let _ = execute!(stdout, LeaveAlternateScreen);
    }
}

#[cfg(test)]
mod tests {
    use super::{
        Focus, MergeDashboardAction, MergeDashboardApp, MergeDashboardData, MergeDashboardExit,
        MergeDashboardOptions, MergeDashboardPullRequest, preview_viewport, run_merge_dashboard,
    };
    use crate::tui::scroll::plain_text;
    use crossterm::event::{KeyModifiers, MouseEvent, MouseEventKind};
    use ratatui::layout::Rect;

    fn demo_data() -> MergeDashboardData {
        MergeDashboardData {
            title: format!("{} merge", crate::branding::COMMAND_NAME),
            repo_label: "metastack-systems/metastack-cli".to_string(),
            base_branch: "main".to_string(),
            pull_requests: vec![
                MergeDashboardPullRequest {
                    number: 101,
                    title: "Add merge transport".to_string(),
                    author: "kames".to_string(),
                    head_ref: "feature/transport".to_string(),
                    updated_at: "2026-03-16T18:30:00Z".to_string(),
                    url: "https://example.com/101".to_string(),
                    body: "## Summary\n\n- transport setup\n- validation".to_string(),
                },
                MergeDashboardPullRequest {
                    number: 102,
                    title: "Add merge dashboard".to_string(),
                    author: "kames".to_string(),
                    head_ref: "feature/dashboard".to_string(),
                    updated_at: "2026-03-16T18:45:00Z".to_string(),
                    url: "https://example.com/102".to_string(),
                    body: "> follow-up preview body".to_string(),
                },
            ],
        }
    }

    #[test]
    fn render_once_handles_empty_state() {
        let exit = run_merge_dashboard(
            MergeDashboardData {
                title: format!("{} merge", crate::branding::COMMAND_NAME),
                repo_label: "demo/repo".to_string(),
                base_branch: "main".to_string(),
                pull_requests: Vec::new(),
            },
            MergeDashboardOptions {
                render_once: true,
                width: 120,
                height: 32,
                actions: Vec::new(),
                vim_mode: false,
            },
        )
        .expect("render_once should succeed");

        let MergeDashboardExit::Snapshot(snapshot) = exit else {
            panic!("render_once should produce a snapshot");
        };
        assert!(snapshot.contains("No open pull requests are available"));
        assert!(snapshot.contains("one-shot"));
    }

    #[test]
    fn render_once_shows_single_selection_summary() {
        let exit = run_merge_dashboard(
            demo_data(),
            MergeDashboardOptions {
                render_once: true,
                width: 120,
                height: 32,
                actions: vec![MergeDashboardAction::Toggle, MergeDashboardAction::Enter],
                vim_mode: false,
            },
        )
        .expect("render_once should succeed");

        let MergeDashboardExit::Snapshot(snapshot) = exit else {
            panic!("render_once should produce a snapshot");
        };
        assert!(snapshot.contains("#101 Add merge transport"));
        assert!(snapshot.contains("1 pull request(s) will be handed to the merge agent"));
    }

    #[test]
    fn merge_dashboard_detail_text_includes_pr_body_markdown() {
        let app = MergeDashboardApp::new(demo_data());
        let detail = plain_text(&app.detail_text());

        assert!(detail.contains("Description"));
        assert!(detail.contains("## Summary"));
        assert!(detail.contains("transport setup"));
    }

    #[test]
    fn render_once_shows_multi_selection_summary() {
        let exit = run_merge_dashboard(
            demo_data(),
            MergeDashboardOptions {
                render_once: true,
                width: 120,
                height: 32,
                actions: vec![
                    MergeDashboardAction::Toggle,
                    MergeDashboardAction::Down,
                    MergeDashboardAction::Toggle,
                    MergeDashboardAction::Enter,
                ],
                vim_mode: false,
            },
        )
        .expect("render_once should succeed");

        let MergeDashboardExit::Snapshot(snapshot) = exit else {
            panic!("render_once should produce a snapshot");
        };
        assert!(snapshot.contains("#101 Add merge transport"));
        assert!(snapshot.contains("#102 Add merge dashboard"));
        assert!(snapshot.contains("2 pull request(s) will be handed to the merge agent"));
    }

    #[test]
    fn back_from_confirm_returns_to_pr_list() {
        let mut app = MergeDashboardApp::new(demo_data());
        assert_eq!(app.focus, Focus::PullRequests);
        app.apply_in_viewport(
            MergeDashboardAction::Toggle,
            preview_viewport(Rect::new(0, 0, 120, 32)),
        );
        app.apply_in_viewport(
            MergeDashboardAction::Enter,
            preview_viewport(Rect::new(0, 0, 120, 32)),
        );
        assert_eq!(app.focus, Focus::Confirm);
        app.apply_in_viewport(
            MergeDashboardAction::Back,
            preview_viewport(Rect::new(0, 0, 120, 32)),
        );
        assert_eq!(app.focus, Focus::PullRequests);
    }

    #[test]
    fn back_from_pr_list_cancels_the_dashboard() {
        let mut app = MergeDashboardApp::new(demo_data());
        let exit = app.apply_in_viewport(
            MergeDashboardAction::Back,
            preview_viewport(Rect::new(0, 0, 120, 32)),
        );
        assert_eq!(exit, Some(Vec::new()));
    }

    #[test]
    fn preview_scrolls_to_bottom_for_long_pr_details() {
        let mut data = demo_data();
        data.pull_requests[0].title = (1..=18)
            .map(|index| format!("overflow detail line {index}"))
            .collect::<Vec<_>>()
            .join(" ");
        data.pull_requests[0].url = (1..=18)
            .map(|index| format!("https://example.com/long/path/segment/{index}"))
            .collect::<Vec<_>>()
            .join("/");

        let viewport = preview_viewport(Rect::new(0, 0, 120, 20));
        let mut app = MergeDashboardApp::new(data);
        app.apply_in_viewport(MergeDashboardAction::Tab, viewport);
        app.apply_in_viewport(MergeDashboardAction::End, viewport);

        assert_eq!(app.focus, Focus::Preview);
        assert!(app.preview_scroll.offset() > 0);
    }

    #[test]
    fn preview_mouse_wheel_scrolls_only_when_preview_is_focused() {
        let mut data = demo_data();
        data.pull_requests[0].title = (1..=18)
            .map(|index| format!("overflow detail line {index}"))
            .collect::<Vec<_>>()
            .join(" ");
        data.pull_requests[0].url = (1..=18)
            .map(|index| format!("https://example.com/long/path/segment/{index}"))
            .collect::<Vec<_>>()
            .join("/");

        let viewport = preview_viewport(Rect::new(0, 0, 120, 20));
        let mut app = MergeDashboardApp::new(data);
        let mouse = MouseEvent {
            kind: MouseEventKind::ScrollDown,
            column: viewport.x,
            row: viewport.y,
            modifiers: KeyModifiers::NONE,
        };

        assert!(!app.handle_mouse(mouse, viewport));
        assert_eq!(app.preview_scroll.offset(), 0);

        app.apply_in_viewport(MergeDashboardAction::Tab, viewport);
        assert!(app.handle_mouse(mouse, viewport));
        assert!(app.preview_scroll.offset() > 0);
    }
}
