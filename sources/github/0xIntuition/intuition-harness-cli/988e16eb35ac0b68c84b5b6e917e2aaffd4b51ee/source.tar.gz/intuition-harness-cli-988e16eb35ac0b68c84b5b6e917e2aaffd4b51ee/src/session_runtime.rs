use std::ffi::OsStr;
use std::fmt;
use std::fs;
use std::io::{ErrorKind, Write};
use std::marker::PhantomData;
use std::path::{Path, PathBuf};

use anyhow::{Context, Result};
use serde::Serialize;
use serde::de::DeserializeOwned;
use tempfile::{Builder, NamedTempFile};

/// Shared root layout for durable workflow state.
#[derive(Debug, Clone)]
pub(crate) struct WorkflowRootLayout {
    root: PathBuf,
    active_session_path: PathBuf,
}

impl WorkflowRootLayout {
    /// Create an install-scoped workflow layout rooted at the provided directory.
    pub(crate) fn install_scoped(root: PathBuf, active_session_file_name: &str) -> Self {
        let active_session_path = root.join(active_session_file_name);
        Self {
            root,
            active_session_path,
        }
    }

    /// Create a repo-local workflow layout under the provided repository root.
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn repo_scoped(
        repo_root: &Path,
        relative_root: impl AsRef<Path>,
        active_session_file_name: &str,
    ) -> Self {
        Self::install_scoped(
            repo_root.join(relative_root.as_ref()),
            active_session_file_name,
        )
    }

    /// Return the workflow root directory.
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn root(&self) -> &Path {
        &self.root
    }

    /// Return the active-session marker path.
    pub(crate) fn active_session_path(&self) -> &Path {
        &self.active_session_path
    }

    /// Join an additional path segment under the workflow root.
    pub(crate) fn path(&self, relative: impl AsRef<Path>) -> PathBuf {
        self.root.join(relative.as_ref())
    }

    /// Build an active-session file handle rooted at this layout's marker path.
    pub(crate) fn active_session_file<T>(&self) -> ActiveSessionFile<T> {
        ActiveSessionFile::new(self.active_session_path.clone())
    }
}

/// Shared layout for workflows that store per-session directories under a root.
#[cfg_attr(not(test), allow(dead_code))]
#[derive(Debug, Clone)]
pub(crate) struct WorkflowSessionLayout {
    workflow: WorkflowRootLayout,
    sessions_dir: PathBuf,
}

impl WorkflowSessionLayout {
    /// Create a session-oriented workflow layout from an existing root layout.
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn with_sessions_dir(workflow: WorkflowRootLayout, sessions_dir_name: &str) -> Self {
        let sessions_dir = workflow.path(sessions_dir_name);
        Self {
            workflow,
            sessions_dir,
        }
    }

    /// Return the shared workflow root layout.
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn workflow(&self) -> &WorkflowRootLayout {
        &self.workflow
    }

    /// Return the directory that stores per-session subdirectories.
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn sessions_dir(&self) -> &Path {
        &self.sessions_dir
    }

    /// Return the directory for a specific session identifier.
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn session_dir(&self, session_id: &str) -> PathBuf {
        self.sessions_dir.join(session_id)
    }
}

/// Shared wrapper around an active-session marker file.
#[derive(Debug, Clone)]
pub(crate) struct ActiveSessionFile<T> {
    path: PathBuf,
    _marker: PhantomData<T>,
}

impl<T> ActiveSessionFile<T> {
    /// Create a typed active-session file handle for the provided path.
    pub(crate) fn new(path: PathBuf) -> Self {
        Self {
            path,
            _marker: PhantomData,
        }
    }

    /// Return the underlying marker path.
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn path(&self) -> &Path {
        &self.path
    }
}

impl<T> ActiveSessionFile<T>
where
    T: Serialize + DeserializeOwned,
{
    /// Persist the marker payload, creating parent directories when needed.
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn store(&self, value: &T) -> Result<()> {
        write_json(&self.path, value)
    }

    /// Load the marker payload, returning `None` when the file does not exist.
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn load_optional(&self) -> Result<Option<T>> {
        read_optional_json(&self.path)
    }

    /// Attempt to create the marker file atomically.
    ///
    /// Returns `Ok(false)` when the file already exists.
    pub(crate) fn try_create_new(&self, value: &T) -> Result<bool> {
        let contents = serde_json::to_vec_pretty(value)
            .with_context(|| format!("failed to serialize `{}`", self.path.display()))?;
        persist_json_bytes(&self.path, &contents, JsonPersistMode::CreateNew)
    }

    /// Remove the marker when the stored payload matches the provided predicate.
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn remove_if<F>(&self, predicate: F) -> Result<bool>
    where
        F: FnOnce(&T) -> bool,
    {
        let Some(existing) = self.load_optional()? else {
            return Ok(false);
        };
        if !predicate(&existing) {
            return Ok(false);
        }

        match fs::remove_file(&self.path) {
            Ok(()) => Ok(true),
            Err(error) if error.kind() == ErrorKind::NotFound => Ok(false),
            Err(error) => {
                Err(error).with_context(|| format!("failed to remove `{}`", self.path.display()))
            }
        }
    }
}

/// Shared labeled summary field used by text and dashboard status rendering.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct SummaryField {
    pub(crate) label: &'static str,
    pub(crate) value: String,
}

impl SummaryField {
    /// Create a labeled summary field.
    pub(crate) fn new(label: &'static str, value: impl Into<String>) -> Self {
        Self {
            label,
            value: value.into(),
        }
    }
}

/// Add an optional labeled summary field when a value is present.
pub(crate) fn push_optional_summary_field<T>(
    fields: &mut Vec<SummaryField>,
    label: &'static str,
    value: Option<T>,
) where
    T: Into<String>,
{
    if let Some(value) = value {
        fields.push(SummaryField::new(label, value));
    }
}

/// Render aligned labeled summary fields into a text buffer.
#[cfg_attr(not(test), allow(dead_code))]
pub(crate) fn write_summary_fields(
    out: &mut impl fmt::Write,
    fields: &[SummaryField],
    label_width: usize,
) -> fmt::Result {
    for field in fields {
        let label = format!("{}:", field.label);
        if label.len() >= label_width {
            writeln!(out, "{label} {}", field.value)?;
            continue;
        }
        writeln!(out, "{label:<width$}{}", field.value, width = label_width)?;
    }
    Ok(())
}

/// Write a JSON file with contextual filesystem errors.
pub(crate) fn write_json<T>(path: &Path, value: &T) -> Result<()>
where
    T: Serialize,
{
    let contents = serde_json::to_vec_pretty(value)
        .with_context(|| format!("failed to serialize `{}`", path.display()))?;
    persist_json_bytes(path, &contents, JsonPersistMode::Replace)?;
    Ok(())
}

/// Read a required JSON file with contextual filesystem and decode errors.
pub(crate) fn read_json<T>(path: &Path) -> Result<T>
where
    T: DeserializeOwned,
{
    let contents =
        fs::read_to_string(path).with_context(|| format!("failed to read `{}`", path.display()))?;
    serde_json::from_str(&contents)
        .with_context(|| format!("failed to decode `{}`", path.display()))
}

/// Read an optional JSON file, returning `None` when the file does not exist.
pub(crate) fn read_optional_json<T>(path: &Path) -> Result<Option<T>>
where
    T: DeserializeOwned,
{
    match fs::read_to_string(path) {
        Ok(contents) => serde_json::from_str(&contents)
            .map(Some)
            .with_context(|| format!("failed to decode `{}`", path.display())),
        Err(error) if error.kind() == ErrorKind::NotFound => Ok(None),
        Err(error) => Err(error).with_context(|| format!("failed to read `{}`", path.display())),
    }
}

/// Read an optional JSON file, suppressing decode failures.
pub(crate) fn read_optional_json_lossy<T>(path: &Path) -> Result<Option<T>>
where
    T: DeserializeOwned,
{
    match read_optional_json(path) {
        Ok(value) => Ok(value),
        Err(_error) => Ok(None),
    }
}

/// Load every JSON record in a directory, skipping malformed entries with a warning.
#[cfg_attr(not(test), allow(dead_code))]
pub(crate) fn load_json_records<T>(
    dir: &Path,
    dir_label: &str,
    record_label: &str,
) -> Result<Vec<T>>
where
    T: DeserializeOwned,
{
    if !dir.exists() {
        return Ok(Vec::new());
    }

    let mut records = Vec::new();
    for entry in fs::read_dir(dir)
        .with_context(|| format!("failed to read {dir_label}: {}", dir.display()))?
    {
        let entry = entry
            .with_context(|| format!("failed to read {dir_label} entry: {}", dir.display()))?;
        let path = entry.path();
        if path.extension().is_some_and(|ext| ext == "json") {
            let content = fs::read_to_string(&path)
                .with_context(|| format!("failed to read {record_label}: {}", path.display()))?;
            match serde_json::from_str::<T>(&content) {
                Ok(record) => records.push(record),
                Err(err) => {
                    eprintln!(
                        "warning: skipping corrupted {record_label} at {}: {err}",
                        path.display()
                    );
                }
            }
        }
    }
    Ok(records)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum JsonPersistMode {
    Replace,
    CreateNew,
}

fn persist_json_bytes(path: &Path, contents: &[u8], mode: JsonPersistMode) -> Result<bool> {
    let directory = path.parent().unwrap_or_else(|| Path::new("."));
    fs::create_dir_all(directory)
        .with_context(|| format!("failed to create `{}`", directory.display()))?;

    let mut temp = json_tempfile(path, directory)?;
    temp.write_all(contents)
        .with_context(|| format!("failed to write temporary file for `{}`", path.display()))?;
    temp.as_file_mut()
        .sync_all()
        .with_context(|| format!("failed to sync temporary file for `{}`", path.display()))?;

    match mode {
        JsonPersistMode::Replace => {
            temp.persist(path)
                .map_err(|error| error.error)
                .with_context(|| format!("failed to persist `{}`", path.display()))?;
            Ok(true)
        }
        JsonPersistMode::CreateNew => match temp.persist_noclobber(path) {
            Ok(_) => Ok(true),
            Err(error) if error.error.kind() == ErrorKind::AlreadyExists => Ok(false),
            Err(error) => {
                Err(error.error).with_context(|| format!("failed to create `{}`", path.display()))
            }
        },
    }
}

fn json_tempfile(path: &Path, directory: &Path) -> Result<NamedTempFile> {
    let prefix = path
        .file_name()
        .and_then(OsStr::to_str)
        .filter(|name| !name.is_empty())
        .map(|name| format!("{name}."))
        .unwrap_or_else(|| "json.".to_string());
    Builder::new()
        .prefix(&prefix)
        .suffix(".tmp")
        .tempfile_in(directory)
        .with_context(|| {
            format!(
                "failed to create temporary file for `{}` in `{}`",
                path.display(),
                directory.display()
            )
        })
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde::{Deserialize, Serialize};
    #[cfg(unix)]
    use std::os::unix::fs::PermissionsExt;
    use tempfile::tempdir;

    #[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
    struct TestMarker {
        value: String,
    }

    #[test]
    fn workflow_layout_builds_expected_paths() {
        let workflow = WorkflowRootLayout::repo_scoped(
            Path::new("/tmp/example"),
            format!("{}/improve", crate::branding::PROJECT_DIR),
            "current.json",
        );
        let sessions = WorkflowSessionLayout::with_sessions_dir(workflow.clone(), "sessions");

        assert_eq!(
            workflow.root(),
            Path::new(&format!(
                "/tmp/example/{}/improve",
                crate::branding::PROJECT_DIR
            ))
        );
        assert_eq!(
            workflow.active_session_path(),
            Path::new(&format!(
                "/tmp/example/{}/improve/current.json",
                crate::branding::PROJECT_DIR
            ))
        );
        assert_eq!(
            sessions.sessions_dir(),
            Path::new(&format!(
                "/tmp/example/{}/improve/sessions",
                crate::branding::PROJECT_DIR
            ))
        );
        assert_eq!(
            sessions.session_dir("sess-1"),
            Path::new(&format!(
                "/tmp/example/{}/improve/sessions/sess-1",
                crate::branding::PROJECT_DIR
            ))
        );
        assert_eq!(
            sessions.workflow().active_session_path(),
            workflow.active_session_path()
        );
    }

    #[test]
    fn active_session_file_round_trips_and_clears() {
        let dir = tempdir().unwrap();
        let file = ActiveSessionFile::<TestMarker>::new(dir.path().join("active.json"));
        let marker = TestMarker {
            value: "lock".to_string(),
        };

        assert_eq!(file.path(), dir.path().join("active.json").as_path());
        file.store(&marker).unwrap();
        assert_eq!(file.load_optional().unwrap(), Some(marker.clone()));
        fs::remove_file(file.path()).unwrap();
        assert!(file.try_create_new(&marker).unwrap());
        assert!(!file.try_create_new(&marker).unwrap());
        assert_eq!(file.load_optional().unwrap(), Some(marker.clone()));
        assert!(file.remove_if(|existing| existing.value == "lock").unwrap());
        assert_eq!(file.load_optional().unwrap(), None);
    }

    #[test]
    fn active_session_file_create_new_preserves_existing_contents() {
        let dir = tempdir().unwrap();
        let file = ActiveSessionFile::<TestMarker>::new(dir.path().join("active.json"));
        let original = TestMarker {
            value: "original".to_string(),
        };
        let replacement = TestMarker {
            value: "replacement".to_string(),
        };

        file.store(&original).unwrap();
        assert!(!file.try_create_new(&replacement).unwrap());
        assert_eq!(file.load_optional().unwrap(), Some(original));
    }

    #[cfg(unix)]
    #[test]
    fn write_json_keeps_existing_file_readable_when_tempfile_creation_fails() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("state.json");
        let original = TestMarker {
            value: "stable".to_string(),
        };
        let replacement = TestMarker {
            value: "replacement".to_string(),
        };

        write_json(&path, &original).unwrap();

        let original_mode = fs::metadata(dir.path()).unwrap().permissions().mode();
        let mut read_only = fs::metadata(dir.path()).unwrap().permissions();
        read_only.set_mode(0o555);
        fs::set_permissions(dir.path(), read_only).unwrap();

        let error = write_json(&path, &replacement).expect_err("temp-file write should fail");

        let mut restored = fs::metadata(dir.path()).unwrap().permissions();
        restored.set_mode(original_mode);
        fs::set_permissions(dir.path(), restored).unwrap();

        assert!(
            error
                .to_string()
                .contains("failed to create temporary file")
        );
        assert_eq!(read_json::<TestMarker>(&path).unwrap(), original);
    }

    #[test]
    fn load_json_records_skips_corrupted_entries() {
        let dir = tempdir().unwrap();
        fs::write(dir.path().join("good.json"), "{\"value\":\"ok\"}").unwrap();
        fs::write(dir.path().join("bad.json"), "{ not valid json").unwrap();

        let records =
            load_json_records::<TestMarker>(dir.path(), "test records", "test record").unwrap();

        assert_eq!(
            records,
            vec![TestMarker {
                value: "ok".to_string()
            }]
        );
    }

    #[test]
    fn write_summary_fields_aligns_labels() {
        let mut out = String::new();
        let fields = vec![
            SummaryField::new("Short", "one"),
            SummaryField::new("Longer Label", "two"),
        ];

        write_summary_fields(&mut out, &fields, 14).unwrap();

        assert_eq!(out, "Short:        one\nLonger Label: two\n");
    }
}
