mod agent_provider;
mod agents;
mod backlog;
mod backlog_defaults;
mod backlog_improve;
mod backlog_spec;
pub mod branding;
mod build;
mod build_dashboard;
mod cli;
mod codebase_context;
mod config;
mod config_command;
mod config_resolution;
mod context;
mod cron;
mod cron_dashboard;
mod doctor;
mod fs;
mod github_pr;
mod improve;
mod linear;
mod listen;
mod managed_child;
mod merge;
mod merge_dashboard;
mod onboarding;
mod output;
mod plan;
mod progress;
mod repo_target;
mod review;
mod scaffold;
mod scan;
mod scan_dashboard;
mod scan_prompts;
mod session_runtime;
mod setup;
mod split;
mod sync_command;
mod sync_dashboard;
mod technical;
mod text_diff;
mod tui;
mod upgrade;
mod validation;
mod workflow_contract;
mod workflows;
mod workspace;
mod workspace_dashboard;
mod workspace_pressure;

use std::ffi::OsString;

use anyhow::{Result, bail};
use clap::Parser;
use clap::error::ErrorKind;

#[doc(hidden)]
pub use crate::backlog_improve::backlog_improve_terminal_cleanup_bytes;
use crate::backlog_improve::run_backlog_improve;
use crate::backlog_spec::{BacklogSpecOutput, run_backlog_spec};
use crate::build::run_build;
use crate::cli::{
    AgentsCommands, BacklogCommands, Cli, Command, ConfigEventArg, DashboardCommands,
    DashboardEventArg, IssueCreateEventArg, IssueEditEventArg, LinearCommands,
    ListenAssigneeScopeArg, MergeDashboardEventArg, RuntimeCommands, SpecEventArg, SyncCommands,
    SyncDashboardEventArg,
};
use crate::config::ListenAssignmentScope;
use crate::config_command::{ConfigAction, ConfigCommandOutput, run_config};
use crate::context::run_context_command;
use crate::cron::run_cron;
use crate::doctor::run_doctor;
use crate::improve::run_improve;
use crate::linear::create::IssueCreateAction;
use crate::linear::dashboard::DashboardAction;
use crate::linear::edit::IssueEditAction;
pub(crate) use crate::linear::{LinearCommandContext, load_linear_command_context};
use crate::linear::{run_dashboard_command, run_issues_command, run_projects_command};
use crate::listen::{
    run_execute, run_listen, run_listen_session_clear, run_listen_session_inspect,
    run_listen_session_list, run_listen_session_resume, run_listen_worker,
};
use crate::merge::run_merge;
use crate::merge_dashboard::MergeDashboardAction;
use crate::onboarding::{
    OnboardingLaunchMode, OnboardingOptions, OnboardingResult, run_onboarding,
};
use crate::output::{render_json_clap_error, render_json_error};
use crate::plan::run_plan;
use crate::review::{run_retro, run_review};
use crate::scaffold::run_scaffold;
use crate::scan::run_scan;
use crate::setup::run_setup;
use crate::split::run_split;
use crate::sync_command::{
    run_sync_dashboard_command, run_sync_link, run_sync_pull, run_sync_push, run_sync_status,
};
use crate::sync_dashboard::{SyncDashboardAction, SyncDashboardOptions};
use crate::technical::run_technical;
use crate::upgrade::run_upgrade;
use crate::workflows::run_workflows;
use crate::workspace::{run_workspace_clean, run_workspace_list, run_workspace_prune};

/// Run the MetaStack CLI with the current process arguments.
///
/// Returns the process exit code after rendering either human-readable output or structured
/// machine-readable error payloads.
pub async fn run() -> i32 {
    run_with_args(std::env::args_os()).await
}

/// Run the MetaStack CLI with an explicit argument iterator.
///
/// Returns the process exit code after rendering either human-readable output or structured
/// machine-readable error payloads.
pub async fn run_with_args<I, T>(args: I) -> i32
where
    I: IntoIterator<Item = T>,
    T: Into<OsString> + Clone,
{
    let argv = args.into_iter().map(Into::into).collect::<Vec<OsString>>();
    let inferred_machine_output_command = Cli::machine_output_command_from_argv(&argv);
    let cli = match Cli::try_parse_from(&argv) {
        Ok(cli) => cli,
        Err(error) => {
            if matches!(
                error.kind(),
                ErrorKind::DisplayHelp | ErrorKind::DisplayVersion
            ) {
                let _ = error.print();
            } else if let Some(command) = inferred_machine_output_command {
                println!("{}", render_json_clap_error(command, &error));
            } else {
                let _ = error.print();
            }
            return error.exit_code();
        }
    };
    let machine_output_command = cli.machine_output_command();

    match dispatch(cli).await {
        Ok(()) => 0,
        Err(error) => {
            if let Some(command) = machine_output_command {
                println!("{}", render_json_error(command, &error));
            } else {
                eprintln!("error: {error:#}");
            }
            1
        }
    }
}

async fn dispatch(cli: Cli) -> Result<()> {
    match maybe_run_onboarding(&cli).await? {
        Some(OnboardingResult::Completed) => {}
        Some(OnboardingResult::Rendered(output)) => {
            println!("{output}");
            return Ok(());
        }
        Some(OnboardingResult::Cancelled) => {
            println!("Onboarding cancelled.");
            return Ok(());
        }
        None => {}
    }

    match cli.command {
        Command::Backlog(args) => match args.command {
            BacklogCommands::Spec(args) => match run_backlog_spec(&args).await? {
                BacklogSpecOutput::Report(report) => println!("{}", report.render()),
                BacklogSpecOutput::Snapshot(snapshot) => println!("{snapshot}"),
            },
            BacklogCommands::Plan(args) => {
                let report = run_plan(&args).await?;
                if args.no_interactive {
                    println!("{}", report.render_json()?);
                } else {
                    println!("{}", report.render());
                }
            }
            BacklogCommands::Improve(args) => {
                run_backlog_improve(&args).await?;
            }
            BacklogCommands::Split(args) => {
                let report = run_split(&args).await?;
                if args.no_interactive {
                    println!("{}", report.render_json()?);
                } else {
                    println!("{}", report.render());
                }
            }
            BacklogCommands::Tech(args) => {
                let report = run_technical(&args).await?;
                if args.no_interactive {
                    println!("{}", report.render_json()?);
                } else {
                    println!("{}", report.render());
                }
            }
            BacklogCommands::Sync(args) => match args.command {
                Some(SyncCommands::Link(link_args)) => {
                    run_sync_link(
                        &args.client,
                        args.project.as_deref(),
                        args.no_interactive,
                        args.json || args.no_interactive,
                        &link_args,
                    )
                    .await?;
                }
                Some(SyncCommands::Status(status_args)) => {
                    run_sync_status(&args.client, args.json || args.no_interactive, &status_args)
                        .await?;
                }
                Some(SyncCommands::Pull(issue_args)) => {
                    run_sync_pull(&args.client, args.json || args.no_interactive, &issue_args)
                        .await?;
                }
                Some(SyncCommands::Push(issue_args)) => {
                    run_sync_push(&args.client, args.json || args.no_interactive, &issue_args)
                        .await?;
                }
                None => {
                    if args.no_interactive || args.json {
                        bail!(
                            "`{cmd} backlog sync` requires a subcommand such as `status`, `link`, `pull`, or `push` when `--no-interactive` or `--json` is used",
                            cmd = branding::COMMAND_NAME
                        );
                    }
                    run_sync_dashboard_command(
                        &args.client,
                        args.project.as_deref(),
                        SyncDashboardOptions {
                            render_once: args.render_once,
                            width: args.width,
                            height: args.height,
                            actions: args
                                .events
                                .into_iter()
                                .map(SyncDashboardAction::from)
                                .collect(),
                            vim_mode: crate::config::AppConfig::load()?.vim_mode_enabled(),
                        },
                    )
                    .await?;
                }
            },
        },
        Command::Agents(args) => match args.command {
            AgentsCommands::Execute(args) => {
                run_execute(&args).await?;
            }
            AgentsCommands::Listen(args) => match args.command {
                Some(crate::cli::ListenCommands::Sessions(session_args)) => {
                    match session_args.command {
                        crate::cli::ListenSessionCommands::List(list_args) => {
                            println!("{}", run_listen_session_list(&list_args)?);
                        }
                        crate::cli::ListenSessionCommands::Inspect(inspect_args) => {
                            println!("{}", run_listen_session_inspect(&inspect_args)?);
                        }
                        crate::cli::ListenSessionCommands::Clear(clear_args) => {
                            println!("{}", run_listen_session_clear(&clear_args)?);
                        }
                        crate::cli::ListenSessionCommands::Resume(resume_args) => {
                            run_listen_session_resume(&resume_args).await?;
                        }
                    }
                }
                None => {
                    run_listen(&args.run).await?;
                }
            },
            AgentsCommands::Review(args) => {
                run_review(&args).await?;
            }
            AgentsCommands::Retro(args) => {
                run_retro(&args).await?;
            }
            AgentsCommands::Improve(args) => {
                run_improve(&args).await?;
            }
            AgentsCommands::Build(args) => {
                run_build(&args).await?;
            }
            AgentsCommands::Workflows(args) => {
                println!("{}", run_workflows(&args).await?);
            }
        },
        Command::Linear(args) => {
            let client = args.client;
            let default_team = args.team;
            match args.command {
                LinearCommands::Projects(command) => {
                    run_projects_command(&client, default_team.clone(), command).await?;
                }
                LinearCommands::Issues(command) => {
                    run_issues_command(&client, default_team.clone(), command).await?;
                }
                LinearCommands::Dashboard(command) => {
                    run_dashboard_command(&client, default_team, command).await?;
                }
            }
        }
        Command::Context(args) => {
            println!("{}", run_context_command(&args)?);
        }
        Command::Runtime(args) => match args.command {
            RuntimeCommands::Config(args) => match run_config(&args).await? {
                ConfigCommandOutput::Text(output) | ConfigCommandOutput::Json(output) => {
                    println!("{output}");
                }
            },
            RuntimeCommands::Setup(args) => {
                println!("{}", run_setup(&args).await?);
            }
            RuntimeCommands::Cron(args) => {
                if let Some(output) = run_cron(&args)? {
                    println!("{output}");
                }
            }
        },
        Command::Dashboard(args) => match args.command {
            Some(DashboardCommands::Linear(args)) | Some(DashboardCommands::Team(args)) => {
                run_dashboard_command(&args.client, None, args.dashboard).await?;
            }
            Some(DashboardCommands::Agents(args)) => {
                run_listen(&args.listen).await?;
            }
            Some(DashboardCommands::Ops(args)) => match args.sync.command {
                Some(SyncCommands::Link(link_args)) => {
                    run_sync_link(
                        &args.sync.client,
                        args.sync.project.as_deref(),
                        args.sync.no_interactive,
                        args.sync.json || args.sync.no_interactive,
                        &link_args,
                    )
                    .await?;
                }
                Some(SyncCommands::Status(status_args)) => {
                    run_sync_status(
                        &args.sync.client,
                        args.sync.json || args.sync.no_interactive,
                        &status_args,
                    )
                    .await?;
                }
                Some(SyncCommands::Pull(issue_args)) => {
                    run_sync_pull(
                        &args.sync.client,
                        args.sync.json || args.sync.no_interactive,
                        &issue_args,
                    )
                    .await?;
                }
                Some(SyncCommands::Push(issue_args)) => {
                    run_sync_push(
                        &args.sync.client,
                        args.sync.json || args.sync.no_interactive,
                        &issue_args,
                    )
                    .await?;
                }
                None => {
                    if args.sync.no_interactive || args.sync.json {
                        bail!(
                            "`{cmd} dashboard ops` requires a subcommand such as `status`, `link`, `pull`, or `push` when `--no-interactive` or `--json` is used",
                            cmd = branding::COMMAND_NAME
                        );
                    }
                    run_sync_dashboard_command(
                        &args.sync.client,
                        args.sync.project.as_deref(),
                        SyncDashboardOptions {
                            render_once: args.sync.render_once,
                            width: args.sync.width,
                            height: args.sync.height,
                            actions: args
                                .sync
                                .events
                                .into_iter()
                                .map(SyncDashboardAction::from)
                                .collect(),
                            vim_mode: crate::config::AppConfig::load()?.vim_mode_enabled(),
                        },
                    )
                    .await?;
                }
            },
            None => {
                print_compatibility_hint("dashboard", "dashboard linear");
                run_dashboard_command(&args.legacy.client, None, args.legacy.dashboard).await?;
            }
        },
        Command::Merge(args) => {
            run_merge(&args).await?;
        }
        Command::Workspace(args) => match args.command {
            crate::cli::WorkspaceCommands::List(args) => {
                println!("{}", run_workspace_list(&args).await?);
            }
            crate::cli::WorkspaceCommands::Clean(args) => {
                println!("{}", run_workspace_clean(&args)?);
            }
            crate::cli::WorkspaceCommands::Prune(args) => {
                println!("{}", run_workspace_prune(&args).await?);
            }
        },
        Command::Upgrade(args) => {
            run_upgrade(&args).await?;
        }
        Command::Scaffold(args) => {
            let report = run_scaffold(&args)?;
            println!("{}", report.render());
        }
        Command::Cron(args) => {
            print_compatibility_hint("cron", "runtime cron");
            if let Some(output) = run_cron(&args)? {
                println!("{output}");
            }
        }
        Command::Scan(args) => {
            print_compatibility_hint("scan", "context scan");
            let report = run_scan(&args)?;
            if args.json {
                println!("{}", report.render_json()?);
            } else {
                println!("{}", report.render());
            }
        }
        Command::Workflows(args) => {
            print_compatibility_hint("workflows", "agents workflows");
            println!("{}", run_workflows(&args).await?);
        }
        Command::Plan(args) => {
            print_compatibility_hint("plan", "backlog plan");
            let report = run_plan(&args).await?;
            if args.no_interactive {
                println!("{}", report.render_json()?);
            } else {
                println!("{}", report.render());
            }
        }
        Command::Config(args) => {
            print_compatibility_hint("config", "runtime config");
            match run_config(&args).await? {
                ConfigCommandOutput::Text(output) | ConfigCommandOutput::Json(output) => {
                    println!("{output}");
                }
            }
        }
        Command::Setup(args) => {
            print_compatibility_hint("setup", "runtime setup");
            println!("{}", run_setup(&args).await?);
        }
        Command::Listen(args) => match args.command {
            Some(crate::cli::ListenCommands::Sessions(session_args)) => {
                print_compatibility_hint("listen", "agents listen");
                match session_args.command {
                    crate::cli::ListenSessionCommands::List(list_args) => {
                        println!("{}", run_listen_session_list(&list_args)?);
                    }
                    crate::cli::ListenSessionCommands::Inspect(inspect_args) => {
                        println!("{}", run_listen_session_inspect(&inspect_args)?);
                    }
                    crate::cli::ListenSessionCommands::Clear(clear_args) => {
                        println!("{}", run_listen_session_clear(&clear_args)?);
                    }
                    crate::cli::ListenSessionCommands::Resume(resume_args) => {
                        run_listen_session_resume(&resume_args).await?;
                    }
                }
            }
            None => {
                print_compatibility_hint("listen", "agents listen");
                run_listen(&args.run).await?;
            }
        },
        Command::Technical(args) => {
            print_compatibility_hint("technical", "backlog tech");
            let report = run_technical(&args).await?;
            if args.no_interactive {
                println!("{}", report.render_json()?);
            } else {
                println!("{}", report.render());
            }
        }
        Command::Sync(args) => match args.command {
            Some(SyncCommands::Link(link_args)) => {
                print_compatibility_hint("sync", "backlog sync");
                run_sync_link(
                    &args.client,
                    args.project.as_deref(),
                    args.no_interactive,
                    args.json || args.no_interactive,
                    &link_args,
                )
                .await?;
            }
            Some(SyncCommands::Status(status_args)) => {
                print_compatibility_hint("sync", "backlog sync");
                run_sync_status(&args.client, args.json || args.no_interactive, &status_args)
                    .await?;
            }
            Some(SyncCommands::Pull(issue_args)) => {
                print_compatibility_hint("sync", "backlog sync");
                run_sync_pull(&args.client, args.json || args.no_interactive, &issue_args).await?;
            }
            Some(SyncCommands::Push(issue_args)) => {
                print_compatibility_hint("sync", "backlog sync");
                run_sync_push(&args.client, args.json || args.no_interactive, &issue_args).await?;
            }
            None => {
                print_compatibility_hint("sync", "backlog sync");
                if args.no_interactive || args.json {
                    bail!(
                        "`{cmd} sync` requires a subcommand such as `status`, `link`, `pull`, or `push` when `--no-interactive` or `--json` is used",
                        cmd = branding::COMMAND_NAME
                    );
                }
                run_sync_dashboard_command(
                    &args.client,
                    args.project.as_deref(),
                    SyncDashboardOptions {
                        render_once: args.render_once,
                        width: args.width,
                        height: args.height,
                        actions: args
                            .events
                            .into_iter()
                            .map(SyncDashboardAction::from)
                            .collect(),
                        vim_mode: crate::config::AppConfig::load()?.vim_mode_enabled(),
                    },
                )
                .await?;
            }
        },
        Command::Doctor(args) => {
            run_doctor(&args).await?;
        }
        Command::ListenWorker(args) => {
            run_listen_worker(&args).await?;
        }
        Command::Projects(args) => {
            print_compatibility_hint("projects", "linear projects");
            run_projects_command(&args.client, None, args.command).await?;
        }
        Command::Issues(args) => {
            print_compatibility_hint("issues", "linear issues");
            run_issues_command(&args.client, None, args.command).await?;
        }
    }

    Ok(())
}

async fn maybe_run_onboarding(cli: &Cli) -> Result<Option<OnboardingResult>> {
    let app_config = crate::config::AppConfig::load()?;
    let replay = matches!(
        &cli.command,
        Command::Runtime(args)
            if matches!(
                &args.command,
                RuntimeCommands::Config(config_args) if config_args.replay_onboarding
            )
    ) || matches!(&cli.command, Command::Config(config_args) if config_args.replay_onboarding);

    if replay {
        return Ok(Some(
            run_onboarding(OnboardingOptions {
                mode: OnboardingLaunchMode::Replay,
                render_once: config_render_once(cli),
                width: config_snapshot_width(cli),
                height: config_snapshot_height(cli),
            })
            .await?,
        ));
    }

    if app_config.onboarding_complete() || command_bypasses_onboarding(cli) {
        return Ok(None);
    }

    Ok(Some(
        run_onboarding(OnboardingOptions {
            mode: OnboardingLaunchMode::Intercepted {
                command_label: command_label(cli),
            },
            render_once: false,
            width: 120,
            height: 32,
        })
        .await?,
    ))
}

fn command_bypasses_onboarding(cli: &Cli) -> bool {
    matches!(
        &cli.command,
        Command::Runtime(args) if matches!(&args.command, RuntimeCommands::Config(_))
    ) || matches!(
        &cli.command,
        Command::Config(_) | Command::Upgrade(_) | Command::Doctor(_)
    )
}

fn command_label(cli: &Cli) -> String {
    let cmd = branding::COMMAND_NAME;
    match &cli.command {
        Command::Backlog(_) => format!("{cmd} backlog"),
        Command::Agents(_) => format!("{cmd} agents"),
        Command::Linear(_) => format!("{cmd} linear"),
        Command::Context(_) => format!("{cmd} context"),
        Command::Runtime(_) => format!("{cmd} runtime"),
        Command::Dashboard(_) => format!("{cmd} dashboard"),
        Command::Merge(_) => format!("{cmd} merge"),
        Command::Workspace(_) => format!("{cmd} workspace"),
        Command::Plan(_) => format!("{cmd} plan"),
        Command::Technical(_) => format!("{cmd} technical"),
        Command::Listen(_) => format!("{cmd} listen"),
        Command::Issues(_) => format!("{cmd} issues"),
        Command::Projects(_) => format!("{cmd} projects"),
        Command::Cron(_) => format!("{cmd} cron"),
        Command::Scan(_) => format!("{cmd} scan"),
        Command::Workflows(_) => format!("{cmd} workflows"),
        Command::Config(_) => format!("{cmd} config"),
        Command::Setup(_) => format!("{cmd} setup"),
        Command::Sync(_) => format!("{cmd} sync"),
        Command::ListenWorker(_) => format!("{cmd} listen-worker"),
        Command::Scaffold(_) => format!("{cmd} scaffold"),
        Command::Upgrade(_) => format!("{cmd} upgrade"),
        Command::Doctor(_) => format!("{cmd} doctor"),
    }
}

#[cfg(test)]
#[test]
fn listen_review_prompt_calls_out_cross_actor_state_ownership_risks() {
    let (review_instructions, final_instructions, review_prompt, final_prompt) =
        crate::listen::review_prompt_hardening_probe();

    for rendered in [
        review_instructions.as_str(),
        final_instructions.as_str(),
        review_prompt.as_str(),
        final_prompt.as_str(),
    ] {
        assert!(rendered.contains("cross-actor state ownership"));
        assert!(rendered.contains("spawn-before-persist"));
        assert!(rendered.contains("whole-state rewrites"));
        assert!(rendered.contains("blocked metadata"));
        assert!(rendered.contains("canonical metadata"));
        assert!(rendered.contains("`turn_history`"));
        assert!(rendered.contains("`latest_resume_handle`"));
        assert!(rendered.contains("src/listen/mod.rs"));
        assert!(rendered.contains("src/listen/store.rs"));
        assert!(rendered.contains("src/listen/worker.rs"));
    }
}

fn config_render_once(cli: &Cli) -> bool {
    match &cli.command {
        Command::Config(args) => args.render_once,
        Command::Runtime(args) => match &args.command {
            RuntimeCommands::Config(config) => config.render_once,
            _ => false,
        },
        _ => false,
    }
}

fn config_snapshot_width(cli: &Cli) -> u16 {
    match &cli.command {
        Command::Config(args) => args.width,
        Command::Runtime(args) => match &args.command {
            RuntimeCommands::Config(config) => config.width,
            _ => 120,
        },
        _ => 120,
    }
}

fn config_snapshot_height(cli: &Cli) -> u16 {
    match &cli.command {
        Command::Config(args) => args.height,
        Command::Runtime(args) => match &args.command {
            RuntimeCommands::Config(config) => config.height,
            _ => 32,
        },
        _ => 32,
    }
}

fn print_compatibility_hint(legacy_sub: &str, preferred_sub: &str) {
    let cmd = branding::COMMAND_NAME;
    eprintln!(
        "hint: `{cmd} {legacy_sub}` is a compatibility alias; prefer `{cmd} {preferred_sub}`."
    );
}

impl From<DashboardEventArg> for DashboardAction {
    fn from(value: DashboardEventArg) -> Self {
        match value {
            DashboardEventArg::Up => DashboardAction::Up,
            DashboardEventArg::Down => DashboardAction::Down,
            DashboardEventArg::Tab => DashboardAction::Tab,
            DashboardEventArg::Enter => DashboardAction::Enter,
        }
    }
}

impl From<SyncDashboardEventArg> for SyncDashboardAction {
    fn from(value: SyncDashboardEventArg) -> Self {
        match value {
            SyncDashboardEventArg::Up => SyncDashboardAction::Up,
            SyncDashboardEventArg::Down => SyncDashboardAction::Down,
            SyncDashboardEventArg::Enter => SyncDashboardAction::Enter,
            SyncDashboardEventArg::Back => SyncDashboardAction::Back,
        }
    }
}

impl From<MergeDashboardEventArg> for MergeDashboardAction {
    fn from(value: MergeDashboardEventArg) -> Self {
        match value {
            MergeDashboardEventArg::Up => MergeDashboardAction::Up,
            MergeDashboardEventArg::Down => MergeDashboardAction::Down,
            MergeDashboardEventArg::Tab => MergeDashboardAction::Tab,
            MergeDashboardEventArg::PageUp => MergeDashboardAction::PageUp,
            MergeDashboardEventArg::PageDown => MergeDashboardAction::PageDown,
            MergeDashboardEventArg::Home => MergeDashboardAction::Home,
            MergeDashboardEventArg::End => MergeDashboardAction::End,
            MergeDashboardEventArg::Space => MergeDashboardAction::Toggle,
            MergeDashboardEventArg::Enter => MergeDashboardAction::Enter,
            MergeDashboardEventArg::Back => MergeDashboardAction::Back,
        }
    }
}

impl From<IssueCreateEventArg> for IssueCreateAction {
    fn from(value: IssueCreateEventArg) -> Self {
        match value {
            IssueCreateEventArg::Up => IssueCreateAction::Up,
            IssueCreateEventArg::Down => IssueCreateAction::Down,
            IssueCreateEventArg::Left => IssueCreateAction::Left,
            IssueCreateEventArg::Right => IssueCreateAction::Right,
            IssueCreateEventArg::Tab => IssueCreateAction::Tab,
            IssueCreateEventArg::BackTab => IssueCreateAction::BackTab,
            IssueCreateEventArg::Enter => IssueCreateAction::Enter,
            IssueCreateEventArg::Esc => IssueCreateAction::Esc,
        }
    }
}

impl From<IssueEditEventArg> for IssueEditAction {
    fn from(value: IssueEditEventArg) -> Self {
        match value {
            IssueEditEventArg::Up => IssueEditAction::Up,
            IssueEditEventArg::Down => IssueEditAction::Down,
            IssueEditEventArg::Left => IssueEditAction::Left,
            IssueEditEventArg::Right => IssueEditAction::Right,
            IssueEditEventArg::Tab => IssueEditAction::Tab,
            IssueEditEventArg::BackTab => IssueEditAction::BackTab,
            IssueEditEventArg::Enter => IssueEditAction::Enter,
            IssueEditEventArg::Esc => IssueEditAction::Esc,
        }
    }
}

impl From<ListenAssigneeScopeArg> for ListenAssignmentScope {
    fn from(value: ListenAssigneeScopeArg) -> Self {
        match value {
            ListenAssigneeScopeArg::Any => ListenAssignmentScope::Any,
            ListenAssigneeScopeArg::ViewerOnly => ListenAssignmentScope::ViewerOnly,
            ListenAssigneeScopeArg::ViewerOrUnassigned => ListenAssignmentScope::ViewerOrUnassigned,
        }
    }
}

impl From<ConfigEventArg> for ConfigAction {
    fn from(value: ConfigEventArg) -> Self {
        match value {
            ConfigEventArg::Up => ConfigAction::Up,
            ConfigEventArg::Down => ConfigAction::Down,
            ConfigEventArg::Tab => ConfigAction::Tab,
            ConfigEventArg::BackTab => ConfigAction::BackTab,
            ConfigEventArg::Enter => ConfigAction::Enter,
            ConfigEventArg::Esc => ConfigAction::Esc,
        }
    }
}

impl From<SpecEventArg> for crate::backlog_spec::SpecAction {
    fn from(value: SpecEventArg) -> Self {
        match value {
            SpecEventArg::Up => crate::backlog_spec::SpecAction::Up,
            SpecEventArg::Down => crate::backlog_spec::SpecAction::Down,
            SpecEventArg::Tab => crate::backlog_spec::SpecAction::Tab,
            SpecEventArg::Enter => crate::backlog_spec::SpecAction::Enter,
            SpecEventArg::Back => crate::backlog_spec::SpecAction::Back,
            SpecEventArg::Wait => crate::backlog_spec::SpecAction::Wait,
        }
    }
}
