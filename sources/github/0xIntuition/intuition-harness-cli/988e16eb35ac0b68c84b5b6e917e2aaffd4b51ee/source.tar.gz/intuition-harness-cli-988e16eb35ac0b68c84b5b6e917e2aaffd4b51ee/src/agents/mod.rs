mod brief;
pub(crate) mod execution;
pub(crate) mod resolution;

pub(crate) use execution::{
    AgentContinuation, AgentTokenUsage, run_agent_capture, run_agent_capture_with_continuation,
    run_agent_streaming_text_with_continuation,
};

pub(crate) use brief::{AgentBriefRequest, TicketMetadata, write_agent_brief};
pub(crate) use execution::{
    AgentExecutionOptions, apply_invocation_environment, apply_noninteractive_agent_environment,
};
pub(crate) use resolution::{
    command_args_for_invocation, command_args_for_invocation_with_options,
    format_agent_config_source, render_invocation_diagnostics,
    resolve_agent_invocation_for_planning, validate_invocation_command_surface,
};

#[cfg(test)]
mod tests {
    use std::collections::BTreeMap;
    use std::fs;
    use std::path::Path;
    use std::process::Command;

    use anyhow::{Context, Result, bail};
    use image::{ImageBuffer, Rgba};
    use serde::Deserialize;
    use tempfile::tempdir;

    use super::{
        AgentBriefRequest, TicketMetadata, command_args_for_invocation,
        resolve_agent_invocation_for_planning, write_agent_brief,
    };
    use crate::cli::{PromptTransportArg, RunAgentArgs};
    use crate::config::{
        AGENT_ROUTE_AGENTS_LISTEN, AgentCommandConfig, AgentSettings, AppConfig, PlanningMeta,
        PromptTransport,
    };
    use crate::fs::{PlanningPaths, canonicalize_existing_dir, ensure_dir};
    use crate::tui::prompt_images::PromptImageAttachment;

    #[test]
    fn write_agent_brief_references_codebase_paths_without_linear_description() -> Result<()> {
        let temp = tempdir()?;
        let root = temp.path();
        ensure_dir(&PlanningPaths::new(root).codebase_dir)?;

        let output = write_agent_brief(
            root,
            AgentBriefRequest {
                ticket: "ENG-10793".to_string(),
                title_override: Some("CLI Scaffolding & Modules".to_string()),
                goal: Some("Slim turn-1 onset artifacts.".to_string()),
                metadata: TicketMetadata {
                    description: Some(
                        "# Narrative\n\nKeep prompt surfaces small.\n\n## Validation\n\n- `cargo test`\n"
                            .to_string(),
                    ),
                    ..TicketMetadata::default()
                },
                output: None,
            },
        )?;

        let brief = fs::read_to_string(output)?;
        assert!(brief.contains("# Agent Kickoff: ENG-10793"));
        assert!(brief.contains("CLI Scaffolding & Modules"));
        assert!(brief.contains("## Codebase Context"));
        assert!(brief.contains(&format!(
            "`{}/codebase/SCAN.md`",
            crate::branding::PROJECT_DIR
        )));
        assert!(brief.contains(&format!(
            "`{}/codebase/TESTING.md`",
            crate::branding::PROJECT_DIR
        )));
        assert!(!brief.contains("## Linear Description"));
        assert!(!brief.contains("_Missing"));

        Ok(())
    }

    #[test]
    fn write_agent_brief_preserves_verbatim_inline_ticket_sections() -> Result<()> {
        let temp = tempdir()?;
        let root = temp.path();
        ensure_dir(&PlanningPaths::new(root).codebase_dir)?;

        let output = write_agent_brief(
            root,
            AgentBriefRequest {
                ticket: "ENG-10793".to_string(),
                title_override: Some("Inline sections".to_string()),
                goal: Some("Keep exact inline ticket sections.".to_string()),
                metadata: TicketMetadata {
                    description: Some(
                        "# Technical cleanup\n\nCompact the brief.\n\n## aCcEpTaNcE cRiTeRiA\n\n- [ ] First bullet stays first\n- [ ] Second bullet stays second\n\n## TEST PLAN\n\n### Focused pass\n\n- `cargo test --lib`\n\n## vALidAtIoN\n\n### Lint\n\n- `cargo clippy --all-targets --all-features -- -D warnings`\n"
                            .to_string(),
                    ),
                    ..TicketMetadata::default()
                },
                output: None,
            },
        )?;

        let brief = fs::read_to_string(output)?;
        assert!(brief.contains("## aCcEpTaNcE cRiTeRiA\n\n- [ ] First bullet stays first\n- [ ] Second bullet stays second"));
        assert!(brief.contains("## TEST PLAN\n\n### Focused pass\n\n- `cargo test --lib`"));
        assert!(brief.contains(
            "## vALidAtIoN\n\n### Lint\n\n- `cargo clippy --all-targets --all-features -- -D warnings`"
        ));

        Ok(())
    }

    #[derive(Debug, Deserialize)]
    struct TurnOneFixture {
        description: String,
        brief_max: usize,
    }

    #[test]
    fn write_agent_brief_fixture_byte_budgets_hold_for_required_cases() -> Result<()> {
        for fixture_name in [
            "small-happy-path",
            "large-narrative",
            "validation-heavy",
            "attachment-heavy",
            "discussion-heavy",
        ] {
            let fixture = load_turn_one_fixture(fixture_name)?;
            let temp = tempdir()?;
            let root = temp.path();
            ensure_dir(&PlanningPaths::new(root).codebase_dir)?;

            let output = write_agent_brief(
                root,
                AgentBriefRequest {
                    ticket: "ENG-10793".to_string(),
                    title_override: Some(format!("Fixture {fixture_name}")),
                    goal: Some("Ticket fixture budget check.".to_string()),
                    metadata: TicketMetadata {
                        description: Some(fixture.description),
                        ..TicketMetadata::default()
                    },
                    output: None,
                },
            )?;

            let brief = fs::read_to_string(output)?;
            assert!(
                brief.len() <= fixture.brief_max,
                "{fixture_name} brief exceeded budget: {} > {}",
                brief.len(),
                fixture.brief_max
            );
            assert!(!brief.contains("## Linear Description"), "{fixture_name}");
            assert!(!brief.contains("_Missing"), "{fixture_name}");
        }

        Ok(())
    }

    fn load_turn_one_fixture(name: &str) -> Result<TurnOneFixture> {
        let path = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("tests/fixtures/listen/turn-one")
            .join(format!("{name}.json"));
        let contents = fs::read_to_string(&path)
            .with_context(|| format!("failed to read fixture `{}`", path.display()))?;
        serde_json::from_str(&contents)
            .with_context(|| format!("failed to parse fixture `{}`", path.display()))
    }

    #[test]
    fn resolve_agent_invocation_uses_configured_default_agent_command() -> Result<()> {
        let mut commands = BTreeMap::new();
        commands.insert(
            "capture".to_string(),
            AgentCommandConfig {
                command: "capture-agent".to_string(),
                args: vec!["{{payload}}".to_string()],
                transport: PromptTransport::Stdin,
            },
        );
        let config = AppConfig {
            agents: AgentSettings {
                default_agent: Some("capture".to_string()),
                default_model: Some("gpt-5".to_string()),
                default_reasoning: None,
                routing: Default::default(),
                commands,
            },
            ..AppConfig::default()
        };

        let invocation = resolve_agent_invocation_for_planning(
            &config,
            &PlanningMeta::default(),
            &RunAgentArgs {
                root: None,
                route_key: None,
                agent: None,
                prompt: "Investigate config loading".to_string(),
                instructions: Some("Reply with a plan".to_string()),
                model: None,
                reasoning: None,
                transport: None,
                attachments: Vec::new(),
            },
        )?;

        assert_eq!(invocation.agent, "capture");
        assert_eq!(invocation.command, "capture-agent");
        assert_eq!(invocation.args, vec![invocation.payload.clone()]);
        assert_eq!(invocation.model.as_deref(), Some("gpt-5"));
        assert_eq!(invocation.transport, PromptTransport::Stdin);
        assert!(invocation.payload.contains("Investigate config loading"));
        assert!(invocation.payload.contains("Reply with a plan"));
        assert!(invocation.payload.contains("gpt-5"));

        Ok(())
    }

    #[test]
    fn resolve_agent_invocation_supports_builtin_codex_preset() -> Result<()> {
        let config = AppConfig {
            agents: AgentSettings {
                default_agent: None,
                default_model: Some("gpt-5.3-codex".to_string()),
                default_reasoning: None,
                routing: Default::default(),
                commands: BTreeMap::new(),
            },
            ..AppConfig::default()
        };

        let invocation = resolve_agent_invocation_for_planning(
            &config,
            &PlanningMeta::default(),
            &RunAgentArgs {
                root: None,
                route_key: None,
                agent: Some("codex".to_string()),
                prompt: "Ship setup flow".to_string(),
                instructions: Some("Use concise output".to_string()),
                model: None,
                reasoning: None,
                transport: None,
                attachments: Vec::new(),
            },
        )?;

        assert_eq!(invocation.command, "codex");
        assert_eq!(invocation.args[0], "exec");
        assert_eq!(invocation.args[1], "--model=gpt-5.3-codex");
        assert_eq!(invocation.transport, PromptTransport::Stdin);
        assert_eq!(invocation.args.len(), 2);
        assert!(invocation.payload.contains("Ship setup flow"));
        assert!(invocation.payload.contains("Use concise output"));

        Ok(())
    }

    #[test]
    fn builtin_codex_execution_adds_workspace_write_flags_for_workspace_clones() -> Result<()> {
        let temp = tempdir()?;
        let repo_root = temp.path().join("repo");
        let workspace_root = temp.path().join("workspace").join("MET-1");
        fs::create_dir_all(&repo_root)?;
        fs::create_dir_all(
            workspace_root
                .parent()
                .expect("workspace parent should exist"),
        )?;

        run_git(&repo_root, &["init", "-b", "main"])?;
        run_git(&repo_root, &["config", "user.email", "codex@example.com"])?;
        run_git(&repo_root, &["config", "user.name", "Codex Tests"])?;
        fs::write(repo_root.join("README.md"), "# Demo\n")?;
        run_git(&repo_root, &["add", "README.md"])?;
        run_git(&repo_root, &["commit", "-m", "init"])?;
        let remote_root = temp.path().join("origin.git");
        run_git(
            temp.path(),
            &[
                "init",
                "--bare",
                remote_root
                    .to_str()
                    .expect("remote path should be valid utf-8"),
            ],
        )?;
        run_git(
            &repo_root,
            &[
                "remote",
                "add",
                "origin",
                remote_root
                    .to_str()
                    .expect("remote path should be valid utf-8"),
            ],
        )?;
        run_git(&repo_root, &["push", "-u", "origin", "main"])?;
        run_git(
            temp.path(),
            &[
                "clone",
                remote_root
                    .to_str()
                    .expect("remote path should be valid utf-8"),
                workspace_root
                    .to_str()
                    .expect("workspace path should be valid utf-8"),
            ],
        )?;

        let config = AppConfig {
            agents: AgentSettings {
                default_agent: None,
                default_model: Some("gpt-5.3-codex".to_string()),
                default_reasoning: None,
                routing: Default::default(),
                commands: BTreeMap::new(),
            },
            ..AppConfig::default()
        };
        let invocation = resolve_agent_invocation_for_planning(
            &config,
            &PlanningMeta::default(),
            &RunAgentArgs {
                root: None,
                route_key: None,
                agent: Some("codex".to_string()),
                prompt: "Ship setup flow".to_string(),
                instructions: None,
                model: None,
                reasoning: None,
                transport: None,
                attachments: Vec::new(),
            },
        )?;

        let command_args = command_args_for_invocation(&invocation, Some(&workspace_root))?;
        let git_dir = git_stdout(
            &workspace_root,
            &["rev-parse", "--path-format=absolute", "--git-dir"],
        )?;
        let git_common_dir = git_stdout(
            &workspace_root,
            &["rev-parse", "--path-format=absolute", "--git-common-dir"],
        )?;

        assert_eq!(command_args[0], "--sandbox");
        assert_eq!(command_args[1], "workspace-write");
        assert_eq!(command_args[2], "--ask-for-approval");
        assert_eq!(command_args[3], "never");
        assert_eq!(command_args[4], "--cd");
        assert_eq!(
            command_args[5],
            canonicalize_existing_dir(&workspace_root)?
                .display()
                .to_string()
        );
        assert!(
            command_args
                .windows(2)
                .any(|pair| { pair[0] == "--add-dir" && pair[1] == git_dir })
        );
        assert!(
            command_args
                .windows(2)
                .any(|pair| { pair[0] == "--add-dir" && pair[1] == git_common_dir })
        );
        assert!(command_args.iter().any(|arg| arg == "exec"));

        Ok(())
    }

    #[test]
    fn builtin_codex_execution_uses_config_override_for_reasoning() -> Result<()> {
        let config = AppConfig {
            agents: AgentSettings {
                default_agent: None,
                default_model: Some("gpt-5.4".to_string()),
                default_reasoning: Some("medium".to_string()),
                routing: Default::default(),
                commands: BTreeMap::new(),
            },
            ..AppConfig::default()
        };
        let invocation = resolve_agent_invocation_for_planning(
            &config,
            &PlanningMeta::default(),
            &RunAgentArgs {
                root: None,
                route_key: None,
                agent: Some("codex".to_string()),
                prompt: "Ship setup flow".to_string(),
                instructions: None,
                model: None,
                reasoning: None,
                transport: None,
                attachments: Vec::new(),
            },
        )?;

        assert_eq!(invocation.args[0], "exec");
        assert_eq!(invocation.args[1], "--model=gpt-5.4");
        assert_eq!(invocation.args[2], "-c");
        assert_eq!(invocation.args[3], "reasoning.effort=\"medium\"");

        Ok(())
    }

    #[test]
    fn builtin_codex_execution_omits_reasoning_override_when_unset() -> Result<()> {
        let config = AppConfig {
            agents: AgentSettings {
                default_agent: None,
                default_model: Some("gpt-5.4".to_string()),
                default_reasoning: None,
                routing: Default::default(),
                commands: BTreeMap::new(),
            },
            ..AppConfig::default()
        };
        let invocation = resolve_agent_invocation_for_planning(
            &config,
            &PlanningMeta::default(),
            &RunAgentArgs {
                root: None,
                route_key: None,
                agent: Some("codex".to_string()),
                prompt: "Ship setup flow".to_string(),
                instructions: None,
                model: None,
                reasoning: None,
                transport: None,
                attachments: Vec::new(),
            },
        )?;

        assert_eq!(invocation.args[0], "exec");
        assert_eq!(invocation.args[1], "--model=gpt-5.4");
        assert!(!invocation.args.iter().any(|arg| arg == "-c"));
        assert!(
            !invocation
                .args
                .iter()
                .any(|arg| arg.starts_with("reasoning.effort="))
        );

        Ok(())
    }

    #[test]
    fn builtin_codex_listen_execution_uses_unrestricted_permissions() -> Result<()> {
        let temp = tempdir()?;
        let repo_root = temp.path().join("repo");
        fs::create_dir_all(&repo_root)?;
        run_git(&repo_root, &["init", "-b", "main"])?;

        let config = AppConfig {
            agents: AgentSettings {
                default_agent: None,
                default_model: Some("gpt-5.4".to_string()),
                default_reasoning: Some("high".to_string()),
                routing: Default::default(),
                commands: BTreeMap::new(),
            },
            ..AppConfig::default()
        };
        let invocation = resolve_agent_invocation_for_planning(
            &config,
            &PlanningMeta::default(),
            &RunAgentArgs {
                root: None,
                route_key: Some(AGENT_ROUTE_AGENTS_LISTEN.to_string()),
                agent: Some("codex".to_string()),
                prompt: "Ship setup flow".to_string(),
                instructions: None,
                model: None,
                reasoning: None,
                transport: None,
                attachments: Vec::new(),
            },
        )?;

        let command_args = command_args_for_invocation(&invocation, Some(&repo_root))?;
        assert_eq!(
            command_args[0],
            "--dangerously-bypass-approvals-and-sandbox"
        );
        assert!(command_args.iter().any(|arg| arg == "--cd"));
        assert!(!command_args.iter().any(|arg| arg == "--sandbox"));
        assert!(!command_args.iter().any(|arg| arg == "--ask-for-approval"));

        Ok(())
    }

    #[test]
    fn resolve_agent_invocation_supports_builtin_claude_preset() -> Result<()> {
        let config = AppConfig {
            agents: AgentSettings {
                default_agent: None,
                default_model: Some("sonnet".to_string()),
                default_reasoning: None,
                routing: Default::default(),
                commands: BTreeMap::new(),
            },
            ..AppConfig::default()
        };

        let invocation = resolve_agent_invocation_for_planning(
            &config,
            &PlanningMeta::default(),
            &RunAgentArgs {
                root: None,
                route_key: None,
                agent: Some("claude".to_string()),
                prompt: "Draft the review summary".to_string(),
                instructions: None,
                model: None,
                reasoning: None,
                transport: None,
                attachments: Vec::new(),
            },
        )?;

        assert_eq!(invocation.command, "claude");
        assert_eq!(invocation.args[0], "-p");
        assert_eq!(invocation.args[1], "--model=sonnet");
        assert_eq!(invocation.transport, PromptTransport::Stdin);
        assert_eq!(invocation.args.len(), 2);
        assert!(invocation.payload.contains("Draft the review summary"));

        Ok(())
    }

    #[test]
    fn builtin_transport_override_to_arg_still_wins() -> Result<()> {
        let config = AppConfig {
            agents: AgentSettings {
                default_agent: None,
                default_model: Some("gpt-5.4".to_string()),
                default_reasoning: None,
                routing: Default::default(),
                commands: BTreeMap::new(),
            },
            ..AppConfig::default()
        };

        let invocation = resolve_agent_invocation_for_planning(
            &config,
            &PlanningMeta::default(),
            &RunAgentArgs {
                root: None,
                route_key: None,
                agent: Some("codex".to_string()),
                prompt: "Ship setup flow".to_string(),
                instructions: Some("Use concise output".to_string()),
                model: None,
                reasoning: None,
                transport: Some(PromptTransportArg::Arg),
                attachments: Vec::new(),
            },
        )?;

        assert_eq!(invocation.transport, PromptTransport::Arg);
        assert_eq!(invocation.args[0], "exec");
        assert_eq!(invocation.args[1], "--model=gpt-5.4");
        assert!(
            invocation
                .args
                .last()
                .is_some_and(|arg| arg.contains("Ship setup flow"))
        );

        Ok(())
    }

    #[test]
    fn builtin_claude_execution_adds_effort_when_reasoning_is_configured() -> Result<()> {
        let config = AppConfig {
            agents: AgentSettings {
                default_agent: None,
                default_model: Some("sonnet".to_string()),
                default_reasoning: Some("max".to_string()),
                routing: Default::default(),
                commands: BTreeMap::new(),
            },
            ..AppConfig::default()
        };
        let invocation = resolve_agent_invocation_for_planning(
            &config,
            &PlanningMeta::default(),
            &RunAgentArgs {
                root: None,
                route_key: None,
                agent: Some("claude".to_string()),
                prompt: "Draft the review summary".to_string(),
                instructions: None,
                model: None,
                reasoning: None,
                transport: None,
                attachments: Vec::new(),
            },
        )?;

        assert_eq!(invocation.args[0], "-p");
        assert_eq!(invocation.args[1], "--model=sonnet");
        assert_eq!(invocation.args[2], "--effort=max");

        Ok(())
    }

    #[test]
    fn builtin_claude_execution_omits_effort_when_reasoning_is_unset() -> Result<()> {
        let config = AppConfig {
            agents: AgentSettings {
                default_agent: None,
                default_model: Some("sonnet".to_string()),
                default_reasoning: None,
                routing: Default::default(),
                commands: BTreeMap::new(),
            },
            ..AppConfig::default()
        };
        let invocation = resolve_agent_invocation_for_planning(
            &config,
            &PlanningMeta::default(),
            &RunAgentArgs {
                root: None,
                route_key: None,
                agent: Some("claude".to_string()),
                prompt: "Draft the review summary".to_string(),
                instructions: None,
                model: None,
                reasoning: None,
                transport: None,
                attachments: Vec::new(),
            },
        )?;

        assert_eq!(invocation.args[0], "-p");
        assert_eq!(invocation.args[1], "--model=sonnet");
        assert!(
            !invocation
                .args
                .iter()
                .any(|arg| arg.starts_with("--effort="))
        );

        Ok(())
    }

    #[test]
    fn builtin_claude_listen_execution_bypasses_permissions() -> Result<()> {
        let config = AppConfig {
            agents: AgentSettings {
                default_agent: None,
                default_model: Some("sonnet".to_string()),
                default_reasoning: Some("high".to_string()),
                routing: Default::default(),
                commands: BTreeMap::new(),
            },
            ..AppConfig::default()
        };
        let invocation = resolve_agent_invocation_for_planning(
            &config,
            &PlanningMeta::default(),
            &RunAgentArgs {
                root: None,
                route_key: Some(AGENT_ROUTE_AGENTS_LISTEN.to_string()),
                agent: Some("claude".to_string()),
                prompt: "Draft the review summary".to_string(),
                instructions: None,
                model: None,
                reasoning: None,
                transport: None,
                attachments: Vec::new(),
            },
        )?;

        let command_args = command_args_for_invocation(&invocation, None)?;
        assert_eq!(command_args[0], "--permission-mode=bypassPermissions");
        assert!(command_args.iter().any(|arg| arg == "--effort=high"));

        Ok(())
    }

    #[test]
    fn builtin_codex_invocation_embeds_prompt_image_payload() -> Result<()> {
        let temp = tempdir()?;
        let image_path = temp.path().join("diagram.png");
        ImageBuffer::<Rgba<u8>, Vec<u8>>::from_pixel(2, 2, Rgba([1, 2, 3, 255]))
            .save(&image_path)?;

        let config = AppConfig {
            agents: AgentSettings {
                default_agent: None,
                default_model: Some("gpt-5.4".to_string()),
                default_reasoning: None,
                routing: Default::default(),
                commands: BTreeMap::new(),
            },
            ..AppConfig::default()
        };
        let invocation = resolve_agent_invocation_for_planning(
            &config,
            &PlanningMeta::default(),
            &RunAgentArgs {
                root: None,
                route_key: None,
                agent: Some("codex".to_string()),
                prompt: "Review this mockup".to_string(),
                instructions: None,
                model: None,
                reasoning: None,
                transport: None,
                attachments: vec![PromptImageAttachment {
                    original_path: image_path.clone(),
                    stored_path: image_path,
                    display_name: "diagram.png".to_string(),
                }],
            },
        )?;

        assert!(invocation.payload.contains("Prompt image attachments"));
        assert!(invocation.payload.contains("[Image #1]"));
        assert!(invocation.payload.contains("base64:"));

        Ok(())
    }

    #[test]
    fn custom_agents_fail_fast_when_prompt_images_are_attached() {
        let mut commands = BTreeMap::new();
        commands.insert(
            "capture".to_string(),
            AgentCommandConfig {
                command: "capture-agent".to_string(),
                args: vec!["{{payload}}".to_string()],
                transport: PromptTransport::Stdin,
            },
        );
        let config = AppConfig {
            agents: AgentSettings {
                default_agent: Some("capture".to_string()),
                default_model: None,
                default_reasoning: None,
                routing: Default::default(),
                commands,
            },
            ..AppConfig::default()
        };

        let error = resolve_agent_invocation_for_planning(
            &config,
            &PlanningMeta::default(),
            &RunAgentArgs {
                root: None,
                route_key: None,
                agent: None,
                prompt: "Review this mockup".to_string(),
                instructions: None,
                model: None,
                reasoning: None,
                transport: None,
                attachments: vec![PromptImageAttachment {
                    original_path: Path::new("/tmp/mock.png").to_path_buf(),
                    stored_path: Path::new("/tmp/mock.png").to_path_buf(),
                    display_name: "mock.png".to_string(),
                }],
            },
        )
        .expect_err("custom agent attachments should be rejected");

        assert!(
            error
                .to_string()
                .contains("does not support prompt image attachments")
        );
    }

    fn run_git(root: &Path, args: &[&str]) -> Result<()> {
        let status = Command::new("git")
            .arg("-C")
            .arg(root)
            .args(args)
            .status()
            .with_context(|| format!("failed to run `git {}`", args.join(" ")))?;
        if !status.success() {
            bail!("git {} failed", args.join(" "));
        }

        Ok(())
    }

    fn git_stdout(root: &Path, args: &[&str]) -> Result<String> {
        let output = Command::new("git")
            .arg("-C")
            .arg(root)
            .args(args)
            .output()
            .with_context(|| format!("failed to run `git {}`", args.join(" ")))?;
        if !output.status.success() {
            bail!(
                "git {} failed: {}",
                args.join(" "),
                String::from_utf8_lossy(&output.stderr).trim()
            );
        }

        Ok(String::from_utf8_lossy(&output.stdout).trim().to_string())
    }
}
