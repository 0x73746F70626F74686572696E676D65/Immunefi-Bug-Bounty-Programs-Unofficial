pub mod dashboard;
mod preflight;
mod state;
pub(crate) mod store;
mod verification;
mod worker;
mod worker_lease;
mod workpad;
mod workspace;

#[cfg(test)]
pub(crate) use worker::review_prompt_hardening_probe;

use std::collections::{BTreeSet, HashMap};
use std::env;
use std::ffi::OsString;
use std::fs;
use std::future::Future;
use std::io::{self, BufRead, BufReader};
use std::path::{Path, PathBuf};
use std::pin::Pin;
use std::process::{Child, Command, Stdio};
use std::thread;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use anyhow::{Context, Result, anyhow, bail};
use crossterm::event::{Event, EventStream, KeyCode, KeyEventKind, KeyModifiers};
use crossterm::execute;
use crossterm::terminal::{
    EnterAlternateScreen, LeaveAlternateScreen, disable_raw_mode, enable_raw_mode,
};
use futures::StreamExt;
use ratatui::Terminal;
use ratatui::backend::CrosstermBackend;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use walkdir::WalkDir;

use crate::agents::{
    AgentBriefRequest, TicketMetadata, command_args_for_invocation, render_invocation_diagnostics,
    resolve_agent_invocation_for_planning, validate_invocation_command_surface, write_agent_brief,
};
use crate::backlog::{
    BacklogIssueMetadata, INDEX_FILE_NAME, ManagedFileRecord, TICKET_DISCUSSION_FILE_NAME,
    TemplateContext, render_template_files, save_issue_metadata, write_issue_description,
};
use crate::cli::{
    ListenDashboardEventArg, ListenRunArgs, ListenSessionClearArgs, ListenSessionInspectArgs,
    ListenSessionListArgs, ListenSessionResumeArgs, ListenWorkerArgs, RunAgentArgs,
};
use crate::config::{
    AGENT_ROUTE_AGENTS_LISTEN_VERIFICATION, AppConfig, DEFAULT_SYNC_DISCUSSION_PROMPT_CHAR_LIMIT,
    LinearConfig, LinearConfigOverrides, ListenAssignmentScope, PlanningListenSettings,
    PlanningMeta, load_required_planning_meta,
};
use crate::fs::{
    PlanningPaths, canonicalize_existing_dir, display_path, sibling_workspace_root,
    ticket_workspace_root,
};
use crate::linear::{
    IssueAssigneeFilter, IssueComment, IssueEditSpec, IssueListFilters, IssueSummary, LinearClient,
    LinearService, ReqwestLinearClient, UserRef, classify_linear_failure,
};
use crate::listen::workpad::{extract_requirements, render_bootstrap_workpad};
use crate::listen::workspace::{TicketWorkspace, ensure_ticket_workspace};
use crate::output::render_json_success;
use crate::scaffold::ensure_planning_layout;
use crate::tui::copy::copy_overlay_viewport;
use crate::tui::keybindings::is_copy_key;
use crate::validation::resolve_validation_profile;
use crate::workspace::{AutoCleanOutcome, try_auto_clean_workspace};
use crate::workspace_pressure;
pub use state::{
    ActiveIssue, AgentSession, BlockedCategory, BlockedReason, CanonicalSessionData,
    LatestResumeHandle, LinearFailureSnapshot, PendingIssue, PendingLinearSync,
    PendingPullRequestAttachment, PullRequestStatus, PullRequestSummary, ResumeProvider,
    SessionExitCondition, SessionLifecycle, SessionLifecycleOutcome, SessionOrigin, SessionPhase,
    SessionTimeoutRecord, SessionTimeoutTermination, StaleWorkerFailure, TokenUsage,
    TurnPromptMode, TurnTokenSnapshot,
};
use state::{
    COMPLETED_SESSION_TTL_SECONDS, ListenState, derive_session_lifecycle, explicit_resume_id_label,
    explicit_resume_provider_label,
};
use store::{
    ListenProjectStore, ListenSessionDetail, RetainedSessionSummary, SessionSelector,
    StoredListenProjectSummary, pid_is_running, resolve_source_project_root,
};
use verification::{VerificationStatus, VerificationSummary};

const TODO_STATE: &str = "Todo";
const BACKLOG_STATE: &str = "Backlog";
const IN_PROGRESS_STATE: &str = "In Progress";
const ISSUE_ATTACHMENT_CONTEXT_FILES_DIR: &str = "files";
const DEFAULT_LISTEN_MAX_TURNS: u32 = 20;
const MAX_STALLED_TURNS: u32 = 2;
const MAX_STALE_WORKER_RECOVERY_ATTEMPTS: u32 = 2;
const TURN_ONE_DISCUSSION_MAX_EXCERPTS: usize = 3;
const TURN_ONE_DISCUSSION_MAX_CHARS: usize = 1_200;
const TURN_ONE_DESCRIPTION_SUMMARY_MAX_CHARS: usize = 1_800;
const TERMINAL_REFRESH_INTERVAL_SECONDS: u64 = 1;
const DEMO_NOW_EPOCH_SECONDS: u64 = 1_773_575_600;
const DEMO_START_EPOCH_SECONDS: u64 = DEMO_NOW_EPOCH_SECONDS - 7_351;
const REVIEW_STATE_CANDIDATES: &[&str] =
    &["Human Review", "In Review", "Review", "Ready for Review"];
const WORKER_LEASE_STARTUP_TIMEOUT: Duration = Duration::from_secs(5);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ListenWorkerSpawnReason {
    Pickup,
    Resume,
    StaleRecovery,
    Execute,
}

impl ListenWorkerSpawnReason {
    fn label(self) -> &'static str {
        match self {
            Self::Pickup => "pickup",
            Self::Resume => "resume",
            Self::StaleRecovery => "stale_recovery",
            Self::Execute => "execute",
        }
    }
}
#[derive(Debug, Clone, Serialize)]
pub struct ListenDashboardData {
    pub title: String,
    pub scope: String,
    pub watch_scope: String,
    pub cycle_summary: String,
    pub vim_mode: bool,
    pub runtime: ListenRuntimeSummary,
    pub pending_issues: Vec<PendingIssue>,
    pub active_issues: Vec<ActiveIssue>,
    pub sessions: Vec<AgentSession>,
    pub session_details: HashMap<String, ListenSessionDetail>,
    pub notes: Vec<String>,
    pub state_file: String,
    pub degraded: Option<LinearFailureSnapshot>,
    pub show_active_issues: bool,
    pub show_preview: bool,
    #[serde(skip_serializing)]
    pub resolved_agent: Option<String>,
}

impl ListenDashboardData {
    pub fn render_summary(&self) -> String {
        let mut lines = vec![
            self.title.clone(),
            self.cycle_summary.clone(),
            format!("Agents: {}", self.runtime.agents),
            format!(
                "Execution agent: {}",
                self.resolved_agent.as_deref().unwrap_or("unresolved")
            ),
            format!("Throughput: {}", self.runtime.throughput),
            format!("Runtime: {}", self.runtime.runtime),
            format!("Tokens: {}", self.runtime.tokens),
            format!("Rate Limits: {}", self.runtime.rate_limits),
            format!("Linear status: {}", self.runtime.linear_status),
            format!("Project: {}", self.runtime.project),
            format!("Watching: {}", self.watch_scope),
            format!("Dashboard: {}", self.runtime.dashboard),
            format!("Terminal refresh: {}", self.runtime.dashboard_refresh),
            format!("Linear refresh: {}", self.runtime.linear_refresh),
            format!("State file: {}", self.state_file),
        ];

        if !self.notes.is_empty() {
            lines.push("Notes:".to_string());
            for note in &self.notes {
                lines.push(format!("  - {note}"));
            }
        }

        if !self.sessions.is_empty() {
            lines.push("Sessions:".to_string());
            for session in &self.sessions {
                let origin_tag = if session.origin.is_execute() {
                    " (execute-origin)"
                } else {
                    ""
                };
                lines.push(format!(
                    "  - {} [{}]{} {}",
                    session.issue_identifier,
                    session.stage_label(),
                    origin_tag,
                    session.summary
                ));
            }
        }

        lines.join("\n")
    }

    pub(crate) fn session_counts(&self) -> SessionListCounts {
        SessionListCounts::from_sessions(&self.sessions)
    }

    pub(crate) fn sessions_for_view(&self, view: SessionListView) -> Vec<&AgentSession> {
        self.sessions
            .iter()
            .filter(|session| match view {
                SessionListView::Active => {
                    !session.is_blocked_session() && !session.shows_in_completed_view()
                }
                SessionListView::Blocked => session.is_blocked_session(),
                SessionListView::Completed => session.shows_in_completed_view(),
            })
            .collect()
    }

    pub(crate) fn detail_for_session(
        &self,
        issue_identifier: &str,
    ) -> Option<&ListenSessionDetail> {
        self.session_details.get(issue_identifier)
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct ListenRuntimeSummary {
    pub agents: String,
    pub throughput: String,
    pub runtime: String,
    pub tokens: String,
    pub rate_limits: String,
    pub linear_status: String,
    pub project: String,
    pub dashboard: String,
    pub dashboard_refresh: String,
    pub linear_refresh: String,
    pub current_epoch_seconds: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub(crate) enum SessionListView {
    #[default]
    Active,
    Blocked,
    Completed,
}

impl SessionListView {
    pub(crate) fn label(self) -> &'static str {
        match self {
            Self::Active => "Active",
            Self::Blocked => "Blocked",
            Self::Completed => "Completed",
        }
    }

    pub(crate) fn toggle(self) -> Self {
        match self {
            Self::Active => Self::Blocked,
            Self::Blocked => Self::Completed,
            Self::Completed => Self::Active,
        }
    }
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub(crate) struct SessionListCounts {
    pub active: usize,
    pub blocked: usize,
    pub completed: usize,
}

impl SessionListCounts {
    fn from_sessions(sessions: &[AgentSession]) -> Self {
        sessions
            .iter()
            .fold(Self::default(), |mut counts, session| {
                if session.shows_in_completed_view() {
                    counts.completed += 1;
                } else if session.is_blocked_session() {
                    counts.blocked += 1;
                } else {
                    counts.active += 1;
                }
                counts
            })
    }
}

#[derive(Debug, Clone)]
struct ListenCycleData {
    scope: String,
    watch_scope: String,
    claimed_this_cycle: usize,
    pending_issues: Vec<PendingIssue>,
    active_issues: Vec<ActiveIssue>,
    sessions: Vec<AgentSession>,
    session_details: HashMap<String, ListenSessionDetail>,
    notes: Vec<String>,
    state_file: String,
    rate_limits: Option<String>,
    degraded: Option<LinearFailureSnapshot>,
}

impl ListenCycleData {
    fn loading(scope: String, watch_scope: String, state_file: String) -> Self {
        Self {
            scope,
            watch_scope,
            claimed_this_cycle: 0,
            pending_issues: Vec::new(),
            active_issues: Vec::new(),
            sessions: Vec::new(),
            session_details: HashMap::new(),
            notes: vec![
                "Starting dashboard before the first Linear refresh completes.".to_string(),
                "Refreshing current Todo issues, listener sessions, and workspace state now."
                    .to_string(),
            ],
            state_file,
            rate_limits: None,
            degraded: None,
        }
    }

    fn demo(root: &Path, state_file: String) -> Self {
        Self::demo_at(root, DEMO_NOW_EPOCH_SECONDS, state_file)
    }

    fn demo_at(root: &Path, reference_now: u64, state_file: String) -> Self {
        let mut notes = vec![
            "Demo mode: no Linear requests were made.".to_string(),
            "The live terminal dashboard adapts to the full viewport.".to_string(),
            format!("State file: {state_file}"),
        ];
        if let Ok(summary) = workspace_pressure::assess_workspace_pressure(root) {
            notes.extend(summary.summary_lines());
        }

        Self {
            scope: "MET / MetaStack CLI".to_string(),
            watch_scope: "all assignees".to_string(),
            claimed_this_cycle: 1,
            pending_issues: vec![PendingIssue {
                identifier: "MET-18".to_string(),
                title: "Dashboard filter polish".to_string(),
                project: Some("MetaStack CLI".to_string()),
                team_key: "MET".to_string(),
            }],
            active_issues: vec![
                ActiveIssue {
                    identifier: "MET-22".to_string(),
                    title: "Integrate backlog sync with cron scheduler".to_string(),
                    assignee: Some("Alice Chen".to_string()),
                    state_name: "In Progress".to_string(),
                    has_open_pr: true,
                    pr_url: Some(
                        "https://github.com/metastack-labs/metastack-cli/pull/45".to_string(),
                    ),
                    description: Some(
                        "Wire the backlog sync polling into the cron scheduler so recurring refreshes happen automatically.\n\nAcceptance criteria:\n- Cron job triggers backlog sync at the configured interval\n- Sync results appear in the dashboard notes\n- Manual sync still works independently"
                            .to_string(),
                    ),
                    url: "https://linear.app/metastack-backlog/issue/MET-22/integrate-backlog-sync"
                        .to_string(),
                    team_key: "MET".to_string(),
                    project: Some("MetaStack CLI".to_string()),
                },
                ActiveIssue {
                    identifier: "MET-25".to_string(),
                    title: "Add workspace prune dry-run mode".to_string(),
                    assignee: Some("Bob Taylor".to_string()),
                    state_name: "In Progress".to_string(),
                    has_open_pr: false,
                    pr_url: None,
                    description: Some(
                        format!(
                            "Add a --dry-run flag to `{} workspace prune` that lists what would be deleted without actually removing anything.",
                            crate::branding::COMMAND_NAME
                        ),
                    ),
                    url: "https://linear.app/metastack-backlog/issue/MET-25/workspace-prune-dry-run"
                        .to_string(),
                    team_key: "MET".to_string(),
                    project: Some("MetaStack CLI".to_string()),
                },
                ActiveIssue {
                    identifier: "MET-30".to_string(),
                    title: "Config migration for deprecated listen fields".to_string(),
                    assignee: None,
                    state_name: "In Progress".to_string(),
                    has_open_pr: false,
                    pr_url: None,
                    description: None,
                    url: "https://linear.app/metastack-backlog/issue/MET-30/config-migration"
                        .to_string(),
                    team_key: "MET".to_string(),
                    project: Some("MetaStack CLI".to_string()),
                },
            ],
            sessions: vec![
                AgentSession {
                    issue_id: Some("019cedb422937651b0b4dfac4af6a640".to_string()),
                    issue_identifier: "MET-13".to_string(),
                    issue_title: "Agent Daemon".to_string(),
                    project_name: Some("MetaStack CLI".to_string()),
                    team_key: "MET".to_string(),
                    issue_url: "https://linear.app/metastack-backlog/issue/MET-13/agent-daemon"
                        .to_string(),
                    phase: SessionPhase::BriefReady,
                    lifecycle: None,
                    summary: "Brief ready | backlog MET-14 | worker active".to_string(),
                    blocked: None,
                    brief_path: Some(format!("{}/agents/briefs/MET-13.md", crate::branding::PROJECT_DIR)),
                    backlog_issue_identifier: Some("MET-14".to_string()),
                    backlog_issue_title: Some("Technical: Agent Daemon".to_string()),
                    backlog_path: Some(format!("{}/backlog/MET-14", crate::branding::PROJECT_DIR)),
                    workspace_path: Some("/tmp/metastack-cli-workspace/MET-13".to_string()),
                    branch: Some("met-13-agent-daemon".to_string()),
                    pull_request: PullRequestSummary {
                        number: Some(321),
                        url: Some(
                            "https://github.com/metastack-labs/metastack-cli/pull/321".to_string(),
                        ),
                        status: PullRequestStatus::Draft,
                    },
                    workpad_comment_id: Some("comment-met-13".to_string()),
                    started_at_epoch_seconds: reference_now - 2_940,
                    updated_at_epoch_seconds: reference_now - 1_180,
                    pid: Some(95_388),
                    session_id: Some("019cedb422937651b0b4dfac4af6a640".to_string()),
                    latest_resume_handle: Some(LatestResumeHandle {
                        provider: ResumeProvider::Codex,
                        id: (
                            "019cedb4-2293-7651-b0b4-dfac4af6a640-019cedb4-229b-7453-825e-3e3da4e1bf2a"
                        )
                            .to_string(),
                    }),
                    context_budget_tokens: Some(crate::config::DEFAULT_LISTEN_CONTEXT_BUDGET_TOKENS),
                    pending_linear_sync: None,
                    stale_worker_recovery_attempt_count: 0,
                    latest_stale_worker_failure: None,
                    last_timeout: None,
                    turns: Some(1),
                    tokens: TokenUsage {
                        input: Some(9_614_112),
                        output: Some(8_120),
                    },
                    turn_history: Vec::new(),
                    canonical: CanonicalSessionData {
                        provider: Some("codex".to_string()),
                        model: Some("gpt-5.4".to_string()),
                        reasoning: Some("high".to_string()),
                        tokens: TokenUsage {
                            input: Some(9_614_112),
                            output: Some(8_120),
                        },
                        repair: None,
                    },
                    log_path: Some(format!("{}/agents/sessions/MET-13.log", crate::branding::PROJECT_DIR)),
                    origin: SessionOrigin::Listen,
                },
                AgentSession {
                    issue_id: Some("019ceda50a417ef1bf964f26683c1570".to_string()),
                    issue_identifier: "MET-17".to_string(),
                    issue_title: "Branch PR reconciliation".to_string(),
                    project_name: Some("MetaStack CLI".to_string()),
                    team_key: "MET".to_string(),
                    issue_url: "https://linear.app/metastack-backlog/issue/MET-17/branch-pr-reconciliation"
                        .to_string(),
                    phase: SessionPhase::Claimed,
                    lifecycle: None,
                    summary: "Claimed | preparing workspace".to_string(),
                    blocked: None,
                    brief_path: None,
                    backlog_issue_identifier: None,
                    backlog_issue_title: None,
                    backlog_path: None,
                    workspace_path: Some("/tmp/metastack-cli-workspace/MET-17".to_string()),
                    branch: Some("met-17-branch-pr-reconciliation".to_string()),
                    pull_request: PullRequestSummary::default(),
                    workpad_comment_id: None,
                    started_at_epoch_seconds: reference_now - 2_940,
                    updated_at_epoch_seconds: reference_now - 2_940,
                    pid: Some(96_104),
                    session_id: Some("019ceda50a417ef1bf964f26683c1570".to_string()),
                    latest_resume_handle: Some(LatestResumeHandle {
                        provider: ResumeProvider::Claude,
                        id: (
                            "019ceda5-0a41-7ef1-bf96-4f26683c1570-019ceda5-0a57-7820-b050-c05e112d66dd"
                        )
                            .to_string(),
                    }),
                    context_budget_tokens: Some(crate::config::DEFAULT_LISTEN_CONTEXT_BUDGET_TOKENS),
                    pending_linear_sync: None,
                    stale_worker_recovery_attempt_count: 0,
                    latest_stale_worker_failure: None,
                    last_timeout: None,
                    turns: Some(1),
                    tokens: TokenUsage {
                        input: Some(8_380_959),
                        output: Some(49_960),
                    },
                    turn_history: Vec::new(),
                    canonical: CanonicalSessionData {
                        provider: Some("claude".to_string()),
                        model: Some("sonnet".to_string()),
                        reasoning: Some("high".to_string()),
                        tokens: TokenUsage {
                            input: Some(8_380_959),
                            output: Some(49_960),
                        },
                        repair: None,
                    },
                    log_path: Some(format!("{}/agents/sessions/MET-17.log", crate::branding::PROJECT_DIR)),
                    origin: state::SessionOrigin::Execute,
                },
            ],
            session_details: demo_session_details(reference_now),
            notes,
            state_file,
            rate_limits: Some(
                "codex | primary 12% / reset 1,773,515,901s | secondary 8% / reset 1,773,855,871s | credits n/a".to_string(),
            ),
            degraded: None,
        }
    }

    fn apply_state_snapshot(
        &mut self,
        state: ListenState,
        sessions: Vec<AgentSession>,
        session_details: HashMap<String, ListenSessionDetail>,
    ) {
        let replace_linear_snapshot = !state.pending_issues.is_empty()
            || !state.active_issues.is_empty()
            || state.degraded.is_some()
            || (self.pending_issues.is_empty()
                && self.active_issues.is_empty()
                && self.degraded.is_none());
        if replace_linear_snapshot {
            self.pending_issues = state.pending_issues.clone();
            self.active_issues = state.active_issues.clone();
            self.degraded = state.degraded.clone();
        }
        self.sessions = sessions;
        self.session_details = session_details;
    }
}

fn merge_visible_sessions(
    live_sessions: Vec<AgentSession>,
    retained_sessions: Vec<RetainedSessionSummary>,
) -> Vec<AgentSession> {
    let mut merged = live_sessions.clone();
    let live_identifiers = live_sessions
        .iter()
        .map(|session| session.issue_identifier.to_ascii_lowercase())
        .collect::<BTreeSet<_>>();
    for retained in retained_sessions {
        if live_identifiers.contains(&retained.session.issue_identifier.to_ascii_lowercase()) {
            continue;
        }
        merged.push(retained.session);
    }
    merged.sort_by(|left, right| {
        right
            .updated_at_epoch_seconds
            .cmp(&left.updated_at_epoch_seconds)
            .then_with(|| left.issue_identifier.cmp(&right.issue_identifier))
    });
    merged
}

fn load_visible_session_details(
    store: &ListenProjectStore,
    app_config: &AppConfig,
    live_sessions: &[AgentSession],
    visible_sessions: &[AgentSession],
) -> Result<HashMap<String, ListenSessionDetail>> {
    let mut details = store
        .load_session_details(app_config, live_sessions)?
        .into_iter()
        .map(|detail| (detail.issue_identifier.clone(), detail))
        .collect::<HashMap<_, _>>();
    for session in visible_sessions {
        if details.contains_key(&session.issue_identifier) {
            continue;
        }
        if let Some(detail) = store.load_retained_session_detail(&session.issue_identifier)? {
            details.insert(session.issue_identifier.clone(), detail);
        }
    }
    Ok(details)
}

fn demo_session_details(reference_now: u64) -> HashMap<String, ListenSessionDetail> {
    HashMap::from([
        (
            "MET-13".to_string(),
            ListenSessionDetail {
                version: 1,
                issue_identifier: "MET-13".to_string(),
                issue_title: "Agent Daemon".to_string(),
                started_at_epoch_seconds: reference_now - 2_940,
                updated_at_epoch_seconds: reference_now - 120,
                session_updated_at_epoch_seconds: reference_now - 1_180,
                phase: SessionPhase::BriefReady,
                lifecycle: None,
                summary: "Brief ready | backlog MET-14 | worker active".to_string(),
                blocked: None,
                turns: Some(1),
                tokens: TokenUsage {
                    input: Some(9_614_112),
                    output: Some(8_120),
                },
                turn_history: vec![TurnTokenSnapshot {
                    turn: 1,
                    prompt_mode: TurnPromptMode::FullPrompt,
                    tokens: TokenUsage {
                        input: Some(9_614_112),
                        output: Some(8_120),
                    },
                    captured_at_epoch_seconds: reference_now - 1_180,
                }],
                context_budget_tokens: Some(crate::config::DEFAULT_LISTEN_CONTEXT_BUDGET_TOKENS),
                canonical: CanonicalSessionData {
                    provider: Some("codex".to_string()),
                    model: Some("gpt-5.4".to_string()),
                    reasoning: Some("high".to_string()),
                    tokens: TokenUsage {
                        input: Some(9_614_112),
                        output: Some(8_120),
                    },
                    repair: None,
                },
                pull_request: PullRequestSummary {
                    number: Some(321),
                    url: Some("https://github.com/metastack-labs/metastack-cli/pull/321".to_string()),
                    status: PullRequestStatus::Draft,
                },
                verification: Some(VerificationSummary {
                    status: VerificationStatus::Passed,
                    summary: "Verification passed for code review, E2E, and battle tests."
                        .to_string(),
                    criteria_total: 3,
                    criteria_failed: 0,
                    e2e_status: VerificationStatus::Passed,
                    battle_test_status: VerificationStatus::Passed,
                    remediation: Vec::new(),
                }),
                latest_resume_handle: Some(LatestResumeHandle {
                    provider: ResumeProvider::Codex,
                    id: "019cedb4-2293-7651-b0b4-dfac4af6a640-019cedb4-229b-7453-825e-3e3da4e1bf2a"
                        .to_string(),
                }),
                pending_linear_sync: None,
                stale_worker_recovery_attempt_count: 0,
                latest_stale_worker_failure: None,
                last_timeout: None,
                references: store::SessionDetailReferences {
                    workspace_path: Some("/tmp/metastack-cli-workspace/MET-13".to_string()),
                    backlog_path: Some(format!("{}/backlog/MET-14", crate::branding::PROJECT_DIR)),
                    brief_path: Some(format!("{}/agents/briefs/MET-13.md", crate::branding::PROJECT_DIR)),
                    workpad_comment_id: Some("comment-met-13".to_string()),
                    log_path: Some(format!("{}/agents/sessions/MET-13.log", crate::branding::PROJECT_DIR)),
                    branch: Some("met-13-agent-daemon".to_string()),
                    verification_json_path: Some(format!(
                        "{}/agents/listen/verification/MET-13.json",
                        crate::branding::PROJECT_DIR
                    )),
                    verification_markdown_path: Some(format!(
                        "{}/agents/listen/verification/MET-13.md",
                        crate::branding::PROJECT_DIR
                    )),
                },
                prompt_context: vec![
                    store::SessionContextReference {
                        label: "Brief".to_string(),
                        value: format!("{}/agents/briefs/MET-13.md", crate::branding::PROJECT_DIR),
                    },
                    store::SessionContextReference {
                        label: "Backlog index".to_string(),
                        value: format!("{}/backlog/MET-14/index.md", crate::branding::PROJECT_DIR),
                    },
                    store::SessionContextReference {
                        label: "Attachment context manifest".to_string(),
                        value: format!("{}/agents/issue-context/MET-13/README.md", crate::branding::PROJECT_DIR),
                    },
                ],
                milestones: vec![
                    store::SessionMilestone {
                        at_epoch_seconds: reference_now - 2_940,
                        phase: SessionPhase::Claimed,
                        lifecycle: None,
                        summary: "Picked up from Todo | local backlog ready | workpad created | worker pid 95388".to_string(),
                        turns: Some(0),
                        pull_request_status: PullRequestStatus::Unpublished,
                        pull_request_number: None,
                    },
                    store::SessionMilestone {
                        at_epoch_seconds: reference_now - 1_180,
                        phase: SessionPhase::BriefReady,
                        lifecycle: None,
                        summary: "Brief ready | backlog MET-14 | worker active".to_string(),
                        turns: Some(1),
                        pull_request_status: PullRequestStatus::Draft,
                        pull_request_number: Some(321),
                    },
                ],
                log_excerpts: vec![
                    store::SessionLogExcerpt {
                        line_number: 18,
                        text: "thread.started: 019cedb4-2293-7651-b0b4-dfac4af6a640".to_string(),
                    },
                    store::SessionLogExcerpt {
                        line_number: 31,
                        text: "Updated local backlog files for MET-14".to_string(),
                    },
                    store::SessionLogExcerpt {
                        line_number: 44,
                        text: "Published draft PR #321 for review visibility".to_string(),
                    },
                ],
            },
        ),
        (
            "MET-17".to_string(),
            ListenSessionDetail {
                version: 1,
                issue_identifier: "MET-17".to_string(),
                issue_title: "Branch PR reconciliation".to_string(),
                started_at_epoch_seconds: reference_now - 2_940,
                updated_at_epoch_seconds: reference_now - 120,
                session_updated_at_epoch_seconds: reference_now - 2_940,
                phase: SessionPhase::Claimed,
                lifecycle: None,
                summary: "Claimed | preparing workspace".to_string(),
                blocked: None,
                turns: Some(1),
                tokens: TokenUsage {
                    input: Some(8_380_959),
                    output: Some(49_960),
                },
                turn_history: vec![TurnTokenSnapshot {
                    turn: 1,
                    prompt_mode: TurnPromptMode::FullPrompt,
                    tokens: TokenUsage {
                        input: Some(8_380_959),
                        output: Some(49_960),
                    },
                    captured_at_epoch_seconds: reference_now - 2_940,
                }],
                context_budget_tokens: Some(crate::config::DEFAULT_LISTEN_CONTEXT_BUDGET_TOKENS),
                canonical: CanonicalSessionData {
                    provider: Some("claude".to_string()),
                    model: Some("sonnet".to_string()),
                    reasoning: Some("high".to_string()),
                    tokens: TokenUsage {
                        input: Some(8_380_959),
                        output: Some(49_960),
                    },
                    repair: None,
                },
                pull_request: PullRequestSummary::default(),
                verification: None,
                latest_resume_handle: Some(LatestResumeHandle {
                    provider: ResumeProvider::Claude,
                    id: "019ceda5-0a41-7ef1-bf96-4f26683c1570-019ceda5-0a57-7820-b050-c05e112d66dd"
                        .to_string(),
                }),
                pending_linear_sync: None,
                stale_worker_recovery_attempt_count: 0,
                latest_stale_worker_failure: None,
                last_timeout: None,
                references: store::SessionDetailReferences {
                    workspace_path: Some("/tmp/metastack-cli-workspace/MET-17".to_string()),
                    backlog_path: None,
                    brief_path: None,
                    workpad_comment_id: None,
                    log_path: Some(format!("{}/agents/sessions/MET-17.log", crate::branding::PROJECT_DIR)),
                    branch: Some("met-17-branch-pr-reconciliation".to_string()),
                    verification_json_path: None,
                    verification_markdown_path: None,
                },
                prompt_context: vec![store::SessionContextReference {
                    label: "Attachment context manifest".to_string(),
                    value: format!("{}/agents/issue-context/MET-17/README.md", crate::branding::PROJECT_DIR),
                }],
                milestones: vec![store::SessionMilestone {
                    at_epoch_seconds: reference_now - 2_940,
                    phase: SessionPhase::Claimed,
                    lifecycle: None,
                    summary: "Claimed | preparing workspace".to_string(),
                    turns: Some(1),
                    pull_request_status: PullRequestStatus::Unpublished,
                    pull_request_number: None,
                }],
                log_excerpts: vec![store::SessionLogExcerpt {
                    line_number: 6,
                    text: "Preparing workspace clone and workpad bootstrap".to_string(),
                }],
            },
        ),
    ])
}

#[derive(Debug, Clone)]
struct DashboardRuntimeContext {
    started_at_epoch_seconds: u64,
    now_epoch_seconds: u64,
    poll_interval_seconds: u64,
    dashboard_label: &'static str,
    dashboard_refresh_seconds: u64,
    linear_refresh_seconds: u64,
    vim_mode: bool,
    show_active_issues: bool,
    show_preview: bool,
    resolved_agent: Option<String>,
}

struct ListenLoopConfig {
    poll_interval_seconds: u64,
    started_at_epoch_seconds: u64,
    refresh_immediately: bool,
    vim_mode: bool,
    show_active_issues: bool,
    show_preview: bool,
    resolved_agent: Option<String>,
}

#[derive(Debug, Clone, Default)]
struct BranchPullRequestLookup {
    cache: HashMap<String, BranchPullRequestLookupResult>,
}

#[derive(Debug, Clone)]
enum BranchPullRequestLookupResult {
    Available(Vec<BranchPullRequestRecord>),
    Unavailable(String),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum BranchPullRequestState {
    Open,
    Closed,
    Merged,
    Other,
}

impl BranchPullRequestState {
    fn is_merged(self) -> bool {
        matches!(self, Self::Merged)
    }
}

#[derive(Debug, Clone, Deserialize)]
struct BranchPullRequestRecord {
    #[serde(rename = "headRefName")]
    head_ref_name: String,
    #[serde(rename = "headRefOid")]
    head_ref_oid: Option<String>,
    state: String,
}

#[derive(Debug, Default)]
struct CodexLiveTokenHydrator {
    sessions_root: Option<PathBuf>,
    snapshots: HashMap<String, CodexSessionSnapshot>,
}

#[derive(Debug, Clone)]
struct CodexSessionSnapshot {
    path: PathBuf,
    file_len: u64,
    usage: Option<TokenUsage>,
}

impl CodexLiveTokenHydrator {
    fn new() -> Self {
        Self {
            sessions_root: env::var_os("HOME")
                .map(PathBuf::from)
                .map(|home| home.join(".codex").join("sessions"))
                .filter(|path| path.is_dir()),
            snapshots: HashMap::new(),
        }
    }

    fn refresh_sessions(&mut self, sessions: &mut [AgentSession]) -> Result<()> {
        for session in sessions
            .iter_mut()
            .filter(|session| !session.shows_in_completed_view())
        {
            let Some(thread_id) = self.resolve_thread_id(session)? else {
                continue;
            };
            if let Some(usage) = self.load_usage(&thread_id)? {
                session.tokens.accumulate(&usage);
            }
        }

        Ok(())
    }

    fn resolve_thread_id(&mut self, session: &AgentSession) -> Result<Option<String>> {
        if let Some(candidate) = session
            .latest_resume_handle
            .as_ref()
            .filter(|resume| resume.provider == ResumeProvider::Codex)
            .map(|resume| resume.id.as_str())
            && self.session_file_path(candidate)?.is_some()
        {
            return Ok(Some(candidate.to_string()));
        }

        let Some(log_path) = session.log_path.as_deref() else {
            return Ok(None);
        };
        let thread_id = parse_codex_thread_id_from_log(Path::new(log_path))?;
        if let Some(thread_id) = thread_id.as_deref()
            && self.session_file_path(thread_id)?.is_none()
        {
            return Ok(None);
        }
        Ok(thread_id)
    }

    fn load_usage(&mut self, thread_id: &str) -> Result<Option<TokenUsage>> {
        let Some(path) = self.session_file_path(thread_id)? else {
            return Ok(None);
        };
        let metadata = fs::metadata(&path)
            .with_context(|| format!("failed to read `{}` metadata", path.display()))?;
        let file_len = metadata.len();

        if let Some(snapshot) = self.snapshots.get(thread_id)
            && snapshot.file_len == file_len
        {
            return Ok(snapshot.usage.clone());
        }

        let usage = parse_codex_token_usage_from_session_file(&path)?;
        self.snapshots.insert(
            thread_id.to_string(),
            CodexSessionSnapshot {
                path,
                file_len,
                usage: usage.clone(),
            },
        );
        Ok(usage)
    }

    fn session_file_path(&mut self, thread_id: &str) -> Result<Option<PathBuf>> {
        if let Some(snapshot) = self.snapshots.get(thread_id)
            && snapshot.path.is_file()
        {
            return Ok(Some(snapshot.path.clone()));
        }

        let Some(root) = self.sessions_root.as_deref() else {
            return Ok(None);
        };
        for entry in WalkDir::new(root).min_depth(1).max_depth(4) {
            let entry = entry.with_context(|| {
                format!(
                    "failed to scan Codex session files under `{}`",
                    root.display()
                )
            })?;
            if !entry.file_type().is_file() {
                continue;
            }
            if entry.file_name().to_string_lossy().contains(thread_id) {
                let path = entry.into_path();
                self.snapshots
                    .entry(thread_id.to_string())
                    .or_insert(CodexSessionSnapshot {
                        path: path.clone(),
                        file_len: 0,
                        usage: None,
                    });
                return Ok(Some(path));
            }
        }

        Ok(None)
    }
}

fn parse_codex_thread_id_from_log(path: &Path) -> Result<Option<String>> {
    if !path.is_file() {
        return Ok(None);
    }

    let file =
        fs::File::open(path).with_context(|| format!("failed to open `{}`", path.display()))?;
    let mut latest = None;
    for line in BufReader::new(file).lines() {
        let line = line.with_context(|| format!("failed to read `{}`", path.display()))?;
        let Ok(value) = serde_json::from_str::<Value>(&line) else {
            continue;
        };
        match value.get("type").and_then(Value::as_str) {
            Some("thread.started") => {
                latest = value
                    .get("thread_id")
                    .and_then(Value::as_str)
                    .map(str::to_string);
            }
            Some("thread/started") => {
                latest = value
                    .get("params")
                    .and_then(|params| {
                        params
                            .get("thread_id")
                            .or_else(|| params.get("threadId"))
                            .or_else(|| params.get("id"))
                    })
                    .and_then(Value::as_str)
                    .map(str::to_string)
                    .or(latest);
            }
            _ => {}
        }
    }

    Ok(latest)
}

fn parse_codex_token_usage_from_session_file(path: &Path) -> Result<Option<TokenUsage>> {
    let file =
        fs::File::open(path).with_context(|| format!("failed to open `{}`", path.display()))?;
    let mut latest = None;
    for line in BufReader::new(file).lines() {
        let line = line.with_context(|| format!("failed to read `{}`", path.display()))?;
        let Ok(value) = serde_json::from_str::<Value>(&line) else {
            continue;
        };
        if value.get("type").and_then(Value::as_str) != Some("event_msg") {
            continue;
        }
        let Some(payload) = value.get("payload") else {
            continue;
        };
        if payload.get("type").and_then(Value::as_str) != Some("token_count") {
            continue;
        }
        let Some(total_usage) = payload
            .get("info")
            .and_then(|info| info.get("total_token_usage"))
        else {
            continue;
        };
        latest = extract_codex_token_usage(total_usage);
    }

    Ok(latest)
}

fn extract_codex_token_usage(value: &Value) -> Option<TokenUsage> {
    fn parse_u64(value: Option<&Value>) -> u64 {
        value
            .and_then(Value::as_u64)
            .or_else(|| {
                value
                    .and_then(Value::as_i64)
                    .filter(|number| *number >= 0)
                    .map(|number| number as u64)
            })
            .or_else(|| {
                value
                    .and_then(Value::as_str)
                    .and_then(|text| text.parse().ok())
            })
            .unwrap_or(0)
    }

    let input = parse_u64(value.get("input_tokens")) + parse_u64(value.get("cached_input_tokens"));
    let output =
        parse_u64(value.get("output_tokens")) + parse_u64(value.get("reasoning_output_tokens"));
    (input > 0 || output > 0).then_some(TokenUsage {
        input: (input > 0).then_some(input),
        output: (output > 0).then_some(output),
    })
}

#[derive(Debug)]
struct AgentDaemon<C> {
    root: PathBuf,
    store: ListenProjectStore,
    filters: IssueListFilters,
    max_pickups: usize,
    linear_config: LinearConfig,
    app_config: AppConfig,
    planning_meta: PlanningMeta,
    worker_agent: Option<String>,
    worker_model: Option<String>,
    worker_reasoning: Option<String>,
    worker_context_budget_tokens: u64,
    listen_settings: PlanningListenSettings,
    viewer: Option<UserRef>,
    service: LinearService<C>,
}

#[derive(Debug, Clone, Default)]
struct SessionArtifacts<'a> {
    brief_path: Option<String>,
    backlog_issue: Option<&'a IssueSummary>,
    backlog_path: Option<String>,
    workspace: Option<&'a TicketWorkspace>,
    workpad_comment: Option<&'a IssueComment>,
    pid: Option<u32>,
    turns: Option<u32>,
    log_path: Option<String>,
}

#[derive(Debug, Clone)]
struct BacklogIssueContext {
    issue: IssueSummary,
    issue_dir: PathBuf,
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
struct BacklogProgress {
    completed: usize,
    total: usize,
    next_step: Option<String>,
}

#[derive(Debug, Clone, Default)]
struct TurnProgress {
    planning_entries: Vec<String>,
    implementation_entries: Vec<String>,
    volatile_validation_entries: Vec<String>,
}

impl TurnProgress {
    fn implementation_changed(&self) -> bool {
        !self.implementation_entries.is_empty()
    }

    fn planning_changed(&self) -> bool {
        !self.planning_entries.is_empty()
    }
}

#[derive(Debug, Clone, Default)]
struct AttachmentContextSummary {
    downloaded_paths: Vec<String>,
    failed_downloads: Vec<String>,
}

impl AttachmentContextSummary {
    fn downloaded_count(&self) -> usize {
        self.downloaded_paths.len()
    }

    fn has_entries(&self) -> bool {
        self.downloaded_count() > 0 || !self.failed_downloads.is_empty()
    }

    fn compact_label(&self) -> Option<String> {
        if self.downloaded_count() == 0 {
            return (!self.failed_downloads.is_empty())
                .then(|| "attachment context failed".to_string());
        }

        Some(format!(
            "{} attachment context file{}",
            self.downloaded_count(),
            if self.downloaded_count() == 1 {
                ""
            } else {
                "s"
            }
        ))
    }
}

fn compact_session_summary(parts: impl IntoIterator<Item = Option<String>>) -> String {
    let parts = parts
        .into_iter()
        .flatten()
        .filter(|part| !part.trim().is_empty())
        .collect::<Vec<_>>();
    if parts.is_empty() {
        "Waiting for progress".to_string()
    } else {
        parts.join(" | ")
    }
}

fn ticket_progress_summary(description: Option<&str>) -> String {
    let acceptance = extract_linear_acceptance_criteria(description);
    if acceptance.is_empty() {
        "Work in progress".to_string()
    } else {
        let count = acceptance.len();
        let noun = if count == 1 {
            "acceptance criterion"
        } else {
            "acceptance criteria"
        };
        format!("Linear: {count} {noun}")
    }
}

fn turn_counter_summary(turn: u32, max_turns: u32) -> String {
    format!("turn {turn}/{max_turns}")
}

fn stalled_turns_summary(stalled_turns: u32) -> Option<String> {
    (stalled_turns > 0).then(|| {
        if stalled_turns == 1 {
            "1 stalled turn".to_string()
        } else {
            format!("{stalled_turns} stalled turns")
        }
    })
}

fn log_reference_summary(log_path: &Path) -> String {
    format!("see {}", log_path.display())
}

fn truncate_summary(value: &str, max_chars: usize) -> String {
    let collapsed = value.split_whitespace().collect::<Vec<_>>().join(" ");
    let mut chars = collapsed.chars();
    let truncated = chars.by_ref().take(max_chars).collect::<String>();
    if chars.next().is_some() {
        format!("{}...", truncated.trim_end())
    } else {
        collapsed
    }
}

fn compact_pickup_summary(
    workpad_reused: bool,
    attachment_context: &AttachmentContextSummary,
    pid: u32,
) -> String {
    compact_session_summary([
        Some("Picked up from Todo".to_string()),
        Some("local backlog ready".to_string()),
        attachment_context.compact_label(),
        Some(if workpad_reused {
            "workpad reused".to_string()
        } else {
            "workpad created".to_string()
        }),
        Some(format!("worker pid {pid}")),
    ])
}

fn compact_running_summary(
    description: Option<&str>,
    turns_completed: u32,
    max_turns: u32,
    stalled_turns: u32,
) -> String {
    compact_session_summary([
        Some(ticket_progress_summary(description)),
        Some(turn_counter_summary(turns_completed, max_turns)),
        stalled_turns_summary(stalled_turns),
    ])
}

fn compact_completed_summary(
    description: Option<&str>,
    turns_completed: u32,
    state_label: &str,
) -> String {
    compact_session_summary([
        Some("Complete".to_string()),
        Some(ticket_progress_summary(description)),
        Some(format!("{turns_completed} turn(s)")),
        Some(format!("moved to `{state_label}`")),
    ])
}

fn compact_blocked_summary(
    blocked: &BlockedReason,
    description: Option<&str>,
    log_path: &Path,
) -> String {
    compact_session_summary([
        Some(blocked.summary_headline()),
        Some(ticket_progress_summary(description)),
        Some(log_reference_summary(log_path)),
    ])
}

fn blocked_reason(
    category: BlockedCategory,
    reason: impl Into<String>,
    retryable: bool,
) -> BlockedReason {
    BlockedReason::new(category, reason, retryable)
}

fn stale_worker_failure(
    session: &AgentSession,
    pid: u32,
    classification: BlockedReason,
) -> StaleWorkerFailure {
    StaleWorkerFailure {
        pid,
        observed_at_epoch_seconds: now_epoch_seconds(),
        last_persisted_phase: session.phase,
        summary: format!(
            "worker pid {pid} disappeared while the session was {}",
            session.phase.label()
        ),
        classification,
    }
}

fn stale_worker_attempts_summary(attempts: u32) -> Option<String> {
    (attempts > 0)
        .then(|| format!("recovery attempts {attempts}/{MAX_STALE_WORKER_RECOVERY_ATTEMPTS}"))
}

fn block_stale_worker_session(
    session: &mut AgentSession,
    issue_identifier: &str,
    fallback_log_path: &Path,
    failure: StaleWorkerFailure,
    blocked: BlockedReason,
) {
    let log_path = session
        .log_path
        .clone()
        .unwrap_or_else(|| fallback_log_path.display().to_string());
    session.phase = failure.last_persisted_phase;
    session.lifecycle = Some(SessionLifecycle::blocked(
        Some(SessionExitCondition::WorkerDied),
        blocked.retryable,
    ));
    session.blocked = Some(blocked);
    session.latest_stale_worker_failure = Some(failure.clone());
    session.log_path = Some(log_path.clone());
    if session.started_at_epoch_seconds == 0 {
        session.started_at_epoch_seconds = session.updated_at_epoch_seconds.max(1);
    }
    session.summary = compact_session_summary([
        session
            .blocked
            .as_ref()
            .map(BlockedReason::summary_headline),
        Some(format!("stale pid {}", failure.pid)),
        stale_worker_attempts_summary(session.stale_worker_recovery_attempt_count),
        Some(log_reference_summary(Path::new(&log_path))),
    ]);
    session.updated_at_epoch_seconds = now_epoch_seconds();
    if session.issue_identifier.is_empty() {
        session.issue_identifier = issue_identifier.to_string();
    }
}

#[cfg(test)]
fn mark_running_session_stale(
    session: &mut AgentSession,
    issue_identifier: &str,
    fallback_log_path: &Path,
    pid: u32,
) {
    let blocked = blocked_reason(BlockedCategory::Infra, "worker died", true);
    let failure = stale_worker_failure(session, pid, blocked.clone());
    block_stale_worker_session(
        session,
        issue_identifier,
        fallback_log_path,
        failure,
        blocked,
    );
}

fn reconcile_stale_worker_session<F>(
    session: &mut AgentSession,
    issue: &IssueSummary,
    fallback_log_path: &Path,
    spawn_worker: F,
) -> String
where
    F: FnOnce(&AgentSession, &Path, &str, Option<&str>) -> Result<u32>,
{
    let Some(workspace_path) = session.workspace_path.as_deref() else {
        let blocked = blocked_reason(
            BlockedCategory::Setup,
            "missing workspace or workpad context",
            false,
        );
        let failure =
            stale_worker_failure(session, session.pid.unwrap_or_default(), blocked.clone());
        block_stale_worker_session(
            session,
            &issue.identifier,
            fallback_log_path,
            failure,
            blocked,
        );
        return format!(
            "{} worker pid {} was no longer running; missing workspace context prevented automatic stale-worker recovery.",
            session.issue_identifier,
            session.pid.unwrap_or_default()
        );
    };
    let Some(workpad_comment_id) = session.workpad_comment_id.as_deref() else {
        let blocked = blocked_reason(
            BlockedCategory::Setup,
            "missing workspace or workpad context",
            false,
        );
        let failure =
            stale_worker_failure(session, session.pid.unwrap_or_default(), blocked.clone());
        block_stale_worker_session(
            session,
            &issue.identifier,
            fallback_log_path,
            failure,
            blocked,
        );
        return format!(
            "{} worker pid {} was no longer running; missing workpad context prevented automatic stale-worker recovery.",
            session.issue_identifier,
            session.pid.unwrap_or_default()
        );
    };
    let workspace_path = PathBuf::from(workspace_path);
    let pid = session.pid.unwrap_or_default();
    if !workspace_path.is_dir() {
        let blocked = blocked_reason(BlockedCategory::Setup, "workspace missing", false);
        let failure = stale_worker_failure(session, pid, blocked.clone());
        block_stale_worker_session(
            session,
            &issue.identifier,
            fallback_log_path,
            failure,
            blocked,
        );
        return format!(
            "{} worker pid {} was no longer running; workspace `{}` was missing, so stale-worker recovery was blocked.",
            session.issue_identifier,
            pid,
            workspace_path.display()
        );
    }

    let blocked = if session.origin.is_execute() {
        blocked_reason(
            BlockedCategory::Other,
            "execute-origin awaiting manual takeover",
            false,
        )
    } else if session.phase != SessionPhase::Running {
        blocked_reason(BlockedCategory::Infra, "paused worker died", false)
    } else if session.stale_worker_recovery_attempt_count >= MAX_STALE_WORKER_RECOVERY_ATTEMPTS {
        blocked_reason(
            BlockedCategory::Infra,
            "stale worker retry budget exhausted",
            false,
        )
    } else {
        blocked_reason(BlockedCategory::Infra, "worker died", true)
    };
    let failure = stale_worker_failure(session, pid, blocked.clone());

    if !blocked.retryable {
        block_stale_worker_session(
            session,
            &issue.identifier,
            fallback_log_path,
            failure,
            blocked,
        );
        return format!(
            "{} worker pid {} was no longer running; session was parked as blocked after stale-worker classification.",
            session.issue_identifier, pid
        );
    }

    session.latest_stale_worker_failure = Some(failure.clone());
    session.stale_worker_recovery_attempt_count = session
        .stale_worker_recovery_attempt_count
        .saturating_add(1);
    if session.started_at_epoch_seconds == 0 {
        session.started_at_epoch_seconds = session.updated_at_epoch_seconds.max(1);
    }
    session.phase = SessionPhase::Running;
    session.blocked = None;
    session.pid = None;
    session.summary = compact_session_summary([
        Some("Recovering stale worker".to_string()),
        Some(format!("stale pid {pid}")),
        stale_worker_attempts_summary(session.stale_worker_recovery_attempt_count),
        session
            .backlog_issue_identifier
            .as_ref()
            .map(|identifier| format!("backlog {identifier}")),
    ]);
    session.updated_at_epoch_seconds = now_epoch_seconds();

    match spawn_worker(
        session,
        &workspace_path,
        workpad_comment_id,
        session.backlog_issue_identifier.as_deref(),
    ) {
        Ok(new_pid) => {
            session.phase = SessionPhase::Running;
            session.blocked = None;
            session.pid = Some(new_pid);
            session.summary = compact_session_summary([
                Some("Recovered stale worker".to_string()),
                Some(format!("pid {new_pid}")),
                stale_worker_attempts_summary(session.stale_worker_recovery_attempt_count),
                session
                    .backlog_issue_identifier
                    .as_ref()
                    .map(|identifier| format!("backlog {identifier}")),
            ]);
            session.updated_at_epoch_seconds = now_epoch_seconds();
            session.log_path = Some(fallback_log_path.display().to_string());
            format!(
                "Recovered stale {} worker pid {} with fresh pid {} (attempt {}/{}).",
                issue.identifier,
                pid,
                new_pid,
                session.stale_worker_recovery_attempt_count,
                MAX_STALE_WORKER_RECOVERY_ATTEMPTS
            )
        }
        Err(error) => {
            let blocked = blocked_reason(
                BlockedCategory::Infra,
                "stale worker recovery failed",
                false,
            );
            block_stale_worker_session(
                session,
                &issue.identifier,
                fallback_log_path,
                failure,
                blocked,
            );
            format!(
                "{} worker pid {} was stale, but automatic recovery failed: {error:#}.",
                session.issue_identifier, pid
            )
        }
    }
}

fn render_watch_scope(assignment_scope: ListenAssignmentScope, viewer: Option<&UserRef>) -> String {
    match assignment_scope {
        ListenAssignmentScope::Any => "all assignees".to_string(),
        ListenAssignmentScope::ViewerOnly => viewer
            .map(|viewer| format!("only {}", viewer.name))
            .unwrap_or_else(|| "viewer only".to_string()),
        ListenAssignmentScope::ViewerOrUnassigned => viewer
            .map(|viewer| format!("{} + unassigned", viewer.name))
            .unwrap_or_else(|| "viewer + unassigned".to_string()),
    }
}

fn should_preserve_last_known_linear_snapshot(error: &anyhow::Error) -> bool {
    error.chain().any(|cause| {
        let message = cause.to_string().to_ascii_lowercase();
        message.contains("linear request failed")
            || message.contains("failed to reach the linear graphql endpoint")
            || message.contains("failed to read the linear response body")
            || message.contains("failed to decode the linear response payload")
            || message.contains("failed to upload file contents to linear storage")
            || message.contains("failed to read the linear upload response body")
            || message.contains("linear file upload failed")
            || message.contains("linear returned no data")
            || message.contains("failed to access linear api")
            || message.contains("not found in linear")
    })
}

fn issue_assignee_filter(
    assignment_scope: ListenAssignmentScope,
    viewer: Option<&UserRef>,
) -> IssueAssigneeFilter {
    match assignment_scope {
        ListenAssignmentScope::Any => IssueAssigneeFilter::Any,
        ListenAssignmentScope::ViewerOnly => viewer.map_or(IssueAssigneeFilter::Any, |viewer| {
            IssueAssigneeFilter::Viewer {
                viewer_id: viewer.id.clone(),
            }
        }),
        ListenAssignmentScope::ViewerOrUnassigned => {
            viewer.map_or(IssueAssigneeFilter::Any, |viewer| {
                IssueAssigneeFilter::ViewerOrUnassigned {
                    viewer_id: viewer.id.clone(),
                }
            })
        }
    }
}

impl BranchPullRequestLookup {
    fn branch_state(
        &mut self,
        root: &Path,
        branch: &str,
        head_ref_oid: Option<&str>,
    ) -> Option<BranchPullRequestState> {
        let result = self
            .cache
            .entry(branch.to_string())
            .or_insert_with(|| discover_branch_pull_requests(root, branch));
        match result {
            BranchPullRequestLookupResult::Available(records) => {
                select_branch_pull_request_state(records, branch, head_ref_oid)
            }
            BranchPullRequestLookupResult::Unavailable(reason) => {
                let _ = reason;
                None
            }
        }
    }
}

fn discover_branch_pull_requests(root: &Path, branch: &str) -> BranchPullRequestLookupResult {
    let output = Command::new("gh")
        .args([
            "pr",
            "list",
            "--head",
            branch,
            "--state",
            "all",
            "--limit",
            "1000",
            "--json",
            "headRefName,headRefOid,state",
        ])
        .current_dir(root)
        .output();
    let output = match output {
        Ok(output) => output,
        Err(error) => return BranchPullRequestLookupResult::Unavailable(error.to_string()),
    };
    if !output.status.success() {
        return BranchPullRequestLookupResult::Unavailable(
            String::from_utf8_lossy(&output.stderr).trim().to_string(),
        );
    }

    let records = match serde_json::from_slice::<Vec<BranchPullRequestRecord>>(&output.stdout) {
        Ok(records) => records,
        Err(error) => return BranchPullRequestLookupResult::Unavailable(error.to_string()),
    };

    BranchPullRequestLookupResult::Available(records)
}

fn select_branch_pull_request_state(
    records: &[BranchPullRequestRecord],
    branch: &str,
    head_ref_oid: Option<&str>,
) -> Option<BranchPullRequestState> {
    let mut matching_records = records
        .iter()
        .filter(|record| record.head_ref_name == branch)
        .collect::<Vec<_>>();

    if let Some(head_ref_oid) = head_ref_oid {
        if let Some(record) = matching_records
            .iter()
            .find(|record| record.head_ref_oid.as_deref() == Some(head_ref_oid))
        {
            return Some(branch_pull_request_state(record.state.as_str()));
        }
    }

    if matching_records.len() == 1 {
        return Some(branch_pull_request_state(
            matching_records.pop()?.state.as_str(),
        ));
    }

    None
}

fn branch_pull_request_state(state: &str) -> BranchPullRequestState {
    match state.trim().to_ascii_uppercase().as_str() {
        "OPEN" => BranchPullRequestState::Open,
        "CLOSED" => BranchPullRequestState::Closed,
        "MERGED" => BranchPullRequestState::Merged,
        _ => BranchPullRequestState::Other,
    }
}

fn render_listen_backlog_file(
    relative_path: &str,
    contents: String,
    parent_issue: &IssueSummary,
) -> String {
    if relative_path != "validation.md" {
        return contents;
    }

    format!(
        "# Validation Plan\n\n## Command Proofs\n\n- Keep packet-local execution notes in this file (`{}/backlog/{}/validation.md`)\n- Record reviewer-facing repo-level validation evidence in `artifacts/validation/{}.md`\n- Run the changed CLI flow against a deterministic local or mocked setup\n- Verify the original Linear issue description for `{}` remains unchanged\n- Update the existing `## Codex Workpad` comment with validation notes instead of running `{} sync push`\n\n## Notes\n\n- `{} listen` must not overwrite the primary Linear issue description.\n- Do not write ticket-specific PR evidence to repo-root `validation.md`.\n- Do not commit validation-artifact-only changes that merely refresh timestamps, latest commit SHA, PR head SHA, workflow run IDs, turn counts, or branch-head status.\n",
        crate::branding::PROJECT_DIR,
        parent_issue.identifier,
        parent_issue.identifier,
        parent_issue.identifier,
        crate::branding::COMMAND_NAME,
        crate::branding::COMMAND_NAME,
    )
}

fn format_required_label_filter(required_labels: &[String]) -> String {
    required_labels
        .iter()
        .map(|label| format!("`{label}`"))
        .collect::<Vec<_>>()
        .join(", ")
}

fn required_label_skip_reason(
    listen_settings: &PlanningListenSettings,
    issue: &IssueSummary,
) -> Option<String> {
    let required_labels = listen_settings.required_label_names();
    if required_labels.is_empty()
        || issue.labels.iter().any(|issue_label| {
            required_labels
                .iter()
                .any(|required| issue_label.name.eq_ignore_ascii_case(required))
        })
    {
        return None;
    }

    Some(if required_labels.len() == 1 {
        format!("missing required label `{}`", required_labels[0])
    } else {
        format!(
            "missing any required label ({})",
            format_required_label_filter(required_labels)
        )
    })
}

impl<C> AgentDaemon<C>
where
    C: LinearClient,
{
    async fn run_cycle_resilient(&self) -> Result<ListenCycleData> {
        let viewer = match self.resolve_cycle_viewer().await {
            Ok(viewer) => viewer,
            Err(error) if should_preserve_last_known_linear_snapshot(&error) => {
                return self.build_degraded_cycle(&error, None);
            }
            Err(error) => return Err(error),
        };

        match self.run_cycle_with_viewer(viewer.as_ref()).await {
            Ok(cycle) => Ok(cycle),
            Err(error) if should_preserve_last_known_linear_snapshot(&error) => {
                self.build_degraded_cycle(&error, viewer.as_ref())
            }
            Err(error) => Err(error),
        }
    }

    async fn run_cycle_with_viewer(&self, viewer: Option<&UserRef>) -> Result<ListenCycleData> {
        self.store.ensure_layout()?;
        let mut state = self.store.load_state()?;
        let filters = self.filters_with_viewer(viewer);
        let pending = self.service.list_issues(filters.clone()).await?;
        let in_progress_issues = self
            .service
            .list_issues(IssueListFilters {
                state: Some(IN_PROGRESS_STATE.to_string()),
                ..filters.clone()
            })
            .await
            .unwrap_or_default();
        let active_issues: Vec<ActiveIssue> = in_progress_issues
            .into_iter()
            .map(ActiveIssue::from_issue)
            .collect();
        let mut notes = vec![format!(
            "Observed {} Todo issue(s) and {} In Progress issue(s) from Linear.",
            pending.len(),
            active_issues.len()
        )];
        notes.extend(workspace_pressure::assess_workspace_pressure(&self.root)?.summary_lines());
        self.reconcile_sessions(&mut state, &mut notes, viewer)
            .await?;
        let required_labels = self.listen_settings.required_label_names();
        if !required_labels.is_empty() {
            notes.push(format!(
                "Listen label filter is active: any of {}.",
                format_required_label_filter(required_labels)
            ));
        }
        notes.push(format!(
            "Watching: {}.",
            self.watch_scope_label_with(viewer)
        ));
        let mut claimed_this_cycle = 0usize;
        let mut claimed_identifiers = Vec::new();
        let mut eligible = Vec::new();

        for issue in &pending {
            if state.blocks_pickup(&issue.identifier) {
                continue;
            }
            if let Some(reason) = self.skip_reason_with_viewer(issue, viewer) {
                notes.push(format!("Skipped {}: {}.", issue.identifier, reason));
                continue;
            }
            eligible.push(issue.clone());
            if eligible.len() >= self.max_pickups.max(1) {
                break;
            }
        }

        for issue in &eligible {
            let session = self.pickup_issue(issue).await?;
            notes.push(format!(
                "Picked up {} and recorded stage `{}`.",
                session.issue_identifier,
                session.phase.label()
            ));
            claimed_this_cycle += 1;
            claimed_identifiers.push(issue.identifier.clone());
            state.upsert(session);
        }

        let pending_issues = pending
            .into_iter()
            .filter(|issue| {
                !claimed_identifiers
                    .iter()
                    .any(|identifier| identifier.eq_ignore_ascii_case(&issue.identifier))
            })
            .map(PendingIssue::from)
            .collect::<Vec<_>>();
        let mut persisted_state = self.store.load_state()?;
        persisted_state.sessions = merge_cycle_sessions(persisted_state.sessions, state.sessions);
        persisted_state.pending_issues = pending_issues.clone();
        persisted_state.active_issues = active_issues.clone();
        persisted_state.degraded = None;
        self.store.save_state(&persisted_state)?;
        let live_sessions = persisted_state.sorted_sessions();
        let sessions =
            merge_visible_sessions(live_sessions.clone(), self.store.load_retained_sessions()?);
        let session_details =
            load_visible_session_details(&self.store, &self.app_config, &live_sessions, &sessions)?;

        let scope = match (&self.filters.team, &self.filters.project) {
            (Some(team), Some(project)) => format!("{team} / {project}"),
            (Some(team), None) => team.clone(),
            (None, Some(project)) => project.clone(),
            (None, None) => "all teams".to_string(),
        };
        let state_file = display_path(&self.store.paths().state_path, &self.root);
        notes.push(format!("Persisted daemon state to {state_file}."));

        Ok(ListenCycleData {
            scope,
            watch_scope: self.watch_scope_label_with(viewer),
            claimed_this_cycle,
            pending_issues,
            active_issues,
            sessions,
            session_details,
            notes,
            state_file,
            rate_limits: None,
            degraded: None,
        })
    }

    fn build_degraded_cycle(
        &self,
        error: &anyhow::Error,
        viewer: Option<&UserRef>,
    ) -> Result<ListenCycleData> {
        self.store.ensure_layout()?;
        let mut state = self.store.load_state()?;
        let classified = classify_linear_failure(error);
        let previous_failures = state
            .degraded
            .as_ref()
            .map(|failure| failure.consecutive_failures)
            .unwrap_or(0);
        let consecutive_failures = previous_failures.saturating_add(1);
        let now_epoch_seconds = now_epoch_seconds();
        let next_retry_at_epoch_seconds = classified.is_retryable().then_some(
            now_epoch_seconds
                + self
                    .app_config
                    .defaults
                    .listen
                    .retry
                    .backoff_seconds_for_failure_streak(consecutive_failures),
        );
        let degraded = LinearFailureSnapshot {
            kind: classified.kind,
            message: classified.message,
            observed_at_epoch_seconds: now_epoch_seconds,
            status_code: classified.status_code,
            consecutive_failures,
            next_retry_at_epoch_seconds,
        };
        state.degraded = Some(degraded.clone());
        self.store.save_state(&state)?;

        let live_sessions = state.sorted_sessions();
        let sessions =
            merge_visible_sessions(live_sessions.clone(), self.store.load_retained_sessions()?);
        let session_details =
            load_visible_session_details(&self.store, &self.app_config, &live_sessions, &sessions)?;
        let scope = match (&self.filters.team, &self.filters.project) {
            (Some(team), Some(project)) => format!("{team} / {project}"),
            (Some(team), None) => team.clone(),
            (None, Some(project)) => project.clone(),
            (None, None) => "all teams".to_string(),
        };
        let retry_note = match degraded.next_retry_at_epoch_seconds {
            Some(_) => format!(
                "Retrying in {} under the shared listen backoff policy.",
                degraded.retry_label(now_epoch_seconds)
            ),
            None => "Operator action is likely required before the next successful Linear refresh."
                .to_string(),
        };
        let notes = vec![
            format!(
                "Preserved the last known queue and session snapshot after a {} Linear failure.",
                degraded.kind.label()
            ),
            retry_note,
            format!("Latest Linear failure: {:#}", error),
        ];
        let mut notes = notes;
        notes.extend(workspace_pressure::assess_workspace_pressure(&self.root)?.summary_lines());
        Ok(ListenCycleData {
            scope,
            watch_scope: self.watch_scope_label_with(viewer),
            claimed_this_cycle: 0,
            pending_issues: state.pending_issues.clone(),
            active_issues: state.active_issues.clone(),
            sessions,
            session_details,
            notes,
            state_file: display_path(&self.store.paths().state_path, &self.root),
            rate_limits: None,
            degraded: Some(degraded),
        })
    }

    async fn reconcile_sessions(
        &self,
        state: &mut ListenState,
        notes: &mut Vec<String>,
        viewer: Option<&UserRef>,
    ) -> Result<()> {
        let pruned = state.prune_completed_sessions_older_than(
            now_epoch_seconds(),
            COMPLETED_SESSION_TTL_SECONDS,
        );
        if !pruned.is_empty() {
            notes.push(format!(
                "Pruned {} completed session(s) older than the 24-hour TTL: {}.",
                pruned.len(),
                pruned
                    .iter()
                    .map(|session| session.issue_identifier.as_str())
                    .collect::<Vec<_>>()
                    .join(", ")
            ));
        }

        let existing_sessions = state.sessions.clone();
        let mut reconciled = Vec::with_capacity(existing_sessions.len());
        let mut branch_pull_requests = BranchPullRequestLookup::default();

        for mut session in existing_sessions {
            let mut issue = match self.service.load_issue(&session.issue_identifier).await {
                Ok(issue) => issue,
                Err(error) => {
                    notes.push(format!(
                        "Retained {} session state because Linear refresh failed: {error:#}.",
                        session.issue_identifier
                    ));
                    reconciled.push(session);
                    continue;
                }
            };

            session.issue_id = Some(issue.id.clone());
            session.issue_title = issue.title.clone();
            session.project_name = issue.project.as_ref().map(|project| project.name.clone());
            session.team_key = issue.team.key.clone();
            session.issue_url = issue.url.clone();

            if !session.shows_in_completed_view()
                && normalize_issue_state_name(issue_state_label(&issue).as_str()) == "todo"
                && self
                    .session_drop_reason_with_viewer(&issue, viewer)
                    .is_none()
            {
                match self
                    .service
                    .edit_issue(IssueEditSpec {
                        identifier: issue.identifier.clone(),
                        title: None,
                        description: None,
                        project: None,
                        state: Some(IN_PROGRESS_STATE.to_string()),
                        priority: None,
                        estimate: None,
                        labels: None,
                        parent_identifier: None,
                    })
                    .await
                {
                    Ok(updated_issue) => {
                        issue = updated_issue;
                        session.issue_title = issue.title.clone();
                        session.project_name =
                            issue.project.as_ref().map(|project| project.name.clone());
                        session.team_key = issue.team.key.clone();
                        session.issue_url = issue.url.clone();
                        session.updated_at_epoch_seconds = now_epoch_seconds();
                        notes.push(format!(
                            "{} was observed back in Todo while a `{}` session existed; restored it to `{}`.",
                            issue.identifier,
                            session.phase.label(),
                            IN_PROGRESS_STATE
                        ));
                    }
                    Err(error) => {
                        notes.push(format!(
                            "Failed to restore {} from Todo to `{}` during session reconciliation: {error:#}.",
                            issue.identifier,
                            IN_PROGRESS_STATE
                        ));
                    }
                }
            }

            if !listen_issue_is_active(issue.state.as_ref().map(|state| state.name.as_str())) {
                if session.effective_lifecycle().outcome != SessionLifecycleOutcome::Completed {
                    session.lifecycle = Some(SessionLifecycle::completed(
                        SessionExitCondition::IssueMoved,
                    ));
                    session.summary = compact_session_summary([
                        Some("Complete".to_string()),
                        Some(format!("moved to `{}`", issue_state_label(&issue))),
                    ]);
                    session.updated_at_epoch_seconds = now_epoch_seconds();
                }
                let (removed, cleanup_note) = self.reconcile_completed_listener_workspace(
                    &mut session,
                    &mut branch_pull_requests,
                );
                if let Some(note) = cleanup_note {
                    notes.push(note);
                }
                if !removed {
                    reconciled.push(session);
                }
                continue;
            }

            if matches!(session.phase, SessionPhase::Running | SessionPhase::Paused)
                && session.pid.is_some_and(pid_is_running)
            {
                reconciled.push(session);
                continue;
            }

            if !session.shows_in_completed_view()
                && !session.is_blocked_session()
                && session.phase != SessionPhase::Paused
                && let Some(reason) = self.session_drop_reason_with_viewer(&issue, viewer)
            {
                session.lifecycle = Some(SessionLifecycle::completed(
                    SessionExitCondition::IssueMoved,
                ));
                session.summary = reason.clone();
                session.updated_at_epoch_seconds = now_epoch_seconds();
                notes.push(format!("Ended {} session: {reason}.", issue.identifier));
                reconciled.push(session);
                continue;
            }

            if (session.shows_in_completed_view() || session.is_blocked_session())
                && !session.can_auto_resume()
                || (session.phase == SessionPhase::Paused && session.pid.is_none())
            {
                if normalize_issue_state_name(issue_state_label(&issue).as_str()) == "todo" {
                    notes.push(format!(
                        "{} returned to Todo; retaining the previous `{}` session to avoid automatic re-pickup churn.",
                        issue.identifier,
                        session.phase.label()
                    ));
                    reconciled.push(session);
                    continue;
                }

                reconciled.push(session);
                continue;
            }

            if matches!(session.phase, SessionPhase::Running | SessionPhase::Paused)
                && let Some(_pid) = session.pid
            {
                let fallback_log_path = self.agent_log_path(&issue.identifier);
                notes.push(reconcile_stale_worker_session(
                    &mut session,
                    &issue,
                    &fallback_log_path,
                    |recovery_session,
                     workspace_path,
                     workpad_comment_id,
                     backlog_issue_identifier| {
                        self.store.upsert_session(recovery_session.clone())?;
                        self.spawn_listen_worker_from_context(
                            &issue,
                            workspace_path,
                            workpad_comment_id,
                            backlog_issue_identifier,
                            ListenWorkerSpawnReason::StaleRecovery,
                        )
                    },
                ));
                reconciled.push(session);
                continue;
            }
            let (Some(workspace_path), Some(workpad_comment_id)) = (
                session.workspace_path.as_deref(),
                session.workpad_comment_id.as_deref(),
            ) else {
                session.phase = SessionPhase::Blocked;
                session.blocked = Some(blocked_reason(
                    BlockedCategory::Setup,
                    "missing workspace or workpad context",
                    false,
                ));
                session.lifecycle = Some(derive_session_lifecycle(
                    session.phase,
                    session.blocked.as_ref(),
                    None,
                    &session.pull_request,
                    session.latest_stale_worker_failure.as_ref(),
                ));
                session.summary = session
                    .blocked
                    .as_ref()
                    .map(BlockedReason::summary_headline)
                    .unwrap_or_else(|| "Blocked".to_string());
                session.updated_at_epoch_seconds = now_epoch_seconds();
                reconciled.push(session);
                continue;
            };

            let workspace_path = PathBuf::from(workspace_path);
            if !workspace_path.is_dir() {
                session.phase = SessionPhase::Blocked;
                session.blocked = Some(blocked_reason(
                    BlockedCategory::Setup,
                    "workspace missing",
                    false,
                ));
                session.lifecycle = Some(derive_session_lifecycle(
                    session.phase,
                    session.blocked.as_ref(),
                    None,
                    &session.pull_request,
                    session.latest_stale_worker_failure.as_ref(),
                ));
                session.summary = session
                    .blocked
                    .as_ref()
                    .map(BlockedReason::summary_headline)
                    .unwrap_or_else(|| "Blocked".to_string());
                session.updated_at_epoch_seconds = now_epoch_seconds();
                reconciled.push(session);
                continue;
            }

            // Execute-origin sessions must not be auto-resumed by the listen daemon;
            // they require explicit operator takeover through `meta listen sessions resume`.
            if session.origin.is_execute() {
                session.phase = SessionPhase::Blocked;
                session.blocked = Some(blocked_reason(
                    BlockedCategory::Other,
                    "execute-origin awaiting manual takeover",
                    false,
                ));
                session.lifecycle = Some(SessionLifecycle::blocked(
                    Some(SessionExitCondition::ExecuteAwaitingTakeover),
                    false,
                ));
                session.summary = compact_session_summary([
                    session
                        .blocked
                        .as_ref()
                        .map(BlockedReason::summary_headline),
                    session
                        .backlog_issue_identifier
                        .as_ref()
                        .map(|identifier| format!("backlog {identifier}")),
                ]);
                session.updated_at_epoch_seconds = now_epoch_seconds();
                notes.push(format!(
                    "{} is execute-origin; skipping automatic resume — use `{} listen sessions resume` to adopt.",
                    issue.identifier,
                    crate::branding::COMMAND_NAME,
                ));
                reconciled.push(session);
                continue;
            }

            match self.spawn_listen_worker_from_context(
                &issue,
                &workspace_path,
                workpad_comment_id,
                session.backlog_issue_identifier.as_deref(),
                ListenWorkerSpawnReason::Resume,
            ) {
                Ok(pid) => {
                    session.phase = SessionPhase::Running;
                    session.lifecycle = Some(SessionLifecycle::active(true));
                    session.blocked = None;
                    session.pid = Some(pid);
                    session.summary = compact_session_summary([
                        Some("Resumed worker".to_string()),
                        Some(format!("pid {pid}")),
                        session
                            .backlog_issue_identifier
                            .as_ref()
                            .map(|identifier| format!("backlog {identifier}")),
                    ]);
                    session.updated_at_epoch_seconds = now_epoch_seconds();
                    session.log_path =
                        Some(self.agent_log_path(&issue.identifier).display().to_string());
                    notes.push(format!(
                        "Resumed {} with a fresh listen worker pid {}.",
                        issue.identifier, pid
                    ));
                    reconciled.push(session);
                }
                Err(_error) => {
                    session.phase = SessionPhase::Blocked;
                    session.blocked = Some(blocked_reason(
                        BlockedCategory::Infra,
                        "worker resume failed",
                        true,
                    ));
                    session.lifecycle = Some(derive_session_lifecycle(
                        session.phase,
                        session.blocked.as_ref(),
                        None,
                        &session.pull_request,
                        session.latest_stale_worker_failure.as_ref(),
                    ));
                    session.summary = compact_session_summary([session
                        .blocked
                        .as_ref()
                        .map(BlockedReason::summary_headline)]);
                    session.updated_at_epoch_seconds = now_epoch_seconds();
                    reconciled.push(session);
                }
            }
        }

        state.sessions = reconciled;
        Ok(())
    }

    fn reconcile_completed_listener_workspace(
        &self,
        session: &mut AgentSession,
        branch_pull_requests: &mut BranchPullRequestLookup,
    ) -> (bool, Option<String>) {
        if session.origin.is_execute() {
            return (false, None);
        }

        let Some(workspace_path) = session.workspace_path.as_deref().map(PathBuf::from) else {
            return (false, None);
        };
        if !workspace_path.is_dir() {
            return (false, None);
        }

        let branch = session
            .branch
            .clone()
            .or_else(|| git_stdout(&workspace_path, &["rev-parse", "--abbrev-ref", "HEAD"]).ok());
        let Some(branch) = branch else {
            return (false, None);
        };
        let head_ref_oid = git_stdout(&workspace_path, &["rev-parse", "HEAD"]).ok();
        let Some(pr_state) =
            branch_pull_requests.branch_state(&self.root, &branch, head_ref_oid.as_deref())
        else {
            return (false, None);
        };
        if !pr_state.is_merged() {
            return (false, None);
        }

        let workspace_root = match sibling_workspace_root(&self.root) {
            Ok(workspace_root) => workspace_root,
            Err(error) => {
                return (
                    false,
                    Some(format!(
                        "Retained completed listener workspace for {} after PR merge: failed to resolve workspace root: {error:#}.",
                        session.issue_identifier
                    )),
                );
            }
        };

        match try_auto_clean_workspace(
            &self.root,
            self.store.identity().project_selector.as_deref(),
            &workspace_root,
            &workspace_path,
            &session.issue_identifier,
        ) {
            Ok(AutoCleanOutcome::Removed { bytes_reclaimed }) => (
                true,
                Some(format!(
                    "Auto-cleaned completed listener workspace for {} after PR merge and freed {} bytes.",
                    session.issue_identifier, bytes_reclaimed
                )),
            ),
            Ok(AutoCleanOutcome::Skipped { reason }) => {
                let reason = reason.to_string();
                session.summary = compact_session_summary([
                    Some("Complete".to_string()),
                    Some(format!("preserved after merge ({reason})")),
                ]);
                session.updated_at_epoch_seconds = now_epoch_seconds();
                (
                    false,
                    Some(format!(
                        "Retained completed listener workspace for {} after PR merge: {}.",
                        session.issue_identifier, reason
                    )),
                )
            }
            Err(error) => (
                false,
                Some(format!(
                    "Retained completed listener workspace for {} after PR merge because auto-clean failed: {error:#}.",
                    session.issue_identifier
                )),
            ),
        }
    }

    async fn ensure_backlog_issue(
        &self,
        parent_issue: &IssueSummary,
        workspace_path: &Path,
    ) -> Result<BacklogIssueContext> {
        Self::ensure_backlog_issue_standalone(parent_issue, workspace_path).await
    }

    /// Shared backlog-issue bootstrap that does not require a daemon instance.
    ///
    /// Both `pickup_issue` (via `ensure_backlog_issue`) and `run_execute` call this
    /// to provision the local backlog directory for the target issue.
    async fn ensure_backlog_issue_standalone(
        parent_issue: &IssueSummary,
        workspace_path: &Path,
    ) -> Result<BacklogIssueContext> {
        let backlog_issue = parent_issue.clone();
        let issue_dir =
            PlanningPaths::new(workspace_path).backlog_issue_dir(&parent_issue.identifier);
        let rendered_files = render_template_files(
            workspace_path,
            &TemplateContext {
                issue_identifier: Some(parent_issue.identifier.clone()),
                issue_title: Some(parent_issue.title.clone()),
                issue_url: Some(parent_issue.url.clone()),
                parent_identifier: Some(parent_issue.identifier.clone()),
                parent_title: Some(parent_issue.title.clone()),
                parent_url: Some(parent_issue.url.clone()),
                parent_description: parent_issue.description.clone(),
                ..TemplateContext::default()
            },
        )?;
        for rendered in rendered_files {
            let path = issue_dir.join(&rendered.relative_path);
            if path.exists() {
                continue;
            }

            let contents = if rendered.relative_path == INDEX_FILE_NAME {
                render_listen_backlog_description(
                    &rendered.contents,
                    parent_issue,
                    parent_issue.description.as_deref(),
                )
            } else {
                render_listen_backlog_file(&rendered.relative_path, rendered.contents, parent_issue)
            };
            fs::create_dir_all(
                path.parent()
                    .ok_or_else(|| anyhow!("missing parent directory for `{}`", path.display()))?,
            )
            .with_context(|| format!("failed to create `{}`", issue_dir.display()))?;
            fs::write(&path, contents)
                .with_context(|| format!("failed to write `{}`", path.display()))?;
        }

        if !issue_dir.join(INDEX_FILE_NAME).exists() {
            let index_contents = render_listen_backlog_description(
                "",
                parent_issue,
                parent_issue.description.as_deref(),
            );
            write_issue_description(workspace_path, &parent_issue.identifier, &index_contents)?;
        }
        save_issue_metadata(
            &issue_dir,
            &BacklogIssueMetadata {
                issue_id: parent_issue.id.clone(),
                identifier: parent_issue.identifier.clone(),
                title: parent_issue.title.clone(),
                url: parent_issue.url.clone(),
                team_key: parent_issue.team.key.clone(),
                project_id: parent_issue
                    .project
                    .as_ref()
                    .map(|project| project.id.clone()),
                project_name: parent_issue
                    .project
                    .as_ref()
                    .map(|project| project.name.clone()),
                parent_id: None,
                parent_identifier: None,
                local_hash: None,
                remote_hash: None,
                last_sync_at: None,
                last_pulled_comment_ids: Vec::new(),
                managed_files: Vec::<ManagedFileRecord>::new(),
            },
        )?;

        Ok(BacklogIssueContext {
            issue: backlog_issue,
            issue_dir,
        })
    }

    async fn pickup_issue(&self, issue: &IssueSummary) -> Result<AgentSession> {
        let expected_workspace_path =
            expected_ticket_workspace_path(&self.root, &issue.identifier)?;
        worker_lease::ensure_listen_worker_lease_available(
            &expected_workspace_path,
            &issue.identifier,
        )?;

        let updated_issue = self
            .service
            .edit_issue(IssueEditSpec {
                identifier: issue.identifier.clone(),
                title: None,
                description: None,
                project: None,
                state: Some(IN_PROGRESS_STATE.to_string()),
                priority: None,
                estimate: None,
                labels: None,
                parent_identifier: None,
            })
            .await?;

        let brief_metadata = TicketMetadata {
            title: Some(issue.title.clone()),
            description: issue.description.clone(),
            url: Some(issue.url.clone()),
            state: updated_issue
                .state
                .as_ref()
                .map(|state| state.name.clone())
                .or_else(|| Some(IN_PROGRESS_STATE.to_string())),
        };
        let updated_at_epoch_seconds = now_epoch_seconds();
        let detailed_issue = match self.service.load_issue(&updated_issue.identifier).await {
            Ok(issue) => issue,
            Err(_error) => {
                let blocked = blocked_reason(
                    BlockedCategory::Infra,
                    "issue refresh failed before workspace setup",
                    true,
                );
                return Ok(self.build_blocked_session(
                    &updated_issue,
                    blocked.clone(),
                    blocked.summary_headline(),
                    SessionArtifacts::default(),
                    updated_at_epoch_seconds,
                ));
            }
        };

        let ws_root = self.root.clone();
        let ws_refresh_policy = self.listen_settings.refresh_policy();
        let ws_identifier = detailed_issue.identifier.clone();
        let ws_title = detailed_issue.title.clone();
        let mut workspace = match tokio::task::spawn_blocking(move || {
            ensure_ticket_workspace(&ws_root, ws_refresh_policy, &ws_identifier, &ws_title)
        })
        .await?
        {
            Ok(workspace) => workspace,
            Err(_error) => {
                let blocked =
                    blocked_reason(BlockedCategory::Setup, "workspace setup failed", false);
                return Ok(self.build_blocked_session(
                    &detailed_issue,
                    blocked.clone(),
                    blocked.summary_headline(),
                    SessionArtifacts::default(),
                    updated_at_epoch_seconds,
                ));
            }
        };
        workspace.workspace_path = canonicalize_existing_dir(&workspace.workspace_path)?;
        worker_lease::ensure_listen_worker_lease_available(
            &workspace.workspace_path,
            &detailed_issue.identifier,
        )?;
        if let Err(error) = preflight::run_listen_preflight(
            &self.service,
            &self.linear_config,
            &self.app_config,
            &self.planning_meta,
            preflight::ListenPreflightRequest {
                working_dir: &workspace.workspace_path,
                agent: self.worker_agent.as_deref(),
                model: self.worker_model.as_deref(),
                reasoning: self.worker_reasoning.as_deref(),
                require_write_access: true,
            },
        )
        .await
        {
            let log_path = self.agent_log_path(&detailed_issue.identifier);
            let _ = worker::write_preflight_failure(&log_path, &error);
            let blocked = blocked_reason(BlockedCategory::Setup, "missing exec capability", false);
            return Ok(self.build_blocked_session(
                &detailed_issue,
                blocked.clone(),
                compact_session_summary([
                    Some(blocked.summary_headline()),
                    Some(truncate_summary(&error.to_string(), 72)),
                ]),
                SessionArtifacts {
                    workspace: Some(&workspace),
                    log_path: Some(log_path.display().to_string()),
                    ..SessionArtifacts::default()
                },
                updated_at_epoch_seconds,
            ));
        }
        let backlog_issue = match self
            .ensure_backlog_issue(&detailed_issue, &workspace.workspace_path)
            .await
        {
            Ok(backlog_issue) => backlog_issue,
            Err(_error) => {
                let blocked = blocked_reason(BlockedCategory::Setup, "backlog setup failed", false);
                return Ok(self.build_blocked_session(
                    &detailed_issue,
                    blocked.clone(),
                    blocked.summary_headline(),
                    SessionArtifacts {
                        workspace: Some(&workspace),
                        ..SessionArtifacts::default()
                    },
                    updated_at_epoch_seconds,
                ));
            }
        };
        let attachment_context = match sync_issue_attachment_context(
            &self.service,
            &workspace.workspace_path,
            &detailed_issue,
        )
        .await
        {
            Ok(summary) => summary,
            Err(_error) => {
                let blocked = blocked_reason(
                    BlockedCategory::Setup,
                    "attachment context setup failed",
                    false,
                );
                return Ok(self.build_blocked_session(
                    &detailed_issue,
                    blocked.clone(),
                    blocked.summary_headline(),
                    SessionArtifacts {
                        backlog_issue: Some(&backlog_issue.issue),
                        backlog_path: Some(backlog_issue.issue_dir.display().to_string()),
                        workspace: Some(&workspace),
                        ..SessionArtifacts::default()
                    },
                    updated_at_epoch_seconds,
                ));
            }
        };

        let brief_workspace = workspace.workspace_path.clone();
        let brief_request = AgentBriefRequest {
            ticket: detailed_issue.identifier.clone(),
            title_override: Some(detailed_issue.title.clone()),
            goal: Some(format!(
                "Picked up automatically by `{} listen`.",
                crate::branding::COMMAND_NAME
            )),
            metadata: brief_metadata,
            output: None,
        };
        let brief_path =
            tokio::task::spawn_blocking(move || write_agent_brief(&brief_workspace, brief_request))
                .await?
                .map(|path| path.display().to_string())
                .ok();

        let timestamp = now_timestamp();
        let workpad_body = render_bootstrap_workpad(&detailed_issue, &workspace, &timestamp);
        let existing_workpad_comment = active_workpad_comment(&detailed_issue);
        let workpad_reused = existing_workpad_comment.is_some();
        let workpad_comment = if let Some(comment) = existing_workpad_comment {
            comment
        } else {
            match self
                .service
                .upsert_workpad_comment(&detailed_issue, workpad_body)
                .await
            {
                Ok(comment) => comment,
                Err(_error) => {
                    let blocked =
                        blocked_reason(BlockedCategory::Infra, "workpad sync failed", true);
                    return Ok(self.build_blocked_session(
                        &detailed_issue,
                        blocked.clone(),
                        compact_session_summary([
                            Some(blocked.summary_headline()),
                            Some("local backlog".to_string()),
                        ]),
                        SessionArtifacts {
                            brief_path: brief_path.clone(),
                            backlog_issue: Some(&backlog_issue.issue),
                            backlog_path: Some(backlog_issue.issue_dir.display().to_string()),
                            workspace: Some(&workspace),
                            ..SessionArtifacts::default()
                        },
                        updated_at_epoch_seconds,
                    ));
                }
            }
        };

        let log_path = self.agent_log_path(&detailed_issue.identifier);
        match self.spawn_listen_worker(
            &detailed_issue,
            &workspace,
            &workpad_comment,
            Some(backlog_issue.issue.identifier.as_str()),
        ) {
            Ok(pid) => Ok(self.build_session(
                &detailed_issue,
                SessionPhase::Running,
                compact_pickup_summary(workpad_reused, &attachment_context, pid),
                SessionArtifacts {
                    brief_path,
                    backlog_issue: Some(&backlog_issue.issue),
                    backlog_path: Some(backlog_issue.issue_dir.display().to_string()),
                    workspace: Some(&workspace),
                    workpad_comment: Some(&workpad_comment),
                    pid: Some(pid),
                    turns: Some(0),
                    log_path: Some(log_path.display().to_string()),
                },
                updated_at_epoch_seconds,
            )),
            Err(_error) => {
                let blocked = blocked_reason(BlockedCategory::Infra, "worker launch failed", true);
                Ok(self.build_blocked_session(
                    &detailed_issue,
                    blocked.clone(),
                    compact_session_summary([
                        Some(blocked.summary_headline()),
                        Some("local backlog".to_string()),
                    ]),
                    SessionArtifacts {
                        brief_path,
                        backlog_issue: Some(&backlog_issue.issue),
                        backlog_path: Some(backlog_issue.issue_dir.display().to_string()),
                        workspace: Some(&workspace),
                        workpad_comment: Some(&workpad_comment),
                        log_path: Some(log_path.display().to_string()),
                        ..SessionArtifacts::default()
                    },
                    updated_at_epoch_seconds,
                ))
            }
        }
    }

    fn skip_reason_with_viewer(
        &self,
        issue: &IssueSummary,
        viewer: Option<&UserRef>,
    ) -> Option<String> {
        let mut reasons = Vec::new();

        if let Some(reason) = required_label_skip_reason(&self.listen_settings, issue) {
            reasons.push(reason);
        }

        if let Some(reason) = self.assignee_scope_skip_reason_with_viewer(issue, viewer) {
            reasons.push(reason);
        }

        (!reasons.is_empty()).then(|| reasons.join("; "))
    }

    fn watch_scope_label(&self) -> String {
        self.watch_scope_label_with(self.viewer.as_ref())
    }

    fn watch_scope_label_with(&self, viewer: Option<&UserRef>) -> String {
        render_watch_scope(self.listen_settings.assignment_scope(), viewer)
    }

    #[cfg(test)]
    fn assignee_scope_skip_reason(&self, issue: &IssueSummary) -> Option<String> {
        self.assignee_scope_skip_reason_with_viewer(issue, self.viewer.as_ref())
    }

    fn assignee_scope_skip_reason_with_viewer(
        &self,
        issue: &IssueSummary,
        viewer: Option<&UserRef>,
    ) -> Option<String> {
        let viewer = viewer?;
        match self.listen_settings.assignment_scope() {
            ListenAssignmentScope::Any => None,
            ListenAssignmentScope::ViewerOnly => match issue.assignee.as_ref() {
                Some(assignee) if assignee.id == viewer.id => None,
                Some(assignee) => Some(format!(
                    "assigned to `{}` instead of `{}`",
                    assignee.name, viewer.name
                )),
                None => Some(format!("unassigned; only `{}` is in scope", viewer.name)),
            },
            ListenAssignmentScope::ViewerOrUnassigned => match issue.assignee.as_ref() {
                Some(assignee) if assignee.id == viewer.id => None,
                Some(assignee) => Some(format!(
                    "assigned to `{}` instead of `{}`",
                    assignee.name, viewer.name
                )),
                None => None,
            },
        }
    }

    async fn resolve_cycle_viewer(&self) -> Result<Option<UserRef>> {
        match self.listen_settings.assignment_scope() {
            ListenAssignmentScope::Any => Ok(None),
            ListenAssignmentScope::ViewerOnly | ListenAssignmentScope::ViewerOrUnassigned => {
                self.service.viewer().await.map(Some)
            }
        }
    }

    fn filters_with_viewer(&self, viewer: Option<&UserRef>) -> IssueListFilters {
        IssueListFilters {
            assignee: issue_assignee_filter(self.listen_settings.assignment_scope(), viewer),
            ..self.filters.clone()
        }
    }

    #[cfg(test)]
    fn session_drop_reason(&self, issue: &IssueSummary) -> Option<String> {
        self.session_drop_reason_with_viewer(issue, self.viewer.as_ref())
    }

    fn session_drop_reason_with_viewer(
        &self,
        issue: &IssueSummary,
        viewer: Option<&UserRef>,
    ) -> Option<String> {
        let viewer = viewer?;
        match self.listen_settings.assignment_scope() {
            ListenAssignmentScope::Any => None,
            ListenAssignmentScope::ViewerOnly => match issue.assignee.as_ref() {
                Some(assignee) if assignee.id == viewer.id => None,
                Some(_) => Some("session ended: ticket reassigned".to_string()),
                None => Some("session ended: ticket became unassigned".to_string()),
            },
            ListenAssignmentScope::ViewerOrUnassigned => match issue.assignee.as_ref() {
                Some(assignee) if assignee.id == viewer.id => None,
                Some(_) => Some("session ended: ticket reassigned".to_string()),
                None => None,
            },
        }
    }

    fn build_session(
        &self,
        issue: &IssueSummary,
        phase: SessionPhase,
        summary: String,
        artifacts: SessionArtifacts<'_>,
        updated_at_epoch_seconds: u64,
    ) -> AgentSession {
        AgentSession {
            issue_id: Some(issue.id.clone()),
            issue_identifier: issue.identifier.clone(),
            issue_title: issue.title.clone(),
            project_name: issue.project.as_ref().map(|project| project.name.clone()),
            team_key: issue.team.key.clone(),
            issue_url: issue.url.clone(),
            phase,
            lifecycle: Some(derive_session_lifecycle(
                phase,
                None,
                None,
                &PullRequestSummary::default(),
                None,
            )),
            summary,
            blocked: None,
            brief_path: artifacts.brief_path,
            backlog_issue_identifier: artifacts
                .backlog_issue
                .map(|backlog_issue| backlog_issue.identifier.clone()),
            backlog_issue_title: artifacts
                .backlog_issue
                .map(|backlog_issue| backlog_issue.title.clone()),
            backlog_path: artifacts.backlog_path,
            workspace_path: artifacts
                .workspace
                .map(|entry| entry.workspace_path.display().to_string()),
            branch: artifacts.workspace.map(|entry| entry.branch.clone()),
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: artifacts.workpad_comment.map(|comment| comment.id.clone()),
            started_at_epoch_seconds: updated_at_epoch_seconds,
            updated_at_epoch_seconds,
            pid: artifacts.pid.filter(|pid| *pid > 0),
            session_id: None,
            latest_resume_handle: None,
            context_budget_tokens: Some(self.worker_context_budget_tokens),
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: None,
            turns: artifacts.turns.or(Some(0)),
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: artifacts.log_path,
            origin: SessionOrigin::Listen,
        }
    }

    fn build_blocked_session(
        &self,
        issue: &IssueSummary,
        blocked: BlockedReason,
        summary: String,
        artifacts: SessionArtifacts<'_>,
        updated_at_epoch_seconds: u64,
    ) -> AgentSession {
        let mut session = self.build_session(
            issue,
            SessionPhase::Blocked,
            summary,
            artifacts,
            updated_at_epoch_seconds,
        );
        session.blocked = Some(blocked);
        session.lifecycle = Some(derive_session_lifecycle(
            session.phase,
            session.blocked.as_ref(),
            None,
            &session.pull_request,
            session.latest_stale_worker_failure.as_ref(),
        ));
        session
    }

    fn spawn_listen_worker(
        &self,
        issue: &IssueSummary,
        workspace: &TicketWorkspace,
        workpad_comment: &IssueComment,
        backlog_issue_identifier: Option<&str>,
    ) -> Result<u32> {
        self.spawn_listen_worker_from_context(
            issue,
            &workspace.workspace_path,
            &workpad_comment.id,
            backlog_issue_identifier,
            ListenWorkerSpawnReason::Pickup,
        )
    }

    fn agent_log_path(&self, identifier: &str) -> PathBuf {
        self.store.log_path(identifier)
    }

    fn spawn_listen_worker_from_context(
        &self,
        issue: &IssueSummary,
        workspace_path: &Path,
        workpad_comment_id: &str,
        backlog_issue_identifier: Option<&str>,
        spawn_reason: ListenWorkerSpawnReason,
    ) -> Result<u32> {
        let current_exe = std::env::current_exe().with_context(|| {
            format!(
                "failed to resolve the {} executable",
                crate::branding::COMMAND_NAME
            )
        })?;
        let workspace_path = canonicalize_existing_dir(workspace_path)?;
        worker_lease::ensure_listen_worker_lease_available(&workspace_path, &issue.identifier)?;
        let log_path = self.agent_log_path(&issue.identifier);
        if let Some(parent) = log_path.parent() {
            fs::create_dir_all(parent)
                .with_context(|| format!("failed to create `{}`", parent.display()))?;
        }
        let stdout = fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(&log_path)
            .with_context(|| format!("failed to open `{}`", log_path.display()))?;
        let stderr = fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(&log_path)
            .with_context(|| format!("failed to open `{}`", log_path.display()))?;

        let mut command = Command::new(current_exe);
        command.current_dir(&self.root);
        command.args(build_listen_worker_cli_args(
            &self.root,
            self.store.identity().project_selector.as_deref(),
            &workspace_path,
            &issue.identifier,
            workpad_comment_id,
            backlog_issue_identifier,
            DEFAULT_LISTEN_MAX_TURNS,
            self.worker_context_budget_tokens,
            self.worker_agent.as_deref(),
            self.worker_model.as_deref(),
            self.worker_reasoning.as_deref(),
        ));
        command.stdout(Stdio::from(stdout));
        command.stderr(Stdio::from(stderr));
        command.stdin(Stdio::null());
        command.env("LINEAR_API_KEY", &self.linear_config.api_key);
        command.env("LINEAR_API_URL", &self.linear_config.api_url);
        if let Some(team) = self.linear_config.default_team.as_deref() {
            command.env("LINEAR_TEAM", team);
        }
        command.env("METASTACK_WORKSPACE_PATH", &workspace_path);
        command.env("METASTACK_SOURCE_ROOT", &self.root);
        command.env(
            "METASTACK_LISTEN_PARENT_PID",
            std::process::id().to_string(),
        );
        command.env("METASTACK_LISTEN_SPAWN_REASON", spawn_reason.label());
        append_worker_lifecycle_log(
            &log_path,
            WorkerLifecycleLog {
                event: "spawn",
                parent_pid: Some(std::process::id()),
                worker_pid: None,
                issue_identifier: &issue.identifier,
                workspace_path: &workspace_path,
                turn_number: None,
                spawn_reason: spawn_reason.label(),
                exit_reason: None,
                lease_owner: false,
            },
        )?;

        let mut child = command
            .spawn()
            .context("failed to launch the hidden listen worker")?;
        let pid = child.id();
        wait_for_worker_lease(&mut child, &workspace_path, &issue.identifier, pid)?;
        spawn_worker_reaper(
            issue.identifier.clone(),
            pid,
            child,
            log_path.clone(),
            workspace_path.clone(),
            spawn_reason,
        );

        Ok(pid)
    }
}

fn expected_ticket_workspace_path(root: &Path, issue_identifier: &str) -> Result<PathBuf> {
    let workspace_path = ticket_workspace_root(root)?.join(issue_identifier);
    if workspace_path.is_dir() {
        canonicalize_existing_dir(&workspace_path)
    } else {
        Ok(workspace_path)
    }
}

struct WorkerLifecycleLog<'a> {
    event: &'a str,
    parent_pid: Option<u32>,
    worker_pid: Option<u32>,
    issue_identifier: &'a str,
    workspace_path: &'a Path,
    turn_number: Option<u32>,
    spawn_reason: &'a str,
    exit_reason: Option<&'a str>,
    lease_owner: bool,
}

fn append_worker_lifecycle_log(log_path: &Path, event: WorkerLifecycleLog<'_>) -> Result<()> {
    use std::io::Write as _;

    let parent = log_path.parent().unwrap_or_else(|| Path::new("."));
    fs::create_dir_all(parent)
        .with_context(|| format!("failed to create `{}`", parent.display()))?;
    let mut log = fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(log_path)
        .with_context(|| format!("failed to open `{}`", log_path.display()))?;
    writeln!(
        log,
        "listen-worker lifecycle event={} parent_pid={} worker_pid={} issue={} workspace={} turn={} spawn_reason={} exit_reason={} lease_owner={}",
        event.event,
        event
            .parent_pid
            .map(|pid| pid.to_string())
            .unwrap_or_else(|| "-".to_string()),
        event
            .worker_pid
            .map(|pid| pid.to_string())
            .unwrap_or_else(|| "-".to_string()),
        event.issue_identifier,
        event.workspace_path.display(),
        event
            .turn_number
            .map(|turn| turn.to_string())
            .unwrap_or_else(|| "-".to_string()),
        event.spawn_reason,
        event.exit_reason.unwrap_or("-"),
        event.lease_owner,
    )
    .with_context(|| format!("failed to write `{}`", log_path.display()))
}

fn wait_for_worker_lease(
    child: &mut Child,
    workspace_path: &Path,
    issue_identifier: &str,
    worker_pid: u32,
) -> Result<()> {
    let deadline = Instant::now() + WORKER_LEASE_STARTUP_TIMEOUT;
    loop {
        match child.try_wait() {
            Ok(Some(status)) => {
                bail!(
                    "listen worker pid {} exited before acquiring the workspace lease for `{}` (status {})",
                    worker_pid,
                    issue_identifier,
                    status
                );
            }
            Ok(None) => {}
            Err(error) => {
                return Err(error)
                    .with_context(|| format!("failed to inspect listen worker pid {worker_pid}"));
            }
        }

        if let Some(lease) = worker_lease::load_listen_worker_lease(workspace_path)
            && lease.worker_pid == worker_pid
        {
            return Ok(());
        }

        if Instant::now() >= deadline {
            let _ = child.kill();
            let _ = child.wait();
            bail!(
                "listen worker pid {} did not acquire the workspace lease for `{}` within {}s",
                worker_pid,
                issue_identifier,
                WORKER_LEASE_STARTUP_TIMEOUT.as_secs()
            );
        }

        thread::sleep(Duration::from_millis(50));
    }
}

fn spawn_worker_reaper(
    issue_identifier: String,
    worker_pid: u32,
    mut child: Child,
    log_path: PathBuf,
    workspace_path: PathBuf,
    spawn_reason: ListenWorkerSpawnReason,
) {
    let builder = thread::Builder::new().name(format!("listen-worker-reaper-{worker_pid}"));
    if let Err(error) = builder.spawn(move || match child.wait() {
        Ok(status) => {
            let exit_reason = if status.success() {
                "exit_success".to_string()
            } else {
                status
                    .code()
                    .map(|code| format!("exit_code_{code}"))
                    .unwrap_or_else(|| "terminated_by_signal".to_string())
            };
            let _ = append_worker_lifecycle_log(
                &log_path,
                WorkerLifecycleLog {
                    event: "exit",
                    parent_pid: Some(std::process::id()),
                    worker_pid: Some(worker_pid),
                    issue_identifier: &issue_identifier,
                    workspace_path: &workspace_path,
                    turn_number: None,
                    spawn_reason: spawn_reason.label(),
                    exit_reason: Some(&exit_reason),
                    lease_owner: false,
                },
            );
        }
        Err(error) => {
            eprintln!("warning: failed to reap listen worker pid {worker_pid}: {error:#}");
        }
    }) {
        eprintln!("warning: failed to spawn listen worker reaper for pid {worker_pid}: {error:#}");
    }
}

fn merge_cycle_sessions(
    persisted_sessions: Vec<AgentSession>,
    daemon_sessions: Vec<AgentSession>,
) -> Vec<AgentSession> {
    let mut merged = persisted_sessions;
    for daemon_session in daemon_sessions {
        if let Some(existing) = merged
            .iter_mut()
            .find(|session| session.issue_matches(&daemon_session.issue_identifier))
        {
            if should_replace_persisted_session(existing, &daemon_session) {
                *existing = merge_monotonic_session_fields(existing, daemon_session);
            }
        } else {
            merged.push(daemon_session);
        }
    }
    merged
}

fn merge_monotonic_session_fields(
    persisted_session: &AgentSession,
    mut daemon_session: AgentSession,
) -> AgentSession {
    if daemon_session.started_at_epoch_seconds == 0 {
        daemon_session.started_at_epoch_seconds = persisted_session.started_at_epoch_seconds;
    }

    if daemon_session.stale_worker_recovery_attempt_count
        < persisted_session.stale_worker_recovery_attempt_count
    {
        daemon_session.stale_worker_recovery_attempt_count =
            persisted_session.stale_worker_recovery_attempt_count;
    }

    if daemon_session.latest_stale_worker_failure.is_none()
        && persisted_session.latest_stale_worker_failure.is_some()
    {
        daemon_session.latest_stale_worker_failure =
            persisted_session.latest_stale_worker_failure.clone();
    }

    if daemon_session.lifecycle.is_none() && persisted_session.lifecycle.is_some() {
        daemon_session.lifecycle = persisted_session.lifecycle.clone();
    }

    if session_phase_regressed(persisted_session, &daemon_session) {
        daemon_session.phase = persisted_session.phase;
        daemon_session.summary = persisted_session.summary.clone();
        daemon_session.blocked = persisted_session.blocked.clone();
        daemon_session.lifecycle = persisted_session.lifecycle.clone();
    }

    if blocked_metadata_regressed(persisted_session, &daemon_session) {
        daemon_session.phase = persisted_session.phase;
        daemon_session.blocked = persisted_session.blocked.clone();
        daemon_session.lifecycle = persisted_session.lifecycle.clone();
        daemon_session.summary = persisted_session.summary.clone();
    }

    daemon_session.canonical =
        merge_monotonic_canonical(&persisted_session.canonical, &daemon_session.canonical);

    if turn_history_regressed(persisted_session, &daemon_session) {
        daemon_session.turn_history = persisted_session.turn_history.clone();
    }

    if latest_resume_handle_regressed(persisted_session, &daemon_session) {
        daemon_session.latest_resume_handle = persisted_session.latest_resume_handle.clone();
    }

    if persisted_session.context_budget_tokens.is_some() {
        daemon_session.context_budget_tokens = persisted_session.context_budget_tokens;
    }

    if turns_regressed(persisted_session, &daemon_session) {
        daemon_session.turns = persisted_session.turns;
    }

    daemon_session
}

fn blocked_metadata_regressed(
    persisted_session: &AgentSession,
    daemon_session: &AgentSession,
) -> bool {
    persisted_session.blocked.is_some()
        && persisted_session.blocked != daemon_session.blocked
        && session_phase_rank(daemon_session.phase) <= session_phase_rank(persisted_session.phase)
}

fn session_phase_regressed(
    persisted_session: &AgentSession,
    daemon_session: &AgentSession,
) -> bool {
    session_phase_rank(daemon_session.phase) < session_phase_rank(persisted_session.phase)
}

fn merge_monotonic_canonical(
    persisted: &CanonicalSessionData,
    daemon: &CanonicalSessionData,
) -> CanonicalSessionData {
    let mut merged = daemon.clone();

    if merged.provider.is_none() {
        merged.provider = persisted.provider.clone();
    }
    if merged.model.is_none() {
        merged.model = persisted.model.clone();
    }
    if merged.reasoning.is_none() {
        merged.reasoning = persisted.reasoning.clone();
    }
    if token_usage_regressed(&persisted.tokens, &merged.tokens) {
        merged.tokens = persisted.tokens.clone();
    }
    if merged.repair.is_none() && persisted.repair.is_some() {
        merged.repair = persisted.repair.clone();
    }

    merged
}

fn token_usage_regressed(persisted: &TokenUsage, daemon: &TokenUsage) -> bool {
    if !persisted.is_known() {
        return false;
    }

    token_usage_field_count(daemon) < token_usage_field_count(persisted)
        || daemon.total().unwrap_or_default() < persisted.total().unwrap_or_default()
}

fn token_usage_field_count(tokens: &TokenUsage) -> u8 {
    u8::from(tokens.input.is_some()) + u8::from(tokens.output.is_some())
}

fn turn_history_regressed(persisted_session: &AgentSession, daemon_session: &AgentSession) -> bool {
    let persisted = &persisted_session.turn_history;
    let daemon = &daemon_session.turn_history;
    !persisted.is_empty()
        && (daemon.len() < persisted.len()
            || !daemon
                .iter()
                .zip(persisted.iter())
                .all(|(daemon_entry, persisted_entry)| daemon_entry == persisted_entry))
}

fn latest_resume_handle_regressed(
    persisted_session: &AgentSession,
    daemon_session: &AgentSession,
) -> bool {
    persisted_session.latest_resume_handle.is_some()
        && daemon_session.latest_resume_handle != persisted_session.latest_resume_handle
}

fn turns_regressed(persisted_session: &AgentSession, daemon_session: &AgentSession) -> bool {
    daemon_session.turns.unwrap_or_default() < persisted_session.turns.unwrap_or_default()
}

fn should_replace_persisted_session(
    persisted_session: &AgentSession,
    daemon_session: &AgentSession,
) -> bool {
    let merged_candidate =
        merge_monotonic_session_fields(persisted_session, daemon_session.clone());

    match daemon_session
        .updated_at_epoch_seconds
        .cmp(&persisted_session.updated_at_epoch_seconds)
    {
        std::cmp::Ordering::Greater => true,
        std::cmp::Ordering::Less => false,
        std::cmp::Ordering::Equal => {
            session_progress_rank(&merged_candidate) > session_progress_rank(persisted_session)
                || merged_candidate != *persisted_session
        }
    }
}

fn session_progress_rank(
    session: &AgentSession,
) -> (u16, u32, u64, usize, u8, u8, u8, u8, u8, u8, u8, u8) {
    (
        u16::from(session_phase_rank(session.phase)) * 8
            + u16::from(session_lifecycle_rank(session)),
        session.turns.unwrap_or_default(),
        session.canonical.tokens.total().unwrap_or_default(),
        session.turn_history.len(),
        u8::from(session.canonical.provider.is_some()),
        u8::from(session.canonical.model.is_some()),
        u8::from(session.canonical.reasoning.is_some()),
        u8::from(session.latest_resume_handle.is_some()),
        u8::from(session.session_id.is_some()),
        u8::from(session.pending_linear_sync.is_some()),
        u8::from(session.last_timeout.is_some()),
        u8::from(session.blocked.is_some()),
    )
}

fn session_lifecycle_rank(session: &AgentSession) -> u8 {
    match session.effective_lifecycle().outcome {
        SessionLifecycleOutcome::Active => 0,
        SessionLifecycleOutcome::Paused => 1,
        SessionLifecycleOutcome::Blocked => 2,
        SessionLifecycleOutcome::Truncated => 3,
        SessionLifecycleOutcome::Completed => 4,
    }
}

fn session_phase_rank(phase: SessionPhase) -> u8 {
    match phase {
        SessionPhase::Claimed => 0,
        SessionPhase::BriefReady => 1,
        SessionPhase::Running => 2,
        SessionPhase::Reviewing => 3,
        SessionPhase::FinalReview => 4,
        SessionPhase::Verifying => 5,
        SessionPhase::Validating => 6,
        SessionPhase::Publishing => 7,
        SessionPhase::Paused => 8,
        SessionPhase::Blocked => 9,
        SessionPhase::Completed => 10,
    }
}

pub async fn run_listen_worker(args: &ListenWorkerArgs) -> Result<()> {
    worker::run_listen_worker(args).await
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct WorkspaceSnapshot {
    head_sha: String,
    status_entries: Vec<String>,
}

fn write_listen_session(
    root: &Path,
    project_selector: Option<&str>,
    session: AgentSession,
) -> Result<()> {
    ListenProjectStore::resolve(root, project_selector)?.upsert_session(session)
}

fn current_workspace_branch(workspace_path: &Path) -> Result<String> {
    git_stdout(workspace_path, &["rev-parse", "--abbrev-ref", "HEAD"])
        .context("failed to inspect the workspace branch")
}

fn agent_log_path(root: &Path, project_selector: Option<&str>, identifier: &str) -> PathBuf {
    ListenProjectStore::resolve(root, project_selector)
        .map(|store| store.log_path(identifier))
        .unwrap_or_else(|_| PathBuf::from(format!("{identifier}.log")))
}

fn capture_workspace_snapshot(
    workspace_path: &Path,
    issue_identifier: &str,
) -> Result<WorkspaceSnapshot> {
    let head_sha = git_stdout(workspace_path, &["rev-parse", "HEAD"])?;
    let status = git_stdout(
        workspace_path,
        &["status", "--short", "--untracked-files=all"],
    )?;
    let ignored_brief_path = display_path(
        &PlanningPaths::new(workspace_path)
            .agent_briefs_dir
            .join(format!("{issue_identifier}.md")),
        workspace_path,
    );
    let status_entries = status
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .filter(|line| !line.contains(&ignored_brief_path))
        .map(str::to_string)
        .collect::<Vec<_>>();

    Ok(WorkspaceSnapshot {
        head_sha,
        status_entries,
    })
}

fn compare_workspace_snapshots(
    workspace_path: &Path,
    before: &WorkspaceSnapshot,
    after: &WorkspaceSnapshot,
) -> Result<TurnProgress> {
    let before_entries = before
        .status_entries
        .iter()
        .cloned()
        .collect::<BTreeSet<_>>();
    let after_entries = after
        .status_entries
        .iter()
        .cloned()
        .collect::<BTreeSet<_>>();
    let mut changed_entries = before_entries
        .symmetric_difference(&after_entries)
        .cloned()
        .collect::<Vec<_>>();
    if before.head_sha != after.head_sha {
        changed_entries.extend(committed_change_entries(
            workspace_path,
            &before.head_sha,
            &after.head_sha,
        )?);
    }
    changed_entries.sort();
    changed_entries.dedup();

    let mut planning_entries = Vec::new();
    let mut implementation_entries = Vec::new();
    let mut volatile_validation_entries = Vec::new();

    for entry in changed_entries {
        if workspace_entry_is_planning_artifact(&entry) {
            planning_entries.push(entry);
        } else if workspace_entry_is_volatile_validation_artifact(
            workspace_path,
            &before.head_sha,
            &after.head_sha,
            &entry,
        )? {
            volatile_validation_entries.push(entry);
        } else {
            implementation_entries.push(entry);
        }
    }

    Ok(TurnProgress {
        planning_entries,
        implementation_entries,
        volatile_validation_entries,
    })
}

fn committed_change_entries(
    workspace_path: &Path,
    before_head: &str,
    after_head: &str,
) -> Result<Vec<String>> {
    let diff = git_stdout(
        workspace_path,
        &["diff", "--name-only", before_head, after_head],
    )?;
    Ok(diff
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .map(str::to_string)
        .collect())
}

fn workspace_entry_is_planning_artifact(entry: &str) -> bool {
    let path = workspace_entry_path(entry);
    path.starts_with(&format!("{}/", crate::branding::PROJECT_DIR))
}

fn workspace_entry_path(entry: &str) -> &str {
    let path = if let Some((_, path)) = entry.split_once(' ') {
        path.trim()
    } else {
        entry.trim()
    };
    path.rsplit(" -> ").next().unwrap_or(path).trim()
}

fn workspace_entry_is_validation_artifact(entry: &str) -> bool {
    let path = workspace_entry_path(entry);
    path.starts_with("artifacts/validation/") && path.ends_with(".md")
}

fn workspace_entry_is_volatile_validation_artifact(
    workspace_path: &Path,
    before_head: &str,
    after_head: &str,
    entry: &str,
) -> Result<bool> {
    if !workspace_entry_is_validation_artifact(entry) {
        return Ok(false);
    }

    let path = workspace_entry_path(entry);
    let mut diff = String::new();
    if before_head != after_head {
        diff.push_str(&git_stdout(
            workspace_path,
            &["diff", "--unified=0", before_head, after_head, "--", path],
        )?);
    }
    diff.push_str(&git_stdout(
        workspace_path,
        &["diff", "--unified=0", "--", path],
    )?);
    diff.push_str(&git_stdout(
        workspace_path,
        &["diff", "--cached", "--unified=0", "--", path],
    )?);

    let changed_lines = validation_artifact_changed_lines(&diff);
    Ok(!changed_lines.is_empty()
        && changed_lines
            .iter()
            .all(|line| validation_artifact_line_is_volatile(line)))
}

fn validation_artifact_changed_lines(diff: &str) -> Vec<String> {
    diff.lines()
        .filter_map(|line| {
            if line.starts_with("+++") || line.starts_with("---") {
                return None;
            }
            line.strip_prefix('+')
                .or_else(|| line.strip_prefix('-'))
                .map(|line| line.trim().to_string())
        })
        .collect()
}

fn validation_artifact_line_is_volatile(line: &str) -> bool {
    let line = line.trim();
    if line.is_empty() || line_starts_with_commit_sha_bullet(line) {
        return true;
    }

    let lower = line.to_ascii_lowercase();
    const VOLATILE_PHRASES: &[&str] = &[
        "date:",
        "captured at",
        "execution turn",
        "worktree state at capture",
        "push state at capture",
        "pr state at capture",
        "pr body status at capture",
        "branch diff vs",
        "current workspace head",
        "current branch head",
        "current workspace sha",
        "latest commit",
        "latest sha",
        "pr head",
        "remote branch",
        "github actions run id",
        "workflow run id",
        "exact-head",
        "exact head",
        "exact final sha",
        "current sha",
        "synchronized through",
        "pending commit",
        "final artifact delta",
        "final validation-artifact refresh",
        "final handoff commit",
        "checkpoint commits",
        "checkpoint lineage",
        "commit lineage",
        "docs-only handoff commits",
        "use the git branch head",
        "matches local `head`",
        "points at the same",
    ];

    VOLATILE_PHRASES.iter().any(|phrase| lower.contains(phrase)) || contains_iso_timestamp(line)
}

fn line_starts_with_commit_sha_bullet(line: &str) -> bool {
    let Some(rest) = line.strip_prefix("- `") else {
        return false;
    };
    let Some((token, _)) = rest.split_once('`') else {
        return false;
    };
    (7..=40).contains(&token.len()) && token.chars().all(|ch| ch.is_ascii_hexdigit())
}

fn contains_iso_timestamp(line: &str) -> bool {
    let bytes = line.as_bytes();
    bytes.windows("2026-04-17T18:03:54Z".len()).any(|window| {
        window.get(4) == Some(&b'-')
            && window.get(7) == Some(&b'-')
            && window.get(10) == Some(&b'T')
            && window.get(13) == Some(&b':')
            && window.get(16) == Some(&b':')
            && window.iter().enumerate().all(|(index, byte)| {
                matches!(index, 4 | 7 | 10 | 13 | 16) || byte.is_ascii_digit() || *byte == b'Z'
            })
    })
}

fn workspace_has_meaningful_progress(
    workspace_path: &Path,
    allow_planning_artifacts: bool,
) -> Result<bool> {
    let ahead_count = git_stdout(
        workspace_path,
        &["rev-list", "--count", "origin/main..HEAD"],
    )?;
    if ahead_count.trim().parse::<u64>().unwrap_or(0) > 0 {
        return Ok(true);
    }

    let status = git_stdout(
        workspace_path,
        &["status", "--short", "--untracked-files=all"],
    )?;
    Ok(status
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .any(|line| allow_planning_artifacts || !workspace_entry_is_planning_artifact(line)))
}

fn active_workpad_comment(issue: &IssueSummary) -> Option<IssueComment> {
    issue.comments.iter().find_map(|comment| {
        (comment.resolved_at.is_none() && comment.body.contains("## Codex Workpad"))
            .then(|| comment.clone())
    })
}

fn backlog_progress_for_issue_dir(
    workspace_path: &Path,
    identifier: &str,
) -> Result<BacklogProgress> {
    let issue_dir = PlanningPaths::new(workspace_path).backlog_issue_dir(identifier);
    if !issue_dir.is_dir() {
        bail!(
            "technical backlog directory `{}` is missing",
            issue_dir.display()
        );
    }

    let index_path = issue_dir.join("index.md");
    if index_path.is_file() {
        let index_contents = fs::read_to_string(&index_path)
            .with_context(|| format!("failed to read `{}`", index_path.display()))?;
        if let Some(section) = marked_section_body(&index_contents, "metastack-listen-progress") {
            return Ok(parse_checklist_progress(section));
        }
    }

    let mut progress = BacklogProgress::default();
    for entry in WalkDir::new(&issue_dir) {
        let entry = entry.with_context(|| {
            format!(
                "failed to traverse technical backlog directory `{}`",
                issue_dir.display()
            )
        })?;
        if !entry.file_type().is_file() {
            continue;
        }
        if entry
            .path()
            .extension()
            .and_then(|extension| extension.to_str())
            != Some("md")
        {
            continue;
        }

        let contents = fs::read_to_string(entry.path())
            .with_context(|| format!("failed to read `{}`", entry.path().display()))?;
        progress = combine_backlog_progress(progress, parse_checklist_progress(&contents));
    }

    Ok(progress)
}

fn combine_backlog_progress(left: BacklogProgress, right: BacklogProgress) -> BacklogProgress {
    BacklogProgress {
        completed: left.completed + right.completed,
        total: left.total + right.total,
        next_step: left.next_step.or(right.next_step),
    }
}

fn parse_checklist_progress(contents: &str) -> BacklogProgress {
    let mut progress = BacklogProgress::default();

    for line in contents.lines() {
        let trimmed = line.trim_start();
        if trimmed.starts_with("- [x] ")
            || trimmed.starts_with("- [X] ")
            || trimmed.starts_with("* [x] ")
            || trimmed.starts_with("* [X] ")
        {
            let Some(label) = checklist_item_label(trimmed) else {
                continue;
            };
            if is_placeholder_checklist_label(&label) {
                continue;
            }
            progress.completed += 1;
            progress.total += 1;
        } else if trimmed.starts_with("- [ ] ") || trimmed.starts_with("* [ ] ") {
            let Some(label) = checklist_item_label(trimmed) else {
                continue;
            };
            if is_placeholder_checklist_label(&label) {
                continue;
            }
            progress.total += 1;
            if progress.next_step.is_none() {
                progress.next_step = Some(label);
            }
        }
    }

    progress
}

fn checklist_item_label(line: &str) -> Option<String> {
    let (_, item) = line.split_once(']')?;
    let item = item
        .trim()
        .trim_start_matches(|ch: char| ch.is_ascii_digit() || ch == '.' || ch == '\\')
        .trim();
    (!item.is_empty()).then(|| item.to_string())
}

fn marked_section_body<'a>(contents: &'a str, marker: &str) -> Option<&'a str> {
    let start = format!("<!-- {marker}:start -->");
    let end = format!("<!-- {marker}:end -->");
    let start_index = contents.find(&start)?;
    let body_start = start_index + start.len();
    let remainder = contents.get(body_start..)?;
    let end_offset = remainder.find(&end)?;
    remainder.get(..end_offset).map(str::trim)
}

fn is_placeholder_checklist_label(label: &str) -> bool {
    let normalized = label.trim();
    normalized.eq_ignore_ascii_case("No completed items recorded yet.")
        || normalized.eq_ignore_ascii_case("No explicit validation status recorded.")
        || normalized.eq_ignore_ascii_case("Confirm owners/reviewers in `contacts.md`.")
        || normalized.eq_ignore_ascii_case("Follow-up action 1")
        || normalized.eq_ignore_ascii_case("Follow-up action 2")
        || normalized.eq_ignore_ascii_case("Remove consumer-side ad hoc transforms.")
        || normalized.eq_ignore_ascii_case("Task 1")
        || normalized.eq_ignore_ascii_case("Task 2")
        || normalized.eq_ignore_ascii_case("Task 3")
        || normalized.eq_ignore_ascii_case("Criterion 1")
        || normalized.eq_ignore_ascii_case("Criterion 2")
        || normalized.eq_ignore_ascii_case("Criterion 3")
}

const TICKET_INLINE_SECTION_HEADINGS: &[&str] = &[
    "Validation",
    "Test Plan",
    "Testing",
    "Acceptance Criteria",
    "Acceptance",
    "Requirements",
];

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct TicketInlineSection {
    pub(crate) heading: String,
    pub(crate) body: String,
}

impl TicketInlineSection {
    pub(crate) fn render(&self) -> String {
        if self.body.is_empty() {
            self.heading.clone()
        } else {
            format!("{}\n{}", self.heading, self.body)
        }
    }
}

pub(crate) fn extract_ticket_inline_sections(
    description: Option<&str>,
) -> Vec<TicketInlineSection> {
    extract_markdown_sections(
        description.unwrap_or_default(),
        TICKET_INLINE_SECTION_HEADINGS,
    )
}

pub(crate) fn strip_ticket_inline_sections(body: &str) -> String {
    let normalized_headings = normalize_section_headings(TICKET_INLINE_SECTION_HEADINGS);
    let mut lines = Vec::new();
    let mut skipping_heading_level: Option<usize> = None;

    for raw_line in body.lines() {
        if let Some(heading) = parse_markdown_heading(raw_line) {
            if skipping_heading_level.is_some_and(|level| heading.level > level) {
                continue;
            }
            let skipping = normalized_headings
                .iter()
                .any(|candidate| candidate == &heading.normalized);
            skipping_heading_level = skipping.then_some(heading.level);
            if !skipping {
                lines.push(raw_line.to_string());
            }
            continue;
        }
        if skipping_heading_level.is_none() {
            lines.push(raw_line.to_string());
        }
    }

    trim_surrounding_blank_lines(lines).join("\n")
}

fn extract_linear_acceptance_criteria(description: Option<&str>) -> Vec<String> {
    extract_markdown_section_bullets(
        description.unwrap_or_default(),
        &["Acceptance Criteria", "Acceptance", "Requirements"],
    )
}

fn extract_markdown_section_bullets(body: &str, headings: &[&str]) -> Vec<String> {
    let section = extract_markdown_section(body, headings).unwrap_or_default();
    section
        .lines()
        .filter_map(|line| {
            let trimmed = line.trim();
            trimmed
                .strip_prefix("- ")
                .or_else(|| trimmed.strip_prefix("* "))
                .map(str::trim)
                .filter(|value| !value.is_empty())
                .map(str::to_string)
        })
        .collect()
}

fn extract_markdown_section(body: &str, headings: &[&str]) -> Option<String> {
    extract_markdown_sections(body, headings)
        .into_iter()
        .next()
        .map(|section| section.body)
}

fn extract_markdown_sections(body: &str, headings: &[&str]) -> Vec<TicketInlineSection> {
    let normalized_headings = normalize_section_headings(headings);
    let mut sections = Vec::new();
    let mut current_heading: Option<(String, usize)> = None;
    let mut current_lines = Vec::new();

    let flush_current = |sections: &mut Vec<TicketInlineSection>,
                         current_heading: &mut Option<(String, usize)>,
                         current_lines: &mut Vec<String>| {
        let Some((heading, _)) = current_heading.take() else {
            current_lines.clear();
            return;
        };
        sections.push(TicketInlineSection {
            heading,
            body: trim_trailing_blank_lines(std::mem::take(current_lines)).join("\n"),
        });
    };

    for raw_line in body.lines() {
        if let Some(heading) = parse_markdown_heading(raw_line) {
            if current_heading
                .as_ref()
                .is_some_and(|(_, level)| heading.level > *level)
            {
                current_lines.push(raw_line.to_string());
                continue;
            }
            if current_heading.is_some() {
                flush_current(&mut sections, &mut current_heading, &mut current_lines);
            }
            current_heading = normalized_headings
                .iter()
                .any(|candidate| candidate == &heading.normalized)
                .then(|| (raw_line.to_string(), heading.level));
            continue;
        }

        if current_heading.is_some() {
            current_lines.push(raw_line.to_string());
        }
    }
    if current_heading.is_some() {
        flush_current(&mut sections, &mut current_heading, &mut current_lines);
    }

    sections
}

fn normalize_section_headings(headings: &[&str]) -> Vec<String> {
    headings
        .iter()
        .map(|heading| heading.trim().to_ascii_lowercase())
        .collect()
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct MarkdownHeading {
    level: usize,
    normalized: String,
}

fn parse_markdown_heading(raw_line: &str) -> Option<MarkdownHeading> {
    let trimmed = raw_line.trim();
    let level = trimmed
        .chars()
        .take_while(|character| *character == '#')
        .count();
    if level == 0 {
        return None;
    }

    let heading = trimmed.get(level..)?.trim();
    if heading.is_empty() {
        return None;
    }

    Some(MarkdownHeading {
        level,
        normalized: heading.trim_matches('#').trim().to_ascii_lowercase(),
    })
}

fn trim_trailing_blank_lines(mut lines: Vec<String>) -> Vec<String> {
    while matches!(lines.last(), Some(last) if last.trim().is_empty()) {
        lines.pop();
    }
    lines
}

fn trim_surrounding_blank_lines(mut lines: Vec<String>) -> Vec<String> {
    while matches!(lines.first(), Some(first) if first.trim().is_empty()) {
        lines.remove(0);
    }
    trim_trailing_blank_lines(lines)
}

async fn try_transition_issue_to_review_state<C>(
    service: &LinearService<C>,
    issue: &IssueSummary,
) -> Result<Option<IssueSummary>>
where
    C: LinearClient,
{
    for candidate in REVIEW_STATE_CANDIDATES {
        for attempt in 0..3 {
            match service
                .edit_issue(IssueEditSpec {
                    identifier: issue.identifier.clone(),
                    title: None,
                    description: None,
                    project: None,
                    state: Some((*candidate).to_string()),
                    priority: None,
                    estimate: None,
                    labels: None,
                    parent_identifier: None,
                })
                .await
            {
                Ok(updated) => return Ok(Some(updated)),
                Err(error) if is_missing_review_state_error(&error) => break,
                Err(error) if attempt < 2 && is_transient_linear_read_failure(&error) => {
                    tokio::time::sleep(Duration::from_millis(100)).await;
                }
                Err(error) => return Err(error),
            }
        }
    }

    Ok(None)
}

fn is_missing_review_state_error(error: &anyhow::Error) -> bool {
    let message = error.to_string();
    message.contains("state `") && message.contains("was not found on team")
}

fn is_transient_linear_read_failure(error: &anyhow::Error) -> bool {
    classify_linear_failure(error).is_retryable()
}

fn git_stdout(workspace_path: &Path, args: &[&str]) -> Result<String> {
    let output = Command::new("git")
        .arg("-C")
        .arg(workspace_path)
        .args(args)
        .output()
        .with_context(|| format!("failed to run `git {}`", args.join(" ")))?;
    if !output.status.success() {
        bail!(
            "git {} failed: {}",
            args.join(" "),
            String::from_utf8_lossy(&output.stderr).trim()
        );
    }

    Ok(String::from_utf8_lossy(&output.stdout).trim().to_string())
}

fn listen_issue_is_active(state_name: Option<&str>) -> bool {
    matches!(
        state_name.map(normalize_issue_state_name).as_deref(),
        Some("todo") | Some("in progress") | Some("rework") | Some("merging")
    )
}

fn issue_state_label(issue: &IssueSummary) -> String {
    issue
        .state
        .as_ref()
        .map(|state| state.name.clone())
        .unwrap_or_else(|| "Unknown".to_string())
}

fn issue_team_key(identifier: &str) -> Option<String> {
    identifier.split_once('-').map(|(team, _)| team.to_string())
}

fn normalize_issue_state_name(state_name: &str) -> String {
    state_name.trim().to_ascii_lowercase()
}

fn listen_scope_label(
    team: Option<&str>,
    project_selector: Option<&str>,
    project_label: &str,
) -> String {
    match (team, project_selector) {
        (Some(team), Some(_)) => format!("{team} / {project_label}"),
        (Some(team), None) => team.to_string(),
        (None, Some(_)) => project_label.to_string(),
        (None, None) => "all teams".to_string(),
    }
}

pub fn run_listen_session_list(_: &ListenSessionListArgs) -> Result<String> {
    let projects = ListenProjectStore::list_projects()?;
    if projects.is_empty() {
        return Ok("No stored MetaListen project sessions were found.".to_string());
    }

    let now = now_epoch_seconds();
    let mut lines = vec![
        "Stored MetaListen project sessions:".to_string(),
        "KEY  SOURCE  PHASE  EXIT  PR  UPDATED  ISSUE  PROVIDER  RESUME ID  PROJECT  ROOT"
            .to_string(),
    ];
    for project in projects {
        let latest = project.latest_visible_session();
        let source = if project.latest_visible_session_is_retained() {
            "retained"
        } else if latest.is_some() {
            "active"
        } else {
            "idle"
        };
        let phase = latest
            .map(AgentSession::stage_label)
            .unwrap_or_else(|| "Idle".to_string());
        let exit = latest
            .and_then(AgentSession::exit_label)
            .unwrap_or_else(|| "-".to_string());
        let pr = latest
            .map(AgentSession::pull_request_label)
            .unwrap_or_else(|| "-".to_string());
        let updated = latest
            .map(|session| format_duration(now.saturating_sub(session.updated_at_epoch_seconds)))
            .unwrap_or_else(|| "-".to_string());
        let issue = latest
            .map(|session| session.issue_identifier.clone())
            .unwrap_or_else(|| "-".to_string());
        let provider = latest
            .map(|session| session.provider_label())
            .unwrap_or_else(|| "-".to_string());
        let resume_id = latest
            .map(|session| explicit_resume_id_label(session.latest_resume_handle.as_ref()))
            .unwrap_or_else(|| "-".to_string());
        lines.push(format!(
            "{}  {}  {}  {}  {}  {}  {}  {}  {}  {}  {}",
            compact_identifier(&project.metadata.project_key),
            source,
            phase,
            exit,
            pr,
            updated,
            issue,
            provider,
            resume_id,
            project.metadata.project_label,
            project.metadata.source_root
        ));
    }

    Ok(lines.join("\n"))
}

pub fn run_listen_session_inspect(args: &ListenSessionInspectArgs) -> Result<String> {
    let store = resolve_session_store(&args.target)?;
    let metadata = store_summary(&store)?;
    let state = store.load_state()?;
    let retained_sessions = store.load_retained_sessions()?;
    let mut lines = vec![
        format!("Project key: {}", metadata.metadata.project_key),
        format!("Project: {}", metadata.metadata.project_label),
        format!("Source root: {}", metadata.metadata.source_root),
        format!("MetaStack root: {}", metadata.metadata.metastack_root),
        format!("State file: {}", metadata.state_path.display()),
        format!("Lock file: {}", metadata.lock_path.display()),
        format!("Logs dir: {}", metadata.logs_dir.display()),
    ];

    if let Some(ref lock) = metadata.active_lock {
        lines.push(format!(
            "Active listener: pid {}{}",
            lock.pid,
            if pid_is_running(lock.pid) {
                ""
            } else {
                " (stale)"
            }
        ));
    } else {
        lines.push("Active listener: none".to_string());
    }

    if let Some(degraded) = state.degraded.as_ref() {
        lines.push(format!(
            "Degraded Linear state: {} | retry {}",
            degraded.kind.label(),
            degraded.retry_label(now_epoch_seconds())
        ));
        lines.push(format!("Degraded failure: {}", degraded.message));
    }

    let latest_session = metadata.latest_visible_session().cloned();
    let latest_session_is_retained = metadata.latest_visible_session_is_retained();
    if let Some(session) = latest_session {
        let detail_path = store.detail_path(&session.issue_identifier);
        let detail = if latest_session_is_retained {
            store.load_retained_session_detail(&session.issue_identifier)?
        } else {
            store
                .load_session_detail(&session.issue_identifier)?
                .or(store.load_retained_session_detail(&session.issue_identifier)?)
        };
        lines.push(String::new());
        lines.push("Latest session:".to_string());
        lines.push(format!(
            "  - Source: {}",
            if latest_session_is_retained {
                "retained audit"
            } else {
                "active state"
            }
        ));
        lines.push(format!("  - Issue: {}", session.issue_identifier));
        lines.push(format!("  - Title: {}", session.issue_title));
        lines.push(format!("  - Phase: {}", session.stage_label()));
        lines.push(format!("  - Lifecycle: {}", session.lifecycle_label()));
        if let Some(exit) = session.exit_label() {
            lines.push(format!("  - Exit: {exit}"));
        }
        if let Some(exit_detail) = session.exit_detail_label() {
            lines.push(format!("  - Exit detail: {exit_detail}"));
        }
        lines.push(format!("  - Origin: {}", session.origin_label()));
        lines.push(format!("  - Summary: {}", session.summary));
        if let Some(category) = session.blocked_category_label() {
            lines.push(format!("  - Blocked category: {category}"));
        }
        if let Some(retryable) = session.blocked_retry_label() {
            lines.push(format!("  - Blocked retryable: {retryable}"));
        }
        if let Some(action) = session.blocked_suggested_action() {
            lines.push(format!("  - Blocked action: {action}"));
        }
        lines.push(format!("  - PR: {}", session.pull_request_label()));
        lines.push(format!(
            "  - Tokens: {}",
            session.canonical_tokens().display_compact()
        ));
        lines.push(format!(
            "  - Started: {}",
            now_timestamp_for_epoch(session.started_at_epoch_seconds)
        ));
        lines.push(format!(
            "  - Elapsed since start: {}",
            session.elapsed_since_start_label(now_epoch_seconds())
        ));
        lines.push(format!(
            "  - Recovery attempts: {}/{}",
            session.stale_worker_recovery_attempt_count, MAX_STALE_WORKER_RECOVERY_ATTEMPTS
        ));
        lines.push(format!(
            "  - Updated: {}",
            now_timestamp_for_epoch(session.updated_at_epoch_seconds)
        ));
        lines.push(format!("  - Provider: {}", session.provider_label()));
        if let Some(model) = session.canonical.model.as_deref() {
            lines.push(format!("  - Model: {model}"));
        }
        if let Some(reasoning) = session.canonical.reasoning.as_deref() {
            lines.push(format!("  - Reasoning: {reasoning}"));
        }
        lines.push(format!(
            "  - Resume provider: {}",
            explicit_resume_provider_label(session.latest_resume_handle.as_ref())
        ));
        lines.push(format!(
            "  - Resume ID: {}",
            explicit_resume_id_label(session.latest_resume_handle.as_ref())
        ));
        if let Some(pending_sync) = session.pending_linear_sync_label() {
            lines.push(format!("  - Pending Linear sync: {pending_sync}"));
        }
        if let Some(failure) = session.latest_stale_worker_failure.as_ref() {
            lines.push(format!(
                "  - Latest stale worker failure: {}",
                failure.operator_summary()
            ));
            lines.push(format!(
                "  - Latest stale worker observed: {}",
                now_timestamp_for_epoch(failure.observed_at_epoch_seconds)
            ));
        }
        if let Some(timeout) = session.last_timeout_label() {
            lines.push(format!("  - Last timeout: {timeout}"));
        }
        if let Some(workspace_path) = session.workspace_path {
            lines.push(format!("  - Workspace: {workspace_path}"));
        }
        if let Some(log_path) = session.log_path {
            lines.push(format!("  - Log: {log_path}"));
        }
        lines.push(format!("  - Detail file: {}", detail_path.display()));
        if let Some(detail) = detail {
            append_session_inspect_detail_lines(&mut lines, &detail, args.turns);
        } else {
            lines.push("  - Detail status: unavailable".to_string());
        }
    }

    if !state.sessions.is_empty() {
        lines.push(String::new());
        lines.push("Tracked sessions:".to_string());
        for session in state.sorted_sessions() {
            let pending_sync = session
                .pending_linear_sync_label()
                .map(|value| format!(" | pending {value}"))
                .unwrap_or_default();
            lines.push(format!(
                "  - {} [{}] {} | tokens {}{}",
                session.issue_identifier,
                session.stage_label(),
                session.summary,
                session.canonical_tokens().display_compact(),
                pending_sync
            ));
        }
    }

    let retained_only = retained_sessions
        .into_iter()
        .filter(|summary| {
            !state
                .sessions
                .iter()
                .any(|session| session.issue_matches(&summary.session.issue_identifier))
        })
        .collect::<Vec<_>>();
    if !retained_only.is_empty() {
        lines.push(String::new());
        lines.push("Retained sessions:".to_string());
        for summary in retained_only {
            let session = &summary.session;
            let exit = session.exit_label().unwrap_or_else(|| "-".to_string());
            lines.push(format!(
                "  - {} [{} | {}] {} | pr {}",
                session.issue_identifier,
                session.stage_label(),
                exit,
                session.summary,
                session.pull_request_label(),
            ));
        }
    }

    Ok(lines.join("\n"))
}

fn append_session_inspect_detail_lines(
    lines: &mut Vec<String>,
    detail: &ListenSessionDetail,
    show_turns: bool,
) {
    let lifecycle = detail.effective_lifecycle();
    lines.push("  - Detail status: available".to_string());
    lines.push(format!(
        "  - Detail lifecycle: {}",
        lifecycle.outcome_label()
    ));
    if let Some(exit) = lifecycle.exit_label() {
        lines.push(format!("  - Detail exit: {exit}"));
    }
    lines.push(format!(
        "  - Detail milestones: {}",
        detail.milestones.len()
    ));
    lines.push(format!(
        "  - Detail excerpts: {}",
        detail.log_excerpts.len()
    ));
    lines.push(format!(
        "  - Detail PR: {}",
        detail.pull_request.compact_label()
    ));
    lines.push(format!(
        "  - Detail provider: {}",
        detail_provider_label(detail)
    ));
    if let Some(model) = detail.canonical.model.as_deref() {
        lines.push(format!("  - Detail model: {model}"));
    }
    if let Some(reasoning) = detail.canonical.reasoning.as_deref() {
        lines.push(format!("  - Detail reasoning: {reasoning}"));
    }
    lines.push(format!(
        "  - Detail tokens: {}",
        detail_tokens(detail).display_compact()
    ));
    lines.push(format!(
        "  - Detail started: {}",
        now_timestamp_for_epoch(detail.started_at_epoch_seconds)
    ));
    lines.push(format!(
        "  - Detail elapsed since start: {}",
        format_duration(now_epoch_seconds().saturating_sub(detail.started_at_epoch_seconds))
    ));
    lines.push(format!(
        "  - Detail recovery attempts: {}/{}",
        detail.stale_worker_recovery_attempt_count, MAX_STALE_WORKER_RECOVERY_ATTEMPTS
    ));
    if let Some(blocked) = detail.blocked.as_ref() {
        lines.push(format!(
            "  - Detail blocked category: {}",
            blocked.category_label()
        ));
        lines.push(format!(
            "  - Detail blocked retryable: {}",
            if blocked.retryable { "yes" } else { "no" }
        ));
        lines.push(format!(
            "  - Detail blocked action: {}",
            blocked.suggested_action()
        ));
    }
    lines.push(format!(
        "  - Detail resume ID: {}",
        explicit_resume_id_label(detail.latest_resume_handle.as_ref())
    ));
    if let Some(pending_sync) = detail.pending_linear_sync.as_ref() {
        lines.push(format!(
            "  - Detail pending Linear sync: {}",
            pending_sync.operation_labels().join(", ")
        ));
        if let Some(failure) = pending_sync.last_failure.as_ref() {
            lines.push(format!(
                "  - Detail pending failure: {} | retry {} | {}",
                failure.kind.label(),
                failure.retry_label(now_epoch_seconds()),
                failure.message
            ));
        }
    }
    if let Some(timeout) = detail.last_timeout.as_ref() {
        lines.push(format!(
            "  - Detail last timeout: {}",
            timeout.summary_label()
        ));
    }
    if let Some(failure) = detail.latest_stale_worker_failure.as_ref() {
        lines.push(format!(
            "  - Detail latest stale worker failure: {}",
            failure.operator_summary()
        ));
        lines.push(format!(
            "  - Detail latest stale worker observed: {}",
            now_timestamp_for_epoch(failure.observed_at_epoch_seconds)
        ));
    }

    if let Some(url) = detail.pull_request.url.as_deref() {
        lines.push(format!("  - Detail PR URL: {url}"));
    } else if let Some(number) = detail.pull_request.number {
        lines.push(format!("  - Detail PR Ref: #{number}"));
    }
    if let Some(branch) = detail.references.branch.as_deref() {
        lines.push(format!("  - Detail branch: {branch}"));
    }
    if let Some(workspace_path) = detail.references.workspace_path.as_deref() {
        lines.push(format!("  - Detail workspace: {workspace_path}"));
    }
    if let Some(backlog_path) = detail.references.backlog_path.as_deref() {
        lines.push(format!("  - Detail backlog: {backlog_path}"));
    }
    if let Some(brief_path) = detail.references.brief_path.as_deref() {
        lines.push(format!("  - Detail brief: {brief_path}"));
    }
    if let Some(workpad_comment_id) = detail.references.workpad_comment_id.as_deref() {
        lines.push(format!("  - Detail workpad: {workpad_comment_id}"));
    }
    if let Some(log_path) = detail.references.log_path.as_deref() {
        lines.push(format!("  - Detail log: {log_path}"));
    }
    if let Some(verification) = detail.verification.as_ref() {
        lines.push(format!(
            "  - Detail verification: {} ({})",
            verification.summary,
            verification.compact_label()
        ));
    }
    if let Some(path) = detail.references.verification_json_path.as_deref() {
        lines.push(format!("  - Detail verification JSON: {path}"));
    }
    if let Some(path) = detail.references.verification_markdown_path.as_deref() {
        lines.push(format!("  - Detail verification markdown: {path}"));
    }

    if !detail.prompt_context.is_empty() {
        lines.push("  - Prompt context:".to_string());
        for reference in detail.prompt_context.iter().take(4) {
            lines.push(format!("    - {}: {}", reference.label, reference.value));
        }
    }

    if !detail.milestones.is_empty() {
        lines.push("  - Recent milestones:".to_string());
        for milestone in detail.milestones.iter().rev().take(3).rev() {
            let turns = milestone
                .turns
                .map(|turns| format!(" | turns {turns}"))
                .unwrap_or_default();
            let pull_request = match milestone.pull_request_number {
                Some(number) => format!(" | {} #{number}", milestone.pull_request_status.label()),
                None if milestone.pull_request_status != PullRequestStatus::Unpublished => {
                    format!(" | {}", milestone.pull_request_status.label())
                }
                None => String::new(),
            };
            lines.push(format!(
                "    - {}: {}{}{}",
                milestone.phase.display_label(),
                milestone.summary,
                turns,
                pull_request
            ));
        }
    }

    if show_turns {
        if detail.turn_history.is_empty() {
            lines.push("  - Turn history: unavailable".to_string());
        } else {
            lines.push("  - Turn history:".to_string());
            for snapshot in &detail.turn_history {
                lines.push(format!("    - {}", snapshot.display_compact()));
            }
        }
    }

    if !detail.log_excerpts.is_empty() {
        lines.push("  - Recent log excerpts:".to_string());
        for excerpt in detail.log_excerpts.iter().take(3) {
            lines.push(format!(
                "    - L{} {}",
                excerpt.line_number,
                truncate_summary(&excerpt.text, 120)
            ));
        }
    }
}

fn detail_provider_label(detail: &ListenSessionDetail) -> String {
    detail
        .canonical
        .provider
        .clone()
        .or_else(|| {
            detail
                .latest_resume_handle
                .as_ref()
                .map(|resume| resume.provider.label().to_string())
        })
        .unwrap_or_else(|| "unavailable".to_string())
}

fn detail_tokens(detail: &ListenSessionDetail) -> &TokenUsage {
    if detail.canonical.tokens.is_known() {
        &detail.canonical.tokens
    } else {
        &detail.tokens
    }
}

fn render_verification_check_lines(
    app_config: &AppConfig,
    planning_meta: &PlanningMeta,
    working_dir: &Path,
    args: &ListenRunArgs,
) -> Result<Vec<String>> {
    let run_args = RunAgentArgs {
        root: None,
        route_key: Some(AGENT_ROUTE_AGENTS_LISTEN_VERIFICATION.to_string()),
        agent: args.agent.clone(),
        prompt: "listen verification check".to_string(),
        instructions: None,
        model: args.model.clone(),
        reasoning: args.reasoning.clone(),
        transport: None,
        attachments: Vec::new(),
    };
    let invocation = resolve_agent_invocation_for_planning(app_config, planning_meta, &run_args)?;
    let command_args = command_args_for_invocation(&invocation, Some(working_dir))?;
    let attempted_command = validate_invocation_command_surface(&invocation, &command_args)?;
    let display_command = attempted_command
        .lines()
        .next()
        .unwrap_or(&attempted_command);

    let mut lines = vec![
        format!(
            "Verification code review: {}",
            if app_config.verification.code_review_enabled() {
                "enabled"
            } else {
                "disabled"
            }
        ),
        format!(
            "Verification E2E: {}",
            if app_config.verification.e2e_verification_enabled() {
                "enabled"
            } else {
                "disabled"
            }
        ),
        format!(
            "Verification battle test count: {}",
            app_config.verification.battle_test_count()
        ),
        format!(
            "Verification quality criteria: {}",
            if app_config.verification.quality_criteria.is_empty() {
                "using built-in defaults".to_string()
            } else {
                app_config.verification.quality_criteria.join(" | ")
            }
        ),
        format!("Verification resolved command: `{display_command} ...`"),
    ];
    for line in render_invocation_diagnostics(&invocation) {
        lines.push(format!("Verification {line}"));
    }
    Ok(lines)
}

pub fn run_listen_session_clear(args: &ListenSessionClearArgs) -> Result<String> {
    let store = resolve_session_store(&args.target)?;
    let label = store.identity().project_label.clone();
    let key = store.identity().project_key.clone();
    let selector = clear_selector(args);
    let outcome = store.clear_sessions(&selector)?;
    if outcome.cleared_sessions.is_empty() {
        return Ok(format!(
            "No stored MetaListen sessions matched {} for project `{label}` ({key}); {} tracked session(s) remain.",
            selector.display_label(),
            outcome.remaining_sessions
        ));
    }

    let cleared = outcome
        .cleared_sessions
        .iter()
        .map(|session| format!("{} [{}]", session.issue_identifier, session.stage_label()))
        .collect::<Vec<_>>()
        .join(", ");
    Ok(format!(
        "Cleared {} stored MetaListen session(s) matched by {} for project `{label}` ({key}): {}. {} tracked session(s) remain.",
        outcome.cleared_sessions.len(),
        selector.display_label(),
        cleared,
        outcome.remaining_sessions
    ))
}

pub async fn run_listen_session_resume(args: &ListenSessionResumeArgs) -> Result<()> {
    let store = match args.project_key.as_deref() {
        Some(project_key) => ListenProjectStore::from_project_key(project_key)?,
        None => resolve_project_store(&args.run.root, args.run.project.as_deref())?,
    };
    let mut run_args = args.run.clone();
    run_args.root = store.identity().source_root.clone();
    run_args.project = store.identity().project_selector.clone();
    run_listen(&run_args).await
}

/// Run a one-off headless agent execution for a single Linear issue.
///
/// This reuses the shared listener bootstrap path (workspace provisioning, backlog setup,
/// workpad creation, worker launch) but records the session origin as `Execute` so that
/// the listen dashboard can surface the run without auto-claiming it.
pub async fn run_execute(args: &crate::cli::ExecuteArgs) -> Result<()> {
    let requested_root = canonicalize_existing_dir(&args.root)?;
    let root = resolve_source_project_root(&requested_root)?;
    let planning_meta = load_required_planning_meta(&root, "execute")?;
    ensure_planning_layout(&root, false)?;
    let app_config = AppConfig::load()?;
    let listen_settings = planning_meta.listen.clone();
    let context_budget_tokens = planning_meta.effective_listen_context_budget_tokens(&app_config);

    let config = LinearConfig::new_with_root(
        Some(&root),
        LinearConfigOverrides {
            api_key: args.api_key.clone(),
            api_url: args.api_url.clone(),
            default_team: args.team.clone(),
            profile: args.profile.clone(),
        },
    )?;
    let store =
        resolve_project_store_for_run(&root, args.project.as_deref(), &planning_meta, &app_config)?;
    let client = ReqwestLinearClient::new(config.clone())?;
    let service = LinearService::new(client, config.default_team.clone());

    let issue = service.load_issue(&args.issue).await?;

    let state = store.load_state()?;
    if state.blocks_pickup(&issue.identifier) {
        bail!(
            "issue `{}` already has an active session; use `{} agents listen` to adopt it or `{} listen sessions clear {}` to remove the existing session first",
            issue.identifier,
            crate::branding::COMMAND_NAME,
            crate::branding::COMMAND_NAME,
            issue.identifier,
        );
    }
    let expected_workspace_path = expected_ticket_workspace_path(&root, &issue.identifier)?;
    worker_lease::ensure_listen_worker_lease_available(
        &expected_workspace_path,
        &issue.identifier,
    )?;

    let updated_issue = service
        .edit_issue(crate::linear::IssueEditSpec {
            identifier: issue.identifier.clone(),
            title: None,
            description: None,
            project: None,
            state: Some(IN_PROGRESS_STATE.to_string()),
            priority: None,
            estimate: None,
            labels: None,
            parent_identifier: None,
        })
        .await?;

    let detailed_issue = service.load_issue(&updated_issue.identifier).await?;
    let mut workspace = ensure_ticket_workspace(
        &root,
        listen_settings.refresh_policy(),
        &detailed_issue.identifier,
        &detailed_issue.title,
    )?;
    workspace.workspace_path = canonicalize_existing_dir(&workspace.workspace_path)?;
    worker_lease::ensure_listen_worker_lease_available(
        &workspace.workspace_path,
        &detailed_issue.identifier,
    )?;

    let brief_metadata = crate::agents::TicketMetadata {
        title: Some(detailed_issue.title.clone()),
        description: detailed_issue.description.clone(),
        url: Some(detailed_issue.url.clone()),
        state: detailed_issue
            .state
            .as_ref()
            .map(|s| s.name.clone())
            .or_else(|| Some(IN_PROGRESS_STATE.to_string())),
    };

    let backlog_issue = AgentDaemon::<ReqwestLinearClient>::ensure_backlog_issue_standalone(
        &detailed_issue,
        &workspace.workspace_path,
    )
    .await?;

    let attachment_context =
        sync_issue_attachment_context(&service, &workspace.workspace_path, &detailed_issue).await?;

    let brief_path = crate::agents::write_agent_brief(
        &workspace.workspace_path,
        crate::agents::AgentBriefRequest {
            ticket: detailed_issue.identifier.clone(),
            title_override: Some(detailed_issue.title.clone()),
            goal: Some(format!(
                "Dispatched by `{} agents execute`.",
                crate::branding::COMMAND_NAME
            )),
            metadata: brief_metadata,
            output: None,
        },
    )
    .map(|path| path.display().to_string())
    .ok();

    let timestamp = now_timestamp();
    let workpad_body = workpad::render_bootstrap_workpad(&detailed_issue, &workspace, &timestamp);
    let existing_workpad_comment = active_workpad_comment(&detailed_issue);
    let workpad_reused = existing_workpad_comment.is_some();
    let workpad_comment = if let Some(comment) = existing_workpad_comment {
        comment
    } else {
        service
            .upsert_workpad_comment(&detailed_issue, workpad_body)
            .await?
    };

    let log_path = store.log_path(&detailed_issue.identifier);
    let updated_at_epoch_seconds = now_epoch_seconds();

    let current_exe = std::env::current_exe().with_context(|| {
        format!(
            "failed to resolve the {} executable",
            crate::branding::COMMAND_NAME
        )
    })?;
    if let Some(parent) = log_path.parent() {
        fs::create_dir_all(parent)
            .with_context(|| format!("failed to create `{}`", parent.display()))?;
    }
    let stdout = fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(&log_path)
        .with_context(|| format!("failed to open `{}`", log_path.display()))?;
    let stderr = fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(&log_path)
        .with_context(|| format!("failed to open `{}`", log_path.display()))?;

    let mut command = Command::new(current_exe);
    command.current_dir(&root);
    command.args(build_listen_worker_cli_args(
        &root,
        store.identity().project_selector.as_deref(),
        &workspace.workspace_path,
        &detailed_issue.identifier,
        &workpad_comment.id,
        Some(&backlog_issue.issue.identifier),
        args.max_turns,
        context_budget_tokens,
        args.agent.as_deref(),
        args.model.as_deref(),
        args.reasoning.as_deref(),
    ));
    command.stdout(Stdio::from(stdout));
    command.stderr(Stdio::from(stderr));
    command.stdin(Stdio::null());
    command.env("LINEAR_API_KEY", &config.api_key);
    command.env("LINEAR_API_URL", &config.api_url);
    if let Some(team) = config.default_team.as_deref() {
        command.env("LINEAR_TEAM", team);
    }
    command.env("METASTACK_WORKSPACE_PATH", &workspace.workspace_path);
    command.env("METASTACK_SOURCE_ROOT", &root);
    command.env(
        "METASTACK_LISTEN_PARENT_PID",
        std::process::id().to_string(),
    );
    command.env(
        "METASTACK_LISTEN_SPAWN_REASON",
        ListenWorkerSpawnReason::Execute.label(),
    );
    append_worker_lifecycle_log(
        &log_path,
        WorkerLifecycleLog {
            event: "spawn",
            parent_pid: Some(std::process::id()),
            worker_pid: None,
            issue_identifier: &detailed_issue.identifier,
            workspace_path: &workspace.workspace_path,
            turn_number: None,
            spawn_reason: ListenWorkerSpawnReason::Execute.label(),
            exit_reason: None,
            lease_owner: false,
        },
    )?;

    let mut child = command
        .spawn()
        .context("failed to launch the execute worker")?;
    let pid = child.id();
    wait_for_worker_lease(
        &mut child,
        &workspace.workspace_path,
        &detailed_issue.identifier,
        pid,
    )?;
    spawn_worker_reaper(
        detailed_issue.identifier.clone(),
        pid,
        child,
        log_path.clone(),
        workspace.workspace_path.clone(),
        ListenWorkerSpawnReason::Execute,
    );

    let session = AgentSession {
        issue_id: Some(detailed_issue.id.clone()),
        issue_identifier: detailed_issue.identifier.clone(),
        issue_title: detailed_issue.title.clone(),
        project_name: detailed_issue.project.as_ref().map(|p| p.name.clone()),
        team_key: detailed_issue.team.key.clone(),
        issue_url: detailed_issue.url.clone(),
        phase: SessionPhase::Running,
        lifecycle: None,
        summary: compact_pickup_summary(workpad_reused, &attachment_context, pid),
        blocked: None,
        brief_path,
        backlog_issue_identifier: Some(backlog_issue.issue.identifier.clone()),
        backlog_issue_title: Some(backlog_issue.issue.title.clone()),
        backlog_path: Some(backlog_issue.issue_dir.display().to_string()),
        workspace_path: Some(workspace.workspace_path.display().to_string()),
        branch: Some(workspace.branch.clone()),
        pull_request: PullRequestSummary::default(),
        workpad_comment_id: Some(workpad_comment.id.clone()),
        started_at_epoch_seconds: updated_at_epoch_seconds,
        updated_at_epoch_seconds,
        pid: Some(pid),
        session_id: Some(detailed_issue.id.clone()),
        latest_resume_handle: None,
        context_budget_tokens: Some(context_budget_tokens),
        pending_linear_sync: None,
        stale_worker_recovery_attempt_count: 0,
        latest_stale_worker_failure: None,
        last_timeout: None,
        turns: Some(0),
        tokens: TokenUsage::default(),
        turn_history: Vec::new(),
        canonical: CanonicalSessionData::default(),
        log_path: Some(log_path.display().to_string()),
        origin: state::SessionOrigin::Execute,
    };

    write_listen_session(&root, args.project.as_deref(), session)?;

    if args.json {
        println!(
            "{}",
            render_json_success(
                "agents.execute",
                &serde_json::json!({
                    "issue_identifier": detailed_issue.identifier,
                    "workspace_path": workspace.workspace_path.display().to_string(),
                    "branch": workspace.branch,
                    "pid": pid,
                    "log_path": log_path.display().to_string(),
                    "origin": "execute",
                })
            )?
        );
    } else {
        println!(
            "Started execute worker for {} (pid {}, workspace {}, log {}).",
            detailed_issue.identifier,
            pid,
            workspace.workspace_path.display(),
            log_path.display(),
        );
    }

    Ok(())
}

pub async fn run_listen(args: &ListenRunArgs) -> Result<()> {
    if args.json && !args.once {
        bail!(
            "`{} agents listen --json` requires `--once`",
            crate::branding::COMMAND_NAME
        );
    }

    let requested_root = canonicalize_existing_dir(&args.root)?;
    let root = resolve_source_project_root(&requested_root)?;
    let planning_meta = load_required_planning_meta(&root, "listen")?;
    ensure_planning_layout(&root, false)?;
    let app_config = AppConfig::load()?;
    let validation_profile = resolve_validation_profile(&root, &planning_meta, &[]);
    let poll_interval_seconds =
        resolve_listen_poll_interval_seconds(args, &planning_meta, &app_config);
    let context_budget_tokens =
        resolve_listen_context_budget_tokens(args, &planning_meta, &app_config);
    let mut listen_settings = planning_meta.listen.clone();
    if listen_settings.assignment_scope.is_none() {
        listen_settings.assignment_scope =
            Some(planning_meta.effective_listen_assignment_scope(&app_config));
    }
    if listen_settings.refresh_policy.is_none() {
        listen_settings.refresh_policy =
            Some(planning_meta.effective_listen_refresh_policy(&app_config));
    }
    if args.all_assignees {
        listen_settings.assignment_scope = Some(ListenAssignmentScope::Any);
    }
    let show_active_issues =
        !args.hide_active_issues && listen_settings.dashboard_active_issues_enabled();
    let show_preview = !args.hide_preview && listen_settings.dashboard_preview_enabled();

    if args.demo {
        let store = resolve_project_store_for_run(
            &root,
            args.project.as_deref(),
            &planning_meta,
            &app_config,
        )?;
        let _lock = store.acquire_listener_lock(std::process::id())?;
        let demo_now = now_epoch_seconds();
        let demo_state_file = display_path(&store.paths().state_path, &root);
        let cycle = ListenCycleData::demo_at(&root, demo_now, demo_state_file.clone());
        if args.render_once {
            let cycle = ListenCycleData::demo(&root, demo_state_file.clone());
            let data = build_dashboard_data(
                &cycle,
                &DashboardRuntimeContext {
                    started_at_epoch_seconds: DEMO_START_EPOCH_SECONDS,
                    now_epoch_seconds: DEMO_NOW_EPOCH_SECONDS,
                    poll_interval_seconds,
                    dashboard_label: "terminal snapshot",
                    dashboard_refresh_seconds: TERMINAL_REFRESH_INTERVAL_SECONDS,
                    linear_refresh_seconds: poll_interval_seconds,
                    vim_mode: app_config.vim_mode_enabled(),
                    show_active_issues,
                    show_preview,
                    resolved_agent: None,
                },
            );
            println!(
                "{}",
                render_listen_snapshot(&data, args.width, args.height, &args.events)?
            );
            return Ok(());
        }
        if args.once {
            let cycle = ListenCycleData::demo(&root, demo_state_file.clone());
            let data = build_dashboard_data(
                &cycle,
                &DashboardRuntimeContext {
                    started_at_epoch_seconds: DEMO_START_EPOCH_SECONDS,
                    now_epoch_seconds: DEMO_NOW_EPOCH_SECONDS,
                    poll_interval_seconds,
                    dashboard_label: "terminal summary",
                    dashboard_refresh_seconds: TERMINAL_REFRESH_INTERVAL_SECONDS,
                    linear_refresh_seconds: poll_interval_seconds,
                    vim_mode: app_config.vim_mode_enabled(),
                    show_active_issues,
                    show_preview,
                    resolved_agent: None,
                },
            );
            if args.json {
                println!("{}", render_json_success("agents.listen", &data)?);
            } else {
                println!("{}", data.render_summary());
            }
            return Ok(());
        }

        let initial_cycle = cycle.clone();
        run_live_loop(
            args,
            ListenLoopConfig {
                poll_interval_seconds,
                started_at_epoch_seconds: demo_now - 7_351,
                refresh_immediately: false,
                vim_mode: app_config.vim_mode_enabled(),
                show_active_issues,
                show_preview,
                resolved_agent: None,
            },
            initial_cycle,
            move || {
                let cycle = cycle.clone();
                async move { Ok(cycle) }
            },
            |_| Ok(()),
            |_: &str| Ok(false),
            |_: &str| Ok(false),
            |_: &str| Ok(false),
        )
        .await?;
        return Ok(());
    }

    let startup_provider_preflight = match preflight::run_listen_provider_preflight(
        &app_config,
        &planning_meta,
        preflight::ListenPreflightRequest {
            working_dir: &root,
            agent: args.agent.as_deref(),
            model: args.model.as_deref(),
            reasoning: args.reasoning.as_deref(),
            require_write_access: false,
        },
    ) {
        Ok(report) => Some(report),
        Err(error) if !args.check && preflight::is_missing_agent_selection(&error) => None,
        Err(error) => {
            if args.check {
                bail!("{}", preflight::render_listen_preflight_report(Err(&error)));
            }
            return Err(error);
        }
    };
    let resolved_agent = startup_provider_preflight
        .as_ref()
        .map(|report| report.provider().to_string());
    let startup_workspace_pressure = workspace_pressure::assess_workspace_pressure(&root)?;
    if !args.check && startup_workspace_pressure.should_block_unattended_startup() {
        bail!("{}", startup_workspace_pressure.startup_block_message());
    }

    let config = LinearConfig::new_with_root(
        Some(&root),
        LinearConfigOverrides {
            api_key: args.api_key.clone(),
            api_url: args.api_url.clone(),
            default_team: args.team.clone(),
            profile: args.profile.clone(),
        },
    )?;
    let store =
        resolve_project_store_for_run(&root, args.project.as_deref(), &planning_meta, &app_config)?;
    let _lock = store.acquire_listener_lock(std::process::id())?;
    let client = ReqwestLinearClient::new(config.clone())?;
    let service = LinearService::new(client, config.default_team.clone());
    let mut preflight_viewer = None;
    if let Some(provider_report) = startup_provider_preflight {
        let startup_preflight =
            preflight::complete_listen_preflight(&service, &config, provider_report).await;
        if args.check {
            match startup_preflight {
                Ok(report) => {
                    println!("{}", preflight::render_listen_preflight_report(Ok(&report)));
                    println!(
                        "- Effective assignee filter: {}",
                        render_watch_scope(
                            listen_settings.assignment_scope(),
                            report.viewer().filter(|_| {
                                !matches!(
                                    listen_settings.assignment_scope(),
                                    ListenAssignmentScope::Any
                                )
                            }),
                        )
                    );
                    match &validation_profile {
                        Ok(profile) => {
                            for line in profile.diagnostics_lines() {
                                println!("- {line}");
                            }
                        }
                        Err(error) => {
                            println!("- Validation profile: unresolved");
                            bail!("{error}");
                        }
                    }
                    for line in
                        render_verification_check_lines(&app_config, &planning_meta, &root, args)?
                    {
                        println!("- {line}");
                    }
                    return Ok(());
                }
                Err(error) => {
                    bail!("{}", preflight::render_listen_preflight_report(Err(&error)));
                }
            }
        }
        match startup_preflight {
            Ok(report) => {
                preflight_viewer = report.viewer().cloned();
                preflight::emit_listen_preflight_warnings(&report);
            }
            Err(error) if classify_linear_failure(&error).is_retryable() => {}
            Err(error) => return Err(error),
        }
    } else if args.check {
        unreachable!("`--check` exits on provider preflight failures before Linear validation");
    }
    let viewer = preflight_viewer;
    let daemon = AgentDaemon {
        root: root.clone(),
        store,
        filters: IssueListFilters {
            team: args.team.clone().or(config.default_team.clone()),
            project: args.project.clone(),
            project_id: if args.project.is_some() {
                None
            } else {
                planning_meta.effective_project_id(&app_config)
            },
            state: Some(TODO_STATE.to_string()),
            assignee: issue_assignee_filter(listen_settings.assignment_scope(), viewer.as_ref()),
            limit: args.limit.max(1),
        },
        max_pickups: args.max_pickups.max(1),
        linear_config: config.clone(),
        app_config,
        planning_meta: planning_meta.clone(),
        worker_agent: args.agent.clone(),
        worker_model: args.model.clone(),
        worker_reasoning: args.reasoning.clone(),
        worker_context_budget_tokens: context_budget_tokens,
        listen_settings,
        viewer,
        service,
    };

    if args.render_once {
        let cycle = daemon.run_cycle_resilient().await?;
        let now = now_epoch_seconds();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: now,
                now_epoch_seconds: now,
                poll_interval_seconds,
                dashboard_label: "terminal snapshot",
                dashboard_refresh_seconds: TERMINAL_REFRESH_INTERVAL_SECONDS,
                linear_refresh_seconds: 0,
                vim_mode: daemon.app_config.vim_mode_enabled(),
                show_active_issues,
                show_preview,
                resolved_agent: resolved_agent.clone(),
            },
        );
        println!(
            "{}",
            render_listen_snapshot(&data, args.width, args.height, &args.events)?
        );
        return Ok(());
    }

    if args.once {
        let cycle = daemon.run_cycle_resilient().await?;
        let now = now_epoch_seconds();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: now,
                now_epoch_seconds: now,
                poll_interval_seconds,
                dashboard_label: "terminal summary",
                dashboard_refresh_seconds: TERMINAL_REFRESH_INTERVAL_SECONDS,
                linear_refresh_seconds: 0,
                vim_mode: daemon.app_config.vim_mode_enabled(),
                show_active_issues,
                show_preview,
                resolved_agent: resolved_agent.clone(),
            },
        );
        if args.json {
            println!("{}", render_json_success("agents.listen", &data)?);
        } else {
            println!("{}", data.render_summary());
        }
        return Ok(());
    }

    let started_at_epoch_seconds = now_epoch_seconds();
    let initial_cycle = ListenCycleData::loading(
        listen_scope_label(
            daemon.filters.team.as_deref(),
            daemon.store.identity().project_selector.as_deref(),
            &daemon.store.identity().project_label,
        ),
        daemon.watch_scope_label(),
        display_path(&daemon.store.paths().state_path, &daemon.root),
    );
    let mut codex_live_tokens = CodexLiveTokenHydrator::new();
    run_live_loop(
        args,
        ListenLoopConfig {
            poll_interval_seconds,
            started_at_epoch_seconds,
            refresh_immediately: true,
            vim_mode: daemon.app_config.vim_mode_enabled(),
            show_active_issues,
            show_preview,
            resolved_agent,
        },
        initial_cycle,
        || daemon.run_cycle_resilient(),
        |cycle| {
            let state = daemon.store.load_state()?;
            let live_sessions = state.sorted_sessions();
            let sessions = merge_visible_sessions(
                live_sessions.clone(),
                daemon.store.load_retained_sessions()?,
            );
            let session_details = load_visible_session_details(
                &daemon.store,
                &daemon.app_config,
                &live_sessions,
                &sessions,
            )?;
            cycle.apply_state_snapshot(state, sessions, session_details);
            codex_live_tokens.refresh_sessions(&mut cycle.sessions)?;
            Ok(())
        },
        |identifier: &str| daemon.store.resume_paused_session(identifier),
        |identifier: &str| daemon.store.pause_running_session(identifier),
        |identifier: &str| daemon.store.retry_blocked_session(identifier),
    )
    .await
}

fn resolve_session_store(
    target: &crate::cli::ListenSessionTargetArgs,
) -> Result<ListenProjectStore> {
    match target.project_key.as_deref() {
        Some(project_key) => ListenProjectStore::from_project_key(project_key),
        None => resolve_project_store(&target.root, target.project.as_deref()),
    }
}

fn resolve_project_store(
    root: &Path,
    explicit_project: Option<&str>,
) -> Result<ListenProjectStore> {
    let requested_root = canonicalize_existing_dir(root)?;
    let source_root = resolve_source_project_root(&requested_root)?;
    let planning_meta = load_required_planning_meta(&source_root, "listen")?;
    let app_config = AppConfig::load()?;
    resolve_project_store_for_run(&source_root, explicit_project, &planning_meta, &app_config)
}

fn resolve_project_store_for_run(
    root: &Path,
    explicit_project: Option<&str>,
    planning_meta: &PlanningMeta,
    app_config: &AppConfig,
) -> Result<ListenProjectStore> {
    ListenProjectStore::resolve(
        root,
        effective_listen_project_selector(explicit_project, planning_meta, app_config).as_deref(),
    )
}

fn effective_listen_project_selector(
    explicit_project: Option<&str>,
    planning_meta: &PlanningMeta,
    app_config: &AppConfig,
) -> Option<String> {
    explicit_project
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(ToOwned::to_owned)
        .or_else(|| planning_meta.effective_project_id(app_config))
}

fn store_summary(store: &ListenProjectStore) -> Result<StoredListenProjectSummary> {
    let mut projects = ListenProjectStore::list_projects()?;
    projects
        .drain(..)
        .find(|project| project.metadata.project_key == store.identity().project_key)
        .ok_or_else(|| {
            anyhow!(
                "stored MetaListen project session `{}` was not found",
                store.identity().project_key
            )
        })
}

fn clear_selector(args: &ListenSessionClearArgs) -> SessionSelector {
    if let Some(identifier) = args.issue_identifier.as_deref() {
        SessionSelector::IssueIdentifier(identifier.to_string())
    } else if args.blocked {
        SessionSelector::Blocked
    } else if args.completed {
        SessionSelector::Completed
    } else if args.stale {
        SessionSelector::Stale
    } else {
        SessionSelector::All
    }
}

fn render_listen_snapshot(
    data: &ListenDashboardData,
    width: u16,
    height: u16,
    events: &[ListenDashboardEventArg],
) -> Result<String> {
    if events.is_empty() {
        return dashboard::render_dashboard(data, width, height);
    }
    let mut browser_state = dashboard::SessionBrowserState::default();
    browser_state.normalize(data);
    for event in events {
        browser_state.apply_action(data, listen_dashboard_action(*event));
    }
    dashboard::render_dashboard_with_state(data, width, height, browser_state)
}

fn listen_dashboard_action(event: ListenDashboardEventArg) -> dashboard::SessionBrowserAction {
    match event {
        ListenDashboardEventArg::Up => dashboard::SessionBrowserAction::Up,
        ListenDashboardEventArg::Down => dashboard::SessionBrowserAction::Down,
        ListenDashboardEventArg::Tab => dashboard::SessionBrowserAction::Tab,
        ListenDashboardEventArg::Left => dashboard::SessionBrowserAction::Left,
        ListenDashboardEventArg::Right => dashboard::SessionBrowserAction::Right,
        ListenDashboardEventArg::Enter => dashboard::SessionBrowserAction::Enter,
        ListenDashboardEventArg::Back | ListenDashboardEventArg::Esc => {
            dashboard::SessionBrowserAction::Back
        }
        ListenDashboardEventArg::PageUp => dashboard::SessionBrowserAction::PageUp,
        ListenDashboardEventArg::PageDown => dashboard::SessionBrowserAction::PageDown,
    }
}

fn listen_browser_action(code: KeyCode, vim_mode: bool) -> Option<dashboard::SessionBrowserAction> {
    match code {
        KeyCode::Up => Some(dashboard::SessionBrowserAction::Up),
        KeyCode::Down => Some(dashboard::SessionBrowserAction::Down),
        KeyCode::Tab => Some(dashboard::SessionBrowserAction::Tab),
        KeyCode::Left => Some(dashboard::SessionBrowserAction::Left),
        KeyCode::Right => Some(dashboard::SessionBrowserAction::Right),
        KeyCode::Enter => Some(dashboard::SessionBrowserAction::Enter),
        KeyCode::Char('p' | 'P') => Some(dashboard::SessionBrowserAction::Pause),
        KeyCode::Esc | KeyCode::Backspace => Some(dashboard::SessionBrowserAction::Back),
        KeyCode::PageUp => Some(dashboard::SessionBrowserAction::PageUp),
        KeyCode::PageDown => Some(dashboard::SessionBrowserAction::PageDown),
        KeyCode::Char('h') if vim_mode => Some(dashboard::SessionBrowserAction::Left),
        KeyCode::Char('j') if vim_mode => Some(dashboard::SessionBrowserAction::Down),
        KeyCode::Char('k') if vim_mode => Some(dashboard::SessionBrowserAction::Up),
        KeyCode::Char('l') if vim_mode => Some(dashboard::SessionBrowserAction::Right),
        _ => None,
    }
}

// The dashboard loop injects separate closures for cycle progression and session actions so
// tests can stub each side effect independently without threading a wider trait object through
// the listen runtime.
#[allow(clippy::too_many_arguments)]
async fn run_live_loop<F, Fut, S, RP, PP, R>(
    _args: &ListenRunArgs,
    loop_config: ListenLoopConfig,
    initial_cycle: ListenCycleData,
    mut next_cycle: F,
    mut refresh_dashboard_state: S,
    mut resume_paused: RP,
    mut pause_running: PP,
    mut retry_blocked: R,
) -> Result<()>
where
    F: FnMut() -> Fut,
    Fut: Future<Output = Result<ListenCycleData>>,
    S: FnMut(&mut ListenCycleData) -> Result<()>,
    RP: FnMut(&str) -> Result<bool>,
    PP: FnMut(&str) -> Result<bool>,
    R: FnMut(&str) -> Result<bool>,
{
    let _initial_data = build_dashboard_data(
        &initial_cycle,
        &DashboardRuntimeContext {
            started_at_epoch_seconds: loop_config.started_at_epoch_seconds,
            now_epoch_seconds: loop_config.started_at_epoch_seconds,
            poll_interval_seconds: loop_config.poll_interval_seconds,
            dashboard_label: "terminal dashboard (TUI)",
            dashboard_refresh_seconds: TERMINAL_REFRESH_INTERVAL_SECONDS,
            linear_refresh_seconds: if loop_config.refresh_immediately {
                0
            } else {
                loop_config.poll_interval_seconds
            },
            vim_mode: loop_config.vim_mode,
            show_active_issues: loop_config.show_active_issues,
            show_preview: loop_config.show_preview,
            resolved_agent: loop_config.resolved_agent.clone(),
        },
    );
    let linear_refresh_interval = Duration::from_secs(loop_config.poll_interval_seconds);
    let terminal_refresh_interval = Duration::from_secs(TERMINAL_REFRESH_INTERVAL_SECONDS);

    let mut stdout = io::stdout();
    enable_raw_mode()?;
    execute!(stdout, EnterAlternateScreen)?;
    let _cleanup = TerminalCleanup;

    let backend = CrosstermBackend::new(stdout);
    let mut terminal = Terminal::new(backend)?;
    let mut cycle = initial_cycle;
    let mut browser_state = dashboard::SessionBrowserState::default();
    let mut next_linear_refresh_at = if loop_config.refresh_immediately {
        Instant::now()
    } else {
        Instant::now() + linear_refresh_interval
    };
    let mut next_terminal_refresh_at = Instant::now() + terminal_refresh_interval;
    let mut pending_cycle_refresh: Option<Pin<Box<Fut>>> = None;
    let mut event_stream = EventStream::new();

    loop {
        let now = now_epoch_seconds();
        let linear_refresh_seconds = next_linear_refresh_at
            .saturating_duration_since(Instant::now())
            .as_secs();
        let data = build_dashboard_data(
            &cycle,
            &DashboardRuntimeContext {
                started_at_epoch_seconds: loop_config.started_at_epoch_seconds,
                now_epoch_seconds: now,
                poll_interval_seconds: loop_config.poll_interval_seconds,
                dashboard_label: "terminal dashboard (TUI)",
                dashboard_refresh_seconds: TERMINAL_REFRESH_INTERVAL_SECONDS,
                linear_refresh_seconds,
                vim_mode: loop_config.vim_mode,
                show_active_issues: loop_config.show_active_issues,
                show_preview: loop_config.show_preview,
                resolved_agent: loop_config.resolved_agent.clone(),
            },
        );
        browser_state.normalize(&data);
        terminal.draw(|frame| dashboard::render(frame, &data, &browser_state))?;

        // Schedule a cycle refresh if it's time and one isn't already pending.
        if pending_cycle_refresh.is_none() && Instant::now() >= next_linear_refresh_at {
            pending_cycle_refresh = Some(Box::pin(next_cycle()));
        }

        // Compute the next terminal-refresh heartbeat deadline.
        let heartbeat = next_terminal_refresh_at
            .saturating_duration_since(Instant::now())
            .min(Duration::from_millis(250));

        // All arms are async — no blocking calls on the tokio runtime.
        let mut should_break = false;
        tokio::select! {
            maybe_event = event_stream.next() => {
                match maybe_event {
                    Some(Ok(Event::Key(key))) if key.kind == KeyEventKind::Press => {
                        if browser_state.copy.export_active()
                            && browser_state.copy.handle_export_key(
                                key,
                                copy_overlay_viewport(terminal.size()?.into()),
                            )
                        {
                            continue;
                        }
                        let ctrl_c = key.code == KeyCode::Char('c')
                            && key.modifiers.contains(KeyModifiers::CONTROL);
                        if ctrl_c || matches!(key.code, KeyCode::Char('q')) {
                            should_break = true;
                        } else if is_copy_key(key) {
                            browser_state.copy.copy_payload(browser_state.copy_payload(&data));
                        } else if matches!(key.code, KeyCode::Char('r' | 'R')) {
                            if let Some(session) = browser_state.selected_session(&data) {
                                let handled = if session.phase == SessionPhase::Paused {
                                    resume_paused(&session.issue_identifier)?
                                } else if session.can_manual_resume() {
                                    retry_blocked(&session.issue_identifier)?
                                } else {
                                    false
                                };
                                if handled {
                                    refresh_dashboard_state(&mut cycle)?;
                                    next_terminal_refresh_at = Instant::now();
                                }
                            }
                        } else if matches!(key.code, KeyCode::Char('p' | 'P')) {
                            if let Some(session) = browser_state.selected_session(&data) {
                                if session.phase == SessionPhase::Running
                                    && pause_running(&session.issue_identifier)?
                                {
                                    refresh_dashboard_state(&mut cycle)?;
                                    next_terminal_refresh_at = Instant::now();
                                }
                            }
                        } else if let Some(action) =
                            listen_browser_action(key.code, loop_config.vim_mode)
                        {
                            browser_state.apply_action(&data, action);
                        }
                    }
                    Some(Err(e)) => return Err(e.into()),
                    _ => {}
                }
            }
            result = async {
                    pending_cycle_refresh.as_mut().unwrap().as_mut().await
                }, if pending_cycle_refresh.is_some() => {
                cycle = result?;
                let refreshed_at = Instant::now();
                next_linear_refresh_at = cycle
                    .degraded
                    .as_ref()
                    .and_then(|failure| failure.next_retry_at_epoch_seconds)
                    .and_then(epoch_seconds_to_instant)
                    .unwrap_or(refreshed_at + linear_refresh_interval);
                pending_cycle_refresh = None;
                refresh_dashboard_state(&mut cycle)?;
                next_terminal_refresh_at = Instant::now() + terminal_refresh_interval;
            }
            _ = tokio::time::sleep(heartbeat) => {
                // Terminal refresh heartbeat — triggers a redraw.
                if Instant::now() >= next_terminal_refresh_at {
                    refresh_dashboard_state(&mut cycle)?;
                    next_terminal_refresh_at = Instant::now() + terminal_refresh_interval;
                }
            }
        }

        if should_break {
            break;
        }
    }

    Ok(())
}

fn epoch_seconds_to_instant(epoch_seconds: u64) -> Option<Instant> {
    let now_epoch_seconds = now_epoch_seconds();
    if epoch_seconds <= now_epoch_seconds {
        return Some(Instant::now());
    }
    Some(Instant::now() + Duration::from_secs(epoch_seconds - now_epoch_seconds))
}

fn resolve_listen_poll_interval_seconds(
    args: &ListenRunArgs,
    planning_meta: &PlanningMeta,
    app_config: &AppConfig,
) -> u64 {
    args.poll_interval
        .unwrap_or_else(|| planning_meta.effective_listen_poll_interval_seconds(app_config))
        .max(1)
}

fn resolve_listen_context_budget_tokens(
    args: &ListenRunArgs,
    planning_meta: &PlanningMeta,
    app_config: &AppConfig,
) -> u64 {
    args.context_budget_tokens
        .unwrap_or_else(|| planning_meta.effective_listen_context_budget_tokens(app_config))
        .max(1)
}

// Hidden worker launches thread through the resolved repo/run settings explicitly so long-lived
// sessions do not drift if config changes later.
#[allow(clippy::too_many_arguments)]
fn build_listen_worker_cli_args(
    source_root: &Path,
    project_selector: Option<&str>,
    workspace_path: &Path,
    issue_identifier: &str,
    workpad_comment_id: &str,
    backlog_issue_identifier: Option<&str>,
    max_turns: u32,
    context_budget_tokens: u64,
    agent: Option<&str>,
    model: Option<&str>,
    reasoning: Option<&str>,
) -> Vec<OsString> {
    let mut args = vec![
        OsString::from("listen-worker"),
        OsString::from("--source-root"),
        source_root.as_os_str().to_os_string(),
    ];
    if let Some(project_selector) = project_selector {
        args.push(OsString::from("--project"));
        args.push(OsString::from(project_selector));
    }
    args.extend([
        OsString::from("--workspace"),
        workspace_path.as_os_str().to_os_string(),
        OsString::from("--issue"),
        OsString::from(issue_identifier),
        OsString::from("--workpad-comment-id"),
        OsString::from(workpad_comment_id),
        OsString::from("--max-turns"),
        OsString::from(max_turns.to_string()),
        OsString::from("--context-budget-tokens"),
        OsString::from(context_budget_tokens.to_string()),
    ]);
    if let Some(backlog_issue_identifier) = backlog_issue_identifier {
        args.push(OsString::from("--backlog-issue"));
        args.push(OsString::from(backlog_issue_identifier));
    }
    if let Some(agent) = agent {
        args.push(OsString::from("--agent"));
        args.push(OsString::from(agent));
    }
    if let Some(model) = model {
        args.push(OsString::from("--model"));
        args.push(OsString::from(model));
    }
    if let Some(reasoning) = reasoning {
        args.push(OsString::from("--reasoning"));
        args.push(OsString::from(reasoning));
    }
    args
}

fn build_dashboard_data(
    cycle: &ListenCycleData,
    runtime: &DashboardRuntimeContext,
) -> ListenDashboardData {
    let session_counts = SessionListCounts::from_sessions(&cycle.sessions);
    let tokens = aggregate_token_usage(&cycle.sessions)
        .map(|totals| {
            format!(
                "in {} | out {} | total {}",
                totals
                    .input
                    .map(format_number)
                    .unwrap_or_else(|| "n/a".to_string()),
                totals
                    .output
                    .map(format_number)
                    .unwrap_or_else(|| "n/a".to_string()),
                format_number(totals.total)
            )
        })
        .unwrap_or_else(|| "n/a".to_string());
    ListenDashboardData {
        title: format!("{} listen", crate::branding::COMMAND_NAME),
        scope: cycle.scope.clone(),
        watch_scope: cycle.watch_scope.clone(),
        cycle_summary: format!(
            "{} pending, {} active / {} blocked / {} completed sessions, {} claimed this cycle",
            cycle.pending_issues.len(),
            session_counts.active,
            session_counts.blocked,
            session_counts.completed,
            cycle.claimed_this_cycle
        ),
        vim_mode: runtime.vim_mode,
        runtime: ListenRuntimeSummary {
            agents: format!(
                "{} active / {} blocked / {} completed / {} queued",
                session_counts.active,
                session_counts.blocked,
                session_counts.completed,
                cycle.pending_issues.len()
            ),
            throughput: format!(
                "{:.2} tps",
                cycle.claimed_this_cycle as f64 / runtime.poll_interval_seconds.max(1) as f64
            ),
            runtime: format_duration(
                runtime
                    .now_epoch_seconds
                    .saturating_sub(runtime.started_at_epoch_seconds),
            ),
            tokens,
            rate_limits: cycle.rate_limits.clone().unwrap_or_else(|| {
                "n/a (agent rate-limit telemetry is not surfaced by this CLI yet)".to_string()
            }),
            linear_status: render_linear_status(cycle.degraded.as_ref(), runtime.now_epoch_seconds),
            project: cycle.scope.clone(),
            dashboard: runtime.dashboard_label.to_string(),
            dashboard_refresh: format!("{}s", runtime.dashboard_refresh_seconds),
            linear_refresh: format!("{}s", runtime.linear_refresh_seconds),
            current_epoch_seconds: runtime.now_epoch_seconds,
        },
        pending_issues: cycle.pending_issues.clone(),
        active_issues: cycle.active_issues.clone(),
        sessions: cycle.sessions.clone(),
        session_details: cycle.session_details.clone(),
        notes: cycle.notes.clone(),
        state_file: cycle.state_file.clone(),
        degraded: cycle.degraded.clone(),
        show_active_issues: runtime.show_active_issues,
        show_preview: runtime.show_preview,
        resolved_agent: runtime.resolved_agent.clone(),
    }
}

fn render_linear_status(
    degraded: Option<&LinearFailureSnapshot>,
    now_epoch_seconds: u64,
) -> String {
    degraded
        .map(|failure| {
            format!(
                "degraded | {} | retry {} | {}",
                failure.kind.label(),
                failure.retry_label(now_epoch_seconds),
                failure.message
            )
        })
        .unwrap_or_else(|| "healthy".to_string())
}

fn aggregate_token_usage(sessions: &[AgentSession]) -> Option<TokenTotals> {
    let mut input = None;
    let mut output = None;

    for session in sessions {
        if let Some(value) = session.canonical_tokens().input {
            input = Some(input.unwrap_or(0) + value);
        }
        if let Some(value) = session.canonical_tokens().output {
            output = Some(output.unwrap_or(0) + value);
        }
    }

    (input.is_some() || output.is_some()).then_some(TokenTotals {
        input,
        output,
        total: input.unwrap_or(0) + output.unwrap_or(0),
    })
}

fn render_agent_prompt(
    issue: &IssueSummary,
    workspace_path: &Path,
    workpad_comment_id: &str,
    backlog_issue: Option<&IssueSummary>,
    turn_number: u32,
    max_turns: u32,
) -> String {
    let continuation = if turn_number > 1 {
        format!(
            "Continuation context:\n\n- This is continuation turn #{turn_number} of {max_turns} because the ticket is still in an active state.\n- Resume from the current workspace and workpad state instead of restarting from scratch.\n- Do not repeat completed investigation or validation unless the new code changes require it.\n- Do not end the turn while the issue remains active unless you are blocked by missing required auth, permissions, or secrets.\n\n"
        )
    } else {
        String::new()
    };
    let state = issue_state_label(issue);
    let brief_path = PlanningPaths::new(workspace_path)
        .agent_briefs_dir
        .join(format!("{}.md", issue.identifier));
    let mut lines = vec![
        format!("You are working on Linear ticket `{}`", issue.identifier),
        String::new(),
    ];
    if !continuation.is_empty() {
        lines.push(continuation.trim_end().to_string());
        lines.push(String::new());
    }
    lines.extend([
        "Issue context:".to_string(),
        format!("Identifier: {}", issue.identifier),
        format!("Title: {}", issue.title),
        format!("Current status: {}", state),
        format!("URL: {}", issue.url),
        format!("Workspace: {}", workspace_path.display()),
        format!("Primary brief: {}", brief_path.display()),
        format!("Tracking workpad comment ID: {workpad_comment_id}"),
    ]);
    if let Some(backlog_issue) = backlog_issue {
        lines.push(format!(
            "Local backlog path: {}",
            PlanningPaths::new(workspace_path)
                .backlog_issue_dir(&backlog_issue.identifier)
                .display()
        ));
        lines.push(format!("Backlog identifier: {}", backlog_issue.identifier));
    }

    let manifest_path =
        PlanningPaths::new(workspace_path).agent_issue_context_manifest_path(&issue.identifier);
    if manifest_path.is_file() {
        lines.push(format!(
            "Attachment context: {}",
            manifest_path.parent().unwrap_or(workspace_path).display()
        ));
        lines.push(format!("Attachment manifest: {}", manifest_path.display()));
    }

    let discussion_summary = backlog_issue
        .and_then(|backlog_issue| {
            let discussion_path = PlanningPaths::new(workspace_path)
                .backlog_issue_dir(&backlog_issue.identifier)
                .join(TICKET_DISCUSSION_FILE_NAME);
            discussion_path.is_file().then_some(discussion_path)
        })
        .and_then(|discussion_path| {
            let contents = fs::read_to_string(&discussion_path).ok()?;
            let char_limit = PlanningMeta::load(workspace_path)
                .ok()
                .map(|planning_meta| planning_meta.sync.discussion_prompt_char_limit())
                .unwrap_or(DEFAULT_SYNC_DISCUSSION_PROMPT_CHAR_LIMIT);
            let summary = render_discussion_summary(&contents, char_limit);
            (!summary.is_empty()).then_some((discussion_path, summary))
        });
    if let Some((discussion_path, summary)) = discussion_summary {
        lines.push(format!("Discussion context: {}", discussion_path.display()));
        lines.push("Discussion summary:".to_string());
        lines.push(String::new());
        lines.push(summary);
    }

    lines.extend([
        String::new(),
        "Description summary:".to_string(),
        String::new(),
        render_issue_description_summary(issue.description.as_deref()),
    ]);

    for section in extract_ticket_inline_sections(issue.description.as_deref()) {
        lines.push(String::new());
        lines.push(section.render());
    }

    lines.join("\n")
}

fn render_continuation_prompt(issue: &IssueSummary, turn_number: u32, max_turns: u32) -> String {
    format!(
        "Continuation guidance for `{identifier}`:\n\n\
         - The previous turn completed normally, but the Linear issue is still in an active state.\n\
         - This is continuation turn #{turn_number} of {max_turns} for the current agent run.\n\
         - Resume from the current workspace and workpad state instead of restarting from scratch.\n\
         - The original task instructions and prior turn context are already present in this session.\n\
         - Focus on the remaining ticket work and do not restart completed steps.\n\
         - Do not end the turn while the issue remains active unless you are blocked by missing required auth, permissions, or secrets.",
        identifier = issue.identifier,
    )
}

fn render_issue_description_summary(description: Option<&str>) -> String {
    let Some(description) = description else {
        return "No description provided.".to_string();
    };
    let narrative = strip_ticket_inline_sections(description);
    let narrative = narrative.trim();
    if narrative.is_empty() {
        return "No additional narrative context outside inline ticket sections.".to_string();
    }

    truncate_turn_one_text(narrative, TURN_ONE_DESCRIPTION_SUMMARY_MAX_CHARS)
}

fn render_discussion_summary(contents: &str, char_limit: usize) -> String {
    let text_budget = char_limit.min(TURN_ONE_DISCUSSION_MAX_CHARS);
    if text_budget == 0 {
        return String::new();
    }

    let sections = extract_discussion_summary_sections(contents);
    if sections.is_empty() {
        let normalized = normalize_discussion_excerpt(contents);
        return if normalized.is_empty() {
            String::new()
        } else {
            truncate_discussion_bullet(None, &normalized, text_budget)
        };
    }

    let mut bullets = Vec::new();
    let mut used_chars = 0usize;
    for section in sections.iter().rev().take(TURN_ONE_DISCUSSION_MAX_EXCERPTS) {
        let remaining = text_budget.saturating_sub(used_chars);
        if remaining == 0 {
            break;
        }
        let separator_cost = usize::from(!bullets.is_empty());
        if remaining <= separator_cost {
            break;
        }
        let bullet = truncate_discussion_bullet(
            section.label.as_deref(),
            &section.excerpt,
            remaining - separator_cost,
        );
        if bullet.is_empty() {
            break;
        }
        used_chars += separator_cost + bullet.chars().count();
        bullets.push(bullet);
    }

    bullets.join("\n")
}

fn truncate_discussion_bullet(label: Option<&str>, excerpt: &str, max_chars: usize) -> String {
    if max_chars <= 2 {
        return String::new();
    }
    let content = match label {
        Some(label) => format!("{label}: {excerpt}"),
        None => excerpt.to_string(),
    };
    let content_budget = max_chars.saturating_sub(2);
    if content_budget == 0 {
        return String::new();
    }
    format!("- {}", truncate_turn_one_text(&content, content_budget))
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct DiscussionSummarySection {
    label: Option<String>,
    excerpt: String,
}

fn extract_discussion_summary_sections(contents: &str) -> Vec<DiscussionSummarySection> {
    let mut sections = Vec::new();
    let mut current_label: Option<String> = None;
    let mut current_lines = Vec::new();

    let flush_current = |sections: &mut Vec<DiscussionSummarySection>,
                         current_label: &mut Option<String>,
                         current_lines: &mut Vec<String>| {
        let excerpt = normalize_discussion_excerpt(&current_lines.join("\n"));
        if excerpt.is_empty() {
            current_label.take();
            current_lines.clear();
            return;
        }
        sections.push(DiscussionSummarySection {
            label: current_label.take(),
            excerpt,
        });
        current_lines.clear();
    };

    for raw_line in contents.lines() {
        let trimmed = raw_line.trim();
        if let Some(label) = trimmed.strip_prefix("### ") {
            if current_label.is_some() || !current_lines.is_empty() {
                flush_current(&mut sections, &mut current_label, &mut current_lines);
            }
            current_label = Some(label.trim().to_string());
            continue;
        }
        if current_label.is_some() {
            current_lines.push(raw_line.to_string());
        }
    }
    if current_label.is_some() || !current_lines.is_empty() {
        flush_current(&mut sections, &mut current_label, &mut current_lines);
    }
    if !sections.is_empty() {
        return sections;
    }

    contents
        .split("\n\n")
        .map(str::trim)
        .filter(|block| !block.is_empty())
        .filter(|block| !block.starts_with("# "))
        .map(normalize_discussion_excerpt)
        .filter(|excerpt| !excerpt.is_empty())
        .map(|excerpt| DiscussionSummarySection {
            label: None,
            excerpt,
        })
        .collect()
}

fn normalize_discussion_excerpt(value: &str) -> String {
    value
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .collect::<Vec<_>>()
        .join(" ")
}

fn truncate_turn_one_text(value: &str, max_chars: usize) -> String {
    let total_chars = value.chars().count();
    if total_chars <= max_chars {
        return value.to_string();
    }
    if max_chars <= 3 {
        return ".".repeat(max_chars);
    }

    let truncated = value.chars().take(max_chars - 3).collect::<String>();
    format!("{truncated}...")
}

fn render_listen_backlog_description(
    template_index: &str,
    parent_issue: &IssueSummary,
    existing_description: Option<&str>,
) -> String {
    if let Some(existing_description) = existing_description
        && backlog_description_has_task_list(existing_description)
    {
        return existing_description.to_string();
    }

    let mut lines = Vec::new();
    if !template_index.trim().is_empty() {
        lines.push(template_index.trim_end().to_string());
    }

    lines.extend([
        String::new(),
        format!("_Generated by `{} listen`._", crate::branding::COMMAND_NAME),
        String::new(),
        "## Source Issue".to_string(),
        String::new(),
        format!("- Identifier: `{}`", parent_issue.identifier),
        format!("- Title: {}", parent_issue.title),
        format!("- URL: {}", parent_issue.url),
    ]);

    let mut requirements = extract_requirements(parent_issue.description.as_deref());
    if requirements.is_empty()
        && let Some(description) = parent_issue.description.as_deref().map(str::trim)
        && !description.is_empty()
    {
        requirements.push(description.to_string());
    }
    if !requirements.is_empty() {
        lines.extend([String::new(), "## Requirements".to_string(), String::new()]);
        lines.extend(
            requirements
                .into_iter()
                .map(|requirement| format!("- [ ] {requirement}")),
        );
    }

    lines.join("\n")
}

fn backlog_description_has_task_list(description: &str) -> bool {
    description.contains("## Requirements")
        || description.contains("- [ ] ")
        || description.contains("- [x] ")
        || description.contains("- [X] ")
        || description.contains("* [ ] ")
        || description.contains("* [x] ")
        || description.contains("* [X] ")
}

async fn sync_issue_attachment_context<C>(
    service: &LinearService<C>,
    workspace_path: &Path,
    issue: &IssueSummary,
) -> Result<AttachmentContextSummary>
where
    C: LinearClient,
{
    let paths = PlanningPaths::new(workspace_path);
    let context_dir = paths.agent_issue_context_dir(&issue.identifier);
    if context_dir.exists() {
        fs::remove_dir_all(&context_dir)
            .with_context(|| format!("failed to reset `{}`", context_dir.display()))?;
    }
    if issue.attachments.is_empty() {
        return Ok(AttachmentContextSummary::default());
    }

    fs::create_dir_all(context_dir.join(ISSUE_ATTACHMENT_CONTEXT_FILES_DIR))
        .with_context(|| format!("failed to create `{}`", context_dir.display()))?;

    let mut summary = AttachmentContextSummary::default();
    for (index, attachment) in issue.attachments.iter().enumerate() {
        let filename = attachment_download_name(attachment, index);
        let relative_path = format!("{ISSUE_ATTACHMENT_CONTEXT_FILES_DIR}/{filename}");
        let destination = context_dir.join(&relative_path);
        match service.download_file(&attachment.url).await {
            Ok(contents) => {
                if let Some(parent) = destination.parent() {
                    fs::create_dir_all(parent)
                        .with_context(|| format!("failed to create `{}`", parent.display()))?;
                }
                fs::write(&destination, contents)
                    .with_context(|| format!("failed to write `{}`", destination.display()))?;
                summary.downloaded_paths.push(relative_path);
            }
            Err(error) => summary.failed_downloads.push(format!(
                "{} ({}) - {}",
                attachment.title,
                attachment.url,
                truncate_summary(&error.to_string(), 120)
            )),
        }
    }

    let manifest_path = paths.agent_issue_context_manifest_path(&issue.identifier);
    fs::write(
        &manifest_path,
        render_issue_attachment_manifest(issue, &summary, workspace_path),
    )
    .with_context(|| format!("failed to write `{}`", manifest_path.display()))?;

    Ok(summary)
}

fn attachment_download_name(attachment: &crate::linear::AttachmentSummary, index: usize) -> String {
    let preferred = file_name_candidate(attachment.title.as_str())
        .or_else(|| file_name_candidate(attachment.url.as_str()))
        .unwrap_or_else(|| "attachment".to_string());
    format!(
        "{:02}-{}",
        index + 1,
        sanitize_attachment_file_name(&preferred)
    )
}

fn file_name_candidate(value: &str) -> Option<String> {
    let trimmed = value.trim();
    if trimmed.is_empty() {
        return None;
    }

    let trimmed = trimmed
        .split('?')
        .next()
        .unwrap_or(trimmed)
        .trim_end_matches('/');
    Path::new(trimmed)
        .file_name()
        .and_then(|name| name.to_str())
        .map(str::trim)
        .filter(|name| !name.is_empty())
        .map(str::to_string)
}

fn sanitize_attachment_file_name(name: &str) -> String {
    let mut sanitized = name
        .chars()
        .map(|ch| {
            if ch.is_ascii_alphanumeric() || matches!(ch, '.' | '-' | '_') {
                ch
            } else {
                '-'
            }
        })
        .collect::<String>();
    while sanitized.contains("--") {
        sanitized = sanitized.replace("--", "-");
    }
    sanitized = sanitized.trim_matches('-').to_string();
    if sanitized.is_empty() {
        "attachment".to_string()
    } else {
        sanitized
    }
}

fn render_issue_attachment_manifest(
    issue: &IssueSummary,
    summary: &AttachmentContextSummary,
    workspace_path: &Path,
) -> String {
    let context_dir = PlanningPaths::new(workspace_path).agent_issue_context_dir(&issue.identifier);
    let mut lines = vec![
        format!("# Attachment Context for {}", issue.identifier),
        String::new(),
        format!("- Source issue: `{}`", issue.identifier),
        format!("- Linear URL: {}", issue.url),
        format!("- Download directory: `{}`", context_dir.display()),
        format!("- Attached items discovered: {}", issue.attachments.len()),
        format!("- Files downloaded: {}", summary.downloaded_count()),
        format!("- Download failures: {}", summary.failed_downloads.len()),
    ];

    let read_first_text_paths = summary
        .downloaded_paths
        .iter()
        .filter(|path| attachment_path_is_read_first_text(path))
        .collect::<Vec<_>>();
    let read_first_other_paths = summary
        .downloaded_paths
        .iter()
        .filter(|path| !attachment_path_is_read_first_text(path))
        .collect::<Vec<_>>();

    if summary.has_entries() {
        lines.extend([String::new(), "## Read First".to_string(), String::new()]);
        if !read_first_text_paths.is_empty() {
            lines.extend(["### Markdown / Text Artifacts".to_string(), String::new()]);
            for path in read_first_text_paths {
                lines.push(format!("- `{path}`"));
            }
            lines.push(String::new());
        }
        if !summary.failed_downloads.is_empty() {
            lines.extend(["### Download Failures".to_string(), String::new()]);
            for failure in &summary.failed_downloads {
                lines.push(format!("- {failure}"));
            }
            lines.push(String::new());
        }
        if !read_first_other_paths.is_empty() {
            lines.extend(["### Other Downloaded Files".to_string(), String::new()]);
            for path in read_first_other_paths {
                lines.push(format!("- `{path}`"));
            }
            lines.push(String::new());
        }
        while matches!(lines.last(), Some(last) if last.is_empty()) {
            lines.pop();
        }
    }

    if !summary.downloaded_paths.is_empty() {
        lines.extend([
            String::new(),
            "## Downloaded Files".to_string(),
            String::new(),
        ]);
        for path in &summary.downloaded_paths {
            lines.push(format!("- `{path}`"));
        }
    }

    if !summary.failed_downloads.is_empty() {
        lines.extend([
            String::new(),
            "## Download Failures".to_string(),
            String::new(),
        ]);
        for failure in &summary.failed_downloads {
            lines.push(format!("- {failure}"));
        }
    }

    if !summary.has_entries() {
        lines.extend([
            String::new(),
            "No downloadable attachment context was available.".to_string(),
        ]);
    }

    lines.join("\n")
}

fn attachment_path_is_read_first_text(path: &str) -> bool {
    Path::new(path)
        .extension()
        .and_then(|extension| extension.to_str())
        .map(|extension| {
            matches!(
                extension.to_ascii_lowercase().as_str(),
                "md" | "markdown" | "txt"
            )
        })
        .unwrap_or(false)
}

fn now_timestamp() -> String {
    Command::new("date")
        .args(["-u", "+%Y-%m-%dT%H:%M:%SZ"])
        .output()
        .ok()
        .filter(|output| output.status.success())
        .map(|output| String::from_utf8_lossy(&output.stdout).trim().to_string())
        .filter(|value| !value.is_empty())
        .unwrap_or_else(|| now_epoch_seconds().to_string())
}

fn now_timestamp_for_epoch(epoch_seconds: u64) -> String {
    epoch_seconds.to_string()
}

fn now_epoch_seconds() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

fn format_duration(total_seconds: u64) -> String {
    if total_seconds < 60 {
        return format!("{total_seconds}s");
    }

    let total_minutes = total_seconds / 60;
    let seconds = total_seconds % 60;
    if total_minutes < 60 * 24 {
        return format!("{total_minutes}m {seconds:02}s");
    }

    let hours = total_seconds / 3_600;
    let minutes = (total_seconds % 3_600) / 60;
    format!("{hours}h {minutes:02}m")
}

fn format_number(value: u64) -> String {
    let digits = value.to_string();
    let mut formatted = String::with_capacity(digits.len() + digits.len() / 3);
    for (index, digit) in digits.chars().rev().enumerate() {
        if index > 0 && index % 3 == 0 {
            formatted.push(',');
        }
        formatted.push(digit);
    }

    formatted.chars().rev().collect()
}

fn compact_identifier(value: &str) -> String {
    if value.len() <= 14 {
        return value.to_string();
    }

    format!("{}...{}", &value[..4], &value[value.len() - 6..])
}

#[derive(Debug, Clone, Copy)]
struct TokenTotals {
    input: Option<u64>,
    output: Option<u64>,
    total: u64,
}

struct TerminalCleanup;

impl Drop for TerminalCleanup {
    fn drop(&mut self) {
        let _ = disable_raw_mode();
        let mut stdout = io::stdout();
        let _ = execute!(stdout, LeaveAlternateScreen);
    }
}

#[cfg(test)]
mod tests {
    use super::{
        AgentDaemon, AgentSession, BlockedCategory, CanonicalSessionData, DashboardRuntimeContext,
        IN_PROGRESS_STATE, LatestResumeHandle, ListenCycleData, ListenState, PullRequestSummary,
        ResumeProvider, SessionExitCondition, SessionLifecycleOutcome, SessionListCounts,
        SessionOrigin, SessionPhase, SessionTimeoutRecord, SessionTimeoutTermination, TODO_STATE,
        TokenUsage, TurnPromptMode, TurnTokenSnapshot, blocked_reason, capture_workspace_snapshot,
        compact_identifier, compare_workspace_snapshots, format_duration, format_number,
        listen_browser_action, listen_scope_label, mark_running_session_stale, render_agent_prompt,
        render_continuation_prompt, required_label_skip_reason,
    };
    use crate::agents::{AgentBriefRequest, TicketMetadata, write_agent_brief};
    use crate::config::{
        AppConfig, LinearConfig, ListenAssignmentScope, ListenRefreshPolicy,
        PlanningListenSettings, PlanningMeta,
    };
    use crate::fs::{PlanningPaths, ensure_dir};
    use crate::linear::{
        AttachmentCreateRequest, AttachmentSummary, IssueComment, IssueCreateRequest,
        IssueLabelCreateRequest, IssueListFilters, IssueSummary, IssueUpdateRequest, LabelRef,
        LinearClient, LinearService, ProjectSummary, TeamRef, TeamSummary, UserRef, WorkflowState,
    };
    use crate::listen::dashboard::SessionBrowserAction;
    use crate::listen::store::ListenProjectStore;
    use anyhow::{Result, anyhow};
    use async_trait::async_trait;
    use crossterm::event::KeyCode;
    use serde::Deserialize;
    use std::collections::HashMap;
    use std::fs;
    use std::path::Path;
    use std::process::Command;
    use tempfile::tempdir;

    #[test]
    fn session_phase_has_human_labels() {
        assert_eq!(SessionPhase::Claimed.display_label(), "Claimed");
        assert_eq!(SessionPhase::BriefReady.display_label(), "Brief Ready");
        assert_eq!(SessionPhase::Running.display_label(), "Running");
        assert_eq!(SessionPhase::Validating.display_label(), "Validating");
        assert_eq!(SessionPhase::Completed.display_label(), "Completed");
        assert_eq!(SessionPhase::Blocked.html_class(), "danger");
        assert_eq!(SessionPhase::Validating.html_class(), "active");
        assert_eq!(SessionPhase::Completed.html_class(), "success");
    }

    #[test]
    fn number_formatter_adds_grouping() {
        assert_eq!(format_number(0), "0");
        assert_eq!(format_number(1_234_567), "1,234,567");
    }

    #[test]
    fn parse_checklist_progress_ignores_template_placeholder_items() {
        let progress = super::parse_checklist_progress(
            "\
- [ ] Follow-up action 1
- [ ] Follow-up action 2
- [ ] Confirm owners/reviewers in `contacts.md`.
- [ ] Remove consumer-side ad hoc transforms.
- [ ] Task 1
- [ ] Task 2
- [ ] Task 3
- [ ] Criterion 1
- [ ] No completed items recorded yet.
- [ ] No explicit validation status recorded.
",
        );

        assert_eq!(progress.completed, 0);
        assert_eq!(progress.total, 0);
        assert_eq!(progress.next_step, None);
    }

    #[test]
    fn parse_checklist_progress_keeps_real_remaining_items() {
        let progress = super::parse_checklist_progress(
            "\
- [x] Implemented the build loop
- [ ] Add regression coverage for live continuation
",
        );

        assert_eq!(progress.completed, 1);
        assert_eq!(progress.total, 2);
        assert_eq!(
            progress.next_step.as_deref(),
            Some("Add regression coverage for live continuation")
        );
    }

    #[test]
    fn marked_section_body_extracts_listener_progress_block() {
        let body = "\
prefix
<!-- metastack-listen-progress:start -->
## Listener Progress Checklist

### Remaining

- [x] No remaining implementation work is tracked locally.
<!-- metastack-listen-progress:end -->
suffix
";

        let section = super::marked_section_body(body, "metastack-listen-progress")
            .expect("listener progress section should be found");

        assert!(section.contains("## Listener Progress Checklist"));
        assert!(!section.contains("prefix"));
        assert!(!section.contains("suffix"));
    }

    #[test]
    fn duration_formatter_matches_dashboard_style() {
        assert_eq!(format_duration(5), "5s");
        assert_eq!(format_duration(95), "1m 35s");
        assert_eq!(format_duration(5_423), "90m 23s");
    }

    #[test]
    fn compact_identifier_shortens_long_values() {
        assert_eq!(compact_identifier("short-id"), "short-id");
        assert_eq!(
            compact_identifier("019cedb4-2293-7651-b0b4-dfac4af6a640"),
            "019c...f6a640"
        );
    }

    #[test]
    fn token_usage_compact_display_shows_in_out_and_total() {
        let usage = TokenUsage {
            input: Some(12_300),
            output: Some(40),
        };

        assert_eq!(usage.display_compact(), "in 12,300 | out 40 | total 12,340");
    }

    #[test]
    fn token_usage_accumulate_preserves_partial_counts() {
        let mut usage = TokenUsage {
            input: Some(10),
            output: None,
        };
        usage.accumulate(&TokenUsage {
            input: None,
            output: Some(5),
        });
        usage.accumulate(&TokenUsage {
            input: Some(7),
            output: None,
        });

        assert_eq!(usage.input, Some(17));
        assert_eq!(usage.output, Some(5));
        assert_eq!(usage.display_compact(), "in 17 | out 5 | total 22");
    }

    #[test]
    fn render_listen_backlog_file_distinguishes_packet_local_and_repo_level_evidence() {
        let issue = test_issue("MET-57");
        let rendered = super::render_listen_backlog_file(
            "validation.md",
            "# Validation\n".to_string(),
            &issue,
        );

        assert!(rendered.contains(&format!(
            "`{}/backlog/MET-57/validation.md`",
            crate::branding::PROJECT_DIR
        )));
        assert!(rendered.contains("`artifacts/validation/MET-57.md`"));
        assert!(
            rendered
                .contains("Do not write ticket-specific PR evidence to repo-root `validation.md`.")
        );
    }

    #[test]
    fn render_listen_backlog_file_preserves_non_validation_templates() {
        let original = "# Notes\n".to_string();

        assert_eq!(
            super::render_listen_backlog_file("notes.md", original.clone(), &test_issue("MET-57")),
            original
        );
    }

    #[test]
    fn aggregate_token_usage_sums_mixed_partial_session_counts() {
        let sessions = vec![
            AgentSession {
                issue_id: Some("issue-1".to_string()),
                issue_identifier: "ENG-1".to_string(),
                issue_title: "One".to_string(),
                project_name: None,
                team_key: "ENG".to_string(),
                issue_url: "https://linear.app/issues/ENG-1".to_string(),
                phase: SessionPhase::Running,
                lifecycle: None,
                summary: "running".to_string(),
                blocked: None,
                brief_path: None,
                backlog_issue_identifier: None,
                backlog_issue_title: None,
                backlog_path: None,
                workspace_path: None,
                branch: None,
                pull_request: PullRequestSummary::default(),
                workpad_comment_id: None,
                started_at_epoch_seconds: 1,
                updated_at_epoch_seconds: 1,
                pid: None,
                session_id: None,
                latest_resume_handle: None,
                context_budget_tokens: None,
                pending_linear_sync: None,
                stale_worker_recovery_attempt_count: 0,
                latest_stale_worker_failure: None,
                last_timeout: None,
                turns: None,
                tokens: TokenUsage {
                    input: Some(100),
                    output: None,
                },
                turn_history: Vec::new(),
                canonical: CanonicalSessionData::default(),
                log_path: None,
                origin: SessionOrigin::Listen,
            },
            AgentSession {
                issue_id: Some("issue-2".to_string()),
                issue_identifier: "ENG-2".to_string(),
                issue_title: "Two".to_string(),
                project_name: None,
                team_key: "ENG".to_string(),
                issue_url: "https://linear.app/issues/ENG-2".to_string(),
                phase: SessionPhase::Completed,
                lifecycle: None,
                summary: "done".to_string(),
                blocked: None,
                brief_path: None,
                backlog_issue_identifier: None,
                backlog_issue_title: None,
                backlog_path: None,
                workspace_path: None,
                branch: None,
                pull_request: PullRequestSummary::default(),
                workpad_comment_id: None,
                started_at_epoch_seconds: 2,
                updated_at_epoch_seconds: 2,
                pid: None,
                session_id: None,
                latest_resume_handle: None,
                context_budget_tokens: None,
                pending_linear_sync: None,
                stale_worker_recovery_attempt_count: 0,
                latest_stale_worker_failure: None,
                last_timeout: None,
                turns: None,
                tokens: TokenUsage {
                    input: None,
                    output: Some(25),
                },
                turn_history: Vec::new(),
                canonical: CanonicalSessionData::default(),
                log_path: None,
                origin: SessionOrigin::Listen,
            },
        ];

        let totals = super::aggregate_token_usage(&sessions).expect("usage totals should exist");
        assert_eq!(totals.input, Some(100));
        assert_eq!(totals.output, Some(25));
        assert_eq!(totals.total, 125);
    }

    #[test]
    fn aggregate_token_usage_preserves_missing_output_counts() {
        let sessions = vec![AgentSession {
            issue_id: Some("issue-1".to_string()),
            issue_identifier: "ENG-1".to_string(),
            issue_title: "One".to_string(),
            project_name: None,
            team_key: "ENG".to_string(),
            issue_url: "https://linear.app/issues/ENG-1".to_string(),
            phase: SessionPhase::Running,
            lifecycle: None,
            summary: "running".to_string(),
            blocked: None,
            brief_path: None,
            backlog_issue_identifier: None,
            backlog_issue_title: None,
            backlog_path: None,
            workspace_path: None,
            branch: None,
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: None,
            started_at_epoch_seconds: 1,
            updated_at_epoch_seconds: 1,
            pid: None,
            session_id: None,
            latest_resume_handle: None,
            context_budget_tokens: None,
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: None,
            turns: None,
            tokens: TokenUsage {
                input: Some(100),
                output: None,
            },
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: None,
            origin: SessionOrigin::Listen,
        }];

        let totals = super::aggregate_token_usage(&sessions).expect("usage totals should exist");
        assert_eq!(totals.input, Some(100));
        assert_eq!(totals.output, None);
        assert_eq!(totals.total, 100);
    }

    #[test]
    fn dashboard_runtime_tokens_use_canonical_mixed_provider_totals() {
        let cycle = ListenCycleData {
            scope: "MET".to_string(),
            watch_scope: "all assignees".to_string(),
            pending_issues: Vec::new(),
            active_issues: Vec::new(),
            session_details: HashMap::new(),
            sessions: vec![
                AgentSession {
                    issue_id: Some("issue-1".to_string()),
                    issue_identifier: "ENG-1".to_string(),
                    issue_title: "Codex".to_string(),
                    project_name: None,
                    team_key: "ENG".to_string(),
                    issue_url: "https://linear.app/issues/ENG-1".to_string(),
                    phase: SessionPhase::Running,
                    lifecycle: None,
                    summary: "running".to_string(),
                    blocked: None,
                    brief_path: None,
                    backlog_issue_identifier: None,
                    backlog_issue_title: None,
                    backlog_path: None,
                    workspace_path: None,
                    branch: None,
                    pull_request: PullRequestSummary::default(),
                    workpad_comment_id: None,
                    started_at_epoch_seconds: 1,
                    updated_at_epoch_seconds: 1,
                    pid: None,
                    session_id: None,
                    latest_resume_handle: None,
                    context_budget_tokens: None,
                    pending_linear_sync: None,
                    stale_worker_recovery_attempt_count: 0,
                    latest_stale_worker_failure: None,
                    last_timeout: None,
                    turns: None,
                    tokens: TokenUsage::default(),
                    turn_history: Vec::new(),
                    canonical: CanonicalSessionData {
                        provider: Some("codex".to_string()),
                        model: Some("gpt-5.4".to_string()),
                        reasoning: Some("high".to_string()),
                        tokens: TokenUsage {
                            input: Some(100),
                            output: Some(10),
                        },
                        repair: None,
                    },
                    log_path: None,
                    origin: SessionOrigin::Listen,
                },
                AgentSession {
                    issue_id: Some("issue-2".to_string()),
                    issue_identifier: "ENG-2".to_string(),
                    issue_title: "Claude".to_string(),
                    project_name: None,
                    team_key: "ENG".to_string(),
                    issue_url: "https://linear.app/issues/ENG-2".to_string(),
                    phase: SessionPhase::Completed,
                    lifecycle: None,
                    summary: "done".to_string(),
                    blocked: None,
                    brief_path: None,
                    backlog_issue_identifier: None,
                    backlog_issue_title: None,
                    backlog_path: None,
                    workspace_path: None,
                    branch: None,
                    pull_request: PullRequestSummary::default(),
                    workpad_comment_id: None,
                    started_at_epoch_seconds: 2,
                    updated_at_epoch_seconds: 2,
                    pid: None,
                    session_id: None,
                    latest_resume_handle: None,
                    context_budget_tokens: None,
                    pending_linear_sync: None,
                    stale_worker_recovery_attempt_count: 0,
                    latest_stale_worker_failure: None,
                    last_timeout: None,
                    turns: None,
                    tokens: TokenUsage::default(),
                    turn_history: Vec::new(),
                    canonical: CanonicalSessionData {
                        provider: Some("claude".to_string()),
                        model: Some("sonnet".to_string()),
                        reasoning: Some("high".to_string()),
                        tokens: TokenUsage {
                            input: Some(20),
                            output: Some(5),
                        },
                        repair: None,
                    },
                    log_path: None,
                    origin: SessionOrigin::Listen,
                },
                AgentSession {
                    issue_id: Some("issue-3".to_string()),
                    issue_identifier: "ENG-3".to_string(),
                    issue_title: "Unknown".to_string(),
                    project_name: None,
                    team_key: "ENG".to_string(),
                    issue_url: "https://linear.app/issues/ENG-3".to_string(),
                    phase: SessionPhase::Blocked,
                    lifecycle: None,
                    summary: "blocked".to_string(),
                    blocked: None,
                    brief_path: None,
                    backlog_issue_identifier: None,
                    backlog_issue_title: None,
                    backlog_path: None,
                    workspace_path: None,
                    branch: None,
                    pull_request: PullRequestSummary::default(),
                    workpad_comment_id: None,
                    started_at_epoch_seconds: 3,
                    updated_at_epoch_seconds: 3,
                    pid: None,
                    session_id: None,
                    latest_resume_handle: None,
                    context_budget_tokens: None,
                    pending_linear_sync: None,
                    stale_worker_recovery_attempt_count: 0,
                    latest_stale_worker_failure: None,
                    last_timeout: None,
                    turns: None,
                    tokens: TokenUsage::default(),
                    turn_history: Vec::new(),
                    canonical: CanonicalSessionData::default(),
                    log_path: None,
                    origin: SessionOrigin::Listen,
                },
            ],
            notes: Vec::new(),
            state_file: "/tmp/session.json".to_string(),
            rate_limits: None,
            claimed_this_cycle: 0,
            degraded: None,
        };
        let runtime = DashboardRuntimeContext {
            started_at_epoch_seconds: 1,
            now_epoch_seconds: 11,
            poll_interval_seconds: 5,
            dashboard_label: "terminal snapshot",
            dashboard_refresh_seconds: 1,
            linear_refresh_seconds: 5,
            vim_mode: false,
            show_active_issues: true,
            show_preview: true,
            resolved_agent: Some("codex".to_string()),
        };

        let dashboard = super::build_dashboard_data(&cycle, &runtime);
        assert_eq!(dashboard.runtime.tokens, "in 120 | out 15 | total 135");
    }

    #[test]
    fn dashboard_runtime_tokens_render_partial_counts_as_na() {
        let cycle = ListenCycleData {
            scope: "MET".to_string(),
            watch_scope: "all assignees".to_string(),
            pending_issues: Vec::new(),
            active_issues: Vec::new(),
            session_details: HashMap::new(),
            sessions: vec![AgentSession {
                issue_id: Some("issue-1".to_string()),
                issue_identifier: "ENG-1".to_string(),
                issue_title: "One".to_string(),
                project_name: None,
                team_key: "ENG".to_string(),
                issue_url: "https://linear.app/issues/ENG-1".to_string(),
                phase: SessionPhase::Running,
                lifecycle: None,
                summary: "running".to_string(),
                blocked: None,
                brief_path: None,
                backlog_issue_identifier: None,
                backlog_issue_title: None,
                backlog_path: None,
                workspace_path: None,
                branch: None,
                pull_request: PullRequestSummary::default(),
                workpad_comment_id: None,
                started_at_epoch_seconds: 1,
                updated_at_epoch_seconds: 1,
                pid: None,
                session_id: None,
                latest_resume_handle: None,
                context_budget_tokens: None,
                pending_linear_sync: None,
                stale_worker_recovery_attempt_count: 0,
                latest_stale_worker_failure: None,
                last_timeout: None,
                turns: None,
                tokens: TokenUsage {
                    input: Some(100),
                    output: None,
                },
                turn_history: Vec::new(),
                canonical: CanonicalSessionData::default(),
                log_path: None,
                origin: SessionOrigin::Listen,
            }],
            notes: Vec::new(),
            state_file: "/tmp/session.json".to_string(),
            rate_limits: None,
            claimed_this_cycle: 0,
            degraded: None,
        };
        let runtime = DashboardRuntimeContext {
            started_at_epoch_seconds: 1,
            now_epoch_seconds: 11,
            poll_interval_seconds: 5,
            dashboard_label: "terminal snapshot",
            dashboard_refresh_seconds: 1,
            linear_refresh_seconds: 5,
            vim_mode: false,
            show_active_issues: true,
            show_preview: true,
            resolved_agent: Some("codex".to_string()),
        };

        let dashboard = super::build_dashboard_data(&cycle, &runtime);
        assert_eq!(dashboard.runtime.tokens, "in 100 | out n/a | total 100");
    }

    #[test]
    fn render_summary_includes_resolved_execution_agent() {
        let cycle = ListenCycleData::demo(
            Path::new("."),
            format!(
                "{}/agents/sessions/listen-state.json",
                crate::branding::PROJECT_DIR
            ),
        );
        let runtime = DashboardRuntimeContext {
            started_at_epoch_seconds: 1_773_568_249,
            now_epoch_seconds: 1_773_575_600,
            poll_interval_seconds: 7,
            dashboard_label: "terminal summary",
            dashboard_refresh_seconds: 1,
            linear_refresh_seconds: 15,
            vim_mode: false,
            show_active_issues: true,
            show_preview: true,
            resolved_agent: Some("claude".to_string()),
        };

        let summary = super::build_dashboard_data(&cycle, &runtime).render_summary();

        assert!(summary.contains("Execution agent: claude"));
    }

    #[test]
    fn session_counts_split_active_blocked_and_completed() {
        let mut cycle = ListenCycleData::demo(
            Path::new("."),
            format!(
                "{}/agents/sessions/listen-state.json",
                crate::branding::PROJECT_DIR
            ),
        );
        let blocked = blocked_reason(BlockedCategory::Infra, "pending Linear sync", true);
        cycle.sessions[1].phase = SessionPhase::Blocked;
        cycle.sessions[1].summary = blocked.summary_headline();
        cycle.sessions[1].blocked = Some(blocked);
        cycle.sessions.push(AgentSession {
            issue_id: Some("issue-3".to_string()),
            issue_identifier: "MET-33".to_string(),
            issue_title: "Completed ticket".to_string(),
            project_name: Some("MetaStack CLI".to_string()),
            team_key: "MET".to_string(),
            issue_url: "https://linear.app/metastack-backlog/issue/MET-33/completed".to_string(),
            phase: SessionPhase::Completed,
            lifecycle: None,
            summary: "Complete".to_string(),
            blocked: None,
            brief_path: None,
            backlog_issue_identifier: None,
            backlog_issue_title: None,
            backlog_path: None,
            workspace_path: None,
            branch: None,
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: None,
            started_at_epoch_seconds: 1_773_575_540,
            updated_at_epoch_seconds: 1_773_575_540,
            pid: None,
            session_id: None,
            latest_resume_handle: None,
            context_budget_tokens: None,
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: None,
            turns: Some(1),
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: None,
            origin: SessionOrigin::Listen,
        });

        let counts = SessionListCounts::from_sessions(&cycle.sessions);
        assert_eq!(counts.active, 1);
        assert_eq!(counts.blocked, 1);
        assert_eq!(counts.completed, 1);

        let runtime = DashboardRuntimeContext {
            started_at_epoch_seconds: 1_773_568_249,
            now_epoch_seconds: 1_773_575_600,
            poll_interval_seconds: 7,
            dashboard_label: "terminal summary",
            dashboard_refresh_seconds: 1,
            linear_refresh_seconds: 15,
            vim_mode: false,
            show_active_issues: true,
            show_preview: true,
            resolved_agent: Some("claude".to_string()),
        };
        let dashboard = super::build_dashboard_data(&cycle, &runtime);

        assert!(
            dashboard
                .cycle_summary
                .contains("1 active / 1 blocked / 1 completed sessions")
        );
        assert_eq!(
            dashboard.runtime.agents,
            "1 active / 1 blocked / 1 completed / 1 queued"
        );
    }

    #[test]
    fn listen_state_merge_rejects_stale_daemon_overwrite_of_enriched_worker_session() {
        let daemon_session = AgentSession {
            issue_id: Some("issue-64".to_string()),
            issue_identifier: "MET-64".to_string(),
            issue_title: "Builtin Claude listen agent".to_string(),
            project_name: Some("MetaStack CLI".to_string()),
            team_key: "MET".to_string(),
            issue_url: "https://linear.app/issues/64".to_string(),
            phase: SessionPhase::Running,
            lifecycle: None,
            summary: "Running".to_string(),
            blocked: None,
            brief_path: None,
            backlog_issue_identifier: None,
            backlog_issue_title: None,
            backlog_path: None,
            workspace_path: None,
            branch: None,
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: None,
            started_at_epoch_seconds: 1_773_575_600,
            updated_at_epoch_seconds: 1_773_575_600,
            pid: Some(42),
            session_id: None,
            latest_resume_handle: None,
            context_budget_tokens: None,
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: None,
            turns: Some(0),
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: None,
            origin: SessionOrigin::Listen,
        };
        let mut worker_session = daemon_session.clone();
        worker_session.phase = SessionPhase::Blocked;
        worker_session.summary = "Blocked | verification failed".to_string();
        worker_session.blocked = Some(blocked_reason(
            BlockedCategory::Gate,
            "verification failed and repair budget exhausted",
            false,
        ));
        worker_session.turns = Some(2);
        worker_session.canonical = CanonicalSessionData {
            provider: Some("claude".to_string()),
            model: Some("sonnet".to_string()),
            reasoning: Some("high".to_string()),
            tokens: TokenUsage {
                input: Some(210),
                output: Some(34),
            },
            repair: None,
        };
        worker_session.latest_resume_handle = Some(LatestResumeHandle {
            provider: ResumeProvider::Claude,
            id: "resume-worker-64".to_string(),
        });
        worker_session.turn_history = vec![
            TurnTokenSnapshot {
                turn: 1,
                prompt_mode: TurnPromptMode::FullPrompt,
                tokens: TokenUsage {
                    input: Some(210),
                    output: Some(34),
                },
                captured_at_epoch_seconds: 1_773_575_590,
            },
            TurnTokenSnapshot {
                turn: 2,
                prompt_mode: TurnPromptMode::Continuation,
                tokens: TokenUsage {
                    input: Some(80),
                    output: Some(13),
                },
                captured_at_epoch_seconds: 1_773_575_600,
            },
        ];

        let merged =
            super::merge_cycle_sessions(vec![worker_session.clone()], vec![daemon_session]);
        assert_eq!(merged.len(), 1);
        assert_eq!(merged[0].phase, SessionPhase::Blocked);
        assert_eq!(merged[0].summary, "Blocked | verification failed");
        assert_eq!(merged[0].blocked, worker_session.blocked);
        assert_eq!(merged[0].turns, worker_session.turns);
        assert_eq!(merged[0].canonical.provider.as_deref(), Some("claude"));
        assert_eq!(merged[0].canonical.model.as_deref(), Some("sonnet"));
        assert_eq!(merged[0].canonical.reasoning.as_deref(), Some("high"));
        assert_eq!(merged[0].canonical.tokens.input, Some(210));
        assert_eq!(merged[0].canonical.tokens.output, Some(34));
        assert_eq!(
            merged[0].latest_resume_handle,
            worker_session.latest_resume_handle
        );
        assert_eq!(merged[0].turn_history, worker_session.turn_history);
    }

    #[test]
    fn listen_state_merge_preserves_worker_owned_fields_while_adopting_newer_timeout_metadata() {
        let daemon_session = AgentSession {
            issue_id: Some("issue-64".to_string()),
            issue_identifier: "MET-64".to_string(),
            issue_title: "Builtin Claude listen agent".to_string(),
            project_name: Some("MetaStack CLI".to_string()),
            team_key: "MET".to_string(),
            issue_url: "https://linear.app/issues/64".to_string(),
            phase: SessionPhase::Running,
            lifecycle: None,
            summary: "Running".to_string(),
            blocked: None,
            brief_path: None,
            backlog_issue_identifier: None,
            backlog_issue_title: None,
            backlog_path: None,
            workspace_path: None,
            branch: None,
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: None,
            started_at_epoch_seconds: 1_773_575_605,
            updated_at_epoch_seconds: 1_773_575_605,
            pid: Some(42),
            session_id: None,
            latest_resume_handle: None,
            context_budget_tokens: None,
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: Some(SessionTimeoutRecord {
                turn: 2,
                pid: 42,
                elapsed_seconds: 1_805,
                timeout_seconds: 1_800,
                graceful_shutdown_seconds: 5,
                termination: SessionTimeoutTermination::Sigterm,
            }),
            turns: Some(0),
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: None,
            origin: SessionOrigin::Listen,
        };
        let mut worker_session = daemon_session.clone();
        worker_session.phase = SessionPhase::Blocked;
        worker_session.summary = "Blocked | verification failed".to_string();
        worker_session.blocked = Some(blocked_reason(
            BlockedCategory::Gate,
            "verification failed and repair budget exhausted",
            false,
        ));
        worker_session.updated_at_epoch_seconds = 1_773_575_600;
        worker_session.last_timeout = None;
        worker_session.turns = Some(2);
        worker_session.canonical = CanonicalSessionData {
            provider: Some("claude".to_string()),
            model: Some("sonnet".to_string()),
            reasoning: Some("high".to_string()),
            tokens: TokenUsage {
                input: Some(210),
                output: Some(34),
            },
            repair: None,
        };
        worker_session.latest_resume_handle = Some(LatestResumeHandle {
            provider: ResumeProvider::Claude,
            id: "resume-worker-64".to_string(),
        });
        worker_session.turn_history = vec![
            TurnTokenSnapshot {
                turn: 1,
                prompt_mode: TurnPromptMode::FullPrompt,
                tokens: TokenUsage {
                    input: Some(210),
                    output: Some(34),
                },
                captured_at_epoch_seconds: 1_773_575_590,
            },
            TurnTokenSnapshot {
                turn: 2,
                prompt_mode: TurnPromptMode::Continuation,
                tokens: TokenUsage {
                    input: Some(80),
                    output: Some(13),
                },
                captured_at_epoch_seconds: 1_773_575_600,
            },
        ];

        let merged =
            super::merge_cycle_sessions(vec![worker_session.clone()], vec![daemon_session.clone()]);
        assert_eq!(merged.len(), 1);
        assert_eq!(merged[0].phase, SessionPhase::Blocked);
        assert_eq!(merged[0].summary, "Blocked | verification failed");
        assert_eq!(merged[0].blocked, worker_session.blocked);
        assert_eq!(merged[0].turns, worker_session.turns);
        assert_eq!(merged[0].canonical, worker_session.canonical);
        assert_eq!(
            merged[0].latest_resume_handle,
            worker_session.latest_resume_handle
        );
        assert_eq!(merged[0].turn_history, worker_session.turn_history);
        assert_eq!(merged[0].last_timeout, daemon_session.last_timeout);
        assert_eq!(
            merged[0].updated_at_epoch_seconds,
            daemon_session.updated_at_epoch_seconds
        );
    }

    #[test]
    fn listen_state_merge_preserves_higher_worker_phase_while_adopting_newer_daemon_timeout() {
        let daemon_session = AgentSession {
            issue_id: Some("issue-65".to_string()),
            issue_identifier: "MET-65".to_string(),
            issue_title: "Listen verification handoff".to_string(),
            project_name: Some("MetaStack CLI".to_string()),
            team_key: "MET".to_string(),
            issue_url: "https://linear.app/issues/65".to_string(),
            phase: SessionPhase::Running,
            lifecycle: None,
            summary: "Running".to_string(),
            blocked: None,
            brief_path: None,
            backlog_issue_identifier: None,
            backlog_issue_title: None,
            backlog_path: None,
            workspace_path: None,
            branch: None,
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: None,
            started_at_epoch_seconds: 1_773_575_705,
            updated_at_epoch_seconds: 1_773_575_705,
            pid: Some(42),
            session_id: None,
            latest_resume_handle: None,
            context_budget_tokens: None,
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: Some(SessionTimeoutRecord {
                turn: 3,
                pid: 42,
                elapsed_seconds: 1_805,
                timeout_seconds: 1_800,
                graceful_shutdown_seconds: 5,
                termination: SessionTimeoutTermination::Sigterm,
            }),
            turns: Some(2),
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: None,
            origin: SessionOrigin::Listen,
        };
        let mut worker_session = daemon_session.clone();
        worker_session.phase = SessionPhase::Verifying;
        worker_session.summary = "Verifying turn 3 via verify-stub".to_string();
        worker_session.updated_at_epoch_seconds = 1_773_575_700;
        worker_session.last_timeout = None;
        worker_session.turns = Some(3);

        let merged =
            super::merge_cycle_sessions(vec![worker_session.clone()], vec![daemon_session.clone()]);
        assert_eq!(merged.len(), 1);
        assert_eq!(merged[0].phase, SessionPhase::Verifying);
        assert_eq!(merged[0].summary, worker_session.summary);
        assert_eq!(merged[0].last_timeout, daemon_session.last_timeout);
        assert_eq!(
            merged[0].updated_at_epoch_seconds,
            daemon_session.updated_at_epoch_seconds
        );
    }

    #[test]
    fn listen_state_merge_preserves_persisted_context_budget_tokens() {
        let daemon_session = AgentSession {
            issue_id: Some("issue-66".to_string()),
            issue_identifier: "MET-66".to_string(),
            issue_title: "Context pressure persistence".to_string(),
            project_name: Some("MetaStack CLI".to_string()),
            team_key: "MET".to_string(),
            issue_url: "https://linear.app/issues/66".to_string(),
            phase: SessionPhase::Running,
            lifecycle: None,
            summary: "Running".to_string(),
            blocked: None,
            brief_path: None,
            backlog_issue_identifier: None,
            backlog_issue_title: None,
            backlog_path: None,
            workspace_path: None,
            branch: None,
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: None,
            started_at_epoch_seconds: 1_773_575_805,
            updated_at_epoch_seconds: 1_773_575_805,
            pid: Some(42),
            session_id: None,
            latest_resume_handle: None,
            context_budget_tokens: Some(crate::config::DEFAULT_LISTEN_CONTEXT_BUDGET_TOKENS),
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: None,
            turns: Some(2),
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: None,
            origin: SessionOrigin::Listen,
        };
        let mut worker_session = daemon_session.clone();
        worker_session.updated_at_epoch_seconds = 1_773_575_800;
        worker_session.context_budget_tokens = Some(90_000);

        let merged =
            super::merge_cycle_sessions(vec![worker_session.clone()], vec![daemon_session.clone()]);

        assert_eq!(merged.len(), 1);
        assert_eq!(merged[0].context_budget_tokens, Some(90_000));
        assert_eq!(
            merged[0].updated_at_epoch_seconds,
            daemon_session.updated_at_epoch_seconds
        );
    }

    #[test]
    fn listen_state_merge_persists_equal_timestamp_summary_updates() {
        let persisted_session = AgentSession {
            issue_id: Some("issue-67".to_string()),
            issue_identifier: "MET-67".to_string(),
            issue_title: "Post-merge cleanup reconciliation".to_string(),
            project_name: Some("MetaStack CLI".to_string()),
            team_key: "MET".to_string(),
            issue_url: "https://linear.app/issues/67".to_string(),
            phase: SessionPhase::Completed,
            lifecycle: None,
            summary: "Completed | waiting for merge reconciliation".to_string(),
            blocked: None,
            brief_path: None,
            backlog_issue_identifier: None,
            backlog_issue_title: None,
            backlog_path: None,
            workspace_path: Some("/tmp/MET-67".to_string()),
            branch: Some("met-67-post-merge-cleanup".to_string()),
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: None,
            started_at_epoch_seconds: 1_773_575_905,
            updated_at_epoch_seconds: 1_773_575_905,
            pid: None,
            session_id: None,
            latest_resume_handle: None,
            context_budget_tokens: None,
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: None,
            turns: Some(1),
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: None,
            origin: SessionOrigin::Listen,
        };
        let mut daemon_session = persisted_session.clone();
        daemon_session.summary =
            "Complete | preserved after merge (uncommitted changes detected)".to_string();

        let merged =
            super::merge_cycle_sessions(vec![persisted_session], vec![daemon_session.clone()]);

        assert_eq!(merged.len(), 1);
        assert_eq!(merged[0].summary, daemon_session.summary);
        assert_eq!(
            merged[0].updated_at_epoch_seconds,
            daemon_session.updated_at_epoch_seconds
        );
    }

    #[test]
    fn parse_codex_thread_id_from_log_reads_latest_started_event() -> Result<()> {
        let temp = tempdir()?;
        let log_path = temp.path().join("MET-7.log");
        fs::write(
            &log_path,
            concat!(
                "plain text\n",
                "{\"type\":\"thread.started\",\"thread_id\":\"thread-1\"}\n",
                "{\"type\":\"thread.started\",\"thread_id\":\"thread-2\"}\n"
            ),
        )?;

        assert_eq!(
            super::parse_codex_thread_id_from_log(&log_path)?,
            Some("thread-2".to_string())
        );
        Ok(())
    }

    #[test]
    fn codex_live_token_hydrator_ignores_legacy_session_id_without_resume_handle() -> Result<()> {
        let temp = tempdir()?;
        let sessions_root = temp.path().join(".codex").join("sessions");
        fs::create_dir_all(&sessions_root)?;
        fs::write(
            sessions_root.join("legacy-session-1.jsonl"),
            "{\"type\":\"event_msg\"}\n",
        )?;

        let mut hydrator = super::CodexLiveTokenHydrator {
            sessions_root: Some(sessions_root),
            snapshots: HashMap::new(),
        };
        let session = AgentSession {
            issue_id: Some("issue-1".to_string()),
            issue_identifier: "ENG-9".to_string(),
            issue_title: "Legacy continuation bookkeeping".to_string(),
            project_name: None,
            team_key: "ENG".to_string(),
            issue_url: "https://linear.app/issues/ENG-9".to_string(),
            phase: SessionPhase::Running,
            lifecycle: None,
            summary: "running".to_string(),
            blocked: None,
            brief_path: None,
            backlog_issue_identifier: None,
            backlog_issue_title: None,
            backlog_path: None,
            workspace_path: None,
            branch: None,
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: None,
            started_at_epoch_seconds: 1,
            updated_at_epoch_seconds: 1,
            pid: None,
            session_id: Some("legacy-session-1".to_string()),
            latest_resume_handle: None,
            context_budget_tokens: None,
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: None,
            turns: None,
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: None,
            origin: SessionOrigin::default(),
        };

        assert_eq!(hydrator.resolve_thread_id(&session)?, None);
        Ok(())
    }

    #[test]
    fn codex_live_token_hydrator_uses_log_thread_when_resume_handle_missing() -> Result<()> {
        let temp = tempdir()?;
        let sessions_root = temp.path().join(".codex").join("sessions");
        fs::create_dir_all(&sessions_root)?;
        fs::write(
            sessions_root.join("thread-log-derived.jsonl"),
            "{\"type\":\"event_msg\"}\n",
        )?;
        let log_path = temp.path().join("ENG-10.log");
        fs::write(
            &log_path,
            "{\"type\":\"thread.started\",\"thread_id\":\"thread-log-derived\"}\n",
        )?;

        let mut hydrator = super::CodexLiveTokenHydrator {
            sessions_root: Some(sessions_root),
            snapshots: HashMap::new(),
        };
        let session = AgentSession {
            issue_id: Some("issue-1".to_string()),
            issue_identifier: "ENG-10".to_string(),
            issue_title: "Codex thread from log".to_string(),
            project_name: None,
            team_key: "ENG".to_string(),
            issue_url: "https://linear.app/issues/ENG-10".to_string(),
            phase: SessionPhase::Running,
            lifecycle: None,
            summary: "running".to_string(),
            blocked: None,
            brief_path: None,
            backlog_issue_identifier: None,
            backlog_issue_title: None,
            backlog_path: None,
            workspace_path: None,
            branch: None,
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: None,
            started_at_epoch_seconds: 1,
            updated_at_epoch_seconds: 1,
            pid: None,
            session_id: Some("legacy-session-1".to_string()),
            latest_resume_handle: None,
            context_budget_tokens: None,
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: None,
            turns: None,
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: Some(log_path.display().to_string()),
            origin: SessionOrigin::default(),
        };

        assert_eq!(
            hydrator.resolve_thread_id(&session)?,
            Some("thread-log-derived".to_string())
        );
        Ok(())
    }

    #[test]
    fn parse_codex_token_usage_from_session_file_reads_total_usage() -> Result<()> {
        let temp = tempdir()?;
        let session_path = temp.path().join("rollout-thread-2.jsonl");
        fs::write(
            &session_path,
            concat!(
                "{\"type\":\"event_msg\",\"payload\":{\"type\":\"token_count\",\"info\":{\"total_token_usage\":{\"input_tokens\":120,\"cached_input_tokens\":30,\"output_tokens\":8,\"reasoning_output_tokens\":2}}}}\n",
                "{\"type\":\"event_msg\",\"payload\":{\"type\":\"token_count\",\"info\":{\"total_token_usage\":{\"input_tokens\":200,\"cached_input_tokens\":50,\"output_tokens\":11,\"reasoning_output_tokens\":4}}}}\n"
            ),
        )?;

        assert_eq!(
            super::parse_codex_token_usage_from_session_file(&session_path)?,
            Some(TokenUsage {
                input: Some(250),
                output: Some(15),
            })
        );
        Ok(())
    }

    fn listen_settings(required_labels: Option<Vec<&str>>) -> PlanningListenSettings {
        PlanningListenSettings {
            required_labels: required_labels
                .map(|labels| labels.into_iter().map(str::to_string).collect::<Vec<_>>()),
            ..PlanningListenSettings::default()
        }
    }

    fn issue_with_labels(labels: &[&str]) -> IssueSummary {
        IssueSummary {
            id: "issue-1".to_string(),
            identifier: "ENG-10211".to_string(),
            title: "Listen labels".to_string(),
            description: None,
            url: "https://linear.app/issues/eng-10211".to_string(),
            priority: None,
            estimate: None,
            updated_at: "2026-03-19T00:00:00Z".to_string(),
            team: TeamRef {
                id: "team-1".to_string(),
                key: "ENG".to_string(),
                name: "Engineering".to_string(),
            },
            project: None,
            assignee: None,
            labels: labels
                .iter()
                .enumerate()
                .map(|(index, label)| LabelRef {
                    id: format!("label-{index}"),
                    name: (*label).to_string(),
                })
                .collect(),
            comments: Vec::new(),
            state: None,
            attachments: Vec::new(),
            parent: None,
            children: Vec::new(),
        }
    }

    #[test]
    fn required_label_skip_reason_allows_single_label_match() {
        let issue = issue_with_labels(&["plan"]);

        assert_eq!(
            required_label_skip_reason(&listen_settings(Some(vec!["plan"])), &issue),
            None
        );
    }

    #[test]
    fn required_label_skip_reason_allows_any_matching_label() {
        let issue = issue_with_labels(&["bug", "urgent"]);

        assert_eq!(
            required_label_skip_reason(&listen_settings(Some(vec!["plan", "urgent"])), &issue),
            None
        );
    }

    #[test]
    fn required_label_skip_reason_is_case_insensitive() {
        let issue = issue_with_labels(&["Urgent"]);

        assert_eq!(
            required_label_skip_reason(&listen_settings(Some(vec!["urgent"])), &issue),
            None
        );
    }

    #[test]
    fn required_label_skip_reason_ignores_empty_required_labels() {
        let issue = issue_with_labels(&[]);

        assert_eq!(
            required_label_skip_reason(&listen_settings(Some(Vec::new())), &issue),
            None
        );
    }

    #[test]
    fn required_label_skip_reason_ignores_unset_required_labels() {
        let issue = issue_with_labels(&[]);

        assert_eq!(
            required_label_skip_reason(&listen_settings(None), &issue),
            None
        );
    }

    #[test]
    fn required_label_skip_reason_reports_missing_any_match() {
        let issue = issue_with_labels(&["bug"]);

        assert_eq!(
            required_label_skip_reason(&listen_settings(Some(vec!["plan", "urgent"])), &issue),
            Some("missing any required label (`plan`, `urgent`)".to_string())
        );
    }

    #[test]
    fn dead_running_session_is_marked_blocked_and_stale() {
        let mut session = AgentSession {
            issue_id: Some("issue-1".to_string()),
            issue_identifier: "ENG-10163".to_string(),
            issue_title: "Listen cleanup".to_string(),
            project_name: Some("MetaStack CLI".to_string()),
            team_key: "MET".to_string(),
            issue_url: "https://linear.app/issues/eng-10163".to_string(),
            phase: SessionPhase::Running,
            lifecycle: None,
            summary: "Running".to_string(),
            blocked: None,
            brief_path: Some(format!(
                "{}/agents/briefs/ENG-10163.md",
                crate::branding::PROJECT_DIR
            )),
            backlog_issue_identifier: Some("TECH-1".to_string()),
            backlog_issue_title: Some("Backlog".to_string()),
            backlog_path: Some(format!("{}/backlog/TECH-1", crate::branding::PROJECT_DIR)),
            workspace_path: Some("/tmp/ENG-10163".to_string()),
            branch: Some("eng-10163".to_string()),
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: Some("comment-1".to_string()),
            started_at_epoch_seconds: 1,
            updated_at_epoch_seconds: 1,
            pid: Some(42_424),
            session_id: Some("session-1".to_string()),
            latest_resume_handle: None,
            context_budget_tokens: None,
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: None,
            turns: Some(2),
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: Some("logs/ENG-10163.log".to_string()),
            origin: SessionOrigin::Listen,
        };

        mark_running_session_stale(&mut session, "ENG-10163", Path::new("fallback.log"), 42_424);

        assert_eq!(session.phase, SessionPhase::Running);
        assert_eq!(
            session
                .lifecycle
                .as_ref()
                .map(|lifecycle| lifecycle.outcome),
            Some(SessionLifecycleOutcome::Blocked)
        );
        assert_eq!(
            session
                .lifecycle
                .as_ref()
                .and_then(|lifecycle| lifecycle.exit_condition),
            Some(SessionExitCondition::WorkerDied)
        );
        assert_eq!(session.workspace_path.as_deref(), Some("/tmp/ENG-10163"));
        assert_eq!(session.log_path.as_deref(), Some("logs/ENG-10163.log"));
        assert!(session.summary.contains("Blocked | worker died"));
        assert!(session.summary.contains("stale pid 42424"));
        assert!(session.summary.contains("see logs/ENG-10163.log"));
    }

    #[test]
    fn stale_running_session_relaunches_with_existing_context_and_fresh_pid() -> Result<()> {
        let temp = tempdir()?;
        let workspace = temp.path().join("workspace");
        fs::create_dir_all(&workspace)?;
        let issue = in_progress_issue();
        let mut session = AgentSession {
            issue_id: Some(issue.id.clone()),
            issue_identifier: issue.identifier.clone(),
            issue_title: issue.title.clone(),
            project_name: issue.project.as_ref().map(|project| project.name.clone()),
            team_key: issue.team.key.clone(),
            issue_url: issue.url.clone(),
            phase: SessionPhase::Running,
            lifecycle: None,
            summary: "Running".to_string(),
            blocked: None,
            brief_path: None,
            backlog_issue_identifier: Some("TECH-90".to_string()),
            backlog_issue_title: Some("Backlog".to_string()),
            backlog_path: Some("/tmp/backlog/TECH-90".to_string()),
            workspace_path: Some(workspace.display().to_string()),
            branch: Some("met-90-recovery".to_string()),
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: Some("comment-90".to_string()),
            started_at_epoch_seconds: 1_773_575_000,
            updated_at_epoch_seconds: 1_773_575_100,
            pid: Some(42_424),
            session_id: Some(issue.id.clone()),
            latest_resume_handle: None,
            context_budget_tokens: None,
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: None,
            turns: Some(1),
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: Some("logs/ENG-90.log".to_string()),
            origin: SessionOrigin::Listen,
        };

        let note = super::reconcile_stale_worker_session(
            &mut session,
            &issue,
            Path::new("logs/ENG-90.log"),
            |_recovery_session, workspace_path, workpad_comment_id, backlog_issue_identifier| {
                assert_eq!(workspace_path, workspace.as_path());
                assert_eq!(workpad_comment_id, "comment-90");
                assert_eq!(backlog_issue_identifier, Some("TECH-90"));
                Ok(51_515)
            },
        );

        assert_eq!(session.phase, SessionPhase::Running);
        assert_eq!(session.pid, Some(51_515));
        assert_eq!(
            session.workspace_path.as_deref(),
            Some(workspace.to_str().unwrap())
        );
        assert_eq!(session.workpad_comment_id.as_deref(), Some("comment-90"));
        assert_eq!(session.backlog_issue_identifier.as_deref(), Some("TECH-90"));
        assert_eq!(session.stale_worker_recovery_attempt_count, 1);
        assert_eq!(session.started_at_epoch_seconds, 1_773_575_000);
        assert_eq!(
            session
                .latest_stale_worker_failure
                .as_ref()
                .map(|failure| failure.pid),
            Some(42_424)
        );
        assert!(session.summary.contains("Recovered stale worker"));
        assert!(note.contains("fresh pid 51515"));
        Ok(())
    }

    #[test]
    fn stale_running_session_budget_exhaustion_blocks_without_relaunch() -> Result<()> {
        let temp = tempdir()?;
        let workspace = temp.path().join("workspace");
        fs::create_dir_all(&workspace)?;
        let issue = in_progress_issue();
        let mut session = AgentSession {
            issue_id: Some(issue.id.clone()),
            issue_identifier: issue.identifier.clone(),
            issue_title: issue.title.clone(),
            project_name: issue.project.as_ref().map(|project| project.name.clone()),
            team_key: issue.team.key.clone(),
            issue_url: issue.url.clone(),
            phase: SessionPhase::Running,
            lifecycle: None,
            summary: "Running".to_string(),
            blocked: None,
            brief_path: None,
            backlog_issue_identifier: Some("TECH-90".to_string()),
            backlog_issue_title: Some("Backlog".to_string()),
            backlog_path: Some("/tmp/backlog/TECH-90".to_string()),
            workspace_path: Some(workspace.display().to_string()),
            branch: Some("met-90-recovery".to_string()),
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: Some("comment-90".to_string()),
            started_at_epoch_seconds: 1_773_575_000,
            updated_at_epoch_seconds: 1_773_575_100,
            pid: Some(42_424),
            session_id: Some(issue.id.clone()),
            latest_resume_handle: None,
            context_budget_tokens: None,
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: super::MAX_STALE_WORKER_RECOVERY_ATTEMPTS,
            latest_stale_worker_failure: None,
            last_timeout: None,
            turns: Some(1),
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: Some("logs/ENG-90.log".to_string()),
            origin: SessionOrigin::Listen,
        };

        let note = super::reconcile_stale_worker_session(
            &mut session,
            &issue,
            Path::new("logs/ENG-90.log"),
            |_recovery_session, _workspace_path, _workpad_comment_id, _backlog_issue_identifier| {
                panic!("retry-budget exhaustion must not relaunch a worker")
            },
        );

        assert_eq!(session.phase, SessionPhase::Running);
        assert_eq!(
            session
                .lifecycle
                .as_ref()
                .map(|lifecycle| lifecycle.outcome),
            Some(SessionLifecycleOutcome::Blocked)
        );
        assert_eq!(
            session
                .lifecycle
                .as_ref()
                .and_then(|lifecycle| lifecycle.exit_condition),
            Some(SessionExitCondition::WorkerDied)
        );
        assert_eq!(session.pid, Some(42_424));
        assert_eq!(
            session
                .blocked
                .as_ref()
                .map(|blocked| blocked.reason.as_str()),
            Some("stale worker retry budget exhausted")
        );
        assert_eq!(
            session
                .latest_stale_worker_failure
                .as_ref()
                .map(|failure| failure.classification.reason.as_str()),
            Some("stale worker retry budget exhausted")
        );
        assert!(note.contains("parked as blocked"));
        Ok(())
    }

    #[test]
    fn stale_worker_recovery_persists_metadata_before_replacement_worker_write() -> Result<()> {
        let temp = tempdir()?;
        let root = temp.path();
        let workspace = root.join("workspace");
        fs::create_dir_all(root.join(crate::branding::PROJECT_DIR))?;
        fs::write(
            root.join(format!("{}/meta.json", crate::branding::PROJECT_DIR)),
            "{}\n",
        )?;
        fs::create_dir_all(&workspace)?;
        let issue = in_progress_issue();
        let store = ListenProjectStore::resolve(root, None)?;

        let initial_session = AgentSession {
            issue_id: Some(issue.id.clone()),
            issue_identifier: issue.identifier.clone(),
            issue_title: issue.title.clone(),
            project_name: issue.project.as_ref().map(|project| project.name.clone()),
            team_key: issue.team.key.clone(),
            issue_url: issue.url.clone(),
            phase: SessionPhase::Running,
            lifecycle: None,
            summary: "Running".to_string(),
            blocked: None,
            brief_path: None,
            backlog_issue_identifier: Some("TECH-90".to_string()),
            backlog_issue_title: Some("Backlog".to_string()),
            backlog_path: Some("/tmp/backlog/TECH-90".to_string()),
            workspace_path: Some(workspace.display().to_string()),
            branch: Some("met-90-recovery".to_string()),
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: Some("comment-90".to_string()),
            started_at_epoch_seconds: 1_773_575_000,
            updated_at_epoch_seconds: 1_773_575_100,
            pid: Some(42_424),
            session_id: Some(issue.id.clone()),
            latest_resume_handle: None,
            context_budget_tokens: None,
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: None,
            turns: Some(1),
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: Some("logs/ENG-90.log".to_string()),
            origin: SessionOrigin::Listen,
        };
        store.upsert_session(initial_session.clone())?;

        let mut session = initial_session;
        let note = super::reconcile_stale_worker_session(
            &mut session,
            &issue,
            Path::new("logs/ENG-90.log"),
            |recovery_session, workspace_path, workpad_comment_id, backlog_issue_identifier| {
                assert_eq!(workspace_path, workspace.as_path());
                assert_eq!(workpad_comment_id, "comment-90");
                assert_eq!(backlog_issue_identifier, Some("TECH-90"));

                store.upsert_session(recovery_session.clone())?;

                let persisted_recovery = store
                    .load_state()?
                    .sessions
                    .into_iter()
                    .find(|stored| stored.issue_matches(&issue.identifier))
                    .expect("recovery snapshot should be persisted");
                assert_eq!(persisted_recovery.pid, None);
                assert_eq!(persisted_recovery.stale_worker_recovery_attempt_count, 1);
                assert_eq!(
                    persisted_recovery
                        .latest_stale_worker_failure
                        .as_ref()
                        .map(|failure| failure.pid),
                    Some(42_424)
                );

                let mut replacement_worker_session = persisted_recovery.clone();
                replacement_worker_session.pid = Some(51_515);
                replacement_worker_session.summary = "Replacement worker running".to_string();
                replacement_worker_session.updated_at_epoch_seconds += 1;
                store.upsert_session(replacement_worker_session)?;

                Ok(51_515)
            },
        );

        let persisted_after_worker_write = store
            .load_state()?
            .sessions
            .into_iter()
            .find(|stored| stored.issue_matches(&issue.identifier))
            .expect("replacement worker write should persist a session");
        assert_eq!(persisted_after_worker_write.pid, Some(51_515));
        assert_eq!(
            persisted_after_worker_write.stale_worker_recovery_attempt_count,
            1
        );
        assert_eq!(
            persisted_after_worker_write.started_at_epoch_seconds,
            1_773_575_000
        );
        assert_eq!(
            persisted_after_worker_write
                .latest_stale_worker_failure
                .as_ref()
                .map(|failure| failure.pid),
            Some(42_424)
        );
        assert!(note.contains("fresh pid 51515"));
        Ok(())
    }

    #[test]
    fn listen_browser_action_accepts_uppercase_pause_key() {
        assert_eq!(
            listen_browser_action(KeyCode::Char('P'), false),
            Some(SessionBrowserAction::Pause)
        );
    }

    #[test]
    fn loading_cycle_starts_empty_and_explains_initial_refresh() {
        let cycle = ListenCycleData::loading(
            "MET / MetaStack CLI".to_string(),
            "all assignees".to_string(),
            format!(
                "{}/agents/sessions/listen-state.json",
                crate::branding::PROJECT_DIR
            ),
        );

        assert_eq!(cycle.scope, "MET / MetaStack CLI");
        assert_eq!(cycle.watch_scope, "all assignees");
        assert_eq!(cycle.claimed_this_cycle, 0);
        assert!(cycle.pending_issues.is_empty());
        assert!(cycle.sessions.is_empty());
        assert_eq!(
            cycle.notes,
            vec![
                "Starting dashboard before the first Linear refresh completes.".to_string(),
                "Refreshing current Todo issues, listener sessions, and workspace state now."
                    .to_string(),
            ]
        );
        assert_eq!(
            cycle.state_file,
            format!(
                "{}/agents/sessions/listen-state.json",
                crate::branding::PROJECT_DIR
            )
        );
        assert_eq!(cycle.rate_limits, None);
    }

    #[test]
    fn cycle_state_snapshot_refreshes_sessions_without_resetting_linear_data() {
        let mut cycle = ListenCycleData::demo(
            Path::new("."),
            format!(
                "{}/agents/sessions/listen-state.json",
                crate::branding::PROJECT_DIR
            ),
        );
        let existing_pending_count = cycle.pending_issues.len();
        let existing_pending_identifier = cycle
            .pending_issues
            .first()
            .map(|issue| issue.identifier.clone());
        let existing_notes = cycle.notes.clone();
        let existing_scope = cycle.scope.clone();
        let existing_claimed = cycle.claimed_this_cycle;

        let mut completed = cycle
            .sessions
            .first()
            .expect("demo cycle should include a session")
            .clone();
        completed.issue_identifier = "MET-99".to_string();
        completed.issue_title = "Completed ticket".to_string();
        completed.phase = SessionPhase::Completed;
        completed.summary = "Complete | moved to `Human Review`".to_string();
        completed.updated_at_epoch_seconds += 60;

        cycle.apply_state_snapshot(
            ListenState::from_sessions(vec![completed.clone()]),
            vec![completed.clone()],
            HashMap::new(),
        );

        assert_eq!(cycle.sessions.len(), 1);
        assert_eq!(
            cycle.sessions[0].issue_identifier,
            completed.issue_identifier
        );
        assert_eq!(cycle.sessions[0].phase, SessionPhase::Completed);
        assert_eq!(cycle.sessions[0].summary, completed.summary);
        assert_eq!(cycle.pending_issues.len(), existing_pending_count);
        assert_eq!(
            cycle
                .pending_issues
                .first()
                .map(|issue| issue.identifier.clone()),
            existing_pending_identifier
        );
        assert_eq!(cycle.notes, existing_notes);
        assert_eq!(cycle.scope, existing_scope);
        assert_eq!(cycle.claimed_this_cycle, existing_claimed);
    }

    #[test]
    fn workspace_snapshot_ignores_generated_agent_brief() {
        let temp = tempdir().expect("tempdir should build");
        let repo = temp.path();
        run_git(repo, &["init"]).expect("git init should succeed");
        run_git(repo, &["config", "user.email", "listen@example.com"])
            .expect("git config should succeed");
        run_git(repo, &["config", "user.name", "Listen Tests"]).expect("git config should succeed");
        fs::write(repo.join("README.md"), "# Demo\n").expect("readme should write");
        run_git(repo, &["add", "README.md"]).expect("git add should succeed");
        run_git(repo, &["commit", "-m", "init"]).expect("git commit should succeed");

        let brief_path = repo.join(format!(
            "{}/agents/briefs/MET-36.md",
            crate::branding::PROJECT_DIR
        ));
        fs::create_dir_all(
            brief_path
                .parent()
                .expect("brief path should have a parent"),
        )
        .expect("brief dir should build");
        fs::write(&brief_path, "# brief\n").expect("brief should write");

        let baseline =
            capture_workspace_snapshot(repo, "MET-36").expect("snapshot should build for brief");
        assert!(
            baseline.status_entries.is_empty(),
            "generated brief should not count as local progress: {:?}",
            baseline.status_entries
        );

        fs::write(repo.join("src.rs"), "fn main() {}\n").expect("source file should write");
        let updated =
            capture_workspace_snapshot(repo, "MET-36").expect("snapshot should build for change");
        assert_ne!(baseline, updated);
        assert!(
            updated
                .status_entries
                .iter()
                .any(|entry: &String| entry.contains("src.rs")),
            "expected src.rs in status entries: {:?}",
            updated.status_entries
        );
    }

    #[test]
    fn volatile_validation_artifact_checkpoint_edits_do_not_count_as_implementation_progress() {
        let temp = tempdir().expect("tempdir should build");
        let repo = temp.path();
        run_git(repo, &["init"]).expect("git init should succeed");
        run_git(repo, &["config", "user.email", "listen@example.com"])
            .expect("git config should succeed");
        run_git(repo, &["config", "user.name", "Listen Tests"]).expect("git config should succeed");
        fs::write(repo.join("README.md"), "# Demo\n").expect("readme should write");
        run_git(repo, &["add", "README.md"]).expect("git add should succeed");
        run_git(repo, &["commit", "-m", "init"]).expect("git commit should succeed");

        let artifact_path = repo.join("artifacts/validation/MET-36.md");
        fs::create_dir_all(
            artifact_path
                .parent()
                .expect("artifact path should have a parent"),
        )
        .expect("artifact dir should build");
        fs::write(
            &artifact_path,
            "# MET-36 Validation\n\n## Command Proofs\n\n- `cargo test`\n\n## Context Checkpoint\n\n- Captured at: 2026-04-17T18:03:37Z\n- Execution turn: 6/6 final checkpoint\n- Push state at capture: synchronized through `386b9510`; this final artifact delta must be committed and pushed before handoff.\n",
        )
        .expect("artifact should write");
        run_git(repo, &["add", "artifacts/validation/MET-36.md"]).expect("git add should succeed");
        run_git(repo, &["commit", "-m", "add validation artifact"])
            .expect("git commit should succeed");

        let baseline = capture_workspace_snapshot(repo, "MET-36")
            .expect("baseline snapshot should build for artifact");
        fs::write(
            &artifact_path,
            "# MET-36 Validation\n\n## Command Proofs\n\n- `cargo test`\n\n## Context Checkpoint\n\n- Captured at: 2026-04-17T18:03:54Z\n- Execution turn: 8/8 final checkpoint\n- Push state at capture: synchronized through `979c438a`; this final artifact delta must be committed and pushed before handoff.\n",
        )
        .expect("artifact should update");
        run_git(repo, &["add", "artifacts/validation/MET-36.md"]).expect("git add should succeed");
        run_git(repo, &["commit", "-m", "refresh volatile handoff"])
            .expect("git commit should succeed");

        let updated =
            capture_workspace_snapshot(repo, "MET-36").expect("updated snapshot should build");
        let progress = compare_workspace_snapshots(repo, &baseline, &updated)
            .expect("progress should compare");

        assert!(
            progress.implementation_entries.is_empty(),
            "volatile artifact changes should not count as implementation progress: {:?}",
            progress.implementation_entries
        );
        assert!(progress.planning_entries.is_empty());
        assert_eq!(
            progress.volatile_validation_entries,
            vec!["artifacts/validation/MET-36.md".to_string()]
        );
    }

    #[test]
    fn substantive_validation_artifact_edits_count_as_implementation_progress() {
        let temp = tempdir().expect("tempdir should build");
        let repo = temp.path();
        run_git(repo, &["init"]).expect("git init should succeed");
        run_git(repo, &["config", "user.email", "listen@example.com"])
            .expect("git config should succeed");
        run_git(repo, &["config", "user.name", "Listen Tests"]).expect("git config should succeed");
        fs::create_dir_all(repo.join("artifacts/validation")).expect("artifact dir should build");
        fs::write(
            repo.join("artifacts/validation/MET-36.md"),
            "# MET-36 Validation\n\n## Command Proofs\n\n- `cargo test`\n",
        )
        .expect("artifact should write");
        run_git(repo, &["add", "artifacts/validation/MET-36.md"]).expect("git add should succeed");
        run_git(repo, &["commit", "-m", "add validation artifact"])
            .expect("git commit should succeed");

        let baseline = capture_workspace_snapshot(repo, "MET-36")
            .expect("baseline snapshot should build for artifact");
        fs::write(
            repo.join("artifacts/validation/MET-36.md"),
            "# MET-36 Validation\n\n## Command Proofs\n\n- `cargo test`\n- `cargo clippy --all-targets --all-features -- -D warnings`\n",
        )
        .expect("artifact should update");
        run_git(repo, &["add", "artifacts/validation/MET-36.md"]).expect("git add should succeed");
        run_git(repo, &["commit", "-m", "add validation proof"])
            .expect("git commit should succeed");

        let updated =
            capture_workspace_snapshot(repo, "MET-36").expect("updated snapshot should build");
        let progress = compare_workspace_snapshots(repo, &baseline, &updated)
            .expect("progress should compare");

        assert_eq!(
            progress.implementation_entries,
            vec!["artifacts/validation/MET-36.md".to_string()]
        );
        assert!(progress.volatile_validation_entries.is_empty());
    }

    #[test]
    fn github_actions_validation_proof_counts_as_implementation_progress() {
        let temp = tempdir().expect("tempdir should build");
        let repo = temp.path();
        run_git(repo, &["init"]).expect("git init should succeed");
        run_git(repo, &["config", "user.email", "listen@example.com"])
            .expect("git config should succeed");
        run_git(repo, &["config", "user.name", "Listen Tests"]).expect("git config should succeed");
        fs::create_dir_all(repo.join("artifacts/validation")).expect("artifact dir should build");
        fs::write(
            repo.join("artifacts/validation/MET-36.md"),
            "# MET-36 Validation\n\n## Command Proofs\n\n- `cargo test`\n",
        )
        .expect("artifact should write");
        run_git(repo, &["add", "artifacts/validation/MET-36.md"]).expect("git add should succeed");
        run_git(repo, &["commit", "-m", "add validation artifact"])
            .expect("git commit should succeed");

        let baseline = capture_workspace_snapshot(repo, "MET-36")
            .expect("baseline snapshot should build for artifact");
        fs::write(
            repo.join("artifacts/validation/MET-36.md"),
            "# MET-36 Validation\n\n## Command Proofs\n\n- `cargo test`\n- GitHub Actions `quality` workflow passed on `a790d24`.\n",
        )
        .expect("artifact should update");
        run_git(repo, &["add", "artifacts/validation/MET-36.md"]).expect("git add should succeed");
        run_git(repo, &["commit", "-m", "add ci validation proof"])
            .expect("git commit should succeed");

        let updated =
            capture_workspace_snapshot(repo, "MET-36").expect("updated snapshot should build");
        let progress = compare_workspace_snapshots(repo, &baseline, &updated)
            .expect("progress should compare");

        assert_eq!(
            progress.implementation_entries,
            vec!["artifacts/validation/MET-36.md".to_string()]
        );
        assert!(progress.volatile_validation_entries.is_empty());
    }

    #[test]
    fn listen_scope_label_uses_effective_default_project_identity() {
        assert_eq!(
            listen_scope_label(Some("MET"), Some("project-default"), "project-default"),
            "MET / project-default"
        );
    }

    #[test]
    fn listen_scope_label_falls_back_to_team_without_project_scope() {
        assert_eq!(listen_scope_label(Some("MET"), None, "All projects"), "MET");
        assert_eq!(listen_scope_label(None, None, "All projects"), "all teams");
    }

    #[test]
    fn render_agent_prompt_turn_one_avoids_full_description_duplication() {
        let temp = tempdir().expect("temp dir should build");
        let workspace = temp.path();
        ensure_dir(&PlanningPaths::new(workspace).codebase_dir).expect("codebase dir should build");
        let description = "# Context\n\nNarrative block that should not appear in full across turn-one surfaces.\n\n## Validation\n\n- `cargo test`\n\n## Acceptance Criteria\n\n- [ ] Preserve compact output\n".to_string();
        let issue = IssueSummary {
            description: Some(description.clone()),
            ..test_issue("ENG-10793")
        };
        let brief_path = write_agent_brief(
            workspace,
            AgentBriefRequest {
                ticket: issue.identifier.clone(),
                title_override: Some(issue.title.clone()),
                goal: Some("Keep turn one compact.".to_string()),
                metadata: TicketMetadata {
                    description: issue.description.clone(),
                    ..TicketMetadata::default()
                },
                output: None,
            },
        )
        .expect("brief should write");
        let brief = fs::read_to_string(brief_path).expect("brief should read");
        let prompt = render_agent_prompt(&issue, workspace, "comment-24", Some(&issue), 1, 20);

        assert!(prompt.contains("Description summary:"));
        assert!(prompt.contains("Narrative block that should not appear in full"));
        assert!(prompt.contains("## Validation\n\n- `cargo test`"));
        assert!(prompt.contains("## Acceptance Criteria\n\n- [ ] Preserve compact output"));
        assert!(!brief.contains("Narrative block that should not appear in full"));
    }

    #[test]
    fn render_issue_attachment_manifest_adds_prioritized_summary() {
        let temp = tempdir().expect("temp dir should build");
        let workspace = temp.path();
        let issue = IssueSummary {
            attachments: vec![
                AttachmentSummary {
                    id: "attachment-1".to_string(),
                    title: "Validation".to_string(),
                    url: "https://example.com/validation.md".to_string(),
                    source_type: None,
                    metadata: serde_json::Value::Null,
                },
                AttachmentSummary {
                    id: "attachment-2".to_string(),
                    title: "Screenshot".to_string(),
                    url: "https://example.com/screenshot.png".to_string(),
                    source_type: None,
                    metadata: serde_json::Value::Null,
                },
            ],
            ..test_issue("ENG-10793")
        };
        let summary = super::AttachmentContextSummary {
            downloaded_paths: vec![
                "files/01-validation.md".to_string(),
                "files/02-screenshot.png".to_string(),
                "files/03-implementation.txt".to_string(),
            ],
            failed_downloads: vec!["README (https://example.com/readme) - failed".to_string()],
        };

        let manifest = super::render_issue_attachment_manifest(&issue, &summary, workspace);

        let read_first = manifest
            .find("## Read First")
            .expect("prioritized summary should render");
        let markdown = manifest
            .find("### Markdown / Text Artifacts")
            .expect("markdown section should render");
        let failures = manifest
            .find("### Download Failures")
            .expect("failure section should render");
        let other = manifest
            .find("### Other Downloaded Files")
            .expect("other-files section should render");
        let full_manifest = manifest
            .find("## Downloaded Files")
            .expect("full manifest should remain");

        assert!(read_first < full_manifest);
        assert!(markdown < failures);
        assert!(failures < other);
        assert!(manifest.contains("- `files/01-validation.md`"));
        assert!(manifest.contains("- `files/03-implementation.txt`"));
        assert!(manifest.contains("- README (https://example.com/readme) - failed"));
        assert!(manifest.contains("## Downloaded Files"));
    }

    #[test]
    fn render_agent_prompt_discussion_summary_is_newest_first_and_bounded() {
        let temp = tempdir().expect("temp dir should build");
        let workspace = temp.path();
        fs::create_dir_all(workspace.join(format!(
            "{}/backlog/MET-24/context",
            crate::branding::PROJECT_DIR
        )))
        .expect("discussion dir should build");
        fs::create_dir_all(workspace.join(crate::branding::PROJECT_DIR))
            .expect("metastack dir should build");
        fs::write(
            workspace.join(format!("{}/meta.json", crate::branding::PROJECT_DIR)),
            r#"{
  "sync": {
    "discussion_prompt_char_limit": 2000
  }
}
"#,
        )
        .expect("meta should write");
        fs::write(
            workspace.join(format!("{}/backlog/MET-24/context/ticket-discussion.md", crate::branding::PROJECT_DIR)),
            "# Ticket Discussion\n\n### **Alice** (2026-04-01)\n\nOldest details that should drop.\n\n### **Bob** (2026-04-02)\n\nSecond newest details stay.\n\n### **Carol** (2026-04-03)\n\nThird newest details stay.\n\n### **Dana** (2026-04-04)\n\nNewest discussion tail stays.",
        )
        .expect("discussion should write");

        let issue = test_issue("MET-24");
        let prompt = render_agent_prompt(&issue, workspace, "comment-24", Some(&issue), 1, 20);

        assert!(prompt.contains("Discussion context:"));
        assert!(prompt.contains("Discussion summary:"));
        assert!(prompt.contains("- **Dana** (2026-04-04): Newest discussion tail stays."));
        assert!(prompt.contains("- **Carol** (2026-04-03): Third newest details stay."));
        assert!(prompt.contains("- **Bob** (2026-04-02): Second newest details stay."));
        assert!(!prompt.contains("Oldest details that should drop."));

        let summary = prompt
            .split("Discussion summary:\n\n")
            .nth(1)
            .and_then(|rest| rest.split("\n\nDescription summary:").next())
            .expect("discussion summary block should exist");
        assert_eq!(
            summary
                .lines()
                .filter(|line| line.starts_with("- "))
                .count(),
            3
        );
        assert!(
            summary.chars().count() <= 1_200,
            "summary exceeded 1200 chars"
        );
    }

    #[test]
    fn render_discussion_summary_counts_labels_inside_total_budget() {
        let contents = "# Ticket Discussion\n\n### **Very Long Reviewer Name With Timestamp Metadata** (2026-04-04)\n\nNewest discussion excerpt still needs room after the label.\n\n### **Another Long Reviewer Name With Timestamp Metadata** (2026-04-03)\n\nSecond discussion excerpt should fit only if the full rendered bullet length is budgeted.\n";

        let summary = super::render_discussion_summary(contents, 80);

        assert!(!summary.is_empty());
        assert!(
            summary.chars().count() <= 80,
            "summary exceeded budget: {summary}"
        );
        assert!(summary.starts_with("- "));
    }

    #[test]
    fn extract_ticket_inline_sections_preserves_nested_headings() {
        let description = "# Context\n\nNarrative.\n\n## Validation\n\n### Unit Tests\n\n- `cargo test`\n\n## Acceptance Criteria\n\n### CLI\n\n- [ ] Compact output\n";

        let sections = super::extract_ticket_inline_sections(Some(description));

        assert_eq!(sections.len(), 2);
        assert_eq!(
            sections[0].render(),
            "## Validation\n\n### Unit Tests\n\n- `cargo test`"
        );
        assert_eq!(
            sections[1].render(),
            "## Acceptance Criteria\n\n### CLI\n\n- [ ] Compact output"
        );
    }

    #[test]
    fn render_issue_description_summary_strips_nested_inline_sections() {
        let description = "# Context\n\nNarrative stays.\n\n## Validation\n\n### Unit Tests\n\n- `cargo test`\n\n## Acceptance Criteria\n\n### CLI\n\n- [ ] Compact output\n";

        let summary = super::render_issue_description_summary(Some(description));

        assert_eq!(summary, "# Context\n\nNarrative stays.");
    }

    #[test]
    fn render_continuation_prompt_includes_identifier_and_turn() {
        let issue = test_issue("MET-57");
        let prompt = render_continuation_prompt(&issue, 3, 20);

        assert!(prompt.contains("MET-57"));
        assert!(prompt.contains("continuation turn #3 of 20"));
        assert!(prompt.contains("Resume from the current workspace"));
        assert!(prompt.contains("already present in this session"));
    }

    #[test]
    fn render_continuation_prompt_is_compact() {
        let issue = test_issue("MET-57");
        let prompt = render_continuation_prompt(&issue, 2, 20);

        // Continuation prompt should be much smaller than the full prompt.
        assert!(
            prompt.len() < 600,
            "continuation prompt too large: {} bytes",
            prompt.len()
        );
        // Must not include fields from the full prompt.
        assert!(!prompt.contains("Description:"));
        assert!(!prompt.contains("Workspace:"));
        assert!(!prompt.contains("Labels:"));
    }

    #[test]
    fn full_prompt_is_larger_than_continuation() {
        let temp = tempdir().expect("temp dir should build");
        let workspace = temp.path();
        fs::create_dir_all(workspace.join(".metastack")).expect("metastack dir should build");

        let issue = test_issue("MET-57");
        let full = render_agent_prompt(&issue, workspace, "comment-1", None, 2, 20);
        let cont = render_continuation_prompt(&issue, 2, 20);

        // With a minimal test issue, the full prompt is modest. In production, issue
        // descriptions, backlog context, and discussion excerpts push it to 2-10KB
        // while the continuation prompt stays ~500 bytes.
        assert!(
            full.len() > cont.len(),
            "full prompt ({} bytes) should be larger than continuation prompt ({} bytes)",
            full.len(),
            cont.len(),
        );
    }

    #[derive(Debug, Deserialize)]
    struct TurnOneFixture {
        description: String,
        discussion: Option<String>,
        attachment_manifest: Option<bool>,
        prompt_max: usize,
    }

    #[test]
    fn turn_one_prompt_fixture_byte_budgets_hold_for_required_cases() {
        for fixture_name in [
            "small-happy-path",
            "large-narrative",
            "validation-heavy",
            "attachment-heavy",
            "discussion-heavy",
        ] {
            let fixture = load_turn_one_fixture(fixture_name).expect("fixture should load");
            let temp = tempdir().expect("temp dir should build");
            let workspace = temp.path();
            ensure_dir(&PlanningPaths::new(workspace).codebase_dir)
                .expect("codebase dir should build");
            fs::create_dir_all(workspace.join(format!(
                "{}/backlog/ENG-10793/context",
                crate::branding::PROJECT_DIR
            )))
            .expect("discussion dir should build");
            fs::create_dir_all(workspace.join(crate::branding::PROJECT_DIR))
                .expect("metastack dir should build");
            fs::write(
                workspace.join(format!("{}/meta.json", crate::branding::PROJECT_DIR)),
                r#"{"sync":{"discussion_prompt_char_limit":2000}}"#,
            )
            .expect("meta should write");
            if let Some(discussion) = fixture.discussion.as_deref() {
                fs::write(
                    workspace.join(format!(
                        "{}/backlog/ENG-10793/context/ticket-discussion.md",
                        crate::branding::PROJECT_DIR
                    )),
                    discussion,
                )
                .expect("discussion should write");
            }
            if fixture.attachment_manifest.unwrap_or(false) {
                let manifest_path =
                    PlanningPaths::new(workspace).agent_issue_context_manifest_path("ENG-10793");
                if let Some(parent) = manifest_path.parent() {
                    fs::create_dir_all(parent).expect("attachment context dir should build");
                }
                fs::write(
                    &manifest_path,
                    "# Attachment Context\n\n## Read First\n\n- `files/01-validation.md`\n",
                )
                .expect("attachment manifest should write");
            }

            let issue = IssueSummary {
                identifier: "ENG-10793".to_string(),
                description: Some(fixture.description.clone()),
                ..test_issue("ENG-10793")
            };
            let prompt =
                render_agent_prompt(&issue, workspace, "comment-10793", Some(&issue), 1, 20);

            assert!(
                prompt.len() <= fixture.prompt_max,
                "{fixture_name} prompt exceeded budget: {} > {}",
                prompt.len(),
                fixture.prompt_max
            );
            assert!(prompt.contains("Description summary:"), "{fixture_name}");
            if fixture.attachment_manifest.unwrap_or(false) {
                assert!(prompt.contains("Attachment context:"), "{fixture_name}");
                assert!(prompt.contains("Attachment manifest:"), "{fixture_name}");
            }
        }
    }

    fn load_turn_one_fixture(name: &str) -> Result<TurnOneFixture> {
        let path = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("tests/fixtures/listen/turn-one")
            .join(format!("{name}.json"));
        let contents = fs::read_to_string(&path)
            .map_err(|error| anyhow!("failed to read fixture `{}`: {error}", path.display()))?;
        serde_json::from_str(&contents)
            .map_err(|error| anyhow!("failed to parse fixture `{}`: {error}", path.display()))
    }

    fn test_issue(identifier: &str) -> IssueSummary {
        IssueSummary {
            id: format!("issue-{identifier}"),
            identifier: identifier.to_string(),
            title: "Attachment bootstrap".to_string(),
            description: Some("Use uploaded docs as implementation context".to_string()),
            url: format!("https://linear.app/issues/{identifier}"),
            priority: Some(2),
            estimate: None,
            updated_at: "2026-03-14T16:00:00Z".to_string(),
            team: TeamRef {
                id: "team-1".to_string(),
                key: "MET".to_string(),
                name: "Metastack".to_string(),
            },
            project: None,
            assignee: None,
            labels: Vec::new(),
            comments: Vec::new(),
            state: None,
            attachments: Vec::new(),
            parent: None,
            children: Vec::new(),
        }
    }

    fn issue_with_assignee(identifier: &str, assignee: Option<(&str, &str)>) -> IssueSummary {
        let mut issue = test_issue(identifier);
        issue.assignee = assignee.map(|(id, name)| UserRef {
            id: id.to_string(),
            name: name.to_string(),
            email: None,
        });
        issue
    }

    fn test_daemon(
        scope: ListenAssignmentScope,
        issue: IssueSummary,
    ) -> Result<(tempfile::TempDir, AgentDaemon<ReassignmentClient>)> {
        let temp = tempdir()?;
        let repo = temp.path();
        fs::create_dir_all(repo.join(crate::branding::PROJECT_DIR))?;
        let store = ListenProjectStore::resolve(repo, None)?;
        let service = LinearService::new(ReassignmentClient { issue }, Some("MET".to_string()));
        let daemon = AgentDaemon {
            root: repo.to_path_buf(),
            store,
            filters: IssueListFilters {
                state: Some(TODO_STATE.to_string()),
                limit: 25,
                ..IssueListFilters::default()
            },
            max_pickups: 1,
            linear_config: LinearConfig {
                api_key: "token".to_string(),
                api_url: "https://linear.example/graphql".to_string(),
                default_team: Some("MET".to_string()),
            },
            app_config: AppConfig::default(),
            planning_meta: PlanningMeta::default(),
            worker_agent: None,
            worker_model: None,
            worker_reasoning: None,
            worker_context_budget_tokens: crate::config::DEFAULT_LISTEN_CONTEXT_BUDGET_TOKENS,
            listen_settings: PlanningListenSettings {
                required_labels: None,
                assignment_scope: Some(scope),
                refresh_policy: Some(ListenRefreshPolicy::ReuseAndRefresh),
                instructions_path: None,
                poll_interval_seconds: None,
                context_budget_tokens: None,
                dashboard_active_issues: None,
                dashboard_preview: None,
            },
            viewer: Some(UserRef {
                id: "viewer-1".to_string(),
                name: "Kames".to_string(),
                email: Some("sudo@example.com".to_string()),
            }),
            service,
        };
        Ok((temp, daemon))
    }

    #[test]
    fn viewer_only_scope_skips_unassigned_issues() -> Result<()> {
        let (_temp, daemon) = test_daemon(
            ListenAssignmentScope::ViewerOnly,
            issue_with_assignee("MET-55", None),
        )?;

        assert_eq!(
            daemon
                .assignee_scope_skip_reason(&issue_with_assignee("MET-55", None))
                .as_deref(),
            Some("unassigned; only `Kames` is in scope")
        );
        assert_eq!(
            daemon
                .session_drop_reason(&issue_with_assignee("MET-55", None))
                .as_deref(),
            Some("session ended: ticket became unassigned")
        );

        Ok(())
    }

    #[test]
    fn viewer_only_scope_skips_foreign_assignees_but_allows_viewer() -> Result<()> {
        let (_temp, daemon) = test_daemon(
            ListenAssignmentScope::ViewerOnly,
            issue_with_assignee("MET-56", Some(("viewer-2", "Someone Else"))),
        )?;

        assert_eq!(
            daemon
                .assignee_scope_skip_reason(&issue_with_assignee(
                    "MET-56",
                    Some(("viewer-2", "Someone Else"))
                ))
                .as_deref(),
            Some("assigned to `Someone Else` instead of `Kames`")
        );
        assert_eq!(
            daemon.assignee_scope_skip_reason(&issue_with_assignee(
                "MET-57",
                Some(("viewer-1", "Kames"))
            )),
            None
        );

        Ok(())
    }

    #[test]
    fn viewer_or_unassigned_scope_allows_unassigned_but_not_foreign_assignees() -> Result<()> {
        let (_temp, daemon) = test_daemon(
            ListenAssignmentScope::ViewerOrUnassigned,
            issue_with_assignee("MET-58", None),
        )?;

        assert_eq!(
            daemon.assignee_scope_skip_reason(&issue_with_assignee("MET-58", None)),
            None
        );
        assert_eq!(
            daemon
                .assignee_scope_skip_reason(&issue_with_assignee(
                    "MET-59",
                    Some(("viewer-2", "Someone Else"))
                ))
                .as_deref(),
            Some("assigned to `Someone Else` instead of `Kames`")
        );

        Ok(())
    }

    #[test]
    fn any_scope_does_not_skip_foreign_or_unassigned_issues() -> Result<()> {
        let (_temp, daemon) = test_daemon(
            ListenAssignmentScope::Any,
            issue_with_assignee("MET-60", None),
        )?;

        assert_eq!(
            daemon.assignee_scope_skip_reason(&issue_with_assignee("MET-60", None)),
            None
        );
        assert_eq!(
            daemon.assignee_scope_skip_reason(&issue_with_assignee(
                "MET-61",
                Some(("viewer-2", "Someone Else"))
            )),
            None
        );

        Ok(())
    }

    #[test]
    fn render_watch_scope_reports_effective_assignee_scope() {
        let viewer = UserRef {
            id: "viewer-1".to_string(),
            name: "Kames".to_string(),
            email: Some("sudo@example.com".to_string()),
        };

        assert_eq!(
            crate::listen::render_watch_scope(ListenAssignmentScope::Any, Some(&viewer)),
            "all assignees"
        );
        assert_eq!(
            crate::listen::render_watch_scope(ListenAssignmentScope::ViewerOnly, Some(&viewer)),
            "only Kames"
        );
        assert_eq!(
            crate::listen::render_watch_scope(
                ListenAssignmentScope::ViewerOrUnassigned,
                Some(&viewer)
            ),
            "Kames + unassigned"
        );
    }

    #[test]
    fn resolve_listen_context_budget_tokens_prefers_cli_repo_install_then_default() {
        let default_args = crate::cli::ListenRunArgs {
            api_key: None,
            api_url: None,
            profile: None,
            team: None,
            project: None,
            root: ".".into(),
            limit: 25,
            max_pickups: 1,
            poll_interval: None,
            context_budget_tokens: None,
            all_assignees: false,
            check: false,
            once: false,
            json: false,
            render_once: false,
            events: Vec::new(),
            demo: false,
            width: 120,
            height: 40,
            agent: None,
            model: None,
            reasoning: None,
            hide_active_issues: false,
            hide_preview: false,
        };
        let app_config = AppConfig::default();
        let planning_meta = PlanningMeta::default();

        assert_eq!(
            super::resolve_listen_context_budget_tokens(&default_args, &planning_meta, &app_config),
            crate::config::DEFAULT_LISTEN_CONTEXT_BUDGET_TOKENS
        );

        let install_config = AppConfig {
            defaults: crate::config::InstallDefaults {
                listen: crate::config::InstallListenSettings {
                    context_budget_tokens: Some(222_000),
                    ..crate::config::InstallListenSettings::default()
                },
                ..crate::config::InstallDefaults::default()
            },
            ..AppConfig::default()
        };
        assert_eq!(
            super::resolve_listen_context_budget_tokens(
                &default_args,
                &planning_meta,
                &install_config
            ),
            222_000
        );

        let repo_meta = PlanningMeta {
            listen: PlanningListenSettings {
                context_budget_tokens: Some(111_000),
                ..PlanningListenSettings::default()
            },
            ..PlanningMeta::default()
        };
        assert_eq!(
            super::resolve_listen_context_budget_tokens(&default_args, &repo_meta, &install_config),
            111_000
        );

        let cli_args = crate::cli::ListenRunArgs {
            context_budget_tokens: Some(99_000),
            ..default_args
        };
        assert_eq!(
            super::resolve_listen_context_budget_tokens(&cli_args, &repo_meta, &install_config),
            99_000
        );
    }

    #[test]
    fn build_listen_worker_cli_args_includes_context_budget_tokens() {
        let args = super::build_listen_worker_cli_args(
            Path::new("/tmp/source"),
            Some("project-1"),
            Path::new("/tmp/workspace"),
            "ENG-10782",
            "comment-1",
            Some("ENG-10776"),
            7,
            155_000,
            Some("codex"),
            Some("gpt-5.4"),
            Some("high"),
        );
        let rendered = args
            .iter()
            .map(|value| value.to_string_lossy().into_owned())
            .collect::<Vec<_>>();

        assert!(
            rendered
                .windows(2)
                .any(|pair| pair == ["--context-budget-tokens", "155000"])
        );
        assert!(
            rendered
                .windows(2)
                .any(|pair| pair == ["--project", "project-1"])
        );
        assert!(
            rendered
                .windows(2)
                .any(|pair| pair == ["--backlog-issue", "ENG-10776"])
        );
    }

    #[test]
    fn degraded_cycle_watch_scope_does_not_reuse_stale_startup_viewer() -> Result<()> {
        let (_temp, daemon) = test_daemon(
            ListenAssignmentScope::ViewerOrUnassigned,
            issue_with_assignee("MET-62", None),
        )?;

        let cycle = daemon.build_degraded_cycle(
            &anyhow!("Linear request failed with status 429 Too Many Requests"),
            None,
        )?;

        assert_eq!(cycle.watch_scope, "viewer + unassigned");
        assert_ne!(cycle.watch_scope, "Kames + unassigned");

        Ok(())
    }

    #[tokio::test]
    async fn reconcile_sessions_marks_reassigned_issue_completed_after_turn_ends() -> Result<()> {
        let temp = tempdir()?;
        let repo = temp.path();
        fs::create_dir_all(repo.join(crate::branding::PROJECT_DIR))?;
        run_git(repo, &["init"])?;
        run_git(repo, &["config", "user.email", "listen@example.com"])?;
        run_git(repo, &["config", "user.name", "Listen Tests"])?;
        fs::write(repo.join("README.md"), "# Demo\n")?;
        run_git(repo, &["add", "README.md"])?;
        run_git(repo, &["commit", "-m", "init"])?;

        let workspace = repo.join("workspace");
        fs::create_dir_all(&workspace)?;
        let store = ListenProjectStore::resolve(repo, None)?;
        let issue = reassigned_issue();
        let client = ReassignmentClient {
            issue: issue.clone(),
        };
        let service = LinearService::new(client, Some("MET".to_string()));
        let daemon = AgentDaemon {
            root: repo.to_path_buf(),
            store,
            filters: IssueListFilters {
                state: Some(TODO_STATE.to_string()),
                limit: 25,
                ..IssueListFilters::default()
            },
            max_pickups: 1,
            linear_config: LinearConfig {
                api_key: "token".to_string(),
                api_url: "https://linear.example/graphql".to_string(),
                default_team: Some("MET".to_string()),
            },
            app_config: AppConfig::default(),
            planning_meta: PlanningMeta::default(),
            worker_agent: None,
            worker_model: None,
            worker_reasoning: None,
            worker_context_budget_tokens: crate::config::DEFAULT_LISTEN_CONTEXT_BUDGET_TOKENS,
            listen_settings: PlanningListenSettings {
                required_labels: None,
                assignment_scope: Some(ListenAssignmentScope::ViewerOrUnassigned),
                refresh_policy: Some(ListenRefreshPolicy::ReuseAndRefresh),
                instructions_path: None,
                poll_interval_seconds: None,
                context_budget_tokens: None,
                dashboard_active_issues: None,
                dashboard_preview: None,
            },
            viewer: None,
            service,
        };
        let cycle_viewer = UserRef {
            id: "viewer-1".to_string(),
            name: "Kames".to_string(),
            email: Some("sudo@example.com".to_string()),
        };
        let workspace = repo.join("workspace");
        let mut state = ListenState::from_sessions(vec![super::AgentSession {
            issue_id: Some(issue.id.clone()),
            issue_identifier: issue.identifier.clone(),
            issue_title: issue.title.clone(),
            project_name: issue.project.as_ref().map(|project| project.name.clone()),
            team_key: issue.team.key.clone(),
            issue_url: issue.url.clone(),
            phase: SessionPhase::Running,
            lifecycle: None,
            summary: "turn 1/20".to_string(),
            blocked: None,
            brief_path: None,
            backlog_issue_identifier: None,
            backlog_issue_title: None,
            backlog_path: None,
            workspace_path: Some(workspace.display().to_string()),
            branch: Some("met-88-reassigned".to_string()),
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: Some("comment-88".to_string()),
            started_at_epoch_seconds: 1_773_575_000,
            updated_at_epoch_seconds: 1_773_575_000,
            pid: None,
            session_id: Some(issue.id.clone()),
            latest_resume_handle: None,
            context_budget_tokens: None,
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: None,
            turns: Some(1),
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: None,
            origin: SessionOrigin::Listen,
        }]);
        let mut notes = Vec::new();

        daemon
            .reconcile_sessions(&mut state, &mut notes, Some(&cycle_viewer))
            .await?;

        assert_eq!(state.sessions.len(), 1);
        assert_eq!(state.sessions[0].phase, SessionPhase::Running);
        assert_eq!(
            state.sessions[0]
                .lifecycle
                .as_ref()
                .map(|lifecycle| lifecycle.outcome),
            Some(SessionLifecycleOutcome::Completed)
        );
        assert_eq!(
            state.sessions[0]
                .lifecycle
                .as_ref()
                .and_then(|lifecycle| lifecycle.exit_condition),
            Some(SessionExitCondition::IssueMoved)
        );
        assert_eq!(
            state.sessions[0].summary,
            "session ended: ticket reassigned"
        );
        assert!(
            notes.iter().any(
                |note| note.contains("Ended MET-88 session: session ended: ticket reassigned.")
            ),
            "expected reassignment note, got {notes:?}"
        );

        Ok(())
    }

    #[tokio::test]
    async fn reconcile_sessions_restores_todo_issue_to_in_progress_when_session_exists()
    -> Result<()> {
        let temp = tempdir()?;
        let repo = temp.path();
        fs::create_dir_all(repo.join(crate::branding::PROJECT_DIR))?;
        run_git(repo, &["init"])?;
        run_git(repo, &["config", "user.email", "listen@example.com"])?;
        run_git(repo, &["config", "user.name", "Listen Tests"])?;
        fs::write(repo.join("README.md"), "# Demo\n")?;
        run_git(repo, &["add", "README.md"])?;
        run_git(repo, &["commit", "-m", "init"])?;

        let store = ListenProjectStore::resolve(repo, None)?;
        let issue = todo_issue();
        let edits = std::sync::Arc::new(std::sync::Mutex::new(Vec::<String>::new()));
        let client = TodoRecoveryClient {
            issue: issue.clone(),
            edits: edits.clone(),
        };
        let service = LinearService::new(client, Some("MET".to_string()));
        let daemon = AgentDaemon {
            root: repo.to_path_buf(),
            store,
            filters: IssueListFilters {
                state: Some(TODO_STATE.to_string()),
                limit: 25,
                ..IssueListFilters::default()
            },
            max_pickups: 1,
            linear_config: LinearConfig {
                api_key: "token".to_string(),
                api_url: "https://linear.example/graphql".to_string(),
                default_team: Some("MET".to_string()),
            },
            app_config: AppConfig::default(),
            planning_meta: PlanningMeta::default(),
            worker_agent: None,
            worker_model: None,
            worker_reasoning: None,
            worker_context_budget_tokens: crate::config::DEFAULT_LISTEN_CONTEXT_BUDGET_TOKENS,
            listen_settings: PlanningListenSettings {
                required_labels: None,
                assignment_scope: Some(ListenAssignmentScope::ViewerOrUnassigned),
                refresh_policy: Some(ListenRefreshPolicy::ReuseAndRefresh),
                instructions_path: None,
                poll_interval_seconds: None,
                context_budget_tokens: None,
                dashboard_active_issues: None,
                dashboard_preview: None,
            },
            viewer: None,
            service,
        };
        let cycle_viewer = UserRef {
            id: "viewer-1".to_string(),
            name: "Kames".to_string(),
            email: Some("sudo@example.com".to_string()),
        };
        let workspace = repo.join("workspace");
        let mut state = ListenState::from_sessions(vec![super::AgentSession {
            issue_id: Some(issue.id.clone()),
            issue_identifier: issue.identifier.clone(),
            issue_title: issue.title.clone(),
            project_name: issue.project.as_ref().map(|project| project.name.clone()),
            team_key: issue.team.key.clone(),
            issue_url: issue.url.clone(),
            phase: SessionPhase::Blocked,
            lifecycle: None,
            summary: "Blocked | waiting for follow-up".to_string(),
            blocked: None,
            brief_path: None,
            backlog_issue_identifier: None,
            backlog_issue_title: None,
            backlog_path: None,
            workspace_path: Some(workspace.display().to_string()),
            branch: Some("met-89-recovery".to_string()),
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: Some("comment-89".to_string()),
            started_at_epoch_seconds: 1_773_575_000,
            updated_at_epoch_seconds: 1_773_575_000,
            pid: None,
            session_id: Some(issue.id.clone()),
            latest_resume_handle: None,
            context_budget_tokens: None,
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: None,
            turns: Some(1),
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: None,
            origin: SessionOrigin::Listen,
        }]);
        let mut notes = Vec::new();

        daemon
            .reconcile_sessions(&mut state, &mut notes, Some(&cycle_viewer))
            .await?;

        let edits = edits.lock().expect("edits lock should succeed");
        assert_eq!(edits.as_slice(), &["state-2".to_string()]);
        assert_eq!(state.sessions.len(), 1);
        assert_eq!(state.sessions[0].phase, SessionPhase::Blocked);
        assert!(
            notes
                .iter()
                .any(|note| note.contains("restored it to `In Progress`")),
            "expected Todo recovery note, got {notes:?}"
        );

        Ok(())
    }

    #[tokio::test]
    async fn reconcile_sessions_blocks_paused_session_with_dead_worker_pid() -> Result<()> {
        let temp = tempdir()?;
        let repo = temp.path();
        fs::create_dir_all(repo.join(crate::branding::PROJECT_DIR))?;
        let store = ListenProjectStore::resolve(repo, None)?;
        let issue = in_progress_issue();
        let client = ReassignmentClient {
            issue: issue.clone(),
        };
        let service = LinearService::new(client, Some("MET".to_string()));
        let daemon = AgentDaemon {
            root: repo.to_path_buf(),
            store,
            filters: IssueListFilters {
                state: Some(TODO_STATE.to_string()),
                limit: 25,
                ..IssueListFilters::default()
            },
            max_pickups: 1,
            linear_config: LinearConfig {
                api_key: "token".to_string(),
                api_url: "https://linear.example/graphql".to_string(),
                default_team: Some("MET".to_string()),
            },
            app_config: AppConfig::default(),
            planning_meta: PlanningMeta::default(),
            worker_agent: None,
            worker_model: None,
            worker_reasoning: None,
            worker_context_budget_tokens: crate::config::DEFAULT_LISTEN_CONTEXT_BUDGET_TOKENS,
            listen_settings: PlanningListenSettings {
                required_labels: None,
                assignment_scope: Some(ListenAssignmentScope::Any),
                refresh_policy: Some(ListenRefreshPolicy::ReuseAndRefresh),
                instructions_path: None,
                poll_interval_seconds: None,
                context_budget_tokens: None,
                dashboard_active_issues: None,
                dashboard_preview: None,
            },
            viewer: None,
            service,
        };
        let workspace = repo.join("workspace");
        fs::create_dir_all(&workspace)?;
        let dead_pid = 999_999;
        let mut state = ListenState::from_sessions(vec![super::AgentSession {
            issue_id: Some(issue.id.clone()),
            issue_identifier: issue.identifier.clone(),
            issue_title: issue.title.clone(),
            project_name: issue.project.as_ref().map(|project| project.name.clone()),
            team_key: issue.team.key.clone(),
            issue_url: issue.url.clone(),
            phase: SessionPhase::Paused,
            lifecycle: None,
            summary: "Paused by operator".to_string(),
            blocked: None,
            brief_path: None,
            backlog_issue_identifier: None,
            backlog_issue_title: None,
            backlog_path: None,
            workspace_path: Some(workspace.display().to_string()),
            branch: Some("met-90-paused".to_string()),
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: Some("comment-90".to_string()),
            started_at_epoch_seconds: 1_773_575_000,
            updated_at_epoch_seconds: 1_773_575_100,
            pid: Some(dead_pid),
            session_id: Some(issue.id.clone()),
            latest_resume_handle: None,
            context_budget_tokens: None,
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: None,
            turns: Some(1),
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: Some("logs/MET-90.log".to_string()),
            origin: SessionOrigin::Listen,
        }]);
        let mut notes = Vec::new();

        daemon
            .reconcile_sessions(&mut state, &mut notes, None)
            .await?;

        assert_eq!(state.sessions.len(), 1);
        let session = &state.sessions[0];
        assert_eq!(session.phase, SessionPhase::Paused);
        assert_eq!(
            session
                .lifecycle
                .as_ref()
                .map(|lifecycle| lifecycle.outcome),
            Some(SessionLifecycleOutcome::Blocked)
        );
        assert_eq!(
            session
                .lifecycle
                .as_ref()
                .and_then(|lifecycle| lifecycle.exit_condition),
            Some(SessionExitCondition::WorkerDied)
        );
        assert_eq!(session.pid, Some(dead_pid));
        assert_eq!(
            session
                .blocked
                .as_ref()
                .map(|blocked| blocked.reason.as_str()),
            Some("paused worker died")
        );
        assert_eq!(
            session
                .latest_stale_worker_failure
                .as_ref()
                .map(|failure| failure.classification.reason.as_str()),
            Some("paused worker died")
        );
        assert_eq!(session.stale_worker_recovery_attempt_count, 0);
        assert!(
            notes.iter().any(|note| note.contains("parked as blocked")),
            "expected stale-worker reconciliation note, got {notes:?}"
        );

        Ok(())
    }

    #[tokio::test]
    async fn run_cycle_resilient_returns_non_linear_errors_without_entering_degraded_mode()
    -> Result<()> {
        let temp = tempdir()?;
        let repo = temp.path();
        fs::create_dir_all(repo.join(crate::branding::PROJECT_DIR))?;
        let store = ListenProjectStore::resolve(repo, None)?;
        let issue = in_progress_issue();
        let client = SessionOnlyClient {
            issue: issue.clone(),
        };
        let service = LinearService::new(client, Some("MET".to_string()));
        let daemon = AgentDaemon {
            root: repo.to_path_buf(),
            store,
            filters: IssueListFilters {
                state: Some(TODO_STATE.to_string()),
                limit: 25,
                ..IssueListFilters::default()
            },
            max_pickups: 1,
            linear_config: LinearConfig {
                api_key: "token".to_string(),
                api_url: "https://linear.example/graphql".to_string(),
                default_team: Some("MET".to_string()),
            },
            app_config: AppConfig::default(),
            planning_meta: PlanningMeta::default(),
            worker_agent: None,
            worker_model: None,
            worker_reasoning: None,
            worker_context_budget_tokens: crate::config::DEFAULT_LISTEN_CONTEXT_BUDGET_TOKENS,
            listen_settings: PlanningListenSettings {
                required_labels: None,
                assignment_scope: Some(ListenAssignmentScope::Any),
                refresh_policy: Some(ListenRefreshPolicy::ReuseAndRefresh),
                instructions_path: None,
                poll_interval_seconds: None,
                context_budget_tokens: None,
                dashboard_active_issues: None,
                dashboard_preview: None,
            },
            viewer: None,
            service,
        };
        let state = ListenState::from_sessions(vec![super::AgentSession {
            issue_id: Some(issue.id.clone()),
            issue_identifier: issue.identifier.clone(),
            issue_title: issue.title.clone(),
            project_name: issue.project.as_ref().map(|project| project.name.clone()),
            team_key: issue.team.key.clone(),
            issue_url: issue.url.clone(),
            phase: SessionPhase::Completed,
            lifecycle: None,
            summary: "Complete".to_string(),
            blocked: None,
            brief_path: None,
            backlog_issue_identifier: None,
            backlog_issue_title: None,
            backlog_path: None,
            workspace_path: None,
            branch: None,
            pull_request: PullRequestSummary::default(),
            workpad_comment_id: None,
            started_at_epoch_seconds: 1_773_575_000,
            updated_at_epoch_seconds: 1_773_575_000,
            pid: None,
            session_id: Some(issue.id.clone()),
            latest_resume_handle: None,
            context_budget_tokens: None,
            pending_linear_sync: None,
            stale_worker_recovery_attempt_count: 0,
            latest_stale_worker_failure: None,
            last_timeout: None,
            turns: Some(1),
            tokens: TokenUsage::default(),
            turn_history: Vec::new(),
            canonical: CanonicalSessionData::default(),
            log_path: None,
            origin: SessionOrigin::Listen,
        }]);
        daemon.store.save_state(&state)?;
        let state_path = daemon.store.paths().state_path.clone();
        fs::remove_file(&state_path)?;
        fs::create_dir(&state_path)?;

        let error = daemon
            .run_cycle_resilient()
            .await
            .expect_err("non-Linear failures should propagate");

        let rendered = format!("{error:#}");
        assert!(
            rendered.contains("failed to read")
                || rendered.contains("Is a directory")
                || rendered.contains("is a directory"),
            "expected state read failure, got {rendered}"
        );
        assert!(!super::should_preserve_last_known_linear_snapshot(&error));

        Ok(())
    }

    fn reassigned_issue() -> IssueSummary {
        IssueSummary {
            id: "issue-88".to_string(),
            identifier: "MET-88".to_string(),
            title: "Reassigned listener issue".to_string(),
            description: Some("Reassigned during an active turn".to_string()),
            url: "https://linear.app/issues/88".to_string(),
            priority: Some(2),
            estimate: None,
            updated_at: "2026-03-14T16:00:00Z".to_string(),
            team: crate::linear::TeamRef {
                id: "team-1".to_string(),
                key: "MET".to_string(),
                name: "Metastack".to_string(),
            },
            project: Some(crate::linear::ProjectRef {
                id: "project-1".to_string(),
                name: "MetaStack CLI".to_string(),
            }),
            assignee: Some(UserRef {
                id: "viewer-2".to_string(),
                name: "Someone Else".to_string(),
                email: Some("else@example.com".to_string()),
            }),
            labels: Vec::new(),
            comments: Vec::new(),
            state: Some(crate::linear::WorkflowState {
                id: "state-2".to_string(),
                name: "In Progress".to_string(),
                kind: Some("started".to_string()),
            }),
            attachments: Vec::new(),
            parent: None,
            children: Vec::new(),
        }
    }

    fn todo_issue() -> IssueSummary {
        IssueSummary {
            id: "issue-89".to_string(),
            identifier: "MET-89".to_string(),
            title: "Returned to todo".to_string(),
            description: Some("Unexpectedly moved back to Todo".to_string()),
            url: "https://linear.app/issues/89".to_string(),
            priority: Some(2),
            estimate: None,
            updated_at: "2026-03-14T16:00:00Z".to_string(),
            team: crate::linear::TeamRef {
                id: "team-1".to_string(),
                key: "MET".to_string(),
                name: "Metastack".to_string(),
            },
            project: Some(crate::linear::ProjectRef {
                id: "project-1".to_string(),
                name: "MetaStack CLI".to_string(),
            }),
            assignee: Some(UserRef {
                id: "viewer-1".to_string(),
                name: "Kames".to_string(),
                email: Some("sudo@example.com".to_string()),
            }),
            labels: Vec::new(),
            comments: Vec::new(),
            state: Some(crate::linear::WorkflowState {
                id: "state-1".to_string(),
                name: TODO_STATE.to_string(),
                kind: Some("unstarted".to_string()),
            }),
            attachments: Vec::new(),
            parent: None,
            children: Vec::new(),
        }
    }

    fn in_progress_issue() -> IssueSummary {
        IssueSummary {
            state: Some(crate::linear::WorkflowState {
                id: "state-2".to_string(),
                name: IN_PROGRESS_STATE.to_string(),
                kind: Some("started".to_string()),
            }),
            ..test_issue("MET-90")
        }
    }

    #[derive(Clone)]
    struct ReassignmentClient {
        issue: IssueSummary,
    }

    #[async_trait]
    impl LinearClient for ReassignmentClient {
        async fn list_projects(&self, _limit: usize) -> Result<Vec<ProjectSummary>> {
            unreachable!("list_projects is not used in this test")
        }

        async fn list_users(&self, _limit: usize) -> Result<Vec<UserRef>> {
            unreachable!("list_users is not used in this test")
        }

        async fn list_issues(&self, _limit: usize) -> Result<Vec<IssueSummary>> {
            Ok(vec![self.issue.clone()])
        }

        async fn list_filtered_issues(
            &self,
            _filters: &IssueListFilters,
        ) -> Result<Vec<IssueSummary>> {
            Ok(vec![self.issue.clone()])
        }

        async fn list_issue_labels(&self, _team: Option<&str>) -> Result<Vec<LabelRef>> {
            unreachable!("list_issue_labels is not used in this test")
        }

        async fn get_issue(&self, _issue_id: &str) -> Result<IssueSummary> {
            Ok(self.issue.clone())
        }

        async fn list_teams(&self) -> Result<Vec<TeamSummary>> {
            unreachable!("list_teams is not used in this test")
        }

        async fn viewer(&self) -> Result<UserRef> {
            unreachable!("viewer is not used in this test")
        }

        async fn create_issue(&self, _request: IssueCreateRequest) -> Result<IssueSummary> {
            unreachable!("create_issue is not used in this test")
        }

        async fn create_issue_label(&self, _request: IssueLabelCreateRequest) -> Result<LabelRef> {
            unreachable!("create_issue_label is not used in this test")
        }

        async fn update_issue(
            &self,
            _issue_id: &str,
            _request: IssueUpdateRequest,
        ) -> Result<IssueSummary> {
            unreachable!("update_issue is not used in this test")
        }

        async fn create_comment(&self, _issue_id: &str, _body: String) -> Result<IssueComment> {
            unreachable!("create_comment is not used in this test")
        }

        async fn create_issue_relation(
            &self,
            _request: crate::linear::IssueRelationCreateRequest,
        ) -> Result<()> {
            unreachable!("create_issue_relation is not used in this test")
        }

        async fn update_comment(&self, _comment_id: &str, _body: String) -> Result<IssueComment> {
            unreachable!("update_comment is not used in this test")
        }

        async fn upload_file(
            &self,
            _filename: &str,
            _content_type: &str,
            _contents: Vec<u8>,
        ) -> Result<String> {
            unreachable!("upload_file is not used in this test")
        }

        async fn create_attachment(
            &self,
            _request: AttachmentCreateRequest,
        ) -> Result<AttachmentSummary> {
            unreachable!("create_attachment is not used in this test")
        }

        async fn delete_attachment(&self, _attachment_id: &str) -> Result<()> {
            unreachable!("delete_attachment is not used in this test")
        }

        async fn download_file(&self, _url: &str) -> Result<Vec<u8>> {
            unreachable!("download_file is not used in this test")
        }
    }

    #[derive(Clone)]
    struct SessionOnlyClient {
        issue: IssueSummary,
    }

    #[async_trait]
    impl LinearClient for SessionOnlyClient {
        async fn list_projects(&self, _limit: usize) -> Result<Vec<ProjectSummary>> {
            unreachable!("list_projects is not used in this test")
        }

        async fn list_users(&self, _limit: usize) -> Result<Vec<UserRef>> {
            unreachable!("list_users is not used in this test")
        }

        async fn list_issues(&self, _limit: usize) -> Result<Vec<IssueSummary>> {
            Ok(Vec::new())
        }

        async fn list_filtered_issues(
            &self,
            _filters: &IssueListFilters,
        ) -> Result<Vec<IssueSummary>> {
            Ok(Vec::new())
        }

        async fn list_issue_labels(&self, _team: Option<&str>) -> Result<Vec<LabelRef>> {
            unreachable!("list_issue_labels is not used in this test")
        }

        async fn get_issue(&self, _issue_id: &str) -> Result<IssueSummary> {
            Ok(self.issue.clone())
        }

        async fn list_teams(&self) -> Result<Vec<TeamSummary>> {
            unreachable!("list_teams is not used in this test")
        }

        async fn viewer(&self) -> Result<UserRef> {
            unreachable!("viewer is not used in this test")
        }

        async fn create_issue(&self, _request: IssueCreateRequest) -> Result<IssueSummary> {
            unreachable!("create_issue is not used in this test")
        }

        async fn create_issue_label(&self, _request: IssueLabelCreateRequest) -> Result<LabelRef> {
            unreachable!("create_issue_label is not used in this test")
        }

        async fn update_issue(
            &self,
            _issue_id: &str,
            _request: IssueUpdateRequest,
        ) -> Result<IssueSummary> {
            unreachable!("update_issue is not used in this test")
        }

        async fn create_comment(&self, _issue_id: &str, _body: String) -> Result<IssueComment> {
            unreachable!("create_comment is not used in this test")
        }

        async fn update_comment(&self, _comment_id: &str, _body: String) -> Result<IssueComment> {
            unreachable!("update_comment is not used in this test")
        }

        async fn upload_file(
            &self,
            _filename: &str,
            _content_type: &str,
            _contents: Vec<u8>,
        ) -> Result<String> {
            unreachable!("upload_file is not used in this test")
        }

        async fn create_attachment(
            &self,
            _request: AttachmentCreateRequest,
        ) -> Result<AttachmentSummary> {
            unreachable!("create_attachment is not used in this test")
        }

        async fn create_issue_relation(
            &self,
            _request: crate::linear::IssueRelationCreateRequest,
        ) -> Result<()> {
            unreachable!("create_issue_relation is not used in this test")
        }

        async fn delete_attachment(&self, _attachment_id: &str) -> Result<()> {
            unreachable!("delete_attachment is not used in this test")
        }

        async fn download_file(&self, _url: &str) -> Result<Vec<u8>> {
            unreachable!("download_file is not used in this test")
        }
    }

    #[derive(Clone)]
    struct TodoRecoveryClient {
        issue: IssueSummary,
        edits: std::sync::Arc<std::sync::Mutex<Vec<String>>>,
    }

    #[async_trait]
    impl LinearClient for TodoRecoveryClient {
        async fn list_projects(&self, _limit: usize) -> Result<Vec<ProjectSummary>> {
            unreachable!("list_projects is not used in this test")
        }

        async fn list_users(&self, _limit: usize) -> Result<Vec<UserRef>> {
            unreachable!("list_users is not used in this test")
        }

        async fn list_issues(&self, _limit: usize) -> Result<Vec<IssueSummary>> {
            Ok(vec![self.issue.clone()])
        }

        async fn list_filtered_issues(
            &self,
            _filters: &IssueListFilters,
        ) -> Result<Vec<IssueSummary>> {
            Ok(vec![self.issue.clone()])
        }

        async fn list_issue_labels(&self, _team: Option<&str>) -> Result<Vec<LabelRef>> {
            unreachable!("list_issue_labels is not used in this test")
        }

        async fn get_issue(&self, _issue_id: &str) -> Result<IssueSummary> {
            Ok(self.issue.clone())
        }

        async fn list_teams(&self) -> Result<Vec<TeamSummary>> {
            Ok(vec![TeamSummary {
                id: "team-1".to_string(),
                key: "MET".to_string(),
                name: "Metastack".to_string(),
                states: vec![
                    WorkflowState {
                        id: "state-1".to_string(),
                        name: TODO_STATE.to_string(),
                        kind: Some("unstarted".to_string()),
                    },
                    WorkflowState {
                        id: "state-2".to_string(),
                        name: IN_PROGRESS_STATE.to_string(),
                        kind: Some("started".to_string()),
                    },
                ],
            }])
        }

        async fn viewer(&self) -> Result<UserRef> {
            unreachable!("viewer is not used in this test")
        }

        async fn create_issue(&self, _request: IssueCreateRequest) -> Result<IssueSummary> {
            unreachable!("create_issue is not used in this test")
        }

        async fn create_issue_label(&self, _request: IssueLabelCreateRequest) -> Result<LabelRef> {
            unreachable!("create_issue_label is not used in this test")
        }

        async fn update_issue(
            &self,
            _issue_id: &str,
            request: IssueUpdateRequest,
        ) -> Result<IssueSummary> {
            self.edits
                .lock()
                .expect("edits lock should succeed")
                .push(request.state_id.unwrap_or_default());
            Ok(IssueSummary {
                state: Some(WorkflowState {
                    id: "state-2".to_string(),
                    name: IN_PROGRESS_STATE.to_string(),
                    kind: Some("started".to_string()),
                }),
                ..self.issue.clone()
            })
        }

        async fn create_comment(&self, _issue_id: &str, _body: String) -> Result<IssueComment> {
            unreachable!("create_comment is not used in this test")
        }

        async fn create_issue_relation(
            &self,
            _request: crate::linear::IssueRelationCreateRequest,
        ) -> Result<()> {
            unreachable!("create_issue_relation is not used in this test")
        }

        async fn update_comment(&self, _comment_id: &str, _body: String) -> Result<IssueComment> {
            unreachable!("update_comment is not used in this test")
        }

        async fn upload_file(
            &self,
            _filename: &str,
            _content_type: &str,
            _contents: Vec<u8>,
        ) -> Result<String> {
            unreachable!("upload_file is not used in this test")
        }

        async fn create_attachment(
            &self,
            _request: AttachmentCreateRequest,
        ) -> Result<AttachmentSummary> {
            unreachable!("create_attachment is not used in this test")
        }

        async fn delete_attachment(&self, _attachment_id: &str) -> Result<()> {
            unreachable!("delete_attachment is not used in this test")
        }

        async fn download_file(&self, _url: &str) -> Result<Vec<u8>> {
            unreachable!("download_file is not used in this test")
        }
    }
    fn run_git(repo: &std::path::Path, args: &[&str]) -> anyhow::Result<()> {
        let status = Command::new("git")
            .arg("-C")
            .arg(repo)
            .args(args)
            .status()?;
        anyhow::ensure!(status.success(), "git {} failed", args.join(" "));
        Ok(())
    }
}
