# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is an MCP (Model Context Protocol) server implementation for Intuition blockchain integration. The project provides tools to interact with the Intuition blockchain network, including account information retrieval and semantic search capabilities.

## Architecture

- **MCP Server**: Built using `@modelcontextprotocol/sdk` with stdio transport
- **Blockchain Integration**: Uses `viem` library for Ethereum-compatible blockchain interactions
- **Chain Configuration**: Connects to Intuition sepolia testnet (chain ID: 13579)
- **Contract Interaction**: Integrates with Multivault smart contract

## Key Files Structure

- `src/index.ts` - Main MCP server setup and entry point
- `src/tools/index.ts` - Tool registration hub
- `src/tools/` - Individual tool implementations:
  - `semantic-search.ts` - Knowledge base search functionality
  - `account-info.ts` - Blockchain account information
  - `general-config.ts` - General contract configuration
  - `protocol-info.ts` - Protocol configuration information
  - `atom-info.ts` - Atom data and information retrieval
- `src/setup.ts` - Blockchain client configuration and contract setup  
- `src/Multivault.abi.ts` - Smart contract ABI definitions
- `build/` - Compiled TypeScript output directory

## Development Commands

```bash
# Build the project
npm run build

# The build command compiles TypeScript and makes the output executable
```

## Environment Variables Required

- `RPC_URL` - Blockchain RPC endpoint (defaults to Intuition testnet)
- `CONTRACT_ADDRESS` - Multivault contract address (has default)
- `PRIVATE_KEY` - Private key for blockchain interactions (required)

## MCP Tools Available

1. `semantic_search` - Searches the Intuition knowledge base
2. `account_info` - Returns blockchain account address and balance information
3. `general_config` - Retrieves general configuration from the Multivault contract
4. `protocol_info` - Gets comprehensive protocol configuration using multicall
5. `atom_info` - Retrieves atom information using termId and curveId

## Key Dependencies

- `@modelcontextprotocol/sdk` - MCP protocol implementation
- `viem` - Ethereum client library for blockchain interactions
- `zod` - Schema validation for tool parameters