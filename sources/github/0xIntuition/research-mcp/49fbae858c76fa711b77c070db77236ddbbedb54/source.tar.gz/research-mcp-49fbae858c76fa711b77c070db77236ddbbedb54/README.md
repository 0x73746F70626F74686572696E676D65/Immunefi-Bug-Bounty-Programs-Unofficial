# Experimental Intuition MCP server


https://github.com/user-attachments/assets/c7715d59-8a24-43b7-882b-f1d5b16af518


https://github.com/user-attachments/assets/d813e9c7-64a3-44f6-9eba-78cf83873f29

## Usage

Clone the repo
```
git clone https://github.com/0xIntuition/research-mcp.git
```

Run this 

```
claude mcp add i7n --env PRIVATE_KEY=YOUR_KEY  -- node /absolute/path/research-mcp/build/index.js
```

or manually update your `~/.claude.json`

```
{
  "mcpServers": {
    "i7n": {
      "type": "stdio",
      "command": "node",
      "args": [
        "/absolute/path/research-mcp/build/index.js"
      ],
      "env": {
        "PRIVATE_KEY": "0x........."
      }
    }
  }
}
```
