---
description: "Analyze content and find relevant Intuition atoms for deposit"
tools: ["WebFetch", "mcp__i7n__semantic_search", "mcp__i7n__atom_info", "mcp__i7n__deposit_atom", "mcp__i7n__create_atom"]
args: ["content_or_url"]
---

Analyze the following content: $ARGUMENTS

If this is a URL (starts with http:// or https://), first use WebFetch to retrieve the content. Then:

1. Extract the most relevant ideas, concepts, topics, and entities from the content
2. Use semantic search to find existing atoms in the Intuition knowledge base that relate to these concepts
3. For each relevant atom found, provide:
   - The atom data/name
   - Why it's relevant to the content
   - Current atom information (if available)
4. Suggest which atoms would be good candidates for depositing based on relevance and potential and show financial summary
5. Identify key concepts that don't exist as atoms yet and suggest creating them using mcp__i7n__create_atom

Focus on identifying meaningful concepts rather than generic terms, and prioritize atoms that have strong conceptual alignment with the content themes.
