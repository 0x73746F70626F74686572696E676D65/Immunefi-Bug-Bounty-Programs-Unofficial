import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { multiVault, account, publicClient } from "../setup.js";
import { toHex, formatEther } from "viem";
import { abi } from "../Multivault.abi.js";

export function registerAtomInfoTool(server: McpServer) {
  server.tool(
    "atom_info",
    "Get comprehensive atom information from the Intuition blockchain. Retrieves atom existence status, vault details (total assets/shares), current share price, bonding curve configuration, and user's share balance for any given atom data string. The atom data is used to calculate a unique atom ID on-chain.",
    {
      atomData: z.string().optional().describe("The atom data string (e.g., 'chimneysweep', 'ethereum', 'alice@example.com') to look up atom information for"),
      termId: z.string().optional().describe("The term ID (atom ID) as a hex string to look up atom information for")
    },
    async ({ atomData, termId }) => {
      try {
        // Validate input: exactly one of atomData or termId must be provided
        if ((!atomData && !termId) || (atomData && termId)) {
          throw new Error("Exactly one of 'atomData' or 'termId' must be provided");
        }

        // Calculate or use provided atom ID
        let atomId: `0x${string}`;
        if (atomData) {
          atomId = await multiVault.read.calculateAtomId([toHex(atomData)]);
        } else {
          atomId = termId as `0x${string}`;
        }

        // Check if atom exists
        const atomExists = await multiVault.read.isAtom([atomId]);

        let atomInfo: any = {
          atomId: atomId,
          exists: atomExists
        };

        if (atomExists) {

          // Get bonding curve config for default curve ID
          const bondingConfig = await multiVault.read.getBondingCurveConfig();
          const defaultCurveId = bondingConfig.defaultCurveId;

          // Use multicall for efficient batch reading of remaining data
          let sharePrice: any = null;
          let vaultInfo: any = null;
          let userShares: any = null;

          if (account) {
            const results = await publicClient.multicall({
              contracts: [
                {
                  address: multiVault.address,
                  abi,
                  functionName: 'currentSharePrice' as const,
                  args: [atomId, defaultCurveId] as const
                },
                {
                  address: multiVault.address,
                  abi,
                  functionName: 'getVault' as const,
                  args: [atomId, defaultCurveId] as const
                },
                {
                  address: multiVault.address,
                  abi,
                  functionName: 'getShares' as const,
                  args: [account.address, atomId, defaultCurveId] as const
                }
              ],
              allowFailure: true,
              multicallAddress: '0xcA11bde05977b3631167028862bE2a173976CA11'
            });

            sharePrice = results[0].status === 'success' ? results[0].result : null;
            vaultInfo = results[1].status === 'success' ? results[1].result : null;
            userShares = results[2].status === 'success' ? results[2].result : null;
          } else {
            const results = await publicClient.multicall({
              contracts: [
                {
                  address: multiVault.address,
                  abi,
                  functionName: 'currentSharePrice' as const,
                  args: [atomId, defaultCurveId] as const
                },
                {
                  address: multiVault.address,
                  abi,
                  functionName: 'getVault' as const,
                  args: [atomId, defaultCurveId] as const
                }
              ],
              allowFailure: true,
              multicallAddress: '0xcA11bde05977b3631167028862bE2a173976CA11'
            });

            sharePrice = results[0].status === 'success' ? results[0].result : null;
            vaultInfo = results[1].status === 'success' ? results[1].result : null;
          }

          atomInfo = {
            ...atomInfo,
            defaultCurveId: defaultCurveId.toString(),
            sharePrice: sharePrice ? formatEther(sharePrice) : "0",
            vaultInfo: vaultInfo ? {
              totalAssets: formatEther(vaultInfo[0]),
              totalShares: formatEther(vaultInfo[1])
            } : null,
            userShares: userShares ? formatEther(userShares) : "0",
            userAddress: account?.address || "No wallet connected",
            currency: publicClient.chain.nativeCurrency.symbol,
          };
        }

        return {
          content: [{
            type: "text",
            text: JSON.stringify(atomInfo, null, 2)
          }]
        };
      } catch (error) {
        return {
          content: [{
            type: "text",
            text: `Error getting atom info: ${error instanceof Error ? error.message : String(error)}`
          }]
        };
      }
    }
  );
}
