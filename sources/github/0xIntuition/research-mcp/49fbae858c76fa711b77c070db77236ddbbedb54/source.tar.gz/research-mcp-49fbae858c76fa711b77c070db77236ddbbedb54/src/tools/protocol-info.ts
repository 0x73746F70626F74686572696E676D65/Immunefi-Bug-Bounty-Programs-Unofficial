import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { formatEther } from "viem";
import { publicClient, multiVault } from "../setup.js";
import { abi } from "../Multivault.abi.js";

export function registerProtocolInfoTool(server: McpServer) {
  server.tool(
    "protocol_info",
    "Get comprehensive protocol configuration from the Multivault contract using efficient multicall. Returns complete system information including constants, configuration parameters, fee structures, bonding curve settings, vault fees, wallet configurations, creation costs, and current system state (epoch, paused status, total terms created).",
    {},
    async () => {
      try {
        // Use multicall for efficient batch reading
        const results = await publicClient.multicall({
          contracts: [
            // Config functions  
            { address: multiVault.address, abi, functionName: 'getGeneralConfig' },
            { address: multiVault.address, abi, functionName: 'getAtomConfig' },
            { address: multiVault.address, abi, functionName: 'getBondingCurveConfig' },
            { address: multiVault.address, abi, functionName: 'getTripleConfig' },
            { address: multiVault.address, abi, functionName: 'getVaultFees' },
            { address: multiVault.address, abi, functionName: 'getWalletConfig' },

            // Single value functions
            { address: multiVault.address, abi, functionName: 'currentEpoch' },
            { address: multiVault.address, abi, functionName: 'getAtomCost' },
            { address: multiVault.address, abi, functionName: 'getAtomCreationCost' },
            { address: multiVault.address, abi, functionName: 'getAtomWarden' },
            { address: multiVault.address, abi, functionName: 'getDefaultCurveId' },
            { address: multiVault.address, abi, functionName: 'getTripleCost' },
            { address: multiVault.address, abi, functionName: 'paused' },
            { address: multiVault.address, abi, functionName: 'totalTermsCreated' },
          ],
          allowFailure: true,
          multicallAddress: '0xcA11bde05977b3631167028862bE2a173976CA11'
        });

        // Extract results with safe handling
        const [
          getGeneralConfig, getAtomConfig, getBondingCurveConfig, getTripleConfig, getVaultFees, getWalletConfig,
          currentEpoch, getAtomCost, getAtomCreationCost, getAtomWarden, getDefaultCurveId, getTripleCost,
          paused, totalTermsCreated
        ] = results.map(result => result.status === 'success' ? result.result : null);

        const config = {
          currency: publicClient.chain.nativeCurrency,

          generalConfig: getGeneralConfig ? {
            admin: (getGeneralConfig as any).admin,
            protocolMultisig: (getGeneralConfig as any).protocolMultisig,
            feeDenominator: (getGeneralConfig as any).feeDenominator?.toString(),
            trustBonding: (getGeneralConfig as any).trustBonding,
            minDeposit: formatEther((getGeneralConfig as any).minDeposit),
            minShare: formatEther((getGeneralConfig as any).minShare),
            atomDataMaxLength: (getGeneralConfig as any).atomDataMaxLength?.toString(),
            decimalPrecision: (getGeneralConfig as any).decimalPrecision?.toString(),
          } : 'Error',

          atomConfig: getAtomConfig ? {
            atomCreationProtocolFee: formatEther((getAtomConfig as any).atomCreationProtocolFee),
            atomWalletDepositFee: formatEther((getAtomConfig as any).atomWalletDepositFee),
          } : 'Error',

          tripleConfig: getTripleConfig ? {
            tripleCreationProtocolFee: formatEther((getTripleConfig as any).tripleCreationProtocolFee),
            totalAtomDepositsOnTripleCreation: formatEther((getTripleConfig as any).totalAtomDepositsOnTripleCreation),
            atomDepositFractionForTriple: (getTripleConfig as any).atomDepositFractionForTriple?.toString(),
          } : 'Error',

          bondingCurveConfig: getBondingCurveConfig ? {
            registry: (getBondingCurveConfig as any).registry,
            defaultCurveId: (getBondingCurveConfig as any).defaultCurveId?.toString(),
          } : 'Error',

          vaultFees: getVaultFees ? {
            entryFee: (getVaultFees as any).entryFee?.toString(),
            exitFee: (getVaultFees as any).exitFee?.toString(),
            protocolFee: (getVaultFees as any).protocolFee?.toString(),
          } : 'Error',

          walletConfig: getWalletConfig ? {
            permit2: (getWalletConfig as any).permit2,
            entryPoint: (getWalletConfig as any).entryPoint,
            atomWarden: (getWalletConfig as any).atomWarden,
            atomWalletBeacon: (getWalletConfig as any).atomWalletBeacon,
            atomWalletFactory: (getWalletConfig as any).atomWalletFactory,
          } : 'Error',

          costs: {
            atomCost: getAtomCost ? formatEther(getAtomCost as bigint) : 'Error',
            atomCreationCost: getAtomCreationCost ? formatEther(getAtomCreationCost as bigint) : 'Error',
            tripleCost: getTripleCost ? formatEther(getTripleCost as bigint) : 'Error',
          },

          systemInfo: {
            currentEpoch: currentEpoch ? (currentEpoch as bigint)?.toString() : 'Error',
            atomWarden: getAtomWarden || 'Error',
            defaultCurveId: getDefaultCurveId ? (getDefaultCurveId as bigint)?.toString() : 'Error',
            paused: paused !== null ? paused : 'Error',
            totalTermsCreated: totalTermsCreated ? (totalTermsCreated as bigint)?.toString() : 'Error',
          }
        };

        return {
          content: [{
            type: "text",
            text: JSON.stringify(config, null, 2)
          }]
        }
      } catch (error) {
        return {
          content: [{
            type: "text",
            text: `Error fetching all config: ${error}`
          }]
        }
      }
    }
  );
}
