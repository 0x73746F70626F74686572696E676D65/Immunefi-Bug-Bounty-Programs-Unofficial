import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { registerSemanticSearchTool } from "./semantic-search.js";
import { registerAccountInfoTool } from "./account-info.js";
import { registerProtocolInfoTool } from "./protocol-info.js";
import { registerAtomInfoTool } from "./atom-info.js";
import { registerDepositAtomTool } from "./deposit-atom.js";
import { registerCreateAtomTool } from "./create-atom.js";

export function registerAllTools(server: McpServer) {
  registerSemanticSearchTool(server);
  registerAccountInfoTool(server);
  registerProtocolInfoTool(server);
  registerAtomInfoTool(server);
  registerDepositAtomTool(server);
  registerCreateAtomTool(server);
}
