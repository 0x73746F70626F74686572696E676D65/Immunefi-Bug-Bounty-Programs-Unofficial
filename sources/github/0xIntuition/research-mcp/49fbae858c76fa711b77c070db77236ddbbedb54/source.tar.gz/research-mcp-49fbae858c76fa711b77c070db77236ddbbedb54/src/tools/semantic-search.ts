import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";

export function registerSemanticSearchTool(server: McpServer) {
  server.tool(
    "semantic_search",
    "Search the Intuition protocol knowledge base for information about concepts, entities, relationships, and protocol functionality. Returns relevant results matching the search query.",
    {
      query: z.string().describe("Search query to find information in the Intuition knowledge base (e.g., 'ethereum', 'bonding curves', 'atom creation')")
    },
    async ({ query }) => {
      return {
        content: [{
          type: "text",
          text: await search(query)
        }]
      }
    }
  );
}

const searchQuery = `
query search ($query: String!) {
  search_term(args: {query: $query} limit: 5) {
    atom {
      term_id
      data
      type
      value {
        account {
          id
          label
        }
        byte_object {
          data
        }
        caip10 {
          chain_id
          namespace
          account_address
        }
        json_object {
          data
        }
        text_object {
          data
        }
      }
    }
  }
}
`

async function search(query: string) {
  const res = await fetch('https://testnet.intuition.sh/v1/graphql', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      query: searchQuery,
      variables: {
        query,
      },
    }),
  })
  const json = await res.json();
  return JSON.stringify(json, null, 2)
}
