import { getContract, createNonceManager, createPublicClient, createWalletClient, defineChain, http, getAddress } from "viem"
import { privateKeyToAccount } from "viem/accounts"
import { jsonRpc } from "viem/nonce"
import { abi } from "./Multivault.abi.js"

const rpcUrl = process.env.RPC_URL || "https://testnet.rpc.intuition.systems/http"
const contractAddress = getAddress(process.env.CONTRACT_ADDRESS || "0x5a0A023F08dF301DCCE96166F4185Ec77DF6a87a")
const privateKey = process.env.PRIVATE_KEY
if (!privateKey) {
  throw Error('PRIVATE_KEY is missing')
}

const chain = defineChain({
  id: 13579,
  name: 'Intuition sepolia',
  nativeCurrency: {
    decimals: 18,
    name: 'Test Trust',
    symbol: 'tTRUST',
  },
  rpcUrls: {
    default: { http: [rpcUrl] },
  },
  blockExplorers: {
    default: {
      name: 'Intuition Explorer',
      url: 'https://testnet.explorer.intuition.systems',
    },
  },
  contracts: {
    multicall3: {
      address: '0x66bf587EdFbd5408121bDb125a1B6F9b830F64AD',
    },
  },
})

export const publicClient = createPublicClient({
  chain,
  transport: http(rpcUrl),
});

const nonceManager = createNonceManager({
  source: jsonRpc()
})

export const account = privateKeyToAccount(privateKey as `0x${string}`, { nonceManager });

export const walletClient = createWalletClient({
  account: account,
  chain,
  transport: http(rpcUrl),
});

export const multiVault = getContract({
  address: contractAddress,
  abi,
  client: { public: publicClient, wallet: walletClient }
});

