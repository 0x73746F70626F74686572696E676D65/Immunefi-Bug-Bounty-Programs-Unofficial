import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { multiVault, account, walletClient, publicClient } from "../setup.js";
import { toHex, parseEther, formatEther } from "viem";

export function registerDepositAtomTool(server: McpServer) {
  server.tool(
    "deposit_atom",
    "Deposit assets into an atom vault on the Intuition blockchain. Accepts either atomData string or atomId hex string. If assets are not provided, uses the minimum deposit amount from the protocol configuration. Executes the deposit transaction and returns transaction details with block explorer URL.",
    {
      atomData: z.string().optional().describe("The atom data string (e.g., 'chimneysweep', 'ethereum', 'alice@example.com') to deposit into"),
      atomId: z.string().optional().describe("The atom ID as a hex string to deposit into"),
      assets: z.string().optional().describe("Optional deposit amount in " + publicClient.chain.nativeCurrency.symbol + " (e.g., '0.1'). If not provided, uses minimum deposit from protocol config")
    },
    async ({ atomData, atomId, assets }) => {
      try {
        // Validate input: exactly one of atomData or atomId must be provided
        if ((!atomData && !atomId) || (atomData && atomId)) {
          throw new Error("Exactly one of 'atomData' or 'atomId' must be provided");
        }

        if (!account || !walletClient) {
          return {
            content: [{
              type: "text",
              text: "Error: No wallet connected. A private key is required to perform deposits."
            }]
          };
        }

        // Calculate or use provided atom ID
        let calculatedAtomId: `0x${string}`;
        if (atomData) {
          calculatedAtomId = await multiVault.read.calculateAtomId([toHex(atomData)]);
        } else {
          calculatedAtomId = atomId as `0x${string}`;
        }

        // Get bonding curve config for default curve ID
        const bondingConfig = await multiVault.read.getBondingCurveConfig();
        const defaultCurveId = bondingConfig.defaultCurveId;

        // Determine deposit amount
        let depositAmount: bigint;
        if (assets) {
          depositAmount = parseEther(assets);
        } else {
          // Get minimum deposit from general config
          const config = await multiVault.read.getGeneralConfig();
          depositAmount = config.minDeposit;
        }

        // Execute deposit transaction
        const txHash = await multiVault.write.deposit(
          [
            account.address,   // receiver
            calculatedAtomId, // termId
            defaultCurveId,   // curveId
            0n                // minShares (set to 0 for now)
          ],
          {
            value: depositAmount
          }
        );

        // Wait for transaction confirmation
        const receipt = await publicClient.waitForTransactionReceipt({
          hash: txHash
        });

        const explorerUrl = `${publicClient.chain.blockExplorers.default.url}/tx/${txHash}`;

        return {
          content: [{
            type: "text",
            text: JSON.stringify({
              success: true,
              transactionHash: txHash,
              explorerUrl: explorerUrl,
              atomData: atomData || null,
              atomId: calculatedAtomId,
              depositAmount: formatEther(depositAmount),
              currency: publicClient.chain.nativeCurrency.symbol,
              curveId: defaultCurveId.toString(),
              receiver: account.address,
              blockNumber: receipt.blockNumber.toString(),
              gasUsed: receipt.gasUsed.toString(),
              status: receipt.status
            }, null, 2)
          }]
        };
      } catch (error) {
        return {
          content: [{
            type: "text",
            text: `Error depositing atom: ${error instanceof Error ? error.message : String(error)}`
          }]
        };
      }
    }
  );
}
