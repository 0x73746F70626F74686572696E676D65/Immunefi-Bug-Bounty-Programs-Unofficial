import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { formatEther } from "viem";
import { account, publicClient } from "../setup.js";

export function registerAccountInfoTool(server: McpServer) {
  server.tool(
    "account_info",
    "Get blockchain account information including wallet address and native token balance. Returns the configured account's address and current balance on the Intuition network.",
    {},
    async () => {
      if (!account) {
        return {
          content: [{
            type: "text",
            text: "No account configured. PRIVATE_KEY environment variable is required."
          }]
        }
      }

      const balance = await publicClient.getBalance({ address: account.address })
      return {
        content: [{
          type: "text",
          text: `Account address: ${account.address}, balance ${formatEther(balance)} ${publicClient.chain.nativeCurrency.symbol}`
        }]
      }
    }
  );
}
