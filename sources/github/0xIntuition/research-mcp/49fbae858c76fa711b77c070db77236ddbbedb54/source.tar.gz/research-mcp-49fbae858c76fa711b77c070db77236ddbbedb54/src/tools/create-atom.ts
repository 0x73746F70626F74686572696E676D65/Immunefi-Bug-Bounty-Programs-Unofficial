import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { multiVault, account, walletClient, publicClient } from "../setup.js";
import { toHex, parseEther, formatEther } from "viem";

export function registerCreateAtomTool(server: McpServer) {
  server.tool(
    "create_atom",
    "Create a new atom on the Intuition blockchain. Checks if atom already exists before creation. Gets atom creation cost from contract and adds optional initial deposit. Executes the creation transaction and returns transaction details with block explorer URL.",
    {
      atomData: z.string().describe("The atom data string (e.g., 'hello world', 'ethereum', 'alice@example.com') to create"),
    },
    async ({ atomData }) => {
      try {
        if (!account || !walletClient) {
          return {
            content: [{
              type: "text",
              text: "Error: No wallet connected. A private key is required to create atoms."
            }]
          };
        }

        // Calculate atom ID using the contract method
        const atomId = await multiVault.read.calculateAtomId([toHex(atomData)]);

        // Check if atom already exists
        const atomExists = await multiVault.read.isAtom([atomId]);

        if (atomExists) {
          return {
            content: [{
              type: "text",
              text: `Error: Atom already exists with ID ${atomId}. Cannot create duplicate atom.`
            }]
          };
        }

        // Get atom creation cost from contract
        const atomCost = await multiVault.read.getAtomCost();
        const { minDeposit } = await multiVault.read.getGeneralConfig();

        // Calculate total value to send
        let totalValue = atomCost + minDeposit;

        // Execute createAtoms transaction
        const txHash = await multiVault.write.createAtoms(
          [
            [toHex(atomData)],    // data array (single atom)
            [totalValue] // assets array (initial deposit or 0)
          ],
          {
            value: totalValue
          }
        );

        // Wait for transaction confirmation
        const receipt = await publicClient.waitForTransactionReceipt({
          hash: txHash
        });

        const explorerUrl = `${publicClient.chain.blockExplorers.default.url}/tx/${txHash}`;

        return {
          content: [{
            type: "text",
            text: JSON.stringify({
              success: true,
              transactionHash: txHash,
              explorerUrl: explorerUrl,
              atomData: atomData,
              atomId: atomId,
              totalValue: formatEther(totalValue),
              currency: publicClient.chain.nativeCurrency.symbol,
              creator: account.address,
              blockNumber: receipt.blockNumber.toString(),
              gasUsed: receipt.gasUsed.toString(),
              status: receipt.status
            }, null, 2)
          }]
        };
      } catch (error) {
        return {
          content: [{
            type: "text",
            text: `Error creating atom: ${error instanceof Error ? error.message : String(error)}`
          }]
        };
      }
    }
  );
}
