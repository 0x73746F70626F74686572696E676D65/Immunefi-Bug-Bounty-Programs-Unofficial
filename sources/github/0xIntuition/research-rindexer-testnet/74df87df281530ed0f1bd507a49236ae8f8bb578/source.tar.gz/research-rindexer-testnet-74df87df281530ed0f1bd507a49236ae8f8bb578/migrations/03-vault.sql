-- Migration: Create vault materialized view
-- This view aggregates SharePriceChanged events and counts positions per vault
--
-- Description:
-- The vault materialized view provides current state for each vault (term_id, curve_id combination).
-- It sources data from SharePriceChanged events and joins with the position view to count active positions.
--
-- Usage:
-- PGPASSWORD=rindexer psql -h localhost -p 5440 -U postgres -d postgres -f migrations/vault.sql
--
-- Refresh:
-- SELECT refresh_vault_view();

-- Create vault_type enum
DO $$ BEGIN
    CREATE TYPE vault_type AS ENUM ('Atom', 'Triple', 'CounterTriple');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Drop existing objects
DROP MATERIALIZED VIEW IF EXISTS public.vault CASCADE;
DROP FUNCTION IF EXISTS refresh_vault_view() CASCADE;

-- Create materialized view
CREATE MATERIALIZED VIEW public.vault AS
WITH
-- Get latest share price event for each vault
latest_share_price AS (
    SELECT DISTINCT ON (term_id, curve_id)
        '0x' || encode(term_id, 'hex') AS term_id,
        CAST(curve_id AS numeric(78,0)) AS curve_id,
        CAST(share_price AS numeric(78,0)) AS current_share_price,
        CAST(total_assets AS numeric(78,0)) AS total_assets,
        CAST(total_shares AS numeric(78,0)) AS total_shares,
        CASE vault_type
            WHEN 0 THEN 'Atom'
            WHEN 1 THEN 'Triple'
            WHEN 2 THEN 'CounterTriple'
        END AS vault_type,
        block_number,
        log_index,
        tx_hash,
        tx_index,
        block_timestamp
    FROM intuition_multi_vault.share_price_changed
    ORDER BY term_id, curve_id, block_number DESC, log_index DESC
),

-- Count active positions per vault (only count positions with shares > 0)
position_counts AS (
    SELECT
        term_id,
        curve_id,
        COUNT(*) AS position_count
    FROM public.position
    WHERE shares > 0
    GROUP BY term_id, curve_id
),

-- Get first event timestamp as created_at
first_event AS (
    SELECT
        '0x' || encode(term_id, 'hex') AS term_id,
        CAST(curve_id AS numeric(78,0)) AS curve_id,
        MIN(block_timestamp) AS created_at
    FROM intuition_multi_vault.share_price_changed
    GROUP BY term_id, curve_id
)

-- Final vault view combining all CTEs
SELECT
    lsp.term_id,
    lsp.curve_id,
    lsp.total_shares,
    lsp.current_share_price,
    lsp.total_assets,
    -- Market cap calculation: (total_shares * current_share_price) / 1e18
    -- This represents the total value of all shares at current price
    CAST((lsp.total_shares * lsp.current_share_price / 1000000000000000000) AS NUMERIC(78, 0)) AS market_cap,
    COALESCE(pc.position_count, 0) AS position_count,
    lsp.vault_type,
    CAST(lsp.block_number AS BIGINT) AS block_number,
    CAST(lsp.log_index AS BIGINT) AS log_index,
    CAST(lsp.tx_hash AS TEXT) AS transaction_hash,
    CAST(lsp.tx_index AS BIGINT) AS transaction_index,
    fe.created_at,
    lsp.block_timestamp AS updated_at
FROM latest_share_price lsp
LEFT JOIN position_counts pc
    ON lsp.term_id = pc.term_id
    AND lsp.curve_id = pc.curve_id
LEFT JOIN first_event fe
    ON lsp.term_id = fe.term_id
    AND lsp.curve_id = fe.curve_id;

-- Create unique index for CONCURRENT refresh capability
-- This index is required for REFRESH MATERIALIZED VIEW CONCURRENTLY
CREATE UNIQUE INDEX vault_pkey
    ON public.vault (term_id, curve_id);

-- Additional indexes for query optimization
CREATE INDEX idx_vault_term_id
    ON public.vault (term_id);

CREATE INDEX idx_vault_vault_type
    ON public.vault (vault_type);

CREATE INDEX idx_vault_updated_at
    ON public.vault (updated_at);

CREATE INDEX idx_vault_market_cap
    ON public.vault (market_cap DESC);

CREATE INDEX idx_vault_position_count
    ON public.vault (position_count DESC);

-- Create refresh function
-- This function can be called manually or scheduled via pg_cron
CREATE OR REPLACE FUNCTION refresh_vault_view()
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY public.vault;
END;
$$;

-- Add comments for documentation
COMMENT ON MATERIALIZED VIEW public.vault IS
'Aggregated vault data from SharePriceChanged events. Shows current state including total assets, total shares, share price, market cap, and position count per (term_id, curve_id). Updated via refresh_vault_view().';

COMMENT ON FUNCTION refresh_vault_view() IS
'Refreshes the vault materialized view using CONCURRENT mode. Can be called manually or scheduled via pg_cron for periodic updates.';

COMMENT ON COLUMN public.vault.term_id IS
'Unique identifier for the term (atom or triple) as hex-encoded bytes32.';

COMMENT ON COLUMN public.vault.curve_id IS
'Bonding curve identifier for the vault (typically 0 for standard curve).';

COMMENT ON COLUMN public.vault.vault_type IS
'Type of vault: Atom, Triple (pro), CounterTriple (con).';

COMMENT ON COLUMN public.vault.market_cap IS
'Calculated market capitalization: (total_shares * current_share_price) / 1e18. Represents total value of all shares.';

COMMENT ON COLUMN public.vault.position_count IS
'Number of active positions (accounts with shares > 0) in this vault.';

COMMENT ON COLUMN public.vault.created_at IS
'Timestamp when the vault was first created (first SharePriceChanged event).';

COMMENT ON COLUMN public.vault.updated_at IS
'Timestamp of the most recent SharePriceChanged event for this vault.';
