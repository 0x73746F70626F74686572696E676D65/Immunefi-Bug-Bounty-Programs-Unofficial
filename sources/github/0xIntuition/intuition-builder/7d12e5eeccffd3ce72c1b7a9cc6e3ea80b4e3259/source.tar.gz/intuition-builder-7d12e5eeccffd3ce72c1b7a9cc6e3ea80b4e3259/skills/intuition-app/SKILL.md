---
name: intuition-app
description: Use this skill when BUILDING AN APPLICATION on the Intuition protocol — a web app, dashboard, or frontend that reads the knowledge graph and lets users create atoms/triples or stake on claims. Covers network and wallet wiring, the GraphQL indexer, local term-ID derivation, revert decoding, React data patterns, and deployment. Triggers on requests to build, scaffold, or debug an app, site, or dashboard on Intuition. For raw transaction encoding and ABI correctness, use the `intuition` skill instead.
license: MIT
metadata:
  author: Selby Studio
  version: "0.1.1"
allowed-tools: "Bash, Read, Write, Edit, Glob, Grep, WebFetch"
---

# Building applications on Intuition

## What this skill is, and what it is not

The official `intuition` skill (`0xIntuition/agent-skills`) is the canonical reference for
**producing correct transactions** — ABIs, encoding, addresses, value calculations. It states its
own boundary plainly:

> Skills produce unsigned transaction parameters. Wallet infrastructure and signing are the
> builder's responsibility.

**This skill is that responsibility.** It covers everything between "I have correct calldata" and
"there is a working app at a URL": chain config, wallet connection, the indexer, React state,
error surfaces, and deploy.

**Division of labour — follow it strictly:**

| Need | Use |
|---|---|
| Exact calldata, ABI encoding, `previewAtomCreate`, IPFS pinning policy, batch semantics | the `intuition` skill |
| Chain/wallet wiring, reading the indexer, local ID derivation, decoding reverts, app structure, deploy | this skill |

If both are installed, prefer `intuition` for anything that touches transaction bytes. Do not
re-derive its guidance here.

## Start here: scaffold, don't hand-roll

There is a working starter at `template/` in this plugin. Copy it rather than assembling one:

```bash
cp -r "${CLAUDE_PLUGIN_ROOT}/template" my-intuition-app
cd my-intuition-app
npm install
cp .env.example .env.local
npm run doctor      # verifies the whole environment before you write a line
npm run dev
```

If the board is empty (fresh graph, no claims on the demo predicate), seed it:
`SEED_PRIVATE_KEY=0x… npm run seed` — idempotent, testnet-only, mints the demo predicate and three
example claims from a funded key.

`src/intuition/` is the reusable core — chains, client, ids, errors, graphql. The rest is a demo
claims board you should delete.

## Run the doctor before debugging anything

`npm run doctor` is the single highest-value command in this skill. It checks, in order: env
config, RPC reachability and chain ID match, bytecode at the MultiVault address, atom/triple cost,
default curve ID, **local term-ID derivation against the contract's own pure functions**, which
GraphQL schema shape the indexer actually speaks, whether `_eq` on an address silently returns
zero rows, and wallet balance. It exits non-zero on failure so it works in CI.

When a user says "it isn't working", run the doctor first. It resolves most reports without
reading any application code.

## The five things that break every first app

These are the failure modes worth memorising. Each is silent — no error, or an error that points
somewhere else.

**1. Addresses are stored CHECKSUMMED in the indexer.**
`where: { account_id: { _eq: "0xabc…" } }` with a lowercase address returns `[]`. No error. It
reads exactly like "this user has no positions". Use `_ilike`, or `getAddress()` the value first.
This is the single most common cause of "my positions query returns nothing".

**2. The published GraphQL docs and the live indexer disagree.**
The docs show TheGraph-style camelCase (`positiveVault`, `negativeVault`, `userPositions`,
`first:`, `orderBy:`). The endpoint is `/v1/graphql` served by `intuition-rs` — Hasura, so
snake_case, `where:`, `limit:`, `order_by:`. Write against the docs and you get a query that
errors on a field you can plainly see documented. The template ships candidate shapes and resolves
at runtime rather than guessing; see `reference/read-layer.md`.

**3. Term IDs are derivable locally — most apps needlessly round-trip.**
Verified against `intuition-contracts-v2`, `MultiVaultCore.sol`:

```
ATOM_SALT    = keccak256("ATOM_SALT")
TRIPLE_SALT  = keccak256("TRIPLE_SALT")
COUNTER_SALT = keccak256("COUNTER_SALT")

atomId          = keccak256(abi.encodePacked(ATOM_SALT, keccak256(data)))
tripleId        = keccak256(abi.encodePacked(TRIPLE_SALT, subjectId, predicateId, objectId))
counterTripleId = keccak256(abi.encodePacked(COUNTER_SALT, tripleId))
```

You can compute an id, link to it, and check existence before spending anything. The doctor
verifies these against the chain's own `calculateAtomId` / `calculateTripleId` /
`calculateCounterTripleId`, so you find out immediately if the derivation ever changes.

**4. The L3 is not on Etherscan, so reverts arrive as a bare 4-byte selector.**
`src/intuition/revert-selectors.json` carries all 96 custom errors across the v2 contracts,
generated from source by `npm run selectors`. `explainRevert(err)` turns a selector into a name
plus a plain-English fix. Regenerate rather than transcribe — a stale table decodes to
confidently wrong error names, which is worse than no table.

**5. Mainnet and testnet have different MultiVault addresses.**
Testnet `0x2Ece8D4dEdcB9918A398528f3fa4688b1d2CAB91`, mainnet
`0x6E35cF57A41fA15eA0EaE9C33e751b01A784Fe7e`. Copying one into the other config gives you "no
contract at that address", which reads like an RPC problem. The doctor catches it in one line.
Also note the RPC URLs need the `/http` suffix.

## Non-negotiable rules when writing app code

- **Never hardcode `curveId = 1`.** Read it from `getBondingCurveConfig()`. It is the current
  default, not a constant.
- **Never hardcode fee percentages or costs.** Read `getAtomCost()` / `getTripleCost()` at
  runtime; they are admin-settable. For what gets charged, use the protocol's own preview
  functions — see the `intuition` skill.
- **Creation is batch-only.** There is no `createAtom()`. Use `createAtoms([data], [assets])`.
  Every array argument must be the same length, and `msg.value` must equal `sum(assets)`.
- **Simulate before you send.** `simulateContract` → `writeContract` surfaces the revert before
  the user pays gas, and gives you a selector to decode.
- **To disagree with a claim, stake the counter-triple id.** Same `deposit()` call, different term
  id. The counter vault is created automatically when the triple is created.
- **One address cannot hold both sides** of a triple at the same curve —
  `MultiVault_HasCounterStake`. Treat it as a UX rail; two addresses defeat it, so never rely on
  it for honest signalling.
- **Always add-then-switch the chain.** Intuition is in no wallet's default list, so a first-run
  user always needs `wallet_addEthereumChain`.

## Reference

Load these as needed rather than up front.

| File | When |
|---|---|
| `reference/networks-and-wallet.md` | chain config, connection, add/switch, wagmi migration |
| `reference/read-layer.md` | indexer queries, the schema-shape problem, pagination, consensus |
| `reference/write-layer.md` | creating atoms/triples, staking, simulate/send/decode |
| `reference/ids-and-errors.md` | ID derivation, the full 96-error selector table, decoding |
| `reference/app-patterns.md` | React state, never-empty UIs, optimistic staking, predicates |
| `reference/deploy.md` | Vercel/Netlify, SPA rewrites, env vars, mainnet checklist |
| `reference/troubleshooting.md` | symptom → cause → fix |
| `reference/app-ideas.md` | what to build — 14 app ideas mapped to claim structures |

## Working style

Ask which network before writing code — testnet unless the user says otherwise. Get to something
running and visible early, then iterate. Prefer showing the user a real screen over describing
one. When something fails, run `npm run doctor` before reading application code, and report the
decoded revert rather than the raw selector.
