# Application patterns

Design guidance specific to building on a knowledge graph with two-sided claims. None of this is
protocol mechanics — it is what makes an Intuition app feel finished rather than like a demo.

## Design around the counter-vault

Most chains give you one direction: hold, stake, like, follow. Intuition gives you a native
**against** side on every triple. If your app only exposes agreement, you have built something you
could have built on any attestation service, and you have thrown away the one primitive nobody else
has.

Concretely, that means: show both sides of the book, not a single score. Make disagreement one click
from agreement, not buried. Display the ratio as a position, not a rating — "62% supported, 1.4k
staked" reads as a market; "3.1 stars" reads as an opinion. And show who is on each side when you
can, because a claim with two large holders on the against side is a different object from one with
two hundred small ones.

## Never render an empty screen

A new graph, a lagging indexer, or a wrong predicate ID all produce the same thing: an empty list.
Users read that as "broken", and it is the most common reason a working app feels broken.

Three defences, in order of value:

**Seed with real content.** Ship your app pointed at claims that already exist and already have
depth. An app that opens with something to look at is a categorically different first impression.

**Blend rather than replace.** If you hold local/demo entries, add live results on top of them
instead of swapping. The board is never empty, and real activity visibly moves it. Label demo data
as demo everywhere it renders — this is a correctness and honesty requirement, not decoration,
especially if you display anything that looks like a price or a probability about a named entity.

**Make empty states diagnostic.** "No claims found for predicate `0x1234…` on testnet. Run
`npm run doctor`, or set `VITE_PREDICATE_ID`." tells the user what to do. "No results" does not.

## Suppress numbers below minimum depth

If you compute a ratio, refuse to display it until the book is deep enough to mean something. A
claim with 0.001 TRUST on each side is not "50% disputed", it is noise, and rendering it as a
percentage manufactures confidence out of nothing.

```ts
const MIN_DEPTH = 25;                                  // in TRUST, tune to your domain
const total = forAssets + againstAssets;               // assets, not shares — see read-layer.md
const ratio = total >= MIN_DEPTH ? forAssets / total : null;
```

Show "insufficient depth" for the null case. A wrong number is worse than no number, and this is
one line of code.

## Predicates are your schema

Your app's entire data model is the predicate atoms it uses. Pick them deliberately, create them
once, and put the IDs in config — do not derive them ad hoc in three places.

For reference, roughly 80% of triples on the live graph use `has tag`, which means generic tagging
is well-trodden and a specific predicate is what makes your app's data distinguishable. Design the
predicate as carefully as you would a database table name; it is the thing other apps will or will
not be able to interoperate with.

Prefer reusing an existing predicate atom over minting a near-duplicate. Two predicates meaning the
same thing split the graph and halve everyone's signal.

## Derive IDs, don't store them

Term IDs are deterministic. Compute them on demand rather than caching them in a database, and you
cannot get out of sync. This also gives you clean permalinks (`/claim/{tripleId}`) that work before
the indexer has caught up.

The one thing worth caching is the resolved GraphQL schema shape, per session.

## React data patterns

Render seed or cached state immediately, then fold live results in — never block first paint on the
network. The indexer is a separate system from the chain and can be slow or briefly unavailable, and
an app that shows a spinner until it answers is an app that is down whenever the indexer is.

Poll rather than subscribe unless you have a specific reason. Blocks are ~2s; a 10–15s poll on the
visible list is plenty and avoids a websocket lifecycle you will otherwise debug.

Key pending writes per item, not globally:

```ts
const [pending, setPending] = useState<Record<string, boolean>>({});
// pending[claim.tripleId] — one in-flight stake never freezes the whole board
```

After a successful write, optimistically bump the local number and re-fetch a few seconds later.
The indexer is a block or two behind, so an immediate re-fetch usually returns the *old* value and
looks like the transaction failed — which is worse than not refetching at all.

## Error surfaces

Every write path should end in a decoded, human-sentence error. `explainRevert()` from the template
does the lookup; your job is to put it somewhere the user will read and to keep it specific. "You
already hold the opposing side of this claim" is a good error. "Transaction failed" is not an error
message, it is an absence of one.

Distinguish three failure classes in the UI, because the user's next action differs: wallet/chain
problems (fix the connection), balance problems (get TRUST — link the faucet on testnet), and
contract reverts (change what you are asking for).

## Structure for reuse

Keep everything protocol-specific in one directory — `src/intuition/` in the template — with no
imports from your UI layer. That directory is portable to the next project, and it is also the unit
an agent can read in one pass when it needs to reason about the data path. Domain logic and
components live outside it.
