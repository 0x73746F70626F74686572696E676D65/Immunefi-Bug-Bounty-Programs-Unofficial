# The read layer

## The schema-shape problem

Read this before writing a single query.

The published documentation at `/developer-tools/graphql-api/overview` shows queries in a
TheGraph/subgraph idiom:

```graphql
triples(first: 10, orderBy: createdAt, orderDirection: desc) {
  id
  positiveVault { totalShares totalAssets }
  negativeVault { totalShares totalAssets }
}
```

The live endpoint is `/v1/graphql` served by `intuition-rs` — a Rust indexer writing Postgres
behind Hasura. Hasura's idiom is different in every particular:

```graphql
triples(where: { predicate_id: { _ilike: $predicate } }, limit: 10, order_by: { created_at: desc }) {
  term_id
  counter_term_id
  term { vaults { curve_id total_shares position_count } }
  counter_term { vaults { curve_id total_shares position_count } }
}
```

snake_case not camelCase. `where: { field: { _op: value } }` not `where: { field: value }`.
`limit`/`order_by` not `first`/`orderBy`. `term`/`counter_term` not `positiveVault`/`negativeVault`.

Both cannot be right. Writing against the docs produces a query that errors on a field you can see
documented, which is a genuinely disorienting way to lose an afternoon.

**Do not guess. Resolve at runtime.** Ship candidate shapes and let the indexer pick:

```ts
const candidates = [
  { shape: "hasura",   query: HASURA_Q,   normalise: fromHasura },
  { shape: "subgraph", query: SUBGRAPH_Q, normalise: fromSubgraph },
];

for (const c of candidates) {
  const json = await post(c.query, vars);
  if (json.errors?.length || json.data == null) continue;
  cachedShape = c.shape;              // reuse for the rest of the session
  return c.normalise(json.data);
}
```

Cost is one wasted round trip on first load, once. The benefit is that a schema change degrades to
"one candidate stopped working" instead of "the app is broken and nobody knows why". The template
implements this in `src/intuition/graphql.ts`; `npm run doctor` reports which shape answered.

If neither answers, open the endpoint in a playground, run an introspection query, and add the real
shape as a third candidate. Never delete the normaliser layer — it is what keeps the schema problem
contained to one file.

## Addresses are stored checksummed

The highest-frequency bug on this stack:

```graphql
# returns [] — silently, no error
positions(where: { account_id: { _eq: "0x3437...9363" } }) { term_id shares }

# returns rows
positions(where: { account_id: { _ilike: "0x3437...9363" } }) { term_id shares }
```

The indexer stores checksummed (mixed-case) addresses. `_eq` is case-sensitive. A lowercase address
from `eth_requestAccounts` therefore matches nothing, and an empty array is indistinguishable from
"this user genuinely has no positions".

Two fixes, use either or both: `_ilike` for any address filter, or `getAddress()` at the boundary
where addresses enter your app. `_ilike` is the safer default because it survives an address
arriving from somewhere you did not write.

The doctor probes this empirically against the live indexer and warns if `_eq` returns zero rows
where `_ilike` returns some.

## Filter operators (Hasura)

| Operator | Use |
|---|---|
| `_eq` / `_neq` | exact match — **never for addresses** |
| `_ilike` | case-insensitive pattern, `%` wildcards — labels and addresses |
| `_like` | case-sensitive pattern |
| `_in` / `_nin` | membership |
| `_gt` `_gte` `_lt` `_lte` | ordering |
| `_is_null` | null check |
| `_and` / `_or` / `_not` | composition |

Pagination is `limit` + `offset`, not cursors. Sort with `order_by: { field: asc|desc }`.

## Shape of the data

- **Atom** — `term_id` (bytes32), `label`, `data` (the URI or raw bytes), `type`.
- **Triple** — `term_id`, `counter_term_id`, and `subject` / `predicate` / `object`, each a full
  atom.
- **Vault** — one per `(term, curve)` pair. Read `total_shares`, `total_assets`, `position_count`.
  A term has multiple vaults if multiple curves are in use, so **filter by `curve_id`** rather than
  taking `vaults[0]`.
- **Position** — `account_id`, `term_id`, `curve_id`, `shares`.

Share and asset values are wei-scale strings. Do not `Number()` them directly — that silently
loses precision above 2^53. Divide in `BigInt` first, then convert:

```ts
const toFloat = (wei: string) => Number(BigInt(wei) / 10n ** 12n) / 1e6;
```

## Consensus

The signal most apps actually want is the ratio between a triple's two vaults — and the units
matter:

```ts
// RIGHT — assets (TRUST) are the common denominator
const consensus = forAssets / (forAssets + againstAssets);   // 1 = supported, 0 = disputed

// WRONG — the two vaults are independent bonding-curve books with their own
// share prices, so share counts are not comparable across them. A mature vault's
// shares are each worth more TRUST than a fresh counter-vault's, and the ratio
// skews toward whichever side minted its shares cheaper.
const wrong = forShares / (forShares + againstShares);
```

Read `total_assets` from each vault (fall back to converting shares via `current_share_price` if
your indexer build lacks it). If all you have is shares, label the number as approximate.

Guard the zero-denominator case and **refuse to render a ratio below a minimum depth**. A claim
with 0.001 TRUST on each side is not "50% disputed", it is noise, and displaying it as a percentage
manufactures confidence that is not there. Show "insufficient depth" instead.

## Practical query recipes

**Claims by predicate** — the workhorse for any board or feed. Filter `predicate_id` with `_ilike`,
pull `term { vaults }` and `counter_term { vaults }` together so you get both sides in one round
trip.

**A user's positions** — filter `account_id` with `_ilike`, then join against the terms you care
about client-side. Do not try to filter positions by term list and account in one query unless you
have confirmed the indexer supports the nested filter; it is easier to over-fetch and intersect.

**Search** — `label: { _ilike: "%term%" }`. Wrap the user's input in `%` yourself; do not make
callers know that.

**Existence** — do not query the indexer. Derive the ID locally and call `isTermCreated(termId)`
on-chain. The indexer lags the chain by a block or two, which is enough to produce a duplicate
creation attempt and a confusing `MultiVault_AtomExists` revert.
