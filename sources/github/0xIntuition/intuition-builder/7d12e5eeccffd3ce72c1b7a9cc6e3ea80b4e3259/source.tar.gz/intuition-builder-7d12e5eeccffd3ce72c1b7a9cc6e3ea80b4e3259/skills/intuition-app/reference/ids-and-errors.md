# Term IDs and revert decoding

## Deriving IDs locally

Every term ID in Intuition v2 is a deterministic `bytes32`. You can compute it before sending
anything — which means you can check existence, build a permalink, or look a term up in the indexer
without a transaction and without an RPC round trip.

Verified against `intuition-contracts-v2`, `src/protocol/MultiVaultCore.sol`:

```solidity
bytes32 public constant ATOM_SALT    = keccak256("ATOM_SALT");
bytes32 public constant TRIPLE_SALT  = keccak256("TRIPLE_SALT");
bytes32 public constant COUNTER_SALT = keccak256("COUNTER_SALT");

function _calculateAtomId(bytes memory data) internal pure returns (bytes32) {
    return keccak256(abi.encodePacked(ATOM_SALT, keccak256(data)));
}

function _calculateTripleId(bytes32 s, bytes32 p, bytes32 o) internal pure returns (bytes32) {
    return keccak256(abi.encodePacked(TRIPLE_SALT, s, p, o));
}

function _calculateCounterTripleId(bytes32 tripleId) internal pure returns (bytes32) {
    return bytes32(keccak256(abi.encodePacked(COUNTER_SALT, tripleId)));
}
```

Resolved salt values:

```
ATOM_SALT    0xc50959b2b0264fed58f3489f13cdf8345df0911245cc2b741070787ee7aceaa2
TRIPLE_SALT  0x23ad11f0a1505378b82984192ad0461e6a012820fc5bf2e4ba16513f8e430552
COUNTER_SALT 0xe7cbc1eb0e9b3f8688b0bc91a8278f7d2867f14f2a10dc3f0d9fcfdc32dada12
```

In viem:

```ts
import { keccak256, encodePacked, toHex } from "viem";

const ATOM_SALT = keccak256(toHex("ATOM_SALT"));

export const calculateAtomId = (data: Hex) =>
  keccak256(encodePacked(["bytes32", "bytes32"], [ATOM_SALT, keccak256(data)]));

export const calculateCounterTripleId = (tripleId: Hex) =>
  keccak256(encodePacked(["bytes32", "bytes32"], [COUNTER_SALT, tripleId]));
```

Note the double hash on atoms — it is `keccak256(SALT ++ keccak256(data))`, not
`keccak256(SALT ++ data)`. Getting that wrong produces plausible-looking IDs that match nothing,
and the failure surfaces much later as `MultiVault_TermDoesNotExist`.

### The counter-ID naming trap

The two counter-triple helpers do not do what their names suggest:

```solidity
// takes the three ATOM ids — derives the triple id internally, then the counter id
function calculateCounterTripleId(bytes32 subjectId, bytes32 predicateId, bytes32 objectId)
    external pure returns (bytes32);

// THIS is the one that takes a triple id
function getCounterIdFromTripleId(bytes32 tripleId) external pure returns (bytes32);
```

The obvious guess — `calculateCounterTripleId(tripleId)` — produces a selector that does not exist
on the contract, so the call reverts with nothing useful attached. Because it happens on a read,
there is no failed transaction to inspect either. Confirmed against testnet.

Related: `getTripleIdFromCounterId(bytes32)` goes the other way, and `getInverseTripleId(bytes32)`
flips whichever side you hand it.

**Verify, don't trust.** The contract exposes `calculateAtomId`, `calculateTripleId`,
`calculateCounterTripleId` and `getCounterIdFromTripleId` as `pure` functions. `npm run doctor`
calls all of them — including both routes to a counter id — and compares against local derivation,
so a change in salting or packing fails loudly at diagnosis time rather than silently in
production. If you copy this derivation into a project without the doctor, add that assertion to
your test suite instead.

The counter-triple ID is the practical payoff: **staking against a claim is the same `deposit()`
call with the counter ID**, and you can derive it from the triple ID alone, with no extra query.

## Revert decoding

The Intuition L3 is not indexed by Etherscan, so a failed transaction gives you a bare 4-byte
selector and nothing else. Wallets render this as "execution reverted", which tells the user
nothing and tells you less.

`src/intuition/revert-selectors.json` in the template carries **all 96 custom errors** across the
v2 contracts, each with its canonical signature and computed selector. Regenerate with:

```bash
npm run selectors                  # clones contracts-v2 at main, pins the SHA it read
npm run selectors -- --ref v2.1.0  # or a tag/SHA
npm run selectors -- --src ../intuition-contracts-v2
```

**Generate, never transcribe.** A hand-maintained selector list goes stale silently, and a stale
table is worse than no table — it decodes to a confidently wrong error name and sends you after the
wrong bug.

Usage:

```ts
try {
  const { request } = await publicClient.simulateContract({ /* … */ });
  await walletClient.writeContract(request);
} catch (err) {
  setError(explainRevert(err));   // "MultiVault_HasCounterStake: This address already holds…"
}
```

### The errors an app actually hits

| Error | Meaning and fix |
|---|---|
| `MultiVault_HasCounterStake` | The address holds shares on the **other** side of this triple at this curve. Cannot be long and short the same claim from one address. Redeem first, or use another address. Per-address only — two addresses defeat it, so treat it as a UX rail, not a guarantee. |
| `MultiVault_CannotDirectlyInitializeCounterTriple` | The counter vault cannot be the first vault created. Deposit into the positive triple first. |
| `MultiVault_AtomExists` | Deterministic IDs — derive locally and call `isTermCreated()` before creating. |
| `MultiVault_TripleExists` | That exact S/P/O already exists. Deposit into it instead. |
| `MultiVault_TermDoesNotExist` | Usually a wrong derivation, or the term exists on the *other* network. |
| `MultiVault_ArraysNotSameLength` | Creation is batch-only; every array argument must match length, including `assets[]`. |
| `MultiVault_InsufficientAssets` | `msg.value` must equal `sum(assets[])`, and each `assets[i]` must cover the creation cost. |
| `MultiVault_DepositBelowMinimumDeposit` | Under the protocol minimum. Read it rather than hardcoding — it is admin-settable. |
| `MultiVault_DepositTooSmallToCoverMinShares` | New vaults burn ghost shares on creation, so the *first* deposit into a term must be larger than you would expect. |
| `MultiVault_SlippageExceeded` | The vault moved between preview and send. Re-preview, or widen `minShares`. |
| `MultiVault_InvalidBondingCurveId` | That curve is not registered. Read the default from `getBondingCurveConfig()`. |
| `MultiVault_SenderNotApproved` / `RedeemerNotApproved` | Delegation missing. See `approve(address, uint8)` — `0=NONE, 1=DEPOSIT, 2=REDEMPTION, 3=BOTH`, and setting `1` then `2` **overwrites**, it does not combine. |

### A note on selector provenance

The published `intuition` skill pins two selectors inline: `0xb4856ebc` for
`MultiVault_AtomExists` and `0x4762af7d` for `MultiVault_TermDoesNotExist`. Computing selectors
from source at `intuition-contracts-v2` HEAD gives `0xe9ae238f` and `0x36559710`; neither pinned
value reproduces from any error signature in `intuition-contracts-v2` **or**
`intuition-beta-contracts`.

That discrepancy is unresolved. It may be that the pinned values came from a deployment predating
both repos. Until it is settled, **decode against a table you generated yourself from the source
matching your deployment**, and treat any decode you cannot reproduce as unverified. This is
precisely why the table is generated rather than transcribed.
