# Troubleshooting

**Run `npm run doctor` first.** It checks config, RPC, chain ID, contract bytecode, costs, curve ID,
local-vs-chain ID derivation, indexer schema shape, the address-casing trap, and wallet balance, and
it names the fix for each failure. Most reports resolve there without reading any application code.

## Symptom → cause → fix

**A query returns `[]` but the data definitely exists.**
Almost always the address-casing trap: the indexer stores addresses checksummed and `_eq` is
case-sensitive, so a lowercase address matches nothing and returns an empty array with no error.
Switch to `_ilike`, or `getAddress()` at the boundary. If the filter is not on an address, check
you are on the network the data is on — mainnet and testnet are entirely separate graphs.

**GraphQL errors on a field that is in the documentation.**
The docs show a subgraph-style camelCase schema; the live endpoint is Hasura and uses snake_case
with `where`/`limit`/`order_by`. Use the candidate-shape resolver in `src/intuition/graphql.ts`
rather than picking one. `npm run doctor` reports which shape your indexer actually speaks.

**"No contract at that address."**
The MultiVault addresses differ between networks — testnet
`0x2Ece8D4dEdcB9918A398528f3fa4688b1d2CAB91`, mainnet
`0x6E35cF57A41fA15eA0EaE9C33e751b01A784Fe7e`. You have almost certainly crossed them. The doctor's
bytecode check catches this immediately.

**RPC 404s or times out.**
The URLs need the `/http` suffix: `https://testnet.rpc.intuition.systems/http`. If it still fails
from a sandbox, CI runner, or corporate network, the host may be blocked outright — test from a
normal machine before assuming the node is down.

**"Execution reverted" with no reason.**
The L3 is not on Etherscan so you get a bare 4-byte selector. Use `explainRevert(err)`; if it
reports an unknown selector, run `npm run selectors` to regenerate against current contracts. Also
make sure you are simulating before sending — `simulateContract` is where you get the selector at
all.

**`MultiVault_HasCounterStake`.**
The address already holds the opposite side of that triple at that curve. Redeem the existing
position or use a different address. Expected behaviour, not a bug — surface it as a sentence.

**`MultiVault_InsufficientAssets` on creation.**
`msg.value` must equal `sum(assets[])` exactly, and each `assets[i]` must be at least the creation
cost. Read the cost at runtime; it is admin-settable.

**`MultiVault_DepositTooSmallToCoverMinShares` on a brand-new term.**
New vaults burn ghost shares at creation, so the first deposit must be larger than you would expect.
Raise the amount.

**`MultiVault_ArraysNotSameLength`.**
Creation is batch-only and every array argument must match length, `assets[]` included. There is no
single-item `createAtom()`.

**A `pure`/`view` read reverts with no message.**
Usually a wrong ABI signature — the selector does not exist, so there is nothing to decode and no
transaction to inspect. The classic on this contract is
`calculateCounterTripleId`, which takes **three atom ids**, not a triple id; the triple-id form is
`getCounterIdFromTripleId`. Check arity against `intuition-contracts-v2` before assuming the
function is missing from the deployment.

**Wallet connects but transactions fail immediately.**
Check the chain. Intuition is in no wallet's default list, so users need `wallet_addEthereumChain`
before `wallet_switchEthereumChain` will work. Then check balance — TRUST is the gas token, and a
zero balance produces an opaque failure. Testnet faucet:
`https://testnet.hub.intuition.systems/` (confirmed working, Jul 2026).

**Using `@0xintuition/sdk` instead of raw viem — two traps.**
This template deliberately uses raw viem, but if your project uses the official SDK: (1) the
SDK's `deposit()` wrapper **drops the `value` field**, so your stake silently deposits 0 — call
`multiVaultDeposit` from `@0xintuition/protocol` directly with
`{ args: [receiver, termId, curveId, minShares], value }`; (2) rich "Thing" atoms
(`createThing…`) require a `pinApiKey` for IPFS pinning and fail without one — URI-string atoms
via `createAtomFromString` need no key (see the canonical-URL pattern in `write-layer.md`). Both
verified on testnet against a production app.

**Numbers look absurdly large or lose precision.**
Share and asset values are wei-scale strings. `Number(bigString)` silently loses precision above
2^53. Divide in `BigInt` first: `Number(BigInt(v) / 10n ** 12n) / 1e6`.

**Stake succeeded but the UI shows the old number.**
The indexer runs a block or two behind the chain. Bump the value optimistically and re-fetch after a
few seconds; an immediate re-fetch returns the pre-transaction state and looks like a failure.

**The board is empty on first load.**
Usually a predicate ID that does not exist on this network. Set `VITE_PREDICATE_ID` to one that
does, or create it. Make the empty state say which predicate and which network it searched — see
`app-patterns.md`.

**Routes 404 after deploying.**
Missing SPA rewrite. `vercel.json` needs `{"rewrites": [{"source": "/(.*)", "destination":
"/index.html"}]}`; Netlify needs the equivalent `_redirects` line.

**`erasableSyntaxOnly` type errors on a class with parameter properties.**
New Vite TS templates enable it by default. Declare the field and assign it in the constructor body
instead of using a parameter property.

**Two chain objects from `defineChain` are "incompatible".**
`defineChain` infers literal types, so mainnet and testnet objects differ structurally on their URL
strings alone. Widen to viem's `Chain` where you hold both.

## When you are properly stuck

Get the selector — from the simulate error, or `cast call` the same args — and look it up in
`src/intuition/revert-selectors.json`. Confirm which network you are on and that your term IDs came
from that same network. Then read the term straight from the chain with `isTermCreated()` and
`getVault()`, bypassing the indexer entirely; that tells you whether the problem is on-chain state
or the read layer, which is the fork that matters.
