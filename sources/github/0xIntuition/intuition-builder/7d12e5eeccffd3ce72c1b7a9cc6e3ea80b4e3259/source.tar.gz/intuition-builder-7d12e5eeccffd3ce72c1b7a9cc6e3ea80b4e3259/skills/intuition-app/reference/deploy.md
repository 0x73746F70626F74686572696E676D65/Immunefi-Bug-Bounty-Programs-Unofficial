# Deploying

## Vercel

The scaffold is a static SPA — no server, no API routes.

1. Push to GitHub.
2. Import the repo in Vercel. Framework preset **Vite**; build `npm run build`; output `dist`.
3. Add environment variables (below).
4. Deploy.

**The SPA rewrite is not optional.** Without it, `/claim/0xabc…` 404s on refresh and on any shared
link — the routes work while you click around and break the moment anyone reloads, which is a
uniquely annoying bug to discover after launch. `vercel.json`:

```json
{
  "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }]
}
```

Netlify equivalent, in `public/_redirects`:

```
/*  /index.html  200
```

Cloudflare Pages: set the SPA fallback to `/index.html` in build settings.

## Environment variables

Everything reaching the browser must be prefixed `VITE_`, and everything prefixed `VITE_` **is
public** — it is inlined into the bundle at build time. Never put a private key, a pinning-service
secret, or any authenticated endpoint behind a `VITE_` name. If you need one, put it behind a
serverless function.

| Variable | Notes |
|---|---|
| `VITE_INTUITION_NETWORK` | `testnet` or `mainnet` |
| `VITE_INTUITION_RPC` | optional override |
| `VITE_INTUITION_GRAPHQL` | optional override |
| `VITE_MULTIVAULT` | optional override — differs per network |
| `VITE_PREDICATE_ID` | the predicate your app queries |

Set these per Vercel environment. A useful pattern: preview deployments on testnet, production on
mainnet, so a preview link can never move real value.

Vite only inlines env vars at build time, so changing one in the dashboard requires a redeploy.
Changing it and wondering why nothing happened is a rite of passage worth skipping.

## Before you point at mainnet

- `npm run doctor -- --network mainnet` passes cleanly.
- The MultiVault address is the mainnet one, and the RPC and GraphQL URLs are mainnet.
- `npm run selectors` regenerated against the contracts version actually deployed to mainnet, so
  your revert decoding is not describing a different deployment.
- Costs are read at runtime, not hardcoded from testnet values.
- Curve ID comes from `getBondingCurveConfig()`, not a literal.
- Every write path surfaces a decoded revert reason.
- Any demo or seed data is either removed or unmistakably labelled in the UI. If your app displays
  anything resembling a price, score, or probability about a named third party, this is a legal
  exposure, not a polish item.
- You have tested with a fresh wallet that has never seen the chain — that is the only way to
  exercise the `wallet_addEthereumChain` path your real first users will hit.

## Bundle size

viem is the bulk of it. It tree-shakes well; import narrowly (`import { keccak256 } from "viem"`)
rather than pulling namespaces. The scaffold builds to roughly 110 kB gzipped total, which is fine.
If you add wagmi and TanStack Query, expect to roughly double that.

## Custom domains

Standard Vercel domain flow. If you are running an Intuition-branded community app, prefer a
subdomain you control over anything that implies official status — and get sign-off before using
protocol branding.
