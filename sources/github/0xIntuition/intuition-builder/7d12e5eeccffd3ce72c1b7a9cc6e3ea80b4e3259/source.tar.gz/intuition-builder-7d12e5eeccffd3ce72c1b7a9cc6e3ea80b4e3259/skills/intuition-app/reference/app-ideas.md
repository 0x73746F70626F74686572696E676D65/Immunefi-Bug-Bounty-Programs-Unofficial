# What to build — app ideas mapped to primitives

Inspiration for builders, each idea reduced to its claim structure so you can start immediately.
The recurring lesson: the apps that only work on Intuition are the ones that make the
**counter-vault** load-bearing. If your idea works fine with likes and follows, you don't need a
knowledge graph. If it needs *priced disagreement*, nothing else has it.

Every idea below states its core triple. Predicates are your schema — see `app-patterns.md`.

## Trust & safety (counter-vault-native)

**Rug radar / doubt market.** Every protocol, vault, or token gets a live number: staked belief it
fails vs. holds. `[Entity] [operates without failure through] [Epoch]`. SAFE side earns from the
FAIL pool, FAIL side is priced protection. The counter-vault IS the product.

**Community notes for tokens.** A browser extension overlaying claims on Dexscreener/Uniswap:
"⚠ 62% of stake says this contract is a honeypot." `[Token] [is flagged as] [honeypot]` — the
counter-vault lets the project's defenders stake the other side, which no report-button system has.

**Audit registry with skin in the game.** `[Contract] [was audited by] [Firm]` — but anyone who
finds the audit shoddy stakes against. An audit badge that can be publicly shorted is a categorically
stronger signal than a PDF.

**Scam-address blocklist.** Crowd-staked `[Address] [is controlled by] [known scammer]`. Wallets
read consensus above a depth threshold. False accusations get counter-staked, which is precisely what
centralized blocklists can't offer.

## Reputation & curation

**KOL / caller scoreboard.** `[Account] [gave honest alpha in] [Period]` with both sides open.
Track-record claims where the audience prices the credibility instead of the influencer curating it.

**DAO delegate scorecards.** `[Delegate] [votes in the interest of] [DAO]`. Stake moves before
elections; a delegate with heavy counter-stake wears it publicly.

**Skill vouching for hiring.** `[Person] [is competent at] [Solidity]`, vouches staked by past
collaborators. Reputation portable across every app reading the graph — the whole point of a shared
substrate.

**Curated token/contract lists.** Registries where inclusion is staked, not admin'd:
`[Token] [belongs on] [Base bluechip list]`. Lists become markets; list quality becomes priceable.

## Content & community

**Conviction-ranked feeds.** Rank links/posts by staked TRUST rather than upvotes:
`[URL] [is worth reading about] [Topic]`. Sybil-resistant by construction — ranking costs capital,
not accounts.

**Locals Only pattern — gated geo/niche knowledge.** Spots, venues, servers, communities as
canonical-URL atoms (`https://yourapp/#/spot/…` — no pinning key needed; see `write-layer.md`),
access gated by stake or vouches. Proven in production at localsonly.tech.

**Prediction-adjacent claim markets.** Not full prediction markets (no settlement layer needed) —
persistent claims like `[Team] [ships] [Roadmap item]` where the ratio over time is the story.

## Infra & meta

**Sybil scoring from graph distance.** Score accounts by staked vouches from established atoms
rather than activity heuristics. Airdrop gating, allowlists, invite systems.

**Bug-report triage.** Protocols post bounties; reporters stake on `[Report] [is valid]`; triagers
counter-stake duplicates/noise. The queue self-sorts by capital-weighted confidence.

**Agent reputation.** As AI agents transact onchain: `[Agent] [acted within mandate in] [Epoch]`.
Same shape as the rug radar, pointed at agents — and the ERC-8004 direction the Intuition team is
already exploring.

## Picking one

Start with: whose disagreement is currently free, and what would change if it cost something? That
question generates most of the list above. Then check `app-patterns.md` for the build rules (never
render empty, suppress thin ratios, predicates-as-schema) and scaffold with the template — the
distance from idea to deployed testnet app is roughly an afternoon.
