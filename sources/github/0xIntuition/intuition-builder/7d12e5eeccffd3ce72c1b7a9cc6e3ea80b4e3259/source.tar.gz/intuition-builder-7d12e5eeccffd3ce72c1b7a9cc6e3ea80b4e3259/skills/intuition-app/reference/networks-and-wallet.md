# Networks and wallet

## Canonical config

| | Mainnet | Testnet |
|---|---|---|
| Chain ID | `1155` | `13579` |
| RPC | `https://rpc.intuition.systems/http` | `https://testnet.rpc.intuition.systems/http` |
| GraphQL | `https://mainnet.intuition.sh/v1/graphql` | `https://testnet.intuition.sh/v1/graphql` |
| MultiVault | `0x6E35cF57A41fA15eA0EaE9C33e751b01A784Fe7e` | `0x2Ece8D4dEdcB9918A398528f3fa4688b1d2CAB91` |
| Explorer | `https://explorer.intuition.systems` | `https://testnet.explorer.intuition.systems` |
| Faucet | — | `https://testnet.hub.intuition.systems/` |
| Bridge | `https://app.intuition.systems/bridge` | same |

Three traps in that table:

- **The `/http` suffix on RPC URLs is required.** Without it you get a 404 that looks like the node
  is down.
- **The MultiVault addresses differ between networks.** Mixing them up produces "no contract at
  that address", which reads like an RPC misconfiguration and sends people down the wrong path.
- **The docs list the testnet GraphQL URL for both PROD and DEV.** Use the mainnet URL above for
  mainnet; if it does not answer, the doctor will tell you.

Native currency is TRUST with 18 decimals on both networks — it is the gas token on the L3, not
an ERC-20 you approve. The ERC-20 TRUST on Base (`0x6cd905dF2Ed214b22e0d48FF17CD4200C1C6d8A3`) is
a different thing; do not use it for gas math.

## viem chain definition

```ts
import { defineChain } from "viem";

export const intuitionTestnet = defineChain({
  id: 13579,
  name: "Intuition Testnet",
  nativeCurrency: { name: "TRUST", symbol: "TRUST", decimals: 18 },
  rpcUrls: { default: { http: ["https://testnet.rpc.intuition.systems/http"] } },
  blockExplorers: {
    default: { name: "Blockscout", url: "https://testnet.explorer.intuition.systems" },
  },
  testnet: true,
});
```

A typing note that costs ten minutes: `defineChain` infers **literal** types for every string, so
`typeof intuitionMainnet` will reject the testnet object purely because its explorer URL differs.
If you hold both in one structure, widen to viem's `Chain`.

## Connecting

Intuition is not in any wallet's built-in network list, so **every first-run user needs the add
path.** Try switch, fall back to add — some wallets return 4902 for an unknown chain, others
return something non-standard, so branch on failure rather than on the error code.

```ts
async function ensureChain(eth) {
  const chainIdHex = `0x${(13579).toString(16)}`;
  try {
    await eth.request({ method: "wallet_switchEthereumChain", params: [{ chainId: chainIdHex }] });
  } catch {
    await eth.request({
      method: "wallet_addEthereumChain",
      params: [{
        chainId: chainIdHex,
        chainName: "Intuition Testnet",
        nativeCurrency: { name: "TRUST", symbol: "TRUST", decimals: 18 },
        rpcUrls: ["https://testnet.rpc.intuition.systems/http"],
        blockExplorerUrls: ["https://testnet.explorer.intuition.systems"],
      }],
    });
  }
}
```

Always `getAddress()` the account you get back from `eth_requestAccounts`. Wallets return
lowercase, the indexer stores checksummed, and normalising at the boundary saves you from the
zero-rows trap later.

## Why the template uses raw EIP-1193 rather than wagmi

Two honest reasons: the dependency surface stays small enough that a reader can hold the whole
data path in their head, and coding agents generate correct viem far more reliably than correct
wagmi, whose hook API has churned across majors. Nothing here is anti-wagmi.

## Migrating to wagmi

Straightforward — the chain object and ABI carry over unchanged.

```ts
import { createConfig, http } from "wagmi";
import { injected } from "wagmi/connectors";

export const config = createConfig({
  chains: [intuitionTestnet],
  connectors: [injected()],
  transports: { [intuitionTestnet.id]: http() },
});
```

Then `useReadContract` replaces `publicClient.readContract`, `useWriteContract` replaces
`walletClient.writeContract`, and `useSimulateContract` replaces `publicClient.simulateContract`.
Keep the simulate-before-send discipline; wagmi makes it easy to skip and you lose your only
pre-flight revert signal.

If you add wagmi, pin the major version in your prompt context — agents routinely mix v1 and v2
hook signatures, and the resulting code typechecks in neither.

## Account abstraction

Every atom has a deterministic ERC-4337 smart account (`AtomWallet`) derived from its ID, custodied
by `AtomWarden` until claimed. This matters if you are building something where atoms hold or route
funds — `atomWalletDepositFee` accrues to the wallet's owner as a claimable balance. It is not
needed for ordinary read/stake apps, and it is not the same thing as the user's wallet. See the
`intuition` skill for `computeAtomWalletAddr` and `claimAtomWalletDepositFees`.
