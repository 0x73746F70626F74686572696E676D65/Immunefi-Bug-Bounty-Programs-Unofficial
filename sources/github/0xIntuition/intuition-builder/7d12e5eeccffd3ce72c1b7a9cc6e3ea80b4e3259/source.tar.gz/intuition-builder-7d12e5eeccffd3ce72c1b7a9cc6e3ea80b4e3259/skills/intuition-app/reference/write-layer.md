# The write layer

For exact calldata, encoding rules and preview functions, defer to the `intuition` skill. This file
covers the *application* concerns around a write: sequencing, cost, failure, and what the user sees.

## Always simulate, then send

```ts
const { request } = await publicClient.simulateContract({
  address: multiVault, abi, functionName, args, value, account: address,
});
const hash = await walletClient.writeContract(request);
const receipt = await publicClient.waitForTransactionReceipt({ hash });
```

Simulating first is the only pre-flight signal you get. It surfaces the revert before the user pays
gas, and it hands you a selector you can decode into something readable. Skipping it is the single
biggest downgrade you can make to an Intuition app's UX.

## Creating atoms

Creation is **batch-only**. There is no `createAtom()`.

```ts
const cost = await read.atomCost();          // never hardcode
await createAtoms([data], [cost]);           // msg.value === sum(assets)
```

Three rules that trip people:

1. `assets[i]` is the **full payment** for item *i*. It must be at least the creation cost. Anything
   above the cost becomes your opening deposit into that new vault.
2. `msg.value` must **exactly** equal `sum(assets)`. Not more.
3. Every array argument must be the same length.

On atom data, there are two legitimate patterns — pick one deliberately:

1. **Rich metadata atoms**: pin a JSON document to IPFS and pass `ipfs://…`. Here the `intuition`
   skill's no-fallback rule applies in full — do not silently degrade to a plain string when
   pinning fails, because plain-string atoms create bare `TextObject` entries with no metadata and
   you cannot retrofit them. Surface the pinning failure to the user instead.
2. **Canonical-URL atoms**: pass an HTTPS URL *you control* as the atom data —
   `https://yourapp.example/#/thing/{id}` — and serve the rich content at that URL. No pinning
   service, no API key, and the atom's identity is a link that resolves to your app. This is a
   first-class pattern, not a degraded one: the URL *is* the identity, term IDs stay deterministic
   (`calculateAtomId(toHex(url))`), and metadata can evolve server-side without re-minting.
   localsonly.tech runs its entire spot graph this way. The trade-offs are honest ones: the data
   is only as permanent as your domain, and indexers can't enrich it the way they enrich pinned
   JSON schemas.

What is *not* acceptable is drifting between the two — deciding per-request based on whether
pinning happened to work. That is how you end up with half a graph in each scheme.

Before creating, derive the ID locally and check:

```ts
const id = calculateAtomId(data);
if (await read.isTermCreated(id)) return id;   // already exists, just use it
```

Check on-chain rather than via the indexer — the indexer lags by a block or two, which is enough to
produce a duplicate attempt and a confusing `MultiVault_AtomExists`.

## Creating triples

```ts
const cost = await read.tripleCost();
await createTriples([subjectId], [predicateId], [objectId], [cost]);
```

All three components must already exist as atoms. Creating a triple **also creates its
counter-triple vault** — you never create the counter side yourself, and attempting to initialise it
directly reverts with `MultiVault_CannotDirectlyInitializeCounterTriple`.

Triples can reference other triples as components (reification), which is how you make claims about
claims. Be aware that `isTriple()` returns true for counter-triples as well, so branch on
`getVaultType()` (`0=ATOM, 1=TRIPLE, 2=COUNTER_TRIPLE`) when you need to distinguish them.

## Staking, and staking against

```ts
const curveId = await read.defaultCurveId();     // from getBondingCurveConfig(), not a constant

// agree
await deposit(receiver, tripleId, curveId, minShares);          // value: amount

// disagree — identical call, counter id
await deposit(receiver, calculateCounterTripleId(tripleId), curveId, minShares);
```

This symmetry is the most useful thing about the protocol for application design, and it is
underexploited. Disagreement is a first-class position with its own vault, its own price, and its
own holders — you do not need to invent a downvote mechanism, and unlike a downvote it costs
something to express.

`MultiVault_HasCounterStake` reverts if the same address already holds the other side at that curve.
Catch it and explain it; do not let it surface as "transaction failed".

## Redeeming

```ts
const shares = await read.shares(account, termId, curveId);
await redeem(receiver, termId, curveId, shares, minAssets);
```

Read the share balance immediately before redeeming rather than caching it — entry and exit fees
accrue to remaining holders, so the balance drifts.

## Costs and fees

Read `getAtomCost()` and `getTripleCost()` at runtime. Both are admin-settable and both have
changed.

For what is actually charged on a deposit, use the protocol's **preview functions** rather than
computing from the fee config yourself. The fee stack — entry, exit, protocol, atom-deposit
fraction for triples, atom wallet fee — has threshold behaviour: several fees are not charged while
a vault is below `feeThreshold`. Deriving a number from the raw config will be wrong for exactly the
new vaults your users are most likely to touch first. The `intuition` skill covers the preview
functions in detail.

For UI purposes: show the preview output, label it as an estimate, and never present a hand-computed
fee as authoritative.

## Curves

`getBondingCurveConfig()` returns `(registry, defaultCurveId)`. Use the default. Registered curves
include a linear curve and progressive/offset-progressive curves whose share price rises as supply
grows; the offset variant shifts initial pricing.

A vault exists per `(term, curve)` pair, so a term can hold several independent books. Two
consequences for apps: filter vault arrays by `curve_id` rather than taking `vaults[0]`, and if you
let users choose a curve, remember that positions on different curves of the same term do not
combine.

## Delegation

`approve(address spender, uint8 approvalType)` with `0=NONE, 1=DEPOSIT, 2=REDEMPTION, 3=BOTH`.

The enum is bit-packed but the setter **overwrites** — calling with `1` and then `2` leaves you with
`REDEMPTION` only, not both. To grant both, pass `3`. This catches people who reason about it as
additive flags.

## Transaction UX that fits this chain

Blocks are ~2s with sub-10s finality, so a spinner-then-confirm flow feels fine and you rarely need
optimistic UI for correctness. What you do need:

- The decoded revert reason, in the interface, in plain language.
- An explorer link on success — `{explorer}/tx/{hash}`.
- A pre-flight balance check. TRUST is the gas token; a user with zero balance gets an opaque
  failure. On testnet, link the faucet at `https://testnet.hub.intuition.systems/` directly from
  the error state.
- Disabled buttons while a write is in flight, keyed per claim rather than globally, so one pending
  stake does not freeze the whole board.
