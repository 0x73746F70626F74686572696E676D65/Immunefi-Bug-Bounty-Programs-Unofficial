# Corrections and additions for `skills/intuition`

Found while building a two-sided claims market on Intuition testnet — an app where every claim has a live price on both the triple and its counter-triple. Used this skill throughout; it held up well. Everything below is at the edges.

Five items, in rough order of how much time each one costs a builder. The first is a silent
failure I hit while building an app on testnet; the last is a question plus an offer.

**Items 1–4 are applied in this PR** (3 files, +17/−5). Item 5 is a question I can't answer from
outside, with an offer attached.

Everything here is reproduced against testnet, not inferred from source. Happy to split into
separate PRs if that's easier to review.

---

## 1. Address queries use `_eq`, but the indexer stores addresses checksummed

`reference/graphql-queries.md` filters account queries with:

```graphql
positions(where: { account_id: { _eq: $accountId } }) { … }
```

There is no guidance anywhere in the repo on address casing — no `getAddress()`, no `toLowerCase()`,
no note. `_ilike` appears only as a label-search idiom.

The indexer stores addresses **checksummed**. `_eq` is case-sensitive. So a lowercase address —
which is exactly what `eth_requestAccounts` hands you, and what most people paste — matches nothing
and returns `[]`.

The failure mode is the problem: no error, no warning, just an empty array, which is
indistinguishable from "this account genuinely has no positions". Every downstream layer treats it
as valid data. I lost most of an afternoon to it before checking casing, and I've since seen the
same thing bite in a second codebase.

**Suggested change** — use `_ilike` in every address filter and add a callout:

```graphql
# Addresses are stored CHECKSUMMED. _eq with a lowercase address returns zero
# rows silently — use _ilike, or getAddress() the value before querying.
positions(where: { account_id: { _ilike: $accountId } }) { … }
```

**Reproduction.** I built a diagnostic that probes this against the live indexer — it pulls a real
`account_id` from `positions`, lowercases it, and runs the same filter both ways. Output against
testnet today (chain 13579):

```
Indexer
  ✔ reachable — https://testnet.intuition.sh/v1/graphql
  ✔ schema shape — hasura (snake_case, where/_ilike, limit) — matches intuition-rs

Address casing trap
  ✔ stored casing — CHECKSUMMED
  ! _eq with a lowercase address returns ZERO rows — silently, with no error
      → Always use _ilike for addresses, or getAddress() them first.
```

This PR rewrites the three `account_id: { _eq: … }` sites in `graphql-queries.md` to `_ilike` and
adds a callout above **Positions by Account**.

---

## 2. `MultiVault_HasCounterStake` is missing from the error table

The error table in `SKILL.md` documents seven errors. `intuition-contracts-v2` declares **32**
`MultiVault_*` errors (96 custom errors across all contracts).

Most of the gap is fine — nobody needs `MultiVault_BurnFromZeroAddress` in a skill. But
`MultiVault_HasCounterStake` is worth adding specifically, because it is the **first error any
app that uses the counter-vault will hit**, and the skill otherwise documents counter-triples very
well (invariant 12, `getCounterIdFromTripleId`, the `TripleConsensus` query, workflow #4). A
builder follows that guidance to stake on both sides, hits an undocumented revert, and has nothing
to search for.

```solidity
// MultiVault.sol:110
error MultiVault_HasCounterStake();
// MultiVault.sol:763
if (_hasCounterStake(termId, curveId, receiver)) revert MultiVault_HasCounterStake();
```

Suggested row:

> `MultiVault_HasCounterStake` — the address already holds shares on the opposite side of this
> triple at this curve. One address cannot hold both sides. Redeem the existing position first, or
> use a different address. Note the guard is per-address only.

Two others worth considering for the same reason:
`MultiVault_CannotDirectlyInitializeCounterTriple` and `MultiVault_DepositTooSmallToCoverMinShares`
(new vaults burn ghost shares, so the first deposit into a term has to be larger than expected —
this reads as a bug the first time you see it).

---

## 3. The counter-ID helpers are easy to call with the wrong arity

Not a bug in the skill, but a strong candidate for the invariants list, because I got it wrong even
after reading the counter-triple guidance — which is otherwise the clearest part of the skill.

```solidity
// takes the three ATOM ids
function calculateCounterTripleId(bytes32 subjectId, bytes32 predicateId, bytes32 objectId)

// takes a triple id — this is the one people actually want
function getCounterIdFromTripleId(bytes32 tripleId)
```

The intuitive guess is `calculateCounterTripleId(tripleId)`. That selector doesn't exist, so the
call reverts with nothing attached — and because it's a `pure` read there's no failed transaction
to inspect either.

I found this the honest way: my diagnostic called the one-argument form, got a bare revert, and I
assumed the deployment simply didn't expose the helper. It does — I had the arity wrong. It now
verifies both routes and they agree:

```
Term ID derivation
  ✔ calculateAtomId — local derivation matches the contract
  ✔ calculateTripleId — matches
  ✔ getCounterIdFromTripleId — matches
  ✔ calculateCounterTripleId — matches (takes 3 atom ids, not a triple id)
```

Since `getCounterIdFromTripleId` is already referenced in the skill, this PR adds a one-line note
next to it. Worth having because the counter-triple guidance is otherwise the clearest part of the
skill — I made this mistake *after* reading it carefully.

---

## 4. Broken link to the contracts repo

`SKILL.md` and `skills/intuition/README.md` both link to:

```
https://github.com/0xIntuition/intuition-v2/tree/main/contracts/core
```

That repo doesn't exist (404 / `git ls-remote` not found). The correct one appears to be
`0xIntuition/intuition-contracts-v2`, where the contracts live under `src/protocol/`.

---

## 5. Two pinned revert selectors don't reproduce from source — and an offer

`scripts/pass2-calldata-verification.sh` pins:

```
0xb4856ebc  MultiVault_AtomExists
0x4762af7d  MultiVault_TermDoesNotExist
```

Computing selectors from the error declarations in `intuition-contracts-v2` gives:

```
MultiVault_AtomExists(bytes)          0xe9ae238f
MultiVault_TermDoesNotExist(bytes32)  0x36559710
```

I couldn't reproduce either pinned value from any error signature in `intuition-contracts-v2` or
`intuition-beta-contracts` — including no-arg, `bytes32`, `string` and `MultiVaultCore_*` variants.

I'm assuming these came from a deployment predating both repos rather than that they're wrong, but
either way it's worth pinning down, because a stale selector decodes to a **confidently incorrect**
error name, which is worse for a debugging builder than no decode at all. Could you confirm which
contract version they're from?

**The offer:** since the L3 isn't on Etherscan, a bare 4-byte selector is all you get from a failed
transaction, and hand-maintaining a couple of them goes stale silently. I've written a generator
that clones `intuition-contracts-v2` at a given ref, extracts every `error` declaration, computes
the selector, and emits JSON with the source SHA recorded — currently 96 errors, zero collisions.

Happy to contribute it as `scripts/generate-selectors.mjs` plus
`reference/revert-selectors.json`, along with a short `reference/decoding-reverts.md`. It would
replace two hand-pinned values with a table that can be regenerated on every contracts release and
can't drift. Say the word and I'll open it as a separate PR.

---

## Context

Found while building an application on Intuition testnet using this skill. The transaction-encoding
guidance held up well — the always-pin-to-IPFS rule with no plain-string fallback, batch-only
creation, `msg.value == sum(assets[])`, and the counter-triple invariants all matched what I hit
in practice. Everything above is at the edges.

The diagnostic quoted throughout lives in a companion plugin I put together while doing this
(https://github.com/keegan-dotcom/intuition-builder): an app-layer skill covering the wallet/indexer/deploy surface this skill
explicitly scopes out, a working Vite + viem scaffold, `npm run doctor`, and the generated selector
table. MIT, and genuinely take any of it — including straight into this repo with no attribution.
Two notes from building it that may be useful regardless:

- The published GraphQL docs at `/developer-tools/graphql-api/overview` show TheGraph-style
  camelCase (`positiveVault`, `negativeVault`, `userPositions`, `first:`, `orderBy:`), which
  doesn't match the Hasura schema this skill's `graphql-queries.md` correctly uses. That mismatch
  sends people writing queries that error on documented fields — this skill is right and the docs
  page appears stale.
- `.claude-plugin/marketplace.json` here is in the skills.sh shape (`skills` array, no top-level
  `owner`, no `plugin.json`), so installation requires `npx skills add` plus `cast`/`jq`/`bc`.
  That works for Claude Code users with Foundry, but it means the skill can't be installed in
  Cowork at all. Adding a `plugin.json` and a Claude Code-shaped marketplace entry alongside the
  existing one is roughly ten lines and would open it to everyone building there. Happy to send
  that as its own PR if it's wanted.
