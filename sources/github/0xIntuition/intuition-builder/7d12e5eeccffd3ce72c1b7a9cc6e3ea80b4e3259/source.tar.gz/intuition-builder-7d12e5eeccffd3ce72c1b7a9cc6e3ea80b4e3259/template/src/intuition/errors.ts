import type { Hex } from "viem";
import SELECTORS from "./revert-selectors.json";

/**
 * Revert decoding.
 *
 * The Intuition L3 is not indexed by Etherscan, so a failed transaction gives
 * you a bare 4-byte selector and nothing else. Without a table, every revert
 * reads as "execution reverted (unknown custom error)" and you are guessing.
 *
 * `./revert-selectors.json` holds all 96 custom errors across the v2
 * contracts, generated from source by `npm run selectors`. Regenerate it
 * whenever the contracts move; the script pins the commit it read.
 */

interface ErrorEntry {
  name: string;
  canonical: string;
  selector: string;
}

const TABLE: Map<string, ErrorEntry> = new Map(
  (SELECTORS.errors as ErrorEntry[]).map((e) => [e.selector.toLowerCase(), e])
);

/** Plain-English guidance for the errors an app actually trips over. */
const HINTS: Record<string, string> = {
  MultiVault_HasCounterStake:
    "This address already holds shares on the OTHER side of this triple at this curve. " +
    "You cannot be long and short the same claim from one address. Redeem the existing " +
    "position first, or use a different address. Note this guard is per-address only — " +
    "it is a UX rail, not a guarantee of honest signalling.",
  MultiVault_CannotDirectlyInitializeCounterTriple:
    "The counter-triple vault cannot be the first vault created. Deposit into the positive " +
    "triple first; the counter vault is initialised alongside it at triple creation.",
  MultiVault_DepositBelowMinimumDeposit:
    "Your deposit is under the protocol minimum. Read the current minimum from the config " +
    "rather than hardcoding it — it is admin-settable.",
  MultiVault_DepositTooSmallToCoverMinShares:
    "The deposit is too small to mint the vault's minimum share amount. New vaults burn " +
    "'ghost shares' on creation, so the first deposit into a term must be larger than you expect.",
  MultiVault_AtomExists:
    "This atom already exists. Ids are deterministic — derive the id with calculateAtomId() " +
    "and check isTermCreated() before trying to create.",
  MultiVault_TripleExists:
    "This exact subject/predicate/object triple already exists. Deposit into it instead of creating it.",
  MultiVault_TermDoesNotExist:
    "No term at that id. Usually a wrong id derivation, or the term exists on the other network — " +
    "check you are pointed at the same chain your ids came from.",
  MultiVault_ArraysNotSameLength:
    "Creation is batch-only: every array argument must be the same length, including assets[].",
  MultiVault_InsufficientAssets:
    "msg.value must exactly equal sum(assets[]), and each assets[i] must cover the creation cost.",
  MultiVault_SlippageExceeded:
    "The vault moved between your preview and your send. Re-preview and retry, or widen minShares.",
  MultiVault_InvalidBondingCurveId:
    "That curveId is not registered. Read the default from getBondingCurveConfig() rather than " +
    "assuming 1.",
};

export interface DecodedRevert {
  selector: string;
  name?: string;
  canonical?: string;
  hint?: string;
}

/** Pull the 4-byte selector out of whatever shape the error arrived in. */
export function extractSelector(err: unknown): Hex | null {
  const hay = typeof err === "string" ? err : JSON.stringify(err ?? "");
  const m = hay.match(/0x[0-9a-fA-F]{8}(?![0-9a-fA-F])/);
  if (m) return m[0] as Hex;
  const long = hay.match(/0x[0-9a-fA-F]{8,}/);
  return long ? (long[0].slice(0, 10) as Hex) : null;
}

export function decodeRevert(err: unknown): DecodedRevert | null {
  const selector = extractSelector(err);
  if (!selector) return null;
  const hit = TABLE.get(selector.toLowerCase());
  if (!hit) return { selector };
  return { selector, name: hit.name, canonical: hit.canonical, hint: HINTS[hit.name] };
}

/** One-line message suitable for putting straight in the UI. */
export function explainRevert(err: unknown): string {
  const d = decodeRevert(err);
  if (!d) return "Transaction failed.";
  if (!d.name) {
    return `Transaction reverted with unknown custom error ${d.selector}. Run \`npm run selectors\` — the contracts may have moved since this table was generated.`;
  }
  return d.hint ? `${d.name}: ${d.hint}` : `${d.name} (${d.canonical})`;
}

export const ERROR_COUNT = (SELECTORS.errors as ErrorEntry[]).length;
