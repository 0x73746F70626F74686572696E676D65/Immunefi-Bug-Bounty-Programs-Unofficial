import {
  createPublicClient,
  createWalletClient,
  custom,
  http,
  getAddress,
  type Hex,
  type WalletClient,
} from "viem";
import { NETWORK, chainIdHex, network } from "./chains";
import { multiVaultAbi } from "./abi";
import { explainRevert } from "./errors";

/**
 * Wallet + chain wiring.
 *
 * Deliberately a thin EIP-1193 layer rather than wagmi. Two reasons: the
 * dependency surface stays small enough to read in one sitting, and agents
 * generate correct viem far more reliably than they generate correct wagmi
 * (whose hook API has churned across majors). If you want wagmi, everything
 * below maps onto it directly — see reference/networks-and-wallet.md.
 */

type Eip1193 = {
  request: (args: { method: string; params?: unknown[] }) => Promise<unknown>;
  on?: (e: string, cb: (...a: unknown[]) => void) => void;
  removeListener?: (e: string, cb: (...a: unknown[]) => void) => void;
};

declare global {
  interface Window {
    ethereum?: Eip1193;
  }
}

export const publicClient = createPublicClient({
  chain: network.chain,
  transport: http(),
});

export function getInjected(): Eip1193 | null {
  return typeof window !== "undefined" && window.ethereum ? window.ethereum : null;
}

/**
 * Add-then-switch, in that order, with the add as the fallback.
 *
 * `wallet_switchEthereumChain` throws 4902 for an unknown chain, and some
 * wallets throw a non-standard code instead — so we just try switch, and add
 * on any failure. Intuition is not in any wallet's default list, so a first-run
 * user ALWAYS needs the add path.
 */
export async function ensureChain(eth: Eip1193) {
  try {
    await eth.request({ method: "wallet_switchEthereumChain", params: [{ chainId: chainIdHex }] });
  } catch {
    await eth.request({
      method: "wallet_addEthereumChain",
      params: [
        {
          chainId: chainIdHex,
          chainName: network.chain.name,
          nativeCurrency: network.chain.nativeCurrency,
          rpcUrls: network.chain.rpcUrls.default.http,
          blockExplorerUrls: [network.chain.blockExplorers!.default.url],
        },
      ],
    });
  }
}

export async function connect(): Promise<{ address: Hex; wallet: WalletClient } | null> {
  const eth = getInjected();
  if (!eth) return null;
  const accounts = (await eth.request({ method: "eth_requestAccounts" })) as string[];
  if (!accounts?.length) return null;
  await ensureChain(eth);
  const address = getAddress(accounts[0]);
  const wallet = createWalletClient({ account: address, chain: network.chain, transport: custom(eth) });
  return { address, wallet };
}

/* -------------------------------------------------------------------------- */
/* Reads                                                                       */
/* -------------------------------------------------------------------------- */

export const read = {
  atomCost: () =>
    publicClient.readContract({
      address: network.multiVault,
      abi: multiVaultAbi,
      functionName: "getAtomCost",
    }),
  tripleCost: () =>
    publicClient.readContract({
      address: network.multiVault,
      abi: multiVaultAbi,
      functionName: "getTripleCost",
    }),
  /** Never hardcode curve 1 — read the default and reuse it. */
  defaultCurveId: async () => {
    const [, curveId] = await publicClient.readContract({
      address: network.multiVault,
      abi: multiVaultAbi,
      functionName: "getBondingCurveConfig",
    });
    return curveId;
  },
  isTermCreated: (termId: Hex) =>
    publicClient.readContract({
      address: network.multiVault,
      abi: multiVaultAbi,
      functionName: "isTermCreated",
      args: [termId],
    }),
  shares: (account: Hex, termId: Hex, curveId: bigint) =>
    publicClient.readContract({
      address: network.multiVault,
      abi: multiVaultAbi,
      functionName: "getShares",
      args: [account, termId, curveId],
    }),
  vault: (termId: Hex, curveId: bigint) =>
    publicClient.readContract({
      address: network.multiVault,
      abi: multiVaultAbi,
      functionName: "getVault",
      args: [termId, curveId],
    }),
};

/* -------------------------------------------------------------------------- */
/* Writes                                                                      */
/* -------------------------------------------------------------------------- */

export class IntuitionTxError extends Error {
  /** Declared explicitly rather than as a parameter property — TS's
   *  `erasableSyntaxOnly` (on by default in new Vite templates) rejects those. */
  readonly reason: unknown;
  constructor(message: string, reason: unknown) {
    super(message);
    this.name = "IntuitionTxError";
    this.reason = reason;
  }
}

/** Simulate → send → wait, with the revert decoded into something readable. */
async function send(
  wallet: WalletClient,
  address: Hex,
  functionName: string,
  args: readonly unknown[],
  value: bigint
) {
  try {
    const { request } = await publicClient.simulateContract({
      address: network.multiVault,
      abi: multiVaultAbi,
      functionName: functionName as never,
      args: args as never,
      value,
      account: address,
    });
    const hash = await wallet.writeContract(request);
    return await publicClient.waitForTransactionReceipt({ hash });
  } catch (err) {
    throw new IntuitionTxError(explainRevert(err), err);
  }
}

/**
 * Create one atom.
 *
 * Creation is batch-only on-chain — there is no createAtom(). This wraps the
 * single-element-array case, which is what apps almost always want.
 *
 * `assets` is the FULL payment for that atom: it must be >= the creation cost,
 * and msg.value must equal the sum across the batch. The remainder above the
 * creation cost becomes your opening deposit into the new atom's vault.
 */
export async function createAtom(
  wallet: WalletClient,
  address: Hex,
  data: Hex,
  assets?: bigint
) {
  const cost = assets ?? (await read.atomCost());
  return send(wallet, address, "createAtoms", [[data], [cost]], cost);
}

export async function createTriple(
  wallet: WalletClient,
  address: Hex,
  subject: Hex,
  predicate: Hex,
  object: Hex,
  assets?: bigint
) {
  const cost = assets ?? (await read.tripleCost());
  return send(wallet, address, "createTriples", [[subject], [predicate], [object], [cost]], cost);
}

/**
 * Stake on a term.
 *
 * To signal DISAGREEMENT with a claim, pass the counter-triple id — the counter
 * vault is created automatically alongside the triple. Use
 * `calculateCounterTripleId()` from ./ids to derive it locally.
 *
 * One address cannot hold both sides of the same triple at the same curve;
 * that reverts with MultiVault_HasCounterStake, which ./errors explains.
 */
export async function stake(
  wallet: WalletClient,
  address: Hex,
  termId: Hex,
  amount: bigint,
  curveId: bigint,
  minShares = 0n
) {
  return send(wallet, address, "deposit", [address, termId, curveId, minShares], amount);
}

export async function unstake(
  wallet: WalletClient,
  address: Hex,
  termId: Hex,
  shares: bigint,
  curveId: bigint,
  minAssets = 0n
) {
  return send(wallet, address, "redeem", [address, termId, curveId, shares, minAssets], 0n);
}

export const explorerTx = (hash: string) =>
  `${network.chain.blockExplorers!.default.url}/tx/${hash}`;

export const CURRENT_NETWORK = NETWORK;
