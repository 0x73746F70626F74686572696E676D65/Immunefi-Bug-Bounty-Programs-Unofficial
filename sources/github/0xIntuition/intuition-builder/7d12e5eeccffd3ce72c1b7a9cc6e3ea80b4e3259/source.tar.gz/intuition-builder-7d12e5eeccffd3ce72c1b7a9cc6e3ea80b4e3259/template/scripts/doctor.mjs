#!/usr/bin/env node
/**
 * intuition doctor
 *
 * Diagnoses an Intuition app environment end to end and tells you exactly what
 * to fix. Run it before you debug anything else.
 *
 *   npm run doctor
 *   npm run doctor -- --network mainnet
 *
 * It answers the questions that otherwise cost you an afternoon:
 *   - is the RPC actually up, and is it the chain I think it is?
 *   - is there code at the MultiVault address I'm using?
 *   - does my LOCAL id derivation match the contract's own pure functions?
 *   - which GraphQL schema shape does this indexer really speak?
 *   - does `_eq` on an address silently return zero rows here?
 *
 * Exit code 0 if everything critical passes, 1 otherwise — so it works in CI.
 */

import { createPublicClient, http, defineChain, keccak256, encodePacked, toHex } from "viem";
import { readFileSync, existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

/* ---------- tiny .env reader (no dependency) ---------- */
function loadEnv() {
  for (const f of [".env.local", ".env"]) {
    const p = join(root, f);
    if (!existsSync(p)) continue;
    for (const line of readFileSync(p, "utf8").split("\n")) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
      if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
    }
  }
}
loadEnv();

const argNetwork = process.argv.includes("--network")
  ? process.argv[process.argv.indexOf("--network") + 1]
  : null;
const NETWORK = argNetwork ?? process.env.VITE_INTUITION_NETWORK ?? "testnet";

const NETWORKS = {
  mainnet: {
    id: 1155,
    rpc: "https://rpc.intuition.systems/http",
    multiVault: "0x6E35cF57A41fA15eA0EaE9C33e751b01A784Fe7e",
    graphql: "https://mainnet.intuition.sh/v1/graphql",
    explorer: "https://explorer.intuition.systems",
  },
  testnet: {
    id: 13579,
    rpc: "https://testnet.rpc.intuition.systems/http",
    multiVault: "0x2Ece8D4dEdcB9918A398528f3fa4688b1d2CAB91",
    graphql: "https://testnet.intuition.sh/v1/graphql",
    explorer: "https://testnet.explorer.intuition.systems",
    faucet: "https://testnet.hub.intuition.systems/",
  },
};

const cfg = NETWORKS[NETWORK];
if (!cfg) {
  console.error(`Unknown network "${NETWORK}". Use mainnet or testnet.`);
  process.exit(1);
}

const rpcUrl = process.env.VITE_INTUITION_RPC || cfg.rpc;
const graphqlUrl = process.env.VITE_INTUITION_GRAPHQL || cfg.graphql;
const multiVault = process.env.VITE_MULTIVAULT || cfg.multiVault;

/* ---------- output ---------- */
const C = {
  dim: (s) => `\x1b[2m${s}\x1b[0m`,
  bold: (s) => `\x1b[1m${s}\x1b[0m`,
  green: (s) => `\x1b[32m${s}\x1b[0m`,
  red: (s) => `\x1b[31m${s}\x1b[0m`,
  yellow: (s) => `\x1b[33m${s}\x1b[0m`,
  cyan: (s) => `\x1b[36m${s}\x1b[0m`,
};

let failures = 0;
let warnings = 0;
const line = (icon, label, detail) =>
  console.log(`  ${icon} ${label}${detail ? C.dim(` — ${detail}`) : ""}`);
const ok = (l, d) => line(C.green("✔"), l, d);
const bad = (l, d) => {
  failures++;
  line(C.red("✘"), l, d);
};
const warn = (l, d) => {
  warnings++;
  line(C.yellow("!"), l, d);
};
const fix = (s) => console.log(`      ${C.cyan("→")} ${C.dim(s)}`);
const section = (s) => console.log(`\n${C.bold(s)}`);

console.log(`\n${C.bold("intuition doctor")} ${C.dim(`· ${NETWORK}`)}`);

/* ---------- 1. config ---------- */
section("Configuration");
ok("network", `${NETWORK} (chain id ${cfg.id})`);
ok("rpc", rpcUrl);
ok("graphql", graphqlUrl);
if (multiVault.toLowerCase() !== cfg.multiVault.toLowerCase()) {
  warn("multiVault", `overridden to ${multiVault}, canonical is ${cfg.multiVault}`);
} else {
  ok("multiVault", multiVault);
}
if (!existsSync(join(root, ".env.local"))) {
  warn(".env.local", "not found — using defaults");
  fix("cp .env.example .env.local");
}

const chain = defineChain({
  id: cfg.id,
  name: `Intuition ${NETWORK}`,
  nativeCurrency: { name: "TRUST", symbol: "TRUST", decimals: 18 },
  rpcUrls: { default: { http: [rpcUrl] } },
});
const client = createPublicClient({ chain, transport: http(rpcUrl, { timeout: 15_000 }) });

/* ---------- 2. rpc ---------- */
section("RPC");
let rpcUp = false;
try {
  const id = await client.getChainId();
  if (id !== cfg.id) {
    bad("chain id", `RPC reports ${id}, expected ${cfg.id}`);
    fix("Your RPC URL points at a different network than VITE_INTUITION_NETWORK.");
  } else {
    ok("chain id", String(id));
    rpcUp = true;
  }
  const block = await client.getBlockNumber();
  ok("head block", String(block));
} catch (e) {
  bad("unreachable", String(e.message ?? e).split("\n")[0]);
  fix(`Check the /http suffix — it is ${cfg.rpc}, not ${cfg.rpc.replace("/http", "")}.`);
  fix("If you are inside a sandbox or corporate proxy, this host may be blocked outright.");
}

/* ---------- 3. contract ---------- */
const abi = [
  { type: "function", name: "getAtomCost", stateMutability: "view", inputs: [], outputs: [{ type: "uint256" }] },
  { type: "function", name: "getTripleCost", stateMutability: "view", inputs: [], outputs: [{ type: "uint256" }] },
  {
    type: "function",
    name: "getBondingCurveConfig",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "address" }, { type: "uint256" }],
  },
  {
    type: "function",
    name: "calculateAtomId",
    stateMutability: "pure",
    inputs: [{ name: "data", type: "bytes" }],
    outputs: [{ type: "bytes32" }],
  },
  {
    type: "function",
    name: "calculateTripleId",
    stateMutability: "pure",
    inputs: [{ type: "bytes32" }, { type: "bytes32" }, { type: "bytes32" }],
    outputs: [{ type: "bytes32" }],
  },
  // NOTE the arity: calculateCounterTripleId takes the three ATOM ids, not a
  // triple id. The triple-id form is getCounterIdFromTripleId. Guessing the
  // obvious signature produces a selector that does not exist and a revert
  // with no useful message.
  {
    type: "function",
    name: "calculateCounterTripleId",
    stateMutability: "pure",
    inputs: [{ type: "bytes32" }, { type: "bytes32" }, { type: "bytes32" }],
    outputs: [{ type: "bytes32" }],
  },
  {
    type: "function",
    name: "getCounterIdFromTripleId",
    stateMutability: "pure",
    inputs: [{ type: "bytes32" }],
    outputs: [{ type: "bytes32" }],
  },
];

let curveId = null;
if (rpcUp) {
  section("MultiVault");
  try {
    const code = await client.getCode({ address: multiVault });
    if (!code || code === "0x") {
      bad("bytecode", "no contract at that address on this chain");
      fix("Mainnet and testnet have DIFFERENT MultiVault addresses. Check you did not copy one into the other.");
    } else {
      ok("bytecode", `${(code.length / 2 - 1).toLocaleString()} bytes`);
      const [atomCost, tripleCost, curveCfg] = await Promise.all([
        client.readContract({ address: multiVault, abi, functionName: "getAtomCost" }),
        client.readContract({ address: multiVault, abi, functionName: "getTripleCost" }),
        client.readContract({ address: multiVault, abi, functionName: "getBondingCurveConfig" }),
      ]);
      ok("atom cost", `${Number(atomCost) / 1e18} TRUST`);
      ok("triple cost", `${Number(tripleCost) / 1e18} TRUST`);
      curveId = curveCfg[1];
      ok("default curve", `${curveId} ${C.dim(`(registry ${curveCfg[0]})`)}`);
    }
  } catch (e) {
    bad("read failed", String(e.shortMessage ?? e.message ?? e).split("\n")[0]);
  }

  /* ---------- 4. the important one: local id derivation ---------- */
  section("Term ID derivation");
  const ATOM_SALT = keccak256(toHex("ATOM_SALT"));
  const TRIPLE_SALT = keccak256(toHex("TRIPLE_SALT"));
  const COUNTER_SALT = keccak256(toHex("COUNTER_SALT"));
  const sample = toHex("ipfs://bafkreidoctorprobe");

  const localAtom = keccak256(encodePacked(["bytes32", "bytes32"], [ATOM_SALT, keccak256(sample)]));
  try {
    const chainAtom = await client.readContract({
      address: multiVault,
      abi,
      functionName: "calculateAtomId",
      args: [sample],
    });
    if (chainAtom.toLowerCase() === localAtom.toLowerCase()) {
      ok("calculateAtomId", "local derivation matches the contract");
    } else {
      bad("calculateAtomId", `local ${localAtom} != chain ${chainAtom}`);
      fix("The salt or packing changed. Do not derive ids locally until src/intuition/ids.ts is updated.");
    }

    const a = localAtom;
    const b = keccak256(encodePacked(["bytes32", "bytes32"], [ATOM_SALT, keccak256(toHex("b"))]));
    const c = keccak256(encodePacked(["bytes32", "bytes32"], [ATOM_SALT, keccak256(toHex("c"))]));
    const localTriple = keccak256(
      encodePacked(["bytes32", "bytes32", "bytes32", "bytes32"], [TRIPLE_SALT, a, b, c])
    );
    const chainTriple = await client.readContract({
      address: multiVault,
      abi,
      functionName: "calculateTripleId",
      args: [a, b, c],
    });
    localTriple.toLowerCase() === chainTriple.toLowerCase()
      ? ok("calculateTripleId", "matches")
      : bad("calculateTripleId", `local ${localTriple} != chain ${chainTriple}`);

    const localCounter = keccak256(
      encodePacked(["bytes32", "bytes32"], [COUNTER_SALT, localTriple])
    );

    // Two independent paths to the same counter id — verify both, because the
    // naming is easy to get backwards and each catches a different mistake.
    const chainCounterFromTriple = await client.readContract({
      address: multiVault,
      abi,
      functionName: "getCounterIdFromTripleId",
      args: [localTriple],
    });
    localCounter.toLowerCase() === chainCounterFromTriple.toLowerCase()
      ? ok("getCounterIdFromTripleId", "matches")
      : bad("getCounterIdFromTripleId", `local ${localCounter} != chain ${chainCounterFromTriple}`);

    const chainCounterFromAtoms = await client.readContract({
      address: multiVault,
      abi,
      functionName: "calculateCounterTripleId",
      args: [a, b, c],
    });
    localCounter.toLowerCase() === chainCounterFromAtoms.toLowerCase()
      ? ok("calculateCounterTripleId", `matches ${C.dim("(takes 3 atom ids, not a triple id)")}`)
      : bad("calculateCounterTripleId", `local ${localCounter} != chain ${chainCounterFromAtoms}`);
  } catch (e) {
    warn("could not verify against chain", String(e.shortMessage ?? e.message ?? e).split("\n")[0]);
    fix("The pure id helpers may not be exposed on this deployment. Local derivation is unverified.");
  }
}

/* ---------- 5. graphql ---------- */
section("Indexer");
async function gql(query, variables) {
  const res = await fetch(graphqlUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query, variables }),
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

let shape = null;
try {
  const hasura = await gql(`{ atoms(limit: 1) { term_id label } }`, {});
  if (!hasura.errors && hasura.data?.atoms) {
    shape = "hasura";
    ok("reachable", graphqlUrl);
    ok("schema shape", `hasura (snake_case, where/_ilike, limit) ${C.dim("— matches intuition-rs")}`);
  } else {
    const sub = await gql(`{ atoms(first: 1) { id uri } }`, {});
    if (!sub.errors && sub.data?.atoms) {
      shape = "subgraph";
      ok("reachable", graphqlUrl);
      warn("schema shape", "subgraph (camelCase, first/orderBy) — the docs shape, not intuition-rs");
      fix("src/intuition/graphql.ts handles both. Nothing to change, but note which one you got.");
    } else {
      bad("no known schema shape answered", hasura.errors?.[0]?.message ?? "unknown");
      fix("Open the endpoint in a GraphQL playground and add the real shape to CLAIM candidates.");
    }
  }
} catch (e) {
  bad("unreachable", String(e.message ?? e).split("\n")[0]);
  fix("If you are in a sandbox, *.intuition.sh may be proxy-blocked. Try from your own machine.");
}

/* ---------- 6. the checksum trap ---------- */
if (shape === "hasura") {
  section("Address casing trap");
  try {
    const probe = await gql(`{ positions(limit: 1) { account_id term_id } }`, {});
    const acct = probe.data?.positions?.[0]?.account_id;
    if (!acct) {
      warn("no positions indexed", "cannot probe — skipping");
    } else {
      const lower = acct.toLowerCase();
      const isChecksummed = acct !== lower;
      const eq = await gql(
        `query($a: String!) { positions(where: { account_id: { _eq: $a } }, limit: 1) { term_id } }`,
        { a: lower }
      );
      const ilike = await gql(
        `query($a: String!) { positions(where: { account_id: { _ilike: $a } }, limit: 1) { term_id } }`,
        { a: lower }
      );
      const eqRows = eq.data?.positions?.length ?? 0;
      const ilikeRows = ilike.data?.positions?.length ?? 0;

      ok("stored casing", isChecksummed ? "CHECKSUMMED" : "lowercase");
      if (eqRows === 0 && ilikeRows > 0) {
        warn("_eq with a lowercase address returns ZERO rows", "silently, with no error");
        fix("Always use _ilike for addresses, or getAddress() them first. This is the single most");
        fix("common cause of 'my positions query returns nothing' on Intuition.");
      } else if (eqRows > 0) {
        ok("_eq with lowercase", "works on this indexer");
      }
    }
  } catch (e) {
    warn("probe failed", String(e.message ?? e).split("\n")[0]);
  }
}

/* ---------- 7. wallet ---------- */
if (rpcUp && process.env.SEED_PRIVATE_KEY) {
  section("Wallet");
  try {
    const { privateKeyToAccount } = await import("viem/accounts");
    const acct = privateKeyToAccount(process.env.SEED_PRIVATE_KEY);
    const bal = await client.getBalance({ address: acct.address });
    const trust = Number(bal) / 1e18;
    ok("address", acct.address);
    if (trust === 0) {
      bad("balance", "0 TRUST — cannot send transactions");
      if (cfg.faucet) fix(`Faucet: ${cfg.faucet}`);
    } else if (trust < 0.05) {
      warn("balance", `${trust} TRUST — low`);
      if (cfg.faucet) fix(`Faucet: ${cfg.faucet}`);
    } else {
      ok("balance", `${trust} TRUST`);
    }
  } catch (e) {
    bad("bad SEED_PRIVATE_KEY", String(e.message ?? e).split("\n")[0]);
  }
}

/* ---------- summary ---------- */
console.log();
if (failures === 0 && warnings === 0) {
  console.log(C.green(C.bold("  All checks passed.")), C.dim("You are clear to build."));
} else if (failures === 0) {
  console.log(
    C.yellow(C.bold(`  ${warnings} warning${warnings === 1 ? "" : "s"}, no failures.`)),
    C.dim("Safe to proceed.")
  );
} else {
  console.log(
    C.red(C.bold(`  ${failures} failure${failures === 1 ? "" : "s"}`)),
    C.dim(`${warnings} warning${warnings === 1 ? "" : "s"}`)
  );
}
console.log();
process.exit(failures === 0 ? 0 : 1);
