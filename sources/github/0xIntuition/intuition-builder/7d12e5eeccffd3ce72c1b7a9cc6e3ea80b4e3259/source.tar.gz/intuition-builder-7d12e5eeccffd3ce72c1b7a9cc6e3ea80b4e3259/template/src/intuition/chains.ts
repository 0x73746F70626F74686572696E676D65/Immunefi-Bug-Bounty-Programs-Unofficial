import { defineChain, type Chain } from "viem";

/**
 * Canonical network config.
 *
 * Source: 0xIntuition/agent-skills → skills/intuition/reference/network-config.md
 * Cross-checked against docs.intuition.systems/docs/intuition-network.
 *
 * Note the `/http` suffix on the RPC URLs — omitting it is a common 404.
 */

export const intuitionMainnet = defineChain({
  id: 1155,
  name: "Intuition",
  nativeCurrency: { name: "TRUST", symbol: "TRUST", decimals: 18 },
  rpcUrls: { default: { http: ["https://rpc.intuition.systems/http"] } },
  blockExplorers: {
    default: { name: "Blockscout", url: "https://explorer.intuition.systems" },
  },
});

export const intuitionTestnet = defineChain({
  id: 13579,
  name: "Intuition Testnet",
  nativeCurrency: { name: "TRUST", symbol: "TRUST", decimals: 18 },
  rpcUrls: { default: { http: ["https://testnet.rpc.intuition.systems/http"] } },
  blockExplorers: {
    default: { name: "Blockscout", url: "https://testnet.explorer.intuition.systems" },
  },
  testnet: true,
});

export interface NetworkConfig {
  /** Widened deliberately: mainnet and testnet are structurally identical but
   *  `defineChain` infers literal types, so `typeof intuitionMainnet` would
   *  reject the testnet object on its explorer URL alone. */
  chain: Chain;
  multiVault: `0x${string}`;
  graphql: string;
  faucet?: string;
  bridge?: string;
}

export const NETWORKS: Record<"mainnet" | "testnet", NetworkConfig> = {
  mainnet: {
    chain: intuitionMainnet,
    multiVault: "0x6E35cF57A41fA15eA0EaE9C33e751b01A784Fe7e",
    graphql: "https://mainnet.intuition.sh/v1/graphql",
    bridge: "https://app.intuition.systems/bridge",
  },
  testnet: {
    chain: intuitionTestnet,
    multiVault: "0x2Ece8D4dEdcB9918A398528f3fa4688b1d2CAB91",
    graphql: "https://testnet.intuition.sh/v1/graphql",
    faucet: "https://testnet.hub.intuition.systems/",
    bridge: "https://app.intuition.systems/bridge",
  },
};

export type NetworkName = keyof typeof NETWORKS;

export const NETWORK: NetworkName =
  (import.meta.env?.VITE_INTUITION_NETWORK as NetworkName) ?? "testnet";

export const network = NETWORKS[NETWORK];

/** Chain id as the 0x-prefixed hex string `wallet_switchEthereumChain` wants. */
export const chainIdHex = `0x${network.chain.id.toString(16)}` as const;
