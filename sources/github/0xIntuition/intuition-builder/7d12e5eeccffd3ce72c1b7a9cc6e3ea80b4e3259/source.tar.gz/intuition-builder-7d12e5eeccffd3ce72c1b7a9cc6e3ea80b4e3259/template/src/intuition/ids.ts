import { keccak256, encodePacked, toHex, type Hex } from "viem";

/**
 * Local term-ID derivation.
 *
 * Every id in Intuition v2 is a bytes32 derived deterministically, so you can
 * compute it BEFORE sending a transaction — which means you can check whether a
 * term already exists, build a link to it, or look it up in the indexer without
 * spending gas. Almost nothing documents this, so most apps round-trip to the
 * chain for something that is three lines of keccak256.
 *
 * Verified against intuition-contracts-v2, src/protocol/MultiVaultCore.sol:
 *
 *   ATOM_SALT    = keccak256("ATOM_SALT")
 *   TRIPLE_SALT  = keccak256("TRIPLE_SALT")
 *   COUNTER_SALT = keccak256("COUNTER_SALT")
 *
 *   _calculateAtomId(data)        = keccak256(abi.encodePacked(ATOM_SALT, keccak256(data)))
 *   _calculateTripleId(s, p, o)   = keccak256(abi.encodePacked(TRIPLE_SALT, s, p, o))
 *   _calculateCounterTripleId(id) = keccak256(abi.encodePacked(COUNTER_SALT, id))
 *
 * `npm run doctor` re-derives these against the deployed contract's pure
 * functions and fails loudly if they ever diverge. Trust the doctor over this
 * comment.
 */

export const ATOM_SALT = keccak256(toHex("ATOM_SALT"));
export const TRIPLE_SALT = keccak256(toHex("TRIPLE_SALT"));
export const COUNTER_SALT = keccak256(toHex("COUNTER_SALT"));

/** `data` is the raw atom bytes — usually `toHex("ipfs://…")`. */
export function calculateAtomId(data: Hex): Hex {
  return keccak256(encodePacked(["bytes32", "bytes32"], [ATOM_SALT, keccak256(data)]));
}

export function atomIdFromUri(uri: string): Hex {
  return calculateAtomId(toHex(uri));
}

export function calculateTripleId(subject: Hex, predicate: Hex, object: Hex): Hex {
  return keccak256(
    encodePacked(["bytes32", "bytes32", "bytes32", "bytes32"], [TRIPLE_SALT, subject, predicate, object])
  );
}

export function calculateCounterTripleId(tripleId: Hex): Hex {
  return keccak256(encodePacked(["bytes32", "bytes32"], [COUNTER_SALT, tripleId]));
}

/** Both sides of a claim in one call — the shape most apps actually want. */
export function claimIds(subject: Hex, predicate: Hex, object: Hex) {
  const tripleId = calculateTripleId(subject, predicate, object);
  return { tripleId, counterTripleId: calculateCounterTripleId(tripleId) };
}
