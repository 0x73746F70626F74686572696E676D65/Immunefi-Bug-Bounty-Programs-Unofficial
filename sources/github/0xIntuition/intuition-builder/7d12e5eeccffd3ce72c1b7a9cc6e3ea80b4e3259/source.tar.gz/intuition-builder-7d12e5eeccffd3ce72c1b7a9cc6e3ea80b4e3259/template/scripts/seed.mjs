#!/usr/bin/env node
/**
 * intuition seed
 *
 * Mints the demo predicate and a few example claims so the starter board is
 * never empty. Idempotent: every id is derived locally and checked on-chain
 * with isTermCreated() before anything is sent, so re-running skips what
 * already exists.
 *
 *   SEED_PRIVATE_KEY=0x… npm run seed
 *   SEED_PRIVATE_KEY=0x… npm run seed -- --network testnet
 *
 * The key needs a little TRUST for gas + creation costs (testnet faucet:
 * https://testnet.hub.intuition.systems/). The key is read from the
 * environment only — never commit it, and never put it in a VITE_ variable.
 */

import {
  createPublicClient,
  createWalletClient,
  http,
  defineChain,
  keccak256,
  encodePacked,
  toHex,
  formatEther,
} from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { readFileSync, existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

/* ---------- tiny .env reader (same as doctor) ---------- */
for (const f of [".env.local", ".env"]) {
  const p = join(root, f);
  if (!existsSync(p)) continue;
  for (const line of readFileSync(p, "utf8").split("\n")) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
}

const argNetwork = process.argv.includes("--network")
  ? process.argv[process.argv.indexOf("--network") + 1]
  : null;
const NETWORK = argNetwork ?? process.env.VITE_INTUITION_NETWORK ?? "testnet";

const NETWORKS = {
  mainnet: {
    id: 1155,
    rpc: "https://rpc.intuition.systems/http",
    multiVault: "0x6E35cF57A41fA15eA0EaE9C33e751b01A784Fe7e",
    explorer: "https://explorer.intuition.systems",
  },
  testnet: {
    id: 13579,
    rpc: "https://testnet.rpc.intuition.systems/http",
    multiVault: "0x2Ece8D4dEdcB9918A398528f3fa4688b1d2CAB91",
    explorer: "https://testnet.explorer.intuition.systems",
  },
};
const cfg = NETWORKS[NETWORK];
if (!cfg) {
  console.error(`Unknown network "${NETWORK}". Use mainnet or testnet.`);
  process.exit(1);
}
if (NETWORK === "mainnet") {
  console.error("Refusing to seed demo data on mainnet. Pass --network testnet (or nothing).");
  process.exit(1);
}

const pk = process.env.SEED_PRIVATE_KEY;
if (!pk || !/^0x[0-9a-fA-F]{64}$/.test(pk)) {
  console.error("Set SEED_PRIVATE_KEY=0x… (a funded testnet key). It is read from env only.");
  process.exit(1);
}

/* ---------- what we seed ---------- */
// The predicate matches the App.tsx default (atomIdFromUri("ipfs://example-predicate")).
const PREDICATE_URI = "ipfs://example-predicate";
const CLAIMS = [
  { s: "ipfs://demo/intuition-starter", o: "ipfs://demo/works-out-of-the-box" },
  { s: "ipfs://demo/the-indexer-docs", o: "ipfs://demo/disagree-with-the-indexer" },
  { s: "ipfs://demo/term-ids", o: "ipfs://demo/derivable-locally" },
];

/* ---------- id derivation (mirrors src/intuition/ids.ts) ---------- */
const ATOM_SALT = keccak256(toHex("ATOM_SALT"));
const TRIPLE_SALT = keccak256(toHex("TRIPLE_SALT"));
const atomId = (uri) =>
  keccak256(encodePacked(["bytes32", "bytes32"], [ATOM_SALT, keccak256(toHex(uri))]));
const tripleId = (s, p, o) =>
  keccak256(encodePacked(["bytes32", "bytes32", "bytes32", "bytes32"], [TRIPLE_SALT, s, p, o]));

/* ---------- clients ---------- */
const chain = defineChain({
  id: cfg.id,
  name: `Intuition ${NETWORK}`,
  nativeCurrency: { name: "TRUST", symbol: "TRUST", decimals: 18 },
  rpcUrls: { default: { http: [cfg.rpc] } },
});
const account = privateKeyToAccount(pk);
const publicClient = createPublicClient({ chain, transport: http(cfg.rpc, { timeout: 20_000 }) });
const walletClient = createWalletClient({ account, chain, transport: http(cfg.rpc, { timeout: 20_000 }) });

const abi = [
  { type: "function", name: "getAtomCost", stateMutability: "view", inputs: [], outputs: [{ type: "uint256" }] },
  { type: "function", name: "getTripleCost", stateMutability: "view", inputs: [], outputs: [{ type: "uint256" }] },
  { type: "function", name: "isTermCreated", stateMutability: "view", inputs: [{ type: "bytes32" }], outputs: [{ type: "bool" }] },
  {
    type: "function", name: "createAtoms", stateMutability: "payable",
    inputs: [{ type: "bytes[]" }, { type: "uint256[]" }], outputs: [{ type: "bytes32[]" }],
  },
  {
    type: "function", name: "createTriples", stateMutability: "payable",
    inputs: [{ type: "bytes32[]" }, { type: "bytes32[]" }, { type: "bytes32[]" }, { type: "uint256[]" }],
    outputs: [{ type: "bytes32[]" }],
  },
];

const send = async (functionName, args, value) => {
  // Simulate first — the only pre-flight revert signal on this chain.
  const { request } = await publicClient.simulateContract({
    address: cfg.multiVault, abi, functionName, args, value, account,
  });
  const hash = await walletClient.writeContract(request);
  await publicClient.waitForTransactionReceipt({ hash });
  return hash;
};

/* ---------- run ---------- */
console.log(`\nseeding ${NETWORK} as ${account.address}`);
const balance = await publicClient.getBalance({ address: account.address });
console.log(`balance: ${formatEther(balance)} TRUST`);

const atomCost = await publicClient.readContract({ address: cfg.multiVault, abi, functionName: "getAtomCost" });
const tripleCost = await publicClient.readContract({ address: cfg.multiVault, abi, functionName: "getTripleCost" });

// 1) atoms — derive, check, batch-create only what's missing
const uris = [PREDICATE_URI, ...CLAIMS.flatMap((c) => [c.s, c.o])];
const missing = [];
for (const uri of [...new Set(uris)]) {
  const id = atomId(uri);
  const exists = await publicClient.readContract({
    address: cfg.multiVault, abi, functionName: "isTermCreated", args: [id],
  });
  console.log(`  atom ${exists ? "exists" : "MINT  "} ${id.slice(0, 14)}… ${uri}`);
  if (!exists) missing.push(uri);
}
if (missing.length) {
  const data = missing.map((u) => toHex(u));
  const assets = data.map(() => atomCost); // full payment per item; msg.value must equal the sum
  const tx = await send("createAtoms", [data, assets], atomCost * BigInt(data.length));
  console.log(`  ✔ created ${missing.length} atom(s) · ${cfg.explorer}/tx/${tx}`);
}

// 2) triples — same pattern
const pId = atomId(PREDICATE_URI);
const toCreate = [];
for (const c of CLAIMS) {
  const id = tripleId(atomId(c.s), pId, atomId(c.o));
  const exists = await publicClient.readContract({
    address: cfg.multiVault, abi, functionName: "isTermCreated", args: [id],
  });
  console.log(`  claim ${exists ? "exists" : "MINT  "} ${id.slice(0, 14)}… [${c.s}] → [${c.o}]`);
  if (!exists) toCreate.push(c);
}
if (toCreate.length) {
  const tx = await send(
    "createTriples",
    [
      toCreate.map((c) => atomId(c.s)),
      toCreate.map(() => pId),
      toCreate.map((c) => atomId(c.o)),
      toCreate.map(() => tripleCost),
    ],
    tripleCost * BigInt(toCreate.length)
  );
  console.log(`  ✔ created ${toCreate.length} claim(s) · ${cfg.explorer}/tx/${tx}`);
}

console.log(`\ndone. The app's default predicate already matches; to pin it explicitly:`);
console.log(`  VITE_PREDICATE_ID=${pId}\n`);
