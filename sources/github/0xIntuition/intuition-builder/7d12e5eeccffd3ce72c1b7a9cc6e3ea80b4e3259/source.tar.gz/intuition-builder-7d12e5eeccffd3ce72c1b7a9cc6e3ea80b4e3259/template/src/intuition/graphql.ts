import { network } from "./chains";

/**
 * Indexer reads, with runtime schema resolution.
 *
 * WHY THIS FILE EXISTS
 * --------------------
 * The published GraphQL docs and the live indexer disagree. The docs page at
 * /developer-tools/graphql-api/overview shows TheGraph-style camelCase
 * (`positiveVault`, `negativeVault`, `userPositions`, `first:`, `orderBy:`),
 * while the endpoint is `/v1/graphql` served by intuition-rs — Hasura, which
 * means snake_case, `where: { … }`, `limit:` and `order_by:`. Writing against
 * the docs gives you a query that returns nothing, or a GraphQL error naming a
 * field you can plainly see in the documentation.
 *
 * Rather than pick a side, every query here ships as a list of candidate shapes
 * and a normaliser. The first shape the indexer actually answers wins, gets
 * cached for the session, and is reported via `resolvedShape()`. When the
 * indexer changes, this degrades to "one candidate stops working" instead of
 * "the app is broken and nobody knows why".
 *
 * THE SILENT-ZERO-ROWS TRAP
 * -------------------------
 * The indexer stores addresses CHECKSUMMED. `where: { account_id: { _eq: $a } }`
 * with a lowercase address returns an empty array — no error, no warning, just
 * zero rows, which reads exactly like "this user has no positions". Use
 * `_ilike`, or checksum the address with viem's `getAddress()` first. This file
 * uses `_ilike` everywhere an address is involved.
 */

export type Shape = "hasura" | "subgraph";

let cachedShape: Shape | null = null;
export const resolvedShape = () => cachedShape;

export interface GqlResult<T> {
  data: T | null;
  shape: Shape | null;
  error: string | null;
}

async function post(query: string, variables: Record<string, unknown>) {
  const res = await fetch(network.graphql, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query, variables }),
  });
  if (!res.ok) return { data: null, errors: [{ message: `HTTP ${res.status}` }] };
  return (await res.json()) as { data: unknown; errors?: { message: string }[] };
}

interface Candidate<T> {
  shape: Shape;
  query: string;
  variables: (v: Record<string, unknown>) => Record<string, unknown>;
  normalise: (data: any) => T;
}

/**
 * Try candidates in order; first one that answers without errors wins.
 * Once a shape is known we skip straight to it on later calls.
 */
async function resolve<T>(
  candidates: Candidate<T>[],
  vars: Record<string, unknown>
): Promise<GqlResult<T>> {
  const ordered = cachedShape
    ? [...candidates].sort((a, b) => (a.shape === cachedShape ? -1 : b.shape === cachedShape ? 1 : 0))
    : candidates;

  let lastError: string | null = null;
  for (const c of ordered) {
    try {
      const json = await post(c.query, c.variables(vars));
      if (json.errors?.length) {
        lastError = json.errors[0].message;
        continue;
      }
      if (json.data == null) continue;
      cachedShape = c.shape;
      return { data: c.normalise(json.data), shape: c.shape, error: null };
    } catch (e) {
      lastError = e instanceof Error ? e.message : String(e);
    }
  }
  return { data: null, shape: null, error: lastError ?? "no candidate query shape matched" };
}

/* -------------------------------------------------------------------------- */
/* Domain types — what your app sees, regardless of which shape answered.      */
/* -------------------------------------------------------------------------- */

export interface Atom {
  termId: string;
  label: string;
  uri: string | null;
}

export interface Claim {
  tripleId: string;
  counterTripleId: string | null;
  subject: Atom | null;
  predicate: Atom | null;
  object: Atom | null;
  /** TRUST-denominated vault totals. Use THESE for any for/against comparison —
   *  the two vaults have independent share prices, so raw share counts are not
   *  comparable across them. */
  forAssets: number;
  againstAssets: number;
  forShares: number;
  againstShares: number;
  forPositions: number;
  againstPositions: number;
}

const wei = (v: unknown): number => {
  if (v == null) return 0;
  try {
    return Number(BigInt(String(v)) / 10n ** 12n) / 1e6;
  } catch {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  }
};

/**
 * Select the vault for a specific curve. Pass the curve id you read from
 * `getBondingCurveConfig()` — do not hardcode "1" here for the same reason you
 * do not hardcode it in writes. The `vaults[0]` fallback only fires when no
 * curve id was supplied at all (e.g. before the contract read resolves), and a
 * term with vaults on several curves may then show the wrong book — thread the
 * real curve id through as soon as you have it.
 */
const pickCurve = (vaults: any[], curveId?: string) =>
  (curveId ? vaults?.find((v) => String(v.curve_id) === curveId) : undefined) ?? vaults?.[0];

/* -------------------------------------------------------------------------- */
/* Queries                                                                     */
/* -------------------------------------------------------------------------- */

/** Search atoms by label. Case-insensitive substring. */
export async function searchAtoms(term: string, limit = 20) {
  return resolve<Atom[]>(
    [
      {
        shape: "hasura",
        query: `query SearchAtoms($q: String!, $limit: Int!) {
          atoms(where: { label: { _ilike: $q } }, limit: $limit) {
            term_id
            label
            data
          }
        }`,
        variables: (v) => ({ q: `%${v.term}%`, limit: v.limit }),
        normalise: (d) =>
          (d.atoms ?? []).map((a: any) => ({
            termId: a.term_id,
            label: a.label ?? "",
            uri: a.data ?? null,
          })),
      },
      {
        shape: "subgraph",
        query: `query SearchAtoms($q: String!, $limit: Int!) {
          atoms(where: { uri_contains: $q }, first: $limit) { id uri }
        }`,
        variables: (v) => ({ q: v.term, limit: v.limit }),
        normalise: (d) =>
          (d.atoms ?? []).map((a: any) => ({ termId: a.id, label: a.uri ?? "", uri: a.uri ?? null })),
      },
    ],
    { term, limit }
  );
}

/**
 * Every claim using a given predicate, with both sides of the book.
 * Pass `curveId` from `read.defaultCurveId()` so vault selection matches the
 * curve you stake on.
 */
export async function claimsByPredicate(predicateId: string, curveId?: string, limit = 50) {
  return resolve<Claim[]>(
    [
      {
        shape: "hasura",
        query: `query ClaimsByPredicate($predicate: String!, $limit: Int!) {
          triples(where: { predicate_id: { _ilike: $predicate } }, limit: $limit) {
            term_id
            counter_term_id
            subject { term_id label }
            predicate { term_id label }
            object { term_id label }
            term { vaults { curve_id total_shares total_assets position_count } }
            counter_term { vaults { curve_id total_shares total_assets position_count } }
          }
        }`,
        variables: (v) => ({ predicate: v.predicateId, limit: v.limit }),
        normalise: (d) =>
          (d.triples ?? []).map((t: any) => {
            const pos = pickCurve(t.term?.vaults ?? [], curveId);
            const neg = pickCurve(t.counter_term?.vaults ?? [], curveId);
            const atom = (a: any): Atom | null =>
              a ? { termId: a.term_id, label: a.label ?? "", uri: null } : null;
            return {
              tripleId: t.term_id,
              counterTripleId: t.counter_term_id ?? null,
              subject: atom(t.subject),
              predicate: atom(t.predicate),
              object: atom(t.object),
              // fall back to shares if the indexer doesn't expose total_assets —
              // wrong-ish but monotonic, and it keeps the board rendering
              forAssets: wei(pos?.total_assets ?? pos?.total_shares),
              againstAssets: wei(neg?.total_assets ?? neg?.total_shares),
              forShares: wei(pos?.total_shares),
              againstShares: wei(neg?.total_shares),
              forPositions: pos?.position_count ?? 0,
              againstPositions: neg?.position_count ?? 0,
            };
          }),
      },
      {
        shape: "subgraph",
        query: `query ClaimsByPredicate($predicate: String!, $limit: Int!) {
          triples(where: { predicate: $predicate }, first: $limit) {
            id
            subject { id uri }
            predicate { id uri }
            object { id uri }
            positiveVault { totalShares totalAssets }
            negativeVault { totalShares totalAssets }
          }
        }`,
        variables: (v) => ({ predicate: v.predicateId, limit: v.limit }),
        normalise: (d) =>
          (d.triples ?? []).map((t: any) => {
            const atom = (a: any): Atom | null =>
              a ? { termId: a.id, label: a.uri ?? "", uri: a.uri ?? null } : null;
            return {
              tripleId: t.id,
              counterTripleId: null,
              subject: atom(t.subject),
              predicate: atom(t.predicate),
              object: atom(t.object),
              forAssets: wei(t.positiveVault?.totalAssets ?? t.positiveVault?.totalShares),
              againstAssets: wei(t.negativeVault?.totalAssets ?? t.negativeVault?.totalShares),
              forShares: wei(t.positiveVault?.totalShares),
              againstShares: wei(t.negativeVault?.totalShares),
              forPositions: 0,
              againstPositions: 0,
            };
          }),
      },
    ],
    { predicateId, limit }
  );
}

export interface Position {
  termId: string;
  shares: number;
  curveId: string;
}

/**
 * Positions for one account.
 *
 * `_ilike` on the address is load-bearing — see the header comment. If you
 * "optimise" this to `_eq` you will get zero rows and no error.
 */
export async function positionsOf(account: string, limit = 100) {
  return resolve<Position[]>(
    [
      {
        shape: "hasura",
        query: `query Positions($account: String!, $limit: Int!) {
          positions(where: { account_id: { _ilike: $account } }, limit: $limit) {
            term_id
            curve_id
            shares
          }
        }`,
        variables: (v) => ({ account: v.account, limit: v.limit }),
        normalise: (d) =>
          (d.positions ?? []).map((p: any) => ({
            termId: p.term_id,
            shares: wei(p.shares),
            curveId: String(p.curve_id ?? "1"),
          })),
      },
      {
        shape: "subgraph",
        query: `query Positions($account: String!, $limit: Int!) {
          userPositions(where: { user: $account }, first: $limit) {
            id
            shares
            vault { curveId }
          }
        }`,
        variables: (v) => ({ account: v.account, limit: v.limit }),
        normalise: (d) =>
          (d.userPositions ?? []).map((p: any) => ({
            termId: p.id,
            shares: wei(p.shares),
            curveId: String(p.vault?.curveId ?? "1"),
          })),
      },
    ],
    { account, limit }
  );
}

/**
 * Consensus ratio for a claim: 0 = fully disputed, 1 = fully supported.
 *
 * Computed over ASSETS, not shares. The for-vault and against-vault are
 * independent bonding-curve books with their own share prices, so comparing raw
 * share counts across them skews the ratio — a mature vault's shares are worth
 * more TRUST each than a fresh counter-vault's. Assets (TRUST) are the common
 * denominator.
 *
 * `minDepth` (in TRUST) suppresses the ratio for shallow books: 0.001 on each
 * side is not "50% disputed", it is noise, and rendering it as a percentage
 * manufactures confidence. Callers get `null` and should show "insufficient
 * depth".
 */
export function consensus(c: Claim, minDepth = 0): number | null {
  const total = c.forAssets + c.againstAssets;
  if (total <= 0 || total < minDepth) return null;
  return c.forAssets / total;
}
