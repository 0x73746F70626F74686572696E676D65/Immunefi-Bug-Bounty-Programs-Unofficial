# Intuition app starter

A working scaffold for building on the [Intuition](https://www.intuition.systems/) knowledge graph.
React + Vite + TypeScript + viem, no framework lock-in.

```bash
npm install
cp .env.example .env.local
npm run doctor      # check the whole environment before writing anything
npm run dev
```

## What you get

**`src/intuition/` — the reusable core.** Copy this directory into any project.

| File | What it handles |
|---|---|
| `chains.ts` | Both networks, canonical addresses, RPC and indexer URLs |
| `client.ts` | Wallet connect, add-then-switch chain, reads, simulate→send→decode writes |
| `ids.ts` | Local term-ID derivation — atom, triple, counter-triple |
| `errors.ts` | Decode a bare 4-byte revert into a name and a plain-English fix |
| `graphql.ts` | Indexer reads with runtime schema-shape resolution |
| `revert-selectors.json` | All 96 custom errors, generated from the contracts |

Everything else is a demo claims board. Delete it.

## `npm run doctor`

The most useful command here. Run it before debugging anything.

```
intuition doctor · testnet

Configuration
  ✔ network — testnet (chain id 13579)
  ✔ multiVault — 0x2Ece8D4dEdcB9918A398528f3fa4688b1d2CAB91

RPC
  ✔ chain id — 13579
  ✔ head block — 4182203

MultiVault
  ✔ bytecode — 24,576 bytes
  ✔ atom cost — 0.001 TRUST
  ✔ default curve — 1

Term ID derivation
  ✔ calculateAtomId — local derivation matches the contract
  ✔ calculateTripleId — matches
  ✔ calculateCounterTripleId — matches

Indexer
  ✔ schema shape — hasura (snake_case, where/_ilike, limit)

Address casing trap
  ✔ stored casing — CHECKSUMMED
  ! _eq with a lowercase address returns ZERO rows — silently, with no error
      → Always use _ilike for addresses, or getAddress() them first.
```

It exits non-zero on failure, so it works in CI.

## The five things that will break your first build

1. **Addresses are stored CHECKSUMMED in the indexer.** `_eq` with a lowercase address returns `[]`
   with no error, which is indistinguishable from "no data". Use `_ilike`.
2. **The published GraphQL docs don't match the live schema.** Docs show subgraph-style camelCase;
   the endpoint is Hasura. `graphql.ts` tries both and reports which answered.
3. **Term IDs are derivable locally** — `keccak256(SALT ++ keccak256(data))`. No round trip needed.
   The doctor verifies the derivation against the contract's own pure functions.
4. **The L3 isn't on Etherscan**, so reverts are bare 4-byte selectors. `explainRevert(err)` turns
   them into sentences.
5. **Mainnet and testnet have different MultiVault addresses.** Crossing them looks like an RPC
   problem.

## Staking against a claim

The thing that makes Intuition different from every other attestation system: every triple has a
counter-vault, so disagreement is a real position rather than a downvote.

```ts
import { calculateCounterTripleId } from "./intuition/ids";
import { stake } from "./intuition/client";

await stake(wallet, address, tripleId, amount, curveId);                          // agree
await stake(wallet, address, calculateCounterTripleId(tripleId), amount, curveId); // disagree
```

Same call, different term ID, derived locally.

## Scripts

| | |
|---|---|
| `npm run dev` | dev server |
| `npm run build` | typecheck + production build |
| `npm run doctor` | diagnose the environment; `-- --network mainnet` to switch |
| `npm run selectors` | regenerate the revert table from the contracts |
| `npm run lint` | typecheck only |

## Deploying

`vercel.json` already has the SPA rewrite — without it every route 404s on refresh. Set your
`VITE_` env vars in the dashboard and redeploy (Vite inlines them at build time). See
`reference/deploy.md` in the skill for the mainnet checklist.

## Related

For transaction encoding, ABI correctness, IPFS pinning policy and preview functions, use the
official skill: `npx skills add 0xintuition/agent-skills --skill intuition`. This scaffold covers
the application layer around it.
