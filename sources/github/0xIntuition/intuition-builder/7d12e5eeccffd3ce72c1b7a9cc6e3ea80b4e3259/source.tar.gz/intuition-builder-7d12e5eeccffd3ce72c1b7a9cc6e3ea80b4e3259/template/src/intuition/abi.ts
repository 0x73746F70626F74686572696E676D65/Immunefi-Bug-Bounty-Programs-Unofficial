/**
 * Minimal MultiVault ABI — only what an app actually calls.
 *
 * Transcribed from intuition-contracts-v2 (src/protocol/MultiVault.sol and
 * MultiVaultCore.sol). Deliberately small: a 900-entry ABI blob is unreadable
 * and agents pattern-match the wrong overload out of it.
 *
 * Two invariants that break most first attempts:
 *
 *  1. Creation is BATCH-ONLY. There is no createAtom(). Use createAtoms() with
 *     single-element arrays.
 *  2. assets[] is the full payment, and msg.value must equal sum(assets[]).
 *     Each assets[i] must be >= the creation cost; the remainder becomes your
 *     opening deposit into that vault.
 */

export const multiVaultAbi = [
  // ---- creation -----------------------------------------------------------
  {
    type: "function",
    name: "createAtoms",
    stateMutability: "payable",
    inputs: [
      { name: "data", type: "bytes[]" },
      { name: "assets", type: "uint256[]" },
    ],
    outputs: [{ name: "", type: "bytes32[]" }],
  },
  {
    type: "function",
    name: "createTriples",
    stateMutability: "payable",
    inputs: [
      { name: "subjectIds", type: "bytes32[]" },
      { name: "predicateIds", type: "bytes32[]" },
      { name: "objectIds", type: "bytes32[]" },
      { name: "assets", type: "uint256[]" },
    ],
    outputs: [{ name: "", type: "bytes32[]" }],
  },

  // ---- positions ----------------------------------------------------------
  {
    type: "function",
    name: "deposit",
    stateMutability: "payable",
    inputs: [
      { name: "receiver", type: "address" },
      { name: "termId", type: "bytes32" },
      { name: "curveId", type: "uint256" },
      { name: "minShares", type: "uint256" },
    ],
    outputs: [{ name: "shares", type: "uint256" }],
  },
  {
    type: "function",
    name: "redeem",
    stateMutability: "nonpayable",
    inputs: [
      { name: "receiver", type: "address" },
      { name: "termId", type: "bytes32" },
      { name: "curveId", type: "uint256" },
      { name: "shares", type: "uint256" },
      { name: "minAssets", type: "uint256" },
    ],
    outputs: [{ name: "assets", type: "uint256" }],
  },

  // ---- reads --------------------------------------------------------------
  {
    type: "function",
    name: "getShares",
    stateMutability: "view",
    inputs: [
      { name: "account", type: "address" },
      { name: "termId", type: "bytes32" },
      { name: "curveId", type: "uint256" },
    ],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    type: "function",
    name: "getVault",
    stateMutability: "view",
    inputs: [
      { name: "termId", type: "bytes32" },
      { name: "curveId", type: "uint256" },
    ],
    outputs: [
      { name: "totalAssets", type: "uint256" },
      { name: "totalShares", type: "uint256" },
    ],
  },
  {
    type: "function",
    name: "getAtomCost",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    type: "function",
    name: "getTripleCost",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    type: "function",
    name: "getBondingCurveConfig",
    stateMutability: "view",
    inputs: [],
    outputs: [
      { name: "registry", type: "address" },
      { name: "defaultCurveId", type: "uint256" },
    ],
  },
  {
    type: "function",
    name: "isTermCreated",
    stateMutability: "view",
    inputs: [{ name: "termId", type: "bytes32" }],
    outputs: [{ name: "", type: "bool" }],
  },

  // ---- pure id helpers (use these to verify local derivation) --------------
  {
    type: "function",
    name: "calculateAtomId",
    stateMutability: "pure",
    inputs: [{ name: "data", type: "bytes" }],
    outputs: [{ name: "id", type: "bytes32" }],
  },
  {
    type: "function",
    name: "calculateTripleId",
    stateMutability: "pure",
    inputs: [
      { name: "subjectId", type: "bytes32" },
      { name: "predicateId", type: "bytes32" },
      { name: "objectId", type: "bytes32" },
    ],
    outputs: [{ name: "id", type: "bytes32" }],
  },
  /**
   * NAMING TRAP — read this before you call either of the next two.
   *
   * `calculateCounterTripleId` does NOT take a triple id. It takes the three
   * component atom ids and derives the counter id from scratch. The function
   * that takes a triple id is called `getCounterIdFromTripleId`.
   *
   * Guessing the obvious signature gives you a call that reverts with no
   * useful message, because the selector simply does not exist on the contract.
   */
  {
    type: "function",
    name: "calculateCounterTripleId",
    stateMutability: "pure",
    inputs: [
      { name: "subjectId", type: "bytes32" },
      { name: "predicateId", type: "bytes32" },
      { name: "objectId", type: "bytes32" },
    ],
    outputs: [{ name: "id", type: "bytes32" }],
  },
  {
    type: "function",
    name: "getCounterIdFromTripleId",
    stateMutability: "pure",
    inputs: [{ name: "tripleId", type: "bytes32" }],
    outputs: [{ name: "counterId", type: "bytes32" }],
  },
  {
    type: "function",
    name: "getTripleIdFromCounterId",
    stateMutability: "view",
    inputs: [{ name: "counterId", type: "bytes32" }],
    outputs: [{ name: "tripleId", type: "bytes32" }],
  },
  {
    type: "function",
    name: "isTriple",
    stateMutability: "view",
    inputs: [{ name: "termId", type: "bytes32" }],
    outputs: [{ name: "", type: "bool" }],
  },
] as const;
