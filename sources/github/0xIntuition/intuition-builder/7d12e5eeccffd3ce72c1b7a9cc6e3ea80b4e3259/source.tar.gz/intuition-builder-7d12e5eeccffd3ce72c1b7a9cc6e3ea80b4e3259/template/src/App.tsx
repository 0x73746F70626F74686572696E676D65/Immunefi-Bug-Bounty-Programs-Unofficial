import { useCallback, useEffect, useState } from "react";
import { parseEther, type Hex, type WalletClient } from "viem";
import { network, NETWORK } from "./intuition/chains";
import { connect, read, stake, explorerTx, IntuitionTxError } from "./intuition/client";
import { claimsByPredicate, resolvedShape, type Claim, consensus } from "./intuition/graphql";
import { calculateCounterTripleId, atomIdFromUri } from "./intuition/ids";
import { ERROR_COUNT } from "./intuition/errors";

/**
 * Demo app: a claims board.
 *
 * Shows the full loop an Intuition app needs — read claims from the indexer,
 * derive ids locally, stake FOR (positive vault) or AGAINST (counter vault),
 * and surface decoded reverts. Delete the UI, keep src/intuition/.
 */

const DEMO_PREDICATE =
  import.meta.env.VITE_PREDICATE_ID ?? atomIdFromUri("ipfs://example-predicate");

export default function App() {
  const [address, setAddress] = useState<Hex | "">("");
  const [wallet, setWallet] = useState<WalletClient | null>(null);
  const [claims, setClaims] = useState<Claim[]>([]);
  const [curveId, setCurveId] = useState<bigint>(1n);
  const [loading, setLoading] = useState(true);
  const [indexerError, setIndexerError] = useState<string | null>(null);
  const [status, setStatus] = useState<string>("");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      // Never hardcode curve 1 — ask the contract, then thread the same curve
      // through the read layer so the vaults you display are the vaults you
      // stake on. If the RPC is down we still render the board (pickCurve
      // falls back), but writes will fail loudly anyway.
      const id = await read.defaultCurveId().catch(() => null);
      if (cancelled) return;
      if (id != null) setCurveId(id);
      const res = await claimsByPredicate(DEMO_PREDICATE, id != null ? String(id) : undefined);
      if (cancelled) return;
      setClaims(res.data ?? []);
      setIndexerError(res.error);
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const onConnect = useCallback(async () => {
    const res = await connect();
    if (!res) {
      setStatus("No injected wallet found. Install MetaMask or Rabby.");
      return;
    }
    setAddress(res.address);
    setWallet(res.wallet);
    setStatus("");
  }, []);

  const onStake = useCallback(
    async (claim: Claim, side: "for" | "against") => {
      if (!wallet || !address) return void onConnect();
      const termId =
        side === "for"
          ? (claim.tripleId as Hex)
          : ((claim.counterTripleId as Hex) ?? calculateCounterTripleId(claim.tripleId as Hex));
      setStatus(`Staking ${side}…`);
      try {
        const receipt = await stake(wallet, address, termId, parseEther("0.01"), curveId);
        setStatus(`Confirmed — ${explorerTx(receipt.transactionHash)}`);
      } catch (err) {
        // IntuitionTxError carries a decoded, human-readable revert reason.
        setStatus(err instanceof IntuitionTxError ? err.message : String(err));
      }
    },
    [wallet, address, curveId, onConnect]
  );

  return (
    <div className="app">
      <header className="top">
        <div className="brand">
          <span className="dot" />
          <strong>Intuition starter</strong>
          <span className="tag">{NETWORK}</span>
        </div>
        <button className="btn" onClick={onConnect}>
          {address ? `${address.slice(0, 6)}…${address.slice(-4)}` : "Connect wallet"}
        </button>
      </header>

      <section className="diag">
        <Diag label="chain" value={`${network.chain.name} · ${network.chain.id}`} />
        <Diag label="curve" value={String(curveId)} hint="read from getBondingCurveConfig()" />
        <Diag
          label="indexer"
          value={resolvedShape() ?? (loading ? "resolving…" : "unresolved")}
          hint="schema shape detected at runtime"
        />
        <Diag label="revert table" value={`${ERROR_COUNT} errors`} hint="decoded locally" />
      </section>

      {indexerError && (
        <div className="banner">
          <strong>Indexer unreachable or schema unmatched.</strong> {indexerError}
          <br />
          Run <code>npm run doctor</code> — it will tell you exactly which layer is broken.
        </div>
      )}

      <main>
        <h1>Claims</h1>
        <p className="lede">
          Every claim has two vaults: the triple itself (agree) and its counter-triple (disagree).
          Both ids are derived locally — no round trip. Staking against a claim is the same call
          with a different term id.
        </p>

        {loading && <p className="muted">Loading…</p>}
        {!loading && claims.length === 0 && (
          <div className="empty">
            <p>No claims found for this predicate.</p>
            <p className="muted">
              Set <code>VITE_PREDICATE_ID</code> in <code>.env.local</code> to a predicate that
              exists on {NETWORK}, or create one with <code>npm run seed</code>.
            </p>
          </div>
        )}

        <div className="claims">
          {claims.map((c) => {
            const ratio = consensus(c);
            return (
              <article className="claim" key={c.tripleId}>
                <div className="triple">
                  <span className="atom">{c.subject?.label ?? "—"}</span>
                  <span className="pred">{c.predicate?.label ?? "—"}</span>
                  <span className="atom">{c.object?.label ?? "—"}</span>
                </div>

                <div className="bar" aria-hidden>
                  <div className="bar-for" style={{ flex: ratio ?? 0.5 }} />
                  <div className="bar-against" style={{ flex: 1 - (ratio ?? 0.5) }} />
                </div>

                <div className="row">
                  {/* Assets (TRUST), not shares — share prices differ per vault. */}
                  <span className="for">
                    {c.forAssets.toFixed(3)} <em>for · {c.forPositions}</em>
                  </span>
                  <span className="against">
                    <em>{c.againstPositions} · against</em> {c.againstAssets.toFixed(3)}
                  </span>
                </div>

                <div className="actions">
                  <button className="btn agree" onClick={() => onStake(c, "for")}>
                    Agree
                  </button>
                  <button className="btn disagree" onClick={() => onStake(c, "against")}>
                    Disagree
                  </button>
                </div>

                <code className="ids">
                  {c.tripleId.slice(0, 10)}… / counter{" "}
                  {(c.counterTripleId ?? calculateCounterTripleId(c.tripleId as Hex)).slice(0, 10)}…
                </code>
              </article>
            );
          })}
        </div>

        {status && <p className="status">{status}</p>}
      </main>

      <footer>
        <span>
          Starter scaffold · <code>src/intuition/</code> is the reusable part
        </span>
        <a href={network.chain.blockExplorers!.default.url} target="_blank" rel="noreferrer">
          explorer ↗
        </a>
      </footer>
    </div>
  );
}

function Diag({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="diag-item" title={hint}>
      <span className="diag-label">{label}</span>
      <span className="diag-value">{value}</span>
    </div>
  );
}
