#!/usr/bin/env node
/**
 * Regenerate src/intuition/revert-selectors.json from the contracts.
 *
 *   npm run selectors                       # clones contracts-v2 at main
 *   npm run selectors -- --ref v2.1.0       # pin a tag or SHA
 *   npm run selectors -- --src ../intuition-contracts-v2
 *
 * Why this exists: the Intuition L3 is not on Etherscan, so a failed tx returns
 * a bare 4-byte selector. Hand-maintaining a couple of selectors goes stale
 * silently — and a stale selector table is worse than none, because it decodes
 * to confidently wrong error names. Generate, don't transcribe.
 */

import { execSync } from "node:child_process";
import { readFileSync, writeFileSync, readdirSync, statSync, mkdtempSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { tmpdir } from "node:os";
import { fileURLToPath } from "node:url";
import { toFunctionSelector } from "viem";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const arg = (name) =>
  process.argv.includes(name) ? process.argv[process.argv.indexOf(name) + 1] : null;

const REPO = "https://github.com/0xIntuition/intuition-contracts-v2.git";
const ref = arg("--ref");
let src = arg("--src");
let resolvedRef = ref ?? "main";

if (!src) {
  const dir = mkdtempSync(join(tmpdir(), "icv2-"));
  console.log(`cloning ${REPO}${ref ? ` @ ${ref}` : ""} …`);
  execSync(`git clone -q ${ref ? "" : "--depth 1"} ${REPO} ${dir}`, { stdio: "inherit" });
  if (ref) execSync(`git -C ${dir} checkout -q ${ref}`, { stdio: "inherit" });
  resolvedRef = execSync(`git -C ${dir} rev-parse HEAD`, { encoding: "utf8" }).trim();
  src = dir;
}

const srcDir = existsSync(join(src, "src")) ? join(src, "src") : src;

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) walk(p, out);
    else if (p.endsWith(".sol")) out.push(p);
  }
  return out;
}

const sigs = new Set();
for (const file of walk(srcDir)) {
  const text = readFileSync(file, "utf8");
  for (const m of text.matchAll(/^\s*error\s+([A-Za-z0-9_]+)\s*\(([^)]*)\)\s*;/gm)) {
    const params = m[2]
      .split(",")
      .map((p) => p.trim())
      .filter(Boolean)
      .map((p) => p.split(/\s+/)[0]);
    sigs.add(`${m[1]}(${params.join(",")})`);
  }
}

const errors = [...sigs]
  .sort()
  .map((canonical) => ({
    name: canonical.slice(0, canonical.indexOf("(")),
    canonical,
    selector: toFunctionSelector(`error ${canonical}`),
  }));

const collisions = errors.filter(
  (e, i, a) => a.findIndex((x) => x.selector === e.selector) !== i
);
if (collisions.length) {
  console.warn(`WARNING: ${collisions.length} selector collision(s):`, collisions.map((c) => c.canonical));
}

const payload = {
  source: "github.com/0xIntuition/intuition-contracts-v2",
  ref: resolvedRef,
  generatedBy: "npm run selectors",
  count: errors.length,
  errors,
};

const out = join(root, "src/intuition/revert-selectors.json");
writeFileSync(out, JSON.stringify(payload, null, 2));
console.log(`wrote ${errors.length} error selectors → ${out}`);
console.log(`ref: ${resolvedRef}`);
