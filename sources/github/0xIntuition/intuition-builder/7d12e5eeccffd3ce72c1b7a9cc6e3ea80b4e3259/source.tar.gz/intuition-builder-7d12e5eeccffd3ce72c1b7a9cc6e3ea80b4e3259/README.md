# intuition-builder

A Claude Code plugin for **building applications** on the [Intuition](https://www.intuition.systems/)
knowledge graph.

**Claude Code** (terminal):

```
/plugin marketplace add keegan-dotcom/intuition-builder
/plugin install intuition-builder@intuition
```

**Cowork / Claude desktop app** (no terminal at all): open the **Customize** menu → **Plugins**
tab → under **Personal plugins** click **+** → **Add marketplace** → paste
`keegan-dotcom/intuition-builder` → install **intuition-builder** from the list.

Either way: no Foundry, no `cast`, no build step. The skill activates automatically whenever you
ask Claude to build something on Intuition.

## Try it in one sentence

Once installed, just describe what you want:

> *"Scaffold me an Intuition testnet app where people stake on whether restaurants are worth the hype."*

> *"Run the doctor and tell me why my positions query returns nothing."*

> *"Add a 'disagree' button to my app using the counter-vault."*

The skill handles chain config, the indexer's real schema, ID derivation, and decoded errors so the
conversation stays about your product. Stuck for an idea? `skills/intuition-app/reference/app-ideas.md`
has 14, each reduced to its claim structure.

---

## Why this exists

`0xIntuition/agent-skills` is the canonical reference for producing **correct transactions** —
ABIs, encoding, addresses, value calculations. It's good, and it states its own boundary plainly:

> Skills produce unsigned transaction parameters. Wallet infrastructure and signing are the
> builder's responsibility.

This plugin is that responsibility. It covers the distance between *"I have correct calldata"* and
*"there is a working app at a URL"* — and it is designed to sit **alongside** the official skill,
not replace it. Install both.

| Need | Use |
|---|---|
| Calldata, ABIs, encoding, IPFS pinning policy, preview functions, batch semantics | `agent-skills` → `intuition` |
| Chain/wallet wiring, indexer reads, local ID derivation, revert decoding, app structure, deploy | this plugin → `intuition-app` |

## What's in it

**`skills/intuition-app/`** — the app-layer skill. Six reference files covering networks and
wallet, the read layer, the write layer, IDs and errors, application patterns, and deploy, plus a
symptom-to-fix troubleshooting guide.

**`template/`** — a working Vite + React + TypeScript + viem scaffold. Builds clean, deploys to
Vercel as-is. `src/intuition/` is a portable core you can lift into any project.

**`template/scripts/doctor.mjs`** — `npm run doctor`. Checks config, RPC reachability and chain ID,
contract bytecode, atom/triple cost, default curve, **local term-ID derivation against the
contract's own pure functions**, which GraphQL schema the indexer actually speaks, the
address-casing trap, and wallet balance. Exits non-zero on failure, so it works in CI.

**`template/src/intuition/revert-selectors.json`** — all **96 custom errors** across the v2
contracts with computed selectors, generated from source by `npm run selectors`, with the contracts
SHA recorded. The L3 isn't on Etherscan, so without this a failed transaction is a bare 4-byte
selector and nothing else.

**`contrib/`** — a corrections PR for `agent-skills`. See below.

## The findings behind it

Everything here came out of actually building an app on testnet. The four that cost the most time:

**Addresses are stored checksummed in the indexer.** `where: { account_id: { _eq: "0xabc…" } }`
with a lowercase address returns `[]` — no error, no warning. It is indistinguishable from "this
user has no positions", so every layer downstream treats it as valid data. Use `_ilike`, or
`getAddress()` at the boundary. This is the single highest-frequency bug on this stack and it is
documented nowhere.

**The published GraphQL docs don't match the live indexer.** The docs show TheGraph-style camelCase
(`positiveVault`, `userPositions`, `first:`, `orderBy:`); the endpoint is `/v1/graphql` served by
`intuition-rs` — Hasura, so snake_case with `where`/`limit`/`order_by`. Writing against the docs
produces a query that errors on a field you can plainly see documented. The template resolves the
shape at runtime instead of guessing, so a schema change degrades to "one candidate stopped
working" rather than "the app is broken".

**Term IDs are derivable locally, and almost nothing says so.** From `MultiVaultCore.sol`:
`atomId = keccak256(ATOM_SALT ++ keccak256(data))`,
`tripleId = keccak256(TRIPLE_SALT ++ s ++ p ++ o)`,
`counterTripleId = keccak256(COUNTER_SALT ++ tripleId)`. You can compute an ID, link to it, and
check existence before spending anything. The counter-triple ID is the payoff: **staking against a
claim is the same `deposit()` call with a locally-derived ID**. The doctor verifies all three
against the chain's own pure functions, so a change in salting fails loudly at diagnosis time.

**Two selectors pinned in the official skill don't reproduce from source.** `0xb4856ebc` and
`0x4762af7d` don't match any error signature in `intuition-contracts-v2` or
`intuition-beta-contracts`. Possibly from an older deployment — but a stale selector decodes to a
confidently *wrong* error name, which is worse than no decode. Hence: generate the table, don't
transcribe it.

## The corrections PR

`contrib/PR_BODY.md` is ready to send to `0xIntuition/agent-skills`:

1. `_eq` → `_ilike` on address filters, with the silent-zero-rows explanation
2. `MultiVault_HasCounterStake` added to the error table — the first error any counter-vault app
   hits, and undocumented despite counter-triples being covered well elsewhere
3. A broken link to `intuition-v2` (the repo is `intuition-contracts-v2`)
4. The selector-provenance question, plus an offer to contribute the generator

## Packaging note

`agent-skills` ships `.claude-plugin/marketplace.json` in the **skills.sh** shape — a `skills` array,
no top-level `owner`, no `plugin.json` — so it installs via `npx skills add` and requires `cast`,
`jq` and `bc` at runtime. That works for Claude Code users with Foundry installed; it locks out
Cowork entirely.

This plugin ships both a proper `plugin.json` and a Claude Code-shaped `marketplace.json`, so
`/plugin marketplace add` works. If the Intuition team wants it, the same packaging can be applied
to `agent-skills` in about ten lines and would make the official skill installable by everyone
building in Cowork.

## License

MIT. Take any of it — including straight into `0xIntuition/agent-skills` with no attribution
needed.
