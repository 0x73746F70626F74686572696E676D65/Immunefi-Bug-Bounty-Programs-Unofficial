# funnel-media

Static media assets for the Intuition funnel marketing site, served via the
jsDelivr CDN. This is a temporary host while permanent object storage (R2/GCS)
is provisioned.

Assets are referenced pinned to a release tag, e.g.:

```
https://cdn.jsdelivr.net/gh/0xIntuition/funnel-media@v1/media/hero-loop-v1.mp4
```

Never overwrite a published file under an existing tag — add a new versioned
filename and cut a new tag so CDN caches stay immutable.
