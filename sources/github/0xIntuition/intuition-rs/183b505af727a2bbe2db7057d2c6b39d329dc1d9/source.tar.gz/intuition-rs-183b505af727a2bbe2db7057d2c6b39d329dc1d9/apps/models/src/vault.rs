use crate::{
    error::ModelError,
    traits::{Model, SimpleCrud},
    types::{FixedBytesWrapper, U256Wrapper},
};
use async_trait::async_trait;
use chrono::{DateTime, Utc};
use sqlx::{Executor, PgPool, Postgres, Result};

/// This struct defines the vault in the database. Note that both `atom_id` and
/// `triple_id` are optional. This is because a vault can either be created by
/// an atom or a triple, but not both. We have SQL rails to prevent a vault from
/// having both an atom_id and a triple_id.
#[derive(Debug, sqlx::FromRow, Builder)]
#[sqlx(type_name = "vault")]
pub struct Vault {
    pub term_id: FixedBytesWrapper,
    pub curve_id: U256Wrapper,
    pub total_shares: U256Wrapper,
    pub current_share_price: U256Wrapper,
    pub position_count: i32,
    pub total_assets: U256Wrapper,
    pub market_cap: U256Wrapper,
    pub block_number: i64,
    pub log_index: i64,
    pub transaction_hash: String,
    pub created_at: DateTime<Utc>,
}
/// This is a trait that all models must implement.
impl Model for Vault {}

/// This trait works as a contract for all models that need to be upserted into the database.
#[async_trait]
impl SimpleCrud<FixedBytesWrapper> for Vault {
    /// This method upserts a vault into the database.
    /// NOTE: position_count is intentionally excluded from the UPDATE clause to preserve values set by database triggers.
    async fn upsert<'e, E>(&self, schema: &str, executor: E) -> Result<Self, ModelError>
    where
        E: Executor<'e, Database = Postgres>,
    {
        let query = format!(
            r#"
            WITH upsert AS (
                INSERT INTO {0}.vault (
                    term_id, curve_id, total_shares, current_share_price, position_count,
                    total_assets, market_cap, block_number, log_index, transaction_hash,
                    created_at
                )
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
                ON CONFLICT (term_id, curve_id) DO UPDATE SET
                    total_shares = EXCLUDED.total_shares,
                    current_share_price = EXCLUDED.current_share_price,
                    -- position_count is NOT updated here - it's managed by database triggers
                    total_assets = EXCLUDED.total_assets,
                    market_cap = EXCLUDED.market_cap,
                    block_number = EXCLUDED.block_number,
                    log_index = EXCLUDED.log_index,
                    transaction_hash = EXCLUDED.transaction_hash,
                    created_at = EXCLUDED.created_at
                WHERE
                EXCLUDED.block_number > vault.block_number
                OR (
                    EXCLUDED.block_number = vault.block_number
                    AND EXCLUDED.log_index > vault.log_index
                )
                RETURNING term_id, curve_id, total_shares, current_share_price, position_count,
                          total_assets, market_cap, block_number, log_index, transaction_hash,
                          created_at
            )
            SELECT * FROM upsert
            UNION ALL
            SELECT term_id, curve_id, total_shares, current_share_price, position_count,
                   total_assets, market_cap, block_number, log_index, transaction_hash,
                   created_at
            FROM {0}.vault
            WHERE term_id = $1 AND curve_id = $2
            AND NOT EXISTS (SELECT 1 FROM upsert)
            "#,
            schema,
        );

        sqlx::query_as::<_, Vault>(&query)
            .bind(self.term_id.clone())
            .bind(self.curve_id.to_big_decimal()?)
            .bind(self.total_shares.to_big_decimal()?)
            .bind(self.current_share_price.to_big_decimal()?)
            .bind(self.position_count)
            .bind(self.total_assets.to_big_decimal()?)
            .bind(self.market_cap.to_big_decimal()?)
            .bind(self.block_number)
            .bind(self.log_index)
            .bind(self.transaction_hash.clone())
            .bind(self.created_at)
            .fetch_one(executor)
            .await
            .map_err(|e| ModelError::VaultUpsertError(e.to_string()))
    }

    /// Finds a vault by its id.
    async fn find_by_id<'e, E>(
        term_id: FixedBytesWrapper,
        schema: &str,
        executor: E,
    ) -> Result<Option<Self>, ModelError>
    where
        E: Executor<'e, Database = Postgres>,
    {
        let query = format!(
            r#"
            SELECT 
                term_id, 
                curve_id,
                total_shares, 
                current_share_price,
                position_count,
                total_assets,
                market_cap,
                block_number,
                log_index,
                transaction_hash,
                created_at
            FROM {}.vault 
            WHERE term_id = $1
            "#,
            schema,
        );

        sqlx::query_as::<_, Vault>(&query)
            .bind(term_id)
            .fetch_optional(executor)
            .await
            .map_err(|e| ModelError::QueryError(e.to_string()))
    }
}

impl Vault {
    /// Finds all the vaults by its term_id.
    pub async fn find_vaults_by_term_id<'e, E>(
        term_id: FixedBytesWrapper,
        schema: &str,
        executor: E,
    ) -> Result<Vec<Self>, ModelError>
    where
        E: Executor<'e, Database = Postgres>,
    {
        let query = format!(
            r#"
            SELECT 
                term_id, 
                curve_id,
                total_shares, 
                current_share_price,
                position_count,
                total_assets,
                market_cap,
                block_number,
                log_index,
                transaction_hash,
                created_at
            FROM {}.vault 
            WHERE term_id = $1
            "#,
            schema,
        );

        sqlx::query_as::<_, Vault>(&query)
            .bind(term_id)
            .fetch_all(executor)
            .await
            .map_err(|e| ModelError::QueryError(e.to_string()))
    }

    /// This function updates the current share price of a vault
    pub async fn update_current_share_price<'e, E>(
        id: U256Wrapper,
        current_share_price: U256Wrapper,
        executor: E,
        schema: &str,
    ) -> Result<Self, ModelError>
    where
        E: Executor<'e, Database = Postgres>,
    {
        let query = format!(
            r#"
            UPDATE {}.vault 
            SET current_share_price = $1 
            WHERE term_id = $2 AND curve_id = $3
            RETURNING term_id, curve_id, total_shares, current_share_price, position_count, total_assets, market_cap, block_number, log_index, transaction_hash, created_at
            "#,
            schema,
        );

        sqlx::query_as::<_, Vault>(&query)
            .bind(current_share_price.to_big_decimal()?)
            .bind(id.to_big_decimal()?)
            .bind(<&str as TryInto<U256Wrapper>>::try_into("1")?.to_big_decimal()?)
            .fetch_one(executor)
            .await
            .map_err(|e| ModelError::UpdateError(e.to_string()))
    }

    /// This function finds a vault by its term_id and curve_id
    pub async fn find_by_term_id_and_curve_id<'e, E>(
        term_id: FixedBytesWrapper,
        curve_id: U256Wrapper,
        executor: E,
        schema: &str,
    ) -> Result<Option<Self>, ModelError>
    where
        E: Executor<'e, Database = Postgres>,
    {
        let query = format!(
            r#"
            SELECT * FROM {}.vault WHERE term_id = $1 AND curve_id = $2
            "#,
            schema,
        );

        sqlx::query_as::<_, Vault>(&query)
            .bind(term_id)
            .bind(curve_id.to_big_decimal()?)
            .fetch_optional(executor)
            .await
            .map_err(|e| ModelError::QueryError(e.to_string()))
    }

    /// This function sums the total assets of all the vaults for a given term
    pub async fn sum_total_assets(
        term_id: FixedBytesWrapper,
        pool: &PgPool,
        schema: &str,
    ) -> Result<U256Wrapper, ModelError> {
        let query = format!(
            r#"SELECT SUM(total_assets) FROM {}.vault WHERE term_id = $1"#,
            schema
        );
        sqlx::query_scalar::<_, U256Wrapper>(&query)
            .bind(term_id)
            .fetch_one(pool)
            .await
            .map_err(|e| ModelError::QueryError(e.to_string()))
    }

    /// This function sums the market cap of all the vaults for a given term
    pub async fn sum_market_cap(
        term_id: FixedBytesWrapper,
        pool: &PgPool,
        schema: &str,
    ) -> Result<U256Wrapper, ModelError> {
        let query = format!(
            r#"SELECT SUM(market_cap) FROM {}.vault WHERE term_id = $1"#,
            schema
        );
        sqlx::query_scalar::<_, U256Wrapper>(&query)
            .bind(term_id)
            .fetch_one(pool)
            .await
            .map_err(|e| ModelError::QueryError(e.to_string()))
    }

    /// This function sums the position count of all the vaults for a given term
    pub async fn sum_position_count(
        term_id: FixedBytesWrapper,
        counter_term_id: FixedBytesWrapper,
        pool: &PgPool,
        schema: &str,
    ) -> Result<i64, ModelError> {
        let query = format!(
            r#"SELECT SUM(position_count) FROM {}.vault WHERE term_id = $1 OR term_id = $2"#,
            schema
        );
        sqlx::query_scalar::<_, i64>(&query)
            .bind(term_id)
            .bind(counter_term_id)
            .fetch_one(pool)
            .await
            .map_err(|e| ModelError::QueryError(e.to_string()))
    }

    /// This function fetches triple vault aggregates from the vault table for a specific curve
    pub async fn fetch_triple_vault_aggregates(
        term_id: FixedBytesWrapper,
        counter_term_id: FixedBytesWrapper,
        curve_id: U256Wrapper,
        pool: &PgPool,
        schema: &str,
    ) -> Result<Vec<Vault>, ModelError> {
        let query = format!(
            r#"
            SELECT * FROM {}.vault 
            WHERE (term_id = $1 OR term_id = $2) AND curve_id = $3
            "#,
            schema
        );
        sqlx::query_as::<_, Vault>(&query)
            .bind(term_id)
            .bind(counter_term_id)
            .bind(curve_id.to_big_decimal()?)
            .fetch_all(pool)
            .await
            .map_err(|e| ModelError::QueryError(e.to_string()))
    }

    /// This function fetches triple term aggregates from the vault table for all curves
    pub async fn fetch_triple_term_aggregates(
        term_id: FixedBytesWrapper,
        counter_term_id: FixedBytesWrapper,
        pool: &PgPool,
        schema: &str,
    ) -> Result<Vec<Vault>, ModelError> {
        let query = format!(
            r#"
            SELECT * FROM {}.vault 
            WHERE term_id = $1 OR term_id = $2
            "#,
            schema
        );
        sqlx::query_as::<_, Vault>(&query)
            .bind(term_id)
            .bind(counter_term_id)
            .fetch_all(pool)
            .await
            .map_err(|e| ModelError::QueryError(e.to_string()))
    }

    /// Inserts a minimal vault stub if one does not already exist for the given
    /// `(term_id, curve_id)` pair. All numeric fields default to zero and the
    /// timestamp defaults to `NOW()`. The `ON CONFLICT DO NOTHING` clause makes
    /// this a true no-op when the vault already exists, preserving any real data
    /// written by `SharePriceChanged` or `AtomCreated` handlers.
    pub async fn ensure_exists<'e, E>(
        term_id: FixedBytesWrapper,
        curve_id: U256Wrapper,
        schema: &str,
        executor: E,
    ) -> Result<(), ModelError>
    where
        E: Executor<'e, Database = Postgres>,
    {
        let query = format!(
            r#"
            INSERT INTO {}.vault (
                term_id, curve_id, total_shares, current_share_price, position_count,
                total_assets, market_cap, block_number, log_index, transaction_hash,
                created_at
            )
            VALUES ($1, $2, 0, 0, 0, 0, 0, 0, 0, '', NOW())
            ON CONFLICT (term_id, curve_id) DO NOTHING
            "#,
            schema,
        );

        sqlx::query(&query)
            .bind(term_id)
            .bind(curve_id.to_big_decimal()?)
            .execute(executor)
            .await
            .map(|_| ())
            .map_err(|e| ModelError::VaultEnsureExistsError(e.to_string()))
    }

    /// This function inserts a vault into the database
    pub async fn insert<'e, E>(&self, executor: E, schema: &str) -> Result<Self, ModelError>
    where
        E: Executor<'e, Database = Postgres>,
    {
        let query = format!(
            r#"
            INSERT INTO {}.vault (term_id, curve_id, total_shares, current_share_price, position_count, total_assets, market_cap, block_number, log_index, transaction_hash, created_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
            "#,
            schema,
        );

        sqlx::query_as::<_, Vault>(&query)
            .bind(self.term_id.clone())
            .bind(self.curve_id.to_big_decimal()?)
            .bind(self.total_shares.to_big_decimal()?)
            .bind(self.current_share_price.to_big_decimal()?)
            .bind(self.position_count)
            .bind(self.total_assets.to_big_decimal()?)
            .bind(self.market_cap.to_big_decimal()?)
            .bind(self.block_number)
            // this is to avoid race conditions with deposit events. AtomCreate and TripleCreate
            // events are using the insert, but we need to make sure that deposits are going to be
            // able to override the total_assets properly, thus we set the log_index to 0.
            .bind(0)
            .bind(self.transaction_hash.clone())
            .bind(self.created_at)
            .fetch_one(executor)
            .await
            .map_err(|e| ModelError::VaultInsertError(e.to_string()))
    }

    /// This method upserts a vault from share price events with special handling for zero total_shares.
    /// It updates even when block_number/log_index is lower, but only if the current vault has zero total_shares.
    /// NOTE: position_count is intentionally excluded from the UPDATE clause to preserve values set by database triggers.
    pub async fn insert_from_share_price<'e, E>(
        &self,
        schema: &str,
        executor: E,
    ) -> Result<Self, ModelError>
    where
        E: Executor<'e, Database = Postgres>,
    {
        let query = format!(
            r#"
            WITH upsert AS (
                INSERT INTO {0}.vault (
                    term_id, curve_id, total_shares, current_share_price, position_count,
                    total_assets, market_cap, block_number, log_index, transaction_hash,
                    created_at
                )
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
                ON CONFLICT (term_id, curve_id) DO UPDATE SET
                    total_shares = EXCLUDED.total_shares,
                    current_share_price = EXCLUDED.current_share_price,
                    -- position_count is NOT updated here - it's managed by database triggers
                    total_assets = EXCLUDED.total_assets,
                    market_cap = EXCLUDED.market_cap,
                    block_number = EXCLUDED.block_number,
                    log_index = EXCLUDED.log_index,
                    transaction_hash = EXCLUDED.transaction_hash,
                    created_at = EXCLUDED.created_at
                WHERE
                EXCLUDED.block_number > vault.block_number
                OR (
                    EXCLUDED.block_number = vault.block_number
                    AND EXCLUDED.log_index > vault.log_index
                )
                OR vault.total_shares = 0
                RETURNING term_id, curve_id, total_shares, current_share_price, position_count,
                          total_assets, market_cap, block_number, log_index, transaction_hash,
                          created_at
            )
            SELECT * FROM upsert
            UNION ALL
            SELECT term_id, curve_id, total_shares, current_share_price, position_count,
                   total_assets, market_cap, block_number, log_index, transaction_hash,
                   created_at
            FROM {0}.vault
            WHERE term_id = $1 AND curve_id = $2
            AND NOT EXISTS (SELECT 1 FROM upsert)
            "#,
            schema,
        );

        sqlx::query_as::<_, Vault>(&query)
            .bind(self.term_id.clone())
            .bind(self.curve_id.to_big_decimal()?)
            .bind(self.total_shares.to_big_decimal()?)
            .bind(self.current_share_price.to_big_decimal()?)
            .bind(self.position_count)
            .bind(self.total_assets.to_big_decimal()?)
            .bind(self.market_cap.to_big_decimal()?)
            .bind(self.block_number)
            .bind(self.log_index)
            .bind(self.transaction_hash.clone())
            .bind(self.created_at)
            .fetch_one(executor)
            .await
            .map_err(|e| ModelError::VaultInsertFromSharePriceError(e.to_string()))
    }
}
