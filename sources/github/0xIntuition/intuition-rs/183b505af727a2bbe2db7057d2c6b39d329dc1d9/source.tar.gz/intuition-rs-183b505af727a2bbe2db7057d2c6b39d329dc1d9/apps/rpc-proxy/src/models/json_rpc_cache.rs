use std::{fmt::Display, str::FromStr};

use macon::Builder;
use serde::{Deserialize, Serialize};
use sqlx::PgPool;

use crate::{app::App, endpoints::proxy::JsonRpcRequest, error::ApiError};

/// The method enum.
#[allow(clippy::enum_variant_names)]
#[derive(sqlx::Type, Debug, PartialEq, Clone, Serialize, Deserialize)]
#[sqlx(type_name = "rpc_proxy.method")]
pub enum Method {
    #[sqlx(rename = "eth_call")]
    EthCall,
    #[sqlx(rename = "eth_getBlockByNumber")]
    EthBlockByNumber,
    #[sqlx(rename = "eth_getBalance")]
    EthGetBalance,
}

impl FromStr for Method {
    type Err = ApiError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        Ok(match s {
            "eth_call" => Method::EthCall,
            "eth_getBlockByNumber" => Method::EthBlockByNumber,
            "eth_getBalance" => Method::EthGetBalance,
            _ => return Err(ApiError::InvalidInput("Invalid method".to_string())),
        })
    }
}

impl Display for Method {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Method::EthCall => write!(f, "eth_call"),
            Method::EthBlockByNumber => write!(f, "eth_getBlockByNumber"),
            Method::EthGetBalance => write!(f, "eth_getBalance"),
        }
    }
}

/// The share price model.
#[derive(sqlx::FromRow, Debug, PartialEq, Clone, Builder, Serialize, Deserialize)]
#[sqlx(type_name = "json_rpc_cache")]
pub struct JsonRpcCache {
    pub chain_id: i64,
    pub block_number: i64,
    pub method: Method,
    pub to_address: Option<String>,
    pub input: String,
    pub result: String,
}

impl JsonRpcCache {
    /// Insert the share price into the DB.
    pub async fn insert(&self, db: &PgPool, schema: &str) -> Result<Self, sqlx::Error> {
        let query = format!(
            r#"
            INSERT INTO {}.json_rpc_cache (chain_id, block_number, method, to_address, input, result) 
            VALUES ($1::numeric, $2, $3::text::{}.method, $4, $5, $6) 
            RETURNING chain_id, block_number, method as "method", to_address, input, result
            "#,
            schema, schema
        );

        sqlx::query_as::<_, JsonRpcCache>(&query)
            .bind(self.chain_id)
            .bind(self.block_number)
            .bind(self.method.to_string())
            .bind(&self.to_address)
            .bind(&self.input)
            .bind(&self.result)
            .fetch_one(db)
            .await
    }

    /// Find the share price in the DB.
    pub async fn find(
        payload: &JsonRpcRequest,
        chain_id: i64,
        app_state: &App,
        method: Method,
    ) -> Result<Option<Self>, ApiError> {
        let query = format!(
            r#"
            SELECT * FROM {}.json_rpc_cache 
            WHERE chain_id = $1 
            AND block_number = $2 
            AND (($3::text IS NULL AND to_address IS NULL) OR to_address = $3)
            AND input = $4
            "#,
            app_state.env.proxy_schema,
        );

        Ok(sqlx::query_as::<_, JsonRpcCache>(&query)
            .bind(chain_id)
            .bind(
                payload
                    .block_number()?
                    .ok_or(ApiError::JsonRpc("Block number is required".to_string()))?,
            )
            .bind(payload.get_contract_address()?)
            .bind(payload.get_input(method)?)
            .fetch_optional(&app_state.pg_pool)
            .await?)
    }
}
