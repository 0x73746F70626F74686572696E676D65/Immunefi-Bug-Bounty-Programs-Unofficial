use crate::{
    error::ModelError,
    traits::{Model, SimpleCrud},
    types::{FixedBytesWrapper, U256Wrapper},
};
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sqlx::{Executor, Postgres};
use strum_macros::{Display, EnumString};

use async_trait::async_trait;
/// This struct represents an atom in the database.
#[derive(sqlx::FromRow, Debug, PartialEq, Clone, Builder, Serialize, Deserialize)]
#[sqlx(type_name = "atom")]
pub struct Atom {
    pub term_id: FixedBytesWrapper,
    pub wallet_id: String,
    pub creator_id: String,
    pub data: Option<String>,
    pub raw_data: String,
    pub atom_type: AtomType,
    pub emoji: Option<String>,
    pub label: Option<String>,
    pub image: Option<String>,
    pub value_id: Option<FixedBytesWrapper>,
    pub block_number: U256Wrapper,
    pub created_at: DateTime<Utc>,
    pub transaction_hash: String,
    pub resolving_status: AtomResolvingStatus,
    pub log_index: i64,
}

#[derive(sqlx::Type, Clone, Debug, Display, EnumString, PartialEq, Serialize, Deserialize)]
#[sqlx(type_name = "atom_resolving_status")]
pub enum AtomResolvingStatus {
    Pending,
    Resolved,
    Failed,
}

/// This enum represents the type of an atom.
#[derive(sqlx::Type, Clone, Debug, Display, EnumString, PartialEq, Serialize, Deserialize)]
#[sqlx(type_name = "atom_type")]
pub enum AtomType {
    Account,
    ByteObject,
    Book,
    Caip10,
    Caip22,
    FollowAction,
    JsonObject,
    Keywords,
    LikeAction,
    Organization,
    OrganizationPredicate,
    Person,
    PersonPredicate,
    TextObject,
    Thing,
    ThingPredicate,
    Unknown,
}

/// Selection thresholds for [`Atom::find_stale_for_resolution`].
#[derive(Debug, Clone, PartialEq)]
pub struct StaleResolutionParams {
    /// `Pending` atoms untouched for at least this long are re-processed.
    pub pending_min_age_secs: i64,
    /// `Failed` atoms are only retried while younger than this window.
    pub failed_retry_window_hours: i64,
    /// `Failed` atoms are retried at most once per this interval.
    pub failed_min_age_secs: i64,
    /// Max rows returned per call.
    pub limit: i64,
}

/// This is a trait that all models must implement.
impl Model for Atom {}

/// This trait works as a contract for all models that need to be upserted into the database.
#[async_trait]
impl SimpleCrud<FixedBytesWrapper> for Atom {
    /// Upserts the current Atom instance into the database.
    /// Utilizes proper serialization for complex types to ensure type safety and consistency.
    async fn upsert<'e, E>(&self, schema: &str, executor: E) -> Result<Self, ModelError>
    where
        E: Executor<'e, Database = Postgres>,
    {
        let query = format!(
            r#"
            WITH upsert AS (
                INSERT INTO {0}.atom (
                    wallet_id, creator_id, term_id, data, raw_data, type, emoji, label,
                    image, value_id, block_number, created_at, transaction_hash, resolving_status, log_index
                )
                VALUES (
                    $1, $2, $3, $4, $5, $6::text::{0}.atom_type, $7, $8, $9, $10, $11, $12, $13, $14::text::{0}.atom_resolving_status, $15
                )
                ON CONFLICT (term_id) DO UPDATE SET
                    wallet_id = EXCLUDED.wallet_id,
                    creator_id = EXCLUDED.creator_id,
                    data = EXCLUDED.data,
                    raw_data = EXCLUDED.raw_data,
                    type = EXCLUDED.type,
                    emoji = EXCLUDED.emoji,
                    label = EXCLUDED.label,
                    image = EXCLUDED.image,
                    value_id = EXCLUDED.value_id,
                    block_number = EXCLUDED.block_number,
                    created_at = EXCLUDED.created_at,
                    transaction_hash = EXCLUDED.transaction_hash,
                    resolving_status = EXCLUDED.resolving_status,
                    log_index = EXCLUDED.log_index
                RETURNING
                    wallet_id,
                    creator_id,
                    term_id,
                    data,
                    raw_data,
                    type AS atom_type,
                    emoji,
                    label,
                    image,
                    value_id,
                    block_number,
                    created_at,
                    transaction_hash,
                    resolving_status,
                    log_index
            )
            SELECT * FROM upsert
            UNION ALL
            SELECT
                wallet_id,
                creator_id,
                term_id,
                data,
                raw_data,
                type AS atom_type,
                emoji,
                label,
                image,
                value_id,
                block_number,
                created_at,
                transaction_hash,
                resolving_status,
                log_index
            FROM {0}.atom
            WHERE term_id = $3
              AND NOT EXISTS (SELECT 1 FROM upsert)
            "#,
            schema
        );

        sqlx::query_as::<_, Atom>(&query)
            .bind(self.wallet_id.clone())
            .bind(self.creator_id.clone())
            .bind(self.term_id.clone())
            .bind(self.data.clone())
            .bind(self.raw_data.clone())
            .bind(self.atom_type.to_string())
            .bind(self.emoji.clone())
            .bind(self.label.clone())
            .bind(self.image.clone())
            .bind(self.value_id.as_ref())
            .bind(self.block_number.to_big_decimal()?)
            .bind(self.created_at)
            .bind(self.transaction_hash.clone())
            .bind(self.resolving_status.to_string())
            .bind(self.log_index)
            .fetch_one(executor)
            .await
            .map_err(ModelError::from)
    }

    /// Finds an Atom by its ID in the database.
    ///
    /// This method queries the database for an Atom with the given ID and returns
    /// an Option<Atom>. If the Atom is found, it returns Some(Atom), otherwise None.
    ///
    /// # Arguments
    ///
    /// * `id` - The ID of the Atom to find, as a U256Wrapper.
    /// * `pool` - A reference to the database connection pool.
    ///
    /// # Returns
    ///
    /// Returns a Result containing an Option<Atom>. The Result is Err if there's a database error.
    async fn find_by_id<'e, E>(
        term_id: FixedBytesWrapper,
        schema: &str,
        executor: E,
    ) -> Result<Option<Self>, ModelError>
    where
        E: Executor<'e, Database = Postgres>,
    {
        let query = format!(
            r#"
            SELECT wallet_id, 
                   creator_id, 
                   term_id, 
                   data, 
                   raw_data,
                   type as atom_type, 
                   emoji, 
                   label, 
                   image, 
                   value_id,
                   block_number,
                   created_at,
                   transaction_hash,
                   resolving_status,
                   log_index
            FROM {}.atom
            WHERE term_id = $1
            "#,
            schema,
        );

        sqlx::query_as::<_, Atom>(&query)
            .bind(term_id)
            .fetch_optional(executor)
            .await
            .map_err(|e| ModelError::QueryError(e.to_string()))
    }
}

impl Atom {
    /// Marks the atom as resolved
    pub async fn mark_as_resolved<'e, E>(&self, schema: &str, executor: E) -> Result<(), ModelError>
    where
        E: Executor<'e, Database = Postgres>,
    {
        let query = format!(
            r#"UPDATE {}.atom SET resolving_status = 'Resolved' WHERE term_id = $1"#,
            schema
        );

        sqlx::query(&query)
            .bind(self.term_id.clone())
            .execute(executor)
            .await
            .map_err(ModelError::from)
            .map(|_| ())
    }

    /// Marks the atom as failed
    pub async fn mark_as_failed<'e, E>(&self, schema: &str, executor: E) -> Result<(), ModelError>
    where
        E: Executor<'e, Database = Postgres>,
    {
        let query = format!(
            r#"UPDATE {}.atom SET resolving_status = 'Failed' WHERE term_id = $1"#,
            schema
        );

        sqlx::query(&query)
            .bind(self.term_id.clone())
            .execute(executor)
            .await
            .map_err(ModelError::from)
            .map(|_| ())
    }

    /// Writes only the resolver-owned columns (`type`, `emoji`, `label`, `image`,
    /// `resolving_status`) in a single statement.
    ///
    /// Both the decoded consumer (initial classification) and the resolver consumer
    /// (after fetching IPFS / parsing JSON) update these columns. A targeted `UPDATE`
    /// instead of a full-row upsert means a concurrent writer can never resurrect stale
    /// values for columns it does not own, and the status flips in the same statement
    /// as the label/type, so there is no window where an atom is `Resolved` while its
    /// metadata is still `Unknown` (see
    /// `docs/atom-resolver-race-investigation-2026-09-14.md`).
    ///
    /// Returns the number of rows updated (`0` when the atom does not exist).
    pub async fn update_metadata<'e, E>(&self, schema: &str, executor: E) -> Result<u64, ModelError>
    where
        E: Executor<'e, Database = Postgres>,
    {
        let query = format!(
            r#"
            UPDATE {0}.atom
            SET type = $2::text::{0}.atom_type,
                emoji = $3,
                label = $4,
                image = $5,
                resolving_status = $6::text::{0}.atom_resolving_status
            WHERE term_id = $1
            "#,
            schema
        );

        sqlx::query(&query)
            .bind(self.term_id.clone())
            .bind(self.atom_type.to_string())
            .bind(self.emoji.clone())
            .bind(self.label.clone())
            .bind(self.image.clone())
            .bind(self.resolving_status.to_string())
            .execute(executor)
            .await
            .map(|result| result.rows_affected())
            .map_err(ModelError::from)
    }

    /// Finds atoms whose resolution never converged and that the resolver should
    /// (re)process:
    ///
    /// * `Pending` atoms untouched for `pending_min_age_secs` (resolver message lost, or
    ///   a stale write clobbered the final status);
    /// * `Resolved` atoms whose type is still `Unknown` (metadata clobbered after the
    ///   resolver wrote it);
    /// * `Failed` atoms created within `failed_retry_window_hours` whose last attempt is
    ///   older than `failed_min_age_secs` (e.g. IPFS content that had not propagated yet
    ///   when the first attempt ran). Retries stop once the window has passed.
    ///
    /// Atoms without decodable `data` are skipped: there is nothing to resolve.
    /// Newest atoms first, so user-visible rows are repaired before old backlog.
    pub async fn find_stale_for_resolution<'e, E>(
        schema: &str,
        params: &StaleResolutionParams,
        executor: E,
    ) -> Result<Vec<FixedBytesWrapper>, ModelError>
    where
        E: Executor<'e, Database = Postgres>,
    {
        let query = format!(
            r#"
            SELECT term_id
            FROM {0}.atom
            WHERE data IS NOT NULL
              AND data <> ''
              AND (
                (resolving_status = 'Pending'
                    AND updated_at < now() - make_interval(secs => $1))
                OR (resolving_status = 'Resolved' AND type = 'Unknown')
                OR (resolving_status = 'Failed'
                    AND created_at > now() - make_interval(hours => $2)
                    AND updated_at < now() - make_interval(secs => $3))
              )
            ORDER BY created_at DESC
            LIMIT $4
            "#,
            schema
        );

        sqlx::query_scalar::<_, FixedBytesWrapper>(&query)
            .bind(params.pending_min_age_secs as f64)
            .bind(params.failed_retry_window_hours as i32)
            .bind(params.failed_min_age_secs as f64)
            .bind(params.limit)
            .fetch_all(executor)
            .await
            .map_err(ModelError::from)
    }

    /// Returns the updated_at field for an atom given its term_id
    pub async fn get_updated_at<'e, E>(
        term_id: FixedBytesWrapper,
        schema: &str,
        executor: E,
    ) -> Result<Option<DateTime<Utc>>, ModelError>
    where
        E: Executor<'e, Database = Postgres>,
    {
        let query = format!(
            r#"SELECT updated_at FROM {}.atom WHERE term_id = $1"#,
            schema
        );

        sqlx::query_scalar::<_, DateTime<Utc>>(&query)
            .bind(term_id)
            .fetch_optional(executor)
            .await
            .map_err(ModelError::from)
    }

    /// This function decodes the atom data
    pub fn decode_data(data: String) -> Result<String, ModelError> {
        // Remove the "0x" prefix and decode the hex string
        let decoded_data =
            hex::decode(&data[2..]).map_err(|e| ModelError::DecodingError(e.to_string()))?;

        // Try UTF-8 and fail if invalid
        let s = String::from_utf8(decoded_data)
            .map_err(|e| ModelError::DecodingError(e.to_string()))?;
        let filtered_bytes: Vec<u8> = s.as_bytes().iter().filter(|&&b| b != 0).cloned().collect();
        String::from_utf8(filtered_bytes).map_err(|e| ModelError::DecodingError(e.to_string()))
    }

    /// Finds subject, predicate, and object atoms by their IDs in a single query.
    /// Returns a tuple of (subject_atom, predicate_atom, object_atom) if all three exist.
    /// Returns an error if any of the atoms are not found.
    pub async fn find_subject_predicate_object<'e, E>(
        subject_id: FixedBytesWrapper,
        predicate_id: FixedBytesWrapper,
        object_id: FixedBytesWrapper,
        schema: &str,
        executor: E,
    ) -> Result<(Self, Self, Self), ModelError>
    where
        E: Executor<'e, Database = Postgres>,
    {
        let query = format!(
            r#"
            SELECT 
                wallet_id, 
                creator_id, 
                term_id, 
                data, 
                raw_data,
                type as atom_type, 
                emoji, 
                label, 
                image, 
                value_id,
                block_number,
                created_at,
                transaction_hash,
                resolving_status,
                log_index
            FROM {}.atom
            WHERE term_id = $1 OR term_id = $2 OR term_id = $3
            ORDER BY 
                CASE term_id
                    WHEN $1 THEN 1
                    WHEN $2 THEN 2
                    WHEN $3 THEN 3
                END
            "#,
            schema
        );

        let atoms: Vec<Atom> = sqlx::query_as::<_, Atom>(&query)
            .bind(subject_id.clone())
            .bind(predicate_id.clone())
            .bind(object_id.clone())
            .fetch_all(executor)
            .await
            .map_err(|e| ModelError::QueryError(e.to_string()))?;

        if atoms.len() != 3 {
            return Err(ModelError::QueryError(format!(
                "Expected 3 atoms, found {}. Missing atoms for IDs: subject={}, predicate={}, object={}",
                atoms.len(),
                subject_id,
                predicate_id,
                object_id
            )));
        }

        // The ORDER BY ensures atoms are returned in the correct order
        let subject_atom = atoms[0].clone();
        let predicate_atom = atoms[1].clone();
        let object_atom = atoms[2].clone();

        Ok((subject_atom, predicate_atom, object_atom))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_decode_data() {
        let hex_string = "0x697066733a2f2f516d58314b5a3445756e64347639336a364333786b383367667133777477667a5a47327465704e7a714e75764768";
        let expected_output = "ipfs://QmX1KZ4Eund4v93j6C3xk83gfq3wtwfzZG2tepNzqNuvGh";

        // Use the decode_data function
        let result = Atom::decode_data(hex_string.to_string()).expect("Decoding data failed");

        assert_eq!(result, expected_output);
    }
}
