use chrono::{DateTime, Local, Utc};
use ratatui::{
    Frame,
    layout::{Constraint, Rect},
    text::Span,
    widgets::{Block, Borders, Cell, Row, Table},
};

use crate::app::App;

pub fn draw(f: &mut Frame, app: &App, area: Rect) {
    let mut rows: Vec<Row> = vec![];
    if let Some(aggregates) = &app.aggregates {
        rows.push(Row::new(vec![
            Cell::from(Span::raw("Last block")),
            Cell::from(Span::raw(
                aggregates
                    .events
                    .first()
                    .map(|e| e.block_number.to_string())
                    .unwrap_or_default(),
            )),
        ]));

        if let Some(event) = aggregates.events.first()
            && let Ok(block_time) = DateTime::parse_from_rfc3339(&event.created_at)
        {
            let block_time = block_time.with_timezone(&Utc);
            let local_time = DateTime::<Local>::from(block_time);
            let formatted_time = local_time.format("%b %d %Y, %I:%M %p").to_string();

            // Calculate time elapsed
            let now = Utc::now();
            let duration = now.signed_duration_since(block_time);
            let elapsed = format_duration(duration);

            rows.push(Row::new(vec![
                Cell::from(Span::raw("Timestamp")),
                Cell::from(Span::raw(format!("{} - {} ago", formatted_time, elapsed))),
            ]));
        }

        rows.push(Row::new(vec![
            Cell::from(Span::raw("Accounts")),
            Cell::from(Span::raw(
                aggregates
                    .accounts_aggregate
                    .aggregate
                    .as_ref()
                    .unwrap()
                    .count
                    .to_string(),
            )),
        ]));

        rows.push(Row::new(vec![
            Cell::from(Span::raw("Atoms")),
            Cell::from(Span::raw(
                aggregates
                    .atoms_aggregate
                    .aggregate
                    .as_ref()
                    .unwrap()
                    .count
                    .to_string(),
            )),
        ]));

        rows.push(Row::new(vec![
            Cell::from(Span::raw("Triples")),
            Cell::from(Span::raw(
                aggregates
                    .triples_aggregate
                    .aggregate
                    .as_ref()
                    .unwrap()
                    .count
                    .to_string(),
            )),
        ]));
        rows.push(Row::new(vec![
            Cell::from(Span::raw("Predicate Objects")),
            Cell::from(Span::raw(
                aggregates
                    .predicate_objects_aggregate
                    .aggregate
                    .as_ref()
                    .unwrap()
                    .count
                    .to_string(),
            )),
        ]));
        rows.push(Row::new(vec![
            Cell::from(Span::raw("Vaults")),
            Cell::from(Span::raw(
                aggregates
                    .vaults_aggregate
                    .aggregate
                    .as_ref()
                    .unwrap()
                    .count
                    .to_string(),
            )),
        ]));
        rows.push(Row::new(vec![
            Cell::from(Span::raw("Atom Values")),
            Cell::from(Span::raw(
                aggregates
                    .atom_values_aggregate
                    .aggregate
                    .as_ref()
                    .unwrap()
                    .count
                    .to_string(),
            )),
        ]));
        rows.push(Row::new(vec![
            Cell::from(Span::raw("Organizations")),
            Cell::from(Span::raw(
                aggregates
                    .organizations_aggregate
                    .aggregate
                    .as_ref()
                    .unwrap()
                    .count
                    .to_string(),
            )),
        ]));

        rows.push(Row::new(vec![
            Cell::from(Span::raw("Persons")),
            Cell::from(Span::raw(
                aggregates
                    .persons_aggregate
                    .aggregate
                    .as_ref()
                    .unwrap()
                    .count
                    .to_string(),
            )),
        ]));
        rows.push(Row::new(vec![
            Cell::from(Span::raw("Things")),
            Cell::from(Span::raw(
                aggregates
                    .things_aggregate
                    .aggregate
                    .as_ref()
                    .unwrap()
                    .count
                    .to_string(),
            )),
        ]));
        rows.push(Row::new(vec![
            Cell::from(Span::raw("Signals")),
            Cell::from(Span::raw(
                aggregates
                    .signals_aggregate
                    .aggregate
                    .as_ref()
                    .unwrap()
                    .count
                    .to_string(),
            )),
        ]));

        rows.push(Row::new(vec![
            Cell::from(Span::raw("Positions")),
            Cell::from(Span::raw(
                aggregates
                    .positions_aggregate
                    .aggregate
                    .as_ref()
                    .unwrap()
                    .count
                    .to_string(),
            )),
        ]));
        rows.push(Row::new(vec![
            Cell::from(Span::raw("Events")),
            Cell::from(Span::raw(
                aggregates
                    .events_aggregate
                    .aggregate
                    .as_ref()
                    .unwrap()
                    .count
                    .to_string(),
            )),
        ]));
        rows.push(Row::new(vec![
            Cell::from(Span::raw("Deposits")),
            Cell::from(Span::raw(
                aggregates
                    .deposits_aggregate
                    .aggregate
                    .as_ref()
                    .unwrap()
                    .count
                    .to_string(),
            )),
        ]));

        rows.push(Row::new(vec![
            Cell::from(Span::raw("Redemptions")),
            Cell::from(Span::raw(
                aggregates
                    .redemptions_aggregate
                    .aggregate
                    .as_ref()
                    .unwrap()
                    .count
                    .to_string(),
            )),
        ]));

        rows.push(Row::new(vec![
            Cell::from(Span::raw("Fee Transfers")),
            Cell::from(Span::raw(
                aggregates
                    .fee_transfers_aggregate
                    .aggregate
                    .as_ref()
                    .unwrap()
                    .count
                    .to_string(),
            )),
        ]));
    }

    let table = Table::new(rows, vec![Constraint::Percentage(100)])
        .block(Block::default().title("Aggregates").borders(Borders::ALL))
        .widths([Constraint::Max(18), Constraint::Fill(50)]);

    f.render_widget(table, area);
}

// Helper function to format duration in a human-readable way
fn format_duration(duration: chrono::Duration) -> String {
    let seconds = duration.num_seconds();
    if seconds < 60 {
        return format!("{} sec", seconds);
    }

    let minutes = duration.num_minutes();
    if minutes < 60 {
        let remaining_seconds = seconds - (minutes * 60);
        return format!("{} min {} sec", minutes, remaining_seconds);
    }

    let hours = duration.num_hours();
    if hours < 24 {
        let remaining_minutes = minutes - (hours * 60);
        return format!("{} hr {} min", hours, remaining_minutes);
    }

    let days = duration.num_days();
    if days < 30 {
        let remaining_hours = hours - (days * 24);
        return format!("{} days {} hr", days, remaining_hours);
    }

    let months = days / 30; // Approximate months
    if months < 12 {
        let remaining_days = days % 30;
        return format!("{} months {} days", months, remaining_days);
    }

    let years = months / 12; // Years
    let remaining_months = months % 12;
    format!("{} years {} months", years, remaining_months)
}
