import { expect, test, suite } from 'vitest'
import { execute, getIntuition, pinJson, SystemAtom, wait } from './setup/utils.js'
import { graphql } from './graphql/gql.js'

suite('create person triple', async () => {
  const alice = await getIntuition(3)

  const person = await alice.getOrCreateAtom(
    SystemAtom.Person,
  )

  const aliceAccount = await alice.getOrCreateAtom(
    alice.account.address
  )

  const uri = await pinJson({
    '@context': 'https://schema.org',
    '@type': 'Person',
    name: 'Alice',
    description: 'Intern at Intuition Systems',
    email: 'alice@intuition.systems',
    image: 'https://avatars.githubusercontent.com/u/94311139?s=200&v=4',
    url: 'https://intuition.systems',
  })

  const alicePerson = await alice.getOrCreateAtom(uri)

  const triple = await alice.getCreateOrDepositOnTriple(
    aliceAccount.vaultId,
    person.vaultId,
    alicePerson.vaultId,
  )

  expect(person).toBeDefined()
  expect(aliceAccount).toBeDefined()
  expect(uri).toBeDefined()
  expect(alicePerson).toBeDefined()
  expect(triple.vaultId).toBeDefined()

  test('query person', async () => {
    await wait(triple.hash)
    const result = await execute(
      graphql(`query Term($termId: String!) {
        atom(term_id: $termId) {
          label
        }
      }`),
      { termId: alicePerson.vaultId })
    expect(result).toBeDefined()
    expect(result.atom?.label).toBe('Alice')
  })

})
