#!/bin/bash
# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Get the project root (parent directory of scripts)
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
# Source .env from project root if it exists
if [ -f "$PROJECT_ROOT/.env" ]; then
  source "$PROJECT_ROOT/.env"
  # Export all variables so they're available to docker-compose
  export OPENAI_API_KEY
  export PINATA_API_JWT
  export PINATA_GATEWAY_TOKEN
  export BASE_MAINNET_RPC_URL
  export BASE_SEPOLIA_RPC_URL
  export ETHEREUM_MAINNET_RPC_URL
  export ETHEREUM_SEPOLIA_RPC_URL
  export LINEA_MAINNET_RPC_URL
  export LINEA_SEPOLIA_RPC_URL
  export TRUST_TESTNET_RPC_URL
  export TRUST_MAINNET_RPC_URL
  export LOCAL_INTUITION_RPC_URL
  export POLYGON_AMOY_RPC_URL
else
  echo "Warning: .env file not found at $PROJECT_ROOT/.env"
  echo "Some environment variables may not be set. Create a .env file with required variables:"
  echo "  OPENAI_API_KEY=your_openai_key"
  echo "  PINATA_API_JWT=your_pinata_jwt"
  echo "  PINATA_GATEWAY_TOKEN=your_pinata_gateway_token"
  echo "  BASE_MAINNET_RPC_URL=your_base_mainnet_rpc"
  echo "  BASE_SEPOLIA_RPC_URL=your_base_sepolia_rpc"
  echo "  ETHEREUM_MAINNET_RPC_URL=your_ethereum_mainnet_rpc"
  echo "  LINEA_MAINNET_RPC_URL=your_linea_mainnet_rpc"
  echo "  LINEA_SEPOLIA_RPC_URL=your_linea_sepolia_rpc"
  echo "  TRUST_TESTNET_RPC_URL=your_trust_testnet_rpc"
  echo "  TRUST_MAINNET_RPC_URL=your_trust_mainnet_rpc"
fi

# Start shared services
docker compose -p intuition -f docker/docker-compose-shared.yml up database pgai-installer vectorizer-worker redis redis-setup ipfs safe-content graphql-engine indexer-migrations hasura-migrations prometheus grafana -d --wait --force-recreate

export INITIAL_CONTRACT_VERSION="v2"
# First arg is indexer schema
INDEXER_SCHEMA="$1"
CONTRACT_ADDRESS=$(docker compose -p intuition -f docker/docker-compose-shared.yml exec database psql -U postgres -d storage -c "SELECT contract_address FROM histocrawler.app_config WHERE indexer_schema = '$INDEXER_SCHEMA'" -tA)
if [ -n "$CONTRACT_ADDRESS" ]; then
  export INTUITION_CONTRACT_ADDRESS=$CONTRACT_ADDRESS
  export INDEXER_SCHEMA=$INDEXER_SCHEMA
fi

# If started with arg histo_local_1_5 deploy contract to local anvil and get contract address
if [ "$INDEXER_SCHEMA" == "local" ]; then
  docker compose -p intuition -f docker/docker-compose-shared.yml up contract-deployer-2-0 reth -d --wait

  docker compose -f infrastructure/blockscout/docker-compose.yml up -d --wait

  docker compose -p intuition -f docker/docker-compose-shared.yml up contract-verifier-2-0 -d

  # Select contract_address from histocrawler.app_config wait until it changes from 0x63B90A9c109fF8f137916026876171ffeEdEe714 or empty
  while [ "$CONTRACT_ADDRESS" == "0xB4375293a13017BCe71a034bB588786A3D3C7295" ] || [ -z "$CONTRACT_ADDRESS" ]; do
    CONTRACT_ADDRESS=$(docker compose -p intuition -f docker/docker-compose-shared.yml exec database psql -U postgres -d storage -c "SELECT contract_address FROM histocrawler.app_config WHERE indexer_schema = 'local'" -tA)
    sleep 1
  done

  echo -e "\nTo run integration tests in a different terminal, run:"
  echo -e "\n\nexport VITE_INTUITION_CONTRACT_ADDRESS=$CONTRACT_ADDRESS"
  echo "cd integration-tests"
  echo "pnpm test src/create-person.test.ts"

  echo -e "\nExplore the contract on blockscout:"
  echo -e "http://localhost/address/$CONTRACT_ADDRESS?tab=read_write_proxy\n\n"

  # Set env vars
  export VITE_INTUITION_CONTRACT_ADDRESS=$CONTRACT_ADDRESS
  export INTUITION_CONTRACT_ADDRESS=$CONTRACT_ADDRESS
  export INDEXER_SCHEMA="local"
  # Note: BASE_SEPOLIA_RPC_URL is intentionally NOT overridden here.
  # CAIP-22 atoms may reference real NFTs on Base Sepolia, so we need
  # the real RPC URL from .env to fetch tokenURI and metadata.
  # If BASE_SEPOLIA_RPC_URL is not set in .env, it will remain unset.
  export BASE_MAINNET_RPC_URL="http://reth:8545"
  export LOCAL_INTUITION_RPC_URL="http://reth:8545"
fi

if [ "$2" == "test" ]; then
  echo "Starting integration tests"
  docker compose -p intuition -f docker/docker-compose-apps.yml up integration-tests -d --force-recreate
fi

# Start apps
docker compose -p intuition -f docker/docker-compose-apps.yml up resolver_consumer ipfs_upload_consumer decoded_consumer api prod-rpc-proxy histocrawler -d --force-recreate

echo -e "\nGraphQL: http://localhost:8080/console"
# echo -e "Database: https://local.drizzle.studio/"
echo -e "Grafana: http://localhost:3001 (admin/admin)"
echo -e "Prometheus: http://localhost:9090"
echo -e "\n"
