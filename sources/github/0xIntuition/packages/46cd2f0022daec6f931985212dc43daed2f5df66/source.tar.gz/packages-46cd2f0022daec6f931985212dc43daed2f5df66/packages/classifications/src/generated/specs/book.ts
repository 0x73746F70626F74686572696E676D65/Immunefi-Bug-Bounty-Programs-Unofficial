import type { ClassificationSpec } from '../../types.js';

export const book: ClassificationSpec = {
	slug: 'book',
	type: 'Book',
	displayName: 'Book',
	description: 'A book identity with only the title and optional disambiguators.',
	category: 'Creative Work',
	schema: { context: 'https://schema.org/', type: 'Book' },
	metadataPredicates: [
		'authoredBy',
		'publisher',
		'hasCategory',
		'reference',
		'listedIn',
		'sameAs',
	] as const,
	fields: [
		{
			key: 'name',
			schemaProperty: 'name',
			label: 'Title',
			description: 'The title of the book.',
			fieldType: 'string',
			required: true,
			placeholder: 'The Sovereign Individual',
		},
		{
			key: 'author',
			schemaProperty: 'author',
			label: 'Author',
			description: 'The author name when disambiguation is needed.',
			fieldType: 'string',
			required: false,
			placeholder: 'James Dale Davidson',
		},
		{
			key: 'isbn',
			schemaProperty: 'isbn',
			label: 'ISBN',
			description: 'The ISBN identifier when known.',
			fieldType: 'string',
			required: false,
			placeholder: '9780684832720',
		},
		{
			key: 'sameAs',
			schemaProperty: 'sameAs',
			label: 'Canonical References',
			description: 'Canonical URLs that identify the same book.',
			fieldType: 'string[]',
			required: false,
			placeholder: 'https://openlibrary.org/...',
		},
	],
	defaults: { pluginId: 'book' },
	identity: {
		identifies: 'the work; isbn identifies editions, bridged via equivalence',
		ladder: [
			{ kind: 'scheme', scheme: 'isbn', source: { kind: 'field', key: 'isbn' } },
			// D27: T2 community open data
			{ kind: 'scheme', scheme: 'olid', source: { kind: 'same-as' } },
			{ kind: 'scheme', scheme: 'wd', source: { kind: 'same-as' } },
			// D21: author omitted — authorship is an authoredBy triple
			{ kind: 'gen1', tag: 3, recipe: [{ key: 'name', from: 'field' }] },
		],
	},
};
