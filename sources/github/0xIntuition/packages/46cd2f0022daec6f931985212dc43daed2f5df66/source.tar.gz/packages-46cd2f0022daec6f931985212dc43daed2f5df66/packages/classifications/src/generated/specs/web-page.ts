import type { ClassificationSpec } from '../../types.js';

export const webPage: ClassificationSpec = {
	slug: 'web-page',
	type: 'WebPage',
	displayName: 'Web Page',
	description: 'A web page identity with a canonical URL.',
	category: 'Web',
	schema: { context: 'https://schema.org/', type: 'WebPage' },
	metadataPredicates: ['listedIn', 'authoredBy', 'imgUrl', 'url', 'sameAs'] as const,
	fields: [
		{
			key: 'name',
			schemaProperty: 'name',
			label: 'Page Name',
			description: 'The page title or name.',
			fieldType: 'string',
			required: true,
			placeholder: 'Brad Pitt',
		},
		{
			key: 'url',
			schemaProperty: 'url',
			label: 'Page URL',
			description: 'The canonical page URL.',
			fieldType: 'url',
			required: true,
			placeholder: 'https://en.wikipedia.org/wiki/Brad_Pitt',
		},
		{
			key: 'isPartOf',
			schemaProperty: 'isPartOf',
			label: 'Website',
			description: 'The website name or URL that the page belongs to.',
			fieldType: 'string',
			required: false,
			placeholder: 'https://en.wikipedia.org',
		},
		{
			key: 'sameAs',
			schemaProperty: 'sameAs',
			label: 'Canonical References',
			description: 'Canonical URLs that identify the same web page.',
			fieldType: 'string[]',
			required: false,
			placeholder: 'https://example.com/...',
		},
	],
	defaults: { pluginId: 'web-page', provider: 'opengraph' },
	identity: {
		identifies: 'a page at a canonical URL',
		ladder: [{ kind: 'scheme', scheme: 'url', source: { kind: 'field', key: 'url' } }],
	},
};
