import type { ClassificationSpec } from '../../types.js';

export const aggregateRating: ClassificationSpec = {
	slug: 'aggregate-rating',
	type: 'AggregateRating',
	displayName: 'Aggregate Rating',
	description: 'A stable aggregate rating summary for a reviewed thing.',
	category: 'Product',
	schema: { context: 'https://schema.org/', type: 'AggregateRating' },
	metadataPredicates: ['itemReviewed', 'authoredBy'] as const,
	fields: [
		{
			key: 'ratingValue',
			schemaProperty: 'ratingValue',
			label: 'Rating Value',
			description: 'The aggregate average rating.',
			fieldType: 'number',
			required: true,
			placeholder: '4.7',
		},
		{
			key: 'reviewCount',
			schemaProperty: 'reviewCount',
			label: 'Review Count',
			description: 'The number of reviews represented by the aggregate.',
			fieldType: 'integer',
			required: true,
			placeholder: '1320',
		},
		{
			key: 'bestRating',
			schemaProperty: 'bestRating',
			label: 'Best Rating',
			description: 'The upper bound of the rating scale when needed.',
			fieldType: 'number',
			required: false,
			placeholder: '5',
		},
		{
			key: 'worstRating',
			schemaProperty: 'worstRating',
			label: 'Worst Rating',
			description: 'The lower bound of the rating scale when needed.',
			fieldType: 'number',
			required: false,
			placeholder: '1',
		},
	],
	defaults: { pluginId: 'aggregate-rating', provider: 'opengraph' },
	// D23: withdrawn from IID scope — remodeled as a triple
	// (subject —hasAggregateRating→ provider atom).
	identity: null,
};
