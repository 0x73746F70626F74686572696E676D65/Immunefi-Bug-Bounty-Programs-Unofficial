import type { ClassificationSpec } from '../../types.js';

export const comment: ClassificationSpec = {
	slug: 'comment',
	type: 'Comment',
	displayName: 'Comment',
	description: 'A minimal comment identity linked to a stable target.',
	category: 'Creative Work',
	schema: { context: 'https://schema.org/', type: 'Comment' },
	metadataPredicates: ['authoredBy', 'parentItem', 'sameAs'] as const,
	fields: [
		{
			key: 'text',
			schemaProperty: 'text',
			label: 'Comment Text',
			description: 'The text body of the comment.',
			fieldType: 'string',
			required: true,
			placeholder: 'This launch thread is incredibly useful.',
		},
		{
			key: 'about',
			schemaProperty: 'about',
			label: 'Target',
			description: 'The target identifier or URL the comment is about.',
			fieldType: 'string',
			required: false,
			placeholder: 'https://example.com/posts/launch-thread',
		},
		{
			key: 'dateCreated',
			schemaProperty: 'dateCreated',
			label: 'Date Created',
			description: 'The date the comment was created.',
			fieldType: 'iso-date',
			required: false,
			placeholder: '2026-02-26',
		},
		{
			key: 'sameAs',
			schemaProperty: 'sameAs',
			label: 'Canonical References',
			description: 'Canonical URLs for the same comment.',
			fieldType: 'string[]',
			required: false,
			placeholder: 'https://example.com/posts/launch-thread#comment-42',
		},
	],
	defaults: { pluginId: 'comment', provider: 'social-media-posting' },
	identity: {
		identifies: 'one comment on one subject (relational entity)',
		ladder: [{ kind: 'scheme', scheme: 'url', source: { kind: 'same-as' } }],
	},
};
