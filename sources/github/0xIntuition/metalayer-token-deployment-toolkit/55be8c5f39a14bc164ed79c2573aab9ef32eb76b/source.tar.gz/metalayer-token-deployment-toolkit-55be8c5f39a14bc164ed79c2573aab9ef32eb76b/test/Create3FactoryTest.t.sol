// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.29;

import { CREATE3 } from "solmate/utils/CREATE3.sol";
import { Test } from "forge-std/src/Test.sol";

import { Create3Factory } from "src/Create3Factory.sol";
import { MockToken } from "test/mocks/MockToken.sol";

/// @dev Simple target contract to validate constructor args and value forwarding
contract TestCreate3Target {
    uint256 public storedConstructorValue;
    address public storedCreator;
    uint256 public storedValueSent;

    constructor(uint256 constructorValue) payable {
        storedConstructorValue = constructorValue;
        storedCreator = msg.sender;
        storedValueSent = msg.value;
    }
}

contract Create3FactoryTest is Test {
    Create3Factory internal create3Factory;

    event ContractDeployed(bytes32 indexed salt, address indexed deployedAddress);

    function setUp() public {
        create3Factory = new Create3Factory();
    }

    /* ===================================================== */
    /*                      Unit Tests                       */
    /* ===================================================== */

    function test_deploy_singleContract_emitsEventAndDeploysToExpectedAddress() public {
        bytes32 salt = keccak256("create3.factory.single.deploy");
        uint256 constructorValue = 123;

        bytes memory creationCode = abi.encodePacked(type(TestCreate3Target).creationCode, abi.encode(constructorValue));

        // Expected deterministic address for this salt, from the factory's point of view
        address expectedDeployedAddress = create3Factory.getDeployedAddress(salt);

        // Expect correct event emission
        vm.expectEmit(true, true, true, true);
        emit ContractDeployed(salt, expectedDeployedAddress);

        address deployedAddress = create3Factory.deploy(salt, creationCode);

        assertEq(
            deployedAddress, expectedDeployedAddress, "Deployed address does not match expected deterministic address"
        );
        assertGt(deployedAddress.code.length, 0, "Deployed contract has no code");

        TestCreate3Target deployedContract = TestCreate3Target(deployedAddress);
        assertEq(
            deployedContract.storedConstructorValue(), constructorValue, "Constructor value was not stored correctly"
        );
        // With CREATE3, the final contract is created by the proxy, not by the factory or test
        assertEq(deployedContract.storedValueSent(), 0, "Value should be zero in this test");
    }

    function test_deploy_withValue_forwardsEtherToDeployedContract() public {
        bytes32 salt = keccak256("create3.factory.value.forwarding");
        uint256 constructorValue = 42;
        uint256 valueToSend = 1 ether;

        bytes memory creationCode = abi.encodePacked(type(TestCreate3Target).creationCode, abi.encode(constructorValue));

        address expectedDeployedAddress = create3Factory.getDeployedAddress(salt);

        vm.deal(address(this), valueToSend);

        vm.expectEmit(true, true, true, true);
        emit ContractDeployed(salt, expectedDeployedAddress);

        address deployedAddress = create3Factory.deploy{ value: valueToSend }(salt, creationCode);

        assertEq(
            deployedAddress, expectedDeployedAddress, "Deployed address does not match expected deterministic address"
        );

        TestCreate3Target deployedContract = TestCreate3Target(deployedAddress);
        assertEq(
            deployedContract.storedConstructorValue(), constructorValue, "Constructor value was not stored correctly"
        );
        assertEq(deployedContract.storedValueSent(), valueToSend, "Value was not forwarded to the deployed contract");
        assertEq(address(deployedAddress).balance, valueToSend, "Deployed contract balance is incorrect");
    }

    function test_deploy_sameSaltTwice_revertsWithDeploymentFailedError() public {
        bytes32 salt = keccak256("create3.factory.same.salt");
        uint256 constructorValue = 1;

        bytes memory creationCode = abi.encodePacked(type(TestCreate3Target).creationCode, abi.encode(constructorValue));

        // First deploy should succeed
        create3Factory.deploy(salt, creationCode);

        // Second deploy with the same salt should revert with DEPLOYMENT_FAILED
        bytes memory expectedRevertData = abi.encodeWithSignature("Error(string)", "DEPLOYMENT_FAILED");

        vm.expectRevert(expectedRevertData);
        create3Factory.deploy(salt, creationCode);
    }

    function test_deploy_withInvalidCreationCode_revertsWithInitializationFailedError() public {
        bytes32 salt = keccak256("create3.factory.invalid.creation.code");

        // Empty creation code leads to INITIALIZATION_FAILED in CREATE3
        bytes memory invalidCreationCode = "";

        bytes memory expectedRevertData = abi.encodeWithSignature("Error(string)", "INITIALIZATION_FAILED");

        vm.expectRevert(expectedRevertData);
        create3Factory.deploy(salt, invalidCreationCode);
    }

    function test_getDeployedAddress_matchesDeploymentAddress_beforeAndAfterDeployment() public {
        bytes32 salt = keccak256("create3.factory.get.address");
        uint256 constructorValue = 777;

        bytes memory creationCode = abi.encodePacked(type(TestCreate3Target).creationCode, abi.encode(constructorValue));

        address predictedAddressBeforeDeployment = create3Factory.getDeployedAddress(salt);
        assertEq(
            predictedAddressBeforeDeployment.code.length, 0, "Predicted address should have no code before deployment"
        );

        address deployedAddress = create3Factory.deploy(salt, creationCode);

        assertEq(deployedAddress, predictedAddressBeforeDeployment, "Deployed address does not match predicted address");
        address predictedAddressAfterDeployment = create3Factory.getDeployedAddress(salt);

        assertEq(
            predictedAddressAfterDeployment, deployedAddress, "Predicted address after deployment does not match actual"
        );
        assertGt(deployedAddress.code.length, 0, "Deployed address should have code after deployment");
    }

    function test_deploy_canBeCalledByAnySender() public {
        bytes32 salt = keccak256("create3.factory.access.control");
        uint256 constructorValue = 999;

        bytes memory creationCode = abi.encodePacked(type(TestCreate3Target).creationCode, abi.encode(constructorValue));

        address externalCaller = address(0xABCDEF);
        vm.deal(externalCaller, 1 ether);

        address expectedDeployedAddress = create3Factory.getDeployedAddress(salt);

        vm.prank(externalCaller);
        address deployedAddress = create3Factory.deploy(salt, creationCode);

        assertEq(
            deployedAddress, expectedDeployedAddress, "Deployed address does not match expected deterministic address"
        );
        assertGt(deployedAddress.code.length, 0, "Deployed contract has no code");
    }

    function testFuzz_deploy_deterministicAddressMatchesGetDeployedAddress(
        bytes32 salt,
        uint256 constructorValue
    )
        public
    {
        // Normalize constructorValue a bit just to keep traces clean
        constructorValue = constructorValue % 1e18;

        bytes memory creationCode = abi.encodePacked(type(TestCreate3Target).creationCode, abi.encode(constructorValue));

        address predictedAddress = create3Factory.getDeployedAddress(salt);
        address deployedAddress = create3Factory.deploy(salt, creationCode);

        assertEq(deployedAddress, predictedAddress, "Deployed address does not match predicted address");

        TestCreate3Target deployedContract = TestCreate3Target(deployedAddress);
        assertEq(
            deployedContract.storedConstructorValue(),
            constructorValue,
            "Constructor value was not stored correctly in fuzzed deployment"
        );
    }

    /* ===================================================== */
    /*               Cross-Chain Forking Test               */
    /* ===================================================== */

    /// @dev Fork test: fork "base" and "intuition", deploy Create3Factory with the same salt,
    ///      then deploy a MockToken through each factory and verify that addresses and code match.
    function testFork_deterministicDeploymentAcrossBaseAndIntuition_matchesAddressesAndCode() public {
        // These aliases must exist in foundry.toml under [rpc_endpoints]
        uint256 baseForkId = vm.createFork("base_backup");
        uint256 intuitionForkId = vm.createFork("intuition");

        bytes32 factorySalt = keccak256("intuition.metatoken.create3.factory.test");
        bytes32 tokenSalt = keccak256("intuition.metatoken.create3.mocktoken.v1");

        // Deploy Create3Factory on Base fork
        vm.selectFork(baseForkId);
        Create3Factory baseFactory = new Create3Factory{ salt: factorySalt }();
        address expectedFactoryAddress = address(baseFactory);
        assertGt(expectedFactoryAddress.code.length, 0, "Base factory should have code");

        // Deploy Create3Factory on Intuition fork with the same salt
        vm.selectFork(intuitionForkId);
        Create3Factory intuitionFactory = new Create3Factory{ salt: factorySalt }();

        assertEq(
            address(intuitionFactory),
            expectedFactoryAddress,
            "Create3Factory addresses should match across forks for the same salt and deployer"
        );
        assertGt(address(intuitionFactory).code.length, 0, "Intuition factory should have code");

        // Build MockToken creation code
        bytes memory mockTokenCreationCode =
            abi.encodePacked(type(MockToken).creationCode, abi.encode("Mock USD Coin", "mUSDC", 6));

        // Deploy MockToken via Create3Factory on Base
        vm.selectFork(baseForkId);
        address baseTokenAddress = baseFactory.deploy(tokenSalt, mockTokenCreationCode);
        bytes memory baseTokenCode = baseTokenAddress.code;

        // Deploy MockToken via Create3Factory on Intuition
        vm.selectFork(intuitionForkId);
        address intuitionTokenAddress = intuitionFactory.deploy(tokenSalt, mockTokenCreationCode);
        bytes memory intuitionTokenCode = intuitionTokenAddress.code;

        assertEq(
            intuitionTokenAddress,
            baseTokenAddress,
            "MockToken addresses should match across forks when using the same factory salt and token salt"
        );
        assertEq(intuitionTokenCode, baseTokenCode, "MockToken bytecode should match across forks");

        // Quick sanity check on metadata just to ensure constructor ran on both
        MockToken baseToken = MockToken(baseTokenAddress);
        MockToken intuitionToken = MockToken(intuitionTokenAddress);

        assertEq(baseToken.name(), intuitionToken.name(), "Token names should match");
        assertEq(baseToken.symbol(), intuitionToken.symbol(), "Token symbols should match");
        assertEq(baseToken.decimals(), intuitionToken.decimals(), "Token decimals should match");
    }
}
