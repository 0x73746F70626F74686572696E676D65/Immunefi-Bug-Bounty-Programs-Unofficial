# Metalayer Token Deployment Toolkit

A standardized deployment toolkit for onboarding ERC20 tokens to Metalayer-enabled chains using Caldera's Metalayer protocol. This repository provides deployment scripts and utilities for creating cross-chain token bridges with deterministic addresses across different networks.

## What is Metalayer?

[Metalayer](https://docs.caldera.xyz/metalayer/protocol/metalayer) is Caldera's upgradeable Hyperlane deployment that standardizes cross-chain communication. It enables seamless token bridging, intents, and message passing between blockchain networks through a unified protocol. The protocol uses a hub-and-spoke architecture where tokens can be bridged between a canonical source chain (hub) and multiple destination chains (spokes).

## Overview

This toolkit uses contracts originally developed by Caldera (Metalayer team) and has been adapted by Intuition's team to create a standardized deployment system for onboarding assets to Metalayer-enabled chains. The repository includes:

- **MetaERC20Hub & MetaERC20Spoke**: Flattened contract implementations for cross-chain token bridging
- **Create3Factory**: Utility for deterministic contract deployment across chains
- **Deployment Scripts**: Automated scripts for deploying and configuring hub-spoke token bridges
- **Testing Scripts**: Utilities for validating cross-chain token transfers

## Architecture

### MetaERC20Hub

The hub contract is deployed on the canonical token's source chain (e.g. USDC on Base). It:
- Wraps the canonical ERC20 token for cross-chain transfers
- Manages token locking when bridging to spoke chains
- Routes messages through the Metalayer protocol
- Maintains a registry of connected spoke contracts

### MetaERC20Spoke

The spoke contract is deployed on destination chains (e.g. Intuition Mainnet). It:
- Mints synthetic tokens representing the canonical asset
- Burns tokens when bridging back to the hub
- Implements security thresholds for large transfers
- Maintains connection to its corresponding hub contract

### Create3Factory

A utility contract that enables deterministic contract deployment using the CREATE3 pattern. This allows:
- Deploying contracts to the same address across different chains
- Predicting contract addresses before deployment
- Simplifying multi-chain coordination and configuration

The factory uses a salt-based approach where the same salt produces the same contract address regardless of the deployer's address or nonce.

## Deployment Flow

The complete flow for adding cross-chain support for a token involves six steps:

### 1. Deploy Create3Factory (if needed)

Deploy the `Create3Factory` to each chain where you'll deploy hub or spoke contracts.

```bash
forge script script/deploy/DeployCreate3Factory.s.sol:DeployCreate3Factory \
  --rpc-url <network> \
  --broadcast \
  --verify
```

### 2. Deploy MetaERC20Hub

Deploy the hub contract on the canonical token's source chain.

**Key Configuration Variables:**
- `CANONICAL_TOKEN`: Address of the canonical ERC20 token to bridge (e.g. USDC address on Base)
- `HUB_PROXY_SALT`: Unique salt for deterministic deployment (e.g. `keccak256("intuition.metatoken.usdc.v1")`)
- `METALAYER_DOMAIN`: Metalayer domain ID for the hub chain (configured in `SetupScript`)
- `METALAYER_ROUTER`: Metalayer router address for the hub chain (configured in `SetupScript`)
- `TTL_WINDOW`: Time-to-live window for messages (recommended: 1-7 days in production)
- `ADMIN`: Admin address for proxy upgrades and contract management

**Example command:**
```bash
forge script script/deploy/DeployMetaERC20Hub.s.sol:DeployMetaERC20Hub \
  --via-ir \
  --optimizer-runs 10000 \
  --rpc-url base \
  --broadcast \
  --slow \
  --verify \
  --chain 8453 \
  --verifier-url "https://api.etherscan.io/v2/api?chainid=8453" \
  --etherscan-api-key $ETHERSCAN_API_KEY
```

### 3. Deploy MetaERC20Spoke

Deploy the spoke contract on each destination chain.

**Key Configuration Variables:**
- `METALAYER_HUB_DOMAIN`: Metalayer domain ID of the hub chain (e.g. `8453` for Base)
- `TOKEN_NAME`: Display name for the synthetic token (e.g. "USD Coin")
- `TOKEN_SYMBOL`: Symbol for the synthetic token (e.g. "USDC")
- `TOKEN_DECIMALS`: Must match the hub's token decimals (e.g., `6` for USDC)
- `SECURITY_THRESHOLD`: Amount above which transfers must route through hub (set to `0` to route all transfers via hub)
- `SPOKE_PROXY_SALT`: Same salt as hub for matching addresses (e.g., `keccak256("intuition.metatoken.usdc.v1")`)
- `METALAYER_DOMAIN`: Metalayer domain ID for the spoke chain (configured in `SetupScript`)
- `METALAYER_ROUTER`: Metalayer router address for the spoke chain (configured in `SetupScript`)
- `TTL_WINDOW`: Time-to-live window for messages (recommended: 1-7 days in production)
- `ADMIN`: Admin address for proxy upgrades and contract management

**Example:**
```bash
forge script script/deploy/DeployMetaERC20Spoke.s.sol:DeployMetaERC20Spoke \
  --via-ir \
  --optimizer-runs 10000 \
  --rpc-url intuition \
  --broadcast \
  --slow \
  --verify \
  --chain 1155 \
  --verifier blockscout \
  --verifier-url "https://intuition.calderaexplorer.xyz/api/"
```

### 4. Wire Hub with Spoke

Register the spoke contract with the hub to enable hub-to-spoke transfers.

**Key Configuration Variables:**
- `SPOKE_DOMAIN`: Metalayer domain ID of the spoke chain (e.g., `1155` for Intuition Mainnet)
- `HUB_PROXY`: Deployed hub proxy address on the hub chain
- `SPOKE_PROXY`: Deployed spoke proxy address on the spoke chain

**Example:**
```bash
forge script script/wire/WireHubWithSpoke.s.sol:WireHubWithSpoke \
  --via-ir \
  --optimizer-runs 10000 \
  --rpc-url base \
  --broadcast
```

### 5. Wire Spoke with Hub

Register the hub contract with the spoke to enable spoke-to-hub transfers.

**Key Configuration Variables:**
- `HUB_DOMAIN`: Metalayer domain ID of the hub chain (e.g., `8453` for Base)
- `SPOKE_PROXY`: Deployed spoke proxy address on the spoke chain
- `HUB_PROXY`: Deployed hub proxy address on the hub chain
  - If using `Create3Factory`, both hub and spoke addresses will be the same, enabling easier configuration and verification, as well as better UX for end users.

**Example:**
```bash
forge script script/wire/WireSpokeWithHub.s.sol:WireSpokeWithHub \
  --via-ir \
  --optimizer-runs 10000 \
  --rpc-url intuition \
  --broadcast
```

### 6. Test Cross-Chain Bridging

Validate the bridge setup by testing transfers in both directions.

**Hub to Spoke Test:**
```bash
forge script script/test/TestHubToSpoke.s.sol:TestHubToSpoke \
  --via-ir \
  --optimizer-runs 10000 \
  --rpc-url base \
  --broadcast
```

**Spoke to Hub Test:**
```bash
forge script script/test/TestSpokeToHub.s.sol:TestSpokeToHub \
  --via-ir \
  --optimizer-runs 10000 \
  --rpc-url intuition \
  --broadcast
```

### 7. Verify Deployment with Metalayer Router

After all spokes have been deployed and registered with the hub contract, verify the deployment with the Metalayer router service. This step is required to make the token visible in the Metalayer Hub UI and Widget.

**Key Requirements:**
- An API key from the Metalayer team (contact them to obtain one)
- All hub-spoke wiring must be completed before verification
- Separate API keys are used for production vs staging/testnet environments

**Verification Command:**

For production (mainnet) deployments:
```bash
curl -X GET "https://metarouter-production.caldera.dev/metatoken/{CHAIN_ID}/{HUB_ADDRESS}" \
  -H "x-api-key: YOUR_API_KEY"
```

For testnet deployments:
```bash
curl -X GET "https://metarouter-staging.caldera.dev/metatoken/{CHAIN_ID}/{HUB_ADDRESS}" \
  -H "x-api-key: YOUR_API_KEY"
```

**Parameters:**
- `CHAIN_ID`: The chain ID of the hub network (e.g., `8453` for Base)
- `HUB_ADDRESS`: The deployed hub proxy address
- `YOUR_API_KEY`: The API key provided by the Metalayer team

**Example:**
```bash
curl -X GET "https://metarouter-production.caldera.dev/metatoken/8453/0x53e8511faE935cE1B723F855Ca4245E9bAa233D0" \
  -H "x-api-key: YOUR_API_KEY"
```

**Expected Response:**
```json
{
    "metatoken": {
        "address": "0x53e8511faE935cE1B723F855Ca4245E9bAa233D0",
        "chainArchitecture": 1,
        "chainId": 8453,
        "metatokenType": "Hub",
        "tokenAddress": "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"
    },
    "spokes": [
        {
            "address": "0x53e8511faE935cE1B723F855Ca4245E9bAa233D0",
            "chainArchitecture": 1,
            "chainId": 1155,
            "hubAddress": "0x53e8511faE935cE1B723F855Ca4245E9bAa233D0",
            "hubChainArchitecture": 1,
            "hubChainId": 8453,
            "metatokenType": "Spoke",
            "tokenAddress": "0x53e8511faE935cE1B723F855Ca4245E9bAa233D0"
        }
    ]
}
```

**Note:** After verification, it may take up to an hour for the token to appear in the Metalayer Hub UI. Contact the Metalayer team if you need the token to be available sooner.

## Configuration

Network-specific configurations are managed in [SetupScript.sol](script/SetupScript.sol). Key parameters include:

- **METALAYER_DOMAIN**: Unique domain identifier for each chain in the Metalayer protocol
- **METALAYER_ROUTER**: Address of the Metalayer router contract for message routing
- **TTL_WINDOW**: Time window for message validity (recommended: 1-7 days in production, but e.g. 10 minutes is okay for testing)
- **ADMIN**: Admin address with upgrade permissions and contract management rights (we recommend using a multisig wallet where possible)
- **CREATE3_FACTORY**: Address of the deployed Create3Factory for deterministic deployments

These values are automatically loaded based on the target network's chain ID. Note that the specific Metalayer router contract addresses and domain IDs for other Metalayer-supported chains can be found in [Metalayer Docs](https://docs.caldera.xyz/metalayer/resources/contract-deployments).

## Tools & Dependencies

- [Forge](https://github.com/foundry-rs/foundry/blob/master/forge): compile, test, fuzz, format, and deploy smart contracts
- [Forge Std](https://github.com/foundry-rs/forge-std): collection of helpful contracts and utilities for testing
- [Prettier](https://github.com/prettier/prettier): code formatter for non-Solidity files
- [Solhint](https://github.com/protofire/solhint): linter for Solidity code

## Usage

This is a list of the most frequently needed commands.

### Build

Build the contracts:

```sh
$ forge build
```

### Clean

Delete the build artifacts and cache directories:

```sh
$ forge clean
```

### Compile

Compile the contracts:

```sh
$ forge build
```

### Coverage

Get a test coverage report:

```sh
$ forge coverage
```

### Deploy

Deploy to Anvil:

```sh
$ forge script script/Deploy.s.sol --broadcast --fork-url http://localhost:8545
```

For this script to work, you need to have a `MNEMONIC` environment variable set to a valid
[BIP39 mnemonic](https://iancoleman.io/bip39/).

For instructions on how to deploy to a testnet or mainnet, check out the
[Solidity Scripting](https://book.getfoundry.sh/tutorials/solidity-scripting.html) tutorial.

### Format

Format the contracts:

```sh
$ forge fmt
```

### Gas Usage

Get a gas report:

```sh
$ forge test --gas-report
```

### Lint

Lint the contracts:

```sh
$ bun run lint
```

### Test

Run the tests:

```sh
$ forge test
```

### Test Coverage

Generate test coverage and output result to the terminal:

```sh
$ forge coverage
```

### Test Coverage Report

Generate test coverage with lcov report (you'll have to open the `./coverage/index.html` file in your browser, to do so
simply copy paste the path):

```sh
$ forge coverage --report lcov
```

> [!NOTE]
>
> This command requires you to have [`lcov`](https://github.com/linux-test-project/lcov) installed on your machine. On
> macOS, you can install it with Homebrew: `brew install lcov`.

## License

This project is licensed under BUSL-1.1

## Reference Deployments

### Base Mainnet

| Contract Name               | Address                                    | ProxyAdmin                                 |
|-----------------------------|--------------------------------------------|--------------------------------------------|
| MetaERC20Hub (USDC)         | 0x7e41962bE9B2640e653BfA8c8713A905659FE157 | 0x6635a40EA4DdB5aa0Cc720A6883E934f4385AA23 |
| MetaERC20Hub (WETH)         | 0xFB4BAa05BF339AD6074047176F90757A6C87f944 | 0x42d2100553eB21e1CB79864C0BCbFA3C963957c7 |
| Create3Factory              | 0x8a282AF462Eb86bFFd71379c0a5c50a940120ECC | /                                          | 

### Intuition Mainnet

| Contract Name               | Address                                    | ProxyAdmin                                 |
|-----------------------------|--------------------------------------------|--------------------------------------------|
| MetaERC20Spoke (USDC)       | 0x7e41962bE9B2640e653BfA8c8713A905659FE157 | 0x6635a40EA4DdB5aa0Cc720A6883E934f4385AA23 |
| MetaERC20Spoke (WETH)       | 0xFB4BAa05BF339AD6074047176F90757A6C87f944 | 0x42d2100553eB21e1CB79864C0BCbFA3C963957c7 |
| Create3Factory              | 0x8a282AF462Eb86bFFd71379c0a5c50a940120ECC | /                                          |

### Ethereum Mainnet

| Contract Name               | Address                                    | ProxyAdmin                                 |
|-----------------------------|--------------------------------------------|--------------------------------------------|
| Create3Factory              | 0x8a282AF462Eb86bFFd71379c0a5c50a940120ECC | /                                          | 

### Arbitrum Mainnet

| Contract Name               | Address                                    | ProxyAdmin                                 |
|-----------------------------|--------------------------------------------|--------------------------------------------|
| Create3Factory              | 0x8a282AF462Eb86bFFd71379c0a5c50a940120ECC | /                                          |
