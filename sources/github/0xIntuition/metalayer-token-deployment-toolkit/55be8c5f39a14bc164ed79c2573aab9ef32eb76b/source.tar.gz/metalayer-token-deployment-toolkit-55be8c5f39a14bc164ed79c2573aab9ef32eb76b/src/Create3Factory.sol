// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.29;

import { CREATE3 } from "solmate/utils/CREATE3.sol";

/**
 * @title Create3Factory
 * @author 0xIntuition
 * @notice Factory contract for deploying contracts at the same addresses on different networks using CREATE3
 */
contract Create3Factory {
    /**
     * @notice Emitted when a contract is deployed
     * @param salt The salt used for deployment
     * @param deployedAddress The address of the deployed contract
     */
    event ContractDeployed(bytes32 indexed salt, address indexed deployedAddress);

    /**
     * @notice Deploy a contract using CREATE3
     * @param salt The salt for deterministic address generation
     * @param creationCode The contract creation code (encoded together with constructor parameters)
     * @return deployed The address of the deployed contract
     */
    function deploy(bytes32 salt, bytes calldata creationCode) external payable returns (address deployed) {
        deployed = CREATE3.deploy(salt, creationCode, msg.value);
        emit ContractDeployed(salt, deployed);
    }

    /**
     * @notice Get the deployed address for a given salt
     * @param salt The salt used for deployment
     * @return The deterministic address
     */
    function getDeployedAddress(bytes32 salt) external view returns (address) {
        return CREATE3.getDeployed(salt);
    }
}
