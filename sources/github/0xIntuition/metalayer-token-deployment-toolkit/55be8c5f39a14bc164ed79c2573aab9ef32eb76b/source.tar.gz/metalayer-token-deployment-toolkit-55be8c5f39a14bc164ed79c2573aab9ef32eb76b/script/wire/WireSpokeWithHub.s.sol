// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.29;

import { console2 } from "forge-std/src/console2.sol";

import { MetaERC20Spoke } from "src/MetaERC20Spoke.sol";
import { SetupScript } from "script/SetupScript.sol";

/*
LOCAL
forge script script/wire/WireSpokeWithHub.s.sol:WireSpokeWithHub \
--via-ir \
--optimizer-runs 10000 \
--rpc-url anvil \
--broadcast \
--slow

TESTNET
forge script script/wire/WireSpokeWithHub.s.sol:WireSpokeWithHub \
--via-ir \
--optimizer-runs 10000 \
--rpc-url intuition_sepolia \
--broadcast \
--slow

MAINNET
forge script script/wire/WireSpokeWithHub.s.sol:WireSpokeWithHub \
--via-ir \
--optimizer-runs 10000 \
--rpc-url intuition \
--broadcast \
--slow
*/

contract WireSpokeWithHub is SetupScript {
    // Domain ID of Base hub
    uint32 public constant HUB_DOMAIN = 8453;

    // Deployed spoke proxy address on Intuition L3
    address public constant SPOKE_PROXY = 0xFB4BAa05BF339AD6074047176F90757A6C87f944;

    // Deployed hub proxy address on Base
    address public constant HUB_PROXY = 0xFB4BAa05BF339AD6074047176F90757A6C87f944;

    function run() external broadcast {
        MetaERC20Spoke spoke = MetaERC20Spoke(SPOKE_PROXY);

        uint32[] memory domains = new uint32[](1);
        domains[0] = HUB_DOMAIN;

        bytes32[] memory addresses = new bytes32[](1);
        addresses[0] = addressToBytes32(HUB_PROXY);

        spoke.setDomainAddressBatch(domains, addresses);

        console2.log("Registered hub on spoke:");
        console2.log("Domain:", HUB_DOMAIN);
        console2.log("Address:", HUB_PROXY);
    }
}
