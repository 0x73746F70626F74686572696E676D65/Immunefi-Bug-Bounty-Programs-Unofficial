// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.29;

import { console2 } from "forge-std/src/console2.sol";

import { MetaERC20Hub } from "src/MetaERC20Hub.sol";
import { SetupScript } from "script/SetupScript.sol";

/*
LOCAL
forge script script/wire/WireHubWithSpoke.s.sol:WireHubWithSpoke \
--via-ir \
--optimizer-runs 10000 \
--rpc-url anvil \
--broadcast \
--slow

TESTNET
forge script script/wire/WireHubWithSpoke.s.sol:WireHubWithSpoke \
--via-ir \
--optimizer-runs 10000 \
--rpc-url base_sepolia \
--broadcast \
--slow

MAINNET
forge script script/wire/WireHubWithSpoke.s.sol:WireHubWithSpoke \
--via-ir \
--optimizer-runs 10000 \
--rpc-url base \
--broadcast \
--slow
*/

contract WireHubWithSpoke is SetupScript {
    // Domain ID of Intuition L3 spoke
    uint32 public constant SPOKE_DOMAIN = 1155;

    // Deployed hub proxy address on Base (NOTE: Adjust if needed)
    address public constant HUB_PROXY = 0xFB4BAa05BF339AD6074047176F90757A6C87f944;

    // Deployed spoke proxy address on Intuition L3 (NOTE: Adjust if needed)
    address public constant SPOKE_PROXY = 0xFB4BAa05BF339AD6074047176F90757A6C87f944;

    function setUp() public override {
        super.setUp();
    }

    function run() external broadcast {
        MetaERC20Hub hub = MetaERC20Hub(HUB_PROXY);

        uint32[] memory domains = new uint32[](1);
        domains[0] = SPOKE_DOMAIN;

        bytes32[] memory addresses = new bytes32[](1);
        addresses[0] = addressToBytes32(SPOKE_PROXY);

        hub.setDomainAddressBatch(domains, addresses);

        console2.log("Registered spoke on hub:");
        console2.log("Domain:", SPOKE_DOMAIN);
        console2.log("Address:", SPOKE_PROXY);
    }
}
