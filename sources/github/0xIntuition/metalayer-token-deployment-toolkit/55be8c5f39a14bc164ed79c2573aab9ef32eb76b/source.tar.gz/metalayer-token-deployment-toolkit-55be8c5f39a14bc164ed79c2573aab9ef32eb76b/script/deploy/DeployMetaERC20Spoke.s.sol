// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.29;

import { console2 } from "forge-std/src/console2.sol";
import { IERC20Metadata } from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import { Script } from "forge-std/src/Script.sol";
import { TransparentUpgradeableProxy } from "@openzeppelin/contracts/proxy/transparent/TransparentUpgradeableProxy.sol";

import { Create3Factory } from "src/Create3Factory.sol";
import { MetaERC20Spoke } from "src/MetaERC20Spoke.sol";
import { SetupScript } from "script/SetupScript.sol";

/*
LOCAL
forge script script/deploy/DeployMetaERC20Spoke.s.sol:DeployMetaERC20Spoke \
--via-ir \
--optimizer-runs 10000 \
--rpc-url anvil \
--broadcast \
--slow

TESTNET
forge script script/deploy/DeployMetaERC20Spoke.s.sol:DeployMetaERC20Spoke \
--via-ir \
--optimizer-runs 10000 \
--rpc-url intuition_sepolia \
--broadcast \
--slow \
--verify \
--chain 13579 \
--verifier blockscout \
--verifier-url "https://intuition-testnet.explorer.caldera.xyz/api/"

MAINNET
forge script script/deploy/DeployMetaERC20Spoke.s.sol:DeployMetaERC20Spoke \
--via-ir \
--optimizer-runs 10000 \
--rpc-url intuition \
--broadcast \
--slow \
--verify \
--chain 1155 \
--verifier blockscout \
--verifier-url "https://intuition.calderaexplorer.xyz/api/"
*/

contract DeployMetaERC20Spoke is SetupScript {
    // Hub domain (Base) – must match hub's localDomain (NOTE: Adjust if needed)
    uint32 public constant METALAYER_HUB_DOMAIN = 8453;

    // Display metadata (NOTE: Adjust these as needed)
    string public constant TOKEN_NAME = "Wrapped Ether";
    string public constant TOKEN_SYMBOL = "WETH";

    // Must match hub's tokenDecimals
    uint8 public constant TOKEN_DECIMALS = 18;

    // Above this amount, transfers go via hub (0 = everything via hub)
    uint256 public constant SECURITY_THRESHOLD = 0; // NOTE: Adjust if needed

    // Salt for Create3Factory (adjust as needed, e.g. by replacing "usdc" with another token symbol you are deploying
    // for)
    bytes32 public constant SPOKE_PROXY_SALT = keccak256("intuition.metalayer.weth.v1");

    function setUp() public override {
        super.setUp();
    }

    function run() external broadcast {
        // 1. Deploy spoke implementation
        MetaERC20Spoke spokeImplementation = new MetaERC20Spoke();
        contractInfo("MetaERC20Spoke Implementation", address(spokeImplementation));

        // 2. Encode initializer for MetaERC20Spoke
        //
        // Assumed initializer:
        // function initialize(
        //     uint32 _localDomain,
        //     address _metalayerRouter,
        //     uint256 _ttlWindow,
        //     uint8 _metaERC20Version,
        //     uint32 _hubDomain,
        //     string memory name_,
        //     string memory symbol_,
        //     uint8 _tokenDecimals,
        //     uint256 _securityThreshold,
        //     address _initialAdmin
        // )
        bytes memory initializationData = abi.encodeWithSelector(
            MetaERC20Spoke.initialize.selector,
            METALAYER_DOMAIN,
            METALAYER_ROUTER,
            TTL_WINDOW,
            METATOKEN_VERSION,
            METALAYER_HUB_DOMAIN,
            TOKEN_NAME,
            TOKEN_SYMBOL,
            TOKEN_DECIMALS,
            SECURITY_THRESHOLD,
            ADMIN
        );

        // 3. Deploy spoke proxy
        if (CREATE3_FACTORY == address(0)) {
            TransparentUpgradeableProxy spokeProxy = new TransparentUpgradeableProxy(
                address(spokeImplementation), // Implementation address
                ADMIN, // ProxyAdmin owner
                initializationData // Encoded initializer call
            );
            contractInfo("MetaERC20Spoke Proxy", address(spokeProxy));
        } else {
            // Use Create3Factory if it's configured
            bytes memory creationCode = abi.encodePacked(
                type(TransparentUpgradeableProxy).creationCode,
                abi.encode(
                    address(spokeImplementation), // Implementation address
                    ADMIN, // ProxyAdmin owner
                    initializationData // Encoded initializer call
                )
            );
            address spokeProxyAddress = Create3Factory(CREATE3_FACTORY).deploy(SPOKE_PROXY_SALT, creationCode);
            contractInfo("MetaERC20Spoke Proxy", spokeProxyAddress);
        }
    }
}
