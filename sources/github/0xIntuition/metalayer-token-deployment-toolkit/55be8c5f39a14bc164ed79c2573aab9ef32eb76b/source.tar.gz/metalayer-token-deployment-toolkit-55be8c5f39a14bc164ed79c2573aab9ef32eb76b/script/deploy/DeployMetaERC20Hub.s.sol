// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.29;

import { console2 } from "forge-std/src/console2.sol";
import { IERC20Metadata } from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import { Script } from "forge-std/src/Script.sol";
import { TransparentUpgradeableProxy } from "@openzeppelin/contracts/proxy/transparent/TransparentUpgradeableProxy.sol";

import { Create3Factory } from "src/Create3Factory.sol";
import { MetaERC20Hub } from "src/MetaERC20Hub.sol";
import { SetupScript } from "script/SetupScript.sol";

/*
LOCAL
forge script script/deploy/DeployMetaERC20Hub.s.sol:DeployMetaERC20Hub \
--via-ir \
--optimizer-runs 10000 \
--rpc-url anvil \
--broadcast \
--slow

TESTNET
forge script script/deploy/DeployMetaERC20Hub.s.sol:DeployMetaERC20Hub \
--via-ir \
--optimizer-runs 10000 \
--rpc-url base_sepolia \
--broadcast \
--slow \
--verify \
--chain 84532 \
--verifier-url "https://api.etherscan.io/v2/api?chainid=84532" \
--etherscan-api-key $ETHERSCAN_API_KEY

MAINNET
forge script script/deploy/DeployMetaERC20Hub.s.sol:DeployMetaERC20Hub \
--via-ir \
--optimizer-runs 10000 \
--rpc-url base \
--broadcast \
--slow \
--verify \
--chain 8453 \
--verifier-url "https://api.etherscan.io/v2/api?chainid=8453" \
--etherscan-api-key $ETHERSCAN_API_KEY
*/

contract DeployMetaERC20Hub is SetupScript {
    // Canonical Token address (in this example, USDC on Base)
    address public constant CANONICAL_TOKEN = 0x4200000000000000000000000000000000000006;

    // Token decimals
    uint8 public TOKEN_DECIMALS;

    // Salt for Create3Factory (adjust as needed, e.g. by replacing "usdc" with another token symbol you are deploying
    // for)
    bytes32 public constant HUB_PROXY_SALT = keccak256("intuition.metalayer.weth.v1");

    function setUp() public override {
        super.setUp();

        // Fetch token decimals
        TOKEN_DECIMALS = IERC20Metadata(CANONICAL_TOKEN).decimals();
    }

    function run() external broadcast {
        // 1. Deploy hub implementation
        MetaERC20Hub hubImplementation = new MetaERC20Hub();
        contractInfo("MetaERC20Hub Implementation", address(hubImplementation));

        // 2. Encode initializer for MetaERC20Hub
        //
        // function initialize(
        //     uint32 _localDomain,
        //     address _metalayerRouter,
        //     uint256 _ttlWindow,
        //     uint8 _metaERC20Version,
        //     address _wrappedToken,
        //     uint8 _tokenDecimals,
        //     address _initialAdmin
        // )
        bytes memory initializationData = abi.encodeWithSelector(
            MetaERC20Hub.initialize.selector,
            METALAYER_DOMAIN,
            METALAYER_ROUTER,
            TTL_WINDOW,
            METATOKEN_VERSION,
            CANONICAL_TOKEN,
            TOKEN_DECIMALS,
            ADMIN
        );

        // 3. Deploy hub proxy
        if (CREATE3_FACTORY == address(0)) {
            TransparentUpgradeableProxy hubProxy = new TransparentUpgradeableProxy(
                address(hubImplementation), // Implementation address
                ADMIN, // ProxyAdmin owner
                initializationData // Encoded initializer call
            );
            contractInfo("MetaERC20Hub Proxy", address(hubProxy));
        } else {
            // Use Create3Factory if it's configured
            bytes memory creationCode = abi.encodePacked(
                type(TransparentUpgradeableProxy).creationCode,
                abi.encode(
                    address(hubImplementation), // Implementation address
                    ADMIN, // ProxyAdmin owner
                    initializationData // Encoded initializer call
                )
            );
            address hubProxyAddress = Create3Factory(CREATE3_FACTORY).deploy(HUB_PROXY_SALT, creationCode);
            contractInfo("MetaERC20Hub Proxy", hubProxyAddress);
        }
    }
}
