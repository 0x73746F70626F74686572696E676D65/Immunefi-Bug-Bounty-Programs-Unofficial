// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.29;

import { console2 } from "forge-std/src/console2.sol";
import { Script } from "forge-std/src/Script.sol";

abstract contract SetupScript is Script {
    /// @dev The address of the transaction broadcaster.
    address internal broadcaster;

    /* =================================================== */
    /*                   Config Constants                  */
    /* =================================================== */

    // Supported Networks
    uint256 public NETWORK_ARBITRUM = vm.envUint("NETWORK_ARBITRUM");
    uint256 public NETWORK_ARBITRUM_SEPOLIA = vm.envUint("NETWORK_ARBITRUM_SEPOLIA");
    uint256 public NETWORK_BASE = vm.envUint("NETWORK_BASE");
    uint256 public NETWORK_BASE_SEPOLIA = vm.envUint("NETWORK_BASE_SEPOLIA");
    uint256 public NETWORK_INTUITION = vm.envUint("NETWORK_INTUITION");
    uint256 public NETWORK_INTUITION_SEPOLIA = vm.envUint("NETWORK_INTUITION_SEPOLIA");
    uint256 public NETWORK_ETHEREUM = vm.envUint("NETWORK_ETHEREUM");
    uint256 public NETWORK_ETHEREUM_SEPOLIA = vm.envUint("NETWORK_ETHEREUM_SEPOLIA");
    uint256 public NETWORK_ANVIL = vm.envUint("NETWORK_ANVIL");

    /* =================================================== */
    /*                  Network Specific                   */
    /* =================================================== */

    // MetaLayer Configurations
    uint32 public METALAYER_DOMAIN;
    uint8 public constant METATOKEN_VERSION = 1;
    address public METALAYER_ROUTER;
    uint256 public TTL_WINDOW;

    // General Config
    address public ADMIN;
    address public CREATE3_FACTORY;

    constructor() {
        if (block.chainid == NETWORK_BASE) {
            uint256 deployerKey = vm.envUint("DEPLOYER_MAINNET");
            broadcaster = vm.rememberKey(deployerKey);
        } else if (block.chainid == NETWORK_BASE_SEPOLIA) {
            uint256 deployerKey = vm.envUint("DEPLOYER_TESTNET");
            broadcaster = vm.rememberKey(deployerKey);
        } else if (block.chainid == NETWORK_INTUITION) {
            uint256 deployerKey = vm.envUint("DEPLOYER_MAINNET");
            broadcaster = vm.rememberKey(deployerKey);
        } else if (block.chainid == NETWORK_INTUITION_SEPOLIA) {
            uint256 deployerKey = vm.envUint("DEPLOYER_TESTNET");
            broadcaster = vm.rememberKey(deployerKey);
        } else if (block.chainid == NETWORK_ANVIL) {
            uint256 deployerKey = vm.envUint("DEPLOYER_LOCAL");
            broadcaster = vm.rememberKey(deployerKey);
        } else if (block.chainid == NETWORK_ETHEREUM) {
            uint256 deployerKey = vm.envUint("DEPLOYER_MAINNET");
            broadcaster = vm.rememberKey(deployerKey);
        } else if (block.chainid == NETWORK_ETHEREUM_SEPOLIA) {
            uint256 deployerKey = vm.envUint("DEPLOYER_TESTNET");
            broadcaster = vm.rememberKey(deployerKey);
        } else if (block.chainid == NETWORK_ARBITRUM) {
            uint256 deployerKey = vm.envUint("DEPLOYER_MAINNET");
            broadcaster = vm.rememberKey(deployerKey);
        } else if (block.chainid == NETWORK_ARBITRUM_SEPOLIA) {
            uint256 deployerKey = vm.envUint("DEPLOYER_TESTNET");
            broadcaster = vm.rememberKey(deployerKey);
        } else {
            revert("Unsupported chain for broadcasting");
        }
    }

    modifier broadcast() {
        vm.startBroadcast(broadcaster);
        console2.log("Broadcasting from:", broadcaster);
        _;
        vm.stopBroadcast();
    }

    function setUp() public virtual {
        console2.log("NETWORK: =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+");
        info("ChainID:", block.chainid);
        info("Broadcasting:", broadcaster);

        if (block.chainid == NETWORK_BASE) {
            METALAYER_DOMAIN = 8453;
            METALAYER_ROUTER = 0x09cE71C24EE2098e351C0cF2dC6431B414d247f3;
            TTL_WINDOW = 1 days; // NOTE: It's recommended for this value to be 1-7 days in production
            ADMIN = 0xBc01aB3839bE8933f6B93163d129a823684f4CDF;
            CREATE3_FACTORY = 0x8a282AF462Eb86bFFd71379c0a5c50a940120ECC;
        } else if (block.chainid == NETWORK_BASE_SEPOLIA) {
            METALAYER_DOMAIN = 84_532;
            METALAYER_ROUTER = 0x6F23B0211056035A22430a10fD27DED8547dc377;
            TTL_WINDOW = 10 minutes;
            ADMIN = broadcaster;
            CREATE3_FACTORY = 0x8a282AF462Eb86bFFd71379c0a5c50a940120ECC;
        } else if (block.chainid == NETWORK_INTUITION) {
            METALAYER_DOMAIN = 1155;
            METALAYER_ROUTER = 0x09cE71C24EE2098e351C0cF2dC6431B414d247f3;
            TTL_WINDOW = 1 days; // NOTE: It's recommended for this value to be 1-7 days in production
            ADMIN = 0xbeA18ab4c83a12be25f8AA8A10D8747A07Cdc6eb;
            CREATE3_FACTORY = 0x8a282AF462Eb86bFFd71379c0a5c50a940120ECC;
        } else if (block.chainid == NETWORK_INTUITION_SEPOLIA) {
            METALAYER_DOMAIN = 13_579;
            METALAYER_ROUTER = 0x6F23B0211056035A22430a10fD27DED8547dc377;
            TTL_WINDOW = 10 minutes;
            ADMIN = broadcaster;
            CREATE3_FACTORY = 0x8a282AF462Eb86bFFd71379c0a5c50a940120ECC;
        } else if (block.chainid == NETWORK_ETHEREUM) {
            METALAYER_DOMAIN = 1;
            METALAYER_ROUTER = 0x09cE71C24EE2098e351C0cF2dC6431B414d247f3;
            TTL_WINDOW = 10 minutes; // NOTE: It's recommended for this value to be 1-7 days in production
            ADMIN = 0xa28d4AAcA48bE54824dA53a19b05121DE71Ef480;
            CREATE3_FACTORY = 0x8a282AF462Eb86bFFd71379c0a5c50a940120ECC;
        } else if (block.chainid == NETWORK_ETHEREUM_SEPOLIA) {
            METALAYER_DOMAIN = 11_155_111;
            METALAYER_ROUTER = 0x6F23B0211056035A22430a10fD27DED8547dc377;
            TTL_WINDOW = 10 minutes;
            ADMIN = broadcaster;
            CREATE3_FACTORY = 0x8a282AF462Eb86bFFd71379c0a5c50a940120ECC;
        } else if (block.chainid == NETWORK_ARBITRUM) {
            METALAYER_DOMAIN = 42_161;
            METALAYER_ROUTER = 0x09cE71C24EE2098e351C0cF2dC6431B414d247f3;
            TTL_WINDOW = 10 minutes; // NOTE: It's recommended for this value to be 1-7 days in production
            ADMIN = broadcaster;
            CREATE3_FACTORY = 0x8a282AF462Eb86bFFd71379c0a5c50a940120ECC;
        } else if (block.chainid == NETWORK_ARBITRUM_SEPOLIA) {
            METALAYER_DOMAIN = 421_614;
            METALAYER_ROUTER = 0x6F23B0211056035A22430a10fD27DED8547dc377;
            TTL_WINDOW = 10 minutes;
            ADMIN = broadcaster;
            CREATE3_FACTORY = 0x8a282AF462Eb86bFFd71379c0a5c50a940120ECC;
        } else if (block.chainid == NETWORK_ANVIL) {
            METALAYER_DOMAIN = 11_111;
            METALAYER_ROUTER = 0x007700aa28A331B91219Ffa4A444711F0D9E57B5;
            TTL_WINDOW = 10 minutes;
            ADMIN = broadcaster;
        } else {
            revert("Unsupported chain for broadcasting");
        }

        console2.log("");
        console2.log("CONFIGURATION: =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+");
        info("Admin Address", ADMIN);
        info("MetaLayer Domain", METALAYER_DOMAIN);
        info("MetaLayer Router", METALAYER_ROUTER);
        info("TTL Window (s)", TTL_WINDOW);
    }

    function info(string memory label, address addr) internal pure {
        console2.log("");
        console2.log(label);
        console2.log("-------------------------------------------------------------------");
        console2.log(addr);
        console2.log("-------------------------------------------------------------------");
    }

    function info(string memory label, bytes32 data) internal pure {
        console2.log("");
        console2.log(label);
        console2.log("-------------------------------------------------------------------");
        console2.logBytes32(data);
        console2.log("-------------------------------------------------------------------");
    }

    function info(string memory label, uint256 data) internal pure {
        console2.log("");
        console2.log(label);
        console2.log("-------------------------------------------------------------------");
        console2.log(data);
        console2.log("-------------------------------------------------------------------");
    }

    function contractInfo(string memory label, address data) internal pure {
        console2.log(label, ":", data);
    }

    function addressToBytes32(address addr) internal pure returns (bytes32) {
        return bytes32(uint256(uint160(addr)));
    }
}
