// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.29;

import { console2 } from "forge-std/src/console2.sol";
import { IERC20Metadata } from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";

import { MetaERC20Spoke } from "src/MetaERC20Spoke.sol";
import { SetupScript } from "script/SetupScript.sol";

/*
LOCAL
forge script script/test/TestSpokeToHub.s.sol:TestSpokeToHub \
  --via-ir \
  --optimizer-runs 10000 \
  --rpc-url anvil \
  --broadcast \
  --slow

TESTNET
forge script script/test/TestSpokeToHub.s.sol:TestSpokeToHub \
  --via-ir \
  --optimizer-runs 10000 \
  --rpc-url intuition_sepolia \
  --broadcast \
  --slow

MAINNET
forge script script/test/TestSpokeToHub.s.sol:TestSpokeToHub \
  --via-ir \
  --optimizer-runs 10000 \
  --rpc-url intuition \
  --broadcast \
  --slow
*/

contract TestSpokeToHub is SetupScript {
    // ========= PLACEHOLDERS – FILL THESE BEFORE RUNNING =========

    /// @notice Metalayer domain ID of Base hub (NOTE: Adjust if needed)
    uint32 public constant HUB_DOMAIN = 8453;

    /// @notice Deployed spoke proxy address on Intuition L3 (NOTE: Adjust if needed)
    address public constant SPOKE_PROXY = 0xFB4BAa05BF339AD6074047176F90757A6C87f944;

    /// @notice Recipient on Base (will receive bridged tokens)
    address public HUB_RECIPIENT;

    /// @notice Test amount to send back: 0.1 USDC
    uint256 public TEST_AMOUNT;

    function setUp() public override {
        super.setUp();

        // Fetch token decimals
        uint8 tokenDecimals = IERC20Metadata(SPOKE_PROXY).decimals();

        // Set test amount to 0.1 tokens (adjust as needed)
        TEST_AMOUNT = 1 * 10 ** (tokenDecimals - 4);

        HUB_RECIPIENT = broadcaster; // Set to the broadcaster's address for testing
    }

    function run() external broadcast {
        MetaERC20Spoke spoke = MetaERC20Spoke(SPOKE_PROXY);

        uint256 gasFee = spoke.quoteTransferRemote(HUB_DOMAIN, addressToBytes32(HUB_RECIPIENT), TEST_AMOUNT);

        console2.log("Calling spoke.transferRemote to send back to Base hub...");
        spoke.transferRemote{ value: gasFee }(HUB_DOMAIN, addressToBytes32(HUB_RECIPIENT), TEST_AMOUNT);

        console2.log("Spoke -> Hub transfer initiated:");
        console2.log("Spoke proxy:", SPOKE_PROXY);
        console2.log("Hub domain:", HUB_DOMAIN);
        console2.log("Hub recipient:", HUB_RECIPIENT);
        console2.log("Token amount:", TEST_AMOUNT);
        console2.log("Gas fee:", gasFee);
    }
}
