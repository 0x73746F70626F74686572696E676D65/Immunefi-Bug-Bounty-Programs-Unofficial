// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.29;

import { Create3Factory } from "src/Create3Factory.sol";
import { SetupScript } from "script/SetupScript.sol";

/*
LOCAL
forge script script/deploy/DeployCreate3Factory.s.sol:DeployCreate3Factory \
--via-ir \
--optimizer-runs 10000 \
--rpc-url anvil \
--broadcast \
--slow

TESTNET
forge script script/deploy/DeployCreate3Factory.s.sol:DeployCreate3Factory \
--via-ir \
--optimizer-runs 10000 \
--rpc-url intuition_sepolia \
--broadcast \
--slow \
--verify \
--chain 13579 \
--verifier blockscout \
--verifier-url 'https://intuition-testnet.explorer.caldera.xyz/api/'

MAINNET
forge script script/deploy/DeployCreate3Factory.s.sol:DeployCreate3Factory \
--via-ir \
--optimizer-runs 10000 \
--rpc-url intuition \
--broadcast \
--slow \
--verify \
--chain 1155 \
--verifier blockscout \
--verifier-url 'https://intuition.calderaexplorer.xyz/api/'
*/

contract DeployCreate3Factory is SetupScript {
    // Salt for deterministic Create3Factory deployment across chains
    bytes32 public constant CREATE3_FACTORY_SALT = keccak256("intuition.metatoken.create3.factory.v1");

    function setUp() public override {
        super.setUp();
    }

    function run() public broadcast {
        // Deploy Create3Factory using CREATE2 for deterministic address
        Create3Factory factory = new Create3Factory{ salt: CREATE3_FACTORY_SALT }();
        contractInfo("Create3Factory", address(factory));
    }
}
