// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.29;

import { console2 } from "forge-std/src/console2.sol";
import { IERC20 } from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import { IERC20Metadata } from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";

import { MetaERC20Hub } from "src/MetaERC20Hub.sol";
import { SetupScript } from "script/SetupScript.sol";

/*
LOCAL
forge script script/test/TestHubToSpoke.s.sol:TestHubToSpoke \
  --via-ir \
  --optimizer-runs 10000 \
  --rpc-url anvil \
  --broadcast \
  --slow

TESTNET
forge script script/test/TestHubToSpoke.s.sol:TestHubToSpoke \
  --via-ir \
  --optimizer-runs 10000 \
  --rpc-url base_sepolia \
  --broadcast \
  --slow

MAINNET
forge script script/test/TestHubToSpoke.s.sol:TestHubToSpoke \
  --via-ir \
  --optimizer-runs 10000 \
  --rpc-url base \
  --broadcast \
  --slow
*/

contract TestHubToSpoke is SetupScript {
    /// @notice Metalayer domain ID of Intuition L3 spoke (NOTE: Adjust if needed)
    uint32 public constant SPOKE_DOMAIN = 1155;

    /// @notice Deployed hub proxy address on Base (NOTE: Adjust if needed)
    address public constant HUB_PROXY = 0xFB4BAa05BF339AD6074047176F90757A6C87f944;

    // Canonical token address
    address public CANONICAL_TOKEN;

    /// @notice Recipient on Intuition L3 (will receive bridged tokens)
    address public SPOKE_RECIPIENT;

    /// @notice Test amount for bridging
    uint256 public TEST_AMOUNT;

    function setUp() public override {
        super.setUp();

        // Fetch canonical token address
        CANONICAL_TOKEN = MetaERC20Hub(HUB_PROXY).token();

        // Fetch token decimals
        uint8 tokenDecimals = IERC20Metadata(CANONICAL_TOKEN).decimals();

        // Set test amount to 0.2 tokens (adjust as needed)
        TEST_AMOUNT = 2 * 10 ** (tokenDecimals - 4);

        SPOKE_RECIPIENT = broadcaster; // Set to the broadcaster's address for testing
    }

    function run() external broadcast {
        MetaERC20Hub hub = MetaERC20Hub(HUB_PROXY);
        IERC20 canonicalToken = IERC20(CANONICAL_TOKEN);

        console2.log("Approving hub to spend the canonical token...");
        canonicalToken.approve(HUB_PROXY, TEST_AMOUNT);

        uint256 gasFee = hub.quoteTransferRemote(SPOKE_DOMAIN, addressToBytes32(SPOKE_RECIPIENT), TEST_AMOUNT);

        console2.log("Calling hub.transferRemote...");
        hub.transferRemote{ value: gasFee }(SPOKE_DOMAIN, addressToBytes32(SPOKE_RECIPIENT), TEST_AMOUNT);

        console2.log("Hub -> Spoke transfer initiated:");
        console2.log("Hub proxy:", HUB_PROXY);
        console2.log("Spoke domain:", SPOKE_DOMAIN);
        console2.log("Spoke recipient:", SPOKE_RECIPIENT);
        console2.log("Token amount:", TEST_AMOUNT);
        console2.log("Gas fee:", gasFee);
    }
}
