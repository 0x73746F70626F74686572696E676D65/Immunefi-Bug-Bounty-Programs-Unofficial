export * from './DiamondWritable.behavior';
