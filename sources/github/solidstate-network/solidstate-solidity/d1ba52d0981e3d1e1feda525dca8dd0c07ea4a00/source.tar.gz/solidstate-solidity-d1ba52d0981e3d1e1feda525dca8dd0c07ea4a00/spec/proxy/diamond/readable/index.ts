export * from './DiamondReadable.behavior';
