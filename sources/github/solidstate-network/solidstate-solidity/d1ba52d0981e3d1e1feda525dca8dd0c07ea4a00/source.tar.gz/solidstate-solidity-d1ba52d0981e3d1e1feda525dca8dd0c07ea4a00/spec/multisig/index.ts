export * from './ECDSAMultisigWallet.behavior';
