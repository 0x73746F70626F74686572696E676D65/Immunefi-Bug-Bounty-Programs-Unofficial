export * from './DiamondBase.behavior';
