export * from './DiamondFallback.behavior';
