// Copyright 2023-, Edge & Node, GraphOps, and Semiotic Labs.
// SPDX-License-Identifier: Apache-2.0

use std::collections::HashSet;

use indexer_tap_agent::{
    agent::{sender_account::SenderAccountMessage, sender_accounts_manager::AllocationId},
    test::{create_received_receipt_v2, create_sender_account, store_receipt},
};
use ractor::concurrency::Duration;
use serde_json::json;
use test_assets::{ALLOCATION_ID_0, TAP_SIGNER as SIGNER};
use thegraph_core::{alloy::hex::ToHexExt, CollectionId};
use wiremock::{
    matchers::{body_string_contains, method},
    Mock, MockServer, ResponseTemplate,
};

const TRIGGER_VALUE: u128 = 500;

// This test should ensure the full flow starting from
// sender account layer to work, up to closing an allocation
#[tokio::test]
async fn sender_account_layer_test() {
    let test_db = test_assets::setup_shared_test_db().await;
    let pgpool = test_db.pool;
    let mock_server = MockServer::start().await;
    mock_server
        .register(
            Mock::given(method("POST"))
                .and(body_string_contains("paymentsEscrowTransactions"))
                .respond_with(
                    ResponseTemplate::new(200)
                        .set_body_json(json!({ "data": { "paymentsEscrowTransactions": [] } })),
                ),
        )
        .await;
    let _mock_escrow_subgraph_server: MockServer = MockServer::start().await;

    let receipt =
        create_received_receipt_v2(&ALLOCATION_ID_0, &SIGNER.0, 1, 1, TRIGGER_VALUE - 100);
    let signed = receipt.signed_receipt().0.clone();
    store_receipt(&pgpool, &signed).await.unwrap();

    let (sender_account, mut msg_receiver, _, _, _, _) = create_sender_account()
        .pgpool(pgpool.clone())
        .max_amount_willing_to_lose_grt(TRIGGER_VALUE + 1000)
        .network_subgraph_endpoint(&mock_server.uri())
        .call()
        .await;

    // we expect it to create a sender allocation
    let allocation_ids = HashSet::from_iter([AllocationId(CollectionId::from(ALLOCATION_ID_0))]);
    sender_account
        .cast(SenderAccountMessage::UpdateAllocationIds(
            allocation_ids.clone(),
        ))
        .unwrap();
    let msg = msg_receiver.recv().await.expect("Channel failed");
    assert_eq!(
        msg,
        SenderAccountMessage::UpdateAllocationIds(allocation_ids)
    );

    mock_server
        .register(
            Mock::given(method("POST"))
                .and(body_string_contains("ClosedAllocations"))
                .respond_with(ResponseTemplate::new(200).set_body_json(json!({ "data": {
                    "meta": {
                        "block": {
                            "number": 1,
                            "hash": "hash",
                            "timestamp": 1
                        }
                    },
                    "allocations": [
                    {"id": *ALLOCATION_ID_0 }
                    ]
                }
                }))),
        )
        .await;

    // try to delete sender allocation_id
    sender_account
        .cast(SenderAccountMessage::UpdateAllocationIds(HashSet::new()))
        .unwrap();

    sender_account
        .stop_children_and_wait(None, Some(Duration::from_secs(10)))
        .await;

    let collection_id = CollectionId::from(ALLOCATION_ID_0).encode_hex();
    let rav_marked_as_last = sqlx::query(
        r#"
                SELECT * FROM tap_horizon_ravs WHERE last = true AND collection_id = $1;
            "#,
    )
    .bind(collection_id)
    .fetch_all(&pgpool)
    .await
    .expect("Should not fail to fetch from tap_horizon_ravs");
    assert!(!rav_marked_as_last.is_empty());
}
