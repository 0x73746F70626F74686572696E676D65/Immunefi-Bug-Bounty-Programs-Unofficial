// Copyright 2023-, Edge & Node, GraphOps, and Semiotic Labs.
// SPDX-License-Identifier: Apache-2.0

//! Injects tap context to be used by the checks
//!
//! Requires Deployment Id extension to available

use std::sync::Arc;

use axum::{
    body::to_bytes,
    extract::{Path, Request, State},
    middleware::Next,
    response::Response,
    RequestExt,
};
use serde_json::value::RawValue;
use tap_core::receipt::Context;
use thegraph_core::DeploymentId;

use super::sender::Sender;
use crate::{error::IndexerServiceError, tap::AgoraQuery};

/// Graphql query body to be decoded and passed to agora context
#[derive(Debug, serde::Deserialize, serde::Serialize)]
pub struct QueryBody {
    pub query: String,
    pub variables: Option<Box<RawValue>>,
}

/// State for the tap context middleware containing request body size limits
#[derive(Clone)]
pub struct TapContextState {
    /// Maximum allowed request body size in bytes.
    /// Prevents DoS attacks via unbounded request buffering.
    pub max_request_body_size: usize,
}

/// Injects tap context in the extensions to be used by tap_receipt_authorize
pub async fn context_middleware(
    State(state): State<TapContextState>,
    mut request: Request,
    next: Next,
) -> Result<Response, IndexerServiceError> {
    let deployment_id = match request.extensions().get::<DeploymentId>() {
        Some(deployment) => *deployment,
        None => match request.extract_parts::<Path<DeploymentId>>().await {
            Ok(Path(deployment)) => deployment,
            Err(_) => return Err(IndexerServiceError::DeploymentIdNotFound),
        },
    };
    let sender = request.extensions().get::<Sender>().cloned();

    let (mut parts, body) = request.into_parts();
    let bytes = to_bytes(body, state.max_request_body_size).await?;
    let query_body: QueryBody = serde_json::from_slice(&bytes)?;

    let variables = query_body
        .variables
        .as_ref()
        .map(ToString::to_string)
        .unwrap_or_default();

    let mut ctx = Context::new();
    ctx.insert(AgoraQuery {
        deployment_id,
        query: query_body.query.clone(),
        variables,
    });

    if let Some(sender) = sender {
        ctx.insert(sender);
    }
    parts.extensions.insert(Arc::new(ctx));
    let request = Request::from_parts(parts, bytes.into());
    Ok(next.run(request).await)
}

#[cfg(test)]
mod tests {
    use std::sync::Arc;

    use axum::{
        body::Body,
        http::{Extensions, Request},
        middleware::from_fn_with_state,
        routing::get,
        Router,
    };
    use reqwest::StatusCode;
    use tap_core::receipt::Context;
    use test_assets::ESCROW_SUBGRAPH_DEPLOYMENT;
    use tower::ServiceExt;

    use crate::{
        middleware::tap_context::{context_middleware, QueryBody, TapContextState},
        tap::AgoraQuery,
    };

    #[tokio::test]
    async fn test_context_middleware() {
        let state = TapContextState {
            max_request_body_size: 2 * 1024 * 1024,
        };
        let middleware = from_fn_with_state(state, context_middleware);
        let deployment = ESCROW_SUBGRAPH_DEPLOYMENT;
        let query_body = QueryBody {
            query: "hello".to_string(),
            variables: None,
        };
        let body = serde_json::to_string(&query_body).unwrap();

        let handle = move |extensions: Extensions| async move {
            let ctx = extensions
                .get::<Arc<Context>>()
                .expect("Should contain context");
            let agora = ctx.get::<AgoraQuery>().expect("should contain agora query");
            assert_eq!(agora.deployment_id, deployment);
            assert_eq!(agora.query, query_body.query);

            let variables = query_body
                .variables
                .as_ref()
                .map(ToString::to_string)
                .unwrap_or_default();
            assert_eq!(agora.variables, variables);
            Body::empty()
        };

        let app = Router::new().route("/", get(handle)).layer(middleware);

        let res = app
            .oneshot(
                Request::builder()
                    .uri("/")
                    .extension(deployment)
                    .body(body)
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
    }

    #[tokio::test]
    async fn test_context_middleware_rejects_oversized_body() {
        let state = TapContextState {
            max_request_body_size: 10, // Very small limit for testing
        };
        let middleware = from_fn_with_state(state, context_middleware);
        let deployment = ESCROW_SUBGRAPH_DEPLOYMENT;
        let query_body = QueryBody {
            query: "this query is definitely longer than 10 bytes".to_string(),
            variables: None,
        };
        let body = serde_json::to_string(&query_body).unwrap();

        let handle = move |_extensions: Extensions| async move { Body::empty() };

        let app = Router::new().route("/", get(handle)).layer(middleware);

        let res = app
            .oneshot(
                Request::builder()
                    .uri("/")
                    .extension(deployment)
                    .body(body)
                    .unwrap(),
            )
            .await
            .unwrap();
        // Should reject with an error status (body exceeds limit)
        assert_ne!(res.status(), StatusCode::OK);
    }
}
