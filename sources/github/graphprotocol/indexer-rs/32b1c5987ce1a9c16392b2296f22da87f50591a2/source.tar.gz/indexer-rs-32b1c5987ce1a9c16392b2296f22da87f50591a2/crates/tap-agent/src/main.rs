// Copyright 2023-, Edge & Node, GraphOps, and Semiotic Labs.
// SPDX-License-Identifier: Apache-2.0

use indexer_tap_agent::{agent, metrics, CONFIG};
use ractor::ActorStatus;
use tokio::signal::unix::{signal, SignalKind};

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    use anyhow::Context;

    #[cfg(all(feature = "profiling", not(test)))]
    if let Err(e) = profiler::setup_profiling(
        "/opt/profiling/tap-agent".to_string(),
        150,
        120,
        Some("Tap-agent service".to_string()),
    ) {
        // If profiling fails, log the error
        // but continue running the application
        // as profiling is just for development.
        tracing::error!("Failed to setup profiling: {e}");
    } else {
        tracing::info!("Profiling setup complete.");
    }

    // initialize LazyLock'd config
    _ = &*CONFIG;

    // Eagerly initialize all Prometheus metrics before starting the metrics server.
    // This ensures metrics are registered even if no senders have escrow accounts
    // or pending allocations at startup.
    agent::init_metrics();
    tracing::info!("Prometheus metrics initialized");

    let (manager, handler) = agent::start_agent()
        .await
        .with_context(|| "Failed to start TAP agent")?;

    tracing::info!("TAP Agent started.");

    tokio::spawn(metrics::run_server(CONFIG.metrics.port));
    tracing::info!("Metrics port opened");

    // Have tokio wait for SIGTERM or SIGINT.
    let mut signal_sigint = signal(SignalKind::interrupt())?;
    let mut signal_sigterm = signal(SignalKind::terminate())?;
    tokio::select! {
        _ = handler => tracing::error!("SenderAccountsManager stopped"),
        _ = signal_sigint.recv() => tracing::debug!("Received SIGINT."),
        _ = signal_sigterm.recv() => tracing::debug!("Received SIGTERM."),
    }
    // If we're here, we've received a signal to exit.
    tracing::info!("Shutting down...");

    // We don't want our actor to run any shutdown logic, so we kill it.
    if manager.get_status() == ActorStatus::Running {
        manager
            .kill_and_wait(None)
            .await
            .expect("Failed to kill manager.");
    }

    // Stop the server and wait for it to finish gracefully.
    tracing::debug!("Goodbye!");
    Ok(())
}
