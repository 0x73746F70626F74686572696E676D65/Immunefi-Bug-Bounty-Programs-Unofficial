// Copyright 2023-, Edge & Node, GraphOps, and Semiotic Labs.
// SPDX-License-Identifier: Apache-2.0

use std::collections::{HashMap, HashSet};

use indexer_monitor::EscrowAccounts;
use indexer_tap_agent::{
    agent::{
        sender_account::SenderAccountMessage,
        sender_accounts_manager::{AllocationId, SenderAccountsManagerMessage},
        sender_allocation::SenderAllocationMessage,
    },
    test::{
        create_received_receipt_v2, create_sender_accounts_manager, store_receipt, ALLOCATION_ID_0,
        ESCROW_VALUE,
    },
};
use ractor::{ActorRef, ActorStatus};
use serde_json::json;
use test_assets::{assert_while_retry, flush_messages, TAP_SENDER as SENDER, TAP_SIGNER as SIGNER};
use thegraph_core::{alloy::primitives::U256, CollectionId};
use wiremock::{
    matchers::{body_string_contains, method},
    Mock, MockServer, ResponseTemplate,
};

const TRIGGER_VALUE: u128 = 100;

// This test should ensure the full flow starting from
// sender account manager layer to work, up to closing an allocation
#[test_log::test(tokio::test)]
async fn sender_account_manager_layer_test() {
    let test_db = test_assets::setup_shared_test_db().await;
    let pgpool = test_db.pool;
    let mock_network_subgraph_server: MockServer = MockServer::start().await;
    mock_network_subgraph_server
        .register(
            Mock::given(method("POST"))
                .and(body_string_contains("paymentsEscrowTransactions"))
                .respond_with(
                    ResponseTemplate::new(200)
                        .set_body_json(json!({ "data": { "paymentsEscrowTransactions": [] } })),
                ),
        )
        .await;
    mock_network_subgraph_server
        .register(
            Mock::given(method("POST"))
                .and(body_string_contains("ClosedAllocations"))
                .respond_with(ResponseTemplate::new(200).set_body_json(json!({ "data": {
                        "meta": {
                            "block": {
                                "number": 1,
                                "hash": "hash",
                                "timestamp": 1
                            }
                        },
                        "allocations": [
                            {"id": *ALLOCATION_ID_0 }
                        ]
                    }
                }))),
        )
        .await;

    let _mock_escrow_subgraph_server: MockServer = MockServer::start().await;

    let (prefix, mut msg_receiver, (actor, join_handle)) = create_sender_accounts_manager()
        .pgpool(pgpool.clone())
        .network_subgraph(&mock_network_subgraph_server.uri())
        .initial_escrow_accounts_v2(EscrowAccounts::new(
            HashMap::from([(SENDER.1, U256::from(ESCROW_VALUE))]),
            HashMap::from([(SENDER.1, vec![SIGNER.1])]),
        ))
        .call()
        .await;

    actor
        .cast(SenderAccountsManagerMessage::UpdateSenderAccountsV2(
            vec![SENDER.1].into_iter().collect(),
        ))
        .unwrap();
    flush_messages(&mut msg_receiver).await;
    assert_while_retry!({
        ActorRef::<SenderAccountMessage>::where_is(format!(
            "{}:horizon:{}",
            prefix.clone(),
            SENDER.1
        ))
        .is_none()
    });

    // verify if create sender account
    let sender_account_ref = ActorRef::<SenderAccountMessage>::where_is(format!(
        "{}:horizon:{}",
        prefix.clone(),
        SENDER.1
    ));
    assert!(sender_account_ref.is_some());

    let receipt = create_received_receipt_v2(&ALLOCATION_ID_0, &SIGNER.0, 1, 1, TRIGGER_VALUE - 10);
    let signed = receipt.signed_receipt().0.clone();
    store_receipt(&pgpool, &signed).await.unwrap();

    // we expect it to create a sender allocation
    sender_account_ref
        .clone()
        .unwrap()
        .cast(SenderAccountMessage::UpdateAllocationIds(
            vec![AllocationId(CollectionId::from(ALLOCATION_ID_0))]
                .into_iter()
                .collect(),
        ))
        .unwrap();

    assert_while_retry!({
        ActorRef::<SenderAllocationMessage>::where_is(format!(
            "{}:{}:{}",
            prefix, SENDER.1, ALLOCATION_ID_0,
        ))
        .is_none()
    });
    let allocation_ref = ActorRef::<SenderAllocationMessage>::where_is(format!(
        "{}:{}:{}",
        prefix, SENDER.1, ALLOCATION_ID_0,
    ))
    .unwrap();

    // try to delete sender allocation_id
    sender_account_ref
        .clone()
        .unwrap()
        .cast(SenderAccountMessage::UpdateAllocationIds(HashSet::new()))
        .unwrap();
    allocation_ref.wait(None).await.unwrap();
    assert_eq!(allocation_ref.get_status(), ActorStatus::Stopped);

    assert!(ActorRef::<SenderAllocationMessage>::where_is(format!(
        "{}:{}:{}",
        prefix, SENDER.1, ALLOCATION_ID_0,
    ))
    .is_none());

    // this calls and closes acounts manager sender accounts
    actor
        .cast(SenderAccountsManagerMessage::UpdateSenderAccountsV2(
            HashSet::new(),
        ))
        .unwrap();

    sender_account_ref.unwrap().wait(None).await.unwrap();
    // verify if it gets removed
    let actor_ref =
        ActorRef::<SenderAccountMessage>::where_is(format!("{}:horizon:{}", prefix, SENDER.1));
    assert!(actor_ref.is_none());

    let rav_marked_as_last = sqlx::query(
        r#"
            SELECT * FROM tap_horizon_ravs WHERE last;
        "#,
    )
    .fetch_all(&pgpool)
    .await
    .expect("Should not fail to fetch from tap_horizon_ravs");

    assert!(!rav_marked_as_last.is_empty());

    // safely stop the manager
    actor.stop_and_wait(None, None).await.unwrap();
    join_handle.await.unwrap();
}
