// Copyright 2023-, Edge & Node, GraphOps, and Semiotic Labs.
// SPDX-License-Identifier: Apache-2.0

use axum::body::Bytes;
use graphql_client::GraphQLQuery;
use reqwest::{header, Url};
use thegraph_core::DeploymentId;
use tokio::sync::watch::Receiver;

use super::monitor::{monitor_deployment_status, DeploymentStatus};

/// Errors that can occur when querying a subgraph.
#[derive(Debug, thiserror::Error)]
pub enum SubgraphQueryError {
    /// The deployment is not synced or healthy.
    #[error("Deployment '{0}' is not ready or healthy to be queried")]
    DeploymentNotReady(Url),

    /// HTTP request failed.
    #[error("HTTP request failed")]
    HttpRequest(#[source] reqwest::Error),

    /// Failed to parse HTTP response as JSON.
    #[error("Failed to parse response")]
    ResponseParse(#[source] reqwest::Error),

    /// GraphQL query returned errors.
    #[error("GraphQL errors: {0}")]
    GraphQLErrors(String),

    /// GraphQL response contained neither data nor errors.
    #[error("No data or errors in response for query to {0}")]
    EmptyResponse(Url),

    /// GraphQL response contained partial data with errors (unsupported).
    #[error("Partial response with errors (unsupported): {0}")]
    PartialResponse(String),
}

#[derive(Debug, Clone)]
pub struct DeploymentDetails {
    deployment: Option<DeploymentId>,
    status_url: Option<Url>,
    query_url: Url,
    query_auth_token: Option<String>,
}

impl DeploymentDetails {
    pub fn for_graph_node(
        graph_node_status_url: &str,
        graph_node_base_url: &str,
        deployment: DeploymentId,
    ) -> Result<Self, anyhow::Error> {
        Ok(Self::for_graph_node_url(
            Url::parse(graph_node_status_url)?,
            Url::parse(graph_node_base_url)?,
            deployment,
        ))
    }

    pub fn for_graph_node_url(
        graph_node_status_url: Url,
        graph_node_base_url: Url,
        deployment: DeploymentId,
    ) -> Self {
        Self {
            deployment: Some(deployment),
            status_url: Some(graph_node_status_url),
            query_url: graph_node_base_url
                .join(&format!("subgraphs/id/{deployment}"))
                .expect("Must be correct"),
            query_auth_token: None,
        }
    }

    pub fn for_query_url(query_url: &str) -> Result<Self, anyhow::Error> {
        Ok(Self {
            deployment: None,
            status_url: None,
            query_url: Url::parse(query_url)?,
            query_auth_token: None,
        })
    }

    pub fn for_query_url_with_token(query_url: Url, query_auth_token: Option<String>) -> Self {
        Self {
            deployment: None,
            status_url: None,
            query_url,
            query_auth_token,
        }
    }
}

struct DeploymentClient {
    pub http_client: reqwest::Client,
    pub status: Option<Receiver<DeploymentStatus>>,
    pub query_url: Url,
    pub query_auth_token: Option<String>,
}

impl DeploymentClient {
    /// Creates a new deployment client.
    ///
    /// For local deployments (where deployment and status_url are provided), returns `None`
    /// if status monitoring fails to initialize - this ensures we don't query a local
    /// deployment without health/sync checks.
    ///
    /// For remote deployments (no deployment/status_url), always returns `Some`.
    pub async fn new(http_client: reqwest::Client, details: DeploymentDetails) -> Option<Self> {
        let status = match details.deployment.zip(details.status_url) {
            Some((deployment, url)) => {
                match monitor_deployment_status(deployment, url.clone()).await {
                    Ok(receiver) => Some(receiver),
                    Err(e) => {
                        tracing::warn!(
                            deployment = %deployment,
                            status_url = %url,
                            error = %e,
                            "Failed to initialize status monitoring for local deployment; \
                             will use remote query URL only"
                        );
                        return None;
                    }
                }
            }
            None => None,
        };

        Some(Self {
            http_client,
            status,
            query_url: details.query_url,
            query_auth_token: details.query_auth_token,
        })
    }

    pub async fn query<T: GraphQLQuery>(
        &self,
        variables: T::Variables,
    ) -> Result<T::ResponseData, SubgraphQueryError> {
        if let Some(ref status) = self.status {
            let deployment_status = status.borrow();

            if !deployment_status.synced || &deployment_status.health != "healthy" {
                return Err(SubgraphQueryError::DeploymentNotReady(
                    self.query_url.clone(),
                ));
            }
        }

        let body = T::build_query(variables);
        let mut req = self
            .http_client
            .post(self.query_url.as_ref())
            .header(header::USER_AGENT, "indexer-common")
            .json(&body);

        if let Some(token) = self.query_auth_token.as_ref() {
            req = req.header(header::AUTHORIZATION, format!("Bearer {token}"));
        }

        let reqwest_response = req.send().await.map_err(SubgraphQueryError::HttpRequest)?;
        let response: graphql_client::Response<T::ResponseData> = reqwest_response
            .json()
            .await
            .map_err(SubgraphQueryError::ResponseParse)?;

        match (response.data, response.errors) {
            (Some(data), None) => Ok(data),
            (None, Some(errors)) => Err(SubgraphQueryError::GraphQLErrors(format!("{errors:?}"))),
            (Some(_data), Some(errors)) => {
                Err(SubgraphQueryError::PartialResponse(format!("{errors:?}")))
            }
            (None, None) => Err(SubgraphQueryError::EmptyResponse(self.query_url.clone())),
        }
    }

    pub async fn query_raw(&self, body: Bytes) -> Result<reqwest::Response, SubgraphQueryError> {
        if let Some(ref status) = self.status {
            let deployment_status = status.borrow();

            if !deployment_status.synced || &deployment_status.health != "healthy" {
                return Err(SubgraphQueryError::DeploymentNotReady(
                    self.query_url.clone(),
                ));
            }
        }

        let mut req = self
            .http_client
            .post(self.query_url.as_ref())
            .header(header::USER_AGENT, "indexer-common")
            .header(header::CONTENT_TYPE, "application/json")
            .body(body);

        if let Some(token) = self.query_auth_token.as_ref() {
            req = req.header(header::AUTHORIZATION, format!("Bearer {token}"));
        }

        req.send().await.map_err(SubgraphQueryError::HttpRequest)
    }
}

/// Client for a subgraph that can fall back from a local deployment to a remote query URL
pub struct SubgraphClient {
    local_client: Option<DeploymentClient>,
    remote_client: DeploymentClient,
}

impl SubgraphClient {
    pub async fn new(
        http_client: reqwest::Client,
        local_deployment: Option<DeploymentDetails>,
        remote_deployment: DeploymentDetails,
    ) -> Self {
        let local_client = match local_deployment {
            Some(d) => DeploymentClient::new(http_client.clone(), d).await,
            None => None,
        };

        // Remote deployments don't have status monitoring, so this should always succeed
        let remote_client = DeploymentClient::new(http_client, remote_deployment)
            .await
            .expect("Remote deployment client should always initialize successfully");

        Self {
            local_client,
            remote_client,
        }
    }

    pub async fn query<Q, V>(
        &self,
        variables: Q::Variables,
    ) -> Result<Q::ResponseData, SubgraphQueryError>
    where
        Q: GraphQLQuery<Variables = V>,
        V: Clone,
    {
        // Try the local client first; if that fails, log the error and move on
        // to the remote client
        if let Some(ref local_client) = self.local_client {
            match local_client.query::<Q>(variables.clone()).await {
                Ok(response) => return Ok(response),
                Err(err) => tracing::warn!(
                    query_url = %local_client.query_url,
                    error = %err,
                    "Failed to query local subgraph deployment; trying remote deployment next"
                ),
            }
        }

        // Try the remote client
        self.remote_client
            .query::<Q>(variables)
            .await
            .inspect_err(|err| {
                tracing::warn!(
                    query_url = %self.remote_client.query_url,
                    error = %err,
                    "Failed to query remote subgraph deployment"
                );
            })
    }

    pub async fn query_raw(&self, query: Bytes) -> Result<reqwest::Response, SubgraphQueryError> {
        // Try the local client first; if that fails, log the error and move on
        // to the remote client
        if let Some(ref local_client) = self.local_client {
            match local_client.query_raw(query.clone()).await {
                Ok(response) => return Ok(response),
                Err(err) => tracing::warn!(
                    query_url = %local_client.query_url,
                    error = %err,
                    "Failed to query local subgraph deployment; trying remote deployment next"
                ),
            }
        }

        // Try the remote client
        self.remote_client
            .query_raw(query)
            .await
            .inspect_err(|err| {
                tracing::warn!(
                    query_url = %self.remote_client.query_url,
                    error = %err,
                    "Failed to query remote subgraph deployment"
                );
            })
    }
}

#[cfg(test)]
mod test {

    use indexer_query::{current_epoch, user_query, CurrentEpoch, UserQuery};
    use serde_json::json;
    use thegraph_core::deployment_id;
    use wiremock::{
        matchers::{method, path},
        Mock, MockServer, ResponseTemplate,
    };

    use super::*;

    async fn mock_graph_node_server() -> MockServer {
        let mock_server = MockServer::start().await;
        let mock = Mock::given(method("POST"))
            .and(path(format!(
                "/subgraphs/id/{}",
                test_assets::NETWORK_SUBGRAPH_DEPLOYMENT
            )))
            .respond_with(ResponseTemplate::new(200).set_body_raw(
                r#"
                {
                    "data": {
                        "graphNetwork": {
                            "currentEpoch": 960
                        }
                    }
                }
                "#,
                "application/json",
            ));
        mock_server.register(mock).await;

        mock_server
    }

    async fn network_subgraph_client() -> SubgraphClient {
        let url = std::env::var("NETWORK_SUBGRAPH_URL").unwrap();
        SubgraphClient::new(
            reqwest::Client::new(),
            None,
            DeploymentDetails::for_query_url(&url).unwrap(),
        )
        .await
    }

    #[tokio::test]
    #[test_with::env(NETWORK_SUBGRAPH_URL)]
    async fn test_network_query() {
        let _mock_server = mock_graph_node_server().await;

        // Check that the response is valid JSON
        let result = network_subgraph_client()
            .await
            .query::<CurrentEpoch, _>(current_epoch::Variables {})
            .await;

        assert!(result.is_ok());
    }

    #[tokio::test]
    async fn test_uses_local_deployment_if_healthy_and_synced() {
        let deployment = deployment_id!("QmAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");

        let mock_server_status = MockServer::start().await;
        mock_server_status
            .register(Mock::given(method("POST")).respond_with(
                ResponseTemplate::new(200).set_body_json(json!({
                    "data": {
                        "indexingStatuses": [
                            {
                                "synced": true,
                                "health": "healthy"
                            }
                        ]
                    }
                })),
            ))
            .await;

        let mock_server_local = MockServer::start().await;
        mock_server_local
            .register(
                Mock::given(method("POST"))
                    .and(path(format!("/subgraphs/id/{deployment}")))
                    .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                        "data": {
                            "user": {
                                "name": "local"
                            }
                        }
                    }))),
            )
            .await;

        let mock_server_remote = MockServer::start().await;
        mock_server_remote
            .register(
                Mock::given(method("POST"))
                    .and(path(format!("/subgraphs/id/{deployment}")))
                    .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                        "data": {
                            "user": {
                                "name": "remote"
                            }
                        }
                    }))),
            )
            .await;

        // Create the subgraph client
        let client = SubgraphClient::new(
            reqwest::Client::new(),
            Some(
                DeploymentDetails::for_graph_node(
                    &mock_server_status.uri(),
                    &mock_server_local.uri(),
                    deployment,
                )
                .unwrap(),
            ),
            DeploymentDetails::for_query_url(&format!(
                "{}/subgraphs/id/{}",
                mock_server_remote.uri(),
                deployment
            ))
            .unwrap(),
        );

        // Query the subgraph
        let data = client
            .await
            .query::<UserQuery, _>(user_query::Variables {})
            .await
            .expect("Query should succeed");

        assert_eq!(data.user.name, "local".to_string());
    }

    #[tokio::test]
    async fn test_uses_query_url_if_local_deployment_is_unhealthy() {
        let deployment = deployment_id!("QmAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");

        let mock_server_status = MockServer::start().await;
        mock_server_status
            .register(Mock::given(method("POST")).respond_with(
                ResponseTemplate::new(200).set_body_json(json!({
                    "data": {
                        "indexingStatuses": [
                            {
                                "synced": true,
                                "health": "unhealthy"
                            }
                        ]
                    }
                })),
            ))
            .await;

        let mock_server_local = MockServer::start().await;
        mock_server_local
            .register(
                Mock::given(method("POST"))
                    .and(path(format!("/subgraphs/id/{deployment}")))
                    .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                        "data": {
                            "user": {
                                "name": "local"
                            }
                        }
                    }))),
            )
            .await;

        let mock_server_remote = MockServer::start().await;
        mock_server_remote
            .register(
                Mock::given(method("POST"))
                    .and(path(format!("/subgraphs/id/{deployment}")))
                    .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                        "data": {
                            "user": {
                                "name": "remote"
                            }
                        }
                    }))),
            )
            .await;

        // Create the subgraph client
        let client = SubgraphClient::new(
            reqwest::Client::new(),
            Some(
                DeploymentDetails::for_graph_node(
                    &mock_server_status.uri(),
                    &mock_server_local.uri(),
                    deployment,
                )
                .unwrap(),
            ),
            DeploymentDetails::for_query_url(&format!(
                "{}/subgraphs/id/{}",
                mock_server_remote.uri(),
                deployment
            ))
            .unwrap(),
        );

        // Query the subgraph
        let data = client
            .await
            .query::<UserQuery, _>(user_query::Variables {})
            .await
            .expect("Query should succeed");

        assert_eq!(data.user.name, "remote".to_string());
    }

    #[tokio::test]
    async fn test_uses_query_url_if_local_deployment_is_not_synced() {
        let deployment = deployment_id!("QmAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");

        let mock_server_status = MockServer::start().await;
        mock_server_status
            .register(Mock::given(method("POST")).respond_with(
                ResponseTemplate::new(200).set_body_json(json!({
                    "data": {
                        "indexingStatuses": [
                            {
                                "synced": false,
                                "health": "healthy"
                            }
                        ]
                    }
                })),
            ))
            .await;

        let mock_server_local = MockServer::start().await;
        mock_server_local
            .register(
                Mock::given(method("POST"))
                    .and(path(format!("/subgraphs/id/{deployment}")))
                    .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                        "data": {
                            "user": {
                                "name": "local"
                            }
                        }
                    }))),
            )
            .await;

        let mock_server_remote = MockServer::start().await;
        mock_server_remote
            .register(
                Mock::given(method("POST"))
                    .and(path(format!("/subgraphs/id/{deployment}")))
                    .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                        "data": {
                            "user": {
                                "name": "remote"
                            }
                        }
                    }))),
            )
            .await;

        // Create the subgraph client
        let client = SubgraphClient::new(
            reqwest::Client::new(),
            Some(
                DeploymentDetails::for_graph_node(
                    &mock_server_status.uri(),
                    &mock_server_local.uri(),
                    deployment,
                )
                .unwrap(),
            ),
            DeploymentDetails::for_query_url(&format!(
                "{}/subgraphs/id/{}",
                mock_server_remote.uri(),
                deployment
            ))
            .unwrap(),
        );

        // Query the subgraph
        let data = client
            .await
            .query::<UserQuery, _>(user_query::Variables {})
            .await
            .expect("Query should succeed");

        assert_eq!(data.user.name, "remote".to_string());
    }

    #[tokio::test]
    async fn test_degrades_gracefully_when_status_url_unreachable() {
        let deployment = deployment_id!("QmAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");

        // Use a URL that will fail to connect (port 1 is reserved and won't have a listener)
        let unreachable_status_url = "http://127.0.0.1:1";

        let mock_server_local = MockServer::start().await;
        mock_server_local
            .register(
                Mock::given(method("POST"))
                    .and(path(format!("/subgraphs/id/{deployment}")))
                    .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                        "data": {
                            "user": {
                                "name": "local"
                            }
                        }
                    }))),
            )
            .await;

        let mock_server_remote = MockServer::start().await;
        mock_server_remote
            .register(
                Mock::given(method("POST"))
                    .and(path(format!("/subgraphs/id/{deployment}")))
                    .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                        "data": {
                            "user": {
                                "name": "remote"
                            }
                        }
                    }))),
            )
            .await;

        // Create the subgraph client - should NOT panic despite unreachable status URL
        let client = SubgraphClient::new(
            reqwest::Client::new(),
            Some(
                DeploymentDetails::for_graph_node(
                    unreachable_status_url,
                    &mock_server_local.uri(),
                    deployment,
                )
                .unwrap(),
            ),
            DeploymentDetails::for_query_url(&format!(
                "{}/subgraphs/id/{}",
                mock_server_remote.uri(),
                deployment
            ))
            .unwrap(),
        )
        .await;

        // Query should succeed using remote since local client was not created
        // (status monitoring failed, so local deployment is skipped entirely)
        let data = client
            .query::<UserQuery, _>(user_query::Variables {})
            .await
            .expect("Query should succeed");

        // Since status monitoring failed, local_client is None and we use remote only
        assert_eq!(data.user.name, "remote".to_string());
    }
}
