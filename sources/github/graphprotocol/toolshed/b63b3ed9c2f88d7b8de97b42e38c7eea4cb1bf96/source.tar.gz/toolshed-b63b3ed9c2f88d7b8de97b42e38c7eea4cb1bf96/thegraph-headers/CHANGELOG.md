# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.1](https://github.com/edgeandnode/toolshed/compare/thegraph-headers-v0.3.0...thegraph-headers-v0.3.1) - 2025-08-27

### Other

- update crates MSRV to 1.86 and 1.88 ([#595](https://github.com/edgeandnode/toolshed/pull/595))

## [0.3.0](https://github.com/edgeandnode/toolshed/compare/thegraph-headers-v0.2.0...thegraph-headers-v0.3.0) - 2025-05-16

### Other

- updated the following local packages: thegraph-core

## [0.2.0](https://github.com/edgeandnode/toolshed/compare/thegraph-headers-v0.1.5...thegraph-headers-v0.2.0) - 2025-04-17

### Other

- set Rust edition to 2024 ([#519](https://github.com/edgeandnode/toolshed/pull/519))
- updated the following local packages: thegraph-core

## [0.1.5](https://github.com/edgeandnode/toolshed/compare/thegraph-headers-v0.1.4...thegraph-headers-v0.1.5) - 2025-03-19

### Other

- updated the following local packages: thegraph-core
- *(deps)* update rust crate fake to v4 ([#491](https://github.com/edgeandnode/toolshed/pull/491))

## [0.1.4](https://github.com/edgeandnode/toolshed/compare/thegraph-headers-v0.1.3...thegraph-headers-v0.1.4) - 2025-01-27

### Other

- updated the following local packages: thegraph-core


## [0.1.3](https://github.com/edgeandnode/toolshed/compare/thegraph-headers-v0.1.2...thegraph-headers-v0.1.3) - 2025-01-09

### Other

- updated the following local packages: thegraph-core

## [0.1.2](https://github.com/edgeandnode/toolshed/compare/thegraph-headers-v0.1.1...thegraph-headers-v0.1.2) - 2024-12-11

### Other

- *(thegraph-headers)* loose dependencies version requirements (#443)

## [0.1.1](https://github.com/edgeandnode/toolshed/compare/thegraph-headers-v0.1.0...thegraph-headers-v0.1.1) - 2024-12-09

### Added

- *(thegraph-headers)* add typed headers http builder extension trait (#434)
