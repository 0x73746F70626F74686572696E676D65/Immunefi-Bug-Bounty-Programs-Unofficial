# EBOCore
**Inherits:**
[ResolutionManager](/contracts/common/ResolutionManager.sol/abstract.ResolutionManager.md), [AccessManager](/contracts/common/AccessManager.sol/abstract.AccessManager.md), [IEBOCore](/interfaces/modules/IEBOCore.sol/interface.IEBOCore.md)

Contains the core logic for EBO


## Functions
### propose

Creates a new proposal


```solidity
function propose(
  uint256 _epoch,
  string calldata _chainId,
  uint256 _blockNumber,
  address _serviceProvider
) external onlyOperator(_serviceProvider);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_epoch`|`uint256`|The epoch of the proposal|
|`_chainId`|`string`|The chain ID of the proposal|
|`_blockNumber`|`uint256`|The block number of the proposal|
|`_serviceProvider`|`address`|The address of the service provider|


### dispute

Disputes a proposal


```solidity
function dispute(uint256 _proposalId, address _serviceProvider) external onlyOperator(_serviceProvider);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_serviceProvider`|`address`|The address of the service provider|


### resolve

Resolves a non-escalated dispute

*This function penalizes losing bonders*


```solidity
function resolve(uint256 _proposalId) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|


### resolve

Resolves a non-escalated dispute

*This function penalizes losing bonders*


```solidity
function resolve(uint256 _proposalId, ProposalStatus _resolutionStatus) external onlyArbitrator;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_resolutionStatus`|`ProposalStatus`||


### finalize

Finalizes a proposal


```solidity
function finalize(uint256 _proposalId) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|


### amendEpochBlock

Amends the epoch block of a proposal

*Only the arbitrator can force data availability in case there was a mistake in the system*


```solidity
function amendEpochBlock(uint256 _proposalId, uint256 _blockNumber) external onlyArbitrator;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_blockNumber`|`uint256`|The amending block number for the proposal|


