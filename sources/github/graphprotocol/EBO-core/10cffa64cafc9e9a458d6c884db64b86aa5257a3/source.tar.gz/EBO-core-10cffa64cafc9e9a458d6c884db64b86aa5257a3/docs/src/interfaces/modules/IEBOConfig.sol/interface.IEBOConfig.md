# IEBOConfig
**Inherits:**
[IAccessManager](/interfaces/common/IAccessManager.sol/interface.IAccessManager.md)

Interface for the EBOConfig module


## Functions
### setArbitrator

Sets the arbitrator


```solidity
function setArbitrator(address _arbitrator) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_arbitrator`|`address`|The address of the arbitrator|


### setPendingCouncil

Sets the pending council


```solidity
function setPendingCouncil(address _pendingCouncil) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_pendingCouncil`|`address`|The address of the pending council|


### confirmCouncil

Confirms the council


```solidity
function confirmCouncil() external;
```

### setGRT

Sets the GRT token contract


```solidity
function setGRT(IERC20 _grt) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_grt`|`IERC20`|The address of the GRT token contract|


### setHorizonStaking

Sets the HorizonStaking contract


```solidity
function setHorizonStaking(IHorizonStaking _horizonStaking) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_horizonStaking`|`IHorizonStaking`|The address of the HorizonStaking contract|


### setEpochManager

Sets the EpochManager contract


```solidity
function setEpochManager(IEpochManager _epochManager) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_epochManager`|`IEpochManager`|The address of the EpochManager contract|


### addChainIds

Add an array of chain IDs


```solidity
function addChainIds(string[] calldata _chainIds) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_chainIds`|`string[]`|The chain IDs|


### removeChainIds

Removes an array of chain IDs


```solidity
function removeChainIds(string[] calldata _chainIds) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_chainIds`|`string[]`|The chain IDs|


### setParameters

Sets the parameters for proposals and disputes


```solidity
function setParameters(IEBOStorage.Parameters calldata _parameters, uint256 _arbitratorResolutionWindow) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_parameters`|`IEBOStorage.Parameters`|The parameters for proposals and disputes|
|`_arbitratorResolutionWindow`|`uint256`|The arbitrator resolution window|


## Events
### ArbitratorSet
Emitted when the arbitrator is set


```solidity
event ArbitratorSet(address indexed _arbitrator);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_arbitrator`|`address`|The address of the arbitrator|

### PendingCouncilSet
Emitted when the pending council is set


```solidity
event PendingCouncilSet(address indexed _pendingCouncil);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_pendingCouncil`|`address`|The address of the pending council|

### CouncilSet
Emitted when the council is set


```solidity
event CouncilSet(address indexed _council);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_council`|`address`|The address of the council|

### GRTSet
Emitted when the GRT token contract is set


```solidity
event GRTSet(IERC20 indexed _grt);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_grt`|`IERC20`|The address of the GRT token contract|

### HorizonStakingSet
Emitted when the HorizonStaking contract is set


```solidity
event HorizonStakingSet(IHorizonStaking indexed _horizonStaking);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_horizonStaking`|`IHorizonStaking`|The address of the HorizonStaking contract|

### EpochManagerSet
Emitted when the EpochManager contract is set


```solidity
event EpochManagerSet(IEpochManager indexed _epochManager);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_epochManager`|`IEpochManager`|The address of the EpochManager contract|

### StartEpochSet
Emitted when the start epoch is set

*To be set only once during initialization*


```solidity
event StartEpochSet(uint256 _startEpoch);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_startEpoch`|`uint256`|The start epoch|

### ChainIdAdded
Emitted when a chain ID is added


```solidity
event ChainIdAdded(string indexed _chainId);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_chainId`|`string`|The chain ID|

### ChainIdRemoved
Emitted when a chain ID is removed


```solidity
event ChainIdRemoved(string indexed _chainId);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_chainId`|`string`|The chain ID|

### ParametersSet
Emitted when the parameters for proposals and disputes are set


```solidity
event ParametersSet(
  IEBOStorage.Parameters _parameters, uint256 indexed _parametersSnapshotId, uint256 _arbitratorResolutionWindow
);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_parameters`|`IEBOStorage.Parameters`|The parameters for proposals and disputes|
|`_parametersSnapshotId`|`uint256`|The snapshot ID of the parameters|
|`_arbitratorResolutionWindow`|`uint256`|The arbitrator resolution window|

## Errors
### EBOConfig_SetArbitrator_AddressAlreadySet
Thrown when setting the arbitrator with an address that is already set


```solidity
error EBOConfig_SetArbitrator_AddressAlreadySet();
```

### EBOConfig_SetPendingCouncil_AddressAlreadySet
Thrown when setting the pending council with an address that is already set


```solidity
error EBOConfig_SetPendingCouncil_AddressAlreadySet();
```

### EBOConfig_SetCouncil_AddressAlreadySet
Thrown when setting the council with an address that is already set


```solidity
error EBOConfig_SetCouncil_AddressAlreadySet();
```

### EBOConfig_SetGRT_AddressAlreadySet
Thrown when setting the GRT token contract with an address that is already set


```solidity
error EBOConfig_SetGRT_AddressAlreadySet();
```

### EBOConfig_SetHorizonStaking_AddressAlreadySet
Thrown when setting the HorizonStaking contract with an address that is already set


```solidity
error EBOConfig_SetHorizonStaking_AddressAlreadySet();
```

### EBOConfig_SetEpochManager_AddressAlreadySet
Thrown when setting the EpochManager contract with an address that is already set


```solidity
error EBOConfig_SetEpochManager_AddressAlreadySet();
```

### EBOConfig_AddChainIds_ChainIdAlreadyAdded
Thrown when adding a chain ID that is already added


```solidity
error EBOConfig_AddChainIds_ChainIdAlreadyAdded();
```

### EBOConfig_RemoveChainIds_ChainIdNotAdded
Thrown when removing a chain ID that is not added


```solidity
error EBOConfig_RemoveChainIds_ChainIdNotAdded();
```

### EBOConfig_CheckParameters_ParametersCannotBeZero
Thrown when checking parameters and a parameter is zero


```solidity
error EBOConfig_CheckParameters_ParametersCannotBeZero();
```

### EBOConfig_CheckParameters_PledgeRefreshWindowExceedsPledgeWindow
Thrown when checking parameters and the pledge refresh window exceeds the pledge window


```solidity
error EBOConfig_CheckParameters_PledgeRefreshWindowExceedsPledgeWindow();
```

### EBOConfig_CheckParameters_MinThawingPeriodTooShort
Thrown when checking parameters and the minimum thawing period is too short


```solidity
error EBOConfig_CheckParameters_MinThawingPeriodTooShort();
```

