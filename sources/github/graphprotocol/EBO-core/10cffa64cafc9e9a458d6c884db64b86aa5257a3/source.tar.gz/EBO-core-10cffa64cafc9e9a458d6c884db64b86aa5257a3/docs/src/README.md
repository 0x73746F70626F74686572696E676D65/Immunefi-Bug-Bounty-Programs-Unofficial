# Epoch Block Oracle (EBO)

## Overview

EBO is a mechanism for clock synchronization in a multichain environment. It enables The Graph to permissionlessly synchronize clocks between Arbitrum (where the protocol contracts are deployed), and multiple other supported chains, allowing rewards to be paid to indexers.

## Useful links

- [EBO repository](https://github.com/defi-wonderland/EBO)

## Deployments

*The addresses of the contracts deployed on Arbitrum will be listed here.*

## Licensing

The primary license for EBO contracts is MIT.

## Contributors

EBO was built with ❤️ by [Wonderland](https://defi.sucks).

Wonderland is a team of top Web3 researchers, developers, and operators who believe that the future needs to be open-source, permissionless, and decentralized.

[DeFi sucks](https://defi.sucks), but Wonderland is here to make it better.
