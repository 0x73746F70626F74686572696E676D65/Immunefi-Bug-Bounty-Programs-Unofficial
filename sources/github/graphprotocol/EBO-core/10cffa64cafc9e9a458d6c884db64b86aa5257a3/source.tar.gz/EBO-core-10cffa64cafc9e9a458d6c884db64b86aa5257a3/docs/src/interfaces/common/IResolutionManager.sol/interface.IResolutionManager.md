# IResolutionManager
**Inherits:**
[IBondManager](/interfaces/common/IBondManager.sol/interface.IBondManager.md)

Interface for the ResolutionManager abstract contract


## Events
### DisputeResolved
Emitted when a dispute is resolved


```solidity
event DisputeResolved(uint256 indexed _proposalId, IEBOStorage.ProposalStatus _resolutionStatus);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_resolutionStatus`|`IEBOStorage.ProposalStatus`|The status of the resolution|

## Structs
### ResolveParams
Read-only parameters for resolving a dispute


```solidity
struct ResolveParams {
  uint256 proposalId;
  uint256 proposalCreatedAt;
  uint256 minThawingPeriod;
  uint256 proposalBondSize;
  uint256 pledgeBondSize;
  uint256 totalPledgesForDispute;
  uint256 totalPledgesAgainstDispute;
  address proposer;
  address disputer;
  IEBOStorage.ProposalStatus resolutionStatus;
}
```

**Properties**

|Name|Type|Description|
|----|----|-----------|
|`proposalId`|`uint256`|The ID of the proposal|
|`proposalCreatedAt`|`uint256`|The creation timestamp of the proposal|
|`minThawingPeriod`|`uint256`|The minimum thawing period|
|`proposalBondSize`|`uint256`|The bond size per proposal or dispute|
|`pledgeBondSize`|`uint256`|The bond size per pledge|
|`totalPledgesForDispute`|`uint256`|The total number of pledges made in favor of the dispute|
|`totalPledgesAgainstDispute`|`uint256`|The total number of pledges made against the dispute|
|`proposer`|`address`|The proposer of the proposal|
|`disputer`|`address`|The disputer of the proposal|
|`resolutionStatus`|`IEBOStorage.ProposalStatus`|The status of the resolution|

