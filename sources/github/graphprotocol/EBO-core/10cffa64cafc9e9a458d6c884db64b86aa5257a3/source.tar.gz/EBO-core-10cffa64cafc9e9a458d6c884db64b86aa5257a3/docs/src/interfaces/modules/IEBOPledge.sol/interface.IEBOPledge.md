# IEBOPledge
**Inherits:**
[IResolutionManager](/interfaces/common/IResolutionManager.sol/interface.IResolutionManager.md), [IAccessManager](/interfaces/common/IAccessManager.sol/interface.IAccessManager.md)

Interface for the EBOPledge module


## Functions
### claimPledgeReward

Claims the pledge reward


```solidity
function claimPledgeReward(uint256 _proposalId, address _pledger) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_pledger`|`address`|The address of the pledger|


### pledgeForDispute

Pledges in favor of a dispute


```solidity
function pledgeForDispute(uint256 _proposalId, address _serviceProvider) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_serviceProvider`|`address`|The address of the service provider|


### pledgeAgainstDispute

Pledges against a dispute


```solidity
function pledgeAgainstDispute(uint256 _proposalId, address _serviceProvider) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_serviceProvider`|`address`|The address of the service provider|


## Events
### PledgeRewardClaimed
Emitted when a pledge reward is claimed by a pledger


```solidity
event PledgeRewardClaimed(uint256 indexed _proposalId, address indexed _pledger, uint256 _rewardAmount);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_pledger`|`address`|The address of the pledger|
|`_rewardAmount`|`uint256`|The amount of GRT tokens claimed|

### PledgedForDispute
Emitted when a pledger bonds for a dispute


```solidity
event PledgedForDispute(uint256 indexed _proposalId, address indexed _pledger, uint256 _pledgeAmount);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_pledger`|`address`|The address of the pledger|
|`_pledgeAmount`|`uint256`|The amount of GRT tokens pledged|

### PledgedAgainstDispute
Emitted when a pledger bonds against a dispute


```solidity
event PledgedAgainstDispute(uint256 indexed _proposalId, address indexed _pledger, uint256 _pledgeAmount);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_pledger`|`address`|The address of the pledger|
|`_pledgeAmount`|`uint256`|The amount of GRT tokens pledged|

### DisputeEscalated
Emitted when a dispute is escalated


```solidity
event DisputeEscalated(uint256 indexed _proposalId);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|

## Errors
### EBOPledge_ClaimPledgeReward_NoRewardToClaim
Thrown when claiming the pledge reward and there is no reward to claim for the pledger


```solidity
error EBOPledge_ClaimPledgeReward_NoRewardToClaim();
```

### EBOPledge_ClaimPledgeReward_AlreadyClaimed
Thrown when claiming the pledge reward and the reward is already claimed


```solidity
error EBOPledge_ClaimPledgeReward_AlreadyClaimed();
```

### EBOPledge_ClaimPledgeReward_DisputeHasNoResolution
Thrown when claiming the pledge reward and the dispute has no resolution


```solidity
error EBOPledge_ClaimPledgeReward_DisputeHasNoResolution();
```

### EBOPledge_Pledge_PledgeWindowOver
Thrown when pledging and the pledge window is over


```solidity
error EBOPledge_Pledge_PledgeWindowOver();
```

### EBOPledge_Pledge_ProposalNotDisputed
Thrown when pledging and the proposal is not disputed


```solidity
error EBOPledge_Pledge_ProposalNotDisputed();
```

### EBOPledge_Pledge_CannotPledgeIfWinning
Thrown when pledging and the pledging side has more pledges than the opposite side


```solidity
error EBOPledge_Pledge_CannotPledgeIfWinning();
```

