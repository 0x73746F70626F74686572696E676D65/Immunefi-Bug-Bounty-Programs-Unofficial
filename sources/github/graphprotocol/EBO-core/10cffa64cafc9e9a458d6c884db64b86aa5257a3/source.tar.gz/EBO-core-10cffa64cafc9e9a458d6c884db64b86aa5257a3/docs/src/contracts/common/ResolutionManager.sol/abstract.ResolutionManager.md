# ResolutionManager
**Inherits:**
[BondManager](/contracts/common/BondManager.sol/abstract.BondManager.md), [IResolutionManager](/interfaces/common/IResolutionManager.sol/interface.IResolutionManager.md)

Contains the reusable logic for the dispute resolution functionality


## Functions
### _resolve

Resolves a dispute

*The possible statuses of a resolution are: NoResolution, DisputerWon, and DisputerLost.*


```solidity
function _resolve(ResolveParams memory _resolveParams) internal;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_resolveParams`|`ResolveParams`|The parameters for the resolution|


### _disputeWindowHasPassed

Returns true if the dispute window has passed for a proposal


```solidity
function _disputeWindowHasPassed(
  uint256 _proposalCreatedAt,
  uint256 _disputeWindow
) internal view returns (bool _passed);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalCreatedAt`|`uint256`|The creation timestamp of the proposal|
|`_disputeWindow`|`uint256`|The dispute window|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_passed`|`bool`|True if the dispute window has passed|


### _pledgeWindowHasPassed

Returns true if the pledge window has passed for a dispute


```solidity
function _pledgeWindowHasPassed(
  uint256 _disputeCreatedAt,
  uint256 _lastPledgeTimestamp,
  uint256 _pledgeWindow,
  uint256 _pledgeRefreshWindow
) internal view returns (bool _passed);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_disputeCreatedAt`|`uint256`|The creation timestamp of the dispute|
|`_lastPledgeTimestamp`|`uint256`|The timestamp of the last pledge|
|`_pledgeWindow`|`uint256`|The pledge window|
|`_pledgeRefreshWindow`|`uint256`|The pledge refresh window|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_passed`|`bool`|True if the pledge window has passed|


### _slashPledges

Slashes and unbonds the losing pledgers


```solidity
function _slashPledges(
  uint256 _pledgeBondSize,
  EnumerableSet.AddressSet storage _pledgersToSlash,
  mapping(address _pledger => uint256 _pledges) storage _pledgesToSlash
) private;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_pledgeBondSize`|`uint256`|The bond size per pledge|
|`_pledgersToSlash`|`EnumerableSet.AddressSet`|The pledgers to slash|
|`_pledgesToSlash`|`mapping(address _pledger => uint256 _pledges)`|The pledges to slash|


### _unbondPledges

Releases the bonds of the winning pledgers


```solidity
function _unbondPledges(
  uint256 _pledgeBondSize,
  EnumerableSet.AddressSet storage _pledgersToUnbond,
  mapping(address _pledger => uint256 _pledges) storage _pledgesToUnbond
) private;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_pledgeBondSize`|`uint256`|The bond size per pledge|
|`_pledgersToUnbond`|`EnumerableSet.AddressSet`|The pledgers to unbond|
|`_pledgesToUnbond`|`mapping(address _pledger => uint256 _pledges)`|The pledges to unbond|


