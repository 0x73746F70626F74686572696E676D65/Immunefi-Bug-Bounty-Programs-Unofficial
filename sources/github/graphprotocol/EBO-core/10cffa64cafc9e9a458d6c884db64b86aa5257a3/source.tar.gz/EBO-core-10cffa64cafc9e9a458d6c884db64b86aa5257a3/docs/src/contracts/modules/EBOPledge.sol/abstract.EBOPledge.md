# EBOPledge
**Inherits:**
[ResolutionManager](/contracts/common/ResolutionManager.sol/abstract.ResolutionManager.md), [AccessManager](/contracts/common/AccessManager.sol/abstract.AccessManager.md), [IEBOPledge](/interfaces/modules/IEBOPledge.sol/interface.IEBOPledge.md)

Contains the logic for the dispute pledge functionality


## Functions
### claimPledgeReward

Claims the pledge reward


```solidity
function claimPledgeReward(uint256 _proposalId, address _pledger) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_pledger`|`address`|The address of the pledger|


### pledgeForDispute

Pledges in favor of a dispute


```solidity
function pledgeForDispute(uint256 _proposalId, address _serviceProvider) external onlyOperator(_serviceProvider);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_serviceProvider`|`address`|The address of the service provider|


### pledgeAgainstDispute

Pledges against a dispute


```solidity
function pledgeAgainstDispute(uint256 _proposalId, address _serviceProvider) external onlyOperator(_serviceProvider);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_serviceProvider`|`address`|The address of the service provider|


### _pledge

Pledges `for` or `against` a dispute


```solidity
function _pledge(address _pledger, uint256 _proposalId, bool _forDispute) private returns (uint256 _pledgeAmount);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_pledger`|`address`|The address of the pledger|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_forDispute`|`bool`|True if the pledge is `for` the dispute, false if it is `against` the dispute|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_pledgeAmount`|`uint256`|The amount of GRT tokens pledged|


