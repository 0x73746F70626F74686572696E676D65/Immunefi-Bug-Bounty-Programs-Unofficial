# IEBO
**Inherits:**
[IEBOCore](/interfaces/modules/IEBOCore.sol/interface.IEBOCore.md), [IEBOPledge](/interfaces/modules/IEBOPledge.sol/interface.IEBOPledge.md), [IEBOConfig](/interfaces/modules/IEBOConfig.sol/interface.IEBOConfig.md), [ISemver](/interfaces/universal/ISemver.sol/interface.ISemver.md)

Interface for the EBO contract


## Functions
### initialize

Initializes the contract

*Protected initializer function that can be invoked at most once*


```solidity
function initialize(EBOInitializationParams calldata _initParams) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_initParams`|`EBOInitializationParams`|The initialization parameters|


## Structs
### EBOInitializationParams
Contains the parameters for the initialization of the EBO contract


```solidity
struct EBOInitializationParams {
  address arbitrator;
  address council;
  IERC20 grt;
  IHorizonStaking horizonStaking;
  IEpochManager epochManager;
  uint256 startEpoch;
  string[] chainIds;
  IEBOStorage.Parameters parameters;
  uint256 arbitratorResolutionWindow;
}
```

**Properties**

|Name|Type|Description|
|----|----|-----------|
|`arbitrator`|`address`|The address of The Graph's Arbitrator|
|`council`|`address`|The address of The Graph's Council|
|`grt`|`IERC20`|The address of the GRT token contract|
|`horizonStaking`|`IHorizonStaking`|The address of the HorizonStaking contract|
|`epochManager`|`IEpochManager`|The address of the EpochManager contract|
|`startEpoch`|`uint256`|The start epoch|
|`chainIds`|`string[]`|The chain IDs|
|`parameters`|`IEBOStorage.Parameters`|The parameters for proposals and disputes|
|`arbitratorResolutionWindow`|`uint256`|The arbitrator resolution window|

