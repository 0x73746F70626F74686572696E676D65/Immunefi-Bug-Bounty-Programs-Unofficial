# AccessManager
**Inherits:**
[EBOStorage](/contracts/common/EBOStorage.sol/abstract.EBOStorage.md), [IAccessManager](/interfaces/common/IAccessManager.sol/interface.IAccessManager.md)

Provides reusable logic for authorized access control


## Functions
### onlyOperator

Checks that the caller is a valid operator


```solidity
modifier onlyOperator(address _serviceProvider);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_serviceProvider`|`address`|The service provider address|


### onlyArbitrator

Checks that the caller is the arbitrator


```solidity
modifier onlyArbitrator();
```

### onlyCouncil

Checks that the caller is the council


```solidity
modifier onlyCouncil();
```

### onlyPendingCouncil

Checks that the caller is the pending council


```solidity
modifier onlyPendingCouncil();
```

