# Proposal Lifecycle

## Parameter Definitions and Values

- **Proposal Bond Size**: The amount of GRT needed to create or dispute a proposal, which shall be staked and provisioned in `HorizonStaking`.

    > 💡 The `proposalBondSize` equals **15k GRT**, which is *15 %* of the minimum stake required by The Graph for indexers.

- **Pledge Bond Size**: The amount of GRT that represents a single pledge, which shall be staked and provisioned in `HorizonStaking`.

    > 💡 The `pledgeBondSize` equals **15k GRT**, which is *15 %* of the minimum stake required by The Graph for indexers.

- **Max Number of Pledges**: The maximum number of pledges permitted per side in a dispute.

    *One* pledge is required when calling the pledge function for the *first* time; subsequent calls will require exactly *two* pledges to surpass the opposite party, if possible; if not, the `maxNumberOfPledges` is reached with *one* last pledge.

    > 💡 The `maxNumberOfPledges` equals **4 pledges**, to be reached after **5 rounds** (pledge calls).
    
    > 💡 Whenever the `maxNumberOfPledges` is reached on a side of a dispute, that side's bond sizes total **75k GRT**, which is *75 %* of the minimum stake required by The Graph for indexers.

- **Min Thawing Period**: The minimum duration a user must wait to finish thawing their tokens in the `HorizonStaking` contract, which shall be pursuant to `EBO`'s most extended possible proposal lifecycle.

    > 💡 The `minThawingPeriod` equals **15 days**.

- **Dispute Window**: The period during which users can challenge a proposal before it can be finalized and be deemed valid.

    This window opens immediately after a proposal is created.

    > 💡 The `disputeWindow` equals **12 hours**.

- **Pledge Window**: The minimum duration during which users can pledge either in support of or against a dispute (provided that the `maxNumberOfPledges` has not been reached on both sides beforehand).

    This window opens immediately after a dispute is created.

    > 💡 The `pledgeWindow` equals **2 days**.

- **Pledge Refresh Window**: The minimum duration during which users can pledge for their side in response to a new contrary pledge.

    This window opens immediately after a pledge is made, operating independently of the `pledgeWindow`, and can be reopened continually up to the `maxNumberOfPledges`.

    > 💡 The `pledgeRefreshWindow` equals **1 day**.

- **Arbitrator Resolution Window**: The maximum estimated time for the arbitrator to resolve an escalated dispute.

    This window opens immediately after a dispute is escalated.

    > 💡 The `arbitratorResolutionWindow` equals **7 days**.

---

## **Longest Proposal Lifecycle**

1. A proposal is disputed at the last possible moment before the `disputeWindow` expires.

2. The first pledge is made at the last possible moment before the `pledgeWindow` ends.

3. Subsequent pledges are placed just before each `pledgeRefreshWindow` expires, continuing until the `maxNumberOfPledges` is reached on both sides of the dispute.

4. The arbitrator resolves the dispute just before the `arbitratorResolutionWindow` ends.

![longest_proposal_lifecycle_scenario.png](longest_proposal_lifecycle_scenario.png)

> 💡 The last `pledgeRefreshWindow` infraimposes on the `arbitratorResolutionWindow`; this is because once the final pledge (i.e., the one that reaches the `maxNumberOfPledges` on both sides of the dispute) is made, the dispute is escalated and ready for arbitrator resolution.

| Call | Proposer party bond variation per call | Disputer party bond variation per call | Proposer party pledges variation per call | Disputer party pledges variation per call | Status after call | Max duration before next call | Comments |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Propose | +15k GRT |  |  |  | Active | +12 hours | Passed the `disputeWindow` (12 hours) without a dispute, the proposal can only be finalized. |
| Dispute |  | +15k GRT |  |  | Disputed | +2 days | As of now, the proposal can no longer be finalized, no matter the resolution status. |
| Pledge (round 1) |  | +15k GRT |  | +1 | Disputed | +1 day | Any party is allowed to start pledging in round 1. |
| Pledge (round 2) | +30k GRT |  | +2 |  | Disputed | +1 day | The counterparty must exceed the total pledges of the opposite side by one pledge in round 2. | 
| Pledge (round 3) |  | +30k GRT |  | +2 | Disputed | +1 day | The counterparty must exceed the total pledges of the opposite side by one pledge in round 3. |
| Pledge (round 4) | +30k GRT |  | +2 |  | Disputed | +1 day | The counterparty must exceed the total pledges of the opposite side by one pledge in round 4. |
| Pledge (round 5) |  | +15k GRT |  | +1 | Escalated | +7 days  | The `maxNumberOfPledges` (4) has been reached by both parties in round 5. |
| Resolve | -75k GRT | -75k GRT |  |  | Disputer Won / Disputer Lost / No Resolution |  | At this point, the cumulative maximum duration (13 days and 12 hours) must not exceed the `minThawingPeriod` (15 days). |

---
