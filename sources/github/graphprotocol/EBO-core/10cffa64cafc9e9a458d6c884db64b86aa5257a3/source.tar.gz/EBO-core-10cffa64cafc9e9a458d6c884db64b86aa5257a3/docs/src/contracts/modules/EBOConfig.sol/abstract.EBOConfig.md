# EBOConfig
**Inherits:**
[AccessManager](/contracts/common/AccessManager.sol/abstract.AccessManager.md), [IEBOConfig](/interfaces/modules/IEBOConfig.sol/interface.IEBOConfig.md)

Contains the configuration logic for EBO


## Functions
### setArbitrator

Sets the arbitrator


```solidity
function setArbitrator(address _arbitrator) external onlyCouncil;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_arbitrator`|`address`|The address of the arbitrator|


### setPendingCouncil

Sets the pending council


```solidity
function setPendingCouncil(address _pendingCouncil) external onlyCouncil;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_pendingCouncil`|`address`|The address of the pending council|


### confirmCouncil

Confirms the council


```solidity
function confirmCouncil() external onlyPendingCouncil;
```

### setGRT

Sets the GRT token contract


```solidity
function setGRT(IERC20 _grt) external onlyCouncil;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_grt`|`IERC20`|The address of the GRT token contract|


### setHorizonStaking

Sets the HorizonStaking contract


```solidity
function setHorizonStaking(IHorizonStaking _horizonStaking) external onlyCouncil;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_horizonStaking`|`IHorizonStaking`|The address of the HorizonStaking contract|


### setEpochManager

Sets the EpochManager contract


```solidity
function setEpochManager(IEpochManager _epochManager) external onlyCouncil;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_epochManager`|`IEpochManager`|The address of the EpochManager contract|


### addChainIds

Add an array of chain IDs


```solidity
function addChainIds(string[] calldata _chainIds) external onlyCouncil;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_chainIds`|`string[]`|The chain IDs|


### removeChainIds

Removes an array of chain IDs


```solidity
function removeChainIds(string[] calldata _chainIds) external onlyCouncil;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_chainIds`|`string[]`|The chain IDs|


### setParameters

Sets the parameters for proposals and disputes


```solidity
function setParameters(Parameters calldata _parameters, uint256 _arbitratorResolutionWindow) external onlyCouncil;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_parameters`|`Parameters`|The parameters for proposals and disputes|
|`_arbitratorResolutionWindow`|`uint256`|The arbitrator resolution window|


### _setArbitrator

Sets the arbitrator


```solidity
function _setArbitrator(address _arbitrator) internal;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_arbitrator`|`address`|The address of the arbitrator|


### _setPendingCouncil

Sets the pending council


```solidity
function _setPendingCouncil(address _pendingCouncil) internal;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_pendingCouncil`|`address`|The address of the pending council|


### _setCouncil

Sets the council


```solidity
function _setCouncil(address _council) internal;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_council`|`address`|The address of the council|


### _setGRT

Sets the GRT token contract


```solidity
function _setGRT(IERC20 _grt) internal;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_grt`|`IERC20`|The address of the GRT token contract|


### _setHorizonStaking

Sets the HorizonStaking contract


```solidity
function _setHorizonStaking(IHorizonStaking _horizonStaking) internal;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_horizonStaking`|`IHorizonStaking`|The address of the HorizonStaking contract|


### _setEpochManager

Sets the EpochManager contract


```solidity
function _setEpochManager(IEpochManager _epochManager) internal;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_epochManager`|`IEpochManager`|The address of the EpochManager contract|


### _setStartEpoch

Sets the start epoch

*To be set only once during initialization*


```solidity
function _setStartEpoch(uint256 _startEpoch) internal;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_startEpoch`|`uint256`|The start epoch|


### _addChainIds

Adds an array of chain IDs


```solidity
function _addChainIds(string[] calldata _chainIds) internal;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_chainIds`|`string[]`|The chain IDs|


### _removeChainIds

Removes an array of chain IDs


```solidity
function _removeChainIds(string[] calldata _chainIds) internal;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_chainIds`|`string[]`|The chain IDs|


### _setParameters

Sets the parameters for proposals and disputes


```solidity
function _setParameters(Parameters calldata _parameters, uint256 _arbitratorResolutionWindow) internal;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_parameters`|`Parameters`|The parameters for proposals and disputes|
|`_arbitratorResolutionWindow`|`uint256`|The arbitrator resolution window|


### _checkParameters

Checks if the parameters are valid and compliant with the EBO protocol


```solidity
function _checkParameters(Parameters calldata _parameters, uint256 _arbitratorResolutionWindow) private pure;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_parameters`|`Parameters`|The parameters for proposals and disputes|
|`_arbitratorResolutionWindow`|`uint256`|The arbitrator resolution window|


### _ceilDiv

Returns the ceiling of the division of two numbers


```solidity
function _ceilDiv(uint256 _a, uint256 _b) private pure returns (uint256 _result);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_a`|`uint256`|The dividend|
|`_b`|`uint256`|The divisor|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_result`|`uint256`|The ceiling of the division|


