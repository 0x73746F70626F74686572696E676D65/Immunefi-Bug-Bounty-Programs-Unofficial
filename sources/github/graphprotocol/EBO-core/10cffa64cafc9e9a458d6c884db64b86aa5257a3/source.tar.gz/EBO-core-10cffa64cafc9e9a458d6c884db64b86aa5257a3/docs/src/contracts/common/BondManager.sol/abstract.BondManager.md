# BondManager
**Inherits:**
[EBOStorage](/contracts/common/EBOStorage.sol/abstract.EBOStorage.md), [IBondManager](/interfaces/common/IBondManager.sol/interface.IBondManager.md)

Contains the reusable logic for the bond functionality


## Functions
### _bond

Bonds the tokens of the bonder getting his provision from the HorizonStaking contract


```solidity
function _bond(address _bonder, uint256 _amount) internal;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_bonder`|`address`|The address of the bonder|
|`_amount`|`uint256`|The amount of GRT tokens to bond|


### _unbond

Unbonds the tokens of the bonder


```solidity
function _unbond(address _bonder, uint256 _amount) internal;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_bonder`|`address`|The address of the bonder|
|`_amount`|`uint256`|The amount of GRT tokens to unbond|


