# IEBOCore
**Inherits:**
[IResolutionManager](/interfaces/common/IResolutionManager.sol/interface.IResolutionManager.md), [IAccessManager](/interfaces/common/IAccessManager.sol/interface.IAccessManager.md)

Interface for the EBOCore module


## Functions
### propose

Creates a new proposal


```solidity
function propose(uint256 _epoch, string calldata _chainId, uint256 _blockNumber, address _serviceProvider) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_epoch`|`uint256`|The epoch of the proposal|
|`_chainId`|`string`|The chain ID of the proposal|
|`_blockNumber`|`uint256`|The block number of the proposal|
|`_serviceProvider`|`address`|The address of the service provider|


### dispute

Disputes a proposal


```solidity
function dispute(uint256 _proposalId, address _serviceProvider) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_serviceProvider`|`address`|The address of the service provider|


### resolve

Resolves a non-escalated dispute

*This function penalizes losing bonders*


```solidity
function resolve(uint256 _proposalId) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|


### resolve

Resolves an escalated dispute

*Only the arbitrator can resolve an escalated dispute*

*This function penalizes losing bonders*


```solidity
function resolve(uint256 _proposalId, IEBOStorage.ProposalStatus _resolutionStatus) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_resolutionStatus`|`IEBOStorage.ProposalStatus`|The status of the resolution|


### finalize

Finalizes a proposal


```solidity
function finalize(uint256 _proposalId) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|


### amendEpochBlock

Amends the epoch block of a proposal

*Only the arbitrator can force data availability in case there was a mistake in the system*


```solidity
function amendEpochBlock(uint256 _proposalId, uint256 _blockNumber) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_blockNumber`|`uint256`|The amending block number for the proposal|


## Events
### ProposalCreated
Emitted when a proposal is created


```solidity
event ProposalCreated(
  uint256 indexed _proposalId,
  uint256 indexed _epoch,
  string indexed _chainId,
  uint256 _blockNumber,
  address _serviceProvider
);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_epoch`|`uint256`|The epoch of the proposal|
|`_chainId`|`string`|The chain ID of the proposal|
|`_blockNumber`|`uint256`|The block number of the proposal|
|`_serviceProvider`|`address`|The address of the service provider|

### ProposalDisputed
Emitted when a proposal is disputed


```solidity
event ProposalDisputed(uint256 indexed _proposalId);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|

### ProposalFinalized
Emitted when a proposal is finalized


```solidity
event ProposalFinalized(
  uint256 indexed _proposalId, uint256 indexed _epoch, string indexed _chainId, uint256 _blockNumber
);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_epoch`|`uint256`|The epoch of the proposal|
|`_chainId`|`string`|The chain ID of the proposal|
|`_blockNumber`|`uint256`|The block number of the proposal|

### ProposalAmended
Emitted when a proposal is amended


```solidity
event ProposalAmended(
  uint256 indexed _proposalId, uint256 indexed _epoch, string indexed _chainId, uint256 _blockNumber
);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_epoch`|`uint256`|The epoch of the proposal|
|`_chainId`|`string`|The chain ID of the proposal|
|`_blockNumber`|`uint256`|The block number of the proposal|

## Errors
### EBOCore_Propose_InvalidEpoch
Thrown when proposing and the epoch is invalid


```solidity
error EBOCore_Propose_InvalidEpoch();
```

### EBOCore_Propose_ChainNotAdded
Thrown when proposing and the chain is not added


```solidity
error EBOCore_Propose_ChainNotAdded();
```

### EBOCore_Propose_ProposalAlreadyActive
Thrown when proposing and the proposal is already active


```solidity
error EBOCore_Propose_ProposalAlreadyActive();
```

### EBOCore_Dispute_DisputeWindowOver
Thrown when disputing and the dispute window is over


```solidity
error EBOCore_Dispute_DisputeWindowOver();
```

### EBOCore_Dispute_ProposalNotActive
Thrown when disputing and the proposal is not active


```solidity
error EBOCore_Dispute_ProposalNotActive();
```

### EBOCore_AmendEpochBlock_ProposalNotFinalized
Thrown when amending the epoch block and the proposal is not finalized


```solidity
error EBOCore_AmendEpochBlock_ProposalNotFinalized();
```

### EBOCore_Finalize_DisputeWindowNotOver
Thrown when finalizing and the dispute window is not over


```solidity
error EBOCore_Finalize_DisputeWindowNotOver();
```

### EBOCore_Finalize_ProposalNotActive
Thrown when finalizing and the proposal is not active


```solidity
error EBOCore_Finalize_ProposalNotActive();
```

### EBOCore_Resolve_ProposalNotDisputed
Thrown when resolving and the proposal is not disputed


```solidity
error EBOCore_Resolve_ProposalNotDisputed();
```

### EBOCore_Resolve_PledgeWindowNotOver
Thrown when resolving and the pledge window is not over


```solidity
error EBOCore_Resolve_PledgeWindowNotOver();
```

### EBOCore_Resolve_DisputeNotEscalated
Thrown when resolving and the dispute is not escalated


```solidity
error EBOCore_Resolve_DisputeNotEscalated();
```

### EBOCore_Resolve_InvalidStatus
Thrown when resolving with an invalid status


```solidity
error EBOCore_Resolve_InvalidStatus();
```

