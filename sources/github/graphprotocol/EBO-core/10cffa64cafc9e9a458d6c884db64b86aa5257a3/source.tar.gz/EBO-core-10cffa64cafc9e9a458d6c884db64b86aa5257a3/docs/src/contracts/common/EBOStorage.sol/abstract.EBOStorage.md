# EBOStorage
**Inherits:**
[IEBOStorage](/interfaces/common/IEBOStorage.sol/interface.IEBOStorage.md)

Provides the storage layout for the EBO system


## State Variables
### MAX_MAX_VERIFIER_CUT
Returns the maximum value that can be set as the maxVerifierCut in a provision of HorizonStaking

*It is equivalent to 100% in parts-per-million*


```solidity
uint32 public constant MAX_MAX_VERIFIER_CUT = 1_000_000;
```


### grt
Returns the address of the GRT token contract


```solidity
IERC20 public grt;
```


### horizonStaking
Returns the address of the HorizonStaking contract


```solidity
IHorizonStaking public horizonStaking;
```


### epochManager
Returns the address of the EpochManager contract


```solidity
IEpochManager public epochManager;
```


### council
Returns the address of the council


```solidity
address public council;
```


### pendingCouncil
Returns the address of the pending council


```solidity
address public pendingCouncil;
```


### arbitrator
Returns the address of the arbitrator


```solidity
address public arbitrator;
```


### startEpoch
Returns the start epoch


```solidity
uint256 public startEpoch;
```


### proposalId
Returns the ID of the last proposal


```solidity
uint256 public proposalId;
```


### parametersSnapshotId
Returns the snapshot ID of the current parameters snapshot


```solidity
uint256 public parametersSnapshotId;
```


### activeProposal
Returns the active proposal for the given epoch and chain ID


```solidity
mapping(uint256 _epoch => mapping(string _chainId => uint256 _proposalId)) public activeProposal;
```


### bonds
Returns the total amount bonded by a bonder


```solidity
mapping(address _bonder => uint256 _bondSize) public bonds;
```


### proposals
Returns the data of the proposal


```solidity
mapping(uint256 _proposalId => Proposal _proposal) public proposals;
```


### parametersSnapshots
Returns the parameters of proposals and disputes for the given parameters snapshot ID


```solidity
mapping(uint256 _parametersSnapshotId => Parameters _parameters) public parametersSnapshots;
```


### pledgesForDispute
Returns the number of pledges a pledger has made in favor of a given dispute


```solidity
mapping(uint256 _proposalId => mapping(address _pledger => uint256 _pledgesForDispute)) public pledgesForDispute;
```


### pledgesAgainstDispute
Returns the number of pledges a pledger has made against a given dispute


```solidity
mapping(uint256 _proposalId => mapping(address _pledger => uint256 _pledgesAgainstDispute)) public pledgesAgainstDispute;
```


### disputes
Returns the data of the dispute


```solidity
mapping(uint256 _proposalId => Dispute _dispute) public disputes;
```


### pledgerClaimed
Returns true if the pledger has claimed the pledge reward


```solidity
mapping(uint256 _proposalId => mapping(address _pledger => bool _claimed)) public pledgerClaimed;
```


### chainIdsAllowed
Returns true if the chain is allowed


```solidity
mapping(string _chainId => bool _allowed) public chainIdsAllowed;
```


### _disputePledgersFor
Stores the pledgers that have pledged in favor of a given dispute


```solidity
mapping(uint256 _proposalId => EnumerableSet.AddressSet _pledgersForDispute) internal _disputePledgersFor;
```


### _disputePledgersAgainst
Stores the pledgers that have pledged against a given dispute


```solidity
mapping(uint256 _proposalId => EnumerableSet.AddressSet _pledgersAgainstDispute) internal _disputePledgersAgainst;
```


## Functions
### pledgersForDispute

Returns the pledgers in favor of a given dispute


```solidity
function pledgersForDispute(uint256 _proposalId) external view returns (address[] memory _pledgersForDispute);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_pledgersForDispute`|`address[]`|The addresses of the pledgers in favor of the dispute|


### pledgersAgainstDispute

Returns the pledgers against a given dispute


```solidity
function pledgersAgainstDispute(uint256 _proposalId) external view returns (address[] memory _pledgersAgainstDispute);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_pledgersAgainstDispute`|`address[]`|The addresses of the pledgers against the dispute|


