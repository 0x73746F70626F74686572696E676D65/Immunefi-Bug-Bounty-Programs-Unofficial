# EBO
**Inherits:**
[EBOCore](/contracts/modules/EBOCore.sol/abstract.EBOCore.md), [EBOPledge](/contracts/modules/EBOPledge.sol/abstract.EBOPledge.md), [EBOConfig](/contracts/modules/EBOConfig.sol/abstract.EBOConfig.md), UUPSUpgradeable, [IEBO](/interfaces/IEBO.sol/interface.IEBO.md)

Contains all the EBO logic


## Functions
### constructor

Constructor

*Prevents this contract from being initialized or reinitialized to any version, locking the implementation*


```solidity
constructor();
```

### initialize

Initializes the contract

*Protected initializer function that can be invoked at most once*


```solidity
function initialize(EBOInitializationParams calldata _initParams) external initializer;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_initParams`|`EBOInitializationParams`|The initialization parameters|


### version

Getter for the semantic version of the contract. This is not
meant to be used onchain but instead meant to be used by offchain
tooling.

**Note:**
semver: 1.0.0


```solidity
function version() external pure returns (string memory);
```
**Returns**

|Name|Type|Description|
|----|----|-----------|
|`<none>`|`string`|Semver contract version as a string.|


### _authorizeUpgrade

*Function that should revert when `msg.sender` is not authorized to upgrade the contract. Called by
{upgradeToAndCall}.
Normally, this function will use an xref:access.adoc[access control] modifier such as {Ownable-onlyOwner}.
```solidity
function _authorizeUpgrade(address) internal onlyOwner {}
```*


```solidity
function _authorizeUpgrade(address) internal override onlyCouncil;
```

