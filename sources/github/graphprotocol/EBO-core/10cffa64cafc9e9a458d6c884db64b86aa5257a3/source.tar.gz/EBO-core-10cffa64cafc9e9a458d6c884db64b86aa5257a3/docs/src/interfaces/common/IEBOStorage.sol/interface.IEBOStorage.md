# IEBOStorage
Interface for the EBOStorage abstract contract


## Functions
### MAX_MAX_VERIFIER_CUT

Returns the maximum value that can be set as the maxVerifierCut in a provision of HorizonStaking

*It is equivalent to 100% in parts-per-million*


```solidity
function MAX_MAX_VERIFIER_CUT() external view returns (uint32 _maxMaxVerifierCut);
```
**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_maxMaxVerifierCut`|`uint32`|The maximum value that can be set as the maxVerifierCut in a provision of HorizonStaking|


### grt

Returns the address of the GRT token contract


```solidity
function grt() external view returns (IERC20 _grt);
```
**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_grt`|`IERC20`|The address of the GRT token contract|


### horizonStaking

Returns the address of the HorizonStaking contract


```solidity
function horizonStaking() external view returns (IHorizonStaking _horizonStaking);
```
**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_horizonStaking`|`IHorizonStaking`|The address of the HorizonStaking contract|


### epochManager

Returns the address of the EpochManager contract


```solidity
function epochManager() external view returns (IEpochManager _epochManager);
```
**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_epochManager`|`IEpochManager`|The address of the EpochManager contract|


### council

Returns the address of the council


```solidity
function council() external view returns (address _council);
```
**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_council`|`address`|The address of the council|


### pendingCouncil

Returns the address of the pending council


```solidity
function pendingCouncil() external view returns (address _pendingCouncil);
```
**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_pendingCouncil`|`address`|The address of the pending council|


### arbitrator

Returns the address of the arbitrator


```solidity
function arbitrator() external view returns (address _arbitrator);
```
**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_arbitrator`|`address`|The address of the arbitrator|


### proposalId

Returns the ID of the last proposal


```solidity
function proposalId() external view returns (uint256 _proposalId);
```
**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the last proposal|


### parametersSnapshotId

Returns the snapshot ID of the current parameters snapshot


```solidity
function parametersSnapshotId() external view returns (uint256 _parametersSnapshotId);
```
**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_parametersSnapshotId`|`uint256`|The snapshot ID of the current parameters snapshot|


### startEpoch

Returns the start epoch


```solidity
function startEpoch() external view returns (uint256 _startEpoch);
```
**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_startEpoch`|`uint256`|The start epoch|


### activeProposal

Returns the active proposal for the given epoch and chain ID


```solidity
function activeProposal(uint256 _epoch, string calldata _chainId) external view returns (uint256 _proposalId);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_epoch`|`uint256`|The epoch|
|`_chainId`|`string`|The chain ID|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the active proposal|


### bonds

Returns the total amount bonded by a bonder


```solidity
function bonds(address _bonder) external view returns (uint256 _bondSize);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_bonder`|`address`|The address of the bonder|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_bondSize`|`uint256`|The total amount bonded|


### proposals

Returns the data of the proposal


```solidity
function proposals(uint256 _proposalId)
  external
  view
  returns (
    uint256 _epoch,
    string memory _chainId,
    uint256 _blockNumber,
    address _proposer,
    uint256 _createdAt,
    uint256 _parametersSnapshotId,
    ProposalStatus _status
  );
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_epoch`|`uint256`|The epoch of the proposal|
|`_chainId`|`string`|The chain ID of the proposal|
|`_blockNumber`|`uint256`|The block number of the proposal|
|`_proposer`|`address`|The address of the proposer|
|`_createdAt`|`uint256`|The creation timestamp of the proposal|
|`_parametersSnapshotId`|`uint256`|The snapshot ID of the proposal and dispute parameters|
|`_status`|`ProposalStatus`|The status of the proposal|


### parametersSnapshots

Returns the parameters of proposals and disputes for the given parameters snapshot ID


```solidity
function parametersSnapshots(uint256 _parametersSnapshotId)
  external
  view
  returns (
    uint256 _proposalBondSize,
    uint256 _pledgeBondSize,
    uint256 _minThawingPeriod,
    uint256 _disputeWindow,
    uint256 _pledgeWindow,
    uint256 _pledgeRefreshWindow,
    uint256 _maxNumberOfPledges
  );
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_parametersSnapshotId`|`uint256`|The parameters snapshot ID|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_proposalBondSize`|`uint256`|The bond size per proposal or dispute|
|`_pledgeBondSize`|`uint256`|The bond size per pledge|
|`_minThawingPeriod`|`uint256`|The minimum thawing period|
|`_disputeWindow`|`uint256`|The dispute window|
|`_pledgeWindow`|`uint256`|The pledge window|
|`_pledgeRefreshWindow`|`uint256`|The pledge refresh window|
|`_maxNumberOfPledges`|`uint256`|The maximum number of pledges for each side of disputes|


### pledgesForDispute

Returns the number of pledges a pledger has made in favor of a given dispute


```solidity
function pledgesForDispute(uint256 _proposalId, address _pledger) external view returns (uint256 _pledgesForDispute);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_pledger`|`address`|The address of the pledger|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_pledgesForDispute`|`uint256`|The number of pledges made by the pledger in favor of the dispute|


### pledgesAgainstDispute

Returns the number of pledges a pledger has made against a given dispute


```solidity
function pledgesAgainstDispute(
  uint256 _proposalId,
  address _pledger
) external view returns (uint256 _pledgesAgainstDispute);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_pledger`|`address`|The address of the pledger|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_pledgesAgainstDispute`|`uint256`|The number of pledges made by the pledger against the dispute|


### disputes

Returns the data of the dispute


```solidity
function disputes(uint256 _proposalId)
  external
  view
  returns (
    address _disputer,
    uint256 _createdAt,
    uint256 _lastPledgeTimestamp,
    uint256 _totalPledgesForDispute,
    uint256 _totalPledgesAgainstDispute,
    uint256 _rewardPerWinningPledge
  );
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_disputer`|`address`|The address of the disputer|
|`_createdAt`|`uint256`|The creation timestamp of the dispute|
|`_lastPledgeTimestamp`|`uint256`|The timestamp of the last pledge|
|`_totalPledgesForDispute`|`uint256`|The total number of pledges in favor of the dispute|
|`_totalPledgesAgainstDispute`|`uint256`|The total number of pledges against the dispute|
|`_rewardPerWinningPledge`|`uint256`|The amount of GRT tokens rewarded per winning pledge|


### pledgerClaimed

Returns true if the pledger has claimed the pledge reward


```solidity
function pledgerClaimed(uint256 _proposalId, address _pledger) external view returns (bool _claimed);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|
|`_pledger`|`address`|The address of the pledger|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_claimed`|`bool`|True if the pledger has claimed|


### chainIdsAllowed

Returns true if the chain is allowed


```solidity
function chainIdsAllowed(string calldata _chainId) external view returns (bool _allowed);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_chainId`|`string`|The chain ID|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_allowed`|`bool`|True if the chain is allowed|


### pledgersForDispute

Returns the pledgers in favor of a given dispute


```solidity
function pledgersForDispute(uint256 _proposalId) external view returns (address[] memory _pledgersForDispute);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_pledgersForDispute`|`address[]`|The addresses of the pledgers in favor of the dispute|


### pledgersAgainstDispute

Returns the pledgers against a given dispute


```solidity
function pledgersAgainstDispute(uint256 _proposalId) external view returns (address[] memory _pledgersAgainstDispute);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_proposalId`|`uint256`|The ID of the proposal|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`_pledgersAgainstDispute`|`address[]`|The addresses of the pledgers against the dispute|


## Structs
### Proposal
Contains the data of a proposal


```solidity
struct Proposal {
  uint256 epoch;
  string chainId;
  uint256 blockNumber;
  address proposer;
  uint256 createdAt;
  uint256 parametersSnapshotId;
  ProposalStatus status;
}
```

**Properties**

|Name|Type|Description|
|----|----|-----------|
|`epoch`|`uint256`|The epoch of the proposal|
|`chainId`|`string`|The chain ID of the proposal|
|`blockNumber`|`uint256`|The block number of the proposal|
|`proposer`|`address`|The address of the proposer|
|`createdAt`|`uint256`|The creation timestamp of the proposal|
|`parametersSnapshotId`|`uint256`|The snapshot ID of the proposal and dispute parameters|
|`status`|`ProposalStatus`|The status of the proposal|

### Parameters
Contains the parameters for proposals and disputes


```solidity
struct Parameters {
  uint256 proposalBondSize;
  uint256 pledgeBondSize;
  uint256 minThawingPeriod;
  uint256 disputeWindow;
  uint256 pledgeWindow;
  uint256 pledgeRefreshWindow;
  uint256 maxNumberOfPledges;
}
```

**Properties**

|Name|Type|Description|
|----|----|-----------|
|`proposalBondSize`|`uint256`|The bond size per proposal or dispute|
|`pledgeBondSize`|`uint256`|The bond size per pledge|
|`minThawingPeriod`|`uint256`|The minimum thawing period|
|`disputeWindow`|`uint256`|The dispute window|
|`pledgeWindow`|`uint256`|The pledge window|
|`pledgeRefreshWindow`|`uint256`|The pledge refresh window|
|`maxNumberOfPledges`|`uint256`|The maximum number of pledges for each side of disputes|

### Dispute
Contains the data of a dispute


```solidity
struct Dispute {
  address disputer;
  uint256 createdAt;
  uint256 lastPledgeTimestamp;
  uint256 totalPledgesForDispute;
  uint256 totalPledgesAgainstDispute;
  uint256 rewardPerWinningPledge;
}
```

**Properties**

|Name|Type|Description|
|----|----|-----------|
|`disputer`|`address`|The address of the disputer|
|`createdAt`|`uint256`|The creation timestamp of the dispute|
|`lastPledgeTimestamp`|`uint256`| The timestamp of the last pledge|
|`totalPledgesForDispute`|`uint256`|The total number of pledges in favor of the dispute|
|`totalPledgesAgainstDispute`|`uint256`|The total number of pledges against the dispute|
|`rewardPerWinningPledge`|`uint256`|The amount of GRT tokens rewarded per winning pledge|

## Enums
### ProposalStatus
The status of the proposal


```solidity
enum ProposalStatus {
  None,
  Active,
  Disputed,
  Escalated,
  DisputerWon,
  DisputerLost,
  NoResolution,
  Finalized
}
```

