# IBondManager
**Inherits:**
[IEBOStorage](/interfaces/common/IEBOStorage.sol/interface.IEBOStorage.md)

Interface for the BondManager abstract contract


## Errors
### BondManager_Bond_InvalidMaxVerifierCut
Thrown when bonding and the bonder has an invalid maximum verifier cut


```solidity
error BondManager_Bond_InvalidMaxVerifierCut();
```

### BondManager_Bond_InvalidThawingPeriod
Thrown when bonding and the bonder has an invalid thawing period


```solidity
error BondManager_Bond_InvalidThawingPeriod();
```

### BondManager_Bond_InsufficientNonThawingTokens
Thrown when bonding and the bonder has insufficient non-thawing tokens


```solidity
error BondManager_Bond_InsufficientNonThawingTokens();
```

### BondManager_Bond_BondedTokensExceedNonThawingTokens
Thrown when bonding and the bonder's bonded tokens exceed his non-thawing tokens


```solidity
error BondManager_Bond_BondedTokensExceedNonThawingTokens();
```

### BondManager_Unbond_InsufficientBondedTokens
Thrown when unbonding and the bonder has insufficient bonded tokens


```solidity
error BondManager_Unbond_InsufficientBondedTokens();
```

