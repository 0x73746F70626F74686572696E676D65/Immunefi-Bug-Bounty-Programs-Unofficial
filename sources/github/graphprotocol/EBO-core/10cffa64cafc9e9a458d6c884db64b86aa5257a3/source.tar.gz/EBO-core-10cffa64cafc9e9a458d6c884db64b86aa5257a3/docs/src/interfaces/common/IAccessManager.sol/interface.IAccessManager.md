# IAccessManager
**Inherits:**
[IEBOStorage](/interfaces/common/IEBOStorage.sol/interface.IEBOStorage.md)

Interface for the AccessManager abstract contract


## Errors
### AccessManager_OnlyOperator_NotOperator
Thrown when the caller is not an operator


```solidity
error AccessManager_OnlyOperator_NotOperator();
```

### AccessManager_OnlyArbitrator_NotArbitrator
Thrown when the caller is not the arbitrator


```solidity
error AccessManager_OnlyArbitrator_NotArbitrator();
```

### AccessManager_OnlyCouncil_NotCouncil
Thrown when the caller is not the council


```solidity
error AccessManager_OnlyCouncil_NotCouncil();
```

### AccessManager_OnlyPendingCouncil_NotPendingCouncil
Thrown when the caller is not the pending council


```solidity
error AccessManager_OnlyPendingCouncil_NotPendingCouncil();
```

