# Protocol Actors

The **protocol actors** are Ethereum externally-owned accounts (EOAs) or off-chain agents that interact with the `EBO` system.

## Deployer

The **deployer** is the protocol actor who creates a smart contract of the `EBO` system on a blockchain. They deploy the implementation contract and/or the proxy contract.

## Initializer

The **initializer** is the protocol actor who configures the foundations of the `EBO` system after deployment. They initialize the fundamental parameters of the implementation in question.

## Council

The **council** is the protocol actor who may configure the `EBO` system after initialization and may upgrade its implementation, if required.

## Pending Council

The **pending council** is the protocol actor who may accept the councilship, displacing the incumbent council.

## Proposer

The **proposer** is the protocol actor who creates a **proposal**, having escrowed a **proposal bond** through `HorizonStaking`. They propose an **epoch block** for a certain epoch and chain; thus, the **proposal status** is set to `Active`.

## Disputer

The **disputer** is the protocol actor who creates a **dispute** against a proposal, having escrowed a **dispute bond**—equal to the proposal bond—through `HorizonStaking`. They dispute the validity of the **epoch block** of the proposal; thus, the **proposal status** is set to `Disputed`.

## Pledger

The **pledger** is the protocol actor who creates a **pledge** in favour of or against a dispute, having escrowed a **pledge bond** through `HorizonStaking`. They pledge their bond either for the **proposer party** or for the **disputer party** in an intent to settle the dispute via economic incentives; however, if a resolution cannot be reached because of a tie, the **proposal status** is set to `Escalated`.

## Resolver

The **resolver** is the protocol actor who settles a dispute, slashing the bonds of the **losing party** and finalizing the bonds of the **winning party**, or finalizing the bonds of both parties in case of a tie. They resolve whose party is the winner and whose party is the loser, if any; thus, the **proposal status** is set to `DisputerWon`, `DisputerLost`, or `NoResolution`, as appropriate.

## Finalizer

The **finalizer** is the protocol actor who validates a proposal by event emission, finalizing the **proposal bond** of the proposer. They emit the **epoch block**—correspondent to a certain epoch and chain—of the proposal; thus, the **proposal status** is set to `Finalized`.

## Arbitrator

The **arbitrator** is the protocol actor who may settle *escalated* disputes at discretion, comporting himself as a *permissioned* **resolver**, and may correct and re-emit the **epoch block**—correspondent to a certain epoch and chain—of *finalized* proposals, if wrongly validated.

## Indexer

The **indexer** is the protocol actor who fetches the **epoch block**—correspondent to a certain epoch and chain—of a *finalized* proposal, decoding an emitted event. Then, they create and post a **Proof of Indexing** (PoI) for The Graph protocol.

## Bonder

The **bonder** is the protocol actor who creates a **bond** between a provision of GRT in `HorizonStaking` and the `EBO`system accounting. They bond sufficient non-thawing tokens in the form of a **proposal bond**, a **dispute bond**, or a **pledge bond**, consequently behaving as a **proposer**, **disputer**, or **pledger**, respectively.

> 💡 In `HorizonStaking`, the bonder is a **service provider** who staked and provisioned GRT to `EBOProxy` (i.e., the **verifier**).

> 💡 As in `HorizonStaking`, an **operator** may act in the name of a **service provider** and bond on his behalf.

## Unbonder

The **unbonder** is the protocol actor who finalizes a **bond** between a provision of GRT in `HorizonStaking` and the `EBO` system accounting. They unbond the non-thawing tokens of a **bonder** constituting a **proposal bond** (i.e., of a **proposer**), a **dispute bond** (i.e., of a **disputer**), or a **pledge bond** (i.e., of a **pledger**), consequently behaving as a **resolver** (**arbitrator** or not), or **finalizer**.

> 💡 In `HorizonStaking`, the unbonder is not the **verifier** of the provisions of GRT, but `EBOProxy` is.
