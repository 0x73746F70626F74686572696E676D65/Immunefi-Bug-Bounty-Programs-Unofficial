#!/bin/bash

# path to the src folder
src_folder="docs/src"
# path to the temp folder
temp_folder="docs/temp"

# generate docs in a temporary directory
FOUNDRY_PROFILE=doc forge doc --out $temp_folder

# delete old generated docs
rm -rf $src_folder/contracts $src_folder/interfaces

# delete the old generated SUMMARY (i.e., after the Technical Documentation section)
# https://stackoverflow.com/questions/67086574/no-such-file-or-directory-when-using-sed-in-combination-with-find
if [[ $OSTYPE == "darwin"* ]]; then
    sed -i '' "/# Technical Documentation/q" $src_folder/SUMMARY.md
else
    sed -i "/# Technical Documentation/q" $src_folder/SUMMARY.md
fi

# there are differences in cp and mv behavior between UNIX and macOS when it comes to non-existing directories
# creating the directory to circumvent them
mkdir -p $src_folder/contracts $src_folder/interfaces

# copy and paste new generated docs from tmp to original directory
cp -R $temp_folder/src/src/{contracts,interfaces} $src_folder

# append the new generated SUMMARY, starting from line 4, to the original SUMMARY (i.e., after the Technical Documentation section)
tail +4 $temp_folder/src/SUMMARY.md >> $src_folder/SUMMARY.md

# delete the temporary directory
rm -rf $temp_folder

# function to replace patterns in all files (to fix the internal paths)
replace_patterns() {
    substitutions=(
        "s|src/||g"
        "s|contracts)|contracts/)|g"
        "s|interfaces)|interfaces/)|g"
        "s|common)|common/)|g"
        "s|modules)|modules/)|g"
        "s|universal)|universal/)|g"
    )

    for file in $1/*; do
        if [ -f $file ]; then
            for substitution in ${substitutions[@]}; do
                # https://stackoverflow.com/questions/67086574/no-such-file-or-directory-when-using-sed-in-combination-with-find
                if [[ $OSTYPE == "darwin"* ]]; then
                    sed -i '' $substitution $file
                else
                    sed -i $substitution $file
                fi
            done
        elif [ -d $file ]; then
            replace_patterns $file
        fi
    done
}

# calling the function to fix the paths
replace_patterns $src_folder
