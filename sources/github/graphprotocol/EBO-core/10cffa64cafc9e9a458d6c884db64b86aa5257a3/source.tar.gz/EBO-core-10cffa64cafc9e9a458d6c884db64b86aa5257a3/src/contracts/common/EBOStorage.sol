// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {EnumerableSet} from '@openzeppelin/contracts/utils/structs/EnumerableSet.sol';

import {IEBOStorage, IERC20, IEpochManager, IHorizonStaking} from 'interfaces/common/IEBOStorage.sol';

/**
 * @title EBOStorage abstract contract
 * @notice Provides the storage layout for the EBO system
 */
abstract contract EBOStorage is IEBOStorage {
  using EnumerableSet for EnumerableSet.AddressSet;

  /// @inheritdoc IEBOStorage
  uint32 public constant MAX_MAX_VERIFIER_CUT = 1_000_000;

  /// @inheritdoc IEBOStorage
  IERC20 public grt;

  /// @inheritdoc IEBOStorage
  IHorizonStaking public horizonStaking;

  /// @inheritdoc IEBOStorage
  IEpochManager public epochManager;

  /// @inheritdoc IEBOStorage
  address public council;

  /// @inheritdoc IEBOStorage
  address public pendingCouncil;

  /// @inheritdoc IEBOStorage
  address public arbitrator;

  /// @inheritdoc IEBOStorage
  uint256 public startEpoch;

  /// @inheritdoc IEBOStorage
  uint256 public proposalId;

  /// @inheritdoc IEBOStorage
  uint256 public parametersSnapshotId;

  /// @inheritdoc IEBOStorage
  mapping(uint256 _epoch => mapping(string _chainId => uint256 _proposalId)) public activeProposal;

  /// @inheritdoc IEBOStorage
  mapping(address _bonder => uint256 _bondSize) public bonds;

  /// @inheritdoc IEBOStorage
  mapping(uint256 _proposalId => Proposal _proposal) public proposals;

  /// @inheritdoc IEBOStorage
  mapping(uint256 _parametersSnapshotId => Parameters _parameters) public parametersSnapshots;

  /// @inheritdoc IEBOStorage
  mapping(uint256 _proposalId => mapping(address _pledger => uint256 _pledgesForDispute)) public pledgesForDispute;

  /// @inheritdoc IEBOStorage
  mapping(uint256 _proposalId => mapping(address _pledger => uint256 _pledgesAgainstDispute)) public
    pledgesAgainstDispute;

  /// @inheritdoc IEBOStorage
  mapping(uint256 _proposalId => Dispute _dispute) public disputes;

  /// @inheritdoc IEBOStorage
  mapping(uint256 _proposalId => mapping(address _pledger => bool _claimed)) public pledgerClaimed;

  /// @inheritdoc IEBOStorage
  mapping(string _chainId => bool _allowed) public chainIdsAllowed;

  /**
   * @notice Stores the pledgers that have pledged in favor of a given dispute
   */
  mapping(uint256 _proposalId => EnumerableSet.AddressSet _pledgersForDispute) internal _disputePledgersFor;

  /**
   * @notice Stores the pledgers that have pledged against a given dispute
   */
  mapping(uint256 _proposalId => EnumerableSet.AddressSet _pledgersAgainstDispute) internal _disputePledgersAgainst;

  /// @inheritdoc IEBOStorage
  function pledgersForDispute(uint256 _proposalId) external view returns (address[] memory _pledgersForDispute) {
    _pledgersForDispute = _disputePledgersFor[_proposalId].values();
  }

  /// @inheritdoc IEBOStorage
  function pledgersAgainstDispute(uint256 _proposalId)
    external
    view
    returns (address[] memory _pledgersAgainstDispute)
  {
    _pledgersAgainstDispute = _disputePledgersAgainst[_proposalId].values();
  }
}
