// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IBondManager} from 'interfaces/common/IBondManager.sol';
import {IEBOStorage} from 'interfaces/common/IEBOStorage.sol';

/**
 * @title IResolutionManager
 * @notice Interface for the ResolutionManager abstract contract
 */
interface IResolutionManager is IBondManager {
  /*///////////////////////////////////////////////////////////////
                              STRUCTS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Read-only parameters for resolving a dispute
   * @param proposalId The ID of the proposal
   * @param proposalCreatedAt The creation timestamp of the proposal
   * @param minThawingPeriod The minimum thawing period
   * @param proposalBondSize The bond size per proposal or dispute
   * @param pledgeBondSize The bond size per pledge
   * @param totalPledgesForDispute The total number of pledges made in favor of the dispute
   * @param totalPledgesAgainstDispute The total number of pledges made against the dispute
   * @param proposer The proposer of the proposal
   * @param disputer The disputer of the proposal
   * @param resolutionStatus The status of the resolution
   */
  struct ResolveParams {
    uint256 proposalId;
    uint256 proposalCreatedAt;
    uint256 minThawingPeriod;
    uint256 proposalBondSize;
    uint256 pledgeBondSize;
    uint256 totalPledgesForDispute;
    uint256 totalPledgesAgainstDispute;
    address proposer;
    address disputer;
    IEBOStorage.ProposalStatus resolutionStatus;
  }

  /*///////////////////////////////////////////////////////////////
                              EVENTS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Emitted when a dispute is resolved
   * @param _proposalId The ID of the proposal
   * @param _resolutionStatus The status of the resolution
   */
  event DisputeResolved(uint256 indexed _proposalId, IEBOStorage.ProposalStatus _resolutionStatus);
}
