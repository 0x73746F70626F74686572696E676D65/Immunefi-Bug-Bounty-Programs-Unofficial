// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IEBOCore} from 'interfaces/modules/IEBOCore.sol';

import {AccessManager} from 'contracts/common/AccessManager.sol';
import {ResolutionManager} from 'contracts/common/ResolutionManager.sol';

/**
 * @title EBOCore module abstract contract
 * @notice Contains the core logic for EBO
 */
abstract contract EBOCore is ResolutionManager, AccessManager, IEBOCore {
  /// @inheritdoc IEBOCore
  function propose(
    uint256 _epoch,
    string calldata _chainId,
    uint256 _blockNumber,
    address _serviceProvider
  ) external onlyOperator(_serviceProvider) {
    if (_epoch > epochManager.currentEpoch() || startEpoch > _epoch) {
      revert EBOCore_Propose_InvalidEpoch();
    }

    if (!chainIdsAllowed[_chainId]) revert EBOCore_Propose_ChainNotAdded();

    if (activeProposal[_epoch][_chainId] != 0) {
      revert EBOCore_Propose_ProposalAlreadyActive();
    }

    uint256 _proposalId = ++proposalId;
    uint256 _parametersSnapshotId = parametersSnapshotId;

    _bond({_bonder: _serviceProvider, _amount: parametersSnapshots[_parametersSnapshotId].proposalBondSize});

    activeProposal[_epoch][_chainId] = _proposalId;

    proposals[_proposalId] = Proposal({
      epoch: _epoch,
      chainId: _chainId,
      blockNumber: _blockNumber,
      proposer: _serviceProvider,
      createdAt: block.timestamp,
      parametersSnapshotId: _parametersSnapshotId,
      status: ProposalStatus.Active
    });

    emit ProposalCreated(_proposalId, _epoch, _chainId, _blockNumber, _serviceProvider);
  }

  /// @inheritdoc IEBOCore
  function dispute(uint256 _proposalId, address _serviceProvider) external onlyOperator(_serviceProvider) {
    Proposal storage _proposal = proposals[_proposalId];
    if (_proposal.status != ProposalStatus.Active) revert EBOCore_Dispute_ProposalNotActive();

    Parameters storage _parameters = parametersSnapshots[_proposal.parametersSnapshotId];

    if (_disputeWindowHasPassed(_proposal.createdAt, _parameters.disputeWindow)) {
      revert EBOCore_Dispute_DisputeWindowOver();
    }

    _bond({_bonder: _serviceProvider, _amount: _parameters.proposalBondSize});

    disputes[_proposalId] = Dispute({
      disputer: _serviceProvider,
      createdAt: block.timestamp,
      lastPledgeTimestamp: 0,
      totalPledgesForDispute: 0,
      totalPledgesAgainstDispute: 0,
      rewardPerWinningPledge: 0
    });

    _proposal.status = ProposalStatus.Disputed;

    activeProposal[_proposal.epoch][_proposal.chainId] = 0;

    emit ProposalDisputed(_proposalId);
  }

  /// @inheritdoc IEBOCore
  function resolve(uint256 _proposalId) external {
    Proposal storage _proposal = proposals[_proposalId];
    Parameters storage _parameters = parametersSnapshots[_proposal.parametersSnapshotId];
    Dispute storage _dispute = disputes[_proposalId];
    uint256 _totalPledgesForDispute = _dispute.totalPledgesForDispute;
    uint256 _totalPledgesAgainstDispute = _dispute.totalPledgesAgainstDispute;
    ProposalStatus _resolutionStatus;

    if (_proposal.status != ProposalStatus.Disputed) {
      revert EBOCore_Resolve_ProposalNotDisputed();
    }

    if (!_pledgeWindowHasPassed({
        _disputeCreatedAt: _dispute.createdAt,
        _lastPledgeTimestamp: _dispute.lastPledgeTimestamp,
        _pledgeWindow: _parameters.pledgeWindow,
        _pledgeRefreshWindow: _parameters.pledgeRefreshWindow
      })) {
      revert EBOCore_Resolve_PledgeWindowNotOver();
    }

    if (_totalPledgesForDispute == 0 && _totalPledgesAgainstDispute == 0) {
      _resolutionStatus = ProposalStatus.NoResolution;
    } else {
      _resolutionStatus = _totalPledgesForDispute > _totalPledgesAgainstDispute
        ? ProposalStatus.DisputerWon
        : ProposalStatus.DisputerLost;
    }

    _resolve(
      ResolveParams({
        proposalId: _proposalId,
        proposalCreatedAt: _proposal.createdAt,
        minThawingPeriod: _parameters.minThawingPeriod,
        proposalBondSize: _parameters.proposalBondSize,
        pledgeBondSize: _parameters.pledgeBondSize,
        proposer: _proposal.proposer,
        disputer: _dispute.disputer,
        totalPledgesForDispute: _totalPledgesForDispute,
        totalPledgesAgainstDispute: _totalPledgesAgainstDispute,
        resolutionStatus: _resolutionStatus
      })
    );
  }

  /// @inheritdoc IEBOCore
  function resolve(uint256 _proposalId, ProposalStatus _resolutionStatus) external onlyArbitrator {
    Proposal storage _proposal = proposals[_proposalId];
    if (_proposal.status != ProposalStatus.Escalated) revert EBOCore_Resolve_DisputeNotEscalated();

    if (
      _resolutionStatus != ProposalStatus.DisputerWon && _resolutionStatus != ProposalStatus.DisputerLost
        && _resolutionStatus != ProposalStatus.NoResolution
    ) revert EBOCore_Resolve_InvalidStatus();

    Parameters storage _parameters = parametersSnapshots[_proposal.parametersSnapshotId];
    Dispute storage _dispute = disputes[_proposalId];

    _resolve(
      ResolveParams({
        proposalId: _proposalId,
        proposalCreatedAt: _proposal.createdAt,
        minThawingPeriod: _parameters.minThawingPeriod,
        proposalBondSize: _parameters.proposalBondSize,
        pledgeBondSize: _parameters.pledgeBondSize,
        proposer: _proposal.proposer,
        disputer: _dispute.disputer,
        totalPledgesForDispute: _dispute.totalPledgesForDispute,
        totalPledgesAgainstDispute: _dispute.totalPledgesAgainstDispute,
        resolutionStatus: _resolutionStatus
      })
    );
  }

  /// @inheritdoc IEBOCore
  function finalize(uint256 _proposalId) external {
    Proposal storage _proposal = proposals[_proposalId];
    if (_proposal.status != ProposalStatus.Active) revert EBOCore_Finalize_ProposalNotActive();

    Parameters storage _parameters = parametersSnapshots[_proposal.parametersSnapshotId];

    if (!_disputeWindowHasPassed(_proposal.createdAt, _parameters.disputeWindow)) {
      revert EBOCore_Finalize_DisputeWindowNotOver();
    }

    _unbond({_bonder: _proposal.proposer, _amount: _parameters.proposalBondSize});

    _proposal.status = ProposalStatus.Finalized;

    emit ProposalFinalized(_proposalId, _proposal.epoch, _proposal.chainId, _proposal.blockNumber);
  }

  /// @inheritdoc IEBOCore
  function amendEpochBlock(uint256 _proposalId, uint256 _blockNumber) external onlyArbitrator {
    Proposal storage _proposal = proposals[_proposalId];
    if (_proposal.status != ProposalStatus.Finalized) revert EBOCore_AmendEpochBlock_ProposalNotFinalized();

    _proposal.blockNumber = _blockNumber;

    emit ProposalAmended(_proposalId, _proposal.epoch, _proposal.chainId, _blockNumber);
  }
}
