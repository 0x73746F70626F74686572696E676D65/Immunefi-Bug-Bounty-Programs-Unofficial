// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {EnumerableSet} from '@openzeppelin/contracts/utils/structs/EnumerableSet.sol';

import {IResolutionManager} from 'interfaces/common/IResolutionManager.sol';

import {BondManager} from 'contracts/common/BondManager.sol';

/**
 * @title ResolutionManager abstract contract
 * @notice Contains the reusable logic for the dispute resolution functionality
 */
abstract contract ResolutionManager is BondManager, IResolutionManager {
  using EnumerableSet for EnumerableSet.AddressSet;

  /**
   * @notice Resolves a dispute
   * @param _resolveParams The parameters for the resolution
   * @dev The possible statuses of a resolution are: NoResolution, DisputerWon, and DisputerLost.
   */
  function _resolve(ResolveParams memory _resolveParams) internal {
    // If the dispute is resolved after the thawing period, set the status to NoResolution
    if (block.timestamp > _resolveParams.proposalCreatedAt + _resolveParams.minThawingPeriod) {
      _resolveParams.resolutionStatus = ProposalStatus.NoResolution;
    }

    uint256 _rewardPerWinningPledge;

    if (_resolveParams.resolutionStatus == ProposalStatus.NoResolution) {
      // Unbond the pledgers of both sides
      _unbondPledges({
        _pledgeBondSize: _resolveParams.pledgeBondSize,
        _pledgersToUnbond: _disputePledgersFor[_resolveParams.proposalId],
        _pledgesToUnbond: pledgesForDispute[_resolveParams.proposalId]
      });
      _unbondPledges({
        _pledgeBondSize: _resolveParams.pledgeBondSize,
        _pledgersToUnbond: _disputePledgersAgainst[_resolveParams.proposalId],
        _pledgesToUnbond: pledgesAgainstDispute[_resolveParams.proposalId]
      });
    } else {
      address _payer;
      address _receiver;

      if (_resolveParams.resolutionStatus == ProposalStatus.DisputerWon) {
        _payer = _resolveParams.proposer;
        _receiver = _resolveParams.disputer;
        _rewardPerWinningPledge = _resolveParams.pledgeBondSize * _resolveParams.totalPledgesAgainstDispute
          / _resolveParams.totalPledgesForDispute;

        // Slash and unbond the pledgers of the losing side
        _slashPledges({
          _pledgeBondSize: _resolveParams.pledgeBondSize,
          _pledgersToSlash: _disputePledgersAgainst[_resolveParams.proposalId],
          _pledgesToSlash: pledgesAgainstDispute[_resolveParams.proposalId]
        });

        // Unbond the pledges of the winning side
        _unbondPledges({
          _pledgeBondSize: _resolveParams.pledgeBondSize,
          _pledgersToUnbond: _disputePledgersFor[_resolveParams.proposalId],
          _pledgesToUnbond: pledgesForDispute[_resolveParams.proposalId]
        });
      } else {
        _payer = _resolveParams.disputer;
        _receiver = _resolveParams.proposer;
        _rewardPerWinningPledge = _resolveParams.pledgeBondSize * _resolveParams.totalPledgesForDispute
          / _resolveParams.totalPledgesAgainstDispute;

        // Slash and unbond the pledgers of the losing side
        _slashPledges({
          _pledgeBondSize: _resolveParams.pledgeBondSize,
          _pledgersToSlash: _disputePledgersFor[_resolveParams.proposalId],
          _pledgesToSlash: pledgesForDispute[_resolveParams.proposalId]
        });

        // Unbond the pledges of the winning side
        _unbondPledges({
          _pledgeBondSize: _resolveParams.pledgeBondSize,
          _pledgersToUnbond: _disputePledgersAgainst[_resolveParams.proposalId],
          _pledgesToUnbond: pledgesAgainstDispute[_resolveParams.proposalId]
        });
      }

      // Slash the payer and pay the receiver
      horizonStaking.slash({
        serviceProvider: _payer,
        tokens: _resolveParams.proposalBondSize,
        tokensVerifier: _resolveParams.proposalBondSize,
        verifierDestination: _receiver
      });
    }

    // Unbond the disputer and proposer bonds
    _unbond({_bonder: _resolveParams.disputer, _amount: _resolveParams.proposalBondSize});
    _unbond({_bonder: _resolveParams.proposer, _amount: _resolveParams.proposalBondSize});

    // Update the proposal status
    proposals[_resolveParams.proposalId].status = _resolveParams.resolutionStatus;
    // Update the reward per winning pledge
    disputes[_resolveParams.proposalId].rewardPerWinningPledge = _rewardPerWinningPledge;

    emit DisputeResolved(_resolveParams.proposalId, _resolveParams.resolutionStatus);
  }

  /**
   * @notice Returns true if the dispute window has passed for a proposal
   * @param _proposalCreatedAt The creation timestamp of the proposal
   * @param _disputeWindow The dispute window
   * @return _passed True if the dispute window has passed
   */
  function _disputeWindowHasPassed(
    uint256 _proposalCreatedAt,
    uint256 _disputeWindow
  ) internal view returns (bool _passed) {
    _passed = block.timestamp >= _proposalCreatedAt + _disputeWindow;
  }

  /**
   * @notice Returns true if the pledge window has passed for a dispute
   * @param _disputeCreatedAt The creation timestamp of the dispute
   * @param _lastPledgeTimestamp The timestamp of the last pledge
   * @param _pledgeWindow The pledge window
   * @param _pledgeRefreshWindow The pledge refresh window
   * @return _passed True if the pledge window has passed
   */
  function _pledgeWindowHasPassed(
    uint256 _disputeCreatedAt,
    uint256 _lastPledgeTimestamp,
    uint256 _pledgeWindow,
    uint256 _pledgeRefreshWindow
  ) internal view returns (bool _passed) {
    if (block.timestamp >= _disputeCreatedAt + _pledgeWindow) {
      _passed = block.timestamp >= _lastPledgeTimestamp + _pledgeRefreshWindow;
    }
  }

  /**
   * @notice Slashes and unbonds the losing pledgers
   * @param _pledgeBondSize The bond size per pledge
   * @param _pledgersToSlash The pledgers to slash
   * @param _pledgesToSlash The pledges to slash
   */
  function _slashPledges(
    uint256 _pledgeBondSize,
    EnumerableSet.AddressSet storage _pledgersToSlash,
    mapping(address _pledger => uint256 _pledges) storage _pledgesToSlash
  ) private {
    address _pledgerToSlash;
    uint256 _slashAmount;
    uint256 _pledgersToSlashLength = _pledgersToSlash.length();

    for (uint256 _i; _i < _pledgersToSlashLength; ++_i) {
      _pledgerToSlash = _pledgersToSlash.at(_i);
      _slashAmount = _pledgeBondSize * _pledgesToSlash[_pledgerToSlash];

      // Slash the pledger and receive the GRT slashed amount in the EBO contract
      horizonStaking.slash({
        serviceProvider: _pledgerToSlash,
        tokens: _slashAmount,
        tokensVerifier: _slashAmount,
        verifierDestination: address(this)
      });

      _unbond({_bonder: _pledgerToSlash, _amount: _slashAmount});
    }
  }

  /**
   * @notice Releases the bonds of the winning pledgers
   * @param _pledgeBondSize The bond size per pledge
   * @param _pledgersToUnbond The pledgers to unbond
   * @param _pledgesToUnbond The pledges to unbond
   */
  function _unbondPledges(
    uint256 _pledgeBondSize,
    EnumerableSet.AddressSet storage _pledgersToUnbond,
    mapping(address _pledger => uint256 _pledges) storage _pledgesToUnbond
  ) private {
    address _pledgerToUnbond;
    uint256 _pledgersToUnbondLength = _pledgersToUnbond.length();

    for (uint256 _i; _i < _pledgersToUnbondLength; ++_i) {
      _pledgerToUnbond = _pledgersToUnbond.at(_i);
      _unbond({_bonder: _pledgerToUnbond, _amount: _pledgeBondSize * _pledgesToUnbond[_pledgerToUnbond]});
    }
  }
}
