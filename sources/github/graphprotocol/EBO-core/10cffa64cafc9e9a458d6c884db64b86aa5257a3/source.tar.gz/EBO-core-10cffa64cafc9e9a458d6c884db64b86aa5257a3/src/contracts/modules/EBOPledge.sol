// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IERC20, SafeERC20} from '@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol';

import {EnumerableSet} from '@openzeppelin/contracts/utils/structs/EnumerableSet.sol';

import {AccessManager} from 'contracts/common/AccessManager.sol';

import {ResolutionManager} from 'contracts/common/ResolutionManager.sol';

import {IEBOPledge} from 'interfaces/modules/IEBOPledge.sol';

/**
 * @title EBOPledge module abstract contract
 * @notice Contains the logic for the dispute pledge functionality
 */
abstract contract EBOPledge is ResolutionManager, AccessManager, IEBOPledge {
  using SafeERC20 for IERC20;
  using EnumerableSet for EnumerableSet.AddressSet;

  /// @inheritdoc IEBOPledge
  function claimPledgeReward(uint256 _proposalId, address _pledger) external {
    ProposalStatus _proposalStatus = proposals[_proposalId].status;

    if (_proposalStatus != ProposalStatus.DisputerLost && _proposalStatus != ProposalStatus.DisputerWon) {
      revert EBOPledge_ClaimPledgeReward_DisputeHasNoResolution();
    }

    if (pledgerClaimed[_proposalId][_pledger]) revert EBOPledge_ClaimPledgeReward_AlreadyClaimed();

    uint256 _rewardAmount = _proposalStatus == ProposalStatus.DisputerWon
      ? pledgesForDispute[_proposalId][_pledger] * disputes[_proposalId].rewardPerWinningPledge
      : pledgesAgainstDispute[_proposalId][_pledger] * disputes[_proposalId].rewardPerWinningPledge;

    if (_rewardAmount == 0) {
      revert EBOPledge_ClaimPledgeReward_NoRewardToClaim();
    }

    pledgerClaimed[_proposalId][_pledger] = true;

    // Send the bonder the amount they won by participating in the dispute
    grt.safeTransfer(_pledger, _rewardAmount);

    emit PledgeRewardClaimed(_proposalId, _pledger, _rewardAmount);
  }

  /// @inheritdoc IEBOPledge
  function pledgeForDispute(uint256 _proposalId, address _serviceProvider) external onlyOperator(_serviceProvider) {
    uint256 _pledgeAmount = _pledge({_pledger: _serviceProvider, _proposalId: _proposalId, _forDispute: true});
    emit PledgedForDispute(_proposalId, _serviceProvider, _pledgeAmount);
  }

  /// @inheritdoc IEBOPledge
  function pledgeAgainstDispute(uint256 _proposalId, address _serviceProvider) external onlyOperator(_serviceProvider) {
    uint256 _pledgeAmount = _pledge({_pledger: _serviceProvider, _proposalId: _proposalId, _forDispute: false});
    emit PledgedAgainstDispute(_proposalId, _serviceProvider, _pledgeAmount);
  }

  /**
   * @notice Pledges `for` or `against` a dispute
   * @param _pledger The address of the pledger
   * @param _proposalId The ID of the proposal
   * @param _forDispute True if the pledge is `for` the dispute, false if it is `against` the dispute
   * @return _pledgeAmount The amount of GRT tokens pledged
   */
  function _pledge(address _pledger, uint256 _proposalId, bool _forDispute) private returns (uint256 _pledgeAmount) {
    Proposal storage _proposal = proposals[_proposalId];
    if (_proposal.status != ProposalStatus.Disputed) revert EBOPledge_Pledge_ProposalNotDisputed();

    Dispute storage _dispute = disputes[_proposalId];
    Parameters storage _parameters = parametersSnapshots[_proposal.parametersSnapshotId];

    if (_pledgeWindowHasPassed({
        _disputeCreatedAt: _dispute.createdAt,
        _lastPledgeTimestamp: _dispute.lastPledgeTimestamp,
        _pledgeWindow: _parameters.pledgeWindow,
        _pledgeRefreshWindow: _parameters.pledgeRefreshWindow
      })) {
      revert EBOPledge_Pledge_PledgeWindowOver();
    }

    _dispute.lastPledgeTimestamp = block.timestamp;

    (uint256 _sidePledges, uint256 _oppositePledges) = _forDispute
      ? (_dispute.totalPledgesForDispute, _dispute.totalPledgesAgainstDispute)
      : (_dispute.totalPledgesAgainstDispute, _dispute.totalPledgesForDispute);

    if (_sidePledges > _oppositePledges) {
      revert EBOPledge_Pledge_CannotPledgeIfWinning();
    }

    uint256 _pledgesRequired = (_oppositePledges > 0 && _sidePledges + 2 <= _parameters.maxNumberOfPledges) ? 2 : 1;
    _pledgeAmount = _parameters.pledgeBondSize * _pledgesRequired;

    _bond({_bonder: _pledger, _amount: _pledgeAmount});

    if (_forDispute) {
      _disputePledgersFor[_proposalId].add(_pledger);
      _dispute.totalPledgesForDispute += _pledgesRequired;
      pledgesForDispute[_proposalId][_pledger] += _pledgesRequired;
    } else {
      _disputePledgersAgainst[_proposalId].add(_pledger);
      _dispute.totalPledgesAgainstDispute += _pledgesRequired;
      pledgesAgainstDispute[_proposalId][_pledger] += _pledgesRequired;
    }

    if (
      _oppositePledges == _parameters.maxNumberOfPledges
        && (_sidePledges + _pledgesRequired) == _parameters.maxNumberOfPledges
    ) {
      _proposal.status = ProposalStatus.Escalated;
      emit DisputeEscalated(_proposalId);
    }
  }
}
