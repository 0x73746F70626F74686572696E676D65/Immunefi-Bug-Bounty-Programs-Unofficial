// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IEBOConfig, IERC20, IEpochManager, IHorizonStaking} from 'interfaces/modules/IEBOConfig.sol';

import {AccessManager} from 'contracts/common/AccessManager.sol';

/**
 * @title EBOConfig module abstract contract
 * @notice Contains the configuration logic for EBO
 */
abstract contract EBOConfig is AccessManager, IEBOConfig {
  /// @inheritdoc IEBOConfig
  function setArbitrator(address _arbitrator) external onlyCouncil {
    _setArbitrator(_arbitrator);
  }

  /// @inheritdoc IEBOConfig
  function setPendingCouncil(address _pendingCouncil) external onlyCouncil {
    _setPendingCouncil(_pendingCouncil);
  }

  /// @inheritdoc IEBOConfig
  function confirmCouncil() external onlyPendingCouncil {
    _setCouncil(pendingCouncil);
    _setPendingCouncil(address(0));
  }

  /// @inheritdoc IEBOConfig
  function setGRT(IERC20 _grt) external onlyCouncil {
    _setGRT(_grt);
  }

  /// @inheritdoc IEBOConfig
  function setHorizonStaking(IHorizonStaking _horizonStaking) external onlyCouncil {
    _setHorizonStaking(_horizonStaking);
  }

  /// @inheritdoc IEBOConfig
  function setEpochManager(IEpochManager _epochManager) external onlyCouncil {
    _setEpochManager(_epochManager);
  }

  /// @inheritdoc IEBOConfig
  function addChainIds(string[] calldata _chainIds) external onlyCouncil {
    _addChainIds(_chainIds);
  }

  /// @inheritdoc IEBOConfig
  function removeChainIds(string[] calldata _chainIds) external onlyCouncil {
    _removeChainIds(_chainIds);
  }

  /// @inheritdoc IEBOConfig
  function setParameters(Parameters calldata _parameters, uint256 _arbitratorResolutionWindow) external onlyCouncil {
    _setParameters(_parameters, _arbitratorResolutionWindow);
  }

  /**
   * @notice Sets the arbitrator
   * @param _arbitrator The address of the arbitrator
   */
  function _setArbitrator(address _arbitrator) internal {
    if (_arbitrator == arbitrator) {
      revert EBOConfig_SetArbitrator_AddressAlreadySet();
    }

    arbitrator = _arbitrator;
    emit ArbitratorSet(_arbitrator);
  }

  /**
   * @notice Sets the pending council
   * @param _pendingCouncil The address of the pending council
   */
  function _setPendingCouncil(address _pendingCouncil) internal {
    if (_pendingCouncil == pendingCouncil) {
      revert EBOConfig_SetPendingCouncil_AddressAlreadySet();
    }

    pendingCouncil = _pendingCouncil;
    emit PendingCouncilSet(_pendingCouncil);
  }

  /**
   * @notice Sets the council
   * @param _council The address of the council
   */
  function _setCouncil(address _council) internal {
    if (_council == council) {
      revert EBOConfig_SetCouncil_AddressAlreadySet();
    }

    council = _council;
    emit CouncilSet(_council);
  }

  /**
   * @notice Sets the GRT token contract
   * @param _grt The address of the GRT token contract
   */
  function _setGRT(IERC20 _grt) internal {
    if (_grt == grt) {
      revert EBOConfig_SetGRT_AddressAlreadySet();
    }

    grt = _grt;
    emit GRTSet(_grt);
  }

  /**
   * @notice Sets the HorizonStaking contract
   * @param _horizonStaking The address of the HorizonStaking contract
   */
  function _setHorizonStaking(IHorizonStaking _horizonStaking) internal {
    if (_horizonStaking == horizonStaking) {
      revert EBOConfig_SetHorizonStaking_AddressAlreadySet();
    }

    horizonStaking = _horizonStaking;
    emit HorizonStakingSet(_horizonStaking);
  }

  /**
   * @notice Sets the EpochManager contract
   * @param _epochManager The address of the EpochManager contract
   */
  function _setEpochManager(IEpochManager _epochManager) internal {
    if (_epochManager == epochManager) {
      revert EBOConfig_SetEpochManager_AddressAlreadySet();
    }

    epochManager = _epochManager;
    emit EpochManagerSet(_epochManager);
  }

  /**
   * @notice Sets the start epoch
   * @dev To be set only once during initialization
   * @param _startEpoch The start epoch
   */
  function _setStartEpoch(uint256 _startEpoch) internal {
    startEpoch = _startEpoch;
    emit StartEpochSet(_startEpoch);
  }

  /**
   * @notice Adds an array of chain IDs
   * @param _chainIds The chain IDs
   */
  function _addChainIds(string[] calldata _chainIds) internal {
    string memory _chainId;
    for (uint256 _i; _i < _chainIds.length; ++_i) {
      _chainId = _chainIds[_i];
      if (chainIdsAllowed[_chainId]) revert EBOConfig_AddChainIds_ChainIdAlreadyAdded();

      chainIdsAllowed[_chainId] = true;
      emit ChainIdAdded(_chainId);
    }
  }

  /**
   * @notice Removes an array of chain IDs
   * @param _chainIds The chain IDs
   */
  function _removeChainIds(string[] calldata _chainIds) internal {
    string memory _chainId;
    for (uint256 _i; _i < _chainIds.length; ++_i) {
      _chainId = _chainIds[_i];
      if (!chainIdsAllowed[_chainId]) revert EBOConfig_RemoveChainIds_ChainIdNotAdded();

      chainIdsAllowed[_chainId] = false;
      emit ChainIdRemoved(_chainId);
    }
  }

  /**
   * @notice Sets the parameters for proposals and disputes
   * @param _parameters The parameters for proposals and disputes
   * @param _arbitratorResolutionWindow The arbitrator resolution window
   */
  function _setParameters(Parameters calldata _parameters, uint256 _arbitratorResolutionWindow) internal {
    _checkParameters(_parameters, _arbitratorResolutionWindow);

    uint256 _parametersSnapshotId = ++parametersSnapshotId;

    parametersSnapshots[_parametersSnapshotId] = _parameters;
    emit ParametersSet(_parameters, _parametersSnapshotId, _arbitratorResolutionWindow);
  }

  /**
   * @notice Checks if the parameters are valid and compliant with the EBO protocol
   * @param _parameters The parameters for proposals and disputes
   * @param _arbitratorResolutionWindow The arbitrator resolution window
   */
  function _checkParameters(Parameters calldata _parameters, uint256 _arbitratorResolutionWindow) private pure {
    if (
      _parameters.proposalBondSize == 0 || _parameters.pledgeBondSize == 0 || _parameters.disputeWindow == 0
        || _parameters.pledgeRefreshWindow == 0 || _arbitratorResolutionWindow == 0
    ) {
      revert EBOConfig_CheckParameters_ParametersCannotBeZero();
    }

    if (_parameters.pledgeRefreshWindow > _parameters.pledgeWindow) {
      revert EBOConfig_CheckParameters_PledgeRefreshWindowExceedsPledgeWindow();
    }

    uint256 _maxCumulativePledgeRefreshWindow = _parameters.maxNumberOfPledges * _parameters.pledgeRefreshWindow;
    uint256 _maxProposalLifecycleDuration = _parameters.disputeWindow + _parameters.pledgeWindow
      + _maxCumulativePledgeRefreshWindow + _arbitratorResolutionWindow;

    if (_maxProposalLifecycleDuration > _parameters.minThawingPeriod) {
      revert EBOConfig_CheckParameters_MinThawingPeriodTooShort();
    }
  }

  /**
   * @notice Returns the ceiling of the division of two numbers
   * @param _a The dividend
   * @param _b The divisor
   * @return _result The ceiling of the division
   */
  function _ceilDiv(uint256 _a, uint256 _b) private pure returns (uint256 _result) {
    _result = (_a + _b - 1) / _b;
  }
}
