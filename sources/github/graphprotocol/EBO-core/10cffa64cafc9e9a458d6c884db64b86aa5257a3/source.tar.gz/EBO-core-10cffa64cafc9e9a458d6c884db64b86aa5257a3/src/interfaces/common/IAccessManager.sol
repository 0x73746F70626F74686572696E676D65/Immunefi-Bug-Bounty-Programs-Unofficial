// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IEBOStorage} from 'interfaces/common/IEBOStorage.sol';

/**
 * @title IAccessManager
 * @notice Interface for the AccessManager abstract contract
 */
interface IAccessManager is IEBOStorage {
  /*///////////////////////////////////////////////////////////////
                              ERRORS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Thrown when the caller is not an operator
   */
  error AccessManager_OnlyOperator_NotOperator();

  /**
   * @notice Thrown when the caller is not the arbitrator
   */
  error AccessManager_OnlyArbitrator_NotArbitrator();

  /**
   * @notice Thrown when the caller is not the council
   */
  error AccessManager_OnlyCouncil_NotCouncil();

  /**
   * @notice Thrown when the caller is not the pending council
   */
  error AccessManager_OnlyPendingCouncil_NotPendingCouncil();
}
