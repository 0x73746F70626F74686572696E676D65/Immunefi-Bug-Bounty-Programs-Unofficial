// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IEBOStorage} from 'interfaces/common/IEBOStorage.sol';

/**
 * @title IBondManager
 * @notice Interface for the BondManager abstract contract
 */
interface IBondManager is IEBOStorage {
  /*///////////////////////////////////////////////////////////////
                              ERRORS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Thrown when bonding and the bonder has an invalid maximum verifier cut
   */
  error BondManager_Bond_InvalidMaxVerifierCut();

  /**
   * @notice Thrown when bonding and the bonder has an invalid thawing period
   */
  error BondManager_Bond_InvalidThawingPeriod();

  /**
   * @notice Thrown when bonding and the bonder has insufficient non-thawing tokens
   */
  error BondManager_Bond_InsufficientNonThawingTokens();

  /**
   * @notice Thrown when bonding and the bonder's bonded tokens exceed his non-thawing tokens
   */
  error BondManager_Bond_BondedTokensExceedNonThawingTokens();

  /**
   * @notice Thrown when unbonding and the bonder has insufficient bonded tokens
   */
  error BondManager_Unbond_InsufficientBondedTokens();
}
