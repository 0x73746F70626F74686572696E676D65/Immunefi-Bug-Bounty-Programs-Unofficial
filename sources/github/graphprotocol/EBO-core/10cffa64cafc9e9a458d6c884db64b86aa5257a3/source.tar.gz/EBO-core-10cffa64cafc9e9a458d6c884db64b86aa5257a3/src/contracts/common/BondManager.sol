// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IBondManager} from 'interfaces/common/IBondManager.sol';

import {EBOStorage, IHorizonStaking} from 'contracts/common/EBOStorage.sol';

/**
 * @title BondManager abstract contract
 * @notice Contains the reusable logic for the bond functionality
 */
abstract contract BondManager is EBOStorage, IBondManager {
  /**
   * @notice Bonds the tokens of the bonder getting his provision from the HorizonStaking contract
   * @param _bonder The address of the bonder
   * @param _amount The amount of GRT tokens to bond
   */
  function _bond(address _bonder, uint256 _amount) internal {
    IHorizonStaking.Provision memory _provisionData = horizonStaking.getProvision(_bonder, address(this));

    if (_provisionData.maxVerifierCut != MAX_MAX_VERIFIER_CUT) revert BondManager_Bond_InvalidMaxVerifierCut();
    if (_provisionData.thawingPeriod < parametersSnapshots[parametersSnapshotId].minThawingPeriod) {
      revert BondManager_Bond_InvalidThawingPeriod();
    }

    uint256 _tokensNotThawing = _provisionData.tokens - _provisionData.tokensThawing;
    if (_amount > _tokensNotThawing) revert BondManager_Bond_InsufficientNonThawingTokens();

    bonds[_bonder] += _amount;

    if (bonds[_bonder] > _tokensNotThawing) {
      revert BondManager_Bond_BondedTokensExceedNonThawingTokens();
    }
  }

  /**
   * @notice Unbonds the tokens of the bonder
   * @param _bonder The address of the bonder
   * @param _amount The amount of GRT tokens to unbond
   */
  function _unbond(address _bonder, uint256 _amount) internal {
    if (_amount > bonds[_bonder]) revert BondManager_Unbond_InsufficientBondedTokens();

    bonds[_bonder] -= _amount;
  }
}
