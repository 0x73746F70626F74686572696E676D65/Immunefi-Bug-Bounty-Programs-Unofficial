// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IAccessManager} from 'interfaces/common/IAccessManager.sol';
import {IResolutionManager} from 'interfaces/common/IResolutionManager.sol';

/**
 * @title IEBOPledge
 * @notice Interface for the EBOPledge module
 */
interface IEBOPledge is IResolutionManager, IAccessManager {
  /*///////////////////////////////////////////////////////////////
                              EVENTS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Emitted when a pledge reward is claimed by a pledger
   * @param _proposalId The ID of the proposal
   * @param _pledger The address of the pledger
   * @param _rewardAmount The amount of GRT tokens claimed
   */
  event PledgeRewardClaimed(uint256 indexed _proposalId, address indexed _pledger, uint256 _rewardAmount);

  /**
   * @notice Emitted when a pledger bonds for a dispute
   * @param _proposalId The ID of the proposal
   * @param _pledger The address of the pledger
   * @param _pledgeAmount The amount of GRT tokens pledged
   */
  event PledgedForDispute(uint256 indexed _proposalId, address indexed _pledger, uint256 _pledgeAmount);

  /**
   * @notice Emitted when a pledger bonds against a dispute
   * @param _proposalId The ID of the proposal
   * @param _pledger The address of the pledger
   * @param _pledgeAmount The amount of GRT tokens pledged
   */
  event PledgedAgainstDispute(uint256 indexed _proposalId, address indexed _pledger, uint256 _pledgeAmount);

  /**
   * @notice Emitted when a dispute is escalated
   * @param _proposalId The ID of the proposal
   */
  event DisputeEscalated(uint256 indexed _proposalId);

  /*///////////////////////////////////////////////////////////////
                              ERRORS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Thrown when claiming the pledge reward and there is no reward to claim for the pledger
   */
  error EBOPledge_ClaimPledgeReward_NoRewardToClaim();

  /**
   * @notice Thrown when claiming the pledge reward and the reward is already claimed
   */
  error EBOPledge_ClaimPledgeReward_AlreadyClaimed();

  /**
   * @notice Thrown when claiming the pledge reward and the dispute has no resolution
   */
  error EBOPledge_ClaimPledgeReward_DisputeHasNoResolution();

  /**
   * @notice Thrown when pledging and the pledge window is over
   */
  error EBOPledge_Pledge_PledgeWindowOver();

  /**
   * @notice Thrown when pledging and the proposal is not disputed
   */
  error EBOPledge_Pledge_ProposalNotDisputed();

  /**
   * @notice Thrown when pledging and the pledging side has more pledges than the opposite side
   */
  error EBOPledge_Pledge_CannotPledgeIfWinning();

  /*///////////////////////////////////////////////////////////////
                              FUNCTIONS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Claims the pledge reward
   * @param _proposalId The ID of the proposal
   * @param _pledger The address of the pledger
   */
  function claimPledgeReward(uint256 _proposalId, address _pledger) external;

  /**
   * @notice Pledges in favor of a dispute
   * @param _proposalId The ID of the proposal
   * @param _serviceProvider The address of the service provider
   */
  function pledgeForDispute(uint256 _proposalId, address _serviceProvider) external;

  /**
   * @notice Pledges against a dispute
   * @param _proposalId The ID of the proposal
   * @param _serviceProvider The address of the service provider
   */
  function pledgeAgainstDispute(uint256 _proposalId, address _serviceProvider) external;
}
