// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IAccessManager} from 'interfaces/common/IAccessManager.sol';

import {EBOStorage} from 'contracts/common/EBOStorage.sol';

/**
 * @title AccessManager abstract contract
 * @notice Provides reusable logic for authorized access control
 */
abstract contract AccessManager is EBOStorage, IAccessManager {
  /**
   * @notice Checks that the caller is a valid operator
   * @param _serviceProvider The service provider address
   */
  modifier onlyOperator(address _serviceProvider) {
    if (
      _serviceProvider != msg.sender
        && !horizonStaking.isAuthorized({
          serviceProvider: _serviceProvider, verifier: address(this), operator: msg.sender
        })
    ) {
      revert AccessManager_OnlyOperator_NotOperator();
    }
    _;
  }

  /**
   * @notice Checks that the caller is the arbitrator
   */
  modifier onlyArbitrator() {
    if (msg.sender != arbitrator) revert AccessManager_OnlyArbitrator_NotArbitrator();
    _;
  }

  /**
   * @notice Checks that the caller is the council
   */
  modifier onlyCouncil() {
    if (msg.sender != council) revert AccessManager_OnlyCouncil_NotCouncil();
    _;
  }

  /**
   * @notice Checks that the caller is the pending council
   */
  modifier onlyPendingCouncil() {
    if (msg.sender != pendingCouncil) revert AccessManager_OnlyPendingCouncil_NotPendingCouncil();
    _;
  }
}
