// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

/**
 * @title IEpochManager
 * @notice Interface for the EpochManager contract
 */
interface IEpochManager {
  function currentEpoch() external view returns (uint256);
}
