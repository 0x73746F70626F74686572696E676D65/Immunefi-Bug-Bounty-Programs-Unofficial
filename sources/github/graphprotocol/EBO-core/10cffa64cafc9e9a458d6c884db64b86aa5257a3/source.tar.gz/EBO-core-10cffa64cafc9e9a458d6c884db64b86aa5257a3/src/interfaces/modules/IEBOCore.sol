// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IAccessManager} from 'interfaces/common/IAccessManager.sol';
import {IEBOStorage} from 'interfaces/common/IEBOStorage.sol';
import {IResolutionManager} from 'interfaces/common/IResolutionManager.sol';

/**
 * @title IEBOCore
 * @notice Interface for the EBOCore module
 */
interface IEBOCore is IResolutionManager, IAccessManager {
  /*///////////////////////////////////////////////////////////////
                              EVENTS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Emitted when a proposal is created
   * @param _proposalId The ID of the proposal
   * @param _epoch The epoch of the proposal
   * @param _chainId The chain ID of the proposal
   * @param _blockNumber The block number of the proposal
   * @param _serviceProvider The address of the service provider
   */
  event ProposalCreated(
    uint256 indexed _proposalId,
    uint256 indexed _epoch,
    string indexed _chainId,
    uint256 _blockNumber,
    address _serviceProvider
  );

  /**
   * @notice Emitted when a proposal is disputed
   * @param _proposalId The ID of the proposal
   */
  event ProposalDisputed(uint256 indexed _proposalId);

  /**
   * @notice Emitted when a proposal is finalized
   * @param _proposalId The ID of the proposal
   * @param _epoch The epoch of the proposal
   * @param _chainId The chain ID of the proposal
   * @param _blockNumber The block number of the proposal
   */
  event ProposalFinalized(
    uint256 indexed _proposalId, uint256 indexed _epoch, string indexed _chainId, uint256 _blockNumber
  );

  /**
   * @notice Emitted when a proposal is amended
   * @param _proposalId The ID of the proposal
   * @param _epoch The epoch of the proposal
   * @param _chainId The chain ID of the proposal
   * @param _blockNumber The block number of the proposal
   */
  event ProposalAmended(
    uint256 indexed _proposalId, uint256 indexed _epoch, string indexed _chainId, uint256 _blockNumber
  );

  /*///////////////////////////////////////////////////////////////
                              ERRORS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Thrown when proposing and the epoch is invalid
   */
  error EBOCore_Propose_InvalidEpoch();

  /**
   * @notice Thrown when proposing and the chain is not added
   */
  error EBOCore_Propose_ChainNotAdded();

  /**
   * @notice Thrown when proposing and the proposal is already active
   */
  error EBOCore_Propose_ProposalAlreadyActive();

  /**
   * @notice Thrown when disputing and the dispute window is over
   */
  error EBOCore_Dispute_DisputeWindowOver();

  /**
   * @notice Thrown when disputing and the proposal is not active
   */
  error EBOCore_Dispute_ProposalNotActive();

  /**
   * @notice Thrown when amending the epoch block and the proposal is not finalized
   */
  error EBOCore_AmendEpochBlock_ProposalNotFinalized();

  /**
   * @notice Thrown when finalizing and the dispute window is not over
   */
  error EBOCore_Finalize_DisputeWindowNotOver();

  /**
   * @notice Thrown when finalizing and the proposal is not active
   */
  error EBOCore_Finalize_ProposalNotActive();

  /**
   * @notice Thrown when resolving and the proposal is not disputed
   */
  error EBOCore_Resolve_ProposalNotDisputed();

  /**
   * @notice Thrown when resolving and the pledge window is not over
   */
  error EBOCore_Resolve_PledgeWindowNotOver();

  /**
   * @notice Thrown when resolving and the dispute is not escalated
   */
  error EBOCore_Resolve_DisputeNotEscalated();

  /**
   * @notice Thrown when resolving with an invalid status
   */
  error EBOCore_Resolve_InvalidStatus();

  /*///////////////////////////////////////////////////////////////
                              FUNCTIONS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Creates a new proposal
   * @param _epoch The epoch of the proposal
   * @param _chainId The chain ID of the proposal
   * @param _blockNumber The block number of the proposal
   * @param _serviceProvider The address of the service provider
   */
  function propose(uint256 _epoch, string calldata _chainId, uint256 _blockNumber, address _serviceProvider) external;

  /**
   * @notice Disputes a proposal
   * @param _proposalId The ID of the proposal
   * @param _serviceProvider The address of the service provider
   */
  function dispute(uint256 _proposalId, address _serviceProvider) external;

  /**
   * @notice Resolves a non-escalated dispute
   * @dev This function penalizes losing bonders
   * @param _proposalId The ID of the proposal
   */
  function resolve(uint256 _proposalId) external;

  /**
   * @notice Resolves an escalated dispute
   * @dev Only the arbitrator can resolve an escalated dispute
   * @dev This function penalizes losing bonders
   * @param _proposalId The ID of the proposal
   * @param _resolutionStatus The status of the resolution
   */
  function resolve(uint256 _proposalId, IEBOStorage.ProposalStatus _resolutionStatus) external;

  /**
   * @notice Finalizes a proposal
   * @param _proposalId The ID of the proposal
   */
  function finalize(uint256 _proposalId) external;

  /**
   * @notice Amends the epoch block of a proposal
   * @dev Only the arbitrator can force data availability in case there was a mistake in the system
   * @param _proposalId The ID of the proposal
   * @param _blockNumber The amending block number for the proposal
   */
  function amendEpochBlock(uint256 _proposalId, uint256 _blockNumber) external;
}
