// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IERC20} from '@openzeppelin/contracts/token/ERC20/IERC20.sol';

import {IEBOStorage} from 'interfaces/common/IEBOStorage.sol';
import {IEpochManager} from 'interfaces/external/IEpochManager.sol';
import {IHorizonStaking} from 'interfaces/external/IHorizonStaking.sol';
import {IEBOConfig} from 'interfaces/modules/IEBOConfig.sol';
import {IEBOCore} from 'interfaces/modules/IEBOCore.sol';
import {IEBOPledge} from 'interfaces/modules/IEBOPledge.sol';
import {ISemver} from 'interfaces/universal/ISemver.sol';

/**
 * @title IEBO
 * @notice Interface for the EBO contract
 */
interface IEBO is IEBOCore, IEBOPledge, IEBOConfig, ISemver {
  /*///////////////////////////////////////////////////////////////
                              STRUCTS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Contains the parameters for the initialization of the EBO contract
   * @param arbitrator The address of The Graph's Arbitrator
   * @param council The address of The Graph's Council
   * @param grt The address of the GRT token contract
   * @param horizonStaking The address of the HorizonStaking contract
   * @param epochManager The address of the EpochManager contract
   * @param startEpoch The start epoch
   * @param chainIds The chain IDs
   * @param parameters The parameters for proposals and disputes
   * @param arbitratorResolutionWindow The arbitrator resolution window
   */
  struct EBOInitializationParams {
    address arbitrator;
    address council;
    IERC20 grt;
    IHorizonStaking horizonStaking;
    IEpochManager epochManager;
    uint256 startEpoch;
    string[] chainIds;
    IEBOStorage.Parameters parameters;
    uint256 arbitratorResolutionWindow;
  }

  /*///////////////////////////////////////////////////////////////
                              FUNCTIONS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Initializes the contract
   * @dev Protected initializer function that can be invoked at most once
   * @param _initParams The initialization parameters
   */
  function initialize(EBOInitializationParams calldata _initParams) external;
}
