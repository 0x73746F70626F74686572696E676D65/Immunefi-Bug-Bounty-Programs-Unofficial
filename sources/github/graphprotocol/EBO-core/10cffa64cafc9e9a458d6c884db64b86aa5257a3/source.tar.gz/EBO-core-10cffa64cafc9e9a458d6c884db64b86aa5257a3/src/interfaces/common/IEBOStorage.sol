// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IERC20} from '@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol';

import {IEpochManager} from 'interfaces/external/IEpochManager.sol';
import {IHorizonStaking} from 'interfaces/external/IHorizonStaking.sol';

/**
 * @title IEBOStorage
 * @notice Interface for the EBOStorage abstract contract
 */
interface IEBOStorage {
  /*///////////////////////////////////////////////////////////////
                              ENUMS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice The status of the proposal
   * @param None No proposal
   * @param Active Proposal active
   * @param Disputed Proposal disputed
   * @param Escalated Dispute escalated
   * @param DisputerWon The disputer won the dispute (proposer and his pledgers are penalized)
   * @param DisputerLost The disputer lost the dispute (disputer and his pledgers are penalized)
   * @param NoResolution No dispute resolution (no bonder is penalized)
   * @param Finalized Proposal finalized (the epoch block is valid)
   */
  enum ProposalStatus {
    None,
    Active,
    Disputed,
    Escalated,
    DisputerWon,
    DisputerLost,
    NoResolution,
    Finalized
  }

  /*///////////////////////////////////////////////////////////////
                              STRUCTS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Contains the data of a proposal
   * @param epoch The epoch of the proposal
   * @param chainId The chain ID of the proposal
   * @param blockNumber The block number of the proposal
   * @param proposer The address of the proposer
   * @param createdAt The creation timestamp of the proposal
   * @param parametersSnapshotId The snapshot ID of the proposal and dispute parameters
   * @param status The status of the proposal
   */
  struct Proposal {
    uint256 epoch;
    string chainId;
    uint256 blockNumber;
    address proposer;
    uint256 createdAt;
    uint256 parametersSnapshotId;
    ProposalStatus status;
  }

  /**
   * @notice Contains the parameters for proposals and disputes
   * @param proposalBondSize The bond size per proposal or dispute
   * @param pledgeBondSize The bond size per pledge
   * @param minThawingPeriod The minimum thawing period
   * @param disputeWindow The dispute window
   * @param pledgeWindow The pledge window
   * @param pledgeRefreshWindow The pledge refresh window
   * @param maxNumberOfPledges The maximum number of pledges for each side of disputes
   */
  struct Parameters {
    uint256 proposalBondSize;
    uint256 pledgeBondSize;
    uint256 minThawingPeriod;
    uint256 disputeWindow;
    uint256 pledgeWindow;
    uint256 pledgeRefreshWindow;
    uint256 maxNumberOfPledges;
  }

  /**
   * @notice Contains the data of a dispute
   * @param disputer The address of the disputer
   * @param createdAt The creation timestamp of the dispute
   * @param lastPledgeTimestamp  The timestamp of the last pledge
   * @param totalPledgesForDispute The total number of pledges in favor of the dispute
   * @param totalPledgesAgainstDispute The total number of pledges against the dispute
   * @param rewardPerWinningPledge The amount of GRT tokens rewarded per winning pledge
   */
  struct Dispute {
    address disputer;
    uint256 createdAt;
    uint256 lastPledgeTimestamp;
    uint256 totalPledgesForDispute;
    uint256 totalPledgesAgainstDispute;
    uint256 rewardPerWinningPledge;
  }

  /*///////////////////////////////////////////////////////////////
                              VARIABLES
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Returns the maximum value that can be set as the maxVerifierCut in a provision of HorizonStaking
   * @dev It is equivalent to 100% in parts-per-million
   * @return _maxMaxVerifierCut The maximum value that can be set as the maxVerifierCut in a provision of HorizonStaking
   */
  function MAX_MAX_VERIFIER_CUT() external view returns (uint32 _maxMaxVerifierCut);

  /**
   * @notice Returns the address of the GRT token contract
   * @return _grt The address of the GRT token contract
   */
  function grt() external view returns (IERC20 _grt);

  /**
   * @notice Returns the address of the HorizonStaking contract
   * @return _horizonStaking The address of the HorizonStaking contract
   */
  function horizonStaking() external view returns (IHorizonStaking _horizonStaking);

  /**
   * @notice Returns the address of the EpochManager contract
   * @return _epochManager The address of the EpochManager contract
   */
  function epochManager() external view returns (IEpochManager _epochManager);

  /**
   * @notice Returns the address of the council
   * @return _council The address of the council
   */
  function council() external view returns (address _council);

  /**
   * @notice Returns the address of the pending council
   * @return _pendingCouncil The address of the pending council
   */
  function pendingCouncil() external view returns (address _pendingCouncil);

  /**
   * @notice Returns the address of the arbitrator
   * @return _arbitrator The address of the arbitrator
   */
  function arbitrator() external view returns (address _arbitrator);

  /**
   * @notice Returns the ID of the last proposal
   * @return _proposalId The ID of the last proposal
   */
  function proposalId() external view returns (uint256 _proposalId);

  /**
   * @notice Returns the snapshot ID of the current parameters snapshot
   * @return _parametersSnapshotId The snapshot ID of the current parameters snapshot
   */
  function parametersSnapshotId() external view returns (uint256 _parametersSnapshotId);

  /**
   * @notice Returns the start epoch
   * @return _startEpoch The start epoch
   */
  function startEpoch() external view returns (uint256 _startEpoch);

  /**
   * @notice Returns the active proposal for the given epoch and chain ID
   * @param _epoch The epoch
   * @param _chainId The chain ID
   * @return _proposalId The ID of the active proposal
   */
  function activeProposal(uint256 _epoch, string calldata _chainId) external view returns (uint256 _proposalId);

  /**
   * @notice Returns the total amount bonded by a bonder
   * @param _bonder The address of the bonder
   * @return _bondSize The total amount bonded
   */
  function bonds(address _bonder) external view returns (uint256 _bondSize);

  /**
   * @notice Returns the data of the proposal
   * @param _proposalId The ID of the proposal
   * @return _epoch The epoch of the proposal
   * @return _chainId The chain ID of the proposal
   * @return _blockNumber The block number of the proposal
   * @return _proposer The address of the proposer
   * @return _createdAt The creation timestamp of the proposal
   * @return _parametersSnapshotId The snapshot ID of the proposal and dispute parameters
   * @return _status The status of the proposal
   */
  function proposals(uint256 _proposalId)
    external
    view
    returns (
      uint256 _epoch,
      string memory _chainId,
      uint256 _blockNumber,
      address _proposer,
      uint256 _createdAt,
      uint256 _parametersSnapshotId,
      ProposalStatus _status
    );

  /**
   * @notice Returns the parameters of proposals and disputes for the given parameters snapshot ID
   * @param _parametersSnapshotId The parameters snapshot ID
   * @return _proposalBondSize The bond size per proposal or dispute
   * @return _pledgeBondSize The bond size per pledge
   * @return _minThawingPeriod The minimum thawing period
   * @return _disputeWindow The dispute window
   * @return _pledgeWindow The pledge window
   * @return _pledgeRefreshWindow The pledge refresh window
   * @return _maxNumberOfPledges The maximum number of pledges for each side of disputes
   */
  function parametersSnapshots(uint256 _parametersSnapshotId)
    external
    view
    returns (
      uint256 _proposalBondSize,
      uint256 _pledgeBondSize,
      uint256 _minThawingPeriod,
      uint256 _disputeWindow,
      uint256 _pledgeWindow,
      uint256 _pledgeRefreshWindow,
      uint256 _maxNumberOfPledges
    );

  /**
   * @notice Returns the number of pledges a pledger has made in favor of a given dispute
   * @param _proposalId The ID of the proposal
   * @param _pledger The address of the pledger
   * @return _pledgesForDispute The number of pledges made by the pledger in favor of the dispute
   */
  function pledgesForDispute(uint256 _proposalId, address _pledger) external view returns (uint256 _pledgesForDispute);

  /**
   * @notice Returns the number of pledges a pledger has made against a given dispute
   * @param _proposalId The ID of the proposal
   * @param _pledger The address of the pledger
   * @return _pledgesAgainstDispute The number of pledges made by the pledger against the dispute
   */
  function pledgesAgainstDispute(
    uint256 _proposalId,
    address _pledger
  ) external view returns (uint256 _pledgesAgainstDispute);

  /**
   * @notice Returns the data of the dispute
   * @param _proposalId The ID of the proposal
   * @return _disputer The address of the disputer
   * @return _createdAt The creation timestamp of the dispute
   * @return _lastPledgeTimestamp The timestamp of the last pledge
   * @return _totalPledgesForDispute The total number of pledges in favor of the dispute
   * @return _totalPledgesAgainstDispute The total number of pledges against the dispute
   * @return _rewardPerWinningPledge The amount of GRT tokens rewarded per winning pledge
   */
  function disputes(uint256 _proposalId)
    external
    view
    returns (
      address _disputer,
      uint256 _createdAt,
      uint256 _lastPledgeTimestamp,
      uint256 _totalPledgesForDispute,
      uint256 _totalPledgesAgainstDispute,
      uint256 _rewardPerWinningPledge
    );

  /**
   * @notice Returns true if the pledger has claimed the pledge reward
   * @param _proposalId The ID of the proposal
   * @param _pledger The address of the pledger
   * @return _claimed True if the pledger has claimed
   */
  function pledgerClaimed(uint256 _proposalId, address _pledger) external view returns (bool _claimed);

  /**
   * @notice Returns true if the chain is allowed
   * @param _chainId The chain ID
   * @return _allowed True if the chain is allowed
   */
  function chainIdsAllowed(string calldata _chainId) external view returns (bool _allowed);

  /**
   * @notice Returns the pledgers in favor of a given dispute
   * @param _proposalId The ID of the proposal
   * @return _pledgersForDispute The addresses of the pledgers in favor of the dispute
   */
  function pledgersForDispute(uint256 _proposalId) external view returns (address[] memory _pledgersForDispute);

  /**
   * @notice Returns the pledgers against a given dispute
   * @param _proposalId The ID of the proposal
   * @return _pledgersAgainstDispute The addresses of the pledgers against the dispute
   */
  function pledgersAgainstDispute(uint256 _proposalId) external view returns (address[] memory _pledgersAgainstDispute);
}
