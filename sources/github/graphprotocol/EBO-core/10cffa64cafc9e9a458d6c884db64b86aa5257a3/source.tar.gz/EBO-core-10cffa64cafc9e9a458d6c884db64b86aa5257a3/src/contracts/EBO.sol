// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {UUPSUpgradeable} from '@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol';

import {IEBO} from 'interfaces/IEBO.sol';
import {ISemver} from 'interfaces/universal/ISemver.sol';

import {EBOConfig} from 'contracts/modules/EBOConfig.sol';
import {EBOCore} from 'contracts/modules/EBOCore.sol';
import {EBOPledge} from 'contracts/modules/EBOPledge.sol';

/**
 * @title EBO contract
 * @notice Contains all the EBO logic
 */
contract EBO is EBOCore, EBOPledge, EBOConfig, UUPSUpgradeable, IEBO {
  /**
   * @notice Constructor
   * @dev Prevents this contract from being initialized or reinitialized to any version, locking the implementation
   */
  constructor() {
    _disableInitializers();
  }

  /// @inheritdoc IEBO
  function initialize(EBOInitializationParams calldata _initParams) external initializer {
    _setArbitrator(_initParams.arbitrator);
    _setCouncil(_initParams.council);
    _setGRT(_initParams.grt);
    _setHorizonStaking(_initParams.horizonStaking);
    _setEpochManager(_initParams.epochManager);
    _setStartEpoch(_initParams.startEpoch);
    _addChainIds(_initParams.chainIds);
    _setParameters(_initParams.parameters, _initParams.arbitratorResolutionWindow);
  }

  /**
   * @inheritdoc ISemver
   * @custom:semver 1.0.0
   */
  function version() external pure returns (string memory) {
    return '1.0.0';
  }

  /// @inheritdoc UUPSUpgradeable
  function _authorizeUpgrade(address) internal override onlyCouncil {}
}
