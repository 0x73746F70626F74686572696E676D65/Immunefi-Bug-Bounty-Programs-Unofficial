// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IERC20} from '@openzeppelin/contracts/token/ERC20/IERC20.sol';

import {IAccessManager} from 'interfaces/common/IAccessManager.sol';
import {IEBOStorage} from 'interfaces/common/IEBOStorage.sol';
import {IEpochManager} from 'interfaces/external/IEpochManager.sol';
import {IHorizonStaking} from 'interfaces/external/IHorizonStaking.sol';

/**
 * @title IEBOConfig
 * @notice Interface for the EBOConfig module
 */
interface IEBOConfig is IAccessManager {
  /*///////////////////////////////////////////////////////////////
                              EVENTS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Emitted when the arbitrator is set
   * @param _arbitrator The address of the arbitrator
   */
  event ArbitratorSet(address indexed _arbitrator);

  /**
   * @notice Emitted when the pending council is set
   * @param _pendingCouncil The address of the pending council
   */
  event PendingCouncilSet(address indexed _pendingCouncil);

  /**
   * @notice Emitted when the council is set
   * @param _council The address of the council
   */
  event CouncilSet(address indexed _council);

  /**
   * @notice Emitted when the GRT token contract is set
   * @param _grt The address of the GRT token contract
   */
  event GRTSet(IERC20 indexed _grt);

  /**
   * @notice Emitted when the HorizonStaking contract is set
   * @param _horizonStaking The address of the HorizonStaking contract
   */
  event HorizonStakingSet(IHorizonStaking indexed _horizonStaking);

  /**
   * @notice Emitted when the EpochManager contract is set
   * @param _epochManager The address of the EpochManager contract
   */
  event EpochManagerSet(IEpochManager indexed _epochManager);

  /**
   * @notice Emitted when the start epoch is set
   * @dev To be set only once during initialization
   * @param _startEpoch The start epoch
   */
  event StartEpochSet(uint256 _startEpoch);

  /**
   * @notice Emitted when a chain ID is added
   * @param _chainId The chain ID
   */
  event ChainIdAdded(string indexed _chainId);

  /**
   * @notice Emitted when a chain ID is removed
   * @param _chainId The chain ID
   */
  event ChainIdRemoved(string indexed _chainId);

  /**
   * @notice Emitted when the parameters for proposals and disputes are set
   * @param _parameters The parameters for proposals and disputes
   * @param _parametersSnapshotId The snapshot ID of the parameters
   * @param _arbitratorResolutionWindow The arbitrator resolution window
   */
  event ParametersSet(
    IEBOStorage.Parameters _parameters, uint256 indexed _parametersSnapshotId, uint256 _arbitratorResolutionWindow
  );

  /*///////////////////////////////////////////////////////////////
                              ERRORS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Thrown when setting the arbitrator with an address that is already set
   */
  error EBOConfig_SetArbitrator_AddressAlreadySet();

  /**
   * @notice Thrown when setting the pending council with an address that is already set
   */
  error EBOConfig_SetPendingCouncil_AddressAlreadySet();

  /**
   * @notice Thrown when setting the council with an address that is already set
   */
  error EBOConfig_SetCouncil_AddressAlreadySet();

  /**
   * @notice Thrown when setting the GRT token contract with an address that is already set
   */
  error EBOConfig_SetGRT_AddressAlreadySet();

  /**
   * @notice Thrown when setting the HorizonStaking contract with an address that is already set
   */
  error EBOConfig_SetHorizonStaking_AddressAlreadySet();

  /**
   * @notice Thrown when setting the EpochManager contract with an address that is already set
   */
  error EBOConfig_SetEpochManager_AddressAlreadySet();

  /**
   * @notice Thrown when adding a chain ID that is already added
   */
  error EBOConfig_AddChainIds_ChainIdAlreadyAdded();

  /**
   * @notice Thrown when removing a chain ID that is not added
   */
  error EBOConfig_RemoveChainIds_ChainIdNotAdded();

  /**
   * @notice Thrown when checking parameters and a parameter is zero
   */
  error EBOConfig_CheckParameters_ParametersCannotBeZero();

  /**
   * @notice Thrown when checking parameters and the pledge refresh window exceeds the pledge window
   */
  error EBOConfig_CheckParameters_PledgeRefreshWindowExceedsPledgeWindow();

  /**
   * @notice Thrown when checking parameters and the minimum thawing period is too short
   */
  error EBOConfig_CheckParameters_MinThawingPeriodTooShort();

  /*///////////////////////////////////////////////////////////////
                              FUNCTIONS
  //////////////////////////////////////////////////////////////*/

  /**
   * @notice Sets the arbitrator
   * @param _arbitrator The address of the arbitrator
   */
  function setArbitrator(address _arbitrator) external;

  /**
   * @notice Sets the pending council
   * @param _pendingCouncil The address of the pending council
   */
  function setPendingCouncil(address _pendingCouncil) external;

  /**
   * @notice Confirms the council
   */
  function confirmCouncil() external;

  /**
   * @notice Sets the GRT token contract
   * @param _grt The address of the GRT token contract
   */
  function setGRT(IERC20 _grt) external;

  /**
   * @notice Sets the HorizonStaking contract
   * @param _horizonStaking The address of the HorizonStaking contract
   */
  function setHorizonStaking(IHorizonStaking _horizonStaking) external;

  /**
   * @notice Sets the EpochManager contract
   * @param _epochManager The address of the EpochManager contract
   */
  function setEpochManager(IEpochManager _epochManager) external;

  /**
   * @notice Add an array of chain IDs
   * @param _chainIds The chain IDs
   */
  function addChainIds(string[] calldata _chainIds) external;

  /**
   * @notice Removes an array of chain IDs
   * @param _chainIds The chain IDs
   */
  function removeChainIds(string[] calldata _chainIds) external;

  /**
   * @notice Sets the parameters for proposals and disputes
   * @param _parameters The parameters for proposals and disputes
   * @param _arbitratorResolutionWindow The arbitrator resolution window
   */
  function setParameters(IEBOStorage.Parameters calldata _parameters, uint256 _arbitratorResolutionWindow) external;
}
