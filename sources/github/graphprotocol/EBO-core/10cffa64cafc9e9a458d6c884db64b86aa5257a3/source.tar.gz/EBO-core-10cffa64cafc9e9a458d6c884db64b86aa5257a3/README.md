# Epoch Block Oracle (EBO)

> [!CAUTION]  
> The code has not been audited yet—tread with caution.

> [!CAUTION] 
> Once the minimum thawing period has passed, the losing party of a dispute may be able to withdraw its stake from the `HorizonStaking` contract.
> In consequence, disputes should be resolved before that period ends to ensure that funds are slashable.

## Overview

EBO is a mechanism for clock synchronization in a multichain environment. It enables The Graph to permissionlessly synchronize clocks between Arbitrum (where the protocol contracts are deployed), and multiple other supported chains, allowing rewards to be paid to indexers.

## Available commands

| Yarn command                   | Description                               |
| ------------------------------ | ----------------------------------------- |
| `yarn build`                   | Compile all contracts.                    |
| `yarn coverage`                | See `forge coverage` report.              |
| `yarn deploy:arbitrum`         | Deploy the contracts to Arbitrum Mainnet. |
| `yarn deploy:arbitrum-sepolia` | Deploy the contracts to Arbitrum Sepolia. |
| `yarn test`                    | Run all unit and integration tests.       |
| `yarn test:unit`               | Run unit tests.                           |
| `yarn test:unit:deep`          | Run unit tests with 5000 fuzz runs.       |
| `yarn test:integration`        | Run integration tests.                    |

## Setup

To clone this repository locally, run:

```sh
git clone git@github.com:defi-wonderland/EBO.git
```

This project uses [Foundry](https://book.getfoundry.sh/).

1. Install Foundry by following the instructions from [their repository](https://github.com/foundry-rs/foundry#installation).
2. Copy the `.env.example` file to `.env` and fill in the variables.
3. Install the dependencies by running: `yarn install`. In case there is an error with the commands, run `foundryup` and try them again.

## Build

The default way to build the code is suboptimal but fast, you can run it via:

```bash
yarn build
```

In order to build a more optimized code ([via IR](https://docs.soliditylang.org/en/v0.8.15/ir-breaking-changes.html#solidity-ir-based-codegen-changes)), run:

```bash
yarn build:optimized
```

## Running tests

Unit tests are built based on the [Branched-Tree Technique](https://x.com/PaulRBerg/status/1682346315806539776) using [Bulloak](https://github.com/alexfertel/bulloak), while formal verification and property-based fuzzing are achieved with [Halmos](https://github.com/a16z/halmos) and [Medusa](https://github.com/crytic/medusa), respectively.

Make sure to set `ARBITRUM_SEPOLIA_RPC` environment variable before running integration tests.

In order to run both unit and integration tests, run:

```bash
yarn test
```

In order to just run unit tests, run:

```bash
yarn test:unit
```

In order to run unit tests and run way more fuzzing than usual (5x), run:

```bash
yarn test:unit:deep
```

In order to just run integration tests, run:

```bash
yarn test:integration
```

To run only the Medusa fuzzing campaign (which requires having [Medusa](https://github.com/crytic/medusa/blob/master/docs/src/getting_started/installation.md) installed), run:

```bash
yarn test:fuzz
```

In order to just run the symbolic execution tests (which requires having [Halmos](https://github.com/a16z/halmos/blob/main/README.md#installation) installed), run:

```bash
yarn test:symbolic
```

In order to check your current code coverage, run:

```bash
yarn coverage
```

## Deploy & verify

### Setup

Configure the `.env` variables.

Import your private keys into Foundry's encrypted keystore:

```bash
cast wallet import $ARBITRUM_DEPLOYER_NAME --interactive
```

```bash
cast wallet import $ARBITRUM_SEPOLIA_DEPLOYER_NAME --interactive
```

### Arbitrum Mainnet

```bash
yarn deploy:arbitrum
```

### Arbitrum Sepolia

```bash
yarn deploy:arbitrum-sepolia
```

The deployments are stored in `./broadcast`.

See the [Foundry Book for available options](https://book.getfoundry.sh/reference/forge/forge-create.html).

## Deployments

*The addresses of the contracts deployed on Arbitrum will be listed here.*

## Licensing

The primary license for EBO contracts is MIT, see [`LICENSE`](./LICENSE).

## Contributors

EBO was built with ❤️ by [Wonderland](https://defi.sucks).

Wonderland is a team of top Web3 researchers, developers, and operators who believe that the future needs to be open-source, permissionless, and decentralized.

[DeFi sucks](https://defi.sucks), but Wonderland is here to make it better.
