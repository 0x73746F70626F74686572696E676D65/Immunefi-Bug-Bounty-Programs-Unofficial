// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IResolutionManager, ResolutionManager} from 'contracts/common/ResolutionManager.sol';
import {IEBOStorage} from 'interfaces/common/IEBOStorage.sol';
import {IHorizonStaking} from 'interfaces/external/IHorizonStaking.sol';

import {EBOStorageHelper} from 'test/utils/EBOStorageHelper.t.sol';
import {EBOTestHelpers} from 'test/utils/EBOTestHelpers.t.sol';

/**
 * @title ResolutionManager unit tests
 */
contract ResolutionManagerUnit is EBOTestHelpers {
  // Contracts
  ResolutionManagerForTest public resolutionManager;

  function setUp() public override {
    pledgerFor = makeAddr('pledgerFor');
    pledgerAgainst = makeAddr('pledgerAgainst');
    proposer = makeAddr('proposer');
    disputer = makeAddr('disputer');

    resolutionManager = new ResolutionManagerForTest();

    // Set up the contract storage
    resolutionManager.setHorizonStakingForTest(IHorizonStaking(horizonStaking));
  }

  function test_Resolve_WhenTheThawingPeriodHasPassed(
    uint256 _proposalId,
    uint256 _pledgesForDispute,
    uint256 _pledgesAgainstDispute,
    uint256 _pledgeBondSize,
    uint256 _proposalBondSize,
    uint256 _proposalCreatedAt,
    uint256 _minThawingPeriod
  ) external {
    _pledgeBondSize = bound(_pledgeBondSize, 1, type(uint128).max);
    _proposalBondSize = bound(_proposalBondSize, 1, type(uint128).max);
    _pledgesForDispute = bound(_pledgesForDispute, 1, 2);
    _pledgesAgainstDispute = bound(_pledgesAgainstDispute, 1, 2);
    _proposalCreatedAt = bound(_proposalCreatedAt, 1, type(uint32).max);
    _minThawingPeriod = bound(_minThawingPeriod, 1, type(uint32).max);

    IEBOStorage.Parameters memory _parameters = IEBOStorage.Parameters({
      proposalBondSize: _proposalBondSize,
      pledgeBondSize: _pledgeBondSize,
      minThawingPeriod: _minThawingPeriod,
      disputeWindow: 0,
      pledgeWindow: 0,
      pledgeRefreshWindow: 0,
      maxNumberOfPledges: 0
    });

    resolutionManager.setParametersForTest({_snapshotId: 0, _parameters: _parameters});

    // Set the proposal, dispute, and pledges
    resolutionManager.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: _proposalCreatedAt,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Disputed
      })
    });

    resolutionManager.setPledgesForDisputeForTest(_proposalId, pledgerFor, _pledgesForDispute);
    resolutionManager.setPledgesAgainstDisputeForTest(_proposalId, pledgerAgainst, _pledgesAgainstDispute);
    resolutionManager.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: _proposalCreatedAt, _lastPledgeTimestamp: 0
    });

    // It should emit the DisputeResolved event
    vm.expectEmit();
    emit IResolutionManager.DisputeResolved(_proposalId, IEBOStorage.ProposalStatus.NoResolution);

    // When the thawing period has passed
    vm.warp(_proposalCreatedAt + _minThawingPeriod + 1);

    resolutionManager.resolve(
      _proposalId,
      _proposalCreatedAt,
      _parameters.minThawingPeriod,
      _parameters.proposalBondSize,
      _parameters.pledgeBondSize,
      proposer,
      disputer,
      _pledgesForDispute,
      _pledgesAgainstDispute,
      IEBOStorage.ProposalStatus.DisputerWon
    );

    // It should unbond the disputer, proposer and pledgers
    _checkAsserts({
      _proposalId: _proposalId,
      _expectedStatus: IEBOStorage.ProposalStatus.NoResolution,
      _expectedRewardPerWinningPledge: 0
    });
  }

  function test_Resolve_WhenTheResolutionStatusIsNoResolution(
    uint256 _proposalId,
    uint256 _pledgesForDispute,
    uint256 _pledgesAgainstDispute,
    uint256 _pledgeBondSize,
    uint256 _proposalBondSize
  ) external {
    _pledgeBondSize = bound(_pledgeBondSize, 1, type(uint128).max);
    _proposalBondSize = bound(_proposalBondSize, 1, type(uint128).max);
    _pledgesForDispute = bound(_pledgesForDispute, 1, 2);
    _pledgesAgainstDispute = bound(_pledgesAgainstDispute, 1, 2);

    IEBOStorage.Parameters memory _parameters = IEBOStorage.Parameters({
      proposalBondSize: _proposalBondSize,
      pledgeBondSize: _pledgeBondSize,
      minThawingPeriod: 0,
      disputeWindow: 0,
      pledgeWindow: 0,
      pledgeRefreshWindow: 0,
      maxNumberOfPledges: 0
    });

    resolutionManager.setParametersForTest({_snapshotId: 0, _parameters: _parameters});

    // Set the proposal, dispute, and pledges
    resolutionManager.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: 0,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.NoResolution
      })
    });

    resolutionManager.setPledgesForDisputeForTest(_proposalId, pledgerFor, _pledgesForDispute);
    resolutionManager.setPledgesAgainstDisputeForTest(_proposalId, pledgerAgainst, _pledgesAgainstDispute);
    resolutionManager.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: 0, _lastPledgeTimestamp: 0
    });

    // It should emit the DisputeResolved event
    vm.expectEmit();
    emit IResolutionManager.DisputeResolved(_proposalId, IEBOStorage.ProposalStatus.NoResolution);

    // When the resolution status is NoResolution
    resolutionManager.resolve(
      _proposalId,
      block.timestamp,
      _parameters.minThawingPeriod,
      _parameters.proposalBondSize,
      _parameters.pledgeBondSize,
      proposer,
      disputer,
      _pledgesForDispute,
      _pledgesAgainstDispute,
      IEBOStorage.ProposalStatus.NoResolution
    );

    // It should unbond the disputer, proposer and pledgers
    _checkAsserts({
      _proposalId: _proposalId,
      _expectedStatus: IEBOStorage.ProposalStatus.NoResolution,
      _expectedRewardPerWinningPledge: 0
    });
  }

  function test_Resolve_WhenTheResolutionStatusIsDisputerWon(
    uint256 _proposalId,
    uint256 _pledgeBondSize,
    uint256 _proposalBondSize,
    address _pledgerFor,
    address _pledgerAgainst
  ) external {
    _pledgeBondSize = bound(_pledgeBondSize, 1, type(uint128).max);
    _proposalBondSize = bound(_proposalBondSize, 1, type(uint128).max);
    vm.assume(_pledgerFor != _pledgerAgainst);

    uint256 _pledgesForDispute = 2;
    uint256 _pledgesAgainstDispute = 1;
    uint256 _rewardPerWinningPledge = _pledgeBondSize * _pledgesAgainstDispute / _pledgesForDispute;

    IEBOStorage.Parameters memory _parameters = IEBOStorage.Parameters({
      proposalBondSize: _proposalBondSize,
      pledgeBondSize: _pledgeBondSize,
      minThawingPeriod: 0,
      disputeWindow: 0,
      pledgeWindow: 0,
      pledgeRefreshWindow: 0,
      maxNumberOfPledges: 0
    });

    resolutionManager.setParametersForTest({_snapshotId: 0, _parameters: _parameters});

    // Set the proposal, dispute, and pledges
    resolutionManager.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: 0,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Disputed
      })
    });
    resolutionManager.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: 0, _lastPledgeTimestamp: 0
    });
    resolutionManager.setPledgesAgainstDisputeForTest(_proposalId, pledgerAgainst, _pledgesAgainstDispute);
    resolutionManager.setPledgesForDisputeForTest(_proposalId, pledgerFor, _pledgesForDispute);

    // It should slash the pledgers `against` the dispute
    _mockAndExpect(
      address(horizonStaking),
      abi.encodeWithSelector(
        IHorizonStaking.slash.selector, pledgerAgainst, _pledgeBondSize, _pledgeBondSize, address(resolutionManager)
      ),
      abi.encode(true)
    );

    // It should pay the disputer and slash the proposer
    _mockAndExpect(
      address(horizonStaking),
      abi.encodeWithSelector(IHorizonStaking.slash.selector, proposer, _proposalBondSize, _proposalBondSize, disputer),
      abi.encode(true)
    );

    // It should emit the DisputeResolved event
    vm.expectEmit();
    emit IResolutionManager.DisputeResolved(_proposalId, IEBOStorage.ProposalStatus.DisputerWon);

    // When the resolution status is DisputerWon
    resolutionManager.resolve(
      _proposalId,
      block.timestamp,
      _parameters.minThawingPeriod,
      _parameters.proposalBondSize,
      _parameters.pledgeBondSize,
      proposer,
      disputer,
      _pledgesForDispute,
      _pledgesAgainstDispute,
      IEBOStorage.ProposalStatus.DisputerWon
    );

    // It should unbond the disputer, proposer and pledgers
    _checkAsserts(_proposalId, IEBOStorage.ProposalStatus.DisputerWon, _rewardPerWinningPledge);
  }

  function test_Resolve_WhenTheResolutionStatusIsDisputerLost(
    uint256 _proposalId,
    uint256 _pledgeBondSize,
    uint256 _proposalBondSize,
    address _pledgerFor,
    address _pledgerAgainst
  ) external {
    _pledgeBondSize = bound(_pledgeBondSize, 1, type(uint128).max);
    _proposalBondSize = bound(_proposalBondSize, 1, type(uint128).max);
    vm.assume(_pledgerFor != _pledgerAgainst);

    uint256 _pledgesForDispute = 1;
    uint256 _pledgesAgainstDispute = 2;
    uint256 _rewardPerWinningPledge = _pledgeBondSize * _pledgesForDispute / _pledgesAgainstDispute;

    IEBOStorage.Parameters memory _parameters = IEBOStorage.Parameters({
      proposalBondSize: _proposalBondSize,
      pledgeBondSize: _pledgeBondSize,
      minThawingPeriod: 0,
      disputeWindow: 0,
      pledgeWindow: 0,
      pledgeRefreshWindow: 0,
      maxNumberOfPledges: 0
    });
    resolutionManager.setParametersForTest({_snapshotId: 0, _parameters: _parameters});

    // Set the proposal, dispute, and pledges
    resolutionManager.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: 0,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Disputed
      })
    });
    resolutionManager.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: 0, _lastPledgeTimestamp: 0
    });
    resolutionManager.setPledgesAgainstDisputeForTest(_proposalId, pledgerAgainst, _pledgesAgainstDispute);
    resolutionManager.setPledgesForDisputeForTest(_proposalId, pledgerFor, _pledgesForDispute);

    // It should slash the pledgers `for` the dispute
    _mockAndExpect(
      address(horizonStaking),
      abi.encodeWithSelector(
        IHorizonStaking.slash.selector, pledgerFor, _pledgeBondSize, _pledgeBondSize, address(resolutionManager)
      ),
      abi.encode(true)
    );

    // It should pay the proposer and slash the disputer
    _mockAndExpect(
      address(horizonStaking),
      abi.encodeWithSelector(IHorizonStaking.slash.selector, disputer, _proposalBondSize, _proposalBondSize, proposer),
      abi.encode(true)
    );

    // It should emit the DisputeResolved event
    vm.expectEmit();
    emit IResolutionManager.DisputeResolved(_proposalId, IEBOStorage.ProposalStatus.DisputerLost);

    // When the resolution status is DisputerLost
    resolutionManager.resolve(
      _proposalId,
      block.timestamp,
      _parameters.minThawingPeriod,
      _parameters.proposalBondSize,
      _parameters.pledgeBondSize,
      proposer,
      disputer,
      _pledgesForDispute,
      _pledgesAgainstDispute,
      IEBOStorage.ProposalStatus.DisputerLost
    );

    // It should unbond the disputer, proposer and pledgers
    _checkAsserts(_proposalId, IEBOStorage.ProposalStatus.DisputerLost, _rewardPerWinningPledge);
  }

  function test_DisputeWindowHasPassed_WhenThePeriodHasElapsed(
    uint256 _proposalCreatedAt,
    uint256 _disputeWindow
  ) external {
    _proposalCreatedAt = bound(_proposalCreatedAt, 1, type(uint32).max);
    _disputeWindow = bound(_disputeWindow, 1, type(uint32).max);

    // When the period has elapsed
    vm.warp(block.timestamp + _disputeWindow + _proposalCreatedAt + 1);

    // It should return true
    assertEq(resolutionManager.disputeWindowHasPassed(_proposalCreatedAt, _disputeWindow), true);
  }

  function test_DisputeWindowHasPassed_WhenThePeriodHasNotElapsed(
    uint256 _proposalCreatedAt,
    uint256 _disputeWindow
  ) external view {
    // When the period has not elapsed
    _proposalCreatedAt = bound(_proposalCreatedAt, 1, type(uint32).max);
    _disputeWindow = bound(_disputeWindow, 1, type(uint32).max);

    // It should return false
    assertEq(resolutionManager.disputeWindowHasPassed(_proposalCreatedAt, _disputeWindow), false);
  }

  function test_PledgeWindowHasPassed_WhenThePeriodHasElapsed() external {
    IEBOStorage.Parameters memory _parameters;
    IEBOStorage.Dispute memory _dispute;

    // When the period has elapsed
    vm.warp(block.timestamp + 1);

    // It should return true
    assertEq(
      resolutionManager.pledgeWindowHasPassed({
        _disputeCreatedAt: _dispute.createdAt,
        _lastPledgeTimestamp: _dispute.lastPledgeTimestamp,
        _pledgeWindow: _parameters.pledgeWindow,
        _pledgeRefreshWindow: _parameters.pledgeRefreshWindow
      }),
      true
    );
  }

  function test_PledgeWindowHasPassed_WhenThePeriodHasNotElapsed(uint256 _disputeCreatedAt) external view {
    // When the period has not elapsed
    _disputeCreatedAt = bound(_disputeCreatedAt, block.timestamp + 1, type(uint32).max);

    IEBOStorage.Parameters memory _parameters;

    IEBOStorage.Dispute memory _dispute = IEBOStorage.Dispute({
      disputer: address(0),
      createdAt: _disputeCreatedAt,
      lastPledgeTimestamp: 0,
      totalPledgesForDispute: 0,
      totalPledgesAgainstDispute: 0,
      rewardPerWinningPledge: 0
    });

    // It should return false
    assertEq(
      resolutionManager.pledgeWindowHasPassed({
        _disputeCreatedAt: _dispute.createdAt,
        _lastPledgeTimestamp: _dispute.lastPledgeTimestamp,
        _pledgeWindow: _parameters.pledgeWindow,
        _pledgeRefreshWindow: _parameters.pledgeRefreshWindow
      }),
      false
    );
  }

  /**
   * @notice Helper function to check the asserts
   * @param _proposalId The proposal ID
   * @param _expectedStatus The expected status
   * @param _expectedRewardPerWinningPledge The expected reward per winning pledge
   */
  function _checkAsserts(
    uint256 _proposalId,
    IEBOStorage.ProposalStatus _expectedStatus,
    uint256 _expectedRewardPerWinningPledge
  ) internal view {
    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = resolutionManager.proposals(_proposalId);
    (,,,,, uint256 _rewardPerWinningPledge) = resolutionManager.disputes(_proposalId);

    assertEq(uint8(_proposalStatus), uint8(_expectedStatus));

    // After the dispute is resolved, the disputer and proposer should have 0 bonds
    assertEq(resolutionManager.bonds(disputer), 0);
    assertEq(resolutionManager.bonds(proposer), 0);

    // After the dispute is resolved, the pledgers should have 0 bonds
    address[] memory _pledgersForDispute = resolutionManager.pledgersForDispute(_proposalId);
    address[] memory _pledgersAgainstDispute = resolutionManager.pledgersAgainstDispute(_proposalId);

    for (uint256 _i = 0; _i < _pledgersForDispute.length; _i++) {
      assertEq(resolutionManager.bonds(_pledgersForDispute[_i]), 0);
    }

    for (uint256 _i = 0; _i < _pledgersAgainstDispute.length; _i++) {
      assertEq(resolutionManager.bonds(_pledgersAgainstDispute[_i]), 0);
    }

    assertEq(_rewardPerWinningPledge, _expectedRewardPerWinningPledge);
  }
}

contract ResolutionManagerForTest is ResolutionManager, EBOStorageHelper {
  function resolve(
    uint256 _proposalId,
    uint256 _proposalCreatedAt,
    uint256 _minThawingPeriod,
    uint256 _proposalBondSize,
    uint256 _pledgeBondSize,
    address _proposer,
    address _disputer,
    uint256 _totalPledgesForDispute,
    uint256 _totalPledgesAgainstDispute,
    IEBOStorage.ProposalStatus _resolutionStatus
  ) external {
    _resolve(
      ResolveParams({
        proposalCreatedAt: _proposalCreatedAt,
        minThawingPeriod: _minThawingPeriod,
        proposalBondSize: _proposalBondSize,
        pledgeBondSize: _pledgeBondSize,
        proposer: _proposer,
        disputer: _disputer,
        totalPledgesForDispute: _totalPledgesForDispute,
        totalPledgesAgainstDispute: _totalPledgesAgainstDispute,
        resolutionStatus: _resolutionStatus,
        proposalId: _proposalId
      })
    );
  }

  function disputeWindowHasPassed(
    uint256 _proposalCreatedAt,
    uint256 _disputeWindow
  ) external view returns (bool _passed) {
    return _disputeWindowHasPassed(_proposalCreatedAt, _disputeWindow);
  }

  function pledgeWindowHasPassed(
    uint256 _disputeCreatedAt,
    uint256 _lastPledgeTimestamp,
    uint256 _pledgeWindow,
    uint256 _pledgeRefreshWindow
  ) external view returns (bool _passed) {
    return _pledgeWindowHasPassed(_disputeCreatedAt, _lastPledgeTimestamp, _pledgeWindow, _pledgeRefreshWindow);
  }
}
