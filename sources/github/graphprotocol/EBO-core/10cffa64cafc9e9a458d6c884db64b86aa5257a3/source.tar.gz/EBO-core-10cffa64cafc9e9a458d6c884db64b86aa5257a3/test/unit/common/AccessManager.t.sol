// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {AccessManager, IAccessManager} from 'contracts/common/AccessManager.sol';
import {IHorizonStaking} from 'interfaces/external/IHorizonStaking.sol';

import {EBOStorageHelper} from 'test/utils/EBOStorageHelper.t.sol';
import {EBOTestHelpers} from 'test/utils/EBOTestHelpers.t.sol';

/**
 * @title AccessManager unit tests
 */
contract AccessManagerUnit is EBOTestHelpers {
  // Contracts
  AccessManagerForTest public accessManager;

  function setUp() public override {
    accessManager = new AccessManagerForTest();

    // Set up the contract storage
    accessManager.setAllStorageForTest(IHorizonStaking(horizonStaking), arbitrator, council, pendingCouncil);
  }

  function test_OnlyOperator_RevertWhen_IsNotAuthorized(address _serviceProvider, address _badCaller) external {
    // When is not authorized
    vm.assume(_serviceProvider != _badCaller);

    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(
        IHorizonStaking.isAuthorized.selector, _serviceProvider, address(accessManager), _badCaller
      ),
      abi.encode(false)
    );

    vm.prank(_badCaller);
    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyOperator_NotOperator.selector);
    accessManager.onlyOperatorForTest(_serviceProvider);
  }

  function test_OnlyOperator_WhenServiceProviderIsAuthorized(address _serviceProvider) external {
    // When service provider is authorized
    vm.prank(_serviceProvider);
    // It should not revert
    assertEq(accessManager.onlyOperatorForTest(_serviceProvider), true);
  }

  function test_OnlyOperator_WhenServiceProviderIsSender(address _serviceProvider, address _operator) external {
    // When service provider is sender
    vm.assume(_serviceProvider != _operator);

    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(
        IHorizonStaking.isAuthorized.selector, _serviceProvider, address(accessManager), _operator
      ),
      abi.encode(true)
    );

    vm.prank(_operator);
    // It should not revert
    assertEq(accessManager.onlyOperatorForTest(_serviceProvider), true);
  }

  function test_OnlyArbitrator_RevertWhen_TheCallerIsNotArbitrator(address _badCaller) external {
    // When the caller is not arbitrator
    vm.assume(arbitrator != _badCaller);

    vm.prank(_badCaller);
    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyArbitrator_NotArbitrator.selector);
    accessManager.onlyArbitratorForTest();
  }

  function test_OnlyArbitrator_WhenTheCallerIsArbitrator() external {
    // When the caller is arbitrator
    vm.prank(arbitrator);
    // It should not revert
    assertEq(accessManager.onlyArbitratorForTest(), true);
  }

  function test_OnlyCouncil_RevertWhen_TheCallerIsNotCouncil(address _badCaller) external {
    // When the caller is not council
    vm.assume(council != _badCaller);

    vm.prank(_badCaller);
    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);
    accessManager.onlyCouncilForTest();
  }

  function test_OnlyCouncil_WhenTheCallerIsCouncil() external {
    // When the caller is council
    vm.prank(council);
    // It should not revert
    assertEq(accessManager.onlyCouncilForTest(), true);
  }

  function test_OnlyPendingCouncil_RevertWhen_TheCallerIsNotPendingCouncil(address _badCaller) external {
    // When the caller is not pending council
    vm.assume(pendingCouncil != _badCaller);

    vm.prank(_badCaller);
    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyPendingCouncil_NotPendingCouncil.selector);
    accessManager.onlyPendingCouncilForTest();
  }

  function test_OnlyPendingCouncil_WhenTheCallerIsPendingCouncil() external {
    // When the caller is pending council
    vm.prank(pendingCouncil);
    // It should not revert
    assertEq(accessManager.onlyPendingCouncilForTest(), true);
  }
}

contract AccessManagerForTest is AccessManager, EBOStorageHelper {
  function onlyOperatorForTest(address _serviceProvider)
    external
    view
    onlyOperator(_serviceProvider)
    returns (bool _valid)
  {
    _valid = true;
  }

  function onlyArbitratorForTest() external view onlyArbitrator returns (bool _valid) {
    _valid = true;
  }

  function onlyCouncilForTest() external view onlyCouncil returns (bool _valid) {
    _valid = true;
  }

  function onlyPendingCouncilForTest() external view onlyPendingCouncil returns (bool _valid) {
    _valid = true;
  }
}
