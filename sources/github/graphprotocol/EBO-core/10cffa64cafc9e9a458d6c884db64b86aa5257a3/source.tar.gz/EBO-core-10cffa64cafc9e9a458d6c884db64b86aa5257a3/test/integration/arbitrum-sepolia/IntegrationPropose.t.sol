// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {ARBITRUM_SEPOLIA_START_EPOCH, ETHEREUM_CHAIN_ID} from 'script/Constants.sol';
import {IntegrationBase} from 'test/integration/arbitrum-sepolia/IntegrationBase.t.sol';

import {IAccessManager} from 'src/interfaces/common/IAccessManager.sol';
import {IBondManager} from 'src/interfaces/common/IBondManager.sol';

import {IEBOStorage} from 'src/interfaces/common/IEBOStorage.sol';
import {IEBOCore} from 'src/interfaces/modules/IEBOCore.sol';

contract IntegrationPropose is IntegrationBase {
  function test_Propose_Revert_NotOperator() public {
    vm.expectRevert(IAccessManager.AccessManager_OnlyOperator_NotOperator.selector);

    eboProxy.propose({
      _epoch: ARBITRUM_SEPOLIA_START_EPOCH, _chainId: ETHEREUM_CHAIN_ID, _blockNumber: 0, _serviceProvider: _proposerA
    });
  }

  function test_Propose_Revert_InvalidEpoch() public {
    uint256 _invalidEpoch = ARBITRUM_SEPOLIA_START_EPOCH - 1;

    vm.expectRevert(IEBOCore.EBOCore_Propose_InvalidEpoch.selector);

    // Propose for an epoch before the start epoch
    _propose(ETHEREUM_CHAIN_ID, _invalidEpoch, _proposerA);
  }

  function test_Propose_Revert_ChainNotAdded() public {
    vm.expectRevert(IEBOCore.EBOCore_Propose_ChainNotAdded.selector);

    // Propose for a chain that is not added
    _propose(_NONEXISTENT_CHAIN_ID, ARBITRUM_SEPOLIA_START_EPOCH, _proposerA);
  }

  function test_Propose_Revert_ProposalAlreadyActive() public {
    // Create an active proposal
    _propose(ETHEREUM_CHAIN_ID);

    vm.expectRevert(IEBOCore.EBOCore_Propose_ProposalAlreadyActive.selector);

    // Propose for the same epoch twice
    _propose(ETHEREUM_CHAIN_ID, _lastProposalEpoch, _proposerA);
  }

  function test_Propose_Revert_InvalidMaxVerifierCut() public {
    // Stake GRT for proposal
    _stakeGRT(_invalidBonder, initParams.parameters.proposalBondSize);

    // Provision with an invalid max verifier cut
    _provision(
      _invalidBonder,
      initParams.parameters.proposalBondSize,
      eboProxy.MAX_MAX_VERIFIER_CUT() - 1,
      uint64(initParams.parameters.minThawingPeriod)
    );

    vm.expectRevert(IBondManager.BondManager_Bond_InvalidMaxVerifierCut.selector);

    // Propose with an invalid max verifier cut
    _propose(ETHEREUM_CHAIN_ID, ARBITRUM_SEPOLIA_START_EPOCH, _invalidBonder);
  }

  function test_Propose_Revert_InvalidThawingPeriod() public {
    // Stake GRT for proposal
    _stakeGRT(_invalidBonder, initParams.parameters.proposalBondSize);

    // Provision with an invalid thawing period
    _provision(
      _invalidBonder,
      initParams.parameters.proposalBondSize,
      eboProxy.MAX_MAX_VERIFIER_CUT(),
      uint64(initParams.parameters.minThawingPeriod - 1)
    );

    vm.expectRevert(IBondManager.BondManager_Bond_InvalidThawingPeriod.selector);

    // Propose with an invalid thawing period
    _propose(ETHEREUM_CHAIN_ID, ARBITRUM_SEPOLIA_START_EPOCH, _invalidBonder);
  }

  function test_Propose_Revert_InsufficientNonThawingTokens_ProvisionTokensNotEnough() public {
    // Stake GRT for proposal
    _stakeGRT(_invalidBonder, initParams.parameters.proposalBondSize);

    // Provision with an insufficient amount of non-thawing tokens
    _provision(
      _invalidBonder,
      initParams.parameters.proposalBondSize - 1,
      eboProxy.MAX_MAX_VERIFIER_CUT(),
      uint64(initParams.parameters.minThawingPeriod)
    );

    vm.expectRevert(IBondManager.BondManager_Bond_InsufficientNonThawingTokens.selector);

    // Propose with an insufficient amount of non-thawing tokens
    _propose(ETHEREUM_CHAIN_ID, ARBITRUM_SEPOLIA_START_EPOCH, _invalidBonder);
  }

  function test_Propose_Revert_InsufficientNonThawingTokens_ProvisionTokensMinusTokensThawingNotEnough() public {
    // Stake GRT for proposal
    _stakeGRT(_invalidBonder, initParams.parameters.proposalBondSize);

    // Provision with a sufficient amount of tokens
    _provision(
      _invalidBonder,
      initParams.parameters.proposalBondSize,
      eboProxy.MAX_MAX_VERIFIER_CUT(),
      uint64(initParams.parameters.minThawingPeriod)
    );

    // Thaw one unit enough to make the provision insufficient
    _thawGRT(_invalidBonder, 1);

    vm.expectRevert(IBondManager.BondManager_Bond_InsufficientNonThawingTokens.selector);

    // Propose with an insufficient amount of non-thawing tokens
    _propose(ETHEREUM_CHAIN_ID, ARBITRUM_SEPOLIA_START_EPOCH, _invalidBonder);
  }

  function test_Propose_Revert_BondedTokensExceedNonThawingTokens() public {
    // Create the first proposal, allocating 100% of the proposer's provision.
    _propose(ETHEREUM_CHAIN_ID);

    vm.expectRevert(IBondManager.BondManager_Bond_BondedTokensExceedNonThawingTokens.selector);

    // Propose when bonded tokens would exceed the amount of non-thawing tokens
    _propose(ETHEREUM_CHAIN_ID, ARBITRUM_SEPOLIA_START_EPOCH + 1, _proposerA);
  }

  function test_Propose() public {
    // Propose
    _propose(ETHEREUM_CHAIN_ID);

    (
      uint256 _queriedEpoch,
      string memory _queriedChainId,
      uint256 _queriedBlockNumber,
      address _queriedProposer,
      uint256 _queriedProposalCreatedAt,
      uint256 _queriedParametersSnapshotId,
      IEBOStorage.ProposalStatus _queriedProposalStatus
    ) = eboProxy.proposals(_lastProposalId);

    // Check the proposal ID
    assertEq(eboProxy.proposalId(), _lastProposalId);

    // Check the proposal data
    assertEq(_queriedEpoch, _lastProposalEpoch);
    assertEq(_queriedChainId, ETHEREUM_CHAIN_ID);
    assertEq(_queriedBlockNumber, _lastProposalBlockNumber);
    assertEq(_queriedProposer, _proposerA);
    assertEq(_queriedProposalCreatedAt, _lastProposalCreatedAt);
    assertEq(_queriedParametersSnapshotId, 1);
    assertEq(uint8(_queriedProposalStatus), uint8(IEBOStorage.ProposalStatus.Active));

    // Check if the proposal is active
    assertEq(eboProxy.activeProposal(_lastProposalEpoch, ETHEREUM_CHAIN_ID), _lastProposalId);

    // Check the bond of the proposer
    assertEq(eboProxy.bonds(_proposerA), initParams.parameters.proposalBondSize);
  }
}
