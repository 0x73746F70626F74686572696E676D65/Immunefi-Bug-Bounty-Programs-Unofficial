// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IEpochManager} from '../../../../src/interfaces/external/IEpochManager.sol';

contract MockEpochManager is IEpochManager {
  uint256 public mockEpoch;

  function currentEpoch() external view returns (uint256) {
    return mockEpoch == 0 ? uint256(block.timestamp) : mockEpoch;
  }

  function handler_setCurrentEpoch(uint256 _epoch) external {
    mockEpoch = _epoch;
  }
}
