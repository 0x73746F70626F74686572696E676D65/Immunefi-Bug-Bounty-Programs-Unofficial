// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {Test} from 'forge-std/Test.sol';

/**
 * @title TestHelpers
 * @notice Contains helper functions for tests
 */
contract TestHelpers is Test {
  /**
   * @notice Returns the ceiling of the division of two numbers
   * @param _a The dividend
   * @param _b The divisor
   * @return _result The ceiling of the division
   */
  function _ceilDiv(uint256 _a, uint256 _b) internal pure returns (uint256 _result) {
    _result = (_a + _b - 1) / _b;
  }

  /**
   * @notice Ensures that a fuzzed address can be used for deployment and calls
   * @param _address The address to check
   */
  function _assumeFuzzable(address _address) internal pure {
    assumeNotForgeAddress(_address);
    assumeNotZeroAddress(_address);
    assumeNotPrecompile(_address);
  }

  /**
   * @notice Sets up a mock and expects a call to it
   * @param _receiver The address to have a mock on
   * @param _calldata The calldata to mock and expect
   * @param _returned The data to return from the mocked call
   */
  function _mockAndExpect(address _receiver, bytes memory _calldata, bytes memory _returned) internal {
    vm.mockCall(_receiver, _calldata, _returned);
    vm.expectCall(_receiver, _calldata);
  }

  /**
   * @notice Creates a mock contract, labels it and etches some bytecode
   * @param _name The label to use for the mock contract
   * @return _contract The address of the mock contract
   */
  function _mockContract(string memory _name) internal returns (address _contract) {
    _contract = makeAddr(_name);
    vm.etch(_contract, hex'69');
  }

  /**
   * @notice Sets an expectation for an event to be emitted
   * @param _contract The contract to expect the event on
   */
  function _expectEmit(address _contract) internal {
    vm.expectEmit(true, true, true, true, _contract);
  }

  /**
   * @notice Returns an address excluding address(0)
   * @param _addr The address to bound
   * @return _boundedAddress The address excluding address(0)
   */
  function _excludingAddressZero(address _addr) internal returns (address _boundedAddress) {
    _boundedAddress = _boundAddressBetween(_addr, address(1), address(type(uint160).max));
  }

  /**
   * @notice Clamps an address between a start and end range
   * @param _addr The address to clamp
   * @param _startRange The start of the range
   * @param _endRange The end of the range
   * @return _boundedAddress The clamped address
   */
  function _boundAddressBetween(
    address _addr,
    address _startRange,
    address _endRange
  ) internal returns (address _boundedAddress) {
    _boundedAddress = address(uint160(bound(uint160(_addr), uint160(_startRange), uint160(_endRange))));

    vm.label(_boundedAddress, 'random address');
  }

  /**
   * @notice Generates a random address that is not equal to a specific address (e.g. contract)
   * @param _addr The address to bound
   * @param _specificAddress The specific address to bound against
   * @return _boundedAddress The bounded address not equal to the specific address
   */
  function _boundNotEq(address _addr, address _specificAddress) internal returns (address _boundedAddress) {
    _boundedAddress = _excludingAddressZero(_addr);

    while (_boundedAddress == _specificAddress) {
      uint160 _seed = uint160(bytes20(keccak256(abi.encodePacked(_boundedAddress, _specificAddress))));
      _boundedAddress = _excludingAddressZero(address(_seed));
    }

    vm.label(_boundedAddress, 'random address');
  }

  /**
   * @notice Checks if an address is contained in an array of addresses
   * @param _address The address to check
   * @param _addresses The array of addresses to check
   * @return _contained Whether the address is contained in the array
   */
  function _containsAddress(address _address, address[] memory _addresses) internal pure returns (bool _contained) {
    for (uint256 _i; _i < _addresses.length; _i++) {
      if (_addresses[_i] == _address) {
        return true;
      }
    }

    return false;
  }
}
