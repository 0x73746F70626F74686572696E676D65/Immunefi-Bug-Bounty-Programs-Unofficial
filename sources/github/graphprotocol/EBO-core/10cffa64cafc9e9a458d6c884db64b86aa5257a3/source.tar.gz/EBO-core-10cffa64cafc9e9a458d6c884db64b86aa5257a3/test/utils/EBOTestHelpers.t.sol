// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {TestHelpers} from 'test/utils/TestHelpers.t.sol';

/**
 * @title EBOTestHelpers
 * @notice Contains EBO specific helper functions and variables for tests
 */
contract EBOTestHelpers is TestHelpers {
  /// Accounts
  address public arbitrator;
  address public council;
  address public pendingCouncil;
  address public grt;
  address public horizonStaking;
  address public epochManager;
  address public caller;
  address public proposer;
  address public disputer;
  address public pledgerFor;
  address public pledgerAgainst;
  address public notProtocolActor;

  /**
   * @notice Sets up the contract state
   */
  function setUp() public virtual {
    arbitrator = makeAddr('arbitrator');
    council = makeAddr('council');
    pendingCouncil = makeAddr('pendingCouncil');
    grt = makeAddr('grt');
    horizonStaking = makeAddr('horizonStaking');
    epochManager = makeAddr('epochManager');

    caller = makeAddr('caller');
    proposer = makeAddr('proposer');
    disputer = makeAddr('disputer');
    pledgerFor = makeAddr('pledgerFor');
    pledgerAgainst = makeAddr('pledgerAgainst');
    notProtocolActor = makeAddr('notProtocolActor');
  }

  /**
   * @notice Returns the maximum proposal lifecycle duration
   * @param _disputeWindow The dispute window
   * @param _pledgeWindow The pledge window
   * @param _pledgeRefreshWindow The pledge refresh window
   * @param _maxNumberOfPledges The maximum number of pledges
   * @param _arbitratorResolutionWindow The arbitrator resolution window
   * @return _maxProposalLifecycleDuration The maximum proposal lifecycle duration
   */
  function _getMaxProposalLifecycleDuration(
    uint256 _disputeWindow,
    uint256 _pledgeWindow,
    uint256 _pledgeRefreshWindow,
    uint256 _maxNumberOfPledges,
    uint256 _arbitratorResolutionWindow
  ) internal pure returns (uint256 _maxProposalLifecycleDuration) {
    uint256 _maxCumulativePledgeRefreshWindow =
      _maxNumberOfPledges * _pledgeRefreshWindow;
    _maxProposalLifecycleDuration =
      _disputeWindow + _pledgeWindow + _maxCumulativePledgeRefreshWindow + _arbitratorResolutionWindow;
  }
}
