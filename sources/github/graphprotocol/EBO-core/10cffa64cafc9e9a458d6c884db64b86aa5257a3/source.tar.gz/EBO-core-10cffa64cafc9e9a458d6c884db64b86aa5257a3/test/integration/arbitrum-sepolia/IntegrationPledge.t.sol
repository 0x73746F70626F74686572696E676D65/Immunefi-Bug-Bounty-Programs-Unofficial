// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {ETHEREUM_CHAIN_ID} from 'script/Constants.sol';
import {IntegrationBase} from 'test/integration/arbitrum-sepolia/IntegrationBase.t.sol';

import {IAccessManager} from 'src/interfaces/common/IAccessManager.sol';
import {IBondManager} from 'src/interfaces/common/IBondManager.sol';

import {IEBOStorage} from 'src/interfaces/common/IEBOStorage.sol';
import {IEBOPledge} from 'src/interfaces/modules/IEBOPledge.sol';

contract IntegrationPledge is IntegrationBase {
  uint256 internal _pledgeMaxTimeBeforeExpiration;

  function setUp() public override {
    super.setUp();

    // Create a proposal
    _propose(ETHEREUM_CHAIN_ID);

    _pledgeMaxTimeBeforeExpiration = initParams.parameters.pledgeWindow - 1;
    uint256 _disputeMaxTimeBeforeExpiration = initParams.parameters.disputeWindow - 1;

    // Advance close to the dispute window expiration to maximize lifecycle time in future tests
    vm.warp(_lastProposalCreatedAt + _disputeMaxTimeBeforeExpiration);

    // Dispute the proposal
    _dispute(_lastProposalId);
  }

  function test_Pledge_Revert_NotOperator() public {
    // Pledge for dispute case
    vm.expectRevert(IAccessManager.AccessManager_OnlyOperator_NotOperator.selector);
    eboProxy.pledgeForDispute({_proposalId: _lastProposalId, _serviceProvider: _pledgerA});

    // Pledge against dispute case
    vm.expectRevert(IAccessManager.AccessManager_OnlyOperator_NotOperator.selector);
    eboProxy.pledgeAgainstDispute({_proposalId: _lastProposalId, _serviceProvider: _pledgerA});
  }

  function test_Pledge_Revert_ProposalNotDisputed() public {
    // Create a new proposal
    _propose(ETHEREUM_CHAIN_ID, _lastProposalEpoch, _proposerB);

    vm.expectRevert(IEBOPledge.EBOPledge_Pledge_ProposalNotDisputed.selector);

    // Pledge for a dispute when the proposal is not disputed
    _pledgeForDispute(_lastProposalId, _pledgerA);

    vm.expectRevert(IEBOPledge.EBOPledge_Pledge_ProposalNotDisputed.selector);

    // Pledge against a dispute when the proposal is not disputed
    _pledgeAgainstDispute(_lastProposalId, _pledgerA);
  }

  function test_Pledge_Revert_PledgeWindowOver_PledgeWindowOver() public {
    // Elapse the pledge window
    vm.warp(_lastDisputeCreatedAt + initParams.parameters.pledgeWindow);

    vm.expectRevert(IEBOPledge.EBOPledge_Pledge_PledgeWindowOver.selector);

    // Pledge for the dispute when the pledge window has passed
    _pledgeForDispute(_lastProposalId, _pledgerA);

    vm.expectRevert(IEBOPledge.EBOPledge_Pledge_PledgeWindowOver.selector);

    // Pledge against the dispute when the pledge window has passed
    _pledgeAgainstDispute(_lastProposalId, _pledgerA);
  }

  function test_PledgeAgainstDispute_Revert_PledgeWindowOver_PledgeRefreshWindowOver() public {
    // Advance close to the pledge window expiration
    vm.warp(_lastDisputeCreatedAt + _pledgeMaxTimeBeforeExpiration);

    // Pledge for the dispute
    _pledgeForDispute(_lastProposalId, _pledgerA);

    // Elapse the pledge refresh window
    vm.warp(_lastPledgeTimestamp + initParams.parameters.pledgeRefreshWindow);

    vm.expectRevert(IEBOPledge.EBOPledge_Pledge_PledgeWindowOver.selector);

    // Pledge against the dispute when the pledge refresh window has passed
    _pledgeAgainstDispute(_lastProposalId, _pledgerA);
  }

  function test_PledgeForDispute_Revert_PledgeWindowOver_PledgeRefreshWindowOver() public {
    // Advance close to the pledge window expiration
    vm.warp(_lastDisputeCreatedAt + _pledgeMaxTimeBeforeExpiration);

    // Pledge against the dispute
    _pledgeAgainstDispute(_lastProposalId, _pledgerA);

    // Elapse the pledge refresh window
    vm.warp(_lastPledgeTimestamp + initParams.parameters.pledgeRefreshWindow);

    vm.expectRevert(IEBOPledge.EBOPledge_Pledge_PledgeWindowOver.selector);

    // Pledge for the dispute when the pledge refresh window has passed
    _pledgeForDispute(_lastProposalId, _pledgerA);
  }

  function test_Pledge_Revert_CannotPledgeIfWinning() public {
    // Pledge for the dispute
    _pledgeForDispute(_lastProposalId, _pledgerA);

    vm.expectRevert(IEBOPledge.EBOPledge_Pledge_CannotPledgeIfWinning.selector);

    // Pledge for the dispute when it's winning side of the dispute
    _pledgeForDispute(_lastProposalId, _pledgerA);

    // Pledge against the dispute and make it the dispute winning side
    _pledgeAgainstDispute(_lastProposalId, _pledgerB);

    vm.expectRevert(IEBOPledge.EBOPledge_Pledge_CannotPledgeIfWinning.selector);

    // Pledge against the dispute when it's winning side of the dispute
    _pledgeAgainstDispute(_lastProposalId, _pledgerA);
  }

  function test_Pledge_Revert_InvalidMaxVerifierCut() public {
    // Stake GRT for proposal
    _stakeGRT(_invalidBonder, initParams.parameters.proposalBondSize);

    // Provision with an invalid max verifier cut
    _provision(
      _invalidBonder,
      initParams.parameters.pledgeBondSize,
      eboProxy.MAX_MAX_VERIFIER_CUT() - 1,
      uint64(initParams.parameters.minThawingPeriod)
    );

    vm.expectRevert(IBondManager.BondManager_Bond_InvalidMaxVerifierCut.selector);

    // Pledge for the dispute with an invalid max verifier cut
    _pledgeForDispute(_lastProposalId, _invalidBonder);

    vm.expectRevert(IBondManager.BondManager_Bond_InvalidMaxVerifierCut.selector);

    // Pledge against the dispute with an invalid max verifier cut
    _pledgeAgainstDispute(_lastProposalId, _invalidBonder);
  }

  function test_Pledge_Revert_InvalidThawingPeriod() public {
    // Stake GRT for proposal
    _stakeGRT(_invalidBonder, initParams.parameters.proposalBondSize);

    // Provision with an invalid thawing period
    _provision(
      _invalidBonder,
      initParams.parameters.pledgeBondSize,
      eboProxy.MAX_MAX_VERIFIER_CUT(),
      uint64(initParams.parameters.minThawingPeriod - 1)
    );

    vm.expectRevert(IBondManager.BondManager_Bond_InvalidThawingPeriod.selector);

    // Pledge for the dispute with an invalid thawing period
    _pledgeForDispute(_lastProposalId, _invalidBonder);

    vm.expectRevert(IBondManager.BondManager_Bond_InvalidThawingPeriod.selector);

    // Pledge against the dispute with an invalid thawing period
    _pledgeAgainstDispute(_lastProposalId, _invalidBonder);
  }

  function test_Pledge_Revert_InsufficientNonThawingTokens_ProvisionTokensNotEnough() public {
    // Stake GRT for proposal
    _stakeGRT(_invalidBonder, initParams.parameters.proposalBondSize);

    // Provision with an insufficient amount of non-thawing tokens
    _provision(
      _invalidBonder,
      initParams.parameters.pledgeBondSize - 1,
      eboProxy.MAX_MAX_VERIFIER_CUT(),
      uint64(initParams.parameters.minThawingPeriod)
    );

    vm.expectRevert(IBondManager.BondManager_Bond_InsufficientNonThawingTokens.selector);

    // Pledge for the dispute with an insufficient amount of non-thawing tokens
    _pledgeForDispute(_lastProposalId, _invalidBonder);

    vm.expectRevert(IBondManager.BondManager_Bond_InsufficientNonThawingTokens.selector);

    // Pledge against the dispute with an insufficient amount of non-thawing tokens
    _pledgeAgainstDispute(_lastProposalId, _invalidBonder);
  }

  function test_Pledge_Revert_InsufficientNonThawingTokens_ProvisionTokensMinusTokensThawingNotEnough() public {
    // Stake GRT for proposal
    _stakeGRT(_invalidBonder, initParams.parameters.proposalBondSize);

    // Provision with a sufficient amount of tokens
    _provision(
      _invalidBonder,
      initParams.parameters.pledgeBondSize,
      eboProxy.MAX_MAX_VERIFIER_CUT(),
      uint64(initParams.parameters.minThawingPeriod)
    );

    // Thaw one unit enough to make the provision insufficient
    _thawGRT(_invalidBonder, 1);

    vm.expectRevert(IBondManager.BondManager_Bond_InsufficientNonThawingTokens.selector);

    // Pledge for the dispute with an insufficient amount of non-thawing tokens
    _pledgeForDispute(_lastProposalId, _invalidBonder);

    vm.expectRevert(IBondManager.BondManager_Bond_InsufficientNonThawingTokens.selector);

    // Pledge against the dispute with an insufficient amount of non-thawing tokens
    _pledgeAgainstDispute(_lastProposalId, _invalidBonder);
  }

  function test_Pledge_Revert_BondedTokensExceedNonThawingTokens() public {
    uint256 _provisionAmount = initParams.parameters.pledgeBondSize * 2;
    // Stake GRT for proposal
    _stakeGRT(_invalidBonder, _provisionAmount);

    // Provision with a sufficient amount of tokens for two pledges
    _provision(
      _invalidBonder, _provisionAmount, eboProxy.MAX_MAX_VERIFIER_CUT(), uint64(initParams.parameters.minThawingPeriod)
    );

    // Pledge for the dispute and allocate the 50% of the bonder's provision
    _pledgeForDispute(_lastProposalId, _invalidBonder);

    vm.expectRevert(IBondManager.BondManager_Bond_BondedTokensExceedNonThawingTokens.selector);

    // Pledge against the dispute when bonded tokens would exceed the amount of non-thawing tokens, because it requires 2 pledges bonds
    _pledgeAgainstDispute(_lastProposalId, _invalidBonder);

    // Another pledger pledges against the dispute
    _pledgeAgainstDispute(_lastProposalId, _pledgerA);

    vm.expectRevert(IBondManager.BondManager_Bond_BondedTokensExceedNonThawingTokens.selector);

    // Pledge for the dispute when bonded tokens would exceed the amount of non-thawing tokens, because it requires 2 pledges bonds
    _pledgeForDispute(_lastProposalId, _invalidBonder);
  }

  function test_Pledge_ForDispute() public {
    // Pledge for the dispute
    _pledgeForDispute(_lastProposalId, _pledgerA);

    (
      ,,
      uint256 _queriedLastPledgeTimestamp,
      uint256 _queriedTotalPledgesForDispute,
      uint256 _queriedTotalPledgesAgainstDispute,
    ) = eboProxy.disputes(_lastProposalId);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboProxy.proposals(_lastProposalId);

    address[] memory _pledgersForDispute = eboProxy.pledgersForDispute(_lastProposalId);
    address[] memory _pledgersAgainstDispute = eboProxy.pledgersAgainstDispute(_lastProposalId);

    // Check the pledger's bond
    assertEq(eboProxy.bonds(_pledgerA), initParams.parameters.pledgeBondSize);

    // Check the last pledge timestamp
    assertEq(_queriedLastPledgeTimestamp, block.timestamp);

    // Check the total pledges for the dispute
    assertEq(_queriedTotalPledgesForDispute, 1);

    // Check the total pledges against the dispute
    assertEq(_queriedTotalPledgesAgainstDispute, 0);

    // Check that the pledger was added to the list of pledgers for the dispute
    assertTrue(_containsAddress(_pledgerA, _pledgersForDispute));

    // Check that the pledger was not added to the list of pledgers against the dispute
    assertFalse(_containsAddress(_pledgerA, _pledgersAgainstDispute));

    // Check the pledger pledges number
    assertEq(eboProxy.pledgesForDispute(_lastProposalId, _pledgerA), 1);
    assertEq(eboProxy.pledgesAgainstDispute(_lastProposalId, _pledgerA), 0);

    // Check the proposal status
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.Disputed));
  }

  function test_Pledge_AgainstDispute() public {
    // Pledge for the dispute
    _pledgeAgainstDispute(_lastProposalId, _pledgerA);

    address[] memory _pledgersAgainstDispute = eboProxy.pledgersAgainstDispute(_lastProposalId);
    address[] memory _pledgersForDispute = eboProxy.pledgersForDispute(_lastProposalId);

    (
      ,,
      uint256 _queriedLastPledgeTimestamp,
      uint256 _queriedTotalPledgesForDispute,
      uint256 _queriedTotalPledgesAgainstDispute,
    ) = eboProxy.disputes(_lastProposalId);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboProxy.proposals(_lastProposalId);

    // Check the pledger's bond
    assertEq(eboProxy.bonds(_pledgerA), initParams.parameters.pledgeBondSize);

    // Check the last pledge timestamp
    assertEq(_queriedLastPledgeTimestamp, block.timestamp);

    // Check the total pledges for the dispute
    assertEq(_queriedTotalPledgesForDispute, 0);

    // Check the total pledges against the dispute
    assertEq(_queriedTotalPledgesAgainstDispute, 1);

    // Check that the pledger was added to the list of pledgers against the dispute
    assertTrue(_containsAddress(_pledgerA, _pledgersAgainstDispute));

    // Check that the pledger was not added to the list of pledgers for the dispute
    assertFalse(_containsAddress(_pledgerA, _pledgersForDispute));

    // Check the pledger pledges number
    assertEq(eboProxy.pledgesAgainstDispute(_lastProposalId, _pledgerA), 1);
    assertEq(eboProxy.pledgesForDispute(_lastProposalId, _pledgerA), 0);

    // Check the proposal status
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.Disputed));
  }

  function test_Pledge_MaxEscalatedLifecycleTime() public {
    uint256 _notFirstPledgeAmount = initParams.parameters.pledgeBondSize * 2;
    uint256 _refreshMaxTimeBeforeExpiration = initParams.parameters.pledgeRefreshWindow - 1;
    // Dispute window was stretched to the max in the setUp

    // Advance close to the pledge window expiration to maximize lifecycle time
    vm.warp(_lastDisputeCreatedAt + _pledgeMaxTimeBeforeExpiration);

    // Pledge for the dispute
    _pledgeForDispute(_lastProposalId, _pledgerA);

    // Advance close to the pledge refresh window expiration to maximize lifecycle time
    vm.warp(_lastPledgeTimestamp + _refreshMaxTimeBeforeExpiration);

    // Pledge against the dispute
    _pledgeAgainstDispute(_lastProposalId, _pledgerB);

    // Advance close to the pledge refresh window expiration to maximize lifecycle time
    vm.warp(_lastPledgeTimestamp + _refreshMaxTimeBeforeExpiration);

    // Pledge for the dispute
    _pledgeForDispute(_lastProposalId, _pledgerC);

    // Advance close to the pledge refresh window expiration to maximize lifecycle time
    vm.warp(_lastPledgeTimestamp + _refreshMaxTimeBeforeExpiration);

    // Pledge against the dispute
    _pledgeAgainstDispute(_lastProposalId, _pledgerD);

    // Advance close to the pledge refresh window expiration to maximize lifecycle time
    vm.warp(_lastPledgeTimestamp + _refreshMaxTimeBeforeExpiration);

    // Pledge for the dispute
    _pledgeForDispute(_lastProposalId, _pledgerE);

    // The dispute is escalated after the last pledge

    address[] memory _pledgersForDispute = eboProxy.pledgersForDispute(_lastProposalId);
    address[] memory _pledgersAgainstDispute = eboProxy.pledgersAgainstDispute(_lastProposalId);

    (
      ,,
      uint256 _queriedLastPledgeTimestamp,
      uint256 _queriedTotalPledgesForDispute,
      uint256 _queriedTotalPledgesAgainstDispute,
    ) = eboProxy.disputes(_lastProposalId);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboProxy.proposals(_lastProposalId);

    // Check the pledgers's bonds
    assertEq(eboProxy.bonds(_pledgerA), initParams.parameters.pledgeBondSize);
    assertEq(eboProxy.bonds(_pledgerB), _notFirstPledgeAmount);
    assertEq(eboProxy.bonds(_pledgerC), _notFirstPledgeAmount);
    assertEq(eboProxy.bonds(_pledgerD), _notFirstPledgeAmount);
    assertEq(eboProxy.bonds(_pledgerE), initParams.parameters.pledgeBondSize);

    //Check the pledgers' pledges number
    assertEq(eboProxy.pledgesForDispute(_lastProposalId, _pledgerA), 1);
    assertEq(eboProxy.pledgesAgainstDispute(_lastProposalId, _pledgerA), 0);

    assertEq(eboProxy.pledgesForDispute(_lastProposalId, _pledgerB), 0);
    assertEq(eboProxy.pledgesAgainstDispute(_lastProposalId, _pledgerB), 2);

    assertEq(eboProxy.pledgesForDispute(_lastProposalId, _pledgerC), 2);
    assertEq(eboProxy.pledgesAgainstDispute(_lastProposalId, _pledgerC), 0);

    assertEq(eboProxy.pledgesForDispute(_lastProposalId, _pledgerD), 0);
    assertEq(eboProxy.pledgesAgainstDispute(_lastProposalId, _pledgerD), 2);

    assertEq(eboProxy.pledgesForDispute(_lastProposalId, _pledgerE), 1);
    assertEq(eboProxy.pledgesAgainstDispute(_lastProposalId, _pledgerE), 0);

    // Check that the pledgers were added to the corresponding list of dispute pledgers
    assertTrue(_containsAddress(_pledgerA, _pledgersForDispute));
    assertTrue(_containsAddress(_pledgerB, _pledgersAgainstDispute));
    assertTrue(_containsAddress(_pledgerC, _pledgersForDispute));
    assertTrue(_containsAddress(_pledgerD, _pledgersAgainstDispute));
    assertTrue(_containsAddress(_pledgerE, _pledgersForDispute));

    // Check that the pledgers were not added to the other list of dispute pledgers
    assertFalse(_containsAddress(_pledgerA, _pledgersAgainstDispute));
    assertFalse(_containsAddress(_pledgerB, _pledgersForDispute));
    assertFalse(_containsAddress(_pledgerC, _pledgersAgainstDispute));
    assertFalse(_containsAddress(_pledgerD, _pledgersForDispute));
    assertFalse(_containsAddress(_pledgerE, _pledgersAgainstDispute));

    // Check the last pledge timestamp
    assertEq(_queriedLastPledgeTimestamp, block.timestamp);

    // Check the total pledges for the dispute
    assertEq(_queriedTotalPledgesForDispute, initParams.parameters.maxNumberOfPledges);

    // Check the total pledges against the dispute
    assertEq(_queriedTotalPledgesAgainstDispute, initParams.parameters.maxNumberOfPledges);

    // Check the proposal status is Escalated
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.Escalated));
  }
}
