// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {ETHEREUM_CHAIN_ID, OPTIMISM_CHAIN_ID} from 'script/Constants.sol';
import {IntegrationBase} from 'test/integration/arbitrum-sepolia/IntegrationBase.t.sol';

import {IAccessManager} from 'src/interfaces/common/IAccessManager.sol';
import {IEBOStorage} from 'src/interfaces/common/IEBOStorage.sol';
import {IEBOCore} from 'src/interfaces/modules/IEBOCore.sol';

contract IntegrationAmendEpoch is IntegrationBase {
  uint256 internal _newBlockNumber;

  function setUp() public override {
    super.setUp();

    // Create a proposal
    _propose(ETHEREUM_CHAIN_ID);

    // Elapse the dispute window
    vm.warp(_lastProposalCreatedAt + initParams.parameters.disputeWindow);

    // Finalize the proposal
    _finalize(_lastProposalId);

    // Set the new block number
    _newBlockNumber = _lastProposalBlockNumber + 1;
  }

  function test_Revert_NotArbitrator() public {
    vm.expectRevert(IAccessManager.AccessManager_OnlyArbitrator_NotArbitrator.selector);

    vm.prank(_proposerA);
    eboProxy.amendEpochBlock(_lastProposalId, _newBlockNumber);
  }

  function test_Revert_ProposalNotFinalized() public {
    // Create a new proposal
    _propose(OPTIMISM_CHAIN_ID);
    vm.expectRevert(IEBOCore.EBOCore_AmendEpochBlock_ProposalNotFinalized.selector);

    vm.prank(arbitrator);
    // Amend the epoch block for the non-finalized proposal
    eboProxy.amendEpochBlock(_lastProposalId, _newBlockNumber);
  }

  function test_AmendEpochBlock() public {
    vm.prank(arbitrator);

    // Check the ProposalAmended event emission
    vm.expectEmit();
    emit IEBOCore.ProposalAmended(_lastProposalId, _lastProposalEpoch, ETHEREUM_CHAIN_ID, _newBlockNumber);

    // Amend the epoch block for the finalized proposal
    eboProxy.amendEpochBlock(_lastProposalId, _newBlockNumber);

    (
      uint256 _queriedEpoch,
      string memory _queriedChainId,
      uint256 _queriedBlockNumber,
      address _queriedProposer,
      uint256 _queriedProposalCreatedAt,
      uint256 _queriedParametersSnapshotId,
      IEBOStorage.ProposalStatus _queriedProposalStatus
    ) = eboProxy.proposals(_lastProposalId);

    uint256 _queriedActiveProposalId = eboProxy.activeProposal(_lastProposalEpoch, ETHEREUM_CHAIN_ID);

    // Check the new proposal data
    assertEq(_queriedEpoch, _lastProposalEpoch);
    assertEq(_queriedChainId, ETHEREUM_CHAIN_ID);
    assertEq(_queriedBlockNumber, _newBlockNumber);
    assertEq(_queriedProposer, _proposerA);
    assertEq(_queriedProposalCreatedAt, _lastProposalCreatedAt);
    assertEq(_queriedParametersSnapshotId, 1);
    assertEq(uint8(_queriedProposalStatus), uint8(IEBOStorage.ProposalStatus.Finalized));

    // Check the active proposal for the chain ID and epoch
    assertEq(_queriedActiveProposalId, _lastProposalId);
  }
}
