// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {HandlersParent} from '../handlers/HandlersParent.t.sol';

contract PropertiesA is HandlersParent {
  function property_sanityCheck() public {
    assertEq(address(ebo.arbitrator()), address(arbitrator), 'Failed sanity check - arbitrator');
    assertEq(address(ebo.council()), address(council), 'Failed sanity check - council');
    assertEq(address(ebo.grt()), address(grt), 'Failed sanity check - grt');
    assertEq(address(ebo.horizonStaking()), address(horizonStaking), 'Failed sanity check - horizonStaking');
    assertEq(address(ebo.epochManager()), address(epochManager), 'Failed sanity check - epochManager');
    assertEq(ebo.startEpoch(), START_EPOCH, 'Failed sanity check - startEpoch');

    for (uint256 _i = 0; _i < chainIds.length; _i++) {
      assertTrue(ebo.chainIdsAllowed(chainIds[_i]), 'Failed sanity check - chainIds');
    }
  }
}
