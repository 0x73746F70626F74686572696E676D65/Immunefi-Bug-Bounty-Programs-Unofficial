// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {ARBITRUM_SEPOLIA_START_EPOCH, ETHEREUM_CHAIN_ID} from 'script/Constants.sol';
import {IntegrationBase} from 'test/integration/arbitrum-sepolia/IntegrationBase.t.sol';

import {IEBOStorage} from 'src/interfaces/common/IEBOStorage.sol';
import {IEBOPledge} from 'src/interfaces/modules/IEBOPledge.sol';

contract IntegrationClaimPledgeReward is IntegrationBase {
  // Non-escalated disputes
  uint256 internal _disputerWonNotEscalatedProposalId;
  uint256 internal _disputerLostNotEscalatedProposalId;
  uint256 internal _noResolutionNotEscalatedProposalId;

  // Escalated disputes
  uint256 internal _disputerWonEscalatedProposalId;
  uint256 internal _disputerLostEscalatedProposalId;
  uint256 internal _noResolutionEscalatedProposalId;

  function setUp() public override {
    super.setUp();

    // Create a proposal, dispute it, and make the disputer win, reaching the max reward per winning pledge for non-escalated dispute
    _propose(ETHEREUM_CHAIN_ID, ARBITRUM_SEPOLIA_START_EPOCH, _proposerA);
    _dispute(_lastProposalId);
    _pledgeAgainstDispute(_lastProposalId, _pledgerA);
    _pledgeForDispute(_lastProposalId, _pledgerB);
    _pledgeAgainstDispute(_lastProposalId, _pledgerC);
    _pledgeForDispute(_lastProposalId, _pledgerD);
    _disputerWonNotEscalatedProposalId = _lastProposalId;

    // Create a proposal, dispute it, and make the disputer lose, reaching the max reward per winning pledge for non-escalated dispute
    _propose(ETHEREUM_CHAIN_ID, _lastProposalEpoch + 1, _proposerB);
    _dispute(_lastProposalId, _disputerB);
    _pledgeForDispute(_lastProposalId, _pledgerE);
    _pledgeAgainstDispute(_lastProposalId, _pledgerF);
    _pledgeForDispute(_lastProposalId, _pledgerG);
    _pledgeAgainstDispute(_lastProposalId, _pledgerH);
    _disputerLostNotEscalatedProposalId = _lastProposalId;

    // Create a proposal, and dispute it without any pledges
    _propose(ETHEREUM_CHAIN_ID, _lastProposalEpoch + 1, _proposerC);
    _dispute(_lastProposalId, _disputerC);
    _noResolutionNotEscalatedProposalId = _lastProposalId;

    // Create a proposal, dispute it reaching the max reward per winning pledge for escalated dispute
    _propose(ETHEREUM_CHAIN_ID, _lastProposalEpoch + 1, _proposerD);
    _dispute(_lastProposalId, _disputerD);
    _pledgeForDispute(_lastProposalId, _pledgerI);
    _pledgeAgainstDispute(_lastProposalId, _pledgerJ);
    _pledgeForDispute(_lastProposalId, _pledgerK);
    _pledgeAgainstDispute(_lastProposalId, _pledgerL);
    _pledgeForDispute(_lastProposalId, _pledgerM);
    _disputerWonEscalatedProposalId = _lastProposalId;

    // Create a proposal, dispute it reaching the max reward per winning pledge for escalated dispute
    _propose(ETHEREUM_CHAIN_ID, _lastProposalEpoch + 1, _proposerE);
    _dispute(_lastProposalId, _disputerE);
    _pledgeForDispute(_lastProposalId, _pledgerN);
    _pledgeAgainstDispute(_lastProposalId, _pledgerO);
    _pledgeForDispute(_lastProposalId, _pledgerP);
    _pledgeAgainstDispute(_lastProposalId, _pledgerQ);
    _pledgeForDispute(_lastProposalId, _pledgerR);
    _disputerLostEscalatedProposalId = _lastProposalId;

    // Create a proposal, dispute it, and escalate it
    _propose(ETHEREUM_CHAIN_ID, _lastProposalEpoch + 1, _proposerF);
    _dispute(_lastProposalId, _disputerF);
    // reusing pledgers because the bonds are going to be released when the dispute outcome is marked as no resolution
    _pledgeForDispute(_lastProposalId, _pledgerN);
    _pledgeAgainstDispute(_lastProposalId, _pledgerO);
    _pledgeForDispute(_lastProposalId, _pledgerP);
    _pledgeAgainstDispute(_lastProposalId, _pledgerQ);
    _pledgeForDispute(_lastProposalId, _pledgerR);
    _noResolutionEscalatedProposalId = _lastProposalId;

    // Resolve the dispute in favor of the disputer
    _resolve(_disputerWonEscalatedProposalId, IEBOStorage.ProposalStatus.DisputerWon);

    // Resolve the dispute in favor of the proposer
    _resolve(_disputerLostEscalatedProposalId, IEBOStorage.ProposalStatus.DisputerLost);

    // Resolve the dispute with no resolution status
    _resolve(_noResolutionEscalatedProposalId, IEBOStorage.ProposalStatus.NoResolution);

    // Elapse the pledge window
    vm.warp(_lastDisputeCreatedAt + initParams.parameters.pledgeWindow);

    // Resolve the disputes
    eboProxy.resolve(_disputerWonNotEscalatedProposalId);
    eboProxy.resolve(_disputerLostNotEscalatedProposalId);
    eboProxy.resolve(_noResolutionNotEscalatedProposalId);
  }

  function test_ClaimPledgeReward_Revert_DisputeHasNoResolution() public {
    // Non-escalated dispute
    vm.expectRevert(IEBOPledge.EBOPledge_ClaimPledgeReward_DisputeHasNoResolution.selector);
    eboProxy.claimPledgeReward(_noResolutionNotEscalatedProposalId, _pledgerA);

    // Escalated dispute
    vm.expectRevert(IEBOPledge.EBOPledge_ClaimPledgeReward_DisputeHasNoResolution.selector);
    eboProxy.claimPledgeReward(_noResolutionEscalatedProposalId, _pledgerN);
  }

  function test_ClaimPledgeReward_Revert_AlreadyClaimed() public {
    // Disputer won case with non-escalated dispute
    eboProxy.claimPledgeReward(_disputerWonNotEscalatedProposalId, _pledgerB);

    vm.expectRevert(IEBOPledge.EBOPledge_ClaimPledgeReward_AlreadyClaimed.selector);
    eboProxy.claimPledgeReward(_disputerWonNotEscalatedProposalId, _pledgerB);

    // Disputer lost case with non-escalated dispute
    eboProxy.claimPledgeReward(_disputerLostNotEscalatedProposalId, _pledgerF);

    vm.expectRevert(IEBOPledge.EBOPledge_ClaimPledgeReward_AlreadyClaimed.selector);
    eboProxy.claimPledgeReward(_disputerLostNotEscalatedProposalId, _pledgerF);

    // Disputer won case with escalated dispute
    eboProxy.claimPledgeReward(_disputerWonEscalatedProposalId, _pledgerI);

    vm.expectRevert(IEBOPledge.EBOPledge_ClaimPledgeReward_AlreadyClaimed.selector);
    eboProxy.claimPledgeReward(_disputerWonEscalatedProposalId, _pledgerI);

    // Disputer lost case with escalated dispute
    eboProxy.claimPledgeReward(_disputerLostEscalatedProposalId, _pledgerO);

    vm.expectRevert(IEBOPledge.EBOPledge_ClaimPledgeReward_AlreadyClaimed.selector);
    eboProxy.claimPledgeReward(_disputerLostEscalatedProposalId, _pledgerO);
  }

  function test_ClaimPledgeReward_Revert_NoRewardToClaim() public {
    // Disputer won case with non-escalated dispute
    vm.expectRevert(IEBOPledge.EBOPledge_ClaimPledgeReward_NoRewardToClaim.selector);
    eboProxy.claimPledgeReward(_disputerWonNotEscalatedProposalId, _pledgerA);

    // Disputer lost case with non-escalated dispute
    vm.expectRevert(IEBOPledge.EBOPledge_ClaimPledgeReward_NoRewardToClaim.selector);
    eboProxy.claimPledgeReward(_disputerLostNotEscalatedProposalId, _pledgerE);

    // Disputer won case with escalated dispute
    vm.expectRevert(IEBOPledge.EBOPledge_ClaimPledgeReward_NoRewardToClaim.selector);
    eboProxy.claimPledgeReward(_disputerWonEscalatedProposalId, _pledgerJ);

    // Disputer lost case with escalated dispute
    vm.expectRevert(IEBOPledge.EBOPledge_ClaimPledgeReward_NoRewardToClaim.selector);
    eboProxy.claimPledgeReward(_disputerLostEscalatedProposalId, _pledgerN);
  }

  function test_ClaimPledgeReward() public {
    // 3 pledges * 2 non-escalated disputes + 4 pledges * 2 escalated disputes => 14 pledges
    uint256 _totalPledgeRewards = initParams.parameters.pledgeBondSize * 14;

    // Santity check of the GRT balance of the EBO contract before the claim
    assertEq(grt.balanceOf(address(eboProxy)), _totalPledgeRewards);

    // Disputer won case with non-escalated dispute
    eboProxy.claimPledgeReward(_disputerWonNotEscalatedProposalId, _pledgerB);
    eboProxy.claimPledgeReward(_disputerWonNotEscalatedProposalId, _pledgerD);

    // Check the pledgerClaimed mapping
    assertTrue(eboProxy.pledgerClaimed(_disputerWonNotEscalatedProposalId, _pledgerB));
    assertTrue(eboProxy.pledgerClaimed(_disputerWonNotEscalatedProposalId, _pledgerD));

    // Check the GRT reward received by the winning pledgers
    assertEq(
      grt.balanceOf(_pledgerB),
      _maxNotEscalatedRewardPerWinningPledge * eboProxy.pledgesForDispute(_disputerWonNotEscalatedProposalId, _pledgerB) // 2 pledges
    );
    assertEq(
      grt.balanceOf(_pledgerD),
      _maxNotEscalatedRewardPerWinningPledge * eboProxy.pledgesForDispute(_disputerWonNotEscalatedProposalId, _pledgerD) // 2 pledges
    );

    // Check that the losing pledgers have not received any GRT
    assertEq(grt.balanceOf(_pledgerA), 0);
    assertEq(grt.balanceOf(_pledgerC), 0);

    // Disputer lost case with non-escalated dispute
    eboProxy.claimPledgeReward(_disputerLostNotEscalatedProposalId, _pledgerF);
    eboProxy.claimPledgeReward(_disputerLostNotEscalatedProposalId, _pledgerH);

    // Check the pledgerClaimed mapping
    assertTrue(eboProxy.pledgerClaimed(_disputerLostNotEscalatedProposalId, _pledgerF));
    assertTrue(eboProxy.pledgerClaimed(_disputerLostNotEscalatedProposalId, _pledgerH));

    // Check the GRT reward received by the winning pledgers
    assertEq(
      grt.balanceOf(_pledgerF),
      _maxNotEscalatedRewardPerWinningPledge
        * eboProxy.pledgesAgainstDispute(_disputerLostNotEscalatedProposalId, _pledgerF) // 2 pledges
    );
    assertEq(
      grt.balanceOf(_pledgerH),
      _maxNotEscalatedRewardPerWinningPledge
        * eboProxy.pledgesAgainstDispute(_disputerLostNotEscalatedProposalId, _pledgerH) // 2 pledges
    );

    // Check that the losing pledgers have not received any GRT
    assertEq(grt.balanceOf(_pledgerE), 0);
    assertEq(grt.balanceOf(_pledgerG), 0);

    // Disputer won case with escalated dispute
    eboProxy.claimPledgeReward(_disputerWonEscalatedProposalId, _pledgerI);
    eboProxy.claimPledgeReward(_disputerWonEscalatedProposalId, _pledgerK);
    eboProxy.claimPledgeReward(_disputerWonEscalatedProposalId, _pledgerM);
    // Check the pledgerClaimed mapping
    assertTrue(eboProxy.pledgerClaimed(_disputerWonEscalatedProposalId, _pledgerI));
    assertTrue(eboProxy.pledgerClaimed(_disputerWonEscalatedProposalId, _pledgerK));
    assertTrue(eboProxy.pledgerClaimed(_disputerWonEscalatedProposalId, _pledgerM));

    // Check the GRT reward received by the winning pledgers
    assertEq(
      grt.balanceOf(_pledgerI),
      initParams.parameters.pledgeBondSize * eboProxy.pledgesForDispute(_disputerWonEscalatedProposalId, _pledgerI)
    );
    assertEq(
      grt.balanceOf(_pledgerK),
      initParams.parameters.pledgeBondSize * eboProxy.pledgesForDispute(_disputerWonEscalatedProposalId, _pledgerK)
    );
    assertEq(
      grt.balanceOf(_pledgerM),
      initParams.parameters.pledgeBondSize * eboProxy.pledgesForDispute(_disputerWonEscalatedProposalId, _pledgerM)
    );

    // Check that the losing pledgers have not received any GRT
    assertEq(grt.balanceOf(_pledgerJ), 0);
    assertEq(grt.balanceOf(_pledgerL), 0);

    // Disputer lost case with escalated dispute
    eboProxy.claimPledgeReward(_disputerLostEscalatedProposalId, _pledgerO);
    eboProxy.claimPledgeReward(_disputerLostEscalatedProposalId, _pledgerQ);

    // Check the pledgerClaimed mapping
    assertTrue(eboProxy.pledgerClaimed(_disputerLostEscalatedProposalId, _pledgerO));
    assertTrue(eboProxy.pledgerClaimed(_disputerLostEscalatedProposalId, _pledgerQ));

    // Check the GRT reward received by the winning pledgers
    assertEq(
      grt.balanceOf(_pledgerO),
      initParams.parameters.pledgeBondSize * eboProxy.pledgesAgainstDispute(_disputerLostEscalatedProposalId, _pledgerO)
    );
    assertEq(
      grt.balanceOf(_pledgerQ),
      initParams.parameters.pledgeBondSize * eboProxy.pledgesAgainstDispute(_disputerLostEscalatedProposalId, _pledgerQ)
    );

    // Check that the losing pledgers have not received any GRT
    assertEq(grt.balanceOf(_pledgerN), 0);
    assertEq(grt.balanceOf(_pledgerP), 0);
    assertEq(grt.balanceOf(_pledgerR), 0);

    // Check the GRT balance of the EBO contract
    assertEq(grt.balanceOf(address(eboProxy)), 0);
  }
}
