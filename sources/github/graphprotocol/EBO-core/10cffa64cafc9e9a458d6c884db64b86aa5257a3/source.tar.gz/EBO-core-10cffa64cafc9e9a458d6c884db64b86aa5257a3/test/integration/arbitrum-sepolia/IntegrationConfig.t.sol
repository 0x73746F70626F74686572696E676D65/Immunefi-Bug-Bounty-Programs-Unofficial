// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IERC20} from '@openzeppelin/contracts/token/ERC20/IERC20.sol';

import {IntegrationBase} from 'test/integration/arbitrum-sepolia/IntegrationBase.t.sol';

import {IAccessManager} from 'src/interfaces/common/IAccessManager.sol';
import {IEBOStorage} from 'src/interfaces/common/IEBOStorage.sol';
import {IEBOConfig} from 'src/interfaces/modules/IEBOConfig.sol';

import {IEpochManager} from 'src/interfaces/external/IEpochManager.sol';
import {IHorizonStaking} from 'src/interfaces/external/IHorizonStaking.sol';

contract IntegrationConfig is IntegrationBase {
  address internal _newAddress;
  string[] internal _notAddedChainIds;

  function setUp() public override {
    super.setUp();
    _newAddress = makeAddr('newAddress');
    _notAddedChainIds.push('notAdded0x1');
    _notAddedChainIds.push('notAddded0x2');
  }

  modifier givenTheCallerIsTheCouncil() {
    vm.startPrank(council);
    _;
  }

  modifier givenTheCallerIsTheArbitrator() {
    vm.startPrank(arbitrator);
    _;
  }

  function test_SetArbitrator_Revert_NotCouncil() public {
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);

    eboProxy.setArbitrator(address(0));
  }

  function test_SetArbitrator_Revert_AddressAlreadySet() public givenTheCallerIsTheCouncil {
    vm.expectRevert(IEBOConfig.EBOConfig_SetArbitrator_AddressAlreadySet.selector);

    eboProxy.setArbitrator(arbitrator);
  }

  function test_SetArbitrator() public givenTheCallerIsTheCouncil {
    eboProxy.setArbitrator(_newAddress);

    assertEq(eboProxy.arbitrator(), _newAddress);
  }

  function test_SetPendingCouncil_Revert_NotCouncil() public {
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);

    eboProxy.setPendingCouncil(address(0));
  }

  function test_SetPendingCouncil_Revert_AddressAlreadySet() public givenTheCallerIsTheCouncil {
    // Check for address already set
    eboProxy.setPendingCouncil(_newAddress);

    vm.expectRevert(IEBOConfig.EBOConfig_SetPendingCouncil_AddressAlreadySet.selector);
    eboProxy.setPendingCouncil(_newAddress);
  }

  function test_SetPendingCouncil() public givenTheCallerIsTheCouncil {
    eboProxy.setPendingCouncil(_newAddress);

    assertEq(eboProxy.pendingCouncil(), _newAddress);
  }

  function test_ConfirmCouncil_Revert_NotPendingCouncil() public {
    vm.expectRevert(IAccessManager.AccessManager_OnlyPendingCouncil_NotPendingCouncil.selector);

    eboProxy.confirmCouncil();
  }

  function test_ConfirmCouncil() public {
    vm.prank(council);
    eboProxy.setPendingCouncil(_newAddress);

    vm.startPrank(_newAddress);
    eboProxy.confirmCouncil();

    assertEq(eboProxy.council(), _newAddress);
    assertEq(eboProxy.pendingCouncil(), address(0));
  }

  function test_SetGRT_Revert_NotCouncil() public {
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);

    eboProxy.setGRT(IERC20(address(0)));
  }

  function test_SetGRT_Revert_AddressAlreadySet() public givenTheCallerIsTheCouncil {
    vm.expectRevert(IEBOConfig.EBOConfig_SetGRT_AddressAlreadySet.selector);

    eboProxy.setGRT(IERC20(address(grt)));
  }

  function test_SetGRT() public givenTheCallerIsTheCouncil {
    eboProxy.setGRT(IERC20(_newAddress));

    assertEq(address(eboProxy.grt()), _newAddress);
  }

  function test_SetHorizonStaking_Revert_NotCouncil() public {
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);

    eboProxy.setHorizonStaking(IHorizonStaking(address(0)));
  }

  function test_SetHorizonStaking_Revert_AddressAlreadySet() public givenTheCallerIsTheCouncil {
    vm.expectRevert(IEBOConfig.EBOConfig_SetHorizonStaking_AddressAlreadySet.selector);

    eboProxy.setHorizonStaking(IHorizonStaking(address(horizonStaking)));
  }

  function test_SetHorizonStaking() public givenTheCallerIsTheCouncil {
    eboProxy.setHorizonStaking(IHorizonStaking(_newAddress));

    assertEq(address(eboProxy.horizonStaking()), _newAddress);
  }

  function test_SetEpochManager_Revert_NotCouncil() public {
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);

    eboProxy.setEpochManager(IEpochManager(address(0)));
  }

  function test_SetEpochManager_Revert_AddressAlreadySet() public givenTheCallerIsTheCouncil {
    vm.expectRevert(IEBOConfig.EBOConfig_SetEpochManager_AddressAlreadySet.selector);

    eboProxy.setEpochManager(IEpochManager(address(epochManager)));
  }

  function test_SetEpochManager() public givenTheCallerIsTheCouncil {
    eboProxy.setEpochManager(IEpochManager(_newAddress));

    assertEq(address(eboProxy.epochManager()), _newAddress);
  }

  function test_AddChainIds_Revert_NotCouncil() public {
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);

    eboProxy.addChainIds(initParams.chainIds);
  }

  function test_AddChainIds_Revert_ChainIdAlreadyAdded() public givenTheCallerIsTheCouncil {
    vm.expectRevert(IEBOConfig.EBOConfig_AddChainIds_ChainIdAlreadyAdded.selector);

    eboProxy.addChainIds(initParams.chainIds);
  }

  function test_AddChainIds() public givenTheCallerIsTheCouncil {
    eboProxy.addChainIds(_notAddedChainIds);

    assertTrue(eboProxy.chainIdsAllowed(_notAddedChainIds[0]));
    assertTrue(eboProxy.chainIdsAllowed(_notAddedChainIds[1]));
  }

  function test_RemoveChainIds_Revert_NotCouncil() public {
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);

    eboProxy.removeChainIds(initParams.chainIds);
  }

  function test_RemoveChainIds_Revert_ChainIdNotAdded() public givenTheCallerIsTheCouncil {
    vm.expectRevert(IEBOConfig.EBOConfig_RemoveChainIds_ChainIdNotAdded.selector);

    eboProxy.removeChainIds(_notAddedChainIds);
  }

  function test_RemoveChainIds() public givenTheCallerIsTheCouncil {
    eboProxy.removeChainIds(initParams.chainIds);

    assertFalse(eboProxy.chainIdsAllowed(initParams.chainIds[0]));
    assertFalse(eboProxy.chainIdsAllowed(initParams.chainIds[1]));
  }

  function test_SetParameters_Revert_NotCouncil() public {
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);

    eboProxy.setParameters(initParams.parameters, initParams.arbitratorResolutionWindow);
  }

  function test_SetParameters_Revert_ProposalBondSizeIsZero() public givenTheCallerIsTheCouncil {
    // Set proposal bond size to zero
    initParams.parameters.proposalBondSize = 0;

    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_ParametersCannotBeZero.selector);

    eboProxy.setParameters(initParams.parameters, initParams.arbitratorResolutionWindow);
  }

  function test_SetParameters_Revert_PledgeBondSizeIsZero() public givenTheCallerIsTheCouncil {
    // Set pledge bond size to zero
    initParams.parameters.pledgeBondSize = 0;

    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_ParametersCannotBeZero.selector);
    eboProxy.setParameters(initParams.parameters, initParams.arbitratorResolutionWindow);
  }

  function test_SetParameters_Revert_DisputeWindowIsZero() public givenTheCallerIsTheCouncil {
    // Set dispute window to zero
    initParams.parameters.disputeWindow = 0;

    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_ParametersCannotBeZero.selector);
    eboProxy.setParameters(initParams.parameters, initParams.arbitratorResolutionWindow);
  }

  function test_SetParameters_Revert_PledgeRefreshWindowIsZero() public givenTheCallerIsTheCouncil {
    // Set pledge refresh window to zero
    initParams.parameters.pledgeRefreshWindow = 0;

    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_ParametersCannotBeZero.selector);
    eboProxy.setParameters(initParams.parameters, initParams.arbitratorResolutionWindow);
  }

  function test_SetParameters_Revert_ArbitratorResolutionWindowIsZero() public givenTheCallerIsTheCouncil {
    // Set arbitrator resolution window to zero
    initParams.arbitratorResolutionWindow = 0;

    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_ParametersCannotBeZero.selector);
    eboProxy.setParameters(initParams.parameters, initParams.arbitratorResolutionWindow);
  }

  function test_SetParameters_Revert_PledgeRefreshWindowExceedsPledgeWindow() public givenTheCallerIsTheCouncil {
    // Set pledge refresh window to exceed pledge window
    initParams.parameters.pledgeRefreshWindow = initParams.parameters.pledgeWindow + 1;

    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_PledgeRefreshWindowExceedsPledgeWindow.selector);
    eboProxy.setParameters(initParams.parameters, initParams.arbitratorResolutionWindow);
  }

  function test_SetParameters_Revert_MinThawingPeriodTooShort() public givenTheCallerIsTheCouncil {
    // Set a not long enough min thawing period
    initParams.parameters.minThawingPeriod = initParams.parameters.disputeWindow + initParams.parameters.pledgeWindow
      + initParams.parameters.pledgeRefreshWindow + initParams.arbitratorResolutionWindow - 1;

    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_MinThawingPeriodTooShort.selector);
    eboProxy.setParameters(initParams.parameters, initParams.arbitratorResolutionWindow);
  }

  function test_SetParameters() public givenTheCallerIsTheCouncil {
    IEBOStorage.Parameters memory _newParameters = IEBOStorage.Parameters({
      proposalBondSize: initParams.parameters.proposalBondSize + 1,
      pledgeBondSize: initParams.parameters.pledgeBondSize + 1,
      disputeWindow: initParams.parameters.disputeWindow + 1,
      pledgeWindow: initParams.parameters.pledgeWindow + 1,
      pledgeRefreshWindow: initParams.parameters.pledgeRefreshWindow + 1,
      minThawingPeriod: initParams.parameters.minThawingPeriod + 1,
      maxNumberOfPledges: initParams.parameters.maxNumberOfPledges + 1
    });
    uint256 _newArbitratorResolutionWindow = initParams.arbitratorResolutionWindow + 1;

    // Expect event emission to check the new arbitrator resolution window
    vm.expectEmit();
    emit IEBOConfig.ParametersSet({
      _parameters: _newParameters, _parametersSnapshotId: 2, _arbitratorResolutionWindow: _newArbitratorResolutionWindow
    });

    eboProxy.setParameters(_newParameters, _newArbitratorResolutionWindow);

    uint256 _queriedParametersSnapshotId = eboProxy.parametersSnapshotId();
    (
      uint256 _queriedProposalBondSize,
      uint256 _queriedPledgeBondSize,
      uint256 _queriedMinThawingPeriod,
      uint256 _queriedDisputeWindow,
      uint256 _queriedPledgeWindow,
      uint256 _queriedPledgeRefreshWindow,
      uint256 _queriedMaxNumberOfPledges
    ) = eboProxy.parametersSnapshots(_queriedParametersSnapshotId);

    assertEq(_queriedParametersSnapshotId, 2);

    assertEq(_queriedProposalBondSize, _newParameters.proposalBondSize);
    assertEq(_queriedPledgeBondSize, _newParameters.pledgeBondSize);
    assertEq(_queriedMinThawingPeriod, _newParameters.minThawingPeriod);
    assertEq(_queriedDisputeWindow, _newParameters.disputeWindow);
    assertEq(_queriedPledgeWindow, _newParameters.pledgeWindow);
    assertEq(_queriedPledgeRefreshWindow, _newParameters.pledgeRefreshWindow);
    assertEq(_queriedMaxNumberOfPledges, _newParameters.maxNumberOfPledges);
  }
}
