// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {Setup} from '../Setup.t.sol';
import {IHorizonStaking} from 'src/interfaces/external/IHorizonStaking.sol';

contract HandlersHorizon is Setup {
  function handler_thaw(uint256 _amount) external createActor {
    IHorizonStaking.Provision memory _provisionData = horizonStaking.getProvision(currentActor, address(ebo));
    uint256 _tokensNotThawing = _provisionData.tokens - _provisionData.tokensThawing;
    _amount = clampBetween(_amount, 0, _tokensNotThawing);

    vm.prank(currentActor);
    try horizonStaking.thaw(currentActor, address(ebo), _amount) {}
    catch (bytes memory) {
      assert(_amount == 0);
    }
  }
}
