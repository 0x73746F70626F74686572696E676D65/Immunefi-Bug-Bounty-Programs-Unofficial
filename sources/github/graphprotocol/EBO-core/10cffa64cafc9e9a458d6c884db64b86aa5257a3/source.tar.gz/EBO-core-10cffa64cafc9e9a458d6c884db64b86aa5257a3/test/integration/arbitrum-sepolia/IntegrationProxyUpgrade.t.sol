// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IntegrationBase} from 'test/integration/arbitrum-sepolia/IntegrationBase.t.sol';

import {EBO} from 'src/contracts/EBO.sol';
import {IAccessManager} from 'src/interfaces/common/IAccessManager.sol';

contract IntegrationProxyUpgrade is IntegrationBase {
  function test_UpgradeToAndCall_Revert_NotCouncil() public {
    // Revert if the caller is not the council
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);

    eboProxy.upgradeToAndCall(address(0), '');
  }

  function test_UpgradeToAndCall() public {
    address _newImplementation = address(new EBO());

    vm.prank(council);
    // Upgrade the proxy to the new implementation
    eboProxy.upgradeToAndCall(_newImplementation, '');

    bytes32 _implSlot = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;

    address _queriedImplementation = address(uint160(uint256(vm.load(address(eboProxy), _implSlot))));

    // It should upgrade the EBO contract to the implementation address
    assertEq(_queriedImplementation, _newImplementation);
  }
}
