// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IHorizonStaking} from 'interfaces/external/IHorizonStaking.sol';

import {EBOCore, IEBOCore} from 'contracts/modules/EBOCore.sol';

import {IAccessManager} from 'interfaces/common/IAccessManager.sol';

import {IEBOStorage, IEpochManager, IHorizonStaking} from 'interfaces/common/IEBOStorage.sol';
import {IResolutionManager} from 'interfaces/common/IResolutionManager.sol';

import {EBOStorageHelper} from 'test/utils/EBOStorageHelper.t.sol';

import {EBOTestHelpers} from 'test/utils/EBOTestHelpers.t.sol';

/**
 * @title EBOCore unit tests
 */
contract EBOCoreUnit is EBOTestHelpers {
  // Contracts
  EBOCoreForTest public eboCore;

  // Variables
  IEBOStorage.Parameters public parameters;

  function setUp() public override {
    super.setUp();

    eboCore = new EBOCoreForTest();

    // Set up the contract storage
    eboCore.setArbitratorForTest(arbitrator);
    eboCore.setHorizonStakingForTest(IHorizonStaking(horizonStaking));
    eboCore.setEpochManagerForTest(IEpochManager(epochManager));

    parameters = IEBOStorage.Parameters({
      proposalBondSize: 15_000 ether,
      pledgeBondSize: 15_000 ether,
      minThawingPeriod: 2 weeks,
      disputeWindow: 12 hours,
      pledgeWindow: 2 days,
      pledgeRefreshWindow: 1 days,
      maxNumberOfPledges: 4
    });

    eboCore.setParametersForTest({_snapshotId: 0, _parameters: parameters});
  }

  function test_Propose_RevertWhen_TheCallerIsNotAValidOperator() external {
    _mockAndExpect(horizonStaking, abi.encodeWithSelector(IHorizonStaking.isAuthorized.selector), abi.encode(false));

    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyOperator_NotOperator.selector);

    // When the caller is not a valid operator
    vm.prank(notProtocolActor);
    eboCore.propose({_epoch: 0, _chainId: '', _blockNumber: 0, _serviceProvider: caller});
  }

  function test_Propose_RevertWhen_TheEpochIsGreaterThanTheCurrentEpoch(uint256 _epoch) external {
    _epoch = bound(_epoch, 1, type(uint128).max);

    // When the epoch is greater than the current epoch
    _mockAndExpect(epochManager, abi.encodeWithSelector(IEpochManager.currentEpoch.selector), abi.encode(0));

    vm.prank(caller);

    // It should revert
    vm.expectRevert(IEBOCore.EBOCore_Propose_InvalidEpoch.selector);
    eboCore.propose({_epoch: _epoch, _chainId: '', _blockNumber: 0, _serviceProvider: caller});
  }

  function test_Propose_RevertWhen_TheEpochIsLessThanTheStartEpoch(uint64 _epoch, uint256 _startEpoch) external {
    _startEpoch = bound(_startEpoch, uint256(_epoch) + 1, type(uint128).max);

    // When the epoch is less than the start epoch
    _mockAndExpect(epochManager, abi.encodeWithSelector(IEpochManager.currentEpoch.selector), abi.encode(_epoch));

    eboCore.setStartEpochForTest(_startEpoch);

    vm.prank(caller);

    // It should revert
    vm.expectRevert(IEBOCore.EBOCore_Propose_InvalidEpoch.selector);
    eboCore.propose({_epoch: _epoch, _chainId: '', _blockNumber: 0, _serviceProvider: caller});
  }

  function test_Propose_RevertWhen_TheChainIsNotAdded(uint256 _epoch) external {
    _mockAndExpect(epochManager, abi.encodeWithSelector(IEpochManager.currentEpoch.selector), abi.encode(_epoch));

    // When the chain is not added

    vm.prank(caller);

    // It should revert
    vm.expectRevert(IEBOCore.EBOCore_Propose_ChainNotAdded.selector);
    eboCore.propose({_epoch: _epoch, _chainId: '', _blockNumber: 0, _serviceProvider: caller});
  }

  function test_Propose_RevertWhen_TheProposalIsAlreadyActive(uint64 _epoch, string memory _chainId) external {
    _mockAndExpect(epochManager, abi.encodeWithSelector(IEpochManager.currentEpoch.selector), abi.encode(_epoch));

    // When the proposal is already active
    eboCore.setActiveProposalForTest({_epoch: _epoch, _chainId: _chainId, _proposalId: 1});
    eboCore.setChainIdsAllowedForTest(_chainId);

    vm.prank(caller);

    // It should revert
    vm.expectRevert(IEBOCore.EBOCore_Propose_ProposalAlreadyActive.selector);
    eboCore.propose({_epoch: _epoch, _chainId: _chainId, _blockNumber: 0, _serviceProvider: caller});
  }

  struct ProposeTestParams {
    uint256 epoch;
    string chainId;
    uint256 blockNumber;
    uint256 proposalBondSize;
    uint256 minThawingPeriod;
    uint256 parametersSnapshotId;
  }

  function test_Propose_WhenAllThePreconditionsAreMet(ProposeTestParams memory _params) external {
    _params.proposalBondSize = bound(_params.proposalBondSize, 1, type(uint256).max);
    _params.minThawingPeriod = bound(_params.minThawingPeriod, 1, type(uint64).max);

    _mockAndExpect(epochManager, abi.encodeWithSelector(IEpochManager.currentEpoch.selector), abi.encode(_params.epoch));

    // It should bond the proposal bond size of the bonder
    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(IHorizonStaking.getProvision.selector, caller, address(eboCore)),
      abi.encode(
        IHorizonStaking.Provision({
            tokens: _params.proposalBondSize,
            tokensThawing: 0,
            sharesThawing: 0,
            maxVerifierCut: eboCore.MAX_MAX_VERIFIER_CUT(),
            thawingPeriod: uint64(_params.minThawingPeriod),
            createdAt: 0,
            maxVerifierCutPending: 0,
            thawingPeriodPending: 0,
            thawingNonce: 0
          })
      )
    );

    uint256 _previousProposalId = eboCore.proposalId();
    uint256 _newProposalId = _previousProposalId + 1;

    // When all the preconditions are met
    eboCore.setChainIdsAllowedForTest(_params.chainId);
    eboCore.setParametersForTest({
      _snapshotId: _params.parametersSnapshotId,
      _parameters: IEBOStorage.Parameters({
        proposalBondSize: _params.proposalBondSize,
        pledgeBondSize: 0,
        minThawingPeriod: _params.minThawingPeriod,
        disputeWindow: 0,
        pledgeWindow: 0,
        pledgeRefreshWindow: 0,
        maxNumberOfPledges: 0
      })
    });

    // It should emit the ProposalCreated event
    vm.expectEmit();
    emit IEBOCore.ProposalCreated(_newProposalId, _params.epoch, _params.chainId, _params.blockNumber, caller);

    vm.prank(caller);
    eboCore.propose(_params.epoch, _params.chainId, _params.blockNumber, caller);

    (
      uint256 _epoch,
      string memory _chainId,
      uint256 _blockNumber,
      address _proposer,
      uint256 _proposalCreatedAt,
      uint256 _parametersSnapshotId,
      IEBOStorage.ProposalStatus _proposalStatus
    ) = eboCore.proposals(_newProposalId);

    (uint256 _proposalBondSize,, uint256 _minThawingPeriod,,,,) = eboCore.parametersSnapshots(_parametersSnapshotId);

    // It should increase the proposal id
    assertEq(eboCore.proposalId(), _newProposalId);

    // It should store the proposal id in the active proposal mapping for the epoch and the chain id
    assertEq(eboCore.activeProposal(_params.epoch, _params.chainId), _newProposalId);

    // It should create and store the proposal with the last proposal id and the last parameters snapshot id
    assertEq(_epoch, _params.epoch);
    assertEq(_chainId, _params.chainId);
    assertEq(_blockNumber, _params.blockNumber);
    assertEq(_proposer, caller);
    assertEq(_proposalCreatedAt, block.timestamp);
    assertEq(_proposalBondSize, _params.proposalBondSize);
    assertEq(_minThawingPeriod, _params.minThawingPeriod);
    assertEq(_parametersSnapshotId, eboCore.parametersSnapshotId());
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.Active));
  }

  function test_Dispute_RevertWhen_TheCallerIsNotAValidOperator() external {
    _mockAndExpect(horizonStaking, abi.encodeWithSelector(IHorizonStaking.isAuthorized.selector), abi.encode(false));

    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyOperator_NotOperator.selector);

    // When the caller is not a valid operator
    vm.prank(notProtocolActor);
    eboCore.dispute({_proposalId: 0, _serviceProvider: caller});
  }

  function test_Dispute_RevertWhen_TheProposalIsNotActive(uint256 _proposalId) external {
    // When the proposal is not active
    vm.prank(caller);

    // It should revert
    vm.expectRevert(IEBOCore.EBOCore_Dispute_ProposalNotActive.selector);
    eboCore.dispute(_proposalId, caller);
  }

  function test_Dispute_RevertWhen_TheDisputeWindowHasPassed(
    uint256 _proposalId,
    uint64 _disputeWindow,
    uint256 _snapshotId
  ) external {
    parameters.disputeWindow = _disputeWindow;
    eboCore.setParametersForTest({_snapshotId: _snapshotId, _parameters: parameters});

    eboCore.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: _snapshotId,
        status: IEBOStorage.ProposalStatus.Active
      })
    });

    // When the dispute window has passed
    vm.warp(block.timestamp + _disputeWindow);

    vm.prank(caller);

    // It should revert
    vm.expectRevert(IEBOCore.EBOCore_Dispute_DisputeWindowOver.selector);
    eboCore.dispute(_proposalId, caller);
  }

  function test_Dispute_WhenAllThePreconditionsAreMet(
    uint256 _proposalId,
    uint256 _disputeWindow,
    uint256 _proposalBondSize,
    uint64 _minThawingPeriod
  ) external {
    _disputeWindow = bound(_disputeWindow, block.timestamp + 1, type(uint128).max);
    _proposalBondSize = bound(_proposalBondSize, 1, type(uint128).max);
    _minThawingPeriod = uint64(bound(_minThawingPeriod, 1, type(uint64).max));

    // When all the preconditions are met
    eboCore.setParametersForTest({
      _snapshotId: 0,
      _parameters: IEBOStorage.Parameters({
        proposalBondSize: _proposalBondSize,
        pledgeBondSize: 0,
        minThawingPeriod: _minThawingPeriod,
        disputeWindow: _disputeWindow,
        pledgeWindow: 0,
        pledgeRefreshWindow: 0,
        maxNumberOfPledges: 0
      })
    });

    eboCore.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Active
      })
    });

    // It should bond the proposal bond size of the bonder
    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(IHorizonStaking.getProvision.selector, disputer, address(eboCore)),
      abi.encode(
        IHorizonStaking.Provision({
            tokens: _proposalBondSize,
            tokensThawing: 0,
            sharesThawing: 0,
            maxVerifierCut: eboCore.MAX_MAX_VERIFIER_CUT(),
            thawingPeriod: _minThawingPeriod,
            createdAt: 0,
            maxVerifierCutPending: 0,
            thawingPeriodPending: 0,
            thawingNonce: 0
          })
      )
    );

    // It should emit the ProposalDisputed event
    vm.expectEmit();
    emit IEBOCore.ProposalDisputed(_proposalId);

    vm.prank(disputer);
    eboCore.dispute(_proposalId, disputer);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboCore.proposals(_proposalId);

    assertEq(eboCore.bonds(disputer), _proposalBondSize);

    // It should set the proposal status to Disputed
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.Disputed));

    // It should delete the active proposal id from active proposal mapping for the epoch and the chain id
    assertEq(eboCore.activeProposal({_epoch: 0, _chainId: ''}), 0);

    // It should create and store the dispute
    (
      address _disputer,
      uint256 _disputeCreatedAt,
      uint256 _lastPledgeTimestamp,
      uint256 _totalPledgesForDispute,
      uint256 _totalPledgesAgainstDispute,
      uint256 _rewardPerWinningPledge
    ) = eboCore.disputes(_proposalId);
    assertEq(_disputer, disputer);
    assertEq(_disputeCreatedAt, block.timestamp);
    assertEq(_lastPledgeTimestamp, 0);
    assertEq(_totalPledgesForDispute, 0);
    assertEq(_totalPledgesAgainstDispute, 0);
    assertEq(_rewardPerWinningPledge, 0);
  }

  function test_ResolveByPledges_RevertWhen_TheProposalIsNotDisputed(uint256 _proposalId) external {
    // When the proposal is not disputed

    // It should revert
    vm.expectRevert(IEBOCore.EBOCore_Resolve_ProposalNotDisputed.selector);
    eboCore.resolve(_proposalId);
  }

  function test_ResolveByPledges_RevertWhen_ThePledgeWindowHasNotPassed(uint256 _proposalId) external {
    // When the pledge window has not passed
    eboCore.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    // It should revert
    vm.expectRevert(IEBOCore.EBOCore_Resolve_PledgeWindowNotOver.selector);
    eboCore.resolve(_proposalId);
  }

  function test_ResolveByPledges_WhenThePledgesForAndAgainstAreZero(uint256 _proposalId) external {
    eboCore.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Disputed
      })
    });

    eboCore.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    // When the pledges for and against are zero
    vm.warp(block.timestamp + parameters.pledgeWindow);

    // It should emit the DisputeResolved event
    vm.expectEmit();
    emit IResolutionManager.DisputeResolved(_proposalId, IEBOStorage.ProposalStatus.NoResolution);

    eboCore.resolve(_proposalId);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboCore.proposals(_proposalId);

    // It should unbond the disputer
    assertEq(eboCore.bonds(disputer), 0);

    // It should unbond the proposer
    assertEq(eboCore.bonds(proposer), 0);

    // It should set the proposal status to NoResolution
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.NoResolution));
  }

  function test_ResolveByPledges_WhenTheResolutionStatusIsDisputerWonAndTheMinThawingPeriodHasNotPassed(uint256 _proposalId)
    external
  {
    eboCore.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Disputed
      })
    });

    eboCore.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    // When the resolution status is DisputerWon
    eboCore.setPledgesForDisputeForTest(_proposalId, pledgerFor, 2);
    eboCore.setPledgesAgainstDisputeForTest(_proposalId, pledgerAgainst, 1);

    // It should slash the pledgers `against` the dispute
    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(
        IHorizonStaking.slash.selector,
        pledgerAgainst,
        parameters.pledgeBondSize,
        parameters.pledgeBondSize,
        address(eboCore)
      ),
      ''
    );

    // It should slash the proposer and pay the disputer
    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(
        IHorizonStaking.slash.selector, proposer, parameters.proposalBondSize, parameters.proposalBondSize, disputer
      ),
      ''
    );

    // It should emit the DisputeResolved event with the DisputerWon status
    vm.expectEmit();
    emit IResolutionManager.DisputeResolved(_proposalId, IEBOStorage.ProposalStatus.DisputerWon);

    // When the min thawing period has not passed
    vm.warp(block.timestamp + parameters.pledgeWindow);

    vm.prank(arbitrator);
    eboCore.resolve(_proposalId);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboCore.proposals(_proposalId);

    (,,,,, uint256 _rewardPerWinningPledge) = eboCore.disputes(_proposalId);

    // It should unbond the disputer
    assertEq(eboCore.bonds(disputer), 0);

    // It should unbond the proposer
    assertEq(eboCore.bonds(proposer), 0);

    // It should unbond the pledgers `for` the dispute
    assertEq(eboCore.bonds(pledgerFor), 0);

    // It should unbond the pledgers `against` the dispute
    assertEq(eboCore.bonds(pledgerAgainst), 0);

    // It should set the proposal status to DisputerWon
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.DisputerWon));

    // It should set the dispute reward per winning pledge
    assertEq(_rewardPerWinningPledge, parameters.pledgeBondSize / 2);
  }

  function test_ResolveByPledges_WhenTheResolutionStatusIsDisputerLostAndTheMinThawingPeriodHasNotPassed(uint256 _proposalId)
    external
  {
    eboCore.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Disputed
      })
    });

    eboCore.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    // When the resolution status is DisputerLost
    eboCore.setPledgesForDisputeForTest(_proposalId, pledgerFor, 1);
    eboCore.setPledgesAgainstDisputeForTest(_proposalId, pledgerAgainst, 2);

    // It should slash the pledgers `for` the dispute
    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(
        IHorizonStaking.slash.selector,
        pledgerFor,
        parameters.pledgeBondSize,
        parameters.pledgeBondSize,
        address(eboCore)
      ),
      ''
    );

    // It should slash the disputer and pay the proposer
    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(
        IHorizonStaking.slash.selector, disputer, parameters.proposalBondSize, parameters.proposalBondSize, proposer
      ),
      ''
    );

    // It should emit the DisputeResolved event
    vm.expectEmit();
    emit IResolutionManager.DisputeResolved(_proposalId, IEBOStorage.ProposalStatus.DisputerLost);

    // When the min thawing period has not passed
    vm.warp(block.timestamp + parameters.pledgeWindow);

    vm.prank(arbitrator);

    eboCore.resolve(_proposalId);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboCore.proposals(_proposalId);

    (,,,,, uint256 _rewardPerWinningPledge) = eboCore.disputes(_proposalId);

    // It should unbond the disputer
    assertEq(eboCore.bonds(disputer), 0);

    // It should unbond the proposer
    assertEq(eboCore.bonds(proposer), 0);

    // It should unbond the pledgers `for` the dispute
    assertEq(eboCore.bonds(pledgerFor), 0);

    // It should unbond the pledgers `against` the dispute
    assertEq(eboCore.bonds(pledgerAgainst), 0);

    // It should set the proposal status to DisputerLost
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.DisputerLost));

    // It should set the dispute reward per winning pledge
    assertEq(_rewardPerWinningPledge, parameters.pledgeBondSize / 2);
  }

  function test_ResolveByPledges_WhenTheResolutionStatusIsDisputerWonAndTheMinThawingPeriodHasPassed(uint256 _proposalId)
    external
  {
    eboCore.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Disputed
      })
    });

    eboCore.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    eboCore.setPledgesForDisputeForTest(_proposalId, pledgerFor, 2);
    eboCore.setPledgesAgainstDisputeForTest(_proposalId, pledgerAgainst, 1);

    // It should emit the DisputeResolved event with the NoResolution status
    vm.expectEmit();
    emit IResolutionManager.DisputeResolved(_proposalId, IEBOStorage.ProposalStatus.NoResolution);

    // Min thawing period has passed
    vm.warp(block.timestamp + parameters.minThawingPeriod + 1);

    vm.prank(arbitrator);

    // When the resolution status is DisputerWon and the min thawing period has passed
    eboCore.resolve(_proposalId);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboCore.proposals(_proposalId);

    // It should unbond the disputer
    assertEq(eboCore.bonds(disputer), 0);

    // It should unbond the proposer
    assertEq(eboCore.bonds(proposer), 0);

    // It should unbond the pledgers `for` the dispute
    assertEq(eboCore.bonds(pledgerFor), 0);

    // It should unbond the pledgers `against` the dispute
    assertEq(eboCore.bonds(pledgerAgainst), 0);

    // It should set the proposal status to NoResolution
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.NoResolution));
  }

  function test_ResolveByPledges_WhenTheResolutionStatusIsDisputerLostAndTheMinThawingPeriodHasPassed(uint256 _proposalId)
    external
  {
    eboCore.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Disputed
      })
    });

    eboCore.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    eboCore.setPledgesForDisputeForTest(_proposalId, pledgerFor, 1);
    eboCore.setPledgesAgainstDisputeForTest(_proposalId, pledgerAgainst, 2);

    // It should emit the DisputeResolved event with the NoResolution status
    vm.expectEmit();
    emit IResolutionManager.DisputeResolved(_proposalId, IEBOStorage.ProposalStatus.NoResolution);

    // Min thawing period has passed
    vm.warp(block.timestamp + parameters.minThawingPeriod + 1);

    vm.prank(arbitrator);

    // When the resolution status is DisputerLost and the min thawing period has passed
    eboCore.resolve(_proposalId);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboCore.proposals(_proposalId);

    // It should unbond the disputer
    assertEq(eboCore.bonds(disputer), 0);

    // It should unbond the proposer
    assertEq(eboCore.bonds(proposer), 0);

    // It should unbond the pledgers `for` the dispute
    assertEq(eboCore.bonds(pledgerFor), 0);

    // It should unbond the pledgers `against` the dispute
    assertEq(eboCore.bonds(pledgerAgainst), 0);

    // It should set the proposal status to NoResolution
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.NoResolution));
  }

  function test_ResolveByArbitration_RevertWhen_TheCallerIsNotTheArbitrator(uint256 _proposalId) external {
    // When the caller is not the arbitrator
    vm.prank(notProtocolActor);

    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyArbitrator_NotArbitrator.selector);
    eboCore.resolve(_proposalId, IEBOStorage.ProposalStatus.None);
  }

  function test_ResolveByArbitration_RevertWhen_TheProposalStatusIsNotEscalated(
    uint256 _proposalId,
    uint8 _status
  ) external {
    _status = uint8(bound(uint256(_status), 0, uint256(type(IEBOStorage.ProposalStatus).max)));

    // When the proposal status is not escalated
    vm.assume(_status != uint8(IEBOStorage.ProposalStatus.Escalated));

    vm.prank(arbitrator);

    // It should revert
    vm.expectRevert(IEBOCore.EBOCore_Resolve_DisputeNotEscalated.selector);
    eboCore.resolve(_proposalId, IEBOStorage.ProposalStatus(_status));
  }

  function test_ResolveByArbitration_RevertWhen_TheStatusIsNotAValidDisputeResolutionStatus(
    uint256 _proposalId,
    uint8 _invalidResolutionStatus
  ) external {
    _invalidResolutionStatus = uint8(
      bound(uint256(_invalidResolutionStatus), 0, uint256(type(IEBOStorage.ProposalStatus).max))
    );

    // When the status is not a valid dispute resolution status
    vm.assume(
      _invalidResolutionStatus != uint8(IEBOStorage.ProposalStatus.NoResolution)
        && _invalidResolutionStatus != uint8(IEBOStorage.ProposalStatus.DisputerWon)
        && _invalidResolutionStatus != uint8(IEBOStorage.ProposalStatus.DisputerLost)
    );

    eboCore.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Escalated
      })
    });

    vm.prank(arbitrator);

    // It should revert
    vm.expectRevert(IEBOCore.EBOCore_Resolve_InvalidStatus.selector);
    eboCore.resolve(_proposalId, IEBOStorage.ProposalStatus(_invalidResolutionStatus));
  }

  function test_ResolveByArbitration_WhenTheResolutionStatusIsDisputerWonAndTheMinThawingPeriodHasNotPassed(uint256 _proposalId)
    external
  {
    eboCore.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    eboCore.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Escalated
      })
    });

    eboCore.setPledgesForDisputeForTest(_proposalId, pledgerFor, 2);
    eboCore.setPledgesAgainstDisputeForTest(_proposalId, pledgerAgainst, 1);

    // It should slash the pledgers `against` the dispute
    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(
        IHorizonStaking.slash.selector,
        pledgerAgainst,
        parameters.pledgeBondSize,
        parameters.pledgeBondSize,
        address(eboCore)
      ),
      ''
    );

    // It should slash the proposer and pay the disputer
    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(
        IHorizonStaking.slash.selector, proposer, parameters.proposalBondSize, parameters.proposalBondSize, disputer
      ),
      ''
    );

    // It should emit the DisputeResolved event with the DisputerWon status
    vm.expectEmit();
    emit IResolutionManager.DisputeResolved(_proposalId, IEBOStorage.ProposalStatus.DisputerWon);

    vm.prank(arbitrator);
    // When the resolution status is DisputerWon and the min thawing period has not passed
    eboCore.resolve(_proposalId, IEBOStorage.ProposalStatus.DisputerWon);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboCore.proposals(_proposalId);

    (,,,,, uint256 _rewardPerWinningPledge) = eboCore.disputes(_proposalId);

    // It should unbond the disputer
    assertEq(eboCore.bonds(disputer), 0);

    // It should unbond the proposer
    assertEq(eboCore.bonds(proposer), 0);

    // It should unbond the pledgers `for` the dispute
    assertEq(eboCore.bonds(pledgerFor), 0);

    // It should unbond the pledgers `against` the dispute
    assertEq(eboCore.bonds(pledgerAgainst), 0);

    // It should set the proposal status to DisputerWon
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.DisputerWon));

    // It should set the dispute reward per winning pledge
    assertEq(_rewardPerWinningPledge, parameters.pledgeBondSize / 2);
  }

  function test_ResolveByArbitration_WhenTheResolutionStatusIsDisputerLostAndTheMinThawingPeriodHasNotPassed(uint256 _proposalId)
    external
  {
    eboCore.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    eboCore.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Escalated
      })
    });

    eboCore.setPledgesForDisputeForTest(_proposalId, pledgerFor, 1);
    eboCore.setPledgesAgainstDisputeForTest(_proposalId, pledgerAgainst, 2);

    // It should slash the pledgers `for` the dispute
    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(
        IHorizonStaking.slash.selector,
        pledgerFor,
        parameters.pledgeBondSize,
        parameters.pledgeBondSize,
        address(eboCore)
      ),
      ''
    );

    // It should slash the disputer and pay the proposer
    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(
        IHorizonStaking.slash.selector, disputer, parameters.proposalBondSize, parameters.proposalBondSize, proposer
      ),
      ''
    );

    // It should emit the DisputeResolved event
    vm.expectEmit();
    emit IResolutionManager.DisputeResolved(_proposalId, IEBOStorage.ProposalStatus.DisputerLost);

    vm.prank(arbitrator);

    // When the resolution status is DisputerLost and the min thawing period has not passed
    eboCore.resolve(_proposalId, IEBOStorage.ProposalStatus.DisputerLost);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboCore.proposals(_proposalId);

    (,,,,, uint256 _rewardPerWinningPledge) = eboCore.disputes(_proposalId);

    // It should unbond the disputer
    assertEq(eboCore.bonds(disputer), 0);

    // It should unbond the proposer
    assertEq(eboCore.bonds(proposer), 0);

    // It should unbond the pledgers `for` the dispute
    assertEq(eboCore.bonds(pledgerFor), 0);

    // It should unbond the pledgers `against` the dispute
    assertEq(eboCore.bonds(pledgerAgainst), 0);

    // It should set the proposal status to DisputerLost
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.DisputerLost));

    // It should set the dispute reward per winning pledge
    assertEq(_rewardPerWinningPledge, parameters.pledgeBondSize / 2);
  }

  function test_ResolveByArbitration_WhenTheResolutionStatusIsDisputerWonAndTheMinThawingPeriodHasPassed(uint256 _proposalId)
    external
  {
    eboCore.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    eboCore.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Escalated
      })
    });

    eboCore.setPledgesForDisputeForTest(_proposalId, pledgerFor, 2);
    eboCore.setPledgesAgainstDisputeForTest(_proposalId, pledgerAgainst, 1);

    // It should emit the DisputeResolved event with the NoResolution status
    vm.expectEmit();
    emit IResolutionManager.DisputeResolved(_proposalId, IEBOStorage.ProposalStatus.NoResolution);

    // Min thawing period has passed
    vm.warp(block.timestamp + parameters.minThawingPeriod + 1);

    vm.prank(arbitrator);

    // When the resolution status is DisputerWon and the min thawing period has passed
    eboCore.resolve(_proposalId, IEBOStorage.ProposalStatus.DisputerWon);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboCore.proposals(_proposalId);

    // It should unbond the disputer
    assertEq(eboCore.bonds(disputer), 0);

    // It should unbond the proposer
    assertEq(eboCore.bonds(proposer), 0);

    // It should unbond the pledgers `for` the dispute
    assertEq(eboCore.bonds(pledgerFor), 0);

    // It should unbond the pledgers `against` the dispute
    assertEq(eboCore.bonds(pledgerAgainst), 0);

    // It should set the proposal status to NoResolution
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.NoResolution));
  }

  function test_ResolveByArbitration_WhenTheResolutionStatusIsDisputerLostAndTheMinThawingPeriodHasPassed(uint256 _proposalId)
    external
  {
    eboCore.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    eboCore.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Escalated
      })
    });

    eboCore.setPledgesForDisputeForTest(_proposalId, pledgerFor, 1);
    eboCore.setPledgesAgainstDisputeForTest(_proposalId, pledgerAgainst, 2);

    // It should emit the DisputeResolved event with the NoResolution status
    vm.expectEmit();
    emit IResolutionManager.DisputeResolved(_proposalId, IEBOStorage.ProposalStatus.NoResolution);

    // Min thawing period has passed
    vm.warp(block.timestamp + parameters.minThawingPeriod + 1);

    vm.prank(arbitrator);

    // When the resolution status is DisputerLost and the min thawing period has passed
    eboCore.resolve(_proposalId, IEBOStorage.ProposalStatus.DisputerLost);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboCore.proposals(_proposalId);

    // It should unbond the disputer
    assertEq(eboCore.bonds(disputer), 0);

    // It should unbond the proposer
    assertEq(eboCore.bonds(proposer), 0);

    // It should unbond the pledgers `for` the dispute
    assertEq(eboCore.bonds(pledgerFor), 0);

    // It should unbond the pledgers `against` the dispute
    assertEq(eboCore.bonds(pledgerAgainst), 0);

    // It should set the proposal status to NoResolution
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.NoResolution));
  }

  function test_ResolveByArbitration_WhenTheResolutionStatusIsNoResolution(uint256 _proposalId) external {
    eboCore.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    eboCore.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Escalated
      })
    });

    eboCore.setPledgesForDisputeForTest(_proposalId, pledgerFor, 1);
    eboCore.setPledgesAgainstDisputeForTest(_proposalId, pledgerAgainst, 2);

    // It should emit the DisputeResolved event with the NoResolution status
    vm.expectEmit();
    emit IResolutionManager.DisputeResolved(_proposalId, IEBOStorage.ProposalStatus.NoResolution);

    // Min thawing period has passed
    vm.warp(block.timestamp + parameters.minThawingPeriod);

    vm.prank(arbitrator);

    // When the resolution status is NoResolution
    eboCore.resolve(_proposalId, IEBOStorage.ProposalStatus.NoResolution);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboCore.proposals(_proposalId);

    // It should unbond the disputer
    assertEq(eboCore.bonds(disputer), 0);

    // It should unbond the proposer
    assertEq(eboCore.bonds(proposer), 0);

    // It should unbond the pledgers `for` the dispute
    assertEq(eboCore.bonds(pledgerFor), 0);

    // It should unbond the pledgers `against` the dispute
    assertEq(eboCore.bonds(pledgerAgainst), 0);

    // It should set the proposal status to NoResolution
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.NoResolution));
  }

  function test_Finalize_RevertWhen_TheProposalIsNotActive(uint256 _proposalId) external {
    // When the proposal is not active

    // It should revert
    vm.expectRevert(IEBOCore.EBOCore_Finalize_ProposalNotActive.selector);
    eboCore.finalize(_proposalId);
  }

  function test_Finalize_RevertWhen_TheDisputeWindowHasNotPassed(uint256 _proposalId, uint256 _disputeWindow) external {
    _disputeWindow = bound(_disputeWindow, block.timestamp + 1, type(uint128).max);

    // When the dispute window has not passed
    eboCore.setParametersForTest({
      _snapshotId: 0,
      _parameters: IEBOStorage.Parameters({
        proposalBondSize: 0,
        pledgeBondSize: 0,
        minThawingPeriod: 0,
        disputeWindow: _disputeWindow,
        pledgeWindow: 0,
        pledgeRefreshWindow: 0,
        maxNumberOfPledges: 0
      })
    });

    eboCore.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Active
      })
    });

    // It should revert
    vm.expectRevert(IEBOCore.EBOCore_Finalize_DisputeWindowNotOver.selector);
    eboCore.finalize(_proposalId);
  }

  function test_Finalize_WhenAllThePreconditionsAreMet(
    uint256 _proposalId,
    uint64 _epoch,
    string memory _chainId,
    uint256 _blockNumber
  ) external {
    eboCore.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: _epoch,
        chainId: _chainId,
        blockNumber: _blockNumber,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Active
      })
    });

    vm.warp(block.timestamp + parameters.disputeWindow);

    // It should emit the ProposalFinalized event
    vm.expectEmit();
    emit IEBOCore.ProposalFinalized(_proposalId, _epoch, _chainId, _blockNumber);

    eboCore.finalize(_proposalId);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboCore.proposals(_proposalId);

    // It should set the proposal status to Finalized
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.Finalized));

    // It should unbond the proposer bond
    assertEq(eboCore.bonds(proposer), 0);
  }

  function test_AmendEpochBlock_RevertWhen_TheCallerIsNotTheArbitrator(
    uint256 _proposalId,
    uint256 _blockNumber
  ) external {
    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyArbitrator_NotArbitrator.selector);
    eboCore.amendEpochBlock(_proposalId, _blockNumber);
  }

  modifier givenTheCallerIsTheArbitrator() {
    vm.startPrank(arbitrator);
    _;
  }

  function test_AmendEpochBlock_RevertWhen_TheProposalIsNotFinalized(
    uint256 _proposalId,
    uint256 _blockNumber
  ) external givenTheCallerIsTheArbitrator {
    // When the proposal is not finalized
    // It should revert
    vm.expectRevert(IEBOCore.EBOCore_AmendEpochBlock_ProposalNotFinalized.selector);
    eboCore.amendEpochBlock(_proposalId, _blockNumber);
  }

  function test_AmendEpochBlock_WhenTheProposalIsFinalized(
    uint256 _proposalId,
    uint256 _epoch,
    string memory _chainId,
    uint256 _oldBlockNumber,
    uint256 _newBlockNumber
  ) external givenTheCallerIsTheArbitrator {
    // When the proposal is finalized
    eboCore.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: _epoch,
        chainId: _chainId,
        blockNumber: _oldBlockNumber,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.Finalized
      })
    });

    // It should emit the ProposalAmended event
    vm.expectEmit();
    emit IEBOCore.ProposalAmended(_proposalId, _epoch, _chainId, _newBlockNumber);

    eboCore.amendEpochBlock(_proposalId, _newBlockNumber);

    IEBOStorage.Proposal memory _proposal;
    (
      _proposal.epoch,
      _proposal.chainId,
      _proposal.blockNumber,
      _proposal.proposer,
      _proposal.createdAt,
      _proposal.parametersSnapshotId,
      _proposal.status
    ) = eboCore.proposals(_proposalId);

    // It should update the block number of the proposal
    assertEq(_proposal.epoch, _epoch);
    assertEq(_proposal.chainId, _chainId);
    assertEq(_proposal.blockNumber, _newBlockNumber);
    assertEq(_proposal.proposer, proposer);
    assertEq(_proposal.createdAt, block.timestamp);
    assertEq(_proposal.parametersSnapshotId, 0);
    assertEq(uint8(_proposal.status), uint8(IEBOStorage.ProposalStatus.Finalized));
  }
}

contract EBOCoreForTest is EBOCore, EBOStorageHelper {}
