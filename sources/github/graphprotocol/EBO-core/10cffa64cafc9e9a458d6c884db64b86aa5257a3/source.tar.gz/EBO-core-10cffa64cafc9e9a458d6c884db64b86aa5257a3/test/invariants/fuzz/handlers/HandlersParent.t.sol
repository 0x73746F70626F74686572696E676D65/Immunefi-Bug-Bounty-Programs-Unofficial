// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {HandlersEbo} from './HandlersEbo.t.sol';
import {HandlersHorizon} from './HandlersHorizon.t.sol';

contract HandlersParent is HandlersHorizon, HandlersEbo {}
