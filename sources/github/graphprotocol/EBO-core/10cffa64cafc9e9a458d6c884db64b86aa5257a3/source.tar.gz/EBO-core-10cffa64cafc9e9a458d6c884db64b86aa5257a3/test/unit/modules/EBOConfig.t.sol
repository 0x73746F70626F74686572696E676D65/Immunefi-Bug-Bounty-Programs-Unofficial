// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {EBOConfig, IEBOConfig, IERC20, IEpochManager, IHorizonStaking} from 'contracts/modules/EBOConfig.sol';

import {IAccessManager} from 'interfaces/common/IAccessManager.sol';
import {IEBOStorage} from 'interfaces/common/IEBOStorage.sol';
import {EBOStorageHelper} from 'test/utils/EBOStorageHelper.t.sol';

import {EBOTestHelpers} from 'test/utils/EBOTestHelpers.t.sol';

/**
 * @title EBOConfig unit tests
 */
contract EBOConfigUnit is EBOTestHelpers {
  // Contracts
  EBOConfigForTest public eboConfig;

  // Variables
  mapping(bytes32 _encodedChainId => bool _allowed) internal _chainIdsAllowedForTest;

  function setUp() public override {
    super.setUp();
    eboConfig = new EBOConfigForTest();

    // Set up the contract storage
    eboConfig.setArbitratorForTest(arbitrator);
    eboConfig.setCouncilForTest(council);
    eboConfig.setPendingCouncilForTest(pendingCouncil);
    eboConfig.setGRTForTest(IERC20(grt));
    eboConfig.setHorizonStakingForTest(IHorizonStaking(horizonStaking));
    eboConfig.setEpochManagerForTest(IEpochManager(epochManager));
  }

  function test_SetArbitrator_RevertWhen_TheCallerIsNotTheCouncil() external {
    // When the caller is not the council
    vm.prank(notProtocolActor);

    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);
    eboConfig.setArbitrator(arbitrator);
  }

  modifier givenTheCallerIsTheCouncil() {
    vm.startPrank(council);
    _;
  }

  function test_SetArbitrator_RevertWhen_TheAddressIsAlreadySet() external givenTheCallerIsTheCouncil {
    // When the address is already set

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_SetArbitrator_AddressAlreadySet.selector);
    eboConfig.setArbitrator(arbitrator);
  }

  function test_SetArbitrator_WhenTheAddressIsNotSet(address _newArbitrator) external givenTheCallerIsTheCouncil {
    // When the address is not set
    vm.assume(_newArbitrator != arbitrator);

    // It should emit the ArbitratorSet event
    vm.expectEmit();
    emit IEBOConfig.ArbitratorSet(_newArbitrator);

    eboConfig.setArbitrator(_newArbitrator);

    // It should set the arbitrator
    assertEq(eboConfig.arbitrator(), _newArbitrator);
  }

  function test_SetPendingCouncil_RevertWhen_TheCallerIsNotTheCouncil() external {
    // When the caller is not the council
    vm.prank(notProtocolActor);

    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);
    eboConfig.setPendingCouncil(pendingCouncil);
  }

  function test_SetPendingCouncil_RevertWhen_TheAddressIsAlreadySet() external givenTheCallerIsTheCouncil {
    // When the address is already set

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_SetPendingCouncil_AddressAlreadySet.selector);
    eboConfig.setPendingCouncil(pendingCouncil);
  }

  function test_SetPendingCouncil_WhenTheAddressIsNotSet(address _newPendingCouncil)
    external
    givenTheCallerIsTheCouncil
  {
    // When the address is not set
    vm.assume(_newPendingCouncil != pendingCouncil);

    // It should emit the PendingCouncilSet event
    vm.expectEmit();
    emit IEBOConfig.PendingCouncilSet(_newPendingCouncil);

    eboConfig.setPendingCouncil(_newPendingCouncil);

    // It should set the pending council
    assertEq(eboConfig.pendingCouncil(), _newPendingCouncil);
  }

  function test_ConfirmCouncil_RevertWhen_TheCallerIsNotThePendingCouncil() external {
    // When the caller is not the pending council
    vm.prank(notProtocolActor);

    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyPendingCouncil_NotPendingCouncil.selector);
    eboConfig.confirmCouncil();
  }

  modifier givenTheCallerIsThePendingCouncil() {
    vm.startPrank(pendingCouncil);
    _;
  }

  function test_ConfirmCouncil_RevertWhen_TheAddressIsAlreadySet() external givenTheCallerIsThePendingCouncil {
    // When the address is already set
    eboConfig.setCouncilForTest(pendingCouncil);

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_SetCouncil_AddressAlreadySet.selector);
    eboConfig.confirmCouncil();
  }

  function test_ConfirmCouncil_WhenTheAddressIsNotSet() external givenTheCallerIsThePendingCouncil {
    // When the address is not set
    vm.assume(pendingCouncil != council);

    // It should emit the CouncilSet event
    vm.expectEmit();
    emit IEBOConfig.CouncilSet(pendingCouncil);

    // It should emit the PendingCouncilSet event
    vm.expectEmit();
    emit IEBOConfig.PendingCouncilSet(address(0));

    eboConfig.confirmCouncil();

    // It should set the council
    assertEq(eboConfig.council(), pendingCouncil);

    // It should set the pending council to the zero address
    assertEq(eboConfig.pendingCouncil(), address(0));
  }

  function test_SetGRT_RevertWhen_TheCallerIsNotTheCouncil(IERC20 _newGRT) external {
    // When the caller is not the council
    vm.prank(notProtocolActor);

    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);
    eboConfig.setGRT(_newGRT);
  }

  function test_SetGRT_RevertWhen_TheAddressIsAlreadySet() external givenTheCallerIsTheCouncil {
    // When the address is already set

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_SetGRT_AddressAlreadySet.selector);
    eboConfig.setGRT(IERC20(grt));
  }

  function test_SetGRT_WhenTheAddressIsNotSet(IERC20 _newGRT) external givenTheCallerIsTheCouncil {
    // When the address is not set
    vm.assume(address(_newGRT) != address(eboConfig.grt()));

    // It should emit the GRTSet event
    vm.expectEmit();
    emit IEBOConfig.GRTSet(_newGRT);

    eboConfig.setGRT(_newGRT);

    // It should set the GRT contract
    assertEq(address(eboConfig.grt()), address(_newGRT));
  }

  function test_SetHorizonStaking_RevertWhen_TheCallerIsNotTheCouncil(IHorizonStaking _newHorizonStaking) external {
    // When the caller is not the council
    vm.prank(notProtocolActor);

    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);
    eboConfig.setHorizonStaking(_newHorizonStaking);
  }

  function test_SetHorizonStaking_RevertWhen_TheAddressIsAlreadySet() external givenTheCallerIsTheCouncil {
    // When the address is already set

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_SetHorizonStaking_AddressAlreadySet.selector);
    eboConfig.setHorizonStaking(IHorizonStaking(horizonStaking));
  }

  function test_SetHorizonStaking_WhenTheAddressIsNotSet(IHorizonStaking _newHorizonStaking)
    external
    givenTheCallerIsTheCouncil
  {
    // When the address is not set
    vm.assume(address(_newHorizonStaking) != address(eboConfig.horizonStaking()));

    // It should emit the HorizonStakingSet event
    vm.expectEmit();
    emit IEBOConfig.HorizonStakingSet(_newHorizonStaking);

    eboConfig.setHorizonStaking(_newHorizonStaking);

    // It should set the HorizonStaking contract
    assertEq(address(eboConfig.horizonStaking()), address(_newHorizonStaking));
  }

  function test_SetEpochManager_RevertWhen_TheCallerIsNotTheCouncil(IEpochManager _newEpochManager) external {
    // When the caller is not the council
    vm.prank(notProtocolActor);

    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);
    eboConfig.setEpochManager(_newEpochManager);
  }

  function test_SetEpochManager_RevertWhen_TheAddressIsAlreadySet() external givenTheCallerIsTheCouncil {
    // When the address is already set

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_SetEpochManager_AddressAlreadySet.selector);
    eboConfig.setEpochManager(IEpochManager(epochManager));
  }

  function test_SetEpochManager_WhenTheAddressIsNotSet(IEpochManager _newEpochManager)
    external
    givenTheCallerIsTheCouncil
  {
    // When the address is not set
    vm.assume(address(_newEpochManager) != address(eboConfig.epochManager()));

    // It should emit the EpochManagerSet event
    vm.expectEmit();
    emit IEBOConfig.EpochManagerSet(_newEpochManager);

    eboConfig.setEpochManager(_newEpochManager);

    // It should set the EpochManager contract
    assertEq(address(eboConfig.epochManager()), address(_newEpochManager));
  }

  function test_AddChainIds_RevertWhen_TheCallerIsNotTheCouncil() external {
    // When the caller is not the council
    vm.prank(notProtocolActor);

    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);
    eboConfig.addChainIds(new string[](0));
  }

  function test_AddChainIds_RevertWhen_TheChainIdIsAlreadyAdded(string memory _chainId)
    external
    givenTheCallerIsTheCouncil
  {
    // When the chain id is already added
    string[] memory _chainIds = new string[](1);
    _chainIds[0] = _chainId;

    eboConfig.addChainIds(_chainIds);

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_AddChainIds_ChainIdAlreadyAdded.selector);
    eboConfig.addChainIds(_chainIds);
  }

  function test_AddChainIds_WhenTheChainIdIsNotAdded(string memory _chainId) external givenTheCallerIsTheCouncil {
    // When the chain id is not added
    string[] memory _chainIds = new string[](1);
    _chainIds[0] = _chainId;

    // It should emit the ChainIdAdded event
    vm.expectEmit();
    emit IEBOConfig.ChainIdAdded(_chainId);

    eboConfig.addChainIds(_chainIds);

    // It should set the chain id as allowed
    assertEq(eboConfig.chainIdsAllowed(_chainId), true);
  }

  function test_RemoveChainIds_RevertWhen_TheCallerIsNotTheCouncil() external {
    // When the caller is not the council
    vm.prank(notProtocolActor);

    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);
    eboConfig.removeChainIds(new string[](0));
  }

  function test_RemoveChainIds_RevertWhen_TheChainIdIsNotAdded(string memory _chainId)
    external
    givenTheCallerIsTheCouncil
  {
    // When the chain id is not added
    string[] memory _chainIds = new string[](1);
    _chainIds[0] = _chainId;

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_RemoveChainIds_ChainIdNotAdded.selector);
    eboConfig.removeChainIds(_chainIds);
  }

  function test_RemoveChainIds_WhenTheChainIdIsAdded(string memory _chainId) external givenTheCallerIsTheCouncil {
    // When the chain id is added
    string[] memory _chainIds = new string[](1);
    _chainIds[0] = _chainId;

    eboConfig.addChainIds(_chainIds);

    // It should emit the ChainIdRemoved event
    vm.expectEmit();
    emit IEBOConfig.ChainIdRemoved(_chainId);

    eboConfig.removeChainIds(_chainIds);

    // It should set the chain id as not allowed
    assertEq(eboConfig.chainIdsAllowed(_chainId), false);
  }

  function test_SetParameters_RevertWhen_TheCallerIsNotTheCouncil() external {
    // When the caller is not the council
    vm.prank(notProtocolActor);

    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);

    eboConfig.setParameters({
      _parameters: IEBOStorage.Parameters({
        proposalBondSize: 0,
        pledgeBondSize: 0,
        minThawingPeriod: 0,
        disputeWindow: 0,
        pledgeWindow: 0,
        pledgeRefreshWindow: 0,
        maxNumberOfPledges: 0
      }),
      _arbitratorResolutionWindow: 0
    });
  }

  function test_SetParameters_RevertWhen_TheProposalBondSizeIsZero() external givenTheCallerIsTheCouncil {
    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_ParametersCannotBeZero.selector);

    // When the proposal bond size is zero
    eboConfig.setParameters(
      IEBOStorage.Parameters({
        proposalBondSize: 0,
        pledgeBondSize: 1,
        minThawingPeriod: 1,
        disputeWindow: 1,
        pledgeWindow: 1,
        pledgeRefreshWindow: 1,
        maxNumberOfPledges: 1
      }),
      1
    );
  }

  function test_SetParameters_RevertWhen_ThePledgeBondSizeIsZero() external givenTheCallerIsTheCouncil {
    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_ParametersCannotBeZero.selector);

    // When the pledge bond size is zero
    eboConfig.setParameters({
      _parameters: IEBOStorage.Parameters({
        proposalBondSize: 1,
        pledgeBondSize: 0,
        minThawingPeriod: 1,
        disputeWindow: 1,
        pledgeWindow: 1,
        pledgeRefreshWindow: 1,
        maxNumberOfPledges: 1
      }),
      _arbitratorResolutionWindow: 1
    });
  }

  function test_SetParameters_RevertWhen_TheDisputeWindowIsZero() external givenTheCallerIsTheCouncil {
    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_ParametersCannotBeZero.selector);

    // When the dispute window is zero
    eboConfig.setParameters({
      _parameters: IEBOStorage.Parameters({
        proposalBondSize: 1,
        pledgeBondSize: 1,
        minThawingPeriod: 1,
        disputeWindow: 0,
        pledgeWindow: 1,
        pledgeRefreshWindow: 1,
        maxNumberOfPledges: 1
      }),
      _arbitratorResolutionWindow: 1
    });
  }

  function test_SetParameters_RevertWhen_ThePledgeRefreshWindowIsZero() external givenTheCallerIsTheCouncil {
    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_ParametersCannotBeZero.selector);

    // When the pledge refresh window is zero
    eboConfig.setParameters({
      _parameters: IEBOStorage.Parameters({
        proposalBondSize: 1,
        pledgeBondSize: 1,
        minThawingPeriod: 1,
        disputeWindow: 1,
        pledgeWindow: 1,
        pledgeRefreshWindow: 0,
        maxNumberOfPledges: 1
      }),
      _arbitratorResolutionWindow: 1
    });
  }

  function test_SetParameters_RevertWhen_TheArbitratorResolutionWindowIsZero() external givenTheCallerIsTheCouncil {
    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_ParametersCannotBeZero.selector);

    // When the arbitrator resolution window is zero
    eboConfig.setParameters({
      _parameters: IEBOStorage.Parameters({
        proposalBondSize: 1,
        pledgeBondSize: 1,
        minThawingPeriod: 1,
        disputeWindow: 1,
        pledgeWindow: 1,
        pledgeRefreshWindow: 1,
        maxNumberOfPledges: 1
      }),
      _arbitratorResolutionWindow: 0
    });
  }

  function test_SetParameters_RevertWhen_ThePledgeRefreshWindowIsGreaterThanPledgeWindow(
    uint256 _pledgeWindow,
    uint256 _pledgeRefreshWindow
  ) external givenTheCallerIsTheCouncil {
    _pledgeWindow = bound(_pledgeWindow, 1, type(uint32).max);
    _pledgeRefreshWindow = bound(_pledgeRefreshWindow, _pledgeWindow + 1, type(uint64).max);

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_PledgeRefreshWindowExceedsPledgeWindow.selector);
    eboConfig.setParameters({
      _parameters: IEBOStorage.Parameters({
        proposalBondSize: 1,
        pledgeBondSize: 1,
        minThawingPeriod: 1,
        disputeWindow: 1,
        pledgeWindow: _pledgeWindow,
        pledgeRefreshWindow: _pledgeRefreshWindow,
        maxNumberOfPledges: 1
      }),
      _arbitratorResolutionWindow: 1
    });
  }

  function test_SetParameters_RevertWhen_TheMinThawingPeriodIsTooShort(
    IEBOStorage.Parameters memory _parameters,
    uint256 _arbitratorResolutionWindow
  ) external givenTheCallerIsTheCouncil {
    _parameters.disputeWindow = bound(_parameters.disputeWindow, 1, type(uint32).max);
    _parameters.pledgeRefreshWindow = bound(_parameters.pledgeRefreshWindow, 1, type(uint32).max);
    _parameters.pledgeWindow = bound(_parameters.pledgeWindow, _parameters.pledgeRefreshWindow + 1, type(uint64).max);
    _parameters.maxNumberOfPledges = bound(_parameters.maxNumberOfPledges, 1, type(uint64).max);
    _arbitratorResolutionWindow = bound(_arbitratorResolutionWindow, 1, type(uint32).max);

    uint256 _maxProposalLifecycleDuration = _getMaxProposalLifecycleDuration(
      _parameters.disputeWindow,
      _parameters.pledgeWindow,
      _parameters.pledgeRefreshWindow,
      _parameters.maxNumberOfPledges,
      _arbitratorResolutionWindow
    );

    _parameters.minThawingPeriod = bound(_parameters.minThawingPeriod, 1, _maxProposalLifecycleDuration - 1);

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_MinThawingPeriodTooShort.selector);
    eboConfig.setParameters({
      _parameters: IEBOStorage.Parameters({
        proposalBondSize: 1,
        pledgeBondSize: 1,
        minThawingPeriod: _parameters.minThawingPeriod,
        disputeWindow: _parameters.disputeWindow,
        pledgeWindow: _parameters.pledgeWindow,
        pledgeRefreshWindow: _parameters.pledgeRefreshWindow,
        maxNumberOfPledges: _parameters.maxNumberOfPledges
      }),
      _arbitratorResolutionWindow: _arbitratorResolutionWindow
    });
  }

  function test_SetParameters_WhenAllThePreconditionsAreMet(
    IEBOStorage.Parameters memory _parameters,
    uint256 _arbitratorResolutionWindow
  ) external givenTheCallerIsTheCouncil {
    _parameters.proposalBondSize = bound(_parameters.proposalBondSize, 1, type(uint256).max);
    _parameters.pledgeBondSize = bound(_parameters.pledgeBondSize, 1, type(uint256).max);
    _parameters.disputeWindow = bound(_parameters.disputeWindow, 1, type(uint32).max);
    _parameters.pledgeRefreshWindow = bound(_parameters.pledgeRefreshWindow, 1, type(uint32).max);
    _parameters.pledgeWindow = bound(_parameters.pledgeWindow, _parameters.pledgeRefreshWindow + 1, type(uint64).max);
    _parameters.maxNumberOfPledges = bound(_parameters.maxNumberOfPledges, 1, type(uint64).max);
    _arbitratorResolutionWindow = bound(_arbitratorResolutionWindow, 1, type(uint32).max);

    uint256 _maxProposalLifecycleDuration = _getMaxProposalLifecycleDuration(
      _parameters.disputeWindow,
      _parameters.pledgeWindow,
      _parameters.pledgeRefreshWindow,
      _parameters.maxNumberOfPledges,
      _arbitratorResolutionWindow
    );

    _parameters.minThawingPeriod = bound(_parameters.minThawingPeriod, _maxProposalLifecycleDuration, type(uint128).max);

    uint256 _expectedSnapshotId = eboConfig.parametersSnapshotId() + 1;

    // It should emit the ParametersSet event
    vm.expectEmit();
    emit IEBOConfig.ParametersSet(_parameters, _expectedSnapshotId, _arbitratorResolutionWindow);

    eboConfig.setParameters(_parameters, _arbitratorResolutionWindow);

    IEBOStorage.Parameters memory _queriedParameters;
    (
      _queriedParameters.proposalBondSize,
      _queriedParameters.pledgeBondSize,
      _queriedParameters.minThawingPeriod,
      _queriedParameters.disputeWindow,
      _queriedParameters.pledgeWindow,
      _queriedParameters.pledgeRefreshWindow,
      _queriedParameters.maxNumberOfPledges
    ) = eboConfig.parametersSnapshots(_expectedSnapshotId);

    // It should set the dispute parameters and increment snapshotId
    assertEq(eboConfig.parametersSnapshotId(), _expectedSnapshotId);
    assertEq(_queriedParameters.proposalBondSize, _parameters.proposalBondSize);
    assertEq(_queriedParameters.minThawingPeriod, _parameters.minThawingPeriod);
    assertEq(_queriedParameters.pledgeBondSize, _parameters.pledgeBondSize);
    assertEq(_queriedParameters.pledgeWindow, _parameters.pledgeWindow);
    assertEq(_queriedParameters.pledgeRefreshWindow, _parameters.pledgeRefreshWindow);
    assertEq(_queriedParameters.maxNumberOfPledges, _parameters.maxNumberOfPledges);
    assertEq(_queriedParameters.disputeWindow, _parameters.disputeWindow);
  }

  function test_SetStartEpoch_WhenCalled(uint256 _newStartEpoch) external {
    // It should emit the StartEpochSet event
    vm.expectEmit();
    emit IEBOConfig.StartEpochSet(_newStartEpoch);

    eboConfig.exposed_setStartEpoch(_newStartEpoch);

    // It should set the start epoch
    assertEq(eboConfig.startEpoch(), _newStartEpoch);
  }
}

contract EBOConfigForTest is EBOConfig, EBOStorageHelper {
  function exposed_setStartEpoch(uint256 _startEpoch) external {
    _setStartEpoch(_startEpoch);
  }
}
