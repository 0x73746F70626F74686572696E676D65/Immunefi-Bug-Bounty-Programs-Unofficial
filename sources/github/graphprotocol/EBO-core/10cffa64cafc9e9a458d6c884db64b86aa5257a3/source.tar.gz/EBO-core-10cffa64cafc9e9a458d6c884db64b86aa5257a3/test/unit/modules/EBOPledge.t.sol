// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {EBOPledge, IEBOPledge} from 'contracts/modules/EBOPledge.sol';

import {IAccessManager} from 'interfaces/common/IAccessManager.sol';
import {IEBOStorage, IERC20, IHorizonStaking} from 'interfaces/common/IEBOStorage.sol';

import {EBOTestHelpers} from 'test/utils/EBOTestHelpers.t.sol';

import {EBOStorageHelper} from 'test/utils/EBOStorageHelper.t.sol';

/**
 * @title EBOPledge unit tests
 */
contract EBOPledgeUnit is EBOTestHelpers {
  // Contracts
  EBOPledgeForTest public eboPledge;

  // Variables
  IEBOStorage.Parameters public parameters;

  function setUp() public override {
    super.setUp();

    eboPledge = new EBOPledgeForTest();

    // Set up the contract storage
    eboPledge.setGRTForTest(IERC20(grt));
    eboPledge.setHorizonStakingForTest(IHorizonStaking(horizonStaking));

    parameters = IEBOStorage.Parameters({
      proposalBondSize: 15_000 ether,
      pledgeBondSize: 15_000 ether,
      minThawingPeriod: 2 weeks,
      disputeWindow: 12 hours,
      pledgeWindow: 2 days,
      pledgeRefreshWindow: 1 days,
      maxNumberOfPledges: 4
    });

    eboPledge.setParametersForTest({_snapshotId: 0, _parameters: parameters});
  }

  function test_ClaimPledgeReward_RevertWhen_TheProposalStatusIsNeitherDisputerWonNorDisputerLost(
    uint256 _proposalId,
    address _pledger,
    uint8 _status
  ) external {
    _status = uint8(bound(uint256(_status), 0, uint256(type(IEBOStorage.ProposalStatus).max)));
    vm.assume(
      _status != uint8(IEBOStorage.ProposalStatus.DisputerWon)
        && _status != uint8(IEBOStorage.ProposalStatus.DisputerLost)
    );

    // When the proposal status is neither DisputerWon nor DisputerLost
    eboPledge.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus(_status)
      })
    });

    // It should revert
    vm.expectRevert(IEBOPledge.EBOPledge_ClaimPledgeReward_DisputeHasNoResolution.selector);
    eboPledge.claimPledgeReward(_proposalId, _pledger);
  }

  function test_ClaimPledgeReward_RevertWhen_ThePledgerAlreadyClaimed(uint256 _proposalId, address _pledger) external {
    eboPledge.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.DisputerWon
      })
    });

    // When the pledger already claimed
    eboPledge.setPledgerClaimedForTest(_proposalId, _pledger, true);

    // It should revert
    vm.expectRevert(IEBOPledge.EBOPledge_ClaimPledgeReward_AlreadyClaimed.selector);
    eboPledge.claimPledgeReward(_proposalId, _pledger);
  }

  function test_ClaimPledgeReward_RevertWhen_ThereIsNoRewardToClaim(
    uint256 _proposalId,
    address _pledger,
    uint256 _forPledges
  ) external {
    _forPledges = bound(_forPledges, 1, type(uint32).max);

    eboPledge.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus.DisputerWon
      })
    });

    eboPledge.setPledgesForDisputeForTest(_proposalId, _pledger, _forPledges);

    vm.expectRevert(IEBOPledge.EBOPledge_ClaimPledgeReward_NoRewardToClaim.selector);

    eboPledge.claimPledgeReward(_proposalId, _pledger);
  }

  function test_ClaimPledgeReward_WhenAllThePreconditionsAreMetAndTheStatusIsDisputerWon(
    uint256 _proposalId,
    uint256 _forPledges,
    uint256 _againstPledges,
    uint256 _rewardPerWinningPledge
  ) external {
    _againstPledges = bound(_againstPledges, 1, type(uint32).max - 1);
    _forPledges = bound(_forPledges, _againstPledges + 1, type(uint32).max);
    _rewardPerWinningPledge = bound(_rewardPerWinningPledge, 1, type(uint128).max);

    eboPledge.setPledgesAgainstDisputeForTest(_proposalId, pledgerAgainst, _againstPledges);
    eboPledge.setPledgesForDisputeForTest(_proposalId, pledgerFor, _forPledges);

    eboPledge.setDisputeRewardPerWinningPledgeForTest(_proposalId, _rewardPerWinningPledge);
    // When all the preconditions are met and the status is DisputerWon
    eboPledge.setProposalStatusForTest(_proposalId, IEBOStorage.ProposalStatus.DisputerWon);

    uint256 _rewardAmount = _forPledges * _rewardPerWinningPledge;

    // It should transfer the reward to the winning pledger
    _mockAndExpect(
      address(grt), abi.encodeWithSelector(IERC20.transfer.selector, pledgerFor, _rewardAmount), abi.encode(true)
    );

    // It should emit the PledgeRewardClaimed event
    vm.expectEmit();
    emit IEBOPledge.PledgeRewardClaimed(_proposalId, pledgerFor, _rewardAmount);

    eboPledge.claimPledgeReward(_proposalId, pledgerFor);

    // It should update the pledger claimed mapping
    assertEq(eboPledge.pledgerClaimed(_proposalId, pledgerFor), true);
  }

  function test_ClaimPledgeReward_WhenAllThePreconditionsAreMetAndTheStatusIsDisputerLost(
    uint256 _proposalId,
    address _pledger,
    uint256 _forPledges,
    uint256 _againstPledges,
    uint256 _rewardPerWinningPledge
  ) external {
    _forPledges = bound(_forPledges, 1, type(uint32).max - 1);
    _againstPledges = bound(_againstPledges, _forPledges + 1, type(uint32).max);
    _rewardPerWinningPledge = bound(_rewardPerWinningPledge, 1, type(uint128).max);

    eboPledge.setPledgesAgainstDisputeForTest(_proposalId, _pledger, _againstPledges);
    eboPledge.setPledgesForDisputeForTest(_proposalId, _pledger, _forPledges);

    eboPledge.setDisputeRewardPerWinningPledgeForTest(_proposalId, _rewardPerWinningPledge);
    // When all the preconditions are met and the status is DisputerLost
    eboPledge.setProposalStatusForTest(_proposalId, IEBOStorage.ProposalStatus.DisputerLost);

    uint256 _rewardAmount = _againstPledges * _rewardPerWinningPledge;

    // It should transfer the reward to the winning pledger
    _mockAndExpect(
      address(grt), abi.encodeWithSelector(IERC20.transfer.selector, _pledger, _rewardAmount), abi.encode(true)
    );

    // It should emit the PledgeRewardClaimed event
    vm.expectEmit();
    emit IEBOPledge.PledgeRewardClaimed(_proposalId, _pledger, _rewardAmount);

    eboPledge.claimPledgeReward(_proposalId, _pledger);

    // It should update the pledger claimed mapping
    assertEq(eboPledge.pledgerClaimed(_proposalId, _pledger), true);
  }

  function test_PledgeForDispute_RevertWhen_TheCallerIsNotAValidOperator(uint256 _proposalId) external {
    // When the caller is not a valid operator
    _mockAndExpect(
      address(horizonStaking),
      abi.encodeWithSelector(IHorizonStaking.isAuthorized.selector, pledgerFor, address(eboPledge), notProtocolActor),
      abi.encode(false)
    );

    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyOperator_NotOperator.selector);
    vm.prank(notProtocolActor);
    eboPledge.pledgeForDispute(_proposalId, pledgerFor);
  }

  function test_PledgeForDispute_RevertWhen_TheProposalIsNotDisputed(
    uint256 _proposalId,
    address _pledger,
    uint256 _status
  ) external {
    _status = uint8(bound(uint256(_status), 0, uint256(type(IEBOStorage.ProposalStatus).max)));
    vm.assume(_status != uint8(IEBOStorage.ProposalStatus.Disputed));

    // When the proposal is not disputed
    eboPledge.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus(_status)
      })
    });

    // It should revert
    vm.expectRevert(IEBOPledge.EBOPledge_Pledge_ProposalNotDisputed.selector);

    vm.prank(_pledger);
    eboPledge.pledgeForDispute(_proposalId, _pledger);
  }

  function test_PledgeForDispute_RevertWhen_ThePledgeWindowHasPassed(uint256 _proposalId, address _pledger) external {
    eboPledge.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    // When the pledge window has passed
    vm.warp(block.timestamp + parameters.pledgeWindow);

    // It should revert
    vm.expectRevert(IEBOPledge.EBOPledge_Pledge_PledgeWindowOver.selector);
    vm.prank(_pledger);
    eboPledge.pledgeForDispute(_proposalId, _pledger);
  }

  function test_PledgeForDispute_RevertWhen_TheForSideOfTheDisputeIsWinning(
    uint256 _proposalId,
    address _pledger
  ) external {
    eboPledge.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    // When the 'for' side of the dispute is winning
    eboPledge.setDisputeTotalPledgesForTest({
      _proposalId: _proposalId, _totalPledgesForDispute: 1, _totalPledgesAgainstDispute: 0
    });

    // It should revert
    vm.expectRevert(IEBOPledge.EBOPledge_Pledge_CannotPledgeIfWinning.selector);

    vm.prank(_pledger);
    eboPledge.pledgeForDispute(_proposalId, _pledger);
  }

  function test_PledgeForDispute_WhenItIsTheFirstPledge(uint256 _proposalId) external {
    eboPledge.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    // It should bond the pledge amount
    _mockAndExpect(
      address(horizonStaking),
      abi.encodeWithSelector(IHorizonStaking.getProvision.selector, pledgerFor, address(eboPledge)),
      abi.encode(
        IHorizonStaking.Provision({
          tokens: parameters.pledgeBondSize,
          tokensThawing: 0,
          sharesThawing: 0,
          maxVerifierCut: eboPledge.MAX_MAX_VERIFIER_CUT(),
          thawingPeriod: uint64(parameters.minThawingPeriod),
          createdAt: 0,
          maxVerifierCutPending: 0,
          thawingPeriodPending: 0,
          thawingNonce: 0
        })
      )
    );

    // One pledge should be required, since it's the first pledge
    uint256 _requiredPledges = 1;
    uint256 _pledgeAmount = parameters.pledgeBondSize;

    // It should emit the PledgedForDispute event
    vm.expectEmit();
    emit IEBOPledge.PledgedForDispute(_proposalId, pledgerFor, _pledgeAmount);

    vm.prank(pledgerFor);

    // When it is the first pledge
    eboPledge.pledgeForDispute(_proposalId, pledgerFor);
    (,, uint256 _lastPledgeTimestamp, uint256 _totalPledgesForDispute, uint256 _totalPledgesAgainstDispute,) =
      eboPledge.disputes(_proposalId);

    // It should update the dispute total number of pledges `for`
    assertEq(_totalPledgesForDispute, _requiredPledges);
    assertEq(_totalPledgesAgainstDispute, 0);

    // It should update the pledger pledges number
    assertEq(eboPledge.pledgesForDispute(_proposalId, pledgerFor), _requiredPledges);

    // It should bond the pledge amount
    assertEq(eboPledge.bonds(pledgerFor), _pledgeAmount);

    // It should set the last pledge timestamp
    assertEq(_lastPledgeTimestamp, block.timestamp);

    // It should add the pledger to the dispute pledgers `for` enum
    assertTrue(_containsAddress(pledgerFor, eboPledge.pledgersForDispute(_proposalId)));
  }

  function test_PledgeForDispute_WhenItsNotTheFirstPledge(uint256 _proposalId) external {
    eboPledge.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    // Two pledges should be required to exceed the opposite side's pledges
    uint256 _requiredPledges = 2;

    // When it is not the first pledge
    eboPledge.setDisputeTotalPledgesForTest({
      _proposalId: _proposalId, _totalPledgesForDispute: 0, _totalPledgesAgainstDispute: 1
    });

    uint256 _pledgeAmount = parameters.pledgeBondSize * _requiredPledges;

    // It should bond the pledge amount
    _mockAndExpect(
      address(horizonStaking),
      abi.encodeWithSelector(IHorizonStaking.getProvision.selector, pledgerFor, address(eboPledge)),
      abi.encode(
        IHorizonStaking.Provision({
          tokens: _pledgeAmount,
          tokensThawing: 0,
          sharesThawing: 0,
          maxVerifierCut: eboPledge.MAX_MAX_VERIFIER_CUT(),
          thawingPeriod: uint64(parameters.minThawingPeriod),
          createdAt: 0,
          maxVerifierCutPending: 0,
          thawingPeriodPending: 0,
          thawingNonce: 0
        })
      )
    );

    // It should emit the PledgedForDispute event
    vm.expectEmit();
    emit IEBOPledge.PledgedForDispute(_proposalId, pledgerFor, _pledgeAmount);

    vm.prank(pledgerFor);

    // When it is not the first pledge
    eboPledge.pledgeForDispute(_proposalId, pledgerFor);

    (,, uint256 _lastPledgeTimestamp, uint256 _totalPledgesForDispute,,) = eboPledge.disputes(_proposalId);

    // It should set the last pledge timestamp
    assertEq(_lastPledgeTimestamp, block.timestamp);

    // It should add the pledger to the dispute pledgers `for` enum
    assertTrue(_containsAddress(pledgerFor, eboPledge.pledgersForDispute(_proposalId)));

    // It should update the dispute total number of pledges `for`
    assertEq(_totalPledgesForDispute, _requiredPledges);

    // It should update the pledger pledges number
    assertEq(eboPledge.pledgesForDispute(_proposalId, pledgerFor), _requiredPledges);

    // It should bond the pledge amount
    assertEq(eboPledge.bonds(pledgerFor), _pledgeAmount);
  }

  function test_PledgeForDispute_WhenTheMaxPledgeNumberIsReached(uint256 _proposalId) external {
    eboPledge.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    uint256 _totalPledgerBondedAmount = parameters.pledgeBondSize * parameters.maxNumberOfPledges;
    uint256 _lastPledgeAmount = parameters.pledgeBondSize;

    // It should bond the pledge amount
    _mockAndExpect(
      address(horizonStaking),
      abi.encodeWithSelector(IHorizonStaking.getProvision.selector, pledgerFor, address(eboPledge)),
      abi.encode(
        IHorizonStaking.Provision({
          tokens: _totalPledgerBondedAmount,
          tokensThawing: 0,
          sharesThawing: 0,
          maxVerifierCut: eboPledge.MAX_MAX_VERIFIER_CUT(),
          thawingPeriod: uint64(parameters.minThawingPeriod),
          createdAt: 0,
          maxVerifierCutPending: 0,
          thawingPeriodPending: 0,
          thawingNonce: 0
        })
      )
    );

    eboPledge.setPledgesAgainstDisputeForTest(_proposalId, pledgerAgainst, parameters.maxNumberOfPledges);
    // One pledge should be required to reach the max pledge number for the 'for' side
    eboPledge.setPledgesForDisputeForTest(_proposalId, pledgerFor, parameters.maxNumberOfPledges - 1);

    // It should emit the DisputeEscalated event
    vm.expectEmit();
    emit IEBOPledge.DisputeEscalated(_proposalId);

    // It should emit the PledgedForDispute event
    vm.expectEmit();
    emit IEBOPledge.PledgedForDispute(_proposalId, pledgerFor, _lastPledgeAmount);

    vm.prank(pledgerFor);
    eboPledge.pledgeForDispute(_proposalId, pledgerFor);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboPledge.proposals(_proposalId);
    (,, uint256 _lastPledgeTimestamp, uint256 _totalPledgesForDispute,,) = eboPledge.disputes(_proposalId);

    // It should set the last pledge timestamp
    assertEq(_lastPledgeTimestamp, block.timestamp);

    // It should set the proposal status to Escalated
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.Escalated));

    // It should update the dispute total number of pledges `for`
    assertEq(_totalPledgesForDispute, parameters.maxNumberOfPledges);

    // It should update the pledger pledges number
    assertEq(eboPledge.pledgesForDispute(_proposalId, pledgerFor), parameters.maxNumberOfPledges);

    // It should bond the pledge amount
    assertEq(eboPledge.bonds(pledgerFor), _totalPledgerBondedAmount);
  }

  function test_PledgeAgainstDispute_RevertWhen_TheCallerIsNotAValidOperator(uint256 _proposalId) external {
    // When the caller is not a valid operator
    _mockAndExpect(
      address(horizonStaking),
      abi.encodeWithSelector(
        IHorizonStaking.isAuthorized.selector, pledgerAgainst, address(eboPledge), notProtocolActor
      ),
      abi.encode(false)
    );

    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyOperator_NotOperator.selector);
    vm.prank(notProtocolActor);
    eboPledge.pledgeAgainstDispute(_proposalId, pledgerAgainst);
  }

  function test_PledgeAgainstDispute_RevertWhen_TheProposalIsNotDisputed(
    uint256 _proposalId,
    address _pledger,
    uint256 _status
  ) external {
    _status = uint8(bound(uint256(_status), 0, uint256(type(IEBOStorage.ProposalStatus).max)));
    vm.assume(_status != uint8(IEBOStorage.ProposalStatus.Disputed));

    // When the proposal is not disputed
    eboPledge.setProposalForTest({
      _proposalId: _proposalId,
      _proposal: IEBOStorage.Proposal({
        epoch: 0,
        chainId: '',
        blockNumber: 0,
        proposer: proposer,
        createdAt: block.timestamp,
        parametersSnapshotId: 0,
        status: IEBOStorage.ProposalStatus(_status)
      })
    });

    // It should revert
    vm.expectRevert(IEBOPledge.EBOPledge_Pledge_ProposalNotDisputed.selector);

    vm.prank(_pledger);
    eboPledge.pledgeAgainstDispute(_proposalId, _pledger);
  }

  function test_PledgeAgainstDispute_RevertWhen_ThePledgeWindowHasPassed(
    uint256 _proposalId,
    address _pledger
  ) external {
    eboPledge.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    // When the pledge window has passed
    vm.warp(block.timestamp + parameters.pledgeWindow);

    // It should revert
    vm.expectRevert(IEBOPledge.EBOPledge_Pledge_PledgeWindowOver.selector);
    vm.prank(_pledger);
    eboPledge.pledgeAgainstDispute(_proposalId, _pledger);
  }

  function test_PledgeAgainstDispute_RevertWhen_TheAgainstSideOfTheDisputeIsWinning(
    uint256 _proposalId,
    address _pledger
  ) external {
    eboPledge.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    // When the 'against' side of the dispute is winning
    eboPledge.setDisputeTotalPledgesForTest({
      _proposalId: _proposalId, _totalPledgesForDispute: 0, _totalPledgesAgainstDispute: 1
    });

    // It should revert
    vm.expectRevert(IEBOPledge.EBOPledge_Pledge_CannotPledgeIfWinning.selector);

    vm.prank(_pledger);
    eboPledge.pledgeAgainstDispute(_proposalId, _pledger);
  }

  function test_PledgeAgainstDispute_WhenItIsTheFirstPledge(uint256 _proposalId) external {
    eboPledge.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    _mockAndExpect(
      address(horizonStaking),
      abi.encodeWithSelector(IHorizonStaking.getProvision.selector, pledgerAgainst, address(eboPledge)),
      abi.encode(
        IHorizonStaking.Provision({
          tokens: parameters.pledgeBondSize,
          tokensThawing: 0,
          sharesThawing: 0,
          maxVerifierCut: eboPledge.MAX_MAX_VERIFIER_CUT(),
          thawingPeriod: uint64(parameters.minThawingPeriod),
          createdAt: 0,
          maxVerifierCutPending: 0,
          thawingPeriodPending: 0,
          thawingNonce: 0
        })
      )
    );

    // One pledge should be required, since it's the first pledge
    uint256 _requiredPledges = 1;
    uint256 _pledgeAmount = parameters.pledgeBondSize;

    // It should emit the PledgedAgainstDispute event
    vm.expectEmit();
    emit IEBOPledge.PledgedAgainstDispute(_proposalId, pledgerAgainst, _pledgeAmount);

    vm.prank(pledgerAgainst);

    // When it is the first pledge
    eboPledge.pledgeAgainstDispute(_proposalId, pledgerAgainst);
    (,, uint256 _lastPledgeTimestamp, uint256 _totalPledgesForDispute, uint256 _totalPledgesAgainstDispute,) =
      eboPledge.disputes(_proposalId);

    // It should update the dispute total number of pledges `against`
    assertEq(_totalPledgesAgainstDispute, _requiredPledges);
    assertEq(_totalPledgesForDispute, 0);

    // It should update the pledger pledges number
    assertEq(eboPledge.pledgesAgainstDispute(_proposalId, pledgerAgainst), _requiredPledges);

    // It should bond the pledge amount
    assertEq(eboPledge.bonds(pledgerAgainst), _pledgeAmount);

    // It should set the last pledge timestamp
    assertEq(_lastPledgeTimestamp, block.timestamp);

    // It should add the pledger to the dispute pledgers `against` enum
    assertTrue(_containsAddress(pledgerAgainst, eboPledge.pledgersAgainstDispute(_proposalId)));
  }

  function test_PledgeAgainstDispute_WhenItsNotTheFirstPledge(uint256 _proposalId) external {
    eboPledge.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    // Two pledges should be required to exceed the opposite side's pledges
    uint256 _requiredPledges = 2;

    // When it is not the first pledge
    eboPledge.setDisputeTotalPledgesForTest({
      _proposalId: _proposalId, _totalPledgesForDispute: 1, _totalPledgesAgainstDispute: 0
    });

    uint256 _pledgeAmount = parameters.pledgeBondSize * _requiredPledges;

    // It should bond the pledge amount
    _mockAndExpect(
      address(horizonStaking),
      abi.encodeWithSelector(IHorizonStaking.getProvision.selector, pledgerAgainst, address(eboPledge)),
      abi.encode(
        IHorizonStaking.Provision({
          tokens: _pledgeAmount,
          tokensThawing: 0,
          sharesThawing: 0,
          maxVerifierCut: eboPledge.MAX_MAX_VERIFIER_CUT(),
          thawingPeriod: uint64(parameters.minThawingPeriod),
          createdAt: 0,
          maxVerifierCutPending: 0,
          thawingPeriodPending: 0,
          thawingNonce: 0
        })
      )
    );

    // It should emit the PledgedAgainstDispute event
    vm.expectEmit();
    emit IEBOPledge.PledgedAgainstDispute(_proposalId, pledgerAgainst, _pledgeAmount);

    vm.prank(pledgerAgainst);

    // When it is not the first pledge
    eboPledge.pledgeAgainstDispute(_proposalId, pledgerAgainst);

    (,, uint256 _lastPledgeTimestamp,, uint256 _totalPledgesAgainstDispute,) = eboPledge.disputes(_proposalId);

    // It should set the last pledge timestamp
    assertEq(_lastPledgeTimestamp, block.timestamp);

    // It should add the pledger to the dispute pledgers `against` enum
    assertTrue(_containsAddress(pledgerAgainst, eboPledge.pledgersAgainstDispute(_proposalId)));

    // It should update the dispute total number of pledges `against`
    assertEq(_totalPledgesAgainstDispute, _requiredPledges);

    // It should update the pledger pledges number
    assertEq(eboPledge.pledgesAgainstDispute(_proposalId, pledgerAgainst), _requiredPledges);

    // It should bond the pledge amount
    assertEq(eboPledge.bonds(pledgerAgainst), _pledgeAmount);
  }

  function test_PledgeAgainstDispute_WhenTheMaxPledgeNumberIsReached(uint256 _proposalId) external {
    eboPledge.setDisputeForTest({
      _proposalId: _proposalId, _disputer: disputer, _createdAt: block.timestamp, _lastPledgeTimestamp: 0
    });

    uint256 _totalPledgerBondedAmount = parameters.pledgeBondSize * parameters.maxNumberOfPledges;
    uint256 _lastPledgeAmount = parameters.pledgeBondSize;

    // It should bond the pledge amount
    _mockAndExpect(
      address(horizonStaking),
      abi.encodeWithSelector(IHorizonStaking.getProvision.selector, pledgerAgainst, address(eboPledge)),
      abi.encode(
        IHorizonStaking.Provision({
          tokens: _totalPledgerBondedAmount,
          tokensThawing: 0,
          sharesThawing: 0,
          maxVerifierCut: eboPledge.MAX_MAX_VERIFIER_CUT(),
          thawingPeriod: uint64(parameters.minThawingPeriod),
          createdAt: 0,
          maxVerifierCutPending: 0,
          thawingPeriodPending: 0,
          thawingNonce: 0
        })
      )
    );

    eboPledge.setPledgesForDisputeForTest(_proposalId, pledgerFor, parameters.maxNumberOfPledges);
    // One pledge should be required to reach the max pledge number for the 'against' side
    eboPledge.setPledgesAgainstDisputeForTest(_proposalId, pledgerAgainst, parameters.maxNumberOfPledges - 1);

    // It should emit the DisputeEscalated event
    vm.expectEmit();
    emit IEBOPledge.DisputeEscalated(_proposalId);

    // It should emit the PledgedAgainstDispute event
    vm.expectEmit();
    emit IEBOPledge.PledgedAgainstDispute(_proposalId, pledgerAgainst, _lastPledgeAmount);

    vm.prank(pledgerAgainst);

    // When the max pledge number is reached
    eboPledge.pledgeAgainstDispute(_proposalId, pledgerAgainst);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboPledge.proposals(_proposalId);
    (,, uint256 _lastPledgeTimestamp,, uint256 _totalPledgesAgainstDispute,) = eboPledge.disputes(_proposalId);

    // It should set the last pledge timestamp
    assertEq(_lastPledgeTimestamp, block.timestamp);

    // It should set the proposal status to Escalated
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.Escalated));

    // It should update the dispute total number of pledges `against`
    assertEq(_totalPledgesAgainstDispute, parameters.maxNumberOfPledges);

    // It should update the pledger pledges number
    assertEq(eboPledge.pledgesAgainstDispute(_proposalId, pledgerAgainst), parameters.maxNumberOfPledges);

    // It should bond the pledge amount
    assertEq(eboPledge.bonds(pledgerAgainst), _totalPledgerBondedAmount);
  }
}

contract EBOPledgeForTest is EBOPledge, EBOStorageHelper {}
