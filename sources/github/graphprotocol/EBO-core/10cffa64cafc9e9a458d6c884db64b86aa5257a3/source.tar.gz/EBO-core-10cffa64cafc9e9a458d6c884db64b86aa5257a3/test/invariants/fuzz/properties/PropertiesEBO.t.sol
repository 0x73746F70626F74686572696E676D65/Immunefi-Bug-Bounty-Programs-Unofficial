// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {HandlersParent} from '../handlers/HandlersParent.t.sol';
import {IEBOStorage} from 'src/interfaces/common/IEBOStorage.sol';
import {IHorizonStaking} from 'src/interfaces/external/IHorizonStaking.sol';
import {IEBOCore} from 'src/interfaces/modules/IEBOCore.sol';
import {IEBOPledge} from 'src/interfaces/modules/IEBOPledge.sol';

contract PropertiesEBO is HandlersParent {
  /// @custom:property-id 1
  /// @custom:description For any user U, bonds(U) is less than or equal to the amount of idle tokens (bonded - thawing) in the HorizonStaking contract.
  function invariant_bondedFunds_lessThanEqualIdle(
    uint256 _epoch,
    uint256 _chainIndex,
    uint256 _blockNumber
  ) external createActor {
    _epoch = clampBetween(_epoch, ebo.startEpoch(), ebo.epochManager().currentEpoch());

    _chainIndex = clampBetween(_chainIndex, 0, chainIds.length - 1);

    (uint256 _proposalBondSize,,,,,,) = ebo.parametersSnapshots(ebo.parametersSnapshotId());

    _provisionIfNeeded(currentActor, _proposalBondSize);

    vm.prank(currentActor);
    try ebo.propose(_epoch, chainIds[_chainIndex], _blockNumber, currentActor) {
      (
        ,
        string memory _chainId,,
        address _proposer,
        uint256 _createdAt,
        uint256 _parametersSnapshotId,
        IEBOStorage.ProposalStatus _status
      ) = ebo.proposals(ebo.proposalId());
      ghost_activeProposals.push(
        ProposalWithId({
          id: ebo.proposalId(),
          proposal: IEBOStorage.Proposal({
            epoch: _epoch,
            chainId: _chainId,
            blockNumber: _blockNumber,
            proposer: _proposer,
            createdAt: _createdAt,
            parametersSnapshotId: _parametersSnapshotId,
            status: _status
          })
        })
      );

      IHorizonStaking.Provision memory _provision = horizonStaking.getProvision(msg.sender, address(ebo));
      uint256 _bonded = ebo.bonds(msg.sender);
      assert(_provision.tokensThawing <= _provision.tokens);
      assert(_bonded <= _provision.tokens - _provision.tokensThawing);
      vm.warp(block.timestamp + 1);
    } catch (bytes memory _reason) {
      assert(
        keccak256(_reason) == keccak256(abi.encodeWithSelector(IEBOCore.EBOCore_Propose_ProposalAlreadyActive.selector))
      );
    }
  }

  /// @custom:property-id 2
  /// @custom:description The proposal with id `0` is always 'empty'
  function invariant_proposal0_isEmpty() external view {
    (,,,,,, IEBOStorage.ProposalStatus _status) = ebo.proposals(0);
    assert(_status == IEBOStorage.ProposalStatus.None);
  }

  /// @custom:property-id 3
  /// @custom:description For any proposals P1, P2 where P2 was submitted after P1: proposalId(P2) > proposalId(P1)
  function invariant_proposalId_monotonic(uint256 _proposalId1, uint256 _proposalId2) external {
    if (ebo.proposalId() <= 1) return;

    _proposalId1 = clampBetween(_proposalId1, 2, ebo.proposalId());
    _proposalId2 = clampBetween(_proposalId2, 1, _proposalId1 - 1);

    (,,,, uint256 _createdAt1,,) = ebo.proposals(_proposalId1);
    (,,,, uint256 _createdAt2,,) = ebo.proposals(_proposalId2);

    assert(_createdAt1 > _createdAt2);
  }

  /// @custom:property-id 4
  /// @custom:description For any dispute D, D.totalPledgesAgainstDispute <= maxNumberOfPledges and D.totalPledgesForDispute <= maxNumberOfPledges
  function invariant_dispute_totalPledges_lessThanEqualMaxNumberOfPledges(uint256 _disputedProposalIndex) external {
    if (ghost_disputedProposals.length == 0) return;

    _disputedProposalIndex = clampBetween(_disputedProposalIndex, 0, ghost_disputedProposals.length - 1);
    ProposalWithId memory _disputedProposal = ghost_disputedProposals[_disputedProposalIndex];

    (,,,,, uint256 _parametersSnapshotId,) = ebo.proposals(_disputedProposal.id);
    (,,, uint256 _totalPledgesAgainstDispute, uint256 _totalPledgesForDispute,) = ebo.disputes(_disputedProposal.id);
    (,,,,,, uint256 _maxNumberOfPledges) = ebo.parametersSnapshots(_parametersSnapshotId);
    assert(_totalPledgesAgainstDispute <= _maxNumberOfPledges);
    assert(_totalPledgesForDispute <= _maxNumberOfPledges);
  }

  /// @custom:property-id 5
  /// @custom:description For any dispute D, the difference between D.totalPledgesAgainstDispute and D.totalPledgesForDispute is less than or equal to 1
  function invariant_dispute_totalPledges_difference_lessThanEqual1(uint256 _disputedProposalIndex) external {
    if (ghost_disputedProposals.length == 0) return;

    _disputedProposalIndex = clampBetween(_disputedProposalIndex, 0, ghost_disputedProposals.length - 1);
    ProposalWithId memory _disputedProposal = ghost_disputedProposals[_disputedProposalIndex];

    (,,, uint256 _totalPledgesForDispute, uint256 _totalPledgesAgainstDispute,) = ebo.disputes(_disputedProposal.id);
    assertDifferenceLessThan(_totalPledgesAgainstDispute, _totalPledgesForDispute, 1);
  }

  /// @custom:property-id 6
  /// @custom:description For any dispute D, if D.status == Escalated: D.totalPledgesForDispute == D.totalPledgesAgainstDispute == maxNumberOfPledges
  function invariant_escalatedDispute_totalPledges_equalMaxNumberOfPledges(uint256 _escalatedProposalIndex) external {
    if (ghost_escalatedProposals.length == 0) return;

    _escalatedProposalIndex = clampBetween(_escalatedProposalIndex, 0, ghost_escalatedProposals.length - 1);
    ProposalWithId memory _escalatedProposal = ghost_escalatedProposals[_escalatedProposalIndex];

    (,,,,, uint256 _parametersSnapshotId,) = ebo.proposals(_escalatedProposal.id);

    (,,, uint256 _totalPledgesAgainstDispute, uint256 _totalPledgesForDispute,) = ebo.disputes(_escalatedProposal.id);
    (,,,,,, uint256 _maxNumberOfPledges) = ebo.parametersSnapshots(_parametersSnapshotId);
    assert(_totalPledgesAgainstDispute == _maxNumberOfPledges);
    assert(_totalPledgesForDispute == _maxNumberOfPledges);
  }

  /// @custom:property-id 7
  /// @custom:description For any dispute D and any user U, if D.status != ProposalStatus.DisputerLost and D.status != ProposalStatus.DisputerWon, claimPledgeReward(D, U) reverts
  function invariant_claimPledgeReward_reverts(uint256 _disputedProposalIndex) external {
    if (ghost_disputedProposals.length == 0) return;

    _disputedProposalIndex = clampBetween(_disputedProposalIndex, 0, ghost_disputedProposals.length - 1);
    ProposalWithId memory _disputedProposal = ghost_disputedProposals[_disputedProposalIndex];

    (,,,,,, IEBOStorage.ProposalStatus _status) = ebo.proposals(_disputedProposal.id);
    if (_status == IEBOStorage.ProposalStatus.DisputerLost || _status == IEBOStorage.ProposalStatus.DisputerWon) {
      return;
    }

    try ebo.claimPledgeReward(_disputedProposal.id, msg.sender) {
      assert(false);
    } catch (bytes memory _reason) {
      assert(
        keccak256(_reason)
          == keccak256(abi.encodeWithSelector(IEBOPledge.EBOPledge_ClaimPledgeReward_DisputeHasNoResolution.selector))
      );
    }
  }

  /// @custom:property-id 8
  /// @custom:description For any proposal P, if P.status == Escalated, disputes(P) is not empty.
  function invariant_escalatedProposal_disputes_notEmpty(uint256 _escalatedProposalIndex) external {
    if (ghost_escalatedProposals.length == 0) return;

    _escalatedProposalIndex = clampBetween(_escalatedProposalIndex, 0, ghost_escalatedProposals.length - 1);
    ProposalWithId memory _escalatedProposal = ghost_escalatedProposals[_escalatedProposalIndex];

    (address _disputer, uint256 _createdAt,, uint256 _totalPledgesAgainstDispute, uint256 _totalPledgesForDispute,) =
      ebo.disputes(_escalatedProposal.id);
    assert(_disputer != address(0));
    assert(_createdAt != 0);
    assert(_totalPledgesAgainstDispute > 0 && _totalPledgesForDispute > 0);
  }

  /// @custom:property-id 9
  /// @custom:description For any dispute `D` and times `t1`, `t2` where `t1` <= `t2`: `totalPledgesForDispute(D, t1)` <= `totalPledgesForDispute(D, t2)` and `totalPledgesAgainstDispute(D, t1)` <= `totalPledgesAgainstDispute(D, t2)`
  function invariant_dispute_totalPledges_monotonic(uint256 _disputedProposalIndex) external {
    if (ghost_disputedProposals.length == 0) return;

    _disputedProposalIndex = clampBetween(_disputedProposalIndex, 0, ghost_disputedProposals.length - 1);
    ProposalWithId memory _disputedProposal = ghost_disputedProposals[_disputedProposalIndex];

    (,,,, uint256 _totalPledgesForDispute, uint256 _totalPledgesAgainstDispute) = ebo.disputes(_disputedProposal.id);
    assert(ghost_totalPledgesForDispute[_disputedProposal.id] <= _totalPledgesForDispute);
    assert(ghost_totalPledgesAgainstDispute[_disputedProposal.id] <= _totalPledgesAgainstDispute);

    ghost_totalPledgesForDispute[_disputedProposal.id] = _totalPledgesForDispute;
    ghost_totalPledgesAgainstDispute[_disputedProposal.id] = _totalPledgesAgainstDispute;
  }

  /// @custom:property-id 10
  /// @custom:description For every Dispute `D` with `D.status` == `DisputerWon` or `D.status` == `DisputerLost`, the GRT balance of EBO is greater than or equal to the sum of (`totalWinningPledges(D)` * `rewardPerWinningPledge(D)` - `totalClaimed(D)`)
  function invariant_dispute_grtBalance_Enough() external view {
    if (ghost_resolvedProposals.length == 0) return;

    uint256 _totalRewardToCoverDisputes = 0;
    for (uint256 _i = 0; _i < ghost_resolvedProposals.length; _i++) {
      _totalRewardToCoverDisputes += _rewardToCoverDispute(ghost_resolvedProposals[_i].id);
    }

    assert(grt.balanceOf(address(ebo)) >= _totalRewardToCoverDisputes);
  }

  function _rewardToCoverDispute(uint256 _proposalId) internal view returns (uint256) {
    (,,,,,, IEBOStorage.ProposalStatus _status) = ebo.proposals(_proposalId);
    (,,, uint256 totalPledgesForDispute, uint256 totalPledgesAgainstDispute, uint256 _rewardPerWinningPledge) =
      ebo.disputes(_proposalId);

    if (_status == IEBOStorage.ProposalStatus.DisputerWon) {
      return totalPledgesForDispute * _rewardPerWinningPledge;
    } else if (_status == IEBOStorage.ProposalStatus.DisputerLost) {
      return totalPledgesAgainstDispute * _rewardPerWinningPledge;
    }

    return 0;
  }
}
