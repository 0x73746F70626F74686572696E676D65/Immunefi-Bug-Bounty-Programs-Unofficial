// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {ETHEREUM_CHAIN_ID} from 'script/Constants.sol';
import {IntegrationBase} from 'test/integration/arbitrum-sepolia/IntegrationBase.t.sol';

import {IHorizonStaking} from 'src/interfaces/external/IHorizonStaking.sol';

import {IAccessManager} from 'src/interfaces/common/IAccessManager.sol';

import {IEBOStorage} from 'src/interfaces/common/IEBOStorage.sol';
import {IEBOCore} from 'src/interfaces/modules/IEBOCore.sol';

contract IntegrationResolveByArbitration is IntegrationBase {
  function setUp() public override {
    super.setUp();

    // Create a proposal
    _propose(ETHEREUM_CHAIN_ID);

    // Dispute the proposal
    _dispute(_lastProposalId);

    // PledgerA pledges for the dispute
    _pledgeForDispute(_lastProposalId, _pledgerA);

    // PledgerB pledges against the dispute
    _pledgeAgainstDispute(_lastProposalId, _pledgerB);

    // PledgerC pledges for the dispute
    _pledgeForDispute(_lastProposalId, _pledgerC);

    // PledgerD pledges against the dispute
    _pledgeAgainstDispute(_lastProposalId, _pledgerD);

    // PledgerE pledges for the dispute
    _pledgeForDispute(_lastProposalId, _pledgerE);

    // The dispute is escalated after the last pledge
  }

  function test_ResolveByArbitration_Revert_NotArbitrator() public {
    vm.expectRevert(IAccessManager.AccessManager_OnlyArbitrator_NotArbitrator.selector);

    // Call resolve as a non-arbitrator
    eboProxy.resolve(_lastProposalId, IEBOStorage.ProposalStatus.DisputerWon);
  }

  function test_ResolveByArbitration_Revert_DisputeNotEscalated() public {
    // Create a new proposal
    _propose(ETHEREUM_CHAIN_ID, _lastProposalEpoch, _proposerB);

    // Dispute the proposal
    _dispute(_lastProposalId, _disputerB);

    // Call resolve on the new active proposal
    vm.expectRevert(IEBOCore.EBOCore_Resolve_DisputeNotEscalated.selector);

    _resolve(_lastProposalId, IEBOStorage.ProposalStatus.DisputerWon);
  }

  function test_ResolveByArbitration_Revert_InvalidStatus() public {
    vm.expectRevert(IEBOCore.EBOCore_Resolve_InvalidStatus.selector);

    // Call resolve with an invalid resolution status
    _resolve(_lastProposalId, IEBOStorage.ProposalStatus.Finalized);
  }

  function test_ResolveByArbitration_DisputerWon() public {
    // Call resolve with the DisputerWon status
    _resolve(_lastProposalId, IEBOStorage.ProposalStatus.DisputerWon);

    uint256 _slashedPledgerProvisionAmount = _pledgerStake - initParams.parameters.pledgeBondSize * 2;

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboProxy.proposals(_lastProposalId);

    (,,,,, uint256 _queriedDisputeRewardPerWinningPledge) = eboProxy.disputes(_lastProposalId);

    // Proposer's provision
    IHorizonStaking.Provision memory _proposerProvision = horizonStaking.getProvision(_proposerA, address(eboProxy));

    // Disputer's provision
    IHorizonStaking.Provision memory _disputerProvision = horizonStaking.getProvision(_disputerA, address(eboProxy));

    // Pledgers' provisions
    IHorizonStaking.Provision memory _pledgerAProvision = horizonStaking.getProvision(_pledgerA, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerBProvision = horizonStaking.getProvision(_pledgerB, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerCProvision = horizonStaking.getProvision(_pledgerC, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerDProvision = horizonStaking.getProvision(_pledgerD, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerEProvision = horizonStaking.getProvision(_pledgerE, address(eboProxy));

    // Check the bonders' bonds
    assertEq(eboProxy.bonds(_proposerA), 0);
    assertEq(eboProxy.bonds(_disputerA), 0);
    assertEq(eboProxy.bonds(_pledgerA), 0);
    assertEq(eboProxy.bonds(_pledgerB), 0);
    assertEq(eboProxy.bonds(_pledgerC), 0);
    assertEq(eboProxy.bonds(_pledgerD), 0);
    assertEq(eboProxy.bonds(_pledgerE), 0);

    // Check the proposal status
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.DisputerWon));

    // Check the proposers' balance
    assertEq(grt.balanceOf(_proposerA), 0);

    // Check the disputers' balance
    assertEq(grt.balanceOf(_disputerA), _proposerAndDisputerStake);

    // Check the reward per winning pledge
    assertEq(_queriedDisputeRewardPerWinningPledge, initParams.parameters.pledgeBondSize);

    // Check the provisions of the non-slashed pledgers
    assertEq(_pledgerAProvision.tokens, _pledgerStake);
    assertEq(_pledgerCProvision.tokens, _pledgerStake);
    assertEq(_pledgerEProvision.tokens, _pledgerStake);

    // Check the provisions of the slashed pledgers
    assertEq(_pledgerBProvision.tokens, _slashedPledgerProvisionAmount);
    assertEq(_pledgerDProvision.tokens, _slashedPledgerProvisionAmount);

    // Check the provisions of the disputer
    assertEq(_disputerProvision.tokens, _proposerAndDisputerStake);

    // Check the provisions of the proposer
    assertEq(_proposerProvision.tokens, 0);

    // Check the balance of the EBO contract
    assertEq(grt.balanceOf(address(eboProxy)), initParams.parameters.pledgeBondSize * 4);
  }

  function test_ResolveByArbitration_DisputerLost() public {
    // Call resolve with the DisputerLost status
    _resolve(_lastProposalId, IEBOStorage.ProposalStatus.DisputerLost);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboProxy.proposals(_lastProposalId);

    (,,,,, uint256 _queriedDisputeRewardPerWinningPledge) = eboProxy.disputes(_lastProposalId);

    // Proposer's provision
    IHorizonStaking.Provision memory _proposerProvision = horizonStaking.getProvision(_proposerA, address(eboProxy));

    // Disputer's provision
    IHorizonStaking.Provision memory _disputerProvision = horizonStaking.getProvision(_disputerA, address(eboProxy));

    // Pledgers' provisions
    IHorizonStaking.Provision memory _pledgerAProvision = horizonStaking.getProvision(_pledgerA, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerBProvision = horizonStaking.getProvision(_pledgerB, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerCProvision = horizonStaking.getProvision(_pledgerC, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerDProvision = horizonStaking.getProvision(_pledgerD, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerEProvision = horizonStaking.getProvision(_pledgerE, address(eboProxy));

    // Check the bonders' bonds
    assertEq(eboProxy.bonds(_proposerA), 0);
    assertEq(eboProxy.bonds(_disputerA), 0);
    assertEq(eboProxy.bonds(_pledgerA), 0);
    assertEq(eboProxy.bonds(_pledgerB), 0);
    assertEq(eboProxy.bonds(_pledgerC), 0);
    assertEq(eboProxy.bonds(_pledgerD), 0);
    assertEq(eboProxy.bonds(_pledgerE), 0);

    // Check the proposal status
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.DisputerLost));

    // Check the proposers' balance
    assertEq(grt.balanceOf(_proposerA), _proposerAndDisputerStake);

    // Check the disputers' balance
    assertEq(grt.balanceOf(_disputerA), 0);

    // Check the reward per winning pledge
    assertEq(_queriedDisputeRewardPerWinningPledge, initParams.parameters.pledgeBondSize);

    // Check the provisions of the non-slashed pledgers
    assertEq(_pledgerBProvision.tokens, _pledgerStake);
    assertEq(_pledgerDProvision.tokens, _pledgerStake);

    // Check the provisions of the slashed pledgers
    assertEq(_pledgerAProvision.tokens, _pledgerStake - initParams.parameters.pledgeBondSize);
    assertEq(_pledgerCProvision.tokens, _pledgerStake - 2 * initParams.parameters.pledgeBondSize);
    assertEq(_pledgerEProvision.tokens, _pledgerStake - initParams.parameters.pledgeBondSize);

    // Check the provisions of the disputer
    assertEq(_disputerProvision.tokens, 0);

    // Check the provisions of the proposer
    assertEq(_proposerProvision.tokens, _proposerAndDisputerStake);

    // Check the balance of the EBO contract
    assertEq(grt.balanceOf(address(eboProxy)), initParams.parameters.pledgeBondSize * 4);
  }

  function test_ResolveByArbitration_NoResolution() public {
    // Call resolve with the NoResolution status
    _resolve(_lastProposalId, IEBOStorage.ProposalStatus.NoResolution);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboProxy.proposals(_lastProposalId);

    (,,,,, uint256 _queriedDisputeRewardPerWinningPledge) = eboProxy.disputes(_lastProposalId);

    // Proposer's provision
    IHorizonStaking.Provision memory _proposerProvision = horizonStaking.getProvision(_proposerA, address(eboProxy));

    // Disputer's provision
    IHorizonStaking.Provision memory _disputerProvision = horizonStaking.getProvision(_disputerA, address(eboProxy));

    // Pledgers' provisions
    IHorizonStaking.Provision memory _pledgerAProvision = horizonStaking.getProvision(_pledgerA, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerBProvision = horizonStaking.getProvision(_pledgerB, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerCProvision = horizonStaking.getProvision(_pledgerC, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerDProvision = horizonStaking.getProvision(_pledgerD, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerEProvision = horizonStaking.getProvision(_pledgerE, address(eboProxy));

    // Check the bonders' bonds
    assertEq(eboProxy.bonds(_proposerA), 0);
    assertEq(eboProxy.bonds(_disputerA), 0);
    assertEq(eboProxy.bonds(_pledgerA), 0);
    assertEq(eboProxy.bonds(_pledgerB), 0);
    assertEq(eboProxy.bonds(_pledgerC), 0);
    assertEq(eboProxy.bonds(_pledgerD), 0);
    assertEq(eboProxy.bonds(_pledgerE), 0);

    // Check the proposal status
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.NoResolution));

    // Check the proposers' balance
    assertEq(grt.balanceOf(_proposerA), 0);

    // Check the disputers' balance
    assertEq(grt.balanceOf(_disputerA), 0);

    // Check the reward per winning pledge
    assertEq(_queriedDisputeRewardPerWinningPledge, 0);

    // Check the provisions of the pledgers
    assertEq(_pledgerAProvision.tokens, _pledgerStake);
    assertEq(_pledgerBProvision.tokens, _pledgerStake);
    assertEq(_pledgerCProvision.tokens, _pledgerStake);
    assertEq(_pledgerDProvision.tokens, _pledgerStake);
    assertEq(_pledgerEProvision.tokens, _pledgerStake);

    // Check the provisions of the disputer
    assertEq(_disputerProvision.tokens, _proposerAndDisputerStake);

    // Check the provisions of the proposer
    assertEq(_proposerProvision.tokens, _proposerAndDisputerStake);

    // Check the balance of the EBO contract
    assertEq(grt.balanceOf(address(eboProxy)), 0);
  }

  function test_ResolveByArbitration_DisputerWon_MinThawingPeriodPassed_NoResolutionForced() public {
    // Elapse the min thawing period
    vm.warp(block.timestamp + initParams.parameters.minThawingPeriod + 1);

    // Call resolve with the DisputerWon status
    _resolve(_lastProposalId, IEBOStorage.ProposalStatus.DisputerWon);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboProxy.proposals(_lastProposalId);

    (,,,,, uint256 _queriedDisputeRewardPerWinningPledge) = eboProxy.disputes(_lastProposalId);

    // Proposer's provision
    IHorizonStaking.Provision memory _proposerProvision = horizonStaking.getProvision(_proposerA, address(eboProxy));

    // Disputer's provision
    IHorizonStaking.Provision memory _disputerProvision = horizonStaking.getProvision(_disputerA, address(eboProxy));

    // Pledgers' provisions
    IHorizonStaking.Provision memory _pledgerAProvision = horizonStaking.getProvision(_pledgerA, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerBProvision = horizonStaking.getProvision(_pledgerB, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerCProvision = horizonStaking.getProvision(_pledgerC, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerDProvision = horizonStaking.getProvision(_pledgerD, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerEProvision = horizonStaking.getProvision(_pledgerE, address(eboProxy));

    // Check the bonders' bonds
    assertEq(eboProxy.bonds(_proposerA), 0);
    assertEq(eboProxy.bonds(_disputerA), 0);
    assertEq(eboProxy.bonds(_pledgerA), 0);
    assertEq(eboProxy.bonds(_pledgerB), 0);
    assertEq(eboProxy.bonds(_pledgerC), 0);
    assertEq(eboProxy.bonds(_pledgerD), 0);
    assertEq(eboProxy.bonds(_pledgerE), 0);

    // Check the proposal status
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.NoResolution));

    // Check the proposers' balance
    assertEq(grt.balanceOf(_proposerA), 0);

    // Check the disputers' balance
    assertEq(grt.balanceOf(_disputerA), 0);

    // Check the reward per winning pledge
    assertEq(_queriedDisputeRewardPerWinningPledge, 0);

    // Check the provisions of the pledgers
    assertEq(_pledgerAProvision.tokens, _pledgerStake);
    assertEq(_pledgerBProvision.tokens, _pledgerStake);
    assertEq(_pledgerCProvision.tokens, _pledgerStake);
    assertEq(_pledgerDProvision.tokens, _pledgerStake);
    assertEq(_pledgerEProvision.tokens, _pledgerStake);

    // Check the provisions of the disputer
    assertEq(_disputerProvision.tokens, _proposerAndDisputerStake);

    // Check the provisions of the proposer
    assertEq(_proposerProvision.tokens, _proposerAndDisputerStake);

    // Check the balance of the EBO contract
    assertEq(grt.balanceOf(address(eboProxy)), 0);
  }

  function test_ResolveByArbitration_DisputerLost_MinThawingPeriodPassed_NoResolutionForced() public {
    // Elapse the min thawing period
    vm.warp(block.timestamp + initParams.parameters.minThawingPeriod + 1);

    // Call resolve with the DisputerLost status
    _resolve(_lastProposalId, IEBOStorage.ProposalStatus.DisputerLost);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboProxy.proposals(_lastProposalId);

    (,,,,, uint256 _queriedDisputeRewardPerWinningPledge) = eboProxy.disputes(_lastProposalId);

    // Proposer's provision
    IHorizonStaking.Provision memory _proposerProvision = horizonStaking.getProvision(_proposerA, address(eboProxy));

    // Disputer's provision
    IHorizonStaking.Provision memory _disputerProvision = horizonStaking.getProvision(_disputerA, address(eboProxy));

    // Pledgers' provisions
    IHorizonStaking.Provision memory _pledgerAProvision = horizonStaking.getProvision(_pledgerA, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerBProvision = horizonStaking.getProvision(_pledgerB, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerCProvision = horizonStaking.getProvision(_pledgerC, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerDProvision = horizonStaking.getProvision(_pledgerD, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerEProvision = horizonStaking.getProvision(_pledgerE, address(eboProxy));

    // Check the bonders' bonds
    assertEq(eboProxy.bonds(_proposerA), 0);
    assertEq(eboProxy.bonds(_disputerA), 0);
    assertEq(eboProxy.bonds(_pledgerA), 0);
    assertEq(eboProxy.bonds(_pledgerB), 0);
    assertEq(eboProxy.bonds(_pledgerC), 0);
    assertEq(eboProxy.bonds(_pledgerD), 0);
    assertEq(eboProxy.bonds(_pledgerE), 0);

    // Check the proposal status
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.NoResolution));

    // Check the proposers' balance
    assertEq(grt.balanceOf(_proposerA), 0);

    // Check the disputers' balance
    assertEq(grt.balanceOf(_disputerA), 0);

    // Check the reward per winning pledge
    assertEq(_queriedDisputeRewardPerWinningPledge, 0);

    // Check the provisions of the pledgers
    assertEq(_pledgerAProvision.tokens, _pledgerStake);
    assertEq(_pledgerBProvision.tokens, _pledgerStake);
    assertEq(_pledgerCProvision.tokens, _pledgerStake);
    assertEq(_pledgerDProvision.tokens, _pledgerStake);
    assertEq(_pledgerEProvision.tokens, _pledgerStake);

    // Check the provisions of the disputer
    assertEq(_disputerProvision.tokens, _proposerAndDisputerStake);

    // Check the provisions of the proposer
    assertEq(_proposerProvision.tokens, _proposerAndDisputerStake);

    // Check the balance of the EBO contract
    assertEq(grt.balanceOf(address(eboProxy)), 0);
  }
}
