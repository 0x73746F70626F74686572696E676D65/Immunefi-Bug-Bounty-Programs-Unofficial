// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {PropertiesA} from './PropertiesA.t.sol';
import {PropertiesEBO} from './PropertiesEBO.t.sol';

contract PropertiesParent is PropertiesA, PropertiesEBO {}
