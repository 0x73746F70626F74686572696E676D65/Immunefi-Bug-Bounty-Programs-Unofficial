// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IHorizonStaking} from '../../../../src/interfaces/external/IHorizonStaking.sol';
import {IERC20} from '@openzeppelin/contracts/token/ERC20/IERC20.sol';

contract MockHorizonStaking is IHorizonStaking {
  error MockHorizonStaking_Error(string message);

  uint256 internal constant FIXED_POINT_PRECISION = 1e18;

  IERC20 grt;
  mapping(address => uint256) public balances;
  mapping(address => uint256) public tokensProvisioned;
  mapping(address => mapping(address => Provision)) public provisions;

  constructor(IERC20 _grt) {
    grt = _grt;
  }

  function stake(uint256 tokens) external {
    balances[msg.sender] += tokens;
    grt.transferFrom(msg.sender, address(this), tokens);
  }

  function thaw(address serviceProvider, address verifier, uint256 tokens) external returns (bytes32) {
    if (tokens == 0) {
      revert MockHorizonStaking_Error('Tokens must be greater than 0');
    }

    uint256 tokensAvailable =
      provisions[serviceProvider][verifier].tokens - provisions[serviceProvider][verifier].tokensThawing;
    if (tokensAvailable < tokens) {
      revert MockHorizonStaking_Error('Not enough tokens');
    }

    Provision storage prov = provisions[serviceProvider][verifier];

    // Calculate shares to issue
    // Thawing pool is reset/initialized when the pool is empty: prov.tokensThawing == 0
    // Round thawing shares up to ensure fairness and avoid undervaluing the shares due to rounding down.
    uint256 thawingShares =
      prov.tokensThawing == 0 ? tokens : ((prov.sharesThawing * tokens + prov.tokensThawing - 1) / prov.tokensThawing);

    prov.sharesThawing = prov.sharesThawing + thawingShares;
    prov.tokensThawing = prov.tokensThawing + tokens;

    return bytes32(0);
  }

  function provision(
    address serviceProvider,
    address verifier,
    uint256 tokens,
    uint32 maxVerifierCut,
    uint64 thawingPeriod
  ) external {
    if (tokens <= 0) {
      revert MockHorizonStaking_Error('Tokens must be greater than 0');
    }
    if (provisions[serviceProvider][verifier].createdAt != 0) {
      revert MockHorizonStaking_Error('Provision already exists');
    }

    uint256 _idleStake = _getIdleStake(serviceProvider);

    if (_idleStake < tokens) {
      revert MockHorizonStaking_Error('Not enough idle stake');
    }

    provisions[serviceProvider][verifier] = Provision({
      tokens: tokens,
      tokensThawing: 0,
      sharesThawing: 0,
      maxVerifierCut: maxVerifierCut,
      thawingPeriod: thawingPeriod,
      createdAt: uint64(block.timestamp),
      maxVerifierCutPending: 0,
      thawingPeriodPending: thawingPeriod,
      thawingNonce: 0
    });
  }

  function addToProvision(address serviceProvider, address verifier, uint256 tokens) external {
    Provision storage _provision = provisions[serviceProvider][verifier];
    if (_provision.createdAt == 0) {
      revert MockHorizonStaking_Error('Provision does not exist');
    }

    uint256 _idleStake = _getIdleStake(serviceProvider);
    if (_idleStake < tokens) {
      revert MockHorizonStaking_Error('Not enough idle stake');
    }

    _provision.tokens += tokens;
  }

  function slash(
    address serviceProvider,
    uint256 tokens,
    uint256 tokensVerifier,
    address verifierDestination
  ) external {
    address verifier = msg.sender;
    Provision storage prov = provisions[serviceProvider][verifier];
    uint256 tokensProvisionTotal = prov.tokens;
    if (tokensProvisionTotal == 0) {
      revert MockHorizonStaking_Error('No provision');
    }

    uint256 tokensToSlash = tokensProvisionTotal < tokens ? tokensProvisionTotal : tokens;

    uint256 providerTokensSlashed = prov.tokens < tokensToSlash ? prov.tokens : tokensToSlash;
    if (providerTokensSlashed > 0) {
      // Pay verifier reward - must be within the maxVerifierCut percentage
      uint256 maxVerifierTokens = _mulPPM(providerTokensSlashed, prov.maxVerifierCut);
      if (maxVerifierTokens < tokensVerifier) {
        revert MockHorizonStaking_Error('Verifier reward is too high');
      }
      if (tokensVerifier > 0) {
        grt.transfer(verifierDestination, tokensVerifier);
      }

      // Burn remainder
      grt.transfer(address(0xdead), providerTokensSlashed - tokensVerifier);

      // Provision accounting
      uint256 provisionFractionSlashed = (providerTokensSlashed * FIXED_POINT_PRECISION + prov.tokens - 1) / prov.tokens;
      prov.tokensThawing =
        (prov.tokensThawing * (FIXED_POINT_PRECISION - provisionFractionSlashed)) / (FIXED_POINT_PRECISION);
      prov.tokens = prov.tokens - providerTokensSlashed;

      // If the slashing leaves the thawing shares with no thawing tokens, cancel pending thawings by:
      // - deleting all thawing shares
      // - incrementing the nonce to invalidate pending thaw requests
      if (prov.sharesThawing != 0 && prov.tokensThawing == 0) {
        prov.sharesThawing = 0;
        prov.thawingNonce++;
      }
    }
  }

  function setOperator(address verifier, address operator, bool allowed) external {}

  function getProvision(address serviceProvider, address verifier) external view returns (Provision memory) {
    return provisions[serviceProvider][verifier];
  }

  function isAuthorized(address serviceProvider, address verifier, address operator) external view returns (bool) {}

  function _getIdleStake(address serviceProvider) internal view returns (uint256) {
    uint256 tokensUsed = tokensProvisioned[serviceProvider];
    uint256 tokensStaked = balances[serviceProvider];
    return tokensStaked > tokensUsed ? tokensStaked - tokensUsed : 0;
  }

  function _mulPPM(uint256 a, uint256 b) internal pure returns (uint256) {
    return (a * b) / 1_000_000;
  }

  function _isValidPPM(uint256 value) internal pure returns (bool) {
    return value <= 1_000_000;
  }
}
