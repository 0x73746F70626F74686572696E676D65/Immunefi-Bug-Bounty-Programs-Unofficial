// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {ARBITRUM_SEPOLIA_START_EPOCH, ETHEREUM_CHAIN_ID} from 'script/Constants.sol';
import {IntegrationBase} from 'test/integration/arbitrum-sepolia/IntegrationBase.t.sol';

import {IEBOStorage} from 'src/interfaces/common/IEBOStorage.sol';

import {IEBOCore} from 'src/interfaces/modules/IEBOCore.sol';

import {IHorizonStaking} from 'src/interfaces/external/IHorizonStaking.sol';

contract IntegrationResolveByPledges is IntegrationBase {
  uint256 internal _disputerWonProposalId;
  uint256 internal _disputerLostProposalId;
  uint256 internal _noResolutionProposalId;
  uint256 internal _rewardPerWinningPledge;

  function setUp() public override {
    super.setUp();

    _rewardPerWinningPledge = initParams.parameters.pledgeBondSize * 2 / 3;

    // Create a proposal, dispute it, and make the disputer win
    _propose(ETHEREUM_CHAIN_ID, ARBITRUM_SEPOLIA_START_EPOCH, _proposerA);
    _dispute(_lastProposalId);
    _pledgeForDispute(_lastProposalId, _pledgerA);
    _pledgeAgainstDispute(_lastProposalId, _pledgerB);
    _pledgeForDispute(_lastProposalId, _pledgerC);
    _disputerWonProposalId = _lastProposalId;

    // Create a proposal, dispute it, and make the disputer lose
    _propose(ETHEREUM_CHAIN_ID, _lastProposalEpoch + 1, _proposerB);
    _dispute(_lastProposalId, _disputerB);
    _pledgeAgainstDispute(_lastProposalId, _pledgerD);
    _pledgeForDispute(_lastProposalId, _pledgerE);
    _pledgeAgainstDispute(_lastProposalId, _pledgerF);
    _disputerLostProposalId = _lastProposalId;

    // Create a proposal, and dispute it without any pledges
    _propose(ETHEREUM_CHAIN_ID, _lastProposalEpoch + 1, _proposerC);
    _dispute(_lastProposalId, _disputerC);
    _noResolutionProposalId = _lastProposalId;
  }

  function test_ResolveByPledges_Revert_ProposalNotDisputed() public {
    // Create a new proposal
    _propose(ETHEREUM_CHAIN_ID, _lastProposalEpoch + 1, _proposerD);

    vm.expectRevert(IEBOCore.EBOCore_Resolve_ProposalNotDisputed.selector);

    // Call resolve on the active proposal
    eboProxy.resolve(_lastProposalId);

    // Elapse the dispute window
    vm.warp(_lastProposalCreatedAt + initParams.parameters.disputeWindow);

    // Finalize the proposal
    _finalize(_lastProposalId);

    vm.expectRevert(IEBOCore.EBOCore_Resolve_ProposalNotDisputed.selector);

    // Call resolve on the finalized proposal
    eboProxy.resolve(_lastProposalId);
  }

  function test_ResolveByPledges_Revert_PledgeWindowNotOver() public {
    vm.expectRevert(IEBOCore.EBOCore_Resolve_PledgeWindowNotOver.selector);

    // Call resolve on a proposal with a non-finalized pledge window where the disputer is leading
    eboProxy.resolve(_disputerWonProposalId);

    vm.expectRevert(IEBOCore.EBOCore_Resolve_PledgeWindowNotOver.selector);

    // Call resolve on a proposal with a non-finalized pledge window where the disputer is behind
    eboProxy.resolve(_disputerLostProposalId);

    vm.expectRevert(IEBOCore.EBOCore_Resolve_PledgeWindowNotOver.selector);

    // Call resolve on a proposal with a non-finalized pledge window that has no pledges
    eboProxy.resolve(_noResolutionProposalId);
  }

  function test_ResolveByPledges_DisputerWon() public {
    // End the pledge window
    vm.warp(_lastDisputeCreatedAt + initParams.parameters.pledgeWindow);

    // Call resolve on a proposal where the disputer won
    eboProxy.resolve(_disputerWonProposalId);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboProxy.proposals(_disputerWonProposalId);

    (,,,,, uint256 _queriedDisputeRewardPerWinningPledge) = eboProxy.disputes(_disputerWonProposalId);

    // Proposer's provision
    IHorizonStaking.Provision memory _proposerProvision = horizonStaking.getProvision(_proposerA, address(eboProxy));

    // Disputer's provision
    IHorizonStaking.Provision memory _disputerProvision = horizonStaking.getProvision(_disputerA, address(eboProxy));

    // Pledgers' provisions
    IHorizonStaking.Provision memory _pledgerAProvision = horizonStaking.getProvision(_pledgerA, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerBProvision = horizonStaking.getProvision(_pledgerB, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerCProvision = horizonStaking.getProvision(_pledgerC, address(eboProxy));

    // Check the bonders' bonds
    assertEq(eboProxy.bonds(_proposerA), 0);
    assertEq(eboProxy.bonds(_disputerA), 0);
    assertEq(eboProxy.bonds(_pledgerA), 0);
    assertEq(eboProxy.bonds(_pledgerB), 0);
    assertEq(eboProxy.bonds(_pledgerC), 0);

    // Check the proposal status
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.DisputerWon));

    // Check the proposers' balance
    assertEq(grt.balanceOf(_proposerA), 0);

    // Check the disputers' balance
    assertEq(grt.balanceOf(_disputerA), _proposerAndDisputerStake);

    // Check the reward per winning pledge
    assertEq(_queriedDisputeRewardPerWinningPledge, _rewardPerWinningPledge);

    // Check the provisions of the non-slashed pledgers
    assertEq(_pledgerAProvision.tokens, _pledgerStake);
    assertEq(_pledgerCProvision.tokens, _pledgerStake);

    // Check the provisions of the slashed pledgers
    assertEq(_pledgerBProvision.tokens, _pledgerStake - initParams.parameters.pledgeBondSize * 2);

    // Check the provisions of the disputer
    assertEq(_disputerProvision.tokens, _proposerAndDisputerStake);

    // Check the provisions of the proposer
    assertEq(_proposerProvision.tokens, 0);

    // Check the balance of the EBO contract
    assertEq(grt.balanceOf(address(eboProxy)), initParams.parameters.pledgeBondSize * 2);
  }

  function test_ResolveByPledges_DisputerLost() public {
    // End the pledge window
    vm.warp(_lastDisputeCreatedAt + initParams.parameters.pledgeWindow);

    // Call resolve on a proposal where the disputer lost
    eboProxy.resolve(_disputerLostProposalId);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboProxy.proposals(_disputerLostProposalId);

    (,,,,, uint256 _queriedDisputeRewardPerWinningPledge) = eboProxy.disputes(_disputerLostProposalId);

    // Proposer's provision
    IHorizonStaking.Provision memory _proposerBProvision = horizonStaking.getProvision(_proposerB, address(eboProxy));

    // Disputer's provision
    IHorizonStaking.Provision memory _disputerBProvision = horizonStaking.getProvision(_disputerB, address(eboProxy));

    // Pledgers' provisions
    IHorizonStaking.Provision memory _pledgerDProvision = horizonStaking.getProvision(_pledgerD, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerEProvision = horizonStaking.getProvision(_pledgerE, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerFProvision = horizonStaking.getProvision(_pledgerF, address(eboProxy));

    // Check the bonders' bonds
    assertEq(eboProxy.bonds(_proposerB), 0);
    assertEq(eboProxy.bonds(_disputerB), 0);
    assertEq(eboProxy.bonds(_pledgerD), 0);
    assertEq(eboProxy.bonds(_pledgerE), 0);
    assertEq(eboProxy.bonds(_pledgerF), 0);

    // Check the proposal status
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.DisputerLost));

    // Check the proposerB's balance
    assertEq(grt.balanceOf(_proposerB), _proposerAndDisputerStake);

    // Check the disputerB's balance
    assertEq(grt.balanceOf(_disputerB), 0);

    // Check the reward per winning pledge
    assertEq(_queriedDisputeRewardPerWinningPledge, _rewardPerWinningPledge);

    // Check the provisions of the non-slashed pledgers
    assertEq(_pledgerDProvision.tokens, _pledgerStake);
    assertEq(_pledgerFProvision.tokens, _pledgerStake);

    // Check the provisions of the slashed pledgers
    assertEq(_pledgerEProvision.tokens, _pledgerStake - initParams.parameters.pledgeBondSize * 2);

    // Check the provisions of the disputerB
    assertEq(_disputerBProvision.tokens, 0);

    // Check the provisions of the proposerB
    assertEq(_proposerBProvision.tokens, _proposerAndDisputerStake);

    // Check the balance of the EBO contract
    assertEq(grt.balanceOf(address(eboProxy)), initParams.parameters.pledgeBondSize * 2);
  }

  function test_ResolveByPledges_NoResolution() public {
    // End the pledge window
    vm.warp(_lastDisputeCreatedAt + initParams.parameters.pledgeWindow);

    // Call resolve on a proposal with a 0-0 result
    eboProxy.resolve(_noResolutionProposalId);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboProxy.proposals(_noResolutionProposalId);

    (,,,,, uint256 _queriedDisputeRewardPerWinningPledge) = eboProxy.disputes(_noResolutionProposalId);

    // Proposer's provision
    IHorizonStaking.Provision memory _proposerCProvision = horizonStaking.getProvision(_proposerC, address(eboProxy));

    // Disputer's provision
    IHorizonStaking.Provision memory _disputerCProvision = horizonStaking.getProvision(_disputerC, address(eboProxy));

    // Check the bonders' bonds
    assertEq(eboProxy.bonds(_proposerC), 0);
    assertEq(eboProxy.bonds(_disputerC), 0);

    // Check the proposal status
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.NoResolution));

    // Check the proposers' balance
    assertEq(grt.balanceOf(_proposerC), 0);

    // Check the disputers' balance
    assertEq(grt.balanceOf(_disputerC), 0);

    // Check the reward per winning pledge
    assertEq(_queriedDisputeRewardPerWinningPledge, 0);

    // Check the provisions of the disputer
    assertEq(_disputerCProvision.tokens, _proposerAndDisputerStake);

    // Check the provisions of the proposer
    assertEq(_proposerCProvision.tokens, _proposerAndDisputerStake);

    // Check the balance of the EBO contract
    assertEq(grt.balanceOf(address(eboProxy)), 0);
  }

  function test_ResolveByPledges_DisputerWon_MinThawingPeriodPassed_NoResolutionForced() public {
    // Elapse the min thawing period
    vm.warp(_lastProposalCreatedAt + initParams.parameters.minThawingPeriod + 1);

    // Call resolve on a proposal where the disputer won
    eboProxy.resolve(_disputerWonProposalId);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboProxy.proposals(_disputerWonProposalId);

    (,,,,, uint256 _queriedDisputeRewardPerWinningPledge) = eboProxy.disputes(_disputerWonProposalId);

    // Proposer's provision
    IHorizonStaking.Provision memory _proposerProvision = horizonStaking.getProvision(_proposerA, address(eboProxy));

    // Disputer's provision
    IHorizonStaking.Provision memory _disputerProvision = horizonStaking.getProvision(_disputerA, address(eboProxy));

    // Pledgers' provisions
    IHorizonStaking.Provision memory _pledgerAProvision = horizonStaking.getProvision(_pledgerA, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerBProvision = horizonStaking.getProvision(_pledgerB, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerCProvision = horizonStaking.getProvision(_pledgerC, address(eboProxy));

    // Check the bonders' bonds
    assertEq(eboProxy.bonds(_proposerA), 0);
    assertEq(eboProxy.bonds(_disputerA), 0);
    assertEq(eboProxy.bonds(_pledgerA), 0);
    assertEq(eboProxy.bonds(_pledgerB), 0);
    assertEq(eboProxy.bonds(_pledgerC), 0);

    // Check the proposal status
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.NoResolution));

    // Check the proposers' balance
    assertEq(grt.balanceOf(_proposerA), 0);

    // Check the disputers' balance
    assertEq(grt.balanceOf(_disputerA), 0);

    // Check the reward per winning pledge
    assertEq(_queriedDisputeRewardPerWinningPledge, 0);

    // Check the provisions of the pledgers
    assertEq(_pledgerAProvision.tokens, _pledgerStake);
    assertEq(_pledgerCProvision.tokens, _pledgerStake);
    assertEq(_pledgerBProvision.tokens, _pledgerStake);

    // Check the provisions of the disputer
    assertEq(_disputerProvision.tokens, _proposerAndDisputerStake);

    // Check the provisions of the proposer
    assertEq(_proposerProvision.tokens, _proposerAndDisputerStake);

    // Check the balance of the EBO contract
    assertEq(grt.balanceOf(address(eboProxy)), 0);
  }

  function test_ResolveByPledges_DisputerLost_MinThawingPeriodPassed_NoResolutionForced() public {
    // Elapse the min thawing period
    vm.warp(_lastProposalCreatedAt + initParams.parameters.minThawingPeriod + 1);

    // Call resolve on a proposal where the disputer lost
    eboProxy.resolve(_disputerLostProposalId);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboProxy.proposals(_disputerLostProposalId);

    (,,,,, uint256 _queriedDisputeRewardPerWinningPledge) = eboProxy.disputes(_disputerLostProposalId);

    // Proposer's provision
    IHorizonStaking.Provision memory _proposerBProvision = horizonStaking.getProvision(_proposerB, address(eboProxy));

    // Disputer's provision
    IHorizonStaking.Provision memory _disputerBProvision = horizonStaking.getProvision(_disputerB, address(eboProxy));

    // Pledgers' provisions
    IHorizonStaking.Provision memory _pledgerDProvision = horizonStaking.getProvision(_pledgerD, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerEProvision = horizonStaking.getProvision(_pledgerE, address(eboProxy));
    IHorizonStaking.Provision memory _pledgerFProvision = horizonStaking.getProvision(_pledgerF, address(eboProxy));

    // Check the bonders' bonds
    assertEq(eboProxy.bonds(_proposerB), 0);
    assertEq(eboProxy.bonds(_disputerB), 0);
    assertEq(eboProxy.bonds(_pledgerD), 0);
    assertEq(eboProxy.bonds(_pledgerE), 0);
    assertEq(eboProxy.bonds(_pledgerF), 0);

    // Check the proposal status
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.NoResolution));

    // Check the proposerB's balance
    assertEq(grt.balanceOf(_proposerB), 0);

    // Check the disputerB's balance
    assertEq(grt.balanceOf(_disputerB), 0);

    // Check the reward per winning pledge
    assertEq(_queriedDisputeRewardPerWinningPledge, 0);

    // Check the provisions of the pledgers
    assertEq(_pledgerDProvision.tokens, _pledgerStake);
    assertEq(_pledgerFProvision.tokens, _pledgerStake);
    assertEq(_pledgerEProvision.tokens, _pledgerStake);

    // Check the provisions of the disputerB
    assertEq(_disputerBProvision.tokens, _proposerAndDisputerStake);

    // Check the provisions of the proposerB
    assertEq(_proposerBProvision.tokens, _proposerAndDisputerStake);

    // Check the balance of the EBO contract
    assertEq(grt.balanceOf(address(eboProxy)), 0);
  }
}
