// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {ETHEREUM_CHAIN_ID} from 'script/Constants.sol';
import {IntegrationBase} from 'test/integration/arbitrum-sepolia/IntegrationBase.t.sol';

import {IEBOStorage} from 'src/interfaces/common/IEBOStorage.sol';
import {IEBOCore} from 'src/interfaces/modules/IEBOCore.sol';

contract IntegrationFinalize is IntegrationBase {
  function setUp() public override {
    super.setUp();
    _propose(ETHEREUM_CHAIN_ID);
  }

  function test_FinalizeProposal_Revert_DisputeWindowNotOver() public {
    // Revert if the dispute window is not over
    vm.expectRevert(IEBOCore.EBOCore_Finalize_DisputeWindowNotOver.selector);

    _finalize(_lastProposalId);
  }

  function test_FinalizeProposal_Revert_ProposalNotActive() public {
    // Revert if the proposal is not active
    vm.expectRevert(IEBOCore.EBOCore_Finalize_ProposalNotActive.selector);

    _finalize(_lastProposalId + 1);
  }

  function test_FinalizeProposal() public {
    // Elapse the dispute window
    vm.warp(_lastProposalCreatedAt + initParams.parameters.disputeWindow);

    // Check the ProposalFinalized event emission
    vm.expectEmit();
    emit IEBOCore.ProposalFinalized(_lastProposalId, _lastProposalEpoch, ETHEREUM_CHAIN_ID, _lastProposalBlockNumber);

    // Finalize the proposal
    _finalize(_lastProposalId);

    (
      uint256 _queriedEpoch,
      string memory _queriedChainId,
      uint256 _queriedBlockNumber,
      address _queriedProposer,
      uint256 _queriedProposalCreatedAt,
      uint256 _queriedParametersSnapshotId,
      IEBOStorage.ProposalStatus _queriedProposalStatus
    ) = eboProxy.proposals(_lastProposalId);

    // Check the proposal data
    assertEq(_queriedEpoch, _lastProposalEpoch);
    assertEq(_queriedChainId, ETHEREUM_CHAIN_ID);
    assertEq(_queriedBlockNumber, _lastProposalBlockNumber);
    assertEq(_queriedProposer, _proposerA);
    assertEq(_queriedProposalCreatedAt, _lastProposalCreatedAt);
    assertEq(_queriedParametersSnapshotId, 1);
    assertEq(uint8(_queriedProposalStatus), uint8(IEBOStorage.ProposalStatus.Finalized));

    // Check if the proposal is active
    assertEq(eboProxy.activeProposal(_lastProposalEpoch, ETHEREUM_CHAIN_ID), _lastProposalId);

    // Check if the bond of the proposer was released
    assertEq(eboProxy.bonds(_proposerA), 0);
  }
}
