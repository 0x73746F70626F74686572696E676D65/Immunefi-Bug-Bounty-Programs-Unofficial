// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {EBO, IEBO} from '../../../src/contracts/EBO.sol';
import {IEBOStorage} from '../../../src/interfaces/common/IEBOStorage.sol';
import {IEpochManager} from '../../../src/interfaces/external/IEpochManager.sol';
import {IHorizonStaking} from '../../../src/interfaces/external/IHorizonStaking.sol';

import {MockEpochManager} from './mocks/MockEpochManager.sol';
import {MockHorizonStaking} from './mocks/MockHorizonStaking.sol';
import {FuzzERC20} from './utils/FuzzERC20.sol';
import {FuzzUtils, IStdCheats} from './utils/FuzzUtils.sol';

import {AddressSet, LibAddressSet} from './utils/AddressSet.sol';
import {IERC20} from '@openzeppelin/contracts/token/ERC20/IERC20.sol';
import {UnsafeUpgrades} from '@openzeppelin/foundry-upgrades/src/Upgrades.sol';

contract Setup is FuzzUtils {
  using LibAddressSet for AddressSet;

  IStdCheats internal vm = IStdCheats(0x7109709ECfa91a80626fF3989D68f67F5b1DD12D);

  AddressSet internal _actors;
  address internal currentActor;

  modifier createActor() {
    currentActor = msg.sender;
    _actors.add(msg.sender);
    _;
  }

  modifier useActor(uint256 actorIndexSeed) {
    currentActor = _actors.rand(actorIndexSeed);
    _;
  }

  FuzzERC20 internal grt;
  MockHorizonStaking internal horizonStaking;
  MockEpochManager internal epochManager;
  address internal arbitrator;
  address internal council;
  EBO internal ebo;

  uint8 constant RESOLUTION_DISPUTER_WON = 4;
  uint8 constant RESOLUTION_NO_RESOLUTION = 6;
  uint256 constant MIN_THAWING_PERIOD = 15 days;
  uint256 constant ARBITRATOR_RESOLUTION_WINDOW = 7 days;
  uint256 constant PROPOSAL_BOND_SIZE = 15e3 ether;
  uint256 constant PLEDGE_BOND_SIZE = 15e3 ether;
  uint256 constant PLEDGE_WINDOW = 2 days;
  uint256 constant PLEDGE_REFRESH_WINDOW = 1 days;
  uint256 constant MAX_NUMBER_OF_PLEDGES = 4;
  uint256 constant DISPUTE_WINDOW = 12 hours;
  uint256 constant START_EPOCH = 1;
  string[] internal chainIds;

  /*//////////////////////////////////////////////////////////////
                            Ghost
  //////////////////////////////////////////////////////////////*/
  struct ProposalWithId {
    IEBOStorage.Proposal proposal;
    uint256 id;
  }

  ProposalWithId[] internal ghost_activeProposals;
  ProposalWithId[] internal ghost_disputedProposals;
  ProposalWithId[] internal ghost_escalatedProposals;
  ProposalWithId[] internal ghost_resolvedProposals;

  mapping(uint256 _proposalId => uint256 _totalPledgesForDispute) internal ghost_totalPledgesForDispute;
  mapping(uint256 _proposalId => uint256 _totalPledgesAgainstDispute) internal ghost_totalPledgesAgainstDispute;

  constructor() {
    grt = new FuzzERC20();
    horizonStaking = new MockHorizonStaking(grt);
    epochManager = new MockEpochManager();
    arbitrator = makeAddr('Arbitrator');
    council = makeAddr('Council');
    ebo = EBO(UnsafeUpgrades.deployUUPSProxy(address(new EBO()), abi.encodeCall(EBO.initialize, (_setInitParams()))));

    vm.label(address(ebo), 'EBO');
    vm.label(arbitrator, 'Arbitrator');
    vm.label(council, 'Council');
    vm.label(address(horizonStaking), 'HorizonStaking');
    vm.label(address(epochManager), 'EpochManager');
    vm.label(address(grt), 'GRT');
  }

  function _setInitParams() internal returns (IEBO.EBOInitializationParams memory) {
    chainIds = new string[](2);
    chainIds[0] = '1';
    chainIds[1] = '10';

    IEBOStorage.Parameters memory _parameters = IEBOStorage.Parameters({
      proposalBondSize: PROPOSAL_BOND_SIZE,
      minThawingPeriod: MIN_THAWING_PERIOD,
      pledgeBondSize: PLEDGE_BOND_SIZE,
      pledgeWindow: PLEDGE_WINDOW,
      pledgeRefreshWindow: PLEDGE_REFRESH_WINDOW,
      maxNumberOfPledges: MAX_NUMBER_OF_PLEDGES,
      disputeWindow: DISPUTE_WINDOW
    });

    IEBO.EBOInitializationParams memory initParams = IEBO.EBOInitializationParams({
      arbitrator: makeAddr('Arbitrator'),
      council: makeAddr('Council'),
      grt: IERC20(address(grt)),
      horizonStaking: IHorizonStaking(address(horizonStaking)),
      // For the EpochManager at the fork block number, the current epoch (currentEpoch()) is 10
      epochManager: IEpochManager(address(epochManager)),
      // The startEpoch is 1
      startEpoch: START_EPOCH,
      chainIds: chainIds,
      parameters: _parameters,
      arbitratorResolutionWindow: ARBITRATOR_RESOLUTION_WINDOW
    });

    return initParams;
  }
}
