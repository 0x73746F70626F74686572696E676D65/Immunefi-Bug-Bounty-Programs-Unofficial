// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {BondManager, IBondManager} from 'contracts/common/BondManager.sol';

import {IEBOStorage} from 'interfaces/IEBO.sol';
import {IHorizonStaking} from 'interfaces/external/IHorizonStaking.sol';

import {EBOStorageHelper} from 'test/utils/EBOStorageHelper.t.sol';
import {EBOTestHelpers} from 'test/utils/EBOTestHelpers.t.sol';

/**
 * @title BondManager unit tests
 */
contract BondManagerUnit is EBOTestHelpers {
  // Contracts
  BondManagerForTest public bondManager;

  // EOAs
  address public bonder;

  // Variables
  IHorizonStaking.Provision public provisionData;

  function setUp() public override {
    bondManager = new BondManagerForTest();

    bonder = makeAddr('bonder');

    // Set up the contract storage
    bondManager.setHorizonStakingForTest(IHorizonStaking(horizonStaking));
  }

  function test_Unbond_RevertWhen_TheAmountIsGreaterThanBondersBondSize(
    uint256 _bondSize,
    uint256 _amountToUnbound
  ) external {
    _bondSize = bound(_bondSize, 1, type(uint256).max - 1);
    _amountToUnbound = bound(_amountToUnbound, _bondSize + 1, type(uint256).max);

    // When the amount is greater than bonder's bond size
    bondManager.setBondsForTest(bonder, _bondSize);

    // It should revert
    vm.expectRevert(IBondManager.BondManager_Unbond_InsufficientBondedTokens.selector);
    bondManager.unbond(bonder, _amountToUnbound);
  }

  function test_Unbond_WhenTheAmountIsLessThanOrEqualToTheBondersBondSize(
    uint256 _bondSize,
    uint256 _amountToUnbound
  ) external {
    _bondSize = bound(_bondSize, 1, type(uint256).max);
    _amountToUnbound = bound(_amountToUnbound, 1, _bondSize);

    // When the amount is less or equal to bonder's bond size
    bondManager.setBondsForTest(bonder, _bondSize);

    bondManager.unbond(bonder, _amountToUnbound);

    // It should decrease bonder's bond size
    assertEq(bondManager.bonds(bonder), _bondSize - _amountToUnbound);
  }

  function test_Bond_RevertWhen_TheMaxVerifierCutIsInvalid() external {
    // When the max verifier cut is invalid
    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(IHorizonStaking.getProvision.selector, bonder, address(bondManager)),
      abi.encode(provisionData)
    );

    // It should revert
    vm.expectRevert(IBondManager.BondManager_Bond_InvalidMaxVerifierCut.selector);
    bondManager.bond(bonder, 1);
  }

  function test_Bond_RevertWhen_TheMinThawingPeriodIsInvalid(uint64 _thawingPeriod, uint64 _minThawingPeriod) external {
    _minThawingPeriod = uint64(bound(_minThawingPeriod, 1, type(uint64).max));
    _thawingPeriod = uint64(bound(_thawingPeriod, 0, _minThawingPeriod - 1));

    provisionData = IHorizonStaking.Provision({
      tokens: 0,
      tokensThawing: 0,
      sharesThawing: 0,
      maxVerifierCut: bondManager.MAX_MAX_VERIFIER_CUT(),
      thawingPeriod: _thawingPeriod,
      createdAt: 0,
      maxVerifierCutPending: 0,
      thawingPeriodPending: 0,
      thawingNonce: 0
    });

    // When the min thawing period is invalid
    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(IHorizonStaking.getProvision.selector, bonder, address(bondManager)),
      abi.encode(provisionData)
    );

    bondManager.setParametersForTest({
      _snapshotId: 0,
      _parameters: IEBOStorage.Parameters({
        proposalBondSize: 0,
        pledgeBondSize: 0,
        minThawingPeriod: _minThawingPeriod,
        disputeWindow: 0,
        pledgeWindow: 0,
        pledgeRefreshWindow: 0,
        maxNumberOfPledges: 0
      })
    });

    // It should revert
    vm.expectRevert(IBondManager.BondManager_Bond_InvalidThawingPeriod.selector);
    bondManager.bond(bonder, 1);
  }

  function test_Bond_RevertWhen_TheAmountIsGreaterThanAvailable(
    uint256 _tokens,
    uint256 _tokensThawing,
    uint256 _amountToBond
  ) external {
    _tokens = bound(_tokens, 1, type(uint256).max - 1);
    _tokensThawing = bound(_tokensThawing, 0, _tokens - 1);
    _amountToBond = bound(_amountToBond, _tokens - _tokensThawing + 1, type(uint256).max);

    provisionData = IHorizonStaking.Provision({
      tokens: _tokens,
      tokensThawing: _tokensThawing,
      sharesThawing: 0,
      maxVerifierCut: bondManager.MAX_MAX_VERIFIER_CUT(),
      thawingPeriod: 0,
      createdAt: 0,
      maxVerifierCutPending: 0,
      thawingPeriodPending: 0,
      thawingNonce: 0
    });

    // When the amount is greater than available
    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(IHorizonStaking.getProvision.selector, bonder, address(bondManager)),
      abi.encode(provisionData)
    );

    // It should revert
    vm.expectRevert(IBondManager.BondManager_Bond_InsufficientNonThawingTokens.selector);
    bondManager.bond(bonder, _amountToBond);
  }

  function test_Bond_RevertWhen_TheBondersBondSizeIsGreaterThanAvailable(
    uint256 _tokens,
    uint256 _tokensThawing,
    uint256 _amountToBond,
    uint256 _bondSize
  ) external {
    _tokens = bound(_tokens, 1, type(uint128).max - 1);
    _tokensThawing = bound(_tokensThawing, 0, _tokens - 1);
    _amountToBond = bound(_amountToBond, 1, _tokens - _tokensThawing);
    _bondSize = bound(_bondSize, _tokens - _tokensThawing, type(uint128).max);

    provisionData = IHorizonStaking.Provision({
      tokens: _tokens,
      tokensThawing: _tokensThawing,
      sharesThawing: 0,
      maxVerifierCut: bondManager.MAX_MAX_VERIFIER_CUT(),
      thawingPeriod: 0,
      createdAt: 0,
      maxVerifierCutPending: 0,
      thawingPeriodPending: 0,
      thawingNonce: 0
    });

    // When the bonder's bond size is greater than available
    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(IHorizonStaking.getProvision.selector, bonder, address(bondManager)),
      abi.encode(provisionData)
    );

    bondManager.setBondsForTest(bonder, _bondSize);

    // It should revert
    vm.expectRevert(IBondManager.BondManager_Bond_BondedTokensExceedNonThawingTokens.selector);
    bondManager.bond(bonder, _amountToBond);
  }

  function test_Bond_WhenAllPreconditionsAreMet(
    uint256 _tokens,
    uint256 _tokensThawing,
    uint256 _amountToBond
  ) external {
    _tokens = bound(_tokens, 1, type(uint256).max - 1);
    _tokensThawing = bound(_tokensThawing, 0, _tokens - 1);
    _amountToBond = bound(_amountToBond, 1, _tokens - _tokensThawing);

    provisionData = IHorizonStaking.Provision({
      tokens: _tokens,
      tokensThawing: _tokensThawing,
      sharesThawing: 0,
      maxVerifierCut: bondManager.MAX_MAX_VERIFIER_CUT(),
      thawingPeriod: 0,
      createdAt: 0,
      maxVerifierCutPending: 0,
      thawingPeriodPending: 0,
      thawingNonce: 0
    });

    // When all preconditions are met
    _mockAndExpect(
      horizonStaking,
      abi.encodeWithSelector(IHorizonStaking.getProvision.selector, bonder, address(bondManager)),
      abi.encode(provisionData)
    );

    bondManager.bond(bonder, _amountToBond);

    // It should increase bonder's bond size
    assertEq(bondManager.bonds(bonder), _amountToBond);
  }
}

contract BondManagerForTest is BondManager, EBOStorageHelper {
  function unbond(address _bonder, uint256 _amount) external {
    _unbond(_bonder, _amount);
  }

  function bond(address _bonder, uint256 _amount) external {
    _bond(_bonder, _amount);
  }
}
