// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {EBOTestHelpers} from 'test/utils/EBOTestHelpers.t.sol';

import {Initializable} from '@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol';
import {IERC1967} from '@openzeppelin/contracts/interfaces/IERC1967.sol';
import {IERC20} from '@openzeppelin/contracts/token/ERC20/IERC20.sol';
import {UnsafeUpgrades} from '@openzeppelin/foundry-upgrades/src/Upgrades.sol';

import {EBO, IEBO} from 'contracts/EBO.sol';
import {IAccessManager} from 'interfaces/common/IAccessManager.sol';
import {IEBOStorage} from 'interfaces/common/IEBOStorage.sol';
import {IEBOConfig} from 'interfaces/modules/IEBOConfig.sol';
import {IEBOCore} from 'interfaces/modules/IEBOCore.sol';
import {IEBOPledge} from 'interfaces/modules/IEBOPledge.sol';

import {IEpochManager} from 'interfaces/external/IEpochManager.sol';
import {IHorizonStaking} from 'interfaces/external/IHorizonStaking.sol';

/**
 * @title EBO unit tests
 */
contract EBOUnit is EBOTestHelpers {
  // Contracts
  EBO public ebo;
  EBO public eboProxy;

  // Variables
  IEBOStorage.Parameters public parameters;
  IEBO.EBOInitializationParams public initParams;

  function setUp() public override {
    super.setUp();

    parameters = IEBOStorage.Parameters({
      proposalBondSize: 15_000 ether,
      pledgeBondSize: 15_000 ether,
      minThawingPeriod: 2 weeks,
      disputeWindow: 12 hours,
      pledgeWindow: 2 days,
      pledgeRefreshWindow: 1 days,
      maxNumberOfPledges: 4
    });

    initParams = IEBO.EBOInitializationParams({
      arbitrator: arbitrator,
      council: council,
      grt: IERC20(grt),
      horizonStaking: IHorizonStaking(horizonStaking),
      epochManager: IEpochManager(epochManager),
      startEpoch: 0,
      chainIds: new string[](0),
      parameters: parameters,
      arbitratorResolutionWindow: 7 days
    });

    ebo = new EBO();
    eboProxy = EBO(UnsafeUpgrades.deployUUPSProxy(address(ebo), abi.encodeCall(EBO.initialize, (initParams))));
  }

  function test_Constructor_WhenCalled() external {
    // It should emit the Initialized event
    vm.expectEmit();
    emit Initializable.Initialized(type(uint64).max);

    new EBO();
  }

  function test_Initialize_RevertWhen_TheCallIsNotDelegated() external {
    // It should revert
    vm.expectRevert(Initializable.InvalidInitialization.selector);

    // When the call is not delegated
    ebo.initialize(initParams);
  }

  function test_Initialize_RevertWhen_TheEBOProxyIsAlreadyInitialized() external {
    // When the EBOProxy is already initialized

    // It should revert
    vm.expectRevert(Initializable.InvalidInitialization.selector);
    eboProxy.initialize(initParams);
  }

  function test_Initialize_RevertWhen_TheArbitratorIsTheZeroAddress() external {
    // When the arbitrator is the zero address
    initParams.arbitrator = address(0);

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_SetArbitrator_AddressAlreadySet.selector);
    UnsafeUpgrades.deployUUPSProxy(address(ebo), abi.encodeCall(EBO.initialize, (initParams)));
  }

  function test_Initialize_RevertWhen_TheCouncilIsTheZeroAddress() external {
    // When the council is the zero address
    initParams.council = address(0);

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_SetCouncil_AddressAlreadySet.selector);
    UnsafeUpgrades.deployUUPSProxy(address(ebo), abi.encodeCall(EBO.initialize, (initParams)));
  }

  function test_Initialize_RevertWhen_TheGRTTokenContractIsTheZeroAddress() external {
    // When the GRT token contract is the zero address
    initParams.grt = IERC20(address(0));

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_SetGRT_AddressAlreadySet.selector);
    UnsafeUpgrades.deployUUPSProxy(address(ebo), abi.encodeCall(EBO.initialize, (initParams)));
  }

  function test_Initialize_RevertWhen_TheHorizonStakingContractIsTheZeroAddress() external {
    // When the HorizonStaking contract is the zero address
    initParams.horizonStaking = IHorizonStaking(address(0));

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_SetHorizonStaking_AddressAlreadySet.selector);
    UnsafeUpgrades.deployUUPSProxy(address(ebo), abi.encodeCall(EBO.initialize, (initParams)));
  }

  function test_Initialize_RevertWhen_TheEpochManagerContractIsTheZeroAddress() external {
    // When the EpochManager contract is the zero address
    initParams.epochManager = IEpochManager(address(0));

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_SetEpochManager_AddressAlreadySet.selector);
    UnsafeUpgrades.deployUUPSProxy(address(ebo), abi.encodeCall(EBO.initialize, (initParams)));
  }

  function test_Initialize_RevertWhen_TheChainIdIsAlreadyAdded(string memory _chainId) external {
    // When the chain id is already added
    string[] memory _chainIds = new string[](2);
    _chainIds[0] = _chainId;
    _chainIds[1] = _chainId;

    initParams.chainIds = _chainIds;

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_AddChainIds_ChainIdAlreadyAdded.selector);
    UnsafeUpgrades.deployUUPSProxy(address(ebo), abi.encodeCall(EBO.initialize, (initParams)));
  }

  function test_Initialize_RevertWhen_TheProposalBondSizeIsZero() external {
    // When the proposal bond size is zero
    parameters.proposalBondSize = 0;
    initParams.parameters = parameters;

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_ParametersCannotBeZero.selector);
    UnsafeUpgrades.deployUUPSProxy(address(ebo), abi.encodeCall(EBO.initialize, (initParams)));
  }

  function test_Initialize_RevertWhen_ThePledgeBondSizeIsZero() external {
    // When the pledge bond size is zero
    parameters.pledgeBondSize = 0;
    initParams.parameters = parameters;

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_ParametersCannotBeZero.selector);
    UnsafeUpgrades.deployUUPSProxy(address(ebo), abi.encodeCall(EBO.initialize, (initParams)));
  }

  function test_Initialize_RevertWhen_TheDisputeWindowIsZero() external {
    // When the dispute window is zero
    parameters.disputeWindow = 0;
    initParams.parameters = parameters;

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_ParametersCannotBeZero.selector);
    UnsafeUpgrades.deployUUPSProxy(address(ebo), abi.encodeCall(EBO.initialize, (initParams)));
  }

  function test_Initialize_RevertWhen_ThePledgeRefreshWindowIsZero() external {
    // When the pledge refresh window is zero
    parameters.pledgeRefreshWindow = 0;
    initParams.parameters = parameters;

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_ParametersCannotBeZero.selector);
    UnsafeUpgrades.deployUUPSProxy(address(ebo), abi.encodeCall(EBO.initialize, (initParams)));
  }

  function test_Initialize_RevertWhen_TheArbitratorResolutionWindowIsZero() external {
    // When the arbitrator resolution window is zero
    initParams.arbitratorResolutionWindow = 0;

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_ParametersCannotBeZero.selector);
    UnsafeUpgrades.deployUUPSProxy(address(ebo), abi.encodeCall(EBO.initialize, (initParams)));
  }

  function test_Initialize_RevertWhen_ThePledgeRefreshWindowIsGreaterThanPledgeWindow(
    uint256 _pledgeWindow,
    uint256 _pledgeRefreshWindow
  ) external {
    // When the pledge refresh window is greater than pledge window
    _pledgeWindow = bound(_pledgeWindow, 1, type(uint32).max);
    _pledgeRefreshWindow = bound(_pledgeRefreshWindow, _pledgeWindow + 1, type(uint64).max);

    parameters.pledgeWindow = _pledgeWindow;
    parameters.pledgeRefreshWindow = _pledgeRefreshWindow;
    initParams.parameters = parameters;

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_PledgeRefreshWindowExceedsPledgeWindow.selector);
    UnsafeUpgrades.deployUUPSProxy(address(ebo), abi.encodeCall(EBO.initialize, (initParams)));
  }

  function test_Initialize_RevertWhen_TheMinThawingPeriodIsTooShort(
    IEBOStorage.Parameters memory _parameters,
    uint256 _arbitratorResolutionWindow
  ) external {
    _parameters.disputeWindow = bound(_parameters.disputeWindow, 1, type(uint32).max);
    _parameters.pledgeRefreshWindow = bound(_parameters.pledgeRefreshWindow, 1, type(uint32).max);
    _parameters.pledgeWindow = bound(_parameters.pledgeWindow, _parameters.pledgeRefreshWindow + 1, type(uint64).max);
    _parameters.maxNumberOfPledges = bound(_parameters.maxNumberOfPledges, 1, type(uint64).max);
    _arbitratorResolutionWindow = bound(_arbitratorResolutionWindow, 1, type(uint32).max);

    uint256 _maxProposalLifecycleDuration = _getMaxProposalLifecycleDuration(
      _parameters.disputeWindow,
      _parameters.pledgeWindow,
      _parameters.pledgeRefreshWindow,
      _parameters.maxNumberOfPledges,
      _arbitratorResolutionWindow
    );

    // When the min thawing period is too short
    _parameters.minThawingPeriod = bound(_parameters.minThawingPeriod, 1, _maxProposalLifecycleDuration - 1);

    parameters.disputeWindow = _parameters.disputeWindow;
    parameters.pledgeWindow = _parameters.pledgeWindow;
    parameters.pledgeRefreshWindow = _parameters.pledgeRefreshWindow;
    parameters.maxNumberOfPledges = _parameters.maxNumberOfPledges;
    parameters.minThawingPeriod = _parameters.minThawingPeriod;
    initParams.parameters = parameters;
    initParams.arbitratorResolutionWindow = _arbitratorResolutionWindow;

    // It should revert
    vm.expectRevert(IEBOConfig.EBOConfig_CheckParameters_MinThawingPeriodTooShort.selector);
    UnsafeUpgrades.deployUUPSProxy(address(ebo), abi.encodeCall(EBO.initialize, (initParams)));
  }

  function test_Initialize_WhenAllThePreconditionsAreMet(
    uint256 _startEpoch,
    string memory _chainId,
    IEBOStorage.Parameters memory _parameters,
    uint256 _arbitratorResolutionWindow
  ) external {
    string[] memory _chainIds = new string[](1);
    _chainIds[0] = _chainId;

    _parameters.proposalBondSize = bound(_parameters.proposalBondSize, 1, type(uint256).max);
    _parameters.pledgeBondSize = bound(_parameters.pledgeBondSize, 1, type(uint256).max);
    _parameters.disputeWindow = bound(_parameters.disputeWindow, 1, type(uint32).max);
    _parameters.pledgeRefreshWindow = bound(_parameters.pledgeRefreshWindow, 1, type(uint32).max);
    _parameters.pledgeWindow = bound(_parameters.pledgeWindow, _parameters.pledgeRefreshWindow + 1, type(uint64).max);
    _parameters.maxNumberOfPledges = bound(_parameters.maxNumberOfPledges, 1, type(uint64).max);
    _arbitratorResolutionWindow = bound(_arbitratorResolutionWindow, 1, type(uint32).max);

    uint256 _maxProposalLifecycleDuration = _getMaxProposalLifecycleDuration(
      _parameters.disputeWindow,
      _parameters.pledgeWindow,
      _parameters.pledgeRefreshWindow,
      _parameters.maxNumberOfPledges,
      _arbitratorResolutionWindow
    );

    _parameters.minThawingPeriod = bound(_parameters.minThawingPeriod, _maxProposalLifecycleDuration, type(uint128).max);

    uint256 _expectedSnapshotId = 1;

    IEBO.EBOInitializationParams memory _initParams = IEBO.EBOInitializationParams({
      arbitrator: arbitrator,
      council: council,
      grt: IERC20(grt),
      horizonStaking: IHorizonStaking(horizonStaking),
      epochManager: IEpochManager(epochManager),
      startEpoch: _startEpoch,
      chainIds: _chainIds,
      parameters: _parameters,
      arbitratorResolutionWindow: _arbitratorResolutionWindow
    });

    // It should emit the Upgraded event
    vm.expectEmit();
    emit IERC1967.Upgraded(address(ebo));

    // It should emit the ArbitratorSet event
    vm.expectEmit();
    emit IEBOConfig.ArbitratorSet(_initParams.arbitrator);

    // It should emit the CouncilSet event
    vm.expectEmit();
    emit IEBOConfig.CouncilSet(_initParams.council);

    // It should emit the GRTSet event
    vm.expectEmit();
    emit IEBOConfig.GRTSet(_initParams.grt);

    // It should emit the HorizonStakingSet event
    vm.expectEmit();
    emit IEBOConfig.HorizonStakingSet(_initParams.horizonStaking);

    // It should emit the EpochManagerSet event
    vm.expectEmit();
    emit IEBOConfig.EpochManagerSet(_initParams.epochManager);

    // It should emit the StartEpochSet event
    vm.expectEmit();
    emit IEBOConfig.StartEpochSet(_initParams.startEpoch);

    // It should emit the ChainIdAdded event
    vm.expectEmit();
    emit IEBOConfig.ChainIdAdded(_chainId);

    // It should emit the ParametersSet event
    vm.expectEmit();
    emit IEBOConfig.ParametersSet(_parameters, _expectedSnapshotId, _arbitratorResolutionWindow);

    // It should emit the Initialized event
    vm.expectEmit();
    emit Initializable.Initialized(1);

    eboProxy = EBO(UnsafeUpgrades.deployUUPSProxy(address(ebo), abi.encodeCall(EBO.initialize, (_initParams))));

    // It should initialize the EBOProxy with the correct initial parameters
    assertEq(eboProxy.arbitrator(), arbitrator);
    assertEq(eboProxy.council(), council);
    assertEq(address(eboProxy.grt()), grt);
    assertEq(address(eboProxy.horizonStaking()), horizonStaking);
    assertEq(address(eboProxy.epochManager()), epochManager);
    assertEq(eboProxy.startEpoch(), _initParams.startEpoch);
    assertEq(eboProxy.chainIdsAllowed(_chainId), true);

    IEBOStorage.Parameters memory _queriedParameters;
    (
      _queriedParameters.proposalBondSize,
      _queriedParameters.pledgeBondSize,
      _queriedParameters.minThawingPeriod,
      _queriedParameters.disputeWindow,
      _queriedParameters.pledgeWindow,
      _queriedParameters.pledgeRefreshWindow,
      _queriedParameters.maxNumberOfPledges
    ) = eboProxy.parametersSnapshots(_expectedSnapshotId);

    assertEq(eboProxy.parametersSnapshotId(), _expectedSnapshotId);
    assertEq(_queriedParameters.proposalBondSize, _parameters.proposalBondSize);
    assertEq(_queriedParameters.pledgeBondSize, _parameters.pledgeBondSize);
    assertEq(_queriedParameters.disputeWindow, _parameters.disputeWindow);
    assertEq(_queriedParameters.pledgeWindow, _parameters.pledgeWindow);
    assertEq(_queriedParameters.pledgeRefreshWindow, _parameters.pledgeRefreshWindow);
    assertEq(_queriedParameters.maxNumberOfPledges, _parameters.maxNumberOfPledges);
    assertEq(_queriedParameters.minThawingPeriod, _parameters.minThawingPeriod);
  }

  function test_Propose_WhenCalled(
    uint256 _epoch,
    string calldata _chainId,
    uint256 _blockNumber,
    address _serviceProvider
  ) external {
    // It should delegate to the EBO implementation
    _mockAndExpect(
      address(ebo), abi.encodeCall(IEBOCore.propose, (_epoch, _chainId, _blockNumber, _serviceProvider)), ''
    );

    eboProxy.propose(_epoch, _chainId, _blockNumber, _serviceProvider);
  }

  function test_Dispute_WhenCalled(uint256 _proposalId, address _serviceProvider) external {
    // It should delegate to the EBO implementation
    _mockAndExpect(address(ebo), abi.encodeCall(IEBOCore.dispute, (_proposalId, _serviceProvider)), '');

    eboProxy.dispute(_proposalId, _serviceProvider);
  }

  function test_ResolveByPledges_WhenCalled(uint256 _proposalId) external {
    // It should delegate to the EBO implementation
    _mockAndExpect(address(ebo), abi.encodeWithSignature('resolve(uint256)', _proposalId), '');

    eboProxy.resolve(_proposalId);
  }

  function test_ResolveByArbitration_WhenCalled(uint256 _proposalId, uint8 _status) external {
    // It should delegate to the EBO implementation
    _status = uint8(_bound(_status, 0, 7));

    _mockAndExpect(address(ebo), abi.encodeWithSignature('resolve(uint256,uint8)', _proposalId, _status), '');

    eboProxy.resolve(_proposalId, IEBOStorage.ProposalStatus(_status));
  }

  function test_Finalize_WhenCalled(uint256 _epoch) external {
    // It should delegate to the EBO implementation
    _mockAndExpect(address(ebo), abi.encodeCall(IEBOCore.finalize, (_epoch)), '');

    eboProxy.finalize(_epoch);
  }

  function test_AmendEpochBlock_WhenCalled(uint256 _epoch, uint256 _blockNumber) external {
    // It should delegate to the EBO implementation
    _mockAndExpect(address(ebo), abi.encodeCall(IEBOCore.amendEpochBlock, (_epoch, _blockNumber)), '');

    eboProxy.amendEpochBlock(_epoch, _blockNumber);
  }

  function test_ClaimPledgeReward_WhenCalled(uint256 _proposalId, address _pledger) external {
    // It should delegate to the EBO implementation
    _mockAndExpect(address(ebo), abi.encodeCall(IEBOPledge.claimPledgeReward, (_proposalId, _pledger)), '');

    eboProxy.claimPledgeReward(_proposalId, _pledger);
  }

  function test_PledgeForDispute_WhenCalled(uint256 _proposalId, address _pledger) external {
    // It should delegate to the EBO implementation
    _mockAndExpect(address(ebo), abi.encodeCall(IEBOPledge.pledgeForDispute, (_proposalId, _pledger)), '');

    eboProxy.pledgeForDispute(_proposalId, _pledger);
  }

  function test_PledgeAgainstDispute_WhenCalled(uint256 _proposalId, address _pledger) external {
    // It should delegate to the EBO implementation
    _mockAndExpect(address(ebo), abi.encodeCall(IEBOPledge.pledgeAgainstDispute, (_proposalId, _pledger)), '');

    eboProxy.pledgeAgainstDispute(_proposalId, _pledger);
  }

  function test_SetArbitrator_WhenCalled(address _arbitrator) external {
    // It should delegate to the EBO implementation
    _mockAndExpect(address(ebo), abi.encodeCall(IEBOConfig.setArbitrator, (_arbitrator)), '');

    eboProxy.setArbitrator(_arbitrator);
  }

  function test_SetPendingCouncil_WhenCalled(address _council) external {
    // It should delegate to the EBO implementation
    _mockAndExpect(address(ebo), abi.encodeCall(IEBOConfig.setPendingCouncil, (_council)), '');

    eboProxy.setPendingCouncil(_council);
  }

  function test_ConfirmCouncil_WhenCalled() external {
    // It should delegate to the EBO implementation
    _mockAndExpect(address(ebo), abi.encodeCall(IEBOConfig.confirmCouncil, ()), '');

    eboProxy.confirmCouncil();
  }

  function test_SetGRT_WhenCalled(IERC20 _grt) external {
    // It should delegate to the EBO implementation
    _mockAndExpect(address(ebo), abi.encodeCall(IEBOConfig.setGRT, (_grt)), '');

    eboProxy.setGRT(_grt);
  }

  function test_SetHorizonStaking_WhenCalled(IHorizonStaking _horizonStaking) external {
    // It should delegate to the EBO implementation
    _mockAndExpect(address(ebo), abi.encodeCall(IEBOConfig.setHorizonStaking, (_horizonStaking)), '');

    eboProxy.setHorizonStaking(_horizonStaking);
  }

  function test_SetEpochManager_WhenCalled(IEpochManager _epochManager) external {
    // It should delegate to the EBO implementation
    _mockAndExpect(address(ebo), abi.encodeCall(IEBOConfig.setEpochManager, (_epochManager)), '');

    eboProxy.setEpochManager(_epochManager);
  }

  function test_AddChainIds_WhenCalled(string[] calldata _chainIds) external {
    // It should delegate to the EBO implementation
    _mockAndExpect(address(ebo), abi.encodeCall(IEBOConfig.addChainIds, (_chainIds)), '');

    eboProxy.addChainIds(_chainIds);
  }

  function test_RemoveChainIds_WhenCalled(string[] calldata _chainIds) external {
    // It should delegate to the EBO implementation
    _mockAndExpect(address(ebo), abi.encodeCall(IEBOConfig.removeChainIds, (_chainIds)), '');

    eboProxy.removeChainIds(_chainIds);
  }

  function test_SetParameters_WhenCalled(
    IEBOStorage.Parameters calldata _parameters,
    uint256 _arbitratorResolutionWindow
  ) external {
    // It should delegate to the EBO implementation
    _mockAndExpect(
      address(ebo), abi.encodeCall(IEBOConfig.setParameters, (_parameters, _arbitratorResolutionWindow)), ''
    );

    eboProxy.setParameters(_parameters, _arbitratorResolutionWindow);
  }

  function test_Version_WhenCalled() external view {
    // It should return the semantic version
    string memory _version = ebo.version();
    assertEq(_version, '1.0.0');
  }

  modifier givenTheCallerIsTheCouncil() {
    vm.startPrank(council);
    _;
  }

  modifier givenTheCallerIsNotTheCouncil() {
    vm.startPrank(notProtocolActor);
    _;
  }

  function test_UpgradeToAndCall_RevertGiven_TheCallerIsNotTheCouncil() external givenTheCallerIsNotTheCouncil {
    // It should revert
    vm.expectRevert(IAccessManager.AccessManager_OnlyCouncil_NotCouncil.selector);

    eboProxy.upgradeToAndCall(address(0), '');
  }

  function test_UpgradeToAndCall_GivenTheCallerIsTheCouncil() external givenTheCallerIsTheCouncil {
    address _newImplementation = address(new EBO());
    eboProxy.upgradeToAndCall(_newImplementation, '');

    bytes32 _implSlot = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;

    address _queriedImplementation = address(uint160(uint256(vm.load(address(eboProxy), _implSlot))));

    // It should upgrade the EBO contract to the implementation address
    assertEq(_queriedImplementation, _newImplementation);
  }
}
