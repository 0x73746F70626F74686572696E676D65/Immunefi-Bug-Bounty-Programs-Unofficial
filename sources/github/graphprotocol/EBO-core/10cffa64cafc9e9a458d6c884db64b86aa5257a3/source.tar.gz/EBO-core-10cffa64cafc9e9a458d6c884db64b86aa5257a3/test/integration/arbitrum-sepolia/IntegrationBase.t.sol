// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {TestHelpers} from 'test/utils/TestHelpers.t.sol';

import {Deploy} from 'script/Deploy.s.sol';

import {IEBOStorage} from 'interfaces/common/IEBOStorage.sol';

import {IERC20} from '@openzeppelin/contracts/token/ERC20/IERC20.sol';

import {IEpochManager} from 'interfaces/external/IEpochManager.sol';
import {IHorizonStaking} from 'interfaces/external/IHorizonStaking.sol';

import {IEBO} from 'interfaces/IEBO.sol';
import {IEBOStorage} from 'interfaces/common/IEBOStorage.sol';

import {
  ARBITRATOR_RESOLUTION_WINDOW,
  ARBITRUM_SEPOLIA_EPOCH_MANAGER,
  ARBITRUM_SEPOLIA_GRAPH_TOKEN,
  ARBITRUM_SEPOLIA_HORIZON_STAKING,
  ARBITRUM_SEPOLIA_START_EPOCH,
  DISPUTE_WINDOW,
  ETHEREUM_CHAIN_ID,
  MAX_NUMBER_OF_PLEDGES,
  MIN_THAWING_PERIOD,
  OPTIMISM_CHAIN_ID,
  PLEDGE_BOND_SIZE,
  PLEDGE_REFRESH_WINDOW,
  PLEDGE_WINDOW,
  PROPOSAL_BOND_SIZE
} from 'script/Constants.sol';

contract IntegrationBase is Deploy, TestHelpers {
  string internal constant _NONEXISTENT_CHAIN_ID = '0';
  uint256 internal constant _ARBITRUM_SEPOLIA_FORK_BLOCK = 129_675_425;

  // Actors

  // Proposers
  address internal _proposerA;
  address internal _proposerB;
  address internal _proposerC;
  address internal _proposerD;
  address internal _proposerE;
  address internal _proposerF;

  // Disputers
  address internal _disputerA;
  address internal _disputerB;
  address internal _disputerC;
  address internal _disputerD;
  address internal _disputerE;
  address internal _disputerF;

  // Pledgers
  address internal _pledgerA;
  address internal _pledgerB;
  address internal _pledgerC;
  address internal _pledgerD;
  address internal _pledgerE;
  address internal _pledgerF;
  address internal _pledgerG;
  address internal _pledgerH;
  address internal _pledgerI;
  address internal _pledgerJ;
  address internal _pledgerK;
  address internal _pledgerL;
  address internal _pledgerM;
  address internal _pledgerN;
  address internal _pledgerO;
  address internal _pledgerP;
  address internal _pledgerQ;
  address internal _pledgerR;

  // Operators
  address internal _proposersOperator;
  address internal _disputersOperator;
  address internal _pledgersOperator;

  address internal _invalidBonder;

  address[] internal _proposers;
  address[] internal _disputers;
  address[] internal _pledgers;

  // Data
  uint256 internal _lastProposalId;
  uint256 internal _lastProposalEpoch;
  uint256 internal _lastProposalBlockNumber;
  uint256 internal _lastProposalCreatedAt;
  uint256 internal _lastPledgeTimestamp;
  uint256 internal _lastDisputeCreatedAt;

  uint256 internal _pledgerStake;
  uint256 internal _proposerAndDisputerStake;
  uint256 internal _maxNotEscalatedRewardPerWinningPledge;

  uint256 internal _serviceProviderOrOperatorSeed;

  function setUp() public virtual override {
    vm.createSelectFork(vm.rpcUrl('arbitrum-sepolia'), _ARBITRUM_SEPOLIA_FORK_BLOCK);

    super.setUp();
    // Set actor accounts
    _setProposers();
    _setDisputers();
    _setPledgers();
    _invalidBonder = makeAddr('InvalidBonder');

    // Set initial stake values
    _pledgerStake = initParams.parameters.pledgeBondSize * initParams.parameters.maxNumberOfPledges;
    _proposerAndDisputerStake = initParams.parameters.proposalBondSize;

    // Run deployment script
    run();

    // Set Operators
    _setOperators();

    _maxNotEscalatedRewardPerWinningPledge = initParams.parameters.pledgeBondSize
      * (initParams.parameters.maxNumberOfPledges - 1) / initParams.parameters.maxNumberOfPledges;

    // Stake GRT and create initial provisions
    _initalGRTStake();
    _createInitialProvisions();
  }

  /**
   * Chooses between the service provider and the operator for the next calls
   * @param _serviceProvider The service provider address
   * @param _operator The operator address
   */
  modifier asServiceProviderOrOperator(address _serviceProvider, address _operator) {
    address _caller = _serviceProvider;
    if (_serviceProvider != _invalidBonder) {
      if (_serviceProviderOrOperatorSeed % 2 == 0) {
        _caller = _operator;
      }
      _serviceProviderOrOperatorSeed++;
    }
    vm.startPrank(_caller);
    _;
    vm.stopPrank();
  }

  /// @inheritdoc Deploy
  function _setInitParams() internal override {
    string[] memory _chainIds = new string[](2);
    _chainIds[0] = ETHEREUM_CHAIN_ID;
    _chainIds[1] = OPTIMISM_CHAIN_ID;

    IEBOStorage.Parameters memory _parameters = IEBOStorage.Parameters({
      proposalBondSize: PROPOSAL_BOND_SIZE,
      minThawingPeriod: MIN_THAWING_PERIOD,
      pledgeBondSize: PLEDGE_BOND_SIZE,
      pledgeWindow: PLEDGE_WINDOW,
      pledgeRefreshWindow: PLEDGE_REFRESH_WINDOW,
      maxNumberOfPledges: MAX_NUMBER_OF_PLEDGES,
      disputeWindow: DISPUTE_WINDOW
    });

    initParams = IEBO.EBOInitializationParams({
      arbitrator: makeAddr('Arbitrator'),
      council: makeAddr('Council'),
      grt: IERC20(ARBITRUM_SEPOLIA_GRAPH_TOKEN),
      horizonStaking: IHorizonStaking(ARBITRUM_SEPOLIA_HORIZON_STAKING),
      // For the EpochManager at the fork block number, the current epoch (currentEpoch()) is 10
      epochManager: IEpochManager(ARBITRUM_SEPOLIA_EPOCH_MANAGER),
      // The startEpoch is 1
      startEpoch: ARBITRUM_SEPOLIA_START_EPOCH,
      chainIds: _chainIds,
      parameters: _parameters,
      arbitratorResolutionWindow: ARBITRATOR_RESOLUTION_WINDOW
    });
  }

  function _initalGRTStake() internal {
    for (uint256 _i = 0; _i < _proposers.length; _i++) {
      _stakeGRT(_proposers[_i], _proposerAndDisputerStake);
    }
    for (uint256 _i = 0; _i < _disputers.length; _i++) {
      _stakeGRT(_disputers[_i], _proposerAndDisputerStake);
    }
    for (uint256 _i = 0; _i < _pledgers.length; _i++) {
      _stakeGRT(_pledgers[_i], _pledgerStake);
    }
  }

  function _createInitialProvisions() internal {
    for (uint256 _i = 0; _i < _proposers.length; _i++) {
      _provision(
        _proposers[_i],
        _proposerAndDisputerStake,
        eboProxy.MAX_MAX_VERIFIER_CUT(),
        uint64(initParams.parameters.minThawingPeriod)
      );
    }
    for (uint256 _i = 0; _i < _disputers.length; _i++) {
      _provision(
        _disputers[_i],
        _proposerAndDisputerStake,
        eboProxy.MAX_MAX_VERIFIER_CUT(),
        uint64(initParams.parameters.minThawingPeriod)
      );
    }
    for (uint256 _i = 0; _i < _pledgers.length; _i++) {
      _provision(
        _pledgers[_i], _pledgerStake, eboProxy.MAX_MAX_VERIFIER_CUT(), uint64(initParams.parameters.minThawingPeriod)
      );
    }
  }

  function _stakeGRT(address _actor, uint256 _amount) internal {
    vm.startPrank(_actor);
    deal(address(grt), _actor, _amount, true);
    grt.approve(address(horizonStaking), _amount);
    horizonStaking.stake(_amount);
    vm.stopPrank();
  }

  function _thawGRT(address _actor, uint256 _amount) internal {
    vm.startPrank(_actor);
    horizonStaking.thaw(_actor, address(eboProxy), _amount);
    vm.stopPrank();
  }

  function _provision(address _provisioner, uint256 _amount, uint32 _maxVerifierCut, uint64 _thawingPeriod) internal {
    vm.startPrank(_provisioner);
    horizonStaking.provision({
      serviceProvider: _provisioner,
      verifier: address(eboProxy),
      tokens: _amount,
      maxVerifierCut: _maxVerifierCut,
      thawingPeriod: _thawingPeriod
    });
    vm.stopPrank();
  }

  function _propose(string memory _chainId) internal {
    // Fetch current epoch
    _lastProposalEpoch = initParams.epochManager.currentEpoch();
    _propose(_chainId, _lastProposalEpoch, _proposerA);
  }

  function _propose(
    string memory _chainId,
    uint256 _epoch,
    address _proposalSender
  ) internal asServiceProviderOrOperator(_proposalSender, _proposersOperator) {
    _lastProposalEpoch = _epoch;
    _lastProposalBlockNumber = block.number;
    eboProxy.propose(_epoch, _chainId, _lastProposalBlockNumber, _proposalSender);
    _lastProposalId++;
    _lastProposalCreatedAt = block.timestamp;
  }

  function _dispute(uint256 _proposalId) internal {
    _dispute(_proposalId, _disputerA);
  }

  function _dispute(
    uint256 _proposalId,
    address _proposalDisputer
  ) internal asServiceProviderOrOperator(_proposalDisputer, _disputersOperator) {
    eboProxy.dispute(_proposalId, _proposalDisputer);
    _lastDisputeCreatedAt = block.timestamp;
  }

  function _pledgeForDispute(
    uint256 _proposalId,
    address _pledger
  ) internal asServiceProviderOrOperator(_pledger, _pledgersOperator) {
    eboProxy.pledgeForDispute(_proposalId, _pledger);
    _lastPledgeTimestamp = block.timestamp;
  }

  function _pledgeAgainstDispute(
    uint256 _proposalId,
    address _pledger
  ) internal asServiceProviderOrOperator(_pledger, _pledgersOperator) {
    eboProxy.pledgeAgainstDispute(_proposalId, _pledger);
    _lastPledgeTimestamp = block.timestamp;
  }

  function _resolve(uint256 _proposalId) internal {
    eboProxy.resolve(_proposalId);
  }

  function _resolve(uint256 _proposalId, IEBOStorage.ProposalStatus _resolutionStatus) internal {
    vm.prank(arbitrator);
    eboProxy.resolve(_proposalId, _resolutionStatus);
  }

  function _claimPledgeReward(uint256 _proposalId, address _pledger) internal {
    eboProxy.claimPledgeReward(_proposalId, _pledger);
  }

  function _finalize(uint256 _proposalId) internal {
    eboProxy.finalize(_proposalId);
  }

  function _amendEpochBlock(uint256 _proposalId, uint256 _blockNumber) internal {
    vm.prank(arbitrator);
    eboProxy.amendEpochBlock(_proposalId, _blockNumber);
  }

  function _setProposers() private {
    _proposerA = makeAddr('ProposerA');
    _proposerB = makeAddr('ProposerB');
    _proposerC = makeAddr('ProposerC');
    _proposerD = makeAddr('ProposerD');
    _proposerE = makeAddr('ProposerE');
    _proposerF = makeAddr('ProposerF');

    _proposers.push(_proposerA);
    _proposers.push(_proposerB);
    _proposers.push(_proposerC);
    _proposers.push(_proposerD);
    _proposers.push(_proposerE);
    _proposers.push(_proposerF);
  }

  function _setDisputers() private {
    _disputerA = makeAddr('DisputerA');
    _disputerB = makeAddr('DisputerB');
    _disputerC = makeAddr('DisputerC');
    _disputerD = makeAddr('DisputerD');
    _disputerE = makeAddr('DisputerE');
    _disputerF = makeAddr('DisputerF');

    _disputers.push(_disputerA);
    _disputers.push(_disputerB);
    _disputers.push(_disputerC);
    _disputers.push(_disputerD);
    _disputers.push(_disputerE);
    _disputers.push(_disputerF);
  }

  function _setPledgers() private {
    _pledgerA = makeAddr('PledgerA');
    _pledgerB = makeAddr('PledgerB');
    _pledgerC = makeAddr('PledgerC');
    _pledgerD = makeAddr('PledgerD');
    _pledgerE = makeAddr('PledgerE');
    _pledgerF = makeAddr('PledgerF');
    _pledgerG = makeAddr('PledgerG');
    _pledgerH = makeAddr('PledgerH');
    _pledgerI = makeAddr('PledgerI');
    _pledgerJ = makeAddr('PledgerJ');
    _pledgerK = makeAddr('PledgerK');
    _pledgerL = makeAddr('PledgerL');
    _pledgerM = makeAddr('PledgerM');
    _pledgerN = makeAddr('PledgerN');
    _pledgerO = makeAddr('PledgerO');
    _pledgerP = makeAddr('PledgerP');
    _pledgerQ = makeAddr('PledgerQ');
    _pledgerR = makeAddr('PledgerR');

    _pledgers.push(_pledgerA);
    _pledgers.push(_pledgerB);
    _pledgers.push(_pledgerC);
    _pledgers.push(_pledgerD);
    _pledgers.push(_pledgerE);
    _pledgers.push(_pledgerF);
    _pledgers.push(_pledgerG);
    _pledgers.push(_pledgerH);
    _pledgers.push(_pledgerI);
    _pledgers.push(_pledgerJ);
    _pledgers.push(_pledgerK);
    _pledgers.push(_pledgerL);
    _pledgers.push(_pledgerM);
    _pledgers.push(_pledgerN);
    _pledgers.push(_pledgerO);
    _pledgers.push(_pledgerP);
    _pledgers.push(_pledgerQ);
    _pledgers.push(_pledgerR);
  }

  function _setOperators() private {
    _proposersOperator = makeAddr('ProposersOperator');
    _disputersOperator = makeAddr('DisputersOperator');
    _pledgersOperator = makeAddr('PledgersOperator');

    for (uint256 _i = 0; _i < _proposers.length; _i++) {
      vm.prank(_proposers[_i]);
      horizonStaking.setOperator({verifier: address(eboProxy), operator: _proposersOperator, allowed: true});
    }

    for (uint256 _i = 0; _i < _disputers.length; _i++) {
      vm.prank(_disputers[_i]);
      horizonStaking.setOperator({verifier: address(eboProxy), operator: _disputersOperator, allowed: true});
    }

    for (uint256 _i = 0; _i < _pledgers.length; _i++) {
      vm.prank(_pledgers[_i]);
      horizonStaking.setOperator({verifier: address(eboProxy), operator: _pledgersOperator, allowed: true});
    }
  }
}

contract SanityChecks is IntegrationBase {
  function test_FinalizeSanityCheck() public {
    _propose(ETHEREUM_CHAIN_ID);

    // The dispute window elapses
    vm.warp(block.timestamp + initParams.parameters.disputeWindow);

    _finalize(_lastProposalId);

    (
      uint256 _queriedEpoch,
      string memory _queriedChainId,
      uint256 _queriedBlockNumber,
      address _queriedProposer,
      uint256 _queriedProposalCreatedAt,
      uint256 _queriedParametersSnapshotId,
      IEBOStorage.ProposalStatus _queriedProposalStatus
    ) = eboProxy.proposals(_lastProposalId);

    assertEq(_queriedEpoch, _lastProposalEpoch);
    assertEq(_queriedChainId, ETHEREUM_CHAIN_ID);
    assertEq(_queriedBlockNumber, _lastProposalBlockNumber);
    assertEq(_queriedProposer, _proposerA);
    assertEq(_queriedProposalCreatedAt, _lastProposalCreatedAt);
    assertEq(_queriedParametersSnapshotId, 1);
    assertEq(uint8(_queriedProposalStatus), uint8(IEBOStorage.ProposalStatus.Finalized));
  }

  function test_ResolveByPledgesSanityCheck() public {
    _propose(ETHEREUM_CHAIN_ID);
    _dispute(_lastProposalId);
    _pledgeForDispute(_lastProposalId, _pledgerA);
    _pledgeAgainstDispute(_lastProposalId, _pledgerB);

    vm.warp(block.timestamp + initParams.parameters.pledgeWindow);
    _resolve(_lastProposalId);

    (
      uint256 _queriedEpoch,
      string memory _queriedChainId,
      uint256 _queriedBlockNumber,
      address _queriedProposer,
      uint256 _queriedProposalCreatedAt,
      uint256 _queriedParametersSnapshotId,
      IEBOStorage.ProposalStatus _queriedProposalStatus
    ) = eboProxy.proposals(_lastProposalId);

    assertEq(_queriedEpoch, _lastProposalEpoch);
    assertEq(_queriedChainId, ETHEREUM_CHAIN_ID);
    assertEq(_queriedBlockNumber, _lastProposalBlockNumber);
    assertEq(_queriedProposer, _proposerA);
    assertEq(_queriedProposalCreatedAt, _lastProposalCreatedAt);
    assertEq(_queriedParametersSnapshotId, 1);
    assertEq(uint8(_queriedProposalStatus), uint8(IEBOStorage.ProposalStatus.DisputerLost));

    assertEq(grt.balanceOf(_proposerA), _proposerAndDisputerStake);

    // Claim pledge reward
    _claimPledgeReward(_lastProposalId, _pledgerB);
    assertEq(grt.balanceOf(_pledgerB), initParams.parameters.pledgeBondSize);
  }

  function test_ResolveByArbitrationSanityCheck() public {
    _propose(ETHEREUM_CHAIN_ID);
    _dispute(_lastProposalId);

    _pledgeForDispute(_lastProposalId, _pledgerA);
    _pledgeAgainstDispute(_lastProposalId, _pledgerB);

    _pledgeForDispute(_lastProposalId, _pledgerA);
    _pledgeAgainstDispute(_lastProposalId, _pledgerB);

    // Last pledge for reaching the max number of pledges for both sides of the dispute
    _pledgeForDispute(_lastProposalId, _pledgerA);

    _resolve(_lastProposalId, IEBOStorage.ProposalStatus.DisputerWon);

    (
      uint256 _queriedEpoch,
      string memory _queriedChainId,
      uint256 _queriedBlockNumber,
      address _queriedProposer,
      uint256 _queriedProposalCreatedAt,
      uint256 _queriedParametersSnapshotId,
      IEBOStorage.ProposalStatus _queriedProposalStatus
    ) = eboProxy.proposals(_lastProposalId);

    assertEq(_queriedEpoch, _lastProposalEpoch);
    assertEq(_queriedChainId, ETHEREUM_CHAIN_ID);
    assertEq(_queriedBlockNumber, block.number);
    assertEq(_queriedProposer, _proposerA);
    assertEq(_queriedProposalCreatedAt, block.timestamp);
    assertEq(_queriedParametersSnapshotId, 1);
    assertEq(uint8(_queriedProposalStatus), uint8(IEBOStorage.ProposalStatus.DisputerWon));
    assertEq(grt.balanceOf(_disputerA), _proposerAndDisputerStake);

    // Claim pledge reward
    _claimPledgeReward(_lastProposalId, _pledgerA);
    assertEq(grt.balanceOf(_pledgerA), _pledgerStake);
  }

  function test_AmendEpochBlockSanityCheck() public {
    _propose(ETHEREUM_CHAIN_ID);

    // The dispute window elapses
    vm.warp(block.timestamp + initParams.parameters.disputeWindow);

    _finalize(_lastProposalId);

    uint256 _amendedBlockNumber = _lastProposalBlockNumber + 1;

    _amendEpochBlock(_lastProposalId, _amendedBlockNumber);

    (
      uint256 _queriedEpoch,
      string memory _queriedChainId,
      uint256 _queriedBlockNumber,
      address _queriedProposer,
      uint256 _queriedProposalCreatedAt,
      uint256 _queriedParametersSnapshotId,
      IEBOStorage.ProposalStatus _queriedProposalStatus
    ) = eboProxy.proposals(_lastProposalId);

    assertEq(_queriedEpoch, _lastProposalEpoch);
    assertEq(_queriedChainId, ETHEREUM_CHAIN_ID);
    assertEq(_queriedBlockNumber, _amendedBlockNumber);
    assertEq(_queriedProposer, _proposerA);
    assertEq(_queriedProposalCreatedAt, _lastProposalCreatedAt);
    assertEq(_queriedParametersSnapshotId, 1);
    assertEq(uint8(_queriedProposalStatus), uint8(IEBOStorage.ProposalStatus.Finalized));
  }
}
