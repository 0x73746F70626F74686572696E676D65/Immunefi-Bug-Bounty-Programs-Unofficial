// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {EBOStorage, IEBOStorage, IERC20, IEpochManager, IHorizonStaking} from 'contracts/common/EBOStorage.sol';

import {EnumerableSet} from '@openzeppelin/contracts/utils/structs/EnumerableSet.sol';

/**
 * @title EBOStorageHelper
 * @notice Helper contract for EBOStorage
 */
contract EBOStorageHelper is EBOStorage {
  using EnumerableSet for EnumerableSet.AddressSet;

  /**
   * @notice Sets all storage variables
   * @param _horizonStaking The HorizonStaking contract address
   * @param _arbitrator The arbitrator address
   * @param _council The council address
   * @param _pendingCouncil The pending council address
   */
  function setAllStorageForTest(
    IHorizonStaking _horizonStaking,
    address _arbitrator,
    address _council,
    address _pendingCouncil
  ) external {
    horizonStaking = _horizonStaking;
    arbitrator = _arbitrator;
    council = _council;
    pendingCouncil = _pendingCouncil;
  }

  /**
   * @notice Sets the GRT token contract address
   * @param _grt The GRT token contract address
   */
  function setGRTForTest(IERC20 _grt) external {
    grt = _grt;
  }

  /**
   * @notice Sets the HorizonStaking contract address
   * @param _horizonStaking The HorizonStaking contract address
   */
  function setHorizonStakingForTest(IHorizonStaking _horizonStaking) external {
    horizonStaking = _horizonStaking;
  }

  /**
   * @notice Sets the arbitrator address
   * @param _arbitrator The arbitrator address
   */
  function setArbitratorForTest(address _arbitrator) external {
    arbitrator = _arbitrator;
  }

  /**
   * @notice Sets the council address
   * @param _council The council address
   */
  function setCouncilForTest(address _council) external {
    council = _council;
  }

  /**
   * @notice Sets the pending council address
   * @param _pendingCouncil The pending council address
   */
  function setPendingCouncilForTest(address _pendingCouncil) external {
    pendingCouncil = _pendingCouncil;
  }

  /**
   * @notice Sets the parameters for a given snapshot ID
   * @param _snapshotId The snapshot ID
   * @param _parameters The parameters
   */
  function setParametersForTest(uint256 _snapshotId, IEBOStorage.Parameters memory _parameters) external {
    parametersSnapshotId = _snapshotId;
    parametersSnapshots[_snapshotId] = _parameters;
  }

  /**
   * @notice Sets the parameters snapshot ID
   * @param _parametersSnapshotId The parameters snapshot ID
   */
  function setParametersSnapshotIdForTest(uint256 _parametersSnapshotId) external {
    parametersSnapshotId = _parametersSnapshotId;
  }

  /**
   * @notice Sets the bonder's total bonded amount
   * @param _bonder The bonder address
   * @param _bondSize The bonder's bonded amount
   */
  function setBondsForTest(address _bonder, uint256 _bondSize) external {
    bonds[_bonder] = _bondSize;
  }

  /**
   * @notice Sets the proposal
   * @param _proposalId The proposal ID
   * @param _proposal The proposal
   */
  function setProposalForTest(uint256 _proposalId, Proposal memory _proposal) external {
    proposals[_proposalId] = _proposal;

    bonds[_proposal.proposer] += parametersSnapshots[_proposal.parametersSnapshotId].proposalBondSize;
  }

  /**
   * @notice Sets the pledges for dispute
   * @param _proposalId The proposal ID
   * @param _pledger The pledger
   * @param _pledgesForDispute The number of pledges in favor of the dispute
   */
  function setPledgesForDisputeForTest(uint256 _proposalId, address _pledger, uint256 _pledgesForDispute) external {
    _disputePledgersFor[_proposalId].add(_pledger);
    bonds[_pledger] += parametersSnapshots[proposals[_proposalId].parametersSnapshotId].pledgeBondSize
    * _pledgesForDispute;
    pledgesForDispute[_proposalId][_pledger] = _pledgesForDispute;
    disputes[_proposalId].totalPledgesForDispute += _pledgesForDispute;
    disputes[_proposalId].lastPledgeTimestamp = block.timestamp;
  }

  /**
   * @notice Sets the pledges against dispute
   * @param _proposalId The proposal ID
   * @param _pledger The pledger
   * @param _pledgesAgainstDispute The number of pledges against the dispute
   */
  function setPledgesAgainstDisputeForTest(
    uint256 _proposalId,
    address _pledger,
    uint256 _pledgesAgainstDispute
  ) external {
    _disputePledgersAgainst[_proposalId].add(_pledger);
    bonds[_pledger] += parametersSnapshots[proposals[_proposalId].parametersSnapshotId].pledgeBondSize
    * _pledgesAgainstDispute;
    pledgesAgainstDispute[_proposalId][_pledger] = _pledgesAgainstDispute;
    disputes[_proposalId].totalPledgesAgainstDispute += _pledgesAgainstDispute;
    disputes[_proposalId].lastPledgeTimestamp = block.timestamp;
  }

  /**
   * @notice Sets the dispute
   * @param _proposalId The proposal ID
   * @param _disputer The disputer
   * @param _createdAt The creation timestamp
   * @param _lastPledgeTimestamp The last pledge timestamp
   */
  function setDisputeForTest(
    uint256 _proposalId,
    address _disputer,
    uint256 _createdAt,
    uint256 _lastPledgeTimestamp
  ) external {
    disputes[_proposalId] = Dispute({
      disputer: _disputer,
      createdAt: _createdAt,
      lastPledgeTimestamp: _lastPledgeTimestamp,
      totalPledgesForDispute: 0,
      totalPledgesAgainstDispute: 0,
      rewardPerWinningPledge: 0
    });

    proposals[_proposalId].status = ProposalStatus.Disputed;

    bonds[_disputer] += parametersSnapshots[proposals[_proposalId].parametersSnapshotId].proposalBondSize;
  }

  /**
   * @notice Sets the dispute total pledges
   * @param _proposalId The proposal ID
   * @param _totalPledgesForDispute The total number of pledges in favor of the dispute
   * @param _totalPledgesAgainstDispute The total number of pledges against the dispute
   */
  function setDisputeTotalPledgesForTest(
    uint256 _proposalId,
    uint256 _totalPledgesForDispute,
    uint256 _totalPledgesAgainstDispute
  ) external {
    disputes[_proposalId].totalPledgesForDispute = _totalPledgesForDispute;
    disputes[_proposalId].totalPledgesAgainstDispute = _totalPledgesAgainstDispute;
  }

  /**
   * @notice Sets the dispute reward per winning pledge
   * @param _proposalId The proposal ID
   * @param _rewardPerWinningPledge The reward per winning pledge
   */
  function setDisputeRewardPerWinningPledgeForTest(uint256 _proposalId, uint256 _rewardPerWinningPledge) external {
    disputes[_proposalId].rewardPerWinningPledge = _rewardPerWinningPledge;
  }

  /**
   * @notice Sets the pledger claimed
   * @param _proposalId The proposal ID
   * @param _pledger The pledger
   */
  function setPledgerClaimedForTest(uint256 _proposalId, address _pledger, bool _claimed) external {
    pledgerClaimed[_proposalId][_pledger] = _claimed;
  }

  /**
   * @notice Sets the active proposal
   * @param _epoch The epoch
   * @param _chainId The chain ID
   * @param _proposalId The proposal ID
   */
  function setActiveProposalForTest(uint256 _epoch, string calldata _chainId, uint256 _proposalId) external {
    activeProposal[_epoch][_chainId] = _proposalId;
  }

  /**
   * @notice Sets the proposal ID
   * @param _proposalId The proposal ID
   */
  function setProposalIdForTest(uint256 _proposalId) external {
    proposalId = _proposalId;
  }

  /**
   * @notice Sets the proposal status
   * @param _proposalId The proposal ID
   * @param _proposalStatus The proposal status
   */
  function setProposalStatusForTest(uint256 _proposalId, IEBOStorage.ProposalStatus _proposalStatus) external {
    proposals[_proposalId].status = _proposalStatus;
  }

  /**
   * @notice Sets the EpochManager contract address
   * @param _epochManager The EpochManager contract address
   */
  function setEpochManagerForTest(IEpochManager _epochManager) external {
    epochManager = _epochManager;
  }

  /**
   * @notice Sets the chain IDs allowed
   * @param _chainId The chain ID
   */
  function setChainIdsAllowedForTest(string calldata _chainId) external {
    chainIdsAllowed[_chainId] = true;
  }

  /**
   * @notice Sets the chain IDs allowed
   * @param _chainIds The chain IDs
   */
  function setChainIdsAllowedForTest(string[] calldata _chainIds) external {
    for (uint256 _i; _i < _chainIds.length; ++_i) {
      chainIdsAllowed[_chainIds[_i]] = true;
    }
  }

  /**
   * @notice Sets the start epoch
   * @param _startEpoch The start epoch
   */
  function setStartEpochForTest(uint256 _startEpoch) external {
    startEpoch = _startEpoch;
  }
}
