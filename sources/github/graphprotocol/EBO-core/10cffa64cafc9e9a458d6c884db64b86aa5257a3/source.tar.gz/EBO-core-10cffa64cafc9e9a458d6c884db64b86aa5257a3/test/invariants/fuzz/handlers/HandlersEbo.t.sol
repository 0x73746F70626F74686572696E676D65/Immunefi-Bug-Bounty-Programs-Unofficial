// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {Setup} from '../Setup.t.sol';
import {IEBOStorage} from 'src/interfaces/common/IEBOStorage.sol';
import {IHorizonStaking} from 'src/interfaces/external/IHorizonStaking.sol';
import {IEBOCore} from 'src/interfaces/modules/IEBOCore.sol';
import {IEBOPledge} from 'src/interfaces/modules/IEBOPledge.sol';

contract HandlersEbo is Setup {
  error HandlersEBO__Error();

  function handler_dispute(uint256 _activeProposalIndex) external createActor {
    if (ebo.proposalId() == 0 || ghost_activeProposals.length == 0) revert HandlersEBO__Error();

    _activeProposalIndex = clampBetween(_activeProposalIndex, 0, ghost_activeProposals.length - 1);
    ProposalWithId memory _activeProposal = ghost_activeProposals[_activeProposalIndex];

    (uint256 _proposalBondSize,,,,,,) = ebo.parametersSnapshots(_activeProposal.proposal.parametersSnapshotId);

    _provisionIfNeeded(currentActor, _proposalBondSize);

    vm.prank(currentActor);
    try ebo.dispute(_activeProposal.id, currentActor) {
      ghost_disputedProposals.push(_activeProposal);
      _removeProposal(ghost_activeProposals, _activeProposalIndex);
    } catch (bytes memory _reason) {
      assert(
        keccak256(_reason) == keccak256(abi.encodeWithSelector(IEBOCore.EBOCore_Dispute_DisputeWindowOver.selector))
      );
    }
  }

  function handler_pledgeAgainstDispute(uint256 _disputedProposalIndex) external createActor {
    if (ghost_disputedProposals.length == 0) revert HandlersEBO__Error();

    _disputedProposalIndex = clampBetween(_disputedProposalIndex, 0, ghost_disputedProposals.length - 1);
    ProposalWithId memory _disputedProposal = ghost_disputedProposals[_disputedProposalIndex];

    (,,,,, uint256 _paramSnapshotId,) = ebo.proposals(_disputedProposal.id);
    (, uint256 _pledgeBondSize,,,,,) = ebo.parametersSnapshots(_paramSnapshotId);

    _provisionIfNeeded(currentActor, _pledgeBondSize * 2);

    vm.prank(currentActor);
    try ebo.pledgeAgainstDispute(_disputedProposal.id, currentActor) {
      (,,,,,, IEBOStorage.ProposalStatus _status) = ebo.proposals(_disputedProposal.id);
      if (_status == IEBOStorage.ProposalStatus.Escalated) {
        _removeProposal(ghost_disputedProposals, _disputedProposalIndex);
        ghost_escalatedProposals.push(_disputedProposal);
      }
    } catch (bytes memory _reason) {
      assert(
        keccak256(_reason) == keccak256(abi.encodeWithSelector(IEBOPledge.EBOPledge_Pledge_PledgeWindowOver.selector))
          || keccak256(_reason)
            == keccak256(abi.encodeWithSelector(IEBOPledge.EBOPledge_Pledge_CannotPledgeIfWinning.selector))
      );
    }
  }

  function handler_pledgeForDispute(uint256 _disputedProposalIndex) external createActor {
    if (ghost_disputedProposals.length == 0) revert HandlersEBO__Error();

    _disputedProposalIndex = clampBetween(_disputedProposalIndex, 0, ghost_disputedProposals.length - 1);
    ProposalWithId memory _disputedProposal = ghost_disputedProposals[_disputedProposalIndex];

    (,,,,, uint256 _paramSnapshotId,) = ebo.proposals(_disputedProposal.id);
    (, uint256 _pledgeBondSize,,,,,) = ebo.parametersSnapshots(_paramSnapshotId);

    _provisionIfNeeded(currentActor, _pledgeBondSize * 2);

    vm.prank(currentActor);
    try ebo.pledgeForDispute(_disputedProposal.id, currentActor) {
      (,,,,,, IEBOStorage.ProposalStatus _status) = ebo.proposals(_disputedProposal.id);
      if (_status == IEBOStorage.ProposalStatus.Escalated) {
        _removeProposal(ghost_disputedProposals, _disputedProposalIndex);
        ghost_escalatedProposals.push(_disputedProposal);
      }
    } catch (bytes memory _reason) {
      assert(
        keccak256(_reason) == keccak256(abi.encodeWithSelector(IEBOPledge.EBOPledge_Pledge_PledgeWindowOver.selector))
          || keccak256(_reason)
            == keccak256(abi.encodeWithSelector(IEBOPledge.EBOPledge_Pledge_CannotPledgeIfWinning.selector))
      );
    }
  }

  function handler_resolveByArbitrator(uint256 _escalatedProposalIndex, uint256 _resolutionStatus) external {
    if (ghost_escalatedProposals.length == 0) revert HandlersEBO__Error();

    _escalatedProposalIndex = clampBetween(_escalatedProposalIndex, 0, ghost_escalatedProposals.length - 1);
    ProposalWithId memory _escalatedProposal = ghost_escalatedProposals[_escalatedProposalIndex];

    _resolutionStatus = clampBetween(_resolutionStatus, RESOLUTION_DISPUTER_WON, RESOLUTION_NO_RESOLUTION);

    vm.prank(arbitrator);
    try ebo.resolve(_escalatedProposal.id, IEBOStorage.ProposalStatus(uint8(_resolutionStatus))) {
      _removeProposal(ghost_escalatedProposals, _escalatedProposalIndex);
      if (
        IEBOStorage.ProposalStatus(uint8(_resolutionStatus)) == IEBOStorage.ProposalStatus.DisputerWon
          || IEBOStorage.ProposalStatus(uint8(_resolutionStatus)) == IEBOStorage.ProposalStatus.DisputerLost
      ) {
        // Check that the minThawingPeriod has not passed
        (,, uint256 _minThawingPeriod,,,,) = ebo.parametersSnapshots(_escalatedProposal.proposal.parametersSnapshotId);
        assert(block.timestamp < _escalatedProposal.proposal.createdAt + _minThawingPeriod);

        ghost_resolvedProposals.push(_escalatedProposal);
      }
    } catch (bytes memory _reason) {
      assert(keccak256(_reason) == keccak256(abi.encodeWithSelector(IEBOCore.EBOCore_Resolve_InvalidStatus.selector)));
    }
  }

  function handler_resolvePermissionless(uint256 _disputedProposalIndex) external createActor {
    if (ghost_disputedProposals.length == 0) revert HandlersEBO__Error();

    _disputedProposalIndex = clampBetween(_disputedProposalIndex, 0, ghost_disputedProposals.length - 1);
    ProposalWithId memory _disputedProposal = ghost_disputedProposals[_disputedProposalIndex];

    vm.prank(currentActor);
    try ebo.resolve(_disputedProposal.id) {
      _removeProposal(ghost_disputedProposals, _disputedProposalIndex);

      (,,,,,, IEBOStorage.ProposalStatus _status) = ebo.proposals(_disputedProposal.id);
      if (_status == IEBOStorage.ProposalStatus.DisputerWon || _status == IEBOStorage.ProposalStatus.DisputerLost) {
        // Check that the minThawingPeriod has not passed
        (,, uint256 _minThawingPeriod,,,,) = ebo.parametersSnapshots(_disputedProposal.proposal.parametersSnapshotId);
        assert(block.timestamp < _disputedProposal.proposal.createdAt + _minThawingPeriod);

        ghost_resolvedProposals.push(_disputedProposal);
      }
    } catch (bytes memory _reason) {
      assert(
        keccak256(_reason) == keccak256(abi.encodeWithSelector(IEBOCore.EBOCore_Resolve_PledgeWindowNotOver.selector))
      );
    }
  }

  function handler_setParameters(
    uint256 _proposalBondSize,
    uint256 _pledgeBondSize,
    uint256 _maxNumberOfPledges
  ) external {
    IEBOStorage.Parameters memory _parameters = IEBOStorage.Parameters({
      proposalBondSize: clampBetween(_proposalBondSize, 1, PROPOSAL_BOND_SIZE),
      minThawingPeriod: MIN_THAWING_PERIOD,
      pledgeBondSize: clampBetween(_pledgeBondSize, 1, PLEDGE_BOND_SIZE),
      pledgeWindow: PLEDGE_WINDOW,
      pledgeRefreshWindow: PLEDGE_REFRESH_WINDOW,
      maxNumberOfPledges: clampBetween(_maxNumberOfPledges, 1, MAX_NUMBER_OF_PLEDGES),
      disputeWindow: DISPUTE_WINDOW
    });

    vm.prank(ebo.council());
    try ebo.setParameters(_parameters, ARBITRATOR_RESOLUTION_WINDOW) {}
    catch (bytes memory _reason) {
      assert(false);
    }
  }

  /*//////////////////////////////////////////////////////////////
                            Helpers
  //////////////////////////////////////////////////////////////*/
  function _provisionIfNeeded(address _actor, uint256 _amount) internal {
    IHorizonStaking.Provision memory _provisionData = horizonStaking.getProvision(_actor, address(ebo));

    if (_provisionData.createdAt == 0) {
      grt.mint(_actor, _amount);
      _stakeAndProvision(_actor, _amount);
    } else {
      uint256 _tokensNotThawing = _provisionData.tokens - _provisionData.tokensThawing;

      uint256 _bondedTokens = ebo.bonds(_actor);

      if (_tokensNotThawing < _bondedTokens + _amount) {
        uint256 _neededTokens = _bondedTokens + _amount - _tokensNotThawing;

        if (grt.balanceOf(_actor) < _neededTokens) {
          grt.mint(_actor, _neededTokens);
        }
        _stakeAndAddToProvision(_actor, _neededTokens);
      }
    }
  }

  function _stakeAndProvision(address _actor, uint256 _amount) internal {
    vm.prank(_actor);
    grt.approve(address(horizonStaking), _amount);

    vm.prank(_actor);
    horizonStaking.stake(_amount);

    (,, uint256 _minThawingPeriod,,,,) = ebo.parametersSnapshots(ebo.parametersSnapshotId());

    vm.prank(_actor);
    horizonStaking.provision(_actor, address(ebo), _amount, ebo.MAX_MAX_VERIFIER_CUT(), uint64(_minThawingPeriod));
  }

  function _stakeAndAddToProvision(address _actor, uint256 _amount) internal {
    vm.prank(_actor);
    grt.approve(address(horizonStaking), _amount);

    vm.prank(_actor);
    horizonStaking.stake(_amount);

    vm.prank(_actor);
    horizonStaking.addToProvision(_actor, address(ebo), _amount);
  }

  function _removeProposal(ProposalWithId[] storage _proposals, uint256 _proposalIndex) internal {
    if (_proposalIndex == _proposals.length - 1) {
      delete _proposals[_proposals.length - 1];
    } else {
      _proposals[_proposalIndex] = _proposals[_proposals.length - 1];
      delete _proposals[_proposals.length - 1];
    }

    _proposals.pop();
  }
}
