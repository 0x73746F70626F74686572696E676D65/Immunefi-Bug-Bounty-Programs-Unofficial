// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {ARBITRUM_SEPOLIA_START_EPOCH, ETHEREUM_CHAIN_ID} from 'script/Constants.sol';
import {IntegrationBase} from 'test/integration/arbitrum-sepolia/IntegrationBase.t.sol';

import {IAccessManager} from 'src/interfaces/common/IAccessManager.sol';
import {IBondManager} from 'src/interfaces/common/IBondManager.sol';

import {IEBOStorage} from 'src/interfaces/common/IEBOStorage.sol';
import {IEBOCore} from 'src/interfaces/modules/IEBOCore.sol';

contract IntegrationDispute is IntegrationBase {
  function setUp() public override {
    super.setUp();
    _propose(ETHEREUM_CHAIN_ID);
  }

  function test_Dispute_Revert_NotOperator() public {
    vm.expectRevert(IAccessManager.AccessManager_OnlyOperator_NotOperator.selector);

    eboProxy.dispute({_proposalId: _lastProposalId, _serviceProvider: _disputerA});
  }

  function test_Dispute_Revert_ProposalNotActive() public {
    vm.expectRevert(IEBOCore.EBOCore_Dispute_ProposalNotActive.selector);

    // Dispute a proposal that is not active
    _dispute(_lastProposalId + 1);
  }

  function test_Dispute_Revert_DisputeWindowOver() public {
    vm.expectRevert(IEBOCore.EBOCore_Dispute_DisputeWindowOver.selector);

    // Elapse the dispute window
    vm.warp(block.timestamp + initParams.parameters.disputeWindow);

    // Dispute when the dispute window is over
    _dispute(_lastProposalId);
  }

  function test_Dispute_Revert_InvalidMaxVerifierCut() public {
    // Stake GRT for proposal
    _stakeGRT(_invalidBonder, initParams.parameters.proposalBondSize);

    // Provision with an invalid max verifier cut
    _provision(
      _invalidBonder,
      initParams.parameters.proposalBondSize,
      eboProxy.MAX_MAX_VERIFIER_CUT() - 1,
      uint64(initParams.parameters.minThawingPeriod)
    );

    vm.expectRevert(IBondManager.BondManager_Bond_InvalidMaxVerifierCut.selector);

    // Dispute with an invalid max verifier cut
    _dispute(_lastProposalId, _invalidBonder);
  }

  function test_Dispute_Revert_InvalidThawingPeriod() public {
    // Stake GRT for proposal
    _stakeGRT(_invalidBonder, initParams.parameters.proposalBondSize);

    // Provision with an invalid thawing period
    _provision(
      _invalidBonder,
      initParams.parameters.proposalBondSize,
      eboProxy.MAX_MAX_VERIFIER_CUT(),
      uint64(initParams.parameters.minThawingPeriod - 1)
    );

    vm.expectRevert(IBondManager.BondManager_Bond_InvalidThawingPeriod.selector);

    // Dispute with an invalid thawing period
    _dispute(_lastProposalId, _invalidBonder);
  }

  function test_Dispute_Revert_InsufficientNonThawingTokens_ProvisionTokensNotEnough() public {
    // Stake GRT for proposal
    _stakeGRT(_invalidBonder, initParams.parameters.proposalBondSize);

    // Provision with an insufficient amount of non-thawing tokens
    _provision(
      _invalidBonder,
      initParams.parameters.proposalBondSize - 1,
      eboProxy.MAX_MAX_VERIFIER_CUT(),
      uint64(initParams.parameters.minThawingPeriod)
    );

    vm.expectRevert(IBondManager.BondManager_Bond_InsufficientNonThawingTokens.selector);

    // Dispute with an insufficient amount of non-thawing tokens
    _dispute(_lastProposalId, _invalidBonder);
  }

  function test_Dispute_Revert_InsufficientNonThawingTokens_ProvisionTokensMinusTokensThawingNotEnough() public {
    // Stake GRT for proposal
    _stakeGRT(_invalidBonder, initParams.parameters.proposalBondSize);

    // Provision with a sufficient amount of tokens
    _provision(
      _invalidBonder,
      initParams.parameters.proposalBondSize,
      eboProxy.MAX_MAX_VERIFIER_CUT(),
      uint64(initParams.parameters.minThawingPeriod)
    );

    // Thaw one unit enough to make the provision insufficient
    _thawGRT(_invalidBonder, 1);

    vm.expectRevert(IBondManager.BondManager_Bond_InsufficientNonThawingTokens.selector);

    // Dispute with an insufficient amount of non-thawing tokens
    _dispute(_lastProposalId, _invalidBonder);
  }

  function test_Dispute_Revert_BondedTokensExceedNonThawingTokens() public {
    // Stake GRT for proposal
    _stakeGRT(_invalidBonder, initParams.parameters.proposalBondSize);

    // Provision with an insufficient amount of non-thawing tokens
    _provision(
      _invalidBonder,
      initParams.parameters.proposalBondSize,
      eboProxy.MAX_MAX_VERIFIER_CUT(),
      uint64(initParams.parameters.minThawingPeriod)
    );

    // Create a proposal allocating 100% of the bonder's provision
    _propose(ETHEREUM_CHAIN_ID, ARBITRUM_SEPOLIA_START_EPOCH, _invalidBonder);
    vm.expectRevert(IBondManager.BondManager_Bond_BondedTokensExceedNonThawingTokens.selector);

    // Dispute when bonded tokens would exceed the amount of non-thawing tokens
    _dispute(_lastProposalId, _invalidBonder);
  }

  function test_Dispute() public {
    // Dispute
    _dispute(_lastProposalId);

    (
      address _queriedDisputer,
      uint256 _queriedDisputeCreatedAt,
      uint256 _queriedLastPledgeTimestamp,
      uint256 _queriedTotalPledgesForDispute,
      uint256 _queriedTotalPledgesAgainstDispute,
      uint256 _queriedRewardPerWinningPledge
    ) = eboProxy.disputes(_lastProposalId);

    // Check the dispute data
    assertEq(_queriedDisputer, _disputerA);
    assertEq(_queriedDisputeCreatedAt, block.timestamp);
    assertEq(_queriedLastPledgeTimestamp, 0);
    assertEq(_queriedTotalPledgesForDispute, 0);
    assertEq(_queriedTotalPledgesAgainstDispute, 0);
    assertEq(_queriedRewardPerWinningPledge, 0);

    // Check if the proposal is disputed
    assertEq(eboProxy.activeProposal(_lastProposalEpoch, ETHEREUM_CHAIN_ID), 0);

    (,,,,,, IEBOStorage.ProposalStatus _proposalStatus) = eboProxy.proposals(_lastProposalId);

    // Check the disputer's bond
    assertEq(eboProxy.bonds(_disputerA), initParams.parameters.proposalBondSize);

    // Check the proposal status
    assertEq(uint8(_proposalStatus), uint8(IEBOStorage.ProposalStatus.Disputed));
  }
}
