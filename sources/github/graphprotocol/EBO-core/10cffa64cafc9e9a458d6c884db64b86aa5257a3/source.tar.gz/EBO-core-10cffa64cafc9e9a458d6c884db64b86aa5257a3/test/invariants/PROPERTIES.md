# Protocol Properties Table

| ID  | Property                                                                                                                                                                                                                            | Type |
| --- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---- |
| 1   | For any user U, when bonding tokens: bonds(U) is less than or equal to the amount of idle tokens (bonded - thawing) in the HorizonStaking contract.                                                                                 |      |
| 2   | The proposal with id `0` is always 'empty'                                                                                                                                                                                          |      |
| 3   | For any proposals P1, P2 where P2 was submitted after P1: proposalId(P2) > proposalId(P1)                                                                                                                                           |      |
| 4   | For any dispute `D`, `D.totalPledgesAgainstDispute` <= `maxNumberOfPledges` and `D.totalPledgesForDispute` <= `maxNumberOfPledges`                                                                                                  |      |
| 5   | For any dispute `D`, the difference between `D.totalPledgesAgainstDispute` and `D.totalPledgesForDispute` is less than or equal to 1                                                                                                |      |
| 6   | For any dispute `D`, if `D.status` == `Escalated`: `D.totalPledgesForDispute` == `D.totalPledgesAgainstDispute` == `maxNumberOfPledges`                                                                                             |      |
| 7   | For any dispute `D` and any user `U`, if `D.status` != `ProposalStatus.DisputerLost` and `D.status` != `ProposalStatus.DisputerWon`, `claimPledgeReward(D, U)` reverts                                                              |      |
| 8   | For any proposal `P`, if `P.status` == `Escalated`, `disputes(P)` is not empty.                                                                                                                                                     |      |
| 9   | For any dispute `D` and times `t1`, `t2` where `t1` <= `t2`: `totalPledgesForDispute(D, t1)` <= `totalPledgesForDispute(D, t2)` and `totalPledgesAgainstDispute(D, t1)` <= `totalPledgesAgainstDispute(D, t2)`                      |      |
| 10  | For every Dispute `D` with `D.status` == `DisputerWon` or `D.status` == `DisputerLost`, the GRT balance of EBO is greater than or equal to the sum of (`totalWinningPledges(D)` \* `rewardPerWinningPledge(D)` - `totalClaimed(D)`) |      |

Accounting:

Protocol balance sheet:

| Assets                                      | Liabilities                                |
| ------------------------------------------- | ------------------------------------------ |
| EBO: token "escrowed" from winning pledgers | EBO: tokens owed to the winning pledgers   |
| Horizon: provisioned tokens                 | Horizon: staked but non-provisioned tokens |
| - bonded (in ebo):                          |                                            |
| -- proposal                                 |                                            |
| -- dispute                                  |                                            |
| -- pledge                                   |                                            |
| - Not bonded                                |                                            |

operations

- propose: proposer: increase bonded by bond amount, decrease staked by bond amount
- disputer: disputer: increase bonded by bond amount, decrease staked by bond amount
- for each pledge: pledger: increased bonded by pledge amount, decrease staked by pledge amount
- resolve:
  proposer/diputer: increase balance of winner, decrease horiz bonded of looser
  pledger winner: increase ebo balance, increase ebo "owned to", decrease horiz bond pledger looser
  pledger looser: decrease ebo balance, decrease ebo "owned to", increase horiz bond pledger winner
