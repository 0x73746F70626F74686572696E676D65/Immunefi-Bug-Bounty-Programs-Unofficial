// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IERC20} from '@openzeppelin/contracts/interfaces/IERC20.sol';
import {UnsafeUpgrades} from '@openzeppelin/foundry-upgrades/src/Upgrades.sol';

import {IEpochManager} from 'interfaces/external/IEpochManager.sol';
import {IHorizonStaking} from 'interfaces/external/IHorizonStaking.sol';

import {EBO, IEBO} from 'contracts/EBO.sol';

import {Script, console} from 'forge-std/Script.sol';

abstract contract Deploy is Script {
  // The Graph
  IERC20 public grt;
  IHorizonStaking public horizonStaking;
  IEpochManager public epochManager;
  address public arbitrator;
  address public council;

  EBO public ebo;
  EBO public eboProxy;

  IEBO.EBOInitializationParams public initParams;

  function setUp() public virtual {
    _setInitParams();

    // The Graph accounts
    grt = IERC20(initParams.grt);
    horizonStaking = IHorizonStaking(initParams.horizonStaking);
    epochManager = IEpochManager(initParams.epochManager);
    arbitrator = initParams.arbitrator;
    council = initParams.council;
  }

  function run() public {
    _deployEBO();
    _logDeployInformation();
  }

  /**
   * @notice Sets the initialization parameters for the EBO.
   * @dev It is implemented in the child contracts.
   */
  function _setInitParams() internal virtual;

  /**
   * @notice Deploys the EBO proxy contract and initializes it.
   */
  function _deployEBO() internal virtual {
    ebo = new EBO();
    eboProxy = EBO(UnsafeUpgrades.deployUUPSProxy(address(ebo), abi.encodeCall(EBO.initialize, (initParams))));
  }

  /**
   * @notice Logs the deployment information.
   */
  function _logDeployInformation() internal virtual {
    console.log('------------------------------- Deployment Information -------------------------------');
    // Log contracts addresses
    console.log('\nContracts addresses:');
    console.log('EBO implementation:', address(ebo));
    console.log('EBO proxy:', address(eboProxy));
    console.log('Council:', address(eboProxy.council()));
    console.log('Arbitrator:', address(eboProxy.arbitrator()));
    console.log('HorizonStaking:', address(eboProxy.horizonStaking()));
    console.log('EpochManager:', address(eboProxy.epochManager()));
    console.log('GRT:', address(eboProxy.grt()));

    // Log parameters
    console.log('\nProposal and dispute parameters:');
    (
      uint256 _proposalBondSize,
      uint256 _pledgeBondSize,
      uint256 _minThawingPeriod,
      uint256 _disputeWindow,
      uint256 _pledgeWindow,
      uint256 _pledgeRefreshWindow,
      uint256 _maxNumberOfPledges
    ) = eboProxy.parametersSnapshots(eboProxy.parametersSnapshotId());

    console.log('Proposal Bond Size:', _proposalBondSize);
    console.log('Pledge Bond Size:', _pledgeBondSize);
    console.log('Min Thawing Period:', _minThawingPeriod);
    console.log('Dispute Window:', _disputeWindow);
    console.log('Pledge Window:', _pledgeWindow);
    console.log('Pledge Refresh Window:', _pledgeRefreshWindow);
    console.log('Max Number of Pledges:', _maxNumberOfPledges);

    console.log('---------------------------------------------------------------------------------------');
  }
}
