// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {Deploy} from 'script/Deploy.s.sol';

import {IERC20} from '@openzeppelin/contracts/interfaces/IERC20.sol';

import {IEBO} from 'interfaces/IEBO.sol';
import {IEBOStorage} from 'interfaces/common/IEBOStorage.sol';

import {IEpochManager} from 'interfaces/external/IEpochManager.sol';
import {IHorizonStaking} from 'interfaces/external/IHorizonStaking.sol';
import {
  ARBITRATOR_RESOLUTION_WINDOW,
  ARBITRUM_SEPOLIA_ARBITRATOR,
  ARBITRUM_SEPOLIA_COUNCIL,
  ARBITRUM_SEPOLIA_EPOCH_MANAGER,
  ARBITRUM_SEPOLIA_GRAPH_TOKEN,
  ARBITRUM_SEPOLIA_HORIZON_STAKING,
  ARBITRUM_SEPOLIA_START_EPOCH,
  DISPUTE_WINDOW,
  ETHEREUM_CHAIN_ID,
  MAX_NUMBER_OF_PLEDGES,
  MIN_THAWING_PERIOD,
  OPTIMISM_CHAIN_ID,
  PLEDGE_BOND_SIZE,
  PLEDGE_REFRESH_WINDOW,
  PLEDGE_WINDOW,
  PROPOSAL_BOND_SIZE
} from 'script/Constants.sol';

contract DeployArbitrumSepolia is Deploy {
  /// @inheritdoc Deploy
  function _setInitParams() internal override {
    string[] memory _chainIds = new string[](2);
    _chainIds[0] = ETHEREUM_CHAIN_ID;
    _chainIds[1] = OPTIMISM_CHAIN_ID;

    IEBOStorage.Parameters memory _parameters = IEBOStorage.Parameters({
      proposalBondSize: PROPOSAL_BOND_SIZE,
      minThawingPeriod: MIN_THAWING_PERIOD,
      pledgeBondSize: PLEDGE_BOND_SIZE,
      pledgeWindow: PLEDGE_WINDOW,
      pledgeRefreshWindow: PLEDGE_REFRESH_WINDOW,
      maxNumberOfPledges: MAX_NUMBER_OF_PLEDGES,
      disputeWindow: DISPUTE_WINDOW
    });

    initParams = IEBO.EBOInitializationParams({
      arbitrator: ARBITRUM_SEPOLIA_ARBITRATOR,
      council: ARBITRUM_SEPOLIA_COUNCIL,
      grt: IERC20(ARBITRUM_SEPOLIA_GRAPH_TOKEN),
      horizonStaking: IHorizonStaking(ARBITRUM_SEPOLIA_HORIZON_STAKING),
      epochManager: IEpochManager(ARBITRUM_SEPOLIA_EPOCH_MANAGER),
      startEpoch: ARBITRUM_SEPOLIA_START_EPOCH,
      chainIds: _chainIds,
      parameters: _parameters,
      arbitratorResolutionWindow: ARBITRATOR_RESOLUTION_WINDOW
    });
  }
}
