# Public Reference Materials

> This repository was formerly `iptf-map`, published under the Institutional Privacy Task Force (now EthSystems).

EthSystems helps onboard institutions and enterprises onto Ethereum, with a focus on ensuring their privacy needs are met in a performant, secure, usable, and accessible way.

This folder contains public-facing documentation for EthSystems, including technical patterns, use cases, regulatory frameworks, and vendor evaluations.

## Structure

- **[Use Cases](./use-cases/)**: Business problems and requirements for privacy-preserving financial applications
- **[Patterns](./patterns/)**: Reusable technical solution cards for common privacy architectures
- **[Approaches](./approaches/)**: Detailed solution approaches combining multiple patterns for specific use cases
- **[Jurisdictions](./jurisdictions/)**: Regulatory frameworks and compliance guides by region/authority
- **[Domains](./domains/)**: Technical domain overviews (payments, custody, trading, etc.)
- **[Vendors](./vendors/)**: Neutral documentation on vendor products and tooling

## Evaluation Framework

This map evaluates solutions against **CROPS** — four properties the Ethereum Foundation considers non-negotiable: Censorship Resistance, Open Source and Free, Privacy, and Security.

Patterns and approaches distinguish between **I2I** (Institution-to-Institution) and **I2U** (Institution-to-End-User) contexts because CROPS requirements differ based on the power dynamic between counterparties. See [GLOSSARY.md](GLOSSARY.md) for full definitions.

## Using This Documentation

**For business stakeholders:**
1. Start with [Use Cases](./use-cases/) to understand business requirements and problems
2. Review [Jurisdictions](./jurisdictions/) for regulatory considerations in your region
3. Explore [Approaches](./approaches/) for recommended solution architectures

**For technical teams:**
1. Browse [Patterns](./patterns/) for reusable technical building blocks
2. Check [Approaches](./approaches/) for detailed implementation guidance
3. Review [Vendors](./vendors/) for tooling and infrastructure options
4. Consult [Domains](./domains/) for domain-specific technical considerations

**For legal/compliance:**
1. Review [Jurisdictions](./jurisdictions/) for regulatory frameworks
2. Read [Use Cases](./use-cases/) for compliance constraints
3. Check [Approaches](./approaches/) for regulatory disclosure mechanisms

## Confidential Information

Business-sensitive details (specific organizations, pilot scopes, committed volumes, next steps) are maintained separately in the `context/` folder with corresponding context files linked from use cases.

## Contributing

When adding new content:
- Use the templates provided in each folder
- Keep content concise and actionable
- Cross-reference related patterns, approaches, and use cases
- Ensure no confidential business information is included

## Development

### Content Validation

This repo includes automated checks to ensure content quality:

```bash
# Install dependencies
npm install && cd scripts && npm install && cd ..

# Run all validations
npm run validate        # Frontmatter schemas, required sections, word limits
npm run check-terms     # GLOSSARY.md term consistency
npm run lint:vale       # Prose quality (requires: brew install vale)

# On-demand LLM review (requires API key)
ANTHROPIC_API_KEY=sk-... npm run llm-review patterns/pattern-foo.md
```

Pre-commit hooks run automatically via Husky on `git commit`.

**CI runs:** validate, check-terms, Vale prose linting on every push.

## Copyright

Copyright and related rights waived via [CC0](https://creativecommons.org/publicdomain/zero/1.0/).
