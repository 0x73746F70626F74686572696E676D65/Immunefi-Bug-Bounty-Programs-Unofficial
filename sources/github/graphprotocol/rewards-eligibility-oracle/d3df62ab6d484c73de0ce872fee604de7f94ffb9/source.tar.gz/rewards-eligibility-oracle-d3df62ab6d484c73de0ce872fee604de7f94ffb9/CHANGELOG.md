# Changelog

All notable changes to the Rewards Eligibility Oracle project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.4.13](https://github.com/graphprotocol/rewards-eligibility-oracle/compare/v0.4.12...v0.4.13) (2026-10-01)


### Added

* generate and post on chain daily eligibility details per indexer ([a956334](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/a956334aca27852a24d28bc4bd18710b2be42374))
* publish metrics on chain ([ea288aa](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/ea288aaa1825a3e21727e4f79b51f2d7fe3e6498))


### Fixed

* add validation for query attempts before publishing ([b55b01f](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/b55b01f17417564a4ab6109c5cda17c07d22eb95))
* adjust days to publish based on window size ([c24105c](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/c24105c8617159b3304922d4a13c0ab6527d952d))
* **bigquery:** stop counting missing measurements as slow or behind ([5b29b54](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/5b29b54c8d14101e8534f44deb71aabc797b678e))
* cache hits + renewal ([c748e46](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/c748e467336f19e087dbd6cc2e387142f278cea9))
* **codec:** limit varints to 64 bits so a subgraph can decode them ([0ef64b1](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/0ef64b1073c77d73edf1160de44134813c6fb0a7))
* **codec:** write message tags as varints, as the wire format states ([ebcc7f2](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/ebcc7f2a5eab06121f028d9ca48996b74cfe47af))
* **config:** check the DataEdge settings when the service starts ([800e106](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/800e106aae2d374e574cbfdd75af15ebfabca519))
* copilot issues ([e21926b](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/e21926b1e6737c643535c4326118b6b53e1d11a1))
* handle overflow in date decoding ([76b6387](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/76b6387f379b211d0ebafc3df89236301616da88))
* limit published days to a maximum threshold ([5b6a16d](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/5b6a16d6be806131a3dd517bdd0d4e5cfa9ec89f))
* more fixes ([dab8f99](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/dab8f9946e38d11e8e862cb2a3d2111e75af6f3e))
* **oracle:** keep renewing when the daily metrics cannot be saved ([db2b112](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/db2b112c04246af4265ad2525b47edd085337f6e))
* **oracle:** renew from cache when the publish files cannot be read ([9e76d12](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/9e76d12cb76cb8f2668e704759387d1f8cf0476a))
* partial published retries ([83204a4](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/83204a4edab18976e8ee7f6311b4f27c4964c254))
* **publishing:** confirm through the next provider if one fails mid-wait ([0541368](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/0541368957e3103032a56287b454b301a0060927))
* **publishing:** keep a 1-day publish setting at 1 day after a good run ([121b289](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/121b289628a552b5c532bd0e672d9e15adfad0a3))
* **publishing:** name the transaction when no provider can send it ([b37739f](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/b37739f26885be585870e937db4374756e3ab7d2))
* **publishing:** reach back over days earlier runs failed to publish ([2b10537](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/2b1053732fe47a74977f8339c2d7c37944e180e8))
* **publishing:** refuse to publish to an address with no contract code ([c80b114](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/c80b114c64f7d7636d3d9651906d524cd19f63ed))
* **publishing:** sign afresh when another transaction took the nonce ([e10922a](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/e10922a3815018e591d0e03257e795393fd8c760))
* **publishing:** sign the metrics once and resend it to each provider ([ac9adfb](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/ac9adfbdc0a16d2ec3d65d670ad28a4a832bf6d0))
* **publishing:** skip publishing when the trailing days have no data ([1f5ca2f](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/1f5ca2f05abf9142ccb53c687fcf05f0c5c8e76d))
* **publishing:** stop sending a payload that reverts in gas estimation ([2728429](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/27284291112c1c682992f2f69b2cc235528d7308))
* **publishing:** treat only rate limits as refused among node errors ([871bbdb](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/871bbdb08b0c032ee33c1176217229b709bb442f))
* **publishing:** try the next provider when a rate-limited send fails ([c5e718c](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/c5e718c469a40dca76ab9555689ee83241c3a0a1))
* refactor publish_days assignment with conditional check ([dff3841](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/dff3841942591b97cd4fd0bf274fb5128f1b915a))
* restore per-day row filtering in the DataEdge payload encoder ([15994c8](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/15994c81559311ea8d510e76a7717303730f7995))
* stop renewals replacing the DataEdge publish transaction ([bf3fcc2](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/bf3fcc22810d0a64766ed5acf6465848180cf60b))


### Changed

* **blockchain:** mark the RPC connection loop's counter as unused ([7b37648](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/7b376487b5ebb0876c55c16d2ead87849d43750f))
* **deps:** Bump the python-dependencies group with 2 updates ([#157](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/157)) ([a1addfc](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/a1addfcd2850b4d1cec04428e31831c9e4362803))
* **docker:** merge back-to-back RUN steps in the image build ([97b8290](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/97b8290756cec514ed7c1f56d5d55886050dd852))
* **docker:** merge back-to-back RUN steps in the image build ([#159](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/159)) ([213a8d5](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/213a8d53ce9406d2affe5b096dd51c8dc7225f7e))
* **errors:** catch OSError once, not alongside its own subclasses ([9d31300](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/9d3130032960fe210b8f8184e9786e39aa7e9c61))
* **errors:** drop 2 handlers that only re-raise what they catch ([c0f3681](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/c0f36812067a6f70fe39ca03f39d766193eccbb7))
* **formatter:** split the blank line pass into small named steps ([437800c](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/437800c9595efc0003d321d8a1b92184c52e214c))
* **formatter:** split the blank line pass into small steps ([#163](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/163)) ([0ed15bd](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/0ed15bd79fa5935f8e81ed22abc36cf7a2189db6))
* **k8s:** drop the unused API token and bound the pod's scratch disk ([52e7c82](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/52e7c82e8c139b2bb5e878ff55aa0eade6e5145c))
* **oracle:** mark the Slack success helper as returning nothing ([0067345](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/0067345f28c381f8d2a38b7ed8a101164a896248))
* **oracle:** split the daily run into a helper per stage ([e6d0d80](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/e6d0d8044505cf382e937532994e0d8a60d98cb9))
* **pipeline:** name each output CSV file once at the top of the module ([8122b56](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/8122b56aa3483a2b43f2857016c5439caf799a03))
* **scheduler:** split start-up into a helper per step ([b493403](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/b4934033a3c092b2e4f9ccc5276ac39beaf9ee43))
* split the daily run and scheduler start-up into steps ([#164](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/164)) ([ef36820](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/ef36820ba089cb977cbb1d6df0929d2b95787b40))


### Documentation

* **docker:** state the Python version the base image actually uses ([edb5048](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/edb50486d6b2f5ff304d041db997e48dcaafdb9a))


### Tests

* **formatter:** cover functions nested inside other functions ([41a4019](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/41a4019942e6fe0978fccd6b2e168123a904f90e))
* **formatter:** pin the blank lines added above definitions ([c79696c](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/c79696c947bf9734e967491513d75c15c3f172bd))
* **oracle:** report a cached data failure at its own stage ([a7250a2](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/a7250a2eabee6ebc7fa94f06154bf864f533d383))

## [0.4.12](https://github.com/graphprotocol/rewards-eligibility-oracle/compare/v0.4.11...v0.4.12) (2026-09-22)


### Fixed

* count only qualifying subgraphs and announce minimum of 5 ([#154](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/154)) ([6650865](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/66508655c229dff3027a7da63d3ab875258a25a5))


### Changed

* **deps:** Bump eth-typing from 5.2.1 to 6.0.0 ([#149](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/149)) ([6831ce5](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/6831ce589c16ab9ee0890358c6a999a6abd923b4))
* **deps:** Bump mypy from 1.19.1 to 2.3.1 ([#152](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/152)) ([7aa920c](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/7aa920c1e4f5bae49ee3abd1ca5797a087eca64b))
* **deps:** Bump pandas from 2.3.3 to 3.0.6 ([#147](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/147)) ([7f10890](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/7f108904e4e4aaeb710264adcee7d8467e2248dc))
* **deps:** Bump python from 3.14.6-slim to 3.14.7-slim ([#131](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/131)) ([7e608c5](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/7e608c5fc467c092c02b0299b8b45520ee704e09))
* **deps:** Bump pytz from 2025.2 to 2026.3.post1 ([#146](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/146)) ([15bb229](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/15bb229caa8ec26e55a8eab75908e263f8679b3e))
* **deps:** Bump the python-dependencies group across 1 directory with 13 updates ([#134](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/134)) ([c1db28d](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/c1db28da3378b8899f8cf3abe110101c269e93e5))
* **deps:** Bump the python-dependencies group with 4 updates ([#145](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/145)) ([5485be3](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/5485be30c28ca5611cfec694bbe520f08ba24d31))
* **deps:** Bump types-pytz from 2025.2.0.20251108 to 2026.3.1.20260727 ([#151](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/151)) ([6ad6d17](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/6ad6d170fcb577baedea3742dc190613efc68e12))
* **deps:** Bump types-requests from 2.33.0.20260712 to 2.33.0.20260906 ([#150](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/150)) ([fd45c3e](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/fd45c3e064c5168527c23688d06d7866e2c294ec))
* **deps:** Bump web3 from 7.14.0 to 8.0.0 ([#148](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/148)) ([2f39cf4](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/2f39cf43959406ce5cab9a6ee631f5df7dc26bd7))
* **slack:** share 1 timestamp format across all notifications ([62f9142](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/62f91421b5338fa7fd6e5e95f1943e89c9132399))


### Documentation

* add missing subgraph rule and config keys to criteria ([#153](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/153)) ([99ed83f](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/99ed83f5aaa70923dedf09b82316fc38def4e5a3))

## [0.4.11](https://github.com/graphprotocol/rewards-eligibility-oracle/compare/v0.4.10...v0.4.11) (2026-08-11)


### Added

* **notifications:** mark each Slack message with its network ([#126](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/126)) ([e93b455](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/e93b4557d63760949681cb978c95447b5a593db0))


### Fixed

* fail over to the next RPC provider when quota runs out ([#129](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/129)) ([f652655](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/f6526553e1789cac54c5752a8dfcc5abd948d2dd))
* stop RPC failover looping forever when all providers fail ([#128](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/128)) ([2a56b19](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/2a56b19838c9e16309a146c336db0b30851ccb72))


### Changed

* **deps:** Bump actions/setup-python from 6 to 7 ([#122](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/122)) ([7f7a4f6](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/7f7a4f6aec28c149985f325e41ab2b863b7d14d1))
* **deps:** Bump python from 3.14.2-slim to 3.14.6-slim ([#116](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/116)) ([884e51b](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/884e51b74fc4c05f3f4e95ebf0ab81c3893755fa))


### Documentation

* **readme:** delete duplicate readme that hid the main one on GitHub ([#124](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/124)) ([e9c5092](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/e9c509288c052a7abb5abda24da07fd8d29a791c))
* **readme:** rewrite README to be more visual and explanatory ([#123](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/123)) ([733abae](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/733abae4109607a1b1b1b79ef9e83f412a64ce45))

## [0.4.10](https://github.com/graphprotocol/rewards-eligibility-oracle/compare/v0.4.9...v0.4.10) (2026-07-13)


### Added

* **ci:** sign sync-manifest commits via GitHub API ([#99](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/99)) ([17f9032](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/17f903259efe63500820a77287522dacfd318bb6))


### Fixed

* **ci:** improve sync-manifest to handle branch protection ([#96](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/96)) ([3b191c2](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/3b191c2a72d741d78bf22213fc3b3d3c6456cda8))
* **ci:** use printf for PR body to avoid YAML parsing error ([#97](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/97)) ([cd07a6d](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/cd07a6df9ded73ef62a28b8a4a6926026a39adb0))


### Changed

* **deps:** Bump actions/cache from 5 to 6 ([#118](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/118)) ([e0cde4c](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/e0cde4cd2d18fc472b5d2e427db5bbd61a3e1f4c))
* **deps:** Bump actions/checkout from 5 to 6 ([#93](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/93)) ([f876bdd](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/f876bdd849a94736d698b56dbea31e97c876cdeb))
* **deps:** Bump actions/checkout from 6 to 7 ([#117](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/117)) ([5e61119](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/5e611192bbc86422196ce4ad769a477d461473c9))
* **deps:** Bump docker/build-push-action from 6 to 7 ([#107](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/107)) ([0ebbf6e](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/0ebbf6e3d13817d2f059dfd28a0d2bf99876d607))
* **deps:** Bump docker/login-action from 3 to 4 ([#105](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/105)) ([90aebf5](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/90aebf5c2ce543dc17fb17cc5f6d0e4c811e0776))
* **deps:** Bump docker/metadata-action from 5 to 6 ([#106](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/106)) ([34a4c84](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/34a4c8441a3ed7262a045cef69dcdcfa9cd545c7))
* **deps:** Bump docker/setup-buildx-action from 3 to 4 ([#104](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/104)) ([f05e5d6](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/f05e5d6e2a644c0cec226c593fbce93bb0c6e111))
* **deps:** Bump softprops/action-gh-release from 2 to 3 ([#112](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/112)) ([bb5d93e](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/bb5d93e17533442c0e61cb4eaf3bd54795d0a965))
* **release:** sync release-please manifest to actual version 0.4.9 ([#119](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/119)) ([b357318](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/b357318320fdfe590a45da7f8b264085be7426f1))
* update testnet contract address to new deployment ([#101](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/101)) ([ed9e1eb](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/ed9e1eb6149587623da9f8b5aa15a673ec063bd1))

## [0.4.5](https://github.com/graphprotocol/rewards-eligibility-oracle/compare/v0.4.4...v0.4.5) (2025-11-22)


### Fixed

* remove unused keys/URLs from config ([3d9f6a1](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/3d9f6a1c3ca837e28cfe803647ea6596822f61a3))

## [0.4.4](https://github.com/graphprotocol/rewards-eligibility-oracle/compare/v0.4.3...v0.4.4) (2025-11-21)


### Added

* **auth:** support Kubernetes inline credentials ([#67](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/67)) ([b1d99e6](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/b1d99e6f0f34afad99b0fb36036c2548e5aae9e3))

## [0.4.3](https://github.com/graphprotocol/rewards-eligibility-oracle/compare/v0.4.2...v0.4.3) (2025-11-21)


### Fixed

* remove package-name from release-please config ([#65](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/65)) ([06f266c](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/06f266c4d35b7f06aef0fe658758b394921b3295))

## [0.4.2](https://github.com/graphprotocol/rewards-eligibility-oracle/compare/rewards-eligibility-oracle-v0.4.1...rewards-eligibility-oracle-v0.4.2) (2025-11-20)


### Added

* Add BigQuery caching with 30-minute freshness ([#12](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/12)) ([ac822a8](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/ac822a82e4307afda6ca5aa2ff29226f2d818dc3))
* Add clickable transaction links and Python style guidelines ([#15](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/15)) ([8534bf8](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/8534bf84263a0c053b8a70efb6486c629e188687))
* Add continuous deployment pipeline with manual version control ([#13](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/13)) ([8ad0436](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/8ad043655a571c37c5f5519c3e5a646cf38f3335))
* Add Kubernetes deployment support ([#14](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/14)) ([daaa778](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/daaa778065ce692d324cb87b2e602235c984c87d))
* add release-please automation ([#45](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/45)) ([4c49ba5](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/4c49ba5a86bc019c7e08ca694892d20359247aee))
* **SQO:** Implement RPC failover, retry logic and notification on RPC provider rotation. ([#4](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/4)) ([5a6ea0a](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/5a6ea0af82e252b9a899027a811551c1d78fc7b0))
* **SQO:** Introduce circuit breaker. ([#9](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/9)) ([62ef969](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/62ef9693f615da2a21df3aacd472dbfb1a32dcc7))
* **SQO:** Introduce minimal CI/CD pipeline ([#1](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/1)) ([8131872](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/8131872515714d9e845f2c51309008c0c75c9f62))
* **SQO:** Introduce Slack notification pipeline and test script for failed/successful runs of the SQO ([#2](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/2)) ([d50ab59](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/d50ab5987a4da3e8b6ad8f69f368f9c6792989f6))


### Fixed

* **ci:** update Python to 3.13.7 and limit workflow permissions ([#43](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/43)) ([cc8cac6](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/cc8cac6621e3dadfc0509dcbd3ea152970fea70c))
* configure release-please to auto-update Docker image versions ([#49](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/49)) ([caf6dbe](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/caf6dbe44ac5c4d5013983ec656bdbb7970ba652))
* configure release-please workflow to use config files ([#53](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/53)) ([dda3c24](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/dda3c24dfc4b62ce859f4af40718bfc052926dda))
* mount config.toml from ConfigMap in K8s ([#62](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/62)) ([09dc59c](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/09dc59c4d94a1c756c62cf5b3033da3cb8738f9a))
* Resolve TruffleHog BASE/HEAD comparison failure ([#11](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/11)) ([d025069](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/d025069cbd04476a48868eea96711e1f784c79b2))
* update contract ABI to match deployed ServiceQualityOracle ([#24](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/24)) ([29001d6](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/29001d662f661d1fbbdaa37e62d70e39f989a382))
* update Dependabot config and add CODEOWNERS ([#26](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/26)) ([8dd13a0](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/8dd13a0ae293c22005c80d40ed2c2c5e0090e41b))
* update release-please config filename and release type ([#63](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/63)) ([231b976](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/231b97650b56be1f109470001dabf380f088ce50))


### Changed

* add dependabot config and update to production image ([#16](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/16)) ([06f58ee](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/06f58eee6688751202dac407dd5c864140eeaa6d))
* **auth:** improve Google Cloud credential handling ([#42](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/42)) ([ab2063c](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/ab2063c2d93274de42a875ed76a61a9bbde8d12f))
* **deps:** Bump actions/cache from 3 to 4 ([#21](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/21)) ([16e6c29](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/16e6c29d76c9c40f3bcf3b8b9325a454a8f2fdd6))
* **deps:** Bump actions/checkout from 4 to 5 ([#31](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/31)) ([cb12126](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/cb12126f0d1b6b980c7e7da631d4e3f224f8a1b0))
* **deps:** Bump actions/setup-python from 4 to 5 ([#19](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/19)) ([82a82bd](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/82a82bd2e9692a7b6fc7d783c1ca8bcb683b2c78))
* **deps:** Bump actions/setup-python from 5 to 6 ([#35](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/35)) ([6c1c174](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/6c1c174857a5b6a0cf1d4a337f947fa525d64b8b))
* **deps:** Bump docker/build-push-action from 5 to 6 ([#18](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/18)) ([5b2cd65](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/5b2cd65ccecac6a56349863626a3c866528c6473))
* **deps:** Bump gql from 3.5.3 to 4.0.0 ([#34](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/34)) ([e7860cd](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/e7860cdad076a1b74bf3ef8d1c6b0e48d123a6e7))
* **deps:** Bump python from 3.11-slim to 3.13.7-slim ([#30](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/30)) ([ba3b323](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/ba3b32362c77da99cda165ec84d1422e447256de))
* **deps:** Bump softprops/action-gh-release from 1 to 2 ([#17](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/17)) ([931f0c1](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/931f0c12c1fe15a4e2ec592665bdd36cc3938236))
* **deps:** Bump tenacity from 8.5.0 to 9.1.2 ([#23](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/23)) ([597c6f6](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/597c6f615d2f9a8a3375adee43bae30ddaf003e7))
* **deps:** Bump the python-dependencies group across 1 directory with 13 updates ([#40](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/40)) ([f2d35e1](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/f2d35e1351a71dfa19e903ed8f1e291c06b5af2d))
* **deps:** Bump the python-dependencies group with 10 updates ([#22](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/22)) ([d1daf2d](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/d1daf2d17f2371d246035b224819a64a07846e10))
* **deps:** Bump types-pytz from 2025.2.0.20250516 to 2025.2.0.20250809 ([#29](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/29)) ([31ea904](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/31ea904f2bcaab44c57c1860828d4bc417d151cb))
* **deps:** Bump types-requests from 2.32.4.20250611 to 2.32.4.20250809 ([#27](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/27)) ([6e1bbc8](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/6e1bbc87da527f27e625097dbaf95c49acee4696))
* **main:** release 0.4.0 ([#46](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/46)) ([eceb4d6](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/eceb4d6987ac4dd1463fae851d0664fd823dfbaf))
* **main:** release 0.4.1 ([#48](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/48)) ([2d32fd5](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/2d32fd57a1ae92fefee758b3dabb9edd7af374f3))
* rename Service Quality to Rewards Eligibility ([#50](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/50)) ([0b1dd6d](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/0b1dd6d8c85deed4f385ee3c08ea632986d6335b))
* **REO:** rename to RewardsEligibilityOracle, reduce initial requirements ([#39](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/39)) ([5043ac7](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/5043ac7620b68445bacd81d16b0a2b70c4f70070))
* **SQO:** Create unit tests. ([#5](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/5)) ([68ba132](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/68ba132b78890ac9a6ddd5b1c11ad641fca5dd17))
* **SQO:** Modularise codebase, create a single source of truth for config, add test framework, review all components. ([#3](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/3)) ([2845036](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/28450369526f8f6a7963ce69f6ded7708899769d))
* **SQO:** Remove unused module/test file.  ([#6](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/6)) ([6950e19](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/6950e196d793320598d600fed523b540d184352e))
* **SQO:** Update eligibility criteria document structure. ([#8](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/8)) ([fc44590](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/fc445901f6b25fa7728eab89d1448ad7dd7f7c94))
* update Docker image to v0.2.2 ([#25](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/25)) ([09d0f4f](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/09d0f4f1727060b980c7349a3df4cbab52632dfb))
* update Docker image to v0.3.0 ([#44](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/44)) ([4075cf9](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/4075cf99e0637c4ad9be5d0e115095f447432a31))


### Documentation

* add end-to-end oracle flow diagram ([#54](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/54)) ([3b1997b](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/3b1997b5ccc3c6dd7babc6faab42b3a56c859e08))
* clean up stale README and apply auto formatting fixes  ([#47](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/47)) ([ba1ce3e](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/ba1ce3ee2aaf593ef32012201aa3767d3a76a01e))
* Remove unimplemented curation requirement and enhance security ([#10](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/10)) ([ee06dee](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/ee06dee778cb4499a7605f250ea1636e09a9885d))

## [0.4.1](https://github.com/graphprotocol/rewards-eligibility-oracle/compare/v0.4.0...v0.4.1) (2025-11-06)


### Documentation

* clean up stale README and apply auto formatting fixes  ([#47](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/47)) ([ba1ce3e](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/ba1ce3ee2aaf593ef32012201aa3767d3a76a01e))

## [0.4.0](https://github.com/graphprotocol/rewards-eligibility-oracle/compare/v0.3.0...v0.4.0) (2025-11-03)


### Features

* add release-please automation ([#45](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/45)) ([4c49ba5](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/4c49ba5a86bc019c7e08ca694892d20359247aee))


### Bug Fixes

* **ci:** update Python to 3.13.7 and limit workflow permissions ([#43](https://github.com/graphprotocol/rewards-eligibility-oracle/issues/43)) ([cc8cac6](https://github.com/graphprotocol/rewards-eligibility-oracle/commit/cc8cac6621e3dadfc0509dcbd3ea152970fea70c))

## [Unreleased]

### Changed

- Apply markdownlint formatting to documentation files
- Update Python to 3.13.7 with limited workflow permissions (#43)
- Update Docker image to v0.3.0 (#44)

## [0.3.0] - 2025-10-30

### Added

- Dependabot configuration for automated dependency updates (#16)
- CODEOWNERS file for code review assignments (#26)

### Changed

- Improved Google Cloud credential handling with better error messages (#42)
- Renamed contract from IssuanceEligibilityOracle to RewardsEligibilityOracle (#39)
- Updated contract ABI to match deployed RewardsEligibilityOracle (#24)
- Updated to production Docker image configuration (#16, #25)
- Python upgraded from 3.11-slim to 3.13.7-slim (#30)

### Dependencies

- Bumped python-dependencies group with 13 updates (#40)
- Bumped python-dependencies group with 10 updates (#22)
- Updated types-pytz from 2025.2.0.20250516 to 2025.2.0.20250809 (#29)
- Updated types-requests from 2.32.4.20250611 to 2.32.4.20250809 (#27)
- Updated tenacity from 8.5.0 to 9.1.2 (#23)
- Updated gql from 3.5.3 to 4.0.0 (#34)
- Updated actions/setup-python from 4 to 5, then 5 to 6 (#19, #35)
- Updated actions/checkout from 4 to 5 (#31)
- Updated actions/cache from 3 to 4 (#21)
- Updated docker/build-push-action from 5 to 6 (#18)
- Updated softprops/action-gh-release from 1 to 2 (#17)

## [0.2.2] - 2025-07-31

### Fixed

- Updated contract ABI to match deployed ServiceQualityOracle (#24)

### Added

- Dependabot configuration for automated dependency updates (#16)
- Production Docker image configuration (#16)

## [0.2.1] - 2025-07-31

### Added

- Clickable transaction links in notifications for easier verification (#15)
- Python style guidelines documentation (#15)

## [0.2.0] - 2025-07-30

### Added

- Kubernetes deployment support with manifests and documentation (#14)
- Persistent volume configurations for data and logs
- ConfigMap and Secret management for Kubernetes
- Resource allocation and health check configurations

## [0.1.0] - 2025-07-25

### Added

- BigQuery caching system with 30-minute freshness threshold
- Cache directory initialization in scheduler
- Force refresh capability via environment variable
- Comprehensive cache test coverage

### Changed

- Container restart performance improved from ~5 minutes to ~30 seconds
- BigQuery costs reduced by eliminating redundant expensive queries

### Technical Details

- Cache location: `/app/data/cache/bigquery_cache.json`
- Configurable via `CACHE_MAX_AGE_MINUTES` environment variable
- Override caching with `FORCE_BIGQUERY_REFRESH=true`

## [0.0.1] - Initial Release

### Added

- Daily BigQuery performance data fetching from Google BigQuery
- Indexer eligibility processing based on threshold algorithms
- On-chain oracle updates to RewardsEligibilityOracle contract
- RPC provider failover with circuit breaker pattern
- Slack notifications for monitoring
- Docker containerization with health checks
- Scheduled execution at 10:00 UTC daily
- Data persistence and CSV output generation
- Comprehensive test coverage

### Technical Implementation

- Python 3.11 with slim Docker image
- Google BigQuery integration
- Web3 blockchain client with automatic failover
- Circuit breaker prevents infinite restart loops
- Retry mechanisms with exponential backoff
- Configuration management via TOML and environment variables
