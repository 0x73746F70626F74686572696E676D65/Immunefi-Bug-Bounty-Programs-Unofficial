# Indexing Rewards Eligibility Criteria

This document defines the requirements an Indexer must meet to be eligible for indexing rewards. It includes the current active criteria, a schedule of any upcoming changes, and a log of all historical requirements. The goal is to provide a transparent and predictable set of standards for all network participants.

---

## Upcoming Eligibility Criteria

**We will announce changes to the eligibility criteria in the table below.** Once the change goes live, it will be reflected in the [Active Eligibility Criteria](https://github.com/graphprotocol/rewards-eligibility-oracle/blob/main/ELIGIBILITY_CRITERIA.md#active-eligibility-criteria) section of this document.

| Upcoming Requirement | Justification | Date Requirement Will Be Updated/Introduced (YYYY-MM-DD) |
|----------------------|---------------|----------------------------------------------------------|
| **Subgraph Coverage:** To be active, an indexer must serve at least 1 qualifying query on each of **5 subgraphs** that day, up from **1 subgraph**. Indexers still need **5+ active days** in a given **28 day** period. | Encourages indexers to sync and reliably serve a range of subgraphs rather than a single one. | 2026-10-06 |

> **Note**:
> We will typically allow a 14 day window after announcing a change before it goes live.

---

## Active Eligibility Criteria

The following criteria are used to identify indexers that should be eligible to receive indexing rewards.

- **Days Online Requirement:** Indexers must be active for **5+ days** in a given **28 day** period for rewards eligibility.
- **Daily Query Requirement:** To be active, an indexer must serve at least **1 qualifying query**.
- **Subgraph Coverage Requirement:** To be active, an indexer must serve qualifying queries on at least **1 subgraph** that day. Any day with a qualifying query already meets this.
- **Query Quality Requirements:** A qualifying query is one that simultaneously meets **all** of the following criteria:
  - Query Response HTTP Status: **200 OK**.
  - Query Response Latency: **< 5,000 ms**.
  - Query Freshness: **< 50,000 blocks** behind chainhead.

Eligibility for indexing rewards is typically refreshed daily via the RewardsEligibilityOracle contract.

> **Note**:
> Once an indexer has successfully qualified for indexing rewards by satisfying the active eligibility criteria, and a corresponding transaction has been submitted on chain by an authorized Oracle into the RewardsEligibilityOracle contract, the now eligible indexer can continue claiming indexing rewards from the protocol for the duration of the qualification period (default is 14 days), even if the active eligibility criteria change.

### Where These Criteria Are Enforced

The values above are the ones deployed today. Most are set in [`k8s/configmap.yaml`](./k8s/configmap.yaml): the analysis window under `[processing]` and the rest under `[eligibility_criteria]`. The query that applies them is in [`src/models/bigquery_provider.py`](./src/models/bigquery_provider.py), which also fixes the 2 values with no config key.

| Requirement | Config Key | Deployed Value |
|-------------|------------|----------------|
| Days online required | `MIN_ONLINE_DAYS` | 5 |
| Analysis window (days) | `BIGQUERY_ANALYSIS_PERIOD_DAYS` | 28 |
| Qualifying queries per active day | None, set in the query | 1 |
| Subgraphs with a qualifying query per active day | `MIN_SUBGRAPHS` | 1 |
| Query response HTTP status | None, set in the query | 200 OK |
| Query latency must be below (ms) | `MAX_LATENCY_MS` | 5,000 |
| Blocks behind chainhead must be below | `MAX_BLOCKS_BEHIND` | 50,000 |

---

## Eligibility Requirements Changelog

This table tracks changes to the indexing rewards eligibility requirements over time.

| Requirement Category | Requirement Details | Effective Date (YYYY-MM-DD) | Change Type: Initial, Updated, New, Removed | Justification | Notes |
|----------------------|---------------------|-----------------------------|-------------|---------------|-------|
| **Indexer Activity** | Indexers must be active for **5+ days** in a given **28 day** period for indexing rewards eligibility. | 2026-08-25 | Initial | Encourages indexers to familiarize themselves with infrastructure maintenance and ongoing operations. | Planned for Rewards Eligibility Oracle launch |
| **Query Qualification** | Indexers must serve **≥1 qualifying query** in a day for the day to count towards the **Indexer Activity** requirement. | 2026-08-25 | Initial | Encourages indexers to become familiar with the process of syncing and serving subgraph data. | Planned for Rewards Eligibility Oracle launch |
| **Subgraph Coverage** | Indexers must serve qualifying queries on **≥1 subgraph** in a day for the day to count towards the **Indexer Activity** requirement. | 2026-08-25 | Initial | Sets a minimum number of subgraphs an indexer must serve each day. At **1** it is met by any day with a qualifying query. | Planned for Rewards Eligibility Oracle launch |
| **Query Response Quality** | *•* Query Response HTTP Status: **200 OK**<br>*•* Query Response Latency: **< 5,000 ms**<br>*•* Query Freshness: **< 50,000 blocks** behind chainhead. | 2026-08-25 | Initial | *•* Indexer infrastructure needs to serve successful queries to benefit data consumers.<br>*•* Fast query responses are important to data consumers.<br>*•* Encourages indexers to sync to chainhead. | Planned for Rewards Eligibility Oracle launch |

---
