#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

source "$REPO_ROOT/.env"
[ -f "$REPO_ROOT/.env.local" ] && source "$REPO_ROOT/.env.local"
source "$REPO_ROOT/shared/lib.sh"

# Get number of epochs to advance (default to 1 if not provided)
EPOCHS_TO_ADVANCE=${1:-1}

EPOCH_MANAGER_ADDRESS=$(contract_addr EpochManager.address horizon)
RPC_URL="http://${CHAIN_HOST:-localhost}:${CHAIN_RPC_PORT:-8545}"

# Get current epoch
CURRENT_EPOCH=$(cast call $EPOCH_MANAGER_ADDRESS "currentEpoch()(uint256)" --rpc-url "$RPC_URL")

# Get epoch length
EPOCH_LENGTH=$(cast call $EPOCH_MANAGER_ADDRESS "epochLength()(uint256)" --rpc-url "$RPC_URL")

# Get current block number
CURRENT_BLOCK=$(cast block latest --rpc-url "$RPC_URL" | grep number | awk '{print $2}')

# Get current epoch block
CURRENT_EPOCH_BLOCK=$(cast call $EPOCH_MANAGER_ADDRESS "currentEpochBlock()(uint256)" --rpc-url "$RPC_URL")

# Calculate blocks until next epoch
BLOCKS_IN_CURRENT_EPOCH=$((CURRENT_BLOCK - CURRENT_EPOCH_BLOCK))
BLOCKS_TO_MINE=$((EPOCH_LENGTH - BLOCKS_IN_CURRENT_EPOCH + (EPOCH_LENGTH * (EPOCHS_TO_ADVANCE - 1))))

echo "Current epoch: $CURRENT_EPOCH"
echo "Epoch length: $EPOCH_LENGTH blocks"
echo "Current block: $CURRENT_BLOCK"
echo "Current epoch block: $CURRENT_EPOCH_BLOCK"
echo "Blocks in current epoch: $BLOCKS_IN_CURRENT_EPOCH"
echo "Advancing by $EPOCHS_TO_ADVANCE epoch(s)"
echo "Blocks to mine: $BLOCKS_TO_MINE"

# Mine blocks until next epoch using mine-block.sh
"$SCRIPT_DIR/mine-block.sh" $BLOCKS_TO_MINE

# Verify we're in the next epoch
NEW_EPOCH=$(cast call $EPOCH_MANAGER_ADDRESS "currentEpoch()(uint256)" --rpc-url "$RPC_URL")
echo "New epoch: $NEW_EPOCH"
