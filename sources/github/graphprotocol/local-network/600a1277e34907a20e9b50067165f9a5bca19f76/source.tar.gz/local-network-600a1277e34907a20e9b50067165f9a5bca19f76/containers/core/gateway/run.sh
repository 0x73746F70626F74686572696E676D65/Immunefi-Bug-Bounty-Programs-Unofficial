#!/bin/sh
set -eu
. /opt/config/.env

. /opt/shared/lib.sh

cd /opt
graph_tally_verifier=$(contract_addr GraphTallyCollector.address horizon)
dispute_manager=$(contract_addr DisputeManager.address subgraph-service)
subgraph_service=$(contract_addr SubgraphService.address subgraph-service)
echo "Waiting for network subgraph..." >&2
network_subgraph_deployment=$(wait_for_gql \
  "http://graph-node:${GRAPH_NODE_GRAPHQL_PORT}/subgraphs/name/graph-network" \
  "{ _meta { deployment } }" \
  ".data._meta.deployment")
cat >config.json <<-EOF
{
  "attestations": {
    "chain_id": "1337",
    "dispute_manager": "${dispute_manager}"
  },
  "api_keys": [
    {
      "key": "${GATEWAY_API_KEY}",
      "user_address": "0xdeadbeefdeadbeefdeadbeefdeadbeefdeadbeef",
      "query_status": "ACTIVE"
    }
  ],
  "exchange_rate_provider": 1.0,
  "graph_env_id": "local",
  "indexer_selection_retry_limit": 2,
  "kafka": {
    "bootstrap.servers": "redpanda:9092"
  },
  "log_json": false,
  "min_graph_node_version": "0.0.0",
  "min_indexer_version": "0.0.0",
  "network_subgraph_max_lag_seconds": 604800,
  "trusted_indexers": [
    {
      "url": "http://indexer-service:${INDEXER_SERVICE_PORT}/subgraphs/id/${network_subgraph_deployment}",
      "auth": "freestuff"
    }
  ],
  "payment_required": true,
  "port_api": 7700,
  "port_metrics": 7301,
  "query_fees_target": 40e-6,
  "receipts": {
    "chain_id": "1337",
    "payer": "${ACCOUNT0_ADDRESS}",
    "signer": "${ACCOUNT1_SECRET}",
    "verifier": "${graph_tally_verifier}"
  },
  "subgraph_service": "${subgraph_service}",
  "x402": {
    "facilitator_url": "https://x402.org/facilitator",
    "receiver_address": "${ACCOUNT_X402_ADDRESS}",
    "chain": "base_sepolia",
    "price": 42e-6
  }
}
EOF
cat config.json
export RUST_LOG=info,gateway_framework=trace,graph_gateway=trace
graph-gateway ./config.json
