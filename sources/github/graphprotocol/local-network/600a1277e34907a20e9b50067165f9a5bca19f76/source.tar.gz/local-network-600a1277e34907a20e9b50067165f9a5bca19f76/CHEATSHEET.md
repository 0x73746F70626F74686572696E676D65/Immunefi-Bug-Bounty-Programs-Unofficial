# local-network component cheatsheet

### chain

- Foundry docs: https://book.getfoundry.sh/
- Automine: blocks are mined instantly on each transaction
- Chain state persists across restarts via `--state` flag
- Use `scripts/mine-block.sh` to manually advance blocks if needed

### block-explorer

- [esplr](https://github.com/paulmillr/esplr) block explorer available at: http://localhost:3000

### ipfs

- cat file via curl:
  ```bash
  curl -X POST "http://localhost:5001/api/v0/cat?arg=f1220d6b169dcf83bfe0f615baa2d83e9adf77d520b52faf18a759eb7277b6d66fa7f"
  ```
- cat file via CLI:
  ```bash
  ipfs --api=/ip4/127.0.0.1/tcp/5001 cat QmagRyTMp4qcRb8fJufk7urNwCQmmUEB9mC6nxHQuKwydb
  ```
- note: if you have a hex digest, a valid CID for it is the hex digits prefixed by `f1220`. For example, `0xd6b169dcf83bfe0f615baa2d83e9adf77d520b52faf18a759eb7277b6d66fa7f` -> `f1220d6b169dcf83bfe0f615baa2d83e9adf77d520b52faf18a759eb7277b6d66fa7f`

### postgres

- `psql -h localhost -U postgres`

### graph-node

- GraphiQL interface: http://localhost:8000/subgraphs/name/${subgraph_name}/graphql
- Status endpoint: http://localhost:8030/graphql/playground

### graph-contracts / subgraph-deploy

- network subgraph: http://localhost:8000/subgraphs/name/graph-network

  ```graphql
  {
    indexers {
      id
      url
      geoHash
    }
    provisions {
      id
      indexer {
        id
        stakedTokens
      }
      tokensProvisioned
      thawingPeriod
      maxVerifierCut
      dataService {
        id
        totalTokensProvisioned
      }
    }
    subgraphs {
      id
      versions {
        subgraphDeployment {
          ipfsHash
          indexerAllocations {
            id
            status
            indexer {
              id
            }
          }
        }
      }
    }
    _meta {
      block {
        number
      }
      deployment
    }
  }
  ```

### block-oracle

- subgraph: http://localhost:8000/subgraphs/name/block-oracle

  ```graphql
  {
    networks {
      id
    }
    _meta {
      block {
        number
      }
      deployment
    }
  }
  ```

### indexer-agent

- `graph indexer connect http://localhost:7600`
- `graph indexer --network=hardhat status`

### indexer-service

- `docker compose up --build indexer-service`
- `docker compose down indexer-service`
- `docker compose logs -f indexer-service`

```bash
curl "http://localhost:7601/subgraphs/id/QmRcucmbxAXLaAZkkCR8Bdj1X7QGPLjfRmQ5H6tFhGqiHX" \
  -H 'content-type: application/json' -H "Authorization: Bearer freestuff" \
  -d '{"query": "{ _meta { block { number } } }"}'
```

### gateway

```bash
curl "http://localhost:7700/api/subgraphs/id/BFr2mx7FgkJ36Y6pE5BiXs1KmNUmVDCnL82KUSdcLW1g" \
  -H 'content-type: application/json' -H "Authorization: Bearer deadbeefdeadbeefdeadbeefdeadbeef" \
  -d '{"query": "{ _meta { block { number } } }"}'
```

### redpanda

```bash
docker exec -it redpanda rpk topic consume gateway_client_query_results --brokers="localhost:9092"
```

### studio

Requires `STUDIO_SOURCE_ROOT` and `COMPOSE_FILE=docker-compose.yaml:compose/dev/studio.yaml` —
see `compose/dev/README.md`.

- UI: http://localhost:5000/studio
- API: http://localhost:4000 — `/graphql`, `/.well-known/jwks.json`
- Redis: `redis-cli -p 6379 ping`

Seed a verified studio user so a MetaMask wallet can sign in and publish
without the email-confirmation prompt:

```bash
./scripts/seed-studio-user.sh 0xYOUR_METAMASK_ADDRESS
# e.g. ACCOUNT0: ./scripts/seed-studio-user.sh 0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266
```

To publish a subgraph from Studio, the connected MetaMask wallet must have ETH
on the local chain to cover gas. Fund it then mine a block so MetaMask picks
up the new balance:

```bash
./scripts/fund-wallet.sh <metamask_address> [amount_in_eth]
./scripts/mine-block.sh
```

