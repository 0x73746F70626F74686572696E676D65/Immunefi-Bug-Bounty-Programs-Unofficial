//! # Graph Tally Core
//!
//! Core library for the Graph Tally protocol: a fast, efficient and trustless
//! unidirectional micro-payments system.
//!
//! ## Getting started
//!
//! To get started with the Graph Tally protocol, take a look on the [`manager`] module
//! to see how to manage the state channel and implement the needed adapters.

use std::time::{SystemTime, UNIX_EPOCH};

use thegraph_core::alloy::{dyn_abi::Eip712Domain, primitives::Address, sol_types::eip712_domain};
use thiserror::Error;

mod error;
pub mod manager;
pub mod rav_request;
pub mod receipt;
pub mod signed_message;

pub use error::Error;
use error::Result;

fn get_current_timestamp_u64_ns() -> Result<u64> {
    Ok(SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|err| Error::InvalidSystemTime {
            source_error_message: err.to_string(),
        })?
        .as_nanos() as u64)
}

/// The EIP712 domain separator builder for the Graph Tally protocol.
///
/// This is the current domain separator that is used for the [EIP712](https://eips.ethereum.org/EIPS/eip-712) signature scheme.
///
/// It's used to validate the signature of the `ReceiptAggregateVoucher` and `Receipt` structs.
///
/// You can take a look on deployed [GraphTallyCollector](https://github.com/graphprotocol/contracts/blob/main/packages/horizon/contracts/payments/collectors/GraphTallyCollector.sol)
/// contract [here](https://github.com/graphprotocol/contracts/blob/main/packages/horizon/addresses.json)
///
/// The domain separator is defined as:
/// - `name`: "GraphTallyCollector"
/// - `version`: "1"
/// - `chain_id`: The chain ID of the chain where the domain separator is deployed.
/// - `verifying_contract`: The address of the contract that is verifying the signature.
pub fn graph_tally_eip712_domain(
    chain_id: u64,
    verifying_contract_address: Address,
) -> Eip712Domain {
    eip712_domain! {
        name: "GraphTallyCollector",
        version: "1",
        chain_id: chain_id,
        verifying_contract: verifying_contract_address,
    }
}

#[cfg(test)]
mod tests {
    use std::str::FromStr;

    use graph_tally_graph::{Receipt, ReceiptAggregateVoucher};
    use rstest::*;
    use thegraph_core::alloy::{
        dyn_abi::Eip712Domain,
        primitives::{Address, FixedBytes},
        signers::local::PrivateKeySigner,
    };

    use crate::{graph_tally_eip712_domain, signed_message::Eip712SignedMessage};

    #[fixture]
    fn keys() -> (PrivateKeySigner, Address) {
        let wallet = PrivateKeySigner::random();
        let address = wallet.address();

        (wallet, address)
    }

    #[fixture]
    fn collection_id() -> FixedBytes<32> {
        FixedBytes::from([0xab; 32])
    }

    #[fixture]
    fn payer() -> Address {
        Address::from_str("0xabababababababababababababababababababab").unwrap()
    }

    #[fixture]
    fn data_service() -> Address {
        Address::from_str("0xdeaddeaddeaddeaddeaddeaddeaddeaddeaddead").unwrap()
    }

    #[fixture]
    fn service_provider() -> Address {
        Address::from_str("0xbeefbeefbeefbeefbeefbeefbeefbeefbeefbeef").unwrap()
    }

    #[fixture]
    fn domain_separator() -> Eip712Domain {
        graph_tally_eip712_domain(1, Address::from([0x11u8; 20]))
    }

    #[rstest]
    #[case::basic_rav_test (vec![45,56,34,23])]
    #[case::rav_from_zero_valued_receipts (vec![0,0,0,0])]
    #[test]
    fn signed_rav_is_valid_with_no_previous_rav(
        keys: (PrivateKeySigner, Address),
        collection_id: FixedBytes<32>,
        payer: Address,
        data_service: Address,
        service_provider: Address,
        domain_separator: Eip712Domain,
        #[case] values: Vec<u128>,
    ) {
        // Create receipts
        let mut receipts = Vec::new();
        for value in values {
            receipts.push(
                Eip712SignedMessage::new(
                    &domain_separator,
                    Receipt::new(collection_id, payer, data_service, service_provider, value)
                        .unwrap(),
                    &keys.0,
                )
                .unwrap(),
            );
        }

        // Skipping receipts validation in this test, aggregate_receipts assumes receipts are valid.

        let rav = ReceiptAggregateVoucher::aggregate_receipts(
            collection_id,
            payer,
            data_service,
            service_provider,
            &receipts,
            None,
        )
        .unwrap();
        let signed_rav = Eip712SignedMessage::new(&domain_separator, rav, &keys.0).unwrap();
        assert!(signed_rav.recover_signer(&domain_separator).unwrap() == keys.1);
    }

    #[rstest]
    #[case::basic_rav_test(vec![45,56,34,23])]
    #[case::rav_from_zero_valued_receipts(vec![0,0,0,0])]
    #[test]
    fn signed_rav_is_valid_with_previous_rav(
        keys: (PrivateKeySigner, Address),
        collection_id: FixedBytes<32>,
        payer: Address,
        data_service: Address,
        service_provider: Address,
        domain_separator: Eip712Domain,
        #[case] values: Vec<u128>,
    ) {
        // Create receipts
        let mut receipts = Vec::new();
        for value in values {
            receipts.push(
                Eip712SignedMessage::new(
                    &domain_separator,
                    Receipt::new(collection_id, payer, data_service, service_provider, value)
                        .unwrap(),
                    &keys.0,
                )
                .unwrap(),
            );
        }

        // Create previous RAV from first half of receipts
        let prev_rav = ReceiptAggregateVoucher::aggregate_receipts(
            collection_id,
            payer,
            data_service,
            service_provider,
            &receipts[0..receipts.len() / 2],
            None,
        )
        .unwrap();
        let signed_prev_rav =
            Eip712SignedMessage::new(&domain_separator, prev_rav, &keys.0).unwrap();

        // Create new RAV from last half of receipts and prev_rav
        let rav = ReceiptAggregateVoucher::aggregate_receipts(
            collection_id,
            payer,
            data_service,
            service_provider,
            &receipts[receipts.len() / 2..receipts.len()],
            Some(signed_prev_rav),
        )
        .unwrap();
        let signed_rav = Eip712SignedMessage::new(&domain_separator, rav, &keys.0).unwrap();

        assert!(signed_rav.recover_signer(&domain_separator).unwrap() == keys.1);
    }
}
