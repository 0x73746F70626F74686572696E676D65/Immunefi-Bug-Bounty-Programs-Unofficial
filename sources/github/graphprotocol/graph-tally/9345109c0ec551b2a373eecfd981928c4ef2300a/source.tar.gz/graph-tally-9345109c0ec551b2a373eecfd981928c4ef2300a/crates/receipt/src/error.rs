use serde::{Deserialize, Serialize};
use thegraph_core::alloy::primitives::FixedBytes;

/// Error type for receipts
#[derive(thiserror::Error, Debug, Clone, Serialize, Deserialize)]
pub enum ReceiptError {
    #[error("invalid collection ID: {received_collection_id}")]
    InvalidCollectionID {
        received_collection_id: FixedBytes<32>,
    },
    #[error("Signature check failed:\n{source_error_message}")]
    InvalidSignature { source_error_message: String },
    #[error("invalid timestamp: {received_timestamp} (expected min {timestamp_min})")]
    InvalidTimestamp {
        received_timestamp: u64,
        timestamp_min: u64,
    },
    #[error("Invalid Value: {received_value} ")]
    InvalidValue { received_value: u128 },
    #[error("Receipt is not unique")]
    NonUniqueReceipt,
    #[error("Attempt to collect escrow failed")]
    SubtractEscrowFailed,
    #[error("Issue encountered while performing check: {0}")]
    CheckFailure(String),
    #[error("Retryable check error encountered: {0}")]
    RetryableCheck(String),
}
