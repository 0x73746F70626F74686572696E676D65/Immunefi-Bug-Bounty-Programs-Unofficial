# Changelog

## [1.0.0](https://github.com/graphprotocol/graph-tally/compare/graph_tally_eip712_message-v0.2.3...graph_tally_eip712_message-v1.0.0) (2026-04-30)


### ⚠ BREAKING CHANGES

* rename to grap tally

### Features

* bump for release ([#287](https://github.com/graphprotocol/graph-tally/issues/287)) ([3ba2620](https://github.com/graphprotocol/graph-tally/commit/3ba262076754e504d45e421ac3b46f4a517a774f))


### Bug Fixes

* revert cargo version bumping ([7afcd92](https://github.com/graphprotocol/graph-tally/commit/7afcd9231f3a592418b93f0061411df0e474a725))


### Code Refactoring

* rename to grap tally ([4587f60](https://github.com/graphprotocol/graph-tally/commit/4587f60c69eecefccd717fa7bd38ddc0f140e788))

## [0.2.3](https://github.com/semiotic-ai/timeline-aggregation-protocol/compare/tap_eip712_message-v0.2.2...tap_eip712_message-v0.2.3) (2025-09-11)


### Bug Fixes

* **tap-eip712:** break circular dependency with tap-graph for releases ([22388fa](https://github.com/semiotic-ai/timeline-aggregation-protocol/commit/22388faab3a1c7d0dd3841c90e69cc784ba39f7d))

## [0.2.2](https://github.com/semiotic-ai/timeline-aggregation-protocol/compare/tap_eip712_message-v0.2.1...tap_eip712_message-v0.2.2) (2025-05-27)


### Bug Fixes

* **eip712-message:** canonicalize to low-S before returning bytes ([1586b0f](https://github.com/semiotic-ai/timeline-aggregation-protocol/commit/1586b0f2f2b8d3ec146c58475442a8f9e0067a35))

## [0.2.1](https://github.com/semiotic-ai/timeline-aggregation-protocol/compare/tap_eip712_message-v0.2.0...tap_eip712_message-v0.2.1) (2025-05-09)


### Bug Fixes

* **eip712:** enhance receipt uniqueness verification ([0f5bb43](https://github.com/semiotic-ai/timeline-aggregation-protocol/commit/0f5bb43e49d286441a239f882f658c570a0ed468))

## [0.2.0](https://github.com/semiotic-ai/timeline-aggregation-protocol/compare/tap_eip712_message-v0.1.0...tap_eip712_message-v0.2.0) (2025-04-22)


### Features

* bump for release ([#287](https://github.com/semiotic-ai/timeline-aggregation-protocol/issues/287)) ([3ba2620](https://github.com/semiotic-ai/timeline-aggregation-protocol/commit/3ba262076754e504d45e421ac3b46f4a517a774f))

## 0.1.0 (2025-01-28)


### ⚠ BREAKING CHANGES

* rename EIP712SignedMessage to Eip712SignedMessage
* create tap_eip712_message, tap_receipts and tap_graph ([#268](https://github.com/semiotic-ai/timeline-aggregation-protocol/issues/268))

### Code Refactoring

* create tap_eip712_message, tap_receipts and tap_graph ([#268](https://github.com/semiotic-ai/timeline-aggregation-protocol/issues/268)) ([3d35cac](https://github.com/semiotic-ai/timeline-aggregation-protocol/commit/3d35cac73159a89125051b5148a88efc63eb2193))
* rename EIP712SignedMessage to Eip712SignedMessage ([0b0b59e](https://github.com/semiotic-ai/timeline-aggregation-protocol/commit/0b0b59e380c9e2f04da2b28c26ccd0202f15a4a8))
