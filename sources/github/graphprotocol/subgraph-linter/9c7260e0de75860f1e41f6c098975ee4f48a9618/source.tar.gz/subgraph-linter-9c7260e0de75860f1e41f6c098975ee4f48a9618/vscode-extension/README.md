# Subgraph Linter for VS Code

Surface Subgraph Linter diagnostics inside VS Code with the bundled language server.

## Features
- Diagnostics-only language server for The Graph mappings; highlights potential entity overwrites, unexpected nulls, unchecked loads/non-nulls, unsafe divisions, derived field issues, and helper return contract violations.
- Auto-discovers `subgraph.yaml` in your workspace.
- Runs automatically on save (configurable) and can be triggered manually from the Command Palette.
- Respects your linter config and severity overrides, so diagnostics in VS Code match your project settings.
- Undeclared eth_call warnings include a quick fix that adds the `calls:` declaration to your manifest.
- Any Subgraph Linter diagnostic can be suppressed with a quick fix that inserts `// [allow(<check-id>)]`.

## Usage
1) Open a workspace containing a subgraph manifest. The extension will locate it and start the analyzer.  
2) Fix diagnostics inline; warnings and errors show in the Problems panel.  
3) Run manually anytime via **Subgraph Linter: Run Analysis** (`subgraph-linter.runAnalysis`).

## Settings (prefix `subgraphLinter`)
- `manifestPaths`: array of manifest paths to use instead of auto-discovery.
- `tsconfigPath`: `tsconfig.json` to pass to the analyzer.
- `configPath`: linter config path (defaults to `subgraph-linter.config.json` in the workspace; supports `severityOverrides`).
- `runOnSave`: boolean, run analysis when files are saved (default `true`).

## How it works
- The extension ships with the bundled language server and can surface diagnostics plus optional quick fixes (e.g., manifest call declarations).
- Severity shown in VS Code mirrors the linter’s configuration; warnings do not block builds.
