declare module 'vscode' {
  export type Disposable = { dispose(): void }

  export interface Uri {
    fsPath: string
  }

  export const Uri: {
    file(path: string): Uri
  }

  export class Position {
    line: number
    character: number
    constructor(line: number, character: number)
  }

  export class Range {
    start: Position
    end: Position
    constructor(start: Position, end: Position)
  }

  export interface TextDocument {
    uri: Uri
    getText(): string
    positionAt(offset: number): Position
    save(): Thenable<void>
  }

  export interface WorkspaceConfiguration {
    get<T>(section: string): T | undefined
  }

  export interface WorkspaceState {
    get<T>(key: string): T | undefined
    update(key: string, value: any): Thenable<void>
  }

  export interface ExtensionContext {
    asAbsolutePath(relativePath: string): string
    subscriptions: Array<{ dispose(): any } | Disposable>
    workspaceState: WorkspaceState
  }

  export const commands: {
    registerCommand(id: string, callback: (...args: any[]) => any): Disposable
  }

  export class WorkspaceEdit {
    replace(uri: Uri, range: Range, newText: string): void
  }

  export const workspace: {
    isTrusted: boolean
    workspaceFolders?: Array<{ uri: Uri }>
    getConfiguration(section?: string): WorkspaceConfiguration
    onDidGrantWorkspaceTrust(callback: () => void): Disposable
    findFiles(globPattern: string, exclude?: string, maxResults?: number): Thenable<Uri[]>
    createFileSystemWatcher(globPattern: string): any
    onDidSaveTextDocument(listener: (...args: any[]) => any): Disposable
    openTextDocument(uri: Uri): Thenable<TextDocument>
    applyEdit(edit: WorkspaceEdit): Thenable<boolean>
  }

  export const window: {
    showQuickPick<T extends { label: string; description?: string }>(
      items: readonly T[] | Thenable<readonly T[]>,
      options?: { placeHolder?: string },
    ): Thenable<T | undefined>
    showErrorMessage(message: string): Thenable<void>
    showInformationMessage(message: string): Thenable<void>
  }

  export type DocumentSelector = Array<{ language: string; scheme?: string }>

  export interface Diagnostic {
    range: Range
    message: string
    code?: string | number
    source?: string
    data?: any
  }

  export interface CodeActionContext {
    diagnostics: Diagnostic[]
  }

  export class CodeActionKind {
    static QuickFix: CodeActionKind
  }

  export class CodeAction {
    constructor(title: string, kind?: CodeActionKind)
    command?: { command: string; title: string; arguments?: any[] }
    edit?: WorkspaceEdit
    diagnostics?: Diagnostic[]
    isPreferred?: boolean
  }

  export interface CodeActionProvider {
    provideCodeActions(
      document: TextDocument,
      range: Range,
      context: CodeActionContext,
    ): CodeAction[] | undefined | null | Thenable<CodeAction[] | undefined | null>
  }

  export const languages: {
    registerCodeActionsProvider(
      selector: DocumentSelector,
      provider: CodeActionProvider,
      metadata?: { providedCodeActionKinds?: CodeActionKind[] },
    ): Disposable
  }
}
