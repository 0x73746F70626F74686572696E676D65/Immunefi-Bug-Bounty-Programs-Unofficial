import path from 'node:path'
import * as vscode from 'vscode'
import YAML from 'yaml'
let client: any | undefined
let languageClientModule: any | undefined
const diagnosticMetadataStore = new Map<string, UndeclaredEthCallMetadata>()

export async function activate(context: vscode.ExtensionContext) {
  if (!vscode.workspace.isTrusted) {
    vscode.workspace.onDidGrantWorkspaceTrust(() => {
      void startClient(context)
    })
    return
  }
  await startClient(context)
}

async function startClient(context: vscode.ExtensionContext) {
  if (!languageClientModule) {
    try {
      languageClientModule = await import('vscode-languageclient/node')
    } catch (error) {
      void vscode.window.showErrorMessage(
        'Subgraph Linter: missing vscode-languageclient dependency. Run npm install in vscode-extension and rebuild.',
      )
      return
    }
  }

  const {
    LanguageClient,
    TransportKind,
  }: { LanguageClient: any; TransportKind: any } = languageClientModule

  const manifestPaths = await getManifestPaths(context)
  const tsconfigPath =
    vscode.workspace.getConfiguration('subgraphLinter').get<string>('tsconfigPath') || undefined
  const configPath =
    vscode.workspace.getConfiguration('subgraphLinter').get<string>('configPath') || undefined
  const runOnSave = vscode.workspace.getConfiguration('subgraphLinter').get<boolean>('runOnSave') ?? true

  const serverModule = context.asAbsolutePath(path.join('dist', 'analyzer', 'server.js'))
  const serverOptions: any = {
    run: { module: serverModule, transport: TransportKind.ipc },
    debug: { module: serverModule, transport: TransportKind.ipc, options: { execArgv: ['--nolazy', '--inspect=6009'] } },
  }

  const clientOptions: any = {
    documentSelector: [
      { scheme: 'file', language: 'typescript' },
      { scheme: 'file', language: 'javascript' },
      { scheme: 'file', language: 'typescriptreact' },
    ],
    synchronize: runOnSave
      ? {
          fileEvents: vscode.workspace.createFileSystemWatcher('**/*.{ts,tsx,js,jsx}'),
        }
      : undefined,
    initializationOptions: {
      manifestPaths,
      tsconfigPath,
      configPath,
    },
    middleware: {
      handleDiagnostics: (uri: vscode.Uri, diagnostics: any[], next: (uri: vscode.Uri, diagnostics: any[]) => void) => {
        storeDiagnosticMetadata({
          uri: uri.toString(),
          diagnostics: diagnostics.map((diag) => ({
            range: diag.range,
            message: diag.message,
            code: diag.code,
            data: diag.data,
          })),
        })
        next(uri, diagnostics)
      },
    },
  }

  client = new LanguageClient('subgraphLinter', 'Subgraph Linter', serverOptions, clientOptions)

  context.subscriptions.push(client.start())

  context.subscriptions.push(
    vscode.workspace.onDidSaveTextDocument(() => {
      if (runOnSave && client) {
        client.sendNotification('subgraphLinter/runAnalysis')
      }
    }),
  )

  context.subscriptions.push(
    vscode.commands.registerCommand('subgraph-linter.runAnalysis', () => {
      client?.sendNotification('subgraphLinter/runAnalysis')
    }),
  )

  context.subscriptions.push(
    vscode.commands.registerCommand('subgraph-linter.addCallDeclaration', async (metadata: unknown) => {
      if (!metadata || typeof metadata !== 'object') {
        void vscode.window.showErrorMessage('Subgraph Linter: unable to apply fix (missing metadata).')
        return
      }
      await addCallDeclaration(metadata)
    }),
  )

  context.subscriptions.push(
    vscode.languages.registerCodeActionsProvider(
      [
        { scheme: 'file', language: 'typescript' },
        { scheme: 'file', language: 'javascript' },
        { scheme: 'file', language: 'typescriptreact' },
      ],
      new UndeclaredEthCallCodeActionProvider(),
      { providedCodeActionKinds: [vscode.CodeActionKind.QuickFix] },
    ),
  )

  context.subscriptions.push(
    vscode.languages.registerCodeActionsProvider(
      [
        { scheme: 'file', language: 'typescript' },
        { scheme: 'file', language: 'javascript' },
        { scheme: 'file', language: 'typescriptreact' },
      ],
      new SuppressDiagnosticCodeActionProvider(),
      { providedCodeActionKinds: [vscode.CodeActionKind.QuickFix] },
    ),
  )
}

export function deactivate(): Thenable<void> | undefined {
  if (!client) {
    return undefined
  }
  return client.stop()
}

async function getManifestPaths(context: vscode.ExtensionContext): Promise<string[]> {
  const configured = vscode.workspace
    .getConfiguration('subgraphLinter')
    .get<string[]>('manifestPaths')
  if (configured && configured.length) {
    return configured
  }
  const folders = vscode.workspace.workspaceFolders
  if (!folders || folders.length === 0) {
    return []
  }
  const root = folders[0].uri.fsPath
  const candidates = await discoverManifests(root)
  if (candidates.length === 1) {
    return candidates
  }
  if (candidates.length > 1) {
    const saved = context.workspaceState.get<string>('subgraphLinter.selectedManifest')
    if (saved && candidates.includes(saved)) {
      return [saved]
    }
    const picked = await vscode.window.showQuickPick(
      candidates.map((c) => ({
        label: path.relative(root, c),
        description: c,
      })),
      { placeHolder: 'Select subgraph manifest for analysis' },
    )
    if (picked?.description) {
      await context.workspaceState.update('subgraphLinter.selectedManifest', picked.description)
      return [picked.description]
    }
  }
  return candidates
}

async function discoverManifests(root: string): Promise<string[]> {
  const matches = await vscode.workspace.findFiles(
    '**/subgraph.yaml',
    '**/{node_modules,build,dist}/**',
    50,
  )
  return matches
    .map((uri: vscode.Uri) => uri.fsPath)
    .filter(
      (p: string) =>
        p.startsWith(root) &&
        !p.includes(`${path.sep}build${path.sep}`) &&
        !p.includes(`${path.sep}dist${path.sep}`),
    )
}

type UndeclaredEthCallMetadata = {
  type?: string
  handlerName?: string
  manifestPath?: string
  mappingFilePath?: string
  fixAvailable?: boolean
  label?: string
  declaration?: string
  abiName?: string
  functionName?: string
  bindingExpr?: string
  argExprs?: string[]
}

class UndeclaredEthCallCodeActionProvider implements vscode.CodeActionProvider {
  provideCodeActions(document: vscode.TextDocument, __: vscode.Range, context: vscode.CodeActionContext) {
    const actions: vscode.CodeAction[] = []
    for (const diagnostic of context.diagnostics) {
      if (diagnostic.source !== 'subgraph-linter' || diagnostic.code !== 'undeclared-eth-call') {
        continue
      }
      const metadata = getMetadataForDiagnostic(document, diagnostic) ?? (diagnostic as any).data
      if (!isUndeclaredEthCallMetadata(metadata)) {
        continue
      }
      const fixAvailable = metadata.fixAvailable ?? Boolean(metadata.declaration)
      if (!fixAvailable || !metadata.declaration) {
        continue
      }
      const title = metadata.label
        ? `Declare ${metadata.label} in manifest`
        : 'Declare contract call in manifest'
      const action = new vscode.CodeAction(title, vscode.CodeActionKind.QuickFix)
      action.command = {
        command: 'subgraph-linter.addCallDeclaration',
        title,
        arguments: [metadata],
      }
      action.diagnostics = [diagnostic]
      action.isPreferred = true
      actions.push(action)
    }
    return actions
  }
}

class SuppressDiagnosticCodeActionProvider implements vscode.CodeActionProvider {
  provideCodeActions(document: vscode.TextDocument, __: vscode.Range, context: vscode.CodeActionContext) {
    const actions: vscode.CodeAction[] = []
    for (const diagnostic of context.diagnostics) {
      if (diagnostic.source !== 'subgraph-linter') {
        continue
      }
      if (typeof diagnostic.code !== 'string' || !diagnostic.code) {
        continue
      }
      const checkId = diagnostic.code
      const action = buildSuppressAction(document, diagnostic, checkId)
      if (action) {
        actions.push(action)
      }
    }
    return actions
  }
}

function isUndeclaredEthCallMetadata(value: unknown): value is Required<Pick<UndeclaredEthCallMetadata, 'manifestPath' | 'handlerName' | 'mappingFilePath'>> &
  UndeclaredEthCallMetadata {
  if (!value || typeof value !== 'object') {
    return false
  }
  const candidate = value as Record<string, unknown>
  return (
    typeof candidate.manifestPath === 'string' &&
    typeof candidate.handlerName === 'string' &&
    typeof candidate.mappingFilePath === 'string'
  )
}

async function addCallDeclaration(metadata: unknown): Promise<void> {
  if (!isUndeclaredEthCallMetadata(metadata)) {
    void vscode.window.showErrorMessage('Subgraph Linter: unable to apply fix (missing metadata).')
    return
  }
  const manifestUri = vscode.Uri.file(metadata.manifestPath)
  let document
  try {
    document = await vscode.workspace.openTextDocument(manifestUri)
  } catch (error) {
    void vscode.window.showErrorMessage(
      `Subgraph Linter: unable to open manifest at ${metadata.manifestPath}. ${(error as Error).message}`,
    )
    return
  }
  let manifest: any
  try {
    manifest = YAML.parse(document.getText()) ?? {}
  } catch (error) {
    void vscode.window.showErrorMessage(`Subgraph Linter: failed to parse manifest. ${(error as Error).message}`)
    return
  }
  const result = insertCallDeclaration(manifest, metadata, metadata.manifestPath)
  if (result === 'not-found') {
    void vscode.window.showErrorMessage(
      `Subgraph Linter: handler ${metadata.handlerName} was not found in ${metadata.manifestPath}.`,
    )
    return
  }
  if (result === 'exists') {
    void vscode.window.showInformationMessage('Subgraph Linter: call declaration already exists in manifest.')
    return
  }
  const newText = YAML.stringify(manifest)
  const edit = new vscode.WorkspaceEdit()
  const fullRange = new vscode.Range(document.positionAt(0), document.positionAt(document.getText().length))
  edit.replace(manifestUri, fullRange, newText)
  const applied = await vscode.workspace.applyEdit(edit)
  if (!applied) {
    void vscode.window.showErrorMessage('Subgraph Linter: failed to update manifest.')
    return
  }
  await document.save()
  void vscode.window.showInformationMessage('Subgraph Linter: added call declaration to manifest.')
}

function insertCallDeclaration(
  manifest: any,
  metadata: UndeclaredEthCallMetadata,
  manifestPath: string,
): 'added' | 'exists' | 'not-found' {
  const sections = ['dataSources', 'templates'] as const
  for (const section of sections) {
    const collection = manifest?.[section]
    if (!Array.isArray(collection)) continue
    for (const source of collection) {
      const mapping = source?.mapping
      if (!mapping || typeof mapping !== 'object') continue
      const mappingFile = mapping.file
      if (typeof mappingFile !== 'string' || mappingFile.length === 0) continue
      const resolvedMapping = path.resolve(path.dirname(manifestPath), mappingFile)
      if (metadata.mappingFilePath && resolvedMapping !== metadata.mappingFilePath) {
        continue
      }
      const handlerLists = getHandlerLists(mapping)
      for (const handlerEntry of handlerLists) {
        if (!handlerEntry || typeof handlerEntry !== 'object') continue
        if (handlerEntry.handler !== metadata.handlerName) continue
        if (!handlerEntry.calls || typeof handlerEntry.calls !== 'object') {
          handlerEntry.calls = {}
        }
        const label = metadata.label ?? `${metadata.abiName ?? 'Contract'}.${metadata.functionName ?? 'method'}`
        const declaration = metadata.declaration ?? buildDeclarationFromMetadata(metadata)
        if (handlerEntry.calls[label] === declaration) {
          return 'exists'
        }
        handlerEntry.calls[label] = declaration
        return 'added'
      }
    }
  }
  return 'not-found'
}

function getHandlerLists(mapping: any): any[] {
  const keys = ['eventHandlers', 'callHandlers', 'blockHandlers', 'fullHandlers']
  const lists: any[] = []
  for (const key of keys) {
    const list = mapping[key]
    if (Array.isArray(list)) {
      for (const item of list) {
        lists.push(item)
      }
    }
  }
  return lists
}

function buildDeclarationFromMetadata(metadata: UndeclaredEthCallMetadata): string {
  const abi = metadata.abiName ?? 'Contract'
  const functionName = metadata.functionName ?? 'method'
  const binding = metadata.bindingExpr ?? 'event.address'
  const args = metadata.argExprs && metadata.argExprs.length > 0 ? metadata.argExprs.join(', ') : ''
  return `${abi}[${binding}].${functionName}(${args})`
}

type StoredDiagnostic = {
  range: RangeLike
  message: string
  code?: string | number
  data?: UndeclaredEthCallMetadata
}

type PublishDiagnosticsParams = {
  uri: string
  diagnostics: StoredDiagnostic[]
}

function storeDiagnosticMetadata(params: PublishDiagnosticsParams): void {
  deleteMetadataForUri(params.uri)
  for (const diagnostic of params.diagnostics) {
    if (diagnostic.code !== 'undeclared-eth-call') continue
    if (!diagnostic.data || !isUndeclaredEthCallMetadata(diagnostic.data)) continue
    const key = buildDiagnosticKey(params.uri, diagnostic.range, diagnostic.message)
    diagnosticMetadataStore.set(key, diagnostic.data)
  }
}

function deleteMetadataForUri(uri: string): void {
  for (const key of diagnosticMetadataStore.keys()) {
    if (key.startsWith(`${uri}::`)) {
      diagnosticMetadataStore.delete(key)
    }
  }
}

type RangeLike = {
  start: { line: number; character: number }
  end: { line: number; character: number }
}

function buildDiagnosticKey(uri: string, range: RangeLike, message: string): string {
  return `${uri}::${range.start.line}:${range.start.character}:${range.end.line}:${range.end.character}::${message}`
}

function getMetadataForDiagnostic(
  document: vscode.TextDocument,
  diagnostic: vscode.Diagnostic,
): UndeclaredEthCallMetadata | undefined {
  const key = buildDiagnosticKey(
    document.uri.toString(),
    {
      start: { line: diagnostic.range.start.line, character: diagnostic.range.start.character },
      end: { line: diagnostic.range.end.line, character: diagnostic.range.end.character },
    },
    diagnostic.message,
  )
  return diagnosticMetadataStore.get(key)
}

function buildSuppressAction(
  document: vscode.TextDocument,
  diagnostic: vscode.Diagnostic,
  checkId: string,
): vscode.CodeAction | null {
  const text = document.getText()
  const line0 = diagnostic.range.start.line
  const startOffset = offsetAtLineStart(text, line0)
  const lineText = getLineText(text, line0)
  const indentation = (lineText.match(/^\s*/) ?? [''])[0]
  const newline = text.includes('\r\n') ? '\r\n' : '\n'
  const directiveLine = `${indentation}// [allow(${checkId})]`

  if (line0 > 0) {
    const prevLine = getLineText(text, line0 - 1).trim()
    if (prevLine === directiveLine.trim()) {
      return null
    }
  }

  const edit = new vscode.WorkspaceEdit()
  const insertPosition = document.positionAt(startOffset)
  edit.replace(document.uri, new vscode.Range(insertPosition, insertPosition), `${directiveLine}${newline}`)

  const title = `Suppress ${checkId} on this line`
  const action = new vscode.CodeAction(title, vscode.CodeActionKind.QuickFix)
  action.edit = edit
  action.diagnostics = [diagnostic]
  action.isPreferred = false
  return action
}

function offsetAtLineStart(text: string, line0: number): number {
  if (line0 <= 0) {
    return 0
  }
  let line = 0
  for (let i = 0; i < text.length; i += 1) {
    if (text[i] === '\n') {
      line += 1
      if (line === line0) {
        return i + 1
      }
    }
  }
  return text.length
}

function getLineText(text: string, line0: number): string {
  const start = offsetAtLineStart(text, line0)
  let end = text.indexOf('\n', start)
  if (end === -1) {
    end = text.length
  }
  if (end > start && text[end - 1] === '\r') {
    end -= 1
  }
  return text.slice(start, end)
}
