import { existsSync, readFileSync } from 'node:fs'
import path from 'node:path'
import process from 'node:process'
import { parse as parseYaml } from 'yaml'

import type { HandlerCallDeclaration, Issue, ManifestInfo } from './types.js'

export type AnalyzerConfig = {
  severityOverrides?: Record<string, 'error' | 'warning'>
  suppression?: {
    allowWarnings?: boolean
    allowErrors?: boolean
  }
}

export function loadConfig(configPath?: string): AnalyzerConfig {
  const defaultPath = path.resolve('subgraph-linter.config.json')
  const resolvedPath = configPath ? path.resolve(configPath) : defaultPath
  if (!configPath && !existsSync(resolvedPath)) {
    return {}
  }
  if (!existsSync(resolvedPath)) {
    console.error(`Config file not found: ${resolvedPath}`)
    process.exit(1)
  }
  try {
    const raw = readFileSync(resolvedPath, 'utf8')
    const parsed = JSON.parse(raw) as AnalyzerConfig
    validateConfig(parsed, resolvedPath)
    return parsed ?? {}
  } catch (error) {
    console.error(`Failed to read config ${resolvedPath}: ${(error as Error).message}`)
    process.exit(1)
  }
}

export function applySeverityOverrides(
  issues: Issue[],
  overrides: Record<string, 'error' | 'warning'>,
): Issue[] {
  if (!overrides || Object.keys(overrides).length === 0) {
    return issues
  }
  return issues.map((issue) => {
    const override = overrides[issue.checkId]
    if (!override) {
      return issue
    }
    return { ...issue, severity: override }
  })
}

export function loadManifestInfo(manifestPaths: string[]): ManifestInfo {
  const handlerNames = new Set<string>()
  const mappingFilePaths = new Set<string>()
  const schemaPaths = new Set<string>()
  const declaredCalls = new Map<string, Map<string, HandlerCallDeclaration[]>>()
  const handlerManifestPaths = new Map<string, string>()

  for (const manifestPath of manifestPaths) {
    const resolvedPath = path.resolve(manifestPath)
    if (!existsSync(resolvedPath)) {
      console.error(`Manifest file not found: ${manifestPath}`)
      process.exit(1)
    }

    let rawContents: string
    try {
      rawContents = readFileSync(resolvedPath, 'utf8')
    } catch (error) {
      console.error(`Failed to read manifest ${manifestPath}: ${(error as Error).message}`)
      process.exit(1)
    }

    let manifest: unknown
    try {
      manifest = parseYaml(rawContents)
    } catch (error) {
      console.error(`Failed to parse manifest ${manifestPath}: ${(error as Error).message}`)
      process.exit(1)
    }

    collectManifestData(
      manifest,
      path.dirname(resolvedPath),
      resolvedPath,
      handlerNames,
      mappingFilePaths,
      schemaPaths,
      declaredCalls,
      handlerManifestPaths,
    )
  }

  if (handlerNames.size === 0) {
    console.error('No handler definitions found in provided manifest(s).')
    process.exit(1)
  }

  if (mappingFilePaths.size === 0) {
    console.error('No mapping.file entries found in provided manifest(s).')
    process.exit(1)
  }

  if (schemaPaths.size === 0) {
    console.error('No schema.file entries found in provided manifest(s).')
    process.exit(1)
  }

  return { handlerNames, mappingFilePaths, schemaPaths, declaredCalls, handlerManifestPaths }
}

function collectManifestData(
  manifest: unknown,
  manifestDir: string,
  manifestPath: string,
  handlerNames: Set<string>,
  mappingFilePaths: Set<string>,
  schemaPaths: Set<string>,
  declaredCalls: Map<string, Map<string, HandlerCallDeclaration[]>>,
  handlerManifestPaths: Map<string, string>,
) {
  if (!manifest || typeof manifest !== 'object') {
    return
  }

  const manifestObj = manifest as Record<string, unknown>
  const schemaEntry = manifestObj.schema
  if (schemaEntry && typeof schemaEntry === 'object') {
    const schemaFile = (schemaEntry as Record<string, unknown>).file
    if (typeof schemaFile === 'string' && schemaFile.length > 0) {
      const resolvedSchema = path.resolve(manifestDir, schemaFile)
      if (!existsSync(resolvedSchema)) {
        console.error(
          `Schema file "${schemaFile}" referenced in ${manifestPath} does not exist (resolved to ${resolvedSchema}).`,
        )
        process.exit(1)
      }
      schemaPaths.add(resolvedSchema)
    }
  }

  const sections: Array<'dataSources' | 'templates'> = ['dataSources', 'templates']
  const handlerKeys = ['eventHandlers', 'callHandlers', 'blockHandlers', 'fullHandlers'] as const

  for (const section of sections) {
    const dataSources = manifestObj[section]
    if (!Array.isArray(dataSources)) continue

    for (const source of dataSources) {
      if (!source || typeof source !== 'object') continue
      const mapping = (source as Record<string, unknown>).mapping
      if (!mapping || typeof mapping !== 'object') continue

      const mappingFile = (mapping as Record<string, unknown>).file
      let resolvedMappingFile: string | null = null
      if (typeof mappingFile === 'string' && mappingFile.length > 0) {
        resolvedMappingFile = path.resolve(manifestDir, mappingFile)
        if (!existsSync(resolvedMappingFile)) {
          console.error(
            `Mapping file "${mappingFile}" referenced in ${manifestPath} does not exist (resolved to ${resolvedMappingFile}).`,
          )
          process.exit(1)
        }
        mappingFilePaths.add(resolvedMappingFile)
      }

      for (const key of handlerKeys) {
        const handlerList = (mapping as Record<string, unknown>)[key]
        if (!Array.isArray(handlerList)) continue

        for (const handler of handlerList) {
          if (!handler || typeof handler !== 'object') continue
          const handlerName = (handler as Record<string, unknown>).handler
          if (typeof handlerName === 'string' && handlerName.length > 0) {
            handlerNames.add(handlerName)
            if (resolvedMappingFile) {
              const handlerDecls = ensureHandlerDeclarationMap(declaredCalls, resolvedMappingFile)
              const declarations = handlerDecls.get(handlerName) ?? []
              const newDecls = parseCallDeclarations(handler as Record<string, unknown>, manifestPath)
              for (const decl of newDecls) {
                if (!declarations.some((existing) => declarationsEqual(existing, decl))) {
                  declarations.push(decl)
                }
              }
              if (declarations.length > 0) {
                handlerDecls.set(handlerName, declarations)
              }
              const handlerKey = makeHandlerKey(resolvedMappingFile, handlerName)
              if (!handlerManifestPaths.has(handlerKey)) {
                handlerManifestPaths.set(handlerKey, manifestPath)
              }
            }
          }
        }
      }
    }
  }
}

function makeHandlerKey(mappingFilePath: string, handlerName: string): string {
  return `${mappingFilePath}::${handlerName}`
}

function ensureHandlerDeclarationMap(
  declaredCalls: Map<string, Map<string, HandlerCallDeclaration[]>>,
  mappingFile: string,
): Map<string, HandlerCallDeclaration[]> {
  const existing = declaredCalls.get(mappingFile)
  if (existing) {
    return existing
  }
  const map = new Map<string, HandlerCallDeclaration[]>()
  declaredCalls.set(mappingFile, map)
  return map
}

function parseCallDeclarations(handler: Record<string, unknown>, manifestPath: string): HandlerCallDeclaration[] {
  const calls = handler.calls
  if (!calls || typeof calls !== 'object') {
    return []
  }
  const declarations: HandlerCallDeclaration[] = []
  for (const [label, entry] of Object.entries(calls)) {
    if (typeof entry !== 'string') {
      continue
    }
    const parsed = parseCallDeclaration(entry)
    if (!parsed) {
      console.warn(`Unable to parse call declaration "${entry}" in ${manifestPath}; skipping.`)
      continue
    }
    declarations.push({ label, ...parsed })
  }
  return declarations
}

function parseCallDeclaration(declaration: string): Omit<HandlerCallDeclaration, 'label'> | null {
  const trimmed = declaration.trim()
  const openBracket = trimmed.indexOf('[')
  const closeBracket = trimmed.indexOf(']', openBracket + 1)
  const dotIndex = trimmed.indexOf('.', closeBracket + 1)
  const openParen = trimmed.indexOf('(', dotIndex + 1)
  const closeParen = trimmed.lastIndexOf(')')
  if (
    openBracket === -1 ||
    closeBracket === -1 ||
    dotIndex === -1 ||
    openParen === -1 ||
    closeParen === -1 ||
    closeParen < openParen
  ) {
    return null
  }
  const abiName = trimmed.slice(0, openBracket).trim()
  const bindingExpr = normalizeManifestExpression(trimmed.slice(openBracket + 1, closeBracket))
  const functionName = trimmed.slice(dotIndex + 1, openParen).trim()
  const argsSegment = trimmed.slice(openParen + 1, closeParen).trim()
  const argExprs =
    argsSegment.length === 0
      ? []
      : argsSegment
          .split(',')
          .map((part) => normalizeManifestExpression(part))
          .filter((part) => part.length > 0)
  if (!abiName || !bindingExpr || !functionName) {
    return null
  }
  return { abiName, functionName, bindingExpr, argExprs }
}

function normalizeManifestExpression(value: string): string {
  return value.replace(/\s+/g, ' ').trim()
}

function declarationsEqual(a: HandlerCallDeclaration, b: HandlerCallDeclaration): boolean {
  if (a.abiName !== b.abiName || a.functionName !== b.functionName || a.bindingExpr !== b.bindingExpr) {
    return false
  }
  if (a.argExprs.length !== b.argExprs.length) {
    return false
  }
  for (let i = 0; i < a.argExprs.length; i += 1) {
    if (a.argExprs[i] !== b.argExprs[i]) {
      return false
    }
  }
  return true
}

function validateConfig(config: AnalyzerConfig, sourcePath: string): void {
  if (!config || typeof config !== 'object') {
    console.error(`Config at ${sourcePath} must be a JSON object.`)
    process.exit(1)
  }
  if (config.severityOverrides && typeof config.severityOverrides === 'object') {
    for (const [checkId, severity] of Object.entries(config.severityOverrides)) {
      if (severity !== 'error' && severity !== 'warning') {
        console.error(
          `Invalid severity "${severity}" for check "${checkId}" in ${sourcePath}. Use "error" or "warning".`,
        )
        process.exit(1)
      }
    }
  }

  if (config.suppression !== undefined) {
    if (!config.suppression || typeof config.suppression !== 'object') {
      console.error(`Config at ${sourcePath} field "suppression" must be an object.`)
      process.exit(1)
    }
    const suppression = config.suppression as Record<string, unknown>
    if (suppression.allowWarnings !== undefined && typeof suppression.allowWarnings !== 'boolean') {
      console.error(
        `Config at ${sourcePath} field "suppression.allowWarnings" must be a boolean.`,
      )
      process.exit(1)
    }
    if (suppression.allowErrors !== undefined && typeof suppression.allowErrors !== 'boolean') {
      console.error(
        `Config at ${sourcePath} field "suppression.allowErrors" must be a boolean.`,
      )
      process.exit(1)
    }
  }
}
