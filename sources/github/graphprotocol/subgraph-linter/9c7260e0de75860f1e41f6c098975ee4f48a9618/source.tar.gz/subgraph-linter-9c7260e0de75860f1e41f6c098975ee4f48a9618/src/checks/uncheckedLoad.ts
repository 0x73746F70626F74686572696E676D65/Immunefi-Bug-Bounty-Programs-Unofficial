import { NonNullExpression, SyntaxKind } from 'ts-morph'

import type { Check, HandlerCheckContext, Issue } from '../types.js'

const CHECK_ID = 'unchecked-load'

export const uncheckedLoadCheck: Check = {
  id: CHECK_ID,
  description: 'Flags non-null assertions on Entity.load results without null checks.',
  run(context) {
    const issues: Issue[] = []
    const assertions = context.handler.getDescendantsOfKind(SyntaxKind.NonNullExpression)
    for (const assertion of assertions) {
      const loadInfo = getLoadCallInfo(assertion)
      if (loadInfo) {
        issues.push(buildIssue(assertion, context.handler.getName() ?? '<anonymous>', loadInfo))
      }
    }
    return issues
  },
}

type LoadCallInfo = {
  calleeText: string
  argText?: string
}

function getLoadCallInfo(assertion: NonNullExpression): LoadCallInfo | null {
  const expr = assertion.getExpression()
  if (!expr || !expr.isKind(SyntaxKind.CallExpression)) {
    return null
  }
  const callee = expr.getExpression()
  if (!callee.isKind(SyntaxKind.PropertyAccessExpression)) {
    return null
  }
  if (callee.getName() !== 'load') {
    return null
  }
  const calleeText = callee.getExpression().getText()
  const firstArg = expr.getArguments()[0]
  return {
    calleeText,
    argText: firstArg?.getText(),
  }
}

function buildIssue(node: NonNullExpression, handlerName: string, loadInfo: LoadCallInfo): Issue {
  const sourceFile = node.getSourceFile()
  const { line } = sourceFile.getLineAndColumnAtPos(node.getPos())
  const idHint = loadInfo.argText ? `(${loadInfo.argText})` : '(...)'
  return {
    checkId: CHECK_ID,
    severity: 'warning',
    filePath: sourceFile.getFilePath(),
    line,
    handlerName,
    message: `${loadInfo.calleeText}.load${idHint} can return null; add an explicit null check instead of using \`!\`.`,
  }
}
