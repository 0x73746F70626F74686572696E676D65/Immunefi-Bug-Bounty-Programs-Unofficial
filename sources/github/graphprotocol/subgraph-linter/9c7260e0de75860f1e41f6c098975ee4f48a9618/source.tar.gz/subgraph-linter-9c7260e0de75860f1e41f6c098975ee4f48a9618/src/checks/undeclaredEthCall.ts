import path from 'node:path'

import type { Check, Issue, HandlerCallDeclaration } from '../types.js'
import { getContractCallSummary } from '../analysis/contractCallSummary.js'

const CHECK_ID = 'undeclared-eth-call'

type NormalizedUsage = {
  abiName: string
  functionName: string
  bindingExpr: string
  argExprs: string[]
  fixAvailable: boolean
  node: ReturnType<typeof getContractCallSummary>['usages'][number]['node']
}

export const undeclaredEthCallCheck: Check = {
  id: CHECK_ID,
  description: 'Warns when handlers invoke eth_calls that are not declared in the manifest.',
  run(context) {
    const issues: Issue[] = []
    const summary = getContractCallSummary(context, context.handler)
    if (summary.usages.length === 0) {
      return issues
    }
    const handlerName = context.handler.getName() ?? '<anonymous>'
    const eventParamName = context.handler.getParameters()[0]?.getName() ?? 'event'
    const sourceFilePath = path.resolve(context.handler.getSourceFile().getFilePath())
    const handlerDeclarations =
      context.manifestInfo.declaredCalls.get(sourceFilePath)?.get(handlerName) ?? []
    const declaredStaticBindingSignatures = new Set(
      handlerDeclarations
        .map(normalizeDeclaration)
        .filter((decl) => Boolean(normalizeAddressLiteral(decl.bindingExpr)))
        .map((decl) => getSignatureKey(decl.abiName, decl.functionName, decl.argExprs)),
    )
    const declaredKeys = new Set(
      handlerDeclarations.map((decl) => getDeclarationKey(normalizeDeclaration(decl))),
    )
    const handlerKey = makeHandlerKey(sourceFilePath, handlerName)
    const manifestPath = context.manifestInfo.handlerManifestPaths.get(handlerKey) ?? null
    const seen = new Set<string>()
    for (const usage of summary.usages) {
      const normalizedUsage = normalizeUsage(usage, eventParamName)
      if (declaredKeys.has(getUsageKey(normalizedUsage))) {
        continue
      }
      if (
        !normalizedUsage.fixAvailable &&
        !isDeclarableBindingExpression(normalizedUsage.bindingExpr) &&
        declaredStaticBindingSignatures.has(
          getSignatureKey(normalizedUsage.abiName, normalizedUsage.functionName, normalizedUsage.argExprs),
        )
      ) {
        continue
      }
      const key = getUsageKey(normalizedUsage)
      if (seen.has(key)) {
        continue
      }
      seen.add(key)
      const location = usage.node.getSourceFile().getLineAndColumnAtPos(usage.node.getPos())
      issues.push({
        checkId: CHECK_ID,
        severity: 'warning',
        filePath: usage.node.getSourceFile().getFilePath(),
        line: location.line,
        handlerName,
        message: buildMessage(normalizedUsage),
        metadata: {
          type: 'undeclared-eth-call',
          handlerName,
          manifestPath,
          mappingFilePath: sourceFilePath,
          fixAvailable: normalizedUsage.fixAvailable,
          label: normalizedUsage.fixAvailable ? buildLabel(normalizedUsage) : undefined,
          declaration: normalizedUsage.fixAvailable ? buildDeclaration(normalizedUsage) : undefined,
          abiName: normalizedUsage.abiName,
          functionName: normalizedUsage.functionName,
          bindingExpr: normalizedUsage.bindingExpr,
          argExprs: normalizedUsage.argExprs,
        },
      })
    }
    return issues
  },
}

function normalizeDeclaration(decl: HandlerCallDeclaration): HandlerCallDeclaration {
  return {
    label: decl.label,
    abiName: decl.abiName,
    functionName: decl.functionName,
    bindingExpr: normalizeManifestExpression(decl.bindingExpr),
    argExprs: decl.argExprs.map(normalizeManifestExpression),
  }
}

function normalizeUsage(
  usage: ReturnType<typeof getContractCallSummary>['usages'][number],
  eventParamName: string,
): NormalizedUsage {
  const bindingExpr = normalizeTsExpression(usage.bindingExpr, eventParamName)
  const argExprs = usage.argExprs.map((arg) => normalizeTsExpression(arg, eventParamName))
  const bindingOk = isDeclarableBindingExpression(bindingExpr)
  const argsOk = argExprs.every(isDeclarableArgumentExpression)
  return {
    abiName: usage.abiName,
    functionName: usage.functionName,
    bindingExpr,
    argExprs,
    fixAvailable: bindingOk && argsOk,
    node: usage.node,
  }
}

function buildMessage(usage: NormalizedUsage): string {
  if (!usage.fixAvailable) {
    const approximation = buildApproximateYamlEntry(usage)
    return `Contract ${usage.abiName}.${usage.functionName} invoked with binding "${usage.bindingExpr}" is not declared in subgraph.yaml. Declared eth_call supports binding and args from event.address/event.params.<name> (and optionally a static 0x… address for binding). This call uses a value that can’t be represented in a calls declaration as-is, but a close approximation would be: "${approximation}".`
  }
  const manifestSnippet = buildDeclaration(usage)
  return `Contract ${usage.abiName}.${usage.functionName} invoked with binding "${usage.bindingExpr}" is not declared in subgraph.yaml. Add "${manifestSnippet}" to the handler's calls block.`
}

function getUsageKey(usage: Pick<NormalizedUsage, 'abiName' | 'functionName' | 'bindingExpr' | 'argExprs'>): string {
  return `${usage.abiName}::${usage.functionName}::${usage.bindingExpr}::${usage.argExprs.join('|')}`
}

function getDeclarationKey(decl: Pick<HandlerCallDeclaration, 'abiName' | 'functionName' | 'bindingExpr' | 'argExprs'>): string {
  return `${decl.abiName}::${decl.functionName}::${decl.bindingExpr}::${decl.argExprs.join('|')}`
}

function getSignatureKey(abiName: string, functionName: string, argExprs: string[]): string {
  return `${abiName}::${functionName}::${argExprs.join('|')}`
}

function buildDeclaration(usage: Pick<NormalizedUsage, 'abiName' | 'functionName' | 'bindingExpr' | 'argExprs'>): string {
  const argString = usage.argExprs.length > 0 ? usage.argExprs.join(', ') : ''
  return `${usage.abiName}[${usage.bindingExpr}].${usage.functionName}(${argString})`
}

function buildLabel(usage: Pick<NormalizedUsage, 'abiName' | 'functionName'>): string {
  return `${usage.abiName}.${usage.functionName}`
}

function makeHandlerKey(mappingFilePath: string, handlerName: string): string {
  return `${mappingFilePath}::${handlerName}`
}

function normalizeManifestExpression(value: string): string {
  const normalized = normalizeWhitespace(value)
  const staticAddr = extractStaticAddressLiteral(normalized)
  if (staticAddr) {
    return staticAddr
  }
  return normalized
}

function normalizeWhitespace(value: string): string {
  return value.replace(/\s+/g, ' ').trim()
}

function normalizeTsExpression(value: string, eventParamName: string): string {
  const normalized = normalizeWhitespace(value)
  const eventValue =
    extractEventExpression(normalized, eventParamName) ?? extractEventExpression(normalized, 'event')
  if (eventValue) {
    return eventValue
  }
  const staticAddr = extractStaticAddressLiteral(normalized)
  if (staticAddr) {
    return staticAddr
  }
  return normalized
}

function extractEventExpression(value: string, eventParamName: string | undefined): string | null {
  const param = eventParamName && /^[A-Za-z_][A-Za-z0-9_]*$/.test(eventParamName) ? eventParamName : null
  if (value === 'event.address' || (param && value === `${param}.address`)) {
    return 'event.address'
  }
  const matchCanonical = value.match(/^event\.params\.([A-Za-z_][A-Za-z0-9_]*)$/)
  if (matchCanonical) {
    return `event.params.${matchCanonical[1]}`
  }
  if (param) {
    const matchOther = value.match(new RegExp(`^${escapeRegExp(param)}\\.params\\.([A-Za-z_][A-Za-z0-9_]*)$`))
    if (matchOther) {
      return `event.params.${matchOther[1]}`
    }
  }
  return null
}

function extractStaticAddressLiteral(value: string): string | null {
  let current = value
  for (let i = 0; i < 6; i += 1) {
    const direct = normalizeAddressLiteral(stripStringLiteralQuotes(current))
    if (direct) {
      return direct
    }
    const call = parseCallExpressionText(current)
    if (!call) {
      return null
    }
    const callee = call.callee
    if (
      callee === 'Address.fromString' ||
      callee === 'Address.fromHexString' ||
      callee === 'Address.fromBytes' ||
      callee === 'Bytes.fromHexString' ||
      callee === 'ByteArray.fromHexString'
    ) {
      if (call.args.length === 0) {
        return null
      }
      current = normalizeWhitespace(call.args[0])
      continue
    }
    return null
  }
  return null
}

function stripStringLiteralQuotes(value: string): string {
  const match = value.match(/^(['"])(.*)\1$/)
  if (!match) {
    return value
  }
  return match[2]
}

function normalizeAddressLiteral(value: string): string | null {
  if (!/^0x[0-9a-fA-F]{40}$/.test(value)) {
    return null
  }
  return value.toLowerCase()
}

function parseCallExpressionText(
  value: string,
): { callee: string; args: string[] } | null {
  const open = value.indexOf('(')
  if (open <= 0 || !value.endsWith(')')) {
    return null
  }
  const callee = value.slice(0, open).trim()
  const argsText = value.slice(open + 1, -1)
  const args = splitTopLevelArgs(argsText)
  return { callee, args }
}

function splitTopLevelArgs(value: string): string[] {
  const args: string[] = []
  let depth = 0
  let start = 0
  for (let i = 0; i < value.length; i += 1) {
    const ch = value[i]
    if (ch === '(' || ch === '[' || ch === '{') {
      depth += 1
      continue
    }
    if (ch === ')' || ch === ']' || ch === '}') {
      if (depth > 0) depth -= 1
      continue
    }
    if (ch === ',' && depth === 0) {
      args.push(value.slice(start, i).trim())
      start = i + 1
    }
  }
  const tail = value.slice(start).trim()
  if (tail.length > 0) {
    args.push(tail)
  }
  return args
}

function isDeclarableBindingExpression(value: string): boolean {
  return Boolean(extractEventExpression(value, 'event') || normalizeAddressLiteral(value))
}

function isDeclarableArgumentExpression(value: string): boolean {
  return Boolean(extractEventExpression(value, 'event'))
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function buildApproximateYamlEntry(usage: Pick<NormalizedUsage, 'abiName' | 'functionName' | 'bindingExpr' | 'argExprs'>): string {
  const binding = isDeclarableBindingExpression(usage.bindingExpr) ? usage.bindingExpr : '<insert-address-here>'
  const args = usage.argExprs.map((arg) => (isDeclarableArgumentExpression(arg) ? arg : '<insert-event-param-here>'))
  const declaration = buildDeclaration({
    abiName: usage.abiName,
    functionName: usage.functionName,
    bindingExpr: binding,
    argExprs: args,
  })
  const label = buildLabel({ abiName: usage.abiName, functionName: usage.functionName })
  return `${label}: ${declaration}`
}
