import path from 'node:path'
import process from 'node:process'
import {
  CallExpression,
  Expression,
  FunctionDeclaration,
  Node,
  ParameterDeclaration,
  Project,
  PropertyAccessExpression,
  SyntaxKind,
  Type,
} from 'ts-morph'

import type { Check, HandlerCheckContext, Issue } from '../types.js'

const CHECK_ID = 'derived-field-guard'

type PendingHelper = {
  helper: HelperDescriptor
  fields: Set<string>
  lastSave?: {
    filePath: string
    line: number
    entityName: string
    fieldsAtSave: Set<string>
  }
}

type EntityState = {
  entityType: string | null
  pending: Map<string, PendingHelper>
  satisfied: Set<string>
}

type HelperDescriptor = {
  helperId: string
  functionDecl: FunctionDeclaration
  helperName: string
  parameterIndex: number
  entityType: string
}

type HelperMetadata = {
  fieldToHelpers: Map<string, HelperDescriptor[]>
  helperDescriptorsByDecl: Map<FunctionDeclaration, HelperDescriptor[]>
}

const helperMetadataCache = new WeakMap<Project, HelperMetadata>()

export const derivedFieldGuardCheck: Check = {
  id: CHECK_ID,
  description: 'Ensures derived metrics helpers run after mutating source fields before saving entities.',
  run(context: HandlerCheckContext) {
    const metadata = getHelperMetadata(context.project)
    if (!metadata.fieldToHelpers.size) {
      return []
    }
    return analyzeHandler(context.handler, metadata)
  },
}

function analyzeHandler(handler: import('ts-morph').FunctionDeclaration, metadata: HelperMetadata) {
  const issues: Issue[] = []
  const context = new Map<string, EntityState>()
  visitStatements(handler.getStatements(), context, metadata, issues, handler.getName() ?? '<anonymous>')
  emitPendingIssues(context, issues, handler.getName() ?? '<anonymous>')
  return issues
}

function visitStatements(
  statements: Node[],
  context: Map<string, EntityState>,
  metadata: HelperMetadata,
  issues: Issue[],
  handlerName: string,
) {
  for (const stmt of statements) {
    if (Node.isVariableStatement(stmt)) {
      handleVariableStatement(stmt, context)
      continue
    }
    if (Node.isExpressionStatement(stmt)) {
      handleExpressionStatement(stmt, context, metadata, issues, handlerName)
      continue
    }
    if (Node.isIfStatement(stmt)) {
      handleIfStatement(stmt, context, metadata, issues, handlerName)
      continue
    }
    if (Node.isBlock(stmt)) {
      visitStatements(stmt.getStatements(), context, metadata, issues, handlerName)
    }
  }
}

function handleVariableStatement(stmt: import('ts-morph').VariableStatement, context: Map<string, EntityState>) {
  for (const decl of stmt.getDeclarations()) {
    const nameNode = decl.getNameNode()
    if (!Node.isIdentifier(nameNode)) continue
    const initializer = decl.getInitializer()
    if (!initializer) {
      context.delete(nameNode.getText())
      continue
    }
    assignIdentifierFromExpression(nameNode.getText(), initializer, context)
  }
}

function handleExpressionStatement(
  stmt: import('ts-morph').ExpressionStatement,
  context: Map<string, EntityState>,
  metadata: HelperMetadata,
  issues: Issue[],
  handlerName: string,
) {
  const expr = unwrapExpression(stmt.getExpression())
  if (Node.isBinaryExpression(expr) && isAssignmentOperator(expr.getOperatorToken().getKind())) {
    handleAssignmentExpression(expr, context, metadata, issues, handlerName)
    return
  }
  if (Node.isCallExpression(expr)) {
    handleCallExpression(expr, context, metadata, issues, handlerName)
  }
}

function handleAssignmentExpression(
  expr: import('ts-morph').BinaryExpression,
  context: Map<string, EntityState>,
  metadata: HelperMetadata,
  issues: Issue[],
  handlerName: string,
) {
  const left = unwrapExpression(expr.getLeft())
  const right = unwrapExpression(expr.getRight())

  if (Node.isPropertyAccessExpression(left)) {
    handleFieldMutation(left, context, metadata)
  } else if (Node.isIdentifier(left)) {
    assignIdentifierFromExpression(left.getText(), right, context)
  }

  if (Node.isCallExpression(right)) {
    handleCallExpression(right, context, metadata, issues, handlerName)
  }
}

function handleFieldMutation(
  access: PropertyAccessExpression,
  context: Map<string, EntityState>,
  metadata: HelperMetadata,
) {
  const targetExpr = unwrapExpression(access.getExpression())
  if (!Node.isIdentifier(targetExpr)) {
    return
  }
  const state = getOrCreateEntityState(targetExpr, context)
  if (!state) {
    return
  }
  const fieldName = access.getName()
  const requirements = state.entityType
    ? metadata.fieldToHelpers.get(buildFieldKey(state.entityType, fieldName))
    : undefined
  if (!requirements) {
    return
  }
  for (const requirement of requirements) {
    if (state.satisfied.has(requirement.helperId)) {
      continue
    }
    let pending = state.pending.get(requirement.helperId)
    if (!pending) {
      pending = {
        helper: requirement,
        fields: new Set(),
      }
      state.pending.set(requirement.helperId, pending)
    }
    pending.fields.add(fieldName)
  }
}

function assignIdentifierFromExpression(
  targetName: string,
  expression: Expression,
  context: Map<string, EntityState>,
) {
  const rhs = unwrapExpression(expression)
  if (Node.isIdentifier(rhs)) {
    const existing = context.get(rhs.getText())
    if (existing) {
      context.set(targetName, existing)
      return
    }
    const inferredType = getEntityTypeFromExpression(rhs)
    if (inferredType) {
      const newState: EntityState = { entityType: inferredType, pending: new Map(), satisfied: new Set() }
      context.set(rhs.getText(), newState)
      context.set(targetName, newState)
      return
    }
    context.delete(targetName)
    return
  }

  const typeName = getEntityTypeFromExpression(rhs)
  if (!typeName) {
    context.delete(targetName)
    return
  }
  const newState: EntityState = { entityType: typeName, pending: new Map(), satisfied: new Set() }
  context.set(targetName, newState)
}

function handleCallExpression(
  callExpr: CallExpression,
  context: Map<string, EntityState>,
  metadata: HelperMetadata,
  issues: Issue[],
  handlerName: string,
) {
  const expression = callExpr.getExpression()
  if (expression.isKind(SyntaxKind.PropertyAccessExpression) && expression.getName() === 'save') {
    handleSaveCall(expression, callExpr, context)
    return
  }
  const helperDescriptors = resolveHelperDescriptors(callExpr, metadata)
  if (!helperDescriptors.length) {
    return
  }
  for (const descriptor of helperDescriptors) {
    const args = callExpr.getArguments()
    const arg = args[descriptor.parameterIndex]
    if (!arg) continue
    const identifier = getIdentifierFromExpression(arg)
    if (!identifier) continue
    const state = getOrCreateEntityState(identifier, context)
    if (!state || state.entityType !== descriptor.entityType) continue
    state.satisfied.add(descriptor.helperId)
    state.pending.delete(descriptor.helperId)
  }
}

function handleSaveCall(
  accessExpr: import('ts-morph').PropertyAccessExpression,
  callExpr: CallExpression,
  context: Map<string, EntityState>,
) {
  const identifier = getIdentifierFromExpression(accessExpr.getExpression() as Expression)
  if (!identifier) {
    return
  }
  const state = getOrCreateEntityState(identifier, context)
  if (!state) {
    return
  }
  const { line } = callExpr.getSourceFile().getLineAndColumnAtPos(callExpr.getPos())
  const filePath = callExpr.getSourceFile().getFilePath()
  for (const pending of state.pending.values()) {
    pending.lastSave = {
      filePath,
      line,
      entityName: identifier.getText(),
      fieldsAtSave: new Set(pending.fields),
    }
  }
}

function handleIfStatement(
  ifStmt: import('ts-morph').IfStatement,
  context: Map<string, EntityState>,
  metadata: HelperMetadata,
  issues: Issue[],
  handlerName: string,
) {
  const thenContext = cloneContext(context)
  visitStatements(toStatements(ifStmt.getThenStatement()), thenContext, metadata, issues, handlerName)

  const elseStmt = ifStmt.getElseStatement()
  if (elseStmt) {
    const elseContext = cloneContext(context)
    visitStatements(toStatements(elseStmt), elseContext, metadata, issues, handlerName)
    mergeContexts(context, [thenContext, elseContext])
  } else {
    mergeContexts(context, [thenContext])
  }
}

function toStatements(node: Node): Node[] {
  return Node.isBlock(node) ? node.getStatements() : [node]
}

function cloneContext(source: Map<string, EntityState>): Map<string, EntityState> {
  const cloned = new Map<string, EntityState>()
  for (const [name, state] of source.entries()) {
    cloned.set(name, cloneEntityState(state))
  }
  return cloned
}

function cloneEntityState(state: EntityState): EntityState {
  const clonedPending = new Map<string, PendingHelper>()
  for (const [key, pending] of state.pending.entries()) {
    clonedPending.set(key, {
      helper: pending.helper,
      fields: new Set(pending.fields),
      lastSave: pending.lastSave
        ? {
            ...pending.lastSave,
            fieldsAtSave: new Set(pending.lastSave.fieldsAtSave),
          }
        : undefined,
    })
  }
  return {
    entityType: state.entityType,
    pending: clonedPending,
    satisfied: new Set(state.satisfied),
  }
}

function mergeContexts(base: Map<string, EntityState>, branches: Array<Map<string, EntityState>>) {
  const merged = new Map<string, EntityState>()
  for (const branch of branches) {
    for (const [name, state] of branch.entries()) {
      const current = merged.get(name)
      if (!current) {
        merged.set(name, cloneEntityState(state))
        continue
      }
      if (current.entityType !== state.entityType) continue
      for (const satisfied of state.satisfied) {
        current.satisfied.add(satisfied)
      }
      for (const [helperId, pending] of state.pending.entries()) {
        let target = current.pending.get(helperId)
        if (!target) {
          target = { helper: pending.helper, fields: new Set() }
          current.pending.set(helperId, target)
        }
        for (const field of pending.fields) {
          target.fields.add(field)
        }
        if (pending.lastSave) {
          target.lastSave = {
            ...pending.lastSave,
            fieldsAtSave: new Set(pending.lastSave.fieldsAtSave),
          }
        }
      }
    }
  }
  base.clear()
  for (const [name, state] of merged.entries()) {
    base.set(name, state)
  }
}

function getOrCreateEntityState(identifier: import('ts-morph').Identifier, context: Map<string, EntityState>) {
  const name = identifier.getText()
  const existing = context.get(name)
  if (existing) {
    return existing
  }
  const typeName = getEntityTypeFromExpression(identifier)
  if (!typeName) {
    return null
  }
  const newState: EntityState = { entityType: typeName, pending: new Map(), satisfied: new Set() }
  context.set(name, newState)
  return newState
}

function getEntityTypeFromExpression(expression: Expression): string | null {
  const type = expression.getType()
  return extractTypeName(type)
}

function extractTypeName(type: Type<import('ts-morph').ts.Type>): string | null {
  if (type.isUnion()) {
    for (const subType of type.getUnionTypes()) {
      const name = extractTypeName(subType)
      if (name) {
        return name
      }
    }
    return null
  }
  const symbol = type.getSymbol()
  if (symbol) {
    return symbol.getName()
  }
  const text = type.getText()
  if (/^[A-Za-z_]\w*$/.test(text)) {
    return text
  }
  return null
}

function getHelperMetadata(project: Project): HelperMetadata {
  const cached = helperMetadataCache.get(project)
  if (cached) {
    return cached
  }
  const fieldToHelpers = new Map<string, HelperDescriptor[]>()
  const helperDescriptorsByDecl = new Map<FunctionDeclaration, HelperDescriptor[]>()

  for (const source of project.getSourceFiles()) {
    for (const func of source.getFunctions()) {
      const descriptors: HelperDescriptor[] = []
      const params = func.getParameters()
      params.forEach((param, index) => {
        const entityType = getParameterEntityType(param)
        if (!entityType) return
        const fields = collectReadFields(func, param)
        if (!fields.size) return
        const helper: HelperDescriptor = {
          helperId: buildHelperId(func, index),
          functionDecl: func,
          helperName: func.getName() ?? '<anonymous>',
          parameterIndex: index,
          entityType,
        }
        descriptors.push(helper)
        for (const field of fields) {
          const key = buildFieldKey(entityType, field)
          let list = fieldToHelpers.get(key)
          if (!list) {
            list = []
            fieldToHelpers.set(key, list)
          }
          list.push(helper)
        }
      })
      if (descriptors.length) {
        helperDescriptorsByDecl.set(func, descriptors)
      }
    }
  }

  const metadata = { fieldToHelpers, helperDescriptorsByDecl }
  helperMetadataCache.set(project, metadata)
  return metadata
}

function buildFieldKey(entityType: string, field: string): string {
  return `${entityType}.${field}`
}

function buildHelperId(func: FunctionDeclaration, parameterIndex: number): string {
  const filePath = path.relative(process.cwd(), func.getSourceFile().getFilePath())
  return `${filePath}:${func.getName() ?? '<anonymous>'}:${parameterIndex}`
}

function getParameterEntityType(param: ParameterDeclaration): string | null {
  const typeNode = param.getTypeNode()
  if (typeNode && Node.isTypeReference(typeNode)) {
    const typeName = typeNode.getTypeName().getText()
    if (typeName) {
      return typeName
    }
  }
  return extractTypeName(param.getType())
}

function emitPendingIssues(
  context: Map<string, EntityState>,
  issues: Issue[],
  handlerName: string,
): void {
  for (const state of context.values()) {
    for (const pending of state.pending.values()) {
      if (!pending.lastSave) continue
      issues.push({
        checkId: CHECK_ID,
        severity: 'warning',
        filePath: pending.lastSave.filePath,
        line: pending.lastSave.line,
        handlerName,
        message: `${pending.lastSave.entityName}.save() persists mutations to ${Array.from(
          pending.lastSave.fieldsAtSave,
        ).join(', ')} without running ${pending.helper.helperName}(). Call the helper before saving.`,
      })
    }
  }
}

function collectReadFields(func: FunctionDeclaration, param: ParameterDeclaration): Set<string> {
  const result = new Set<string>()
  const paramName = param.getName()
  func.forEachDescendant((node) => {
    if (!Node.isPropertyAccessExpression(node)) {
      return
    }
    if (isWriteAccess(node)) {
      return
    }
    const target = unwrapExpression(node.getExpression())
    if (!Node.isIdentifier(target)) {
      return
    }
    if (target.getText() !== paramName) {
      return
    }
    result.add(node.getName())
  })
  return result
}

function isWriteAccess(node: PropertyAccessExpression): boolean {
  const parent = node.getParent()
  if (Node.isBinaryExpression(parent)) {
    if (parent.getLeft() === node && isAssignmentOperator(parent.getOperatorToken().getKind())) {
      return true
    }
  }
  if (
    (Node.isPrefixUnaryExpression(parent) || Node.isPostfixUnaryExpression(parent)) &&
    (parent.getOperatorToken() === SyntaxKind.PlusPlusToken ||
      parent.getOperatorToken() === SyntaxKind.MinusMinusToken)
  ) {
    return true
  }
  return false
}

function isAssignmentOperator(kind: SyntaxKind): boolean {
  return (
    kind === SyntaxKind.EqualsToken ||
    kind === SyntaxKind.PlusEqualsToken ||
    kind === SyntaxKind.MinusEqualsToken ||
    kind === SyntaxKind.AsteriskEqualsToken ||
    kind === SyntaxKind.SlashEqualsToken ||
    kind === SyntaxKind.PercentEqualsToken
  )
}

function unwrapExpression(expression: Expression): Expression {
  let current = expression
  while (
    Node.isAsExpression(current) ||
    Node.isTypeAssertion(current) ||
    Node.isParenthesizedExpression(current) ||
    Node.isNonNullExpression(current)
  ) {
    current = current.getExpression()
  }
  return current
}

function getIdentifierFromExpression(node: Node): import('ts-morph').Identifier | null {
  if (!Node.isExpression(node)) {
    return null
  }
  const unwrapped = unwrapExpression(node)
  return Node.isIdentifier(unwrapped) ? unwrapped : null
}

function resolveHelperDescriptors(
  callExpr: CallExpression,
  metadata: HelperMetadata,
): HelperDescriptor[] {
  const calleeDecl = resolveFunctionDeclaration(callExpr)
  if (!calleeDecl) {
    return []
  }
  return metadata.helperDescriptorsByDecl.get(calleeDecl) ?? []
}

function resolveFunctionDeclaration(callExpr: CallExpression): FunctionDeclaration | null {
  let symbol = callExpr.getExpression().getSymbol()
  if (!symbol) return null
  if (symbol.isAlias()) {
    const aliased = symbol.getAliasedSymbol()
    if (aliased) {
      symbol = aliased
    }
  }
  for (const decl of symbol.getDeclarations() ?? []) {
    if (Node.isFunctionDeclaration(decl)) {
      return decl
    }
  }
  return null
}
