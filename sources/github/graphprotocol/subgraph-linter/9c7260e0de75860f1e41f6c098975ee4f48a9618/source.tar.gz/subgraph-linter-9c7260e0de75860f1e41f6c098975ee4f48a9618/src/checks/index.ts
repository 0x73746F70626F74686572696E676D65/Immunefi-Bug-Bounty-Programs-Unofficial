import type { Check } from '../types.js'
import { entityOverwriteCheck } from './entityOverwrite.js'
import { unexpectedNullCheck } from './unexpectedNull.js'
import { uncheckedLoadCheck } from './uncheckedLoad.js'
import { uncheckedNonNullCheck } from './uncheckedNonNull.js'
import { divisionGuardCheck } from './divisionGuard.js'
import { derivedFieldGuardCheck } from './derivedFieldGuard.js'
import { helperReturnContractCheck } from './helperReturnContract.js'
import { undeclaredEthCallCheck } from './undeclaredEthCall.js'

export const checks: Check[] = [
  entityOverwriteCheck,
  unexpectedNullCheck,
  uncheckedLoadCheck,
  uncheckedNonNullCheck,
  divisionGuardCheck,
  derivedFieldGuardCheck,
  helperReturnContractCheck,
  undeclaredEthCallCheck,
]
