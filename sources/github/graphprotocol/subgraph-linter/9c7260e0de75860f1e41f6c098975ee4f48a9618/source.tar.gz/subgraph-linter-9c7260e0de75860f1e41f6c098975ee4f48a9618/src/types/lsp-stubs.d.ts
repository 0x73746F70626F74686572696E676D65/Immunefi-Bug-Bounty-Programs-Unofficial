// Minimal stubs for LSP dependencies to keep the TypeScript build happy when the packages are not installed.
declare module 'vscode-languageserver/node.js' {
  export type InitializeParams = any
  export type InitializeResult = any
  export type Diagnostic = any
  export enum DiagnosticSeverity {
    Error = 1,
    Warning = 2,
  }
  export type ServerOptions = any
  export type TransportKind = any
  export enum TextDocumentSyncKind {
    None = 0,
    Full = 1,
    Incremental = 2,
  }
  export const ProposedFeatures: any
  export function createConnection(...args: any[]): any
  export class TextDocuments<T = any> {
    constructor(...args: any[])
    onDidSave: (...args: any[]) => void
    listen: (conn: any) => void
  }
}

declare module 'vscode-languageserver-textdocument' {
  export class TextDocument {}
}

declare module 'vscode-languageclient/node' {
  export type LanguageClientOptions = any
  export type ServerOptions = any
  export const TransportKind: any
  export class LanguageClient {
    constructor(name: string, description: string, serverOptions: any, clientOptions: any)
    start(): any
    stop(): any
    sendNotification(method: string, params?: any): void
    onReady(): Promise<void>
  }
}
