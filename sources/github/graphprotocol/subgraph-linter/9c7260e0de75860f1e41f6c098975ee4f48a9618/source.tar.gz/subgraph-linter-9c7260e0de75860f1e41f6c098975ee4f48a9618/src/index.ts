import { readFileSync } from 'node:fs'
import path from 'node:path'
import process from 'node:process'
import { Project } from 'ts-morph'

import { checks } from './checks/index.js'
import { runChecks, RunChecksError } from './runner.js'
import { loadSchemaInfo } from './schema.js'
import type { ManifestInfo, Issue, SchemaInfo } from './types.js'
import {
  AnalyzerConfig,
  applySeverityOverrides,
  loadConfig,
  loadManifestInfo,
} from './analyzerSupport.js'
import { applyCommentSuppressions } from './suppression.js'

type CliOptions = {
  tsconfigPath?: string
  configPath?: string
  manifestPaths: string[]
}

const sourceLineCache = new Map<string, string[]>()
const RESET = '\x1b[0m'
const ERROR_COLOR = '\x1b[31m'
const WARNING_COLOR = '\x1b[33m'

const cliOptions = parseCliArguments(process.argv.slice(2))
const { tsconfigPath, manifestPaths, configPath } = cliOptions
const tsConfigFilePath = path.resolve(tsconfigPath ?? 'tsconfig.json')
const analyzerConfig = loadConfig(configPath)

const manifestInfo = loadManifestInfo(manifestPaths)
const schemaInfo = loadSchemaInfo(manifestInfo.schemaPaths)
const project = new Project({
  tsConfigFilePath,
})

let rawIssues: Issue[]
try {
  rawIssues = runChecks({ project, manifestInfo, schema: schemaInfo }, checks)
} catch (error) {
  if (error instanceof RunChecksError) {
    console.error(error.message)
    process.exit(1)
  }
  throw error
}

const issues = applyCommentSuppressions(
  applySeverityOverrides(rawIssues, analyzerConfig.severityOverrides ?? {}),
  analyzerConfig.suppression,
)

printResults(issues)

function parseCliArguments(args: string[]): CliOptions {
  let tsconfigPath: string | undefined
  let configPath: string | undefined
  const manifestPaths: string[] = []

  for (let i = 0; i < args.length; i += 1) {
    const arg = args[i]
    if (arg === '--manifest') {
      const manifestPath = args[i + 1]
      if (!manifestPath || manifestPath.startsWith('--')) {
        console.error('--manifest flag requires a file path argument.')
        printUsageAndExit()
      }
      manifestPaths.push(manifestPath)
      i += 1
      continue
    }

    if (arg === '--tsconfig') {
      const providedTsconfig = args[i + 1]
      if (!providedTsconfig || providedTsconfig.startsWith('--')) {
        console.error('--tsconfig flag requires a file path argument.')
        printUsageAndExit()
      }
      tsconfigPath = providedTsconfig
      i += 1
      continue
    }

    if (arg === '--config') {
      const providedConfig = args[i + 1]
      if (!providedConfig || providedConfig.startsWith('--')) {
        console.error('--config flag requires a file path argument.')
        printUsageAndExit()
      }
      configPath = providedConfig
      i += 1
      continue
    }

    console.error(`Unknown option: ${arg}`)
    printUsageAndExit()
  }

  if (manifestPaths.length === 0) {
    console.error('At least one --manifest <path> must be provided.')
    printUsageAndExit()
  }

  return { tsconfigPath, configPath, manifestPaths }
}

function printUsageAndExit(): never {
  console.error(
    'Usage: node dist/index.js --manifest <path> [--manifest <path> ...] [--tsconfig <path>] [--config <path>]',
  )
  process.exit(1)
}

function printResults(issues: Issue[]): never {
  if (issues.length === 0) {
    console.log('No potential issues detected.')
    process.exit(0)
  }

  const errors = issues.filter((issue) => issue.severity === 'error')
  const warnings = issues.filter((issue) => issue.severity === 'warning')

  if (errors.length > 0) {
    console.log('Errors:')
    for (const issue of errors) {
      printIssue(issue)
    }
  }

  if (warnings.length > 0) {
    if (errors.length > 0) {
      console.log('')
    }
    console.log('Warnings:')
    for (const issue of warnings) {
      printIssue(issue)
    }
  }

  console.log(
    `Summary: ${errors.length} error${errors.length === 1 ? '' : 's'}, ${warnings.length} warning${
      warnings.length === 1 ? '' : 's'
    }`,
  )

  process.exit(errors.length > 0 ? 1 : 0)
}

function printIssue(issue: Issue): void {
  const color = issue.severity === 'error' ? ERROR_COLOR : WARNING_COLOR
  const label = issue.severity
  console.log(`${color}${label}${RESET}[${issue.checkId}]: ${issue.handlerName}`)
  const relativePath = path.relative(process.cwd(), issue.filePath)
  console.log(`  --> ${relativePath}:${issue.line}`)
  const lineText = getSourceLine(issue.filePath, issue.line)
  const gutterWidth = Math.max(issue.line.toString().length, 2)
  console.log('   |')
  if (lineText !== null) {
    console.log(`${issue.line.toString().padStart(gutterWidth)} | ${lineText}`)
  } else {
    console.log(`${issue.line.toString().padStart(gutterWidth)} |`)
  }
  console.log('   |')
  console.log(`   = ${issue.message}`)
  console.log('')
}

function getSourceLine(filePath: string, line: number): string | null {
  if (!sourceLineCache.has(filePath)) {
    try {
      const contents = readFileSync(filePath, 'utf8')
      sourceLineCache.set(filePath, contents.split(/\r?\n/))
    } catch {
      sourceLineCache.set(filePath, [])
    }
  }
  const lines = sourceLineCache.get(filePath)!
  if (line - 1 < 0 || line - 1 >= lines.length) {
    return null
  }
  return lines[line - 1]
}
