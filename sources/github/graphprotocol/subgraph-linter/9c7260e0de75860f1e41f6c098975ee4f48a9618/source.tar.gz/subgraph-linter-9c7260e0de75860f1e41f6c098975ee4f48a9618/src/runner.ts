import path from 'node:path'
import type { Project } from 'ts-morph'

import type { AnalyzerContext, Check, Issue } from './types.js'

export class RunChecksError extends Error {}

export function runChecks(context: AnalyzerContext, checks: Check[]): Issue[] {
  const handlerFiles = getManifestSourceFiles(context.project, context.manifestInfo.mappingFilePaths).filter(
    (file) => !file.isDeclarationFile(),
  )

  const issues: Issue[] = []
  for (const file of handlerFiles) {
    for (const func of file.getFunctions()) {
      if (!func.isExported()) continue
      const name = func.getName()
      if (!name || !context.manifestInfo.handlerNames.has(name)) continue

      for (const check of checks) {
        issues.push(...check.run({ ...context, handler: func }))
      }
    }
  }

  return issues
}

function getManifestSourceFiles(project: Project, mappingFilePaths: Set<string>) {
  const normalizedTargets = new Set(
    Array.from(mappingFilePaths).map((filePath) => path.normalize(filePath)),
  )
  const matchedFiles = project
    .getSourceFiles()
    .filter((file) => normalizedTargets.has(path.normalize(file.getFilePath())))
  const matchedPaths = new Set(matchedFiles.map((file) => path.normalize(file.getFilePath())))
  const missing = Array.from(normalizedTargets).filter((target) => !matchedPaths.has(target))

  if (missing.length > 0) {
    const lines = [
      'The following mapping files were not found in the provided TypeScript project:',
      ...missing.map((missingFile) => ` - ${missingFile}`),
      'Ensure your tsconfig includes every mapping referenced by the manifests.',
    ]
    throw new RunChecksError(lines.join('\n'))
  }

  if (matchedFiles.length === 0) {
    throw new RunChecksError('None of the manifest mapping files were loaded from the TypeScript project.')
  }

  return matchedFiles
}
