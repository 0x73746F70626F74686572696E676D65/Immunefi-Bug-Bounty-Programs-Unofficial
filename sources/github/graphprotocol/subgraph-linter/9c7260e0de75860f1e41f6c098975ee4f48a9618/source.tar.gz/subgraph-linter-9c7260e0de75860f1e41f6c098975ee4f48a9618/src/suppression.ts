import { readFileSync, statSync } from 'node:fs'

import type { Issue } from './types.js'

export type SuppressionConfig = {
  allowWarnings?: boolean
  allowErrors?: boolean
}

type AllowMap = Map<number /* 1-based line */, Set<string>>

const allowMapCache = new Map<string, { mtimeMs: number; map: AllowMap }>()

export function applyCommentSuppressions(
  issues: Issue[],
  suppression: SuppressionConfig | undefined,
): Issue[] {
  const allowWarnings = suppression?.allowWarnings ?? true
  const allowErrors = suppression?.allowErrors ?? true
  if (!allowWarnings && !allowErrors) {
    return issues
  }
  if (issues.length === 0) {
    return issues
  }

  const grouped = new Map<string, Issue[]>()
  for (const issue of issues) {
    const list = grouped.get(issue.filePath) ?? []
    list.push(issue)
    grouped.set(issue.filePath, list)
  }

  const result: Issue[] = []
  for (const [filePath, fileIssues] of grouped.entries()) {
    const allowMap = getAllowMap(filePath)
    for (const issue of fileIssues) {
      if (issue.severity === 'warning' && !allowWarnings) {
        result.push(issue)
        continue
      }
      if (issue.severity === 'error' && !allowErrors) {
        result.push(issue)
        continue
      }
      const allows = allowMap.get(issue.line) ?? allowMap.get(issue.line + 1)
      if (!allows) {
        result.push(issue)
        continue
      }
      if (allows.has('all') || allows.has(issue.checkId)) {
        continue
      }
      result.push(issue)
    }
  }

  return result
}

function getAllowMap(filePath: string): AllowMap {
  let mtimeMs = 0
  try {
    mtimeMs = statSync(filePath).mtimeMs
  } catch {
    return new Map()
  }
  const cached = allowMapCache.get(filePath)
  if (cached && cached.mtimeMs === mtimeMs) {
    return cached.map
  }
  const map = parseAllowDirectives(filePath)
  allowMapCache.set(filePath, { mtimeMs, map })
  return map
}

function parseAllowDirectives(filePath: string): AllowMap {
  let raw = ''
  try {
    raw = readFileSync(filePath, 'utf8')
  } catch {
    return new Map()
  }
  const lines = raw.split(/\r?\n/)
  const map: AllowMap = new Map()

  const directive = /^\s*\/\/\s*\[\s*allow\s*\(\s*([^)]+?)\s*\)\s*]\s*$/
  for (let i = 0; i < lines.length; i += 1) {
    const match = lines[i].match(directive)
    if (!match) {
      continue
    }
    const values = match[1]
      .split(',')
      .map((part) => part.trim())
      .filter((part) => part.length > 0)
      .map((part) => part.toLowerCase())
    if (values.length === 0) {
      continue
    }

    const directiveLine = i + 1
    const targetLine = i + 2
    const candidateLines = [directiveLine, targetLine].filter(
      (line) => line > 0 && line <= lines.length,
    )
    for (const line of candidateLines) {
      const set = map.get(line) ?? new Set<string>()
      for (const value of values) {
        set.add(value)
      }
      map.set(line, set)
    }
  }

  return map
}
