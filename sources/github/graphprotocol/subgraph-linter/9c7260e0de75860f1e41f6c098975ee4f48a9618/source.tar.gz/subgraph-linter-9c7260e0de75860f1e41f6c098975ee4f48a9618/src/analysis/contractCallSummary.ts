import {
  CallExpression,
  Expression,
  FunctionDeclaration,
  Identifier,
  Node,
  SyntaxKind,
} from 'ts-morph'

import type { HandlerCheckContext } from '../types.js'

export type ContractCallUsage = {
  abiName: string
  functionName: string
  bindingExpr: string
  argExprs: string[]
  node: CallExpression
}

type ContractCallSummary = {
  usages: ContractCallUsage[]
}

type ContractBinding = {
  className: string
  bindingExpr: string
}

type ValueAlias = {
  text: string
  targetKey?: string
}

const summaries = new Map<FunctionDeclaration, ContractCallSummary>()
const summaryInProgress = new Set<FunctionDeclaration>()

export function getContractCallSummary(
  context: HandlerCheckContext,
  func: FunctionDeclaration,
): ContractCallSummary {
  if (summaries.has(func)) {
    return summaries.get(func)!
  }
  if (summaryInProgress.has(func)) {
    return { usages: [] }
  }
  summaryInProgress.add(func)
  const summary = analyzeFunction(context, func)
  summaries.set(func, summary)
  summaryInProgress.delete(func)
  return summary
}

function analyzeFunction(context: HandlerCheckContext, func: FunctionDeclaration): ContractCallSummary {
  const bindings = new Map<string, ContractBinding>()
  const valueAliases = new Map<string, ValueAlias>()
  const usages: ContractCallUsage[] = []

  func.forEachDescendant((node) => {
    if (Node.isVariableDeclaration(node)) {
      const initializer = node.getInitializer()
      const nameKey = symbolKey(node.getNameNode())
      if (initializer && Node.isExpression(initializer)) {
        const alias = buildValueAlias(initializer, valueAliases)
        if (alias) {
          valueAliases.set(nameKey, alias)
        } else {
          valueAliases.delete(nameKey)
        }
      } else {
        valueAliases.delete(nameKey)
      }
      if (initializer && Node.isCallExpression(initializer)) {
        const bindInfo = getBindInfo(initializer, valueAliases)
        if (bindInfo) {
          bindings.set(nameKey, bindInfo)
        }
      }
      return
    }
    if (Node.isBinaryExpression(node) && node.getOperatorToken().getKind() === SyntaxKind.EqualsToken) {
      const left = node.getLeft()
      const right = node.getRight()
      if (!Node.isIdentifier(left)) {
        return
      }
      const leftKey = symbolKey(left)
      if (Node.isExpression(right)) {
        const alias = buildValueAlias(right, valueAliases)
        if (alias) {
          valueAliases.set(leftKey, alias)
        } else {
          valueAliases.delete(leftKey)
        }
      }
      if (!Node.isCallExpression(right)) {
        bindings.delete(leftKey)
        return
      }
      const bindInfo = getBindInfo(right, valueAliases)
      if (bindInfo) {
        bindings.set(leftKey, bindInfo)
      } else {
        bindings.delete(leftKey)
      }
      return
    }
    if (Node.isCallExpression(node)) {
      const usage = getUsageFromContractCall(node, bindings, valueAliases)
      if (usage) {
        usages.push(usage)
        return
      }
      const calleeDecl = resolveFunction(node)
      if (calleeDecl) {
        const calleeSummary = getContractCallSummary(context, calleeDecl)
        const substituted = substituteUsagesForCall(node, calleeDecl, calleeSummary.usages, valueAliases)
        usages.push(...substituted)
      }
    }
  })

  return { usages }
}

function getBindInfo(callExpr: CallExpression, valueAliases: Map<string, ValueAlias>): ContractBinding | null {
  const expression = callExpr.getExpression()
  if (!Node.isPropertyAccessExpression(expression)) return null
  if (expression.getName() !== 'bind') return null
  const contractExpr = expression.getExpression()
  const className = contractExpr.getText()
  if (!className) return null
  const args = callExpr.getArguments()
  if (args.length === 0) return null
  const bindingArg = args[0]
  if (!Node.isExpression(bindingArg)) return null
  const bindingExpr = normalizeExpressionText(bindingArg, valueAliases)
  return { className, bindingExpr }
}

function getUsageFromContractCall(
  callExpr: CallExpression,
  bindings: Map<string, ContractBinding>,
  valueAliases: Map<string, ValueAlias>,
): ContractCallUsage | null {
  const expression = callExpr.getExpression()
  if (!Node.isPropertyAccessExpression(expression)) {
    return null
  }
  const methodName = expression.getName()
  const baseExpression = expression.getExpression()
  const binding = getBindingForExpression(baseExpression, bindings, valueAliases)
  if (!binding) {
    return null
  }
  if (methodName === 'bind') {
    return null
  }
  const normalizedArgs = callExpr
    .getArguments()
    .map((arg) => normalizeArgumentNode(arg, valueAliases))
    .filter((value): value is string => Boolean(value))
  const cleanMethodName = methodName.startsWith('try_') ? methodName.slice(4) : methodName
  return {
    abiName: binding.className,
    functionName: cleanMethodName,
    bindingExpr: binding.bindingExpr,
    argExprs: normalizedArgs,
    node: callExpr,
  }
}

function getBindingForExpression(
  expr: Expression,
  bindings: Map<string, ContractBinding>,
  valueAliases: Map<string, ValueAlias>,
): ContractBinding | null {
  const unwrapped = unwrapExpression(expr)
  if (Node.isIdentifier(unwrapped)) {
    const key = symbolKey(unwrapped)
    return bindings.get(key) ?? null
  }
  if (Node.isCallExpression(unwrapped)) {
    const bindInfo = getBindInfo(unwrapped, valueAliases)
    if (bindInfo) {
      return bindInfo
    }
    const returnBindInfo = getReturnBindInfo(unwrapped, valueAliases)
    if (returnBindInfo) {
      return returnBindInfo
    }
  }
  return null
}

function getReturnBindInfo(callExpr: CallExpression, valueAliases: Map<string, ValueAlias>): ContractBinding | null {
  const callee = resolveFunction(callExpr)
  if (!callee) {
    return null
  }
  const returnStatements = callee.getDescendantsOfKind(SyntaxKind.ReturnStatement)
  if (returnStatements.length === 0) {
    return null
  }

  const substitutions = new Map<string, string>()
  const params = callee.getParameters()
  const args = callExpr.getArguments()
  for (let i = 0; i < params.length && i < args.length; i += 1) {
    const argNode = args[i]
    if (!Node.isExpression(argNode)) continue
    substitutions.set(params[i].getName(), normalizeExpressionText(argNode, valueAliases))
  }

  let candidate: ContractBinding | null = null
  for (const ret of returnStatements) {
    const expr = ret.getExpression()
    if (!expr || !Node.isExpression(expr)) {
      continue
    }
    const unwrapped = unwrapExpression(expr)
    if (!Node.isCallExpression(unwrapped)) {
      return null
    }
    const bindInfo = getBindInfo(unwrapped, new Map())
    if (!bindInfo) {
      return null
    }
    const resolved: ContractBinding = substitutions.size
      ? {
          className: bindInfo.className,
          bindingExpr: substituteExpression(bindInfo.bindingExpr, substitutions),
        }
      : bindInfo
    if (!candidate) {
      candidate = resolved
      continue
    }
    if (candidate.className !== resolved.className || candidate.bindingExpr !== resolved.bindingExpr) {
      return null
    }
  }
  return candidate
}

function resolveFunction(callExpr: CallExpression): FunctionDeclaration | null {
  let symbol = callExpr.getExpression().getSymbol()
  if (!symbol) {
    return null
  }
  if (symbol.isAlias()) {
    const aliased = symbol.getAliasedSymbol()
    if (aliased) {
      symbol = aliased
    }
  }
  for (const decl of symbol.getDeclarations() ?? []) {
    if (Node.isFunctionDeclaration(decl)) {
      return decl
    }
  }
  return null
}

function substituteUsagesForCall(
  callExpr: CallExpression,
  callee: FunctionDeclaration,
  usages: ContractCallUsage[],
  valueAliases: Map<string, ValueAlias>,
): ContractCallUsage[] {
  if (usages.length === 0) {
    return []
  }
  const substitutions = new Map<string, string>()
  const params = callee.getParameters()
  const args = callExpr.getArguments()
  for (let i = 0; i < params.length && i < args.length; i += 1) {
    const argNode = args[i]
    if (!Node.isExpression(argNode)) {
      continue
    }
    const paramName = params[i].getName()
    substitutions.set(paramName, normalizeExpressionText(argNode, valueAliases))
  }
  if (substitutions.size === 0) {
    return usages.slice()
  }
  return usages.map((usage) => ({
    abiName: usage.abiName,
    functionName: usage.functionName,
    bindingExpr: substituteExpression(usage.bindingExpr, substitutions),
    argExprs: usage.argExprs.map((expr) => substituteExpression(expr, substitutions)),
    node: callExpr,
  }))
}

function substituteExpression(expr: string, substitutions: Map<string, string>): string {
  let result = expr
  const entries = Array.from(substitutions.entries()).sort(([a], [b]) => b.length - a.length)
  for (const [param, value] of entries) {
    const pattern = new RegExp(`\\b${escapeRegExp(param)}\\b`, 'g')
    result = result.replace(pattern, value)
  }
  return result
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function normalizeExpressionText(expression: Expression, valueAliases: Map<string, ValueAlias>): string {
  const unwrapped = unwrapExpression(expression)
  const rendered = renderExpression(unwrapped, valueAliases, 0)
  return rendered.replace(/\s+/g, ' ').trim()
}

function normalizeArgumentNode(arg: Node, valueAliases: Map<string, ValueAlias>): string | null {
  if (Node.isExpression(arg)) {
    return normalizeExpressionText(arg, valueAliases)
  }
  const text = arg.getText().replace(/\s+/g, ' ').trim()
  return text.length > 0 ? text : null
}

function unwrapExpression(expression: Expression): Expression {
  let current: Expression = expression
  while (true) {
    if (Node.isParenthesizedExpression(current) || Node.isNonNullExpression(current)) {
      current = current.getExpression()
      continue
    }
    if (Node.isAsExpression(current)) {
      current = current.getExpression()
      continue
    }
    if (Node.isTypeAssertion(current)) {
      current = current.getExpression()
      continue
    }
    break
  }
  if (Node.isCallExpression(current)) {
    const expr = current.getExpression()
    if (Node.isIdentifier(expr) && expr.getText() === 'changetype' && current.getArguments().length > 0) {
      const callArg = current.getArguments()[0]
      if (Node.isExpression(callArg)) {
        return unwrapExpression(callArg)
      }
    }
  }
  return current
}

function symbolKey(node: Node): string {
  const symbol = node.getSymbol()
  if (!symbol) {
    return node.getText()
  }
  return symbol.getFullyQualifiedName()
}

function buildValueAlias(expression: Expression, valueAliases: Map<string, ValueAlias>): ValueAlias | null {
  const unwrapped = unwrapExpression(expression)
  if (Node.isIdentifier(unwrapped)) {
    const targetKey = symbolKey(unwrapped)
    const resolved = resolveValueAliasByKey(targetKey, valueAliases)
    return { text: resolved ?? unwrapped.getText(), targetKey }
  }
  return { text: normalizeExpressionText(unwrapped, valueAliases) }
}

function resolveValueAlias(identifier: Identifier, valueAliases: Map<string, ValueAlias>): string | null {
  return resolveValueAliasByKey(symbolKey(identifier), valueAliases)
}

function resolveValueAliasByKey(key: string, valueAliases: Map<string, ValueAlias>): string | null {
  const seen = new Set<string>()
  let currentKey: string | undefined = key
  for (let i = 0; i < 12 && currentKey; i += 1) {
    if (seen.has(currentKey)) {
      return null
    }
    seen.add(currentKey)
    const entry = valueAliases.get(currentKey)
    if (!entry) {
      return null
    }
    if (!entry.targetKey) {
      return entry.text
    }
    const next = valueAliases.get(entry.targetKey)
    if (!next) {
      return entry.text
    }
    currentKey = entry.targetKey
  }
  return null
}

function renderExpression(expression: Expression, valueAliases: Map<string, ValueAlias>, depth: number): string {
  if (depth > 12) {
    return expression.getText()
  }
  if (Node.isIdentifier(expression)) {
    return resolveValueAlias(expression, valueAliases) ?? expression.getText()
  }
  if (Node.isStringLiteral(expression) || Node.isNoSubstitutionTemplateLiteral(expression)) {
    return expression.getText()
  }
  if (Node.isPropertyAccessExpression(expression)) {
    const base = renderExpression(expression.getExpression(), valueAliases, depth + 1)
    return `${base}.${expression.getName()}`
  }
  if (Node.isCallExpression(expression)) {
    const callee = renderExpression(expression.getExpression(), valueAliases, depth + 1)
    const args = expression.getArguments().map((arg) => {
      if (Node.isExpression(arg)) {
        return renderExpression(arg, valueAliases, depth + 1)
      }
      return arg.getText()
    })
    return `${callee}(${args.join(', ')})`
  }
  if (Node.isElementAccessExpression(expression)) {
    const base = renderExpression(expression.getExpression(), valueAliases, depth + 1)
    const arg = expression.getArgumentExpression()
    const index = arg ? renderExpression(arg, valueAliases, depth + 1) : ''
    return `${base}[${index}]`
  }
  return expression.getText()
}
