import { existsSync, readFileSync } from 'node:fs'
import path from 'node:path'
import { parse, type DocumentNode, type FieldDefinitionNode, type TypeNode } from 'graphql'

import type { SchemaEntityInfo, SchemaInfo } from './types.js'

export function loadSchemaInfo(schemaPaths: Set<string>): SchemaInfo {
  const schemaInfo: SchemaInfo = new Map()

  for (const schemaPath of schemaPaths) {
    const resolvedPath = path.resolve(schemaPath)
    if (!existsSync(resolvedPath)) {
      console.error(`Schema file not found: ${schemaPath}`)
      process.exit(1)
    }

    let contents: string
    try {
      contents = readFileSync(resolvedPath, 'utf8')
    } catch (error) {
      console.error(`Failed to read schema ${schemaPath}: ${(error as Error).message}`)
      process.exit(1)
    }

    let document: DocumentNode
    try {
      document = parse(contents)
    } catch (error) {
      console.error(`Failed to parse schema ${schemaPath}: ${(error as Error).message}`)
      process.exit(1)
    }

    for (const definition of document.definitions) {
      if (definition.kind !== 'ObjectTypeDefinition') continue
      const typeName = definition.name.value
      if (!typeName || typeName.length === 0) continue

      const entityInfo = getOrCreateEntityInfo(schemaInfo, typeName)
      for (const field of definition.fields ?? []) {
        registerField(field, entityInfo)
      }
    }
  }

  return schemaInfo
}

function getOrCreateEntityInfo(schemaInfo: SchemaInfo, entityType: string): SchemaEntityInfo {
  if (!schemaInfo.has(entityType)) {
    schemaInfo.set(entityType, { requiredFields: new Set(), derivedFields: new Set() })
  }
  return schemaInfo.get(entityType)!
}

function registerField(field: FieldDefinitionNode, entityInfo: SchemaEntityInfo): void {
  const fieldName = field.name.value
  if (!fieldName || fieldName === 'id') return

  const isDerived = (field.directives ?? []).some((dir) => dir.name.value === 'derivedFrom')
  if (isDerived) {
    entityInfo.derivedFields.add(fieldName)
    return
  }

  if (isNonNullType(field.type)) {
    entityInfo.requiredFields.add(fieldName)
  }
}

function isNonNullType(type: TypeNode): boolean {
  return type.kind === 'NonNullType'
}
