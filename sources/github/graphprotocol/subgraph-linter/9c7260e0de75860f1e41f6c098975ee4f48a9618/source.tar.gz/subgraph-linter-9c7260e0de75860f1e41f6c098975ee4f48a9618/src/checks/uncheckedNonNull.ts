import { Node, SyntaxKind } from 'ts-morph'

import type { Check, HandlerCheckContext, Issue } from '../types.js'

const CHECK_ID = 'unchecked-nonnull'

export const uncheckedNonNullCheck: Check = {
  id: CHECK_ID,
  description: 'Flags non-null assertions (`!`) on nullable expressions without guards.',
  run(context) {
    const issues: Issue[] = []
    for (const assertion of context.handler.getDescendantsOfKind(SyntaxKind.NonNullExpression)) {
      if (!isNullableExpression(assertion)) continue
      issues.push(buildIssue(assertion, context.handler.getName() ?? '<anonymous>'))
    }
    return issues
  },
}

function isNullableExpression(node: import('ts-morph').NonNullExpression): boolean {
  const expression = node.getExpression()
  const type = expression.getType()
  if (type.isNullable()) {
    return true
  }

  if (expression.isKind(SyntaxKind.PropertyAccessExpression) || expression.isKind(SyntaxKind.Identifier)) {
    const symbol = expression.getSymbol()
    const declaration = symbol?.getValueDeclaration()
    if (declaration && declarationAllowsNull(declaration)) {
      return true
    }
  }

  return false
}

function declarationAllowsNull(declaration: Node): boolean {
  if (Node.isPropertyDeclaration(declaration) || Node.isVariableDeclaration(declaration) || Node.isParameterDeclaration(declaration)) {
    const typeNode = declaration.getTypeNode()
    if (typeNode && typeNodeAllowsNull(typeNode)) {
      return true
    }
    const initializer = declaration.getInitializer()
    if (initializer && initializer.getKind() === SyntaxKind.NullKeyword) {
      return true
    }
  }
  return false
}

function typeNodeAllowsNull(typeNode: import('ts-morph').TypeNode): boolean {
  if (Node.isUnionTypeNode(typeNode)) {
    return typeNode.getTypeNodes().some((child) => typeNodeAllowsNull(child))
  }
  return typeNode.getKind() === SyntaxKind.NullKeyword || typeNode.getKind() === SyntaxKind.UndefinedKeyword
}

function buildIssue(node: import('ts-morph').NonNullExpression, handlerName: string): Issue {
  const sourceFile = node.getSourceFile()
  const { line } = sourceFile.getLineAndColumnAtPos(node.getPos())
  return {
    checkId: CHECK_ID,
    severity: 'error',
    filePath: sourceFile.getFilePath(),
    line,
    handlerName,
    message: `Avoid using '!' on nullable expression (${node.getExpression().getText()}); guard the value or restructure the code.`,
  }
}
