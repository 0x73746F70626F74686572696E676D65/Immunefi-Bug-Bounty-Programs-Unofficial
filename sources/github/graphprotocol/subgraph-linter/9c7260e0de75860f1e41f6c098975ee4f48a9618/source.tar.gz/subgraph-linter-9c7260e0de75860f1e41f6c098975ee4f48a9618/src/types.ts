import type { FunctionDeclaration, Project } from 'ts-morph'

export type HandlerCallDeclaration = {
  label: string
  abiName: string
  functionName: string
  bindingExpr: string
  argExprs: string[]
}

export type ManifestInfo = {
  handlerNames: Set<string>
  mappingFilePaths: Set<string>
  schemaPaths: Set<string>
  declaredCalls: Map<string, Map<string, HandlerCallDeclaration[]>>
  handlerManifestPaths: Map<string, string>
}

export type SchemaEntityInfo = {
  requiredFields: Set<string>
  derivedFields: Set<string>
}

export type SchemaInfo = Map<string, SchemaEntityInfo>

export type Issue = {
  checkId: string
  filePath: string
  line: number
  handlerName: string
  message: string
  severity: 'error' | 'warning'
  metadata?: Record<string, unknown>
}

export type AnalyzerContext = {
  project: Project
  manifestInfo: ManifestInfo
  schema: SchemaInfo
}

export type HandlerCheckContext = AnalyzerContext & {
  handler: FunctionDeclaration
}

export interface Check {
  id: string
  description: string
  run(context: HandlerCheckContext): Issue[]
}
