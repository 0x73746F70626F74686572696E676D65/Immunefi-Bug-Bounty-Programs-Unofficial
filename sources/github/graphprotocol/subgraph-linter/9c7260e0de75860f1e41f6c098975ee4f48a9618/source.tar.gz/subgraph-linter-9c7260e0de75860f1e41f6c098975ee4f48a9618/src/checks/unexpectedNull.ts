import path from 'node:path'
import process from 'node:process'
import {
  CallExpression,
  Expression,
  FunctionDeclaration,
  Node,
  SyntaxKind,
} from 'ts-morph'

import type { Check, HandlerCheckContext, Issue, SchemaEntityInfo } from '../types.js'

const CHECK_ID = 'unexpected-null'

type AliasMap = Map<string, string>

type PendingEntity = {
  entityType: string
  schemaInfo?: SchemaEntityInfo
  pendingFields?: Set<string>
  source?: string
}

type EntityReturnSummary = {
  entityType: string
  missingFields?: Set<string>
  source?: string
}

type FunctionSummary = {
  returnedEntities: EntityReturnSummary[]
  issues: Issue[]
}

const summaries = new Map<FunctionDeclaration, FunctionSummary>()
const summaryInProgress = new Set<FunctionDeclaration>()
const reportedSummaryIssues = new Set<FunctionDeclaration>()

export const unexpectedNullCheck: Check = {
  id: CHECK_ID,
  description: 'Ensures new entities initialize required fields before save and forbids derived field assignments.',
  run(context) {
    return analyzeHandler(context)
  },
}

function analyzeHandler(context: HandlerCheckContext): Issue[] {
  const issues: Issue[] = []
  const entities = new Map<string, PendingEntity>()
  const aliases: AliasMap = new Map()
  walkStatements(context, context.handler.getStatements(), entities, aliases, context.handler.getName() ?? '<anonymous>', issues)
  return issues
}

function walkStatements(
  context: HandlerCheckContext,
  statements: Node[],
  entities: Map<string, PendingEntity>,
  aliases: AliasMap,
  handlerName: string,
  issues: Issue[],
) {
  for (const stmt of statements) {
    switch (stmt.getKind()) {
      case SyntaxKind.VariableStatement:
        handleVariableStatement(context, stmt, entities, aliases, handlerName, issues)
        break
      case SyntaxKind.ExpressionStatement:
        handleExpressionStatement(context, stmt, entities, aliases, handlerName, issues)
        break
      case SyntaxKind.IfStatement:
        handleIfStatement(context, stmt.asKindOrThrow(SyntaxKind.IfStatement), entities, aliases, handlerName, issues)
        break
      case SyntaxKind.Block:
        walkStatements(
          context,
          stmt.asKindOrThrow(SyntaxKind.Block).getStatements(),
          entities,
          aliases,
          handlerName,
          issues,
        )
        break
      default:
        break
    }
  }
}

function handleVariableStatement(
  context: HandlerCheckContext,
  stmt: Node,
  entities: Map<string, PendingEntity>,
  aliases: AliasMap,
  handlerName: string,
  issues: Issue[],
) {
  const varStmt = stmt.asKindOrThrow(SyntaxKind.VariableStatement)
  for (const decl of varStmt.getDeclarations()) {
    const initializer = decl.getInitializer()
    if (!initializer) continue
    const initExpr = unwrapExpression(initializer)
    const varName = decl.getName()
    if (Node.isNewExpression(initExpr)) {
      registerNewEntity(context, varName, initExpr, entities, aliases)
      continue
    }

    if (Node.isCallExpression(initExpr)) {
      if (assignEntityFromCallExpression(context, varName, initExpr, entities, aliases, handlerName, issues)) {
        continue
      }
      applyHelperEffects(context, initExpr, entities, aliases, handlerName, issues)
      aliases.set(varName, expressionToText(initExpr, aliases))
      entities.delete(varName)
      continue
    }

    aliases.set(varName, expressionToText(initExpr, aliases))
    entities.delete(varName)
  }
}

function handleExpressionStatement(
  context: HandlerCheckContext,
  stmt: Node,
  entities: Map<string, PendingEntity>,
  aliases: AliasMap,
  handlerName: string,
  issues: Issue[],
) {
  const exprStmt = stmt.asKindOrThrow(SyntaxKind.ExpressionStatement)
  const expr = unwrapExpression(exprStmt.getExpression())
  if (Node.isBinaryExpression(expr) && expr.getOperatorToken().getText() === '=') {
    if (handleAssignmentExpression(context, expr, entities, aliases, handlerName, issues)) {
      return
    }
  }
  if (Node.isCallExpression(expr)) {
    if (handleSaveCall(context, expr, entities, aliases, handlerName, issues)) {
      return
    }
    applyHelperEffects(context, expr, entities, aliases, handlerName, issues)
  }
}

function handleAssignmentExpression(
  context: HandlerCheckContext,
  expr: import('ts-morph').BinaryExpression,
  entities: Map<string, PendingEntity>,
  aliases: AliasMap,
  handlerName: string,
  issues: Issue[],
): boolean {
  const left = unwrapExpression(expr.getLeft())
  const right = unwrapExpression(expr.getRight())

  if (Node.isPropertyAccessExpression(left)) {
    handleFieldAssignment(context, left, entities, aliases, handlerName, issues)
    return true
  }

  if (!Node.isIdentifier(left)) {
    return false
  }

  const target = left.getText()

  if (Node.isNewExpression(right)) {
    registerNewEntity(context, target, right, entities, aliases)
    return true
  }

  if (Node.isCallExpression(right)) {
    if (assignEntityFromCallExpression(context, target, right, entities, aliases, handlerName, issues)) {
      return true
    }
    applyHelperEffects(context, right, entities, aliases, handlerName, issues)
    aliases.set(target, expressionToText(right, aliases))
    entities.delete(target)
    return true
  }

  aliases.set(target, expressionToText(right, aliases))
  entities.delete(target)
  return true
}

function handleFieldAssignment(
  context: HandlerCheckContext,
  property: import('ts-morph').PropertyAccessExpression,
  entities: Map<string, PendingEntity>,
  aliases: AliasMap,
  handlerName: string,
  issues: Issue[],
) {
  const baseName = normalizeExpression(property.getExpression().getText())
  const resolved = resolveAlias(baseName, aliases) ?? baseName
  let state = entities.get(resolved)
  if (!state) {
    const inferredType = inferEntityType(property.getExpression(), context)
    if (!inferredType) return
    const schemaInfo = context.schema.get(inferredType)
    state = { entityType: inferredType, schemaInfo }
    entities.set(resolved, state)
  }
  const field = property.getName()
  if (state.schemaInfo?.derivedFields.has(field)) {
    const location = property.getSourceFile().getLineAndColumnAtPos(property.getPos())
    issues.push({
      checkId: CHECK_ID,
      severity: 'error',
      filePath: property.getSourceFile().getFilePath(),
      line: location.line,
      handlerName,
      message: `Field "${field}" on ${state.entityType} is @derivedFrom and must not be assigned.`,
    })
    return
  }
  state.pendingFields?.delete(field)
}

function handleSaveCall(
  context: HandlerCheckContext,
  callExpr: CallExpression,
  entities: Map<string, PendingEntity>,
  aliases: AliasMap,
  handlerName: string,
  issues: Issue[],
): boolean {
  const expression = callExpr.getExpression()
  if (!Node.isPropertyAccessExpression(expression)) return false
  if (expression.getName() !== 'save') return false

  const entityName = normalizeExpression(expression.getExpression().getText())
  const resolved = resolveAlias(entityName, aliases) ?? entityName
  const state = entities.get(resolved)
  if (!state || !state.schemaInfo) return true

  const pending = state.pendingFields
  if (!pending || pending.size === 0) {
    state.pendingFields = undefined
    return true
  }

  const missing = Array.from(pending).sort()
  const location = callExpr.getSourceFile().getLineAndColumnAtPos(callExpr.getPos())
  issues.push({
    checkId: CHECK_ID,
    severity: 'error',
    filePath: callExpr.getSourceFile().getFilePath(),
    line: location.line,
    handlerName,
    message: `${entityName}.save() is called before initializing required fields on ${state.entityType}: ${missing.join(', ')}.`,
  })

  state.pendingFields = undefined
  return true
}

function handleIfStatement(
  context: HandlerCheckContext,
  ifStmt: import('ts-morph').IfStatement,
  entities: Map<string, PendingEntity>,
  aliases: AliasMap,
  handlerName: string,
  issues: Issue[],
) {
  const thenEntities = cloneEntities(entities)
  const thenAliases = cloneAliases(aliases)
  walkStatements(context, toStatements(ifStmt.getThenStatement()), thenEntities, thenAliases, handlerName, issues)

  const elseStmt = ifStmt.getElseStatement()
  if (elseStmt) {
    const elseEntities = cloneEntities(entities)
    const elseAliases = cloneAliases(aliases)
    walkStatements(context, toStatements(elseStmt), elseEntities, elseAliases, handlerName, issues)
    mergeEntities(entities, [thenEntities, elseEntities])
  } else {
    mergeEntities(entities, [thenEntities])
  }
}

function registerNewEntity(
  context: HandlerCheckContext,
  target: string,
  newExpr: import('ts-morph').NewExpression,
  entities: Map<string, PendingEntity>,
  aliases: AliasMap,
) {
  const expr = newExpr.getExpression()
  if (!Node.isIdentifier(expr)) return
  const entityType = expr.getText()
  const schemaInfo = context.schema.get(entityType)
  const pendingFields = schemaInfo ? new Set(schemaInfo.requiredFields) : undefined
  entities.set(target, {
    entityType,
    schemaInfo,
    pendingFields,
    source: formatLocation(newExpr),
  })
  aliases.delete(target)
}

function assignEntityFromCallExpression(
  context: HandlerCheckContext,
  target: string,
  callExpr: CallExpression,
  entities: Map<string, PendingEntity>,
  aliases: AliasMap,
  handlerName: string,
  issues: Issue[],
): boolean {
  const calleeDecl = resolveFunction(callExpr)
  if (!calleeDecl) return false
  const summary = getUnexpectedNullFunctionSummary(context, calleeDecl)
  reportSummaryIssues(calleeDecl, summary, issues)
  const returnInfo = combineReturnSummaries(summary.returnedEntities)
  if (!returnInfo) {
    const inferredType = inferEntityType(callExpr, context)
    if (inferredType) {
      const schemaInfo = context.schema.get(inferredType)
      entities.set(target, { entityType: inferredType, schemaInfo })
      aliases.delete(target)
      return true
    }
    entities.delete(target)
    aliases.delete(target)
    return false
  }
  const schemaInfo = context.schema.get(returnInfo.entityType)
  if (!schemaInfo) {
    entities.set(target, { entityType: returnInfo.entityType })
    aliases.delete(target)
    return true
  }
  const pendingFields = returnInfo.missingFields ? new Set(returnInfo.missingFields) : undefined
  entities.set(target, {
    entityType: returnInfo.entityType,
    schemaInfo,
    pendingFields,
    source: returnInfo.source,
  })
  aliases.delete(target)
  return true
}

function applyHelperEffects(
  context: HandlerCheckContext,
  callExpr: CallExpression,
  entities: Map<string, PendingEntity>,
  aliases: AliasMap,
  handlerName: string,
  issues: Issue[],
) {
  const calleeDecl = resolveFunction(callExpr)
  if (!calleeDecl) return
  const summary = getUnexpectedNullFunctionSummary(context, calleeDecl)
  reportSummaryIssues(calleeDecl, summary, issues)
}

function combineReturnSummaries(summaries: EntityReturnSummary[]): EntityReturnSummary | null {
  if (summaries.length === 0) return null
  const entityType = summaries[0].entityType
  for (const summary of summaries) {
    if (summary.entityType !== entityType) {
      return null
    }
  }
  let missingFields: Set<string> | undefined = new Set<string>()
  for (const summary of summaries) {
    if (!summary.missingFields) {
      missingFields = undefined
      break
    }
    for (const field of summary.missingFields) {
      missingFields?.add(field)
    }
  }
  return { entityType, missingFields, source: summaries[0].source }
}

function cloneEntities(source: Map<string, PendingEntity>): Map<string, PendingEntity> {
  const cloned = new Map<string, PendingEntity>()
  for (const [key, value] of source.entries()) {
    cloned.set(key, {
      entityType: value.entityType,
      schemaInfo: value.schemaInfo,
      pendingFields: value.pendingFields ? new Set(value.pendingFields) : undefined,
      source: value.source,
    })
  }
  return cloned
}

function mergeEntities(
  base: Map<string, PendingEntity>,
  branches: Array<Map<string, PendingEntity>>,
) {
  for (const [name, baseState] of base.entries()) {
    for (const branch of branches) {
      const branchState = branch.get(name)
      if (!branchState) {
        base.delete(name)
        break
      }
      if (branchState.entityType !== baseState.entityType) {
        base.delete(name)
        break
      }
      if (!baseState.pendingFields) {
        continue
      }
      if (!branchState.pendingFields) {
        baseState.pendingFields = undefined
        continue
      }
      const intersection = new Set<string>()
      for (const field of baseState.pendingFields) {
        if (branchState.pendingFields.has(field)) {
          intersection.add(field)
        }
      }
      baseState.pendingFields = intersection
    }
  }
}

function cloneAliases(source: AliasMap): AliasMap {
  const cloned = new Map<string, string>()
  for (const [key, value] of source.entries()) {
    cloned.set(key, value)
  }
  return cloned
}

function toStatements(node: Node): Node[] {
  return Node.isBlock(node) ? node.getStatements() : [node]
}

function resolveAlias(name: string, aliases: AliasMap, seen: Set<string> = new Set()): string | null {
  if (seen.has(name)) return null
  const value = aliases.get(name)
  if (!value) return null
  if (/^[A-Za-z_$][\w$]*$/.test(value) && value !== name) {
    seen.add(name)
    return resolveAlias(value, aliases, seen) ?? value
  }
  return value
}

function expressionToText(expression: Expression, aliases?: AliasMap): string {
  const unwrapped = unwrapExpression(expression)
  if (Node.isIdentifier(unwrapped)) {
    const resolved = aliases ? resolveAlias(unwrapped.getText(), aliases) : undefined
    if (resolved) {
      return resolved
    }
  }
  return normalizeExpression(unwrapped.getText())
}

function unwrapExpression(expression: Expression): Expression {
  let current: Expression = expression
  while (
    Node.isNonNullExpression(current) ||
    Node.isParenthesizedExpression(current) ||
    Node.isAsExpression(current) ||
    Node.isTypeAssertion(current)
  ) {
    current = current.getExpression()
  }
  return current
}

function normalizeExpression(text: string): string {
  return text.replace(/\s+/g, ' ').trim()
}

function formatLocation(node: Node): string {
  const filePath = path.relative(process.cwd(), node.getSourceFile().getFilePath())
  const { line } = node.getSourceFile().getLineAndColumnAtPos(node.getPos())
  return `${filePath}:${line}`
}

function inferEntityType(expression: Expression, context: HandlerCheckContext): string | undefined {
  const type = expression.getType()
  if (!type) return undefined
  const candidates = type.isUnion() ? type.getUnionTypes() : [type]
  for (const candidate of candidates) {
    const symbol = candidate.getSymbol() ?? candidate.getAliasSymbol()
    const name = symbol?.getName()
    if (name && context.schema.has(name)) {
      return name
    }
  }
  return undefined
}

function resolveFunction(callExpr: CallExpression): FunctionDeclaration | null {
  let symbol = callExpr.getExpression().getSymbol()
  if (!symbol) return null
  if (symbol.isAlias()) {
    const aliased = symbol.getAliasedSymbol()
    if (aliased) {
      symbol = aliased
    }
  }
  for (const decl of symbol.getDeclarations() ?? []) {
    if (Node.isFunctionDeclaration(decl)) {
      return decl
    }
  }
  return null
}

export function getUnexpectedNullFunctionSummary(
  context: HandlerCheckContext,
  func: FunctionDeclaration,
): FunctionSummary {
  if (summaries.has(func)) {
    return summaries.get(func)!
  }
  if (summaryInProgress.has(func)) {
    return { returnedEntities: [], issues: [] }
  }
  summaryInProgress.add(func)

  const issues: Issue[] = []
  const returnedEntities: EntityReturnSummary[] = []
  const entities = new Map<string, PendingEntity>()
  const aliases: AliasMap = new Map()

  walkStatementsForSummary(context, func.getStatements(), entities, aliases, func.getName() ?? '<anonymous>', issues, returnedEntities)

  const summary = { returnedEntities, issues }
  summaries.set(func, summary)
  summaryInProgress.delete(func)
  return summary
}

function walkStatementsForSummary(
  context: HandlerCheckContext,
  statements: Node[],
  entities: Map<string, PendingEntity>,
  aliases: AliasMap,
  handlerName: string,
  issues: Issue[],
  returnedEntities: EntityReturnSummary[],
) {
  for (const stmt of statements) {
    switch (stmt.getKind()) {
      case SyntaxKind.VariableStatement:
        handleVariableStatement(context, stmt, entities, aliases, handlerName, issues)
        break
      case SyntaxKind.ExpressionStatement:
        handleExpressionStatement(context, stmt, entities, aliases, handlerName, issues)
        break
      case SyntaxKind.ReturnStatement:
        recordReturn(context, stmt.asKindOrThrow(SyntaxKind.ReturnStatement), entities, aliases, returnedEntities)
        break
      case SyntaxKind.IfStatement:
        const thenEntities = cloneEntities(entities)
        const thenAliases = cloneAliases(aliases)
        walkStatementsForSummary(
          context,
          toStatements(stmt.asKindOrThrow(SyntaxKind.IfStatement).getThenStatement()),
          thenEntities,
          thenAliases,
          handlerName,
          issues,
          returnedEntities,
        )
        const elseStmt = stmt.asKindOrThrow(SyntaxKind.IfStatement).getElseStatement()
        if (elseStmt) {
          const elseEntities = cloneEntities(entities)
          const elseAliases = cloneAliases(aliases)
          walkStatementsForSummary(
            context,
            toStatements(elseStmt),
            elseEntities,
            elseAliases,
            handlerName,
            issues,
            returnedEntities,
          )
        }
        break
      case SyntaxKind.Block:
        walkStatementsForSummary(
          context,
          stmt.asKindOrThrow(SyntaxKind.Block).getStatements(),
          entities,
          aliases,
          handlerName,
          issues,
          returnedEntities,
        )
        break
      default:
        break
    }
  }
}

function recordReturn(
  context: HandlerCheckContext,
  returnStmt: import('ts-morph').ReturnStatement,
  entities: Map<string, PendingEntity>,
  aliases: AliasMap,
  returnedEntities: EntityReturnSummary[],
) {
  const expr = returnStmt.getExpression()
  if (!expr) return
  const unwrapped = unwrapExpression(expr)
  if (Node.isNewExpression(unwrapped)) {
    const ctor = unwrapped.getExpression()
    if (!Node.isIdentifier(ctor)) return
    const entityType = ctor.getText()
    const schemaInfo = context.schema.get(entityType)
    const missingFields = schemaInfo ? new Set(schemaInfo.requiredFields) : undefined
    returnedEntities.push({
      entityType,
      missingFields,
      source: formatLocation(returnStmt),
    })
    return
  }
  if (!Node.isIdentifier(unwrapped)) return
  const resolved = resolveAlias(unwrapped.getText(), aliases) ?? unwrapped.getText()
  const state = entities.get(resolved)
  if (!state) return
  returnedEntities.push({
    entityType: state.entityType,
    missingFields: state.pendingFields ? new Set(state.pendingFields) : undefined,
    source: formatLocation(returnStmt),
  })
}

function reportSummaryIssues(
  func: FunctionDeclaration,
  summary: FunctionSummary,
  issues: Issue[],
) {
  if (reportedSummaryIssues.has(func)) {
    return
  }
  issues.push(...summary.issues)
  reportedSummaryIssues.add(func)
}
