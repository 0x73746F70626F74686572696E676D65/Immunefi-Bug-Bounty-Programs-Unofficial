import path from 'node:path'
import process from 'node:process'
import {
  CallExpression,
  Expression,
  FunctionDeclaration,
  Identifier,
  Node,
  ReturnStatement,
  SyntaxKind,
} from 'ts-morph'

import type { Check, Issue } from '../types.js'

const CHECK_ID = 'entity-overwrite'

type EntityState = {
  entityType: string
  idExpr: string
  dirty: boolean
  lastMutation?: string
}

type Operation = {
  entityType: string
  idExpr: string
  source?: string
}

type EntityInfo = {
  entityType: string
  idExpr: string
}

type FunctionSummary = {
  operations: Operation[]
  returnEntities: EntityInfo[]
  parameterMutations: string[]
}

type AliasMap = Map<string, string>

type WalkOptions = {
  collectIssues: boolean
  issueSink?: Issue[]
  onSave?: (state: EntityState, callExpr: CallExpression) => void
}

const summaries = new Map<FunctionDeclaration, FunctionSummary>()
const summaryInProgress = new Set<FunctionDeclaration>()

export const entityOverwriteCheck: Check = {
  id: CHECK_ID,
  description: 'Detects load → helper mutates/save → handler saves stale copy patterns.',
  run({ handler }) {
    return analyzeHandler(handler)
  },
}

function analyzeHandler(func: FunctionDeclaration): Issue[] {
  const issues: Issue[] = []
  const context = new Map<string, EntityState>()
  const aliases: AliasMap = new Map()
  walkStatements(func.getStatements(), context, aliases, func.getName() ?? '<anonymous>', {
    collectIssues: true,
    issueSink: issues,
  })
  return issues
}

function walkStatements(
  statements: Node[],
  context: Map<string, EntityState>,
  aliases: AliasMap,
  handlerName: string,
  options: WalkOptions,
) {
  for (const stmt of statements) {
    switch (stmt.getKind()) {
      case SyntaxKind.VariableStatement:
        handleVariableStatement(stmt, context, aliases)
        break
      case SyntaxKind.ExpressionStatement:
        handleExpressionStatement(stmt, context, aliases, handlerName, options)
        break
      case SyntaxKind.IfStatement:
        handleIfStatement(
          stmt.asKindOrThrow(SyntaxKind.IfStatement),
          context,
          aliases,
          handlerName,
          options,
        )
        break
      case SyntaxKind.Block:
        walkStatements(
          stmt.asKindOrThrow(SyntaxKind.Block).getStatements(),
          context,
          aliases,
          handlerName,
          options,
        )
        break
      default:
        break
    }
  }
}

function handleIfStatement(
  ifStmt: import('ts-morph').IfStatement,
  context: Map<string, EntityState>,
  aliases: AliasMap,
  handlerName: string,
  options: WalkOptions,
) {
  const thenContext = cloneContext(context)
  const thenAliases = cloneAliases(aliases)
  walkStatements(toStatements(ifStmt.getThenStatement()), thenContext, thenAliases, handlerName, options)

  const elseStmt = ifStmt.getElseStatement()
  if (elseStmt) {
    const elseContext = cloneContext(context)
    const elseAliases = cloneAliases(aliases)
    walkStatements(toStatements(elseStmt), elseContext, elseAliases, handlerName, options)
    mergeContexts(context, [thenContext, elseContext])
  } else {
    mergeContexts(context, [thenContext])
  }
}

function toStatements(node: Node): Node[] {
  return Node.isBlock(node) ? node.getStatements() : [node]
}

function cloneContext(source: Map<string, EntityState>): Map<string, EntityState> {
  const cloned = new Map<string, EntityState>()
  for (const [key, value] of source.entries()) {
    cloned.set(key, { ...value })
  }
  return cloned
}

function mergeContexts(
  base: Map<string, EntityState>,
  branches: Array<Map<string, EntityState>>,
): void {
  for (const [key, baseState] of base.entries()) {
    for (const branch of branches) {
      const branchState = branch.get(key)
      if (!branchState) continue
      if (
        branchState.entityType === baseState.entityType &&
        branchState.idExpr === baseState.idExpr
      ) {
        baseState.dirty = baseState.dirty || branchState.dirty
      }
    }
  }

  for (const branch of branches) {
    for (const [key, branchState] of branch.entries()) {
      if (!base.has(key)) {
        base.set(key, { ...branchState })
      }
    }
  }
}

function cloneAliases(source: AliasMap): AliasMap {
  const cloned = new Map<string, string>()
  for (const [key, value] of source.entries()) {
    cloned.set(key, value)
  }
  return cloned
}

function resolveAlias(name: string, aliases?: AliasMap, seen: Set<string> = new Set()): string | null {
  if (!aliases) return null
  if (seen.has(name)) return null
  const value = aliases.get(name)
  if (!value) return null
  if (/^[A-Za-z_$][\w$]*$/.test(value) && value !== name) {
    seen.add(name)
    return resolveAlias(value, aliases, seen) ?? value
  }
  return value
}

function expressionToText(expression: Expression, aliases?: AliasMap): string {
  const unwrapped = unwrapExpression(expression)
  if (Node.isIdentifier(unwrapped)) {
    const resolved = resolveAlias(unwrapped.getText(), aliases)
    if (resolved) {
      return resolved
    }
  }
  return normalizeExpression(unwrapped.getText())
}

function handleVariableStatement(stmt: Node, context: Map<string, EntityState>, aliases: AliasMap) {
  const varStmt = stmt.asKindOrThrow(SyntaxKind.VariableStatement)
  for (const decl of varStmt.getDeclarations()) {
    const nameNode = decl.getNameNode()
    const initializer = decl.getInitializer()
    if (!initializer) continue
    const initExpr = unwrapExpression(initializer)
    const varName = nameNode.getText()
    if (!Node.isCallExpression(initExpr)) {
      if (Node.isNewExpression(initExpr)) {
        const entityCtor = initExpr.getExpression().getText()
        const idArg = initExpr.getArguments()[0]
        if (entityCtor && idArg && Node.isExpression(idArg)) {
          context.set(varName, {
            entityType: entityCtor,
            idExpr: expressionToText(idArg, aliases),
            dirty: false,
          })
          aliases.delete(varName)
        }
        continue
      }
      aliases.set(varName, expressionToText(initExpr, aliases))
      continue
    }

    if (assignEntityFromCallExpression(varName, initExpr, context, aliases)) {
      continue
    }

    aliases.set(varName, expressionToText(initExpr, aliases))
  }
}

function handleExpressionStatement(
  stmt: Node,
  context: Map<string, EntityState>,
  aliases: AliasMap,
  handlerName: string,
  options: WalkOptions,
) {
  const exprStmt = stmt.asKindOrThrow(SyntaxKind.ExpressionStatement)
  const expr = unwrapExpression(exprStmt.getExpression())
  if (Node.isBinaryExpression(expr) && expr.getOperatorToken().getText() === '=') {
    if (handleAssignmentExpression(expr, context, aliases)) {
      return
    }
  }
  if (Node.isCallExpression(expr)) {
    if (handleSaveCall(expr, context, handlerName, options)) {
      return
    }
    handleGeneralCall(expr, context)
  }
}

function handleAssignmentExpression(
  expr: import('ts-morph').BinaryExpression,
  context: Map<string, EntityState>,
  aliases: AliasMap,
): boolean {
  const left = expr.getLeft()
  if (!Node.isIdentifier(left)) {
    return false
  }
  const target = left.getText()
  const right = unwrapExpression(expr.getRight())

  if (Node.isCallExpression(right)) {
    if (assignEntityFromCallExpression(target, right, context, aliases)) {
      return true
    }
    aliases.set(target, expressionToText(right, aliases))
    context.delete(target)
    return true
  }

  if (Node.isNewExpression(right)) {
    const entityCtor = right.getExpression().getText()
    const idArg = right.getArguments()[0]
    if (entityCtor && idArg && Node.isExpression(idArg)) {
      context.set(target, {
        entityType: entityCtor,
        idExpr: expressionToText(idArg, aliases),
        dirty: false,
      })
      aliases.delete(target)
      return true
    }
    return false
  }

  aliases.set(target, expressionToText(right, aliases))
  context.delete(target)
  return true
}

function assignEntityFromCallExpression(
  target: string,
  callExpr: CallExpression,
  context: Map<string, EntityState>,
  aliases: AliasMap,
): boolean {
  const calleeDecl = resolveFunction(callExpr)
  if (calleeDecl) {
    const summary = getFunctionSummary(calleeDecl)
    const substitutions = buildSubstitutionMap(calleeDecl, callExpr)
    applyOperations(summary.operations, context, substitutions)
    markParameterMutations(summary, calleeDecl, callExpr, context)
    if (summary.returnEntities.length > 0) {
      const entity = summary.returnEntities[0]
      context.set(target, {
        entityType: entity.entityType,
        idExpr: substituteExpression(entity.idExpr, substitutions),
        dirty: false,
      })
      aliases.delete(target)
      return true
    }
  }

  const direct = extractEntityFromDirectLoad(callExpr, aliases)
  if (direct) {
    context.set(target, { ...direct, dirty: false })
    aliases.delete(target)
    return true
  }
  return false
}

function handleSaveCall(
  callExpr: CallExpression,
  context: Map<string, EntityState>,
  handlerName: string,
  options: WalkOptions,
): boolean {
  const expression = callExpr.getExpression()
  if (!Node.isPropertyAccessExpression(expression)) return false
  if (expression.getName() !== 'save') return false

  const targetText = normalizeExpression(expression.getExpression().getText())
  const state = context.get(targetText)
  if (!state) return true

  if (options.onSave) {
    options.onSave(state, callExpr)
  }

  if (state.dirty) {
    const location = callExpr.getSourceFile().getLineAndColumnAtPos(callExpr.getPos())
    if (options.collectIssues && options.issueSink) {
      const mutationInfo = state.lastMutation ? ` Last change at ${state.lastMutation}.` : ''
      options.issueSink.push({
        checkId: CHECK_ID,
        severity: 'error',
        filePath: callExpr.getSourceFile().getFilePath(),
        line: location.line,
        handlerName,
        message: `${targetText}.save() overwrites recent changes to ${state.entityType} (${state.idExpr}).${mutationInfo}`,
      })
    }
    state.dirty = false
    state.lastMutation = undefined
  } else {
    state.dirty = false
    state.lastMutation = undefined
  }

  return true
}

function handleGeneralCall(callExpr: CallExpression, context: Map<string, EntityState>) {
  const calleeDecl = resolveFunction(callExpr)
  if (!calleeDecl) {
    return
  }
  const summary = getFunctionSummary(calleeDecl)
  if (summary.operations.length === 0) return

  const substitutions = buildSubstitutionMap(calleeDecl, callExpr)
  applyOperations(summary.operations, context, substitutions)
  markParameterMutations(summary, calleeDecl, callExpr, context)
}

function applyOperations(
  operations: Operation[],
  context: Map<string, EntityState>,
  substitution: Map<string, string>,
) {
  for (const op of operations) {
    const instantiatedExpr = substituteExpression(op.idExpr, substitution)
    for (const state of context.values()) {
      if (state.entityType === op.entityType && state.idExpr === instantiatedExpr) {
        state.dirty = true
        state.lastMutation = op.source
      }
    }
  }
}

function markParameterMutations(
  summary: FunctionSummary,
  calleeDecl: FunctionDeclaration,
  callExpr: CallExpression,
  context: Map<string, EntityState>,
  label?: string,
): void {
  if (!summary.parameterMutations.length) return
  const params = calleeDecl.getParameters()
  const args = callExpr.getArguments()
  for (const paramName of summary.parameterMutations) {
    const index = params.findIndex((param) => param.getName() === paramName)
    if (index === -1) continue
    const arg = args[index] as Expression | undefined
    if (!arg) continue
    const argExpr = unwrapExpression(arg)
    if (!Node.isIdentifier(argExpr)) continue
    const state = context.get(argExpr.getText())
    if (!state) continue
    state.dirty = true
    state.lastMutation = formatOperationSource(
      callExpr,
      label ?? `${calleeDecl.getName() ?? '<anonymous>'} (param ${paramName})`,
    )
  }
}

function extractEntityFromDirectLoad(
  callExpr: CallExpression,
  aliases?: AliasMap,
): { entityType: string; idExpr: string } | null {
  const expression = callExpr.getExpression()

  if (Node.isPropertyAccessExpression(expression) && expression.getName() === 'load') {
    const entityType = expression.getExpression().getText()
    const idArg = callExpr.getArguments()[0]
    if (!idArg || !Node.isExpression(idArg)) return null
    return { entityType, idExpr: expressionToText(idArg, aliases) }
  }

  if (Node.isIdentifier(expression)) {
    const calleeDecl = resolveFunction(callExpr)
    if (calleeDecl) {
      const summary = getFunctionSummary(calleeDecl)
      if (summary.returnEntities.length > 0) {
        const substitution = buildSubstitutionMap(calleeDecl, callExpr)
        const entity = summary.returnEntities[0]
        return {
          entityType: entity.entityType,
          idExpr: substituteExpression(entity.idExpr, substitution),
        }
      }
    }
  }

  return null
}

function resolveFunction(callExpr: CallExpression): FunctionDeclaration | null {
  let symbol = callExpr.getExpression().getSymbol()
  if (!symbol) return null
  if (symbol.isAlias()) {
    const aliased = symbol.getAliasedSymbol()
    if (aliased) {
      symbol = aliased
    }
  }
  for (const decl of symbol.getDeclarations() ?? []) {
    if (Node.isFunctionDeclaration(decl)) {
      return decl
    }
  }
  return null
}

function getFunctionSummary(func: FunctionDeclaration): FunctionSummary {
  if (summaries.has(func)) {
    return summaries.get(func)!
  }
  if (summaryInProgress.has(func)) {
    return { operations: [], returnEntities: [], parameterMutations: [] }
  }

  summaryInProgress.add(func)
  const operations: Operation[] = []
  const returnEntities: EntityInfo[] = []
  const context = new Map<string, EntityState>()
  const aliases: AliasMap = new Map()
  const parameterMutations = new Set<string>()

  const collect = (callExpr: CallExpression) => {
    const calleeDecl = resolveFunction(callExpr)
    if (!calleeDecl) return
    const nestedOps = getFunctionSummary(calleeDecl)
    const substitution = buildSubstitutionMap(calleeDecl, callExpr)
    for (const op of nestedOps.operations) {
      operations.push({
        entityType: op.entityType,
        idExpr: substituteExpression(op.idExpr, substitution),
        source: op.source,
      })
    }
    for (const ret of nestedOps.returnEntities) {
      returnEntities.push({
        entityType: ret.entityType,
        idExpr: substituteExpression(ret.idExpr, substitution),
      })
    }
    markParameterMutations(nestedOps, calleeDecl, callExpr, context, func.getName())
  }

  const statements = func.getStatements()
  for (const stmt of statements) {
    if (Node.isVariableStatement(stmt)) {
      for (const decl of stmt.getDeclarations()) {
        const initializer = decl.getInitializer()
        if (!initializer) continue
        const initExpr = unwrapExpression(initializer)
        const name = decl.getName()
        if (Node.isCallExpression(initExpr)) {
          if (assignEntityFromCallExpression(name, initExpr, context, aliases)) {
            continue
          }
          aliases.set(name, expressionToText(initExpr, aliases))
          continue
        }

        if (Node.isNewExpression(initExpr)) {
          const entityCtor = initExpr.getExpression().getText()
          const idArg = initExpr.getArguments()[0]
          if (entityCtor && idArg && Node.isExpression(idArg)) {
            context.set(name, {
              entityType: entityCtor,
              idExpr: expressionToText(idArg, aliases),
              dirty: false,
            })
            aliases.delete(name)
          }
          continue
        }

        aliases.set(name, expressionToText(initExpr, aliases))
      }
      continue
    }

    if (Node.isExpressionStatement(stmt)) {
      const expr = unwrapExpression(stmt.getExpression())
      if (Node.isBinaryExpression(expr) && expr.getOperatorToken().getText() === '=') {
        if (handleAssignmentExpression(expr, context, aliases)) {
          continue
        }
      }
      if (Node.isCallExpression(expr)) {
        if (handleSummarySave(expr, context, operations, func, parameterMutations)) continue
        collect(expr)
      }
      continue
    }

    if (Node.isIfStatement(stmt)) {
      const branchLabel = func.getName() ? `${func.getName()} (branch)` : '<branch>'
      const thenOps = getOperationsFromBlock(stmt.getThenStatement(), context, aliases, branchLabel)
      operations.push(...thenOps)
      const elseStmt = stmt.getElseStatement()
      if (elseStmt) {
        operations.push(...getOperationsFromBlock(elseStmt, context, aliases, branchLabel))
      }
      continue
    }

    if (Node.isReturnStatement(stmt)) {
      const entity = resolveEntityFromReturn(stmt, context, aliases)
      if (entity) {
        returnEntities.push(entity)
      }
      continue
    }
  }

  summaries.set(func, {
    operations,
    returnEntities,
    parameterMutations: Array.from(parameterMutations),
  })
  summaryInProgress.delete(func)
  return { operations, returnEntities, parameterMutations: Array.from(parameterMutations) }
}

function formatOperationSource(callExpr: CallExpression, contextLabel?: string): string {
  const filePath = path.relative(process.cwd(), callExpr.getSourceFile().getFilePath())
  const { line } = callExpr.getSourceFile().getLineAndColumnAtPos(callExpr.getPos())
  if (contextLabel && contextLabel.length > 0) {
    return `${filePath}:${line} (${contextLabel})`
  }
  const parentFunc = callExpr.getFirstAncestorByKind(SyntaxKind.FunctionDeclaration)
  const label = parentFunc?.getName()
  return label ? `${filePath}:${line} (${label})` : `${filePath}:${line}`
}

function handleSummarySave(
  callExpr: CallExpression,
  context: Map<string, EntityState>,
  ops: Operation[],
  ownerFunc?: FunctionDeclaration,
  parameterMutations?: Set<string>,
): boolean {
  const expression = callExpr.getExpression()
  if (!Node.isPropertyAccessExpression(expression) || expression.getName() !== 'save') return false
  const varName = expression.getExpression().getText()
  const state = context.get(varName)
  if (state) {
    ops.push({
      entityType: state.entityType,
      idExpr: state.idExpr,
      source: formatOperationSource(callExpr, ownerFunc?.getName()),
    })
    return true
  }
  if (ownerFunc && parameterMutations) {
    for (const param of ownerFunc.getParameters()) {
      if (param.getName() === varName) {
        parameterMutations.add(varName)
        return true
      }
    }
  }
  return true
}

function getOperationsFromBlock(
  block: Node,
  parentContext: Map<string, EntityState>,
  parentAliases: AliasMap,
  label?: string,
): Operation[] {
  const context = cloneContext(parentContext)
  const aliases = cloneAliases(parentAliases)
  const ops: Operation[] = []
  walkStatements(toStatements(block), context, aliases, '<summary>', {
    collectIssues: false,
    onSave: (state, callExpr) => {
      ops.push({
        entityType: state.entityType,
        idExpr: state.idExpr,
        source: formatOperationSource(callExpr, label ?? '<branch>'),
      })
    },
  })
  return ops
}

function buildSubstitutionMap(func: FunctionDeclaration, callExpr: CallExpression): Map<string, string> {
  const substitution = new Map<string, string>()
  const params = func.getParameters()
  const args = callExpr.getArguments()
  params.forEach((param, index) => {
    const arg = args[index]
    if (!arg) return
    substitution.set(param.getName(), normalizeExpression(arg.getText()))
  })
  return substitution
}

function substituteExpression(expr: string, substitution: Map<string, string>): string {
  let result = expr
  for (const [param, value] of substitution.entries()) {
    const regex = new RegExp(`\\b${param}\\b`, 'g')
    result = result.replace(regex, value)
  }
  return normalizeExpression(result)
}

function normalizeExpression(text: string): string {
  return text.replace(/\s+/g, ' ').trim()
}

function resolveEntityFromReturn(
  returnStmt: ReturnStatement,
  context: Map<string, EntityState>,
  aliases: AliasMap,
): EntityInfo | null {
  const expr = returnStmt.getExpression()
  if (!expr) return null

  const unwrapped = unwrapExpression(expr)

  if (Node.isIdentifier(unwrapped)) {
    const state = context.get(unwrapped.getText())
    if (state) {
      return { entityType: state.entityType, idExpr: state.idExpr }
    }
  }

  if (Node.isCallExpression(unwrapped)) {
    const direct = extractEntityFromDirectLoad(unwrapped, aliases)
    if (direct) return direct

    const callee = resolveFunction(unwrapped)
    if (!callee) return null
    const summary = getFunctionSummary(callee)
    if (!summary.returnEntities.length) return null
    const substitution = buildSubstitutionMap(callee, unwrapped)
    const first = summary.returnEntities[0]
    return {
      entityType: first.entityType,
      idExpr: substituteExpression(first.idExpr, substitution),
    }
  }

  return null
}

function unwrapExpression(expression: Expression): Expression {
  let current: Expression = expression
  while (
    Node.isNonNullExpression(current) ||
    Node.isParenthesizedExpression(current) ||
    Node.isAsExpression(current) ||
    Node.isTypeAssertion(current)
  ) {
    current = current.getExpression()
  }
  return current
}
