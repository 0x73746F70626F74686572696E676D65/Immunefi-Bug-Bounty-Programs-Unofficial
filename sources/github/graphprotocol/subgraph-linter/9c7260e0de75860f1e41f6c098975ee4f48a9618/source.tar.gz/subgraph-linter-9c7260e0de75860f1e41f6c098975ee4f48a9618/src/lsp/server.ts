import { readFileSync, existsSync, readdirSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import {
  createConnection,
  Diagnostic,
  DiagnosticSeverity,
  InitializeParams,
  InitializeResult,
  ProposedFeatures,
  TextDocumentSyncKind,
} from 'vscode-languageserver/node.js'
import { TextDocuments } from 'vscode-languageserver/node.js'
import { TextDocument } from 'vscode-languageserver-textdocument'
import { Project } from 'ts-morph'

import { checks } from '../checks/index.js'
import { runChecks, RunChecksError } from '../runner.js'
import { loadSchemaInfo } from '../schema.js'
import {
  AnalyzerConfig,
  applySeverityOverrides,
  loadConfig,
  loadManifestInfo,
} from '../analyzerSupport.js'
import type { Issue } from '../types.js'
import { applyCommentSuppressions } from '../suppression.js'

const connection = createConnection(ProposedFeatures.all)
const documents = new TextDocuments(TextDocument)

type InitOptions = {
  manifestPaths?: string[]
  tsconfigPath?: string
  configPath?: string
}

let workspaceRoot: string | null = null
let manifestPaths: string[] = []
let tsconfigPath: string | undefined
let configPath: string | undefined
let lastPublishedUris = new Set<string>()

connection.onInitialize((params: InitializeParams): InitializeResult => {
  workspaceRoot = params.rootUri ? fileURLToPath(params.rootUri) : params.rootPath ?? null
  const options: InitOptions = (params.initializationOptions as InitOptions) ?? {}
  manifestPaths = options.manifestPaths ?? []
  tsconfigPath = options.tsconfigPath
  configPath = options.configPath

  if (manifestPaths.length === 0 && workspaceRoot) {
    manifestPaths = discoverManifests(workspaceRoot)
  }

  return {
    capabilities: {
      textDocumentSync: {
        change: TextDocumentSyncKind.Incremental,
        save: { includeText: false },
      },
    },
  }
})

connection.onInitialized(() => {
  runAnalysis()
})

documents.onDidSave(() => {
  runAnalysis()
})

connection.onNotification('subgraphLinter/runAnalysis', () => {
  runAnalysis()
})

documents.listen(connection)
connection.listen()

function runAnalysis() {
  if (!manifestPaths.length) {
    connection.console.warn('No manifest paths provided; skipping analysis.')
    publishDiagnostics([])
    return
  }
  connection.console.log(
    `Analyzing with manifests: ${manifestPaths.map((p) => path.relative(workspaceRoot ?? '', p)).join(', ')}`,
  )
  const tsConfigFilePath = resolveTsConfigFilePath()
  if (!existsSync(tsConfigFilePath)) {
    connection.console.error(`tsconfig not found at ${tsConfigFilePath}; skipping analysis.`)
    publishDiagnostics([])
    return
  }
  let config: AnalyzerConfig = {}
  try {
    config = loadConfig(configPath)
  } catch (error) {
    connection.console.error(`Failed to load config: ${(error as Error).message}`)
  }

  let manifestInfo
  try {
    manifestInfo = loadManifestInfo(manifestPaths)
  } catch (error) {
    connection.console.error(`Failed to load manifest: ${(error as Error).message}`)
    publishDiagnostics([])
    return
  }

  const project = new Project({
    tsConfigFilePath,
  })
  const schema = loadSchemaInfo(manifestInfo.schemaPaths)
  let rawIssues
  try {
    rawIssues = runChecks({ project, manifestInfo, schema }, checks)
  } catch (error) {
    if (error instanceof RunChecksError) {
      connection.console.error(error.message)
      publishDiagnostics([])
      return
    }
    throw error
  }
  const issues = applyCommentSuppressions(
    applySeverityOverrides(rawIssues, config.severityOverrides ?? {}),
    config.suppression,
  )
  publishDiagnostics(issues)
}

function publishDiagnostics(issues: Issue[]) {
  const byFile = new Map<string, Issue[]>()
  for (const issue of issues) {
    const list = byFile.get(issue.filePath) ?? []
    list.push(issue)
    byFile.set(issue.filePath, list)
  }

  const currentUris = new Set<string>()
  for (const [filePath, fileIssues] of byFile.entries()) {
    const uri = pathToFileURL(filePath).toString()
    currentUris.add(uri)
    const diagnostics: Diagnostic[] = fileIssues.map((issue) => {
      const line = Math.max(issue.line - 1, 0)
      const length = getLineLength(issue.filePath, line)
      return {
        range: {
          start: { line, character: 0 },
          end: { line, character: Math.max(length, 1) },
        },
        severity: issue.severity === 'error' ? DiagnosticSeverity.Error : DiagnosticSeverity.Warning,
        message: issue.message,
        source: 'subgraph-linter',
        code: issue.checkId,
        data: issue.metadata,
      }
    })
    connection.sendDiagnostics({ uri, diagnostics })
  }

  for (const uri of lastPublishedUris) {
    if (currentUris.has(uri)) continue
    connection.sendDiagnostics({ uri, diagnostics: [] })
  }
  lastPublishedUris = currentUris
}

function getLineLength(filePath: string, lineZeroBased: number): number {
  try {
    const contents = readFileSync(filePath, 'utf8')
    const lines = contents.split(/\r?\n/)
    return lines[lineZeroBased]?.length ?? 0
  } catch (error) {
    connection.console.warn(
      `Unable to read ${filePath} for diagnostic range: ${(error as Error).message}`,
    )
    return 0
  }
}

function discoverManifests(root: string): string[] {
  const candidates: string[] = []
  const rootCandidate = path.join(root, 'subgraph.yaml')
  if (existsSync(rootCandidate)) {
    candidates.push(rootCandidate)
  }
  try {
    for (const entry of readdirSync(root, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue
      if (entry.name === 'node_modules' || entry.name === 'build' || entry.name === 'dist') continue
      const candidate = path.join(root, entry.name, 'subgraph.yaml')
      if (existsSync(candidate)) {
        candidates.push(candidate)
      }
    }
  } catch {
    // ignore
  }
  return candidates.filter((p) => !p.includes(`${path.sep}build${path.sep}`) && !p.includes(`${path.sep}dist${path.sep}`))
}

function resolveTsConfigFilePath(): string {
  if (tsconfigPath) {
    return workspaceRoot ? path.resolve(workspaceRoot, tsconfigPath) : path.resolve(tsconfigPath)
  }

  const candidates: string[] = []
  for (const manifestPath of manifestPaths) {
    const manifestDir = path.dirname(manifestPath)
    candidates.push(path.join(manifestDir, 'tsconfig.json'))
  }
  if (workspaceRoot) {
    candidates.push(path.join(workspaceRoot, 'tsconfig.json'))
  }

  for (const candidate of candidates) {
    if (existsSync(candidate)) {
      return candidate
    }
  }

  return workspaceRoot ? path.join(workspaceRoot, 'tsconfig.json') : path.resolve('tsconfig.json')
}
