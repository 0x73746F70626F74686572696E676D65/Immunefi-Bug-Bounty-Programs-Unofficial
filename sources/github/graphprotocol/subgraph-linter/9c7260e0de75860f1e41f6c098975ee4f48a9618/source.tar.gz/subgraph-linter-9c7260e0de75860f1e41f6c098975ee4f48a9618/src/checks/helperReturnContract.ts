import { CallExpression, Node, SyntaxKind } from 'ts-morph'

import type { Check, HandlerCheckContext, Issue } from '../types.js'
import { getUnexpectedNullFunctionSummary } from './unexpectedNull.js'

const CHECK_ID = 'helper-return-contract'

export const helperReturnContractCheck: Check = {
  id: CHECK_ID,
  description: 'Warns when helpers may return partially initialized entities so callers can fill required fields.',
  run(context) {
    const issues: Issue[] = []
    visitCallExpressions(context, issues)
    return issues
  },
}

function visitCallExpressions(context: HandlerCheckContext, issues: Issue[]) {
  context.handler.forEachDescendant((node) => {
    if (!Node.isCallExpression(node)) return
    checkCallExpression(context, node, issues)
  })
}

function checkCallExpression(
  context: HandlerCheckContext,
  callExpr: CallExpression,
  issues: Issue[],
) {
  const calleeDecl = resolveFunction(callExpr)
  if (!calleeDecl) return
  const summary = getUnexpectedNullFunctionSummary(context, calleeDecl)
  const helperName = calleeDecl.getName() ?? '<anonymous>'
  const entityWarnings = collectEntityWarnings(summary)
  const assignedIdentifier = getAssignedIdentifier(callExpr)
  if (!entityWarnings.size) {
    return
  }
  const { line } = callExpr.getSourceFile().getLineAndColumnAtPos(callExpr.getPos())
  const filePath = callExpr.getSourceFile().getFilePath()
  const handlerName = context.handler.getName() ?? '<anonymous>'
  for (const [entityType, fields] of entityWarnings.entries()) {
    if (
      assignedIdentifier &&
      fields.size > 0 &&
      fieldsSatisfiedBeforeSave(callExpr, assignedIdentifier, fields)
    ) {
      continue
    }
    issues.push({
      checkId: CHECK_ID,
      severity: 'warning',
      filePath,
      line,
      handlerName,
      message: `Helper ${helperName} may return ${entityType} without initializing: ${Array.from(
        fields,
      )
        .sort()
        .join(', ')}. Ensure the caller sets these fields before saving.`,
    })
  }
}

function collectEntityWarnings(
  summary: ReturnType<typeof getUnexpectedNullFunctionSummary>,
): Map<string, Set<string>> {
  const map = new Map<string, Set<string>>()
  for (const returned of summary.returnedEntities) {
    if (!returned.missingFields || returned.missingFields.size === 0) {
      continue
    }
    const existing = map.get(returned.entityType) ?? new Set<string>()
    for (const field of returned.missingFields) {
      existing.add(field)
    }
    map.set(returned.entityType, existing)
  }
  return map
}

function resolveFunction(callExpr: CallExpression) {
  let symbol = callExpr.getExpression().getSymbol()
  if (!symbol) {
    return null
  }
  if (symbol.isAlias()) {
    const aliased = symbol.getAliasedSymbol()
    if (aliased) {
      symbol = aliased
    }
  }
  for (const decl of symbol.getDeclarations() ?? []) {
    if (Node.isFunctionDeclaration(decl)) {
      return decl
    }
  }
  return null
}

function getAssignedIdentifier(callExpr: CallExpression): string | null {
  const parent = callExpr.getParent()
  if (Node.isVariableDeclaration(parent)) {
    return parent.getName()
  }
  if (
    Node.isBinaryExpression(parent) &&
    parent.getOperatorToken().getText() === '=' &&
    Node.isIdentifier(parent.getLeft())
  ) {
    return parent.getLeft().getText()
  }
  return null
}

function fieldsSatisfiedBeforeSave(
  callExpr: CallExpression,
  targetIdentifier: string,
  missingFields: Set<string>,
): boolean {
  const statement = callExpr.getFirstAncestor((node) => Node.isStatement(node))
  if (!statement) return false

  const parent = statement.getParent()
  if (!parent || (!Node.isBlock(parent) && !Node.isSourceFile(parent))) return false

  const statements = parent.getStatements()
  const currentIndex = statements.findIndex((stmt) => stmt === statement)
  if (currentIndex === -1) return false

  const pending = new Set(missingFields)
  for (let i = currentIndex + 1; i < statements.length; i += 1) {
    const stmt = statements[i]
    if (!Node.isExpressionStatement(stmt)) {
      continue
    }
    const expr = unwrapExpression(stmt.getExpression())
    if (Node.isBinaryExpression(expr) && expr.getOperatorToken().getText() === '=') {
      const left = unwrapExpression(expr.getLeft())
      if (Node.isPropertyAccessExpression(left)) {
        const base = normalizeExpression(left.getExpression().getText())
        if (base === targetIdentifier) {
          pending.delete(left.getName())
        }
      }
    }

    if (Node.isCallExpression(expr)) {
      const callee = expr.getExpression()
      if (
        Node.isPropertyAccessExpression(callee) &&
        callee.getName() === 'save' &&
        normalizeExpression(callee.getExpression().getText()) === targetIdentifier
      ) {
        return pending.size === 0
      }
    }
  }

  return pending.size === 0
}

function unwrapExpression(expression: import('ts-morph').Expression) {
  let current = expression
  while (
    Node.isParenthesizedExpression(current) ||
    Node.isAsExpression(current) ||
    Node.isNonNullExpression(current)
  ) {
    current = current.getExpression()
  }
  return current
}

function normalizeExpression(text: string): string {
  return text.replace(/\s+/g, '').trim()
}
