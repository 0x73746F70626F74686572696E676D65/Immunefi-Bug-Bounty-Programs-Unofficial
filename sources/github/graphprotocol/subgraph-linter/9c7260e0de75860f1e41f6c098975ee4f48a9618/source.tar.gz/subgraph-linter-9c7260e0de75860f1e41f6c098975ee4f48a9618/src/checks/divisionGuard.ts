import { Node, SyntaxKind } from 'ts-morph'

import type { Check, HandlerCheckContext, Issue } from '../types.js'

const CHECK_ID = 'division-guard'

export const divisionGuardCheck: Check = {
  id: CHECK_ID,
  description: 'Ensures divisions guard against zero denominators.',
  run(context) {
    const issues: Issue[] = []
    const handlerName = context.handler.getName() ?? '<anonymous>'
    const initialGuards = new Set<string>()
    visitNode(context.handler, initialGuards, handlerName, issues)
    return issues
  },
}

function visitNode(
  node: Node,
  guards: Set<string>,
  handlerName: string,
  issues: Issue[],
) {
  if (Node.isConditionalExpression(node)) {
    const { thenGuards, elseGuards } = deriveGuardsForCondition(node.getCondition(), guards)
    visitNode(node.getCondition(), guards, handlerName, issues)
    visitNode(node.getWhenTrue(), thenGuards, handlerName, issues)
    visitNode(node.getWhenFalse(), elseGuards, handlerName, issues)
    return
  }

  if (Node.isIfStatement(node)) {
    const { thenGuards, elseGuards } = deriveBranchGuards(node, guards)
    visitNode(node.getThenStatement(), thenGuards, handlerName, issues)
    const elseStmt = node.getElseStatement()
    if (elseStmt) {
      visitNode(elseStmt, elseGuards, handlerName, issues)
    }
    return
  }

  if (Node.isBinaryExpression(node) && node.getOperatorToken().getKind() === SyntaxKind.SlashToken) {
    checkDenominator(node.getRight(), guards, handlerName, issues)
  }

  if (Node.isCallExpression(node) && isDivisionCall(node)) {
    const args = node.getArguments()
    if (args.length > 0) {
      checkDenominator(args[0], guards, handlerName, issues)
    }
  }

  node.forEachChild((child) => visitNode(child, guards, handlerName, issues))
}

function isDivisionCall(node: import('ts-morph').CallExpression): boolean {
  const expression = node.getExpression()
  if (!expression.isKind(SyntaxKind.PropertyAccessExpression)) {
    return false
  }
  const name = expression.getName()
  return name === 'div' || name === 'divide'
}

function checkDenominator(
  denominatorNode: Node,
  guards: Set<string>,
  handlerName: string,
  issues: Issue[],
) {
  if (!Node.isExpression(denominatorNode)) {
    return
  }
  const denominator = denominatorNode
  if (isDefinitelyNonZero(denominator)) {
    return
  }
  const key = normalizeExpression(denominator)
  if (guards.has(key)) {
    return
  }
  const sourceFile = denominator.getSourceFile()
  const { line } = sourceFile.getLineAndColumnAtPos(denominator.getPos())
  issues.push({
    checkId: CHECK_ID,
    severity: 'error',
    filePath: sourceFile.getFilePath(),
    line,
    handlerName,
    message: `Division uses a potentially zero denominator (${denominator.getText()}); ensure it is guarded before dividing.`,
  })
}

function deriveBranchGuards(
  ifStmt: import('ts-morph').IfStatement,
  currentGuards: Set<string>,
) {
  return deriveGuardsForCondition(ifStmt.getExpression(), currentGuards)
}

function deriveGuardsForCondition(
  condition: Node,
  currentGuards: Set<string>,
) {
  const guards = extractGuardInfo(condition)
  const thenGuards = new Set(currentGuards)
  const elseGuards = new Set(currentGuards)
  for (const guard of guards) {
    if (guard.branch === 'then') {
      thenGuards.add(guard.expr)
    } else if (guard.branch === 'else') {
      elseGuards.add(guard.expr)
    }
  }
  return { thenGuards, elseGuards }
}

type GuardInfo = {
  expr: string
  branch: 'then' | 'else'
}

function extractGuardInfo(conditionNode: Node): GuardInfo[] {
  if (!Node.isExpression(conditionNode)) {
    return []
  }
  const condition = conditionNode
  if (Node.isBinaryExpression(condition)) {
    return extractFromBinary(condition)
  }
  if (Node.isPrefixUnaryExpression(condition) && condition.getOperatorToken() === SyntaxKind.ExclamationToken) {
    const inner = condition.getOperand()
    return extractGuardInfo(inner).map((guard) => ({ expr: guard.expr, branch: guard.branch === 'then' ? 'else' : 'then' }))
  }
  if (Node.isCallExpression(condition)) {
    return extractFromCall(condition)
  }
  return []
}

function extractFromBinary(node: import('ts-morph').BinaryExpression): GuardInfo[] {
  const operator = node.getOperatorToken().getKind()
  if (!isComparisonOperator(operator)) {
    return []
  }
  const left = node.getLeft()
  const right = node.getRight()
  const leftText = normalizeText(left.getText())
  const rightText = normalizeText(right.getText())
  const leftZero = isZeroExpression(left)
  const rightZero = isZeroExpression(right)
  const guards: GuardInfo[] = []

  if (rightZero && !leftZero) {
    const expr = normalizeExpression(left)
    if (operator === SyntaxKind.ExclamationEqualsEqualsToken || operator === SyntaxKind.ExclamationEqualsToken || operator === SyntaxKind.GreaterThanToken || operator === SyntaxKind.LessThanToken) {
      guards.push({ expr, branch: 'then' })
    } else if (operator === SyntaxKind.EqualsEqualsToken || operator === SyntaxKind.EqualsEqualsEqualsToken) {
      guards.push({ expr, branch: 'else' })
    }
  }
  if (leftZero && !rightZero) {
    const expr = normalizeExpression(right)
    if (operator === SyntaxKind.ExclamationEqualsEqualsToken || operator === SyntaxKind.ExclamationEqualsToken || operator === SyntaxKind.GreaterThanToken || operator === SyntaxKind.LessThanToken) {
      guards.push({ expr, branch: 'then' })
    } else if (operator === SyntaxKind.EqualsEqualsToken || operator === SyntaxKind.EqualsEqualsEqualsToken) {
      guards.push({ expr, branch: 'else' })
    }
  }
  return guards
}

function extractFromCall(node: import('ts-morph').CallExpression): GuardInfo[] {
  const expression = node.getExpression()
  if (!expression.isKind(SyntaxKind.PropertyAccessExpression)) {
    return []
  }
  const name = expression.getName()
  const targetText = normalizeExpression(expression.getExpression())
  if (name === 'isZero') {
    return [{ expr: targetText, branch: 'else' }]
  }
  if (name === 'isNotZero') {
    return [{ expr: targetText, branch: 'then' }]
  }
  const args = node.getArguments()
  if (args.length === 0) {
    return []
  }
  const zeroArg = args[0]
  if (!isZeroExpression(zeroArg)) {
    return []
  }
  if (name === 'equals' || name === 'eq') {
    return [{ expr: targetText, branch: 'else' }]
  }
  if (name === 'notEquals' || name === 'notEqual') {
    return [{ expr: targetText, branch: 'then' }]
  }
  if (name === 'gt' || name === 'greaterThan') {
    if (isZeroExpression(zeroArg)) {
      return [{ expr: targetText, branch: 'then' }]
    }
    return []
  }
  if (name === 'lt' || name === 'lessThan') {
    if (isZeroExpression(zeroArg)) {
      return [{ expr: targetText, branch: 'then' }]
    }
    return []
  }
  return []
}

function isComparisonOperator(kind: SyntaxKind): boolean {
  return (
    kind === SyntaxKind.EqualsEqualsEqualsToken ||
    kind === SyntaxKind.EqualsEqualsToken ||
    kind === SyntaxKind.ExclamationEqualsEqualsToken ||
    kind === SyntaxKind.ExclamationEqualsToken ||
    kind === SyntaxKind.GreaterThanToken ||
    kind === SyntaxKind.LessThanToken
  )
}

function isZeroExpression(exprNode: Node): boolean {
  if (!Node.isExpression(exprNode)) {
    return false
  }
  const expr = exprNode
  if (Node.isNumericLiteral(expr)) {
    return Number(expr.getLiteralValue()) === 0
  }
  const text = normalizeText(expr.getText())
  if (text === '0' || text === 'BigInt.zero' || text === 'BigDecimal.zero') {
    return true
  }
  if (Node.isIdentifier(expr) && /zero/i.test(expr.getText())) {
    return true
  }
  if (Node.isPropertyAccessExpression(expr) && /zero/i.test(expr.getName())) {
    return true
  }
  if (Node.isCallExpression(expr)) {
    const callee = expr.getExpression()
    if (callee.isKind(SyntaxKind.PropertyAccessExpression)) {
      const name = callee.getName()
      const target = normalizeText(callee.getExpression().getText())
      if (name === 'equals' || name === 'eq') {
        const args = expr.getArguments()
        if (args.length > 0 && isZeroExpression(args[0])) {
          return false
        }
      }
    }
    const printed = normalizeText(expr.getText())
    if (
      printed === 'BigInt.fromI32(0)' ||
      printed === 'BigInt.fromString("0")' ||
      printed === 'BigDecimal.fromString("0")'
    ) {
      return true
    }
  }
  return false
}

function isDefinitelyNonZero(exprNode: Node): boolean {
  if (!Node.isExpression(exprNode)) {
    return false
  }
  const expr = exprNode
  if (Node.isNumericLiteral(expr)) {
    return Number(expr.getLiteralValue()) !== 0
  }
  const text = normalizeText(expr.getText())
  if (
    text === 'BigInt.fromI32(1)' ||
    text === 'BigInt.fromI32(-1)' ||
    text === 'BigDecimal.fromString("1")' ||
    text === 'BigInt.fromI32(1000000)' ||
    text === 'BigDecimal.fromString("1000000")'
  ) {
    return true
  }
  return false
}

function normalizeText(text: string): string {
  return text.replace(/\s+/g, '').replace(/'/g, '"')
}

function normalizeExpression(expr: Node): string {
  if (!Node.isExpression(expr)) {
    return ''
  }

  if (Node.isCallExpression(expr)) {
    const callee = expr.getExpression()
    if (callee.isKind(SyntaxKind.PropertyAccessExpression)) {
      const name = callee.getName()
      if (name === 'toBigDecimal' || name === 'toBigInt') {
        return normalizeExpression(callee.getExpression())
      }
      const namespace = normalizeText(callee.getExpression().getText())
      if (
        name === 'fromString' &&
        (namespace === 'BigDecimal' || namespace === 'BigInt')
      ) {
        const args = expr.getArguments()
        if (args.length > 0) {
          const firstArg = args[0]
          if (Node.isCallExpression(firstArg)) {
            const innerExpr = firstArg.getExpression()
            if (
              innerExpr.isKind(SyntaxKind.PropertyAccessExpression) &&
              innerExpr.getName() === 'toString'
            ) {
              return normalizeExpression(innerExpr.getExpression())
            }
          }
        }
      }
    }
  }

  const text = normalizeText(expr.getText())
  return text.replace(/\.toBigDecimal\(\)/g, '')
}
