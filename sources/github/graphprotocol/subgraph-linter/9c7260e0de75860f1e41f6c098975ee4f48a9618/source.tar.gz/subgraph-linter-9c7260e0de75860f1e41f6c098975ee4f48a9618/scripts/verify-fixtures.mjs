#!/usr/bin/env node
import { readFileSync } from 'node:fs'
import path from 'node:path'

const repoRoot = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..')
const expectedPath = path.resolve(repoRoot, 'test-fixtures', 'expected-issues.json')
const expected = JSON.parse(readFileSync(expectedPath, 'utf8'))
const expectedMap = new Map(expected.map((issue) => [issueKey(issue), issue]))

const outputPath = process.argv[2]
if (!outputPath) {
  console.error('Usage: node scripts/verify-fixtures.mjs <output-file>')
  process.exit(1)
}

const resolvedOutput = path.isAbsolute(outputPath)
  ? outputPath
  : path.resolve(repoRoot, outputPath)

let analyzerOutput = ''
try {
  analyzerOutput = readFileSync(resolvedOutput, 'utf8')
} catch (error) {
  console.error(`Failed to read analyzer output (${outputPath}): ${(error).message}`)
  process.exit(1)
}

if (!analyzerOutput.trim()) {
  console.error('Analyzer output is empty.')
  process.exit(1)
}

const issues = parseIssues(analyzerOutput)

if (issues.length === 0) {
  console.error('Expected fixture positives, but analyzer reported none.')
  process.exit(1)
}

if (issues.length !== expected.length) {
  console.error(`Fixture mismatch: expected ${expected.length} issues but saw ${issues.length}.`)
  reportDiff(issues, expectedMap)
  process.exit(1)
}

let allMatch = true
for (const issue of issues) {
  const key = issueKey(issue)
  const expectedIssue = expectedMap.get(key)
  if (!expectedIssue || expectedIssue.message !== issue.message) {
    console.error('Unexpected fixture issue:', issue)
    allMatch = false
  }
}

if (!allMatch) {
  console.error('Fixture verification failed. See differences above.')
  process.exit(1)
}

console.log(`Fixture verification passed (${issues.length} expected issues).`)
process.exit(0)

function parseIssues(output) {
  const lines = output
    .split('\n')
    .map((line) => line.replace(/\x1B\[[0-9;]*m/g, '').trimEnd())

  const issues = []
  for (let i = 0; i < lines.length; i += 1) {
    const headerMatch = lines[i].match(/^(error|warning)\[([^\]]+)]\: (.+)$/)
    if (!headerMatch) {
      continue
    }
    const [, _severity, checkId, handler] = headerMatch
    const locationLine = lines[i + 1]?.match(/^--> (.*):(\d+)$/) ?? lines[i + 1]?.match(/^  --> (.*):(\d+)$/)
    if (!locationLine) {
      continue
    }
    const [, filePath, lineNumber] = locationLine
    let message = ''
    for (let j = i + 2; j < lines.length; j += 1) {
      const stripped = lines[j].trimStart()
      if (!stripped.startsWith('= ')) {
        continue
      }
      message = stripped.slice(2)
      break
    }
    issues.push({
      file: path.normalize(path.relative(repoRoot, filePath)).replace(/\\/g, '/'),
      line: Number(lineNumber),
      handler,
      checkId,
      message,
    })
  }
  return issues
}

function issueKey(issue) {
  return `${issue.file}:${issue.line}:${issue.handler}:${issue.checkId}:${issue.message}`
}

function reportDiff(actualIssues, expectedMap) {
  const actualKeys = new Set(actualIssues.map(issueKey))
  for (const key of actualKeys) {
    if (!expectedMap.has(key)) {
      const issue = actualIssues.find((item) => issueKey(item) === key)
      console.error('Unexpected issue:', issue)
    }
  }
  for (const [key, issue] of expectedMap.entries()) {
    if (!actualKeys.has(key)) {
      console.error('Missing expected issue:', issue)
    }
  }
}
