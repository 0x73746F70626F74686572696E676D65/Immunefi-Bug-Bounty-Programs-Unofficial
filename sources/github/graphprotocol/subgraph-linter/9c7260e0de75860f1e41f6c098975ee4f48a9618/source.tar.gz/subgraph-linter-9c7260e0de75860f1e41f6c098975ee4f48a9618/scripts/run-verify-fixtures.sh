#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")"/.. && pwd)"
OUTPUT_FILE="$(mktemp)"
trap 'rm -f "$OUTPUT_FILE"' EXIT

set +e
node dist/index.js --manifest test-fixtures/subgraph.yaml --tsconfig test-fixtures/tsconfig.json >"$OUTPUT_FILE" 2>&1
set -e

if [[ ! -s "$OUTPUT_FILE" ]]; then
  echo "Analyzer produced no output" >&2
  exit 1
fi

node scripts/verify-fixtures.mjs "$OUTPUT_FILE"
