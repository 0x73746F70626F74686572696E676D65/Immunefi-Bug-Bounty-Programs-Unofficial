import { Curator, GraphAccount, GraphNetwork, Indexer, Provision, SubgraphDeployment } from '../entities'
import { BigDecimal, BigInt } from '../graph-ts-stubs'
import {
  createAccountWithOptionalInitialization,
  createGraphAccountWithoutBalance,
  createInitializedGraphAccount,
  createOrLoadGraphAccount,
  createOrLoadGraphNetwork,
  createOrLoadSubgraph,
  createOrLoadSubgraphDeployment,
  createOrLoadEpoch,
  addDefaultNameTokenLockWallets,
  updateCurrentDeploymentLinks,
  batchUpdateSubgraphSignalledTokens,
  calculateOwnStakeRatio,
  calculateOverdelegationDilution,
  calculateCapacitiesLegacy,
  calculateOwnStakeRatioForProvision,
  calculateDelegatedStakeRatioForProvision,
  calculateOverdelegationDilutionForProvision,
  updateDelegationExchangeRateForProvision,
  updateGraphNetworkDerivedMetrics,
} from '../helpers'
import { ExampleContract } from '../contracts'
import { addresses } from '../addresses'

type ContractEvent = {
  address: string
  params: {
    id: string
  }
}

const Address = {
  fromHexString(value: string): string {
    return value
  },
}

export function handleReloadedEntity(): void {
  let graphNetwork = createOrLoadGraphNetwork()
  createOrLoadSubgraphDeployment('QmSAFE', graphNetwork)
  graphNetwork = GraphNetwork.load('1')
  graphNetwork.subgraphDeploymentCount += 1
  graphNetwork.save()
}

export function handleCuratorReload(): void {
  let curator = Curator.load('curator-1')
  createOrLoadSubgraphDeployment('QmSAFE', createOrLoadGraphNetwork())
  curator = Curator.load('curator-1')
  curator.activeSignalCount += 1
  curator.save()
}

export function handleDistinctAccounts(): void {
  const alice = createOrLoadGraphAccount('alice')
  alice.balance += 10
  alice.save()

  const bob = createOrLoadGraphAccount('bob')
  bob.balance += 5
  bob.save()
}

export function handleSameAccountButReloaded(): void {
  let owner = createOrLoadGraphAccount('owner')
  createOrLoadSubgraphDeployment('QmX', createOrLoadGraphNetwork())
  owner = GraphAccount.load('owner')
  owner.balance += 1
  owner.save()
}

export function handleHelperInitializedSave(): void {
  const account = createInitializedGraphAccount('init-account')
  account.save()
}

export function handleHelperThenInitialize(): void {
  const account = createGraphAccountWithoutBalance('late-init')
  account.balance = 42
  account.save()
}

export function handleCheckedLoad(): void {
  const account = GraphAccount.load('safe-load')
  if (!account) return
  account.balance += 1
  account.save()
}

export function handleSafeCurrentL1Usage(): void {
  const graphNetwork = createOrLoadGraphNetwork()
  if (!graphNetwork.currentL1BlockNumber) {
    return
  }
  const blockNumber = graphNetwork.currentL1BlockNumber
  graphNetwork.subgraphDeploymentCount += blockNumber.length
  graphNetwork.save()
}

export function handleSafeDivision(): void {
  const numerator = 10
  const divisor = Math.random() > 0.5 ? 1 : 0
  if (divisor !== 0) {
    const ratio = numerator / divisor
    if (ratio > 0) {
      GraphNetwork.load('1')?.save()
    }
  }
}

export function handleBigDecimalGuard(): void {
  const fishermanRewardPercentage = BigInt.fromI32(100)
  const ratio =
    fishermanRewardPercentage == BigInt.fromI32(0)
      ? BigDecimal.fromString('0')
      : BigDecimal.fromString('1000000').div(
          BigDecimal.fromString(fishermanRewardPercentage.toString()),
        )
  if (ratio) {
    GraphNetwork.load('1').save()
  }
}

export function handleShareGuardedDivision(): void {
  const averageCostBasisShares = BigInt.fromI32(5)
  if (averageCostBasisShares.gt(BigInt.fromI32(0))) {
    const tokens = BigDecimal.fromString('10')
    const price = tokens.div(averageCostBasisShares.toBigDecimal())
    price.truncate(18)
  }
}

export function handleSafeDerivedRefresh(): void {
  const graphNetwork = createOrLoadGraphNetwork()
  graphNetwork.delegatedTokens += 5
  updateGraphNetworkDerivedMetrics(graphNetwork)
  graphNetwork.save()
}

export function handleSafeDerivedRefreshAfterSave(): void {
  const graphNetwork = createOrLoadGraphNetwork()
  graphNetwork.delegatedTokens += 2
  graphNetwork.save()
  updateGraphNetworkDerivedMetrics(graphNetwork)
}

export function handleSafeDefaultReserveRefresh(): void {
  let graphNetwork = createOrLoadGraphNetwork()
  graphNetwork.defaultReserveRatio += 1
  createOrLoadSubgraphDeployment('safe-reserve', graphNetwork)
  graphNetwork = GraphNetwork.load('1')
  graphNetwork.save()
}

export function handleSafeEpochRefresh(): void {
  const graphNetwork = createOrLoadGraphNetwork()
  graphNetwork.epochLength += 1
  createOrLoadEpoch(graphNetwork)
  graphNetwork.save()
}

export function handleSafeEpochRefreshAfterSave(): void {
  const graphNetwork = createOrLoadGraphNetwork()
  graphNetwork.epochLength += 3
  graphNetwork.lastLengthUpdateBlock += 1
  graphNetwork.currentEpoch += 1
  graphNetwork.save()
  createOrLoadEpoch(graphNetwork)
}

export function handleSafeDefaultNameHelper(): void {
  const account = createOrLoadGraphAccount('safe-name')
  account.defaultName = 'safe'
  addDefaultNameTokenLockWallets(account)
  account.save()
}

export function handleSafeActiveSubgraphRefresh(): void {
  const graphNetwork = createOrLoadGraphNetwork()
  graphNetwork.activeSubgraphCount += 1
  createOrLoadSubgraph(graphNetwork)
  graphNetwork.save()
}

export function handleSafeDeploymentSync(): void {
  const deployment = SubgraphDeployment.load('safe-deployment') ?? new SubgraphDeployment('safe-deployment')
  deployment.signalledTokens += 1
  updateCurrentDeploymentLinks(deployment)
  batchUpdateSubgraphSignalledTokens(deployment)
  deployment.save()
}

export function handleSafeIndexerRecalc(): void {
  const indexer = Indexer.load('safe-indexer')
  indexer.stakedTokens += 1
  calculateOwnStakeRatio(indexer)
  calculateOverdelegationDilution(indexer)
  calculateCapacitiesLegacy(indexer)
  indexer.save()
}

export function handleSafeProvisionRecalc(): void {
  const provision = Provision.load('safe-provision')
  provision.tokensProvisioned += 1
  calculateOwnStakeRatioForProvision(provision)
  calculateDelegatedStakeRatioForProvision(provision)
  calculateOverdelegationDilutionForProvision(provision)
  provision.save()
}

export function handleSafeProvisionDelegationRefresh(): void {
  const provision = Provision.load('safe-provision-delegation')
  provision.delegatedTokens += 1
  calculateOverdelegationDilutionForProvision(provision)
  updateDelegationExchangeRateForProvision(provision)
  provision.save()
}

export function handleDeclaredEthCallNonDeclarableBinding(event: ContractEvent): void {
  ExampleContract.bind(Address.fromHexString(addresses.ens)).getValue(event.params.id)
}
