export class ExampleContract {
  private constructor(public readonly address: string) {}

  static bind(address: string): ExampleContract {
    return new ExampleContract(address)
  }

  getValue(argument: string): string {
    return `${this.address}:${argument}`
  }

  try_getValue(argument: string): string {
    return this.getValue(argument)
  }
}
