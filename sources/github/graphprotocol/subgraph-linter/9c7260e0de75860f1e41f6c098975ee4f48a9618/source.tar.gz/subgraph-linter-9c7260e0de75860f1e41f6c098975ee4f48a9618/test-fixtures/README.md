# Detector Test Fixtures

This mini subgraph-style project provides two kinds of handlers:

- `src/mappings/positives.ts` contains patterns that *should* be flagged (helper mutates the singleton via a separate load and the handler never reloads it).
- `src/mappings/negatives.ts` covers safe scenarios (explicit reloads, distinct entity ids, helper returns reloaded instances, etc.).

Run the detector against the fixtures with:

```bash
npm run build
npm run check:fixtures
```

`npm run check:fixtures` points the CLI at `test-fixtures/subgraph.yaml` and `test-fixtures/tsconfig.json`. That manifest wires the overwrite cases (`handleMissingReload`, `handleHiddenOverwrite`, `processAllocation`), unexpected-null scenarios (`handleMissingInitialization`, `handleHelperMissingInitialization`, `handleDerivedAssignment`, `handleHelperOptionalInitialization`), the `[unchecked-load]` violation (`handleUncheckedLoadAssertion`), the `[unchecked-nonnull]` example (`handleUnsafeCurrentL1Usage`), and the `[division-guard]` case (`handleUnsafeDivision`). You should only see those intentional positives reported, which gives us a fast regression playground whenever we tweak the analyzer logic.

`npm run verify:fixtures` automates that expectation by comparing analyzer output with `test-fixtures/expected-issues.json`. If the detector emits new findings (or stops reporting an intentional positive) the script fails, prompting you to adjust either the code or the expected list.
