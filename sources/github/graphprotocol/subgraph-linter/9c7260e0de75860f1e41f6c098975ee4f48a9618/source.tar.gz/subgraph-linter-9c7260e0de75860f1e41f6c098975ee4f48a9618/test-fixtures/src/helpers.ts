import {
  GraphAccount,
  GraphNetwork,
  Indexer,
  Provision,
  SubgraphDeployment,
} from './entities'

export function createOrLoadGraphNetwork(): GraphNetwork {
  const network = GraphNetwork.load('1')
  network.save()
  return network
}

export function createOrLoadSubgraphDeployment(
  id: string,
  _graphNetwork?: GraphNetwork,
): SubgraphDeployment {
  const deployment = SubgraphDeployment.load(id) ?? new SubgraphDeployment(id)
  // Simulate helper re-loading the singleton and persisting independent changes
  const globalNetwork = GraphNetwork.load('1')
  globalNetwork.subgraphDeploymentCount += 1
  globalNetwork.save()
  if (_graphNetwork) {
    void _graphNetwork.defaultReserveRatio
  }
  deployment.save()
  return deployment
}

export function createOrLoadGraphAccount(id: string): GraphAccount {
  let account = GraphAccount.load(id)
  if (!account) {
    account = new GraphAccount(id)
    account.balance = 0
    account.save()
  }
  return account
}

export function createGraphAccountWithoutBalance(id: string): GraphAccount {
  return new GraphAccount(id)
}

export function createInitializedGraphAccount(id: string): GraphAccount {
  const account = new GraphAccount(id)
  account.balance = 1
  return account
}

export function createAccountWithOptionalInitialization(id: string, initialize: boolean): GraphAccount {
  const account = new GraphAccount(id)
  if (initialize) {
    account.balance = 1
  }
  return account
}

export function updateGraphNetworkDerivedMetrics(network: GraphNetwork): GraphNetwork {
  network.delegationExchangeRate = network.delegatedTokens * 2
  return network
}

export function createOrLoadEpoch(graphNetwork: GraphNetwork): void {
  void graphNetwork.epochLength
  void graphNetwork.lastLengthUpdateBlock
  void graphNetwork.currentEpoch
  void graphNetwork.epochCount
  void graphNetwork.lastLengthUpdateEpoch
}

export function addDefaultNameTokenLockWallets(account: GraphAccount): void {
  const name = account.defaultName
  const display = account.defaultDisplayName
  if (name && !display) {
    account.defaultDisplayName = name
  }
}

export function createOrLoadSubgraph(graphNetwork: GraphNetwork): void {
  void graphNetwork.activeSubgraphCount
}

export function updateCurrentDeploymentLinks(deployment: SubgraphDeployment): void {
  void deployment.signalledTokens
}

export function batchUpdateSubgraphSignalledTokens(deployment: SubgraphDeployment): void {
  void deployment.signalledTokens
}

export function calculateOwnStakeRatio(indexer: Indexer): void {
  void indexer.stakedTokens
}

export function calculateOverdelegationDilution(indexer: Indexer): void {
  void indexer.stakedTokens
  void indexer.lockedTokens
}

export function calculateCapacitiesLegacy(indexer: Indexer): void {
  void indexer.stakedTokens
  void indexer.lockedTokens
}

export function calculateOwnStakeRatioForProvision(provision: Provision): void {
  void provision.tokensProvisioned
}

export function calculateDelegatedStakeRatioForProvision(provision: Provision): void {
  void provision.tokensProvisioned
}

export function calculateOverdelegationDilutionForProvision(provision: Provision): void {
  void provision.delegatedTokens
}

export function updateDelegationExchangeRateForProvision(provision: Provision): void {
  void provision.delegatedTokens
}

import { ExampleContract } from './contracts'

export function callExampleGetValue(address: string, id: string): void {
  const contract = ExampleContract.bind(address)
  contract.getValue(id)
}

export function getExampleContract(address: string): ExampleContract {
  return ExampleContract.bind(address)
}
