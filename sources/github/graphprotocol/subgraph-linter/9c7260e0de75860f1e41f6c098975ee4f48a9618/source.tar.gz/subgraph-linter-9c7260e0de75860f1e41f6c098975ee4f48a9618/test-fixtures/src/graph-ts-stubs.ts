export class GraphProtocolBigDecimal {
  constructor(public readonly value: number) {}

  div(other: GraphProtocolBigDecimal): GraphProtocolBigDecimal {
    return new GraphProtocolBigDecimal(this.value / (other.value || 1))
  }

  minus(other: GraphProtocolBigDecimal): GraphProtocolBigDecimal {
    return new GraphProtocolBigDecimal(this.value - other.value)
  }

  times(other: GraphProtocolBigDecimal): GraphProtocolBigDecimal {
    return new GraphProtocolBigDecimal(this.value * other.value)
  }

  truncate(_: number): GraphProtocolBigDecimal {
    return new GraphProtocolBigDecimal(this.value)
  }
}

export class GraphProtocolBigInt {
  constructor(public readonly value: number) {}

  toString(): string {
    return this.value.toString()
  }

  toBigDecimal(): GraphProtocolBigDecimal {
    return new GraphProtocolBigDecimal(this.value)
  }

  gt(other: GraphProtocolBigInt): boolean {
    return this.value > other.value
  }
}

export const BigDecimal = {
  fromString(raw: string): GraphProtocolBigDecimal {
    return new GraphProtocolBigDecimal(Number(raw))
  },
}

export const BigInt = {
  fromI32(value: number): GraphProtocolBigInt {
    return new GraphProtocolBigInt(value)
  },
}
