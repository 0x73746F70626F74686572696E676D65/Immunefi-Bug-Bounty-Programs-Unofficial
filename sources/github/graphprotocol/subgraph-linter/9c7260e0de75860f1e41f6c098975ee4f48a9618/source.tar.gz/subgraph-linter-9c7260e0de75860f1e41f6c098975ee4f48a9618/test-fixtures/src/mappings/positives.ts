import { GraphAccount, GraphNetwork, Indexer, Provision, SubgraphDeployment } from '../entities'
import {
  createAccountWithOptionalInitialization,
  createGraphAccountWithoutBalance,
  createOrLoadGraphAccount,
  createOrLoadGraphNetwork,
  createOrLoadSubgraphDeployment,
  callExampleGetValue,
  getExampleContract,
} from '../helpers'
import { BigInt } from '../graph-ts-stubs'
import { ExampleContract } from '../contracts'

type ContractEvent = {
  address: string
  params: {
    id: string
  }
}

export function handleMissingReload(): void {
  const graphNetwork = createOrLoadGraphNetwork()
  createOrLoadSubgraphDeployment('QmABC', graphNetwork)
  graphNetwork.subgraphDeploymentCount += 1
  graphNetwork.save()
}

export function handleHiddenOverwrite(): void {
  let graphNetwork = GraphNetwork.load('1')
  createOrLoadSubgraphDeployment('Qm123', graphNetwork)
  // Forget to reload after helper side-effect
  graphNetwork.subgraphDeploymentCount += 5
  graphNetwork.save()
}

export function processAllocation(): void {
  const graphNetwork = GraphNetwork.load('1')
  createOrLoadSubgraphDeployment('QmALLOC', graphNetwork)
  graphNetwork.activeCuratorCount += 3
  graphNetwork.save()
}

export function handleMissingInitialization(): void {
  const account = new GraphAccount('account-1')
  // Forget to set required balance field
  account.save()
}

export function handleHelperMissingInitialization(): void {
  const account = createGraphAccountWithoutBalance('helper-account')
  account.save()
}

export function handleDerivedAssignment(): void {
  const account = createOrLoadGraphAccount('derived-account')
  account.signalledAllocations = []
  account.save()
}

export function handleHelperOptionalInitialization(): void {
  const account = createAccountWithOptionalInitialization('optional-init', false)
  account.save()
}

export function handleHelperOptionalInitializationSafe(): void {
  const account = createAccountWithOptionalInitialization('optional-safe', true)
  account.balance = 1
  account.save()
}

export function handleUncheckedLoadAssertion(): void {
  const account = GraphAccount.load('unchecked')!
  account.balance += 1
  account.save()
}

export function handleUnsafeCurrentL1Usage(): void {
  const graphNetwork = createOrLoadGraphNetwork()
  const blockNumber = graphNetwork.currentL1BlockNumber!
  graphNetwork.subgraphDeploymentCount += blockNumber.length
  graphNetwork.save()
}

export function handleUnsafeDivision(): void {
  const numerator = 10
  const divisor = maybeZero()
  const ratio = numerator / divisor
  if (ratio > 0) {
    GraphNetwork.load('1')?.save()
  }
}

function maybeZero(): number {
  return Math.random() > 2 ? 1 : 0
}

export function handleDeclaredEthCall(event: ContractEvent): void {
  const contract = ExampleContract.bind(event.address)
  contract.getValue(event.params.id)
}

export function handleMissingDerivedRefresh(): void {
  const graphNetwork = createOrLoadGraphNetwork()
  graphNetwork.delegatedTokens += 5
  graphNetwork.save()
}

export function handleMissingDefaultReserveRefresh(): void {
  const graphNetwork = createOrLoadGraphNetwork()
  graphNetwork.defaultReserveRatio += 1
  graphNetwork.save()
}

export function handleMissingEpochRefresh(): void {
  const graphNetwork = createOrLoadGraphNetwork()
  graphNetwork.epochLength += 1
  graphNetwork.lastLengthUpdateBlock += 1
  graphNetwork.currentEpoch += 1
  graphNetwork.epochCount += 1
  graphNetwork.lastLengthUpdateEpoch += 1
  graphNetwork.save()
}

export function handleMissingDefaultNameHelper(): void {
  const account = createOrLoadGraphAccount('default-name')
  account.defaultName = 'new-default'
  account.defaultDisplayName = 'New Default'
  account.save()
}

export function handleMissingActiveSubgraphRefresh(): void {
  const graphNetwork = createOrLoadGraphNetwork()
  graphNetwork.activeSubgraphCount += 1
  graphNetwork.save()
}

export function handleMissingDeploymentSync(): void {
  const deployment = SubgraphDeployment.load('deployment-edge') ?? new SubgraphDeployment('deployment-edge')
  deployment.signalledTokens += 1
  deployment.save()
}

export function handleMissingIndexerRecalc(): void {
  const indexer = Indexer.load('indexer-edge')
  indexer.stakedTokens += 10
  indexer.lockedTokens += 1
  indexer.save()
}

export function handleMissingProvisionRecalc(): void {
  const provision = Provision.load('provision-edge')
  provision.tokensProvisioned += 3
  provision.save()
}

export function handleMissingProvisionDelegationRefresh(): void {
  const provision = Provision.load('provision-delegation-edge')
  provision.delegatedTokens += 2
  provision.save()
}

class MockStaking {
  alphaNumerator() {
    return BigInt.fromI32(1)
  }

  alphaDenominator() {
    return BigInt.fromI32(0)
  }
}

export function handleAssumedSafeContractDivision(): void {
  const graphNetwork = createOrLoadGraphNetwork()
  const staking = new MockStaking()
  const ratio = staking
    .alphaNumerator()
    .toBigDecimal()
    .div(staking.alphaDenominator().toBigDecimal())
  ratio.truncate(18)
  graphNetwork.save()
}

const Address = {
  fromString(value: string): string {
    return value
  },
}

export function handleDeclaredEthCallWithAlias(evt: ContractEvent): void {
  const addr = evt.address
  const id = evt.params.id
  const contract = ExampleContract.bind(addr)
  contract.getValue(id)
}

export function handleDeclaredEthCallViaHelper(evt: ContractEvent): void {
  callExampleGetValue(evt.address, evt.params.id)
}

export function handleDeclaredEthCallStaticBinding(event: ContractEvent): void {
  ExampleContract.bind('0x0000000000000000000000000000000000000001').getValue(event.params.id)
}

export function handleDeclaredEthCallStaticBindingWrapper(event: ContractEvent): void {
  ExampleContract.bind(Address.fromString('0x0000000000000000000000000000000000000002')).getValue(event.params.id)
}

export function handleDeclaredEthCallTry(event: ContractEvent): void {
  const contract = ExampleContract.bind(event.address)
  contract.try_getValue(event.params.id)
}

export function handleDeclaredEthCallFromFactory(event: ContractEvent): void {
  getExampleContract(event.address).getValue(event.params.id)
}

export function handleUndeclaredEthCall(event: ContractEvent): void {
  ExampleContract.bind(event.address).getValue(event.params.id)
}

export function handleUndeclaredEthCallWithAlias(evt: ContractEvent): void {
  const addr = evt.address
  const id = evt.params.id
  const contract = ExampleContract.bind(addr)
  contract.getValue(id)
}

export function handleUndeclaredEthCallViaHelper(evt: ContractEvent): void {
  callExampleGetValue(evt.address, evt.params.id)
}

export function handleUndeclaredEthCallStaticBindingWrapper(event: ContractEvent): void {
  ExampleContract.bind(Address.fromString('0x0000000000000000000000000000000000000003')).getValue(event.params.id)
}

export function handleUndeclaredEthCallStaticBindingConstant(event: ContractEvent): void {
  const STATIC_ADDR = '0x0000000000000000000000000000000000000004'
  ExampleContract.bind(Address.fromString(STATIC_ADDR)).getValue(event.params.id)
}

export function handleUndeclaredEthCallNonDeclarableArg(event: ContractEvent): void {
  const id = 'local'
  ExampleContract.bind(event.address).getValue(id)
}

export function handleUndeclaredEthCallDuplicate(event: ContractEvent): void {
  ExampleContract.bind(event.address).getValue(event.params.id)
  ExampleContract.bind(event.address).getValue(event.params.id)
}

export function handleUndeclaredEthCallFromFactory(event: ContractEvent): void {
  getExampleContract(event.address).getValue(event.params.id)
}

export function handleSuppressedUndeclaredEthCall(event: ContractEvent): void {
  // [allow(undeclared-eth-call)]
  ExampleContract.bind(event.address).getValue(event.params.id)
}
