const graphNetworkStore = new Map<string, GraphNetwork>()
const subgraphDeploymentStore = new Map<string, SubgraphDeployment>()
const curatorStore = new Map<string, Curator>()
const graphAccountStore = new Map<string, GraphAccount>()
const allocationStore = new Map<string, Allocation>()
const indexerStore = new Map<string, Indexer>()
const provisionStore = new Map<string, Provision>()

export class GraphNetwork {
  constructor(public id: string) {}

  subgraphDeploymentCount = 0
  activeCuratorCount = 0
  currentL1BlockNumber: string | null = null
  delegatedTokens = 0
  delegationExchangeRate = 0
  defaultReserveRatio = 0
  epochLength = 0
  lastLengthUpdateBlock = 0
  currentEpoch = 0
  epochCount = 0
  lastLengthUpdateEpoch = 0
  activeSubgraphCount = 0

  static load(id: string): GraphNetwork {
    return graphNetworkStore.get(id) ?? new GraphNetwork(id)
  }

  save(): void {
    graphNetworkStore.set(this.id, this)
  }
}

export class SubgraphDeployment {
  constructor(public id: string) {}
  stakedTokens = 0
  signalledTokens = 0

  static load(id: string): SubgraphDeployment | null {
    return subgraphDeploymentStore.get(id) ?? null
  }

  save(): void {
    subgraphDeploymentStore.set(this.id, this)
  }
}

export class Curator {
  constructor(public id: string) {}
  activeSignalCount = 0
  activeCombinedSignalCount = 0

  static load(id: string): Curator {
    return curatorStore.get(id) ?? new Curator(id)
  }

  save(): void {
    curatorStore.set(this.id, this)
  }
}

export class GraphAccount {
  constructor(public id: string) {}
  balance = 0
  signalledAllocations: string[] = []
  defaultName: string | null = null
  defaultDisplayName: string | null = null

  static load(id: string): GraphAccount | null {
    return graphAccountStore.get(id) ?? null
  }

  save(): void {
    graphAccountStore.set(this.id, this)
  }
}

export class Allocation {
  constructor(public id: string) {}
  account: string = ''

  static load(id: string): Allocation | null {
    return allocationStore.get(id) ?? null
  }

  save(): void {
    allocationStore.set(this.id, this)
  }
}

export class Indexer {
  constructor(public id: string) {}
  stakedTokens = 0
  lockedTokens = 0

  static load(id: string): Indexer {
    return indexerStore.get(id) ?? new Indexer(id)
  }

  save(): void {
    indexerStore.set(this.id, this)
  }
}

export class Provision {
  constructor(public id: string) {}
  tokensProvisioned = 0
  delegatedTokens = 0

  static load(id: string): Provision {
    return provisionStore.get(id) ?? new Provision(id)
  }

  save(): void {
    provisionStore.set(this.id, this)
  }
}
