# Adding New Checks

This project now exposes a shared runner plus a registry of `Check` implementations. Follow the checklist below whenever you add another static-analysis rule so every contributor (human or LLM) keeps the architecture consistent and the fixtures up to date.

## 1. Implement the Check
1. Create a file under `src/checks/` (for example `src/checks/myNewRule.ts`).
2. Import the shared interfaces from `src/types.ts`:
   - `Check` gives you the `id`, `description`, and `run` signature.
   - `HandlerCheckContext` exposes the `ts-morph` `Project`, manifest metadata, parsed schema info, and the current handler declaration.
3. Write your analysis inside `run(context)` without reimplementing CLI/plumbing logic. Reuse helper utilities (`schemaInfo`, entity summaries, etc.) instead of duplicating manifest parsing.
4. Export the check and register it in `src/checks/index.ts` so the runner executes it alongside the existing rules.

## 2. Update Fixtures
1. Add representative positives/negatives under `test-fixtures/src/mappings/` so the new rule has deterministic coverage.
2. Wire the new handlers into `test-fixtures/subgraph.yaml` (and `test-fixtures/tsconfig.json` if needed) so the CLI analyzes them.
3. If the check relies on schema metadata, update `test-fixtures/schema.graphql` / `test-fixtures/src/entities.ts` accordingly.
4. Document the scenario in `test-fixtures/README.md` so future changes know why the fixture exists.

## 3. Refresh Expected Issues
1. Run `node dist/index.js --tsconfig test-fixtures/tsconfig.json --manifest test-fixtures/subgraph.yaml` to inspect the current output.
2. Update `test-fixtures/expected-issues.json` to include the new positives (and remove any that should disappear).
3. Run `npm run verify:fixtures`. This script captures the analyzer output, compares it with `expected-issues.json`, and fails if anything diverges. Keep running it until it prints `Fixture verification passed (...)`.

## 4. Communicate the Change
1. Mention the new check in `README.md` (What checks exist? How to enable/disable them?).
2. If the design should be tracked long-term, update `UNEXPECTED_NULL_CHECK_PLAN.md` or the relevant architecture proposal with rationale and progress.

## 5. Final Validation
1. Re-run `npm run build` so `dist/` reflects your changes.
2. Run `npm run check -- --manifest <real-subgraph> --tsconfig <tsconfig>` if you have a target project to ensure no unexpected failures leak through.

By following these steps every check remains plug-and-play: the runner stays clean, fixtures remain authoritative, and `npm run verify:fixtures` guards against regressions.
