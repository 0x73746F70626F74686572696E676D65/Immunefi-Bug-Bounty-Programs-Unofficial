# GRT Token Metadata

Token metadata repository for The Graph (GRT) enabling cross-chain integrations.

## Overview

This repository contains the official metadata and assets for The Graph (GRT) token.

## Repository Structure

```
├── metadata/
│   └── metadata.json    # Token metadata for GRT
├── assets/
│   └── logo.svg         # Official GRT Token logo
```

## Token Metadata

The token metadata includes:
- **Name**: Graph Token
- **Symbol**: GRT
- **Description**: The Graph is an indexing protocol for organizing and accessing data from blockchains and storage networks
- **Logo**: Official GRT logo in SVG format

## Usage

The metadata is available at:
- Metadata JSON: https://raw.githubusercontent.com/graphprotocol/GRT-Token-Metadata/main/metadata/metadata.json
- Logo: https://raw.githubusercontent.com/graphprotocol/GRT-Token-Metadata/main/assets/logo.svg

## License

MIT License - see LICENSE file for details.
