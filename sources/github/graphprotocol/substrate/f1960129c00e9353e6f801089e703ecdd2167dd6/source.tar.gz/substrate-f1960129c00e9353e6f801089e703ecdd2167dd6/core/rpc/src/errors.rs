// Copyright 2018 Parity Technologies (UK) Ltd.
// This file is part of Substrate.

// Substrate is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Substrate is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with Substrate.  If not, see <http://www.gnu.org/licenses/>.

use rpc;

pub fn unimplemented() -> rpc::Error {
	rpc::Error {
		code: rpc::ErrorCode::ServerError(1),
		message: "Not implemented yet".into(),
		data: None,
	}
}

pub fn internal<E: ::std::fmt::Debug>(e: E) -> rpc::Error {
	warn!("Unknown error: {:?}", e);
	rpc::Error {
		code: rpc::ErrorCode::InternalError,
		message: "Unknown error occured".into(),
		data: Some(format!("{:?}", e).into()),
	}
}
