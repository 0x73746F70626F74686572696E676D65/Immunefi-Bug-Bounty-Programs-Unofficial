import { BlockNumberService } from "@ebo-agent/blocknumber";
import { Caip2ChainId, EBO_SUPPORTED_CHAIN_IDS, UnixTimestamp } from "@ebo-agent/shared";
import {
    Address,
    createPublicClient,
    createWalletClient,
    decodeEventLog,
    fallback,
    GetBlockReturnType,
    getContract,
    Hex,
    http,
    Log,
    TransactionReceipt,
} from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { arbitrum, arbitrumSepolia, mainnet, sepolia } from "viem/chains";
import { afterEach, beforeEach, describe, expect, it, Mock, vi } from "vitest";

import { eboAbi, epochManagerV2Abi } from "../../src/abis/index.js";
import {
    BlockNumberServiceRequiredError,
    FetchAvailableChainsError,
    InvalidBlockHashError,
    RpcUrlsEmpty,
    TransactionExecutionError,
} from "../../src/exceptions/index.js";
import { ProtocolContractsAddressesV2 } from "../../src/interfaces/protocolProviderV2.interface.js";
import { ProtocolProviderV2 } from "../../src/providers/protocolProviderV2.js";
import { EboEventDataV2, EboEventV2 } from "../../src/types/eventsV2.types.js";
import { ProposalId } from "../../src/types/index.js";
import { mockLogger } from "../mocks/logger.mocks.js";

vi.mock("viem", async () => {
    const actual = await vi.importActual("viem");
    return {
        ...actual,
        http: vi.fn((url, options) => ({ url, ...options })),
        fallback: vi.fn((transports) => transports),
        createPublicClient: vi.fn(),
        createWalletClient: vi.fn(),
        getContract: vi.fn(),
        decodeEventLog: vi.fn(),
    };
});

vi.mock("viem/accounts", async () => {
    const actual = await vi.importActual<typeof import("viem/accounts")>("viem/accounts");
    return {
        ...actual,
        privateKeyToAccount: vi.fn(),
    };
});

describe("ProtocolProviderV2", () => {
    const mockedPrivateKey: Hex =
        "0x5c1ef825533283fe656537944d0075c3857cc1880f4aa86b743ba9180d1db241";
    const mockDerivedAddress: Address = "0xd133BBBC4aa80F365A2595Fe10B84a3Aff0a0ac1";

    const mockRpcConfigBase = {
        l1: {
            chainId: "eip155:1" as Caip2ChainId,
            urls: ["http://localhost:8545"],
            retryInterval: 1,
            timeout: 100,
            transactionReceiptConfirmations: 1,
        },
        l2: {
            chainId: "eip155:42161" as Caip2ChainId,
            urls: ["http://localhost:8546"],
            retryInterval: 1,
            timeout: 100,
            transactionReceiptConfirmations: 1,
        },
    };

    const mockContracts: ProtocolContractsAddressesV2 = {
        ebo: "0x1234567890123456789012345678901234567890" as Address,
        epochManager: "0x2345678901234567890123456789012345678901" as Address,
    };

    const mockBlockNumberService = {
        getEpochBlockNumber: vi.fn().mockResolvedValue(100n),
    } as unknown as BlockNumberService;

    beforeEach(() => {
        vi.resetModules();
        vi.clearAllMocks();

        // Mock getContract
        (getContract as Mock).mockImplementation(({ address, abi }) => {
            if (abi === eboAbi && address === mockContracts.ebo) {
                return {
                    address,
                    read: {
                        proposals: vi.fn(),
                        disputes: vi.fn(),
                        parametersSnapshots: vi.fn(),
                        activeProposal: vi.fn(),
                        chainIdsAllowed: vi.fn(),
                    },
                };
            }
            if (abi === epochManagerV2Abi && address === mockContracts.epochManager) {
                return {
                    address,
                    read: {
                        currentEpoch: vi.fn(),
                        currentEpochBlock: vi.fn(),
                    },
                };
            }
            throw new Error("Invalid contract address or ABI");
        });

        // Mock createPublicClient
        (createPublicClient as Mock).mockImplementation(() => ({
            simulateContract: vi.fn().mockImplementation(({ functionName, args }) => {
                return Promise.resolve({
                    request: {
                        functionName,
                        args,
                    },
                });
            }),
            getBlock: vi.fn().mockResolvedValue({ timestamp: 1697530555n }),
            waitForTransactionReceipt: vi.fn().mockResolvedValue({ status: "success" }),
            getContractEvents: vi.fn(),
            getLogs: vi.fn(),
        }));

        // Mock privateKeyToAccount
        (privateKeyToAccount as Mock).mockReturnValue({
            address: mockDerivedAddress,
            publicKey: "0xPublicKey",
            signMessage: vi.fn(),
            signTransaction: vi.fn(),
            signTypedData: vi.fn(),
            source: "privateKey",
            type: "local",
        });

        // Mock createWalletClient
        (createWalletClient as Mock).mockReturnValue({
            writeContract: vi.fn().mockResolvedValue("0xmockedTransactionHash"),
            account: privateKeyToAccount(mockedPrivateKey),
        });

        // Mock http and fallback
        (http as Mock).mockImplementation((url) => url);
        (fallback as Mock).mockImplementation((transports) => transports);
    });

    afterEach(() => {
        vi.restoreAllMocks();
    });

    describe("constructor", () => {
        it("creates a new ProtocolProviderV2 instance successfully", () => {
            void new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            expect(createPublicClient).toHaveBeenCalledWith(
                expect.objectContaining({
                    chain: arbitrum,
                    transport: expect.any(Array),
                }),
            );

            expect(createWalletClient).toHaveBeenCalledWith(
                expect.objectContaining({
                    chain: arbitrum,
                    transport: expect.any(Array),
                    account: expect.objectContaining({
                        address: expect.any(String),
                    }),
                }),
            );

            expect(getContract).toHaveBeenCalledWith(
                expect.objectContaining({
                    address: mockContracts.ebo,
                    abi: eboAbi,
                }),
            );

            expect(getContract).toHaveBeenCalledWith(
                expect.objectContaining({
                    address: mockContracts.epochManager,
                    abi: epochManagerV2Abi,
                }),
            );
        });

        it("throws if L1 rpcUrls are empty", () => {
            expect(
                () =>
                    new ProtocolProviderV2(
                        { ...mockRpcConfigBase, l1: { ...mockRpcConfigBase.l1, urls: [] } },
                        mockContracts,
                        mockedPrivateKey,

                        mockLogger(),
                        mockBlockNumberService,
                    ),
            ).toThrowError(RpcUrlsEmpty);
        });

        it("throws if L2 rpcUrls are empty", () => {
            expect(
                () =>
                    new ProtocolProviderV2(
                        { ...mockRpcConfigBase, l2: { ...mockRpcConfigBase.l2, urls: [] } },
                        mockContracts,
                        mockedPrivateKey,

                        mockLogger(),
                        mockBlockNumberService,
                    ),
            ).toThrowError(RpcUrlsEmpty);
        });
    });

    describe("getCurrentEpoch", () => {
        it("returns currentEpoch, firstBlockNumber, and startTimestamp successfully", async () => {
            const mockEpoch = BigInt(1);
            const mockEpochBlock_L1 = BigInt(12345);
            const mockEpochBlock_L2 = BigInt(67890);
            const mockEpochTimestamp = BigInt(Date.UTC(2024, 1, 1, 0, 0, 0, 0)) / 1000n;

            const mockBlockNumberService = {
                getEpochBlockNumber: vi.fn().mockResolvedValue(mockEpochBlock_L2),
            } as unknown as BlockNumberService;

            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            vi.spyOn(
                protocolProvider["epochManagerContract"].read,
                "currentEpoch",
            ).mockResolvedValue(mockEpoch);
            vi.spyOn(
                protocolProvider["epochManagerContract"].read,
                "currentEpochBlock",
            ).mockResolvedValue(mockEpochBlock_L1);
            vi.spyOn(protocolProvider["l1ReadClient"], "getBlock").mockResolvedValue({
                timestamp: mockEpochTimestamp,
            } as GetBlockReturnType);

            const result = await protocolProvider.read.getCurrentEpoch();

            expect(result.number).toBe(mockEpoch);
            expect(result.firstBlockNumber).toBe(mockEpochBlock_L2);
            expect(result.startTimestamp).toBe(mockEpochTimestamp);

            expect(mockBlockNumberService.getEpochBlockNumber).toHaveBeenCalledWith(
                mockEpochTimestamp,
                mockRpcConfigBase.l2.chainId,
            );
        });

        it("throws BlockNumberServiceRequiredError when blockNumberService is not provided", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                undefined,
            );

            await expect(protocolProvider.read.getCurrentEpoch()).rejects.toThrow(
                BlockNumberServiceRequiredError,
            );
        });

        it("throws when current epoch request fails", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );
            const error = new Error("Failed to get current epoch");
            const mockEpochBlock = BigInt(12345);

            vi.spyOn(
                protocolProvider["epochManagerContract"].read,
                "currentEpoch",
            ).mockRejectedValue(error);
            vi.spyOn(
                protocolProvider["epochManagerContract"].read,
                "currentEpochBlock",
            ).mockResolvedValue(mockEpochBlock);

            await expect(protocolProvider.read.getCurrentEpoch()).rejects.toThrow(error);
        });
    });

    describe("getLastFinalizedBlock", () => {
        it("returns the last finalized block", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const mockBlock = {
                number: 123n,
                hash: "0xabcdef",
                timestamp: 1697530555n,
            } as unknown as GetBlockReturnType;
            vi.spyOn(protocolProvider["l2ReadClient"], "getBlock").mockResolvedValue(mockBlock);

            const result = await protocolProvider.read.getLastFinalizedBlock();

            expect(result).toEqual(mockBlock);
            expect(protocolProvider["l2ReadClient"].getBlock).toHaveBeenCalledWith({
                blockTag: "finalized",
            });
        });
    });

    describe("getEvents", () => {
        it("fetches and merges events successfully", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            // Create mock events for different event types
            const mockProposalCreatedEvent = {
                eventName: "ProposalCreated",
                blockNumber: 1n,
                logIndex: 0,
                blockHash: "0xabcdef" as Hex,
                address: mockContracts.ebo,
                data: "0x" as Hex,
                transactionHash: "0x123456" as Hex,
                transactionIndex: 0,
                removed: false,
                topics: ["0x1234567890123456789012345678901234567890"],
                args: {
                    _proposalId: 123n,
                    _epoch: 1n,
                    _chainId: "eip155:1",
                    _blockNumber: 100n,
                    _serviceProvider: "0x3456789012345678901234567890123456789012" as Address,
                },
            } as unknown as Log;

            const mockProposalDisputedEvent = {
                eventName: "ProposalDisputed",
                blockNumber: 2n,
                logIndex: 1,
                blockHash: "0xabcdef" as Hex,
                address: mockContracts.ebo,
                data: "0x" as Hex,
                transactionHash: "0x123456" as Hex,
                transactionIndex: 0,
                removed: false,
                topics: ["0x1234567890123456789012345678901234567890"],
                args: {
                    _proposalId: 123n,
                },
            } as unknown as Log;

            const mockProposalFinalizedEvent = {
                eventName: "ProposalFinalized",
                blockNumber: 3n,
                logIndex: 0,
                blockHash: "0xabcdef" as Hex,
                address: mockContracts.ebo,
                data: "0x" as Hex,
                transactionHash: "0x123456" as Hex,
                transactionIndex: 0,
                topics: ["0x1234567890123456789012345678901234567890"],
                removed: false,
                args: {
                    _proposalId: 456n,
                    _epoch: 1n,
                    _chainId: "eip155:1",
                    _blockNumber: 200n,
                },
            } as unknown as Log;

            const mockRawLogs = [
                mockProposalCreatedEvent,
                mockProposalDisputedEvent,
                mockProposalFinalizedEvent,
            ];

            // Create the decoded events that decodeEventLogs should return
            const mockProposalCreatedDecoded = {
                ...mockRawLogs[0],
                eventName: "ProposalCreated",
                args: {
                    _proposalId: 123n,
                    _epoch: 1n,
                    _chainId: "eip155:1",
                    _blockNumber: 100n,
                    _serviceProvider: "0x3456789012345678901234567890123456789012" as Address,
                },
            };

            const mockProposalDisputedDecoded = {
                ...mockRawLogs[1],
                eventName: "ProposalDisputed",
                args: {
                    _proposalId: 123n,
                },
            };

            const mockProposalFinalizedDecoded = {
                ...mockRawLogs[2],
                eventName: "ProposalFinalized",
                args: {
                    _proposalId: 456n,
                    _epoch: 1n,
                    _chainId: "eip155:1",
                    _blockNumber: 200n,
                },
            };

            // Mock the getBlock method to return a timestamp
            vi.spyOn(protocolProvider["l2ReadClient"], "getBlock").mockResolvedValue({
                timestamp: 1697530555n,
            } as unknown as GetBlockReturnType);

            // Mock the getLogs method to return different events based on eventName
            vi.spyOn(protocolProvider["l2ReadClient"], "getLogs").mockResolvedValue([
                mockProposalDisputedEvent,
                mockProposalCreatedEvent,
                mockProposalFinalizedEvent,
            ]);

            // Mock decodeEventLogs to return our decoded events
            (decodeEventLog as Mock).mockImplementation(({ eventName }) => {
                if (eventName === "ProposalDisputed") return mockProposalDisputedDecoded;
                if (eventName === "ProposalCreated") return mockProposalCreatedDecoded;
                if (eventName === "ProposalFinalized") return mockProposalFinalizedDecoded;
            });

            const result = await protocolProvider.read.getEvents(0n, 100n);

            // Verify the result contains all events sorted by blockNumber and logIndex
            expect(result).toHaveLength(3);

            // Check that events are properly sorted and transformed
            expect(result[0]?.name).toBe("ProposalCreated");
            expect(result[0]?.blockNumber).toBe(1n);
            expect(result[0]?.logIndex).toBe(0);
            expect(result[0]?.proposalId).toBe(123n);

            expect(result[1]?.name).toBe("ProposalDisputed");
            expect(result[1]?.blockNumber).toBe(2n);
            expect(result[1]?.logIndex).toBe(1);
            expect(result[1]?.proposalId).toBe(123n);

            expect(result[2]?.name).toBe("ProposalFinalized");
            expect(result[2]?.blockNumber).toBe(3n);
            expect(result[2]?.logIndex).toBe(0);
            expect(result[2]?.proposalId).toBe(456n);
        });

        it("throws when from block is greater than to block", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            await expect(protocolProvider.read.getEvents(100n, 50n)).rejects.toThrow(
                "Invalid block range: fromBlock (100) must be less than or equal to toBlock (50)",
            );
        });
    });

    describe("getAvailableChains", () => {
        it("returns an array of allowed chains", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            // Mock the chainIdsAllowed method to return true for certain chains
            vi.spyOn(protocolProvider["eboContract"].read, "chainIdsAllowed").mockImplementation(
                ([chainId]) => {
                    if (
                        ["eip155:1", "eip155:42161", "eip155:11155111", "eip155:421614"].includes(
                            chainId,
                        )
                    )
                        return Promise.resolve(true);
                    return Promise.resolve(false);
                },
            );

            const result = await protocolProvider.read.getAvailableChains();

            expect(result).toContainEqual("eip155:1");
            expect(result).toContainEqual("eip155:42161");
            expect(result).toContainEqual("eip155:11155111");
            expect(result).toContainEqual("eip155:421614");
            expect(protocolProvider["eboContract"].read.chainIdsAllowed).toHaveBeenCalledTimes(
                EBO_SUPPORTED_CHAIN_IDS.length,
            );
        });

        it("uses multicall3 when available", async () => {
            // Mock createPublicClient
            (createPublicClient as Mock).mockImplementation(() => ({
                simulateContract: vi.fn().mockImplementation(({ functionName, args }) => {
                    return Promise.resolve({
                        request: {
                            functionName,
                            args,
                        },
                    });
                }),
                getBlock: vi.fn().mockResolvedValue({ timestamp: 1697530555n }),
                waitForTransactionReceipt: vi.fn().mockResolvedValue({ status: "success" }),
                getContractEvents: vi.fn(),
                chain: {
                    contracts: {
                        multicall3: {
                            address: "0x1234567890123456789012345678901234567890" as Address,
                        },
                    },
                },
                multicall: vi.fn(),
            }));
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,
                mockLogger(),
                mockBlockNumberService,
            );

            // Mock the multicall method to return predefined results
            vi.spyOn(protocolProvider["l2ReadClient"], "multicall").mockImplementation(() => {
                const results = [];
                for (const contract of EBO_SUPPORTED_CHAIN_IDS) {
                    if (
                        ["eip155:1", "eip155:42161", "eip155:11155111", "eip155:421614"].includes(
                            contract,
                        )
                    ) {
                        results.push(true);
                    } else {
                        results.push(false);
                    }
                }
                return Promise.resolve(results);
            });

            const result = await protocolProvider.read.getAvailableChains();

            expect(protocolProvider["l2ReadClient"].multicall).toHaveBeenCalledWith({
                allowFailure: false,
                contracts: EBO_SUPPORTED_CHAIN_IDS.map(
                    (chainId) =>
                        ({
                            abi: eboAbi,
                            address: mockContracts.ebo,
                            functionName: "chainIdsAllowed",
                            args: [chainId],
                        }) as const,
                ),
            });

            expect(result).toContainEqual("eip155:1");
            expect(result).toContainEqual("eip155:42161");
            expect(result).toContainEqual("eip155:11155111");
            expect(result).toContainEqual("eip155:421614");

            // Verify that individual chainIdsAllowed calls were not made
            expect(protocolProvider["eboContract"].read.chainIdsAllowed).not.toHaveBeenCalled();
        });

        it("falls back to individual calls when multicall3 fails", async () => {
            (createPublicClient as Mock).mockImplementation(() => ({
                simulateContract: vi.fn().mockImplementation(({ functionName, args }) => {
                    return Promise.resolve({
                        request: {
                            functionName,
                            args,
                        },
                    });
                }),
                getBlock: vi.fn().mockResolvedValue({ timestamp: 1697530555n }),
                waitForTransactionReceipt: vi.fn().mockResolvedValue({ status: "success" }),
                getContractEvents: vi.fn(),
                chain: {
                    contracts: {
                        multicall3: {
                            address: "0x1234567890123456789012345678901234567890" as Address,
                        },
                    },
                },
                multicall: vi.fn(),
            }));

            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,
                mockLogger(),
                mockBlockNumberService,
            );

            // Mock the chain to include multicall3 contract
            Object.defineProperty(protocolProvider["l2ReadClient"], "chain", {
                value: {
                    contracts: {
                        multicall3: {
                            address: "0x1234567890123456789012345678901234567890" as Address,
                        },
                    },
                },
                configurable: true,
            });

            // Mock multicall to throw an error
            vi.spyOn(protocolProvider["l2ReadClient"], "multicall").mockRejectedValue(
                new Error("Multicall failed"),
            );

            // Mock individual chainIdsAllowed calls
            vi.spyOn(protocolProvider["eboContract"].read, "chainIdsAllowed").mockImplementation(
                ([chainId]) => {
                    if (["eip155:1", "eip155:42161", "eip155:11155111"].includes(chainId))
                        return Promise.resolve(true);
                    return Promise.resolve(false);
                },
            );

            // This should throw FetchAvailableChainsError
            await expect(protocolProvider.read.getAvailableChains()).rejects.toThrow(
                FetchAvailableChainsError,
            );

            // Verify that multicall was attempted
            expect(protocolProvider["l2ReadClient"].multicall).toHaveBeenCalled();
        });

        it("throws FetchAvailableChainsError when the call fails", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            vi.spyOn(protocolProvider["eboContract"].read, "chainIdsAllowed").mockRejectedValue(
                new Error("RPC error"),
            );

            await expect(protocolProvider.read.getAvailableChains()).rejects.toThrow(
                FetchAvailableChainsError,
            );
        });
    });

    describe("getProposalById", () => {
        it("returns a proposal by ID", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const mockProposal = [
                1n, // epoch
                "eip155:1", // chainId
                100n, // blockNumber
                "0x3456789012345678901234567890123456789012" as Address, // proposer
                1697530555n, // createdAt
                1n, // parametersSnapshotId
                0, // status
            ] as const;

            vi.spyOn(protocolProvider["eboContract"].read, "proposals").mockResolvedValue(
                mockProposal,
            );

            const result = await protocolProvider.read.getProposalById(1n as ProposalId);

            expect(result).toEqual({
                id: 1n,
                epoch: 1n,
                chainId: "eip155:1",
                blockNumber: 100n,
                proposer: "0x3456789012345678901234567890123456789012",
                createdAt: 1697530555n,
                parametersSnapshotId: 1n,
                status: 0,
            });
            expect(protocolProvider["eboContract"].read.proposals).toHaveBeenCalledWith([1n]);
        });

        it("returns undefined when proposal matches NULL_PROPOSAL", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,
                mockLogger(),
                mockBlockNumberService,
            );

            const mockNullProposal = [
                0n, // epoch
                "", // chainId
                0n, // blockNumber
                "0x0000000000000000000000000000000000000000" as Address, // proposer
                0n, // createdAt
                0n, // parametersSnapshotId
                0, // status
            ] as const;

            vi.spyOn(protocolProvider["eboContract"].read, "proposals").mockResolvedValue(
                mockNullProposal,
            );

            const result = await protocolProvider.read.getProposalById(1n as ProposalId);
            expect(result).toBeUndefined();
        });
    });

    describe("getDisputeByProposalId", () => {
        it("returns a dispute by proposal ID", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const mockDispute = [
                "0x4567890123456789012345678901234567890123" as Address, // disputer
                1697530555n, // createdAt
                1697530655n, // lastPledgeTimestamp
                100n, // totalPledgesForDispute
                50n, // totalPledgesAgainstDispute
                10n, // rewardPerWinningPledge
            ] as const;

            vi.spyOn(protocolProvider["eboContract"].read, "disputes").mockResolvedValue(
                mockDispute,
            );

            const result = await protocolProvider.read.getDisputeByProposalId(1n as ProposalId);

            expect(result).toEqual({
                disputer: "0x4567890123456789012345678901234567890123",
                createdAt: 1697530555n,
                lastPledgeTimestamp: 1697530655n,
                totalPledgesForDispute: 100n,
                totalPledgesAgainstDispute: 50n,
                rewardPerWinningPledge: 10n,
            });
            expect(protocolProvider["eboContract"].read.disputes).toHaveBeenCalledWith([1n]);
        });

        it("returns undefined when dispute matches NULL_DISPUTE", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,
                mockLogger(),
                mockBlockNumberService,
            );

            const mockNullDispute = [
                "0x0000000000000000000000000000000000000000" as Address, // disputer
                0n, // createdAt
                0n, // lastPledgeTimestamp
                0n, // totalPledgesForDispute
                0n, // totalPledgesAgainstDispute
                0n, // rewardPerWinningPledge
            ] as const;

            vi.spyOn(protocolProvider["eboContract"].read, "disputes").mockResolvedValue(
                mockNullDispute,
            );

            const result = await protocolProvider.read.getDisputeByProposalId(1n as ProposalId);
            expect(result).toBeUndefined();
        });
    });

    describe("getSnapshotParameters", () => {
        it("returns snapshot parameters by ID", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const mockParameters = [
                100n, // proposalBondSize
                50n, // pledgeBondSize
                3600n, // minThawingPeriod
                7200n, // disputeWindow
                3600n, // pledgeWindow
                1800n, // pledgeRefreshWindow
                10n, // maxNumberOfPledges
            ] as const;

            vi.spyOn(protocolProvider["eboContract"].read, "parametersSnapshots").mockResolvedValue(
                mockParameters,
            );

            const result = await protocolProvider.read.getSnapshotParameters(1n);

            expect(result).toEqual({
                proposalBondSize: 100n,
                pledgeBondSize: 50n,
                minThawingPeriod: 3600n,
                disputeWindow: 7200n,
                pledgeWindow: 3600n,
                pledgeRefreshWindow: 1800n,
                maxNumberOfPledges: 10n,
            });
            expect(protocolProvider["eboContract"].read.parametersSnapshots).toHaveBeenCalledWith([
                1n,
            ]);
        });

        it("returns undefined when parameters match NULL_SNAPSHOT_PARAMETERS", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,
                mockLogger(),
                mockBlockNumberService,
            );

            const mockNullParameters = [
                0n, // proposalBondSize
                0n, // pledgeBondSize
                0n, // minThawingPeriod
                0n, // disputeWindow
                0n, // pledgeWindow
                0n, // pledgeRefreshWindow
                0n, // maxNumberOfPledges
            ] as const;

            vi.spyOn(protocolProvider["eboContract"].read, "parametersSnapshots").mockResolvedValue(
                mockNullParameters,
            );

            const result = await protocolProvider.read.getSnapshotParameters(1n);
            expect(result).toBeUndefined();
        });
    });

    describe("getActiveProposal", () => {
        it("returns the active proposal for an epoch and chain ID", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const mockProposalId = 1n;
            const mockProposal = [
                1n, // epoch
                "eip155:1", // chainId
                100n, // blockNumber
                "0x3456789012345678901234567890123456789012" as Address, // proposer
                1697530555n, // createdAt
                1n, // parametersSnapshotId
                0, // status
            ] as const;

            vi.spyOn(protocolProvider["eboContract"].read, "activeProposal").mockResolvedValue(
                mockProposalId,
            );
            vi.spyOn(protocolProvider["eboContract"].read, "proposals").mockResolvedValue(
                mockProposal,
            );

            const result = await protocolProvider.read.getActiveProposal(1n, "eip155:1");

            expect(result).toEqual({
                id: 1n,
                epoch: 1n,
                chainId: "eip155:1",
                blockNumber: 100n,
                proposer: "0x3456789012345678901234567890123456789012",
                createdAt: 1697530555n,
                parametersSnapshotId: 1n,
                status: 0,
            });
            expect(protocolProvider["eboContract"].read.activeProposal).toHaveBeenCalledWith([
                1n,
                "eip155:1",
            ]);
            expect(protocolProvider["eboContract"].read.proposals).toHaveBeenCalledWith([
                mockProposalId,
            ]);
        });

        it("returns undefined when active proposal matches NULL_PROPOSAL", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,
                mockLogger(),
                mockBlockNumberService,
            );

            const mockProposalId = 1n;
            const mockNullProposal = [
                0n, // epoch
                "", // chainId
                0n, // blockNumber
                "0x0000000000000000000000000000000000000000" as Address, // proposer
                0n, // createdAt
                0n, // parametersSnapshotId
                0, // status
            ] as const;

            vi.spyOn(protocolProvider["eboContract"].read, "activeProposal").mockResolvedValue(
                mockProposalId,
            );
            vi.spyOn(protocolProvider["eboContract"].read, "proposals").mockResolvedValue(
                mockNullProposal,
            );

            const result = await protocolProvider.read.getActiveProposal(1n, "eip155:1");
            expect(result).toBeUndefined();
        });
    });

    describe("propose", () => {
        it("successfully proposes", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const epoch = 1n;
            const chainId = "eip155:1";
            const blockNumber = 100n;
            const serviceProvider = "0x5678901234567890123456789012345678901234" as Address;

            await protocolProvider.write.propose(epoch, chainId, blockNumber, serviceProvider);

            expect(protocolProvider["l2ReadClient"].simulateContract).toHaveBeenCalledWith({
                address: mockContracts.ebo,
                abi: eboAbi,
                functionName: "propose",
                args: [epoch, chainId, blockNumber, serviceProvider],
                account: expect.any(Object),
            });

            expect(protocolProvider["l2WriteClient"].writeContract).toHaveBeenCalled();
            expect(protocolProvider["l2ReadClient"].waitForTransactionReceipt).toHaveBeenCalled();
        });

        it("throws TransactionExecutionError when transaction fails", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            vi.spyOn(
                protocolProvider["l2ReadClient"],
                "waitForTransactionReceipt",
            ).mockResolvedValue({
                status: "reverted",
            } as unknown as TransactionReceipt);

            const epoch = 1n;
            const chainId = "eip155:1";
            const blockNumber = 100n;
            const serviceProvider = "0x5678901234567890123456789012345678901234" as Address;

            await expect(
                protocolProvider.write.propose(epoch, chainId, blockNumber, serviceProvider),
            ).rejects.toThrow(TransactionExecutionError);
        });

        it("handles ContractFunctionRevertedError", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const revertError = new Error("Contract function reverted");
            revertError.name = "ContractFunctionRevertedError";

            vi.spyOn(protocolProvider["l2ReadClient"], "simulateContract").mockRejectedValue(
                revertError,
            );

            const epoch = 1n;
            const chainId = "eip155:1";
            const blockNumber = 100n;
            const serviceProvider = "0x5678901234567890123456789012345678901234" as Address;

            await expect(
                protocolProvider.write.propose(epoch, chainId, blockNumber, serviceProvider),
            ).rejects.toThrow("Contract function reverted");
        });
    });

    describe("dispute", () => {
        it("successfully disputes a proposal", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const proposalId = 1n as ProposalId;
            const serviceProvider = "0x5678901234567890123456789012345678901234" as Address;

            await protocolProvider.write.dispute(proposalId, serviceProvider);

            expect(protocolProvider["l2ReadClient"].simulateContract).toHaveBeenCalledWith({
                address: mockContracts.ebo,
                abi: eboAbi,
                functionName: "dispute",
                args: [proposalId, serviceProvider],
                account: expect.any(Object),
            });

            expect(protocolProvider["l2WriteClient"].writeContract).toHaveBeenCalled();
            expect(protocolProvider["l2ReadClient"].waitForTransactionReceipt).toHaveBeenCalled();
        });

        it("throws TransactionExecutionError when transaction fails", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            vi.spyOn(
                protocolProvider["l2ReadClient"],
                "waitForTransactionReceipt",
            ).mockResolvedValue({
                status: "reverted",
            } as unknown as TransactionReceipt);

            const proposalId = 1n as ProposalId;
            const serviceProvider = "0x5678901234567890123456789012345678901234" as Address;

            await expect(
                protocolProvider.write.dispute(proposalId, serviceProvider),
            ).rejects.toThrow(TransactionExecutionError);
        });
    });

    describe("resolve", () => {
        it("successfully resolves a dispute", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const proposalId = 1n as ProposalId;

            await protocolProvider.write.resolve(proposalId);

            expect(protocolProvider["l2ReadClient"].simulateContract).toHaveBeenCalledWith({
                address: mockContracts.ebo,
                abi: eboAbi,
                functionName: "resolve",
                args: [proposalId],
                account: expect.any(Object),
            });

            expect(protocolProvider["l2WriteClient"].writeContract).toHaveBeenCalled();
            expect(protocolProvider["l2ReadClient"].waitForTransactionReceipt).toHaveBeenCalled();
        });

        it("throws TransactionExecutionError when transaction fails", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            vi.spyOn(
                protocolProvider["l2ReadClient"],
                "waitForTransactionReceipt",
            ).mockResolvedValue({
                status: "reverted",
            } as unknown as TransactionReceipt);

            const proposalId = 1n as ProposalId;

            await expect(protocolProvider.write.resolve(proposalId)).rejects.toThrow(
                TransactionExecutionError,
            );
        });
    });

    describe("finalize", () => {
        it("successfully finalizes a proposal", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const proposalId = 1n as ProposalId;

            await protocolProvider.write.finalize(proposalId);

            expect(protocolProvider["l2ReadClient"].simulateContract).toHaveBeenCalledWith({
                address: mockContracts.ebo,
                abi: eboAbi,
                functionName: "finalize",
                args: [proposalId],
                account: expect.any(Object),
            });

            expect(protocolProvider["l2WriteClient"].writeContract).toHaveBeenCalled();
            expect(protocolProvider["l2ReadClient"].waitForTransactionReceipt).toHaveBeenCalled();
        });

        it("throws TransactionExecutionError when transaction fails", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            vi.spyOn(
                protocolProvider["l2ReadClient"],
                "waitForTransactionReceipt",
            ).mockResolvedValue({
                status: "reverted",
            } as unknown as TransactionReceipt);

            const proposalId = 1n as ProposalId;

            await expect(protocolProvider.write.finalize(proposalId)).rejects.toThrow(
                TransactionExecutionError,
            );
        });
    });

    describe("pledgeForDispute", () => {
        it("successfully pledges for a dispute", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const proposalId = 1n as ProposalId;
            const serviceProvider = "0xServiceProvider" as Address;

            await protocolProvider.write.pledgeForDispute(proposalId, serviceProvider);

            expect(protocolProvider["l2ReadClient"].simulateContract).toHaveBeenCalledWith({
                address: mockContracts.ebo,
                abi: eboAbi,
                functionName: "pledgeForDispute",
                args: [proposalId, serviceProvider],
                account: expect.any(Object),
            });

            expect(protocolProvider["l2WriteClient"].writeContract).toHaveBeenCalled();
            expect(protocolProvider["l2ReadClient"].waitForTransactionReceipt).toHaveBeenCalled();
        });

        it("throws TransactionExecutionError when transaction fails", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            vi.spyOn(
                protocolProvider["l2ReadClient"],
                "waitForTransactionReceipt",
            ).mockResolvedValue({
                status: "reverted",
            } as unknown as TransactionReceipt);

            const proposalId = 1n as ProposalId;
            const serviceProvider = "0xServiceProvider" as Address;

            await expect(
                protocolProvider.write.pledgeForDispute(proposalId, serviceProvider),
            ).rejects.toThrow(TransactionExecutionError);
        });
    });

    describe("pledgeAgainstDispute", () => {
        it("successfully pledges against a dispute", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const proposalId = 1n as ProposalId;
            const serviceProvider = "0xServiceProvider" as Address;

            await protocolProvider.write.pledgeAgainstDispute(proposalId, serviceProvider);

            expect(protocolProvider["l2ReadClient"].simulateContract).toHaveBeenCalledWith({
                address: mockContracts.ebo,
                abi: eboAbi,
                functionName: "pledgeAgainstDispute",
                args: [proposalId, serviceProvider],
                account: expect.any(Object),
            });

            expect(protocolProvider["l2WriteClient"].writeContract).toHaveBeenCalled();
            expect(protocolProvider["l2ReadClient"].waitForTransactionReceipt).toHaveBeenCalled();
        });

        it("throws TransactionExecutionError when transaction fails", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            vi.spyOn(
                protocolProvider["l2ReadClient"],
                "waitForTransactionReceipt",
            ).mockResolvedValue({
                status: "reverted",
            } as unknown as TransactionReceipt);

            const proposalId = 1n as ProposalId;
            const serviceProvider = "0xServiceProvider" as Address;

            await expect(
                protocolProvider.write.pledgeAgainstDispute(proposalId, serviceProvider),
            ).rejects.toThrow(TransactionExecutionError);
        });
    });

    describe("getAccountAddress", () => {
        it("returns the account address", () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            expect(protocolProvider.getAccountAddress()).toBe(mockDerivedAddress);
        });
    });

    describe("getViemChain", () => {
        it("returns the correct viem chain for mainnet", () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const result = protocolProvider["getViemChain"]("eip155:1");
            expect(result).toBe(mainnet);
        });

        it("returns the correct viem chain for sepolia", () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const result = protocolProvider["getViemChain"]("eip155:11155111");
            expect(result).toBe(sepolia);
        });

        it("returns the correct viem chain for arbitrum", () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const result = protocolProvider["getViemChain"]("eip155:42161");
            expect(result).toBe(arbitrum);
        });

        it("returns the correct viem chain for arbitrum sepolia", () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const result = protocolProvider["getViemChain"]("eip155:421614");
            expect(result).toBe(arbitrumSepolia);
        });

        it("throws UnsupportedChain for unsupported chains", () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            expect(() => protocolProvider["getViemChain"]("eip155:999999")).toThrow();
        });
    });

    describe("getEventTimestamp", () => {
        it("returns the timestamp for an event", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const mockEvent = {
                blockHash: "0xabcdef",
            } as unknown as Log;

            const mockBlock = {
                timestamp: 1697530555n,
            } as unknown as GetBlockReturnType;

            vi.spyOn(protocolProvider["l2ReadClient"], "getBlock").mockResolvedValue(mockBlock);

            const result = await protocolProvider["getEventTimestamp"](mockEvent);

            expect(result).toBe(1697530555n);
            expect(protocolProvider["l2ReadClient"].getBlock).toHaveBeenCalledWith({
                blockHash: "0xabcdef",
            });
        });

        it("throws InvalidBlockHashError when blockHash is null", async () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const mockEvent = {
                blockHash: null,
            } as unknown as Log;

            await expect(protocolProvider["getEventTimestamp"](mockEvent)).rejects.toThrow(
                InvalidBlockHashError,
            );
        });
    });

    describe("mergeEventStreams", () => {
        it("merges and sorts events by block number and log index", () => {
            const protocolProvider = new ProtocolProviderV2(
                mockRpcConfigBase,
                mockContracts,
                mockedPrivateKey,

                mockLogger(),
                mockBlockNumberService,
            );

            const events1: EboEventV2[] = [
                {
                    name: "ProposalCreated",
                    blockNumber: 2n,
                    logIndex: 1,
                    timestamp: 1697530555n as UnixTimestamp,
                    rawLog: {} as unknown as Log,
                    proposalId: 123n as ProposalId,
                    args: {} as EboEventDataV2<"ProposalCreated">,
                },
                {
                    name: "ProposalCreated",
                    blockNumber: 1n,
                    logIndex: 0,
                    timestamp: 1697530555n as UnixTimestamp,
                    rawLog: {} as unknown as Log,
                    proposalId: 456n as ProposalId,
                    args: {} as EboEventDataV2<"ProposalCreated">,
                },
            ];

            const events2: EboEventV2[] = [
                {
                    name: "ProposalDisputed",
                    blockNumber: 1n,
                    logIndex: 1,
                    timestamp: 1697530555n as UnixTimestamp,
                    rawLog: {} as unknown as Log,
                    proposalId: 123n as ProposalId,
                    args: {} as EboEventDataV2<"ProposalDisputed">,
                },
                {
                    name: "ProposalDisputed",
                    blockNumber: 3n,
                    logIndex: 0,
                    timestamp: 1697530555n as UnixTimestamp,
                    rawLog: {} as unknown as Log,
                    proposalId: 456n as ProposalId,
                    args: {} as EboEventDataV2<"ProposalDisputed">,
                },
            ];

            const result = protocolProvider["mergeEventStreams"](events1, events2);

            // Events should be sorted by block number, then log index
            expect(result[0]!.blockNumber).toBe(1n);
            expect(result[0]!.logIndex).toBe(0);
            expect(result[0]!.name).toBe("ProposalCreated");

            expect(result[1]!.blockNumber).toBe(1n);
            expect(result[1]!.logIndex).toBe(1);
            expect(result[1]!.name).toBe("ProposalDisputed");

            expect(result[2]!.blockNumber).toBe(2n);
            expect(result[2]!.logIndex).toBe(1);
            expect(result[2]!.name).toBe("ProposalCreated");

            expect(result[3]!.blockNumber).toBe(3n);
            expect(result[3]!.logIndex).toBe(0);
            expect(result[3]!.name).toBe("ProposalDisputed");
        });
    });
});
