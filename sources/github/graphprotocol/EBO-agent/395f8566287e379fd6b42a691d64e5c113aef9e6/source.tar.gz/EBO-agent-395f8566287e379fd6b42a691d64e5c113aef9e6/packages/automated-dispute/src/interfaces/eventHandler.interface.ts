import { EboEventV2 } from "../types/eventsV2.types.js";

export interface IEventHandler<Type extends EboEventV2["name"]> {
    run(event: Extract<EboEventV2, { name: Type }>): Promise<void>;
}
