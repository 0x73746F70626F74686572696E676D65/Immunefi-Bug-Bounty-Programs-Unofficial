import { EboEventV2 } from "../../types/index.js";
import { BaseEventHandler } from "./base.handler.js";

/**
 * @description Handles the ProposalFinalized event
 * @extends BaseEventHandler
 *
 * It logs the proposal id when it is finalized.
 */
export class ProposalFinalizedHandler extends BaseEventHandler<"ProposalFinalized"> {
    async run(event: Extract<EboEventV2, { name: "ProposalFinalized" }>): Promise<void> {
        this.logger.info(`Proposal ${event.args.proposalId} has been finalized.`, {
            proposalId: event.args.proposalId,
        });
    }
}
