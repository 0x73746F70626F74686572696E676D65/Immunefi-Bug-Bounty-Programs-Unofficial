import { isNativeError } from "util/types";
import type { APIEmbed, JSONEncodable } from "discord.js";
import { ILogger, IMessage, NotificationService, stringify } from "@ebo-agent/shared";
import { WebhookClient, WebhookMessageCreateOptions } from "discord.js";

import { NotificationFailureException } from "../exceptions/index.js";

export type WebhookMessage = WebhookMessageCreateOptions & {
    content: string;
};

/**
 * A notifier class for sending notifications to Discord via webhooks.
 */
export class DiscordNotifier implements NotificationService {
    private client: WebhookClient;

    /**
     * Creates an instance of DiscordNotifier.
     *
     * @param {string} url - The Discord webhook URL.
     * @param {ILogger} logger - An injected logger instance implementing ILogger.
     * @param {string} [defaultAvatarUrl] - The default avatar URL to use if none is provided.
     */
    constructor(
        url: string,
        private readonly logger: ILogger,
        private readonly defaultAvatarUrl?: string,
    ) {
        this.client = new WebhookClient({ url });
        this.defaultAvatarUrl = defaultAvatarUrl;
    }

    /**
     * Sends a notification message to Discord. Errors are logged but not thrown.
     *
     * @param {IMessage} message - The message to send.
     * @returns {Promise<void>} A promise that resolves when the message is sent.
     */
    async send(message: IMessage): Promise<void> {
        const webhookMessage = this.buildWebhookMessage(message);
        try {
            await this.client.send(webhookMessage);
        } catch (error) {
            this.logger.error(
                `Failed to send Discord notification: ${
                    error instanceof Error ? error.message : String(error)
                }`,
            );
        }
    }

    /**
     * Sends a notification message to Discord. Throws an exception if sending fails.
     *
     * @param {IMessage} message - The message to send.
     * @returns {Promise<void>} A promise that resolves when the message is sent.
     * @throws {NotificationFailureException} If sending the message fails.
     */
    async sendOrThrow(message: IMessage): Promise<void> {
        const webhookMessage = this.buildWebhookMessage(message);
        try {
            await this.client.send(webhookMessage);
        } catch (error) {
            throw new NotificationFailureException("An error occurred with the Discord client.");
        }
    }

    /**
     * Builds a Discord webhook message from the given IMessage.
     *
     * @param {IMessage} message - The message details.
     * @returns {WebhookMessage} The built Discord webhook message.
     */
    private buildWebhookMessage(message: IMessage): WebhookMessage {
        return {
            username: message.username || "EBO Agent",
            content: message.title,
            avatarURL: message.avatarUrl || this.defaultAvatarUrl,
            embeds:
                message.subtitle || message.description
                    ? [this.buildWebhookMessageEmbed(message)]
                    : undefined,
        } as WebhookMessage;
    }

    /**
     * Builds a Discord embed message from the given IMessage.
     *
     * @param {IMessage} message - The message details.
     * @returns {APIEmbed | JSONEncodable<APIEmbed>} The built Discord embed message.
     */
    private buildWebhookMessageEmbed(message: IMessage): APIEmbed | JSONEncodable<APIEmbed> {
        return {
            title: message.subtitle,
            description: message.description,
            color: 2326507,
            url: message.actionUrl,
        };
    }

    /**
     * Creates an IMessage from an error.
     *
     * @param {string} defaultMessage - A default message describing the error context.
     * @param {unknown} [context={}] - Additional context for the error.
     * @param {unknown} [err] - The error object.
     * @returns {IMessage} An IMessage object ready to be sent via the notifier.
     */
    public createErrorMessage(
        defaultMessage: string,
        context: unknown = {},
        err?: unknown,
    ): IMessage {
        const contextObject = typeof context === "object" && context !== null ? context : {};
        if (isNativeError(err)) {
            return {
                title: `**Error:** ${err.name} - ${err.message}`,
                description: `**Context:**\n\`\`\`json\n${stringify({
                    ...contextObject,
                    stack: err.stack,
                })}\n\`\`\``,
            };
        } else {
            return {
                title: `**Error:** ${defaultMessage}`,
                description: `**Context:**\n\`\`\`json\n${stringify({
                    ...contextObject,
                    error: err ? stringify(err) : undefined,
                })}\n\`\`\``,
            };
        }
    }

    /**
     * Sends an error notification message to Discord.
     *
     * @param {string} defaultMessage - A default message describing the error context.
     * @param {Record<string, unknown>} [context={}] - Additional context for the error.
     * @param {unknown} [err] - The error object.
     * @returns {Promise<void>} A promise that resolves when the message is sent.
     */
    public async sendError(
        defaultMessage: string,
        context: Record<string, unknown> = {},
        err?: unknown,
    ): Promise<void> {
        const errorMessage = this.createErrorMessage(defaultMessage, context, err);
        await this.send(errorMessage);
    }
}
