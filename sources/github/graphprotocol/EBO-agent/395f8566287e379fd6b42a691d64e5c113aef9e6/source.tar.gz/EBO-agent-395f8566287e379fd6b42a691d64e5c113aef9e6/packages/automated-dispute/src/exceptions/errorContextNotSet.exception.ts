export class ErrorContextNotSetException extends Error {
    constructor(message?: string) {
        super(`Context is not set: ${message}`);
    }
}
