import { UnixTimestamp } from "@ebo-agent/shared";
import { AbiParametersToPrimitiveTypes, ExtractAbiEvent, ExtractAbiEventNames } from "abitype";
import { Hex, Log } from "viem";

import { eboAbi } from "../abis/index.js";
import { ProposalId, ProposalStatus } from "./index.js";

export type EboEventNameV2 = Extract<
    ExtractAbiEventNames<typeof eboAbi>,
    | "ProposalCreated"
    | "ProposalDisputed"
    | "ProposalFinalized"
    | "PledgedForDispute"
    | "PledgedAgainstDispute"
    | "DisputeEscalated"
    | "DisputeResolved"
>;

/**
 * This is the list of events that are interesting to us.
 */
export const EboEventNameV2Includes = [
    "ProposalCreated",
    "ProposalDisputed",
    "ProposalFinalized",
    "PledgedForDispute",
    "PledgedAgainstDispute",
    "DisputeEscalated",
    "DisputeResolved",
] as const satisfies EboEventNameV2[];

export const eboEventsAbi = eboAbi.filter(
    (item): item is (typeof eboAbi)[number] & { type: "event"; name: EboEventNameV2 } =>
        item.type === "event" &&
        item.name !== undefined &&
        EboEventNameV2Includes.includes(item.name as EboEventNameV2),
);

type DynamicType = "string" | "bytes" | `${string}[]`;

type AbiEventToType<T extends readonly unknown[]> = {
    [K in T[number] as K extends { name: infer Name extends string }
        ? Name extends `_${infer CleanName}`
            ? CleanName
            : Name
        : never]: K extends {
        type: infer Type extends string;
        indexed?: infer Indexed extends boolean;
    }
        ? Indexed extends true
            ? Type extends DynamicType
                ? Hex
                : AbiParametersToPrimitiveTypes<[K]>[0]
            : AbiParametersToPrimitiveTypes<[K]>[0]
        : never;
};

export type ProposalCreatedV2 = AbiEventToType<
    ExtractAbiEvent<typeof eboAbi, "ProposalCreated">["inputs"]
>;

export type ProposalDisputedV2 = AbiEventToType<
    ExtractAbiEvent<typeof eboAbi, "ProposalDisputed">["inputs"]
>;

export type ProposalFinalizedV2 = AbiEventToType<
    ExtractAbiEvent<typeof eboAbi, "ProposalFinalized">["inputs"]
>;

export type PledgedForDisputeV2 = AbiEventToType<
    ExtractAbiEvent<typeof eboAbi, "PledgedForDispute">["inputs"]
>;

export type PledgedAgainstDisputeV2 = AbiEventToType<
    ExtractAbiEvent<typeof eboAbi, "PledgedAgainstDispute">["inputs"]
>;

export type DisputeEscalatedV2 = AbiEventToType<
    ExtractAbiEvent<typeof eboAbi, "DisputeEscalated">["inputs"]
>;

export type DisputeResolvedV2 = Omit<
    AbiEventToType<ExtractAbiEvent<typeof eboAbi, "DisputeResolved">["inputs"]>,
    "resolutionStatus"
> & {
    resolutionStatus: ProposalStatus;
};

export type EboEventDataV2<T extends EboEventNameV2> = T extends "ProposalCreated"
    ? ProposalCreatedV2
    : T extends "ProposalDisputed"
      ? ProposalDisputedV2
      : T extends "ProposalFinalized"
        ? ProposalFinalizedV2
        : T extends "PledgedForDispute"
          ? PledgedForDisputeV2
          : T extends "PledgedAgainstDispute"
            ? PledgedAgainstDisputeV2
            : T extends "DisputeEscalated"
              ? DisputeEscalatedV2
              : T extends "DisputeResolved"
                ? DisputeResolvedV2
                : never;

type BaseEventFields = {
    /** Block's number this event was logged on */
    blockNumber: bigint;
    /** Log index relative to the block this event was logged on */
    logIndex: number;
    /** Block's timestamp this event was logged on */
    timestamp: UnixTimestamp;
    /** Raw log data */
    rawLog?: Log;
    /** Proposal ID */
    proposalId: ProposalId;
};

export type EboEventV2 = {
    [K in EboEventNameV2]: BaseEventFields & {
        /** Event name */
        name: K;
        /** Event args */
        args: EboEventDataV2<K>;
    };
}[EboEventNameV2];
