export class FetchAvailableChainsError extends Error {
    constructor() {
        super(`Failed to fetch available chains from EBO`);
        this.name = "FetchAvailableChains";
    }
}
