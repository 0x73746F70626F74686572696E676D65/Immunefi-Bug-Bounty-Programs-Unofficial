import { UnixTimestamp } from "@ebo-agent/shared";

/**
 * @description Gets the current timestamp in seconds
 * @returns {UnixTimestamp} The current timestamp in seconds
 *
 * This timestamp is compliant to the way timestamps are represented in the blockchain.
 */
export const getCurrentTimestampInSec = (): UnixTimestamp => {
    // timestamps are stored in seconds in blockchain
    return BigInt(Math.floor(Date.now() / 1000)) as UnixTimestamp;
};
