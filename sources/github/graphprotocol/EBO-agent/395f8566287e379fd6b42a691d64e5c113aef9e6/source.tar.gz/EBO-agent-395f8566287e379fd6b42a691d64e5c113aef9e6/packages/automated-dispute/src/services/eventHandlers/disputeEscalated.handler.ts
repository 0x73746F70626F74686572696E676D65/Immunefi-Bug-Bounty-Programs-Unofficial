import { EboEventV2 } from "../../types/index.js";
import { BaseEventHandler } from "./base.handler.js";

/**
 * @description Handles the DisputeEscalated event
 * @extends BaseEventHandler
 *
 * Logs the escalated proposal id.
 */
export class DisputeEscalatedHandler extends BaseEventHandler<"DisputeEscalated"> {
    async run(event: Extract<EboEventV2, { name: "DisputeEscalated" }>): Promise<void> {
        this.logger.info(`Proposal ${event.args.proposalId} dispute has been escalated.`, {
            proposalId: event.args.proposalId,
        });
    }
}
