import { BlockNumberService } from "@ebo-agent/blocknumber";
import { Caip2ChainId, NotificationService, UnixTimestamp } from "@ebo-agent/shared";
// NOTE: Must import Caip2Utils from here to ensure mock applies correctly
import { Caip2Utils } from "@ebo-agent/shared/src/index.js";
import { Address, Block, keccak256, stringToBytes } from "viem";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import {
    ErrorFactoryV2,
    PastEventEnqueueError,
    ProcessorAlreadyStarted,
} from "../../src/exceptions/index.js";
import { EboActorsManagerV2, ProtocolProviderV2 } from "../../src/index.js";
import { IEboParametersRegistry } from "../../src/interfaces/index.js";
import { EboProcessorV2 } from "../../src/services/eboProcessorV2.js";
import { EboActorV2 } from "../../src/services/index.js";
import {
    DisputeV2,
    EboEventV2,
    Epoch,
    Proposal,
    ProposalId,
    ProposalStatus,
    SnapshotParameters,
} from "../../src/types/index.js";
import mocks from "../mocks/index.js";

const logger = mocks.mockLogger();
const msBetweenChecks = 1;

describe("EboProcessorV2", () => {
    let notifier: NotificationService;
    let processor: EboProcessorV2;
    let protocolProvider: ProtocolProviderV2;
    let actorsManager: EboActorsManagerV2;
    let blockNumberService: BlockNumberService;
    let parametersRegistry: IEboParametersRegistry;

    const mockProposalId = 1n as unknown as ProposalId;
    const mockEpoch = 1n;
    const mockChainId = "eip155:1" as Caip2ChainId;
    const mockBlockNumber = 100n;
    const mockCreatedAt = 1000n;
    const baseTimestamp = 1740870187n as UnixTimestamp; // March 1st 2025

    const mockParameters: SnapshotParameters = {
        proposalBondSize: 100n,
        pledgeBondSize: 10n,
        minThawingPeriod: 1000n,
        disputeWindow: 86400n, // 24 hours
        pledgeWindow: 172800n, // 48 hours
        pledgeRefreshWindow: 3600n, // 1 hour
        maxNumberOfPledges: 5n,
    };

    const mockProposal: Proposal = {
        id: mockProposalId,
        epoch: mockEpoch,
        chainId: mockChainId,
        blockNumber: mockBlockNumber,
        proposer: "0x123" as Address,
        createdAt: mockCreatedAt,
        parametersSnapshotId: 1n,
        status: ProposalStatus.Active,
    };

    const mockDispute: DisputeV2 = {
        disputer: "0x456" as Address,
        createdAt: 1100n,
        lastPledgeTimestamp: 1100n,
        totalPledgesForDispute: 0n,
        totalPledgesAgainstDispute: 0n,
        rewardPerWinningPledge: 0n,
    };

    const mockActor: EboActorV2 = {
        enqueue: vi.fn(),
        processEvents: vi.fn(),
        canBeTerminated: vi.fn(),
        onLastBlockUpdated: vi.fn(),
    } as unknown as EboActorV2;

    beforeEach(() => {
        vi.useFakeTimers();
        notifier = {
            send: vi.fn().mockResolvedValue(undefined),
            sendOrThrow: vi.fn().mockResolvedValue(undefined),
            sendError: vi.fn().mockResolvedValue(undefined),
            createErrorMessage: vi.fn((defaultMessage, context) => {
                return {
                    title: defaultMessage,
                    description: JSON.stringify(context, null, 2),
                };
            }),
        };

        protocolProvider = {
            read: {
                getCurrentEpoch: vi.fn().mockResolvedValue({
                    number: mockEpoch,
                    firstBlockNumber: 1n,
                    startTimestamp: baseTimestamp,
                }),
                getLastFinalizedBlock: vi.fn().mockResolvedValue({
                    number: 10n,
                    timestamp: baseTimestamp,
                }),
                getEvents: vi.fn().mockResolvedValue([]),
                getAvailableChains: vi.fn().mockResolvedValue([mockChainId]),
                getProposalById: vi.fn().mockResolvedValue(mockProposal),
                getDisputeByProposalId: vi.fn().mockResolvedValue(mockDispute),
                getActiveProposal: vi.fn().mockResolvedValue(null),
            },
            write: {
                propose: vi.fn().mockResolvedValue(undefined),
                finalize: vi.fn().mockResolvedValue(undefined),
                resolve: vi.fn().mockResolvedValue(undefined),
            },
            getAccountAddress: vi.fn().mockReturnValue("0x789" as Address),
        } as unknown as ProtocolProviderV2;

        actorsManager = {
            createActor: vi.fn(),
            getActor: vi.fn(),
            deleteActor: vi.fn(),
            getProposalIds: vi.fn().mockReturnValue([]),
        } as unknown as EboActorsManagerV2;

        blockNumberService = {
            getEpochBlockNumber: vi.fn().mockResolvedValue(100n),
        } as unknown as BlockNumberService;

        parametersRegistry = {
            getParameters: vi.fn().mockResolvedValue(mockParameters),
        } as unknown as IEboParametersRegistry;

        processor = new EboProcessorV2(
            protocolProvider,
            blockNumberService,
            actorsManager,
            parametersRegistry,
            logger,
            notifier,
        );

        vi.spyOn(Caip2Utils, "isSupported").mockImplementation((chainId: Caip2ChainId) => {
            return chainId === mockChainId;
        });
    });

    afterEach(() => {
        vi.useRealTimers();
        vi.clearAllTimers();
        vi.resetAllMocks();
    });

    describe("start", () => {
        it("throws if called more than once", async () => {
            await processor.start(msBetweenChecks);
            await expect(processor.start(msBetweenChecks)).rejects.toThrow(ProcessorAlreadyStarted);
        });

        it("bootstraps by syncing when starting", async () => {
            const currentEpoch: Epoch = {
                number: 1n,
                firstBlockNumber: 1n,
                startTimestamp: BigInt(Date.UTC(2024, 1, 1, 0, 0, 0, 0)) as UnixTimestamp,
            };
            const lastFinalizedBlock = {
                number: currentEpoch.firstBlockNumber + 10n,
            } as unknown as Block<bigint, false, "finalized">;

            const proposalCreatedEvent: EboEventV2 = {
                name: "ProposalCreated",
                blockNumber: 1n,
                logIndex: 1,
                timestamp: baseTimestamp,
                proposalId: mockProposalId,
                args: {
                    proposalId: mockProposalId,
                    epoch: mockEpoch,
                    chainId: keccak256(stringToBytes(mockChainId)),
                    blockNumber: mockBlockNumber,
                    serviceProvider: "0x789" as Address,
                },
            };

            vi.spyOn(protocolProvider.read, "getCurrentEpoch").mockResolvedValue(currentEpoch);
            vi.spyOn(protocolProvider.read, "getLastFinalizedBlock").mockResolvedValue(
                lastFinalizedBlock,
            );
            vi.spyOn(protocolProvider.read, "getEvents").mockResolvedValue([proposalCreatedEvent]);
            vi.spyOn(protocolProvider.read, "getAvailableChains").mockResolvedValue(["eip155:1"]);
            vi.spyOn(protocolProvider.read, "getProposalById").mockResolvedValue(mockProposal);
            vi.spyOn(parametersRegistry, "getParameters").mockResolvedValue(mockParameters);
            const mockCreateActor = vi
                .spyOn(actorsManager, "createActor")
                .mockReturnValue(mockActor);

            await processor.start(msBetweenChecks);
            expect(mockCreateActor).toHaveBeenCalled();
            expect(mockActor.enqueue).toHaveBeenCalledWith(proposalCreatedEvent);
            expect(mockActor.processEvents).toHaveBeenCalled();
            expect(mockActor.onLastBlockUpdated).toHaveBeenCalledWith(lastFinalizedBlock.timestamp);
        });

        it("sets up a recurring sync at specified interval", async () => {
            const setIntervalSpy = vi.spyOn(global, "setInterval");
            vi.spyOn(processor as any, "sync").mockResolvedValue(undefined);

            await processor.start(msBetweenChecks);

            expect(setIntervalSpy).toHaveBeenCalledWith(expect.any(Function), msBetweenChecks);
        });
    });

    describe("sync", () => {
        it("fetches events since the block after lastCheckedBlock", async () => {
            const currentEpoch: Epoch = {
                number: mockEpoch,
                firstBlockNumber: 1n,
                startTimestamp: baseTimestamp,
            };

            const lastBlock = {
                number: 10n,
                timestamp: baseTimestamp,
            } as unknown as Block<bigint, boolean, "finalized">;

            processor["lastCheckedBlock"] = 5n;

            const getEventsSpy = vi.spyOn(protocolProvider.read, "getEvents").mockResolvedValue([]);
            vi.spyOn(protocolProvider.read, "getCurrentEpoch").mockResolvedValue(currentEpoch);
            vi.spyOn(protocolProvider.read, "getLastFinalizedBlock").mockResolvedValue(lastBlock);

            await processor["sync"]();

            expect(getEventsSpy).toHaveBeenCalledWith(6n, 10n);
        });

        it("initializes lastCheckedBlock to epoch.firstBlockNumber - 1 on first run", async () => {
            const currentEpoch: Epoch = {
                number: mockEpoch,
                firstBlockNumber: 5n,
                startTimestamp: baseTimestamp,
            };

            const lastBlock = {
                number: 10n,
                timestamp: baseTimestamp,
            } as unknown as Block<bigint, boolean, "finalized">;

            vi.spyOn(protocolProvider.read, "getCurrentEpoch").mockResolvedValue(currentEpoch);
            vi.spyOn(protocolProvider.read, "getLastFinalizedBlock").mockResolvedValue(lastBlock);
            vi.spyOn(protocolProvider.read, "getEvents").mockResolvedValue([]);

            await processor["sync"]();

            expect(processor["lastCheckedBlock"]).toBe(10n); // Updated to lastBlock.number after sync
        });

        it("groups events by proposal ID", async () => {
            const mockEvent1: EboEventV2 = {
                name: "ProposalCreated",
                blockNumber: 2n,
                logIndex: 1,
                timestamp: baseTimestamp,
                proposalId: mockProposalId,
                args: {
                    proposalId: mockProposalId,
                    epoch: mockEpoch,
                    chainId: keccak256(stringToBytes(mockChainId)),
                    blockNumber: 100n,
                    serviceProvider: "0x789" as Address,
                },
                rawLog: {} as any,
            };

            const mockEvent2: EboEventV2 = {
                name: "ProposalDisputed",
                blockNumber: 3n,
                logIndex: 1,
                timestamp: baseTimestamp,
                proposalId: mockProposalId,
                args: {
                    proposalId: mockProposalId,
                },
                rawLog: {} as any,
            };

            vi.spyOn(protocolProvider.read, "getEvents").mockResolvedValue([
                mockEvent1,
                mockEvent2,
            ]);

            const groupEventsSpy = vi.spyOn(processor as any, "groupEventsByProposal");

            await processor["sync"]();

            expect(groupEventsSpy).toHaveBeenCalledWith([mockEvent1, mockEvent2]);

            const result = processor["groupEventsByProposal"]([mockEvent1, mockEvent2]);
            expect(result.size).toBe(1);
            expect(result.get(mockProposalId)).toEqual([mockEvent1, mockEvent2]);
        });

        it("creates new actors for ProposalCreated events", async () => {
            const mockEvent: EboEventV2 = {
                name: "ProposalCreated",
                blockNumber: 2n,
                logIndex: 1,
                timestamp: baseTimestamp,
                proposalId: mockProposalId,
                args: {
                    proposalId: mockProposalId,
                    epoch: mockEpoch,
                    chainId: keccak256(stringToBytes(mockChainId)),
                    blockNumber: mockBlockNumber,
                    serviceProvider: "0x789" as Address,
                },
                rawLog: {} as any,
            };

            vi.spyOn(protocolProvider.read, "getEvents").mockResolvedValue([mockEvent]);
            vi.spyOn(actorsManager, "getActor").mockReturnValue(undefined);

            const mockActor = {
                enqueue: vi.fn(),
                processEvents: vi.fn().mockResolvedValue(undefined),
                onLastBlockUpdated: vi.fn().mockResolvedValue(undefined),
                canBeTerminated: vi.fn().mockReturnValue(false),
            };

            vi.spyOn(actorsManager, "createActor").mockReturnValue(mockActor as any);

            await processor["sync"]();

            expect(actorsManager.createActor).toHaveBeenCalledWith(
                expect.objectContaining({
                    id: mockProposalId,
                    epoch: mockEpoch,
                    chainId: mockChainId,
                }),
                protocolProvider,
                blockNumberService,
                logger,
                notifier,
            );
        });

        it("does not create actors for unsupported chains", async () => {
            const unsupportedChainId = "eip155:999" as Caip2ChainId;
            const mockEvent: EboEventV2 = {
                name: "ProposalCreated",
                blockNumber: 2n,
                logIndex: 1,
                timestamp: baseTimestamp,
                proposalId: mockProposalId,
                args: {
                    proposalId: mockProposalId,
                    epoch: mockEpoch,
                    chainId: keccak256(stringToBytes(unsupportedChainId)),
                    blockNumber: mockBlockNumber,
                    serviceProvider: "0x789" as Address,
                },
                rawLog: {} as any,
            };

            vi.spyOn(protocolProvider.read, "getEvents").mockResolvedValue([mockEvent]);
            vi.spyOn(Caip2Utils, "isSupported").mockImplementation((chainId: Caip2ChainId) => {
                return chainId === mockChainId; // Only mockChainId is supported
            });

            const notifierSpy = vi.spyOn(notifier, "sendError");
            const createActorSpy = vi.spyOn(actorsManager, "createActor");

            await processor["sync"]();

            expect(createActorSpy).not.toHaveBeenCalled();
            expect(notifierSpy).toHaveBeenCalledWith(
                expect.stringContaining(mockEvent.args.chainId),
                expect.objectContaining({ chainId: mockEvent.args.chainId }),
                expect.any(Error),
            );
        });

        it("enqueues events to the appropriate actor", async () => {
            const mockEvent: EboEventV2 = {
                name: "ProposalFinalized",
                blockNumber: 2n,
                logIndex: 1,
                timestamp: baseTimestamp,
                proposalId: mockProposalId,
                args: {
                    proposalId: mockProposalId,
                    epoch: mockEpoch,
                    chainId: keccak256(stringToBytes(mockChainId)),
                    blockNumber: mockBlockNumber,
                },
                rawLog: {} as any,
            };

            vi.spyOn(protocolProvider.read, "getEvents").mockResolvedValue([mockEvent]);

            const mockActor = {
                enqueue: vi.fn(),
                processEvents: vi.fn().mockResolvedValue(undefined),
                onLastBlockUpdated: vi.fn().mockResolvedValue(undefined),
                canBeTerminated: vi.fn().mockReturnValue(false),
            };

            vi.spyOn(actorsManager, "getActor").mockReturnValue(mockActor as any);

            await processor["sync"]();

            expect(mockActor.enqueue).toHaveBeenCalledWith(mockEvent);
        });

        it("terminates actor when canBeTerminated returns true", async () => {
            const mockEvent: EboEventV2 = {
                name: "ProposalFinalized",
                blockNumber: 2n,
                logIndex: 1,
                timestamp: baseTimestamp,
                proposalId: mockProposalId,
                args: {
                    proposalId: mockProposalId,
                    epoch: mockEpoch,
                    chainId: keccak256(stringToBytes(mockChainId)),
                    blockNumber: mockBlockNumber,
                },
                rawLog: {} as any,
            };

            vi.spyOn(protocolProvider.read, "getEvents").mockResolvedValue([mockEvent]);

            const mockActor = {
                enqueue: vi.fn(),
                processEvents: vi.fn().mockResolvedValue(undefined),
                onLastBlockUpdated: vi.fn().mockResolvedValue(undefined),
                canBeTerminated: vi.fn().mockReturnValue(true),
            };

            vi.spyOn(actorsManager, "getActor").mockReturnValue(mockActor as any);
            vi.spyOn(actorsManager, "deleteActor").mockReturnValue(mockActor as any);

            await processor["sync"]();

            expect(actorsManager.deleteActor).toHaveBeenCalledWith(mockProposalId);
        });

        it("handles PastEventEnqueueError by logging and continuing", async () => {
            const mockEvent: EboEventV2 = {
                name: "ProposalFinalized",
                blockNumber: 2n,
                logIndex: 1,
                timestamp: baseTimestamp,
                proposalId: mockProposalId,
                args: {
                    proposalId: mockProposalId,
                    epoch: mockEpoch,
                    chainId: keccak256(stringToBytes(mockChainId)),
                    blockNumber: mockBlockNumber,
                },
                rawLog: {} as any,
            };

            vi.spyOn(protocolProvider.read, "getEvents").mockResolvedValue([mockEvent]);

            const mockActor = {
                enqueue: vi.fn().mockImplementation(() => {
                    throw new PastEventEnqueueError(mockEvent, mockEvent);
                }),
                processEvents: vi.fn().mockResolvedValue(undefined),
                onLastBlockUpdated: vi.fn().mockResolvedValue(undefined),
                canBeTerminated: vi.fn().mockReturnValue(false),
            };

            vi.spyOn(actorsManager, "getActor").mockReturnValue(mockActor as any);
            const loggerWarnSpy = vi.spyOn(logger, "warn");

            await processor["sync"]();

            expect(loggerWarnSpy).toHaveBeenCalledWith(
                expect.stringContaining("Dropping already enqueued event"),
            );
            expect(mockActor.processEvents).toHaveBeenCalled();
        });

        it("calls createMissingProposals for epochs", async () => {
            const createMissingProposalsSpy = vi.spyOn(processor as any, "createMissingProposals");

            await processor["sync"]();

            expect(createMissingProposalsSpy).toHaveBeenCalledWith(expect.any(Object));
        });
    });

    describe("createMissingProposals", () => {
        it("proposes for available chains that don't have proposals", async () => {
            const epoch: Epoch = {
                number: mockEpoch,
                firstBlockNumber: 1n,
                startTimestamp: baseTimestamp,
            };

            vi.spyOn(protocolProvider.read, "getAvailableChains").mockResolvedValue([
                mockChainId,
                "eip155:42161" as Caip2ChainId,
            ]);

            vi.spyOn(protocolProvider.read, "getActiveProposal").mockImplementation(
                (_epochNumber, _chainId) => Promise.resolve(undefined),
            );
            vi.spyOn(Caip2Utils, "isSupported").mockReturnValue(true);

            const proposeSpy = vi.spyOn(protocolProvider.write, "propose");

            await processor["createMissingProposals"](epoch);

            expect(proposeSpy).toHaveBeenCalledTimes(2);
            expect(proposeSpy).toHaveBeenCalledWith(
                mockEpoch,
                mockChainId,
                expect.any(BigInt),
                expect.any(String),
            );
        });

        it("does not propose for chains that already have active proposals", async () => {
            const epoch: Epoch = {
                number: mockEpoch,
                firstBlockNumber: 1n,
                startTimestamp: baseTimestamp,
            };

            vi.spyOn(protocolProvider.read, "getAvailableChains").mockResolvedValue([mockChainId]);
            vi.spyOn(protocolProvider.read, "getActiveProposal").mockImplementation(
                (_epochNumber, _chainId) => Promise.resolve(mockProposal),
            );

            const proposeSpy = vi.spyOn(protocolProvider.write, "propose");

            await processor["createMissingProposals"](epoch);

            expect(proposeSpy).not.toHaveBeenCalled();
        });

        it("handles error when proposal already exists", async () => {
            const epoch: Epoch = {
                number: mockEpoch,
                firstBlockNumber: 1n,
                startTimestamp: baseTimestamp,
            };

            vi.spyOn(protocolProvider.read, "getAvailableChains").mockResolvedValue([mockChainId]);
            vi.spyOn(protocolProvider.read, "getActiveProposal").mockImplementation(
                (_epochNumber, _chainId) => Promise.resolve(undefined),
            );

            const error = ErrorFactoryV2.createError("EBOCore_Propose_ProposalAlreadyActive");
            vi.spyOn(protocolProvider.write, "propose").mockRejectedValue(error);

            const loggerInfoSpy = vi.spyOn(logger, "info");

            await processor["createMissingProposals"](epoch);

            expect(loggerInfoSpy).toHaveBeenCalledWith(
                expect.stringContaining("Active proposal for epoch"),
            );
        });

        it("doesn't increment the counter when proposal creation throws ProposalAlreadyActive error", async () => {
            const epoch: Epoch = {
                number: mockEpoch,
                firstBlockNumber: 1n,
                startTimestamp: baseTimestamp,
            };

            vi.spyOn(protocolProvider.read, "getAvailableChains").mockResolvedValue([mockChainId]);
            vi.spyOn(protocolProvider.read, "getActiveProposal").mockImplementation(
                (_epochNumber, _chainId) => Promise.resolve(undefined),
            );

            const error = ErrorFactoryV2.createError("EBOCore_Propose_ProposalAlreadyActive");
            vi.spyOn(protocolProvider.write, "propose").mockRejectedValue(error);

            // Spy on the incrementCounter method to verify it's not called
            const incrementCounterSpy = vi.spyOn(
                processor as any,
                "incrementCounterProposalsCreatedPerEpochAndChain",
            );

            // Get initial counter value
            const initialCounter = processor["getCounterProposalsCreatedPerEpochAndChain"](
                `${mockEpoch}-${mockChainId}`,
            );

            await processor["createMissingProposals"](epoch);

            // Verify counter wasn't incremented
            expect(incrementCounterSpy).not.toHaveBeenCalled();
            const finalCounter = processor["getCounterProposalsCreatedPerEpochAndChain"](
                `${mockEpoch}-${mockChainId}`,
            );
            expect(finalCounter).toBe(initialCounter);
        });

        it("respects maxProposalsPerEpochAndChain limit", async () => {
            const epoch: Epoch = {
                number: mockEpoch,
                firstBlockNumber: 1n,
                startTimestamp: baseTimestamp,
            };

            vi.spyOn(protocolProvider.read, "getAvailableChains").mockResolvedValue([mockChainId]);
            vi.spyOn(protocolProvider.read, "getActiveProposal").mockImplementation(
                (_epochNumber, _chainId) => Promise.resolve(undefined),
            );

            vi.spyOn(
                processor as any,
                "getCounterProposalsCreatedPerEpochAndChain",
            ).mockReturnValue(processor["maxProposalsPerEpochAndChain"]);

            const proposeSpy = vi.spyOn(protocolProvider.write, "propose");
            const loggerInfoSpy = vi.spyOn(logger, "info");

            await processor["createMissingProposals"](epoch);

            expect(proposeSpy).not.toHaveBeenCalled();
            expect(loggerInfoSpy).toHaveBeenCalledWith(
                expect.stringContaining("Max proposals per epoch and chain reached"),
            );
        });
    });

    describe("cleanupOldEpochs", () => {
        it("cleans up epochs less than currentEpoch - 1", () => {
            processor["handledChainIdsPerEpoch"].set(1n, new Set([mockChainId]));
            processor["handledChainIdsPerEpoch"].set(2n, new Set([mockChainId]));
            processor["handledChainIdsPerEpoch"].set(3n, new Set([mockChainId]));

            // Also set up counters
            processor["counterProposalsCreatedPerEpochAndChain"].set(`${1n}-${mockChainId}`, 1);

            processor["cleanupOldEpochs"](3n);

            expect(processor["handledChainIdsPerEpoch"].has(1n)).toBe(false);
            expect(processor["handledChainIdsPerEpoch"].has(2n)).toBe(true);
            expect(processor["handledChainIdsPerEpoch"].has(3n)).toBe(true);

            expect(
                processor["counterProposalsCreatedPerEpochAndChain"].has(`${1n}-${mockChainId}`),
            ).toBe(false);
        });
    });

    describe("Counter for proposals per epoch and chain", () => {
        it("increments the counter correctly", () => {
            const epoch = 1n;
            const chainId = "eip155:1" as Caip2ChainId;

            expect(
                processor["getCounterProposalsCreatedPerEpochAndChain"](`${epoch}-${chainId}`),
            ).toBe(0);

            processor["incrementCounterProposalsCreatedPerEpochAndChain"](`${epoch}-${chainId}`);
            expect(
                processor["getCounterProposalsCreatedPerEpochAndChain"](`${epoch}-${chainId}`),
            ).toBe(1);

            processor["incrementCounterProposalsCreatedPerEpochAndChain"](`${epoch}-${chainId}`);
            expect(
                processor["getCounterProposalsCreatedPerEpochAndChain"](`${epoch}-${chainId}`),
            ).toBe(2);
        });

        it("handles different epochs and chains separately", () => {
            const epoch1 = 1n;
            const epoch2 = 2n;
            const chainId1 = "eip155:1" as Caip2ChainId;
            const chainId2 = "eip155:2" as Caip2ChainId;

            processor["incrementCounterProposalsCreatedPerEpochAndChain"](`${epoch1}-${chainId1}`);
            processor["incrementCounterProposalsCreatedPerEpochAndChain"](`${epoch2}-${chainId2}`);

            expect(
                processor["getCounterProposalsCreatedPerEpochAndChain"](`${epoch1}-${chainId1}`),
            ).toBe(1);
            expect(
                processor["getCounterProposalsCreatedPerEpochAndChain"](`${epoch2}-${chainId2}`),
            ).toBe(1);
            expect(
                processor["getCounterProposalsCreatedPerEpochAndChain"](`${epoch1}-${chainId2}`),
            ).toBe(0);
            expect(
                processor["getCounterProposalsCreatedPerEpochAndChain"](`${epoch2}-${chainId1}`),
            ).toBe(0);
        });
    });
});
