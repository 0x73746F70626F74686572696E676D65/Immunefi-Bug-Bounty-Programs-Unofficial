import { BlockNumberService } from "@ebo-agent/blocknumber";
import { ILogger, NotificationService } from "@ebo-agent/shared";
import { Mutex } from "async-mutex";

import { ProposalAlreadyHandled } from "../exceptions/index.js";
import { ProtocolProviderV2 } from "../providers/index.js";
import { ActorProposal, ProposalId } from "../types/index.js";
import { EboActorV2 } from "./index.js";

/**
 * Manager that handles the creation and retrieval of `EboActorV2` instances.
 */
export class EboActorsManagerV2 {
    private readonly requestActorMap: Map<ProposalId, EboActorV2>;

    constructor() {
        this.requestActorMap = new Map();
    }

    /**
     * Return an array of the proposal IDs this instance is handling.
     *
     * @returns array of proposal IDs
     */
    public getProposalIds(): ProposalId[] {
        return [...this.requestActorMap.keys()].map((proposalId) => proposalId);
    }

    /**
     * Creates and registers the actor by its proposal ID.
     *
     * @param actor an `EboActorV2` instance that handles a proposal.
     */
    public createActor(
        actorProposal: ActorProposal,
        protocolProvider: ProtocolProviderV2,
        blockNumberService: BlockNumberService,
        logger: ILogger,
        notifier: NotificationService,
    ): EboActorV2 {
        const proposalId = actorProposal.id;

        if (this.requestActorMap.has(proposalId)) throw new ProposalAlreadyHandled(proposalId);

        const eventProcessingMutex = new Mutex();

        const actor = new EboActorV2(
            actorProposal,
            protocolProvider,
            blockNumberService,
            eventProcessingMutex,
            logger,
            notifier,
        );

        this.requestActorMap.set(proposalId, actor);

        return actor;
    }

    /**
     * Get the `EboActorV2` instance linked with the `proposalId`.
     *
     * @param proposalId proposal ID
     * @returns an `EboActorV2` instance if found by `proposalId`, otherwise `undefined`
     */
    public getActor(proposalId: ProposalId): EboActorV2 | undefined {
        return this.requestActorMap.get(proposalId);
    }

    /**
     * Deletes an actor from the manager, based on its linked proposal.
     *
     * @param proposalId proposal ID
     * @returns `true` if there was a linked actor for the proposal ID and it was removed, or `false` if the proposal was not linked to any actor.
     */
    public deleteActor(proposalId: ProposalId): boolean {
        return this.requestActorMap.delete(proposalId);
    }
}
