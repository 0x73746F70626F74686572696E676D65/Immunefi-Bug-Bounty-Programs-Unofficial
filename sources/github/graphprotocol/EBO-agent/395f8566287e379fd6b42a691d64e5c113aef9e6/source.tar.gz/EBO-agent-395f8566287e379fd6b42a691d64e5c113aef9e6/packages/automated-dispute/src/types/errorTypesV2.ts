import { eboAbi } from "../abis/index.js";
import { DisputeV2, EboEventV2, Proposal, SnapshotParameters } from "./index.js";

export type BaseErrorStrategyV2 = {
    shouldNotify: boolean;
    shouldTerminate: boolean;
    shouldReenqueue: boolean;
    customAction?: (context: any) => Promise<void> | void;
};

export type ErrorHandlingStrategyV2 = BaseErrorStrategyV2;

export interface ErrorContextV2 {
    [key: string]: unknown;
    proposal: Proposal;
    parameters: SnapshotParameters;
    dispute?: DisputeV2;
    event?: EboEventV2;
    reenqueueEvent?: () => void;
    terminateActor?: () => void;
}

// Extract error names from the EBO ABI
type EboAbiErrorName = Extract<(typeof eboAbi)[number], { type: "error" }>["name"];

type EBOContractErrorNameV2 =
    /**
     * @notice Thrown when the caller is not an operator
     */
    | "AccessManager_OnlyOperator_NotOperator"
    /**
     * @notice Thrown when proposing and the epoch is invalid
     */
    | "EBOCore_Propose_InvalidEpoch"
    /**
     * @notice Thrown when proposing and the chain is not added
     */
    | "EBOCore_Propose_ChainNotAdded"
    /**
     * @notice Thrown when proposing and the proposal is already active
     */
    | "EBOCore_Propose_ProposalAlreadyActive"
    /**
     * @notice Thrown when disputing and the dispute window is over
     */
    | "EBOCore_Dispute_ProposalNotActive"
    /**
     * @notice Thrown when disputing and the dispute window is over
     */
    | "EBOCore_Dispute_DisputeWindowOver"
    /**
     * @notice Thrown when finalizing and the dispute window is not over
     */
    | "EBOCore_Finalize_DisputeWindowNotOver"
    /**
     * @notice Thrown when finalizing and the proposal is not active
     */
    | "EBOCore_Finalize_ProposalNotActive"
    /**
     * @notice Thrown when resolving and the proposal is not disputed
     */
    | "EBOCore_Resolve_ProposalNotDisputed"
    /**
     * @notice Thrown when resolving and the pledge window is not over
     */
    | "EBOCore_Resolve_PledgeWindowNotOver"
    /**
     * @notice Thrown when resolving and the dispute is not escalated
     */
    | "EBOCore_Resolve_DisputeNotEscalated"
    /**
     * @notice Thrown when resolving with an invalid status
     */
    | "EBOCore_Resolve_InvalidStatus"
    /**
     * @notice Thrown when pledging and the pledge window is over
     */
    | "EBOPledge_Pledge_PledgeWindowOver"
    /**
     * @notice Thrown when pledging and the proposal is not disputed
     */
    | "EBOPledge_Pledge_ProposalNotDisputed"
    /**
     * @notice Thrown when pledging and the pledging side has more pledges than the opposite side
     */
    | "EBOPledge_Pledge_CannotPledgeIfWinning"
    /**
     * @notice Thrown when bonding and the bonder has an invalid maximum verifier cut
     */
    | "BondManager_Bond_InvalidMaxVerifierCut"
    /**
     * @notice Thrown when bonding and the bonder has an invalid thawing period
     */
    | "BondManager_Bond_InvalidThawingPeriod"
    /**
     * @notice Thrown when bonding and the bonder has insufficient non-thawing tokens
     */
    | "BondManager_Bond_InsufficientNonThawingTokens"
    /**
     * @notice Thrown when bonding and the bonder's bonded tokens exceed his non-thawing tokens
     */
    | "BondManager_Bond_BondedTokensExceedNonThawingTokens";

// This will cause a type error if any EBOContractErrorNameV2 is not in the ABI
// The `as const` and explicit type ensures it's used without runtime impact
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const _VALIDATE_ERROR_NAMES = true as const satisfies Exclude<
    EBOContractErrorNameV2,
    EboAbiErrorName
> extends never
    ? true
    : false;

export type ErrorNameV2 = EBOContractErrorNameV2 | "UnknownError";
