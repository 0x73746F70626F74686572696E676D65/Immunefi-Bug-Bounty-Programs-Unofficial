import { Branded } from "@ebo-agent/shared";
import { Address } from "viem";

export type ProposalId = Branded<bigint, "ProposalId">;

/**
 * @notice Contains the data of a proposal
 * @param epoch The epoch of the proposal
 * @param chainId The chain ID of the proposal
 * @param blockNumber The block number of the proposal
 * @param proposer The address of the proposer
 * @param createdAt The creation timestamp of the proposal
 * @param parametersSnapshotId The snapshot ID of the proposal and dispute parameters
 * @param status The status of the proposal
 */
export type Proposal = {
    id: ProposalId;
    epoch: bigint;
    chainId: string;
    blockNumber: bigint;
    proposer: Address;
    createdAt: bigint;
    parametersSnapshotId: bigint;
    status: ProposalStatus;
};

/**
 * @notice The status of the proposal
 * @param None No proposal
 * @param Active Proposal active
 * @param Disputed Proposal disputed
 * @param Escalated Dispute escalated
 * @param DisputerWon The disputer won the dispute (proposer and his pledgers are penalized)
 * @param DisputerLost The disputer lost the dispute (disputer and his pledgers are penalized)
 * @param NoResolution No dispute resolution (no bonder is penalized)
 * @param Finalized Proposal finalized (the epoch block is valid)
 */
export enum ProposalStatus {
    None = 0,
    Active = 1,
    Disputed = 2,
    Escalated = 3,
    DisputerWon = 4,
    DisputerLost = 5,
    NoResolution = 6,
    Finalized = 7,
}

/**
 * @notice Returns the data of the dispute
 * @param disputer The address of the disputer
 * @param createdAt The creation timestamp of the dispute
 * @param lastPledgeTimestamp The timestamp of the last pledge
 * @param totalPledgesForDispute The total number of pledges in favor of the dispute
 * @param totalPledgesAgainstDispute The total number of pledges against the dispute
 * @param rewardPerWinningPledge The amount of GRT tokens rewarded per winning pledge
 */
export type DisputeV2 = {
    disputer: Address;
    createdAt: bigint;
    lastPledgeTimestamp: bigint;
    totalPledgesForDispute: bigint;
    totalPledgesAgainstDispute: bigint;
    rewardPerWinningPledge: bigint;
};

/**
 * @notice Contains the parameters for proposals and disputes
 * @param proposalBondSize The bond size per proposal or dispute
 * @param pledgeBondSize The bond size per pledge
 * @param minThawingPeriod The minimum thawing period
 * @param disputeWindow The dispute window
 * @param pledgeWindow The pledge window
 * @param pledgeRefreshWindow The pledge refresh window
 * @param maxNumberOfPledges The maximum number of pledges for each side of disputes
 */
export type SnapshotParameters = {
    proposalBondSize: bigint;
    pledgeBondSize: bigint;
    minThawingPeriod: bigint;
    disputeWindow: bigint;
    pledgeWindow: bigint;
    pledgeRefreshWindow: bigint;
    maxNumberOfPledges: bigint;
};
