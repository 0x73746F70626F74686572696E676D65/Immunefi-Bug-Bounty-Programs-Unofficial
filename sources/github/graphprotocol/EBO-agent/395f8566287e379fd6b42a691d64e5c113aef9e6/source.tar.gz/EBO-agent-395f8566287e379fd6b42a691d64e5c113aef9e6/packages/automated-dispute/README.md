# ebo-agent: automated dispute

The `automated-dispute` package in `ebo-agent` provides services for interacting with EBO contracts to create EBO proposals, disputes, and pledges.

## Available Scripts

Available scripts that can be run using `pnpm`:

| Script       | Description                                             |
| ------------ | ------------------------------------------------------- |
| `build`      | Build the library                                       |
| `lint`       | Run ESLint to check for coding standards                |
| `lint:fix`   | Run linter and automatically fix code formatting issues |
| `format`     | Check code formatting and style using Prettier          |
| `format:fix` | Run formatter and automatically fix issues              |
| `test`       | Run unit tests using Vitest                             |
| `coverage`   | Run tests with coverage report                          |

## API

The primary services available within the `automated-dispute` package are the following:

### [EboProcessorV2](./src/services/eboProcessorV2.ts)

Class responsible for orchestrating the whole agent's flow. It fetches EBO events and routes them (per proposal) to be handled by `EboActorV2` instances.

The general flow of each periodic check can be summarized with the following diagram:

```mermaid
sequenceDiagram
    title EboProcessor General Flow

    participant EboProcessorV2
    participant ProtocolProviderV2
    participant EboActorV2

    EboProcessorV2->>ProtocolProviderV2: getCurrentEpoch()
    ProtocolProviderV2-->>EboProcessorV2: epoch: Epoch

    EboProcessorV2->>ProtocolProviderV2: getEvents(lastCheckedBlock, lastBlock)
    ProtocolProviderV2-->>EboProcessorV2: events: EboEvent[]

    EboProcessorV2->>EboProcessorV2: group events by request id

    loop group in groups
        loop event in groups
            EboProcessorV2->>EboActorV2: enqueue(event)
        end

        EboProcessorV2->>EboActorV2: processEvents()
        EboActorV2-->>EboProcessorV2: void
        EboProcessorV2->>EboActorV2: onLastBlockUpdated()
        EboActorV2-->>EboProcessorV2: void

        Note over EboProcessorV2,EboActorV2: If actor can be terminated (eg. request was finalized)
        EboProcessorV2->>EboActorV2: terminate()
    end

    loop chain in availableChains
        Note over EboProcessorV2: If chain has no active proposal for the current epoch and proposal limit not reached
        EboProcessorV2->>ProtocolProviderV2: propose(...)
        ProtocolProviderV2-->>EboProcessorV2: void
        Note over EboProcessorV2: Increment proposal counter
    end
```

It also creates new proposals if a chain has no active proposal for the current epoch.
It has a configurable rate limiter on the times it creates a proposal for the same epoch, to prevent proposing "indefinitely".

### [EboActorV2](./src/services/eboActoV2.ts)

Class responsible for EBO business logic implementation that handles a single proposal (ie each proposal should have an instance of an `EboActorV2`).

It triggers actions based on a stream of recent unprocessed events, eg:

-   Dispute proposals when there's an error with its block number
-   Pledge for/against disputes
-   Finalize proposals
-   Resolve disputes (if not escalated)

It's suggested to enqueue all unprocessed on chain events prior triggering `processEvents()`, as the actor assumes the last enqueued event is the last event on chain.

### [ProtocolProviderV2](./src/providers/protocolProviderV2.ts)

Class responsible for interacting with EBO contract on Arbitrum. It wraps `viem` clients for reading blockchain state and sending transactions.

It interacts with the following contracts:

-   EBO using `eboAbi`
-   EpochManager using `epochManagerV2Abi`

All contract write calls are being simulated first by default (via `viem`). After submitting the transaction, the `ProtocolProviderV2` instance will wait for transaction receipts based on configured confirmations.

#### Available methods

The provider separates read and write operations:

**Read Methods (`provider.read`)**

```typescript
getCurrentEpoch(): Promise<Epoch>;
getLastFinalizedBlock(): Promise<Block<bigint, false, "finalized">>;
getEvents(fromBlock: bigint, toBlock: bigint): Promise<EboEventV2[]>;
getAvailableChains(): Promise<Caip2ChainId[]>;
getProposalById(proposalId: ProposalId): Promise<Proposal | undefined>;
getDisputeByProposalId(proposalId: ProposalId): Promise<DisputeV2 | undefined>;
getSnapshotParameters(parameterSnapshotId: bigint): Promise<SnapshotParameters | undefined>;
getActiveProposal(epoch: bigint, chainId: Caip2ChainId): Promise<Proposal | undefined>;
```

**Write Methods (`provider.write`)**

```typescript
propose(epoch: bigint, chainId: Caip2ChainId, blockNumber: bigint, serviceProvider: Address): Promise<void>;
dispute(proposalId: ProposalId, serviceProvider: Address): Promise<void>;
resolve(proposalId: ProposalId): Promise<void>;
finalize(proposalId: bigint): Promise<void>;
pledgeForDispute(proposalId: bigint, serviceProvider: Address): Promise<void>;
pledgeAgainstDispute(proposalId: bigint, serviceProvider: Address): Promise<void>;
```

**Other Methods**

```typescript
getAccountAddress(): Address;
```
