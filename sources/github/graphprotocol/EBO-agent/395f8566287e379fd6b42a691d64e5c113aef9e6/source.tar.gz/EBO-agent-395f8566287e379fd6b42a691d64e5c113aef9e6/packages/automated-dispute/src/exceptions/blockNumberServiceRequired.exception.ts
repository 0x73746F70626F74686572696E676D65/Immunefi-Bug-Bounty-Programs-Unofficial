export class BlockNumberServiceRequiredError extends Error {
    constructor() {
        super("BlockNumberService is required to get the current epoch");
        this.name = "BlockNumberServiceRequiredError";
    }
}
