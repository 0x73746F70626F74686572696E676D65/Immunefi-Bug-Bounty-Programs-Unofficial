import { BlockNumberService } from "@ebo-agent/blocknumber";
import { ILogger, NotificationService, UnixTimestamp } from "@ebo-agent/shared";
import { Mutex } from "async-mutex";
import { Heap } from "heap-js";

import {
    CustomContractErrorV2,
    ErrorHandlerV2,
    InvalidActorState,
    MissingEventHandler,
    PastEventEnqueueError,
    ProposalMismatch,
} from "../exceptions/index.js";
import { IEventHandler } from "../interfaces/eventHandler.interface.js";
import { ProtocolProviderV2 } from "../providers/index.js";
import {
    ActorProposal,
    DisputeV2,
    EboEventV2,
    Epoch,
    Proposal,
    ProposalId,
    ProposalStatus,
    SnapshotParameters,
} from "../types/index.js";
import {
    DisputeEscalatedHandler,
    DisputeResolvedHandler,
    ProposalCreatedHandler,
    ProposalFinalizedHandler,
    WithPledgeActionBaseHandler,
} from "./eventHandlers/index.js";

/**
 * Compare function to sort events chronologically in ascending order by block number
 * and log index.
 *
 * @param e1 EBO event
 * @param e2 EBO event
 * @returns 1 if `e2` is older than `e1`, -1 if `e1` is older than `e2`, 0 otherwise
 */
const EBO_EVENT_COMPARATOR = (e1: EboEventV2, e2: EboEventV2) => {
    if (e1.blockNumber > e2.blockNumber) return 1;
    if (e1.blockNumber < e2.blockNumber) return -1;

    return e1.logIndex - e2.logIndex;
};

/**
 * Actor that handles a singular EBO's proposal through its lifecycle.
 */
// TODO: Implement EBO Actor V2
export class EboActorV2 {
    /**
     * Events queue that keeps the pending events to be processed.
     *
     * **NOTE**: the only place where `pop` should be called for the queue is during
     * `processEvents`
     */
    private readonly eventsQueue: Heap<EboEventV2>;
    private lastEventProcessed: EboEventV2 | undefined;
    private errorHandler: ErrorHandlerV2;

    private proposal: Proposal;
    private readonly parameters: SnapshotParameters;
    private dispute?: DisputeV2;
    /**
     * Creates an `EboActorV2` instance.
     *
     * @param actorProposal the proposal this actor will handle
     * @param protocolProvider a `ProtocolProviderV2` instance
     * @param blockNumberService a `BlockNumberService` instance
     * @param eventProcessingMutex
     * @param logger an `ILogger` instance
     * @param notificationService for notifying about any agent or contract errors
     */
    constructor(
        private readonly actorProposal: ActorProposal,
        private readonly protocolProvider: ProtocolProviderV2,
        private readonly blockNumberService: BlockNumberService,
        private readonly eventProcessingMutex: Mutex,
        private readonly logger: ILogger,
        private readonly notificationService: NotificationService,
    ) {
        this.eventsQueue = new Heap(EBO_EVENT_COMPARATOR);
        this.proposal = this.actorProposal.proposal;
        // actors are created from the proposalCreated event, so we need to set the status to active
        // there's an edge case when we received too many events altogether, so the status might be another one
        // but we will handle the status update through events processing
        this.proposal.status = ProposalStatus.Active;
        this.dispute = this.actorProposal.dispute;
        this.parameters = this.actorProposal.parameters;
        this.errorHandler = new ErrorHandlerV2(this.notificationService, this.logger);
    }

    /**
     * Enqueue events to be processed by the actor.
     *
     * @param event EBO event
     */
    public enqueue(event: EboEventV2): void {
        if (!this.shouldHandleProposal(event.proposalId)) {
            this.logger.error(`The proposal ${event.proposalId} is not handled by this actor.`, {
                proposalId: event.proposalId,
            });

            throw new ProposalMismatch(this.actorProposal.id, event.proposalId);
        }

        if (this.lastEventProcessed) {
            const isPastEvent = EBO_EVENT_COMPARATOR(this.lastEventProcessed, event) >= 0;

            if (isPastEvent) throw new PastEventEnqueueError(this.lastEventProcessed, event);
        }

        this.eventsQueue.push(event);
    }

    /**
     * Process all enqueued events synchronously and sequentially, based on their block numbers.
     *
     * The processing will update the internal state of the actor and, if the event is the most
     * recent one, it will try to react to it by interacting with the protocol smart contracts.
     *
     * 1) New events were fetched, the failing event was handled by another agent and event
     *      processing resumes.
     * 2) No new events were fetched, the failing event processing will be retried until it
     *      succeeds, new events are fetched or the actor expires.
     *
     * The actor is supposed to process the events until the proposal expires somehow.
     *
     * @throws {ProposalMismatch} when an event from another proposal was enqueued in this actor
     */
    public async processEvents(): Promise<void> {
        return await this.eventProcessingMutex.runExclusive(async () => {
            let event: EboEventV2 | undefined;

            while ((event = this.eventsQueue.pop())) {
                this.lastEventProcessed = event;

                try {
                    const wasLastEvent = this.eventsQueue.isEmpty();

                    this.logger.info(
                        `Processing event ${event.name} for proposal ${this.actorProposal.id}...`,
                    );

                    // we just update the proposal or dispute state from the actor
                    await this.updateState(event);

                    if (wasLastEvent) {
                        // `event` is the last and most recent event thus
                        // it needs to run some RPCs to keep 's flow going on
                        await this.onLastEvent(event);
                    }
                } catch (err) {
                    if (err instanceof CustomContractErrorV2) {
                        err.setProcessEventsContext(
                            event,
                            () => {
                                this.eventsQueue.push(event!);
                            },
                            () => {
                                throw err;
                            },
                        );

                        await this.errorHandler.handle(err);

                        return;
                    } else {
                        this.logger.error(`Error processing event ${event.name}: ${err}`, {
                            eventName: event.name,
                        });
                        throw err;
                    }
                }
            }
        });
    }

    /**
     * Check if a proposal can be terminated (ie its status is not changeable by this system), e.g.:
     * * Proposal status is `DisputerLost`, `DisputerWon` or `NoResolution` (dispute resolution)
     * * Proposal status is `Finalized` (accepted proposal)
     *
     * At last, actors must be kept alive until their epoch concludes, to ensure no actor/proposal duplication.
     *
     * @param currentEpoch the epoch to check against actor termination
     * @returns `true` if all entities are settled, otherwise `false`
     */
    public canBeTerminated(currentEpoch: Epoch["number"]): boolean {
        const isPastEpoch = currentEpoch > this.actorProposal.epoch;
        const isRequestFinalized = this.isTerminalStatus(this.proposal.status);

        return isPastEpoch && isRequestFinalized;
    }

    // ================================
    // Private methods
    // ================================

    /**
     * Validate that the actor should handle the proposal by its ID.
     *
     * @param proposalId proposal ID
     * @returns `true` if the actor is handling the proposal, `false` otherwise
     */
    private shouldHandleProposal(proposalId: ProposalId) {
        return this.actorProposal.id === proposalId;
    }

    private async updateState(event: EboEventV2): Promise<void> {
        switch (event.name) {
            case "ProposalCreated":
                break;
            case "ProposalFinalized":
                if (this.proposal.status !== ProposalStatus.Active) {
                    throw new InvalidActorState(
                        `[${event.name}]: Trying to finalize a proposal that isn't Active, Current status: ${this.proposal.status}`,
                    );
                }
                this.proposal.status = ProposalStatus.Finalized;
                break;
            case "ProposalDisputed":
                if (this.proposal.status !== ProposalStatus.Active) {
                    throw new InvalidActorState(
                        `[${event.name}]: Trying to dispute a proposal that isn't Active, Current status: ${this.proposal.status}`,
                    );
                }
                this.proposal.status = ProposalStatus.Disputed;
                this.dispute = await this.protocolProvider.getDisputeByProposalId(
                    event.args.proposalId as ProposalId,
                );
                break;
            case "DisputeEscalated":
                this.proposal.status = ProposalStatus.Escalated;
                break;
            case "DisputeResolved":
                this.proposal.status = event.args.resolutionStatus;
                break;
            case "PledgedForDispute":
                // DisputeEscalated is emitted before last Pledge event
                if (
                    (this.proposal.status !== ProposalStatus.Disputed &&
                        this.proposal.status !== ProposalStatus.Escalated) ||
                    !this.dispute
                )
                    throw new InvalidActorState(
                        `[${event.name}]: Proposal not in Disputed status or Dispute not existent`,
                    );
                this.dispute = await this.protocolProvider.getDisputeByProposalId(
                    event.args.proposalId as ProposalId,
                );
                break;
            case "PledgedAgainstDispute":
                // DisputeEscalated is emitted before last Pledge event
                if (
                    (this.proposal.status !== ProposalStatus.Disputed &&
                        this.proposal.status !== ProposalStatus.Escalated) ||
                    !this.dispute
                )
                    throw new InvalidActorState(
                        `[${event.name}]: Proposal not in Disputed status or Dispute not existent`,
                    );
                this.dispute = await this.protocolProvider.getDisputeByProposalId(
                    event.args.proposalId as ProposalId,
                );
                break;
            default:
                const eventName = (event as EboEventV2)?.name || "Unknown";
                throw new MissingEventHandler(eventName);
        }
    }

    /**
     * Handle the last known event and triggers reactive interactions with smart contracts.
     *
     * A basic example would be reacting to a pledge for a dispute.
     *
     * @param event EBO event
     */
    private async onLastEvent(event: EboEventV2) {
        const eventHandlersDependencies = {
            actorProposal: {
                id: this.actorProposal.id,
                epoch: this.actorProposal.epoch,
                chainId: this.actorProposal.chainId,
                proposal: this.proposal,
                dispute: this.dispute,
                parameters: this.parameters,
            },
            protocolProvider: this.protocolProvider,
            blockNumberService: this.blockNumberService,
            logger: this.logger,
        };
        let handler: IEventHandler<EboEventV2["name"]>;
        switch (event.name) {
            case "ProposalCreated":
                handler = new ProposalCreatedHandler(eventHandlersDependencies);
                break;

            case "ProposalFinalized":
                handler = new ProposalFinalizedHandler(eventHandlersDependencies);
                break;

            case "ProposalDisputed":
                handler = new WithPledgeActionBaseHandler(eventHandlersDependencies);
                break;

            case "PledgedForDispute":
                handler = new WithPledgeActionBaseHandler(eventHandlersDependencies);
                break;

            case "PledgedAgainstDispute":
                handler = new WithPledgeActionBaseHandler(eventHandlersDependencies);
                break;

            case "DisputeResolved":
                handler = new DisputeResolvedHandler(eventHandlersDependencies);
                break;

            case "DisputeEscalated":
                handler = new DisputeEscalatedHandler(eventHandlersDependencies);
                break;
            default:
                const eventName = (event as EboEventV2)?.name || "Unknown";
                throw new MissingEventHandler(eventName);
        }

        await handler.run(event);
    }

    /**
     * Triggers time-based interactions with smart contracts. This handles window-based
     * checks like dispute or pledge window expiration for finalizing proposals or resolving disputes.
     *
     * @param atTimestamp the timestamp of the last block
     */
    public async onLastBlockUpdated(atTimestamp: UnixTimestamp): Promise<void> {
        if (this.canFinalizeRequest(atTimestamp)) {
            await this.finalizeRequest();
        } else if (this.canResolveDispute(atTimestamp)) {
            await this.resolveDispute();
        } else if (this.shouldEvaluatePledging(atTimestamp)) {
            await this.pledgeDispute();
        }
    }

    /**
     * Finalizes the request by calling the finalize method on the protocol provider.
     * This should only be called when canFinalizeRequest is true.
     */
    private async finalizeRequest(): Promise<void> {
        try {
            await this.protocolProvider.write.finalize(this.actorProposal.id);
            this.logger.info(`Proposal ${this.actorProposal.id} finalized`);
        } catch (error) {
            if (error instanceof CustomContractErrorV2) {
                this.logger.warn(`Finalizing request reverted: ${error.name}`, {
                    requestId: this.actorProposal.id,
                });

                error.setContext({
                    proposal: this.proposal,
                    dispute: this.dispute,
                    parameters: this.parameters,
                });

                await this.errorHandler.handle(error);
            } else {
                this.logger.error(
                    `Failed to finalize proposal ${this.actorProposal.id}: ${error}`,
                    {
                        proposalId: this.actorProposal.id,
                        error,
                    },
                );
                throw error;
            }
        }
    }

    /**
     * Resolves a dispute by calling the resolve method on the protocol provider.
     * This should only be called for disputed proposals where the pledge window has passed.
     */
    private async resolveDispute(): Promise<void> {
        try {
            await this.protocolProvider.write.resolve(this.actorProposal.id);
            this.logger.info(`Proposal ${this.actorProposal.id} resolved`);
        } catch (error) {
            if (error instanceof CustomContractErrorV2) {
                this.logger.warn(`Resolving dispute reverted: ${error.name}`, {
                    requestId: this.actorProposal.id,
                });

                error.setContext({
                    proposal: this.proposal,
                    dispute: this.dispute,
                    parameters: this.parameters,
                });

                await this.errorHandler.handle(error);
            } else {
                this.logger.error(
                    `Failed to resolve dispute for proposal ${this.actorProposal.id}: ${error}`,
                    {
                        proposalId: this.actorProposal.id,
                        error,
                    },
                );
                throw error;
            }
        }
    }

    /**
     * Pledges for or against a dispute.
     * This should only be called for disputed proposals where the pledge window has passed.
     */
    private async pledgeDispute(): Promise<void> {
        try {
            // First, refresh our dispute data to ensure we have the latest state
            this.dispute = await this.protocolProvider.getDisputeByProposalId(
                this.actorProposal.id,
            );

            if (!this.dispute) return;

            // Create handler dependencies
            const handlerDependencies = {
                actorProposal: {
                    id: this.actorProposal.id,
                    epoch: this.actorProposal.epoch,
                    chainId: this.actorProposal.chainId,
                    proposal: this.proposal,
                    dispute: this.dispute,
                    parameters: this.parameters,
                },
                protocolProvider: this.protocolProvider,
                blockNumberService: this.blockNumberService,
                logger: this.logger,
            };

            const pledgeHandler = new WithPledgeActionBaseHandler(handlerDependencies);

            // Create a minimal synthetic event
            // WithPledgeActionBaseHandler only needs the event.name for logging
            // It doesn't use other fields from the event in its core logic
            const mockEvent: EboEventV2 = {
                name: "ProposalDisputed",
                blockNumber: 0n,
                logIndex: 0,
                timestamp: 0n as UnixTimestamp,
                proposalId: this.actorProposal.id,
                args: {
                    proposalId: this.actorProposal.id,
                },
            };

            await pledgeHandler.run(mockEvent);
        } catch (error) {
            if (error instanceof CustomContractErrorV2) {
                this.logger.warn(`Pledge evaluation failed: ${error.name}`, {
                    proposalId: this.actorProposal.id,
                });

                error.setContext({
                    proposal: this.proposal,
                    dispute: this.dispute,
                    parameters: this.parameters,
                });

                await this.errorHandler.handle(error);
            } else {
                this.logger.error(
                    `Failed to evaluate pledge opportunity for proposal ${this.actorProposal.id}: ${error}`,
                    { proposalId: this.actorProposal.id, error },
                );
            }
        }
    }

    /**
     * Checks if the proposal can be finalized.
     *
     * @param atTimestamp the timestamp of the last block
     * @returns `true` if the proposal can be finalized, `false` otherwise
     */
    private canFinalizeRequest(atTimestamp: UnixTimestamp): boolean {
        const disputeWindowEnd = this.proposal.createdAt + this.parameters.disputeWindow;
        return this.proposal.status === ProposalStatus.Active && atTimestamp >= disputeWindowEnd;
    }

    /**
     * Checks if the dispute can be resolved.
     *
     * @param atTimestamp the timestamp of the last block
     * @returns `true` if the dispute can be resolved, `false` otherwise
     */
    private canResolveDispute(atTimestamp: UnixTimestamp): boolean {
        // If no dispute or proposal is not in Disputed status, cannot resolve
        if (!this.dispute || this.proposal.status !== ProposalStatus.Disputed) {
            return false;
        }

        const pledgeWindowEnd = this.dispute.createdAt + this.parameters.pledgeWindow;
        const pledgeRefreshWindowEnd =
            this.dispute.lastPledgeTimestamp + this.parameters.pledgeRefreshWindow;
        let pledgeWindowHasPassed = false;
        if (atTimestamp >= pledgeWindowEnd) {
            pledgeWindowHasPassed = atTimestamp >= pledgeRefreshWindowEnd;
        }

        return pledgeWindowHasPassed;
    }

    /**
     * Checks if we should evaluate pledging.
     *
     * @param atTimestamp the timestamp of the last block
     * @returns `true` if we should evaluate pledging, `false` otherwise
     */
    private shouldEvaluatePledging(atTimestamp: UnixTimestamp): boolean {
        return (
            this.proposal.status === ProposalStatus.Disputed &&
            this.dispute !== undefined &&
            !this.hasPledgeWindowPassed(atTimestamp)
        );
    }

    private hasPledgeWindowPassed(atTimestamp: UnixTimestamp): boolean {
        const pledgeWindowEnd = this.dispute!.createdAt + this.parameters.pledgeWindow;
        if (atTimestamp < pledgeWindowEnd) {
            return false;
        }

        return (
            atTimestamp >= this.dispute!.lastPledgeTimestamp + this.parameters.pledgeRefreshWindow
        );
    }

    /**
     * Check if the proposal status is terminal.
     *
     * @param status proposal status
     * @returns `true` if the status is terminal, `false` otherwise
     */
    private isTerminalStatus(status: ProposalStatus) {
        return [
            ProposalStatus.DisputerLost,
            ProposalStatus.DisputerWon,
            ProposalStatus.NoResolution,
            ProposalStatus.Finalized,
        ].includes(status);
    }
}
