import { mockLogger } from "./logger.mocks.js";

export default {
    mockLogger,
};
