import { BlockNumberService } from "@ebo-agent/blocknumber";
import { ILogger, NotificationService } from "@ebo-agent/shared";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { ProposalAlreadyHandled } from "../../src/exceptions/index.js";
import { ProtocolProviderV2 } from "../../src/providers/index.js";
import { EboActorsManagerV2, EboActorV2 } from "../../src/services/index.js";
import {
    ActorProposal,
    Proposal,
    ProposalId,
    ProposalStatus,
    SnapshotParameters,
} from "../../src/types/index.js";

describe("EboActorsManagerV2", () => {
    let manager: EboActorsManagerV2;
    let mockProtocolProvider: ProtocolProviderV2;
    let mockBlockNumberService: BlockNumberService;
    let mockLogger: ILogger;
    let mockNotifier: NotificationService;
    let mockProposal: ActorProposal;

    beforeEach(() => {
        manager = new EboActorsManagerV2();

        mockProtocolProvider = {} as ProtocolProviderV2;
        mockBlockNumberService = {} as BlockNumberService;
        mockLogger = {
            info: vi.fn(),
            error: vi.fn(),
            debug: vi.fn(),
            warn: vi.fn(),
        } as unknown as ILogger;
        mockNotifier = {} as NotificationService;

        mockProposal = {
            id: BigInt("0x123") as ProposalId,
            epoch: BigInt(1),
            chainId: "eip155:1",
            severity: 1,
            proposal: {
                status: ProposalStatus.Active,
            } as Proposal,
            parameters: {} as SnapshotParameters,
        } as ActorProposal;
    });

    describe("getProposalIds", () => {
        it("returns empty array when no actors exist", () => {
            expect(manager.getProposalIds()).toEqual([]);
        });

        it("returns array of proposal IDs when actors exist", () => {
            manager.createActor(
                mockProposal,
                mockProtocolProvider,
                mockBlockNumberService,
                mockLogger,
                mockNotifier,
            );

            expect(manager.getProposalIds()).toEqual([mockProposal.id]);
        });
    });

    describe("createActor", () => {
        it("creates and returns new actor instance", () => {
            const actor = manager.createActor(
                mockProposal,
                mockProtocolProvider,
                mockBlockNumberService,
                mockLogger,
                mockNotifier,
            );

            expect(actor).toBeInstanceOf(EboActorV2);
            expect(manager.getActor(mockProposal.id)).toBe(actor);
        });

        it("throws ProposalAlreadyHandled when creating duplicate actor", () => {
            manager.createActor(
                mockProposal,
                mockProtocolProvider,
                mockBlockNumberService,
                mockLogger,
                mockNotifier,
            );

            expect(() =>
                manager.createActor(
                    mockProposal,
                    mockProtocolProvider,
                    mockBlockNumberService,
                    mockLogger,
                    mockNotifier,
                ),
            ).toThrow(ProposalAlreadyHandled);
        });
    });

    describe("getActor", () => {
        it("returns undefined for non-existent actor", () => {
            expect(manager.getActor(BigInt("0xabc") as ProposalId)).toBeUndefined();
        });

        it("returns correct actor for existing proposal ID", () => {
            const actor = manager.createActor(
                mockProposal,
                mockProtocolProvider,
                mockBlockNumberService,
                mockLogger,
                mockNotifier,
            );

            expect(manager.getActor(mockProposal.id)).toBe(actor);
        });
    });

    describe("deleteActor", () => {
        it("returns false when deleting non-existent actor", () => {
            expect(manager.deleteActor(BigInt("0xabc") as ProposalId)).toBe(false);
        });

        it("returns true and removes actor when deleting existing actor", () => {
            manager.createActor(
                mockProposal,
                mockProtocolProvider,
                mockBlockNumberService,
                mockLogger,
                mockNotifier,
            );

            expect(manager.deleteActor(mockProposal.id)).toBe(true);
            expect(manager.getActor(mockProposal.id)).toBeUndefined();
        });
    });
});
