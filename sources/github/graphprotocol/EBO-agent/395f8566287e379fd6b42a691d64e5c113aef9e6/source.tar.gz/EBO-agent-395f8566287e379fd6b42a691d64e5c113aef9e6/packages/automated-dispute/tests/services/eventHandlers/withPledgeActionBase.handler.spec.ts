import { BlockNumberService } from "@ebo-agent/blocknumber";
import { Caip2ChainId, ILogger, UnixTimestamp } from "@ebo-agent/shared";
import { Block } from "viem";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import {
    CustomContractErrorV2,
    ErrorFactoryV2,
    InvalidActorState,
} from "../../../src/exceptions/index.js";
import { ProtocolProviderV2 } from "../../../src/external.js";
import { WithPledgeActionBaseHandler } from "../../../src/services/eventHandlers/withPledgeActionBase.handler.js";
import {
    ActorProposal,
    DisputeV2,
    EboEventV2,
    ProposalId,
    ProposalStatus,
} from "../../../src/types/index.js";
import { mockLogger } from "../../mocks/logger.mocks.js";

describe("WithPledgeActionBaseHandler", () => {
    let handler: WithPledgeActionBaseHandler<"ProposalDisputed">;
    let logger: ILogger;
    let protocolProvider: ProtocolProviderV2;
    let blockNumberService: BlockNumberService;
    let actorProposal: ActorProposal;

    // Helper to create a mock block with the required properties for testing
    const createMockBlock = (timestamp: bigint): Block<bigint, false, "finalized"> =>
        ({
            number: 123456n,
            timestamp,
        }) as unknown as Block<bigint, false, "finalized">;

    beforeEach(() => {
        logger = mockLogger();

        protocolProvider = {
            getAccountAddress: vi
                .fn()
                .mockReturnValue("0xd133BBBC4aa80F365A2595Fe10B84a3Aff0a0ac1"),
            getCurrentEpoch: vi.fn(),
            pledgeForDispute: vi.fn(),
            pledgeAgainstDispute: vi.fn(),
            getLastFinalizedBlock: vi.fn().mockResolvedValue(createMockBlock(1000n)), // Default timestamp same as proposal creation
        } as unknown as ProtocolProviderV2;

        blockNumberService = {
            getEpochBlockNumber: vi.fn(),
        } as unknown as BlockNumberService;

        actorProposal = {
            id: BigInt(1) as ProposalId,
            chainId: "eip155:1" as Caip2ChainId,
            proposal: {
                createdAt: 1000n as UnixTimestamp,
                epoch: 1n,
                chainId: "eip155:1" as Caip2ChainId,
                blockNumber: 123456n,
                proposer: "0xd133BBBC4aa80F365A2595Fe10B84a3Aff0a0ac1",
                parametersSnapshotId: 1n,
                status: ProposalStatus.Active,
            },
            parameters: {
                disputeWindow: 3600n,
                proposalBondSize: 500n,
                pledgeBondSize: 500n,
                minThawingPeriod: 0n,
                pledgeWindow: 3600n, // 1 hour window
                pledgeRefreshWindow: 10800n, // 3 hours refresh
                maxNumberOfPledges: 4n,
            },
            dispute: {
                disputer: "0xd133BBBC4aa80F365A2595Fe10B84a3Aff0a0ac1",
                createdAt: 1000n as UnixTimestamp,
                lastPledgeTimestamp: 11000n as UnixTimestamp,
                totalPledgesForDispute: 0n,
                totalPledgesAgainstDispute: 0n,
                rewardPerWinningPledge: 0n,
            } as DisputeV2,
            epoch: 1n,
        };

        handler = new WithPledgeActionBaseHandler({
            actorProposal,
            protocolProvider,
            blockNumberService,
            logger,
        });

        vi.useFakeTimers();
    });

    afterEach(() => {
        vi.clearAllMocks();
        vi.useRealTimers();
    });

    it("doesn't pledge when pledge window has passed", async () => {
        // Set blockchain timestamp to be beyond the pledge window (lastPledgeTimestamp + pledgeRefreshWindow)
        const pledgeWindowPassedTimestamp =
            actorProposal.dispute!.lastPledgeTimestamp +
            actorProposal.parameters.pledgeRefreshWindow +
            1n;
        vi.spyOn(protocolProvider, "getLastFinalizedBlock").mockResolvedValue(
            createMockBlock(pledgeWindowPassedTimestamp),
        );

        const event: EboEventV2 & { name: "ProposalDisputed" } = {
            name: "ProposalDisputed",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId: BigInt(1) as ProposalId,
            args: {
                proposalId: BigInt(1) as ProposalId,
            },
        };

        await handler.run(event);

        expect(protocolProvider.pledgeForDispute).not.toHaveBeenCalled();
        expect(protocolProvider.pledgeAgainstDispute).not.toHaveBeenCalled();
        expect(logger.info).toHaveBeenCalledWith(
            "ProposalDisputed event received but pledge window has passed.",
            { proposalId: BigInt(1) },
        );
    });

    it("pledges for when epoch block number is different", async () => {
        vi.spyOn(protocolProvider, "getCurrentEpoch").mockResolvedValue({
            startTimestamp: 1000n as UnixTimestamp,
            firstBlockNumber: 123400n,
            number: 1n,
        });
        // Return a different block number to make dispute valid (proposed != expected)
        vi.spyOn(blockNumberService, "getEpochBlockNumber").mockResolvedValue(BigInt(999999));

        vi.spyOn(protocolProvider, "getLastFinalizedBlock").mockResolvedValue(
            createMockBlock(1500n),
        );

        const event: EboEventV2 & { name: "ProposalDisputed" } = {
            name: "ProposalDisputed",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId: BigInt(1) as ProposalId,
            args: {
                proposalId: BigInt(1) as ProposalId,
            },
        };

        await handler.run(event);

        expect(protocolProvider.pledgeForDispute).toHaveBeenCalledWith(
            BigInt(1),
            "0xd133BBBC4aa80F365A2595Fe10B84a3Aff0a0ac1",
        );
        expect(logger.info).toHaveBeenCalledWith("Pledged 'for' dispute on proposal 1.", {
            proposalId: BigInt(1),
        });
    });

    it("pledges against when epoch block number is the same", async () => {
        vi.spyOn(protocolProvider, "getCurrentEpoch").mockResolvedValue({
            startTimestamp: 1000n as UnixTimestamp,
            firstBlockNumber: 123400n,
            number: 1n,
        });
        // Return the same block number to make dispute invalid (proposed == expected)
        vi.spyOn(blockNumberService, "getEpochBlockNumber").mockResolvedValue(
            actorProposal.proposal.blockNumber,
        );

        vi.spyOn(protocolProvider, "getLastFinalizedBlock").mockResolvedValue(
            createMockBlock(1500n),
        );

        const event: EboEventV2 & { name: "ProposalDisputed" } = {
            name: "ProposalDisputed",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId: BigInt(1) as ProposalId,
            args: {
                proposalId: BigInt(1) as ProposalId,
            },
        };

        await handler.run(event);

        expect(protocolProvider.pledgeAgainstDispute).toHaveBeenCalledWith(
            BigInt(1),
            "0xd133BBBC4aa80F365A2595Fe10B84a3Aff0a0ac1",
        );
        expect(logger.info).toHaveBeenCalledWith("Pledged 'against' dispute on proposal 1.", {
            proposalId: BigInt(1),
        });
    });

    it("doesn't pledge 'against' when it's already winning and dispute is invalid", async () => {
        // Set total pledges so that against is already winning
        actorProposal.dispute!.totalPledgesAgainstDispute = 2n;
        actorProposal.dispute!.totalPledgesForDispute = 1n;

        vi.spyOn(protocolProvider, "getCurrentEpoch").mockResolvedValue({
            startTimestamp: 1000n as UnixTimestamp,
            firstBlockNumber: 123400n,
            number: 1n,
        });
        vi.spyOn(blockNumberService, "getEpochBlockNumber").mockResolvedValue(
            actorProposal.proposal.blockNumber,
        );

        vi.spyOn(protocolProvider, "getLastFinalizedBlock").mockResolvedValue(
            createMockBlock(1500n),
        );

        const event: EboEventV2 & { name: "ProposalDisputed" } = {
            name: "ProposalDisputed",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId: BigInt(1) as ProposalId,
            args: {
                proposalId: BigInt(1) as ProposalId,
            },
        };

        await handler.run(event);

        expect(protocolProvider.pledgeAgainstDispute).not.toHaveBeenCalled();
        expect(logger.info).toHaveBeenCalledWith(
            "Cannot pledge 'against' dispute. 'against' is already winning.",
            { proposalId: BigInt(1) },
        );
    });

    it("doesn't pledge 'for' when it's already winning and dispute is valid", async () => {
        // Set total pledges so that for is already winning
        actorProposal.dispute!.totalPledgesForDispute = 1n;
        actorProposal.dispute!.totalPledgesAgainstDispute = 0n;

        vi.spyOn(protocolProvider, "getCurrentEpoch").mockResolvedValue({
            startTimestamp: 1000n as UnixTimestamp,
            firstBlockNumber: 123400n,
            number: 1n,
        });
        vi.spyOn(blockNumberService, "getEpochBlockNumber").mockResolvedValue(999999n);

        vi.spyOn(protocolProvider, "getLastFinalizedBlock").mockResolvedValue(
            createMockBlock(1500n),
        );

        const event: EboEventV2 & { name: "ProposalDisputed" } = {
            name: "ProposalDisputed",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId: BigInt(1) as ProposalId,
            args: {
                proposalId: BigInt(1) as ProposalId,
            },
        };

        await handler.run(event);

        expect(protocolProvider.pledgeForDispute).not.toHaveBeenCalled();
        expect(protocolProvider.pledgeAgainstDispute).not.toHaveBeenCalled();
        expect(logger.info).toHaveBeenCalledWith(
            "Cannot pledge 'for' dispute. 'for' is already winning.",
            { proposalId: BigInt(1) },
        );
    });

    it("throws if dispute is undefined", async () => {
        actorProposal.dispute = undefined;

        const event: EboEventV2 & { name: "ProposalDisputed" } = {
            name: "ProposalDisputed",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId: BigInt(1) as ProposalId,
            args: {
                proposalId: BigInt(1) as ProposalId,
            },
        };

        await expect(handler.run(event)).rejects.toThrow(InvalidActorState);
    });

    it("handles custom contract revert errors when pledging for a dispute", async () => {
        vi.spyOn(protocolProvider, "getCurrentEpoch").mockResolvedValue({
            startTimestamp: 1000n as UnixTimestamp,
            firstBlockNumber: 123400n,
            number: 1n,
        });
        vi.spyOn(blockNumberService, "getEpochBlockNumber").mockResolvedValue(BigInt(999999));

        vi.spyOn(protocolProvider, "getLastFinalizedBlock").mockResolvedValue(
            createMockBlock(1500n),
        );

        // Create a mock contract revert error
        const revertError = ErrorFactoryV2.createError("EBOPledge_Pledge_CannotPledgeIfWinning");

        vi.spyOn(protocolProvider, "pledgeForDispute").mockRejectedValueOnce(revertError);

        const event: EboEventV2 & { name: "ProposalDisputed" } = {
            name: "ProposalDisputed",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId: BigInt(1) as ProposalId,
            args: {
                proposalId: BigInt(1) as ProposalId,
            },
        };

        try {
            await handler.run(event);
        } catch (error) {
            expect(error).toBeInstanceOf(CustomContractErrorV2);
            expect((error as CustomContractErrorV2).name).toBe(
                "EBOPledge_Pledge_CannotPledgeIfWinning",
            );
            expect((error as CustomContractErrorV2).context).toEqual({
                proposal: actorProposal.proposal,
                parameters: actorProposal.parameters,
                dispute: actorProposal.dispute,
                event,
            });
        }
    });

    it("handles custom contract error when pledging against a dispute", async () => {
        vi.spyOn(protocolProvider, "getCurrentEpoch").mockResolvedValue({
            startTimestamp: 1000n as UnixTimestamp,
            firstBlockNumber: 123400n,
            number: 1n,
        });
        // Return same block number to make dispute invalid, triggering pledge against
        vi.spyOn(blockNumberService, "getEpochBlockNumber").mockResolvedValue(
            actorProposal.proposal.blockNumber,
        );

        vi.spyOn(protocolProvider, "getLastFinalizedBlock").mockResolvedValue(
            createMockBlock(1500n),
        );

        const revertError = ErrorFactoryV2.createError("EBOPledge_Pledge_PledgeWindowOver");

        vi.spyOn(protocolProvider, "pledgeAgainstDispute").mockRejectedValueOnce(revertError);

        const event: EboEventV2 & { name: "ProposalDisputed" } = {
            name: "ProposalDisputed",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId: BigInt(1) as ProposalId,
            args: {
                proposalId: BigInt(1) as ProposalId,
            },
        };

        try {
            await handler.run(event);
        } catch (error) {
            expect(error).toBeInstanceOf(CustomContractErrorV2);
            expect((error as CustomContractErrorV2).name).toBe("EBOPledge_Pledge_PledgeWindowOver");
            expect((error as CustomContractErrorV2).context).toEqual({
                proposal: actorProposal.proposal,
                parameters: actorProposal.parameters,
                dispute: actorProposal.dispute,
                event,
            });
        }
    });

    it("handles other errors", async () => {
        vi.spyOn(protocolProvider, "getCurrentEpoch").mockResolvedValue({
            startTimestamp: 1000n as UnixTimestamp,
            firstBlockNumber: 123400n,
            number: 1n,
        });
        vi.spyOn(blockNumberService, "getEpochBlockNumber").mockResolvedValue(BigInt(999999));

        vi.spyOn(protocolProvider, "getLastFinalizedBlock").mockResolvedValue(
            createMockBlock(1500n),
        );

        vi.spyOn(protocolProvider, "pledgeForDispute").mockRejectedValue(new Error("Test error"));

        const event: EboEventV2 & { name: "ProposalDisputed" } = {
            name: "ProposalDisputed",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId: BigInt(1) as ProposalId,
            args: {
                proposalId: BigInt(1) as ProposalId,
            },
        };

        await expect(handler.run(event)).rejects.toThrow("Test error");
    });
});
