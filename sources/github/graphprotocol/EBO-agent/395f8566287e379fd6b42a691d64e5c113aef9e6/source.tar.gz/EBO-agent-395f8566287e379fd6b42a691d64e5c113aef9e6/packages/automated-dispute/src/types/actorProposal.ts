import type { Caip2ChainId } from "@ebo-agent/shared";

import type { DisputeV2, Proposal, ProposalId, SnapshotParameters } from "./index.js";

export type ActorProposal = {
    id: ProposalId;
    epoch: bigint;
    chainId: Caip2ChainId;
    proposal: Proposal;
    parameters: SnapshotParameters;
    dispute?: DisputeV2;
};
