import { EboEventV2, ProposalStatus } from "../../types/index.js";
import { BaseEventHandler } from "./base.handler.js";

/**
 * @description Handles the DisputeResolved event
 * @extends BaseEventHandler
 *
 * Logs the resolved proposal id and the resolution status.
 */
export class DisputeResolvedHandler extends BaseEventHandler<"DisputeResolved"> {
    async run(event: Extract<EboEventV2, { name: "DisputeResolved" }>): Promise<void> {
        this.logger.info(
            `Proposal ${event.proposalId} dispute has been resolved with status ${ProposalStatus[event.args.resolutionStatus]}.`,
            {
                proposalId: event.proposalId,
                resolutionStatus: event.args.resolutionStatus,
            },
        );
    }
}
