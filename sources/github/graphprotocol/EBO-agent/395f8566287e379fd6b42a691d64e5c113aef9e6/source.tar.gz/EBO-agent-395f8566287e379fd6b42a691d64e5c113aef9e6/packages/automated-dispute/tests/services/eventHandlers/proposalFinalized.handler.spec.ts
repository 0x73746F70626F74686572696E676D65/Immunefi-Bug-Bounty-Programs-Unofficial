import { BlockNumberService } from "@ebo-agent/blocknumber";
import { Caip2ChainId, ILogger, UnixTimestamp } from "@ebo-agent/shared";
import { keccak256, stringToBytes } from "viem";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { ProposalFinalizedHandler } from "../../../src/services/eventHandlers/proposalFinalized.handler.js";
import { EboEventV2, ProposalId } from "../../../src/types/index.js";
import mocks from "../../mocks/index.js";

describe("ProposalFinalizedHandler", () => {
    let handler: ProposalFinalizedHandler;
    let logger: ILogger;
    let protocolProvider: any;
    let blockNumberService: BlockNumberService;
    let actorProposal: any;

    beforeEach(() => {
        logger = mocks.mockLogger();

        protocolProvider = {
            getAccountAddress: vi.fn().mockReturnValue("0xuser"),
        };

        blockNumberService = {} as BlockNumberService;

        actorProposal = {
            id: 1n as ProposalId,
            chainId: "eip155:1" as Caip2ChainId,
            proposal: {
                createdAt: 1000n as UnixTimestamp,
            },
            parameters: {
                disputeWindow: 3600n,
            },
            epoch: 1n,
        };

        handler = new ProposalFinalizedHandler({
            actorProposal,
            protocolProvider,
            blockNumberService,
            logger,
        });
    });

    it("logs when a proposal is finalized", async () => {
        const proposalId = 1n as ProposalId;
        const event: EboEventV2 & { name: "ProposalFinalized" } = {
            name: "ProposalFinalized",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId,
            args: {
                proposalId,
                blockNumber: 123456n,
                epoch: 1n,
                chainId: keccak256(stringToBytes("eip155:1")),
            },
        };

        await handler.run(event);

        expect(logger.info).toHaveBeenCalledWith(
            `Proposal ${event.args.proposalId} has been finalized.`,
            { proposalId: event.args.proposalId },
        );
    });
});
