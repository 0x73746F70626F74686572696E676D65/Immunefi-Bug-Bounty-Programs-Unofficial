import { isNativeError } from "util/types";
import { ILogger, stringify } from "@ebo-agent/shared";

import type { IEboParametersRegistry } from "../interfaces/index.js";
import type { SnapshotParameters } from "../types/index.js";
import { ProtocolProviderV2 } from "../providers/index.js";

export class EboParametersRegistry implements IEboParametersRegistry {
    private parameters: Map<bigint, SnapshotParameters> = new Map();

    constructor(
        private readonly protocolProvider: ProtocolProviderV2,
        private readonly logger: ILogger,
    ) {}

    /** @inheritdoc */
    public async getParameters(snapshotId: bigint): Promise<SnapshotParameters | undefined> {
        if (this.parameters.has(snapshotId)) {
            return this.parameters.get(snapshotId);
        }

        const parameters = await this.fetchParameters(snapshotId);

        if (parameters !== undefined) {
            this.parameters.set(snapshotId, parameters);
        }

        return parameters;
    }

    /** @inheritdoc */
    public setParameters(snapshotId: bigint, parameters: SnapshotParameters): void {
        this.parameters.set(snapshotId, parameters);
    }

    /** @inheritdoc */
    public clear(): void {
        this.parameters.clear();
    }

    /**
     * Fetch the parameters for a given snapshot ID.
     *
     * @param snapshotId the snapshot ID
     * @returns the parameters for the given snapshot ID, or `undefined` if no parameters are available
     */
    private async fetchParameters(snapshotId: bigint): Promise<SnapshotParameters | undefined> {
        try {
            return await this.protocolProvider.getSnapshotParameters(snapshotId);
        } catch (error: unknown) {
            const errorMessage = isNativeError(error) ? error.message : stringify(error);
            this.logger.error(
                `Failed to fetch parameters for snapshot ID ${snapshotId}: ${errorMessage}`,
            );
            throw error;
        }
    }
}
