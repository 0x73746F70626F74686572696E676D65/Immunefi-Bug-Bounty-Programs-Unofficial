import { createLogger, format, Logform, transports, Logger as WinstonLogger } from "winston";
import Transport from "winston-transport";

import { ILogger } from "../index.js";

type LogLevel = "error" | "warn" | "info" | "debug";

const validLogLevels: LogLevel[] = ["error", "warn", "info", "debug"];

/**
 * Logger class that wraps the Winston logger.
 * @class Logger
 * @implements {ILogger}
 */
export class Logger implements ILogger {
    private logger: WinstonLogger;
    private static instance: Logger | null;
    public readonly level: LogLevel;

    private constructor(transportsArray?: Transport[]) {
        this.level = this.isValidLogLevel(process.env.LOG_LEVEL) ? process.env.LOG_LEVEL : "info";
        this.logger = createLogger({
            level: this.level,
            format: format.combine(
                format.timestamp(),
                format.errors({ stack: true }),
                format((info: Logform.TransformableInfo) => {
                    return {
                        ...info,
                        level: this.isValidLogLevel(info.level) ? info.level : "info",
                        data: Object.keys(info).reduce((acc: Record<string, unknown>, key) => {
                            if (!["timestamp", "level", "message", "stack"].includes(key)) {
                                acc[key] = info[key];
                            }
                            return acc;
                        }, {}),
                    };
                })(),
                format.json(),
            ),
            transports: transportsArray || [
                new transports.Console({
                    handleExceptions: true,
                    handleRejections: true,
                    stderrLevels: ["error"],
                    consoleWarnLevels: ["warn"],
                }),
            ],
        });
    }

    /**
     * Returns the instance of the Logger class.
     * @returns The instance of the Logger class.
     */
    public static getInstance(): Logger {
        if (!Logger.instance) {
            Logger.instance = new Logger();
        }
        return Logger.instance;
    }

    isValidLogLevel(level: string | undefined): level is LogLevel {
        return validLogLevels.includes(level as LogLevel);
    }

    info(message: string, meta?: unknown) {
        this.logger.info(message, meta);
    }

    error(error: Error | string, meta?: unknown): void {
        const metaData = meta ? (meta as object) : {};
        if (error instanceof Error) {
            this.logger.error(error.message, { stack: error.stack, ...metaData });
        } else {
            this.logger.error(error, metaData);
        }
    }

    warn(message: string, meta?: unknown) {
        this.logger.warn(message, meta);
    }

    debug(message: string, meta?: unknown) {
        this.logger.debug(message, meta);
    }
}
