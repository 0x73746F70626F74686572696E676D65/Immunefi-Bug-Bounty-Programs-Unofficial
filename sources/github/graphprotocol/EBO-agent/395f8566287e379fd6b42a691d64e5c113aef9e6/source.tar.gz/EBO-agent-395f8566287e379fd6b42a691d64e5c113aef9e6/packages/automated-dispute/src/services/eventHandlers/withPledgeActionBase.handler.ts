import { CustomContractErrorV2, InvalidActorState } from "../../exceptions/index.js";
import { DisputeV2, EboEventV2, ProposalId, SnapshotParameters } from "../../types/index.js";
import { BaseEventHandler } from "./index.js";

type PledgeCounts = {
    sidePledges: bigint;
    oppositePledges: bigint;
};

/**
 * @description Base class for handlers that pledge for or against a dispute
 * @extends BaseEventHandler
 *
 * Handles the logic of pledging for or against a dispute if conditions are met.
 * Note: in case of requiring any custom logic, this class should be extended.
 */
export class WithPledgeActionBaseHandler<T extends EboEventV2["name"]> extends BaseEventHandler<T> {
    override async run(event: Extract<EboEventV2, { name: T }>): Promise<void> {
        const { proposal, id: proposalId, parameters, dispute } = this.actorProposal;

        if (!dispute) {
            throw new InvalidActorState(
                `Dispute state for Proposal ${this.actorProposal.id} was not found.`,
            );
        }

        if (await this.hasPledgeWindowPassed(dispute, parameters)) {
            this.logger.info(`${event.name} event received but pledge window has passed.`, {
                proposalId,
            });

            return;
        }

        const expectedBlockNumber = await this.getEpochBlockNumber();
        const isValidDispute = this.isValidDispute(proposal.blockNumber, expectedBlockNumber);

        const side = isValidDispute ? "for" : "against";
        const { sidePledges, oppositePledges } = this.getPledgeCounts(side, dispute);

        if (sidePledges > oppositePledges) {
            this.logger.info(`Cannot pledge '${side}' dispute. '${side}' is already winning.`, {
                proposalId,
            });
            return;
        }

        if (sidePledges < parameters.maxNumberOfPledges) {
            await this.pledge(side, proposalId, event);
        } else {
            this.logger.warn(`Skipping pledge '${side}' dispute. Max number of pledges reached`, {
                side,
                proposalId,
            });
        }
    }

    /**
     * @description Pledges for or against a dispute
     * @param {string} side - The side to pledge for or against
     * @param {ProposalId} proposalId - The proposal ID
     * @param {DisputeV2} dispute - The dispute to pledge for or against
     */
    protected async pledge(side: "for" | "against", proposalId: ProposalId, event: EboEventV2) {
        const pledger = this.protocolProvider.getAccountAddress();

        try {
            if (side === "for") await this.protocolProvider.pledgeForDispute(proposalId, pledger);
            else await this.protocolProvider.pledgeAgainstDispute(proposalId, pledger);

            this.logger.info(`Pledged '${side}' dispute on proposal ${proposalId}.`, {
                proposalId,
            });
        } catch (err) {
            if (err instanceof CustomContractErrorV2) {
                err.setContext({
                    proposal: this.actorProposal.proposal,
                    parameters: this.actorProposal.parameters,
                    dispute: this.actorProposal.dispute,
                    event,
                });
            }
            throw err;
        }
    }

    /**
     * @description Gets the pledge counts for a given side
     * @param {string} side - The side to get the pledge counts for
     * @param {DisputeV2} dispute - The dispute to get the pledge counts for
     * @returns {PledgeCounts} The pledge counts for the given side
     */
    private getPledgeCounts(side: "for" | "against", dispute: DisputeV2): PledgeCounts {
        return side === "for"
            ? {
                  sidePledges: dispute.totalPledgesForDispute,
                  oppositePledges: dispute.totalPledgesAgainstDispute,
              }
            : {
                  sidePledges: dispute.totalPledgesAgainstDispute,
                  oppositePledges: dispute.totalPledgesForDispute,
              };
    }

    /**
     * @description Checks if the pledge window has passed
     * @param {DisputeV2} dispute - The dispute to check
     * @param {SnapshotParameters} parameters - The parameters of the dispute
     * @returns {boolean} True if the pledge window has passed, false otherwise
     */
    protected async hasPledgeWindowPassed(
        dispute: DisputeV2,
        parameters: SnapshotParameters,
    ): Promise<boolean> {
        const { timestamp: currentTimestamp } = await this.protocolProvider.getLastFinalizedBlock();
        if (currentTimestamp < dispute.createdAt + parameters.pledgeWindow) {
            return false;
        } else {
            return currentTimestamp >= dispute.lastPledgeTimestamp + parameters.pledgeRefreshWindow;
        }
    }

    /**
     * @description Checks if the dispute is valid
     * @param {bigint} proposedBlockNumber - The block number of the proposed response
     * @param {bigint} expectedBlockNumber - The block number of the expected response
     * @returns {boolean} True if the dispute is valid, false otherwise
     */
    protected isValidDispute(proposedBlockNumber: bigint, expectedBlockNumber: bigint) {
        return proposedBlockNumber !== expectedBlockNumber;
    }

    /**
     * @description Gets the expected epoch block number to be proposed
     * @returns The epoch block number
     */
    protected async getEpochBlockNumber(): Promise<bigint> {
        // FIXME(non-current epochs): adapt this code to fetch timestamps corresponding
        // to the first block of any epoch, not just the current epoch

        const { startTimestamp: epochStartTimestamp } =
            await this.protocolProvider.getCurrentEpoch();

        const epochBlockNumber = await this.blockNumberService.getEpochBlockNumber(
            epochStartTimestamp,
            this.actorProposal.chainId,
        );

        return epochBlockNumber;
    }
}
