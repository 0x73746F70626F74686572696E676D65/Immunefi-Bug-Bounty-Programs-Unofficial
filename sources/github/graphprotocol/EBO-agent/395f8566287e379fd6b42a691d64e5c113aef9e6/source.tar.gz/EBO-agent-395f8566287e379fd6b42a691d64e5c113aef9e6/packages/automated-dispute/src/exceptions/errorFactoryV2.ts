import { CustomContractErrorV2 } from "../exceptions/index.js";
import { ErrorHandlingStrategyV2, ErrorNameV2 } from "../types/index.js";

const errorStrategiesEntries: [ErrorNameV2, ErrorHandlingStrategyV2][] = [
    [
        "EBOCore_Propose_ChainNotAdded",
        {
            shouldNotify: true,
            shouldTerminate: false,
            shouldReenqueue: false,
        },
    ],
    [
        "EBOCore_Propose_InvalidEpoch",
        {
            shouldNotify: true,
            shouldTerminate: false,
            shouldReenqueue: false,
        },
    ],
    [
        "EBOCore_Propose_ProposalAlreadyActive",
        {
            shouldNotify: false,
            shouldTerminate: false,
            shouldReenqueue: false,
        },
    ],
    [
        "EBOCore_Dispute_ProposalNotActive",
        {
            shouldNotify: false,
            shouldTerminate: false,
            shouldReenqueue: false,
        },
    ],
    [
        "EBOCore_Dispute_DisputeWindowOver",
        {
            shouldNotify: false,
            shouldTerminate: false,
            shouldReenqueue: false,
        },
    ],
    [
        "EBOCore_Finalize_DisputeWindowNotOver",
        {
            shouldNotify: false,
            shouldTerminate: false,
            shouldReenqueue: true,
        },
    ],
    [
        "EBOCore_Finalize_ProposalNotActive",
        {
            shouldNotify: false,
            shouldTerminate: false,
            shouldReenqueue: false,
        },
    ],
    [
        "EBOCore_Resolve_ProposalNotDisputed",
        {
            shouldNotify: false,
            shouldTerminate: false,
            shouldReenqueue: false,
        },
    ],
    [
        "EBOCore_Resolve_PledgeWindowNotOver",
        {
            shouldNotify: false,
            shouldTerminate: false,
            shouldReenqueue: true,
        },
    ],
    [
        "EBOCore_Resolve_DisputeNotEscalated",
        {
            shouldNotify: false,
            shouldTerminate: false,
            shouldReenqueue: false,
        },
    ],
    [
        "EBOCore_Resolve_InvalidStatus",
        {
            shouldNotify: true,
            shouldTerminate: false,
            shouldReenqueue: false,
        },
    ],
    [
        "EBOPledge_Pledge_PledgeWindowOver",
        {
            shouldNotify: false,
            shouldTerminate: false,
            shouldReenqueue: false,
        },
    ],
    [
        "EBOPledge_Pledge_ProposalNotDisputed",
        {
            shouldNotify: false,
            shouldTerminate: false,
            shouldReenqueue: false,
        },
    ],
    [
        "EBOPledge_Pledge_CannotPledgeIfWinning",
        {
            shouldNotify: false,
            shouldTerminate: false,
            shouldReenqueue: true,
        },
    ],
    [
        "BondManager_Bond_InvalidMaxVerifierCut",
        {
            shouldNotify: true,
            shouldTerminate: false,
            shouldReenqueue: true,
        },
    ],
    [
        "BondManager_Bond_InvalidThawingPeriod",
        {
            shouldNotify: true,
            shouldTerminate: false,
            shouldReenqueue: true,
        },
    ],
    [
        "BondManager_Bond_InsufficientNonThawingTokens",
        {
            shouldNotify: true,
            shouldTerminate: false,
            shouldReenqueue: true,
        },
    ],
    [
        "BondManager_Bond_BondedTokensExceedNonThawingTokens",
        {
            shouldNotify: true,
            shouldTerminate: false,
            shouldReenqueue: true,
        },
    ],
    [
        "AccessManager_OnlyOperator_NotOperator",
        {
            shouldNotify: true,
            shouldTerminate: false,
            shouldReenqueue: false,
        },
    ],
];

const errorStrategies = new Map<ErrorNameV2, ErrorHandlingStrategyV2>(errorStrategiesEntries);

export class ErrorFactoryV2 {
    public static createError(errorName: ErrorNameV2 | string): CustomContractErrorV2 {
        if (!errorStrategies.has(errorName as ErrorNameV2)) {
            return new CustomContractErrorV2("UnknownError", {
                shouldNotify: true,
                shouldTerminate: false,
                shouldReenqueue: true,
            });
        }
        const strategy = errorStrategies.get(errorName as ErrorNameV2)!;

        return new CustomContractErrorV2(errorName as ErrorNameV2, strategy);
    }
}
