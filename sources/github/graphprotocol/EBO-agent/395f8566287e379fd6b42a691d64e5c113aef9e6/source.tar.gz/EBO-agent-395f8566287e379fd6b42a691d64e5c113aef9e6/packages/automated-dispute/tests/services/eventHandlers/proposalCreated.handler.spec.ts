import { BlockNumberService } from "@ebo-agent/blocknumber";
import { Caip2ChainId, ILogger, UnixTimestamp } from "@ebo-agent/shared";
import { Block, keccak256, stringToBytes } from "viem";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { CustomContractErrorV2, ErrorFactoryV2 } from "../../../src/exceptions/index.js";
import { ProtocolProviderV2 } from "../../../src/external.js";
import { ProposalCreatedHandler } from "../../../src/services/eventHandlers/index.js";
import { ActorProposal, EboEventV2, ProposalId, ProposalStatus } from "../../../src/types/index.js";
import mocks from "../../mocks/index.js";

describe("ProposalCreatedHandler", () => {
    let handler: ProposalCreatedHandler;
    let logger: ILogger;
    let protocolProvider: ProtocolProviderV2;
    let blockNumberService: BlockNumberService;
    let actorProposal: ActorProposal;

    // Helper to create a mock block with the required properties for testing
    const createMockBlock = (timestamp: bigint): Block<bigint, false, "finalized"> =>
        ({
            number: 123456n,
            timestamp,
        }) as unknown as Block<bigint, false, "finalized">;

    beforeEach(() => {
        logger = mocks.mockLogger();

        protocolProvider = {
            getAccountAddress: vi
                .fn()
                .mockReturnValue("0xd133BBBC4aa80F365A2595Fe10B84a3Aff0a0ac1"),
            getCurrentEpoch: vi.fn(),
            dispute: vi.fn(),
            pledgeForDispute: vi.fn(),
            getLastFinalizedBlock: vi.fn().mockResolvedValue(createMockBlock(1800n)), // Default mock returns 30 minutes after proposal creation
        } as unknown as ProtocolProviderV2;

        blockNumberService = {
            getEpochBlockNumber: vi.fn(),
        } as unknown as BlockNumberService;

        actorProposal = {
            id: BigInt(1) as ProposalId,
            chainId: "eip155:1" as Caip2ChainId,
            proposal: {
                createdAt: 1000n as UnixTimestamp,
                epoch: 1n,
                chainId: "eip155:1" as Caip2ChainId,
                blockNumber: 123456n,
                proposer: "0xd133BBBC4aa80F365A2595Fe10B84a3Aff0a0ac1",
                parametersSnapshotId: 1n,
                status: ProposalStatus.Active,
            },
            parameters: {
                disputeWindow: 3600n,
                proposalBondSize: 500n,
                pledgeBondSize: 500n,
                minThawingPeriod: 0n,
                pledgeWindow: 0n,
                pledgeRefreshWindow: 0n,
                maxNumberOfPledges: 3n,
            },
            epoch: 1n,
        };

        handler = new ProposalCreatedHandler({
            actorProposal,
            protocolProvider,
            blockNumberService,
            logger,
        });
        vi.useFakeTimers();
    });

    afterEach(() => {
        vi.clearAllMocks();
        vi.useRealTimers();
    });

    it("runs successfully when proposal has correct block number", async () => {
        const proposalId = 1n as ProposalId;
        const event: EboEventV2 & { name: "ProposalCreated" } = {
            name: "ProposalCreated",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId,
            args: {
                proposalId,
                blockNumber: 123456n,
                epoch: 1n,
                chainId: keccak256(stringToBytes("eip155:1")),
                serviceProvider: "0xprovider",
            },
        };

        vi.spyOn(protocolProvider, "getCurrentEpoch").mockResolvedValue({
            startTimestamp: 1000n as UnixTimestamp,
            firstBlockNumber: BigInt(123400),
            number: 1n,
        });
        vi.spyOn(blockNumberService, "getEpochBlockNumber").mockResolvedValue(BigInt(123456));
        vi.spyOn(protocolProvider, "getLastFinalizedBlock").mockResolvedValue(
            createMockBlock(1800n),
        );

        await handler.run(event);

        expect(protocolProvider.dispute).not.toHaveBeenCalled();
        expect(logger.info).toHaveBeenLastCalledWith(
            `ProposalCreated event received but epoch block number ${event.args.blockNumber} is correct.`,
            {
                proposalId,
            },
        );
    });

    it("disputes when epoch block number is incorrect", async () => {
        const proposalId = 1n as ProposalId;
        const event: EboEventV2 & { name: "ProposalCreated" } = {
            name: "ProposalCreated",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId,
            args: {
                proposalId,
                blockNumber: 999999n, // Different from expected
                epoch: 1n,
                chainId: keccak256(stringToBytes("eip155:1")),
                serviceProvider: "0xprovider",
            },
        };

        vi.spyOn(protocolProvider, "getCurrentEpoch").mockResolvedValue({
            startTimestamp: 1000n as UnixTimestamp,
            firstBlockNumber: 123400n,
            number: 1n,
        });
        vi.spyOn(blockNumberService, "getEpochBlockNumber").mockResolvedValue(BigInt(123450));
        vi.spyOn(protocolProvider, "getLastFinalizedBlock").mockResolvedValue(
            createMockBlock(1800n),
        );

        await handler.run(event);

        expect(protocolProvider.dispute).toHaveBeenCalledWith(
            proposalId,
            "0xd133BBBC4aa80F365A2595Fe10B84a3Aff0a0ac1",
        );
        expect(protocolProvider.pledgeForDispute).toHaveBeenCalledWith(
            proposalId,
            "0xd133BBBC4aa80F365A2595Fe10B84a3Aff0a0ac1",
        );
        expect(logger.info).toHaveBeenNthCalledWith(
            1,
            `Proposal ${proposalId} disputed successfully.`,
            {
                proposalId,
            },
        );
    });

    it("handles custom contract error when disputing", async () => {
        const proposalId = 1n as ProposalId;
        const event: EboEventV2 & { name: "ProposalCreated" } = {
            name: "ProposalCreated",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId,
            args: {
                proposalId,
                blockNumber: 999999n, // Different from expected
                epoch: 1n,
                chainId: keccak256(stringToBytes("eip155:1")),
                serviceProvider: "0xprovider",
            },
        };

        vi.spyOn(protocolProvider, "getCurrentEpoch").mockResolvedValue({
            startTimestamp: 1000n as UnixTimestamp,
            firstBlockNumber: 123400n,
            number: 1n,
        });
        vi.spyOn(blockNumberService, "getEpochBlockNumber").mockResolvedValue(BigInt(123450));
        vi.spyOn(protocolProvider, "getLastFinalizedBlock").mockResolvedValue(
            createMockBlock(1800n),
        );

        const error = ErrorFactoryV2.createError("EBOCore_Dispute_DisputeWindowOver");

        vi.spyOn(protocolProvider, "dispute").mockRejectedValueOnce(error);

        try {
            await handler.run(event);
        } catch (err) {
            const error = err as CustomContractErrorV2;
            expect(error.name).toBe("EBOCore_Dispute_DisputeWindowOver");
            expect(error).toHaveProperty("context");
            expect(error.context).toEqual({
                proposal: actorProposal.proposal,
                parameters: actorProposal.parameters,
                dispute: actorProposal.dispute,
                event,
            });
        }

        // Verify pledge was not called
        expect(protocolProvider.pledgeForDispute).not.toHaveBeenCalled();
    });

    it("handles custom contract error when pledging", async () => {
        const proposalId = 1n as ProposalId;
        const event: EboEventV2 & { name: "ProposalCreated" } = {
            name: "ProposalCreated",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId,
            args: {
                proposalId,
                blockNumber: 999999n, // Different from expected
                epoch: 1n,
                chainId: keccak256(stringToBytes("eip155:1")),
                serviceProvider: "0xprovider",
            },
        };

        vi.spyOn(protocolProvider, "getCurrentEpoch").mockResolvedValue({
            startTimestamp: 1000n as UnixTimestamp,
            firstBlockNumber: 123400n,
            number: 1n,
        });
        vi.spyOn(blockNumberService, "getEpochBlockNumber").mockResolvedValue(BigInt(123450));
        vi.spyOn(protocolProvider, "getLastFinalizedBlock").mockResolvedValue(
            createMockBlock(1800n),
        );

        // Create a mock contract revert error
        const revertError = ErrorFactoryV2.createError("EBOPledge_Pledge_CannotPledgeIfWinning");

        vi.spyOn(protocolProvider, "pledgeForDispute").mockRejectedValueOnce(revertError);

        try {
            await handler.run(event);
        } catch (err) {
            const error = err as CustomContractErrorV2;
            expect(error.name).toBe("EBOPledge_Pledge_CannotPledgeIfWinning");
            expect(error).toHaveProperty("context");
            expect(error.context).toEqual({
                proposal: actorProposal.proposal,
                parameters: actorProposal.parameters,
                dispute: actorProposal.dispute,
                event,
            });
            // Verify shouldReenqueue was set to false as per the code
            expect(error.strategy.shouldReenqueue).toBe(false);
        }
    });

    it("skips disputing when dispute window has expired", async () => {
        // Set proposal creation time far in the past so window is expired
        actorProposal.proposal.createdAt = BigInt(0);

        const proposalId = 1n as ProposalId;
        const event: EboEventV2 & { name: "ProposalCreated" } = {
            name: "ProposalCreated",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId,
            args: {
                proposalId,
                blockNumber: 999999n, // Different from expected
                epoch: 1n,
                chainId: keccak256(stringToBytes("eip155:1")),
                serviceProvider: "0xprovider",
            },
        };

        // Set blockchain timestamp to a value that exceeds the dispute window
        vi.spyOn(protocolProvider, "getLastFinalizedBlock").mockResolvedValue(
            createMockBlock(4000n),
        );

        await handler.run(event);

        // Verify that we didn't try to fetch epoch data or dispute
        expect(protocolProvider.getCurrentEpoch).not.toHaveBeenCalled();
        expect(blockNumberService.getEpochBlockNumber).not.toHaveBeenCalled();
        expect(protocolProvider.dispute).not.toHaveBeenCalled();
        expect(logger.info).toHaveBeenLastCalledWith(
            "ProposalCreated event received but dispute window has expired.",
            {
                proposalId,
            },
        );
    });

    it("handles other errors", async () => {
        const proposalId = 1n as ProposalId;
        const event: EboEventV2 & { name: "ProposalCreated" } = {
            name: "ProposalCreated",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId,
            args: {
                proposalId,
                blockNumber: 999999n, // Different from expected
                epoch: 1n,
                chainId: keccak256(stringToBytes("eip155:1")),
                serviceProvider: "0xprovider",
            },
        };

        vi.spyOn(protocolProvider, "getCurrentEpoch").mockResolvedValue({
            startTimestamp: 1000n as UnixTimestamp,
            firstBlockNumber: 123400n,
            number: 1n,
        });
        vi.spyOn(blockNumberService, "getEpochBlockNumber").mockResolvedValue(BigInt(123450));

        vi.spyOn(protocolProvider, "getLastFinalizedBlock").mockResolvedValue(
            createMockBlock(1800n),
        );
        vi.spyOn(protocolProvider, "dispute").mockRejectedValueOnce(new Error("Test error"));

        await expect(handler.run(event)).rejects.toThrow();
    });
});
