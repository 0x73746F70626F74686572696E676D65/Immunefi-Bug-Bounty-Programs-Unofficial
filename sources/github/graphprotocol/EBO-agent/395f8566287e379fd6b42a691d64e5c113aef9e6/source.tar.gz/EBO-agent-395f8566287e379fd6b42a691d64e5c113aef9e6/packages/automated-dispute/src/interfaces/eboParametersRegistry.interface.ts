import { SnapshotParameters } from "../types/index.js";

export interface IEboParametersRegistry {
    /**
     * Get the parameters for a given snapshot ID.
     *
     * @param snapshotId the snapshot ID
     * @returns the parameters for the given snapshot ID, or `undefined` if no parameters are available
     */
    getParameters(snapshotId: bigint): Promise<SnapshotParameters | undefined>;

    /**
     * Set the parameters for a given snapshot ID.
     * It overwrites the existing parameters for the given snapshot ID if they exist.
     *
     * @param snapshotId the snapshot ID
     * @param parameters the parameters
     */
    setParameters(snapshotId: bigint, parameters: SnapshotParameters): void;

    /**
     * Clear the cache.
     */
    clear(): void;
}
