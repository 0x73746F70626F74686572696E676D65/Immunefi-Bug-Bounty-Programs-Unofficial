import { Caip2ChainId, Logger, NotificationService, UnixTimestamp } from "@ebo-agent/shared";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { ChainWithoutProvider, EmptyRpcUrls } from "../../src/exceptions/index.js";
import { BlockNumberProviderFactory } from "../../src/providers/blockNumberProviderFactory.js";
import { EvmBlockNumberProvider } from "../../src/providers/evmBlockNumberProvider.js";
import { BlockNumberService } from "../../src/services/index.js";

describe("BlockNumberService", () => {
    const logger = Logger.getInstance();

    describe("constructor", () => {
        const dummyProviders: Record<Caip2ChainId, any> = {
            "eip155:1": {
                getEpochBlockNumber: async () => undefined,
                providerClass: EvmBlockNumberProvider,
            },
            "eip155:137": {
                getEpochBlockNumber: async () => undefined,
                providerClass: EvmBlockNumberProvider,
            },
        };

        const providersChains = Object.keys(dummyProviders) as Caip2ChainId[];
        const rpcUrls = new Map(
            providersChains.map((chain) => [
                chain,
                ["http://localhost:8545", "http://localhost:8546"],
            ]),
        );

        const mockNotificationService: NotificationService = {
            send: vi.fn().mockResolvedValue(undefined),
            sendOrThrow: vi.fn().mockResolvedValue(undefined),
            createErrorMessage: vi.fn().mockReturnValue({ title: "Test", description: "Test" }),
            sendError: vi.fn().mockResolvedValue(undefined),
        };

        beforeEach(() => {
            spyWithDummyProviders(dummyProviders);
        });

        afterEach(() => {
            vi.restoreAllMocks();
        });

        it("creates an instance of BlockNumberService", () => {
            const blockmetaConfig = {
                baseUrl: new URL("http://localhost:443"),
                servicePaths: {
                    block: "/block",
                    blockByTime: "/blockByTime",
                },
                bearerToken: "bearer-token",
                bearerTokenExpirationWindow: 300,
            };

            const service = new BlockNumberService(
                rpcUrls,
                blockmetaConfig,
                logger,
                mockNotificationService,
            );

            expect(service).toBeInstanceOf(BlockNumberService);
        });

        it("fails if initialized without any chain", () => {
            const emptyRpcUrls = new Map();
            const blockmetaConfig = {
                baseUrl: new URL("http://localhost:443"),
                servicePaths: {
                    block: "/block",
                    blockByTime: "/blockByTime",
                },
                bearerToken: "bearer-token",
                bearerTokenExpirationWindow: 300,
            };

            expect(
                () =>
                    new BlockNumberService(
                        emptyRpcUrls,
                        blockmetaConfig,
                        logger,
                        mockNotificationService,
                    ),
            ).toThrow(EmptyRpcUrls);
        });
    });

    describe("getEpochBlockNumber", () => {
        const dummyProviders: Record<Caip2ChainId, any> = {
            "eip155:1": {
                getEpochBlockNumber: async () => 1234n,
                providerClass: EvmBlockNumberProvider,
            },
            "eip155:137": {
                getEpochBlockNumber: async () => 5678n,
                providerClass: EvmBlockNumberProvider,
            },
        } as const;

        const providersChains = Object.keys(dummyProviders) as Caip2ChainId[];
        const rpcUrls = new Map(
            providersChains.map((chain) => [
                chain,
                ["http://localhost:8545", "http://localhost:8546"],
            ]),
        );

        const mockNotificationService: NotificationService = {
            send: vi.fn().mockResolvedValue(undefined),
            sendOrThrow: vi.fn().mockResolvedValue(undefined),
            createErrorMessage: vi.fn().mockReturnValue({ title: "Test", description: "Test" }),
            sendError: vi.fn().mockResolvedValue(undefined),
        };

        beforeEach(() => {
            spyWithDummyProviders(dummyProviders);
        });

        afterEach(() => {
            vi.restoreAllMocks();
        });

        it("returns the chain epoch block number", async () => {
            const blockmetaConfig = {
                baseUrl: new URL("http://localhost:443"),
                servicePaths: {
                    block: "/block",
                    blockByTime: "/blockByTime",
                },
                bearerToken: "bearer-token",
                bearerTokenExpirationWindow: 300,
            };

            const service = new BlockNumberService(
                rpcUrls,
                blockmetaConfig,
                logger,
                mockNotificationService,
            );

            const timestamp = BigInt(Date.UTC(2024, 1, 1, 0, 0, 0, 0)) as UnixTimestamp;
            const epochChainId = "eip155:1" as Caip2ChainId;
            const blockNumber = await service.getEpochBlockNumber(timestamp, epochChainId);

            expect(blockNumber).toEqual(1234n);
        });

        it("fails if the chain has no provider assigned", async () => {
            const blockmetaConfig = {
                baseUrl: new URL("http://localhost:443"),
                servicePaths: {
                    block: "/block",
                    blockByTime: "/blockByTime",
                },
                bearerToken: "bearer-token",
                bearerTokenExpirationWindow: 300,
            };

            const service = new BlockNumberService(
                rpcUrls,
                blockmetaConfig,
                logger,
                mockNotificationService,
            );

            const timestamp = BigInt(Date.UTC(2024, 1, 1, 0, 0, 0, 0)) as UnixTimestamp;
            const epochChainId = "eip155:42161" as Caip2ChainId;

            await expect(service.getEpochBlockNumber(timestamp, epochChainId)).rejects.toThrow(
                ChainWithoutProvider,
            );
        });

        it("fails if the provider fails", async () => {
            const failingProviders = {
                "eip155:1": {
                    getEpochBlockNumber: async () => {
                        throw new Error();
                    },
                    providerClass: EvmBlockNumberProvider,
                },
            };

            spyWithDummyProviders(failingProviders);

            const rpcUrls: Map<Caip2ChainId, string[]> = new Map([
                ["eip155:1", ["http://localhost:8545"]],
            ]);

            const blockmetaConfig = {
                baseUrl: new URL("http://localhost:443"),
                servicePaths: {
                    block: "/block",
                    blockByTime: "/blockByTime",
                },
                bearerToken: "bearer-token",
                bearerTokenExpirationWindow: 300,
            };

            const service = new BlockNumberService(
                rpcUrls,
                blockmetaConfig,
                logger,
                mockNotificationService,
            );
            const timestamp = BigInt(Date.UTC(2024, 1, 1, 0, 0, 0, 0)) as UnixTimestamp;

            await expect(service.getEpochBlockNumber(timestamp, "eip155:1")).rejects.toBeDefined();

            vi.clearAllMocks();
        });
    });

    describe("getEpochBlockNumbers", () => {
        const dummyProviders: Record<Caip2ChainId, any> = {
            "eip155:1": {
                getEpochBlockNumber: async () => 1234n,
                providerClass: EvmBlockNumberProvider,
            },
            "eip155:137": {
                getEpochBlockNumber: async () => 5678n,
                providerClass: EvmBlockNumberProvider,
            },
        } as const;

        const providersChains = Object.keys(dummyProviders) as Caip2ChainId[];
        const rpcUrls = new Map(
            providersChains.map((chain) => [
                chain,
                ["http://localhost:8545", "http://localhost:8546"],
            ]),
        );

        const mockNotificationService: NotificationService = {
            send: vi.fn().mockResolvedValue(undefined),
            sendOrThrow: vi.fn().mockResolvedValue(undefined),
            createErrorMessage: vi.fn().mockReturnValue({ title: "Test", description: "Test" }),
            sendError: vi.fn().mockResolvedValue(undefined),
        };

        beforeEach(() => {
            spyWithDummyProviders(dummyProviders);
        });

        afterEach(() => {
            vi.restoreAllMocks();
        });

        it("returns the chains' epoch block numbers", async () => {
            const blockmetaConfig = {
                baseUrl: new URL("http://localhost:443"),
                servicePaths: {
                    block: "/block",
                    blockByTime: "/blockByTime",
                },
                bearerToken: "bearer-token",
                bearerTokenExpirationWindow: 300,
            };

            const service = new BlockNumberService(
                rpcUrls,
                blockmetaConfig,
                logger,
                mockNotificationService,
            );

            const timestamp = BigInt(Date.UTC(2024, 1, 1, 0, 0, 0, 0)) as UnixTimestamp;
            const epochChains = ["eip155:1", "eip155:137"] as Caip2ChainId[];
            const blockNumbers = await service.getEpochBlockNumbers(timestamp, epochChains);

            epochChains.forEach(async (chain) => {
                const blockNumber = await dummyProviders[chain].getEpochBlockNumber();

                expect(blockNumbers.get(chain)).toEqual(blockNumber);
            });
        });

        it("fails if some input chain has no provider assigned", async () => {
            const blockmetaConfig = {
                baseUrl: new URL("http://localhost:443"),
                servicePaths: {
                    block: "/block",
                    blockByTime: "/blockByTime",
                },
                bearerToken: "bearer-token",
                bearerTokenExpirationWindow: 300,
            };

            const service = new BlockNumberService(
                rpcUrls,
                blockmetaConfig,
                logger,
                mockNotificationService,
            );

            const timestamp = BigInt(Date.UTC(2024, 1, 1, 0, 0, 0, 0)) as UnixTimestamp;
            const epochChains = ["eip155:1", "eip155:42161"] as Caip2ChainId[];

            await expect(service.getEpochBlockNumbers(timestamp, epochChains)).rejects.toThrow(
                ChainWithoutProvider,
            );
        });

        it("fails if a provider fails", async () => {
            const failingProviders = {
                "eip155:1": {
                    getEpochBlockNumber: async () => {
                        throw new Error();
                    },
                    providerClass: EvmBlockNumberProvider,
                },
            };

            spyWithDummyProviders(failingProviders);

            const rpcUrls: Map<Caip2ChainId, string[]> = new Map([
                ["eip155:1", ["http://localhost:8545"]],
            ]);

            const blockmetaConfig = {
                baseUrl: new URL("http://localhost:443"),
                servicePaths: {
                    block: "/block",
                    blockByTime: "/blockByTime",
                },
                bearerToken: "bearer-token",
                bearerTokenExpirationWindow: 300,
            };

            const service = new BlockNumberService(
                rpcUrls,
                blockmetaConfig,
                logger,
                mockNotificationService,
            );
            const timestamp = BigInt(Date.UTC(2024, 1, 1, 0, 0, 0, 0)) as UnixTimestamp;

            await expect(
                service.getEpochBlockNumbers(timestamp, ["eip155:1"]),
            ).rejects.toBeDefined();

            vi.clearAllMocks();
        });
    });

    function spyWithDummyProviders(providersResults: Record<Caip2ChainId, any>) {
        const dummyProvider = (chainId: Caip2ChainId, client: any) => {
            const provider = new providersResults[chainId].providerClass(client, {});

            provider.getEpochBlockNumber = vi
                .fn()
                .mockImplementation(providersResults[chainId].getEpochBlockNumber);

            return provider;
        };

        vi.spyOn(BlockNumberProviderFactory, "buildProvider").mockImplementation(dummyProvider);
    }
});
