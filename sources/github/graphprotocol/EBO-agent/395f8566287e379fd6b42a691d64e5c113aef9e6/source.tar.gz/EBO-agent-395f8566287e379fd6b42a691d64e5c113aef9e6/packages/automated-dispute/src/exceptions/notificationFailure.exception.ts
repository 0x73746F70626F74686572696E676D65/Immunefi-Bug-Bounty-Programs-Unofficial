export class NotificationFailureException extends Error {
    constructor(message: string) {
        super(`Failed to send notification: ${message}`);
        this.name = "NotificationFailureException";
    }
}
