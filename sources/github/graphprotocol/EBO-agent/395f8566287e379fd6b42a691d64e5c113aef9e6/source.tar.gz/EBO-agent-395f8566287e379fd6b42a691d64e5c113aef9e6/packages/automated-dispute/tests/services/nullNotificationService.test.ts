import { IMessage, NotificationService } from "@ebo-agent/shared";
import { beforeEach, describe, expect, it } from "vitest";

import { NullNotificationService } from "../../src/interfaces/index.js";

describe("NullNotificationService", () => {
    let notifier: NotificationService;

    beforeEach(() => {
        notifier = new NullNotificationService();
    });

    describe("send", () => {
        it("executes without throwing an error", async () => {
            const message: IMessage = { title: "Test Title" };
            await expect(notifier.send(message)).resolves.toBeUndefined();
        });
    });

    describe("sendOrThrow", () => {
        it("executes without throwing an error", async () => {
            const message: IMessage = { title: "Test Title" };
            await expect(notifier.sendOrThrow(message)).resolves.toBeUndefined();
        });
    });

    describe("createErrorMessage", () => {
        it("returns an IMessage with title only when no context or error is provided", () => {
            const defaultMessage = "Default Error";
            const errorMessage = notifier.createErrorMessage(defaultMessage);
            expect(errorMessage).toEqual({
                title: "Default Error",
                subtitle: undefined,
                description: undefined,
            });
        });

        it("includes subtitle when context is provided", () => {
            const defaultMessage = "Error with Context";
            const context = { key: "value" };
            const errorMessage = notifier.createErrorMessage(defaultMessage, context);
            expect(errorMessage).toEqual({
                title: "Default Error",
                subtitle: JSON.stringify(context),
                description: undefined,
            });
        });

        it("includes description when an error is provided", () => {
            const defaultMessage = "Error with Exception";
            const error = new Error("Something went wrong");
            const errorMessage = notifier.createErrorMessage(defaultMessage, undefined, error);
            expect(errorMessage).toEqual({
                title: "Default Error",
                subtitle: undefined,
                description: "Something went wrong",
            });
        });

        it("includes both subtitle and description when context and error are provided", () => {
            const defaultMessage = "Error with Context and Exception";
            const context = { key: "value" };
            const error = new Error("Something went wrong");
            const errorMessage = notifier.createErrorMessage(defaultMessage, context, error);
            expect(errorMessage).toEqual({
                title: "Default Error",
                subtitle: JSON.stringify(context),
                description: "Something went wrong",
            });
        });

        it("handles non-Error error objects gracefully", () => {
            const defaultMessage = "Error with Non-Error";
            const context = { key: "value" };
            const error = { message: "Non-Error message" };
            const errorMessage = notifier.createErrorMessage(defaultMessage, context, error);
            expect(errorMessage).toEqual({
                title: "Default Error",
                subtitle: JSON.stringify(context),
                description: '{"message":"Non-Error message"}',
            });
        });
    });

    describe("sendError", () => {
        it("executes without throwing an error", async () => {
            const defaultMessage = "Error Occurred";
            const context = { key: "value" };
            const error = new Error("Something went wrong");
            await expect(
                notifier.sendError(defaultMessage, context, error),
            ).resolves.toBeUndefined();
        });

        it("handles cases where context and error are not provided", async () => {
            const defaultMessage = "Error Occurred";
            await expect(notifier.sendError(defaultMessage)).resolves.toBeUndefined();
        });
    });
});
