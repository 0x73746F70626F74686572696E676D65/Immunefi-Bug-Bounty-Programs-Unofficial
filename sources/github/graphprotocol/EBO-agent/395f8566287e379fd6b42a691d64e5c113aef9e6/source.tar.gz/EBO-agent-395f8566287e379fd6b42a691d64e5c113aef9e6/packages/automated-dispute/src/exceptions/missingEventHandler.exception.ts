export class MissingEventHandler extends Error {
    constructor(eventName: string) {
        super(`Missing event handler: ${eventName}`);

        this.name = "MissingEventHandler";
    }
}
