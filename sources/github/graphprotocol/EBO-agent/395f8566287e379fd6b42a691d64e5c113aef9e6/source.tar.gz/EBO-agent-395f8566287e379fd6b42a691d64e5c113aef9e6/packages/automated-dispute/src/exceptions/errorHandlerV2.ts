import { ILogger, NotificationService } from "@ebo-agent/shared";

import { CustomContractErrorV2 } from "../exceptions/index.js";

export class ErrorHandlerV2 {
    private notificationService: NotificationService;
    private logger: ILogger;

    constructor(notificationService: NotificationService, logger: ILogger) {
        this.notificationService = notificationService;
        this.logger = logger;
    }

    public async handle(error: CustomContractErrorV2): Promise<void> {
        const strategy = error.strategy;
        const context = error.getContext();

        this.logger.error(`Error occurred: ${error.message}`);

        try {
            await error.executeCustomAction();
        } catch (actionError) {
            this.logger.error(`Error executing custom action: ${actionError}`);
        } finally {
            if (strategy.shouldNotify) {
                await this.notificationService.sendError(
                    "An error occurred in the custom contract",
                    context,
                    error,
                );
            }

            if (strategy.shouldReenqueue && context.reenqueueEvent) {
                context.reenqueueEvent();
            }

            if (strategy.shouldTerminate && context.terminateActor) {
                context.terminateActor();
            } else {
                this.logger.warn(`Event handling caused an error`);
            }
        }
    }
}
