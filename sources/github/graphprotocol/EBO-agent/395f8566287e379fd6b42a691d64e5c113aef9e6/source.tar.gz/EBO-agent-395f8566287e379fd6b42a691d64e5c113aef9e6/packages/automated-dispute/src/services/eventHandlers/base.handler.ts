import { BlockNumberService } from "@ebo-agent/blocknumber";
import { ILogger } from "@ebo-agent/shared";

import { ProtocolProviderV2 } from "../../external.js";
import { IEventHandler } from "../../interfaces/index.js";
import { ActorProposal, EboEventV2 } from "../../types/index.js";

export abstract class BaseEventHandler<Type extends EboEventV2["name"]>
    implements IEventHandler<Type>
{
    protected readonly actorProposal: ActorProposal;
    protected readonly protocolProvider: ProtocolProviderV2;
    protected readonly blockNumberService: BlockNumberService;
    protected readonly logger: ILogger;

    constructor({
        actorProposal,
        protocolProvider,
        blockNumberService,
        logger,
    }: {
        actorProposal: ActorProposal;
        protocolProvider: ProtocolProviderV2;
        blockNumberService: BlockNumberService;
        logger: ILogger;
    }) {
        this.actorProposal = actorProposal;
        this.protocolProvider = protocolProvider;
        this.blockNumberService = blockNumberService;
        this.logger = logger;
    }

    abstract run(event: Extract<EboEventV2, { name: Type }>): Promise<void>;
}
