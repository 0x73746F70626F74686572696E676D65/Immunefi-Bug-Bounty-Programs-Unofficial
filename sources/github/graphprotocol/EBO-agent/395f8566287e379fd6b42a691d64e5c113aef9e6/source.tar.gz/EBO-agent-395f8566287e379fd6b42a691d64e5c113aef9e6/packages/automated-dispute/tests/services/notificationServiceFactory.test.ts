import { ILogger, NotificationService } from "@ebo-agent/shared";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("../../src/services/discordNotifier.js", () => ({
    DiscordNotifier: vi.fn(),
}));

vi.mock("../../src/interfaces/nullNotificationService.js", () => ({
    NullNotificationService: vi.fn(),
}));

/**
 * Helper function to mock the config module with a specified DISCORD_WEBHOOK.
 *
 * @param {string | undefined} discordWebhook - The Discord webhook URL or undefined.
 */
const mockConfig = (discordWebhook?: string) => {
    vi.doMock("../../src/config.js", () => ({
        config: {
            DISCORD_WEBHOOK: discordWebhook,
        },
    }));
};

describe("NotificationServiceFactory", () => {
    let logger: ILogger;

    beforeEach(() => {
        vi.resetModules();
        vi.clearAllMocks();

        logger = {
            error: vi.fn(),
            warn: vi.fn(),
            info: vi.fn(),
            debug: vi.fn(),
        };
    });

    afterEach(() => {
        vi.resetAllMocks();
    });

    it("should create DiscordNotifier when DISCORD_WEBHOOK is defined", async () => {
        const discordWebhookUrl = "https://discord.com/api/webhooks/test-webhook";
        mockConfig(discordWebhookUrl);

        const { NotificationServiceFactory } = await import(
            "../../src/interfaces/notificationServiceFactory.js"
        );
        const { DiscordNotifier: MockDiscordNotifier } = await import(
            "../../src/services/discordNotifier.js"
        );

        const notifier: NotificationService = NotificationServiceFactory.create(logger);

        expect(MockDiscordNotifier).toHaveBeenCalledWith(discordWebhookUrl, logger);
        expect(notifier).toBeInstanceOf(MockDiscordNotifier);
        expect(logger.debug).toHaveBeenCalledWith("Initializing DiscordNotifier...");
    });

    it("should create NullNotificationService when DISCORD_WEBHOOK is not defined", async () => {
        mockConfig(undefined);

        const { NotificationServiceFactory } = await import(
            "../../src/interfaces/notificationServiceFactory.js"
        );
        const { NullNotificationService: MockNullNotificationService } = await import(
            "../../src/interfaces/nullNotificationService.js"
        );

        const notifier: NotificationService = NotificationServiceFactory.create(logger);

        expect(logger.warn).toHaveBeenCalledWith(
            "No notification service configured. Using NullNotificationService.",
        );
        expect(MockNullNotificationService).toHaveBeenCalled();
        expect(notifier).toBeInstanceOf(MockNullNotificationService);
    });

    it("should log a warning and create NullNotificationService when DISCORD_WEBHOOK is empty string", async () => {
        mockConfig("");

        const { NotificationServiceFactory } = await import(
            "../../src/interfaces/notificationServiceFactory.js"
        );
        const { NullNotificationService: MockNullNotificationService } = await import(
            "../../src/interfaces/nullNotificationService.js"
        );

        const notifier: NotificationService = NotificationServiceFactory.create(logger);

        expect(logger.warn).toHaveBeenCalledWith(
            "No notification service configured. Using NullNotificationService.",
        );
        expect(MockNullNotificationService).toHaveBeenCalled();
        expect(notifier).toBeInstanceOf(MockNullNotificationService);
    });

    it("should not instantiate DiscordNotifier when DISCORD_WEBHOOK is undefined", async () => {
        mockConfig(undefined);

        const { NotificationServiceFactory } = await import(
            "../../src/interfaces/notificationServiceFactory.js"
        );
        const { DiscordNotifier: MockDiscordNotifier } = await import(
            "../../src/services/discordNotifier.js"
        );
        const { NullNotificationService: MockNullNotificationService } = await import(
            "../../src/interfaces/nullNotificationService.js"
        );

        const notifier: NotificationService = NotificationServiceFactory.create(logger);

        expect(MockDiscordNotifier).not.toHaveBeenCalled();
        expect(MockNullNotificationService).toHaveBeenCalled();
        expect(notifier).toBeInstanceOf(MockNullNotificationService);
    });
});
