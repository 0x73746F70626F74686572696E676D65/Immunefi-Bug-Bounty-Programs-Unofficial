import { describe, expect, it } from "vitest";

import { CustomContractErrorV2, ErrorFactoryV2 } from "../../src/exceptions/index.js";
import { ErrorNameV2 } from "../../src/types/index.js";

describe("ErrorFactoryV2", () => {
    it("creates a CustomContractErrorV2 with the correct name and strategy for known errors", () => {
        const errorName: ErrorNameV2 = "EBOCore_Propose_ChainNotAdded";
        const error = ErrorFactoryV2.createError(errorName);

        expect(error).toBeInstanceOf(CustomContractErrorV2);
        expect(error.name).toBe(errorName);
        expect(error.strategy).toEqual({
            shouldNotify: true,
            shouldTerminate: false,
            shouldReenqueue: false,
        });
    });

    it("creates a CustomContractErrorV2 with default strategy for unknown errors", () => {
        const errorName = "UnknownError";
        const error = ErrorFactoryV2.createError(errorName);

        expect(error).toBeInstanceOf(CustomContractErrorV2);
        expect(error.name).toBe(errorName);
        expect(error.strategy).toEqual({
            shouldNotify: true,
            shouldTerminate: false,
            shouldReenqueue: true,
        });
    });

    it("creates a CustomContractErrorV2 with the correct strategy for errors without custom actions", () => {
        const errorName: ErrorNameV2 = "EBOCore_Propose_InvalidEpoch";
        const error = ErrorFactoryV2.createError(errorName);

        expect(error).toBeInstanceOf(CustomContractErrorV2);
        expect(error.name).toBe(errorName);
        expect(error.strategy).toEqual({
            shouldNotify: true,
            shouldTerminate: false,
            shouldReenqueue: false,
        });
        expect(error.strategy).not.toHaveProperty("customAction");
    });

    it("creates different CustomContractErrorV2s for different error names", () => {
        const error1 = ErrorFactoryV2.createError("EBOCore_Propose_ChainNotAdded");
        const error2 = ErrorFactoryV2.createError("EBOCore_Dispute_DisputeWindowOver");

        expect(error1.name).not.toBe(error2.name);
        expect(error1.strategy).not.toEqual(error2.strategy);
    });

    it("creates CustomContractErrorV2s with consistent strategies for the same error name", () => {
        const errorName: ErrorNameV2 = "EBOCore_Propose_ChainNotAdded";
        const error1 = ErrorFactoryV2.createError(errorName);
        const error2 = ErrorFactoryV2.createError(errorName);

        expect(error1.strategy).toEqual(error2.strategy);
    });

    it("creates a CustomContractErrorV2 with UnknownError for non-existent error names", () => {
        const nonExistentErrorName = "NonExistentError";
        const error = ErrorFactoryV2.createError(nonExistentErrorName);

        expect(error).toBeInstanceOf(CustomContractErrorV2);
        expect(error.name).toBe("UnknownError");
        expect(error.strategy).toEqual({
            shouldNotify: true,
            shouldTerminate: false,
            shouldReenqueue: true,
        });
    });

    it("correctly sets error message with contract revert prefix", () => {
        const errorName: ErrorNameV2 = "EBOCore_Propose_ChainNotAdded";
        const error = ErrorFactoryV2.createError(errorName);

        expect(error.message).toBe(`Contract reverted: ${errorName}`);
    });

    it("handles edge case error names correctly", () => {
        const edgeCaseErrors: ErrorNameV2[] = [
            "AccessManager_OnlyOperator_NotOperator",
            "BondManager_Bond_BondedTokensExceedNonThawingTokens",
        ];

        for (const errorName of edgeCaseErrors) {
            const error = ErrorFactoryV2.createError(errorName);
            expect(error).toBeInstanceOf(CustomContractErrorV2);
            expect(error.name).toBe(errorName);
        }
    });

    it("verifies all defined error strategies exist and match expected pattern", () => {
        // This test ensures all error strategies defined in errorStrategiesEntries are accessible
        const knownErrors: ErrorNameV2[] = [
            "EBOCore_Propose_ChainNotAdded",
            "EBOCore_Propose_InvalidEpoch",
            "EBOCore_Propose_ProposalAlreadyActive",
            "EBOCore_Dispute_ProposalNotActive",
            "EBOCore_Dispute_DisputeWindowOver",
            "EBOCore_Finalize_DisputeWindowNotOver",
            "EBOCore_Finalize_ProposalNotActive",
            "EBOCore_Resolve_ProposalNotDisputed",
            "EBOCore_Resolve_PledgeWindowNotOver",
            "EBOCore_Resolve_DisputeNotEscalated",
            "EBOCore_Resolve_InvalidStatus",
            "EBOPledge_Pledge_PledgeWindowOver",
            "EBOPledge_Pledge_ProposalNotDisputed",
            "EBOPledge_Pledge_CannotPledgeIfWinning",
            "BondManager_Bond_InvalidMaxVerifierCut",
            "BondManager_Bond_InvalidThawingPeriod",
            "BondManager_Bond_InsufficientNonThawingTokens",
            "BondManager_Bond_BondedTokensExceedNonThawingTokens",
            "AccessManager_OnlyOperator_NotOperator",
        ];

        for (const errorName of knownErrors) {
            const error = ErrorFactoryV2.createError(errorName);
            expect(error).toBeInstanceOf(CustomContractErrorV2);
            expect(error.name).toBe(errorName);
            expect(error.strategy).toBeDefined();
            expect(error.strategy).toHaveProperty("shouldNotify");
            expect(error.strategy).toHaveProperty("shouldTerminate");
            expect(error.strategy).toHaveProperty("shouldReenqueue");
        }
    });

    it("creates errors with correctly typed context handling", () => {
        const error = ErrorFactoryV2.createError("EBOCore_Propose_InvalidEpoch");

        // Test that context methods exist
        expect(typeof error.setContext).toBe("function");
        expect(typeof error.getContext).toBe("function");
        expect(typeof error.setProcessEventsContext).toBe("function");

        // Test the context functionality
        const mockContext = {
            proposal: { id: "test" } as any,
            parameters: {} as any,
        };

        error.setContext(mockContext);
        expect(error.getContext()).toEqual(mockContext);
    });

    it("correctly handles empty string error names", () => {
        const error = ErrorFactoryV2.createError("");

        expect(error).toBeInstanceOf(CustomContractErrorV2);
        expect(error.name).toBe("UnknownError");
    });
});
