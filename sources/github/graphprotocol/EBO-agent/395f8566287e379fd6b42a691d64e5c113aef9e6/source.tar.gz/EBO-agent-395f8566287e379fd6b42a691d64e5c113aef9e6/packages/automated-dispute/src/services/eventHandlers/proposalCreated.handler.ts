import { Address } from "viem";

import { CustomContractErrorV2 } from "../../exceptions/index.js";
import { EboEventV2, ProposalId } from "../../types/index.js";
import { BaseEventHandler } from "./base.handler.js";

/**
 * @description Handles the ProposalCreated event
 * @extends BaseEventHandler
 *
 * It checks if the proposal is within the dispute window and if the epoch block number is correct.
 * If the proposal is within the dispute window and the epoch block number isn't correct, it will dispute the proposal.
 * Also, it will immediately pledge for the dispute
 */
export class ProposalCreatedHandler extends BaseEventHandler<"ProposalCreated"> {
    override async run(event: Extract<EboEventV2, { name: "ProposalCreated" }>): Promise<void> {
        const { proposal, parameters, id: proposalId } = this.actorProposal;

        const { timestamp: currentTimestamp } = await this.protocolProvider.getLastFinalizedBlock();

        if (currentTimestamp >= proposal.createdAt + parameters.disputeWindow) {
            this.logger.info("ProposalCreated event received but dispute window has expired.", {
                proposalId,
            });

            return;
        }

        const expectedEpochBlockNumber = await this.getEpochBlockNumber();

        if (event.args.blockNumber === expectedEpochBlockNumber) {
            this.logger.info(
                `ProposalCreated event received but epoch block number ${event.args.blockNumber} is correct.`,
                {
                    proposalId,
                },
            );
        } else {
            const disputer = this.protocolProvider.getAccountAddress();

            await this.disputeAndPledge(proposalId, disputer, event);
        }
    }

    /**
     * @description Disputes a proposal
     * @param proposalId - The proposal ID
     * @param disputer - The disputer address
     */
    private async disputeProposal(
        proposalId: ProposalId,
        disputer: Address,
        event: EboEventV2,
    ): Promise<void> {
        try {
            await this.protocolProvider.dispute(proposalId, disputer);
            this.logger.info(`Proposal ${proposalId} disputed successfully.`, {
                proposalId,
            });
        } catch (err) {
            if (err instanceof CustomContractErrorV2) {
                err.setContext({
                    proposal: this.actorProposal.proposal,
                    parameters: this.actorProposal.parameters,
                    dispute: this.actorProposal.dispute,
                    event,
                });
            }
            throw err;
        }
    }

    /**
     * @description Pledges for a dispute
     * @param proposalId - The proposal ID
     * @param disputer - The disputer address
     */
    private async pledgeForDispute(
        proposalId: ProposalId,
        disputer: Address,
        event: EboEventV2,
    ): Promise<void> {
        try {
            // we want to immediately pledge 'for' our dispute as is the cheapest pledge
            await this.protocolProvider.pledgeForDispute(proposalId, disputer);
            this.logger.info(`Pledged for dispute on Proposal ${proposalId} successfully.`, {
                proposalId,
            });
        } catch (err) {
            if (err instanceof CustomContractErrorV2) {
                err.setContext({
                    proposal: this.actorProposal.proposal,
                    parameters: this.actorProposal.parameters,
                    dispute: this.actorProposal.dispute,
                    event,
                });
                // in case an error is thrown from the pledge, we don't want to reenqueue
                // as it's not critical, we will try to pledge again on the next tick
                err.strategy.shouldReenqueue = false;
            }

            throw err;
        }
    }

    /**
     * @description Disputes a proposal and pledges for it
     * @param proposalId - The proposal ID
     * @param disputer - The disputer address
     */
    private async disputeAndPledge(
        proposalId: ProposalId,
        disputer: Address,
        event: EboEventV2,
    ): Promise<void> {
        await this.disputeProposal(proposalId, disputer, event);
        await this.pledgeForDispute(proposalId, disputer, event);
    }

    /**
     * @description Gets the expected epoch block number to be proposed
     * @returns The epoch block number
     */
    private async getEpochBlockNumber(): Promise<bigint> {
        // FIXME(non-current epochs): adapt this code to fetch timestamps corresponding
        // to the first block of any epoch, not just the current epoch

        const { startTimestamp: epochStartTimestamp } =
            await this.protocolProvider.getCurrentEpoch();

        const epochBlockNumber = await this.blockNumberService.getEpochBlockNumber(
            epochStartTimestamp,
            this.actorProposal.chainId,
        );

        return epochBlockNumber;
    }
}
