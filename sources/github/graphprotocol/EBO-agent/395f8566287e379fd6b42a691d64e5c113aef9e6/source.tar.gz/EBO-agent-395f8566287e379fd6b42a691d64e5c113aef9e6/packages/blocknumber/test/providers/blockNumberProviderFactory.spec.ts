import { Caip2ChainId, Logger, NotificationService } from "@ebo-agent/shared";
import {
    createPublicClient,
    fallback,
    FallbackTransport,
    http,
    HttpTransport,
    PublicClient,
} from "viem";
import { describe, expect, it, vi } from "vitest";

import { UnsupportedChain } from "../../src/exceptions/index.js";
import {
    BlockmetaClientConfig,
    BlockmetaJsonBlockNumberProvider,
    BlockNumberProviderFactory,
    EvmBlockNumberProvider,
} from "../../src/providers/index.js";

describe("BlockNumberProviderFactory", () => {
    const logger = Logger.getInstance();

    const client: PublicClient<FallbackTransport<HttpTransport[]>> = createPublicClient({
        transport: fallback([http("http://localhost:8545")]),
    });

    const blockmetaConfig: BlockmetaClientConfig = {
        baseUrl: new URL("http://localhost:443"),
        servicePaths: {
            block: "/block",
            blockByTime: "/blockByTime",
        },
        bearerToken: "bearer-token",
        bearerTokenExpirationWindow: 300,
    };

    const mockNotificationService: NotificationService = {
        send: vi.fn().mockResolvedValue(undefined),
        sendOrThrow: vi.fn().mockResolvedValue(undefined),
        createErrorMessage: vi.fn().mockReturnValue({ title: "Test", description: "Test" }),
        sendError: vi.fn().mockResolvedValue(undefined),
    };

    describe("buildProvider", () => {
        it("builds an EVM provider", () => {
            const provider = BlockNumberProviderFactory.buildProvider(
                "eip155:1",
                client,
                blockmetaConfig,
                logger,
                mockNotificationService,
            );

            expect(provider).toBeInstanceOf(EvmBlockNumberProvider);
        });

        it("builds a Solana Blockmeta provider", async () => {
            const provider = await BlockNumberProviderFactory.buildProvider(
                "solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp",
                client,
                blockmetaConfig,
                logger,
                mockNotificationService,
            );

            expect(provider).toBeInstanceOf(BlockmetaJsonBlockNumberProvider);
        });

        it("fails if chain is not supported", () => {
            const unsupportedChainId = "antelope:f16b1833c747c43682f4386fca9cbb32" as Caip2ChainId;

            expect(() => {
                BlockNumberProviderFactory.buildProvider(
                    unsupportedChainId,
                    client,
                    blockmetaConfig,
                    logger,
                    mockNotificationService,
                );
            }).toThrow(UnsupportedChain);
        });
    });
});
