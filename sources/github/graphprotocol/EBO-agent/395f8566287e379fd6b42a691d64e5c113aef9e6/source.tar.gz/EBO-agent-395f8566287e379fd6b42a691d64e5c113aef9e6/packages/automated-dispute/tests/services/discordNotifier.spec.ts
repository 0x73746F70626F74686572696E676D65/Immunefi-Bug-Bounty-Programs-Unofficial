import { ILogger, IMessage, stringify } from "@ebo-agent/shared";
import { WebhookClient } from "discord.js";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { NotificationFailureException } from "../../src/exceptions/index.js";
import { DiscordNotifier } from "../../src/index.js";

vi.mock("discord.js", () => {
    const mockSend = vi.fn();

    const MockWebhookClient = vi.fn(() => ({
        send: mockSend,
    }));

    return {
        WebhookClient: MockWebhookClient,
    };
});

describe("DiscordNotifier", () => {
    let notifier: DiscordNotifier;
    const webhookUrl = "https://discord.com/api/webhooks/TEST/TEST";

    beforeEach(() => {
        vi.clearAllMocks();
        const mockLogger: ILogger = {
            error: vi.fn(),
            info: vi.fn(),
            warn: vi.fn(),
            debug: vi.fn(),
        };
        notifier = new DiscordNotifier(webhookUrl, mockLogger);
    });

    describe("send", () => {
        it("initializes the WebhookClient with the correct URL", () => {
            const WebhookClientMock = WebhookClient as vi.Mock;
            expect(WebhookClientMock).toHaveBeenCalledWith({ url: webhookUrl });
        });

        it("sends a message successfully", async () => {
            const message: IMessage = {
                title: "Test message",
                subtitle: "Test subtitle",
                description: "Test description",
                username: "TestUserWithoutAvatar",
                avatarUrl: "https://example.com/avatar.png",
                actionUrl: "https://example.com/action",
            };

            await notifier.send(message);

            const WebhookClientMock = WebhookClient as vi.Mock;
            const webhookClientInstance = WebhookClientMock.mock.results[0].value;
            const sendMock = webhookClientInstance.send as vi.Mock;

            expect(sendMock).toHaveBeenCalledWith(
                expect.objectContaining({
                    username: "TestUserWithoutAvatar",
                    content: "Test message",
                    avatarURL: "https://example.com/avatar.png",
                    embeds: [
                        {
                            title: "Test subtitle",
                            description: "Test description",
                            color: 2326507,
                            url: "https://example.com/action",
                        },
                    ],
                }),
            );
        });
    });

    describe("sendOrThrow", () => {
        it("sends a message successfully", async () => {
            const message: IMessage = {
                title: "Test message",
            };

            await notifier.sendOrThrow(message);

            const WebhookClientMock = WebhookClient as vi.Mock;
            const webhookClientInstance = WebhookClientMock.mock.results[0].value;
            const sendMock = webhookClientInstance.send as vi.Mock;

            expect(sendMock).toHaveBeenCalledWith(
                expect.objectContaining({
                    username: "EBO Agent",
                    content: "Test message",
                    avatarURL: undefined,
                }),
            );
        });

        it("throws NotificationFailureException when send fails", async () => {
            const message: IMessage = {
                title: "Test message",
            };

            const WebhookClientMock = WebhookClient as vi.Mock;
            const webhookClientInstance = WebhookClientMock.mock.results[0].value;
            const sendMock = webhookClientInstance.send as vi.Mock;
            sendMock.mockRejectedValueOnce(new Error("Send failed"));

            await expect(notifier.sendOrThrow(message)).rejects.toThrow(
                NotificationFailureException,
            );
        });
    });

    describe("createErrorMessage", () => {
        it("creates an error message from an Error object", () => {
            const error = new Error("Test error");
            const context = { foo: "bar" };
            const defaultMessage = "Default error message";

            const errorMessage = notifier.createErrorMessage(defaultMessage, context, error);

            expect(errorMessage).toEqual({
                title: `**Error:** Error - Test error`,
                description: `**Context:**\n\`\`\`json\n${stringify({
                    foo: "bar",
                    stack: error.stack,
                })}\n\`\`\``,
            });
        });

        it("creates an error message from a non-Error object", () => {
            const error = { message: "String error" };
            const context = { foo: "bar" };
            const defaultMessage = "Default error message";

            const errorMessage = notifier.createErrorMessage(defaultMessage, context, error);

            expect(errorMessage).toEqual({
                title: `**Error:** Default error message`,
                description: `**Context:**\n\`\`\`json\n${stringify({
                    foo: "bar",
                    error: stringify(error),
                })}\n\`\`\``,
            });
        });
    });

    describe("sendError", () => {
        it("sends an error message successfully", async () => {
            const error = new Error("Test error");
            const context = { foo: "bar" };
            const defaultMessage = "Default error message";

            const sendSpy = vi.spyOn(notifier, "send").mockResolvedValueOnce();

            await notifier.sendError(defaultMessage, context, error);

            expect(sendSpy).toHaveBeenCalledWith({
                title: `**Error:** Error - Test error`,
                description: `**Context:**\n\`\`\`json\n${stringify({
                    foo: "bar",
                    stack: error.stack,
                })}\n\`\`\``,
            });

            sendSpy.mockRestore();
        });
    });
});
