import { z } from "zod";

const ConfigSchema = z.object({
    DISCORD_WEBHOOK: z.string().url().optional(),
});

/**
 * Parses and validates the environment variables using the defined schema.
 * If validation fails, it throws an error detailing the issues.
 */
export const config = ConfigSchema.parse(process.env);
