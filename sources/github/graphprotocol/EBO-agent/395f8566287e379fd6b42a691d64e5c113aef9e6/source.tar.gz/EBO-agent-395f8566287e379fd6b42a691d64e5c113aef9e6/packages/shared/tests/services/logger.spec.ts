import { beforeEach, describe, expect, it, vi } from "vitest";

import { Logger } from "../../src/services/index.js";

describe("Logger Methods", () => {
    beforeEach(() => {
        Logger["instance"] = null;
        delete process.env.LOG_LEVEL;
    });

    it("includes metadata in log output", () => {
        const logger = Logger.getInstance();
        const mockInfo = vi.spyOn(logger["logger"], "info");

        const message = "Test message";
        const meta = { key: "value" };

        logger.info(message, meta);

        expect(mockInfo).toHaveBeenCalledWith(message, meta);
        mockInfo.mockRestore();
    });

    it("handles errors with metadata", () => {
        const logger = Logger.getInstance();
        const mockError = vi.spyOn(logger["logger"], "error");

        const error = new Error("An error occurred");
        const meta = { key: "value" };

        logger.error(error, meta);

        expect(mockError).toHaveBeenCalledWith(
            error.message,
            expect.objectContaining({ stack: error.stack, ...meta }),
        );
        mockError.mockRestore();
    });

    it("includes metadata in debug log output", () => {
        const logger = Logger.getInstance();
        const mockDebug = vi.spyOn(logger["logger"], "debug");

        const message = "Debug message";
        const meta = { debugKey: "debugValue" };

        logger.debug(message, meta);

        expect(mockDebug).toHaveBeenCalledWith(message, meta);
        mockDebug.mockRestore();
    });
});

describe("Logger Singleton", () => {
    it("creates a logger instance with the given log level", () => {
        const logger = Logger.getInstance();
        expect(logger).toBeInstanceOf(Logger);
        expect(() => Logger.getInstance()).not.toThrow();
    });

    it("returns the same instance if called multiple times", () => {
        const logger1 = Logger.getInstance();
        const logger2 = Logger.getInstance();
        expect(logger1).toBe(logger2);
    });

    it("sets level correctly based on LOG_LEVEL env var", () => {
        Logger["instance"] = null;
        process.env.LOG_LEVEL = "debug";
        const logger = Logger.getInstance();

        expect(logger.level).toEqual("debug");
    });
});
