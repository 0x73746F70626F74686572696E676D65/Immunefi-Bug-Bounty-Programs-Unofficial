import { ILogger, NotificationService } from "@ebo-agent/shared";

import { config } from "../config.js";
import { DiscordNotifier } from "../services/index.js";
import { NullNotificationService } from "./nullNotificationService.js";

/**
 * Factory class to create instances of NotificationService based on configuration.
 */
export class NotificationServiceFactory {
    /**
     * Creates an instance of NotificationService based on environment variables.
     *
     * @param {ILogger} logger - An injected logger instance.
     * @returns {NotificationService} An instance of NotificationService.
     */
    static create(logger: ILogger): NotificationService {
        if (config.DISCORD_WEBHOOK && config.DISCORD_WEBHOOK.length > 0) {
            logger.debug("Initializing DiscordNotifier...");
            return new DiscordNotifier(config.DISCORD_WEBHOOK, logger);
        }

        // Can add more notification services here, like TelegramNotifier, etc.

        // Default to NullNotificationService if no webhook is configured
        logger.warn("No notification service configured. Using NullNotificationService.");
        return new NullNotificationService();
    }
}
