import { EboEventV2 } from "./types/index.js";

/**
 * Checks if an event is a ProposalCreated event.
 *
 * @param event The event to check.
 * @returns `true` if the event is a ProposalCreated event, `false` otherwise.
 */
export const isProposalCreatedEvent = (
    event: EboEventV2,
): event is EboEventV2 & { name: "ProposalCreated" } => {
    return event.name === "ProposalCreated";
};
