/**
 * Represents a notification message.
 */
export interface IMessage {
    /**
     * The main content of the message.
     */
    title: string;
    /**
     * An optional subtitle for the message.
     */
    subtitle?: string;
    /**
     * An optional description providing more details.
     */
    description?: string;
    /**
     * The username to display as the sender.
     */
    username?: string;
    /**
     * The URL of the avatar image to display.
     */
    avatarUrl?: string;
    /**
     * An optional URL associated with the message.
     */
    actionUrl?: string;
}

/**
 * Interface representing a notification service capable of sending notifications.
 */
export interface NotificationService {
    /**
     * Sends a notification message.
     *
     * @param {IMessage} message - The message to send.
     * @returns {Promise<void>} A promise that resolves when the message is sent.
     */
    send(message: IMessage): Promise<void>;

    /**
     * Sends a notification message and throws an exception if sending fails.
     *
     * @param {IMessage} message - The message to send.
     * @returns {Promise<void>} A promise that resolves when the message is sent.
     * @throws {NotificationFailureException} If sending the message fails.
     */
    sendOrThrow(message: IMessage): Promise<void>;

    /**
     * Creates an IMessage from an error.
     *
     * @param {string} defaultMessage - A default message describing the error context.
     * @param {unknown} [context] - Additional context for the error.
     * @param {unknown} [err] - The error object.
     * @returns {IMessage} An IMessage object ready to be sent via the notifier.
     */
    createErrorMessage(defaultMessage: string, context?: unknown, err?: unknown): IMessage;

    /**
     * Sends an error notification message.
     *
     * @param {string} defaultMessage - A default message describing the error context.
     * @param {Record<string, unknown>} [context] - Additional context for the error.
     * @param {unknown} [err] - The error object.
     * @returns {Promise<void>} A promise that resolves when the message is sent.
     */
    sendError(
        defaultMessage: string,
        context?: Record<string, unknown>,
        err?: unknown,
    ): Promise<void>;
}
