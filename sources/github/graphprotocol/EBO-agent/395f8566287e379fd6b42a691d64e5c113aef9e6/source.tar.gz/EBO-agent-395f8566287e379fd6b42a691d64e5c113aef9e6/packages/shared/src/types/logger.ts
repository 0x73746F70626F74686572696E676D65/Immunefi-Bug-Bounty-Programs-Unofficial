/**
 * Generic logger interface.
 */
export interface ILogger {
    error: (error: Error | string, meta?: unknown) => void;
    info: (message: string, meta?: unknown) => void;
    warn: (message: string, meta?: unknown) => void;
    debug: (message: string, meta?: unknown) => void;
}
