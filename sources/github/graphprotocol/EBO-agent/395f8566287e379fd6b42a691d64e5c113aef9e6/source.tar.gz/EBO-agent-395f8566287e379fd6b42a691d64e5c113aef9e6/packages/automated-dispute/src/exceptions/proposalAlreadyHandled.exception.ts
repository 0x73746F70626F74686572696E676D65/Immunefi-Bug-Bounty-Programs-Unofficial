import { ProposalId } from "../types/index.js";

/**
 * Thrown when attempting to create an actor for a proposal that is already being handled
 */
export class ProposalAlreadyHandled extends Error {
    constructor(proposalId: ProposalId) {
        super(`Proposal ${proposalId} is already being handled by an actor`);
        this.name = "ProposalAlreadyHandled";
    }
}
