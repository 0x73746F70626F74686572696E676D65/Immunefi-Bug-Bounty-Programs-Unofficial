/**
 * NOTE: this is not the full ABI, just the functions we need and a few more.
 * Helps reduce amount of context sent to AI tools.
 */
export const eboAbi = [
    {
        type: "function",
        name: "activeProposal",
        inputs: [
            { name: "_epoch", type: "uint256", internalType: "uint256" },
            { name: "_chainId", type: "string", internalType: "string" },
        ],
        outputs: [{ name: "_proposalId", type: "uint256", internalType: "uint256" }],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "arbitrator",
        inputs: [],
        outputs: [{ name: "", type: "address", internalType: "address" }],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "bonds",
        inputs: [{ name: "_bonder", type: "address", internalType: "address" }],
        outputs: [{ name: "_bondSize", type: "uint256", internalType: "uint256" }],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "chainIdsAllowed",
        inputs: [{ name: "_chainId", type: "string", internalType: "string" }],
        outputs: [{ name: "_allowed", type: "bool", internalType: "bool" }],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "claimPledgeReward",
        inputs: [
            { name: "_proposalId", type: "uint256", internalType: "uint256" },
            { name: "_pledger", type: "address", internalType: "address" },
        ],
        outputs: [],
        stateMutability: "nonpayable",
    },
    {
        type: "function",
        name: "dispute",
        inputs: [
            { name: "_proposalId", type: "uint256", internalType: "uint256" },
            {
                name: "_serviceProvider",
                type: "address",
                internalType: "address",
            },
        ],
        outputs: [],
        stateMutability: "nonpayable",
    },
    {
        type: "function",
        name: "disputes",
        inputs: [{ name: "_proposalId", type: "uint256", internalType: "uint256" }],
        outputs: [
            { name: "disputer", type: "address", internalType: "address" },
            { name: "createdAt", type: "uint256", internalType: "uint256" },
            {
                name: "lastPledgeTimestamp",
                type: "uint256",
                internalType: "uint256",
            },
            {
                name: "totalPledgesForDispute",
                type: "uint256",
                internalType: "uint256",
            },
            {
                name: "totalPledgesAgainstDispute",
                type: "uint256",
                internalType: "uint256",
            },
            {
                name: "rewardPerWinningPledge",
                type: "uint256",
                internalType: "uint256",
            },
        ],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "epochManager",
        inputs: [],
        outputs: [
            {
                name: "",
                type: "address",
                internalType: "contract IEpochManager",
            },
        ],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "finalize",
        inputs: [{ name: "_proposalId", type: "uint256", internalType: "uint256" }],
        outputs: [],
        stateMutability: "nonpayable",
    },
    {
        type: "function",
        name: "grt",
        inputs: [],
        outputs: [{ name: "", type: "address", internalType: "contract IERC20" }],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "horizonStaking",
        inputs: [],
        outputs: [
            {
                name: "",
                type: "address",
                internalType: "contract IHorizonStaking",
            },
        ],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "parametersSnapshotId",
        inputs: [],
        outputs: [{ name: "", type: "uint256", internalType: "uint256" }],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "parametersSnapshots",
        inputs: [
            {
                name: "_parametersSnapshotId",
                type: "uint256",
                internalType: "uint256",
            },
        ],
        outputs: [
            {
                name: "proposalBondSize",
                type: "uint256",
                internalType: "uint256",
            },
            {
                name: "pledgeBondSize",
                type: "uint256",
                internalType: "uint256",
            },
            {
                name: "minThawingPeriod",
                type: "uint256",
                internalType: "uint256",
            },
            {
                name: "disputeWindow",
                type: "uint256",
                internalType: "uint256",
            },
            {
                name: "pledgeWindow",
                type: "uint256",
                internalType: "uint256",
            },
            {
                name: "pledgeRefreshWindow",
                type: "uint256",
                internalType: "uint256",
            },
            {
                name: "maxNumberOfPledges",
                type: "uint256",
                internalType: "uint256",
            },
        ],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "pledgeAgainstDispute",
        inputs: [
            { name: "_proposalId", type: "uint256", internalType: "uint256" },
            {
                name: "_serviceProvider",
                type: "address",
                internalType: "address",
            },
        ],
        outputs: [],
        stateMutability: "nonpayable",
    },
    {
        type: "function",
        name: "pledgeForDispute",
        inputs: [
            { name: "_proposalId", type: "uint256", internalType: "uint256" },
            {
                name: "_serviceProvider",
                type: "address",
                internalType: "address",
            },
        ],
        outputs: [],
        stateMutability: "nonpayable",
    },
    {
        type: "function",
        name: "pledgerClaimed",
        inputs: [
            { name: "_proposalId", type: "uint256", internalType: "uint256" },
            { name: "_pledger", type: "address", internalType: "address" },
        ],
        outputs: [{ name: "_claimed", type: "bool", internalType: "bool" }],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "pledgersAgainstDispute",
        inputs: [{ name: "_proposalId", type: "uint256", internalType: "uint256" }],
        outputs: [
            {
                name: "_pledgersAgainstDispute",
                type: "address[]",
                internalType: "address[]",
            },
        ],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "pledgersForDispute",
        inputs: [{ name: "_proposalId", type: "uint256", internalType: "uint256" }],
        outputs: [
            {
                name: "_pledgersForDispute",
                type: "address[]",
                internalType: "address[]",
            },
        ],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "pledgesAgainstDispute",
        inputs: [
            { name: "_proposalId", type: "uint256", internalType: "uint256" },
            { name: "_pledger", type: "address", internalType: "address" },
        ],
        outputs: [
            {
                name: "_pledgesAgainstDispute",
                type: "uint256",
                internalType: "uint256",
            },
        ],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "pledgesForDispute",
        inputs: [
            { name: "_proposalId", type: "uint256", internalType: "uint256" },
            { name: "_pledger", type: "address", internalType: "address" },
        ],
        outputs: [
            {
                name: "_pledgesForDispute",
                type: "uint256",
                internalType: "uint256",
            },
        ],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "proposalId",
        inputs: [],
        outputs: [{ name: "", type: "uint256", internalType: "uint256" }],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "proposals",
        inputs: [{ name: "_proposalId", type: "uint256", internalType: "uint256" }],
        outputs: [
            { name: "epoch", type: "uint256", internalType: "uint256" },
            { name: "chainId", type: "string", internalType: "string" },
            { name: "blockNumber", type: "uint256", internalType: "uint256" },
            { name: "proposer", type: "address", internalType: "address" },
            { name: "createdAt", type: "uint256", internalType: "uint256" },
            {
                name: "parametersSnapshotId",
                type: "uint256",
                internalType: "uint256",
            },
            {
                name: "status",
                type: "uint8",
                internalType: "enum IEBOStorage.ProposalStatus",
            },
        ],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "propose",
        inputs: [
            { name: "_epoch", type: "uint256", internalType: "uint256" },
            { name: "_chainId", type: "string", internalType: "string" },
            {
                name: "_blockNumber",
                type: "uint256",
                internalType: "uint256",
            },
            {
                name: "_serviceProvider",
                type: "address",
                internalType: "address",
            },
        ],
        outputs: [],
        stateMutability: "nonpayable",
    },
    {
        type: "function",
        name: "resolve",
        inputs: [{ name: "_proposalId", type: "uint256", internalType: "uint256" }],
        outputs: [],
        stateMutability: "nonpayable",
    },
    {
        type: "function",
        name: "resolve",
        inputs: [
            { name: "_proposalId", type: "uint256", internalType: "uint256" },
            {
                name: "_resolutionStatus",
                type: "uint8",
                internalType: "enum IEBOStorage.ProposalStatus",
            },
        ],
        outputs: [],
        stateMutability: "nonpayable",
    },
    {
        type: "function",
        name: "setEpochManager",
        inputs: [
            {
                name: "_epochManager",
                type: "address",
                internalType: "contract IEpochManager",
            },
        ],
        outputs: [],
        stateMutability: "nonpayable",
    },
    {
        type: "function",
        name: "startEpoch",
        inputs: [],
        outputs: [{ name: "", type: "uint256", internalType: "uint256" }],
        stateMutability: "view",
    },
    {
        type: "function",
        name: "chainIdsAllowed",
        inputs: [{ name: "_chainId", type: "string", internalType: "string" }],
        outputs: [{ name: "_allowed", type: "bool", internalType: "bool" }],
        stateMutability: "view",
    },
    {
        type: "event",
        name: "ChainIdAdded",
        inputs: [
            {
                name: "_chainId",
                type: "string",
                indexed: true,
                internalType: "string",
            },
        ],
        anonymous: false,
    },
    {
        type: "event",
        name: "ChainIdRemoved",
        inputs: [
            {
                name: "_chainId",
                type: "string",
                indexed: true,
                internalType: "string",
            },
        ],
        anonymous: false,
    },
    {
        type: "event",
        name: "DisputeEscalated",
        inputs: [
            {
                name: "_proposalId",
                type: "uint256",
                indexed: true,
                internalType: "uint256",
            },
        ],
        anonymous: false,
    },
    {
        type: "event",
        name: "DisputeResolved",
        inputs: [
            {
                name: "_proposalId",
                type: "uint256",
                indexed: true,
                internalType: "uint256",
            },
            {
                name: "_resolutionStatus",
                type: "uint8",
                indexed: false,
                internalType: "enum IEBOStorage.ProposalStatus",
            },
        ],
        anonymous: false,
    },
    {
        type: "event",
        name: "PledgeRewardClaimed",
        inputs: [
            {
                name: "_proposalId",
                type: "uint256",
                indexed: true,
                internalType: "uint256",
            },
            {
                name: "_pledger",
                type: "address",
                indexed: true,
                internalType: "address",
            },
            {
                name: "_rewardAmount",
                type: "uint256",
                indexed: false,
                internalType: "uint256",
            },
        ],
        anonymous: false,
    },
    {
        type: "event",
        name: "PledgedAgainstDispute",
        inputs: [
            {
                name: "_proposalId",
                type: "uint256",
                indexed: true,
                internalType: "uint256",
            },
            {
                name: "_pledger",
                type: "address",
                indexed: true,
                internalType: "address",
            },
            {
                name: "_pledgeAmount",
                type: "uint256",
                indexed: false,
                internalType: "uint256",
            },
        ],
        anonymous: false,
    },
    {
        type: "event",
        name: "PledgedForDispute",
        inputs: [
            {
                name: "_proposalId",
                type: "uint256",
                indexed: true,
                internalType: "uint256",
            },
            {
                name: "_pledger",
                type: "address",
                indexed: true,
                internalType: "address",
            },
            {
                name: "_pledgeAmount",
                type: "uint256",
                indexed: false,
                internalType: "uint256",
            },
        ],
        anonymous: false,
    },
    {
        type: "event",
        name: "ProposalAmended",
        inputs: [
            {
                name: "_proposalId",
                type: "uint256",
                indexed: true,
                internalType: "uint256",
            },
            {
                name: "_epoch",
                type: "uint256",
                indexed: true,
                internalType: "uint256",
            },
            {
                name: "_chainId",
                type: "string",
                indexed: true,
                internalType: "string",
            },
            {
                name: "_blockNumber",
                type: "uint256",
                indexed: false,
                internalType: "uint256",
            },
        ],
        anonymous: false,
    },
    {
        type: "event",
        name: "ProposalCreated",
        inputs: [
            {
                name: "_proposalId",
                type: "uint256",
                indexed: true,
                internalType: "uint256",
            },
            {
                name: "_epoch",
                type: "uint256",
                indexed: true,
                internalType: "uint256",
            },
            {
                name: "_chainId",
                type: "string",
                indexed: true,
                internalType: "string",
            },
            {
                name: "_blockNumber",
                type: "uint256",
                indexed: false,
                internalType: "uint256",
            },
            {
                name: "_serviceProvider",
                type: "address",
                indexed: false,
                internalType: "address",
            },
        ],
        anonymous: false,
    },
    {
        type: "event",
        name: "ProposalDisputed",
        inputs: [
            {
                name: "_proposalId",
                type: "uint256",
                indexed: true,
                internalType: "uint256",
            },
        ],
        anonymous: false,
    },
    {
        type: "event",
        name: "ProposalFinalized",
        inputs: [
            {
                name: "_proposalId",
                type: "uint256",
                indexed: true,
                internalType: "uint256",
            },
            {
                name: "_epoch",
                type: "uint256",
                indexed: true,
                internalType: "uint256",
            },
            {
                name: "_chainId",
                type: "string",
                indexed: true,
                internalType: "string",
            },
            {
                name: "_blockNumber",
                type: "uint256",
                indexed: false,
                internalType: "uint256",
            },
        ],
        anonymous: false,
    },
    {
        type: "error",
        name: "AccessManager_OnlyArbitrator_NotArbitrator",
        inputs: [],
    },
    {
        type: "error",
        name: "AccessManager_OnlyCouncil_NotCouncil",
        inputs: [],
    },
    {
        type: "error",
        name: "AccessManager_OnlyOperator_NotOperator",
        inputs: [],
    },
    {
        type: "error",
        name: "AccessManager_OnlyPendingCouncil_NotPendingCouncil",
        inputs: [],
    },
    {
        type: "error",
        name: "AddressEmptyCode",
        inputs: [{ name: "target", type: "address", internalType: "address" }],
    },
    {
        type: "error",
        name: "BondManager_Bond_BondedTokensExceedNonThawingTokens",
        inputs: [],
    },
    {
        type: "error",
        name: "BondManager_Bond_InsufficientNonThawingTokens",
        inputs: [],
    },
    {
        type: "error",
        name: "BondManager_Bond_InvalidMaxVerifierCut",
        inputs: [],
    },
    {
        type: "error",
        name: "BondManager_Bond_InvalidThawingPeriod",
        inputs: [],
    },
    {
        type: "error",
        name: "BondManager_Unbond_InsufficientBondedTokens",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOConfig_AddChainIds_ChainIdAlreadyAdded",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOConfig_CheckParameters_MinThawingPeriodTooShort",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOConfig_CheckParameters_ParametersCannotBeZero",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOConfig_CheckParameters_PledgeRefreshWindowExceedsPledgeWindow",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOConfig_RemoveChainIds_ChainIdNotAdded",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOConfig_SetArbitrator_AddressAlreadySet",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOConfig_SetCouncil_AddressAlreadySet",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOConfig_SetEpochManager_AddressAlreadySet",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOConfig_SetGRT_AddressAlreadySet",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOConfig_SetHorizonStaking_AddressAlreadySet",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOConfig_SetPendingCouncil_AddressAlreadySet",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOCore_AmendEpochBlock_ProposalNotFinalized",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOCore_Dispute_DisputeWindowOver",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOCore_Dispute_ProposalNotActive",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOCore_Finalize_DisputeWindowNotOver",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOCore_Finalize_ProposalNotActive",
        inputs: [],
    },
    { type: "error", name: "EBOCore_Propose_ChainNotAdded", inputs: [] },
    { type: "error", name: "EBOCore_Propose_InvalidEpoch", inputs: [] },
    {
        type: "error",
        name: "EBOCore_Propose_ProposalAlreadyActive",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOCore_Resolve_DisputeNotEscalated",
        inputs: [],
    },
    { type: "error", name: "EBOCore_Resolve_InvalidStatus", inputs: [] },
    {
        type: "error",
        name: "EBOCore_Resolve_PledgeWindowNotOver",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOCore_Resolve_ProposalNotDisputed",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOPledge_ClaimPledgeReward_AlreadyClaimed",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOPledge_ClaimPledgeReward_DisputeHasNoResolution",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOPledge_ClaimPledgeReward_NoRewardToClaim",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOPledge_Pledge_CannotPledgeIfWinning",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOPledge_Pledge_PledgeWindowOver",
        inputs: [],
    },
    {
        type: "error",
        name: "EBOPledge_Pledge_ProposalNotDisputed",
        inputs: [],
    },
    {
        type: "error",
        name: "ERC1967InvalidImplementation",
        inputs: [
            {
                name: "implementation",
                type: "address",
                internalType: "address",
            },
        ],
    },
    { type: "error", name: "ERC1967NonPayable", inputs: [] },
    { type: "error", name: "FailedCall", inputs: [] },
    { type: "error", name: "InvalidInitialization", inputs: [] },
    { type: "error", name: "NotInitializing", inputs: [] },
    {
        type: "error",
        name: "SafeERC20FailedOperation",
        inputs: [{ name: "token", type: "address", internalType: "address" }],
    },
    { type: "error", name: "UUPSUnauthorizedCallContext", inputs: [] },
    {
        type: "error",
        name: "UUPSUnsupportedProxiableUUID",
        inputs: [{ name: "slot", type: "bytes32", internalType: "bytes32" }],
    },
] as const;
