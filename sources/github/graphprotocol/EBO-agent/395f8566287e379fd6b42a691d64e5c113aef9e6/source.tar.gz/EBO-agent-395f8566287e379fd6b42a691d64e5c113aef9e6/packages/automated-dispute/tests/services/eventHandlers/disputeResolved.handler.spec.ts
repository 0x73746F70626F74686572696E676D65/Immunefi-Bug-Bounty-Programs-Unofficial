import { BlockNumberService } from "@ebo-agent/blocknumber";
import { Caip2ChainId, ILogger, UnixTimestamp } from "@ebo-agent/shared";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { DisputeResolvedHandler } from "../../../src/services/eventHandlers/disputeResolved.handler.js";
import { EboEventV2, ProposalId, ProposalStatus } from "../../../src/types/index.js";
import mocks from "../../mocks/index.js";

describe("DisputeResolvedHandler", () => {
    let handler: DisputeResolvedHandler;
    let logger: ILogger;
    let protocolProvider: any;
    let blockNumberService: BlockNumberService;
    let actorProposal: any;

    beforeEach(() => {
        logger = mocks.mockLogger();

        protocolProvider = {
            getAccountAddress: vi.fn().mockReturnValue("0xuser"),
        };

        blockNumberService = {} as BlockNumberService;

        actorProposal = {
            id: 1n as ProposalId,
            chainId: "eip155:1" as Caip2ChainId,
            proposal: {
                createdAt: 1000n as UnixTimestamp,
            },
            parameters: {
                disputeWindow: 3600n,
            },
            epoch: 1n,
        };

        handler = new DisputeResolvedHandler({
            actorProposal,
            protocolProvider,
            blockNumberService,
            logger,
        });
    });

    it("logs when a dispute is resolved with DisputerWon status", async () => {
        const proposalId = 1n as ProposalId;
        const event: EboEventV2 & { name: "DisputeResolved" } = {
            name: "DisputeResolved",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId,
            args: {
                proposalId,
                resolutionStatus: ProposalStatus.DisputerWon,
            },
        };

        await handler.run(event);

        expect(logger.info).toHaveBeenCalledWith(
            `Proposal ${event.proposalId} dispute has been resolved with status ${ProposalStatus[event.args.resolutionStatus]}.`,
            {
                proposalId: event.proposalId,
                resolutionStatus: event.args.resolutionStatus,
            },
        );
    });

    it("logs when a dispute is resolved with DisputerLost status", async () => {
        const proposalId = 1n as ProposalId;
        const event: EboEventV2 & { name: "DisputeResolved" } = {
            name: "DisputeResolved",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId,
            args: {
                proposalId,
                resolutionStatus: ProposalStatus.DisputerLost,
            },
        };

        await handler.run(event);

        expect(logger.info).toHaveBeenCalledWith(
            `Proposal ${event.proposalId} dispute has been resolved with status ${ProposalStatus[event.args.resolutionStatus]}.`,
            {
                proposalId: event.proposalId,
                resolutionStatus: event.args.resolutionStatus,
            },
        );
    });

    it("logs when a dispute is resolved with NoResolution status", async () => {
        const proposalId = 1n as ProposalId;
        const event: EboEventV2 & { name: "DisputeResolved" } = {
            name: "DisputeResolved",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId,
            args: {
                proposalId,
                resolutionStatus: ProposalStatus.NoResolution,
            },
        };

        await handler.run(event);

        expect(logger.info).toHaveBeenCalledWith(
            `Proposal ${event.proposalId} dispute has been resolved with status ${ProposalStatus[event.args.resolutionStatus]}.`,
            {
                proposalId: event.proposalId,
                resolutionStatus: event.args.resolutionStatus,
            },
        );
    });
});
