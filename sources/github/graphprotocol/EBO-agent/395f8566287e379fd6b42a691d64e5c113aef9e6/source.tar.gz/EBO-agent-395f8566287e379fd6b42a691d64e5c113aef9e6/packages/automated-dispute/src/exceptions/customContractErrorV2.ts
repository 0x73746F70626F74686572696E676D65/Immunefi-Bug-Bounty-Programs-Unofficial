import {
    EboEventV2,
    ErrorContextV2,
    ErrorHandlingStrategyV2,
    ErrorNameV2,
} from "../types/index.js";
import { ErrorContextNotSetException } from "./index.js";

export class CustomContractErrorV2 extends Error {
    public override name: ErrorNameV2;
    public strategy: ErrorHandlingStrategyV2;
    public context!: ErrorContextV2;
    private customActions: Map<ErrorNameV2, (context: ErrorContextV2) => Promise<void> | void> =
        new Map();

    constructor(name: ErrorNameV2, strategy: ErrorHandlingStrategyV2) {
        super(`Contract reverted: ${name}`);
        this.name = name;
        this.strategy = strategy;
    }

    public setContext(context: ErrorContextV2): this {
        this.context = context;
        return this;
    }

    public getContext(): ErrorContextV2 {
        if (!this.context) throw new ErrorContextNotSetException("Context is not set");
        return this.context;
    }

    /**
     * Sets the context specific to processEvents.
     * This method replaces addContext for processEvents-related context updates.
     *
     * @param event The event being processed.
     * @param reenqueueEvent Callback to reenqueue the event.
     * @param terminateActor Callback to terminate the actor.
     * @returns The error instance.
     */
    public setProcessEventsContext(
        event: EboEventV2,
        reenqueueEvent: () => void,
        terminateActor: () => void,
    ): this {
        this.context = {
            ...this.context,
            event,
            reenqueueEvent,
            terminateActor,
        };
        return this;
    }

    public on(errorName: string, action: (context: ErrorContextV2) => Promise<void> | void): this {
        if (this.name === errorName) {
            this.customActions.set(errorName, action);
        }
        return this;
    }

    public async executeCustomAction(): Promise<void> {
        const action = this.customActions.get(this.name) || this.strategy.customAction;
        if (action) {
            await action(this.context);
        }
    }
}
