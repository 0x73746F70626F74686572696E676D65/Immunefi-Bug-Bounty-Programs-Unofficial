import { BlockNumberService } from "@ebo-agent/blocknumber";
import { Caip2ChainId, ILogger, NotificationService, UnixTimestamp } from "@ebo-agent/shared";
import { Mutex } from "async-mutex";
import { Address, keccak256, Log, stringToBytes } from "viem";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import {
    ErrorFactoryV2,
    InvalidActorState,
    MissingEventHandler,
    PastEventEnqueueError,
    ProposalMismatch,
} from "../../src/exceptions/index.js";
import { ProtocolProviderV2 } from "../../src/providers/index.js";
import { EboActorV2 } from "../../src/services/eboActorV2.js";
import {
    DisputeEscalatedHandler,
    DisputeResolvedHandler,
    ProposalCreatedHandler,
    ProposalFinalizedHandler,
    WithPledgeActionBaseHandler,
} from "../../src/services/eventHandlers/index.js";
import {
    ActorProposal,
    DisputeV2,
    EboEventV2,
    Proposal,
    ProposalCreatedV2,
    ProposalId,
    ProposalStatus,
    SnapshotParameters,
} from "../../src/types/index.js";

describe("EboActorV2", () => {
    // Setup fixtures
    const mockProposalId = 1n as ProposalId;
    const mockEpoch = 1n;
    const mockChainId = "eip155:1" as Caip2ChainId;
    const mockBlockNumber = 100n;
    const mockProposer = "0x123" as Address;
    const mockCreatedAt = 1000n;
    const mockParametersSnapshotId = 1n;

    const mockProposal: Proposal = {
        epoch: mockEpoch,
        chainId: mockChainId,
        blockNumber: mockBlockNumber,
        proposer: mockProposer,
        createdAt: mockCreatedAt,
        parametersSnapshotId: mockParametersSnapshotId,
        status: ProposalStatus.Active,
    };

    // Define mockDispute for future test cases involving disputes
    const mockDispute: DisputeV2 = {
        disputer: "0x456" as Address,
        createdAt: 1100n,
        lastPledgeTimestamp: 1100n,
        totalPledgesForDispute: 0n,
        totalPledgesAgainstDispute: 0n,
        rewardPerWinningPledge: 0n,
    };

    const mockParameters: SnapshotParameters = {
        proposalBondSize: 100n,
        pledgeBondSize: 10n,
        minThawingPeriod: 1000n,
        disputeWindow: 86400n, // 24 hours
        pledgeWindow: 172800n, // 48 hours
        pledgeRefreshWindow: 3600n, // 1 hour
        maxNumberOfPledges: 5n,
    };

    const mockActorProposal: ActorProposal = {
        id: mockProposalId,
        epoch: mockEpoch,
        chainId: mockChainId,
        proposal: mockProposal,
        dispute: undefined,
        parameters: mockParameters,
    };

    // Mock provider, services
    const mockProtocolProvider = {
        getDisputeByProposalId: vi.fn(),
        write: {
            finalize: vi.fn().mockResolvedValue(undefined),
            resolve: vi.fn().mockResolvedValue(undefined),
        } as any,
    } as unknown as ProtocolProviderV2;

    const mockBlockNumberService = {} as BlockNumberService;
    const mockMutex = new Mutex();
    const mockLogger = {
        info: vi.fn(),
        error: vi.fn(),
        debug: vi.fn(),
        warn: vi.fn(),
    } as unknown as ILogger;
    const mockNotificationService = {} as NotificationService;

    // Create a base ProposalCreated event
    const createMockEvent = (): EboEventV2 => {
        const proposalCreatedArgs: ProposalCreatedV2 = {
            proposalId: mockProposalId,
            epoch: mockEpoch,
            chainId: keccak256(stringToBytes(mockChainId)),
            blockNumber: mockBlockNumber,
            serviceProvider: "0x789" as Address,
        };

        return {
            name: "ProposalCreated",
            blockNumber: 200n,
            logIndex: 1,
            timestamp: 2000n as UnixTimestamp,
            proposalId: mockProposalId,
            args: proposalCreatedArgs,
            rawLog: {} as Log,
        };
    };

    // Create a modified version of the base event with type safety
    const createModifiedEvent = (overrides: Partial<EboEventV2>): EboEventV2 => {
        const baseEvent = createMockEvent();
        // We need this type assertion because TypeScript doesn't understand
        // that we're preserving the discriminated union structure
        return { ...baseEvent, ...overrides } as EboEventV2;
    };

    // Create actor for tests
    const createActor = () => {
        return new EboActorV2(
            mockActorProposal,
            mockProtocolProvider,
            mockBlockNumberService,
            mockMutex,
            mockLogger,
            mockNotificationService,
        );
    };

    afterEach(() => {
        vi.restoreAllMocks();
    });

    describe("enqueue", () => {
        it("enqueues an event", () => {
            const actor = createActor();
            const event = createMockEvent();

            // Spy on the private eventsQueue.push method
            const pushSpy = vi.spyOn(actor["eventsQueue"], "push");

            actor.enqueue(event);

            expect(pushSpy).toHaveBeenCalledWith(event);
        });

        it("throws when the event's proposal does not match with actor's proposal", () => {
            const actor = createActor();
            const event = createModifiedEvent({ proposalId: 2n as ProposalId });

            expect(() => actor.enqueue(event)).toThrow(ProposalMismatch);
            expect(mockLogger.error).toHaveBeenCalled();
        });

        it("throws when an older event is enqueued after processing newer events", async () => {
            const actor = createActor();

            // First event
            const newerEvent = createModifiedEvent({
                blockNumber: 300n,
            });

            // Event with older block number
            const olderEvent = createModifiedEvent({
                blockNumber: 200n,
            });

            // Mock onLastEvent to resolve immediately for testing
            actor["onLastEvent"] = vi.fn().mockResolvedValue(undefined);

            // Enqueue and process the newer event first
            actor.enqueue(newerEvent);
            await actor.processEvents();

            // Now try to enqueue an older event, which should throw
            expect(() => actor.enqueue(olderEvent)).toThrow(PastEventEnqueueError);
        });

        it("throws when an older event is enqueued after processing newer events same block number", async () => {
            const actor = createActor();

            // First event
            const newerEvent = createModifiedEvent({
                blockNumber: 300n,
                logIndex: 5,
            });

            // Event with older block number
            const olderEvent = createModifiedEvent({
                blockNumber: 300n,
                logIndex: 2,
            });

            // Mock onLastEvent to resolve immediately for testing
            actor["onLastEvent"] = vi.fn().mockResolvedValue(undefined);

            // Enqueue and process the newer event first
            actor.enqueue(newerEvent);
            await actor.processEvents();

            // Now try to enqueue an older event, which should throw
            expect(() => actor.enqueue(olderEvent)).toThrow(PastEventEnqueueError);
        });
    });

    describe("processEvents", () => {
        it("processes all events in the queue", async () => {
            const actor = createActor();

            // Mock the onLastEvent method to prevent actual handler calls
            actor["onLastEvent"] = vi.fn().mockResolvedValue(undefined);

            // Spy on the updateState method to verify it's called
            const updateStateSpy = vi.spyOn(actor as any, "updateState");

            // Create multiple events
            const event1 = createMockEvent();
            const event2 = createModifiedEvent({ blockNumber: 300n });

            // Enqueue events
            actor.enqueue(event1);
            actor.enqueue(event2);

            // Process events
            await actor.processEvents();

            // Verify updateState was called for both events
            expect(updateStateSpy).toHaveBeenCalledTimes(2);
            expect(updateStateSpy).toHaveBeenCalledWith(event1);
            expect(updateStateSpy).toHaveBeenCalledWith(event2);

            // Verify the queue is empty after processing
            expect(actor["eventsQueue"].size()).toBe(0);
        });

        it("updates actor state based on ProposalCreated event", async () => {
            const actor = createActor();
            const event = createMockEvent();

            // Mock the onLastEvent method
            actor["onLastEvent"] = vi.fn().mockResolvedValue(undefined);

            // Enqueue and process the event
            actor.enqueue(event);
            await actor.processEvents();

            // No state changes expected for ProposalCreated since proposal is already set during construction
            expect(actor["proposal"]).toEqual(mockProposal);
        });

        it("updates actor state based on ProposalFinalized event", async () => {
            const actor = createActor();

            // Create a ProposalFinalized event
            const event = createModifiedEvent({
                name: "ProposalFinalized",
                args: {
                    proposalId: mockProposalId,
                    epoch: mockEpoch,
                    chainId: keccak256(stringToBytes(mockChainId)),
                    blockNumber: mockBlockNumber,
                },
            });

            // Mock onLastEvent to avoid handler execution
            actor["onLastEvent"] = vi.fn().mockResolvedValue(undefined);

            // Enqueue and process the event
            actor.enqueue(event);
            await actor.processEvents();

            // Verify the proposal status was updated to Finalized
            expect(actor["proposal"].status).toBe(ProposalStatus.Finalized);
        });

        it("updates actor state based on ProposalDisputed event", async () => {
            const actor = createActor();

            // Ensure proposal status is Active before the test
            actor["proposal"].status = ProposalStatus.Active;

            // Create a ProposalDisputed event
            const event = createModifiedEvent({
                name: "ProposalDisputed",
                args: {
                    proposalId: mockProposalId,
                },
            });

            // Mock getDisputeByProposalId to return a dispute
            mockProtocolProvider.getDisputeByProposalId = vi.fn().mockResolvedValue(mockDispute);

            // Mock onLastEvent to avoid handler execution
            actor["onLastEvent"] = vi.fn().mockResolvedValue(undefined);

            // Enqueue and process the event
            actor.enqueue(event);
            await actor.processEvents();

            // Verify the proposal status was updated to Disputed
            expect(actor["proposal"].status).toBe(ProposalStatus.Disputed);

            // Verify that dispute was fetched and set
            expect(mockProtocolProvider.getDisputeByProposalId).toHaveBeenCalledWith(
                mockProposalId,
            );
            expect(actor["dispute"]).toEqual(mockDispute);
        });

        it("updates actor state based on DisputeEscalated event", async () => {
            const actor = createActor();

            // First change status to Disputed
            actor["proposal"].status = ProposalStatus.Disputed;

            // Create a DisputeEscalated event
            const event = createModifiedEvent({
                name: "DisputeEscalated",
                args: {
                    proposalId: mockProposalId,
                },
            });

            // Mock onLastEvent to avoid handler execution
            actor["onLastEvent"] = vi.fn().mockResolvedValue(undefined);

            // Enqueue and process the event
            actor.enqueue(event);
            await actor.processEvents();

            // Verify the proposal status was updated to Escalated
            expect(actor["proposal"].status).toBe(ProposalStatus.Escalated);
        });

        it("updates actor state based on DisputeResolved event", async () => {
            const actor = createActor();

            // First change status to Disputed
            actor["proposal"].status = ProposalStatus.Disputed;

            // Create a DisputeResolved event
            const event = createModifiedEvent({
                name: "DisputeResolved",
                args: {
                    proposalId: mockProposalId,
                    resolutionStatus: ProposalStatus.DisputerWon,
                },
            });

            // Mock onLastEvent to avoid handler execution
            actor["onLastEvent"] = vi.fn().mockResolvedValue(undefined);

            // Enqueue and process the event
            actor.enqueue(event);
            await actor.processEvents();

            // Verify the proposal status was updated to DisputerWon
            expect(actor["proposal"].status).toBe(ProposalStatus.DisputerWon);
        });

        it("updates actor state based on PledgedForDispute event", async () => {
            const actor = createActor();

            // Setup actor with existing dispute
            actor["proposal"].status = ProposalStatus.Disputed;
            actor["dispute"] = { ...mockDispute };

            // Create a PledgedForDispute event
            const event = createModifiedEvent({
                name: "PledgedForDispute",
                args: {
                    proposalId: mockProposalId,
                    pledger: "0xabc" as Address,
                    pledgeAmount: 10n,
                },
            });

            // Updated dispute after pledge
            const updatedDispute = {
                ...mockDispute,
                totalPledgesForDispute: 1n,
                lastPledgeTimestamp: 2100n,
            };

            // Mock getDisputeByProposalId to return updated dispute
            mockProtocolProvider.getDisputeByProposalId = vi.fn().mockResolvedValue(updatedDispute);

            // Mock onLastEvent to avoid handler execution
            actor["onLastEvent"] = vi.fn().mockResolvedValue(undefined);

            // Enqueue and process the event
            actor.enqueue(event);
            await actor.processEvents();

            // Verify dispute was updated
            expect(mockProtocolProvider.getDisputeByProposalId).toHaveBeenCalledWith(
                mockProposalId,
            );
            expect(actor["dispute"]).toEqual(updatedDispute);
        });

        it("updates actor state based on PledgedAgainstDispute event", async () => {
            const actor = createActor();

            // Setup actor with existing dispute
            actor["proposal"].status = ProposalStatus.Disputed;
            actor["dispute"] = { ...mockDispute };

            // Create a PledgedAgainstDispute event
            const event = createModifiedEvent({
                name: "PledgedAgainstDispute",
                args: {
                    proposalId: mockProposalId,
                    pledger: "0xabc" as Address,
                    pledgeAmount: 10n,
                },
            });

            // Updated dispute after pledge
            const updatedDispute = {
                ...mockDispute,
                totalPledgesAgainstDispute: 1n,
                lastPledgeTimestamp: 2100n,
            };

            // Mock getDisputeByProposalId to return updated dispute
            mockProtocolProvider.getDisputeByProposalId = vi.fn().mockResolvedValue(updatedDispute);

            // Mock onLastEvent to avoid handler execution
            actor["onLastEvent"] = vi.fn().mockResolvedValue(undefined);

            // Enqueue and process the event
            actor.enqueue(event);
            await actor.processEvents();

            // Verify dispute was updated
            expect(mockProtocolProvider.getDisputeByProposalId).toHaveBeenCalledWith(
                mockProposalId,
            );
            expect(actor["dispute"]).toEqual(updatedDispute);
        });

        it("throws InvalidActorState when trying to update states in invalid transitions", async () => {
            const actor = createActor();

            // Manually set the proposal state to Finalized
            actor["proposal"].status = ProposalStatus.Finalized;

            // Create a ProposalDisputed event
            const event = createModifiedEvent({
                name: "ProposalDisputed",
                args: {
                    proposalId: mockProposalId,
                },
            });

            // Enqueue the event
            actor.enqueue(event);

            // Expect the process to throw InvalidActorState
            await expect(actor.processEvents()).rejects.toThrow(InvalidActorState);
        });

        it("handles CustomContractErrorV2 by delegating to errorHandler", async () => {
            const actor = createActor();
            const event = createMockEvent();

            // Create a CustomContractErrorV2
            const contractError = ErrorFactoryV2.createError("TestError");
            contractError.setProcessEventsContext = vi.fn();

            // Mock onLastEvent to throw the error
            actor["onLastEvent"] = vi.fn().mockRejectedValue(contractError);

            // Mock the errorHandler.handle method
            const errorHandlerSpy = vi.spyOn(actor["errorHandler"], "handle").mockResolvedValue();

            // Enqueue the event
            actor.enqueue(event);

            // Process events
            await actor.processEvents();

            // Verify error handler was called with the correct error
            expect(errorHandlerSpy).toHaveBeenCalledWith(contractError);

            // Verify that the context was set before handling with expected parameters
            expect(contractError.setProcessEventsContext).toHaveBeenCalledWith(
                event,
                expect.any(Function),
                expect.any(Function),
            );
        });

        it("rethrows non-CustomContractErrorV2 errors", async () => {
            const actor = createActor();
            const event = createMockEvent();

            // Create a generic error
            const genericError = new Error("Generic error");

            // Mock onLastEvent to throw the error
            actor["onLastEvent"] = vi.fn().mockRejectedValue(genericError);

            // Enqueue the event
            actor.enqueue(event);

            // Expect the process to throw the generic error
            await expect(actor.processEvents()).rejects.toThrow(genericError);
        });

        it("ensures mutual exclusion of event processing", async () => {
            // We'll use fake timers to control async timing
            vi.useFakeTimers();

            try {
                const actor = createActor();

                // Explicitly set the proposal status to Active before testing
                actor["proposal"].status = ProposalStatus.Active;

                // Create two real events with different types
                const event1 = createModifiedEvent({
                    name: "ProposalDisputed",
                    args: {
                        proposalId: mockProposalId,
                    },
                });

                const event2 = createModifiedEvent({
                    name: "DisputeEscalated",
                    args: {
                        proposalId: mockProposalId,
                    },
                    blockNumber: 300n, // Higher block number for chronological ordering
                });

                // Track which events were processed and in what order
                const processedEvents: string[] = [];

                // Mock dispute data to be returned when fetching dispute
                mockProtocolProvider.getDisputeByProposalId = vi
                    .fn()
                    .mockResolvedValue(mockDispute);

                // Mock the onLastEvent implementation for the first call to take longer
                actor["onLastEvent"] = vi
                    .fn()
                    .mockImplementationOnce(async (event) => {
                        processedEvents.push(`start-${event.name}`);
                        await vi.advanceTimersByTimeAsync(100);
                        processedEvents.push(`end-${event.name}`);
                    })
                    .mockImplementationOnce(async (event) => {
                        processedEvents.push(`start-${event.name}`);
                        await vi.advanceTimersByTimeAsync(10);
                        processedEvents.push(`end-${event.name}`);
                    });

                // Enqueue first event and start processing
                actor.enqueue(event1);
                const promise1 = actor.processEvents();

                // Start the first event handler
                await vi.advanceTimersByTimeAsync(10);

                // Try to process events again immediately with a second event
                actor.enqueue(event2);
                const promise2 = actor.processEvents();

                // Let the first event handler complete
                await vi.advanceTimersByTimeAsync(100);

                // Let the second event handler complete
                await vi.advanceTimersByTimeAsync(100);

                // Wait for both processes to complete
                await Promise.all([promise1, promise2]);

                // Verify execution order - the second process should wait for the first to complete
                expect(processedEvents).toEqual([
                    "start-ProposalDisputed",
                    "end-ProposalDisputed",
                    "start-DisputeEscalated",
                    "end-DisputeEscalated",
                ]);

                // Verify the state changes occurred in correct order
                expect(actor["proposal"].status).toBe(ProposalStatus.Escalated);
            } finally {
                // Restore real timers
                vi.useRealTimers();
            }
        });
    });

    describe("onLastEvent", () => {
        it("calls ProposalCreatedHandler for ProposalCreated events", async () => {
            const actor = createActor();
            const event = createMockEvent(); // Default is ProposalCreated

            // Mock handler's run method
            const runMock = vi.fn().mockResolvedValue(undefined);

            // Mock the ProposalCreatedHandler constructor to return an object with run method
            vi.spyOn(ProposalCreatedHandler.prototype, "run").mockImplementation(runMock);

            // Call the private onLastEvent method directly
            await actor["onLastEvent"](event);

            // Verify handler was constructed and run was called with the event
            expect(ProposalCreatedHandler.prototype.run).toHaveBeenCalledWith(event);
        });

        it("calls ProposalFinalizedHandler for ProposalFinalized events", async () => {
            const actor = createActor();
            const event = createModifiedEvent({
                name: "ProposalFinalized",
                args: {
                    proposalId: mockProposalId,
                    epoch: mockEpoch,
                    chainId: keccak256(stringToBytes(mockChainId)),
                    blockNumber: mockBlockNumber,
                },
            });

            // Mock handler's run method
            const runMock = vi.fn().mockResolvedValue(undefined);

            // Mock the ProposalFinalizedHandler constructor to return an object with run method
            vi.spyOn(ProposalFinalizedHandler.prototype, "run").mockImplementation(runMock);

            // Call the private onLastEvent method directly
            await actor["onLastEvent"](event);

            // Verify handler was constructed and run was called with the event
            expect(ProposalFinalizedHandler.prototype.run).toHaveBeenCalledWith(event);
        });

        it("calls WithPledgeActionBaseHandler for ProposalDisputed events", async () => {
            const actor = createActor();
            const event = createModifiedEvent({
                name: "ProposalDisputed",
                args: {
                    proposalId: mockProposalId,
                },
            });

            // Mock handler's run method
            const runMock = vi.fn().mockResolvedValue(undefined);

            // Mock the WithPledgeActionBaseHandler constructor to return an object with run method
            vi.spyOn(WithPledgeActionBaseHandler.prototype, "run").mockImplementation(runMock);

            // Call the private onLastEvent method directly
            await actor["onLastEvent"](event);

            // Verify handler was constructed and run was called with the event
            expect(WithPledgeActionBaseHandler.prototype.run).toHaveBeenCalledWith(event);
        });

        it("calls WithPledgeActionBaseHandler for PledgedForDispute events", async () => {
            const actor = createActor();
            const event = createModifiedEvent({
                name: "PledgedForDispute",
                args: {
                    proposalId: mockProposalId,
                    pledger: "0xabc" as Address,
                    pledgeAmount: 10n,
                },
            });

            // Mock handler's run method
            const runMock = vi.fn().mockResolvedValue(undefined);

            // Mock the WithPledgeActionBaseHandler constructor to return an object with run method
            vi.spyOn(WithPledgeActionBaseHandler.prototype, "run").mockImplementation(runMock);

            // Call the private onLastEvent method directly
            await actor["onLastEvent"](event);

            // Verify handler was constructed and run was called with the event
            expect(WithPledgeActionBaseHandler.prototype.run).toHaveBeenCalledWith(event);
        });

        it("calls WithPledgeActionBaseHandler for PledgedAgainstDispute events", async () => {
            const actor = createActor();
            const event = createModifiedEvent({
                name: "PledgedAgainstDispute",
                args: {
                    proposalId: mockProposalId,
                    pledger: "0xabc" as Address,
                    pledgeAmount: 10n,
                },
            });

            // Mock handler's run method
            const runMock = vi.fn().mockResolvedValue(undefined);

            // Mock the WithPledgeActionBaseHandler constructor to return an object with run method
            vi.spyOn(WithPledgeActionBaseHandler.prototype, "run").mockImplementation(runMock);

            // Call the private onLastEvent method directly
            await actor["onLastEvent"](event);

            // Verify handler was constructed and run was called with the event
            expect(WithPledgeActionBaseHandler.prototype.run).toHaveBeenCalledWith(event);
        });

        it("calls DisputeResolvedHandler for DisputeResolved events", async () => {
            const actor = createActor();
            const event = createModifiedEvent({
                name: "DisputeResolved",
                args: {
                    proposalId: mockProposalId,
                    resolutionStatus: ProposalStatus.DisputerWon,
                },
            });

            // Mock handler's run method
            const runMock = vi.fn().mockResolvedValue(undefined);

            // Mock the DisputeResolvedHandler constructor to return an object with run method
            vi.spyOn(DisputeResolvedHandler.prototype, "run").mockImplementation(runMock);

            // Call the private onLastEvent method directly
            await actor["onLastEvent"](event);

            // Verify handler was constructed and run was called with the event
            expect(DisputeResolvedHandler.prototype.run).toHaveBeenCalledWith(event);
        });

        it("calls DisputeEscalatedHandler for DisputeEscalated events", async () => {
            const actor = createActor();
            const event = createModifiedEvent({
                name: "DisputeEscalated",
                args: {
                    proposalId: mockProposalId,
                },
            });

            // Mock handler's run method
            const runMock = vi.fn().mockResolvedValue(undefined);

            // Mock the DisputeEscalatedHandler constructor to return an object with run method
            vi.spyOn(DisputeEscalatedHandler.prototype, "run").mockImplementation(runMock);

            // Call the private onLastEvent method directly
            await actor["onLastEvent"](event);

            // Verify handler was constructed and run was called with the event
            expect(DisputeEscalatedHandler.prototype.run).toHaveBeenCalledWith(event);
        });

        it("throws MissingEventHandler for unrecognized event types", async () => {
            const actor = createActor();

            // Create a mock event with an invalid name (forcing a type cast)
            const event = {
                ...createMockEvent(),
                name: "InvalidEventName" as any,
            } as EboEventV2;

            // Call the private onLastEvent method directly and expect it to throw
            await expect(actor["onLastEvent"](event)).rejects.toThrow(MissingEventHandler);
        });
    });

    describe("canBeTerminated", () => {
        it("returns false when current epoch is the same as the actor's epoch", () => {
            const actor = createActor();
            const currentEpoch = mockEpoch;

            // Set a terminal state just to ensure it's the epoch check that's being tested
            actor["proposal"].status = ProposalStatus.Finalized;

            // Should return false because the epoch has not advanced
            expect(actor.canBeTerminated(currentEpoch)).toBe(false);
        });

        it("returns false when proposal status is not terminal", () => {
            const actor = createActor();
            const nextEpoch = mockEpoch + 1n;

            // Ensure proposal is in a non-terminal state
            actor["proposal"].status = ProposalStatus.Active;

            // Should return false because the proposal is not in a terminal state
            expect(actor.canBeTerminated(nextEpoch)).toBe(false);
        });

        it("returns true when proposal status is DisputerLost and epoch has advanced", () => {
            const actor = createActor();
            const nextEpoch = mockEpoch + 1n;

            // Set proposal to DisputerLost state
            actor["proposal"].status = ProposalStatus.DisputerLost;

            // Should return true because both conditions are met
            expect(actor.canBeTerminated(nextEpoch)).toBe(true);
        });

        it("returns true when proposal status is DisputerWon and epoch has advanced", () => {
            const actor = createActor();
            const nextEpoch = mockEpoch + 1n;

            // Set proposal to DisputerWon state
            actor["proposal"].status = ProposalStatus.DisputerWon;

            // Should return true because both conditions are met
            expect(actor.canBeTerminated(nextEpoch)).toBe(true);
        });

        it("returns true when proposal status is NoResolution and epoch has advanced", () => {
            const actor = createActor();
            const nextEpoch = mockEpoch + 1n;

            // Set proposal to NoResolution state
            actor["proposal"].status = ProposalStatus.NoResolution;

            // Should return true because both conditions are met
            expect(actor.canBeTerminated(nextEpoch)).toBe(true);
        });

        it("returns true when proposal status is Finalized and epoch has advanced", () => {
            const actor = createActor();
            const nextEpoch = mockEpoch + 1n;

            // Set proposal to Finalized state
            actor["proposal"].status = ProposalStatus.Finalized;

            // Should return true because both conditions are met
            expect(actor.canBeTerminated(nextEpoch)).toBe(true);
        });
    });

    describe("onLastBlockUpdated", () => {
        // Base timestamp: March 1st 2025
        const baseTimestamp = 1740870187n;

        beforeEach(() => {
            mockProtocolProvider.write.finalize = vi.fn().mockResolvedValue(undefined);
            mockProtocolProvider.write.resolve = vi.fn().mockResolvedValue(undefined);
        });

        it("calls finalizeRequest when dispute window has passed for active proposal", async () => {
            const actor = createActor();

            actor["proposal"].status = ProposalStatus.Active;
            actor["proposal"].createdAt = baseTimestamp;
            actor["parameters"].disputeWindow = 86400n; // 24 hours

            await actor.onLastBlockUpdated((baseTimestamp + 86401n) as UnixTimestamp);

            expect(mockProtocolProvider.write.finalize).toHaveBeenCalledWith(mockProposalId);
        });

        it("does not call finalizeRequest when dispute window has not passed", async () => {
            const actor = createActor();

            actor["proposal"].status = ProposalStatus.Active;
            actor["proposal"].createdAt = baseTimestamp;
            actor["parameters"].disputeWindow = 86400n; // 24 hours

            await actor.onLastBlockUpdated((baseTimestamp + 86399n) as UnixTimestamp);

            expect(mockProtocolProvider.write.finalize).not.toHaveBeenCalled();
        });

        it("calls resolveDispute when pledge window and refresh window have passed for disputed proposal", async () => {
            const actor = createActor();

            actor["proposal"].status = ProposalStatus.Disputed;
            actor["dispute"] = {
                ...mockDispute,
                createdAt: baseTimestamp - 176400n, // 49 hours ago
                lastPledgeTimestamp: baseTimestamp - 7200n, // 2 hours ago
            };

            actor["parameters"].pledgeWindow = 172800n; // 48 hours
            actor["parameters"].pledgeRefreshWindow = 3600n; // 1 hour

            await actor.onLastBlockUpdated(baseTimestamp as UnixTimestamp);

            expect(mockProtocolProvider.write.resolve).toHaveBeenCalledWith(mockProposalId);
        });

        it("does not call resolveDispute when pledge window has not passed", async () => {
            const actor = createActor();

            actor["proposal"].status = ProposalStatus.Disputed;
            actor["dispute"] = {
                ...mockDispute,
                createdAt: baseTimestamp - 86400n, // Only 24 hours ago (48 hours needed)
                lastPledgeTimestamp: baseTimestamp - 86400n,
            };

            actor["parameters"].pledgeWindow = 172800n; // 48 hours
            actor["parameters"].pledgeRefreshWindow = 3600n; // 1 hour

            await actor.onLastBlockUpdated(baseTimestamp as UnixTimestamp);

            expect(mockProtocolProvider.write.resolve).not.toHaveBeenCalled();
        });

        it("does not call resolveDispute when main pledge window passed but refresh window has not", async () => {
            const actor = createActor();

            actor["proposal"].status = ProposalStatus.Disputed;
            actor["dispute"] = {
                ...mockDispute,
                createdAt: baseTimestamp - 172900n, // Just over 48 hours ago
                lastPledgeTimestamp: baseTimestamp - 1800n, // Only 30 minutes ago (1 hour needed)
            };

            actor["parameters"].pledgeWindow = 172800n; // 48 hours
            actor["parameters"].pledgeRefreshWindow = 3600n; // 1 hour

            await actor.onLastBlockUpdated(baseTimestamp as UnixTimestamp);

            expect(mockProtocolProvider.write.resolve).not.toHaveBeenCalled();
        });

        it("calls pledgeDispute when proposal is disputed and in pledge window", async () => {
            const actor = createActor();

            // Mock the pledgeDispute method to verify it's called
            const pledgeDisputeSpy = vi.spyOn(actor as any, "pledgeDispute");

            // Set up proposal as disputed
            actor["proposal"].status = ProposalStatus.Disputed;
            actor["dispute"] = {
                ...mockDispute,
                createdAt: baseTimestamp - 86400n, // 24 hours ago (within 48 hour window)
                lastPledgeTimestamp: baseTimestamp - 1800n, // 30 minutes ago (within refresh window)
            };

            actor["parameters"].pledgeWindow = 172800n; // 48 hours
            actor["parameters"].pledgeRefreshWindow = 3600n; // 1 hour

            await actor.onLastBlockUpdated(baseTimestamp as UnixTimestamp);

            // Verify pledgeDispute was called
            expect(pledgeDisputeSpy).toHaveBeenCalled();
        });

        it("does not call pledgeDispute when proposal is not disputed", async () => {
            const actor = createActor();

            // Mock the pledgeDispute method to verify it's not called
            const pledgeDisputeSpy = vi.spyOn(actor as any, "pledgeDispute");

            // Set up proposal as active (not disputed)
            actor["proposal"].status = ProposalStatus.Active;

            await actor.onLastBlockUpdated(baseTimestamp as UnixTimestamp);

            // Verify pledgeDispute was not called
            expect(pledgeDisputeSpy).not.toHaveBeenCalled();
        });

        it("does not call pledgeDispute when pledge window has passed", async () => {
            const actor = createActor();

            // Mock the pledgeDispute method to verify it's not called
            const pledgeDisputeSpy = vi.spyOn(actor as any, "pledgeDispute");

            // Set up proposal as disputed but outside pledge window
            actor["proposal"].status = ProposalStatus.Disputed;
            actor["dispute"] = {
                ...mockDispute,
                createdAt: baseTimestamp - 176400n, // 49 hours ago (outside 48 hour window)
                lastPledgeTimestamp: baseTimestamp - 7200n, // 2 hours ago (outside refresh window)
            };

            actor["parameters"].pledgeWindow = 172800n; // 48 hours
            actor["parameters"].pledgeRefreshWindow = 3600n; // 1 hour

            await actor.onLastBlockUpdated(baseTimestamp as UnixTimestamp);

            // Verify pledgeDispute was not called
            expect(pledgeDisputeSpy).not.toHaveBeenCalled();
        });

        it("successfully handles a pledge using the WithPledgeActionBaseHandler", async () => {
            const actor = createActor();

            // Setup the actor with a disputed proposal
            actor["proposal"].status = ProposalStatus.Disputed;
            actor["dispute"] = {
                ...mockDispute,
                createdAt: baseTimestamp - 86400n, // 24 hours ago
                lastPledgeTimestamp: baseTimestamp - 1800n, // 30 minutes ago
                totalPledgesForDispute: 0n,
                totalPledgesAgainstDispute: 1n, // We're losing, so should pledge
            };

            actor["parameters"].pledgeWindow = 172800n; // 48 hours
            actor["parameters"].pledgeRefreshWindow = 3600n; // 1 hour

            // Mock getDisputeByProposalId to return our dispute
            mockProtocolProvider.getDisputeByProposalId = vi
                .fn()
                .mockResolvedValue(actor["dispute"]);

            // Mock the WithPledgeActionBaseHandler run method
            const handlerRunMock = vi.fn().mockResolvedValue(undefined);
            vi.spyOn(WithPledgeActionBaseHandler.prototype, "run").mockImplementation(
                handlerRunMock,
            );

            // Trigger the pledgeDispute via onLastBlockUpdated
            await actor.onLastBlockUpdated(baseTimestamp as UnixTimestamp);

            // Verify the handler's run method was called with the correct event type
            expect(WithPledgeActionBaseHandler.prototype.run).toHaveBeenCalledWith(
                expect.objectContaining({
                    name: "ProposalDisputed",
                    proposalId: mockProposalId,
                }),
            );
        });

        it("handles CustomContractErrorV2 when pledging for dispute", async () => {
            const actor = createActor();

            // Setup the actor with a disputed proposal
            actor["proposal"].status = ProposalStatus.Disputed;
            actor["dispute"] = {
                ...mockDispute,
                createdAt: baseTimestamp - 86400n, // 24 hours ago
                lastPledgeTimestamp: baseTimestamp - 1800n, // 30 minutes ago
            };

            actor["parameters"].pledgeWindow = 172800n; // 48 hours
            actor["parameters"].pledgeRefreshWindow = 3600n; // 1 hour

            // Mock getDisputeByProposalId to return our dispute
            mockProtocolProvider.getDisputeByProposalId = vi
                .fn()
                .mockResolvedValue(actor["dispute"]);

            // Create a contract error
            const contractError = ErrorFactoryV2.createError("PledgeError");
            contractError.setContext = vi.fn();

            // Make WithPledgeActionBaseHandler.run throw the error
            vi.spyOn(WithPledgeActionBaseHandler.prototype, "run").mockRejectedValue(contractError);

            // Mock error handler
            const errorHandlerSpy = vi.spyOn(actor["errorHandler"], "handle").mockResolvedValue();

            // Trigger the pledgeDispute via onLastBlockUpdated
            await actor.onLastBlockUpdated(baseTimestamp as UnixTimestamp);

            // Verify error handler was called and context was set
            expect(mockLogger.warn).toHaveBeenCalled();
            expect(contractError.setContext).toHaveBeenCalled();
            expect(errorHandlerSpy).toHaveBeenCalledWith(contractError);
        });

        it("handles general error when pledging for dispute", async () => {
            const actor = createActor();

            // Setup the actor with a disputed proposal
            actor["proposal"].status = ProposalStatus.Disputed;
            actor["dispute"] = {
                ...mockDispute,
                createdAt: baseTimestamp - 86400n, // 24 hours ago
                lastPledgeTimestamp: baseTimestamp - 1800n, // 30 minutes ago
            };

            actor["parameters"].pledgeWindow = 172800n; // 48 hours
            actor["parameters"].pledgeRefreshWindow = 3600n; // 1 hour

            // Mock getDisputeByProposalId to return our dispute
            mockProtocolProvider.getDisputeByProposalId = vi
                .fn()
                .mockResolvedValue(actor["dispute"]);

            // Create a generic error
            const genericError = new Error("Generic pledge error");

            // Make WithPledgeActionBaseHandler.run throw the error
            vi.spyOn(WithPledgeActionBaseHandler.prototype, "run").mockRejectedValue(genericError);

            // Trigger the pledgeDispute via onLastBlockUpdated
            await actor.onLastBlockUpdated(baseTimestamp as UnixTimestamp);

            // Verify error was logged but not thrown (as pledgeDispute handles errors internally)
            expect(mockLogger.error).toHaveBeenCalledWith(
                expect.stringContaining("Failed to evaluate pledge opportunity"),
                expect.objectContaining({
                    proposalId: mockProposalId,
                    error: genericError,
                }),
            );
        });

        it("handles CustomContractErrorV2 when finalizing proposal", async () => {
            const actor = createActor();

            actor["proposal"].status = ProposalStatus.Active;
            actor["proposal"].createdAt = baseTimestamp;
            actor["parameters"].disputeWindow = 86400n; // 24 hours

            const contractError = ErrorFactoryV2.createError("FinalizeError");
            contractError.setContext = vi.fn();

            mockProtocolProvider.write.finalize = vi.fn().mockRejectedValue(contractError);

            const errorHandlerSpy = vi.spyOn(actor["errorHandler"], "handle").mockResolvedValue();

            await actor.onLastBlockUpdated((baseTimestamp + 86401n) as UnixTimestamp);

            expect(mockLogger.warn).toHaveBeenCalled();
            expect(contractError.setContext).toHaveBeenCalled();
            expect(errorHandlerSpy).toHaveBeenCalledWith(contractError);
        });

        it("handles generic error when finalizing proposal", async () => {
            const actor = createActor();

            actor["proposal"].status = ProposalStatus.Active;
            actor["proposal"].createdAt = baseTimestamp;
            actor["parameters"].disputeWindow = 86400n; // 24 hours

            const genericError = new Error("Generic error");

            mockProtocolProvider.write.finalize = vi.fn().mockRejectedValue(genericError);

            await expect(
                actor.onLastBlockUpdated((baseTimestamp + 86401n) as UnixTimestamp),
            ).rejects.toThrow(genericError);

            expect(mockLogger.error).toHaveBeenCalled();
        });

        it("handles CustomContractErrorV2 when resolving dispute", async () => {
            const actor = createActor();

            actor["proposal"].status = ProposalStatus.Disputed;
            actor["dispute"] = {
                ...mockDispute,
                createdAt: baseTimestamp - 176400n, // 49 hours ago
                lastPledgeTimestamp: baseTimestamp - 7200n, // 2 hours ago
            };

            actor["parameters"].pledgeWindow = 172800n; // 48 hours
            actor["parameters"].pledgeRefreshWindow = 3600n; // 1 hour

            const contractError = ErrorFactoryV2.createError("ResolveError");
            contractError.setContext = vi.fn();

            mockProtocolProvider.write.resolve = vi.fn().mockRejectedValue(contractError);

            const errorHandlerSpy = vi.spyOn(actor["errorHandler"], "handle").mockResolvedValue();

            await actor.onLastBlockUpdated(baseTimestamp as UnixTimestamp);

            expect(mockLogger.warn).toHaveBeenCalled();
            expect(contractError.setContext).toHaveBeenCalled();
            expect(errorHandlerSpy).toHaveBeenCalledWith(contractError);
        });

        it("handles generic error when resolving dispute", async () => {
            const actor = createActor();

            actor["proposal"].status = ProposalStatus.Disputed;
            actor["dispute"] = {
                ...mockDispute,
                createdAt: baseTimestamp - 176400n, // 49 hours ago
                lastPledgeTimestamp: baseTimestamp - 7200n, // 2 hours ago
            };

            actor["parameters"].pledgeWindow = 172800n; // 48 hours
            actor["parameters"].pledgeRefreshWindow = 3600n; // 1 hour

            const genericError = new Error("Generic error");

            mockProtocolProvider.write.resolve = vi.fn().mockRejectedValue(genericError);

            await expect(actor.onLastBlockUpdated(baseTimestamp as UnixTimestamp)).rejects.toThrow(
                genericError,
            );

            expect(mockLogger.error).toHaveBeenCalled();
        });
    });
});
