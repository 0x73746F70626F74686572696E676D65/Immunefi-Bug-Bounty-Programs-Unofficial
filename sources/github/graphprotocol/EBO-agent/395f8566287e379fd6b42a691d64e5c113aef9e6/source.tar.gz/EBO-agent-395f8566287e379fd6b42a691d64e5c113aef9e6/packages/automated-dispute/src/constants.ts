export const ProtocolContractsNamesV2 = ["ebo", "epochManager"] as const;
