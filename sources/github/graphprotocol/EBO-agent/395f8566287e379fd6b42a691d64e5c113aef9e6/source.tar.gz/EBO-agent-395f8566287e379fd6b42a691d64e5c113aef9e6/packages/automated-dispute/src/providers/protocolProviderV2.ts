import { BlockNumberService, UnsupportedChain } from "@ebo-agent/blocknumber";
import { Caip2ChainId, EBO_SUPPORTED_CHAIN_IDS, ILogger, UnixTimestamp } from "@ebo-agent/shared";
import { ExtractAbiEvent } from "abitype";
import { Mutex } from "async-mutex";
import lodash from "lodash";
import {
    Account,
    Address,
    BaseError,
    Block,
    Chain,
    ContractFunctionRevertedError,
    createPublicClient,
    createWalletClient,
    decodeEventLog,
    fallback,
    FallbackTransport,
    getContract,
    GetContractReturnType,
    Hex,
    http,
    HttpTransport,
    Log,
    PublicClient,
    WalletClient,
    zeroAddress,
} from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { arbitrum, arbitrumSepolia, mainnet, sepolia } from "viem/chains";

import type {
    IProtocolProviderV2,
    IReadProviderV2,
    IWriteProviderV2,
    ProtocolContractsAddressesV2,
} from "../interfaces/index.js";
import { eboAbi, epochManagerV2Abi } from "../abis/index.js";
import {
    BlockNumberServiceRequiredError,
    ErrorFactoryV2,
    FetchAvailableChainsError,
    InvalidBlockHashError,
    InvalidBlockRangeError,
    RpcUrlsEmpty,
    TransactionExecutionError,
    UnsupportedEvent,
} from "../exceptions/index.js";
import {
    DisputeV2,
    EboEventNameV2,
    eboEventsAbi,
    EboEventV2,
    Epoch,
    Proposal,
    ProposalId,
    ProposalStatus,
    SnapshotParameters,
} from "../types/index.js";

const { isEqual } = lodash;

// Define the configuration types
interface RpcConfig {
    chainId: Caip2ChainId;
    urls: string[];
    transactionReceiptConfirmations: number;
    timeout: number;
    retryInterval: number;
}

interface ProtocolRpcConfig {
    l1: RpcConfig;
    l2: RpcConfig;
}

type EboEventLog<eventName extends EboEventNameV2> = Log<
    bigint,
    number,
    false,
    ExtractAbiEvent<typeof eboEventsAbi, eventName>,
    true,
    typeof eboEventsAbi,
    eventName
>;

// null values don't exist on Solidity, the default values are used
const NULL_PROPOSAL: Omit<Proposal, "id"> = {
    epoch: 0n,
    chainId: "",
    blockNumber: 0n,
    proposer: zeroAddress,
    createdAt: 0n,
    parametersSnapshotId: 0n,
    status: ProposalStatus.None,
};
const NULL_SNAPSHOT_PARAMETERS: SnapshotParameters = {
    proposalBondSize: 0n,
    pledgeBondSize: 0n,
    minThawingPeriod: 0n,
    disputeWindow: 0n,
    pledgeWindow: 0n,
    pledgeRefreshWindow: 0n,
    maxNumberOfPledges: 0n,
};
const NULL_DISPUTE: DisputeV2 = {
    disputer: zeroAddress,
    createdAt: 0n,
    lastPledgeTimestamp: 0n,
    totalPledgesForDispute: 0n,
    totalPledgesAgainstDispute: 0n,
    rewardPerWinningPledge: 0n,
};
export class ProtocolProviderV2 implements IProtocolProviderV2 {
    private l1ReadClient: PublicClient<FallbackTransport<HttpTransport[]>>;
    private readonly l2ReadClient: PublicClient<FallbackTransport<HttpTransport[]>>;
    private readonly l2WriteClient: WalletClient<
        FallbackTransport<HttpTransport[]>,
        Chain,
        Account
    >;
    private readonly blockNumberService?: BlockNumberService;

    private eboContract: GetContractReturnType<typeof eboAbi, typeof this.l2WriteClient, Address>;

    private epochManagerContract: GetContractReturnType<
        typeof epochManagerV2Abi,
        typeof this.l2ReadClient,
        Address
    >;

    private writeMutex: Mutex;

    constructor(
        private readonly rpcConfig: ProtocolRpcConfig,
        contracts: ProtocolContractsAddressesV2,
        privateKey: Hex,
        private readonly logger: ILogger,
        blockNumberService?: BlockNumberService,
    ) {
        const l1Chain = this.getViemChain(rpcConfig.l1.chainId);
        const l2Chain = this.getViemChain(rpcConfig.l2.chainId);

        this.l1ReadClient = this.createReadClient(rpcConfig.l1, l1Chain);
        this.l2ReadClient = this.createReadClient(rpcConfig.l2, l2Chain);
        this.l2WriteClient = this.createWriteClient(rpcConfig.l2, l2Chain, privateKey);
        this.blockNumberService = blockNumberService;

        // Instantiate all the protocol contracts
        this.eboContract = getContract({
            address: contracts.ebo,
            abi: eboAbi,
            client: {
                public: this.l2ReadClient,
                wallet: this.l2WriteClient,
            },
        });

        this.epochManagerContract = getContract({
            address: contracts.epochManager,
            abi: epochManagerV2Abi,
            client: this.l2ReadClient,
        });

        this.writeMutex = new Mutex();
    }

    private createReadClient(
        config: RpcConfig,
        chain: Chain,
    ): PublicClient<FallbackTransport<HttpTransport[]>> {
        const { urls, timeout, retryInterval } = config;

        if (urls.length === 0) {
            throw new RpcUrlsEmpty();
        }

        return createPublicClient({
            chain: chain,
            transport: fallback(
                urls.map((url) => this.createHttpTransportWithLogging(url, timeout, retryInterval)),
            ),
        });
    }

    private createWriteClient(
        config: RpcConfig,
        chain: Chain,
        privateKey: Hex,
    ): WalletClient<FallbackTransport<HttpTransport[]>, Chain, Account> {
        const { urls, timeout, retryInterval } = config;
        const account = privateKeyToAccount(privateKey);

        return createWalletClient({
            chain: chain,
            transport: fallback(
                urls.map((url) => this.createHttpTransportWithLogging(url, timeout, retryInterval)),
            ),
            account: account,
        });
    }

    /**
     * Creates an HTTP transport with logging capabilities for requests and responses.
     *
     * This function sets up a custom HTTP transport that logs the details of each
     * HTTP request and response, including the URL, method, headers, and body.
     * The logging captures and logs the cloned `Request` and `Response` objects,
     * ensuring the original objects remain unaltered.
     *
     *
     * @param {string} url - The base URL for the HTTP transport.
     * @param {number} timeout - The timeout duration in milliseconds for each HTTP request.
     * @param {number} retryInterval - The delay in milliseconds before retrying a failed request.
     * @returns {HttpTransport} The configured HTTP transport with logging enabled.
     */
    private createHttpTransportWithLogging(
        url: string,
        timeout: number,
        retryInterval: number,
    ): HttpTransport {
        return http(url, {
            timeout: timeout,
            retryDelay: retryInterval,
            onFetchRequest: async (request) => {
                const reqObject = {
                    url: request.url,
                    method: request.method,
                    headers: Array.from(request.headers.entries()),
                    body: await request.clone().text(),
                };

                this.logger.debug(`Fetch Request`, reqObject);
            },
            onFetchResponse: async (response) => {
                const respObject = {
                    url: response.url,
                    status: response.status,
                    headers: Array.from(response.headers.entries()),
                    body: await response.clone().text(),
                };

                this.logger.debug(`Fetch Response`, respObject);
            },
        });
    }

    public read: IReadProviderV2 = {
        getCurrentEpoch: this.getCurrentEpoch.bind(this),
        getLastFinalizedBlock: this.getLastFinalizedBlock.bind(this),
        getEvents: this.getEvents.bind(this),
        getAvailableChains: this.getAvailableChains.bind(this),
        getProposalById: this.getProposalById.bind(this),
        getDisputeByProposalId: this.getDisputeByProposalId.bind(this),
        getActiveProposal: this.getActiveProposal.bind(this),
        getSnapshotParameters: this.getSnapshotParameters.bind(this),
    };

    public write: IWriteProviderV2 = {
        propose: this.propose.bind(this),
        dispute: this.dispute.bind(this),
        resolve: this.resolve.bind(this),
        finalize: this.finalize.bind(this),
        pledgeForDispute: this.pledgeForDispute.bind(this),
        pledgeAgainstDispute: this.pledgeAgainstDispute.bind(this),
    };

    /** @inheritdoc */
    public getAccountAddress(): Address {
        return this.l2WriteClient.account.address;
    }

    /**
     * Gets the current epoch, including the block number and its timestamp.
     *
     * NOTE: this method works on L1 block numbers as EpochManager contract uses blocks from L1.
     *
     * @returns {Promise<Epoch>} The current epoch, its block number, and its timestamp.
     */
    async getCurrentEpoch(): Promise<Epoch> {
        if (!this.blockNumberService) {
            throw new BlockNumberServiceRequiredError();
        }

        const [epoch, epochFirstBlockNumber] = await Promise.all([
            this.epochManagerContract.read.currentEpoch(),
            this.epochManagerContract.read.currentEpochBlock(),
        ]);

        const epochFirstBlock = await this.l1ReadClient.getBlock({
            blockNumber: epochFirstBlockNumber,
        });

        const startTimestamp = epochFirstBlock.timestamp as UnixTimestamp;

        const l2ChainId = this.rpcConfig.l2.chainId;
        const l2FirstBlockNumber = await this.blockNumberService.getEpochBlockNumber(
            startTimestamp,
            l2ChainId,
        );

        return {
            number: epoch,
            firstBlockNumber: l2FirstBlockNumber,
            startTimestamp: startTimestamp,
        };
    }

    /** @inheritdoc */
    async getLastFinalizedBlock(): Promise<Block<bigint, false, "finalized">> {
        return await this.l2ReadClient.getBlock({ blockTag: "finalized" });
    }

    /**
     * Fetches the timestamp for a given event by using its block hash.
     *
     * Note: We use block hash instead of block number due to an Anvil bug where events are generated with L1 block numbers
     * instead of L2 block numbers when forking Arbitrum. By using the block hash, we can get the correct timestamp
     * even if the block number is incorrect.
     *
     * @param event - The event for which to fetch the timestamp.
     * @returns The timestamp of the block in which the event was included.
     */
    private async getEventTimestamp(event: Log): Promise<UnixTimestamp> {
        if (event.blockHash === null) {
            throw new InvalidBlockHashError();
        }
        const block = await this.l2ReadClient.getBlock({ blockHash: event.blockHash });
        return block.timestamp as UnixTimestamp;
    }

    private getEboEventBaseFields(
        log: EboEventLog<EboEventNameV2>,
        timestamp: UnixTimestamp,
    ): Omit<EboEventV2, "args" | "proposalId" | "name"> {
        return {
            blockNumber: log.blockNumber,
            logIndex: log.logIndex,
            timestamp: timestamp,
            rawLog: log,
        };
    }

    /**
     * Fetches all EboEvents from the EBO contract within a specified block range.
     * Uses a single RPC call to get all Logs in the range.
     *
     * @param fromBlock - The starting block number.
     * @param toBlock - The ending block number.
     * @returns An array of EboEventV2 objects.
     */
    private async getEboEvents(fromBlock: bigint, toBlock: bigint): Promise<EboEventV2[]> {
        // Get all events logs in a single RPC call
        const allEvents = await this.l2ReadClient.getLogs({
            address: this.eboContract.address,
            fromBlock,
            toBlock,
            events: eboEventsAbi,
            strict: true,
        });

        return Promise.all(allEvents.map(async (log) => this.parseLogToEboEvent(log)));
    }

    /**
     * Parses a log to an EboEventV2 object.
     *
     * @param log - The log object containing the event data.
     * @returns The parsed EboEventV2 object.
     */
    private async parseLogToEboEvent(log: EboEventLog<EboEventNameV2>): Promise<EboEventV2> {
        const timestamp = await this.getEventTimestamp(log);

        // we have to decode the log on each case because TS complains about the topics typing
        switch (log.eventName) {
            case "ProposalCreated":
                return this.formatProposalCreatedEvent(
                    log as EboEventLog<"ProposalCreated">,
                    timestamp,
                );
            case "ProposalDisputed":
                return this.formatProposalDisputedEvent(
                    log as EboEventLog<"ProposalDisputed">,
                    timestamp,
                );
            case "ProposalFinalized":
                return this.formatProposalFinalizedEvent(
                    log as EboEventLog<"ProposalFinalized">,
                    timestamp,
                );

            case "PledgedForDispute":
                return this.formatPledgedForDisputeEvent(
                    log as EboEventLog<"PledgedForDispute">,
                    timestamp,
                );

            case "PledgedAgainstDispute":
                return this.formatPledgedAgainstDisputeEvent(
                    log as EboEventLog<"PledgedAgainstDispute">,
                    timestamp,
                );

            case "DisputeEscalated":
                return this.formatDisputeEscalatedEvent(
                    log as EboEventLog<"DisputeEscalated">,
                    timestamp,
                );

            case "DisputeResolved":
                return this.formatDisputeResolvedEvent(
                    log as EboEventLog<"DisputeResolved">,
                    timestamp,
                );
            //we should never reach this point and TS types log:never
            default:
                throw new UnsupportedEvent("Unsupported event");
        }
    }

    /**
     * Formats a ProposalCreated event.
     *
     * @param log - The log object containing the event data.
     * @param timestamp - The timestamp of the event.
     * @returns The formatted ProposalCreated event.
     */
    private formatProposalCreatedEvent(
        log: EboEventLog<"ProposalCreated">,
        timestamp: UnixTimestamp,
    ): EboEventV2 {
        const decoded = decodeEventLog({
            abi: eboEventsAbi,
            eventName: log.eventName,
            data: log.data,
            topics: log.topics,
            strict: true,
        });

        return {
            ...this.getEboEventBaseFields(log, timestamp),
            name: log.eventName,
            proposalId: decoded.args._proposalId as ProposalId,
            args: {
                proposalId: decoded.args._proposalId as ProposalId,
                epoch: decoded.args._epoch,
                chainId: decoded.args._chainId as Hex,
                blockNumber: decoded.args._blockNumber,
                serviceProvider: decoded.args._serviceProvider,
            },
        };
    }

    /**
     * Formats a ProposalDisputed event.
     *
     * @param log - The log object containing the event data.
     * @param timestamp - The timestamp of the event.
     * @returns The formatted ProposalDisputed event.
     */
    private formatProposalDisputedEvent(
        log: EboEventLog<"ProposalDisputed">,
        timestamp: UnixTimestamp,
    ): EboEventV2 {
        const decoded = decodeEventLog({
            abi: eboEventsAbi,
            eventName: log.eventName,
            data: log.data,
            topics: log.topics,
            strict: true,
        });

        return {
            ...this.getEboEventBaseFields(log, timestamp),
            name: log.eventName,
            proposalId: decoded.args._proposalId as ProposalId,
            args: {
                proposalId: decoded.args._proposalId as ProposalId,
            },
        };
    }

    /**
     * Formats a ProposalFinalized event.
     *
     * @param log - The log object containing the event data.
     * @param timestamp - The timestamp of the event.
     * @returns The formatted ProposalFinalized event.
     */
    private formatProposalFinalizedEvent(
        log: EboEventLog<"ProposalFinalized">,
        timestamp: UnixTimestamp,
    ): EboEventV2 {
        const decoded = decodeEventLog({
            abi: eboEventsAbi,
            eventName: log.eventName,
            data: log.data,
            topics: log.topics,
            strict: true,
        });

        return {
            ...this.getEboEventBaseFields(log, timestamp),
            name: log.eventName,
            proposalId: decoded.args._proposalId as ProposalId,
            args: {
                proposalId: decoded.args._proposalId as ProposalId,
                epoch: decoded.args._epoch,
                chainId: decoded.args._chainId as Hex,
                blockNumber: decoded.args._blockNumber,
            },
        };
    }

    /**
     * Formats a PledgedForDispute event.
     *
     * @param log - The log object containing the event data.
     * @param timestamp - The timestamp of the event.
     * @returns The formatted PledgedForDispute event.
     */
    private formatPledgedForDisputeEvent(
        log: EboEventLog<"PledgedForDispute">,
        timestamp: UnixTimestamp,
    ): EboEventV2 {
        const decoded = decodeEventLog({
            abi: eboEventsAbi,
            eventName: log.eventName,
            data: log.data,
            topics: log.topics,
            strict: true,
        });

        return {
            ...this.getEboEventBaseFields(log, timestamp),
            name: log.eventName,
            proposalId: decoded.args._proposalId as ProposalId,
            args: {
                proposalId: decoded.args._proposalId as ProposalId,
                pledger: decoded.args._pledger,
                pledgeAmount: decoded.args._pledgeAmount,
            },
        };
    }

    /**
     * Formats a PledgedAgainstDispute event.
     *
     * @param log - The log object containing the event data.
     * @param timestamp - The timestamp of the event.
     * @returns The formatted PledgedAgainstDispute event.
     */
    private formatPledgedAgainstDisputeEvent(
        log: EboEventLog<"PledgedAgainstDispute">,
        timestamp: UnixTimestamp,
    ): EboEventV2 {
        const decoded = decodeEventLog({
            abi: eboEventsAbi,
            eventName: log.eventName,
            data: log.data,
            topics: log.topics,
            strict: true,
        });

        return {
            ...this.getEboEventBaseFields(log, timestamp),
            name: log.eventName,
            proposalId: decoded.args._proposalId as ProposalId,
            args: {
                proposalId: decoded.args._proposalId as ProposalId,
                pledger: decoded.args._pledger,
                pledgeAmount: decoded.args._pledgeAmount,
            },
        };
    }

    /**
     * Formats a DisputeEscalated event.
     *
     * @param log - The log object containing the event data.
     * @param timestamp - The timestamp of the event.
     * @returns The formatted DisputeEscalated event.
     */
    private formatDisputeEscalatedEvent(
        log: EboEventLog<"DisputeEscalated">,
        timestamp: UnixTimestamp,
    ): EboEventV2 {
        const decoded = decodeEventLog({
            abi: eboEventsAbi,
            eventName: log.eventName,
            data: log.data,
            topics: log.topics,
            strict: true,
        });

        return {
            ...this.getEboEventBaseFields(log, timestamp),
            name: log.eventName,
            proposalId: decoded.args._proposalId as ProposalId,
            args: {
                proposalId: decoded.args._proposalId as ProposalId,
            },
        };
    }

    /**
     * Formats a DisputeResolved event.
     *
     * @param log - The log object containing the event data.
     * @param timestamp - The timestamp of the event.
     * @returns The formatted DisputeResolved event.
     */
    private formatDisputeResolvedEvent(
        log: EboEventLog<"DisputeResolved">,
        timestamp: UnixTimestamp,
    ): EboEventV2 {
        const decoded = decodeEventLog({
            abi: eboEventsAbi,
            eventName: log.eventName,
            data: log.data,
            topics: log.topics,
            strict: true,
        });

        return {
            ...this.getEboEventBaseFields(log, timestamp),
            name: log.eventName,
            proposalId: decoded.args._proposalId as ProposalId,
            args: {
                proposalId: decoded.args._proposalId as ProposalId,
                resolutionStatus: decoded.args._resolutionStatus,
            },
        };
    }

    /** @inheritdoc */
    async getEvents(fromBlock: bigint, toBlock: bigint): Promise<EboEventV2[]> {
        if (fromBlock > toBlock) {
            throw new InvalidBlockRangeError(fromBlock, toBlock);
        }

        // Fetch events from the EBO contract
        const events = await this.getEboEvents(fromBlock, toBlock);

        return this.mergeEventStreams(events);
    }

    /**
     * Merge multiple streams of events considering the chain order, based on their block numbers
     * and log indexes.
     *
     * @param {EboEventV2[][]} streams - A collection of EboEventV2[] arrays.
     * @returns {EboEventV2[]} The merged and sorted event array.
     */
    private mergeEventStreams(...streams: EboEventV2[][]): EboEventV2[] {
        return streams
            .reduce((acc, curr) => acc.concat(curr), [])
            .sort((a, b) => {
                if (a.blockNumber > b.blockNumber) return 1;
                if (a.blockNumber < b.blockNumber) return -1;

                if (a.logIndex > b.logIndex) return 1;
                if (a.logIndex < b.logIndex) return -1;

                return 0;
            });
    }

    /** @inheritdoc */
    async getAvailableChains(): Promise<Caip2ChainId[]> {
        try {
            // Since there's no direct method to get all allowed chain IDs, we'll use the EBO_SUPPORTED_CHAIN_IDS
            // and check each one against the chainIdsAllowed mapping
            const allowedChainIds: Caip2ChainId[] = [];
            // Check each supported chain ID against the chainIdsAllowed mapping
            if (this.l2ReadClient.chain?.contracts?.multicall3) {
                const results = await this.l2ReadClient.multicall({
                    allowFailure: false,
                    contracts: EBO_SUPPORTED_CHAIN_IDS.map(
                        (chainId) =>
                            ({
                                abi: eboAbi,
                                address: this.eboContract.address,
                                functionName: "chainIdsAllowed",
                                args: [chainId],
                            }) as const,
                    ),
                });

                // Since we use allowFailure: false, we always obtain an array of the same length as EBO_SUPPORTED_CHAIN_IDS
                for (let i = 0; i < results.length; i++) {
                    const isAllowed = results[i];
                    if (isAllowed) {
                        allowedChainIds.push(EBO_SUPPORTED_CHAIN_IDS[i]!);
                    }
                }
            } else {
                await Promise.all(
                    EBO_SUPPORTED_CHAIN_IDS.map(async (chainId) => {
                        const isAllowed = await this.eboContract.read.chainIdsAllowed([chainId]);
                        if (isAllowed) {
                            allowedChainIds.push(chainId);
                        }
                    }),
                );
            }

            return allowedChainIds;
        } catch (error) {
            throw new FetchAvailableChainsError();
        }
    }

    /** @inheritdoc */
    async getProposalById(proposalId: ProposalId): Promise<Proposal | undefined> {
        const [epoch, chainId, blockNumber, proposer, createdAt, parametersSnapshotId, status] =
            await this.eboContract.read.proposals([proposalId]);
        const proposal: Omit<Proposal, "id"> = {
            epoch,
            chainId,
            blockNumber,
            proposer,
            createdAt,
            parametersSnapshotId,
            status,
        };

        if (isEqual(proposal, NULL_PROPOSAL)) {
            return undefined;
        }

        return {
            ...proposal,
            id: proposalId,
        };
    }

    /** @inheritdoc */
    async getDisputeByProposalId(proposalId: ProposalId): Promise<DisputeV2 | undefined> {
        const [
            disputer,
            createdAt,
            lastPledgeTimestamp,
            totalPledgesForDispute,
            totalPledgesAgainstDispute,
            rewardPerWinningPledge,
        ] = await this.eboContract.read.disputes([proposalId]);
        const dispute: DisputeV2 = {
            disputer,
            createdAt,
            lastPledgeTimestamp,
            totalPledgesForDispute,
            totalPledgesAgainstDispute,
            rewardPerWinningPledge,
        };

        if (isEqual(dispute, NULL_DISPUTE)) {
            return undefined;
        }

        return dispute;
    }

    /** @inheritdoc */
    async getSnapshotParameters(
        parameterSnapshotId: bigint,
    ): Promise<SnapshotParameters | undefined> {
        const [
            proposalBondSize,
            pledgeBondSize,
            minThawingPeriod,
            disputeWindow,
            pledgeWindow,
            pledgeRefreshWindow,
            maxNumberOfPledges,
        ] = await this.eboContract.read.parametersSnapshots([parameterSnapshotId]);
        const snapshotParameters: SnapshotParameters = {
            proposalBondSize,
            pledgeBondSize,
            minThawingPeriod,
            disputeWindow,
            pledgeWindow,
            pledgeRefreshWindow,
            maxNumberOfPledges,
        };

        if (isEqual(snapshotParameters, NULL_SNAPSHOT_PARAMETERS)) {
            return undefined;
        }

        return snapshotParameters;
    }

    /** @inheritdoc */
    async getActiveProposal(epoch: bigint, chainId: Caip2ChainId): Promise<Proposal | undefined> {
        const proposalId = await this.eboContract.read.activeProposal([epoch, chainId]);
        return this.getProposalById(proposalId as ProposalId);
    }

    // ================================
    // Write methods
    // ================================

    // ================================
    // IEBOCore
    // ================================

    /**
     * Proposes a new proposal.
     *
     * @param {bigint} epoch - The epoch number.
     * @param {Caip2ChainId} chainId - The chain ID.
     * @param {bigint} blockNumber - The block number.
     * @param {Address} serviceProvider - The address of the service provider.
     * @throws {TransactionExecutionError} Throws if the transaction fails during execution.
     * @throws {ContractFunctionRevertedError} Throws if the contract function reverts.
     * @returns {Promise<void>}
     */
    async propose(
        epoch: bigint,
        chainId: Caip2ChainId,
        blockNumber: bigint,
        serviceProvider: Address,
    ): Promise<void> {
        await this.writeMutex.runExclusive(async () => {
            try {
                // Simulate the transaction first
                const { request } = await this.l2ReadClient.simulateContract({
                    address: this.eboContract.address,
                    abi: eboAbi,
                    functionName: "propose",
                    args: [epoch, chainId, blockNumber, serviceProvider],
                    account: this.l2WriteClient.account,
                });

                // Execute the transaction
                const hash = await this.l2WriteClient.writeContract(request);

                // Wait for the transaction to be confirmed
                const { transactionReceiptConfirmations } = this.rpcConfig.l2;
                const receipt = await this.l2ReadClient.waitForTransactionReceipt({
                    hash,
                    confirmations: transactionReceiptConfirmations,
                });

                if (receipt.status !== "success") {
                    throw new TransactionExecutionError(
                        `propose transaction failed for epoch ${epoch} and chain ${chainId}`,
                    );
                }

                this.logger.debug(
                    `Successfully created proposal for epoch ${epoch} and chain ${chainId}`,
                );
            } catch (error) {
                if (error instanceof BaseError) {
                    this.handleBaseError(error);
                }
                throw error;
            }
        });
    }

    /**
     * Disputes a proposal.
     *
     * @param {bigint} proposalId - The ID of the proposal.
     * @param {Address} serviceProvider - The address of the service provider.
     * @throws {TransactionExecutionError} Throws if the transaction fails during execution.
     * @throws {ContractFunctionRevertedError} Throws if the contract function reverts.
     * @returns {Promise<void>}
     */
    async dispute(proposalId: ProposalId, serviceProvider: Address): Promise<void> {
        await this.writeMutex.runExclusive(async () => {
            try {
                // Simulate the transaction first
                const { request } = await this.l2ReadClient.simulateContract({
                    address: this.eboContract.address,
                    abi: eboAbi,
                    functionName: "dispute",
                    args: [proposalId, serviceProvider],
                    account: this.l2WriteClient.account,
                });

                // Execute the transaction
                const hash = await this.l2WriteClient.writeContract(request);

                // Wait for the transaction to be confirmed
                const { transactionReceiptConfirmations } = this.rpcConfig.l2;
                const receipt = await this.l2ReadClient.waitForTransactionReceipt({
                    hash,
                    confirmations: transactionReceiptConfirmations,
                });

                if (receipt.status !== "success") {
                    throw new TransactionExecutionError(
                        `dispute transaction failed for proposal ${proposalId}`,
                    );
                }

                this.logger.debug(`Successfully disputed proposal ${proposalId}`);
            } catch (error) {
                if (error instanceof BaseError) {
                    this.handleBaseError(error);
                }
                throw error;
            }
        });
    }

    /**
     * Resolves a proposal.
     *
     * @param {bigint} proposalId - The ID of the proposal.
     * @throws {TransactionExecutionError} Throws if the transaction fails during execution.
     * @throws {ContractFunctionRevertedError} Throws if the contract function reverts.
     * @returns {Promise<void>}
     */
    async resolve(proposalId: ProposalId): Promise<void> {
        await this.writeMutex.runExclusive(async () => {
            try {
                // Simulate the transaction first
                const { request } = await this.l2ReadClient.simulateContract({
                    address: this.eboContract.address,
                    abi: eboAbi,
                    functionName: "resolve",
                    args: [proposalId],
                    account: this.l2WriteClient.account,
                });

                // Execute the transaction
                const hash = await this.l2WriteClient.writeContract(request);

                // Wait for the transaction to be confirmed
                const { transactionReceiptConfirmations } = this.rpcConfig.l2;
                const receipt = await this.l2ReadClient.waitForTransactionReceipt({
                    hash,
                    confirmations: transactionReceiptConfirmations,
                });

                if (receipt.status !== "success") {
                    throw new TransactionExecutionError(
                        `resolve transaction failed for proposal ${proposalId}`,
                    );
                }

                this.logger.debug(`Successfully resolved dispute for proposal ${proposalId}`);
            } catch (error) {
                if (error instanceof BaseError) {
                    this.handleBaseError(error);
                }
                throw error;
            }
        });
    }

    /**
     * Finalizes a proposal.
     *
     * @param {bigint} proposalId - The ID of the proposal.
     * @throws {TransactionExecutionError} Throws if the transaction fails during execution.
     * @throws {ContractFunctionRevertedError} Throws if the contract function reverts.
     * @returns {Promise<void>}
     */

    async finalize(proposalId: bigint): Promise<void> {
        await this.writeMutex.runExclusive(async () => {
            try {
                // Simulate the transaction first
                const { request } = await this.l2ReadClient.simulateContract({
                    address: this.eboContract.address,
                    abi: eboAbi,
                    functionName: "finalize",
                    args: [proposalId],
                    account: this.l2WriteClient.account,
                });

                // Execute the transaction
                const hash = await this.l2WriteClient.writeContract(request);

                // Wait for the transaction to be confirmed
                const { transactionReceiptConfirmations } = this.rpcConfig.l2;
                const receipt = await this.l2ReadClient.waitForTransactionReceipt({
                    hash,
                    confirmations: transactionReceiptConfirmations,
                });

                if (receipt.status !== "success") {
                    throw new TransactionExecutionError(
                        `finalize transaction failed for proposal ${proposalId}`,
                    );
                }

                this.logger.debug(`Successfully finalized proposal ${proposalId}`);
            } catch (error) {
                if (error instanceof BaseError) {
                    this.handleBaseError(error);
                }
                throw error;
            }
        });
    }

    // ================================
    // IEBOPledge
    // ================================

    /**
     * Pledges for a dispute.
     *
     * @param {bigint} proposalId - The ID of the proposal.
     * @param {Address} serviceProvider - The address of the service provider.
     * @throws {TransactionExecutionError} Throws if the transaction fails during execution.
     * @throws {ContractFunctionRevertedError} Throws if the contract function reverts.
     * @returns {Promise<void>}
     */
    async pledgeForDispute(proposalId: bigint, serviceProvider: Address): Promise<void> {
        await this.writeMutex.runExclusive(async () => {
            try {
                // Simulate the transaction first
                const { request } = await this.l2ReadClient.simulateContract({
                    address: this.eboContract.address,
                    abi: eboAbi,
                    functionName: "pledgeForDispute",
                    args: [proposalId, serviceProvider],
                    account: this.l2WriteClient.account,
                });

                // Execute the transaction
                const hash = await this.l2WriteClient.writeContract(request);

                // Wait for the transaction to be confirmed
                const { transactionReceiptConfirmations } = this.rpcConfig.l2;
                const receipt = await this.l2ReadClient.waitForTransactionReceipt({
                    hash,
                    confirmations: transactionReceiptConfirmations,
                });

                if (receipt.status !== "success") {
                    throw new TransactionExecutionError(
                        `pledgeForDispute transaction failed for proposal ${proposalId}`,
                    );
                }

                this.logger.debug(`Successfully pledged for dispute on proposal ${proposalId}`);
            } catch (error) {
                if (error instanceof BaseError) {
                    this.handleBaseError(error);
                }
                throw error;
            }
        });
    }

    /**
     * Pledges against a dispute.
     *
     * @param {bigint} proposalId - The ID of the proposal.
     * @param {Address} serviceProvider - The address of the service provider.
     * @throws {TransactionExecutionError} Throws if the transaction fails during execution.
     * @throws {ContractFunctionRevertedError} Throws if the contract function reverts.
     * @returns {Promise<void>}
     */
    async pledgeAgainstDispute(proposalId: bigint, serviceProvider: Address): Promise<void> {
        await this.writeMutex.runExclusive(async () => {
            try {
                // Simulate the transaction first
                const { request } = await this.l2ReadClient.simulateContract({
                    address: this.eboContract.address,
                    abi: eboAbi,
                    functionName: "pledgeAgainstDispute",
                    args: [proposalId, serviceProvider],
                    account: this.l2WriteClient.account,
                });

                // Execute the transaction
                const hash = await this.l2WriteClient.writeContract(request);

                // Wait for the transaction to be confirmed
                const { transactionReceiptConfirmations } = this.rpcConfig.l2;
                const receipt = await this.l2ReadClient.waitForTransactionReceipt({
                    hash,
                    confirmations: transactionReceiptConfirmations,
                });

                if (receipt.status !== "success") {
                    throw new TransactionExecutionError(
                        `pledgeAgainstDispute transaction failed for proposal ${proposalId}`,
                    );
                }

                this.logger.debug(`Successfully pledged against dispute on proposal ${proposalId}`);
            } catch (error) {
                if (error instanceof BaseError) {
                    this.handleBaseError(error);
                }
                throw error;
            }
        });
    }

    // ================================
    // Helpers
    // ================================

    private getViemChain(chainId: Caip2ChainId): Chain {
        switch (chainId) {
            case "eip155:1":
                return mainnet;
            case "eip155:11155111":
                return sepolia;
            case "eip155:42161":
                return arbitrum;
            case "eip155:421614":
                return arbitrumSepolia;
            default:
                throw new UnsupportedChain(chainId);
        }
    }

    private handleBaseError(error: BaseError) {
        const revertError = error.walk((err) => err instanceof ContractFunctionRevertedError);

        if (revertError instanceof ContractFunctionRevertedError) {
            const errorName = revertError.data?.errorName ?? "";

            throw ErrorFactoryV2.createError(errorName);
        }
    }
}
