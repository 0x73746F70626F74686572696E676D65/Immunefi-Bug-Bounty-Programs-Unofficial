import { ProposalId } from "../types/index.js";

export class ProposalMismatch extends Error {
    constructor(proposalId: ProposalId, eventProposalId: ProposalId) {
        super(
            `Actor handling proposal ${proposalId} received a proposal ${eventProposalId} event.`,
        );
        this.name = "ProposalMismatch";
    }
}
