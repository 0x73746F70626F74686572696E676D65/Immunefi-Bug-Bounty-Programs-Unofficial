import { IMessage, NotificationService } from "@ebo-agent/shared";

/**
 * A null implementation of NotificationService that performs no actions but allows the application to have an undefined notificationService if desired
 */
export class NullNotificationService implements NotificationService {
    async send(_message: IMessage): Promise<void> {
        // Do nothing
    }

    async sendOrThrow(_message: IMessage): Promise<void> {
        // Do nothing
    }

    createErrorMessage(_defaultMessage: string, _context?: unknown, _err?: unknown): IMessage {
        // Return a default IMessage without sending
        return {
            title: "Default Error Message",
            subtitle: _context ? JSON.stringify(_context) : undefined,
            description: _err ? (_err instanceof Error ? _err.message : String(_err)) : undefined,
        };
    }

    async sendError(
        _defaultMessage: string,
        _context?: Record<string, unknown>,
        _err?: unknown,
    ): Promise<void> {
        // Do nothing
    }
}
