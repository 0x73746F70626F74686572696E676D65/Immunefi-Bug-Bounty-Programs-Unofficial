import { Caip2ChainId } from "@ebo-agent/shared";
import { Address, Block } from "viem";

import type {
    DisputeV2,
    EboEventV2,
    Epoch,
    Proposal,
    ProposalId,
    SnapshotParameters,
} from "../types/index.js";
import { ProtocolContractsNamesV2 } from "../constants.js";

/**
 * Represents the names of protocol contracts.
 */
export type ProtocolContractV2 = (typeof ProtocolContractsNamesV2)[number];

/**
 * Maps protocol contract names to their respective addresses.
 */
export type ProtocolContractsAddressesV2 = Record<ProtocolContractV2, Address>;

/**
 * IReadProviderV2 defines the read operations that can be performed on the EBO protocol.
 */
export interface IReadProviderV2 {
    /**
     * Gets the current epoch, along with the block number and its timestamp.
     *
     * @returns A promise that resolves with the current epoch, block number, and timestamp.
     */
    getCurrentEpoch(): Promise<Epoch>;

    /**
     * Gets the last finalized block.
     *
     * @returns A promise that resolves with the last finalized block.
     */
    getLastFinalizedBlock(): Promise<Block<bigint, boolean, "finalized">>;

    /**
     * Retrieves events from the EBO contract within a specified block range.
     *
     * @param fromBlock The starting block number.
     * @param toBlock The ending block number.
     * @returns A promise that resolves with an array of EBO events.
     */
    getEvents(fromBlock: bigint, toBlock: bigint): Promise<EboEventV2[]>;

    /**
     * Gets the list of available chains that the EBO contract supports.
     *
     * @returns A promise that resolves with an array of chain IDs.
     */
    getAvailableChains(): Promise<Caip2ChainId[]>;

    /**
     * Gets a proposal by its ID from the EBO contract.
     *
     * @param proposalId The ID of the proposal.
     * @returns A promise that resolves with the proposal data.
     */
    getProposalById(proposalId: ProposalId): Promise<Proposal | undefined>;

    /**
     * Gets the dispute data for a proposal from the EBO contract.
     *
     * @param proposalId The ID of the proposal.
     * @returns A promise that resolves with the dispute data.
     */
    getDisputeByProposalId(proposalId: ProposalId): Promise<DisputeV2 | undefined>;

    /**
     * Gets the active proposal for a given epoch and chain ID.
     *
     * @param epoch The epoch number.
     * @param chainId The chain ID.
     * @returns A promise that resolves with the active proposal.
     */
    getActiveProposal(epoch: bigint, chainId: Caip2ChainId): Promise<Proposal | undefined>;

    /**
     * Gets the snapshot parameters for a given parameter snapshot ID.
     *
     * @param parameterSnapshotId The ID of the parameter snapshot.
     * @returns A promise that resolves with the snapshot parameters.
     */
    getSnapshotParameters(parameterSnapshotId: bigint): Promise<SnapshotParameters | undefined>;
}

/**
 * IWriteProviderV2 defines the write operations that can be performed on the EBO protocol.
 */
export interface IWriteProviderV2 {
    /**
     * Creates a new proposal.
     *
     * @param epoch The epoch of the proposal.
     * @param chainId The chain ID of the proposal.
     * @param blockNumber The block number of the proposal.
     * @param serviceProvider The address of the service provider.
     * @returns A promise that resolves when the proposal is created.
     */
    propose(
        epoch: bigint,
        chainId: Caip2ChainId,
        blockNumber: bigint,
        serviceProvider: Address,
    ): Promise<void>;

    /**
     * Disputes a proposal.
     *
     * @param proposalId The ID of the proposal.
     * @param serviceProvider The address of the service provider.
     * @returns A promise that resolves when the proposal is disputed.
     */
    dispute(proposalId: ProposalId, serviceProvider: Address): Promise<void>;

    /**
     * Resolves a non-escalated dispute.
     *
     * @param proposalId The ID of the proposal.
     * @returns A promise that resolves when the dispute is resolved.
     */
    resolve(proposalId: ProposalId): Promise<void>;

    /**
     * Finalizes a proposal.
     *
     * @param proposalId The ID of the proposal.
     * @returns A promise that resolves when the proposal is finalized.
     */
    finalize(proposalId: ProposalId): Promise<void>;

    /**
     * Pledges in favor of a dispute.
     *
     * @param proposalId The ID of the proposal.
     * @param serviceProvider The address of the service provider.
     * @returns A promise that resolves when the pledge is made.
     */
    pledgeForDispute(proposalId: ProposalId, serviceProvider: Address): Promise<void>;

    /**
     * Pledges against a dispute.
     *
     * @param proposalId The ID of the proposal.
     * @param serviceProvider The address of the service provider.
     * @returns A promise that resolves when the pledge is made.
     */
    pledgeAgainstDispute(proposalId: ProposalId, serviceProvider: Address): Promise<void>;
}

/**
 * IProtocolProviderV2 defines the interface for a protocol provider that includes both read and write operations.
 */
export interface IProtocolProviderV2 {
    /**
     * The write operations available on the protocol.
     */
    write: IWriteProviderV2;

    /**
     * The read operations available on the protocol.
     */
    read: IReadProviderV2;

    /**
     * Returns the address of the account used for transactions.
     *
     * @returns {Address} The account address.
     */
    getAccountAddress(): Address;
}
