import { BlockNumberService } from "@ebo-agent/blocknumber";
import { Caip2ChainId, ILogger, UnixTimestamp } from "@ebo-agent/shared";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { DisputeEscalatedHandler } from "../../../src/services/eventHandlers/disputeEscalated.handler.js";
import { EboEventV2, ProposalId } from "../../../src/types/index.js";
import mocks from "../../mocks/index.js";

describe("DisputeEscalatedHandler", () => {
    let handler: DisputeEscalatedHandler;
    let logger: ILogger;
    let protocolProvider: any;
    let blockNumberService: BlockNumberService;
    let actorProposal: any;

    beforeEach(() => {
        logger = mocks.mockLogger();

        protocolProvider = {
            getAccountAddress: vi.fn().mockReturnValue("0xuser"),
        };

        blockNumberService = {} as BlockNumberService;

        actorProposal = {
            id: 1n as ProposalId,
            chainId: "eip155:1" as Caip2ChainId,
            proposal: {
                createdAt: 1000n as UnixTimestamp,
            },
            parameters: {
                disputeWindow: 3600n,
            },
            epoch: 1n,
        };

        handler = new DisputeEscalatedHandler({
            actorProposal,
            protocolProvider,
            blockNumberService,
            logger,
        });
    });

    it("logs when a dispute is escalated", async () => {
        const proposalId = 1n as ProposalId;
        const event: EboEventV2 & { name: "DisputeEscalated" } = {
            name: "DisputeEscalated",
            blockNumber: 123456n,
            logIndex: 0,
            timestamp: 1000n as UnixTimestamp,
            proposalId,
            args: {
                proposalId,
            },
        };

        await handler.run(event);

        expect(logger.info).toHaveBeenCalledWith(
            `Proposal ${event.args.proposalId} dispute has been escalated.`,
            { proposalId: event.args.proposalId },
        );
    });
});
