import { ILogger } from "@ebo-agent/shared";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import type { SnapshotParameters } from "../../src/types/index.js";
import { ProtocolProviderV2 } from "../../src/providers/index.js";
import { EboParametersRegistry } from "../../src/services/index.js";
import { mockLogger } from "../mocks/logger.mocks.js";

describe("EboParametersRegistry", () => {
    let protocolProvider: ProtocolProviderV2;
    let logger: ILogger;
    let registry: EboParametersRegistry;
    const mockParameters: SnapshotParameters = {
        proposalBondSize: 1000n,
        pledgeBondSize: 500n,
        minThawingPeriod: 100n,
        disputeWindow: 200n,
        pledgeWindow: 300n,
        pledgeRefreshWindow: 400n,
        maxNumberOfPledges: 10n,
    };

    beforeEach(() => {
        protocolProvider = {
            getSnapshotParameters: vi.fn(),
        } as unknown as ProtocolProviderV2;
        logger = mockLogger();
        registry = new EboParametersRegistry(protocolProvider, logger);
    });

    afterEach(() => {
        vi.clearAllMocks();
    });

    it("gets parameters from cache if available", async () => {
        const snapshotId = 1n;
        registry.setParameters(snapshotId, mockParameters);

        const result = await registry.getParameters(snapshotId);
        expect(result).toEqual(mockParameters);
        expect(protocolProvider.getSnapshotParameters).not.toHaveBeenCalled();
    });

    it("fetches parameters from provider if not in cache", async () => {
        const snapshotId = 1n;
        vi.mocked(protocolProvider.getSnapshotParameters).mockResolvedValue(mockParameters);

        const result = await registry.getParameters(snapshotId);
        expect(result).toEqual(mockParameters);
        expect(protocolProvider.getSnapshotParameters).toHaveBeenCalledWith(snapshotId);
    });

    it("returns undefined if provider returns undefined", async () => {
        const snapshotId = 1n;
        vi.mocked(protocolProvider.getSnapshotParameters).mockResolvedValue(undefined);
        const cacheSetSpy = vi.spyOn(registry["parameters"], "set");

        const result = await registry.getParameters(snapshotId);
        expect(result).toBeUndefined();
        expect(cacheSetSpy).not.toHaveBeenCalled();
    });

    it("throws if provider fetch fails", async () => {
        const snapshotId = 1n;
        vi.mocked(protocolProvider.getSnapshotParameters).mockRejectedValue(
            new Error("fetch failed"),
        );

        await expect(registry.getParameters(snapshotId)).rejects.toThrow();
        expect(logger.error).toHaveBeenCalledWith(
            "Failed to fetch parameters for snapshot ID 1: fetch failed",
        );
    });

    it("clears all cached parameters", async () => {
        const snapshotId = 1n;
        registry.setParameters(snapshotId, mockParameters);
        registry.clear();

        const result = await registry.getParameters(snapshotId);

        expect(protocolProvider.getSnapshotParameters).toHaveBeenCalled();
        expect(result).toBeUndefined();
        expect(registry["parameters"].size).toBe(0);
    });
});
