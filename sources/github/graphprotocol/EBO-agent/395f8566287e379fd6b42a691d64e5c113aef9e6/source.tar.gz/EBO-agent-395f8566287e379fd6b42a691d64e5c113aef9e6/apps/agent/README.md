# Agent Monorepo

The `agent` package is designed as a service that drives the EBO agent's main workflow. It initializes the relevant
services in the `packages` directory that are necessary to run the agent, like `BlockNumberService` and `ProtocolProvider`.
The agent interacts with the EBO smart contracts deployed on the chains specified in the `config.yml` file
that you'll create during this setup process.

## Setup

To set up the EBO agent, follow these steps:

1. **Install Dependencies**: Ensure you have `pnpm` installed, and run:

```bash
pnpm install
```

2. **Configure Environment Variables**:

You can configure environment variables in one of two ways:

-   **Using a `.env` file**: Create a `.env` file in the root of the `agent` package. Refer to `.env.example` for the required environment variables, and copy it to `.env`:

```bash
cp .env.example .env
```

-   **Setting environment variables directly**: Alternatively, you may set the environment variables directly in your shell or deployment environment without using a `.env` file.

**Environment Variables**:

| Variable                        | Description                                                                                                                                                       | Required |
| ------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------- |
| `PROTOCOL_PROVIDER_PRIVATE_KEY` | Private key for the Protocol Provider                                                                                                                             | Yes      |
| `PROTOCOL_PROVIDER_L1_RPC_URLS` | Comma-separated URLs for Layer 1 RPC endpoints                                                                                                                    | Yes      |
| `PROTOCOL_PROVIDER_L2_RPC_URLS` | Comma-separated URLs for Layer 2 RPC endpoints                                                                                                                    | Yes      |
| `BLOCK_NUMBER_RPC_URLS_MAP`     | JSON map of chain IDs to arrays of RPC URLs for Block Number calculations                                                                                         | Yes      |
| `BLOCK_NUMBER_BLOCKMETA_TOKEN`  | Bearer token for the Blockmeta service (see notes below on how to obtain)                                                                                         | Yes      |
| `EBO_AGENT_CONFIG_FILE_PATH`    | Path to the agent YAML configuration file                                                                                                                         | Yes      |
| `DISCORD_WEBHOOK`               | Your Discord channel webhook for notifications [Learn how to create a Discord webhook](https://support.discord.com/hc/en-us/articles/228383668-Intro-to-Webhooks) | No       |

**Notes:**

-   For information on generating the `BLOCK_NUMBER_BLOCKMETA_TOKEN`, refer to [Substreams Authentication Documentation](https://docs.substreams.dev/documentation/consume/authentication) for guidance on obtaining and using an authentication token.
-   To explore the available Substreams providers and URLs, check out [The Graph’s Marketplace](https://thegraph.market/), which lists supported substreams.

3. **Configuration File**:

-   The agent requires a YAML configuration file. The path to this file must be specified in the `.env` file via `EBO_AGENT_CONFIG_FILE_PATH`.
-   To set up the configuration, copy `config.example.yml` to `config.yml`:

```bash
cp config.example.yml config.yml
```

-   Update the `config.yml` file with your specific settings. Comments have been added in `config.example.yml` to explain each property.

## Available Scripts

Here are the scripts you can run using `pnpm`:

| Script        | Description                                    |
| ------------- | ---------------------------------------------- |
| `build`       | Build the agent                                |
| `check-types` | Check for type issues using TypeScript         |
| `clean`       | Remove `dist` folder                           |
| `format`      | Check code formatting using Prettier           |
| `format:fix`  | Automatically fix code formatting issues       |
| `lint`        | Run ESLint to check for code quality and style |
| `lint:fix`    | Automatically fix ESLint errors                |
| `start`       | Start the EBO Agent                            |
| `test`        | Run tests using Vitest                         |
| `test:cov`    | Run tests with a coverage report               |
| `test:e2e`    | Run e2e tests                                  |

### Running the Agent

To start the EBO Agent, run:

```bash
pnpm run start
```

## Running Tests

The `agent` package includes a suite of Vitest and end-to-end (e2e) tests to verify the correct functioning of the agent's processes. To run the Vitest tests, execute:

```bash
pnpm run test
```

For a coverage report, run:

```bash
pnpm run test:cov
```

### End-to-End Testing

The e2e tests simulate scenarios starting at the contract level and extending to the agent, like creating proposals and handling disputes. See more in depth explanation in [E2E.md](./E2E.md). For detailed test scenarios, refer to the files in [test/e2e/scenarios](./test/e2e/scenarios).

Pre-requisites:

-   [Foundry](https://book.getfoundry.sh/getting-started/installation)
-   Local clone of EBO contract's repository

To run e2e tests:

```bash
pnpm run test:e2e
```

Note: it can be a bit resource intensive since it creates one Anvil instance per scenario
