# End-to-End (E2E) Testing Framework

## Overview

This document describes the E2E testing infrastructure for the EBO agent. The framework creates isolated blockchain environments that enable comprehensive testing against a local Anvil instance, treating the EBO-agent as a black-box.

## Architecture

The E2E testing framework is built around the following components:

-   **Anvil**: Local Ethereum node that simulates a blockchain environment
-   **Fork-based testing**: Each test environment forks from a specific block on Arbitrum Sepolia
-   **Isolated environments and parallelism**: Each test suite (ie. each test file) runs in its own Anvil instance with a dedicated port
-   **State management**: Blockchain state snapshots enable test isolation within the same file tests

## What Happens During Setup

When the test environment initializes:

1. **Environment Creation**

    - An Anvil server starts with a fork of Arbitrum Sepolia at a specified block
    - A client is configured to connect to this local instance

2. **State Initialization**

    - Test accounts are created
    - Each account receives predetermined amounts of ETH and GRT
    - Specifically, 5 accounts are created by default:
        - 2 accounts have their GRT staked and provisioned for the EBO contract.
        - 3 accounts retain their GRT in their balance (not staked).
    - EBO Protocol contracts are deployed to the local environment from the EBO repository (NEEDS TO BE CLONED LOCALLY)
    - An initial state snapshot is created (by default into `e2e-state.json` file)

3. **Environment Validation**
    - Contract deployments are verified
    - Account balances are confirmed
    - Key addresses are checked for proper funding

## Creating a New E2E Test

To create a new E2E test:

1. **Create a new directory** in the scenarios folder
2. **Define your test file** with the `.e2e-spec.ts` extension
3. **Initialize the test environment** in the `beforeAll` hook
4. **Clean up resources** in the `afterAll` hook
5. **Reset state** in the `afterEach` hook
6. **Write test cases** that interact with the blockchain

## Writing E2E Tests

E2E tests typically follow this pattern:

```typescript
import { setupAnvilTestEnvironment } from "../../utils/e2e-scaffold/index.js";

describe("My E2E Test", () => {
    let testEnv: AnvilTestEnvironment;

    beforeAll(async () => {
        testEnv = await setupAnvilTestEnvironment(__dirname);
    }, E2E_SCENARIO_SETUP_TIMEOUT);

    afterAll(async () => {
        await testEnv.cleanup();
    });

    afterEach(async () => {
        await testEnv.anvilClient.revert({ id: testEnv.snapshotId });
    });

    it("should perform an action", async () => {
        // Test interactions with contracts/agent
    });
});
```

## Best Practices

-   **Always clean up**: Use `afterAll` to call `testEnv.cleanup()` to stop Anvil servers
-   **Reset state between tests within a same file**: Call `anvilClient.revert({ id: snapshotId })` in `afterEach`
-   **Verify interactions**: Confirm contract state changes after operations
-   **Timeout Management**: Set appropriate timeouts for setup operations

## Troubleshooting

Common issues include:

-   Port conflicts (resolved by dynamic port allocation)
-   Network timeouts during forking
-   Contract deployment failures
-   Transaction simulation errors

When encountering issues, check the Anvil logs and ensure the source network is accessible.
