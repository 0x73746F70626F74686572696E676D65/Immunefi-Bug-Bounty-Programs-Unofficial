import { existsSync } from "fs";

import { DEFAULT_PROTOCOL_L2_LOCAL_RPC_PORT, dumpInitialState, env } from "./index.js";

/**
 * Number of accounts to create in the global setup
 * This should be sufficient for most test scenarios
 */
const GLOBAL_SETUP_ACCOUNTS = 5;

/**
 * Global setup function for Vitest
 * This will be called once before any test runs
 * It ensures the state file exists for later test use
 */
export async function setup() {
    // Only run dumpInitialState if the state file doesn't exist
    if (!existsSync(env.STATE_FILE_PATH)) {
        console.log(
            `Global Setup: State file ${env.STATE_FILE_PATH} not found. Creating initial state...`,
        );
        await dumpInitialState(env, GLOBAL_SETUP_ACCOUNTS, DEFAULT_PROTOCOL_L2_LOCAL_RPC_PORT);
        console.log(`Global Setup: State file created at ${env.STATE_FILE_PATH}`);
    } else {
        console.log(`Global Setup: Using existing state file at ${env.STATE_FILE_PATH}`);
    }
}

export async function teardown() {
    // No teardown needed - state file persists between test runs
    console.log("Global Setup: Teardown complete");
}

export default setup;
