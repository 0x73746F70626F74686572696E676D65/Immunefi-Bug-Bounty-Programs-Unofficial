import path from "path";
import { config } from "dotenv";
import { configDefaults, defineConfig } from "vitest/config";

config({ path: ".env.e2e" });

export default defineConfig({
    test: {
        globals: true, // Use Vitest's global API without importing it in each file
        environment: "node", // Use the Node.js environment
        include: ["test/**/*.e2e-spec.ts"], // Include test files
        exclude: ["node_modules", "dist"], // Exclude certain directories
        coverage: {
            provider: "v8",
            reporter: ["text", "json", "html"], // Coverage reporters
            exclude: ["node_modules", "dist", "src/index.ts", ...configDefaults.exclude], // Files to exclude from coverage
        },
        env: process.env,
        globalSetup: ["./test/e2e/utils/e2e-scaffold/globalSetup.ts"],
    },
    resolve: {
        alias: {
            // Setup path alias based on tsconfig paths
            "@": path.resolve(__dirname, "src"),
        },
    },
});
