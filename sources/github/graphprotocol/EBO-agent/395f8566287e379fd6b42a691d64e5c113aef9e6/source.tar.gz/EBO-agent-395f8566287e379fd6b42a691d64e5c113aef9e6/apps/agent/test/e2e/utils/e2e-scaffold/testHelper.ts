import { mkdirSync, rmSync } from "fs";
import net from "net";
import path from "path";
import { CreateServerReturnType } from "prool";
import { Account, Hex, Quantity, WalletClient } from "viem";

import {
    AnvilClientType,
    createAnvilServer,
    createViemAnvilClient,
    DeployContractsOutput,
    env,
    FORK_L2_BLOCK_NUMBER,
    FORK_L2_URL,
    getProtocolL2LocalUrl,
    GRT_HOLDER,
    loadInitialState,
    PROTOCOL_L2_CHAIN,
    PROTOCOL_L2_LOCAL_RPC_HOST,
} from "./index.js";

const MIN_PORT = 10000;
const MAX_PORT = 65535;
const MAX_RETRIES = 10;

/**
 * Check if a port is available
 * @param port - Port number to check
 * @returns Promise that resolves to true if port is available, false otherwise
 */
async function isPortAvailable(port: number): Promise<boolean> {
    return new Promise((resolve) => {
        const server = net.createServer();
        server.once("error", () => {
            resolve(false);
        });
        server.once("listening", () => {
            server.close();
            resolve(true);
        });
        server.listen(port);
    });
}

/**
 * Get a random available port number in a safe range
 * @returns Promise that resolves to an available port number between MIN_PORT and MAX_PORT
 * @throws Error if no available port found after MAX_RETRIES attempts
 */
export async function getUniquePort(): Promise<number> {
    for (let i = 0; i < MAX_RETRIES; i++) {
        const port = Math.floor(Math.random() * (MAX_PORT - MIN_PORT + 1)) + MIN_PORT;
        if (await isPortAvailable(port)) {
            return port;
        }
    }
    throw new Error(`No available port found after ${MAX_RETRIES} attempts`);
}

/**
 * Setup an Anvil test environment with automatic state management
 * @param testDir - The test directory (usually __dirname)
 * @param port - Optional port number (defaults to a unique port)
 * @param stateFilePath - Optional custom state file path (defaults to env.STATE_FILE_PATH)
 * @returns An object with the Anvil server, client, contracts, accounts and snapshot ID
 */
export async function setupAnvilTestEnvironment(
    testDir: string,
    port?: number,
    stateFilePath?: string,
) {
    // Create a unique port if not provided
    const testPort = port ?? (await getUniquePort());
    const testLocalUrl = getProtocolL2LocalUrl(testPort);

    // Create temp dir if needed
    const tmpConfigDir = path.join(testDir, "/tmp");
    mkdirSync(tmpConfigDir, { recursive: true });

    // Start Anvil server
    const l2ProtocolAnvil = await createAnvilServer(PROTOCOL_L2_LOCAL_RPC_HOST, testPort, {
        forkUrl: FORK_L2_URL,
        forkBlockNumber: FORK_L2_BLOCK_NUMBER,
        slotsInAnEpoch: 1,
        blockTime: 0.25,
    });

    // Create Anvil client
    const anvilClient = createViemAnvilClient(GRT_HOLDER, PROTOCOL_L2_CHAIN, testLocalUrl);

    // Load state (created by globalSetup)
    const state = await loadInitialState(
        stateFilePath || env.STATE_FILE_PATH,
        anvilClient,
        testPort,
    );

    // Advance blockchain time to current timestamp
    const currentTimestamp = Math.floor(Date.now() / 1000);
    await anvilClient.setNextBlockTimestamp({ timestamp: BigInt(currentTimestamp) });
    await anvilClient.mine({ blocks: 1 });

    // Take a snapshot to reset between tests
    const snapshotId = await anvilClient.snapshot();

    return {
        port: testPort,
        localUrl: testLocalUrl,
        anvilServer: l2ProtocolAnvil,
        anvilClient,
        protocolContracts: state.protocolContracts,
        withStakeAccounts: state.withStakeAccounts,
        withoutStakeAccounts: state.withoutStakeAccounts,
        snapshotId,
        tmpConfigDir,

        /**
         * Clean up the Anvil server and temp directory
         */
        cleanup: async () => {
            await l2ProtocolAnvil.stop();
            rmSync(tmpConfigDir, { recursive: true, force: true });
        },
    };
}

/**
 * Helper type for the return value of setupAnvilTestEnvironment
 */
export type AnvilTestEnvironment = {
    port: number;
    localUrl: string;
    anvilServer: CreateServerReturnType;
    anvilClient: AnvilClientType;
    protocolContracts: DeployContractsOutput;
    withStakeAccounts: { privateKey: Hex; account: Account; walletClient: WalletClient }[];
    withoutStakeAccounts: { privateKey: Hex; account: Account; walletClient: WalletClient }[];
    snapshotId: Quantity;
    tmpConfigDir: string;
    cleanup: () => Promise<void>;
};
