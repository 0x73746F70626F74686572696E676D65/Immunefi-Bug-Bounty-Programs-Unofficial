import { keccak256, stringToBytes } from "viem";
import { arbitrumSepolia } from "viem/chains";

export const E2E_SCENARIO_SETUP_TIMEOUT = 120_000;
export const E2E_TEST_TIMEOUT = 120_000;

// Arbitrum Sepolia
export const GRT_HOLDER = "0xadE6B8EB69a49B56929C1d4F4b428d791861dB6f";

export const EPOCH_MANAGER_GOVERNOR_ADDRESS = "0xad834c286A9B590F8264C8D9574fAfCbbBe90b3B";

export const BASE_ETH_AMOUNT = 100n;
export const BASE_GRT_AMOUNT = 100_000n;

export const EPOCH_LENGTH = 100_000n;

// Arbitrum
// const GRT_HOLDER = "0x00669A4CF01450B64E8A2A20E9b1FCB71E61eF03";

export const ARBITRUM_SEPOLIA_ID = "eip155:421614";
export const ARBITRUM_SEPOLIA_ID_HASH = keccak256(stringToBytes(ARBITRUM_SEPOLIA_ID));

export const PROTOCOL_L2_CHAIN = arbitrumSepolia;
export const PROTOCOL_L2_CHAIN_ID = ARBITRUM_SEPOLIA_ID;

export const PROTOCOL_L2_LOCAL_RPC_HOST = "127.0.0.1";
// Default port, but can be overridden
export const DEFAULT_PROTOCOL_L2_LOCAL_RPC_PORT = 8545;

export const FORK_L2_URL = "https://arbitrum-sepolia.gateway.tenderly.co";
export const FORK_L2_BLOCK_NUMBER = 129675425;

// Function to get the protocol L2 local URL with configurable port
export function getProtocolL2LocalUrl(port = DEFAULT_PROTOCOL_L2_LOCAL_RPC_PORT): string {
    return `http://${PROTOCOL_L2_LOCAL_RPC_HOST}:${port}/1`;
}

// For backward compatibility
export const PROTOCOL_L2_LOCAL_URL = getProtocolL2LocalUrl(DEFAULT_PROTOCOL_L2_LOCAL_RPC_PORT);
