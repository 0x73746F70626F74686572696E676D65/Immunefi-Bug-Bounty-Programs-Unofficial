import { ChildProcessWithoutNullStreams } from "child_process";
import { existsSync } from "fs";
import path from "path";
import {
    eboAbi,
    NotificationServiceFactory,
    ProposalId,
    ProposalStatus,
    ProtocolProviderV2,
} from "@ebo-agent/automated-dispute";
import { BlockNumberService } from "@ebo-agent/blocknumber";
import { Caip2ChainId, Logger, NotificationService } from "@ebo-agent/shared";
import { Address, getAbiItem } from "viem";
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

import {
    AnvilTestEnvironment,
    ARBITRUM_SEPOLIA_ID_HASH,
    E2E_SCENARIO_SETUP_TIMEOUT,
    E2E_TEST_TIMEOUT,
    killAgent,
    PROTOCOL_L2_CHAIN_ID,
    setupAnvilTestEnvironment,
    spawnAgent,
    waitForEvent,
} from "../../utils/e2e-scaffold/index.js";

interface RpcConfig {
    chainId: Caip2ChainId;
    urls: string[];
    transactionReceiptConfirmations: number;
    timeout: number;
    retryInterval: number;
}

describe.sequential("escalate dispute and resolve with NoResolution", () => {
    const tmpConfigDir = path.join(__dirname, "/tmp");
    const tmpConfigFile = path.join(tmpConfigDir, "/config.yml");

    let agent: ChildProcessWithoutNullStreams | undefined;
    let testEnv: AnvilTestEnvironment;

    let protocolProvider: ProtocolProviderV2; // Agent's provider
    let adversarialProvider: ProtocolProviderV2; // Adversarial actor's provider
    let blockNumberService: BlockNumberService;

    const notifier: NotificationService = NotificationServiceFactory.create(Logger.getInstance());
    const logger = Logger.getInstance();

    let baseProviderConfig: {
        l1: RpcConfig;
        l2: RpcConfig;
    };

    let contractAddresses: {
        epochManager: Address;
        ebo: Address;
    };
    beforeAll(async () => {
        testEnv = await setupAnvilTestEnvironment(__dirname);
    }, E2E_SCENARIO_SETUP_TIMEOUT);

    afterAll(async () => {
        await testEnv.cleanup();
    });

    beforeEach(async () => {
        blockNumberService = new BlockNumberService(
            new Map<Caip2ChainId, string[]>([[PROTOCOL_L2_CHAIN_ID, [testEnv.localUrl]]]),
            {
                baseUrl: new URL("http://not.needed/"),
                bearerToken: "not.needed",
                bearerTokenExpirationWindow: 1000,
                servicePaths: {
                    block: "/block",
                    blockByTime: "/blockByTime",
                },
            },
            logger,
            notifier,
        );

        baseProviderConfig = {
            l1: {
                chainId: PROTOCOL_L2_CHAIN_ID as Caip2ChainId,
                urls: [testEnv.localUrl],
                transactionReceiptConfirmations: 1,
                timeout: 1_000,
                retryInterval: 500,
            },
            l2: {
                chainId: PROTOCOL_L2_CHAIN_ID as Caip2ChainId,
                urls: [testEnv.localUrl],
                transactionReceiptConfirmations: 1,
                timeout: 1_000,
                retryInterval: 500,
            },
        };

        contractAddresses = {
            epochManager: testEnv.protocolContracts.epochManager,
            ebo: testEnv.protocolContracts.eboProxy,
        };
    });

    afterEach(async () => {
        await testEnv.anvilClient.revert({ id: testEnv.snapshotId });

        if (existsSync(tmpConfigFile) && agent) {
            await killAgent({
                process: agent,
                configPath: tmpConfigFile,
            });
            agent = undefined; // Reset agent variable
        }
    });

    it(
        "agent creates proposal, adversary disputes, pledges are exchanged until escalation, dispute resolved with NoResolution",
        { timeout: E2E_TEST_TIMEOUT },
        async () => {
            const { anvilClient, protocolContracts, withStakeAccounts, withoutStakeAccounts } =
                testEnv;

            const agentAccount = withStakeAccounts[0];
            const adversarialAccount = withStakeAccounts[1];
            const e2eAccount = withoutStakeAccounts[0];

            // Check if accounts and keys exist
            if (
                !withStakeAccounts ||
                withStakeAccounts.length < 2 ||
                !agentAccount?.privateKey ||
                !adversarialAccount?.privateKey ||
                !e2eAccount?.privateKey
            ) {
                throw new Error("Required test accounts not found or missing private keys.");
            }

            // Provider for the agent
            protocolProvider = new ProtocolProviderV2(
                baseProviderConfig,
                contractAddresses,
                agentAccount.privateKey,
                logger,
                blockNumberService,
            );

            // Provider for the adversarial actor
            adversarialProvider = new ProtocolProviderV2(
                baseProviderConfig,
                contractAddresses,
                adversarialAccount.privateKey,
                logger,
                blockNumberService,
            );

            const initBlock = await anvilClient.getBlockNumber();
            const currentEpoch = await protocolProvider.read.getCurrentEpoch();
            const correctBlockNumber = await blockNumberService.getEpochBlockNumber(
                currentEpoch.startTimestamp,
                PROTOCOL_L2_CHAIN_ID,
            );

            // Spawn the agent first
            agent = spawnAgent({
                configPath: tmpConfigFile,
                config: {
                    protocolProvider: {
                        contracts: {
                            ebo: protocolContracts.eboProxy,
                            epochManager: protocolContracts.epochManager,
                        },
                        rpcsConfig: {
                            l1: {
                                chainId: PROTOCOL_L2_CHAIN_ID,
                                transactionReceiptConfirmations: 1,
                                timeout: 1_000,
                                retryInterval: 500,
                            },
                            l2: {
                                chainId: PROTOCOL_L2_CHAIN_ID,
                                transactionReceiptConfirmations: 1,
                                timeout: 1_000,
                                retryInterval: 500,
                            },
                        },
                    },
                    blockNumberService: {
                        blockmetaConfig: {
                            baseUrl: new URL("http://not.needed/"),
                            bearerTokenExpirationWindow: 1000,
                            servicePaths: {
                                block: "/block",
                                blockByTime: "/blockByTime",
                            },
                        },
                    },
                    processor: {
                        // Check frequently to react quickly in the test
                        msBetweenChecks: 2000,
                    },
                },
                env: {
                    PROTOCOL_PROVIDER_PRIVATE_KEY: agentAccount.privateKey,
                    PROTOCOL_PROVIDER_L1_RPC_URLS: [testEnv.localUrl],
                    PROTOCOL_PROVIDER_L2_RPC_URLS: [testEnv.localUrl],
                    BLOCK_NUMBER_BLOCKMETA_TOKEN: "not.needed",
                    BLOCK_NUMBER_RPC_URLS_MAP: new Map<Caip2ChainId, string[]>([
                        [PROTOCOL_L2_CHAIN_ID, [testEnv.localUrl]],
                    ]),
                },
            });

            let agentOutput = "";
            agent.stdout.on("data", (data) => {
                agentOutput += data.toString();
            });

            // 1. Wait for the agent to create the initial proposal
            const proposalCreatedEvent = await waitForEvent({
                client: anvilClient,
                filter: {
                    address: protocolContracts.eboProxy,
                    fromBlock: initBlock,
                    event: getAbiItem({ abi: eboAbi, name: "ProposalCreated" }),
                    strict: true,
                },
                matcher: (log) => {
                    return (
                        log.args._serviceProvider === agentAccount.account.address &&
                        log.args._epoch === currentEpoch.number &&
                        log.args._chainId === ARBITRUM_SEPOLIA_ID_HASH &&
                        log.args._blockNumber === correctBlockNumber
                    );
                },
                pollingIntervalMs: 100,
                blockTimeout: initBlock + 1000n,
            });

            expect(proposalCreatedEvent).toBeDefined();
            const proposalId = proposalCreatedEvent.args._proposalId as ProposalId;
            const proposal = await protocolProvider.read.getProposalById(proposalId);
            expect(proposal).toBeDefined();
            const parameters = await protocolProvider.read.getSnapshotParameters(
                proposal!.parametersSnapshotId,
            );
            expect(parameters).toBeDefined();
            const maxPledges = Number(parameters!.maxNumberOfPledges);

            // 2. Adversary disputes the agent's proposal and pledges 'for' the dispute
            await adversarialProvider.write.dispute(proposalId, adversarialAccount.account.address);
            await adversarialProvider.write.pledgeForDispute(
                proposalId,
                adversarialAccount.account.address,
            );
            await anvilClient.mine({ blocks: 5 });

            let lastAgentPledgeAgainstEvent = undefined;
            let lastAdversaryPledgeForEvent = undefined;
            let fromBlockPledgeFor = proposalCreatedEvent.blockNumber + 1n;
            let dispute = await adversarialProvider.read.getDisputeByProposalId(proposalId);

            let pledgesForCount = Number(dispute!.totalPledgesForDispute);
            let pledgesAgainstCount = Number(dispute!.totalPledgesAgainstDispute);

            // 3. Pledge for and against the dispute back and forth until max pledges are reached
            while (pledgesForCount < maxPledges || pledgesAgainstCount < maxPledges) {
                lastAdversaryPledgeForEvent = await waitForEvent({
                    client: anvilClient,
                    filter: {
                        address: protocolContracts.eboProxy,
                        fromBlock: fromBlockPledgeFor,
                        event: getAbiItem({ abi: eboAbi, name: "PledgedForDispute" }),
                        strict: true,
                    },
                    matcher: (log) =>
                        log.args._proposalId === proposalId &&
                        log.args._pledger === adversarialAccount.account.address,
                    pollingIntervalMs: 100,
                    blockTimeout: proposalCreatedEvent.blockNumber + 1000n,
                });
                expect(lastAdversaryPledgeForEvent).toBeDefined();

                lastAgentPledgeAgainstEvent = await waitForEvent({
                    client: anvilClient,
                    filter: {
                        address: protocolContracts.eboProxy,
                        fromBlock: lastAdversaryPledgeForEvent.blockNumber + 1n,
                        event: getAbiItem({
                            abi: eboAbi,
                            name: "PledgedAgainstDispute",
                        }),
                        strict: true,
                    },
                    matcher: (log) =>
                        log.args._proposalId === proposalId &&
                        log.args._pledger === agentAccount.account.address,
                    pollingIntervalMs: 100,
                    blockTimeout: proposalCreatedEvent.blockNumber + 1000n,
                });
                expect(lastAgentPledgeAgainstEvent).toBeDefined();
                dispute = await adversarialProvider.read.getDisputeByProposalId(proposalId);
                pledgesForCount = Number(dispute!.totalPledgesForDispute);
                pledgesAgainstCount = Number(dispute!.totalPledgesAgainstDispute);
                fromBlockPledgeFor = lastAgentPledgeAgainstEvent.blockNumber;

                await anvilClient.mine({ blocks: 1 });

                if (pledgesForCount == maxPledges && pledgesAgainstCount == maxPledges) {
                    break;
                }

                try {
                    await adversarialProvider.write.pledgeForDispute(
                        proposalId,
                        adversarialAccount.account.address,
                    );
                } catch (error) {
                    console.log("error", JSON.stringify(error, null, 2));
                    throw error;
                }
                dispute = await adversarialProvider.read.getDisputeByProposalId(proposalId);
                pledgesForCount = Number(dispute!.totalPledgesForDispute);
                pledgesAgainstCount = Number(dispute!.totalPledgesAgainstDispute);
            }

            expect(pledgesForCount).toEqual(maxPledges);
            expect(pledgesAgainstCount).toEqual(maxPledges);

            // 4. Wait for DisputeEscalated event
            const lastPledgeEvent =
                lastAdversaryPledgeForEvent!.blockNumber > lastAgentPledgeAgainstEvent!.blockNumber
                    ? lastAdversaryPledgeForEvent!
                    : lastAgentPledgeAgainstEvent!;

            const disputeEscalatedEvent = await waitForEvent({
                client: anvilClient,
                filter: {
                    address: protocolContracts.eboProxy,
                    fromBlock: lastPledgeEvent.blockNumber,
                    event: getAbiItem({ abi: eboAbi, name: "DisputeEscalated" }),
                    strict: true,
                },
                matcher: (log) => log.args._proposalId === proposalId,
                pollingIntervalMs: 100,
                blockTimeout: lastPledgeEvent.blockNumber + 1000n,
            });
            expect(disputeEscalatedEvent).toBeDefined();

            let currentProposalState = await protocolProvider.read.getProposalById(proposalId);
            expect(currentProposalState?.status).toEqual(ProposalStatus.Escalated);

            // 5. Manually resolve the dispute to NoResolution impersonating the arbitrator account
            await anvilClient.impersonateAccount({ address: protocolContracts.arbitrator });
            const resolveTxHash = await anvilClient.writeContract({
                address: protocolContracts.eboProxy,
                abi: eboAbi,
                functionName: "resolve",
                args: [proposalId, ProposalStatus.NoResolution],
                account: protocolContracts.arbitrator,
            });

            const resolveReceipt = await anvilClient.waitForTransactionReceipt({
                hash: resolveTxHash,
            });
            await anvilClient.mine({ blocks: 1 });
            await anvilClient.stopImpersonatingAccount({ address: protocolContracts.arbitrator });
            expect(resolveReceipt.status).toBe("success");

            // 6. Wait for DisputeResolved event with NoResolution status
            const disputeResolvedEvent = await waitForEvent({
                client: anvilClient,
                filter: {
                    address: protocolContracts.eboProxy,
                    fromBlock: disputeEscalatedEvent.blockNumber, // Search after escalation
                    event: getAbiItem({ abi: eboAbi, name: "DisputeResolved" }),
                    strict: true,
                },
                matcher: (log) =>
                    log.args._proposalId === proposalId &&
                    log.args._resolutionStatus === ProposalStatus.NoResolution,
                pollingIntervalMs: 100,
                blockTimeout: disputeEscalatedEvent.blockNumber + 1000n,
            });

            expect(disputeResolvedEvent).toBeDefined();
            expect(disputeResolvedEvent.args._resolutionStatus).toEqual(
                ProposalStatus.NoResolution,
            );

            // 7. Verify final proposal status from contract
            currentProposalState = await protocolProvider.read.getProposalById(proposalId);
            expect(currentProposalState?.status).toEqual(ProposalStatus.NoResolution);

            // Check agent logs for expected messages
            await vi.waitFor(() => expect(agentOutput).not.toContain(`Critical error`), {
                timeout: 5000,
            });
            await vi.waitFor(
                () =>
                    expect(agentOutput).toContain(
                        `Pledged 'against' dispute on proposal ${proposalId}`,
                    ),
                { timeout: 5000 },
            );
            await vi.waitFor(
                () =>
                    expect(agentOutput).toContain(
                        `Processing event ${disputeEscalatedEvent.eventName} for proposal ${proposalId}...`,
                    ),
                { timeout: 5000 },
            );
            await vi.waitFor(
                () =>
                    expect(agentOutput).toContain(
                        `Processing event ${disputeResolvedEvent.eventName} for proposal ${proposalId}...`,
                    ),
                { timeout: 10000 },
            );
        },
    );
});
