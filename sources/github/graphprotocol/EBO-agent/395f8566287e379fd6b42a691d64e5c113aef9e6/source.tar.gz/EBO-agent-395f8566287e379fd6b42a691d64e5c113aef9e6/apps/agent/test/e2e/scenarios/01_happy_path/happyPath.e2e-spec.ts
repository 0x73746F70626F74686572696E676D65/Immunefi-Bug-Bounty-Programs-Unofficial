import { ChildProcessWithoutNullStreams } from "child_process";
import { existsSync } from "fs";
import path from "path";
import {
    eboAbi,
    NotificationServiceFactory,
    ProposalId,
    ProtocolProviderV2,
} from "@ebo-agent/automated-dispute";
import { BlockNumberService } from "@ebo-agent/blocknumber";
import { Caip2ChainId, Logger, NotificationService } from "@ebo-agent/shared";
import { getAbiItem } from "viem";
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

import {
    AnvilTestEnvironment,
    ARBITRUM_SEPOLIA_ID,
    ARBITRUM_SEPOLIA_ID_HASH,
    E2E_SCENARIO_SETUP_TIMEOUT,
    E2E_TEST_TIMEOUT,
    killAgent,
    PROTOCOL_L2_CHAIN_ID,
    setupAnvilTestEnvironment,
    spawnAgent,
    waitForEvent,
} from "../../utils/e2e-scaffold/index.js";

describe.sequential("proposal created and finalized", () => {
    const tmpConfigDir = path.join(__dirname, "/tmp");
    const tmpConfigFile = path.join(tmpConfigDir, "/config.yml");

    let agent: ChildProcessWithoutNullStreams | undefined;
    let testEnv: AnvilTestEnvironment;

    let protocolProvider: ProtocolProviderV2;
    let blockNumberService: BlockNumberService;

    const notifier: NotificationService = NotificationServiceFactory.create(Logger.getInstance());
    const logger = Logger.getInstance();

    beforeAll(async () => {
        // Setup the test environment with dynamic port allocation
        testEnv = await setupAnvilTestEnvironment(__dirname);
    }, E2E_SCENARIO_SETUP_TIMEOUT);

    afterAll(async () => {
        // Clean up the test environment
        await testEnv.cleanup();
    });

    beforeEach(async () => {
        blockNumberService = new BlockNumberService(
            new Map<Caip2ChainId, string[]>([["eip155:421614", [testEnv.localUrl]]]),
            {
                baseUrl: new URL("http://not.needed/"),
                bearerToken: "not.needed",
                bearerTokenExpirationWindow: 1000,
                servicePaths: {
                    block: "/block",
                    blockByTime: "/blockByTime",
                },
            },
            logger,
            notifier,
        );
    }, E2E_SCENARIO_SETUP_TIMEOUT);

    afterEach(async () => {
        await testEnv.anvilClient.revert({ id: testEnv.snapshotId });

        if (existsSync(tmpConfigFile) && agent) {
            await killAgent({
                process: agent,
                configPath: tmpConfigFile,
            });
        }
    });

    it("proposes and finalizes successfully", { timeout: E2E_TEST_TIMEOUT }, async () => {
        const { anvilClient, protocolContracts, withStakeAccounts, localUrl } = testEnv;

        const agentAccount = withStakeAccounts[0];

        if (!agentAccount || agentAccount.privateKey === undefined) {
            throw new Error("Accounts not found");
        }

        protocolProvider = new ProtocolProviderV2(
            {
                l1: {
                    chainId: "eip155:421614",
                    // Using the same RPC due to Anvil's arbitrum block number bug
                    urls: [testEnv.localUrl],
                    transactionReceiptConfirmations: 1,
                    timeout: 1_000,
                    retryInterval: 500,
                },
                l2: {
                    chainId: "eip155:421614",
                    urls: [testEnv.localUrl],
                    transactionReceiptConfirmations: 1,
                    timeout: 1_000,
                    retryInterval: 500,
                },
            },
            {
                epochManager: testEnv.protocolContracts.epochManager,
                ebo: testEnv.protocolContracts.eboProxy,
            },
            agentAccount.privateKey,
            logger,
            blockNumberService,
        );

        const currentEpoch = await protocolProvider.getCurrentEpoch();
        const initBlock = await anvilClient.getBlockNumber();

        agent = spawnAgent({
            configPath: tmpConfigFile,
            config: {
                protocolProvider: {
                    contracts: {
                        ebo: protocolContracts.eboProxy,
                        epochManager: protocolContracts.epochManager,
                    },
                    rpcsConfig: {
                        l1: {
                            chainId: PROTOCOL_L2_CHAIN_ID,
                            transactionReceiptConfirmations: 1,
                            timeout: 1_000,
                            retryInterval: 500,
                        },
                        l2: {
                            chainId: PROTOCOL_L2_CHAIN_ID,
                            transactionReceiptConfirmations: 1,
                            timeout: 1_000,
                            retryInterval: 500,
                        },
                    },
                },
                blockNumberService: {
                    blockmetaConfig: {
                        baseUrl: new URL("http://not.needed/"),
                        bearerTokenExpirationWindow: 1000,
                        servicePaths: {
                            block: "/block",
                            blockByTime: "/blockByTime",
                        },
                    },
                },
                processor: {
                    msBetweenChecks: 3000,
                },
            },
            env: {
                PROTOCOL_PROVIDER_PRIVATE_KEY: agentAccount.privateKey,
                PROTOCOL_PROVIDER_L1_RPC_URLS: [localUrl],
                // Using the same RPC due to Anvil's arbitrum block number bug
                PROTOCOL_PROVIDER_L2_RPC_URLS: [localUrl],
                BLOCK_NUMBER_BLOCKMETA_TOKEN: "not.needed",
                BLOCK_NUMBER_RPC_URLS_MAP: new Map<Caip2ChainId, string[]>([
                    [PROTOCOL_L2_CHAIN_ID, [localUrl]],
                ]),
            },
        });

        let agentOutput = ""; // Variable to capture agent's stdout
        // Capture agent's stdout and stderr
        agent.stdout.on("data", (data) => {
            agentOutput += data.toString();
        });

        const proposalCreatedAbi = getAbiItem({ abi: eboAbi, name: "ProposalCreated" });

        let chainProposalId: bigint;

        const proposalCreatedEvent = await waitForEvent({
            client: anvilClient,
            filter: {
                address: protocolContracts.eboProxy,
                fromBlock: initBlock,
                event: proposalCreatedAbi,
                strict: true,
            },
            matcher: (log) => {
                const chainId = log.args._chainId;

                if (chainId !== ARBITRUM_SEPOLIA_ID_HASH) return false;

                chainProposalId = log.args._proposalId;

                return true;
            },
            pollingIntervalMs: 100,
            blockTimeout: initBlock + 1000n,
        });

        expect(proposalCreatedEvent).toBeDefined();

        const proposal = await protocolProvider.getProposalById(chainProposalId! as ProposalId);
        expect(proposal).toBeDefined();

        const snapshotParameters = await protocolProvider.getSnapshotParameters(
            proposal!.parametersSnapshotId,
        );

        expect(snapshotParameters).toBeDefined();

        await anvilClient.increaseTime({ seconds: Number(snapshotParameters!.disputeWindow) });

        await anvilClient.mine({ blocks: 1 });

        const proposalFinalizedAbi = getAbiItem({
            abi: eboAbi,
            name: "ProposalFinalized",
        });

        const proposalFinalizedEvent = await waitForEvent({
            client: anvilClient,
            filter: {
                address: protocolContracts.eboProxy,
                fromBlock: initBlock,
                event: proposalFinalizedAbi,
                strict: true,
            },
            matcher: (log) => {
                return (
                    log.args._proposalId === chainProposalId &&
                    log.args._chainId === ARBITRUM_SEPOLIA_ID_HASH &&
                    log.args._epoch === currentEpoch.number
                );
            },
            pollingIntervalMs: 100,
            blockTimeout: initBlock + 1000n,
        });

        expect(proposalFinalizedEvent).toBeDefined();

        await vi.waitFor(
            () => expect(agentOutput).toContain(`Proposal ${chainProposalId} has been finalized.`),
            {
                timeout: 5000,
            },
        );
    });

    it(
        "adversarial actor proposes correct block number and agent finalizes",
        { timeout: E2E_TEST_TIMEOUT },
        async () => {
            const { anvilClient, protocolContracts, withStakeAccounts, localUrl } = testEnv;

            const agentAccount = withStakeAccounts[0];
            const adversarialAccount = withStakeAccounts[1];
            if (
                !withStakeAccounts ||
                withStakeAccounts.length < 2 ||
                agentAccount?.privateKey === undefined ||
                adversarialAccount?.privateKey === undefined
            ) {
                throw new Error("Not enough accounts found");
            }

            const currentEpoch = await protocolProvider.getCurrentEpoch();
            const initBlock = await anvilClient.getBlockNumber();

            // Create a separate protocol provider for the "adversarial" actor using a different account
            const adversarialProvider = new ProtocolProviderV2(
                {
                    l1: {
                        chainId: "eip155:421614",
                        urls: [testEnv.localUrl],
                        transactionReceiptConfirmations: 1,
                        timeout: 1_000,
                        retryInterval: 500,
                    },
                    l2: {
                        chainId: "eip155:421614",
                        urls: [testEnv.localUrl],
                        transactionReceiptConfirmations: 1,
                        timeout: 1_000,
                        retryInterval: 500,
                    },
                },
                {
                    epochManager: testEnv.protocolContracts.epochManager,
                    ebo: testEnv.protocolContracts.eboProxy,
                },
                adversarialAccount.privateKey, // Using a different account for the adversarial actor
                logger,
                blockNumberService,
            );

            // The "adversarial" actor (second account) creates a proposal with a correct block number
            // Here we're using the blockNumberService to get the "real" block number to simulate a correct proposal
            const targetBlockNumber = await blockNumberService.getEpochBlockNumber(
                currentEpoch.startTimestamp,
                PROTOCOL_L2_CHAIN_ID,
            );

            // Create a proposal using the adversarial account
            await adversarialProvider.propose(
                currentEpoch.number,
                ARBITRUM_SEPOLIA_ID,
                targetBlockNumber,
                adversarialAccount.account.address,
            );

            // Mine the transaction
            await anvilClient.mine({ blocks: 1 });

            // Start the agent with the first account
            agent = spawnAgent({
                configPath: tmpConfigFile,
                config: {
                    protocolProvider: {
                        contracts: {
                            ebo: protocolContracts.eboProxy,
                            epochManager: protocolContracts.epochManager,
                        },
                        rpcsConfig: {
                            l1: {
                                chainId: PROTOCOL_L2_CHAIN_ID,
                                transactionReceiptConfirmations: 1,
                                timeout: 1_000,
                                retryInterval: 500,
                            },
                            l2: {
                                chainId: PROTOCOL_L2_CHAIN_ID,
                                transactionReceiptConfirmations: 1,
                                timeout: 1_000,
                                retryInterval: 500,
                            },
                        },
                    },
                    blockNumberService: {
                        blockmetaConfig: {
                            baseUrl: new URL("http://not.needed/"),
                            bearerTokenExpirationWindow: 1000,
                            servicePaths: {
                                block: "/block",
                                blockByTime: "/blockByTime",
                            },
                        },
                    },
                    processor: {
                        msBetweenChecks: 3000,
                    },
                },
                env: {
                    PROTOCOL_PROVIDER_PRIVATE_KEY: agentAccount.privateKey,
                    PROTOCOL_PROVIDER_L1_RPC_URLS: [localUrl],
                    PROTOCOL_PROVIDER_L2_RPC_URLS: [localUrl],
                    BLOCK_NUMBER_BLOCKMETA_TOKEN: "not.needed",
                    BLOCK_NUMBER_RPC_URLS_MAP: new Map<Caip2ChainId, string[]>([
                        [PROTOCOL_L2_CHAIN_ID, [localUrl]],
                    ]),
                },
            });

            let agentOutput = ""; // Variable to capture agent's stdout
            // Capture agent's stdout and stderr
            agent.stdout.on("data", (data) => {
                agentOutput += data.toString();
            });

            const proposalCreatedAbi = getAbiItem({ abi: eboAbi, name: "ProposalCreated" });

            let chainProposalId: bigint;

            // Wait for the ProposalCreated event
            const proposalCreatedEvent = await waitForEvent({
                client: anvilClient,
                filter: {
                    address: protocolContracts.eboProxy,
                    fromBlock: initBlock,
                    event: proposalCreatedAbi,
                    strict: true,
                },
                matcher: (log) => {
                    const chainId = log.args._chainId;
                    const epoch = log.args._epoch;

                    if (chainId !== ARBITRUM_SEPOLIA_ID_HASH || epoch !== currentEpoch.number) {
                        return false;
                    }

                    chainProposalId = log.args._proposalId;
                    return true;
                },
                pollingIntervalMs: 100,
                blockTimeout: initBlock + 1000n,
            });

            expect(proposalCreatedEvent).toBeDefined();
            expect(proposalCreatedEvent?.args._blockNumber).toBe(targetBlockNumber);

            // Get the proposal and snapshot parameters
            const proposal = await protocolProvider.getProposalById(chainProposalId! as ProposalId);
            expect(proposal).toBeDefined();

            const snapshotParameters = await protocolProvider.getSnapshotParameters(
                proposal!.parametersSnapshotId,
            );
            expect(snapshotParameters).toBeDefined();

            // Since the block number is correct, agent should not dispute it
            // We can mine a few blocks to let the agent have time to check
            await anvilClient.mine({ blocks: 5 });

            // Verify proposal is still active (not disputed)
            const proposalAfterAgentCheck = await protocolProvider.getProposalById(
                chainProposalId! as ProposalId,
            );
            expect(proposalAfterAgentCheck?.status).toEqual(1); // Active status

            await vi.waitFor(
                () =>
                    expect(agentOutput).toContain(
                        `ProposalCreated event received but epoch block number ${targetBlockNumber} is correct.`,
                    ),
                {
                    timeout: 21_000,
                },
            );

            // Advance time past the dispute window to allow finalization
            await anvilClient.increaseTime({ seconds: Number(snapshotParameters!.disputeWindow) });
            await anvilClient.mine({ blocks: 1 });

            // Wait for the agent to finalize the proposal
            const proposalFinalizedAbi = getAbiItem({
                abi: eboAbi,
                name: "ProposalFinalized",
            });

            const proposalFinalizedEvent = await waitForEvent({
                client: anvilClient,
                filter: {
                    address: protocolContracts.eboProxy,
                    fromBlock: initBlock,
                    event: proposalFinalizedAbi,
                    strict: true,
                },
                matcher: (log) => {
                    return (
                        log.args._proposalId === chainProposalId &&
                        log.args._chainId === ARBITRUM_SEPOLIA_ID_HASH &&
                        log.args._epoch === currentEpoch.number
                    );
                },
                pollingIntervalMs: 100,
                blockTimeout: initBlock + 1000n,
            });

            expect(proposalFinalizedEvent).toBeDefined();

            // Verify the proposal was finalized
            const finalizedProposal = await protocolProvider.getProposalById(
                chainProposalId! as ProposalId,
            );
            expect(finalizedProposal?.status).toEqual(7); // Finalized status

            await vi.waitFor(
                () =>
                    expect(agentOutput).toContain(
                        `Proposal ${chainProposalId} has been finalized.`,
                    ),
                {
                    timeout: 5000,
                },
            );
        },
    );
});
