import { ChildProcessWithoutNullStreams, spawn } from "child_process";
import fs from "fs";
import yaml from "yaml";

import { eboAgentConfigSchema, envSchema } from "../../../../src/config/schemas.js";

type AgentConfig = Zod.infer<typeof eboAgentConfigSchema>;
type AgentEnv = Omit<Zod.infer<typeof envSchema>, "EBO_AGENT_CONFIG_FILE_PATH">;

export const spawnAgent = (params: { config: AgentConfig; configPath: string; env: AgentEnv }) => {
    const { config, configPath, env } = params;

    generateConfigFile(configPath, config);

    console.log("Spawning node");

    const blockNumberUrls = JSON.stringify(
        Object.fromEntries(env.BLOCK_NUMBER_RPC_URLS_MAP.entries()),
    );

    const agentProcess = spawn("pnpm", ["start"], {
        env: {
            ...process.env,
            ...env,
            LOG_LEVEL: "info",
            PROTOCOL_PROVIDER_L1_RPC_URLS: env.PROTOCOL_PROVIDER_L1_RPC_URLS.toString(),
            PROTOCOL_PROVIDER_L2_RPC_URLS: env.PROTOCOL_PROVIDER_L2_RPC_URLS.toString(),
            BLOCK_NUMBER_RPC_URLS_MAP: blockNumberUrls,
            EBO_AGENT_CONFIG_FILE_PATH: configPath,
            // Force Winston to not colorize output in child process
            NO_COLOR: "1",
        },
        stdio: "pipe",
        shell: true,
    });

    agentProcess.on("error", (data) => {
        console.error(data);
    });

    agentProcess.on("exit", (code) => {
        if (code !== null && code !== 0) {
            console.error(`Exited with code ${code}`);
        }
    });

    agentProcess.stdout.on("data", (data) => {
        console.log(`[stdout] data: ${data}`);
    });

    agentProcess.stderr.on("data", (data) => {
        console.log(`[stderr] data: ${data}`);
    });

    return agentProcess;
};

export const killAgent = (params: {
    process: ChildProcessWithoutNullStreams;
    configPath: string;
}) => {
    const { process, configPath } = params;

    if (process) {
        // Need to clear process channel to actually kill it
        process.stdin.end();
        process.stdout.destroy();
        process.stderr.destroy();

        process.kill("SIGKILL");
    }

    fs.rmSync(configPath);

    console.log("Agent killed");
};

const generateConfigFile = (path: string, config: AgentConfig) => {
    const content = yaml.stringify(config);

    fs.writeFileSync(path, content, "utf-8");
};
