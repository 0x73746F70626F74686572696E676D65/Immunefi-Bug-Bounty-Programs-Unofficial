import { ChildProcessWithoutNullStreams } from "child_process";
import { existsSync } from "fs";
import path from "path";
import {
    eboAbi,
    NotificationServiceFactory,
    ProposalId,
    ProtocolProviderV2,
} from "@ebo-agent/automated-dispute";
import { BlockNumberService } from "@ebo-agent/blocknumber";
import { Caip2ChainId, Logger, NotificationService } from "@ebo-agent/shared";
import { defineChain, getAbiItem, keccak256, stringToBytes } from "viem";
import { sepolia } from "viem/chains";
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

import {
    addEboChains,
    AnvilTestEnvironment,
    ARBITRUM_SEPOLIA_ID,
    ARBITRUM_SEPOLIA_ID_HASH,
    createAnvilServer,
    createViemAnvilClient,
    E2E_SCENARIO_SETUP_TIMEOUT,
    E2E_TEST_TIMEOUT,
    env,
    GRT_HOLDER,
    killAgent,
    PROTOCOL_L2_CHAIN_ID,
    setupAnvilTestEnvironment,
    spawnAgent,
    waitForEvent,
} from "../../utils/e2e-scaffold/index.js";

// Define constants for Ethereum Sepolia
const ETHEREUM_SEPOLIA_ID = "eip155:11155111";
const ETHEREUM_SEPOLIA_ID_HASH = keccak256(stringToBytes(ETHEREUM_SEPOLIA_ID));
const ETHEREUM_SEPOLIA_FORK_URL = "https://sepolia.gateway.tenderly.co";

// Define constants for Solana mainnet
const BLOCKMETA_SOLANA_MAINNET_URL = "https://mainnet.sol.streamingfast.io/";
const SOLANA_MAINNET_ID = "solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp";
const SOLANA_MAINNET_ID_HASH = keccak256(stringToBytes(SOLANA_MAINNET_ID));

// Setup chain config
const ETHEREUM_SEPOLIA_CHAIN = defineChain({
    ...sepolia,
    id: 11155111,
    name: "Ethereum Sepolia",
});

type MultiChainTestEnvironment = {
    arbitrumEnv: AnvilTestEnvironment;
    ethereumEnv: {
        port: number;
        localUrl: string;
        anvilServer: any;
        anvilClient: any;
        snapshotId: `0x${string}`;
    };
    cleanup: () => Promise<void>;
};

describe.sequential("multi-chain support", () => {
    const tmpConfigDir = path.join(__dirname, "/tmp");
    const tmpConfigFile = path.join(tmpConfigDir, "/config.yml");

    let agent: ChildProcessWithoutNullStreams | undefined;
    let testEnv: MultiChainTestEnvironment;

    let protocolProvider: ProtocolProviderV2;
    let blockNumberService: BlockNumberService;
    let blockMetaClient: BlockNumberService["blockmetaConfig"];

    const notifier: NotificationService = NotificationServiceFactory.create(Logger.getInstance());
    const logger = Logger.getInstance();

    async function setupMultiChainEnvironment(testDir: string): Promise<MultiChainTestEnvironment> {
        // Setup the Arbitrum Sepolia environment (main chain)
        const arbitrumEnv = await setupAnvilTestEnvironment(testDir);

        // Create a second Anvil instance for Ethereum Sepolia
        const ethereumSepoliaPort = arbitrumEnv.port + 1;
        const ethereumSepoliaUrl = `http://127.0.0.1:${ethereumSepoliaPort}/1`;

        const ethereumSepoliaAnvil = await createAnvilServer("127.0.0.1", ethereumSepoliaPort, {
            forkUrl: ETHEREUM_SEPOLIA_FORK_URL,
            slotsInAnEpoch: 1,
            blockTime: 0.25,
        });

        // Create client for the Ethereum Sepolia fork
        const ethereumSepoliaClient = createViemAnvilClient(
            GRT_HOLDER,
            ETHEREUM_SEPOLIA_CHAIN,
            ethereumSepoliaUrl,
        );
        const currentTimestamp = Math.floor(Date.now() / 1000);
        await ethereumSepoliaClient.setNextBlockTimestamp({ timestamp: BigInt(currentTimestamp) });
        await ethereumSepoliaClient.mine({ blocks: 1 });

        await addEboChains(
            [ETHEREUM_SEPOLIA_ID],
            arbitrumEnv.protocolContracts,
            arbitrumEnv.anvilClient,
        );

        // Take a snapshot for the Ethereum Sepolia environment
        const ethereumSepoliaSnapshotId = await ethereumSepoliaClient.snapshot();

        return {
            arbitrumEnv,
            ethereumEnv: {
                port: ethereumSepoliaPort,
                localUrl: ethereumSepoliaUrl,
                anvilServer: ethereumSepoliaAnvil,
                anvilClient: ethereumSepoliaClient,
                snapshotId: ethereumSepoliaSnapshotId,
            },
            cleanup: async () => {
                await ethereumSepoliaAnvil.stop();
                await arbitrumEnv.cleanup();
            },
        };
    }

    beforeAll(async () => {
        // Setup the multi-chain test environment
        testEnv = await setupMultiChainEnvironment(__dirname);
    }, E2E_SCENARIO_SETUP_TIMEOUT);

    afterAll(async () => {
        // Clean up both test environments
        await testEnv.cleanup();
    });

    beforeEach(async () => {
        // Setup block number service with both chains
        blockMetaClient = {
            baseUrl: new URL(BLOCKMETA_SOLANA_MAINNET_URL),
            bearerToken: env.BLOCK_NUMBER_BLOCKMETA_TOKEN || "not.needed",
            bearerTokenExpirationWindow: 31536000000,
            servicePaths: {
                block: "/sf.blockmeta.v2.Block",
                blockByTime: "/sf.blockmeta.v2.BlockByTime",
            },
        };
        blockNumberService = new BlockNumberService(
            new Map<Caip2ChainId, string[]>([
                [ARBITRUM_SEPOLIA_ID, [testEnv.arbitrumEnv.localUrl]],
                [ETHEREUM_SEPOLIA_ID, [testEnv.ethereumEnv.localUrl]],
            ]),
            blockMetaClient,
            logger,
            notifier,
        );
    }, E2E_SCENARIO_SETUP_TIMEOUT);

    afterEach(async () => {
        // Revert both environments to initial snapshots
        await testEnv.arbitrumEnv.anvilClient.revert({ id: testEnv.arbitrumEnv.snapshotId });
        await testEnv.ethereumEnv.anvilClient.revert({ id: testEnv.ethereumEnv.snapshotId });

        if (existsSync(tmpConfigFile) && agent) {
            await killAgent({
                process: agent,
                configPath: tmpConfigFile,
            });
        }
    });

    it(
        "proposes successfully on arbitrum sepolia and ethereum sepolia",
        {
            timeout: E2E_TEST_TIMEOUT,
        },
        async () => {
            const { arbitrumEnv } = testEnv;
            const { anvilClient, protocolContracts, withStakeAccounts } = arbitrumEnv;

            const agentAccount = withStakeAccounts[0];

            if (!agentAccount || agentAccount.privateKey === undefined) {
                throw new Error("Accounts not found");
            }

            // Create protocol provider with both chains
            protocolProvider = new ProtocolProviderV2(
                {
                    l1: {
                        chainId: ARBITRUM_SEPOLIA_ID,
                        urls: [testEnv.arbitrumEnv.localUrl],
                        transactionReceiptConfirmations: 1,
                        timeout: 1_000,
                        retryInterval: 500,
                    },
                    l2: {
                        chainId: ARBITRUM_SEPOLIA_ID,
                        urls: [testEnv.arbitrumEnv.localUrl],
                        transactionReceiptConfirmations: 1,
                        timeout: 1_000,
                        retryInterval: 500,
                    },
                },
                {
                    epochManager: protocolContracts.epochManager,
                    ebo: protocolContracts.eboProxy,
                },
                agentAccount.privateKey,
                logger,
                blockNumberService,
            );

            const initBlock = await anvilClient.getBlockNumber();
            const epoch = await protocolProvider.getCurrentEpoch();

            // Spawn agent with configuration for both chains
            agent = spawnAgent({
                configPath: tmpConfigFile,
                config: {
                    protocolProvider: {
                        contracts: {
                            ebo: protocolContracts.eboProxy,
                            epochManager: protocolContracts.epochManager,
                        },
                        rpcsConfig: {
                            l1: {
                                chainId: PROTOCOL_L2_CHAIN_ID,
                                transactionReceiptConfirmations: 1,
                                timeout: 1_000,
                                retryInterval: 500,
                            },
                            l2: {
                                chainId: PROTOCOL_L2_CHAIN_ID,
                                transactionReceiptConfirmations: 1,
                                timeout: 1_000,
                                retryInterval: 500,
                            },
                        },
                    },
                    blockNumberService: {
                        blockmetaConfig: {
                            baseUrl: new URL("http://not.needed/"),
                            bearerTokenExpirationWindow: 1000,
                            servicePaths: {
                                block: "/block",
                                blockByTime: "/blockByTime",
                            },
                        },
                    },
                    processor: {
                        msBetweenChecks: 3000,
                    },
                },
                env: {
                    PROTOCOL_PROVIDER_PRIVATE_KEY: agentAccount.privateKey,
                    PROTOCOL_PROVIDER_L1_RPC_URLS: [testEnv.arbitrumEnv.localUrl],
                    PROTOCOL_PROVIDER_L2_RPC_URLS: [testEnv.arbitrumEnv.localUrl],
                    BLOCK_NUMBER_BLOCKMETA_TOKEN: "not.needed",
                    BLOCK_NUMBER_RPC_URLS_MAP: new Map<Caip2ChainId, string[]>([
                        [ARBITRUM_SEPOLIA_ID, [testEnv.arbitrumEnv.localUrl]],
                        [ETHEREUM_SEPOLIA_ID, [testEnv.ethereumEnv.localUrl]],
                    ]),
                },
            });

            let agentOutput = ""; // Variable to capture agent's stdout

            agent.stdout.on("data", (data) => {
                agentOutput += data.toString();
            });

            const proposalCreatedAbi = getAbiItem({ abi: eboAbi, name: "ProposalCreated" });

            // Wait for proposal on Arbitrum Sepolia
            let arbitrumProposalId: bigint;
            const arbitrumProposalEvent = await waitForEvent({
                client: anvilClient,
                filter: {
                    address: protocolContracts.eboProxy,
                    fromBlock: initBlock,
                    event: proposalCreatedAbi,
                    strict: true,
                },
                matcher: (log) => {
                    if (log.args._chainId !== ARBITRUM_SEPOLIA_ID_HASH) return false;
                    arbitrumProposalId = log.args._proposalId;
                    return true;
                },
                pollingIntervalMs: 100,
                blockTimeout: initBlock + 1000n,
            });

            expect(arbitrumProposalEvent).toBeDefined();
            expect(arbitrumProposalId!).toBeDefined();

            // Mine a few blocks on Ethereum Sepolia to trigger proposal there
            await testEnv.ethereumEnv.anvilClient.mine({ blocks: 10 });

            // Wait for proposal on Ethereum Sepolia
            let ethereumProposalId: bigint;
            const ethereumProposalEvent = await waitForEvent({
                client: anvilClient,
                filter: {
                    address: protocolContracts.eboProxy,
                    fromBlock: initBlock,
                    event: proposalCreatedAbi,
                    strict: true,
                },
                matcher: (log) => {
                    if (log.args._chainId !== ETHEREUM_SEPOLIA_ID_HASH) return false;
                    ethereumProposalId = log.args._proposalId;
                    return true;
                },
                pollingIntervalMs: 100,
                blockTimeout: initBlock + 1000n,
            });

            expect(ethereumProposalEvent).toBeDefined();
            expect(ethereumProposalId!).toBeDefined();

            // Verify proposals exist on both chains
            const arbitrumProposal = await protocolProvider.getProposalById(
                arbitrumProposalId! as ProposalId,
            );
            expect(arbitrumProposal).toBeDefined();

            const ethereumProposal = await protocolProvider.getProposalById(
                ethereumProposalId! as ProposalId,
            );
            expect(ethereumProposal).toBeDefined();

            // Verify agent output mentions both chains
            await vi.waitFor(
                () => {
                    expect(agentOutput).toContain(
                        `Proposal created for chain eip155:421614 and epoch ${epoch.number}`,
                    );
                    expect(agentOutput).toContain(
                        `Proposal created for chain eip155:11155111 and epoch ${epoch.number}`,
                    );
                },
                { timeout: 10000 },
            );
        },
    );

    it(
        "proposes successfully on Solana mainnet",
        {
            timeout: E2E_TEST_TIMEOUT,
            skip: env.BLOCK_NUMBER_BLOCKMETA_TOKEN === undefined,
        },
        async () => {
            const { arbitrumEnv } = testEnv;
            const { anvilClient, protocolContracts, withStakeAccounts } = arbitrumEnv;

            const agentAccount = withStakeAccounts[0];

            if (!agentAccount || agentAccount.privateKey === undefined) {
                throw new Error("Accounts not found");
            }

            // Add Solana to EBO chains
            await addEboChains(
                [SOLANA_MAINNET_ID],
                arbitrumEnv.protocolContracts,
                arbitrumEnv.anvilClient,
            );

            // Setup block number service with Solana chain
            blockNumberService = new BlockNumberService(
                new Map<Caip2ChainId, string[]>([
                    [ARBITRUM_SEPOLIA_ID, [testEnv.arbitrumEnv.localUrl]],
                    [SOLANA_MAINNET_ID, ["https://api.mainnet-beta.solana.com"]],
                ]),
                blockMetaClient,
                logger,
                notifier,
            );

            // Create protocol provider with Solana configured
            protocolProvider = new ProtocolProviderV2(
                {
                    l1: {
                        chainId: ARBITRUM_SEPOLIA_ID,
                        urls: [testEnv.arbitrumEnv.localUrl],
                        transactionReceiptConfirmations: 1,
                        timeout: 1_000,
                        retryInterval: 500,
                    },
                    l2: {
                        chainId: ARBITRUM_SEPOLIA_ID,
                        urls: [testEnv.arbitrumEnv.localUrl],
                        transactionReceiptConfirmations: 1,
                        timeout: 1_000,
                        retryInterval: 500,
                    },
                },
                {
                    epochManager: protocolContracts.epochManager,
                    ebo: protocolContracts.eboProxy,
                },
                agentAccount.privateKey,
                logger,
                blockNumberService,
            );

            const initBlock = await anvilClient.getBlockNumber();
            const epoch = await protocolProvider.getCurrentEpoch();

            // Spawn agent with configuration for Solana
            agent = spawnAgent({
                configPath: tmpConfigFile,
                config: {
                    protocolProvider: {
                        contracts: {
                            ebo: protocolContracts.eboProxy,
                            epochManager: protocolContracts.epochManager,
                        },
                        rpcsConfig: {
                            l1: {
                                chainId: PROTOCOL_L2_CHAIN_ID,
                                transactionReceiptConfirmations: 1,
                                timeout: 1_000,
                                retryInterval: 500,
                            },
                            l2: {
                                chainId: PROTOCOL_L2_CHAIN_ID,
                                transactionReceiptConfirmations: 1,
                                timeout: 1_000,
                                retryInterval: 500,
                            },
                        },
                    },
                    blockNumberService: {
                        blockmetaConfig: blockMetaClient,
                    },
                    processor: {
                        msBetweenChecks: 3000,
                    },
                },
                env: {
                    PROTOCOL_PROVIDER_PRIVATE_KEY: agentAccount.privateKey,
                    PROTOCOL_PROVIDER_L1_RPC_URLS: [testEnv.arbitrumEnv.localUrl],
                    PROTOCOL_PROVIDER_L2_RPC_URLS: [testEnv.arbitrumEnv.localUrl],
                    BLOCK_NUMBER_BLOCKMETA_TOKEN: env.BLOCK_NUMBER_BLOCKMETA_TOKEN!,
                    BLOCK_NUMBER_RPC_URLS_MAP: new Map<Caip2ChainId, string[]>([
                        [ARBITRUM_SEPOLIA_ID, [testEnv.arbitrumEnv.localUrl]],
                        [SOLANA_MAINNET_ID, ["https://api.mainnet-beta.solana.com"]],
                    ]),
                },
            });

            let agentOutput = ""; // Variable to capture agent's stdout

            agent.stdout.on("data", (data) => {
                agentOutput += data.toString();
            });

            // Wait for proposal on Solana
            let solanaProposalId: bigint;
            const solanaProposalEvent = await waitForEvent({
                client: anvilClient,
                filter: {
                    address: protocolContracts.eboProxy,
                    fromBlock: initBlock,
                    event: getAbiItem({ abi: eboAbi, name: "ProposalCreated" }),
                    strict: true,
                },
                matcher: (log) => {
                    if (log.args._chainId !== SOLANA_MAINNET_ID_HASH) return false;
                    solanaProposalId = log.args._proposalId;
                    return true;
                },
                pollingIntervalMs: 100,
                blockTimeout: initBlock + 1000n,
            });

            expect(solanaProposalEvent).toBeDefined();
            expect(solanaProposalId!).toBeDefined();

            // Verify proposal exists for Solana
            const solanaProposal = await protocolProvider.getProposalById(
                solanaProposalId! as ProposalId,
            );
            expect(solanaProposal).toBeDefined();

            // Verify agent output mentions Solana proposal
            await vi.waitFor(
                () => {
                    expect(agentOutput).toContain(
                        `Proposal created for chain solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp and epoch ${epoch.number}`,
                    );
                },
                { timeout: 10000 },
            );
        },
    );
});
