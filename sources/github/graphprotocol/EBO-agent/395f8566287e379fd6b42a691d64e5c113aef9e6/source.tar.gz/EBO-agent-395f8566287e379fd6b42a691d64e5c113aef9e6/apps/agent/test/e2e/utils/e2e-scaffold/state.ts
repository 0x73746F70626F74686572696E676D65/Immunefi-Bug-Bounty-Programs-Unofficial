import { existsSync, readFileSync, writeFileSync } from "fs";
import { Hex, parseEther, stringify } from "viem";

import type { AnvilClient, DeployContractsOutput, E2EEnv } from "./index.js";
import {
    addEboChains,
    BASE_ETH_AMOUNT,
    BASE_GRT_AMOUNT,
    createAnvilServer,
    createViemAnvilClient,
    DEFAULT_PROTOCOL_L2_LOCAL_RPC_PORT,
    deployEboContracts,
    EPOCH_LENGTH,
    EPOCH_MANAGER_GOVERNOR_ADDRESS,
    FORK_L2_BLOCK_NUMBER,
    FORK_L2_URL,
    fundAccountWithEth,
    getProtocolL2LocalUrl,
    GRT_HOLDER,
    PROTOCOL_L2_CHAIN,
    PROTOCOL_L2_CHAIN_ID,
    PROTOCOL_L2_LOCAL_RPC_HOST,
    restoreFromPrivateKey,
    setEpochLength,
    setUpAccount,
    stakeGrtWithProvision,
} from "./index.js";

export type StateFile = {
    state: Hex;
    protocolContracts: DeployContractsOutput;
    withStakeAccounts: { privateKey: Hex }[];
    withoutStakeAccounts: { privateKey: Hex }[];
};

/**
 * Dump the initial state of the blockchain into a file
 * @description This function will dump the initial state of the blockchain and save it to a file, the protocol contracts and accounts will be saved to the file
 * @param env {E2EEnv} - The environment variables
 * @param numberAccounts {number} - The number of accounts to create
 * @param port {number} - Optional port for the Anvil instance (defaults to DEFAULT_PROTOCOL_L2_LOCAL_RPC_PORT)
 *
 * This function will:
 * - Deploy EBO contracts from EBO contracts repository (requires EBO_CORE_PATH and EBO_AGENT_DEPLOYER_NAME and local clone of EBO contracts repository)
 * - Add Arbitrum Sepolia chain to EBO
 * - Fund the GRT holder and the epoch manager governor with ETH
 * - Create the specified number of accounts and fund them with ETH and GRT
 * - Set the epoch length to a big enough epoch length as in sepolia is way too short at the moment
 * - Mine a block
 */
export async function dumpInitialState(
    env: E2EEnv,
    numberAccounts: number,
    port: number = DEFAULT_PROTOCOL_L2_LOCAL_RPC_PORT,
): Promise<void> {
    const localUrl = getProtocolL2LocalUrl(port);

    const l2ProtocolAnvil = await createAnvilServer(PROTOCOL_L2_LOCAL_RPC_HOST, port, {
        forkUrl: FORK_L2_URL,
        forkBlockNumber: FORK_L2_BLOCK_NUMBER,
        slotsInAnEpoch: 1,
        blockTime: 0.1,
    });

    try {
        const anvilClient = createViemAnvilClient(GRT_HOLDER, PROTOCOL_L2_CHAIN, localUrl);

        const protocolContracts = await deployEboContracts({
            eboCorePath: env.EBO_CORE_PATH,
            keystorePassword: env.KEYSTORE_PASSWORD,
            rpcUrl: localUrl,
            deployerName: env.EBO_AGENT_DEPLOYER_NAME,
        });

        await addEboChains([PROTOCOL_L2_CHAIN_ID], protocolContracts, anvilClient);

        await fundAccountWithEth({
            account: GRT_HOLDER,
            anvilClient,
            amount: parseEther(BASE_ETH_AMOUNT.toString()),
        });

        await fundAccountWithEth({
            account: EPOCH_MANAGER_GOVERNOR_ADDRESS,
            anvilClient,
            amount: parseEther(BASE_ETH_AMOUNT.toString()),
        });

        const accounts = [];
        for (let i = 0; i < numberAccounts; i++) {
            accounts.push(
                await setUpAccount({
                    localRpcUrl: localUrl,
                    deployedContracts: protocolContracts,
                    chain: PROTOCOL_L2_CHAIN,
                    grtHolder: GRT_HOLDER,
                    grtContractAddress: protocolContracts.grt,
                    grtFundAmount: parseEther(BASE_GRT_AMOUNT.toString()),
                }),
            );
        }

        // Pick half of the accounts (floor the value)
        const halfAccounts = accounts.slice(0, Math.floor(accounts.length / 2));
        const withoutStakeAccounts = accounts.slice(Math.floor(accounts.length / 2));

        if (halfAccounts.length > 0) {
            await stakeGrtWithProvision(
                halfAccounts.map((acc) => acc.account),
                {
                    grt: protocolContracts.grt,
                    horizonStaking: protocolContracts.horizonStaking,
                    verifier: protocolContracts.eboProxy,
                },
                parseEther(BASE_GRT_AMOUNT.toString()),
                anvilClient,
            );
            console.log(`Staked GRT with provision for ${halfAccounts.length} accounts`);
        }

        // Set epoch length to a big enough epoch length as in sepolia is way too short at the moment
        await setEpochLength({
            length: EPOCH_LENGTH,
            client: anvilClient,
            epochManagerAddress: protocolContracts.epochManager,
            governorAddress: EPOCH_MANAGER_GOVERNOR_ADDRESS,
        });

        await anvilClient.mine({ blocks: 1 });

        const state = await anvilClient.dumpState();

        writeFileSync(
            env.STATE_FILE_PATH,
            stringify(
                {
                    state,
                    protocolContracts,
                    withStakeAccounts: halfAccounts.map((acc) => ({
                        privateKey: acc.privateKey,
                    })),
                    withoutStakeAccounts: withoutStakeAccounts.map((acc) => ({
                        privateKey: acc.privateKey,
                    })),
                },
                null,
                2,
            ),
        );
    } finally {
        await l2ProtocolAnvil.stop();
    }
}

/**
 * Load the blockchain state from the file
 * @description This function will load the blockchain state from the file into the anvil client
 * The state file is expected to exist (created by globalSetup)
 * @param stateFilePath - The path to the state file
 * @param anvilClient - The anvil client
 * @param port - Optional port for the Anvil instance (defaults to DEFAULT_PROTOCOL_L2_LOCAL_RPC_PORT)
 * @returns The protocol contracts and accounts
 */
export async function loadInitialState(
    stateFilePath: string,
    anvilClient: AnvilClient,
    port: number = DEFAULT_PROTOCOL_L2_LOCAL_RPC_PORT,
) {
    const localUrl = getProtocolL2LocalUrl(port);

    // Check if state file exists - it should always exist due to globalSetup
    if (!existsSync(stateFilePath)) {
        throw new Error(
            `State file ${stateFilePath} not found. Make sure globalSetup is configured correctly.`,
        );
    }

    // restore state from file
    const state = JSON.parse(readFileSync(stateFilePath, "utf8")) as StateFile;

    await anvilClient.loadState({ state: state.state });

    return {
        protocolContracts: state.protocolContracts,
        withStakeAccounts: state.withStakeAccounts.map((acc) =>
            restoreFromPrivateKey(acc.privateKey, localUrl, PROTOCOL_L2_CHAIN),
        ),
        withoutStakeAccounts: state.withoutStakeAccounts.map((acc) =>
            restoreFromPrivateKey(acc.privateKey, localUrl, PROTOCOL_L2_CHAIN),
        ),
    };
}
