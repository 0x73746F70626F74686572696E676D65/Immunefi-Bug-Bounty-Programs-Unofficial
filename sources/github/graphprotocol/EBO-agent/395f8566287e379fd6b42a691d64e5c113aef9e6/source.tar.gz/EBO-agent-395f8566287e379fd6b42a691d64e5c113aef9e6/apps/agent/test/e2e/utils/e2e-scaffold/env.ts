import { z } from "zod";

// Environment variables validation using Zod
const envSchema = z.object({
    KEYSTORE_PASSWORD: z.string().min(1, "KEYSTORE_PASSWORD is required"),
    EBO_CORE_PATH: z.string().min(1, "EBO_CORE_PATH is required"),
    EBO_AGENT_DEPLOYER_NAME: z.string().min(1, "EBO_AGENT_DEPLOYER_NAME is required"),
    STATE_FILE_PATH: z.string().min(1, "STATE_FILE_PATH is required").default("e2e-state.json"),
    BLOCK_NUMBER_BLOCKMETA_TOKEN: z
        .string()
        .min(1, "BLOCK_NUMBER_BLOCKMETA_TOKEN is at least 1 character")
        .optional(),
});

// Validate environment variables
const envValidation = envSchema.safeParse(process.env);

if (!envValidation.success) {
    console.error("Environment variable validation failed:", envValidation.error.format());
    process.exit(1);
}

export const env = envValidation.data;
export type E2EEnv = z.infer<typeof envSchema>;
