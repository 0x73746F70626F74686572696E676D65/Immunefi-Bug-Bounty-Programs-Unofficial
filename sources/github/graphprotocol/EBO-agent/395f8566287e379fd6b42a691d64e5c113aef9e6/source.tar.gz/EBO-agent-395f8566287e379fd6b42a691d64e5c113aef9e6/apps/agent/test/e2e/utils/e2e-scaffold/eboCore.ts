import assert from "assert";
import { Caip2ChainId } from "@ebo-agent/shared";
import { execa } from "execa";
import {
    Account,
    Address,
    Chain,
    createPublicClient,
    createTestClient,
    createWalletClient,
    encodeFunctionData,
    formatEther,
    Hex,
    http,
    HttpTransport,
    parseAbi,
    parseEther,
    publicActions,
    walletActions,
} from "viem";
import { generatePrivateKey, privateKeyToAccount } from "viem/accounts";

import { AnvilClient } from "./anvil.js";
import { BASE_ETH_AMOUNT } from "./index.js";

/**
 * Encode the function to transfer ERC20 GRT token to a specified `address`
 *
 * @param address token receiver's address
 * @returns the abi encoded transfer function
 */
function transferGrtToAccount(address: Address, amount: bigint) {
    return encodeFunctionData({
        abi: parseAbi(["function transfer(address, uint256)"]),
        args: [address, amount],
    });
}

/**
 * Fund an account with ETH.
 *
 * @param account account to fund
 * @param amount amount of ETH to fund `account` with
 * @param anvilClient wallet client for anvil to use to impersonate the account
 */
export async function fundAccountWithEth({
    account,
    anvilClient,
    amount,
}: {
    account: Address;
    anvilClient: AnvilClient<HttpTransport, Chain, Account | undefined>;
    amount: bigint;
}) {
    await anvilClient.setBalance({
        address: account,
        value: amount,
    });

    const balance = await anvilClient.getBalance({
        address: account,
    });

    assert.strictEqual(balance, amount, `Unexpected balance for ${account}`);

    console.log(`Added ${formatEther(amount)} ETH to ${account}.`);
}

/**
 * Fund `account` with `amount` GRT tokens by transferring from a known holder.
 *
 * @param account account to fund
 * @param anvilClient wallet client for anvil to use to impersonate the GRT holder
 * @param grt.fundAmount amount of GRT to fund `account` with
 * @param grt.holderAddress address of the GRT tokens holder
 * @param grt.contractAddress address of the GRT contract address
 *
 * Holder must have enough ETH balance to send the tokens.
 */
export async function fundAccountWithGrt(
    account: Account,
    anvilClient: AnvilClient<HttpTransport, Chain, Account | undefined>,
    grt: {
        fundAmount: bigint;
        holderAddress: Address;
        contractAddress: Address;
    },
) {
    await anvilClient.impersonateAccount({
        address: grt.holderAddress,
    });

    console.log(`Impersonating ${grt.holderAddress}...`);

    console.log(`Sending GRT tokens from ${grt.holderAddress} to ${account.address}...`);

    const hash = await anvilClient.sendTransaction({
        account: grt.holderAddress,
        to: grt.contractAddress,
        data: transferGrtToAccount(account.address, grt.fundAmount),
    });

    console.log("Waiting for transaction receipt...");

    await anvilClient.waitForTransactionReceipt({
        hash: hash,
        confirmations: 1,
    });

    console.log(`GRT tokens sent.`);

    await anvilClient.stopImpersonatingAccount({ address: grt.holderAddress });
}

interface SetUpAccountConfig {
    localRpcUrl: string;
    chain: Chain;
    deployedContracts: DeployContractsOutput;
    grtHolder: Address;
    grtContractAddress: Address;
    grtFundAmount: bigint;
}

export function restoreFromPrivateKey(privateKey: Hex, localRpcUrl: string, chain: Chain) {
    const account = privateKeyToAccount(privateKey);
    const localRpcTransport = http(localRpcUrl);

    const walletClient = createWalletClient({
        account,
        chain: chain,
        transport: localRpcTransport,
    });

    return {
        privateKey,
        account,
        walletClient,
    };
}
/**
 * Fund an account with ETH and GRT to interact with smart contracts. Also, issues
 * the respective approvals for modules to be allowed to operate.
 *
 * @param config {SetUpAccountConfig}
 * @returns the private key, the account and a wallet client for the set up account
 */
export async function setUpAccount(config: SetUpAccountConfig) {
    const { localRpcUrl, chain, grtHolder, grtContractAddress, grtFundAmount } = config;

    const privateKey = generatePrivateKey();
    const account = privateKeyToAccount(privateKey);
    const localRpcTransport = http(localRpcUrl);

    const publicClient = createPublicClient({
        chain: chain,
        transport: localRpcTransport,
    });

    const walletClient = createWalletClient({
        account,
        chain: chain,
        transport: localRpcTransport,
    });

    const anvilClient = createTestClient({
        mode: "anvil",
        account: grtHolder,
        chain: chain,
        transport: localRpcTransport,
    })
        .extend(publicActions)
        .extend(walletActions);

    await Promise.all([
        fundAccountWithEth({
            account: account.address,
            anvilClient,
            amount: parseEther(BASE_ETH_AMOUNT.toString()),
        }),
        fundAccountWithGrt(account, anvilClient, {
            holderAddress: grtHolder,
            contractAddress: grtContractAddress,
            fundAmount: grtFundAmount,
        }),
    ]);

    const balance = await publicClient.readContract({
        address: grtContractAddress,
        abi: parseAbi(["function balanceOf(address) returns (uint256)"]),
        functionName: "balanceOf",
        args: [account.address],
    });

    console.log(`GRT balance for ${account.address} is ${balance}.`);

    assert.strictEqual(
        balance,
        grtFundAmount,
        `Unexpected GRT balance in account ${account.address}`,
    );

    return {
        privateKey,
        account,
        walletClient,
    };
}

/**
 * Config params to deploy ebo core smart contracts in a local anvil instance.
 */
export interface DeployContractsConfig {
    // ebo-core repo's local path
    eboCorePath: string;
    // Deployer name
    deployerName: string;
    // Keystore password
    keystorePassword: string;
    // Anvil RPC URL
    rpcUrl: string;
}

export type DeployContractsOutput = {
    eboImplementation: Address;
    eboProxy: Address;
    horizonStaking: Address;
    epochManager: Address;
    grt: Address;
    council: Address;
    arbitrator: Address;
};

const DEPLOYED_CONTRACTS_REGEX =
    /^\s*(\w+(?:\s+\w+)*(?:\s+implementation)?(?:\s+proxy)?): (0x[a-fA-F0-9]{40})/gm;

const CONTRACT_NAME_MAP: Record<string, keyof DeployContractsOutput | undefined> = {
    "EBO implementation": "eboImplementation",
    "EBO proxy": "eboProxy",
    HorizonStaking: "horizonStaking",
    EpochManager: "epochManager",
    GRT: "grt",
    Council: "council",
    Arbitrator: "arbitrator",
};

/**
 * Deploy ebo-core contracts into a local anvil instance.
 *
 * @param config {DeployContractsConfig}
 * @returns a map of contract names with their corresponding addresses
 */
export async function deployEboContracts(
    config: DeployContractsConfig,
): Promise<DeployContractsOutput> {
    const { keystorePassword, eboCorePath, rpcUrl, deployerName } = config;

    console.log("Deploying smart contracts...");

    // TODO: cast wallet import...

    const { stdout } = await execa(
        "bash",
        [
            "-c",
            `source .env && forge script DeployArbitrumSepolia --rpc-url $RPC_URL --account $ARBITRUM_SEPOLIA_DEPLOYER_NAME --broadcast --chain-id 421614 -vvvvv --password $KEYSTORE_PASSWORD`,
        ],
        {
            cwd: eboCorePath,
            env: {
                ARBITRUM_SEPOLIA_DEPLOYER_NAME: deployerName,
                KEYSTORE_PASSWORD: keystorePassword,
                ARBISCAN_API_KEY: "",
                RPC_URL: rpcUrl,
            },
        },
    );

    const deployedContractsMatches = stdout.matchAll(DEPLOYED_CONTRACTS_REGEX);

    const contracts = [...deployedContractsMatches].reduce((addresses, contractAddress) => {
        const originalName = contractAddress[1] ?? "";
        const address = contractAddress[2] as Address;

        // Only add contracts that we have defined mappings for
        const mappedName = CONTRACT_NAME_MAP[originalName];
        if (mappedName) {
            return { ...addresses, [mappedName]: address };
        }

        return addresses;
    }, {} as Partial<DeployContractsOutput>);

    // Ensure all required contracts are found
    const missingContracts = Object.keys(CONTRACT_NAME_MAP)
        .map((key) => CONTRACT_NAME_MAP[key])
        .filter((name) => name && !contracts[name]);

    if (missingContracts.length > 0) {
        throw new Error(`Missing required contracts: ${missingContracts.join(", ")}`);
    }

    console.dir(contracts, { depth: null });

    return contracts as DeployContractsOutput;
}

export async function stakeGrtWithProvision(
    accounts: Account[],
    addresses: {
        grt: Address;
        horizonStaking: Address;
        verifier: Address;
    },
    grtProvisionAmount: bigint,
    anvilClient: AnvilClient<HttpTransport, Chain, Account | undefined>,
) {
    console.log("Staking GRT into Horizon...");

    const { grt, horizonStaking, verifier } = addresses;

    for (const account of accounts) {
        // 1. First approve GRT spending
        console.log(`Approving GRT spending for ${account.address}`);

        const approveHash = await anvilClient.sendTransaction({
            account: account,
            to: grt,
            data: encodeFunctionData({
                abi: parseAbi(["function approve(address spender, uint256 amount)"]),
                args: [horizonStaking, grtProvisionAmount],
            }),
        });

        await anvilClient.waitForTransactionReceipt({
            hash: approveHash,
            confirmations: 1,
        });

        // 2. Verify GRT allowance
        const allowance = await anvilClient.readContract({
            address: grt,
            abi: parseAbi(["function allowance(address,address) view returns (uint256)"]),
            functionName: "allowance",
            args: [account.address, horizonStaking],
        });

        assert.strictEqual(
            allowance,
            grtProvisionAmount,
            `Unexpected GRT allowance for ${account.address}`,
        );
        console.log(`GRT allowance for staking: ${allowance}`);

        // 3. Stake GRT tokens
        console.log("Staking GRT...");
        console.log(grtProvisionAmount, "grtProvisionAmount");

        const stakeHash = await anvilClient.sendTransaction({
            account: account,
            to: horizonStaking,
            data: encodeFunctionData({
                abi: parseAbi(["function stake(uint256 tokens)"]),
                args: [grtProvisionAmount],
            }),
        });

        await anvilClient.waitForTransactionReceipt({
            hash: stakeHash,
            confirmations: 1,
        });

        // 4. Mine a block to update state
        await anvilClient.mine({ blocks: 1 });

        // 5. Now check staked amount
        const stakedAmount = await anvilClient.readContract({
            address: horizonStaking,
            abi: parseAbi([
                "function getStake(address serviceProvider) external view returns (uint256)",
            ]),
            functionName: "getStake",
            args: [account.address],
        });

        assert.strictEqual(
            stakedAmount,
            grtProvisionAmount,
            `Unexpected staked amount for ${account.address}`,
        );
        console.log(`Staked amount: ${stakedAmount}`);

        // 6. Provision GRT tokens
        console.log("Provisioning GRT...");

        const provisionHash = await anvilClient.sendTransaction({
            account: account,
            to: horizonStaking,
            data: encodeFunctionData({
                abi: parseAbi([
                    "function provision(address serviceProvider, address verifier, uint256 tokens, uint32 maxVerifierCut, uint64 thawingPeriod)",
                ]),
                args: [
                    account.address,
                    verifier,
                    grtProvisionAmount,
                    1_000_000,
                    BigInt(60 * 60 * 24 * 15), // 15 days in seconds
                ],
            }),
        });

        await anvilClient.waitForTransactionReceipt({
            hash: provisionHash,
            confirmations: 1,
        });

        console.log(`Stake and provision done for ${account.address}`);
    }
}

/**
 * Add indexed chains to EBO.
 *
 * @param chainsToAdd array of Caip2 compliant ids
 * @param deployedContracts {@link DeployContractsOutput}
 * @param client anvil client
 */
export async function addEboChains(
    chainsToAdd: Caip2ChainId[],
    deployedContracts: DeployContractsOutput,
    client: AnvilClient<HttpTransport, Chain, Account | undefined>,
) {
    await client.impersonateAccount({
        address: deployedContracts.council,
    });

    await client.setBalance({
        address: deployedContracts.council,
        value: parseEther("1"),
    });

    console.log(`Adding ${chainsToAdd.join(", ")} to EBO...`);

    const addChainTxHash = await client.sendTransaction({
        account: deployedContracts.council,
        from: deployedContracts.council,
        to: deployedContracts.eboProxy,
        data: encodeFunctionData({
            abi: parseAbi(["function addChainIds(string[] calldata _chainId)"]),
            args: [chainsToAdd],
            functionName: "addChainIds",
        }),
    });

    await client.waitForTransactionReceipt({
        hash: addChainTxHash,
        confirmations: 1,
    });

    console.log(`${chainsToAdd.join(", ")} added.`);

    await client.stopImpersonatingAccount({ address: deployedContracts.council });
}
