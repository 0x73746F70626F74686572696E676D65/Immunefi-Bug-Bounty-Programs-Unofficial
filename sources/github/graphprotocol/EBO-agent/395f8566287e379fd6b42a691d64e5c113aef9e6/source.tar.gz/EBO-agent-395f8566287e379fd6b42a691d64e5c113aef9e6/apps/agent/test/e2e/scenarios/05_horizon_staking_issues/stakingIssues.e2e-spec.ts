import { ChildProcessWithoutNullStreams } from "child_process";
import { existsSync } from "fs";
import path from "path";
import {
    eboAbi,
    NotificationServiceFactory,
    ProposalId,
    ProposalStatus,
    ProtocolProviderV2,
} from "@ebo-agent/automated-dispute";
import { BlockNumberService } from "@ebo-agent/blocknumber";
import { Caip2ChainId, Logger, NotificationService } from "@ebo-agent/shared";
import { Address, getAbiItem, parseEther } from "viem";
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

import {
    AnvilTestEnvironment,
    ARBITRUM_SEPOLIA_ID_HASH,
    BASE_GRT_AMOUNT,
    E2E_SCENARIO_SETUP_TIMEOUT,
    E2E_TEST_TIMEOUT,
    fundAccountWithGrt,
    GRT_HOLDER,
    killAgent,
    PROTOCOL_L2_CHAIN_ID,
    setupAnvilTestEnvironment,
    spawnAgent,
    stakeGrtWithProvision,
    waitForEvent,
} from "../../utils/e2e-scaffold/index.js";

interface RpcConfig {
    chainId: Caip2ChainId;
    urls: string[];
    transactionReceiptConfirmations: number;
    timeout: number;
    retryInterval: number;
}

describe.sequential("Horizon Staking Issues", () => {
    const tmpConfigDir = path.join(__dirname, "/tmp");
    const tmpConfigFile = path.join(tmpConfigDir, "/config.yml");

    let agent: ChildProcessWithoutNullStreams | undefined;
    let testEnv: AnvilTestEnvironment;

    let protocolProvider: ProtocolProviderV2; // Agent's provider
    let blockNumberService: BlockNumberService;

    const notifier: NotificationService = NotificationServiceFactory.create(Logger.getInstance());
    const logger = Logger.getInstance();

    let baseProviderConfig: {
        l1: RpcConfig;
        l2: RpcConfig;
    };

    let contractAddresses: {
        epochManager: Address;
        ebo: Address;
    };
    beforeAll(async () => {
        testEnv = await setupAnvilTestEnvironment(__dirname);
    }, E2E_SCENARIO_SETUP_TIMEOUT);

    afterAll(async () => {
        await testEnv.cleanup();
    });

    beforeEach(async () => {
        blockNumberService = new BlockNumberService(
            new Map<Caip2ChainId, string[]>([[PROTOCOL_L2_CHAIN_ID, [testEnv.localUrl]]]),
            {
                baseUrl: new URL("http://not.needed/"),
                bearerToken: "not.needed",
                bearerTokenExpirationWindow: 1000,
                servicePaths: {
                    block: "/block",
                    blockByTime: "/blockByTime",
                },
            },
            logger,
            notifier,
        );

        baseProviderConfig = {
            l1: {
                chainId: PROTOCOL_L2_CHAIN_ID as Caip2ChainId,
                urls: [testEnv.localUrl],
                transactionReceiptConfirmations: 1,
                timeout: 1_000,
                retryInterval: 500,
            },
            l2: {
                chainId: PROTOCOL_L2_CHAIN_ID as Caip2ChainId,
                urls: [testEnv.localUrl],
                transactionReceiptConfirmations: 1,
                timeout: 1_000,
                retryInterval: 500,
            },
        };

        contractAddresses = {
            epochManager: testEnv.protocolContracts.epochManager,
            ebo: testEnv.protocolContracts.eboProxy,
        };
    });

    afterEach(async () => {
        await testEnv.anvilClient.revert({ id: testEnv.snapshotId });

        if (existsSync(tmpConfigFile) && agent) {
            await killAgent({
                process: agent,
                configPath: tmpConfigFile,
            });
            agent = undefined; // Reset agent variable
        }
    });

    it(
        "fails to propose without stake, succeeds after staking",
        { timeout: E2E_TEST_TIMEOUT },
        async () => {
            const { anvilClient, protocolContracts, withoutStakeAccounts } = testEnv;

            const agentAccount = withoutStakeAccounts[0];

            // Check if accounts and keys exist
            if (
                !withoutStakeAccounts ||
                withoutStakeAccounts.length < 1 ||
                !agentAccount?.privateKey
            ) {
                throw new Error("Required test accounts not found or missing private keys.");
            }

            // Provider for the agent
            protocolProvider = new ProtocolProviderV2(
                baseProviderConfig,
                contractAddresses,
                agentAccount.privateKey,
                logger,
                blockNumberService,
            );

            const initBlock = await anvilClient.getBlockNumber();
            const currentEpoch = await protocolProvider.read.getCurrentEpoch();

            // Spawn the agent
            agent = spawnAgent({
                configPath: tmpConfigFile,
                config: {
                    protocolProvider: {
                        contracts: {
                            ebo: protocolContracts.eboProxy,
                            epochManager: protocolContracts.epochManager,
                        },
                        rpcsConfig: {
                            l1: {
                                chainId: PROTOCOL_L2_CHAIN_ID,
                                transactionReceiptConfirmations: 1,
                                timeout: 1_000,
                                retryInterval: 500,
                            },
                            l2: {
                                chainId: PROTOCOL_L2_CHAIN_ID,
                                transactionReceiptConfirmations: 1,
                                timeout: 1_000,
                                retryInterval: 500,
                            },
                        },
                    },
                    blockNumberService: {
                        blockmetaConfig: {
                            baseUrl: new URL("http://not.needed/"),
                            bearerTokenExpirationWindow: 1000,
                            servicePaths: {
                                block: "/block",
                                blockByTime: "/blockByTime",
                            },
                        },
                    },
                    processor: {
                        // Check frequently to react quickly in the test
                        msBetweenChecks: 1000,
                    },
                },
                env: {
                    PROTOCOL_PROVIDER_PRIVATE_KEY: agentAccount.privateKey,
                    PROTOCOL_PROVIDER_L1_RPC_URLS: [testEnv.localUrl],
                    PROTOCOL_PROVIDER_L2_RPC_URLS: [testEnv.localUrl],
                    BLOCK_NUMBER_BLOCKMETA_TOKEN: "not.needed",
                    BLOCK_NUMBER_RPC_URLS_MAP: new Map<Caip2ChainId, string[]>([
                        [PROTOCOL_L2_CHAIN_ID, [testEnv.localUrl]],
                    ]),
                },
            });

            let agentErrorOutput = "";
            agent.stderr.on("data", (data) => {
                agentErrorOutput += data.toString();
            });

            const fromBlock = initBlock;

            // 1. Wait for reading a proposal failure creation on the agent output
            await vi.waitFor(
                () =>
                    expect(agentErrorOutput).toContain(
                        `Failed to create proposal for chain ${PROTOCOL_L2_CHAIN_ID} and epoch ${currentEpoch.number}`,
                    ),
                { timeout: 20000 },
            );

            // 2. Fund the agent account with GRT
            const grtFundAmount = parseEther((BASE_GRT_AMOUNT * 3n).toString());
            await fundAccountWithGrt(agentAccount.account, anvilClient, {
                holderAddress: GRT_HOLDER,
                contractAddress: protocolContracts.grt,
                fundAmount: grtFundAmount,
            });

            // 3. Stake the GRT
            await stakeGrtWithProvision(
                [agentAccount.account],
                {
                    grt: protocolContracts.grt,
                    horizonStaking: protocolContracts.horizonStaking,
                    verifier: protocolContracts.eboProxy,
                },
                grtFundAmount,
                anvilClient,
            );

            //4. Wait for the ProposalCreated event
            const proposalCreatedEvent = await waitForEvent({
                client: anvilClient,
                filter: {
                    address: protocolContracts.eboProxy,
                    fromBlock,
                    event: getAbiItem({ abi: eboAbi, name: "ProposalCreated" }),
                    strict: true,
                },
                matcher: (log) => {
                    return (
                        log.args._serviceProvider === agentAccount.account.address &&
                        log.args._epoch === currentEpoch.number &&
                        log.args._chainId === ARBITRUM_SEPOLIA_ID_HASH
                    );
                },
                pollingIntervalMs: 100,
                blockTimeout: fromBlock + 1000n,
            });
            expect(proposalCreatedEvent).toBeDefined();

            expect(agentErrorOutput).toContain(`BondManager_Bond_`);
        },
    );

    it(
        "creates a proposal, adversarial disputes it but agent doesn't have enough stake for pledging and loses the dispute",
        { timeout: E2E_TEST_TIMEOUT },
        async () => {
            const { anvilClient, protocolContracts, withoutStakeAccounts, withStakeAccounts } =
                testEnv;

            const agentAccount = withoutStakeAccounts[0];
            const adversarialAccount = withStakeAccounts[0];

            if (
                !agentAccount?.privateKey ||
                !adversarialAccount?.privateKey ||
                !agentAccount?.account ||
                !adversarialAccount?.account
            ) {
                throw new Error("Required test accounts not found or missing private keys.");
            }

            // Provider for the agent
            protocolProvider = new ProtocolProviderV2(
                baseProviderConfig,
                contractAddresses,
                agentAccount.privateKey,
                logger,
                blockNumberService,
            );

            const adversarialProvider = new ProtocolProviderV2(
                baseProviderConfig,
                contractAddresses,
                adversarialAccount.privateKey,
                logger,
                blockNumberService,
            );

            const snapshotParameters = await protocolProvider.getSnapshotParameters(1n);
            const minimumStake = snapshotParameters!.proposalBondSize;

            // 1. Fund the agent account with minimum stake for a proposal
            const grtFundAmount = minimumStake;
            await fundAccountWithGrt(agentAccount.account, anvilClient, {
                holderAddress: GRT_HOLDER,
                contractAddress: protocolContracts.grt,
                fundAmount: grtFundAmount,
            });

            // 2. Stake the GRT
            await stakeGrtWithProvision(
                [agentAccount.account],
                {
                    grt: protocolContracts.grt,
                    horizonStaking: protocolContracts.horizonStaking,
                    verifier: protocolContracts.eboProxy,
                },
                grtFundAmount,
                anvilClient,
            );

            const initBlock = await anvilClient.getBlockNumber();
            const currentEpoch = await protocolProvider.read.getCurrentEpoch();

            // Spawn the agent
            agent = spawnAgent({
                configPath: tmpConfigFile,
                config: {
                    protocolProvider: {
                        contracts: contractAddresses,
                        rpcsConfig: baseProviderConfig,
                    },
                    blockNumberService: {
                        blockmetaConfig: {
                            baseUrl: new URL("http://not.needed/"),
                            servicePaths: {
                                block: "/block",
                                blockByTime: "/blockByTime",
                            },
                            bearerTokenExpirationWindow: 1000,
                        },
                    },
                    processor: {
                        msBetweenChecks: 1000,
                    },
                },
                env: {
                    PROTOCOL_PROVIDER_PRIVATE_KEY: agentAccount.privateKey,
                    PROTOCOL_PROVIDER_L1_RPC_URLS: [testEnv.localUrl],
                    PROTOCOL_PROVIDER_L2_RPC_URLS: [testEnv.localUrl],
                    BLOCK_NUMBER_BLOCKMETA_TOKEN: "not.needed",
                    BLOCK_NUMBER_RPC_URLS_MAP: new Map<Caip2ChainId, string[]>([
                        [PROTOCOL_L2_CHAIN_ID, [testEnv.localUrl]],
                    ]),
                },
            });

            let agentErrorOutput = "";
            agent.stderr.on("data", (data) => {
                agentErrorOutput += data.toString();
            });

            // 3. Wait for the agent to create a proposal
            const proposalCreatedEvent = await waitForEvent({
                client: anvilClient,
                filter: {
                    address: protocolContracts.eboProxy,
                    fromBlock: initBlock,
                    event: getAbiItem({ abi: eboAbi, name: "ProposalCreated" }),
                    strict: true,
                },
                matcher: (log) => {
                    return (
                        log.args._serviceProvider === agentAccount.account.address &&
                        log.args._epoch === currentEpoch.number &&
                        log.args._chainId === ARBITRUM_SEPOLIA_ID_HASH
                    );
                },
                pollingIntervalMs: 100,
                blockTimeout: initBlock + 1000n,
            });
            expect(proposalCreatedEvent).toBeDefined();

            const proposalId = proposalCreatedEvent!.args._proposalId as ProposalId;

            // 4. Adversarial disputes and pledgesForDispute the proposal
            await adversarialProvider.write.dispute(proposalId, adversarialAccount.account.address);
            await adversarialProvider.write.pledgeForDispute(
                proposalId,
                adversarialAccount.account.address,
            );

            // 5. Wait for agent trying to dispute the proposal but failing to do so due to stake
            await vi.waitFor(
                () =>
                    expect(agentErrorOutput).toContain(
                        "BondManager_Bond_InsufficientNonThawingTokens",
                    ),
                {
                    timeout: 20000,
                },
            );

            // 4. Advance time past the dispute window
            await anvilClient.increaseTime({
                seconds: Math.floor(
                    (Number(snapshotParameters!.pledgeWindow) +
                        Number(snapshotParameters!.pledgeRefreshWindow)) *
                        1.2,
                ),
            });
            await anvilClient.mine({ blocks: 1 });

            // 6. Agent should resolve the dispute and lose it
            const disputeResolvedEvent = await waitForEvent({
                client: anvilClient,
                filter: {
                    address: protocolContracts.eboProxy,
                    fromBlock: proposalCreatedEvent!.blockNumber,
                    event: getAbiItem({ abi: eboAbi, name: "DisputeResolved" }),
                    strict: true,
                },
                matcher: (log) => {
                    return (
                        log.args._proposalId === proposalId &&
                        log.args._resolutionStatus === ProposalStatus.DisputerWon
                    );
                },
                pollingIntervalMs: 100,
                blockTimeout: proposalCreatedEvent!.blockNumber + 1000n,
            });
            expect(disputeResolvedEvent).toBeDefined();
        },
    );
});
