import { inspect } from "util";
import { isNativeError } from "util/types";
import {
    EboActorsManagerV2,
    EboParametersRegistry,
    EboProcessorV2,
    NotificationServiceFactory,
    ProtocolProviderV2,
} from "@ebo-agent/automated-dispute";
import { BlockNumberService } from "@ebo-agent/blocknumber";
import { Logger, NotificationService, stringify } from "@ebo-agent/shared";

import { config } from "./config/index.js";

const logger = Logger.getInstance();

const main = async (): Promise<void> => {
    logger.debug("Initializing agent V2...");

    logger.debug("Initializing notification service...");

    const notifier: NotificationService = NotificationServiceFactory.create(logger);

    logger.debug("Initialized notification service.");

    logger.debug("Initializing block number service...");

    logger.debug(stringify(config.blockNumberService));

    const blockNumberService = new BlockNumberService(
        config.blockNumberService.chainRpcUrls,
        config.blockNumberService.blockmetaConfig,
        logger,
        notifier,
    );

    logger.debug("Block number service initialized.");

    logger.debug("Initializing protocol provider...");
    logger.debug(stringify(config.protocolProvider));

    const protocolProvider = new ProtocolProviderV2(
        config.protocolProvider.rpcsConfig,
        config.protocolProvider.contracts,
        config.protocolProvider.privateKey,
        logger,
        blockNumberService,
    );

    logger.debug("Protocol provider initialized.");

    const actorsManager = new EboActorsManagerV2();
    const parametersRegistry = new EboParametersRegistry(protocolProvider, logger);

    logger.debug("Initializing EBO processor...");
    logger.debug(stringify(config.processor));

    const processor = new EboProcessorV2(
        protocolProvider,
        blockNumberService,
        actorsManager,
        parametersRegistry,
        logger,
        notifier,
    );

    logger.debug("EBO processor initialized.");
    logger.debug("Starting processing...");

    await processor.start(config.processor.msBetweenChecks);
};

process.on("unhandledRejection", (reason, p) => {
    logger.error(`Unhandled Rejection at: \n${inspect(p, undefined, 100)}, \nreason: ${reason}`);

    process.exit(1);
});

process.on("uncaughtException", (error: Error) => {
    logger.error(`An uncaught exception occurred: ${error}\n` + `Exception origin: ${error.stack}`);

    process.exit(1);
});

main().catch((err) => {
    logger.error(`Main handler failure.`);

    if (isNativeError(err)) {
        logger.error(`${err.stack}`);
        logger.error(`${err.message}`);
    } else {
        logger.error(err);
    }

    process.exit(1);
});
