package gateway

import (
	"context"
	"fmt"
	"math/big"

	"connectrpc.com/connect"
	providerv1 "github.com/graphprotocol/substreams-data-service/pb/graph/substreams/data_service/provider/v1"
	"github.com/graphprotocol/substreams-data-service/sidecar"
	"go.uber.org/zap"
)

// SubmitRAV submits a signed RAV to the provider gateway.
// Deprecated for provider-managed runtime sessions: live provider-issued
// rav_request messages must be answered on the bound PaymentSession stream.
// This unary surface remains only for legacy/manual non-runtime flows.
func (s *Gateway) SubmitRAV(
	ctx context.Context,
	req *connect.Request[providerv1.SubmitRAVRequest],
) (*connect.Response[providerv1.SubmitRAVResponse], error) {
	sessionID := req.Msg.SessionId

	s.logger.Info("SubmitRAV called",
		zap.String("session_id", sessionID),
	)

	// Get the session from GlobalRepository
	session, err := s.repo.SessionGet(ctx, sessionID)
	if err != nil {
		s.logger.Warn("session not found", zap.String("session_id", sessionID))
		return connect.NewResponse(&providerv1.SubmitRAVResponse{
			Accepted:        false,
			RejectionReason: "session not found",
			ShouldContinue:  false,
		}), nil
	}

	// Check session is active
	if !session.IsActive() {
		return connect.NewResponse(&providerv1.SubmitRAVResponse{
			Accepted:        false,
			RejectionReason: "session is not active",
			ShouldContinue:  false,
		}), nil
	}
	if s.runtime.hasPendingRAV(sessionID) {
		return connect.NewResponse(&providerv1.SubmitRAVResponse{
			Accepted:        false,
			RejectionReason: "SubmitRAV is deprecated for provider-managed runtime requests; respond on the bound PaymentSession stream",
			ShouldContinue:  true,
		}), nil
	}

	// Convert and validate the RAV
	if req.Msg.SignedRav == nil {
		return connect.NewResponse(&providerv1.SubmitRAVResponse{
			Accepted:        false,
			RejectionReason: "invalid or missing RAV",
			ShouldContinue:  true,
		}), nil
	}
	signedRAV, err := sidecar.ProtoSignedRAVToHorizon(req.Msg.SignedRav)
	if err != nil {
		return nil, connect.NewError(connect.CodeInvalidArgument, fmt.Errorf("invalid <signed_rav>: %w", err))
	}

	// Verify signature
	signerAddr, err := signedRAV.RecoverSigner(s.domain)
	if err != nil {
		s.logger.Warn("failed to verify RAV signature", zap.Error(err))
		return connect.NewResponse(&providerv1.SubmitRAVResponse{
			Accepted:        false,
			RejectionReason: fmt.Sprintf("signature verification failed: %v", err),
			ShouldContinue:  true,
		}), nil
	}

	// Check if signer is authorized
	isAuthorized, err := s.isSignerAuthorized(ctx, session.Payer, signerAddr)
	if err != nil {
		s.logger.Warn("authorization check failed", zap.Error(err))
		return connect.NewResponse(&providerv1.SubmitRAVResponse{
			Accepted:        false,
			RejectionReason: fmt.Sprintf("authorization check failed: %v", err),
			ShouldContinue:  false,
		}), nil
	}
	if !isAuthorized {
		s.logger.Warn("RAV signer not authorized",
			zap.Stringer("signer", signerAddr),
		)
		return connect.NewResponse(&providerv1.SubmitRAVResponse{
			Accepted:        false,
			RejectionReason: fmt.Sprintf("signer %s is not authorized", signerAddr.Pretty()),
			ShouldContinue:  false,
		}), nil
	}

	// Verify RAV is for the correct session participants
	if !sidecar.AddressesEqual(signedRAV.Message.Payer, session.Payer) {
		return connect.NewResponse(&providerv1.SubmitRAVResponse{
			Accepted:        false,
			RejectionReason: "RAV payer does not match session",
			ShouldContinue:  true,
		}), nil
	}
	if !sidecar.AddressesEqual(signedRAV.Message.ServiceProvider, s.serviceProvider) {
		return connect.NewResponse(&providerv1.SubmitRAVResponse{
			Accepted:        false,
			RejectionReason: "RAV service provider does not match",
			ShouldContinue:  true,
		}), nil
	}

	// Verify RAV value is greater than or equal to previous RAV
	currentRAV := session.CurrentRAV
	if currentRAV != nil && currentRAV.Message != nil {
		if signedRAV.Message.ValueAggregate.Cmp(currentRAV.Message.ValueAggregate) < 0 {
			return connect.NewResponse(&providerv1.SubmitRAVResponse{
				Accepted:        false,
				RejectionReason: "RAV value is less than current RAV",
				ShouldContinue:  true,
			}), nil
		}
	}

	// Enforce that the submitted RAV covers the server-computed usage since baseline.
	// Do not trust caller-provided Usage.cost.
	currentValue := big.NewInt(0)
	if currentRAV != nil && currentRAV.Message != nil && currentRAV.Message.ValueAggregate != nil {
		currentValue = currentRAV.Message.ValueAggregate
	}
	_, _, _, deltaCost := session.UsageDeltaSinceBaseline()
	minValue := new(big.Int).Add(currentValue, deltaCost)
	if signedRAV.Message.ValueAggregate.Cmp(minValue) < 0 {
		return connect.NewResponse(&providerv1.SubmitRAVResponse{
			Accepted:        false,
			RejectionReason: fmt.Sprintf("RAV underpays usage: want >= %s (current %s + delta %s)", minValue.String(), currentValue.String(), deltaCost.String()),
			ShouldContinue:  false,
		}), nil
	}

	baselineBlocks := session.BlocksProcessed
	baselineBytes := session.BytesTransferred
	baselineReqs := session.Requests
	baselineCost := big.NewInt(0)
	if session.TotalCost != nil {
		baselineCost = new(big.Int).Set(session.TotalCost)
	}

	// Update only the accepted RAV and the matching baseline in the repository.
	if err := s.repo.SessionUpdateRAVAndBaseline(ctx, sessionID, signedRAV, baselineBlocks, baselineBytes, baselineReqs, baselineCost); err != nil {
		s.logger.Warn("failed to update session", zap.String("session_id", sessionID), zap.Error(err))
	}

	s.logger.Info("SubmitRAV accepted",
		zap.String("session_id", sessionID),
		zap.Stringer("signer", signerAddr),
		zap.Stringer("value", signedRAV.Message.ValueAggregate),
	)

	response := &providerv1.SubmitRAVResponse{
		Accepted:       true,
		ShouldContinue: true,
	}

	return connect.NewResponse(response), nil
}
