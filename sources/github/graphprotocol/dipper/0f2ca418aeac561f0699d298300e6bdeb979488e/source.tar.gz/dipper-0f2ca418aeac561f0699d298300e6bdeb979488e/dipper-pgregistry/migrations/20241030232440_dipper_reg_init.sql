-- Table: dipper_reg_indexing_requests
CREATE TABLE dipper_reg_indexing_requests
(
    id            UUID PRIMARY KEY,
    created_at    TIMESTAMPTZ NOT NULL,
    updated_at    TIMESTAMPTZ NOT NULL,

    status        INT         NOT NULL,
    requested_by  BYTEA NOT NULL,
    deployment_id       TEXT  NOT NULL,
    deployment_chain_id BYTEA NOT NULL
);

-- Table: dipper_reg_indexing_agreements
CREATE TABLE dipper_reg_indexing_agreements
(
    id                  UUID PRIMARY KEY,
    created_at          TIMESTAMPTZ NOT NULL,
    updated_at          TIMESTAMPTZ NOT NULL,

    status            INT  NOT NULL,
    indexing_request_id UUID REFERENCES dipper_reg_indexing_requests (id),
    deployment_id     TEXT NOT NULL,
    accepted_at_epoch BIGINT,

    -- Indexer information
    indexer_id          BYTEA       NOT NULL,
    indexer_url         TEXT        NOT NULL,

    -- Voucher
    voucher JSON NOT NULL
);

-- Table: dipper_reg_indexing_receipts
CREATE TABLE dipper_reg_indexing_receipts
(
    id                    UUID PRIMARY KEY,
    created_at            TIMESTAMPTZ NOT NULL,
    updated_at            TIMESTAMPTZ NOT NULL,

    indexing_agreement_id UUID REFERENCES dipper_reg_indexing_agreements (id),
    indexer_id             BYTEA   NOT NULL,
    indexer_operator_id    BYTEA   NOT NULL,

    -- Report information
    reported_work_epoch BIGINT NOT NULL,
    reported_work_allocation_id BYTEA NOT NULL,
    reported_work_entity_count BYTEA  NOT NULL,
    reported_work_poi   BYTEA  NOT NULL,

    amount              BYTEA  NOT NULL
);
