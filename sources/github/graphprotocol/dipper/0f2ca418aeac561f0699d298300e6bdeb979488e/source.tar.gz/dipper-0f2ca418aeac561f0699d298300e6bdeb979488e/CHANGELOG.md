# Changelog

## [0.2.1](https://github.com/graphprotocol/dipper/compare/v0.2.0...v0.2.1) (2026-10-01)


### Fixed

* **escrow:** release escrow held by agreements that have ended ([#703](https://github.com/graphprotocol/dipper/issues/703)) ([37c980d](https://github.com/graphprotocol/dipper/commit/37c980d732e657e4677738277dc3d2498a6d9b1c))
* **escrow:** send reconciles only where the escrow needs one ([#702](https://github.com/graphprotocol/dipper/issues/702)) ([9300302](https://github.com/graphprotocol/dipper/commit/930030212de2cf6a7cd8d111043898cd8c66601d))
* **escrow:** wait for reconcile transactions to be mined ([#701](https://github.com/graphprotocol/dipper/issues/701)) ([3400d51](https://github.com/graphprotocol/dipper/commit/3400d51bea76593c65fe9430e08bbb76ed3a9337))


### Changed

* **ci:** fail the build on dead code and unused dependencies ([#705](https://github.com/graphprotocol/dipper/issues/705)) ([837090d](https://github.com/graphprotocol/dipper/commit/837090dffe92d00c0797b5c4c7ae5537f3f7d368))

## [0.2.0](https://github.com/graphprotocol/dipper/compare/v0.1.12...v0.2.0) (2026-10-01)


### ⚠ BREAKING CHANGES

* **cli:** detect the chain from the subgraph manifest ([#699](https://github.com/graphprotocol/dipper/issues/699))

### Added

* **cli:** detect the chain from the subgraph manifest ([#699](https://github.com/graphprotocol/dipper/issues/699)) ([bd61524](https://github.com/graphprotocol/dipper/commit/bd6152480e143a96073b9379619c60962be9aadf))


### Fixed

* send agreement proposals to https indexers over TLS ([#698](https://github.com/graphprotocol/dipper/issues/698)) ([2b5f751](https://github.com/graphprotocol/dipper/commit/2b5f7510f83c4452083442055e9ded0eb161a6d2))

## [0.1.12](https://github.com/graphprotocol/dipper/compare/v0.1.11...v0.1.12) (2026-09-17)


### Fixed

* **ci:** publish container images under the graphprotocol organisation ([#696](https://github.com/graphprotocol/dipper/issues/696)) ([87f7c12](https://github.com/graphprotocol/dipper/commit/87f7c12a11e878fafd8c69c226c6e8d49973e6fc))

## [0.1.11](https://github.com/graphprotocol/dipper/compare/v0.1.10...v0.1.11) (2026-09-17)


### Fixed

* **worker:** let a chain submission try every RPC provider in one job ([#695](https://github.com/graphprotocol/dipper/issues/695)) ([f40a71f](https://github.com/graphprotocol/dipper/commit/f40a71ff52e78d37ffa57fe19a9d88b28b8ada1d))


### Documentation

* rewrite the README around the agreement lifecycle ([#688](https://github.com/graphprotocol/dipper/issues/688)) ([38f86ae](https://github.com/graphprotocol/dipper/commit/38f86ae44b9067877f121fdf7c86e9f03fb316b1))

## [0.1.10](https://github.com/edgeandnode/dipper/compare/v0.1.9...v0.1.10) (2026-08-03)


### Fixed

* **worker:** size offer retries from the indexer's acceptance window ([#686](https://github.com/edgeandnode/dipper/issues/686)) ([7803ce7](https://github.com/edgeandnode/dipper/commit/7803ce714c1653910c936d41f46095d1da251596))

## [0.1.9](https://github.com/edgeandnode/dipper/compare/v0.1.8...v0.1.9) (2026-07-30)


### Fixed

* retry transaction sends across every RPC provider ([#683](https://github.com/edgeandnode/dipper/issues/683)) ([da9de2f](https://github.com/edgeandnode/dipper/commit/da9de2f33ea219360804011db83cfd277d83a21b))
* stop benching indexers for offers we never landed ([#684](https://github.com/edgeandnode/dipper/issues/684)) ([26272f5](https://github.com/edgeandnode/dipper/commit/26272f5a24a5d046543d648e7bb08f97c8f068a9))

## [0.1.8](https://github.com/edgeandnode/dipper/compare/v0.1.7...v0.1.8) (2026-07-23)


### Added

* report worker liveness on an HTTP health endpoint ([#680](https://github.com/edgeandnode/dipper/issues/680)) ([450c36d](https://github.com/edgeandnode/dipper/commit/450c36dd1feba96bd7ce5b1a5c1fda7ca8439f9d))
* restart the process when a critical background task dies ([#678](https://github.com/edgeandnode/dipper/issues/678)) ([432b567](https://github.com/edgeandnode/dipper/commit/432b567b7aed591e4613dc583f582f8cbb4cfa58))
* stream indexing agreement lifecycle events to Kafka ([#675](https://github.com/edgeandnode/dipper/issues/675)) ([c0db997](https://github.com/edgeandnode/dipper/commit/c0db9978e6345da38c8365af656ee253d620dad3))


### Fixed

* **config:** reject unknown keys so config typos fail at startup ([#682](https://github.com/edgeandnode/dipper/issues/682)) ([0c800e2](https://github.com/edgeandnode/dipper/commit/0c800e265adc86dbc7f8351271f5c54dcdac114c))
* keep processing jobs when the notification listener fails ([#677](https://github.com/edgeandnode/dipper/issues/677)) ([0fbc686](https://github.com/edgeandnode/dipper/commit/0fbc6866a42ecdbacaf30dcf79bdfe42c6296939))
* reschedule background jobs stuck past a 300 second timeout ([#681](https://github.com/edgeandnode/dipper/issues/681)) ([3c20be6](https://github.com/edgeandnode/dipper/commit/3c20be670417504faa196605696043daa29deaca))
* wind down the signing domain refresh on shutdown ([#679](https://github.com/edgeandnode/dipper/issues/679)) ([81f0d12](https://github.com/edgeandnode/dipper/commit/81f0d124c3d186227babe2dc472064a3c4f50df1))

## [0.1.7](https://github.com/edgeandnode/dipper/compare/v0.1.6...v0.1.7) (2026-07-14)


### Documentation

* point example subgraph placeholders at indexing-payments ([#672](https://github.com/edgeandnode/dipper/issues/672)) ([aa55181](https://github.com/edgeandnode/dipper/commit/aa551812ef5eaa5a31ac65d038d6826280a1c97d))

## [0.1.6](https://github.com/edgeandnode/dipper/compare/v0.1.5...v0.1.6) (2026-07-14)


### Changed

* get indexer URLs from the indexing-payments subgraph ([#669](https://github.com/edgeandnode/dipper/issues/669)) ([a2217f3](https://github.com/edgeandnode/dipper/commit/a2217f317fafa3954c7793658eb57e6699e49581))
* **k8s:** sync the example configmap with the current config schema ([#667](https://github.com/edgeandnode/dipper/issues/667)) ([2593557](https://github.com/edgeandnode/dipper/commit/2593557936270f8bc7f0815357f6333a4db2f885))

## [0.1.5](https://github.com/edgeandnode/dipper/compare/v0.1.4...v0.1.5) (2026-07-10)


### Added

* pace agreement offers to match indexer capacity ([#661](https://github.com/edgeandnode/dipper/issues/661)) ([861d5b1](https://github.com/edgeandnode/dipper/commit/861d5b1f2d2fc4d367081e27f86fc813c7bcc849))
* **worker:** serve interactive requests before background sweeps ([#662](https://github.com/edgeandnode/dipper/issues/662)) ([cb89726](https://github.com/edgeandnode/dipper/commit/cb8972602b5293cfc529bf4041f71d8e0fd52cc3))


### Fixed

* attribute agreement cancellations to the correct party ([#659](https://github.com/edgeandnode/dipper/issues/659)) ([67a48d5](https://github.com/edgeandnode/dipper/commit/67a48d589bdc038808d4eedc4de6ab6923c5850a))
* **dips:** stamp agreement deadlines from live chain time ([#657](https://github.com/edgeandnode/dipper/issues/657)) ([7f8a887](https://github.com/edgeandnode/dipper/commit/7f8a88717b0acde1318407cfafbe2735e7ef8a11))
* refuse to start with agreement terms the contract rejects ([#664](https://github.com/edgeandnode/dipper/issues/664)) ([78a8a1a](https://github.com/edgeandnode/dipper/commit/78a8a1a93fc8598640acb7bebd61297c64a9e2ed))
* stop endlessly retrying payment offers that always fail ([#665](https://github.com/edgeandnode/dipper/issues/665)) ([564407b](https://github.com/edgeandnode/dipper/commit/564407ba2f0608f89a0bc7f446089b1e4c447822))


### Changed

* **pgregistry:** drop unused voucher-era indexing receipts code ([#663](https://github.com/edgeandnode/dipper/issues/663)) ([fb6d64d](https://github.com/edgeandnode/dipper/commit/fb6d64ded7ef33609f85a1c6369a2919943514d7))
* sync manifest to 0.1.4 (was 0.1.3) ([#653](https://github.com/edgeandnode/dipper/issues/653)) ([b2e0640](https://github.com/edgeandnode/dipper/commit/b2e0640f9560c62353ad697bd8e539eb5f4feb50))


### Performance

* **worker:** raise default job concurrency to 8 with matching pool ([#655](https://github.com/edgeandnode/dipper/issues/655)) ([86ef9dd](https://github.com/edgeandnode/dipper/commit/86ef9dd3d545f99e70eea53285e6650e01615ad9))


### Tests

* share one panic-by-default registry stub across mocks ([#666](https://github.com/edgeandnode/dipper/issues/666)) ([bcdb8d0](https://github.com/edgeandnode/dipper/commit/bcdb8d0eef6072b7b0f2a671f80f545de2ac5ca4))


### CI/CD

* **release:** sign manifest-sync bot commits via the GitHub API ([#652](https://github.com/edgeandnode/dipper/issues/652)) ([3381333](https://github.com/edgeandnode/dipper/commit/338133366a01848fcf81259f718ddd7d63f11301))

## [0.1.3](https://github.com/edgeandnode/dipper/compare/v0.1.2...v0.1.3) (2026-06-11)


### Added

* **config:** reject unknown keys in the chain client section ([#630](https://github.com/edgeandnode/dipper/issues/630)) ([0e947dc](https://github.com/edgeandnode/dipper/commit/0e947dc24bbabc34cc3f7f539fb1447f6a85f1da))
* **dips:** refresh the RCA signing domain while dipper runs ([#632](https://github.com/edgeandnode/dipper/issues/632)) ([bbd6b2c](https://github.com/edgeandnode/dipper/commit/bbd6b2cbf69392eae4f1f49203e3485cd5dfdf7b))
* fetch the signing domain from the deployed contract ([#629](https://github.com/edgeandnode/dipper/issues/629)) ([5537d95](https://github.com/edgeandnode/dipper/commit/5537d9534b8d319795a45d836dfb3876f164856e))
* sign indexing agreement proposals sent to indexers ([#626](https://github.com/edgeandnode/dipper/issues/626)) ([e10b57c](https://github.com/edgeandnode/dipper/commit/e10b57c8dd197790421b4e0a09137a0dc076bd95))


### Fixed

* **dips:** retry untrusted and unknown rejections within a day ([#633](https://github.com/edgeandnode/dipper/issues/633)) ([76fabda](https://github.com/edgeandnode/dipper/commit/76fabdacc83fb7693bc40608b9539a1ee40f0ac9))
* give each indexer rejection its own retry backoff window ([#627](https://github.com/edgeandnode/dipper/issues/627)) ([51e0fc0](https://github.com/edgeandnode/dipper/commit/51e0fc01b3c1aa374935d38a7288402313f9e989))


### Changed

* read the indexer's new accept-or-reject response ([#625](https://github.com/edgeandnode/dipper/issues/625)) ([42bec75](https://github.com/edgeandnode/dipper/commit/42bec75c88c972d0661b86843d342fe07e53c725))
* **registry:** drop rejection reasons that can no longer occur ([#631](https://github.com/edgeandnode/dipper/issues/631)) ([81cb563](https://github.com/edgeandnode/dipper/commit/81cb563146d2b8ba36d5c2c341c85c000dc3e489))


### Documentation

* **readme:** correct IISA startup requirement for dipper ([#623](https://github.com/edgeandnode/dipper/issues/623)) ([0bbbc78](https://github.com/edgeandnode/dipper/commit/0bbbc7864e274fc9062aaeedad3673317d495853))


### Tests

* **network:** address Arbitrum subgraph by ID, not pinned deployment ([#628](https://github.com/edgeandnode/dipper/issues/628)) ([202585a](https://github.com/edgeandnode/dipper/commit/202585a5bf975cd5377c1464d3d5532e3614cde0))

## [0.1.2](https://github.com/edgeandnode/dipper/compare/v0.1.1...v0.1.2) (2026-06-03)


### Changed

* **deps:** update leafwing-studios/cargo-cache digest to ba6ee76 ([#496](https://github.com/edgeandnode/dipper/issues/496)) ([3a78f84](https://github.com/edgeandnode/dipper/commit/3a78f84e4f3b99d62b948150b0bd972a169231f3))
* **deps:** update rust crate tracing-subscriber to v0.3.22 ([#505](https://github.com/edgeandnode/dipper/issues/505)) ([e5390b5](https://github.com/edgeandnode/dipper/commit/e5390b50f7187a8b25e53220770d6ef4834b6fba))
* **deps:** update taiki-e/install-action digest to dfcb1ee ([#530](https://github.com/edgeandnode/dipper/issues/530)) ([b9deb23](https://github.com/edgeandnode/dipper/commit/b9deb236e09b4ffee2978eac564c095bb6f9bb1a))

## [0.1.1](https://github.com/edgeandnode/dipper/compare/v0.1.0...v0.1.1) (2026-06-03)


### Added

* add docker-compose for local image builds ([#564](https://github.com/edgeandnode/dipper/issues/564)) ([4731dbf](https://github.com/edgeandnode/dipper/commit/4731dbf1c3485ac0e2992e4bb4beaf5b9828b44c))
* add entity count cache background service ([#591](https://github.com/edgeandnode/dipper/issues/591)) ([0d36f4d](https://github.com/edgeandnode/dipper/commit/0d36f4d3ef977e23bc3c84b4259d91e44cc9ac57))
* add indexer denylist for emergency exclusion from selection ([#546](https://github.com/edgeandnode/dipper/issues/546)) ([6311800](https://github.com/edgeandnode/dipper/commit/6311800bbbc64ebb3bd04cac59d29cb829897130))
* add just build-image target for local-network ([3e91e20](https://github.com/edgeandnode/dipper/commit/3e91e2079a4a91e9a110442bef66d267f972f1e4))
* add kustomization so k8s can be a remote base ([1269d33](https://github.com/edgeandnode/dipper/commit/1269d33f7619e33da23e35f018242ecd94a87315))
* add observability logging to topology refresh service ([#593](https://github.com/edgeandnode/dipper/issues/593)) ([acbb230](https://github.com/edgeandnode/dipper/commit/acbb23096b6a6642d7ea5d8fd02f0e42967b8558))
* add SIGNER_NOT_AUTHORISED rejection reason with 5-minute lookback ([#575](https://github.com/edgeandnode/dipper/issues/575)) ([ecd1072](https://github.com/edgeandnode/dipper/commit/ecd10726cf8ac6c985463c3705c6a358ec8dc756))
* add state transition logging to chain listener accepted events ([#596](https://github.com/edgeandnode/dipper/issues/596)) ([c1bddbe](https://github.com/edgeandnode/dipper/commit/c1bddbe59d2b3f38ca70c4f05af7cb62543f9929))
* add structured agreement state transition logging ([#595](https://github.com/edgeandnode/dipper/issues/595)) ([73b8b69](https://github.com/edgeandnode/dipper/commit/73b8b698a954734580cb75d830985032d95c9f34))
* cancel old agreements only after on-chain acceptance of replacements ([#584](https://github.com/edgeandnode/dipper/issues/584)) ([f55ae23](https://github.com/edgeandnode/dipper/commit/f55ae23ff462a4cee00178ac131f01839e195fbd))
* chain listener observability — adaptive polling, heartbeat, stall detection ([#586](https://github.com/edgeandnode/dipper/issues/586)) ([7214c2c](https://github.com/edgeandnode/dipper/commit/7214c2cf96c54996f56fc9a6461a21a6cd9011c8))
* deadline expiration mechanism for stale Created agreements ([#559](https://github.com/edgeandnode/dipper/issues/559)) ([7bf7f6c](https://github.com/edgeandnode/dipper/commit/7bf7f6c123bb1d4246052aa82004fc9970830918))
* **dipper-cli:** add `init` bootstrap command ([#389](https://github.com/edgeandnode/dipper/issues/389)) ([e6b38e3](https://github.com/edgeandnode/dipper/commit/e6b38e31e9d26dea311e7f2defeda869d2ba5000))
* **dipper-cli:** add agreements list command for listing indexing agreements ([#371](https://github.com/edgeandnode/dipper/issues/371)) ([1896425](https://github.com/edgeandnode/dipper/commit/1896425ce4e936185e5d2aebb748c121228840f5))
* **dipper-cli:** add cancel command for agreements management ([#372](https://github.com/edgeandnode/dipper/issues/372)) ([d5de0ed](https://github.com/edgeandnode/dipper/commit/d5de0edc83d99aafd63e03dde963f47b6057d278))
* **dipper-cli:** add CLI indexings admin commands ([#158](https://github.com/edgeandnode/dipper/issues/158)) ([999ba4d](https://github.com/edgeandnode/dipper/commit/999ba4dd22d71ef2800b83da5ade7eaa0e640262))
* **dipper-cli:** add dipper-cli docker image ([#390](https://github.com/edgeandnode/dipper/issues/390)) ([54ee185](https://github.com/edgeandnode/dipper/commit/54ee1857ee4f2c8e251cc58d1952d10d7425a57d))
* **dipper-cli:** add get indexing request status by deployment ID ([#185](https://github.com/edgeandnode/dipper/issues/185)) ([0846bc8](https://github.com/edgeandnode/dipper/commit/0846bc80153c12f9ffb7b46a67f983fd4ab616b0))
* **dipper-cli:** add indexing request register support ([fa7f228](https://github.com/edgeandnode/dipper/commit/fa7f2289646f779970ac18749afe4d4bbe50d322))
* **dipper-cli:** enhance command structure and add error handling improvements ([#377](https://github.com/edgeandnode/dipper/issues/377)) ([16c7d72](https://github.com/edgeandnode/dipper/commit/16c7d7247573fb4bfe46b0cc736467bc55b153cd))
* **dipper-cli:** support indexing request registration ([#320](https://github.com/edgeandnode/dipper/issues/320)) ([fa7f228](https://github.com/edgeandnode/dipper/commit/fa7f2289646f779970ac18749afe4d4bbe50d322))
* **dipper-core:** add admin API messages ([#155](https://github.com/edgeandnode/dipper/issues/155)) ([50316fd](https://github.com/edgeandnode/dipper/commit/50316fdf62f5e6215576034a499487d2d2783bd9))
* **dipper-core:** add dipper core crate ([#132](https://github.com/edgeandnode/dipper/issues/132)) ([7ca2df5](https://github.com/edgeandnode/dipper/commit/7ca2df53d39d3276172d4c18dbd3fae72e41d527))
* **dipper-core:** add fake-rs support ([#208](https://github.com/edgeandnode/dipper/issues/208)) ([e59ca56](https://github.com/edgeandnode/dipper/commit/e59ca56587ab20d1d699cf28780e7c144accfcb9))
* **dipper-core:** add ids from bytes method ([#142](https://github.com/edgeandnode/dipper/issues/142)) ([f8f5fba](https://github.com/edgeandnode/dipper/commit/f8f5fbae08e2e628b26762dfeea37b81009f5f32))
* **dipper-core:** add indexing agreements rpc ([#179](https://github.com/edgeandnode/dipper/issues/179)) ([b4fccbf](https://github.com/edgeandnode/dipper/commit/b4fccbfaf4334d9aed32b2dfac71765428fb922a))
* **dipper-core:** add serde support to EIP-712 signed_message ([#149](https://github.com/edgeandnode/dipper/issues/149)) ([e776309](https://github.com/edgeandnode/dipper/commit/e7763095d826780d23f463d4e689aab7643e0204))
* **dipper-core:** add serialization support to signed message ([#143](https://github.com/edgeandnode/dipper/issues/143)) ([293c540](https://github.com/edgeandnode/dipper/commit/293c54094bf9a79d2bbd611611d29fbfc83eb77e))
* **dipper-core:** add signed message module ([#141](https://github.com/edgeandnode/dipper/issues/141)) ([2ca5856](https://github.com/edgeandnode/dipper/commit/2ca5856d3a61e965d1856ec23334d4e9f61d0ab5))
* **dipper-core:** extend ID convert traits implementation ([#228](https://github.com/edgeandnode/dipper/issues/228)) ([1914cb9](https://github.com/edgeandnode/dipper/commit/1914cb9a2e76b37d1ef5ef3d9dfaed4d119ba6f9))
* **dipper-iisa-python:** random indexer selection ([#282](https://github.com/edgeandnode/dipper/issues/282)) ([5f3ca0c](https://github.com/edgeandnode/dipper/commit/5f3ca0c8f4bfc9c1fb44703eaaca0af26497d5bd))
* **dipper-iisa-python:** relocate iisa python code ([#177](https://github.com/edgeandnode/dipper/issues/177)) ([45949fb](https://github.com/edgeandnode/dipper/commit/45949fb8f198a950ac0fe4b6a2bf773eeca3b3af))
* **dipper-iisa:** add geoip resolver auth config parameter ([#169](https://github.com/edgeandnode/dipper/issues/169)) ([7b47873](https://github.com/edgeandnode/dipper/commit/7b47873c133fd994b91be100d0880c88b0530682))
* **dipper-iisa:** add graceful stop service command ([#181](https://github.com/edgeandnode/dipper/issues/181)) ([126f1d1](https://github.com/edgeandnode/dipper/commit/126f1d123f66b56c0af495cd6317604e53696e90))
* **dipper-iisa:** add iisa crate ([#135](https://github.com/edgeandnode/dipper/issues/135)) ([2b8bfaa](https://github.com/edgeandnode/dipper/commit/2b8bfaa39c71e58de037d8cc9b08202cedfdcd15))
* **dipper-iisa:** add iisa select placeholder functions ([#171](https://github.com/edgeandnode/dipper/issues/171)) ([6087a2c](https://github.com/edgeandnode/dipper/commit/6087a2ccc251e4b52a28eea064dae064e136ed3e))
* **dipper-iisa:** add iisa service handler stop mechanism ([#175](https://github.com/edgeandnode/dipper/issues/175)) ([53fae27](https://github.com/edgeandnode/dipper/commit/53fae274f155ae569ad5a4d7b2e0baa1a13c6ca0))
* **dipper-iisa:** do not resolve private IP addresses geoip info ([#170](https://github.com/edgeandnode/dipper/issues/170)) ([1c6d488](https://github.com/edgeandnode/dipper/commit/1c6d4886cbb4d461a0b439b9f4cb39848ec300f1))
* **dipper-iisa:** random indexer selection ([#283](https://github.com/edgeandnode/dipper/issues/283)) ([13beda6](https://github.com/edgeandnode/dipper/commit/13beda65064cac050e48c3597ca14309de03f2cb))
* **dipper-indexer-client:** add indexer-client crate ([#137](https://github.com/edgeandnode/dipper/issues/137)) ([519c40f](https://github.com/edgeandnode/dipper/commit/519c40f817ec1a31ff249a47b96e468ccf02f1e3))
* **dipper-indexer-client:** make urls module public ([#146](https://github.com/edgeandnode/dipper/issues/146)) ([8d227f6](https://github.com/edgeandnode/dipper/commit/8d227f68d985ff3194bb058eb48b93b56fd0235a))
* **dipper-pgmq:** add job available notification mechanism ([#433](https://github.com/edgeandnode/dipper/issues/433)) ([e190db4](https://github.com/edgeandnode/dipper/commit/e190db4971b1fc592976c1dadfd52a559d3f4ce9))
* **dipper-pgmq:** add job builder and simplify queue API ([#429](https://github.com/edgeandnode/dipper/issues/429)) ([ead02e0](https://github.com/edgeandnode/dipper/commit/ead02e0703a9817f13c1f8bbe1e782911c7062da))
* **dipper-pgmq:** add postgres-backed message queue crate ([#123](https://github.com/edgeandnode/dipper/issues/123)) ([94428bb](https://github.com/edgeandnode/dipper/commit/94428bbc2811915dfeb36ac44be7ef0f66fdac3e))
* **dipper-pgmq:** add transaction job guard ([#327](https://github.com/edgeandnode/dipper/issues/327)) ([9102a2d](https://github.com/edgeandnode/dipper/commit/9102a2defac262675ea40ef2626010812f7e59b5))
* **dipper-pgmq:** enhance job processing and error handling ([#434](https://github.com/edgeandnode/dipper/issues/434)) ([9a68043](https://github.com/edgeandnode/dipper/commit/9a68043e163cdccb7d6e700335ca9aef443df399))
* **dipper-pgmq:** expose job details and rename retry columns ([#431](https://github.com/edgeandnode/dipper/issues/431)) ([e71f25b](https://github.com/edgeandnode/dipper/commit/e71f25bdcbcb4310873813a0f0612105d63afb02))
* **dipper-pgmq:** extend queue api and add job result enum ([#133](https://github.com/edgeandnode/dipper/issues/133)) ([1f04ce8](https://github.com/edgeandnode/dipper/commit/1f04ce834c14cb9687b2b763aa5b50bebf70aa98))
* **dipper-pgregistry:** refactor voucher handling and update SQL schema ([#365](https://github.com/edgeandnode/dipper/issues/365)) ([7cf336d](https://github.com/edgeandnode/dipper/commit/7cf336d6dd5faed785d162850b5b50a22035f692))
* **dipper-registry:** add dipper registry crate ([#134](https://github.com/edgeandnode/dipper/issues/134)) ([fafaa6d](https://github.com/edgeandnode/dipper/commit/fafaa6de7779b3edefb295c3c2a482eb821da8bd))
* **dipper-registry:** add function to retrieve latest receipt for agreement ([#288](https://github.com/edgeandnode/dipper/issues/288)) ([2e5a8c2](https://github.com/edgeandnode/dipper/commit/2e5a8c2bcb02f926c7424c20b399c3b07cb298d6))
* **dipper-registry:** add trait placeholder methods ([#182](https://github.com/edgeandnode/dipper/issues/182)) ([b39fa4c](https://github.com/edgeandnode/dipper/commit/b39fa4c425baa01fee9cbaf6ce0ac86542e76143))
* **dipper-registry:** add voucher info to registry ([#214](https://github.com/edgeandnode/dipper/issues/214)) ([aa23019](https://github.com/edgeandnode/dipper/commit/aa23019fbfb222afdfdc34914a0bea061b35b151))
* **dipper-rpc:** add dipper rpc crate ([#209](https://github.com/edgeandnode/dipper/issues/209)) ([8cd0681](https://github.com/edgeandnode/dipper/commit/8cd06813e0afd3c5e1d2227510cbf08321010287))
* **dipper-rpc:** split dips.proto into indexer and gateway services ([#221](https://github.com/edgeandnode/dipper/issues/221)) ([76ed6d8](https://github.com/edgeandnode/dipper/commit/76ed6d8ae43426f3b82d5296a2ce866844419f8f))
* **dipper-rpc:** update agreement proposal and progress reporting messages ([#289](https://github.com/edgeandnode/dipper/issues/289)) ([11e28b5](https://github.com/edgeandnode/dipper/commit/11e28b5d58a1198600fef9564ced2ff8b96fab83))
* **dipper-rpc:** use latest indexer-rs dips crate ([#364](https://github.com/edgeandnode/dipper/issues/364)) ([d4fbec2](https://github.com/edgeandnode/dipper/commit/d4fbec25f9624cc38ae6da06c0b45956d9496a8b))
* **dipper-rpc:** use thegraph-core signed message implementation ([#224](https://github.com/edgeandnode/dipper/issues/224)) ([71785b4](https://github.com/edgeandnode/dipper/commit/71785b41121050c21558f28daff989895838090b))
* **dipper-service:** accept indexing requests for subgraphs not registered in the network subgraph ([#366](https://github.com/edgeandnode/dipper/issues/366)) ([283b6d0](https://github.com/edgeandnode/dipper/commit/283b6d0c1291c1709bc04e57679bf28502f033e3))
* **dipper-service:** add admin RPC API error responses ([#231](https://github.com/edgeandnode/dipper/issues/231)) ([07e87fc](https://github.com/edgeandnode/dipper/commit/07e87fce29fb20be46ddb66e6c2d91508d1199d4))
* **dipper-service:** add collect payment handling logic ([#299](https://github.com/edgeandnode/dipper/issues/299)) ([4185486](https://github.com/edgeandnode/dipper/commit/41854864d2d68abfdb7d1e766208b9c9a337592d))
* **dipper-service:** add graph network module ([#139](https://github.com/edgeandnode/dipper/issues/139)) ([5b0bb6d](https://github.com/edgeandnode/dipper/commit/5b0bb6d5bad87ae8dded97e0c6a7ca5ede29a7f5))
* **dipper-service:** add http server service ([#144](https://github.com/edgeandnode/dipper/issues/144)) ([57b330b](https://github.com/edgeandnode/dipper/commit/57b330b2c31f11a2a8cdb37082c927df3e201584))
* **dipper-service:** add indexer DIPs RPC client ([#223](https://github.com/edgeandnode/dipper/issues/223)) ([c8700e2](https://github.com/edgeandnode/dipper/commit/c8700e2c6907a9921c7e8d1c6d5066efbabfb0c4))
* **dipper-service:** add indexer JSON-RPC server ([#180](https://github.com/edgeandnode/dipper/issues/180)) ([1150b69](https://github.com/edgeandnode/dipper/commit/1150b69b8cb7635e8472ad98926d7c0150524317))
* **dipper-service:** add indexer RPC service ([#222](https://github.com/edgeandnode/dipper/issues/222)) ([1ff084e](https://github.com/edgeandnode/dipper/commit/1ff084e3bead1def7a753f5c2e3445788a464d4d))
* **dipper-service:** add indexer to operator wallet address mapping ([#193](https://github.com/edgeandnode/dipper/issues/193)) ([41dbb8b](https://github.com/edgeandnode/dipper/commit/41dbb8b82dee53202ab690bbbc92141336a35ce7))
* **dipper-service:** add queue worker module ([#140](https://github.com/edgeandnode/dipper/issues/140)) ([90a13f8](https://github.com/edgeandnode/dipper/commit/90a13f81552ddedd0ea444aca1446dc148c41705))
* **dipper-service:** add specialized EIP-712 message signer methods ([#362](https://github.com/edgeandnode/dipper/issues/362)) ([50495fe](https://github.com/edgeandnode/dipper/commit/50495fe9c0ad16529361f082985f1a53126741d5))
* **dipper-service:** add TAP receipt signer and configuration ([#285](https://github.com/edgeandnode/dipper/issues/285)) ([bda01b1](https://github.com/edgeandnode/dipper/commit/bda01b1e55f09d3fad6522bbf608bb38ae83ea59))
* **dipper-service:** add TAP receipt signer to context ([#287](https://github.com/edgeandnode/dipper/issues/287)) ([2e4844d](https://github.com/edgeandnode/dipper/commit/2e4844d0aa135185ea62c4d698587a1fc490cbc4))
* **dipper-service:** add tracing for indexing request cancellation ([#370](https://github.com/edgeandnode/dipper/issues/370)) ([be005d5](https://github.com/edgeandnode/dipper/commit/be005d52bd9400916d21f4403556aac04a7dcddc))
* **dipper-service:** check if requested deployment ID exists in the network ([#225](https://github.com/edgeandnode/dipper/issues/225)) ([abae580](https://github.com/edgeandnode/dipper/commit/abae580aae99131ece2e137a1e48f48f4527e2e8))
* **dipper-service:** extract worker queue trait ([#230](https://github.com/edgeandnode/dipper/issues/230)) ([e56a5d5](https://github.com/edgeandnode/dipper/commit/e56a5d53b908d75f1ddb4a9d2ee79f4e9fb9bfc5))
* **dipper-service:** filter network provider indexers with allowlist ([#286](https://github.com/edgeandnode/dipper/issues/286)) ([b3e35aa](https://github.com/edgeandnode/dipper/commit/b3e35aa17470feb00123b60cdd7e0b54400dba36))
* **dipper-service:** implement get indexing agreements RPC methods ([#183](https://github.com/edgeandnode/dipper/issues/183)) ([647c8b4](https://github.com/edgeandnode/dipper/commit/647c8b4905e68710fe2709ef1c90860e4d7193e0))
* **dipper-service:** implement receipt handling and epoch validation in progress reporting ([#290](https://github.com/edgeandnode/dipper/issues/290)) ([58bf35c](https://github.com/edgeandnode/dipper/commit/58bf35c6597e772df2e554a9cf627982b0b0076d))
* **dipper-service:** integrate the different components ([#176](https://github.com/edgeandnode/dipper/issues/176)) ([daba182](https://github.com/edgeandnode/dipper/commit/daba182e932905e813800e08e15ab2913004de8e))
* **dipper-service:** remove NetworkProvider dependency from indexing requests context ([#367](https://github.com/edgeandnode/dipper/issues/367)) ([dc5b772](https://github.com/edgeandnode/dipper/commit/dc5b7720ae49500f6e399e8d05f4fc0a63574733))
* **dipper-service:** replace HTTP server with JSON-RPC server ([#157](https://github.com/edgeandnode/dipper/issues/157)) ([39c438a](https://github.com/edgeandnode/dipper/commit/39c438a66f3d490c29ffd186b4b9575f1cfe90c1))
* **dipper-service:** require a network subgraph snapshot to start ([#178](https://github.com/edgeandnode/dipper/issues/178)) ([e18e2ac](https://github.com/edgeandnode/dipper/commit/e18e2ac8abdb01f8add4dec8362abe5470a01fac))
* **dipper-service:** run migrations at boot ([#328](https://github.com/edgeandnode/dipper/issues/328)) ([769b7e8](https://github.com/edgeandnode/dipper/commit/769b7e882f67062a4cd8b2cc2d9a00f589465344))
* **dipper-service:** split network subgraph fetch services ([#318](https://github.com/edgeandnode/dipper/issues/318)) ([c544000](https://github.com/edgeandnode/dipper/commit/c5440005abfd4f407f5c096cdfbf24d95fe4d264))
* **dipper-service:** use signer chain ID in DIPs EIP-712 domains ([#363](https://github.com/edgeandnode/dipper/issues/363)) ([5c54797](https://github.com/edgeandnode/dipper/commit/5c547972710db90641421ad6850fae3edfb92b13))
* **dipper-service:** use snmalloc memory allocator ([#116](https://github.com/edgeandnode/dipper/issues/116)) ([066c525](https://github.com/edgeandnode/dipper/commit/066c525b763a6d2a91358342208dc0f28a9d1d9d))
* **dipper:** add iisa API pyo3 wrapper ([#73](https://github.com/edgeandnode/dipper/issues/73)) ([12800de](https://github.com/edgeandnode/dipper/commit/12800de158c0949224c118da8913ecffd5081563))
* **dipper:** add iisa data manager pyo3 wrapper ([#79](https://github.com/edgeandnode/dipper/issues/79)) ([d893b1a](https://github.com/edgeandnode/dipper/commit/d893b1aa0ba5a7c9f414d4c2c89429ef283c597f))
* **dipper:** add iisa.data_manager output newtypes ([#85](https://github.com/edgeandnode/dipper/issues/85)) ([64f076a](https://github.com/edgeandnode/dipper/commit/64f076a5936b222dabab88ee6299dff95835f69c))
* **dipper:** add network subgraph service ([#63](https://github.com/edgeandnode/dipper/issues/63)) ([f0635cc](https://github.com/edgeandnode/dipper/commit/f0635ccae331d97b1c926be9c7c31cf0ecff6337))
* **dipper:** add payments support to indexers client module ([#65](https://github.com/edgeandnode/dipper/issues/65)) ([49f6b77](https://github.com/edgeandnode/dipper/commit/49f6b7777118d28754aa8a4bfba9117317b39bbd))
* **dipper:** add python logging to rust log bridge ([#69](https://github.com/edgeandnode/dipper/issues/69)) ([2348142](https://github.com/edgeandnode/dipper/commit/2348142f629306741de714ebfc989a019c03e67e))
* **dipper:** type-annotate data manager output data ([#82](https://github.com/edgeandnode/dipper/issues/82)) ([1bbe77f](https://github.com/edgeandnode/dipper/commit/1bbe77f2b3ad2b8aae9ecc67385369f037960518))
* **dipper:** update indexer selection service to support data manager commands ([#86](https://github.com/edgeandnode/dipper/issues/86)) ([c5258f3](https://github.com/edgeandnode/dipper/commit/c5258f32c574be1ed3ffdc2ae32719580fb7248e))
* **dips:** add bypass_chain_clock_defenses flag for local testing ([#617](https://github.com/edgeandnode/dipper/issues/617)) ([b3bc74d](https://github.com/edgeandnode/dipper/commit/b3bc74d88d5f07ffff11eb5a022e00088b916eb2))
* **dips:** log reassessment diff with IISA candidate counts ([#618](https://github.com/edgeandnode/dipper/issues/618)) ([02b0d33](https://github.com/edgeandnode/dipper/commit/02b0d33ee70e52d7dc070d2a557f6a4c27ed0032))
* **dips:** switch to offer-based RCA authorization ([#607](https://github.com/edgeandnode/dipper/issues/607)) ([dac67db](https://github.com/edgeandnode/dipper/commit/dac67dbf175aa5a85cd06ceab8088e6f2472d4bb))
* exclude recently declined indexers from selection (30-day TTL) ([#545](https://github.com/edgeandnode/dipper/issues/545)) ([b611901](https://github.com/edgeandnode/dipper/commit/b61190155996af3d33afcccb30b62db5ce5a4eae))
* handle specific rejection reasons from indexer-rs ([#577](https://github.com/edgeandnode/dipper/issues/577)) ([7564929](https://github.com/edgeandnode/dipper/commit/75649290184984ab105beeaa4735e995209f9c7c))
* **iisa:** add blocklist and declined_indexers to SelectionContext ([#542](https://github.com/edgeandnode/dipper/issues/542)) ([f0c70b2](https://github.com/edgeandnode/dipper/commit/f0c70b25e93f8fcc0be361a6306dd2010d54ae42))
* **iisa:** add chain/pricing filtering to fallback path ([#566](https://github.com/edgeandnode/dipper/issues/566)) ([f9c2e2c](https://github.com/edgeandnode/dipper/commit/f9c2e2cca79e5f04e05aa19cc2247f845a34b1ec))
* **iisa:** add error handling and resilience policy ([#532](https://github.com/edgeandnode/dipper/issues/532)) ([b008fad](https://github.com/edgeandnode/dipper/commit/b008fadc9eee96bebdc07fc57b2864a1eda97e21))
* **iisa:** add load balancing context with batch query optimization ([#522](https://github.com/edgeandnode/dipper/issues/522)) ([d3776dc](https://github.com/edgeandnode/dipper/commit/d3776dc561854b9279eb455bf9686656c4b46dc6))
* **iisa:** add network subgraph indexers info provider ([#33](https://github.com/edgeandnode/dipper/issues/33)) ([2f06ba5](https://github.com/edgeandnode/dipper/commit/2f06ba5c84c8559dad6e1abd164774a1ebe9a746))
* **iisa:** add timeout and retry logic to HTTP client ([#534](https://github.com/edgeandnode/dipper/issues/534)) ([e39206d](https://github.com/edgeandnode/dipper/commit/e39206db0c944a71765203b86c9f96ce8ee8d0a8))
* **iisa:** expose iisa public API ([#55](https://github.com/edgeandnode/dipper/issues/55)) ([7dedb1d](https://github.com/edgeandnode/dipper/commit/7dedb1db19397ccd9c327319dd3f298ebf88f803))
* **iisa:** geoip resolver return none on failure ([#51](https://github.com/edgeandnode/dipper/issues/51)) ([612e4db](https://github.com/edgeandnode/dipper/commit/612e4db89163c8f86837abb419064c5a3f010424))
* **iisa:** integrate network indexers info provider ([#56](https://github.com/edgeandnode/dipper/issues/56)) ([36cd940](https://github.com/edgeandnode/dipper/commit/36cd940073489648e1215d929d6e522d7b0eae73))
* include entity fees in optimistic DIPs fee estimation ([#592](https://github.com/edgeandnode/dipper/issues/592)) ([844c4c6](https://github.com/edgeandnode/dipper/commit/844c4c6a3f5ac9945dd3dd00ed3da101e93e2ee9))
* **indexer-client:** add configurable gRPC timeouts and retries ([#558](https://github.com/edgeandnode/dipper/issues/558)) ([5fc350a](https://github.com/edgeandnode/dipper/commit/5fc350aea7180cb46ff5faf1e502c9969221df93))
* liveness checker for silent agreement abandonment ([#549](https://github.com/edgeandnode/dipper/issues/549)) ([#562](https://github.com/edgeandnode/dipper/issues/562)) ([e9ec1ff](https://github.com/edgeandnode/dipper/commit/e9ec1ffd593d9391be2f3e588a32ae6e167922e4))
* migrate from epoch-based voucher to seconds-based RCA ([#555](https://github.com/edgeandnode/dipper/issues/555)) ([22a648e](https://github.com/edgeandnode/dipper/commit/22a648e7f7cd067af5d38cd2b11645f57323b67b))
* periodic reassignment, V2 status cleanup, and AcceptedOnChain ([#550](https://github.com/edgeandnode/dipper/issues/550)) ([#553](https://github.com/edgeandnode/dipper/issues/553)) ([97af12b](https://github.com/edgeandnode/dipper/commit/97af12baec13aa4161640a002b281f7b950fa279))
* **pricing:** add payment ceiling, rejection tracking, and dynamic pricing ([#563](https://github.com/edgeandnode/dipper/issues/563)) ([ea125e7](https://github.com/edgeandnode/dipper/commit/ea125e7977ebc2b4504a7eb4c0ba683449538287))
* **registry:** add expiration and audit fields to indexer denylist ([#551](https://github.com/edgeandnode/dipper/issues/551)) ([4c96e21](https://github.com/edgeandnode/dipper/commit/4c96e21aa8b25598a343885ba68f004a4db616ec))
* reject topology updates that produce zero indexers ([#594](https://github.com/edgeandnode/dipper/issues/594)) ([883c709](https://github.com/edgeandnode/dipper/commit/883c70959cd3da5930c17cfd03f2241224c4ed26))
* replace hardcoded chain_id_to_name with graph-networks-registry ([#573](https://github.com/edgeandnode/dipper/issues/573)) ([7b6445b](https://github.com/edgeandnode/dipper/commit/7b6445b5406cc6c404fdecbe06f50e890d5343b3))
* **rpc,cli:** add optional num_candidates to register_new_indexing_request ([#572](https://github.com/edgeandnode/dipper/issues/572)) ([33a3655](https://github.com/edgeandnode/dipper/commit/33a36555c1cd22773aa3f8639ce292954c64fa7d))
* send indexer's optimistic DIPs revenue to IISA to improve the stake_to_fees calculation ([#580](https://github.com/edgeandnode/dipper/issues/580)) ([a5fbd8c](https://github.com/edgeandnode/dipper/commit/a5fbd8c42e98e398ba50937a8e3fabd2551aeccf))
* use chain time for agreement expiration ([#587](https://github.com/edgeandnode/dipper/issues/587)) ([d3b5f94](https://github.com/edgeandnode/dipper/commit/d3b5f94fb28519dbd010a1a3658de6f0cb128728))
* use Solidty and RPC types from indexer-dips crate ([#298](https://github.com/edgeandnode/dipper/issues/298)) ([6f55ad4](https://github.com/edgeandnode/dipper/commit/6f55ad44a1482eaef89f53dd85e26ea85a17bf0e))
* warn when pricing falls back to static pricing_table ([#598](https://github.com/edgeandnode/dipper/issues/598)) ([771c4c3](https://github.com/edgeandnode/dipper/commit/771c4c3ac689209cfcb403a233910edc10740cac))


### Fixed

* **ci:** improve sync-manifest to handle branch protection ([#548](https://github.com/edgeandnode/dipper/issues/548)) ([b9fd020](https://github.com/edgeandnode/dipper/commit/b9fd0207046192d6862b8a1a3f1a0b9efa987ffa))
* **ci:** prevent sync-manifest from downgrading manifest version ([81a6357](https://github.com/edgeandnode/dipper/commit/81a635758a77fee06b385021c4462422eedacc30))
* **ci:** repair sync-manifest action.yml YAML parse ([#612](https://github.com/edgeandnode/dipper/issues/612)) ([6aa74ff](https://github.com/edgeandnode/dipper/commit/6aa74ff593f06c440df2f81ae909b5ae85ad68e5))
* delegate DB migrations to sub-crate migrators ([#571](https://github.com/edgeandnode/dipper/issues/571)) ([a5696bc](https://github.com/edgeandnode/dipper/commit/a5696bc3445140c2cf74856cb6bab040aa084f57))
* **dipper-cli:** hide environment values for signing key argument ([#385](https://github.com/edgeandnode/dipper/issues/385)) ([b98ca4d](https://github.com/edgeandnode/dipper/commit/b98ca4de132e41ecb6d6d9443642da0041919305))
* **dipper-cli:** remove unused args ([#358](https://github.com/edgeandnode/dipper/issues/358)) ([41a7b80](https://github.com/edgeandnode/dipper/commit/41a7b803a22912b0299301deaed8b005496934f6))
* **dipper-pgregistry:** fix db migrations ([#356](https://github.com/edgeandnode/dipper/issues/356)) ([e64ce38](https://github.com/edgeandnode/dipper/commit/e64ce380949a776f6d23c5523b648682ab5e5983))
* **dipper-service:** check if request/agreement exists before canceling ([#184](https://github.com/edgeandnode/dipper/issues/184)) ([371a279](https://github.com/edgeandnode/dipper/commit/371a279114fc9cf797c3bcb51c0aafced2c23062))
* **dipper-service:** improve logs traceability ([#357](https://github.com/edgeandnode/dipper/issues/357)) ([de28d3c](https://github.com/edgeandnode/dipper/commit/de28d3c8acbdf6ade419f7755e4fb0aaeab4c162))
* **dipper-service:** update fee calculation logic ([#442](https://github.com/edgeandnode/dipper/issues/442)) ([8047907](https://github.com/edgeandnode/dipper/commit/804790713afa6cf2a66f1dbb2033fd0472644e83))
* **dipper:** fix the iisa integration tests ([#91](https://github.com/edgeandnode/dipper/issues/91)) ([2a6dcfd](https://github.com/edgeandnode/dipper/commit/2a6dcfd53d9dc6bb306405b39a8c529c15a34f1a))
* handle duplicate agreement constraint as warning instead of fatal error ([#579](https://github.com/edgeandnode/dipper/issues/579)) ([5a1d291](https://github.com/edgeandnode/dipper/commit/5a1d291f4b17f37c2792acb386387025fbbeba9b))
* harden indexer offer flow before testnet launch ([#610](https://github.com/edgeandnode/dipper/issues/610)) ([b6e807f](https://github.com/edgeandnode/dipper/commit/b6e807fb9662c0d97996836989c49b0b62de214d))
* **iisa:** correct pending_agreements format to match IISA expectations ([#540](https://github.com/edgeandnode/dipper/issues/540)) ([945725a](https://github.com/edgeandnode/dipper/commit/945725a99a7f01bd4c6d215ca4a589c0f7a2bbe8))
* **iisa:** keep request destination lat/long coordinates columns ([#84](https://github.com/edgeandnode/dipper/issues/84)) ([0aab437](https://github.com/edgeandnode/dipper/commit/0aab437856adda04d39cdaaac07769fa7891e40e))
* make initial topology fetch non-fatal ([#578](https://github.com/edgeandnode/dipper/issues/578)) ([a3d0538](https://github.com/edgeandnode/dipper/commit/a3d05384d0889d9d396db89c0722493a88248435))
* propose DIPs agreements to indexers without allocations ([#581](https://github.com/edgeandnode/dipper/issues/581)) ([1c1649d](https://github.com/edgeandnode/dipper/commit/1c1649d837ab4bccb3cb72dd86bdd5d8645a39d6))
* send the right value when creating a new on-chain offer ([#613](https://github.com/edgeandnode/dipper/issues/613)) ([5cf3f0b](https://github.com/edgeandnode/dipper/commit/5cf3f0b47954ffcc63f0ca507ac0ca3e1a73817e))
* suppress dead code warnings in topology data model structs ([#597](https://github.com/edgeandnode/dipper/issues/597)) ([181a052](https://github.com/edgeandnode/dipper/commit/181a0527c2b9d2710d2b78e11f37f3643b6d9ab3))
* use on-chain agreement ID for cancellation requests ([#603](https://github.com/edgeandnode/dipper/issues/603)) ([4217929](https://github.com/edgeandnode/dipper/commit/42179292c7180d0f2e4122ab80387d91c4032f41))
* use version 0 for IndexingAgreementVersion.V1 in RCA metadata ([#583](https://github.com/edgeandnode/dipper/issues/583)) ([81aa242](https://github.com/edgeandnode/dipper/commit/81aa24240047099cdf8c5d314a1ef2f9f5c3498f))
* wake chain_listener immediately when proposals are dispatched ([#599](https://github.com/edgeandnode/dipper/issues/599)) ([0dc3f8c](https://github.com/edgeandnode/dipper/commit/0dc3f8c6eca1ecaa8f2dbda86446569ebece2856))
* wire on-chain agreement ID into chain_listener lookup ([#600](https://github.com/edgeandnode/dipper/issues/600)) ([ec0fcf3](https://github.com/edgeandnode/dipper/commit/ec0fcf3bb3665dc58fd141a31252d36e43a4c486))


### Changed

* add chain_listener and reassignment to configmap example ([#585](https://github.com/edgeandnode/dipper/issues/585)) ([039bcc6](https://github.com/edgeandnode/dipper/commit/039bcc66879692efa36a7de90acdb95e354bd34c))
* add CONTRIBUTING.md docs ([#174](https://github.com/edgeandnode/dipper/issues/174)) ([2dd8009](https://github.com/edgeandnode/dipper/commit/2dd80097da397455eb9d7658cefe80a54f9e4572))
* add create migrations links script ([#130](https://github.com/edgeandnode/dipper/issues/130)) ([a273cf1](https://github.com/edgeandnode/dipper/commit/a273cf1534cd61537dd83ad5f2748769c29b6250))
* add Git hook installation and removal scripts with pre-commit configuration ([#432](https://github.com/edgeandnode/dipper/issues/432)) ([63d5c71](https://github.com/edgeandnode/dipper/commit/63d5c710bbf5a2401f1617002408ab57dc8a993d))
* add justfile for task management ([#411](https://github.com/edgeandnode/dipper/issues/411)) ([1689c72](https://github.com/edgeandnode/dipper/commit/1689c727e4d722aa12d3469244647af7bd6ebff2))
* **admin-rpc:** extract common error handling utilities ([#567](https://github.com/edgeandnode/dipper/issues/567)) ([21c4a58](https://github.com/edgeandnode/dipper/commit/21c4a588a8c5329aa0751b31a92b6e1219227c9a))
* **ci:** add dipper-cli build workflow ([#194](https://github.com/edgeandnode/dipper/issues/194)) ([ab7f50f](https://github.com/edgeandnode/dipper/commit/ab7f50f504ceb2ca95b7fdac2f1a7472666f433c))
* **ci:** add docker image build check to pull requests ([#76](https://github.com/edgeandnode/dipper/issues/76)) ([b25f47a](https://github.com/edgeandnode/dipper/commit/b25f47a1be4627d8c0b33639d91bcf697784e15e))
* **ci:** add docker image build workflow ([#58](https://github.com/edgeandnode/dipper/issues/58)) ([24d10d4](https://github.com/edgeandnode/dipper/commit/24d10d46828c42815a3c5533ec1e34f9db38275d))
* **ci:** disable test-python CI workflow mypy checks ([#373](https://github.com/edgeandnode/dipper/issues/373)) ([2e2686f](https://github.com/edgeandnode/dipper/commit/2e2686f8fca815113813b0e3f9572d967a837461))
* **ci:** migrate project to pyproject.toml and uv.lock ([#57](https://github.com/edgeandnode/dipper/issues/57)) ([2d94afb](https://github.com/edgeandnode/dipper/commit/2d94afbae943ae3498eeadfc41c63cd605f72a56))
* **ci:** set up uv/python before cargo check ([#156](https://github.com/edgeandnode/dipper/issues/156)) ([2ef6f43](https://github.com/edgeandnode/dipper/commit/2ef6f4300b8aa43a25d4838819865bd2d2f44aac))
* **ci:** use ghcr.io for container image buildcache ([#59](https://github.com/edgeandnode/dipper/issues/59)) ([1896f19](https://github.com/edgeandnode/dipper/commit/1896f1983df0a48c4040cff7f83aeb80df43612f))
* **config:** migrate config .github/renovate.json5 ([#400](https://github.com/edgeandnode/dipper/issues/400)) ([7d70bd7](https://github.com/edgeandnode/dipper/commit/7d70bd785a514eaece3e100000eee90cbc219e65))
* cut the dead cancel path and cancel on-chain ([#614](https://github.com/edgeandnode/dipper/issues/614)) ([7d85f4d](https://github.com/edgeandnode/dipper/commit/7d85f4db58b27231873a899a42bdacb32d367d58))
* **deps:** add find-libpython dependency to project ([#440](https://github.com/edgeandnode/dipper/issues/440)) ([d4d8a03](https://github.com/edgeandnode/dipper/commit/d4d8a032a07a34c1ff92e67f6b9f8c85982eebf1))
* **deps:** add tracing logger ([#124](https://github.com/edgeandnode/dipper/issues/124)) ([ea72fe0](https://github.com/edgeandnode/dipper/commit/ea72fe092b91582c7986cf860786dc35c2b42688))
* **deps:** lock file maintenance ([#101](https://github.com/edgeandnode/dipper/issues/101)) ([19afb48](https://github.com/edgeandnode/dipper/commit/19afb4811ecb8a90966cc1f42f3d21a84791f5cc))
* **deps:** lock file maintenance ([#166](https://github.com/edgeandnode/dipper/issues/166)) ([e7f4a8e](https://github.com/edgeandnode/dipper/commit/e7f4a8e5d6e0f24835e13353d28fbfa2e4870607))
* **deps:** lock file maintenance ([#192](https://github.com/edgeandnode/dipper/issues/192)) ([eba0e38](https://github.com/edgeandnode/dipper/commit/eba0e3826b57d8f86e9b3e7c331b28606eaf0ffe))
* **deps:** lock file maintenance ([#206](https://github.com/edgeandnode/dipper/issues/206)) ([b597333](https://github.com/edgeandnode/dipper/commit/b5973332d4712c7a4a43ca69c3b7c95d5b2a303f))
* **deps:** lock file maintenance ([#277](https://github.com/edgeandnode/dipper/issues/277)) ([597fc93](https://github.com/edgeandnode/dipper/commit/597fc93665982e2aa61b85ae8b9b16add25d4967))
* **deps:** lock file maintenance ([#315](https://github.com/edgeandnode/dipper/issues/315)) ([2deca56](https://github.com/edgeandnode/dipper/commit/2deca56f2a01fb38ebaa8037ea07460e25fc3a5c))
* **deps:** lock file maintenance ([#350](https://github.com/edgeandnode/dipper/issues/350)) ([fb71a42](https://github.com/edgeandnode/dipper/commit/fb71a42ca1c09e71a8971c24bf1a7b94e7e483f9))
* **deps:** lock file maintenance ([#384](https://github.com/edgeandnode/dipper/issues/384)) ([cdf6983](https://github.com/edgeandnode/dipper/commit/cdf6983c0c2d04ef2d559354483b969b5eeceb06))
* **deps:** lock file maintenance ([#424](https://github.com/edgeandnode/dipper/issues/424)) ([7a5c92a](https://github.com/edgeandnode/dipper/commit/7a5c92af93a6bc4c748dbec3fc7a3894ef412376))
* **deps:** lock file maintenance ([#435](https://github.com/edgeandnode/dipper/issues/435)) ([aaf5ce7](https://github.com/edgeandnode/dipper/commit/aaf5ce7becd1b978c0ae4fd4d4d5551187d1f200))
* **deps:** lock file maintenance ([#54](https://github.com/edgeandnode/dipper/issues/54)) ([affd6e1](https://github.com/edgeandnode/dipper/commit/affd6e1854152da99ad8c76120989f743337370c))
* **deps:** lock file maintenance ([#78](https://github.com/edgeandnode/dipper/issues/78)) ([6b1a35a](https://github.com/edgeandnode/dipper/commit/6b1a35a51f8c7e2e69047932b1e8e0dbf33612d5))
* **deps:** lock file maintenance ([#80](https://github.com/edgeandnode/dipper/issues/80)) ([0a9b230](https://github.com/edgeandnode/dipper/commit/0a9b230f7b087d000f52d8d4988d771b545777e8))
* **deps:** lock file maintenance ([#96](https://github.com/edgeandnode/dipper/issues/96)) ([43a2c05](https://github.com/edgeandnode/dipper/commit/43a2c050f3240332c4d3e5a2378df351144e0bb7))
* **deps:** remove direct dependency on alloy-sol-types ([#154](https://github.com/edgeandnode/dipper/issues/154)) ([a2dba1a](https://github.com/edgeandnode/dipper/commit/a2dba1ad9b7da1ab607880ebee7d6bdad882e4f9))
* **deps:** remove unused dependencies ([#118](https://github.com/edgeandnode/dipper/issues/118)) ([041cf6a](https://github.com/edgeandnode/dipper/commit/041cf6af55c14b9a41bd7abdb61d1582ee114d46))
* **deps:** update actions-rust-lang/setup-rust-toolchain digest to 02be93d ([#476](https://github.com/edgeandnode/dipper/issues/476)) ([2468f06](https://github.com/edgeandnode/dipper/commit/2468f066a652286c584307896a2d6b07e1dad540))
* **deps:** update actions-rust-lang/setup-rust-toolchain digest to 11df97a ([#97](https://github.com/edgeandnode/dipper/issues/97)) ([7986ea5](https://github.com/edgeandnode/dipper/commit/7986ea5e9116a19a8a5ee7fa6d3c412c9a2d65f3))
* **deps:** update actions-rust-lang/setup-rust-toolchain digest to 1780873 ([#478](https://github.com/edgeandnode/dipper/issues/478)) ([7888f84](https://github.com/edgeandnode/dipper/commit/7888f84a4acdd95ebf34067950783122cbcf268b))
* **deps:** update actions-rust-lang/setup-rust-toolchain digest to 2fcdc49 ([#468](https://github.com/edgeandnode/dipper/issues/468)) ([3dbb607](https://github.com/edgeandnode/dipper/commit/3dbb607e0402ae077af66eabb1710c5b815dc17b))
* **deps:** update actions-rust-lang/setup-rust-toolchain digest to 4d1965c ([#87](https://github.com/edgeandnode/dipper/issues/87)) ([33b1072](https://github.com/edgeandnode/dipper/commit/33b1072f1b80a9669709476e63799920014dab61))
* **deps:** update actions-rust-lang/setup-rust-toolchain digest to 9399c7b ([#305](https://github.com/edgeandnode/dipper/issues/305)) ([0cc50c6](https://github.com/edgeandnode/dipper/commit/0cc50c6888a257618e34c5311919451c2d435e7a))
* **deps:** update actions-rust-lang/setup-rust-toolchain digest to 9d7e65c ([#396](https://github.com/edgeandnode/dipper/issues/396)) ([37eb8c2](https://github.com/edgeandnode/dipper/commit/37eb8c24049263d796208ddcbb10e0cbc07648f7))
* **deps:** update actions-rust-lang/setup-rust-toolchain digest to ac90e63 ([#464](https://github.com/edgeandnode/dipper/issues/464)) ([0fc3e9c](https://github.com/edgeandnode/dipper/commit/0fc3e9c4ab0abcc7ddfb73353210fbb0c7068c3a))
* **deps:** update actions-rust-lang/setup-rust-toolchain digest to fb51252 ([#449](https://github.com/edgeandnode/dipper/issues/449)) ([d8ebfe8](https://github.com/edgeandnode/dipper/commit/d8ebfe88e5c97e2693896a3ae043d75529b9ee1a))
* **deps:** update actions/checkout digest to 08eba0b ([#465](https://github.com/edgeandnode/dipper/issues/465)) ([198cf03](https://github.com/edgeandnode/dipper/commit/198cf033fb1342ceca79eda5a40c3f487c872b18))
* **deps:** update actions/checkout digest to 11bd719 ([#119](https://github.com/edgeandnode/dipper/issues/119)) ([0670df2](https://github.com/edgeandnode/dipper/commit/0670df2b82755dba2a509a17c22bd06f2651d33a))
* **deps:** update actions/checkout digest to eef6144 ([#108](https://github.com/edgeandnode/dipper/issues/108)) ([11b864c](https://github.com/edgeandnode/dipper/commit/11b864cbfea21c67c22395cb8a564248ea712181))
* **deps:** update actions/setup-python digest to f677139 ([#53](https://github.com/edgeandnode/dipper/issues/53)) ([becbb18](https://github.com/edgeandnode/dipper/commit/becbb18ce4032ec2a5e3ef81d81ed4471646c92f))
* **deps:** update actions/upload-artifact digest to 4cec3d8 ([#301](https://github.com/edgeandnode/dipper/issues/301)) ([c726f49](https://github.com/edgeandnode/dipper/commit/c726f4945c9b0349b812f328f7f5ec9d48981078))
* **deps:** update actions/upload-artifact digest to 65c4c4a ([#246](https://github.com/edgeandnode/dipper/issues/246)) ([d5f881d](https://github.com/edgeandnode/dipper/commit/d5f881d3c7843bcb3e161a9250bf7d8bcd34195b))
* **deps:** update actions/upload-artifact digest to 6f51ac0 ([#236](https://github.com/edgeandnode/dipper/issues/236)) ([20bae4c](https://github.com/edgeandnode/dipper/commit/20bae4ce8c55b01b5f889698ee8f494bd85811ce))
* **deps:** update actions/upload-artifact digest to ea165f8 ([#343](https://github.com/edgeandnode/dipper/issues/343)) ([b33ec18](https://github.com/edgeandnode/dipper/commit/b33ec18d6949bf511a303e8ecbfb391e59256856))
* **deps:** update astral-sh/setup-uv action to v3 ([#94](https://github.com/edgeandnode/dipper/issues/94)) ([f15d07d](https://github.com/edgeandnode/dipper/commit/f15d07d00ac3696ce0d7f9e3639c46b64ad95f4a))
* **deps:** update astral-sh/setup-uv action to v4 ([#191](https://github.com/edgeandnode/dipper/issues/191)) ([b80affa](https://github.com/edgeandnode/dipper/commit/b80affab7b04f1d3328262f9ec1b271cd52ba33b))
* **deps:** update astral-sh/setup-uv action to v5 ([#265](https://github.com/edgeandnode/dipper/issues/265)) ([ba325ff](https://github.com/edgeandnode/dipper/commit/ba325ff5320f398edc403210282d892df3bde517))
* **deps:** update astral-sh/setup-uv action to v6 ([#414](https://github.com/edgeandnode/dipper/issues/414)) ([86b1e6a](https://github.com/edgeandnode/dipper/commit/86b1e6a227d371252b888b0779872fe9b49bf636))
* **deps:** update astral-sh/setup-uv digest to 0c5e2b8 ([#368](https://github.com/edgeandnode/dipper/issues/368)) ([74e4951](https://github.com/edgeandnode/dipper/commit/74e4951af02f2ae5d51c71e4298df0fc340ecd0e))
* **deps:** update astral-sh/setup-uv digest to 1edb525 ([#302](https://github.com/edgeandnode/dipper/issues/302)) ([642972e](https://github.com/edgeandnode/dipper/commit/642972ec967cd94249a9582712d6c9d500364ce6))
* **deps:** update astral-sh/setup-uv digest to 2269511 ([#354](https://github.com/edgeandnode/dipper/issues/354)) ([2d14096](https://github.com/edgeandnode/dipper/commit/2d1409659471d1ebb48e472b8e232c9fde269d19))
* **deps:** update astral-sh/setup-uv digest to 2e657c1 ([#150](https://github.com/edgeandnode/dipper/issues/150)) ([c2b2b6d](https://github.com/edgeandnode/dipper/commit/c2b2b6dcc35874d91d5597cbbf139ec3ba47d824))
* **deps:** update astral-sh/setup-uv digest to 38f3f10 ([#210](https://github.com/edgeandnode/dipper/issues/210)) ([14808b1](https://github.com/edgeandnode/dipper/commit/14808b19d8a7b1e094ed9a0ccabf3493120cd68e))
* **deps:** update astral-sh/setup-uv digest to 3b9817b ([#120](https://github.com/edgeandnode/dipper/issues/120)) ([26ffd29](https://github.com/edgeandnode/dipper/commit/26ffd29736309449c6ec4f5743576e9fe4a440bd))
* **deps:** update astral-sh/setup-uv digest to 445689e ([#450](https://github.com/edgeandnode/dipper/issues/450)) ([fa8c595](https://github.com/edgeandnode/dipper/commit/fa8c595c8b1df90123971c6f540c5f0a9402dbdd))
* **deps:** update astral-sh/setup-uv digest to 4959332 ([#451](https://github.com/edgeandnode/dipper/issues/451)) ([34f56dc](https://github.com/edgeandnode/dipper/commit/34f56dc5a56123dc3b444cbba21e7fe749961479))
* **deps:** update astral-sh/setup-uv digest to 4db9619 ([#278](https://github.com/edgeandnode/dipper/issues/278)) ([3e3ef06](https://github.com/edgeandnode/dipper/commit/3e3ef060cc5b0eb08869c19faee73ef1b15b4524))
* **deps:** update astral-sh/setup-uv digest to 557e51d ([#466](https://github.com/edgeandnode/dipper/issues/466)) ([6fc1594](https://github.com/edgeandnode/dipper/commit/6fc1594717a1a1c3a414f4c0493602464e09ae23))
* **deps:** update astral-sh/setup-uv digest to 5f42d5a ([#197](https://github.com/edgeandnode/dipper/issues/197)) ([2de39ae](https://github.com/edgeandnode/dipper/commit/2de39aed618aac0d9d52f1372ad9201867f468fd))
* **deps:** update astral-sh/setup-uv digest to 6dfebec ([#77](https://github.com/edgeandnode/dipper/issues/77)) ([c9d371e](https://github.com/edgeandnode/dipper/commit/c9d371e8697efeb1be70b3ed6b61ad8b2d018fd5))
* **deps:** update astral-sh/setup-uv digest to b463f5b ([#60](https://github.com/edgeandnode/dipper/issues/60)) ([9e3a8f7](https://github.com/edgeandnode/dipper/commit/9e3a8f7f3e2c10d6d91ad171e4fe17d7afae3a26))
* **deps:** update astral-sh/setup-uv digest to b5f58b2 ([#266](https://github.com/edgeandnode/dipper/issues/266)) ([05b39af](https://github.com/edgeandnode/dipper/commit/05b39af90cd0e0961fe027e87d3d101dedea13be))
* **deps:** update astral-sh/setup-uv digest to b75a909 ([#469](https://github.com/edgeandnode/dipper/issues/469)) ([9388f0b](https://github.com/edgeandnode/dipper/commit/9388f0beb0f4a405ecfdd6857964e14543520606))
* **deps:** update astral-sh/setup-uv digest to caf0cab ([#187](https://github.com/edgeandnode/dipper/issues/187)) ([5371cae](https://github.com/edgeandnode/dipper/commit/5371caec6bc1e8d63428042a26d599491b7d9175))
* **deps:** update astral-sh/setup-uv digest to d0cc045 ([#479](https://github.com/edgeandnode/dipper/issues/479)) ([c18ed35](https://github.com/edgeandnode/dipper/commit/c18ed35594dc6880e4837aff49c228a9ea635352))
* **deps:** update astral-sh/setup-uv digest to d4b2f3b ([#394](https://github.com/edgeandnode/dipper/issues/394)) ([5182291](https://github.com/edgeandnode/dipper/commit/518229160179abebeb94a35c67076e808ac772ed))
* **deps:** update astral-sh/setup-uv digest to e779db7 ([#159](https://github.com/edgeandnode/dipper/issues/159)) ([04457dd](https://github.com/edgeandnode/dipper/commit/04457dd4e62e88a12b831ee260bf91df6c8eaf6a))
* **deps:** update astral-sh/setup-uv digest to f3bcaeb ([#104](https://github.com/edgeandnode/dipper/issues/104)) ([56c4f41](https://github.com/edgeandnode/dipper/commit/56c4f417614bf627c0c39ffed13cbcc7c648af27))
* **deps:** update astral-sh/setup-uv digest to f94ec6b ([#316](https://github.com/edgeandnode/dipper/issues/316)) ([dab2571](https://github.com/edgeandnode/dipper/commit/dab257155e0019e07e14aacd2c31d1c33e22173d))
* **deps:** update dependency faker to &gt;=33,&lt;33.2 ([#204](https://github.com/edgeandnode/dipper/issues/204)) ([50ac718](https://github.com/edgeandnode/dipper/commit/50ac718a80e722d0f38f77606e9e22d2f5bef806))
* **deps:** update dependency faker to &gt;=33,&lt;33.4 ([#255](https://github.com/edgeandnode/dipper/issues/255)) ([22fd200](https://github.com/edgeandnode/dipper/commit/22fd20070d5cccee3eb55898dac840da313f8706))
* **deps:** update dependency faker to &gt;=35,&lt;35.3 ([#297](https://github.com/edgeandnode/dipper/issues/297)) ([53ebb9a](https://github.com/edgeandnode/dipper/commit/53ebb9a7dc0f11fba386569cb9c25c657eff8bac))
* **deps:** update dependency faker to &gt;=37,&lt;37.2 ([#359](https://github.com/edgeandnode/dipper/issues/359)) ([d2204b5](https://github.com/edgeandnode/dipper/commit/d2204b5d96d3480328b92bdad2ab16ca502a1d79))
* **deps:** update dependency faker to &gt;=37,&lt;37.4 ([#419](https://github.com/edgeandnode/dipper/issues/419)) ([99faf2d](https://github.com/edgeandnode/dipper/commit/99faf2df28df1e1e5c36e23a30042d752c1e7d8d))
* **deps:** update dependency faker to &gt;=37,&lt;37.6 ([#456](https://github.com/edgeandnode/dipper/issues/456)) ([fb9448b](https://github.com/edgeandnode/dipper/commit/fb9448bee13ee1c9bb8206693432b25677af2e55))
* **deps:** update dependency faker to &gt;=37,&lt;37.9 ([#481](https://github.com/edgeandnode/dipper/issues/481)) ([86636eb](https://github.com/edgeandnode/dipper/commit/86636ebb126710722b58e590d0046b734a5d4d3d))
* **deps:** update dependency faker to v33 ([#165](https://github.com/edgeandnode/dipper/issues/165)) ([d16ac57](https://github.com/edgeandnode/dipper/commit/d16ac5766386714fe216e54ad0fa684aa3792d2d))
* **deps:** update dependency faker to v35 ([#276](https://github.com/edgeandnode/dipper/issues/276)) ([9365e6d](https://github.com/edgeandnode/dipper/commit/9365e6daf32b60e8ef13db9e8ddf99598241ab5d))
* **deps:** update dependency faker to v36 ([#313](https://github.com/edgeandnode/dipper/issues/313)) ([5f3e086](https://github.com/edgeandnode/dipper/commit/5f3e086b5ab7c8247105c61a28dd3aa3010647f5))
* **deps:** update dependency faker to v37 ([#349](https://github.com/edgeandnode/dipper/issues/349)) ([f93066d](https://github.com/edgeandnode/dipper/commit/f93066d9dd8ea6789bf7e62e5efe3956df4db01c))
* **deps:** update dependency find-libpython to &gt;=0.5,&lt;0.6 ([#499](https://github.com/edgeandnode/dipper/issues/499)) ([b406011](https://github.com/edgeandnode/dipper/commit/b406011c1d5e289f067fcd4cbdfaa9ff76f07d5d))
* **deps:** update dependency pandera to &gt;=0.21,&lt;0.22 ([#163](https://github.com/edgeandnode/dipper/issues/163)) ([6b70871](https://github.com/edgeandnode/dipper/commit/6b70871150bd6b317b7b25f36578fdfaa37358fe))
* **deps:** update dependency pandera to &gt;=0.22,&lt;0.23 ([#243](https://github.com/edgeandnode/dipper/issues/243)) ([b49528d](https://github.com/edgeandnode/dipper/commit/b49528d018b4f675dc0adff96856e77be5da82d6))
* **deps:** update dependency pandera to &gt;=0.23,&lt;0.24 ([#352](https://github.com/edgeandnode/dipper/issues/352)) ([422520a](https://github.com/edgeandnode/dipper/commit/422520ad53404e39db98c6435fe460a95721a5d3))
* **deps:** update dependency ruff to &gt;=0.11,&lt;0.12 ([#353](https://github.com/edgeandnode/dipper/issues/353)) ([08f28e4](https://github.com/edgeandnode/dipper/commit/08f28e4b5e08fa5d93a7252c8e9d3534fa0591e7))
* **deps:** update dependency ruff to &gt;=0.7,&lt;0.8 ([#115](https://github.com/edgeandnode/dipper/issues/115)) ([8394c2d](https://github.com/edgeandnode/dipper/commit/8394c2deba0fd7c801be0abdb1b76375e8cc3edb))
* **deps:** update dependency ruff to &gt;=0.8,&lt;0.9 ([#190](https://github.com/edgeandnode/dipper/issues/190)) ([cbb34c7](https://github.com/edgeandnode/dipper/commit/cbb34c77a156f3c27973760edc8d01e75ace99d2))
* **deps:** update dependency ruff to &gt;=0.9,&lt;0.10 ([#256](https://github.com/edgeandnode/dipper/issues/256)) ([9ca516b](https://github.com/edgeandnode/dipper/commit/9ca516bdd4187d49bc7b1900636b7cc6e7e8425c))
* **deps:** update dependency rust to v1.81.0 ([#61](https://github.com/edgeandnode/dipper/issues/61)) ([8484288](https://github.com/edgeandnode/dipper/commit/84842884683eecb05c445ccd39d00596e745be59))
* **deps:** update dependency rust to v1.82.0 ([#111](https://github.com/edgeandnode/dipper/issues/111)) ([083b26c](https://github.com/edgeandnode/dipper/commit/083b26c36b073a83f6fcb30fde044d80972f388c))
* **deps:** update dependency rust to v1.83.0 ([#205](https://github.com/edgeandnode/dipper/issues/205)) ([644e86c](https://github.com/edgeandnode/dipper/commit/644e86c2c09fd17c7111abb40a9f401a642c145a))
* **deps:** update dependency rust to v1.84.0 ([#257](https://github.com/edgeandnode/dipper/issues/257)) ([dddf2e5](https://github.com/edgeandnode/dipper/commit/dddf2e5f53ac6777df17b040583fd953687be647))
* **deps:** update dependency rust to v1.84.1 ([#279](https://github.com/edgeandnode/dipper/issues/279)) ([ba3ade5](https://github.com/edgeandnode/dipper/commit/ba3ade58127b0b1ed19d36f7d91b0aa9ea68451c))
* **deps:** update dependency rust to v1.85.0 ([#306](https://github.com/edgeandnode/dipper/issues/306)) ([2ac85ca](https://github.com/edgeandnode/dipper/commit/2ac85ca2b8aa4f095ac9c3e02d9df2e5d50ff5bc))
* **deps:** update dependency rust to v1.85.1 ([#344](https://github.com/edgeandnode/dipper/issues/344)) ([e1e5bef](https://github.com/edgeandnode/dipper/commit/e1e5bef872a32448f1d12f0d0e05bcce3a800a59))
* **deps:** update dependency rust to v1.86.0 ([#381](https://github.com/edgeandnode/dipper/issues/381)) ([0dc7ba5](https://github.com/edgeandnode/dipper/commit/0dc7ba55dfd72fb7dbee3395ff3547cecca55d70))
* **deps:** update dependency rust to v1.87.0 ([#409](https://github.com/edgeandnode/dipper/issues/409)) ([c7a3dfd](https://github.com/edgeandnode/dipper/commit/c7a3dfd8113e7082dd6b446a190dd1567299da19))
* **deps:** update dependency rust to v1.89.0 ([#459](https://github.com/edgeandnode/dipper/issues/459)) ([b765d52](https://github.com/edgeandnode/dipper/commit/b765d52f4a8d05dae08190a757554f9ca50ecfa8))
* **deps:** update docker/build-push-action digest to 0adf995 ([#303](https://github.com/edgeandnode/dipper/issues/303)) ([2d44387](https://github.com/edgeandnode/dipper/commit/2d443872f5f36ab3eb291f884731a29e6bd1d589))
* **deps:** update docker/build-push-action digest to 14487ce ([#397](https://github.com/edgeandnode/dipper/issues/397)) ([6e5c5a4](https://github.com/edgeandnode/dipper/commit/6e5c5a45422aed895577f66be06c359ea6b188bb))
* **deps:** update docker/build-push-action digest to 1dc7386 ([#403](https://github.com/edgeandnode/dipper/issues/403)) ([f66033f](https://github.com/edgeandnode/dipper/commit/f66033ffae66e89812fc8be3c0f4811272419ab8))
* **deps:** update docker/build-push-action digest to 2634353 ([#415](https://github.com/edgeandnode/dipper/issues/415)) ([56ff4c7](https://github.com/edgeandnode/dipper/commit/56ff4c73935753dcb13c2c9ff48f1b02aadc5c9e))
* **deps:** update docker/build-push-action digest to 471d1dc ([#317](https://github.com/edgeandnode/dipper/issues/317)) ([823174c](https://github.com/edgeandnode/dipper/commit/823174cf00b73cddf5cfa9eea8e160678d21d9d5))
* **deps:** update docker/build-push-action digest to 48aba3b ([#198](https://github.com/edgeandnode/dipper/issues/198)) ([194fe1a](https://github.com/edgeandnode/dipper/commit/194fe1a9014c76f26dfd9bf64a1d852bebb713b1))
* **deps:** update docker/build-push-action digest to 4f58ea7 ([#92](https://github.com/edgeandnode/dipper/issues/92)) ([a24eef5](https://github.com/edgeandnode/dipper/commit/a24eef5789700e4010ac4587cecac5a17145230c))
* **deps:** update docker/build-push-action digest to 67a2d40 ([#267](https://github.com/edgeandnode/dipper/issues/267)) ([6bcdd5f](https://github.com/edgeandnode/dipper/commit/6bcdd5f10308e490f4650dee3f4cb450a923bef7))
* **deps:** update docker/build-push-action digest to b32b51a ([#247](https://github.com/edgeandnode/dipper/issues/247)) ([7b4151d](https://github.com/edgeandnode/dipper/commit/7b4151db05742f8a6499cbd768a00243792ffa56))
* **deps:** update docker/build-push-action digest to ca877d9 ([#270](https://github.com/edgeandnode/dipper/issues/270)) ([5e9a178](https://github.com/edgeandnode/dipper/commit/5e9a17849eeb2e5096c908a726f3064a51094a6c))
* **deps:** update docker/login-action digest to 184bdaa ([#460](https://github.com/edgeandnode/dipper/issues/460)) ([ddc1e91](https://github.com/edgeandnode/dipper/commit/ddc1e9115da8bdd1e8dbaf9e129190ca3c43075f))
* **deps:** update docker/login-action digest to 5e57cd1 ([#480](https://github.com/edgeandnode/dipper/issues/480)) ([fa22fb7](https://github.com/edgeandnode/dipper/commit/fa22fb762a7996fe13e98b2a8c3bb9139e22ba5a))
* **deps:** update docker/login-action digest to 74a5d14 ([#331](https://github.com/edgeandnode/dipper/issues/331)) ([04aca8b](https://github.com/edgeandnode/dipper/commit/04aca8b53915ff91084d1354b9fc4c120ba7c8bf))
* **deps:** update docker/metadata-action digest to 369eb59 ([#188](https://github.com/edgeandnode/dipper/issues/188)) ([520936f](https://github.com/edgeandnode/dipper/commit/520936fab5910088fa5217c4fcba46c7f038e0b5))
* **deps:** update docker/metadata-action digest to 902fa8e ([#329](https://github.com/edgeandnode/dipper/issues/329)) ([7587ae4](https://github.com/edgeandnode/dipper/commit/7587ae4d5ae8acf5c831d932b89f078f1e0f81b7))
* **deps:** update docker/metadata-action digest to c1e5197 ([#461](https://github.com/edgeandnode/dipper/issues/461)) ([e5aa193](https://github.com/edgeandnode/dipper/commit/e5aa19314f63e12aea854778cc547e34209b3649))
* **deps:** update docker/setup-buildx-action digest to 6524bf6 ([#237](https://github.com/edgeandnode/dipper/issues/237)) ([2f6c89e](https://github.com/edgeandnode/dipper/commit/2f6c89e5fe0e662da0b5bb783f540d5b10a87cc5))
* **deps:** update docker/setup-buildx-action digest to b5ca514 ([#330](https://github.com/edgeandnode/dipper/issues/330)) ([a1bb9b9](https://github.com/edgeandnode/dipper/commit/a1bb9b9315284d375c8c92f5848291cfbb86efde))
* **deps:** update docker/setup-buildx-action digest to c47758b ([#105](https://github.com/edgeandnode/dipper/issues/105)) ([4207a78](https://github.com/edgeandnode/dipper/commit/4207a78c87f5f8509be6ffdc2f6245e8e33026d9))
* **deps:** update docker/setup-buildx-action digest to e468171 ([#452](https://github.com/edgeandnode/dipper/issues/452)) ([df8edb2](https://github.com/edgeandnode/dipper/commit/df8edb2ea647902fead678abd87720f09648e983))
* **deps:** update docker/setup-buildx-action digest to f7ce87c ([#292](https://github.com/edgeandnode/dipper/issues/292)) ([58e4b6e](https://github.com/edgeandnode/dipper/commit/58e4b6e08073865ed542df7511f04a822f7f4874))
* **deps:** update leafwing-studios/cargo-cache digest to 43ec9a5 ([#398](https://github.com/edgeandnode/dipper/issues/398)) ([e0de670](https://github.com/edgeandnode/dipper/commit/e0de670c03a200aea8ac0393883f26653707dc8d))
* **deps:** update leafwing-studios/cargo-cache digest to 5d5d363 ([#39](https://github.com/edgeandnode/dipper/issues/39)) ([ceabd29](https://github.com/edgeandnode/dipper/commit/ceabd29f96630c99b3b965a0b359949481ac769e))
* **deps:** update leafwing-studios/cargo-cache digest to a0709d8 ([#244](https://github.com/edgeandnode/dipper/issues/244)) ([c9fc60a](https://github.com/edgeandnode/dipper/commit/c9fc60ac9d37e9458865faed6b676992d6c98e9e))
* **deps:** update multiple dependencies ([#412](https://github.com/edgeandnode/dipper/issues/412)) ([54d6924](https://github.com/edgeandnode/dipper/commit/54d6924af731954512741fb6a02499c954de4736))
* **deps:** update nhedger/setup-sops digest to 187c90d ([#395](https://github.com/edgeandnode/dipper/issues/395)) ([bfb4a54](https://github.com/edgeandnode/dipper/commit/bfb4a54b7ea41aaf63f2a481760df29c9fccefbe))
* **deps:** update nhedger/setup-sops digest to 1912bba ([#245](https://github.com/edgeandnode/dipper/issues/245)) ([97f4927](https://github.com/edgeandnode/dipper/commit/97f49272d430717511d8f4b8c1c4502d98fd09d3))
* **deps:** update nhedger/setup-sops digest to 4cb6513 ([#293](https://github.com/edgeandnode/dipper/issues/293)) ([d55157b](https://github.com/edgeandnode/dipper/commit/d55157b64673f38746d635701f51041f718bd9e1))
* **deps:** update python docker tag to v3.12.6 ([#74](https://github.com/edgeandnode/dipper/issues/74)) ([4c7eebe](https://github.com/edgeandnode/dipper/commit/4c7eebe32a9b78c0affecfa1a582f8da86919066))
* **deps:** update python docker tag to v3.13.3 ([#420](https://github.com/edgeandnode/dipper/issues/420)) ([5b8615e](https://github.com/edgeandnode/dipper/commit/5b8615e05e5d54aa8dfb690df0395a48bea4a563))
* **deps:** update python docker tag to v3.13.5 ([#444](https://github.com/edgeandnode/dipper/issues/444)) ([87cf37e](https://github.com/edgeandnode/dipper/commit/87cf37e36be4cef6f9aacfa9668a14893a10e194))
* **deps:** update python docker tag to v3.13.7 ([#462](https://github.com/edgeandnode/dipper/issues/462)) ([9e70b8f](https://github.com/edgeandnode/dipper/commit/9e70b8f4130ff5186bd08c9a3c5700837fd91bcc))
* **deps:** update rust crate anyhow to v1.0.100 ([#472](https://github.com/edgeandnode/dipper/issues/472)) ([19ec30e](https://github.com/edgeandnode/dipper/commit/19ec30ed17b9bae8c366f9bf19f4d566762bbd2c))
* **deps:** update rust crate anyhow to v1.0.90 ([#112](https://github.com/edgeandnode/dipper/issues/112)) ([2d5849f](https://github.com/edgeandnode/dipper/commit/2d5849fb526d0d4ea62b1040da8197248e3b6a54))
* **deps:** update rust crate anyhow to v1.0.91 ([#121](https://github.com/edgeandnode/dipper/issues/121)) ([342d06d](https://github.com/edgeandnode/dipper/commit/342d06d96d905aab95d40c0fe20af83d79a1977e))
* **deps:** update rust crate anyhow to v1.0.92 ([#126](https://github.com/edgeandnode/dipper/issues/126)) ([c395a55](https://github.com/edgeandnode/dipper/commit/c395a554cd645310c3e449386697bb89e9bb7df4))
* **deps:** update rust crate anyhow to v1.0.94 ([#218](https://github.com/edgeandnode/dipper/issues/218)) ([453eaee](https://github.com/edgeandnode/dipper/commit/453eaee6e03e6a40a765d9684c969d9b228a58fa))
* **deps:** update rust crate anyhow to v1.0.95 ([#238](https://github.com/edgeandnode/dipper/issues/238)) ([9ebe818](https://github.com/edgeandnode/dipper/commit/9ebe818ea34a3be0241063316c2b0a3f795d76ee))
* **deps:** update rust crate anyhow to v1.0.96 ([#304](https://github.com/edgeandnode/dipper/issues/304)) ([095bfc0](https://github.com/edgeandnode/dipper/commit/095bfc058cc82ce43631a27a0bca9e03e19b1498))
* **deps:** update rust crate anyhow to v1.0.97 ([#332](https://github.com/edgeandnode/dipper/issues/332)) ([1be4c49](https://github.com/edgeandnode/dipper/commit/1be4c4932cdde9c62f25d542f29e3e0b6b4cebf3))
* **deps:** update rust crate anyhow to v1.0.98 ([#392](https://github.com/edgeandnode/dipper/issues/392)) ([77ba9d8](https://github.com/edgeandnode/dipper/commit/77ba9d8c703c15497f52b6506da5da96ff62195f))
* **deps:** update rust crate anyhow to v1.0.99 ([#467](https://github.com/edgeandnode/dipper/issues/467)) ([5d3629c](https://github.com/edgeandnode/dipper/commit/5d3629c175a8b14a779634e23dd4cd6cb2d99461))
* **deps:** update rust crate async-signal to v0.2.13 ([#470](https://github.com/edgeandnode/dipper/issues/470)) ([f643095](https://github.com/edgeandnode/dipper/commit/f643095b9d2b46651983fd72776b94a044ad9db1))
* **deps:** update rust crate async-trait to v0.1.85 ([#248](https://github.com/edgeandnode/dipper/issues/248)) ([43446e3](https://github.com/edgeandnode/dipper/commit/43446e3615e1ec96e5218e86663c45acfbbfadde))
* **deps:** update rust crate async-trait to v0.1.86 ([#280](https://github.com/edgeandnode/dipper/issues/280)) ([9fbea2e](https://github.com/edgeandnode/dipper/commit/9fbea2e056896265330b23be878446ac93790b2c))
* **deps:** update rust crate async-trait to v0.1.88 ([#334](https://github.com/edgeandnode/dipper/issues/334)) ([3a7568f](https://github.com/edgeandnode/dipper/commit/3a7568f15619ad09ff4f81f77d7246e456109791))
* **deps:** update rust crate async-trait to v0.1.89 ([#471](https://github.com/edgeandnode/dipper/issues/471)) ([92a8043](https://github.com/edgeandnode/dipper/commit/92a8043af745f3d38ddaf1ed58c1046b63e47f13))
* **deps:** update rust crate axum to v0.7.7 ([#88](https://github.com/edgeandnode/dipper/issues/88)) ([a0f389f](https://github.com/edgeandnode/dipper/commit/a0f389fa5d38e3e5806f71e96fcfb234cb88d4bf))
* **deps:** update rust crate clap to v4.5.18 ([#89](https://github.com/edgeandnode/dipper/issues/89)) ([5842a93](https://github.com/edgeandnode/dipper/commit/5842a93885ec67f82638c909450cbfee3d31db3a))
* **deps:** update rust crate clap to v4.5.19 ([#98](https://github.com/edgeandnode/dipper/issues/98)) ([2241e99](https://github.com/edgeandnode/dipper/commit/2241e999d4f951102d623f60b8cdf11a63593f0b))
* **deps:** update rust crate clap to v4.5.20 ([#109](https://github.com/edgeandnode/dipper/issues/109)) ([58503fb](https://github.com/edgeandnode/dipper/commit/58503fb824d22f7d3e68d8cb175f8f0af44df422))
* **deps:** update rust crate clap to v4.5.21 ([#160](https://github.com/edgeandnode/dipper/issues/160)) ([c79991d](https://github.com/edgeandnode/dipper/commit/c79991d2f443bfcdb8d5d3f7c2a555e98c473033))
* **deps:** update rust crate clap to v4.5.23 ([#219](https://github.com/edgeandnode/dipper/issues/219)) ([a73ff1f](https://github.com/edgeandnode/dipper/commit/a73ff1f20babd9442fac83f0468a254cdf72b7bc))
* **deps:** update rust crate clap to v4.5.26 ([#249](https://github.com/edgeandnode/dipper/issues/249)) ([d09d9b1](https://github.com/edgeandnode/dipper/commit/d09d9b15901d424f4c95aa3a9b0b5e5f09399ed0))
* **deps:** update rust crate clap to v4.5.27 ([#271](https://github.com/edgeandnode/dipper/issues/271)) ([a3284e6](https://github.com/edgeandnode/dipper/commit/a3284e67683372902bb45f9fe0ccc04e14f78a61))
* **deps:** update rust crate clap to v4.5.29 ([#294](https://github.com/edgeandnode/dipper/issues/294)) ([aa43e40](https://github.com/edgeandnode/dipper/commit/aa43e4011096baaab0b33f1653209720ab0bbc33))
* **deps:** update rust crate clap to v4.5.32 ([#335](https://github.com/edgeandnode/dipper/issues/335)) ([a3f2414](https://github.com/edgeandnode/dipper/commit/a3f2414c0175c90d10f2afd094539c0dcb0779b6))
* **deps:** update rust crate clap to v4.5.34 ([#369](https://github.com/edgeandnode/dipper/issues/369)) ([e355a66](https://github.com/edgeandnode/dipper/commit/e355a66f88e0a3b5ec9b0f5b81776a09ebd14884))
* **deps:** update rust crate clap to v4.5.35 ([#378](https://github.com/edgeandnode/dipper/issues/378)) ([3381550](https://github.com/edgeandnode/dipper/commit/3381550a549057f2af899927f050583fa8d5fcf9))
* **deps:** update rust crate clap to v4.5.36 ([#393](https://github.com/edgeandnode/dipper/issues/393)) ([e8b8845](https://github.com/edgeandnode/dipper/commit/e8b8845408a18662e12116bf24a93979a964113c))
* **deps:** update rust crate clap to v4.5.37 ([#399](https://github.com/edgeandnode/dipper/issues/399)) ([6f04861](https://github.com/edgeandnode/dipper/commit/6f04861a15e8ebe2aa5c8c60d3c9b69918cce2be))
* **deps:** update rust crate clap to v4.5.38 ([#401](https://github.com/edgeandnode/dipper/issues/401)) ([5616958](https://github.com/edgeandnode/dipper/commit/56169589c67d416896d135145b86266c6ffc8725))
* **deps:** update rust crate clap to v4.5.40 ([#447](https://github.com/edgeandnode/dipper/issues/447)) ([3bcb9c7](https://github.com/edgeandnode/dipper/commit/3bcb9c7648b6ab1853ccb994a0997983e01a8591))
* **deps:** update rust crate clap to v4.5.46 ([#457](https://github.com/edgeandnode/dipper/issues/457)) ([89bc034](https://github.com/edgeandnode/dipper/commit/89bc03442e1724c76533894b754c1315485ca3f1))
* **deps:** update rust crate clap to v4.5.48 ([#473](https://github.com/edgeandnode/dipper/issues/473)) ([369b2e5](https://github.com/edgeandnode/dipper/commit/369b2e599b5e2973331158ad42dd77abd0d189e6))
* **deps:** update rust crate clap to v4.5.49 ([#484](https://github.com/edgeandnode/dipper/issues/484)) ([01f2986](https://github.com/edgeandnode/dipper/commit/01f29865f199e4b1e6cbd311eba79a47c18d52ef))
* **deps:** update rust crate clap to v4.5.50 ([#486](https://github.com/edgeandnode/dipper/issues/486)) ([db4ca9b](https://github.com/edgeandnode/dipper/commit/db4ca9b06ca93f56cb23b6bac5c4b8e44bfd6eda))
* **deps:** update rust crate clap to v4.5.51 ([#490](https://github.com/edgeandnode/dipper/issues/490)) ([e93694e](https://github.com/edgeandnode/dipper/commit/e93694efcdcca1f84c846b622da2ac9a27dc9e3e))
* **deps:** update rust crate custom_debug to v0.6.2 ([#199](https://github.com/edgeandnode/dipper/issues/199)) ([68be845](https://github.com/edgeandnode/dipper/commit/68be845fcf8f8aef99ff91a70cd6fce0e3c89021))
* **deps:** update rust crate fake to v3.1.0 ([#258](https://github.com/edgeandnode/dipper/issues/258)) ([99ded35](https://github.com/edgeandnode/dipper/commit/99ded35f439bb8c361f0a0681cd8f4afc7fe00a5))
* **deps:** update rust crate fake to v4.2.0 ([#360](https://github.com/edgeandnode/dipper/issues/360)) ([24af8a3](https://github.com/edgeandnode/dipper/commit/24af8a39a9904be836256970d72aa2245357294c))
* **deps:** update rust crate fake to v4.3.0 ([#382](https://github.com/edgeandnode/dipper/issues/382)) ([989e08e](https://github.com/edgeandnode/dipper/commit/989e08e6be6abae7525e1822f7da391265d98bbb))
* **deps:** update rust crate futures-lite to v2.5.0 ([#152](https://github.com/edgeandnode/dipper/issues/152)) ([691d3bc](https://github.com/edgeandnode/dipper/commit/691d3bcc02e6dd431b3d512cb15396c0bd1420b4))
* **deps:** update rust crate futures-lite to v2.6.0 ([#259](https://github.com/edgeandnode/dipper/issues/259)) ([8d21fb6](https://github.com/edgeandnode/dipper/commit/8d21fb6417c9a0e1dac1a024bac01f4a882e24ca))
* **deps:** update rust crate futures-lite to v2.6.1 ([#463](https://github.com/edgeandnode/dipper/issues/463)) ([634854d](https://github.com/edgeandnode/dipper/commit/634854dbdcd636b9dd16e8bc331ba9b9fc086080))
* **deps:** update rust crate indoc to v2.0.6 ([#336](https://github.com/edgeandnode/dipper/issues/336)) ([b51cd9b](https://github.com/edgeandnode/dipper/commit/b51cd9b013014e5690838cdbc760d51eafcab38e))
* **deps:** update rust crate indoc to v2.0.7 ([#487](https://github.com/edgeandnode/dipper/issues/487)) ([f82d0c0](https://github.com/edgeandnode/dipper/commit/f82d0c0bd7fb3d4d8663aa4c655bf310c7318533))
* **deps:** update rust crate jsonrpsee to 0.26.0 ([#421](https://github.com/edgeandnode/dipper/issues/421)) ([d2557f1](https://github.com/edgeandnode/dipper/commit/d2557f15d95a633e16b3f7b135656f6121a7d74c))
* **deps:** update rust crate jsonrpsee to v0.24.8 ([#272](https://github.com/edgeandnode/dipper/issues/272)) ([8156d72](https://github.com/edgeandnode/dipper/commit/8156d727ae1d2142a4b21805a7181411a619157f))
* **deps:** update rust crate jsonrpsee to v0.24.9 ([#337](https://github.com/edgeandnode/dipper/issues/337)) ([c4b3ea1](https://github.com/edgeandnode/dipper/commit/c4b3ea1519d759d228f69b9beae0ea9cf4482172))
* **deps:** update rust crate log to v0.4.25 ([#268](https://github.com/edgeandnode/dipper/issues/268)) ([d15a308](https://github.com/edgeandnode/dipper/commit/d15a308d352c8d8ced4da7ce9cf6c5e3519f2e3f))
* **deps:** update rust crate log to v0.4.26 ([#308](https://github.com/edgeandnode/dipper/issues/308)) ([edf4ac6](https://github.com/edgeandnode/dipper/commit/edf4ac629b722db45d98e81af2abde074d382bd3))
* **deps:** update rust crate log to v0.4.28 ([#474](https://github.com/edgeandnode/dipper/issues/474)) ([4beb4c1](https://github.com/edgeandnode/dipper/commit/4beb4c13d99ec9b50ff1fe4afcc11c05cc5adf96))
* **deps:** update rust crate pyo3 to 0.23.0 ([#164](https://github.com/edgeandnode/dipper/issues/164)) ([f9139b0](https://github.com/edgeandnode/dipper/commit/f9139b004be78b72bfbd3a85755ba8e4141bf59a))
* **deps:** update rust crate pyo3 to 0.24.0 ([#346](https://github.com/edgeandnode/dipper/issues/346)) ([e041f79](https://github.com/edgeandnode/dipper/commit/e041f794e84cba0ba140647a1e4329f9cdcb049c))
* **deps:** update rust crate pyo3 to 0.25.0 ([#422](https://github.com/edgeandnode/dipper/issues/422)) ([3f57de2](https://github.com/edgeandnode/dipper/commit/3f57de2e21bbea3cadd8bd02a0debf53bcf092ba))
* **deps:** update rust crate pyo3 to v0.22.4 ([#110](https://github.com/edgeandnode/dipper/issues/110)) ([0080697](https://github.com/edgeandnode/dipper/commit/0080697eca21be41fc1dc2352da55c1601106159))
* **deps:** update rust crate pyo3 to v0.22.5 ([#113](https://github.com/edgeandnode/dipper/issues/113)) ([880a939](https://github.com/edgeandnode/dipper/commit/880a93962b014a18509a96059b15fa32b1af2095))
* **deps:** update rust crate pyo3 to v0.23.2 ([#200](https://github.com/edgeandnode/dipper/issues/200)) ([932e4ec](https://github.com/edgeandnode/dipper/commit/932e4ec559e8045bc24363c1cdbb52d9241acade))
* **deps:** update rust crate pyo3 to v0.23.3 ([#232](https://github.com/edgeandnode/dipper/issues/232)) ([91f7ca6](https://github.com/edgeandnode/dipper/commit/91f7ca69a680e94d0e0abd75811ce1edaf9cbd3c))
* **deps:** update rust crate pyo3 to v0.23.4 ([#250](https://github.com/edgeandnode/dipper/issues/250)) ([fb1ab4f](https://github.com/edgeandnode/dipper/commit/fb1ab4fd75c34851072be2c579022a3bc1bd0362))
* **deps:** update rust crate pyo3 to v0.24.1 ([#379](https://github.com/edgeandnode/dipper/issues/379)) ([77478b9](https://github.com/edgeandnode/dipper/commit/77478b91ebc3658b62abbf4845d4f5891f493564))
* **deps:** update rust crate pyo3 to v0.24.2 ([#402](https://github.com/edgeandnode/dipper/issues/402)) ([b7a28f3](https://github.com/edgeandnode/dipper/commit/b7a28f33df53ca523a37e91dbb946496e9cdb435))
* **deps:** update rust crate pyo3 to v0.25.1 ([#448](https://github.com/edgeandnode/dipper/issues/448)) ([f975bd1](https://github.com/edgeandnode/dipper/commit/f975bd181aba479095af1fa036f9b43bdabcb1a7))
* **deps:** update rust crate rand to v0.9.1 ([#404](https://github.com/edgeandnode/dipper/issues/404)) ([aa6d6e8](https://github.com/edgeandnode/dipper/commit/aa6d6e8a0e95c150ab9af495b2e546ae0c63d3d2))
* **deps:** update rust crate rand to v0.9.2 ([#475](https://github.com/edgeandnode/dipper/issues/475)) ([a941a56](https://github.com/edgeandnode/dipper/commit/a941a56bb28a783476b6f6f295aca10a95f00988))
* **deps:** update rust crate reqwest to v0.12.15 ([#338](https://github.com/edgeandnode/dipper/issues/338)) ([1892fe8](https://github.com/edgeandnode/dipper/commit/1892fe83732d66f6febc0ad4abb75b3b92b8db46))
* **deps:** update rust crate reqwest to v0.12.18 ([#416](https://github.com/edgeandnode/dipper/issues/416)) ([1afa58a](https://github.com/edgeandnode/dipper/commit/1afa58afab9e0ed55ac9be3a31bd4797ea882833))
* **deps:** update rust crate reqwest to v0.12.19 ([#445](https://github.com/edgeandnode/dipper/issues/445)) ([54e185a](https://github.com/edgeandnode/dipper/commit/54e185a3ba875da3ed8bd1472e7675ff18c1da47))
* **deps:** update rust crate reqwest to v0.12.22 ([#453](https://github.com/edgeandnode/dipper/issues/453)) ([faf8b75](https://github.com/edgeandnode/dipper/commit/faf8b75e5ca4f64885759a7657dafcf912ab9c69))
* **deps:** update rust crate reqwest to v0.12.24 ([#482](https://github.com/edgeandnode/dipper/issues/482)) ([5fae416](https://github.com/edgeandnode/dipper/commit/5fae416278f5832b9841c164ed9bdc718edf686f))
* **deps:** update rust crate reqwest to v0.12.9 ([#127](https://github.com/edgeandnode/dipper/issues/127)) ([8862e71](https://github.com/edgeandnode/dipper/commit/8862e719a337a227d0b3045579a6bd273b3654e7))
* **deps:** update rust crate serde to v1.0.214 ([#128](https://github.com/edgeandnode/dipper/issues/128)) ([6bc1f9e](https://github.com/edgeandnode/dipper/commit/6bc1f9e5f105f8cbd69f0788076b508d5381806d))
* **deps:** update rust crate serde to v1.0.216 ([#233](https://github.com/edgeandnode/dipper/issues/233)) ([da839f3](https://github.com/edgeandnode/dipper/commit/da839f39ca61e6e9f080d0af707cb8c82a8a26bb))
* **deps:** update rust crate serde_json to v1.0.132 ([#122](https://github.com/edgeandnode/dipper/issues/122)) ([66ecd43](https://github.com/edgeandnode/dipper/commit/66ecd435701c785c005ec359df507f4170dac801))
* **deps:** update rust crate serde_json to v1.0.137 ([#269](https://github.com/edgeandnode/dipper/issues/269)) ([e2ffdd3](https://github.com/edgeandnode/dipper/commit/e2ffdd330ee078827b786f9aa65447bd386eb9f2))
* **deps:** update rust crate serde_json to v1.0.138 ([#281](https://github.com/edgeandnode/dipper/issues/281)) ([652045c](https://github.com/edgeandnode/dipper/commit/652045cd901f2b0ad85ce7febecf6b9bcd11fd78))
* **deps:** update rust crate serde_with to v3.10.0 ([#99](https://github.com/edgeandnode/dipper/issues/99)) ([1b59e54](https://github.com/edgeandnode/dipper/commit/1b59e54b03d4ce09076e94517e9050f15fe9605e))
* **deps:** update rust crate serde_with to v3.11.0 ([#107](https://github.com/edgeandnode/dipper/issues/107)) ([bda1bfc](https://github.com/edgeandnode/dipper/commit/bda1bfc2d1824548246f76fa0bbb47c75c4977c4))
* **deps:** update rust crate serde-envfile to v0.3.0 ([#436](https://github.com/edgeandnode/dipper/issues/436)) ([1272c22](https://github.com/edgeandnode/dipper/commit/1272c2298c8cc5629a8fb7db97198bdc415c66b5))
* **deps:** update rust crate snmalloc-rs to v0.3.7 ([#201](https://github.com/edgeandnode/dipper/issues/201)) ([d544f0f](https://github.com/edgeandnode/dipper/commit/d544f0f6ef7f3c504a98649e889de9444e37a898))
* **deps:** update rust crate snmalloc-rs to v0.3.8 ([#295](https://github.com/edgeandnode/dipper/issues/295)) ([d65cdb3](https://github.com/edgeandnode/dipper/commit/d65cdb3b48e098a996c5afcc4ba0aa201856dce1))
* **deps:** update rust crate sqlx to v0.8.3 ([#251](https://github.com/edgeandnode/dipper/issues/251)) ([038fa2c](https://github.com/edgeandnode/dipper/commit/038fa2c66ab33b1f8c52f5d99dbe3dee8e0644bb))
* **deps:** update rust crate sqlx to v0.8.6 ([#405](https://github.com/edgeandnode/dipper/issues/405)) ([3ec9ab9](https://github.com/edgeandnode/dipper/commit/3ec9ab9f74421845c3c22254503a6e12c215e7a1))
* **deps:** update rust crate tap_graph to v0.3.4 ([#454](https://github.com/edgeandnode/dipper/issues/454)) ([26a04f9](https://github.com/edgeandnode/dipper/commit/26a04f98f8f77fa927e1737030704b795531f48f))
* **deps:** update rust crate tap_graph to v0.3.5 ([#483](https://github.com/edgeandnode/dipper/issues/483)) ([6e2ace4](https://github.com/edgeandnode/dipper/commit/6e2ace45bc081fd086a6e999836c3f396d3becaa))
* **deps:** update rust crate tempfile to v3.13.0 ([#95](https://github.com/edgeandnode/dipper/issues/95)) ([300d15a](https://github.com/edgeandnode/dipper/commit/300d15a1908c3bb56b1d6fdaf5e2bf0fed066e35))
* **deps:** update rust crate test-with to 0.14.0 ([#93](https://github.com/edgeandnode/dipper/issues/93)) ([e19d214](https://github.com/edgeandnode/dipper/commit/e19d21460c315816afc3cd52875c0437c4c66f69))
* **deps:** update rust crate test-with to v0.14.10 ([#406](https://github.com/edgeandnode/dipper/issues/406)) ([703a11e](https://github.com/edgeandnode/dipper/commit/703a11ed2cfa3199a3818a4a2ba715ada196bb31))
* **deps:** update rust crate test-with to v0.14.11 ([#446](https://github.com/edgeandnode/dipper/issues/446)) ([9ef1c44](https://github.com/edgeandnode/dipper/commit/9ef1c44b3689d451a86a81756c30034c7d9c1392))
* **deps:** update rust crate test-with to v0.14.4 ([#106](https://github.com/edgeandnode/dipper/issues/106)) ([c91ac34](https://github.com/edgeandnode/dipper/commit/c91ac34c3a5fa6f0e90572e539678331639a9826))
* **deps:** update rust crate test-with to v0.14.5 ([#161](https://github.com/edgeandnode/dipper/issues/161)) ([c9da53e](https://github.com/edgeandnode/dipper/commit/c9da53eac9f790176f36a1a2cd78b24ea575af98))
* **deps:** update rust crate test-with to v0.14.6 ([#234](https://github.com/edgeandnode/dipper/issues/234)) ([cfa6c6a](https://github.com/edgeandnode/dipper/commit/cfa6c6a972786d47b60cdaefc8ee2a96cb955a68))
* **deps:** update rust crate test-with to v0.14.7 ([#252](https://github.com/edgeandnode/dipper/issues/252)) ([f1a8de7](https://github.com/edgeandnode/dipper/commit/f1a8de729de63eb5b579a427ed0f2795ab335a36))
* **deps:** update rust crate test-with to v0.14.8 ([#351](https://github.com/edgeandnode/dipper/issues/351)) ([ff3eed1](https://github.com/edgeandnode/dipper/commit/ff3eed11e74916c35af823aa1e34916a3b97c133))
* **deps:** update rust crate thegraph-core to 0.10.0 ([#260](https://github.com/edgeandnode/dipper/issues/260)) ([26412b1](https://github.com/edgeandnode/dipper/commit/26412b1f747f4f03b8f7bc0e91b838eba798dda9))
* **deps:** update rust crate thegraph-core to 0.11.0 ([#274](https://github.com/edgeandnode/dipper/issues/274)) ([25798ff](https://github.com/edgeandnode/dipper/commit/25798ff767c5dc9f21544ed87ca9f9d17089af3e))
* **deps:** update rust crate thegraph-core to 0.7.0 ([#103](https://github.com/edgeandnode/dipper/issues/103)) ([617422a](https://github.com/edgeandnode/dipper/commit/617422a28d3baba73118424ca6fa5b1f46c2a576))
* **deps:** update rust crate thegraph-core to v0.15.1 ([#455](https://github.com/edgeandnode/dipper/issues/455)) ([0dcf305](https://github.com/edgeandnode/dipper/commit/0dcf305a51ab1c8666ca9ca486420231fe03caf3))
* **deps:** update rust crate thegraph-core to v0.15.2 ([#485](https://github.com/edgeandnode/dipper/issues/485)) ([5720d6e](https://github.com/edgeandnode/dipper/commit/5720d6ea1d18097d692ca00c9042db82c9898556))
* **deps:** update rust crate thegraph-core to v0.8.1 ([#148](https://github.com/edgeandnode/dipper/issues/148)) ([035db78](https://github.com/edgeandnode/dipper/commit/035db78e0a36afd15302a0e8b83fcddf3cbe724f))
* **deps:** update rust crate thegraph-core to v0.8.2 ([#153](https://github.com/edgeandnode/dipper/issues/153)) ([c47c5db](https://github.com/edgeandnode/dipper/commit/c47c5db14c12b89ee6042edbce4cc2987a8d4d2f))
* **deps:** update rust crate thegraph-core to v0.8.5 ([#202](https://github.com/edgeandnode/dipper/issues/202)) ([fe0bad8](https://github.com/edgeandnode/dipper/commit/fe0bad8d4e3c52ca0fad98dc2c42f7caf1e2a5ff))
* **deps:** update rust crate thegraph-core to v0.9.0 ([#207](https://github.com/edgeandnode/dipper/issues/207)) ([532d31a](https://github.com/edgeandnode/dipper/commit/532d31aa6e3a4a93f90be87084a3a59a26685b28))
* **deps:** update rust crate thegraph-core to v0.9.5 ([#235](https://github.com/edgeandnode/dipper/issues/235)) ([4c26934](https://github.com/edgeandnode/dipper/commit/4c26934b5bf700ecdb0863cbb8d7bfcd98f7da40))
* **deps:** update rust crate thegraph-graphql-http to 0.3.0 ([#261](https://github.com/edgeandnode/dipper/issues/261)) ([ba1d6f6](https://github.com/edgeandnode/dipper/commit/ba1d6f628727ee05ddf74c864ee182d833f35039))
* **deps:** update rust crate thegraph-graphql-http to 0.4.0 ([#417](https://github.com/edgeandnode/dipper/issues/417)) ([3242838](https://github.com/edgeandnode/dipper/commit/324283816c7dfe6c576c8d9e764d27a6a5cf89a8))
* **deps:** update rust crate thegraph-graphql-http to v0.3.3 ([#339](https://github.com/edgeandnode/dipper/issues/339)) ([8165d69](https://github.com/edgeandnode/dipper/commit/8165d6945d1199e1f8927325f8434d09dda345a4))
* **deps:** update rust crate thegraph-graphql-http to v0.4.1 ([#488](https://github.com/edgeandnode/dipper/issues/488)) ([97bdbfb](https://github.com/edgeandnode/dipper/commit/97bdbfb2dc1591c90f4426abff4895d9bd09ae03))
* **deps:** update rust crate thiserror to v1.0.64 ([#90](https://github.com/edgeandnode/dipper/issues/90)) ([dd784cf](https://github.com/edgeandnode/dipper/commit/dd784cfd5586c2b1e1b5b567c74bde60c4258a6c))
* **deps:** update rust crate thiserror to v1.0.68 ([#129](https://github.com/edgeandnode/dipper/issues/129)) ([c024616](https://github.com/edgeandnode/dipper/commit/c024616333fdb5ba498eeb51ff9b504301b7282a))
* **deps:** update rust crate thiserror to v2.0.10 ([#241](https://github.com/edgeandnode/dipper/issues/241)) ([7959f5f](https://github.com/edgeandnode/dipper/commit/7959f5f56849165f3230cfcd7f617e47a5ba16db))
* **deps:** update rust crate thiserror to v2.0.11 ([#253](https://github.com/edgeandnode/dipper/issues/253)) ([4887c50](https://github.com/edgeandnode/dipper/commit/4887c5029993826dac2f6ce7cd7aba6fb408a85e))
* **deps:** update rust crate thiserror to v2.0.12 ([#340](https://github.com/edgeandnode/dipper/issues/340)) ([6af7163](https://github.com/edgeandnode/dipper/commit/6af7163e3faecef70a713c6489a8087744c77591))
* **deps:** update rust crate thiserror to v2.0.17 ([#489](https://github.com/edgeandnode/dipper/issues/489)) ([bd2768b](https://github.com/edgeandnode/dipper/commit/bd2768b42b171af57b6c10f4657d797652b32e3c))
* **deps:** update rust crate thiserror to v2.0.3 ([#151](https://github.com/edgeandnode/dipper/issues/151)) ([4fac6ea](https://github.com/edgeandnode/dipper/commit/4fac6ea32af7e4dba7e72740848a5392f679d6dd))
* **deps:** update rust crate time to v0.3.37 ([#242](https://github.com/edgeandnode/dipper/issues/242)) ([321c389](https://github.com/edgeandnode/dipper/commit/321c389d2626e08957c2dc5e97666707f0c2cb09))
* **deps:** update rust crate time to v0.3.40 ([#341](https://github.com/edgeandnode/dipper/issues/341)) ([1be8043](https://github.com/edgeandnode/dipper/commit/1be80437856c149dea974a40656d12bf8094405b))
* **deps:** update rust crate time to v0.3.41 ([#355](https://github.com/edgeandnode/dipper/issues/355)) ([87e9848](https://github.com/edgeandnode/dipper/commit/87e98487a9bb1b4773ffc4b206e01227815aef1a))
* **deps:** update rust crate tokio to v1.43.0 ([#262](https://github.com/edgeandnode/dipper/issues/262)) ([2fca63d](https://github.com/edgeandnode/dipper/commit/2fca63d9ce9ef83a48416c7324dd5650defadf40))
* **deps:** update rust crate tokio to v1.44.1 ([#347](https://github.com/edgeandnode/dipper/issues/347)) ([a018acb](https://github.com/edgeandnode/dipper/commit/a018acb40f6ad600360613a67e8f45d97da7d33c))
* **deps:** update rust crate tokio to v1.44.2 ([#380](https://github.com/edgeandnode/dipper/issues/380)) ([5311ba7](https://github.com/edgeandnode/dipper/commit/5311ba719a35719a18b75d5cef9d5904d38ad538))
* **deps:** update rust crate tokio to v1.45.1 ([#423](https://github.com/edgeandnode/dipper/issues/423)) ([7f365f4](https://github.com/edgeandnode/dipper/commit/7f365f4be5c64217a5720b8e81f477db6fef0851))
* **deps:** update rust crate tracing to v0.1.41 ([#203](https://github.com/edgeandnode/dipper/issues/203)) ([16783ca](https://github.com/edgeandnode/dipper/commit/16783ca67018e3494f16a8986509ebccc1c7755c))
* **deps:** update rust crate tracing to v0.1.43 ([#503](https://github.com/edgeandnode/dipper/issues/503)) ([db48052](https://github.com/edgeandnode/dipper/commit/db480529a8785336fa761623ec0d3a6924caf632))
* **deps:** update rust crate tracing-subscriber to v0.3.19 ([#211](https://github.com/edgeandnode/dipper/issues/211)) ([d39c8c4](https://github.com/edgeandnode/dipper/commit/d39c8c4e457acebcdfe2ae2e89b105b3d4aa48a2))
* **deps:** update rust crate tracing-subscriber to v0.3.20 ([#492](https://github.com/edgeandnode/dipper/issues/492)) ([d47a58f](https://github.com/edgeandnode/dipper/commit/d47a58fef601139706fcab0a746dfc0118d728a4))
* **deps:** update rust crate url to v2.5.4 ([#189](https://github.com/edgeandnode/dipper/issues/189)) ([c889c29](https://github.com/edgeandnode/dipper/commit/c889c29d010d28926095e35e227bbe200be3e80e))
* **deps:** update rust crate url to v2.5.7 ([#493](https://github.com/edgeandnode/dipper/issues/493)) ([578f7f5](https://github.com/edgeandnode/dipper/commit/578f7f5004fee30c8a2bdeb1f2d6b93fa4e339cc))
* **deps:** update rust crate uuid to v1.11.1 (I) ([#254](https://github.com/edgeandnode/dipper/issues/254)) ([cfd3e71](https://github.com/edgeandnode/dipper/commit/cfd3e7181f5f22b447485dedf67ee2af8655dd7d))
* **deps:** update rust crate uuid to v1.12.1 ([#275](https://github.com/edgeandnode/dipper/issues/275)) ([4c32163](https://github.com/edgeandnode/dipper/commit/4c321636773dedba6253c6607c2268b179c91088))
* **deps:** update rust crate uuid to v1.15.0 ([#312](https://github.com/edgeandnode/dipper/issues/312)) ([121c4c1](https://github.com/edgeandnode/dipper/commit/121c4c1b2ba934e612801cd47fee131504ba97fc))
* **deps:** update rust crate uuid to v1.16.0 ([#348](https://github.com/edgeandnode/dipper/issues/348)) ([e3a7f59](https://github.com/edgeandnode/dipper/commit/e3a7f59bd494bf8b92597828ac30bc672e5169d6))
* **deps:** update rust crate uuid to v1.17.0 ([#413](https://github.com/edgeandnode/dipper/issues/413)) ([5acbf5d](https://github.com/edgeandnode/dipper/commit/5acbf5df8c7a9da5747975c49c89b1fca3b1cc68))
* **deps:** update serde crates ([#114](https://github.com/edgeandnode/dipper/issues/114)) ([db648b5](https://github.com/edgeandnode/dipper/commit/db648b54d574543cc585bbb0cef4374f4b09fda0))
* **deps:** update serde crates ([#239](https://github.com/edgeandnode/dipper/issues/239)) ([85c3993](https://github.com/edgeandnode/dipper/commit/85c399396a6236c8de56906522bf0e049cb9cc85))
* **deps:** update serde crates to v1.0.215 ([#162](https://github.com/edgeandnode/dipper/issues/162)) ([786c26b](https://github.com/edgeandnode/dipper/commit/786c26ba9d8a1447e2545266ec7b4403f7644000))
* **deps:** update serde crates to v1.0.218 ([#310](https://github.com/edgeandnode/dipper/issues/310)) ([57f60cf](https://github.com/edgeandnode/dipper/commit/57f60cf4205d5aa136d339b438f8cdb33ccf457d))
* **deps:** update serde crates to v1.0.219 ([#342](https://github.com/edgeandnode/dipper/issues/342)) ([04bdd02](https://github.com/edgeandnode/dipper/commit/04bdd02d7fceb10028aedb2c4f28a42add421432))
* **deps:** upgrade thegraph-core to the latest version ([#333](https://github.com/edgeandnode/dipper/issues/333)) ([393f609](https://github.com/edgeandnode/dipper/commit/393f609fbe171e34527e699688b6bec38a4d35c0))
* **dipper-cli:** consolidate command execution and improve structure ([#388](https://github.com/edgeandnode/dipper/issues/388)) ([ff2b884](https://github.com/edgeandnode/dipper/commit/ff2b884a90f3054ae1aa4bb99ae969ac9b19a6b3))
* **dipper-cli:** remove chain ID and payer config params ([#195](https://github.com/edgeandnode/dipper/issues/195)) ([36ba40e](https://github.com/edgeandnode/dipper/commit/36ba40e9ba78055bf840f83f0b2f71ad243a9ec6))
* **dipper-cli:** streamline command error handling and improve logging ([#387](https://github.com/edgeandnode/dipper/issues/387)) ([4fd3bf7](https://github.com/edgeandnode/dipper/commit/4fd3bf77f623580198f77b1f3b1e8d156912d93c))
* **dipper-core:** improve signed message documentation ([#196](https://github.com/edgeandnode/dipper/issues/196)) ([958d25c](https://github.com/edgeandnode/dipper/commit/958d25ce48e60abb349491feeda556f43c807c04))
* **dipper-core:** use fake's crate uuid v7 faker impl ([#263](https://github.com/edgeandnode/dipper/issues/263)) ([78d0632](https://github.com/edgeandnode/dipper/commit/78d0632d131701b8b77b19e6b2a836a88a6f7fc5))
* **dipper-iisa-python:** reduce batch fetch latency, add multiple attempts ([#217](https://github.com/edgeandnode/dipper/issues/217)) ([1719be0](https://github.com/edgeandnode/dipper/commit/1719be02408d5c8c57bceb546dd19e6179d03365))
* **dipper-iisa-python:** remove unused code and dependencies ([#376](https://github.com/edgeandnode/dipper/issues/376)) ([e36f047](https://github.com/edgeandnode/dipper/commit/e36f047a9e532072492693b5341f25e69ddd82fe))
* **dipper-iisa:** add debug logging to bq provider ([#173](https://github.com/edgeandnode/dipper/issues/173)) ([5ae93e7](https://github.com/edgeandnode/dipper/commit/5ae93e7ee6b15d1015d1d0982a7293b47f8461d2))
* **dipper-iisa:** disable iisa geoip integration tests ([#264](https://github.com/edgeandnode/dipper/issues/264)) ([08a211e](https://github.com/edgeandnode/dipper/commit/08a211ed810c9865fcb7805e39b1898e055a27db))
* **dipper-iisa:** disable tests due to expired ipinfo.io api key ([#167](https://github.com/edgeandnode/dipper/issues/167)) ([06cb551](https://github.com/edgeandnode/dipper/commit/06cb551f7ac0488167a5aa1b97a292ab8487e626))
* **dipper-iisa:** fix new pyo3 version deprecation warnings ([#168](https://github.com/edgeandnode/dipper/issues/168)) ([20b3eef](https://github.com/edgeandnode/dipper/commit/20b3eef291d7c93b9e8ce33a682d3f935f80c342))
* **dipper-iisa:** simplify iisa service api ([#284](https://github.com/edgeandnode/dipper/issues/284)) ([806c2e5](https://github.com/edgeandnode/dipper/commit/806c2e5d9caf42474a1c4b12e964d67a9e7569ee))
* **dipper-iisa:** use sphinx python code documentation format ([#172](https://github.com/edgeandnode/dipper/issues/172)) ([0ae2c5f](https://github.com/edgeandnode/dipper/commit/0ae2c5f411988f8cc6667d5537ba4cabc0efba6e))
* **dipper-pgmq:** add postgres integration tests for pgmq ([#300](https://github.com/edgeandnode/dipper/issues/300)) ([4393dd3](https://github.com/edgeandnode/dipper/commit/4393dd38f9405a5780c6c0e2de275f7f9fef9f89))
* **dipper-pgmq:** change pgmq public api ([#125](https://github.com/edgeandnode/dipper/issues/125)) ([31a2520](https://github.com/edgeandnode/dipper/commit/31a2520e078f8676f54ade7a6f4b28ca722cec7a))
* **dipper-pgmq:** extract async query functions. ([#427](https://github.com/edgeandnode/dipper/issues/427)) ([5f5687d](https://github.com/edgeandnode/dipper/commit/5f5687dab5ecc1fe9d7309cf9f2aae8b2cc575ba))
* **dipper-pgmq:** remove duplicate sqlx files ([#145](https://github.com/edgeandnode/dipper/issues/145)) ([c716c0d](https://github.com/edgeandnode/dipper/commit/c716c0d0802af99ed4b8a755cb6e20fbc0568402))
* **dipper-pgmq:** use `Json&lt;T&gt;` and  handle job descriptor serde with sqlx ([#430](https://github.com/edgeandnode/dipper/issues/430)) ([d060a45](https://github.com/edgeandnode/dipper/commit/d060a45c6105f4b24f2f5b0849c9538508b4a38f))
* **dipper-pgregistry:** migrate tests to use pgtemp for integration testing ([#426](https://github.com/edgeandnode/dipper/issues/426)) ([7f5cd82](https://github.com/edgeandnode/dipper/commit/7f5cd8270d4f787aae582935cf5641f7ce595ebe))
* **dipper-pgregistry:** remove redundant registry trait ([#323](https://github.com/edgeandnode/dipper/issues/323)) ([669ba61](https://github.com/edgeandnode/dipper/commit/669ba61da47094bad47533bec8611fb5c05fc385))
* **dipper-rpc:** merge admin RPC handlers ([#212](https://github.com/edgeandnode/dipper/issues/212)) ([54f0e8f](https://github.com/edgeandnode/dipper/commit/54f0e8f19226174926c6fbfd4e154569b1e9d4ea))
* **dipper-rpc:** move rpc code under indexer module ([#220](https://github.com/edgeandnode/dipper/issues/220)) ([658bc07](https://github.com/edgeandnode/dipper/commit/658bc0756d20848ac7e67501010ab1b386aca234))
* **dipper-rpc:** reorg network RPC API modules ([#229](https://github.com/edgeandnode/dipper/issues/229)) ([6c20610](https://github.com/edgeandnode/dipper/commit/6c20610dce7b2907d40d8717e05e97e3792075c6))
* **dipper-service:** add signing module ([#321](https://github.com/edgeandnode/dipper/issues/321)) ([b06fa29](https://github.com/edgeandnode/dipper/commit/b06fa296d90be47ae6b1a58d24842d1b251fe10c))
* **dipper-service:** enhance migration link creation and update migration paths ([#438](https://github.com/edgeandnode/dipper/issues/438)) ([cb78c8b](https://github.com/edgeandnode/dipper/commit/cb78c8bc4a35827faefc35b252e704a5183030ac))
* **dipper-service:** introduce context modules for admin and indexer RPC servers ([#375](https://github.com/edgeandnode/dipper/issues/375)) ([098cdd2](https://github.com/edgeandnode/dipper/commit/098cdd2a0aea0a65354c97afd64566846423c8cf))
* **dipper-service:** remove redundant build.rs file ([#439](https://github.com/edgeandnode/dipper/issues/439)) ([85f0458](https://github.com/edgeandnode/dipper/commit/85f0458bb4ff7e7bd2050790666c1a87b5091075))
* **dipper-service:** remove redundant context builder test ([#319](https://github.com/edgeandnode/dipper/issues/319)) ([d11bc5e](https://github.com/edgeandnode/dipper/commit/d11bc5ed043f3704e8642840c6058b6881bac1f0))
* **dipper-service:** remove unused fields ([#226](https://github.com/edgeandnode/dipper/issues/226)) ([4dfd7f5](https://github.com/edgeandnode/dipper/commit/4dfd7f5072077b6adda5b9f8124454f437c72f71))
* **dipper-service:** remove unused registry methods ([#322](https://github.com/edgeandnode/dipper/issues/322)) ([5643434](https://github.com/edgeandnode/dipper/commit/5643434ab6eb5bc329e78f2cd3ff64fafb5f5205))
* **dipper-service:** rename admin rpc server module ([#216](https://github.com/edgeandnode/dipper/issues/216)) ([04a0ae1](https://github.com/edgeandnode/dipper/commit/04a0ae149adfb59c60ab367fe5a04a1b87934904))
* **dipper-service:** restructure configuration and worker context ([#437](https://github.com/edgeandnode/dipper/issues/437)) ([ed10e1b](https://github.com/edgeandnode/dipper/commit/ed10e1b48c181ad2cd07c1141cf1ae4b4feea410))
* **dipper-service:** restructure worker context and handlers for indexing agreements ([#374](https://github.com/edgeandnode/dipper/issues/374)) ([20e4327](https://github.com/edgeandnode/dipper/commit/20e4327e77b99929aa4794b609716768ff7483ad))
* **dipper-service:** restructure worker queue handling ([#428](https://github.com/edgeandnode/dipper/issues/428)) ([745c740](https://github.com/edgeandnode/dipper/commit/745c740ef878dc3d5f782eb19250e7ede371659c))
* **dipper-service:** unify application context ([#227](https://github.com/edgeandnode/dipper/issues/227)) ([e194d80](https://github.com/edgeandnode/dipper/commit/e194d8048561853e61eec1dd64fefdea07c264d0))
* **dipper-service:** use serde_yaml_ng dependency instead ([#147](https://github.com/edgeandnode/dipper/issues/147)) ([d27022e](https://github.com/edgeandnode/dipper/commit/d27022e47dfa4fe443fd27693f952760f3089170))
* **dipper:** extend timeout for subgraph paginated client integration tests ([#117](https://github.com/edgeandnode/dipper/issues/117)) ([63a3055](https://github.com/edgeandnode/dipper/commit/63a3055b24ece4a3ff4f5d86c124706562498fbe))
* **dipper:** fix tracing dependency warning ([#131](https://github.com/edgeandnode/dipper/issues/131)) ([5ec109c](https://github.com/edgeandnode/dipper/commit/5ec109c60e2dd980a5c03feca4ccdeafc1e18d7e))
* **dipper:** relocate indexer client module ([#64](https://github.com/edgeandnode/dipper/issues/64)) ([a6eef20](https://github.com/edgeandnode/dipper/commit/a6eef20b1fc5fd8e0464011e5c8448cf472a4c1f))
* **dips:** drive chain_listener off stateful IndexingAgreement entity ([#609](https://github.com/edgeandnode/dipper/issues/609)) ([09af73e](https://github.com/edgeandnode/dipper/commit/09af73e0247e96b9dfb1b6c44381778381d901f0))
* fix cargo lockfile ([#136](https://github.com/edgeandnode/dipper/issues/136)) ([acf17bc](https://github.com/edgeandnode/dipper/commit/acf17bc2377b161b06ea20a55d12e125c61cf335))
* fix create migrations links script ([#324](https://github.com/edgeandnode/dipper/issues/324)) ([0b69b12](https://github.com/edgeandnode/dipper/commit/0b69b122f226cf796f552342768da7a3e881a156))
* fix migrations symbolic links ([#325](https://github.com/edgeandnode/dipper/issues/325)) ([0bbe7a2](https://github.com/edgeandnode/dipper/commit/0bbe7a22ac4967af6e46525057b04fbaa76a917e))
* fix various clippy warnings ([#291](https://github.com/edgeandnode/dipper/issues/291)) ([a800424](https://github.com/edgeandnode/dipper/commit/a800424c4bedd79da5b3dcea18daf222b760f6d2))
* flatten project structure ([#138](https://github.com/edgeandnode/dipper/issues/138)) ([1e44acb](https://github.com/edgeandnode/dipper/commit/1e44acb008c0e9b3dc3135184e819b652eeaddd3))
* ignore .claude/ worktree scratch dir ([3970734](https://github.com/edgeandnode/dipper/commit/397073438b01322e26ff72aa2f91bf80e393705d))
* **iisa:** detach data manager instantiation from data fetch ([#81](https://github.com/edgeandnode/dipper/issues/81)) ([57f0472](https://github.com/edgeandnode/dipper/commit/57f0472db2dec71ec447aab664651006550b6cc2))
* **iisa:** Implement unit/integration tests for methods in the DataProcessor class. ([#50](https://github.com/edgeandnode/dipper/issues/50)) ([889b640](https://github.com/edgeandnode/dipper/commit/889b6400d3010f3a0ad1a5450c609040ee3c7319))
* **iisa:** Merge _select_next_best_indexer & _find_best_replacement methods. New instance variable `declined_indexers`. ([#70](https://github.com/edgeandnode/dipper/issues/70)) ([cdc117d](https://github.com/edgeandnode/dipper/commit/cdc117d3908595320902e534d016d29470fe3608))
* **iisa:** normalize_indexing_agreement_acceptance_latency now uses a piecewise function to normalise latnecy. ([#68](https://github.com/edgeandnode/dipper/issues/68)) ([ca7d6ce](https://github.com/edgeandnode/dipper/commit/ca7d6ce552182583f03cd075a7d84cbe6ae4803b))
* **iisa:** restrict python dependency version ranges ([#102](https://github.com/edgeandnode/dipper/issues/102)) ([5c1e02f](https://github.com/edgeandnode/dipper/commit/5c1e02fec05bf2d0927fa9c4b8f50e6b16c9d2cb))
* **iisa:** simplify network provider API ([#71](https://github.com/edgeandnode/dipper/issues/71)) ([0279a5c](https://github.com/edgeandnode/dipper/commit/0279a5c558ceaf7190d53f53ea23e914e9121573))
* **iisa:** split datamanager class into a new module ([#83](https://github.com/edgeandnode/dipper/issues/83)) ([6b8d808](https://github.com/edgeandnode/dipper/commit/6b8d8081816959e08050cac1ee2b89923dd45854))
* **iisa:** Update uptime calculations, get_indexer_selections, _fetch_number_of_indexer_agreements, and NaN handling in scoring. ([#67](https://github.com/edgeandnode/dipper/issues/67)) ([9c4dd9e](https://github.com/edgeandnode/dipper/commit/9c4dd9ee9c17421c72d0fc6d9d264877c9fe8df6))
* migrate IISA to HTTP service ([#521](https://github.com/edgeandnode/dipper/issues/521)) ([47b9612](https://github.com/edgeandnode/dipper/commit/47b96120f7f8e8be009499287ce88a85917e1d59))
* **pgmq:** migrate tests to use pgtemp for integration testing ([#425](https://github.com/edgeandnode/dipper/issues/425)) ([3c916f7](https://github.com/edgeandnode/dipper/commit/3c916f7394785555735281c714f36012f2708163))
* pin python version to v3.11.10 ([#75](https://github.com/edgeandnode/dipper/issues/75)) ([00bdd52](https://github.com/edgeandnode/dipper/commit/00bdd5291ae092986eb85c52302ce8e184b2bbb9))
* remove dead code surfaced by the admin API collapse ([#616](https://github.com/edgeandnode/dipper/issues/616)) ([249ad31](https://github.com/edgeandnode/dipper/commit/249ad31438f034b51ed22eb02a07d80d749e86dd))
* remove dipper-indexer-client crate ([#215](https://github.com/edgeandnode/dipper/issues/215)) ([4611913](https://github.com/edgeandnode/dipper/commit/4611913a5feb04a2bfe34c744ef8754fecf1cdcd))
* remove test file ([#391](https://github.com/edgeandnode/dipper/issues/391)) ([2224968](https://github.com/edgeandnode/dipper/commit/222496880986992a5fdb7ca665682e691b0ec674))
* remove unused files ([#408](https://github.com/edgeandnode/dipper/issues/408)) ([88772d4](https://github.com/edgeandnode/dipper/commit/88772d47344d1dfc271993cd6b1f44863ff4b48d))
* remove V1 payment collection dead code ([#574](https://github.com/edgeandnode/dipper/issues/574)) ([c0746f9](https://github.com/edgeandnode/dipper/commit/c0746f94e0cdf69cb46f5a3ca8699eb895dfe211))
* rename Voucher types and DB column to Terms ([#605](https://github.com/edgeandnode/dipper/issues/605)) ([8dacc2a](https://github.com/edgeandnode/dipper/commit/8dacc2a2aa0211bb8c69f891575156f495562e2e))
* replace register/cancel with set-indexing-target ([#615](https://github.com/edgeandnode/dipper/issues/615)) ([6b1a4de](https://github.com/edgeandnode/dipper/commit/6b1a4de719ad5f80304cc8584ab990fe8874678c))
* replace UUID primary key with on-chain agreement ID ([#604](https://github.com/edgeandnode/dipper/issues/604)) ([6147c77](https://github.com/edgeandnode/dipper/commit/6147c772fd01a1a4cd46c30da163a60aded205a8))
* return per-agreement rate fields from fee query ([#588](https://github.com/edgeandnode/dipper/issues/588)) ([523d24c](https://github.com/edgeandnode/dipper/commit/523d24c24139c638673d63ede288a3a7dfba19d0))
* simplify dipper agreement payment-cap configuration ([#619](https://github.com/edgeandnode/dipper/issues/619)) ([75f4932](https://github.com/edgeandnode/dipper/commit/75f493280f823bf4aea64def529b1ef39633a781))
* upgrade Rust edition to 2024 ([#326](https://github.com/edgeandnode/dipper/issues/326)) ([91b1f8e](https://github.com/edgeandnode/dipper/commit/91b1f8e41a379bff07434f86f4e40f64fd6d82e0))
* use GRT per billion entities instead of per million ([#565](https://github.com/edgeandnode/dipper/issues/565)) ([0d51630](https://github.com/edgeandnode/dipper/commit/0d5163070c75a45426d6ae3465ef10b7966e3d76))
* **worker:** consolidate FromState impls with declarative macro ([#568](https://github.com/edgeandnode/dipper/issues/568)) ([6d84b5b](https://github.com/edgeandnode/dipper/commit/6d84b5be7ae7f75adbcb2620a943228139434711))


### Performance

* **ci:** parallelize clippy and adopt cargo-nextest ([#527](https://github.com/edgeandnode/dipper/issues/527)) ([6d26ced](https://github.com/edgeandnode/dipper/commit/6d26ced597bfd0c2353eb760809216197cd63e50))
* **iisa:** add database-side aggregation for pending agreements query ([#541](https://github.com/edgeandnode/dipper/issues/541)) ([bab9b99](https://github.com/edgeandnode/dipper/commit/bab9b99fb2f38431488365310c1ff7d32e56b352))


### Infrastructure

* **k8s:** add Kubernetes deployment manifests for dipper ([#538](https://github.com/edgeandnode/dipper/issues/538)) ([42c78c9](https://github.com/edgeandnode/dipper/commit/42c78c92fc5bd578d2c47ea8d8993f19a73aeb94))


### Documentation

* add Dipper Admin CLI documentation and update README ([#386](https://github.com/edgeandnode/dipper/issues/386)) ([b93a014](https://github.com/edgeandnode/dipper/commit/b93a0148378c1a88f45984326a652ce88c316a3c))


### Tests

* **iisa:** add timeout and malformed JSON response tests ([#535](https://github.com/edgeandnode/dipper/issues/535)) ([1dc5294](https://github.com/edgeandnode/dipper/commit/1dc52949774582b7b9b3dae1c5d9a51ef0cd5088))


### CI/CD

* **build:** publish multi-arch (amd64+arm64) images ([#611](https://github.com/edgeandnode/dipper/issues/611)) ([b730772](https://github.com/edgeandnode/dipper/commit/b7307727dcd4a32669a64af9abe9019e5b87f363))
* publish latest tag for container images ([#570](https://github.com/edgeandnode/dipper/issues/570)) ([1b7ef28](https://github.com/edgeandnode/dipper/commit/1b7ef288fc8810905df3757ac58c66bdf84e0a4a))
* **release:** add release-please for automated releases ([#539](https://github.com/edgeandnode/dipper/issues/539)) ([8763724](https://github.com/edgeandnode/dipper/commit/8763724f5a30cf22892db47cc3b3402b1ed5d222))
