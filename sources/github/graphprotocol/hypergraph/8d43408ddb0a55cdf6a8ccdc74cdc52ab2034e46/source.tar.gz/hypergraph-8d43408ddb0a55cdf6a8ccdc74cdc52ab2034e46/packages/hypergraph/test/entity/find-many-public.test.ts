import { Id } from '@geoprotocol/geo-sdk';
import { describe, expect, it } from 'vitest';
import { parseResult } from '../../src/entity/find-many-public.js';
import * as Entity from '../../src/entity/index.js';
import * as Type from '../../src/type/type.js';
import { getRelationTypeIds } from '../../src/utils/get-relation-type-ids.js';
import { getRelationAlias } from '../../src/utils/relation-query-helpers.js';

const TITLE_PROPERTY_ID = Id('79c1a9510074401087d07501ef9d7b3d');
const CHILDREN_RELATION_PROPERTY_ID = Id('ca7c7167250249c490b084c147f9b12b');
const CHILD_NAME_PROPERTY_ID = Id('25584af039414ab986f7a603305b19bb');

const Child = Entity.Schema(
  {
    name: Type.String,
  },
  {
    types: [Id('3c2ae3aa4ec141e3bc4c1fe7a5e07bc1')],
    properties: {
      name: CHILD_NAME_PROPERTY_ID,
    },
  },
);

const Parent = Entity.Schema(
  {
    title: Type.String,
    children: Type.Relation(Child),
  },
  {
    types: [Id('af571d8c06d44add8cfa4c6b50412254')],
    properties: {
      title: TITLE_PROPERTY_ID,
      children: CHILDREN_RELATION_PROPERTY_ID,
    },
  },
);

const buildValueEntry = (
  propertyId: string,
  value: Partial<{
    text: string;
    boolean: boolean;
    float: number;
    datetime: string;
    point: string;
    schedule: string;
  }> = {},
) => ({
  propertyId,
  text: value.text ?? '',
  boolean: value.boolean ?? false,
  float: value.float ?? 0,
  datetime: value.datetime ?? new Date(0).toISOString(),
  point: value.point ?? '0,0',
  schedule: value.schedule ?? '',
});

describe('findManyPublic parseResult', () => {
  it('collects invalidEntities when decoding fails', () => {
    const queryData = {
      entities: [
        {
          id: 'parent-valid',
          name: 'Parent valid',
          valuesList: [buildValueEntry(TITLE_PROPERTY_ID, { text: 'Parent valid' })],
          spaceIds: [],
        },
        {
          id: 'parent-invalid',
          name: 'Parent invalid',
          valuesList: [],
          spaceIds: [],
        },
      ],
    };

    const result = parseResult(queryData, Parent, []);

    expect(result.data).toHaveLength(1);
    expect(result.invalidEntities).toHaveLength(1);
    expect(result.invalidEntities[0].raw.id).toBe('parent-invalid');
    expect(result.invalidRelationEntities).toHaveLength(0);
  });

  it('collects invalidRelationEntities when nested relations fail to decode', () => {
    const relationInfo = getRelationTypeIds(Parent, { children: {} });
    const childrenRelationInfo = relationInfo.find((info) => info.propertyName === 'children');
    const relationAlias = getRelationAlias(CHILDREN_RELATION_PROPERTY_ID, childrenRelationInfo?.targetTypeIds);

    const queryData = {
      entities: [
        {
          id: 'parent-with-invalid-child',
          name: 'Parent with invalid child',
          valuesList: [buildValueEntry(TITLE_PROPERTY_ID, { text: 'Parent with invalid child' })],
          spaceIds: [],
          [relationAlias]: {
            nodes: [
              {
                id: 'relation-1',
                entity: { valuesList: [] },
                toEntity: {
                  id: 'child-bad',
                  name: 'Child bad',
                  valuesList: [],
                },
                typeId: CHILDREN_RELATION_PROPERTY_ID,
              },
            ],
          },
        },
      ],
    };

    const result = parseResult(queryData, Parent, relationInfo);

    expect(result.data).toHaveLength(1);
    expect(result.data[0].children).toEqual([]);
    expect(result.invalidEntities).toHaveLength(0);
    expect(result.invalidRelationEntities).toHaveLength(1);
    expect(result.invalidRelationEntities[0]).toMatchObject({
      parentEntityId: 'parent-with-invalid-child',
      propertyName: 'children',
    });
  });

  it('exposes normalized spaceIds when requested', () => {
    const queryData = {
      entities: [
        {
          id: 'parent-with-spaces',
          name: 'Parent with spaces',
          valuesList: [buildValueEntry(TITLE_PROPERTY_ID, { text: 'Parent with spaces' })],
          spaceIds: ['space-1', null, 'space-2'],
        },
      ],
    };

    const result = parseResult(queryData, Parent, [], { includeSpaceIds: true });

    expect(result.data).toHaveLength(1);
    const entityWithSpaceIds = result.data[0] as { spaceIds?: string[] };
    expect(entityWithSpaceIds.spaceIds).toEqual(['space-1', 'space-2']);
  });
});
