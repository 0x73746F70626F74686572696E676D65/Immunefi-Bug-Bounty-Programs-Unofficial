import type { Op } from '@geoprotocol/geo-sdk';
import { Ipfs } from '@geoprotocol/geo-sdk';
import { Config, Connect } from '@graphprotocol/hypergraph';
import type { Hash } from 'viem';

type PublishParams = {
  name: string;
  ops: Op[];
  walletClient: Connect.SmartSessionClient;
  space: string;
};

type PublishResult = {
  txResult: Hash;
  to: Hash;
  data: Hash;
  cid: string;
};

export const publishOps = async ({ name, ops, walletClient, space }: PublishParams): Promise<PublishResult> => {
  const address = walletClient.account?.address;
  if (!address) {
    throw new Error('No address found');
  }

  const network = walletClient.chain.id === Connect.GEO_TESTNET.id ? 'TESTNET' : 'TESTNET'; // TODO: switch to mainnet
  const publishResult = await Ipfs.publishEdit({
    name,
    ops: ops,
    author: address,
    network,
  });

  const cid = publishResult.cid;

  // This returns the correct contract address and calldata depending on the space id
  const result = await fetch(`${Config.getApiOrigin()}/space/${space}/edit/calldata`, {
    method: 'POST',
    body: JSON.stringify({ cid }),
  });

  const { to, data } = await result.json();

  const txResult = await walletClient.sendUserOperation({
    calls: [
      {
        to: to,
        value: 0n,
        data: data,
      },
    ],
  });

  return { txResult: txResult as `0x${string}`, to, data, cid };
};
