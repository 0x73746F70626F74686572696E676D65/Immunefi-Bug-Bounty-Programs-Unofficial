// @ts-check
// `@type` JSDoc annotations allow editor autocompletion and type checking
// (when paired with `@ts-check`).
// There are various equivalent ways to declare your Docusaurus config.
// See: https://docusaurus.io/docs/api/docusaurus-config

import { themes as prismThemes } from 'prism-react-renderer';

// This runs in Node.js - Don't use client-side code here (browser APIs, JSX...)

/** @type {import('@docusaurus/types').Config} */
const config = {
  title: 'Hypergraph',
  tagline: 'Framework for building web3 apps',

  // Set the production url of your site here
  url: 'https://graphprotocol.github.io',
  // Set the /<baseUrl>/ pathname under which your site is served
  // For GitHub pages deployment, it is often '/<projectName>/'
  baseUrl: '/',

  // GitHub pages deployment config.
  // If you aren't using GitHub pages, you don't need these.
  organizationName: 'graphprotocol',
  projectName: 'hypergraph',

  onBrokenLinks: 'warn',
  onBrokenMarkdownLinks: 'warn',

  // Even if you don't use internationalization, you can use this field to set
  // useful metadata like html lang. For example, if your site is Chinese, you
  // may want to replace "en" with "zh-Hans".
  i18n: {
    defaultLocale: 'en',
    locales: ['en'],
  },

  headTags: [
    {
      tagName: 'meta',
      attributes: {
        name: 'algolia-site-verification',
        content: '536FEAE3B63DD658',
      },
    },
    {
      tagName: 'link',
      attributes: {
        rel: 'icon',
        type: 'image/png',
        href: '/img/HypergraphLogoDark.png',
        media: '(prefers-color-scheme: light)',
      },
    },
    {
      tagName: 'link',
      attributes: {
        rel: 'icon',
        type: 'image/png',
        href: '/img/HypergraphLogo.png',
        media: '(prefers-color-scheme: dark)',
      },
    },
  ],

  plugins: [
    [
      'docusaurus-plugin-llms',
      {
        includeOrder: [
          'quickstart',
          'ai-usage',
          'key-features',
          'core-concepts',
          'typesync',
          'providers',
          'authentication',
          'spaces',
          'schema',
          'writing-private-data',
          'query-private-data',
          'mapping',
          'publishing-public-data',
          'query-public-data',
          'filtering-query-results',
          'space-invitations',
          'inboxes',
          'troubleshooting',
          'faq',
          'advanced/*',
        ],
      },
    ],
    [
      'docusaurus-plugin-typedoc',
      {
        id: 'api-hypergraph',
        entryPoints: ['../packages/hypergraph/src/index.ts'],
        tsconfig: '../packages/hypergraph/tsconfig.json',
        out: 'docs/api-reference/hypergraph',
        readme: 'none',
        name: 'Hypergraph',
        categorizeByGroup: false,
        excludeExternals: true,
        excludePrivate: true,
        excludeProtected: true,
        sidebar: {
          autoConfiguration: true,
          pretty: true,
        },
      },
    ],
    [
      'docusaurus-plugin-typedoc',
      {
        id: 'api-hypergraph-react',
        entryPoints: ['../packages/hypergraph-react/src/index.ts'],
        tsconfig: '../packages/hypergraph-react/tsconfig.json',
        out: 'docs/api-reference/hypergraph-react',
        readme: 'none',
        name: 'Hypergraph React',
        categorizeByGroup: false,
        excludeExternals: true,
        excludePrivate: true,
        excludeProtected: true,
        skipErrorChecking: true,
        sidebar: {
          autoConfiguration: true,
          pretty: true,
        },
      },
    ],
  ],

  presets: [
    [
      'classic',
      /** @type {import('@docusaurus/preset-classic').Options} */
      ({
        docs: {
          sidebarPath: './sidebars.js',
          // Please change this to your repo.
          // Remove this to remove the "edit this page" links.
          editUrl: 'https://github.com/graphprotocol/hypergraph/edit/main/docs',
        },
        blog: {
          showReadingTime: true,
          blogSidebarCount: 'ALL',
          feedOptions: {
            type: ['rss', 'atom'],
            xslt: true,
          },
          // Please change this to your repo.
          // Remove this to remove the "edit this page" links.
          editUrl: 'https://github.com/facebook/docusaurus/tree/main/packages/create-docusaurus/templates/shared/',
          // Useful options to enforce blogging best practices
          onInlineTags: 'warn',
          onInlineAuthors: 'warn',
          onUntruncatedBlogPosts: 'warn',
        },
        theme: {
          customCss: './src/css/custom.css',
        },
      }),
    ],
  ],

  themeConfig:
    /** @type {import('@docusaurus/preset-classic').ThemeConfig} */
    ({
      colorMode: { defaultMode: 'dark', disableSwitch: true },
      // Replace with your project's social card
      image: 'img/docusaurus-social-card.jpg',
      navbar: {
        title: 'Hypergraph',
        logo: {
          alt: 'Hypergraph Logo',
          src: 'img/HypergraphLogo.png',
        },
        items: [
          {
            type: 'docSidebar',
            sidebarId: 'docs',
            position: 'left',
            label: 'Docs',
          },
          { to: '/blog', label: 'Blog', position: 'left' },
          {
            href: 'https://github.com/graphprotocol/hypergraph',
            label: 'GitHub',
            position: 'right',
          },
        ],
      },
      footer: {
        style: 'light',
        links: [
          {
            title: 'Docs',
            items: [
              {
                label: 'Quickstart',
                to: '/docs/quickstart',
              },
            ],
          },
          {
            title: 'Community',
            items: [
              {
                label: 'Discord',
                href: 'https://discord.gg/NN69QZQQAZ',
              },
              {
                label: 'X',
                href: 'https://x.com/geobrowser',
              },
            ],
          },
          {
            title: 'More',
            items: [
              {
                label: 'Geo',
                to: 'https://geobrowser.io',
              },
            ],
          },
        ],
        copyright: `Copyright © ${new Date().getFullYear()} Geo Browser & contributors.`,
      },
      prism: {
        theme: prismThemes.github,
        darkTheme: prismThemes.dracula,
      },
      algolia: {
        appId: 'E46M8TLYZ1',
        apiKey: '7bc604aed2cae4aa59febf78339ffc14',
        indexName: 'Documentation Website',
        contextualSearch: true,
      },
    }),
};

export default config;
