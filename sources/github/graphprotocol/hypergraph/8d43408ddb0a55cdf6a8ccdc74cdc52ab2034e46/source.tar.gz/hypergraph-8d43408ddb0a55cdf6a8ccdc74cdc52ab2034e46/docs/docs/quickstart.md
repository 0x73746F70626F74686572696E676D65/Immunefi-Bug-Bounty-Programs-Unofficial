---
title: Quickstart
description: Create your first Hypergraph-powered application in minutes with TypeSync.
version: 0.0.1
tags: [quickstart, typesync]
---

# 🚀 Quickstart

The quickest way to create a new Hypergraph application you can use the `create-hypergraph` CLI command. Make sure you have Node.js >= 22 installed.

```bash
npx create-hypergraph@latest
# or
pnpm create hypergraph@latest
bunx create-hypergraph@latest
yarn create hypergraph@latest
```

During installation, you'll see the following prompts to choose your app name, template, and package manager.


1. What is your app named? …
2. Choose your template …
3. What package manager do you want to use? …


After the prompts, you'll have a new Hypergraph application ready to use and can start exploring the app. To run it use the following command:

```bash
cd my-hypergraph-app
npm run dev
# or depending on your package manager
yarn run dev
pnpm run dev
bun run dev
```

Open the browser and navigate to the development server URL shown in your terminal (for example, `http://localhost:5173` for Vite or `http://localhost:3000` for Next.js)

<!-- ## Example Datasets

A few example datasets to use when building your apps are available here:

- [Web3 projects](https://testnet.geobrowser.io/space/3f32353d3b274a13b71a746f06e1f7db/0f3e0e211636435a850f6f57d616e28e)
- [Web3 VCs](https://testnet.geobrowser.io/space/3f32353d3b274a13b71a746f06e1f7db/d8ec3f5776014befa648a64799dfd964)
- [Web3 DAPPs](https://testnet.geobrowser.io/space/3f32353d3b274a13b71a746f06e1f7db/09d3188c8e204083a6ade696cc493c7a)
- [Token Values](https://testnet.geobrowser.io/space/2df119689d1c489f91b7bdc88b472161/f8780a80c2384a2a96cb567d88b1aa63) -->

---

## Edit on GitHub :bust_in_silhouette:

[✏️ Improve this page](https://github.com/graphprotocol/hypergraph/edit/main/docs/docs/quickstart.md)

```

```
