function getImageUrl(src: string | undefined | Blob) {
  if (!src || typeof src !== 'string') return src;
  const image = src.split('ipfs://');
  if (image.length === 2) {
    return `https://gateway.lighthouse.storage/ipfs/${image[1]}`;
  }
  return src;
}

export function GraphImage(
  props: React.DetailedHTMLProps<React.ImgHTMLAttributes<HTMLImageElement>, HTMLImageElement>,
) {
  // biome-ignore lint/a11y/useAltText: should be provided with the props
  return <img {...props} src={getImageUrl(props.src)} />;
}
