use std::sync::Arc;
use std::time::Duration;

use anyhow::Error;
use anyhow::anyhow;
use bytes::Bytes;
use graph::futures03::future::BoxFuture;
use graph::ipfs::{ContentPath, IpfsClient, IpfsContext, RetryPolicy};
use graph::{derive::CheapClone, prelude::CheapClone};
use tower::{ServiceBuilder, ServiceExt, buffer::Buffer};

pub type IpfsService = Buffer<IpfsRequest, BoxFuture<'static, Result<Option<Bytes>, Error>>>;

#[derive(Debug, Clone, CheapClone)]
pub struct IpfsRequest {
    pub ctx: IpfsContext,
    pub path: ContentPath,
}

pub fn ipfs_service(
    client: Arc<dyn IpfsClient>,
    max_file_size: usize,
    timeout: Duration,
    rate_limit: u16,
) -> IpfsService {
    let ipfs = IpfsServiceInner {
        client,
        timeout,
        max_file_size,
    };

    let svc = ServiceBuilder::new()
        .rate_limit(rate_limit.into(), Duration::from_secs(1))
        .service_fn(move |req| ipfs.cheap_clone().call_inner(req))
        .boxed();

    // The `Buffer` makes it so the rate limit is shared among clones.
    // Make it unbounded to avoid any risk of starvation.
    Buffer::new(svc, u32::MAX as usize)
}

#[derive(Clone, CheapClone)]
struct IpfsServiceInner {
    client: Arc<dyn IpfsClient>,
    timeout: Duration,
    max_file_size: usize,
}

impl IpfsServiceInner {
    async fn call_inner(
        self,
        IpfsRequest { ctx, path }: IpfsRequest,
    ) -> Result<Option<Bytes>, Error> {
        let multihash = path.cid().hash().code();
        if !SAFE_MULTIHASHES.contains(&multihash) {
            return Err(anyhow!("CID multihash {} is not allowed", multihash));
        }

        let res = self
            .client
            .cat(
                &ctx,
                &path,
                self.max_file_size,
                Some(self.timeout),
                RetryPolicy::None,
            )
            .await;

        match res {
            Ok(file_bytes) => Ok(Some(file_bytes)),
            Err(err) if err.is_timeout() => {
                // Timeouts in IPFS mean that the content is not available, so we return `None`.
                Ok(None)
            }
            Err(err) => Err(err.into()),
        }
    }
}

// Multihashes that are collision resistant. This is not complete but covers the commonly used ones.
// Code table: https://github.com/multiformats/multicodec/blob/master/table.csv
// rust-multihash code enum: https://github.com/multiformats/rust-multihash/blob/master/src/multihash_impl.rs
const SAFE_MULTIHASHES: [u64; 15] = [
    0x0,    // Identity
    0x12,   // SHA2-256 (32-byte hash size)
    0x13,   // SHA2-512 (64-byte hash size)
    0x17,   // SHA3-224 (28-byte hash size)
    0x16,   // SHA3-256 (32-byte hash size)
    0x15,   // SHA3-384 (48-byte hash size)
    0x14,   // SHA3-512 (64-byte hash size)
    0x1a,   // Keccak-224 (28-byte hash size)
    0x1b,   // Keccak-256 (32-byte hash size)
    0x1c,   // Keccak-384 (48-byte hash size)
    0x1d,   // Keccak-512 (64-byte hash size)
    0xb220, // BLAKE2b-256 (32-byte hash size)
    0xb240, // BLAKE2b-512 (64-byte hash size)
    0xb260, // BLAKE2s-256 (32-byte hash size)
    0x1e,   // BLAKE3-256 (32-byte hash size)
];

#[cfg(test)]
mod test {
    use std::time::Duration;

    use graph::components::link_resolver::ArweaveClient;
    use graph::data::value::Word;
    use graph::ipfs::test_utils::add_files_to_local_ipfs_node_for_testing;
    use graph::ipfs::{IpfsContext, IpfsMetrics, IpfsRpcClient, ServerAddress};
    use graph::log::discard;
    use tower::ServiceExt;
    use wiremock::Mock;
    use wiremock::MockServer;
    use wiremock::ResponseTemplate;
    use wiremock::matchers as m;

    use super::*;

    #[graph::test]
    async fn cat_file_in_folder() {
        let random_bytes = "One morning, when Gregor Samsa woke \
          from troubled dreams, he found himself transformed in his bed \
          into a horrible vermin"
            .as_bytes()
            .to_vec();
        let ipfs_file = ("dir/file.txt", random_bytes.clone());

        let add_resp = add_files_to_local_ipfs_node_for_testing([ipfs_file])
            .await
            .unwrap();

        let dir_cid = add_resp.into_iter().find(|x| x.name == "dir").unwrap().hash;

        let client = IpfsRpcClient::new_unchecked(
            ServerAddress::test_rpc_api(),
            IpfsMetrics::test(),
            &graph::log::discard(),
        )
        .unwrap();

        let svc = ipfs_service(Arc::new(client), 100000, Duration::from_secs(30), 10);

        let path = ContentPath::new(format!("{dir_cid}/file.txt")).unwrap();
        let content = svc
            .oneshot(IpfsRequest {
                ctx: IpfsContext::test(),
                path,
            })
            .await
            .unwrap()
            .unwrap();

        assert_eq!(content.to_vec(), random_bytes);
    }

    // Ignored because arweave.net is unreliable right now
    #[graph::test]
    #[ignore]
    async fn arweave_get() {
        const ID: &str = "8APeQ5lW0-csTcBaGdPBDLAL2ci2AT9pTn2tppGPU_8";

        let Some(body) = ArweaveClient::get_test(&Word::from(ID)).await else {
            return;
        };
        let body = String::from_utf8(body).unwrap();

        let expected = r#"
            {"name":"Arloader NFT #1","description":"Super dope, one of a kind NFT","collection":{"name":"Arloader NFT","family":"We AR"},"attributes":[{"trait_type":"cx","value":-0.4042198883730073},{"trait_type":"cy","value":0.5641681708263335},{"trait_type":"iters","value":44}],"properties":{"category":"image","files":[{"uri":"https://arweave.net/7gWCr96zc0QQCXOsn5Vk9ROVGFbMaA9-cYpzZI8ZMDs","type":"image/png"},{"uri":"https://arweave.net/URwQtoqrbYlc5183STNy3ZPwSCRY4o8goaF7MJay3xY/1.png","type":"image/png"}]},"image":"https://arweave.net/URwQtoqrbYlc5183STNy3ZPwSCRY4o8goaF7MJay3xY/1.png"}
        "#.trim_start().trim_end();
        assert_eq!(expected, body);
    }

    #[graph::test]
    async fn no_client_retries_to_allow_polling_monitor_to_handle_retries_internally() {
        const CID: &str = "QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn";

        let server = MockServer::start().await;
        let ipfs_client =
            IpfsRpcClient::new_unchecked(server.uri(), IpfsMetrics::test(), &discard()).unwrap();
        let ipfs_service = ipfs_service(Arc::new(ipfs_client), 10, Duration::from_secs(1), 1);
        let path = ContentPath::new(CID).unwrap();

        Mock::given(m::method("POST"))
            .and(m::path("/api/v0/cat"))
            .and(m::query_param("arg", CID))
            .respond_with(ResponseTemplate::new(500))
            .up_to_n_times(1)
            .expect(1)
            .mount(&server)
            .await;

        Mock::given(m::method("POST"))
            .and(m::path("/api/v0/cat"))
            .and(m::query_param("arg", CID))
            .respond_with(ResponseTemplate::new(200))
            .expect(..=1)
            .mount(&server)
            .await;

        // This means that we never reached the successful response.
        ipfs_service
            .oneshot(IpfsRequest {
                ctx: IpfsContext::test(),
                path,
            })
            .await
            .unwrap_err();
    }
}
