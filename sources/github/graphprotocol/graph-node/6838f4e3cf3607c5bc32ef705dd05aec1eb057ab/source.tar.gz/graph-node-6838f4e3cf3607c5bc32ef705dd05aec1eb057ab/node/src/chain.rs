use crate::config::{ChainSettings as ConfigChainSettings, Config, ProviderDetails};
use crate::network_setup::{
    AdapterConfiguration, EthAdapterConfig, FirehoseAdapterConfig, Networks,
};
use ethereum::ProviderEthRpcMetrics;
use ethereum::chain::ChainSettings;
use ethereum::chain::{
    EthereumAdapterSelector, EthereumBlockRefetcher, EthereumRuntimeAdapterBuilder,
    EthereumStreamBuilder,
};
use ethereum::network::EthereumNetworkAdapter;
use graph::anyhow::bail;
use graph::blockchain::client::ChainClient;
use graph::blockchain::{BlockchainKind, BlockchainMap, ChainIdentifier};
use graph::cheap_clone::CheapClone;
use graph::components::network_provider::ChainName;
use graph::components::store::BlockStore as _;
use graph::endpoint::EndpointMetrics;
use graph::env::{ENV_VARS, EnvVars};
use graph::firehose::FirehoseEndpoint;
use graph::futures03::future::try_join_all;
use graph::itertools::Itertools;
use graph::log::factory::LoggerFactory;
use graph::prelude::MetricsRegistry;
use graph::prelude::anyhow;
use graph::slog::{Logger, debug, info, o, warn};
use graph::url::Url;
use graph_chain_ethereum::{self as ethereum, Transport};
use graph_store_postgres::{BlockStore, ChainHeadUpdateListener};
use std::cmp::Ordering;
use std::collections::BTreeMap;
use std::sync::Arc;
use tokio::time::timeout;

// The status of a provider that we learned from connecting to it
#[derive(PartialEq)]
pub enum ProviderNetworkStatus {
    Broken {
        chain_id: String,
        provider: String,
    },
    Version {
        chain_id: String,
        ident: ChainIdentifier,
    },
}

pub trait ChainFilter: Send + Sync {
    fn filter(&self, chain_name: &str) -> bool;
}

pub struct AnyChainFilter;

impl ChainFilter for AnyChainFilter {
    fn filter(&self, _: &str) -> bool {
        true
    }
}

pub struct OneChainFilter {
    chain_name: String,
}

impl OneChainFilter {
    pub fn new(chain_name: String) -> Self {
        Self { chain_name }
    }
}

impl ChainFilter for OneChainFilter {
    fn filter(&self, chain_name: &str) -> bool {
        self.chain_name == chain_name
    }
}

pub fn create_firehose_networks(
    logger: Logger,
    config: &Config,
    endpoint_metrics: Arc<EndpointMetrics>,
    chain_filter: &dyn ChainFilter,
) -> Vec<AdapterConfiguration> {
    debug!(
        logger,
        "Creating firehose networks [{} chains, ingestor {}]",
        config.chains.chains.len(),
        config.chains.ingestor,
    );

    let mut networks_by_kind: BTreeMap<(BlockchainKind, ChainName), Vec<Arc<FirehoseEndpoint>>> =
        BTreeMap::new();

    let filtered_chains = config
        .chains
        .chains
        .iter()
        .filter(|(name, _)| chain_filter.filter(name));

    for (name, chain) in filtered_chains {
        let name: ChainName = name.as_str().into();
        for provider in &chain.providers {
            let logger = logger.cheap_clone();
            if let ProviderDetails::Firehose(ref firehose) = provider.details {
                info!(
                    &logger,
                    "Configuring firehose endpoint";
                    "provider" => &provider.label,
                    "network" => &name.to_string(),
                );

                let parsed_networks = networks_by_kind
                    .entry((chain.protocol, name.clone()))
                    .or_default();

                // Create n FirehoseEndpoints where n is the size of the pool. If a
                // subgraph limit is defined for this endpoint then each endpoint
                // instance will have their own subgraph limit.
                // eg: pool_size = 3 and sg_limit 2 will result in 3 separate instances
                // of FirehoseEndpoint and each of those instance can be used in 2 different
                // SubgraphInstances.
                for _ in 0..firehose.conn_pool_size {
                    parsed_networks.push(Arc::new(FirehoseEndpoint::new(
                        // This label needs to be the original label so that the metrics
                        // can be deduped.
                        &provider.label,
                        &firehose.url,
                        firehose.token.clone(),
                        firehose.key.clone(),
                        firehose.filters_enabled(),
                        firehose.compression_enabled(),
                        firehose.limit_for(&config.node),
                        endpoint_metrics.cheap_clone(),
                    )));
                }
            }
        }
    }

    networks_by_kind
        .into_iter()
        .map(|((kind, chain_id), endpoints)| {
            AdapterConfiguration::Firehose(FirehoseAdapterConfig {
                chain_id,
                kind,
                adapters: endpoints,
            })
        })
        .collect()
}

impl From<ConfigChainSettings> for ChainSettings {
    fn from(c: ConfigChainSettings) -> Self {
        let ConfigChainSettings {
            polling_interval,
            json_rpc_timeout,
            request_retries,
            max_block_range_size,
            block_batch_size,
            block_ptr_batch_size,
            max_event_only_range,
            target_triggers_per_block_range,
            get_logs_max_contracts,
            block_ingestor_max_concurrent_json_rpc_calls,
            genesis_block_number,
        } = c;
        ChainSettings {
            polling_interval,
            json_rpc_timeout,
            request_retries,
            max_block_range_size,
            block_batch_size,
            block_ptr_batch_size,
            max_event_only_range,
            target_triggers_per_block_range,
            get_logs_max_contracts,
            block_ingestor_max_concurrent_json_rpc_calls,
            genesis_block_number,
        }
    }
}

/// Parses all Ethereum connection strings and returns their network names and
/// `EthereumAdapter`.
pub async fn create_ethereum_networks(
    logger: Logger,
    registry: Arc<MetricsRegistry>,
    config: &Config,
    endpoint_metrics: Arc<EndpointMetrics>,
    chain_filter: &dyn ChainFilter,
) -> anyhow::Result<Vec<AdapterConfiguration>> {
    let eth_rpc_metrics = Arc::new(ProviderEthRpcMetrics::new(registry));
    let eth_networks_futures = config
        .chains
        .chains
        .iter()
        .filter(|(_, chain)| chain.protocol == BlockchainKind::Ethereum)
        .filter(|(name, _)| chain_filter.filter(name))
        .map(|(name, _)| {
            create_ethereum_networks_for_chain(
                &logger,
                eth_rpc_metrics.clone(),
                config,
                name,
                endpoint_metrics.cheap_clone(),
            )
        });

    try_join_all(eth_networks_futures).await
}

/// Parses a single Ethereum connection string and returns its network name and `EthereumAdapter`.
pub async fn create_ethereum_networks_for_chain(
    logger: &Logger,
    eth_rpc_metrics: Arc<ProviderEthRpcMetrics>,
    config: &Config,
    network_name: &str,
    endpoint_metrics: Arc<EndpointMetrics>,
) -> anyhow::Result<AdapterConfiguration> {
    let chain = config
        .chains
        .chains
        .get(network_name)
        .ok_or_else(|| anyhow!("unknown network {}", network_name))?;
    let settings = Arc::new(ChainSettings::from(chain.settings.clone()));
    let mut adapters = vec![];
    let mut call_only_adapters = vec![];

    for provider in &chain.providers {
        let (web3, call_only) = match &provider.details {
            ProviderDetails::Web3Call(web3) => (web3, true),
            ProviderDetails::Web3(web3) => (web3, false),
            _ => {
                continue;
            }
        };

        let capabilities = web3.node_capabilities();
        if call_only && !capabilities.archive {
            bail!("Ethereum call-only adapters require archive features to be enabled");
        }

        let logger = logger.new(o!("provider" => provider.label.clone()));
        let compression = web3.compression();
        info!(
            logger,
            "Creating transport";
            "url" => &web3.url,
            "capabilities" => capabilities,
            "compression" => compression.to_string()
        );

        use crate::config::Transport::*;

        let no_eip2718 = web3.features.contains("no_eip2718");
        let transport = match web3.transport {
            Rpc => Transport::new_rpc(
                Url::parse(&web3.url)?,
                web3.headers.clone(),
                endpoint_metrics.cheap_clone(),
                &provider.label,
                no_eip2718,
                compression,
            ),
            Ipc => Transport::new_ipc(&web3.url).await,
            Ws => Transport::new_ws(&web3.url).await,
        };

        let supports_eip_1898 = !web3.features.contains("no_eip1898");
        let adapter = EthereumNetworkAdapter::new(
            endpoint_metrics.cheap_clone(),
            capabilities,
            Arc::new(
                graph_chain_ethereum::EthereumAdapter::new(
                    logger,
                    provider.label.clone(),
                    transport,
                    eth_rpc_metrics.clone(),
                    supports_eip_1898,
                    call_only,
                    settings.clone(),
                )
                .await,
            ),
            web3.limit_for(&config.node),
        );

        if call_only {
            call_only_adapters.push(adapter);
        } else {
            adapters.push(adapter);
        }
    }

    adapters.sort_by(|a, b| {
        a.capabilities
            .partial_cmp(&b.capabilities)
            // We can't define a total ordering over node capabilities,
            // so incomparable items are considered equal and end up
            // near each other.
            .unwrap_or(Ordering::Equal)
    });

    Ok(AdapterConfiguration::Rpc(EthAdapterConfig {
        chain_id: network_name.into(),
        adapters,
        call_only: call_only_adapters,
        settings,
    }))
}

/// Networks as chains will create the necessary chains from the adapter information.
/// There are two major cases that are handled currently:
/// Deep integration chains (explicitly defined on the graph-node like Ethereum, Near, etc):
///  - These can have adapter of any type. Adapters of firehose and rpc types are used by the Chain implementation, aka deep integration
///  - The substreams adapters will trigger the creation of a Substreams chain, the priority for the block ingestor setup depends on the chain, if enabled at all.
///    Substreams Chain(chains the graph-node knows nothing about and are only accessible through substreams):
///  - This chain type is more generic and can only have adapters of substreams type.
///  - Substreams chain are created as a "secondary" chain for deep integrations but in that case the block ingestor should be run by the main/deep integration chain.
///  - These chains will use SubstreamsBlockIngestor by default.
pub async fn networks_as_chains(
    config: &Arc<EnvVars>,
    blockchain_map: &mut BlockchainMap,
    logger: &Logger,
    networks: &Networks,
    store: BlockStore,
    logger_factory: &LoggerFactory,
    metrics_registry: Arc<MetricsRegistry>,
    chain_head_update_listener: Arc<ChainHeadUpdateListener>,
) {
    let adapters = networks
        .adapters
        .iter()
        .sorted_by_key(|a| a.chain_id())
        .chunk_by(|a| a.chain_id())
        .into_iter()
        .map(|(chain_id, adapters)| (chain_id, adapters.into_iter().collect_vec()))
        .collect_vec();

    let chains = adapters.into_iter().map(|(chain_id, adapters)| {
        let adapters: Vec<&AdapterConfiguration> = adapters.into_iter().collect();
        let kind = adapters
            .first()
            .map(|a| a.blockchain_kind())
            .expect("validation should have checked we have at least one provider");
        (chain_id, adapters, kind)
    });

    for (chain_id, adapters, kind) in chains.into_iter() {
        let chain_store = match store.chain_store(chain_id).await {
            Some(c) => c,
            None => {
                let ident = match timeout(
                    config.genesis_validation_timeout,
                    networks.chain_identifier(logger, chain_id),
                )
                .await
                {
                    Ok(Ok(ident)) => ident,
                    err => {
                        warn!(
                            &logger,
                            "unable to fetch genesis for {}. Err: {:?}.falling back to the default value",
                            chain_id,
                            err
                        );
                        ChainIdentifier::default()
                    }
                };
                store
                    .create_chain_store(chain_id, ident)
                    .await
                    .expect("must be able to create store if one is not yet setup for the chain")
            }
        };

        match kind {
            BlockchainKind::Ethereum => {
                // settings come from the first RPC adapter config; falls back to ENV_VAR
                // defaults for firehose-only chains.
                let settings = adapters
                    .iter()
                    .find_map(|a| a.as_rpc().map(|r| r.settings.clone()))
                    .unwrap_or_else(|| Arc::new(ChainSettings::from_env_defaults()));

                let firehose_endpoints = networks.firehose_endpoints(chain_id.clone());
                let eth_adapters = networks.ethereum_rpcs(chain_id.clone());

                let cc = if !firehose_endpoints.is_empty() {
                    ChainClient::<graph_chain_ethereum::Chain>::new_firehose(firehose_endpoints)
                } else {
                    ChainClient::<graph_chain_ethereum::Chain>::new_rpc(eth_adapters.clone())
                };

                let client = Arc::new(cc);
                let eth_adapters = Arc::new(eth_adapters);
                let adapter_selector = EthereumAdapterSelector::new(
                    logger_factory.clone(),
                    client.clone(),
                    metrics_registry.clone(),
                    chain_store.clone(),
                    eth_adapters.clone(),
                );

                let call_cache = chain_store.cheap_clone();

                let chain = ethereum::Chain::new(
                    logger_factory.clone(),
                    chain_id.clone(),
                    metrics_registry.clone(),
                    chain_store.cheap_clone(),
                    call_cache,
                    client,
                    chain_head_update_listener.clone(),
                    Arc::new(EthereumStreamBuilder {}),
                    Arc::new(EthereumBlockRefetcher {}),
                    Arc::new(adapter_selector),
                    Arc::new(EthereumRuntimeAdapterBuilder {}),
                    eth_adapters,
                    ENV_VARS.reorg_threshold(),
                    true,
                    settings,
                );

                blockchain_map
                    .insert::<graph_chain_ethereum::Chain>(chain_id.clone(), Arc::new(chain));
            }
            BlockchainKind::Near => {
                let firehose_endpoints = networks.firehose_endpoints(chain_id.clone());
                let chain = graph_chain_near::Chain::new(
                    logger_factory.clone(),
                    chain_id.clone(),
                    chain_store.cheap_clone(),
                    firehose_endpoints,
                    metrics_registry.clone(),
                );
                blockchain_map.insert::<graph_chain_near::Chain>(chain_id.clone(), Arc::new(chain));
            }
        }
    }
}

#[cfg(test)]
mod test {
    use crate::config::{Config, Opt};
    use crate::network_setup::{AdapterConfiguration, Networks};
    use graph::components::network_provider::ChainName;
    use graph::endpoint::EndpointMetrics;
    use graph::log::logger;
    use graph::prelude::MetricsRegistry;
    use graph_chain_ethereum::NodeCapabilities;
    use std::sync::Arc;

    #[graph::test]
    async fn correctly_parse_ethereum_networks() {
        let logger = logger(true);

        let network_args = vec![
            "mainnet:traces:http://localhost:8545/".to_string(),
            "goerli:archive:http://localhost:8546/".to_string(),
        ];

        let opt = Opt {
            postgres_url: Some("not needed".to_string()),
            config: None,
            store_connection_pool_size: 5,
            postgres_secondary_hosts: vec![],
            postgres_host_weights: vec![],
            disable_block_ingestor: true,
            node_id: "default".to_string(),
            ethereum_rpc: network_args,
            ethereum_ws: vec![],
            ethereum_ipc: vec![],
            unsafe_config: false,
        };

        let metrics = Arc::new(EndpointMetrics::mock());
        let config = Config::load(&logger, &opt).expect("can create config");
        let metrics_registry = Arc::new(MetricsRegistry::mock());

        let networks = Networks::from_config(logger, &config, metrics_registry, metrics, &[])
            .await
            .expect("can parse config");
        let mut network_names = networks
            .adapters
            .iter()
            .map(|a| a.chain_id())
            .collect::<Vec<&ChainName>>();
        network_names.sort();

        let traces = NodeCapabilities {
            archive: false,
            traces: true,
        };
        let archive = NodeCapabilities {
            archive: true,
            traces: false,
        };

        let mainnet: Vec<&AdapterConfiguration> = networks
            .adapters
            .iter()
            .filter(|a| a.chain_id().as_str().eq("mainnet"))
            .collect();
        assert_eq!(mainnet.len(), 1);
        let mainnet = mainnet.first().unwrap().as_rpc().unwrap();
        assert_eq!(mainnet.adapters.len(), 1);
        let mainnet = mainnet.adapters.first().unwrap();
        assert_eq!(mainnet.capabilities, traces);

        let goerli: Vec<&AdapterConfiguration> = networks
            .adapters
            .iter()
            .filter(|a| a.chain_id().as_str().eq("goerli"))
            .collect();
        assert_eq!(goerli.len(), 1);
        let goerli = goerli.first().unwrap().as_rpc().unwrap();
        assert_eq!(goerli.adapters.len(), 1);
        let goerli = goerli.adapters.first().unwrap();
        assert_eq!(goerli.capabilities, archive);
    }
}
