//! Tools for parsing SQL expressions
use sqlparser::ast as p;
use sqlparser::dialect::PostgreSqlDialect;
use sqlparser::parser::{Parser as SqlParser, ParserError};
use sqlparser::tokenizer::Tokenizer;

use crate::schema::SchemaValidationError;

pub(crate) trait CheckIdentFn: Fn(&str) -> Result<(), SchemaValidationError> {}

impl<T> CheckIdentFn for T where T: Fn(&str) -> Result<(), SchemaValidationError> {}

/// Parse a SQL expression and check that it only uses whitelisted
/// operations and functions. The `check_ident` function is called for each
/// identifier in the expression
pub(crate) fn parse<F: CheckIdentFn>(
    sql: &str,
    check_ident: F,
) -> Result<(), Vec<SchemaValidationError>> {
    let mut validator = Validator {
        check_ident,
        errors: Vec::new(),
    };
    VisitExpr::visit(sql, &mut validator)
        .map(|_| ())
        .map_err(|()| validator.errors)
}

/// A visitor for `VistExpr` that gets called for the constructs for which
/// we need different behavior between validation and query generation in
/// `store/postgres/src/relational/rollup.rs`. Note that the visitor can
/// mutate both itself (e.g., to store errors) and the expression it is
/// visiting.
///
/// The error type is `()`, as the visitor is expected to record any errors
/// internally
pub trait ExprVisitor {
    /// Visit an identifier (column name). Must return `Err` if the
    /// identifier is not allowed
    #[allow(clippy::result_unit_err)]
    fn visit_ident(&mut self, ident: &mut p::Ident) -> Result<(), ()>;
    /// Visit a function name. Must return `Err` if the function is not
    /// allowed
    #[allow(clippy::result_unit_err)]
    fn visit_func_name(&mut self, func: &mut p::ObjectNamePart) -> Result<(), ()>;
    /// Called when we encounter a construct that is not supported like a
    /// subquery
    fn not_supported(&mut self, msg: String);
    /// Called if the SQL expression we are visiting has SQL syntax errors
    fn parse_error(&mut self, e: sqlparser::parser::ParserError);
}

pub struct VisitExpr<'a> {
    visitor: &'a mut dyn ExprVisitor,
}

impl<'a> VisitExpr<'a> {
    fn nope(&mut self, construct: &str) -> Result<(), ()> {
        self.not_supported(format!("Expressions using {construct} are not supported"))
    }

    fn illegal_function(&mut self, msg: String) -> Result<(), ()> {
        self.not_supported(format!("Illegal function: {msg}"))
    }

    fn not_supported(&mut self, msg: String) -> Result<(), ()> {
        self.visitor.not_supported(msg);
        Err(())
    }

    /// Parse `sql` into an expression and traverse it, calling back into
    /// `visitor` at the appropriate places. Return the parsed expression,
    /// which might have been changed by the visitor, on success. On error,
    /// return `Err(())`. The visitor will know the details of the error
    /// since this can only happen if `visit_ident` or `visit_func_name`
    /// returned an error, or `parse_error` or `not_supported` was called.
    #[allow(clippy::result_unit_err)]
    pub fn visit(sql: &str, visitor: &'a mut dyn ExprVisitor) -> Result<p::Expr, ()> {
        let dialect = PostgreSqlDialect {};

        let mut parser = SqlParser::new(&dialect);
        let tokens = Tokenizer::new(&dialect, sql)
            .with_unescape(true)
            .tokenize_with_location()
            .unwrap();
        parser = parser.with_tokens_with_locations(tokens);
        let mut visit = VisitExpr { visitor };
        let mut expr = match parser.parse_expr() {
            Ok(expr) => expr,
            Err(e) => {
                visitor.parse_error(e);
                return Err(());
            }
        };
        visit.visit_expr(&mut expr).map(|()| expr)
    }

    fn visit_expr(&mut self, expr: &mut p::Expr) -> Result<(), ()> {
        use p::Expr::*;

        match expr {
            Identifier(ident) => self.visitor.visit_ident(ident),
            BinaryOp { left, op, right } => {
                self.check_binary_op(op)?;
                self.visit_expr(left)?;
                self.visit_expr(right)?;
                Ok(())
            }
            UnaryOp { op, expr } => {
                self.check_unary_op(op)?;
                self.visit_expr(expr)?;
                Ok(())
            }
            Function(func) => self.visit_func(func),
            Value(_) => Ok(()),
            Case {
                operand,
                conditions,
                else_result,
                case_token: _,
                end_token: _,
            } => {
                if let Some(operand) = operand {
                    self.visit_expr(operand)?;
                }
                for condition in conditions {
                    self.visit_expr(&mut condition.condition)?;
                    self.visit_expr(&mut condition.result)?;
                }
                if let Some(else_result) = else_result {
                    self.visit_expr(else_result)?;
                }
                Ok(())
            }
            Cast {
                expr,
                data_type: _,
                kind,
                format: _,
                array: _,
            } => match kind {
                // Cast: `CAST(<expr> as <datatype>)`
                // DoubleColon: `<expr>::<datatype>`
                p::CastKind::Cast | p::CastKind::DoubleColon => self.visit_expr(expr),
                // These two are not Postgres syntax
                p::CastKind::TryCast | p::CastKind::SafeCast => {
                    self.nope(&format!("non-standard cast '{:?}'", kind))
                }
            },
            Nested(expr) | IsFalse(expr) | IsNotFalse(expr) | IsTrue(expr) | IsNotTrue(expr)
            | IsNull(expr) | IsNotNull(expr) => self.visit_expr(expr),
            IsDistinctFrom(expr1, expr2) | IsNotDistinctFrom(expr1, expr2) => {
                self.visit_expr(expr1)?;
                self.visit_expr(expr2)?;
                Ok(())
            }
            CompoundIdentifier(_) => self.nope("CompoundIdentifier"),
            JsonAccess { .. } => self.nope("JsonAccess"),
            IsUnknown(_) => self.nope("IsUnknown"),
            IsNotUnknown(_) => self.nope("IsNotUnknown"),
            InList { .. } => self.nope("InList"),
            InSubquery { .. } => self.nope("InSubquery"),
            InUnnest { .. } => self.nope("InUnnest"),
            Between { .. } => self.nope("Between"),
            Like { .. } => self.nope("Like"),
            ILike { .. } => self.nope("ILike"),
            SimilarTo { .. } => self.nope("SimilarTo"),
            RLike { .. } => self.nope("RLike"),
            AnyOp { .. } => self.nope("AnyOp"),
            AllOp { .. } => self.nope("AllOp"),
            Convert { .. } => self.nope("Convert"),
            AtTimeZone { .. } => self.nope("AtTimeZone"),
            Extract { .. } => self.nope("Extract"),
            Ceil { .. } => self.nope("Ceil"),
            Floor { .. } => self.nope("Floor"),
            Position { .. } => self.nope("Position"),
            Substring { .. } => self.nope("Substring"),
            Trim { .. } => self.nope("Trim"),
            Overlay { .. } => self.nope("Overlay"),
            Collate { .. } => self.nope("Collate"),
            TypedString { .. } => self.nope("TypedString"),
            Exists { .. } => self.nope("Exists"),
            Subquery(_) => self.nope("Subquery"),
            GroupingSets(_) => self.nope("GroupingSets"),
            Cube(_) => self.nope("Cube"),
            Rollup(_) => self.nope("Rollup"),
            Tuple(_) => self.nope("Tuple"),
            Struct { .. } => self.nope("Struct"),
            Named { .. } => self.nope("Named"),
            Array(_) => self.nope("Array"),
            Interval(_) => self.nope("Interval"),
            MatchAgainst { .. } => self.nope("MatchAgainst"),
            Wildcard(_) => self.nope("Wildcard"),
            QualifiedWildcard(_, _) => self.nope("QualifiedWildcard"),
            Dictionary(_) => self.nope("Dictionary"),
            OuterJoin(_) => self.nope("OuterJoin"),
            Prior(_) => self.nope("Prior"),
            CompoundFieldAccess { .. } => self.nope("CompoundFieldAccess"),
            IsNormalized { .. } => self.nope("IsNormalized"),
            Prefixed { .. } => self.nope("Prefixed"),
            Map(_) => self.nope("Map"),
            Lambda(_) => self.nope("Lambda"),
            MemberOf(_) => self.nope("MemberOf"),
        }
    }

    fn visit_func(&mut self, func: &mut p::Function) -> Result<(), ()> {
        let p::Function {
            name,
            parameters,
            args: pargs,
            filter,
            null_treatment,
            over,
            within_group,
            uses_odbc_syntax,
        } = func;

        if filter.is_some()
            || null_treatment.is_some()
            || over.is_some()
            || !within_group.is_empty()
            || *uses_odbc_syntax
            || !matches!(parameters, p::FunctionArguments::None)
        {
            return self.illegal_function(format!("call to {name} uses an illegal feature"));
        }

        let idents = &mut name.0;
        if idents.len() != 1 {
            return self.illegal_function(format!(
                "function name {name} uses a qualified name with '.'"
            ));
        }
        self.visitor.visit_func_name(&mut idents[0])?;
        match pargs {
            p::FunctionArguments::None => { /* nothing to do */ }
            p::FunctionArguments::Subquery(_) => {
                return self.illegal_function(format!("call to {name} uses a subquery argument"));
            }
            p::FunctionArguments::List(pargs) => {
                let p::FunctionArgumentList {
                    duplicate_treatment,
                    args,
                    clauses,
                } = pargs;
                if duplicate_treatment.is_some() {
                    return self
                        .illegal_function(format!("call to {name} uses a duplicate treatment"));
                }
                if !clauses.is_empty() {
                    return self.illegal_function(format!("call to {name} uses a clause"));
                }
                for arg in args {
                    use p::FunctionArg::*;
                    match arg {
                        Named { .. } => {
                            return self
                                .illegal_function(format!("call to {name} uses a named argument"));
                        }
                        Unnamed(arg) => match arg {
                            p::FunctionArgExpr::Expr(expr) => {
                                self.visit_expr(expr)?;
                            }
                            p::FunctionArgExpr::QualifiedWildcard(_)
                            | p::FunctionArgExpr::Wildcard
                            | p::FunctionArgExpr::WildcardWithOptions(_) => {
                                return self.illegal_function(format!(
                                    "call to {name} uses a wildcard argument"
                                ));
                            }
                        },
                        ExprNamed {
                            name: expr_name,
                            arg: _,
                            operator: _,
                        } => {
                            return self.illegal_function(format!(
                                "call to {name} uses illegal ExprNamed {expr_name}"
                            ));
                        }
                    };
                }
            }
        }
        Ok(())
    }

    fn check_binary_op(&mut self, op: &p::BinaryOperator) -> Result<(), ()> {
        use p::BinaryOperator::*;
        match op {
            Plus | Minus | Multiply | Divide | Modulo | PGExp | Gt | Lt | GtEq | LtEq
            | Spaceship | Eq | NotEq | And | Or => Ok(()),
            StringConcat
            | Xor
            | BitwiseOr
            | BitwiseAnd
            | BitwiseXor
            | DuckIntegerDivide
            | MyIntegerDivide
            | Custom(_)
            | PGBitwiseXor
            | PGBitwiseShiftLeft
            | PGBitwiseShiftRight
            | PGOverlap
            | PGRegexMatch
            | PGRegexIMatch
            | PGRegexNotMatch
            | PGRegexNotIMatch
            | PGLikeMatch
            | PGILikeMatch
            | PGNotLikeMatch
            | PGNotILikeMatch
            | PGStartsWith
            | PGCustomBinaryOperator(_)
            | Arrow
            | LongArrow
            | HashArrow
            | HashLongArrow
            | AtAt
            | AtArrow
            | ArrowAt
            | HashMinus
            | AtQuestion
            | Question
            | QuestionAnd
            | QuestionPipe
            | Match
            | Regexp
            | Overlaps
            | DoubleHash
            | LtDashGt
            | AndLt
            | AndGt
            | LtLtPipe
            | PipeGtGt
            | AndLtPipe
            | PipeAndGt
            | LtCaret
            | GtCaret
            | QuestionHash
            | QuestionDash
            | QuestionDashPipe
            | QuestionDoublePipe
            | At
            | TildeEq
            | Assignment => self.not_supported(format!("binary operator {op} is not supported")),
        }
    }

    fn check_unary_op(&mut self, op: &p::UnaryOperator) -> Result<(), ()> {
        use p::UnaryOperator::*;
        match op {
            Plus | Minus | Not => Ok(()),
            BitwiseNot | PGSquareRoot | PGCubeRoot | PGPostfixFactorial | PGPrefixFactorial
            | PGAbs | BangNot | Hash | AtDashAt | DoubleAt | QuestionDash | QuestionPipe => {
                self.not_supported(format!("unary operator {op} is not supported"))
            }
        }
    }
}

/// An `ExprVisitor` that validates an expression
struct Validator<F> {
    check_ident: F,
    errors: Vec<SchemaValidationError>,
}

const FN_WHITELIST: [&str; 14] = [
    // Clearly deterministic functions from
    // https://www.postgresql.org/docs/current/functions-math.html, Table
    // 9.5. We could also add trig functions (Table 9.7 and 9.8), but under
    // no circumstances random functions from Table 9.6
    "abs", "ceil", "ceiling", "div", "floor", "gcd", "lcm", "mod", "power", "sign",
    // Conditional functions from
    // https://www.postgresql.org/docs/current/functions-conditional.html.
    "coalesce", "nullif", "greatest", "least",
];

impl<F: CheckIdentFn> ExprVisitor for Validator<F> {
    fn visit_ident(&mut self, ident: &mut p::Ident) -> Result<(), ()> {
        match (self.check_ident)(&ident.value) {
            Ok(()) => Ok(()),
            Err(e) => {
                self.errors.push(e);
                Err(())
            }
        }
    }

    fn visit_func_name(&mut self, func: &mut p::ObjectNamePart) -> Result<(), ()> {
        let func = match func {
            p::ObjectNamePart::Identifier(ident) => ident,
            p::ObjectNamePart::Function(p::ObjectNamePartFunction { name, args: _ }) => {
                self.not_supported(format!("function {name} is an object naming function"));
                return Err(());
            }
        };
        let p::Ident {
            value,
            quote_style,
            span: _,
        } = &func;
        let whitelisted = match quote_style {
            Some(_) => FN_WHITELIST.contains(&value.as_str()),
            None => FN_WHITELIST
                .iter()
                .any(|name| name.eq_ignore_ascii_case(value)),
        };
        if whitelisted {
            Ok(())
        } else {
            self.not_supported(format!("Function {func} is not supported"));
            Err(())
        }
    }

    fn not_supported(&mut self, msg: String) {
        self.errors
            .push(SchemaValidationError::ExprNotSupported(msg));
    }

    fn parse_error(&mut self, e: ParserError) {
        self.errors
            .push(SchemaValidationError::ExprParseError(e.to_string()));
    }
}
