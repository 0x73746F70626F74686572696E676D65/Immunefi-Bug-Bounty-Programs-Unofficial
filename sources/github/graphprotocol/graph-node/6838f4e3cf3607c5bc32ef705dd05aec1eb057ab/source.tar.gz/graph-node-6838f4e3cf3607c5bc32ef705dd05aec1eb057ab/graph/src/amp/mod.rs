//! This module contains the functionality required to support Amp subgraphs.

pub mod client;
pub mod codec;
pub mod common;
pub mod error;
pub mod log;
pub mod manifest;
pub mod schema;
pub mod sql;
pub mod stream_aggregator;

pub use self::{
    client::{Client, flight_client::FlightClient},
    codec::Codec,
    manifest::Manifest,
};
