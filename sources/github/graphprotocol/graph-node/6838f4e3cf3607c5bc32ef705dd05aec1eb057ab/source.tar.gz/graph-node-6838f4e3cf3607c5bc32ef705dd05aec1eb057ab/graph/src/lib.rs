/// Traits and types for all system components.
pub mod components;

/// Common data types used throughout The Graph.
pub mod data;

/// Utilities.
pub mod util;

/// Extension traits for external types.
pub mod ext;

/// Logging utilities
pub mod log;

/// `CheapClone` trait.
pub mod cheap_clone;

pub mod data_source;

pub mod blockchain;

pub mod runtime;

pub mod firehose;

pub mod endpoint;

pub mod schema;

/// Helpers for parsing environment variables.
pub mod env;

pub mod ipfs;

pub mod tls;

pub mod abi;

pub mod amp;

/// Wrapper for spawning tasks that abort on panic, which is our default.
mod tokio;
#[cfg(debug_assertions)]
pub use tokio::TEST_RUNTIME;
pub use tokio::{
    block_on, spawn, spawn_allow_panic, spawn_blocking, spawn_blocking_allow_panic, spawn_thread,
};

pub use anyhow;
pub use bytes;
pub use futures01;
pub use futures03;
pub use graph_derive as derive;
pub use graph_derive::test;
pub use http;
pub use http_body_util;
pub use http0;
pub use hyper;
pub use hyper_util;
pub use itertools;
pub use parking_lot;
pub use petgraph;
pub use prometheus;
pub use semver;
pub use slog;
pub use sqlparser;
pub use stable_hash;
pub use stable_hash_legacy;
pub use url;

/// A prelude that makes all system component traits and data types available.
///
/// Add the following code to import all traits and data types listed below at once.
///
/// ```
/// use graph::prelude::*;
/// ```
pub mod prelude {
    pub use ::anyhow;
    pub use alloy;
    pub use anyhow::{Context as _, Error, anyhow};
    pub use chrono;
    pub use diesel;
    pub use envconfig;
    pub use hex;
    pub use lazy_static::lazy_static;
    pub use prost;
    pub use rand;
    pub use regex;
    pub use reqwest;
    pub use serde;
    pub use serde_derive::{Deserialize, Serialize};
    pub use serde_json;
    pub use serde_regex;
    pub use serde_yaml;
    pub use slog::{self, Logger, crit, debug, error, info, o, trace, warn};
    pub use std::convert::TryFrom;
    pub use std::fmt::Debug;
    pub use std::iter::FromIterator;
    pub use std::pin::Pin;
    pub use std::sync::Arc;
    pub use std::time::Duration;
    pub use thiserror;
    pub use tokio;
    pub use toml;
    pub use tonic;

    pub type DynTryFuture<'a, Ok = (), Err = Error> =
        Pin<Box<dyn futures03::Future<Output = Result<Ok, Err>> + Send + 'a>>;

    pub use crate::blockchain::{BlockHash, BlockPtr};

    pub use crate::components::ethereum::{
        EthereumBlock, EthereumBlockWithCalls, EthereumCall, LightEthereumBlock,
        LightEthereumBlockExt,
    };
    pub use crate::components::graphql::{GraphQLMetrics, GraphQlRunner};
    pub use crate::components::link_resolver::{
        IpfsResolver, JsonStreamValue, JsonValueStream, LinkResolver,
    };
    pub use crate::components::metrics::{
        Collector, Counter, CounterVec, Gauge, GaugeVec, Histogram, HistogramOpts, HistogramVec,
        MetricsRegistry, Opts, PrometheusError, Registry, stopwatch::StopwatchMetrics, subgraph::*,
    };
    pub use crate::components::store::{
        AssignmentChange, AssignmentOperation, AttributeNames, BLOCK_NUMBER_MAX, BlockNumber,
        CachedEthereumCall, ChainStore, Child, ChildMultiplicity, EntityCache, EntityCollection,
        EntityFilter, EntityLink, EntityOperation, EntityOrder, EntityOrderByChild,
        EntityOrderByChildInfo, EntityQuery, EntityRange, EntityWindow, EthereumCallCache,
        ParentLink, PartialBlockPtr, PoolWaitStats, QueryStore, QueryStoreManager, SeqGenerator,
        StaleCallCacheResult, StoreError, StoreEvent, StoreEventStreamBox, SubgraphStore,
        UnfailOutcome, WindowAttribute, write::EntityModification,
    };
    pub use crate::components::subgraph::{
        BlockState, BlockStateCheckpoint, HostMetrics, InstanceDSTemplateInfo, RuntimeHost,
        RuntimeHostBuilder, SubgraphInstanceManager, SubgraphRegistrar,
        SubgraphVersionSwitchingMode,
    };
    pub use crate::components::trigger_processor::TriggerProcessor;
    pub use crate::components::versions::{ApiVersion, FeatureFlag};
    pub use crate::components::{EventConsumer, EventProducer, transaction_receipt};
    pub use crate::env::ENV_VARS;

    pub use crate::cheap_clone::CheapClone;
    pub use crate::data::graphql::{
        SerializableValue, TryFromValue, ValueMap, shape_hash::shape_hash,
    };
    pub use crate::data::query::{
        Query, QueryError, QueryExecutionError, QueryResult, QueryTarget, QueryVariables,
    };
    pub use crate::data::store::scalar::{BigDecimal, BigInt, BigIntSign};
    pub use crate::data::store::{Attribute, Entity, NodeId, Value, ValueType};
    pub use crate::data::subgraph::schema::SubgraphDeploymentEntity;
    pub use crate::data::subgraph::{
        CreateSubgraphResult, DataSourceContext, DeploymentHash, DeploymentState, Link,
        SubgraphAssignmentProviderError, SubgraphManifest, SubgraphManifestResolveError,
        SubgraphManifestValidationError, SubgraphName, SubgraphRegistrarError,
        UnvalidatedSubgraphManifest,
    };
    pub use crate::data_source::DataSourceTemplateInfo;
    pub use crate::ext::futures::{
        CancelGuard, CancelHandle, CancelToken, CancelableError, FutureExtension,
        SharedCancelGuard, StreamExtension,
    };
    pub use crate::impl_slog_value;
    pub use crate::log::codes::LogCode;
    pub use crate::log::elastic::{ElasticDrainConfig, ElasticLoggingConfig, elastic_logger};
    pub use crate::log::factory::{
        ComponentLoggerConfig, ElasticComponentLoggerConfig, LoggerFactory,
    };
    pub use crate::log::split::split_logger;
    pub use crate::util::cache_weight::CacheWeight;
    pub use crate::util::futures::{TimeoutError, retry};
    pub use crate::util::stats::{AtomicMovingStats, MovingStats};
    pub use crate::util::test_utils::*;

    macro_rules! static_graphql {
        ($m:ident, $m2:ident, {$($n:ident,)*}) => {
                use graphql_tools::parser::$m2 as $m;
                pub use graphql_tools::parser::Pos;
                pub use $m::*;
                $(
                    pub type $n = $m::$n<'static, String>;
                )*
        };
    }

    // Static graphql mods. These are to be phased out, with a preference
    // toward making graphql generic over text. This helps to ease the
    // transition by providing the old graphql-parse 0.2.x API
    pub mod q {
        static_graphql!(q, query, {
            Document, Value, OperationDefinition, InlineFragment, TypeCondition,
            FragmentSpread, Field, Selection, SelectionSet, FragmentDefinition,
            Directive, VariableDefinition, Type, Query,
        });
        pub use q::parse_query;
    }
    pub mod s {
        static_graphql!(s, schema, {
            Field, Directive, InterfaceType, ObjectType, Value, TypeDefinition,
            EnumType, Type, Definition, Document, ScalarType, InputValue, DirectiveDefinition,
            UnionType, InputObjectType, EnumValue,
        });
        pub use s::parse_schema;
    }
    pub mod r {
        pub use crate::data::value::{Object, Value};
    }
}
