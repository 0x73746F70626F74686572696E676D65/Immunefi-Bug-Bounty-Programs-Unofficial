use std::sync::Arc;

use anyhow::anyhow;
use async_trait::async_trait;
use derive_more::Debug;
use http::header::ACCEPT;
use http::header::CACHE_CONTROL;
use reqwest::{StatusCode, redirect::Policy as RedirectPolicy};
use slog::Logger;

use crate::env::ENV_VARS;
use crate::ipfs::{
    IpfsClient, IpfsError, IpfsMetrics, IpfsRequest, IpfsResponse, IpfsResult, RetryPolicy,
    ServerAddress,
};

/// A client that connects to an IPFS gateway.
///
/// Reference: <https://specs.ipfs.tech/http-gateways/path-gateway>
#[derive(Clone, Debug)]
pub struct IpfsGatewayClient {
    server_address: ServerAddress,

    #[debug(skip)]
    http_client: reqwest::Client,

    metrics: IpfsMetrics,
    logger: Logger,
}

impl IpfsGatewayClient {
    /// Creates a new [IpfsGatewayClient] with the specified server address.
    /// Verifies that the server is responding to IPFS gateway requests.
    pub(crate) async fn new(
        server_address: impl AsRef<str>,
        metrics: IpfsMetrics,
        logger: &Logger,
    ) -> IpfsResult<Self> {
        let client = Self::new_unchecked(server_address, metrics, logger)?;

        client
            .send_test_request()
            .await
            .map_err(|reason| IpfsError::InvalidServer {
                server_address: client.server_address.clone(),
                reason,
            })?;

        Ok(client)
    }

    /// Creates a new [IpfsGatewayClient] with the specified server address.
    /// Does not verify that the server is responding to IPFS gateway requests.
    pub fn new_unchecked(
        server_address: impl AsRef<str>,
        metrics: IpfsMetrics,
        logger: &Logger,
    ) -> IpfsResult<Self> {
        Ok(Self {
            server_address: ServerAddress::new(server_address)?,
            http_client: reqwest::Client::builder()
                // IPFS gateways allow requests to directory CIDs.
                // However, they sometimes redirect before displaying the directory listing.
                // This policy permits that behavior.
                .redirect(RedirectPolicy::limited(1))
                .build()?,
            metrics,
            logger: logger.to_owned(),
        })
    }

    /// A one-time request sent at client initialization to verify that the specified
    /// server address is a valid IPFS gateway server.
    async fn send_test_request(&self) -> anyhow::Result<()> {
        // To successfully perform this test, it does not really matter which CID we use.
        const RANDOM_CID: &str = "QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn";

        // A special request described in the specification that should instruct the gateway
        // to perform a very quick local check and return either HTTP status 200, which would
        // mean the server has the content locally cached, or a 412 error, which would mean the
        // content is not locally cached. This information is sufficient to verify that the
        // server behaves like an IPFS gateway.
        let req = self
            .http_client
            .head(self.ipfs_url(RANDOM_CID))
            .header(CACHE_CONTROL, "only-if-cached");

        let fut = RetryPolicy::NonDeterministic
            .create("IPFS.Gateway.send_test_request", &self.logger)
            .no_logging()
            .no_timeout()
            .run(move || {
                let req = req.try_clone().expect("request can be cloned");

                async move {
                    let resp = req.send().await?;
                    let status = resp.status();

                    if status == StatusCode::OK || status == StatusCode::PRECONDITION_FAILED {
                        return Ok(true);
                    }

                    resp.error_for_status()?;

                    Ok(false)
                }
            });

        let ok = tokio::time::timeout(ENV_VARS.ipfs_request_timeout, fut)
            .await
            .map_err(|_| anyhow!("request timed out"))??;

        if !ok {
            return Err(anyhow!("not a gateway"));
        }

        Ok(())
    }

    fn ipfs_url(&self, path_and_query: impl AsRef<str>) -> String {
        format!("{}ipfs/{}", self.server_address, path_and_query.as_ref())
    }
}

#[async_trait]
impl IpfsClient for IpfsGatewayClient {
    fn metrics(&self) -> &IpfsMetrics {
        &self.metrics
    }

    async fn call(self: Arc<Self>, req: IpfsRequest) -> IpfsResult<IpfsResponse> {
        use IpfsRequest::*;

        let (path, req) = match req {
            Cat(path) => {
                let url = self.ipfs_url(path.to_string());
                let req = self.http_client.get(url);

                (path, req)
            }
            GetBlock(path) => {
                let url = self.ipfs_url(format!("{path}?format=raw"));

                let req = self
                    .http_client
                    .get(url)
                    .header(ACCEPT, "application/vnd.ipld.raw");

                (path, req)
            }
        };

        let response = req.send().await?.error_for_status()?;

        Ok(IpfsResponse { path, response })
    }
}

#[cfg(test)]
mod tests {
    use std::time::Duration;

    use bytes::BytesMut;
    use futures03::TryStreamExt;
    use wiremock::Mock;
    use wiremock::MockBuilder;
    use wiremock::MockServer;
    use wiremock::ResponseTemplate;
    use wiremock::matchers as m;

    use super::*;
    use crate::data::subgraph::DeploymentHash;
    use crate::ipfs::{ContentPath, IpfsContext, IpfsMetrics};
    use crate::log::discard;

    const PATH: &str = "/ipfs/QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn";

    async fn mock_server() -> MockServer {
        MockServer::start().await
    }

    fn mock_head() -> MockBuilder {
        Mock::given(m::method("HEAD")).and(m::path(PATH))
    }

    fn mock_get() -> MockBuilder {
        Mock::given(m::method("GET")).and(m::path(PATH))
    }

    fn mock_gateway_check(status: StatusCode) -> Mock {
        mock_head()
            .and(m::header("Cache-Control", "only-if-cached"))
            .respond_with(ResponseTemplate::new(status))
    }

    fn mock_get_block() -> MockBuilder {
        mock_get()
            .and(m::query_param("format", "raw"))
            .and(m::header("Accept", "application/vnd.ipld.raw"))
    }

    async fn make_client() -> (MockServer, Arc<IpfsGatewayClient>) {
        let server = mock_server().await;
        let client =
            IpfsGatewayClient::new_unchecked(server.uri(), IpfsMetrics::test(), &discard())
                .unwrap();

        (server, Arc::new(client))
    }

    fn make_path() -> ContentPath {
        ContentPath::new(PATH).unwrap()
    }

    fn ms(millis: u64) -> Duration {
        Duration::from_millis(millis)
    }

    #[crate::test]
    async fn new_fails_to_create_the_client_if_gateway_is_not_accessible() {
        let server = mock_server().await;

        IpfsGatewayClient::new(server.uri(), IpfsMetrics::test(), &discard())
            .await
            .unwrap_err();
    }

    #[crate::test]
    async fn new_creates_the_client_if_it_can_check_the_gateway() {
        let server = mock_server().await;

        // Test content is cached locally on the gateway.
        mock_gateway_check(StatusCode::OK)
            .up_to_n_times(1)
            .expect(1)
            .mount(&server)
            .await;

        IpfsGatewayClient::new(server.uri(), IpfsMetrics::test(), &discard())
            .await
            .unwrap();

        // Test content is not cached locally on the gateway.
        mock_gateway_check(StatusCode::PRECONDITION_FAILED)
            .expect(1)
            .mount(&server)
            .await;

        IpfsGatewayClient::new(server.uri(), IpfsMetrics::test(), &discard())
            .await
            .unwrap();
    }

    #[crate::test]
    async fn new_retries_gateway_check_on_non_deterministic_errors() {
        let server = mock_server().await;

        mock_gateway_check(StatusCode::INTERNAL_SERVER_ERROR)
            .up_to_n_times(1)
            .expect(1)
            .mount(&server)
            .await;

        mock_gateway_check(StatusCode::OK)
            .expect(1)
            .mount(&server)
            .await;

        IpfsGatewayClient::new(server.uri(), IpfsMetrics::test(), &discard())
            .await
            .unwrap();
    }

    #[crate::test]
    async fn new_unchecked_creates_the_client_without_checking_the_gateway() {
        let server = mock_server().await;

        IpfsGatewayClient::new_unchecked(server.uri(), IpfsMetrics::test(), &discard()).unwrap();
    }

    #[crate::test]
    async fn cat_stream_returns_the_content() {
        let (server, client) = make_client().await;

        mock_get()
            .respond_with(ResponseTemplate::new(StatusCode::OK).set_body_bytes(b"some data"))
            .expect(1)
            .mount(&server)
            .await;

        let bytes = client
            .cat_stream(&IpfsContext::test(), &make_path(), None, RetryPolicy::None)
            .await
            .unwrap()
            .try_fold(BytesMut::new(), |mut acc, chunk| async {
                acc.extend(chunk);

                Ok(acc)
            })
            .await
            .unwrap();

        assert_eq!(bytes.as_ref(), b"some data")
    }

    #[crate::test]
    async fn cat_stream_fails_on_timeout() {
        let (server, client) = make_client().await;

        mock_get()
            .respond_with(ResponseTemplate::new(StatusCode::OK).set_delay(ms(500)))
            .expect(1)
            .mount(&server)
            .await;

        let result = client
            .cat_stream(
                &IpfsContext::test(),
                &make_path(),
                Some(ms(300)),
                RetryPolicy::None,
            )
            .await;

        assert!(result.is_err());
    }

    #[crate::test]
    async fn cat_stream_retries_the_request_on_non_deterministic_errors() {
        let (server, client) = make_client().await;

        mock_get()
            .respond_with(ResponseTemplate::new(StatusCode::INTERNAL_SERVER_ERROR))
            .up_to_n_times(1)
            .expect(1)
            .mount(&server)
            .await;

        mock_get()
            .respond_with(ResponseTemplate::new(StatusCode::OK))
            .expect(1)
            .mount(&server)
            .await;

        let _stream = client
            .cat_stream(
                &IpfsContext::test(),
                &make_path(),
                None,
                RetryPolicy::NonDeterministic,
            )
            .await
            .unwrap();
    }

    #[crate::test]
    async fn cat_returns_the_content() {
        let (server, client) = make_client().await;

        mock_get()
            .respond_with(ResponseTemplate::new(StatusCode::OK).set_body_bytes(b"some data"))
            .expect(1)
            .mount(&server)
            .await;

        let bytes = client
            .cat(
                &IpfsContext::test(),
                &make_path(),
                usize::MAX,
                None,
                RetryPolicy::None,
            )
            .await
            .unwrap();

        assert_eq!(bytes.as_ref(), b"some data");
    }

    #[crate::test]
    async fn cat_returns_the_content_if_max_size_is_equal_to_the_content_size() {
        let (server, client) = make_client().await;

        let data = b"some data";

        mock_get()
            .respond_with(ResponseTemplate::new(StatusCode::OK).set_body_bytes(data))
            .expect(1)
            .mount(&server)
            .await;

        let bytes = client
            .cat(
                &IpfsContext::test(),
                &make_path(),
                data.len(),
                None,
                RetryPolicy::None,
            )
            .await
            .unwrap();

        assert_eq!(bytes.as_ref(), data);
    }

    #[crate::test]
    async fn cat_fails_if_content_is_too_large() {
        let (server, client) = make_client().await;

        let data = b"some data";

        mock_get()
            .respond_with(ResponseTemplate::new(StatusCode::OK).set_body_bytes(data))
            .expect(1)
            .mount(&server)
            .await;

        client
            .cat(
                &IpfsContext::test(),
                &make_path(),
                data.len() - 1,
                None,
                RetryPolicy::None,
            )
            .await
            .unwrap_err();
    }

    #[crate::test]
    async fn cat_fails_on_timeout() {
        let (server, client) = make_client().await;

        mock_get()
            .respond_with(ResponseTemplate::new(StatusCode::OK).set_delay(ms(500)))
            .expect(1)
            .mount(&server)
            .await;

        client
            .cat(
                &IpfsContext::test(),
                &make_path(),
                usize::MAX,
                Some(ms(300)),
                RetryPolicy::None,
            )
            .await
            .unwrap_err();
    }

    #[crate::test]
    async fn cat_retries_the_request_on_non_deterministic_errors() {
        let (server, client) = make_client().await;

        mock_get()
            .respond_with(ResponseTemplate::new(StatusCode::INTERNAL_SERVER_ERROR))
            .up_to_n_times(1)
            .expect(1)
            .mount(&server)
            .await;

        mock_get()
            .respond_with(ResponseTemplate::new(StatusCode::OK).set_body_bytes(b"some data"))
            .expect(1)
            .mount(&server)
            .await;

        let bytes = client
            .cat(
                &IpfsContext::test(),
                &make_path(),
                usize::MAX,
                None,
                RetryPolicy::NonDeterministic,
            )
            .await
            .unwrap();

        assert_eq!(bytes.as_ref(), b"some data");
    }

    #[crate::test]
    async fn get_block_returns_the_block_content() {
        let (server, client) = make_client().await;

        mock_get_block()
            .respond_with(ResponseTemplate::new(StatusCode::OK).set_body_bytes(b"some data"))
            .expect(1)
            .mount(&server)
            .await;

        let bytes = client
            .get_block(&IpfsContext::test(), &make_path(), None, RetryPolicy::None)
            .await
            .unwrap();

        assert_eq!(bytes.as_ref(), b"some data");
    }

    #[crate::test]
    async fn get_block_fails_on_timeout() {
        let (server, client) = make_client().await;

        mock_get_block()
            .respond_with(ResponseTemplate::new(StatusCode::OK).set_delay(ms(500)))
            .expect(1)
            .mount(&server)
            .await;

        client
            .get_block(
                &IpfsContext::test(),
                &make_path(),
                Some(ms(300)),
                RetryPolicy::None,
            )
            .await
            .unwrap_err();
    }

    #[crate::test]
    async fn get_block_retries_the_request_on_non_deterministic_errors() {
        let (server, client) = make_client().await;

        mock_get_block()
            .respond_with(ResponseTemplate::new(StatusCode::INTERNAL_SERVER_ERROR))
            .up_to_n_times(1)
            .expect(1)
            .mount(&server)
            .await;

        mock_get_block()
            .respond_with(ResponseTemplate::new(StatusCode::OK).set_body_bytes(b"some data"))
            .expect(1)
            .mount(&server)
            .await;

        let bytes = client
            .get_block(
                &IpfsContext::test(),
                &make_path(),
                None,
                RetryPolicy::NonDeterministic,
            )
            .await
            .unwrap();

        assert_eq!(bytes.as_ref(), b"some data");
    }

    #[crate::test]
    async fn operation_names_include_cid_for_debugging() {
        use slog::{Drain, Logger, Record, o};
        use std::sync::{Arc, Mutex};

        // Custom drain to capture log messages
        struct LogCapture {
            messages: Arc<Mutex<Vec<String>>>,
        }

        impl Drain for LogCapture {
            type Ok = ();
            type Err = std::io::Error;

            fn log(
                &self,
                record: &Record,
                values: &slog::OwnedKVList,
            ) -> std::result::Result<Self::Ok, Self::Err> {
                use slog::KV;

                let mut serialized_values = String::new();
                let mut serializer = StringSerializer(&mut serialized_values);
                values.serialize(record, &mut serializer).unwrap();

                let message = format!("{}; {serialized_values}", record.msg());
                self.messages.lock().unwrap().push(message);

                Ok(())
            }
        }

        struct StringSerializer<'a>(&'a mut String);

        impl<'a> slog::Serializer for StringSerializer<'a> {
            fn emit_arguments(
                &mut self,
                key: slog::Key,
                val: &std::fmt::Arguments,
            ) -> slog::Result {
                use std::fmt::Write;
                write!(self.0, "{}: {}, ", key, val).unwrap();
                Ok(())
            }
        }

        let captured_messages = Arc::new(Mutex::new(Vec::new()));
        let drain = LogCapture {
            messages: captured_messages.clone(),
        };
        let logger = Logger::root(drain.fuse(), o!());

        let server = mock_server().await;
        let client = Arc::new(
            IpfsGatewayClient::new_unchecked(server.uri(), IpfsMetrics::test(), &logger).unwrap(),
        );

        // Set up mock to fail twice then succeed to trigger retry with warning logs
        mock_get()
            .respond_with(ResponseTemplate::new(StatusCode::INTERNAL_SERVER_ERROR))
            .up_to_n_times(2)
            .expect(2)
            .mount(&server)
            .await;

        mock_get()
            .respond_with(ResponseTemplate::new(StatusCode::OK).set_body_bytes(b"data"))
            .expect(1)
            .mount(&server)
            .await;

        let path = make_path();

        // This should trigger retry logs because we set up failures first
        let _result = client
            .cat(
                &IpfsContext::new(&DeploymentHash::default(), &logger),
                &path,
                usize::MAX,
                None,
                RetryPolicy::NonDeterministic,
            )
            .await
            .unwrap();

        // Check that the captured log messages include the CID
        let messages = captured_messages.lock().unwrap();
        let retry_messages: Vec<_> = messages
            .iter()
            .filter(|msg| msg.contains("Trying again after"))
            .collect();

        assert!(
            !retry_messages.is_empty(),
            "Expected retry messages but found none. All messages: {:?}",
            *messages
        );

        // Verify that the operation name includes the CID
        let expected_cid = "QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn";
        let has_cid_in_operation = retry_messages
            .iter()
            .any(|msg| msg.contains(&format!("path: {expected_cid}")));

        assert!(
            has_cid_in_operation,
            "Expected operation name to include CID [{}] in retry messages: {:?}",
            expected_cid, retry_messages
        );
    }
}
