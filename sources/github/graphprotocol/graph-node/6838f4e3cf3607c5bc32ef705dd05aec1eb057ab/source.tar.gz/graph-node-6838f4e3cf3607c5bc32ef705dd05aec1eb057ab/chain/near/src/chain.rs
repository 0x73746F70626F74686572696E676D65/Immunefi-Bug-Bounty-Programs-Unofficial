use async_trait::async_trait;
use graph::blockchain::client::ChainClient;
use graph::blockchain::firehose_block_ingestor::FirehoseBlockIngestor;
use graph::blockchain::{
    BlockIngestor, BlockchainKind, NoopDecoderHook, NoopRuntimeAdapter, TriggerFilterWrapper,
};
use graph::cheap_clone::CheapClone;
use graph::components::network_provider::ChainName;
use graph::components::store::{ChainHeadStore, DeploymentCursorTracker, SourceableStore};
use graph::data::subgraph::UnifiedMappingApiVersion;
use graph::firehose::{FirehoseEndpoint, FirehoseEndpoints};
use graph::futures03::TryFutureExt;
use graph::prelude::MetricsRegistry;
use graph::{
    anyhow::Result,
    blockchain::{
        BlockHash, BlockPtr, Blockchain, EmptyNodeCapabilities, IngestorError,
        RuntimeAdapter as RuntimeAdapterTrait,
        block_stream::{
            BlockStreamEvent, BlockWithTriggers, FirehoseError,
            FirehoseMapper as FirehoseMapperTrait, TriggersAdapter as TriggersAdapterTrait,
        },
        firehose_block_stream::FirehoseBlockStream,
    },
    components::store::DeploymentLocator,
    firehose::{self as firehose, ForkStep},
    prelude::{BlockNumber, Error, Logger, LoggerFactory, o},
};
use prost::Message;
use std::collections::BTreeSet;
use std::sync::Arc;

use crate::adapter::TriggerFilter;
use crate::codec::Block;
use crate::data_source::{DataSourceTemplate, UnresolvedDataSourceTemplate};
use crate::trigger::{self, NearTrigger};
use crate::{
    codec,
    data_source::{DataSource, UnresolvedDataSource},
};
use graph::blockchain::block_stream::{
    BlockStream, BlockStreamBuilder, BlockStreamError, BlockStreamMapper, FirehoseCursor,
};

pub struct NearStreamBuilder {}

#[async_trait]
impl BlockStreamBuilder<Chain> for NearStreamBuilder {
    async fn build_firehose(
        &self,
        chain: &Chain,
        deployment: DeploymentLocator,
        block_cursor: FirehoseCursor,
        start_blocks: Vec<BlockNumber>,
        subgraph_current_block: Option<BlockPtr>,
        filter: Arc<<Chain as Blockchain>::TriggerFilter>,
        unified_api_version: UnifiedMappingApiVersion,
    ) -> Result<Box<dyn BlockStream<Chain>>> {
        let adapter = chain
            .triggers_adapter(
                &deployment,
                &EmptyNodeCapabilities::default(),
                unified_api_version,
            )
            .unwrap_or_else(|_| panic!("no adapter for network {}", chain.name));

        let logger = chain
            .logger_factory
            .subgraph_logger(&deployment)
            .new(o!("component" => "FirehoseBlockStream"));

        let firehose_mapper = Arc::new(FirehoseMapper { adapter, filter });

        Ok(Box::new(FirehoseBlockStream::new(
            deployment.hash,
            chain.chain_client(),
            subgraph_current_block,
            block_cursor,
            firehose_mapper,
            start_blocks,
            logger,
            chain.metrics_registry.clone(),
        )))
    }

    async fn build_polling(
        &self,
        _chain: &Chain,
        _deployment: DeploymentLocator,
        _start_blocks: Vec<BlockNumber>,
        _source_subgraph_stores: Vec<Arc<dyn SourceableStore>>,
        _subgraph_current_block: Option<BlockPtr>,
        _filter: Arc<TriggerFilterWrapper<Chain>>,
        _unified_api_version: UnifiedMappingApiVersion,
    ) -> Result<Box<dyn BlockStream<Chain>>> {
        todo!()
    }
}

pub struct Chain {
    logger_factory: LoggerFactory,
    name: ChainName,
    client: Arc<ChainClient<Self>>,
    chain_head_store: Arc<dyn ChainHeadStore>,
    metrics_registry: Arc<MetricsRegistry>,
    block_stream_builder: Arc<dyn BlockStreamBuilder<Self>>,
}

impl std::fmt::Debug for Chain {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "chain: near")
    }
}

impl Chain {
    pub fn new(
        logger_factory: LoggerFactory,
        name: ChainName,
        chain_head_store: Arc<dyn ChainHeadStore>,
        firehose_endpoints: FirehoseEndpoints,
        metrics_registry: Arc<MetricsRegistry>,
    ) -> Self {
        Chain {
            logger_factory,
            name,
            chain_head_store,
            client: Arc::new(ChainClient::new_firehose(firehose_endpoints)),
            metrics_registry,
            block_stream_builder: Arc::new(NearStreamBuilder {}),
        }
    }
}

#[async_trait]
impl Blockchain for Chain {
    const KIND: BlockchainKind = BlockchainKind::Near;

    type Client = ();
    type Block = codec::Block;

    type DataSource = DataSource;

    type UnresolvedDataSource = UnresolvedDataSource;

    type DataSourceTemplate = DataSourceTemplate;

    type UnresolvedDataSourceTemplate = UnresolvedDataSourceTemplate;

    type TriggerData = crate::trigger::NearTrigger;

    type MappingTrigger = crate::trigger::NearTrigger;

    type TriggerFilter = crate::adapter::TriggerFilter;

    type NodeCapabilities = EmptyNodeCapabilities<Chain>;

    type DecoderHook = NoopDecoderHook;

    fn triggers_adapter(
        &self,
        _loc: &DeploymentLocator,
        _capabilities: &Self::NodeCapabilities,
        _unified_api_version: UnifiedMappingApiVersion,
    ) -> Result<Arc<dyn TriggersAdapterTrait<Self>>, Error> {
        let adapter = TriggersAdapter {};
        Ok(Arc::new(adapter))
    }

    async fn new_block_stream(
        &self,
        deployment: DeploymentLocator,
        store: impl DeploymentCursorTracker,
        start_blocks: Vec<BlockNumber>,
        _source_subgraph_stores: Vec<Arc<dyn SourceableStore>>,
        filter: Arc<TriggerFilterWrapper<Self>>,
        unified_api_version: UnifiedMappingApiVersion,
    ) -> Result<Box<dyn BlockStream<Self>>, Error> {
        self.block_stream_builder
            .build_firehose(
                self,
                deployment,
                store.firehose_cursor(),
                start_blocks,
                store.block_ptr(),
                filter.chain_filter.clone(),
                unified_api_version,
            )
            .await
    }

    fn is_refetch_block_required(&self) -> bool {
        false
    }

    async fn refetch_firehose_block(
        &self,
        _logger: &Logger,
        _cursor: FirehoseCursor,
    ) -> Result<codec::Block, Error> {
        unimplemented!(
            "This chain does not support Dynamic Data Sources. is_refetch_block_required always returns false, this shouldn't be called."
        )
    }

    async fn chain_head_ptr(&self) -> Result<Option<BlockPtr>, Error> {
        self.chain_head_store.cheap_clone().chain_head_ptr().await
    }

    async fn block_pointer_from_number(
        &self,
        logger: &Logger,
        number: BlockNumber,
    ) -> Result<BlockPtr, IngestorError> {
        let firehose_endpoint = self.client.firehose_endpoint().await?;

        firehose_endpoint
            .block_ptr_for_number::<codec::HeaderOnlyBlock>(logger, number)
            .map_err(Into::into)
            .await
    }

    async fn runtime(
        &self,
    ) -> anyhow::Result<(Arc<dyn RuntimeAdapterTrait<Self>>, Self::DecoderHook)> {
        Ok((Arc::new(NoopRuntimeAdapter::default()), NoopDecoderHook))
    }

    fn chain_client(&self) -> Arc<ChainClient<Self>> {
        self.client.clone()
    }

    async fn block_ingestor(&self) -> anyhow::Result<Box<dyn BlockIngestor>> {
        let ingestor = FirehoseBlockIngestor::<crate::HeaderOnlyBlock, Self>::new(
            self.chain_head_store.cheap_clone(),
            self.chain_client(),
            self.logger_factory
                .component_logger("NearFirehoseBlockIngestor", None),
            self.name.clone(),
        );
        Ok(Box::new(ingestor))
    }
}

pub struct TriggersAdapter {}

#[async_trait]
impl TriggersAdapterTrait<Chain> for TriggersAdapter {
    async fn scan_triggers(
        &self,
        _from: BlockNumber,
        _to: BlockNumber,
        _filter: &TriggerFilter,
    ) -> Result<(Vec<BlockWithTriggers<Chain>>, BlockNumber), Error> {
        panic!("Should never be called since not used by FirehoseBlockStream")
    }

    async fn load_block_ptrs_by_numbers(
        &self,
        _logger: Logger,
        _block_numbers: BTreeSet<BlockNumber>,
    ) -> Result<Vec<Block>> {
        unimplemented!()
    }

    async fn chain_head_ptr(&self) -> Result<Option<BlockPtr>, Error> {
        unimplemented!()
    }

    async fn triggers_in_block(
        &self,
        logger: &Logger,
        block: codec::Block,
        filter: &TriggerFilter,
    ) -> Result<BlockWithTriggers<Chain>, Error> {
        // TODO: Find the best place to introduce an `Arc` and avoid this clone.
        let shared_block = Arc::new(block.clone());

        let TriggerFilter {
            block_filter,
            receipt_filter,
        } = filter;

        // Filter non-successful or non-action receipts.
        let receipts = block.shards.iter().flat_map(|shard| {
            shard
                .receipt_execution_outcomes
                .iter()
                .filter_map(|outcome| {
                    if !outcome
                        .execution_outcome
                        .as_ref()?
                        .outcome
                        .as_ref()?
                        .status
                        .as_ref()?
                        .is_success()
                    {
                        return None;
                    }
                    if !matches!(
                        outcome.receipt.as_ref()?.receipt,
                        Some(codec::receipt::Receipt::Action(_))
                    ) {
                        return None;
                    }

                    let receipt = outcome.receipt.as_ref()?.clone();
                    if !receipt_filter.matches(&receipt.receiver_id) {
                        return None;
                    }

                    Some(trigger::ReceiptWithOutcome {
                        outcome: outcome.execution_outcome.as_ref()?.clone(),
                        receipt,
                        block: shared_block.cheap_clone(),
                    })
                })
        });

        let mut trigger_data: Vec<_> = receipts
            .map(|r| NearTrigger::Receipt(Arc::new(r)))
            .collect();

        if block_filter.trigger_every_block {
            trigger_data.push(NearTrigger::Block(shared_block.cheap_clone()));
        }

        Ok(BlockWithTriggers::new(block, trigger_data, logger))
    }

    async fn is_on_main_chain(&self, _ptr: BlockPtr) -> Result<bool, Error> {
        panic!("Should never be called since not used by FirehoseBlockStream")
    }

    async fn ancestor_block(
        &self,
        _ptr: BlockPtr,
        _offset: BlockNumber,
        _root: Option<BlockHash>,
    ) -> Result<Option<codec::Block>, Error> {
        panic!("Should never be called since FirehoseBlockStream cannot resolve it")
    }

    /// Panics if `block` is genesis.
    /// But that's ok since this is only called when reverting `block`.
    async fn parent_ptr(&self, block: &BlockPtr) -> Result<Option<BlockPtr>, Error> {
        // FIXME (NEAR):  Might not be necessary for NEAR support for now
        Ok(Some(BlockPtr {
            hash: BlockHash::from(vec![0xff; 32]),
            number: block.number.saturating_sub(1),
        }))
    }
}

pub struct FirehoseMapper {
    adapter: Arc<dyn TriggersAdapterTrait<Chain>>,
    filter: Arc<TriggerFilter>,
}

#[async_trait]
impl BlockStreamMapper<Chain> for FirehoseMapper {
    fn decode_block(
        &self,
        output: Option<&[u8]>,
    ) -> Result<Option<codec::Block>, BlockStreamError> {
        let block = match output {
            Some(block) => codec::Block::decode(block)?,
            None => {
                return Err(anyhow::anyhow!(
                    "near mapper is expected to always have a block"
                ))
                .map_err(BlockStreamError::from);
            }
        };

        Ok(Some(block))
    }

    async fn block_with_triggers(
        &self,
        logger: &Logger,
        block: codec::Block,
    ) -> Result<BlockWithTriggers<Chain>, BlockStreamError> {
        self.adapter
            .triggers_in_block(logger, block, self.filter.as_ref())
            .await
            .map_err(BlockStreamError::from)
    }
}

#[async_trait]
impl FirehoseMapperTrait<Chain> for FirehoseMapper {
    fn trigger_filter(&self) -> &TriggerFilter {
        self.filter.as_ref()
    }

    async fn to_block_stream_event(
        &self,
        logger: &Logger,
        response: &firehose::Response,
    ) -> Result<BlockStreamEvent<Chain>, FirehoseError> {
        let step = ForkStep::try_from(response.step).unwrap_or_else(|_| {
            panic!(
                "unknown step i32 value {}, maybe you forgot update & re-regenerate the protobuf definitions?",
                response.step
            )
        });

        let any_block = response
            .block
            .as_ref()
            .expect("block payload information should always be present");

        // Right now, this is done in all cases but in reality, with how the BlockStreamEvent::Revert
        // is defined right now, only block hash and block number is necessary. However, this information
        // is not part of the actual bstream::BlockResponseV2 payload. As such, we need to decode the full
        // block which is useless.
        //
        // Check about adding basic information about the block in the bstream::BlockResponseV2 or maybe
        // define a slimmed down stuct that would decode only a few fields and ignore all the rest.
        // unwrap: Input cannot be None so output will be error or block.
        let block = self.decode_block(Some(any_block.value.as_ref()))?.unwrap();

        use ForkStep::*;
        match step {
            StepNew => Ok(BlockStreamEvent::ProcessBlock(
                self.block_with_triggers(logger, block).await?,
                FirehoseCursor::from(response.cursor.clone()),
            )),

            StepUndo => {
                let parent_ptr = block
                    .header()
                    .parent_ptr()
                    .expect("Genesis block should never be reverted");

                Ok(BlockStreamEvent::Revert(
                    parent_ptr,
                    FirehoseCursor::from(response.cursor.clone()),
                ))
            }

            StepFinal => {
                panic!(
                    "irreversible step is not handled and should not be requested in the Firehose request"
                )
            }

            StepUnset => {
                panic!("unknown step should not happen in the Firehose response")
            }
        }
    }

    async fn block_ptr_for_number(
        &self,
        logger: &Logger,
        endpoint: &Arc<FirehoseEndpoint>,
        number: BlockNumber,
    ) -> Result<BlockPtr, Error> {
        endpoint
            .block_ptr_for_number::<codec::HeaderOnlyBlock>(logger, number)
            .await
    }

    async fn final_block_ptr_for(
        &self,
        logger: &Logger,
        endpoint: &Arc<FirehoseEndpoint>,
        block: &codec::Block,
    ) -> Result<BlockPtr, Error> {
        let final_block_number = block.header().last_final_block_height as BlockNumber;

        self.block_ptr_for_number(logger, endpoint, final_block_number)
            .await
    }
}

#[cfg(test)]
mod test {
    use std::{collections::HashSet, sync::Arc, vec};

    use graph::{
        blockchain::{DataSource as _, TriggersAdapter as _, block_stream::BlockWithTriggers},
        data::subgraph::LATEST_VERSION,
        prelude::Link,
        semver::Version,
        slog::{self, Logger, o},
    };

    use crate::{
        Chain,
        adapter::{NearReceiptFilter, TriggerFilter},
        codec::{
            self, Block, BlockHeader, DataReceiver, ExecutionOutcome, ExecutionOutcomeWithId,
            IndexerExecutionOutcomeWithReceipt, IndexerShard, ReceiptAction,
            SuccessValueExecutionStatus, execution_outcome, receipt,
        },
        data_source::{DataSource, Mapping, NEAR_KIND, PartialAccounts, ReceiptHandler},
        trigger::{NearTrigger, ReceiptWithOutcome},
    };

    use super::TriggersAdapter;

    #[test]
    fn validate_empty() {
        let ds = new_data_source(None, None);
        let errs = ds.validate(LATEST_VERSION);
        assert_eq!(errs.len(), 1, "{:?}", ds);
        assert_eq!(errs[0].to_string(), "subgraph source address is required");
    }

    #[test]
    fn validate_empty_account_none_partial() {
        let ds = new_data_source(None, Some(PartialAccounts::default()));
        let errs = ds.validate(LATEST_VERSION);
        assert_eq!(errs.len(), 1, "{:?}", ds);
        assert_eq!(errs[0].to_string(), "subgraph source address is required");
    }

    #[test]
    fn validate_empty_account() {
        let ds = new_data_source(
            None,
            Some(PartialAccounts {
                prefixes: vec![],
                suffixes: vec!["x.near".to_string()],
            }),
        );
        let errs = ds.validate(LATEST_VERSION);
        assert_eq!(errs.len(), 0, "{:?}", ds);
    }

    #[test]
    fn validate_empty_prefix_and_suffix_values() {
        let ds = new_data_source(
            None,
            Some(PartialAccounts {
                prefixes: vec!["".to_string()],
                suffixes: vec!["".to_string()],
            }),
        );
        let errs: Vec<String> = ds
            .validate(LATEST_VERSION)
            .into_iter()
            .map(|err| err.to_string())
            .collect();
        assert_eq!(errs.len(), 2, "{:?}", ds);

        let expected_errors = [
            "partial account prefixes can't have empty values".to_string(),
            "partial account suffixes can't have empty values".to_string(),
        ];
        assert!(
            expected_errors.iter().all(|err| errs.contains(err)),
            "{:?}",
            errs
        );
    }

    #[test]
    fn validate_empty_partials() {
        let ds = new_data_source(Some("x.near".to_string()), None);
        let errs = ds.validate(LATEST_VERSION);
        assert_eq!(errs.len(), 0, "{:?}", ds);
    }

    #[test]
    fn receipt_filter_from_ds() {
        struct Case {
            name: String,
            account: Option<String>,
            partial_accounts: Option<PartialAccounts>,
            expected: HashSet<(Option<String>, Option<String>)>,
        }

        let cases = vec![
            Case {
                name: "2 prefix && 1 suffix".into(),
                account: None,
                partial_accounts: Some(PartialAccounts {
                    prefixes: vec!["a".to_string(), "b".to_string()],
                    suffixes: vec!["d".to_string()],
                }),
                expected: HashSet::from_iter(vec![
                    (Some("a".to_string()), Some("d".to_string())),
                    (Some("b".to_string()), Some("d".to_string())),
                ]),
            },
            Case {
                name: "1 prefix && 2 suffix".into(),
                account: None,
                partial_accounts: Some(PartialAccounts {
                    prefixes: vec!["a".to_string()],
                    suffixes: vec!["c".to_string(), "d".to_string()],
                }),
                expected: HashSet::from_iter(vec![
                    (Some("a".to_string()), Some("c".to_string())),
                    (Some("a".to_string()), Some("d".to_string())),
                ]),
            },
            Case {
                name: "no prefix".into(),
                account: None,
                partial_accounts: Some(PartialAccounts {
                    prefixes: vec![],
                    suffixes: vec!["c".to_string(), "d".to_string()],
                }),
                expected: HashSet::from_iter(vec![
                    (None, Some("c".to_string())),
                    (None, Some("d".to_string())),
                ]),
            },
            Case {
                name: "no suffix".into(),
                account: None,
                partial_accounts: Some(PartialAccounts {
                    prefixes: vec!["a".to_string(), "b".to_string()],
                    suffixes: vec![],
                }),
                expected: HashSet::from_iter(vec![
                    (Some("a".to_string()), None),
                    (Some("b".to_string()), None),
                ]),
            },
        ];

        for case in cases.into_iter() {
            let ds1 = new_data_source(case.account, None);
            let ds2 = new_data_source(None, case.partial_accounts);

            let receipt = NearReceiptFilter::from_data_sources(vec![&ds1, &ds2]);
            assert_eq!(
                receipt.partial_accounts.len(),
                case.expected.len(),
                "name: {}\npartial_accounts: {:?}",
                case.name,
                receipt.partial_accounts,
            );
            assert!(
                case.expected
                    .iter()
                    .all(|x| receipt.partial_accounts.contains(x)),
                "name: {}\npartial_accounts: {:?}",
                case.name,
                receipt.partial_accounts,
            );
        }
    }

    #[test]
    fn data_source_match_and_decode() {
        struct Request {
            account: String,
            matches: bool,
        }
        struct Case {
            name: String,
            account: Option<String>,
            partial_accounts: Option<PartialAccounts>,
            expected: Vec<Request>,
        }

        let cases = vec![
            Case {
                name: "2 prefix && 1 suffix".into(),
                account: None,
                partial_accounts: Some(PartialAccounts {
                    prefixes: vec!["a".to_string(), "b".to_string()],
                    suffixes: vec!["d".to_string()],
                }),
                expected: vec![
                    Request {
                        account: "ssssssd".to_string(),
                        matches: false,
                    },
                    Request {
                        account: "asasdasdas".to_string(),
                        matches: false,
                    },
                    Request {
                        account: "asd".to_string(),
                        matches: true,
                    },
                    Request {
                        account: "bsd".to_string(),
                        matches: true,
                    },
                ],
            },
            Case {
                name: "1 prefix && 2 suffix".into(),
                account: None,
                partial_accounts: Some(PartialAccounts {
                    prefixes: vec!["a".to_string()],
                    suffixes: vec!["c".to_string(), "d".to_string()],
                }),
                expected: vec![
                    Request {
                        account: "ssssssd".to_string(),
                        matches: false,
                    },
                    Request {
                        account: "asasdasdas".to_string(),
                        matches: false,
                    },
                    Request {
                        account: "asdc".to_string(),
                        matches: true,
                    },
                    Request {
                        account: "absd".to_string(),
                        matches: true,
                    },
                ],
            },
            Case {
                name: "no prefix with exact match".into(),
                account: Some("bsda".to_string()),
                partial_accounts: Some(PartialAccounts {
                    prefixes: vec![],
                    suffixes: vec!["c".to_string(), "d".to_string()],
                }),
                expected: vec![
                    Request {
                        account: "ssssss".to_string(),
                        matches: false,
                    },
                    Request {
                        account: "asasdasdas".to_string(),
                        matches: false,
                    },
                    Request {
                        account: "asdasdasdasdc".to_string(),
                        matches: true,
                    },
                    Request {
                        account: "bsd".to_string(),
                        matches: true,
                    },
                    Request {
                        account: "bsda".to_string(),
                        matches: true,
                    },
                ],
            },
            Case {
                name: "no suffix with exact match".into(),
                account: Some("zbsd".to_string()),
                partial_accounts: Some(PartialAccounts {
                    prefixes: vec!["a".to_string(), "b".to_string()],
                    suffixes: vec![],
                }),
                expected: vec![
                    Request {
                        account: "ssssssd".to_string(),
                        matches: false,
                    },
                    Request {
                        account: "zasdasdas".to_string(),
                        matches: false,
                    },
                    Request {
                        account: "asa".to_string(),
                        matches: true,
                    },
                    Request {
                        account: "bsb".to_string(),
                        matches: true,
                    },
                    Request {
                        account: "zbsd".to_string(),
                        matches: true,
                    },
                ],
            },
        ];

        let logger = Logger::root(slog::Discard, o!());
        for case in cases.into_iter() {
            let ds = new_data_source(case.account, case.partial_accounts);
            let filter = NearReceiptFilter::from_data_sources(vec![&ds]);

            for req in case.expected {
                let res = filter.matches(&req.account);
                assert_eq!(
                    res, req.matches,
                    "name: {} request:{} failed",
                    case.name, req.account
                );

                let block = Arc::new(new_success_block(11, &req.account));
                let receipt = Arc::new(new_receipt_with_outcome(&req.account, block.clone()));
                let res = ds
                    .match_and_decode(&NearTrigger::Receipt(receipt.clone()), &block, &logger)
                    .expect("unable to process block");
                assert_eq!(
                    req.matches,
                    res.is_some(),
                    "case name: {} req: {}",
                    case.name,
                    req.account
                );
            }
        }
    }

    #[graph::test]
    async fn test_trigger_filter_empty() {
        let account1: String = "account1".into();

        let adapter = TriggersAdapter {};

        let logger = Logger::root(slog::Discard, o!());
        let block1 = new_success_block(1, &account1);

        let filter = TriggerFilter::default();

        let block_with_triggers: BlockWithTriggers<Chain> = adapter
            .triggers_in_block(&logger, block1, &filter)
            .await
            .expect("failed to execute triggers_in_block");
        assert_eq!(block_with_triggers.trigger_count(), 0);
    }

    #[graph::test]
    async fn test_trigger_filter_every_block() {
        let account1: String = "account1".into();

        let adapter = TriggersAdapter {};

        let logger = Logger::root(slog::Discard, o!());
        let block1 = new_success_block(1, &account1);

        let filter = TriggerFilter {
            block_filter: crate::adapter::NearBlockFilter {
                trigger_every_block: true,
            },
            ..Default::default()
        };

        let block_with_triggers: BlockWithTriggers<Chain> = adapter
            .triggers_in_block(&logger, block1, &filter)
            .await
            .expect("failed to execute triggers_in_block");
        assert_eq!(block_with_triggers.trigger_count(), 1);

        let height: Vec<u64> = heights_from_triggers(&block_with_triggers);
        assert_eq!(height, vec![1]);
    }

    #[graph::test]
    async fn test_trigger_filter_every_receipt() {
        let account1: String = "account1".into();

        let adapter = TriggersAdapter {};

        let logger = Logger::root(slog::Discard, o!());
        let block1 = new_success_block(1, &account1);

        let filter = TriggerFilter {
            receipt_filter: NearReceiptFilter {
                accounts: HashSet::from_iter(vec![account1]),
                partial_accounts: HashSet::new(),
            },
            ..Default::default()
        };

        let block_with_triggers: BlockWithTriggers<Chain> = adapter
            .triggers_in_block(&logger, block1, &filter)
            .await
            .expect("failed to execute triggers_in_block");
        assert_eq!(block_with_triggers.trigger_count(), 1);

        let height: Vec<u64> = heights_from_triggers(&block_with_triggers);
        assert_eq!(height.len(), 0);
    }

    fn heights_from_triggers(block: &BlockWithTriggers<Chain>) -> Vec<u64> {
        block
            .trigger_data
            .clone()
            .into_iter()
            .filter_map(|x| match x.as_chain() {
                Some(crate::trigger::NearTrigger::Block(b)) => b.header.clone().map(|x| x.height),
                _ => None,
            })
            .collect()
    }

    fn new_success_block(height: u64, receiver_id: &str) -> codec::Block {
        codec::Block {
            header: Some(BlockHeader {
                height,
                hash: Some(codec::CryptoHash { bytes: vec![0; 32] }),
                ..Default::default()
            }),
            shards: vec![IndexerShard {
                receipt_execution_outcomes: vec![IndexerExecutionOutcomeWithReceipt {
                    receipt: Some(crate::codec::Receipt {
                        receipt: Some(receipt::Receipt::Action(ReceiptAction {
                            output_data_receivers: vec![DataReceiver {
                                receiver_id: receiver_id.to_string(),
                                ..Default::default()
                            }],
                            ..Default::default()
                        })),
                        receiver_id: receiver_id.to_string(),
                        ..Default::default()
                    }),
                    execution_outcome: Some(ExecutionOutcomeWithId {
                        outcome: Some(ExecutionOutcome {
                            status: Some(execution_outcome::Status::SuccessValue(
                                SuccessValueExecutionStatus::default(),
                            )),

                            ..Default::default()
                        }),
                        ..Default::default()
                    }),
                }],
                ..Default::default()
            }],
            ..Default::default()
        }
    }

    fn new_data_source(
        account: Option<String>,
        partial_accounts: Option<PartialAccounts>,
    ) -> DataSource {
        DataSource {
            kind: NEAR_KIND.to_string(),
            network: None,
            name: "asd".to_string(),
            source: crate::data_source::Source {
                account,
                start_block: 10,
                end_block: None,
                accounts: partial_accounts,
            },
            mapping: Mapping {
                api_version: Version::parse("1.0.0").expect("unable to parse version"),
                language: "".to_string(),
                entities: vec![],
                block_handlers: vec![],
                receipt_handlers: vec![ReceiptHandler {
                    handler: "asdsa".to_string(),
                }],
                runtime: Arc::new(vec![]),
                link: Link::default(),
            },
            context: Arc::new(None),
            creation_block: None,
        }
    }

    fn new_receipt_with_outcome(receiver_id: &str, block: Arc<Block>) -> ReceiptWithOutcome {
        ReceiptWithOutcome {
            outcome: ExecutionOutcomeWithId {
                outcome: Some(ExecutionOutcome {
                    status: Some(execution_outcome::Status::SuccessValue(
                        SuccessValueExecutionStatus::default(),
                    )),

                    ..Default::default()
                }),
                ..Default::default()
            },
            receipt: codec::Receipt {
                receipt: Some(receipt::Receipt::Action(ReceiptAction {
                    output_data_receivers: vec![DataReceiver {
                        receiver_id: receiver_id.to_string(),
                        ..Default::default()
                    }],
                    ..Default::default()
                })),
                receiver_id: receiver_id.to_string(),
                ..Default::default()
            },
            block,
        }
    }
}
