//! ABI encoding of JSON test triggers into graph-node's Ethereum trigger types.
//!
//! For `Transfer(address indexed from, address indexed to, uint256 value)`:
//! - topic0 = keccak256("Transfer(address,address,uint256)")
//! - topic1 = left-padded `from` address (indexed)
//! - topic2 = left-padded `to` address (indexed)
//! - data = ABI-encoded `value` (non-indexed)

use super::schema::{LogEvent, TestFile};
use anyhow::{Context, Result, anyhow, ensure};
use graph::blockchain::block_stream::BlockWithTriggers;
use graph::components::ethereum::AnyTransactionReceiptBare;
use graph::prelude::alloy::consensus::{Eip658Value, Receipt, ReceiptWithBloom};
use graph::prelude::alloy::dyn_abi::{DynSolType, DynSolValue};
use graph::prelude::alloy::json_abi::Event;
use graph::prelude::alloy::network::AnyReceiptEnvelope;
use graph::prelude::alloy::primitives::{Address, B256, Bloom, Bytes, I256, U256, keccak256};
use graph::prelude::alloy::rpc::types::{Log, TransactionReceipt};
use graph::prelude::{BlockPtr, LightEthereumBlock};
use graph_chain_ethereum::Chain;
use graph_chain_ethereum::chain::BlockFinality;
use graph_chain_ethereum::trigger::{EthereumBlockTriggerType, EthereumTrigger, LogRef};
use std::collections::HashMap;
use std::sync::Arc;

/// Build `BlockWithTriggers` from test blocks, chained by parent hash.
/// Numbers auto-increment from `start_block` when omitted.
/// Only logs whose topic0 is in `receipt_required_selectors` get a non-null receipt.
pub fn build_blocks_with_triggers(
    test_file: &TestFile,
    start_block: u64,
    receipt_required_selectors: &std::collections::HashSet<B256>,
) -> Result<Vec<BlockWithTriggers<Chain>>> {
    let mut blocks = Vec::new();
    let mut current_number = start_block;
    let mut parent_hash = B256::ZERO;

    for test_block in &test_file.blocks {
        let number = test_block.number.unwrap_or(current_number);

        let hash = test_block
            .hash
            .as_ref()
            .map(|h| h.parse::<B256>())
            .transpose()
            .context("Invalid block hash")?
            .unwrap_or_else(|| keccak256(number.to_be_bytes()));

        // Default timestamp = block number — avoids chain-specific block times.
        let timestamp = test_block.timestamp.unwrap_or(number);

        let mut triggers = Vec::new();

        // Pass 1: parse each event into (tx_hash, Arc<Log>).
        let event_logs: Vec<(B256, Arc<Log>)> = test_block
            .events
            .iter()
            .enumerate()
            .map(|(i, e)| prepare_event_log(number, hash, i as u64, e))
            .collect::<Result<_>>()?;

        // Pass 2: build one mock receipt per tx-hash group.
        let receipts = build_receipts_by_tx(number, hash, &event_logs);

        // Pass 3: one log trigger per event. Receipt only for `receipt: true` handlers.
        for (tx_hash, full_log) in &event_logs {
            let needs_receipt = full_log
                .topics()
                .first()
                .is_some_and(|t| receipt_required_selectors.contains(t));
            let receipt = needs_receipt.then(|| receipts[tx_hash].clone());
            triggers.push(EthereumTrigger::Log(LogRef::FullLog(
                full_log.clone(),
                receipt,
            )));
        }

        // Inject Start/End block triggers so `once`, `polling`, and unfiltered handlers fire.
        ensure!(
            number <= i32::MAX as u64,
            "block number {} exceeds i32::MAX",
            number
        );
        let block_ptr = BlockPtr::new(hash.into(), number as i32);
        triggers.push(EthereumTrigger::Block(
            block_ptr.clone(),
            EthereumBlockTriggerType::Start,
        ));
        triggers.push(EthereumTrigger::Block(
            block_ptr,
            EthereumBlockTriggerType::End,
        ));

        let block = create_block_with_triggers(number, hash, parent_hash, timestamp, triggers)?;
        blocks.push(block);

        parent_hash = hash;
        current_number = number + 1;
    }

    Ok(blocks)
}

/// Parse a test event into `(tx_hash, Arc<Log>)`.
/// tx_hash from the event or generated as `keccak256(block_number || log_index)`.
fn prepare_event_log(
    block_number: u64,
    block_hash: B256,
    log_index: u64,
    trigger: &LogEvent,
) -> Result<(B256, Arc<Log>)> {
    let address: Address = trigger.address.parse()?;

    let (topics, data) = encode_event_log(&trigger.event, &trigger.params)?;

    // Deterministic tx hash: keccak256(block_number || log_index).
    let tx_hash = trigger
        .tx_hash
        .as_ref()
        .map(|h| h.parse::<B256>())
        .transpose()?
        .unwrap_or_else(|| {
            keccak256([block_number.to_be_bytes(), log_index.to_be_bytes()].concat())
        });

    let inner_log = graph::prelude::alloy::primitives::Log {
        address,
        data: graph::prelude::alloy::primitives::LogData::new_unchecked(topics, data),
    };

    let full_log = Arc::new(Log {
        inner: inner_log,
        block_hash: Some(block_hash),
        block_number: Some(block_number),
        block_timestamp: None,
        transaction_hash: Some(tx_hash),
        transaction_index: Some(0),
        log_index: Some(log_index),
        removed: false,
    });

    Ok((tx_hash, full_log))
}

/// Build one receipt per unique tx_hash. Logs sharing a tx_hash are grouped;
/// events without an explicit tx_hash each get their own receipt.
fn build_receipts_by_tx(
    block_number: u64,
    block_hash: B256,
    event_logs: &[(B256, Arc<Log>)],
) -> HashMap<B256, Arc<AnyTransactionReceiptBare>> {
    // Collect logs per tx_hash, preserving insertion order for tx_index.
    let mut tx_order: Vec<B256> = Vec::new();
    let mut logs_by_tx: HashMap<B256, Vec<Log>> = HashMap::new();

    for (tx_hash, log) in event_logs {
        let entry = logs_by_tx.entry(*tx_hash).or_insert_with(|| {
            tx_order.push(*tx_hash);
            Vec::new()
        });
        entry.push((**log).clone());
    }

    let mut receipts: HashMap<B256, Arc<AnyTransactionReceiptBare>> =
        HashMap::with_capacity(tx_order.len());

    for (tx_index, tx_hash) in tx_order.into_iter().enumerate() {
        let logs = logs_by_tx.remove(&tx_hash).unwrap_or_default();

        let core_receipt = Receipt {
            status: Eip658Value::Eip658(true),
            cumulative_gas_used: 21_000,
            logs,
        };

        let receipt_with_bloom = ReceiptWithBloom::new(core_receipt, Bloom::default());

        let any_envelope = AnyReceiptEnvelope {
            inner: receipt_with_bloom,
            r#type: 2,
        };

        let receipt = TransactionReceipt {
            transaction_hash: tx_hash,
            transaction_index: Some(tx_index as u64),
            block_hash: Some(block_hash),
            block_number: Some(block_number),
            gas_used: 21_000,
            from: Address::ZERO,
            to: None,
            effective_gas_price: 0,
            blob_gas_used: None,
            blob_gas_price: None,
            contract_address: None,
            inner: any_envelope,
        };

        receipts.insert(tx_hash, Arc::new(receipt));
    }

    receipts
}

/// ABI-encode event params into EVM log (topics, data).
///
/// topic0 = keccak256 of the canonical signature; indexed params → topics;
/// non-indexed params → ABI-encoded data.
pub fn encode_event_log(
    event_sig: &str,
    params: &serde_json::Map<String, serde_json::Value>,
) -> Result<(Vec<B256>, Bytes)> {
    // Event::parse requires "event " prefix — add if missing.
    let sig_with_prefix = if event_sig.trim_start().starts_with("event ") {
        event_sig.to_string()
    } else {
        format!("event {}", event_sig)
    };

    let event = Event::parse(&sig_with_prefix)
        .map_err(|e| anyhow!("Failed to parse event signature '{}': {:?}", event_sig, e))?;

    let topic0 = event.selector();
    let mut topics = vec![topic0];
    let mut data_values = Vec::new();

    for input in &event.inputs {
        let value = params
            .get(&input.name)
            .ok_or_else(|| anyhow!("Missing parameter: {}", input.name))?;

        let sol_type: DynSolType = input
            .ty
            .parse()
            .map_err(|e| anyhow!("Invalid type '{}': {:?}", input.ty, e))?;

        let sol_value = json_to_sol_value(&sol_type, value)?;

        if input.indexed {
            let topic = sol_value_to_topic(&sol_value)?;
            topics.push(topic);
        } else {
            data_values.push(sol_value);
        }
    }

    let data = if data_values.is_empty() {
        Bytes::new()
    } else {
        let tuple = DynSolValue::Tuple(data_values);
        Bytes::from(tuple.abi_encode_params())
    };

    Ok((topics, data))
}

/// Convert a JSON value to the corresponding Solidity type.
/// Supports: address, uint/int (decimal or hex string), bool, bytes, string, bytes1-32, arrays, tuples.
pub fn json_to_sol_value(sol_type: &DynSolType, value: &serde_json::Value) -> Result<DynSolValue> {
    match sol_type {
        DynSolType::Address => {
            let s = value
                .as_str()
                .ok_or_else(|| anyhow!("Expected string for address"))?;
            let addr: Address = s.parse().context("Invalid address")?;
            Ok(DynSolValue::Address(addr))
        }
        DynSolType::Uint(bits) => {
            let n = match value {
                serde_json::Value::String(s) => {
                    let (digits, radix) = match s.strip_prefix("0x") {
                        Some(hex) => (hex, 16),
                        None => (s.as_str(), 10),
                    };
                    U256::from_str_radix(digits, radix).context("Invalid uint")?
                }
                // JSON numbers are limited to u64 range — use strings for larger values.
                serde_json::Value::Number(n) => U256::from(n.as_u64().ok_or_else(|| {
                    anyhow!("uint value {} does not fit in u64, use a string instead", n)
                })?),
                _ => return Err(anyhow!("Expected string or number for uint")),
            };
            Ok(DynSolValue::Uint(n, *bits))
        }
        DynSolType::Int(bits) => {
            let n = match value {
                serde_json::Value::String(s) => {
                    let (is_neg, s_abs) = match s.strip_prefix('-') {
                        Some(rest) => (true, rest),
                        None => (false, s.as_str()),
                    };
                    let (digits, radix) = match s_abs.strip_prefix("0x") {
                        Some(hex) => (hex, 16),
                        None => (s_abs, 10),
                    };
                    let abs = U256::from_str_radix(digits, radix).context("Invalid int")?;
                    if is_neg { !abs + U256::from(1) } else { abs }
                }
                serde_json::Value::Number(n) => {
                    if let Some(i) = n.as_i64() {
                        // into_raw() gives the two's complement U256 representation.
                        // Handles i64::MIN correctly (unlike `-i as u64` which overflows).
                        I256::try_from(i).unwrap().into_raw()
                    } else {
                        U256::from(n.as_u64().ok_or_else(|| {
                            anyhow!(
                                "int value {} not representable as u64, use a string instead",
                                n
                            )
                        })?)
                    }
                }
                _ => return Err(anyhow!("Expected string or number for int")),
            };
            Ok(DynSolValue::Int(I256::from_raw(n), *bits))
        }
        DynSolType::Bool => {
            let b = value.as_bool().ok_or_else(|| anyhow!("Expected bool"))?;
            Ok(DynSolValue::Bool(b))
        }
        DynSolType::Bytes => {
            let s = value
                .as_str()
                .ok_or_else(|| anyhow!("Expected string for bytes"))?;
            let hex_str = s.strip_prefix("0x").unwrap_or(s);
            let bytes = hex::decode(hex_str).context("Invalid hex")?;
            Ok(DynSolValue::Bytes(bytes))
        }
        DynSolType::String => {
            let s = value.as_str().ok_or_else(|| anyhow!("Expected string"))?;
            Ok(DynSolValue::String(s.to_string()))
        }
        DynSolType::FixedBytes(len) => {
            let s = value
                .as_str()
                .ok_or_else(|| anyhow!("Expected string for bytes{}", len))?;
            let hex_str = s.strip_prefix("0x").unwrap_or(s);
            let bytes = hex::decode(hex_str).context("Invalid hex")?;
            if bytes.len() > *len {
                return Err(anyhow!(
                    "bytes{}: got {} bytes, expected at most {}",
                    len,
                    bytes.len(),
                    len
                ));
            }
            // DynSolValue::FixedBytes wraps a full B256 — right-zero-pad.
            let mut padded = [0u8; 32];
            padded[..bytes.len()].copy_from_slice(&bytes);
            Ok(DynSolValue::FixedBytes(B256::from(padded), *len))
        }
        DynSolType::Array(inner) => {
            let arr = value
                .as_array()
                .ok_or_else(|| anyhow!("Expected JSON array for array type"))?;
            let elements: Vec<DynSolValue> = arr
                .iter()
                .map(|elem| json_to_sol_value(inner, elem))
                .collect::<Result<_>>()?;
            Ok(DynSolValue::Array(elements))
        }
        DynSolType::FixedArray(inner, size) => {
            let arr = value
                .as_array()
                .ok_or_else(|| anyhow!("Expected JSON array for fixed array type"))?;
            ensure!(
                arr.len() == *size,
                "Fixed array expects {} elements, got {}",
                size,
                arr.len()
            );
            let elements: Vec<DynSolValue> = arr
                .iter()
                .map(|elem| json_to_sol_value(inner, elem))
                .collect::<Result<_>>()?;
            Ok(DynSolValue::FixedArray(elements))
        }
        DynSolType::Tuple(types) => {
            let arr = value
                .as_array()
                .ok_or_else(|| anyhow!("Expected JSON array for tuple type (positional)"))?;
            ensure!(
                arr.len() == types.len(),
                "Tuple expects {} elements, got {}",
                types.len(),
                arr.len()
            );
            let values: Vec<DynSolValue> = types
                .iter()
                .zip(arr.iter())
                .map(|(ty, val)| json_to_sol_value(ty, val))
                .collect::<Result<_>>()?;
            Ok(DynSolValue::Tuple(values))
        }
        _ => Err(anyhow!("Unsupported type: {:?}", sol_type)),
    }
}

/// Encode a Solidity value as a 32-byte EVM log topic.
fn sol_value_to_topic(value: &DynSolValue) -> Result<B256> {
    match value {
        DynSolValue::Address(addr) => {
            let mut bytes = [0u8; 32];
            bytes[12..].copy_from_slice(addr.as_slice());
            Ok(B256::from(bytes))
        }
        DynSolValue::Uint(n, _) => Ok(B256::from(*n)),
        DynSolValue::Int(n, _) => Ok(B256::from(n.into_raw())),
        DynSolValue::Bool(b) => {
            let mut bytes = [0u8; 32];
            if *b {
                bytes[31] = 1;
            }
            Ok(B256::from(bytes))
        }
        DynSolValue::FixedBytes(b, _) => Ok(*b),
        // Dynamic types are hashed per Solidity spec.
        DynSolValue::Bytes(b) => Ok(keccak256(b)),
        DynSolValue::String(s) => Ok(keccak256(s.as_bytes())),
        _ => Err(anyhow!("Cannot convert {:?} to topic", value)),
    }
}

/// Create a dummy transaction for block transaction lists.
/// Graph-node requires matching transactions for log processing.
fn dummy_transaction(
    block_number: u64,
    block_hash: B256,
    transaction_index: u64,
    transaction_hash: B256,
) -> graph::components::ethereum::AnyTransaction {
    use graph::components::ethereum::AnyTxEnvelope;
    use graph::prelude::alloy::consensus::transaction::Recovered;
    use graph::prelude::alloy::consensus::{Signed, TxEnvelope, TxLegacy};
    use graph::prelude::alloy::primitives::{Address, Signature, U256};
    use graph::prelude::alloy::rpc::types::Transaction;

    let signed = Signed::new_unchecked(
        TxLegacy::default(),
        Signature::new(U256::from(1), U256::from(1), false),
        transaction_hash,
    );

    let envelope = AnyTxEnvelope::Ethereum(TxEnvelope::Legacy(signed));

    Transaction {
        inner: Recovered::new_unchecked(envelope, Address::ZERO),
        block_hash: Some(block_hash),
        block_number: Some(block_number),
        block_timestamp: None,
        transaction_index: Some(transaction_index),
        effective_gas_price: None,
    }
}

fn create_block_with_triggers(
    number: u64,
    hash: B256,
    parent_hash: B256,
    timestamp: u64,
    triggers: Vec<EthereumTrigger>,
) -> Result<BlockWithTriggers<Chain>> {
    use graph::components::ethereum::AnyHeader;
    use graph::prelude::alloy::consensus::Header as ConsensusHeader;
    use graph::prelude::alloy::rpc::types::{Block, BlockTransactions, Header};
    use std::collections::HashSet;

    // Collect unique transaction hashes from log triggers.
    let mut tx_hashes: HashSet<B256> = HashSet::new();
    for trigger in &triggers {
        if let EthereumTrigger::Log(LogRef::FullLog(log, _)) = trigger
            && let Some(tx_hash) = log.transaction_hash
        {
            tx_hashes.insert(tx_hash);
        }
    }

    let transactions: Vec<_> = tx_hashes
        .into_iter()
        .enumerate()
        .map(|(idx, tx_hash)| dummy_transaction(number, hash, idx as u64, tx_hash))
        .collect();

    let alloy_block = Block::empty(Header {
        hash,
        inner: AnyHeader::from(ConsensusHeader {
            number,
            parent_hash,
            timestamp,
            ..Default::default()
        }),
        total_difficulty: None,
        size: None,
    })
    .with_transactions(BlockTransactions::Full(transactions));

    let light_block = LightEthereumBlock::new(alloy_block);
    let finality_block = BlockFinality::Final(Arc::new(light_block));

    Ok(BlockWithTriggers::new(
        finality_block,
        triggers,
        &graph::log::logger(false),
    ))
}
