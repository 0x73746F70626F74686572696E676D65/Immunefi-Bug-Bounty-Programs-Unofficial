import { Address, BigDecimal, BigInt } from '@graphprotocol/graph-ts'
import { Indexer, Allocation, GraphNetwork, SubgraphDeployment } from '../types/schema'
import {
  RewardsAssigned,
  ParameterUpdated,
  RewardsManager,
  RewardsDenylistUpdated,
} from '../types/RewardsManager/RewardsManager'
import {
  createOrLoadSubgraphDeployment,
  updateAdvancedIndexerMetrics,
  updateDelegationExchangeRate,
  createOrLoadGraphNetwork,
  getAndUpdateIndexerDailyData,
  getAndUpdateSubgraphDeploymentDailyData,
  batchUpdateDelegatorsForIndexer,
  getAndUpdateNetworkDailyData,
  BIGINT_ZERO,
} from './helpers'

export function handleRewardsAssigned(event: RewardsAssigned): void {
  let indexerID = event.params.indexer
  let allocationID = event.params.allocationID

  // update indexer
  let indexer = Indexer.load(indexerID)!
  indexer.rewardsEarned = indexer.rewardsEarned.plus(event.params.amount)
  // If the delegation pool has zero tokens, the contracts don't give away any rewards
  let indexerIndexingRewards =
    indexer.delegatedTokens == BIGINT_ZERO
      ? event.params.amount
      : event.params.amount
          .times(BigInt.fromI32(indexer.indexingRewardCut))
          .div(BigInt.fromI32(1000000))

  let delegatorIndexingRewards = event.params.amount.minus(indexerIndexingRewards)

  indexer.delegatorIndexingRewards = indexer.delegatorIndexingRewards.plus(delegatorIndexingRewards)
  indexer.indexerIndexingRewards = indexer.indexerIndexingRewards.plus(indexerIndexingRewards)
  indexer.delegatedTokens = indexer.delegatedTokens.plus(delegatorIndexingRewards)

  if (indexer.delegatorShares != BIGINT_ZERO) {
    indexer = updateDelegationExchangeRate(indexer as Indexer)
  }
  indexer = updateAdvancedIndexerMetrics(indexer as Indexer)
  indexer.save()

  // update allocation
  // no status updated, Claimed happens when RebateClaimed, and it is done
  let allocation = Allocation.load(allocationID)!
  allocation.indexingRewards = allocation.indexingRewards.plus(event.params.amount)
  allocation.indexingIndexerRewards = allocation.indexingIndexerRewards.plus(indexerIndexingRewards)
  allocation.indexingDelegatorRewards =
    allocation.indexingDelegatorRewards.plus(delegatorIndexingRewards)
  allocation.save()

  // update subgraph deployment
  let subgraphDeploymentID = allocation.subgraphDeployment
  let subgraphDeployment = createOrLoadSubgraphDeployment(
    subgraphDeploymentID,
    event.block.timestamp,
  )
  subgraphDeployment.indexingRewardAmount = subgraphDeployment.indexingRewardAmount.plus(
    event.params.amount,
  )
  subgraphDeployment.indexingIndexerRewardAmount =
    subgraphDeployment.indexingIndexerRewardAmount.plus(indexerIndexingRewards)
  subgraphDeployment.indexingDelegatorRewardAmount =
    subgraphDeployment.indexingDelegatorRewardAmount.plus(delegatorIndexingRewards)
  subgraphDeployment.save()

  // update graph network
  let graphNetwork = createOrLoadGraphNetwork()
  graphNetwork.totalIndexingRewards = graphNetwork.totalIndexingRewards.plus(event.params.amount)
  graphNetwork.totalIndexingIndexerRewards =
    graphNetwork.totalIndexingIndexerRewards.plus(indexerIndexingRewards)
  graphNetwork.totalIndexingDelegatorRewards =
    graphNetwork.totalIndexingDelegatorRewards.plus(delegatorIndexingRewards)
  graphNetwork.totalDelegatedTokens =
    graphNetwork.totalDelegatedTokens.plus(delegatorIndexingRewards)
  graphNetwork.save()

  batchUpdateDelegatorsForIndexer(indexer.id, event.block.timestamp)

  getAndUpdateIndexerDailyData(indexer as Indexer, event.block.timestamp)
  getAndUpdateSubgraphDeploymentDailyData(
    subgraphDeployment as SubgraphDeployment,
    event.block.timestamp,
  )
  getAndUpdateNetworkDailyData(graphNetwork as GraphNetwork, event.block.timestamp)
}

/**
 * @dev handleParameterUpdated
 * - handlers updating all parameters
 */
// export function handleParameterUpdated(event: ParameterUpdated): void {
//   let parameter = event.params.param
//   let graphNetwork = createOrLoadGraphNetwork()
//   let rewardsManager = RewardsManager.bind(event.address as Address)
//
//   if (parameter == 'issuanceRate') {
//     graphNetwork.networkGRTIssuance = rewardsManager.issuanceRate()
//   } else if (parameter == 'subgraphAvailabilityOracle') {
//     graphNetwork.subgraphAvailabilityOracle = rewardsManager.subgraphAvailabilityOracle()
//   }
//   graphNetwork.save()
// }

// export function handleImplementationUpdated(event: ImplementationUpdated): void {
//   let graphNetwork = createOrLoadGraphNetwork()
//   let implementations = graphNetwork.rewardsManagerImplementations
//   implementations.push(event.params.newImplementation)
//   graphNetwork.rewardsManagerImplementations = implementations
//   graphNetwork.save()
// }

export function handleRewardsDenyListUpdated(event: RewardsDenylistUpdated): void {
  let subgraphDeployment = SubgraphDeployment.load(event.params.subgraphDeploymentID)!
  if (event.params.sinceBlock.toI32() == 0) {
    subgraphDeployment.deniedAt = 0
  } else {
    subgraphDeployment.deniedAt = event.params.sinceBlock.toI32()
  }
  subgraphDeployment.save()
}
