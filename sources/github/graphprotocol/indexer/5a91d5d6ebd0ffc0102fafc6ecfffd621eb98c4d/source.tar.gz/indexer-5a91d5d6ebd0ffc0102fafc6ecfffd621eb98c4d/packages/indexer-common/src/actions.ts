import { NetworkMonitor } from './indexer-management'
import { AllocationStatus } from './allocations'
import { Logger } from '@graphprotocol/common-ts'
import { WhereOperators, WhereOptions } from 'sequelize'
import { Op } from 'sequelize'
import { WhereAttributeHashValue } from 'sequelize/types/model'
import { validateNetworkIdentifier } from './parsers'

export interface ActionParamsInput {
  deploymentID?: string
  allocationID?: string
  amount?: string
  poi?: string
  publicPOI?: string
  poiBlockNumber?: number
  force?: boolean
}

export interface ActionItem {
  params: ActionParamsInput
  type: ActionType
  reason: string
  status?: ActionStatus
  protocolNetwork: string
  isLegacy?: boolean
}

export interface ActionUpdateInput {
  deploymentID?: string
  allocationID?: string
  amount?: string
  poi?: string
  publicPOI?: string
  poiBlockNumber?: number
  force?: boolean
  type?: ActionType
  status?: ActionStatus
  reason?: string
  protocolNetwork?: string
  isLegacy?: boolean
}

export interface ActionInput {
  type: ActionType
  deploymentID: string
  allocationID?: string
  amount?: string
  poi?: string
  publicPOI?: string
  poiBlockNumber?: number
  force?: boolean
  source: string
  reason: string
  status: ActionStatus
  priority: number | undefined
  protocolNetwork: string
  isLegacy: boolean
}

const ZERO_POI = '0x0000000000000000000000000000000000000000000000000000000000000000'

// Validates POI-related fields for non-legacy actions.
// When POI is zero, publicPOI and poiBlockNumber are optional.
// When POI is non-zero, all three fields are required.
/* eslint-disable @typescript-eslint/no-explicit-any */
const hasValidPOIParams = (variableToCheck: any): boolean => {
  if (variableToCheck.isLegacy || variableToCheck.poi === undefined) {
    return true
  }
  if (variableToCheck.poi === ZERO_POI) {
    return 'poi' in variableToCheck
  }
  return (
    'poi' in variableToCheck &&
    'publicPOI' in variableToCheck &&
    'poiBlockNumber' in variableToCheck
  )
}

export const isValidActionInput = (
  /* eslint-disable @typescript-eslint/no-explicit-any */
  variableToCheck: any,
): variableToCheck is ActionInput => {
  if (!('type' in variableToCheck)) {
    return false
  }
  let hasActionParams = false
  switch (variableToCheck.type) {
    case ActionType.ALLOCATE:
      hasActionParams = 'deploymentID' in variableToCheck && 'amount' in variableToCheck
      break
    case ActionType.UNALLOCATE:
      hasActionParams =
        'deploymentID' in variableToCheck &&
        'allocationID' in variableToCheck &&
        hasValidPOIParams(variableToCheck)
      break
    case ActionType.REALLOCATE:
      hasActionParams =
        'deploymentID' in variableToCheck &&
        'allocationID' in variableToCheck &&
        'amount' in variableToCheck &&
        hasValidPOIParams(variableToCheck)
      break
    case ActionType.RESIZE:
      hasActionParams =
        'deploymentID' in variableToCheck &&
        'allocationID' in variableToCheck &&
        'amount' in variableToCheck
      break
    case ActionType.PRESENT_POI:
      hasActionParams =
        'deploymentID' in variableToCheck &&
        'allocationID' in variableToCheck &&
        hasValidPOIParams(variableToCheck)
      break
  }
  return (
    hasActionParams &&
    'source' in variableToCheck &&
    'reason' in variableToCheck &&
    'status' in variableToCheck &&
    'priority' in variableToCheck
  )
}

export const validateActionInputs = async (
  actions: ActionInput[],
  networkMonitor: NetworkMonitor,
  logger: Logger,
): Promise<void> => {
  // Validate actions before adding to queue
  // TODO: Perform all checks simultaneously and throw combined error if 1 or more fail
  for (const action of actions) {
    // Must have a valid protocol network identifier
    if (!action.protocolNetwork) {
      throw Error("Cannot set an action without the field 'protocolNetwork'")
    }

    try {
      // Set the parsed network identifier back in the action input object
      action.protocolNetwork = validateNetworkIdentifier(action.protocolNetwork)
    } catch (e) {
      throw Error(`Invalid value for the field 'protocolNetwork'. ${e}`)
    }

    // Must have the required params for the action type
    if (!isValidActionInput(action)) {
      throw new Error(
        `Failed to queue action: Invalid action input, actionInput: ${JSON.stringify(
          action,
        )}`,
      )
    }

    // Must have status QUEUED or APPROVED, or DEPLOYING
    if (
      [
        ActionStatus.FAILED,
        ActionStatus.SUCCESS,
        ActionStatus.PENDING,
        ActionStatus.CANCELED,
      ].includes(action.status)
    ) {
      throw Error(
        `Cannot queue action with status ${action.status}, must be one of ['APPROVED', 'QUEUED']`,
      )
    }

    // Action must target an existing subgraph deployment
    const subgraphDeployment = await networkMonitor.subgraphDeployment(
      action.deploymentID,
    )
    if (!subgraphDeployment) {
      logger.warn(
        `No subgraphDeployment with ipfsHash = '${action.deploymentID}' found on the network`,
      )
    }

    // Unallocate, reallocate, resize, and presentPOI actions must target an active allocationID
    if (
      [
        ActionType.UNALLOCATE,
        ActionType.REALLOCATE,
        ActionType.RESIZE,
        ActionType.PRESENT_POI,
      ].includes(action.type)
    ) {
      // allocationID must belong to active allocation
      // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
      const allocation = await networkMonitor.allocation(action.allocationID!)
      if (allocation.status !== AllocationStatus.ACTIVE) {
        throw new Error(
          `An active allocation does not exist with id = '${action.allocationID}'`,
        )
      }

      // Provided allocationIDs must be associated with the provided deploymentIDs
      if (allocation.subgraphDeployment.id.ipfsHash !== action.deploymentID) {
        throw new Error(
          `Allocation specified (${action.allocationID}) is not associated with the deployment specified (${action.deploymentID})`,
        )
      }
    }
  }
}

export interface ActionFilter {
  id?: number | undefined
  type?: ActionType
  status?: ActionStatus | ActionStatus[]
  source?: string
  reason?: string
  updatedAt?: WhereOperators
  protocolNetwork?: string
  isLegacy?: boolean
}

export const actionFilterToWhereOptions = (filter: ActionFilter): WhereOptions => {
  const whereOptions = [] as WhereAttributeHashValue<any>[]

  Object.entries(filter).forEach(([key, value]) => {
    if (value) {
      const obj: { [key: string]: any } = {}
      obj[key] = value
      whereOptions.push(obj)
    }
  })

  return whereOptions.length == 0 ? {} : { [Op.and]: whereOptions }
}

export interface ActionResult {
  id: number
  type: ActionType
  deploymentID: string
  allocationID: string | null
  amount: string | null
  poi: string | null
  publicPOI: string | null
  poiBlockNumber: number | null
  force: boolean | null
  source: string
  reason: string
  status: ActionStatus
  priority: number | undefined
  failureReason: string | null
  transaction: string | null
  protocolNetwork: string
  isLegacy: boolean
}

export enum ActionType {
  ALLOCATE = 'allocate',
  UNALLOCATE = 'unallocate',
  REALLOCATE = 'reallocate',
  PRESENT_POI = 'presentPOI',
  RESIZE = 'resize',
}

export enum ActionStatus {
  QUEUED = 'queued',
  APPROVED = 'approved',
  PENDING = 'pending',
  DEPLOYING = 'deploying',
  SUCCESS = 'success',
  FAILED = 'failed',
  CANCELED = 'canceled',
}

export enum ActionParams {
  ID = 'id',
  STATUS = 'status',
  TYPE = 'type',
  DEPLOYMENT_ID = 'deploymentID',
  ALLOCATION_ID = 'allocationID',
  TRANSACTION = 'transaction',
  AMOUNT = 'amount',
  POI = 'poi',
  PUBLIC_POI = 'publicPOI',
  POI_BLOCK_NUMBER = 'poiBlockNumber',
  FORCE = 'force',
  SOURCE = 'source',
  REASON = 'reason',
  PRIORITY = 'priority',
  CREATED_AT = 'createdAt',
  UPDATED_AT = 'updatedAt',
  PROTOCOL_NETWORK = 'protocolNetwork',
  IS_LEGACY = 'isLegacy',
}
