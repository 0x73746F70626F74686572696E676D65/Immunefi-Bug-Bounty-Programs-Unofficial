// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

interface IBARD {
    error MintWaitPeriodNotClosed(uint256 timeToWait);

    error MaxInflationExceeded(uint256 maxAllowedAmount);

    error CantRenounceOwnership();
}
