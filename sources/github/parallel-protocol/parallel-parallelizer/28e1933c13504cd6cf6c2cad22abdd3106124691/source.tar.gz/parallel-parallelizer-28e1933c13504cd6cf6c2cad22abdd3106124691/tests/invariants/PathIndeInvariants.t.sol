// SPDX-License-Identifier: UNLICENSED

pragma solidity 0.8.28;

import { IERC20 } from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import { IERC20Metadata } from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import "@openzeppelin/contracts/utils/Strings.sol";
import { AggregatorV3Interface } from "contracts/interfaces/external/chainlink/AggregatorV3Interface.sol";
import { MockAccessControlManager } from "tests/mock/MockAccessControlManager.sol";

import "contracts/utils/Constants.sol";
import { CollateralSetup, Fixture, IParallelizer, Test } from "../Fixture.sol";
import { TraderWithSplit } from "./actors/TraderWithSplit.t.sol";
import { ArbitragerWithSplit } from "./actors/ArbitragerWithSplit.t.sol";
import { Governance } from "./actors/Governance.t.sol";

//solhint-disable
import { console } from "@forge-std/console.sol";

contract PathIndeInvariants is Fixture {
  uint256 internal constant _NUM_TRADER = 2;
  uint256 internal constant _NUM_ARB = 2;

  IParallelizer parallelizerSplit;

  TraderWithSplit internal _traderHandler;
  ArbitragerWithSplit internal _arbitragerHandler;
  Governance internal _governanceHandler;

  address[] internal _collaterals;
  AggregatorV3Interface[] internal _oracles;
  uint8[] internal _decimals;

  function setUp() public virtual override {
    super.setUp();

    // Deploy another parallelizer to check the independant path property
    config = address(new Test());
    parallelizerSplit = deployReplicaParallelizer(
      config,
      abi.encodeWithSelector(
        Test.initialize.selector,
        accessManager,
        tokenP,
        CollateralSetup(address(eurA), address(oracleA)),
        CollateralSetup(address(eurB), address(oracleB)),
        CollateralSetup(address(eurY), address(oracleY))
      )
    );

    vm.startPrank(governor);
    accessManager.setTargetFunctionRole(
      address(parallelizerSplit), getParallelizerGovernorSelectorAccess(), GOVERNOR_ROLE
    );
    accessManager.setTargetFunctionRole(
      address(parallelizerSplit), getParallelizerGuardianSelectorAccess(), GUARDIAN_ROLE
    );
    vm.stopPrank();

    {
      // set redemption fees
      uint64[] memory xFeeRedemption = new uint64[](4);
      xFeeRedemption[0] = uint64(0);
      xFeeRedemption[1] = uint64(1e9 / 2);
      xFeeRedemption[2] = uint64((1e9 * 3) / 4);
      xFeeRedemption[3] = uint64(1e9);
      int64[] memory yFeeRedemption = new int64[](4);
      yFeeRedemption[0] = int64(int256(1e9));
      yFeeRedemption[1] = int64(int256(1e9));
      yFeeRedemption[2] = int64(int256((1e9 * 9) / 10));
      yFeeRedemption[3] = int64(int256(1e9));
      vm.startPrank(guardian);
      parallelizer.setRedemptionCurveParams(xFeeRedemption, yFeeRedemption);
      parallelizerSplit.setRedemptionCurveParams(xFeeRedemption, yFeeRedemption);
      vm.stopPrank();
    }

    _collaterals.push(address(eurA));
    _collaterals.push(address(eurB));
    _collaterals.push(address(eurY));
    _decimals.push(IERC20Metadata(address(eurA)).decimals());
    _decimals.push(IERC20Metadata(address(eurB)).decimals());
    _decimals.push(IERC20Metadata(address(eurY)).decimals());
    _oracles.push(oracleA);
    _oracles.push(oracleB);
    _oracles.push(oracleY);

    _traderHandler = new TraderWithSplit(parallelizer, parallelizerSplit, _collaterals, _oracles, _NUM_TRADER);
    _arbitragerHandler = new ArbitragerWithSplit(parallelizer, parallelizerSplit, _collaterals, _oracles, _NUM_ARB);
    _governanceHandler = new Governance(parallelizer, parallelizerSplit, _collaterals, _oracles);

    vm.startPrank(governor);
    accessManager.grantRole(GOVERNOR_ROLE, _governanceHandler.actors(0), 0);
    accessManager.grantRole(GUARDIAN_ROLE, _governanceHandler.actors(0), 0);
    vm.stopPrank();

    // Label newly created addresses
    vm.label(address(parallelizerSplit), "ParallelizerSplit");
    for (uint256 i; i < _NUM_ARB; i++) {
      vm.label(_arbitragerHandler.actors(i), string.concat("Arbi ", Strings.toString(i)));
    }
    for (uint256 i; i < _NUM_TRADER; i++) {
      vm.label(_traderHandler.actors(i), string.concat("Trader ", Strings.toString(i)));
    }

    targetContract(address(_traderHandler));
    targetContract(address(_arbitragerHandler));
    targetContract(address(_governanceHandler));

    {
      bytes4[] memory selectors = new bytes4[](1);
      selectors[0] = TraderWithSplit.swap.selector;
      targetSelector(FuzzSelector({ addr: address(_traderHandler), selectors: selectors }));
    }

    {
      bytes4[] memory selectors = new bytes4[](2);
      selectors[0] = ArbitragerWithSplit.swap.selector;
      selectors[1] = ArbitragerWithSplit.redeem.selector;
      targetSelector(FuzzSelector({ addr: address(_arbitragerHandler), selectors: selectors }));
    }

    {
      bytes4[] memory selectors = new bytes4[](4);
      selectors[0] = Governance.updateOracle.selector;
      selectors[1] = Governance.updateRedemptionFees.selector;
      selectors[2] = Governance.updateBurnFees.selector;
      selectors[3] = Governance.updateMintFees.selector;
      targetSelector(FuzzSelector({ addr: address(_governanceHandler), selectors: selectors }));
    }
  }

  function systemState() public view {
    console.log("");
    console.log("SYSTEM STATE");
    console.log("");
    console.log("Calls summary:");
    console.log("-------------------");
    console.log("Trader:swap", _traderHandler.calls("swap"));
    console.log("Arbitrager:swap", _arbitragerHandler.calls("swap"));
    console.log("Arbitrager:redeem", _arbitragerHandler.calls("redeem"));
    console.log("oracle", _governanceHandler.calls("oracle"));
    console.log("Mint fees", _governanceHandler.calls("feeMint"));
    console.log("Burn fees", _governanceHandler.calls("feeBurn"));
    console.log("Redeem fees", _governanceHandler.calls("feeRedeem"));
    console.log("Increase time", _governanceHandler.calls("timestamp"));
    console.log("-------------------");
    console.log("");

    (uint256 issuedA, uint256 issued) = parallelizer.getIssuedByCollateral(address(eurA));
    (uint256 issuedB,) = parallelizer.getIssuedByCollateral(address(eurB));
    (uint256 issuedY,) = parallelizer.getIssuedByCollateral(address(eurY));
    console.log("Issued A: ", issuedA);
    console.log("Issued B: ", issuedB);
    console.log("Issued Y: ", issuedY);
    console.log("Issued Total: ", issued);
  }

  function invariant_Supply() public {
    uint256 stablecoinIssued = parallelizer.getTotalIssued();
    uint256 stablecoinIssuedSplit = parallelizerSplit.getTotalIssued();

    uint256 balance = tokenP.balanceOf(sweeper);
    uint256 traderActors = _traderHandler.nbrActor();
    uint256 arbitrageActors = _arbitragerHandler.nbrActor();
    for (uint256 i = 0; i < traderActors; i++) {
      balance += tokenP.balanceOf(_traderHandler.actors(i));
    }
    for (uint256 i = 0; i < arbitrageActors; i++) {
      balance += tokenP.balanceOf(_arbitragerHandler.actors(i));
    }

    assertApproxEqAbs(stablecoinIssued + stablecoinIssuedSplit, balance, BASE_12);
  }

  function invariant_CollateralRatio() public {
    uint256 storedCollatRatio = _governanceHandler.collateralRatio();
    (uint64 collateralRatio,) = parallelizer.getCollateralRatio();
    if (storedCollatRatio <= BASE_9) {
      assertGe(uint256(collateralRatio), storedCollatRatio);
    }
    // if we have a collateral ratio above 100% and without fees, then a mint will decrease the collateral ratio
    // as it will become (a+c)/(b+c) with a>b
    // With fees it is less predictable, but in all cases the collateral ratio should not drop below over
    // collateralise = 100%
    else {
      assertGe(uint256(collateralRatio), BASE_9);
    }

    _governanceHandler.updateCollateralRatio(collateralRatio);
  }

  function invariant_RedeemCollateralRatio() public {
    uint256 storedCollatRatio = _governanceHandler.collateralRatio();
    (uint64 collateralRatio,) = parallelizer.getCollateralRatio();
    if (storedCollatRatio <= BASE_9) assertGe(collateralRatio, storedCollatRatio);
    else assertGe(collateralRatio, BASE_9);

    _governanceHandler.updateCollateralRatio(collateralRatio);
  }

  function invariant_PathIndependenceTotalSupply() public {
    uint256 stablecoinIssued = parallelizer.getTotalIssued();
    uint256 stablecoinIssuedSplit = parallelizerSplit.getTotalIssued();
    assertApproxEqRelDecimal(stablecoinIssued, stablecoinIssuedSplit, _MAX_PERCENTAGE_DEVIATION * 100, 18);
  }

  function invariant_PathIndependenceSubSupply() public {
    for (uint256 i; i < _collaterals.length; i++) {
      (uint256 issuedPerCollat,) = parallelizer.getIssuedByCollateral(_collaterals[i]);
      (uint256 issuedPerCollatSplit,) = parallelizerSplit.getIssuedByCollateral(_collaterals[i]);
      assertApproxEqRelDecimal(issuedPerCollat, issuedPerCollatSplit, _MAX_PERCENTAGE_DEVIATION * 500, 18);
    }
  }

  // Path independence holds exactly only where the mint/burn/redemption curves are flat. The
  // redemption penalty is evaluated at the entry-time collateral ratio on the full amount (Cyfrin
  // finding I-6) and governance may install non-flat fee curves, so single-path and split-path
  // outcomes legitimately diverge by a bounded amount. These tolerances bound that intended path
  // dependence (1% on collateral balances, 0.2% on the collateral ratio) while still catching gross
  // path-dependence regressions.
  function invariant_PathIndependenceBalanceCollaterals() public {
    for (uint256 i; i < _collaterals.length; i++) {
      uint256 balance = IERC20(_collaterals[i]).balanceOf(address(parallelizer));
      uint256 balanceSplit = IERC20(_collaterals[i]).balanceOf(address(parallelizerSplit));
      assertApproxEqRelDecimal(balance, balanceSplit, _MAX_PERCENTAGE_DEVIATION * 10000, 18);
    }
  }

  function invariant_PathIndependenceCollateralRatio() public {
    (uint256 collateralRatio,) = parallelizer.getCollateralRatio();
    (uint256 collateralRatioSplit,) = parallelizerSplit.getCollateralRatio();
    assertApproxEqRelDecimal(collateralRatio, collateralRatioSplit, _MAX_PERCENTAGE_DEVIATION * 2000, 18);
  }

  function invariantSystemState() public view {
    systemState();
  }
}
