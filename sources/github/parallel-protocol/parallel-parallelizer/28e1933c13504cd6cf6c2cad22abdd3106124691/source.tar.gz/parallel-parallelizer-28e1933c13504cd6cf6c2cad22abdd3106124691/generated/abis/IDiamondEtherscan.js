export const Abi_IDiamondEtherscan = /** @type {const} **/ ([
  {
    "inputs": [],
    "name": "implementation",
    "outputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "_implementation",
        "type": "address"
      }
    ],
    "name": "setDummyImplementation",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
]);