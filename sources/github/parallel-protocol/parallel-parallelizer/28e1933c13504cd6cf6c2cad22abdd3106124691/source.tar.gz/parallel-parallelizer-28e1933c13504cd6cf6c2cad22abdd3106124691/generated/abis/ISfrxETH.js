export const Abi_ISfrxETH = /** @type {const} **/ ([
  {
    "inputs": [],
    "name": "pricePerShare",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  }
]);