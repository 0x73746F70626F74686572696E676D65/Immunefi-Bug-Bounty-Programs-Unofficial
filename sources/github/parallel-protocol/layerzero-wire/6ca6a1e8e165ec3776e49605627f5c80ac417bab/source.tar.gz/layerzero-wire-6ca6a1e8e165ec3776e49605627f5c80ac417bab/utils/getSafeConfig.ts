import { SafeConfig } from 'hardhat/types'

export const getSafeConfig = (network: string): SafeConfig => {
    switch (network) {
        case 'mainnet': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/eth',
                safeAddress: '0x25Fc7ffa8f9da3582a36633d04804F0004706F9b',
            }
        }
        case 'polygon': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/pol',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'arbitrum': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/arb1',
                safeAddress: '0xC5201FFE258a95Af986E7cD1fcaD54f3f63f2C95',
            }
        }
        case 'base': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/base',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'optimism': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/oeth',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'avalanche': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/avax',
                safeAddress: '0xC5201FFE258a95Af986E7cD1fcaD54f3f63f2C95',
            }
        }
        case 'bsc': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/bnb',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'gnosis': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/gno',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'unichain': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/unichain',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'hyperevm': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/hyperliquid',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'ink': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/ink',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'tac': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/tac',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'plume': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/plume',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'xlayer': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/xlayer',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'scroll': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/scr',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'sei': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/sei',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'sonic': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/sonic',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'berachain': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/berachain',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'mantle': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/mantle',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'plasma': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/plasma',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'linea': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/linea',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'katana': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/katana',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'fraxtal': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/eth',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'world': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/eth',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        case 'monad': {
            return {
                safeUrl: 'https://api.safe.global/tx-service/eth',
                safeAddress: '0x2046c0416A558C40cb112E5ebB0Ca764c3C5c32a',
            }
        }
        default: {
            throw new Error(`${network} Network Safe Config not configured`)
        }
    }
}
