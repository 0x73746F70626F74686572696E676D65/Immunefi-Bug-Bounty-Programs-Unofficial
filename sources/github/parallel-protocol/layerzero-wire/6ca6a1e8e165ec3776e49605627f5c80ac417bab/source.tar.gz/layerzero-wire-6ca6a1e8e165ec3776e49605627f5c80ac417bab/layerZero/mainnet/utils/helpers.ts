import { TwoWayConfig } from '@layerzerolabs/metadata-tools'
import { OmniPointHardhat } from '@layerzerolabs/toolbox-hardhat'

import { CONFIRMATIONS_BLOCKS, DVNs, EVM_ENFORCED_OPTIONS } from './constants'
import { ContractsType, NetworkType } from './types'

export const generatePathConfig = (
    chainA: Partial<NetworkType>,
    contractsA: OmniPointHardhat,
    chainB: Partial<NetworkType>,
    contractsB: OmniPointHardhat
): TwoWayConfig => {
    return [
        contractsA,
        contractsB,
        DVNs,
        [CONFIRMATIONS_BLOCKS[chainA], CONFIRMATIONS_BLOCKS[chainB]],
        [EVM_ENFORCED_OPTIONS, EVM_ENFORCED_OPTIONS],
    ]
}

export const generatePathways = (selectedNetworks: NetworkType[], contracts: ContractsType): TwoWayConfig[] => {
    const pathways: TwoWayConfig[] = []

    for (let i = 0; i < selectedNetworks.length; i++) {
        for (let j = i + 1; j < selectedNetworks.length; j++) {
            const chainA = selectedNetworks[i]
            const chainB = selectedNetworks[j]
            pathways.push(
                generatePathConfig(chainA, getContract(chainA, contracts), chainB, getContract(chainB, contracts))
            )
        }
    }
    return pathways
}

export const getChainsContract = (
    selectedNetworks: NetworkType[],
    contracts: ContractsType
): { contract: OmniPointHardhat }[] => {
    return selectedNetworks.map((network) => ({
        contract: getContract(network, contracts),
    }))
}

function getContract(network: NetworkType, contracts: ContractsType): OmniPointHardhat {
    const contract = contracts[network]
    if (!contract) {
        throw new Error(`Contract not found for network ${network} in contracts: ${JSON.stringify(contracts)}`)
    }
    return contract
}
