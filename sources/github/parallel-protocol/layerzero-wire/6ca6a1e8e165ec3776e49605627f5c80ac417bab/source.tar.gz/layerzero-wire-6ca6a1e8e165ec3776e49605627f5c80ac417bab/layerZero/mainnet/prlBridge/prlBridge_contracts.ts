import { EndpointId } from '@layerzerolabs/lz-definitions'
import { OmniPointHardhat } from '@layerzerolabs/toolbox-hardhat'

import { NETWORKS } from '../utils/constants'
import { ContractsType } from '../utils/types'

export const mainnetContract: OmniPointHardhat = {
    eid: EndpointId.ETHEREUM_V2_MAINNET,
    contractName: 'LockBox',
}

export const polygonContract: OmniPointHardhat = {
    eid: EndpointId.POLYGON_V2_MAINNET,
    contractName: 'PeripheralPRL',
}

export const baseContract: OmniPointHardhat = {
    eid: EndpointId.BASE_V2_MAINNET,
    contractName: 'PeripheralPRL',
}

export const optimismContract: OmniPointHardhat = {
    eid: EndpointId.OPTIMISM_V2_MAINNET,
    contractName: 'PeripheralPRL',
}

export const arbitrumContract: OmniPointHardhat = {
    eid: EndpointId.ARBITRUM_V2_MAINNET,
    contractName: 'PeripheralPRL',
}

export const sonicContract: OmniPointHardhat = {
    eid: EndpointId.SONIC_V2_MAINNET,
    contractName: 'PeripheralPRL',
}

export const contracts: ContractsType = {
    [NETWORKS.MAINNET]: mainnetContract,
    [NETWORKS.ARBITRUM]: arbitrumContract,
    [NETWORKS.BASE]: baseContract,
    [NETWORKS.OPTIMISM]: optimismContract,
    [NETWORKS.POLYGON]: polygonContract,
    [NETWORKS.SONIC]: sonicContract,
}
