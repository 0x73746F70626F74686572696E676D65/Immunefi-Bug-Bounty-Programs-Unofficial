import { generateConnectionsConfig } from '@layerzerolabs/metadata-tools'

import { NETWORKS } from '../utils/constants'
import { generatePathways, getChainsContract } from '../utils/helpers'
import { NetworkType } from '../utils/types'

import { contracts } from './bridgeableTokenP_contracts'

const SELECTED_NETWORKS: NetworkType[] = [
    NETWORKS.ARBITRUM,
    NETWORKS.AVALANCHE,
    NETWORKS.BASE,
    NETWORKS.BERACHAIN,
    NETWORKS.BSC,
    NETWORKS.GNOSIS,
    NETWORKS.HYPERLIQUID,
    NETWORKS.INK,
    NETWORKS.MAINNET,
    NETWORKS.OPTIMISM,
    NETWORKS.POLYGON,
    NETWORKS.SCROLL,
    NETWORKS.SEI,
    NETWORKS.SONIC,
    NETWORKS.TAC,
    NETWORKS.UNICHAIN,
    // NETWORKS.PLUME,
    // NETWORKS.XLAYER,
    // NETWORKS.PLASMA,
    // NETWORKS.LINEA,
    // NETWORKS.KATANA,
    // NETWORKS.FRAXTAL,
    // NETWORKS.WORLD,
    // NETWORKS.MONAD,
]

export default async function () {
    // Generate the connections config based on the pathways
    const connections = await generateConnectionsConfig(generatePathways(SELECTED_NETWORKS, contracts))
    return {
        contracts: getChainsContract(SELECTED_NETWORKS, contracts),
        connections,
    }
}
