import { generateConnectionsConfig } from '@layerzerolabs/metadata-tools'

import { NETWORKS } from '../utils/constants'
import { generatePathways, getChainsContract } from '../utils/helpers'
import { NetworkType } from '../utils/types'

import { contracts } from './prlMigration_contracts'

const SELECTED_NETWORKS: NetworkType[] = [NETWORKS.MAINNET, NETWORKS.POLYGON]

export default async function () {
    // Generate the connections config based on the pathways
    const connections = await generateConnectionsConfig(generatePathways(SELECTED_NETWORKS, contracts))
    return {
        contracts: getChainsContract(SELECTED_NETWORKS, contracts),
        connections,
    }
}
