import { OmniPointHardhat } from '@layerzerolabs/toolbox-hardhat'

import { NETWORKS } from './constants'

export type NetworkType = NETWORKS

export type ContractsType = Partial<Record<NetworkType, OmniPointHardhat>>
