import { EndpointId } from '@layerzerolabs/lz-definitions'
import { OmniPointHardhat } from '@layerzerolabs/toolbox-hardhat'

import { NETWORKS } from '../utils/constants'
import { ContractsType } from '../utils/types'

export const mainnetContract: OmniPointHardhat = {
    eid: EndpointId.ETHEREUM_V2_MAINNET,
    contractName: 'PrincipalMigrationContract',
}

export const polygonContract: OmniPointHardhat = {
    eid: EndpointId.POLYGON_V2_MAINNET,
    contractName: 'PeripheralMigrationContract',
}

export const contracts: ContractsType = {
    [NETWORKS.MAINNET]: mainnetContract,
    [NETWORKS.POLYGON]: polygonContract,
}
