# Parallel Lz Wire

This project is used to update Parallel's contracts LayerZero DVN configurations.

## Requirements

- `Node.js` >= 18.16.0
- `bun`

## How to Update DVNs

### Add New Contracts to Update

1. **Add deployment files**: Add the `deployment.json` files of contracts you want to update to the `/deployments` folder. These contracts must inherit from LayerZero's OApp.

2. **Create contract folder**: In the `layerZero` folder, add a new folder under `mainnet` or `testnet` that represents your contract.

3. **Create contract files**: Inside the folder, create two files:
   - `myContract_contracts.ts` - Maps networks to LayerZero endpoints and contract names (matching the deployment.json file names from step 1)
   - `myContract.config.ts` - Contains the LayerZero deployment setup (you can use helper functions from `layerZero/mainnet/utils/helpers.ts` to use the last deployed config)

4. **Add package.json script**: Add a script in `package.json` that matches your contract configuration:

   ```json
   "wire:%MYCONTRACT%": "bunx hardhat lz:oapp:wire --oapp-config layerZero/%NETWORK%/%MYCONTRACT%/%MYCONTRACT%.config.ts"
   ```

   Replace `%MYCONTRACT%` and `%NETWORK%` with your actual contract name and network.

### Run LayerZero DVN Update

1. **Check DVN configuration**: Review the DVN configuration for your contract. For common setups, check `layerZero/mainnet/utils/helpers.ts` which contains the default DVN configuration. Also check your `myContract/` folder to see which networks are configured.

2. **Run the update command**: Execute the appropriate command:

   ```bash
   bun run wire:%MYCONTRACT%
   ```
