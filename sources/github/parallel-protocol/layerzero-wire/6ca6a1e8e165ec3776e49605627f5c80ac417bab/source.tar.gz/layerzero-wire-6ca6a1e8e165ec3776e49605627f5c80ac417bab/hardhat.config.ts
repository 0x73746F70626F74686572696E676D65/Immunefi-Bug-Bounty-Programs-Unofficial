// Get the environment configuration from .env file
//
// To make use of automatic environment setup:
// - Duplicate .env.example file and name it .env
// - Fill in the environment variables
import 'dotenv/config'

import 'hardhat-deploy'
import 'hardhat-contract-sizer'
import '@nomiclabs/hardhat-ethers'
import '@layerzerolabs/toolbox-hardhat'

import { HardhatUserConfig } from 'hardhat/types'

import { EndpointId } from '@layerzerolabs/lz-definitions'

import { getRpcURL } from './utils/getRpcURL'
import { getSafeConfig } from './utils/getSafeConfig'

const PRIVATE_KEY = process.env.PRIVATE_KEY
if (!PRIVATE_KEY) throw new Error('PRIVATE_KEY is not set')

const accounts = [PRIVATE_KEY]

if (accounts == null) {
    console.warn(
        'Could not find MNEMONIC or PRIVATE_KEY environment variables. It will not be possible to execute transactions in your example.'
    )
}

const config: HardhatUserConfig = {
    paths: {
        cache: 'cache/hardhat',
    },
    solidity: {
        compilers: [
            {
                version: '0.8.28',
                settings: {
                    evmVersion: 'cancun',
                    optimizer: {
                        enabled: true,
                        runs: 10_000,
                    },
                },
            },
        ],
    },
    networks: {
        mainnet: {
            eid: EndpointId.ETHEREUM_V2_MAINNET,
            url: getRpcURL('mainnet'),
            // safeConfig: getSafeConfig('mainnet'),
            accounts,
        },
        polygon: {
            eid: EndpointId.POLYGON_V2_MAINNET,
            url: getRpcURL('polygon'),
            // safeConfig: getSafeConfig('polygon'),
            accounts,
        },
        optimism: {
            eid: EndpointId.OPTIMISM_V2_MAINNET,
            url: getRpcURL('optimism'),
            accounts,
        },
        base: {
            eid: EndpointId.BASE_V2_MAINNET,
            url: getRpcURL('base'),
            accounts,
        },
        arbitrum: {
            eid: EndpointId.ARBITRUM_V2_MAINNET,
            url: getRpcURL('arbitrum'),
            // safeConfig: getSafeConfig('arbitrum'),
            accounts,
        },
        sonic: {
            eid: EndpointId.SONIC_V2_MAINNET,
            url: getRpcURL('sonic'),
            accounts,
        },
        sei: {
            eid: EndpointId.SEI_V2_MAINNET,
            url: getRpcURL('sei'),
            accounts,
        },
        avalanche: {
            eid: EndpointId.AVALANCHE_V2_MAINNET,
            url: getRpcURL('avalanche'),
            // safeConfig: getSafeConfig('avalanche'),
            accounts,
        },
        bsc: {
            eid: EndpointId.BSC_V2_MAINNET,
            url: getRpcURL('bsc'),
            accounts,
        },
        berachain: {
            eid: EndpointId.BERA_V2_MAINNET,
            url: getRpcURL('berachain'),
            accounts,
        },
        scroll: {
            eid: EndpointId.SCROLL_V2_MAINNET,
            url: getRpcURL('scroll'),
            accounts,
        },
        gnosis: {
            eid: EndpointId.GNOSIS_V2_MAINNET,
            url: getRpcURL('gnosis'),
            accounts,
        },
        unichain: {
            eid: EndpointId.UNICHAIN_V2_MAINNET,
            url: getRpcURL('unichain'),
            accounts,
        },
        ink: {
            eid: EndpointId.INK_V2_MAINNET,
            url: getRpcURL('ink'),
            accounts,
        },
        hyperevm: {
            eid: EndpointId.HYPERLIQUID_V2_MAINNET,
            url: getRpcURL('hyperevm'),
            accounts,
        },
        tac: {
            eid: EndpointId.TAC_V2_MAINNET,
            url: getRpcURL('tac'),
            accounts,
        },
        plume: {
            eid: EndpointId.PLUME_V2_MAINNET,
            url: getRpcURL('plume'),
            accounts,
        },
        xlayer: {
            eid: EndpointId.XLAYER_V2_MAINNET,
            url: getRpcURL('xlayer'),
            accounts,
        },
        plasma: {
            eid: EndpointId.PLASMA_V2_MAINNET,
            url: getRpcURL('plasma'),
            accounts,
        },
        linea: {
            eid: EndpointId.ZKCONSENSYS_V2_MAINNET,
            url: getRpcURL('linea'),
            accounts,
        },
        katana: {
            eid: EndpointId.KATANA_V2_MAINNET,
            url: getRpcURL('katana'),
            // safeConfig: getSafeConfig('katana'),
            accounts,
        },
        fraxtal: {
            eid: EndpointId.FRAXTAL_V2_MAINNET,
            url: getRpcURL('fraxtal'),
            accounts,
        },
        world: {
            eid: EndpointId.WORLDCHAIN_V2_MAINNET,
            url: getRpcURL('world'),
            accounts,
        },
        monad: {
            eid: EndpointId.MONAD_V2_MAINNET,
            url: getRpcURL('monad'),
            accounts,
        },
    },
    namedAccounts: {
        deployer: {
            default: 0, // wallet address of index[0], of the mnemonic in .env
        },
    },
}

export default config
