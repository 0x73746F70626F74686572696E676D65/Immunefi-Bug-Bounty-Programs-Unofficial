process.env.SKIP_RPC_CHECK = 'true'

require("dotenv").config();
const path = require("path");
import * as sdk from "@defillama/sdk";
import peggedAssets from "../../peggedData/peggedData";
import { PeggedAssetIssuance, PeggedTokenBalance } from "../../types";
import { extractIssuanceFromSnapshot, getClosestSnapshotForChain } from "../../utils/extrapolatedCacheFallback";
import { PeggedIssuanceAdapter } from "./peggedAsset.type";
import { DEAD_CHAINS } from "../../utils/deadChains";
import { importAdapter } from "../../peggedAssets/utils/importAdapter";
const {
  humanizeNumber,
} = require("@defillama/sdk/build/computeTVL/humanizeNumber");
const chainList = require("./helper/chains.json");
const errorString = "------ ERROR ------";

type ChainBlocks = {
  [chain: string]: number;
};

type BridgeMapping = {
  [chain: string]: PeggedTokenBalance[];
};

function detectPegKey(balance: any, wanted: string) {
  if (balance && typeof balance === 'object') {
    if (wanted in balance && typeof balance[wanted] === 'number' && !Number.isNaN(balance[wanted]))
      return wanted;
    const found = Object.keys(balance).find(k => k.startsWith('pegged') && typeof balance[k] === 'number' && !Number.isNaN(balance[k]));
    if (found) return found;
  }
  return wanted;
}

async function getPeggedAsset(
  _unixTimestamp: number,
  ethBlock: number,
  chainBlocks: ChainBlocks,
  peggedBalances: PeggedAssetIssuance,
  chain: string,
  issuanceType: string,
  issuanceFunction: any,
  pegType: string,
  bridgedFromMapping: BridgeMapping = {},
  extrapolationMetadata: { extrapolated: boolean; extrapolatedChains: Array<{ chain: string; timestamp: number }> },
  stablecoinId: string,
  adapterLabel: string
) {
  const maxRetries = 3;
  const timeoutMs = 3 * 60 * 1000; // 3 minutes

  for (let i = 0; i < maxRetries; i++) {
    try {
      const chainApi = new sdk.ChainApi({ chain, timestamp: _unixTimestamp })
      let balance: PeggedTokenBalance | null = null;
      if (!DEAD_CHAINS.has(chain))
        balance = await Promise.race([
          issuanceFunction(
            chainApi,
            ethBlock,
            chainBlocks
          ) as Promise<PeggedTokenBalance>,
          new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error(`Issuance function for chain ${chain} exceeded the timeout limit`)), timeoutMs)
          ),
        ])
      else {
        console.log(`[${adapterLabel}] Skipping RPC calls for dead chain ${chain}`);
        balance = {} as PeggedTokenBalance;
      }

      if (balance && Object.keys(balance).length === 0) {
        peggedBalances[chain] = peggedBalances[chain] || {};
        peggedBalances[chain][issuanceType] = { [pegType]: 0 } as any;
        return balance;
      }

      if (!balance) {
        throw new Error(`Could not get pegged balance on chain ${chain}`);
      }
      const pegKey = detectPegKey(balance as any, pegType);
      if (typeof (balance as any)[pegKey] !== "number" || Number.isNaN((balance as any)[pegKey])) {
        throw new Error(
          `Pegged balance on chain ${chain} is not a number, instead it is ${(balance as any)[pegKey]}. Make sure balance object contains a numeric pegged* key.`
        );
      }
      if (pegKey !== pegType) {
        (balance as any)[pegType] = (balance as any)[pegKey];
      }
      const bridges = (balance as any).bridges;
      if (!bridges && issuanceType !== "minted" && issuanceType !== "unreleased") {
        console.error(
          `${errorString}
          Bridge data not found on chain ${chain}. Use sumSingleBalance from helper/generalUtil to add bridge data.`
        );
      }

      peggedBalances[chain] = peggedBalances[chain] || {};
      peggedBalances[chain][issuanceType] = balance as PeggedTokenBalance;

      if (issuanceType !== "minted" && issuanceType !== "unreleased") {
        bridgedFromMapping[issuanceType] = bridgedFromMapping[issuanceType] || [];
        bridgedFromMapping[issuanceType].push(balance as PeggedTokenBalance);
      }

      return balance as PeggedTokenBalance;

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);

      if (i >= maxRetries - 1) {
        console.warn(`[${adapterLabel}] Chain ${chain} failed after ${maxRetries} attempts:`, errorMessage);
        console.log(`[${adapterLabel}] Using snapshot fallback for failed chain ${chain}`);

        try {
          const snap = await getClosestSnapshotForChain(
            stablecoinId,
            chain,
            _unixTimestamp,
          );

          if (snap && snap.snapshot && typeof snap.snapshot === 'object') {
            const { snapshot, timestamp } = snap;

            const extracted = extractIssuanceFromSnapshot(snapshot, issuanceType, pegType, chain);

            peggedBalances[chain] = peggedBalances[chain] || {};
            if (extracted) {
              peggedBalances[chain][issuanceType] = extracted as any;

              if (issuanceType !== "minted" && issuanceType !== "unreleased" && issuanceType !== "circulating") {
                bridgedFromMapping[issuanceType] = bridgedFromMapping[issuanceType] || [];
                bridgedFromMapping[issuanceType].push(extracted as any);
              }
            } else {
              (peggedBalances as any)[chain][issuanceType] = { [pegType]: null as any };
              console.log(
                `[${adapterLabel}] Snapshot found but issuance '${issuanceType}' not present in bridgedTo for ${chain}`
              );
            }

            extrapolationMetadata.extrapolated = true;
            if (!extrapolationMetadata.extrapolatedChains.find(ec => ec.chain === chain)) {
              extrapolationMetadata.extrapolatedChains.push({ chain, timestamp });
            }

            return (peggedBalances as any)[chain][issuanceType] || null;
          }

          console.log(`[${adapterLabel}] No cached snapshot found for chain ${chain} (issuance: ${issuanceType})`);
          peggedBalances[chain] = peggedBalances[chain] || {};
          (peggedBalances as any)[chain][issuanceType] = { [pegType]: null as any };

          console.error(`Getting ${issuanceType} on chain ${chain} failed.`);
          return null;
        } catch (cacheError) {
          console.error(`[${adapterLabel}] Cache fallback also failed for chain ${chain}:`, cacheError);
          peggedBalances[chain] = peggedBalances[chain] || {};
          (peggedBalances as any)[chain][issuanceType] = { [pegType]: null as any };
          return null;
        }
      } else {
        console.warn(`[${adapterLabel}] Chain ${chain} attempt ${i + 1}/${maxRetries} failed:`, errorMessage);
        await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1))); // 1s, 2s, 3s
        continue;
      }
    }
  }
}

function calcCirculating(
  peggedBalances: PeggedAssetIssuance,
  bridgedFromMapping: BridgeMapping,
  pegType: string
) {
  Object.keys(peggedBalances).map(
    (chain) => {
      let circulating: PeggedTokenBalance = { [pegType]: 0 } as any;
      const chainIssuances = peggedBalances[chain];

      Object.entries(chainIssuances).map(
        ([issuanceType, peggedTokenBalance]) => {
          const balance = (peggedTokenBalance as any)[pegType];
          if (balance == null) {
            return;
          }
          if (issuanceType === "unreleased") {
            (circulating as any)[pegType] = (circulating as any)[pegType] || 0;
            (circulating as any)[pegType]! -= balance;
          } else {
            (circulating as any)[pegType]! = (circulating as any)[pegType] || 0;
            (circulating as any)[pegType]! += balance;
          }
        }
      );

      if (bridgedFromMapping[chain]) {
        bridgedFromMapping[chain].forEach((peggedTokenBalance) => {
          const balance = (peggedTokenBalance as any)[pegType];
          if (balance == null || (circulating as any)[pegType] === 0) {
            console.error(`Null balance or 0 circulating on chain ${chain}`);
            return;
          }
          (circulating as any)[pegType]! -= balance;
        });
      }

      if ((circulating as any)[pegType]! < 0) {
        throw new Error(
          `Pegged asset on chain ${chain} has negative circulating amount`
        );
      }
      (peggedBalances as any)[chain].circulating = circulating;
    }
  );

  (peggedBalances as any)["totalCirculating"] = {};
  (peggedBalances as any)["totalCirculating"]["circulating"] = { [pegType]: 0 } as any;
  (peggedBalances as any)["totalCirculating"]["unreleased"] = { [pegType]: 0 } as any;
  Object.keys(peggedBalances).map((chain) => {
    const circulating = (peggedBalances as any)[chain].circulating || { [pegType]: 0 };
    const unreleased = (peggedBalances as any)[chain].unreleased || { [pegType]: 0 };
    if (chain !== "totalCirculating") {
      (peggedBalances as any)["totalCirculating"]["circulating"][pegType]! +=
        circulating[pegType] || 0;
      (peggedBalances as any)["totalCirculating"]["unreleased"][pegType]! +=
        unreleased[pegType] || 0;
    }
  });
}

if (process.argv.length < 3) {
  console.error(`Missing argument, you need to provide the filename of the adapter to test and the pegType.
      Eg: npx ts-node test projects/myadapter/index peggedUSD`);
  process.exit(1);
}

const passedFile = path.resolve(process.cwd(), process.argv[2]);
const dummyFn = () => { };
const INTERNAL_CACHE_FILE = 'pegged-assets-cache/sdk-cache.json';

function getStablecoinIdFromPath(filePath: string): string {
  const pathParts = filePath.split(path.sep);
  const stablecoinDir = pathParts[pathParts.length - 1];

  if (/^\d+$/.test(stablecoinDir)) {
    return stablecoinDir;
  }

  const peggedAsset = peggedAssets.find((pegged) => {
    return pegged.gecko_id === stablecoinDir || pegged.module === stablecoinDir;
  });

  if (peggedAsset) {
    return peggedAsset.id;
  }

  console.warn(`[WARNING] Could not determine stablecoin ID for path: ${filePath}, using folder name: ${stablecoinDir}`);
  return stablecoinDir;
}

function getAdapterLabelFromPath(filePath: string): string {
  const parts = filePath.split(path.sep);
  const last = parts[parts.length - 1] || 'unknown-adapter';
  if (/^\d+$/.test(last)) {
    const found = peggedAssets.find(p => p.id === last);
    return (found?.gecko_id || found?.name || last) as string;
  }
  const byName = peggedAssets.find(p => p.gecko_id === last || p.module === last);
  return (byName?.gecko_id || byName?.module || last) as string;
}

(async () => {
  let adapter = {} as PeggedIssuanceAdapter;
  let module: any
  const stablecoinId = getStablecoinIdFromPath(passedFile);
  const adapterLabel = getAdapterLabelFromPath(passedFile);

  const peggedAsset = peggedAssets.find((p) => p.id === stablecoinId);

  try {
    adapter = require(passedFile);
  } catch (e) {
    // No adapter file: assets defined purely via `chainConfig` in peggedData have
    // no module file — importAdapter builds them below. Only bail if there's also
    // no chainConfig to build from.
    if (!peggedAsset?.chainConfig) {
      console.log(e);
      return;
    }
  }

  let relativeModulePath = path.relative(__dirname, passedFile).replace(/\\/g, '/').replace(/\.ts$/, '');
  module = await importAdapter(peggedAsset ?? {
    module: relativeModulePath
  } as any, adapter.default);

  const chains = Object.keys(module).filter(
    (chain) => !["minted", "unreleased"].includes(chain)
  );
  console.log(`[INFO] Detected stablecoin: ${adapterLabel} (id: ${stablecoinId}) for file: ${passedFile}`);

  checkExportKeys(passedFile, chains);

  // Parse optional date and pegType from argv. Accepts either:
  //   --date=YYYY-MM-DD   or a bare YYYY-MM-DD positional
  //   pegType as any remaining positional (e.g. peggedEUR)
  let dateTimestamp: number | undefined;
  let pegType: string | undefined;
  for (const arg of process.argv.slice(3)) {
    if (arg.startsWith("--date=")) {
      const parsed = new Date(arg.slice("--date=".length));
      if (!isNaN(parsed.getTime())) dateTimestamp = Math.round(parsed.getTime() / 1000);
    } else if (/^\d{4}-\d{2}-\d{2}$/.test(arg)) {
      const parsed = new Date(arg);
      if (!isNaN(parsed.getTime())) dateTimestamp = Math.round(parsed.getTime() / 1000);
    } else if (!pegType) {
      pegType = arg;
    }
  }
  pegType = pegType ?? "peggedUSD";

  const unixTimestamp = dateTimestamp ?? Math.round(Date.now() / 1000) - 60;
  if (dateTimestamp) {
    console.log(`[INFO] Using historical timestamp: ${new Date(dateTimestamp * 1000).toISOString()} (${dateTimestamp})`);
  }

  const chainBlocks = {} as ChainBlocks;

  if (!chains.includes("ethereum")) {
    chains.push("ethereum");
  }

  const ethBlock = chainBlocks.ethereum;
  let peggedBalances: PeggedAssetIssuance = {};
  let bridgedFromMapping: BridgeMapping = {};

  const extrapolationMetadata = {
    extrapolated: false,
    extrapolatedChains: [] as Array<{ chain: string; timestamp: number }>
  };

  await initializeSdkInternalCache()

  let peggedBalancesPromises = Object.entries(module).map(
    async ([chain, issuances]) => {
      if (typeof issuances !== "object" || issuances === null) {
        return;
      }
      const issuanceTypes = Object.keys(issuances);

      if (issuanceTypes.includes(chain)) {
        throw new Error(`Chain ${chain} has issuance bridged to itself.`);
      }
      let peggedChainPromises = Object.entries(issuances).map(
        async ([issuanceType, issuanceFunctionPromise]) => {
          try {
            const issuanceFunction = await issuanceFunctionPromise;
            if (typeof issuanceFunction !== "function") {
              return;
            }
            await getPeggedAsset(
              unixTimestamp,
              ethBlock,
              chainBlocks,
              peggedBalances,
              chain,
              issuanceType,
              issuanceFunction,
              pegType,
              bridgedFromMapping,
              extrapolationMetadata,
              stablecoinId,
              adapterLabel
            );
          } catch (e) {
            console.log(`Failed on ${chain}:${issuanceType}`, e);
          }
        }
      );
      await Promise.all(peggedChainPromises);
    }
  );
  await Promise.all(peggedBalancesPromises);

  calcCirculating(peggedBalances, bridgedFromMapping, pegType)

  if (
    typeof (peggedBalances as any).totalCirculating.circulating[pegType] !== "number"
  ) {
    throw new Error(`Pegged asset doesn't have total circulating`);
  }
  if ((peggedBalances as any).totalCirculating.circulating[pegType]! > 1000e9) {
    throw new Error(`Pegged asset total circulating is over 1000 billion`);
  }
  if ((peggedBalances as any).totalCirculating.circulating[pegType] === 0) {
    throw new Error(`Returned 0 total circulating`);
  }
  const displayTable: any = []
  Object.entries(peggedBalances).forEach(([chain, issuances]) => {
    if (chain === "extrapolated" || chain === "extrapolatedChains") {
      return;
    }

    const item: any = { chain }
    if (chain !== "totalCirculating") {
      displayTable.push(item)
      console.log(`--- ${chain} ---`);

      if (issuances && typeof issuances === 'object') {
        Object.entries(issuances)
          .filter(([_, issuance]) => issuance && typeof issuance === 'object')
          .sort((a, b) => {
            const aValue = (a[1] as any)?.[pegType] ?? 0;
            const bValue = (b[1] as any)?.[pegType] ?? 0;
            return bValue - aValue;
          })
          .forEach(([issuanceType, issuance]) => {
            const value = (issuance as any)?.[pegType];
            item[issuanceType] = safeHumanizeNumber(value);
            console.log(
              issuanceType.padEnd(25, " "),
              safeHumanizeNumber(value)
            );
          });
      } else {
        console.log(`[DEBUG] Chain ${chain} has invalid issuances data:`, issuances);
      }
    }
  });
  console.log(`------ Total Circulating ------`);
  const totalItem: any = { chain: "Total Circulating" }
  Object.entries((peggedBalances as any).totalCirculating).forEach(
    ([issuanceType, issuance]) => {
      totalItem[issuanceType] = humanizeNumber((issuance as any)[pegType]);
      console.log(
        `Total ${issuanceType}`.padEnd(25, " "),
        humanizeNumber((issuance as any)[pegType])
      )
    }
  );

  if (extrapolationMetadata.extrapolated) {
    console.log(`\n------ EXTRAPOLATION INFO ------`);
    console.log(`⚠️  Some chains used extrapolated data from cache`);
    console.log(`Extrapolated chains details:`);

    extrapolationMetadata.extrapolatedChains?.forEach((extrapolatedChain: any) => {
      const d = new Date(extrapolatedChain.timestamp * 1000);
      const formattedDate = d.toISOString().slice(0, 10); // YYYY-MM-DD
      console.log(`   • ${extrapolatedChain.chain}: ${formattedDate}`);
    });
  } else {
    console.log(`\n------ NO EXTRAPOLATION ------`);
    console.log(`✅ All chains used real-time data`);
  }

  if (extrapolationMetadata?.extrapolated)
    console.log(`\n[DEBUG] Final extrapolation state:`, {
      extrapolated: extrapolationMetadata.extrapolated,
      extrapolatedChainsCount: extrapolationMetadata.extrapolatedChains?.length || 0,
      extrapolationMetadata: extrapolationMetadata.extrapolatedChains
    });

  displayTable.push(totalItem)
  displayTable.sort((a: any, b: any) => valueFromItem(a) - valueFromItem(b))

  function valueFromItem(item: any) {
    let val = item.circulating || item.unreleased || 0;
    if (typeof val === 'string') {
      let [v0, exponent]: any = val.toLowerCase().split(' ');
      if (exponent === 'k') {
        exponent = 1e3;
      } else if (exponent === 'm') {
        exponent = 1e6;
      } else if (exponent === 'b') {
        exponent = 1e9;
      } else {
        exponent = 1;
      }
      val = parseFloat(v0) * exponent;
    }
    return val;
  }

  console.table(displayTable);
  process.exit(0);
})();

function checkExportKeys(_filePath: string, chains: string[]) {

  const unknownChains = chains.filter((chain) => !chainList.includes(chain));

  if (unknownChains.length) {
    console.log(`
      ${errorString}
  
      Unknown chain(s): ${unknownChains.join(", ")}
      Note: if you think that the chain is correct but missing from our list, please add it to 'projects/helper/chains.json' file
      `);
    process.exit(1);
  }
}

function handleError(error: string) {
  console.log("\n", errorString, "\n\n");
  console.error(error);
  process.exit(1);
}

process.on("unhandledRejection", handleError);
process.on("uncaughtException", handleError);

async function initializeSdkInternalCache() {
  let currentCache = await sdk.cache.readCache(INTERNAL_CACHE_FILE)
  const ONE_MONTH = 60 * 60 * 24 * 30
  if (!currentCache || !currentCache.startTime || (Date.now() / 1000 - currentCache.startTime > ONE_MONTH)) {
    currentCache = {
      startTime: Math.round(Date.now() / 1000),
    }
    await sdk.cache.writeCache(INTERNAL_CACHE_FILE, currentCache)
  }
  sdk.sdkCache.startCache(currentCache)
}

async function saveSdkInternalCache() {
  await sdk.cache.writeCache(INTERNAL_CACHE_FILE, sdk.sdkCache.retriveCache())
}

function safeHumanizeNumber(value: any): string {
  if (value === null || value === undefined) {
    return "0";
  }
  if (typeof value === "number") {
    return humanizeNumber(value);
  }
  if (typeof value === "string") {
    const numValue = parseFloat(value);
    if (isNaN(numValue)) {
      return "0";
    }
    return humanizeNumber(numValue);
  }
  return "0";
}
