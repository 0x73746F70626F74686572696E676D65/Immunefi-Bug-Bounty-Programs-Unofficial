type PegType =
  | "peggedUSD" //dollar
  | "peggedVAR" //variable
  | "peggedEUR" //europe/euro
  | "peggedSGD" //singapora
  | "peggedJPY" //japan
  | "peggedCNY" //china
  | "peggedMXN" //mexican peso
  | "peggedMYR" //malaysian ringgit
  | "peggedUAH" //ukraine
  | "peggedARS" //ARGENTINE
  | "peggedGBP" //GB
  | "peggedCAD" //canadian dollar
  | "peggedTRY" //Turkish lira
  | "peggedXAU" //Gold this is not used
  | "peggedCHF" //Swiss franc
  | "peggedCOP" //colombian peso
  | "peggedREAL"//brazilian real 
  | "peggedRUB" //russian ruble
  | "peggedAUD" //Australian currency
  | "peggedKES" //Kenyan shilling
  | "peggedZAR" //South African rand
  | "peggedNGN" //Nigerian naira
  | "peggedXOF" //West African CFA franc
  | "peggedGHS" //Ghanaian cedi
  | "peggedCLP" //chilean peso
  | "peggedPEN" //peruvian sol
  | "peggedKRW" //South Korean won

type PegMechanism = "algorithmic" | "fiat-backed" | "crypto-backed";

export type PriceSource =
  | "chainlink"
  | "uniswap"
  | "dexscreener"
  | "curve"
  | "coingecko"
  | "birdeye"
  | "kucoin"
  | "defillama"
  | "kaddex";

export type PeggedAsset = {
  id: string;
  name: string;
  address: string;
  symbol: string;
  url: string;
  description: string;
  mintRedeemDescription: string;
  onCoinGecko: string;
  gecko_id: string;
  cmcId: string;
  pegType: PegType;
  pegMechanism: PegMechanism;
  priceSource: PriceSource;
  auditLinks: string[];
  twitter: string;
  wiki: string;
  delisted?: boolean;
  deadFrom?: string;
  doublecounted?: boolean;
  deprecated?: boolean;
  yieldBearing?: boolean;
  bridgeConfig?: BridgeConfig;
  module?: string;  // adapter module to use, defaults to gecko_id if not set
  chainConfig?: ChainConfig; // inline declarative adapter: chain -> contracts, built via addChainExports. Avoids needing an adapter file for simple issued/bridged configs.
};

// map of llama chain key -> contract config consumed by addChainExports.
// per-chain keys: issued | unreleased | reserves | bridgedFromETH | bridgeOnETH | bridgedFrom<Chain>.
// values are address strings or arrays of address strings.
export type ChainConfig = {
  decimals?: number; // token decimals passed to addChainExports (default 18)
  chains: {
    [chain: string]: {
      [key: string]: string | string[];
    };
  };
};

type BridgeConfig = {
  lzConfig?: {
    symbols?: string[]; // list of symbols to include in the config, if empty or not set, includes all
    excludeChains?: string[]; // llama chain keys to skip in generated LZ config (avoids collisions with manual entries on wrong-key chains)
    oftTypes?: string[]; // advanced override: explicit LZ types to include; bypasses auto-inference.
    chainMap?: { [llamaKey: string]: string }; // rename emitted chain keys: { frax: "fraxtal" } maps LZ's frax to adapter's fraxtal
    requirePeggedToSource?: boolean; // advanced: force oftTypes override to additionally require peggedTo.chainName === detected source
  };
  hyperlaneConfig?: {
    symbols?: string[]; // list of symbols to match against registry tokens; default: [peggedAsset.symbol]
    excludeChains?: string[]; // DefiLlama chain keys to skip in generated config (avoids collisions with manual bridgedFrom entries)
    standardTypes?: string[]; // advanced override: explicit Hyperlane standard types to include; bypasses default synthetic-only filter
    chainMap?: { [llamaKey: string]: string }; // per-asset chain key rename on top of the generator's global Hyperlane→DefiLlama mapping
    sourceChain?: string; // pin the source chain (DefiLlama llamaKey) instead of relying on collateral-side voting; protects against silent flips when the registry adds new collateral entries
  };
}

type Bridge = {
  name: string;
  link?: string;
};

export type BridgeInfo = {
  [bridgeID: string]: Bridge;
};
