package ambient

import (
	"math/big"
	"testing"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
	"github.com/goccy/go-json"
	"github.com/holiman/uint256"
	"github.com/stretchr/testify/require"

	"github.com/KyberNetwork/kyberswap-dex-lib/pkg/entity"
	"github.com/KyberNetwork/kyberswap-dex-lib/pkg/source/pool"
	"github.com/KyberNetwork/kyberswap-dex-lib/pkg/swaplimit"
	"github.com/KyberNetwork/kyberswap-dex-lib/pkg/valueobject"
)

const (
	testWETH = "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"
	testUSDC = "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"
)

var testNative = hexutil.Encode(valueobject.AddrZero[:])

func TestPoolSimulatorCalcAmountOutAndUpdateBalance(t *testing.T) {
	t.Parallel()

	sim := newTestPoolSimulator(t)
	cloned := sim.CloneState().(*PoolSimulator)

	limit := swaplimit.NewInventory(DexType, sim.CalculateLimit())

	require.NotNil(t, limit.GetLimit(testNative))
	require.NotNil(t, limit.GetLimit(testUSDC))
	require.Nil(t, limit.GetLimit(testWETH))

	amountIn := big.NewInt(1_000_000)
	res, err := sim.CalcAmountOut(pool.CalcAmountOutParams{
		TokenAmountIn: pool.TokenAmount{Token: testWETH, Amount: amountIn},
		TokenOut:      testUSDC,
		Limit:         limit,
	})
	require.NoError(t, err)
	require.Positive(t, res.TokenAmountOut.Amount.Sign())
	require.Zero(t, cloned.Info.Reserves[0].Cmp(sim.Info.Reserves[0]), "CalcAmountOut must not mutate state")

	beforeIn := new(big.Int).Set(sim.Info.Reserves[0])
	beforeOut := new(big.Int).Set(sim.Info.Reserves[1])
	quoteBudgetBefore := new(big.Int).Set(limit.GetLimit(testUSDC))
	nativeBudgetBefore := new(big.Int).Set(limit.GetLimit(testNative))

	sim.UpdateBalance(pool.UpdateBalanceParams{
		TokenAmountIn:  pool.TokenAmount{Token: testWETH, Amount: amountIn},
		TokenAmountOut: *res.TokenAmountOut,
		Fee:            *res.Fee,
		SwapInfo:       res.SwapInfo,
		SwapLimit:      limit,
	})

	require.Equal(t, new(big.Int).Add(beforeIn, amountIn), sim.Info.Reserves[0])
	require.Equal(t, new(big.Int).Sub(beforeOut, res.TokenAmountOut.Amount), sim.Info.Reserves[1])
	require.Equal(t, new(big.Int).Sub(quoteBudgetBefore, res.TokenAmountOut.Amount), limit.GetLimit(testUSDC))
	require.Equal(t, new(big.Int).Add(nativeBudgetBefore, amountIn), limit.GetLimit(testNative))

	_, _, err = limit.UpdateLimit(testUSDC, testNative, limit.GetLimit(testUSDC), big.NewInt(0))
	require.NoError(t, err)

	_, err = sim.CalcAmountOut(pool.CalcAmountOutParams{
		TokenAmountIn: pool.TokenAmount{Token: testWETH, Amount: amountIn},
		TokenOut:      testUSDC,
		Limit:         limit,
	})
	require.ErrorIs(t, err, pool.ErrNotEnoughInventory)
}

func TestPoolSimulatorCloneStateIsolatesPairState(t *testing.T) {
	t.Parallel()

	sim := newTestPoolSimulator(t)
	cloned := sim.CloneState().(*PoolSimulator)

	// PriceRoot is uint256.Int (value type); mutating cloned must not affect original.
	cloned.state.Curve.PriceRoot.Add(&cloned.state.Curve.PriceRoot, uint256.NewInt(1))
	require.NotEqual(t, 0, cloned.state.Curve.PriceRoot.Cmp(&sim.state.Curve.PriceRoot))
}

func newTestPoolSimulator(t *testing.T) *PoolSimulator {
	t.Helper()

	base := valueobject.AddrZero
	quote := common.HexToAddress(testUSDC)
	poolHash := EncodePoolHash(base, quote, 420)

	staticExtra, err := json.Marshal(StaticExtra{
		NativeToken: testWETH,
		PoolIdx:     420,
		SwapDex:     "0xaaaaaaaaa24eeeb8d57d431224f73832bc34f688",
		Base:        base.String(),
		Quote:       testUSDC,
	})
	require.NoError(t, err)

	var seeds, concLiq uint256.Int
	seeds.SetUint64(1_000_000_000)
	concLiq.SetUint64(500_000_000)
	var bidLots100, askLots100 uint256.Int
	askLots100.SetUint64(100)
	bidLots100.SetUint64(100)

	state := &TrackerExtra{
		Base:     base,
		Quote:    quote,
		PoolIdx:  420,
		PoolHash: poolHash,
		Curve: CurveState{
			PriceRoot:    GetSqrtRatioAtTick(0),
			AmbientSeeds: seeds,
			ConcLiq:      concLiq,
			SeedDeflator: 0,
			ConcGrowth:   0,
		},
		PoolSpec:    PoolSpec{FeeRate: 2500, ProtocolTake: 0, TickSize: 16},
		PoolParams:  PoolParams{FeeRate: 2500, ProtocolTake: 0, TickSize: 16},
		ActiveTicks: []int32{-256, 256},
		Levels: []TrackedLevel{
			{Tick: -256, Level: BookLevel{AskLots: askLots100}},
			{Tick: 256, Level: BookLevel{BidLots: bidLots100}},
		},
	}

	extra, err := json.Marshal(Extra{State: state})
	require.NoError(t, err)

	sim, err := NewPoolSimulator(entity.Pool{
		Address:  poolHash.Hex(),
		Exchange: valueobject.ExchangeAmbient,
		Type:     DexType,
		Tokens: []*entity.PoolToken{
			{Address: testWETH, Swappable: true},
			{Address: testUSDC, Swappable: true},
		},
		Reserves:    []string{"1000000000000000000000", "1000000000000"},
		Extra:       string(extra),
		StaticExtra: string(staticExtra),
	})
	require.NoError(t, err)

	return sim
}
