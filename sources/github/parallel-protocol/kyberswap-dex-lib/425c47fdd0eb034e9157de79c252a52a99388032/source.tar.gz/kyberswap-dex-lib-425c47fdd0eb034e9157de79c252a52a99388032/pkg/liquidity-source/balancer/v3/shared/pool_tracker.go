package shared

import (
	"math/big"

	"github.com/KyberNetwork/ethrpc"
	"github.com/holiman/uint256"
	"github.com/samber/lo"

	"github.com/KyberNetwork/kyberswap-dex-lib/pkg/liquidity-source/erc4626"
	"github.com/KyberNetwork/kyberswap-dex-lib/pkg/valueobject"
)

func GetBufferTokens(addFn func(*ethrpc.Call, []any), chainID valueobject.ChainID, exchange string, bufferTokens []string) func() []*ExtraBuffer {
	var (
		rates       = make([][]Rate, len(bufferTokens))
		maxDeposits = make([]*big.Int, len(bufferTokens))
		maxRedeems  = make([]*big.Int, len(bufferTokens))
	)

	vault := Vault(chainID, exchange)
	for i, bufferToken := range bufferTokens {
		if bufferToken == "" {
			continue
		}

		rates[i] = make([]Rate, len(erc4626.PrefetchAmounts))
		for j, amt := range erc4626.PrefetchAmounts {
			addFn(&ethrpc.Call{
				ABI:    ERC4626ABI,
				Target: bufferToken,
				Method: ERC4626MethodConvertToAssets,
				Params: []any{amt.ToBig()},
			}, []any{&rates[i][j].RedeemRate})
			addFn(&ethrpc.Call{
				ABI:    ERC4626ABI,
				Target: bufferToken,
				Method: ERC4626MethodConvertToShares,
				Params: []any{amt.ToBig()},
			}, []any{&rates[i][j].DepositRate})
		}
		addFn(&ethrpc.Call{
			ABI:    ERC4626ABI,
			Target: bufferToken,
			Method: ERC4626MethodMaxDeposit,
			Params: []any{vault},
		}, []any{&maxDeposits[i]})
		addFn(&ethrpc.Call{
			ABI:    ERC4626ABI,
			Target: bufferToken,
			Method: ERC4626MethodMaxRedeem,
			Params: []any{vault},
		}, []any{&maxRedeems[i]})
	}

	return func() []*ExtraBuffer {
		return lo.Map(rates, func(rates []Rate, i int) *ExtraBuffer {
			if bufferTokens[i] == "" {
				return nil
			}

			var extra = ExtraBuffer{
				DepositRates: make([]*uint256.Int, len(rates)),
				RedeemRates:  make([]*uint256.Int, len(rates)),
				MaxDeposit:   uint256.MustFromBig(maxDeposits[i]),
				MaxRedeem:    uint256.MustFromBig(maxRedeems[i]),
			}

			for j, rate := range rates {
				extra.DepositRates[j] = uint256.MustFromBig(rate.DepositRate)
				extra.RedeemRates[j] = uint256.MustFromBig(rate.RedeemRate)
			}

			return &extra
		})
	}
}
