module.exports = {
  "Storage": "0xf4D0374AE0c3Fa6bc073D3C1b4Db364610345437",
  "RewardForwarder": "0x98E03c6Ed7374F1e58FF022f1D2D8239526E13F9",
  "Controller": "0xF90FF0F7c8Db52bF1bF869F74226eAD125EFa745",
  "Governance": "0x6a74649aCFD7822ae8Fb78463a9f2192752E5Aa2",
  "iFARM": "0x0000000000000000000000000000000000000000",
  "WETH": "0x4200000000000000000000000000000000000006",
  "VaultImplementation": "0x47cAB26Cf72D969bE2af365F23D62d2056ECE1Cf",
  "CommunityMsig": "0x6a74649aCFD7822ae8Fb78463a9f2192752E5Aa2",
  "ProfitShare": "0xCD719739C3Ece8b576D649BE97195aD03e676a2c",
  "Reader": "",
  "Factory": {
    "VaultFactory": "0xC0cE53f755feAe93Fd219b2Cd0F58a4Fd0d535Dd",
    "PotPoolFactory": "0x58F1014065E66176CDafbb61D7Ce8EBCbd7D392c",
    "MegaFactory": "0x8F0d40c95047c6B09f08905C110d002E65e96C7d",
    "UpgradableStrategyFactory": "0x99AFf7327CEb88fE408d1fB93dc3150fEa5f9A2A"
  },
  "UniversalLiquidator": {
    "UniversalLiquidator": "0x88937abfc8C6A88cc70bfc686E4fBba80DE8d329",
    "UniversalLiquidatorRegistry": "0x292eB9d147566F6c6777f55Ff2b632D4673Ced29",
    "Dexes": {
      "": {
        "hex": "",
        "address": ""
      }
    }
  }
};
