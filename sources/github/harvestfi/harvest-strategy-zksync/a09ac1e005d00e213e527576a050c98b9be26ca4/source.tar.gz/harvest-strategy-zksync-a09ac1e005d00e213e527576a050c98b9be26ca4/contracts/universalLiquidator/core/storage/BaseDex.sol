// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

abstract contract BaseDexStorage {
    address internal _router;
}
