const prompt = require('prompt');
const addresses = require("../../test/test-config.js")

async function main() {
    prompt.start();
    const wallet = await zksyncEthers.getWallet()
    
    const registry = await zksyncEthers.getContractAt("IDex", addresses.UniversalLiquidator.Dexes.uniV3.address, wallet);
    await registry.setFee(
      "0xD78ABD81a3D57712a3af080dc4185b698Fe9ac5A",
      "0x5AEa5775959fBC2557Cc8789bC1bf90A239D9a91",
      3000,
    );
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
