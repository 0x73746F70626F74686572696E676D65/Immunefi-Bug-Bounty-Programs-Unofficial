const prompt = require('prompt');
const addresses = require("../../test/test-config.js")

async function main() {
    prompt.start();
    const wallet = await zksyncEthers.getWallet()
    
    const registry = await zksyncEthers.getContractAt("UniversalLiquidatorRegistry", addresses.UniversalLiquidator.UniversalLiquidatorRegistry, wallet);
    await registry.setPath(
      "0x8f78a54cb77f4634a5bf3dd452ed6a2e33432c73821be59208661199511cd94f",
      [
        "0xA900cbE7739c96D2B153a273953620A701d5442b",
        "0x5AEa5775959fBC2557Cc8789bC1bf90A239D9a91",
      ]
    );
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
