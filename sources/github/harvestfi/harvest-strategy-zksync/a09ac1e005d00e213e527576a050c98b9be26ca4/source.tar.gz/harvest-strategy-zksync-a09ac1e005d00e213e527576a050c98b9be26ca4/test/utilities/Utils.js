const BigNumber = require('bignumber.js');
const { time } = require("@openzeppelin/test-helpers");
BigNumber.config({DECIMAL_PLACES: 0});

const sleep = (delay) => new Promise((resolve) => setTimeout(resolve, delay))

let gasLogger = {};
let gasLoggerNum = {};

async function gasLog(logTo, targetPromise) {
  let tx = await targetPromise;
  gasUsed = tx.receipt.gasUsed;

  if(gasLogger[logTo] == undefined) {
    gasLogger[logTo] = gasUsed;
    gasLoggerNum[logTo] = 1;
  }
  else {
    gasLogger[logTo] = (gasLogger[logTo])/(gasLoggerNum[logTo]+1) + gasUsed/(gasLoggerNum[logTo]+1);
    gasLoggerNum[logTo]++;
  }
}

async function printGasLog() {
  console.log(gasLogger);
}

async function advanceNBlock (n) {
  let startingBlock = await time.latestBlock();
  // await time.increase(1 * Math.round(n));
  let endBlock = startingBlock.addn(n);
  await time.advanceBlockTo(endBlock);
}
async function waitHours (n) {
  await time.increase(n * 3600 + 1);
  let startingBlock = await time.latestBlock();
  await time.advanceBlockTo(startingBlock.addn(1));
};

async function waitTime (n) {
  await time.increase(n);
  let startingBlock = await time.latestBlock();
  await time.advanceBlockTo(startingBlock.addn(1));
};

function assertBNEq(a, b){
  let _a = new BigNumber(a);
  let _b = new BigNumber(b);
  let msg = _a.toFixed() + " != " + _b.toFixed();
  assert.equal(_a.eq(_b), true, msg);
}

function assertApproxBNEq(a, b, c){
  let _a = new BigNumber(a).div(c);
  let _b = new BigNumber(b).div(c);
  let msg = _a.toFixed() + " != " + _b.toFixed();
  assert.equal(_a.eq(_b), true, msg);
}

function assertBNGt(a, b){
  let _a = new BigNumber(a);
  let _b = new BigNumber(b);
  let msg = _a.toFixed() + " is not greater than " + _b.toFixed();
  assert.equal(_a.gt(_b), true, msg);
}

function assertBNGte(a, b){
  let _a = new BigNumber(a);
  let _b = new BigNumber(b);
  let msg = _a.toFixed() + " is not greater than " + _b.toFixed();
  assert.equal(_a.gte(_b), true, msg);
}

function assertNEqBN(a, b){
  let _a = new BigNumber(a);
  let _b = new BigNumber(b);
  assert.equal(_a.eq(_b), false);
}

async function inBNfixed(a) {
  return await (new BigNumber(a)).toFixed();
}

module.exports = {
  gasLogger,
  gasLoggerNum,
  gasLog,
  printGasLog,
  advanceNBlock,
  assertBNEq,
  assertApproxBNEq,
  assertBNGt,
  assertNEqBN,
  inBNfixed,
  waitHours,
  waitTime,
  assertBNGte,
  sleep,
};
