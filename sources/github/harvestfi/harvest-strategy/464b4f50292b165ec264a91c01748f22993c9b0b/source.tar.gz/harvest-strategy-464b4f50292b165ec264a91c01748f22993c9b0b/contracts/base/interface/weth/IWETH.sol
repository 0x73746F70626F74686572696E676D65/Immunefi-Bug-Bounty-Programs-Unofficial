//SPDX-License-Identifier: Unlicense
pragma solidity 0.8.26;

interface IWETH {
    function deposit() external payable;
    function transfer(address to, uint value) external returns (bool);
    function withdraw(uint) external;
}
