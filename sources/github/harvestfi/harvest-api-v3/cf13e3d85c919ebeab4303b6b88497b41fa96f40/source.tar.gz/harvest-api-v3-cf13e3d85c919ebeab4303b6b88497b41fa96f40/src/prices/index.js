const { toArray, isArray } = require('lodash')
const { cache } = require('../lib/cache')
const { UI_DATA_FILES, GET_PRICE_TYPES, CHAIN_IDS } = require('../lib/constants')
const { getUIData } = require('../lib/data')
const {
  getTokenPriceByAddress,
  getTokenPriceById,
  priceByAddresses,
  priceByIds,
} = require('./coingecko')
const logger = require('../lib/logger')

const executePriceFunction = async (type, params) => {
  let implementation
  const transformedType = type.toLowerCase().replace(/_/g, '-')
  try {
    implementation = require(`./implementations/${transformedType}.js`)
  } catch (e) {
    logger.error(
      `executePriceFunction(...) implementation for '${transformedType}' [${type}] is not available`,
      e,
    )
    return Promise.resolve(0)
  }

  const price = await implementation.getPrice(...params)
  return Promise.resolve(price)
}

const getTokenPrice = async (selectedToken, ourChainId = CHAIN_IDS.ETH) => {
  const currency = 'usd'
  const normalizedSelectedToken = selectedToken.toLowerCase()
  const cachedPriceKey1 = `tokenPrice${normalizedSelectedToken}${ourChainId}${currency}`
  const cachedPrice1 = cache.get(cachedPriceKey1)

  if (cachedPrice1 && !(selectedToken == 'IFARM')) {
    return cachedPrice1
  }

  const tokens = await getUIData(UI_DATA_FILES.TOKENS)

  const tokenData =
    tokens[selectedToken] ||
    toArray(tokens).find(
      token =>
        token.tokenAddress &&
        !isArray(token.tokenAddress) &&
        token.tokenAddress.toLowerCase() === selectedToken.toLowerCase(),
    )

  let cachedPriceKey2 = null
  let result
  if (
    tokenData &&
    tokenData.tokenAddress &&
    !isArray(tokenData.tokenAddress) &&
    tokenData.priceFunction?.type === GET_PRICE_TYPES.COINGECKO_CONTRACT
  ) {
    const normalizedTokenAddress = tokenData.tokenAddress.toLowerCase()
    cachedPriceKey2 = `tokenPrice${normalizedTokenAddress}${ourChainId}${currency}`
    const cachedPrice2 = cache.get(cachedPriceKey2)

    if (cachedPrice2) {
      return cachedPrice2
    }
  }

  if (tokenData) {
    result = await executePriceFunction(
      tokenData.priceFunction.type,
      tokenData.priceFunction.params,
    )
  } else {
    // first, checking if staking token is an f-token (vault)
    const vaultData =
      !tokens[selectedToken] &&
      toArray(tokens).find(
        token =>
          token.chain === ourChainId &&
          token.vaultAddress &&
          token.vaultAddress.toLowerCase() === selectedToken.toLowerCase(),
      )
    if (vaultData) {
      result = await executePriceFunction(GET_PRICE_TYPES.F_TOKEN, [
        vaultData.vaultAddress,
        vaultData.decimals,
        ourChainId,
      ])
    } else {
      // otherwise, just fallback to CoinGecko
      result = selectedToken.startsWith('0x')
        ? await getTokenPriceByAddress(selectedToken, ourChainId, currency)
        : await getTokenPriceById(selectedToken, ourChainId, currency)
    }
  }

  cache.set(cachedPriceKey1, result)
  if (cachedPriceKey2 && tokenData?.priceFunction?.type === GET_PRICE_TYPES.COINGECKO_CONTRACT) {
    cache.set(cachedPriceKey2, result)
  }
  return result
}

module.exports = {
  getTokenPrice,
  prefetchPriceByAddresses: priceByAddresses,
  prefetchPriceByIds: priceByIds,
}
