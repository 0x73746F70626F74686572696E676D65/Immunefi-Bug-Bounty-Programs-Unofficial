const axios = require('axios')

const BigNumber = require('bignumber.js')
const { getWeb3 } = require('../../lib/web3')
const { getTokenPrice } = require('../../prices')
const { getApy: getMerklApy } = require('../../vaults/apys/implementations/merkl')
const { CHAIN_IDS, FOLD_CHECK_DISCORD_WEBHOOK } = require('../../lib/constants')
const addresses = require('../../../data/mainnet/addresses.json')
const {
  mToken,
  moonwellReward,
  jumpRateModel,
  venusJumpRateModel,
  token,
  moonwellComptroller: comptroller,
  lodestarCToken: cToken,
  lodestarStrategy: strategy,
  venusComptroller,
  venusDistributor,
  lodestarComptroller,
  seamlessPool,
  aToken,
  aaveInterestModel,
  zeroInterestModel,
  aaveRewards,
  controller,
} = require('../../lib/web3/contracts')
const { getCachedContract } = require('../../lib/web3/contractCache')

const platforms = ['moonwell', 'aave', 'zerolend', 'reactor', 'venus']

const rewardReduction = {
  1: 0.85,
  137: 0.92,
  324: 0.9,
  8453: 0.9,
  42161: 0.9,
}

const getMarketDataAave = async (vault, chain) => {
  const web3 = await getWeb3(chain)
  const {
    contract: { abi: poolAbi },
    methods: poolMethods,
  } = seamlessPool
  const {
    contract: { abi: aTokenAbi },
    methods: aTokenMethods,
  } = aToken
  const {
    contract: { abi: aaveInterestAbi },
    methods: aaveInterestMethods,
  } = aaveInterestModel
  const {
    contract: { abi: zeroInterestAbi },
    methods: zeroInterestMethods,
  } = zeroInterestModel
  const {
    contract: { abi: tokenAbi },
    methods: { getDecimals },
  } = token

  const poolInstance = getCachedContract({
    web3,
    abi: poolAbi,
    address: vault.AavePool,
  })
  const assetData = await poolMethods.getReserveData(vault.Underlying, poolInstance)
  const aTokenInstance = getCachedContract({
    web3,
    abi: aTokenAbi,
    address: assetData.aTokenAddress,
  })
  const debtTokenInstance = getCachedContract({
    web3,
    abi: aTokenAbi,
    address: assetData.variableDebtTokenAddress,
  })
  const underlyingPrice = await getTokenPrice(vault.Underlying, chain)
  const underlyingInstance = getCachedContract({
    web3,
    abi: tokenAbi,
    address: vault.Underlying,
  })
  const underlyingDecimals = await getDecimals(underlyingInstance)

  const usdSupplied = new BigNumber(await aTokenMethods.getTotalSupply(aTokenInstance))
    .times(underlyingPrice)
    .div(new BigNumber(10).pow(Number(underlyingDecimals)))
  const totalDebt = new BigNumber(await aTokenMethods.getTotalSupply(debtTokenInstance))
  const usdBorrowed = totalDebt
    .times(underlyingPrice)
    .div(new BigNumber(10).pow(Number(underlyingDecimals)))

  const MASK_16 = (1n << 16n) - 1n // 0xFFFFn
  const config = BigInt(assetData.configuration[0])
  let collateralFactor = new BigNumber(config & MASK_16).div(1e4)
  if (assetData.isolationModeTotalDebt > 0) {
    collateralFactor = new BigNumber(0)
  }
  const reserveFactor = new BigNumber((config >> 64n) & MASK_16).div(1e4)

  let interestParams, interestInstance, interestMethods
  if (vault.platform == 'aave') {
    const virtualBalance = new BigNumber(
      await poolMethods.getVirtualBalance(vault.Underlying, poolInstance),
    )
    interestParams = [
      assetData.unbacked,
      0,
      0,
      totalDebt.toFixed(),
      reserveFactor.times(1e4).toFixed(),
      vault.Underlying,
      true,
      virtualBalance.toFixed(),
    ]
    interestInstance = getCachedContract({
      web3,
      abi: aaveInterestAbi,
      address: assetData.interestRateStrategyAddress,
    })
    interestMethods = aaveInterestMethods
  } else if (vault.platform == 'zerolend') {
    interestParams = [
      assetData.unbacked,
      0,
      0,
      0,
      totalDebt.toFixed(),
      0,
      reserveFactor.times(1e4).toFixed(),
      vault.Underlying,
      assetData.aTokenAddress,
    ]
    interestInstance = getCachedContract({
      web3,
      abi: zeroInterestAbi,
      address: assetData.interestRateStrategyAddress,
    })
    interestMethods = zeroInterestMethods
  }

  const supplied = new BigNumber(await aTokenMethods.balanceOf(vault.NewStrategy, aTokenInstance))
  const borrowed = new BigNumber(
    await aTokenMethods.balanceOf(vault.NewStrategy, debtTokenInstance),
  )
  const invested = supplied.minus(borrowed)
  const usdTVLVault = invested
    .times(underlyingPrice)
    .div(new BigNumber(10).pow(Number(underlyingDecimals)))
  const usdSuppliedVault = supplied
    .times(underlyingPrice)
    .div(new BigNumber(10).pow(Number(underlyingDecimals)))
  const usdBorrowedVault = borrowed
    .times(underlyingPrice)
    .div(new BigNumber(10).pow(Number(underlyingDecimals)))

  const marketData = {
    usdSupplied: usdSupplied,
    usdBorrowed: usdBorrowed,
    collateralFactor: collateralFactor,
  }
  const vaultData = {
    usdSupplied: usdSuppliedVault,
    usdBorrowed: usdBorrowedVault,
    usdTVL: usdTVLVault,
  }
  const interestData = {
    params: interestParams,
    borrows: totalDebt,
    interestInstance: interestInstance,
    interestMethods: interestMethods,
  }
  return [marketData, vaultData, interestData]
}

const getMarketDataCompound = async (vault, chain) => {
  const web3 = await getWeb3(chain)
  const {
    contract: { abi: mTokenAbi },
    methods: mTokenMethods,
  } = mToken
  const {
    contract: { abi: comptrollerAbi },
    methods: comptrollerMethods,
  } = comptroller
  const {
    contract: { abi: tokenAbi },
    methods: { getDecimals },
  } = token

  let mTokenAddress
  if (vault.platform == 'moonwell') {
    mTokenAddress = vault.mToken
  } else {
    mTokenAddress = vault.cToken
  }

  const mTokenInstance = getCachedContract({
    web3,
    abi: mTokenAbi,
    address: mTokenAddress,
  })
  const comptrollerAddr = await mTokenMethods.getComptroller(mTokenInstance)
  const comptrollerInstance = getCachedContract({
    web3,
    abi: comptrollerAbi,
    address: comptrollerAddr,
  })
  const mkt = await comptrollerMethods.getCollateralFactor(mTokenAddress, comptrollerInstance)
  const collateralFactor = new BigNumber(mkt.collateralFactorMantissa).div(
    new BigNumber(10).pow(18),
  )
  const interestRateModel = await mTokenMethods.getInterestRateModel(mTokenInstance)

  let jumprateMethods, interestInstance
  if (vault.platform == 'venus') {
    let {
      contract: { abi: jumpRateAbi },
      methods: interestMethods,
    } = venusJumpRateModel
    jumprateMethods = interestMethods
    interestInstance = getCachedContract({
      web3,
      abi: jumpRateAbi,
      address: interestRateModel,
    })
  } else {
    let {
      contract: { abi: jumpRateAbi },
      methods: interestMethods,
    } = jumpRateModel
    jumprateMethods = interestMethods
    interestInstance = getCachedContract({
      web3,
      abi: jumpRateAbi,
      address: interestRateModel,
    })
  }

  const cash = new BigNumber(await mTokenMethods.getCash(mTokenInstance))
  const borrows = new BigNumber(await mTokenMethods.totalBorrows(mTokenInstance))
  const reserves = new BigNumber(await mTokenMethods.totalReserves(mTokenInstance))
  const reserveFactor = new BigNumber(await mTokenMethods.getReserveFactor(mTokenInstance))

  const underlyingPrice = await getTokenPrice(vault.Underlying, chain)
  const underlyingInstance = getCachedContract({
    web3,
    abi: tokenAbi,
    address: vault.Underlying,
  })
  const underlyingDecimals = await getDecimals(underlyingInstance)

  const usdSupplied = cash
    .plus(borrows)
    .plus(reserves)
    .times(underlyingPrice)
    .div(new BigNumber(10).pow(Number(underlyingDecimals)))
  const usdBorrowed = borrows
    .times(underlyingPrice)
    .div(new BigNumber(10).pow(Number(underlyingDecimals)))

  const snapshot = await mTokenMethods.getAccountSnapshot(vault.NewStrategy, mTokenInstance)
  const supplied = new BigNumber(snapshot[1]).times(snapshot[3]).div(new BigNumber(10).pow(18))
  const borrowed = new BigNumber(snapshot[2])
  const invested = supplied.minus(borrowed)
  const usdTVLVault = invested
    .times(underlyingPrice)
    .div(new BigNumber(10).pow(Number(underlyingDecimals)))
  const usdSuppliedVault = supplied
    .times(underlyingPrice)
    .div(new BigNumber(10).pow(Number(underlyingDecimals)))
  const usdBorrowedVault = borrowed
    .times(underlyingPrice)
    .div(new BigNumber(10).pow(Number(underlyingDecimals)))
  const marketData = {
    usdSupplied: usdSupplied,
    usdBorrowed: usdBorrowed,
    collateralFactor: collateralFactor,
  }
  if (vault.platform == 'venus') {
    const badDebt = new BigNumber(await mTokenMethods.getBadDebt(mTokenInstance))
    marketData.badDebt = badDebt
  }
  const vaultData = {
    usdSupplied: usdSuppliedVault,
    usdBorrowed: usdBorrowedVault,
    usdTVL: usdTVLVault,
  }
  const interestData = {
    cash: cash,
    borrows: borrows,
    reserves: reserves,
    reserveFactor: reserveFactor,
    interestInstance: interestInstance,
    interestMethods: jumprateMethods,
  }
  return [marketData, vaultData, interestData]
}

const getRewardDataMoonwell = async (vault, chain) => {
  const web3 = await getWeb3(chain)
  const {
    contract: { abi: moonwellRewardAbi, address: moonwellRewardAddress },
    methods: moonwellRewardMethods,
  } = moonwellReward
  const {
    contract: { abi: tokenAbi },
    methods: { getDecimals },
  } = token

  const now = Date.now() / 1000
  const timePerYear = new BigNumber(31536000)
  const rewardInstance = getCachedContract({
    web3,
    abi: moonwellRewardAbi,
    address: moonwellRewardAddress.mainnet,
  })
  const rewardConfigs = await moonwellRewardMethods.getAllMarketConfigs(
    vault.mToken,
    rewardInstance,
  )
  let usdRewardSupply = new BigNumber(0)
  let usdRewardBorrow = new BigNumber(0)
  for (const config of rewardConfigs) {
    if (now < config.endTime) {
      const rateSupply = new BigNumber(config.supplyEmissionsPerSec)
      const rateBorrow = new BigNumber(config.borrowEmissionsPerSec)
      const rewardToken = config.emissionToken
      const rewardPrice = await getTokenPrice(rewardToken, chain)
      const rewardTokenInstance = getCachedContract({
        web3,
        abi: tokenAbi,
        address: rewardToken,
      })
      const rewardDecimals = await getDecimals(rewardTokenInstance)
      if (rateSupply.gt(0)) {
        usdRewardSupply = usdRewardSupply.plus(
          rateSupply
            .times(timePerYear)
            .times(rewardPrice)
            .div(new BigNumber(10).pow(Number(rewardDecimals))),
        )
      }
      if (rateBorrow.gt(1)) {
        usdRewardBorrow = usdRewardBorrow.plus(
          rateBorrow
            .times(timePerYear)
            .times(rewardPrice)
            .div(new BigNumber(10).pow(Number(rewardDecimals))),
        )
      }
    }
  }

  return [usdRewardSupply, usdRewardBorrow]
}

const getRewardDataVenus = async (vault, chain) => {
  const web3 = await getWeb3(chain)
  const {
    contract: { abi: cTokenAbi },
    methods: cTokenMethods,
  } = cToken
  const {
    contract: { abi: comptrollerAbi },
    methods: comptrollerMethods,
  } = venusComptroller
  const {
    contract: { abi: distributorAbi },
    methods: distributorMethods,
  } = venusDistributor
  const {
    contract: { abi: tokenAbi },
    methods: { getDecimals },
  } = token

  const timePerYear = new BigNumber(31536000)
  let usdRewardSupply = new BigNumber(0)
  let usdRewardBorrow = new BigNumber(0)

  const cTokenInstance = getCachedContract({
    web3,
    abi: cTokenAbi,
    address: vault.cToken,
  })
  const comptrollerAddress = await cTokenMethods.getComptroller(cTokenInstance)
  const comptrollerInstance = getCachedContract({
    web3,
    abi: comptrollerAbi,
    address: comptrollerAddress,
  })
  const distributors = await comptrollerMethods.getRewardDistributors(comptrollerInstance)

  for (const distributor of distributors) {
    const distributorInstance = getCachedContract({
      web3,
      abi: distributorAbi,
      address: distributor,
    })
    const rewardToken = await distributorMethods.getRewardToken(distributorInstance)
    const rewardPrice = await getTokenPrice(rewardToken, chain)
    const rewardTokenInstance = getCachedContract({
      web3,
      abi: tokenAbi,
      address: rewardToken,
    })
    const rewardDecimals = await getDecimals(rewardTokenInstance)
    const rewardPerYearSupply = new BigNumber(
      await distributorMethods.getSupplyRate(vault.cToken, distributorInstance),
    )
      .times(timePerYear)
      .div(new BigNumber(10).pow(Number(rewardDecimals)))
    const rewardPerYearBorrow = new BigNumber(
      await distributorMethods.getBorrowRate(vault.cToken, distributorInstance),
    )
      .times(timePerYear)
      .div(new BigNumber(10).pow(Number(rewardDecimals)))
    usdRewardSupply = usdRewardSupply.plus(rewardPerYearSupply.times(rewardPrice))
    usdRewardBorrow = usdRewardBorrow.plus(rewardPerYearBorrow.times(rewardPrice))
  }

  return [usdRewardSupply, usdRewardBorrow]
}

const getRewardDataLodestar = async (vault, chain) => {
  const web3 = await getWeb3(chain)
  const {
    contract: { abi: cTokenAbi },
    methods: cTokenMethods,
  } = cToken
  const {
    contract: { abi: comptrollerAbi },
    methods: comptrollerMethods,
  } = lodestarComptroller

  const timePerYear = new BigNumber(2628000)

  const cTokenInstance = getCachedContract({
    web3,
    abi: cTokenAbi,
    address: vault.cToken,
  })
  const comptrollerAddress = await cTokenMethods.getComptroller(cTokenInstance)
  const comptrollerInstance = getCachedContract({
    web3,
    abi: comptrollerAbi,
    address: comptrollerAddress,
  })

  const rewardToken = '0xF19547f9ED24aA66b03c3a552D181Ae334FBb8DB'
  const rewardPrice = await getTokenPrice(rewardToken, chain)
  const usdRewardSupply = new BigNumber(
    await comptrollerMethods.getSupplyRewardRate(vault.cToken, comptrollerInstance),
  )
    .times(timePerYear)
    .times(rewardPrice)
    .div(new BigNumber(10).pow(18))
  const usdRewardBorrow = new BigNumber(
    await comptrollerMethods.getBorrowRewardRate(vault.cToken, comptrollerInstance),
  )
    .times(timePerYear)
    .times(rewardPrice)
    .div(new BigNumber(10).pow(18))

  return [usdRewardSupply, usdRewardBorrow]
}

const getRewardDataAave = async (vault, chain) => {
  const web3 = await getWeb3(chain)
  const {
    contract: { abi: poolAbi },
    methods: poolMethods,
  } = seamlessPool
  const {
    contract: { abi: aTokenAbi },
    methods: aTokenMethods,
  } = aToken
  const {
    contract: { abi: rewardsAbi },
    methods: rewardsMethods,
  } = aaveRewards
  const {
    contract: { abi: tokenAbi },
    methods: { getDecimals },
  } = token

  const timePerYear = new BigNumber(31536000)
  const now = Date.now() / 1000

  const poolInstance = getCachedContract({
    web3,
    abi: poolAbi,
    address: vault.AavePool,
  })
  const assetData = await poolMethods.getReserveData(vault.Underlying, poolInstance)
  const aTokenInstance = getCachedContract({
    web3,
    abi: aTokenAbi,
    address: assetData.aTokenAddress,
  })
  const supplyRewardsInstance = getCachedContract({
    web3,
    abi: rewardsAbi,
    address: await aTokenMethods.getIncentivesController(aTokenInstance),
  })

  const supplyRewardList = await rewardsMethods.getRewardsList(supplyRewardsInstance)
  let usdRewardSupply = new BigNumber(0)
  for (let reward in supplyRewardList) {
    if (supplyRewardList[reward] == '0x9793eac2fECef55248efA039BEC78e82aC01CB2f') {
      continue
    }
    const rewardsData = await rewardsMethods.getRewardsData(
      assetData.aTokenAddress,
      supplyRewardList[reward],
      supplyRewardsInstance,
    )
    if (rewardsData[3] < now) {
      continue
    }
    const rewardPrice = await getTokenPrice(supplyRewardList[reward], chain)
    const rewardTokenInstance = getCachedContract({
      web3,
      abi: tokenAbi,
      address: supplyRewardList[reward],
    })
    const rewardDecimals = await getDecimals(rewardTokenInstance)
    const emissionPerYear = new BigNumber(rewardsData[1])
      .times(timePerYear)
      .div(new BigNumber(10).pow(Number(rewardDecimals)))
    usdRewardSupply = usdRewardSupply.plus(emissionPerYear.times(rewardPrice))
  }

  const debtTokenInstance = getCachedContract({
    web3,
    abi: aTokenAbi,
    address: assetData.variableDebtTokenAddress,
  })
  const borrowRewardsInstance = getCachedContract({
    web3,
    abi: rewardsAbi,
    address: await aTokenMethods.getIncentivesController(debtTokenInstance),
  })

  const borrowRewardList = await rewardsMethods.getRewardsList(borrowRewardsInstance)
  let usdRewardBorrow = new BigNumber(0)
  for (let reward in borrowRewardList) {
    if (borrowRewardList[reward] == '0x9793eac2fECef55248efA039BEC78e82aC01CB2f') {
      continue
    }
    const rewardsData = await rewardsMethods.getRewardsData(
      assetData.variableDebtTokenAddress,
      borrowRewardList[reward],
      borrowRewardsInstance,
    )
    if (rewardsData[3] < now) {
      continue
    }
    const rewardPrice = await getTokenPrice(borrowRewardList[reward], chain)
    const rewardTokenInstance = getCachedContract({
      web3,
      abi: tokenAbi,
      address: borrowRewardList[reward],
    })
    const rewardDecimals = await getDecimals(rewardTokenInstance)
    const emissionPerYear = new BigNumber(rewardsData[1])
      .times(timePerYear)
      .div(new BigNumber(10).pow(Number(rewardDecimals)))
    usdRewardBorrow = usdRewardBorrow.plus(emissionPerYear.times(rewardPrice))
  }

  return [usdRewardSupply, usdRewardBorrow]
}

const getMarketData = async (vault, chain) => {
  let marketData, vaultData, interestData
  if (
    vault.platform == 'moonwell' ||
    vault.platform == 'lodestar' ||
    vault.platform == 'reactor' ||
    vault.platform == 'venus'
  ) {
    ;[marketData, vaultData, interestData] = await getMarketDataCompound(vault, chain)
  } else {
    ;[marketData, vaultData, interestData] = await getMarketDataAave(vault, chain)
  }

  let usdRewardSupply, usdRewardBorrow
  if (vault.platform == 'moonwell') {
    ;[usdRewardSupply, usdRewardBorrow] = await getRewardDataMoonwell(vault, chain)
  } else if (vault.platform == 'venus') {
    ;[usdRewardSupply, usdRewardBorrow] = await getRewardDataVenus(vault, chain)
  } else if (vault.platform == 'lodestar') {
    ;[usdRewardSupply, usdRewardBorrow] = await getRewardDataLodestar(vault, chain)
  } else if (vault.platform == 'aave' || vault.platform == 'zerolend') {
    ;[usdRewardSupply, usdRewardBorrow] = await getRewardDataAave(vault, chain)
  } else {
    usdRewardSupply = new BigNumber(0)
    usdRewardBorrow = new BigNumber(0)
  }

  if (vault.platform == 'aave' || vault.platform == 'zerolend') {
    const web3 = await getWeb3(chain)
    const {
      contract: { abi: poolAbi },
      methods: poolMethods,
    } = seamlessPool
    const poolInstance = getCachedContract({
      web3,
      abi: poolAbi,
      address: vault.AavePool,
    })
    const assetData = await poolMethods.getReserveData(vault.Underlying, poolInstance)
    const merklSupply = new BigNumber(
      await getMerklApy(vault.NewStrategy, assetData.aTokenAddress, chain, 1),
    )
    const merklBorrow = new BigNumber(
      await getMerklApy(vault.NewStrategy, assetData.variableDebtTokenAddress, chain, 1),
    )
    if (merklSupply.gt(0)) {
      usdRewardSupply = usdRewardSupply.plus(merklSupply.times(marketData.usdSupplied).div(100))
    }
    if (merklBorrow.gt(0)) {
      usdRewardBorrow = usdRewardBorrow.plus(merklBorrow.times(marketData.usdBorrowed).div(100))
    }
  } else {
    const merklSupply = new BigNumber(
      await getMerklApy(vault.NewStrategy, vault.mToken ? vault.mToken : vault.cToken, chain, 1),
    )
    if (merklSupply.gt(0) && vault.id != 'moonwell_tBTC') {
      usdRewardSupply = usdRewardSupply.plus(merklSupply.times(marketData.usdSupplied).div(100))
    }
  }

  marketData.usdRewardSupply = usdRewardSupply
  marketData.usdRewardBorrow = usdRewardBorrow

  return [marketData, vaultData, interestData]
}

const getRateCompound = async (
  borrowFactor,
  marketData,
  vaultData,
  interestData,
  chain,
  platform,
) => {
  const newVaultSupplied = vaultData.usdTVL.div(new BigNumber(1).minus(borrowFactor))
  const newVaultBorrowed = newVaultSupplied.minus(vaultData.usdTVL)
  const suppliedMul = newVaultSupplied.div(vaultData.usdTVL)
  const borrowedMul = newVaultBorrowed.div(vaultData.usdTVL)
  const newUsdSupplied = marketData.usdSupplied.minus(vaultData.usdSupplied).plus(newVaultSupplied)
  const newUsdBorrowed = marketData.usdBorrowed.minus(vaultData.usdBorrowed).plus(newVaultBorrowed)
  const newBorrows = interestData.borrows
    .div(marketData.usdBorrowed)
    .times(newUsdBorrowed)
    .integerValue()

  let unitsPerYear
  if (platform == 'lodestar') {
    unitsPerYear = new BigNumber(2628000)
  } else {
    unitsPerYear = new BigNumber(365 * 24 * 60 * 60)
  }
  let newBorrowRate, newSupplyRate
  if (platform == 'venus') {
    newBorrowRate = new BigNumber(
      await interestData.interestMethods.getBorrowRate(
        interestData.cash.toFixed(),
        newBorrows.toFixed(),
        interestData.reserves.toFixed(),
        marketData.badDebt.toFixed(),
        interestData.interestInstance,
      ),
    )
      .times(unitsPerYear)
      .div(1e18)
    newSupplyRate = new BigNumber(
      await interestData.interestMethods.getSupplyRate(
        interestData.cash.toFixed(),
        newBorrows.toFixed(),
        interestData.reserves.toFixed(),
        interestData.reserveFactor.toFixed(),
        marketData.badDebt.toFixed(),
        interestData.interestInstance,
      ),
    )
      .times(unitsPerYear)
      .div(1e18)
  } else {
    newBorrowRate = new BigNumber(
      await interestData.interestMethods.getBorrowRate(
        interestData.cash.toFixed(),
        newBorrows.toFixed(),
        interestData.reserves.toFixed(),
        interestData.interestInstance,
      ),
    )
      .times(unitsPerYear)
      .div(1e18)
    newSupplyRate = new BigNumber(
      await interestData.interestMethods.getSupplyRate(
        interestData.cash.toFixed(),
        newBorrows.toFixed(),
        interestData.reserves.toFixed(),
        interestData.reserveFactor.toFixed(),
        interestData.interestInstance,
      ),
    )
      .times(unitsPerYear)
      .div(1e18)
  }
  const newSupplyReward = marketData.usdRewardSupply
    .div(newUsdSupplied)
    .times(rewardReduction[chain])
  const newBorrowReward = marketData.usdRewardBorrow
    .div(newUsdBorrowed)
    .times(rewardReduction[chain])

  const newRate = suppliedMul
    .times(newSupplyRate.plus(newSupplyReward))
    .minus(borrowedMul.times(newBorrowRate.minus(newBorrowReward)))
  return newRate
}

const getRateAave = async (borrowFactor, marketData, vaultData, interestData, chain, platform) => {
  const newVaultSupplied = vaultData.usdTVL.div(new BigNumber(1).minus(borrowFactor))
  const newVaultBorrowed = newVaultSupplied.minus(vaultData.usdTVL)
  const suppliedMul = newVaultSupplied.div(vaultData.usdTVL)
  const borrowedMul = newVaultBorrowed.div(vaultData.usdTVL)
  const newUsdSupplied = marketData.usdSupplied.minus(vaultData.usdSupplied).plus(newVaultSupplied)
  const newUsdBorrowed = marketData.usdBorrowed.minus(vaultData.usdBorrowed).plus(newVaultBorrowed)
  const newBorrows = interestData.borrows
    .div(marketData.usdBorrowed)
    .times(newUsdBorrowed)
    .integerValue()

  if (platform == 'aave') {
    interestData.params[3] = newBorrows.toFixed()
  } else {
    interestData.params[4] = newBorrows.toFixed()
  }

  const rates = await interestData.interestMethods.getInterestRates(
    interestData.params,
    interestData.interestInstance,
  )

  const newSupplyRate = new BigNumber(rates[0]).div(1e27)
  let newBorrowRate
  if (platform == 'aave') {
    newBorrowRate = new BigNumber(rates[1]).div(1e27)
  } else {
    newBorrowRate = new BigNumber(rates[2]).div(1e27)
  }

  const newSupplyReward = marketData.usdRewardSupply
    .div(newUsdSupplied)
    .times(rewardReduction[chain])
  const newBorrowReward = marketData.usdRewardBorrow
    .div(newUsdBorrowed)
    .times(rewardReduction[chain])

  const newRate = suppliedMul
    .times(newSupplyRate.plus(newSupplyReward))
    .minus(borrowedMul.times(newBorrowRate.minus(newBorrowReward)))
  return newRate
}

const getRate = async (borrowFactor, marketData, vaultData, interestData, chain, platform) => {
  let newRate
  if (
    platform == 'moonwell' ||
    platform == 'lodestar' ||
    platform == 'reactor' ||
    platform == 'venus'
  ) {
    newRate = await getRateCompound(
      borrowFactor,
      marketData,
      vaultData,
      interestData,
      chain,
      platform,
    )
  } else {
    newRate = await getRateAave(borrowFactor, marketData, vaultData, interestData, chain, platform)
  }
  return newRate
}

const checkFoldingLeverage = async () => {
  console.log('\n-- Running leverage checks for Folding strategies --')

  for (const chain of Object.keys(CHAIN_IDS)) {
    if (chain == 'ZKSYNC') continue
    console.log(`\n-- Chain: ${chain} --`)

    let chainAddresses, controllerAddress
    if (chain == 'ETH') {
      chainAddresses = addresses.V2
      controllerAddress = addresses.Controller
    } else if (chain == 'POLYGON') {
      chainAddresses = addresses.MATIC.V2
      controllerAddress = addresses.MATIC.Controller
    } else {
      chainAddresses = addresses[chain].V2
      controllerAddress = addresses[chain].Controller
    }
    let filteredAddresses = []
    for (const vault in chainAddresses) {
      let include = false
      for (let platform of platforms) {
        if (vault.toLowerCase().includes(platform) && !vault.toLowerCase().includes('hodl')) {
          if (
            vault != 'lodestar_LODE' &&
            !vault.toLowerCase().includes('moonwellloop') &&
            chainAddresses[vault].doHardwork != false
          ) {
            console.log(`Including vault: ${vault} on platform: ${platform}`)
            include = true
            chainAddresses[vault].platform = platform
            chainAddresses[vault].id = vault
            if (vault == 'lodestar_ARB') {
              chainAddresses[vault].platform = 'venus'
            }
          }
          break
        }
      }
      if (include) {
        filteredAddresses.push(chainAddresses[vault])
      }
    }

    for (const vault of filteredAddresses) {
      const {
        contract: { abi: strategyAbi },
        methods: strategyMethods,
      } = strategy
      const {
        contract: { abi: controllerAbi },
      } = controller
      const web3 = await getWeb3(CHAIN_IDS[chain])
      const strategyInstance = getCachedContract({
        web3,
        abi: strategyAbi,
        address: vault.NewStrategy,
      })
      const controllerInstance = getCachedContract({
        web3,
        abi: controllerAbi,
        address: controllerAddress,
      })
      try {
        await strategyMethods.fold(strategyInstance)
      } catch (e) {
        continue
      }

      let [marketData, vaultData, interestData] = await getMarketData(vault, CHAIN_IDS[chain])
      if (marketData.collateralFactor.eq(0)) {
        continue
      }
      if (vaultData.usdTVL.eq(0)) {
        continue
      }
      const maxBorrowFactor = marketData.collateralFactor.minus(0.02)
      const currentBorrowFactor = vaultData.usdBorrowed.div(vaultData.usdSupplied)
      const currentRate = await getRate(
        currentBorrowFactor,
        marketData,
        vaultData,
        interestData,
        CHAIN_IDS[chain],
        vault.platform,
      )

      const rateZero = await getRate(
        new BigNumber(0),
        marketData,
        vaultData,
        interestData,
        CHAIN_IDS[chain],
        vault.platform,
      )
      const rateMid = await getRate(
        maxBorrowFactor.div(2),
        marketData,
        vaultData,
        interestData,
        CHAIN_IDS[chain],
        vault.platform,
      )
      const rateMax = await getRate(
        maxBorrowFactor,
        marketData,
        vaultData,
        interestData,
        CHAIN_IDS[chain],
        vault.platform,
      )

      let optimalFactor, optimalRate
      if (rateZero.gt(rateMid) && rateZero.gt(rateMax)) {
        let oldRate = rateZero
        let oldFactor = new BigNumber(0)
        let newFactor = oldFactor.plus(0.01)
        let newRate = await getRate(
          newFactor,
          marketData,
          vaultData,
          interestData,
          CHAIN_IDS[chain],
          vault.platform,
        )
        while (newRate.gt(oldRate)) {
          oldRate = newRate
          oldFactor = newFactor
          newFactor = oldFactor.plus(0.01)
          newRate = await getRate(
            newFactor,
            marketData,
            vaultData,
            interestData,
            CHAIN_IDS[chain],
            vault.platform,
          )
        }
        optimalFactor = oldFactor
        optimalRate = oldRate
      } else if (rateMid.gt(rateZero) && rateMid.gt(rateMax)) {
        let low = new BigNumber(0)
        let high = new BigNumber(0)
        let rateLow = new BigNumber(0)
        let rateHigh = new BigNumber(0)
        for (let i = 0; i < 16; i++) {
          const factor = maxBorrowFactor.div(15).times(i)
          const rate = await getRate(
            factor,
            marketData,
            vaultData,
            interestData,
            CHAIN_IDS[chain],
            vault.platform,
          )
          if (rateLow.eq(0)) {
            low = factor
            rateLow = rate
          } else if (rateHigh.eq(0)) {
            high = factor
            rateHigh = rate
          } else if (rate.gt(rateHigh) || rate.gt(rateLow)) {
            low = high
            rateLow = rateHigh
            high = factor
            rateHigh = rate
          }
        }
        while (rateHigh.minus(rateLow).absoluteValue().gt(0.00001)) {
          let mid = low.plus(high).div(2)
          const newRate = await getRate(
            mid,
            marketData,
            vaultData,
            interestData,
            CHAIN_IDS[chain],
            vault.platform,
          )
          if (newRate.gt(rateLow)) {
            low = mid
            rateLow = newRate
          } else {
            high = mid
            rateHigh = newRate
          }
        }
        optimalFactor = low
        optimalRate = rateLow
      } else if (rateMax.gt(rateZero) && rateMax.gt(rateMid)) {
        optimalFactor = maxBorrowFactor
        optimalRate = rateMax
      }

      if (
        optimalRate.gte(currentRate.plus(0.001)) &&
        optimalFactor.minus(currentBorrowFactor).absoluteValue().gt(0.001)
      ) {
        const txs = []
        txs.push({
          to: vault.NewStrategy,
          data: strategyInstance.methods
            .setBorrowTargetFactorNumerator(optimalFactor.times(1000).toFixed(0))
            .encodeABI(),
        })
        if (optimalFactor.gt(0) && !(await strategyMethods.fold(strategyInstance))) {
          txs.push({
            to: vault.NewStrategy,
            data: strategyInstance.methods.setFold(true).encodeABI(),
          })
        }
        txs.push({
          to: controllerAddress,
          data: controllerInstance.methods.doHardWork(vault.NewVault).encodeABI(),
        })
        if (optimalFactor.eq(0) && (await strategyMethods.fold(strategyInstance))) {
          txs.push({
            to: vault.NewStrategy,
            data: strategyInstance.methods.setFold(false).encodeABI(),
          })
        }
        let msg = `${chain}: ${vault.id} \nCurrent Borrow Factor: ${currentBorrowFactor.toFixed(
          4,
        )} Current Rate: ${currentRate
          .times(100)
          .toFixed(2)}% \nOptimal Borrow Factor: ${optimalFactor.toFixed(
          4,
        )} Optimal Rate: ${optimalRate
          .times(100)
          .toFixed(2)}% \nVault TVL: ${vaultData.usdTVL.toFixed(2)} \nTransactions: \n`
        for (const tx of txs) {
          msg += `{to: ${tx.to}, data: ${tx.data}} \n`
        }
        console.log(
          '---------------------------> Leverage NOT optimal <---------------------------',
        )
        if (FOLD_CHECK_DISCORD_WEBHOOK) {
          console.log('Sending Discord message for:', vault.id)
          const green = 5763719
          const yellow = 16705372
          const red = 15548997
          let color
          if (currentRate.lt(0)) {
            color = red
          } else if (optimalRate.minus(currentRate).gt(0.02) && vaultData.usdTVL.gt(10000)) {
            color = yellow
          } else {
            color = green
          }
          await axios.post(
            FOLD_CHECK_DISCORD_WEBHOOK,
            { embeds: [{ description: msg, color: color }] },
            { headers: { 'Content-Type': 'application/json' } },
          )
        } else {
          console.log('No Discord webhook provided, msg:')
          console.log(msg)
        }
        console.log('---')
      }
    }
  }

  console.log('-- Done running leverage checks for Folding strategies --\n')
}

module.exports = {
  checkFoldingLeverage,
}
