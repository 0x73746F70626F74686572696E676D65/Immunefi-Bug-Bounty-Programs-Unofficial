require('dotenv').config()
const { UI_DATA_FILES, DB_CACHE_IDS } = require('../../src/lib/constants')
const initDb = require('../../src/lib/db')
const { fetchAndExpandVault } = require('../../src/vaults')
const { fetchAndExpandIPORVault } = require('../../src/vaults/ipor')
const { fetchAndExpandPool } = require('../../src/pools')
const { cliPreload } = require('../../src/runtime/pollers')
const { getUIData } = require('../../src/lib/data')
const { Cache } = require('../../src/lib/db/models/cache')

const main = async () => {
  const vaultId = process.argv[2]

  console.log('vault/pool:', vaultId)

  await initDb()
  await cliPreload()
  const tokens = await getUIData(UI_DATA_FILES.TOKENS)
  const pools = await getUIData(UI_DATA_FILES.POOLS)
  const poolsDoc = await Cache.collection.findOne({ type: DB_CACHE_IDS.POOLS })
  const statsDoc = await Cache.collection.findOne({ type: DB_CACHE_IDS.STATS })
  let vault = null

  try {
    console.log('====================')
    console.log('fetching vault...')
    if (!tokens[vaultId]) {
      console.log(`Vault: ${vaultId} does not exist. Is casing correct?`)
    } else {
      if (Object.prototype.hasOwnProperty.call(tokens[vaultId], 'isIPORVault'))
        vault = await fetchAndExpandIPORVault(vaultId, tokens)
      else vault = await fetchAndExpandVault(vaultId, poolsDoc, statsDoc, tokens, pools)
      console.log(vault)
    }
  } catch (err) {
    console.log(`Error getting vault ${vaultId}:`, err)
  }

  try {
    console.log('fetching pool...')
    const poolToFetch = pools.find(
      pool =>
        pool.id === vaultId ||
        (pool.collateralAddress &&
          tokens[vaultId] &&
          (!vault || tokens[vaultId].chain === pool.chain) &&
          tokens[vaultId].vaultAddress &&
          !Object.prototype.hasOwnProperty.call(tokens[vaultId], 'isIPORVault') &&
          pool.collateralAddress.toLowerCase() === tokens[vaultId].vaultAddress.toLowerCase()),
    )
    if (poolToFetch) {
      const pool = await fetchAndExpandPool(poolToFetch, poolsDoc, statsDoc, tokens)
      console.log('====================')
      console.log(pool)
    }
  } catch (err) {
    console.log(`Error getting pool ${vaultId}`, err)
  }
}

main()
  .then(() => process.exit(0))
  .catch(error => {
    console.error(error)
    process.exit(1)
  })
