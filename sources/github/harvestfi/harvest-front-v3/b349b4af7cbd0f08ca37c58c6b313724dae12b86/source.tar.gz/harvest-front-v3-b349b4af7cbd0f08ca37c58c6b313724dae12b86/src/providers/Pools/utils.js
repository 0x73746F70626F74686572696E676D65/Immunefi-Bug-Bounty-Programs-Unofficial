import BigNumber from 'bignumber.js'
import equal from 'fast-deep-equal/react'
import { get } from 'lodash'
import { forEach } from 'promised-loops'
import { POLL_POOL_USER_DATA_INTERVAL_MS } from '../../constants'
import { newContractInstance } from '../../services/viem'
import poolMethods from '../../services/viem/contracts/pool/methods'
import tokenContract from '../../services/viem/contracts/token/contract.json'
import tokenMethods from '../../services/viem/contracts/token/methods'

const { pools, tokens } = require('../../data')

export const calculateTotalRewardsEarned = async (account, contractInstance) => {
  const { totalEarned: earned } = poolMethods

  let totalEarned = '0'

  if (account) {
    totalEarned = await earned(account, contractInstance)
  }

  return totalEarned
}

export const calculateRewardsEarned = async (rewardAddress, account, contractInstance) => {
  const { earned } = poolMethods

  let totalEarned = '0'

  if (account) {
    totalEarned = await earned(rewardAddress, account, contractInstance)
  }

  return totalEarned
}

export const getTotalStaked = async (account, contractInstance) => {
  const { balanceOf } = poolMethods

  if (account) {
    const fetchedBalance = await balanceOf(account, contractInstance)

    return fetchedBalance
  }

  return '0'
}

export const getLpTokenData = async (poolInstance, viemProvider) => {
  const { lpToken } = poolMethods

  const { abi: tokenAbi } = tokenContract
  const { getDecimals, getSymbol } = tokenMethods

  const lpAddress = await lpToken(poolInstance)
  const lpInstance = await newContractInstance(null, lpAddress, tokenAbi, viemProvider)

  const lpDecimals = await getDecimals(lpInstance)
  const lpSymbol = await getSymbol(lpInstance)

  return {
    address: lpAddress,
    decimals: lpDecimals,
    symbol: lpSymbol,
  }
}

export const getUserStats = async (
  poolContractInstance,
  lpTokenContractInstance,
  poolContractAddress,
  autoStakePoolAddress,
  account,
  autoStakeContractInstance,
  isIPOR = false,
) => {
  let lpTokenBalance = '0',
    lpTokenApprovedBalance = '0',
    totalStaked = '0',
    totalRewardsEarned = '0'

  const rewardsEarned = {}

  if (account) {
    totalStaked = await getTotalStaked(account, autoStakeContractInstance || poolContractInstance)

    if (!isIPOR) {
      const rewardTokenSymbols = get(
        pools.find(pool => pool.contractAddress === poolContractAddress),
        'rewardTokenSymbols',
        [],
      )

      const rewardTokens = get(
        pools.find(pool => pool.contractAddress === poolContractAddress),
        'rewardTokens',
        [],
      )

      if (rewardTokenSymbols.length > 1) {
        totalRewardsEarned = new BigNumber(0)

        await forEach(rewardTokenSymbols, async (symbol, index) => {
          let rewardAddress = ''
          try {
            rewardAddress = rewardTokens[index] || tokens[symbol].tokenAddress
          } catch (err) {
            console.log('rewardSymbol: ', rewardTokenSymbols, symbol)
          }

          rewardsEarned[symbol] =
            rewardAddress !== ''
              ? await calculateRewardsEarned(rewardAddress, account, poolContractInstance)
              : '0'
          totalRewardsEarned = totalRewardsEarned.plus(new BigNumber(rewardsEarned[symbol]))
        })

        totalRewardsEarned = totalRewardsEarned.toFixed()
      } else {
        totalRewardsEarned = await calculateTotalRewardsEarned(account, poolContractInstance)
      }

      lpTokenBalance = await tokenMethods.getBalance(account, lpTokenContractInstance)
      lpTokenApprovedBalance = await tokenMethods.getApprovedAmount(
        account,
        autoStakePoolAddress || poolContractAddress,
        lpTokenContractInstance,
      )
    }
  }

  return {
    lpTokenBalance,
    lpTokenApprovedBalance,
    totalStaked,
    totalRewardsEarned,
    rewardsEarned,
  }
}

export const pollUpdatedUserStats = (method, currStats, onTimeout, onSuccess, maxRetries = 2) =>
  new Promise((resolve, reject) => {
    let retries = 0
    const pollStats = setInterval(() => {
      if (retries >= maxRetries) {
        clearInterval(pollStats)
        resolve(onTimeout())
      }

      retries += 1

      method
        .then(fetchedStats => {
          if (!equal(fetchedStats, currStats)) {
            resolve(onSuccess(fetchedStats))
            clearInterval(pollStats)
          }
        })
        .catch(err => {
          console.error(err)
          reject(err)
        })
    }, POLL_POOL_USER_DATA_INTERVAL_MS)
  })
