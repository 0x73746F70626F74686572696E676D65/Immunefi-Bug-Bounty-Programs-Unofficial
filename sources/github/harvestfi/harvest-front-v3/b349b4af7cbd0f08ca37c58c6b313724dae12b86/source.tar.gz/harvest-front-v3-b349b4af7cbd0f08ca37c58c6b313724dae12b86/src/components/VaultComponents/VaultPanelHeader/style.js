import styled from 'styled-components'
import { Modal } from 'react-bootstrap'

const PanelContainer = styled.a`
  display: flex;
  justify-content: start;
  align-items: center;
  padding: 16px 24px;
  border-bottom: 1px solid ${props => props.$bordercolor};
  cursor: pointer;
  color: ${props => props.$fontcolor};
  text-decoration: none;

  &:hover {
    color: ${props => props.$fontcolor};
  }

  @media screen and (max-width: 992px) {
    flex-direction: row;
    align-items: baseline;
    position: relative;
    padding: 10px 25px;
    justify-content: space-between;
  }
`

const TokenLogo = styled.img`
  max-width: 30px;
  float: left;

  @media screen and (max-width: 992px) {
    margin-left: 0;
  }
`

const TokenNameContainer = styled.div`
  display: flex;
  align-items: center;
  font-weight: 600;
  font-size: 14px;
  line-height: 20px;
  color: ${props => props.$fontcolor1};

  @media screen and (max-width: 1480px) {
    font-size: 12px;
    line-height: 16px;
    margin-bottom: 10px;
  }
  @media screen and (max-width: 992px) {
    font-size: 11px;
    margin-bottom: 8px;
  }
`

const TokenDescriptionContainer = styled.div`
  display: flex;
  flex-direction: column;
  font-size: 14px;

  small {
    font-size: 14px;
  }

  @media screen and (max-width: 1480px) {
    font-weight: 400;
    font-size: 10px;
    line-height: 13px;
  }
  @media screen and (max-width: 992px) {
    font-size: 11px;
  }
`

const RewardsContainer = styled.div`
  display: flex;
  justify-content: flex-start;
  align-items: center;
  color: ${props => props.$fontcolor1};
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;

  span {
    font-size: 20px;

    @media screen and (max-width: 1480px) {
      font-size: 16px;
    }
  }

  b {
    display: flex;
    justify-content: center;
    align-items: center;
  }

  div.boost-apy {
    font-weight: 600;
    display: flex;

    div.boost-img {
      margin: auto 0px auto 5px;

      img {
        width: 16px;
        margin-top: -2px;

        @media screen and (max-width: 992px) {
          margin-top: -4px;
        }
      }
    }
  }
`

const ValueContainer = styled.div`
  font-weight: 500;
  width: ${props => props.$width || 'auto'};
  text-align: ${props => props.$textalign || 'center'};
  display: flex;
  justify-content: start;
  align-items: center;
  ${props => (props.$textalign === 'left' ? `justify-content: start;` : '')}
  padding-right: ${props => props.$paddingright || '0px'};
  padding-left: ${props => props.$paddingleft || '0px'};
  position: relative;

  .tag {
    display: none;
    position: absolute;
    left: 53px;
    top: 31px;
  }

  ${props =>
    props.$position
      ? `
    position: ${props.$position};
  `
      : ''}
`

const LogoImg = styled.img`
  z-index: 10;
  width: 30px;
  height: 30px;
  &:not(:first-child) {
    margin-left: -7px;
    ${props =>
      props.$zindex
        ? `
      z-index: ${props.$zindex};
    `
        : ``};
  }

  @media screen and (max-width: 1480px) {
    width: 25px;
    height: 25px;
  }
`

const BadgeIcon = styled.div`
  position: absolute;
  top: 50%;
  left: -50%;
  transform: translateY(-50%);
  width: 23px;
  height: 23px;
  display: flex;
  justify-content: center;
  align-items: center;

  img {
    width: 16px;
    height: 16px;
  }

  @media screen and (max-width: 992px) {
    position: inherit;
    border: none;
    width: 13.096px;
    height: 13.096px;
    margin: auto 5px auto 0px;
    transform: none;
    top: auto;
    left: auto;
    img {
      padding: 1.708px 1.706px 1.709px 1.71px;
      width: 13px;
      height: 13px;
    }
  }
`

const TokenLogoContainer = styled.div`
  width: ${props => (props.$width ? props.$width : 'auto')};
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-weight: bold;
  margin-right: 5px;
  text-align: left;
  position: relative;

  @media screen and (max-width: 992px) {
    margin-top: 8px;
  }
`

const TooltipText = styled.div`
  font-weight: normal;
  width: ${props => props.$width || 'auto'};
  text-align: ${props => props.$textalign || 'unset'};
`

const NewBadge = styled.img`
  position: absolute;
  top: -4px;
  left: -4px;
  width: 35px;
  height: 35px;
`

const AdditionalBadge = styled.img`
  width: 20px;
  height: 20px;
  margin-left: 5px;
`

const ArrowContainer = styled.div`
  padding: 0px 5.4px;
  background: ${props => (props.$open ? '#f2b435' : '#FFFCE6')};
  border-radius: 4px;
  margin-right: 5px;

  svg {
    width: 9px;
    height: 9px;
    transition: 0.25s;
    transform: ${props => (props.$open ? 'rotate(-180deg)' : 'unset')};

    path {
      fill: ${props => (props.$open ? '#4C351B' : '#F2B435')};
    }
  }
`

const MobileVaultInfoContainer = styled.div`
  display: flex;
  flex-flow: column;
  justify-content: space-between;
  flex-wrap: wrap;
  width: 100%;
  align-items: end;
  gap: 4px;
`

const MobileVaultValueContainer = styled.div`
  display: flex;
  justify-content: end;
  align-items: baseline;
  line-height: 2;
  font-size: 11px;

  * {
    font-size: 11px !important;
  }

  div {
    font-weight: bold;
  }

  img {
    width: 12px;
    height: 12px;
  }

  .title {
    img {
      margin-left: 7px;
      margin-top: -2px;
      filter: ${props => props.$filtercolor};
    }
  }
`

const ApyInfo = styled.img`
  margin-top: 4px;
  width: 15px;
  height: 15px;
`

const FlexDiv = styled.div`
  ${props =>
    props.$alignself
      ? `
    align-self: ${props.$alignself};
  `
      : ''}
  ${props =>
    props.$paddingbottom
      ? `
        padding-bottom: ${props.$paddingbottom};
      `
      : ''}
  ${props =>
    props.$width
      ? `
    width: ${props.$width};
  `
      : 'width: auto;'}
  ${props =>
    props.$marginright
      ? `
    margin-right: ${props.$marginright};
  `
      : ''}

  .tag {
    display: none;
    position: absolute;
    left: 6px;
  }
  &.token-icons {
    display: flex;
    margin: auto 0px auto 5px;
    img {
      position: relative;
    }
  }
  &.token-symbols {
    img {
      margin-left: -4px;
    }
    img:first-child {
      margin-left: 0px;
    }
  }
`

const DetailModal = styled(Modal)`
  display: none;
  position: relative;

  @media screen and (max-width: 992px) {
    .modal-dialog {
      width: -webkit-fill-available;
      position: absolute;
      bottom: 0;
      margin: 0;
      .modal-content {
        border-radius: 20px 20px 0 0;
      }
    }
  }

  @media (min-width: 576px) {
    .modal-dialog {
      max-width: unset;
    }
  }
`
const Value = styled.div`
  color: ${props => props.$fontcolor1};
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
`

const BadgePlatform = styled.div`
  display: flex;
  justify-content: space-between;
  width: fit-content;
`

const Autopilot = styled.div`
  display: flex;
  flex-flow: row;
  border-radius: 13px;
  justify-content: space-between;
  align-items: center;
  background: #ecfdf3;
  color: #5dcf46;
  padding: 3px 10px;
  gap: 5px;

  @media screen and (max-width: 1400px) {
    padding: 2px 8px;
    gap: 4px;
  }

  @media screen and (max-width: 992px) {
    padding: 2px 6px;
    gap: 3px;
  }
`

const NewLabel = styled.div`
  font-size: 10px;
  font-weight: 500;
  line-height: 15px;

  @media screen and (max-width: 1600px) {
    font-size: 9px;
    line-height: 13px;
  }

  @media screen and (max-width: 992px) {
    font-size: 8px;
    line-height: 12px;
  }
`

const BadgeRow = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 8px;

  @media screen and (max-width: 1600px) {
    flex-direction: column;
    align-items: flex-start;
    gap: 4px;
  }

  @media screen and (max-width: 992px) {
    flex-direction: row;
    align-items: center;
    gap: 6px;
  }
`

const MorphoBadge = styled.div`
  display: flex;
  flex-flow: row;
  border-radius: 13px;
  justify-content: space-between;
  align-items: center;
  background: #f0f4ff;
  color: #3b82f6;
  padding: 3px 10px;
  gap: 5px;

  .question {
    font-size: 12px;
    cursor: pointer;
    color: #475467;
  }

  @media screen and (max-width: 1600px) {
    padding: 2px 8px;
    gap: 4px;

    .question {
      font-size: 12px;
    }
  }

  @media screen and (max-width: 992px) {
    padding: 2px 6px;
    gap: 3px;

    .question {
      font-size: 12px;
    }
  }
`

export {
  PanelContainer,
  BadgePlatform,
  TokenLogo,
  RewardsContainer,
  TokenLogoContainer,
  ValueContainer,
  NewBadge,
  AdditionalBadge,
  TooltipText,
  ArrowContainer,
  TokenNameContainer,
  MobileVaultInfoContainer,
  MobileVaultValueContainer,
  TokenDescriptionContainer,
  ApyInfo,
  BadgeIcon,
  FlexDiv,
  DetailModal,
  Value,
  LogoImg,
  Autopilot,
  NewLabel,
  MorphoBadge,
  BadgeRow,
}
