import { isArray } from 'lodash'
import TokenContract from './token-copy/contract.json'
import TokenMethods from './token-copy/methods'

import DepositHelperContract from './deposit-helper/contract.json'
import DepositHelperMethods from './deposit-helper/methods'

import UniswapContract from './uniswap/contract.json'
import UniswapMethods from './uniswap/methods'

import ReaderEthContract from './reader-eth/contract.json'
import ReaderEthMethods from './reader-eth/methods'

import ReaderMaticContract from './reader-matic/contract.json'
import ReaderMaticMethods from './reader-matic/methods'

import ReaderArbitrumContract from './reader-arbitrum/contract.json'
import ReaderArbitrumMethods from './reader-arbitrum/methods'

import ReaderBaseContract from './reader-base/contract.json'
import ReaderBaseMethods from './reader-base/methods'

import ReaderZksyncContract from './reader-zksync/contract.json'
import ReaderZksyncMethods from './reader-zksync/methods'

import ReaderHyperevmContract from './reader-hyperevm/contract.json'
import ReaderHyperevmMethods from './reader-hyperevm/methods'

import IporVaultContract from './ipor-vault/contract.json'
import IporVaultMethods from './ipor-vault/methods'

import ClVaultContract from './cl-vault/contract.json'
import ClVaultMethods from './cl-vault/methods'

import ClWrapperContract from './cl-wrapper/contract.json'
import ClWrapperMethods from './cl-wrapper/methods'

import LoopVaultContract from './loop-vault/contract.json'
import LoopVaultMethods from './loop-vault/methods'

import AavePoolContract from './aave-pool/contract.json'
import AavePoolMethods from './aave-pool/methods'

import AaveViewerContract from './aave-viewer/contract.json'
import AaveViewerMethods from './aave-viewer/methods'

import LoopStrategyContract from './loop-strategy/contract.json'
import LoopStrategyMethods from './loop-strategy/methods'

import { CHAIN_IDS } from '../../../data/constants'

const { tokens } = require('../../../data')

const getTokensContracts = () => {
  const tokenContracts = {}
  Object.keys(tokens).forEach(token => {
    if (!isArray(tokens[token].tokenAddress)) {
      tokenContracts[token] = {
        contract: {
          address: token == 'IFARM' ? tokens[token].vaultAddress : tokens[token].tokenAddress,
          abi: TokenContract.abi,
        },
        methods: TokenMethods,
        chain: tokens[token].chain,
      }
    }
  })

  return tokenContracts
}

const getIPORVaultContracts = () => {
  const iporVaultContracts = {}
  Object.keys(tokens).forEach(token => {
    if (tokens[token].isIPORVault) {
      iporVaultContracts[token] = {
        contract: {
          address: tokens[token].vaultAddress,
          abi: IporVaultContract.abi,
        },
        methods: IporVaultMethods,
        chain: tokens[token].chain,
      }
    }
  })

  return {
    iporVaults: iporVaultContracts,
  }
}

export default {
  depositHelper: {
    contract: DepositHelperContract,
    methods: DepositHelperMethods,
    chain: CHAIN_IDS.ETH_MAINNET,
  },
  uniswap: {
    contract: UniswapContract,
    methods: UniswapMethods,
    chain: CHAIN_IDS.ETH_MAINNET,
  },
  readerEth: {
    contract: ReaderEthContract,
    methods: ReaderEthMethods,
    chain: CHAIN_IDS.ETH_MAINNET,
  },

  readerMatic: {
    contract: ReaderMaticContract,
    methods: ReaderMaticMethods,
    chain: CHAIN_IDS.POLYGON_MAINNET,
  },

  readerArbitrum: {
    contract: ReaderArbitrumContract,
    methods: ReaderArbitrumMethods,
    chain: CHAIN_IDS.ARBITRUM_ONE,
  },

  readerBase: {
    contract: ReaderBaseContract,
    methods: ReaderBaseMethods,
    chain: CHAIN_IDS.BASE,
  },

  readerZksync: {
    contract: ReaderZksyncContract,
    methods: ReaderZksyncMethods,
    chain: CHAIN_IDS.ZKSYNC,
  },

  readerHyperevm: {
    contract: ReaderHyperevmContract,
    methods: ReaderHyperevmMethods,
    chain: CHAIN_IDS.HYPEREVM,
  },

  clVault: {
    contract: ClVaultContract,
    methods: ClVaultMethods,
    chain: CHAIN_IDS.BASE,
  },

  clWrapper: {
    contract: ClWrapperContract,
    methods: ClWrapperMethods,
    chain: CHAIN_IDS.BASE,
  },

  loopVault: {
    contract: LoopVaultContract,
    methods: LoopVaultMethods,
    chain: CHAIN_IDS.BASE,
  },

  aavePool: {
    contract: AavePoolContract,
    methods: AavePoolMethods,
    chain: CHAIN_IDS.BASE,
  },

  aaveViewer: {
    contract: AaveViewerContract,
    methods: AaveViewerMethods,
    chain: CHAIN_IDS.BASE,
  },

  loopStrategy: {
    contract: LoopStrategyContract,
    methods: LoopStrategyMethods,
    chain: CHAIN_IDS.BASE,
  },

  ...getTokensContracts(),
  ...getIPORVaultContracts(),
}
