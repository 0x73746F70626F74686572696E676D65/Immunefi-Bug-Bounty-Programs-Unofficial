// SPDX-License-Identifier: Apache-2.0
//
// Copyright (c) 2023 Berachain Foundation
//
// Permission is hereby granted, free of charge, to any person
// obtaining a copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including without limitation the rights to use,
// copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following
// conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
// HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
// WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.

package debug_test

import (
	"testing"

	"pkg.berachain.dev/polaris/lib/errors/debug"

	. "github.com/onsi/ginkgo/v2"
	. "github.com/onsi/gomega"
)

func TestDebug(t *testing.T) {
	RegisterFailHandler(Fail)
	RunSpecs(t, "lib/errors/debug")
}

func Hello() error {
	return nil
}

type GoodBye struct{}

func (g GoodBye) GoodBye() error {
	return nil
}

func (g *GoodBye) GoodByePtr() error {
	return nil
}

type GoodBye2 struct{}

func (g GoodBye2) GoodBye2() error {
	return nil
}

var _ = Describe("TestFnName", func() {
	It("should return the name of the function", func() {
		Expect(debug.GetFnName(Hello)).Should(Equal("Hello"))
	})

	It("should return the name of the function for struct functions", func() {
		gb := GoodBye{}
		Expect(debug.GetFnName(gb.GoodBye)).Should(Equal("GoodBye"))
		Expect(debug.GetFnName(gb.GoodByePtr)).Should(Equal("GoodByePtr"))
		Expect(debug.GetFnName(GoodBye2{}.GoodBye2)).Should(Equal("GoodBye2"))
	})
})
