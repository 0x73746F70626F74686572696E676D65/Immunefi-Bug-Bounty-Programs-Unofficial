// SPDX-License-Identifier: BUSL-1.1
//
// Copyright (C) 2023, Berachain Foundation. All rights reserved.
// Use of this software is govered by the Business Source License included
// in the LICENSE file of this repository and at www.mariadb.com/bsl11.
//
// ANY USE OF THE LICENSED WORK IN VIOLATION OF THIS LICENSE WILL AUTOMATICALLY
// TERMINATE YOUR RIGHTS UNDER THIS LICENSE FOR THE CURRENT AND ALL OTHER
// VERSIONS OF THE LICENSED WORK.
//
// THIS LICENSE DOES NOT GRANT YOU ANY RIGHT IN ANY TRADEMARK OR LOGO OF
// LICENSOR OR ITS AFFILIATES (PROVIDED THAT YOU MAY USE A TRADEMARK OR LOGO OF
// LICENSOR AS EXPRESSLY REQUIRED BY THIS LICENSE).
//
// TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE LICENSED WORK IS PROVIDED ON
// AN “AS IS” BASIS. LICENSOR HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS,
// EXPRESS OR IMPLIED, INCLUDING (WITHOUT LIMITATION) WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT, AND
// TITLE.

package vm

import (
	"github.com/ethereum/go-ethereum/core/vm"
)

type (
	AccountRef          = vm.AccountRef
	BlockContext        = vm.BlockContext
	CanTransferFunc     = vm.CanTransferFunc
	ContractRef         = vm.ContractRef
	Config              = vm.Config
	EVMLogger           = vm.EVMLogger
	GethEVM             = vm.EVM
	GethStateDB         = vm.StateDB
	GetHashFunc         = vm.GetHashFunc
	PrecompileContainer = vm.PrecompiledContract
	PrecompileManager   = vm.PrecompileManager
	PrecompileEVM       = vm.PrecompileEVM
	TransferFunc        = vm.TransferFunc
	TxContext           = vm.TxContext
)

var (
	NewGethEVMWithPrecompiles     = vm.NewEVMWithPrecompiles
	ErrOutOfGas                   = vm.ErrOutOfGas
	ErrExecutionReverted          = vm.ErrExecutionReverted
	ErrWriteProtection            = vm.ErrWriteProtection
	PrecompiledContractsBerlin    = vm.PrecompiledContractsBerlin
	PrecompiledContractsByzantium = vm.PrecompiledContractsByzantium
	PrecompiledContractsHomestead = vm.PrecompiledContractsHomestead
	PrecompiledContractsIstanbul  = vm.PrecompiledContractsIstanbul
)
