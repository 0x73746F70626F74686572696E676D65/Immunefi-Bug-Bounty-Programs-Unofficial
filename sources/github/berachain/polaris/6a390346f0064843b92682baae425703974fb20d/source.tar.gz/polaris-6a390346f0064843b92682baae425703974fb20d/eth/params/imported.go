// SPDX-License-Identifier: BUSL-1.1
//
// Copyright (C) 2023, Berachain Foundation. All rights reserved.
// Use of this software is govered by the Business Source License included
// in the LICENSE file of this repository and at www.mariadb.com/bsl11.
//
// ANY USE OF THE LICENSED WORK IN VIOLATION OF THIS LICENSE WILL AUTOMATICALLY
// TERMINATE YOUR RIGHTS UNDER THIS LICENSE FOR THE CURRENT AND ALL OTHER
// VERSIONS OF THE LICENSED WORK.
//
// THIS LICENSE DOES NOT GRANT YOU ANY RIGHT IN ANY TRADEMARK OR LOGO OF
// LICENSOR OR ITS AFFILIATES (PROVIDED THAT YOU MAY USE A TRADEMARK OR LOGO OF
// LICENSOR AS EXPRESSLY REQUIRED BY THIS LICENSE).
//
// TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE LICENSED WORK IS PROVIDED ON
// AN “AS IS” BASIS. LICENSOR HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS,
// EXPRESS OR IMPLIED, INCLUDING (WITHOUT LIMITATION) WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT, AND
// TITLE.

package params

import "github.com/ethereum/go-ethereum/params"

type (
	// ChainConfig is the chain parameters config.
	ChainConfig = params.ChainConfig
	// Rules is the chain rules.
	Rules = params.Rules
)

var (
	// BloomBitsBlocks is the number of blocks a single bloom bit section vector contains on the server side.
	BloomBitsBlocks = params.BloomBitsBlocks
	// VersionWithMeta holds the textual version string including the metadata.
	VersionWithMeta = params.VersionWithMeta
	// VersionWithCommit holds the textual version string including the commit hash.
	VersionWithCommit = params.VersionWithCommit
	// InitialBaseFee is the initial base fee for the first block of the chain.
	InitialBaseFee = params.InitialBaseFee
)
