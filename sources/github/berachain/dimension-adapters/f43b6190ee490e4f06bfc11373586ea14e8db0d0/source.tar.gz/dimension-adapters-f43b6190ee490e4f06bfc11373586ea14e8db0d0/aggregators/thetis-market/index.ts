import { Adapter, FetchOptions } from "../../adapters/types";
import { CHAIN } from "../../helpers/chains";
import fetchURL from "../../utils/fetchURL";

const endpoint = "https://api.thetis.market/indexer/v1/stats/volume-daily";

const fetch = async (_a: any, _b: any, options: FetchOptions) => {
  const startTime = options.startOfDay;
  const data = await fetchURL(endpoint);

  let dailyVolume = 0;
  for (const item of data) {
    if (item.time == startTime) {
      dailyVolume += ((item.swap) / 1e18);
    }
  }

  return { dailyVolume };
};

const adapter: Adapter = {
  version: 1,
  fetch,
  chains: [CHAIN.APTOS],
  start: "2024-08-09",
};

export default adapter;
