package hermes_test

import (
	"context"
	"log/slog"
	"os"
	"testing"
	"time"

	"github.com/berachain/go-pyth-client/hermes"
	"github.com/berachain/go-pyth-client/httpclient"
)

// This file contains test utils that are shared for tests of Hermes.

var testPairs = []string{
	"0xc9d8b075a5c69303365ae23633d4e085199bf5c520a3b90fed1322a0342ffc33", // WBTC/USD
	"0x9d4294bbcd1174d6f2003ec365831e64cc31d9f6f15a2b85399db8d5000960f6", // WETH/USD
	"0x962088abcfdbdb6e30db2e340c8cf887d9efb311b1f2f17b155a63dbb6d40265", // BERA/USD
}

var testConfig = hermes.Config{
	// Offchain parameters
	BaseConfig: httpclient.BaseConfig{
		APIEndpoint: "https://pyth.dourolabs.app/hermes",
		APIKey:      httpclient.NewSecretWrapper(os.Getenv("PYTH_API_KEY")),
		HTTPTimeout: 1 * time.Second,
		MaxRetries:  2,
	},

	// Onchain parameters
	UseMock: true, // Uses the mock Pyth contract rather than the real one.
}

func setUp(tb testing.TB) (context.Context, *hermes.Client) {
	tb.Helper()

	// These tests hit the real Hermes API, which requires a valid key. Skip them when no key is
	// configured (e.g. local runs without PYTH_API_KEY set) rather than panicking.
	if testConfig.APIKey.Reveal() == "" {
		tb.Skip("no Pyth API key configured; set PYTH_API_KEY to run this test")
	}

	// set up Pyth client and subscribe
	pythClient, err := hermes.NewClient(&testConfig, slog.Default())
	if err != nil {
		tb.Fatalf("failed to create hermes client: %v", err)
	}

	return context.Background(), pythClient
}
