// SPDX-License-Identifier: MIT
pragma solidity 0.6.6;

import "./VRFConsumerBase.sol";

contract VRFConsumer is VRFConsumerBase {

  uint256 public currentRoundID = 0;
  uint256 public prevRandomnessOutput;
  uint256 public randomnessOutput;
  bytes32 public requestId;

  event PerfMetricsEvent(uint256 roundID, bytes32 requestId, uint256 timestamp);

  constructor(address _vrfCoordinator, address _link) public
    // solhint-disable-next-line no-empty-blocks
    VRFConsumerBase(_vrfCoordinator, _link) { /* empty */ }

  function fulfillRandomness(bytes32 _requestId, uint256 _randomness)
    internal override
  {
    randomnessOutput = _randomness;
    requestId = _requestId;
    currentRoundID += 1;
    emit PerfMetricsEvent(currentRoundID, _requestId, block.timestamp);
  }

  function testRequestRandomness(bytes32 _keyHash, uint256 _fee)
    external returns (bytes32 requestId)
  {
    return requestRandomness(_keyHash, _fee);
  }
}
