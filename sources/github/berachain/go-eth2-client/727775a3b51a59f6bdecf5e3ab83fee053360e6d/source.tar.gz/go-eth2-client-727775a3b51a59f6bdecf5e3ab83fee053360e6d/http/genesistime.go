// Copyright © 2020 - 2024 Attestant Limited.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package http

import (
	"context"
	"time"

	"github.com/attestantio/go-eth2-client/api"
)

// GenesisTime provides the genesis time of the chain.
func (s *Service) GenesisTime(ctx context.Context) (time.Time, error) {
	if err := s.assertIsActive(ctx); err != nil {
		return time.Time{}, err
	}

	response, err := s.Genesis(ctx, &api.GenesisOpts{})
	if err != nil {
		return time.Time{}, err
	}

	return response.Data.GenesisTime, nil
}
