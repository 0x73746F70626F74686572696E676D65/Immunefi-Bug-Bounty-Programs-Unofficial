// SPDX-License-Identifier: BUSL-1.1
//
// Copyright (C) 2025, Berachain Foundation. All rights reserved.
// Use of this software is governed by the Business Source License included
// in the LICENSE file of this repository and at www.mariadb.com/bsl11.
//
// ANY USE OF THE LICENSED WORK IN VIOLATION OF THIS LICENSE WILL AUTOMATICALLY
// TERMINATE YOUR RIGHTS UNDER THIS LICENSE FOR THE CURRENT AND ALL OTHER
// VERSIONS OF THE LICENSED WORK.
//
// THIS LICENSE DOES NOT GRANT YOU ANY RIGHT IN ANY TRADEMARK OR LOGO OF
// LICENSOR OR ITS AFFILIATES (PROVIDED THAT YOU MAY USE A TRADEMARK OR LOGO OF
// LICENSOR AS EXPRESSLY REQUIRED BY THIS LICENSE).
//
// TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE LICENSED WORK IS PROVIDED ON
// AN “AS IS” BASIS. LICENSOR HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS,
// EXPRESS OR IMPLIED, INCLUDING (WITHOUT LIMITATION) WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT, AND
// TITLE.

package beacon

import (
	"fmt"

	"github.com/berachain/beacon-kit/node-api/handlers"
	beacontypes "github.com/berachain/beacon-kit/node-api/handlers/beacon/types"
	handlertypes "github.com/berachain/beacon-kit/node-api/handlers/types"
	"github.com/berachain/beacon-kit/node-api/handlers/utils"
	"github.com/berachain/beacon-kit/primitives/version"
)

func (h *Handler) GetPendingPartialWithdrawals(c handlers.Context) (any, error) {
	req, err := utils.BindAndValidate[beacontypes.GetPendingPartialWithdrawalsRequest](
		c, h.Logger(),
	)
	if err != nil {
		return nil, err
	}

	// Load state for the requested state ID
	height, err := utils.StateIDToHeight(req.StateID, h.backend)
	if err != nil {
		return nil, err
	}
	st, _, err := h.backend.StateAndSlotFromHeight(height)
	if err != nil {
		return nil, err
	}

	// Check withdrawal are active
	forkVersion, err := st.GetFork()
	if err != nil {
		return nil, err
	}
	if version.IsBefore(forkVersion.CurrentVersion, version.Electra()) {
		return nil, fmt.Errorf("%w: Electra fork not active yet", handlertypes.ErrInvalidRequest)
	}

	// Retrieve and return withdrawals
	cTypePartialWithdrawals, err := st.GetPendingPartialWithdrawals()
	if err != nil {
		return nil, fmt.Errorf("failed to get pending partial withdrawals from state: %w", err)
	}

	partialWithdrawals := make([]*beacontypes.PendingPartialWithdrawalData, len(cTypePartialWithdrawals))
	for i, cTypeWithdrawal := range cTypePartialWithdrawals {
		partialWithdrawals[i] = &beacontypes.PendingPartialWithdrawalData{
			ValidatorIndex:  cTypeWithdrawal.ValidatorIndex.Unwrap(),
			Amount:          cTypeWithdrawal.Amount.Unwrap(),
			WithdrawalEpoch: cTypeWithdrawal.WithdrawableEpoch.Unwrap(),
		}
	}

	return beacontypes.NewPendingPartialWithdrawalsResponse(
		forkVersion.CurrentVersion,
		partialWithdrawals,
	), nil
}
