// SPDX-License-Identifier: BUSL-1.1
//
// Copyright (C) 2025, Berachain Foundation. All rights reserved.
// Use of this software is governed by the Business Source License included
// in the LICENSE file of this repository and at www.mariadb.com/bsl11.
//
// ANY USE OF THE LICENSED WORK IN VIOLATION OF THIS LICENSE WILL AUTOMATICALLY
// TERMINATE YOUR RIGHTS UNDER THIS LICENSE FOR THE CURRENT AND ALL OTHER
// VERSIONS OF THE LICENSED WORK.
//
// THIS LICENSE DOES NOT GRANT YOU ANY RIGHT IN ANY TRADEMARK OR LOGO OF
// LICENSOR OR ITS AFFILIATES (PROVIDED THAT YOU MAY USE A TRADEMARK OR LOGO OF
// LICENSOR AS EXPRESSLY REQUIRED BY THIS LICENSE).
//
// TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE LICENSED WORK IS PROVIDED ON
// AN “AS IS” BASIS. LICENSOR HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS,
// EXPRESS OR IMPLIED, INCLUDING (WITHOUT LIMITATION) WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT, AND
// TITLE.

package mock

import (
	"github.com/berachain/beacon-kit/consensus-types/types"
	"github.com/berachain/beacon-kit/primitives/common"
	"github.com/berachain/beacon-kit/primitives/math"
	"github.com/berachain/beacon-kit/primitives/version"
)

// NewBeaconStateWith creates a new mock beacon state with only the given fork version,
// slot, validators, execution number, and execution fee recipient populated.
func NewBeaconStateWith(
	slot math.Slot,
	vals types.Validators,
	executionNumber math.U64,
	executionFeeRecipient common.ExecutionAddress,
	forkVersion common.Version,
) *types.BeaconState {
	// If no validators are provided, create an empty slice.
	if len(vals) == 0 {
		vals = make(types.Validators, 0)
	}

	// Create an empty execution payload header with the given execution number and fee recipient.
	execPayloadHeader := types.NewEmptyExecutionPayloadHeaderWithVersion(forkVersion)
	execPayloadHeader.Number = executionNumber
	execPayloadHeader.FeeRecipient = executionFeeRecipient

	bsm := types.NewEmptyBeaconStateWithVersion(forkVersion)
	bsm.Slot = slot
	bsm.GenesisValidatorsRoot = common.Root{}
	bsm.Fork = &types.Fork{}
	bsm.LatestBlockHeader = types.NewEmptyBeaconBlockHeader()
	bsm.BlockRoots = []common.Root{}
	bsm.StateRoots = []common.Root{}
	bsm.LatestExecutionPayloadHeader = execPayloadHeader
	bsm.Eth1Data = &types.Eth1Data{}
	bsm.Eth1DepositIndex = 0
	bsm.Validators = vals
	bsm.Balances = []uint64{}
	bsm.RandaoMixes = []common.Bytes32{}
	bsm.NextWithdrawalIndex = 0
	bsm.NextWithdrawalValidatorIndex = 0
	bsm.Slashings = []math.Gwei{}
	bsm.TotalSlashing = 0
	if version.EqualsOrIsAfter(bsm.GetForkVersion(), version.Electra()) {
		bsm.PendingPartialWithdrawals = []*types.PendingPartialWithdrawal{}
	}

	return bsm
}
