// SPDX-License-Identifier: BUSL-1.1
//
// Copyright (C) 2025, Berachain Foundation. All rights reserved.
// Use of this software is governed by the Business Source License included
// in the LICENSE file of this repository and at www.mariadb.com/bsl11.
//
// ANY USE OF THE LICENSED WORK IN VIOLATION OF THIS LICENSE WILL AUTOMATICALLY
// TERMINATE YOUR RIGHTS UNDER THIS LICENSE FOR THE CURRENT AND ALL OTHER
// VERSIONS OF THE LICENSED WORK.
//
// THIS LICENSE DOES NOT GRANT YOU ANY RIGHT IN ANY TRADEMARK OR LOGO OF
// LICENSOR OR ITS AFFILIATES (PROVIDED THAT YOU MAY USE A TRADEMARK OR LOGO OF
// LICENSOR AS EXPRESSLY REQUIRED BY THIS LICENSE).
//
// TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE LICENSED WORK IS PROVIDED ON
// AN “AS IS” BASIS. LICENSOR HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS,
// EXPRESS OR IMPLIED, INCLUDING (WITHOUT LIMITATION) WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT, AND
// TITLE.

package merkle

import (
	ctypes "github.com/berachain/beacon-kit/consensus-types/types"
	"github.com/berachain/beacon-kit/errors"
	"github.com/berachain/beacon-kit/primitives/common"
	"github.com/berachain/beacon-kit/primitives/merkle"
)

// ProveProposerIndexInBlock generates a proof for the proposer index in the
// beacon block. The proof is then verified against the beacon block root as a
// sanity check. Returns the proof along with the beacon block root. It uses
// the fastssz library to generate the proof.
func ProveProposerIndexInBlock(
	bbh *ctypes.BeaconBlockHeader,
) ([]common.Root, common.Root, error) {
	blockProofTree, err := bbh.GetTree()
	if err != nil {
		return nil, common.Root{}, err
	}

	proposerIndexProof, err := blockProofTree.Prove(ProposerIndexGIndexBlock)
	if err != nil {
		return nil, common.Root{}, err
	}

	proof := make([]common.Root, len(proposerIndexProof.Hashes))
	for i, hash := range proposerIndexProof.Hashes {
		proof[i] = common.NewRootFromBytes(hash)
	}

	beaconRoot, err := verifyProposerIndexInBlock(
		bbh, proof, common.NewRootFromBytes(proposerIndexProof.Leaf),
	)
	if err != nil {
		return nil, common.Root{}, err
	}

	return proof, beaconRoot, nil
}

// verifyProposerIndexInBlock verifies the proposer index proof in the block.
//
// TODO: verifying the proof is not absolutely necessary.
func verifyProposerIndexInBlock(
	bbh *ctypes.BeaconBlockHeader, proof []common.Root, leaf common.Root,
) (common.Root, error) {
	beaconRoot := bbh.HashTreeRoot()
	if !merkle.VerifyProof(beaconRoot, leaf, ProposerIndexGIndexBlock, proof) {
		return common.Root{}, errors.Wrapf(
			errors.New("proposer index proof failed to verify against beacon root"),
			"beacon root: 0x%s", beaconRoot,
		)
	}

	return beaconRoot, nil
}
