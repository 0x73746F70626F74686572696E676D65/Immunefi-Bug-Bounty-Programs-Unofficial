// SPDX-License-Identifier: BUSL-1.1
//
// Copyright (C) 2025, Berachain Foundation. All rights reserved.
// Use of this software is governed by the Business Source License included
// in the LICENSE file of this repository and at www.mariadb.com/bsl11.
//
// ANY USE OF THE LICENSED WORK IN VIOLATION OF THIS LICENSE WILL AUTOMATICALLY
// TERMINATE YOUR RIGHTS UNDER THIS LICENSE FOR THE CURRENT AND ALL OTHER
// VERSIONS OF THE LICENSED WORK.
//
// THIS LICENSE DOES NOT GRANT YOU ANY RIGHT IN ANY TRADEMARK OR LOGO OF
// LICENSOR OR ITS AFFILIATES (PROVIDED THAT YOU MAY USE A TRADEMARK OR LOGO OF
// LICENSOR AS EXPRESSLY REQUIRED BY THIS LICENSE).
//
// TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE LICENSED WORK IS PROVIDED ON
// AN “AS IS” BASIS. LICENSOR HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS,
// EXPRESS OR IMPLIED, INCLUDING (WITHOUT LIMITATION) WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT, AND
// TITLE.

package deposit

import (
	"context"
	"errors"
	"fmt"
	"sync/atomic"

	ctypes "github.com/berachain/beacon-kit/consensus-types/types"
	"github.com/berachain/beacon-kit/gethlib/deposit"
	"github.com/berachain/beacon-kit/primitives/bytes"
	"github.com/berachain/beacon-kit/primitives/common"
	"github.com/berachain/beacon-kit/primitives/math"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	gethcommon "github.com/ethereum/go-ethereum/common"
)

// WrappedDepositContract is a struct that holds a pointer to an ABI.
type WrappedDepositContract struct {
	// DepositContractFilterer is a pointer to the codegen ABI binding.
	deposit.DepositContractFilterer

	// lastBlockNumber is the last block number that was successfully consumed from
	// the deposit contract.
	lastBlockNumber atomic.Uint64
}

// NewWrappedDepositContract creates a new DepositContract.
func NewWrappedDepositContract(
	address common.ExecutionAddress,
	client bind.ContractFilterer,
) (*WrappedDepositContract, error) {
	contract, err := deposit.NewDepositContractFilterer(
		gethcommon.Address(address), client,
	)

	if err != nil {
		return nil, err
	} else if contract == nil {
		return nil, errors.New("contract must not be nil")
	}

	return &WrappedDepositContract{
		DepositContractFilterer: *contract,
	}, nil
}

// LastBlockNumber returns the last block number that was successfully
// consumed from the deposit contract.
func (dc *WrappedDepositContract) LastBlockNumber() math.U64 {
	return math.U64(dc.lastBlockNumber.Load())
}

// ReadDeposits reads deposits from the deposit contract.
func (dc *WrappedDepositContract) ReadDeposits(
	ctx context.Context,
	blockNumber math.U64,
) ([]*ctypes.Deposit, error) {
	logs, err := dc.FilterDeposit(
		&bind.FilterOpts{
			Context: ctx,
			Start:   blockNumber.Unwrap(),
			End:     blockNumber.UnwrapPtr(),
		},
	)
	if err != nil {
		return nil, err
	}

	defer logs.Close()

	deposits := make([]*ctypes.Deposit, 0)
	for logs.Next() {
		var (
			cred   bytes.B32
			pubKey bytes.B48
			sign   bytes.B96
		)
		pubKey, err = bytes.ToBytes48(logs.Event.Pubkey)
		if err != nil {
			return nil, fmt.Errorf("failed reading pub key: %w", err)
		}
		cred, err = bytes.ToBytes32(logs.Event.Credentials)
		if err != nil {
			return nil, fmt.Errorf("failed reading credentials: %w", err)
		}
		sign, err = bytes.ToBytes96(logs.Event.Signature)
		if err != nil {
			return nil, fmt.Errorf("failed reading signature: %w", err)
		}
		deposit := &ctypes.Deposit{
			Pubkey:      pubKey,
			Credentials: ctypes.WithdrawalCredentials(cred),
			Amount:      math.U64(logs.Event.Amount),
			Signature:   sign,
			Index:       logs.Event.Index,
		}
		deposits = append(deposits, deposit)
	}

	if err = logs.Error(); err != nil {
		return nil, fmt.Errorf("deposit log iterator: %w", err)
	}

	return deposits, nil
}

// SetLastBlockNumber sets the last block number that was successfully
// consumed from the deposit contract.
func (dc *WrappedDepositContract) SetLastBlockNumber(blockNumber math.U64) {
	dc.lastBlockNumber.Store(blockNumber.Unwrap())
}
