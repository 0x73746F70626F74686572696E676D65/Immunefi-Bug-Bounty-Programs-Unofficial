CONSENSUS_DEFAULT_SETTINGS = {
    "specs": {
        "min_cpu": 0,
        "max_cpu": 2000,
        "min_memory": 0,
        "max_memory": 2048,
    },
    "images": {
        "beaconkit": "beacond:kurtosis-local",
    },
    "labels": {},
    "node_selectors": {},
    "config": {
        "timeout_propose": "3s",
        "timeout_prevote": "1s",
        "timeout_precommit": "1s",
        "max_num_inbound_peers": 40,
        "max_num_outbound_peers": 10,
    },
    "app": {
        "payload-timeout": "1.5s",
    },
}

EXECUTION_DEFAULT_SETTINGS = {
    "specs": {
        "min_cpu": 0,
        "max_cpu": 2000,
        "min_memory": 0,
        "max_memory": 2048,
    },
    "images": {
        "reth": "ghcr.io/berachain/bera-reth:nightly",
    },
    "labels": {},
    "node_selectors": {},
}

CL_TYPE = "beaconkit"

def parse_nodes_from_dict(vals, settings):
    node_type = vals["type"]
    node_list = []

    consensus_settings = parse_consensus_settings(settings)
    execution_settings = parse_execution_settings(settings)

    count = 0
    for val_configuration in vals["nodes"]:
        replicas = 1
        if "replicas" in val_configuration:
            replicas = val_configuration["replicas"]
        if replicas != 0:
            for i in range(replicas):
                val_struct = parse_node_from_dict(node_type, val_configuration, consensus_settings, execution_settings, count)
                node_list.append(val_struct)
                count += 1

    return node_list

def parse_node_from_dict(node_type, val, consensus_settings, execution_settings, index):
    # if kzg implementation is not provided, give default
    kzg_impl = "crate-crypto/go-kzg-4844"
    if "kzg_impl" in val:
        kzg_impl = val["kzg_impl"]

    return struct(
        node_type = node_type,
        el_type = val["el_type"],
        el_image = execution_settings.images[val["el_type"]],
        cl_type = CL_TYPE,
        cl_image = consensus_settings.images[CL_TYPE],
        index = index,
        cl_service_name = "cl-{}-{}-{}".format(node_type, CL_TYPE, index),
        el_service_name = "el-{}-{}-{}".format(node_type, val["el_type"], index),
        consensus_settings = consensus_settings,
        execution_settings = execution_settings,
        kzg_impl = kzg_impl,
    )

def parse_consensus_settings(settings):
    consensus_settings = {}
    if "consensus_settings" in settings:
        consensus_settings = dict(settings["consensus_settings"])
    consensus_settings = parse_default_node_settings(consensus_settings, CONSENSUS_DEFAULT_SETTINGS)
    consensus_settings = parse_extra_consensus_settings(consensus_settings)

    return get_consensus_struct(consensus_settings)

def parse_extra_consensus_settings(settings):
    config_settings = parse_consensus_config_settings(settings["config"]) if "config" in settings else parse_consensus_config_settings(CONSENSUS_DEFAULT_SETTINGS["config"])
    app_settings = parse_consensus_app_settings(settings["app"]) if "app" in settings else parse_consensus_app_settings(CONSENSUS_DEFAULT_SETTINGS["app"])

    consensus_settings = dict(settings)
    consensus_settings["config"] = config_settings
    consensus_settings["app"] = app_settings

    return consensus_settings

def parse_consensus_config_settings(config_settings):
    config_settings = dict(config_settings)

    if "timeout_propose" not in config_settings:
        config_settings["timeout_propose"] = CONSENSUS_DEFAULT_SETTINGS["config"]["timeout_propose"]
    if "timeout_prevote" not in config_settings:
        config_settings["timeout_prevote"] = CONSENSUS_DEFAULT_SETTINGS["config"]["timeout_prevote"]
    if "timeout_precommit" not in config_settings:
        config_settings["timeout_precommit"] = CONSENSUS_DEFAULT_SETTINGS["config"]["timeout_precommit"]
    if "max_num_inbound_peers" not in config_settings:
        config_settings["max_num_inbound_peers"] = CONSENSUS_DEFAULT_SETTINGS["config"]["max_num_inbound_peers"]
    if "max_num_outbound_peers" not in config_settings:
        config_settings["max_num_outbound_peers"] = CONSENSUS_DEFAULT_SETTINGS["config"]["max_num_outbound_peers"]

    return struct(
        timeout_propose = config_settings["timeout_propose"],
        timeout_prevote = config_settings["timeout_prevote"],
        timeout_precommit = config_settings["timeout_precommit"],
        max_num_inbound_peers = config_settings["max_num_inbound_peers"],
        max_num_outbound_peers = config_settings["max_num_outbound_peers"],
    )

def parse_consensus_app_settings(app_settings):
    app_settings = dict(app_settings)

    if "payload_timeout" not in app_settings:
        app_settings["payload_timeout"] = CONSENSUS_DEFAULT_SETTINGS["app"]["payload_timeout"]

    return struct(
        payload_timeout = app_settings["payload_timeout"],
    )

def parse_execution_settings(settings):
    execution_settings = {}
    if "execution_settings" in settings:
        execution_settings = dict(settings["execution_settings"])
    execution_settings = parse_default_node_settings(execution_settings, EXECUTION_DEFAULT_SETTINGS)
    return get_execution_struct(execution_settings)

def parse_default_node_settings(settings, default_settings):
    node_settings = dict(settings)
    if "specs" not in node_settings:
        node_settings["specs"] = default_settings["specs"]

    node_specs = dict(node_settings["specs"])
    if "min_cpu" not in node_specs:
        node_specs["min_cpu"] = default_settings["specs"]["min_cpu"]
    if "max_cpu" not in node_specs:
        node_specs["max_cpu"] = default_settings["specs"]["max_cpu"]
    if "min_memory" not in node_specs:
        node_specs["min_memory"] = default_settings["specs"]["min_memory"]
    if "max_memory" not in node_specs:
        node_specs["max_memory"] = default_settings["specs"]["max_memory"]
    if "images" not in node_settings:
        node_settings["images"] = default_settings["images"]
    if "labels" not in node_settings:
        node_settings["labels"] = default_settings["labels"]
    if "node_selectors" not in node_settings:
        node_settings["node_selectors"] = default_settings["node_selectors"]

    node_specs = struct(
        min_cpu = node_specs["min_cpu"],
        max_cpu = node_specs["max_cpu"],
        min_memory = node_specs["min_memory"],
        max_memory = node_specs["max_memory"],
    )
    node_settings["specs"] = node_specs

    return node_settings

def get_consensus_struct(consensus_settings):
    return struct(
        specs = consensus_settings["specs"],
        images = consensus_settings["images"],
        labels = consensus_settings["labels"],
        node_selectors = consensus_settings["node_selectors"],
        config = consensus_settings["config"],
        app = consensus_settings["app"],
    )

def get_execution_struct(execution_settings):
    return struct(
        specs = execution_settings["specs"],
        images = execution_settings["images"],
        labels = execution_settings["labels"],
        node_selectors = execution_settings["node_selectors"],
    )

def int_to_hex(plan, n):
    """Convert integer to hex string with '0x' prefix using shell printf"""
    result = plan.run_sh(
        run = 'printf "0x%x" ' + str(n),
        description = "Converting {} to hex".format(n),
    )
    return str(result.output.strip())

def render_genesis_template(plan, template_path, chain_id, chain_id_hex, genesis_deposits_root, genesis_deposit_count_hex):
    """Helper function to render a specific genesis template"""
    genesis_template = read_file(src = template_path)

    artifact = plan.render_templates(
        config = {
            "genesis.json": struct(
                template = genesis_template,
                data = {
                    "CHAIN_ID": chain_id,
                    "CHAIN_ID_HEX": chain_id_hex,
                    "GENESIS_DEPOSIT_COUNT_HEX": genesis_deposit_count_hex,
                    "GENESIS_DEPOSITS_ROOT": genesis_deposits_root,
                },
            ),
        },
        # As we are rendering the template twice, add GENESIS_DEPOSITS_ROOT to the name
        name = template_path + "_" + genesis_deposits_root,
        description = "Rendering genesis.json template",
    )
    return artifact

def create_genesis_files_part1(plan, chain_id):
    """Creates genesis files for all client types and returns them as a dict"""

    # Convert chain_id to hexadecimal string
    chain_id_hex = int_to_hex(plan, int(chain_id))

    genesis_files = {}

    # Render default genesis for all clients
    default_artifact = render_genesis_template(
        plan,
        "../networks/kurtosis-devnet/network-configs/genesis.json.template",
        chain_id,
        chain_id_hex,
        "0x0000000000000000000000000000000000000000000000000000000000000000",
        "0x0000000000000000000000000000000000000000000000000000000000000000",
    )
    genesis_files["default"] = default_artifact

    return genesis_files

# This has the deposit contract storage slots and we need to modify the eth genesis files with them.
def create_genesis_files_part2(plan, chain_id, genesis_deposits_root, genesis_deposit_count_hex):
    """Creates genesis files for all client types and returns them as a dict"""

    # Convert chain_id to hexadecimal string
    chain_id_hex = int_to_hex(plan, int(chain_id))

    genesis_files = {}

    # Render default genesis for all clients
    default_artifact = render_genesis_template(
        plan,
        "../networks/kurtosis-devnet/network-configs/genesis.json.template",
        chain_id,
        chain_id_hex,
        genesis_deposits_root,
        genesis_deposit_count_hex,
    )
    genesis_files["default"] = default_artifact

    return genesis_files
