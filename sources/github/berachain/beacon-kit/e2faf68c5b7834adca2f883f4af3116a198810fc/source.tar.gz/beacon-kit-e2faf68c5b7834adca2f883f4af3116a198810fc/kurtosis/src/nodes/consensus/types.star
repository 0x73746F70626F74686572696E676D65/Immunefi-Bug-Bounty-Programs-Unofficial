CLIENTS = struct(
    beacond = "beacond",
)
