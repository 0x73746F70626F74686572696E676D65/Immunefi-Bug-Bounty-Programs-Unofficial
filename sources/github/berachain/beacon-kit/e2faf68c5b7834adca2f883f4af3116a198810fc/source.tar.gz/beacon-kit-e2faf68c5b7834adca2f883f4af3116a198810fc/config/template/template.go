// SPDX-License-Identifier: BUSL-1.1
//
// Copyright (C) 2025, Berachain Foundation. All rights reserved.
// Use of this software is governed by the Business Source License included
// in the LICENSE file of this repository and at www.mariadb.com/bsl11.
//
// ANY USE OF THE LICENSED WORK IN VIOLATION OF THIS LICENSE WILL AUTOMATICALLY
// TERMINATE YOUR RIGHTS UNDER THIS LICENSE FOR THE CURRENT AND ALL OTHER
// VERSIONS OF THE LICENSED WORK.
//
// THIS LICENSE DOES NOT GRANT YOU ANY RIGHT IN ANY TRADEMARK OR LOGO OF
// LICENSOR OR ITS AFFILIATES (PROVIDED THAT YOU MAY USE A TRADEMARK OR LOGO OF
// LICENSOR AS EXPRESSLY REQUIRED BY THIS LICENSE).
//
// TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE LICENSED WORK IS PROVIDED ON
// AN “AS IS” BASIS. LICENSOR HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS,
// EXPRESS OR IMPLIED, INCLUDING (WITHOUT LIMITATION) WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT, AND
// TITLE.

package template

const TomlTemplate = `
###############################################################################
###                                BeaconKit                                ###
###############################################################################

[beacon-kit]
# ChainSpec is the type of chain spec to use.
chain-spec = "{{ .BeaconKit.ChainSpec }}"

# ChainSpecFilePath is the path to the chain spec file to use.
chain-spec-file = "{{ .BeaconKit.ChainSpecFilePath }}"

# ShutdownTimeout is the maximum time to wait for the node to gracefully
# shutdown before forcing an exit.
shutdown-timeout = "{{ .BeaconKit.ShutdownTimeout }}"

[beacon-kit.engine]
# HTTP url of the execution client JSON-RPC endpoint.
rpc-dial-url = "{{ .BeaconKit.Engine.RPCDialURL }}"

# RPC timeout for execution client requests.
rpc-timeout = "{{ .BeaconKit.Engine.RPCTimeout }}"

# Interval for the startup check.
rpc-startup-check-interval = "{{ .BeaconKit.Engine.RPCStartupCheckInterval }}"

# Interval for the JWT refresh.
rpc-jwt-refresh-interval = "{{ .BeaconKit.Engine.RPCJWTRefreshInterval }}"

# Path to the execution client JWT-secret
jwt-secret-path = "{{.BeaconKit.Engine.JWTSecretPath}}"

[beacon-kit.logger]
# TimeFormat is a string that defines the format of the time in the logger.
time-format = "{{.BeaconKit.Logger.TimeFormat}}"

# LogLevel is the level of logging. Logger will log messages with verbosity up
# to LogLevel.
log-level = "{{.BeaconKit.Logger.LogLevel}}"

# Style is the style of the logger.
style = "{{.BeaconKit.Logger.Style}}"

[beacon-kit.kzg]
# Path to the trusted setup path.
trusted-setup-path = "{{.BeaconKit.KZG.TrustedSetupPath}}"

# KZG implementation to use.
# Options are "crate-crypto/go-kzg-4844".
implementation = "{{.BeaconKit.KZG.Implementation}}"

[beacon-kit.payload-builder]
# Enabled determines if the local payload builder is enabled.
# It should be enabled for validators, but it can be disabled
# for full nodes.
enabled = {{ .BeaconKit.PayloadBuilder.Enabled }}

# Post bellatrix, this address will receive the transaction fees produced by any blocks
# from this node.
suggested-fee-recipient = "{{.BeaconKit.PayloadBuilder.SuggestedFeeRecipient}}"

# The timeout for local build payload. This should match, or be slightly less
# than the configured timeout on your execution client. It also must be less than
# timeout_proposal in the CometBFT configuration.
payload-timeout = "{{ .BeaconKit.PayloadBuilder.PayloadTimeout }}"

[beacon-kit.validator]
# Graffiti string that will be included in the graffiti field of the beacon block.
graffiti = "{{ .BeaconKit.Validator.Graffiti }}"

[beacon-kit.block-store-service]
# AvailabilityWindow is the number of slots to keep in the store.
# Setting AvailabilityWindow to 0 disables block store and does not allow the node
# to serve proof or namespace apis from beacon node-api.
availability-window = "{{ .BeaconKit.BlockStoreService.AvailabilityWindow }}"

[beacon-kit.node-api]
# Enabled determines if the node API is enabled.
enabled = "{{ .BeaconKit.NodeAPI.Enabled }}"

# Address is the address to bind the node API to.
address = "{{ .BeaconKit.NodeAPI.Address }}"

# Logging determines if the node API logging is enabled.
logging = "{{ .BeaconKit.NodeAPI.Logging }}"
`
