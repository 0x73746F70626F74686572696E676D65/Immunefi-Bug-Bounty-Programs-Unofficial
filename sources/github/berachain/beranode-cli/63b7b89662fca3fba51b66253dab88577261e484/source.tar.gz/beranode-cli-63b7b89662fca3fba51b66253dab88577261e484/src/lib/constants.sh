#!/usr/bin/env bash
set -euo pipefail
################################################################################
# constants.sh - Beranode CLI Constants and Configuration
################################################################################
#
# This module defines all readonly constants and configuration values used
# throughout the Beranode CLI. Constants are organized into logical sections
# for maintainability and ease of reference.
#
# IMPORTANT: This file contains critical configuration for:
#   - Network identifiers (chain IDs, network names)
#   - Port allocations (consensus layer, execution layer, metrics)
#   - Binary names and release URLs
#   - Directory structure definitions
#   - Genesis contract deployments (EIP-4788, CREATE2, Multicall3, etc.)
#   - Prague upgrade parameters (Berachain-specific)
#
# VERSION MANAGEMENT:
#   BERANODE_VERSION is the CLI SemVer source of truth. Update it by hand
#   when releasing, then rebuild with build.sh and tag vX.Y.Z.
#
# LEGEND - Constant Categories:
# ──────────────────────────────────────────────────────────────────────────────
# [1] VERSION INFORMATION
#     └─ BERANODE_VERSION          : CLI version (auto-managed)
#
# [2] PLATFORM DETECTION
#     └─ PLATFORM, ARCH            : OS and architecture detection
#     └─ IS_MACOS, IS_LINUX, etc.  : Platform-specific booleans
#     └─ SED_OPT                   : Platform-specific sed options
#
# [3] NETWORK CONFIGURATION
#     └─ CHAIN_ID_*                : Network chain IDs (devnet, testnet, mainnet)
#     └─ CHAIN_NAME_*              : Network names
#     └─ GENESIS_DEPOSIT_AMOUNT    : Validator deposit amount
#
# [4] PORT ALLOCATIONS
#     └─ DEFAULT_CL_*              : Consensus Layer (BeaconKit) ports
#     └─ DEFAULT_EL_*              : Execution Layer (Bera-Reth) ports
#     └─ DEFAULT_*_PROMETHEUS_PORT : Metrics ports
#
# [5] BINARIES AND RELEASES
#     └─ BIN_*                     : Binary executable names
#     └─ RELEASE_*                 : GitHub release API URLs
#     └─ REPO_*                    : GitHub repository URLs
#
# [6] DIRECTORY STRUCTURE
#     └─ BERANODES_PATH_*          : Standard directory layout
#     └─ GENESIS_*_NAME_DEFAULT    : Genesis file names
#
# [7] GENESIS CONTRACTS
#     └─ ETH_GENESIS_BEACON_ROOTS_*      : EIP-4788 Beacon Roots
#     └─ ETH_GENESIS_CREATE2_DEPLOYER_*  : CREATE2 factory
#     └─ ETH_GENESIS_MULTICALL3_*        : Batch call aggregator
#     └─ ETH_GENESIS_WBERA_*             : Wrapped BERA token
#     └─ ETH_GENESIS_PERMIT2_*           : Uniswap Permit2
#     └─ ETH_GENESIS_BEACON_DEPOSIT_*    : Validator deposits
#
# [8] PRAGUE UPGRADE PARAMETERS
#     └─ ETH_GENESIS_PRAGUE*_*     : Berachain-specific upgrade configs
#
################################################################################

# =============================================================================
# [1] VERSION INFORMATION
# =============================================================================

# Variable: BERANODE_VERSION
# Type: String (semver format: X.Y.Z)
# Description: Current version of the Beranode CLI tool
# Management: Edit this value when releasing, then run ./build.sh
#
# Example: "0.9.0"
BERANODE_VERSION="0.12.0"

# =============================================================================
# [2] PLATFORM DETECTION
# =============================================================================

# Variables: PLATFORM, ARCH
# Type: String (readonly)
# Description: Detected operating system and CPU architecture
# Values:
#   - PLATFORM: "Darwin" (macOS), "Linux", "MINGW*/CYGWIN*/MSYS*" (Windows)
#   - ARCH: "x86_64", "arm64", "aarch64", etc.
# Usage: Used throughout the CLI for platform-specific logic
readonly PLATFORM="$(uname)"
readonly ARCH="$(uname -m)"

# Variables: IS_MACOS, IS_LINUX, IS_WINDOWS, IS_LINUX_ARM
# Type: Boolean (readonly)
# Description: Platform detection flags for conditional logic
# Values: true/false
# Purpose: Enables platform-specific behavior (binary selection, sed syntax, etc.)
if [[ "$PLATFORM" == "Darwin" ]]; then
	readonly IS_MACOS=true
	readonly IS_LINUX=false
	readonly IS_WINDOWS=false
	readonly IS_LINUX_ARM=false
elif [[ "$PLATFORM" == "Linux" ]]; then
	readonly IS_MACOS=false
	readonly IS_LINUX=true
	readonly IS_WINDOWS=false
	# Detect if CPU architecture is ARM (e.g., "armv7l", "aarch64", etc.)
	if [[ "$ARCH" == arm* ]] || [[ "$ARCH" == aarch64* ]]; then
		readonly IS_LINUX_ARM=true
	else
		readonly IS_LINUX_ARM=false
	fi
elif [[ "$PLATFORM" == MINGW* ]] || [[ "$PLATFORM" == CYGWIN* ]] || [[ "$PLATFORM" == MSYS* ]]; then
	readonly IS_MACOS=false
	readonly IS_LINUX=false
	readonly IS_WINDOWS=true
	readonly IS_LINUX_ARM=false
else
	readonly IS_MACOS=false
	readonly IS_LINUX=false
	readonly IS_WINDOWS=false
	readonly IS_LINUX_ARM=false
	echo "error: unsupported platform: '${PLATFORM}'" >&2
	exit 1
fi

# Windows Support Status
# Currently, Windows support is not implemented. This check prevents
# the CLI from running on Windows until full support is added.
if [ "$IS_WINDOWS" == true ]; then
	local_red='\033[0;31m'
	local_reset='\033[0m'
	echo -e "${local_red}[ERROR] This script currently only supports macOS and Linux. Windows support coming soon.${local_reset}" >&2
	exit 1
fi

# Variable: SED_OPT
# Type: Array (readonly)
# Description: Platform-specific sed in-place edit options
# Values:
#   - macOS: (-i '') - requires empty string argument
#   - Linux: (-i)    - no additional argument needed
# Purpose: Ensures sed in-place editing works across platforms
if [[ $(uname) == "Darwin" ]]; then
	readonly SED_OPT=(-i '')
else
	readonly SED_OPT=(-i)
fi

# =============================================================================
# [3] NETWORK CONFIGURATION
# =============================================================================

# Variables: CHAIN_ID_*, CHAIN_NAME_*
# Type: Integer (chain ID) and String (chain name) - readonly
# Description: Berachain network identifiers and names
#
# Supported Networks:
#   - devnet (chain ID: 80087)   : Local development network
#   - bepolia (chain ID: 80069)  : Public testnet
#   - mainnet (chain ID: 80094)  : Production network
#
# Purpose: These constants enforce network identity for EIP-155 transaction
#          signing and prevent replay attacks across different networks.
readonly CHAIN_ID_DEVNET=80087
readonly CHAIN_NAME_DEVNET="devnet"
readonly CHAIN_ID_TESTNET=80069
readonly CHAIN_NAME_TESTNET="bepolia"
readonly CHAIN_ID_MAINNET=80094
readonly CHAIN_NAME_MAINNET="mainnet"

# BeaconKit --beacon-kit.chain-spec values (distinct from network names).
# Bepolia uses "testnet"; mainnet uses "mainnet"; local uses "devnet".
readonly BEACON_CHAIN_SPEC_DEVNET="devnet"
readonly BEACON_CHAIN_SPEC_TESTNET="testnet"
readonly BEACON_CHAIN_SPEC_MAINNET="mainnet"

# Official snapshot index hosts (index.csv is the stable API).
readonly SNAPSHOT_HOST_BEPOLIA="https://bepolia.snapshots.berachain.com"
readonly SNAPSHOT_HOST_MAINNET="https://snapshots.berachain.com"

# Official public Execution Layer JSON-RPC endpoints (status LIVE EL BLOCK).
readonly PUBLIC_EL_RPC_BEPOLIA="https://bepolia.rpc.berachain.com"
readonly PUBLIC_EL_RPC_MAINNET="https://rpc.berachain.com"

# How often `beranode status` re-reads network from beranodes.config.json
# and queries the public EL RPC for LIVE EL BLOCK.
readonly LIVE_EL_REFRESH_SECONDS=10

# How often `beranode status --watch` re-runs diskutil/df and `du` for the
# Storage footer (directory walk can be slow on large chaindata).
readonly STORAGE_REFRESH_SECONDS=30

# How often `beranode status --watch` re-queries process RSS / docker stats
# for the Memory footer. Cheaper than `du`, but docker stats still takes ~1s.
readonly MEMORY_REFRESH_SECONDS=5

# How often `beranode status --watch` re-queries per-binary CPU usage
# (ps %cpu on local/serviceman, docker stats CPUPerc on docker) for the CPU
# footer. Same cadence as Memory; docker stats still takes ~1s.
readonly CPU_REFRESH_SECONDS=5

# Official seed-data (genesis, KZG, EL bootnodes/peers, toml overlays).
readonly SEED_DATA_BASE_URL="https://raw.githubusercontent.com/berachain/beacon-kit/refs/heads/main/testing/networks"

# Recommended client versions per public network (docs; will drift — override with flags).
readonly RECOMMENDED_BEACOND_VERSION_BEPOLIA="v1.4.1"
readonly RECOMMENDED_BERARETH_VERSION_BEPOLIA="v1.4.4"
readonly RECOMMENDED_BEACOND_VERSION_MAINNET="v1.4.1"
readonly RECOMMENDED_BERARETH_VERSION_MAINNET="v1.4.4"

# Documented md5 checksums for seed-data files (warn on mismatch).
readonly SEED_MD5_GENESIS_BEPOLIA="a24fb9c7ddf3ebd557300e989d44b619"
readonly SEED_MD5_GENESIS_MAINNET="c66dbea5ee3889e1d0a11f856f1ab9f0"
readonly SEED_MD5_KZG="5d0d482758117af8dfc20e1d52c31eef"

# GitHub / CLI version tags: latest, v1.4.1, v1.4.2-rc.0, v1.4.2-rc2
readonly VERSION_TAG_REGEX='^(latest|v\.?[0-9]+\.[0-9]+\.[0-9]+(-rc\.?[0-9]+(\.[0-9]+)?)?)$'

# Variable: GENESIS_DEPOSIT_AMOUNT
# Type: Integer (Wei denomination) - readonly
# Description: Minimum validator deposit amount for Berachain PoS
# Value: 250000000000000 Wei (0.00025 BERA)
# Purpose: Validators must deposit this amount to participate in consensus
readonly GENESIS_DEPOSIT_AMOUNT=250000000000000

# =============================================================================
# [4] PORT ALLOCATIONS
# =============================================================================

# ─────────────────────────────────────────────────────────────────────────────
# Consensus Layer (BeaconKit/Beacond) Ports
# ─────────────────────────────────────────────────────────────────────────────
# Variable: DEFAULT_CL_ETHRPC_PORT
# Description: Consensus layer RPC endpoint port (Tendermint RPC)
# Default: 26657
# Usage: Used for querying consensus layer state and submitting transactions
readonly DEFAULT_CL_ETHRPC_PORT=26657

# Variable: DEFAULT_CL_ETHP2P_PORT
# Description: Consensus layer P2P communication port
# Default: 26656
# Usage: Node-to-node communication for block propagation and consensus
readonly DEFAULT_CL_ETHP2P_PORT=26656

# Variable: DEFAULT_CL_ETHPROXY_PORT
# Description: Consensus layer proxy port
# Default: 26658
# Usage: HTTP proxy for consensus layer API access
readonly DEFAULT_CL_ETHPROXY_PORT=26658

# Variable: DEFAULT_CL_PROMETHEUS_PORT
# Description: Consensus layer Prometheus metrics port
# Default: 26660
# Usage: Exports consensus layer metrics for monitoring
readonly DEFAULT_CL_PROMETHEUS_PORT=26660

# ─────────────────────────────────────────────────────────────────────────────
# Execution Layer (Bera-Reth) Ports
# ─────────────────────────────────────────────────────────────────────────────
# Variable: DEFAULT_EL_ETHRPC_PORT
# Description: Execution layer JSON-RPC HTTP endpoint
# Default: 8545 (standard Ethereum RPC port)
# Usage: Primary interface for dApp communication (eth_call, eth_sendTransaction, etc.)
readonly DEFAULT_EL_ETHRPC_PORT=8545

# Variable: DEFAULT_EL_WS_PORT
# Description: Execution layer WebSocket endpoint
# Default: 8546 (standard Ethereum WebSocket port)
# Usage: Real-time event subscriptions (logs, newHeads, etc.)
readonly DEFAULT_EL_WS_PORT=8546

# Variable: DEFAULT_EL_AUTHRPC_PORT
# Description: Execution layer authenticated Engine API port
# Default: 8551 (standard post-Merge auth port)
# Usage: Secure communication between consensus and execution layers
readonly DEFAULT_EL_AUTHRPC_PORT=8551

# Variable: DEFAULT_DEFAULT_EL_ETH_PORT
# Description: Execution layer P2P networking port
# Default: 30303 (standard Ethereum discovery port)
# Usage: Peer discovery and block/transaction propagation
readonly DEFAULT_DEFAULT_EL_ETH_PORT=30303

# Variable: DEFAULT_EL_PROMETHEUS_PORT
# Description: Execution layer Prometheus metrics port
# Default: 9101
# Usage: Exports execution layer metrics for monitoring
readonly DEFAULT_EL_PROMETHEUS_PORT=9101

# ─────────────────────────────────────────────────────────────────────────────
# Additional Service Ports
# ─────────────────────────────────────────────────────────────────────────────
# Variable: DEFAULT_BEACON_NODE_API_PORT
# Description: Beacon node API port (Beacon Chain API spec)
# Default: 3500
# Usage: Standard beacon chain API for validator operations
readonly DEFAULT_BEACON_NODE_API_PORT=3500

# Variable: DEFAULT_GRPC_LADDR_PORT
# Description: gRPC service port
# Default: 9090
# Usage: gRPC API for application-specific queries
readonly DEFAULT_GRPC_LADDR_PORT=9090

# Variable: DEFAULT_GRPC_PRIVILEGED_LADDR_PORT
# Description: Privileged gRPC service port
# Default: 9091
# Usage: gRPC API with elevated permissions for administrative operations
readonly DEFAULT_GRPC_PRIVILEGED_LADDR_PORT=9091

# ─────────────────────────────────────────────────────────────────────────────
# Port Management Configuration
# ─────────────────────────────────────────────────────────────────────────────
# Variable: DEFAULT_PORT_INCREMENT
# Description: Port increment for multi-node setups
# Default: 100
# Purpose: Each additional node adds this value to base ports to avoid conflicts
# Example: Node 1 uses 26657, Node 2 uses 26757, Node 3 uses 26857
readonly DEFAULT_PORT_INCREMENT=100

# ─────────────────────────────────────────────────────────────────────────────
# Wallet Configuration
# ─────────────────────────────────────────────────────────────────────────────
# Variable: DEFAULT_WALLET_BALANCE
# Description: Default wallet balance for genesis accounts
# Default: 1000000000000000000000000000 Wei (1 billion BERA)
# Purpose: Pre-funded balance for development/testing accounts
readonly DEFAULT_WALLET_BALANCE=1000000000000000000000000000

# =============================================================================
# [5] BINARIES AND RELEASES
# =============================================================================

# ─────────────────────────────────────────────────────────────────────────────
# Binary Executable Names
# ─────────────────────────────────────────────────────────────────────────────
# Variable: BIN_BEACONKIT
# Description: Consensus layer binary name
# Value: "beacond"
# Purpose: Name of the BeaconKit consensus client executable
readonly BIN_BEACONKIT="beacond"

# Variable: BIN_BERARETH
# Description: Execution layer binary name
# Value: "bera-reth"
# Purpose: Name of the Bera-Reth execution client executable
readonly BIN_BERARETH="bera-reth"

# ─────────────────────────────────────────────────────────────────────────────
# GitHub Release URLs
# ─────────────────────────────────────────────────────────────────────────────
# Variable: RELEASE_BERARETH
# Description: GitHub API URL for Bera-Reth releases
# Usage: Used by download.sh to fetch latest binary releases
readonly RELEASE_BERARETH="https://api.github.com/repos/berachain/bera-reth"

# Variable: RELEASE_BEACONKIT
# Description: GitHub API URL for BeaconKit releases
# Usage: Used by download.sh to fetch latest binary releases
readonly RELEASE_BEACONKIT="https://api.github.com/repos/berachain/beacon-kit"

# Variable: REPO_BEACONKIT
# Description: GitHub raw content URL for BeaconKit test networks (legacy default: mainnet 80094)
# Usage: Prefer network_seed_data_url; kept for backward-compatible KZG fetch on devnet
readonly REPO_BEACONKIT="${SEED_DATA_BASE_URL}/80094"

# ─────────────────────────────────────────────────────────────────────────────
# Docker Registry URLs
# ─────────────────────────────────────────────────────────────────────────────
# Variable: DOCKER_REGISTRY_BERARETH
# Description: Docker registry URL for Bera-Reth container images
# Usage: Used for pulling Bera-Reth Docker images (version tags retrieved via API)
readonly DOCKER_REGISTRY_BERARETH="ghcr.io/berachain/bera-reth"

# Variable: DOCKER_REGISTRY_BEACONKIT
# Description: Docker registry URL for BeaconKit container images
# Usage: Used for pulling BeaconKit Docker images (version tags retrieved via API)
readonly DOCKER_REGISTRY_BEACONKIT="ghcr.io/berachain/beacon-kit"

# =============================================================================
# [6] DIRECTORY STRUCTURE
# =============================================================================

# ─────────────────────────────────────────────────────────────────────────────
# Base Directories
# ─────────────────────────────────────────────────────────────────────────────
# Variable: BERANODES_PATH_DEFAULT
# Description: Default root directory for all beranode data
# Default: $(pwd)/beranodes
# Purpose: Contains all node configurations, binaries, logs, and data
readonly BERANODES_PATH_DEFAULT="$(pwd)/beranodes"

# Variable: BERANODES_PATH (mutable)
# Description: Configurable base path for beranodes installation
# Default: $(pwd)/beranodes (can be overridden by environment variable)
# Usage: export BERANODES_PATH=/custom/path before running beranode
BERANODES_PATH=${BERANODES_PATH:-$(pwd)/beranodes}

# ─────────────────────────────────────────────────────────────────────────────
# Subdirectory Paths (relative to BERANODES_PATH_DEFAULT)
# ─────────────────────────────────────────────────────────────────────────────
# Variable: BERANODES_PATH_BIN
# Description: Binary directory path
# Value: "/bin"
# Contents: beacond and bera-reth executables
readonly BERANODES_PATH_BIN="/bin"

# Variable: BERANODES_PATH_TMP
# Description: Temporary files directory path
# Value: "/tmp"
# Contents: Genesis files, intermediate configs, build artifacts
readonly BERANODES_PATH_TMP="/tmp"

# Variable: BERANODES_PATH_LOGS
# Description: Log files directory path
# Value: "/logs"
# Contents: Node logs, error logs, debug output
readonly BERANODES_PATH_LOGS="/logs"

# Variable: BERANODES_PATH_NODES
# Description: Node data directory path
# Value: "/nodes"
# Contents: Per-node subdirectories with chain data, configs
readonly BERANODES_PATH_NODES="/nodes"

# Variable: BERANODES_PATH_RUNS
# Description: Runtime process tracking directory path
# Value: "/runs"
# Contents: PID files for running nodes
readonly BERANODES_PATH_RUNS="/runs"

# Variable: BERANODES_PATH_SNAPSHOTS
# Description: Official chain-state snapshot download directory
# Value: "/snapshots"
# Contents: Per-network subdirs (bepolia/, mainnet/) with .tar.lz4 archives
#           plus unzipped beacond/ and reth/ trees
readonly BERANODES_PATH_SNAPSHOTS="/snapshots"

# Variable: BERANODES_PATH_SERVICES
# Description: OS service-manager artifacts (unit files / plists, runner, manifest)
# Value: "/services"
# Contents: launchd plists + launchd.json (macOS) or systemd units + systemd.json (Linux)
readonly BERANODES_PATH_SERVICES="/services"

# Variable: SERVICEMAN_LAUNCHD_LABEL_PREFIX
# Description: Reverse-DNS prefix for launchd job labels and systemd unit names
readonly SERVICEMAN_LAUNCHD_LABEL_PREFIX="com.berachain.beranode"

# Variable: SERVICEMAN_LAUNCHD_THROTTLE_INTERVAL
# Description: Seconds launchd waits before restarting a crashed job
readonly SERVICEMAN_LAUNCHD_THROTTLE_INTERVAL=10

# Variable: SERVICEMAN_SYSTEMD_RESTART_SEC
# Description: Seconds systemd waits before Restart=always (KeepAlive equivalent)
readonly SERVICEMAN_SYSTEMD_RESTART_SEC=10

# Variable: SERVICEMAN_SYSTEMD_TIMEOUT_STOP_SEC
# Description: Seconds systemd waits for a clean stop before SIGKILL
readonly SERVICEMAN_SYSTEMD_TIMEOUT_STOP_SEC=60

# Variable: SERVICEMAN_SYSTEMD_LIMIT_NOFILE
# Description: Soft/hard NOFILE rlimit for user units (CL/EL open many sockets)
readonly SERVICEMAN_SYSTEMD_LIMIT_NOFILE=1048576

# Variable: SERVICEMAN_SYSTEMD_RUNNER_NAME
# Description: Shared tee runner that mirrors stdout/stderr to beranodes/logs and journald
readonly SERVICEMAN_SYSTEMD_RUNNER_NAME="beranode-tee-journal.sh"

# ─────────────────────────────────────────────────────────────────────────────
# File Names
# ─────────────────────────────────────────────────────────────────────────────
# Variable: GENESIS_ETH_NAME_DEFAULT
# Description: Execution layer genesis file name
# Value: "eth-genesis.json"
# Format: Geth/Reth-compatible JSON genesis specification
readonly GENESIS_ETH_NAME_DEFAULT="eth-genesis.json"

# Variable: GENESIS_BEACON_NAME_DEFAULT
# Description: Consensus layer genesis file name
# Value: "genesis.json"
# Format: BeaconKit/Tendermint genesis specification
readonly GENESIS_BEACON_NAME_DEFAULT="genesis.json"

# ─────────────────────────────────────────────────────────────────────────────
# Dependency Version Requirements
# ─────────────────────────────────────────────────────────────────────────────
# Variable: SUPPORTED_CAST_VERSION
# Description: Minimum required cast (Foundry) version
# Value: "1.6.0"
# Purpose: Used for key generation and Ethereum utilities
readonly SUPPORTED_CAST_VERSION="1.6.0"

# Variable: SUPPORTED_TAR_GZ_VERSION
# Description: Minimum required tar version
# Value: "1.34"
# Purpose: Binary extraction from GitHub releases
readonly SUPPORTED_TAR_GZ_VERSION="1.34"

# Variable: SUPPORTED_CURL_VERSION
# Description: Minimum required curl version
# Value: "8.7.1"
# Purpose: Downloading binaries and artifacts
readonly SUPPORTED_CURL_VERSION="8.7.1"

# =============================================================================
# Default Genesis Contracts
# =============================================================================
# These contracts are deployed at genesis with pre-set addresses.
# This ensures critical infrastructure exists from block 0.

# --- EIP-4788 Beacon Roots Contract ---
# Address: 0x000F3df6D732807Ef1319fB7B8bB8522d0Beac02
# Purpose: Stores beacon chain block roots, allowing smart contracts to
# trustlessly access consensus layer data (validator info, etc.)
# Required for Cancun-enabled networks (EIP-4788)
ETH_GENESIS_BEACON_ROOTS_ADDRESS="0x000F3df6D732807Ef1319fB7B8bB8522d0Beac02"
ETH_GENESIS_BEACON_ROOTS_CODE="0x3373fffffffffffffffffffffffffffffffffffffffe14604d57602036146024575f5ffd5b5f35801560495762001fff810690815414603c575f5ffd5b62001fff01545f5260205ff35b5f5ffd5b62001fff42064281555f359062001fff015500"
ETH_GENESIS_BEACON_ROOTS_BALANCE="0x0"
ETH_GENESIS_BEACON_ROOTS_NONCE="0x1"

# --- CREATE2 Deployer (Deterministic Deployment Proxy) ---
# Address: 0x4e59b44847b379578588920cA78FbF26c0B4956C
# Purpose: Allows deploying contracts to deterministic addresses using CREATE2
# The same contract deployed with same bytecode + salt = same address on any chain
# This is a standard address used across many EVM chains
ETH_GENESIS_CREATE2_DEPLOYER_ADDRESS="0x4e59b44847b379578588920cA78FbF26c0B4956C"
ETH_GENESIS_CREATE2_DEPLOYER_CODE="0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe03601600081602082378035828234f58015156039578182fd5b8082525050506014600cf3"
ETH_GENESIS_CREATE2_DEPLOYER_BALANCE="0x0"
ETH_GENESIS_CREATE2_DEPLOYER_NONCE="0x1"

# --- Multicall3 ---
# Address: 0xcA11bde05977b3631167028862bE2a173976CA11
# Purpose: Batch multiple read-only calls into a single RPC request
# Essential for efficient dApp frontends and indexers
# Standard deployment address across EVM chains
ETH_GENESIS_MULTICALL3_ADDRESS="0xcA11bde05977b3631167028862bE2a173976CA11"
ETH_GENESIS_MULTICALL3_CODE="0x6080604052600436106100f35760003560e01c80634d2301cc1161008a578063a8b0574e11610059578063a8b0574e1461025a578063bce38bd714610275578063c3077fa914610288578063ee82ac5e1461029b57600080fd5b80634d2301cc146101ec57806372425d9d1461022157806382ad56cb1461023457806386d516e81461024757600080fd5b80633408e470116100c65780633408e47014610191578063399542e9146101a45780633e64a696146101c657806342cbb15c146101d957600080fd5b80630f28c97d146100f8578063174dea711461011a578063252dba421461013a57806327e86d6e1461015b575b600080fd5b34801561010457600080fd5b50425b6040519081526020015b60405180910390f35b61012d610128366004610a85565b6102ba565b6040516101119190610bbe565b61014d610148366004610a85565b6104ef565b604051610111929190610bd8565b34801561016757600080fd5b50437fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0140610107565b34801561019d57600080fd5b5046610107565b6101b76101b2366004610c60565b610690565b60405161011193929190610cba565b3480156101d257600080fd5b5048610107565b3480156101e557600080fd5b5043610107565b3480156101f857600080fd5b50610107610207366004610ce2565b73ffffffffffffffffffffffffffffffffffffffff163190565b34801561022d57600080fd5b5044610107565b61012d610242366004610a85565b6106ab565b34801561025357600080fd5b5045610107565b34801561026657600080fd5b50604051418152602001610111565b61012d610283366004610c60565b61085a565b6101b7610296366004610a85565b610a1a565b3480156102a757600080fd5b506101076102b6366004610d18565b4090565b60606000828067ffffffffffffffff8111156102d8576102d8610d31565b60405190808252806020026020018201604052801561031e57816020015b6040805180820190915260008152606060208201528152602001906001900390816102f65790505b5092503660005b8281101561047757600085828151811061034157610341610d60565b6020026020010151905087878381811061035d5761035d610d60565b905060200281019061036f9190610d8f565b6040810135958601959093506103886020850185610ce2565b73ffffffffffffffffffffffffffffffffffffffff16816103ac6060870187610dcd565b6040516103ba929190610e32565b60006040518083038185875af1925050503d80600081146103f7576040519150601f19603f3d011682016040523d82523d6000602084013e6103fc565b606091505b50602080850191909152901515808452908501351761046d577f08c379a000000000000000000000000000000000000000000000000000000000600052602060045260176024527f4d756c746963616c6c333a2063616c6c206661696c656400000000000000000060445260846000fd5b5050600101610325565b508234146104e6576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601a60248201527f4d756c746963616c6c333a2076616c7565206d69736d6174636800000000000060448201526064015b60405180910390fd5b50505092915050565b436060828067ffffffffffffffff81111561050c5761050c610d31565b60405190808252806020026020018201604052801561053f57816020015b606081526020019060019003908161052a5790505b5091503660005b8281101561068657600087878381811061056257610562610d60565b90506020028101906105749190610e42565b92506105836020840184610ce2565b73ffffffffffffffffffffffffffffffffffffffff166105a66020850185610dcd565b6040516105b4929190610e32565b6000604051808303816000865af19150503d80600081146105f1576040519150601f19603f3d011682016040523d82523d6000602084013e6105f6565b606091505b5086848151811061060957610609610d60565b602090810291909101015290508061067d576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601760248201527f4d756c746963616c6c333a2063616c6c206661696c656400000000000000000060448201526064016104dd565b50600101610546565b5050509250929050565b43804060606106a086868661085a565b905093509350939050565b6060818067ffffffffffffffff8111156106c7576106c7610d31565b60405190808252806020026020018201604052801561070d57816020015b6040805180820190915260008152606060208201528152602001906001900390816106e55790505b5091503660005b828110156104e657600084828151811061073057610730610d60565b6020026020010151905086868381811061074c5761074c610d60565b905060200281019061075e9190610e76565b925061076d6020840184610ce2565b73ffffffffffffffffffffffffffffffffffffffff166107906040850185610dcd565b60405161079e929190610e32565b6000604051808303816000865af19150503d80600081146107db576040519150601f19603f3d011682016040523d82523d6000602084013e6107e0565b606091505b506020808401919091529015158083529084013517610851577f08c379a000000000000000000000000000000000000000000000000000000000600052602060045260176024527f4d756c746963616c6c333a2063616c6c206661696c656400000000000000000060445260646000fd5b50600101610714565b6060818067ffffffffffffffff81111561087657610876610d31565b6040519080825280602002602001820160405280156108bc57816020015b6040805180820190915260008152606060208201528152602001906001900390816108945790505b5091503660005b82811015610a105760008482815181106108df576108df610d60565b602002602001015190508686838181106108fb576108fb610d60565b905060200281019061090d9190610e42565b925061091c6020840184610ce2565b73ffffffffffffffffffffffffffffffffffffffff1661093f6020850185610dcd565b60405161094d929190610e32565b6000604051808303816000865af19150503d806000811461098a576040519150601f19603f3d011682016040523d82523d6000602084013e61098f565b606091505b506020830152151581528715610a07578051610a07576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601760248201527f4d756c746963616c6c333a2063616c6c206661696c656400000000000000000060448201526064016104dd565b506001016108c3565b5050509392505050565b6000806060610a2b60018686610690565b919790965090945092505050565b60008083601f840112610a4b57600080fd5b50813567ffffffffffffffff811115610a6357600080fd5b6020830191508360208260051b8501011115610a7e57600080fd5b9250929050565b60008060208385031215610a9857600080fd5b823567ffffffffffffffff811115610aaf57600080fd5b610abb85828601610a39565b90969095509350505050565b6000815180845260005b81811015610aed57602081850181015186830182015201610ad1565b81811115610aff576000602083870101525b50601f017fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0169290920160200192915050565b600082825180855260208086019550808260051b84010181860160005b84811015610bb1578583037fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe001895281518051151584528401516040858501819052610b9d81860183610ac7565b9a86019a9450505090830190600101610b4f565b5090979650505050505050565b602081526000610bd16020830184610b32565b9392505050565b600060408201848352602060408185015281855180845260608601915060608160051b870101935082870160005b82811015610c52577fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa0888703018452610c40868351610ac7565b95509284019290840190600101610c06565b509398975050505050505050565b600080600060408486031215610c7557600080fd5b83358015158114610c8557600080fd5b9250602084013567ffffffffffffffff811115610ca157600080fd5b610cad86828701610a39565b9497909650939450505050565b838152826020820152606060408201526000610cd96060830184610b32565b95945050505050565b600060208284031215610cf457600080fd5b813573ffffffffffffffffffffffffffffffffffffffff81168114610bd157600080fd5b600060208284031215610d2a57600080fd5b5035919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052603260045260246000fd5b600082357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff81833603018112610dc357600080fd5b9190910192915050565b60008083357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe1843603018112610e0257600080fd5b83018035915067ffffffffffffffff821115610e1d57600080fd5b602001915036819003821315610a7e57600080fd5b8183823760009101908152919050565b600082357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc1833603018112610dc357600080fd5b600082357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa1833603018112610dc357600080fdfea2646970667358221220bb2b5c71a328032f97c676ae39a1ec2148d3e5d6f73d95e9b17910152d61f16264736f6c634300080c0033"
ETH_GENESIS_MULTICALL3_BALANCE="0x0"
ETH_GENESIS_MULTICALL3_NONCE="0x1"

# --- WBERA (Wrapped BERA) ---
# Address: 0x6969696969696969696969696969696969696969
# Purpose: ERC-20 wrapper for the native BERA token
# Allows BERA to be used in DeFi protocols that require ERC-20 tokens
# Equivalent to WETH on Ethereum
ETH_GENESIS_WBERA_ADDRESS="0x6969696969696969696969696969696969696969"
ETH_GENESIS_WBERA_CODE="0x6080604052600436106100dc575f3560e01c806370a082311161007c578063a9059cbb11610057578063a9059cbb14610365578063d0e30db014610384578063d505accf1461038c578063dd62ed3e146103ab575f80fd5b806370a08231146102be5780637ecebe00146102ef57806395d89b4114610320575f80fd5b806323b872dd116100b757806323b872dd1461019b5780632e1a7d4d146101ba578063313ce567146101d95780633644e515146101f4575f80fd5b806306fdde03146100ef578063095ea7b31461014657806318160ddd14610175575f80fd5b366100eb576100e96103df565b005b5f80fd5b3480156100fa575f80fd5b5060408051808201909152600c81527f577261707065642042657261000000000000000000000000000000000000000060208201525b60405161013d9190610865565b60405180910390f35b348015610151575f80fd5b506101656101603660046108e0565b6103eb565b604051901515815260200161013d565b348015610180575f80fd5b506805345cdf77eb68f44c545b60405190815260200161013d565b3480156101a6575f80fd5b506101656101b5366004610908565b61043a565b3480156101c5575f80fd5b506100e96101d4366004610942565b6104f2565b3480156101e4575f80fd5b506040516012815260200161013d565b3480156101ff575f80fd5b50604080518082018252600c81527f577261707065642042657261000000000000000000000000000000000000000060209182015281517f8b73c3c69bb8fe3d512ecc4cf759cc79239f7b179b0ffacaa9a75d522b39400f81527fb6c9387dd48cdde7d71a807357f57f1fef05232a4af3ed7fdf1f050c8e1a69fe918101919091527fc89efdaa54c0f20c7adf612882df0950f5a951637e0307cdcb4c672f298b8bc69181019190915246606082015230608082015260a0902061018d565b3480156102c9575f80fd5b5061018d6102d8366004610959565b6387a211a2600c9081525f91909152602090205490565b3480156102fa575f80fd5b5061018d610309366004610959565b6338377508600c9081525f91909152602090205490565b34801561032b575f80fd5b5060408051808201909152600581527f57424552410000000000000000000000000000000000000000000000000000006020820152610130565b348015610370575f80fd5b5061016561037f3660046108e0565b610518565b6100e96103df565b348015610397575f80fd5b506100e96103a6366004610979565b61058f565b3480156103b6575f80fd5b5061018d6103c53660046109e6565b602052637f5e9f20600c9081525f91909152603490205490565b6103e93334610768565b565b5f82602052637f5e9f20600c52335f52816034600c2055815f52602c5160601c337f8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b92560205fa350600192915050565b5f8360601b33602052637f5e9f208117600c526034600c2080548019156104765780851115610470576313be252b5f526004601cfd5b84810382555b50506387a211a28117600c526020600c2080548085111561049e5763f4d678b85f526004601cfd5b84810382555050835f526020600c208381540181555082602052600c5160601c8160601c7fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef602080a3505060019392505050565b6104fc33826107e4565b5f385f3884335af16105155763b12d13eb5f526004601cfd5b50565b5f6387a211a2600c52335f526020600c208054808411156105405763f4d678b85f526004601cfd5b83810382555050825f526020600c208281540181555081602052600c5160601c337fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef602080a350600192915050565b60408051808201909152600c81527f57726170706564204265726100000000000000000000000000000000000000006020909101527fb6c9387dd48cdde7d71a807357f57f1fef05232a4af3ed7fdf1f050c8e1a69fe7fc89efdaa54c0f20c7adf612882df0950f5a951637e0307cdcb4c672f298b8bc64286101561061b57631a15a3cc5f526004601cfd5b6040518960601b60601c99508860601b60601c985065383775081901600e52895f526020600c2080547f8b73c3c69bb8fe3d512ecc4cf759cc79239f7b179b0ffacaa9a75d522b39400f835284602084015283604084015246606084015230608084015260a08320602e527f6e71edae12b1b97f4d1f60370fef10105fa2faae0126114a169c64845d6126c983528b60208401528a60408401528960608401528060808401528860a084015260c08320604e526042602c205f528760ff16602052866040528560605260208060805f60015afa8c3d51146107035763ddafbaef5f526004601cfd5b019055777f5e9f20000000000000000000000000000000000000000089176040526034602c20889055888a7f8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925602060608501a360405250505f60605250505050505050565b6805345cdf77eb68f44c548181018181101561078b5763e5cfe9575f526004601cfd5b806805345cdf77eb68f44c5550506387a211a2600c52815f526020600c208181540181555080602052600c5160601c5f7fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef602080a35050565b6387a211a2600c52815f526020600c2080548083111561080b5763f4d678b85f526004601cfd5b82900390556805345cdf77eb68f44c805482900390555f81815273ffffffffffffffffffffffffffffffffffffffff83167fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef602083a35050565b602081525f82518060208401528060208501604085015e5f6040828501015260407fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0601f83011684010191505092915050565b803573ffffffffffffffffffffffffffffffffffffffff811681146108db575f80fd5b919050565b5f80604083850312156108f1575f80fd5b6108fa836108b8565b946020939093013593505050565b5f805f6060848603121561091a575f80fd5b610923846108b8565b9250610931602085016108b8565b929592945050506040919091013590565b5f60208284031215610952575f80fd5b5035919050565b5f60208284031215610969575f80fd5b610972826108b8565b9392505050565b5f805f805f805f60e0888a03121561098f575f80fd5b610998886108b8565b96506109a6602089016108b8565b95506040880135945060608801359350608088013560ff811681146109c9575f80fd5b9699959850939692959460a0840135945060c09093013592915050565b5f80604083850312156109f7575f80fd5b610a00836108b8565b9150610a0e602084016108b8565b9050925092905056fea164736f6c634300081a000a"
ETH_GENESIS_WBERA_BALANCE="0x0"
ETH_GENESIS_WBERA_NONCE="0x1"

# --- Permit2 (Uniswap) ---
# Address: 0x000000000022D473030F116dDEE9F6B43aC78BA3
# Purpose: Advanced token approval patterns for secure token transfers
# Standard deployment address used across all EVM chains
# Enables time-limited and granular allowances
ETH_GENESIS_PERMIT2_ADDRESS="0x000000000022D473030F116dDEE9F6B43aC78BA3"
ETH_GENESIS_PERMIT2_CODE="0x6040608081526004908136101561001557600080fd5b600090813560e01c80630d58b1db1461126c578063137c29fe146110755780632a2d80d114610db75780632b67b57014610bde57806330f28b7a14610ade5780633644e51514610a9d57806336c7851614610a285780633ff9dcb1146109a85780634fe02b441461093f57806365d9723c146107ac57806387517c451461067a578063927da105146105c3578063cc53287f146104a3578063edd9444b1461033a5763fe8ec1a7146100c657600080fd5b346103365760c07ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc3601126103365767ffffffffffffffff833581811161033257610114903690860161164b565b60243582811161032e5761012b903690870161161a565b6101336114e6565b9160843585811161032a5761014b9036908a016115c1565b98909560a43590811161032657610164913691016115c1565b969095815190610173826113ff565b606b82527f5065726d697442617463685769746e6573735472616e7366657246726f6d285460208301527f6f6b656e5065726d697373696f6e735b5d207065726d69747465642c61646472838301527f657373207370656e6465722c75696e74323536206e6f6e63652c75696e74323560608301527f3620646561646c696e652c000000000000000000000000000000000000000000608083015282519a8b9181610222602085018096611f93565b918237018a8152039961025b7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe09b8c8101835282611437565b5190209085515161026b81611ebb565b908a5b8181106102f95750506102f6999a6102ed9183516102a081610294602082018095611f66565b03848101835282611437565b519020602089810151858b015195519182019687526040820192909252336060820152608081019190915260a081019390935260643560c08401528260e081015b03908101835282611437565b51902093611cf7565b80f35b8061031161030b610321938c5161175e565b51612054565b61031b828661175e565b52611f0a565b61026e565b8880fd5b8780fd5b8480fd5b8380fd5b5080fd5b5091346103365760807ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc3601126103365767ffffffffffffffff9080358281116103325761038b903690830161164b565b60243583811161032e576103a2903690840161161a565b9390926103ad6114e6565b9160643590811161049f576103c4913691016115c1565b949093835151976103d489611ebb565b98885b81811061047d5750506102f697988151610425816103f9602082018095611f66565b037fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe08101835282611437565b5190206020860151828701519083519260208401947ffcf35f5ac6a2c28868dc44c302166470266239195f02b0ee408334829333b7668652840152336060840152608083015260a082015260a081526102ed8161141b565b808b61031b8261049461030b61049a968d5161175e565b9261175e565b6103d7565b8680fd5b5082346105bf57602090817ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc3601126103325780359067ffffffffffffffff821161032e576104f49136910161161a565b929091845b848110610504578580f35b8061051a610515600193888861196c565b61197c565b61052f84610529848a8a61196c565b0161197c565b3389528385528589209173ffffffffffffffffffffffffffffffffffffffff80911692838b528652868a20911690818a5285528589207fffffffffffffffffffffffff000000000000000000000000000000000000000081541690558551918252848201527f89b1add15eff56b3dfe299ad94e01f2b52fbcb80ae1a3baea6ae8c04cb2b98a4853392a2016104f9565b8280fd5b50346103365760607ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc36011261033657610676816105ff6114a0565b936106086114c3565b6106106114e6565b73ffffffffffffffffffffffffffffffffffffffff968716835260016020908152848420928816845291825283832090871683528152919020549251938316845260a083901c65ffffffffffff169084015260d09190911c604083015281906060820190565b0390f35b50346103365760807ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc360112610336576106b26114a0565b906106bb6114c3565b916106c46114e6565b65ffffffffffff926064358481169081810361032a5779ffffffffffff0000000000000000000000000000000000000000947fda9fa7c1b00402c17d0161b249b1ab8bbec047c5a52207b9c112deffd817036b94338a5260016020527fffffffffffff0000000000000000000000000000000000000000000000000000858b209873ffffffffffffffffffffffffffffffffffffffff809416998a8d5260205283878d209b169a8b8d52602052868c209486156000146107a457504216925b8454921697889360a01b16911617179055815193845260208401523392a480f35b905092610783565b5082346105bf5760607ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc3601126105bf576107e56114a0565b906107ee6114c3565b9265ffffffffffff604435818116939084810361032a57338852602091600183528489209673ffffffffffffffffffffffffffffffffffffffff80911697888b528452858a20981697888a5283528489205460d01c93848711156109175761ffff9085840316116108f05750907f55eb90d810e1700b35a8e7e25395ff7f2b2259abd7415ca2284dfb1c246418f393929133895260018252838920878a528252838920888a5282528389209079ffffffffffffffffffffffffffffffffffffffffffffffffffff7fffffffffffff000000000000000000000000000000000000000000000000000083549260d01b16911617905582519485528401523392a480f35b84517f24d35a26000000000000000000000000000000000000000000000000000000008152fd5b5084517f756688fe000000000000000000000000000000000000000000000000000000008152fd5b503461033657807ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc360112610336578060209273ffffffffffffffffffffffffffffffffffffffff61098f6114a0565b1681528084528181206024358252845220549051908152f35b5082346105bf57817ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc3601126105bf577f3704902f963766a4e561bbaab6e6cdc1b1dd12f6e9e99648da8843b3f46b918d90359160243533855284602052818520848652602052818520818154179055815193845260208401523392a280f35b8234610a9a5760807ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc360112610a9a57610a606114a0565b610a686114c3565b610a706114e6565b6064359173ffffffffffffffffffffffffffffffffffffffff8316830361032e576102f6936117a1565b80fd5b503461033657817ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc36011261033657602090610ad7611b1e565b9051908152f35b508290346105bf576101007ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc3601126105bf57610b1a3661152a565b90807fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff7c36011261033257610b4c611478565b9160e43567ffffffffffffffff8111610bda576102f694610b6f913691016115c1565b939092610b7c8351612054565b6020840151828501519083519260208401947f939c21a48a8dbe3a9a2404a1d46691e4d39f6583d6ec6b35714604c986d801068652840152336060840152608083015260a082015260a08152610bd18161141b565b51902091611c25565b8580fd5b509134610336576101007ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc36011261033657610c186114a0565b7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffdc360160c08112610332576080855191610c51836113e3565b1261033257845190610c6282611398565b73ffffffffffffffffffffffffffffffffffffffff91602435838116810361049f578152604435838116810361049f57602082015265ffffffffffff606435818116810361032a5788830152608435908116810361049f576060820152815260a435938285168503610bda576020820194855260c4359087830182815260e43567ffffffffffffffff811161032657610cfe90369084016115c1565b929093804211610d88575050918591610d786102f6999a610d7e95610d238851611fbe565b90898c511690519083519260208401947ff3841cd1ff0085026a6327b620b67997ce40f282c88a8e905a7a5626e310f3d086528401526060830152608082015260808152610d70816113ff565b519020611bd9565b916120c7565b519251169161199d565b602492508a51917fcd21db4f000000000000000000000000000000000000000000000000000000008352820152fd5b5091346103365760607ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc93818536011261033257610df36114a0565b9260249081359267ffffffffffffffff9788851161032a578590853603011261049f578051978589018981108282111761104a578252848301358181116103265785019036602383011215610326578382013591610e50836115ef565b90610e5d85519283611437565b838252602093878584019160071b83010191368311611046578801905b828210610fe9575050508a526044610e93868801611509565b96838c01978852013594838b0191868352604435908111610fe557610ebb90369087016115c1565b959096804211610fba575050508998995151610ed681611ebb565b908b5b818110610f9757505092889492610d7892610f6497958351610f02816103f98682018095611f66565b5190209073ffffffffffffffffffffffffffffffffffffffff9a8b8b51169151928551948501957faf1b0d30d2cab0380e68f0689007e3254993c596f2fdd0aaa7f4d04f794408638752850152830152608082015260808152610d70816113ff565b51169082515192845b848110610f78578580f35b80610f918585610f8b600195875161175e565b5161199d565b01610f6d565b80610311610fac8e9f9e93610fb2945161175e565b51611fbe565b9b9a9b610ed9565b8551917fcd21db4f000000000000000000000000000000000000000000000000000000008352820152fd5b8a80fd5b6080823603126110465785608091885161100281611398565b61100b85611509565b8152611018838601611509565b838201526110278a8601611607565b8a8201528d611037818701611607565b90820152815201910190610e7a565b8c80fd5b84896041867f4e487b7100000000000000000000000000000000000000000000000000000000835252fd5b5082346105bf576101407ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc3601126105bf576110b03661152a565b91807fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff7c360112610332576110e2611478565b67ffffffffffffffff93906101043585811161049f5761110590369086016115c1565b90936101243596871161032a57611125610bd1966102f6983691016115c1565b969095825190611134826113ff565b606482527f5065726d69745769746e6573735472616e7366657246726f6d28546f6b656e5060208301527f65726d697373696f6e73207065726d69747465642c6164647265737320737065848301527f6e6465722c75696e74323536206e6f6e63652c75696e7432353620646561646c60608301527f696e652c0000000000000000000000000000000000000000000000000000000060808301528351948591816111e3602085018096611f93565b918237018b8152039361121c7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe095868101835282611437565b5190209261122a8651612054565b6020878101518589015195519182019687526040820192909252336060820152608081019190915260a081019390935260e43560c08401528260e081016102e1565b5082346105bf576020807ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc36011261033257813567ffffffffffffffff92838211610bda5736602383011215610bda5781013592831161032e576024906007368386831b8401011161049f57865b8581106112e5578780f35b80821b83019060807fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffdc83360301126103265761139288876001946060835161132c81611398565b611368608461133c8d8601611509565b9485845261134c60448201611509565b809785015261135d60648201611509565b809885015201611509565b918291015273ffffffffffffffffffffffffffffffffffffffff80808093169516931691166117a1565b016112da565b6080810190811067ffffffffffffffff8211176113b457604052565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b6060810190811067ffffffffffffffff8211176113b457604052565b60a0810190811067ffffffffffffffff8211176113b457604052565b60c0810190811067ffffffffffffffff8211176113b457604052565b90601f7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0910116810190811067ffffffffffffffff8211176113b457604052565b60c4359073ffffffffffffffffffffffffffffffffffffffff8216820361149b57565b600080fd5b6004359073ffffffffffffffffffffffffffffffffffffffff8216820361149b57565b6024359073ffffffffffffffffffffffffffffffffffffffff8216820361149b57565b6044359073ffffffffffffffffffffffffffffffffffffffff8216820361149b57565b359073ffffffffffffffffffffffffffffffffffffffff8216820361149b57565b7ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc01906080821261149b576040805190611563826113e3565b8082941261149b57805181810181811067ffffffffffffffff8211176113b457825260043573ffffffffffffffffffffffffffffffffffffffff8116810361149b578152602435602082015282526044356020830152606435910152565b9181601f8401121561149b5782359167ffffffffffffffff831161149b576020838186019501011161149b57565b67ffffffffffffffff81116113b45760051b60200190565b359065ffffffffffff8216820361149b57565b9181601f8401121561149b5782359167ffffffffffffffff831161149b576020808501948460061b01011161149b57565b91909160608184031261149b576040805191611666836113e3565b8294813567ffffffffffffffff9081811161149b57830182601f8201121561149b578035611693816115ef565b926116a087519485611437565b818452602094858086019360061b8501019381851161149b579086899897969594939201925b8484106116e3575050505050855280820135908501520135910152565b90919293949596978483031261149b578851908982019082821085831117611730578a928992845261171487611509565b81528287013583820152815201930191908897969594936116c6565b602460007f4e487b710000000000000000000000000000000000000000000000000000000081526041600452fd5b80518210156117725760209160051b010190565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052603260045260246000fd5b92919273ffffffffffffffffffffffffffffffffffffffff604060008284168152600160205282828220961695868252602052818120338252602052209485549565ffffffffffff8760a01c16804211611884575082871696838803611812575b5050611810955016926118b5565b565b878484161160001461184f57602488604051907ff96fb0710000000000000000000000000000000000000000000000000000000082526004820152fd5b7fffffffffffffffffffffffff000000000000000000000000000000000000000084846118109a031691161790553880611802565b602490604051907fd81b2f2e0000000000000000000000000000000000000000000000000000000082526004820152fd5b9060006064926020958295604051947f23b872dd0000000000000000000000000000000000000000000000000000000086526004860152602485015260448401525af13d15601f3d116001600051141617161561190e57565b60646040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601460248201527f5452414e534645525f46524f4d5f4641494c45440000000000000000000000006044820152fd5b91908110156117725760061b0190565b3573ffffffffffffffffffffffffffffffffffffffff8116810361149b5790565b9065ffffffffffff908160608401511673ffffffffffffffffffffffffffffffffffffffff908185511694826020820151169280866040809401511695169560009187835260016020528383208984526020528383209916988983526020528282209184835460d01c03611af5579185611ace94927fc6a377bfc4eb120024a8ac08eef205be16b817020812c73223e81d1bdb9708ec98979694508715600014611ad35779ffffffffffff00000000000000000000000000000000000000009042165b60a01b167fffffffffffff00000000000000000000000000000000000000000000000000006001860160d01b1617179055519384938491604091949373ffffffffffffffffffffffffffffffffffffffff606085019616845265ffffffffffff809216602085015216910152565b0390a4565b5079ffffffffffff000000000000000000000000000000000000000087611a60565b600484517f756688fe000000000000000000000000000000000000000000000000000000008152fd5b467f00000000000000000000000000000000000000000000000000000000000138de03611b69577f1dc08c4ac637ae13fdbae95e53fb95942c41e44de89165404e5111c4e5b560ae90565b60405160208101907f8cad95687ba82c2ce50e74f7b754645e5117c3a5bec8151c0726d5857980a86682527f9ac997416e8ff9d2ff6bebeb7149f65cdae5e32e2b90440b566bb3044041d36a604082015246606082015230608082015260808152611bd3816113ff565b51902090565b611be1611b1e565b906040519060208201927f190100000000000000000000000000000000000000000000000000000000000084526022830152604282015260428152611bd381611398565b9192909360a435936040840151804211611cc65750602084510151808611611c955750918591610d78611c6594611c60602088015186611e47565b611bd9565b73ffffffffffffffffffffffffffffffffffffffff809151511692608435918216820361149b57611810936118b5565b602490604051907f3728b83d0000000000000000000000000000000000000000000000000000000082526004820152fd5b602490604051907fcd21db4f0000000000000000000000000000000000000000000000000000000082526004820152fd5b959093958051519560409283830151804211611e175750848803611dee57611d2e918691610d7860209b611c608d88015186611e47565b60005b868110611d42575050505050505050565b611d4d81835161175e565b5188611d5a83878a61196c565b01359089810151808311611dbe575091818888886001968596611d84575b50505050505001611d31565b611db395611dad9273ffffffffffffffffffffffffffffffffffffffff6105159351169561196c565b916118b5565b803888888883611d78565b6024908651907f3728b83d0000000000000000000000000000000000000000000000000000000082526004820152fd5b600484517fff633a38000000000000000000000000000000000000000000000000000000008152fd5b6024908551907fcd21db4f0000000000000000000000000000000000000000000000000000000082526004820152fd5b9073ffffffffffffffffffffffffffffffffffffffff600160ff83161b9216600052600060205260406000209060081c6000526020526040600020818154188091551615611e9157565b60046040517f756688fe000000000000000000000000000000000000000000000000000000008152fd5b90611ec5826115ef565b611ed26040519182611437565b8281527fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0611f0082946115ef565b0190602036910137565b7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff8114611f375760010190565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601160045260246000fd5b805160208092019160005b828110611f7f575050505090565b835185529381019392810192600101611f71565b9081519160005b838110611fab575050016000815290565b8060208092840101518185015201611f9a565b60405160208101917f65626cad6cb96493bf6f5ebea28756c966f023ab9e8a83a7101849d5573b3678835273ffffffffffffffffffffffffffffffffffffffff8082511660408401526020820151166060830152606065ffffffffffff9182604082015116608085015201511660a082015260a0815260c0810181811067ffffffffffffffff8211176113b45760405251902090565b6040516020808201927f618358ac3db8dc274f0cd8829da7e234bd48cd73c4a740aede1adec9846d06a1845273ffffffffffffffffffffffffffffffffffffffff81511660408401520151606082015260608152611bd381611398565b919082604091031261149b576020823592013590565b6000843b61222e5750604182036121ac576120e4828201826120b1565b939092604010156117725760209360009360ff6040608095013560f81c5b60405194855216868401526040830152606082015282805260015afa156121a05773ffffffffffffffffffffffffffffffffffffffff806000511691821561217657160361214c57565b60046040517f815e1d64000000000000000000000000000000000000000000000000000000008152fd5b60046040517f8baa579f000000000000000000000000000000000000000000000000000000008152fd5b6040513d6000823e3d90fd5b60408203612204576121c0918101906120b1565b91601b7f7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff84169360ff1c019060ff8211611f375760209360009360ff608094612102565b60046040517f4be6321b000000000000000000000000000000000000000000000000000000008152fd5b929391601f928173ffffffffffffffffffffffffffffffffffffffff60646020957fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0604051988997889687947f1626ba7e000000000000000000000000000000000000000000000000000000009e8f8752600487015260406024870152816044870152868601378b85828601015201168101030192165afa9081156123a857829161232a575b7fffffffff000000000000000000000000000000000000000000000000000000009150160361230057565b60046040517fb0669cbc000000000000000000000000000000000000000000000000000000008152fd5b90506020813d82116123a0575b8161234460209383611437565b810103126103365751907fffffffff0000000000000000000000000000000000000000000000000000000082168203610a9a57507fffffffff0000000000000000000000000000000000000000000000000000000090386122d4565b3d9150612337565b6040513d84823e3d90fdfea164736f6c6343000811000a"
ETH_GENESIS_PERMIT2_BALANCE="0x0"
ETH_GENESIS_PERMIT2_NONCE="0x1"

# --- BeaconDeposit Contract ---
# Address: 0x4242424242424242424242424242424242424242
# Purpose: Handles validator deposits for Berachain's Proof-of-Stake consensus
# Validators deposit BERA (min 10,000) to participate in consensus
# Events from this contract are used by the beacon chain for staking management
ETH_GENESIS_BEACON_DEPOSIT_ADDRESS="0x4242424242424242424242424242424242424242"
ETH_GENESIS_BEACON_DEPOSIT_CODE="0x608060405234801561001057600080fd5b50600436106100935760003560e01c8063621fd130116100665780636353586511610050578063635358651461011f578063c5f2892f14610132578063d2354e4a1461014557600080fd5b80637f8661a11461010c578063a38b4f4114610114575b600080fd5b6100a661009e36600461066c565b600092915050565b60405160ff90911681526020015b60405180910390f35b6100bd61015857610158565b60405190815260200161009e565b61010a6101083660046106df565b565b005b61010a61016957610169565b61010a61012236600461071f565b50565b61010a61013036600461078c565b565b6100bd6101403660046107f8565b610179565b61010a61015336600461080e565b600080fd5b600080fd5b50565b50565b600080fd5b600080fd5b919050565b600080fd5b505050565b50565b600080fd5b50565b50565b600080fd5b50565b600080fd5b6000806000604084860312156101a857600080fd5b833567ffffffffffffffff808211156101c057600080fd5b818601915086601f8301126101d457600080fd5b8135818111156101e357600080fd5b8760208285010111156101f557600080fd5b6020928301955093505084013561020b81610257565b809150509250925092565b60006020828403121561022857600080fd5b5035919050565b60006020828403121561024157600080fd5b813561024c81610257565b809150509291505056fea164736f6c6343000817000a"
ETH_GENESIS_BEACON_DEPOSIT_BALANCE="0x0"
ETH_GENESIS_BEACON_DEPOSIT_NONCE="0x1"
ETH_GENESIS_BEACON_DEPOSIT_STORAGE_KEY="0x0000000000000000000000000000000000000000000000000000000000000000,0x0000000000000000000000000000000000000000000000000000000000000001"
ETH_GENESIS_BEACON_DEPOSIT_STORAGE_VALUE="0x0000000000000000000000000000000000000000000000000000000000000000,0x0000000000000000000000000000000000000000000000000000000000000000"

# =============================================================================
# Prague Upgrade Configurations
# =============================================================================

# --- Prague1 ---
ETH_GENESIS_PRAGUE1_TIME=1756915200
ETH_GENESIS_PRAGUE1_BASE_FEE_CHANGE_DENOMINATOR=48
ETH_GENESIS_PRAGUE1_MIN_BASE_FEE=1000000000
ETH_GENESIS_PRAGUE1_POL_DISTRIBUTOR="0xD2f19a79b026Fb636A7c300bF5947df113940761"
# Empty on purpose
ETH_GENESIS_PRAGUE1_BEX_VAULT=
ETH_GENESIS_PRAGUE1_RESCUE_ADDRESS=
ETH_GENESIS_PRAGUE1_BLOCKED_ADDRESSES=

# --- Prague2 ---
ETH_GENESIS_PRAGUE2_TIME=1759248000
ETH_GENESIS_PRAGUE2_BASE_FEE_CHANGE_DENOMINATOR=
ETH_GENESIS_PRAGUE2_MIN_BASE_FEE=0
ETH_GENESIS_PRAGUE2_POL_DISTRIBUTOR=
ETH_GENESIS_PRAGUE2_BEX_VAULT=
ETH_GENESIS_PRAGUE2_RESCUE_ADDRESS=
ETH_GENESIS_PRAGUE2_BLOCKED_ADDRESSES=

# --- Prague3 ---
ETH_GENESIS_PRAGUE3_TIME=1762164459
ETH_GENESIS_PRAGUE3_BASE_FEE_CHANGE_DENOMINATOR=
ETH_GENESIS_PRAGUE3_MIN_BASE_FEE=
ETH_GENESIS_PRAGUE3_POL_DISTRIBUTOR=
ETH_GENESIS_PRAGUE3_BEX_VAULT="0x4be03f781c497a489e3cb0287833452ca9b9e80b"
ETH_GENESIS_PRAGUE3_RESCUE_ADDRESS="0xD276D30592bE512a418f2448e23f9E7F372b32A2"
ETH_GENESIS_PRAGUE3_BLOCKED_ADDRESSES="0xF8Bec8cB704b8BD427FD209A2058b396C4BC543e,0x0000000000000000000000000000000000000000"

# --- Prague4 ---
ETH_GENESIS_PRAGUE4_TIME=1762963200
ETH_GENESIS_PRAGUE4_BASE_FEE_CHANGE_DENOMINATOR=
ETH_GENESIS_PRAGUE4_MIN_BASE_FEE=
ETH_GENESIS_PRAGUE4_POL_DISTRIBUTOR=
ETH_GENESIS_PRAGUE4_BEX_VAULT=
ETH_GENESIS_PRAGUE4_RESCUE_ADDRESS=
ETH_GENESIS_PRAGUE4_BLOCKED_ADDRESSES=

# =============================================================================
# Default Beacond app.toml - See ./beacond/config/app.toml
# =============================================================================
readonly APPTOML_PRUNING="everything"
readonly APPTOML_PRUNING_KEEP_RECENT="0"
readonly APPTOML_PRUNING_INTERVAL="0"
readonly APPTOML_HALT_HEIGHT=0
readonly APPTOML_HALT_TIME=0
readonly APPTOML_MIN_RETAIN_BLOCKS=0
readonly APPTOML_INTER_BLOCK_CACHE=true
readonly APPTOML_INDEX_EVENTS=() # Ex: ["message.sender", "message.recipient"]
readonly APPTOML_IAVL_CACHE_SIZE=781250
readonly APPTOML_IAVL_DISABLE_FASTNODE=true
readonly APPTOML_APP_DB_BACKEND="pebbledb"

# Telemetry Configuration
readonly APPTOML_TELEMETRY_SERVICE_NAME="beacond_node"
readonly APPTOML_TELEMETRY_ENABLED=true
readonly APPTOML_TELEMETRY_ENABLE_HOSTNAME=true
readonly APPTOML_TELEMETRY_ENABLE_HOSTNAME_LABEL=true
readonly APPTOML_TELEMETRY_ENABLE_SERVICE_LABEL=true
readonly APPTOML_TELEMETRY_PROMETHEUS_RETENTION_TIME=60
readonly APPTOML_TELEMETRY_GLOBAL_LABELS="" # Ex: "chain_id,cosmoshub-1"
readonly APPTOML_TELEMETRY_METRICS_SINK=""
readonly APPTOML_TELEMETRY_STATSD_ADDR=""
readonly APPTOML_TELEMETRY_DATADOG_HOSTNAME="my_beacond_node"

# BeaconKit Configuration
readonly APPTOML_BEACON_KIT_CHAIN_SPEC="devnet" # Ex: "devnet" | "testnet" | "mainnet"
readonly APPTOML_BEACON_KIT_CHAIN_SPEC_FILE=""  # Ex: "./testing/networks/80094/chain-spec.json"
readonly APPTOML_BEACON_KIT_SHUTDOWN_TIMEOUT="5m0s"

# BeaconKit Engine Configuration
readonly APPTOML_BEACON_KIT_ENGINE_RPC_DIAL_URL="http://localhost:8551"
readonly APPTOML_BEACON_KIT_ENGINE_RPC_TIMEOUT="2s"
readonly APPTOML_BEACON_KIT_ENGINE_RPC_RETRY_INTERVAL="100ms"
readonly APPTOML_BEACON_KIT_ENGINE_RPC_MAX_RETRY_INTERVAL="10s"
readonly APPTOML_BEACON_KIT_ENGINE_RPC_STARTUP_CHECK_INTERVAL="3s"
readonly APPTOML_BEACON_KIT_ENGINE_RPC_JWT_REFRESH_INTERVAL="30s"
readonly APPTOML_BEACON_KIT_ENGINE_JWT_SECRET_PATH="~/config/jwt.hex"

# BeaconKit Logger Configuration
readonly APPTOML_BEACON_KIT_LOGGER_TIME_FORMAT="RFC3339"
readonly APPTOML_BEACON_KIT_LOGGER_LOG_LEVEL="info"
readonly APPTOML_BEACON_KIT_LOGGER_STYLE="pretty"

# BeaconKit KZG Configuration
readonly APPTOML_BEACON_KIT_KZG_TRUSTED_SETUP_PATH="~/config/kzg-trusted-setup.json"
readonly APPTOML_BEACON_KIT_KZG_IMPLEMENTATION="crate-crypto/go-kzg-4844"

# BeaconKit Payload Builder Configuration
readonly APPTOML_BEACON_KIT_PAYLOAD_BUILDER_ENABLED=true
readonly APPTOML_BEACON_KIT_PAYLOAD_BUILDER_SUGGESTED_FEE_RECIPIENT="0x0000000000000000000000000000000000000000"
readonly APPTOML_BEACON_KIT_PAYLOAD_BUILDER_PAYLOAD_TIMEOUT="850ms"

# BeaconKit Validator Configuration
readonly APPTOML_BEACON_KIT_VALIDATOR_GRAFFITI=""
readonly APPTOML_BEACON_KIT_VALIDATOR_AVAILABILITY_WINDOW="8192"

# BeaconKit Node API Configuration
readonly APPTOML_BEACON_KIT_NODE_API_ENABLED="true"
readonly APPTOML_BEACON_KIT_NODE_API_ADDRESS="0.0.0.0:3500"
readonly APPTOML_BEACON_KIT_NODE_API_LOGGING="true"

# =============================================================================
# Default Beacond client.toml - See ./beacond/config/client.toml
# =============================================================================

readonly CLIENTTOML_CHAIN_ID="devnet-beacon-80087"
readonly CLIENTTOML_KEYRING_BACKEND="test"
readonly CLIENTTOML_KEYRING_DEFAULT_KEYNAME=""
readonly CLIENTTOML_OUTPUT="text"
readonly CLIENTTOML_NODE="tcp://localhost:26657"
readonly CLIENTTOML_BROADCAST_MODE="sync"
readonly CLIENTTOML_GRPC_ADDRESS=""
readonly CLIENTTOML_GRPC_INSECURE=false

# =============================================================================
# Default Beacond config.toml - See ./beacond/config/config.toml
# =============================================================================

# Main Base Config
readonly CONFIGTOML_VERSION="1.0.1"
readonly CONFIGTOML_PROXY_APP="tcp://127.0.0.1:26658"
readonly CONFIGTOML_MONIKER="beranode-<MONIKER>"
readonly CONFIGTOML_DB_BACKEND="pebbledb"
readonly CONFIGTOML_DB_DIR="data"
readonly CONFIGTOML_LOG_LEVEL="info"
readonly CONFIGTOML_LOG_FORMAT="plain"
readonly CONFIGTOML_GENESIS_FILE="config/genesis.json"
readonly CONFIGTOML_PRIV_VALIDATOR_KEY_FILE="config/priv_validator_key.json"
readonly CONFIGTOML_PRIV_VALIDATOR_STATE_FILE="data/priv_validator_state.json"
readonly CONFIGTOML_PRIV_VALIDATOR_LADDR=""
readonly CONFIGTOML_NODE_KEY_FILE="config/node_key.json"
readonly CONFIGTOML_ABCI="socket"
readonly CONFIGTOML_FILTER_PEERS=false

# RPC Server Configuration
readonly CONFIGTOML_RPC_LADDR="tcp://127.0.0.1:26657"
readonly CONFIGTOML_RPC_CORS_ALLOWED_ORIGINS=()
readonly CONFIGTOML_RPC_CORS_ALLOWED_METHODS=("HEAD" "GET" "POST")
readonly CONFIGTOML_RPC_CORS_ALLOWED_HEADERS=("Origin" "Accept" "Content-Type" "X-Requested-With" "X-Server-Time")
readonly CONFIGTOML_RPC_UNSAFE=false
readonly CONFIGTOML_RPC_MAX_OPEN_CONNECTIONS=900
readonly CONFIGTOML_RPC_MAX_SUBSCRIPTION_CLIENTS=100
readonly CONFIGTOML_RPC_MAX_SUBSCRIPTIONS_PER_CLIENT=5
readonly CONFIGTOML_RPC_EXPERIMENTAL_SUBSCRIPTION_BUFFER_SIZE=200
readonly CONFIGTOML_RPC_EXPERIMENTAL_WEBSOCKET_WRITE_BUFFER_SIZE=200
readonly CONFIGTOML_RPC_EXPERIMENTAL_CLOSE_ON_SLOW_CLIENT=false
readonly CONFIGTOML_RPC_TIMEOUT_BROADCAST_TX_COMMIT="10s"
readonly CONFIGTOML_RPC_MAX_REQUEST_BATCH_SIZE=10
readonly CONFIGTOML_RPC_MAX_BODY_BYTES=1000000
readonly CONFIGTOML_RPC_MAX_HEADER_BYTES=1048576
readonly CONFIGTOML_RPC_TLS_CERT_FILE=""
readonly CONFIGTOML_RPC_TLS_KEY_FILE=""
readonly CONFIGTOML_RPC_PPROF_LADDR=""

# gRPC Server Configuration
readonly CONFIGTOML_GRPC_LADDR=""
readonly CONFIGTOML_GRPC_VERSION_SERVICE_ENABLED=true
readonly CONFIGTOML_GRPC_BLOCK_SERVICE_ENABLED=true
readonly CONFIGTOML_GRPC_BLOCK_RESULTS_SERVICE_ENABLED=true
readonly CONFIGTOML_GRPC_PRIVILEGED_LADDR=""
readonly CONFIGTOML_GRPC_PRIVILEGED_PRUNING_SERVICE_ENABLED=false

# P2P Configuration
readonly CONFIGTOML_P2P_LADDR="tcp://0.0.0.0:26656"
readonly CONFIGTOML_P2P_EXTERNAL_ADDRESS=""
readonly CONFIGTOML_P2P_SEEDS=""
readonly CONFIGTOML_P2P_PERSISTENT_PEERS=""
readonly CONFIGTOML_P2P_ADDR_BOOK_FILE="config/addrbook.json"
# must be set to false for multiple nodes on the same machine
readonly CONFIGTOML_P2P_ADDR_BOOK_STRICT=false
readonly CONFIGTOML_P2P_MAX_NUM_INBOUND_PEERS=40
readonly CONFIGTOML_P2P_MAX_NUM_OUTBOUND_PEERS=10
readonly CONFIGTOML_P2P_UNCONDITIONAL_PEER_IDS=""
readonly CONFIGTOML_P2P_PERSISTENT_PEERS_MAX_DIAL_PERIOD="0s"
readonly CONFIGTOML_P2P_FLUSH_THROTTLE_TIMEOUT="10ms"
readonly CONFIGTOML_P2P_MAX_PACKET_MSG_PAYLOAD_SIZE=1024
readonly CONFIGTOML_P2P_SEND_RATE=5120000
readonly CONFIGTOML_P2P_RECV_RATE=5120000
readonly CONFIGTOML_P2P_PEX=true
readonly CONFIGTOML_P2P_SEED_MODE=false
readonly CONFIGTOML_P2P_PRIVATE_PEER_IDS=""
# must be set to true for multiple nodes on the same machine
readonly CONFIGTOML_P2P_ALLOW_DUPLICATE_IP=true
readonly CONFIGTOML_P2P_HANDSHAKE_TIMEOUT="20s"
readonly CONFIGTOML_P2P_DIAL_TIMEOUT="3s"

# Mempool Configuration
readonly CONFIGTOML_MEMPOOL_TYPE="nop"
readonly CONFIGTOML_MEMPOOL_RECHECK=false
readonly CONFIGTOML_MEMPOOL_RECHECK_TIMEOUT="0s"
readonly CONFIGTOML_MEMPOOL_BROADCAST=false
readonly CONFIGTOML_MEMPOOL_WAL_DIR=""
readonly CONFIGTOML_MEMPOOL_SIZE=0
readonly CONFIGTOML_MEMPOOL_MAX_TX_BYTES=0
readonly CONFIGTOML_MEMPOOL_MAX_TXS_BYTES=0
readonly CONFIGTOML_MEMPOOL_CACHE_SIZE=0
readonly CONFIGTOML_MEMPOOL_KEEP_INVALID_TXS_IN_CACHE=false
readonly CONFIGTOML_MEMPOOL_EXPERIMENTAL_MAX_GOSSIP_CONNECTIONS_TO_PERSISTENT_PEERS=0
readonly CONFIGTOML_MEMPOOL_EXPERIMENTAL_MAX_GOSSIP_CONNECTIONS_TO_NON_PERSISTENT_PEERS=0

# State Sync Configuration
readonly CONFIGTOML_STATESYNC_ENABLE=false
readonly CONFIGTOML_STATESYNC_RPC_SERVERS=""
readonly CONFIGTOML_STATESYNC_TRUST_HEIGHT=0
readonly CONFIGTOML_STATESYNC_TRUST_HASH=""
readonly CONFIGTOML_STATESYNC_TRUST_PERIOD="168h0m0s"
readonly CONFIGTOML_STATESYNC_DISCOVERY_TIME="15s"
readonly CONFIGTOML_STATESYNC_TEMP_DIR=""
readonly CONFIGTOML_STATESYNC_CHUNK_REQUEST_TIMEOUT="10s"
readonly CONFIGTOML_STATESYNC_CHUNK_FETCHERS="4"

# Block Sync Configuration
readonly CONFIGTOML_BLOCKSYNC_VERSION="v0"

# Consensus Configuration
readonly CONFIGTOML_CONSENSUS_WAL_FILE="data/cs.wal/wal"
readonly CONFIGTOML_CONSENSUS_TIMEOUT_PROPOSE="2s"
readonly CONFIGTOML_CONSENSUS_TIMEOUT_PROPOSE_DELTA="500ms"
readonly CONFIGTOML_CONSENSUS_TIMEOUT_PREVOTE="2s"
readonly CONFIGTOML_CONSENSUS_TIMEOUT_PREVOTE_DELTA="500ms"
readonly CONFIGTOML_CONSENSUS_TIMEOUT_PRECOMMIT="2s"
readonly CONFIGTOML_CONSENSUS_TIMEOUT_PRECOMMIT_DELTA="500ms"
readonly CONFIGTOML_CONSENSUS_TIMEOUT_COMMIT="0s"
readonly CONFIGTOML_CONSENSUS_SKIP_TIMEOUT_COMMIT=false
readonly CONFIGTOML_CONSENSUS_DOUBLE_SIGN_CHECK_HEIGHT=0
readonly CONFIGTOML_CONSENSUS_CREATE_EMPTY_BLOCKS=true
readonly CONFIGTOML_CONSENSUS_CREATE_EMPTY_BLOCKS_INTERVAL="0s"
readonly CONFIGTOML_CONSENSUS_PEER_GOSSIP_SLEEP_DURATION="100ms"
readonly CONFIGTOML_CONSENSUS_PEER_GOSSIP_INTRALOOP_SLEEP_DURATION="0s"
readonly CONFIGTOML_CONSENSUS_PEER_QUERY_MAJ23_SLEEP_DURATION="2s"

# Storage Configuration
readonly CONFIGTOML_STORAGE_DISCARD_ABCI_RESPONSES=true
readonly CONFIGTOML_STORAGE_EXPERIMENTAL_DB_KEY_LAYOUT="v1"
readonly CONFIGTOML_STORAGE_COMPACT=false
readonly CONFIGTOML_STORAGE_COMPACTION_INTERVAL="1000"
readonly CONFIGTOML_STORAGE_PRUNING_INTERVAL="10s"
readonly CONFIGTOML_STORAGE_PRUNING_DATA_COMPANION_ENABLED=false
readonly CONFIGTOML_STORAGE_PRUNING_DATA_COMPANION_INITIAL_BLOCK_RETAIN_HEIGHT=0
readonly CONFIGTOML_STORAGE_PRUNING_DATA_COMPANION_INITIAL_BLOCK_RESULTS_RETAIN_HEIGHT=0

# Transaction Indexer Configuration
readonly CONFIGTOML_TX_INDEX_INDEXER="null"
readonly CONFIGTOML_TX_INDEX_PSQL_CONN=""

# Instrumentation Configuration
readonly CONFIGTOML_INSTRUMENTATION_PROMETHEUS=true
readonly CONFIGTOML_INSTRUMENTATION_PROMETHEUS_LISTEN_ADDR=":26660"
readonly CONFIGTOML_INSTRUMENTATION_MAX_OPEN_CONNECTIONS=800
readonly CONFIGTOML_INSTRUMENTATION_NAMESPACE="cometbft"
