# =============================================================================
# Start Command - Beranode CLI v0.9.0
# =============================================================================
# This module implements the 'start' command for the Beranode CLI tool.
# It orchestrates the startup of Berachain nodes (validators, full nodes, or
# pruned nodes) based on the configuration specified in beranodes.config.json.
#
# EXECUTION FLOW LEGEND:
# ----------------------
# [1] Parse command-line arguments and validate beranodes directory
# [2] Locate and validate beranodes.config.json configuration file
# [3] Parse configuration and extract node parameters
# [4] Validate network type (devnet, testnet, mainnet)
# [5] Download required artifacts (KZG trusted setup, genesis files)
# [6] Initialize node directories and configuration files
# [7] Start nodes based on role (validator, full node, or pruned node)
# [8] Monitor node health and report status
#
# VERSION HISTORY:
# ----------------
# v0.9.0 - Current version
#        - Added --help command support
#        - Enhanced version management with semantic versioning
#        - Improved error handling and validation
#        - Standardized logging output
#
# DEPENDENCIES:
# -------------
# - jq (JSON parsing)
# - beacond binary (consensus layer)
# - bera-reth binary (execution layer)
# - beranodes.config.json (configuration file)
#
# =============================================================================

# =============================================================================
# [SECTION 1] Help Documentation
# =============================================================================
# Displays comprehensive usage information for the start command.
# Invoked via: beranode start --help
# =============================================================================

show_start_help() {
	cat <<EOF
Usage: beranode start [OPTIONS]

Start Berachain nodes based on the configuration file.

In docker mode, uses docker compose. In local mode, starts binaries in the
background and records PIDs. In serviceman mode, installs and starts launchd
jobs (macOS user LaunchAgents); logs go to beranodes/logs/.

Options:
  --beranodes-dir <path>    Specify the beranodes directory path
                            (default: \$PWD/beranodes)
  --external-ip <ip>        Public IP advertised to peers (public networks)
  --bootnodes <enodes>      Comma-separated EL bootnodes (public networks omit
                            --bootnodes unless this is set)
  --trusted-peers <enodes>  Comma-separated EL trusted peers (public networks
                            omit --trusted-peers unless this is set)
  --ws                      Enable the EL websocket RPC (--ws, --ws.addr,
                            --ws.port, --ws.origins). Omitted unless set
  --ws.addr <addr>          Websocket bind address (requires --ws;
                            default: 0.0.0.0)
  --ws.port <port>          Websocket port (requires --ws; default: 8546
                            or the node's el_ws_port)
  --ws.origin <origins>     Websocket allowed origins (requires --ws;
                            default: *). Alias: --ws.origins
  --logs-reset              Remove existing files in beranodes/logs without
                            prompting (answers y to the log-reset prompt)
  --help|-h                 Display this help message

Examples:
  beranode start
  beranode start --beranodes-dir /custom/path
  beranode start --ws
  beranode start --logs-reset
  beranode start --help

EOF
}

################################################################################
# Helper: print_port_section
# Description: Prints a titled group of port keys from a node config object.
################################################################################
print_port_section() {
	local node_json="$1"
	local title="$2"
	shift 2
	local key value printed=false

	for key in "$@"; do
		value=$(printf '%s\n' "$node_json" | jq -r --arg k "$key" 'if has($k) and .[$k] != null then .[$k] else empty end')
		if [[ -n "$value" ]]; then
			if [[ "$printed" == false ]]; then
				echo "-- ${title} --"
				printed=true
			fi
			echo "${key}: ${value}"
		fi
	done
}

################################################################################
# Helper: print_node_ports
# Description: Prints the listening ports for a node, grouped by component.
################################################################################
print_node_ports() {
	local node_json="$1"

	echo "--------------------------------"
	echo "Ports"
	echo "--------------------------------"
	print_port_section "$node_json" "bera-reth" \
		ethrpc_port ethp2p_port ethproxy_port \
		el_ethrpc_port el_ws_port el_authrpc_port el_eth_port el_prometheus_port
	print_port_section "$node_json" "beacon-kit" \
		cl_prometheus_port beacond_node_port \
		configtoml_grpc_laddr configtoml_grpc_privileged_laddr
}

# Starts a native process either in the background (local) or via launchd (serviceman).
# $1 mode  $2 beranodes_dir  $3 base_moniker  $4 node_index  $5 component
# $6 working_dir  $7 log_file  $8 pid_file  $9... argv
_start_native_process() {
	local mode="$1"
	local beranodes_dir="$2"
	local base_moniker="$3"
	local node_index="$4"
	local component="$5"
	local working_dir="$6"
	local log_file="$7"
	local pid_file="$8"
	shift 8

	if [[ "${mode}" == "serviceman" ]]; then
		serviceman_start_service \
			"${beranodes_dir}" \
			"${base_moniker}" \
			"${node_index}" \
			"${component}" \
			"${working_dir}" \
			"${log_file}" \
			"$@" || return 1
	else
		"$@" &>"${log_file}" &
		echo "$!" >"${pid_file}"
	fi
}

# =============================================================================
# [SECTION 1.5] Docker Compose Generator
# =============================================================================
# Generates a docker-compose.yml file for orchestrating multi-node deployments
# in Docker mode. Creates a shared network for inter-container communication.
# =============================================================================

# generate_docker_compose - Creates docker-compose.yml from beranodes.config.json
#
# Arguments:
#   $1 - beranodes_dir: Path to the beranodes directory
#   $2 - config_json_path: Path to beranodes.config.json
#   $3 - docker_beacond_tag: Docker image tag for beacond
#   $4 - docker_berareth_tag: Docker image tag for bera-reth
#   $5 - explicit_bootnodes: Optional --bootnodes override
#   $6 - explicit_trusted_peers: Optional --trusted-peers override
#   $7 - enable_ws: "true" to include --ws and related flags
#   $8 - explicit_ws_addr: Optional --ws.addr override
#   $9 - explicit_ws_port: Optional --ws.port override
#   $10 - explicit_ws_origins: Optional --ws.origin override
#
# Output:
#   Creates docker-compose.yml in beranodes/tmp/
#
generate_docker_compose() {
	local beranodes_dir="$1"
	local config_json_path="$2"
	local docker_beacond_tag="$3"
	local docker_berareth_tag="$4"
	local explicit_bootnodes="${5:-}"
	local explicit_trusted_peers="${6:-}"
	local enable_ws="${7:-false}"
	local explicit_ws_addr="${8:-}"
	local explicit_ws_port="${9:-}"
	local explicit_ws_origins="${10:-}"
	
	local compose_file="${beranodes_dir}/tmp/docker-compose.yml"
	local nodes_count=$(jq -r '.total_nodes' "${config_json_path}")
	local nodes=$(jq -c '.nodes' "${config_json_path}")
	local base_moniker=$(jq -r '.moniker' "${config_json_path}")
	local compose_network=$(jq -r '.network' "${config_json_path}")
	local snapshot_override
	snapshot_override=$(jq -r '.snapshot_type // empty' "${config_json_path}")
	local reth_chain_value="/root/.bera-reth/eth-genesis.json"
	if is_public_network "${compose_network}"; then
		reth_chain_value="$(network_reth_chain "${compose_network}")"
	fi
	
	log_info "Generating docker-compose.yml for ${nodes_count} node(s)..."
	
	# Start the docker-compose.yml file
	cat > "${compose_file}" <<EOF
version: '3.8'

# =============================================================================
# Beranode Docker Compose Configuration
# Generated by beranode CLI v${BERANODE_VERSION}
# Moniker: ${base_moniker}
# Nodes: ${nodes_count}
# =============================================================================

services:
EOF

	# Generate services for each node
	for ((node_index = 0; node_index < nodes_count; node_index++)); do
		local node_json=$(echo "${nodes}" | jq -r ".[$node_index]")
		local role=$(echo "${node_json}" | jq -r '.role')
		local moniker=$(echo "${node_json}" | jq -r '.moniker')
		
		# Get role short name for service naming
		local role_short="${role}"
		if [[ "${role}" == "validator" ]]; then
			role_short="val"
		elif [[ "${role}" == "full_node" ]]; then
			role_short="full"
		elif [[ "${role}" == "pruned_node" ]]; then
			role_short="pruned"
		fi
		
		# Service name prefix
		local service_prefix="${node_index}-${role_short}"
		
		# Get ports from config (these will be exposed to host)
		local ethrpc_port=$(echo "${node_json}" | jq -r '.ethrpc_port')
		local ethp2p_port=$(echo "${node_json}" | jq -r '.ethp2p_port')
		local ethproxy_port=$(echo "${node_json}" | jq -r '.ethproxy_port')
		local el_ethrpc_port=$(echo "${node_json}" | jq -r '.el_ethrpc_port')
		local el_ws_port=$(echo "${node_json}" | jq -r '.el_ws_port')
		local el_authrpc_port=$(echo "${node_json}" | jq -r '.el_authrpc_port')
		local el_eth_port=$(echo "${node_json}" | jq -r '.el_eth_port')
		local el_prometheus_port=$(echo "${node_json}" | jq -r '.el_prometheus_port')
		local cl_prometheus_port=$(echo "${node_json}" | jq -r '.cl_prometheus_port')
		local beacond_node_port=$(echo "${node_json}" | jq -r '.beacond_node_port')
		
		# Get peer info for bera-reth
		local berareth_private_key=$(echo "${node_json}" | jq -r '.berareth_config.private_key')
		
		# Build bootnodes and trusted-peers for bera-reth (excluding self)
		local berareth_bootnodes=""
		local berareth_trusted_peers=""
		if [[ ${nodes_count} -gt 1 ]]; then
			local bootnode_list=()
			for ((other_idx = 0; other_idx < nodes_count; other_idx++)); do
				if [[ ${other_idx} -ne ${node_index} ]]; then
					local other_node=$(echo "${nodes}" | jq -r ".[$other_idx]")
					local other_role=$(echo "${other_node}" | jq -r '.role')
					local other_role_short="${other_role}"
					if [[ "${other_role}" == "validator" ]]; then
						other_role_short="val"
					elif [[ "${other_role}" == "full_node" ]]; then
						other_role_short="full"
					fi
					local other_pubkey=$(echo "${other_node}" | jq -r '.berareth_config.public_key')
					# Use Docker service name and internal port (30303)
					bootnode_list+=("enode://${other_pubkey}@${other_idx}-${other_role_short}-bera-reth:30303")
				fi
			done
			berareth_bootnodes=$(IFS=,; echo "${bootnode_list[*]}")
			berareth_trusted_peers="${berareth_bootnodes}"
		fi
		berareth_bootnodes="$(resolve_reth_enodes "${compose_network}" "${berareth_bootnodes}" "${explicit_bootnodes}")"
		berareth_trusted_peers="$(resolve_reth_enodes "${compose_network}" "${berareth_trusted_peers}" "${explicit_trusted_peers}")"
		
		# =================================================================
		# Generate bera-reth service (execution layer - starts first)
		# =================================================================
		cat >> "${compose_file}" <<EOF
  # ---------------------------------------------------------------------------
  # Node ${node_index} - ${role} - Execution Layer (bera-reth)
  # ---------------------------------------------------------------------------
  ${service_prefix}-bera-reth:
    image: docker-bera-reth:${docker_berareth_tag}
    container_name: ${service_prefix}-${base_moniker}-bera-reth
    restart: unless-stopped
    networks:
      - beranet
    ports:
      - "${el_ethrpc_port}:8545"
EOF
		if [[ "${enable_ws}" == "true" ]]; then
			local ws_host_port="${explicit_ws_port:-${el_ws_port}}"
			local ws_listen_port="${explicit_ws_port:-8546}"
			cat >> "${compose_file}" <<EOF
      - "${ws_host_port}:${ws_listen_port}"
EOF
		fi
		cat >> "${compose_file}" <<EOF
      - "${el_eth_port}:30303"
      - "${el_eth_port}:30303/udp"
      - "${el_prometheus_port}:9001"
    volumes:
      - ${beranodes_dir}/nodes/${node_index}-${role}/bera-reth:/root/.bera-reth
    command:
      - bera-reth
      - node
EOF
		if [[ -n "${berareth_bootnodes}" ]]; then
			cat >> "${compose_file}" <<EOF
      - --bootnodes=${berareth_bootnodes}
EOF
		fi
		if [[ -n "${berareth_trusted_peers}" ]]; then
			cat >> "${compose_file}" <<EOF
      - --trusted-peers=${berareth_trusted_peers}
EOF
		fi
		if ! is_public_network "${compose_network}"; then
			cat >> "${compose_file}" <<EOF
      - --disable-dns-discovery
EOF
		fi

		local reth_full_line=""
		if is_public_network "${compose_network}" && reth_uses_pruning "${role}" "${snapshot_override}"; then
			reth_full_line=$'      - --full\n'
		fi
		
		cat >> "${compose_file}" <<EOF
      - --authrpc.addr=0.0.0.0
      - --authrpc.port=8551
      - --authrpc.jwtsecret=/root/.bera-reth/jwt.hex
      - --chain=${reth_chain_value}
${reth_full_line}      - --datadir=/root/.bera-reth
      - --discovery.port=30303
      - --engine.persistence-threshold=0
      - --engine.memory-block-buffer-target=0
      - --http
      - --http.api=admin,debug,eth,net,trace,txpool,web3,rpc,reth,ots,flashbots,miner,mev
      - --http.addr=0.0.0.0
      - --http.port=8545
      - --http.corsdomain=*
      - --port=30303
EOF
		if [[ "${enable_ws}" == "true" ]]; then
			local ws_flag
			while IFS= read -r ws_flag; do
				[[ -z "${ws_flag}" ]] && continue
				cat >> "${compose_file}" <<EOF
      - ${ws_flag}
EOF
			done <<< "$(format_reth_ws_flags true "${explicit_ws_addr}" "${explicit_ws_port}" "${explicit_ws_origins}" 8546)"
		fi
		cat >> "${compose_file}" <<EOF
    healthcheck:
      test: ["CMD-SHELL", "curl -sf -X POST -H 'Content-Type: application/json' -d '{\"jsonrpc\":\"2.0\",\"method\":\"eth_blockNumber\",\"params\":[],\"id\":1}' http://localhost:8545 || exit 1"]
      interval: 10s
      timeout: 5s
      retries: 5
      start_period: 30s

EOF

		# Build persistent_peers for beacond (excluding self)
		local beacond_peers=""
		if [[ ${nodes_count} -gt 1 ]]; then
			local peer_list=()
			for ((other_idx = 0; other_idx < nodes_count; other_idx++)); do
				if [[ ${other_idx} -ne ${node_index} ]]; then
					local other_node=$(echo "${nodes}" | jq -r ".[$other_idx]")
					local other_role=$(echo "${other_node}" | jq -r '.role')
					local other_role_short="${other_role}"
					if [[ "${other_role}" == "validator" ]]; then
						other_role_short="val"
					elif [[ "${other_role}" == "full_node" ]]; then
						other_role_short="full"
					fi
					local other_node_id=$(echo "${other_node}" | jq -r '.beacond_config.node_id')
					# Use Docker service name and internal port (26656)
					peer_list+=("${other_node_id}@${other_idx}-${other_role_short}-beacond:26656")
				fi
			done
			beacond_peers=$(IFS=,; echo "${peer_list[*]}")
		fi

		# =================================================================
		# Generate beacond service (consensus layer - depends on bera-reth)
		# =================================================================
		cat >> "${compose_file}" <<EOF
  # ---------------------------------------------------------------------------
  # Node ${node_index} - ${role} - Consensus Layer (beacond)
  # ---------------------------------------------------------------------------
  ${service_prefix}-beacond:
    image: docker-beacond:${docker_beacond_tag}
    container_name: ${service_prefix}-${base_moniker}-beacond
    restart: unless-stopped
    depends_on:
      ${service_prefix}-bera-reth:
        condition: service_healthy
    networks:
      - beranet
    ports:
      - "${ethrpc_port}:26657"
      - "${ethp2p_port}:26656"
      - "${ethproxy_port}:26658"
      - "${cl_prometheus_port}:26660"
      - "${beacond_node_port}:3500"
    volumes:
      - ${beranodes_dir}/nodes/${node_index}-${role}/beacond:/root/.beacond
    command:
      - beacond
      - start
      - --home=/root/.beacond
    environment:
      - BEACOND_MONIKER=${moniker}

EOF
	done

	# Add the network definition at the end
	cat >> "${compose_file}" <<EOF
# =============================================================================
# Docker Network Configuration
# =============================================================================
networks:
  beranet:
    driver: bridge
    name: beranet
    ipam:
      driver: default
      config:
        - subnet: 172.28.0.0/16
EOF

	log_success "Generated docker-compose.yml at ${compose_file}"
	return 0
}

# =============================================================================
# [SECTION 2] Main Start Command Function
# =============================================================================
# Primary entry point for the start command. Orchestrates the entire node
# startup process from configuration parsing to node initialization.
# =============================================================================

cmd_start() {
	# Enable debug output if DEBUG_MODE is set
	[[ "$DEBUG_MODE" == "true" ]] && echo "[DEBUG] Function: cmd_start" >&2

	# -------------------------------------------------------------------------
	# [STEP 1] Command-Line Argument Parsing
	# -------------------------------------------------------------------------
	# Parse and validate command-line options. Supports:
	# - --beranodes-dir: Custom directory for node data
	# - --logs-reset: Remove existing log files without prompting
	# - --help/-h: Display help information
	# -------------------------------------------------------------------------

	local beranodes_dir="${BERANODES_PATH_DEFAULT}"
	local external_ip=""
	local explicit_bootnodes=""
	local explicit_trusted_peers=""
	local enable_ws="false"
	local explicit_ws_addr=""
	local explicit_ws_port=""
	local explicit_ws_origins=""
	local logs_reset="false"

	while [[ $# -gt 0 ]]; do
		case $1 in
		--beranodes-dir)
			beranodes_dir=$(parse_beranodes_dir "$2")
			shift 2
			;;
		--external-ip)
			if [[ -n "${2:-}" ]]; then
				external_ip="$2"
				shift 2
			else
				log_error "--external-ip requires an IP address"
				return 1
			fi
			;;
		--bootnodes)
			if [[ -n "${2:-}" ]]; then
				explicit_bootnodes="$2"
				shift 2
			else
				log_error "--bootnodes requires a comma-separated enode list"
				return 1
			fi
			;;
		--trusted-peers)
			if [[ -n "${2:-}" ]]; then
				explicit_trusted_peers="$2"
				shift 2
			else
				log_error "--trusted-peers requires a comma-separated enode list"
				return 1
			fi
			;;
		--ws.addr)
			if [[ -n "${2:-}" ]]; then
				explicit_ws_addr="$2"
				shift 2
			else
				log_error "--ws.addr requires a bind address"
				return 1
			fi
			;;
		--ws.port)
			if [[ -n "${2:-}" ]]; then
				explicit_ws_port="$2"
				shift 2
			else
				log_error "--ws.port requires a port"
				return 1
			fi
			;;
		--ws.origin | --ws.origins)
			if [[ -n "${2:-}" ]]; then
				explicit_ws_origins="$2"
				shift 2
			else
				log_error "--ws.origin requires an origin list"
				return 1
			fi
			;;
		--ws)
			enable_ws="true"
			shift
			;;
		--logs-reset)
			logs_reset="true"
			shift
			;;
		--help | -h)
			show_start_help
			return 0
			;;
		*)
			check_unknown_option "$1" "show_start_help" || return 1
			;;
		esac
	done

	if [[ "${enable_ws}" != "true" ]] && [[ -n "${explicit_ws_addr}" || -n "${explicit_ws_port}" || -n "${explicit_ws_origins}" ]]; then
		log_error "--ws.addr, --ws.port, and --ws.origin require --ws"
		return 1
	fi

	# -------------------------------------------------------------------------
	# [STEP 2] Configuration File Validation
	# -------------------------------------------------------------------------
	# Verify the existence of beranodes.config.json in the specified directory.
	# This file contains all node configuration parameters including:
	# - Network type (devnet/testnet/mainnet)
	# - Node counts (validators, full nodes, pruned nodes)
	# - Port configurations
	# - Wallet addresses and keys
	# -------------------------------------------------------------------------

	log_info "Starting Beranode in ${beranodes_dir} directory"

	print_header "Starting Beranode"
	local beranodes_config_path="${beranodes_dir}/beranodes.config.json"

	if ! [[ -f "${beranodes_config_path}" ]]; then
		log_error "Beranode configuration file does not exist: ${beranodes_dir}/beranodes.config.json"
		return 1
	else
		log_success "Beranode configuration file exists: ${beranodes_config_path}"
	fi

	# This will ensure all required fields are present and properly formatted
	# Validate the beranodes configuration JSON file before proceeding
	if ! validate_beranodes_config "${beranodes_config_path}"; then
		log_error "Configuration validation failed. Please review errors above and fix your beranodes.config.json file."
		return 1
	else
		log_success "beranodes.config.json passed validation."
	fi

	# -------------------------------------------------------------------------
	# [STEP 3] Configuration Parsing
	# -------------------------------------------------------------------------
	# Extract all configuration values from beranodes.config.json using jq.
	# These values control node behavior, network settings, and resource
	# allocation throughout the startup process.
	# -------------------------------------------------------------------------

	print_header "Beranode Configuration"
	log_info "Configuration file: ${beranodes_config_path}"

	local config_json_path="${beranodes_dir}/beranodes.config.json"

	# Load entire configuration into memory (single jq call replaces 80+ separate calls)
	load_config "${config_json_path}" || return 1

	# Binary paths
	local beranodes_dir=$(get_config "beranode_dir")
	local bin_beacond="$beranodes_dir${BERANODES_PATH_BIN}/${BIN_BEACONKIT}"
	local bin_bera_reth="$beranodes_dir${BERANODES_PATH_BIN}/${BIN_BERARETH}"

	# Node identity and network configuration
	local moniker=$(get_config "moniker")
	local network=$(get_config "network")

	# Node count configuration
	local validators=$(get_config "validators")
	local full_nodes=$(get_config "full_nodes")
	local pruned_nodes=$(get_config "pruned_nodes")
	local total_nodes=$(get_config "total_nodes")

	# Directory and operational settings
	local beranode_dir=$(get_config "beranode_dir")
	local skip_genesis=$(get_config "skip_genesis")
	local force=$(get_config "force")
	local mode=$(get_config "mode")

	if [[ "${mode}" == "serviceman" ]]; then
		serviceman_prepare_start "${beranode_dir}" || return 1
	fi

	# Wallet configuration
	local wallet_private_key=$(get_config "wallet_private_key")
	local wallet_address=$(get_config "wallet_address")

	# Node-specific configurations (array of node objects)
	# All node configs were loaded by load_config() above with keys like "nodes.0.ethrpc_port"
	local nodes_count=$(get_config "total_nodes" "0")

	# Get all ports and check if they are currently in use
	local ports=()
	for ((node_index = 0; node_index < ${nodes_count}; node_index++)); do
		local ethrpc_port=$(get_config "nodes.${node_index}.ethrpc_port")
		local ethp2p_port=$(get_config "nodes.${node_index}.ethp2p_port")
		local ethproxy_port=$(get_config "nodes.${node_index}.ethproxy_port")
		local el_ethrpc_port=$(get_config "nodes.${node_index}.el_ethrpc_port")
		local el_authrpc_port=$(get_config "nodes.${node_index}.el_authrpc_port")
		local el_eth_port=$(get_config "nodes.${node_index}.el_eth_port")
		local el_prometheus_port=$(get_config "nodes.${node_index}.el_prometheus_port")
		local cl_prometheus_port=$(get_config "nodes.${node_index}.cl_prometheus_port")
		local beacond_node_port=$(get_config "nodes.${node_index}.beacond_node_port")
		local configtoml_grpc_laddr=$(get_config "nodes.${node_index}.configtoml_grpc_laddr")
		local configtoml_grpc_privileged_laddr=$(get_config "nodes.${node_index}.configtoml_grpc_privileged_laddr")
		ports[${node_index}]="${ethrpc_port} ${ethp2p_port} ${ethproxy_port} ${el_ethrpc_port} ${el_authrpc_port} ${el_eth_port} ${el_prometheus_port} ${cl_prometheus_port} ${beacond_node_port} ${configtoml_grpc_laddr} ${configtoml_grpc_privileged_laddr}"
	done
	log_info "Checking if ports are in use:\n${ports[*]}\n"
	for port in "${ports[@]}"; do
		# Only check ports that are numbers, skip empty/invalid ones to avoid "No such file or directory"
		if [[ "$port" =~ ^[0-9]+$ ]]; then
			if lsof -iTCP:"${port}" -sTCP:LISTEN >/dev/null 2>&1; then
				log_error "Port ${port} is already in use"
				return 1
			fi
		fi
	done
	log_success "All ports are available"

	# Docker tags
	docker_berareth_tag=""
	docker_beacond_tag=""
	if [[ "${mode}" == "docker" ]]; then
		# Get tags
		docker_berareth_tag=$(curl -sI https://github.com/berachain/bera-reth/releases/latest | grep -i location: | grep -oE '/tag/[^ ]+' | awk -F'/tag/' '{print $2}' | tr -d '\r\n')
		docker_beacond_tag=$(curl -sI https://github.com/berachain/beacon-kit/releases/latest | grep -i location: | grep -oE '/tag/[^ ]+' | awk -F'/tag/' '{print $2}' | tr -d '\r\n')

		# Check for existing docker image
		docker_berareth_image=$(docker images --format '{{.Repository}}:{{.Tag}}' | grep "docker-bera-reth:${docker_berareth_tag}" || true)
		if [[ -n "$docker_berareth_image" ]]; then
			log_success "Found existing docker-bera-reth image: docker-bera-reth:${docker_berareth_tag}"
		else
			log_error "docker-bera-reth:${docker_berareth_tag} image not found"
			return 1
		fi

		docker_beacond_image=$(docker images --format '{{.Repository}}:{{.Tag}}' | grep "docker-beacond:${docker_beacond_tag}" || true)
		if [[ -n "$docker_beacond_image" ]]; then
			log_success "Found existing docker-beacond image: docker-beacond:${docker_beacond_tag}"
		else
			log_error "docker-beacond:${docker_beacond_tag} image not found"
			return 1
		fi
	elif [[ "${mode}" == "local" || "${mode}" == "serviceman" ]]; then
		# Verify local binaries exist and can execute natively
		if [[ ! -x "${bin_beacond}" ]]; then
			log_error "beacond binary not found or not executable at: ${bin_beacond}"
			log_error "Run 'beranode init' first to install binaries, or place native binaries in ${beranodes_dir}${BERANODES_PATH_BIN}/"
			return 1
		fi
		if ! "${bin_beacond}" version >/dev/null 2>&1; then
			log_error "beacond binary at ${bin_beacond} cannot execute on this platform."
			log_error "Local mode requires native binaries. The binary may be built for a different OS/architecture."
			log_error "Please provide a native '${BIN_BEACONKIT}' binary or use 'beranode init --mode docker' instead."
			return 1
		fi
		log_success "beacond binary is valid: ${bin_beacond}"

		if [[ ! -x "${bin_bera_reth}" ]]; then
			log_error "bera-reth binary not found or not executable at: ${bin_bera_reth}"
			log_error "Run 'beranode init' first to install binaries, or place native binaries in ${beranodes_dir}${BERANODES_PATH_BIN}/"
			return 1
		fi
		if ! "${bin_bera_reth}" --version >/dev/null 2>&1; then
			log_error "bera-reth binary at ${bin_bera_reth} cannot execute on this platform."
			log_error "Local mode requires native binaries. The binary may be built for a different OS/architecture."
			log_error "Please provide a native '${BIN_BERARETH}' binary or use 'beranode init --mode docker' instead."
			return 1
		fi
		log_success "bera-reth binary is valid: ${bin_bera_reth}"
	fi

	# -------------------------------------------------------------------------
	# [STEP 5] Network-Specific Initialization
	# -------------------------------------------------------------------------
	# Route to the appropriate network handler based on the configuration.
	# Currently supports: devnet (local development), bepolia (testnet), mainnet
	# -------------------------------------------------------------------------

	if [[ "${network}" != "${CHAIN_NAME_DEVNET}" ]] && ! is_public_network "${network}"; then
		log_error "Unknown network: ${network}. Supported: ${CHAIN_NAME_DEVNET}, ${CHAIN_NAME_TESTNET}, ${CHAIN_NAME_MAINNET}"
		return 1
	fi

	if [[ "${network}" == "${CHAIN_NAME_DEVNET}" ]] || is_public_network "${network}"; then
		log_info "Starting Beranode in ${network} network"

		# ---------------------------------------------------------------------
		# [STEP 5.1] Mode Selection: Local Development
		# ---------------------------------------------------------------------
		# Local mode: Single-machine deployment for development/testing
		# - Runs all nodes on localhost with incremental ports
		# - Suitable for rapid iteration and testing
		# ---------------------------------------------------------------------

		if [[ "${mode}" == "local" ]] || [[ "${mode}" == "docker" ]] || [[ "${mode}" == "serviceman" ]]; then
			log_info "Starting Beranode in ${mode} mode"

			if [[ "${mode}" == "local" || "${mode}" == "serviceman" ]]; then
				# Check if bin/beacond exists in ${config_dir}/bin and is executable
				local beacond_binary="${beranodes_dir}/bin/beacond"
				if [[ ! -x "${beacond_binary}" ]]; then
					log_error "beacond binary not found or not executable at: ${beacond_binary}"
					return 1
				fi

				# Check if bin/bera-reth exists in ${config_dir}/bin and is executable
				local bera_reth_binary="${beranodes_dir}/bin/bera-reth"
				if [[ ! -x "${bera_reth_binary}" ]]; then
					log_error "bera-reth binary not found or not executable at: ${bera_reth_binary}"
					return 1
				fi
			fi

			# Check if logs directory has existing files and prompt user
			local logs_dir="${beranode_dir}${BERANODES_PATH_LOGS}"
			if [ -d "${logs_dir}" ] && [ "$(ls -A "${logs_dir}")" ]; then
				if [[ "${logs_reset}" == "true" ]]; then
					rm -f "${logs_dir}"/*
					log_info "Existing log files removed (--logs-reset)"
				else
					log_warn "Existing log files found in ${logs_dir}"
					read -p "Do you want to remove existing log files? (y/n) " remove_logs
					if [ "${remove_logs}" == "y" ]; then
						rm -f "${logs_dir}"/*
						log_info "Existing log files removed"
					else
						log_info "Keeping existing log files"
					fi
				fi
			fi

			# Do a check if `beranode_dir/nodes` has any directories, if so, ask if the user wants to delete them
			if [ -d "${beranode_dir}/nodes" ] && [ "$(ls -A "${beranode_dir}/nodes")" ]; then
				if is_public_network "${network}"; then
					log_info "Keeping existing public-network node directories (snapshots and keys would be lost if deleted)"
				else
					log_warn "Node directories already exist in ${beranode_dir}/nodes"
					read -p "Do you want to delete them? (y/n) " delete_nodes
					if [ "${delete_nodes}" == "y" ]; then
						rm -rf "${beranode_dir}/nodes"
						log_info "Node directories deleted"
					else
						log_error "Node directories not deleted. stopping..."
						return 1
					fi
				fi
			fi
			mkdir -p "${beranode_dir}/nodes"
			log_info "Node directories created in ${beranode_dir}/nodes"

			local network=$(jq -r '.network' "${config_json_path}")
			local chain_id
			chain_id="$(network_chain_id "${network}")"
			local chain_spec
			chain_spec="$(network_beacon_chain_spec "${network}")"
			local chain_id_beacond=$(jq -r '.clienttoml.chain_id' "${config_json_path}")
			local snapshot_type_override
			snapshot_type_override=$(jq -r '.snapshot_type // empty' "${config_json_path}")

			if is_public_network "${network}" && [[ -z "${external_ip}" ]]; then
				external_ip="$(detect_external_ip)"
				if [[ -n "${external_ip}" ]]; then
					log_info "Detected external IP: ${external_ip}"
				else
					log_warn "Could not detect external IP; P2P may fail behind NAT. Pass --external-ip."
				fi
			fi

			local wallet_address=$(jq -r '.wallet_address' "${config_json_path}")
			local wallet_private_key=$(jq -r '.wallet_private_key' "${config_json_path}")
			local wallet_balance=$(jq -r '.wallet_balance' "${config_json_path}")

			# Load all nodes from config
			local nodes=$(jq -c '.nodes' "${config_json_path}")

			# get all seeds and peers
			local seeds=()
			local peers=()
			local p2p_ports=()
			local node_roles=()
			local berareth_bootnodes=()
			local berareth_trusted_peers=()
			local berareth_el_eth_port=()
			for ((node_index = 0; node_index < ${nodes_count}; node_index++)); do
				local json=$(echo "${nodes}" | jq -r ".[$node_index]")
				local id=$(echo "${json}" | jq -r '.beacond_config.node_id')
				local node_role=$(echo "${json}" | jq -r '.role')
				seeds[${node_index}]="${id}"
				peers[${node_index}]="${id}"
				p2p_ports[${node_index}]=$(echo "${json}" | jq -r '.ethp2p_port')
				node_roles[${node_index}]="${node_role}"
				berareth_bootnodes[${node_index}]=$(echo "${json}" | jq -r '.berareth_config.public_key')
				berareth_trusted_peers[${node_index}]=$(echo "${json}" | jq -r '.berareth_config.public_key')
				berareth_el_eth_port[${node_index}]=$(echo "${json}" | jq -r '.el_eth_port')
			done

			for ((node_index = 0; node_index < ${nodes_count}; node_index++)); do
				echo "--------------------------------"
				echo "Configuring node $node_index"
				echo "--------------------------------"

				local node_json=$(echo "${nodes}" | jq -r ".[$node_index]")
				local role=$(echo "${node_json}" | jq -r '.role')
				local moniker=$(echo "${node_json}" | jq -r '.moniker')
				local node_key_type=$(echo "${node_json}" | jq -r '.beacond_config.node_key.priv_key.type')
				local node_key_value=$(echo "${node_json}" | jq -r '.beacond_config.node_key.priv_key.value')
				local node_id=$(echo "${node_json}" | jq -r '.node_id')
				local priv_validator_key_address=$(echo "${node_json}" | jq -r '.beacond_config.priv_validator_key.address')
				local priv_validator_key_pubkey_type=$(echo "${node_json}" | jq -r '.beacond_config.priv_validator_key.pub_key.type')
				local priv_validator_key_pubkey_value=$(echo "${node_json}" | jq -r '.beacond_config.priv_validator_key.pub_key.value')
				local priv_validator_key_privkey_type=$(echo "${node_json}" | jq -r '.beacond_config.priv_validator_key.priv_key.type')
				local priv_validator_key_privkey_value=$(echo "${node_json}" | jq -r '.beacond_config.priv_validator_key.priv_key.value')
				local premined_deposit=$(echo "${node_json}" | jq -r '.premined_deposit')
				local deposit_amount=$(echo "${node_json}" | jq -r '.deposit_amount')
				local jwt=$(echo "${node_json}" | jq -r '.beacond_config.jwt')
				local comet_address=$(echo "${node_json}" | jq -r '.beacond_config.comet_address')
				local comet_pubkey=$(echo "${node_json}" | jq -r '.beacond_config.comet_pubkey')
				local eth_beacon_pubkey=$(echo "${node_json}" | jq -r '.beacond_config.eth_beacon_pubkey')

				# ports
				local ethrpc_port=$(echo "${node_json}" | jq -r '.ethrpc_port')
				local ethp2p_port=$(echo "${node_json}" | jq -r '.ethp2p_port')
				local ethproxy_port=$(echo "${node_json}" | jq -r '.ethproxy_port')
				local el_ethrpc_port=$(echo "${node_json}" | jq -r '.el_ethrpc_port')
				local el_authrpc_port=$(echo "${node_json}" | jq -r '.el_authrpc_port')
				local el_eth_port=$(echo "${node_json}" | jq -r '.el_eth_port')
				local el_prometheus_port=$(echo "${node_json}" | jq -r '.el_prometheus_port')
				local cl_prometheus_port=$(echo "${node_json}" | jq -r '.cl_prometheus_port')
				local beacond_node_port=$(echo "${node_json}" | jq -r '.beacond_node_port')

				# client.toml variables
				local clienttoml_chain_id=$(jq -r '.clienttoml.chain_id' "${config_json_path}")
				local clienttoml_keyring_backend=$(jq -r '.clienttoml.keyring_backend' "${config_json_path}")
				local clienttoml_keyring_default_keyname=$(jq -r '.clienttoml.keyring_default_keyname' "${config_json_path}")
				local clienttoml_output=$(jq -r '.clienttoml.output' "${config_json_path}")
				local clienttoml_node=$(jq -r '.clienttoml.node' "${config_json_path}")
				local clienttoml_broadcast_mode=$(jq -r '.clienttoml.broadcast_mode' "${config_json_path}")
				local clienttoml_grpc_address=$(jq -r '.clienttoml.grpc_address' "${config_json_path}")
				local clienttoml_grpc_insecure=$(jq -r '.clienttoml.grpc_insecure' "${config_json_path}")

				# app.toml variables
				local apptoml_pruning=$(jq -r '.apptoml.pruning' "${config_json_path}")
				local apptoml_pruning_keep_recent=$(jq -r '.apptoml.pruning_keep_recent' "${config_json_path}")
				local apptoml_pruning_interval=$(jq -r '.apptoml.pruning_interval' "${config_json_path}")
				local apptoml_halt_height=$(jq -r '.apptoml.halt_height' "${config_json_path}")
				local apptoml_halt_time=$(jq -r '.apptoml.halt_time' "${config_json_path}")
				local apptoml_min_retain_blocks=$(jq -r '.apptoml.min_retain_blocks' "${config_json_path}")
				local apptoml_inter_block_cache=$(jq -r '.apptoml.inter_block_cache' "${config_json_path}")
				local apptoml_iavl_cache_size=$(jq -r '.apptoml.iavl_cache_size' "${config_json_path}")
				local apptoml_iavl_disable_fastnode=$(jq -r '.apptoml.iavl_disable_fastnode' "${config_json_path}")
				local apptoml_telemetry_service_name=$(jq -r '.apptoml.telemetry_service_name' "${config_json_path}")
				local apptoml_telemetry_enabled=$(jq -r '.apptoml.telemetry_enabled' "${config_json_path}")
				local apptoml_telemetry_enable_hostname=$(jq -r '.apptoml.telemetry_enable_hostname' "${config_json_path}")
				local apptoml_telemetry_enable_hostname_label=$(jq -r '.apptoml.telemetry_enable_hostname_label' "${config_json_path}")
				local apptoml_telemetry_enable_service_label=$(jq -r '.apptoml.telemetry_enable_service_label' "${config_json_path}")
				local apptoml_telemetry_prometheus_retention_time=$(jq -r '.apptoml.telemetry_prometheus_retention_time' "${config_json_path}")
				local apptoml_telemetry_global_labels=$(jq -r '.apptoml.telemetry_global_labels' "${config_json_path}")
				local apptoml_telemetry_metrics_sink=$(jq -r '.apptoml.telemetry_metrics_sink' "${config_json_path}")
				local apptoml_telemetry_statsd_addr=$(jq -r '.apptoml.telemetry_statsd_addr' "${config_json_path}")
				local apptoml_telemetry_datadog_hostname=$(jq -r '.apptoml.telemetry_datadog_hostname' "${config_json_path}")
				local apptoml_beacon_kit_chain_spec=$(jq -r '.apptoml.beacon_kit_chain_spec' "${config_json_path}")
				local apptoml_beacon_kit_chain_spec_file=$(jq -r '.apptoml.beacon_kit_chain_spec_file' "${config_json_path}")
				local apptoml_beacon_kit_shutdown_timeout=$(jq -r '.apptoml.beacon_kit_shutdown_timeout' "${config_json_path}")
				local apptoml_beacon_kit_engine_rpc_dial_url=$(jq -r '.apptoml.beacon_kit_engine_rpc_dial_url' "${config_json_path}")
				local apptoml_beacon_kit_engine_rpc_timeout=$(jq -r '.apptoml.beacon_kit_engine_rpc_timeout' "${config_json_path}")
				local apptoml_beacon_kit_engine_rpc_startup_check_interval=$(jq -r '.apptoml.beacon_kit_engine_rpc_startup_check_interval' "${config_json_path}")
				local apptoml_beacon_kit_engine_rpc_jwt_refresh_interval=$(jq -r '.apptoml.beacon_kit_engine_rpc_jwt_refresh_interval' "${config_json_path}")
				local apptoml_beacon_kit_engine_jwt_secret_path=$(jq -r '.apptoml.beacon_kit_engine_jwt_secret_path' "${config_json_path}")
				local apptoml_beacon_kit_logger_time_format=$(jq -r '.apptoml.beacon_kit_logger_time_format' "${config_json_path}")
				local apptoml_beacon_kit_logger_log_level=$(jq -r '.apptoml.beacon_kit_logger_log_level' "${config_json_path}")
				local apptoml_beacon_kit_logger_style=$(jq -r '.apptoml.beacon_kit_logger_style' "${config_json_path}")
				local apptoml_beacon_kit_kzg_trusted_setup_path=$(jq -r '.apptoml.beacon_kit_kzg_trusted_setup_path' "${config_json_path}")
				local apptoml_beacon_kit_kzg_implementation=$(jq -r '.apptoml.beacon_kit_kzg_implementation' "${config_json_path}")
				local apptoml_beacon_kit_payload_builder_enabled=$(jq -r '.apptoml.beacon_kit_payload_builder_enabled' "${config_json_path}")
				local apptoml_beacon_kit_payload_builder_suggested_fee_recipient=$(jq -r '.apptoml.beacon_kit_payload_builder_suggested_fee_recipient' "${config_json_path}")
				local apptoml_beacon_kit_payload_builder_payload_timeout=$(jq -r '.apptoml.beacon_kit_payload_builder_payload_timeout' "${config_json_path}")
				local apptoml_beacon_kit_validator_graffiti=$(jq -r '.apptoml.beacon_kit_validator_graffiti' "${config_json_path}")
				local apptoml_beacon_kit_validator_availability_window=$(jq -r '.apptoml.beacon_kit_validator_availability_window' "${config_json_path}")
				local apptoml_beacon_kit_node_api_enabled=$(jq -r '.apptoml.beacon_kit_node_api_enabled' "${config_json_path}")
				local apptoml_beacon_kit_node_api_address=$(jq -r '.apptoml.beacon_kit_node_api_address' "${config_json_path}")
				local apptoml_beacon_kit_node_api_logging=$(jq -r '.apptoml.beacon_kit_node_api_logging' "${config_json_path}")

				# config.toml variables
				local configtoml_version=$(jq -r '.configtoml.version' "${config_json_path}")
				local configtoml_proxy_app=$(jq -r '.configtoml.proxy_app' "${config_json_path}")
				local configtoml_moniker=$(jq -r '.configtoml.moniker' "${config_json_path}")
				local configtoml_db_backend=$(jq -r '.configtoml.db_backend' "${config_json_path}")
				local configtoml_db_dir=$(jq -r '.configtoml.db_dir' "${config_json_path}")
				local configtoml_log_level=$(jq -r '.configtoml.log_level' "${config_json_path}")
				local configtoml_log_format=$(jq -r '.configtoml.log_format' "${config_json_path}")
				local configtoml_genesis_file=$(jq -r '.configtoml.genesis_file' "${config_json_path}")
				local configtoml_priv_validator_key_file=$(jq -r '.configtoml.priv_validator_key_file' "${config_json_path}")
				local configtoml_priv_validator_state_file=$(jq -r '.configtoml.priv_validator_state_file' "${config_json_path}")
				local configtoml_priv_validator_laddr=$(jq -r '.configtoml.priv_validator_laddr' "${config_json_path}")
				local configtoml_node_key_file=$(jq -r '.configtoml.node_key_file' "${config_json_path}")
				local configtoml_abci=$(jq -r '.configtoml.abci' "${config_json_path}")
				local configtoml_filter_peers=$(jq -r '.configtoml.filter_peers' "${config_json_path}")
				local configtoml_rpc_laddr=$(jq -r '.configtoml.rpc_laddr' "${config_json_path}")
				local configtoml_rpc_cors_allowed_origins=$(jq -r '.configtoml.rpc_cors_allowed_origins' "${config_json_path}")
				local configtoml_rpc_cors_allowed_methods=$(jq -r '.configtoml.rpc_cors_allowed_methods' "${config_json_path}")
				local configtoml_rpc_cors_allowed_headers=$(jq -r '.configtoml.rpc_cors_allowed_headers' "${config_json_path}")
				local configtoml_rpc_unsafe=$(jq -r '.configtoml.rpc_unsafe' "${config_json_path}")
				local configtoml_rpc_max_open_connections=$(jq -r '.configtoml.rpc_max_open_connections' "${config_json_path}")
				local configtoml_rpc_max_subscription_clients=$(jq -r '.configtoml.rpc_max_subscription_clients' "${config_json_path}")
				local configtoml_rpc_max_subscriptions_per_client=$(jq -r '.configtoml.rpc_max_subscriptions_per_client' "${config_json_path}")
				local configtoml_rpc_experimental_subscription_buffer_size=$(jq -r '.configtoml.rpc_experimental_subscription_buffer_size' "${config_json_path}")
				local configtoml_rpc_experimental_websocket_write_buffer_size=$(jq -r '.configtoml.rpc_experimental_websocket_write_buffer_size' "${config_json_path}")
				local configtoml_rpc_experimental_close_on_slow_client=$(jq -r '.configtoml.rpc_experimental_close_on_slow_client' "${config_json_path}")
				local configtoml_rpc_timeout_broadcast_tx_commit=$(jq -r '.configtoml.rpc_timeout_broadcast_tx_commit' "${config_json_path}")
				local configtoml_rpc_max_request_batch_size=$(jq -r '.configtoml.rpc_max_request_batch_size' "${config_json_path}")
				local configtoml_rpc_max_body_bytes=$(jq -r '.configtoml.rpc_max_body_bytes' "${config_json_path}")
				local configtoml_rpc_max_header_bytes=$(jq -r '.configtoml.rpc_max_header_bytes' "${config_json_path}")
				local configtoml_rpc_tls_cert_file=$(jq -r '.configtoml.rpc_tls_cert_file' "${config_json_path}")
				local configtoml_rpc_tls_key_file=$(jq -r '.configtoml.rpc_tls_key_file' "${config_json_path}")
				local configtoml_rpc_pprof_laddr=$(jq -r '.configtoml.rpc_pprof_laddr' "${config_json_path}")
				local configtoml_grpc_laddr=$(jq -r '.configtoml.grpc_laddr' "${config_json_path}")
				local configtoml_grpc_version_service_enabled=$(jq -r '.configtoml.grpc_version_service_enabled' "${config_json_path}")
				local configtoml_grpc_block_service_enabled=$(jq -r '.configtoml.grpc_block_service_enabled' "${config_json_path}")
				local configtoml_grpc_block_results_service_enabled=$(jq -r '.configtoml.grpc_block_results_service_enabled' "${config_json_path}")
				local configtoml_grpc_privileged_laddr=$(jq -r '.configtoml.grpc_privileged_laddr' "${config_json_path}")
				local configtoml_grpc_privileged_pruning_service_enabled=$(jq -r '.configtoml.grpc_privileged_pruning_service_enabled' "${config_json_path}")
				local configtoml_p2p_laddr=$(jq -r '.configtoml.p2p_laddr' "${config_json_path}")
				local configtoml_p2p_external_address=$(jq -r '.configtoml.p2p_external_address' "${config_json_path}")
				local configtoml_p2p_seeds=$(jq -r '.configtoml.p2p_seeds' "${config_json_path}")
				local configtoml_p2p_persistent_peers=$(jq -r '.configtoml.p2p_persistent_peers' "${config_json_path}")
				local configtoml_p2p_addr_book_file=$(jq -r '.configtoml.p2p_addr_book_file' "${config_json_path}")
				local configtoml_p2p_addr_book_strict=$(jq -r '.configtoml.p2p_addr_book_strict' "${config_json_path}")
				local configtoml_p2p_max_num_inbound_peers=$(jq -r '.configtoml.p2p_max_num_inbound_peers' "${config_json_path}")
				local configtoml_p2p_max_num_outbound_peers=$(jq -r '.configtoml.p2p_max_num_outbound_peers' "${config_json_path}")
				local configtoml_p2p_unconditional_peer_ids=$(jq -r '.configtoml.p2p_unconditional_peer_ids' "${config_json_path}")
				local configtoml_p2p_persistent_peers_max_dial_period=$(jq -r '.configtoml.p2p_persistent_peers_max_dial_period' "${config_json_path}")
				local configtoml_p2p_flush_throttle_timeout=$(jq -r '.configtoml.p2p_flush_throttle_timeout' "${config_json_path}")
				local configtoml_p2p_max_packet_msg_payload_size=$(jq -r '.configtoml.p2p_max_packet_msg_payload_size' "${config_json_path}")
				local configtoml_p2p_send_rate=$(jq -r '.configtoml.p2p_send_rate' "${config_json_path}")
				local configtoml_p2p_recv_rate=$(jq -r '.configtoml.p2p_recv_rate' "${config_json_path}")
				local configtoml_p2p_pex=$(jq -r '.configtoml.p2p_pex' "${config_json_path}")
				local configtoml_p2p_seed_mode=$(jq -r '.configtoml.p2p_seed_mode' "${config_json_path}")
				local configtoml_p2p_private_peer_ids=$(jq -r '.configtoml.p2p_private_peer_ids' "${config_json_path}")
				local configtoml_p2p_allow_duplicate_ip=$(jq -r '.configtoml.p2p_allow_duplicate_ip' "${config_json_path}")
				local configtoml_p2p_handshake_timeout=$(jq -r '.configtoml.p2p_handshake_timeout' "${config_json_path}")
				local configtoml_p2p_dial_timeout=$(jq -r '.configtoml.p2p_dial_timeout' "${config_json_path}")
				local configtoml_mempool_type=$(jq -r '.configtoml.mempool_type' "${config_json_path}")
				local configtoml_mempool_recheck=$(jq -r '.configtoml.mempool_recheck' "${config_json_path}")
				local configtoml_mempool_recheck_timeout=$(jq -r '.configtoml.mempool_recheck_timeout' "${config_json_path}")
				local configtoml_mempool_broadcast=$(jq -r '.configtoml.mempool_broadcast' "${config_json_path}")
				local configtoml_mempool_wal_dir=$(jq -r '.configtoml.mempool_wal_dir' "${config_json_path}")
				local configtoml_mempool_size=$(jq -r '.configtoml.mempool_size' "${config_json_path}")
				local configtoml_mempool_max_tx_bytes=$(jq -r '.configtoml.mempool_max_tx_bytes' "${config_json_path}")
				local configtoml_mempool_max_txs_bytes=$(jq -r '.configtoml.mempool_max_txs_bytes' "${config_json_path}")
				local configtoml_mempool_cache_size=$(jq -r '.configtoml.mempool_cache_size' "${config_json_path}")
				local configtoml_mempool_keep_invalid_txs_in_cache=$(jq -r '.configtoml.mempool_keep_invalid_txs_in_cache' "${config_json_path}")
				local configtoml_statesync_enable=$(jq -r '.configtoml.statesync_enable' "${config_json_path}")
				local configtoml_statesync_rpc_servers=$(jq -r '.configtoml.statesync_rpc_servers' "${config_json_path}")
				local configtoml_statesync_trust_height=$(jq -r '.configtoml.statesync_trust_height' "${config_json_path}")
				local configtoml_statesync_trust_hash=$(jq -r '.configtoml.statesync_trust_hash' "${config_json_path}")
				local configtoml_statesync_trust_period=$(jq -r '.configtoml.statesync_trust_period' "${config_json_path}")
				local configtoml_statesync_discovery_time=$(jq -r '.configtoml.statesync_discovery_time' "${config_json_path}")
				local configtoml_statesync_temp_dir=$(jq -r '.configtoml.statesync_temp_dir' "${config_json_path}")
				local configtoml_statesync_chunk_request_timeout=$(jq -r '.configtoml.statesync_chunk_request_timeout' "${config_json_path}")
				local configtoml_statesync_chunk_fetchers=$(jq -r '.configtoml.statesync_chunk_fetchers' "${config_json_path}")
				local configtoml_blocksync_version=$(jq -r '.configtoml.blocksync_version' "${config_json_path}")
				local configtoml_consensus_wal_file=$(jq -r '.configtoml.consensus_wal_file' "${config_json_path}")
				local configtoml_consensus_timeout_propose=$(jq -r '.configtoml.consensus_timeout_propose' "${config_json_path}")
				local configtoml_consensus_timeout_propose_delta=$(jq -r '.configtoml.consensus_timeout_propose_delta' "${config_json_path}")
				local configtoml_consensus_timeout_prevote=$(jq -r '.configtoml.consensus_timeout_prevote' "${config_json_path}")
				local configtoml_consensus_timeout_prevote_delta=$(jq -r '.configtoml.consensus_timeout_prevote_delta' "${config_json_path}")
				local configtoml_consensus_timeout_precommit=$(jq -r '.configtoml.consensus_timeout_precommit' "${config_json_path}")
				local configtoml_consensus_timeout_precommit_delta=$(jq -r '.configtoml.consensus_timeout_precommit_delta' "${config_json_path}")
				local configtoml_consensus_timeout_commit=$(jq -r '.configtoml.consensus_timeout_commit' "${config_json_path}")
				local configtoml_consensus_skip_timeout_commit=$(jq -r '.configtoml.consensus_skip_timeout_commit' "${config_json_path}")
				local configtoml_consensus_double_sign_check_height=$(jq -r '.configtoml.consensus_double_sign_check_height' "${config_json_path}")
				local configtoml_consensus_create_empty_blocks=$(jq -r '.configtoml.consensus_create_empty_blocks' "${config_json_path}")
				local configtoml_consensus_create_empty_blocks_interval=$(jq -r '.configtoml.consensus_create_empty_blocks_interval' "${config_json_path}")
				local configtoml_consensus_peer_gossip_sleep_duration=$(jq -r '.configtoml.consensus_peer_gossip_sleep_duration' "${config_json_path}")
				local configtoml_consensus_peer_gossip_intraloop_sleep_duration=$(jq -r '.configtoml.consensus_peer_gossip_intraloop_sleep_duration' "${config_json_path}")
				local configtoml_consensus_peer_query_maj23_sleep_duration=$(jq -r '.configtoml.consensus_peer_query_maj23_sleep_duration' "${config_json_path}")
				local configtoml_storage_discard_abci_responses=$(jq -r '.configtoml.storage_discard_abci_responses' "${config_json_path}")
				local configtoml_storage_experimental_db_key_layout=$(jq -r '.configtoml.storage_experimental_db_key_layout' "${config_json_path}")
				local configtoml_storage_compact=$(jq -r '.configtoml.storage_compact' "${config_json_path}")
				local configtoml_storage_compaction_interval=$(jq -r '.configtoml.storage_compaction_interval' "${config_json_path}")
				local configtoml_storage_pruning_interval=$(jq -r '.configtoml.storage_pruning_interval' "${config_json_path}")
				local configtoml_storage_pruning_data_companion_enabled=$(jq -r '.configtoml.storage_pruning_data_companion_enabled' "${config_json_path}")
				local configtoml_storage_pruning_data_companion_initial_block_retain_height=$(jq -r '.configtoml.storage_pruning_data_companion_initial_block_retain_height' "${config_json_path}")
				local configtoml_storage_pruning_data_companion_initial_block_results_retain_height=$(jq -r '.configtoml.storage_pruning_data_companion_initial_block_results_retain_height' "${config_json_path}")
				local configtoml_tx_index_indexer=$(jq -r '.configtoml.tx_index_indexer' "${config_json_path}")
				local configtoml_tx_index_psql_conn=$(jq -r '.configtoml.tx_index_psql_conn' "${config_json_path}")
				local configtoml_instrumentation_prometheus=$(jq -r '.configtoml.instrumentation_prometheus' "${config_json_path}")
				local configtoml_instrumentation_prometheus_listen_addr=$(jq -r '.configtoml.instrumentation_prometheus_listen_addr' "${config_json_path}")
				local configtoml_instrumentation_max_open_connections=$(jq -r '.configtoml.instrumentation_max_open_connections' "${config_json_path}")
				local configtoml_instrumentation_namespace=$(jq -r '.configtoml.instrumentation_namespace' "${config_json_path}")

				# Make node directories
				local node_dir="${beranodes_dir}${BERANODES_PATH_NODES}/${node_index}-${role}"
				local beacond_dir="${node_dir}/beacond"
				local bera_reth_dir="${node_dir}/bera-reth"
				mkdir -p "${node_dir}"
				mkdir -p "${beacond_dir}"
				mkdir -p "${bera_reth_dir}"
				log_success "✔ Directories made"

				# Init beacond node (skip if home already exists so snapshot data is kept)
				if [[ -f "${beacond_dir}/config/config.toml" ]]; then
					log_info "Beacond home already initialized at ${beacond_dir}; keeping existing data"
				elif [[ "$mode" == "docker" ]]; then
					docker run --rm -v ${beacond_dir}:/tmp docker-beacond:${docker_beacond_tag} beacond init ${moniker} --chain-id "${chain_id_beacond}" --beacon-kit.chain-spec ${chain_spec} --home /tmp >/dev/null 2>&1
					log_success "✔ Beacond node initialized"
				else
					${bin_beacond} init "${moniker}" --chain-id "${chain_id_beacond}" --beacon-kit.chain-spec "${chain_spec}" --home "${beacond_dir}" 2>/dev/null
					log_success "✔ Beacond node initialized"
				fi

				# - replace priv_validator_key.json
				cat >"${beacond_dir}/config/priv_validator_key.json" <<EOF
{
  "address": "${priv_validator_key_address}",
  "pub_key": {
    "type": "${priv_validator_key_pubkey_type}",
    "value": "${priv_validator_key_pubkey_value}"
  },
  "priv_key": {
    "type": "${priv_validator_key_privkey_type}",
    "value": "${priv_validator_key_privkey_value}"
  }
}
EOF
				log_success "✔ priv_validator_key.json replaced"

				# - replace node_key.json
				cat >"${beacond_dir}/config/node_key.json" <<EOF
{
  "priv_key": {
    "type": "${node_key_type}",
    "value": "${node_key_value}"
    }
  }
EOF
				log_success "✔ node_key.json replaced"

				# - update genesis.json
				cp -f "${beranodes_dir}/tmp/genesis.json" "${node_dir}/beacond/config/genesis.json"
				log_success "✔ genesis.json copied"

				# - add jwt.hex
				echo -n "${jwt}" >"${node_dir}/beacond/config/jwt.hex"
				if [[ "${mode}" == "docker" ]]; then
					echo -n "${jwt}" >"${node_dir}/bera-reth/jwt.hex"
				fi
				log_success "✔ jwt.hex added"

				# - update client.toml
				# chain-id
				sed "${SED_OPT[@]}" "s|^chain_id = \".*\"|chain_id = \"${chain_id_beacond}\"|" "${node_dir}/beacond/config/client.toml"
				# keyring-backend
				sed "${SED_OPT[@]}" "s|^keyring_backend = \".*\"|keyring_backend = \"${clienttoml_keyring_backend}\"|" "${node_dir}/beacond/config/client.toml"
				# keyring-default-keyname
				sed "${SED_OPT[@]}" "s|^keyring_default_keyname = \".*\"|keyring_default_keyname = \"${clienttoml_keyring_default_keyname}\"|" "${node_dir}/beacond/config/client.toml"
				# output
				sed "${SED_OPT[@]}" "s|^output = \".*\"|output = \"${clienttoml_output}\"|" "${node_dir}/beacond/config/client.toml"
				# node
				sed "${SED_OPT[@]}" "s|^node = \".*\"|node = \"tcp://localhost:${ethrpc_port}\"|" "${node_dir}/beacond/config/client.toml"
				# broadcast-mode
				sed "${SED_OPT[@]}" "s|^broadcast_mode = \".*\"|broadcast_mode = \"${clienttoml_broadcast_mode}\"|" "${node_dir}/beacond/config/client.toml"
				# grpc-address
				sed "${SED_OPT[@]}" "s|^grpc_address = \".*\"|grpc_address = \"${clienttoml_grpc_address}\"|" "${node_dir}/beacond/config/client.toml"
				# grpc-insecure
				sed "${SED_OPT[@]}" "s|^grpc_insecure = \".*\"|grpc_insecure = \"${clienttoml_grpc_insecure}\"|" "${node_dir}/beacond/config/client.toml"
				log_success "✔ client.toml updated"

				# - update app.toml
				echo "--------------------------------"
				echo "app.toml"
				echo "--------------------------------"
				# [base]
				# pruning - TODO - revamp if pruned node
				sed "${SED_OPT[@]}" "s|^pruning = \".*\"|pruning = \"${apptoml_pruning}\"|" "${node_dir}/beacond/config/app.toml"
				# pruning-keep-recent
				sed "${SED_OPT[@]}" "s|^pruning-keep-recent = \".*\"|pruning-keep-recent = \"${apptoml_pruning_keep_recent}\"|" "${node_dir}/beacond/config/app.toml"
				# pruning-interval
				sed "${SED_OPT[@]}" "s|^pruning-interval = \".*\"|pruning-interval = \"${apptoml_pruning_interval}\"|" "${node_dir}/beacond/config/app.toml"
				# halt-height
				sed "${SED_OPT[@]}" "s|^halt-height = \".*\"|halt-height = \"${apptoml_halt_height}\"|" "${node_dir}/beacond/config/app.toml"
				# halt-time
				sed "${SED_OPT[@]}" "s|^halt-time = \".*\"|halt-time = \"${apptoml_halt_time}\"|" "${node_dir}/beacond/config/app.toml"
				# min-retain-blocks
				sed "${SED_OPT[@]}" "s|^min-retain-blocks = \".*\"|min-retain-blocks = \"${apptoml_min_retain_blocks}\"|" "${node_dir}/beacond/config/app.toml"
				# inter-block-cache
				sed "${SED_OPT[@]}" "s|^inter-block-cache = \".*\"|inter-block-cache = \"${apptoml_inter_block_cache}\"|" "${node_dir}/beacond/config/app.toml"
				# iavl-cache-size
				sed "${SED_OPT[@]}" "s|^iavl-cache-size = \".*\"|iavl-cache-size = \"${apptoml_iavl_cache_size}\"|" "${node_dir}/beacond/config/app.toml"
				# iavl-disable-fastnode
				sed "${SED_OPT[@]}" "s|^iiavl-disable-fastnode = \".*\"|iiavl-disable-fastnode = \"${apptoml_iavl_disable_fastnode}\"|" "${node_dir}/beacond/config/app.toml"
				# [telemetry]
				# service-name
				sed "${SED_OPT[@]}" "s|^service-name = \".*\"|service-name = \"${apptoml_telemetry_service_name}\"|" "${node_dir}/beacond/config/app.toml"
				# enabled
				sed "${SED_OPT[@]}" "70s|^enabled = .*|enabled = ${apptoml_telemetry_enabled}|" "${node_dir}/beacond/config/app.toml"
				# enable-hostname
				sed "${SED_OPT[@]}" "s|^enable-hostname = \".*\"|enable-hostname = \"${apptoml_telemetry_enable_hostname}\"|" "${node_dir}/beacond/config/app.toml"
				# enable-hostname-label
				sed "${SED_OPT[@]}" "s|^enable-hostname-label = \".*\"|enable-hostname-label = \"${apptoml_telemetry_enable_hostname_label}\"|" "${node_dir}/beacond/config/app.toml"
				# enable-service-label
				sed "${SED_OPT[@]}" "s|^enable-service-label = \".*\"|enable-service-label = \"${apptoml_telemetry_enable_service_label}\"|" "${node_dir}/beacond/config/app.toml"
				# prometheus-retention-time
				sed "${SED_OPT[@]}" "s|^prometheus-retention-time = \".*\"|prometheus-retention-time = \"${apptoml_telemetry_prometheus_retention_time}\"|" "${node_dir}/beacond/config/app.toml"
				# global-labels
				sed "${SED_OPT[@]}" "s|^global-labels = \[.*\]|global-labels = [\n${apptoml_telemetry_global_labels}\n]|" "${node_dir}/beacond/config/app.toml"
				# metrics-sink
				sed "${SED_OPT[@]}" "s|^metrics-sink = \".*\"|metrics-sink = \"${apptoml_telemetry_metrics_sink}\"|" "${node_dir}/beacond/config/app.toml"
				# statsd-addr
				sed "${SED_OPT[@]}" "s|^statsd-addr = \".*\"|statsd-addr = \"${apptoml_telemetry_statsd_addr}\"|" "${node_dir}/beacond/config/app.toml"
				# datadog-hostname
				sed "${SED_OPT[@]}" "s|^datadog-hostname = \".*\"|datadog-hostname = \"${moniker}\"|" "${node_dir}/beacond/config/app.toml"
				# [beacon-kit]
				# chain-spec
				sed "${SED_OPT[@]}" "s|^chain-spec = \".*\"|chain-spec = \"${apptoml_beacon_kit_chain_spec}\"|" "${node_dir}/beacond/config/app.toml"
				# chain-spec-file
				sed "${SED_OPT[@]}" "s|^chain-spec-file = \".*\"|chain-spec-file = \"${apptoml_beacon_kit_chain_spec_file}\"|" "${node_dir}/beacond/config/app.toml"
				# shutdown-timeout
				sed "${SED_OPT[@]}" "s|^shutdown-timeout = \".*\"|shutdown-timeout = \"${apptoml_beacon_kit_shutdown_timeout}\"|" "${node_dir}/beacond/config/app.toml"
				# rpc-dial-url
				if [[ "${mode}" == "docker" ]]; then
					# In Docker mode, use the bera-reth service name with internal port 8551
					local role_short_name="${role}"
					if [[ "${role}" == "validator" ]]; then
						role_short_name="val"
					elif [[ "${role}" == "full_node" ]]; then
						role_short_name="full"
					fi
					sed "${SED_OPT[@]}" "s|^rpc-dial-url = \".*\"|rpc-dial-url = \"http://${node_index}-${role_short_name}-bera-reth:8551\"|" "${node_dir}/beacond/config/app.toml"
				else
					sed "${SED_OPT[@]}" "s|^rpc-dial-url = \".*\"|rpc-dial-url = \"http://localhost:${el_authrpc_port}\"|" "${node_dir}/beacond/config/app.toml"
				fi
				# rpc-timeout
				sed "${SED_OPT[@]}" "s|^rpc-timeout = \".*\"|rpc-timeout = \"${apptoml_beacon_kit_engine_rpc_timeout}\"|" "${node_dir}/beacond/config/app.toml"
				# rpc-startup-check-interval
				sed "${SED_OPT[@]}" "s|^rpc-startup-check-interval = \".*\"|rpc-startup-check-interval = \"${apptoml_beacon_kit_engine_rpc_startup_check_interval}\"|" "${node_dir}/beacond/config/app.toml"
				# rpc-jwt-refresh-interval
				sed "${SED_OPT[@]}" "s|^rpc-jwt-refresh-interval = \".*\"|rpc-jwt-refresh-interval = \"${apptoml_beacon_kit_engine_rpc_jwt_refresh_interval}\"|" "${node_dir}/beacond/config/app.toml"
				# jwt-secret
				if [[ "${mode}" == "docker" ]]; then
					sed "${SED_OPT[@]}" "s|^jwt-secret-path = \".*\"|jwt-secret-path = \"/root/.beacond/config/jwt.hex\"|" "${node_dir}/beacond/config/app.toml"
				else
					sed "${SED_OPT[@]}" "s|^jwt-secret-path = \".*\"|jwt-secret-path = \"${node_dir}/beacond/config/jwt.hex\"|" "${node_dir}/beacond/config/app.toml"
				fi
				# [beacon-kit-logger]
				# time-format
				sed "${SED_OPT[@]}" "s|^time-format = \".*\"|time-format = \"${apptoml_beacon_kit_logger_time_format}\"|" "${node_dir}/beacond/config/app.toml"
				# log-level
				sed "${SED_OPT[@]}" "s|^log-level = \".*\"|log-level = \"${apptoml_beacon_kit_logger_log_level}\"|" "${node_dir}/beacond/config/app.toml"
				# log-style
				sed "${SED_OPT[@]}" "s|^log-style = \".*\"|log-style = \"${apptoml_beacon_kit_logger_style}\"|" "${node_dir}/beacond/config/app.toml"
				# [beacon-kit-kzg]
				# trusted-setup-path
				if [[ "${mode}" == "docker" ]]; then
					cp ${beranodes_dir}/tmp/kzg-trusted-setup.json ${node_dir}/beacond/kzg-trusted-setup.json
					sed "${SED_OPT[@]}" "s|^trusted-setup-path = \".*\"|trusted-setup-path = \"/root/.beacond/kzg-trusted-setup.json\"|" "${node_dir}/beacond/config/app.toml"
				else
					sed "${SED_OPT[@]}" "s|^trusted-setup-path = \".*\"|trusted-setup-path = \"${beranodes_dir}/tmp/kzg-trusted-setup.json\"|" "${node_dir}/beacond/config/app.toml"
				fi
				# kzg-implementation
				sed "${SED_OPT[@]}" "s|^implementation = \".*\"|implementation = \"${apptoml_beacon_kit_kzg_implementation}\"|" "${node_dir}/beacond/config/app.toml"
				# [beacon-kit-payload-builder]
				# enabled
				sed "${SED_OPT[@]}" "157s|^enabled = .*|enabled = ${apptoml_beacon_kit_payload_builder_enabled}|" "${node_dir}/beacond/config/app.toml"
				# suggested-fee-recipient
				sed "${SED_OPT[@]}" "s|^suggested-fee-recipient = \".*\"|suggested-fee-recipient = \"${wallet_address}\"|" "${node_dir}/beacond/config/app.toml"
				# payload-timeout
				sed "${SED_OPT[@]}" "s|^payload-timeout = \".*\"|payload-timeout = \"${apptoml_beacon_kit_payload_builder_payload_timeout}\"|" "${node_dir}/beacond/config/app.toml"
				# [beacon-kit.validator]
				# graffiti
				sed "${SED_OPT[@]}" "s|^graffiti = \".*\"|graffiti = \"${moniker}\"|" "${node_dir}/beacond/config/app.toml"
				# availability-window
				sed "${SED_OPT[@]}" "s|^availability-window = \".*\"|availability-window = \"${apptoml_beacon_kit_validator_availability_window}\"|" "${node_dir}/beacond/config/app.toml"
				# [beacon-kit.node-api]
				# enabled
				sed "${SED_OPT[@]}" "180s|^enabled = .*|enabled = \"${apptoml_beacon_kit_node_api_enabled}\"|" "${node_dir}/beacond/config/app.toml"
				# address
				if [[ "${mode}" == "docker" ]]; then
					# Docker mode: use internal port 3500 and bind to all interfaces
					sed "${SED_OPT[@]}" "183s|^address = \".*\"|address = \"0.0.0.0:3500\"|" "${node_dir}/beacond/config/app.toml"
				else
					sed "${SED_OPT[@]}" "183s|^address = \".*\"|address = \"127.0.0.1:${beacond_node_port}\"|" "${node_dir}/beacond/config/app.toml"
				fi
				# logging
				sed "${SED_OPT[@]}" "s|^logging = \".*\"|logging = \"${apptoml_beacon_kit_node_api_logging}\"|" "${node_dir}/beacond/config/app.toml"
				log_success "✔ app.toml updated"

				# - update config.toml
				echo "--------------------------------"
				echo "config.toml"
				echo "--------------------------------"
				# version
				sed "${SED_OPT[@]}" "11s|^version = \".*\"|version = \"${configtoml_version}\"|" "${node_dir}/beacond/config/config.toml"
				# [base]
				# proxy_app
				if [[ "${mode}" == "docker" ]]; then
					# Docker mode: use internal port 26658
					sed "${SED_OPT[@]}" "s|^proxy_app = \".*\"|proxy_app = \"tcp://127.0.0.1:26658\"|" "${node_dir}/beacond/config/config.toml"
				else
					sed "${SED_OPT[@]}" "s|^proxy_app = \".*\"|proxy_app = \"tcp://127.0.0.1:${ethproxy_port}\"|" "${node_dir}/beacond/config/config.toml"
				fi
				# moniker
				sed "${SED_OPT[@]}" "s|^moniker = \".*\"|moniker = \"${moniker}\"|" "${node_dir}/beacond/config/config.toml"
				# db_backend
				sed "${SED_OPT[@]}" "s|^db_backend = \".*\"|db_backend = \"${configtoml_db_backend}\"|" "${node_dir}/beacond/config/config.toml"
				# db_dir
				sed "${SED_OPT[@]}" "s|^db_dir = \".*\"|db_dir = \"${node_dir}/beacond/data\"|" "${node_dir}/beacond/config/config.toml"
				# log_level
				sed "${SED_OPT[@]}" "s|^log_level = \".*\"|log_level = \"${configtoml_log_level}\"|" "${node_dir}/beacond/config/config.toml"
				# log_format
				sed "${SED_OPT[@]}" "s|^log_format = \".*\"|log_format = \"${configtoml_log_format}\"|" "${node_dir}/beacond/config/config.toml"
				# genesis_file
				if [[ "${mode}" == "docker" ]]; then
					sed "${SED_OPT[@]}" "s|^genesis_file = \".*\"|genesis_file = \"/root/.beacond/config/genesis.json\"|" "${node_dir}/beacond/config/config.toml"
				else
					sed "${SED_OPT[@]}" "s|^genesis_file = \".*\"|genesis_file = \"${node_dir}/beacond/config/genesis.json\"|" "${node_dir}/beacond/config/config.toml"
				fi
				# priv_validator_key_file
				if [[ "${mode}" == "docker" ]]; then
					sed "${SED_OPT[@]}" "s|^priv_validator_key_file = \".*\"|priv_validator_key_file = \"/root/.beacond/config/priv_validator_key.json\"|" "${node_dir}/beacond/config/config.toml"
				else
					sed "${SED_OPT[@]}" "s|^priv_validator_key_file = \".*\"|priv_validator_key_file = \"${node_dir}/beacond/config/priv_validator_key.json\"|" "${node_dir}/beacond/config/config.toml"
				fi
				# priv_validator_state_file
				if [[ "${mode}" == "docker" ]]; then
					sed "${SED_OPT[@]}" "s|^priv_validator_state_file = \".*\"|priv_validator_state_file = \"/root/.beacond/data/priv_validator_state.json\"|" "${node_dir}/beacond/config/config.toml"
				else
					sed "${SED_OPT[@]}" "s|^priv_validator_state_file = \".*\"|priv_validator_state_file = \"${node_dir}/beacond/data/priv_validator_state.json\"|" "${node_dir}/beacond/config/config.toml"
				fi
				# priv_validator_laddr
				sed "${SED_OPT[@]}" "s|^priv_validator_laddr = \".*\"|priv_validator_laddr = \"${configtoml_priv_validator_laddr}\"|" "${node_dir}/beacond/config/config.toml"
				# node_key_file
				if [[ "${mode}" == "docker" ]]; then
					sed "${SED_OPT[@]}" "s|^node_key_file = \".*\"|node_key_file = \"/root/.beacond/config/node_key.json\"|" "${node_dir}/beacond/config/config.toml"
				else
					sed "${SED_OPT[@]}" "s|^node_key_file = \".*\"|node_key_file = \"${node_dir}/beacond/config/node_key.json\"|" "${node_dir}/beacond/config/config.toml"
				fi
				# abci
				sed "${SED_OPT[@]}" "s|^abci = \".*\"|abci = \"${configtoml_abci}\"|" "${node_dir}/beacond/config/config.toml"
				# filter_peers
				sed "${SED_OPT[@]}" "s|^filter_peers = .*|filter_peers = \"${configtoml_filter_peers}\"|" "${node_dir}/beacond/config/config.toml"
				# [rpc]
				# laddr
				if [[ "${mode}" == "docker" ]]; then
					# Docker mode: use internal port 26657 and bind to all interfaces
					sed "${SED_OPT[@]}" "94s|^laddr = \".*\"|laddr = \"tcp://0.0.0.0:26657\"|" "${node_dir}/beacond/config/config.toml"
				else
					sed "${SED_OPT[@]}" "94s|^laddr = \".*\"|laddr = \"tcp://127.0.0.1:${ethrpc_port}\"|" "${node_dir}/beacond/config/config.toml"
				fi
				# cors_allowed_origins
				if [ -z "${configtoml_rpc_cors_allowed_origins}" ]; then
					sed "${SED_OPT[@]}" "s|^cors_allowed_origins = \[.*\]|cors_allowed-origins = []|" "${node_dir}/beacond/config/config.toml"
				else
					formatted_cors_allowed_origins="$(format_csv_as_string "${configtoml_rpc_cors_allowed_origins}")"
					sed "${SED_OPT[@]}" "s|^cors_allowed_origins = \[.*\]|cors_allowed-origins = [${formatted_cors_allowed_origins}]|" "${node_dir}/beacond/config/config.toml"
				fi
				# cors_allowed_methods
				if [ -z "${configtoml_rpc_cors_allowed_methods}" ]; then
					sed "${SED_OPT[@]}" "s|^cors_allowed_methods = \[.*\]|cors_allowed_methods = []|" "${node_dir}/beacond/config/config.toml"
				else
					formatted_cors_allowed_methods="$(format_csv_as_string "${configtoml_rpc_cors_allowed_methods}")"
					sed "${SED_OPT[@]}" "s|^cors_allowed_methods = \[.*\]|cors_allowed_methods = [${formatted_cors_allowed_methods}]|" "${node_dir}/beacond/config/config.toml"
				fi
				# cors_allowed_headers
				if [ -z "${configtoml_rpc_cors_allowed_headers}" ]; then
					sed "${SED_OPT[@]}" "s|^cors_allowed_headers = \[.*\]|cors_allowed_headers = []|" "${node_dir}/beacond/config/config.toml"
				else
					formatted_cors_allowed_headers="$(format_csv_as_string "${configtoml_rpc_cors_allowed_headers}")"
					sed "${SED_OPT[@]}" "s|^cors_allowed_headers = \[.*\]|cors_allowed_headers = [${formatted_cors_allowed_headers}]|" "${node_dir}/beacond/config/config.toml"
				fi
				# unsafe
				sed "${SED_OPT[@]}" "s|^unsafe = .*|unsafe = \"${configtoml_rpc_unsafe}\"|" "${node_dir}/beacond/config/config.toml"
				# max_open_connections
				sed "${SED_OPT[@]}" "s|^max_open_connections = .*|max_open_connections = \"${configtoml_rpc_max_open_connections}\"|" "${node_dir}/beacond/config/config.toml"
				# max_subscription_clients
				sed "${SED_OPT[@]}" "s|^max_subscription_clients = .*|max_subscription_clients = \"${configtoml_rpc_max_subscription_clients}\"|" "${node_dir}/beacond/config/config.toml"
				# max_subscriptions_per_client
				sed "${SED_OPT[@]}" "s|^max_subscriptions_per_client = .*|max_subscriptions_per_client = \"${configtoml_rpc_max_subscriptions_per_client}\"|" "${node_dir}/beacond/config/config.toml"
				# experimental-subscription-buffer-size
				sed "${SED_OPT[@]}" "s|^experimental_subscription_buffer_size = .*|experimental_subscription_buffer_size = \"${configtoml_rpc_experimental_subscription_buffer_size}\"|" "${node_dir}/beacond/config/config.toml"
				# experimental_websocket_write_buffer_size
				sed "${SED_OPT[@]}" "s|^experimental_websocket_write_buffer_size = .*|experimental_websocket_write_buffer_size = \"${configtoml_rpc_experimental_websocket_write_buffer_size}\"|" "${node_dir}/beacond/config/config.toml"
				# experimental_close_on_slow_client
				sed "${SED_OPT[@]}" "s|^experimental_close_on_slow_client = .*|experimental_close_on_slow_client = \"${configtoml_rpc_experimental_close_on_slow_client}\"|" "${node_dir}/beacond/config/config.toml"
				# timeout_broadcast_tx_commit
				sed "${SED_OPT[@]}" "s|^timeout_broadcast_tx_commit = \".*\"|timeout_broadcast_tx_commit = \"${configtoml_rpc_timeout_broadcast_tx_commit}\"|" "${node_dir}/beacond/config/config.toml"
				# max_request_batch_size
				sed "${SED_OPT[@]}" "s|^max_request_batch_size = .*|max_request_batch_size = \"${configtoml_rpc_max_request_batch_size}\"|" "${node_dir}/beacond/config/config.toml"
				# max_body_bytes
				sed "${SED_OPT[@]}" "s|^max_body_bytes = .*|max_body_bytes = \"${configtoml_rpc_max_body_bytes}\"|" "${node_dir}/beacond/config/config.toml"
				# max_header_bytes
				sed "${SED_OPT[@]}" "s|^max_header_bytes = .*|max_header_bytes = \"${configtoml_rpc_max_header_bytes}\"|" "${node_dir}/beacond/config/config.toml"
				# tls_cert_file
				# TODO: refactor docker compose
				sed "${SED_OPT[@]}" "s|^tls_cert_file = \".*\"|tls_cert_file = \"${configtoml_rpc_tls_cert_file}\"|" "${node_dir}/beacond/config/config.toml"
				# tls_key_file
				# TODO: refactor docker compose
				sed "${SED_OPT[@]}" "s|^tls_key_file = \".*\"|tls_key_file = \"${configtoml_rpc_tls_key_file}\"|" "${node_dir}/beacond/config/config.toml"
				# pprof_laddr
				sed "${SED_OPT[@]}" "s|^pprof_laddr = \".*\"|pprof_laddr = \"${configtoml_rpc_pprof_laddr}\"|" "${node_dir}/beacond/config/config.toml"
				# [grpc]
				# laddr
				sed "${SED_OPT[@]}" "137s|^laddr = \".*\"|laddr = \"${configtoml_grpc_laddr}\"|" "${node_dir}/beacond/config/config.toml"
				# [grpc.version_service]
				# enabled
				sed "${SED_OPT[@]}" "218s|^enabled = .*|enabled = \"${configtoml_grpc_version_service_enabled}\"|" "${node_dir}/beacond/config/config.toml"
				# [grpc.block_service]
				# enabled
				sed "${SED_OPT[@]}" "222s|^enabled = .*|enabled = \"${configtoml_grpc_block_service_enabled}\"|" "${node_dir}/beacond/config/config.toml"
				# [grpc.block_results_service]
				# enabled
				sed "${SED_OPT[@]}" "227s|^enabled = .*|enabled = \"${configtoml_grpc_block_results_service_enabled}\"|" "${node_dir}/beacond/config/config.toml"
				# [grpc.privileged]
				# laddr
				sed "${SED_OPT[@]}" "235s|^laddr = \".*\"|laddr = \"${configtoml_grpc_privileged_laddr}\"|" "${node_dir}/beacond/config/config.toml"
				# [grpc.privileged.pruning_service]
				# enabled
				sed "${SED_OPT[@]}" "248s|^enabled = .*|enabled = \"${configtoml_grpc_privileged_pruning_service_enabled}\"|" "${node_dir}/beacond/config/config.toml"
				# [p2p]
				# laddr
				if [[ "${mode}" == "docker" ]]; then
					# Docker mode: use internal port 26656
					sed "${SED_OPT[@]}" "256s|^laddr = \".*\"|laddr = \"tcp://0.0.0.0:26656\"|" "${node_dir}/beacond/config/config.toml"
				else
					sed "${SED_OPT[@]}" "256s|^laddr = \".*\"|laddr = \"tcp://0.0.0.0:${ethp2p_port}\"|" "${node_dir}/beacond/config/config.toml"
				fi
				# external_address
				sed "${SED_OPT[@]}" "s|^external_address = \".*\"|external_address = \"${configtoml_p2p_external_address}\"|" "${node_dir}/beacond/config/config.toml"
				# Adjust seeds and peers to exclude the current node for connections
				if [[ ${#seeds[@]} -gt 1 ]]; then
					read -a node_seeds < <(array_exclude_element seeds[@] "${seeds[$node_index]}")
					read -a node_p2p_ports < <(array_exclude_element p2p_ports[@] "${p2p_ports[$node_index]}")
					
					# Build array of peer indices (excluding current node)
					local peer_indices=()
					for ((pi = 0; pi < nodes_count; pi++)); do
						if [[ ${pi} -ne ${node_index} ]]; then
							peer_indices+=("${pi}")
						fi
					done
					
					if [[ "${mode}" == "docker" ]]; then
						# Docker mode: use service names and internal port 26656
						configtoml_p2p_seeds="$(
							out=()
							for pi_idx in "${!peer_indices[@]}"; do
								local peer_i="${peer_indices[$pi_idx]}"
								local peer_role="${node_roles[$peer_i]}"
								local peer_role_short="${peer_role}"
								if [[ "${peer_role}" == "validator" ]]; then
									peer_role_short="val"
								elif [[ "${peer_role}" == "full_node" ]]; then
									peer_role_short="full"
								fi
								out+=("${node_seeds[$pi_idx]}@${peer_i}-${peer_role_short}-beacond:26656")
							done
							(
								IFS=,
								echo "${out[*]}"
							)
						)"
						configtoml_p2p_persistent_peers="${configtoml_p2p_seeds}"
					else
						# Local mode: use localhost and config ports
						configtoml_p2p_seeds="$(
							out=()
							for i in "${!node_seeds[@]}"; do
								out+=("${node_seeds[$i]}@localhost:${node_p2p_ports[$i]}")
							done
							(
								IFS=,
								echo "${out[*]}"
							)
						)"
						read -a node_peers < <(array_exclude_element peers[@] "${peers[$node_index]}")
						configtoml_p2p_persistent_peers="$(
							out=()
							for i in "${!node_seeds[@]}"; do
								out+=("${node_seeds[$i]}@localhost:${node_p2p_ports[$i]}")
							done
							(
								IFS=,
								echo "${out[*]}"
							)
						)"
					fi
					# seeds
					sed "${SED_OPT[@]}" "s|^seeds = \".*\"|seeds = \"${configtoml_p2p_seeds}\"|" "${node_dir}/beacond/config/config.toml"
					# persistent_peers
					sed "${SED_OPT[@]}" "s|^persistent_peers = \".*\"|persistent_peers = \"${configtoml_p2p_persistent_peers}\"|" "${node_dir}/beacond/config/config.toml"
				fi
				# Public networks: keep official seeds from config (do not replace with local-only mesh)
				if is_public_network "${network}"; then
					configtoml_p2p_seeds=$(jq -r '.configtoml.p2p_seeds' "${config_json_path}")
					sed "${SED_OPT[@]}" "s|^seeds = \".*\"|seeds = \"${configtoml_p2p_seeds}\"|" "${node_dir}/beacond/config/config.toml"
				fi

				# addr_book_file
				if [[ "${mode}" == "docker" ]]; then
					sed "${SED_OPT[@]}" "s|^addr_book_file = \".*\"|addr_book_file = \"/root/.beacond/config/addrbook.json\"|" "${node_dir}/beacond/config/config.toml"
				else
					sed "${SED_OPT[@]}" "s|^addr_book_file = \".*\"|addr_book_file = \"${node_dir}/beacond/config/addrbook.json\"|" "${node_dir}/beacond/config/config.toml"
				fi
				# addr_book_strict
				sed "${SED_OPT[@]}" "s|^addr_book_strict = .*|addr_book_strict = \"${configtoml_p2p_addr_book_strict}\"|" "${node_dir}/beacond/config/config.toml"
				# max_num_inbound_peers
				sed "${SED_OPT[@]}" "s|^max_num_inbound_peers = .*|max_num_inbound_peers = \"${configtoml_p2p_max_num_inbound_peers}\"|" "${node_dir}/beacond/config/config.toml"
				# max_num_outbound_peers
				sed "${SED_OPT[@]}" "s|^max_num_outbound_peers = .*|max_num_outbound_peers = \"${configtoml_p2p_max_num_outbound_peers}\"|" "${node_dir}/beacond/config/config.toml"
				# unconditional_peer_ids
				sed "${SED_OPT[@]}" "s|^unconditional_peer_ids = \".*\"|unconditional_peer_ids = \"${configtoml_p2p_unconditional_peer_ids}\"|" "${node_dir}/beacond/config/config.toml"
				# persistent_peers_max_dial_period
				sed "${SED_OPT[@]}" "s|^persistent_peers_max_dial_period = \".*\"|persistent_peers_max_dial_period = \"${configtoml_p2p_persistent_peers_max_dial_period}\"|" "${node_dir}/beacond/config/config.toml"
				# flush_throttle_timeout
				sed "${SED_OPT[@]}" "s|^flush_throttle_timeout = \".*\"|flush_throttle_timeout = \"${configtoml_p2p_flush_throttle_timeout}\"|" "${node_dir}/beacond/config/config.toml"
				# max_packet_msg_payload_size
				sed "${SED_OPT[@]}" "s|^max_packet_msg_payload_size = \".*\"|max_packet_msg_payload_size = \"${configtoml_p2p_max_packet_msg_payload_size}\"|" "${node_dir}/beacond/config/config.toml"
				# send_rate
				sed "${SED_OPT[@]}" "s|^send_rate = .*|send_rate = \"${configtoml_p2p_send_rate}\"|" "${node_dir}/beacond/config/config.toml"
				# recv_rate
				sed "${SED_OPT[@]}" "s|^recv_rate = .*|recv_rate = \"${configtoml_p2p_recv_rate}\"|" "${node_dir}/beacond/config/config.toml"
				# pex
				sed "${SED_OPT[@]}" "s|^pex = .*|pex = \"${configtoml_p2p_pex}\"|" "${node_dir}/beacond/config/config.toml"
				# seed_mode
				sed "${SED_OPT[@]}" "s|^seed_mode = \".*\"|seed_mode = \"${configtoml_p2p_seed_mode}\"|" "${node_dir}/beacond/config/config.toml"
				# private_peer_ids
				sed "${SED_OPT[@]}" "s|^private_peer_ids = \".*\"|private_peer_ids = \"${configtoml_p2p_private_peer_ids}\"|" "${node_dir}/beacond/config/config.toml"
				# allow_duplicate_ip
				sed "${SED_OPT[@]}" "s|^allow_duplicate_ip = .*|allow_duplicate_ip = ${configtoml_p2p_allow_duplicate_ip}|" "${node_dir}/beacond/config/config.toml"
				# handshake_timeout
				sed "${SED_OPT[@]}" "s|^handshake_timeout = \".*\"|handshake_timeout = \"${configtoml_p2p_handshake_timeout}\"|" "${node_dir}/beacond/config/config.toml"
				# dial_timeout
				sed "${SED_OPT[@]}" "s|^dial_timeout = \".*\"|dial_timeout = \"${configtoml_p2p_dial_timeout}\"|" "${node_dir}/beacond/config/config.toml"
				# [mempool]
				# type
				sed "${SED_OPT[@]}" "s|^type = \".*\"|type = \"${configtoml_mempool_type}\"|" "${node_dir}/beacond/config/config.toml"
				# recheck
				sed "${SED_OPT[@]}" "s|^recheck = \".*\"|recheck = \"${configtoml_mempool_recheck}\"|" "${node_dir}/beacond/config/config.toml"
				# recheck_timeout
				sed "${SED_OPT[@]}" "s|^recheck_timeout = \".*\"|recheck_timeout = \"${configtoml_mempool_recheck_timeout}\"|" "${node_dir}/beacond/config/config.toml"
				# broadcast
				sed "${SED_OPT[@]}" "s|^broadcast = \".*\"|broadcast = \"${configtoml_mempool_broadcast}\"|" "${node_dir}/beacond/config/config.toml"
				# wal_dir
				sed "${SED_OPT[@]}" "s|^wal_dir = \".*\"|wal_dir = \"${configtoml_mempool_wal_dir}\"|" "${node_dir}/beacond/config/config.toml"
				# size
				sed "${SED_OPT[@]}" "s|^size = \".*\"|size = \"${configtoml_mempool_size}\"|" "${node_dir}/beacond/config/config.toml"
				# max_tx_bytes
				sed "${SED_OPT[@]}" "s|^max_tx_bytes = \".*\"|max_tx_bytes = \"${configtoml_mempool_max_tx_bytes}\"|" "${node_dir}/beacond/config/config.toml"
				# max_txs_bytes
				sed "${SED_OPT[@]}" "s|^max_txs_bytes = \".*\"|max_txs_bytes = \"${configtoml_mempool_max_txs_bytes}\"|" "${node_dir}/beacond/config/config.toml"
				# cache_size
				sed "${SED_OPT[@]}" "s|^cache_size = \".*\"|cache_size = \"${configtoml_mempool_cache_size}\"|" "${node_dir}/beacond/config/config.toml"
				# keep-invalid-txs-in-cache
				sed "${SED_OPT[@]}" "s|^keep_invalid_txs_in_cache = \".*\"|keep_invalid_txs_in_cache = \"${configtoml_mempool_keep_invalid_txs_in_cache}\"|" "${node_dir}/beacond/config/config.toml"
				# [statesync]
				# enable
				sed "${SED_OPT[@]}" "404s|^enable = .*|enable = ${configtoml_statesync_enable}|" "${node_dir}/beacond/config/config.toml"
				# rpc_servers
				sed "${SED_OPT[@]}" "s|^rpc_servers = \".*\"|rpc_servers = \"${configtoml_statesync_rpc_servers}\"|" "${node_dir}/beacond/config/config.toml"
				# trust_height
				sed "${SED_OPT[@]}" "s|^trust_height = \".*\"|trust_height = \"${configtoml_statesync_trust_height}\"|" "${node_dir}/beacond/config/config.toml"
				# trust_hash
				sed "${SED_OPT[@]}" "s|^trust_hash = \".*\"|trust_hash = \"${configtoml_statesync_trust_hash}\"|" "${node_dir}/beacond/config/config.toml"
				# trust_period
				sed "${SED_OPT[@]}" "s|^trust_period = \".*\"|trust_period = \"${configtoml_statesync_trust_period}\"|" "${node_dir}/beacond/config/config.toml"
				# discovery_time
				sed "${SED_OPT[@]}" "s|^discovery_time = \".*\"|discovery_time = \"${configtoml_statesync_discovery_time}\"|" "${node_dir}/beacond/config/config.toml"
				# temp_dir
				sed "${SED_OPT[@]}" "s|^temp_dir = \".*\"|temp_dir = \"${configtoml_statesync_temp_dir}\"|" "${node_dir}/beacond/config/config.toml"
				# chunk_request_timeout
				sed "${SED_OPT[@]}" "s|^chunk_request_timeout = \".*\"|chunk_request_timeout = \"${configtoml_statesync_chunk_request_timeout}\"|" "${node_dir}/beacond/config/config.toml"
				# chunk_fetchers
				sed "${SED_OPT[@]}" "s|^chunk_fetchers = \".*\"|chunk_fetchers = \"${configtoml_statesync_chunk_fetchers}\"|" "${node_dir}/beacond/config/config.toml"
				# [blocksync]
				# version
				sed "${SED_OPT[@]}" "442s|^version = .*|version = \"${configtoml_blocksync_version}\"|" "${node_dir}/beacond/config/config.toml"
				# [consensus]
				# wal_file
				# TODO: refactor docker compose
				sed "${SED_OPT[@]}" "s|^wal_file = \".*\"|wal_file = \"${configtoml_consensus_wal_file}\"|" "${node_dir}/beacond/config/config.toml"
				# timeout_propose
				sed "${SED_OPT[@]}" "s|^timeout_propose = \".*\"|timeout_propose = \"${configtoml_consensus_timeout_propose}\"|" "${node_dir}/beacond/config/config.toml"
				# timeout_propose_delta
				sed "${SED_OPT[@]}" "s|^timeout_propose_delta = \".*\"|timeout_propose_delta = \"${configtoml_consensus_timeout_propose_delta}\"|" "${node_dir}/beacond/config/config.toml"
				# timeout_prevote
				sed "${SED_OPT[@]}" "s|^timeout_prevote = \".*\"|timeout_prevote = \"${configtoml_consensus_timeout_prevote}\"|" "${node_dir}/beacond/config/config.toml"
				# timeout_prevote_delta
				sed "${SED_OPT[@]}" "s|^timeout_prevote_delta = \".*\"|timeout_prevote_delta = \"${configtoml_consensus_timeout_prevote_delta}\"|" "${node_dir}/beacond/config/config.toml"
				# timeout_precommit
				sed "${SED_OPT[@]}" "s|^timeout_precommit = \".*\"|timeout_precommit = \"${configtoml_consensus_timeout_precommit}\"|" "${node_dir}/beacond/config/config.toml"
				# timeout_precommit_delta
				sed "${SED_OPT[@]}" "s|^timeout_precommit_delta = \".*\"|timeout_precommit_delta = \"${configtoml_consensus_timeout_precommit_delta}\"|" "${node_dir}/beacond/config/config.toml"
				# timeout_commit
				sed "${SED_OPT[@]}" "s|^timeout_commit = \".*\"|timeout_commit = \"${configtoml_consensus_timeout_commit}\"|" "${node_dir}/beacond/config/config.toml"
				# skip_timeout_commit
				sed "${SED_OPT[@]}" "s|^skip_timeout_commit = \".*\"|skip_timeout_commit = \"${configtoml_consensus_skip_timeout_commit}\"|" "${node_dir}/beacond/config/config.toml"
				# double_sign_check_height
				sed "${SED_OPT[@]}" "s|^double_sign_check_height = \".*\"|double_sign_check_height = \"${configtoml_consensus_double_sign_check_height}\"|" "${node_dir}/beacond/config/config.toml"
				# create_empty_blocks
				sed "${SED_OPT[@]}" "s|^create_empty_blocks = \".*\"|create_empty_blocks = \"${configtoml_consensus_create_empty_blocks}\"|" "${node_dir}/beacond/config/config.toml"
				# create_empty_blocks_interval
				sed "${SED_OPT[@]}" "s|^create_empty_blocks_interval = \".*\"|create_empty_blocks_interval = \"${configtoml_consensus_create_empty_blocks_interval}\"|" "${node_dir}/beacond/config/config.toml"
				# peer_gossip_sleep_duration
				sed "${SED_OPT[@]}" "s|^peer_gossip_sleep_duration = \".*\"|peer_gossip_sleep_duration = \"${configtoml_consensus_peer_gossip_sleep_duration}\"|" "${node_dir}/beacond/config/config.toml"
				# peer_gossip_intraloop_sleep_duration
				sed "${SED_OPT[@]}" "s|^peer_gossip_intraloop_sleep_duration = \".*\"|peer_gossip_intraloop_sleep_duration = \"${configtoml_consensus_peer_gossip_intraloop_sleep_duration}\"|" "${node_dir}/beacond/config/config.toml"
				# peer_query_maj23_sleep_duration
				sed "${SED_OPT[@]}" "s|^peer_query_maj23_sleep_duration = \".*\"|peer_query_maj23_sleep_duration = \"${configtoml_consensus_peer_query_maj23_sleep_duration}\"|" "${node_dir}/beacond/config/config.toml"
				# [storage]
				# discard_abci_responses
				sed "${SED_OPT[@]}" "s|^discard_abci_responses = \".*\"|discard_abci_responses = \"${configtoml_storage_discard_abci_responses}\"|" "${node_dir}/beacond/config/config.toml"
				# experimental_db_key_layout
				sed "${SED_OPT[@]}" "s|^experimental_db_key_layout = \".*\"|experimental_db_key_layout = \"${configtoml_storage_experimental_db_key_layout}\"|" "${node_dir}/beacond/config/config.toml"
				# compact
				sed "${SED_OPT[@]}" "s|^compact = \".*\"|compact = \"${configtoml_storage_compact}\"|" "${node_dir}/beacond/config/config.toml"
				# compaction_interval
				sed "${SED_OPT[@]}" "s|^compaction_interval = \".*\"|compaction_interval = \"${configtoml_storage_compaction_interval}\"|" "${node_dir}/beacond/config/config.toml"
				# [storage.pruning]
				# interval
				sed "${SED_OPT[@]}" "s|^interval = \".*\"|interval = \"${configtoml_storage_pruning_interval}\"|" "${node_dir}/beacond/config/config.toml"
				# [storage.pruning.data_companion]
				# enabled
				sed "${SED_OPT[@]}" '537s|^enabled = .*$|enabled = '"${configtoml_storage_pruning_data_companion_enabled}"'|' "${node_dir}/beacond/config/config.toml"
				# initial_block_retain_height
				sed "${SED_OPT[@]}" "s|^initial_block_retain_height = \".*\"|initial_block_retain_height = \"${configtoml_storage_pruning_data_companion_initial_block_retain_height}\"|" "${node_dir}/beacond/config/config.toml"
				# initial_block_results_retain_height
				sed "${SED_OPT[@]}" "s|^initial_block_results_retain_height = \".*\"|initial_block_results_retain_height = \"${configtoml_storage_pruning_data_companion_initial_block_results_retain_height}\"|" "${node_dir}/beacond/config/config.toml"
				# [tx_index]
				# indexer
				sed "${SED_OPT[@]}" "s|^indexer = \".*\"|indexer = \"${configtoml_tx_index_indexer}\"|" "${node_dir}/beacond/config/config.toml"
				# psql_conn
				sed "${SED_OPT[@]}" "s|^psql_conn = \".*\"|psql_conn = \"${configtoml_tx_index_psql_conn}\"|" "${node_dir}/beacond/config/config.toml"
				# [instrumentation]
				# prometheus
				sed "${SED_OPT[@]}" "s|^prometheus = \".*\"|prometheus = \"${cl_prometheus_port}\"|" "${node_dir}/beacond/config/config.toml"
				# prometheus_listen_addr
				if [[ "${mode}" == "docker" ]]; then
					# Docker mode: use internal port 26660
					sed "${SED_OPT[@]}" "s|^prometheus_listen_addr = \".*\"|prometheus_listen_addr = \":26660\"|" "${node_dir}/beacond/config/config.toml"
				else
					sed "${SED_OPT[@]}" "s|^prometheus_listen_addr = \".*\"|prometheus_listen_addr = \":${cl_prometheus_port}\"|" "${node_dir}/beacond/config/config.toml"
				fi
				# max_open_connections
				sed "${SED_OPT[@]}" '588s|^max_open_connections = .*$|max_open_connections = '"${configtoml_instrumentation_max_open_connections}"'|' "${node_dir}/beacond/config/config.toml"
				# namespace
				sed "${SED_OPT[@]}" "s|^namespace = \".*\"|namespace = \"${configtoml_instrumentation_namespace}\"|" "${node_dir}/beacond/config/config.toml"
				log_success "✔ config.toml updated"

				# Init bera-reth node
				if is_public_network "${network}"; then
					# Built-in --chain preset; do not run `bera-reth init` (it would wipe snapshots).
					if [[ "${mode}" == "docker" ]]; then
						cp "${node_dir}/beacond/config/jwt.hex" "${bera_reth_dir}/jwt.hex" 2>/dev/null || true
					fi
					if [ -f "${bera_reth_dir}/discovery-secret" ]; then
						rm -f "${bera_reth_dir}/discovery-secret"
					fi
					local bera_reth_private_key=$(echo "${node_json}" | jq -r '.berareth_config.private_key')
					echo -n "${bera_reth_private_key}" > "${bera_reth_dir}/discovery-secret"
					log_success "✔ bera-reth datadir ready (public network; snapshot data preserved)"
				else
					cp "${beranodes_dir}${BERANODES_PATH_TMP}/${GENESIS_ETH_NAME_DEFAULT}" "${bera_reth_dir}/${GENESIS_ETH_NAME_DEFAULT}"
					if [[ "${mode}" == "docker" ]]; then
						docker run --rm -v ${bera_reth_dir}:/root/.bera-reth docker-bera-reth:${docker_berareth_tag} bera-reth init --chain=/root/.bera-reth/${GENESIS_ETH_NAME_DEFAULT} --datadir=/root/.bera-reth >/dev/null 2>&1
						# Copy jwt.hex for bera-reth in Docker mode
						cp "${node_dir}/beacond/config/jwt.hex" "${bera_reth_dir}/jwt.hex"
					else
						${bin_bera_reth} init \
							--chain="${bera_reth_dir}/${GENESIS_ETH_NAME_DEFAULT}" \
							--datadir="${bera_reth_dir}" >/dev/null 2>&1
					fi
					# remove existing discovery-secret and add the node's secret
					if [ -f "${bera_reth_dir}/discovery-secret" ]; then
						rm -f "${bera_reth_dir}/discovery-secret"
					fi
					# Write the discovery secret for bera-reth
					local bera_reth_private_key=$(echo "${node_json}" | jq -r '.berareth_config.private_key')
					echo -n "${bera_reth_private_key}" > "${bera_reth_dir}/discovery-secret"
					log_success "✔ bera-reth node initialized"
				fi
				print_node_ports "${node_json}"
			done

			# Start the nodes
			print_header "Starting nodes"
			
			if [[ "${mode}" == "docker" ]]; then
				# =================================================================
				# Docker Mode: Use docker-compose to orchestrate all nodes
				# =================================================================
				log_info "Starting nodes with docker-compose..."
				
				# Generate docker-compose.yml
				generate_docker_compose "${beranodes_dir}" "${config_json_path}" "${docker_beacond_tag}" "${docker_berareth_tag}" "${explicit_bootnodes}" "${explicit_trusted_peers}" "${enable_ws}" "${explicit_ws_addr}" "${explicit_ws_port}" "${explicit_ws_origins}"
				
				# Change to the beranodes directory for docker-compose context
				local compose_file="${beranodes_dir}/tmp/docker-compose.yml"
				
				# Stop any existing containers from previous runs
				log_info "Stopping any existing containers..."
				docker-compose -f "${compose_file}" down --remove-orphans 2>/dev/null || true
				
				# Start all services with docker-compose
				log_info "Starting docker-compose services..."
				docker-compose -f "${compose_file}" up -d
				
				if [[ $? -eq 0 ]]; then
					log_success "✔ All nodes started successfully with docker-compose"
					local nodes=$(jq -c '.nodes' "${config_json_path}")
					for ((node_index = 0; node_index < ${nodes_count}; node_index++)); do
						echo "--------------------------------"
						echo "Starting node $node_index"
						echo "--------------------------------"
						print_node_ports "$(echo "${nodes}" | jq -c ".[$node_index]")"
					done
					log_info "To view logs: docker-compose -f ${compose_file} logs -f"
					log_info "To stop: docker-compose -f ${compose_file} down"
				else
					log_error "Failed to start nodes with docker-compose"
					return 1
				fi
			else
				# =================================================================
				# Local Mode: Start nodes individually with process management
				# =================================================================
				local nodes=$(jq -r '.nodes' "${config_json_path}")
				for ((node_index = 0; node_index < ${nodes_count}; node_index++)); do
					echo "--------------------------------"
					echo "Starting node $node_index"
					echo "--------------------------------"

					# beacond
					local node_json=$(echo "${nodes}" | jq -r ".[$node_index]")
					local moniker=$(echo "${node_json}" | jq -r '.moniker')
					local role=$(echo "${node_json}" | jq -r '.role')
					local node_dir="${beranode_dir}${BERANODES_PATH_NODES}/${node_index}-${role}"
					local beacond_dir="${node_dir}/beacond"
					local bera_reth_dir="${node_dir}/bera-reth"
					local jwt=$(echo "${node_json}" | jq -r '.beacond_config.jwt')
					# Get base moniker and abbreviate role for log file naming
					local base_moniker=$(jq -r '.moniker' "${config_json_path}")
					local role_short="${role}"
					if [[ "${role}" == "validator" ]]; then
						role_short="val"
					fi

					local beacond_log="${beranode_dir}${BERANODES_PATH_LOGS}/${base_moniker}-${node_index}-${role_short}-beacond.log"
					local beacond_pid="${beranode_dir}${BERANODES_PATH_RUNS}/${base_moniker}-${node_index}-${role_short}-beacond.pid"
					_start_native_process \
						"${mode}" \
						"${beranode_dir}" \
						"${base_moniker}" \
						"${node_index}" \
						"beacond" \
						"${beacond_dir}" \
						"${beacond_log}" \
						"${beacond_pid}" \
						"${bin_beacond}" start --home "${beacond_dir}"
					log_success "✔ Beacond node started"

					# bera-reth
					local el_authrpc_port=$(echo "${node_json}" | jq -r '.el_authrpc_port')
					local el_ws_port=$(echo "${node_json}" | jq -r '.el_ws_port')
					local el_eth_port=$(echo "${node_json}" | jq -r '.el_eth_port')
					local el_ethrpc_port=$(echo "${node_json}" | jq -r '.el_ethrpc_port')
					local el_prometheus_port=$(echo "${node_json}" | jq -r '.el_prometheus_port')
					local cl_prometheus_port=$(echo "${node_json}" | jq -r '.cl_prometheus_port')
					local beacond_node_port=$(echo "${node_json}" | jq -r '.beacond_node_port')

					configtoml_berareth_bootnodes=""
					configtoml_berareth_trusted_peers=""
					if [[ ${#berareth_bootnodes[@]} -gt 1 ]]; then
						read -a bootnodes < <(array_exclude_element berareth_bootnodes[@] "${berareth_bootnodes[$node_index]}")
						read -a el_eth_ports < <(array_exclude_element berareth_el_eth_port[@] "${berareth_el_eth_port[$node_index]}")

						# Local/serviceman: IPv4 loopback. `localhost` can resolve to ::1,
						# which reth cannot dial (discv4 records and trusted peers need an IP).
						local enode_pairs=()
						local ei
						for ei in "${!bootnodes[@]}"; do
							enode_pairs+=("${bootnodes[$ei]}" "${el_eth_ports[$ei]}")
						done
						configtoml_berareth_bootnodes="$(format_reth_enodes_at_host "127.0.0.1" "${enode_pairs[@]}")"
						configtoml_berareth_trusted_peers="${configtoml_berareth_bootnodes}"
					fi

					private_key=$(echo "${node_json}" | jq -r '.berareth_config.private_key')
					public_key=$(echo "${node_json}" | jq -r '.berareth_config.public_key')

					# Add discovery secret - enode bera-reth id
					echo -n "${private_key}" >"${bera_reth_dir}/discovery-secret" 2>/dev/null

					local reth_chain_arg="--chain=${bera_reth_dir}/eth-genesis.json"
					local reth_full_arg=""
					local nat_arg="--nat=extip:127.0.0.1"
					if is_public_network "${network}"; then
						reth_chain_arg="--chain=$(network_reth_chain "${network}")"
						if reth_uses_pruning "${role}" "${snapshot_type_override}"; then
							reth_full_arg="--full"
						fi
						if [[ -n "${external_ip}" ]]; then
							nat_arg="--nat=extip:${external_ip}"
						else
							nat_arg=""
						fi
					fi
					configtoml_berareth_bootnodes="$(resolve_reth_enodes "${network}" "${configtoml_berareth_bootnodes}" "${explicit_bootnodes}")"
					configtoml_berareth_trusted_peers="$(resolve_reth_enodes "${network}" "${configtoml_berareth_trusted_peers}" "${explicit_trusted_peers}")"

					local reth_ws_flags=()
					local reth_ws_flag
					while IFS= read -r reth_ws_flag; do
						[[ -z "${reth_ws_flag}" ]] && continue
						reth_ws_flags+=("${reth_ws_flag}")
					done <<< "$(format_reth_ws_flags "${enable_ws}" "${explicit_ws_addr}" "${explicit_ws_port}" "${explicit_ws_origins}" "${el_ws_port}")"
					
					local reth_cmd=("${bin_bera_reth}" node)
					[[ -n "${configtoml_berareth_bootnodes}" ]] && reth_cmd+=(--bootnodes="${configtoml_berareth_bootnodes}")
					[[ -n "${configtoml_berareth_trusted_peers}" ]] && reth_cmd+=(--trusted-peers="${configtoml_berareth_trusted_peers}")
					if ! is_public_network "${network}"; then
						reth_cmd+=(--disable-dns-discovery)
					fi
					[[ -n "${reth_full_arg}" ]] && reth_cmd+=("${reth_full_arg}")
					reth_cmd+=(
						--authrpc.addr="127.0.0.1"
						--authrpc.port="${el_authrpc_port}"
						--authrpc.jwtsecret="${beacond_dir}/config/jwt.hex"
						"${reth_chain_arg}"
						--datadir="${bera_reth_dir}"
						--discovery.port="${el_eth_port}"
						--engine.persistence-threshold=0
						--engine.memory-block-buffer-target=0
						--http
					)
					[[ -n "${nat_arg}" ]] && reth_cmd+=("${nat_arg}")
					reth_cmd+=(
						--http.api="admin,debug,eth,net,trace,txpool,web3,rpc,reth,ots,flashbots,miner,mev"
						--http.addr=0.0.0.0
						--http.port="${el_ethrpc_port}"
						--http.corsdomain="*"
						--port="${el_eth_port}"
					)
					if [[ ${#reth_ws_flags[@]} -gt 0 ]]; then
						reth_cmd+=("${reth_ws_flags[@]}")
					fi

					local reth_log="${beranode_dir}${BERANODES_PATH_LOGS}/${base_moniker}-${node_index}-${role_short}-bera-reth.log"
					local reth_pid="${beranode_dir}${BERANODES_PATH_RUNS}/${base_moniker}-${node_index}-${role_short}-bera-reth.pid"
					_start_native_process \
						"${mode}" \
						"${beranode_dir}" \
						"${base_moniker}" \
						"${node_index}" \
						"bera-reth" \
						"${bera_reth_dir}" \
						"${reth_log}" \
						"${reth_pid}" \
						"${reth_cmd[@]}"
					log_success "✔ Bera-reth node started"
					print_node_ports "${node_json}"
				done
				if [[ "${mode}" == "serviceman" ]]; then
					log_info "Logs: ${beranode_dir}${BERANODES_PATH_LOGS}/"
					log_info "Plists: ${HOME}/Library/LaunchAgents/${SERVICEMAN_LAUNCHD_LABEL_PREFIX}.*.plist"
					log_info "Stop with: beranode stop"
				fi
			fi
		else
			# Unsupported mode (e.g., "distributed", "cloud")
			log_error "Unsupported mode: ${mode}"
			return 1
		fi
	fi
}
