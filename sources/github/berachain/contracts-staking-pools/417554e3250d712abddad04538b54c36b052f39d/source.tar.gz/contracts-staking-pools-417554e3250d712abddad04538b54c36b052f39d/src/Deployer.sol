/// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import { Create2Deployer } from "src/base/Create2Deployer.sol";
import { AccountingOracle } from "src/AccountingOracle.sol";
import { StakingPoolContractsFactory } from "src/StakingPoolContractsFactory.sol";
import { WithdrawalVault } from "src/WithdrawalVault.sol";
import { Salt } from "src/base/Salt.sol";

contract Deployer is Create2Deployer {
    /// @notice The AccountingOracle contract.
    // solhint-disable-next-line immutable-vars-naming
    AccountingOracle public immutable accountingOracle;

    /// @notice The StakingPoolContractsFactory contract.
    // solhint-disable-next-line immutable-vars-naming
    StakingPoolContractsFactory public immutable stakingPoolContractsFactory;

    /// @notice The WithdrawalVault contract.
    // solhint-disable-next-line immutable-vars-naming
    WithdrawalVault public immutable withdrawalVault;

    constructor(
        address governance,
        Salt memory accountingOracleSalt,
        Salt memory withdrawalVaultSalt,
        Salt memory stakingPoolContractsFactorySalt,
        address smartOperatorInitialImpl,
        address stakingPoolInitialImpl,
        address stakingRewardsVaultInitialImpl,
        address incentiveCollectorInitialImpl
    ) {
        // Deploy accounting oracle implementation
        address accountingOracleImpl =
            deployWithCreate2(accountingOracleSalt.implementation, type(AccountingOracle).creationCode);
        // deploy accounting oracle proxy
        accountingOracle = AccountingOracle(deployProxyWithCreate2(accountingOracleImpl, accountingOracleSalt.proxy));

        // Deploy staking pool contracts factory implementation
        address stakingPoolContractsFactoryImpl = deployWithCreate2(
            stakingPoolContractsFactorySalt.implementation, type(StakingPoolContractsFactory).creationCode
        );

        // deploy staking pool contracts factory proxy
        stakingPoolContractsFactory = StakingPoolContractsFactory(
            deployProxyWithCreate2(stakingPoolContractsFactoryImpl, stakingPoolContractsFactorySalt.proxy)
        );

        // Deploy withdrawal vault implementation
        address withdrawalVaultImpl =
            deployWithCreate2(withdrawalVaultSalt.implementation, type(WithdrawalVault).creationCode);

        // deploy withdrawal vault proxy
        withdrawalVault =
            WithdrawalVault(payable(deployProxyWithCreate2(withdrawalVaultImpl, withdrawalVaultSalt.proxy)));

        // initialize the accounting oracle
        accountingOracle.initialize(governance, address(stakingPoolContractsFactory));

        // initialize the withdrawal vault
        withdrawalVault.initialize(governance, address(stakingPoolContractsFactory));

        // initialize the staking pool contracts factory
        stakingPoolContractsFactory.initialize(
            governance,
            address(accountingOracle),
            address(withdrawalVault),
            smartOperatorInitialImpl,
            stakingPoolInitialImpl,
            stakingRewardsVaultInitialImpl,
            incentiveCollectorInitialImpl
        );
    }
}
