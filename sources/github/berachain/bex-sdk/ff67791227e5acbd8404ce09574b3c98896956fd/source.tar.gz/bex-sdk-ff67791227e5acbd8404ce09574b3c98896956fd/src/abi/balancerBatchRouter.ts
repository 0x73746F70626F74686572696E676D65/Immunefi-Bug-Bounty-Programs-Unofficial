export const balancerBatchRouterAbi = [
    {
        inputs: [
            { internalType: 'contract IVault', name: 'vault', type: 'address' },
            { internalType: 'contract IWETH', name: 'weth', type: 'address' },
            {
                internalType: 'contract IPermit2',
                name: 'permit2',
                type: 'address',
            },
            { internalType: 'string', name: 'routerVersion', type: 'string' },
        ],
        stateMutability: 'nonpayable',
        type: 'constructor',
    },
    {
        inputs: [{ internalType: 'address', name: 'target', type: 'address' }],
        name: 'AddressEmptyCode',
        type: 'error',
    },
    {
        inputs: [{ internalType: 'address', name: 'account', type: 'address' }],
        name: 'AddressInsufficientBalance',
        type: 'error',
    },
    { inputs: [], name: 'ErrorSelectorNotFound', type: 'error' },
    { inputs: [], name: 'EthTransfer', type: 'error' },
    { inputs: [], name: 'FailedInnerCall', type: 'error' },
    { inputs: [], name: 'InputLengthMismatch', type: 'error' },
    { inputs: [], name: 'InsufficientEth', type: 'error' },
    { inputs: [], name: 'ReentrancyGuardReentrantCall', type: 'error' },
    {
        inputs: [
            { internalType: 'uint8', name: 'bits', type: 'uint8' },
            { internalType: 'uint256', name: 'value', type: 'uint256' },
        ],
        name: 'SafeCastOverflowedUintDowncast',
        type: 'error',
    },
    {
        inputs: [{ internalType: 'address', name: 'token', type: 'address' }],
        name: 'SafeERC20FailedOperation',
        type: 'error',
    },
    {
        inputs: [{ internalType: 'address', name: 'sender', type: 'address' }],
        name: 'SenderIsNotVault',
        type: 'error',
    },
    { inputs: [], name: 'SwapDeadline', type: 'error' },
    { inputs: [], name: 'TransientIndexOutOfBounds', type: 'error' },
    {
        inputs: [],
        name: 'getSender',
        outputs: [{ internalType: 'address', name: '', type: 'address' }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [{ internalType: 'bytes[]', name: 'data', type: 'bytes[]' }],
        name: 'multicall',
        outputs: [
            { internalType: 'bytes[]', name: 'results', type: 'bytes[]' },
        ],
        stateMutability: 'payable',
        type: 'function',
    },
    {
        inputs: [
            {
                components: [
                    { internalType: 'address', name: 'token', type: 'address' },
                    { internalType: 'address', name: 'owner', type: 'address' },
                    {
                        internalType: 'address',
                        name: 'spender',
                        type: 'address',
                    },
                    {
                        internalType: 'uint256',
                        name: 'amount',
                        type: 'uint256',
                    },
                    { internalType: 'uint256', name: 'nonce', type: 'uint256' },
                    {
                        internalType: 'uint256',
                        name: 'deadline',
                        type: 'uint256',
                    },
                ],
                internalType: 'struct IRouterCommon.PermitApproval[]',
                name: 'permitBatch',
                type: 'tuple[]',
            },
            {
                internalType: 'bytes[]',
                name: 'permitSignatures',
                type: 'bytes[]',
            },
            {
                components: [
                    {
                        components: [
                            {
                                internalType: 'address',
                                name: 'token',
                                type: 'address',
                            },
                            {
                                internalType: 'uint160',
                                name: 'amount',
                                type: 'uint160',
                            },
                            {
                                internalType: 'uint48',
                                name: 'expiration',
                                type: 'uint48',
                            },
                            {
                                internalType: 'uint48',
                                name: 'nonce',
                                type: 'uint48',
                            },
                        ],
                        internalType:
                            'struct IAllowanceTransfer.PermitDetails[]',
                        name: 'details',
                        type: 'tuple[]',
                    },
                    {
                        internalType: 'address',
                        name: 'spender',
                        type: 'address',
                    },
                    {
                        internalType: 'uint256',
                        name: 'sigDeadline',
                        type: 'uint256',
                    },
                ],
                internalType: 'struct IAllowanceTransfer.PermitBatch',
                name: 'permit2Batch',
                type: 'tuple',
            },
            { internalType: 'bytes', name: 'permit2Signature', type: 'bytes' },
            { internalType: 'bytes[]', name: 'multicallData', type: 'bytes[]' },
        ],
        name: 'permitBatchAndCall',
        outputs: [
            { internalType: 'bytes[]', name: 'results', type: 'bytes[]' },
        ],
        stateMutability: 'payable',
        type: 'function',
    },
    {
        inputs: [
            {
                components: [
                    {
                        internalType: 'contract IERC20',
                        name: 'tokenIn',
                        type: 'address',
                    },
                    {
                        components: [
                            {
                                internalType: 'address',
                                name: 'pool',
                                type: 'address',
                            },
                            {
                                internalType: 'contract IERC20',
                                name: 'tokenOut',
                                type: 'address',
                            },
                            {
                                internalType: 'bool',
                                name: 'isBuffer',
                                type: 'bool',
                            },
                        ],
                        internalType: 'struct IBatchRouter.SwapPathStep[]',
                        name: 'steps',
                        type: 'tuple[]',
                    },
                    {
                        internalType: 'uint256',
                        name: 'exactAmountIn',
                        type: 'uint256',
                    },
                    {
                        internalType: 'uint256',
                        name: 'minAmountOut',
                        type: 'uint256',
                    },
                ],
                internalType: 'struct IBatchRouter.SwapPathExactAmountIn[]',
                name: 'paths',
                type: 'tuple[]',
            },
            { internalType: 'address', name: 'sender', type: 'address' },
            { internalType: 'bytes', name: 'userData', type: 'bytes' },
        ],
        name: 'querySwapExactIn',
        outputs: [
            {
                internalType: 'uint256[]',
                name: 'pathAmountsOut',
                type: 'uint256[]',
            },
            { internalType: 'address[]', name: 'tokensOut', type: 'address[]' },
            {
                internalType: 'uint256[]',
                name: 'amountsOut',
                type: 'uint256[]',
            },
        ],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                components: [
                    {
                        internalType: 'address',
                        name: 'sender',
                        type: 'address',
                    },
                    {
                        components: [
                            {
                                internalType: 'contract IERC20',
                                name: 'tokenIn',
                                type: 'address',
                            },
                            {
                                components: [
                                    {
                                        internalType: 'address',
                                        name: 'pool',
                                        type: 'address',
                                    },
                                    {
                                        internalType: 'contract IERC20',
                                        name: 'tokenOut',
                                        type: 'address',
                                    },
                                    {
                                        internalType: 'bool',
                                        name: 'isBuffer',
                                        type: 'bool',
                                    },
                                ],
                                internalType:
                                    'struct IBatchRouter.SwapPathStep[]',
                                name: 'steps',
                                type: 'tuple[]',
                            },
                            {
                                internalType: 'uint256',
                                name: 'exactAmountIn',
                                type: 'uint256',
                            },
                            {
                                internalType: 'uint256',
                                name: 'minAmountOut',
                                type: 'uint256',
                            },
                        ],
                        internalType:
                            'struct IBatchRouter.SwapPathExactAmountIn[]',
                        name: 'paths',
                        type: 'tuple[]',
                    },
                    {
                        internalType: 'uint256',
                        name: 'deadline',
                        type: 'uint256',
                    },
                    { internalType: 'bool', name: 'wethIsEth', type: 'bool' },
                    { internalType: 'bytes', name: 'userData', type: 'bytes' },
                ],
                internalType: 'struct IBatchRouter.SwapExactInHookParams',
                name: 'params',
                type: 'tuple',
            },
        ],
        name: 'querySwapExactInHook',
        outputs: [
            {
                internalType: 'uint256[]',
                name: 'pathAmountsOut',
                type: 'uint256[]',
            },
            { internalType: 'address[]', name: 'tokensOut', type: 'address[]' },
            {
                internalType: 'uint256[]',
                name: 'amountsOut',
                type: 'uint256[]',
            },
        ],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                components: [
                    {
                        internalType: 'contract IERC20',
                        name: 'tokenIn',
                        type: 'address',
                    },
                    {
                        components: [
                            {
                                internalType: 'address',
                                name: 'pool',
                                type: 'address',
                            },
                            {
                                internalType: 'contract IERC20',
                                name: 'tokenOut',
                                type: 'address',
                            },
                            {
                                internalType: 'bool',
                                name: 'isBuffer',
                                type: 'bool',
                            },
                        ],
                        internalType: 'struct IBatchRouter.SwapPathStep[]',
                        name: 'steps',
                        type: 'tuple[]',
                    },
                    {
                        internalType: 'uint256',
                        name: 'maxAmountIn',
                        type: 'uint256',
                    },
                    {
                        internalType: 'uint256',
                        name: 'exactAmountOut',
                        type: 'uint256',
                    },
                ],
                internalType: 'struct IBatchRouter.SwapPathExactAmountOut[]',
                name: 'paths',
                type: 'tuple[]',
            },
            { internalType: 'address', name: 'sender', type: 'address' },
            { internalType: 'bytes', name: 'userData', type: 'bytes' },
        ],
        name: 'querySwapExactOut',
        outputs: [
            {
                internalType: 'uint256[]',
                name: 'pathAmountsIn',
                type: 'uint256[]',
            },
            { internalType: 'address[]', name: 'tokensIn', type: 'address[]' },
            { internalType: 'uint256[]', name: 'amountsIn', type: 'uint256[]' },
        ],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                components: [
                    {
                        internalType: 'address',
                        name: 'sender',
                        type: 'address',
                    },
                    {
                        components: [
                            {
                                internalType: 'contract IERC20',
                                name: 'tokenIn',
                                type: 'address',
                            },
                            {
                                components: [
                                    {
                                        internalType: 'address',
                                        name: 'pool',
                                        type: 'address',
                                    },
                                    {
                                        internalType: 'contract IERC20',
                                        name: 'tokenOut',
                                        type: 'address',
                                    },
                                    {
                                        internalType: 'bool',
                                        name: 'isBuffer',
                                        type: 'bool',
                                    },
                                ],
                                internalType:
                                    'struct IBatchRouter.SwapPathStep[]',
                                name: 'steps',
                                type: 'tuple[]',
                            },
                            {
                                internalType: 'uint256',
                                name: 'maxAmountIn',
                                type: 'uint256',
                            },
                            {
                                internalType: 'uint256',
                                name: 'exactAmountOut',
                                type: 'uint256',
                            },
                        ],
                        internalType:
                            'struct IBatchRouter.SwapPathExactAmountOut[]',
                        name: 'paths',
                        type: 'tuple[]',
                    },
                    {
                        internalType: 'uint256',
                        name: 'deadline',
                        type: 'uint256',
                    },
                    { internalType: 'bool', name: 'wethIsEth', type: 'bool' },
                    { internalType: 'bytes', name: 'userData', type: 'bytes' },
                ],
                internalType: 'struct IBatchRouter.SwapExactOutHookParams',
                name: 'params',
                type: 'tuple',
            },
        ],
        name: 'querySwapExactOutHook',
        outputs: [
            {
                internalType: 'uint256[]',
                name: 'pathAmountsIn',
                type: 'uint256[]',
            },
            { internalType: 'address[]', name: 'tokensIn', type: 'address[]' },
            { internalType: 'uint256[]', name: 'amountsIn', type: 'uint256[]' },
        ],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                components: [
                    {
                        internalType: 'contract IERC20',
                        name: 'tokenIn',
                        type: 'address',
                    },
                    {
                        components: [
                            {
                                internalType: 'address',
                                name: 'pool',
                                type: 'address',
                            },
                            {
                                internalType: 'contract IERC20',
                                name: 'tokenOut',
                                type: 'address',
                            },
                            {
                                internalType: 'bool',
                                name: 'isBuffer',
                                type: 'bool',
                            },
                        ],
                        internalType: 'struct IBatchRouter.SwapPathStep[]',
                        name: 'steps',
                        type: 'tuple[]',
                    },
                    {
                        internalType: 'uint256',
                        name: 'exactAmountIn',
                        type: 'uint256',
                    },
                    {
                        internalType: 'uint256',
                        name: 'minAmountOut',
                        type: 'uint256',
                    },
                ],
                internalType: 'struct IBatchRouter.SwapPathExactAmountIn[]',
                name: 'paths',
                type: 'tuple[]',
            },
            { internalType: 'uint256', name: 'deadline', type: 'uint256' },
            { internalType: 'bool', name: 'wethIsEth', type: 'bool' },
            { internalType: 'bytes', name: 'userData', type: 'bytes' },
        ],
        name: 'swapExactIn',
        outputs: [
            {
                internalType: 'uint256[]',
                name: 'pathAmountsOut',
                type: 'uint256[]',
            },
            { internalType: 'address[]', name: 'tokensOut', type: 'address[]' },
            {
                internalType: 'uint256[]',
                name: 'amountsOut',
                type: 'uint256[]',
            },
        ],
        stateMutability: 'payable',
        type: 'function',
    },
    {
        inputs: [
            {
                components: [
                    {
                        internalType: 'address',
                        name: 'sender',
                        type: 'address',
                    },
                    {
                        components: [
                            {
                                internalType: 'contract IERC20',
                                name: 'tokenIn',
                                type: 'address',
                            },
                            {
                                components: [
                                    {
                                        internalType: 'address',
                                        name: 'pool',
                                        type: 'address',
                                    },
                                    {
                                        internalType: 'contract IERC20',
                                        name: 'tokenOut',
                                        type: 'address',
                                    },
                                    {
                                        internalType: 'bool',
                                        name: 'isBuffer',
                                        type: 'bool',
                                    },
                                ],
                                internalType:
                                    'struct IBatchRouter.SwapPathStep[]',
                                name: 'steps',
                                type: 'tuple[]',
                            },
                            {
                                internalType: 'uint256',
                                name: 'exactAmountIn',
                                type: 'uint256',
                            },
                            {
                                internalType: 'uint256',
                                name: 'minAmountOut',
                                type: 'uint256',
                            },
                        ],
                        internalType:
                            'struct IBatchRouter.SwapPathExactAmountIn[]',
                        name: 'paths',
                        type: 'tuple[]',
                    },
                    {
                        internalType: 'uint256',
                        name: 'deadline',
                        type: 'uint256',
                    },
                    { internalType: 'bool', name: 'wethIsEth', type: 'bool' },
                    { internalType: 'bytes', name: 'userData', type: 'bytes' },
                ],
                internalType: 'struct IBatchRouter.SwapExactInHookParams',
                name: 'params',
                type: 'tuple',
            },
        ],
        name: 'swapExactInHook',
        outputs: [
            {
                internalType: 'uint256[]',
                name: 'pathAmountsOut',
                type: 'uint256[]',
            },
            { internalType: 'address[]', name: 'tokensOut', type: 'address[]' },
            {
                internalType: 'uint256[]',
                name: 'amountsOut',
                type: 'uint256[]',
            },
        ],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                components: [
                    {
                        internalType: 'contract IERC20',
                        name: 'tokenIn',
                        type: 'address',
                    },
                    {
                        components: [
                            {
                                internalType: 'address',
                                name: 'pool',
                                type: 'address',
                            },
                            {
                                internalType: 'contract IERC20',
                                name: 'tokenOut',
                                type: 'address',
                            },
                            {
                                internalType: 'bool',
                                name: 'isBuffer',
                                type: 'bool',
                            },
                        ],
                        internalType: 'struct IBatchRouter.SwapPathStep[]',
                        name: 'steps',
                        type: 'tuple[]',
                    },
                    {
                        internalType: 'uint256',
                        name: 'maxAmountIn',
                        type: 'uint256',
                    },
                    {
                        internalType: 'uint256',
                        name: 'exactAmountOut',
                        type: 'uint256',
                    },
                ],
                internalType: 'struct IBatchRouter.SwapPathExactAmountOut[]',
                name: 'paths',
                type: 'tuple[]',
            },
            { internalType: 'uint256', name: 'deadline', type: 'uint256' },
            { internalType: 'bool', name: 'wethIsEth', type: 'bool' },
            { internalType: 'bytes', name: 'userData', type: 'bytes' },
        ],
        name: 'swapExactOut',
        outputs: [
            {
                internalType: 'uint256[]',
                name: 'pathAmountsIn',
                type: 'uint256[]',
            },
            { internalType: 'address[]', name: 'tokensIn', type: 'address[]' },
            { internalType: 'uint256[]', name: 'amountsIn', type: 'uint256[]' },
        ],
        stateMutability: 'payable',
        type: 'function',
    },
    {
        inputs: [
            {
                components: [
                    {
                        internalType: 'address',
                        name: 'sender',
                        type: 'address',
                    },
                    {
                        components: [
                            {
                                internalType: 'contract IERC20',
                                name: 'tokenIn',
                                type: 'address',
                            },
                            {
                                components: [
                                    {
                                        internalType: 'address',
                                        name: 'pool',
                                        type: 'address',
                                    },
                                    {
                                        internalType: 'contract IERC20',
                                        name: 'tokenOut',
                                        type: 'address',
                                    },
                                    {
                                        internalType: 'bool',
                                        name: 'isBuffer',
                                        type: 'bool',
                                    },
                                ],
                                internalType:
                                    'struct IBatchRouter.SwapPathStep[]',
                                name: 'steps',
                                type: 'tuple[]',
                            },
                            {
                                internalType: 'uint256',
                                name: 'maxAmountIn',
                                type: 'uint256',
                            },
                            {
                                internalType: 'uint256',
                                name: 'exactAmountOut',
                                type: 'uint256',
                            },
                        ],
                        internalType:
                            'struct IBatchRouter.SwapPathExactAmountOut[]',
                        name: 'paths',
                        type: 'tuple[]',
                    },
                    {
                        internalType: 'uint256',
                        name: 'deadline',
                        type: 'uint256',
                    },
                    { internalType: 'bool', name: 'wethIsEth', type: 'bool' },
                    { internalType: 'bytes', name: 'userData', type: 'bytes' },
                ],
                internalType: 'struct IBatchRouter.SwapExactOutHookParams',
                name: 'params',
                type: 'tuple',
            },
        ],
        name: 'swapExactOutHook',
        outputs: [
            {
                internalType: 'uint256[]',
                name: 'pathAmountsIn',
                type: 'uint256[]',
            },
            { internalType: 'address[]', name: 'tokensIn', type: 'address[]' },
            { internalType: 'uint256[]', name: 'amountsIn', type: 'uint256[]' },
        ],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [],
        name: 'version',
        outputs: [{ internalType: 'string', name: '', type: 'string' }],
        stateMutability: 'view',
        type: 'function',
    },
    { stateMutability: 'payable', type: 'receive' },
] as const;
