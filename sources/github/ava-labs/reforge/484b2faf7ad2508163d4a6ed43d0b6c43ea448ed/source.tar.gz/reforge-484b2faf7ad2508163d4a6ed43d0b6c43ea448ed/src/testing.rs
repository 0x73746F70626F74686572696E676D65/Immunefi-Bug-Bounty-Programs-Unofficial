// Copyright (C) 2026, Ava Labs, Inc.
// See the file LICENSE for licensing terms.

//! Test utilities for verifying macro expansions against expected Solidity output.

use std::{collections::HashSet, path::Path};

use foundry_compilers::{
    Language, ProjectPathsConfig, SourceParser,
    artifacts::{SolcLanguage, Source, Sources},
    utils::source_files_iter,
};
use solar::{parse::interface::Session, sema::Compiler};

use crate::{Macro, PreprocessingData};

/// Loads all `.sol` files under `dir` into a `Sources` map keyed by absolute path.
pub(crate) fn load_sol_sources(dir: &Path) -> eyre::Result<Sources> {
    Source::read_all(source_files_iter(dir, SolcLanguage::FILE_EXTENSIONS))
        .map_err(|e| eyre::eyre!("{e}"))
}

/// Runs `macro_rules` over the Solidity sources in `source`, then compares the
/// expanded output file-by-file against the pre-expanded sources in `expected`
/// (matched by path relative to their respective roots).
///
/// On mismatch, the actual expanded content is written to `mismatches` (mirroring
/// the same relative path structure) so testers can inspect the output and copy
/// it to `expected` if it is correct.
pub fn test_macros(
    source: impl AsRef<Path>,
    expected: impl AsRef<Path>,
    mismatches: impl AsRef<Path>,
    macro_rules: &[Macro],
) -> eyre::Result<()> {
    let source = source.as_ref();
    let expected = expected.as_ref();
    let snapshot = mismatches.as_ref();

    let sources = expand_macros(source, None, macro_rules)?;
    let expected_sources = load_sol_sources(expected)?;

    let mut failures: Vec<(std::path::PathBuf, String)> = Vec::new();
    for (actual_path, actual_src) in &sources {
        let relative_path = actual_path.strip_prefix(source).map_err(|_| {
            eyre::eyre!(
                "expanded source path '{}' is not under source root '{}'",
                actual_path.display(),
                source.display()
            )
        })?;
        let expected_path = expected.join(relative_path);
        let actual_formatted = crate::display::format_sol(actual_src.content.as_str());
        let matches = expected_sources.get(&expected_path).is_some_and(|exp| {
            actual_formatted == crate::display::format_sol(exp.content.as_str())
        });
        if !matches {
            failures.push((relative_path.to_path_buf(), actual_formatted));
        }
    }

    if !failures.is_empty() {
        for (relative_path, content) in &failures {
            let snapshot_path = snapshot.join(relative_path);
            if let Some(parent) = snapshot_path.parent() {
                std::fs::create_dir_all(parent)?;
            }
            std::fs::write(&snapshot_path, content)?;
        }
        let paths: Vec<_> = failures.iter().map(|(p, _)| p.display().to_string()).collect();
        eyre::bail!(
            "macro expansion mismatch in: {}\nActual output written to '{}' — copy to '{}' if correct.",
            paths.join(", "),
            snapshot.display(),
            expected.display(),
        );
    }

    Ok(())
}

/// Runs `macro_rule` over the Solidity sources in `source` and expects the
/// rule to return an error. Returns the error if one is produced, else fails
/// if the rule completes without error.
pub fn test_macro_err(source: impl AsRef<Path>, macro_rule: Macro) -> eyre::Result<eyre::Report> {
    match expand_macros(source, None, &[macro_rule]) {
        Err(e) => Ok(e),
        Ok(_) => eyre::bail!("expected macro to error but it succeeded"),
    }
}

/// Runs `macro_rules` over the Solidity sources in `source` and returns the
/// expanded [`Sources`] map. Rules are applied in order, with each rule seeing
/// the output of the previous.
///
/// When `paths` is `Some`, Solar is initialised with the provided
/// `ProjectPathsConfig` so that Foundry remappings are resolved correctly. Pass
/// `None` for self-contained test fixtures that have no external imports.
pub fn expand_macros(
    source: impl AsRef<Path>,
    paths: Option<&ProjectPathsConfig<SolcLanguage>>,
    macro_rules: &[Macro],
) -> eyre::Result<Sources> {
    let source = source.as_ref();
    let sources = load_sol_sources(source)?;
    expand_macros_with_sources(sources, source, paths, macro_rules)
}

/// Runs `macro_rules` over a pre-loaded [`Sources`] map and returns the expanded result.
///
/// Unlike [`expand_macros`], this does not load files from disk — callers supply the
/// sources directly. `root` is used as [`PreprocessingData::root_dir`].  When `paths`
/// is `Some`, Solar is initialised with the provided `ProjectPathsConfig` so that
/// Foundry remappings are resolved correctly for any imports that solar needs to follow.
pub fn expand_macros_with_sources(
    mut sources: Sources,
    root: &Path,
    paths: Option<&ProjectPathsConfig<SolcLanguage>>,
    macro_rules: &[Macro],
) -> eyre::Result<Sources> {
    let mut compiler = match paths {
        Some(paths) => {
            foundry_compilers::resolver::parse::SolParser::new(paths.with_language_ref())
                .into_compiler()
        }
        None => {
            let session = Session::builder().with_silent_emitter(None).build();
            Compiler::new(session)
        }
    };

    crate::solar_load_and_lower(
        &mut compiler,
        sources.iter().map(|(p, s)| (p.clone(), s.content.as_str())),
    );

    let relative_paths_storage;
    let src_dir = match paths {
        Some(paths) => {
            relative_paths_storage = paths.paths_relative();
            &relative_paths_storage.sources
        }
        None => root,
    };
    let mut mocks = HashSet::new();
    let mut data = PreprocessingData {
        input: &mut sources,
        root_dir: root,
        src_dir,
        mocks: &mut mocks,
        offset_adjustments: Default::default(),
    };
    compiler
        .enter_mut(|compiler| -> foundry_compilers::error::Result<()> {
            let gcx = compiler.gcx();
            for rule in macro_rules {
                rule(&gcx, &mut data)?;
            }
            Ok(())
        })
        .map_err(|e| eyre::eyre!("{e}"))?;

    Ok(sources)
}
