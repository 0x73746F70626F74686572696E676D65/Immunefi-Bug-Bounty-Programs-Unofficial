/*******************************************************************************
*   (c) 2022 Zondax AG
*
*  Licensed under the Apache License, Version 2.0 (the "License");
*  you may not use this file except in compliance with the License.
*  You may obtain a copy of the License at
*
*      http://www.apache.org/licenses/LICENSE-2.0
*
*  Unless required by applicable law or agreed to in writing, software
*  distributed under the License is distributed on an "AS IS" BASIS,
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*  See the License for the specific language governing permissions and
*  limitations under the License.
********************************************************************************/
use core::{mem::MaybeUninit, ptr::addr_of_mut};
use zemu_sys::ViewError;

use super::parse_rlp_item;
use super::BaseLegacy;
use crate::parser::ETH_MAINNET_ID;
use crate::parser::{DisplayableItem, FromBytes, ParserError};

#[derive(Clone, Copy, PartialEq, Eq)]
#[cfg_attr(test, derive(Debug))]
pub struct Eip2930<'b> {
    // it is not clear if chainID
    // is an u32, u8, u64
    // considering this might
    // come from an avax C-Chain
    chain_id: &'b [u8],
    pub base: BaseLegacy<'b>,
    access_list: &'b [u8],
    // R and S must be empty
    // so do not put and empty
    // field here, it is just to indicate
    // that they are expected
}

impl Eip2930<'_> {
    pub fn chain_id(&self) -> &[u8] {
        self.chain_id
    }
}

impl<'b> FromBytes<'b> for Eip2930<'b> {
    fn from_bytes_into(
        input: &'b [u8],
        out: &mut MaybeUninit<Self>,
    ) -> Result<&'b [u8], nom::Err<ParserError>> {
        crate::zlog("Eip2930::from_bytes_into\x00");

        // get out pointer
        let out = out.as_mut_ptr();

        // chainID
        let (rem, id_bytes) = parse_rlp_item(input)?;
        if id_bytes.is_empty() {
            return Err(ParserError::InvalidChainId.into());
        }

        let data_out = unsafe { &mut *addr_of_mut!((*out).base).cast() };
        let rem = BaseLegacy::from_bytes_into(rem, data_out)?;

        // access list
        let (rem, access_list) = parse_rlp_item(rem)?;

        let chain_id = super::bytes_to_u64(id_bytes)?;

        if chain_id == ETH_MAINNET_ID {
            crate::zlog("Mainnet not allowed\x00");
            return Err(ParserError::InvalidChainId.into());
        }

        // check for erc721 call and chainID
        #[cfg(feature = "erc721")]
        {
            let base = unsafe { &*data_out.as_ptr() };
            if matches!(base.data, crate::parser::EthData::Erc721(..)) {
                let contract_chain_id = crate::parser::ERC721Info::get_nft_info()?.chain_id;
                if chain_id != contract_chain_id {
                    return Err(ParserError::InvalidAssetCall.into());
                }
            }
        }

        // The transaction RLP list must be fully consumed after the access
        // list; any trailing item would be included in the signing hash
        // without being surfaced in the review UI.
        if !rem.is_empty() {
            return Err(ParserError::UnexpectedData.into());
        }

        unsafe {
            addr_of_mut!((*out).chain_id).write(id_bytes);
            addr_of_mut!((*out).access_list).write(access_list);
            // Backfill the embedded BaseLegacy with the chain_id so its
            // renderer can pick the right ticker prefix (AVAX vs ???).
            addr_of_mut!((*out).base.chain_id).write(id_bytes);
        }

        Ok(rem)
    }
}

impl DisplayableItem for Eip2930<'_> {
    fn num_items(&self) -> Result<u8, ViewError> {
        let items = self.base.num_items()?;

        // Includes chain_id in the list
        Ok(items + 1)
    }

    fn render_item(
        &self,
        item_n: u8,
        title: &mut [u8],
        message: &mut [u8],
        page: u8,
    ) -> Result<u8, ViewError> {
        if item_n == 0 {
            return super::render_chain_id(title, message, page, self.chain_id);
        }

        let item_n = item_n - 1;
        self.base.render_item(item_n, title, message, page)
    }
}

#[cfg(test)]
mod tests {
    use crate::parser::EthData;

    use super::*;

    #[test]
    fn parse_eip2930() {
        let data = "01f901b10280018402625a0080830186a0b901447f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f7465737432000000000000000000000000000000000000000000000000000000600057f85bf859940000000000000000000000000000000000000101f842a00000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000060a7";
        let data = hex::decode(data).unwrap();

        // remove transaction version, which is the first bytes
        let (_, bytes) = parse_rlp_item(&data[1..]).unwrap();

        _ = Eip2930::from_bytes(bytes).unwrap().1;
    }

    #[test]
    fn parse_eip2930_contract_call() {
        let data = "01f901c60281e0018402625a0094cccccccccccccccccccccccccccccccccccccccc830186a0b901447f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f7465737432000000000000000000000000000000000000000000000000000000600057f85bf859940000000000000000000000000000000000000101f842a00000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000060a7";
        let data = hex::decode(data).unwrap();

        let address = hex::decode("cccccccccccccccccccccccccccccccccccccccc").unwrap();

        // remove transaction version, which is the first bytes
        let (_, bytes) = parse_rlp_item(&data[1..]).unwrap();

        let tx = Eip2930::from_bytes(bytes).unwrap().1;

        assert_eq!(tx.base.value[0], 1u8);
        assert_eq!(tx.base.nonce[0], 0xe0);

        assert!(matches!(tx.base.data, EthData::ContractCall(..)));
        assert_eq!(&tx.base.to.unwrap().raw_address()[..], &address);
    }

    // Same RLP body as `parse_eip2930_contract_call`, but with an extra `0x01`
    // item appended inside the transaction list (body length 0x01c6 → 0x01c7).
    // The trailing byte would otherwise be covered by the signing hash without
    // being displayed.
    #[test]
    fn parse_eip2930_with_trailing_bytes_rejected() {
        let data = "01f901c70281e0018402625a0094cccccccccccccccccccccccccccccccccccccccc830186a0b901447f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f74657374320000000000000000000000000000000000000000000000000000006000577f7465737432000000000000000000000000000000000000000000000000000000600057f85bf859940000000000000000000000000000000000000101f842a00000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000060a701";
        let data = hex::decode(data).unwrap();

        let (_, bytes) = parse_rlp_item(&data[1..]).unwrap();
        let tx = Eip2930::from_bytes(bytes);
        assert!(tx.is_err());
    }
}
