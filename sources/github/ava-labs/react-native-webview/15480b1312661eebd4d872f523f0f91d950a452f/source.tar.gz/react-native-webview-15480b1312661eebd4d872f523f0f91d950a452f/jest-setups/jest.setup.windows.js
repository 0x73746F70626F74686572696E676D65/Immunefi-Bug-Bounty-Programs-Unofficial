export const platform = 'windows';
