//  Created by react-native-create-bridge

// import RCTBridgeModule
#if __has_include(<React/RCTBridgeModule.h>)
#import <React/RCTBridgeModule.h>
#elif __has_include(“RCTBridgeModule.h”)
#import “RCTBridgeModule.h”
#else
#import “React/RCTBridgeModule.h” // Required when used as a Pod in a Swift project
#endif

#import <Firebase/Firebase.h>

@interface StartupPerformanceTrace : NSObject <RCTBridgeModule>

@property (class, nonatomic, assign, readonly) FIRTrace* startupTrace;
+ (void)start;

@end
