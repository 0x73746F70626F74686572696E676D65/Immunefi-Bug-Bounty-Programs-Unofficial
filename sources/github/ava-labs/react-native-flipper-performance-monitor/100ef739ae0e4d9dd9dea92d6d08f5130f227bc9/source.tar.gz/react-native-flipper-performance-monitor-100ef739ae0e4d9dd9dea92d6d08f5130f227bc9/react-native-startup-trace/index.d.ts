export const useStopStartupTrace: () => void;
