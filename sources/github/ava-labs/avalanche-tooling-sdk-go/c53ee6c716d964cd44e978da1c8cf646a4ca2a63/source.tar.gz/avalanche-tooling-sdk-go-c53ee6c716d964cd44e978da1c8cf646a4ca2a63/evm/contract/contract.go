// Copyright (C) 2025, Ava Labs, Inc. All rights reserved.
// See the file LICENSE for licensing terms.
package contract

import (
	"encoding/json"
	"fmt"
	"math/big"
	"reflect"
	"strings"

	"github.com/ava-labs/avalanchego/utils/logging"
	"github.com/ava-labs/avalanchego/vms/platformvm/warp"
	"github.com/ava-labs/libevm/common"
	"github.com/ava-labs/libevm/core/types"
	"github.com/ava-labs/subnet-evm/accounts/abi/bind"

	"github.com/ava-labs/avalanche-tooling-sdk-go/evm"
	"github.com/ava-labs/avalanche-tooling-sdk-go/utils"
)

var ErrFailedReceiptStatus = fmt.Errorf("failed receipt status")

func removeSurroundingParenthesis(s string) (string, error) {
	s = strings.TrimSpace(s)
	if len(s) > 0 {
		if string(s[0]) != "(" || string(s[len(s)-1]) != ")" {
			return "", fmt.Errorf("expected esp %q to be surrounded by parenthesis", s)
		}
		s = s[1 : len(s)-1]
	}
	return s, nil
}

func removeSurroundingBrackets(s string) (string, error) {
	s = strings.TrimSpace(s)
	if len(s) > 0 {
		if string(s[0]) != "[" || string(s[len(s)-1]) != "]" {
			return "", fmt.Errorf("expected esp %q to be surrounded by parenthesis", s)
		}
		s = s[1 : len(s)-1]
	}
	return s, nil
}

func getWords(s string) []string {
	words := []string{}
	word := ""
	parenthesisCount := 0
	insideBrackets := false
	for _, rune := range s {
		c := string(rune)
		if parenthesisCount > 0 {
			word += c
			if c == "(" {
				parenthesisCount++
			}
			if c == ")" {
				parenthesisCount--
				if parenthesisCount == 0 {
					words = append(words, word)
					word = ""
				}
			}
			continue
		}
		if insideBrackets {
			word += c
			if c == "]" {
				words = append(words, word)
				word = ""
				insideBrackets = false
			}
			continue
		}
		if c == " " || c == "," || c == "(" || c == "[" {
			if word != "" {
				words = append(words, word)
				word = ""
			}
		}
		if c == " " || c == "," {
			continue
		}
		if c == "(" {
			parenthesisCount++
		}
		if c == "[" {
			insideBrackets = true
		}
		word += c
	}
	if word != "" {
		words = append(words, word)
	}
	return words
}

func getMap(
	types []string,
	params interface{},
) ([]map[string]interface{}, error) {
	r := []map[string]interface{}{}
	for i, t := range types {
		var (
			param      interface{}
			name       string
			structName string
		)
		rt := reflect.ValueOf(params)
		if rt.Kind() == reflect.Ptr {
			rt = rt.Elem()
		}
		if rt.Kind() == reflect.Slice {
			if rt.Len() != len(types) {
				if rt.Len() == 1 {
					return getMap(types, rt.Index(0).Interface())
				} else {
					return nil, fmt.Errorf(
						"inconsistency in slice len between method esp %q and given params %#v: expected %d got %d",
						types,
						params,
						len(types),
						rt.Len(),
					)
				}
			}
			param = rt.Index(i).Interface()
		} else if rt.Kind() == reflect.Struct {
			if rt.NumField() < len(types) {
				return nil, fmt.Errorf(
					"inconsistency in struct len between method esp %q and given params %#v: expected %d got %d",
					types,
					params,
					len(types),
					rt.NumField(),
				)
			}
			name = rt.Type().Field(i).Name
			structName = rt.Type().Field(i).Type.Name()
			param = rt.Field(i).Interface()
		}
		m := map[string]interface{}{}
		switch {
		case string(t[0]) == "(":
			// struct type
			var err error
			t, err = removeSurroundingParenthesis(t)
			if err != nil {
				return nil, err
			}
			m["components"], err = getMap(getWords(t), param)
			if err != nil {
				return nil, err
			}
			if structName != "" {
				m["internalType"] = "struct " + structName
			} else {
				m["internalType"] = "tuple"
			}
			m["type"] = "tuple"
			m["name"] = name
		case string(t[0]) == "[":
			var err error
			t, err = removeSurroundingBrackets(t)
			if err != nil {
				return nil, err
			}
			if string(t[0]) == "(" {
				t, err = removeSurroundingParenthesis(t)
				if err != nil {
					return nil, err
				}
				rt := reflect.ValueOf(param)
				if rt.Kind() != reflect.Slice {
					return nil, fmt.Errorf("expected param for field %d of esp %q to be an slice", i, types)
				}
				param = reflect.Zero(rt.Type().Elem()).Interface()
				structName = rt.Type().Elem().Name()
				m["components"], err = getMap(getWords(t), param)
				if err != nil {
					return nil, err
				}
				if structName != "" {
					m["internalType"] = "struct " + structName + "[]"
				} else {
					m["internalType"] = "tuple[]"
				}
				m["type"] = "tuple[]"
				m["name"] = name
			} else {
				m["internalType"] = fmt.Sprintf("%s[]", t)
				m["type"] = fmt.Sprintf("%s[]", t)
				m["name"] = name
			}
		default:
			m["internalType"] = t
			m["type"] = t
			m["name"] = name
		}
		r = append(r, m)
	}
	return r, nil
}

func ParseSpec(
	esp string,
	indexedFields []int,
	constructor bool,
	event bool,
	paid bool,
	view bool,
	outputParams interface{},
	params ...interface{},
) (string, string, error) {
	index := strings.Index(esp, "(")
	if index == -1 {
		return esp, "", nil
	}
	name := esp[:index]
	types := esp[index:]
	inputs := ""
	outputs := ""
	index = strings.Index(types, "->")
	if index == -1 {
		inputs = types
	} else {
		inputs = types[:index]
		outputs = types[index+2:]
	}
	var err error
	inputs, err = removeSurroundingParenthesis(inputs)
	if err != nil {
		return "", "", err
	}
	outputs, err = removeSurroundingParenthesis(outputs)
	if err != nil {
		return "", "", err
	}
	inputTypes := getWords(inputs)
	outputTypes := getWords(outputs)
	inputsMaps, err := getMap(inputTypes, params)
	if err != nil {
		return "", "", err
	}
	outputsMaps, err := getMap(outputTypes, outputParams)
	if err != nil {
		return "", "", err
	}
	if event {
		for i := range inputsMaps {
			if utils.Belongs(indexedFields, i) {
				inputsMaps[i]["indexed"] = true
			} else {
				inputsMaps[i]["indexed"] = false
			}
		}
	}
	abiMap := []map[string]interface{}{
		{
			"inputs": inputsMaps,
		},
	}
	switch {
	case paid:
		abiMap[0]["stateMutability"] = "payable"
	case view:
		abiMap[0]["stateMutability"] = "view"
	default:
		abiMap[0]["stateMutability"] = "nonpayable"
	}
	switch {
	case constructor:
		abiMap[0]["type"] = "constructor"
	case event:
		abiMap[0]["type"] = "event"
		abiMap[0]["name"] = name
		delete(abiMap[0], "stateMutability")
	default:
		abiMap[0]["type"] = "function"
		abiMap[0]["outputs"] = outputsMaps
		abiMap[0]["name"] = name
	}
	abiBytes, err := json.MarshalIndent(abiMap, "", "  ")
	if err != nil {
		return "", "", err
	}
	return name, string(abiBytes), nil
}

// get method name and types from [methodsSpec], then call it
// at the smart contract [contractAddress] with the given [params].
// also send [payment] tokens to it
func TxToMethod(
	logger logging.Logger,
	rpcURL string,
	signer *evm.Signer,
	contractAddress common.Address,
	payment *big.Int,
	description string,
	errorSignatureToError map[string]error,
	methodSpec string,
	params ...interface{},
) (*types.Transaction, *types.Receipt, error) {
	methodName, methodABI, err := ParseSpec(methodSpec, nil, false, false, payment != nil, false, nil, params...)
	if err != nil {
		return nil, nil, err
	}
	metadata := &bind.MetaData{
		ABI: methodABI,
	}
	abi, err := metadata.GetAbi()
	if err != nil {
		return nil, nil, err
	}
	client, err := evm.GetClient(rpcURL)
	if err != nil {
		return nil, nil, err
	}
	defer client.Close()
	contract := bind.NewBoundContract(contractAddress, *abi, client.EthClient, client.EthClient, client.EthClient)
	txOpts, err := client.GetTxOptsWithSigner(signer)
	if err != nil {
		return nil, nil, err
	}
	txOpts.Value = payment
	tx, err := contract.Transact(txOpts, methodName, params...)
	if err != nil {
		// Try to map the error, or enrich it with selector/revert data if no mapping found
		return tx, nil, ExtractAndEnrichRPCError(err, errorSignatureToError)
	}
	if txOpts.NoSend {
		return tx, nil, nil
	}
	receipt, success, err := client.WaitForTransaction(tx)
	if err != nil {
		return tx, nil, err
	} else if !success {
		return handleFailedReceiptStatus(
			logger,
			rpcURL,
			description,
			errorSignatureToError,
			tx,
			receipt,
		)
	}
	return tx, receipt, nil
}

// get method name and types from [methodsSpec], then call it
// at the smart contract [contractAddress] with the given [params].
// send [warpMessage] on the same call, whose signature is
// going to be verified previously to pass it to the method
// also send [payment] tokens to it
func TxToMethodWithWarpMessage(
	logger logging.Logger,
	rpcURL string,
	signer *evm.Signer,
	contractAddress common.Address,
	warpMessage *warp.Message,
	payment *big.Int,
	description string,
	errorSignatureToError map[string]error,
	methodSpec string,
	params ...interface{},
) (*types.Transaction, *types.Receipt, error) {
	methodName, methodABI, err := ParseSpec(methodSpec, nil, false, false, false, false, nil, params...)
	if err != nil {
		return nil, nil, err
	}
	metadata := &bind.MetaData{
		ABI: methodABI,
	}
	abi, err := metadata.GetAbi()
	if err != nil {
		return nil, nil, err
	}
	callData, err := abi.Pack(methodName, params...)
	if err != nil {
		return nil, nil, err
	}
	client, err := evm.GetClient(rpcURL)
	if err != nil {
		return nil, nil, err
	}
	defer client.Close()
	tx, err := client.TransactWithWarpMessage(
		signer,
		warpMessage,
		contractAddress,
		callData,
		payment,
	)
	if err != nil {
		// Try to map the error, or enrich it with selector/revert data if no mapping found
		return nil, nil, ExtractAndEnrichRPCError(err, errorSignatureToError)
	}
	if isNoOp, err := signer.IsNoOp(); err != nil {
		return nil, nil, err
	} else if isNoOp {
		return tx, nil, nil
	}
	if err := client.SendTransaction(tx); err != nil {
		return tx, nil, err
	}
	receipt, success, err := client.WaitForTransaction(tx)
	if err != nil {
		return tx, receipt, err
	} else if !success {
		return handleFailedReceiptStatus(
			logger,
			rpcURL,
			description,
			errorSignatureToError,
			tx,
			receipt,
		)
	}
	return tx, receipt, nil
}

func printFailedReceiptStatusMessage(
	logger logging.Logger,
	rpcURL string,
	description string,
	tx *types.Transaction,
) {
	logger.Error(fmt.Sprintf("Failed receipt status for %s error on %s, tx hash %s",
		description,
		rpcURL,
		tx.Hash()),
	)
}

func handleFailedReceiptStatus(
	logger logging.Logger,
	rpcURL string,
	description string,
	errorSignatureToError map[string]error,
	tx *types.Transaction,
	receipt *types.Receipt,
) (*types.Transaction, *types.Receipt, error) {
	// Re-simulate the transaction at the block before it was mined to get the revert reason
	// This uses standard eth_call instead of debug_traceTransaction
	txHash := tx.Hash().String()
	simErr := evm.SimulateTransaction(rpcURL, txHash)

	// If the simulation returned an error, try to extract and map it
	if simErr != nil {
		if mappedErr := ExtractErrorFromRPCError(simErr, errorSignatureToError); mappedErr != simErr {
			// Successfully mapped the error
			return tx, receipt, mappedErr
		}
		// Could not map the error, but we have the revert reason
		printFailedReceiptStatusMessage(logger, rpcURL, description, tx)
		// Try to extract and print error selector and revert data for debugging
		if errorSelector, err := GetErrorSelectorFromRPCError(simErr); err == nil {
			logger.Error(fmt.Sprintf("Error selector: %s", errorSelector))
		}
		if revertData, err := GetRevertDataFromRPCError(simErr); err == nil {
			logger.Error(fmt.Sprintf("Revert data: %s", revertData))
		}
		logger.Error(fmt.Sprintf("Transaction reverted: %s", simErr))
		return tx, receipt, simErr
	}

	// Simulation succeeded but original tx failed (race condition or other issue)
	printFailedReceiptStatusMessage(logger, rpcURL, description, tx)
	logger.Error("Transaction failed on-chain but succeeded during simulation (possible race condition)")
	return tx, receipt, ErrFailedReceiptStatus
}

func CallToMethod(
	rpcURL string,
	from common.Address,
	contractAddress common.Address,
	methodSpec string,
	outputParams interface{},
	params ...interface{},
) ([]interface{}, error) {
	methodName, methodABI, err := ParseSpec(methodSpec, nil, false, false, false, true, outputParams, params...)
	if err != nil {
		return nil, err
	}
	metadata := &bind.MetaData{
		ABI: methodABI,
	}
	abi, err := metadata.GetAbi()
	if err != nil {
		return nil, err
	}
	client, err := evm.GetClient(rpcURL)
	if err != nil {
		return nil, err
	}
	defer client.Close()
	contract := bind.NewBoundContract(contractAddress, *abi, client.EthClient, client.EthClient, client.EthClient)
	var out []interface{}
	err = contract.Call(&bind.CallOpts{From: from}, &out, methodName, params...)
	if err != nil {
		return nil, err
	}
	return out, nil
}

func GetSmartContractCallResult[T any](methodName string, out []interface{}) (T, error) {
	empty := new(T)
	if len(out) == 0 {
		return *empty, fmt.Errorf("error at %s call: no return value", methodName)
	}
	if len(out) != 1 {
		return *empty, fmt.Errorf("error at %s call: expected 1 return value, got %d", methodName, len(out))
	}
	received, typeIsOk := out[0].(T)
	if !typeIsOk {
		return *empty, fmt.Errorf("error at %s call, expected %T, got %T", methodName, *empty, out[0])
	}
	return received, nil
}

func DeployContract(
	rpcURL string,
	signer *evm.Signer,
	binBytes []byte,
	methodSpec string,
	params ...interface{},
) (common.Address, *types.Transaction, *types.Receipt, error) {
	_, methodABI, err := ParseSpec(methodSpec, nil, true, false, false, false, nil, params...)
	if err != nil {
		return common.Address{}, nil, nil, err
	}
	metadata := &bind.MetaData{
		ABI: methodABI,
		Bin: string(binBytes),
	}
	abi, err := metadata.GetAbi()
	if err != nil {
		return common.Address{}, nil, nil, err
	}
	bin := common.FromHex(metadata.Bin)
	if len(bin) == 0 {
		return common.Address{}, nil, nil, fmt.Errorf("failure on given binary for smart contract: zero len")
	}
	client, err := evm.GetClient(rpcURL)
	if err != nil {
		return common.Address{}, nil, nil, err
	}
	defer client.Close()
	txOpts, err := client.GetTxOptsWithSigner(signer)
	if err != nil {
		return common.Address{}, nil, nil, err
	}
	address, tx, _, err := bind.DeployContract(txOpts, *abi, bin, client.EthClient, params...)
	if err != nil {
		return common.Address{}, nil, nil, err
	}
	receipt, success, err := client.WaitForTransaction(tx)
	if err != nil {
		return common.Address{}, tx, receipt, err
	} else if !success {
		return common.Address{}, tx, receipt, ErrFailedReceiptStatus
	}
	return address, tx, receipt, nil
}

func UnpackLog(
	eventSpec string,
	indexedFields []int,
	log types.Log,
	event interface{},
) error {
	eventName, eventABI, err := ParseSpec(eventSpec, indexedFields, false, true, false, false, nil, event)
	if err != nil {
		return err
	}
	metadata := &bind.MetaData{
		ABI: eventABI,
	}
	abi, err := metadata.GetAbi()
	if err != nil {
		return err
	}
	contract := bind.NewBoundContract(common.Address{}, *abi, nil, nil, nil)
	return contract.UnpackLog(event, eventName, log)
}
