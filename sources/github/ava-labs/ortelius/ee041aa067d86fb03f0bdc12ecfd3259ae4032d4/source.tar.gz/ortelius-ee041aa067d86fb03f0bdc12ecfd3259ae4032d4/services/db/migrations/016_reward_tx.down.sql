DROP TABLE `rewards`;
