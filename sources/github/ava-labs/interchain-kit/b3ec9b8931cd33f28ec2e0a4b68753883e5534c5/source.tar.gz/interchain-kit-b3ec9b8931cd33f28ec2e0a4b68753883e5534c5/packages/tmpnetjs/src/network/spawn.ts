// Boot the avalanchego primary network (P, X, C chains).
//
// This is a TypeScript translation of avalanche-benchmark's
// `local/internal/network/network.go`. Each call to `startPrimaryNetwork`:
//
//   1. Locates an avalanchego binary (env > PATH > workDir/bin).
//   2. For each requested primary node:
//        - allocates HTTP/staking ports (9650 + 100*i, +1).
//        - prepares a private node data dir under <workDir>/data/node-N/.
//        - spawns avalanchego with `--network-id=local` and a fresh ephemeral
//          staking key. Node 0 is the bootstrap; others bootstrap off it.
//        - tees stdout+stderr to <workDir>/logs/node-N.log.
//   3. Polls `/ext/info` on every node until they all report a node ID,
//      then resolves with handles + RPC URLs.
//
// `--network-id=local` makes avalanchego load its built-in local genesis,
// which pre-funds the EWOQ key on the C-Chain. We don't need to provide
// `--genesis-file` for that — it's only required for custom networks.

import { execSync } from "node:child_process";
import { accessSync, constants, existsSync, mkdirSync, statSync } from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * The 5 canonical local-network staker keys, vendored into this package at
 * `<pkg>/staking/local`. Both `dist/network/spawn.js` and `src/network/spawn.ts`
 * sit two levels under the package root, so the same relative path resolves it.
 */
const VENDORED_STAKING_KEYS_DIR = path.join(
  path.dirname(fileURLToPath(import.meta.url)),
  "..",
  "..",
  "staking",
  "local",
);

import { binaryPath } from "@interchain-kit/icm-services-installer";

import type { paths as Paths } from "../internal/config.js";
import { spawnTracked } from "../internal/process.js";
import { PreflightError } from "../internal/preflight.js";
import type { ProcessHandle } from "../types.js";

/**
 * Avalanchego ships 5 preconfigured local-network staker keys. The local
 * genesis stamps them into the initial primary-network validator set, so
 * using these keys (instead of ephemeral certs) lets a 1-or-more-node
 * primary network actually leave bootstrap.
 *
 * Lookup order:
 *   1. AVALANCHEGO_STAKING_KEYS_DIR (explicit override)
 *   2. <dirname(AVALANCHEGO_PATH)>/../staking/local
 *      (matches the canonical `<repo>/build/avalanchego` + `<repo>/staking/local`
 *      layout shipped by the avalanchego source tree.)
 */
export function resolveStakingKeysDir(avalanchegoBinary: string | undefined): string {
  const candidates: string[] = [];
  const env = process.env.AVALANCHEGO_STAKING_KEYS_DIR?.trim();
  if (env) candidates.push(env);
  // <avalanchego>/build/avalanchego => <avalanchego>/staking/local. Skipped
  // when the binary itself didn't resolve — the combined preflight still wants
  // to report the keys requirement, and the explicit env override above may
  // satisfy it on its own.
  if (avalanchegoBinary) {
    candidates.push(
      path.join(path.dirname(avalanchegoBinary), "..", "staking", "local"),
    );
  }
  // Always available: the keys vendored into this package. Release binaries
  // don't ship the key files (they're embedded in the binary's genesis), so
  // this is what makes a zero-env-var boot work.
  candidates.push(VENDORED_STAKING_KEYS_DIR);
  for (const dir of candidates) {
    const abs = path.resolve(dir);
    if (existsSync(path.join(abs, "staker1.key"))) return abs;
  }
  // Without these keys the nodes would boot with ephemeral certs, hold
  // NodeIDs that are NOT in the local genesis validator set, and the network
  // would sit at `isBootstrapped: false` until the timeout — with no error
  // anywhere but a `bls: node is not a validator` line in /ext/health.
  // Refuse up front instead.
  throw new PreflightError(
    [
      "Local staking keys (staker1.key ...) not found — refusing to boot.",
      "",
      ...(candidates.length
        ? ["Tried (in order):", ...candidates.map((c) => `  - ${path.resolve(c)}`), ""]
        : []),
      "The local network genesis only admits the 5 canonical staker NodeIDs as",
      "validators; without their keys the primary network can never leave bootstrap.",
      "",
      "Fixes:",
      "  - Set AVALANCHEGO_STAKING_KEYS_DIR=<avalanchego repo>/staking/local",
      "  - Or run an avalanchego binary from a source tree, which ships the keys",
      "    next to it (<repo>/build/avalanchego + <repo>/staking/local)",
    ].join("\n"),
  );
}

/** Number of preconfigured local stakers shipped with avalanchego. */
const MAX_LOCAL_STAKERS = 5;

/** Result of {@link startPrimaryNetwork}. */
export interface PrimaryNetwork {
  /** One handle per spawned avalanchego process, in node-index order. */
  nodes: PrimaryNodeHandle[];
  /** Canonical C-Chain RPC URL (uses node 0). */
  cChainRpcUrl: string;
  /** Where every node has its HTTP API listening (`http://127.0.0.1:<port>`). */
  apiURIs: string[];
}

/** Per-node metadata we hold onto for downstream l1/icm work. */
export interface PrimaryNodeHandle extends ProcessHandle {
  /** Sequential index (0 is the bootstrap node). */
  index: number;
  /** `http://127.0.0.1:<httpPort>` — base URL for /ext/info, /ext/bc/P, etc. */
  apiURI: string;
  /** NodeID-... string returned by `info.getNodeID`. Filled once healthy. */
  nodeID: string;
  /** HTTP API port. */
  httpPort: number;
  /** P2P staking port. */
  stakingPort: number;
}

const BASE_HTTP_PORT = 9650;
/** Per-node port stride. Mirrors avalanche-benchmark. */
const PORT_INCREMENT = 100;
const HEALTH_TIMEOUT_MS = 60_000;
const HEALTH_POLL_INTERVAL_MS = 250;

/**
 * Locate a usable `avalanchego` binary. Lookup order:
 *
 *   1. `process.env.AVALANCHEGO_PATH` (highest priority — explicit user choice)
 *   2. The PATH (via `which avalanchego`)
 *   3. `<workDir>/bin/avalanchego` (a plain drop-in)
 *   4. `<workDir>/bin/avalanchego-v<ver>/avalanchego` (the pinned release the
 *      zero-setup `up` auto-installs). `up` pins AVALANCHEGO_PATH for its own
 *      process, but a standalone consumer script (add-validator) runs without
 *      that env, so we resolve the cache path the installer would have used.
 *
 * Throws with install instructions if none of those resolve to an existing
 * file. We deliberately don't try `$HOME/code/avalanchego/build/avalanchego`
 * or similar — those leak my developer environment into someone else's repo.
 */
export function findAvalanchego(workDir: string): string {
  const candidates: string[] = [];
  const envPath = process.env.AVALANCHEGO_PATH?.trim();
  if (envPath) candidates.push(envPath);

  try {
    const onPath = execSync("which avalanchego", { encoding: "utf8" }).trim();
    if (onPath) candidates.push(onPath);
  } catch {
    // `which` returns non-zero when not found — fine, fall through.
  }

  candidates.push(path.join(workDir, "bin", "avalanchego"));
  // The pinned release auto-installed by `up` (versioned cache subdir).
  candidates.push(binaryPath("avalanchego", { cacheDir: path.join(workDir, "bin") }));

  // First candidate that existed but couldn't be used as a binary, plus why.
  // Surfaced in the error so "you pointed AVALANCHEGO_PATH at the build/
  // directory" beats a bare "not found".
  let rejected: string | undefined;

  for (const candidate of candidates) {
    let abs = path.resolve(candidate);
    let isDir: boolean;
    try {
      isDir = statSync(abs).isDirectory();
    } catch {
      continue; // doesn't exist — try the next candidate
    }

    // Common foot-gun: AVALANCHEGO_PATH points at the source tree's `build/`
    // directory (or repo root) instead of the binary. Resolve the conventional
    // `<dir>/avalanchego` rather than letting spawn() choke on a directory
    // later with an opaque "returned no PID".
    if (isDir) {
      const inner = path.join(abs, "avalanchego");
      try {
        if (!statSync(inner).isFile()) throw new Error("not a file");
      } catch {
        rejected ??= `${abs} is a directory with no 'avalanchego' binary inside it`;
        continue;
      }
      abs = inner;
    }

    // Must be runnable. A non-executable file (lost +x, or a stray text file)
    // would also fail at spawn with no useful diagnostic.
    try {
      accessSync(abs, constants.X_OK);
    } catch {
      rejected ??= `${abs} is not executable — run: chmod +x ${abs}`;
      continue;
    }
    return abs;
  }

  throw new Error(
    [
      "avalanchego binary not found.",
      "",
      "Tried (in order):",
      ...candidates.map((c) => `  - ${c}`),
      ...(rejected ? ["", `Closest match was unusable: ${rejected}.`] : []),
      "",
      "Fixes:",
      "  - Set AVALANCHEGO_PATH to the binary itself (e.g. <repo>/build/avalanchego).",
      "    Pointing it at the build/ directory also works — we resolve the binary inside.",
      "  - Install via `go install github.com/ava-labs/avalanchego@latest`",
      "  - Or drop the binary at <workDir>/bin/avalanchego",
    ].join("\n"),
  );
}

/**
 * Spawn the primary network and wait for every node to be healthy.
 *
 * @param cfg - Normalized network config (see config.ts). We only read
 *   `cfg.primaryNodes` and `cfg.workDir` here.
 * @param ps  - Output of `paths(cfg.workDir)`.
 */
export async function startPrimaryNetwork(
  cfg: { primaryNodes: number; workDir: string },
  ps: ReturnType<typeof Paths>,
): Promise<PrimaryNetwork> {
  const avalanchego = findAvalanchego(cfg.workDir);
  const stakingKeysDir = resolveStakingKeysDir(avalanchego);
  // One line that answers "which binary/keys did it actually pick?" — the
  // first question every version-mismatch or wrong-binary debugging session
  // starts with.
  console.log(`[primary] avalanchego: ${avalanchego} (staking keys: ${stakingKeysDir})`);

  // Pre-create top-level dirs the spawn helper would otherwise have to make
  // lazily. Saves a per-process mkdir and matches paths.go in benchmark.
  for (const dir of [ps.data, ps.logs, ps.bin, ps.artifacts]) {
    mkdirSync(dir, { recursive: true });
  }

  const nodeCount = Math.min(
    Math.max(1, cfg.primaryNodes),
    MAX_LOCAL_STAKERS,
  );
  const nodes: PrimaryNodeHandle[] = [];

  // Start the bootstrap node first. Subsequent nodes will use its NodeID +
  // staking endpoint to join. We can't compute the NodeID up front because
  // we're letting avalanchego generate ephemeral staking keys per node.
  const bootstrap = await spawnPrimaryNode({
    index: 0,
    avalanchego,
    paths: ps,
    bootstrap: undefined, // node 0 IS the bootstrap; no peer
    stakerNum: 1,
    stakingKeysDir,
  });
  nodes.push(bootstrap);

  // Remaining nodes bootstrap off node 0. Each node is its own process-group
  // leader (see internal/process.ts) so SIGTERM on `down` cascades to that
  // node's subnet-evm plugin grandchild.
  for (let i = 1; i < nodeCount; i++) {
    const node = await spawnPrimaryNode({
      index: i,
      avalanchego,
      paths: ps,
      bootstrap: {
        nodeID: bootstrap.nodeID,
        stakingPort: bootstrap.stakingPort,
      },
      stakerNum: i + 1,
      stakingKeysDir,
    });
    nodes.push(node);
  }

  // Every primary node serves the C-Chain at the same path. We arbitrarily
  // return node 0's URL for downstream wallets; callers needing load balancing
  // can iterate `apiURIs`.
  const node0 = nodes[0];
  if (!node0) {
    throw new Error("internal: primary network started 0 nodes");
  }
  return {
    nodes,
    cChainRpcUrl: `${node0.apiURI}/ext/bc/C/rpc`,
    apiURIs: nodes.map((n) => n.apiURI),
  };
}

interface SpawnPrimaryNodeArgs {
  index: number;
  avalanchego: string;
  paths: ReturnType<typeof Paths>;
  /** Pass omitted for the bootstrap node, set for everyone else. */
  bootstrap: { nodeID: string; stakingPort: number } | undefined;
  /**
   * 1-based index into the preconfigured local staker key set
   * (staker1..staker5).
   */
  stakerNum: number;
  stakingKeysDir: string;
}

/**
 * Spawn one avalanchego primary-network node, wait for it to expose a node
 * ID via `/ext/info`, and return its handle.
 *
 * Implementation notes:
 *   - We rely on `--network-id=local` to populate the built-in EWOQ genesis.
 *     Custom networks would also need `--genesis-file`.
 *   - `--sybil-protection-enabled=false` lets us run with a single
 *     ephemeral staking key without needing pre-distributed stakers.
 *   - The bootstrap node is told to expect zero peers (`--bootstrap-ips=`,
 *     `--bootstrap-ids=`) so it doesn't sit forever trying to join.
 */
async function spawnPrimaryNode(args: SpawnPrimaryNodeArgs): Promise<PrimaryNodeHandle> {
  const { index, avalanchego, paths: ps, bootstrap } = args;
  const httpPort = BASE_HTTP_PORT + index * PORT_INCREMENT;
  const stakingPort = httpPort + 1;
  const nodeDir = path.join(ps.data, `node-${index}`);
  const logFile = path.join(ps.logs, `node-${index}.log`);
  const name = `node-${index}`;

  // Subdirectories avalanchego will write into. Creating them up-front
  // makes flags + on-disk layout legible from the outside.
  for (const sub of ["db", "logs", "staking", "chainData", "configs"]) {
    mkdirSync(path.join(nodeDir, sub), { recursive: true });
  }

  const cliArgs: string[] = [
    `--http-port=${httpPort}`,
    `--staking-port=${stakingPort}`,
    "--http-host=127.0.0.1",
    "--network-id=local",
    // sybil-protection MUST stay ON (default). With it off, every node
    // reports myNodeID=NodeID-111...DBWJs at the network layer, which
    // doesn't match the staker NodeID that ConvertSubnetToL1 baked into
    // the L1 validator set. Result: L1 consensus can't find its peers
    // and the chain never leaves bootstrap.
    `--data-dir=${nodeDir}`,
    `--db-dir=${path.join(nodeDir, "db")}`,
    `--log-dir=${path.join(nodeDir, "logs")}`,
    `--chain-data-dir=${path.join(nodeDir, "chainData")}`,
  ];

  // The local network's genesis stamps the canonical staker NodeIDs into the
  // initial primary-network validator set, so consensus can converge with as
  // few as 1 node. An ephemeral-cert fallback would produce a non-validator
  // NodeID and a network that never bootstraps, so a missing key file is an
  // error, not a downgrade.
  const stakerNum = args.stakerNum;
  for (const file of [`staker${stakerNum}.crt`, `staker${stakerNum}.key`, `signer${stakerNum}.key`]) {
    if (!existsSync(path.join(args.stakingKeysDir, file))) {
      throw new Error(
        `Staking keys dir ${args.stakingKeysDir} is missing ${file} — ` +
          `node-${index} would boot as a non-validator and the network could never bootstrap.`,
      );
    }
  }
  cliArgs.push(
    `--staking-tls-cert-file=${path.join(args.stakingKeysDir, `staker${stakerNum}.crt`)}`,
    `--staking-tls-key-file=${path.join(args.stakingKeysDir, `staker${stakerNum}.key`)}`,
    `--staking-signer-key-file=${path.join(args.stakingKeysDir, `signer${stakerNum}.key`)}`,
  );

  if (bootstrap) {
    cliArgs.push(
      `--bootstrap-ips=127.0.0.1:${bootstrap.stakingPort}`,
      `--bootstrap-ids=${bootstrap.nodeID}`,
    );
  } else {
    // Explicitly empty values stop avalanchego from looking up the default
    // mainnet bootstrappers. Without these the bootstrap node will hang
    // trying to contact peers that don't exist on the local network.
    cliArgs.push("--bootstrap-ips=", "--bootstrap-ids=");
  }

  const handle = spawnTracked(name, avalanchego, cliArgs, logFile, {
    cwd: nodeDir,
    pidFile: ps.pidFile,
    kind: "primary",
  });

  const apiURI = `http://127.0.0.1:${httpPort}`;
  const nodeID = await waitForNodeID(apiURI, HEALTH_TIMEOUT_MS);

  return {
    ...handle,
    index,
    apiURI,
    nodeID,
    httpPort,
    stakingPort,
  };
}

/**
 * Poll `<apiURI>/ext/info { method: "info.getNodeID" }` until it returns a
 * non-empty NodeID or the deadline elapses. We use this as our "is the node
 * up?" signal rather than `/ext/health` because health is much pickier (it
 * wants chains to be bootstrapped) and we just want the HTTP server alive.
 */
export async function waitForNodeID(
  apiURI: string,
  timeoutMs: number,
): Promise<string> {
  const deadline = Date.now() + timeoutMs;
  let lastErr: unknown = undefined;

  while (Date.now() < deadline) {
    try {
      const res = await fetch(`${apiURI}/ext/info`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          jsonrpc: "2.0",
          id: 1,
          method: "info.getNodeID",
        }),
      });
      if (res.ok) {
        const json = (await res.json()) as {
          result?: { nodeID?: string };
        };
        const nodeID = json.result?.nodeID;
        if (nodeID && nodeID.startsWith("NodeID-")) {
          return nodeID;
        }
      }
    } catch (err) {
      lastErr = err;
    }
    await new Promise((r) => setTimeout(r, HEALTH_POLL_INTERVAL_MS));
  }

  throw new Error(
    `Timed out after ${timeoutMs}ms waiting for ${apiURI}/ext/info. ` +
      `Last error: ${String(lastErr)}`,
  );
}

/**
 * Wait until every node in the primary network reports `info.isBootstrapped`
 * for the P, X, and C chains. Heavier than {@link waitForNodeID} but the
 * right check before issuing a CreateSubnet tx.
 */
export async function waitForBootstrap(
  apiURI: string,
  chain: "P" | "X" | "C",
  timeoutMs: number,
): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  // Track the last thing we saw, error or not. A node that answers
  // `isBootstrapped: false` forever is the common failure (wrong staking
  // keys → not a validator → no consensus), and it never throws.
  let last = "no response received";
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`${apiURI}/ext/info`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          jsonrpc: "2.0",
          id: 1,
          method: "info.isBootstrapped",
          params: { chain },
        }),
      });
      if (res.ok) {
        const json = (await res.json()) as {
          result?: { isBootstrapped?: boolean };
        };
        if (json.result?.isBootstrapped === true) return;
        last = `last response: ${JSON.stringify(json)}`;
      } else {
        last = `last response: HTTP ${res.status}`;
      }
    } catch (err) {
      last = `last error: ${String(err)}`;
    }
    await new Promise((r) => setTimeout(r, HEALTH_POLL_INTERVAL_MS));
  }
  throw new Error(
    `Timed out waiting for ${chain}-Chain bootstrap at ${apiURI} (${last}). ` +
      `If the node keeps reporting isBootstrapped=false, check ${apiURI}/ext/health — ` +
      `"node is not a validator" means it isn't using the canonical local staking keys.`,
  );
}

/** Re-exported so callers can compute extra ports without doing arithmetic. */
export const PRIMARY_PORTS = {
  BASE_HTTP_PORT,
  PORT_INCREMENT,
};
