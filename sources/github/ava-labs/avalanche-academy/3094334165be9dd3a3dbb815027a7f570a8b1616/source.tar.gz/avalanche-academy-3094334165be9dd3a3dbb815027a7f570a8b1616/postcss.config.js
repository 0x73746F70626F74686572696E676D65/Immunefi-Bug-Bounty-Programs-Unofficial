module.exports = {
  plugins: {
    tailwindcss: {}
  },
};
