module.exports = {
  distDir: 'build',
};
