// (c) 2024, Ava Labs, Inc. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AvaLabsProprietary

// This code is licensed under a custom license.
// See the file LICENSE for licensing terms.

pragma solidity 0.8.25;

import {IVRFConsumerRegistry} from "./interfaces/IVRFConsumerRegistry.sol";
import {AccessControl} from "@openzeppelin/contracts@5.0.2/access/AccessControl.sol";

/// @custom:security-contact security.alerts@nima.enterprises
contract VRFConsumerRegistry is IVRFConsumerRegistry, AccessControl {
    /// @inheritdoc IVRFConsumerRegistry
    mapping(address consumer => bool isApproved) public isApprovedConsumer;

    /// @inheritdoc IVRFConsumerRegistry
    bytes32 public constant CONSUMER_MANAGER = keccak256("CONSUMER_MANAGER");

    constructor(address admin, address[] memory consumerManagers) {
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(CONSUMER_MANAGER, admin);
        uint256 length = consumerManagers.length;
        for (uint256 i; i < length; ++i) {
            _grantRole(CONSUMER_MANAGER, consumerManagers[i]);
        }
    }

    /// @inheritdoc IVRFConsumerRegistry
    function addConsumers(address[] calldata consumers) external onlyRole(CONSUMER_MANAGER) {
        uint256 length = consumers.length;
        for (uint256 i; i < length; ++i) {
            address consumer = consumers[i];
            if (!isApprovedConsumer[consumer] && consumer != address(0)) {
                isApprovedConsumer[consumer] = true;
                emit ConsumerAdded(consumer);
            }
        }
    }

    /// @inheritdoc IVRFConsumerRegistry
    function removeConsumers(address[] calldata consumers) external onlyRole(CONSUMER_MANAGER) {
        uint256 length = consumers.length;
        for (uint256 i; i < length; ++i) {
            address consumer = consumers[i];
            if (isApprovedConsumer[consumer] && consumer != address(0)) {
                delete isApprovedConsumer[consumer];
                emit ConsumerRemoved(consumer);
            }
        }
    }
}
