// (c) 2024, Ava Labs, Inc. All rights reserved.
// SPDX-License-Identifier: LicenseRef-AvaLabsProprietary

// This code is licensed under a custom license.
// See the file LICENSE for licensing terms.

pragma solidity 0.8.25;

import {IVRFConsumerRegistry} from "./interfaces/IVRFConsumerRegistry.sol";
import {IVRFProxy} from "./interfaces/IVRFProxy.sol";
import {VRFRequestInfo, VRFResponseInfo} from "./interfaces/IVRF.sol";
import {GasUtils} from "./libraries/GasUtils.sol";
import {TeleporterMessageInput, TeleporterFeeInfo} from "@teleporter/ITeleporterMessenger.sol";
import {TeleporterRegistryOwnableApp} from "@teleporter/registry/TeleporterRegistryOwnableApp.sol";
import {VRFV2PlusWrapperConsumerBase} from "@chainlink/contracts/src/v0.8/vrf/dev/VRFV2PlusWrapperConsumerBase.sol";

/// @custom:security-contact security.alerts@nima.enterprises
contract VRFProxy is IVRFProxy, TeleporterRegistryOwnableApp {
    /// @inheritdoc IVRFProxy
    IVRFConsumerRegistry public immutable vrfConsumerRegistry;
    /// @inheritdoc IVRFProxy
    bytes32 public immutable vrfProviderBlockchainID;
    /// @inheritdoc IVRFProxy
    address public immutable vrfProviderAddress;
    /// @inheritdoc IVRFProxy
    uint256 public requestNonce;
    /// @inheritdoc IVRFProxy
    mapping(uint256 requestID => address requester) public requesters;

    /// Chainlink Avalanche values
    uint32 public maximumRandomWords = 10;
    uint16 public minimumConfirmations = 0;
    uint16 public constant MAXIMUM_CONFIRMATIONS = 200;

    /// @inheritdoc IVRFProxy
    uint256 public constant VRF_REQUEST_REQUIRED_GAS = 500_000;

    constructor(
        address teleporterRegistryAddress_,
        address vrfConsumerRegistry_,
        bytes32 vrfProviderBlockchainID_,
        address vrfProviderAddress_
    ) TeleporterRegistryOwnableApp(teleporterRegistryAddress_, msg.sender, 1) {
        if (vrfProviderAddress_ == address(0)) revert VRFProviderAddressIsZero();
        vrfProviderAddress = vrfProviderAddress_;
        if (vrfConsumerRegistry_ == address(0)) revert VRFConsumerRegistryAddressIsZero();
        vrfConsumerRegistry = IVRFConsumerRegistry(vrfConsumerRegistry_);
        if (vrfProviderBlockchainID_ == bytes32(0)) revert VRFProviderBlockchainIDIsZero();
        vrfProviderBlockchainID = vrfProviderBlockchainID_;
    }

    /// @inheritdoc IVRFProxy
    function setMinimumConfirmations(uint16 minimumConfirmations_) external onlyOwner {
        if (minimumConfirmations_ > MAXIMUM_CONFIRMATIONS) revert InvalidValue();
        minimumConfirmations = minimumConfirmations_;
        emit MinimumConfirmationsSet(minimumConfirmations_);
    }

    /// @inheritdoc IVRFProxy
    function setMaximumRandomWords(uint32 maximumRandomWords_) external onlyOwner {
        if (maximumRandomWords_ > type(uint8).max) revert InvalidValue();
        maximumRandomWords = maximumRandomWords_;
        emit MaximumRandomWordsSet(maximumRandomWords_);
    }

    /// @inheritdoc IVRFProxy
    function requestRandomWords(uint16 minimumRequestConfirmations, uint32 callbackGasLimit, uint32 numWords)
        external
        returns (uint256)
    {
        // Ensure that caller is an approved consumer.
        if (!vrfConsumerRegistry.isApprovedConsumer(msg.sender)) revert CallerIsNotAnApprovedConsumer();
        if (minimumRequestConfirmations < minimumConfirmations || minimumRequestConfirmations > MAXIMUM_CONFIRMATIONS) {
            revert MinimumRequestConfirmationsIsOutOfBounds();
        }
        if (numWords > maximumRandomWords) revert NumberOfRequestedWordsIsOverTheLimit();
        // Assign the next nonce to be used at the request ID.
        uint256 nonce = ++requestNonce;
        VRFRequestInfo memory requestInfo = VRFRequestInfo({
            requestID: nonce,
            minimumRequestConfirmations: minimumRequestConfirmations,
            callbackGasLimit: callbackGasLimit,
            numWords: numWords,
            consumer: msg.sender
        });

        // Store the address requesting the random value to be called
        // when the random value is fulfilled via receival of a Teleporter
        // message.
        requesters[nonce] = msg.sender;

        // Submit the VRF request to the partner VRFProvider via Teleporter message.
        _getTeleporterMessenger().sendCrossChainMessage(
            TeleporterMessageInput({
                destinationBlockchainID: vrfProviderBlockchainID,
                destinationAddress: vrfProviderAddress,
                feeInfo: TeleporterFeeInfo({feeTokenAddress: address(0), amount: 0}),
                requiredGasLimit: VRF_REQUEST_REQUIRED_GAS,
                allowedRelayerAddresses: new address[](0),
                message: abi.encode(requestInfo)
            })
        );

        emit RandomWordsRequested({
            requestID: nonce,
            requester: msg.sender,
            minimumRequestConfirmations: minimumRequestConfirmations,
            callbackGasLimit: callbackGasLimit,
            numWords: numWords
        });

        return nonce;
    }

    /**
     * @dev Called when a Teleporter message is delivered to this VRFProxyContract. Verifies the sender of the message
     * and then processes it by passing the random values back to their original requester.
     * @param sourceBlockchainID - The blockchain ID where the message originated. The only allowed sender is
     * the vrfProviderBlockchainID.
     * @param originSenderAddress - The address of the message sender on the source blockchain. The only allowed sender
     * is the vrfProviderAddress.
     * @param message - The raw Teleporter message payload. Expected to be an ABI encoded VRFResponseInfo instance.
     */
    function _receiveTeleporterMessage(bytes32 sourceBlockchainID, address originSenderAddress, bytes memory message)
        internal
        override
    {
        // Verify the sender.
        if (sourceBlockchainID != vrfProviderBlockchainID) revert InvalidSourceBlockchainID();
        if (originSenderAddress != vrfProviderAddress) revert CallerNotVRFProvider();

        // Decode the response.
        VRFResponseInfo memory response = abi.decode(message, (VRFResponseInfo));
        // gas opt
        uint256 requestID = response.requestID;

        // Ensure the validity of the requestID.
        address requester = requesters[requestID];
        if (requester == address(0)) revert InvalidRequestID();

        // Clear the requesting address since the request is now fulfilled.
        delete requesters[requestID];

        // Pass the result to the destination with the exact gas limit.
        bytes memory resp =
            abi.encodeCall(VRFV2PlusWrapperConsumerBase.rawFulfillRandomWords, (requestID, response.randomWords));

        // Call with explicitly the amount of callback gas requested.
        // Note that _callWithSufficientGas will revert if we do not have sufficient gas
        // to give the callee their requested amount.
        bool success = GasUtils._callWithSufficientGas(response.callbackGasLimit, requester, resp);
        if (!success) revert ConsumerCallFailed();

        emit RandomWordsFulfilled(requestID);
    }
}
