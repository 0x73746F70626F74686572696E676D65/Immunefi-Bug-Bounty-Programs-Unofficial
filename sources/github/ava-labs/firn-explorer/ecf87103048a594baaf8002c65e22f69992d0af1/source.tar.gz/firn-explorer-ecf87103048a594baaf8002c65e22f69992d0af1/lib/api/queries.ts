/**
 * Thin wrappers around the orval-generated hooks. Their job is twofold:
 *
 *   1. Keep the call signatures the rest of the app already uses
 *      (`useBlocks({limit, miner, …})` instead of `useListBlocks({…})`),
 *      so this migration is one file diff per page rather than many.
 *   2. Normalize the spec's nullable array fields (`page.data: T[] | null`,
 *      `tx.logs: Log[] | null`) into the non-null shapes components were
 *      written against. The OpenAPI generator faithfully reflects
 *      `["array", "null"]` from huma; at the UI layer "no rows yet" and
 *      "null" mean the same thing.
 *
 * Beyond those two concerns this module adds nothing the generated
 * hooks don't already provide. New call sites can pull directly from
 * `@/lib/api/generated/firn`.
 */

import { useQuery, type UseQueryOptions } from "@tanstack/react-query";
import {
  getBlock as fetchBlock,
  getChain as fetchChain,
  getGenesis as fetchGenesis,
  getProposerState as fetchProposerState,
  getTransaction as fetchTransaction,
  getValidatorUptime as fetchValidatorUptime,
  getValidators as fetchValidators,
  listAddressInternalTransactions as fetchAddressInternalTransactions,
  listAddressLogs as fetchAddressLogs,
  listAddressTokenTransfers as fetchAddressTokenTransfers,
  listBlocks as fetchBlocks,
  getPeers as fetchPeers,
  listICMMessages as fetchICMMessages,
  listICMRoutes as fetchICMRoutes,
  listICTTTokens as fetchICTTTokens,
  getICMStats as fetchICMStats,
  getICMTimeseries as fetchICMTimeseries,
  listTeleporterMessages as fetchTeleporterMessages,
  listTokenHolders as fetchTokenHolders,
  listTokenTransfers as fetchTokenTransfers,
  listTokens as fetchTokens,
  listTransactions as fetchTransactions,
  getBlockTransactions as fetchBlockTransactions,
  getStats as fetchStats,
  getAddress as fetchAddress,
  getToken as fetchToken,
  getListBlocksUrl,
  getListTransactionsUrl,
  getGetChainUrl,
  getGetGenesisUrl,
  getGetStatsUrl,
  getGetBlockUrl,
  getGetBlockTransactionsUrl,
  getGetTransactionUrl,
  getGetValidatorsUrl,
  getGetProposerStateUrl,
  getGetValidatorUptimeUrl,
  getListICMMessagesUrl,
  getGetPeersUrl,
  getListICMRoutesUrl,
  getListICTTTokensUrl,
  getGetICMStatsUrl,
  getGetICMTimeseriesUrl,
  getListTeleporterMessagesUrl,
  getListTokensUrl,
  getGetTokenUrl,
  getListTokenTransfersUrl,
  getListTokenHoldersUrl,
  getGetAddressUrl,
  getListAddressInternalTransactionsUrl,
  getListAddressTokenTransfersUrl,
  getListAddressLogsUrl,
} from "./generated/firn";
import { firnQueryKey } from "./generated-query-key";
import { FirnApiError, getApiBase, pchainCall } from "./client";
import { fetchSourcifyContract, type SourcifyContract } from "@/lib/sourcify";
import { decodeFromAbi, fetchExternalSelector, type SelectorMatch } from "@/lib/selectors";
import type {
  Address as FirnAddress,
  AddressLog as GenAddressLog,
  Block as GenBlock,
  Chain as GenChain,
  GenesisResponse as GenGenesisResponse,
  ICMRoute as GenICMRoute,
  ICMStats as GenICMStats,
  ICMTimeseriesPoint as GenICMTimeseriesPoint,
  TokenVolume as GenICTTTokenVolume,
  Peer as GenPeer,
  InternalTransaction as GenInternalTransaction,
  Message as GenMessage,
  StatsExtended as GenStats,
  Token as GenToken,
  TokenHolder as GenTokenHolder,
  TokenTransfer as GenTokenTransfer,
  Transaction as GenTransaction,
} from "./generated/schemas";

// Re-export the generated schema types so call sites can pull them
// from one place instead of remembering whether a name lives here or
// in the generated tree.
export type {
  Address,
  AddressLog,
  AppMessage,
  AppFieldNode,
  AppMessageEnvelope,
  Block,
  BlockConsensus,
  BlockGas,
  BlockRef,
  Chain,
  Cursor,
  ErrorModel,
  GasPrice,
  GenesisAllocation,
  GenesisAllocationsSummary,
  GenesisConfig,
  GenesisConfigFeeConfig,
  GenesisContract,
  GenesisERC20Balance,
  GenesisHardfork,
  GenesisHeader,
  GenesisPrecompile,
  GenesisPrecompileConfig,
  GenesisRaw,
  GenesisResponse,
  GenesisUpgrades,
  GenesisUpgradesNetworkUpgrades,
  GenesisUpgradesPrecompileUpgradesItem,
  GenesisUpgradesRaw,
  GenesisUpgradesStateUpgradesItem,
  ICMRoute,
  ICMStats,
  ICMTimeseriesPoint,
  TokenVolume as ICTTTokenVolume,
  TokensResponse as ICTTTokensResponse,
  Peer,
  PeersResponse,
  TokenRef,
  InternalTransaction,
  Log,
  Message,
  Method,
  NativeToken,
  StatsExtended as Stats,
  StatsExtended,
  TeleporterFeeInfoDecoded,
  TeleporterMessageDecoded,
  TeleporterMessageReceiptDecoded,
  Token,
  TokenHolder,
  TokenTransfer,
  Trace,
  Transaction,
  TransactionGas,
  WarpAddressedCall,
  WarpEnvelope,
} from "./generated/schemas";

// Legacy alias — old code referenced `AppMessageFieldNode`; the spec
// renamed it to `AppFieldNode`. Keep both spellings available.
export type { AppFieldNode as AppMessageFieldNode } from "./generated/schemas";

/** firn API kind discriminator — `kind: string` in the spec, but only
 *  these two values are ever emitted. */
export type ICMKind = "warp" | "teleporter";

/** Frontend-friendly alias for the wire `Message` type. */
export type ICMMessage = GenMessage;

/** Page<T> — generated as nullable; we normalize to non-null arrays. */
export interface Page<T> {
  data: T[];
  cursor: { next?: string; prev?: string };
}

type RawPage<T> = {
  data: T[] | null | undefined;
  cursor?: { next?: string; prev?: string } | undefined;
};
function normalizePage<T>(p: RawPage<T>): Page<T> {
  return { data: p.data ?? [], cursor: p.cursor ?? {} };
}

type QueryOpts<T> = Omit<UseQueryOptions<T, Error, T, readonly unknown[]>, "queryKey" | "queryFn">;
const DEFAULT_LIMIT = 50;

// ---------------------------------------------------------------------------
// Top-level chain meta
// ---------------------------------------------------------------------------

export function useChain(opts?: QueryOpts<GenChain>) {
  return useQuery({
    queryKey: firnQueryKey({}, { url: getGetChainUrl() }),
    queryFn: ({ signal }) => fetchChain({ signal }) as unknown as Promise<GenChain>,
    staleTime: 5 * 60 * 1000,
    ...opts,
  });
}

/**
 * Genesis is a static, chain-lifetime artifact — once firn has indexed
 * it the response never changes. Cache aggressively (10 min stale,
 * never auto-refetch) so /genesis is effectively free after first load
 * and tab switches don't re-hit the wire.
 */
export function useGenesis(opts?: QueryOpts<GenGenesisResponse>) {
  return useQuery({
    queryKey: firnQueryKey({}, { url: getGetGenesisUrl() }),
    queryFn: ({ signal }) => fetchGenesis({ signal }) as unknown as Promise<GenGenesisResponse>,
    staleTime: 10 * 60 * 1000,
    refetchOnWindowFocus: false,
    retry: 1,
    ...opts,
  });
}

export function useStats(opts?: QueryOpts<GenStats>) {
  return useQuery({
    queryKey: firnQueryKey({}, { url: getGetStatsUrl() }),
    queryFn: ({ signal }) => fetchStats({ signal }) as unknown as Promise<GenStats>,
    ...opts,
  });
}

// ---------------------------------------------------------------------------
// Blocks + Transactions
// ---------------------------------------------------------------------------

export function useBlocks(
  params: { limit?: number; cursor?: string; miner?: string; from?: number; to?: number } = {},
  opts?: QueryOpts<Page<GenBlock>>,
) {
  const limit = params.limit ?? DEFAULT_LIMIT;
  // Spec types from/to as decimal strings for int64 safety; UI passes
  // numbers. Stringify here so the URL serializer works without surprises.
  const merged = {
    limit,
    cursor: params.cursor,
    miner: params.miner,
    from: params.from != null ? String(params.from) : undefined,
    to: params.to != null ? String(params.to) : undefined,
  };
  return useQuery({
    queryKey: firnQueryKey({ params: merged }, { url: getListBlocksUrl(merged) }),
    queryFn: ({ signal }) =>
      fetchBlocks(merged, { signal }).then((p) =>
        normalizePage<GenBlock>(p as unknown as RawPage<GenBlock>),
      ),
    ...opts,
  });
}

export function useTransactions(
  params: {
    limit?: number;
    cursor?: string;
    address?: string;
    method?: string;
    status?: "success" | "failed";
  } = {},
  opts?: QueryOpts<Page<GenTransaction>>,
) {
  const limit = params.limit ?? DEFAULT_LIMIT;
  const merged = { ...params, limit };
  return useQuery({
    queryKey: firnQueryKey({ params: merged }, { url: getListTransactionsUrl(merged) }),
    queryFn: ({ signal }) =>
      fetchTransactions(merged, { signal }).then((p) =>
        normalizePage<GenTransaction>(p as unknown as RawPage<GenTransaction>),
      ),
    ...opts,
  });
}

export function useBlock(id: string | number | undefined, opts?: QueryOpts<GenBlock>) {
  return useQuery({
    queryKey: firnQueryKey(
      { id },
      { url: id != null ? getGetBlockUrl(String(id)) : "/v1/blocks/_" },
    ),
    queryFn: ({ signal }) =>
      fetchBlock(String(id), undefined, { signal }) as unknown as Promise<GenBlock>,
    enabled: id != null,
    ...opts,
  });
}

export function useBlockTransactions(
  id: string | number | undefined,
  params: { limit?: number; cursor?: string } = {},
  opts?: QueryOpts<Page<GenTransaction>>,
) {
  const limit = params.limit ?? DEFAULT_LIMIT;
  const merged = { ...params, limit };
  return useQuery({
    queryKey: firnQueryKey(
      { id, params: merged },
      {
        url:
          id != null ? getGetBlockTransactionsUrl(String(id), merged) : "/v1/blocks/_/transactions",
      },
    ),
    queryFn: ({ signal }) =>
      fetchBlockTransactions(String(id), merged, { signal }).then((p) =>
        normalizePage<GenTransaction>(p as unknown as RawPage<GenTransaction>),
      ),
    enabled: id != null,
    ...opts,
  });
}

export function useTransaction(hash: string | undefined, opts?: QueryOpts<GenTransaction>) {
  const params = { expand: "logs,traces" };
  return useQuery({
    queryKey: firnQueryKey(
      { hash, params },
      { url: hash != null ? getGetTransactionUrl(hash, params) : "/v1/transactions/_" },
    ),
    queryFn: ({ signal }) =>
      fetchTransaction(hash!, params, { signal }) as unknown as Promise<GenTransaction>,
    enabled: hash != null && hash.length > 0,
    ...opts,
  });
}

// ---------------------------------------------------------------------------
// Validators — `/v1/validators` and `/v1/validators/uptime` are JSON
// pass-throughs to P-Chain / subnet-evm — typed as `unknown` in
// openapi.json. Hand-stamped shapes mirror the upstream responses.
// ---------------------------------------------------------------------------

export interface ValidatorsResponse {
  validators: Validator[];
}

export interface Validator {
  txID: string;
  validationID?: string;
  startTime: string;
  endTime: string;
  stakeAmount?: string;
  weight: string;
  nodeID: string;
  publicKey?: string;
  uptime?: string;
  connected?: boolean;
  delegationFee?: string;
  delegatorCount?: string;
  delegatorWeight?: string;
  potentialReward?: string;
  accruedDelegateeReward?: string;
  delegators?: Delegator[] | null;
  validationRewardOwner?: RewardOwner;
  delegationRewardOwner?: RewardOwner;
  signer?: { publicKey: string; proofOfPossession: string };
}

export interface Delegator {
  txID: string;
  startTime: string;
  endTime: string;
  stakeAmount: string;
  nodeID: string;
  rewardOwner?: RewardOwner;
  potentialReward?: string;
}

export interface RewardOwner {
  locktime: string;
  threshold: string;
  addresses: string[];
}

export interface L1UptimeResponse {
  validators: L1UptimeEntry[];
}

export interface L1UptimeEntry {
  nodeID: string;
  // subnet-evm validators.getCurrentValidators emits these names
  // verbatim (uptimeSeconds / uptimePercentage) and firn passes the
  // JSON through without renaming. Keep the field names matching the
  // upstream so the type and the wire stay in lockstep — an earlier
  // pass mismatched them (uptime / uptimePercent), which silently
  // resolved to undefined for every L1 and surfaced the "no uptime
  // reported · subnet-evm tracks per-L1 uptime locally" fallback on
  // every validator detail page despite the data being present.
  uptimeSeconds?: number;
  uptimePercentage?: number;
  weight?: number | string;
  startTimestamp?: number | string;
  validationID?: string;
  isActive?: boolean;
  isConnected?: boolean;
  isL1Validator?: boolean;
}

export interface L1ValidatorDetails {
  subnetID: string;
  nodeID: string;
  publicKey: string;
  remainingBalanceOwner: RewardOwner;
  deactivationOwner: RewardOwner;
  startTime: string;
  weight: string;
  minNonce: string;
  balance: string;
  height?: string;
}

export interface ProposerState {
  proposedHeight?: string;
}

export function useValidators(
  params: { subnetID?: string } = {},
  opts?: QueryOpts<ValidatorsResponse>,
) {
  return useQuery({
    queryKey: firnQueryKey({ params }, { url: getGetValidatorsUrl(params) }),
    queryFn: ({ signal }) =>
      fetchValidators(params, { signal }) as unknown as Promise<ValidatorsResponse>,
    staleTime: 30 * 1000,
    refetchInterval: (q) => (isBootstrappingError(q.state.error) ? 15_000 : false),
    retry: (n, err) => (isBootstrappingError(err) ? false : n < 2),
    ...opts,
  });
}

export function isBootstrappingError(err: unknown): boolean {
  return err instanceof FirnApiError && err.code === "bootstrapping";
}

export function useProposerState(opts?: QueryOpts<ProposerState>) {
  return useQuery({
    queryKey: firnQueryKey({}, { url: getGetProposerStateUrl() }),
    queryFn: ({ signal }) => fetchProposerState({ signal }) as unknown as Promise<ProposerState>,
    staleTime: 5 * 1000,
    retry: 1,
    ...opts,
  });
}

export function useL1Uptime(opts?: QueryOpts<L1UptimeResponse>) {
  return useQuery({
    queryKey: firnQueryKey({}, { url: getGetValidatorUptimeUrl() }),
    queryFn: ({ signal }) =>
      fetchValidatorUptime({ signal }) as unknown as Promise<L1UptimeResponse>,
    staleTime: 30 * 1000,
    retry: 1,
    ...opts,
  });
}

/** /v1/peers — avalanchego info.peers proxied through firn. The peers
 *  array is normalized to non-null. Returns 503 when firn was started
 *  without -info-rpc; the consumer should treat that as "peer info
 *  unavailable" and fall back to whatever P-Chain `connected` says. */
export interface PeersView {
  peers: GenPeer[];
  numPeers: number;
  ourSubnetId?: string;
}

export function usePeers(params: { subnetID?: string } = {}, opts?: QueryOpts<PeersView>) {
  type RawBody = {
    peers: GenPeer[] | null;
    numPeers: number;
    ourSubnetId?: string;
  };
  return useQuery({
    queryKey: firnQueryKey({ params }, { url: getGetPeersUrl(params) }),
    queryFn: ({ signal }) =>
      (fetchPeers(params, { signal }) as unknown as Promise<RawBody>).then((r) => ({
        peers: r.peers ?? [],
        numPeers: r.numPeers,
        ourSubnetId: r.ourSubnetId,
      })),
    staleTime: 30 * 1000,
    // info.peers is best-effort — a 503 means firn isn't pointed at an
    // /ext/info-exposing node. Don't retry on configured-disabled paths.
    retry: (n, err) => (err instanceof FirnApiError && err.code === "rpc_disabled" ? false : n < 1),
    ...opts,
  });
}

// ---------------------------------------------------------------------------
// Aggregate stats endpoints (firn /v1/stats/*) — hand-rolled until orval
// regenerates against the latest openapi.json. The shapes mirror firn's
// internal/types/types.go: TimeseriesPoint, MethodMixPoint,
// ProducerEntry, ReorgsResponse.
// ---------------------------------------------------------------------------

export type StatsBucket = "1h" | "1d";
export type StatsWindow = "1h" | "6h" | "24h" | "7d" | "30d";
export type StatsTimeseriesMetric = "tps" | "gasPct" | "blockTime" | "fee";

export interface MethodMixPoint {
  ts: string;
  by: Record<string, number>;
}

export interface TimeseriesPoint {
  ts: string;
  value: number;
}

export interface ProducerEntry {
  miner: string;
  blocks: number;
  sharePct: number;
}

export interface ReorgsResponse {
  count: number;
  lastAt?: string;
}

/**
 * Generic fetcher for the aggregate endpoints. Returns raw JSON and lets
 * the caller cast — keeps this file leaner than per-endpoint helpers
 * given the shapes are small and stable.
 */
async function fetchStatsAggregate<T>(path: string, signal?: AbortSignal): Promise<T> {
  const url = `${getApiBase()}/v1${path}`;
  const r = await fetch(url, { signal });
  if (!r.ok) {
    throw new Error(`firn ${path}: ${r.status} ${r.statusText}`);
  }
  return (await r.json()) as T;
}

export function useStatsMethods(
  bucket: StatsBucket,
  window: StatsWindow,
  opts?: QueryOpts<MethodMixPoint[]>,
) {
  return useQuery({
    queryKey: firnQueryKey({ bucket, window }, { url: "/v1/stats/methods" }),
    queryFn: ({ signal }) =>
      fetchStatsAggregate<MethodMixPoint[]>(
        `/stats/methods?bucket=${bucket}&window=${window}`,
        signal,
      ),
    staleTime: 30 * 1000,
    refetchOnWindowFocus: false,
    retry: 1,
    ...opts,
  });
}

export function useStatsTimeseries(
  metric: StatsTimeseriesMetric,
  bucket: StatsBucket,
  window: StatsWindow,
  opts?: QueryOpts<TimeseriesPoint[]>,
) {
  return useQuery({
    queryKey: firnQueryKey({ metric, bucket, window }, { url: "/v1/stats/timeseries" }),
    queryFn: ({ signal }) =>
      fetchStatsAggregate<TimeseriesPoint[]>(
        `/stats/timeseries?metric=${metric}&bucket=${bucket}&window=${window}`,
        signal,
      ),
    staleTime: 30 * 1000,
    refetchOnWindowFocus: false,
    retry: 1,
    ...opts,
  });
}

export function useStatsProducers(window: StatsWindow, opts?: QueryOpts<ProducerEntry[]>) {
  return useQuery({
    queryKey: firnQueryKey({ window }, { url: "/v1/stats/producers" }),
    queryFn: ({ signal }) =>
      fetchStatsAggregate<ProducerEntry[]>(`/stats/producers?window=${window}`, signal),
    staleTime: 30 * 1000,
    refetchOnWindowFocus: false,
    retry: 1,
    ...opts,
  });
}

export function useStatsReorgs(window: StatsWindow, opts?: QueryOpts<ReorgsResponse>) {
  return useQuery({
    queryKey: firnQueryKey({ window }, { url: "/v1/stats/reorgs" }),
    queryFn: ({ signal }) =>
      fetchStatsAggregate<ReorgsResponse>(`/stats/reorgs?window=${window}`, signal),
    staleTime: 60 * 1000,
    refetchOnWindowFocus: false,
    retry: 1,
    ...opts,
  });
}

/**
 * `platform.getL1Validator(validationID)` — JSON-RPC POST. The opaque
 * body keeps it out of the generated query surface; we use pchainCall
 * directly so the call site stays a `useQuery` (cached) instead of a
 * mutation.
 */
export function useL1Validator(
  validationID: string | undefined,
  opts?: QueryOpts<L1ValidatorDetails>,
) {
  return useQuery({
    queryKey: firnQueryKey(
      { method: "platform.getL1Validator", validationID },
      { url: "/v1/rpc/p" },
    ),
    queryFn: () => pchainCall<L1ValidatorDetails>("platform.getL1Validator", { validationID }),
    enabled: !!validationID,
    staleTime: 30 * 1000,
    ...opts,
  });
}

// ---------------------------------------------------------------------------
// Tokens
// ---------------------------------------------------------------------------

export function useTokens(
  params: { limit?: number; cursor?: string } = {},
  opts?: QueryOpts<Page<GenToken>>,
) {
  const limit = params.limit ?? DEFAULT_LIMIT;
  const merged = { ...params, limit };
  return useQuery({
    queryKey: firnQueryKey({ params: merged }, { url: getListTokensUrl(merged) }),
    queryFn: ({ signal }) =>
      fetchTokens(merged, { signal }).then((p) =>
        normalizePage<GenToken>(p as unknown as RawPage<GenToken>),
      ),
    staleTime: 30_000,
    ...opts,
  });
}

export function useToken(address: string | undefined, opts?: QueryOpts<GenToken>) {
  return useQuery({
    queryKey: firnQueryKey(
      { address: address?.toLowerCase() },
      { url: address ? getGetTokenUrl(address) : "/v1/tokens/_" },
    ),
    queryFn: ({ signal }) => fetchToken(address!, { signal }) as unknown as Promise<GenToken>,
    enabled: address != null && address.length === 42,
    staleTime: 60_000,
    ...opts,
  });
}

export function useTokenTransfers(
  address: string | undefined,
  params: { limit?: number; cursor?: string } = {},
  opts?: QueryOpts<Page<GenTokenTransfer>>,
) {
  const limit = params.limit ?? DEFAULT_LIMIT;
  const merged = { ...params, limit };
  return useQuery({
    queryKey: firnQueryKey(
      { address: address?.toLowerCase(), params: merged },
      { url: address ? getListTokenTransfersUrl(address, merged) : "/v1/tokens/_/transfers" },
    ),
    queryFn: ({ signal }) =>
      fetchTokenTransfers(address!, merged, { signal }).then((p) =>
        normalizePage<GenTokenTransfer>(p as unknown as RawPage<GenTokenTransfer>),
      ),
    enabled: address != null && address.length === 42,
    staleTime: 5_000,
    ...opts,
  });
}

export function useTokenHolders(
  address: string | undefined,
  params: { limit?: number } = {},
  opts?: QueryOpts<Page<GenTokenHolder>>,
) {
  const limit = params.limit ?? 100;
  const merged = { ...params, limit };
  return useQuery({
    queryKey: firnQueryKey(
      { address: address?.toLowerCase(), params: merged },
      { url: address ? getListTokenHoldersUrl(address, merged) : "/v1/tokens/_/holders" },
    ),
    queryFn: ({ signal }) =>
      fetchTokenHolders(address!, merged, { signal }).then((p) =>
        normalizePage<GenTokenHolder>(p as unknown as RawPage<GenTokenHolder>),
      ),
    enabled: address != null && address.length === 42,
    staleTime: 30_000,
    ...opts,
  });
}

// ---------------------------------------------------------------------------
// Address detail
// ---------------------------------------------------------------------------

export function useAddress(hash: string | undefined, opts?: QueryOpts<FirnAddress>) {
  return useQuery({
    queryKey: firnQueryKey(
      { hash: hash?.toLowerCase() },
      { url: hash ? getGetAddressUrl(hash) : "/v1/addresses/_" },
    ),
    queryFn: ({ signal }) => fetchAddress(hash!, { signal }) as unknown as Promise<FirnAddress>,
    enabled: hash != null && hash.length === 42,
    staleTime: 10_000,
    ...opts,
  });
}

export function useAddressInternalTransactions(
  hash: string | undefined,
  params: { limit?: number; cursor?: string } = {},
  opts?: QueryOpts<Page<GenInternalTransaction>>,
) {
  const limit = params.limit ?? DEFAULT_LIMIT;
  const merged = { ...params, limit };
  return useQuery({
    queryKey: firnQueryKey(
      { hash: hash?.toLowerCase(), params: merged },
      {
        url: hash
          ? getListAddressInternalTransactionsUrl(hash, merged)
          : "/v1/addresses/_/internal-transactions",
      },
    ),
    queryFn: ({ signal }) =>
      fetchAddressInternalTransactions(hash!, merged, { signal }).then((p) =>
        normalizePage<GenInternalTransaction>(p as unknown as RawPage<GenInternalTransaction>),
      ),
    enabled: hash != null && hash.length === 42,
    staleTime: 5_000,
    ...opts,
  });
}

export function useAddressTokenTransfers(
  hash: string | undefined,
  params: { limit?: number; cursor?: string } = {},
  opts?: QueryOpts<Page<GenTokenTransfer>>,
) {
  const limit = params.limit ?? DEFAULT_LIMIT;
  const merged = { ...params, limit };
  return useQuery({
    queryKey: firnQueryKey(
      { hash: hash?.toLowerCase(), params: merged },
      {
        url: hash
          ? getListAddressTokenTransfersUrl(hash, merged)
          : "/v1/addresses/_/token-transfers",
      },
    ),
    queryFn: ({ signal }) =>
      fetchAddressTokenTransfers(hash!, merged, { signal }).then((p) =>
        normalizePage<GenTokenTransfer>(p as unknown as RawPage<GenTokenTransfer>),
      ),
    enabled: hash != null && hash.length === 42,
    staleTime: 5_000,
    ...opts,
  });
}

export function useAddressLogs(
  hash: string | undefined,
  params: { limit?: number; cursor?: string } = {},
  opts?: QueryOpts<Page<GenAddressLog>>,
) {
  const limit = params.limit ?? DEFAULT_LIMIT;
  const merged = { ...params, limit };
  return useQuery({
    queryKey: firnQueryKey(
      { hash: hash?.toLowerCase(), params: merged },
      { url: hash ? getListAddressLogsUrl(hash, merged) : "/v1/addresses/_/logs" },
    ),
    queryFn: ({ signal }) =>
      fetchAddressLogs(hash!, merged, { signal }).then((p) =>
        normalizePage<GenAddressLog>(p as unknown as RawPage<GenAddressLog>),
      ),
    enabled: hash != null && hash.length === 42,
    staleTime: 5_000,
    ...opts,
  });
}

export function useAddressTransactions(
  hash: string | undefined,
  params: { limit?: number; cursor?: string } = {},
  opts?: QueryOpts<Page<GenTransaction>>,
) {
  const limit = params.limit ?? DEFAULT_LIMIT;
  const merged = { ...params, limit, address: hash };
  return useQuery({
    queryKey: firnQueryKey({ hash, params: merged }, { url: getListTransactionsUrl(merged) }),
    queryFn: ({ signal }) =>
      fetchTransactions(merged, { signal }).then((p) =>
        normalizePage<GenTransaction>(p as unknown as RawPage<GenTransaction>),
      ),
    enabled: hash != null && hash.length > 0,
    ...opts,
  });
}

// ---------------------------------------------------------------------------
// ICM
// ---------------------------------------------------------------------------

export function useICMMessages(
  params: {
    limit?: number;
    cursor?: string;
    kind?: ICMKind;
    messageId?: string;
    address?: string;
    block?: number;
  } = {},
  opts?: QueryOpts<Page<GenMessage>>,
) {
  const limit = params.limit ?? DEFAULT_LIMIT;
  const merged = { ...params, limit };
  return useQuery({
    queryKey: firnQueryKey({ params: merged }, { url: getListICMMessagesUrl(merged) }),
    queryFn: ({ signal }) =>
      fetchICMMessages(merged, { signal }).then((p) =>
        normalizePage<GenMessage>(p as unknown as RawPage<GenMessage>),
      ),
    ...opts,
  });
}

export function useTeleporterMessages(
  params: {
    limit?: number;
    cursor?: string;
    messageId?: string;
    address?: string;
    block?: number;
  } = {},
  opts?: QueryOpts<Page<GenMessage>>,
) {
  const limit = params.limit ?? DEFAULT_LIMIT;
  const merged = { ...params, limit };
  return useQuery({
    queryKey: firnQueryKey({ params: merged }, { url: getListTeleporterMessagesUrl(merged) }),
    queryFn: ({ signal }) =>
      fetchTeleporterMessages(merged, { signal }).then((p) =>
        normalizePage<GenMessage>(p as unknown as RawPage<GenMessage>),
      ),
    ...opts,
  });
}

export type ICMWindow = "1h" | "6h" | "24h" | "7d" | "30d";
export type ICMBucket = "5m" | "15m" | "1h" | "1d";

/** /v1/icm/routes — top source→destination pairs over a trailing window.
 *  The `routes` array is normalized to non-null. ActiveBlockchain* fields
 *  identify the L1 firn is currently indexing — that side ships with a
 *  blank `*BlockchainId` on each route entry. */
export interface ICMRoutesResponse {
  activeBlockchainCb58?: string;
  activeBlockchainName?: string;
  routes: GenICMRoute[];
}

export function useICMRoutes(
  params: { window?: ICMWindow; limit?: number } = {},
  opts?: QueryOpts<ICMRoutesResponse>,
) {
  type RoutesBody = {
    activeBlockchainCb58?: string;
    activeBlockchainName?: string;
    routes: GenICMRoute[] | null;
  };
  return useQuery({
    queryKey: firnQueryKey({ params }, { url: getListICMRoutesUrl(params) }),
    queryFn: ({ signal }) =>
      (fetchICMRoutes(params, { signal }) as unknown as Promise<RoutesBody>).then((r) => ({
        activeBlockchainCb58: r.activeBlockchainCb58,
        activeBlockchainName: r.activeBlockchainName,
        routes: r.routes ?? [],
      })),
    ...opts,
  });
}

export function useICMStats(params: { window?: ICMWindow } = {}, opts?: QueryOpts<GenICMStats>) {
  return useQuery({
    queryKey: firnQueryKey({ params }, { url: getGetICMStatsUrl(params) }),
    queryFn: ({ signal }) => fetchICMStats(params, { signal }) as unknown as Promise<GenICMStats>,
    ...opts,
  });
}

/** /v1/ictt/tokens — top tokens by ICTT-transferred volume. The
 *  `tokens` array is normalized to non-null. The endpoint may truncate
 *  to the most recent N events on long windows; `truncated` flags
 *  that case so the UI can label it honestly. ICTT lives in a sibling
 *  decoder to ICM (decoders/ictt) — same data plane, different
 *  application protocol. */
export interface ICTTTokensView {
  tokens: GenICTTTokenVolume[];
  sampledMessages: number;
  truncated: boolean;
  windowSeconds: number;
}

export function useICTTTokens(
  params: { window?: ICMWindow; limit?: number } = {},
  opts?: QueryOpts<ICTTTokensView>,
) {
  type RawBody = {
    tokens: GenICTTTokenVolume[] | null;
    sampledMessages: number;
    truncated: boolean;
    windowSeconds: number;
  };
  return useQuery({
    queryKey: firnQueryKey({ params }, { url: getListICTTTokensUrl(params) }),
    queryFn: ({ signal }) =>
      (fetchICTTTokens(params, { signal }) as unknown as Promise<RawBody>).then((r) => ({
        tokens: r.tokens ?? [],
        sampledMessages: r.sampledMessages,
        truncated: r.truncated,
        windowSeconds: r.windowSeconds,
      })),
    ...opts,
  });
}

export function useICMTimeseries(
  params: { window?: ICMWindow; bucket?: ICMBucket } = {},
  opts?: QueryOpts<GenICMTimeseriesPoint[]>,
) {
  return useQuery({
    queryKey: firnQueryKey({ params }, { url: getGetICMTimeseriesUrl(params) }),
    queryFn: ({ signal }) =>
      (
        fetchICMTimeseries(params, { signal }) as unknown as Promise<
          GenICMTimeseriesPoint[] | null | undefined
        >
      ).then((p) => p ?? []),
    ...opts,
  });
}

// ---------------------------------------------------------------------------
// Sourcify + selector decoding (network-agnostic — global resources)
// ---------------------------------------------------------------------------

export function useContractSource(
  chainId: number | string | undefined,
  address: string | undefined,
  opts?: QueryOpts<SourcifyContract | null>,
) {
  return useQuery({
    queryKey: [
      /* network-agnostic: Sourcify is keyed globally by EVM chainId. */
      "sourcify",
      chainId ?? null,
      address ?? null,
    ] as const,
    queryFn: () => fetchSourcifyContract(chainId!, address!),
    enabled: chainId != null && !!address,
    staleTime: 5 * 60 * 1000,
    retry: 1,
    ...opts,
  });
}

export function useMethodSignature({
  selector,
  contractAddress,
  chainId,
  firnName,
}: {
  selector: string | undefined;
  contractAddress: string | null | undefined;
  chainId: number | string | undefined;
  firnName?: string | null;
}) {
  const hasFirnName = !!firnName;
  const sourcify = useContractSource(
    chainId,
    hasFirnName ? undefined : (contractAddress ?? undefined),
  );

  return useQuery({
    queryKey: [
      /* network-agnostic: 4-byte selectors are a global signature space. */
      "selector",
      selector ?? null,
      contractAddress ?? null,
      hasFirnName ? "firn" : (sourcify.data?.match ?? null),
      firnName ?? null,
    ] as const,
    queryFn: async (): Promise<SelectorMatch | null> => {
      if (!selector) return null;
      if (firnName) return { signature: firnName, name: firnName, source: "firn" };
      const fromAbi = decodeFromAbi(selector, sourcify.data?.abi);
      if (fromAbi) return fromAbi;
      return fetchExternalSelector(selector);
    },
    enabled: !!selector && (hasFirnName || !sourcify.isPending),
    staleTime: 24 * 60 * 60 * 1000,
    retry: 1,
  });
}
