[avalanche](../README.md) › [EVM-Interfaces](../modules/evm_interfaces.md) › [ImportAVAXParams](evm_interfaces.importavaxparams.md)

# Interface: ImportAVAXParams

## Hierarchy

* [CredsInterface](common_interfaces.credsinterface.md)

  ↳ **ImportAVAXParams**

  ↳ [ImportParams](evm_interfaces.importparams.md)

## Index

### Properties

* [password](evm_interfaces.importavaxparams.md#password)
* [sourceChain](evm_interfaces.importavaxparams.md#sourcechain)
* [to](evm_interfaces.importavaxparams.md#to)
* [username](evm_interfaces.importavaxparams.md#username)

## Properties

###  password

• **password**: *string*

*Inherited from [CredsInterface](common_interfaces.credsinterface.md).[password](common_interfaces.credsinterface.md#password)*

*Defined in [src/common/interfaces.ts:11](https://github.com/ava-labs/avalanchejs/blob/ca67b81/src/common/interfaces.ts#L11)*

___

###  sourceChain

• **sourceChain**: *string*

*Defined in [src/apis/evm/interfaces.ts:40](https://github.com/ava-labs/avalanchejs/blob/ca67b81/src/apis/evm/interfaces.ts#L40)*

___

###  to

• **to**: *string*

*Defined in [src/apis/evm/interfaces.ts:39](https://github.com/ava-labs/avalanchejs/blob/ca67b81/src/apis/evm/interfaces.ts#L39)*

___

###  username

• **username**: *string*

*Inherited from [CredsInterface](common_interfaces.credsinterface.md).[username](common_interfaces.credsinterface.md#username)*

*Defined in [src/common/interfaces.ts:10](https://github.com/ava-labs/avalanchejs/blob/ca67b81/src/common/interfaces.ts#L10)*
