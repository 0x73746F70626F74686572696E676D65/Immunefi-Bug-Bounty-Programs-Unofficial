[avalanche](../README.md) › [AVM-Interfaces](../modules/avm_interfaces.md) › [SendNFTParams](avm_interfaces.sendnftparams.md)

# Interface: SendNFTParams

## Hierarchy

* **SendNFTParams**

## Index

### Properties

* [assetID](avm_interfaces.sendnftparams.md#assetid)
* [changeAddr](avm_interfaces.sendnftparams.md#optional-changeaddr)
* [from](avm_interfaces.sendnftparams.md#optional-from)
* [groupID](avm_interfaces.sendnftparams.md#groupid)
* [password](avm_interfaces.sendnftparams.md#password)
* [to](avm_interfaces.sendnftparams.md#to)
* [username](avm_interfaces.sendnftparams.md#username)

## Properties

###  assetID

• **assetID**: *string*

*Defined in [src/apis/avm/interfaces.ts:191](https://github.com/ava-labs/avalanchejs/blob/ca67b81/src/apis/avm/interfaces.ts#L191)*

___

### `Optional` changeAddr

• **changeAddr**? : *string*

*Defined in [src/apis/avm/interfaces.ts:190](https://github.com/ava-labs/avalanchejs/blob/ca67b81/src/apis/avm/interfaces.ts#L190)*

___

### `Optional` from

• **from**? : *string[]*

*Defined in [src/apis/avm/interfaces.ts:189](https://github.com/ava-labs/avalanchejs/blob/ca67b81/src/apis/avm/interfaces.ts#L189)*

___

###  groupID

• **groupID**: *number*

*Defined in [src/apis/avm/interfaces.ts:192](https://github.com/ava-labs/avalanchejs/blob/ca67b81/src/apis/avm/interfaces.ts#L192)*

___

###  password

• **password**: *string*

*Defined in [src/apis/avm/interfaces.ts:188](https://github.com/ava-labs/avalanchejs/blob/ca67b81/src/apis/avm/interfaces.ts#L188)*

___

###  to

• **to**: *string*

*Defined in [src/apis/avm/interfaces.ts:193](https://github.com/ava-labs/avalanchejs/blob/ca67b81/src/apis/avm/interfaces.ts#L193)*

___

###  username

• **username**: *string*

*Defined in [src/apis/avm/interfaces.ts:187](https://github.com/ava-labs/avalanchejs/blob/ca67b81/src/apis/avm/interfaces.ts#L187)*
