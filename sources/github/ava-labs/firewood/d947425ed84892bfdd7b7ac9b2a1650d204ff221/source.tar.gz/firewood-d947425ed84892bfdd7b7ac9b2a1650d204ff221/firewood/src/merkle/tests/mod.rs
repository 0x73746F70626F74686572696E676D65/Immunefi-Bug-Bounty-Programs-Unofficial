// Copyright (C) 2025, Ava Labs, Inc. All rights reserved.
// See the file LICENSE.md for licensing terms.

mod change;
mod collapse;
#[cfg(feature = "ethhash")]
mod ethhash;
#[cfg(feature = "ethhash")]
mod ethhash_fuzz;
// TODO(rkuris): get the hashes from merkledb and verify compatibility with branch factor 256
mod proof;
mod range;
mod reconcile;
mod sized;
#[cfg(not(feature = "ethhash"))]
mod triehash;

use std::collections::HashMap;
use std::fmt::Write;

use super::*;
use crate::api::Error;
use crate::{ProofError, ProofNode};
use firewood_storage::{
    Committed, DefaultHashMode, DeletedNodeTracking, DenseChildren, HashMode, MemStore, Mutable,
    NodeStore, NodeStoreHeader, PathComponent, Propose, RootReader, TrieHash, ValueDigest,
};
use test_case::test_case;

/// Test wrapper around [`crate::merkle::verify_range_proof`] that supplies the
/// compile-default hash mode as the expected `algorithm` (the mode every proof
/// built in the test binary carries). Shadows the glob-imported real function
/// so the many existing call sites need not pass the mode explicitly.
fn verify_range_proof<H: ProofCollection<Node = ProofNode>>(
    first_key: Option<impl KeyType>,
    last_key: Option<impl KeyType>,
    root_hash: &TrieHash,
    proof: &RangeProof<impl KeyType, impl ValueType, H>,
) -> Result<(), Error> {
    crate::merkle::verify_range_proof(
        first_key,
        last_key,
        root_hash,
        DefaultHashMode::ALGORITHM,
        proof,
    )
    .map(drop)
}

// Returns n random key-value pairs.
fn generate_random_kvs(rng: &firewood_storage::SeededRng, n: usize) -> Vec<(Vec<u8>, Vec<u8>)> {
    let mut kvs: Vec<(Vec<u8>, Vec<u8>)> = Vec::new();
    for _ in 0..n {
        let key_len = rng.random_range(1..=4096);
        let key: Vec<u8> = (0..key_len).map(|_| rng.random()).collect();

        let val_len = rng.random_range(1..=4096);
        let val: Vec<u8> = (0..val_len).map(|_| rng.random()).collect();

        kvs.push((key, val));
    }

    kvs
}

fn into_committed(
    merkle: Merkle<NodeStore<Arc<ImmutableProposal>, MemStore, DefaultHashMode>>,
    header: &mut NodeStoreHeader,
) -> Merkle<NodeStore<Committed, MemStore, DefaultHashMode>> {
    let ns = merkle.into_inner().as_committed();
    ns.persist(header).unwrap();
    ns.into()
}

pub(crate) fn init_merkle<I, K, V>(
    iter: I,
) -> Merkle<NodeStore<Committed, MemStore, DefaultHashMode>>
where
    I: Clone + IntoIterator<Item = (K, V)>,
    K: AsRef<[u8]>,
    V: AsRef<[u8]>,
{
    let (merkle, _header) = init_merkle_with_header(iter);
    merkle
}

pub(crate) fn init_merkle_with_header<I, K, V>(
    iter: I,
) -> (
    Merkle<NodeStore<Committed, MemStore, DefaultHashMode>>,
    NodeStoreHeader,
)
where
    I: Clone + IntoIterator<Item = (K, V)>,
    K: AsRef<[u8]>,
    V: AsRef<[u8]>,
{
    let memstore = Arc::new(MemStore::new(Vec::with_capacity(64 * 1024)));
    let mut header = NodeStoreHeader::new(DefaultHashMode::ALGORITHM);
    let base = Merkle::from(NodeStore::new_empty_committed(
        memstore.clone(),
        DeletedNodeTracking::Enabled,
    ));
    let mut merkle = base.fork().unwrap();

    for (k, v) in iter.clone() {
        let key = k.as_ref();
        let value = v.as_ref();

        merkle.insert(key, value.into()).unwrap();
    }

    let merkle = merkle.hash();
    let merkle = into_committed(merkle, &mut header);

    // Single verification pass at the end to ensure correctness
    for (k, v) in iter {
        let key = k.as_ref();
        let value = v.as_ref();

        let stored = merkle.get_value(key).unwrap();
        // In ethhash mode, account keys (32 bytes) have their storageRoot field
        // updated during hashing, so the stored value will differ from the original.
        #[cfg(feature = "ethhash")]
        if key.len() == 32 {
            assert!(
                stored.is_some(),
                "Failed to get account key after committing: {key:?}"
            );
            continue;
        }
        assert_eq!(
            stored.as_deref(),
            Some(value),
            "Failed to get key after committing: {key:?}"
        );
    }

    (merkle, header)
}

// generate pseudorandom data, but prefix it with some known data
// The number of fixed data points is 100; you specify how much random data you want
#[expect(clippy::arithmetic_side_effects)]
fn fixed_and_pseudorandom_data(
    rng: &firewood_storage::SeededRng,
    random_count: u32,
) -> HashMap<[u8; 32], [u8; 20]> {
    let mut items = HashMap::new();
    for i in 0..100_u32 {
        let mut key: [u8; 32] = [0; 32];
        let mut value: [u8; 20] = [0; 20];
        for (index, d) in i.to_be_bytes().iter().enumerate() {
            key[index] = *d;
            value[index] = *d;
        }
        items.insert(key, value);

        let mut more_key: [u8; 32] = [0; 32];
        for (index, d) in (i + 10).to_be_bytes().iter().enumerate() {
            more_key[index] = *d;
        }
        items.insert(more_key, value);
    }

    for _ in 0..random_count {
        let key = rng.random::<[u8; 32]>();
        let val = rng.random::<[u8; 20]>();
        items.insert(key, val);
    }
    items
}

fn increase_key(key: &[u8; 32]) -> [u8; 32] {
    let mut new_key = *key;
    for ch in new_key.iter_mut().rev() {
        let overflow;
        (*ch, overflow) = ch.overflowing_add(1);
        if !overflow {
            break;
        }
    }
    new_key
}

fn decrease_key(key: &[u8; 32]) -> [u8; 32] {
    let mut new_key = *key;
    for ch in new_key.iter_mut().rev() {
        let overflow;
        (*ch, overflow) = ch.overflowing_sub(1);
        if !overflow {
            break;
        }
    }
    new_key
}

#[test]
fn test_get_regression() {
    let mut merkle = create_in_memory_merkle();

    merkle.insert(&[0], Box::new([0])).unwrap();
    assert_eq!(merkle.get_value(&[0]).unwrap(), Some(Box::from([0])));

    merkle.insert(&[1], Box::new([1])).unwrap();
    assert_eq!(merkle.get_value(&[1]).unwrap(), Some(Box::from([1])));

    merkle.insert(&[2], Box::new([2])).unwrap();
    assert_eq!(merkle.get_value(&[2]).unwrap(), Some(Box::from([2])));

    let merkle = merkle.hash();

    assert_eq!(merkle.get_value(&[0]).unwrap(), Some(Box::from([0])));
    assert_eq!(merkle.get_value(&[1]).unwrap(), Some(Box::from([1])));
    assert_eq!(merkle.get_value(&[2]).unwrap(), Some(Box::from([2])));

    for result in merkle.path_iter(&[2]).unwrap() {
        result.unwrap();
    }
}

#[test]
fn insert_one() {
    let mut merkle = create_in_memory_merkle();
    merkle.insert(b"abc", Box::new([])).unwrap();
}

fn create_in_memory_merkle() -> Merkle<NodeStore<Mutable<Propose>, MemStore, DefaultHashMode>> {
    let memstore = MemStore::new(Vec::new());

    let nodestore = NodeStore::new_empty_proposal(memstore.into(), DeletedNodeTracking::Enabled);

    Merkle { nodestore }
}

fn test_branch_proof_node(
    key_nibbles: &[u8],
    value_digest: Option<ValueDigest<Value>>,
) -> ProofNode {
    let key = key_nibbles
        .iter()
        .copied()
        .map(|nibble| PathComponent::try_new(nibble).unwrap())
        .collect();

    ProofNode {
        key,
        partial_len: 0,
        value_digest,
        child_hashes: DenseChildren::new(),
    }
}

#[test]
fn test_get_node_from_nibbles_matches_byte_lookup() {
    let mut merkle = create_in_memory_merkle();
    merkle.insert(&[0xab, 0xcd], Box::from([1u8])).unwrap();

    let from_bytes = merkle.get_node(&[0xab, 0xcd]).unwrap();
    let from_nibbles = merkle.get_node_from_nibbles(&[0xa, 0xb, 0xc, 0xd]).unwrap();

    assert_eq!(from_bytes, from_nibbles);
}

#[test]
fn test_insert_branch_from_nibbles_into_empty_trie() {
    let mut merkle = create_in_memory_merkle();

    merkle.insert_branch_from_nibbles(&[0xa, 0xb, 0xc]).unwrap();

    let node = merkle
        .get_node_from_nibbles(&[0xa, 0xb, 0xc])
        .unwrap()
        .unwrap();
    let branch = node.as_branch().expect("expected branch node");
    assert!(branch.value.is_none());
}

#[test]
fn test_insert_branch_from_nibbles_converts_leaf_to_branch() {
    let mut merkle = create_in_memory_merkle();
    merkle.insert(&[0xab], Box::from([9u8])).unwrap();

    merkle.insert_branch_from_nibbles(&[0xa, 0xb]).unwrap();

    let node = merkle.get_node_from_nibbles(&[0xa, 0xb]).unwrap().unwrap();
    let branch = node.as_branch().expect("expected branch node");
    assert_eq!(branch.value.as_deref(), Some([9u8].as_slice()));
    assert_eq!(
        merkle.get_value(&[0xab]).unwrap().as_deref(),
        Some([9u8].as_slice())
    );
}

#[test]
fn test_insert_branch_from_nibbles_inserts_missing_ancestor() {
    let mut merkle = create_in_memory_merkle();
    merkle.insert(&[0xab, 0xcd], Box::from([7u8])).unwrap();

    merkle.insert_branch_from_nibbles(&[0xa]).unwrap();

    let ancestor = merkle.get_node_from_nibbles(&[0xa]).unwrap().unwrap();
    let ancestor_branch = ancestor.as_branch().expect("expected ancestor branch");
    assert!(ancestor_branch.value.is_none());
    assert_eq!(
        merkle.get_value(&[0xab, 0xcd]).unwrap().as_deref(),
        Some([7u8].as_slice())
    );
}

#[test]
fn test_insert_branch_from_nibbles_inserts_missing_descendant() {
    let mut merkle = create_in_memory_merkle();
    merkle.insert(&[0xab], Box::from([5u8])).unwrap();

    merkle.insert_branch_from_nibbles(&[0xa, 0xb, 0xc]).unwrap();

    let descendant = merkle
        .get_node_from_nibbles(&[0xa, 0xb, 0xc])
        .unwrap()
        .unwrap();
    let descendant_branch = descendant.as_branch().expect("expected descendant branch");
    assert!(descendant_branch.value.is_none());
    assert_eq!(
        merkle.get_value(&[0xab]).unwrap().as_deref(),
        Some([5u8].as_slice())
    );
}

#[test]
fn test_insert_branch_from_nibbles_splits_divergent_paths() {
    let mut merkle = create_in_memory_merkle();
    // Leaf at [0xab] has nibble path [a, b]
    merkle.insert(&[0xab], Box::from([3u8])).unwrap();

    // Branch at [0xa, 0xc] shares prefix [a] then diverges: key goes 'c', node goes 'b'
    // This exercises the (Some, Some) arm of insert_branch_helper
    merkle.insert_branch_from_nibbles(&[0xa, 0xc]).unwrap();

    let branch = merkle.get_node_from_nibbles(&[0xa, 0xc]).unwrap().unwrap();
    let branch_node = branch.as_branch().expect("expected branch node");
    assert!(branch_node.value.is_none());
    assert_eq!(
        merkle.get_value(&[0xab]).unwrap().as_deref(),
        Some([3u8].as_slice())
    );
}

#[test]
fn test_insert_and_get() {
    let mut merkle = create_in_memory_merkle();

    // insert values
    for key_val in u8::MIN..=u8::MAX {
        let key = vec![key_val];
        let val = Box::new([key_val]);

        merkle.insert(&key, val.clone()).unwrap();

        let fetched_val = merkle.get_value(&key).unwrap();

        // make sure the value was inserted
        assert_eq!(fetched_val.as_deref(), val.as_slice().into());
    }

    // make sure none of the previous values were forgotten after initial insert
    for key_val in u8::MIN..=u8::MAX {
        let key = vec![key_val];
        let val = vec![key_val];

        let fetched_val = merkle.get_value(&key).unwrap();

        assert_eq!(fetched_val.as_deref(), val.as_slice().into());
    }
}

#[test]
fn overwrite_leaf() {
    let key = &[0x00];
    let val = &[1];
    let overwrite = &[2];

    let mut merkle = create_in_memory_merkle();

    merkle.insert(key, val[..].into()).unwrap();

    assert_eq!(
        merkle.get_value(key).unwrap().as_deref(),
        Some(val.as_slice())
    );

    merkle.insert(key, overwrite[..].into()).unwrap();

    assert_eq!(
        merkle.get_value(key).unwrap().as_deref(),
        Some(overwrite.as_slice())
    );
}

#[test]
fn remove_root() {
    let key0 = vec![0];
    let val0 = [0];
    let key1 = vec![0, 1];
    let val1 = [0, 1];
    let key2 = vec![0, 1, 2];
    let val2 = [0, 1, 2];
    let key3 = vec![0, 1, 15];
    let val3 = [0, 1, 15];

    let mut merkle = create_in_memory_merkle();

    merkle.insert(&key0, Box::from(val0)).unwrap();
    merkle.insert(&key1, Box::from(val1)).unwrap();
    merkle.insert(&key2, Box::from(val2)).unwrap();
    merkle.insert(&key3, Box::from(val3)).unwrap();
    // Trie is:
    //   key0
    //    |
    //   key1
    //  /    \
    // key2  key3

    // Test removal of root when it's a branch with 1 branch child
    let removed_val = merkle.remove(&key0).unwrap();
    assert_eq!(removed_val, Some(Box::from(val0)));
    assert!(merkle.get_value(&key0).unwrap().is_none());
    // Removing an already removed key is a no-op
    assert!(merkle.remove(&key0).unwrap().is_none());

    // Trie is:
    //   key1
    //  /    \
    // key2  key3
    // Test removal of root when it's a branch with multiple children
    assert_eq!(merkle.remove(&key1).unwrap(), Some(Box::from(val1)));
    assert!(merkle.get_value(&key1).unwrap().is_none());
    assert!(merkle.remove(&key1).unwrap().is_none());

    // Trie is:
    //   key1 (now has no value)
    //  /    \
    // key2  key3
    let removed_val = merkle.remove(&key2).unwrap();
    assert_eq!(removed_val, Some(Box::from(val2)));
    assert!(merkle.get_value(&key2).unwrap().is_none());
    assert!(merkle.remove(&key2).unwrap().is_none());

    // Trie is:
    // key3
    let removed_val = merkle.remove(&key3).unwrap();
    assert_eq!(removed_val, Some(Box::from(val3)));
    assert!(merkle.get_value(&key3).unwrap().is_none());
    assert!(merkle.remove(&key3).unwrap().is_none());

    assert!(merkle.nodestore.root_node().is_none());
}

#[test]
fn remove_prefix_exact() {
    let mut merkle = two_byte_all_keys();
    for key_val in u8::MIN..=u8::MAX {
        let key = [key_val];
        let got = merkle.remove_prefix(&key).unwrap();
        assert_eq!(got, 1);
        let got = merkle.get_value(&key).unwrap();
        assert!(got.is_none());
    }
}

fn two_byte_all_keys() -> Merkle<NodeStore<Mutable<Propose>, MemStore, DefaultHashMode>> {
    let mut merkle = create_in_memory_merkle();
    for key_val in u8::MIN..=u8::MAX {
        let key = [key_val, key_val];
        let val = [key_val];

        merkle.insert(&key, Box::new(val)).unwrap();
        let got = merkle.get_value(&key).unwrap().unwrap();
        assert_eq!(&*got, val);
    }
    merkle
}

#[test]
fn remove_prefix_all() {
    let mut merkle = two_byte_all_keys();
    let got = merkle.remove_prefix(&[]).unwrap();
    assert_eq!(got, 256);
}

#[test]
fn remove_prefix_partial() {
    let mut merkle = create_in_memory_merkle();
    merkle
        .insert(b"abc", Box::from(b"value".as_slice()))
        .unwrap();
    merkle
        .insert(b"abd", Box::from(b"value".as_slice()))
        .unwrap();
    let got = merkle.remove_prefix(b"ab").unwrap();
    assert_eq!(got, 2);
}

#[test]
fn remove_many() {
    let mut merkle = create_in_memory_merkle();

    // insert key-value pairs
    for key_val in u8::MIN..=u8::MAX {
        let key = [key_val];
        let val = [key_val];

        merkle.insert(&key, Box::new(val)).unwrap();
        let got = merkle.get_value(&key).unwrap().unwrap();
        assert_eq!(&*got, val);
    }

    // remove key-value pairs
    for key_val in u8::MIN..=u8::MAX {
        let key = [key_val];
        let val = [key_val];

        let got = merkle.remove(&key).unwrap().unwrap();
        assert_eq!(&*got, val);

        // Removing an already removed key is a no-op
        assert!(merkle.remove(&key).unwrap().is_none());

        let got = merkle.get_value(&key).unwrap();
        assert!(got.is_none());
    }
    assert!(merkle.nodestore.root_node().is_none());
}

#[test]
fn remove_prefix() {
    let mut merkle = create_in_memory_merkle();

    // insert key-value pairs
    for key_val in u8::MIN..=u8::MAX {
        let key = [key_val, key_val];
        let val = [key_val];

        merkle.insert(&key, Box::new(val)).unwrap();
        let got = merkle.get_value(&key).unwrap().unwrap();
        assert_eq!(&*got, val);
    }

    // remove key-value pairs with prefix [0]
    let prefix = [0];
    assert_eq!(merkle.remove_prefix(&[0]).unwrap(), 1);

    // make sure all keys with prefix [0] were removed
    for key_val in u8::MIN..=u8::MAX {
        let key = [key_val, key_val];
        let got = merkle.get_value(&key).unwrap();
        if key[0] == prefix[0] {
            assert!(got.is_none());
        } else {
            assert!(got.is_some());
        }
    }
}

#[test]
fn get_empty_proof() {
    let merkle = create_in_memory_merkle().hash();
    let proof = merkle.prove(b"any-key");
    assert!(matches!(proof.unwrap_err(), ProofError::Empty));
}

#[test]
fn single_key_proof() {
    const TEST_SIZE: usize = 1;

    let mut merkle = create_in_memory_merkle();

    let rng = firewood_storage::SeededRng::from_env_or_random();

    let kvs = generate_random_kvs(&rng, TEST_SIZE);

    for (key, val) in &kvs {
        merkle.insert(key, val.clone().into_boxed_slice()).unwrap();
    }

    let merkle = merkle.hash();

    let root_hash = merkle.nodestore.root_hash().unwrap();

    for (key, value) in kvs {
        let proof = merkle.prove(&key).unwrap();

        proof
            .verify(
                key.clone(),
                Some(value.clone()),
                &root_hash,
                DefaultHashMode::ALGORITHM,
            )
            .unwrap();

        {
            // Test that the proof is invalid when the value is different
            let mut value = value.clone();
            value[0] = value[0].wrapping_add(1);
            assert!(
                proof
                    .verify(
                        key.clone(),
                        Some(value),
                        &root_hash,
                        DefaultHashMode::ALGORITHM
                    )
                    .is_err()
            );
        }

        {
            // Test that the proof is invalid when the hash is different
            assert!(
                proof
                    .verify(
                        key,
                        Some(value),
                        &TrieHash::empty(),
                        DefaultHashMode::ALGORITHM
                    )
                    .is_err()
            );
        }
    }
}

#[test]
fn empty_range_proof() {
    let merkle = create_in_memory_merkle();

    assert!(matches!(
        merkle.range_proof(None, None, None).unwrap_err(),
        api::Error::RangeProofOnEmptyTrie
    ));
}

#[test]
fn test_insert_leaf_suffix() {
    // key_2 is a suffix of key, which is a leaf
    let key = vec![0xff];
    let val = [1];
    let key_2 = vec![0xff, 0x00];
    let val_2 = [2];

    let mut merkle = create_in_memory_merkle();

    merkle.insert(&key, Box::new(val)).unwrap();
    merkle.insert(&key_2, Box::new(val_2)).unwrap();

    let got = merkle.get_value(&key).unwrap().unwrap();

    assert_eq!(*got, val);

    let got = merkle.get_value(&key_2).unwrap().unwrap();
    assert_eq!(*got, val_2);
}

#[test]
fn test_insert_leaf_prefix() {
    // key_2 is a prefix of key, which is a leaf
    let key = vec![0xff, 0x00];
    let val = [1];
    let key_2 = vec![0xff];
    let val_2 = [2];

    let mut merkle = create_in_memory_merkle();

    merkle.insert(&key, Box::new(val)).unwrap();
    merkle.insert(&key_2, Box::new(val_2)).unwrap();

    let got = merkle.get_value(&key).unwrap().unwrap();
    assert_eq!(*got, val);

    let got = merkle.get_value(&key_2).unwrap().unwrap();
    assert_eq!(*got, val_2);
}

#[test]
fn test_insert_sibling_leaf() {
    // The node at key is a branch node with children key_2 and key_3.
    // TODO(rkuris) assert in this test that key is the parent of key_2 and key_3.
    // i.e. the node types are branch, leaf, leaf respectively.
    let key = vec![0xff];
    let val = [1];
    let key_2 = vec![0xff, 0x00];
    let val_2 = [2];
    let key_3 = vec![0xff, 0x0f];
    let val_3 = [3];

    let mut merkle = create_in_memory_merkle();

    merkle.insert(&key, Box::new(val)).unwrap();
    merkle.insert(&key_2, Box::new(val_2)).unwrap();
    merkle.insert(&key_3, Box::new(val_3)).unwrap();

    let got = merkle.get_value(&key).unwrap().unwrap();
    assert_eq!(*got, val);

    let got = merkle.get_value(&key_2).unwrap().unwrap();
    assert_eq!(*got, val_2);

    let got = merkle.get_value(&key_3).unwrap().unwrap();
    assert_eq!(*got, val_3);
}

#[test]
fn test_insert_branch_as_branch_parent() {
    let key = vec![0xff, 0xf0];
    let val = [1];
    let key_2 = vec![0xff, 0xf0, 0x00];
    let val_2 = [2];
    let key_3 = vec![0xff];
    let val_3 = [3];

    let mut merkle = create_in_memory_merkle();

    merkle.insert(&key, Box::new(val)).unwrap();
    // key is a leaf

    merkle.insert(&key_2, Box::new(val_2)).unwrap();
    // key is branch with child key_2

    merkle.insert(&key_3, Box::new(val_3)).unwrap();
    // key_3 is a branch with child key
    // key is a branch with child key_3

    let got = merkle.get_value(&key).unwrap().unwrap();
    assert_eq!(&*got, val);

    let got = merkle.get_value(&key_2).unwrap().unwrap();
    assert_eq!(&*got, val_2);

    let got = merkle.get_value(&key_3).unwrap().unwrap();
    assert_eq!(&*got, val_3);
}

#[test]
fn test_insert_overwrite_branch_value() {
    let key = vec![0xff];
    let val = [1];
    let key_2 = vec![0xff, 0x00];
    let val_2 = [2];
    let overwrite = [3];

    let mut merkle = create_in_memory_merkle();

    merkle.insert(&key, Box::new(val)).unwrap();
    merkle.insert(&key_2, Box::new(val_2)).unwrap();

    let got = merkle.get_value(&key).unwrap().unwrap();
    assert_eq!(*got, val);

    let got = merkle.get_value(&key_2).unwrap().unwrap();
    assert_eq!(*got, val_2);

    merkle.insert(&key, Box::new(overwrite)).unwrap();

    let got = merkle.get_value(&key).unwrap().unwrap();
    assert_eq!(*got, overwrite);

    let got = merkle.get_value(&key_2).unwrap().unwrap();
    assert_eq!(*got, val_2);
}

#[test]
fn test_delete_one_child_with_branch_value() {
    let mut merkle = create_in_memory_merkle();
    // insert a parent with a value
    merkle.insert(&[0], Box::new([42u8])).unwrap();
    // insert child1 with a value
    merkle.insert(&[0, 1], Box::new([43u8])).unwrap();
    // insert child2 with a value
    merkle.insert(&[0, 2], Box::new([44u8])).unwrap();

    // now delete one of the children
    let deleted = merkle.remove(&[0, 1]).unwrap();
    assert_eq!(deleted, Some([43u8].to_vec().into_boxed_slice()));

    // make sure the parent still has the correct value
    let got = merkle.get_value(&[0]).unwrap().unwrap();
    assert_eq!(*got, [42u8]);

    // and check the remaining child
    let other_child = merkle.get_value(&[0, 2]).unwrap().unwrap();
    assert_eq!(*other_child, [44u8]);
}

#[test]
fn test_root_hash_simple_insertions() -> Result<(), Error> {
    init_merkle([
        ("do", "verb"),
        ("doe", "reindeer"),
        ("dog", "puppy"),
        ("doge", "coin"),
        ("horse", "stallion"),
        ("ddd", "ok"),
    ])
    .dump_to_string()
    .unwrap();
    Ok(())
}

#[test]
fn test_root_hash_fuzz_insertions() -> Result<(), FileIoError> {
    let rng = firewood_storage::SeededRng::from_option(Some(42));
    let max_len0 = 8;
    let max_len1 = 4;
    let keygen = || {
        let (len0, len1): (usize, usize) = {
            (
                rng.random_range(1..=max_len0),
                rng.random_range(1..=max_len1),
            )
        };
        let key: Vec<u8> = (0..len0)
            .map(|_| rng.random_range(0..2))
            .chain((0..len1).map(|_| rng.random()))
            .collect();
        key
    };

    for _ in 0..32 {
        let mut items = Vec::new();

        for _ in 0..100 {
            let val: Vec<u8> = (0..256).map(|_| rng.random()).collect();
            items.push((keygen(), val));
        }

        init_merkle(items);
    }

    Ok(())
}

#[test]
fn test_delete_child() {
    let items = vec![("do", "verb")];
    let merkle = init_merkle(items);
    let mut merkle = merkle.fork().unwrap();

    assert_eq!(merkle.remove(b"does_not_exist").unwrap(), None);
    assert_eq!(&*merkle.get_value(b"do").unwrap().unwrap(), b"verb");
}

#[test]
fn test_delete_some() {
    let items = (0..100)
        .map(|n| {
            let key = format!("key{n}");
            let val = format!("value{n}");
            (key.as_bytes().to_vec(), val.as_bytes().to_vec())
        })
        .collect::<Vec<(Vec<u8>, Vec<u8>)>>();
    let mut merkle = init_merkle(items.clone()).fork().unwrap();
    merkle.remove_prefix(b"key1").unwrap();
    for item in items {
        let (key, val) = item;
        if key.starts_with(b"key1") {
            assert!(merkle.get_value(&key).unwrap().is_none());
        } else {
            assert_eq!(&*merkle.get_value(&key).unwrap().unwrap(), val.as_slice());
        }
    }
}

#[test]
fn test_root_hash_reversed_deletions() -> Result<(), FileIoError> {
    let rng = firewood_storage::SeededRng::from_env_or_random();

    let max_len0 = 8;
    let max_len1 = 4;
    let keygen = || {
        let (len0, len1): (usize, usize) = {
            (
                rng.random_range(1..=max_len0),
                rng.random_range(1..=max_len1),
            )
        };
        (0..len0)
            .map(|_| rng.random_range(0..2))
            .chain((0..len1).map(|_| rng.random()))
            .collect()
    };

    for _ in 0..10 {
        let mut items: Vec<(Key, Value)> = (0..10)
            .map(|_| keygen())
            .map(|key| {
                let val = (0..8).map(|_| rng.random()).collect();
                (key, val)
            })
            .collect();

        items.sort_unstable();
        items.dedup_by_key(|(k, _)| k.clone());

        let init_merkle = create_in_memory_merkle();
        let init_immutable_merkle = init_merkle.hash();

        let (hashes, complete_immutable_merkle) = items.iter().fold(
            (vec![], init_immutable_merkle),
            |(mut hashes, immutable_merkle), (k, v)| {
                let root_hash = immutable_merkle.nodestore.root_hash();
                hashes.push(root_hash);
                let mut merkle = immutable_merkle.fork().unwrap();
                merkle.insert(k, v.clone()).unwrap();
                (hashes, merkle.hash())
            },
        );

        let (new_hashes, _) = items.iter().rev().fold(
            (vec![], complete_immutable_merkle),
            |(mut new_hashes, immutable_merkle_before_removal), (k, _)| {
                let before = immutable_merkle_before_removal.dump_to_string().unwrap();
                let mut merkle = Merkle::from(
                    NodeStore::new(immutable_merkle_before_removal.nodestore()).unwrap(),
                );
                merkle.remove(k).unwrap();
                let immutable_merkle_after_removal: Merkle<
                    NodeStore<Arc<ImmutableProposal>, _, DefaultHashMode>,
                > = merkle.try_into().unwrap();
                new_hashes.push((
                    immutable_merkle_after_removal.nodestore.root_hash(),
                    k,
                    before,
                    immutable_merkle_after_removal.dump_to_string().unwrap(),
                ));
                (new_hashes, immutable_merkle_after_removal)
            },
        );

        for (expected_hash, (actual_hash, key, before_removal, after_removal)) in
            hashes.into_iter().rev().zip(new_hashes)
        {
            let key = key.iter().fold(String::new(), |mut s, b| {
                let _ = write!(s, "{b:02x}");
                s
            });
            assert_eq!(
                actual_hash, expected_hash,
                "\n\nkey: {key}\nbefore:\n{before_removal}\nafter:\n{after_removal}\n\nexpected:\n{expected_hash:?}\nactual:\n{actual_hash:?}\n",
            );
        }
    }

    Ok(())
}

#[test]
fn remove_nonexistent_with_one() {
    let items = [("do", "verb")];
    let mut merkle = init_merkle(items).fork().unwrap();

    assert_eq!(merkle.remove(b"does_not_exist").unwrap(), None);
    assert_eq!(&*merkle.get_value(b"do").unwrap().unwrap(), b"verb");
}

#[test]
fn test_get_branch_from_nibbles_mut() {
    type TestMerkle = Merkle<NodeStore<Mutable<Propose>, MemStore, DefaultHashMode>>;
    let mut merkle = create_in_memory_merkle();
    merkle.insert(b"\xab", Box::from([1])).unwrap();
    merkle.insert(b"\xac", Box::from([2])).unwrap();

    // Branch exists at [a] — has children at b and c
    let branch = TestMerkle::get_branch_from_nibbles_mut(
        merkle.nodestore.root_mut(),
        &[PathComponent::try_new(0xa).unwrap()],
    );
    assert!(branch.is_some());

    // Nothing at [f]
    let missing = TestMerkle::get_branch_from_nibbles_mut(
        merkle.nodestore.root_mut(),
        &[PathComponent::try_new(0xf).unwrap()],
    );
    assert!(missing.is_none());

    // [a, b] is a leaf, not a branch
    let leaf = TestMerkle::get_branch_from_nibbles_mut(
        merkle.nodestore.root_mut(),
        &[
            PathComponent::try_new(0xa).unwrap(),
            PathComponent::try_new(0xb).unwrap(),
        ],
    );
    assert!(leaf.is_none());
}

/// `CollapseRange::contains` decides which boundary proof nodes the reconcile
/// loops in `verify_change_proof_root_hash` treat as in-range, and which branch
/// values `collapse_strip` clears. Its bound conventions are easy to get wrong,
/// so pin them directly: both bounds are inclusive, an empty `start` is −∞, and
/// a `None` `end` is +∞. `None` is distinct from `Some(&[])`, which is the empty
/// key itself — conflating the two put every key out of range at the upper
/// bound.
#[test_case(&[3], &[3], Some(&[7]), true ; "start bound is inclusive")]
#[test_case(&[7], &[3], Some(&[7]), true ; "end bound is inclusive")]
#[test_case(&[2], &[3], Some(&[7]), false ; "before start")]
#[test_case(&[8], &[3], Some(&[7]), false ; "after end")]
#[test_case(&[7, 0], &[3], Some(&[7]), false ; "longer key extending the end bound sorts after it")]
#[test_case(&[9, 9], &[3], None, true ; "None end is positive infinity")]
#[test_case(&[0], &[], Some(&[]), false ; "Some(empty) is the empty key, not positive infinity")]
fn test_collapse_range_contains(node: &[u8], start: &[u8], end: Option<&[u8]>, expected: bool) {
    assert_eq!(CollapseRange { start, end }.contains(node), expected);
}
