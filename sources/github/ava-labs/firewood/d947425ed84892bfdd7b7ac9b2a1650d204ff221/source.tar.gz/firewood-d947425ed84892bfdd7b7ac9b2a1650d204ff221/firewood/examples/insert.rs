// Copyright (C) 2023, Ava Labs, Inc. All rights reserved.
// See the file LICENSE.md for licensing terms.

// This example isn't an actual benchmark, it's just an example of how to
// insert some random keys using the front-end API.

use clap::Parser;
use std::collections::HashMap;
use std::error::Error;
use std::num::NonZeroUsize;
use std::ops::RangeInclusive;
use std::time::Instant;

use firewood::api::{self, DynDb, KeyType, ValueType};
use firewood::db::{BatchOp, DbConfig};
use firewood::manager::RevisionManagerConfig;
use firewood::open;
use firewood_storage::{DefaultHashMode, HashMode};
use rand::{RngExt, distr::Alphanumeric};

#[derive(Parser, Debug)]
struct Args {
    #[arg(short, long, default_value = "1-64", value_parser = string_to_range)]
    keylen: RangeInclusive<usize>,
    #[arg(short, long, default_value = "32", value_parser = string_to_range)]
    valuelen: RangeInclusive<usize>,
    #[arg(short, long, default_value_t = 1)]
    batch_size: usize,
    #[arg(short, long, default_value_t = 100)]
    number_of_batches: usize,
    #[arg(short = 'p', long, default_value_t = 0, value_parser = clap::value_parser!(u16).range(0..=100))]
    read_verify_percent: u16,
    #[arg(short, long)]
    seed: Option<u64>,
    #[arg(short, long, default_value_t = NonZeroUsize::new(192_000_000).expect("is non-zero"))]
    cache_memory_limit: NonZeroUsize,
    #[arg(short, long, default_value_t = true)]
    truncate: bool,
    #[arg(short, long, default_value_t = 128)]
    revisions: usize,
}

fn string_to_range(input: &str) -> Result<RangeInclusive<usize>, Box<dyn Error + Sync + Send>> {
    //<usize as std::str::FromStr>::Err> {
    let parts: Vec<&str> = input.split('-').collect();
    #[expect(clippy::indexing_slicing)]
    match parts.len() {
        1 => Ok(input.parse()?..=input.parse()?),
        2 => Ok(parts[0].parse()?..=parts[1].parse()?),
        _ => Err("Too many dashes in input string".into()),
    }
}

/// cargo run --release --example insert
fn main() -> Result<(), Box<dyn Error>> {
    let args = Args::parse();

    let mgrcfg = RevisionManagerConfig::builder()
        .node_cache_memory_limit(args.cache_memory_limit)
        .max_revisions(args.revisions)
        .build();
    let cfg = DbConfig::builder()
        .node_hash_algorithm(DefaultHashMode::ALGORITHM)
        .truncate(args.truncate)
        .manager(mgrcfg)
        .build();

    let db = open("firewood", cfg).expect("db initiation should succeed");

    let keys = args.batch_size;
    let start = Instant::now();

    let rng = &firewood_storage::SeededRng::from_option(args.seed);

    for _ in 0..args.number_of_batches {
        let keylen = rng.random_range(args.keylen.clone());
        let valuelen = rng.random_range(args.valuelen.clone());
        let batch = (0..keys)
            .map(|_| {
                (
                    rng.sample_iter(&Alphanumeric)
                        .take(keylen)
                        .collect::<Vec<u8>>(),
                    rng.sample_iter(&Alphanumeric)
                        .take(valuelen)
                        .collect::<Vec<u8>>(),
                )
            })
            .map(|(key, value)| BatchOp::Put { key, value })
            .collect::<Vec<_>>();

        let verify = get_keys_to_verify(rng, &batch, args.read_verify_percent);

        #[expect(clippy::unwrap_used)]
        let proposal = db
            .propose(api::collect_owned_batch(batch.clone())?)
            .unwrap();
        proposal.commit()?;
        verify_keys(db.as_ref(), verify)?;
    }

    let duration = start.elapsed();
    println!(
        "Generated and inserted {} batches of size {keys} in {duration:?}",
        args.number_of_batches
    );

    Ok(())
}

fn get_keys_to_verify<'a, K: KeyType + 'a, V: ValueType + 'a>(
    rng: &firewood_storage::SeededRng,
    batch: impl IntoIterator<Item = &'a BatchOp<K, V>>,
    pct: u16,
) -> HashMap<&'a [u8], &'a [u8]> {
    if pct == 0 {
        HashMap::new()
    } else {
        batch
            .into_iter()
            .filter(|_last_key| rng.random_range(0..=100u16.saturating_sub(pct)) == 0)
            .map(|op| {
                if let BatchOp::Put { key, value } = op {
                    (key.as_ref(), value.as_ref())
                } else {
                    unreachable!()
                }
            })
            .collect()
    }
}

fn verify_keys(db: &dyn DynDb, verify: HashMap<&[u8], &[u8]>) -> Result<(), firewood::api::Error> {
    if !verify.is_empty() {
        let hash = db.root_hash().expect("root hash should exist");
        let revision = db.revision(hash)?;
        for (key, value) in verify {
            assert_eq!(Some(value), revision.val(key)?.as_deref());
        }
    }
    Ok(())
}
