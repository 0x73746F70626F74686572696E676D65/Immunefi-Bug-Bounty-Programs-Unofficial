// Copyright (C) 2023, Ava Labs, Inc. All rights reserved.
// See the file LICENSE.md for licensing terms.

#![expect(
    clippy::missing_errors_doc,
    reason = "Found 12 occurrences after enabling the lint."
)]

#[cfg(test)]
mod tests;

pub use crate::api::BatchOp;
use crate::api::{
    self, ArcDynDbView, FrozenChangeProof, FrozenProof, FrozenRangeProof, HashKey, IntoBatchIter,
    KeyType, KeyValuePair,
};
use crate::iter::MerkleKeyValueIter;
use crate::merkle::changes::DiffMerkleNodeStream;
use crate::merkle::{Merkle, Value, verify_change_proof_root_hash};
use crate::verify_change_proof_structure;

use crate::manager::{ConfigManager, RevisionManager, RevisionManagerConfig};
use firewood_metrics::{firewood_counter, firewood_gauge, firewood_histogram};
#[cfg(test)]
use firewood_storage::DefaultHashMode;
use firewood_storage::{
    CargoVersion, CheckOpt, CheckerReport, Committed, CommittedParentHash, EthHash, FileBacked,
    FileIoError, GitDescribe, HashMode, HashedNodeReader, ImmutableProposal, MerkleDbHash, Mutable,
    NodeHashAlgorithm, NodeStore, Parentable, Propose, ReadableStorage, Recon, Reconstructed,
    TrieReader,
};
use std::io::Write;
use std::num::NonZeroUsize;
use std::path::Path;
use std::sync::Arc;
use thiserror::Error;
use typed_builder::TypedBuilder;

#[derive(Error, Debug)]
#[non_exhaustive]
/// Represents the different types of errors that can occur in the database.
pub enum DbError {
    /// I/O error
    #[error("I/O error: {0:?}")]
    FileIo(#[from] FileIoError),
}

impl<P, S: ReadableStorage, H: HashMode> api::DbView for NodeStore<P, S, H>
where
    NodeStore<P, S, H>: HashedNodeReader,
{
    type Iter<'view>
        = MerkleKeyValueIter<'view, Self>
    where
        Self: 'view;

    fn node_hash_algorithm(&self) -> NodeHashAlgorithm {
        H::ALGORITHM
    }

    fn root_hash(&self) -> Option<HashKey> {
        // Resolve the empty-trie root via the runtime hash mode `H`.
        HashedNodeReader::root_hash(self).or_else(H::default_root_hash)
    }

    fn val<K: api::KeyType>(&self, key: K) -> Result<Option<Value>, api::Error> {
        let merkle = Merkle::from(self);
        Ok(merkle.get_value(key.as_ref())?)
    }

    fn single_key_proof<K: api::KeyType>(&self, key: K) -> Result<FrozenProof, api::Error> {
        let merkle = Merkle::from(self);
        merkle.prove(key.as_ref()).map_err(api::Error::from)
    }

    fn range_proof<K: api::KeyType>(
        &self,
        first_key: Option<K>,
        last_key: Option<K>,
        limit: Option<NonZeroUsize>,
    ) -> Result<FrozenRangeProof, api::Error> {
        Merkle::from(self).range_proof(
            first_key.as_ref().map(AsRef::as_ref),
            last_key.as_ref().map(AsRef::as_ref),
            limit,
        )
    }

    fn iter_option<K: KeyType>(&self, first_key: Option<K>) -> Result<Self::Iter<'_>, api::Error> {
        match first_key {
            Some(key) => Ok(MerkleKeyValueIter::from_key(self, key)),
            None => Ok(MerkleKeyValueIter::from(self)),
        }
    }

    fn dump_to_string(&self) -> Result<String, api::Error> {
        let merkle = Merkle::from(self);
        merkle.dump_to_string().map_err(api::Error::from)
    }
}

#[derive(Clone, Debug)]
pub enum UseParallel {
    Never,
    BatchSize(usize),
    Always,
}

/// Database configuration.
#[derive(Clone, TypedBuilder, Debug)]
#[non_exhaustive]
pub struct DbConfig {
    /// The algorithm used for hashing nodes (required).
    ///
    /// In tests this defaults to the feature-selected compatibility algorithm.
    /// Production callers must select the algorithm explicitly.
    #[cfg_attr(test, builder(default = DefaultHashMode::ALGORITHM))]
    pub node_hash_algorithm: NodeHashAlgorithm,
    /// Whether to create the DB if it doesn't exist.
    #[builder(default = true)]
    pub create_if_missing: bool,
    /// Whether to truncate the DB when opening it. If set, the DB will be reset and all its
    /// existing contents will be lost.
    #[builder(default = false)]
    pub truncate: bool,
    /// Revision manager configuration.
    #[builder(default = RevisionManagerConfig::builder().build())]
    pub manager: RevisionManagerConfig,
    // Whether to perform parallel proposal creation. If set to BatchSize, then firewood
    // performs parallel proposal creation if the batch is >= to the BatchSize value.
    // TODO(bernard-avalabs): Experimentally determine the right value for BatchSize.
    #[builder(default = UseParallel::BatchSize(8))]
    pub use_parallel: UseParallel,
    /// Whether to enable `RootStore`.
    #[builder(default = false)]
    pub root_store: bool,
}

/// A database instance.
///
/// Callers **must** call `close()` when they are done with the database
/// to ensure the latest committed revision is persisted to disk. Dropping a
/// database without calling `close()` may result in committed data being lost.
#[derive(Debug)]
pub struct Db<H> {
    manager: RevisionManager<H>,
    use_parallel: UseParallel,
}

impl<H: HashMode> api::Db for Db<H> {
    type Historical = NodeStore<Committed, FileBacked, H>;

    type Proposal<'db>
        = Proposal<'db, H>
    where
        Self: 'db;

    fn node_hash_algorithm(&self) -> NodeHashAlgorithm {
        H::ALGORITHM
    }

    fn revision(&self, root_hash: HashKey) -> Result<Arc<Self::Historical>, api::Error> {
        let nodestore = self.manager.revision(root_hash)?;
        Ok(nodestore)
    }

    fn root_hash(&self) -> Option<HashKey> {
        self.manager.root_hash().or_else(H::default_root_hash)
    }

    fn propose(&self, batch: impl IntoBatchIter) -> Result<Self::Proposal<'_>, api::Error> {
        // Proposal created from db
        firewood_counter!(PROPOSALS_CREATED, "base" => "db").increment(1);

        self.propose_with_parent(batch, &*self.manager.current_revision())
    }
}

// The dyn boundary: erase a concrete `Db<H>` to `Box<dyn DynDb>` so a single
// binary can hold databases of different hash modes behind one type. The
// generic batch is pre-collected into an `OwnedBatch` at the boundary because a
// generic `impl IntoBatchIter` method is not object-safe.
impl<H: HashMode> api::DynDb for Db<H> {
    fn revision(&self, hash: HashKey) -> Result<ArcDynDbView, api::Error> {
        let nodestore = self.manager.revision(hash)?;
        Ok(nodestore as ArcDynDbView)
    }

    fn root_hash(&self) -> Option<HashKey> {
        api::Db::root_hash(self)
    }

    fn view(&self, hash: HashKey) -> Result<ArcDynDbView, api::Error> {
        Db::view(self, hash)
    }

    fn propose(
        &self,
        ops: api::OwnedBatch,
    ) -> Result<Box<dyn api::DynProposal<'_> + '_>, api::Error> {
        let proposal = api::Db::propose(self, ops)?;
        Ok(Box::new(proposal))
    }

    fn node_hash_algorithm(&self) -> NodeHashAlgorithm {
        H::ALGORITHM
    }

    fn dump_to_string(&self) -> Result<String, api::Error> {
        Db::dump_to_string(self).map_err(api::Error::from)
    }

    fn change_proof(
        &self,
        start_hash: HashKey,
        end_hash: HashKey,
        start_key: Option<&[u8]>,
        end_key: Option<&[u8]>,
        limit: Option<NonZeroUsize>,
    ) -> Result<FrozenChangeProof, api::Error> {
        Db::change_proof(self, start_hash, end_hash, start_key, end_key, limit)
    }

    fn verify_change_proof(
        &self,
        proof: &FrozenChangeProof,
        end_root: HashKey,
        start_key: Option<&[u8]>,
        end_key: Option<&[u8]>,
        max_length: Option<NonZeroUsize>,
    ) -> Result<Box<dyn api::DynProposal<'_> + '_>, api::Error> {
        let proposal =
            Db::verify_change_proof(self, proof, end_root, start_key, end_key, max_length)?;
        Ok(Box::new(proposal))
    }

    fn merge_key_value_range(
        &self,
        first_key: Option<&[u8]>,
        last_key: Option<&[u8]>,
        key_values: api::OwnedKeyValuePairs,
    ) -> Result<Box<dyn api::DynProposal<'_> + '_>, api::Error> {
        let proposal = Db::merge_key_value_range(self, first_key, last_key, key_values)?;
        Ok(Box::new(proposal))
    }

    fn reconstruct_from_view(
        &self,
        parent: &CommittedView,
        batch: api::OwnedBatch,
    ) -> Result<ReconstructedView<'_>, api::Error> {
        Db::reconstruct_from_view(self, parent, batch)
    }

    fn reconstruct_from_reconstructed<'db>(
        &'db self,
        parent: ReconstructedView<'db>,
        batch: api::OwnedBatch,
    ) -> Result<ReconstructedView<'db>, api::Error> {
        Db::reconstruct_from_reconstructed(self, parent.nodestore, batch)
    }

    fn committed_view(&self, hash: HashKey) -> Result<Option<CommittedView>, api::Error> {
        match Db::committed_view(self, hash) {
            Ok(view) => Ok(Some(view)),
            // `hash` names a proposal, not a committed revision.
            Err(api::Error::RevisionNotFound { .. }) => Ok(None),
            Err(err) => Err(err),
        }
    }

    fn close(self: Box<Self>) -> Result<(), api::Error> {
        Db::close(*self)
    }
}

/// Open or create a database, selecting the concrete hash mode at runtime from
/// [`DbConfig::node_hash_algorithm`], and return it as an erased [`api::DynDb`].
/// This is the public way to construct a database; the concrete [`Db<H>`](Db)
/// type is an implementation detail.
///
/// For an existing database, the configured algorithm must match the algorithm
/// persisted in the header; a mismatch is an error. For a fresh database, it
/// is the node-hashing scheme to create with. A single binary can open both an
/// Ethereum and a MerkleDB database.
///
/// # Errors
///
/// Returns an error if the database cannot be opened, or if the configured node
/// hash algorithm does not match an existing database's header.
pub fn open<P: AsRef<Path>>(db_dir: P, cfg: DbConfig) -> Result<Box<dyn api::DynDb>, api::Error> {
    Ok(match cfg.node_hash_algorithm {
        NodeHashAlgorithm::Ethereum => Box::new(Db::<EthHash>::new_with_hash_mode(db_dir, cfg)?),
        NodeHashAlgorithm::MerkleDB => {
            Box::new(Db::<MerkleDbHash>::new_with_hash_mode(db_dir, cfg)?)
        }
    })
}

impl<H: HashMode> Db<H> {
    /// Synchronously get an opaque handle to a committed historical revision.
    ///
    /// # Errors
    ///
    /// Returns [`api::Error::RevisionNotFound`] if `root_hash` does not identify
    /// an available committed revision.
    pub fn committed_view(&self, root_hash: HashKey) -> Result<CommittedView, api::Error> {
        Ok(CommittedView {
            nodestore: self.manager.revision(root_hash)?,
        })
    }

    /// Create or open a database with the hash mode fixed by `H`.
    // In-crate tests and benchmarks need typed construction; public callers use `open`.
    pub(crate) fn new_with_hash_mode<P: AsRef<Path>>(
        db_dir: P,
        cfg: DbConfig,
    ) -> Result<Self, api::Error> {
        if cfg.node_hash_algorithm != H::ALGORITHM {
            return Err(api::Error::HashModeMismatch {
                expected: H::ALGORITHM,
                found: cfg.node_hash_algorithm,
            });
        }
        let config_manager = ConfigManager::builder()
            .root_dir(db_dir.as_ref().to_path_buf())
            .create(cfg.create_if_missing)
            .truncate(cfg.truncate)
            .root_store(cfg.root_store)
            .manager(cfg.manager)
            .build();
        let manager = RevisionManager::<H>::new(config_manager)?;
        firewood_gauge!(
            BUILD_INFO,
            "version" => CargoVersion::CARGO_PKG_VERSION,
            "git_describe" => GitDescribe::GIT_DESCRIBE
        )
        .set(1.0);
        let db = Self {
            manager,
            use_parallel: cfg.use_parallel,
        };
        Ok(db)
    }

    /// Synchronously get a view, either committed or proposed
    pub fn view(&self, root_hash: HashKey) -> Result<ArcDynDbView, api::Error> {
        self.manager.view(root_hash).map_err(Into::into)
    }

    /// Dump the Trie of the latest revision.
    pub fn dump(&self, w: &mut dyn Write) -> Result<(), std::io::Error> {
        let latest_rev_nodestore = self.manager.current_revision();
        let merkle = Merkle::from(latest_rev_nodestore);
        merkle.dump(w).map_err(std::io::Error::other)
    }

    /// Dump the Trie of the latest revision to a String
    ///
    /// # Errors
    ///
    /// Returns an error if the dump operation fails
    pub fn dump_to_string(&self) -> Result<String, std::io::Error> {
        let latest_rev_nodestore = self.manager.current_revision();
        let merkle = Merkle::from(latest_rev_nodestore);
        merkle.dump_to_string().map_err(std::io::Error::other)
    }

    /// Check the database for consistency
    pub fn check(&self, opt: CheckOpt) -> CheckerReport {
        self.manager.check(opt)
    }

    /// Create a proposal with a specified parent. A proposal is created in parallel if `use_parallel`
    /// is `Always` or if `use_parallel` is `BatchSize` and the batch is >= to the `BatchSize` value.
    ///
    /// # Panics
    ///
    /// Panics if the revision manager cannot create a thread pool.
    #[fastrace::trace(name = "propose")]
    fn propose_with_parent<F: Parentable>(
        &self,
        batch: impl IntoBatchIter,
        parent: &NodeStore<F, FileBacked, H>,
    ) -> Result<Proposal<'_, H>, api::Error> {
        let propose_start = std::time::Instant::now();
        // Return immediately if the background thread is no longer running.
        self.manager.check_persist_error()?;
        let proposal: NodeStore<Mutable<Propose>, FileBacked, H> = NodeStore::new(parent)?;
        let mutable_nodestore = self
            .manager
            .apply_batch(&self.use_parallel, proposal, batch)?;
        let immutable: Arc<NodeStore<Arc<ImmutableProposal>, FileBacked, H>> =
            Arc::new(mutable_nodestore.try_into()?);
        self.manager.add_proposal(immutable.clone());

        firewood_histogram!(PROPOSE_DURATION_SECONDS).record(propose_start.elapsed().as_secs_f64());

        Ok(Proposal {
            nodestore: immutable,
            db: self,
        })
    }

    /// Merge a range of key-values into a new proposal on top of the current
    /// root revision.
    ///
    /// All items within the range `(first_key..=last_key)` will be replaced with
    /// the provided key-values from the iterator. I.e., any existing keys within
    /// the range that are not present in the provided key-values will be deleted,
    /// any duplicate keys will be overwritten, and any new keys will be inserted.
    ///
    /// Because that deletion is unconditional, `last_key` must be a bound the
    /// caller can justify. When the key-values come from a verified range
    /// proof, that is the proof's proven right edge ([`ProvenRange::end`]) and
    /// not the bound the caller requested: a truncated reply proves less than
    /// was asked for, and merging to the requested bound erases every local key
    /// in the span the proof never covered. Cover the remainder by iterating
    /// [`find_next_key_after_range_proof`] — each reply can truncate again.
    ///
    /// Invariant: `key_values` must be sorted by key in ascending order; however,
    /// because debug assertions are disabled, this is not checked.
    ///
    /// [`ProvenRange::end`]: crate::ProvenRange::end
    /// [`find_next_key_after_range_proof`]: crate::find_next_key_after_range_proof
    pub fn merge_key_value_range(
        &self,
        first_key: Option<impl KeyType>,
        last_key: Option<impl KeyType>,
        key_values: impl IntoIterator<Item: KeyValuePair>,
    ) -> Result<Proposal<'_, H>, api::Error> {
        self.merge_key_value_range_with_parent(
            first_key,
            last_key,
            key_values,
            &self.manager.current_revision(),
        )
    }

    /// Merge a range of key-values into a new proposal on top of a specified parent.
    ///
    /// All items within the range `(first_key..=last_key)` will be replaced with
    /// the provided key-values from the iterator. I.e., any existing keys within
    /// the range that are not present in the provided key-values will be deleted,
    /// any duplicate keys will be overwritten, and any new keys will be inserted.
    ///
    /// See [`Db::merge_key_value_range`] for the obligation `last_key` carries.
    ///
    /// Invariant: `key_values` must be sorted by key in ascending order; however,
    /// because debug assertions are disabled, this is not checked.
    pub fn merge_key_value_range_with_parent<F: Parentable>(
        &self,
        first_key: Option<impl KeyType>,
        last_key: Option<impl KeyType>,
        key_values: impl IntoIterator<Item: KeyValuePair>,
        parent: &NodeStore<F, FileBacked, H>,
    ) -> Result<Proposal<'_, H>, api::Error>
    where
        NodeStore<F, FileBacked, H>: TrieReader,
    {
        let merkle = Merkle::from(parent);
        let merge_ops = merkle.merge_key_value_range(first_key, last_key, key_values);
        self.propose_with_parent(merge_ops, merkle.nodestore())
    }

    pub fn apply_change_proof_to_parent<F: Parentable>(
        &self,
        batch_ops: impl IntoBatchIter,
        parent: &NodeStore<F, FileBacked, H>,
    ) -> Result<Proposal<'_, H>, api::Error>
    where
        NodeStore<F, FileBacked, H>: HashedNodeReader,
    {
        // Create a new proposal from the parent
        let merkle = Merkle::from(parent);
        self.propose_with_parent(batch_ops, merkle.nodestore())
    }

    /// Verify a change proof and create a proposal from it.
    ///
    /// Performs all three verification phases:
    /// 1. Structural validation (key ordering, range bounds, boundary proofs)
    /// 2. Apply batch ops to the latest revision to create a proposal
    /// 3. Root hash verification against `end_root`
    ///
    /// The batch ops are applied to the latest revision rather than
    /// `start_root` because each truncated change proof covers a
    /// non-overlapping key range. This avoids requiring `start_root` to
    /// still be available and reduces rebasing in `commit_with_rebase`.
    ///
    /// The proof is borrowed, not consumed — the caller retains it for
    /// `find_next_key` or serialization. Returns a standard `Proposal`
    /// ready for commit.
    pub fn verify_change_proof(
        &self,
        proof: &FrozenChangeProof,
        end_root: HashKey,
        start_key: Option<&[u8]>,
        end_key: Option<&[u8]>,
        max_length: Option<NonZeroUsize>,
    ) -> Result<Proposal<'_, H>, api::Error> {
        // The DB's hash mode is its type parameter `H`; the proof is verified
        // against that mode. The verifier rejects a proof whose header
        // advertises a different mode.
        let verification = verify_change_proof_structure(
            proof,
            end_root.clone(),
            start_key,
            end_key,
            H::ALGORITHM,
            max_length,
        )?;
        let parent = self.manager.current_revision();
        let proposal = self.apply_change_proof_to_parent(proof, &*parent)?;
        verify_change_proof_root_hash(proof, &verification, &proposal)?;
        Ok(proposal)
    }

    /// Reconstruct a view from a parent view by applying batch operations.
    ///
    /// Reconstruction is currently always applied serially.
    ///
    /// # Errors
    ///
    /// Returns an error if reconstruction fails.
    pub fn reconstruct_from_view(
        &self,
        parent: &CommittedView,
        batch: impl IntoBatchIter,
    ) -> Result<ReconstructedView<'_>, api::Error> {
        // A `CommittedView` can only be produced by a database of its own hash
        // mode, so a mismatch here means handles from two databases were mixed.
        debug_assert_eq!(parent.nodestore.node_hash_algorithm(), H::ALGORITHM);
        let nodestore =
            Arc::clone(&parent.nodestore).begin_reconstruction(api::collect_owned_batch(batch)?)?;

        Ok(ReconstructedView {
            db: self,
            nodestore,
        })
    }

    /// Reconstruct a view from an owned reconstructed parent by applying batch operations.
    ///
    /// This path consumes the reconstructed parent handle, allowing the internal
    /// conversion to move state instead of cloning when the underlying `Arc` is unique.
    ///
    /// # Errors
    ///
    /// Returns an error if reconstruction fails.
    fn reconstruct_from_reconstructed(
        &self,
        parent: api::ArcDynReconstructed,
        batch: impl IntoBatchIter,
    ) -> Result<ReconstructedView<'_>, api::Error> {
        // See `reconstruct_from_view`: a mismatch means mixed-database handles.
        debug_assert_eq!(parent.node_hash_algorithm(), H::ALGORITHM);
        let nodestore = parent.reconstruct_next(api::collect_owned_batch(batch)?)?;

        Ok(ReconstructedView {
            db: self,
            nodestore,
        })
    }

    /// Generate a change proof between two revisions identified by their root hashes.
    ///
    /// Returns the proof that covers key-value changes between `start_hash` and
    /// `end_hash` within the optional `[start_key, end_key]` range, truncated to
    /// at most `limit` entries.
    ///
    /// # Errors
    ///
    /// - [`api::Error::EndRevisionNotFound`] if `end_hash` is not found.
    /// - [`api::Error::StartRevisionNotFound`] if `start_hash` is not found.
    /// - Other I/O or structural errors during proof generation.
    pub fn change_proof(
        &self,
        start_hash: HashKey,
        end_hash: HashKey,
        start_key: Option<&[u8]>,
        end_key: Option<&[u8]>,
        limit: Option<NonZeroUsize>,
    ) -> Result<FrozenChangeProof, api::Error> {
        // Resolve end revision first so we return EndRevisionNotFound when both
        // hashes are missing (matching the FFI's prior error-precedence rule).
        let end_rev = self.manager.revision(end_hash).map_err(|err| {
            let err = api::Error::from(err);
            if let api::Error::RevisionNotFound { provided } = err {
                api::Error::EndRevisionNotFound { provided }
            } else {
                err
            }
        })?;
        let start_rev = self.manager.revision(start_hash).map_err(|err| {
            let err = api::Error::from(err);
            if let api::Error::RevisionNotFound { provided } = err {
                api::Error::StartRevisionNotFound { provided }
            } else {
                err
            }
        })?;
        let start_merkle = Merkle::from(start_rev);
        let end_merkle = Merkle::from(end_rev);
        end_merkle.change_proof(start_key, end_key, start_merkle.nodestore(), limit)
    }

    /// Closes the database gracefully.
    ///
    /// Shuts down the background persistence worker and persists the latest
    /// committed revision to disk. This method **must** be called before the
    /// database is dropped as otherwise, any committed data may be lost.
    pub fn close(self) -> Result<(), api::Error> {
        self.manager.close().map_err(Into::into)
    }
}

#[derive(Debug)]
/// A user-visible database proposal.
///
/// `H` mirrors the parent [`Db`]'s hash mode so the proof verify/write paths
/// can name it.
pub struct Proposal<'db, H> {
    nodestore: Arc<NodeStore<Arc<ImmutableProposal>, FileBacked, H>>,
    db: &'db Db<H>,
}

#[derive(Clone, Debug)]
/// Opaque handle to a historical committed revision.
///
/// Use this as the parent argument to [`Db::reconstruct_from_view`]. The
/// revision's hash mode is erased so the handle works for every mode without
/// naming it.
pub struct CommittedView {
    nodestore: api::ArcDynCommittedRevision,
}

#[derive(Debug)]
/// A user-visible reconstructed view.
///
/// The reconstructed state's hash mode is erased so the view can be produced
/// from a runtime-selected `Db<H>` in any hash mode without naming `H`.
pub struct ReconstructedView<'db> {
    nodestore: api::ArcDynReconstructed,
    db: &'db dyn api::DynDb,
}

impl Clone for ReconstructedView<'_> {
    fn clone(&self) -> Self {
        Self {
            nodestore: self.nodestore.clone(),
            db: self.db,
        }
    }
}

impl ReconstructedView<'_> {
    /// Returns the view backing this reconstructed state.
    #[must_use]
    pub fn view(&self) -> ArcDynDbView {
        Arc::clone(&self.nodestore) as ArcDynDbView
    }
}

// The erased reconstruction capabilities. These blanket impls cover every
// hash mode `H`, which is what lets the non-generic `CommittedView` and
// `ReconstructedView` handles work for any mode.
impl<H: HashMode> api::DynCommittedRevision for NodeStore<Committed, FileBacked, H> {
    fn begin_reconstruction(
        self: Arc<Self>,
        batch: api::OwnedBatch,
    ) -> Result<api::ArcDynReconstructed, api::Error> {
        let mutable = self.reconstruction_child()?;
        let mutable = RevisionManager::<H>::apply_batch_recon(mutable, batch)?;
        let reconstructed: NodeStore<Reconstructed<FileBacked, H>, FileBacked, H> = mutable.into();
        Ok(Arc::new(reconstructed))
    }
}

impl<H: HashMode> api::DynReconstructed for NodeStore<Reconstructed<FileBacked, H>, FileBacked, H> {
    fn reconstruct_next(
        self: Arc<Self>,
        batch: api::OwnedBatch,
    ) -> Result<api::ArcDynReconstructed, api::Error> {
        // Convert through `From<Arc<NodeStore<Reconstructed<_>, _, _>>>` so a
        // uniquely-held `Arc` moves the in-memory root (`Arc::try_unwrap` fast
        // path) instead of deep-cloning the subtree on every chain step.
        let mutable: NodeStore<Mutable<Recon<FileBacked, H>>, FileBacked, H> = self.into();
        let mutable = RevisionManager::<H>::apply_batch_recon(mutable, batch)?;
        let reconstructed: NodeStore<Reconstructed<FileBacked, H>, FileBacked, H> = mutable.into();
        Ok(Arc::new(reconstructed))
    }
}

impl<H: HashMode> api::DbView for Proposal<'_, H> {
    type Iter<'view>
        = MerkleKeyValueIter<'view, NodeStore<Arc<ImmutableProposal>, FileBacked, H>>
    where
        Self: 'view;

    fn node_hash_algorithm(&self) -> NodeHashAlgorithm {
        H::ALGORITHM
    }

    fn root_hash(&self) -> Option<api::HashKey> {
        api::DbView::root_hash(&*self.nodestore)
    }

    fn val<K: KeyType>(&self, key: K) -> Result<Option<Value>, api::Error> {
        api::DbView::val(&*self.nodestore, key)
    }

    fn single_key_proof<K: KeyType>(&self, key: K) -> Result<FrozenProof, api::Error> {
        api::DbView::single_key_proof(&*self.nodestore, key)
    }

    fn range_proof<K: KeyType>(
        &self,
        first_key: Option<K>,
        last_key: Option<K>,
        limit: Option<NonZeroUsize>,
    ) -> Result<FrozenRangeProof, api::Error> {
        api::DbView::range_proof(&*self.nodestore, first_key, last_key, limit)
    }

    fn iter_option<K: KeyType>(&self, first_key: Option<K>) -> Result<Self::Iter<'_>, api::Error> {
        api::DbView::iter_option(&*self.nodestore, first_key)
    }

    fn dump_to_string(&self) -> Result<String, api::Error> {
        api::DbView::dump_to_string(&*self.nodestore)
    }
}

impl<'db, H: HashMode> api::Proposal for Proposal<'db, H> {
    type Proposal = Proposal<'db, H>;

    fn propose(&self, batch: impl IntoBatchIter) -> Result<Self::Proposal, api::Error> {
        self.create_proposal(batch)
    }

    fn commit(self) -> Result<(), api::Error> {
        Ok(self.db.manager.commit(self.nodestore)?)
    }
}

// The dyn boundary for proposals. A borrowing `Proposal<'_, H>` cannot be
// `DynDbView` (that trait is `'static`), so its read surface is mirrored here
// by delegating to the proposal's `DbView` impl, and `view()` exposes the
// `'static` `ArcDynDbView` for the iterator/reconstruct paths.
impl<'db, H: HashMode> api::DynProposal<'db> for Proposal<'db, H> {
    fn root_hash(&self) -> Option<HashKey> {
        api::DbView::root_hash(self)
    }

    fn val(&self, key: &[u8]) -> Result<Option<Value>, api::Error> {
        api::DbView::val(self, key)
    }

    fn single_key_proof(&self, key: &[u8]) -> Result<FrozenProof, api::Error> {
        api::DbView::single_key_proof(self, key)
    }

    fn range_proof(
        &self,
        first_key: Option<&[u8]>,
        last_key: Option<&[u8]>,
        limit: Option<NonZeroUsize>,
    ) -> Result<FrozenRangeProof, api::Error> {
        api::DbView::range_proof(self, first_key, last_key, limit)
    }

    fn iter_option(
        &self,
        first_key: Option<&[u8]>,
    ) -> Result<api::BoxKeyValueIter<'_>, api::Error> {
        // NOTE: `Result::map` does not work here because the compiler cannot
        // correctly infer the unsizing coercion (see the `DynDbView` blanket).
        match api::DbView::iter_option(self, first_key) {
            Ok(iter) => Ok(Box::new(iter)),
            Err(e) => Err(e),
        }
    }

    fn dump_to_string(&self) -> Result<String, api::Error> {
        api::DbView::dump_to_string(self)
    }

    fn view(&self) -> ArcDynDbView {
        Proposal::view(self)
    }

    fn propose(
        &self,
        ops: api::OwnedBatch,
    ) -> Result<Box<dyn api::DynProposal<'db> + 'db>, api::Error> {
        // `create_proposal` builds a fresh nodestore borrowing the parent
        // `Db<H>` (lifetime `'db`), not `self`, so the result genuinely lives
        // for `'db` even though it is created through `&self`.
        let proposal = self.create_proposal(ops)?;
        Ok(Box::new(proposal))
    }

    fn commit(self: Box<Self>) -> Result<(), api::Error> {
        api::Proposal::commit(*self)
    }

    fn commit_with_rebase(self: Box<Self>) -> Result<Option<HashKey>, api::Error> {
        Proposal::commit_with_rebase(*self)
    }
}

impl<H: HashMode> Proposal<'_, H> {
    /// Commit the proposal, automatically rebasing if the parent revision
    /// is no longer the latest.
    ///
    /// Acquires the committed revisions write lock, checks if the proposal's
    /// parent matches the current revision, and if not, diffs the proposal
    /// against its original parent to reconstruct the batch ops, re-proposes
    /// them against the current revision, and commits the new proposal.
    ///
    /// The write lock is held throughout to prevent other commits from
    /// interleaving between the rebase and commit.
    ///
    /// Returns the root hash of the committed revision, or `None` if the
    /// committed trie is empty.
    ///
    /// # Panics
    ///
    /// Panics if the committed revisions queue is empty, which cannot happen
    /// because the queue is initialized with one revision at database creation.
    pub fn commit_with_rebase(self) -> Result<Option<api::HashKey>, api::Error> {
        let mut nodestore = self.nodestore;
        let db = self.db;

        let mut revisions_guard = db.manager.lock_committed_revisions();
        let current = revisions_guard.back().expect("always one revision");

        if !nodestore.parent_id_is(current.committed_id()) {
            // Parent is stale — rebase onto the current revision.
            let old_parent = match nodestore.committed_parent_hash() {
                CommittedParentHash::NotCommitted => {
                    return Err(api::Error::ParentNotCommitted);
                }
                CommittedParentHash::Hash(Some(hash)) => Some(db.manager.revision(hash)?),
                CommittedParentHash::Hash(None) => None,
            };
            db.manager.remove_proposal(&nodestore);

            // Empty trie parent — diff against a synthetic empty view.
            // Avoids depending on the manager's revisions queue, whose front
            // entry is not guaranteed to still be empty once `max_revisions`
            // has been exceeded.
            let empty_parent;
            let old_parent_ref: &NodeStore<Committed, FileBacked, H> =
                if let Some(rev) = &old_parent {
                    rev
                } else {
                    empty_parent = nodestore.empty_committed_sibling();
                    &empty_parent
                };
            let diff = DiffMerkleNodeStream::new(old_parent_ref, &*nodestore, Box::default())?;
            let batch_ops: Vec<BatchOp<crate::merkle::Key, crate::merkle::Value>> =
                diff.collect::<Result<_, _>>()?;

            let new_proposal = db.propose_with_parent(batch_ops, &**current)?;
            nodestore = new_proposal.nodestore;
        }

        let hash = api::DbView::root_hash(&*nodestore);
        let new_id = db
            .manager
            .commit_critical_section(&nodestore, &mut revisions_guard)?;
        drop(revisions_guard);
        db.manager.commit_cleanup(&nodestore, new_id);
        Ok(hash)
    }

    fn create_proposal(&self, batch: impl IntoBatchIter) -> Result<Self, api::Error> {
        // Proposal created based on another proposal
        firewood_counter!(PROPOSALS_CREATED, "base" => "proposal").increment(1);

        self.db.propose_with_parent(batch, &self.nodestore)
    }

    /// Returns the view backing this proposal.
    #[must_use]
    pub fn view(&self) -> ArcDynDbView {
        self.nodestore.clone()
    }

    /// Returns a reference to the inner nodestore.
    #[must_use]
    pub(crate) fn inner_nodestore(&self) -> &NodeStore<Arc<ImmutableProposal>, FileBacked, H> {
        &self.nodestore
    }
}

impl api::DbView for ReconstructedView<'_> {
    type Iter<'view>
        = api::BoxKeyValueIter<'view>
    where
        Self: 'view;

    fn node_hash_algorithm(&self) -> NodeHashAlgorithm {
        self.nodestore.node_hash_algorithm()
    }

    fn root_hash(&self) -> Option<api::HashKey> {
        self.nodestore.root_hash()
    }

    fn val<K: KeyType>(&self, key: K) -> Result<Option<Value>, api::Error> {
        self.nodestore.val(key.as_ref())
    }

    fn single_key_proof<K: KeyType>(&self, key: K) -> Result<FrozenProof, api::Error> {
        self.nodestore.single_key_proof(key.as_ref())
    }

    fn range_proof<K: KeyType>(
        &self,
        first_key: Option<K>,
        last_key: Option<K>,
        limit: Option<NonZeroUsize>,
    ) -> Result<FrozenRangeProof, api::Error> {
        self.nodestore.range_proof(
            first_key.as_ref().map(AsRef::as_ref),
            last_key.as_ref().map(AsRef::as_ref),
            limit,
        )
    }

    fn iter_option<K: KeyType>(&self, first_key: Option<K>) -> Result<Self::Iter<'_>, api::Error> {
        self.nodestore
            .iter_option(first_key.as_ref().map(AsRef::as_ref))
    }

    fn dump_to_string(&self) -> Result<String, api::Error> {
        self.nodestore.dump_to_string()
    }
}

// The owning database is reached through the erased [`api::DynDb`] so
// reconstruction works off a runtime-selected `Db<H>` in any hash mode.
impl<'a> api::Reconstructible for ReconstructedView<'a> {
    type Reconstructed = ReconstructedView<'a>;

    fn reconstruct(self, batch: impl IntoBatchIter) -> Result<Self::Reconstructed, api::Error>
    where
        Self: Sized,
    {
        let ops = api::collect_owned_batch(batch)?;
        let db = self.db;
        db.reconstruct_from_reconstructed(self, ops)
    }

    fn db(&self) -> &dyn api::DynDb {
        self.db
    }
}

#[cfg(test)]
mod test {
    use core::iter::Take;
    use std::collections::HashMap;
    use std::iter::Peekable;
    use std::num::{NonZeroU64, NonZeroUsize};
    use std::ops::{Deref, DerefMut};
    use std::path::Path;

    use firewood_storage::{
        CheckOpt, CheckerError, DefaultHashMode, HashMode, LinearAddress, MaybePersistedNode,
        NodeHashAlgorithm, TrieHash,
    };
    use nonzero_ext::nonzero;

    use crate::api::{self, Db as _, DbView, HashKeyExt, Proposal as _, Reconstructible};
    use crate::db::{Db, Proposal, UseParallel};
    use crate::manager::RevisionManagerConfig;

    use super::{BatchOp, DbConfig, open};

    /// A chunk of an iterator, provided by [`IterExt::chunk_fold`] to the folding
    /// function.
    type Chunk<'chunk, 'base, T> = &'chunk mut Take<&'base mut Peekable<T>>;

    trait IterExt: Iterator {
        /// Asynchronously folds the iterator with chunks of a specified size. The last
        /// chunk may be smaller than the specified size.
        ///
        /// The folding function is a closure that takes an accumulator and a
        /// chunk of the underlying iterator, and returns a new accumulator.
        ///
        /// # Panics
        ///
        /// If the folding function does not consume the entire chunk, it will panic.
        ///
        /// If the folding function panics, the iterator will be dropped (because this
        /// method consumes `self`).
        fn chunk_fold<B, F>(self, chunk_size: NonZeroUsize, init: B, mut f: F) -> B
        where
            Self: Sized,
            F: for<'a, 'b> FnMut(B, Chunk<'a, 'b, Self>) -> B,
        {
            let chunk_size = chunk_size.get();
            let mut iter = self.peekable();
            let mut acc = init;
            while iter.peek().is_some() {
                let mut chunk = iter.by_ref().take(chunk_size);
                acc = f(acc, chunk.by_ref());
                assert!(chunk.next().is_none(), "entire chunk was not consumed");
            }
            acc
        }
    }

    impl<T: Iterator> IterExt for T {}

    impl Db<DefaultHashMode> {
        /// Wait until all pending commits have been persisted.
        fn wait_persisted(&self) {
            self.manager.wait_persisted();
        }
    }

    fn runtime_mode_puts(pairs: &[(&str, &str)]) -> api::OwnedBatch {
        pairs
            .iter()
            .map(|(key, value)| BatchOp::Put {
                key: key.as_bytes().into(),
                value: value.as_bytes().into(),
            })
            .collect()
    }

    #[test]
    fn runtime_hash_modes_work_side_by_side() {
        let ethereum_dir = tempfile::tempdir().unwrap();
        let ethereum_db = open(
            ethereum_dir.path(),
            DbConfig::builder()
                .node_hash_algorithm(NodeHashAlgorithm::Ethereum)
                .build(),
        )
        .unwrap();

        let merkledb_dir = tempfile::tempdir().unwrap();
        let merkledb_db = open(
            merkledb_dir.path(),
            DbConfig::builder()
                .node_hash_algorithm(NodeHashAlgorithm::MerkleDB)
                .build(),
        )
        .unwrap();

        // Both implementations remain live behind the same object-safe interface.
        assert_eq!(
            ethereum_db.node_hash_algorithm(),
            NodeHashAlgorithm::Ethereum
        );
        assert_eq!(
            ethereum_db.root_hash().map(hex::encode).as_deref(),
            Some("56e81f171bcc55a6ff8345e692c0f86e5b48e01b996cadc001622fb5e363b421")
        );

        assert_eq!(
            merkledb_db.node_hash_algorithm(),
            NodeHashAlgorithm::MerkleDB
        );
        assert_eq!(merkledb_db.root_hash(), None);

        ethereum_db
            .propose(runtime_mode_puts(&[("a", "1")]))
            .unwrap()
            .commit()
            .unwrap();
        merkledb_db
            .propose(runtime_mode_puts(&[("a", "1")]))
            .unwrap()
            .commit()
            .unwrap();

        let ethereum_root = ethereum_db.root_hash().expect("committed trie has a root");
        assert_eq!(
            hex::encode(ethereum_root.clone()),
            "59b697a4db0c475540486215c1e8f64945a4a0ad8d291de6cd9021c4fbf639dd"
        );
        let ethereum_proof = ethereum_db
            .view(ethereum_root)
            .unwrap()
            .range_proof(None, None, None)
            .unwrap();
        assert_eq!(ethereum_proof.hash_mode(), NodeHashAlgorithm::Ethereum);

        let merkledb_root = merkledb_db.root_hash().expect("committed trie has a root");
        assert_eq!(
            hex::encode(merkledb_root.clone()),
            "1ffe11ce995a9c07021d6f8a8c5b1817e6375dd0ea27296b91a8d48db2858bc9"
        );
        let merkledb_proof = merkledb_db
            .view(merkledb_root)
            .unwrap()
            .range_proof(None, None, None)
            .unwrap();
        assert_eq!(merkledb_proof.hash_mode(), NodeHashAlgorithm::MerkleDB);

        ethereum_db.close().unwrap();
        merkledb_db.close().unwrap();

        // The persisted header restores the selected algorithm and root.
        let ethereum_db = open(
            ethereum_dir.path(),
            DbConfig::builder()
                .node_hash_algorithm(NodeHashAlgorithm::Ethereum)
                .build(),
        )
        .unwrap();
        assert_eq!(
            ethereum_db.node_hash_algorithm(),
            NodeHashAlgorithm::Ethereum
        );
        assert_eq!(
            ethereum_db.root_hash().map(hex::encode).as_deref(),
            Some("59b697a4db0c475540486215c1e8f64945a4a0ad8d291de6cd9021c4fbf639dd")
        );

        let merkledb_db = open(
            merkledb_dir.path(),
            DbConfig::builder()
                .node_hash_algorithm(NodeHashAlgorithm::MerkleDB)
                .build(),
        )
        .unwrap();
        assert_eq!(
            merkledb_db.node_hash_algorithm(),
            NodeHashAlgorithm::MerkleDB
        );
        assert_eq!(
            merkledb_db.root_hash().map(hex::encode).as_deref(),
            Some("1ffe11ce995a9c07021d6f8a8c5b1817e6375dd0ea27296b91a8d48db2858bc9")
        );

        ethereum_db.close().unwrap();
        merkledb_db.close().unwrap();
    }

    #[test]
    fn reconstructed_views_preserve_runtime_hash_mode() {
        let dir = tempfile::tempdir().unwrap();
        let db = open(
            dir.path(),
            DbConfig::builder()
                .node_hash_algorithm(DefaultHashMode::ALGORITHM)
                .build(),
        )
        .unwrap();

        db.propose(runtime_mode_puts(&[("a", "1")]))
            .unwrap()
            .commit()
            .unwrap();

        let root = db.root_hash().expect("committed trie has a root");
        let committed = db
            .committed_view(root)
            .unwrap()
            .expect("root is a committed revision");
        let reconstructed = db
            .reconstruct_from_view(&committed, runtime_mode_puts(&[]))
            .unwrap();
        assert_eq!(
            reconstructed.node_hash_algorithm(),
            DefaultHashMode::ALGORITHM
        );

        let reconstructed = reconstructed
            .reconstruct(runtime_mode_puts(&[("b", "2")]))
            .unwrap();
        assert_eq!(
            reconstructed.node_hash_algorithm(),
            DefaultHashMode::ALGORITHM
        );
        assert_eq!(
            reconstructed.val(b"a").unwrap().as_deref(),
            Some(b"1".as_slice())
        );
        assert_eq!(
            reconstructed.val(b"b").unwrap().as_deref(),
            Some(b"2".as_slice())
        );

        db.close().unwrap();
    }

    /// Reconstruction always uses the serial path (`apply_batch_recon`), but the base
    /// revision may have been built with parallel or serial proposals. This test confirms
    /// both produce identical reconstruction results.
    #[test]
    fn test_reconstruct_deterministic() {
        let parallel_db = TestDb::new_with_config(
            DbConfig::builder()
                .use_parallel(UseParallel::Always)
                .build(),
        );
        let serial_db =
            TestDb::new_with_config(DbConfig::builder().use_parallel(UseParallel::Never).build());

        let initial_batch = vec![BatchOp::Put {
            key: b"base",
            value: b"v0",
        }];
        let parallel_proposal = parallel_db.propose(initial_batch.clone()).unwrap();
        let serial_proposal = serial_db.propose(initial_batch).unwrap();
        parallel_proposal.commit().unwrap();
        serial_proposal.commit().unwrap();

        let parallel_historical = parallel_db
            .committed_view(parallel_db.root_hash().unwrap())
            .unwrap();
        let serial_historical = serial_db
            .committed_view(serial_db.root_hash().unwrap())
            .unwrap();

        let reconstruct_batch = vec![
            BatchOp::Put {
                key: b"base",
                value: b"v1",
            },
            BatchOp::Put {
                key: b"next",
                value: b"v2",
            },
        ];

        let parallel_reconstructed = parallel_db
            .reconstruct_from_view(&parallel_historical, reconstruct_batch.clone())
            .unwrap();
        let serial_reconstructed = serial_db
            .reconstruct_from_view(&serial_historical, reconstruct_batch)
            .unwrap();

        assert_eq!(
            parallel_reconstructed.root_hash(),
            serial_reconstructed.root_hash()
        );
        assert_eq!(
            parallel_reconstructed.val(b"base").unwrap(),
            serial_reconstructed.val(b"base").unwrap()
        );
        assert_eq!(
            parallel_reconstructed.val(b"next").unwrap(),
            serial_reconstructed.val(b"next").unwrap()
        );
    }

    #[test]
    fn test_update_commits_batch_and_returns_root() {
        let db = TestDb::new();

        let root = db
            .update(vec![BatchOp::Put {
                key: b"k",
                value: b"v",
            }])
            .unwrap()
            .unwrap();

        assert_eq!(db.root_hash().as_ref(), Some(&root));

        let historical = db.revision(root.clone()).unwrap();
        assert_eq!(&*historical.val(b"k").unwrap().unwrap(), b"v");

        let next_root = db
            .update(vec![BatchOp::Put {
                key: b"k",
                value: b"v2",
            }])
            .unwrap()
            .unwrap();

        assert_ne!(root, next_root);
        assert_eq!(&*historical.val(b"k").unwrap().unwrap(), b"v");
        assert_eq!(
            &*db.revision(next_root).unwrap().val(b"k").unwrap().unwrap(),
            b"v2"
        );
    }

    #[test]
    fn test_update_returns_empty_root_after_delete_all() {
        let db = TestDb::new();

        db.update(vec![BatchOp::Put {
            key: b"k",
            value: b"v",
        }])
        .unwrap();

        let root = db
            .update(vec![BatchOp::<&[u8], &[u8]>::Delete {
                key: b"k".as_slice(),
            }])
            .unwrap();

        assert_eq!(root, TrieHash::default_root_hash());
        assert_eq!(db.root_hash(), TrieHash::default_root_hash());
    }

    #[test]
    fn test_proposal_reads() {
        let db = TestDb::new();
        let batch = vec![BatchOp::Put {
            key: b"k",
            value: b"v",
        }];
        let proposal = db.propose(batch).unwrap();
        assert_eq!(&*proposal.val(b"k").unwrap().unwrap(), b"v");

        assert_eq!(proposal.val(b"notfound").unwrap(), None);
        proposal.commit().unwrap();

        let batch = vec![BatchOp::Put {
            key: b"k",
            value: b"v2",
        }];
        let proposal = db.propose(batch).unwrap();
        assert_eq!(&*proposal.val(b"k").unwrap().unwrap(), b"v2");

        let committed = db.root_hash().unwrap();
        let historical = db.revision(committed).unwrap();
        assert_eq!(&*historical.val(b"k").unwrap().unwrap(), b"v");
    }

    #[test]
    fn test_reconstruct_reads_and_chains() {
        let db = TestDb::new();

        let initial = db
            .propose(vec![BatchOp::Put {
                key: b"base",
                value: b"v0",
            }])
            .unwrap();
        initial.commit().unwrap();

        let historical_hash = db.root_hash().unwrap();
        let historical = db.committed_view(historical_hash).unwrap();

        let reconstructed = db
            .reconstruct_from_view(
                &historical,
                vec![BatchOp::Put {
                    key: b"base",
                    value: b"v1",
                }],
            )
            .unwrap();
        assert!(reconstructed.root_hash().is_some());
        assert_eq!(&*reconstructed.val(b"base").unwrap().unwrap(), b"v1");

        let reconstructed = reconstructed
            .reconstruct(vec![BatchOp::Put {
                key: b"next",
                value: b"v2",
            }])
            .unwrap();

        assert_eq!(&*reconstructed.val(b"base").unwrap().unwrap(), b"v1");
        assert_eq!(&*reconstructed.val(b"next").unwrap().unwrap(), b"v2");
    }

    #[test]
    fn test_reconstruct_from_committed_view_uses_requested_revision() {
        let db = TestDb::new();
        let key = b"k";
        let historical_value = b"historical";
        let latest_value = b"latest";

        db.propose(vec![BatchOp::Put {
            key,
            value: historical_value,
        }])
        .unwrap()
        .commit()
        .unwrap();
        let historical_hash = db.root_hash().unwrap();

        db.propose(vec![BatchOp::Put {
            key,
            value: latest_value,
        }])
        .unwrap()
        .commit()
        .unwrap();

        let historical = db.committed_view(historical_hash).unwrap();
        let reconstructed = db
            .reconstruct_from_view(&historical, Vec::<BatchOp<&[u8], &[u8]>>::new())
            .unwrap();

        assert_eq!(&*reconstructed.val(key).unwrap().unwrap(), historical_value);
        assert_eq!(
            &*db.revision(db.root_hash().unwrap())
                .unwrap()
                .val(key)
                .unwrap()
                .unwrap(),
            latest_value
        );
    }

    #[test]
    fn test_reconstruct_clone_is_independent() {
        let db = TestDb::new();

        // Build a base committed revision.
        let initial = db
            .propose(vec![BatchOp::Put {
                key: b"base",
                value: b"v0",
            }])
            .unwrap();
        initial.commit().unwrap();
        let historical_hash = db.root_hash().unwrap();
        let historical = db.committed_view(historical_hash).unwrap();

        // Build a reconstructed view on top of the historical revision.
        let original = db
            .reconstruct_from_view(
                &historical,
                vec![BatchOp::Put {
                    key: b"shared",
                    value: b"v1",
                }],
            )
            .unwrap();
        let original_root = original.root_hash();

        // Verify that a cloned reconstructed revision has the same state as the original.
        let cloned = original.clone();
        assert_eq!(cloned.root_hash(), original_root);
        assert_eq!(&*cloned.val(b"base").unwrap().unwrap(), b"v0");
        assert_eq!(&*cloned.val(b"shared").unwrap().unwrap(), b"v1");

        // Mutating the clone via reconstruct does not affect the original.
        let new_cloned = cloned
            .reconstruct(vec![BatchOp::Put {
                key: b"clone_only",
                value: b"v2",
            }])
            .unwrap();
        assert_eq!(&*new_cloned.val(b"clone_only").unwrap().unwrap(), b"v2");
        assert_eq!(original.val(b"clone_only").unwrap(), None);
        assert_eq!(original.root_hash(), original_root);

        // Mutating the original via reconstruct does not affect the clone.
        let original_next = original
            .reconstruct(vec![BatchOp::Put {
                key: b"original_only",
                value: b"v3",
            }])
            .unwrap();
        assert_eq!(
            &*original_next.val(b"original_only").unwrap().unwrap(),
            b"v3"
        );
        assert_eq!(new_cloned.val(b"original_only").unwrap(), None);
    }

    #[test]
    fn test_reconstruct_clone_of_clone() {
        let db = TestDb::new();

        // Build a base committed revision.
        let initial = db
            .propose(vec![BatchOp::Put {
                key: b"base",
                value: b"v0",
            }])
            .unwrap();
        initial.commit().unwrap();
        let historical_hash = db.root_hash().unwrap();
        let historical = db.committed_view(historical_hash).unwrap();

        // Build a reconstructed view on top of the historical revision.
        let original = db
            .reconstruct_from_view(
                &historical,
                vec![BatchOp::Put {
                    key: b"shared",
                    value: b"v1",
                }],
            )
            .unwrap();
        let original_root = original.root_hash();

        let first_clone = original.clone();
        let second_clone = first_clone.clone();

        // Verify that the first and second clones are usable
        assert_eq!(original_root, first_clone.root_hash());
        assert_eq!(original_root, second_clone.root_hash());
    }

    #[test]
    fn test_reconstruct_clone_outlives_original() {
        let db = TestDb::new();

        let key = b"k";
        let value = b"v";
        let initial = db.propose(vec![BatchOp::Put { key, value }]).unwrap();
        initial.commit().unwrap();

        let historical_hash = db.root_hash().unwrap();
        let historical = db.committed_view(historical_hash).unwrap();

        let original = db
            .reconstruct_from_view(&historical, Vec::<BatchOp<&[u8], &[u8]>>::new())
            .unwrap();
        let cloned = original.clone();
        let expected_root = original.root_hash();

        drop(original);

        // The clone is fully functional after the original is dropped.
        assert_eq!(cloned.root_hash(), expected_root);
        assert_eq!(&*cloned.val(b"k").unwrap().unwrap(), b"v");
    }

    #[test]
    fn reopen_test() {
        let db = TestDb::new();
        let initial_root = db.root_hash();
        let batch = vec![
            BatchOp::Put {
                key: b"a",
                value: b"1",
            },
            BatchOp::Put {
                key: b"b",
                value: b"2",
            },
        ];
        let proposal = db.propose(batch).unwrap();
        proposal.commit().unwrap();
        println!("{:?}", db.root_hash().unwrap());

        let db = db.reopen();
        println!("{:?}", db.root_hash().unwrap());
        let committed = db.root_hash().unwrap();
        let historical = db.revision(committed).unwrap();
        assert_eq!(&*historical.val(b"a").unwrap().unwrap(), b"1");
        drop(historical);

        let db = db.replace();
        let final_root = db.root_hash();
        println!("{final_root:?}");
        assert_eq!(final_root, initial_root);
    }

    #[test]
    // test that dropping a proposal removes it from the list of known proposals
    //    /-> P1 - will get committed
    // R1 --> P2 - will get dropped
    //    \-> P3 - will get orphaned, but it's still known
    fn test_proposal_scope_historic() {
        let db = TestDb::new();
        let batch1 = vec![BatchOp::Put {
            key: b"k1",
            value: b"v1",
        }];
        let proposal1 = db.propose(batch1).unwrap();
        assert_eq!(&*proposal1.val(b"k1").unwrap().unwrap(), b"v1");

        let batch2 = vec![BatchOp::Put {
            key: b"k2",
            value: b"v2",
        }];
        let proposal2 = db.propose(batch2).unwrap();
        assert_eq!(&*proposal2.val(b"k2").unwrap().unwrap(), b"v2");

        let batch3 = vec![BatchOp::Put {
            key: b"k3",
            value: b"v3",
        }];
        let proposal3 = db.propose(batch3).unwrap();
        assert_eq!(&*proposal3.val(b"k3").unwrap().unwrap(), b"v3");

        // the proposal is dropped here, but the underlying
        // nodestore is still accessible because it's referenced by the revision manager
        // The third proposal remains referenced
        let p2hash = proposal2.root_hash().unwrap();
        assert!(db.manager.proposal_hashes().contains(&p2hash));
        drop(proposal2);

        // commit the first proposal
        proposal1.commit().unwrap();
        // Ensure we committed the first proposal's data
        let committed = db.root_hash().unwrap();
        let historical = db.revision(committed).unwrap();
        assert_eq!(&*historical.val(b"k1").unwrap().unwrap(), b"v1");

        // the second proposal shouldn't be available to commit anymore
        assert!(!db.manager.proposal_hashes().contains(&p2hash));

        // the third proposal should still be contained within the all_hashes list
        // would be deleted if another proposal was committed and proposal3 was dropped here
        let hash3 = proposal3.root_hash().unwrap();
        assert!(db.manager.proposal_hashes().contains(&hash3));
    }

    #[test]
    // test that dropping a proposal removes it from the list of known proposals
    // R1 - base revision
    //  \-> P1 - will get committed
    //   \-> P2 - will get dropped
    //    \-> P3 - will get orphaned, but it's still known
    fn test_proposal_scope_orphan() {
        let db = TestDb::new();
        let batch1 = vec![BatchOp::Put {
            key: b"k1",
            value: b"v1",
        }];
        let proposal1 = db.propose(batch1).unwrap();
        assert_eq!(&*proposal1.val(b"k1").unwrap().unwrap(), b"v1");

        let batch2 = vec![BatchOp::Put {
            key: b"k2",
            value: b"v2",
        }];
        let proposal2 = proposal1.propose(batch2).unwrap();
        assert_eq!(&*proposal2.val(b"k2").unwrap().unwrap(), b"v2");

        let batch3 = vec![BatchOp::Put {
            key: b"k3",
            value: b"v3",
        }];
        let proposal3 = proposal2.propose(batch3).unwrap();
        assert_eq!(&*proposal3.val(b"k3").unwrap().unwrap(), b"v3");

        // the proposal is dropped here, but the underlying
        // nodestore is still accessible because it's referenced by the revision manager
        // The third proposal remains referenced
        let p2hash = proposal2.root_hash().unwrap();
        assert!(db.manager.proposal_hashes().contains(&p2hash));
        drop(proposal2);

        // commit the first proposal
        proposal1.commit().unwrap();
        // Ensure we committed the first proposal's data
        let committed = db.root_hash().unwrap();
        let historical = db.revision(committed).unwrap();
        assert_eq!(&*historical.val(b"k1").unwrap().unwrap(), b"v1");

        // the second proposal shouldn't be available to commit anymore
        assert!(!db.manager.proposal_hashes().contains(&p2hash));

        // the third proposal should still be contained within the all_hashes list
        let hash3 = proposal3.root_hash().unwrap();
        assert!(db.manager.proposal_hashes().contains(&hash3));

        // moreover, the data from the second and third proposals should still be available
        // through proposal3
        assert_eq!(&*proposal3.val(b"k2").unwrap().unwrap(), b"v2");
        assert_eq!(&*proposal3.val(b"k3").unwrap().unwrap(), b"v3");
    }

    #[test]
    fn test_view_sync() {
        let db = TestDb::new();

        // Create and commit some data to get a historical revision
        let batch = vec![BatchOp::Put {
            key: b"historical_key",
            value: b"historical_value",
        }];
        let proposal = db.propose(batch).unwrap();
        let historical_hash = proposal.root_hash().unwrap();
        proposal.commit().unwrap();

        // Create a new proposal (uncommitted)
        let batch = vec![BatchOp::Put {
            key: b"proposal_key",
            value: b"proposal_value",
        }];
        let proposal = db.propose(batch).unwrap();
        let proposal_hash = proposal.root_hash().unwrap();

        // Test that view_sync can find the historical revision
        let historical_view = db.view(historical_hash).unwrap();
        let value = historical_view.val(b"historical_key").unwrap().unwrap();
        assert_eq!(&*value, b"historical_value");

        // Test that view_sync can find the proposal
        let proposal_view = db.view(proposal_hash).unwrap();
        let value = proposal_view.val(b"proposal_key").unwrap().unwrap();
        assert_eq!(&*value, b"proposal_value");
    }

    #[test]
    fn test_propose_parallel_reopen() {
        fn insert_commit(db: &TestDb, kv: u8) {
            let keys: Vec<[u8; 1]> = vec![[kv; 1]];
            let vals: Vec<Box<[u8]>> = vec![Box::new([kv; 1])];
            let kviter = keys.iter().zip(vals.iter());
            let proposal = db.propose(kviter).unwrap();
            proposal.commit().unwrap();
        }

        // Create, insert, close, open, insert
        let db = TestDb::new_with_config(
            DbConfig::builder()
                .use_parallel(UseParallel::Always)
                .build(),
        );
        insert_commit(&db, 1);
        let db = db.reopen();
        insert_commit(&db, 2);
        // Check that the keys are still there after the commits
        let committed = db.revision(db.root_hash().unwrap()).unwrap();
        let keys: Vec<[u8; 1]> = vec![[1; 1], [2; 1]];
        let vals: Vec<Box<[u8]>> = vec![Box::new([1; 1]), Box::new([2; 1])];
        let kviter = keys.iter().zip(vals.iter());
        for (k, v) in kviter {
            assert_eq!(&committed.val(k).unwrap().unwrap(), v);
        }
        drop(db);

        // Open-db1, insert, open-db2, insert
        let db1 = TestDb::new_with_config(
            DbConfig::builder()
                .use_parallel(UseParallel::Always)
                .build(),
        );
        insert_commit(&db1, 1);
        let db2 = TestDb::new_with_config(
            DbConfig::builder()
                .use_parallel(UseParallel::Always)
                .build(),
        );
        insert_commit(&db2, 2);
        let committed1 = db1.revision(db1.root_hash().unwrap()).unwrap();
        let committed2 = db2.revision(db2.root_hash().unwrap()).unwrap();
        let keys: Vec<[u8; 1]> = vec![[1; 1], [2; 1]];
        let vals: Vec<Box<[u8]>> = vec![Box::new([1; 1]), Box::new([2; 1])];
        let mut kviter = keys.iter().zip(vals.iter());
        let (k, v) = kviter.next().unwrap();
        assert_eq!(&committed1.val(k).unwrap().unwrap(), v);
        let (k, v) = kviter.next().unwrap();
        assert_eq!(&committed2.val(k).unwrap().unwrap(), v);
    }

    #[test]
    fn test_propose_parallel() {
        const N: usize = 100;
        let db = TestDb::new_with_config(
            DbConfig::builder()
                .use_parallel(UseParallel::Always)
                .build(),
        );

        // Test an empty proposal
        let keys: Vec<[u8; 0]> = Vec::new();
        let vals: Vec<Box<[u8]>> = Vec::new();

        let kviter = keys.iter().zip(vals.iter());
        let proposal = db.propose(kviter).unwrap();
        proposal.commit().unwrap();

        // Create a proposal consisting of a single entry and an empty key.
        let keys: Vec<[u8; 0]> = vec![[0; 0]];

        // Note that if the value is [], then it is interpreted as a DeleteRange.
        // Instead, set value to [0]
        let vals: Vec<Box<[u8]>> = vec![Box::new([0; 1])];

        let kviter = keys.iter().zip(vals.iter());
        let proposal = db.propose(kviter).unwrap();

        let kviter = keys.iter().zip(vals.iter());
        for (k, v) in kviter {
            assert_eq!(&proposal.val(k).unwrap().unwrap(), v);
        }
        proposal.commit().unwrap();

        // Check that the key is still there after the commit
        let committed = db.revision(db.root_hash().unwrap()).unwrap();
        let kviter = keys.iter().zip(vals.iter());
        for (k, v) in kviter {
            assert_eq!(&committed.val(k).unwrap().unwrap(), v);
        }

        // Create a proposal that deletes the previous entry
        let vals: Vec<Box<[u8]>> = vec![Box::new([0; 0])];
        let kviter = keys.iter().zip(vals.iter());
        let proposal = db.propose(kviter).unwrap();

        let kviter = keys.iter().zip(vals.iter());
        for (k, _v) in kviter {
            assert_eq!(proposal.val(k).unwrap(), None);
        }
        proposal.commit().unwrap();

        // Create a proposal that inserts 0 to 999
        let (keys, vals): (Vec<_>, Vec<_>) = (0..1000)
            .map(|i| {
                (
                    format!("key{i}").into_bytes(),
                    Box::from(format!("value{i}").as_bytes()),
                )
            })
            .unzip();

        let kviter = keys.iter().zip(vals.iter());
        let proposal = db.propose(kviter).unwrap();
        let kviter = keys.iter().zip(vals.iter());
        for (k, v) in kviter {
            assert_eq!(&proposal.val(k).unwrap().unwrap(), v);
        }
        proposal.commit().unwrap();

        // Create a proposal that deletes all of the even entries
        let (keys, vals): (Vec<_>, Vec<_>) = (0..1000)
            .filter_map(|i| {
                if i % 2 != 0 {
                    Some::<(Vec<u8>, Box<[u8]>)>((format!("key{i}").into_bytes(), Box::new([])))
                } else {
                    None
                }
            })
            .unzip();

        let kviter = keys.iter().zip(vals.iter());
        let proposal = db.propose(kviter).unwrap();
        let kviter = keys.iter().zip(vals.iter());
        for (k, _v) in kviter {
            assert_eq!(proposal.val(k).unwrap(), None);
        }
        proposal.commit().unwrap();

        // Create a proposal that deletes using empty prefix
        let keys: Vec<[u8; 0]> = vec![[0; 0]];
        let vals: Vec<Box<[u8]>> = vec![Box::new([0; 0])];
        let kviter = keys.iter().zip(vals.iter());
        let proposal = db.propose(kviter).unwrap();
        proposal.commit().unwrap();

        // Create N keys and values like (key0, value0)..(keyN, valueN)
        let rng = firewood_storage::SeededRng::from_env_or_random();
        let (keys, vals): (Vec<_>, Vec<_>) = (0..N)
            .map(|i| {
                (
                    rng.random::<[u8; 32]>(),
                    Box::from(format!("value{i}").as_bytes()),
                )
            })
            .unzip();

        // Looping twice to test that we are reusing the thread pool.
        for _ in 0..2 {
            let kviter = keys.iter().zip(vals.iter());
            let proposal = db.propose(kviter).unwrap();

            // iterate over the keys and values again, checking that the values are in the correct proposal
            let kviter = keys.iter().zip(vals.iter());

            for (k, v) in kviter {
                assert_eq!(&proposal.val(k).unwrap().unwrap(), v);
            }
            proposal.commit().unwrap();
        }
    }

    #[test]
    fn test_propose_parallel_vs_normal_propose() {
        fn persisted_deleted(nodes: &[MaybePersistedNode]) -> Vec<LinearAddress> {
            let mut addresses: Vec<_> = nodes
                .iter()
                .filter_map(MaybePersistedNode::as_linear_address)
                .collect();
            addresses.sort();
            addresses
        }

        let parallel_db = TestDb::new_with_config(
            DbConfig::builder()
                .use_parallel(UseParallel::Always)
                .build(),
        );
        let single_threaded_db =
            TestDb::new_with_config(DbConfig::builder().use_parallel(UseParallel::Never).build());

        // First batch: insert two keys with different first nibbles so they are
        // handled by different workers in the parallel merkle implementation.
        let initial_keys: Vec<[u8; 1]> = vec![[0x00], [0x10]];
        let initial_values: Vec<Box<[u8]>> = vec![Box::new([1u8]), Box::new([2u8])];

        let initial_parallel_proposal = parallel_db
            .propose(initial_keys.iter().zip(initial_values.iter()))
            .unwrap();
        let initial_single_proposal = single_threaded_db
            .propose(initial_keys.iter().zip(initial_values.iter()))
            .unwrap();

        initial_parallel_proposal.commit().unwrap();
        initial_single_proposal.commit().unwrap();

        // Second batch: update only the first key.
        let update_keys: Vec<[u8; 1]> = vec![[0x00]];
        let update_values: Vec<Box<[u8]>> = vec![Box::new([3u8])];

        let update_parallel_proposal = parallel_db
            .propose(update_keys.iter().zip(update_values.iter()))
            .unwrap();
        let update_single_proposal = single_threaded_db
            .propose(update_keys.iter().zip(update_values.iter()))
            .unwrap();

        // Wait for background persistence to complete before creating update proposals
        // so both DBs are in the same persisted state
        parallel_db.wait_persisted();
        single_threaded_db.wait_persisted();

        let parallel_deleted = update_parallel_proposal.nodestore.deleted().to_vec();
        let single_deleted = update_single_proposal.nodestore.deleted().to_vec();

        assert_eq!(
            persisted_deleted(&parallel_deleted),
            persisted_deleted(&single_deleted),
            "persisted deleted nodes should match between parallel and single proposals",
        );

        update_parallel_proposal.commit().unwrap();
        update_single_proposal.commit().unwrap();
    }

    /// Test that `DeleteRange` with an empty prefix correctly clears all subtries
    /// in the parallel merkle implementation, even those without existing workers.
    ///
    /// Workers are created lazily — only when a prior operation in the same batch
    /// targets a subtrie's first nibble. `remove_all_entries` (triggered by
    /// `DeleteRange { prefix: &[] }`) only sends the delete to existing workers,
    /// so children in subtries that were never touched by prior operations in the
    /// batch may survive incorrectly.
    #[test]
    fn test_parallel_delete_range_empty_prefix_with_existing_workers() {
        let parallel_db = TestDb::new_with_config(
            DbConfig::builder()
                .use_parallel(UseParallel::Always)
                .build(),
        );
        let single_db =
            TestDb::new_with_config(DbConfig::builder().use_parallel(UseParallel::Never).build());

        // Insert keys in different subtries (different first nibbles)
        let setup_keys: Vec<[u8; 1]> = vec![[0x00], [0x10], [0x20]];
        let setup_vals: Vec<Box<[u8]>> = vec![Box::new([1]), Box::new([2]), Box::new([3])];

        for db in [&parallel_db, &single_db] {
            let proposal = db
                .propose(setup_keys.iter().zip(setup_vals.iter()))
                .unwrap();
            proposal.commit().unwrap();
        }

        // Batch: update a key in the 0x0 subtrie, then DeleteRange with empty prefix.
        // This ensures only the 0x0 worker exists when remove_all_entries runs.
        let batch: Vec<BatchOp<Vec<u8>, Vec<u8>>> = vec![
            BatchOp::Put {
                key: vec![0x00],
                value: vec![99],
            },
            BatchOp::DeleteRange { prefix: vec![] },
        ];

        for db in [&parallel_db, &single_db] {
            let proposal = db.propose(batch.iter()).unwrap();
            proposal.commit().unwrap();
        }

        // All keys should be deleted in both implementations.
        // When the trie is completely empty, root_hash() may return None (e.g. without
        // the ethhash feature). In that case, the trie is empty and all keys are deleted.
        assert_eq!(
            parallel_db.root_hash(),
            single_db.root_hash(),
            "root hashes should match after delete-all"
        );
        if let Some(root_hash) = parallel_db.root_hash() {
            let parallel_rev = parallel_db.revision(root_hash).unwrap();
            let single_rev = single_db.revision(single_db.root_hash().unwrap()).unwrap();

            for key in &setup_keys {
                let parallel_val = parallel_rev.val(key).unwrap();
                let single_val = single_rev.val(key).unwrap();
                assert_eq!(
                    parallel_val, single_val,
                    "mismatch for key {key:?}: parallel={parallel_val:?}, single={single_val:?}"
                );
                assert_eq!(single_val, None, "key {key:?} should be deleted");
            }
        }
    }

    /// Test that proposing on a proposal works as expected
    ///
    /// Test creates two batches and proposes them, and verifies that the values are in the correct proposal.
    /// It then commits them one by one, and verifies the latest committed version is correct.
    #[test]
    fn test_propose_on_proposal() {
        // number of keys and values to create for this test
        const N: usize = 20;

        let db = TestDb::new();

        // create N keys and values like (key0, value0)..(keyN, valueN)
        let (keys, vals): (Vec<_>, Vec<_>) = (0..N)
            .map(|i| {
                (
                    format!("key{i}").into_bytes(),
                    Box::from(format!("value{i}").as_bytes()),
                )
            })
            .unzip();

        // create two batches, one with the first half of keys and values, and one with the last half keys and values
        let mut kviter = keys.iter().zip(vals.iter());

        // create two proposals, second one has a base of the first one
        let proposal1 = db.propose(kviter.by_ref().take(N / 2)).unwrap();
        let proposal2 = proposal1.propose(kviter).unwrap();

        // iterate over the keys and values again, checking that the values are in the correct proposal
        let mut kviter = keys.iter().zip(vals.iter());

        // first half of the keys should be in both proposals
        for (k, v) in kviter.by_ref().take(N / 2) {
            assert_eq!(&proposal1.val(k).unwrap().unwrap(), v);
            assert_eq!(&proposal2.val(k).unwrap().unwrap(), v);
        }

        // remaining keys should only be in the second proposal
        for (k, v) in kviter {
            // second half of keys are in the second proposal
            assert_eq!(&proposal2.val(k).unwrap().unwrap(), v);
            // but not in the first
            assert_eq!(proposal1.val(k).unwrap(), None);
        }

        proposal1.commit().unwrap();

        // all keys are still in the second proposal (first is no longer accessible)
        for (k, v) in keys.iter().zip(vals.iter()) {
            assert_eq!(&proposal2.val(k).unwrap().unwrap(), v);
        }

        // commit the second proposal
        proposal2.commit().unwrap();

        // all keys are in the database
        let committed = db.root_hash().unwrap();
        let revision = db.revision(committed).unwrap();

        for (k, v) in keys.into_iter().zip(vals) {
            assert_eq!(revision.val(k).unwrap().unwrap(), v);
        }
    }

    #[test]
    fn test_slow_fuzz_checker() {
        let rng = firewood_storage::SeededRng::from_env_or_random();

        let db = TestDb::new();

        // takes about 0.3s on a mac to run 50 times
        for _ in 0..50 {
            // create a batch of 10 random key-value pairs
            let batch = (0..10).fold(vec![], |mut batch, _| {
                let key: [u8; 32] = rng.random();
                let value: [u8; 8] = rng.random();
                batch.push(BatchOp::Put {
                    key: key.to_vec(),
                    value,
                });
                if rng.random_range(0..5) == 0 {
                    let addon: [u8; 32] = rng.random();
                    let key = [key, addon].concat();
                    let value: [u8; 8] = rng.random();
                    batch.push(BatchOp::Put { key, value });
                }
                batch
            });
            let proposal = db.propose(batch).unwrap();
            proposal.commit().unwrap();

            // Wait for background persistence to complete before checking consistency
            db.wait_persisted();

            // check the database for consistency, sometimes checking the hashes
            let hash_check = rng.random();
            let report = db.check(CheckOpt {
                hash_check,
                progress_bar: None,
            });
            if report
                .errors
                .iter()
                .filter(|e| !matches!(e, CheckerError::AreaLeaks(_)))
                .count()
                != 0
            {
                db.dump(&mut std::io::stdout()).unwrap();
                panic!("error: {:?}", report.errors);
            }
        }
    }

    #[test]
    fn test_deep_propose() {
        const NUM_KEYS: NonZeroUsize = const { NonZeroUsize::new(2).unwrap() };
        const NUM_PROPOSALS: usize = 100;

        let db = TestDb::new();

        let ops = (0..(NUM_KEYS.get() * NUM_PROPOSALS))
            .map(|i| (format!("key{i}"), format!("value{i}")))
            .collect::<Vec<_>>();

        let proposals = ops.iter().chunk_fold(
            NUM_KEYS,
            Vec::<Proposal<'_, DefaultHashMode>>::with_capacity(NUM_PROPOSALS),
            |mut proposals, ops| {
                let proposal = if let Some(parent) = proposals.last() {
                    parent.propose(ops).unwrap()
                } else {
                    db.propose(ops).unwrap()
                };

                proposals.push(proposal);
                proposals
            },
        );

        let last_proposal_root_hash = proposals.last().unwrap().root_hash().unwrap();

        // commit the proposals
        for proposal in proposals {
            proposal.commit().unwrap();
        }

        // get the last committed revision
        let last_root_hash = db.root_hash().unwrap();
        let committed = db.revision(last_root_hash.clone()).unwrap();

        // the last root hash should be the same as the last proposal root hash
        assert_eq!(last_root_hash, last_proposal_root_hash);

        // check that all the keys and values are still present
        for (k, v) in &ops {
            let found = committed.val(k).unwrap();
            assert_eq!(
                found.as_deref(),
                Some(v.as_bytes()),
                "Value for key {k:?} should be {v:?} but was {found:?}",
            );
        }
    }

    /// Test that reading from a proposal during commit works as expected
    #[test]
    fn test_slow_read_during_commit() {
        use crate::db::Proposal;

        const CHANNEL_CAPACITY: usize = 8;

        let testdb = TestDb::new();
        let db = &*testdb;

        let (tx, rx) =
            std::sync::mpsc::sync_channel::<Proposal<'_, DefaultHashMode>>(CHANNEL_CAPACITY);
        let (result_tx, result_rx) = std::sync::mpsc::sync_channel(CHANNEL_CAPACITY);

        // scope will block until all scope-spawned threads finish
        std::thread::scope(|scope| {
            // Commit task
            scope.spawn(move || {
                while let Ok(proposal) = rx.recv() {
                    let result = proposal.commit();
                    // send result back to the main thread, both for synchronization and stopping the
                    // test on error
                    result_tx.send(result).unwrap();
                }
            });
            scope.spawn(move || {
                // Proposal creation
                for id in 0u32..500 {
                    // insert a key of length 32 and a value of length 8,
                    // rotating between all zeroes through all 255
                    let batch = vec![BatchOp::Put {
                        key: [id as u8; 32],
                        value: [id as u8; 8],
                    }];
                    let proposal = db.propose(batch).unwrap();
                    let last_hash = proposal.root_hash().unwrap();
                    let view = db.view(last_hash).unwrap();

                    tx.send(proposal).unwrap();

                    let key = [id as u8; 32];
                    let value = view.val(&key).unwrap().unwrap();
                    assert_eq!(&*value, &[id as u8; 8]);
                    result_rx.recv().unwrap().unwrap();
                }
                // close the channel, which will cause the commit task to exit
                drop(tx);
            });
        });
    }

    /// Verifies that after reopening the database, an older revision can still
    /// be retrieved via the root store.
    #[test]
    fn test_resurrect_unpersisted_root() {
        let db = TestDb::new_with_config(DbConfig::builder().root_store(true).build());

        // First, create a revision to retrieve
        let key = b"key";
        let value = b"value";
        let batch = vec![BatchOp::Put { key, value }];

        let proposal = db.propose(batch).unwrap();
        let root_hash = proposal.root_hash().unwrap();
        proposal.commit().unwrap();

        // Next, overwrite the kv-pair with a new revision
        let new_value = b"new_value";
        let batch = vec![BatchOp::Put {
            key,
            value: new_value,
        }];

        let proposal = db.propose(batch).unwrap();
        proposal.commit().unwrap();

        // Reopen the database and make sure that we can retrieve the first revision
        let db = db.reopen();

        let latest_root_hash = db.root_hash().unwrap();
        let latest_revision = db.revision(latest_root_hash).unwrap();

        let latest_value = latest_revision.val(key).unwrap().unwrap();
        assert_eq!(new_value, latest_value.as_ref());

        // Retrieve the old revision via root store
        let old_revision = db.revision(root_hash).unwrap();
        let retrieved_value = old_revision.val(key).unwrap().unwrap();
        assert_eq!(value, retrieved_value.as_ref());
    }

    /// Verifies that persisted revisions are still accessible when reopening the database.
    #[test]
    fn test_root_store() {
        let db = TestDb::new_with_config(DbConfig::builder().root_store(true).build());

        // First, create a revision to retrieve
        let key = b"key";
        let value = b"value";
        let batch = vec![BatchOp::Put { key, value }];

        let proposal = db.propose(batch).unwrap();
        let root_hash = proposal.root_hash().unwrap();
        proposal.commit().unwrap();

        // Next, overwrite the kv-pair with a new revision
        let new_value = b"new_value";
        let batch = vec![BatchOp::Put {
            key,
            value: new_value,
        }];

        let proposal = db.propose(batch).unwrap();
        proposal.commit().unwrap();

        // Reopen the database and verify that the database can access a persisted revision
        let db = db.reopen();

        let view = db.view(root_hash).unwrap();
        let retrieved_value = view.val(key).unwrap().unwrap();
        assert_eq!(value, retrieved_value.as_ref());
    }

    /// Verifies that proposals skip building the future-delete log when
    /// archival mode is enabled, since it is never consumed.
    #[test]
    fn test_no_fdl_when_root_store_enabled() {
        let db = TestDb::new_with_config(DbConfig::builder().root_store(true).build());

        let key = b"key";
        let batch = vec![BatchOp::Put {
            key,
            value: b"value",
        }];
        db.propose(batch).unwrap().commit().unwrap();

        // Overwriting the key puts the existing node on the future-delete log.
        let batch = vec![BatchOp::Put {
            key,
            value: b"new_value",
        }];
        db.propose(batch).unwrap().commit().unwrap();

        assert_eq!(
            db.manager.current_revision().deleted_len(),
            0,
            "future-delete log should not be built in archival mode"
        );
    }

    /// Verifies that proposals build the future-delete log if archival mode is disabled.
    #[test]
    fn test_fdl_tracked_when_root_store_disabled() {
        let db = TestDb::new_with_config(DbConfig::builder().root_store(false).build());

        let key = b"key";
        let batch = vec![BatchOp::Put {
            key,
            value: b"value",
        }];
        db.propose(batch).unwrap().commit().unwrap();

        let batch = vec![BatchOp::Put {
            key,
            value: b"new_value",
        }];
        db.propose(batch).unwrap().commit().unwrap();

        assert!(
            db.manager.current_revision().deleted_len() > 0,
            "future-delete log should record replaced nodes when archival mode is disabled"
        );
    }

    #[test]
    fn test_rootstore_empty_db_reopen() {
        let db = TestDb::new_with_config(DbConfig::builder().root_store(true).build());

        db.reopen();
    }

    /// Verifies that revisions exceeding the in-memory limit can still be retrieved.
    #[test]
    fn test_root_store_with_capped_max_revisions() {
        const NUM_REVISIONS: usize = 10;

        let dbconfig = DbConfig::builder()
            .manager(RevisionManagerConfig::builder().max_revisions(5).build())
            .root_store(true)
            .build();
        let db = TestDb::new_with_config(dbconfig);

        // Create and commit 10 proposals
        let key = b"root_store";
        let revisions: HashMap<TrieHash, _> = (0..NUM_REVISIONS)
            .map(|i| {
                let value = i.to_be_bytes();
                let batch = vec![BatchOp::Put { key, value }];
                let proposal = db.propose(batch).unwrap();
                let root_hash = proposal.root_hash().unwrap();
                proposal.commit().unwrap();

                (root_hash, value)
            })
            .collect();

        // Verify that we can access all revisions with their correct values
        for (root_hash, value) in &revisions {
            let revision = db.revision(root_hash.clone()).unwrap();
            let retrieved_value = revision.val(key).unwrap().unwrap();
            assert_eq!(value.as_slice(), retrieved_value.as_ref());
        }

        let db = db.reopen();

        // Verify that we can access all revisions with their correct values
        // after reopening
        for (root_hash, value) in &revisions {
            let revision = db.revision(root_hash.clone()).unwrap();
            let retrieved_value = revision.val(key).unwrap().unwrap();
            assert_eq!(value.as_slice(), retrieved_value.as_ref());
        }
    }

    /// Verifies that `RootStore` is truncated as well if we truncate the database.
    #[test]
    fn test_root_store_truncation() {
        let db =
            TestDb::new_with_config(DbConfig::builder().root_store(true).truncate(true).build());

        // Create a revision to store
        let batch = vec![BatchOp::Put {
            key: b"foo",
            value: b"bar",
        }];
        let proposal = db.propose(batch).unwrap();
        let root_hash = proposal.root_hash().unwrap();
        proposal.commit().unwrap();

        let db = db.reopen();
        assert!(db.view(root_hash).is_err());
    }

    /// Verifies that opening a database fails if the directory doesn't exist.
    #[test]
    fn test_nonexistent_directory() {
        let tmpdir = tempfile::tempdir().unwrap();

        assert!(
            Db::<DefaultHashMode>::new_with_hash_mode(
                tmpdir,
                DbConfig::builder()
                    .node_hash_algorithm(DefaultHashMode::ALGORITHM)
                    .create_if_missing(false)
                    .build(),
            )
            .is_err()
        );
    }

    #[test]
    fn test_new_rejects_hash_mode_mismatch() {
        let tmpdir = tempfile::tempdir().unwrap();
        let configured_algorithm = match DefaultHashMode::ALGORITHM {
            NodeHashAlgorithm::MerkleDB => NodeHashAlgorithm::Ethereum,
            NodeHashAlgorithm::Ethereum => NodeHashAlgorithm::MerkleDB,
        };
        let config = DbConfig::builder()
            .node_hash_algorithm(configured_algorithm)
            .build();

        let error = Db::<DefaultHashMode>::new_with_hash_mode(tmpdir.path(), config).unwrap_err();
        assert!(matches!(
            error,
            api::Error::HashModeMismatch {
                expected: DefaultHashMode::ALGORITHM,
                found,
            } if found == configured_algorithm
        ));
    }

    #[test]
    fn test_backwards_compatible_magic_string() {
        use std::os::unix::fs::FileExt;

        let testdb = TestDb::new();

        testdb
            .propose([(b"key", b"value")])
            .unwrap()
            .commit()
            .unwrap();

        // Wait for background persistence to complete before reading the file
        testdb.wait_persisted();

        let rh = testdb.root_hash().unwrap();

        let file = std::fs::OpenOptions::new()
            .read(true)
            .write(true)
            .append(false)
            .truncate(false)
            .open(testdb.path().join(crate::manager::DB_FILE_NAME))
            .unwrap();

        let mut version = [0_u8; 16];
        file.read_exact_at(&mut version, 0).unwrap();
        assert_eq!(&version, b"firewood-v1-hfix");

        // overwrite the magic string to simulate an older version
        file.write_all_at(b"firewood 0.0.18\0", 0).unwrap();
        drop(file);

        let testdb = testdb.reopen();

        assert_eq!(rh, testdb.root_hash().unwrap());
    }

    #[test]
    fn test_deferred_persist_multiple_commits_with_max_persistence_gap_one() {
        const NUM_REVISIONS: usize = 20;

        let dbcfg = DbConfig::builder()
            .manager(
                RevisionManagerConfig::builder()
                    .max_revisions(NUM_REVISIONS)
                    .build(),
            )
            .build();

        let db = TestDb::new_with_config(dbcfg);

        // Create and commit NUM_REVISIONS proposals, storing their root hashes
        let root_hashes: Vec<TrieHash> = (0..NUM_REVISIONS)
            .map(|i| {
                let batch = vec![BatchOp::Put {
                    key: format!("key{i}").as_bytes().to_vec(),
                    value: format!("value{i}").as_bytes().to_vec(),
                }];
                let proposal = db.propose(batch).unwrap();
                let root_hash = proposal.root_hash().unwrap();
                proposal.commit().unwrap();
                root_hash
            })
            .collect();

        // Wait for the background thread to finish persisting
        db.wait_persisted();

        // Verify that all revisions were persisted
        for (i, root_hash) in root_hashes.iter().enumerate() {
            let is_persisted = db
                .manager
                .revision_persist_status(root_hash.clone())
                .unwrap();

            assert!(
                is_persisted,
                "Revision {i} with root hash {root_hash:?} should be persisted"
            );
        }
    }

    #[test]
    fn test_deferred_persist_close_with_max_persistence_gap_one() {
        let dbcfg = DbConfig::builder().build();

        let db = TestDb::new_with_config(dbcfg);

        // Then, commit once and see what the latest revision is
        let key = b"foo";
        let value = b"bar";
        let batch = vec![BatchOp::Put { key, value }];
        let proposal = db.propose(batch).unwrap();
        let root_hash = proposal.root_hash().unwrap();

        proposal.commit().unwrap();
        let db = db.reopen();

        let revision = db.view(root_hash).unwrap();
        let new_value = revision.val(b"foo").unwrap().unwrap();

        assert_eq!(value, new_value.as_ref());
    }

    #[test]
    fn test_deferred_persist_close_with_high_max_persistence_gap() {
        const HIGH_MAX_PERSISTENCE_GAP: NonZeroU64 = nonzero!(1_000_000u64);
        const MAX_REVISIONS: usize = HIGH_MAX_PERSISTENCE_GAP.get() as usize + 1;

        // Set the persistence gap limit high enough so persistence happens
        // only on shutdown
        let dbcfg = DbConfig::builder()
            .manager(
                RevisionManagerConfig::builder()
                    .max_revisions(MAX_REVISIONS)
                    .max_persistence_gap(HIGH_MAX_PERSISTENCE_GAP)
                    .build(),
            )
            .build();

        let db = TestDb::new_with_config(dbcfg);

        // Then, commit once and see what the latest revision is
        let key = b"foo";
        let value = b"bar";
        let batch = vec![BatchOp::Put { key, value }];
        let proposal = db.propose(batch).unwrap();
        let root_hash = proposal.root_hash().unwrap();

        proposal.commit().unwrap();
        let db = db.reopen();

        let revision = db.view(root_hash).unwrap();
        let new_value = revision.val(b"foo").unwrap().unwrap();

        assert_eq!(value, new_value.as_ref());
    }

    #[test]
    fn test_persisted_state_within_max_persistence_gap() {
        const MAX_PERSISTENCE_GAP: NonZeroU64 = nonzero!(5u64);
        const NUM_REVISIONS: u64 = MAX_PERSISTENCE_GAP.get() + 1;

        let dbcfg = DbConfig::builder()
            .manager(
                RevisionManagerConfig::builder()
                    .max_persistence_gap(MAX_PERSISTENCE_GAP)
                    .build(),
            )
            .build();

        let db = TestDb::new_with_config(dbcfg);

        let mut root_hashes = Vec::new();

        for i in 0..NUM_REVISIONS {
            let batch = vec![BatchOp::Put {
                key: format!("key{i}").as_bytes().to_vec(),
                value: format!("value{i}").as_bytes().to_vec(),
            }];
            let proposal = db.propose(batch).unwrap();
            root_hashes.push(proposal.root_hash().unwrap());
            proposal.commit().unwrap();
        }

        // Going back at most MAX_PERSISTENCE_GAP revisions includes the current state.
        let max_persistence_gap = MAX_PERSISTENCE_GAP.get() as usize;
        let any_persisted = root_hashes
            .iter()
            .rev()
            .take(max_persistence_gap.saturating_add(1))
            .any(|hash| db.manager.revision_persist_status(hash.clone()).unwrap());

        assert!(
            any_persisted,
            "A persisted state should be at most {MAX_PERSISTENCE_GAP} revisions behind"
        );
    }

    /// Verifies that an unpersisted revision which wipes the database is
    /// persisted when the database closes.
    #[test]
    fn test_deferred_persistence_closing_on_empty_trie() {
        const MAX_PERSISTENCE_GAP: NonZeroU64 = nonzero!(10u64);

        let dbcfg = DbConfig::builder()
            .manager(
                RevisionManagerConfig::builder()
                    .max_persistence_gap(MAX_PERSISTENCE_GAP)
                    .build(),
            )
            .build();

        let db = TestDb::new_with_config(dbcfg);

        // Reach the gap limit before committing the empty state below.
        for i in 0..MAX_PERSISTENCE_GAP.get() {
            let batch = vec![BatchOp::Put {
                key: format!("key{i}").as_bytes().to_vec(),
                value: format!("value{i}").as_bytes().to_vec(),
            }];
            let proposal = db.propose(batch).unwrap();
            proposal.commit().unwrap();
        }

        // Empty the trie
        let batch: Vec<BatchOp<Vec<u8>, Vec<u8>>> = vec![BatchOp::DeleteRange { prefix: vec![] }];
        let proposal = db.propose(batch).unwrap();
        proposal.commit().unwrap();

        let db = db.reopen();

        // Verify that the latest committed revision is empty.
        let last_committed_hash = db.root_hash();
        assert_eq!(last_committed_hash, TrieHash::default_root_hash());
    }

    #[test]
    fn test_deferred_persistence_root_store() {
        const NUM_COMMITS: usize = 20;
        const MAX_PERSISTENCE_GAP: NonZeroU64 = nonzero!(10u64);
        const MAX_REVISIONS: usize = MAX_PERSISTENCE_GAP.get() as usize + 1;

        let dbcfg = DbConfig::builder()
            .manager(
                RevisionManagerConfig::builder()
                    .max_revisions(MAX_REVISIONS)
                    .max_persistence_gap(MAX_PERSISTENCE_GAP)
                    .build(),
            )
            .root_store(true)
            .build();

        let db = TestDb::new_with_config(dbcfg);

        let mut root_hashes = Vec::new();

        let key = b"key";
        for i in 0..NUM_COMMITS {
            let batch = vec![BatchOp::Put {
                key,
                value: format!("{i}").as_bytes().to_vec(),
            }];
            let proposal = db.propose(batch).unwrap();
            root_hashes.push(proposal.root_hash().unwrap());
            proposal.commit().unwrap();
        }

        let db = db.reopen();

        // Verify that we never went more than MAX_PERSISTENCE_GAP revisions without
        // persisting.
        let max_persistence_gap = MAX_PERSISTENCE_GAP.get() as usize;
        let mut last_persisted: Option<usize> = None;

        for (i, hash) in root_hashes.iter().enumerate() {
            let is_persisted = db
                .manager
                .revision_persist_status(hash.clone())
                .is_ok_and(|persisted| persisted);

            if is_persisted {
                let gap = match last_persisted {
                    Some(prev) => i.wrapping_sub(prev),
                    None => i.wrapping_add(1),
                };
                assert!(
                    gap <= max_persistence_gap,
                    "Gap of {gap} between persisted revisions exceeds MAX_PERSISTENCE_GAP of {max_persistence_gap}"
                );
                last_persisted = Some(i);
            }
        }

        assert!(
            last_persisted.is_some(),
            "At least one revision should be persisted"
        );
    }

    /// Verifies that non-persisted revisions are lost after reopening the database.
    #[test]
    fn test_deferred_persistence_unpersisted_revisions() {
        const MAX_PERSISTENCE_GAP: NonZeroU64 = nonzero!(10u64);

        let dbcfg = DbConfig::builder()
            .manager(
                RevisionManagerConfig::builder()
                    .max_persistence_gap(MAX_PERSISTENCE_GAP)
                    .build(),
            )
            .root_store(true)
            .build();

        let db = TestDb::new_with_config(dbcfg);

        let mut root_hashes = Vec::new();

        let key = b"key";
        for i in 0..MAX_PERSISTENCE_GAP.get() {
            let batch = vec![BatchOp::Put {
                key,
                value: format!("{i}").as_bytes().to_vec(),
            }];
            let proposal = db.propose(batch).unwrap();
            root_hashes.push(proposal.root_hash().unwrap());
            proposal.commit().unwrap();
        }

        let db = db.reopen();

        let persisted_count = root_hashes
            .iter()
            .filter(|&hash| {
                db.manager
                    .revision_persist_status(hash.clone())
                    .is_ok_and(|is_persisted| is_persisted)
            })
            .count();

        assert!(
            persisted_count > 0 && persisted_count <= 2,
            "Expected at most 2 persisted revisions, but found {persisted_count}"
        );
    }

    // Testdb is a helper struct for testing the Db. Once it's dropped, the directory and file disappear
    pub(super) struct TestDb {
        db: Option<Db<DefaultHashMode>>,
        tmpdir: tempfile::TempDir,
        dbconfig: DbConfig,
    }
    impl Drop for TestDb {
        fn drop(&mut self) {
            if let Some(db) = self.db.take() {
                db.close().unwrap();
            }
        }
    }
    impl Deref for TestDb {
        type Target = Db<DefaultHashMode>;
        fn deref(&self) -> &Self::Target {
            self.db.as_ref().unwrap()
        }
    }
    impl DerefMut for TestDb {
        fn deref_mut(&mut self) -> &mut Self::Target {
            self.db.as_mut().unwrap()
        }
    }

    impl TestDb {
        pub fn new() -> Self {
            TestDb::new_with_config(
                DbConfig::builder()
                    .node_hash_algorithm(DefaultHashMode::ALGORITHM)
                    .build(),
            )
        }

        pub fn new_with_config(dbconfig: DbConfig) -> Self {
            let tmpdir = tempfile::tempdir().unwrap();
            let db = Db::<DefaultHashMode>::new_with_hash_mode(tmpdir.as_ref(), dbconfig.clone())
                .unwrap();
            TestDb {
                db: Some(db),
                tmpdir,
                dbconfig,
            }
        }

        /// Reopens the database at the same path, preserving existing data.
        ///
        /// This method closes the current database instance (releasing the advisory lock),
        /// then opens it again at the same path while keeping the same configuration.
        pub fn reopen(mut self) -> Self {
            self.db.take().unwrap().close().unwrap();

            let db = Db::<DefaultHashMode>::new_with_hash_mode(
                self.tmpdir.path(),
                self.dbconfig.clone(),
            )
            .unwrap();
            self.db = Some(db);
            self
        }

        /// Replaces the database with a fresh instance at the same path.
        ///
        /// This method closes the current database instance (releasing the advisory lock),
        /// and creates a new database. This completely resets the database, removing all
        /// existing data and starting fresh. The new database instance will use the default
        /// configuration with truncation enabled.
        ///
        /// This is useful for testing scenarios where you want to start with a clean slate
        /// while maintaining the same temporary directory structure.
        pub fn replace(mut self) -> Self {
            self.db.take().unwrap().close().unwrap();

            self.dbconfig = DbConfig::builder()
                .node_hash_algorithm(DefaultHashMode::ALGORITHM)
                .truncate(true)
                .build();
            let db = Db::<DefaultHashMode>::new_with_hash_mode(
                self.tmpdir.path(),
                self.dbconfig.clone(),
            )
            .unwrap();
            self.db = Some(db);
            self
        }

        pub fn path(&self) -> &Path {
            self.tmpdir.path()
        }
    }
}
