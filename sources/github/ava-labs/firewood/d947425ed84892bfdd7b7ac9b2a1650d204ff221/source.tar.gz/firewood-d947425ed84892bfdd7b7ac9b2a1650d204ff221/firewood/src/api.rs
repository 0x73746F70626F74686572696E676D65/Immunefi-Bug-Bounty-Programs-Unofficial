// Copyright (C) 2023, Ava Labs, Inc. All rights reserved.
// See the file LICENSE.md for licensing terms.

use crate::manager::RevisionManagerError;
use crate::merkle::parallel::CreateProposalError;
use crate::merkle::{Key, Value};
use crate::persist_worker::PersistError;
use crate::{Proof, ProofError, ProofNode, RangeProof};
use firewood_storage::{DefaultHashMode, FileIoError, HashMode, NodeHashAlgorithm, TrieHash};
use std::fmt::Debug;
use std::num::NonZeroUsize;
use std::sync::Arc;

pub use crate::batch_op::{BatchIter, BatchOp, IntoBatchIter, KeyValuePair, TryIntoBatch};
use crate::proofs::change::ChangeProof;

/// A `KeyType` is something that can be xcast to a u8 reference,
/// and can be sent and shared across threads. References with
/// lifetimes are not allowed (hence 'static)
pub trait KeyType: AsRef<[u8]> + Debug {}

impl<T> KeyType for T where T: AsRef<[u8]> + Debug {}

/// A `ValueType` is the same as a `KeyType`. However, these could
/// be a different type from the `KeyType` on a given API call.
/// For example, you might insert `{key: "key", value: [0u8]}`
/// This also means that the type of all the keys for a single
/// API call must be the same, as well as the type of all values
/// must be the same.
pub trait ValueType: AsRef<[u8]> + Debug {}

impl<T> ValueType for T where T: AsRef<[u8]> + Debug {}

/// The type and size of a single hash key
/// These are 256-bit hashes that are used for a variety of reasons:
///  - They identify a version of the datastore at a specific point
///    in time
///  - They are used to provide integrity at different points in a
///    proof
pub type HashKey = firewood_storage::TrieHash;

/// An extension trait for the [`HashKey`] type to provide additional methods.
pub trait HashKeyExt: Sized {
    /// Default root hash for an empty database.
    fn default_root_hash() -> Option<HashKey>;
}

/// An extension trait for an optional `HashKey` type to provide additional methods.
pub trait OptionalHashKeyExt: Sized {
    /// Returns the default root hash if the current value is [`None`].
    fn or_default_root_hash(self) -> Option<HashKey>;
}

impl HashKeyExt for HashKey {
    /// Returns the empty-database root hash for the compile-selected mode:
    /// `None` for merkledb, `Some(keccak256(0x80))` for ethhash.
    #[inline]
    fn default_root_hash() -> Option<HashKey> {
        DefaultHashMode::default_root_hash()
    }
}

impl OptionalHashKeyExt for Option<HashKey> {
    #[inline]
    fn or_default_root_hash(self) -> Option<HashKey> {
        self.or_else(HashKey::default_root_hash)
    }
}

/// A frozen proof is a proof that is stored in immutable memory.
pub type FrozenRangeProof = RangeProof<Key, Value, Box<[ProofNode]>>;

pub type FrozenChangeProof = ChangeProof<Key, Value, Box<[ProofNode]>>;

/// A frozen proof uses an immutable collection of proof nodes.
pub type FrozenProof = Proof<Box<[ProofNode]>>;

/// Errors returned through the API
#[derive(thiserror::Error, Debug)]
#[non_exhaustive]
pub enum Error {
    /// A given hash key is not available in the database
    #[error("Revision for {provided:?} not found")]
    RevisionNotFound {
        /// the provided hash key
        provided: Option<HashKey>,
    },

    /// The start hash key is not available in the database
    #[error("Start revision for {provided:?} not found")]
    StartRevisionNotFound {
        /// the provided hash key
        provided: Option<HashKey>,
    },

    /// The end hash key is not available in the database
    #[error("End revision for {provided:?} not found")]
    EndRevisionNotFound {
        /// the provided hash key
        provided: Option<HashKey>,
    },

    /// A committed revision does not have an address.
    #[error("Revision for {provided:?} has no address")]
    RevisionWithoutAddress { provided: HashKey },

    /// Incorrect root hash for commit
    #[error(
        "The proposal cannot be committed since it is not a direct child of the most recent commit. Proposal parent: {provided:?}, current root: {expected:?}"
    )]
    ParentNotLatest {
        /// the provided root hash
        provided: Option<HashKey>,
        /// the expected root hash
        expected: Option<HashKey>,
    },

    /// Invalid range
    #[error("Invalid range: {start_key:?} > {end_key:?}")]
    InvalidRange {
        /// The provided starting key
        start_key: Key,
        /// The provided ending key
        end_key: Key,
    },

    #[error("IO error: {0}")]
    /// An IO error occurred
    IO(#[from] std::io::Error),

    #[error("File IO error: {0}")]
    /// A file I/O error occurred
    FileIO(#[from] FileIoError),

    #[error("RootStore error: {0}")]
    /// A `RootStore` error occurred
    RootStoreError(#[source] Box<dyn std::error::Error + Send + Sync>),

    #[error("Deferred persistence error: {0}")]
    DeferredPersistenceError(#[source] PersistError),

    /// Cannot commit a committed proposal
    #[error("Cannot commit a committed proposal")]
    AlreadyCommitted,

    /// Internal error
    #[error("Internal error")]
    InternalError(Box<dyn std::error::Error + Send + Sync>),

    /// Cannot rebase a proposal whose parent is not a committed revision
    #[error("cannot rebase: proposal parent is not committed")]
    ParentNotCommitted,

    /// Range too small
    #[error("Range too small")]
    RangeTooSmall,

    /// Request `RangeProof` for empty trie
    #[error("request RangeProof for empty trie")]
    RangeProofOnEmptyTrie,

    /// The smallest possible sized-proof chunk (one entry, or the edge proofs
    /// alone) serializes past the requested wire budget.
    #[error("smallest proof chunk is {wire} bytes, over the {budget}-byte budget")]
    ProofOverBudget {
        /// Serialized size of the chunk.
        wire: usize,
        /// The requested budget.
        budget: usize,
    },

    /// Request `RangeProof` for empty range
    #[error("the latest revision is empty and has no root hash")]
    LatestIsEmpty,

    /// Sibling already committed
    #[error("sibling already committed")]
    SiblingCommitted,

    /// Proof error
    #[error("proof error: {0}")]
    ProofError(#[from] ProofError),

    /// An invalid root hash was provided
    #[error(transparent)]
    InvalidRootHash(#[from] firewood_storage::InvalidTrieHashLength),

    // Error sending to worker
    #[error("send error to worker")]
    SendErrorToWorker,

    // Error converting a u8 index into a path component
    #[error("error converting a u8 index into a path component")]
    InvalidConversionToPathComponent,

    // Feature not supported in this build
    #[error("feature not supported in this build: {0}")]
    FeatureNotSupported(String),

    #[error("max_persistence_gap must be positive")]
    ZeroMaxPersistenceGap,

    #[error(
        "max_revisions ({max_revisions}) must be > max_persistence_gap ({max_persistence_gap})"
    )]
    InsufficientRevisions {
        max_revisions: usize,
        max_persistence_gap: u64,
    },

    #[error(
        "node hash algorithm mismatch: hash mode expects {expected:?}, config specifies {found:?}"
    )]
    HashModeMismatch {
        expected: NodeHashAlgorithm,
        found: NodeHashAlgorithm,
    },
}

impl From<std::convert::Infallible> for Error {
    fn from(value: std::convert::Infallible) -> Self {
        match value {}
    }
}

impl From<RevisionManagerError> for Error {
    fn from(err: RevisionManagerError) -> Self {
        use RevisionManagerError::{
            FileIoError, IOError, InsufficientRevisions, NotLatest, PersistError, RevisionNotFound,
            RevisionWithoutAddress, RootStoreError,
        };
        match err {
            NotLatest { provided, expected } => Self::ParentNotLatest { provided, expected },
            RevisionNotFound { provided } => Self::RevisionNotFound {
                provided: Some(provided),
            },
            RevisionWithoutAddress { provided } => Self::RevisionWithoutAddress { provided },
            FileIoError(io_err) => Self::FileIO(io_err),
            IOError(err) => Self::IO(err),
            RootStoreError(err) => Self::RootStoreError(err),
            PersistError(err) => Self::DeferredPersistenceError(err),
            InsufficientRevisions {
                max_revisions,
                max_persistence_gap,
            } => Self::InsufficientRevisions {
                max_revisions,
                max_persistence_gap,
            },
        }
    }
}

impl From<crate::db::DbError> for Error {
    fn from(value: crate::db::DbError) -> Self {
        match value {
            crate::db::DbError::FileIo(err) => Error::FileIO(err),
        }
    }
}

impl From<CreateProposalError> for Error {
    fn from(value: CreateProposalError) -> Self {
        match value {
            CreateProposalError::FileIoError(err) => Error::FileIO(err),
            CreateProposalError::SendError => Error::SendErrorToWorker,
            CreateProposalError::InvalidConversionToPathComponent => {
                Error::InvalidConversionToPathComponent
            }
        }
    }
}

/// The database interface. The methods here operate on the most
/// recently committed revision, and allow the creation of a new
/// [`Proposal`] or a new [`DbView`] based on a specific historical
/// revision.
pub trait Db {
    /// The type of a historical revision
    type Historical: DbView;

    /// The type of a proposal
    type Proposal<'db>: DbView + Proposal
    where
        Self: 'db;

    /// The node-hashing scheme this database uses.
    fn node_hash_algorithm(&self) -> NodeHashAlgorithm;

    /// Get a reference to a specific view based on a hash
    ///
    /// # Arguments
    ///
    /// - `hash` - Identifies the revision for the view
    #[expect(clippy::missing_errors_doc)]
    fn revision(&self, hash: TrieHash) -> Result<Arc<Self::Historical>, Error>;

    /// Get the hash of the most recently committed version
    ///
    /// # Note
    ///
    /// If the database is empty, this will return None, unless the ethhash feature is enabled.
    /// In that case, we return the special ethhash compatible empty trie hash.
    fn root_hash(&self) -> Option<TrieHash>;

    /// Propose a change to the database via a batch
    ///
    /// This proposal assumes it is based off the most recently
    /// committed transaction
    ///
    /// # Arguments
    ///
    /// * `data` - A batch consisting of [`BatchOp::Put`] and [`BatchOp::Delete`]
    ///   operations to apply
    #[expect(clippy::missing_errors_doc)]
    fn propose(&self, data: impl IntoBatchIter) -> Result<Self::Proposal<'_>, Error>;

    /// Apply a batch to the latest revision, commit it, and return the committed root hash.
    ///
    /// This is a convenience method for the common one-shot write path. It returns the
    /// proposal's root hash instead of reading [`Db::root_hash`] after commit, so callers
    /// receive the root for the revision this method committed.
    #[expect(clippy::missing_errors_doc)]
    fn update(&self, data: impl IntoBatchIter) -> Result<Option<HashKey>, Error> {
        let proposal = self.propose(data)?;
        let root_hash = DbView::root_hash(&proposal);
        proposal.commit()?;
        Ok(root_hash)
    }
}

/// A view of the database at a specific time.
///
/// There are a few ways to create a [`DbView`]:
/// 1. From [`Db::revision`] which gives you a view for a specific
///    historical revision
/// 2. From [`Db::propose`] which is a view on top of the most recently
///    committed revision with changes applied; or
/// 3. From [`Proposal::propose`] which is a view on top of another proposal; or
/// 4. From [`Reconstructible::reconstruct`] which is a view of a
///    reconstructed revision.
pub trait DbView {
    /// The type of a stream of key/value pairs
    type Iter<'view>: Iterator<Item = Result<(Key, Value), FileIoError>>
    where
        Self: 'view;

    /// The node-hashing scheme the view's backing database was created with.
    fn node_hash_algorithm(&self) -> NodeHashAlgorithm;

    /// Get the root hash for the current [`DbView`]
    ///
    /// # Note
    ///
    /// If the database is empty, this will return None, unless the ethhash feature is enabled.
    /// In that case, we return the special ethhash compatible empty trie hash.
    fn root_hash(&self) -> Option<HashKey>;

    /// Get the value of a specific key
    #[expect(clippy::missing_errors_doc)]
    fn val<K: KeyType>(&self, key: K) -> Result<Option<Value>, Error>;

    /// Obtain a proof for a single key
    #[expect(clippy::missing_errors_doc)]
    fn single_key_proof<K: KeyType>(&self, key: K) -> Result<FrozenProof, Error>;

    /// Obtain a range proof over a set of keys
    ///
    /// # Arguments
    ///
    /// * `first_key` - If None, start at the lowest key
    /// * `last_key` - If None, continue to the end of the database
    /// * `limit` - The maximum number of keys in the range proof
    #[expect(clippy::missing_errors_doc)]
    fn range_proof<K: KeyType>(
        &self,
        first_key: Option<K>,
        last_key: Option<K>,
        limit: Option<NonZeroUsize>,
    ) -> Result<FrozenRangeProof, Error>;

    /// Obtain a stream over the keys/values of this view, using an optional starting point
    ///
    /// # Arguments
    ///
    /// * `first_key` - If None, start at the lowest key
    ///
    /// # Note
    ///
    /// If you always want to start at the beginning, [`DbView::iter`] is easier to use
    /// If you always provide a key, [`DbView::iter_from`] is easier to use
    #[expect(clippy::missing_errors_doc)]
    fn iter_option<K: KeyType>(&self, first_key: Option<K>) -> Result<Self::Iter<'_>, Error>;

    /// Obtain a stream over the keys/values of this view, starting from the beginning
    #[expect(clippy::missing_errors_doc)]
    #[expect(clippy::iter_not_returning_iterator)]
    fn iter(&self) -> Result<Self::Iter<'_>, Error> {
        self.iter_option(Option::<Key>::None)
    }

    /// Obtain a stream over the key/values, starting at a specific key
    #[expect(clippy::missing_errors_doc)]
    fn iter_from<K: KeyType>(&self, first_key: K) -> Result<Self::Iter<'_>, Error> {
        self.iter_option(Some(first_key))
    }

    /// Dump the Trie structure in DOT (Graphviz) format
    ///
    /// # Errors
    ///
    /// Returns an error if the dump operation fails
    fn dump_to_string(&self) -> Result<String, Error>;
}

/// A boxed iterator over key/value pairs.
pub type BoxKeyValueIter<'view> =
    Box<dyn Iterator<Item = Result<(Key, Value), FileIoError>> + 'view>;

/// A dynamic dyspatch version of [`DbView`] that can be shared.
pub type ArcDynDbView = Arc<dyn DynDbView>;

/// A dyn-safe version of [`DbView`].
pub trait DynDbView: Debug + Send + Sync + 'static {
    /// The node-hashing scheme the view's backing database was created with.
    fn node_hash_algorithm(&self) -> NodeHashAlgorithm;

    /// Get the root hash for the current [`DynDbView`]
    ///
    /// # Note
    ///
    /// If the database is empty, this will return None, unless the ethhash feature is enabled.
    /// In that case, we return the special ethhash compatible empty trie hash.
    fn root_hash(&self) -> Option<HashKey>;

    /// Get the value of a specific key
    #[expect(clippy::missing_errors_doc)]
    fn val(&self, key: &[u8]) -> Result<Option<Value>, Error>;

    /// Obtain a proof for a single key
    #[expect(clippy::missing_errors_doc)]
    fn single_key_proof(&self, key: &[u8]) -> Result<FrozenProof, Error>;

    /// Obtain a range proof over a set of keys
    ///
    /// # Arguments
    ///
    /// * `first_key` - If None, start at the lowest key
    /// * `last_key` - If None, continue to the end of the database
    /// * `limit` - The maximum number of keys in the range proof
    #[expect(clippy::missing_errors_doc)]
    fn range_proof(
        &self,
        first_key: Option<&[u8]>,
        last_key: Option<&[u8]>,
        limit: Option<NonZeroUsize>,
    ) -> Result<FrozenRangeProof, Error>;

    /// Obtain a stream over the keys/values of this view, using an optional starting point
    ///
    /// # Arguments
    ///
    /// * `first_key` - If None, start at the lowest key
    ///
    /// # Note
    ///
    /// If you always want to start at the beginning, [`DbView::iter`] is easier to use
    /// If you always provide a key, [`DbView::iter_from`] is easier to use
    #[expect(clippy::missing_errors_doc)]
    fn iter_option(&self, first_key: Option<&[u8]>) -> Result<BoxKeyValueIter<'_>, Error>;

    /// Obtain a stream over the keys/values of this view, starting from the beginning
    #[expect(clippy::missing_errors_doc)]
    #[expect(clippy::iter_not_returning_iterator)]
    fn iter(&self) -> Result<BoxKeyValueIter<'_>, Error> {
        self.iter_option(None)
    }

    /// Obtain a stream over the key/values, starting at a specific key
    #[expect(clippy::missing_errors_doc)]
    fn iter_from(&self, first_key: &[u8]) -> Result<BoxKeyValueIter<'_>, Error> {
        self.iter_option(Some(first_key))
    }

    /// Dump the Trie structure in DOT (Graphviz) format
    ///
    /// # Errors
    ///
    /// Returns an error if the dump operation fails
    fn dump_to_string(&self) -> Result<String, Error>;
}

impl<T: Debug + DbView + Send + Sync + 'static> DynDbView for T
where
    for<'view> T::Iter<'view>: Sized,
{
    fn node_hash_algorithm(&self) -> NodeHashAlgorithm {
        DbView::node_hash_algorithm(self)
    }

    fn root_hash(&self) -> Option<HashKey> {
        DbView::root_hash(self)
    }

    fn val(&self, key: &[u8]) -> Result<Option<Value>, Error> {
        DbView::val(self, key)
    }

    fn single_key_proof(&self, key: &[u8]) -> Result<FrozenProof, Error> {
        DbView::single_key_proof(self, key)
    }

    fn range_proof(
        &self,
        first_key: Option<&[u8]>,
        last_key: Option<&[u8]>,
        limit: Option<NonZeroUsize>,
    ) -> Result<FrozenRangeProof, Error> {
        DbView::range_proof(self, first_key, last_key, limit)
    }

    fn iter_option(&self, first_key: Option<&[u8]>) -> Result<BoxKeyValueIter<'_>, Error> {
        // NOTE: `Result::map` does not work here because the compiler cannot correctly
        // infer the unsizing operation
        match DbView::iter_option(self, first_key) {
            Ok(iter) => Ok(Box::new(iter)),
            Err(e) => Err(e),
        }
    }

    fn dump_to_string(&self) -> Result<String, Error> {
        DbView::dump_to_string(self)
    }
}

/// A shareable committed revision that can start a reconstruction chain.
///
/// This is the erased capability behind
/// [`CommittedView`](crate::db::CommittedView): the blanket impl in `db.rs`
/// covers the committed nodestore of every hash mode, so reconstruction works
/// regardless of the mode the database was opened with.
pub(crate) trait DynCommittedRevision: DynDbView {
    /// Start a reconstruction chain from this committed revision by applying
    /// `batch`, producing an erased reconstructed state.
    fn begin_reconstruction(
        self: Arc<Self>,
        batch: OwnedBatch,
    ) -> Result<ArcDynReconstructed, Error>;
}

/// A shareable reconstructed state that can continue a reconstruction chain.
///
/// This is the erased capability behind
/// [`ReconstructedView`](crate::db::ReconstructedView); like
/// [`DynCommittedRevision`], its blanket impl in `db.rs` covers every hash
/// mode.
pub(crate) trait DynReconstructed: DynDbView {
    /// Continue the reconstruction chain by applying `batch` on top of this
    /// state.
    ///
    /// Consumes the `Arc` so that a uniquely-held state can move its in-memory
    /// root into the next step instead of deep-cloning it.
    fn reconstruct_next(self: Arc<Self>, batch: OwnedBatch) -> Result<ArcDynReconstructed, Error>;
}

/// A shareable, erased committed revision usable as a reconstruction parent.
pub(crate) type ArcDynCommittedRevision = Arc<dyn DynCommittedRevision>;

/// A shareable, erased reconstructed state.
pub(crate) type ArcDynReconstructed = Arc<dyn DynReconstructed>;

/// A reconstructible database view.
///
/// This trait models linear reconstruction by consuming `self` and returning
/// a new reconstructed view.
pub trait Reconstructible: DbView {
    /// The reconstructed output type.
    type Reconstructed: DbView + Reconstructible<Reconstructed = Self::Reconstructed>;

    /// Reconstruct a new view from this one by applying `data`.
    ///
    /// # Errors
    ///
    /// Returns an error if applying the batch fails or if the underlying
    /// storage cannot be read while resolving nodes.
    fn reconstruct(self, data: impl IntoBatchIter) -> Result<Self::Reconstructed, Error>
    where
        Self: Sized;

    /// The underlying database
    fn db(&self) -> &dyn DynDb;
}

/// A proposal for a new revision of the database.
///
/// A proposal may be committed, which consumes the
/// [`Proposal`] and return the generic type `T`, which
/// is the same thing you get if you call [`Db::root_hash`]
/// immediately after committing, and then call
/// [`Db::revision`] with the returned revision.
///
/// A proposal type must also implement everything in a
/// [`DbView`], which means you can fetch values from it or
/// obtain proofs.
pub trait Proposal: DbView {
    /// The type of a proposal
    type Proposal: DbView + Proposal;

    /// Commit this revision
    #[expect(clippy::missing_errors_doc)]
    fn commit(self) -> Result<(), Error>;

    /// Propose a new revision on top of an existing proposal
    ///
    /// # Arguments
    ///
    /// * `data` - the batch changes to apply
    ///
    /// # Return value
    ///
    /// A new proposal
    #[expect(clippy::missing_errors_doc)]
    fn propose(&self, data: impl IntoBatchIter) -> Result<Self::Proposal, Error>;
}

/// A batch already collected into owned key/value pairs.
///
/// The [`DynDb`]/[`DynProposal`] boundary cannot accept an `impl IntoBatchIter`
/// (a generic method is not dispatchable through a vtable), so the generic
/// batch is pre-collected into this concrete, owned shape at the boundary.
pub type OwnedBatch = Box<[BatchOp<Box<[u8]>, Box<[u8]>>]>;

/// Key/value pairs collected into an owned shape for range merging across the
/// [`DynDb`] boundary.
pub type OwnedKeyValuePairs = Box<[(Key, Value)]>;

/// Collect a generic batch into the concrete [`OwnedBatch`] shape required at
/// the dyn boundary.
///
/// # Errors
///
/// Returns an error if the batch iterator yields one.
pub fn collect_owned_batch(batch: impl IntoBatchIter) -> Result<OwnedBatch, Error> {
    batch
        .into_batch_iter::<Error>()
        .map(|res| {
            res.map(|op| match op {
                BatchOp::Put { key, value } => BatchOp::Put {
                    key: key.as_ref().into(),
                    value: value.as_ref().into(),
                },
                BatchOp::Delete { key } => BatchOp::Delete {
                    key: key.as_ref().into(),
                },
                BatchOp::DeleteRange { prefix } => BatchOp::DeleteRange {
                    prefix: prefix.as_ref().into(),
                },
            })
        })
        .collect()
}

/// The object-safe erasure of [`Db`], used to hold databases of different
/// hash modes behind one type since [`Db`] itself is not object-safe. The
/// blanket impl lives next to the concrete `Db<H>` in `db.rs`.
pub trait DynDb: Debug + Send + Sync + 'static {
    /// Object-safe version of [`Db::revision`], returning a shareable,
    /// `'static` view instead of `Arc<Self::Historical>`.
    #[expect(clippy::missing_errors_doc)]
    fn revision(&self, hash: TrieHash) -> Result<ArcDynDbView, Error>;

    /// Object-safe version of [`Db::root_hash`].
    fn root_hash(&self) -> Option<TrieHash>;

    /// Object-safe version of [`Db::view`](crate::db::Db::view).
    #[expect(clippy::missing_errors_doc)]
    fn view(&self, hash: HashKey) -> Result<ArcDynDbView, Error>;

    /// Object-safe version of [`Db::propose`], taking an already-collected
    /// [`OwnedBatch`] since a generic `impl IntoBatchIter` parameter cannot
    /// cross a vtable.
    #[expect(clippy::missing_errors_doc)]
    fn propose(&self, ops: OwnedBatch) -> Result<Box<dyn DynProposal<'_> + '_>, Error>;

    /// The node-hashing scheme this database uses.
    fn node_hash_algorithm(&self) -> NodeHashAlgorithm;

    /// Dump the latest revision's trie to a string.
    #[expect(clippy::missing_errors_doc)]
    fn dump_to_string(&self) -> Result<String, Error>;

    /// Object-safe version of [`Db::change_proof`](crate::db::Db::change_proof).
    #[expect(clippy::missing_errors_doc)]
    fn change_proof(
        &self,
        start_hash: HashKey,
        end_hash: HashKey,
        start_key: Option<&[u8]>,
        end_key: Option<&[u8]>,
        limit: Option<NonZeroUsize>,
    ) -> Result<FrozenChangeProof, Error>;

    /// Object-safe version of
    /// [`Db::verify_change_proof`](crate::db::Db::verify_change_proof).
    #[expect(clippy::missing_errors_doc)]
    fn verify_change_proof(
        &self,
        proof: &FrozenChangeProof,
        end_root: HashKey,
        start_key: Option<&[u8]>,
        end_key: Option<&[u8]>,
        max_length: Option<NonZeroUsize>,
    ) -> Result<Box<dyn DynProposal<'_> + '_>, Error>;

    /// Object-safe version of
    /// [`Db::merge_key_value_range`](crate::db::Db::merge_key_value_range),
    /// taking already-collected [`OwnedKeyValuePairs`].
    #[expect(clippy::missing_errors_doc)]
    fn merge_key_value_range(
        &self,
        first_key: Option<&[u8]>,
        last_key: Option<&[u8]>,
        key_values: OwnedKeyValuePairs,
    ) -> Result<Box<dyn DynProposal<'_> + '_>, Error>;

    /// Object-safe version of
    /// [`Db::reconstruct_from_view`](crate::db::Db::reconstruct_from_view),
    /// taking an already-collected [`OwnedBatch`].
    #[expect(clippy::missing_errors_doc)]
    fn reconstruct_from_view(
        &self,
        parent: &crate::db::CommittedView,
        batch: OwnedBatch,
    ) -> Result<crate::db::ReconstructedView<'_>, Error>;

    /// Reconstruct a view from a reconstructed parent by applying batch
    /// operations (used internally by [`Reconstructible::reconstruct`]).
    #[expect(clippy::missing_errors_doc)]
    fn reconstruct_from_reconstructed<'db>(
        &'db self,
        parent: crate::db::ReconstructedView<'db>,
        batch: OwnedBatch,
    ) -> Result<crate::db::ReconstructedView<'db>, Error>;

    /// Object-safe version of
    /// [`Db::committed_view`](crate::db::Db::committed_view).
    ///
    /// Returns `Ok(None)` when `hash` names a proposal rather than a committed
    /// revision.
    #[expect(clippy::missing_errors_doc)]
    fn committed_view(&self, hash: TrieHash) -> Result<Option<crate::db::CommittedView>, Error>;

    /// Object-safe version of [`Db::close`](crate::db::Db::close), consuming
    /// the box instead of `self` by value.
    #[expect(clippy::missing_errors_doc)]
    fn close(self: Box<Self>) -> Result<(), Error>;
}

/// A dyn-safe version of [`Proposal`].
///
/// Unlike [`DynDbView`], this trait is **not** `'static`: a [`Proposal`]
/// borrows its parent database, so it cannot outlive it. That borrow is why
/// `DynProposal` cannot simply extend `DynDbView` (whose `'static` bound a
/// borrowing proposal cannot satisfy); instead it carries the same read
/// surface directly, plus the proposal-only `propose`/`commit` operations in
/// their object-safe form (`commit` consumes the box rather than `self` by
/// value). The proposal's shareable, `'static` view is reachable via [`DynProposal::view`].
pub trait DynProposal<'db>: Debug + Send + Sync {
    /// Object-safe version of [`DbView::root_hash`].
    fn root_hash(&self) -> Option<HashKey>;

    /// Object-safe version of [`DbView::val`].
    #[expect(clippy::missing_errors_doc)]
    fn val(&self, key: &[u8]) -> Result<Option<Value>, Error>;

    /// Object-safe version of [`DbView::single_key_proof`].
    #[expect(clippy::missing_errors_doc)]
    fn single_key_proof(&self, key: &[u8]) -> Result<FrozenProof, Error>;

    /// Object-safe version of [`DbView::range_proof`].
    #[expect(clippy::missing_errors_doc)]
    fn range_proof(
        &self,
        first_key: Option<&[u8]>,
        last_key: Option<&[u8]>,
        limit: Option<NonZeroUsize>,
    ) -> Result<FrozenRangeProof, Error>;

    /// Object-safe version of [`DbView::iter_option`].
    #[expect(clippy::missing_errors_doc)]
    fn iter_option(&self, first_key: Option<&[u8]>) -> Result<BoxKeyValueIter<'_>, Error>;

    /// Object-safe version of [`DbView::dump_to_string`].
    #[expect(clippy::missing_errors_doc)]
    fn dump_to_string(&self) -> Result<String, Error>;

    /// Returns the shareable, `'static` view backing this proposal.
    fn view(&self) -> ArcDynDbView;

    /// Object-safe version of [`Proposal::propose`].
    ///
    /// The returned proposal shares the parent database's `'db` lifetime, so it
    /// may outlive the borrow of `self` (proposal chaining keeps the original
    /// database handle alive, not the parent proposal).
    #[expect(clippy::missing_errors_doc)]
    fn propose(&self, ops: OwnedBatch) -> Result<Box<dyn DynProposal<'db> + 'db>, Error>;

    /// Object-safe version of [`Proposal::commit`], consuming the box instead
    /// of `self` by value.
    #[expect(clippy::missing_errors_doc)]
    fn commit(self: Box<Self>) -> Result<(), Error>;

    /// Object-safe version of
    /// [`Proposal::commit_with_rebase`](crate::db::Proposal::commit_with_rebase),
    /// consuming the box instead of `self` by value.
    #[expect(clippy::missing_errors_doc)]
    fn commit_with_rebase(self: Box<Self>) -> Result<Option<HashKey>, Error>;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[cfg(feature = "ethhash")]
    fn test_ethhash_compat_default_root_hash_equals_empty_rlp_hash() {
        use sha3::Digest as _;

        assert_eq!(
            TrieHash::default_root_hash(),
            Some(sha3::Keccak256::digest(rlp::NULL_RLP).into()),
        );
    }

    #[test]
    #[cfg(not(feature = "ethhash"))]
    fn test_firewood_default_root_hash_equals_none() {
        assert_eq!(TrieHash::default_root_hash(), None);
    }
}
