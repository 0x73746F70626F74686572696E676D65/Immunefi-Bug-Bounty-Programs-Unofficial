// Copyright (C) 2025, Ava Labs, Inc. All rights reserved.
// See the file LICENSE.md for licensing terms.

//! Proof reading utilities and traits.
//!
//! This module provides low-level utilities for reading binary proof data,
//! including the `ProofReader` type for sequential reading and traits for
//! deserializing individual proof components.

use firewood_storage::NodeHashAlgorithm;

use super::header::{Header, InvalidHeader};
use std::num::NonZeroUsize;
pub(super) trait ReadItem<'a>: Sized {
    /// Reads an item from the given reader, or terrminates with an error.
    fn read_item(data: &mut ProofReader<'a>) -> Result<Self, ReadError>;
}

pub(super) trait Version0: Sized {
    /// The minimum number of bytes required to deserialize a single instance of this type.
    const MIN_BYTES_PER_ITEM: NonZeroUsize = NonZeroUsize::new(1).unwrap();

    fn read_v0_item(reader: &mut V0Reader<'_>) -> Result<Self, ReadError>;
}

/// Marker for a reader that has not yet learned the proof's hash algorithm
/// from the header. It exists only so that body reads are
/// inexpressible during the header phase.
pub(super) struct NoAlgorithm;

pub(super) struct ProofReader<'a, M = NodeHashAlgorithm> {
    data: &'a [u8],
    offset: usize,
    /// The hash algorithm the proof being read was encoded with, resolved from
    /// the self-describing `hash_mode` header byte. During the header phase
    /// this is [`NoAlgorithm`]: no placeholder mode ever exists.
    mode: M,
}

impl<'a> ProofReader<'a, NoAlgorithm> {
    /// Creates a reader for parsing the fixed-size header, before the proof's
    /// own hash mode is known. Body items cannot be read until the resolved
    /// algorithm is supplied via [`ProofReader::into_body`].
    #[must_use]
    pub const fn new(data: &'a [u8]) -> Self {
        Self {
            data,
            offset: 0,
            mode: NoAlgorithm,
        }
    }

    /// Parses the fixed-size proof header — the only item that can be read
    /// before the proof's hash algorithm is known.
    pub fn read_header(&mut self) -> Result<Header, ReadError> {
        self.read_chunk::<{ size_of::<Header>() }>()
            .map_err(|err| err.set_item("header"))
            .copied()
            .map(bytemuck::cast)
    }

    /// Transitions to the body phase with the hash algorithm resolved from the
    /// validated header, so body reads dispatch on the proof's own mode.
    /// Consuming `self` keeps the phases exclusive: the only way to read body
    /// items is to supply the algorithm first.
    #[must_use]
    pub const fn into_body(self, algorithm: NodeHashAlgorithm) -> ProofReader<'a> {
        ProofReader {
            data: self.data,
            offset: self.offset,
            mode: algorithm,
        }
    }
}

impl<'a> ProofReader<'a> {
    /// The hash algorithm the proof being read was encoded with.
    #[must_use]
    pub const fn node_hash_algorithm(&self) -> NodeHashAlgorithm {
        self.mode
    }

    pub(super) fn read_item<T: ReadItem<'a>>(&mut self) -> Result<T, ReadError> {
        T::read_item(self)
    }
}

impl<'a, M> ProofReader<'a, M> {
    pub fn read_chunk<const N: usize>(&mut self) -> Result<&'a [u8; N], ReadError> {
        if let Some((chunk, _)) = self.remainder().split_first_chunk::<N>() {
            #[expect(clippy::arithmetic_side_effects)]
            {
                self.offset += N;
            }
            Ok(chunk)
        } else {
            Err(self.incomplete_item(std::any::type_name::<[u8; N]>(), N))
        }
    }

    pub fn read_slice(&mut self, n: usize) -> Result<&'a [u8], ReadError> {
        if self.remainder().len() >= n {
            #[expect(
                clippy::disallowed_methods,
                reason = "n is checked against remainder().len() on the line above"
            )]
            let (slice, _) = self.remainder().split_at(n);
            #[expect(clippy::arithmetic_side_effects)]
            {
                self.offset += n;
            }
            Ok(slice)
        } else {
            Err(self.incomplete_item("byte slice", n))
        }
    }

    pub fn remainder(&self) -> &'a [u8] {
        #![expect(clippy::indexing_slicing)]
        &self.data[self.offset..]
    }

    pub fn advance(&mut self, n: usize) {
        #![expect(clippy::arithmetic_side_effects)]
        debug_assert!(self.offset + n <= self.data.len());
        self.offset += n;
    }

    #[must_use]
    pub const fn incomplete_item(&self, item: &'static str, expected: usize) -> ReadError {
        ReadError::IncompleteItem {
            item,
            offset: self.offset,
            expected,
            #[expect(clippy::arithmetic_side_effects)]
            found: self.data.len() - self.offset,
        }
    }

    #[must_use]
    pub fn invalid_item(
        &self,
        item: &'static str,
        expected: &'static str,
        found: impl ToString,
    ) -> ReadError {
        ReadError::InvalidItem {
            item,
            offset: self.offset,
            expected,
            found: found.to_string(),
        }
    }
}

pub(super) struct V0Reader<'a> {
    inner: ProofReader<'a>,
    header: Header,
}

impl<'a> V0Reader<'a> {
    #[must_use]
    pub fn new(inner: ProofReader<'a>, header: Header) -> Self {
        let this = Self { inner, header };
        debug_assert_eq!(this.header().version, 0);
        this
    }

    pub fn read_v0_item<T: Version0>(&mut self) -> Result<T, ReadError> {
        T::read_v0_item(self)
    }

    pub const fn header(&self) -> &Header {
        &self.header
    }
}

impl<'a> std::ops::Deref for V0Reader<'a> {
    type Target = ProofReader<'a>;

    fn deref(&self) -> &Self::Target {
        &self.inner
    }
}

impl std::ops::DerefMut for V0Reader<'_> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        &mut self.inner
    }
}

/// Error that ocurred while reading an item from the byte stream.
#[derive(Debug, thiserror::Error)]
pub enum ReadError {
    /// Insufficient data in the byte stream.
    #[error("incomplete {item} at offset {offset}: expected {expected} bytes, but found {found}")]
    IncompleteItem {
        /// The specific item that was trying to parse.
        item: &'static str,
        /// The offset in the byte stream where the error ocurred.
        offset: usize,
        /// The expected length of the input (for this item).
        expected: usize,
        /// The number of bytes found in the byte stream.
        found: usize,
    },
    /// An item was invalid after parsing.
    #[error("invalid {item} at offset {offset}: expected {expected}, but found {found}")]
    InvalidItem {
        /// The item that was trying to parse.
        item: &'static str,
        /// The offset in the byte stream where the error ocurred.
        offset: usize,
        /// A hint at what was expected.
        expected: &'static str,
        /// Message indicating what was actually found.
        found: String,
    },
    /// Failed to validate the header.
    #[error("invalid header: {0}")]
    InvalidHeader(InvalidHeader),
}

impl ReadError {
    pub(super) const fn set_item(mut self, item: &'static str) -> Self {
        match &mut self {
            Self::IncompleteItem { item: e_item, .. } | Self::InvalidItem { item: e_item, .. } => {
                *e_item = item;
            }
            Self::InvalidHeader(_) => {}
        }
        self
    }
}
