// Copyright (C) 2025, Ava Labs, Inc. All rights reserved.
// See the file LICENSE.md for licensing terms.

use integer_encoding::VarInt;
use test_case::test_case;

use firewood_storage::{
    DefaultHashMode, DenseChildren, HashMode, HashType, NodeHashAlgorithm, PathComponent,
    SeededRng, TrieHash, ValueDigest, logger::debug,
};

use super::frame::MAX_DECOMPRESSED_LEN;
use super::{
    header::{Header, InvalidHeader},
    magic,
    reader::{ProofReader, ReadError},
    types::{Proof, ProofError, ProofNode, ProofType},
};
use crate::api::{FrozenChangeProof, FrozenRangeProof};
use crate::db::BatchOp;

/// Length of the serialized proof header, which the wire stores uncompressed.
const HEADER_LEN: usize = size_of::<Header>();

/// Builds the serialized proof header
fn raw_header(proof_type: ProofType) -> Vec<u8> {
    bytemuck::bytes_of(&Header::from((proof_type, DefaultHashMode::ALGORITHM))).to_vec()
}

/// Builds real wire bytes from `data` in uncompressed `header || body` form
/// (the layout the byte-taxonomy tests mutate at known offsets) by
/// zstd-compressing the body half, then parses the result.
///
/// Data too short to contain a header has no body to compress and is parsed
/// as-is: the header is stored uncompressed on the wire, so the parser sees
/// exactly what a truncated wire message would contain. The header-truncation
/// cases rely on this to reach the parser's short-header error.
fn compress_and_parse_range(data: &[u8]) -> Result<FrozenRangeProof, ReadError> {
    match data.split_at_checked(HEADER_LEN) {
        Some((header, body)) => {
            let mut wire = header.to_vec();
            super::frame::write_compressed_body(body, &mut wire).expect("compress body");
            FrozenRangeProof::from_slice(&wire)
        }
        None => FrozenRangeProof::from_slice(data),
    }
}

/// See [`compress_and_parse_range`].
fn compress_and_parse_change(data: &[u8]) -> Result<FrozenChangeProof, ReadError> {
    match data.split_at_checked(HEADER_LEN) {
        Some((header, body)) => {
            let mut wire = header.to_vec();
            super::frame::write_compressed_body(body, &mut wire).expect("compress body");
            FrozenChangeProof::from_slice(&wire)
        }
        None => FrozenChangeProof::from_slice(data),
    }
}

/// Returns a valid range proof plus its canonical uncompressed bytes
/// (`header || body`) for the byte-taxonomy tests.
///
/// This particular proof (keys `[2]..[8]` over `([k], [k])` for `k in 0..=10`,
/// capped at 5 key-values) is chosen because the cap makes every wire feature
/// non-empty at once — a two-node start proof, a two-node end proof, and five
/// key-values — so a mutation test exists for each section, while the
/// single-byte keys keep the byte offsets those tests hard-code small and
/// stable.
fn create_valid_range_proof() -> (FrozenRangeProof, Vec<u8>) {
    let merkle = crate::merkle::tests::init_merkle((0u8..=10).map(|k| ([k], [k])));
    let proof = merkle
        .range_proof(Some(&[2u8]), Some(&[8u8]), std::num::NonZeroUsize::new(5))
        .unwrap();
    let mut serialized = raw_header(ProofType::Range);
    proof.write_body_to_vec(&mut serialized);
    (proof, serialized)
}

/// Change-proof counterpart of [`create_valid_range_proof`].
///
/// The empty start and end proofs pin the batch-op section to fixed offsets
/// right after the header (see the layout comments where tests mutate it),
/// and one operation of each kind (`Put`, `Delete`, `DeleteRange`) covers all
/// three opcodes on the wire.
fn create_valid_change_proof(hash_mode: NodeHashAlgorithm) -> (FrozenChangeProof, Vec<u8>) {
    let proof = FrozenChangeProof::with_hash_mode(
        Proof::new(Box::<[ProofNode]>::from([])),
        Proof::new(Box::<[ProofNode]>::from([])),
        Box::new([
            BatchOp::Put {
                key: Box::from(b"key1".as_slice()),
                value: Box::from(b"val1".as_slice()),
            },
            BatchOp::Delete {
                key: Box::from(b"key2".as_slice()),
            },
            BatchOp::DeleteRange {
                prefix: Box::from(b"key3".as_slice()),
            },
        ]),
        hash_mode,
    );
    let mut serialized = raw_header(ProofType::Change);
    proof.write_body_to_vec(&mut serialized);
    (proof, serialized)
}

#[test]
fn test_range_proof_roundtrip() {
    let (proof, _) = create_valid_range_proof();
    let mut wire = Vec::new();
    proof.write_to_vec(&mut wire).expect("serialize proof");
    let parsed = FrozenRangeProof::from_slice(&wire).expect("roundtrip should succeed");
    assert_eq!(proof, parsed);
    let mut re_serialized = Vec::new();
    parsed
        .write_to_vec(&mut re_serialized)
        .expect("serialize proof");
    assert_eq!(wire, re_serialized, "re-serialization must be idempotent");
}

#[test_case(NodeHashAlgorithm::MerkleDB; "merkledb")]
#[test_case(NodeHashAlgorithm::Ethereum; "ethereum")]
fn test_change_proof_roundtrip(hash_mode: NodeHashAlgorithm) {
    let (proof, _) = create_valid_change_proof(hash_mode);
    let mut wire = Vec::new();
    proof.write_to_vec(&mut wire).expect("serialize proof");
    let parsed = FrozenChangeProof::from_slice(&wire).expect("roundtrip should succeed");
    assert_eq!(proof, parsed);
    assert_eq!(parsed.hash_mode(), hash_mode);
    let mut re_serialized = Vec::new();
    parsed
        .write_to_vec(&mut re_serialized)
        .expect("serialize proof");
    assert_eq!(wire, re_serialized, "re-serialization must be idempotent");
}

const fn hash_mode_byte(hash_mode: NodeHashAlgorithm) -> u8 {
    match hash_mode {
        NodeHashAlgorithm::MerkleDB => magic::MERKLEDB_HASH_MODE,
        NodeHashAlgorithm::Ethereum => magic::ETHEREUM_HASH_MODE,
    }
}

/// Ensures mode-dependent proof-node fields round-trip using the proof's recorded hash mode.
#[test_case(NodeHashAlgorithm::MerkleDB; "merkledb")]
#[test_case(NodeHashAlgorithm::Ethereum; "ethereum")]
fn test_mode_dependent_proof_node_roundtrip(hash_mode: NodeHashAlgorithm) {
    let mut node = make_proof_node(&[1], 0, Some(vec![0xabu8; 32].into_boxed_slice()), &[]);
    node.child_hashes.insert(
        PathComponent::try_new(7).unwrap().0,
        TrieHash::from([0xabu8; 32]).into(),
    );

    let range = FrozenRangeProof::with_hash_mode(
        Proof::new(Box::new([node])),
        Proof::new(Box::<[ProofNode]>::from([])),
        Box::new([]),
        hash_mode,
    );
    let mut serialized = Vec::new();
    range
        .write_to_vec(&mut serialized)
        .expect("serialize proof");

    let parsed = FrozenRangeProof::from_slice(&serialized)
        .expect("range proof should parse in its recorded mode");
    assert_eq!(parsed.hash_mode(), hash_mode);
    let value_digest = parsed
        .start_proof()
        .first()
        .and_then(|node| node.value_digest.as_ref())
        .expect("fixture should contain a value digest");
    assert_eq!(
        matches!(value_digest, ValueDigest::Hash(_)),
        hash_mode == NodeHashAlgorithm::MerkleDB
    );

    let mut reserialized = Vec::new();
    parsed
        .write_to_vec(&mut reserialized)
        .expect("serialize proof");
    assert_eq!(reserialized, serialized);
}

#[test_case(
    |data| *<&mut [u8; 8]>::try_from(&mut data[0..8]).unwrap() = *b"badmagic",
    |err| matches!(err, InvalidHeader::InvalidMagic { found } if found == b"badmagic");
    "invalid magic"
)]
#[test_case(
    |data| data[8] = 99,
    |err| matches!(err, InvalidHeader::UnsupportedVersion { found: 99 });
    "unsupported version"
)]
#[test_case(
    |data| data[9] = 99,
    |err| matches!(err, InvalidHeader::UnsupportedHashMode { found: 99 });
    "unsupported hash mode"
)]
#[test_case(
    |data| data[10] = 99,
    |err| matches!(err, InvalidHeader::UnsupportedBranchFactor { found: 99 });
    "unsupported branch factor"
)]
#[test_case(
    |data| data[11] = 99,
    |err| matches!(err, InvalidHeader::InvalidProofType { found: 99, expected: Some(ProofType::Range) });
    "invalid proof type"
)]
#[test_case(
    |data| data[11] = ProofType::Change as u8,
    |err| matches!(err, InvalidHeader::InvalidProofType { found: 2, expected: Some(ProofType::Range) });
    "wrong proof type"
)]
fn test_invalid_header(
    mutator: impl FnOnce(&mut Vec<u8>),
    expected: impl FnOnce(&InvalidHeader) -> bool,
) {
    let (_, mut data) = create_valid_range_proof();

    mutator(&mut data);

    match compress_and_parse_range(&data) {
        Err(ReadError::InvalidHeader(err)) => assert!(expected(&err), "unexpected error: {err}"),
        other => panic!("Expected ReadError::InvalidHeader, got: {other:?}"),
    }
}

#[test_case(
    |_, data| data.truncate(20),
    "header",
    32, // expected len
    20; // found len
    "incomplete header"
)]
#[test_case(
    |_, data| data.truncate(31),
    "header",
    32, // expected len
    31; // found len
    "header one byte short"
)]

fn test_incomplete_item(
    mutator: impl FnOnce(&FrozenRangeProof, &mut Vec<u8>),
    item: &'static str,
    expected_len: usize,
    found_len: usize,
) {
    let (proof, mut data) = create_valid_range_proof();

    debug!("data len: {}", data.len());
    debug!("proof: {proof:#?}");
    debug!("data: {}", hex::encode(&data));

    mutator(&proof, &mut data);

    match compress_and_parse_range(&data) {
        Err(ReadError::IncompleteItem {
            item: found_item,
            offset: _,
            expected,
            found,
        }) => {
            assert_eq!(
                found_item, item,
                "unexpected `item` value, got: {found_item}, wanted: {item}; {data:?}"
            );
            assert_eq!(
                expected, expected_len,
                "unexpected `expected` value, got: {expected}, wanted: {expected_len}; {data:?}"
            );
            assert_eq!(
                found, found_len,
                "unexpected `found` value, got: {found}, wanted: {found_len}; {data:?}"
            );
        }
        other => panic!("Expected ReadError::IncompleteItem, got: {other:?}"),
    }
}

#[test_case(
    |proof, data| data[32
        + proof.start_proof().len().required_space()
        + proof.start_proof()[0].key.len().required_space()
        + proof.start_proof()[0].key.len()
        + proof.start_proof()[0].partial_len.required_space()
        // Corrupt the option discriminant for the value digest (should be 0 or 1)
    ] = 3, // invalid option discriminant
    "option discriminant",
    "0 or 1",
    "3";
    "invalid option discriminant"
)]
#[test_case(
    |_, data| *<&mut [u8; 10]>::try_from(&mut data[32..42]).unwrap() = [0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89],
    "array length",
    "byte with no MSB within 9 bytes",
    "[128, 129, 130, 131, 132, 133, 134, 135, 136, 137]";
    "invalid varint"
)]
#[test_case(
    |_, data| data.extend_from_slice(&[0xFF; 100]), // extend data with invalid trailing bytes
    "trailing bytes",
    "no data after the proof",
    "100 bytes";
    "extra trailing bytes"
)]
#[test_case(
    |proof, data| {
        #[expect(clippy::arithmetic_side_effects)]
        data.truncate(
            32
            + proof.start_proof().len().required_space()
            + proof.start_proof()[0].key.len().required_space()
        );
    },
    "array length",
    "length less than or equal to the maximum possible items in remaining bytes",
    "2 > (1 / 5)";
    "truncated node key"
)]
fn test_invalid_item(
    mutator: impl FnOnce(&FrozenRangeProof, &mut Vec<u8>),
    item: &'static str,
    expected: &'static str,
    found: &'static str,
) {
    let (proof, mut data) = create_valid_range_proof();

    mutator(&proof, &mut data);

    match compress_and_parse_range(&data) {
        Err(ReadError::InvalidItem {
            item: found_item,
            offset: _,
            expected: found_expected,
            found: found_found,
        }) => {
            assert_eq!(
                found_item, item,
                "unexpected `item` value, got: {found_item}, wanted: {item}"
            );
            assert_eq!(
                found_expected, expected,
                "unexpected `expected` value, got: {found_expected}, wanted: {expected}"
            );
            assert_eq!(
                found_found, found,
                "unexpected `found` value, got: {found_found}, wanted: {found}"
            );
        }
        other => panic!("Expected ReadError::InvalidItem, got: {other:?}"),
    }
}

#[test]
fn test_partial_key_len_exceeds_key_len() {
    let (proof, mut data) = create_valid_range_proof();

    let node = &proof.start_proof()[0];
    let key_len = node.key.len();
    let original_partial_len_size = node.partial_len.required_space();
    let invalid_partial_len: usize = key_len + 1;

    let offset =
        32 + proof.start_proof().len().required_space() + key_len.required_space() + key_len;

    data.splice(
        offset..offset + original_partial_len_size,
        invalid_partial_len.encode_var_vec(),
    );

    match compress_and_parse_range(&data) {
        Err(ReadError::InvalidItem {
            item,
            expected,
            found,
            ..
        }) => {
            assert_eq!(item, "partial key length");
            assert_eq!(expected, "value less than or equal to the key length");
            assert_eq!(found, invalid_partial_len.to_string());
        }
        other => panic!("Expected ReadError::InvalidItem, got: {other:?}"),
    }
}

#[test]
fn test_empty_proof() {
    #[rustfmt::skip]
    let bytes = [
        b'f', b'w', b'd', b'p', b'r', b'o', b'o', b'f', // magic
        0, // version
        hash_mode_byte(DefaultHashMode::ALGORITHM),
        magic::BRANCH_FACTOR,
        ProofType::Range as u8,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // reserved
        0, // start proof length = 0
        0, // end proof length = 0
        0, // key-value pairs length = 0
    ];

    match compress_and_parse_range(&bytes) {
        Ok(proof) => {
            assert!(proof.start_proof().is_empty());
            assert!(proof.end_proof().is_empty());
            assert!(proof.key_values().is_empty());
        }
        Err(err) => panic!("Expected valid empty proof, got error: {err}"),
    }
}

#[test_case(
    |data| *<&mut [u8; 8]>::try_from(&mut data[0..8]).unwrap() = *b"badmagic",
    |err| matches!(err, InvalidHeader::InvalidMagic { found } if found == b"badmagic");
    "invalid magic"
)]
#[test_case(
    |data| data[8] = 99,
    |err| matches!(err, InvalidHeader::UnsupportedVersion { found: 99 });
    "unsupported version"
)]
#[test_case(
    |data| data[9] = 99,
    |err| matches!(err, InvalidHeader::UnsupportedHashMode { found: 99 });
    "unsupported hash mode"
)]
#[test_case(
    |data| data[10] = 99,
    |err| matches!(err, InvalidHeader::UnsupportedBranchFactor { found: 99 });
    "unsupported branch factor"
)]
#[test_case(
    |data| data[11] = 99,
    |err| matches!(err, InvalidHeader::InvalidProofType { found: 99, expected: Some(ProofType::Change) });
    "invalid proof type"
)]
#[test_case(
    |data| data[11] = ProofType::Range as u8,
    |err| matches!(err, InvalidHeader::InvalidProofType { found: 1, expected: Some(ProofType::Change) });
    "wrong proof type"
)]
fn test_change_proof_invalid_header(
    mutator: impl FnOnce(&mut Vec<u8>),
    expected: impl FnOnce(&InvalidHeader) -> bool,
) {
    let (_, mut data) = create_valid_change_proof(DefaultHashMode::ALGORITHM);

    mutator(&mut data);

    match compress_and_parse_change(&data) {
        Err(ReadError::InvalidHeader(err)) => assert!(expected(&err), "unexpected error: {err}"),
        other => panic!("Expected ReadError::InvalidHeader, got: {other:?}"),
    }
}

#[test_case(
    |data| data.truncate(20),
    "header",
    32, // expected len
    20; // found len
    "incomplete header"
)]
#[test_case(
    |data| data.truncate(31),
    "header",
    32, // expected len
    31; // found len
    "header one byte short"
)]
fn test_change_proof_incomplete_item(
    mutator: impl FnOnce(&mut Vec<u8>),
    item: &'static str,
    expected_len: usize,
    found_len: usize,
) {
    let (_, mut data) = create_valid_change_proof(DefaultHashMode::ALGORITHM);

    mutator(&mut data);

    match compress_and_parse_change(&data) {
        Err(ReadError::IncompleteItem {
            item: found_item,
            offset: _,
            expected,
            found,
        }) => {
            assert_eq!(
                found_item, item,
                "unexpected `item` value, got: {found_item}, wanted: {item}; {data:?}"
            );
            assert_eq!(
                expected, expected_len,
                "unexpected `expected` value, got: {expected}, wanted: {expected_len}; {data:?}"
            );
            assert_eq!(
                found, found_len,
                "unexpected `found` value, got: {found}, wanted: {found_len}; {data:?}"
            );
        }
        other => panic!("Expected ReadError::IncompleteItem, got: {other:?}"),
    }
}

#[test_case(
    |_, data| *<&mut [u8; 10]>::try_from(&mut data[32..42]).unwrap() = [0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89],
    "array length",
    "byte with no MSB within 9 bytes",
    "[128, 129, 130, 131, 132, 133, 134, 135, 136, 137]";
    "invalid varint"
)]
#[test_case(
    |_, data| data.extend_from_slice(&[0xFF; 100]),
    "trailing bytes",
    "no data after the proof",
    "100 bytes";
    "extra trailing bytes"
)]
#[test_case(
    // Layout: 32 (header) + 1 (start_proof len=0) + 1 (end_proof len=0) + 1 (batch_ops len=3) = offset 35
    // Byte at offset 35 is the first BatchOp discriminant (BATCH_PUT = 0)
    |_, data| data[35] = 99,
    "option discriminant",
    "0, 1, or 2",
    "99";
    "invalid batch op discriminant"
)]
fn test_change_proof_invalid_item(
    mutator: impl FnOnce(&FrozenChangeProof, &mut Vec<u8>),
    item: &'static str,
    expected: &'static str,
    found: &'static str,
) {
    let (proof, mut data) = create_valid_change_proof(DefaultHashMode::ALGORITHM);

    mutator(&proof, &mut data);

    match compress_and_parse_change(&data) {
        Err(ReadError::InvalidItem {
            item: found_item,
            offset: _,
            expected: found_expected,
            found: found_found,
        }) => {
            assert_eq!(
                found_item, item,
                "unexpected `item` value, got: {found_item}, wanted: {item}"
            );
            assert_eq!(
                found_expected, expected,
                "unexpected `expected` value, got: {found_expected}, wanted: {expected}"
            );
            assert_eq!(
                found_found, found,
                "unexpected `found` value, got: {found_found}, wanted: {found}"
            );
        }
        other => panic!("Expected ReadError::InvalidItem, got: {other:?}"),
    }
}

/// Constructs a `ProofNode` with the given nibble key, partial length, optional
/// value, and children at the specified nibble indices.
fn make_proof_node(
    key_nibbles: &[u8],
    partial_len: usize,
    value: Option<Box<[u8]>>,
    child_nibbles: &[u8],
) -> ProofNode {
    let key = key_nibbles
        .iter()
        .map(|&n| PathComponent::try_new(n).unwrap())
        .collect();
    let mut child_hashes = DenseChildren::new();
    for &nibble in child_nibbles {
        child_hashes.insert(
            PathComponent::try_new(nibble).unwrap().0,
            TrieHash::from([0u8; 32]).into(),
        );
    }
    ProofNode {
        key,
        partial_len,
        value_digest: value.map(ValueDigest::Value),
        child_hashes,
    }
}

/// Wraps a single `ProofNode` in a minimal `FrozenRangeProof` and serializes it.
/// Returns the proof plus its canonical uncompressed bytes
/// (`header || body`); parse with [`compress_and_parse_range`].
fn make_range_proof_from_single_node(node: ProofNode) -> (FrozenRangeProof, Vec<u8>) {
    let proof = FrozenRangeProof::new(
        Proof::new(Box::new([node])),
        Proof::new(Box::<[ProofNode]>::from([])),
        Box::new([]),
    );
    let mut serialized = raw_header(ProofType::Range);
    proof.write_body_to_vec(&mut serialized);
    (proof, serialized)
}

/// Verifies that parsing the canonical bytes and re-serializing the
/// canonical body produces the same bytes.
fn assert_range_proof_round_trip(serialized: Vec<u8>) {
    let parsed = compress_and_parse_range(&serialized).expect("deserialization should succeed");
    let mut re_serialized = raw_header(ProofType::Range);
    parsed.write_body_to_vec(&mut re_serialized);
    assert_eq!(serialized, re_serialized, "round-trip bytes must match");
}

#[test]
fn test_proof_node_leaf_round_trip() {
    // Leaf: no children, no value, empty key
    let node = make_proof_node(&[], 0, None, &[]);
    let (_, serialized) = make_range_proof_from_single_node(node);
    assert_range_proof_round_trip(serialized);
}

#[test]
fn test_proof_node_single_child_round_trip() {
    // Branch with one child at nibble index 7
    let node = make_proof_node(&[1, 2, 3], 0, None, &[7]);
    let (_, serialized) = make_range_proof_from_single_node(node);
    assert_range_proof_round_trip(serialized);
}

#[test]
fn test_proof_node_all_children_round_trip() {
    // Branch with all 16 children present (ChildMask = 0xFFFF)
    let all_nibbles: Vec<u8> = (0u8..16).collect();
    let node = make_proof_node(&[0], 0, None, &all_nibbles);
    let (_, serialized) = make_range_proof_from_single_node(node);
    assert_range_proof_round_trip(serialized);
}

#[cfg(not(feature = "ethhash"))]
#[test]
fn test_value_digest_hash_round_trip() {
    // Values >= 32 bytes are converted to a hash by make_hash() during serialization.
    // The round-trip bytes should still match because re-serializing a Hash-variant
    // node also produces a hash discriminant (1) rather than a value discriminant (0).
    let value: Box<[u8]> = vec![0xABu8; 32].into_boxed_slice();
    let node = make_proof_node(&[1, 2], 0, Some(value), &[]);
    let (_, serialized) = make_range_proof_from_single_node(node);
    assert_range_proof_round_trip(serialized);
}

#[test_case(
    BatchOp::Put { key: Box::from(b"k".as_slice()), value: Box::from(b"v".as_slice()) };
    "put"
)]
#[test_case(
    BatchOp::Delete { key: Box::from(b"k".as_slice()) };
    "delete"
)]
#[test_case(
    BatchOp::DeleteRange { prefix: Box::from(b"k".as_slice()) };
    "delete range"
)]
fn test_change_proof_batch_op_variant(op: BatchOp<Box<[u8]>, Box<[u8]>>) {
    let proof = FrozenChangeProof::new(
        Proof::new(Box::<[ProofNode]>::from([])),
        Proof::new(Box::<[ProofNode]>::from([])),
        Box::new([op]),
    );
    let mut serialized = Vec::new();
    proof
        .write_to_vec(&mut serialized)
        .expect("serialize proof");
    let parsed =
        FrozenChangeProof::from_slice(&serialized).expect("deserialization should succeed");
    let mut re_serialized = Vec::new();
    parsed
        .write_to_vec(&mut re_serialized)
        .expect("serialize proof");
    assert_eq!(serialized, re_serialized, "round-trip bytes must match");
}

#[test]
fn test_proof_node_partial_len_boundaries() {
    // partial_len = 0: no shared prefix with the parent node
    let node = make_proof_node(&[1, 2, 3, 4], 0, None, &[]);
    let (_, serialized) = make_range_proof_from_single_node(node);
    assert_range_proof_round_trip(serialized);

    // partial_len = key.len(): entire key is shared with the parent
    let node = make_proof_node(&[1, 2, 3, 4], 4, None, &[]);
    let (_, serialized) = make_range_proof_from_single_node(node);
    assert_range_proof_round_trip(serialized);
}

// These tests use manually constructed proofs with known byte layouts.
//
// Layout for make_range_proof_from_single_node(make_proof_node(&[1, 2, 3], 0, None, &[])):
//   [32]=0x01 (start_proof count)
//   [33]=0x03 (key byte length)    [34]=0x01  [35]=0x02  [36]=0x03 (key bytes)
//   [37]=0x00 (partial_len)        [38]=0x00  (option discriminant = None)
//   [39]=0x00  [40]=0x00           (ChildMask = 0)
//   [41]=0x00 (end_proof count)    [42]=0x00  (key_values count)
//
// Layout for make_range_proof_from_single_node(make_proof_node(&[1, 2, 3], 0, Some(b"v"), &[])):
//   [32..37] same as above
//   [38]=0x01 (option discriminant = Some)   [39]=0x00 (value digest discriminant = Value)
//   [40]=0x01 (value byte length)            [41]=0x76 (b'v')
//   [42]=0x00  [43]=0x00 (ChildMask = 0)     [44]=0x00  [45]=0x00
//
// Layout for make_range_proof_from_single_node(make_proof_node(&[1], 0, None, &[7])):
//   [32]=0x01  [33]=0x01  [34]=0x01  (count, key len, key byte)
//   [35]=0x00  [36]=0x00             (partial_len, option discriminant = None)
//   [37]=0x80  [38]=0x00             (ChildMask — nibble 7 = bit 7 of low byte)
//   Non-ethhash: [39..71] = TrieHash (32 bytes)
//   Ethhash:     [39] = HashType discriminant, [40..72] = TrieHash

#[test]
fn test_invalid_path_nibble() {
    let node = make_proof_node(&[1, 2, 3], 0, None, &[]);
    let (_, mut data) = make_range_proof_from_single_node(node);
    data[34] = 0x10; // first key byte set to an invalid nibble (16 > 15)
    match compress_and_parse_range(&data) {
        Err(ReadError::InvalidItem { item, .. }) => assert_eq!(item, "path"),
        other => panic!("Expected InvalidItem {{ item: \"path\" }}, got: {other:?}"),
    }
}

#[test]
fn test_invalid_value_digest_discriminant() {
    let node = make_proof_node(&[1, 2, 3], 0, Some(Box::from(b"v".as_slice())), &[]);
    let (_, mut data) = make_range_proof_from_single_node(node);
    data[39] = 2; // invalid ValueDigest discriminant (must be 0 or 1)
    match compress_and_parse_range(&data) {
        Err(ReadError::InvalidItem {
            item,
            expected,
            found,
            ..
        }) => {
            assert_eq!(item, "value digest discriminant");
            assert_eq!(expected, "0 (value) or 1 (hash)");
            assert_eq!(found, "2");
        }
        other => {
            panic!("Expected InvalidItem {{ item: \"value digest discriminant\" }}, got: {other:?}")
        }
    }
}

#[test_case(38, "option discriminant", 1, 0; "option discriminant")]
#[test_case(39, "children map", 2, 0; "children map zero bytes")]
#[test_case(40, "children map", 2, 1; "children map one byte")]
fn test_incomplete_item_known_layout(
    truncate_at: usize,
    item: &'static str,
    expected_len: usize,
    found_len: usize,
) {
    let node = make_proof_node(&[1, 2, 3], 0, None, &[]);
    let (_, mut data) = make_range_proof_from_single_node(node);
    data.truncate(truncate_at);
    match compress_and_parse_range(&data) {
        Err(ReadError::IncompleteItem {
            item: found_item,
            expected,
            found,
            ..
        }) => {
            assert_eq!(found_item, item);
            assert_eq!(expected, expected_len);
            assert_eq!(found, found_len);
        }
        other => panic!("Expected IncompleteItem {{ item: {item:?} }}, got: {other:?}"),
    }
}

#[cfg(not(feature = "ethhash"))]
#[test]
fn test_incomplete_trie_hash() {
    let node = make_proof_node(&[1], 0, None, &[7]);
    let (_, mut data) = make_range_proof_from_single_node(node);
    data.truncate(39); // ChildMask ends at [38]; TrieHash starts at [39]
    match compress_and_parse_range(&data) {
        Err(ReadError::IncompleteItem {
            item,
            expected,
            found,
            ..
        }) => {
            assert_eq!(item, "trie hash");
            assert_eq!(expected, 32);
            assert_eq!(found, 0);
        }
        other => panic!("Expected IncompleteItem {{ item: \"trie hash\" }}, got: {other:?}"),
    }
}

#[cfg(feature = "ethhash")]
#[test]
fn test_incomplete_hash_type_discriminant() {
    let node = make_proof_node(&[1], 0, None, &[7]);
    let (_, mut data) = make_range_proof_from_single_node(node);
    data.truncate(39); // ChildMask ends at [38]; HashType discriminant is at [39]
    match compress_and_parse_range(&data) {
        Err(ReadError::IncompleteItem {
            item,
            expected,
            found,
            ..
        }) => {
            assert_eq!(item, "hash type discriminant");
            assert_eq!(expected, 1);
            assert_eq!(found, 0);
        }
        other => {
            panic!("Expected IncompleteItem {{ item: \"hash type discriminant\" }}, got: {other:?}")
        }
    }
}

#[cfg(feature = "ethhash")]
#[test]
fn test_invalid_hash_type_discriminant() {
    let node = make_proof_node(&[1], 0, None, &[7]);
    let (_, mut data) = make_range_proof_from_single_node(node);
    data[39] = 2; // invalid HashType discriminant (must be 0 or 1)
    match compress_and_parse_range(&data) {
        Err(ReadError::InvalidItem {
            item,
            expected,
            found,
            ..
        }) => {
            assert_eq!(item, "hash type discriminant");
            assert_eq!(expected, "0 (hash) or 1 (rlp)");
            assert_eq!(found, "2");
        }
        other => {
            panic!("Expected InvalidItem {{ item: \"hash type discriminant\" }}, got: {other:?}")
        }
    }
}

#[test]
fn test_change_proof_incomplete_batch_op_discriminant() {
    // Layout of create_valid_change_proof() after the 32-byte header:
    //   [32]=0x00 (start_proof count=0)  [33]=0x00 (end_proof count=0)
    //   [34]=0x03 (batch_ops count=3)    [35]=0x00 (first BatchOp discriminant)
    let (_, mut data) = create_valid_change_proof(DefaultHashMode::ALGORITHM);
    data.truncate(35); // cut before the first BatchOp discriminant byte
    match compress_and_parse_change(&data) {
        Err(ReadError::InvalidItem {
            item,
            expected,
            found,
            ..
        }) => {
            assert_eq!(item, "array length");
            assert_eq!(
                expected,
                "length less than or equal to the maximum possible items in remaining bytes"
            );
            assert_eq!(found, "3 > (0 / 2)");
        }
        other => {
            panic!("Expected InvalidItem {{ item: \"array length\" }}, got: {other:?}")
        }
    }
}

/// Generates a random `ProofNode` using `rng`.
fn generate_random_proof_node(rng: &SeededRng) -> ProofNode {
    let key_len = rng.random_range(0usize..=32);
    let key = (0..key_len)
        .map(|_| PathComponent::try_new(rng.random_range(0u8..16)).unwrap())
        .collect();
    let partial_len = if key_len == 0 {
        0
    } else {
        rng.random_range(0..=key_len)
    };
    let value_digest = rng.random::<bool>().then(|| {
        let val_len = rng.random_range(0usize..=64);
        let value: Box<[u8]> = (0..val_len).map(|_| rng.random::<u8>()).collect();
        ValueDigest::Value(value)
    });
    let mut child_hashes = DenseChildren::new();
    for nibble in 0u8..16 {
        if rng.random::<bool>() {
            child_hashes.insert(
                PathComponent::try_new(nibble).unwrap().0,
                TrieHash::from(rng.random::<[u8; 32]>()).into(),
            );
        }
    }
    ProofNode {
        key,
        partial_len,
        value_digest,
        child_hashes,
    }
}

/// Generates a random `FrozenRangeProof` and returns it with its wire bytes.
///
/// The seed used is printed to stderr by `SeededRng` so failures can be reproduced.
fn generate_random_range_proof(rng: &SeededRng) -> (FrozenRangeProof, Vec<u8>) {
    let start_nodes: Box<[ProofNode]> = (0..rng.random_range(0usize..=5))
        .map(|_| generate_random_proof_node(rng))
        .collect();
    let end_nodes: Box<[ProofNode]> = (0..rng.random_range(0usize..=5))
        .map(|_| generate_random_proof_node(rng))
        .collect();
    let key_values: Box<[_]> = (0..rng.random_range(0usize..=10))
        .map(|_| {
            let key_len = rng.random_range(0usize..=32);
            let key: Box<[u8]> = (0..key_len).map(|_| rng.random::<u8>()).collect();
            let val_len = rng.random_range(0usize..=32);
            let val: Box<[u8]> = (0..val_len).map(|_| rng.random::<u8>()).collect();
            (key, val)
        })
        .collect();

    let proof = FrozenRangeProof::new(Proof::new(start_nodes), Proof::new(end_nodes), key_values);
    let mut serialized = Vec::new();
    proof
        .write_to_vec(&mut serialized)
        .expect("serialize proof");
    (proof, serialized)
}

/// Generates a random `FrozenChangeProof` and returns it with its wire bytes.
fn generate_random_change_proof(rng: &SeededRng) -> (FrozenChangeProof, Vec<u8>) {
    let start_nodes: Box<[ProofNode]> = (0..rng.random_range(0usize..=5))
        .map(|_| generate_random_proof_node(rng))
        .collect();
    let end_nodes: Box<[ProofNode]> = (0..rng.random_range(0usize..=5))
        .map(|_| generate_random_proof_node(rng))
        .collect();
    let batch_ops: Box<[_]> = (0..rng.random_range(0usize..=10))
        .map(|_| {
            let key_len = rng.random_range(0usize..=32);
            let key: Box<[u8]> = (0..key_len).map(|_| rng.random::<u8>()).collect();
            match rng.random_range(0u8..3) {
                0 => {
                    let val_len = rng.random_range(0usize..=32);
                    let val: Box<[u8]> = (0..val_len).map(|_| rng.random::<u8>()).collect();
                    BatchOp::Put { key, value: val }
                }
                1 => BatchOp::Delete { key },
                _ => BatchOp::DeleteRange { prefix: key },
            }
        })
        .collect();

    let proof = FrozenChangeProof::new(Proof::new(start_nodes), Proof::new(end_nodes), batch_ops);
    let mut serialized = Vec::new();
    proof
        .write_to_vec(&mut serialized)
        .expect("serialize proof");
    (proof, serialized)
}

#[test]
fn test_slow_range_proof_roundtrip_fuzz() {
    let rng = SeededRng::from_env_or_random();
    for i in 0..100 {
        let (proof, bytes) = generate_random_range_proof(&rng);
        debug!("iteration {i}: proof: {proof:#?}");
        debug!("iteration {i}: bytes: {}", hex::encode(&bytes));

        let parsed = FrozenRangeProof::from_slice(&bytes).expect("generated proof should be valid");
        let mut re_bytes = Vec::new();
        parsed.write_to_vec(&mut re_bytes).expect("serialize proof");
        assert_eq!(bytes, re_bytes, "re-serialized bytes must match original");
    }
}

#[test]
fn test_slow_change_proof_roundtrip_fuzz() {
    let rng = SeededRng::from_env_or_random();
    for i in 0..100 {
        let (proof, bytes) = generate_random_change_proof(&rng);
        debug!("iteration {i}: proof: {proof:#?}");
        debug!("iteration {i}: bytes: {}", hex::encode(&bytes));

        let parsed =
            FrozenChangeProof::from_slice(&bytes).expect("generated proof should be valid");
        let mut re_bytes = Vec::new();
        parsed.write_to_vec(&mut re_bytes).expect("serialize proof");
        assert_eq!(bytes, re_bytes, "re-serialized bytes must match original");
    }
}

#[test]
fn test_slow_malformed_proof_fuzz() {
    let rng = SeededRng::from_env_or_random();
    for i in 0..200 {
        // Corrupt the *canonical* bytes (header || body), not the wire:
        // this test targets the body parser via compress_and_parse_range.
        let (proof, _) = generate_random_range_proof(&rng);
        let mut data = raw_header(ProofType::Range);
        proof.write_body_to_vec(&mut data);

        // Corrupt 1–3 bytes at random positions.
        let num_corruptions = rng.random_range(1usize..=3);
        for _ in 0..num_corruptions {
            if data.is_empty() {
                break;
            }
            let pos = rng.random_range(0..data.len());
            let old = data[pos];
            let new_val = rng.random::<u8>();
            debug!("iteration {i}: corrupted byte {pos}: {old} -> {new_val}");
            data[pos] = new_val;
        }
        debug!("iteration {i}: corrupted bytes: {}", hex::encode(&data));

        match compress_and_parse_range(&data) {
            Err(err) => {
                debug!("iteration {i}: parse error (expected): {err}");
            }
            Ok(parsed) => {
                debug!("iteration {i}: corruption produced valid proof (checking stability)");
                // Verify idempotency: serialize(parsed) should be stable across two round-trips.
                let mut re_bytes = Vec::new();
                parsed.write_to_vec(&mut re_bytes).expect("serialize proof");
                let re_parsed = FrozenRangeProof::from_slice(&re_bytes)
                    .expect("re-serialized proof should parse cleanly");
                let mut re_re_bytes = Vec::new();
                re_parsed
                    .write_to_vec(&mut re_re_bytes)
                    .expect("serialize proof");
                assert_eq!(
                    re_bytes, re_re_bytes,
                    "re-serialized proof must be idempotent"
                );
            }
        }
    }
}

#[test]
fn test_dos_array_length_bounds() {
    use integer_encoding::VarInt;

    let (proof, mut data) = create_valid_range_proof();

    // The first array length (for start_proof) is at offset 32.
    let original_len = proof.start_proof().len();
    let original_len_space = original_len.required_space();

    let malicious_num_items: usize = 10_000_000;
    let encoded = malicious_num_items.encode_var_vec();

    data.splice(32..32 + original_len_space, encoded);

    // Calculate the remaining bytes after parsing the new varint (offset 32 + encoded varint len)
    let remainder_len = data.len() - 32 - malicious_num_items.required_space();

    match compress_and_parse_range(&data) {
        Err(ReadError::InvalidItem {
            item,
            expected,
            found,
            ..
        }) => {
            assert_eq!(item, "array length");
            assert_eq!(
                expected,
                "length less than or equal to the maximum possible items in remaining bytes"
            );
            assert_eq!(
                found,
                format!("{malicious_num_items} > ({remainder_len} / 5)")
            );
        }
        other => panic!("Expected ReadError::InvalidItem for DoS vector, got: {other:?}"),
    }
}

#[test_case(b"", &[0u8] ; "empty key")]
#[test_case(b"a", &[b'a', 0] ; "single byte")]
#[test_case(b"\xff", &[0xff, 0] ; "maximum byte does not carry")]
#[test_case(b"ab\x00", &[b'a', b'b', 0, 0] ; "key already ending in zero")]
fn test_lex_successor(key: &[u8], expected: &[u8]) {
    assert_eq!(&*super::lex_successor(key), expected);
}

#[test_case(b"" ; "empty key")]
#[test_case(b"a" ; "single byte")]
#[test_case(b"\xff\xff" ; "maximum bytes")]
#[test_case(b"key50" ; "multi byte")]
fn test_lex_successor_is_least_strict_upper_bound(key: &[u8]) {
    let successor = super::lex_successor(key);
    assert!(&*successor > key, "the successor must sort above the key");

    // Nothing sorts strictly between a key and its successor. A string that
    // diverges from `key` at some byte is either below `key` entirely or above
    // the successor, so it can never land between them; only a string extending
    // `key` could. Every extension begins with a byte of at least 0, so it is at
    // or above the successor, and the ones beginning with 0 are the cases where
    // that is least obvious.
    for extra in [&[0u8][..], &[0, 0], &[0, 0xff], &[1], &[0xff]] {
        let mut extension = key.to_vec();
        extension.extend_from_slice(extra);
        assert!(
            extension[..] >= successor[..],
            "{extension:?} sorts between {key:?} and its successor"
        );
    }
}

mod box_array_deserialization_tests {
    use std::num::NonZeroUsize;

    use super::*;
    use crate::proofs::header::Header;
    use crate::proofs::reader::{ProofReader, ReadError, V0Reader, Version0};
    use integer_encoding::VarInt;

    #[derive(Debug, PartialEq)]
    struct Hash32([u8; 32]);

    impl Version0 for Hash32 {
        const MIN_BYTES_PER_ITEM: NonZeroUsize = NonZeroUsize::new(32).unwrap();

        fn read_v0_item(reader: &mut V0Reader<'_>) -> Result<Self, ReadError> {
            let chunk = reader.read_chunk::<32>()?;
            Ok(Hash32(*chunk))
        }
    }

    impl Version0 for u8 {
        fn read_v0_item(reader: &mut V0Reader<'_>) -> Result<Self, ReadError> {
            let chunk = reader.read_chunk::<1>()?;
            Ok(chunk[0])
        }
    }

    #[derive(Debug, PartialEq)]
    struct VarLenVec(Vec<u8>);

    impl Version0 for VarLenVec {
        fn read_v0_item(reader: &mut V0Reader<'_>) -> Result<Self, ReadError> {
            let len = reader.read_item::<usize>()?;
            let slice = reader.read_slice(len)?;
            Ok(VarLenVec(slice.to_vec()))
        }
    }

    fn v0_reader(data: &[u8]) -> V0Reader<'_> {
        // Resolve the algorithm from the header itself, mirroring the
        // production validate-then-into_body flow. (These tests exercise
        // mode-independent reads, so any consistent mode works.)
        let header = Header::from((ProofType::Range, DefaultHashMode::ALGORITHM));
        let validated_header = header
            .validate(Some(ProofType::Range))
            .expect("default header should be valid");
        let inner = ProofReader::new(data).into_body(validated_header.node_hash_algorithm);
        V0Reader::new(inner, header)
    }

    #[test]
    fn rejects_usize_max_items_via_length_guard() {
        // Guard catches extreme case before any iteration
        let mut data = Vec::new();
        data.extend_from_slice(&usize::MAX.encode_var_vec());
        let mut reader = v0_reader(&data);
        let result: Result<Box<[Hash32]>, _> = reader.read_v0_item();

        assert!(matches!(
            result,
            Err(ReadError::InvalidItem {
                item: "array length",
                ..
            })
        ));
    }

    #[test]
    fn rejects_eof_mid_array() {
        // Guard doesn't trigger (5 > 64 is FALSE), but loop fails safely on EOF
        let mut data = Vec::new();
        data.extend_from_slice(&5usize.encode_var_vec());
        data.extend_from_slice(&[0u8; 64]); // only 2 complete Hash32 items
        let mut reader = v0_reader(&data);
        let result: Result<Box<[Hash32]>, _> = reader.read_v0_item();

        assert!(result.is_err());
    }

    #[test]
    fn rejects_var_len_item_with_huge_claimed_length() {
        // Nested length field amplification
        let mut data = Vec::new();
        data.extend_from_slice(&1usize.encode_var_vec());
        data.extend_from_slice(&usize::MAX.encode_var_vec());
        data.extend_from_slice(&[0u8; 10]);
        let mut reader = v0_reader(&data);
        let result: Result<Box<[VarLenVec]>, _> = reader.read_v0_item();

        assert!(result.is_err());
    }

    #[test]
    fn accepts_empty_array() {
        let mut data = Vec::new();
        data.extend_from_slice(&0usize.encode_var_vec());
        let mut reader = v0_reader(&data);
        let result: Result<Box<[Hash32]>, _> = reader.read_v0_item();

        assert!(result.is_ok());
        assert_eq!(result.unwrap().len(), 0);
    }

    #[test]
    fn boundary_exact_fit_passes() {
        // 10 items, 50 bytes → 10 > 50 / 5 is FALSE → PASS
        // T = u8 so num_items directly equals bytes needed
        let mut data = Vec::new();
        data.extend_from_slice(&10usize.encode_var_vec());
        data.extend_from_slice(&[0u8; 50]);
        let mut reader = v0_reader(&data);
        let result: Result<Box<[u8]>, _> = reader.read_v0_item();

        assert!(result.is_ok());
        assert_eq!(result.unwrap().len(), 10);
    }

    #[test]
    fn boundary_one_over_fails() {
        // 51 items, 50 bytes → 51 > 50 / 1 is TRUE → FAIL
        // T = u8 so MIN_BYTES_PER_ITEM = 1
        let mut data = Vec::new();
        data.extend_from_slice(&51usize.encode_var_vec());
        data.extend_from_slice(&[0u8; 50]);
        let mut reader = v0_reader(&data);
        let result: Result<Box<[u8]>, _> = reader.read_v0_item();

        assert!(matches!(
            result,
            Err(ReadError::InvalidItem {
                item: "array length",
                ..
            })
        ));
    }
}

fn range_wire() -> Vec<u8> {
    let (proof, _) = create_valid_range_proof();
    let mut wire = Vec::new();
    proof.write_to_vec(&mut wire).expect("serialize proof");
    wire
}

fn change_wire() -> Vec<u8> {
    let (proof, _) = create_valid_change_proof(DefaultHashMode::ALGORITHM);
    let mut wire = Vec::new();
    proof.write_to_vec(&mut wire).expect("serialize proof");
    wire
}

#[test]
fn test_frame_wire_is_compressed_and_versioned() {
    // A compressible proof
    let kvs: Box<[_]> = (0u16..512)
        .map(|i| {
            (
                Box::from(format!("key-{i:05}").as_bytes()),
                Box::from(b"value-value-value-value".as_slice()),
            )
        })
        .collect();
    let proof = FrozenRangeProof::new(
        Proof::new(Box::<[ProofNode]>::from([])),
        Proof::new(Box::<[ProofNode]>::from([])),
        kvs,
    );
    let mut canonical_body = Vec::new();
    proof.write_body_to_vec(&mut canonical_body);
    let mut wire = Vec::new();
    proof.write_to_vec(&mut wire).expect("serialize proof");

    assert_eq!(&wire[..8], magic::PROOF_HEADER);
    assert_eq!(wire[8], 0, "compressed wire keeps version byte 0");
    // A zstd frame (magic 0xFD2FB528, little-endian) follows the header.
    assert_eq!(
        &wire[32..36],
        &[0x28, 0xB5, 0x2F, 0xFD],
        "zstd frame magic must follow the header"
    );
    // The wire is actually compressed, not stored.
    assert!(
        wire.len() < canonical_body.len() + 32,
        "wire ({} bytes) must be smaller than header + canonical body ({} bytes)",
        wire.len(),
        canonical_body.len() + 32
    );
}

#[test]
fn test_frame_rejects_over_cap_content_size() {
    // A frame whose header declares a content size just over the cap: the
    // decoder must reject it before allocating.
    let body = vec![0u8; MAX_DECOMPRESSED_LEN + 1];
    let mut wire = raw_header(ProofType::Range);
    super::frame::write_compressed_body(&body, &mut wire).expect("compress body");
    let err = FrozenRangeProof::from_slice(&wire).expect_err("over-cap content size");
    assert!(
        matches!(
            err,
            ReadError::InvalidItem { item, expected, .. }
                if item == "frame content size" && expected.contains("within the maximum")
        ),
        "got {err:?}"
    );
}

/// Wire mutations the frame layer must reject with
/// `InvalidItem { item: "compressed body frame" }`.
/// Each case runs against both proof types.
#[test_case(|wire| wire.push(0xAB) ; "trailing byte")]
#[test_case(|wire| wire[32] ^= 0xFF ; "corrupt frame magic")]
#[test_case(|wire| { wire.pop(); } ; "truncated frame")]
#[test_case(|wire| {
    // zstd skippable frame (magic 0x184D2A50, little-endian, 4-byte payload)
    wire.extend_from_slice(&[0x50, 0x2A, 0x4D, 0x18]);
    wire.extend_from_slice(&4u32.to_le_bytes());
    wire.extend_from_slice(&[0xAB; 4]);
} ; "trailing skippable frame")]
#[test_case(|wire| {
    // a second, fully valid zstd frame (compressing zero bytes)
    let empty = zstd::bulk::compress(&[], zstd::DEFAULT_COMPRESSION_LEVEL)
        .expect("compress empty buffer");
    wire.extend_from_slice(&empty);
} ; "trailing concatenated frame")]
fn test_frame_rejects_malformed_wire(mutate: fn(&mut Vec<u8>)) {
    let mut wire = range_wire();
    mutate(&mut wire);
    let err = FrozenRangeProof::from_slice(&wire).expect_err("range wire must be rejected");
    assert!(
        matches!(err, ReadError::InvalidItem { item, .. } if item == "compressed body frame"),
        "got {err:?}"
    );

    let mut wire = change_wire();
    mutate(&mut wire);
    let err = FrozenChangeProof::from_slice(&wire).expect_err("change wire must be rejected");
    assert!(
        matches!(err, ReadError::InvalidItem { item, .. } if item == "compressed body frame"),
        "got {err:?}"
    );
}

#[test]
fn test_write_to_vec_rejects_over_cap_body() {
    // One more 1 MiB value than the cap holds
    let over_cap = u8::try_from(MAX_DECOMPRESSED_LEN / (1024 * 1024) + 1).unwrap();
    let kvs: Box<[_]> = (0u8..over_cap)
        .map(|i| {
            (
                Box::from([i].as_slice()),
                vec![i; 1024 * 1024].into_boxed_slice(),
            )
        })
        .collect();
    let proof = FrozenRangeProof::new(
        Proof::new(Box::<[ProofNode]>::from([])),
        Proof::new(Box::<[ProofNode]>::from([])),
        kvs,
    );
    let mut out = Vec::new();
    let err = proof
        .write_to_vec(&mut out)
        .expect_err("over-cap body must fail to serialize");
    assert!(
        matches!(
            err,
            ProofError::BodyTooLarge {
                limit: MAX_DECOMPRESSED_LEN,
                ..
            }
        ),
        "got {err:?}"
    );
    assert!(out.is_empty(), "a failed serialization must not write");
}

#[test]
fn test_write_to_vec_keeps_over_compressible_bodies_decodable() {
    // A constant value bulk-compresses beyond the ratio decoders accept;
    // the producer re-encodes it in flushed blocks and the decoder's
    // single-frame, content-size and ratio checks must all still pass.
    for len in [128, 16 * 1024, MAX_DECOMPRESSED_LEN - 64] {
        let kvs: Box<[_]> = Box::from([(
            Box::from([0u8].as_slice()),
            vec![0u8; len].into_boxed_slice(),
        )]);
        let proof = FrozenRangeProof::new(
            Proof::new(Box::<[ProofNode]>::from([])),
            Proof::new(Box::<[ProofNode]>::from([])),
            kvs,
        );
        let mut wire = Vec::new();
        proof.write_to_vec(&mut wire).expect("serialize");
        let decoded = FrozenRangeProof::from_slice(&wire).expect("decodable frame");
        assert_eq!(decoded.key_values(), proof.key_values());
    }
}

/// Frames declaring a zero content size are rejected at the frame layer
#[test_case(|wire: &mut Vec<u8>| {
    crate::proofs::frame::write_compressed_body(&[], wire).expect("compress body");
} ; "empty body frame")]
#[test_case(|wire: &mut Vec<u8>| {
    // zstd skippable frame (magic 0x184D2A50, little-endian, 4-byte payload)
    wire.extend_from_slice(&[0x50, 0x2A, 0x4D, 0x18]);
    wire.extend_from_slice(&4u32.to_le_bytes());
    wire.extend_from_slice(&[0xAB; 4]);
} ; "lone skippable frame")]
fn test_frame_rejects_zero_content_size(append_frame: fn(&mut Vec<u8>)) {
    let mut wire = raw_header(ProofType::Range);
    append_frame(&mut wire);
    let err = FrozenRangeProof::from_slice(&wire).expect_err("zero content size");
    assert!(
        matches!(err, ReadError::InvalidItem { item, .. } if item == "frame content size"),
        "got {err:?}"
    );
}

#[test]
fn test_frame_rejects_missing_frame() {
    // Nothing after the header: the frame is missing.
    let wire = range_wire()[..32].to_vec();
    let err = FrozenRangeProof::from_slice(&wire).expect_err("missing frame");
    assert!(
        matches!(err, ReadError::InvalidItem { item, .. } if item == "compressed body frame"),
        "got {err:?}"
    );
}

#[test]
fn test_frame_rejects_frame_without_content_size() {
    // The producer's bulk compressor always records the content size in
    // the frame header, but zstd streaming encoders (which don't know the
    // input size up front) omit it. An attacker can hand-craft such a
    // frame; the decoder must reject it before allocating.
    let (_, canonical) = create_valid_range_proof();
    let body = &canonical[32..];
    let frame = zstd::stream::encode_all(body, zstd::DEFAULT_COMPRESSION_LEVEL)
        .expect("stream compression of an in-memory buffer");
    let mut wire = canonical[..32].to_vec();
    wire.extend_from_slice(&frame);
    let err = FrozenRangeProof::from_slice(&wire).expect_err("frame without content size");
    assert!(
        matches!(
            err,
            ReadError::InvalidItem { item, ref found, .. }
                if item == "frame content size" && found.contains("no content size")
        ),
        "got {err:?}"
    );
}

#[test]
fn test_frame_rejects_excessive_compression_ratio() {
    // A 4 MiB all-zero body compresses to a few hundred bytes: under the
    // length cap and consistent with the frame header's content size, but
    // far over MAX_COMPRESSION_RATIO. The decoder must reject it before
    // allocating the 4 MiB. The producer no longer emits such a frame (it
    // re-encodes in flushed blocks), so build the bomb with zstd directly.
    let body = vec![0u8; 4 * 1024 * 1024];
    let mut wire = raw_header(ProofType::Range);
    wire.extend_from_slice(
        &zstd::bulk::compress(&body, zstd::DEFAULT_COMPRESSION_LEVEL).expect("compress body"),
    );
    let err = FrozenRangeProof::from_slice(&wire).expect_err("compression bomb");
    assert!(
        matches!(
            err,
            ReadError::InvalidItem { item, expected, .. }
                if item == "frame content size" && expected.contains("compression ratio")
        ),
        "got {err:?}"
    );
}

#[test]
fn test_frame_accepts_max_decompressed_len_exactly() {
    // A body of exactly MAX_DECOMPRESSED_LEN must pass the length cap
    // (the bound is inclusive). A random 1 MiB block repeated to the cap
    // keeps the compression ratio ~4x — above honest proofs (~2.3x) but
    // inside MAX_COMPRESSION_RATIO, so this doubles as the accept-side
    // coverage for high-but-legal ratios.
    let rng = SeededRng::from_env_or_random();
    let cap = MAX_DECOMPRESSED_LEN;
    let block: Vec<u8> = (0..1024 * 1024).map(|_| rng.random::<u8>()).collect();
    let body = block.repeat(cap / block.len());
    assert_eq!(body.len(), cap);
    let mut frame = Vec::new();
    super::frame::write_compressed_body(&body, &mut frame).expect("compress body");
    let decoded = super::frame::decompress_body(&frame, 0)
        .expect("body exactly at MAX_DECOMPRESSED_LEN must decode");
    assert_eq!(decoded, body);
}

/// The zstd frame of [`golden_proof`]'s wire encoding, captured at zstd
/// 1.5.7. Encoder output may drift across zstd versions, but the format is
/// stable: these exact bytes must decode forever (decode-side wire
/// compatibility).
const GOLDEN_WIRE_TAIL: &str =
    "28b52ffd201bd90000000002046b6579310676616c756531046b6579320676616c756532";

fn golden_proof() -> FrozenRangeProof {
    FrozenRangeProof::new(
        Proof::new(Box::<[ProofNode]>::from([])),
        Proof::new(Box::<[ProofNode]>::from([])),
        Box::new([
            (
                Box::from(b"key1".as_slice()),
                Box::from(b"value1".as_slice()),
            ),
            (
                Box::from(b"key2".as_slice()),
                Box::from(b"value2".as_slice()),
            ),
        ]),
    )
}

#[test]
fn test_frame_rejects_content_size_mismatch() {
    // Bump the declared content size in the frame header (the golden
    // frame is single-segment, so its 1-byte FCS field sits at frame
    // offset 5). The frame now declares 28 bytes but decompresses to 27;
    // decompress_body relies on zstd rejecting this, so pin it.
    let mut wire = raw_header(ProofType::Range);
    wire.extend_from_slice(&hex::decode(GOLDEN_WIRE_TAIL).expect("valid hex"));
    assert_eq!(wire[37], 0x1b, "golden frame content-size byte moved");
    wire[37] += 1;
    let err = FrozenRangeProof::from_slice(&wire).expect_err("content size mismatch");
    assert!(
        matches!(err, ReadError::InvalidItem { item, .. } if item == "compressed body frame"),
        "got {err:?}"
    );
}

#[test]
fn test_frame_golden_vector_decodes() {
    // The golden body is key-value-only, so its bytes are identical under
    // both hash modes; raw_header supplies the mode-correct header.
    let mut wire = raw_header(ProofType::Range);
    wire.extend_from_slice(&hex::decode(GOLDEN_WIRE_TAIL).expect("valid hex"));
    let parsed = FrozenRangeProof::from_slice(&wire)
        .expect("checked-in compressed golden vector must always decode");
    assert_eq!(parsed, golden_proof());
}

#[test]
fn test_slow_malformed_wire_fuzz() {
    // Wire-level complement of test_slow_malformed_proof_fuzz: corrupts
    // the compressed wire instead of the canonical body.
    let rng = SeededRng::from_env_or_random();
    for i in 0..200 {
        let (_, mut data) = generate_random_range_proof(&rng);

        let num_corruptions = rng.random_range(1usize..=3);
        for _ in 0..num_corruptions {
            let pos = rng.random_range(0..data.len());
            let old = data[pos];
            let new_val = rng.random::<u8>();
            debug!("iteration {i}: corrupted wire byte {pos}: {old} -> {new_val}");
            data[pos] = new_val;
        }
        debug!("iteration {i}: corrupted wire: {}", hex::encode(&data));

        match FrozenRangeProof::from_slice(&data) {
            Err(err) => {
                debug!("iteration {i}: parse error (expected): {err}");
            }
            Ok(parsed) => {
                debug!("iteration {i}: corruption produced valid proof (checking stability)");
                let mut re_bytes = Vec::new();
                parsed.write_to_vec(&mut re_bytes).expect("serialize proof");
                let re_parsed = FrozenRangeProof::from_slice(&re_bytes)
                    .expect("re-serialized proof should parse cleanly");
                assert_eq!(parsed, re_parsed, "roundtrip must preserve the proof");
            }
        }
    }
}
#[test]
fn test_header_validate_accepts_both_hash_modes() {
    let (_, base) = create_valid_range_proof();

    for (byte, expected) in [
        (magic::MERKLEDB_HASH_MODE, NodeHashAlgorithm::MerkleDB),
        (magic::ETHEREUM_HASH_MODE, NodeHashAlgorithm::Ethereum),
    ] {
        let mut data = base.clone();
        data[9] = byte;

        let mut reader = ProofReader::new(&data);
        let header = reader
            .read_header()
            .expect("header should parse successfully");

        let validated_header = header
            .validate(Some(ProofType::Range))
            .expect("hash_mode should validate");

        assert_eq!(validated_header.proof_type, ProofType::Range);
        assert_eq!(
            validated_header.node_hash_algorithm, expected,
            "hash_mode {byte} should resolve to {expected:?}"
        );
    }

    // A byte that maps to no known algorithm is still rejected.
    let mut data = base;
    data[9] = 99;
    let mut reader = ProofReader::new(&data);
    let header = reader
        .read_header()
        .expect("header should parse successfully");

    match header.validate(Some(ProofType::Range)) {
        Err(InvalidHeader::UnsupportedHashMode { found: 99 }) => {}
        other => panic!("expected UnsupportedHashMode {{ found: 99 }}, got: {other:?}"),
    }
}

#[test]
fn test_hash_type_read_dispatches_on_threaded_mode() {
    let raw = [0x11u8; 32];

    // Ethereum wire layout: a 0x00 discriminant followed by the 32 hash bytes.
    let mut eth_bytes = vec![0x00u8];
    eth_bytes.extend_from_slice(&raw);
    let mut eth_reader = ProofReader::new(&eth_bytes).into_body(NodeHashAlgorithm::Ethereum);
    let decoded = eth_reader
        .read_item::<HashType>()
        .expect("eth HashType should decode under Ethereum mode");
    assert_eq!(decoded, HashType::from(TrieHash::from(raw)));
    assert!(eth_reader.remainder().is_empty(), "all eth bytes consumed");

    // MerkleDB wire layout: bare 32 bytes, no discriminant.
    let mut mdb_reader = ProofReader::new(&raw).into_body(NodeHashAlgorithm::MerkleDB);
    let decoded = mdb_reader
        .read_item::<HashType>()
        .expect("merkledb HashType should decode under MerkleDB mode");
    assert_eq!(decoded, HashType::from(TrieHash::from(raw)));
    assert!(
        mdb_reader.remainder().is_empty(),
        "all merkledb bytes consumed"
    );
}

#[test]
fn test_verify_range_proof_rejects_hash_mode_mismatch() {
    let (proof, _) = create_valid_range_proof();
    let other_mode = if proof.hash_mode().is_ethereum() {
        NodeHashAlgorithm::MerkleDB
    } else {
        NodeHashAlgorithm::Ethereum
    };

    // Root hash and keys are irrelevant: the guard fires before any hashing or
    // structural checks. Use a placeholder root.
    let result = crate::merkle::verify_range_proof(
        Some(&[2u8]),
        Some(&[8u8]),
        &TrieHash::from([0u8; 32]),
        other_mode,
        &proof,
    );

    match result {
        Err(crate::api::Error::ProofError(ProofError::HashModeMismatch { expected, found })) => {
            assert_eq!(expected, other_mode);
            assert_eq!(found, proof.hash_mode());
        }
        other => panic!("expected HashModeMismatch, got: {other:?}"),
    }
}

#[test]
fn test_verify_change_proof_structure_rejects_hash_mode_mismatch() {
    let (proof, _) = create_valid_change_proof(DefaultHashMode::ALGORITHM);
    let other_mode = if proof.hash_mode().is_ethereum() {
        NodeHashAlgorithm::MerkleDB
    } else {
        NodeHashAlgorithm::Ethereum
    };

    // The guard fires before any hashing or structural checks; end_root and keys
    // are placeholders.
    let result = crate::verify_change_proof_structure(
        &proof,
        TrieHash::from([0u8; 32]),
        Some(&[2u8]),
        Some(&[8u8]),
        other_mode,
        None,
    );

    match result {
        Err(crate::api::Error::ProofError(ProofError::HashModeMismatch { expected, found })) => {
            assert_eq!(expected, other_mode);
            assert_eq!(found, proof.hash_mode());
        }
        other => panic!("expected HashModeMismatch, got: {other:?}"),
    }
}

#[test]
fn test_value_digest_hash_read_arm_is_unconditional() {
    // ValueDigest::Hash wire layout: 0x01 digest discriminant + a HashType.
    // In MerkleDB mode the HashType is a bare 32-byte hash (no inner
    // discriminant), so this is the canonical on-wire shape of a Hash digest.
    let mut bytes = vec![0x01u8];
    bytes.extend_from_slice(&[0x22u8; 32]);

    let mut reader = ProofReader::new(&bytes).into_body(NodeHashAlgorithm::MerkleDB);
    let decoded = reader
        .read_item::<ValueDigest<&[u8]>>()
        .expect("0x01 Hash discriminant must be accepted unconditionally");
    match decoded {
        ValueDigest::Hash(h) => assert_eq!(h, HashType::from(TrieHash::from([0x22u8; 32]))),
        ValueDigest::Value(_) => panic!("expected ValueDigest::Hash"),
    }
    assert!(reader.remainder().is_empty(), "all bytes consumed");

    // Across modes: an Ethereum-seeded reader also accepts the 0x01 digest
    // discriminant unconditionally; the inner HashType then follows the eth
    // encoding (0x00 Hash discriminant + 32 bytes).
    let mut eth_bytes = vec![0x01u8, 0x00u8];
    eth_bytes.extend_from_slice(&[0x33u8; 32]);
    let mut eth_reader = ProofReader::new(&eth_bytes).into_body(NodeHashAlgorithm::Ethereum);
    let eth_decoded = eth_reader
        .read_item::<ValueDigest<&[u8]>>()
        .expect("0x01 Hash discriminant must be accepted in eth mode too");
    match eth_decoded {
        ValueDigest::Hash(h) => assert_eq!(h, HashType::from(TrieHash::from([0x33u8; 32]))),
        ValueDigest::Value(_) => panic!("expected ValueDigest::Hash"),
    }
    assert!(eth_reader.remainder().is_empty(), "all bytes consumed");
}
