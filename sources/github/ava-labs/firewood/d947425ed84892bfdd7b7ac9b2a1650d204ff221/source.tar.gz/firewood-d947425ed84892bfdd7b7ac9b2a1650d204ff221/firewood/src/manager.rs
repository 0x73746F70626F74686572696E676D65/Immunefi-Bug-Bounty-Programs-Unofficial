// Copyright (C) 2023, Ava Labs, Inc. All rights reserved.
// See the file LICENSE.md for licensing terms.

#![expect(
    clippy::default_trait_access,
    reason = "Found 3 occurrences after enabling the lint."
)]

use nonzero_ext::nonzero;
use parking_lot::{Mutex, RwLock};
use std::collections::{HashMap, VecDeque};
use std::io;
use std::num::{NonZero, NonZeroU64};
use std::path::PathBuf;
use std::sync::{Arc, OnceLock};

use firewood_storage::logger::{trace, warn};
use rayon::{ThreadPool, ThreadPoolBuilder};
use typed_builder::TypedBuilder;

use crate::api::{self, ArcDynDbView, HashKey, IntoBatchIter};
use crate::db::{BatchOp, UseParallel};
use crate::merkle::Merkle;
use crate::merkle::parallel::ParallelMerkle;
use crate::persist_worker::{PersistError, PersistWorker};
use firewood_metrics::{GaugeExt, firewood_counter, firewood_gauge, firewood_histogram};
pub use firewood_storage::CacheReadStrategy;
use firewood_storage::RootStore;
use firewood_storage::{
    BranchNode, CheckOpt, CheckerReport, Committed, CommittedId, DeletedNodeTracking, FileBacked,
    FileIoError, HashMode, HashedNodeReader, ImmutableProposal, Mutable, MutableKind,
    MutableReconNodeStore, NodeStore, NodeStoreHeader, Propose, TrieHash,
};

pub(crate) const DB_FILE_NAME: &str = "firewood.db";

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, TypedBuilder)]
/// Revision manager configuratoin
pub struct RevisionManagerConfig {
    /// The number of committed revisions to keep in memory.
    ///
    /// Must be > `max_persistence_gap`.
    #[builder(default = 128)]
    max_revisions: usize,

    /// The memory limit for the node cache in bytes.
    ///
    /// Defaults to 192MB (equivalent to 1,500,000 nodes × 128 bytes).
    #[builder(default = nonzero!(192_000_000_usize))]
    node_cache_memory_limit: NonZero<usize>,

    /// The memory limit for the free-list cache in kibibytes.
    ///
    /// The cache maps a freed node's address to the next entry in its free list,
    /// so allocation can reuse space without reading it from disk. This limit is
    /// an upper bound converted into an entry count; nothing is preallocated, so
    /// the memory is only used once that many nodes have been freed.
    ///
    /// Defaults to 4MB.
    #[builder(default = nonzero!(4096_usize))]
    freelist_memory_limit_kb: NonZero<usize>,

    #[builder(default = CacheReadStrategy::WritesOnly)]
    cache_read_strategy: CacheReadStrategy,

    /// The maximum number of committed revisions that can be ahead of the last persisted
    /// revision. A commit that would exceed this distance blocks until persistence advances the
    /// checkpoint.
    ///
    /// Consequently, a persisted revision is guaranteed to be found by looking back at most
    /// `max_persistence_gap` revisions from any committed revision.
    ///
    /// Defaults to 1. Must be positive and less than `max_revisions`.
    #[builder(default = nonzero!(1u64))]
    max_persistence_gap: NonZeroU64,
}

#[derive(Clone, Debug, TypedBuilder)]
#[non_exhaustive]
/// Configuration manager that contains both truncate and revision manager config
pub struct ConfigManager {
    /// The directory where the database files will be stored (required).
    pub root_dir: PathBuf,

    /// Whether to create the DB if it doesn't exist.
    #[builder(default = true)]
    pub create: bool,
    /// Whether to truncate the DB when opening it. If set, the DB will be reset and all its
    /// existing contents will be lost.
    #[builder(default = false)]
    pub truncate: bool,
    /// Whether to enable `RootStore`.
    #[builder(default = false)]
    pub root_store: bool,
    /// Revision manager configuration.
    #[builder(default = RevisionManagerConfig::builder().build())]
    pub manager: RevisionManagerConfig,
}

pub type CommittedRevision<H> = Arc<NodeStore<Committed, FileBacked, H>>;
type ProposedRevision<H> = Arc<NodeStore<Arc<ImmutableProposal>, FileBacked, H>>;

/// Manages historical revisions and proposals for a [`crate::db::Db`].
///
/// `H` mirrors the owning database's hash-mode type parameter and is threaded
/// through every managed nodestore (revisions, proposals, and reconstruction
/// chains).
#[derive(Debug)]
pub(crate) struct RevisionManager<H> {
    /// Maximum number of revisions to keep in memory.
    ///
    /// When this limit is exceeded, the oldest revision is removed from memory.
    /// If `root_store` is `None`, the oldest revision's nodes are added to the
    /// free list for space reuse. Otherwise, the oldest revision
    /// is preserved on disk for historical queries.
    max_revisions: usize,

    /// FIFO queue of committed revisions kept in memory. The queue always
    /// contains at least one revision.
    in_memory_revisions: RwLock<VecDeque<CommittedRevision<H>>>,

    /// Hash-based index of committed revisions kept in memory.
    ///
    /// Maps root hash to the corresponding committed revision for O(1) lookup
    /// performance. This allows efficient retrieval of revisions without
    /// scanning through the `in_memory_revisions` queue.
    by_hash: RwLock<HashMap<TrieHash, CommittedRevision<H>>>,

    /// Active proposals that have not yet been committed.
    proposals: Mutex<Vec<ProposedRevision<H>>>,

    /// Lazily initialized thread pool for parallel operations.
    threadpool: OnceLock<ThreadPool>,

    /// Optional persistent store for historical root addresses.
    ///
    /// When present, enables retrieval of revisions beyond `max_revisions` by
    /// persisting root hash to disk address mappings. This allows historical
    /// queries of arbitrarily old revisions without keeping them in memory.
    root_store: Option<Arc<RootStore<H>>>,

    /// Worker responsible for persisting revisions to disk.
    persist_worker: PersistWorker<H>,
}

#[derive(Debug, thiserror::Error)]
pub(crate) enum RevisionManagerError {
    #[error("Revision for {provided:?} not found")]
    RevisionNotFound { provided: HashKey },
    #[error("Revision for {provided:?} has no address")]
    RevisionWithoutAddress { provided: HashKey },
    #[error(
        "The proposal cannot be committed since it is not a direct child of the most recent commit. Proposal parent: {provided:?}, current root: {expected:?}"
    )]
    NotLatest {
        provided: Option<HashKey>,
        expected: Option<HashKey>,
    },
    #[error("A FileIO error occurred during the commit: {0}")]
    FileIoError(#[from] FileIoError),
    #[error("An IO error occurred while creating the database directory: {0}")]
    IOError(#[from] io::Error),
    #[error("A RootStore error occurred: {0}")]
    RootStoreError(#[source] Box<dyn std::error::Error + Send + Sync>),
    #[error("A deferred persistence error occurred: {0}")]
    PersistError(#[source] PersistError),
    #[error(
        "max_revisions ({max_revisions}) must be > max_persistence_gap ({max_persistence_gap})"
    )]
    InsufficientRevisions {
        max_revisions: usize,
        max_persistence_gap: u64,
    },
}

impl<H: HashMode> RevisionManager<H> {
    pub fn new(config: ConfigManager) -> Result<Self, RevisionManagerError> {
        let max_persistence_gap = config.manager.max_persistence_gap.get();
        if (config.manager.max_revisions as u64) <= max_persistence_gap {
            return Err(RevisionManagerError::InsufficientRevisions {
                max_revisions: config.manager.max_revisions,
                max_persistence_gap,
            });
        }

        if config.create {
            std::fs::create_dir_all(&config.root_dir).map_err(RevisionManagerError::IOError)?;
        }

        let file = config.root_dir.join(DB_FILE_NAME);
        let fb = FileBacked::new(
            file,
            config.manager.node_cache_memory_limit,
            config.manager.freelist_memory_limit_kb,
            config.truncate,
            config.create,
            config.manager.cache_read_strategy,
        )?;

        // Acquire an advisory lock on the database file to prevent multiple processes
        // from opening the same database simultaneously
        fb.lock()?;

        let storage = Arc::new(fb);
        let header = match NodeStoreHeader::read_from_storage(storage.as_ref(), H::ALGORITHM) {
            Ok(header) => header,
            Err(err) if err.kind() == io::ErrorKind::UnexpectedEof => {
                // Empty file - create a new header for a fresh database
                NodeStoreHeader::new(H::ALGORITHM)
            }
            Err(err) => return Err(err.into()),
        };

        let deleted_node_tracking = if config.root_store {
            DeletedNodeTracking::Disabled
        } else {
            DeletedNodeTracking::Enabled
        };
        let nodestore = Arc::new(NodeStore::open(
            &header,
            storage.clone(),
            deleted_node_tracking,
        )?);
        let root_store = config
            .root_store
            .then(|| {
                let root_store_dir = config.root_dir.join("root_store");
                RootStore::new(root_store_dir, storage.clone(), config.truncate)
                    .map_err(RevisionManagerError::RootStoreError)
            })
            .transpose()?
            .map(Arc::new);

        if config.truncate {
            header.flush_to(storage.as_ref())?;
            storage.set_len(NodeStoreHeader::SIZE)?;
        }

        let mut by_hash = HashMap::new();
        if let Some(hash) = nodestore.root_hash().or_else(H::default_root_hash) {
            by_hash.insert(hash, nodestore.clone());
        }

        let persist_worker = PersistWorker::new(
            config.manager.max_persistence_gap,
            header,
            root_store.clone(),
        );

        firewood_gauge!(MAX_REVISIONS).set_integer(config.manager.max_revisions);

        let manager = Self {
            max_revisions: config.manager.max_revisions,
            in_memory_revisions: RwLock::new(VecDeque::from([nodestore.clone()])),
            by_hash: RwLock::new(by_hash),
            proposals: Mutex::new(Default::default()),
            threadpool: OnceLock::new(),
            root_store,
            persist_worker,
        };

        // On startup, we always write the latest revision to RootStore
        if let Some(root_hash) = manager.current_revision().root_hash() {
            let root_address = manager.current_revision().root_address().ok_or(
                RevisionManagerError::RevisionWithoutAddress {
                    provided: root_hash.clone(),
                },
            )?;

            if let Some(store) = &manager.root_store {
                store
                    .add_root(&root_hash, &root_address)
                    .map_err(RevisionManagerError::RootStoreError)?;
            }
        }

        Ok(manager)
    }
}

impl<H: HashMode> RevisionManager<H> {
    /// Commit a proposal
    /// To commit a proposal involves a few steps:
    /// 1. Check if the persist worker has failed.
    ///    If so, return the error as this means we won't be able to make any
    ///    further progress.
    /// 2. Commit check.
    ///    The proposal's parent must be the last committed revision, otherwise the commit fails.
    ///    It only contains the address of the nodes that are deleted, which should be very small.
    /// 3. Revision reaping.
    ///    If more than the maximum number of revisions are kept in memory, the
    ///    oldest revision is removed from memory and sent to the `PersistWorker`
    ///    for reaping.
    /// 4. Signal to the `PersistWorker` to persist this revision.
    /// 5. Set last committed revision.
    ///    Set last committed revision in memory.
    /// 6. Proposal Cleanup.
    ///    Any other proposals that have this proposal as a parent should be reparented to the committed version.
    ///
    /// Steps 1 through 5 are executed behind a lock to maintain the invariant
    /// that only one revision can commit at a time.
    #[fastrace::trace(short_name = true)]
    #[crate::metrics(PROPOSAL_COMMITS)]
    pub fn commit(&self, proposal: ProposedRevision<H>) -> Result<(), RevisionManagerError> {
        // Hold a write lock on `in_memory_revisions` for the duration of the
        // critical section (steps 1-5). This is necessary because:
        // 1. Without the lock, two proposals with the same parent could pass the
        //    commit check simultaneously, allowing both to commit.
        // 2. New proposals rely on the latest committed revision via
        //    `current_revision()`, which takes a read lock on `in_memory_revisions`.
        //    The write lock here prevents proposals from being created against
        //    an older revision while a newer revision is mid-commit.
        // BLOCKING: write lock on `in_memory_revisions`. Blocks all concurrent readers
        // (current_revision, view) and any other commit attempts for the full duration of steps
        // 1-5. In high-commit-rate scenarios with many parallel readers, lock contention here
        // may stall reader threads until the commit critical section completes.
        let __lock_start = ::std::time::Instant::now();
        let mut revisions_guard = self.lock_committed_revisions();
        firewood_histogram!(cheap: COMMIT_LOCK_WAIT_SECONDS)
            .record(__lock_start.elapsed().as_secs_f64());

        // Steps 1-5: validate, reap, persist, insert (under write lock)
        let new_id = self.commit_critical_section(&proposal, &mut revisions_guard)?;
        drop(revisions_guard);
        // Step 6: proposal cleanup and reparenting (lock released)
        self.commit_cleanup(&proposal, new_id);
        Ok(())
    }

    /// Acquire an exclusive write guard on the committed revisions queue.
    ///
    /// The guard prevents other commits and blocks `current_revision()` readers
    /// until dropped. Used by [`crate::db::Proposal::commit_with_rebase`] to
    /// hold the lock across a rebase-then-commit sequence, ensuring no other
    /// commit can interleave between the rebase and the commit.
    pub(crate) fn lock_committed_revisions(
        &self,
    ) -> parking_lot::RwLockWriteGuard<'_, VecDeque<CommittedRevision<H>>> {
        self.in_memory_revisions.write()
    }

    /// Validate and commit a proposal under the caller's write guard.
    ///
    /// Checks that the proposal's parent matches the latest revision, reaps
    /// old revisions that exceed `max_revisions`, signals the persist worker,
    /// and inserts the new committed revision into the queue. The caller must
    /// hold the write lock on committed revisions and pass the locked queue in.
    ///
    /// Returns the [`CommittedId`] of the revision the proposal now lives in:
    /// either the freshly-inserted revision for a regular commit, or the
    /// current latest revision's id when the proposal was absorbed by the
    /// trivial fast path (proposal root hash equals the latest revision's).
    /// The caller passes this id to [`Self::commit_cleanup`], which uses it
    /// to reparent any sibling proposals that pointed at the just-committed
    /// proposal.
    pub(crate) fn commit_critical_section(
        &self,
        proposal: &ProposedRevision<H>,
        revisions: &mut VecDeque<CommittedRevision<H>>,
    ) -> Result<CommittedId, RevisionManagerError> {
        // Check if the persist worker has failed.
        self.persist_worker
            .check_error()
            .map_err(RevisionManagerError::PersistError)?;

        let current_revision = revisions.back().expect("there is always one revision");
        if !proposal.parent_id_is(current_revision.committed_id()) {
            return Err(RevisionManagerError::NotLatest {
                provided: proposal.root_hash(),
                expected: current_revision.root_hash(),
            });
        }

        if proposal.root_hash() == current_revision.root_hash() {
            firewood_counter!(PROPOSAL_COMMITS_TRIVIAL).increment(1);
            return Ok(current_revision.committed_id());
        }

        let committed = proposal.as_committed();

        firewood_gauge!(DELETED_LIST_LEN).set_integer(committed.deleted_len());

        // Revision reaping: when we exceed max_revisions, remove the oldest revision from memory
        // and send it to the `PersistWorker`.
        // If you crash after freeing some of these, then the free list will point to nodes that are not actually free.
        // TODO(rkuris): Handle the case where we get something off the free list that is not free
        while revisions.len() >= self.max_revisions {
            let oldest = revisions.pop_front().expect("must be present");
            let oldest_hash = oldest.root_hash().or_else(H::default_root_hash);
            if let Some(ref hash) = oldest_hash {
                // BLOCKING: write lock on `by_hash` while already holding the
                // revisions write lock. Nested locking order must remain
                // consistent (always acquire revisions before `by_hash`) to
                // avoid deadlocks.
                self.by_hash.write().remove(hash);
            }

            // The warning in the docs for `Arc::try_unwrap` does not apply here
            // because `original` is retained and not immediately dropped.
            match Arc::try_unwrap(oldest) {
                Ok(oldest) => self
                    .persist_worker
                    .reap(oldest)
                    .map_err(RevisionManagerError::PersistError)?,
                Err(original) => {
                    warn!("Oldest revision could not be reaped; still referenced");
                    revisions.push_front(original);
                    break;
                }
            }
            firewood_gauge!(ACTIVE_REVISIONS).set_integer(revisions.len());
        }

        let new_id = committed.committed_id();

        // Signal to the `PersistWorker` to persist this revision.
        let committed: CommittedRevision<H> = committed.into();
        let __submit_start = ::std::time::Instant::now();
        self.persist_worker
            .submit_revision(committed.clone())
            .map_err(RevisionManagerError::PersistError)?;
        firewood_histogram!(cheap: PERSIST_SUBMIT_DURATION_SECONDS)
            .record(__submit_start.elapsed().as_secs_f64());

        // Set last committed revision.
        // The revision is added to `by_hash` here while it still exists in `proposals`.
        // The `view()` method relies on this ordering - it checks `proposals` first,
        // then `by_hash`, ensuring the revision is always findable during the transition.
        revisions.push_back(committed.clone());
        if let Some(hash) = committed.root_hash().or_else(H::default_root_hash) {
            // BLOCKING: write lock on `by_hash` (still inside the revisions
            // write lock). Same nested ordering as the reap path above; must
            // not be inverted.
            self.by_hash.write().insert(hash, committed);
        }

        Ok(new_id)
    }

    /// Proposal cleanup and reparenting.
    /// Called after releasing the committed revisions write lock.
    ///
    /// `new_id` is the [`CommittedId`] children of `proposal` should reparent
    /// onto — the value returned by [`Self::commit_critical_section`].
    pub(crate) fn commit_cleanup(&self, proposal: &ProposedRevision<H>, new_id: CommittedId) {
        // Free the proposal being committed and any proposals no longer referenced
        // by anyone else, then reparent the survivors that referenced this proposal.
        // Both phases run under a single lock acquisition so the reparented set is
        // exactly the survivors of cleanup — no other thread can insert or remove
        // proposals between the two phases.
        //
        // BLOCKING: mutex lock on `proposals`. Held while scanning all open proposals
        // (cleanup) and then iterating survivors (reparent). Duration is proportional
        // to the number of live proposals. In pathological cases (many stale proposals)
        // this extends the overall time the commit function runs, though it is no
        // longer inside the `in_memory_revisions` write lock at this point.
        let mut lock = self.proposals.lock();
        let mut discarded = 0u64;
        lock.retain(|p| {
            // The proposal being committed leaves the list but isn't a
            // discard — it was successfully committed. Only abandoned
            // proposals (no external strong refs) count toward
            // PROPOSALS_DISCARDED.
            if Arc::ptr_eq(p, proposal) {
                return false;
            }
            if Arc::strong_count(p) <= 1 {
                discarded = discarded.wrapping_add(1);
                return false;
            }
            true
        });

        if discarded > 0 {
            firewood_counter!(PROPOSALS_DISCARDED).increment(discarded);
        }

        // Update uncommitted proposals gauge after cleanup
        firewood_gauge!(PROPOSALS_UNCOMMITTED).set_integer(lock.len());

        // Reparent any surviving proposals that have this proposal as a parent.
        // `commit_reparent` only locks each proposal's own `parent` field, not
        // `self.proposals`, so calling it under the outer lock cannot deadlock.
        for p in lock.iter() {
            proposal.commit_reparent(p, new_id);
        }
        drop(lock);

        if crate::logger::trace_enabled() {
            let committed = proposal.as_committed();
            let committed: CommittedRevision<H> = committed.into();
            let merkle = Merkle::from(committed);
            if let Ok(s) = merkle.dump_to_string() {
                trace!("{s}");
            }
        }
    }

    /// View the database at a specific hash.
    /// To view the database at a specific hash involves a few steps:
    /// 1. Try to find it in proposals.
    /// 2. Try to find it in committed revisions.
    pub fn view(&self, root_hash: HashKey) -> Result<ArcDynDbView, RevisionManagerError> {
        // 1. Try to find it in proposals.
        // BLOCKING: mutex lock on `proposals` held while scanning all proposals for the target
        // hash. Concurrent commits that need the proposals lock will queue behind this.
        let proposal = self
            .proposals
            .lock()
            .iter()
            .find(|p| p.root_hash().as_ref() == Some(&root_hash))
            .cloned();

        if let Some(proposal) = proposal {
            return Ok(proposal);
        }

        // 2. Try to find it in committed revisions.
        self.revision(root_hash).map(|r| r as ArcDynDbView)
    }

    /// Remove a proposal from the tracking list. Retains all proposals
    /// except the one matching `proposal` by `Arc::ptr_eq`.
    pub fn remove_proposal(&self, proposal: &ProposedRevision<H>) {
        let len = {
            let mut lock = self.proposals.lock();
            lock.retain(|p| !Arc::ptr_eq(p, proposal));
            lock.len()
        };
        firewood_gauge!(PROPOSALS_UNCOMMITTED).set_integer(len);
    }

    pub fn add_proposal(&self, proposal: ProposedRevision<H>) {
        let len = {
            // BLOCKING: mutex lock on `proposals`. Short critical section (just a push), but
            // contends with view(), commit() cleanup, and the reparent loop.
            let mut lock = self.proposals.lock();
            lock.push(proposal);
            lock.len()
        };
        // Update uncommitted proposals gauge after adding
        firewood_gauge!(PROPOSALS_UNCOMMITTED).set_integer(len);
    }

    /// Retrieve a committed revision by its root hash.
    /// To retrieve a revision involves a few steps:
    /// 1. Check the in-memory revision manager.
    /// 2. If the caller requested the default empty-trie hash, return an
    ///    empty committed nodestore.
    /// 3. Check `RootStore` (if it exists).
    pub fn revision(
        &self,
        root_hash: HashKey,
    ) -> Result<CommittedRevision<H>, RevisionManagerError> {
        // 1. Check the in-memory revision manager.
        // BLOCKING: read lock on `by_hash`. Concurrent writes (commit reap/insert) will pause
        // until readers release. Low contention in practice since reads are fast, but parking_lot
        // RwLock favours writers, so a steady stream of commits can starve readers transiently.
        let __lock_start = ::std::time::Instant::now();
        let by_hash = self.by_hash.read();
        firewood_histogram!(cheap: BY_HASH_LOCK_WAIT_SECONDS)
            .record(__lock_start.elapsed().as_secs_f64());
        if let Some(revision) = by_hash.get(&root_hash).cloned() {
            return Ok(revision);
        }
        drop(by_hash);

        // 2. Empty-trie short-circuit for this hash mode. An empty trie has no
        //    on-disk root node, so `RootStore` can never produce it; synthesize
        //    one against the file backing carried by the latest committed
        //    revision.
        if H::default_root_hash().as_ref() == Some(&root_hash) {
            let storage = self.current_revision().storage().clone();
            let deleted_node_tracking = if self.root_store.is_some() {
                DeletedNodeTracking::Disabled
            } else {
                DeletedNodeTracking::Enabled
            };
            return Ok(Arc::new(NodeStore::new_empty_committed(
                storage,
                deleted_node_tracking,
            )));
        }

        // 3. Check `RootStore` (if it exists).
        let root_store =
            self.root_store
                .as_ref()
                .ok_or(RevisionManagerError::RevisionNotFound {
                    provided: root_hash.clone(),
                })?;
        let revision = root_store
            .get(&root_hash)
            .map_err(RevisionManagerError::RootStoreError)?
            .ok_or(RevisionManagerError::RevisionNotFound {
                provided: root_hash.clone(),
            })?;

        Ok(revision)
    }

    pub fn root_hash(&self) -> Option<HashKey> {
        self.current_revision().root_hash()
    }

    pub(crate) fn check(&self, opt: CheckOpt) -> CheckerReport {
        let current_revision = self.current_revision();
        let header = self.persist_worker.locked_header();
        current_revision.check(&header, opt)
    }

    pub fn current_revision(&self) -> CommittedRevision<H> {
        // BLOCKING: read lock on `in_memory_revisions`. Called on every propose() and
        // merge_key_value_range(); blocks while a commit() holds the write lock (steps 1-5).
        let __lock_start = ::std::time::Instant::now();
        let revisions = self.in_memory_revisions.read();
        firewood_histogram!(cheap: CURRENT_REVISION_LOCK_WAIT_SECONDS)
            .record(__lock_start.elapsed().as_secs_f64());
        revisions
            .back()
            .expect("there is always one revision")
            .clone()
    }

    /// Gets or creates a threadpool associated with the revision manager.
    ///
    /// # Panics
    ///
    /// Panics if the it cannot create a thread pool.
    pub fn threadpool(&self) -> &ThreadPool {
        // Note that OnceLock currently doesn't support get_or_try_init (it is available in a
        // nightly release). The get_or_init should be replaced with get_or_try_init once it
        // is available to allow the error to be passed back to the caller.
        self.threadpool.get_or_init(|| {
            ThreadPoolBuilder::new()
                .num_threads(BranchNode::MAX_CHILDREN)
                .build()
                .expect("Error in creating threadpool")
        })
    }

    /// Returns whether a batch should use parallel application based on configuration.
    #[inline]
    fn should_parallelize<I>(use_parallel: &UseParallel, batch_iter: &I) -> bool
    where
        I: Iterator,
    {
        let batch_size_lower_bound = batch_iter.size_hint().0;
        match use_parallel {
            UseParallel::Never => false,
            UseParallel::Always => true,
            UseParallel::BatchSize(required_size) => batch_size_lower_bound >= *required_size,
        }
    }

    /// Applies a batch to a mutable nodestore using the configured parallel policy.
    pub fn apply_batch(
        &self,
        use_parallel: &UseParallel,
        mutable_nodestore: NodeStore<Mutable<Propose>, FileBacked, H>,
        batch: impl IntoBatchIter,
    ) -> Result<NodeStore<Mutable<Propose>, FileBacked, H>, api::Error> {
        let batch = batch.into_iter();
        if Self::should_parallelize(use_parallel, &batch) {
            let mut parallel_merkle = ParallelMerkle::default();
            Ok(parallel_merkle.apply(mutable_nodestore, batch, self.threadpool())?)
        } else {
            Self::apply_batch_serial(mutable_nodestore, batch)
        }
    }

    /// Serial batch application shared by [`apply_batch`][Self::apply_batch].
    fn apply_batch_serial<K: MutableKind, BH: HashMode>(
        mutable_nodestore: NodeStore<Mutable<K>, FileBacked, BH>,
        batch: impl IntoBatchIter,
    ) -> Result<NodeStore<Mutable<K>, FileBacked, BH>, api::Error> {
        let mut merkle = Merkle::from(mutable_nodestore);
        for res in batch.into_batch_iter::<api::Error>() {
            match res? {
                BatchOp::Put { key, value } => {
                    merkle.insert(key.as_ref(), value.as_ref().into())?;
                }
                BatchOp::Delete { key } => {
                    merkle.remove(key.as_ref())?;
                }
                BatchOp::DeleteRange { prefix } => {
                    merkle.remove_prefix(prefix.as_ref())?;
                }
            }
        }
        Ok(merkle.into_inner())
    }

    /// Serial batch application for reconstruction chains.
    pub(crate) fn apply_batch_recon(
        mutable_nodestore: MutableReconNodeStore<FileBacked, H>,
        batch: impl IntoBatchIter,
    ) -> Result<MutableReconNodeStore<FileBacked, H>, api::Error> {
        Self::apply_batch_serial(mutable_nodestore, batch)
    }

    /// Checks if the `PersistWorker` has errored.
    pub fn check_persist_error(&self) -> Result<(), RevisionManagerError> {
        self.persist_worker
            .check_error()
            .map_err(RevisionManagerError::PersistError)
    }

    /// Closes the revision manager gracefully.
    ///
    /// This method shuts down the background persistence worker and persists
    /// the latest committed revision.
    pub fn close(self) -> Result<(), RevisionManagerError> {
        let current_revision = self.current_revision();
        self.persist_worker
            .close(current_revision)
            .map_err(RevisionManagerError::PersistError)
    }
}

#[cfg(test)]
mod tests {
    use firewood_storage::{DefaultHashMode, RootReader};

    use super::*;
    #[cfg(feature = "ethhash")]
    use crate::api::HashKeyExt;
    use crate::api::OptionalHashKeyExt;

    impl RevisionManager<DefaultHashMode> {
        /// Get all proposal hashes available.
        pub fn proposal_hashes(&self) -> Vec<TrieHash> {
            self.proposals
                .lock()
                .iter()
                .filter_map(|p| p.root_hash().or_default_root_hash())
                .collect()
        }

        /// Wait until all pending commits have been persisted.
        pub(crate) fn wait_persisted(&self) {
            self.persist_worker.wait_persisted();
        }

        /// Returns true if the root node (if it exists) of this revision is
        /// persisted. Otherwise, returns false.
        ///
        /// ## Errors
        ///
        /// Returns an error if the revision does not exist.
        pub(crate) fn revision_persist_status(
            &self,
            root_hash: TrieHash,
        ) -> Result<bool, RevisionManagerError> {
            let revision = self.revision(root_hash)?;
            Ok(revision
                .root_as_maybe_persisted_node()
                .is_some_and(|node| node.unpersisted().is_none()))
        }
    }

    #[test]
    fn test_file_advisory_lock() {
        // Create a temporary file for testing
        let db_dir = tempfile::tempdir().unwrap();

        let config = ConfigManager::builder()
            .root_dir(db_dir.as_ref().to_path_buf())
            .create(true)
            .truncate(false)
            .build();

        // First database instance should open successfully
        let first_manager = RevisionManager::<DefaultHashMode>::new(config.clone());
        assert!(
            first_manager.is_ok(),
            "First database should open successfully"
        );

        // Second database instance should fail to open due to file locking
        let second_manager = RevisionManager::<DefaultHashMode>::new(config.clone());
        assert!(
            second_manager.is_err(),
            "Second database should fail to open"
        );

        // Verify the error message contains the expected information
        let error = second_manager.unwrap_err();
        let error_string = error.to_string();

        assert!(
            error_string.contains("database may be opened by another instance"),
            "Error is missing 'database may be opened by another instance', got: {error_string}"
        );

        // The file lock is held by the FileBacked instance. When we drop the first_manager,
        // the Arc<FileBacked> should be dropped, releasing the file lock.
        drop(first_manager.unwrap());

        // Now the second database should open successfully
        let third_manager = RevisionManager::<DefaultHashMode>::new(config);
        assert!(
            third_manager.is_ok(),
            "Database should open after first instance is dropped"
        );
    }

    #[test]
    #[expect(clippy::too_many_lines)]
    fn test_slow_concurrent_view_during_commit() {
        use firewood_storage::{
            ImmutableProposal, LeafNode, NibblesIterator, Node, NodeStore, Path,
        };
        use std::sync::Barrier;
        use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
        use std::thread;

        const NUM_ITERATIONS: usize = 1000;
        const NUM_VIEWER_THREADS: usize = 10;
        const NUM_COMMITTER_THREADS: usize = 5;

        // Create a temporary database
        let db_dir = tempfile::tempdir().unwrap();

        let config = ConfigManager::builder()
            .root_dir(db_dir.as_ref().to_path_buf())
            .create(true)
            .manager(
                RevisionManagerConfig::builder()
                    .max_revisions(100_000) // Set very high to prevent reaping during test
                    .build(),
            )
            .build();

        let manager = Arc::new(RevisionManager::<DefaultHashMode>::new(config).unwrap());

        // Create an initial proposal and commit it to have a non-empty base
        let base_revision = manager.current_revision();
        let mut proposal = NodeStore::new(&*base_revision).unwrap();
        {
            let root = proposal.root_mut();
            *root = Some(Node::Leaf(LeafNode {
                partial_path: Path::from_nibbles_iterator(NibblesIterator::new(b"initial")),
                value: b"value".to_vec().into_boxed_slice(),
            }));
        }
        let proposal: Arc<NodeStore<Arc<ImmutableProposal>, _, DefaultHashMode>> =
            Arc::new(proposal.try_into().unwrap());
        manager.add_proposal(proposal.clone());
        manager.commit(proposal).unwrap();

        let error_count = Arc::new(AtomicUsize::new(0));
        let stop_flag = Arc::new(AtomicBool::new(false));
        let barrier = Arc::new(Barrier::new(NUM_VIEWER_THREADS + NUM_COMMITTER_THREADS));

        let mut handles = vec![];

        // Spawn viewer threads
        for thread_id in 0..NUM_VIEWER_THREADS {
            let manager = Arc::clone(&manager);
            let error_count = Arc::clone(&error_count);
            let stop_flag = Arc::clone(&stop_flag);
            let barrier = Arc::clone(&barrier);

            let handle = thread::spawn(move || {
                barrier.wait(); // Synchronize thread start

                let mut local_errors = 0;
                for _ in 0..NUM_ITERATIONS {
                    if stop_flag.load(Ordering::Relaxed) {
                        break;
                    }

                    // Try to view the current revision
                    let current_hash = manager.current_revision().root_hash();
                    if let Some(hash) = current_hash {
                        match manager.view(hash.clone()) {
                            Ok(_) => {}
                            Err(RevisionManagerError::RevisionNotFound { .. }) => {
                                local_errors += 1;
                                eprintln!("Thread {thread_id}: RevisionNotFound for hash {hash:?}");
                            }
                            Err(e) => {
                                eprintln!("Thread {thread_id}: Unexpected error: {e:?}");
                            }
                        }
                    }

                    // Small yield to increase contention
                    thread::yield_now();
                }

                error_count.fetch_add(local_errors, Ordering::Relaxed);
            });

            handles.push(handle);
        }

        // Spawn committer threads
        for thread_id in 0..NUM_COMMITTER_THREADS {
            let manager = Arc::clone(&manager);
            let stop_flag = Arc::clone(&stop_flag);
            let barrier = Arc::clone(&barrier);

            let handle = thread::spawn(move || {
                barrier.wait(); // Synchronize thread start

                for i in 0..NUM_ITERATIONS {
                    if stop_flag.load(Ordering::Relaxed) {
                        break;
                    }

                    // Create and commit a proposal
                    let current = manager.current_revision();
                    let mut new_proposal = match NodeStore::new(&*current) {
                        Ok(p) => p,
                        Err(e) => {
                            eprintln!("Thread {thread_id}: Failed to create proposal: {e:?}");
                            continue;
                        }
                    };

                    // Modify the proposal
                    {
                        let root = new_proposal.root_mut();
                        let key = format!("key_{thread_id}_{i}");
                        *root = Some(Node::Leaf(LeafNode {
                            partial_path: Path::from_nibbles_iterator(NibblesIterator::new(
                                key.as_bytes(),
                            )),
                            value: format!("value_{i}").as_bytes().to_vec().into_boxed_slice(),
                        }));
                    }

                    let immutable: Arc<NodeStore<Arc<ImmutableProposal>, _, DefaultHashMode>> =
                        Arc::new(match new_proposal.try_into() {
                            Ok(p) => p,
                            Err(e) => {
                                eprintln!(
                                    "Thread {thread_id}: Failed to convert to immutable: {e:?}"
                                );
                                continue;
                            }
                        });

                    manager.add_proposal(immutable.clone());

                    match manager.commit(immutable) {
                        Ok(()) | Err(RevisionManagerError::NotLatest { .. }) => {
                            // Expected when multiple threads try to commit
                        }
                        Err(e) => {
                            eprintln!("Thread {thread_id}: Unexpected commit error: {e:?}");
                            stop_flag.store(true, Ordering::Relaxed);
                            break;
                        }
                    }

                    thread::yield_now();
                }
            });

            handles.push(handle);
        }

        // Wait for all threads to complete
        for handle in handles {
            handle.join().unwrap();
        }

        let total_errors = error_count.load(Ordering::Relaxed);

        if total_errors > 0 {
            eprintln!(
                "\nRace condition detected! {total_errors} RevisionNotFound errors occurred."
            );
            eprintln!("This confirms the race condition exists between commit and view.");
        } else {
            eprintln!(
                "\nNo race condition detected in this run. Try running the test multiple times or increasing iterations."
            );
        }

        // For now, we expect the race to occur, so we fail if we see errors
        assert_eq!(
            total_errors, 0,
            "Race condition detected: {total_errors} threads failed to find revisions that should exist"
        );
    }

    #[test]
    fn test_no_fjall_directory_when_root_store_disabled() {
        // Create a temporary directory for the database
        let db_dir = tempfile::tempdir().unwrap();
        let db_path = db_dir.as_ref().to_path_buf();

        // Create a database with root_store disabled (default)
        let config = ConfigManager::builder()
            .root_dir(db_path.clone())
            .create(true)
            .root_store(false)
            .build();

        let _manager = RevisionManager::<DefaultHashMode>::new(config).unwrap();

        // Verify that the root_store directory does NOT exist
        let root_store_dir = db_path.join("root_store");
        assert!(
            !root_store_dir.exists(),
            "root_store directory should not be created when root_store is disabled"
        );
    }

    #[test]
    fn test_fjall_directory_when_root_store_enabled() {
        // Create a temporary directory for the database
        let db_dir = tempfile::tempdir().unwrap();
        let db_path = db_dir.as_ref().to_path_buf();

        // Create a database with root_store enabled
        let config = ConfigManager::builder()
            .root_dir(db_path.clone())
            .create(true)
            .root_store(true)
            .build();

        let _manager = RevisionManager::<DefaultHashMode>::new(config).unwrap();

        // Verify that the root_store directory DOES exist
        let root_store_dir = db_path.join("root_store");
        assert!(
            root_store_dir.exists(),
            "root_store directory should be created when root_store is enabled"
        );
    }

    #[test]
    fn test_revision_count() {
        let db_dir = tempfile::tempdir().unwrap();
        let max_persistence_gap = nonzero!(10u64);

        // `max_revisions` < `max_persistence_gap`
        let config = ConfigManager::builder()
            .root_dir(db_dir.as_ref().to_path_buf())
            .create(true)
            .manager(
                RevisionManagerConfig::builder()
                    .max_revisions(5)
                    .max_persistence_gap(max_persistence_gap)
                    .build(),
            )
            .build();

        let result = RevisionManager::<DefaultHashMode>::new(config);
        assert!(result.is_err());

        // `max_revisions` == `max_persistence_gap`
        let config = ConfigManager::builder()
            .root_dir(db_dir.as_ref().to_path_buf())
            .manager(
                RevisionManagerConfig::builder()
                    .max_revisions(max_persistence_gap.get() as usize)
                    .max_persistence_gap(max_persistence_gap)
                    .build(),
            )
            .build();

        let result = RevisionManager::<DefaultHashMode>::new(config);
        assert!(result.is_err());

        // `max_revisions` > `max_persistence_gap`
        let max_revisions = max_persistence_gap.get().wrapping_add(1) as usize;
        let config = ConfigManager::builder()
            .root_dir(db_dir.as_ref().to_path_buf())
            .manager(
                RevisionManagerConfig::builder()
                    .max_revisions(max_revisions)
                    .max_persistence_gap(max_persistence_gap)
                    .build(),
            )
            .build();

        let result = RevisionManager::<DefaultHashMode>::new(config);
        assert!(result.is_ok());
    }

    /// Under `ethhash`, an empty committed revision is exposed via the
    /// Ethereum empty-trie hash but never indexed in `RootStore` (an empty
    /// trie has no on-disk root node, so there is no `LinearAddress` to
    /// record). Once the in-memory entry is evicted from `by_hash`,
    /// `revision()` previously fell through to `RootStore::get` and returned
    /// `RevisionNotFound`. The fix synthesizes an empty committed nodestore
    /// when the caller asks for the default empty-trie hash.
    #[cfg(feature = "ethhash")]
    #[test]
    fn test_revision_empty_root_after_eviction() {
        use firewood_storage::{LeafNode, NibblesIterator, Node, Path};

        let empty_hash =
            HashKey::default_root_hash().expect("ethhash exposes a default empty-trie hash");

        let db_dir = tempfile::tempdir().unwrap();
        let config = ConfigManager::builder()
            .root_dir(db_dir.as_ref().to_path_buf())
            .create(true)
            .manager(
                // Smallest legal queue: max_revisions must exceed
                // max_persistence_gap (default 1). Two slots is
                // enough for the initial empty revision to be reaped after a
                // pair of non-empty commits.
                RevisionManagerConfig::builder().max_revisions(2).build(),
            )
            .build();

        let manager = RevisionManager::<DefaultHashMode>::new(config).unwrap();

        // Sanity: the fresh manager indexes the empty revision under the
        // default hash.
        assert!(manager.revision(empty_hash.clone()).is_ok());

        // Commit two non-empty revisions to push the empty one out of the
        // in-memory queue and out of `by_hash`.
        for i in 0..2u8 {
            let base = manager.current_revision();
            let mut proposal = NodeStore::new(&*base).unwrap();
            *proposal.root_mut() = Some(Node::Leaf(LeafNode {
                partial_path: Path::from_nibbles_iterator(NibblesIterator::new(&[i])),
                value: Box::new([i]),
            }));
            let proposal: Arc<NodeStore<Arc<ImmutableProposal>, _, DefaultHashMode>> =
                Arc::new(proposal.try_into().unwrap());
            manager.add_proposal(proposal.clone());
            manager.commit(proposal).unwrap();
        }

        // Verify the empty revision has actually been evicted from the
        // in-memory index — otherwise the next assertion would just be
        // testing the step-1 path again.
        assert!(
            !manager.by_hash.read().contains_key(&empty_hash),
            "precondition: empty-trie revision must have been evicted from by_hash"
        );

        // Empty hash should still resolve via the default-hash short-circuit.
        let revision = manager
            .revision(empty_hash.clone())
            .expect("empty-trie revision must resolve via the default-hash short-circuit");
        assert!(revision.root_address().is_none());
    }
}
