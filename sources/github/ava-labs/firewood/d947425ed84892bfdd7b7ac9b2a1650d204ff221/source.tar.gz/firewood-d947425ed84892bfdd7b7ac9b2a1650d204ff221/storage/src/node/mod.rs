// Copyright (C) 2023, Ava Labs, Inc. All rights reserved.
// See the file LICENSE.md for licensing terms.

#![expect(
    clippy::items_after_statements,
    reason = "Found 2 occurrences after enabling the lint."
)]
#![expect(
    clippy::missing_errors_doc,
    reason = "Found 1 occurrences after enabling the lint."
)]
#![expect(
    clippy::missing_panics_doc,
    reason = "Found 1 occurrences after enabling the lint."
)]

use crate::node::branch::ReadSerializable;
use crate::nodestore::AreaIndex;
use crate::{HashMode, LinearAddress, Path, PathBuf, PathComponent, SharedNode};
use bitfield::bitfield;
pub use branch::{BranchNode, Child};
pub use children::{Children, ChildrenSlots, DenseChildren};
use enum_as_inner::EnumAsInner;
use integer_encoding::{VarInt, VarIntReader as _};
pub use leaf::LeafNode;
use std::fmt::Debug;
use std::io::{Error, Read, Write};

pub mod branch;
pub mod children;
mod leaf;
pub mod path;
pub mod persist;
/// A node, either a Branch or Leaf

// TODO(rkuris): explain why Branch is boxed but Leaf is not
#[derive(PartialEq, Eq, Clone, Debug, EnumAsInner)]
#[repr(C)]
pub enum Node {
    /// This node is a [`BranchNode`]
    Branch(Box<BranchNode>),
    /// This node is a [`LeafNode`]
    Leaf(LeafNode),
}

impl lru_mem::HeapSize for Node {
    fn heap_size(&self) -> usize {
        match self {
            Node::Branch(branch) => {
                std::mem::size_of::<BranchNode>().wrapping_add(branch.heap_size())
            }
            Node::Leaf(leaf) => leaf.heap_size(),
        }
    }
}

impl Default for Node {
    fn default() -> Self {
        Node::Leaf(LeafNode {
            partial_path: Path::new(),
            value: Box::default(),
        })
    }
}

impl From<BranchNode> for Node {
    fn from(branch: BranchNode) -> Self {
        Node::Branch(Box::new(branch))
    }
}

impl From<LeafNode> for Node {
    fn from(leaf: LeafNode) -> Self {
        Node::Leaf(leaf)
    }
}

bitfield! {
    struct BranchFirstByte(u8);
    impl Debug;
    impl new;
    u8;
    has_value, set_has_value: 1, 1;
    number_children, set_number_children: 5, 2;
    partial_path_length, set_partial_path_length: 7, 6;
}
const BRANCH_PARTIAL_PATH_LEN_OVERFLOW: u8 = (1 << 2) - 1; // 3 nibbles

bitfield! {
    struct LeafFirstByte(u8);
    impl Debug;
    impl new;
    u8;
    is_leaf, set_is_leaf: 0, 0;
    partial_path_length, set_partial_path_length: 7, 1;
}

const LEAF_PARTIAL_PATH_LEN_OVERFLOW: u8 = (1 << 7) - 2; // 126 nibbles (-1 for indicating Free Area (0xff))

impl Default for LeafFirstByte {
    fn default() -> Self {
        LeafFirstByte(1)
    }
}

// TODO(rkuris): Unstable extend_reserve re-implemented here
// Extend<A>::extend_reserve is unstable so we implement it here
// see https://github.com/rust-lang/rust/issues/72631
pub trait ExtendableBytes: Write {
    fn extend<T: IntoIterator<Item = u8>>(&mut self, other: T);
    fn reserve(&mut self, reserve: usize) {
        let _ = reserve;
    }
    fn push(&mut self, value: u8);

    fn extend_from_slice(&mut self, other: &[u8]) {
        self.extend(other.iter().copied());
    }

    /// Write a variable-length integer to the buffer without allocating an
    /// intermediate buffer on the heap.
    ///
    /// This uses a stack buffer for holding the encoded integer and copies it
    /// into the buffer.
    #[expect(clippy::indexing_slicing)]
    fn extend_var_int<VI: VarInt>(&mut self, int: VI) {
        let mut buf = [0u8; 10];
        let len = VarInt::encode_var(int, &mut buf);
        self.extend_from_slice(&buf[..len]);
    }
}

impl ExtendableBytes for Vec<u8> {
    fn extend<T: IntoIterator<Item = u8>>(&mut self, other: T) {
        std::iter::Extend::extend(self, other);
    }
    fn reserve(&mut self, reserve: usize) {
        self.reserve(reserve);
    }
    fn push(&mut self, value: u8) {
        Vec::push(self, value);
    }
    fn extend_from_slice(&mut self, other: &[u8]) {
        Vec::extend_from_slice(self, other);
    }
}

impl ExtendableBytes for bumpalo::collections::Vec<'_, u8> {
    fn extend<T: IntoIterator<Item = u8>>(&mut self, other: T) {
        std::iter::Extend::extend(self, other);
    }
    fn reserve(&mut self, reserve: usize) {
        bumpalo::collections::Vec::reserve(self, reserve);
    }
    fn push(&mut self, value: u8) {
        bumpalo::collections::Vec::push(self, value);
    }
    fn extend_from_slice(&mut self, other: &[u8]) {
        bumpalo::collections::Vec::extend_from_slice(self, other);
    }
}

impl Node {
    /// Returns the partial path of the node.
    #[must_use]
    pub fn partial_path(&self) -> &Path {
        match self {
            Node::Branch(b) => &b.partial_path,
            Node::Leaf(l) => &l.partial_path,
        }
    }

    /// Updates the partial path of the node to `partial_path`.
    pub fn update_partial_path(&mut self, partial_path: Path) {
        match self {
            Node::Branch(b) => b.partial_path = partial_path,
            Node::Leaf(l) => l.partial_path = partial_path,
        }
    }

    /// Updates the value of the node to `value`.
    pub fn update_value(&mut self, value: Box<[u8]>) {
        match self {
            Node::Branch(b) => b.value = Some(value),
            Node::Leaf(l) => l.value = value,
        }
    }

    /// Returns Some(value) inside the node, or None if the node is a branch
    /// with no value.
    #[must_use]
    pub fn value(&self) -> Option<&[u8]> {
        match self {
            Node::Branch(b) => b.value.as_deref(),
            Node::Leaf(l) => Some(&l.value),
        }
    }

    /// Given a [Node], returns a set of bytes to write to storage
    /// The format is as follows:
    ///
    /// For a branch:
    ///  - Byte 0:
    ///   - Bit 0: always 0
    ///   - Bit 1: indicates if the branch has a value
    ///   - Bits 2-5: the number of children
    ///   - Bits 6-7: 0: empty `partial_path`, 1: 1 nibble, 2: 2 nibbles, 3: length is encoded in the next byte
    ///
    /// The remaining bytes are in the following order:
    ///   - The partial path, possibly preceeded by the length if it is longer than 3 nibbles (varint encoded)
    ///   - The number of children, if the branch factor is 256
    ///   - The children. If the number of children == [`BranchNode::MAX_CHILDREN`], then the children are just
    ///     addresses with hashes. Otherwise, they are offset, address, hash tuples.
    ///
    /// For a leaf:
    ///  - Byte 0:
    ///    - Bit 0: always 1
    ///    - Bits 1-7: the length of the partial path. If the partial path is longer than 126 nibbles, this is set to
    ///      126 and the length is encoded in the next byte.
    ///
    /// The remaining bytes are in the following order:
    ///    - The partial path, possibly preceeded by the length if it is longer than 126 nibbles (varint encoded)
    ///    - The value, always preceeded by the length, varint encoded
    ///
    /// Note that this means the first byte cannot be 255, which would be a leaf with 127 nibbles. We save this extra
    /// value to mark this as a freed area.
    ///
    /// The first byte of the encoding is the area size index, which is calculated from the total
    /// size of the encoded node. This method returns the `AreaIndex` for the encoded node.
    ///
    /// TODO(rkuris): We could pack two bytes of the partial path into one and handle the odd byte length
    ///
    /// # Errors
    ///
    /// Returns an error if the encoded size exceeds the maximum area size.
    pub fn as_bytes<H, T>(&self, encoded: &mut T) -> Result<AreaIndex, Error>
    where
        H: HashMode,
        T: ExtendableBytes + AsRef<[u8]> + std::ops::IndexMut<usize, Output = u8>,
    {
        // Push placeholder for area size index (will be updated later)
        let area_size_index_position = encoded.as_ref().len();
        encoded.push(0);

        match self {
            Node::Branch(b) => {
                let child_iter = b.children.iter_present();
                let childcount = child_iter.clone().count();

                // encode the first byte
                let pp_len = match b.partial_path.len() {
                    // less than 3 or 62 nibbles
                    len if len < BRANCH_PARTIAL_PATH_LEN_OVERFLOW as usize => len as u8,
                    _ => BRANCH_PARTIAL_PATH_LEN_OVERFLOW,
                };

                let first_byte: BranchFirstByte = BranchFirstByte::new(
                    u8::from(b.value.is_some()),
                    (childcount % BranchNode::MAX_CHILDREN) as u8,
                    pp_len,
                );

                // create an output stack item, which can overflow to memory for very large branch nodes
                const OPTIMIZE_BRANCHES_FOR_SIZE: usize = 1024;
                encoded.reserve(OPTIMIZE_BRANCHES_FOR_SIZE);
                encoded.push(first_byte.0);

                // encode the partial path, including the length if it didn't fit above
                if pp_len == BRANCH_PARTIAL_PATH_LEN_OVERFLOW {
                    encoded.extend_var_int(b.partial_path.len());
                }
                encoded.extend_from_slice(&b.partial_path);

                // encode the value. For tries that have the same length keys, this is always empty
                if let Some(v) = &b.value {
                    encoded.extend_var_int(v.len());
                    encoded.extend_from_slice(v);
                }

                // encode the children
                if childcount == BranchNode::MAX_CHILDREN {
                    for (_, child) in child_iter {
                        let (address, hash) = child
                            .persist_info()
                            .expect("child must be hashed when serializing");
                        encoded.extend_from_slice(&address.get().to_ne_bytes());
                        H::write_child_hash(hash, encoded)?;
                    }
                } else {
                    for (position, child) in child_iter {
                        encoded.extend_var_int(position.as_u8());
                        let (address, hash) = child
                            .persist_info()
                            .expect("child must be hashed when serializing");
                        encoded.extend_from_slice(&address.get().to_ne_bytes());
                        H::write_child_hash(hash, encoded)?;
                    }
                }
            }
            Node::Leaf(l) => {
                let pp_len = match l.partial_path.len() {
                    // less than 126 nibbles
                    len if len < LEAF_PARTIAL_PATH_LEN_OVERFLOW as usize => len as u8,
                    _ => LEAF_PARTIAL_PATH_LEN_OVERFLOW,
                };
                let first_byte: LeafFirstByte = LeafFirstByte::new(1, pp_len);

                const OPTIMIZE_LEAVES_FOR_SIZE: usize = 128;
                encoded.reserve(OPTIMIZE_LEAVES_FOR_SIZE);
                encoded.push(first_byte.0);

                // encode the partial path, including the length if it didn't fit above
                if pp_len == LEAF_PARTIAL_PATH_LEN_OVERFLOW {
                    encoded.extend_var_int(l.partial_path.len());
                }
                encoded.extend_from_slice(&l.partial_path);

                // encode the value
                encoded.extend_var_int(l.value.len());
                encoded.extend_from_slice(&l.value);
            }
        }

        // Calculate the area index from the encoded length (subtract position to get just this node's size)
        let node_size = encoded
            .as_ref()
            .len()
            .checked_sub(area_size_index_position)
            .expect("area_size_index_position should always be <= encoded length");
        let area_index = AreaIndex::from_size(node_size as u64)?;

        // Update the first byte with the correct area size index
        encoded[area_size_index_position] = area_index.get();

        Ok(area_index)
    }

    /// Given a reader, return a [Node] from those bytes, deserializing child
    /// hashes under the scheme `H`.
    pub fn from_reader<H: HashMode>(mut serialized: &mut impl Read) -> Result<Self, Error> {
        match serialized.read_byte()? {
            255 => {
                // this is a freed area
                Err(Error::other("attempt to read freed area"))
            }
            first_byte if first_byte & 1 == 1 => {
                let partial_path = read_path_with_overflow_length(
                    &mut serialized,
                    first_byte >> 1,
                    LEAF_PARTIAL_PATH_LEN_OVERFLOW,
                )?;
                let value_len = serialized.read_varint()?;
                let value = serialized.read_fixed_len(value_len)?;
                Ok(Node::Leaf(LeafNode {
                    partial_path,
                    value: value.into(),
                }))
            }
            branch_first_byte => {
                let branch_first_byte = BranchFirstByte(branch_first_byte);

                let has_value = branch_first_byte.has_value() == 1;
                let childcount = branch_first_byte.number_children() as usize;

                let partial_path = read_path_with_overflow_length(
                    &mut serialized,
                    branch_first_byte.partial_path_length(),
                    BRANCH_PARTIAL_PATH_LEN_OVERFLOW,
                )?;

                let value = if has_value {
                    let value_len = serialized.read_varint()?;
                    let value = serialized.read_fixed_len(value_len)?;
                    Some(value.into())
                } else {
                    None
                };

                let mut children = Children::new();
                if childcount == 0 {
                    // branch is full of all children
                    for (_, child) in &mut children {
                        // TODO(rkuris): we can read them all at once
                        let mut address_buf = [0u8; 8];
                        serialized.read_exact(&mut address_buf)?;
                        let address = u64::from_ne_bytes(address_buf);

                        let hash = H::read_child_hash(&mut serialized)?;

                        *child = Some(Child::AddressWithHash(
                            LinearAddress::new(address)
                                .ok_or(Error::other("zero address in child"))?,
                            hash,
                        ));
                    }
                } else {
                    for _ in 0..childcount {
                        let mut position_buf = [0u8; 1];
                        serialized.read_exact(&mut position_buf)?;
                        let position =
                            PathComponent::try_new(position_buf[0]).ok_or_else(|| {
                                Error::other(format!(
                                    "invalid child position {:02x}",
                                    position_buf[0]
                                ))
                            })?;

                        let mut address_buf = [0u8; 8];
                        serialized.read_exact(&mut address_buf)?;
                        let address = u64::from_ne_bytes(address_buf);

                        let hash = H::read_child_hash(&mut serialized)?;

                        children[position] = Some(Child::AddressWithHash(
                            LinearAddress::new(address)
                                .ok_or(Error::other("zero address in child"))?,
                            hash,
                        ));
                    }
                }

                Ok(Node::Branch(Box::new(BranchNode {
                    partial_path,
                    value,
                    children,
                })))
            }
        }
    }

    /// Force the node (which should be a root of a trie) into a branch with no partial path
    /// in preparation for a parallel insert. There are two cases to handle depending on whether
    /// the node has a partial path.
    ///
    /// 1.  If the node has a partial path, then create a new node with an empty partial path
    ///     and a None for a value. Push down the previous node as a child and return the
    ///     branch.
    /// 2.  If the existing node does not have a partial path, then there is nothing we need
    ///     to do if it is a branch. If it is a leaf, then convert it into a branch.
    ///
    /// # Errors
    ///
    /// Returns an `Error` if it cannot create a `PathComponent` from a u8 index.
    pub fn force_branch_for_insert(mut self) -> Result<Box<BranchNode>, Error> {
        // If the `partial_path` is non-empty, then create a branch that will be the new
        // root with the previous root as the child at the index returned from split_first.
        if let Some((child_index, child_path)) = self
            .partial_path()
            .split_first()
            .map(|(index, path)| (*index, path.into()))
        {
            let mut branch = BranchNode {
                partial_path: Path::new(),
                value: None,
                children: Children::default(),
            };
            self.update_partial_path(child_path);
            let child_path_component = PathComponent::try_new(child_index)
                .ok_or_else(|| Error::other("invalid child index"))?;
            *branch.children.get_mut(child_path_component) = Some(Child::Node(self));
            Ok(branch.into())
        } else {
            Ok(match self {
                Node::Leaf(leaf) => {
                    // Root is a leaf with an empty partial path. Replace it with a branch.
                    BranchNode {
                        partial_path: Path::new(),
                        value: Some(leaf.value),
                        children: Children::default(),
                    }
                    .into()
                }
                Node::Branch(branch) => branch,
            })
        }
    }
}

/// A path iterator item, which has the key nibbles up to this point,
/// a node, the address of the node, and the nibble that points to the
/// next child down the list
#[derive(Debug)]
pub struct PathIterItem {
    /// The key of the node at `address` as nibbles.
    pub key_nibbles: PathBuf,
    /// A reference to the node
    pub node: SharedNode,
    /// The next item returned by the iterator is a child of `node`.
    /// Specifically, it's the child at index `next_nibble` in `node`'s
    /// children array.
    /// None if `node` is the last node in the path.
    pub next_nibble: Option<PathComponent>,
    /// Whether the source database requires storageRoot recomputation at
    /// proof-generation time. Older databases (pre-`firewood-v1-hfix`) stored
    /// caller-supplied account bytes verbatim and need the splice; newer
    /// databases persist the correct value during hashing.
    pub must_recompute_storage_hash: bool,
}

fn read_path_with_overflow_length(
    reader: &mut impl Read,
    value: u8,
    overflow: u8,
) -> std::io::Result<Path> {
    if value < overflow {
        // the value is less than the overflow, so we can read it directly
        read_path_with_provided_length(reader, value as usize)
    } else {
        read_path_with_prefix_length(reader)
    }
}

#[cold]
#[inline(never)]
fn read_path_with_prefix_length(reader: &mut impl Read) -> std::io::Result<Path> {
    let len = reader.read_varint()?;
    read_path_with_provided_length(reader, len)
}

#[inline]
fn read_path_with_provided_length(reader: &mut impl Read, len: usize) -> std::io::Result<Path> {
    reader.read_fixed_len(len).map(Path::from)
}

struct DisplayTruncatedHex<'a>(&'a [u8]);

impl std::fmt::Display for DisplayTruncatedHex<'_> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        if let Some(truncated) = self.0.get(0..256)
            && truncated.len() < self.0.len()
        {
            write!(f, "0x{}... (len={})", hex::encode(truncated), self.0.len())
        } else {
            write!(f, "0x{}", hex::encode(self.0))
        }
    }
}

#[cfg(test)]
mod snapshot_tests;

#[cfg(test)]
mod test {
    #[cfg(feature = "ethhash")]
    use crate::DefaultHashMode;
    use crate::node::{BranchNode, LeafNode, Node};
    use crate::{
        Child, Children, EthHash, HashMode, LinearAddress, MerkleDbHash, NibblesIterator,
        NodeHashAlgorithm, Path,
    };
    use firewood_macros::hash_mode;
    use test_case::test_case;

    #[hash_mode]
    #[test_case(
        Node::Leaf(LeafNode {
            partial_path: Path::from(vec![0, 1, 2, 3]),
            value: vec![4, 5, 6, 7].into()
        }), 11; "leaf node with value")]
    #[test_case(
        Node::Leaf(LeafNode {
            partial_path: Path::from_nibbles_iterator(NibblesIterator::new(b"this is a really long partial path, like so long it's more than 63 nibbles long which triggers #1056.")),
            value: vec![4, 5, 6, 7].into()
        }), 211; "leaf node obnoxiously long partial path")]
    #[test_case(Node::Branch(Box::new(BranchNode {
        partial_path: Path::from(vec![0, 1]),
        value: None,
        children: Children::from_fn(|i| {
            if i.as_u8() == 15 {
                Some(Child::AddressWithHash(LinearAddress::new(1).unwrap(), std::array::from_fn::<u8, 32, _>(|i| i as u8).into()))
            } else {
                None
            }
        })})), 45; "one child branch node with short partial path and no value"
    )]
    #[test_case(Node::Branch(Box::new(BranchNode {
        partial_path: Path::from(vec![0, 1, 2, 3]),
        value: Some(vec![4, 5, 6, 7].into()),
        // Each child's hash starts with its own nibble so a decode that pairs
        // slots with the wrong wire entries fails the round-trip comparison.
        children: Children::from_fn(|pc|
                Some(Child::AddressWithHash(LinearAddress::new(1).unwrap(), std::array::from_fn::<u8, 32, _>(|i| if i == 0 { pc.as_u8() } else { i as u8 }).into()))
        )})), 652; "full branch node with long partial path and value"
    )]
    #[test_case(Node::Branch(Box::new(BranchNode {
        partial_path: Path::from_nibbles_iterator(NibblesIterator::new(b"this is a really long partial path, like so long it's more than 63 nibbles long which triggers #1056.")),
        value: Some(vec![4, 5, 6, 7].into()),
        children: Children::from_fn(|_|
                Some(Child::AddressWithHash(LinearAddress::new(1).unwrap(), std::array::from_fn::<u8, 32, _>(|i| i as u8).into()))
        )})), 851; "full branch node with obnoxiously long partial path"
    )]
    #[test_case(Node::Branch(Box::new(BranchNode {
        partial_path: Path::from_nibbles_iterator(NibblesIterator::new(b"this is a really long partial path, like so long it's more than 63 nibbles long which triggers #1056.")),
        value: Some((*br"
We also need to test values that have a length longer than 255 bytes so that we
verify that we decode the entire value every time. previously, we would only read
the first byte for the value length, which is incorrect if the length is greater
than 126 bytes as the length would be encoded in multiple bytes.
        ").into()),
        children: Children::from_fn(|_|
                Some(Child::AddressWithHash(LinearAddress::new(1).unwrap(), std::array::from_fn::<u8, 32, _>(|i| i as u8).into()))
        )})), 1165; "full branch node with obnoxiously long partial path and long value"
    )]
    fn test_serialize_deserialize<H: HashMode>(node: Node, expected_length: usize) {
        use crate::node::Node;
        use std::io::Cursor;

        let mut serialized = Vec::new();
        let _area_index = node.as_bytes::<H, _>(&mut serialized).unwrap();
        if H::ALGORITHM == NodeHashAlgorithm::MerkleDB {
            assert_eq!(serialized.len(), expected_length);
        }
        let mut cursor = Cursor::new(&serialized);
        cursor.set_position(1);
        let deserialized = Node::from_reader::<H>(&mut cursor).unwrap();

        assert_eq!(node, deserialized);
    }

    /// Golden test locking the on-disk byte layout of a branch node's
    /// child-hash region in eth mode: an 8-byte native-endian address followed
    /// by the hash codec output (`0x00` + 32 raw bytes for a full hash). These
    /// bytes must stay byte-for-byte stable so existing databases keep working.
    #[cfg(feature = "ethhash")]
    #[test]
    fn test_eth_child_hash_region_exact_bytes() {
        // A partial branch with a single child at slot 15, no value. Distinct
        // per-byte values make a mismatch easy to spot in the failure hex dump.
        let hash_bytes: [u8; 32] = std::array::from_fn(|i| i as u8);
        let child_hash: crate::HashType = hash_bytes.into();
        let node = Node::Branch(Box::new(BranchNode {
            partial_path: Path::from(vec![0, 1]),
            value: None,
            children: Children::from_fn(|i| {
                if i.as_u8() == 15 {
                    Some(Child::AddressWithHash(
                        LinearAddress::new(1).unwrap(),
                        child_hash.clone(),
                    ))
                } else {
                    None
                }
            }),
        }));

        let mut serialized = Vec::new();
        node.as_bytes::<DefaultHashMode, _>(&mut serialized)
            .unwrap();

        // The child record is the tail of the encoding.
        let mut expected_tail = Vec::new();
        expected_tail.push(15u8); // child-slot nibble varint (single byte)
        expected_tail.extend_from_slice(&1u64.to_ne_bytes()); // address
        expected_tail.push(0x00); // full-hash discriminant
        expected_tail.extend_from_slice(&hash_bytes);

        assert!(
            serialized.ends_with(&expected_tail),
            "child-hash region changed; got {}",
            hex::encode(&serialized)
        );

        // And the whole thing must round-trip.
        let mut cursor = std::io::Cursor::new(&serialized);
        cursor.set_position(1);
        assert_eq!(
            node,
            Node::from_reader::<DefaultHashMode>(&mut cursor).unwrap()
        );
    }

    #[hash_mode]
    #[test]
    #[expect(
        clippy::arithmetic_side_effects,
        reason = "fixture buffer sizes are bounded"
    )]
    fn test_area_index_with_non_empty_buffer<H: HashMode>() {
        use crate::node::Node;
        use crate::nodestore::AreaIndex;

        // Create a simple leaf node
        let node = Node::Leaf(LeafNode {
            partial_path: Path::from(vec![0, 1, 2, 3]),
            value: vec![4, 5, 6, 7].into(),
        });

        // First, encode into an empty buffer to get the expected area index
        let mut empty_buffer = Vec::new();
        let expected_area_index = node.as_bytes::<H, _>(&mut empty_buffer).unwrap();
        let expected_size = empty_buffer.len();

        // Now encode into a non-empty buffer with a 100-byte prefix
        let mut non_empty_buffer = vec![0xFF; 100];
        let area_index = node.as_bytes::<H, _>(&mut non_empty_buffer).unwrap();

        // The area index should be the same regardless of buffer prefix
        assert_eq!(
            area_index, expected_area_index,
            "Area index should be calculated from node size, not total buffer size"
        );

        // Verify the area index stored in the buffer is correct
        assert_eq!(
            non_empty_buffer.get(100).copied().unwrap(),
            area_index.get(),
            "Area index at position 100 should match calculated area index"
        );

        // Verify the total buffer size is prefix + node size
        assert_eq!(
            non_empty_buffer.len(),
            100 + expected_size,
            "Total buffer size should be prefix + node size"
        );

        // Verify the area index corresponds to the node size, not total buffer
        assert_eq!(
            AreaIndex::from_size(expected_size as u64).unwrap(),
            area_index,
            "Area index should be calculated from node size only"
        );
    }
}
