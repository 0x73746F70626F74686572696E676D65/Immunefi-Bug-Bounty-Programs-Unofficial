# Changelog

All notable changes to this project will be documented in this file.

## [0.8.0] - 2026-07-09

### 🚀 Features

- *(fwdctl)* Add import command ([#2082](https://github.com/ava-labs/firewood/pull/2082))
- *(ffi)* Close option to force-close outstanding FFI handles for avalanchego async execution engine ([#1976](https://github.com/ava-labs/firewood/pull/1976))

### 🐛 Bug Fixes

- *(proofs)* Change-proof verification accepts forged batch ops ([#2109](https://github.com/ava-labs/firewood/pull/2109))
- *(storage)* Validate AreaIndex::TryFrom<usize> against NUM_AREA_SIZES ([#2119](https://github.com/ava-labs/firewood/pull/2119))

### 📚 Documentation

- *(storage)* Document FileBacked struct and its fields ([#2112](https://github.com/ava-labs/firewood/pull/2112))
- Document the lint-suppression policy ([#2116](https://github.com/ava-labs/firewood/pull/2116))

### ⚙️ Miscellaneous Tasks

- *(deps)* Bump golang.org/x/net from 0.52.0 to 0.55.0 in /ffi/tests/firewood ([#2113](https://github.com/ava-labs/firewood/pull/2113))
- *(clippy)* Allow unwrap and indexing in tests ([#2117](https://github.com/ava-labs/firewood/pull/2117))
- Run clippy on a pinned nightly, gate maxperf, and add a weekly nightly lint ([#2115](https://github.com/ava-labs/firewood/pull/2115))
- *(deps)* Bump golang.org/x/crypto from 0.51.0 to 0.52.0 in /ffi/tests/firewood ([#2127](https://github.com/ava-labs/firewood/pull/2127))
- *(deps)* Bump golang.org/x/crypto from 0.45.0 to 0.52.0 in /ffi/tests/eth ([#2129](https://github.com/ava-labs/firewood/pull/2129))

## [0.7.0] - 2026-06-29

### 🚀 Features

- *(proofs)* 5/7 add eth_get_proof entry point producing eth_getProof-compatible proofs ([#2053](https://github.com/ava-labs/firewood/pull/2053))
- *(labels)* Introduce versioned label taxonomy ([#2084](https://github.com/ava-labs/firewood/pull/2084))
- *(labels)* Add issue intake forms and label lifecycle automation ([#2085](https://github.com/ava-labs/firewood/pull/2085))
- *(ffi)* 6/7 add fwd_eth_get_proof FFI surface ([#2054](https://github.com/ava-labs/firewood/pull/2054))
- *(devcontainer)* Rewrite as a Dockerfile-less feature-based config ([#2087](https://github.com/ava-labs/firewood/pull/2087))
- *(ffi)* 7/7 add Go EthGetProof wrapper and go-ethereum verification test ([#2055](https://github.com/ava-labs/firewood/pull/2055))
- Support eth_getProof for reconstructed revisions ([#2059](https://github.com/ava-labs/firewood/pull/2059))

### 🐛 Bug Fixes

- *(proofs)* Reconcile partial-storage account values ([#2060](https://github.com/ava-labs/firewood/pull/2060))
- *(launch)* Correct restored C-chain config for the validator scenario ([#2072](https://github.com/ava-labs/firewood/pull/2072))
- *(proofs)* Reject change proof that drops an in-range Put behind a left-edge exclusion boundary ([#2064](https://github.com/ava-labs/firewood/pull/2064))
- Prevent OOM DoS in Box<[T]>::read_v0_item via untrusted num_items ([#2095](https://github.com/ava-labs/firewood/pull/2095))

### 🚜 Refactor

- *(storage)* Unify hash_helper receiver ([#2093](https://github.com/ava-labs/firewood/pull/2093))
- *(storage)* Add FreeLists newtype ([#2097](https://github.com/ava-labs/firewood/pull/2097))
- *(storage)* Remove bitflags dependency from path.rs ([#2092](https://github.com/ava-labs/firewood/pull/2092))

### 📚 Documentation

- Explain how to sign commits in CONTRIBUTING ([#2096](https://github.com/ava-labs/firewood/pull/2096))
- Update CONTRIBUTING.md for duplicate docs ([#2106](https://github.com/ava-labs/firewood/pull/2106))

### ⚡ Performance

- Skip using FDL when running in archival mode ([#2078](https://github.com/ava-labs/firewood/pull/2078))

### 🧪 Testing

- Add insta snapshot tests for proof and node wire serialization ([#2104](https://github.com/ava-labs/firewood/pull/2104))

## [0.6.0] - 2026-06-09

### 🚀 Features

- *(proofs)* Emit canonical Ethereum MPT-RLP from ProofNode ([#2004](https://github.com/ava-labs/firewood/pull/2004))
- *(storage)* Add NodeHashAlgorithm::is_ethereum predicate ([#2014](https://github.com/ava-labs/firewood/pull/2014))
- *(ffi)* Code-hash iterator for change proofs ([#2033](https://github.com/ava-labs/firewood/pull/2033))
- Add update convenience API ([#2029](https://github.com/ava-labs/firewood/pull/2029))
- *(proofs)* 4/7 add AccountFields decoder and rlp byte-string parse helpers ([#2051](https://github.com/ava-labs/firewood/pull/2051))
- *(metrics)* Add firewood_proof_keys histogram for proof sizes ([#2069](https://github.com/ava-labs/firewood/pull/2069))
- *(launch)* Add validator scenario bootstrapping from S3 state snapshot ([#2071](https://github.com/ava-labs/firewood/pull/2071))

### 🐛 Bug Fixes

- *(storage)* 2/2 persist computed storageRoot in account node values ([#1938](https://github.com/ava-labs/firewood/pull/1938))
- *(proofs)* Annotate edge-proof hash mismatches with Left/Right edge ([#2028](https://github.com/ava-labs/firewood/pull/2028))
- Set background in Firewood architecture diagram ([#2065](https://github.com/ava-labs/firewood/pull/2065))
- *(proofs)* Hash single storage child as storage-trie root ([#2058](https://github.com/ava-labs/firewood/pull/2058))
- *(launch)* Repair grafana/prometheus metrics pipeline on launched instances ([#2070](https://github.com/ava-labs/firewood/pull/2070))

### 💼 Other

- *(ffi)* Run the ffi tests in debug mode ([#1562](https://github.com/ava-labs/firewood/pull/1562))
- *(ffi)* Vendor golangci-lint as go tool, drop third-party action ([#2026](https://github.com/ava-labs/firewood/pull/2026))

### 🚜 Refactor

- Take &[u8] in key_value_iter_from_key ([#2041](https://github.com/ava-labs/firewood/pull/2041))

### 📚 Documentation

- *(changelog)* Detect breaking-change PR labels in CHANGELOG automatically ([#2016](https://github.com/ava-labs/firewood/pull/2016))
- *(release)* Document undocumented steps, add versioning policy ([#2017](https://github.com/ava-labs/firewood/pull/2017))

### ⚡ Performance

- *(storage)* Fill predictive read buffer for unaligned reads ([#1964](https://github.com/ava-labs/firewood/pull/1964))

### 🧪 Testing

- *(fwdctl)* Refactor CLI test setup ([#2037](https://github.com/ava-labs/firewood/pull/2037))

### ⚙️ Miscellaneous Tasks

- Gate canonical-repo workflows on github.repository ([#2011](https://github.com/ava-labs/firewood/pull/2011))
- Fix nightly clippy warnings ([#2019](https://github.com/ava-labs/firewood/pull/2019))
- Bump go to 1.25.10 ([#2036](https://github.com/ava-labs/firewood/pull/2036))
- Add 33m-33.5m benchmark ([#2038](https://github.com/ava-labs/firewood/pull/2038))
- Add TODO checker ([#2044](https://github.com/ava-labs/firewood/pull/2044))

## [0.5.0] - 2026-05-19

### 🚀 Features

- Add pathdb config + 33m block option ([#1959](https://github.com/ava-labs/firewood/pull/1959))
- *(ffi)* Implement range proof verification (Trail of Bits finding TOB-FIREWOOD-2) ([#1971](https://github.com/ava-labs/firewood/pull/1971))
- Add ability to clone reconstructed revisions ([#1991](https://github.com/ava-labs/firewood/pull/1991))

### 🐛 Bug Fixes

- Resolve false rejection at straddling nibbles in collapse_strip ([#1952](https://github.com/ava-labs/firewood/pull/1952))
- Remove duplicate children loop in compute_root_hash_with_proofs ([#1948](https://github.com/ava-labs/firewood/pull/1948))
- *(fwdctl)* Drop legacy rustls feature to clear GHSA-82j2-j2ch-gfr8 ([#1956](https://github.com/ava-labs/firewood/pull/1956))
- *(manager)* Resolve empty-trie revision under ethhash without RootStore (TOB-FIREWOOD-7) ([#1982](https://github.com/ava-labs/firewood/pull/1982))
- *(range-proof)* Use last_kv_key as right-edge anchor for inclusion-style end_proofs ([#1970](https://github.com/ava-labs/firewood/pull/1970))
- *(manager)* Hold proposals lock across cleanup and reparent (TOB-FIREWOOD-6) ([#1981](https://github.com/ava-labs/firewood/pull/1981))
- *(manager)* Use CommittedId for parent identity, skip trivial commits ([#1987](https://github.com/ava-labs/firewood/pull/1987))
- *(storage)* Pin committed parent in Reconstructed to prevent reaping ([#2000](https://github.com/ava-labs/firewood/pull/2000))

### 🚜 Refactor

- *(ffi)* Simplify change proof interface with unified Proposal type ([#1966](https://github.com/ava-labs/firewood/pull/1966))
- *(proofs)* Move range/change proof verification helpers from FFI to firewood ([#1990](https://github.com/ava-labs/firewood/pull/1990))
- *(storage)* Lift nibbles_to_eth_compact into eth_encoding module ([#2003](https://github.com/ava-labs/firewood/pull/2003))

### ⚡ Performance

- *(storage)* Add in-tree `crate::rlp` module + benchmark ([#1957](https://github.com/ava-labs/firewood/pull/1957))
- Migrate firewood off the upstream `rlp` crate ([#1958](https://github.com/ava-labs/firewood/pull/1958))
- *(storage)* Retain hashed root in Reconstructed for cheap forks ([#1999](https://github.com/ava-labs/firewood/pull/1999))

### 🧪 Testing

- Add edge case tests for change proof verification ([#1946](https://github.com/ava-labs/firewood/pull/1946))
- Add adversarial attack tests for change proof verification ([#1947](https://github.com/ava-labs/firewood/pull/1947))

### ⚙️ Miscellaneous Tasks

- *(deps)* Bump DavidAnson/markdownlint-cli2-action from 23.0.0 to 23.1.0 in the github-actions group ([#1954](https://github.com/ava-labs/firewood/pull/1954))
- *(deps)* Bump the github-actions group with 2 updates ([#1977](https://github.com/ava-labs/firewood/pull/1977))
- Remove weekly 50m-60m job ([#1983](https://github.com/ava-labs/firewood/pull/1983))
- Export errRevisionNotFound ([#1955](https://github.com/ava-labs/firewood/pull/1955))
- Update workflow to use macOS 26, drop x86_64 mac target ([#1996](https://github.com/ava-labs/firewood/pull/1996))
- *(deps)* Bump cachix/cachix-action from 1eb2ef646ac0255473d23a5907ad7b04ce94065c to 5f2d7c5294214f71b873db4b969586b980625e71 in the github-actions group ([#1995](https://github.com/ava-labs/firewood/pull/1995))
- Use deploy key instead of pat ([#2002](https://github.com/ava-labs/firewood/pull/2002))

## [0.4.0] - 2026-04-29

### 🚀 Features

- *(proofs)* 1/4 Range Proof Verification  ([#1715](https://github.com/ava-labs/firewood/pull/1715))
- *(metrics)* Add jemalloc metrics ([#1837](https://github.com/ava-labs/firewood/pull/1837))
- *(proofs)* 2/6 Range Proof Verification ([#1716](https://github.com/ava-labs/firewood/pull/1716))
- *(range-proof-verification)* 4/6 complete range proof verification ([#1833](https://github.com/ava-labs/firewood/pull/1833))
- *(metrics)* Add firewood_describe_counter! and firewood_describe_gauge! facades ([#1853](https://github.com/ava-labs/firewood/pull/1853))
- *(change-proof)* Add change proof verification error variants and document value_digest ([#1866](https://github.com/ava-labs/firewood/pull/1866))
- *(storage)* Autogen area sizes hash and names ([#1906](https://github.com/ava-labs/firewood/pull/1906))
- *(metrics)* Export prometheus metrics as structured data ([#1868](https://github.com/ava-labs/firewood/pull/1868))
- *(metrics)* [**breaking**] Overhaul metrics for Prometheus best practices ([#1912](https://github.com/ava-labs/firewood/pull/1912))
- *(ffi)* [**breaking**] Remove http and text exporter ([#1913](https://github.com/ava-labs/firewood/pull/1913))
- Add verify_change_proof_structure and module documentation ([#1918](https://github.com/ava-labs/firewood/pull/1918))
- Add verify_change_proof_root_hash for change proof verification ([#1930](https://github.com/ava-labs/firewood/pull/1930))

### 🐛 Bug Fixes

- *(ffi)* Return error from ChangeProof. Allow MarshalBinary after verification ([#1828](https://github.com/ava-labs/firewood/pull/1828))
- *(deferred-persistence)* Carry metrics context into worker ([#1829](https://github.com/ava-labs/firewood/pull/1829))
- *(range-proof)* Manual audit bug fixes ([#1848](https://github.com/ava-labs/firewood/pull/1848))
- Add `test_utils` feature when running benchmarks ([#1873](https://github.com/ava-labs/firewood/pull/1873))
- *(proofs)* Yield divergent nodes from PathIterator for exclusion proofs ([#1875](https://github.com/ava-labs/firewood/pull/1875))
- *(proofs)* Verify proof path follows target key branch ([#1881](https://github.com/ava-labs/firewood/pull/1881))
- *(nix)* Update rust-overlay in nix flake for MSRV 1.94.0 ([#1888](https://github.com/ava-labs/firewood/pull/1888))
- *(test)* Audit range.rs — fix bugs, add missing coverage, unignore bloated test ([#1895](https://github.com/ava-labs/firewood/pull/1895))
- Verify proof node values match key_values in range proofs ([#1896](https://github.com/ava-labs/firewood/pull/1896))
- *(proofs)* Mark right-edge terminal children as outside in compute_outside_children ([#1886](https://github.com/ava-labs/firewood/pull/1886))
- Update nix lockfile for rust-overlay ([#1899](https://github.com/ava-labs/firewood/pull/1899))
- *(proofs, de)* Verify partial len is within bounds ([#1920](https://github.com/ava-labs/firewood/pull/1920))
- *(clippy)* Disallow panicking slice methods via clippy lint ([#1926](https://github.com/ava-labs/firewood/pull/1926))
- *(ffi)* Add GC finalizers for change proof types and NextKeyRange ([#1921](https://github.com/ava-labs/firewood/pull/1921))
- *(proofs)* 1/2 recompute storageRoot in ethhash proof generation ([#1935](https://github.com/ava-labs/firewood/pull/1935))
- Update change proof generator end proof key logic ([#1931](https://github.com/ava-labs/firewood/pull/1931))
- *(ci)* Replace CI Nix cache with cachix to speed up worst ffi-nix run-time case ([#1902](https://github.com/ava-labs/firewood/pull/1902))
- *(proofs)* Reject truncated exclusion proofs with reachable children ([#1950](https://github.com/ava-labs/firewood/pull/1950))

### 🚜 Refactor

- *(metrics)* [**breaking**] Remove histograms ([#1847](https://github.com/ava-labs/firewood/pull/1847))
- *(proofs)* Replace ChildMask [bool; 16] with u16 newtype ([#1849](https://github.com/ava-labs/firewood/pull/1849))
- *(range-proofs)* Consolidate ChildrenMap into ChildMask ([#1852](https://github.com/ava-labs/firewood/pull/1852))
- *(merkle)* [**breaking**] Reduce visibility of firewood::merkle module ([#1858](https://github.com/ava-labs/firewood/pull/1858))
- Rename verify_root_hash to verify_range_proof_root_hash ([#1887](https://github.com/ava-labs/firewood/pull/1887))
- *(ffi)* Remove ArcCache from DatabaseHandle ([#1891](https://github.com/ava-labs/firewood/pull/1891))
- *(metrics)* Consolidate metric registry definitions with macro ([#1867](https://github.com/ava-labs/firewood/pull/1867))
- Move ChangeProof from merkle/changes to proofs/change ([#1915](https://github.com/ava-labs/firewood/pull/1915))
- Update reconcile_branch_proof_node with callback interface ([#1914](https://github.com/ava-labs/firewood/pull/1914))

### 📚 Documentation

- Include go docs in gh-pages ([#1819](https://github.com/ava-labs/firewood/pull/1819))
- *(metrics)* Add usage guidance metric-naming conforming examples ([#1864](https://github.com/ava-labs/firewood/pull/1864))
- Clarify fwdctl launch usage ([#1874](https://github.com/ava-labs/firewood/pull/1874))
- Replace ignore doctests with runnable examples (Unix only) ([#1865](https://github.com/ava-labs/firewood/pull/1865)) ([#1878](https://github.com/ava-labs/firewood/pull/1878))
- Document empty-value semantics for batch operations ([#1916](https://github.com/ava-labs/firewood/pull/1916))
- *(storage/hashers)* Document ethhash design and refactor replace_hash ([#1943](https://github.com/ava-labs/firewood/pull/1943))

### ⚡ Performance

- *(storage)* Use binary search in AreaIndex::from_size ([#1940](https://github.com/ava-labs/firewood/pull/1940))

### 🧪 Testing

- *(proofs)* Add fuzz-style standalone range proof verification
- *(proofs)* Add round-trip and FrozenChangeProof serialization tests ([#1922](https://github.com/ava-labs/firewood/pull/1922))
- *(merkle)* Decouple tests from insert-value-equals-stored-value assumption ([#1942](https://github.com/ava-labs/firewood/pull/1942))
- Add change proof test infrastructure with bounds and empty tests ([#1932](https://github.com/ava-labs/firewood/pull/1932))
- Add structural validation and partial proof tests for change proofs ([#1934](https://github.com/ava-labs/firewood/pull/1934))
- *(proofs)* Add edge case tests for valid proof structures ([#1923](https://github.com/ava-labs/firewood/pull/1923))
- *(proofs)* Add SeededRng fuzz tests for proof round-trips ([#1924](https://github.com/ava-labs/firewood/pull/1924))
- *(proofs)* Cover remaining deserialization failure paths ([#1925](https://github.com/ava-labs/firewood/pull/1925))

### ⚙️ Miscellaneous Tasks

- *(ci)* Pedantically check all golang errors ([#1820](https://github.com/ava-labs/firewood/pull/1820))
- *(ci)* Remove metrics check ([#1838](https://github.com/ava-labs/firewood/pull/1838))
- *(deps)* Bump the github-actions group with 4 updates ([#1871](https://github.com/ava-labs/firewood/pull/1871))
- Bump MSRV from 1.91.0 to 1.94.0 ([#1885](https://github.com/ava-labs/firewood/pull/1885))
- Use RAID0 in reexecution tests ([#1884](https://github.com/ava-labs/firewood/pull/1884))
- *(ci)* Avoid running benchmarks on normal nextest ([#1903](https://github.com/ava-labs/firewood/pull/1903))
- Update go linter rules ([#1927](https://github.com/ava-labs/firewood/pull/1927))
- *(deps)* Bump the github-actions group with 3 updates ([#1936](https://github.com/ava-labs/firewood/pull/1936))
- *(storage)* Fix 'occured' -> 'occurred' in io_uring.rs doc comment ([#1937](https://github.com/ava-labs/firewood/pull/1937))
- *(deps)* Bump devcontainers/ci from 0.3.1900000417 to 0.3.1900000449 in the github-actions group ([#1945](https://github.com/ava-labs/firewood/pull/1945))

## [0.3.1] - 2026-03-20

### 🚀 Features

- *(c-chain-benchmark)* Add firewood-40m-41m test and harden bench-cchain ([#1800](https://github.com/ava-labs/firewood/pull/1800))
- *(reconstruct)* Support Reconstructible revisions ([#1786](https://github.com/ava-labs/firewood/pull/1786))
- *(reconstruct)* Add benchmarks for rust reconstruction ([#1787](https://github.com/ava-labs/firewood/pull/1787))
- *(reconstruction)* Add FFI Rust layer ([#1813](https://github.com/ava-labs/firewood/pull/1813))
- *(reconstruction)* Add Go bindings and tests ([#1814](https://github.com/ava-labs/firewood/pull/1814))

### 🐛 Bug Fixes

- *(fwdctl)* Use libevm only when specified ([#1805](https://github.com/ava-labs/firewood/pull/1805))
- Adding keepAlive to ProposedChangeProof ([#1817](https://github.com/ava-labs/firewood/pull/1817))

### 📚 Documentation

- *(reconstruct)* Diagram move ([#1795](https://github.com/ava-labs/firewood/pull/1795))
- *(c-chain-benchmark)* Add BENCHMARK.md  ([#1801](https://github.com/ava-labs/firewood/pull/1801))
- *(benchmark)* Improve and consolidate Firewood's benchmarks ([#1812](https://github.com/ava-labs/firewood/pull/1812))

### ⚙️ Miscellaneous Tasks

- *(revert)* Remove nix flake and all references to it ([#1788](https://github.com/ava-labs/firewood/pull/1788)) ([#1794](https://github.com/ava-labs/firewood/pull/1794))
- Reduce visibility of flush_nodes() ([#1802](https://github.com/ava-labs/firewood/pull/1802))
- *(deps)* Bump the github-actions group with 2 updates ([#1809](https://github.com/ava-labs/firewood/pull/1809))
- Rootstore cleanups ([#1798](https://github.com/ava-labs/firewood/pull/1798))
- *(fwdctl)* Add block height 77m ([#1816](https://github.com/ava-labs/firewood/pull/1816))

## [0.3.0] - 2026-03-13

### 🚀 Features

- *(ffi)* Automatically generate `cgo` pragma declarations ([#1784](https://github.com/ava-labs/firewood/pull/1784))

### 🐛 Bug Fixes

- Enforce `max_revisions` > `commit_count` ([#1749](https://github.com/ava-labs/firewood/pull/1749))
- [**breaking**] Clock source miss-match between Rust and Go ([#1742](https://github.com/ava-labs/firewood/pull/1742))
- Fwdctl vm config ([#1776](https://github.com/ava-labs/firewood/pull/1776))
- Bug where remove_all_entries may not remove all subtries ([#1778](https://github.com/ava-labs/firewood/pull/1778))

### 🚜 Refactor

- *(perf)* Calculate AreaIndex in as_bytes methods ([#1675](https://github.com/ava-labs/firewood/pull/1675))
- Replace `PersistSemaphore` with `PersistChannel` ([#1710](https://github.com/ava-labs/firewood/pull/1710))
- *(metrics)* Migrate ffi histogram recording to macros ([#1712](https://github.com/ava-labs/firewood/pull/1712))
- Parallel execution helpers ([#1764](https://github.com/ava-labs/firewood/pull/1764))
- [**breaking**] Remove v2 module ([#1760](https://github.com/ava-labs/firewood/pull/1760))
- Read node mode ([#1792](https://github.com/ava-labs/firewood/pull/1792))

### 📚 Documentation

- Clarify deferred persistence terminology ([#1733](https://github.com/ava-labs/firewood/pull/1733))

### ⚡ Performance

- Use `runtime.AddCleanup` ([#1705](https://github.com/ava-labs/firewood/pull/1705))
- *(ffi)* Add cgo pragma declarations ([#1722](https://github.com/ava-labs/firewood/pull/1722))
- Fix child pruning in iterate_to_key ([#1783](https://github.com/ava-labs/firewood/pull/1783))

### ⚙️ Miscellaneous Tasks

- Update pull request template to include breaking changes ([#1723](https://github.com/ava-labs/firewood/pull/1723))
- *(deps)* Bump the github-actions group with 3 updates ([#1738](https://github.com/ava-labs/firewood/pull/1738))
- *(ffi)* Fix lint emitted in maxperf builds ([#1732](https://github.com/ava-labs/firewood/pull/1732))
- *(docs)* Render mermaid graphs with aquamarine ([#1753](https://github.com/ava-labs/firewood/pull/1753))
- Remove dead code ([#1755](https://github.com/ava-labs/firewood/pull/1755))
- [**breaking**] Remove node_cache_size ([#1758](https://github.com/ava-labs/firewood/pull/1758))
- Bump go to 1.25.8 ([#1775](https://github.com/ava-labs/firewood/pull/1775))
- Add additional metrics for `v0.3.0` ([#1782](https://github.com/ava-labs/firewood/pull/1782))
- Remove nix flake and all references to it ([#1788](https://github.com/ava-labs/firewood/pull/1788))
- Verify go.mod files all have the same declared go version ([#1790](https://github.com/ava-labs/firewood/pull/1790))

## [0.2.0] - 2026-02-26

### 🚀 Features

- Creating change proofs using FFI ([#1637](https://github.com/ava-labs/firewood/pull/1637))
- *(db)* Add explicit close() method ([#1650](https://github.com/ava-labs/firewood/pull/1650))
- Defer persist every commit ([#1656](https://github.com/ava-labs/firewood/pull/1656))
- *(fwdctl/launch)* Add feature-gated fwdctl EC2 deploy workflow for benchmark setup (1/4) ([#1662](https://github.com/ava-labs/firewood/pull/1662))
- *(fwdctl/launch)* Add SSM-based monitor/follow flow for cloud-init and bootstrap progress (2/4) ([#1663](https://github.com/ava-labs/firewood/pull/1663))
- Node cache entry-based to memory-based LRU ([#1677](https://github.com/ava-labs/firewood/pull/1677))
- Change proof serialization/deserialization ([#1638](https://github.com/ava-labs/firewood/pull/1638))
- Defer persist every `N` commits ([#1657](https://github.com/ava-labs/firewood/pull/1657))
- *(ffi)* Remove explicit garbage collection call ([#1681](https://github.com/ava-labs/firewood/pull/1681))
- Change proof verification and proposal creation ([#1641](https://github.com/ava-labs/firewood/pull/1641))
- *(fwdctl/launch)* Add scenario-driven deploy, list/kill instance management, and dry-run planning (3/4) ([#1664](https://github.com/ava-labs/firewood/pull/1664))
- [**breaking**] Remove error returned by Hash ([#1671](https://github.com/ava-labs/firewood/pull/1671))
- *(fwdctl/launch)* Add docs, deprecate aws-launch.sh (4/4) ([#1665](https://github.com/ava-labs/firewood/pull/1665))
- *(ffi)* [**breaking**] Add optional node cache memory limit to open args ([#1713](https://github.com/ava-labs/firewood/pull/1713))
- Change proof commit and find next key ([#1646](https://github.com/ava-labs/firewood/pull/1646))

### 🐛 Bug Fixes

- *(flake)* Grab version from correct location ([#1630](https://github.com/ava-labs/firewood/pull/1630))
- *(storage)* Handle possible short writes ([#1635](https://github.com/ava-labs/firewood/pull/1635))
- *(ffi)* Force correct alignment on certain c structs ([#1652](https://github.com/ava-labs/firewood/pull/1652))
- *(db)* Lock in-memory revisions during commit critical section ([#1661](https://github.com/ava-labs/firewood/pull/1661))
- *(track-performance)* Fail hard on gh errors  ([#1659](https://github.com/ava-labs/firewood/pull/1659))
- *(track-performance)* Stale cron expression in daily bench ([#1667](https://github.com/ava-labs/firewood/pull/1667))
- *(ffi)* Prevent potential use-after-free in Go Iterator ([#1688](https://github.com/ava-labs/firewood/pull/1688))
- Avoid holding the last_committed_revision arc ([#1685](https://github.com/ava-labs/firewood/pull/1685))
- Acquire lock for displaying MaybePersistedNode ([#1719](https://github.com/ava-labs/firewood/pull/1719))

### 🚜 Refactor

- Decouple header from `NodeStore` ([#1618](https://github.com/ava-labs/firewood/pull/1618))
- Close consumes itself ([#1701](https://github.com/ava-labs/firewood/pull/1701))
- Stop keeping around the last committed revision ([#1690](https://github.com/ava-labs/firewood/pull/1690))

### 📚 Documentation

- Update comments on Arc::try_unwrap safety ([#1649](https://github.com/ava-labs/firewood/pull/1649))
- Update README to include archival support ([#1674](https://github.com/ava-labs/firewood/pull/1674))

### ⚡ Performance

- Increase limits and monitor freelist cache size better ([#1668](https://github.com/ava-labs/firewood/pull/1668))
- *(ffi)* [**breaking**] Remove Pinner interface ([#1721](https://github.com/ava-labs/firewood/pull/1721))

### ⚙️ Miscellaneous Tasks

- Build and lint with --all-features ([#1636](https://github.com/ava-labs/firewood/pull/1636))
- *(perf)* Track Firewood Performance via AvalancheGo Benchmarks ([#1493](https://github.com/ava-labs/firewood/pull/1493))
- Add Bernard as codeowner ([#1647](https://github.com/ava-labs/firewood/pull/1647))
- Add benchmark workflow ([#1643](https://github.com/ava-labs/firewood/pull/1643))
- Add scheduled benchmark runs ([#1639](https://github.com/ava-labs/firewood/pull/1639)) ([#1645](https://github.com/ava-labs/firewood/pull/1645))
- *(track-performance)* Local iteration ([#1642](https://github.com/ava-labs/firewood/pull/1642))
- Update to go 1.24.12 ([#1658](https://github.com/ava-labs/firewood/pull/1658))
- Trace->info logging ([#1682](https://github.com/ava-labs/firewood/pull/1682))
- Add deferred persistence benchmark ([#1670](https://github.com/ava-labs/firewood/pull/1670))
- *(ffi)* Update CGO LDFLAGS to include -ldl ([#1686](https://github.com/ava-labs/firewood/pull/1686))
- Github actions security audit ([#1691](https://github.com/ava-labs/firewood/pull/1691))
- *(deps)* Bump the github-actions group with 14 updates ([#1695](https://github.com/ava-labs/firewood/pull/1695))
- *(ci)* Update .golangci.yaml ([#1703](https://github.com/ava-labs/firewood/pull/1703))
- Add RootStore metrics ([#1680](https://github.com/ava-labs/firewood/pull/1680))
- Bump go to 1.25.7 ([#1707](https://github.com/ava-labs/firewood/pull/1707))

## [0.1.0] - 2026-01-20

### 🚀 Features

- *(metrics)* Switch to `metrics-exporter-prometheus` and histogram support in FFI ([#1490](https://github.com/ava-labs/firewood/pull/1490))
- [**breaking**] Use AWS profile in launch script ([#1587](https://github.com/ava-labs/firewood/pull/1587))
- *(metrics)* [**breaking**] Proposal tracking ([#1571](https://github.com/ava-labs/firewood/pull/1571))
- Add `FlushAndSync()` ([#1595](https://github.com/ava-labs/firewood/pull/1595))
- Difference iterator for change proofs part 1 ([#1553](https://github.com/ava-labs/firewood/pull/1553))
- *(replay)* Add `firewood-replay` crate for operation recording and replay (1/5) ([#1590](https://github.com/ava-labs/firewood/pull/1590))
- Difference iterator for change proofs part 2 ([#1554](https://github.com/ava-labs/firewood/pull/1554))
- Difference iterator for change proofs part 3 ([#1555](https://github.com/ava-labs/firewood/pull/1555))
- *(ffi/replay)* Add `block-replay` feature for recording FFI operations (2/5) ([#1591](https://github.com/ava-labs/firewood/pull/1591))
- *(ffi/replay)* Add Go replay log decoder and execution tests (3/5) ([#1592](https://github.com/ava-labs/firewood/pull/1592))
- *(fwdctl/replay)* Add command for replaying recorded operations (4/5) ([#1593](https://github.com/ava-labs/firewood/pull/1593))
- CodeHashes() for range proofs ([#1597](https://github.com/ava-labs/firewood/pull/1597))
- [**breaking**] Remove `GetFromRoot` API ([#1614](https://github.com/ava-labs/firewood/pull/1614))
- [**breaking**] Make `NodeHashAlgorithm` a required option on storage ([#1608](https://github.com/ava-labs/firewood/pull/1608))
- Add cargo_version and git_describe to storage header ([#1611](https://github.com/ava-labs/firewood/pull/1611))
- [**breaking**] Add the hash of the root node to the header ([#1612](https://github.com/ava-labs/firewood/pull/1612))
- *(metrics)* Metrics crate, separate registries and expensive metrics (1/2) ([#1619](https://github.com/ava-labs/firewood/pull/1619))
- *(metrics)* Integrate FFI with expensive metrics and add Go tests (2/2) ([#1620](https://github.com/ava-labs/firewood/pull/1620))
- *(ffi)* BatchOp in FFI ([#1624](https://github.com/ava-labs/firewood/pull/1624))

### 🐛 Bug Fixes

- Eager evaluation causing fjall store creation when root_store disabled ([#1577](https://github.com/ava-labs/firewood/pull/1577))
- *(ci)* Update golang-ci patch ([#1584](https://github.com/ava-labs/firewood/pull/1584))
- *(benchmark)* Align metrics config with new avalanchego task format ([#1580](https://github.com/ava-labs/firewood/pull/1580))
- *(benchmark/bootstrap)* Update script to use new task ([#1601](https://github.com/ava-labs/firewood/pull/1601))

### 🚜 Refactor

- Replace counter! with firewood_counter! macro ([#1569](https://github.com/ava-labs/firewood/pull/1569))
- Simplify `into_committed()` ([#1621](https://github.com/ava-labs/firewood/pull/1621))
- *(checker)* Extract `check_area_aligned()` from `NodeStore` ([#1623](https://github.com/ava-labs/firewood/pull/1623))

### 📚 Documentation

- *(ffi)* Update iterator documentation ([#1585](https://github.com/ava-labs/firewood/pull/1585))
- *(nodestore)* Expand header documentation ([#1610](https://github.com/ava-labs/firewood/pull/1610))

### ⚡ Performance

- *(ffi)* Elide panic handling if not needed ([#1606](https://github.com/ava-labs/firewood/pull/1606))

### ⚙️ Miscellaneous Tasks

- *(ffi)* Add `io-uring` feature flag ([#1565](https://github.com/ava-labs/firewood/pull/1565))
- Add Rodrigo as codeowner ([#1573](https://github.com/ava-labs/firewood/pull/1573))
- Stop fwdctl from rebuilding every time ([#1574](https://github.com/ava-labs/firewood/pull/1574))
- Remove 'firewood' from metric names ([#1581](https://github.com/ava-labs/firewood/pull/1581))
- Update to go 1.24.11 ([#1599](https://github.com/ava-labs/firewood/pull/1599))
- [**breaking**] Remove `FlushAndSyncRoot()` API ([#1617](https://github.com/ava-labs/firewood/pull/1617))

## [0.0.18] - 2025-12-17

### 🐛 Bug Fixes

- Hash mismatch when proposing on uncommitted proposal ([#1557](https://github.com/ava-labs/firewood/pull/1557))

### 🧪 Testing

- Guarantee that revisions work after commit ([#1558](https://github.com/ava-labs/firewood/pull/1558))

## [0.0.17] - 2025-12-16

### 🚀 Features

- *(ffi)* Stub for code hashes in proof ([#1526](https://github.com/ava-labs/firewood/pull/1526))
- Add ffi support for dump() ([#1527](https://github.com/ava-labs/firewood/pull/1527))
- Disable automatic io-uring enablement ([#1528](https://github.com/ava-labs/firewood/pull/1528))
- [**breaking**] Open database with directory instead of filepath ([#1532](https://github.com/ava-labs/firewood/pull/1532))

### 🐛 Bug Fixes

- *(io-uring)* Use sqwait to correctly synchronize kernel updates ([#1523](https://github.com/ava-labs/firewood/pull/1523))
- *(rootstore)* Respect db truncation ([#1538](https://github.com/ava-labs/firewood/pull/1538))
- *(ffi/iterator)* Keep view alive for iterator lifetime ([#1542](https://github.com/ava-labs/firewood/pull/1542))
- Generated instance names have whitespace ([#1550](https://github.com/ava-labs/firewood/pull/1550))

### 🚜 Refactor

- [**breaking**] Remove branch_factor_256 ([#1533](https://github.com/ava-labs/firewood/pull/1533))
- [**breaking**] Go DB config to functional options pattern ([#1534](https://github.com/ava-labs/firewood/pull/1534))
- *(ffi/iterator)* Move tests into a separate file ([#1543](https://github.com/ava-labs/firewood/pull/1543))

### 🧪 Testing

- *(fwdctl)* Parallelize test suite ([#1540](https://github.com/ava-labs/firewood/pull/1540))
- *(firewood)* Reduce thread spawn count ([#1547](https://github.com/ava-labs/firewood/pull/1547))

### ⚙️ Miscellaneous Tasks

- Update GitHub templates ([#1525](https://github.com/ava-labs/firewood/pull/1525))
- *(benchmark/bootstrap)* Remove Coreth branch option ([#1530](https://github.com/ava-labs/firewood/pull/1530))
- *(firewood)* Clean up RevisionManager fields ([#1536](https://github.com/ava-labs/firewood/pull/1536))
- Remove reference to RELEASES.md ([#1544](https://github.com/ava-labs/firewood/pull/1544))
- Switch to cargo-nextest ([#1541](https://github.com/ava-labs/firewood/pull/1541))
- Aws-launch.sh: libevm-commit -> libevm-branch ([#1552](https://github.com/ava-labs/firewood/pull/1552))
- *(nextest)* Skip slow tests in local development ([#1551](https://github.com/ava-labs/firewood/pull/1551))

## [0.0.16] - 2025-12-09

### 🚀 Features

- Use `parking_lot` to eliminate lock poisoning ([#1476](https://github.com/ava-labs/firewood/pull/1476))
- *(ffi)* Protect unsafe concurrent ops ([#1474](https://github.com/ava-labs/firewood/pull/1474))

### 🐛 Bug Fixes

- Mark node as allocated before serializing parent ([#1489](https://github.com/ava-labs/firewood/pull/1489))
- *(parallel)* Track deleted nodes from root branch in parallel propose ([#1491](https://github.com/ava-labs/firewood/pull/1491))
- Refactor io-uring to drive the queue to completion ([#1498](https://github.com/ava-labs/firewood/pull/1498))
- *(ffi)* Hold onto verification context in next key range ([#1486](https://github.com/ava-labs/firewood/pull/1486))
- *(range-proof)* Skip leaf nodes that come before lower bound ([#1512](https://github.com/ava-labs/firewood/pull/1512))
- Correct architecture for m5ad.2xlarge ([#1514](https://github.com/ava-labs/firewood/pull/1514))
- Race condition between view and commit ([#1519](https://github.com/ava-labs/firewood/pull/1519))
- *(range-proofs)* Generate proofs for lower and upper bounds correctly ([#1513](https://github.com/ava-labs/firewood/pull/1513))

### 🚜 Refactor

- *(rootstore)* Remove `MockStore` ([#1477](https://github.com/ava-labs/firewood/pull/1477))
- *(firewood/db)* Unify reopen methods ([#1481](https://github.com/ava-labs/firewood/pull/1481))
- *(db/revisionmanager)* Move `RootStore` creation to `RevisionManager` ([#1482](https://github.com/ava-labs/firewood/pull/1482))
- *(rootstore)* Remove box pointer ([#1484](https://github.com/ava-labs/firewood/pull/1484))
- *(rootstore)* Own nodestore logic ([#1495](https://github.com/ava-labs/firewood/pull/1495))
- *(checker)* Separate check and fix ([#1506](https://github.com/ava-labs/firewood/pull/1506))

### 📚 Documentation

- *(ffi)* Update godoc ([#1466](https://github.com/ava-labs/firewood/pull/1466))

### ⚡ Performance

- Avoid extra copying when comparing `HashOrRlp` ([#1505](https://github.com/ava-labs/firewood/pull/1505))

### 🧪 Testing

- Optimize init_merkle by removing redundant verification passes ([#1504](https://github.com/ava-labs/firewood/pull/1504))
- Enhance aws-launch with show and terminate options ([#1517](https://github.com/ava-labs/firewood/pull/1517))

### ⚙️ Miscellaneous Tasks

- Update golangci yaml files ([#1492](https://github.com/ava-labs/firewood/pull/1492))
- Remove windows remnants ([#1503](https://github.com/ava-labs/firewood/pull/1503))
- *(db)* Remove unused `all_hashes()` method ([#1509](https://github.com/ava-labs/firewood/pull/1509))
- *(bootstrap)* Update SSH authorized key for user 'brandon' ([#1510](https://github.com/ava-labs/firewood/pull/1510))
- [**breaking**] Reorganize proof code ([#1511](https://github.com/ava-labs/firewood/pull/1511))

## [0.0.15] - 2025-11-18

### 🚀 Features

- Merge key-value range into trie ([#1427](https://github.com/ava-labs/firewood/pull/1427))
- *(storage)* Replace `ArcSwap` with `Mutex` for better performance ([#1447](https://github.com/ava-labs/firewood/pull/1447))
- *(ffi)* [**breaking**] Remove unused kvBackend interface ([#1448](https://github.com/ava-labs/firewood/pull/1448))
- *(ffi)* Add keepalive struct to own waitgroup logic ([#1437](https://github.com/ava-labs/firewood/pull/1437))
- Remove the last bits of arc-swap ([#1464](https://github.com/ava-labs/firewood/pull/1464))
- *(ffi)* Fill in ffi methods for range proofs ([#1429](https://github.com/ava-labs/firewood/pull/1429))
- *(firewood/ffi)* Add `FjallStore` ([#1395](https://github.com/ava-labs/firewood/pull/1395))

### 🚜 Refactor

- *(rootstore)* Replace RootStoreError with boxed error ([#1446](https://github.com/ava-labs/firewood/pull/1446))
- Remove default 1-minute timeout on `Database.Close()` and set 1-sec in tests ([#1458](https://github.com/ava-labs/firewood/pull/1458))

### 📚 Documentation

- Add agent instructions ([#1445](https://github.com/ava-labs/firewood/pull/1445))
- *(firewood)* Clean up commit steps ([#1453](https://github.com/ava-labs/firewood/pull/1453))
- Merge code review process into CONTRIBUTING.md ([#1397](https://github.com/ava-labs/firewood/pull/1397))
- Add comprehensive metrics documentation in METRICS.md ([#1402](https://github.com/ava-labs/firewood/pull/1402))

### ⚡ Performance

- *(ffi)* [**breaking**] Use fixed size Hash ([#1449](https://github.com/ava-labs/firewood/pull/1449))

### 🧪 Testing

- Fix `giant_node` test ([#1465](https://github.com/ava-labs/firewood/pull/1465))

### ⚙️ Miscellaneous Tasks

- *(ci)* Re-enable ffi-nix job ([#1450](https://github.com/ava-labs/firewood/pull/1450))
- Relegate build equivalent check to post-merge job ([#1469](https://github.com/ava-labs/firewood/pull/1469))

## [0.0.14] - 2025-11-07

### 🚀 Features

- *(monitoring)* Grafana automatic dashboard and auth provisioning ([#1307](https://github.com/ava-labs/firewood/pull/1307))
- *(ffi)* Implement revision handles and expose to FFI layer ([#1326](https://github.com/ava-labs/firewood/pull/1326))
- *(ffi-iterator)* Implementation of Iterator in Rust (1/4) ([#1255](https://github.com/ava-labs/firewood/pull/1255))
- *(ffi-iterator)* Implementation of Iterator in Go (2/4) ([#1256](https://github.com/ava-labs/firewood/pull/1256))
- *(1/7)* Add U4 type to be used as a path component ([#1336](https://github.com/ava-labs/firewood/pull/1336))
- *(2/7)* Add newtype for PathComponent ([#1337](https://github.com/ava-labs/firewood/pull/1337))
- *(3/7)* Add TriePath trait and path abstraction ([#1338](https://github.com/ava-labs/firewood/pull/1338))
- *(4/7)* Add SplitPath trait ([#1339](https://github.com/ava-labs/firewood/pull/1339))
- *(ffi-iterator)* Batching support for Iterator (3/4) ([#1257](https://github.com/ava-labs/firewood/pull/1257))
- *(5/7)* Add PackedPathRef type ([#1341](https://github.com/ava-labs/firewood/pull/1341))
- *(6/7)* Children newtype ([#1344](https://github.com/ava-labs/firewood/pull/1344))
- Use PathComponent in proofs ([#1359](https://github.com/ava-labs/firewood/pull/1359))
- Replace NodeAndPrefix with HashableShunt ([#1362](https://github.com/ava-labs/firewood/pull/1362))
- Parallel updates to Merkle trie (v2) ([#1258](https://github.com/ava-labs/firewood/pull/1258))
- Parallel hashing of Merkle trie ([#1303](https://github.com/ava-labs/firewood/pull/1303))
- Add nix flake for ffi ([#1319](https://github.com/ava-labs/firewood/pull/1319))
- Add more info for IO error message ([#1378](https://github.com/ava-labs/firewood/pull/1378))
- Add TrieNode trait and related functionality ([#1363](https://github.com/ava-labs/firewood/pull/1363))
- Add hashed key-value trie implementation ([#1365](https://github.com/ava-labs/firewood/pull/1365))
- Define explicit associated types on Hashable ([#1366](https://github.com/ava-labs/firewood/pull/1366))
- *(ffi)* `Database.Close()` guarantees proposals committed or freed ([#1349](https://github.com/ava-labs/firewood/pull/1349))
- *(ffi)* [**breaking**] Support empty values in Update operations ([#1420](https://github.com/ava-labs/firewood/pull/1420))
- Add just task runner to ensure reproducibility of CI ([#1345](https://github.com/ava-labs/firewood/pull/1345))
- *(ffi)* [**breaking**] Add finalization logic for Revisions ([#1435](https://github.com/ava-labs/firewood/pull/1435))
- *(benchmark/bootstrap)* Add config param ([#1438](https://github.com/ava-labs/firewood/pull/1438))

### 🐛 Bug Fixes

- Explicitly release advisory lock on drop ([#1352](https://github.com/ava-labs/firewood/pull/1352))
- EINTR during iouring calls ([#1354](https://github.com/ava-labs/firewood/pull/1354))
- Revert "feat: Parallel updates to Merkle trie (v2)" ([#1372](https://github.com/ava-labs/firewood/pull/1372))
- Revert "fix: Revert "feat: Parallel updates to Merkle trie (v2)"" ([#1374](https://github.com/ava-labs/firewood/pull/1374))
- *(storage)* Flush freelist early to prevent corruption ([#1389](https://github.com/ava-labs/firewood/pull/1389))
- *(benchmark/bootstrap)* Consistent go deps ([#1436](https://github.com/ava-labs/firewood/pull/1436))

### 🚜 Refactor

- Unify root storage using Child enum ([#1330](https://github.com/ava-labs/firewood/pull/1330))
- *(db)* `TestDb` constructor ([#1351](https://github.com/ava-labs/firewood/pull/1351))

### 📚 Documentation

- *(benchmark/bootstrap)* Expand README.md ([#1421](https://github.com/ava-labs/firewood/pull/1421))

### 🧪 Testing

- Show symbol diff when ffi-nix build equivalency test fails ([#1423](https://github.com/ava-labs/firewood/pull/1423))

### ⚙️ Miscellaneous Tasks

- Include dependency lockfile ([#1321](https://github.com/ava-labs/firewood/pull/1321))
- Add race detection in Go ([#1323](https://github.com/ava-labs/firewood/pull/1323))
- *(nodestore)* Remove empty committed err ([#1353](https://github.com/ava-labs/firewood/pull/1353))
- Upgrade dependencies ([#1360](https://github.com/ava-labs/firewood/pull/1360))
- *(nodestore)* Access persisted nodestores ([#1355](https://github.com/ava-labs/firewood/pull/1355))
- Update Go to 1.24.8 ([#1361](https://github.com/ava-labs/firewood/pull/1361))
- Print ulimits and set memlock to unlimited before fuzz tests ([#1375](https://github.com/ava-labs/firewood/pull/1375))
- *(db/manager)* Add `MockStore` ([#1346](https://github.com/ava-labs/firewood/pull/1346))
- Update Go to 1.24.9 ([#1380](https://github.com/ava-labs/firewood/pull/1380))
- *(ffi/firewood)* Remove `RootStore` generics ([#1388](https://github.com/ava-labs/firewood/pull/1388))
- Update .golangci.yaml ([#1394](https://github.com/ava-labs/firewood/pull/1394))
- Update ffi build check to configure cargo with same MAKEFLAGS as nix ([#1392](https://github.com/ava-labs/firewood/pull/1392))
- Fix new lint warning from 1.91 update ([#1417](https://github.com/ava-labs/firewood/pull/1417))
- Update .golangci.yaml ([#1419](https://github.com/ava-labs/firewood/pull/1419))
- [**breaking**] Drop binary support for macos 13/14 ([#1425](https://github.com/ava-labs/firewood/pull/1425))
- *(ci)* Disable ffi-nix job pending reliable build equivalency ([#1426](https://github.com/ava-labs/firewood/pull/1426))
- Added helper to reduce code duplication between Db.propose and Proposal.create_proposal ([#1343](https://github.com/ava-labs/firewood/pull/1343))
- Add guidance on Go workspaces ([#1434](https://github.com/ava-labs/firewood/pull/1434))

## [0.0.13] - 2025-09-26

### 🚀 Features

- *(async-removal)* Phase 3 - make `Db` trait sync ([#1213](https://github.com/ava-labs/firewood/pull/1213))
- *(checker)* Fix error with free area that is not head of a free list ([#1231](https://github.com/ava-labs/firewood/pull/1231))
- *(async-removal)* Phase 4 - Make `DbView` synchronous ([#1219](https://github.com/ava-labs/firewood/pull/1219))
- *(ffi-refactor)* Refactor cached view (1/8) ([#1222](https://github.com/ava-labs/firewood/pull/1222))
- *(ffi-refactor)* Add OwnedSlice and OwnedBytes (2/8) ([#1223](https://github.com/ava-labs/firewood/pull/1223))
- *(ffi-refactor)* Introduce VoidResult and panic handlers (3/8) ([#1224](https://github.com/ava-labs/firewood/pull/1224))
- *(ffi-refactor)* Refactor Db opening to use new Result structure (4/8) ([#1225](https://github.com/ava-labs/firewood/pull/1225))
- *(ffi-refactor)* Refactor how hash values are returned (5/8) ([#1226](https://github.com/ava-labs/firewood/pull/1226))
- *(ffi-refactor)* Refactor revision to use database handle (6/8) ([#1227](https://github.com/ava-labs/firewood/pull/1227))
- *(ffi-refactor)* Add `ValueResult` type (7/8) ([#1228](https://github.com/ava-labs/firewood/pull/1228))
- *(checker)* Print report using template for better readability ([#1237](https://github.com/ava-labs/firewood/pull/1237))
- *(checker)* Fix free lists when the erroneous area is the head ([#1240](https://github.com/ava-labs/firewood/pull/1240))
- *(ffi-proofs)* Stub interfaces for FFI to interact with proofs. ([#1253](https://github.com/ava-labs/firewood/pull/1253))
- Explicit impl of PartialEq/Eq on HashOrRlp ([#1260](https://github.com/ava-labs/firewood/pull/1260))
- *(proofs)* [**breaking**] Disable `ValueDigest::Hash` for ethhash ([#1269](https://github.com/ava-labs/firewood/pull/1269))
- [**breaking**] Rename `Hashable::key` ([#1270](https://github.com/ava-labs/firewood/pull/1270))
- *(range-proofs)* KeyValuePairIter (1/2) ([#1282](https://github.com/ava-labs/firewood/pull/1282))
- *(proofs)* [**breaking**] Add v0 serialization for RangeProofs ([#1271](https://github.com/ava-labs/firewood/pull/1271))
- *(ffi-refactor)* Replace sequence id with pointer to proposals (8/8) ([#1221](https://github.com/ava-labs/firewood/pull/1221))

### 🐛 Bug Fixes

- Add an advisory lock ([#1244](https://github.com/ava-labs/firewood/pull/1244))
- Path iterator returned wrong node ([#1259](https://github.com/ava-labs/firewood/pull/1259))
- Use `count` instead of `size_hint` ([#1268](https://github.com/ava-labs/firewood/pull/1268))
- Correct typo in README.md ([#1276](https://github.com/ava-labs/firewood/pull/1276))
- Resolve build failures by pinning opentelemetry to 0.30 ([#1281](https://github.com/ava-labs/firewood/pull/1281))
- *(range-proofs)* Serialize range proof key consistently ([#1278](https://github.com/ava-labs/firewood/pull/1278))
- *(range-proofs)* Fix verify of exclusion proofs ([#1279](https://github.com/ava-labs/firewood/pull/1279))
- *(ffi)* GetFromRoot typo ([#1298](https://github.com/ava-labs/firewood/pull/1298))
- Incorrect gauge metrics ([#1300](https://github.com/ava-labs/firewood/pull/1300))
- M6id is a amd64 machine ([#1305](https://github.com/ava-labs/firewood/pull/1305))
- Revert #1116 ([#1313](https://github.com/ava-labs/firewood/pull/1313))

### 💼 Other

- *(deps)* Update typed-builder requirement from 0.21.0 to 0.22.0 ([#1275](https://github.com/ava-labs/firewood/pull/1275))

### 📚 Documentation

- README implies commit == persist ([#1283](https://github.com/ava-labs/firewood/pull/1283))

### 🧪 Testing

- Mark new_empty_proposal as test only ([#1249](https://github.com/ava-labs/firewood/pull/1249))
- *(firewood)* Use ctor section to init logger for all tests ([#1277](https://github.com/ava-labs/firewood/pull/1277))
- *(bootstrap)* Bootstrap testing scripts ([#1287](https://github.com/ava-labs/firewood/pull/1287))

### ⚙️ Miscellaneous Tasks

- Only allocate the area needed ([#1217](https://github.com/ava-labs/firewood/pull/1217))
- Synchronize .golangci.yaml ([#1234](https://github.com/ava-labs/firewood/pull/1234))
- *(metrics-check)* Re-use previous comment instead of spamming new ones ([#1232](https://github.com/ava-labs/firewood/pull/1232))
- Nuke grpc-testtool ([#1220](https://github.com/ava-labs/firewood/pull/1220))
- Rename FuzzTree ([#1239](https://github.com/ava-labs/firewood/pull/1239))
- Upgrade to rust 1.89 ([#1242](https://github.com/ava-labs/firewood/pull/1242))
- Rename mut_root to root_mut ([#1248](https://github.com/ava-labs/firewood/pull/1248))
- Add missing debug traits ([#1254](https://github.com/ava-labs/firewood/pull/1254))
- These tests actually work now ([#1262](https://github.com/ava-labs/firewood/pull/1262))
- Cargo +nightly clippy --fix ([#1265](https://github.com/ava-labs/firewood/pull/1265))
- Update .golangci.yaml ([#1274](https://github.com/ava-labs/firewood/pull/1274))
- Various script improvements ([#1288](https://github.com/ava-labs/firewood/pull/1288))
- *(bootstrap)* Add keys for brandon ([#1289](https://github.com/ava-labs/firewood/pull/1289))
- *(bootstrap)* Add keys for Bernard and Amin ([#1291](https://github.com/ava-labs/firewood/pull/1291))
- [**breaking**] Decorate enums and structs with `#[non_exhaustive]` ([#1292](https://github.com/ava-labs/firewood/pull/1292))
- Add spot instance support ([#1294](https://github.com/ava-labs/firewood/pull/1294))
- Upgrade go ([#1296](https://github.com/ava-labs/firewood/pull/1296))
- Ask for clippy and rustfmt ([#1306](https://github.com/ava-labs/firewood/pull/1306))
- Add support for enormous disk ([#1308](https://github.com/ava-labs/firewood/pull/1308))
- Disable non-security dependabot version bumps ([#1315](https://github.com/ava-labs/firewood/pull/1315))
- Upgrade dependencies ([#1314](https://github.com/ava-labs/firewood/pull/1314))
- *(benchmark)* Add ssh key ([#1316](https://github.com/ava-labs/firewood/pull/1316))

## [0.0.11] - 2025-08-20

### 🚀 Features

- *(checker)* Checker returns all errors found in the report ([#1176](https://github.com/ava-labs/firewood/pull/1176))
- Remove Default impl on HashType ([#1169](https://github.com/ava-labs/firewood/pull/1169))
- Update revision manager error ([#1170](https://github.com/ava-labs/firewood/pull/1170))
- *(checker)* Return the leaked areas in the checker report ([#1179](https://github.com/ava-labs/firewood/pull/1179))
- *(checker)* Update unaligned page count ([#1181](https://github.com/ava-labs/firewood/pull/1181))
- *(checker)* Add error when node data is bigger than area size ([#1183](https://github.com/ava-labs/firewood/pull/1183))
- Remove `Batch` type alias ([#1171](https://github.com/ava-labs/firewood/pull/1171))
- *(checker)* Annotate IO error with parent pointer in checker errors ([#1188](https://github.com/ava-labs/firewood/pull/1188))
- *(checker)* Do not return physical size to accomodate raw disks ([#1200](https://github.com/ava-labs/firewood/pull/1200))
- *(ffi)* Add BorrowedBytes type ([#1174](https://github.com/ava-labs/firewood/pull/1174))
- *(checker)* More clear print formats for checker report ([#1201](https://github.com/ava-labs/firewood/pull/1201))
- *(async-removal)* Phase 1 - lint on `clippy::unused_async` ([#1211](https://github.com/ava-labs/firewood/pull/1211))
- *(checker)* Collect statistics for branches and leaves separately ([#1206](https://github.com/ava-labs/firewood/pull/1206))
- *(async-removal)* Phase 2 - make `Proposal` trait sync ([#1212](https://github.com/ava-labs/firewood/pull/1212))
- *(checker)* Add checker fix template ([#1199](https://github.com/ava-labs/firewood/pull/1199))

### 🐛 Bug Fixes

- *(checker)* Skip freelist after first encountering an invalid free area ([#1178](https://github.com/ava-labs/firewood/pull/1178))
- Fix race around reading nodes during commit ([#1180](https://github.com/ava-labs/firewood/pull/1180))
- *(fwdctl)* [**breaking**] Db path consistency + no auto-create ([#1189](https://github.com/ava-labs/firewood/pull/1189))

### ⚡ Performance

- Remove unnecessary Box on `OffsetReader` ([#1185](https://github.com/ava-labs/firewood/pull/1185))

### 🧪 Testing

- Add read-during-commit test ([#1186](https://github.com/ava-labs/firewood/pull/1186))
- Fix merkle compatibility test ([#1173](https://github.com/ava-labs/firewood/pull/1173))
- Ban `rand::rng()` and provide an env seeded alternative ([#1192](https://github.com/ava-labs/firewood/pull/1192))
- Reenable eth merkle compatibility test ([#1214](https://github.com/ava-labs/firewood/pull/1214))

### ⚙️ Miscellaneous Tasks

- Metric change detection comments only on 1st-party PRs ([#1167](https://github.com/ava-labs/firewood/pull/1167))
- Run CI on macOS ([#1168](https://github.com/ava-labs/firewood/pull/1168))
- Update .golangci.yaml ([#1166](https://github.com/ava-labs/firewood/pull/1166))
- Allow FreeListIterator to skip to next free list ([#1177](https://github.com/ava-labs/firewood/pull/1177))
- Address lints triggered with rust 1.89 ([#1182](https://github.com/ava-labs/firewood/pull/1182))
- Deny `undocumented-unsafe-blocks` ([#1172](https://github.com/ava-labs/firewood/pull/1172))
- Fwdctl cleanups ([#1190](https://github.com/ava-labs/firewood/pull/1190))
- AreaIndex newtype ([#1193](https://github.com/ava-labs/firewood/pull/1193))
- Remove setup-protoc ([#1203](https://github.com/ava-labs/firewood/pull/1203))
- Automatically label PRs from external contributors ([#1195](https://github.com/ava-labs/firewood/pull/1195))
- Don't fail fast on certain jobs ([#1198](https://github.com/ava-labs/firewood/pull/1198))
- Add PathGuard type when computing hashes ([#1202](https://github.com/ava-labs/firewood/pull/1202))
- *(checker)* Add function to compute area counts and bytes ([#1218](https://github.com/ava-labs/firewood/pull/1218))

## [0.0.10] - 2025-08-01

### 🚀 Features

- *(async-iterator)* Implement ([#1096](https://github.com/ava-labs/firewood/pull/1096))
- Export logs ([#1070](https://github.com/ava-labs/firewood/pull/1070))
- Render the commit sha in fwdctl ([#1109](https://github.com/ava-labs/firewood/pull/1109))
- Update proof types to be generic over mutable or immutable collections ([#1121](https://github.com/ava-labs/firewood/pull/1121))
- Refactor value types to use the type alias ([#1122](https://github.com/ava-labs/firewood/pull/1122))
- *(dumper)* Child links in hex (easy) ([#1124](https://github.com/ava-labs/firewood/pull/1124))
- *(deferred-allocate)* Part 3: Defer allocate ([#1061](https://github.com/ava-labs/firewood/pull/1061))
- *(checker)* Disable buggy ethhash checker ([#1127](https://github.com/ava-labs/firewood/pull/1127))
- Add `Children<T>` type alias ([#1123](https://github.com/ava-labs/firewood/pull/1123))
- Make NodeStore more generic ([#1134](https://github.com/ava-labs/firewood/pull/1134))
- *(checker)* Add progress bar ([#1105](https://github.com/ava-labs/firewood/pull/1105))
- *(checker)* Checker errors include reference to parent ([#1085](https://github.com/ava-labs/firewood/pull/1085))
- Update RangeProof structure ([#1136](https://github.com/ava-labs/firewood/pull/1136))
- Update range_proof signature ([#1151](https://github.com/ava-labs/firewood/pull/1151))
- *(checker)* Add InvalidKey error
- *(deferred-persist)* Part 1: unpersisted gauge ([#1116](https://github.com/ava-labs/firewood/pull/1116))
- *(checker)* Collect basic statistics while checking the db image ([#1149](https://github.com/ava-labs/firewood/pull/1149))
- *(fwdctl)* Add support for dump formats ([#1161](https://github.com/ava-labs/firewood/pull/1161))
- *(ffi)* Remove the Arc wrapper around Proposal ([#1160](https://github.com/ava-labs/firewood/pull/1160))

### 🐛 Bug Fixes

- *(fwdctl)* Fix fwdctl with ethhash ([#1091](https://github.com/ava-labs/firewood/pull/1091))
- *(checker)* Fix checker with ethhash ([#1130](https://github.com/ava-labs/firewood/pull/1130))
- Fix broken deserialization of old FreeArea format ([#1147](https://github.com/ava-labs/firewood/pull/1147))
- Create metrics registration macros ([#980](https://github.com/ava-labs/firewood/pull/980))

### 💼 Other

- Cargo.toml upgrades and fixes ([#1099](https://github.com/ava-labs/firewood/pull/1099))
- *(deps)* Update criterion requirement from 0.6.0 to 0.7.0 ([#1140](https://github.com/ava-labs/firewood/pull/1140))

### 📚 Documentation

- Update ffi/README.md to include configs, metrics, and logs ([#1111](https://github.com/ava-labs/firewood/pull/1111))

### 🎨 Styling

- Remove unnecessary string in error ([#1104](https://github.com/ava-labs/firewood/pull/1104))

### 🧪 Testing

- Add fuzz testing for checker, with fixes ([#1118](https://github.com/ava-labs/firewood/pull/1118))
- Port TestDeepPropose from go->rust ([#1115](https://github.com/ava-labs/firewood/pull/1115))

### ⚙️ Miscellaneous Tasks

- Add propose-on-propose test ([#1097](https://github.com/ava-labs/firewood/pull/1097))
- Implement newtype for LInearAddress ([#1086](https://github.com/ava-labs/firewood/pull/1086))
- Refactor verifying value digests ([#1119](https://github.com/ava-labs/firewood/pull/1119))
- Checker test cleanups ([#1131](https://github.com/ava-labs/firewood/pull/1131))
- Minor cleanups and nits ([#1133](https://github.com/ava-labs/firewood/pull/1133))
- Add a golang install script ([#1141](https://github.com/ava-labs/firewood/pull/1141))
- Move all merkle tests into a subdirectory ([#1150](https://github.com/ava-labs/firewood/pull/1150))
- Require license header for ffi code ([#1159](https://github.com/ava-labs/firewood/pull/1159))
- Bump version to v0.0.10 ([#1165](https://github.com/ava-labs/firewood/pull/1165))

## [0.0.9] - 2025-07-17

### 🚀 Features

- *(ffi)* Add gauges to metrics reporter ([#1035](https://github.com/ava-labs/firewood/pull/1035))
- *(delayed-persist)* Part 1: Roots may be in mem ([#1041](https://github.com/ava-labs/firewood/pull/1041))
- *(delayed-persist)* 2.1: Unpersisted deletions ([#1045](https://github.com/ava-labs/firewood/pull/1045))
- *(delayed-persist)* Part 2.2: Branch Children ([#1047](https://github.com/ava-labs/firewood/pull/1047))
- [**breaking**] Export firewood metrics ([#1044](https://github.com/ava-labs/firewood/pull/1044))
- *(checker)* Add error to report finding leaked areas ([#1052](https://github.com/ava-labs/firewood/pull/1052))
- *(delayed-persist)* Dump unpersisted nodestore ([#1055](https://github.com/ava-labs/firewood/pull/1055))
- *(checker)* Split leaked ranges into valid areas ([#1059](https://github.com/ava-labs/firewood/pull/1059))
- *(checker)* Check for misaligned stored areas ([#1046](https://github.com/ava-labs/firewood/pull/1046))
- [**breaking**] Auto open or create with truncate ([#1064](https://github.com/ava-labs/firewood/pull/1064))
- *(deferred-allocate)* UnpersistedIterator ([#1060](https://github.com/ava-labs/firewood/pull/1060))
- *(checker)* Add hash checks ([#1063](https://github.com/ava-labs/firewood/pull/1063))

### 🐛 Bug Fixes

- Avoid reference to LinearAddress ([#1042](https://github.com/ava-labs/firewood/pull/1042))
- Remove dependency on serde ([#1066](https://github.com/ava-labs/firewood/pull/1066))
- Encoding partial paths for leaf nodes ([#1067](https://github.com/ava-labs/firewood/pull/1067))
- Root_hash_reversed_deletions duplicate keys ([#1076](https://github.com/ava-labs/firewood/pull/1076))
- *(checker)* Avoid checking physical file size for compatibility ([#1079](https://github.com/ava-labs/firewood/pull/1079))

### 🎨 Styling

- Remove unnecessary error descriptor ([#1049](https://github.com/ava-labs/firewood/pull/1049))

### ⚙️ Miscellaneous Tasks

- *(build)* Remove unused dependencies ([#1037](https://github.com/ava-labs/firewood/pull/1037))
- Update firewood in grpc-testtool ([#1040](https://github.com/ava-labs/firewood/pull/1040))
- Aaron is requested only for .github ([#1043](https://github.com/ava-labs/firewood/pull/1043))
- Remove `#[allow]`s no longer needed ([#1022](https://github.com/ava-labs/firewood/pull/1022))
- Split nodestore into functional areas ([#1048](https://github.com/ava-labs/firewood/pull/1048))
- Update `golangci-lint` ([#1053](https://github.com/ava-labs/firewood/pull/1053))
- Update CODEOWNERS ([#1080](https://github.com/ava-labs/firewood/pull/1080))
- Run CI with --no-default-features ([#1081](https://github.com/ava-labs/firewood/pull/1081))
- Release 0.0.9 ([#1084](https://github.com/ava-labs/firewood/pull/1084))

## [0.0.8] - 2025-07-07

### 🚀 Features

- *(checker)* Firewood checker framework ([#936](https://github.com/ava-labs/firewood/pull/936))
- Enable a configurable free list cache in the FFI ([#1017](https://github.com/ava-labs/firewood/pull/1017))
- *(nodestore)* Add functionalities to iterate the free list ([#1015](https://github.com/ava-labs/firewood/pull/1015))
- *(checker)* Traverse free lists ([#1026](https://github.com/ava-labs/firewood/pull/1026))

### 🐛 Bug Fixes

- Unnecessary quotes in publish action ([#996](https://github.com/ava-labs/firewood/pull/996))
- Report IO errors ([#1005](https://github.com/ava-labs/firewood/pull/1005))
- Publish firewood-macros ([#1019](https://github.com/ava-labs/firewood/pull/1019))
- Logger macros causing linting warnings ([#1021](https://github.com/ava-labs/firewood/pull/1021))

### 💼 Other

- *(deps)* Update lru requirement from 0.14.0 to 0.15.0 ([#1001](https://github.com/ava-labs/firewood/pull/1001))
- *(deps)* Update lru requirement from 0.15.0 to 0.16.0 ([#1023](https://github.com/ava-labs/firewood/pull/1023))
- *(deps)* Upgrade sha2, tokio, clap, fastrace, serde... ([#1025](https://github.com/ava-labs/firewood/pull/1025))

### 🚜 Refactor

- *(deps)* Move duplicates to workspace ([#1002](https://github.com/ava-labs/firewood/pull/1002))
- *(ffi)* [**breaking**] Split starting metrics exporter from db startup ([#1016](https://github.com/ava-labs/firewood/pull/1016))

### 📚 Documentation

- README cleanup ([#1024](https://github.com/ava-labs/firewood/pull/1024))

### ⚡ Performance

- Cache the latest view ([#1004](https://github.com/ava-labs/firewood/pull/1004))
- Allow cloned proposals ([#1010](https://github.com/ava-labs/firewood/pull/1010))
- Break up the RevisionManager lock ([#1027](https://github.com/ava-labs/firewood/pull/1027))

### ⚙️ Miscellaneous Tasks

- Suppress clippy::cast_possible_truncation across the workspace ([#1012](https://github.com/ava-labs/firewood/pull/1012))
- Clippy pushdown ([#1011](https://github.com/ava-labs/firewood/pull/1011))
- Allow some extra pedantic warnings ([#1014](https://github.com/ava-labs/firewood/pull/1014))
- Check for metrics changes ([#1013](https://github.com/ava-labs/firewood/pull/1013))
- Share workspace metadata and packages ([#1020](https://github.com/ava-labs/firewood/pull/1020))
- Add concurrency group to attach static libs workflow ([#1038](https://github.com/ava-labs/firewood/pull/1038))
- Bump version to v0.0.8 ([#1018](https://github.com/ava-labs/firewood/pull/1018))

## [0.0.7] - 2025-06-26

### 🚀 Features

- Add methods to fetch views from any hash ([#993](https://github.com/ava-labs/firewood/pull/993))

### 🐛 Bug Fixes

- *(ci)* Include submodule name in ffi tag ([#991](https://github.com/ava-labs/firewood/pull/991))

### ⚡ Performance

- *(metrics)* Add some metrics around propose and commit times ([#989](https://github.com/ava-labs/firewood/pull/989))

### 🎨 Styling

- Use cbindgen to convert to pointers ([#969](https://github.com/ava-labs/firewood/pull/969))

### 🧪 Testing

- Check support for empty proposals ([#988](https://github.com/ava-labs/firewood/pull/988))

### ⚙️ Miscellaneous Tasks

- Simplify + cleanup generate_cgo script ([#979](https://github.com/ava-labs/firewood/pull/979))
- Update Cargo.toml add repository field ([#987](https://github.com/ava-labs/firewood/pull/987))
- *(fuzz)* Add step to upload fuzz testdata on failure ([#990](https://github.com/ava-labs/firewood/pull/990))
- Add special case for non semver tags to attach static libs ([#992](https://github.com/ava-labs/firewood/pull/992))
- Remove requirement for conventional commits ([#994](https://github.com/ava-labs/firewood/pull/994))
- Release v0.0.7 ([#997](https://github.com/ava-labs/firewood/pull/997))

## [0.0.6] - 2025-06-21

### 🚀 Features

- Improve error handling and add sync iterator ([#941](https://github.com/ava-labs/firewood/pull/941))
- *(metrics)* Add read_node counters ([#947](https://github.com/ava-labs/firewood/pull/947))
- Return database creation errors through FFI ([#945](https://github.com/ava-labs/firewood/pull/945))
- *(ffi)* Add go generate switch between enabled cgo blocks ([#978](https://github.com/ava-labs/firewood/pull/978))

### 🐛 Bug Fixes

- Use saturating subtraction for metrics counter ([#937](https://github.com/ava-labs/firewood/pull/937))
- *(attach-static-libs)* Push commit/branch to remote on tag events ([#944](https://github.com/ava-labs/firewood/pull/944))
- Add add_arithmetic_side_effects clippy ([#949](https://github.com/ava-labs/firewood/pull/949))
- Improve ethhash warning message ([#961](https://github.com/ava-labs/firewood/pull/961))
- *(storage)* Parse and validate database versions ([#964](https://github.com/ava-labs/firewood/pull/964))

### 💼 Other

- *(deps)* Update fastrace-opentelemetry requirement from 0.11.0 to 0.12.0 ([#943](https://github.com/ava-labs/firewood/pull/943))
- Move lints to the workspace ([#957](https://github.com/ava-labs/firewood/pull/957))

### ⚡ Performance

- Remove some unecessary allocs during serialization ([#965](https://github.com/ava-labs/firewood/pull/965))

### 🎨 Styling

- *(attach-static-libs)* Use go mod edit instead of sed to update mod path ([#946](https://github.com/ava-labs/firewood/pull/946))

### 🧪 Testing

- *(ethhash)* Convert ethhash test to fuzz test for ethhash compatibility ([#956](https://github.com/ava-labs/firewood/pull/956))

### ⚙️ Miscellaneous Tasks

- Upgrade actions/checkout ([#939](https://github.com/ava-labs/firewood/pull/939))
- Add push to main to attach static libs triggers ([#952](https://github.com/ava-labs/firewood/pull/952))
- Check the PR title for conventional commits ([#953](https://github.com/ava-labs/firewood/pull/953))
- Add Brandon to CODEOWNERS ([#954](https://github.com/ava-labs/firewood/pull/954))
- Set up for publishing to crates.io ([#962](https://github.com/ava-labs/firewood/pull/962))
- Remove remnants of no-std ([#968](https://github.com/ava-labs/firewood/pull/968))
- *(ffi)* Rename ffi package to match dir ([#971](https://github.com/ava-labs/firewood/pull/971))
- *(attach-static-libs)* Add pre build command to set MACOSX_DEPLOYMENT_TARGET for static libs build ([#973](https://github.com/ava-labs/firewood/pull/973))
- Use new firewood-go-* FFI repo naming ([#975](https://github.com/ava-labs/firewood/pull/975))
- Upgrade metrics packages ([#982](https://github.com/ava-labs/firewood/pull/982))
- Release v0.0.6 ([#985](https://github.com/ava-labs/firewood/pull/985))

## [0.0.5] - 2025-06-05

### 🚀 Features

- *(ffi)* Ffi error messages ([#860](https://github.com/ava-labs/firewood/pull/860))
- *(ffi)* Proposal creation isolated from committing ([#867](https://github.com/ava-labs/firewood/pull/867))
- *(ffi)* Get values from proposals ([#877](https://github.com/ava-labs/firewood/pull/877))
- *(ffi)* Full proposal support ([#878](https://github.com/ava-labs/firewood/pull/878))
- *(ffi)* Support `Get` for historical revisions ([#881](https://github.com/ava-labs/firewood/pull/881))
- *(ffi)* Add proposal root retrieval ([#910](https://github.com/ava-labs/firewood/pull/910))

### 🐛 Bug Fixes

- *(ffi)* Prevent memory leak and tips for finding leaks ([#862](https://github.com/ava-labs/firewood/pull/862))
- *(src)* Drop unused revisions ([#866](https://github.com/ava-labs/firewood/pull/866))
- *(ffi)* Clarify roles of `Value` extractors ([#875](https://github.com/ava-labs/firewood/pull/875))
- *(ffi)* Check revision is available ([#890](https://github.com/ava-labs/firewood/pull/890))
- *(ffi)* Prevent undefined behavior on empty slices ([#894](https://github.com/ava-labs/firewood/pull/894))
- Fix empty hash values ([#925](https://github.com/ava-labs/firewood/pull/925))

### 💼 Other

- *(deps)* Update pprof requirement from 0.12.1 to 0.13.0 ([#283](https://github.com/ava-labs/firewood/pull/283))
- *(deps)* Update lru requirement from 0.11.0 to 0.12.0 ([#306](https://github.com/ava-labs/firewood/pull/306))
- *(deps)* Update typed-builder requirement from 0.16.0 to 0.17.0 ([#320](https://github.com/ava-labs/firewood/pull/320))
- *(deps)* Update typed-builder requirement from 0.17.0 to 0.18.0 ([#324](https://github.com/ava-labs/firewood/pull/324))
- Remove dead code ([#333](https://github.com/ava-labs/firewood/pull/333))
- Kv_dump should be done with the iterator ([#347](https://github.com/ava-labs/firewood/pull/347))
- Add remaining lint checks ([#397](https://github.com/ava-labs/firewood/pull/397))
- Finish error handler mapper ([#421](https://github.com/ava-labs/firewood/pull/421))
- Switch from EmptyDB to Db ([#422](https://github.com/ava-labs/firewood/pull/422))
- *(deps)* Update aquamarine requirement from 0.3.1 to 0.4.0 ([#434](https://github.com/ava-labs/firewood/pull/434))
- *(deps)* Update serial_test requirement from 2.0.0 to 3.0.0 ([#477](https://github.com/ava-labs/firewood/pull/477))
- *(deps)* Update aquamarine requirement from 0.4.0 to 0.5.0 ([#496](https://github.com/ava-labs/firewood/pull/496))
- *(deps)* Update env_logger requirement from 0.10.1 to 0.11.0 ([#502](https://github.com/ava-labs/firewood/pull/502))
- *(deps)* Update tonic-build requirement from 0.10.2 to 0.11.0 ([#522](https://github.com/ava-labs/firewood/pull/522))
- *(deps)* Update tonic requirement from 0.10.2 to 0.11.0 ([#523](https://github.com/ava-labs/firewood/pull/523))
- *(deps)* Update nix requirement from 0.27.1 to 0.28.0 ([#563](https://github.com/ava-labs/firewood/pull/563))
- Move clippy pragma closer to usage ([#578](https://github.com/ava-labs/firewood/pull/578))
- *(deps)* Update typed-builder requirement from 0.18.1 to 0.19.1 ([#684](https://github.com/ava-labs/firewood/pull/684))
- *(deps)* Update lru requirement from 0.8.0 to 0.12.4 ([#708](https://github.com/ava-labs/firewood/pull/708))
- *(deps)* Update typed-builder requirement from 0.19.1 to 0.20.0 ([#711](https://github.com/ava-labs/firewood/pull/711))
- *(deps)* Bump actions/download-artifact from 3 to 4.1.7 in /.github/workflows ([#715](https://github.com/ava-labs/firewood/pull/715))
- Insert truncated trie
- Allow for trace and no logging
- Add read_for_update
- Revision history should never grow
- Use a more random hash
- Use smallvec to optimize for 16 byte values
- *(deps)* Update aquamarine requirement from 0.5.0 to 0.6.0 ([#727](https://github.com/ava-labs/firewood/pull/727))
- *(deps)* Update thiserror requirement from 1.0.57 to 2.0.3 ([#751](https://github.com/ava-labs/firewood/pull/751))
- *(deps)* Update pprof requirement from 0.13.0 to 0.14.0 ([#750](https://github.com/ava-labs/firewood/pull/750))
- *(deps)* Update metrics-util requirement from 0.18.0 to 0.19.0 ([#765](https://github.com/ava-labs/firewood/pull/765))
- *(deps)* Update cbindgen requirement from 0.27.0 to 0.28.0 ([#767](https://github.com/ava-labs/firewood/pull/767))
- *(deps)* Update bitfield requirement from 0.17.0 to 0.18.1 ([#772](https://github.com/ava-labs/firewood/pull/772))
- *(deps)* Update lru requirement from 0.12.4 to 0.13.0 ([#771](https://github.com/ava-labs/firewood/pull/771))
- *(deps)* Update bitfield requirement from 0.18.1 to 0.19.0 ([#801](https://github.com/ava-labs/firewood/pull/801))
- *(deps)* Update typed-builder requirement from 0.20.0 to 0.21.0 ([#815](https://github.com/ava-labs/firewood/pull/815))
- *(deps)* Update tonic requirement from 0.12.1 to 0.13.0 ([#826](https://github.com/ava-labs/firewood/pull/826))
- *(deps)* Update opentelemetry requirement from 0.28.0 to 0.29.0 ([#816](https://github.com/ava-labs/firewood/pull/816))
- *(deps)* Update lru requirement from 0.13.0 to 0.14.0 ([#840](https://github.com/ava-labs/firewood/pull/840))
- *(deps)* Update metrics-exporter-prometheus requirement from 0.16.1 to 0.17.0 ([#853](https://github.com/ava-labs/firewood/pull/853))
- *(deps)* Update rand requirement from 0.8.5 to 0.9.1 ([#850](https://github.com/ava-labs/firewood/pull/850))
- *(deps)* Update pprof requirement from 0.14.0 to 0.15.0 ([#906](https://github.com/ava-labs/firewood/pull/906))
- *(deps)* Update cbindgen requirement from 0.28.0 to 0.29.0 ([#899](https://github.com/ava-labs/firewood/pull/899))
- *(deps)* Update criterion requirement from 0.5.1 to 0.6.0 ([#898](https://github.com/ava-labs/firewood/pull/898))
- *(deps)* Bump golang.org/x/crypto from 0.17.0 to 0.35.0 in /ffi/tests ([#907](https://github.com/ava-labs/firewood/pull/907))
- *(deps)* Bump google.golang.org/protobuf from 1.27.1 to 1.33.0  /ffi/tests ([#923](https://github.com/ava-labs/firewood/pull/923))
- *(deps)* Bump google.golang.org/protobuf from 1.30.0 to 1.33.0 ([#924](https://github.com/ava-labs/firewood/pull/924))

### 🚜 Refactor

- *(ffi)* Cleanup unused and duplicate code ([#926](https://github.com/ava-labs/firewood/pull/926))

### 📚 Documentation

- *(ffi)* Remove private declarations from public docs ([#874](https://github.com/ava-labs/firewood/pull/874))

### 🧪 Testing

- *(ffi/tests)* Basic eth compatibility ([#825](https://github.com/ava-labs/firewood/pull/825))
- *(ethhash)* Use libevm ([#900](https://github.com/ava-labs/firewood/pull/900))

### ⚙️ Miscellaneous Tasks

- Use `decode` in single key proof verification ([#295](https://github.com/ava-labs/firewood/pull/295))
- Use `decode` in range proof verification ([#303](https://github.com/ava-labs/firewood/pull/303))
- Naming the elements of `ExtNode` ([#305](https://github.com/ava-labs/firewood/pull/305))
- Remove the getter pattern over `ExtNode` ([#310](https://github.com/ava-labs/firewood/pull/310))
- Proof cleanup ([#316](https://github.com/ava-labs/firewood/pull/316))
- *(ffi/tests)* Update go-ethereum v1.15.7 ([#838](https://github.com/ava-labs/firewood/pull/838))
- *(ffi)* Fix typo fwd_close_db comment ([#843](https://github.com/ava-labs/firewood/pull/843))
- *(ffi)* Add linter ([#893](https://github.com/ava-labs/firewood/pull/893))
- Require conventional commit format ([#933](https://github.com/ava-labs/firewood/pull/933))
- Bump to v0.5.0 ([#934](https://github.com/ava-labs/firewood/pull/934))

## [0.0.4] - 2023-09-27

### 🚀 Features

- Identify a revision with root hash ([#126](https://github.com/ava-labs/firewood/pull/126))
- Supports chains of `StoreRevMut` ([#175](https://github.com/ava-labs/firewood/pull/175))
- Add proposal ([#181](https://github.com/ava-labs/firewood/pull/181))

### 🐛 Bug Fixes

- Update release to cargo-workspace-version ([#75](https://github.com/ava-labs/firewood/pull/75))

### 💼 Other

- *(deps)* Update criterion requirement from 0.4.0 to 0.5.1 ([#96](https://github.com/ava-labs/firewood/pull/96))
- *(deps)* Update enum-as-inner requirement from 0.5.1 to 0.6.0 ([#107](https://github.com/ava-labs/firewood/pull/107))
- :position FTW? ([#140](https://github.com/ava-labs/firewood/pull/140))
- *(deps)* Update indexmap requirement from 1.9.1 to 2.0.0 ([#147](https://github.com/ava-labs/firewood/pull/147))
- *(deps)* Update pprof requirement from 0.11.1 to 0.12.0 ([#152](https://github.com/ava-labs/firewood/pull/152))
- *(deps)* Update typed-builder requirement from 0.14.0 to 0.15.0 ([#153](https://github.com/ava-labs/firewood/pull/153))
- *(deps)* Update lru requirement from 0.10.0 to 0.11.0 ([#155](https://github.com/ava-labs/firewood/pull/155))
- Update hash fn to root_hash ([#170](https://github.com/ava-labs/firewood/pull/170))
- Remove generics on Db ([#196](https://github.com/ava-labs/firewood/pull/196))
- Remove generics for Proposal ([#197](https://github.com/ava-labs/firewood/pull/197))
- Use quotes around all ([#200](https://github.com/ava-labs/firewood/pull/200))
- :get<K>: use Nibbles ([#210](https://github.com/ava-labs/firewood/pull/210))
- Variable renames ([#211](https://github.com/ava-labs/firewood/pull/211))
- Use thiserror ([#221](https://github.com/ava-labs/firewood/pull/221))
- *(deps)* Update typed-builder requirement from 0.15.0 to 0.16.0 ([#222](https://github.com/ava-labs/firewood/pull/222))
- *(deps)* Update tonic-build requirement from 0.9.2 to 0.10.0 ([#247](https://github.com/ava-labs/firewood/pull/247))
- *(deps)* Update prost requirement from 0.11.9 to 0.12.0 ([#246](https://github.com/ava-labs/firewood/pull/246))

### ⚙️ Miscellaneous Tasks

- Refactor `rev.rs` ([#74](https://github.com/ava-labs/firewood/pull/74))
- Disable `test_buffer_with_redo` ([#128](https://github.com/ava-labs/firewood/pull/128))
- Verify concurrent committing write batches ([#172](https://github.com/ava-labs/firewood/pull/172))
- Remove redundant code ([#174](https://github.com/ava-labs/firewood/pull/174))
- Remove unused clone for `StoreRevMutDelta` ([#178](https://github.com/ava-labs/firewood/pull/178))
- Abstract out mutable store creation ([#176](https://github.com/ava-labs/firewood/pull/176))
- Proposal test cleanup ([#184](https://github.com/ava-labs/firewood/pull/184))
- Add comments for `Proposal` ([#186](https://github.com/ava-labs/firewood/pull/186))
- Deprecate `WriteBatch` and use `Proposal` instead ([#188](https://github.com/ava-labs/firewood/pull/188))
- Inline doc clean up ([#240](https://github.com/ava-labs/firewood/pull/240))
- Remove unused blob in db ([#245](https://github.com/ava-labs/firewood/pull/245))
- Add license header to firewood files ([#262](https://github.com/ava-labs/firewood/pull/262))
- Revert back `test_proof` changes accidentally changed ([#279](https://github.com/ava-labs/firewood/pull/279))

## [0.0.3] - 2023-04-28

### 💼 Other

- Move benching to criterion ([#61](https://github.com/ava-labs/firewood/pull/61))
- Refactor file operations to use a Path ([#26](https://github.com/ava-labs/firewood/pull/26))
- Fix panic get_item on a dirty write ([#66](https://github.com/ava-labs/firewood/pull/66))
- Improve error handling ([#70](https://github.com/ava-labs/firewood/pull/70))

### 🧪 Testing

- Speed up slow unit tests ([#58](https://github.com/ava-labs/firewood/pull/58))

### ⚙️ Miscellaneous Tasks

- Add backtrace to e2e tests ([#59](https://github.com/ava-labs/firewood/pull/59))

## [0.0.2] - 2023-04-21

### 💼 Other

- Fix test flake ([#44](https://github.com/ava-labs/firewood/pull/44))

### 📚 Documentation

- Add release notes ([#27](https://github.com/ava-labs/firewood/pull/27))
- Update CODEOWNERS ([#28](https://github.com/ava-labs/firewood/pull/28))
- Add badges to README ([#33](https://github.com/ava-labs/firewood/pull/33))

## [0.0.1] - 2023-04-14

### 🐛 Bug Fixes

- Clippy linting
- Specificy --lib in rustdoc linters
- Unset the pre calculated RLP values of interval nodes
- Run cargo clippy --fix
- Handle empty key value proof arguments as an error
- Tweak repo organization ([#130](https://github.com/ava-labs/firewood/pull/130))
- Run clippy --fix across all workspaces ([#149](https://github.com/ava-labs/firewood/pull/149))
- Update StoreError to use thiserror ([#156](https://github.com/ava-labs/firewood/pull/156))
- Update db::new() to accept a Path ([#187](https://github.com/ava-labs/firewood/pull/187))
- Use bytemuck instead of unsafe in growth-ring ([#185](https://github.com/ava-labs/firewood/pull/185))
- Update firewood sub-projects ([#16](https://github.com/ava-labs/firewood/pull/16))

### 💼 Other

- Fix additional clippy warnings
- Additional clippy fixes
- Fix additional clippy warnings
- Fix outstanding lint issues
- *(deps)* Update nix requirement from 0.25.0 to 0.26.1
- Update version to 0.0.1
- Add usage examples
- Add fwdctl create command
- Add fwdctl README and test
- Fix flag arguments; add fwdctl documentation
- Add logger
- Use log-level flag for setting logging level
- *(deps)* Update lru requirement from 0.8.0 to 0.9.0
- Add generic key value insertion command
- Add get command
- Add delete command
- Move cli tests under tests/
- Only use kv_ functions in fwdctl
- Fix implementation and add tests
- Add exit codes and stderr error logging
- Add tests
- Add serial library for testing purposes
- Add root command
- Add dump command
- Fixup root tests to be serial
- *(deps)* Update typed-builder requirement from 0.11.0 to 0.12.0
- Add VSCode
- Update merkle_utils to return Results
- Fixup command UX to be positional
- Update firewood to match needed functionality
- Update DB and Merkle errors to implement the Error trait
- Update proof errors
- Add StdError trait to ProofError
- *(deps)* Update nix requirement from 0.25.0 to 0.26.2
- *(deps)* Update lru requirement from 0.8.0 to 0.10.0
- *(deps)* Update typed-builder requirement from 0.12.0 to 0.13.0
- *(deps)* Update typed-builder requirement from 0.13.0 to 0.14.0 ([#144](https://github.com/ava-labs/firewood/pull/144))
- Update create_file to return a Result ([#150](https://github.com/ava-labs/firewood/pull/150))
- *(deps)* Update predicates requirement from 2.1.1 to 3.0.1 ([#154](https://github.com/ava-labs/firewood/pull/154))
- Add new library crate ([#158](https://github.com/ava-labs/firewood/pull/158))
- *(deps)* Update serial_test requirement from 1.0.0 to 2.0.0 ([#173](https://github.com/ava-labs/firewood/pull/173))
- Refactor kv_remove to be more ergonomic ([#168](https://github.com/ava-labs/firewood/pull/168))
- Add e2e test ([#167](https://github.com/ava-labs/firewood/pull/167))
- Use eth and proof feature gates across all API surfaces. ([#181](https://github.com/ava-labs/firewood/pull/181))
- Add license header to firewood source code ([#189](https://github.com/ava-labs/firewood/pull/189))

### 📚 Documentation

- Add link to fwdctl README in main README
- Update fwdctl README with storage information
- Update fwdctl README with more examples
- Document get_revisions function with additional information. ([#177](https://github.com/ava-labs/firewood/pull/177))
- Add alpha warning to firewood README ([#191](https://github.com/ava-labs/firewood/pull/191))

### 🧪 Testing

- Add more range proof tests
- Update tests to use Results
- Re-enable integration tests after introduce cargo workspaces

### ⚙️ Miscellaneous Tasks

- Add release and publish GH Actions
- Update batch sizes in ci e2e job
- Add docs linter to strengthen firewood documentation
- Clippy should fail in case of warnings ([#151](https://github.com/ava-labs/firewood/pull/151))
- Fail in case of error publishing firewood crate ([#21](https://github.com/ava-labs/firewood/pull/21))

<!-- generated by git-cliff -->
