// Copyright (C) 2023, Ava Labs, Inc. All rights reserved.
// See the file LICENSE.md for licensing terms.

#![doc = include_str!("../README.md")]

use std::path::PathBuf;

use clap::{Parser, Subcommand};
use firewood::api;

pub mod check;
pub mod create;
pub mod delete;
pub mod dump;
pub mod get;
pub mod graph;
pub mod import;
pub mod insert;
pub mod key;
#[cfg(feature = "launch")]
pub mod launch;
pub mod replay;
pub mod root;

#[derive(Clone, Debug, Parser)]
pub struct DatabasePath {
    /// The database path. Defaults to firewood
    #[arg(
        long = "db",
        short = 'd',
        required = false,
        value_name = "DB_DIR_NAME",
        default_value_os_t = default_db_path(),
        help = "Name of the database directory"
    )]
    pub dbpath: PathBuf,
}

impl DatabasePath {
    /// Reads the node-hashing scheme from the existing database header.
    ///
    /// All commands other than `create` require a database to exist so its
    /// persisted scheme remains the single source of truth.
    ///
    /// # Errors
    ///
    /// Returns an error if the database file or its header cannot be read.
    pub(crate) fn node_hash_algorithm(
        &self,
    ) -> Result<firewood_storage::NodeHashAlgorithm, firewood_storage::FileIoError> {
        firewood_storage::NodeStoreHeader::read_node_hash_algorithm_from_file(
            self.dbpath.join("firewood.db"),
        )
    }
}

#[derive(Parser)]
#[command(author, version, about, long_about = None)]
#[command(propagate_version = true)]
#[command(version = concat!(env!("CARGO_PKG_VERSION"), " (", env!("GIT_COMMIT_SHA"), ", ", env!("ETHHASH_FEATURE"), ")"))]
struct Cli {
    #[command(subcommand)]
    command: Commands,
    #[arg(
        long,
        short = 'l',
        required = false,
        help = "Log level. Respects RUST_LOG.",
        value_name = "LOG_LEVEL",
        num_args = 1,
        value_parser = ["debug", "info"],
        default_value_t = String::from("info"),
    )]
    log_level: String,
}

#[derive(Subcommand)]
enum Commands {
    /// Create a new firewood database
    Create(create::Options),
    /// Insert a key/value pair into the database
    Insert(insert::Options),
    /// Get values associated with a key
    Get(get::Options),
    /// Delete values associated with a key
    Delete(delete::Options),
    /// Restore database from a dump file
    Import(import::Options),
    /// Display key/value trie root hash
    Root(root::Options),
    /// Dump contents of key/value store
    Dump(dump::Options),
    /// Produce a dot file of the database
    Graph(graph::Options),
    /// Runs the checker on the database
    Check(check::Options),
    /// Replay recorded operations from a log file
    Replay(replay::Options),
    #[cfg(feature = "launch")]
    /// Launch AWS instance for benchmarking
    Launch(launch::Options),
}

fn main() -> Result<(), api::Error> {
    let cli = Cli::parse();

    env_logger::init_from_env(
        env_logger::Env::default().filter_or(env_logger::DEFAULT_FILTER_ENV, cli.log_level.clone()),
    );

    match &cli.command {
        Commands::Create(opts) => create::run(opts),
        Commands::Insert(opts) => insert::run(opts),
        Commands::Get(opts) => get::run(opts),
        Commands::Delete(opts) => delete::run(opts),
        Commands::Import(opts) => import::run(opts),
        Commands::Root(opts) => root::run(opts),
        Commands::Dump(opts) => dump::run(opts),
        Commands::Graph(opts) => graph::run(opts),
        Commands::Check(opts) => check::run(opts),
        Commands::Replay(opts) => replay::run(opts),
        #[cfg(feature = "launch")]
        Commands::Launch(opts) => launch::run(opts),
    }
}

fn default_db_path() -> PathBuf {
    PathBuf::from("firewood")
}
