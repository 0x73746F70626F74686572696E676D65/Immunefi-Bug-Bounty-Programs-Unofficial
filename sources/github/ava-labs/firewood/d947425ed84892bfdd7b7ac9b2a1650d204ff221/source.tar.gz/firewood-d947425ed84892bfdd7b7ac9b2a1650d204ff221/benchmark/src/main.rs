// Copyright (C) 2023, Ava Labs, Inc. All rights reserved.
// See the file LICENSE.md for licensing terms.
//

#![expect(
    clippy::arithmetic_side_effects,
    reason = "Found 2 occurrences after enabling the lint."
)]
#![expect(
    clippy::match_same_arms,
    reason = "Found 1 occurrences after enabling the lint."
)]
#![doc = include_str!("../docs/synthetic-workloads.md")]

use clap::{Parser, Subcommand, ValueEnum};
use fastrace_opentelemetry::OpenTelemetryReporter;
use firewood::logger::trace;
use firewood::open;
use firewood_storage::{DefaultHashMode, FREE_LIST_CACHE_ENTRY_SIZE, HashMode};
use log::LevelFilter;
use sha2::{Digest, Sha256};
use std::borrow::Cow;
use std::error::Error;
use std::fmt::Display;
use std::num::NonZeroUsize;
use std::path::PathBuf;

use firewood::api::DynDb;
use firewood::db::{BatchOp, DbConfig};
use firewood::manager::{CacheReadStrategy, RevisionManagerConfig};

use fastrace::collector::Config;

use opentelemetry::InstrumentationScope;
use opentelemetry_otlp::{SpanExporter, WithExportConfig};
use opentelemetry_sdk::Resource;

#[derive(Parser, Debug)]
struct Args {
    #[clap(flatten)]
    global_opts: GlobalOpts,

    #[clap(subcommand)]
    test_name: TestName,
}

#[derive(clap::Args, Debug)]
struct GlobalOpts {
    #[arg(
        short = 'e',
        long,
        default_value_t = false,
        help = "Enable telemetry server reporting"
    )]
    telemetry_server: bool,
    #[arg(short, long, default_value_t = 10000)]
    batch_size: u64,
    #[arg(short, long, default_value_t = 1000)]
    number_of_batches: u64,
    #[arg(short, long, default_value_t = NonZeroUsize::new(192_000_000).expect("is non-zero"))]
    cache_memory_limit: NonZeroUsize,
    #[arg(short, long, default_value_t = 128)]
    revisions: usize,
    #[cfg(feature = "prometheus")]
    #[arg(
        short = 'p',
        long,
        default_value_t = 3000,
        help = "Port to listen for prometheus"
    )]
    prometheus_port: u16,
    #[cfg(feature = "prometheus")]
    #[arg(
        short = 's',
        long,
        default_value_t = false,
        help = "Dump prometheus stats on exit"
    )]
    stats_dump: bool,

    #[arg(
        long,
        short = 'l',
        required = false,
        help = "Log level. Respects RUST_LOG.",
        value_name = "LOG_LEVEL",
        num_args = 1,
        value_parser = ["trace", "debug", "info", "warn", "none"],
        default_value_t = String::from("info"),
    )]
    log_level: String,
    #[arg(
        long,
        short = 'd',
        required = false,
        help = "Use this database name instead of the default",
        default_value = PathBuf::from("benchmark_db").into_os_string(),
    )]
    dbname: PathBuf,
    #[arg(
        long,
        short = 't',
        required = false,
        help = "Terminate the test after this many minutes",
        default_value_t = 65
    )]
    duration_minutes: u64,
    #[arg(
        long,
        short = 'C',
        required = false,
        help = "Read cache strategy",
        default_value_t = ArgCacheReadStrategy::WritesOnly
    )]
    cache_read_strategy: ArgCacheReadStrategy,
}
#[derive(Debug, PartialEq, ValueEnum, Clone)]
pub enum ArgCacheReadStrategy {
    WritesOnly,
    BranchReads,
    All,
}
impl Display for ArgCacheReadStrategy {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ArgCacheReadStrategy::WritesOnly => write!(f, "writes-only"),
            ArgCacheReadStrategy::BranchReads => write!(f, "branch-reads"),
            ArgCacheReadStrategy::All => write!(f, "all"),
        }
    }
}
impl From<ArgCacheReadStrategy> for CacheReadStrategy {
    fn from(arg: ArgCacheReadStrategy) -> Self {
        match arg {
            ArgCacheReadStrategy::WritesOnly => CacheReadStrategy::WritesOnly,
            ArgCacheReadStrategy::BranchReads => CacheReadStrategy::BranchReads,
            ArgCacheReadStrategy::All => CacheReadStrategy::All,
        }
    }
}

mod create;
mod single;
mod tenkrandom;
mod zipf;

#[derive(Debug, Subcommand, PartialEq)]
enum TestName {
    /// Create a database
    Create,

    /// Insert batches of random keys
    TenKRandom,

    /// Insert batches of keys following a Zipf distribution
    Zipf(zipf::Args),

    /// Repeatedly update a single row
    Single,
}

trait TestRunner {
    fn run(&self, db: &dyn DynDb, args: &Args) -> Result<(), Box<dyn Error>>;

    fn generate_inserts(
        start: u64,
        count: u64,
    ) -> impl Iterator<Item = BatchOp<Box<[u8]>, Box<[u8]>>> {
        (start..start + count)
            .map(|inner_key| {
                let digest: Box<[u8]> = Sha256::digest(inner_key.to_ne_bytes())[..].into();
                trace!(
                    "inserting {:?} with digest {}",
                    inner_key,
                    hex::encode(&digest),
                );
                (digest.clone(), digest)
            })
            .map(|(key, value)| BatchOp::Put { key, value })
            .collect::<Vec<_>>()
            .into_iter()
    }
}

#[global_allocator]
static GLOBAL: tikv_jemallocator::Jemalloc = tikv_jemallocator::Jemalloc;

fn main() -> Result<(), Box<dyn Error>> {
    let args = Args::parse();

    if args.global_opts.telemetry_server {
        let reporter = OpenTelemetryReporter::new(
            SpanExporter::builder()
                .with_tonic()
                .with_endpoint("http://127.0.0.1:4317".to_owned())
                .with_protocol(opentelemetry_otlp::Protocol::Grpc)
                .with_timeout(opentelemetry_otlp::OTEL_EXPORTER_OTLP_TIMEOUT_DEFAULT)
                .build()
                .expect("initialize oltp exporter"),
            Cow::Owned(
                Resource::builder()
                    .with_service_name("avalabs.firewood.benchmark")
                    .build(),
            ),
            InstrumentationScope::builder("firewood")
                .with_version(env!("CARGO_PKG_VERSION"))
                .build(),
        );
        fastrace::set_reporter(reporter, Config::default());
    }

    assert!(
        !(args.test_name == TestName::Single && args.global_opts.batch_size > 1000),
        "Single test is not designed to handle batch sizes > 1000"
    );

    env_logger::Builder::new()
        .filter_level(match args.global_opts.log_level.as_str() {
            "debug" => LevelFilter::Debug,
            "info" => LevelFilter::Info,
            "trace" => LevelFilter::Trace,
            "none" => LevelFilter::Off,
            _ => LevelFilter::Info,
        })
        .init();

    // Manually set up prometheus
    #[cfg(feature = "prometheus")]
    let prometheus_handle = spawn_prometheus_listener(args.global_opts.prometheus_port)
        .expect("failed to spawn prometheus listener");

    let mgrcfg = RevisionManagerConfig::builder()
        .node_cache_memory_limit(args.global_opts.cache_memory_limit)
        // Budget enough free-list cache for four batches' worth of freed nodes,
        // expressed in the kibibytes those entries occupy.
        .freelist_memory_limit_kb(
            NonZeroUsize::new(
                (4 * args.global_opts.batch_size as usize * FREE_LIST_CACHE_ENTRY_SIZE)
                    .div_ceil(1024),
            )
            .expect("batch size > 0"),
        )
        .cache_read_strategy(args.global_opts.cache_read_strategy.clone().into())
        .max_revisions(args.global_opts.revisions)
        .build();
    let cfg = DbConfig::builder()
        .node_hash_algorithm(DefaultHashMode::ALGORITHM)
        .truncate(matches!(args.test_name, TestName::Create))
        .manager(mgrcfg)
        .build();

    let db = open(args.global_opts.dbname.clone(), cfg).expect("db initiation should succeed");

    match args.test_name {
        TestName::Create => {
            let runner = create::Create;
            runner.run(db.as_ref(), &args)?;
        }
        TestName::TenKRandom => {
            let runner = tenkrandom::TenKRandom;
            runner.run(db.as_ref(), &args)?;
        }
        TestName::Zipf(_) => {
            let runner = zipf::Zipf;
            runner.run(db.as_ref(), &args)?;
        }
        TestName::Single => {
            let runner = single::Single;
            runner.run(db.as_ref(), &args)?;
        }
    }

    #[cfg(feature = "prometheus")]
    if args.global_opts.stats_dump {
        println!("{}", prometheus_handle.render());
    }

    fastrace::flush();

    Ok(())
}

#[cfg(feature = "prometheus")]
fn spawn_prometheus_listener(
    port: u16,
) -> Result<metrics_exporter_prometheus::PrometheusHandle, Box<dyn Error>> {
    use metrics_exporter_prometheus::PrometheusBuilder;
    use metrics_util::MetricKindMask;
    use std::net::{Ipv6Addr, SocketAddr};
    use std::time::Duration;

    let rt = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()?;

    let (recorder, exporter) = {
        // PrometheusBuilder::build requires that we be within the tokio runtime context
        // but we don't need to actually invoke the runtime until we spawn the thread
        let _guard = rt.enter();
        PrometheusBuilder::new()
            .with_http_listener(SocketAddr::new(Ipv6Addr::UNSPECIFIED.into(), port))
            .idle_timeout(
                MetricKindMask::COUNTER | MetricKindMask::HISTOGRAM,
                Some(Duration::from_secs(10)),
            )
            .build()?
    };

    std::thread::Builder::new()
        .name("metrics-exporter-prometheus".to_owned())
        .spawn(move || rt.block_on(exporter))?;

    let handle = recorder.handle();

    // Register the Prometheus recorder directly; prefixing is handled by Grafana/Prometheus relabeling.
    metrics::set_global_recorder(recorder)?;

    Ok(handle)
}
