// Copyright (C) 2025, Ava Labs, Inc. All rights reserved.
// See the file LICENSE.md for licensing terms.

package ffi

// #include <stdlib.h>
// #include "firewood.h"
// #cgo noescape fwd_get_from_proposal
// #cgo nocallback fwd_get_from_proposal
// #cgo noescape fwd_iter_on_proposal
// #cgo nocallback fwd_iter_on_proposal
// #cgo noescape fwd_propose_on_proposal
// #cgo nocallback fwd_propose_on_proposal
// #cgo noescape fwd_commit_proposal
// #cgo nocallback fwd_commit_proposal
// #cgo noescape fwd_commit_proposal_with_rebase
// #cgo nocallback fwd_commit_proposal_with_rebase
// #cgo noescape fwd_proposal_dump
// #cgo nocallback fwd_proposal_dump
// #cgo noescape fwd_free_proposal
// #cgo nocallback fwd_free_proposal
import "C"

import (
	"fmt"
	"runtime"
	"sync"
	"unsafe"
)

// errDroppedProposal wraps [ErrDropped].
var errDroppedProposal = fmt.Errorf("proposal %w", ErrDropped)

// Proposal represents a set of proposed changes to be committed to the database.
// Proposals are created via [Database.Propose] or [Proposal.Propose], and must be
// either committed with [Proposal.Commit] or released with [Proposal.Drop].
//
// Proposals must be committed or released before the associated database is
// closed. Release is done by calling [Proposal.Drop]. A finalizer is set on
// each Proposal to ensure Drop is called when the Proposal is garbage
// collected, but relying on finalizers is not recommended. Failing to commit
// or release a proposal before the database is closed will cause it to block
// or fail.
//
// All read operations on a Proposal are thread-safe with respect to each other,
// and can be performed regardless of the state of the associated database. However,
// proposals cannot be committed concurrently with other operations that access
// the latest state of the database, such as [Database.Get] and [Database.Propose],
type Proposal struct {
	// handle is an opaque pointer to the proposal within Firewood. It should be
	// passed to the C FFI functions that operate on proposals
	//
	// It is not safe to call these methods with a nil handle.
	//
	// Calls to `C.fwd_commit_proposal` and `C.fwd_free_proposal` will invalidate
	// this handle, so it should not be used after those calls.
	*handle[*C.ProposalHandle]

	// root is the root hash of the proposal and the expected root hash after commit.
	root Hash

	// commitLock is used to ensure that methods accessing the latest state do not conflict.
	commitLock *sync.Mutex
}

// Root retrieves the root hash of the proposal.
func (p *Proposal) Root() Hash {
	return p.root
}

// Get retrieves the value for the given key.
// If the key does not exist, it returns nil.
func (p *Proposal) Get(key []byte) ([]byte, error) {
	p.lease.mu.RLock()
	defer p.lease.mu.RUnlock()
	if p.dropped {
		return nil, errDroppedProposal
	}

	var pinner runtime.Pinner
	defer pinner.Unpin()

	return getValueFromValueResult(C.fwd_get_from_proposal(p.ptr, newBorrowedBytes(key, &pinner)))
}

// Iter creates an [Iterator] over the key-value pairs in this proposal,
// starting at the first key greater than or equal to the provided key.
// Pass nil or an empty slice to iterate from the beginning.
//
// The Iterator must be released with [Iterator.Drop] when no longer needed,
// otherwise the underlying proposal will never be properly freed.
//
// It returns an error if this Proposal has already been committed or released.
func (p *Proposal) Iter(key []byte) (*Iterator, error) {
	p.lease.mu.RLock()
	defer p.lease.mu.RUnlock()
	if p.dropped {
		return nil, errDroppedProposal
	}

	var pinner runtime.Pinner
	defer pinner.Unpin()

	itResult := C.fwd_iter_on_proposal(p.ptr, newBorrowedBytes(key, &pinner))

	return getIteratorFromIteratorResult(itResult, p.lease.registry)
}

// Propose is equivalent to [Database.Propose] except that the new proposal is
// based on `p`.
// The returned proposal cannot be committed until the parent proposal `p` has been
// committed. Additionally, it must be committed or released before the [Database] is closed.
//
// Use [Put], [Delete], and [PrefixDelete] to create batch operations. A [Put]
// with an empty value stores an empty value; use [Delete] or [PrefixDelete] to
// remove keys.
func (p *Proposal) Propose(batch []BatchOp) (*Proposal, error) {
	p.lease.mu.RLock()
	defer p.lease.mu.RUnlock()
	if p.dropped {
		return nil, errDroppedProposal
	}

	var pinner runtime.Pinner
	defer pinner.Unpin()

	kvp := newKeyValuePairsFromBatch(batch, &pinner)
	return getProposalFromProposalResult(C.fwd_propose_on_proposal(p.ptr, kvp), p.lease.registry, p.commitLock)
}

// Commit commits the proposal and returns any errors.
//
// The underlying data is no longer available during/after this call, but the root
// hash can still be retrieved using [Proposal.Root].
// This is safe to call only once; subsequent calls will return an error.
//
// During this function, the latest state of the database is locked, so other
// operations that access it (such as [Database.Get] and [Database.Propose]) will
// block until this function returns.
func (p *Proposal) Commit() error {
	return p.lease.release(func() error {
		if p.dropped {
			return errDroppedProposal
		}

		p.commitLock.Lock()
		resp := C.fwd_commit_proposal(p.ptr)
		p.commitLock.Unlock()
		_, err := getHashKeyFromHashResult(resp)

		// Prevent double free
		p.ptr = nil
		p.dropped = true

		return err
	})
}

// CommitWithRebase commits the proposal, automatically rebasing if the
// proposal's parent is no longer the latest revision. Returns the root hash
// of the committed revision.
//
// Only this proposal is rebased. Child proposals created via [Proposal.Propose]
// are not automatically reparented after a rebase and should not be used.
//
// This is safe to call only once; subsequent calls will return an error.
//
// During this function, the latest state of the database is locked, so other
// operations that access it (such as [Database.Get] and [Database.Propose]) will
// block until this function returns.
func (p *Proposal) CommitWithRebase() (Hash, error) {
	var hash Hash
	err := p.lease.release(func() error {
		if p.dropped {
			return errDroppedProposal
		}

		p.commitLock.Lock()
		resp := C.fwd_commit_proposal_with_rebase(p.ptr)
		p.commitLock.Unlock()

		var err error
		hash, err = getHashKeyFromHashResult(resp)

		// Prevent double free
		p.ptr = nil
		p.dropped = true

		return err
	})
	return hash, err
}

// Dump returns a DOT (Graphviz) format representation of the trie structure
// of this proposal for debugging purposes.
//
// Returns errDroppedProposal if this Proposal has already been committed or released.
func (p *Proposal) Dump() (string, error) {
	p.lease.mu.RLock()
	defer p.lease.mu.RUnlock()
	if p.dropped {
		return "", errDroppedProposal
	}

	bytes, err := getValueFromValueResult(C.fwd_proposal_dump(p.ptr))
	if err != nil {
		return "", err
	}

	return string(bytes), nil
}

// getProposalFromProposalResult converts a C.ProposalResult to a Proposal or error.
func getProposalFromProposalResult(result C.ProposalResult, registry *keepAliveRegistry, commitLock *sync.Mutex) (*Proposal, error) {
	switch result.tag {
	case C.ProposalResult_NullHandlePointer:
		return nil, errDBClosed
	case C.ProposalResult_Ok:
		body := (*C.ProposalResult_Ok_Body)(unsafe.Pointer(&result.anon0))
		hashKey := *(*Hash)(unsafe.Pointer(&body.root_hash._0))
		proposal := &Proposal{
			handle:     newHandle(body.handle, func(p *C.ProposalHandle) C.VoidResult { return C.fwd_free_proposal(p) }),
			root:       hashKey,
			commitLock: commitLock,
		}
		// attach calls proposal.Drop on the closed-registry path; nothing else to clean up.
		if err := proposal.lease.attach(registry, proposal.Drop); err != nil {
			return nil, err
		}
		runtime.AddCleanup(proposal, drop[*C.ProposalHandle], proposal.handle)
		return proposal, nil
	case C.ProposalResult_Err:
		err := newOwnedBytes(*(*C.OwnedBytes)(unsafe.Pointer(&result.anon0))).intoError()
		return nil, err
	default:
		return nil, fmt.Errorf("unknown C.ProposalResult tag: %d", result.tag)
	}
}
