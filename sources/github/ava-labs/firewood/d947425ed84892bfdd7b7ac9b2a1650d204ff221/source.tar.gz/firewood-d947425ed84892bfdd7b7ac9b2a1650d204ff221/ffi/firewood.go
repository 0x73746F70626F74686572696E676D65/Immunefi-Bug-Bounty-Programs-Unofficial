// Copyright (C) 2025, Ava Labs, Inc. All rights reserved.
// See the file LICENSE.md for licensing terms.

// Package ffi provides a Go wrapper around the [Firewood] database.
//
// [Firewood]: https://github.com/ava-labs/firewood
package ffi

//go:generate go run ./gen/update-cgo-ldflags
//go:generate go run ./gen/update-cgo-pragmas

// // Note that -lm is required on Linux but not on Mac.
// // FIREWOOD_CGO_BEGIN_STATIC_LIBS
// // #cgo linux,amd64 LDFLAGS: -L${SRCDIR}/libs/x86_64-unknown-linux-gnu
// // #cgo linux,arm64 LDFLAGS: -L${SRCDIR}/libs/aarch64-unknown-linux-gnu
// // #cgo darwin,amd64 LDFLAGS: -L${SRCDIR}/libs/x86_64-apple-darwin
// // #cgo darwin,arm64 LDFLAGS: -L${SRCDIR}/libs/aarch64-apple-darwin
// // FIREWOOD_CGO_END_STATIC_LIBS
// // FIREWOOD_CGO_BEGIN_LOCAL_LIBS
// #cgo LDFLAGS: -L${SRCDIR}/../target/debug
// #cgo LDFLAGS: -L${SRCDIR}/../target/release
// #cgo LDFLAGS: -L${SRCDIR}/../target/maxperf
// // FIREWOOD_CGO_END_LOCAL_LIBS
// #cgo LDFLAGS: -lfirewood_ffi -lm -ldl
// #include <stdlib.h>
// #include "firewood.h"
// #cgo noescape fwd_open_db
// #cgo nocallback fwd_open_db
// #cgo noescape fwd_batch
// #cgo nocallback fwd_batch
// #cgo noescape fwd_propose_on_db
// #cgo nocallback fwd_propose_on_db
// #cgo noescape fwd_get_latest
// #cgo nocallback fwd_get_latest
// #cgo noescape fwd_root_hash
// #cgo nocallback fwd_root_hash
// #cgo noescape fwd_get_revision
// #cgo nocallback fwd_get_revision
// #cgo noescape fwd_close_db
// #cgo nocallback fwd_close_db
// #cgo noescape fwd_db_dump
// #cgo nocallback fwd_db_dump
// #cgo noescape fwd_block_replay_flush
// #cgo nocallback fwd_block_replay_flush
import "C"

import (
	"context"
	"errors"
	"fmt"
	"runtime"
	"sync"
)

// RootLength is the hash length for all Firewood hashes.
const RootLength = C.sizeof_HashKey

// Hash is the type used for all firewood hashes.
type Hash [RootLength]byte

// NodeHashAlgorithm represents the node hashing algorithm used by the database.
// It is a per-database runtime choice: a single binary can open databases of
// either algorithm. When opening an existing database, the algorithm must match
// the one the database was created with.
//
// Currently, there are only two variants but more may be added in the future.
type NodeHashAlgorithm C.enum_NodeHashAlgorithm

const (
	// MerkleDBNodeHashing uses MerkleDB-compatible SHA-256 based hashing
	MerkleDBNodeHashing NodeHashAlgorithm = C.NodeHashAlgorithm_MerkleDB
	// EthereumNodeHashing uses Ethereum-compatible Keccak-256 based hashing
	EthereumNodeHashing NodeHashAlgorithm = C.NodeHashAlgorithm_Ethereum
)

var (
	// EmptyRoot is the zero value for [Hash]
	EmptyRoot Hash
	// ErrActiveKeepAliveHandles is returned by [Database.Close] when the
	// supplied context is cancelled before every outstanding handle that
	// holds a keep-alive lease on the database has been released. That
	// set includes [Proposal], [Revision], [Reconstructed], [Iterator] and
	// [RangeProof] and instances. Pass [WithForceCloseHandles] to drop
	// them automatically.
	ErrActiveKeepAliveHandles = errors.New("cannot close database with active keep-alive handles")

	errDBClosed = errors.New("firewood database already closed")
)

// Database is an FFI wrapper for the Rust Firewood database.
// All functions rely on CGO to call into the underlying Rust implementation.
// Instances are created via [New] and must be closed with [Database.Close]
// when no longer needed.
//
// A Database can have outstanding [Revision] and [Proposal], which
// access the database's memory. These must be released before closing the
// database. See [Database.Close] for more details.
//
// Database supports two hashing modes: Firewood hashing and Ethereum-compatible
// hashing. Ethereum-compatible hashing is distributed, but you can use the more efficient
// Firewood hashing by compiling from source. See the Firewood repository for more details.
//
// For concurrent use cases, see each type and method's documentation for thread-safety.
type Database struct {
	// handle is returned and accepted by cgo functions. It MUST be treated as
	// an opaque value without special meaning.
	// https://en.wikipedia.org/wiki/Blinkenlights
	handle     *C.DatabaseHandle
	handleLock sync.RWMutex

	// keepAlives tracks every outstanding [Proposal], [Revision],
	// [Reconstructed], [Iterator], [RangeProof], and [ChangeProof] created
	// from this database. It carries both the outstanding-handle count that
	// [Database.Close] waits on and the registry of drop callbacks that
	// [WithForceCloseHandles] uses to release them forcibly.
	keepAlives *keepAliveRegistry

	// commitLock is used to ensure that methods accessing or modifying the latest
	// revision do not conflict.
	commitLock sync.Mutex
}

// config defines the internal configuration parameters used when opening a [Database].
type config struct {
	// truncate indicates whether to clear the database file if it already exists.
	truncate bool
	// nodeCacheSizeInBytes is the memory limit for the node cache in bytes.
	// Must be non-zero.
	nodeCacheSizeInBytes uint
	// freeListMemoryLimitKB is the memory limit for the freelist cache in kibibytes.
	// Must be non-zero.
	freeListMemoryLimitKB uint
	// revisions is the maximum number of historical revisions to keep in memory.
	// If rootStoreDir is set, then any revisions removed from memory will still be kept on disk.
	// Otherwise, any revisions removed from memory will no longer be kept on disk.
	// Must be >= 2 and > maxPersistenceGap.
	revisions uint
	// readCacheStrategy is the caching strategy used for the node cache.
	readCacheStrategy CacheStrategy
	// rootStore defines whether to enable storing all historical revisions on disk.
	rootStore bool
	// expensiveMetricsEnabled controls whether expensive metrics recording is enabled.
	expensiveMetricsEnabled bool
	// metricsTag separates metrics and logs by database handle.
	metricsTag string
	// maxPersistenceGap is configured by WithMaxPersistenceGap.
	maxPersistenceGap uint64
}

func defaultConfig() *config {
	return &config{
		nodeCacheSizeInBytes:  128_000_000,
		freeListMemoryLimitKB: 4096,
		revisions:             100,
		readCacheStrategy:     OnlyCacheWrites,
		maxPersistenceGap:     1,
	}
}

// Option is a function that configures a [Database].
type Option func(*config)

// WithTruncate sets whether to clear the database file if it already exists.
// Default: false
func WithTruncate(truncate bool) Option {
	return func(c *config) {
		c.truncate = truncate
	}
}

// WithNodeCacheSizeInBytes sets the node cache memory limit in bytes.
// Must be non-zero.
// Default: 128 MB
func WithNodeCacheSizeInBytes(sizeInBytes uint) Option {
	return func(c *config) {
		c.nodeCacheSizeInBytes = sizeInBytes
	}
}

// WithFreeListMemoryLimitKB sets the memory limit for the freelist cache in kibibytes.
// The freelist cache manages available disk space for reuse. Nothing is
// preallocated, so this is an upper bound on the memory the cache may use.
// Must be non-zero.
// Default: 4096 (4 MB)
func WithFreeListMemoryLimitKB(memoryLimitKB uint) Option {
	return func(c *config) {
		c.freeListMemoryLimitKB = memoryLimitKB
	}
}

// WithRevisions sets the maximum number of historical revisions to keep in memory.
// If RootStoreDir is set, then any revisions removed from memory will still be kept on disk.
// Otherwise, any revisions removed from memory will no longer be kept on disk.
// Must be >= 2 and > WithMaxPersistenceGap.
// Default: 100
func WithRevisions(revisions uint) Option {
	return func(c *config) {
		c.revisions = revisions
	}
}

// WithReadCacheStrategy sets the caching strategy used for the node cache.
// Default: OnlyCacheWrites
func WithReadCacheStrategy(strategy CacheStrategy) Option {
	return func(c *config) {
		c.readCacheStrategy = strategy
	}
}

// WithRootStore defines whether to enable storing all historical revisions on disk.
// When set, historical revisions will be persisted to disk even after being
// removed from memory (based on the Revisions limit).
// Default: false
func WithRootStore() Option {
	return func(c *config) {
		c.rootStore = true
	}
}

// WithExpensiveMetrics enables expensive metrics recording for this database.
// Expensive metrics are disabled by default since they can introduce overhead.
// Default: false
func WithExpensiveMetrics() Option {
	return func(c *config) {
		c.expensiveMetricsEnabled = true
	}
}

// WithMetricsTag sets a tag to attach to metrics and logs emitted for this database.
// Default: empty (no tag; metrics are recorded with the fallback db_tag="untagged" label)
func WithMetricsTag(tag string) Option {
	return func(c *config) {
		c.metricsTag = tag
	}
}

// WithMaxPersistenceGap sets the maximum number of committed revisions that can
// be ahead of the last persisted revision. A commit that would exceed this
// distance blocks until persistence advances the checkpoint.
//
// Consequently, a persisted revision is guaranteed to be found by looking back
// at most maxPersistenceGap revisions from any committed revision.
//
// Defaults to 1. Must be positive and less than the value set by [WithRevisions].
func WithMaxPersistenceGap(maxPersistenceGap uint64) Option {
	return func(c *config) {
		c.maxPersistenceGap = maxPersistenceGap
	}
}

// A CacheStrategy represents the caching strategy used by a [Database].
type CacheStrategy uint8

const (
	// OnlyCacheWrites caches only writes.
	OnlyCacheWrites CacheStrategy = iota
	// CacheBranchReads caches intermediate reads and writes.
	CacheBranchReads
	// CacheAllReads caches all reads and writes.
	CacheAllReads

	// invalidCacheStrategy MUST be the final value in the iota block to make it
	// the smallest value greater than all valid values.
	invalidCacheStrategy
)

// New opens or creates a new Firewood database with the given node hashing
// algorithm and database options. The database directory will be created at the
// provided path if it does not already exist.
//
// The [nodeHashAlgorithm] is required and selects the database's hashing mode at
// runtime, on a per-database basis:
//   - EthereumNodeHashing for Ethereum-compatible (Keccak-256) hashing
//   - MerkleDBNodeHashing for MerkleDB-compatible (SHA-256) hashing
//
// A single binary supports both modes. When opening an existing database, the
// algorithm must match the one the database was created with.
//
// If no [Option] is provided, sensible defaults will be used.
// See the With* functions for details about each configuration parameter and its default value.
//
// It is the caller's responsibility to call [Database.Close] when the database
// is no longer needed. No other [Database] in this process should be opened with
// the same file path until the database is closed.
func New(dbDir string, nodeHashAlgorithm NodeHashAlgorithm, opts ...Option) (*Database, error) {
	conf := defaultConfig()
	for _, opt := range opts {
		opt(conf)
	}

	if conf.readCacheStrategy >= invalidCacheStrategy {
		return nil, fmt.Errorf("invalid cache strategy (%d)", conf.readCacheStrategy)
	}
	if conf.revisions < 2 {
		return nil, fmt.Errorf("revisions must be >= 2, got %d", conf.revisions)
	}
	if conf.nodeCacheSizeInBytes < 1 {
		return nil, fmt.Errorf("node cache size in bytes must be >= 1, got %d", conf.nodeCacheSizeInBytes)
	}
	if conf.freeListMemoryLimitKB < 1 {
		return nil, fmt.Errorf("free list memory limit in KB must be >= 1, got %d", conf.freeListMemoryLimitKB)
	}
	var pinner runtime.Pinner
	defer pinner.Unpin()

	args := C.struct_DatabaseHandleArgs{
		dir:                      newBorrowedBytes([]byte(dbDir), &pinner),
		node_cache_memory_limit:  C.size_t(conf.nodeCacheSizeInBytes),
		freelist_memory_limit_kb: C.size_t(conf.freeListMemoryLimitKB),
		revisions:                C.size_t(conf.revisions),
		strategy:                 C.uint8_t(conf.readCacheStrategy),
		truncate:                 C.bool(conf.truncate),
		root_store:               C.bool(conf.rootStore),
		expensive_metrics:        C.bool(conf.expensiveMetricsEnabled),
		node_hash_algorithm:      C.enum_NodeHashAlgorithm(nodeHashAlgorithm),
		db_tag:                   newBorrowedBytes([]byte(conf.metricsTag), &pinner),
		max_persistence_gap:      C.uint64_t(conf.maxPersistenceGap),
	}

	return getDatabaseFromHandleResult(C.fwd_open_db(args))
}

// Update applies a batch of operations to the database, returning the hash of the
// root node after the batch is applied. This is equivalent to creating a proposal
// with [Database.Propose], then committing it with [Proposal.Commit].
//
// Use [Put], [Delete], and [PrefixDelete] to create batch operations. A [Put]
// with an empty value stores an empty value; use [Delete] or [PrefixDelete] to
// remove keys.
//
// This function conflicts with all other calls that access the latest state of the database,
// and will lock for the duration of this function.
func (db *Database) Update(batch []BatchOp) (Hash, error) {
	db.handleLock.RLock()
	defer db.handleLock.RUnlock()
	if db.handle == nil {
		return EmptyRoot, errDBClosed
	}

	db.commitLock.Lock()
	defer db.commitLock.Unlock()

	var pinner runtime.Pinner
	defer pinner.Unpin()

	kvp := newKeyValuePairsFromBatch(batch, &pinner)

	return getHashKeyFromHashResult(C.fwd_batch(db.handle, kvp))
}

// Propose creates a new proposal with the given batch operations. The proposal
// is not committed until [Proposal.Commit] is called. See [Database.Close] regarding
// freeing proposals. All proposals should be freed before closing the database.
//
// Use [Put], [Delete], and [PrefixDelete] to create batch operations. A [Put]
// with an empty value stores an empty value; use [Delete] or [PrefixDelete] to
// remove keys.
//
// This function conflicts with all other calls that access the latest state of the database,
// and will lock for the duration of this function.
func (db *Database) Propose(batch []BatchOp) (*Proposal, error) {
	db.handleLock.RLock()
	defer db.handleLock.RUnlock()
	if db.handle == nil {
		return nil, errDBClosed
	}

	db.commitLock.Lock()
	defer db.commitLock.Unlock()

	var pinner runtime.Pinner
	defer pinner.Unpin()

	kvp := newKeyValuePairsFromBatch(batch, &pinner)
	return getProposalFromProposalResult(C.fwd_propose_on_db(db.handle, kvp), db.keepAlives, &db.commitLock)
}

// Get retrieves the value for the given key from the most recent revision.
// If the key is not found, the return value will be nil.
//
// This function conflicts with all other calls that access the latest state of the database,
// and will lock for the duration of this function. If you need to perform concurrent reads,
// consider using [Database.Revision] or [Database.LatestRevision] to get a [Revision] and
// calling [Revision.Get] on it.
func (db *Database) Get(key []byte) ([]byte, error) {
	db.handleLock.RLock()
	defer db.handleLock.RUnlock()
	if db.handle == nil {
		return nil, errDBClosed
	}

	db.commitLock.Lock()
	defer db.commitLock.Unlock()

	var pinner runtime.Pinner
	defer pinner.Unpin()

	val, err := getValueFromValueResult(C.fwd_get_latest(db.handle, newBorrowedBytes(key, &pinner)))
	// The revision won't be found if the database is empty.
	// This is valid, but should be treated as a non-existent key
	if errors.Is(err, ErrRevisionNotFound) {
		return nil, nil
	}

	return val, err
}

// Root returns the current root hash of the trie.
// With Firewood hashing, the empty trie must return [EmptyRoot].
// If the database is already closed, it returns [EmptyRoot].
//
// This function conflicts with all other calls that access the latest state of the database,
// and will lock for the duration of this function.
func (db *Database) Root() Hash {
	db.handleLock.RLock()
	defer db.handleLock.RUnlock()
	if db.handle == nil {
		return EmptyRoot
	}

	db.commitLock.Lock()
	defer db.commitLock.Unlock()
	return db.root()
}

// root assumes db.stateLock is held and the database is open.
func (db *Database) root() Hash {
	// Since we already guaranteed the database is open, we can ignore the error since the only error is that the handle is nil.
	hash, _ := getHashKeyFromHashResult(C.fwd_root_hash(db.handle))
	return hash
}

// LatestRevision returns a [Revision] representing the latest state of the database.
// If the latest revision has root [EmptyRoot], it returns an error. The
// [Revision] must be released with [Revision.Drop] before closing the database.
//
// This function conflicts with all other calls that access the latest state of the database,
// and will lock for the duration of this function.
func (db *Database) LatestRevision() (*Revision, error) {
	db.handleLock.RLock()
	defer db.handleLock.RUnlock()
	if db.handle == nil {
		return nil, errDBClosed
	}

	db.commitLock.Lock()
	defer db.commitLock.Unlock()
	root := db.root()
	if root == EmptyRoot {
		return nil, ErrRevisionNotFound
	}
	return db.Revision(root)
}

// Revision returns a revision of the database.
// If the provided root does not exist (or is the [EmptyRoot]), it returns an
// error. The [Revision] must be released with [Revision.Drop] before closing
// the database.
//
// This function is thread-safe with all other operations.
func (db *Database) Revision(root Hash) (*Revision, error) {
	db.handleLock.RLock()
	defer db.handleLock.RUnlock()
	if db.handle == nil {
		return nil, errDBClosed
	}

	rev, err := getRevisionFromResult(C.fwd_get_revision(
		db.handle,
		newCHashKey(root),
	), db.keepAlives)
	if err != nil {
		return nil, err
	}

	return rev, nil
}

// CloseOption configures the behavior of [Database.Close].
type CloseOption func(*closeConfig)

type closeConfig struct {
	forceCloseHandles bool
}

// WithForceCloseHandles makes [Database.Close] forcibly drop every outstanding
// [Proposal], [Revision], [Reconstructed], [Iterator], [RangeProof], and
// [ChangeProof] before closing the database, instead of waiting for the
// caller to release them.
//
// Each handle is dropped once even if its underlying free errors, so a
// failing free cannot stall the close. Dropping a handle can still wait
// for an in-flight operation on it to finish, so a slow reader can delay
// the close past the deadline. Drop errors are joined and returned, and
// the database close is still attempted on a best-effort basis.
//
// While force-close is in progress, attempts to construct derived handles
// (for example via [Proposal.Propose] or [Revision.Iter]) fail with an
// error indicating the database is closed: a child constructor that would
// otherwise race the close is rejected rather than leaking past it.
//
// Methods on a force-dropped handle behave the same as if the caller had
// explicitly invoked Drop.
func WithForceCloseHandles() CloseOption {
	return func(c *closeConfig) {
		c.forceCloseHandles = true
	}
}

// Close releases the memory associated with the Database and stops the
// background persistence thread.
//
// By default Close blocks until all outstanding keep-alive handles are
// disowned or the [context.Context] is cancelled. That is, until every
// [Proposal], [Revision], [Reconstructed], [Iterator], [RangeProof], and
// [ChangeProof] created from this Database is either unreachable or has
// been explicitly released via [Proposal.Commit] or its Drop method.
// Committing a proof does not release it. Unreachable objects are released
// by their GC cleanups before Close returns. If the context expires first,
// [ErrActiveKeepAliveHandles] is returned and [C.fwd_close_db] is not
// called.
//
// Pass [WithForceCloseHandles] to forcibly drop every outstanding handle
// instead of waiting for the caller to release them. See
// [WithForceCloseHandles] for details on its semantics, including how ctx
// cancellation is reported.
//
// Safe to call multiple times; subsequent calls after the first are no-ops
// and return nil.
func (db *Database) Close(ctx context.Context, opts ...CloseOption) error {
	cfg := closeConfig{}
	for _, opt := range opts {
		opt(&cfg)
	}

	db.handleLock.Lock()
	defer db.handleLock.Unlock()
	if db.handle == nil {
		return nil
	}

	var forcedDropErr error
	if cfg.forceCloseHandles {
		forcedDropErr = db.keepAlives.closeAndForceDrop(ctx)
	}

	// waitForKeepAlives decides whether handles remain: nil once the count
	// drains (even if ctx is already cancelled), ErrActiveKeepAliveHandles
	// otherwise.
	if err := db.waitForKeepAlives(ctx); err != nil {
		// Graceful path: bookkeeping says handles are still live. Don't
		// touch fwd_close_db — we'd be freeing the Db out from under
		// objects whose Rust-side counterparts borrow it.
		return errors.Join(forcedDropErr, err)
	}

	db.commitLock.Lock()
	defer db.commitLock.Unlock()
	// Clear db.handle before fwd_close_db so any retry of Close is a no-op
	// rather than re-entering with a possibly-freed pointer, regardless of
	// whether the close succeeds or errors.
	handle := db.handle
	db.handle = nil
	if err := getErrorFromVoidResult(C.fwd_close_db(handle)); err != nil {
		return errors.Join(forcedDropErr, fmt.Errorf("unexpected error when closing database: %w", err))
	}

	return forcedDropErr
}

// waitForKeepAlives blocks until the outstanding-handle count reaches
// zero or ctx fires. Returns nil on drain, a wrapped
// [ErrActiveKeepAliveHandles] on cancellation. Caller should hold
// db.handleLock.Lock to prevent creating more handles.
func (db *Database) waitForKeepAlives(ctx context.Context) error {
	if err := db.keepAlives.waitDrained(ctx); err != nil {
		return fmt.Errorf("%w: %w", ErrActiveKeepAliveHandles, err)
	}
	return nil
}

// Dump returns a DOT (Graphviz) format representation of the trie structure
// of the latest revision for debugging purposes.
//
// Returns an error if the database is closed or if there was an error
// dumping the trie.
func (db *Database) Dump() (string, error) {
	db.handleLock.RLock()
	defer db.handleLock.RUnlock()
	if db.handle == nil {
		return "", errDBClosed
	}

	bytes, err := getValueFromValueResult(C.fwd_db_dump(db.handle))
	if err != nil {
		return "", err
	}

	return string(bytes), nil
}

// FlushBlockReplay flushes buffered block replay operations to disk.
//
// This function is only meaningful when the FFI library was compiled with
// the `block-replay` feature and the `FIREWOOD_BLOCK_REPLAY_PATH` environment
// variable is set. Otherwise, it is a no-op.
//
// Note: the recording and flushing is not handled per db, and this will flush
// all logs, if multiple databases are open.
func FlushBlockReplay() error {
	return getErrorFromVoidResult(C.fwd_block_replay_flush())
}
