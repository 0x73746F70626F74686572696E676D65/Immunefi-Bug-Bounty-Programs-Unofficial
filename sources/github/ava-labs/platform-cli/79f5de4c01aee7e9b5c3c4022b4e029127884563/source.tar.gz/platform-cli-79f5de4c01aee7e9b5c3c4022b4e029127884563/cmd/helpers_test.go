package cmd

import (
	"math"
	"strings"
	"testing"
	"time"

	"github.com/ava-labs/platform-cli/pkg/network"
)

func TestAvaxToNAVAX(t *testing.T) {
	tests := []struct {
		name    string
		input   float64
		want    uint64
		wantErr bool
	}{
		{
			name:  "whole avax",
			input: 1,
			want:  1_000_000_000,
		},
		{
			name:  "fractional avax",
			input: 1.5,
			want:  1_500_000_000,
		},
		{
			name:  "smallest unit",
			input: 0.000000001,
			want:  1,
		},
		{
			name:    "negative amount",
			input:   -1,
			wantErr: true,
		},
		{
			name:    "overflow",
			input:   float64(math.MaxUint64)/1e9 + 1,
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := avaxToNAVAX(tt.input)
			if tt.wantErr {
				if err == nil {
					t.Fatalf("avaxToNAVAX(%f) expected error", tt.input)
				}
				return
			}
			if err != nil {
				t.Fatalf("avaxToNAVAX(%f) returned error: %v", tt.input, err)
			}
			if got != tt.want {
				t.Fatalf("avaxToNAVAX(%f) = %d, want %d", tt.input, got, tt.want)
			}
		})
	}
}

func TestFeeToShares(t *testing.T) {
	tests := []struct {
		name    string
		input   float64
		want    uint32
		wantErr bool
	}{
		{
			name:  "zero",
			input: 0,
			want:  0,
		},
		{
			name:  "two percent",
			input: 0.02,
			want:  20_000,
		},
		{
			name:  "hundred percent",
			input: 1,
			want:  1_000_000,
		},
		{
			name:    "negative",
			input:   -0.01,
			wantErr: true,
		},
		{
			name:    "above one",
			input:   1.01,
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := feeToShares(tt.input)
			if tt.wantErr {
				if err == nil {
					t.Fatalf("feeToShares(%f) expected error", tt.input)
				}
				return
			}
			if err != nil {
				t.Fatalf("feeToShares(%f) returned error: %v", tt.input, err)
			}
			if got != tt.want {
				t.Fatalf("feeToShares(%f) = %d, want %d", tt.input, got, tt.want)
			}
		})
	}
}

func TestGetTransferAmountNAVAX(t *testing.T) {
	origAmount := transferAmount
	origAmountNAVAX := transferAmountNAVAX
	defer func() {
		transferAmount = origAmount
		transferAmountNAVAX = origAmountNAVAX
	}()

	transferAmount = 1
	transferAmountNAVAX = 123
	_, err := getTransferAmountNAVAX()
	if err == nil {
		t.Fatal("getTransferAmountNAVAX() expected error when both --amount and --amount-navax are set")
	}

	transferAmount = 0
	transferAmountNAVAX = 123
	got, err := getTransferAmountNAVAX()
	if err != nil {
		t.Fatalf("getTransferAmountNAVAX() returned error: %v", err)
	}
	if got != 123 {
		t.Fatalf("getTransferAmountNAVAX() = %d, want 123", got)
	}

	transferAmount = 1.5
	transferAmountNAVAX = 0
	got, err = getTransferAmountNAVAX()
	if err != nil {
		t.Fatalf("getTransferAmountNAVAX() returned error: %v", err)
	}
	if got != 1_500_000_000 {
		t.Fatalf("getTransferAmountNAVAX() = %d, want 1500000000", got)
	}

	transferAmount = 0
	transferAmountNAVAX = 0
	_, err = getTransferAmountNAVAX()
	if err == nil {
		t.Fatal("getTransferAmountNAVAX() expected error for missing amount")
	}
}

func TestParseTimeRange(t *testing.T) {
	before := time.Now()
	start, end, err := parseTimeRange("now", "1h")
	after := time.Now()
	if err != nil {
		t.Fatalf("parseTimeRange(now, 1h) returned error: %v", err)
	}

	// now mode should default to ~30s in the future.
	if start.Before(before.Add(25*time.Second)) || start.After(after.Add(35*time.Second)) {
		t.Fatalf("parseTimeRange(now, 1h) start=%v outside expected now+30s window", start)
	}
	if end.Sub(start) != time.Hour {
		t.Fatalf("parseTimeRange(now, 1h) duration=%v, want 1h", end.Sub(start))
	}

	fixedStart := "2026-01-01T00:00:00Z"
	start, end, err = parseTimeRange(fixedStart, "2h")
	if err != nil {
		t.Fatalf("parseTimeRange(fixed, 2h) returned error: %v", err)
	}
	if start.Format(time.RFC3339) != fixedStart {
		t.Fatalf("parseTimeRange(fixed, 2h) start=%s, want %s", start.Format(time.RFC3339), fixedStart)
	}
	if end.Sub(start) != 2*time.Hour {
		t.Fatalf("parseTimeRange(fixed, 2h) duration=%v, want 2h", end.Sub(start))
	}

	_, _, err = parseTimeRange("bad-time", "1h")
	if err == nil {
		t.Fatal("parseTimeRange() expected error for invalid start time")
	}

	_, _, err = parseTimeRange("now", "bad-duration")
	if err == nil {
		t.Fatal("parseTimeRange() expected error for invalid duration")
	}
}

func TestFractionToShares(t *testing.T) {
	got, err := fractionToShares("auto-compound", 0.3)
	if err != nil {
		t.Fatalf("fractionToShares() returned error: %v", err)
	}
	if got != 300_000 {
		t.Fatalf("fractionToShares() = %d, want 300000", got)
	}

	_, err = fractionToShares("auto-compound", 1.01)
	if err == nil {
		t.Fatal("fractionToShares() expected error for value above one")
	}
	if !strings.Contains(err.Error(), "auto-compound") {
		t.Fatalf("fractionToShares() error = %v, want field name", err)
	}
}

func TestParseAutoRenewPeriod(t *testing.T) {
	got, err := parseAutoRenewPeriod("336h")
	if err != nil {
		t.Fatalf("parseAutoRenewPeriod() returned error: %v", err)
	}
	if got != 14*24*time.Hour {
		t.Fatalf("parseAutoRenewPeriod() = %s, want 336h", got)
	}

	for _, bad := range []string{"0s", "1.5s", "bad-period"} {
		if _, err := parseAutoRenewPeriod(bad); err == nil {
			t.Fatalf("parseAutoRenewPeriod(%q) expected error", bad)
		}
	}
}

func TestParseAutoRenewConfigPeriod(t *testing.T) {
	tests := []struct {
		name    string
		input   string
		want    time.Duration
		wantErr bool
	}{
		{name: "zero duration", input: "0", want: 0},
		{name: "zero seconds", input: "0s", want: 0},
		{name: "non-zero duration", input: "336h", want: 14 * 24 * time.Hour},
		{name: "negative duration", input: "-1s", wantErr: true},
		{name: "sub-second duration", input: "1.5s", wantErr: true},
		{name: "invalid duration", input: "bad-period", wantErr: true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := parseAutoRenewConfigPeriod(tt.input)
			if tt.wantErr {
				if err == nil {
					t.Fatalf("parseAutoRenewConfigPeriod(%q) expected error", tt.input)
				}
				return
			}
			if err != nil {
				t.Fatalf("parseAutoRenewConfigPeriod(%q) returned error: %v", tt.input, err)
			}
			if got != tt.want {
				t.Fatalf("parseAutoRenewConfigPeriod(%q) = %s, want %s", tt.input, got, tt.want)
			}
		})
	}
}

func TestNormalizeValidatorNodeURI(t *testing.T) {
	tests := []struct {
		name  string
		input string
		want  string
	}{
		{"ip only", "127.0.0.1", "http://127.0.0.1:9650"},
		{"ip with port", "127.0.0.1:9650", "http://127.0.0.1:9650"},
		{"hostname shorthand defaults https", "mynode.example.com:9650", "https://mynode.example.com:9650"},
		{"http uri", "http://127.0.0.1:9650", "http://127.0.0.1:9650"},
		{"https uri", "https://example.com", "https://example.com"},
		{"ext info path is stripped", "http://127.0.0.1:9650/ext/info", "http://127.0.0.1:9650"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := normalizeValidatorNodeURI(tt.input)
			if err != nil {
				t.Fatalf("normalizeValidatorNodeURI(%q) returned error: %v", tt.input, err)
			}
			if got != tt.want {
				t.Fatalf("normalizeValidatorNodeURI(%q) = %q, want %q", tt.input, got, tt.want)
			}
		})
	}
}

func TestNormalizeValidatorNodeURI_InvalidPath(t *testing.T) {
	_, err := normalizeValidatorNodeURI("http://127.0.0.1:9650/custom/path")
	if err == nil {
		t.Fatal("normalizeValidatorNodeURI() expected error for custom path")
	}
}

func TestIsEwoqKey(t *testing.T) {
	key := make([]byte, len(ewoqPrivateKey))
	copy(key, ewoqPrivateKey)
	if !isEwoqKey(key) {
		t.Fatal("isEwoqKey() expected true for ewoq key bytes")
	}

	key[0] ^= 0xFF
	if isEwoqKey(key) {
		t.Fatal("isEwoqKey() expected false for modified key bytes")
	}

	if isEwoqKey([]byte{1, 2, 3}) {
		t.Fatal("isEwoqKey() expected false for wrong length")
	}
}

func TestApplyHeliconMinOverride(t *testing.T) {
	// Config as resolved for a custom network: the CLI cannot read the node's real
	// minimum, so it falls back to 1h.
	base := network.Config{Name: "custom-custom", HeliconMinStakeDuration: time.Hour}

	tests := []struct {
		name    string
		flag    string
		want    time.Duration
		wantErr bool
	}{
		{
			name: "unset leaves the built-in value untouched",
			flag: "",
			want: time.Hour,
		},
		{
			name: "shorter duration, the devnet case",
			flag: "5m",
			want: 5 * time.Minute,
		},
		{
			name: "longer duration is allowed too",
			flag: "72h",
			want: 72 * time.Hour,
		},
		{
			name:    "zero",
			flag:    "0s",
			wantErr: true,
		},
		{
			name:    "negative",
			flag:    "-5m",
			wantErr: true,
		},
		{
			name:    "not a duration",
			flag:    "5 minutes",
			wantErr: true,
		},
		{
			name:    "bare number without unit",
			flag:    "300",
			wantErr: true,
		},
	}

	original := heliconMinPeriod
	t.Cleanup(func() { heliconMinPeriod = original })

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			heliconMinPeriod = tt.flag
			got, err := applyHeliconMinOverride(base)
			if tt.wantErr {
				if err == nil {
					t.Fatalf("applyHeliconMinOverride(%q) expected error", tt.flag)
				}
				return
			}
			if err != nil {
				t.Fatalf("applyHeliconMinOverride(%q) unexpected error: %v", tt.flag, err)
			}
			if got.HeliconMinStakeDuration != tt.want {
				t.Fatalf("applyHeliconMinOverride(%q) = %s, want %s",
					tt.flag, got.HeliconMinStakeDuration, tt.want)
			}
			// Only the Helicon minimum may change.
			if got.Name != base.Name {
				t.Fatalf("applyHeliconMinOverride(%q) modified Name: %q", tt.flag, got.Name)
			}
			// The caller's config must not be mutated: Config is passed by value.
			if base.HeliconMinStakeDuration != time.Hour {
				t.Fatalf("applyHeliconMinOverride(%q) mutated the input config", tt.flag)
			}
		})
	}
}
