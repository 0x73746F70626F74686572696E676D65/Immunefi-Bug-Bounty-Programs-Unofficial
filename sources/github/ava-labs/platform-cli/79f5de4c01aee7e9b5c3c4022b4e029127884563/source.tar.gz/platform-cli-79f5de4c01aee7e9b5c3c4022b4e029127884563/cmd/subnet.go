package cmd

import (
	"fmt"
	"strings"

	"github.com/ava-labs/avalanchego/ids"
	"github.com/ava-labs/avalanchego/vms/platformvm/txs"
	ethcommon "github.com/ava-labs/libevm/common"
	"github.com/ava-labs/platform-cli/pkg/network"
	"github.com/ava-labs/platform-cli/pkg/pchain"
	"github.com/spf13/cobra"
)

var (
	subnetID               string
	subnetNewOwner         string
	subnetChainID          string
	subnetManager          string
	subnetValidatorIPs     string
	subnetValidatorIDs     string
	subnetValidatorBLS     string
	subnetValidatorPoP     string
	subnetValBalance       float64
	subnetMockVal          bool
	subnetValidatorWeights string

	subnetValRemainingBalanceOwner string
	subnetValDeactivationOwner     string
	subnetAllowEmptyOwners         bool

	subnetValNodeID    string
	subnetValWeight    uint64
	subnetValStartTime string
	subnetValDuration  string
)

var subnetCmd = &cobra.Command{
	Use:   "subnet",
	Short: "Subnet management",
	Long:  `Create and manage subnets on the Avalanche P-Chain.`,
	RunE:  requireSubcommand,
}

var subnetCreateCmd = &cobra.Command{
	Use:   "create",
	Short: "Create a new subnet (CreateSubnetTx)",
	Long:  `Create a new subnet on the P-Chain.`,
	RunE: func(cmd *cobra.Command, args []string) error {
		ctx, cancel := getOperationContext()
		defer cancel()

		netConfig, err := getNetworkConfig(ctx)
		if err != nil {
			return fmt.Errorf("failed to get network config: %w", err)
		}

		w, cleanup, err := loadPChainWallet(ctx, netConfig)
		if err != nil {
			return fmt.Errorf("failed to create wallet: %w", err)
		}
		defer cleanup()

		fmt.Println("Creating new subnet...")
		fmt.Printf("Owner: %s\n", w.FormattedPChainAddress())
		fmt.Println("Submitting transaction...")

		txID, err := pchain.CreateSubnet(ctx, w)
		if err != nil {
			return err
		}

		fmt.Println("Subnet created successfully!")
		fmt.Printf("Subnet ID: %s\n", txID)
		return nil
	},
}

var subnetTransferOwnershipCmd = &cobra.Command{
	Use:   "transfer-ownership",
	Short: "Transfer subnet ownership (TransferSubnetOwnershipTx)",
	Long:  `Transfer ownership of a subnet to a new address.`,
	RunE: func(cmd *cobra.Command, args []string) error {
		ctx, cancel := getOperationContext()
		defer cancel()

		if subnetID == "" {
			return fmt.Errorf("--subnet-id is required")
		}
		if subnetNewOwner == "" {
			return fmt.Errorf("--new-owner is required")
		}

		sid, err := ids.FromString(subnetID)
		if err != nil {
			return fmt.Errorf("invalid subnet ID: %w", err)
		}

		newOwner, err := ids.ShortFromString(subnetNewOwner)
		if err != nil {
			return fmt.Errorf("invalid new owner address: %w", err)
		}

		netConfig, err := getNetworkConfig(ctx)
		if err != nil {
			return fmt.Errorf("failed to get network config: %w", err)
		}

		w, cleanup, err := loadPChainWalletWithSubnet(ctx, netConfig, sid)
		if err != nil {
			return fmt.Errorf("failed to create wallet: %w", err)
		}
		defer cleanup()

		txID, err := pchain.TransferSubnetOwnership(ctx, w, sid, newOwner)
		if err != nil {
			return err
		}

		fmt.Printf("Transfer Subnet Ownership TX: %s\n", txID)
		return nil
	},
}

var subnetConvertL1Cmd = &cobra.Command{
	Use:   "convert-to-l1",
	Short: "Convert subnet to L1 (ConvertSubnetToL1Tx)",
	Long: `Convert a permissioned subnet to an L1 blockchain.

Each initial validator has two P-Chain owners:
  - The remaining balance owner receives the validator's unspent balance when
    the validator is disabled or removed.
  - The deactivation owner can disable the validator (DisableL1ValidatorTx).

Both owners default to the address of the issuing key, with threshold 1. Use
--validator-remaining-balance-owner and --validator-deactivation-owner to set
other P-Chain addresses. Give one address for all validators, or one address
per validator in the same order as the validators.

The P-Chain cannot change the owners after the conversion. An empty owner has
threshold 0, so any funded P-Chain key can disable the validator and spend its
remaining balance. The command refuses to issue an empty owner unless you set
--allow-empty-owners.`,
	RunE: func(cmd *cobra.Command, args []string) error {
		ctx, cancel := getOperationContext()
		defer cancel()

		if subnetID == "" {
			return fmt.Errorf("--subnet-id is required")
		}
		if subnetChainID == "" {
			return fmt.Errorf("--chain-id is required")
		}
		validatorAddrs := parseValidatorAddrs(subnetValidatorIPs)
		hasValidatorIPs := len(validatorAddrs) > 0
		hasManualValidators := strings.TrimSpace(subnetValidatorIDs) != "" ||
			strings.TrimSpace(subnetValidatorBLS) != "" ||
			strings.TrimSpace(subnetValidatorPoP) != ""
		hasValidatorFlag := strings.TrimSpace(subnetValidatorIPs) != ""
		switch {
		case subnetMockVal && hasValidatorIPs:
			return fmt.Errorf("--mock-validator cannot be used with --validators")
		case subnetMockVal && hasManualValidators:
			return fmt.Errorf("--mock-validator cannot be used with manual validator flags")
		case hasValidatorFlag && !hasValidatorIPs:
			return fmt.Errorf("--validators must include at least one non-empty validator address")
		case hasValidatorIPs && hasManualValidators:
			return fmt.Errorf("use either --validators (auto-discovery) or manual validator flags, not both")
		case !subnetMockVal && !hasValidatorIPs && !hasManualValidators:
			return fmt.Errorf("at least one validator is required: provide --validators, manual validator flags, or use --mock-validator for testing")
		}

		sid, err := ids.FromString(subnetID)
		if err != nil {
			return fmt.Errorf("invalid subnet ID: %w", err)
		}

		cid, err := ids.FromString(subnetChainID)
		if err != nil {
			return fmt.Errorf("invalid chain ID: %w", err)
		}

		var managerAddr []byte
		if subnetManager != "" {
			managerAddr, err = decodeHexExactLength(subnetManager, ethcommon.AddressLength)
			if err != nil {
				return fmt.Errorf("invalid manager address: %w", err)
			}
		}

		// Parse optional per-validator weights
		var weights []uint64
		if strings.TrimSpace(subnetValidatorWeights) != "" {
			weights, err = parseValidatorWeights(subnetValidatorWeights)
			if err != nil {
				return fmt.Errorf("invalid --validator-weights: %w", err)
			}
		}

		// Gather validator info from IPs or generate mock
		var validators []*txs.ConvertSubnetToL1Validator
		if subnetMockVal {
			// For mock, use the first weight if provided, otherwise 0 (default)
			var mockWeight uint64
			if weights != nil {
				if len(weights) != 1 {
					return fmt.Errorf("--validator-weights must have exactly 1 value when using --mock-validator, got %d", len(weights))
				}
				mockWeight = weights[0]
			}
			mockVal, err := generateMockValidator(subnetValBalance, mockWeight)
			if err != nil {
				return fmt.Errorf("failed to generate mock validator: %w", err)
			}
			validators = []*txs.ConvertSubnetToL1Validator{mockVal}
			fmt.Printf("Using mock validator (NodeID: %x)\n", mockVal.NodeID)
		} else if hasManualValidators {
			validators, err = buildManualL1Validators(
				subnetValidatorIDs,
				subnetValidatorBLS,
				subnetValidatorPoP,
				subnetValBalance,
				weights,
			)
			if err != nil {
				return err
			}
		} else {
			validators, err = gatherL1Validators(ctx, validatorAddrs, subnetValBalance, weights)
			if err != nil {
				return err
			}
		}

		netConfig, err := getNetworkConfig(ctx)
		if err != nil {
			return fmt.Errorf("failed to get network config: %w", err)
		}

		hrp := network.GetHRP(netConfig.NetworkID)
		remainingBalanceOwners, err := parseValidatorOwners(subnetValRemainingBalanceOwner, hrp, len(validators))
		if err != nil {
			return fmt.Errorf("invalid --validator-remaining-balance-owner: %w", err)
		}
		deactivationOwners, err := parseValidatorOwners(subnetValDeactivationOwner, hrp, len(validators))
		if err != nil {
			return fmt.Errorf("invalid --validator-deactivation-owner: %w", err)
		}

		w, cleanup, err := loadPChainWalletWithSubnet(ctx, netConfig, sid)
		if err != nil {
			return fmt.Errorf("failed to create wallet: %w", err)
		}
		defer cleanup()

		err = finalizeL1Validators(
			validators,
			remainingBalanceOwners,
			deactivationOwners,
			w.PChainAddress(),
			subnetAllowEmptyOwners,
		)
		if err != nil {
			return err
		}

		fmt.Println("Converting subnet to L1...")
		fmt.Printf("  Subnet ID: %s\n", sid)
		fmt.Printf("  Chain ID: %s\n", cid)
		fmt.Printf("  Validators: %d\n", len(validators))
		for _, v := range validators {
			nodeID, err := ids.ToNodeID(v.NodeID)
			if err != nil {
				return fmt.Errorf("invalid validator node ID: %w", err)
			}
			fmt.Printf("  - %s\n", nodeID)
			fmt.Printf("      Remaining balance owner: %s\n", formatPChainOwner(v.RemainingBalanceOwner, netConfig.NetworkID))
			fmt.Printf("      Deactivation owner: %s\n", formatPChainOwner(v.DeactivationOwner, netConfig.NetworkID))
		}
		fmt.Println("Submitting transaction...")

		txID, err := pchain.ConvertSubnetToL1(ctx, w, sid, cid, managerAddr, validators)
		if err != nil {
			return err
		}

		fmt.Println("Subnet converted to L1 successfully!")
		fmt.Printf("TX ID: %s\n", txID)
		return nil
	},
}

var subnetAddValidatorCmd = &cobra.Command{
	Use:   "add-validator",
	Short: "Add a validator to a permissioned subnet (AddSubnetValidatorTx)",
	Long: `Add a validator to a permissioned subnet (AddSubnetValidatorTx).

The node must already be a primary network validator, and the validation period
must fall within its primary network validation window. The subnet owner key
authorizes the transaction, so load the owner key via --key-name or --ledger.`,
	RunE: func(cmd *cobra.Command, args []string) error {
		ctx, cancel := getOperationContext()
		defer cancel()

		if subnetID == "" {
			return fmt.Errorf("--subnet-id is required")
		}
		if subnetValNodeID == "" {
			return fmt.Errorf("--node-id is required")
		}
		if subnetValWeight == 0 {
			return fmt.Errorf("--weight is required and must be positive")
		}

		sid, err := ids.FromString(subnetID)
		if err != nil {
			return fmt.Errorf("invalid subnet ID: %w", err)
		}

		nodeID, err := ids.NodeIDFromString(subnetValNodeID)
		if err != nil {
			return fmt.Errorf("invalid node ID: %w", err)
		}

		start, end, err := parseTimeRange(subnetValStartTime, subnetValDuration)
		if err != nil {
			return err
		}

		netConfig, err := getNetworkConfig(ctx)
		if err != nil {
			return fmt.Errorf("failed to get network config: %w", err)
		}
		if end.Sub(start) < netConfig.MinStakeDuration {
			return fmt.Errorf("duration too short for %s: minimum is %s", netConfig.Name, netConfig.MinStakeDuration)
		}

		w, cleanup, err := loadPChainWalletWithSubnet(ctx, netConfig, sid)
		if err != nil {
			return fmt.Errorf("failed to create wallet: %w", err)
		}
		defer cleanup()

		fmt.Printf("Adding validator %s to subnet %s...\n", nodeID, sid)
		fmt.Printf("  Weight: %d\n", subnetValWeight)
		fmt.Printf("  Start: %s\n", start.UTC().Format("2006-01-02 15:04:05 MST"))
		fmt.Printf("  End: %s\n", end.UTC().Format("2006-01-02 15:04:05 MST"))
		fmt.Println("Submitting transaction...")

		txID, err := pchain.AddSubnetValidator(ctx, w, pchain.AddSubnetValidatorConfig{
			SubnetID: sid,
			NodeID:   nodeID,
			Start:    start,
			End:      end,
			Weight:   subnetValWeight,
		})
		if err != nil {
			return err
		}

		fmt.Printf("TX ID: %s\n", txID)
		return nil
	},
}

var subnetRemoveValidatorCmd = &cobra.Command{
	Use:   "remove-validator",
	Short: "Remove a validator from a subnet (RemoveSubnetValidatorTx)",
	Long: `Remove a validator from a subnet (RemoveSubnetValidatorTx).

The subnet owner key authorizes the transaction, so load the owner key via
--key-name or --ledger.

This removes legacy subnet validators (those added by 'subnet add-validator').
L1 validators registered under ACP-77 are not removed this way; use
'l1 disable-validator' or the validator manager contract instead.

This still works after a subnet has been converted to an L1. Converting does not
remove pre-existing subnet validators, and those leftover validators keep
contributing weight to the L1's Warp signing set. If they are offline, the
signable weight can fall below the quorum that initializeValidatorSet requires,
in which case removing them restores the quorum.`,
	RunE: func(cmd *cobra.Command, args []string) error {
		ctx, cancel := getOperationContext()
		defer cancel()

		if subnetID == "" {
			return fmt.Errorf("--subnet-id is required")
		}
		if subnetValNodeID == "" {
			return fmt.Errorf("--node-id is required")
		}

		sid, err := ids.FromString(subnetID)
		if err != nil {
			return fmt.Errorf("invalid subnet ID: %w", err)
		}

		nodeID, err := ids.NodeIDFromString(subnetValNodeID)
		if err != nil {
			return fmt.Errorf("invalid node ID: %w", err)
		}

		netConfig, err := getNetworkConfig(ctx)
		if err != nil {
			return fmt.Errorf("failed to get network config: %w", err)
		}

		w, cleanup, err := loadPChainWalletWithSubnet(ctx, netConfig, sid)
		if err != nil {
			return fmt.Errorf("failed to create wallet: %w", err)
		}
		defer cleanup()

		fmt.Printf("Removing validator %s from subnet %s...\n", nodeID, sid)
		fmt.Println("Submitting transaction...")

		txID, err := pchain.RemoveSubnetValidator(ctx, w, pchain.RemoveSubnetValidatorConfig{
			SubnetID: sid,
			NodeID:   nodeID,
		})
		if err != nil {
			return err
		}

		fmt.Printf("TX ID: %s\n", txID)
		return nil
	},
}

func init() {
	rootCmd.AddCommand(subnetCmd)

	subnetCmd.AddCommand(subnetCreateCmd)
	subnetCmd.AddCommand(subnetTransferOwnershipCmd)
	subnetCmd.AddCommand(subnetConvertL1Cmd)
	subnetCmd.AddCommand(subnetAddValidatorCmd)
	subnetCmd.AddCommand(subnetRemoveValidatorCmd)

	// Transfer ownership flags
	subnetTransferOwnershipCmd.Flags().StringVar(&subnetID, "subnet-id", "", "Subnet ID")
	subnetTransferOwnershipCmd.Flags().StringVar(&subnetNewOwner, "new-owner", "", "New owner P-Chain address")

	// Convert L1 flags
	subnetConvertL1Cmd.Flags().StringVar(&subnetID, "subnet-id", "", "Subnet ID to convert")
	subnetConvertL1Cmd.Flags().StringVar(&subnetChainID, "chain-id", "", "Chain ID where the validator manager contract lives (often the L1 chain ID)")
	subnetConvertL1Cmd.Flags().StringVar(&subnetManager, "manager", "", "Validator manager contract address (hex)")
	subnetConvertL1Cmd.Flags().StringVar(&subnetManager, "contract-address", "", "Alias for --manager")
	subnetConvertL1Cmd.Flags().StringVar(&subnetValidatorIPs, "validators", "", "Comma-separated validator node addresses (auto-fetches NodeID + BLS PoP from /ext/info)")
	subnetConvertL1Cmd.Flags().StringVar(&subnetValidatorIDs, "validator-node-ids", "", "Manual mode: comma-separated validator NodeIDs (must align with --validator-bls-public-keys and --validator-bls-pops)")
	subnetConvertL1Cmd.Flags().StringVar(&subnetValidatorBLS, "validator-bls-public-keys", "", "Manual mode: comma-separated validator BLS public keys (hex)")
	subnetConvertL1Cmd.Flags().StringVar(&subnetValidatorPoP, "validator-bls-pops", "", "Manual mode: comma-separated validator BLS proofs of possession (hex)")
	subnetConvertL1Cmd.Flags().Float64Var(&subnetValBalance, "validator-balance", 1.0, "Balance per validator in AVAX")
	subnetConvertL1Cmd.Flags().StringVar(&subnetValidatorWeights, "validator-weights", "", "Comma-separated validator weights (uint64). Must match validator count. Defaults to 100 per validator if omitted.")
	subnetConvertL1Cmd.Flags().BoolVar(&subnetMockVal, "mock-validator", false, "Use a mock validator (for testing)")
	subnetConvertL1Cmd.Flags().StringVar(&subnetValRemainingBalanceOwner, "validator-remaining-balance-owner", "", "Comma-separated P-Chain addresses that receive each validator's remaining balance. Give one address for all validators, or one address per validator. Defaults to your own address.")
	subnetConvertL1Cmd.Flags().StringVar(&subnetValDeactivationOwner, "validator-deactivation-owner", "", "Comma-separated P-Chain addresses that can disable each validator. Give one address for all validators, or one address per validator. Defaults to your own address.")
	subnetConvertL1Cmd.Flags().BoolVar(&subnetAllowEmptyOwners, "allow-empty-owners", false, "Do not default unset owners to your own address. An empty owner lets any P-Chain key disable the validator and spend its balance (unsafe).")

	// Add validator flags
	subnetAddValidatorCmd.Flags().StringVar(&subnetID, "subnet-id", "", "Subnet ID")
	subnetAddValidatorCmd.Flags().StringVar(&subnetValNodeID, "node-id", "", "Validator node ID (must already validate the primary network)")
	subnetAddValidatorCmd.Flags().Uint64Var(&subnetValWeight, "weight", 0, "Validator sampling weight on the subnet")
	subnetAddValidatorCmd.Flags().StringVar(&subnetValStartTime, "start", "now", "Start time (RFC3339 or 'now'). Post-Durango networks ignore this; validation begins at tx acceptance")
	subnetAddValidatorCmd.Flags().StringVar(&subnetValDuration, "duration", "336h", "Validation duration (must fall within the node's primary network validation period)")

	// Remove validator flags
	subnetRemoveValidatorCmd.Flags().StringVar(&subnetID, "subnet-id", "", "Subnet ID")
	subnetRemoveValidatorCmd.Flags().StringVar(&subnetValNodeID, "node-id", "", "Validator node ID to remove from the subnet")
}
