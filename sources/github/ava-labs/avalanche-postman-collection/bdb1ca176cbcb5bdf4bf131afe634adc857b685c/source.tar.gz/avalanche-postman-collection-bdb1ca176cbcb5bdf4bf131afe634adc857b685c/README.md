# Avalanche Postman Collection

Postman collection for [Avalanche](https://docs.avax.network).

## Installation

1. Download [Postman](https://postman.com)
2. Import Avalanche Postman Collection. Import -> Upload Files -> `Avalanche.postman_collection.json`
3. Import the Example Avalanche Postman Environment. Settings -> Import -> Choose Files -> `Example_Avalanche_Environment.postman_environment.json`
4. Call any Avalanche RPC endpoint

The official documentation on how to use the Avalanche Postman Collection can be found [here](https://docs.avax.network/tooling/avalanchego-postman-collection/setup).

## Contributing

We're hoping to continuously keep this collection up-to-date with the [Avalanche APIs](https://docs.avax.network/reference). If you're able to help improve the Avalanche Postman Collection in any way, first create a fork of this repository, next make the improvements, and lastly create a [pull request](https://github.com/ava-labs/avalanche-postman-collection/pulls) to merge your changes into the main repo `master` branch. 

## Version

v1.6.4
