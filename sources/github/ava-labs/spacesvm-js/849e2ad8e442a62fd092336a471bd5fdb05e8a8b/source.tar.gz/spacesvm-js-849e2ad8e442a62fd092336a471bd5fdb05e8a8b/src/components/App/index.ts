export { App } from './App'
