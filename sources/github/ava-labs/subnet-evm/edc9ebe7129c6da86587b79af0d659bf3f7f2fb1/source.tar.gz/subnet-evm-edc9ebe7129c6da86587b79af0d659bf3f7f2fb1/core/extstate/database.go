// Copyright (C) 2019-2025, Ava Labs, Inc. All rights reserved.
// See the file LICENSE for licensing terms.

package extstate

import (
	"github.com/ava-labs/libevm/core/state"
	"github.com/ava-labs/libevm/ethdb"
	"github.com/ava-labs/libevm/triedb"

	"github.com/ava-labs/subnet-evm/triedb/firewood"
)

func NewDatabaseWithConfig(db ethdb.Database, config *triedb.Config) state.Database {
	coredb := state.NewDatabaseWithConfig(db, config)
	return wrapIfFirewood(coredb)
}

func NewDatabaseWithNodeDB(db ethdb.Database, triedb *triedb.Database) state.Database {
	coredb := state.NewDatabaseWithNodeDB(db, triedb)
	return wrapIfFirewood(coredb)
}

func wrapIfFirewood(db state.Database) state.Database {
	fw, ok := db.TrieDB().Backend().(*firewood.Database)
	if !ok {
		return db
	}
	return &firewoodAccessorDB{
		Database: db,
		fw:       fw,
	}
}
