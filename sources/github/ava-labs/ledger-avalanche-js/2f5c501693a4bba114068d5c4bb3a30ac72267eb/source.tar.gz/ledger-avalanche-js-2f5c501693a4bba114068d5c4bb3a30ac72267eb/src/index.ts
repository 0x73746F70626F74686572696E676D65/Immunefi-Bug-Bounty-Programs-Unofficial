/** ******************************************************************************
 *  (c) 2019-2020 Zondax GmbH
 *  (c) 2016-2017 Ledger
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 ******************************************************************************* */
import {
  CHAIN_ID_SIZE,
  CHUNK_SIZE,
  CLA,
  CLA_ETH,
  COLLECTION_NAME_MAX_LEN,
  ADDRESS_LENGTH,
  ALGORITHM_ID_1,
  ALGORITHM_ID_SIZE,
  TYPE_SIZE,
  VERSION_SIZE,
  SIGNATURE_LENGTH_SIZE,
  errorCodeToString,
  FIRST_MESSAGE,
  getVersion,
  HASH_LEN,
  INS,
  INS_ETH,
  LAST_MESSAGE,
  LedgerError,
  NEXT_MESSAGE,
  P1_VALUES,
  PAYLOAD_TYPE,
  processErrorResponse,
  TYPE_1,
  VERSION_1,
  P2_VALUES,
  P2_EIP712_HASHED,
  P1_PERSONAL_MESSAGE_FIRST,
  P1_PERSONAL_MESSAGE_MORE,
  ED25519_PK_SIZE,
} from "./common";
import {
  pathCoinType,
  serializeChainID,
  serializeHrp,
  serializePath,
  serializePathSuffix,
} from "./helper";
import {
  ResponseAddress,
  ResponseAppInfo,
  ResponseSign,
  ResponseVersion,
  ResponseWalletId,
  ResponseXPub,
  LedgerTransport,
  EvmSignerOptions,
} from "./types";

import {
  SignerEthBuilder,
  type SignerEth,
  type TypedData,
} from "@ledgerhq/device-signer-kit-ethereum";

import {
  evmDerivationPath,
  hexToBytes,
  runDeviceAction,
  stripHexPrefix,
  toEvmTransactionSignature,
  toEvmTypedDataSignature,
} from "./evm";

export * from "./types";
export { LedgerError };
export { DeviceActionError } from "./evm";
export type { TypedData } from "@ledgerhq/device-signer-kit-ethereum";

function processGetAddrResponse(response: Buffer) {
  let partialResponse = response;

  const errorCodeData = partialResponse.slice(-2);
  if (errorCodeData.length < 2) {
    throw new Error("Invalid response: missing error code data");
  }
  const returnCode = errorCodeData[0]! * 256 + errorCodeData[1]!;

  //get public key len (variable)
  const PKLEN = partialResponse[0];
  if (PKLEN === undefined) {
    throw new Error("Invalid response: missing public key length");
  }
  const publicKey = Buffer.from(partialResponse.slice(1, 1 + PKLEN));

  //"advance" buffer
  partialResponse = partialResponse.slice(1 + PKLEN);

  let hash: Buffer | undefined;
  let address: string;

  if (PKLEN != ED25519_PK_SIZE) {
    hash = Buffer.from(partialResponse.slice(0, 20));

    //"advance" buffer
    partialResponse = partialResponse.slice(20);
    address = Buffer.from(partialResponse.subarray(0, -2)).toString();
  } else {
    // ED25519: Convert raw bytes to hex string
    address = partialResponse.subarray(0, -2).toString("hex");
  }

  return {
    publicKey,
    hash,
    address,
    returnCode,
    errorMessage: errorCodeToString(returnCode),
  };
}

function processGetXPubResponse(response: Buffer) {
  let partialResponse = response;

  const errorCodeData = partialResponse.slice(-2);
  if (errorCodeData.length < 2) {
    throw new Error("Invalid response: missing error code data");
  }
  const returnCode = errorCodeData[0]! * 256 + errorCodeData[1]!;

  //get public key len (variable)
  const PKLEN = partialResponse[0];
  if (PKLEN === undefined) {
    throw new Error("Invalid response: missing public key length");
  }
  const publicKey = Buffer.from(partialResponse.slice(1, 1 + PKLEN));

  //"advance" buffer
  partialResponse = partialResponse.slice(1 + PKLEN);

  const chain_code = Buffer.from(partialResponse.slice(0, -2));

  return {
    publicKey,
    chain_code,
    returnCode,
    errorMessage: errorCodeToString(returnCode),
  };
}

export default class AvalancheApp {
  transport;
  private readonly evm: EvmSignerOptions | undefined;
  private signer: SignerEth | undefined;

  /**
   * @param transport - anything that can send an APDU (`DMKTransport`, or a legacy hw-transport)
   * @param evm - the DMK session behind that transport; needed only for the C-Chain (EVM) methods
   */
  constructor(transport: LedgerTransport, evm?: EvmSignerOptions) {
    this.transport = transport;
    if (!transport) {
      throw new Error("Transport has not been defined");
    }
    this.evm = evm;
  }

  private static prepareChunks(message: Buffer, serializedPathBuffer?: Buffer) {
    const chunks = [];

    // First chunk (only path)
    if (serializedPathBuffer !== undefined) {
      // First chunk (only path)
      chunks.push(serializedPathBuffer);
    }

    const buffer = Buffer.from(message);
    for (let i = 0; i < buffer.length; i += CHUNK_SIZE) {
      let end = i + CHUNK_SIZE;
      if (i > buffer.length) {
        end = buffer.length;
      }
      chunks.push(buffer.slice(i, end));
    }

    return chunks;
  }

  private async signGetChunks(message: Buffer, path?: string) {
    if (path === undefined) {
      return await AvalancheApp.prepareChunks(message, Buffer.alloc(0));
    }
    return await AvalancheApp.prepareChunks(message, serializePath(path));
  }

  private concatMessageAndChangePath(
    message: Buffer,
    path?: Array<string>,
  ): Buffer {
    // data
    const msg = message;
    // no change_path
    if (path === undefined) {
      const buffer = Buffer.alloc(1);
      buffer.writeUInt8(0);
      return Buffer.concat([new Uint8Array(buffer), new Uint8Array(msg)]);
    }
    let buffer = Buffer.alloc(1);
    buffer.writeUInt8(path.length);
    path.forEach((element) => {
      buffer = Buffer.concat([
        new Uint8Array(buffer),
        new Uint8Array(serializePathSuffix(element)),
      ]);
    });
    return Buffer.concat([new Uint8Array(buffer), new Uint8Array(msg)]);
  }

  private async signSendChunk(
    chunkIdx: number,
    chunkNum: number,
    chunk: Buffer,
    param?: number,
    ins: number = INS.SIGN,
  ): Promise<ResponseSign> {
    let payloadType = PAYLOAD_TYPE.ADD;
    let p2 = 0;
    if (chunkIdx === 1) {
      payloadType = PAYLOAD_TYPE.INIT;
      if (param === undefined) {
        throw Error("number type not given");
      }
      p2 = param;
    }
    if (chunkIdx === chunkNum) {
      payloadType = PAYLOAD_TYPE.LAST;
    }

    return await this.transport
      .send(CLA, ins, payloadType, p2, chunk, [
        LedgerError.NoErrors,
        LedgerError.DataIsInvalid,
        LedgerError.BadKeyHandle,
        LedgerError.SignVerifyError,
        // The device replies with this when the accumulated payload exceeds its
        // upload buffer. Without it in the accepted list the transport raises a
        // TransportStatusError and the real reason is lost.
        LedgerError.OutputBufferTooSmall,
      ])
      .then((response: Buffer) => {
        const errorCodeData = response.slice(-2);
        if (errorCodeData.length < 2) {
          throw new Error("Invalid response: missing error code data");
        }
        const returnCode = errorCodeData[0]! * 256 + errorCodeData[1]!;
        let errorMessage = errorCodeToString(returnCode);

        if (
          returnCode === LedgerError.BadKeyHandle ||
          returnCode === LedgerError.DataIsInvalid ||
          returnCode === LedgerError.SignVerifyError
        ) {
          errorMessage = `${errorMessage} : ${response.slice(0, response.length - 2).toString("ascii")}`;
        }

        if (returnCode === LedgerError.NoErrors && response.length > 2) {
          return {
            hash: null,
            signature: null,
            returnCode: returnCode,
            errorMessage: errorMessage,
          };
        }

        return {
          returnCode: returnCode,
          errorMessage: errorMessage,
        };
      }, processErrorResponse);
  }

  async signHash(
    path_prefix: string,
    signing_paths: Array<string>,
    hash: Buffer,
    curve_type: number = P2_VALUES.SECP256K1,
  ): Promise<ResponseSign> {
    if (hash.length !== HASH_LEN) {
      throw new Error("Invalid hash length");
    }

    //send hash and path
    const first_response = await this.transport
      .send(
        CLA,
        INS.SIGN_HASH,
        FIRST_MESSAGE,
        0x00,
        Buffer.concat([
          new Uint8Array(serializePath(path_prefix)),
          new Uint8Array(hash),
        ]),
        [LedgerError.NoErrors],
      )
      .then((response: Buffer) => {
        const errorCodeData = response.slice(-2);
        if (errorCodeData.length < 2) {
          throw new Error("Invalid response: missing error code data");
        }
        const returnCode = errorCodeData[0]! * 256 + errorCodeData[1]!;
        let errorMessage = errorCodeToString(returnCode);

        if (
          returnCode === LedgerError.BadKeyHandle ||
          returnCode === LedgerError.DataIsInvalid
        ) {
          errorMessage = `${errorMessage} : ${response.slice(0, response.length - 2).toString("ascii")}`;
        }
        return {
          returnCode: returnCode,
          errorMessage: errorMessage,
        };
      }, processErrorResponse);

    if (first_response.returnCode !== LedgerError.NoErrors) {
      return first_response;
    }

    return this._signAndCollect(signing_paths, curve_type);
  }

  private async _signAndCollect(
    signing_paths: Array<string>,
    curve_type: number,
  ): Promise<ResponseSign> {
    // base response object to output on each iteration
    const result = {
      returnCode: LedgerError.NoErrors,
      errorMessage: "",
      hash: null,
      signatures: null as null | Map<string, Buffer>,
    };

    // where each pair path_suffix, signature are stored
    const signatures = new Map();

    for (let idx = 0; idx < signing_paths.length; idx++) {
      const suffix = signing_paths[idx];
      if (!suffix) {
        throw new Error(`Invalid signing path at index ${idx}`);
      }
      const path_buf = serializePathSuffix(suffix);

      const p1 = idx >= signing_paths.length - 1 ? LAST_MESSAGE : NEXT_MESSAGE;

      // send path to sign hash that should be in device's ram memory
      await this.transport
        .send(CLA, INS.SIGN_HASH, p1, curve_type, path_buf, [
          LedgerError.NoErrors,
          LedgerError.DataIsInvalid,
          LedgerError.BadKeyHandle,
          LedgerError.SignVerifyError,
          LedgerError.OutputBufferTooSmall,
        ])
        .then((response: Buffer) => {
          const errorCodeData = response.slice(-2);
          if (errorCodeData.length < 2) {
            throw new Error("Invalid response: missing error code data");
          }
          const returnCode = errorCodeData[0]! * 256 + errorCodeData[1]!;
          const errorMessage = errorCodeToString(returnCode);

          if (
            returnCode === LedgerError.BadKeyHandle ||
            returnCode === LedgerError.DataIsInvalid ||
            returnCode === LedgerError.SignVerifyError
          ) {
            result.errorMessage = `${errorMessage} : ${response.slice(0, response.length - 2).toString("ascii")}`;
          }

          if (returnCode === LedgerError.NoErrors && response.length > 2) {
            signatures.set(suffix, response.slice(0, -2));
          }

          result.returnCode = returnCode;
          result.errorMessage = errorMessage;

          return;
        }, processErrorResponse);

      if (result.returnCode !== LedgerError.NoErrors) {
        break;
      }
    }
    result.signatures = signatures;
    return result;
  }

  async sign(
    path_prefix: string,
    signing_paths: Array<string>,
    message: Buffer,
    change_paths?: Array<string>,
    curve_type: number = P2_VALUES.SECP256K1,
  ): Promise<ResponseSign> {
    // Do not show outputs that go to the signers
    let paths = signing_paths;
    if (change_paths !== undefined) {
      // remove duplication just is case
      paths = [...new Set([...paths, ...change_paths])];
    }

    // Prepend change_paths to the message as the device do set which outputs should be
    // shown at parsing
    const msg = this.concatMessageAndChangePath(message, paths);

    // Send transaction for review
    const response = await this.signGetChunks(msg, path_prefix)
      .then(
        (chunks) => {
          if (!chunks || chunks.length === 0 || !chunks[0]) {
            throw new Error("Invalid chunks array");
          }
          return this.signSendChunk(
            1,
            chunks.length,
            chunks[0],
            FIRST_MESSAGE,
            INS.SIGN,
          ).then(async (response) => {
            // initialize response
            let result = {
              returnCode: response.returnCode,
              errorMessage: response.errorMessage,
              signatures: null as null | Map<string, Buffer>,
            };

            // send chunks
            for (let i = 1; i < chunks.length; i += 1) {
              const chunk = chunks[i];
              if (!chunk) {
                throw new Error(`Invalid chunk at index ${i}`);
              }
              result = await this.signSendChunk(
                1 + i,
                chunks.length,
                chunk,
                NEXT_MESSAGE,
                INS.SIGN,
              );
              if (result.returnCode !== LedgerError.NoErrors) {
                break;
              }
            }
            return result;
          });
        },
        // NOTE: `.catch` rather than a second `.then` argument on purpose. An
        // onRejected handler only sees rejections of the promise it is attached
        // to, not ones raised inside its own onFulfilled callback -- and the
        // chunk loop above runs inside that callback. Attached as a rejection
        // argument, a mid-upload failure escaped as a raw TransportStatusError
        // instead of being mapped to a { returnCode, errorMessage }.
      )
      .catch(processErrorResponse);

    if (response.returnCode !== LedgerError.NoErrors) {
      return response;
    }

    // Transaction was approved so start iterating over signing_paths to sign
    // and collect each signature
    return this._signAndCollect(signing_paths, curve_type);
  }

  // Sign an arbitrary message.
  // This function takes in an avax path prefix like: m/44'/9000'/0'/0'
  // signing_paths: ["0/1", "5/8"]
  // message: The message to be signed
  async signMsg(
    path_prefix: string,
    signing_paths: Array<string>,
    message: string,
    curve_type: number = P2_VALUES.SECP256K1,
  ): Promise<ResponseSign> {
    const coinType = pathCoinType(path_prefix);

    if (coinType !== "9000'") {
      throw new Error("Only avax path is supported");
    }

    const header = Buffer.from("\x1AAvalanche Signed Message:\n", "utf8");

    const content = Buffer.from(message, "utf8");

    const msgSize = Buffer.alloc(4);
    msgSize.writeUInt32BE(content.length, 0);

    const avax_msg = Buffer.from(`${header}${msgSize}${content}`, "utf8");

    // Send msg for review
    const response = await this.signGetChunks(avax_msg, path_prefix)
      .then(
        (chunks) => {
          if (!chunks || chunks.length === 0 || !chunks[0]) {
            throw new Error("Invalid chunks array");
          }
          return this.signSendChunk(
            1,
            chunks.length,
            chunks[0],
            FIRST_MESSAGE,
            INS.SIGN_MSG,
          ).then(async (response) => {
            // initialize response
            let result = {
              returnCode: response.returnCode,
              errorMessage: response.errorMessage,
              signatures: null as null | Map<string, Buffer>,
            };

            // send chunks
            for (let i = 1; i < chunks.length; i += 1) {
              const chunk = chunks[i];
              if (!chunk) {
                throw new Error(`Invalid chunk at index ${i}`);
              }
              result = await this.signSendChunk(
                1 + i,
                chunks.length,
                chunk,
                NEXT_MESSAGE,
                INS.SIGN_MSG,
              );
              if (result.returnCode !== LedgerError.NoErrors) {
                break;
              }
            }
            return result;
          });
        },
        // See the note in sign(): the rejection handler must be a `.catch` so it
        // also covers failures raised inside the chunk loop above.
      )
      .catch(processErrorResponse);

    if (response.returnCode !== LedgerError.NoErrors) {
      return response;
    }

    // Message was approved so start iterating over signing_paths to sign
    // and collect each signature
    return this._signAndCollect(signing_paths, curve_type);
  }

  async getVersion(): Promise<ResponseVersion> {
    return await getVersion(this.transport).catch((err) =>
      processErrorResponse(err),
    );
  }

  async getAppInfo(): Promise<ResponseAppInfo> {
    return await this.transport.send(0xb0, 0x01, 0, 0).then((response) => {
      const errorCodeData = response.slice(-2);
      if (errorCodeData.length < 2) {
        throw new Error("Invalid response: missing error code data");
      }
      const returnCode = errorCodeData[0]! * 256 + errorCodeData[1]!;

      const result: { errorMessage?: string; returnCode?: LedgerError } = {};

      let appName = "err";
      let appVersion = "err";
      let flagLen = 0;
      let flagsValue = 0;

      if (response[0] !== 1) {
        // Ledger responds with format ID 1. There is no spec for any format != 1
        result.errorMessage = "response format ID not recognized";
        result.returnCode = LedgerError.DeviceIsBusy;
      } else {
        const appNameLen = response[1];
        if (appNameLen === undefined) {
          throw new Error("Invalid response: missing app name length");
        }
        appName = response.slice(2, 2 + appNameLen).toString("ascii");
        let idx = 2 + appNameLen;
        const appVersionLen = response[idx];
        if (appVersionLen === undefined) {
          throw new Error("Invalid response: missing app version length");
        }
        idx += 1;
        appVersion = response.slice(idx, idx + appVersionLen).toString("ascii");
        idx += appVersionLen;
        const appFlagsLen = response[idx];
        if (appFlagsLen === undefined) {
          throw new Error("Invalid response: missing app flags length");
        }
        idx += 1;
        flagLen = appFlagsLen;
        const flagsVal = response[idx];
        if (flagsVal === undefined) {
          throw new Error("Invalid response: missing flags value");
        }
        flagsValue = flagsVal;
      }

      return {
        returnCode,
        errorMessage: errorCodeToString(returnCode),
        //
        appName,
        appVersion,
        flagLen,
        flagsValue,
        flagRecovery: (flagsValue & 1) !== 0,

        flagSignedMcuCode: (flagsValue & 2) !== 0,

        flagOnboarded: (flagsValue & 4) !== 0,

        flagPINValidated: (flagsValue & 128) !== 0,
      };
    }, processErrorResponse);
  }

  private async _pubkey(
    path: string,
    show: boolean,
    hrp?: string,
    chainid?: string,
    curve_type: number = P2_VALUES.SECP256K1,
  ): Promise<ResponseAddress> {
    const p1 = show
      ? P1_VALUES.SHOW_ADDRESS_IN_DEVICE
      : P1_VALUES.ONLY_RETRIEVE;
    const serializedPath = serializePath(path);
    // Validate curve type
    if (
      curve_type !== P2_VALUES.SECP256K1 &&
      curve_type !== P2_VALUES.ED25519
    ) {
      throw new Error(
        "Invalid curve type. Must be 0 for secp256k1 or 1 for ed25519",
      );
    }

    const payload =
      curve_type === P2_VALUES.SECP256K1
        ? Buffer.concat([
            new Uint8Array(serializeHrp(hrp)),
            new Uint8Array(serializeChainID(chainid)),
            new Uint8Array(serializedPath),
          ])
        : serializedPath;

    return await this.transport
      .send(CLA, INS.GET_ADDR, p1, curve_type, payload, [LedgerError.NoErrors])
      .then(processGetAddrResponse, processErrorResponse);
  }

  async getAddressAndPubKey(
    path: string,
    show: boolean,
    hrp?: string,
    chainid?: string,
    curve_type: number = P2_VALUES.SECP256K1,
  ) {
    return await this._pubkey(path, show, hrp, chainid, curve_type);
  }

  private async _xpub(
    path: string,
    show: boolean,
    hrp?: string,
    chainid?: string,
  ): Promise<ResponseXPub> {
    const p1 = show
      ? P1_VALUES.SHOW_ADDRESS_IN_DEVICE
      : P1_VALUES.ONLY_RETRIEVE;
    const serializedPath = serializePath(path);
    const serializedHrp = serializeHrp(hrp);
    const serializedChainID = serializeChainID(chainid);

    return await this.transport
      .send(
        CLA,
        INS.GET_EXTENDED_PUBLIC_KEY,
        p1,
        0,
        Buffer.concat([
          new Uint8Array(serializedHrp),
          new Uint8Array(serializedChainID),
          new Uint8Array(serializedPath),
        ]),
        [LedgerError.NoErrors],
      )
      .then(processGetXPubResponse, processErrorResponse);
  }

  async getExtendedPubKey(
    path: string,
    show: boolean,
    hrp?: string,
    chainid?: string,
  ) {
    return await this._xpub(path, show, hrp, chainid);
  }

  private async _walletId(show: boolean): Promise<ResponseWalletId> {
    const p1 = show
      ? P1_VALUES.SHOW_ADDRESS_IN_DEVICE
      : P1_VALUES.ONLY_RETRIEVE;

    return await this.transport
      .send(CLA, INS.WALLET_ID, p1, 0)
      .then((response) => {
        const errorCodeData = response.slice(-2);
        if (errorCodeData.length < 2) {
          throw new Error("Invalid response: missing error code data");
        }
        const returnCode = (errorCodeData[0]! * 256 +
          errorCodeData[1]!) as LedgerError;

        return {
          returnCode,
          errorMessage: errorCodeToString(returnCode),
          id: response.slice(0, 6),
        };
      }, processErrorResponse);
  }

  async getWalletId() {
    return await this._walletId(false);
  }

  async showWalletId() {
    return await this._walletId(true);
  }

  // ---------------------------------------------------------------------------
  // EVM (C-Chain)
  //
  // Signing goes through the Device Management Kit's Ethereum signer, which replaces
  // `@ledgerhq/hw-app-eth` (deprecated, removed September 2026). The few APDUs the kit has
  // no equivalent for are sent through the transport, laid out exactly as hw-app-eth did.
  // ---------------------------------------------------------------------------

  /**
   * The Ethereum signer, built on first use so that callers who only touch the X/P chains
   * never pay for it -- or need a DMK session at all.
   */
  private get ethSigner(): SignerEth {
    if (this.signer === undefined) {
      if (this.evm === undefined) {
        throw new Error(
          "EVM signing needs a Device Management Kit session: construct AvalancheApp with { dmk, sessionId }",
        );
      }
      const { dmk, sessionId, originToken, contextModule } = this.evm;
      const builder = new SignerEthBuilder({
        dmk,
        sessionId,
        ...(originToken !== undefined ? { originToken } : {}),
      });
      if (contextModule !== undefined) {
        builder.withContextModule(contextModule);
      }
      this.signer = builder.build();
    }
    return this.signer;
  }

  /**
   * Signs a serialized C-Chain transaction.
   *
   * Clear-signing context (token metadata, plugins, trusted names) is resolved by the
   * signer's context module, so there is no `resolution` argument any more.
   *
   * @param path - BIP-32 path, e.g. `m/44'/60'/0'/0/0`
   * @param rawTxHex - the RLP-encoded transaction as hex (`0x` prefix optional)
   * @returns `r`, `s` and `v` as hex strings, as `hw-app-eth` returned them
   */
  async signEVMTransaction(
    path: string,
    rawTxHex: string,
  ): Promise<{ s: string; v: string; r: string }> {
    const signature = await runDeviceAction(
      this.ethSigner.signTransaction(
        evmDerivationPath(path),
        hexToBytes(rawTxHex),
        { skipOpenApp: true },
      ),
    );
    return toEvmTransactionSignature(signature);
  }

  async getETHAddress(
    path: string,
    boolDisplay = false,
    boolChaincode = false,
  ): Promise<{
    publicKey: string;
    address: string;
    chainCode?: string;
  }> {
    const { publicKey, address, chainCode } = await runDeviceAction(
      this.ethSigner.getAddress(evmDerivationPath(path), {
        checkOnDevice: boolDisplay,
        returnChainCode: boolChaincode,
        skipOpenApp: true,
      }),
    );
    return chainCode === undefined
      ? { publicKey, address }
      : { publicKey, address, chainCode };
  }

  async getAppConfiguration(): Promise<{
    arbitraryDataEnabled: number;
    erc20ProvisioningNecessary: number;
    starkEnabled: number;
    starkv2Supported: number;
    version: string;
  }> {
    const response = await this.transport.send(
      CLA_ETH,
      INS_ETH.GET_APP_CONFIGURATION,
      0x00,
      0x00,
    );
    if (response.length < 4) {
      throw new Error(
        `Malformed app configuration response: ${response.length} bytes`,
      );
    }
    const flags = response.readUInt8(0);
    return {
      arbitraryDataEnabled: flags & 0x01,
      erc20ProvisioningNecessary: flags & 0x02,
      starkEnabled: flags & 0x04,
      starkv2Supported: flags & 0x08,
      version: `${response.readUInt8(1)}.${response.readUInt8(2)}.${response.readUInt8(3)}`,
    };
  }

  /**
   * Sends one of the Ethereum app's "provide context" APDUs.
   *
   * Same contract as hw-app-eth: resolves `true` when the app took the data, `false` for
   * the status words meaning "this app cannot use it" (so callers can fall back to blind
   * signing), and rejects on anything else.
   */
  private async provideEthContext(
    ins: number,
    data: Buffer,
    tolerated: number[],
  ): Promise<boolean> {
    const response = await this.transport.send(CLA_ETH, ins, 0x00, 0x00, data, [
      LedgerError.NoErrors,
      ...tolerated,
    ]);
    return response.readUInt16BE(response.length - 2) === LedgerError.NoErrors;
  }

  async provideERC20TokenInformation(
    ticker: string,
    contractName: string,
    address: string,
    decimals: number,
    chainId: number,
  ): Promise<boolean> {
    // Calculate lengths
    const tickerLength = Buffer.byteLength(ticker);
    const contractNameLength = Buffer.byteLength(contractName);

    // Create a buffer with the exact size needed
    const buffer = Buffer.alloc(
      1 + tickerLength + 1 + contractNameLength + 20 + 4 + 4,
    );

    let offset = 0;

    // Ticker length and ticker
    buffer.writeUInt8(tickerLength, offset);
    offset += 1;
    buffer.write(ticker, offset);
    offset += tickerLength;

    // Contract name length and contract name
    buffer.writeUInt8(contractNameLength, offset);
    offset += 1;
    buffer.write(contractName, offset);
    offset += contractNameLength;

    // Address (20 bytes, hex string needs to be parsed)

    var addr_offset = 0;
    if (address.startsWith("0x")) {
      addr_offset = 2;
    }

    // Slice to remove '0x'
    const addressBuffer = Buffer.from(address.slice(addr_offset), "hex");
    addressBuffer.copy(new Uint8Array(buffer), offset);
    offset += 20;

    // Decimals (4 bytes, big endian)
    buffer.writeUInt32BE(decimals, offset);
    offset += 4;

    // Chain ID (4 bytes, big endian)
    buffer.writeUInt32BE(chainId, offset);
    offset += 4;

    // 0x6d00: an app too old to know this instruction
    return await this.provideEthContext(
      INS_ETH.PROVIDE_ERC20_TOKEN_INFORMATION,
      buffer,
      [0x6d00],
    );
  }

  async provideNFTInformation(
    collectionName: string,
    contractAddress: string,
    chainId: bigint,
  ): Promise<boolean> {
    const NAME_LENGTH_SIZE = 1;
    const HEADER_SIZE = TYPE_SIZE + VERSION_SIZE + NAME_LENGTH_SIZE;
    const KEY_ID_SIZE = 1;
    const PROD_NFT_METADATA_KEY = 1;

    const collectionNameLength = Buffer.byteLength(collectionName, "utf8");

    if (collectionNameLength > COLLECTION_NAME_MAX_LEN) {
      throw new Error(
        `Collection name exceeds maximum allowed length of ${COLLECTION_NAME_MAX_LEN}`,
      );
    }

    // We generate a fake signature, because verification is disabled
    // in the app.
    const fakeDerSignature = this._generateFakeDerSignature();

    const buffer = Buffer.alloc(
      HEADER_SIZE +
        collectionNameLength +
        ADDRESS_LENGTH +
        CHAIN_ID_SIZE +
        KEY_ID_SIZE +
        ALGORITHM_ID_SIZE +
        SIGNATURE_LENGTH_SIZE +
        fakeDerSignature.length,
    );

    let offset = 0;

    buffer.writeUInt8(TYPE_1, offset);
    offset += TYPE_SIZE;

    buffer.writeUInt8(VERSION_1, offset);
    offset += VERSION_SIZE;

    buffer.writeUInt8(collectionNameLength, offset);
    offset += NAME_LENGTH_SIZE;

    buffer.write(collectionName, offset, "utf8");
    offset += collectionNameLength;

    Buffer.from(contractAddress.slice(2), "hex").copy(
      new Uint8Array(buffer),
      offset,
    ); // Remove '0x' from address
    offset += ADDRESS_LENGTH;

    buffer.writeBigUInt64BE(chainId, offset);
    offset += CHAIN_ID_SIZE;

    buffer.writeUInt8(PROD_NFT_METADATA_KEY, offset); // Assume production key for simplicity
    offset += KEY_ID_SIZE;

    buffer.writeUInt8(ALGORITHM_ID_1, offset); // Assume a specific algorithm for signature or hash
    offset += ALGORITHM_ID_SIZE;

    buffer.writeUInt8(fakeDerSignature.length, offset);
    offset += SIGNATURE_LENGTH_SIZE;

    fakeDerSignature.copy(new Uint8Array(buffer), offset);

    // 0x6d00: an app too old to know this instruction
    return await this.provideEthContext(
      INS_ETH.PROVIDE_NFT_INFORMATION,
      buffer,
      [0x6d00],
    );
  }

  _generateFakeDerSignature(): Buffer {
    const fakeSignatureLength = 70;
    const fakeDerSignature = Buffer.alloc(fakeSignatureLength);

    // Fill the buffer with random bytes
    for (let i = 0; i < fakeSignatureLength; i++) {
      fakeDerSignature[i] = Math.floor(Math.random() * 256);
    }

    return fakeDerSignature;
  }

  // We assume pluginName is ERC721 for Nft tokens
  async setPlugin(
    contractAddress: string,
    methodSelector: string,
    chainId: bigint,
  ): Promise<boolean> {
    const KEY_ID = 2;
    const PLUGIN_NAME_LENGTH_SIZE = 1;
    const KEY_ID_SIZE = 1;
    const PLUGIN_NAME = "ERC721";

    const pluginNameBuffer = Buffer.from(PLUGIN_NAME, "utf8");
    const pluginNameLength = pluginNameBuffer.length;

    const contractAddressBuffer = Buffer.from(contractAddress.slice(2), "hex");
    const methodSelectorBuffer = Buffer.from(methodSelector.slice(2), "hex");

    // We generate a fake signature, because verification is disabled
    // in the app.
    const signatureBuffer = this._generateFakeDerSignature();
    const signatureLength = signatureBuffer.length;

    const buffer = Buffer.alloc(
      TYPE_SIZE +
        VERSION_SIZE +
        PLUGIN_NAME_LENGTH_SIZE +
        pluginNameLength +
        contractAddressBuffer.length +
        methodSelectorBuffer.length +
        CHAIN_ID_SIZE +
        KEY_ID_SIZE +
        ALGORITHM_ID_SIZE +
        SIGNATURE_LENGTH_SIZE +
        signatureLength,
    );

    let offset = 0;

    buffer.writeUInt8(TYPE_1, offset);
    offset += TYPE_SIZE;

    buffer.writeUInt8(VERSION_1, offset);
    offset += VERSION_SIZE;

    buffer.writeUInt8(pluginNameLength, offset);
    offset += PLUGIN_NAME_LENGTH_SIZE;

    pluginNameBuffer.copy(new Uint8Array(buffer), offset);
    offset += pluginNameLength;

    contractAddressBuffer.copy(new Uint8Array(buffer), offset);
    offset += contractAddressBuffer.length;

    methodSelectorBuffer.copy(new Uint8Array(buffer), offset);
    offset += methodSelectorBuffer.length;

    buffer.writeBigUInt64BE(BigInt(chainId), offset);
    offset += CHAIN_ID_SIZE;

    // use default key_id
    buffer.writeUInt8(KEY_ID, offset);
    offset += KEY_ID_SIZE;

    // use default algorithm
    buffer.writeUInt8(ALGORITHM_ID_1, offset);
    offset += ALGORITHM_ID_SIZE;

    buffer.writeUInt8(signatureLength, offset);
    offset += SIGNATURE_LENGTH_SIZE;

    signatureBuffer.copy(new Uint8Array(buffer), offset);

    // 0x6a80: plugin name too short or too long; 0x6984: plugin not installed;
    // 0x6d00: an app too old to know this instruction
    return await this.provideEthContext(
      INS_ETH.SET_PLUGIN,
      buffer,
      [0x6a80, 0x6984, 0x6d00],
    );
  }

  /**
   * @deprecated `hw-app-eth`'s resolution step is now done inside the signer, so this is
   * the same call as {@link signEVMTransaction}. It will be removed in the next major.
   */
  async clearSignTransaction(
    path: string,
    rawTxHex: string,
  ): Promise<{ r: string; s: string; v: string }> {
    return await this.signEVMTransaction(path, rawTxHex);
  }

  /**
   * Signs an EIP-712 typed-data message, showing its fields on the device.
   *
   * The message is the usual `{ domain, types, primaryType, message }` object. The signer
   * always uses the app's full EIP-712 implementation (the one Ledger keeps after
   * September 2026) and falls back to the hashed one only when the app rejects it.
   */
  async signEIP712Message(
    path: string,
    typedData: TypedData,
  ): Promise<{ v: number; s: string; r: string }> {
    const signature = await runDeviceAction(
      this.ethSigner.signTypedData(evmDerivationPath(path), typedData, {
        skipOpenApp: true,
      }),
    );
    return toEvmTypedDataSignature(signature);
  }

  /**
   * Signs an EIP-712 message from its two hashes (the "v0" flow), showing only the
   * hashes on the device.
   *
   * @deprecated This is the flow Ledger removes from its own Ethereum app in September
   * 2026 and the Device Management Kit has no equivalent for. The Avalanche app still
   * implements it, so the APDU is sent by hand for now; prefer {@link signEIP712Message}.
   */
  async signEIP712HashedMessage(
    path: string,
    domainSeparatorHex: string,
    hashStructMessageHex: string,
  ): Promise<{ v: number; s: string; r: string }> {
    const domainSeparator = Buffer.from(
      stripHexPrefix(domainSeparatorHex),
      "hex",
    );
    const hashStruct = Buffer.from(stripHexPrefix(hashStructMessageHex), "hex");
    if (domainSeparator.length !== HASH_LEN || hashStruct.length !== HASH_LEN) {
      throw new Error(
        "domainSeparatorHex and hashStructMessageHex must each be 32 bytes of hex",
      );
    }
    const data = Buffer.concat([
      new Uint8Array(serializePath(path.startsWith("m/") ? path : `m/${path}`)),
      new Uint8Array(domainSeparator),
      new Uint8Array(hashStruct),
    ]);
    const response = await this.transport.send(
      CLA_ETH,
      INS_ETH.SIGN_EIP712_MESSAGE,
      0x00,
      P2_EIP712_HASHED,
      data,
    );
    if (response.length < 1 + 2 * HASH_LEN) {
      throw new Error(
        `Malformed EIP-712 signature response: ${response.length} bytes`,
      );
    }
    return {
      v: response.readUInt8(0),
      r: response.subarray(1, 1 + HASH_LEN).toString("hex"),
      s: response.subarray(1 + HASH_LEN, 1 + 2 * HASH_LEN).toString("hex"),
    };
  }

  /**
   * Signs an EIP-191 personal message (`personal_sign`), showing it on the device.
   *
   * The APDU is sent through the transport, not the Device Management Kit signer, so this
   * works without `{ dmk, sessionId }`. It is laid out exactly as `hw-app-eth`'s
   * `signPersonalMessage` laid it out; the app prepends `"\x19Ethereum Signed Message:\n"`
   * and the length itself, so pass the bare message.
   *
   * Differences from `hw-app-eth` when migrating:
   * - The path must have 3 to 5 levels, as for the SDK's other methods. `hw-app-eth` accepted
   *   any depth; a shorter or longer path now throws before anything is sent.
   * - An empty message is not rejected (`hw-app-eth` threw): the device shows the review
   *   without a message page and signs it.
   *
   * There is no size check before sending. The app checks the size only after the last chunk
   * arrives, so a message that is too large is sent in full and then rejected. The limit
   * depends on the content: the app shows each non-ASCII byte as a 4-character `\xNN` code,
   * so such messages reach it sooner.
   *
   * @param path - BIP-32 path with 3 to 5 levels, e.g. `m/44'/60'/0'/0/0`
   * @param messageHex - the message bytes as hex (`0x` prefix optional), not the text itself
   * @returns `v` = 27 + recovery id and unprefixed hex `r`/`s`, as `hw-app-eth` returned them.
   *   `v` is 27 or 28 in practice; 29 or 30 would need R.x ≥ the curve order, which
   *   essentially never happens.
   */
  async signPersonalMessage(
    path: string,
    messageHex: string,
  ): Promise<{ v: number; r: string; s: string }> {
    const message = hexToBytes(messageHex);
    const length = Buffer.alloc(4);
    length.writeUInt32BE(message.length);
    // path | message length (u32 BE) | message, split across as many APDUs as it takes
    const payload = Buffer.concat([
      new Uint8Array(serializePath(path.startsWith("m/") ? path : `m/${path}`)),
      new Uint8Array(length),
      message,
    ]);

    let response: Buffer = Buffer.alloc(0);
    for (let offset = 0; offset < payload.length; offset += CHUNK_SIZE) {
      response = await this.transport.send(
        CLA_ETH,
        INS_ETH.SIGN_PERSONAL_MESSAGE,
        offset === 0 ? P1_PERSONAL_MESSAGE_FIRST : P1_PERSONAL_MESSAGE_MORE,
        0x00,
        payload.subarray(offset, offset + CHUNK_SIZE),
      );
    }
    if (response.length < 1 + 2 * HASH_LEN) {
      throw new Error(
        `Malformed personal message signature response: ${response.length} bytes`,
      );
    }
    return {
      v: response.readUInt8(0),
      r: response.subarray(1, 1 + HASH_LEN).toString("hex"),
      s: response.subarray(1 + HASH_LEN, 1 + 2 * HASH_LEN).toString("hex"),
    };
  }
}
