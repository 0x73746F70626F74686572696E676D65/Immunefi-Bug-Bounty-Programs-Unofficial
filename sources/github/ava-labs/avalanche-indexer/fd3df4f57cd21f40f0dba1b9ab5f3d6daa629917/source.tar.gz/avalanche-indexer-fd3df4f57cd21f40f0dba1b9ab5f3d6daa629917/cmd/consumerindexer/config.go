package main

import (
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/urfave/cli/v2"

	"github.com/ava-labs/avalanche-indexer/pkg/clickhouse"
	"github.com/ava-labs/avalanche-indexer/pkg/kafka"
)

const (
	// minBlockBufferSize is the minimum valid value for BlockBufferSize (uint8: 0)
	minBlockBufferSize = 0
	// maxBlockBufferSize is the maximum valid value for BlockBufferSize (uint8: 255)
	maxBlockBufferSize = 255
)

// validateRetentionValue validates a Kafka retention configuration value.
// It ensures the value is either "-1" (infinite) or a positive integer.
func validateRetentionValue(value, fieldName string) error {
	if value == "" {
		return nil // Empty is valid (uses Kafka broker default)
	}

	parsed, err := strconv.ParseInt(value, 10, 64)
	if err != nil {
		return fmt.Errorf("%s must be a valid integer or -1 for infinite retention, got: %s", fieldName, value)
	}

	if parsed == -1 {
		return nil // -1 is valid (infinite retention)
	}

	if parsed <= 0 {
		return fmt.Errorf("%s must be positive or -1 for infinite retention, got: %d", fieldName, parsed)
	}

	return nil
}

// validateBlockBufferSize validates that the block buffer size is within uint8 range (0-255)
// and returns the validated uint8 value or an error
func validateBlockBufferSize(size int) (uint8, error) {
	if size < minBlockBufferSize || size > maxBlockBufferSize {
		return 0, fmt.Errorf(
			"clickhouse-block-buffer-size must be between %d and %d, got %d",
			minBlockBufferSize, maxBlockBufferSize, size,
		)
	}
	return uint8(size), nil
}

// Config holds all configuration for the consumerindexer application
type Config struct {
	// Application settings
	Verbose bool
	Mode    string

	// Kafka consumer settings
	BootstrapServers               string
	GroupID                        string
	Topic                          string
	DLQTopic                       string
	AutoOffsetReset                string
	Concurrency                    int64
	OffsetCommitInterval           time.Duration
	EnableKafkaLogs                bool
	SessionTimeout                 time.Duration
	MaxPollInterval                time.Duration
	FlushTimeout                   time.Duration
	GoroutineWaitTimeout           time.Duration
	PollInterval                   time.Duration
	PublishToDLQ                   bool
	KafkaTopicNumPartitions        int
	KafkaTopicReplicationFactor    int
	KafkaTopicRetentionMs          string
	KafkaTopicRetentionBytes       string
	KafkaDLQTopicNumPartitions     int
	KafkaDLQTopicReplicationFactor int
	KafkaDLQTopicRetentionMs       string
	KafkaDLQTopicRetentionBytes    string
	KafkaTopicMessageMaxBytes      string
	KafkaSASL                      kafka.SASLConfig

	// Consumer retry policy settings
	ConsumerRetryMaxRetries     int
	ConsumerRetryBaseDelay      time.Duration
	ConsumerRetryMaxDelay       time.Duration
	EnableClickHouseBatchWrites bool

	BatchWriterWorkers      int
	BatchWriterMaxBlocks    int
	BatchWriterFlushTimeout time.Duration

	// DLQ consumer settings
	EnableDLQConsumer               bool
	DLQConsumerGroupID              string
	DLQConsumerConcurrency          int64
	DLQConsumerOffsetCommitInterval time.Duration
	DLQConsumerSessionTimeout       time.Duration
	DLQConsumerMaxPollInterval      time.Duration
	DLQConsumerGoroutineWaitTimeout time.Duration
	DLQConsumerPollInterval         time.Duration
	DLQConsumerRetryBaseDelay       time.Duration
	DLQConsumerRetryMaxDelay        time.Duration

	// ClickHouse settings
	ClickHouse clickhouse.Config

	// Table names
	RawBlocksTableName            string
	RawTransactionsTableName      string
	RawLogsTableName              string
	InternalTransactionsTableName string

	// ICM settings
	TeleporterContractAddresses              []string
	ICMMessagesTableName                     string
	ICMSendEventsTableName                   string
	ICMReceiveEventsTableName                string
	ICMMessageExecutedEventsTableName        string
	ICMMessageExecutionFailedEventsTableName string
	ICMReceiptsEventsTableName               string
	ICMFeeInfoEventsTableName                string
	ICMFeeRedemptionsEventsTableName         string

	// Metrics settings
	MetricsHost   string
	MetricsPort   int
	ChainID       uint64
	Environment   string
	Region        string
	CloudProvider string
}

// MetricsAddr returns the formatted metrics address
func (c *Config) MetricsAddr() string {
	return fmt.Sprintf("%s:%d", c.MetricsHost, c.MetricsPort)
}

// buildConfig builds a Config from CLI context flags
func buildConfig(c *cli.Context) (*Config, error) {
	chCfg, err := buildClickHouseConfig(c)
	if err != nil {
		return nil, fmt.Errorf("failed to build ClickHouse config: %w", err)
	}

	// Validate retention configuration values for main topic
	topicRetentionMs := c.String("kafka-topic-retention-ms")
	if err := validateRetentionValue(topicRetentionMs, "kafka-topic-retention-ms"); err != nil {
		return nil, err
	}

	topicRetentionBytes := c.String("kafka-topic-retention-bytes")
	if err := validateRetentionValue(topicRetentionBytes, "kafka-topic-retention-bytes"); err != nil {
		return nil, err
	}

	// Validate retention configuration values for DLQ topic
	dlqRetentionMs := c.String("kafka-dlq-topic-retention-ms")
	if err := validateRetentionValue(dlqRetentionMs, "kafka-dlq-topic-retention-ms"); err != nil {
		return nil, err
	}

	dlqRetentionBytes := c.String("kafka-dlq-topic-retention-bytes")
	if err := validateRetentionValue(dlqRetentionBytes, "kafka-dlq-topic-retention-bytes"); err != nil {
		return nil, err
	}

	return &Config{
		Verbose:                         c.Bool("verbose"),
		Mode:                            c.String("mode"),
		BootstrapServers:                c.String("bootstrap-servers"),
		GroupID:                         c.String("group-id"),
		Topic:                           c.String("topic"),
		DLQTopic:                        c.String("dlq-topic"),
		AutoOffsetReset:                 c.String("auto-offset-reset"),
		Concurrency:                     c.Int64("concurrency"),
		OffsetCommitInterval:            c.Duration("offset-commit-interval"),
		EnableKafkaLogs:                 c.Bool("enable-kafka-logs"),
		SessionTimeout:                  c.Duration("session-timeout"),
		MaxPollInterval:                 c.Duration("max-poll-interval"),
		FlushTimeout:                    c.Duration("flush-timeout"),
		GoroutineWaitTimeout:            c.Duration("goroutine-wait-timeout"),
		PollInterval:                    c.Duration("poll-interval"),
		PublishToDLQ:                    c.Bool("publish-to-dlq"),
		KafkaTopicNumPartitions:         c.Int("kafka-topic-num-partitions"),
		KafkaTopicReplicationFactor:     c.Int("kafka-topic-replication-factor"),
		KafkaTopicRetentionMs:           c.String("kafka-topic-retention-ms"),
		KafkaTopicRetentionBytes:        c.String("kafka-topic-retention-bytes"),
		KafkaDLQTopicNumPartitions:      c.Int("kafka-dlq-topic-num-partitions"),
		KafkaDLQTopicReplicationFactor:  c.Int("kafka-dlq-topic-replication-factor"),
		KafkaDLQTopicRetentionMs:        c.String("kafka-dlq-topic-retention-ms"),
		KafkaDLQTopicRetentionBytes:     c.String("kafka-dlq-topic-retention-bytes"),
		KafkaTopicMessageMaxBytes:       c.String("kafka-topic-message-max-bytes"),
		ConsumerRetryMaxRetries:         c.Int("consumer-retry-max-retries"),
		ConsumerRetryBaseDelay:          c.Duration("consumer-retry-base-delay"),
		ConsumerRetryMaxDelay:           c.Duration("consumer-retry-max-delay"),
		EnableDLQConsumer:               c.Bool("enable-dlq-consumer"),
		DLQConsumerGroupID:              c.String("dlq-consumer-group-id"),
		DLQConsumerConcurrency:          c.Int64("dlq-consumer-concurrency"),
		DLQConsumerOffsetCommitInterval: c.Duration("dlq-consumer-offset-commit-interval"),
		DLQConsumerSessionTimeout:       c.Duration("dlq-consumer-session-timeout"),
		DLQConsumerMaxPollInterval:      c.Duration("dlq-consumer-max-poll-interval"),
		DLQConsumerGoroutineWaitTimeout: c.Duration("dlq-consumer-goroutine-wait-timeout"),
		DLQConsumerPollInterval:         c.Duration("dlq-consumer-poll-interval"),
		DLQConsumerRetryBaseDelay:       c.Duration("dlq-consumer-retry-base-delay"),
		DLQConsumerRetryMaxDelay:        c.Duration("dlq-consumer-retry-max-delay"),
		KafkaSASL: kafka.SASLConfig{
			Username:         c.String("kafka-sasl-username"),
			Password:         c.String("kafka-sasl-password"),
			Mechanism:        c.String("kafka-sasl-mechanism"),
			SecurityProtocol: c.String("kafka-security-protocol"),
		},
		ClickHouse:                               chCfg,
		RawBlocksTableName:                       c.String("raw-blocks-table-name"),
		RawTransactionsTableName:                 c.String("raw-transactions-table-name"),
		RawLogsTableName:                         c.String("raw-logs-table-name"),
		InternalTransactionsTableName:            c.String("internal-transactions-table-name"),
		TeleporterContractAddresses:              buildTeleporterAddresses(c),
		ICMMessagesTableName:                     c.String("icm-messages-table-name"),
		ICMSendEventsTableName:                   c.String("icm-send-events-table-name"),
		ICMReceiveEventsTableName:                c.String("icm-receive-events-table-name"),
		ICMMessageExecutedEventsTableName:        c.String("icm-message-executed-events-table-name"),
		ICMMessageExecutionFailedEventsTableName: c.String("icm-message-execution-failed-events-table-name"),
		ICMReceiptsEventsTableName:               c.String("icm-receipts-events-table-name"),
		ICMFeeInfoEventsTableName:                c.String("icm-fee-info-events-table-name"),
		ICMFeeRedemptionsEventsTableName:         c.String("icm-fee-redemptions-events-table-name"),
		MetricsHost:                              c.String("metrics-host"),
		MetricsPort:                              c.Int("metrics-port"),
		ChainID:                                  c.Uint64("chain-id"),
		Environment:                              c.String("environment"),
		Region:                                   c.String("region"),
		CloudProvider:                            c.String("cloud-provider"),
		EnableClickHouseBatchWrites:              c.Bool("enable-clickhouse-batch-writes"),
		BatchWriterWorkers:                       c.Int("batch-writer-workers"),
		BatchWriterMaxBlocks:                     c.Int("batch-writer-max-blocks"),
		BatchWriterFlushTimeout:                  c.Duration("batch-writer-flush-timeout"),
	}, nil
}

// buildTeleporterAddresses reads the teleporter-contract-addresses flag.
// Handles both repeated flags (--flag a --flag b) and a single comma-separated value
// (consistent with the clickhouse-hosts handling in buildClickHouseConfig).
func buildTeleporterAddresses(c *cli.Context) []string {
	addrs := c.StringSlice("teleporter-contract-addresses")
	if len(addrs) == 1 && strings.Contains(addrs[0], ",") {
		parts := strings.Split(addrs[0], ",")
		addrs = make([]string, 0, len(parts))
		for _, p := range parts {
			if trimmed := strings.TrimSpace(p); trimmed != "" {
				addrs = append(addrs, trimmed)
			}
		}
	}
	return addrs
}

// buildClickHouseConfig builds a ClickhouseConfig from CLI context flags
func buildClickHouseConfig(c *cli.Context) (clickhouse.Config, error) {
	// Handle hosts - StringSliceFlag returns []string, but we need to handle comma-separated values
	hosts := c.StringSlice("clickhouse-hosts")
	// If hosts is a single comma-separated string, split it
	if len(hosts) == 1 && strings.Contains(hosts[0], ",") {
		hosts = strings.Split(hosts[0], ",")
		for i, host := range hosts {
			hosts[i] = strings.TrimSpace(host)
		}
	}

	// Validate and convert block buffer size to uint8 range
	blockBufferSize := c.Int("clickhouse-block-buffer-size")
	validatedSize, err := validateBlockBufferSize(blockBufferSize)
	if err != nil {
		return clickhouse.Config{}, err
	}

	return clickhouse.Config{
		Hosts:                hosts,
		Cluster:              c.String("clickhouse-cluster"),
		Database:             c.String("clickhouse-database"),
		Username:             c.String("clickhouse-username"),
		Password:             c.String("clickhouse-password"),
		Debug:                c.Bool("clickhouse-debug"),
		InsecureSkipVerify:   c.Bool("clickhouse-insecure-skip-verify"),
		MaxExecutionTime:     c.Int("clickhouse-max-execution-time"),
		DialTimeout:          c.Int("clickhouse-dial-timeout"),
		MaxOpenConns:         c.Int("clickhouse-max-open-conns"),
		MaxIdleConns:         c.Int("clickhouse-max-idle-conns"),
		ConnMaxLifetime:      c.Int("clickhouse-conn-max-lifetime"),
		BlockBufferSize:      validatedSize,
		MaxBlockSize:         c.Int("clickhouse-max-block-size"),
		MaxCompressionBuffer: c.Int("clickhouse-max-compression-buffer"),
		ClientName:           c.String("clickhouse-client-name"),
		ClientVersion:        c.String("clickhouse-client-version"),
		UseHTTP:              c.Bool("clickhouse-use-http"),
	}, nil
}
