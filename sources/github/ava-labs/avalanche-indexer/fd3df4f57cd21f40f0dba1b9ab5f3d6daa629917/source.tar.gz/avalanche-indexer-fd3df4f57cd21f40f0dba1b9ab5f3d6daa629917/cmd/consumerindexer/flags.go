package main

import (
	"time"

	"github.com/urfave/cli/v2"

	"github.com/ava-labs/avalanche-indexer/pkg/clickhouse"
	"github.com/ava-labs/avalanche-indexer/pkg/kafka"
)

// runFlags returns all CLI runFlags for the consumerindexer run command
func runFlags() []cli.Flag {
	return []cli.Flag{
		&cli.BoolFlag{
			Name:    "verbose",
			Aliases: []string{"v"},
			Usage:   "Enable verbose logging",
			EnvVars: []string{"VERBOSE"},
			Value:   false,
		},
		&cli.StringFlag{
			Name:    "mode",
			Usage:   "The mode to run the block fetcher in (blocks or traces). Default is blocks.",
			EnvVars: []string{"MODE"},
			Value:   blocksMode,
		},
		// Kafka configuration flags
		&cli.StringFlag{
			Name:     "bootstrap-servers",
			Aliases:  []string{"b"},
			Usage:    "Kafka bootstrap servers (comma-separated)",
			EnvVars:  []string{"KAFKA_BOOTSTRAP_SERVERS"},
			Required: true,
		},
		&cli.StringFlag{
			Name:     "group-id",
			Aliases:  []string{"g"},
			Usage:    "Kafka consumer group ID",
			EnvVars:  []string{"KAFKA_GROUP_ID"},
			Required: true,
		},
		&cli.StringFlag{
			Name:     "topic",
			Aliases:  []string{"t"},
			Usage:    "Kafka topic to consume from",
			EnvVars:  []string{"KAFKA_TOPIC"},
			Required: true,
		},
		&cli.StringFlag{
			Name:    "dlq-topic",
			Usage:   "Dead letter queue topic for failed messages",
			EnvVars: []string{"KAFKA_DLQ_TOPIC"},
			Value:   "",
		},
		&cli.StringFlag{
			Name:    "auto-offset-reset",
			Aliases: []string{"o"},
			Usage:   "Kafka auto offset reset policy (earliest, latest, none)",
			EnvVars: []string{"KAFKA_AUTO_OFFSET_RESET"},
			Value:   "earliest",
		},
		&cli.Int64Flag{
			Name:    "concurrency",
			Usage:   "Concurrent message processors",
			EnvVars: []string{"KAFKA_CONCURRENCY"},
			Value:   10,
		},
		&cli.DurationFlag{
			Name:    "offset-commit-interval",
			Usage:   "Interval for committing offsets",
			EnvVars: []string{"KAFKA_OFFSET_COMMIT_INTERVAL"},
			Value:   10 * time.Second,
		},
		&cli.BoolFlag{
			Name:    "enable-kafka-logs",
			Usage:   "Enable librdkafka client logs",
			EnvVars: []string{"KAFKA_ENABLE_LOGS"},
			Value:   false,
		},
		&cli.DurationFlag{
			Name:    "session-timeout",
			Usage:   "Kafka consumer session timeout",
			EnvVars: []string{"KAFKA_SESSION_TIMEOUT"},
			Value:   240 * time.Second,
		},
		&cli.DurationFlag{
			Name:    "max-poll-interval",
			Usage:   "Kafka consumer max poll interval",
			EnvVars: []string{"KAFKA_MAX_POLL_INTERVAL"},
			Value:   3400 * time.Second,
		},
		&cli.DurationFlag{
			Name:    "flush-timeout",
			Usage:   "Kafka dlq producer flush timeout when closing",
			EnvVars: []string{"KAFKA_FLUSH_TIMEOUT"},
			Value:   15 * time.Second,
		},
		&cli.DurationFlag{
			Name:    "goroutine-wait-timeout",
			Usage:   "Timeout for waiting in-flight goroutines on shutdown",
			EnvVars: []string{"KAFKA_GOROUTINE_WAIT_TIMEOUT"},
			Value:   30 * time.Second,
		},
		&cli.DurationFlag{
			Name:    "poll-interval",
			Usage:   "Poll interval for Kafka consumer",
			EnvVars: []string{"KAFKA_POLL_INTERVAL"},
			Value:   100 * time.Millisecond,
		},
		&cli.IntFlag{
			Name:    "kafka-topic-num-partitions",
			Usage:   "The number of partitions to use for the Kafka topic (must be greater than 0)",
			EnvVars: []string{"KAFKA_TOPIC_NUM_PARTITIONS"},
			Value:   1,
		},
		&cli.IntFlag{
			Name:    "kafka-dlq-topic-num-partitions",
			Usage:   "The number of partitions to use for the Kafka DLQ topic (must be greater than 0)",
			EnvVars: []string{"KAFKA_DLQ_TOPIC_NUM_PARTITIONS"},
			Value:   1,
		},
		&cli.IntFlag{
			Name:    "kafka-topic-replication-factor",
			Usage:   "The replication factor to use for the Kafka topic (must be greater than 0)",
			EnvVars: []string{"KAFKA_TOPIC_REPLICATION_FACTOR"},
			Value:   1,
		},
		&cli.IntFlag{
			Name:    "kafka-dlq-topic-replication-factor",
			Usage:   "The replication factor to use for the Kafka DLQ topic (must be greater than 0)",
			EnvVars: []string{"KAFKA_DLQ_TOPIC_REPLICATION_FACTOR"},
			Value:   1,
		},
		&cli.StringFlag{
			Name:    "kafka-topic-retention-ms",
			Usage:   "Retention time in milliseconds for the Kafka topic (e.g., 604800000 for 7 days, -1 for infinite)",
			EnvVars: []string{"KAFKA_TOPIC_RETENTION_MS"},
			Value:   "604800000", // 7 days
		},
		&cli.StringFlag{
			Name:    "kafka-topic-retention-bytes",
			Usage:   "Retention size in bytes for the Kafka topic (e.g., 161061273600 for 150GB, -1 for infinite)",
			EnvVars: []string{"KAFKA_TOPIC_RETENTION_BYTES"},
			Value:   "161061273600", // 150GB
		},
		&cli.StringFlag{
			Name:    "kafka-dlq-topic-retention-ms",
			Usage:   "Retention time in milliseconds for the Kafka DLQ topic (e.g., 604800000 for 7 days, -1 for infinite)",
			EnvVars: []string{"KAFKA_DLQ_TOPIC_RETENTION_MS"},
			Value:   "604800000", // 7 days
		},
		&cli.StringFlag{
			Name:    "kafka-dlq-topic-retention-bytes",
			Usage:   "Retention size in bytes for the Kafka DLQ topic (e.g., 161061273600 for 150GB, -1 for infinite)",
			EnvVars: []string{"KAFKA_DLQ_TOPIC_RETENTION_BYTES"},
			Value:   "161061273600", // 150GB
		},
		&cli.StringFlag{
			Name:    "kafka-topic-message-max-bytes",
			Usage:   "Maximum message size in bytes for Kafka topics (e.g., 20971521 for ~20MB). Applied to both main and DLQ topics. If not set, uses broker default.",
			EnvVars: []string{"KAFKA_TOPIC_MESSAGE_MAX_BYTES"},
		},
		&cli.StringFlag{
			Name:    "kafka-sasl-username",
			Usage:   "SASL username for Kafka authentication",
			EnvVars: []string{"KAFKA_SASL_USERNAME"},
		},
		&cli.StringFlag{
			Name:    "kafka-sasl-password",
			Usage:   "SASL password for Kafka authentication",
			EnvVars: []string{"KAFKA_SASL_PASSWORD"},
		},
		&cli.StringFlag{
			Name:    "kafka-sasl-mechanism",
			Usage:   "SASL mechanism (SCRAM-SHA-256, SCRAM-SHA-512, or PLAIN)",
			EnvVars: []string{"KAFKA_SASL_MECHANISM"},
			Value:   "SCRAM-SHA-512",
		},
		&cli.StringFlag{
			Name:    "kafka-security-protocol",
			Usage:   "Security protocol (SASL_SSL or SASL_PLAINTEXT)",
			EnvVars: []string{"KAFKA_SECURITY_PROTOCOL"},
			Value:   "SASL_SSL",
		},
		&cli.BoolFlag{
			Name:    "publish-to-dlq",
			Usage:   "Publish failed messages to DLQ",
			EnvVars: []string{"KAFKA_PUBLISH_TO_DLQ"},
			Value:   false,
		},
		// Consumer retry policy flags
		&cli.IntFlag{
			Name:    "consumer-retry-max-retries",
			Usage:   "Max retry attempts for failed message processing (-1 = infinite, 0 = disabled)",
			EnvVars: []string{"CONSUMER_RETRY_MAX_RETRIES"},
			Value:   3,
		},
		&cli.DurationFlag{
			Name:    "consumer-retry-base-delay",
			Usage:   "Initial backoff delay between retries",
			EnvVars: []string{"CONSUMER_RETRY_BASE_DELAY"},
			Value:   kafka.DefaultRetryBaseDelay,
		},
		&cli.DurationFlag{
			Name:    "consumer-retry-max-delay",
			Usage:   "Maximum backoff delay between retries",
			EnvVars: []string{"CONSUMER_RETRY_MAX_DELAY"},
			Value:   kafka.DefaultRetryMaxDelay,
		},
		// DLQ consumer flags
		&cli.BoolFlag{
			Name:    "enable-dlq-consumer",
			Usage:   "Enable a secondary consumer that reprocesses messages from the DLQ topic",
			EnvVars: []string{"ENABLE_DLQ_CONSUMER"},
			Value:   false,
		},
		&cli.StringFlag{
			Name:    "dlq-consumer-group-id",
			Usage:   "Kafka consumer group ID for the DLQ consumer",
			EnvVars: []string{"KAFKA_DLQ_CONSUMER_GROUP_ID"},
		},
		&cli.Int64Flag{
			Name:    "dlq-consumer-concurrency",
			Usage:   "Concurrent message processors for the DLQ consumer (keep low; DLQ retries indefinitely)",
			EnvVars: []string{"KAFKA_DLQ_CONSUMER_CONCURRENCY"},
			Value:   1,
		},
		&cli.DurationFlag{
			Name:    "dlq-consumer-offset-commit-interval",
			Usage:   "Interval for committing offsets in the DLQ consumer",
			EnvVars: []string{"KAFKA_DLQ_CONSUMER_OFFSET_COMMIT_INTERVAL"},
			Value:   10 * time.Second,
		},
		&cli.DurationFlag{
			Name:    "dlq-consumer-session-timeout",
			Usage:   "Kafka session timeout for the DLQ consumer",
			EnvVars: []string{"KAFKA_DLQ_CONSUMER_SESSION_TIMEOUT"},
			Value:   240 * time.Second,
		},
		&cli.DurationFlag{
			Name:    "dlq-consumer-max-poll-interval",
			Usage:   "Kafka max poll interval for the internal DLQ confluent kafka consumer",
			EnvVars: []string{"KAFKA_DLQ_CONSUMER_MAX_POLL_INTERVAL"},
			Value:   3400 * time.Second,
		},
		&cli.DurationFlag{
			Name:    "dlq-consumer-goroutine-wait-timeout",
			Usage:   "Timeout for waiting in-flight goroutines on shutdown for the DLQ consumer",
			EnvVars: []string{"KAFKA_DLQ_CONSUMER_GOROUTINE_WAIT_TIMEOUT"},
			Value:   30 * time.Second,
		},
		&cli.DurationFlag{
			Name:    "dlq-consumer-poll-interval",
			Usage:   "Poll interval for the DLQ Kafka consumer",
			EnvVars: []string{"KAFKA_DLQ_CONSUMER_POLL_INTERVAL"},
			Value:   100 * time.Millisecond,
		},
		&cli.DurationFlag{
			Name:    "dlq-consumer-retry-base-delay",
			Usage:   "Initial backoff delay between retries for the DLQ consumer",
			EnvVars: []string{"DLQ_CONSUMER_RETRY_BASE_DELAY"},
			Value:   1 * time.Second,
		},
		&cli.DurationFlag{
			Name:    "dlq-consumer-retry-max-delay",
			Usage:   "Maximum backoff delay between retries for the DLQ consumer",
			EnvVars: []string{"DLQ_CONSUMER_RETRY_MAX_DELAY"},
			Value:   5 * time.Minute,
		},
		// ClickHouse configuration flags
		&cli.StringSliceFlag{
			Name:    "clickhouse-hosts",
			Usage:   "ClickHouse server hosts (comma-separated)",
			EnvVars: []string{"CLICKHOUSE_HOSTS"},
			Value:   cli.NewStringSlice("localhost:9000"),
		},
		&cli.StringFlag{
			Name:    "clickhouse-cluster",
			Usage:   "ClickHouse cluster name",
			EnvVars: []string{"CLICKHOUSE_CLUSTER"},
			Value:   "default",
		},
		&cli.StringFlag{
			Name:    "clickhouse-database",
			Usage:   "ClickHouse database name",
			EnvVars: []string{"CLICKHOUSE_DATABASE"},
			Value:   "default",
		},
		&cli.StringFlag{
			Name:    "clickhouse-username",
			Usage:   "ClickHouse username",
			EnvVars: []string{"CLICKHOUSE_USERNAME"},
			Value:   "default",
		},
		&cli.StringFlag{
			Name:    "clickhouse-password",
			Usage:   "ClickHouse password",
			EnvVars: []string{"CLICKHOUSE_PASSWORD"},
			Value:   "",
		},
		&cli.BoolFlag{
			Name:    "clickhouse-debug",
			Usage:   "Enable ClickHouse debug logging",
			EnvVars: []string{"CLICKHOUSE_DEBUG"},
		},
		&cli.BoolFlag{
			Name:    "clickhouse-insecure-skip-verify",
			Usage:   "Skip TLS certificate verification for ClickHouse",
			EnvVars: []string{"CLICKHOUSE_INSECURE_SKIP_VERIFY"},
			Value:   true,
		},
		&cli.IntFlag{
			Name:    "clickhouse-max-execution-time",
			Usage:   "ClickHouse max execution time in seconds",
			EnvVars: []string{"CLICKHOUSE_MAX_EXECUTION_TIME"},
			Value:   60,
		},
		&cli.IntFlag{
			Name:    "clickhouse-dial-timeout",
			Usage:   "ClickHouse dial timeout in seconds",
			EnvVars: []string{"CLICKHOUSE_DIAL_TIMEOUT"},
			Value:   30,
		},
		&cli.IntFlag{
			Name:    "clickhouse-max-open-conns",
			Usage:   "ClickHouse maximum open connections",
			EnvVars: []string{"CLICKHOUSE_MAX_OPEN_CONNS"},
			Value:   5,
		},
		&cli.IntFlag{
			Name:    "clickhouse-max-idle-conns",
			Usage:   "ClickHouse maximum idle connections",
			EnvVars: []string{"CLICKHOUSE_MAX_IDLE_CONNS"},
			Value:   5,
		},
		&cli.IntFlag{
			Name:    "clickhouse-conn-max-lifetime",
			Usage:   "ClickHouse connection max lifetime in minutes",
			EnvVars: []string{"CLICKHOUSE_CONN_MAX_LIFETIME"},
			Value:   10,
		},
		&cli.IntFlag{
			Name:    "clickhouse-block-buffer-size",
			Usage:   "ClickHouse block buffer size",
			EnvVars: []string{"CLICKHOUSE_BLOCK_BUFFER_SIZE"},
			Value:   10,
		},
		&cli.IntFlag{
			Name:    "clickhouse-max-block-size",
			Usage:   "ClickHouse max block size (recommended maximum number of rows in a single block)",
			EnvVars: []string{"CLICKHOUSE_MAX_BLOCK_SIZE"},
			Value:   1000,
		},
		&cli.IntFlag{
			Name:    "clickhouse-max-compression-buffer",
			Usage:   "ClickHouse max compression buffer in bytes",
			EnvVars: []string{"CLICKHOUSE_MAX_COMPRESSION_BUFFER"},
			Value:   10240,
		},
		&cli.StringFlag{
			Name:    "clickhouse-client-name",
			Usage:   "ClickHouse client name for ClientInfo",
			EnvVars: []string{"CLICKHOUSE_CLIENT_NAME"},
			Value:   "ac-client-name",
		},
		&cli.StringFlag{
			Name:    "clickhouse-client-version",
			Usage:   "ClickHouse client version for ClientInfo",
			EnvVars: []string{"CLICKHOUSE_CLIENT_VERSION"},
			Value:   "1.0",
		},
		&cli.BoolFlag{
			Name:    "clickhouse-use-http",
			Usage:   "Use HTTP protocol instead of native protocol",
			EnvVars: []string{"CLICKHOUSE_USE_HTTP"},
			Value:   false,
		},
		&cli.StringFlag{
			Name:    "raw-blocks-table-name",
			Usage:   "ClickHouse table name for raw blocks",
			EnvVars: []string{"CLICKHOUSE_RAW_BLOCKS_TABLE_NAME"},
			Value:   clickhouse.DefaultRawBlocksTableName,
		},
		&cli.StringFlag{
			Name:    "raw-transactions-table-name",
			Usage:   "ClickHouse table name for raw transactions",
			EnvVars: []string{"CLICKHOUSE_RAW_TRANSACTIONS_TABLE_NAME"},
			Value:   clickhouse.DefaultRawTransactionsTableName,
		},
		&cli.StringFlag{
			Name:    "raw-logs-table-name",
			Usage:   "ClickHouse table name for raw logs",
			EnvVars: []string{"CLICKHOUSE_RAW_LOGS_TABLE_NAME"},
			Value:   clickhouse.DefaultRawLogsTableName,
		},
		&cli.StringFlag{
			Name:    "internal-transactions-table-name",
			Usage:   "ClickHouse table name for internal transactions",
			EnvVars: []string{"CLICKHOUSE_INTERNAL_TRANSACTIONS_TABLE_NAME"},
			Value:   "internal_transactions",
		},
		// Metrics configuration flags
		&cli.StringFlag{
			Name:    "metrics-host",
			Usage:   "Host for Prometheus metrics server (empty for all interfaces)",
			EnvVars: []string{"METRICS_HOST"},
			Value:   "",
		},
		&cli.IntFlag{
			Name:    "metrics-port",
			Aliases: []string{"m"},
			Usage:   "Port for Prometheus metrics server",
			EnvVars: []string{"METRICS_PORT"},
			Value:   9090,
		},
		&cli.Uint64Flag{
			Name:    "chain-id",
			Aliases: []string{"C"},
			Usage:   "EVM chain ID for metrics labels (e.g., 43114 for C-Chain mainnet)",
			EnvVars: []string{"CHAIN_ID"},
			Value:   0,
		},
		&cli.StringFlag{
			Name:    "environment",
			Aliases: []string{"E"},
			Usage:   "Deployment environment for metrics labels (e.g., 'production', 'staging')",
			EnvVars: []string{"ENVIRONMENT"},
			Value:   "",
		},
		&cli.StringFlag{
			Name:    "region",
			Aliases: []string{"R"},
			Usage:   "Cloud region for metrics labels (e.g., 'us-east-1')",
			EnvVars: []string{"REGION"},
			Value:   "",
		},
		&cli.StringFlag{
			Name:    "cloud-provider",
			Aliases: []string{"P"},
			Usage:   "Cloud provider for metrics labels (e.g., 'aws', 'oci', 'gcp')",
			EnvVars: []string{"CLOUD_PROVIDER"},
			Value:   "",
		},
		&cli.BoolFlag{
			Name:    "enable-clickhouse-batch-writes",
			Usage:   "Enable ClickHouse batch writes",
			EnvVars: []string{"ENABLE_CLICKHOUSE_BATCH_WRITES"},
			Value:   false,
		},
		// Batch writer service flags
		&cli.IntFlag{
			Name:    "batch-writer-workers",
			Usage:   "Maximum number of concurrent goroutines the batch writer uses to flush batches to ClickHouse",
			EnvVars: []string{"BATCH_WRITER_WORKERS"},
			Value:   3,
		},
		&cli.IntFlag{
			Name:    "batch-writer-max-blocks",
			Usage:   "Maximum number of blocks the batch writer dispatcher accumulates before triggering a flush",
			EnvVars: []string{"BATCH_WRITER_MAX_BLOCKS"},
			Value:   1000,
		},
		&cli.DurationFlag{
			Name:    "batch-writer-flush-timeout",
			Usage:   "Maximum time the batch writer dispatcher waits before flushing an incomplete batch",
			EnvVars: []string{"BATCH_WRITER_FLUSH_TIMEOUT"},
			Value:   120 * time.Second,
		},
		// ICM / Teleporter configuration flags
		&cli.StringSliceFlag{
			Name:    "teleporter-contract-addresses",
			Usage:   "Teleporter contract addresses to watch (repeated or comma-separated). Required when mode=icm.",
			EnvVars: []string{"TELEPORTER_CONTRACT_ADDRESSES"},
		},
		&cli.StringFlag{
			Name:    "icm-messages-table-name",
			Usage:   "ClickHouse table name for the ICM messages summary",
			EnvVars: []string{"ICM_MESSAGES_TABLE_NAME"},
			Value:   "icm_messages",
		},
		&cli.StringFlag{
			Name:    "icm-send-events-table-name",
			Usage:   "ClickHouse table name for ICM send events",
			EnvVars: []string{"ICM_SEND_EVENTS_TABLE_NAME"},
			Value:   "icm_send_events",
		},
		&cli.StringFlag{
			Name:    "icm-receive-events-table-name",
			Usage:   "ClickHouse table name for ICM receive events",
			EnvVars: []string{"ICM_RECEIVE_EVENTS_TABLE_NAME"},
			Value:   "icm_receive_events",
		},
		&cli.StringFlag{
			Name:    "icm-message-executed-events-table-name",
			Usage:   "ClickHouse table name for ICM message executed events",
			EnvVars: []string{"ICM_MESSAGE_EXECUTED_EVENTS_TABLE_NAME"},
			Value:   "icm_message_executed_events",
		},
		&cli.StringFlag{
			Name:    "icm-message-execution-failed-events-table-name",
			Usage:   "ClickHouse table name for ICM message execution failed events",
			EnvVars: []string{"ICM_MESSAGE_EXECUTION_FAILED_EVENTS_TABLE_NAME"},
			Value:   "icm_message_execution_failed_events",
		},
		&cli.StringFlag{
			Name:    "icm-receipts-events-table-name",
			Usage:   "ClickHouse table name for ICM receipt received events",
			EnvVars: []string{"ICM_RECEIPTS_EVENTS_TABLE_NAME"},
			Value:   "icm_receipts_events",
		},
		&cli.StringFlag{
			Name:    "icm-fee-info-events-table-name",
			Usage:   "ClickHouse table name for ICM fee info events",
			EnvVars: []string{"ICM_FEE_INFO_EVENTS_TABLE_NAME"},
			Value:   "icm_fee_info_events",
		},
		&cli.StringFlag{
			Name:    "icm-fee-redemptions-events-table-name",
			Usage:   "ClickHouse table name for ICM fee redemptions events",
			EnvVars: []string{"ICM_FEE_REDEMPTIONS_EVENTS_TABLE_NAME"},
			Value:   "icm_fee_redemptions_events",
		},
	}
}

// removeFlags returns all CLI removeFlags for the consumerindexer remove command
func removeFlags() []cli.Flag {
	return []cli.Flag{
		&cli.Uint64Flag{
			Name:     "evm-chain-id",
			Aliases:  []string{"C"},
			Usage:    "The EVM chain ID of the blockchain resources being removed",
			EnvVars:  []string{"EVM_CHAIN_ID"},
			Required: true,
		},
		&cli.StringSliceFlag{
			Name:    "clickhouse-hosts",
			Usage:   "ClickHouse server hosts (comma-separated)",
			EnvVars: []string{"CLICKHOUSE_HOSTS"},
			Value:   cli.NewStringSlice("localhost:9000"),
		},
		&cli.StringFlag{
			Name:    "clickhouse-cluster",
			Usage:   "ClickHouse cluster name",
			EnvVars: []string{"CLICKHOUSE_CLUSTER"},
			Value:   "default",
		},
		&cli.StringFlag{
			Name:    "clickhouse-database",
			Usage:   "ClickHouse database name",
			EnvVars: []string{"CLICKHOUSE_DATABASE"},
			Value:   "default",
		},
		&cli.StringFlag{
			Name:    "clickhouse-username",
			Usage:   "ClickHouse username",
			EnvVars: []string{"CLICKHOUSE_USERNAME"},
			Value:   "default",
		},
		&cli.StringFlag{
			Name:    "clickhouse-password",
			Usage:   "ClickHouse password",
			EnvVars: []string{"CLICKHOUSE_PASSWORD"},
			Value:   "",
		},
		&cli.BoolFlag{
			Name:    "clickhouse-debug",
			Usage:   "Enable ClickHouse debug logging",
			EnvVars: []string{"CLICKHOUSE_DEBUG"},
		},
		&cli.BoolFlag{
			Name:    "clickhouse-insecure-skip-verify",
			Usage:   "Skip TLS certificate verification for ClickHouse",
			EnvVars: []string{"CLICKHOUSE_INSECURE_SKIP_VERIFY"},
			Value:   true,
		},
		&cli.IntFlag{
			Name:    "clickhouse-max-execution-time",
			Usage:   "ClickHouse max execution time in seconds",
			EnvVars: []string{"CLICKHOUSE_MAX_EXECUTION_TIME"},
			Value:   60,
		},
		&cli.IntFlag{
			Name:    "clickhouse-dial-timeout",
			Usage:   "ClickHouse dial timeout in seconds",
			EnvVars: []string{"CLICKHOUSE_DIAL_TIMEOUT"},
			Value:   30,
		},
		&cli.IntFlag{
			Name:    "clickhouse-max-open-conns",
			Usage:   "ClickHouse maximum open connections",
			EnvVars: []string{"CLICKHOUSE_MAX_OPEN_CONNS"},
			Value:   5,
		},
		&cli.IntFlag{
			Name:    "clickhouse-max-idle-conns",
			Usage:   "ClickHouse maximum idle connections",
			EnvVars: []string{"CLICKHOUSE_MAX_IDLE_CONNS"},
			Value:   5,
		},
		&cli.IntFlag{
			Name:    "clickhouse-conn-max-lifetime",
			Usage:   "ClickHouse connection max lifetime in minutes",
			EnvVars: []string{"CLICKHOUSE_CONN_MAX_LIFETIME"},
			Value:   10,
		},
		&cli.IntFlag{
			Name:    "clickhouse-block-buffer-size",
			Usage:   "ClickHouse block buffer size",
			EnvVars: []string{"CLICKHOUSE_BLOCK_BUFFER_SIZE"},
			Value:   10,
		},
		&cli.IntFlag{
			Name:    "clickhouse-max-block-size",
			Usage:   "ClickHouse max block size (recommended maximum number of rows in a single block)",
			EnvVars: []string{"CLICKHOUSE_MAX_BLOCK_SIZE"},
			Value:   1000,
		},
		&cli.IntFlag{
			Name:    "clickhouse-max-compression-buffer",
			Usage:   "ClickHouse max compression buffer in bytes",
			EnvVars: []string{"CLICKHOUSE_MAX_COMPRESSION_BUFFER"},
			Value:   10240,
		},
		&cli.StringFlag{
			Name:    "clickhouse-client-name",
			Usage:   "ClickHouse client name for ClientInfo",
			EnvVars: []string{"CLICKHOUSE_CLIENT_NAME"},
			Value:   "ac-client-name",
		},
		&cli.StringFlag{
			Name:    "clickhouse-client-version",
			Usage:   "ClickHouse client version for ClientInfo",
			EnvVars: []string{"CLICKHOUSE_CLIENT_VERSION"},
			Value:   "1.0",
		},
		&cli.BoolFlag{
			Name:    "clickhouse-use-http",
			Usage:   "Use HTTP protocol instead of native protocol",
			EnvVars: []string{"CLICKHOUSE_USE_HTTP"},
			Value:   false,
		},
		&cli.StringFlag{
			Name:    "raw-blocks-table-name",
			Usage:   "ClickHouse table name for raw blocks",
			EnvVars: []string{"CLICKHOUSE_RAW_BLOCKS_TABLE_NAME"},
			Value:   clickhouse.DefaultRawBlocksTableName,
		},
		&cli.StringFlag{
			Name:    "raw-transactions-table-name",
			Usage:   "ClickHouse table name for raw transactions",
			EnvVars: []string{"CLICKHOUSE_RAW_TRANSACTIONS_TABLE_NAME"},
			Value:   clickhouse.DefaultRawTransactionsTableName,
		},
		&cli.StringFlag{
			Name:    "raw-logs-table-name",
			Usage:   "ClickHouse table name for raw logs",
			EnvVars: []string{"CLICKHOUSE_RAW_LOGS_TABLE_NAME"},
			Value:   clickhouse.DefaultRawLogsTableName,
		},
		&cli.StringFlag{
			Name:    "internal-transactions-table-name",
			Usage:   "ClickHouse table name for internal transactions",
			EnvVars: []string{"CLICKHOUSE_INTERNAL_TRANSACTIONS_TABLE_NAME"},
			Value:   "internal_transactions",
		},
		&cli.StringFlag{
			Name:    "icm-send-events-table-name",
			Usage:   "ClickHouse table name for ICM send events",
			EnvVars: []string{"ICM_SEND_EVENTS_TABLE_NAME"},
			Value:   "icm_send_events",
		},
		&cli.StringFlag{
			Name:    "icm-receive-events-table-name",
			Usage:   "ClickHouse table name for ICM receive events",
			EnvVars: []string{"ICM_RECEIVE_EVENTS_TABLE_NAME"},
			Value:   "icm_receive_events",
		},
		&cli.StringFlag{
			Name:    "icm-message-executed-events-table-name",
			Usage:   "ClickHouse table name for ICM message executed events",
			EnvVars: []string{"ICM_MESSAGE_EXECUTED_EVENTS_TABLE_NAME"},
			Value:   "icm_message_executed_events",
		},
		&cli.StringFlag{
			Name:    "icm-message-execution-failed-events-table-name",
			Usage:   "ClickHouse table name for ICM message execution failed events",
			EnvVars: []string{"ICM_MESSAGE_EXECUTION_FAILED_EVENTS_TABLE_NAME"},
			Value:   "icm_message_execution_failed_events",
		},
		&cli.StringFlag{
			Name:    "icm-receipts-events-table-name",
			Usage:   "ClickHouse table name for ICM receipt received events",
			EnvVars: []string{"ICM_RECEIPTS_EVENTS_TABLE_NAME"},
			Value:   "icm_receipts_events",
		},
		&cli.StringFlag{
			Name:    "icm-fee-info-events-table-name",
			Usage:   "ClickHouse table name for ICM fee info events",
			EnvVars: []string{"ICM_FEE_INFO_EVENTS_TABLE_NAME"},
			Value:   "icm_fee_info_events",
		},
		&cli.StringFlag{
			Name:    "icm-fee-redemptions-events-table-name",
			Usage:   "ClickHouse table name for ICM fee redemptions events",
			EnvVars: []string{"ICM_FEE_REDEMPTIONS_EVENTS_TABLE_NAME"},
			Value:   "icm_fee_redemptions_events",
		},
	}
}
