//go:build e2e

package e2e

import (
	"context"
	"fmt"
	"os"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
	"go.uber.org/zap"

	"github.com/ava-labs/avalanche-indexer/pkg/checkpointer"
	"github.com/ava-labs/avalanche-indexer/pkg/clickhouse"
	chcheckpoint "github.com/ava-labs/avalanche-indexer/pkg/data/clickhouse/checkpoint"
	ddbcheckpoint "github.com/ava-labs/avalanche-indexer/pkg/data/dynamodb/checkpoint"
	"github.com/ava-labs/avalanche-indexer/pkg/dynamodb"
	"github.com/ava-labs/avalanche-indexer/pkg/utils"
)

var clickhouseTestConfig = clickhouse.Config{
	Hosts:                []string{"localhost:9000"},
	Cluster:              "default",
	Database:             "default",
	Username:             "default",
	Password:             "",
	Debug:                false,
	InsecureSkipVerify:   true,
	MaxExecutionTime:     60,
	DialTimeout:          30,
	MaxOpenConns:         5,
	MaxIdleConns:         5,
	ConnMaxLifetime:      10,
	BlockBufferSize:      10,
	MaxBlockSize:         1000,
	MaxCompressionBuffer: 10240,
	ClientName:           "avalanche-indexer-e2e",
	ClientVersion:        "1.0",
	UseHTTP:              false,
}

var dynamoDBTestConfig = dynamodb.Config{
	Region:          "us-west-2",
	AccessKeyID:     "test",
	SecretAccessKey: "test",
	EndpointURL:     "http://localhost:4566",
}

// verifyCheckpointFromMaxProcessed finds the max processed height and checks checkpoint lowest==max+1.
func verifyCheckpointFromMaxProcessed(t *testing.T, ctx context.Context, repo checkpointer.Checkpointer, chainID uint64, kafkaByNumber map[uint64][]byte) {
	t.Helper()
	if len(kafkaByNumber) == 0 {
		return
	}
	var max uint64
	for n := range kafkaByNumber {
		if n > max {
			max = n
		}
	}
	verifyCheckpointLowestCorrect(t, ctx, repo, chainID, max+1)
}

// verifyCheckpointLowestCorrect polls ClickHouse checkpoint for the chain until lowest>=expected or timeout.
func verifyCheckpointLowestCorrect(t *testing.T, ctx context.Context, repo checkpointer.Checkpointer, chainID uint64, expected uint64) {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	for {
		lowest, exists, err := repo.Read(ctx, chainID, "blocks")
		if err == nil && exists && lowest >= expected {
			return
		}
		if time.Now().After(deadline) {
			require.NoError(t, err, "read checkpoint failed")
			require.True(t, exists, "checkpoint doesn't exist")
			require.GreaterOrEqual(t, lowest, expected, "checkpoint lowest mismatch")
			return
		}
		time.Sleep(200 * time.Millisecond)
	}
}

func getEnvStr(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}

func getEnvUint64(key string, def uint64) uint64 {
	if v := os.Getenv(key); v != "" {
		var out uint64
		_, _ = fmt.Sscanf(v, "%d", &out)
		if out != 0 {
			return out
		}
	}
	return def
}

func queryCount(t *testing.T, ctx context.Context, ch clickhouse.Client, query string, args ...interface{}) uint64 {
	t.Helper()
	conn := ch.Conn()
	var cnt uint64
	require.NoError(t, conn.QueryRow(ctx, query, args...).Scan(&cnt))
	return cnt
}

func queryFixedString(t *testing.T, ctx context.Context, ch clickhouse.Client, query string, args ...interface{}) string {
	t.Helper()
	conn := ch.Conn()
	var s string
	require.NoError(t, conn.QueryRow(ctx, query, args...).Scan(&s))
	return s
}

func queryString(t *testing.T, ctx context.Context, ch clickhouse.Client, query string, args ...interface{}) string {
	t.Helper()
	conn := ch.Conn()
	var s string
	require.NoError(t, conn.QueryRow(ctx, query, args...).Scan(&s))
	return s
}

func mustHexToFixed32(t *testing.T, hex string) string {
	t.Helper()
	b, err := utils.HexToBytes32(hex)
	require.NoError(t, err)
	return string(b[:])
}

func createCheckpointerAndLoggerDynamoDB(t *testing.T) (checkpointer.Checkpointer, *zap.SugaredLogger) {
	log, err := utils.NewSugaredLogger(true)
	require.NoError(t, err)
	defer log.Desugar().Sync() //nolint:errcheck

	ddbClient, err := dynamodb.New(dynamoDBTestConfig)
	require.NoError(t, err, "dynamodb connection failed (is docker-compose up?)")

	chkpt, err := ddbcheckpoint.NewRepository(ddbClient, "checkpoints", log)
	require.NoError(t, err, "failed to create checkpoint repository")

	return chkpt, log
}

func createCheckpointerAndLoggerClickHouse(t *testing.T) (checkpointer.Checkpointer, *zap.SugaredLogger) {
	log, err := utils.NewSugaredLogger(true)
	require.NoError(t, err)
	defer log.Desugar().Sync() //nolint:errcheck

	chClient, err := clickhouse.New(clickhouseTestConfig, log)
	require.NoError(t, err, "clickhouse connection failed (is docker-compose up?)")

	chkpt, err := chcheckpoint.NewRepository(chClient, clickhouseTestConfig.Cluster, clickhouseTestConfig.Database, "checkpoints")
	require.NoError(t, err, "failed to create checkpoint repository")

	return chkpt, log
}
