//go:build e2e

package e2e

import (
	"context"
	"encoding/json"
	"fmt"
	"math/big"
	"testing"
	"time"

	ckafka "github.com/confluentinc/confluent-kafka-go/v2/kafka"
	"go.uber.org/zap"
	"golang.org/x/sync/errgroup"

	"github.com/ava-labs/avalanche-indexer/pkg/checkpointer"
	stream "github.com/ava-labs/avalanche-indexer/pkg/kafka"
	kafkamsg "github.com/ava-labs/avalanche-indexer/pkg/kafka/messages"
	"github.com/ava-labs/avalanche-indexer/pkg/slidingwindow"
	"github.com/ava-labs/avalanche-indexer/pkg/slidingwindow/subscriber"
	"github.com/ava-labs/avalanche-indexer/pkg/slidingwindow/worker"

	"github.com/ava-labs/coreth/plugin/evm/customethclient"
	"github.com/ava-labs/coreth/rpc"
	"github.com/stretchr/testify/require"
)

// TestE2EBlockfetcherRealTime_ClickHouse validates that blockfetcher ingests realtime blocks
// using verifyBlockfetcherRealTime. It assumes Docker Compose has started Kafka and ClickHouse.
func TestE2EBlockfetcherRealTime_ClickHouse(t *testing.T) {
	chkpt, log := createCheckpointerAndLoggerClickHouse(t)
	verifyBlockfetcherRealTime(t, chkpt, log)
}

// TestE2EBlockfetcherRealTime_DynamoDB validates that blockfetcher ingests realtime block.
// using verifyBlockfetcherRealTime. It assumes Docker Compose has started Kafka and DynamoDB.
func TestE2EBlockfetcherRealTime_DynamoDB(t *testing.T) {
	chkpt, log := createCheckpointerAndLoggerDynamoDB(t)
	verifyBlockfetcherRealTime(t, chkpt, log)
}

// verifyBlockfetcherRealTime validates that blockfetcher ingests realtime blocks
// by producing them to Kafka.
func verifyBlockfetcherRealTime(t *testing.T, chkpt checkpointer.Checkpointer, log *zap.SugaredLogger) {
	// ---- Config (can be overridden via env to match local setup) ----
	evmChainID := uint64(getEnvUint64("CHAIN_ID", 43113)) // Fuji testnet
	bcID := getEnvStr("BC_ID", "11111111111111111111111111111111LpoYY")
	rpcURL := getEnvStr("RPC_URL", "wss://api.avax-test.network/ext/bc/C/ws")
	kafkaBrokers := getEnvStr("KAFKA_BROKERS", "localhost:9092")
	kafkaTopic := getEnvStr("KAFKA_TOPIC", "blocks_realtime")
	kafkaClientID := getEnvStr("KAFKA_CLIENT_ID", "blockfetcher-e2e")
	concurrency := int64(3)
	backfill := int64(1)
	blocksCap := 100
	maxFailures := 10
	// Keep interval short to validate checkpoint writes if desired (not asserted).
	checkpointInterval := 2 * time.Second

	// ---- Test context ----
	ctx, cancel := context.WithTimeout(context.Background(), 120*time.Second)
	defer cancel()

	// Get latest block height from RPC to seed checkpoint.
	rpcClient, err := rpc.DialContext(ctx, rpcURL)
	require.NoError(t, err, "rpc dial failed (check RPC_URL)")
	defer rpcClient.Close()
	latest, err := customethclient.New(rpcClient).BlockNumber(ctx)
	require.NoError(t, err, "failed to get latest block height")

	// Start from a slightly older block to avoid "cannot query unfinalized data" errors.
	// RPC nodes may not have the absolute latest block finalized yet.
	const safetyMargin = 5
	startHeight := latest
	if latest > safetyMargin {
		startHeight = latest - safetyMargin
	}

	err = chkpt.Write(ctx, evmChainID, "blocks", startHeight)
	require.NoError(t, err, "failed to seed checkpoint row")

	// ---- Kafka consumer to observe realtime blocks ----
	consumer, err := ckafka.NewConsumer(&ckafka.ConfigMap{
		"bootstrap.servers": kafkaBrokers,
		"group.id":          fmt.Sprintf("e2e-blockfetcher-%d", time.Now().UnixNano()),
		"auto.offset.reset": "earliest",
	})
	require.NoError(t, err)
	defer consumer.Close()
	require.NoError(t, consumer.Subscribe(kafkaTopic, nil))

	// ---- Start blockfetcher components (producer, worker, manager, subscriber, scheduler) ----
	kCfg := &ckafka.ConfigMap{
		"bootstrap.servers":      kafkaBrokers,
		"client.id":              kafkaClientID,
		"acks":                   "all",
		"linger.ms":              5,
		"batch.size":             16384,
		"compression.type":       "lz4",
		"enable.idempotence":     true,
		"go.logs.channel.enable": false,
	}
	producer, err := stream.NewProducer(ctx, kCfg, log)
	require.NoError(t, err)
	defer producer.Close(15 * time.Second)

	client, err := customethclient.DialContext(ctx, rpcURL)
	if err != nil {
		require.Fail(t, "failed to dial rpc", err)
	}
	defer client.Close()

	w, err := worker.NewCorethWorker(client, producer, kafkaTopic, evmChainID, bcID, log, nil, 10*time.Second)
	require.NoError(t, err)

	state, err := slidingwindow.NewState(startHeight, latest)
	require.NoError(t, err)
	mgr, err := slidingwindow.NewManager(log, state, w, concurrency, backfill, blocksCap, maxFailures, nil)
	require.NoError(t, err)

	sub := subscriber.NewCoreth(log, customethclient.New(rpcClient))

	g, gctx := errgroup.WithContext(ctx)
	g.Go(func() error { return sub.Subscribe(gctx, blocksCap, mgr) })
	g.Go(func() error { return mgr.Run(gctx) })
	g.Go(func() error {
		select {
		case <-gctx.Done():
			return gctx.Err()
		case err := <-producer.Errors():
			return err
		}
	})
	g.Go(func() error {
		cfg := checkpointer.DefaultConfig()
		cfg.Interval = checkpointInterval
		return checkpointer.Start(gctx, state, chkpt, cfg, evmChainID, "blocks")
	})

	minMsgs := 5
	received := 0
	kafkaByNumber := make(map[uint64][]byte)
	var receivedOrder []uint64
	for received < minMsgs {
		ev := consumer.Poll(2000)
		if ev == nil {
			if gctx.Err() != nil {
				break
			}
			continue
		}
		switch e := ev.(type) {
		case *ckafka.Message:
			// Parse block number from message key (decimal string)
			var n uint64
			if len(e.Key) > 0 {
				_, _ = fmt.Sscanf(string(e.Key), "%d", &n)
			}
			if n != 0 {
				if _, exists := kafkaByNumber[n]; !exists {
					receivedOrder = append(receivedOrder, n)
				}
				kafkaByNumber[n] = e.Value
			}
			received++
		case ckafka.Error:
			// Non-fatal errors can occur; surface fatal/all-brokers-down.
			if e.IsFatal() || e.Code() == ckafka.ErrAllBrokersDown {
				require.NoError(t, e, "fatal kafka error")
			}
		default:
			// ignore other events
		}
		if gctx.Err() != nil {
			break
		}
	}

	// Wait for at least one checkpoint interval to ensure scheduler writes updated checkpoint
	// (Scheduler writes every 2 seconds, wait a bit longer to be safe)
	time.Sleep(2500 * time.Millisecond)

	// Shutdown gracefully
	cancel()
	_ = g.Wait()

	verifyCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	require.GreaterOrEqual(t, received, minMsgs, "did not receive realtime block(s) from Kafka")

	// Verify Kafka payloads match RPC for the received block numbers (in arrival order).
	verifyBlocksFromRPC(t, verifyCtx, rpcURL, kafkaByNumber, receivedOrder)

	// Verify checkpoint reflects max processed block (+1 for lowest_unprocessed_block).
	verifyCheckpointFromMaxProcessed(t, verifyCtx, chkpt, evmChainID, kafkaByNumber)
}

// TestE2EBlockfetcherBackfill runs backfill over a small recent range and verifies
// produced Kafka blocks match RPC responses using verifyBlocksFromRPC.
func TestE2EBlockfetcherBackfill_ClickHouse(t *testing.T) {
	chkpt, log := createCheckpointerAndLoggerClickHouse(t)
	verifyBlockfetcherBackfill(t, chkpt, log)
}

// TestE2EBlockfetcherBackfill_DynamoDB runs backfill over a small recent range and verifies
// produced Kafka blocks match RPC responses using verifyBlocksFromRPC.
func TestE2EBlockfetcherBackfill_DynamoDB(t *testing.T) {
	chkpt, log := createCheckpointerAndLoggerDynamoDB(t)
	verifyBlockfetcherBackfill(t, chkpt, log)
}

// verifyBlockfetcherBackfill runs backfill over a small recent range and verifies
// produced Kafka blocks match RPC responses using verifyBlocksFromRPC.
func verifyBlockfetcherBackfill(t *testing.T, chkpt checkpointer.Checkpointer, log *zap.SugaredLogger) {
	// ---- Config ----
	evmChainID := uint64(getEnvUint64("CHAIN_ID", 43113)) // Fuji by default
	bcID := getEnvStr("BC_ID", "11111111111111111111111111111111LpoYY")
	rpcURL := getEnvStr("RPC_URL", "wss://api.avax-test.network/ext/bc/C/ws")
	kafkaBrokers := getEnvStr("KAFKA_BROKERS", "localhost:9092")
	kafkaTopic := getEnvStr("KAFKA_TOPIC", "blocks_backfill")
	kafkaClientID := "blockfetcher-e2e-backfill"
	concurrency := int64(4)
	backfill := int64(2)
	blocksCap := 50
	maxFailures := 10
	checkpointInterval := 2 * time.Second

	// ---- Test context ----
	ctx, cancel := context.WithTimeout(context.Background(), 120*time.Second)
	defer cancel()

	// Determine recent range [start..end]
	rpcClient, err := rpc.DialContext(ctx, rpcURL)
	require.NoError(t, err, "rpc dial failed (check RPC_URL)")
	defer rpcClient.Close()
	latest, err := customethclient.New(rpcClient).BlockNumber(ctx)
	require.NoError(t, err, "failed to get latest block height")
	const span uint64 = 6
	var start uint64
	if latest > span {
		start = latest - span
	} else {
		start = 1
	}
	end := latest

	// ---- Kafka consumer to observe backfilled blocks ----
	consumer, err := ckafka.NewConsumer(&ckafka.ConfigMap{
		"bootstrap.servers": kafkaBrokers,
		"group.id":          fmt.Sprintf("e2e-blockfetcher-backfill-%d", time.Now().UnixNano()),
		"auto.offset.reset": "earliest",
	})
	require.NoError(t, err)
	defer consumer.Close()
	require.NoError(t, consumer.Subscribe(kafkaTopic, nil))

	// ---- Start producer/worker/manager (no realtime subscriber) ----
	kCfg := &ckafka.ConfigMap{
		"bootstrap.servers":      kafkaBrokers,
		"client.id":              kafkaClientID,
		"acks":                   "all",
		"linger.ms":              5,
		"batch.size":             16384,
		"compression.type":       "lz4",
		"enable.idempotence":     true,
		"go.logs.channel.enable": false,
	}
	producer, err := stream.NewProducer(ctx, kCfg, log)
	require.NoError(t, err)
	defer producer.Close(15 * time.Second)

	client, err := customethclient.DialContext(ctx, rpcURL)
	if err != nil {
		require.Fail(t, "failed to dial rpc", err)
	}
	defer client.Close()

	w, err := worker.NewCorethWorker(client, producer, kafkaTopic, evmChainID, bcID, log, nil, 10*time.Second)
	require.NoError(t, err)

	state, err := slidingwindow.NewState(start, end)
	require.NoError(t, err)
	mgr, err := slidingwindow.NewManager(log, state, w, concurrency, backfill, blocksCap, maxFailures, nil)
	require.NoError(t, err)

	g, gctx := errgroup.WithContext(ctx)
	g.Go(func() error { return mgr.Run(gctx) })
	g.Go(func() error {
		select {
		case <-gctx.Done():
			return gctx.Err()
		case err := <-producer.Errors():
			return err
		}
	})
	g.Go(func() error {
		cfg := checkpointer.DefaultConfig()
		cfg.Interval = checkpointInterval
		return checkpointer.Start(gctx, state, chkpt, cfg, evmChainID, "blocks")
	})

	// Collect exactly the expected backfill range
	expectedCount := int(end - start + 1)
	kafkaByNumber := make(map[uint64][]byte, expectedCount)
	var numbers []uint64
	for len(kafkaByNumber) < expectedCount {
		ev := consumer.Poll(1000)
		if ev == nil {
			if gctx.Err() != nil {
				break
			}
			continue
		}
		switch e := ev.(type) {
		case *ckafka.Message:
			var n uint64
			if len(e.Key) > 0 {
				_, _ = fmt.Sscanf(string(e.Key), "%d", &n)
			}
			// Only track if within our backfill window
			if n >= start && n <= end {
				if _, ok := kafkaByNumber[n]; !ok {
					numbers = append(numbers, n)
				}
				kafkaByNumber[n] = e.Value
			}
		case ckafka.Error:
			if e.IsFatal() || e.Code() == ckafka.ErrAllBrokersDown {
				require.NoError(t, e, "fatal kafka error")
			}
		default:
			// ignore
		}
		if gctx.Err() != nil {
			break
		}
	}

	// Wait for at least one checkpoint interval to ensure scheduler writes a checkpoint
	// (Scheduler writes every 2 seconds, wait a bit longer to be safe)
	time.Sleep(2500 * time.Millisecond)

	// Shutdown
	cancel()
	_ = g.Wait()

	require.Equal(t, expectedCount, len(kafkaByNumber), "missing backfilled blocks from Kafka")

	verifyCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// Verify messages with RPC
	verifyBlocksFromRPC(t, verifyCtx, rpcURL, kafkaByNumber, numbers)

	// Verify checkpoint reflects max processed block (+1 for lowest_unprocessed_block).
	verifyCheckpointFromMaxProcessed(t, verifyCtx, chkpt, evmChainID, kafkaByNumber)
}

// verifyBlocksFromRPC fetches blocks by number from RPC and compares to Kafka payloads.
func verifyBlocksFromRPC(t *testing.T, ctx context.Context, rpcURL string, kafkaByNumber map[uint64][]byte, numbers []uint64) {
	if len(numbers) == 0 {
		return
	}
	client, err := rpc.DialContext(ctx, rpcURL)
	require.NoError(t, err, "dial rpc for verification")
	defer client.Close()
	ec := customethclient.New(client)

	// Compare only for numbers we have payloads for.
	for _, n := range numbers {
		val, ok := kafkaByNumber[n]
		if !ok {
			continue
		}
		// Decode Kafka payload
		var got kafkamsg.EVMBlock
		require.NoError(t, json.Unmarshal(val, &got), "decode kafka block %d", n)

		// Fetch from RPC and convert to our Block type
		bn := new(big.Int).SetUint64(n)
		lb, err := ec.BlockByNumber(ctx, bn)
		require.NoError(t, err, "fetch rpc block %d", n)

		evmChainID := got.EVMChainID
		blockchainIDStr := got.BlockchainID
		exp, err := kafkamsg.EVMBlockFromLibevmCoreth(lb, evmChainID, blockchainIDStr)
		require.NoError(t, err, "convert rpc block %d", n)

		// Compare a set of critical fields for robustness
		require.Equal(t, exp.EVMChainID, got.EVMChainID, "evmChainID %d", n)
		require.Equal(t, exp.BlockchainID, got.BlockchainID, "blockchainID %d", n)
		require.Equal(t, exp.Hash, got.Hash, "hash %d", n)
		require.Equal(t, exp.ParentHash, got.ParentHash, "parentHash %d", n)
		require.Equal(t, exp.Number.Uint64(), got.Number.Uint64(), "number %d", n)
		require.Equal(t, exp.GasLimit, got.GasLimit, "gasLimit %d", n)
		require.Equal(t, exp.GasUsed, got.GasUsed, "gasUsed %d", n)
		require.Equal(t, exp.StateRoot, got.StateRoot, "stateRoot %d", n)
		require.Equal(t, exp.TransactionsRoot, got.TransactionsRoot, "txRoot %d", n)
		require.Equal(t, exp.ReceiptsRoot, got.ReceiptsRoot, "receiptsRoot %d", n)
		require.Equal(t, exp.TimestampMs, got.TimestampMs, "timestampMs %d", n)
		// Optional fields (presence may vary across forks)
		if exp.BaseFee != nil || got.BaseFee != nil {
			require.NotNil(t, exp.BaseFee, "exp baseFee nil for %d", n)
			require.NotNil(t, got.BaseFee, "got baseFee nil for %d", n)
			require.Equal(t, exp.BaseFee.String(), got.BaseFee.String(), "baseFee %d", n)
		}
	}
}
