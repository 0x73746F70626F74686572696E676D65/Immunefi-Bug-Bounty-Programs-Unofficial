package evmrepo

import (
	"errors"
	"math/big"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/ava-labs/avalanche-indexer/pkg/clickhouse/testutils"
	"github.com/ava-labs/avalanche-indexer/pkg/utils"
)

func TestTransactionsRepository_WriteTransaction_Success(t *testing.T) {
	t.Parallel()
	mockConn := &testutils.MockConn{}
	ctx := t.Context()

	// Create a test transaction
	tx := createTestTransaction()

	// Convert hex strings to binary strings for FixedString fields (matching what WriteTransaction does)
	blockHashBytes, err := utils.HexToBytes32(tx.BlockHash)
	require.NoError(t, err, "blockHash conversion should succeed")
	hashBytes, err := utils.HexToBytes32(tx.Hash)
	require.NoError(t, err, "hash conversion should succeed")
	fromBytes, err := utils.HexToBytes20(tx.From)
	require.NoError(t, err, "fromAddress conversion should succeed")
	var toBytes interface{}
	if tx.To == nil || *tx.To == "" {
		toBytes = nil
	} else {
		toBytesVal, err := utils.HexToBytes20(*tx.To)
		require.NoError(t, err, "toAddress conversion should succeed")
		toBytes = string(toBytesVal[:])
	}

	// Expect CreateTableIfNotExists + migrations during initialization
	expectTableInit(mockConn, "raw_transactions_local", "raw_transactions")

	// Expect WriteTransaction call
	mockConn.
		On("Exec", mock.Anything, mock.MatchedBy(func(q string) bool {
			return len(q) > 0 && containsSubstring(q, "INSERT INTO") && containsSubstring(q, "`default`.`raw_transactions`")
		}),
			*tx.BlockchainID,       // string: blockchain ID
			tx.EVMChainID.String(), // string: UInt256
			tx.BlockNumber,
			string(blockHashBytes[:]), // string: 32-byte binary string
			tx.BlockTime,
			tx.TimestampMs,
			string(hashBytes[:]), // string: 32-byte binary string
			string(fromBytes[:]), // string: 20-byte binary string
			toBytes,              // string or nil: 20-byte binary string
			tx.Nonce,
			tx.Value.String(), // string: UInt256
			tx.Gas,
			tx.GasUsed,
			tx.EffectiveGasPrice.String(), // string: UInt256
			tx.GasPrice.String(),          // string: UInt256
			tx.MaxFeePerGas.String(),      // string: UInt256 (nullable)
			tx.MaxPriorityFee.String(),    // string: UInt256 (nullable)
			tx.Input,
			tx.Type,
			tx.TransactionIndex,
			tx.Success, // UInt8: success status
			tx.NumLogs, // uint32: number of logs
		).
		Return(nil).
		Once()

	repo, err := NewTransactions(ctx, testutils.NewTestClient(mockConn), "default", "default", "raw_transactions")
	require.NoError(t, err)
	err = repo.WriteTransaction(ctx, tx)
	require.NoError(t, err)
	mockConn.AssertExpectations(t)
}

func TestTransactionsRepository_WriteTransaction_Error(t *testing.T) {
	t.Parallel()
	mockConn := &testutils.MockConn{}
	ctx := t.Context()

	tx := createTestTransaction()
	execErr := errors.New("exec failed")

	// Convert hex strings to binary strings for FixedString fields (matching what WriteTransaction does)
	blockHashBytes, err := utils.HexToBytes32(tx.BlockHash)
	require.NoError(t, err, "blockHash conversion should succeed")
	hashBytes, err := utils.HexToBytes32(tx.Hash)
	require.NoError(t, err, "hash conversion should succeed")
	fromBytes, err := utils.HexToBytes20(tx.From)
	require.NoError(t, err, "fromAddress conversion should succeed")
	var toBytes interface{}
	if tx.To == nil || *tx.To == "" {
		toBytes = nil
	} else {
		toBytesVal, err := utils.HexToBytes20(*tx.To)
		require.NoError(t, err, "toAddress conversion should succeed")
		toBytes = string(toBytesVal[:])
	}

	// Expect CreateTableIfNotExists + migrations during initialization
	expectTableInit(mockConn, "raw_transactions_local", "raw_transactions")

	// Expect WriteTransaction call that fails
	mockConn.
		On("Exec", mock.Anything, mock.Anything,
			*tx.BlockchainID,       // string: blockchain ID
			tx.EVMChainID.String(), // string: UInt256
			tx.BlockNumber,
			string(blockHashBytes[:]), // string: 32-byte binary string
			tx.BlockTime,
			tx.TimestampMs,
			string(hashBytes[:]), // string: 32-byte binary string
			string(fromBytes[:]), // string: 20-byte binary string
			toBytes,              // string or nil: 20-byte binary string
			tx.Nonce,
			tx.Value.String(), // string: UInt256
			tx.Gas,
			tx.GasUsed,
			tx.EffectiveGasPrice.String(), // string: UInt256
			tx.GasPrice.String(),          // string: UInt256
			tx.MaxFeePerGas.String(),      // string: UInt256 (nullable)
			tx.MaxPriorityFee.String(),    // string: UInt256 (nullable)
			tx.Input,
			tx.Type,
			tx.TransactionIndex,
			tx.Success, // UInt8: success status
			tx.NumLogs, // uint32: number of logs
		).
		Return(execErr).
		Once()

	repo, err := NewTransactions(ctx, testutils.NewTestClient(mockConn), "default", "default", "raw_transactions")
	require.NoError(t, err)
	err = repo.WriteTransaction(ctx, tx)
	require.ErrorIs(t, err, execErr)
	assert.Contains(t, err.Error(), "failed to write transaction")
	assert.Contains(t, err.Error(), "exec failed")
	mockConn.AssertExpectations(t)
}

func TestTransactionsRepository_WriteTransaction_WithNullTo(t *testing.T) {
	t.Parallel()
	mockConn := &testutils.MockConn{}
	ctx := t.Context()

	// Create a test transaction with null To (contract creation)
	tx := createTestTransaction()
	tx.To = nil

	// Convert hex strings to binary strings for FixedString fields (matching what WriteTransaction does)
	blockHashBytes, err := utils.HexToBytes32(tx.BlockHash)
	require.NoError(t, err, "blockHash conversion should succeed")
	hashBytes, err := utils.HexToBytes32(tx.Hash)
	require.NoError(t, err, "hash conversion should succeed")
	fromBytes, err := utils.HexToBytes20(tx.From)
	require.NoError(t, err, "fromAddress conversion should succeed")
	// To is nil, so toBytes should be nil
	var toBytes interface{} = nil

	// Expect CreateTableIfNotExists + migrations during initialization
	expectTableInit(mockConn, "raw_transactions_local", "raw_transactions")

	// Expect WriteTransaction call
	mockConn.
		On("Exec", mock.Anything, mock.MatchedBy(func(q string) bool {
			return len(q) > 0 && containsSubstring(q, "INSERT INTO") && containsSubstring(q, "`default`.`raw_transactions`")
		}),
			*tx.BlockchainID,       // string: blockchain ID
			tx.EVMChainID.String(), // string: UInt256
			tx.BlockNumber,
			string(blockHashBytes[:]), // string: 32-byte binary string
			tx.BlockTime,
			tx.TimestampMs,
			string(hashBytes[:]), // string: 32-byte binary string
			string(fromBytes[:]), // string: 20-byte binary string
			toBytes,              // nil for contract creation
			tx.Nonce,
			tx.Value.String(), // string: UInt256
			tx.Gas,
			tx.GasUsed,
			tx.EffectiveGasPrice.String(), // string: UInt256
			tx.GasPrice.String(),          // string: UInt256
			tx.MaxFeePerGas.String(),      // string: UInt256 (nullable)
			tx.MaxPriorityFee.String(),    // string: UInt256 (nullable)
			tx.Input,
			tx.Type,
			tx.TransactionIndex,
			tx.Success, // UInt8: success status
			tx.NumLogs, // uint32: number of logs
		).
		Return(nil).
		Once()

	repo, err := NewTransactions(ctx, testutils.NewTestClient(mockConn), "default", "default", "raw_transactions")
	require.NoError(t, err)
	err = repo.WriteTransaction(ctx, tx)
	require.NoError(t, err)
	mockConn.AssertExpectations(t)
}

func TestTransactionsRepository_DeleteTransactions_Success(t *testing.T) {
	t.Parallel()
	mockConn := &testutils.MockConn{}
	ctx := t.Context()

	chainID := uint64(43114)

	// Expect CreateTableIfNotExists + migrations during initialization
	expectTableInit(mockConn, "raw_transactions_local", "raw_transactions")

	// Expect DeleteTransactions call
	mockConn.
		On("Exec", mock.Anything, "DELETE FROM `default`.`raw_transactions_local` ON CLUSTER 'default' WHERE evm_chain_id = ?\n", chainID).
		Return(nil).
		Once()

	repo, err := NewTransactions(ctx, testutils.NewTestClient(mockConn), "default", "default", "raw_transactions")
	require.NoError(t, err)
	err = repo.DeleteTransactions(ctx, chainID)
	require.NoError(t, err)
	mockConn.AssertExpectations(t)
}

func TestTransactionsRepository_DeleteTransactions_Error(t *testing.T) {
	t.Parallel()
	mockConn := &testutils.MockConn{}
	ctx := t.Context()

	chainID := uint64(43114)
	deleteErr := errors.New("delete failed")

	// Expect CreateTableIfNotExists + migrations during initialization
	expectTableInit(mockConn, "raw_transactions_local", "raw_transactions")

	// Expect DeleteTransactions call that fails
	mockConn.
		On("Exec", mock.Anything, "DELETE FROM `default`.`raw_transactions_local` ON CLUSTER 'default' WHERE evm_chain_id = ?\n", chainID).
		Return(deleteErr).
		Once()

	repo, err := NewTransactions(ctx, testutils.NewTestClient(mockConn), "default", "default", "raw_transactions")
	require.NoError(t, err)
	err = repo.DeleteTransactions(ctx, chainID)
	require.ErrorIs(t, err, deleteErr)
	assert.Contains(t, err.Error(), "failed to delete transactions")
	mockConn.AssertExpectations(t)
}

// Helper function to create a test transaction with all fields populated
func createTestTransaction() *TransactionRow {
	blockHash := testBlockHash
	txHash := testTxHash
	from := testFromAddress
	to := testToAddress

	blockchainID := testBlockchainID
	return &TransactionRow{
		BlockchainID:      &blockchainID,
		EVMChainID:        big.NewInt(0),
		BlockNumber:       1647,
		BlockHash:         blockHash,
		BlockTime:         time.Unix(1604768510, 0).UTC(),
		TimestampMs:       1604768510000,
		Hash:              txHash,
		From:              from,
		To:                &to,
		Nonce:             42,
		Value:             big.NewInt(1000000000000000000), // 1 ETH in wei
		Gas:               21000,
		GasUsed:           11000,
		EffectiveGasPrice: big.NewInt(470000000000), // 470 gwei
		GasPrice:          big.NewInt(470000000000), // 470 gwei
		MaxFeePerGas:      big.NewInt(1000000000),
		MaxPriorityFee:    big.NewInt(2000000000),
		Input:             "0x",
		Type:              2, // EIP-1559 transaction
		TransactionIndex:  0,
		Success:           1, // Default to success for tests
	}
}
