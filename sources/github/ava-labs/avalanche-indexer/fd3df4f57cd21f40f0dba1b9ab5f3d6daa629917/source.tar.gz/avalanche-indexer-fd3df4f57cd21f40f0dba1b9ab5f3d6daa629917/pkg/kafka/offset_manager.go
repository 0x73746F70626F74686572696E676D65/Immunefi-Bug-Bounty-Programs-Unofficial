package kafka

import (
	"context"
	"fmt"
	"slices"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"go.uber.org/zap"

	"github.com/ava-labs/avalanche-indexer/pkg/metrics"

	ckafka "github.com/confluentinc/confluent-kafka-go/v2/kafka"
)

const (
	// Default suggested Offset Manager parameters
	OffsetManagerCommitInterval  = 5 * time.Second
	OffsetManagerAutoOffsetReset = "latest"

	// ConsumerGroupLagInterval is the interval at which the offset manager queries
	// broker watermarks and committed offsets to compute consumer group lag.
	ConsumerGroupLagInterval = 30 * time.Second

	WindowLengthWarningThreshold  = 10000
	DefaultOffsetCommitTimeout    = 5000
	DefaultInsertOffsetRetryDelay = 200 * time.Millisecond
)

type offsetState struct {
	window        []ckafka.TopicPartition
	lastCommitted ckafka.Offset
}

/*
A a thread-safe, in-memory sliding window offset manager for Kafka consumers to
manage offsets for each assigned partition and ensure "at least once" message
processing. A single OffsetManager supports only one topic subscription at a
time.

The OffsetManager is configured with a commit interval and initial lastCommitted
offset. At every commit interval, the OffsetManager will analyze the
lastCommitted offset and those in the window to determine the highest offset to
commit to Kafka brokers.

When threads are done processing consumed messages, they should call
InsertOffset() to add the commits to the window.

The window length is unbounded, meaning code bugs can lead to no offsets
committed and a continually growing window size. If the offset window length
goes above WindowLengthWarningThreshold, warning logs will be printed to help
diagnose.
*/
type OffsetManager struct {
	consumer        *ckafka.Consumer
	autoOffsetReset string                 // auto.offset.reset config: "earliest" or "latest"
	partitionStates map[int32]*offsetState // map of offset states for each assigned partition
	topic           *string                // single topic for all assigned partitions
	mutex           sync.Mutex
	dryRun          bool // skip interactions with Brokers for testing
	log             *zap.SugaredLogger
	metrics         *metrics.Metrics // Prometheus metrics for offset tracking
}

// Creates new OffsetManager. To begin the OffsetManager, Start() must be called.
func NewOffsetManager(
	ctx context.Context,
	consumer *ckafka.Consumer,
	interval time.Duration,
	autoOffsetReset string,
	dryRun bool,
	log *zap.SugaredLogger,
	m *metrics.Metrics,
) *OffsetManager {
	if m == nil {
		m = metrics.NewNoOp()
	}
	om := &OffsetManager{
		consumer:        consumer,
		autoOffsetReset: autoOffsetReset,
		partitionStates: make(map[int32]*offsetState),
		dryRun:          dryRun,
		log:             log,
		metrics:         m,
	}
	go om.run(ctx, interval, dryRun)
	if !dryRun {
		go om.runLagRecorder(ctx)
	}
	return om
}

func (om *OffsetManager) run(
	ctx context.Context,
	interval time.Duration,
	dryRun bool,
) {
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			om.commitLatestValidOffsets(dryRun)
		case <-ctx.Done():
			return
		}
	}
}

// For each assigned partition, scan for a contiguous set of offsets in the
// current window starting from lastCommitted to find the latest valid offset to
// commit to Kafka brokers. After successful commits, truncate the window
// accordingly.
func (om *OffsetManager) commitLatestValidOffsets(dryRun bool) {
	var err error
	om.mutex.Lock()
	defer om.mutex.Unlock()

	for partition, state := range om.partitionStates {
		window := state.window
		lastCommitted := state.lastCommitted

		windowSize := len(window)
		var latestProcessed ckafka.Offset
		if windowSize > 0 {
			latestProcessed = window[windowSize-1].Offset
		} else {
			latestProcessed = lastCommitted
		}

		om.metrics.UpdateOffsetMetrics(partition, int64(lastCommitted), int64(latestProcessed), windowSize)

		if len(window) == 0 {
			om.log.Debug("no offsets to commit")
			continue
		}

		if window[0].Offset <= lastCommitted+1 {
			end := 0
			for i := 1; i < len(window); i++ {
				// Commit any dangling offsets. This will happen when a new
				// consumer group is formed with auto.offset.reset="latest" and
				// there is no strict consensus on what the "latest" offset is
				// the producer is actively writing to the topic. See
				// InsertOffset() for more details.
				if window[i].Offset <= lastCommitted {
					end = i
					continue
				}

				if window[i].Offset != window[i-1].Offset+1 {
					break
				}
				end = i
			}

			commitStart := time.Now()
			if !dryRun {
				_, err = om.consumer.CommitOffsets([]ckafka.TopicPartition{window[end]})
			}
			commitDuration := time.Since(commitStart).Seconds()

			om.metrics.RecordOffsetCommit(partition, err, commitDuration)

			if err != nil {
				om.log.Errorf("failed to commit offsets: %v", err)
				return
			}

			om.log.Debugf("committed offset %d for partition %d", window[end].Offset, partition)
			if end == len(window)-1 {
				om.partitionStates[partition] = &offsetState{
					window:        []ckafka.TopicPartition{},
					lastCommitted: window[end].Offset,
				}
			} else {
				om.partitionStates[partition] = &offsetState{
					window:        window[end+1:],
					lastCommitted: window[end].Offset,
				}
			}

			newWindowSize := len(om.partitionStates[partition].window)
			var newLatestProcessed ckafka.Offset
			if newWindowSize > 0 {
				newLatestProcessed = om.partitionStates[partition].window[newWindowSize-1].Offset
			} else {
				newLatestProcessed = window[end].Offset
			}
			om.metrics.UpdateOffsetMetrics(partition, int64(window[end].Offset), int64(newLatestProcessed), newWindowSize)
		}

		if len(om.partitionStates[partition].window) > WindowLengthWarningThreshold {
			om.log.Warnf(
				"partition %d window length is high: %d\n",
				partition,
				len(om.partitionStates[partition].window),
			)
		}
	}
}

// Inserts an offset to commit into the sliding window for partition
// `offset.Partition`. The argument `offset.Offset`  should be one higher than
// the offset of the message processed. That is
// `message.TopicPartition.Offset+1`. This is an unclear semantic in Kafka
// client libraries. E.g.
// https://github.com/confluentinc/confluent-kafka-go/issues/350
//
// Topic, Partition, and Offset fields are required.
func (om *OffsetManager) InsertOffset(ctx context.Context, offset ckafka.TopicPartition) error {
	om.mutex.Lock()
	defer om.mutex.Unlock()

	select {
	case <-ctx.Done():
		return ctx.Err()
	default:
	}

	state := om.partitionStates[offset.Partition]
	if state == nil {
		om.log.Warnf("partition %d not found in partition states, ignoring", offset.Partition)
		return nil
	}

	// If the lastCommitted offset is not initialized, we set it to the offset
	// of the actual message that has been processed to generate this offset
	// commit (offset.Offset-1). This first picked offset does not need to be
	// the absolute first one fetched from the broker.
	if state.lastCommitted < 0 {
		state.lastCommitted = offset.Offset - 1
		om.log.Infof("init partition %d lastCommitted to %d", offset.Partition, offset.Offset)
	}

	window := state.window
	i := sort.Search(
		len(window),
		func(j int) bool { return window[j].Offset >= offset.Offset },
	)
	if i < len(window) && window[i].Offset == offset.Offset {
		return nil // already inserted
	}
	om.partitionStates[offset.Partition].window = slices.Insert(window, i, offset)

	om.metrics.RecordOffsetInsert(offset.Partition)

	return nil
}

// Resets or initializes the OffsetManager's partitionStates. This rebalance
// callback function must be passed to ckafka.Consumer.Subscribe(). When the
// consumer joins a group, this will then be called as a way to initialize the
// OffsetManager
func (om *OffsetManager) RebalanceCb(consumer *ckafka.Consumer, event ckafka.Event) error {
	om.mutex.Lock()
	defer om.mutex.Unlock()
	switch ev := event.(type) {
	case ckafka.AssignedPartitions:
		// Extract partition numbers for metrics (before processing)
		partitionNums := make([]int32, len(ev.Partitions))
		for i, p := range ev.Partitions {
			partitionNums[i] = p.Partition
		}

		om.metrics.RecordPartitionAssignment(partitionNums)

		// Rebalance events may provide offsets, but offsets seem to be
		// ckafka.InvalidOffset (-1001) when a consumer is joining an idle, but
		// already existing, group. So we explicitly get the committed offsets
		// from the broker.
		var err error
		var committedOffsets []ckafka.TopicPartition
		if om.dryRun {
			committedOffsets = ev.Partitions
		} else {
			committedOffsets, err = consumer.Committed(ev.Partitions, DefaultOffsetCommitTimeout)
		}

		if err != nil {
			return fmt.Errorf("failed to get committed offsets: %w", err)
		}

		logStr := make([]string, len(committedOffsets))
		var assignedTopic *string
		for i, co := range committedOffsets {
			om.partitionStates[co.Partition] = &offsetState{
				window:        []ckafka.TopicPartition{},
				lastCommitted: co.Offset,
			}
			if co.Topic != nil {
				topicName := *co.Topic
				if assignedTopic == nil {
					assignedTopic = &topicName
				} else if *assignedTopic != topicName {
					om.log.Warnf(
						"received mixed topic assignment (%s and %s); lag metrics will use %s",
						*assignedTopic,
						topicName,
						*assignedTopic,
					)
				}
			}

			// If the group's stored offset is lower than the earliest offset of
			// the topic due to its retention policy, librdkafka will
			// immediately start fetching based off auto.offset.reset. We
			// invalidate any stored offset here and will have the OffsetManager
			// pick any first offset to initialize the window.
			if !om.dryRun {
				low, high, err := om.consumer.QueryWatermarkOffsets(*(co.Topic), co.Partition, 5000)
				if err != nil {
					om.log.Errorf("GetWatermarkOffsets failed: %v", err)
					return fmt.Errorf("GetWatermarkOffsets failed: %w", err)
				}

				om.log.Infof(
					"QueryWatermarkOffsets for partition %d: (low: %d, high: %d), auto.offset.reset: %s",
					co.Partition,
					low,
					high,
					om.autoOffsetReset,
				)

				if co.Offset < 0 || co.Offset < ckafka.Offset(low) {
					// Reset the offset to ckafka.OffsetInvalid (-1001) to
					// indicate a stored offset does not exist or is now out of
					// range
					om.partitionStates[co.Partition].lastCommitted = ckafka.OffsetInvalid
				}
			}

			// Initialize offset metrics for this partition using the actual
			// state value, which may have been reset to OffsetInvalid above.
			actualCommitted := int64(om.partitionStates[co.Partition].lastCommitted)
			om.metrics.UpdateOffsetMetrics(co.Partition, actualCommitted, actualCommitted, 0)

			logStr[i] = fmt.Sprintf("(partition: %d, lastCommitted: %d)", co.Partition, om.partitionStates[co.Partition].lastCommitted)
		}
		if assignedTopic != nil {
			if om.topic != nil && *om.topic != *assignedTopic {
				om.log.Warnf("offset manager topic changed from %s to %s", *om.topic, *assignedTopic)
			}
			om.topic = assignedTopic
		}

		om.log.Infof("rebalance event, adding partition states: %s\n", strings.Join(logStr, ","))
	case ckafka.RevokedPartitions:
		// Extract partition numbers for metrics (before processing)
		partitionNums := make([]int32, len(ev.Partitions))
		for i, p := range ev.Partitions {
			partitionNums[i] = p.Partition
		}

		om.metrics.RecordPartitionRevocation(partitionNums)

		logStr := make([]string, len(ev.Partitions))
		for i, partition := range ev.Partitions {
			logStr[i] = strconv.Itoa(int(partition.Partition))
			delete(om.partitionStates, partition.Partition)
			om.metrics.DeleteKafkaConsumerGroupLag(partition.Partition)
		}
		if len(om.partitionStates) == 0 {
			om.topic = nil
		}
		om.log.Infof("rebalance event, removing state for partitions: %s\n", strings.Join(logStr, ","))
	default:
		om.log.Warnf("unknown rebalance event: %v", event)
	}
	return nil
}

// runLagRecorder periodically queries broker watermarks and committed offsets to compute
// consumer group lag on its own timer.
func (om *OffsetManager) runLagRecorder(ctx context.Context) {
	ticker := time.NewTicker(ConsumerGroupLagInterval)
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			om.recordConsumerGroupLag()
		case <-ctx.Done():
			return
		}
	}
}

// recordConsumerGroupLag queries committed offsets and partition watermarks from Kafka
// brokers to compute and record true consumer group lag for each assigned partition.
// TODO: the lag gauge should eventually be defined locally in the kafka package with a
// prometheus.Registerer passed to NewOffsetManager.
// When no committed offset exists (offset < 0), lag is estimated based on auto.offset.reset:
// zero for "latest", full partition range for "earliest" or unknown values.
// Only called from runLagRecorder, which is not started in dryRun mode.
func (om *OffsetManager) recordConsumerGroupLag() {
	om.mutex.Lock()
	if om.topic == nil {
		om.mutex.Unlock()
		return
	}
	topic := *om.topic
	partitions := make([]ckafka.TopicPartition, 0, len(om.partitionStates))
	for partition := range om.partitionStates {
		partitions = append(partitions, ckafka.TopicPartition{
			Topic:     &topic,
			Partition: partition,
		})
	}
	om.mutex.Unlock()

	if len(partitions) == 0 {
		return
	}

	committed, err := om.consumer.Committed(partitions, DefaultOffsetCommitTimeout)
	if err != nil {
		om.log.Warnf("failed to query committed offsets for lag metrics: %v", err)
		return
	}

	for _, partition := range committed {
		if partition.Topic == nil {
			continue
		}

		low, high, err := om.consumer.QueryWatermarkOffsets(*partition.Topic, partition.Partition, DefaultOffsetCommitTimeout)
		if err != nil {
			om.log.Warnf("failed to query watermark offsets for lag metrics (partition=%d): %v", partition.Partition, err)
			continue
		}

		var lag int64
		if partition.Offset < 0 {
			// No committed offset exists: effective lag depends on auto.offset.reset behavior.
			switch strings.ToLower(om.autoOffsetReset) {
			case "latest":
				lag = 0
			case "earliest":
				lag = high - low
			default:
				// Treat unknown auto.offset.reset values as "earliest" (conservative: assume maximum lag)
				om.log.Warnf("unrecognized auto.offset.reset value %q, defaulting to earliest-style lag calculation", om.autoOffsetReset)
				lag = high - low
			}
		} else {
			lag = high - int64(partition.Offset)
		}
		if lag < 0 {
			lag = 0
		}

		om.metrics.SetKafkaConsumerGroupLag(partition.Partition, lag)
	}
}

func (om *OffsetManager) InsertOffsetWithRetry(
	ctx context.Context,
	msg *ckafka.Message,
) {
	for {
		err := om.InsertOffset(ctx, ckafka.TopicPartition{
			Topic:     msg.TopicPartition.Topic,
			Partition: msg.TopicPartition.Partition,
			Offset:    msg.TopicPartition.Offset + 1,
		})
		if err == nil || ctx.Err() != nil {
			if ctx.Err() != nil {
				om.log.Warnf("context cancelled, returning: %v", ctx.Err())
			} else {
				om.log.Debugf("InsertOffset successful, returning for offset %d and partition %d", msg.TopicPartition.Offset+1, msg.TopicPartition.Partition)
			}
			return
		}

		om.log.Error("retrying InsertOffset. err ", err)
		time.Sleep(DefaultInsertOffsetRetryDelay)
	}
}

// getPartitionState returns a copy of the partition state for testing.
// Returns nil if the partition is not assigned.
// This is unexported and only used by tests in the same package.
func (om *OffsetManager) getPartitionState(partition int32) *offsetState {
	om.mutex.Lock()
	defer om.mutex.Unlock()

	state := om.partitionStates[partition]
	if state == nil {
		return nil
	}

	// Return a copy to avoid race conditions
	windowCopy := make([]ckafka.TopicPartition, len(state.window))
	copy(windowCopy, state.window)

	return &offsetState{
		window:        windowCopy,
		lastCommitted: state.lastCommitted,
	}
}

// getPartitionCount returns the number of assigned partitions.
// This is unexported and only used by tests in the same package.
func (om *OffsetManager) getPartitionCount() int {
	om.mutex.Lock()
	defer om.mutex.Unlock()
	return len(om.partitionStates)
}
