package kafka

import (
	"math"
	"time"

	ckafka "github.com/confluentinc/confluent-kafka-go/v2/kafka"
)

// Default timeout values for Kafka consumer
const (
	DefaultSessionTimeout       = 240 * time.Second
	DefaultMaxPollInterval      = 3400 * time.Second
	DefaultFlushTimeout         = 15 * time.Second
	DefaultGoroutineWaitTimeout = 30 * time.Second
	DefaultPollInterval         = 100 * time.Millisecond
	DefaultMessageMaxBytes      = 20971521 // 20MB

	DefaultRetryBaseDelay = 500 * time.Millisecond
	DefaultRetryMaxDelay  = 2 * time.Second
)

// InfiniteRetries signals that the consumer should retry failed messages
// indefinitely until they succeed or the context is cancelled.
const InfiniteRetries = -1

// RetryPolicy controls how the consumer retries failed messages before
// escalating to DLQ publication or error propagation. Only retryable
// errors (plain errors) enter the retry loop; non-retryable and fatal
// errors bypass retries entirely.
//
//   - MaxRetries = 0  : no retries, escalate immediately
//   - MaxRetries > 0  : retry up to N times, then escalate
//   - MaxRetries = -1 : retry forever (suited for DLQ consumers)
type RetryPolicy struct {
	MaxRetries int           // -1 = infinite, 0 = disabled, >0 = count
	BaseDelay  time.Duration // initial backoff sleep
	MaxDelay   time.Duration // upper bound on exponential backoff
}

// Backoff returns the sleep duration for the given zero-based attempt,
// clamped to MaxDelay. Uses 2^attempt * BaseDelay with a cap.
func (r RetryPolicy) Backoff(attempt int) time.Duration {
	if r.BaseDelay <= 0 {
		return 0
	}
	shift := math.Min(float64(attempt), 30) // avoid overflow
	delay := time.Duration(float64(r.BaseDelay) * math.Pow(2, shift))
	if delay > r.MaxDelay {
		return r.MaxDelay
	}
	return delay
}

// ShouldRetry reports whether another attempt is allowed for the given
// zero-based attempt number (i.e. attempt 0 is the first retry).
func (r RetryPolicy) ShouldRetry(attempt int) bool {
	if r.MaxRetries == InfiniteRetries {
		return true
	}
	return attempt < r.MaxRetries
}

// ConsumerConfig holds the configuration for a Kafka consumer
type ConsumerConfig struct {
	DLQTopic                    string         // Dead letter queue topic for failed messages
	Topic                       string         // Primary topic to consume from
	BootstrapServers            string         // Kafka broker addresses
	GroupID                     string         // Consumer group ID for offset management
	AutoOffsetReset             string         // Offset reset strategy: "earliest" or "latest"
	Concurrency                 int64          // Maximum concurrent message processors
	OffsetManagerCommitInterval time.Duration  // Interval for committing offsets
	SessionTimeout              *time.Duration // Session timeout for Kafka consumer
	MaxPollInterval             *time.Duration // Max poll interval for Kafka consumer
	FlushTimeout                *time.Duration // Flush timeout for Kafka consumer
	GoroutineWaitTimeout        *time.Duration // Goroutine wait timeout while Closing the Kafka consumer
	PollInterval                *time.Duration // Poll interval for Kafka consumer
	EnableLogs                  bool           // Enable librdkafka client logs
	PublishToDLQ                bool           // If true, failed messages are published to DLQ
	SASL                        SASLConfig     // SASL authentication configuration
	MessageMaxBytes             int            // Maximum message size in bytes
	Retry                       RetryPolicy    // Retry policy for failed message processing
}

// WithDefaults returns a copy of the config with default values filled in for any nil pointer fields.
// This method does not mutate the original config.
func (c ConsumerConfig) WithDefaults() ConsumerConfig {
	if c.SessionTimeout == nil {
		timeout := DefaultSessionTimeout
		c.SessionTimeout = &timeout
	}
	if c.MaxPollInterval == nil {
		interval := DefaultMaxPollInterval
		c.MaxPollInterval = &interval
	}
	if c.FlushTimeout == nil {
		timeout := DefaultFlushTimeout
		c.FlushTimeout = &timeout
	}
	if c.GoroutineWaitTimeout == nil {
		timeout := DefaultGoroutineWaitTimeout
		c.GoroutineWaitTimeout = &timeout
	}
	if c.PollInterval == nil {
		interval := DefaultPollInterval
		c.PollInterval = &interval
	}
	if c.MessageMaxBytes == 0 {
		c.MessageMaxBytes = DefaultMessageMaxBytes
	}
	if c.Retry.BaseDelay == 0 {
		c.Retry.BaseDelay = DefaultRetryBaseDelay
	}
	if c.Retry.MaxDelay == 0 {
		c.Retry.MaxDelay = DefaultRetryMaxDelay
	}
	return c
}

// SASLConfig holds SASL authentication configuration
type SASLConfig struct {
	Username         string // SASL username
	Password         string //nolint:gosec // runtime-provided credential required for Kafka SASL; not hardcoded
	Mechanism        string // SASL mechanism: "SCRAM-SHA-256", "SCRAM-SHA-512", or "PLAIN"
	SecurityProtocol string // Security protocol: "SASL_SSL" or "SASL_PLAINTEXT"
}

// IsEnabled returns true if SASL authentication is configured
func (s SASLConfig) IsEnabled() bool {
	return s.Username != "" && s.Password != "" && s.Mechanism != "" && s.SecurityProtocol != ""
}

// ApplyToConfigMap applies SASL configuration to a Kafka ConfigMap
func (s SASLConfig) ApplyToConfigMap(cfg *ckafka.ConfigMap) {
	if !s.IsEnabled() {
		return
	}
	(*cfg)["security.protocol"] = s.SecurityProtocol
	(*cfg)["sasl.mechanism"] = s.Mechanism
	(*cfg)["sasl.username"] = s.Username
	(*cfg)["sasl.password"] = s.Password
}
