package processor

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"math/big"
	"testing"
	"time"

	"github.com/ava-labs/libevm/common"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.uber.org/zap"

	"github.com/ava-labs/avalanche-indexer/pkg/data/clickhouse/evmrepo"

	chdriver "github.com/ClickHouse/clickhouse-go/v2"
	kafkamsg "github.com/ava-labs/avalanche-indexer/pkg/kafka/messages"
	ckafka "github.com/confluentinc/confluent-kafka-go/v2/kafka"
)

const (
	testBlockHash    = "0x0102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f20"
	testBlockchainID = "11111111111111111111111111111111LpoYY"
)

// Mock implementations for testing
type mockBlocksRepo struct {
	writeBlockFunc        func(ctx context.Context, block *evmrepo.BlockRow) error
	batchInsertBlocksFunc func(ctx context.Context, blocks []*evmrepo.BlockRow) error
	deleteBlocksFunc      func(ctx context.Context, chainID uint64) error
}

func (*mockBlocksRepo) CreateTableIfNotExists(context.Context) error { return nil }

func (m *mockBlocksRepo) WriteBlock(ctx context.Context, block *evmrepo.BlockRow) error {
	if m.writeBlockFunc != nil {
		return m.writeBlockFunc(ctx, block)
	}
	return nil
}

func (m *mockBlocksRepo) BatchInsertBlocks(ctx context.Context, blocks []*evmrepo.BlockRow) error {
	if m.batchInsertBlocksFunc != nil {
		return m.batchInsertBlocksFunc(ctx, blocks)
	}
	return nil
}

func (m *mockBlocksRepo) DeleteBlocks(ctx context.Context, chainID uint64) error {
	if m.deleteBlocksFunc != nil {
		return m.deleteBlocksFunc(ctx, chainID)
	}
	return nil
}

type mockTransactionsRepo struct {
	writeTransactionFunc        func(ctx context.Context, tx *evmrepo.TransactionRow) error
	batchInsertTransactionsFunc func(ctx context.Context, txs []*evmrepo.TransactionRow) error
	deleteTransactionsFunc      func(ctx context.Context, chainID uint64) error
}

func (*mockTransactionsRepo) CreateTableIfNotExists(context.Context) error { return nil }
func (m *mockTransactionsRepo) WriteTransaction(ctx context.Context, tx *evmrepo.TransactionRow) error {
	if m.writeTransactionFunc != nil {
		return m.writeTransactionFunc(ctx, tx)
	}
	return nil
}

func (m *mockTransactionsRepo) DeleteTransactions(ctx context.Context, chainID uint64) error {
	if m.deleteTransactionsFunc != nil {
		return m.deleteTransactionsFunc(ctx, chainID)
	}
	return nil
}

func (m *mockTransactionsRepo) BatchInsertTransactions(ctx context.Context, txs []*evmrepo.TransactionRow) error {
	if m.batchInsertTransactionsFunc != nil {
		return m.batchInsertTransactionsFunc(ctx, txs)
	}
	return nil
}

type mockLogsRepo struct {
	writeLogFunc        func(ctx context.Context, log *evmrepo.LogRow) error
	deleteLogsFunc      func(ctx context.Context, chainID uint64) error
	batchInsertLogsFunc func(ctx context.Context, logs []*evmrepo.LogRow) error
}

func (*mockLogsRepo) CreateTableIfNotExists(context.Context) error { return nil }
func (m *mockLogsRepo) WriteLog(ctx context.Context, log *evmrepo.LogRow) error {
	if m.writeLogFunc != nil {
		return m.writeLogFunc(ctx, log)
	}
	return nil
}

func (m *mockLogsRepo) DeleteLogs(ctx context.Context, chainID uint64) error {
	if m.deleteLogsFunc != nil {
		return m.deleteLogsFunc(ctx, chainID)
	}
	return nil
}

func (m *mockLogsRepo) BatchInsertLogs(ctx context.Context, logs []*evmrepo.LogRow) error {
	if m.batchInsertLogsFunc != nil {
		return m.batchInsertLogsFunc(ctx, logs)
	}
	return nil
}

// Helper to compare *big.Int values (handles nil cases)
func assertBigIntEqual(t *testing.T, expected, actual *big.Int) {
	t.Helper()
	if expected == nil && actual == nil {
		return
	}
	if expected == nil {
		require.Nil(t, actual, "Expected nil, got %v", actual)
		return
	}
	if actual == nil {
		require.NotNil(t, actual, "Expected %v, got nil", expected)
		return
	}
	assert.Equal(t, 0, expected.Cmp(actual), "Expected %s, got %s", expected.String(), actual.String())
}

// Helper function to create a uint64 pointer
func uintPtr(u uint64) *uint64 {
	return &u
}

// ============================================================================
// CorethLogToLogRow Tests
// ============================================================================

func TestCorehtLogToLogRow_Success(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	log := createTestLog()

	logRow, err := CorethLogToLogRow(log, block)
	require.NoError(t, err)
	require.NotNil(t, logRow)

	assert.Equal(t, testBlockchainID, *logRow.BlockchainID)
	assertBigIntEqual(t, big.NewInt(43113), logRow.EVMChainID)
	assert.Equal(t, uint64(1647), logRow.BlockNumber)
	assert.Equal(t, log.BlockHash.Hex(), logRow.BlockHash)
	assert.Equal(t, time.Unix(1604768510, 0).UTC(), logRow.BlockTime)
	assert.Equal(t, uint64(1604768510000), logRow.TimestampMs)
	assert.Equal(t, log.TxHash.Hex(), logRow.TxHash)
	assert.Equal(t, uint32(0), logRow.TxIndex)
	assert.Equal(t, log.Address.Hex(), logRow.Address)
	assert.Equal(t, uint32(0), logRow.LogIndex)
	assert.False(t, logRow.Removed)
	assert.Equal(t, log.Data, logRow.Data)

	// Check topics
	assert.NotEmpty(t, logRow.Topic0)
	assert.Equal(t, log.Topics[0].Hex(), logRow.Topic0)
	require.NotNil(t, logRow.Topic1)
	assert.Equal(t, log.Topics[1].Hex(), *logRow.Topic1)
	require.NotNil(t, logRow.Topic2)
	assert.Equal(t, log.Topics[2].Hex(), *logRow.Topic2)
	assert.Nil(t, logRow.Topic3)
}

func TestCorethLogToLogRow_NilBlockchainID(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	block.BlockchainID = nil
	log := createTestLog()

	logRow, err := CorethLogToLogRow(log, block)
	require.ErrorIs(t, err, evmrepo.ErrBlockChainIDRequired)
	assert.Nil(t, logRow)
}

func TestCorethLogToLogRow_NilEVMChainID(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	block.EVMChainID = nil
	log := createTestLog()

	logRow, err := CorethLogToLogRow(log, block)
	require.ErrorIs(t, err, evmrepo.ErrEvmChainIDRequired)
	assert.Nil(t, logRow)
}

func TestCorethLogToLogRow_EmptyTopics(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	log := createTestLog()
	log.Topics = []common.Hash{}

	logRow, err := CorethLogToLogRow(log, block)
	require.NoError(t, err)
	require.NotNil(t, logRow)

	assert.Empty(t, logRow.Topic0)
	assert.Nil(t, logRow.Topic1)
	assert.Nil(t, logRow.Topic2)
	assert.Nil(t, logRow.Topic3)
}

func TestCorethLogToLogRow_AllFourTopics(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	log := createTestLog()
	log.Topics = []common.Hash{
		common.HexToHash("0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"),
		common.HexToHash("0x0000000000000000000000004142434445464748494a4b4c4d4e4f5051525354"),
		common.HexToHash("0x00000000000000000000000055565758595a5b5c5d5e5f6061626364656667"),
		common.HexToHash("0x0000000000000000000000000000000000000000000000000000000000001234"),
	}

	logRow, err := CorethLogToLogRow(log, block)
	require.NoError(t, err)
	require.NotNil(t, logRow)

	assert.NotEmpty(t, logRow.Topic0)
	require.NotNil(t, logRow.Topic1)
	require.NotNil(t, logRow.Topic2)
	require.NotNil(t, logRow.Topic3)
	assert.Equal(t, log.Topics[3].Hex(), *logRow.Topic3)
}

func TestCorethLogToLogRow_RemovedFlag(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	log := createTestLog()
	log.Removed = true

	logRow, err := CorethLogToLogRow(log, block)
	require.NoError(t, err)
	require.NotNil(t, logRow)

	assert.True(t, logRow.Removed)
}

// ============================================================================
// CorethBlockToBlockRow Tests
// ============================================================================

func TestCorethBlockToBlockRow_Success(t *testing.T) {
	t.Parallel()

	block := createTestBlock()

	blockRow, err := CorethBlockToBlockRow(block)
	require.NoError(t, err)
	require.NotNil(t, blockRow)

	assert.Equal(t, testBlockchainID, *blockRow.BlockchainID)
	assertBigIntEqual(t, big.NewInt(43113), blockRow.EVMChainID)
	assertBigIntEqual(t, big.NewInt(1647), blockRow.BlockNumber)
	assert.Equal(t, testBlockHash, blockRow.Hash)
	assert.Equal(t, "0x2122232425262728292a2b2c2d2e2f303132333435363738393a3b3c3d3e3f40", blockRow.ParentHash)
	assert.Equal(t, time.Unix(1604768510, 0).UTC(), blockRow.BlockTime)
	assert.Equal(t, uint64(1604768510000), blockRow.TimestampMs)
	assert.Equal(t, uint64(1331), blockRow.Size)
	assert.Equal(t, uint64(20006296), blockRow.GasLimit)
	assert.Equal(t, uint64(183061), blockRow.GasUsed)
	assertBigIntEqual(t, big.NewInt(470000000000), blockRow.BaseFeePerGas)
	assert.Equal(t, "2a", blockRow.Nonce)        // 42 in hex
	assert.Equal(t, uint32(1), blockRow.NumTxns) // 1 transaction in the test block
}

func TestCorethBlockToBlockRow_NoTransactions(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	block.Transactions = []*kafkamsg.EVMTransaction{} // No transactions

	blockRow, err := CorethBlockToBlockRow(block)
	require.NoError(t, err)
	require.NotNil(t, blockRow)

	assert.Equal(t, uint32(0), blockRow.NumTxns)
}

func TestCorethBlockToBlockRow_NilBlockchainID(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	block.BlockchainID = nil

	blockRow, err := CorethBlockToBlockRow(block)
	require.ErrorIs(t, err, evmrepo.ErrBlockChainIDRequired)
	assert.Nil(t, blockRow)
}

func TestCorethBlockToBlockRow_NilNumber(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	block.Number = nil

	blockRow, err := CorethBlockToBlockRow(block)
	require.NoError(t, err)
	require.NotNil(t, blockRow)

	assertBigIntEqual(t, big.NewInt(0), blockRow.BlockNumber)
}

func TestCorethBlockToBlockRow_NilEVMChainID(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	block.EVMChainID = nil

	blockRow, err := CorethBlockToBlockRow(block)
	require.NoError(t, err)
	require.NotNil(t, blockRow)

	assertBigIntEqual(t, big.NewInt(0), blockRow.EVMChainID)
}

func TestCorethBlockToBlockRow_NilDifficulty(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	block.Difficulty = nil

	blockRow, err := CorethBlockToBlockRow(block)
	require.NoError(t, err)
	require.NotNil(t, blockRow)

	assertBigIntEqual(t, big.NewInt(0), blockRow.Difficulty)
	assertBigIntEqual(t, big.NewInt(0), blockRow.TotalDifficulty)
}

func TestCorethBlockToBlockRow_OptionalFields(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	block.BlobGasUsed = uintPtr(1000)
	block.ExcessBlobGas = uintPtr(2000)
	block.ParentBeaconBlockRoot = "0xbeaconroot1234567890abcdef1234567890abcdef1234567890abcdef1234567890"
	block.MinDelayExcess = 5000

	blockRow, err := CorethBlockToBlockRow(block)
	require.NoError(t, err)
	require.NotNil(t, blockRow)

	assert.Equal(t, uint64(1000), blockRow.BlobGasUsed)
	assert.Equal(t, uint64(2000), blockRow.ExcessBlobGas)
	assert.Equal(t, "0xbeaconroot1234567890abcdef1234567890abcdef1234567890abcdef1234567890", blockRow.ParentBeaconBlockRoot)
	assert.Equal(t, uint64(5000), blockRow.MinDelayExcess)
}

// ============================================================================
// CorethTransactionToTransactionRow Tests
// ============================================================================

func TestCorethTransactionToTransactionRow_Success(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	tx := createTestTransaction()
	txIndex := uint64(0)

	txRow, err := CorethTransactionToTransactionRow(tx, block, txIndex)
	require.NoError(t, err)
	require.NotNil(t, txRow)

	assert.Equal(t, testBlockchainID, *txRow.BlockchainID)
	assertBigIntEqual(t, big.NewInt(43113), txRow.EVMChainID)
	assert.Equal(t, uint64(1647), txRow.BlockNumber)
	assert.Equal(t, testBlockHash, txRow.BlockHash)
	assert.Equal(t, time.Unix(1604768510, 0).UTC(), txRow.BlockTime)
	assert.Equal(t, uint64(1604768510000), txRow.TimestampMs)
	assert.Equal(t, "0x55565758595a5b5c5d5e5f606162636465666768696a6b6c6d6e6f70717273", txRow.Hash)
	assert.Equal(t, "0x4142434445464748494a4b4c4d4e4f5051525354", txRow.From)
	require.NotNil(t, txRow.To)
	assert.Equal(t, "0x55565758595a5b5c5d5e5f6061626364656667", *txRow.To)
	assert.Equal(t, uint64(1), txRow.Nonce)
	assertBigIntEqual(t, big.NewInt(1000000000000000000), txRow.Value)
	assert.Equal(t, uint64(21000), txRow.Gas)
	assertBigIntEqual(t, big.NewInt(470000000000), txRow.GasPrice)
	assert.Equal(t, txIndex, txRow.TransactionIndex)
	assert.Equal(t, uint32(0), txRow.NumLogs) // No receipt on test transaction
}

func TestCorethTransactionToTransactionRow_NilBlockchainID(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	block.BlockchainID = nil
	tx := createTestTransaction()

	txRow, err := CorethTransactionToTransactionRow(tx, block, 0)
	require.ErrorIs(t, err, evmrepo.ErrBlockChainIDRequiredForTx)
	assert.Nil(t, txRow)
}

func TestCorethTransactionToTransactionRow_NilTo(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	tx := createTestTransaction()
	tx.To = "" // Empty To (contract creation)

	txRow, err := CorethTransactionToTransactionRow(tx, block, 0)
	require.NoError(t, err)
	require.NotNil(t, txRow)

	assert.Nil(t, txRow.To)
}

func TestCorethTransactionToTransactionRow_NilValue(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	tx := createTestTransaction()
	tx.Value = nil

	txRow, err := CorethTransactionToTransactionRow(tx, block, 0)
	require.NoError(t, err)
	require.NotNil(t, txRow)

	assertBigIntEqual(t, big.NewInt(0), txRow.Value)
}

func TestCorethTransactionToTransactionRow_NilGasPrice(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	tx := createTestTransaction()
	tx.GasPrice = nil

	txRow, err := CorethTransactionToTransactionRow(tx, block, 0)
	require.NoError(t, err)
	require.NotNil(t, txRow)

	assertBigIntEqual(t, big.NewInt(0), txRow.GasPrice)
}

func TestCorethTransactionToTransactionRow_MaxFeeFields(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	tx := createTestTransaction()
	tx.MaxFeePerGas = big.NewInt(1000000000)
	tx.MaxPriorityFee = big.NewInt(2000000000)

	txRow, err := CorethTransactionToTransactionRow(tx, block, 0)
	require.NoError(t, err)
	require.NotNil(t, txRow)

	require.NotNil(t, txRow.MaxFeePerGas)
	require.NotNil(t, txRow.MaxPriorityFee)
	assertBigIntEqual(t, big.NewInt(1000000000), txRow.MaxFeePerGas)
	assertBigIntEqual(t, big.NewInt(2000000000), txRow.MaxPriorityFee)
}

func TestCorethTransactionToTransactionRow_WithReceipt(t *testing.T) {
	t.Parallel()

	block := createTestBlockWithLogs()
	tx := block.Transactions[0] // This transaction has a receipt with 2 logs
	txIndex := uint64(0)

	txRow, err := CorethTransactionToTransactionRow(tx, block, txIndex)
	require.NoError(t, err)
	require.NotNil(t, txRow)

	assert.Equal(t, uint32(2), txRow.NumLogs) // 2 logs in the test receipt
}

func TestCorethTransactionToTransactionRow_NilBlockNumber(t *testing.T) {
	t.Parallel()

	block := createTestBlock()
	block.Number = nil
	tx := createTestTransaction()

	txRow, err := CorethTransactionToTransactionRow(tx, block, 0)
	require.NoError(t, err)
	require.NotNil(t, txRow)

	assert.Equal(t, uint64(0), txRow.BlockNumber)
}

// ============================================================================
// Process Tests
// ============================================================================

func TestProcess_NilMessage(t *testing.T) {
	t.Parallel()

	sugar := zap.NewNop().Sugar()
	proc := NewCorethProcessor(sugar, nil, nil, nil, nil, false, nil)

	err := proc.Process(t.Context(), nil)
	require.ErrorIs(t, err, ErrNilMessage)
}

func TestProcess_NilMessageValue(t *testing.T) {
	t.Parallel()

	sugar := zap.NewNop().Sugar()
	proc := NewCorethProcessor(sugar, nil, nil, nil, nil, false, nil)

	msg := &ckafka.Message{Value: nil}
	err := proc.Process(t.Context(), msg)
	require.ErrorIs(t, err, ErrNilMessage)
}

func TestProcess_InvalidJSON(t *testing.T) {
	t.Parallel()

	sugar := zap.NewNop().Sugar()
	proc := NewCorethProcessor(sugar, nil, nil, nil, nil, false, nil)

	msg := &ckafka.Message{Value: []byte(`{invalid json}`)}
	err := proc.Process(t.Context(), msg)

	require.ErrorIs(t, err, ErrUnmarshalBlock)
}

func TestProcess_MissingBlockchainID(t *testing.T) {
	t.Parallel()

	sugar := zap.NewNop().Sugar()
	proc := NewCorethProcessor(sugar, nil, nil, nil, nil, false, nil)

	block := &kafkamsg.EVMBlock{
		Number:       big.NewInt(1647),
		Hash:         testBlockHash,
		BlockchainID: nil,
		Transactions: []*kafkamsg.EVMTransaction{},
	}

	data, err := json.Marshal(block)
	require.NoError(t, err)

	msg := &ckafka.Message{Value: data}
	err = proc.Process(t.Context(), msg)
	require.ErrorIs(t, err, evmrepo.ErrBlockChainIDRequired)
}

func TestProcess_Success_NoRepos(t *testing.T) {
	t.Parallel()

	sugar := zap.NewNop().Sugar()
	proc := NewCorethProcessor(sugar, nil, nil, nil, nil, false, nil)

	block := createTestBlock()
	data, err := json.Marshal(block)
	require.NoError(t, err)

	msg := &ckafka.Message{Value: data}
	err = proc.Process(t.Context(), msg)
	require.NoError(t, err)
}

func TestProcess_Success_WithBlocksRepo(t *testing.T) {
	t.Parallel()

	sugar := zap.NewNop().Sugar()
	var capturedBlock *evmrepo.BlockRow
	blocksRepo := &mockBlocksRepo{
		writeBlockFunc: func(_ context.Context, blk *evmrepo.BlockRow) error {
			capturedBlock = blk
			return nil
		},
	}
	proc := NewCorethProcessor(sugar, blocksRepo, nil, nil, nil, false, nil)

	block := createTestBlock()
	data, err := json.Marshal(block)
	require.NoError(t, err)

	msg := &ckafka.Message{Value: data}
	err = proc.Process(t.Context(), msg)
	require.NoError(t, err)

	require.NotNil(t, capturedBlock)
	assert.Equal(t, testBlockchainID, *capturedBlock.BlockchainID)
	assert.Equal(t, testBlockHash, capturedBlock.Hash)
	assert.Equal(t, uint32(1), capturedBlock.NumTxns) // 1 transaction in the test block
}

func TestProcess_BlocksRepoError(t *testing.T) {
	t.Parallel()

	sugar := zap.NewNop().Sugar()
	expectedErr := errors.New("write block failed")
	blocksRepo := &mockBlocksRepo{
		writeBlockFunc: func(_ context.Context, _ *evmrepo.BlockRow) error {
			return expectedErr
		},
	}
	proc := NewCorethProcessor(sugar, blocksRepo, nil, nil, nil, false, nil)

	block := createTestBlock()
	data, err := json.Marshal(block)
	require.NoError(t, err)

	msg := &ckafka.Message{Value: data}
	err = proc.Process(t.Context(), msg)
	require.ErrorIs(t, err, expectedErr)
}

func TestProcess_Success_WithTransactionsRepo(t *testing.T) {
	t.Parallel()

	sugar := zap.NewNop().Sugar()
	var capturedTxs []*evmrepo.TransactionRow
	txsRepo := &mockTransactionsRepo{
		batchInsertTransactionsFunc: func(_ context.Context, txs []*evmrepo.TransactionRow) error {
			capturedTxs = append(capturedTxs, txs...)
			return nil
		},
	}
	proc := NewCorethProcessor(sugar, nil, txsRepo, nil, nil, true, nil)

	block := createTestBlock()
	data, err := json.Marshal(block)
	require.NoError(t, err)

	msg := &ckafka.Message{Value: data}
	err = proc.Process(t.Context(), msg)
	require.NoError(t, err)

	require.Len(t, capturedTxs, 1)
	assert.Equal(t, "0x55565758595a5b5c5d5e5f606162636465666768696a6b6c6d6e6f70717273", capturedTxs[0].Hash)
}

func TestProcess_TransactionsRepoError(t *testing.T) {
	t.Parallel()

	sugar := zap.NewNop().Sugar()
	expectedErr := errors.New("write transaction failed")
	txsRepo := &mockTransactionsRepo{
		batchInsertTransactionsFunc: func(_ context.Context, _ []*evmrepo.TransactionRow) error {
			return expectedErr
		},
	}
	proc := NewCorethProcessor(sugar, nil, txsRepo, nil, nil, true, nil)

	block := createTestBlock()
	data, err := json.Marshal(block)
	require.NoError(t, err)

	msg := &ckafka.Message{Value: data}
	err = proc.Process(t.Context(), msg)
	require.ErrorIs(t, err, expectedErr)
}

func TestProcess_Success_WithLogsRepo(t *testing.T) {
	t.Parallel()

	sugar := zap.NewNop().Sugar()
	var capturedLogs []*evmrepo.LogRow
	logsRepo := &mockLogsRepo{
		batchInsertLogsFunc: func(_ context.Context, logs []*evmrepo.LogRow) error {
			capturedLogs = append(capturedLogs, logs...)
			return nil
		},
	}
	proc := NewCorethProcessor(sugar, nil, nil, logsRepo, nil, true, nil)

	block := createTestBlockWithLogs()
	data, err := json.Marshal(block)
	require.NoError(t, err)

	msg := &ckafka.Message{Value: data}
	err = proc.Process(t.Context(), msg)
	require.NoError(t, err)

	require.Len(t, capturedLogs, 2)
}

func TestProcess_LogsRepoError(t *testing.T) {
	t.Parallel()

	sugar := zap.NewNop().Sugar()
	expectedErr := errors.New("write log failed")
	logsRepo := &mockLogsRepo{
		batchInsertLogsFunc: func(_ context.Context, _ []*evmrepo.LogRow) error {
			return expectedErr
		},
	}
	proc := NewCorethProcessor(sugar, nil, nil, logsRepo, nil, true, nil)

	block := createTestBlockWithLogs()
	data, err := json.Marshal(block)
	require.NoError(t, err)

	msg := &ckafka.Message{Value: data}
	err = proc.Process(t.Context(), msg)
	require.ErrorIs(t, err, expectedErr)
}

func TestProcess_NoTransactions_SkipsRepos(t *testing.T) {
	t.Parallel()

	sugar := zap.NewNop().Sugar()
	txsRepoCalled := false
	logsRepoCalled := false

	txsRepo := &mockTransactionsRepo{
		batchInsertTransactionsFunc: func(_ context.Context, _ []*evmrepo.TransactionRow) error {
			txsRepoCalled = true
			return nil
		},
	}
	logsRepo := &mockLogsRepo{
		batchInsertLogsFunc: func(_ context.Context, _ []*evmrepo.LogRow) error {
			logsRepoCalled = true
			return nil
		},
	}
	proc := NewCorethProcessor(sugar, nil, txsRepo, logsRepo, nil, false, nil)

	block := createTestBlock()
	block.Transactions = []*kafkamsg.EVMTransaction{} // No transactions
	data, err := json.Marshal(block)
	require.NoError(t, err)

	msg := &ckafka.Message{Value: data}
	err = proc.Process(t.Context(), msg)
	require.NoError(t, err)

	assert.False(t, txsRepoCalled, "transactions repo should not be called")
	assert.False(t, logsRepoCalled, "logs repo should not be called")
}

// ============================================================================
// Repository Delete Method Tests
// ============================================================================

func TestMockBlocksRepo_DeleteBlocks_Success(t *testing.T) {
	t.Parallel()

	deleteCalled := false
	var capturedChainID uint64

	blocksRepo := &mockBlocksRepo{
		deleteBlocksFunc: func(_ context.Context, chainID uint64) error {
			deleteCalled = true
			capturedChainID = chainID
			return nil
		},
	}

	err := blocksRepo.DeleteBlocks(t.Context(), 43114)
	require.NoError(t, err)
	assert.True(t, deleteCalled)
	assert.Equal(t, uint64(43114), capturedChainID)
}

func TestMockBlocksRepo_DeleteBlocks_Error(t *testing.T) {
	t.Parallel()

	expectedErr := errors.New("delete blocks failed")
	blocksRepo := &mockBlocksRepo{
		deleteBlocksFunc: func(_ context.Context, _ uint64) error {
			return expectedErr
		},
	}

	err := blocksRepo.DeleteBlocks(t.Context(), 43114)
	require.ErrorIs(t, err, expectedErr)
}

func TestMockBlocksRepo_DeleteBlocks_NilFunc(t *testing.T) {
	t.Parallel()

	blocksRepo := &mockBlocksRepo{
		deleteBlocksFunc: nil, // No function set
	}

	err := blocksRepo.DeleteBlocks(t.Context(), 43114)
	require.NoError(t, err, "should return nil when deleteBlocksFunc is not set")
}

func TestMockTransactionsRepo_DeleteTransactions_Success(t *testing.T) {
	t.Parallel()

	deleteCalled := false
	var capturedChainID uint64

	txsRepo := &mockTransactionsRepo{
		deleteTransactionsFunc: func(_ context.Context, chainID uint64) error {
			deleteCalled = true
			capturedChainID = chainID
			return nil
		},
	}

	err := txsRepo.DeleteTransactions(t.Context(), 43114)
	require.NoError(t, err)
	assert.True(t, deleteCalled)
	assert.Equal(t, uint64(43114), capturedChainID)
}

func TestMockTransactionsRepo_DeleteTransactions_Error(t *testing.T) {
	t.Parallel()

	expectedErr := errors.New("delete transactions failed")
	txsRepo := &mockTransactionsRepo{
		deleteTransactionsFunc: func(_ context.Context, _ uint64) error {
			return expectedErr
		},
	}

	err := txsRepo.DeleteTransactions(t.Context(), 43114)
	require.ErrorIs(t, err, expectedErr)
}

func TestMockTransactionsRepo_DeleteTransactions_NilFunc(t *testing.T) {
	t.Parallel()

	txsRepo := &mockTransactionsRepo{
		deleteTransactionsFunc: nil, // No function set
	}

	err := txsRepo.DeleteTransactions(t.Context(), 43114)
	require.NoError(t, err, "should return nil when deleteTransactionsFunc is not set")
}

func TestMockLogsRepo_DeleteLogs_Success(t *testing.T) {
	t.Parallel()

	deleteCalled := false
	var capturedChainID uint64

	logsRepo := &mockLogsRepo{
		deleteLogsFunc: func(_ context.Context, chainID uint64) error {
			deleteCalled = true
			capturedChainID = chainID
			return nil
		},
	}

	err := logsRepo.DeleteLogs(t.Context(), 43114)
	require.NoError(t, err)
	assert.True(t, deleteCalled)
	assert.Equal(t, uint64(43114), capturedChainID)
}

func TestMockLogsRepo_DeleteLogs_Error(t *testing.T) {
	t.Parallel()

	expectedErr := errors.New("delete logs failed")
	logsRepo := &mockLogsRepo{
		deleteLogsFunc: func(_ context.Context, _ uint64) error {
			return expectedErr
		},
	}

	err := logsRepo.DeleteLogs(t.Context(), 43114)
	require.ErrorIs(t, err, expectedErr)
}

func TestMockLogsRepo_DeleteLogs_NilFunc(t *testing.T) {
	t.Parallel()

	logsRepo := &mockLogsRepo{
		deleteLogsFunc: nil, // No function set
	}

	err := logsRepo.DeleteLogs(t.Context(), 43114)
	require.NoError(t, err, "should return nil when deleteLogsFunc is not set")
}

// ============================================================================
// classifyWriteErr Tests
// ============================================================================

func TestClassifyWriteErr_FatalCodes(t *testing.T) {
	t.Parallel()

	fatalCodes := []struct {
		code int32
		name string
	}{
		{clickhouseErrAuthenticationFailed, "AUTHENTICATION_FAILED"},
		{clickhouseErrAccessDenied, "ACCESS_DENIED"},
		{clickhouseErrUnknownTable, "UNKNOWN_TABLE"},
		{clickhouseErrUnknownDatabase, "UNKNOWN_DATABASE"},
	}

	for _, tc := range fatalCodes {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			chErr := &chdriver.Exception{Code: tc.code, Message: tc.name}
			err := classifyWriteErr(chErr)
			assert.True(t, IsFatal(err), "code %d (%s) should be classified as fatal", tc.code, tc.name)
			assert.ErrorIs(t, err, chErr)
		})
	}
}

func TestClassifyWriteErr_RetryableCodes(t *testing.T) {
	t.Parallel()

	retryableCodes := []struct {
		code int32
		name string
	}{
		{159, "TIMEOUT_EXCEEDED"},
		{242, "TABLE_IS_READ_ONLY"},
		{999, "UNKNOWN_CODE"},
	}

	for _, tc := range retryableCodes {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			chErr := &chdriver.Exception{Code: tc.code, Message: tc.name}
			err := classifyWriteErr(chErr)
			assert.False(t, IsFatal(err), "code %d (%s) should NOT be fatal", tc.code, tc.name)
			assert.ErrorIs(t, err, chErr)
		})
	}
}

func TestClassifyWriteErr_NonClickHouseError(t *testing.T) {
	t.Parallel()

	plainErr := errors.New("connection reset")
	err := classifyWriteErr(plainErr)
	assert.False(t, IsFatal(err))
	assert.ErrorIs(t, err, plainErr, "non-ClickHouse errors should pass through unchanged")
}

func TestClassifyWriteErr_WrappedClickHouseError(t *testing.T) {
	t.Parallel()

	chErr := &chdriver.Exception{Code: clickhouseErrAuthenticationFailed, Message: "auth failed"}
	wrapped := fmt.Errorf("write block: %w", chErr)
	err := classifyWriteErr(wrapped)
	assert.True(t, IsFatal(err), "wrapped ClickHouse fatal error should be classified as fatal")
	assert.ErrorIs(t, err, chErr)
}

// ============================================================================
// Process Error Classification Tests
// ============================================================================

func TestProcess_NilMessage_IsNonRetryable(t *testing.T) {
	t.Parallel()

	proc := NewCorethProcessor(zap.NewNop().Sugar(), nil, nil, nil, nil, false, nil)

	err := proc.Process(t.Context(), nil)
	require.ErrorIs(t, err, ErrNilMessage)
	assert.True(t, IsNonRetryable(err), "nil message should be NonRetryable")
}

func TestProcess_InvalidJSON_IsNonRetryable(t *testing.T) {
	t.Parallel()

	proc := NewCorethProcessor(zap.NewNop().Sugar(), nil, nil, nil, nil, false, nil)

	msg := &ckafka.Message{Value: []byte(`{bad}`)}
	err := proc.Process(t.Context(), msg)
	require.ErrorIs(t, err, ErrUnmarshalBlock)
	assert.True(t, IsNonRetryable(err), "unmarshal failure should be NonRetryable")
}

func TestProcess_MissingBlockchainID_IsNonRetryable(t *testing.T) {
	t.Parallel()

	proc := NewCorethProcessor(zap.NewNop().Sugar(), nil, nil, nil, nil, false, nil)

	block := &kafkamsg.EVMBlock{
		Number:       big.NewInt(1),
		BlockchainID: nil,
		Transactions: []*kafkamsg.EVMTransaction{},
	}
	data, err := json.Marshal(block)
	require.NoError(t, err)

	msg := &ckafka.Message{Value: data}
	err = proc.Process(t.Context(), msg)
	require.ErrorIs(t, err, evmrepo.ErrBlockChainIDRequired)
	assert.True(t, IsNonRetryable(err), "missing blockchainID should be NonRetryable")
}

func TestProcess_BlockWriteFatal(t *testing.T) {
	t.Parallel()

	chErr := &chdriver.Exception{Code: clickhouseErrAuthenticationFailed, Message: "auth failed"}
	blocksRepo := &mockBlocksRepo{
		writeBlockFunc: func(_ context.Context, _ *evmrepo.BlockRow) error {
			return chErr
		},
	}
	proc := NewCorethProcessor(zap.NewNop().Sugar(), blocksRepo, nil, nil, nil, false, nil)

	block := createTestBlock()
	data, err := json.Marshal(block)
	require.NoError(t, err)

	msg := &ckafka.Message{Value: data}
	err = proc.Process(t.Context(), msg)
	assert.True(t, IsFatal(err), "auth failure on block write should be Fatal")
	assert.ErrorIs(t, err, chErr)
}

func TestProcess_BlockWriteRetryable(t *testing.T) {
	t.Parallel()

	transientErr := errors.New("connection timeout")
	blocksRepo := &mockBlocksRepo{
		writeBlockFunc: func(_ context.Context, _ *evmrepo.BlockRow) error {
			return transientErr
		},
	}
	proc := NewCorethProcessor(zap.NewNop().Sugar(), blocksRepo, nil, nil, nil, false, nil)

	block := createTestBlock()
	data, err := json.Marshal(block)
	require.NoError(t, err)

	msg := &ckafka.Message{Value: data}
	err = proc.Process(t.Context(), msg)
	assert.False(t, IsFatal(err), "transient error should NOT be Fatal")
	assert.False(t, IsNonRetryable(err), "transient error should NOT be NonRetryable")
	assert.ErrorIs(t, err, transientErr)
}

func TestProcess_TransactionWriteFatal(t *testing.T) {
	t.Parallel()

	chErr := &chdriver.Exception{Code: clickhouseErrUnknownTable, Message: "unknown table"}
	txsRepo := &mockTransactionsRepo{
		batchInsertTransactionsFunc: func(_ context.Context, _ []*evmrepo.TransactionRow) error {
			return chErr
		},
	}
	proc := NewCorethProcessor(zap.NewNop().Sugar(), nil, txsRepo, nil, nil, true, nil)

	block := createTestBlock()
	data, err := json.Marshal(block)
	require.NoError(t, err)

	msg := &ckafka.Message{Value: data}
	err = proc.Process(t.Context(), msg)
	assert.True(t, IsFatal(err), "unknown table on tx write should be Fatal")
	assert.ErrorIs(t, err, chErr)
}

func TestProcess_LogWriteFatal(t *testing.T) {
	t.Parallel()

	chErr := &chdriver.Exception{Code: clickhouseErrUnknownDatabase, Message: "unknown db"}
	logsRepo := &mockLogsRepo{
		batchInsertLogsFunc: func(_ context.Context, _ []*evmrepo.LogRow) error {
			return chErr
		},
	}
	proc := NewCorethProcessor(zap.NewNop().Sugar(), nil, nil, logsRepo, nil, true, nil)

	block := createTestBlockWithLogs()
	data, err := json.Marshal(block)
	require.NoError(t, err)

	msg := &ckafka.Message{Value: data}
	err = proc.Process(t.Context(), msg)
	assert.True(t, IsFatal(err), "unknown database on log write should be Fatal")
	assert.ErrorIs(t, err, chErr)
}

// ============================================================================
// Helper Functions
// ============================================================================

func createTestBlock() *kafkamsg.EVMBlock {
	blockchainID := testBlockchainID
	return &kafkamsg.EVMBlock{
		BlockchainID:     &blockchainID,
		EVMChainID:       big.NewInt(43113),
		Number:           big.NewInt(1647),
		Hash:             testBlockHash,
		ParentHash:       "0x2122232425262728292a2b2c2d2e2f303132333435363738393a3b3c3d3e3f40",
		Timestamp:        1604768510,
		TimestampMs:      1604768510000,
		Size:             1331,
		GasLimit:         20006296,
		GasUsed:          183061,
		Difficulty:       big.NewInt(1),
		Nonce:            42,
		Miner:            "0x4142434445464748494a4b4c4d4e4f5051525354",
		StateRoot:        testBlockHash,
		TransactionsRoot: testBlockHash,
		ReceiptsRoot:     testBlockHash,
		UncleHash:        testBlockHash,
		MixHash:          testBlockHash,
		ExtraData:        "0xd883010916846765746888676f312e31332e38856c696e7578236a756571a22fb6b759507d25baa07790e2dcb952924471d436785469db4655",
		BaseFee:          big.NewInt(470000000000),
		Transactions: []*kafkamsg.EVMTransaction{
			{
				Hash:     "0x55565758595a5b5c5d5e5f606162636465666768696a6b6c6d6e6f70717273",
				From:     "0x4142434445464748494a4b4c4d4e4f5051525354",
				To:       "0x55565758595a5b5c5d5e5f6061626364656667",
				Nonce:    1,
				Value:    big.NewInt(1000000000000000000),
				Gas:      21000,
				GasPrice: big.NewInt(470000000000),
			},
		},
	}
}

func createTestBlockWithLogs() *kafkamsg.EVMBlock {
	block := createTestBlock()
	block.Transactions[0].Receipt = &kafkamsg.EVMTxReceipt{
		Status:  1,
		GasUsed: 21000,
		Logs: []*kafkamsg.EVMLog{
			createTestLog(),
			{
				Address:     common.HexToAddress("0x55565758595a5b5c5d5e5f6061626364656667"),
				Topics:      []common.Hash{common.HexToHash("0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef")},
				Data:        []byte{0x01, 0x02, 0x03},
				BlockNumber: 1647,
				TxHash:      common.HexToHash("0x55565758595a5b5c5d5e5f606162636465666768696a6b6c6d6e6f70717273"),
				TxIndex:     0,
				BlockHash:   common.HexToHash(testBlockHash),
				Index:       1,
				Removed:     false,
			},
		},
	}
	return block
}

func createTestTransaction() *kafkamsg.EVMTransaction {
	return &kafkamsg.EVMTransaction{
		Hash:     "0x55565758595a5b5c5d5e5f606162636465666768696a6b6c6d6e6f70717273",
		From:     "0x4142434445464748494a4b4c4d4e4f5051525354",
		To:       "0x55565758595a5b5c5d5e5f6061626364656667",
		Nonce:    1,
		Value:    big.NewInt(1000000000000000000),
		Gas:      21000,
		GasPrice: big.NewInt(470000000000),
	}
}

func createTestLog() *kafkamsg.EVMLog {
	return &kafkamsg.EVMLog{
		Address: common.HexToAddress("0x4142434445464748494a4b4c4d4e4f5051525354"),
		Topics: []common.Hash{
			common.HexToHash("0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"),
			common.HexToHash("0x0000000000000000000000004142434445464748494a4b4c4d4e4f5051525354"),
			common.HexToHash("0x00000000000000000000000055565758595a5b5c5d5e5f6061626364656667"),
		},
		Data:        []byte{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
		BlockNumber: 1647,
		TxHash:      common.HexToHash("0x55565758595a5b5c5d5e5f606162636465666768696a6b6c6d6e6f70717273"),
		TxIndex:     0,
		BlockHash:   common.HexToHash(testBlockHash),
		Index:       0,
		Removed:     false,
	}
}
