# EvmNetworkOptions

## Example Usage

```typescript
import { EvmNetworkOptions } from "@avalanche-sdk/chainkit/models/components";

let value: EvmNetworkOptions = {
  addresses: [],
  includeChains: [
    "43114",
  ],
};
```

## Fields

| Field              | Type               | Required           | Description        | Example            |
| ------------------ | ------------------ | ------------------ | ------------------ | ------------------ |
| `addresses`        | *string*[]         | :heavy_check_mark: | N/A                |                    |
| `includeChains`    | *string*[]         | :heavy_check_mark: | N/A                | [<br/>"43114"<br/>] |