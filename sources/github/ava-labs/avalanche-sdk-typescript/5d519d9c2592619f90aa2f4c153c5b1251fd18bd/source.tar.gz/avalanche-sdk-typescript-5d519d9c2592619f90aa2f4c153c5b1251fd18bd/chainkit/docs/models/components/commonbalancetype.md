# CommonBalanceType

Type of balance to monitor

## Example Usage

```typescript
import { CommonBalanceType } from "@avalanche-sdk/chainkit/models/components";

let value: CommonBalanceType = "atomicMemoryUnlocked";
```

## Values

```typescript
"unlockedUnstaked" | "unlockedStaked" | "lockedPlatform" | "lockedStakeable" | "lockedStaked" | "pendingStaked" | "unlocked" | "locked" | "atomicMemoryUnlocked" | "atomicMemoryLocked"
```