# GetSubnetByIdRequest

## Example Usage

```typescript
import { GetSubnetByIdRequest } from "@avalanche-sdk/chainkit/models/operations";

let value: GetSubnetByIdRequest = {
  subnetId: "11111111111111111111111111111111LpoYY",
};
```

## Fields

| Field                                                                          | Type                                                                           | Required                                                                       | Description                                                                    | Example                                                                        |
| ------------------------------------------------------------------------------ | ------------------------------------------------------------------------------ | ------------------------------------------------------------------------------ | ------------------------------------------------------------------------------ | ------------------------------------------------------------------------------ |
| `network`                                                                      | [components.GlobalParamNetwork](../../models/components/globalparamnetwork.md) | :heavy_minus_sign:                                                             | Either mainnet or testnet/fuji.                                                | mainnet                                                                        |
| `subnetId`                                                                     | *string*                                                                       | :heavy_check_mark:                                                             | Subnet ID to fetch details for                                                 | 11111111111111111111111111111111LpoYY                                          |