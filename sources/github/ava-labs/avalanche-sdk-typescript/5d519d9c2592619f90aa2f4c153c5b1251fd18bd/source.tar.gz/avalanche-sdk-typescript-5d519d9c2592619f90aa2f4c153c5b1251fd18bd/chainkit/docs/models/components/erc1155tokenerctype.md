# Erc1155TokenErcType

## Example Usage

```typescript
import { Erc1155TokenErcType } from "@avalanche-sdk/chainkit/models/components";

let value: Erc1155TokenErcType = "ERC-1155";
```

## Values

```typescript
"ERC-1155"
```