# ResourceLinkType

## Example Usage

```typescript
import { ResourceLinkType } from "@avalanche-sdk/chainkit/models/components";

let value: ResourceLinkType = "Telegram";
```

## Values

```typescript
"Blog" | "CoinGecko" | "CoinMarketCap" | "Discord" | "Documentation" | "Facebook" | "Github" | "Instagram" | "LinkedIn" | "Medium" | "Reddit" | "Support" | "Telegram" | "TikTok" | "Twitter" | "Website" | "Whitepaper" | "Youtube"
```