# HealthIndicatorResultDto

## Example Usage

```typescript
import { HealthIndicatorResultDto } from "@avalanche-sdk/chainkit/models/components";

let value: HealthIndicatorResultDto = {};
```

## Fields

| Field                                                                                                  | Type                                                                                                   | Required                                                                                               | Description                                                                                            |
| ------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------ |
| `status`                                                                                               | [components.HealthIndicatorResultDtoStatus](../../models/components/healthindicatorresultdtostatus.md) | :heavy_minus_sign:                                                                                     | Status of the health indicator.                                                                        |