# GetAddressesFromWebhookResponse

## Example Usage

```typescript
import { GetAddressesFromWebhookResponse } from "@avalanche-sdk/chainkit/models/operations";

let value: GetAddressesFromWebhookResponse = {
  result: {
    addresses: [
      "<value 1>",
      "<value 2>",
      "<value 3>",
    ],
    totalAddresses: 1227.61,
  },
};
```

## Fields

| Field                                                                                              | Type                                                                                               | Required                                                                                           | Description                                                                                        |
| -------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| `result`                                                                                           | [components.ListWebhookAddressesResponse](../../models/components/listwebhookaddressesresponse.md) | :heavy_check_mark:                                                                                 | N/A                                                                                                |