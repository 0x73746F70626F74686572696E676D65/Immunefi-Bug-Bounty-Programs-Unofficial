# DeliveredSourceNotIndexedTeleporterMessageStatus

## Example Usage

```typescript
import { DeliveredSourceNotIndexedTeleporterMessageStatus } from "@avalanche-sdk/chainkit/models/components";

let value: DeliveredSourceNotIndexedTeleporterMessageStatus =
  "delivered_source_not_indexed";
```

## Values

```typescript
"delivered_source_not_indexed"
```