# GetLastActivityTimestampByAddressesRequest

## Example Usage

```typescript
import { GetLastActivityTimestampByAddressesRequest } from "@avalanche-sdk/chainkit/models/operations";

let value: GetLastActivityTimestampByAddressesRequest = {
  addresses: "avax1h2ccj9f5ay5acl6tyn9mwmw32p8wref8vl8ctg",
  blockchainId: "p-chain",
};
```

## Fields

| Field                                                                                                                               | Type                                                                                                                                | Required                                                                                                                            | Description                                                                                                                         | Example                                                                                                                             |
| ----------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| `addresses`                                                                                                                         | *string*                                                                                                                            | :heavy_minus_sign:                                                                                                                  | A comma separated list of X-Chain or P-Chain wallet addresses, starting with "avax"/"fuji", "P-avax"/"P-fuji" or "X-avax"/"X-fuji". | avax1h2ccj9f5ay5acl6tyn9mwmw32p8wref8vl8ctg                                                                                         |
| `blockchainId`                                                                                                                      | [components.BlockchainId](../../models/components/blockchainid.md)                                                                  | :heavy_check_mark:                                                                                                                  | A primary network blockchain id or alias.                                                                                           | p-chain                                                                                                                             |
| `network`                                                                                                                           | [components.GlobalParamNetwork](../../models/components/globalparamnetwork.md)                                                      | :heavy_minus_sign:                                                                                                                  | Either mainnet or testnet/fuji.                                                                                                     | mainnet                                                                                                                             |