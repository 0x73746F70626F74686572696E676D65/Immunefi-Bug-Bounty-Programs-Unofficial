# TeleporterRewardDetailsErcType

## Example Usage

```typescript
import { TeleporterRewardDetailsErcType } from "@avalanche-sdk/chainkit/models/components";

let value: TeleporterRewardDetailsErcType = "ERC-20";
```

## Values

```typescript
"ERC-20"
```