# ChainMetric

## Example Usage

```typescript
import { ChainMetric } from "@avalanche-sdk/chainkit/models/components";

let value: ChainMetric = "activeAddresses";
```

## Values

```typescript
"activeAddresses" | "activeSenders" | "cumulativeTxCount" | "cumulativeAddresses" | "cumulativeContracts" | "cumulativeDeployers" | "contracts" | "deployers" | "gasUsed" | "txCount" | "avgGps" | "maxGps" | "avgTps" | "maxTps" | "avgGasPrice" | "maxGasPrice" | "feesPaid"
```