# IcmReceipt

## Example Usage

```typescript
import { IcmReceipt } from "@avalanche-sdk/chainkit/models/components";

let value: IcmReceipt = {
  receivedMessageNonce: "<value>",
  relayerRewardAddress: "<value>",
};
```

## Fields

| Field                  | Type                   | Required               | Description            |
| ---------------------- | ---------------------- | ---------------------- | ---------------------- |
| `receivedMessageNonce` | *string*               | :heavy_check_mark:     | N/A                    |
| `relayerRewardAddress` | *string*               | :heavy_check_mark:     | N/A                    |