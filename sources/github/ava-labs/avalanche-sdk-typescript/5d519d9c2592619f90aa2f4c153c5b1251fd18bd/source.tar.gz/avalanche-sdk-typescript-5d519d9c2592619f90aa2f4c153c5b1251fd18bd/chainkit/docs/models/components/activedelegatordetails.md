# ActiveDelegatorDetails

## Example Usage

```typescript
import { ActiveDelegatorDetails } from "@avalanche-sdk/chainkit/models/components";

let value: ActiveDelegatorDetails = {
  txHash: "<value>",
  nodeId: "<id>",
  rewardAddresses: [
    "<value 1>",
  ],
  amountDelegated: "<value>",
  delegationFee: "<value>",
  startTimestamp: 1058.92,
  endTimestamp: 337.36,
  estimatedGrossReward: "<value>",
  estimatedNetReward: "<value>",
  delegationStatus: "active",
};
```

## Fields

| Field                  | Type                   | Required               | Description            |
| ---------------------- | ---------------------- | ---------------------- | ---------------------- |
| `txHash`               | *string*               | :heavy_check_mark:     | N/A                    |
| `nodeId`               | *string*               | :heavy_check_mark:     | N/A                    |
| `rewardAddresses`      | *string*[]             | :heavy_check_mark:     | N/A                    |
| `amountDelegated`      | *string*               | :heavy_check_mark:     | N/A                    |
| `delegationFee`        | *string*               | :heavy_check_mark:     | N/A                    |
| `startTimestamp`       | *number*               | :heavy_check_mark:     | N/A                    |
| `endTimestamp`         | *number*               | :heavy_check_mark:     | N/A                    |
| `estimatedGrossReward` | *string*               | :heavy_check_mark:     | N/A                    |
| `estimatedNetReward`   | *string*               | :heavy_check_mark:     | N/A                    |
| `delegationStatus`     | *"active"*             | :heavy_check_mark:     | N/A                    |