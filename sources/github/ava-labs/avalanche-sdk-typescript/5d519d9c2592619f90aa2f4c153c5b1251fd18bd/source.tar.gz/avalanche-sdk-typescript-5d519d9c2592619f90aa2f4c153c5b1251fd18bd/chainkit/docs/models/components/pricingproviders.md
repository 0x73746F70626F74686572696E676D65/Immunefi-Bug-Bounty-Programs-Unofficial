# PricingProviders

## Example Usage

```typescript
import { PricingProviders } from "@avalanche-sdk/chainkit/models/components";

let value: PricingProviders = {};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `coingeckoCoinId`  | *string*           | :heavy_minus_sign: | N/A                |