# OperationType

## Example Usage

```typescript
import { OperationType } from "@avalanche-sdk/chainkit/models/components";

let value: OperationType = "TRANSACTION_EXPORT_PRIMARY_NETWORK_STAKING";
```

## Values

```typescript
"TRANSACTION_EXPORT_PRIMARY_NETWORK" | "TRANSACTION_EXPORT_PRIMARY_NETWORK_STAKING" | "TRANSACTION_EXPORT_PRIMARY_NETWORK_SIMPLE" | "TRANSACTION_EXPORT_EVM"
```