# BlsCredentials

## Example Usage

```typescript
import { BlsCredentials } from "@avalanche-sdk/chainkit/models/components";

let value: BlsCredentials = {
  publicKey: "<value>",
  proofOfPossession: "<value>",
};
```

## Fields

| Field               | Type                | Required            | Description         |
| ------------------- | ------------------- | ------------------- | ------------------- |
| `publicKey`         | *string*            | :heavy_check_mark:  | N/A                 |
| `proofOfPossession` | *string*            | :heavy_check_mark:  | N/A                 |