# ListAllLatestTransactionsResponse

## Example Usage

```typescript
import { ListAllLatestTransactionsResponse } from "@avalanche-sdk/chainkit/models/operations";

let value: ListAllLatestTransactionsResponse = {
  result: {
    transactions: [],
  },
};
```

## Fields

| Field                                                                                                  | Type                                                                                                   | Required                                                                                               | Description                                                                                            |
| ------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------ |
| `result`                                                                                               | [components.ListNativeTransactionsResponse](../../models/components/listnativetransactionsresponse.md) | :heavy_check_mark:                                                                                     | N/A                                                                                                    |