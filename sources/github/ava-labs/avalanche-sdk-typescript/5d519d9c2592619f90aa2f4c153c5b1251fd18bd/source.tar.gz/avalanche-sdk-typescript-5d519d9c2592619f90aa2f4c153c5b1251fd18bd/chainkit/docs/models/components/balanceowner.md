# BalanceOwner

## Example Usage

```typescript
import { BalanceOwner } from "@avalanche-sdk/chainkit/models/components";

let value: BalanceOwner = {
  addresses: [
    "<value 1>",
    "<value 2>",
  ],
  threshold: 328.11,
};
```

## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `addresses`        | *string*[]         | :heavy_check_mark: | N/A                |
| `threshold`        | *number*           | :heavy_check_mark: | N/A                |