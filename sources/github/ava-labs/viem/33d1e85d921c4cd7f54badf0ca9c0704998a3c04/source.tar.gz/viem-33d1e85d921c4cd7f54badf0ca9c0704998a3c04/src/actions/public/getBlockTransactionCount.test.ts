import { beforeAll, expect, test } from 'vitest'

import { accounts, forkBlockNumber } from '../../_test/constants.js'
import { publicClient, testClient, walletClient } from '../../_test/utils.js'
import { parseEther } from '../../utils/unit/parseEther.js'
import { mine } from '../test/mine.js'
import { setIntervalMining } from '../test/setIntervalMining.js'
import { sendTransaction } from '../wallet/sendTransaction.js'

import { getBlock } from './getBlock.js'
import { getBlockTransactionCount } from './getBlockTransactionCount.js'

await beforeAll(async () => {
  await setIntervalMining(testClient, { interval: 0 })
})

test('default', async () => {
  expect(await getBlockTransactionCount(publicClient)).toBeDefined()
})

test('args: blockNumber', async () => {
  expect(
    await getBlockTransactionCount(publicClient, {
      blockNumber: forkBlockNumber - 1n,
    }),
  ).toBe(120)
})

test('args: blockHash', async () => {
  const block = await getBlock(publicClient, {
    blockNumber: forkBlockNumber - 1n,
  })
  expect(
    await getBlockTransactionCount(publicClient, {
      blockHash: block.hash!,
    }),
  ).toBe(120)
})

test('args: blockTag', async () => {
  await mine(testClient, { blocks: 1 })
  expect(
    await getBlockTransactionCount(publicClient, {
      blockTag: 'latest',
    }),
  ).toBe(0)
  await sendTransaction(walletClient, {
    account: accounts[0].address,
    to: accounts[1].address,
    value: parseEther('1'),
  })
  await mine(testClient, { blocks: 1 })
  expect(
    await getBlockTransactionCount(publicClient, {
      blockTag: 'latest',
    }),
  ).toBe(1)
})
