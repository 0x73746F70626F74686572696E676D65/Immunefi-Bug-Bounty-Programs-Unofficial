import { TokenUnit } from '@avalabs/core-utils-sdk';
import {
  ButtonProps,
  CircularProgress,
  Collapse,
  Grow,
  Stack,
  useTheme,
} from '@avalabs/k2-alpine';
import {
  FC,
  FocusEventHandler,
  ReactNode,
  useCallback,
  useEffect,
  useMemo,
  useRef,
} from 'react';
import { isNil } from 'lodash';
import { useTranslation } from 'react-i18next';

import { stringToBigint } from '@core/common';
import { FungibleTokenBalance, getUniqueTokenId } from '@core/types';
import { useConvertedCurrencyFormatter } from '@core/ui';

import { TokenSelect } from '@/components/TokenSelect';
import { ChainFilterMode } from '@/components/TokenSelect/types';
import { type ChainOption } from '@/components/TokenSelect/components/ChainFilterChips';

import { AmountPresetButton, InvisibleAmountInput } from './components';

type TokenAmountInputProps = {
  id: string;
  'data-testid'?: string;
  estimatedFee?: bigint;
  alwaysApplyFee?: boolean;
  tokenId: string;
  tokensForAccount: FungibleTokenBalance[];
  onTokenChange: (token: string) => void;
  tokenQuery: string;
  onQueryChange: (tokenQuery: string) => void;
  amount: string;
  maxAmount?: bigint;
  minAmount?: bigint;
  withPresetButtons?: boolean;
  tokenHint?: string;
  autoFocus?: boolean;
  isLoading?: boolean;
  onFocus?: FocusEventHandler;
  onBlur?: FocusEventHandler;
  disabled?: boolean;
  chainFilterMode?: ChainFilterMode;
  presetButtonsStartSlot?: ReactNode;
  presetButtonSx?: ButtonProps['sx'];
  onEndReached?: () => void;
  defaultChainId?: number | 'avalanche' | null;
  externalChainOptions?: ChainOption[];
  onChainChange?: (chainId: number | 'avalanche' | null) => void;
  selectedChainId?: number | 'avalanche' | null;
  onOpenChange?: (isOpen: boolean) => void;
  isLoadingTokens?: boolean;
  selectedTokenFallback?: FungibleTokenBalance;
} & AmountInputProps;

type AmountInputProps =
  | {
      isAmountReadOnly?: undefined;
      onAmountChange?: (amount: string, isMax: boolean) => void;
    }
  | {
      isAmountReadOnly?: never;
      onAmountChange?: (amount: string, isMax: boolean) => void;
    }
  | {
      isAmountReadOnly: false;
      onAmountChange: (amount: string, isMax: boolean) => void;
    }
  | {
      isAmountReadOnly: true;
      onAmountChange?: never;
    };

export const TokenAmountInput: FC<TokenAmountInputProps> = ({
  id,
  'data-testid': testId,
  maxAmount,
  minAmount = 0n,
  estimatedFee,
  alwaysApplyFee,
  tokenId,
  tokensForAccount,
  onTokenChange,
  tokenQuery,
  onQueryChange,
  amount,
  onAmountChange,
  isAmountReadOnly,
  withPresetButtons = true,
  tokenHint,
  autoFocus = true,
  isLoading = false,
  onFocus,
  onBlur,
  disabled,
  chainFilterMode,
  presetButtonsStartSlot,
  presetButtonSx,
  onEndReached,
  defaultChainId,
  externalChainOptions,
  onChainChange,
  selectedChainId,
  onOpenChange,
  isLoadingTokens,
  selectedTokenFallback,
}) => {
  const { t } = useTranslation();
  const theme = useTheme();
  const convertedCurrencyFormatter = useConvertedCurrencyFormatter();
  const amountInputRef = useRef<HTMLInputElement>(null);
  const previousTokenIdRef = useRef<string>(tokenId);

  const token = useMemo(
    () =>
      tokensForAccount.find((tok) => getUniqueTokenId(tok) === tokenId) ??
      selectedTokenFallback,
    [tokensForAccount, tokenId, selectedTokenFallback],
  );

  // Auto-focus the input when a token is selected for THIS specific component
  // Only focus when tokenId changes (not just when token exists)
  useEffect(() => {
    const tokenIdChanged = previousTokenIdRef.current !== tokenId;
    if (tokenIdChanged && token && amountInputRef.current) {
      // Use a small delay to ensure the Grow animation has started (the props seem to be not fix the issue)
      const timeoutId = setTimeout(() => {
        if (amountInputRef.current) {
          amountInputRef.current.focus();
        }
      }, 100);
      previousTokenIdRef.current = tokenId;
      return () => clearTimeout(timeoutId);
    } else if (tokenIdChanged) {
      previousTokenIdRef.current = tokenId;
    }
  }, [tokenId, token]);

  // Amount comes in as a string, we need to convert it to BigInt for computation
  const amountHasValue =
    Number.isFinite(parseFloat(amount)) && parseFloat(amount) !== 0;
  const amountBigInt =
    token && amountHasValue ? stringToBigint(amount, token.decimals) : 0n;

  const isAmountTooBig = token && maxAmount ? amountBigInt > maxAmount : false;

  // Apply a 50% buffer to the estimated fee to account for fee increases during congestion (can jump between 75nAVAX and 225nAVAX), we need to multiply by 3n and divide by 2n to get the 50% buffer.
  const estimatedFeeWithBuffer = useCallback((fee?: bigint) => {
    if (!fee) return 0n;
    return fee ? (fee * 3n) / 2n : 0n;
  }, []);

  const handlePresetClick = useCallback(
    (percentage: number) => {
      if (!token || isNil(maxAmount)) return;

      // Prefer maxAmount (fee-adjusted / balance-capped) over raw token.balance so
      // presets stay correct for HyperCore withdrawable and native fee reserves.
      const tokenUnit = new TokenUnit(maxAmount, token.decimals, token.symbol);

      // maxAmount from Swap/Send is already fee-adjusted; only subtract again when
      // a caller explicitly opts in via alwaysApplyFee.
      const shouldSubtractFee = Boolean(alwaysApplyFee);
      const amountToSubtract = shouldSubtractFee
        ? estimatedFeeWithBuffer(estimatedFee)
        : 0n;
      const calculatedMaxAmount = tokenUnit
        .div(100 / percentage)
        .sub(new TokenUnit(amountToSubtract, token.decimals, token.symbol));

      // Make sure we never seem silly by telling the user to send a negative amount.
      onAmountChange?.(
        calculatedMaxAmount.lt(0n) ? '0' : calculatedMaxAmount.toString(),
        percentage === 100,
      );
    },
    [
      token,
      maxAmount,
      alwaysApplyFee,
      estimatedFee,
      onAmountChange,
      estimatedFeeWithBuffer,
    ],
  );

  const usdValue =
    token && token.priceInCurrency && amountHasValue
      ? new TokenUnit(amountBigInt, token.decimals, token.symbol).toDisplay({
          asNumber: true,
        }) * token.priceInCurrency
      : undefined;

  const currencyValue =
    typeof usdValue === 'number'
      ? convertedCurrencyFormatter(usdValue)
      : undefined;

  const arePresetButtonsDisabled =
    isLoading || disabled || !token || !maxAmount || maxAmount <= 0n;

  return (
    <Stack py={1} px={1.5} gap={1} data-testid={testId}>
      <Stack
        id={id}
        display="grid"
        alignItems="center"
        gridTemplateColumns={token ? 'auto minmax(35%, 1fr)' : '1fr'}
        gap={1}
        width="100%"
      >
        <TokenSelect
          id={`${id}-token-select`}
          tokenId={tokenId}
          tokenList={tokensForAccount}
          onValueChange={(selectedTokenId) => {
            onTokenChange(selectedTokenId);
          }}
          query={tokenQuery}
          onQueryChange={onQueryChange}
          hint={tokenHint}
          disabled={disabled}
          chainFilterMode={chainFilterMode}
          onEndReached={onEndReached}
          defaultChainId={defaultChainId}
          externalChainOptions={externalChainOptions}
          onChainChange={onChainChange}
          selectedChainId={selectedChainId}
          onOpenChange={onOpenChange}
          isLoadingTokens={isLoadingTokens}
          selectedTokenFallback={selectedTokenFallback}
        />
        <Grow in={Boolean(token)} mountOnEnter unmountOnExit>
          <InvisibleAmountInput
            data-testid="send-amount-input"
            autoFocus={autoFocus}
            placeholder={(0).toFixed(2)}
            onChange={(ev) => onAmountChange?.(ev.target.value, false)}
            error={Boolean(isAmountTooBig) || amountBigInt < minAmount}
            helperText={
              isLoading ? <CircularProgress size={12} /> : currencyValue || '-'
            }
            slotProps={{
              htmlInput: {
                ref: amountInputRef,
                ...(testId && {
                  'data-testid': `${testId}-amount`,
                }),
              },
              input: {
                onFocus,
                onBlur,
                disabled: disabled || isAmountReadOnly,
              },
            }}
            value={amount}
          />
        </Grow>
      </Stack>
      <Collapse
        in={withPresetButtons && Boolean(token) && !isAmountReadOnly}
        mountOnEnter
        unmountOnExit
      >
        <Stack
          direction="row"
          width="100%"
          justifyContent={presetButtonsStartSlot ? 'space-between' : 'end'}
          alignItems="center"
          gap={1}
          onFocus={onFocus}
          onBlur={onBlur}
          sx={{
            opacity: isLoading ? 0.35 : 1,
            transition: theme.transitions.create('opacity'),
          }}
        >
          {presetButtonsStartSlot}
          <Stack direction="row" alignItems="center" gap={1}>
            <AmountPresetButton
              onClick={() => handlePresetClick(25)}
              disabled={arePresetButtonsDisabled}
              sx={presetButtonSx}
            >
              {t('25%')}
            </AmountPresetButton>
            <AmountPresetButton
              onClick={() => handlePresetClick(50)}
              disabled={arePresetButtonsDisabled}
              sx={presetButtonSx}
            >
              {t('50%')}
            </AmountPresetButton>
            <AmountPresetButton
              data-testid="amount-preset-max"
              onClick={() => handlePresetClick(100)}
              disabled={arePresetButtonsDisabled}
              sx={presetButtonSx}
            >
              {t('Max')}
            </AmountPresetButton>
          </Stack>
        </Stack>
      </Collapse>
    </Stack>
  );
};
