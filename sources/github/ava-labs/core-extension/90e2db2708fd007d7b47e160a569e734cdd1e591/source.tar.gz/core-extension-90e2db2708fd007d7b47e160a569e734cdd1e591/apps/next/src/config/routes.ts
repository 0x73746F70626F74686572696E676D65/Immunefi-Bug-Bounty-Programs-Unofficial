import { generatePath } from 'react-router-dom';

/**
 * Contacts
 **/
export const CONTACTS_QUERY_TOKENS = {
  id: 'id',
  search: 'q',
  sort: 's',
};
export type ContactQueryTokens = typeof CONTACTS_QUERY_TOKENS;
export const getContactsPath = (
  view?: 'list' | 'details' | 'remove' | 'add',
  query?: Partial<ContactQueryTokens>,
) => {
  const pathname = generatePath('/contacts/:view?', { view });
  const search = new URLSearchParams(query);
  const searchString = search.toString();

  if (!searchString) {
    return pathname;
  }

  return `${pathname}?${searchString}`;
};

/**
 * Send
 **/
export const SEND_QUERY_TOKENS = {
  fromQuery: 'fromQ',
  to: 'to',
  toQuery: 'toQ',
  token: 'token',
  tokenQuery: 'tokenQ',
  amount: 'amount',
};
export type SendQueryTokens = typeof SEND_QUERY_TOKENS;
export const getSendPath = (query?: Partial<SendQueryTokens>) => {
  const pathname = generatePath('/send');
  const search = new URLSearchParams(query);
  const searchString = search.toString();

  if (!searchString) {
    return pathname;
  }

  return `${pathname}?${searchString}`;
};

/**
 * Wallet View
 **/
export const ACCOUNT_MANAGEMENT_QUERY_TOKENS = {
  showImportSuccess: 'showImportSuccess',
} as const;

/**
 * Swap
 **/
export const FUSION_QUERY_TOKENS = {
  from: 'from',
  fromQuery: 'fromQ',
  to: 'to',
  toQuery: 'toQ',
  userAmount: 'userAmount',
  isRecurring: 'recurring',
};
export type FusionQueryTokens = typeof FUSION_QUERY_TOKENS;
export const getFusionPath = (query?: Partial<FusionQueryTokens>) => {
  const pathname = generatePath('/fusion');
  const search = new URLSearchParams(query);
  const searchString = search.toString();

  if (!searchString) {
    return pathname;
  }

  return `${pathname}?${searchString}`;
};

export const getRecurringSwapsPath = () => generatePath('/fusion/recurring');
