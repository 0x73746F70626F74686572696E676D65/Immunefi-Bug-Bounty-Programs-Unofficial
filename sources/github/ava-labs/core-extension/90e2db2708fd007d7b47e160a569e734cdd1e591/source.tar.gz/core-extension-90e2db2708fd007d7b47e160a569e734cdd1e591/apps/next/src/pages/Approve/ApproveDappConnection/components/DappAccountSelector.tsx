import { Stack, Typography } from '@avalabs/k2-alpine';
import { FC, useCallback, useEffect } from 'react';
import { Trans, useTranslation } from 'react-i18next';

import { Account, Action, ActionStatus } from '@core/types';

import { NoScrollStack } from '@/components/NoScrollStack';
import { useDappScansCache } from '@/hooks/useDappScansCache';

import { ActionDrawer, LoadingScreen, NoteWarning } from '../../components';
import { ActionError, CancelActionFn, UpdateActionFn } from '../../types';

import { AlertType } from '@avalabs/vm-module-types';
import { isPrimaryAccount } from '@core/common';
import { ConnectWalletCard, SizedAvatar } from '../components';
import { useDappPermissionsState } from '../hooks';
import { sanitizeDappUrl } from '../lib';
import { ConnectDappDisplayData } from '../types';

type DappAccountSelectorProps = {
  activeAccount: Account;
  action: Action<ConnectDappDisplayData>;
  updateAction: UpdateActionFn;
  cancelHandler: CancelActionFn;
  error: ActionError;
};

export const DappAccountSelector: FC<DappAccountSelectorProps> = ({
  action,
  updateAction,
  cancelHandler,
  activeAccount,
}) => {
  const { t } = useTranslation();
  const {
    wallets,
    isLoading,
    selectedAccountId,
    selectAccount,
    numberOfSelectedAccounts,
  } = useDappPermissionsState(activeAccount, action.displayData);
  const { storeMaliciousDappDomain } = useDappScansCache();

  const onApproveClicked = useCallback(async () => {
    // If the app is malicious, save this data for later use.
    if (action.displayData.isMalicious) {
      storeMaliciousDappDomain(action.displayData.dappDomain);
    }

    updateAction({
      status: ActionStatus.SUBMITTING,
      id: action.actionId,
      result: [{ id: selectedAccountId, enabled: true }],
    });
  }, [
    selectedAccountId,
    updateAction,
    action.actionId,
    action.displayData.dappDomain,
    action.displayData.isMalicious,
    storeMaliciousDappDomain,
  ]);

  useEffect(() => {
    if (action.displayData.canSkipApproval) {
      onApproveClicked();
    }
  }, [action.displayData.canSkipApproval, onApproveClicked]);

  if (action.displayData.canSkipApproval) {
    return <LoadingScreen />;
  }

  return (
    <NoScrollStack stackProps={{ mt: 5 }}>
      <Stack px={2} alignItems="center" gap={3}>
        <SizedAvatar size={60} src={action.displayData.dappIcon} />
        <Typography variant="body3" mx={5} textAlign="center">
          <Trans
            i18nKey="Do you want to allow <b>{{dappUrl}}</b> to access your wallet?"
            components={{
              b: <b />,
            }}
            values={{
              dappUrl: sanitizeDappUrl(action.displayData.dappUrl),
            }}
          />
        </Typography>
      </Stack>
      {action.displayData.isMalicious && (
        <Stack mt={2}>
          <NoteWarning
            alert={{
              type: AlertType.DANGER,
              details: {
                title: t('Scam application'),
                description: t(
                  'Use caution, this application might be malicious.',
                ),
              },
            }}
          />
        </Stack>
      )}
      <Stack width="100%" gap={1.5} mt={1.5} flexGrow={1} px={2}>
        {wallets.map((wallet) => (
          <ConnectWalletCard
            key={wallet.id}
            wallet={wallet}
            initiallyExpanded
            numberOfSelectedAccounts={numberOfSelectedAccounts}
            selectedAccountId={selectedAccountId}
            selectAccount={selectAccount}
            isLoading={isLoading}
            isActiveWallet={
              isPrimaryAccount(activeAccount) &&
              wallet.id === activeAccount.walletId
            }
          />
        ))}
      </Stack>
      <ActionDrawer
        open
        approve={onApproveClicked}
        reject={cancelHandler}
        isProcessing={action.status === ActionStatus.SUBMITTING}
        isDisabled={!numberOfSelectedAccounts}
        approveText={t('Connect')}
      />
    </NoScrollStack>
  );
};
