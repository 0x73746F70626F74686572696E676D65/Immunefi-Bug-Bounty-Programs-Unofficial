export * from './DetailsItem';
