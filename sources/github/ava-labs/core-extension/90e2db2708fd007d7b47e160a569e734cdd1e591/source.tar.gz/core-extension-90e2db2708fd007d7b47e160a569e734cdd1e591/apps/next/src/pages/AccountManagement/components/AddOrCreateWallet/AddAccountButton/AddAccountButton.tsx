import AddIcon from '@/components/AddIcon';
import { Button, Stack } from '@avalabs/k2-alpine';
import { toast } from '@core/ui';
import {
  LedgerAppType,
  useAccountsContext,
  useActiveLedgerAppInfo,
  useAnalyticsContext,
  useIsCorrectDeviceForActiveWallet,
  useIsUsingKeystoneWallet,
  useLedgerContext,
  useWalletContext,
} from '@core/ui';
import { FC, Fragment } from 'react';
import { useTranslation } from 'react-i18next';
import { LedgerTooltip } from './components/LedgerTooltip';

export const AddAccountButton: FC = () => {
  const { t } = useTranslation();
  const { capture } = useAnalyticsContext();
  const { addAccount, selectAccount } = useAccountsContext();
  const { walletDetails, isLedgerWallet } = useWalletContext();
  const { hasLedgerTransport } = useLedgerContext();
  const { appType } = useActiveLedgerAppInfo();
  const status = useIsCorrectDeviceForActiveWallet();
  const isUsingKeystoneWallet = useIsUsingKeystoneWallet();

  const canAddNewAccount =
    !isLedgerWallet ||
    (hasLedgerTransport &&
      appType === LedgerAppType.AVALANCHE &&
      status === 'correct');

  const TooltipWrapper = canAddNewAccount ? Fragment : LedgerTooltip;

  return (
    <TooltipWrapper>
      <Stack marginTop={1} alignItems="center" justifyContent="center">
        <Button
          variant="contained"
          color="secondary"
          size="small"
          data-testid="add-account-button"
          disabled={!canAddNewAccount}
          onClick={() => {
            if (isUsingKeystoneWallet) {
              toast.error(t('Keystone support has been deprecated'));
              return;
            }

            addAccount()
              .then(selectAccount)
              .then(() => {
                toast.success(t('Account created successfully'));
                capture('CreatedANewAccountSuccessfully', {
                  walletType: walletDetails?.type,
                });
              })
              .catch((error) => {
                toast.error(t('Account creation failed'));
                console.error(error);
              });
          }}
        >
          <AddIcon size={12} />
          {t('Add account')}
        </Button>
      </Stack>
    </TooltipWrapper>
  );
};
