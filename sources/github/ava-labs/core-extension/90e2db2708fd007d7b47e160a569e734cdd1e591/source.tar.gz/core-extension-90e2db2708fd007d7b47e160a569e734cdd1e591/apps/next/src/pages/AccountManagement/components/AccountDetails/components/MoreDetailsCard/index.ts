export * from './MoreDetailsCard';
