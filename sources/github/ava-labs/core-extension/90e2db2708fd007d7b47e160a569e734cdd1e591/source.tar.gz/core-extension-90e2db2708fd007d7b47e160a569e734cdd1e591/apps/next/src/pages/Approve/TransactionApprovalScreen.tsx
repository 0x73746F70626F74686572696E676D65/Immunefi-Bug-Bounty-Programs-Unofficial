import { Stack } from '@avalabs/k2-alpine';
import { TokenType } from '@avalabs/vm-module-types';
import { FC, useCallback, useEffect, useRef } from 'react';

import { isDirectLedgerHyperEvmTransactionUnsupported } from '@core/common';
import { ActionStatus, GaslessPhase, NetworkWithCaipId } from '@core/types';
import { useLiveBalance, useWalletContext } from '@core/ui';
import { useTranslation } from 'react-i18next';

import { NoScrollStack } from '@/components/NoScrollStack';
import { SimulationAlertBox } from '@/components/SimulationAlertBox';
import { useIsUsingHardwareWallet } from '@/hooks/useIsUsingHardwareWallet';

import {
  ActionDetails,
  ActionDrawer,
  ApprovalContextNote,
  ApprovalScreenTitle,
  HardwareApprovalOverlay,
  MaliciousTxOverlay,
  NoteWarning,
  Styled,
} from './components';
import { TxDataUpdateProvider, useTxDataUpdate } from './contexts';
import { useApprovalHelpers, useGasless } from './hooks';
import {
  getRecurringSwapsNote,
  hasNoteWarning,
  hasOverlayWarning,
  hasRecurringSwapsContext,
} from './lib';
import {
  ActionError,
  CancelActionFn,
  TransactionSigningRequest,
  UpdateActionFn,
} from './types';

const POLLED_BALANCES = [
  TokenType.NATIVE,
  TokenType.ERC20,
  TokenType.HYPERCORE_SPOT,
]; // Approval screen should always have the latest balance

type TransactionApprovalScreenProps = {
  action: TransactionSigningRequest;
  network: NetworkWithCaipId;
  updateAction: UpdateActionFn;
  cancelHandler: CancelActionFn;
  error: ActionError;
};

export const TransactionApprovalScreen: FC<TransactionApprovalScreenProps> = (
  props,
) => (
  <TxDataUpdateProvider>
    <TransactionApprovalScreenContent {...props} />
  </TxDataUpdateProvider>
);

const TransactionApprovalScreenContent: FC<TransactionApprovalScreenProps> = ({
  action,
  network,
  updateAction,
  cancelHandler,
  error,
}) => {
  const { t } = useTranslation();
  const gaslessUnavailable = useRef<boolean>(false);

  useLiveBalance(POLLED_BALANCES);

  const { isUsingHardwareWallet, deviceType } = useIsUsingHardwareWallet();
  const { walletDetails } = useWalletContext();
  const { isUpdating: isUpdatingTxData } = useTxDataUpdate();
  const isDirectLedgerHyperEvmTransactionBlocked =
    isDirectLedgerHyperEvmTransactionUnsupported(network, walletDetails?.type);

  const { tryFunding, setGaslessDefaultValues, gaslessPhase } = useGasless({
    action,
  });

  const approve = useCallback(async () => {
    updateAction(
      {
        status: ActionStatus.SUBMITTING,
        id: action.actionId,
      },
      isUsingHardwareWallet,
    );
  }, [updateAction, action.actionId, isUsingHardwareWallet]);

  const cancel = useCallback(() => {
    // Reset the gasless state
    setGaslessDefaultValues();
    cancelHandler();
  }, [cancelHandler, setGaslessDefaultValues]);

  const { isApprovalOverlayVisible, handleApproval, handleRejection } =
    useApprovalHelpers({
      isUsingHardwareWallet,
      deviceType,
      onApprove: approve,
      onReject: cancel,
    });

  useEffect(() => {
    if (gaslessPhase === GaslessPhase.ERROR) {
      gaslessUnavailable.current = true;
    }
  }, [gaslessPhase]);

  const isProcessing =
    action.status === ActionStatus.SUBMITTING ||
    gaslessPhase === GaslessPhase.FUNDING_IN_PROGRESS;
  const showGaslessErrorMessage =
    gaslessPhase === GaslessPhase.ERROR || gaslessUnavailable.current;

  return (
    <Styled.ApprovalScreenPage data-testid="approval-screen">
      <NoScrollStack stackProps={{ sx: { mt: 3 } }}>
        <ApprovalScreenTitle title={action.displayData.title} />
        {hasRecurringSwapsContext(action.context) && (
          <ApprovalContextNote
            {...getRecurringSwapsNote(action.context.recurringSwaps, t)}
          />
        )}
        {hasNoteWarning(action) && (
          <NoteWarning alert={action.displayData.alert} />
        )}
        {showGaslessErrorMessage && (
          <Stack px={2} mt={1.5} mb={1.5}>
            <SimulationAlertBox
              textLines={[
                t(
                  'Core was unable to fund the gas. You will need to pay the fee for this transaction.',
                ),
              ]}
            />
          </Stack>
        )}
        {isDirectLedgerHyperEvmTransactionBlocked && (
          <Stack px={2} mt={1.5} mb={1.5}>
            <SimulationAlertBox
              textLines={[
                t(
                  'Transactions on HyperEVM are not supported for Ledger wallets.',
                ),
              ]}
            />
          </Stack>
        )}
        <Stack flexGrow={1} px={2}>
          <ActionDetails
            network={network}
            action={action}
            updateAction={updateAction}
            error={error}
          />
        </Stack>
        <ActionDrawer
          open
          approve={() => tryFunding(handleApproval)}
          reject={handleRejection}
          isProcessing={isProcessing}
          isDisabled={
            isUpdatingTxData || isDirectLedgerHyperEvmTransactionBlocked
          }
          withConfirmationSwitch={hasOverlayWarning(action)}
        />
      </NoScrollStack>
      {hasOverlayWarning(action) && (
        <MaliciousTxOverlay
          open={hasOverlayWarning(action)}
          cancelHandler={cancelHandler}
          alert={action.displayData.alert}
        />
      )}
      {isUsingHardwareWallet && isApprovalOverlayVisible && deviceType && (
        <HardwareApprovalOverlay
          deviceType={deviceType}
          action={action}
          network={network}
          approve={approve}
          reject={cancel}
        />
      )}
    </Styled.ApprovalScreenPage>
  );
};
