import { NoScrollStack } from '@/components/NoScrollStack';
import { Avatar, Button, Stack, styled, useTheme } from '@avalabs/k2-alpine';
import { FC } from 'react';
import { useTranslation } from 'react-i18next';

export type ChainOption = {
  chainId: number | 'avalanche';
  chainName: string;
  logoUri?: string;
};

type ChainFilterChipsProps = {
  chainOptions: ChainOption[];
  selectedChainId: number | 'avalanche' | null;
  onChainSelect: (chainId: number | 'avalanche' | null) => void;
  showAllNetworksChip?: boolean;
};

const ChipsContainer = styled(Stack)(({ theme }) => ({
  padding: theme.spacing(1, 2),
  gap: theme.spacing(1),
  flexWrap: 'wrap',
}));

const FilterChip = styled(Button)<{ selected?: boolean }>(
  ({ theme, selected }) => ({
    minWidth: 'auto',
    height: '24px',
    padding: theme.spacing(0.5, 1),
    borderRadius: parseInt(theme.shape.borderRadius.toString(), 10) * 4,
    textTransform: 'none',
    fontSize: theme.typography.body2.fontSize,
    fontWeight: theme.typography.fontWeightSemiBold,
    backgroundColor: selected
      ? theme.palette.primary.main
      : theme.palette.background.paper,
    color: selected
      ? theme.palette.primary.contrastText
      : theme.palette.text.primary,
    gap: theme.spacing(0.5),
    border: '0px solid transparent',
    display: 'flex',
    alignItems: 'center',
    flexShrink: 0, // Prevent chips from shrinking when scrolling
    whiteSpace: 'nowrap', // Prevent text from wrapping
    '&:hover': {
      backgroundColor: selected
        ? theme.palette.primary.main
        : theme.palette.action.hover,
    },
  }),
);

const ChainLogo = styled(Avatar)({
  width: 12,
  height: 12,
  backgroundColor: 'transparent',
});

export const ChainFilterChips: FC<ChainFilterChipsProps> = ({
  chainOptions,
  selectedChainId,
  onChainSelect,
  showAllNetworksChip = true,
}) => {
  const { t } = useTranslation();
  const theme = useTheme();

  const renderChainLogo = (
    chainId: number | 'avalanche',
    chainName: string,
  ) => {
    // Special handling for Avalanche (merged networks - c-x-p)
    if (chainId === 'avalanche') {
      const mainLogo = chainOptions.find(
        (option) => option.chainId === 'avalanche',
      )?.logoUri;
      if (!mainLogo) {
        return null;
      }
      return <ChainLogo src={mainLogo} alt={chainName} variant="circular" />;
    }

    const logoUri = chainOptions.find(
      (option) => option.chainId === chainId,
    )?.logoUri;

    if (!logoUri) {
      return null;
    }

    return <ChainLogo src={logoUri} alt={chainName} variant="circular" />;
  };

  return (
    <NoScrollStack
      autoHide
      autoHeight
      autoHeightMin={theme.spacing(10)}
      autoHeightMax={theme.spacing(12)}
      style={{
        borderBottom: `1px solid ${theme.palette.divider}`,
      }}
    >
      <ChipsContainer direction="row">
        {showAllNetworksChip && (
          <FilterChip
            selected={selectedChainId === null}
            onClick={() => onChainSelect(null)}
            variant="outlined"
            size="small"
          >
            {t('All networks')}
          </FilterChip>
        )}
        {chainOptions.map(({ chainId, chainName }) => (
          <FilterChip
            key={chainId}
            selected={selectedChainId === chainId}
            onClick={() => onChainSelect(chainId)}
            variant="outlined"
            size="small"
          >
            {renderChainLogo(chainId, chainName)}
            {chainName}
          </FilterChip>
        ))}
      </ChipsContainer>
    </NoScrollStack>
  );
};
