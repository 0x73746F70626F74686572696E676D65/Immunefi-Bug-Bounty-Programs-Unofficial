import { Stack } from '@avalabs/k2-alpine';
import { DisplayData } from '@avalabs/vm-module-types';

import { Action, EnsureDefined, EvmNetwork } from '@core/types';

import { ActionDetailsProps } from '../../../types';
import { DetailsItem } from '../generic/DetailsItem';
import { DetailsSection } from '../generic/DetailsSection';
import { TransactionBalanceChange } from '../generic/TransactionBalanceChange';

import { EvmTokenApprovals } from './EvmTokenApprovals';
import { EvmNetworkFeeWidget } from './EvmNetworkFeeWidget';
import { EvmNftDisplay } from './EvmNftDisplay';
import { isNftTokenType } from '@core/common';
import { NoScrollStack } from '@/components/NoScrollStack';

type EvmActionDetailsProps = Omit<ActionDetailsProps, 'network'> & {
  network: EvmNetwork;
};

export const EvmActionDetails = ({
  action,
  network,
  disableGasless,
}: EvmActionDetailsProps) => {
  // Extract NFTs from balanceChange outs (NFTs being sent/received)
  const nftDiffs =
    action.displayData.balanceChange?.outs.filter((diff) => {
      if ('type' in diff.token) {
        return isNftTokenType(diff.token.type);
      }
      return false;
    }) ?? [];

  return (
    <Stack gap={1}>
      {nftDiffs.length > 0 && (
        <NoScrollStack
          autoHide
          autoHeight
          autoHeightMin={120}
          autoHeightMax={120}
          stackProps={{
            direction: 'row',
            gap: 1,
          }}
        >
          <EvmNftDisplay nftDiffs={nftDiffs} network={network} />
        </NoScrollStack>
      )}
      <TransactionBalanceChange
        ins={action.displayData.balanceChange?.ins ?? []}
        outs={action.displayData.balanceChange?.outs ?? []}
        isSimulationSuccessful={action.displayData.isSimulationSuccessful}
      />
      {hasTokenApprovals(action) && (
        <EvmTokenApprovals action={action} network={network} />
      )}
      {action.displayData.details.map((section) => (
        <DetailsSection key={section.title}>
          {section.items.map((item, index) => (
            <DetailsItem key={index} item={item} network={network} />
          ))}
        </DetailsSection>
      ))}
      {action.displayData.networkFeeSelector && (
        <EvmNetworkFeeWidget
          action={action}
          network={network}
          disableGasless={disableGasless}
        />
      )}
    </Stack>
  );
};

const hasTokenApprovals = (
  action: Action<DisplayData>,
): action is Action<EnsureDefined<DisplayData, 'tokenApprovals'>> => {
  return (
    action.displayData.tokenApprovals !== undefined &&
    action.displayData.tokenApprovals.approvals.some(
      (approval) => approval.value !== undefined,
    )
  );
};
