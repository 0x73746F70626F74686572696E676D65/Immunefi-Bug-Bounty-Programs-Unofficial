#!/usr/bin/env bash
# Copyright (C) 2023, Ava Labs, Inc. All rights reserved.
# See the file LICENSE for licensing terms.

set -eo pipefail

BASE_PATH=$(
  cd "$(dirname "${BASH_SOURCE[0]}")"
  cd .. && pwd
)

# Pass in the full name of the dependency.
# Parses go.mod for a matching entry and extracts the version number.
function getDepVersion() {
    grep -m1 "^\s*$1" $BASE_PATH/go.mod | cut -d ' ' -f2
}

function extract_commit() {
  local version=$1

  # Regex for a commit hash (assumed to be a 12+ character hex string)
  commit_hash_regex="-([0-9a-f]{12,})$"

  if [[ "$version" =~ $commit_hash_regex ]]; then
      # Extract the substring after the last '-'
      version=${BASH_REMATCH[1]}
  fi
  echo "$version"
}

# This needs to be exported to be picked up by the dockerfile.
export GO_VERSION=${GO_VERSION:-$(getDepVersion go)}
# Don't export them as they're used in the context of other calls

# Currently using an instrumented version for testing; differs from the version in go.mod
# AVALANCHEGO_VERSION=${AVALANCHEGO_VERSION:-$(extract_commit "$(getDepVersion github.com/ava-labs/avalanchego)")}
AVALANCHEGO_VERSION=${AVALANCHEGO_VERSION:-cf35cc4cbf6254b02593fbf3b0276a4f8da96272}
LIBEVM_VERSION=${LIBEVM_VERSION:-$(extract_commit "$(getDepVersion github.com/ava-labs/libevm)")}

# Extract the Solidity version from foundry.toml
AVALANCHE_ICM_PATH=${BASE_PATH}/icm-contracts/avalanche
AVALANCHE_SOLIDITY_VERSION=$(awk -v profile=default -v key=solc_version -f scripts/parse_config.awk foundry.toml)
AVALANCHE_EVM_VERSION=$(awk -v profile=default -v key=evm_version -f scripts/parse_config.awk foundry.toml)
ETHEREUM_ICM_PATH=${BASE_PATH}/icm-contracts/ethereum
ETHEREUM_SOLIDITY_VERSION=$(awk -v profile=ethereum -v key=solc_version -f scripts/parse_config.awk foundry.toml)
ETHEREUM_EVM_VERSION=$(awk -v profile=ethereum -v key=evm_version -f scripts/parse_config.awk foundry.toml)
COMMON_ICM_PATH=${BASE_PATH}/icm-contracts/common
COMMON_SOLIDITY_VERSION=$(awk -v profile=common -v key=solc_version -f scripts/parse_config.awk foundry.toml)
COMMON_EVM_VERSION=$(awk -v profile=common -v key=evm_version -f scripts/parse_config.awk foundry.toml)
