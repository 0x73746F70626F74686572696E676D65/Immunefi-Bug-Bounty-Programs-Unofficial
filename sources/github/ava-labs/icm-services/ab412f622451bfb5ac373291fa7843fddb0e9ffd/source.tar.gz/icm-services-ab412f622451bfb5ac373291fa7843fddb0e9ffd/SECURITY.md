# Security Policy

Avalanche takes the security of the platform and of its users very seriously. We and our community recognize the critical role of external security researchers and developers and welcome responsible disclosures. Valid reports will be eligible for a reward (terms and conditions apply).

## Reporting a Vulnerability

**Please do not file a public ticket** mentioning the vulnerability. To disclose a vulnerability submit it through our [Bug Bounty Program](https://immunefi.com/bug-bounty/avalanche/information/).

Vulnerabilities must be disclosed to us privately with reasonable time to respond, and avoid compromise of other users and accounts, or loss of funds that are not your own. We do not reward spam or social engineering vulnerabilities.

Do not test for or validate any security issues in the live Avalanche networks (Mainnet and Fuji testnet), confirm all exploits in a local private testnet.

Please refer to the [Bug Bounty Page](https://immunefi.com/bug-bounty/avalanche/information/) for the most up-to-date program rules and scope.

## Scope

Any contract code that doesn't have an audit or isn't released with a versioned tag should be considered incomplete and under active development and as such isn't in scope for the bug bounty program.

## Supported Versions

Please use the most recently released version to perform testing and to validate security issues.

## Audit Reports

All complete audit reports for the contracts in this repository can be found in the [audits](./audits/) directory.
