// Copyright (C) 2023, Ava Labs, Inc. All rights reserved.
// See the file LICENSE for licensing terms.

package utils

import (
	"bufio"
	"context"
	"crypto/ecdsa"
	"encoding/json"
	"errors"
	"fmt"
	"math/big"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"github.com/ava-labs/avalanchego/ids"
	"github.com/ava-labs/avalanchego/utils/logging"
	teleportermessengerv2 "github.com/ava-labs/icm-services/abi-bindings/go/TeleporterMessengerV2"
	teleportermessenger "github.com/ava-labs/icm-services/abi-bindings/go/teleporter/TeleporterMessenger"
	batchcrosschainmessenger "github.com/ava-labs/icm-services/abi-bindings/go/utilities/BatchCrossChainMessenger"
	"github.com/ava-labs/icm-services/config"
	testinfo "github.com/ava-labs/icm-services/icm-contracts/tests/test-info"
	offchainregistry "github.com/ava-labs/icm-services/messages/off-chain-registry"
	teleporterv2 "github.com/ava-labs/icm-services/messages/teleporterv2"
	relayercfg "github.com/ava-labs/icm-services/relayer/config"
	signatureaggregatorcfg "github.com/ava-labs/icm-services/signature-aggregator/config"
	relayerUtils "github.com/ava-labs/icm-services/utils"
	"github.com/ava-labs/libevm/accounts/abi/bind"
	"github.com/ava-labs/libevm/common"
	"github.com/ava-labs/libevm/core/types"
	"github.com/ava-labs/libevm/crypto"
	. "github.com/onsi/gomega"
	"go.uber.org/zap"
)

// Write the test database to /tmp since the data is not needed after the test
var StorageLocation = fmt.Sprintf("%s/.icm-relayer-storage", os.TempDir())

const (
	DefaultRelayerCfgFname             = "relayer-config.json"
	DefaultSignatureAggregatorCfgFname = "signature-aggregator-config.json"
	DBUpdateSeconds                    = 1
)

func BuildAllExecutables(ctx context.Context, log logging.Logger) {
	cmd := exec.Command("./scripts/build.sh")
	out, err := cmd.CombinedOutput()
	log.Info(string(out))
	Expect(err).Should(BeNil())
}

func RunRelayerExecutable(
	ctx context.Context,
	log logging.Logger,
	relayerConfigPath string,
	relayerConfig relayercfg.Config,
) (context.CancelFunc, chan struct{}) {
	relayerCtx, relayerCancel := context.WithCancel(ctx)
	relayerCmd := exec.CommandContext(relayerCtx, "./build/icm-relayer", "--config-file", relayerConfigPath)

	healthCheckURL := fmt.Sprintf("http://localhost:%d/health", relayerConfig.APIPort)

	readyChan := runExecutable(
		relayerCmd,
		relayerCtx,
		log,
		"icm-relayer",
		healthCheckURL,
	)
	return func() {
		relayerCancel()
		<-relayerCtx.Done()
	}, readyChan
}

func RunSignatureAggregatorExecutable(
	ctx context.Context,
	log logging.Logger,
	configPath string,
	config signatureaggregatorcfg.Config,
) (context.CancelFunc, chan struct{}) {
	aggregatorCtx, aggregatorCancel := context.WithCancel(ctx)
	signatureAggregatorCmd := exec.CommandContext(
		aggregatorCtx,
		"./build/signature-aggregator",
		"--config-file",
		configPath,
	)

	healthCheckURL := fmt.Sprintf("http://localhost:%d/health", config.APIPort)
	readyChan := runExecutable(
		signatureAggregatorCmd,
		aggregatorCtx,
		log,
		"signature-aggregator",
		healthCheckURL,
	)

	return func() {
		aggregatorCancel()
		<-aggregatorCtx.Done()
	}, readyChan
}

func ReadHexTextFile(filename string) string {
	fileData, err := os.ReadFile(filename)
	Expect(err).Should(BeNil())
	return strings.TrimRight(string(fileData), "\n")
}

// Constructs a relayer config with all subnets as sources and destinations
func CreateDefaultRelayerConfig(
	log logging.Logger,
	teleporter TeleporterTestInfo,
	sourceL1sInfo []testinfo.L1TestInfo,
	destinationL1sInfo []testinfo.L1TestInfo,
	fundedAddress common.Address,
	relayerKey *ecdsa.PrivateKey,
) relayercfg.Config {
	logLevel, err := logging.ToLevel(os.Getenv("LOG_LEVEL"))
	if err != nil {
		logLevel = logging.Info
	}

	log.Info("Setting up relayer config", zap.String("logLevel", logLevel.LowerString()))
	// Construct the config values for each subnet
	sources := make([]*relayercfg.SourceBlockchain, len(sourceL1sInfo))
	destinations := make([]*relayercfg.DestinationBlockchain, len(destinationL1sInfo))
	for i, l1Info := range sourceL1sInfo {
		host, port, err := GetURIHostAndPort(l1Info.NodeURIs[0])
		Expect(err).Should(BeNil())

		messageContracts := map[string]relayercfg.MessageProtocolConfig{
			offchainregistry.OffChainRegistrySourceAddress.Hex(): {
				MessageFormat: relayercfg.OFF_CHAIN_REGISTRY.String(),
				Settings: map[string]interface{}{
					"teleporter-registry-address": teleporter.TeleporterRegistryAddress(l1Info.BlockchainID).Hex(),
				},
			},
		}
		teleporterMessengerAddress := teleporter.TeleporterMessengerAddress(l1Info.BlockchainID)
		switch teleporter.TeleporterProtocol(l1Info.BlockchainID) {
		case TELEPORTER:
			messageContracts[teleporterMessengerAddress.Hex()] = relayercfg.MessageProtocolConfig{
				MessageFormat: relayercfg.TELEPORTER.String(),
				Settings: map[string]interface{}{
					"reward-address": fundedAddress.Hex(),
				},
			}
		case TELEPORTER_V2:
			// TeleporterV2 messages originate from the messenger's verifier adapter contract, so the
			// message contract entry is keyed by the adapter address. Only the WarpAdapter path is
			// configured here; Merkle registry tests construct their own configs.
			warpAdapterAddress := teleporter.WarpAdapterAddress(l1Info.BlockchainID)
			Expect(warpAdapterAddress).ShouldNot(Equal(common.Address{}))
			messageContracts[warpAdapterAddress.Hex()] = relayercfg.MessageProtocolConfig{
				MessageFormat: relayercfg.TELEPORTER_V2.String(),
				Settings: map[string]interface{}{
					"reward-address":     fundedAddress.Hex(),
					"verifier-type":      teleporterv2.VerifierTypeWarp,
					"teleporter-address": teleporterMessengerAddress.Hex(),
				},
			}
		}

		sources[i] = &relayercfg.SourceBlockchain{
			SubnetID:     l1Info.SubnetID.String(),
			BlockchainID: l1Info.BlockchainID.String(),
			RPCEndpoint: config.APIConfig{
				BaseURL: fmt.Sprintf("http://%s:%d/ext/bc/%s/rpc", host, port, l1Info.BlockchainID.String()),
			},
			WSEndpoint: config.APIConfig{
				BaseURL: fmt.Sprintf("ws://%s:%d/ext/bc/%s/ws", host, port, l1Info.BlockchainID.String()),
			},

			MessageContracts: messageContracts,
		}

		log.Info(
			"Creating relayer config for source subnet",
			zap.Stringer("subnetID", l1Info.SubnetID),
			zap.Stringer("blockchainID", l1Info.BlockchainID),
			zap.String("host", host),
			zap.Uint32("port", port),
		)
	}

	for i, l1Info := range destinationL1sInfo {
		host, port, err := GetURIHostAndPort(l1Info.NodeURIs[0])
		Expect(err).Should(BeNil())

		destinations[i] = &relayercfg.DestinationBlockchain{
			SubnetID:     l1Info.SubnetID.String(),
			BlockchainID: l1Info.BlockchainID.String(),
			RPCEndpoint: config.APIConfig{
				BaseURL: fmt.Sprintf("http://%s:%d/ext/bc/%s/rpc", host, port, l1Info.BlockchainID.String()),
			},
			AccountPrivateKeys: []string{relayerUtils.PrivateKeyToString(relayerKey)},
		}

		log.Info(
			"Creating relayer config for destination subnet",
			zap.Stringer("subnetID", l1Info.SubnetID),
			zap.Stringer("blockchainID", l1Info.BlockchainID),
			zap.String("host", host),
			zap.Uint32("port", port),
		)
	}

	return relayercfg.Config{
		LogLevel: logLevel.LowerString(),
		PChainAPI: &config.APIConfig{
			BaseURL: sourceL1sInfo[0].NodeURIs[0],
		},
		InfoAPI: &config.APIConfig{
			BaseURL: sourceL1sInfo[0].NodeURIs[0],
		},
		StorageLocation:                 StorageLocation,
		DBWriteIntervalSeconds:          DBUpdateSeconds,
		ProcessMissedBlocks:             false,
		MetricsPort:                     9090,
		SourceBlockchains:               sources,
		DestinationBlockchains:          destinations,
		APIPort:                         8080,
		SignatureCacheSize:              (1024 * 1024),
		AllowPrivateIPs:                 true,
		InitialConnectionTimeoutSeconds: 300,
		MaxConcurrentMessages:           250,
		// Refresh tracked validators frequently so tests that restarted nodes
		// re-establish connections quickly.
		ValidatorRefreshPeriodSeconds: 5,
	}
}

// TODO: convert this function to be just "applySubnetsInfoToConfig" and have
// callers use the defaults defined in the config package via viper, so that
// there aren't two sets of "defaults".
func CreateDefaultSignatureAggregatorConfig(
	log logging.Logger,
	sourceL1Info []testinfo.L1TestInfo,
) signatureaggregatorcfg.Config {
	logLevel, err := logging.ToLevel(os.Getenv("LOG_LEVEL"))
	if err != nil {
		logLevel = logging.Info
	}

	log.Info(
		"Setting up signature aggregator config",
		zap.String("logLevel", logLevel.LowerString()),
	)
	// Construct the config values for each subnet
	return signatureaggregatorcfg.Config{
		LogLevel: logLevel.LowerString(),
		PChainAPI: &config.APIConfig{
			BaseURL: sourceL1Info[0].NodeURIs[0],
		},
		InfoAPI: &config.APIConfig{
			BaseURL: sourceL1Info[0].NodeURIs[0],
		},
		APIPort:            8080,
		MetricsPort:        8081,
		SignatureCacheSize: (1024 * 1024),
		AllowPrivateIPs:    true,
		MaxPChainLookback:  -1,
		// Refresh tracked validators frequently so tests that restarted nodes
		// re-establish connections quickly.
		ValidatorRefreshPeriodSeconds: 5,
	}
}

func ClearRelayerStorage() error {
	return os.RemoveAll(StorageLocation)
}

func FundRelayers(
	ctx context.Context,
	subnetsInfo []testinfo.L1TestInfo,
	fundedKey *ecdsa.PrivateKey,
	relayerKey *ecdsa.PrivateKey,
) {
	relayerAddress := crypto.PubkeyToAddress(relayerKey.PublicKey)
	fundAmount := big.NewInt(0).Mul(big.NewInt(1e18), big.NewInt(10)) // 10eth

	for _, subnetInfo := range subnetsInfo {
		fundRelayerTx := CreateNativeTransferTransaction(
			ctx, &subnetInfo.EVMTestInfo, fundedKey, relayerAddress, fundAmount,
		)
		SendTransactionAndWaitForSuccess(ctx, subnetInfo.EthClient, fundRelayerTx)
	}
}

func SendBasicTeleporterMessageAsync(
	ctx context.Context,
	log logging.Logger,
	teleporter TeleporterTestInfo,
	source testinfo.L1TestInfo,
	destination testinfo.L1TestInfo,
	fundedKey *ecdsa.PrivateKey,
	destinationAddress common.Address,
	ids chan<- ids.ID,
) {
	input := teleportermessenger.TeleporterMessageInput{
		DestinationBlockchainID: destination.BlockchainID,
		DestinationAddress:      destinationAddress,
		FeeInfo: teleportermessenger.TeleporterFeeInfo{
			FeeTokenAddress: common.Address{},
			Amount:          big.NewInt(0),
		},
		RequiredGasLimit:        big.NewInt(1),
		AllowedRelayerAddresses: []common.Address{},
		Message:                 []byte{1, 2, 3, 4},
	}

	// Send a transaction to the Teleporter contract
	log.Info(
		"Sending teleporter transaction",
		zap.Stringer("sourceBlockchainID", source.BlockchainID),
		zap.Stringer("destinationBlockchainID", destination.BlockchainID),
	)
	_, teleporterMessageID := SendCrossChainMessageAndWaitForAcceptance(
		ctx,
		teleporter.TeleporterMessenger(&source),
		source,
		destination,
		input,
		fundedKey,
	)
	ids <- teleporterMessageID
}

func SendBasicTeleporterMessage(
	ctx context.Context,
	log logging.Logger,
	teleporter TeleporterTestInfo,
	source testinfo.L1TestInfo,
	destination testinfo.L1TestInfo,
	fundedKey *ecdsa.PrivateKey,
	destinationAddress common.Address,
) (*types.Receipt, teleportermessenger.TeleporterMessage, ids.ID) {
	input := teleportermessenger.TeleporterMessageInput{
		DestinationBlockchainID: destination.BlockchainID,
		DestinationAddress:      destinationAddress,
		FeeInfo: teleportermessenger.TeleporterFeeInfo{
			FeeTokenAddress: common.Address{},
			Amount:          big.NewInt(0),
		},
		RequiredGasLimit:        big.NewInt(1),
		AllowedRelayerAddresses: []common.Address{},
		Message:                 []byte{1, 2, 3, 4},
	}

	// Send a transaction to the Teleporter contract
	log.Info("Sending teleporter transaction",
		zap.Stringer("sourceBlockchainID", source.BlockchainID),
		zap.Stringer("destinationBlockchainID", destination.BlockchainID),
	)
	receipt, teleporterMessageID := SendCrossChainMessageAndWaitForAcceptance(
		ctx,
		teleporter.TeleporterMessenger(&source),
		source,
		destination,
		input,
		fundedKey,
	)
	sendEvent, err := GetEventFromLogs(
		receipt.Logs,
		teleporter.TeleporterMessenger(&source).ParseSendCrossChainMessage,
	)
	Expect(err).Should(BeNil())

	return receipt, sendEvent.Message, teleporterMessageID
}

func SendBasicTeleporterMessageV2(
	ctx context.Context,
	log logging.Logger,
	teleporter TeleporterTestInfo,
	source testinfo.L1TestInfo,
	destination testinfo.L1TestInfo,
	fundedKey *ecdsa.PrivateKey,
	destinationAddress common.Address,
) (*types.Receipt, teleportermessengerv2.TeleporterMessageV2, ids.ID) {
	input := teleportermessengerv2.TeleporterMessageInput{
		DestinationBlockchainID: destination.BlockchainID,
		DestinationAddress:      destinationAddress,
		FeeInfo: teleportermessengerv2.TeleporterFeeInfo{
			FeeTokenAddress: common.Address{},
			Amount:          big.NewInt(0),
		},
		RequiredGasLimit:        big.NewInt(1),
		AllowedRelayerAddresses: []common.Address{},
		Message:                 []byte{1, 2, 3, 4},
	}

	// Send a transaction to the Teleporter contract
	log.Info("Sending teleporter transaction",
		zap.Stringer("sourceBlockchainID", source.BlockchainID),
		zap.Stringer("destinationBlockchainID", destination.BlockchainID),
	)
	receipt, teleporterMessageID := SendCrossChainMessageV2AndWaitForAcceptance(
		ctx,
		teleporter.TeleporterMessengerV2(&source),
		source,
		destination,
		input,
		fundedKey,
	)
	sendEvent, err := GetEventFromLogs(
		receipt.Logs,
		teleporter.TeleporterMessengerV2(&source).ParseSendCrossChainMessage,
	)
	Expect(err).Should(BeNil())

	return receipt, sendEvent.Message, teleporterMessageID
}

func RelayBasicMessage(
	ctx context.Context,
	log logging.Logger,
	teleporter TeleporterTestInfo,
	source testinfo.L1TestInfo,
	destination testinfo.L1TestInfo,
	fundedKey *ecdsa.PrivateKey,
	destinationAddress common.Address,
) {
	newHeadsDest := make(chan *types.Header, 10)
	sub, err := destination.WSClient.SubscribeNewHead(ctx, newHeadsDest)
	Expect(err).Should(BeNil())
	defer sub.Unsubscribe()

	_, _, teleporterMessageID := SendBasicTeleporterMessage(
		ctx,
		log,
		teleporter,
		source,
		destination,
		fundedKey,
		destinationAddress,
	)

	log.Info("Waiting for Teleporter message delivery")
	err = WaitTeleporterMessageDelivered(ctx, teleporter.TeleporterMessenger(&destination), teleporterMessageID)
	Expect(err).Should(BeNil())
}

func RelayBasicMessageV2(
	ctx context.Context,
	log logging.Logger,
	teleporter TeleporterTestInfo,
	source testinfo.L1TestInfo,
	destination testinfo.L1TestInfo,
	fundedKey *ecdsa.PrivateKey,
	destinationAddress common.Address,
) {
	_, _, teleporterMessageID := SendBasicTeleporterMessageV2(
		ctx,
		log,
		teleporter,
		source,
		destination,
		fundedKey,
		destinationAddress,
	)

	log.Info("Waiting for Teleporter message delivery")
	err := WaitTeleporterMessageDeliveredV2(ctx, teleporter.TeleporterMessengerV2(&destination), teleporterMessageID)
	Expect(err).Should(BeNil())
}

// Blocks until the given teleporter message is delivered to the specified TeleporterMessenger
// before the timeout, or if an error occurred.
func WaitTeleporterMessageDelivered(
	ctx context.Context,
	teleporterMessenger *teleportermessenger.TeleporterMessenger,
	teleporterMessageID ids.ID,
) error {
	cctx, cancel := context.WithTimeout(ctx, 60*time.Second)
	defer cancel()

	queryTicker := time.NewTicker(200 * time.Millisecond)
	defer queryTicker.Stop()
	for {
		delivered, err := teleporterMessenger.MessageReceived(
			&bind.CallOpts{}, teleporterMessageID,
		)
		if err != nil {
			return err
		}

		if delivered {
			return nil
		}

		// Wait for the next round.
		select {
		case <-cctx.Done():
			return cctx.Err()
		case <-queryTicker.C:
		}
	}
}

// Blocks until the given teleporter message is delivered to the specified TeleporterMessengerV2
// before the timeout, or if an error occurred.
func WaitTeleporterMessageDeliveredV2(
	ctx context.Context,
	teleporterMessenger *teleportermessengerv2.TeleporterMessengerV2,
	teleporterMessageID ids.ID,
) error {
	cctx, cancel := context.WithTimeout(ctx, 60*time.Second)
	defer cancel()

	queryTicker := time.NewTicker(200 * time.Millisecond)
	defer queryTicker.Stop()
	for {
		delivered, err := teleporterMessenger.MessageReceived(
			&bind.CallOpts{}, teleporterMessageID,
		)
		if err != nil {
			return err
		}

		if delivered {
			return nil
		}

		// Wait for the next round.
		select {
		case <-cctx.Done():
			return cctx.Err()
		case <-queryTicker.C:
		}
	}
}

func WriteRelayerConfig(
	log logging.Logger,
	relayerConfig relayercfg.Config,
	fname string,
) string {
	data, err := json.MarshalIndent(relayerConfig, "", "\t")
	Expect(err).Should(BeNil())

	f, err := os.CreateTemp(os.TempDir(), fname)
	Expect(err).Should(BeNil())

	_, err = f.Write(data)
	Expect(err).Should(BeNil())
	relayerConfigPath := f.Name()

	log.Info("Created icm-relayer config",
		zap.String("configPath", relayerConfigPath),
		zap.String("config", string(data)),
	)
	return relayerConfigPath
}

// TODO define interface over Config and write a generic function to write either config
func WriteSignatureAggregatorConfig(
	log logging.Logger,
	signatureAggregatorConfig signatureaggregatorcfg.Config,
	fname string,
) string {
	data, err := json.MarshalIndent(signatureAggregatorConfig, "", "\t")
	Expect(err).Should(BeNil())

	f, err := os.CreateTemp(os.TempDir(), fname)
	Expect(err).Should(BeNil())

	_, err = f.Write(data)
	Expect(err).Should(BeNil())
	signatureAggregatorConfigPath := f.Name()

	log.Info("Created signature-aggregator config",
		zap.String("configPath", signatureAggregatorConfigPath),
		zap.String("config", string(data)),
	)
	return signatureAggregatorConfigPath
}

func TriggerProcessMissedBlocks(
	ctx context.Context,
	log logging.Logger,
	teleporter TeleporterTestInfo,
	sourceL1Info testinfo.L1TestInfo,
	destinationSubnetInfo testinfo.L1TestInfo,
	currRelayerCleanup context.CancelFunc,
	currentRelayerConfig relayercfg.Config,
	fundedAddress common.Address,
	fundedKey *ecdsa.PrivateKey,
) {
	// First, make sure the relayer is stopped
	currRelayerCleanup()

	// Subscribe to the destination chain
	newHeads := make(chan *types.Header, 10)
	sub, err := destinationSubnetInfo.WSClient.SubscribeNewHead(ctx, newHeads)
	Expect(err).Should(BeNil())
	defer sub.Unsubscribe()

	// Send three Teleporter messages from subnet A to subnet B
	log.Info("Sending three Teleporter messages from subnet A to subnet B")
	_, _, id1 := SendBasicTeleporterMessage(
		ctx,
		log,
		teleporter,
		sourceL1Info,
		destinationSubnetInfo,
		fundedKey,
		fundedAddress,
	)
	_, _, id2 := SendBasicTeleporterMessage(
		ctx,
		log,
		teleporter,
		sourceL1Info,
		destinationSubnetInfo,
		fundedKey,
		fundedAddress,
	)
	_, _, id3 := SendBasicTeleporterMessage(
		ctx,
		log,
		teleporter,
		sourceL1Info,
		destinationSubnetInfo,
		fundedKey,
		fundedAddress,
	)

	currHeight, err := sourceL1Info.EthClient.BlockNumber(ctx)
	Expect(err).Should(BeNil())
	log.Info("Current block height", zap.Uint64("height", currHeight))

	// Configure the relayer such that it will only process the last of the three messages sent above.
	// The relayer DB stores the height of the block *before* the first message, so by setting the
	// ProcessHistoricalBlocksFromHeight to the block height of the *third* message, we expect the relayer to skip
	// the first two messages on startup, but process the third.
	modifiedRelayerConfig := currentRelayerConfig
	modifiedRelayerConfig.SourceBlockchains[0].ProcessHistoricalBlocksFromHeight = currHeight
	modifiedRelayerConfig.ProcessMissedBlocks = true
	relayerConfigPath := WriteRelayerConfig(log, modifiedRelayerConfig, DefaultRelayerCfgFname)

	log.Info("Starting the relayer")
	relayerCleanup, readyChan := RunRelayerExecutable(
		ctx,
		log,
		relayerConfigPath,
		currentRelayerConfig,
	)
	defer relayerCleanup()

	// Wait for relayer to start up
	startupCtx, startupCancel := context.WithTimeout(ctx, 60*time.Second)
	defer startupCancel()
	WaitForChannelClose(startupCtx, readyChan)

	// Send a native transfer to trigger block production
	SendNativeTransfer(ctx, sourceL1Info, fundedKey, fundedAddress, big.NewInt(1))
	log.Info("Waiting for a new block confirmation on the destination")
	<-newHeads

	log.Info("Waiting for Teleporter message delivery")
	err = WaitTeleporterMessageDelivered(ctx, teleporter.TeleporterMessenger(&destinationSubnetInfo), id3)
	Expect(err).Should(BeNil())

	delivered1, err := teleporter.TeleporterMessenger(&destinationSubnetInfo).MessageReceived(
		&bind.CallOpts{}, id1,
	)
	Expect(err).Should(BeNil())
	delivered2, err := teleporter.TeleporterMessenger(&destinationSubnetInfo).MessageReceived(
		&bind.CallOpts{}, id2,
	)
	Expect(err).Should(BeNil())
	delivered3, err := teleporter.TeleporterMessenger(&destinationSubnetInfo).MessageReceived(
		&bind.CallOpts{}, id3,
	)
	Expect(err).Should(BeNil())
	Expect(delivered1).Should(BeFalse())
	Expect(delivered2).Should(BeFalse())
	Expect(delivered3).Should(BeTrue())
}

func TriggerProcessMissedBlocksV2(
	ctx context.Context,
	log logging.Logger,
	teleporter TeleporterTestInfo,
	sourceL1Info testinfo.L1TestInfo,
	destinationSubnetInfo testinfo.L1TestInfo,
	currRelayerCleanup context.CancelFunc,
	currentRelayerConfig relayercfg.Config,
	fundedAddress common.Address,
	fundedKey *ecdsa.PrivateKey,
) {
	// First, make sure the relayer is stopped
	currRelayerCleanup()

	// Subscribe to the destination chain
	newHeads := make(chan *types.Header, 10)
	sub, err := destinationSubnetInfo.WSClient.SubscribeNewHead(ctx, newHeads)
	Expect(err).Should(BeNil())
	defer sub.Unsubscribe()

	// Send three Teleporter messages from subnet A to subnet B
	log.Info("Sending three Teleporter messages from subnet A to subnet B")
	_, _, id1 := SendBasicTeleporterMessageV2(
		ctx,
		log,
		teleporter,
		sourceL1Info,
		destinationSubnetInfo,
		fundedKey,
		fundedAddress,
	)
	_, _, id2 := SendBasicTeleporterMessageV2(
		ctx,
		log,
		teleporter,
		sourceL1Info,
		destinationSubnetInfo,
		fundedKey,
		fundedAddress,
	)
	_, _, id3 := SendBasicTeleporterMessageV2(
		ctx,
		log,
		teleporter,
		sourceL1Info,
		destinationSubnetInfo,
		fundedKey,
		fundedAddress,
	)

	currHeight, err := sourceL1Info.EthClient.BlockNumber(ctx)
	Expect(err).Should(BeNil())
	log.Info("Current block height", zap.Uint64("height", currHeight))

	// Configure the relayer such that it will only process the last of the three messages sent above.
	// The relayer DB stores the height of the block *before* the first message, so by setting the
	// ProcessHistoricalBlocksFromHeight to the block height of the *third* message, we expect the relayer to skip
	// the first two messages on startup, but process the third.
	modifiedRelayerConfig := currentRelayerConfig
	modifiedRelayerConfig.SourceBlockchains[0].ProcessHistoricalBlocksFromHeight = currHeight
	modifiedRelayerConfig.ProcessMissedBlocks = true
	relayerConfigPath := WriteRelayerConfig(log, modifiedRelayerConfig, DefaultRelayerCfgFname)

	log.Info("Starting the relayer")
	relayerCleanup, readyChan := RunRelayerExecutable(
		ctx,
		log,
		relayerConfigPath,
		currentRelayerConfig,
	)
	defer relayerCleanup()

	// Wait for relayer to start up
	startupCtx, startupCancel := context.WithTimeout(ctx, 60*time.Second)
	defer startupCancel()
	WaitForChannelClose(startupCtx, readyChan)

	// Send a native transfer to trigger block production
	SendNativeTransfer(ctx, sourceL1Info, fundedKey, fundedAddress, big.NewInt(1))
	log.Info("Waiting for a new block confirmation on the destination")
	<-newHeads

	log.Info("Waiting for Teleporter message delivery")
	err = WaitTeleporterMessageDeliveredV2(ctx, teleporter.TeleporterMessengerV2(&destinationSubnetInfo), id3)
	Expect(err).Should(BeNil())

	destinationTeleporterMessenger := teleporter.TeleporterMessengerV2(&destinationSubnetInfo)
	delivered1, err := destinationTeleporterMessenger.MessageReceived(
		&bind.CallOpts{}, id1,
	)
	Expect(err).Should(BeNil())
	delivered2, err := destinationTeleporterMessenger.MessageReceived(
		&bind.CallOpts{}, id2,
	)
	Expect(err).Should(BeNil())
	delivered3, err := destinationTeleporterMessenger.MessageReceived(
		&bind.CallOpts{}, id3,
	)
	Expect(err).Should(BeNil())
	Expect(delivered1).Should(BeFalse())
	Expect(delivered2).Should(BeFalse())
	Expect(delivered3).Should(BeTrue())
}

func DeployBatchCrossChainMessenger(
	ctx context.Context,
	senderKey *ecdsa.PrivateKey,
	teleporter TeleporterTestInfo,
	teleporterManager common.Address,
	l1 testinfo.L1TestInfo,
) (common.Address, *batchcrosschainmessenger.BatchCrossChainMessenger) {
	opts, err := bind.NewKeyedTransactorWithChainID(
		senderKey, l1.EVMChainID)
	Expect(err).Should(BeNil())
	address, tx, exampleMessenger, err := batchcrosschainmessenger.DeployBatchCrossChainMessenger(
		opts,
		l1.EthClient,
		teleporter.TeleporterRegistryAddress(l1.BlockchainID),
		teleporterManager,
		teleporter.GetLatestTeleporterVersion(l1),
	)
	Expect(err).Should(BeNil())

	// Wait for the transaction to be mined
	WaitForTransactionSuccess(ctx, l1.EthClient, tx.Hash())

	return address, exampleMessenger
}

func runExecutable(
	cmd *exec.Cmd,
	ctx context.Context,
	log logging.Logger,
	appName string,
	healthCheckUrl string,
) chan struct{} {
	log = log.With(zap.String("appName", appName))
	cmdOutput := make(chan string)

	// Set up a pipe to capture the command's output
	cmdStdOutReader, err := cmd.StdoutPipe()
	Expect(err).Should(BeNil())
	cmdStdErrReader, err := cmd.StderrPipe()
	Expect(err).Should(BeNil())

	// Start the command
	log.Info("Starting executable")
	err = cmd.Start()
	Expect(err).Should(BeNil())

	readyChan := make(chan struct{})

	// Start goroutines to read and output the command's stdout and stderr
	go func() {
		scanner := bufio.NewScanner(cmdStdOutReader)
		for scanner.Scan() {
			fmt.Println(scanner.Text())
		}
		cmdOutput <- "Command execution finished"
	}()
	go func() {
		scanner := bufio.NewScanner(cmdStdErrReader)
		for scanner.Scan() {
			fmt.Println(scanner.Text())
		}
		cmdOutput <- "Command execution finished"
	}()
	go func() {
		err := cmd.Wait()
		// Context cancellation is the only expected way for the process to exit, otherwise log an error
		// Don't panic to allow for easier cleanup
		if !errors.Is(ctx.Err(), context.Canceled) {
			log.Error("Executable exited abnormally", zap.Error(err))
		}
	}()
	go func() { // wait for health check to report healthy
		for {
			resp, err := http.Get(healthCheckUrl)
			if err == nil {
				resp.Body.Close()
				if resp.StatusCode == 200 {
					log.Info("Health check passed")
					close(readyChan)
					break
				}
			}
			log.Info("Health check failed", zap.Error(err))
			time.Sleep(time.Second * 1)
		}
	}()
	return readyChan
}

// Helper function that waits for a signaling channel to be closed
// or throws an error if the channel is not closed in time
func WaitForChannelClose(ctx context.Context, ch <-chan struct{}) {
	select {
	case <-ch:
	case <-ctx.Done():
		Expect(false).To(BeTrue(), "Channel did not close in time")
	}
}

// GetRepoRoot finds the repository root by looking for the go.mod file
func GetRepoRoot() (string, error) {
	dir, err := os.Getwd()
	if err != nil {
		return "", err
	}

	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir, nil
		}

		parent := filepath.Dir(dir)
		if parent == dir {
			return "", fmt.Errorf("could not find repository root (no go.mod found)")
		}
		dir = parent
	}
}
