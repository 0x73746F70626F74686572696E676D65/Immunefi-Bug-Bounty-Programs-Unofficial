// Copyright (C) 2024, Ava Labs, Inc. All rights reserved.
// See the file LICENSE for licensing terms.

package tests

import (
	"bytes"
	"context"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"time"

	"github.com/ava-labs/avalanchego/api/info"
	"github.com/ava-labs/avalanchego/ids"
	"github.com/ava-labs/avalanchego/staking"
	"github.com/ava-labs/avalanchego/utils/logging"
	"github.com/ava-labs/avalanchego/utils/set"
	"github.com/ava-labs/avalanchego/utils/units"
	"github.com/ava-labs/avalanchego/vms/platformvm"
	"github.com/ava-labs/avalanchego/vms/platformvm/warp"
	avalancheWarp "github.com/ava-labs/avalanchego/vms/platformvm/warp"
	"github.com/ava-labs/icm-services/config"
	"github.com/ava-labs/icm-services/icm-contracts/tests/network"
	testinfo "github.com/ava-labs/icm-services/icm-contracts/tests/test-info"
	"github.com/ava-labs/icm-services/icm-contracts/tests/utils"
	"github.com/ava-labs/icm-services/peers/clients"
	"github.com/ava-labs/icm-services/signature-aggregator/api"
	. "github.com/onsi/gomega"
	"go.uber.org/zap"
)

const (
	minimumBalanceForValidator = 2048 * units.NanoAvax // Minimum balance for a validator to be considered funded
)

// Tests signature aggregation with a private network
// Steps:
// - Sets up a primary network and a subnet.
// - Generates a config with temporary paths set for TLS cert and key
// - Starts the signature aggregator with the generated config once to populate the TLS cert and key
// - Reads the nodeID from the TLS cert and stops the signature aggregator
// - Sends the teleporter message from B -> A
// - Restarts the subnet B nodes with the validatorOnly flag set to true and nodeID added to allowedNodes
// - Restarts the signature aggregator with the same config which should re-use
// now populated TLS cert and key and result in same nodeID
// - Requests an aggregated signature from the signature aggregator API which
// will only be returned successfully if the nodeID is explicitly allowed by the subnet
func ValidatorsOnlyNetwork(
	ctx context.Context,
	log logging.Logger,
	network *network.LocalAvalancheNetwork,
	teleporter utils.TeleporterTestInfo,
) {
	// Begin Setup step
	l1AInfo := network.GetPrimaryNetworkInfo()
	_, l1BInfo := network.GetTwoL1s()
	fundedAddress, fundedKey := network.GetFundedAccountInfo()

	underfundedNodesIndex := getUnderfundedNodeIndexes(ctx, l1AInfo.NodeURIs[0], l1BInfo.SubnetID)

	// Start the signature-aggregator for the first time to generate the
	// TLS cert key pair
	dir, err := os.MkdirTemp(os.TempDir(), "sig-agg-tls-cert")
	Expect(err).Should(BeNil())

	// Create a config without TLS cert and key
	baseConfig := utils.CreateDefaultSignatureAggregatorConfig(
		log,
		[]testinfo.L1TestInfo{l1AInfo, l1BInfo},
	)
	baseConfigPath := utils.WriteSignatureAggregatorConfig(
		log,
		baseConfig,
		utils.DefaultSignatureAggregatorCfgFname,
	)

	keyPath := dir + "/key.pem"
	certPath := dir + "/cert.pem"

	signatureAggregatorConfig := baseConfig
	signatureAggregatorConfig.TrackedSubnetIDs = []string{l1BInfo.SubnetID.String()}
	signatureAggregatorConfig.TLSCertPath = certPath
	signatureAggregatorConfig.TLSKeyPath = keyPath

	signatureAggregatorConfigPath := utils.WriteSignatureAggregatorConfig(
		log,
		signatureAggregatorConfig,
		utils.DefaultSignatureAggregatorCfgFname,
	)
	log.Info("Starting the signature aggregator",
		zap.String("configPath", signatureAggregatorConfigPath),
	)
	signatureAggregatorCancel, readyChan := utils.RunSignatureAggregatorExecutable(
		ctx,
		log,
		signatureAggregatorConfigPath,
		signatureAggregatorConfig,
	)

	// Wait for signature-aggregator to start up
	log.Info("Waiting for the signature-aggregator to start up")
	startupCtx, startupCancel := context.WithTimeout(ctx, 60*time.Second)
	defer startupCancel()
	utils.WaitForChannelClose(startupCtx, readyChan)

	cert, err := staking.LoadTLSCertFromFiles(keyPath, certPath)
	Expect(err).Should(BeNil())
	peerCert, err := staking.ParseCertificate(cert.Leaf.Raw)
	Expect(err).Should(BeNil())
	nodeID := ids.NodeIDFromCert(peerCert)

	signatureAggregatorCancel()
	log.Info("Retrieved nodeID", zap.Stringer("nodeID", nodeID))

	// We have to send the message before making the network private.

	log.Info("Sending teleporter message from B -> A")
	receipt, _, _ := utils.SendBasicTeleporterMessage(
		ctx,
		log,
		teleporter,
		l1BInfo,
		l1AInfo,
		fundedKey,
		fundedAddress,
	)
	warpMessage := getWarpMessageFromLog(ctx, log, receipt, l1BInfo)

	// Restart l1B and make it private
	relayerNodeIDSet := set.NewSet[ids.NodeID](1)
	relayerNodeIDSet.Add(nodeID)

	l1BNodes := set.NewSet[ids.NodeID](1)

	// Make l1BInfo a validator only network
	for _, subnet := range network.Subnets {
		if subnet.SubnetID == l1BInfo.SubnetID {
			subnet.Config = make(map[string]interface{})
			subnet.Config["validatorOnly"] = true
			subnet.Config["allowedNodes"] = relayerNodeIDSet
			err := subnet.Write(network.GetSubnetDir())
			Expect(err).Should(BeNil())
			l1BNodes.Add(subnet.ValidatorIDs...)
		}
	}
	// Restart l1B nodes
	for _, tmpnetNode := range network.Nodes {
		if l1BNodes.Contains(tmpnetNode.NodeID) {
			Expect(network.DefaultRuntimeConfig).ShouldNot(BeNil())
			Expect(network.DefaultRuntimeConfig.Process.ReuseDynamicPorts).Should(BeTrue())
			tmpnetNode.RuntimeConfig = &network.DefaultRuntimeConfig
			// Restart the network to apply the new chain configs
			cctx, cancel := context.WithTimeout(ctx, 120*time.Second)
			defer cancel()
			err := tmpnetNode.Restart(cctx)
			Expect(err).Should(BeNil())
		}
	}

	// The signature aggregator's readiness health check requires a quorum of l1B stake to be
	// connected, and with one of the equal-weight validators intentionally underfunded the margin
	// is a single node. Wait for the restarted validators to re-establish their p2p connections
	// before starting the aggregator so its initial dials don't race the restarts.
	waitForNodesToReconnect(ctx, log, network, l1BNodes)

	// End setup step

	requestURL := fmt.Sprintf("http://localhost:%d%s", signatureAggregatorConfig.APIPort, api.APIPath)

	reqBody := api.AggregateSignatureRequest{
		Message: "0x" + hex.EncodeToString(warpMessage.Bytes()),
	}
	client := http.Client{
		Timeout: 30 * time.Second,
	}

	var sendRequestToAPI = func(success bool) {
		b, err := json.Marshal(reqBody)
		Expect(err).Should(BeNil())
		bodyReader := bytes.NewReader(b)

		req, err := http.NewRequest(http.MethodPost, requestURL, bodyReader)
		Expect(err).Should(BeNil())
		req.Header.Set("Content-Type", "application/json")

		res, err := client.Do(req)
		Expect(err).Should(BeNil())

		if !success {
			Expect(res.Status).ShouldNot(Equal("200 OK"))
			return
		}

		Expect(res.Status).Should(Equal("200 OK"))
		Expect(res.Header.Get("Content-Type")).Should(Equal("application/json"))

		defer res.Body.Close()
		body, err := io.ReadAll(res.Body)
		Expect(err).Should(BeNil())

		var response api.AggregateSignatureResponse
		err = json.Unmarshal(body, &response)
		Expect(err).Should(BeNil())

		decodedMessage, err := hex.DecodeString(response.SignedMessage)
		Expect(err).Should(BeNil())

		signedMessage, err := avalancheWarp.ParseMessage(decodedMessage)
		Expect(err).Should(BeNil())
		Expect(signedMessage.ID()).Should(Equal(warpMessage.ID()))

		bitsetSig, ok := signedMessage.Signature.(*warp.BitSetSignature)
		Expect(ok).Should(BeTrue(), "Signature is not a BitSetSignature")

		signerBits := set.BitsFromBytes(bitsetSig.Signers)
		for i := 0; i < signerBits.BitLen(); i++ {
			if underfundedNodesIndex.Contains(i) {
				Expect(signerBits.Contains(i)).Should(BeFalse(), "Signature contains underfunded node index %d", i)
			}
		}
	}

	// start sig-agg again with a floating TLS cert - this should fail
	log.Info("Starting the signature aggregator with a floating TLS cert")
	signatureAggregatorCancel, readyChan = utils.RunSignatureAggregatorExecutable(
		ctx,
		log,
		baseConfigPath,
		baseConfig,
	)

	// Wait for signature-aggregator to start up
	log.Info("Waiting for the signature-aggregator to start up")
	startupCtx, startupCancel = context.WithTimeout(ctx, 60*time.Second)
	defer startupCancel()
	utils.WaitForChannelClose(startupCtx, readyChan)

	sendRequestToAPI(false)
	signatureAggregatorCancel()

	// start sig-agg again with the same TLS cert
	log.Info("Starting the signature aggregator with the same TLS cert")
	signatureAggregatorCancel, readyChan = utils.RunSignatureAggregatorExecutable(
		ctx,
		log,
		signatureAggregatorConfigPath,
		signatureAggregatorConfig,
	)
	defer signatureAggregatorCancel()

	// Wait for signature-aggregator to start up
	log.Info("Waiting for the signature-aggregator to start up")
	startupCtx, startupCancel = context.WithTimeout(ctx, 60*time.Second)
	defer startupCancel()
	utils.WaitForChannelClose(startupCtx, readyChan)

	sendRequestToAPI(true)
}

// waitForNodesToReconnect blocks until every node in [nodeIDs] reports every other node in
// [nodeIDs] as a connected peer, or fails the test after a timeout.
func waitForNodesToReconnect(
	ctx context.Context,
	log logging.Logger,
	network *network.LocalAvalancheNetwork,
	nodeIDs set.Set[ids.NodeID],
) {
	cctx, cancel := context.WithTimeout(ctx, 120*time.Second)
	defer cancel()
	for _, tmpnetNode := range network.Nodes {
		if !nodeIDs.Contains(tmpnetNode.NodeID) {
			continue
		}
		infoClient := info.NewClient(tmpnetNode.URI)
		for {
			if cctx.Err() != nil {
				Expect(false).Should(BeTrue(), "timed out waiting for restarted nodes to reconnect")
			}

			peers, err := infoClient.Peers(cctx, nil)
			if err != nil {
				log.Error("Failed to get peers from node",
					zap.Stringer("nodeID", tmpnetNode.NodeID),
					zap.Error(err),
				)
				continue
			}

			connected := set.NewSet[ids.NodeID](len(peers))
			for _, peer := range peers {
				connected.Add(peer.ID)
			}
			var missing []ids.NodeID
			for _, want := range nodeIDs.List() {
				if want != tmpnetNode.NodeID && !connected.Contains(want) {
					missing = append(missing, want)
				}
			}
			if len(missing) == 0 {
				break
			}

			log.Info("Waiting for restarted node to reconnect to its peers",
				zap.Stringer("nodeID", tmpnetNode.NodeID),
				zap.Any("missingPeers", missing),
			)
			select {
			case <-cctx.Done():
				Expect(false).Should(BeTrue(), "timed out waiting for restarted nodes to reconnect")
			case <-time.After(time.Second):
			}
		}
	}
	log.Info("Restarted nodes reconnected to their peers")
}

func getUnderfundedNodeIndexes(
	ctx context.Context,
	primaryNetworkURI string,
	subnetID ids.ID,
) set.Set[int] {
	// Find the underfunded nodes index
	pClient := platformvm.NewClient(primaryNetworkURI)
	currentValidators, err := pClient.GetCurrentValidators(ctx, subnetID, nil)
	Expect(err).Should(BeNil(), "Failed to get current validators")

	underfundedNodes := set.NewSet[ids.NodeID](0)
	for _, v := range currentValidators {
		// Check if the validator is L1 and underfunded
		if v.ClientL1Validator.ValidationID != nil && (v.Balance == nil || *v.Balance < minimumBalanceForValidator) {
			underfundedNodes.Add(v.NodeID)
		}
	}

	if underfundedNodes.Len() == 0 {
		return set.NewSet[int](0)
	}

	// Get the canonical validator set to find the underfunded nodes index
	underfundedNodesIndex := set.NewSet[int](0)
	validatorClient := clients.NewCanonicalValidatorClient(&config.APIConfig{
		BaseURL: primaryNetworkURI,
	})
	canonicalSet, err := validatorClient.GetProposedValidators(ctx, subnetID)
	Expect(err).Should(BeNil(), "Failed to get current canonical validator set")

	for i, validator := range canonicalSet.Validators {
		for _, nodeID := range validator.NodeIDs {
			if underfundedNodes.Contains(nodeID) {
				underfundedNodesIndex.Add(i)
			}
		}
	}

	return underfundedNodesIndex
}
