package service

import (
	"testing"

	"github.com/ava-labs/avalanchego/graft/coreth/params"
	"github.com/ava-labs/avalanchego/graft/coreth/plugin/evm"
	"github.com/coinbase/rosetta-sdk-go/types"
	"github.com/stretchr/testify/require"

	ethtypes "github.com/ava-labs/libevm/core/types"
)

func TestConfig(t *testing.T) {
	evm.RegisterAllLibEVMExtras()
	t.Run("online", func(t *testing.T) {
		cfg := Config{
			Mode:      "online",
			ChainID:   params.AvalancheMainnetChainID,
			NetworkID: &types.NetworkIdentifier{},
		}

		require.False(t, cfg.IsOfflineMode())
		require.True(t, cfg.IsOnlineMode())
	})

	t.Run("offline", func(t *testing.T) {
		cfg := Config{
			Mode:      "offline",
			ChainID:   params.AvalancheMainnetChainID,
			NetworkID: &types.NetworkIdentifier{},
		}

		require.True(t, cfg.IsOfflineMode())
		require.False(t, cfg.IsOnlineMode())
	})

	t.Run("signer", func(t *testing.T) {
		cfg := Config{
			ChainID: params.AvalancheMainnetChainID,
		}
		require.IsType(t, ethtypes.NewLondonSigner(params.AvalancheMainnetChainID), cfg.Signer())
	})
}
