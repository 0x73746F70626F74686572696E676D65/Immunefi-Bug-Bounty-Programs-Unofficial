# @internal/utils

## 0.9.0

### Minor Changes

- cce416d: add value details to avalanche tx approval screens

## 0.8.2

### Patch Changes

- 2497ece: fix: bitcoin transaction building

## 0.8.1

### Patch Changes

- 6b68f23: Update SDKs

## 0.8.0

### Minor Changes

- 1eaf0ca: auto-renewed validators - ACP-236

## 0.7.2

### Patch Changes

- e205743: fix: reset failed attempts

## 0.7.1

### Patch Changes

- 281614e: getAddressesByIndices supports internalIndices on P Chain; bump sdks

## 0.7.0

### Minor Changes

- 34fb4c3: The modules use runtime.fetch if available

## 0.6.1

### Patch Changes

- 2e0c5f7: changed exponential backoff params to try 10 times at a 500ms increment
- d311fe6: fix(evm-module): filter out spam transactions from history"

## 0.6.0

### Minor Changes

- 18ad6d5: Add skipIntermediateTxs option to eth_sendTransactionBatch

## 0.5.4

### Patch Changes

- ba3878e: Use prices from the watchlist for native tokens

## 0.5.3

### Patch Changes

- 67e5683: update avalanche sdks to latest

## 0.5.2

### Patch Changes

- cc3811a: feat: support atomic txs on c-chain

## 0.5.1

### Patch Changes

- 6712674: bump internal sdks to 3.1.0-alpha.58

## 0.5.0

### Minor Changes

- b4b6652: get Solana transaction history
- 55f2c23: feat: introduce deriveAddress() method

### Patch Changes

- 00f59fe: Solana signing RPC calls

## 0.4.0

### Minor Changes

- 1f54063: feat: return reputation for ERC20 tokens

## 0.3.5

### Patch Changes

- af15f8d: feat: batch signing for EVM, stable release for all

## 0.3.4

### Patch Changes

- 20e096d: chore: update SDKs

## 0.3.3

### Patch Changes

- 6c5f7e5: chore: update SDKs and AJS

## 0.3.2

### Patch Changes

- b156e27: chore: use devnet

## 0.3.1

### Patch Changes

- 70cf899: fix: make _to_ field optional for eth_sendTransaction

## 0.3.0

### Minor Changes

- 293b07b: feat: add bitcoin_signTransaction

## 0.2.0

### Minor Changes

- 045271a: Load NFTs on EVM

## 0.1.0

### Minor Changes

- 04cc519: feat: add LINK tx detail type

## 0.0.4

### Patch Changes

- 132e988: avalanche_sendTransaction
