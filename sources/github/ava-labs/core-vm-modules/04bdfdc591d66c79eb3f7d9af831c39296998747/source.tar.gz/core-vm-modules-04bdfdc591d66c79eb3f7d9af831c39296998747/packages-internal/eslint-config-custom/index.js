/**
 * @type {import('eslint').Linter.Config}
 */
// eslint-disable-next-line no-undef
module.exports = {
  extends: ['turbo', 'prettier', 'eslint:recommended', 'plugin:@typescript-eslint/recommended'],
  parser: '@typescript-eslint/parser',
  plugins: ['@typescript-eslint', 'eslint-plugin-unicorn'],
  root: true,
  ignorePatterns: ['**/contracts/openzeppelin/**/*.ts'],
  rules: {
    '@typescript-eslint/no-unused-vars': [
      'error',
      {
        argsIgnorePattern: '^_', // Ignore unused variables whose name starts with `_`
        ignoreRestSiblings: true,
      },
    ],
    'unicorn/filename-case': [
      'error',
      {
        case: 'kebabCase',
      },
    ],
    '@typescript-eslint/no-var-requires': 'off',
    'no-console': ['error', { allow: ['error'] }],
    'turbo/no-undeclared-env-vars': [
      'error',
      {
        allowList: ['GLACIER_API_KEY'],
      },
    ],
  },
};
