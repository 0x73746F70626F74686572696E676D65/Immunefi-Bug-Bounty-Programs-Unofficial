import { rpcErrors } from '@metamask/rpc-errors';
import {
  RpcMethod,
  type ApprovalController,
  type DisplayData,
  type Network,
  type RpcRequest,
  type SigningData,
  type SigningResult,
} from '@avalabs/vm-module-types';
import { type Base64EncodedWireTransaction } from '@solana/kit';

import { getProvider } from '@src/utils/get-provider';
import { assertTxBelongsToNetwork } from '@src/utils/assert-tx-belongs-to-network';
import { getNetworkName } from '@src/utils/get-network-name';
import { explainTransaction } from '@src/utils/explain/explain-transaction';
import { waitForTransactionConfirmation } from '@src/utils/wait-for-transaction-confirmation';

import { parseRequestParams, type SendOptions } from './schema';
import type Blockaid from '@blockaid/client';
import { getExplorerAddressByNetwork } from '@src/utils/get-explorer-address-by-network';
import { rpcErrorOpts } from '@internal/utils';

export const signAndSendTransaction = async ({
  request,
  network,
  approvalController,
  proxyApiUrl,
  blockaid,
}: {
  request: RpcRequest;
  network: Network;
  approvalController: ApprovalController;
  proxyApiUrl: string;
  blockaid: Blockaid;
}) => {
  const { params } = request;
  const { data, success, error } = parseRequestParams(params);

  if (!success) {
    console.error('invalid params', error);
    return {
      error: rpcErrors.invalidParams(rpcErrorOpts('Transaction params are invalid', error)),
    };
  }

  const [{ account, serializedTx, sendOptions }] = data;

  const provider = getProvider({ network, proxyApiUrl });

  const clusterMismatch = await assertTxBelongsToNetwork({ serializedTx, provider, network });

  if (clusterMismatch) {
    return {
      error: rpcErrors.invalidParams(rpcErrorOpts(clusterMismatch, null)),
    };
  }

  const { details, isSimulationSuccessful, alert, balanceChange } = await explainTransaction({
    simulationParams: {
      dAppUrl: request.dappInfo.url,
      params: {
        account,
        chain: getNetworkName(network),
        transactionBase64: serializedTx,
      },
      blockaid,
    },
    network,
    provider,
  });

  const displayData: DisplayData = {
    title: 'Do you approve this transaction?',
    network: {
      chainId: network.chainId,
      name: network.chainName,
      logoUri: network.logoUri,
    },
    details,
    alert,
    balanceChange,
    networkFeeSelector: false,
    isSimulationSuccessful,
  };

  const signingData: SigningData = {
    type: RpcMethod.SOLANA_SIGN_AND_SEND_TRANSACTION,
    account,
    data: serializedTx,
  };

  const response = await approvalController.requestApproval({ request, displayData, signingData });

  if ('error' in response) {
    return {
      error: response.error,
    };
  }

  let txHash;

  try {
    txHash = await getTxHash(provider, response, sendOptions);
    const explorerLink = getExplorerAddressByNetwork(network, txHash);
    await approvalController.onTransactionPending({ txHash, request, explorerLink });

    waitForTransactionConfirmation({
      provider,
      txHash,
      approvalController,
      request,
      network,
      commitment: sendOptions?.preflightCommitment,
    });

    return {
      result: txHash,
    };
  } catch (error) {
    console.error(error);
    // Note: we don't need to call onTransactionReverted here as waitForTransactionConfirmation handles that
    return {
      error: rpcErrors.internal(rpcErrorOpts('Transaction failed', error)),
    };
  }
};

const getTxHash = async (
  provider: ReturnType<typeof getProvider>,
  response: SigningResult,
  sendOptions?: SendOptions,
) => {
  if ('txHash' in response) {
    return response.txHash;
  }

  const base58TxHash = await provider
    .sendTransaction(response.signedData as Base64EncodedWireTransaction, {
      ...sendOptions,
      encoding: 'base64',
    })
    .send();

  return base58TxHash;
};
