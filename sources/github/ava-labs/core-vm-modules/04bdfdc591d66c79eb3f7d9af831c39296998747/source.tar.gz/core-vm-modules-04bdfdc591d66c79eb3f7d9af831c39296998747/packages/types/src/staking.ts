import type { NetworkVMType } from './common';

export type TxDetails = TxValueDetails &
  (StakingDetails | ExportImportTxDetails | ChainDetails | BlockchainDetails | SubnetDetails | L1Details);

export type TxValueDetails = {
  outputs: TxOutput[];
  inputAmounts: Record<string, bigint>;
  outputAmounts: Record<string, bigint>;
  totalAvaxInput: bigint;
  totalAvaxOutput: bigint;
  totalAvaxBurned: bigint;
  isValidAvaxBurnedAmount: boolean;
};

export type TxOutput = {
  assetId: string;
  amount: bigint;
  owners: string[];
  locktime: bigint;
  stakeableLocktime: bigint;
  threshold: bigint;
  isAvax: boolean;
  isStake: boolean;
  assetDescription?: {
    assetID: string;
    name: string;
    symbol: string;
    denomination: number;
  };
};

export type StakingDetails =
  | AddPermissionlessDelegatorTx
  | AddPermissionlessValidatorTx
  | AddSubnetValidatorTx
  | RemoveSubnetValidatorTx
  | AddAutoRenewedValidatorTx
  | SetAutoRenewedValidatorConfigTx;
export type ExportImportTxDetails = ExportTx | ImportTx;
export type ChainDetails = BaseTx;
export type BlockchainDetails = CreateChainTx;
export type SubnetDetails = CreateSubnetTx;
export type L1Details =
  | ConvertSubnetToL1Tx
  | RegisterL1ValidatorTx
  | SetL1ValidatorWeightTx
  | IncreaseL1ValidatorBalanceTx
  | DisableL1ValidatorTx;

export type VM = NetworkVMType.AVM | NetworkVMType.EVM | NetworkVMType.PVM;

export type AddPermissionlessDelegatorTx = {
  type: TxType.AddPermissionlessDelegator;
  nodeID: string;
  subnetID: string;
  stake: bigint;
  start: string;
  end: string;
  txFee: bigint;
};

export type AddPermissionlessValidatorTx = {
  type: TxType.AddPermissionlessValidator;
  nodeID: string;
  subnetID: string;
  stake: bigint;
  delegationFee: number;
  start: string;
  end: string;
  txFee: bigint;
  publicKey?: string;
  signature?: string;
};

export interface ExportTx {
  type: TxType.Export;
  destination: VM;
  amount: bigint;
  chain: VM;
  txFee: bigint;
}

export interface ImportTx {
  type: TxType.Import;
  source: VM;
  amount: bigint;
  chain: VM;
  txFee: bigint;
}

export interface BaseTx {
  type: TxType.Base;
  chain: VM;
  outputs: TxOutput[];
  memo?: string;
  txFee: bigint;
}

export type AddSubnetValidatorTx = {
  type: TxType.AddSubnetValidator;
  nodeID: string;
  subnetID: string;
  stake: bigint;
  start: string;
  end: string;
  txFee: bigint;
};

export type CreateChainTx = {
  type: TxType.CreateChain;
  chainName: string;
  chainID: string;
  vmID: string;
  genesisData: string;
  txFee: bigint;
};

export type CreateSubnetTx = {
  type: TxType.CreateSubnet;
  threshold: number;
  controlKeys: string[];
  txFee: bigint;
};

export type RemoveSubnetValidatorTx = {
  type: TxType.RemoveSubnetValidator;
  nodeID: string;
  subnetID: string;
  txFee: bigint;
};

export type AddAutoRenewedValidatorTx = {
  type: TxType.AddAutoRenewedValidator;
  nodeID: string;
  stake: bigint;
  delegationFee: number;
  // Share of staking rewards reinvested as additional stake on each auto-renewal cycle (ACP-236).
  // Expressed in millionths (percentage × 10,000), range [0..1_000_000]: 1_000_000 = 100%, 300_000 = 30%.
  autoCompoundRewardShares: number;
  // Auto-renewal cycle duration in seconds (ACP-236)
  period: bigint;
  publicKey?: string;
  signature?: string;
  txFee: bigint;
};

export type SetAutoRenewedValidatorConfigTx = {
  type: TxType.SetAutoRenewedValidatorConfig;
  // ID of the AddAutoRenewedValidator tx whose config is being updated (ACP-236)
  txId: string;
  // Same scale as `AddAutoRenewedValidatorTx.autoCompoundRewardShares`:
  // millionths (percentage × 10,000), range [0..1_000_000].
  autoCompoundRewardShares: number;
  period: bigint;
  txFee: bigint;
};

export type FeeData = {
  totalAvaxBurned: bigint;
  totalAvaxOutput: bigint;
  totalAvaxInput: bigint;
  isValidAvaxBurnedAmount: boolean;
  txFee: bigint;
};

export type TxBase = FeeData & {
  chain: VM;
};

export type ConvertSubnetToL1Tx = TxBase & {
  type: TxType.ConvertSubnetToL1;
  managerAddress: string;
  validators: {
    nodeId: string;
    stake: bigint;
    balance: bigint;
    remainingBalanceOwners: string[];
    deactivationOwners: string[];
  }[];
  subnetID: string;
  chainID: string;
};

export type RegisterL1ValidatorTx = TxBase & {
  type: TxType.RegisterL1Validator;
  balance: bigint;
};

export type SetL1ValidatorWeightTx = TxBase & {
  type: TxType.SetL1ValidatorWeight;
};

export type IncreaseL1ValidatorBalanceTx = TxBase & {
  type: TxType.IncreaseL1ValidatorBalance;
  balance: bigint;
  validationId: string;
};

export type DisableL1ValidatorTx = TxBase & {
  type: TxType.DisableL1Validator;
  validationId: string;
};

export enum TxType {
  Base = 'base',
  AddValidator = 'add_validator',
  AddDelegator = 'add_delegator',
  Export = 'export',
  Import = 'import',
  CreateSubnet = 'create_subnet',
  CreateChain = 'create_chain',
  AddSubnetValidator = 'add_subnet_validator',
  RemoveSubnetValidator = 'remove_subnet_validator',
  AddPermissionlessValidator = 'add_permissionless_validator',
  AddPermissionlessDelegator = 'add_permissionless_delegator',
  TransformSubnet = 'transform_subnet',
  TransferSubnetOwnership = 'transfer_subnet_ownership',
  ConvertSubnetToL1 = 'convert_subnet_to_l1',
  RegisterL1Validator = 'register_l1_validator',
  SetL1ValidatorWeight = 'set_l1_validator_weight',
  IncreaseL1ValidatorBalance = 'increase_l1_validator_balance',
  DisableL1Validator = 'disable_l1_validator',
  AddAutoRenewedValidator = 'add_auto_renewed_validator',
  SetAutoRenewedValidatorConfig = 'set_auto_renewed_validator_config',
  Unknown = 'unknown',
}
