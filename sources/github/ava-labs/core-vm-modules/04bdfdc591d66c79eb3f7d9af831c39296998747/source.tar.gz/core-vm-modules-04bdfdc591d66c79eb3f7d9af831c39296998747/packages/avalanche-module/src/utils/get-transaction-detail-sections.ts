import { type DetailSection, type Network, type TxDetails } from '@avalabs/vm-module-types';
import { collapsibleGroupItem } from '@internal/utils';
import {
  isAddAutoRenewedValidatorTx,
  isAddPermissionlessDelegatorTx,
  isAddPermissionlessValidatorTx,
  isAddSubnetValidatorTx,
  isBlockchainDetails,
  isExportTx,
  isImportTx,
  isRemoveSubnetValidatorTx,
  isSetAutoRenewedValidatorConfigTx,
  isSubnetDetails,
  isConvertSubnetToL1Tx,
  isDisableL1ValidatorTx,
  isIncreaseL1ValidatorBalanceTx,
  isRegisterL1ValidatorTx,
  isSetL1ValidatorWeightTx,
  isChainDetails,
} from '../handlers/avalanche-send-transaction/typeguards';
import { amountDetailsSections } from './transaction-detail-sections/amount-details-sections';
import { spendDetailsSection } from './transaction-detail-sections/spend-details-section';
import type { TransactionSpendDetails } from './get-transaction-spend-details';
import { valueDetailsSection } from './transaction-detail-sections/value-details-section';
import {
  addAutoRenewedValidatorDetailSection,
  convertSubnetToL1DetailSection,
  addSubnetValidatorDetailSection,
  removeSubnetValidatorDetailSection,
  addPermissionlessValidatorDetailSection,
  blockChainDetailSection,
  subnetDetailSection,
  chainDetailSection,
  exportDetailSection,
  importDetailSection,
  addPermissionlessDelegatorDetailSection,
  disableL1ValidatorDetailSection,
  increaseL1ValidatorBalanceDetailSection,
  registerL1ValidatorDetailSection,
  setAutoRenewedValidatorConfigDetailSection,
  setL1ValidatorWeightDetailSection,
} from './transaction-detail-sections';

export type GetTransactionDetailSectionsContext = {
  network: Network;
  signerAccount: string;
  /** Addresses receiving the funds of a cross-chain transfer - see getExportRecipients. */
  recipients?: string[];
  avaxAssetId?: string;
  spendDetails?: TransactionSpendDetails;
};

const _getDetailSectionsByType = (
  txDetails: TxDetails,
  symbol: string,
  context?: GetTransactionDetailSectionsContext,
) => {
  if (isChainDetails(txDetails)) {
    return chainDetailSection(txDetails, symbol);
  } else if (isExportTx(txDetails)) {
    return exportDetailSection(txDetails, symbol, context?.recipients);
  } else if (isImportTx(txDetails)) {
    return importDetailSection(txDetails, symbol, context?.recipients);
  } else if (isSubnetDetails(txDetails)) {
    return subnetDetailSection(txDetails, symbol);
  } else if (isAddPermissionlessDelegatorTx(txDetails)) {
    if (!context) throw new Error('context (network, signerAccount) is required for AddPermissionlessDelegator');
    return addPermissionlessDelegatorDetailSection({
      tx: txDetails,
      symbol,
      network: context.network,
      signerAccount: context.signerAccount,
    });
  } else if (isAddPermissionlessValidatorTx(txDetails)) {
    if (!context) throw new Error('context (network, signerAccount) is required for AddPermissionlessValidator');
    return addPermissionlessValidatorDetailSection({
      tx: txDetails,
      symbol,
      network: context.network,
      signerAccount: context.signerAccount,
    });
  } else if (isBlockchainDetails(txDetails)) {
    return blockChainDetailSection(txDetails, symbol);
  } else if (isAddSubnetValidatorTx(txDetails)) {
    return addSubnetValidatorDetailSection(txDetails, symbol);
  } else if (isRemoveSubnetValidatorTx(txDetails)) {
    return removeSubnetValidatorDetailSection(txDetails, symbol);
  } else if (isConvertSubnetToL1Tx(txDetails)) {
    return convertSubnetToL1DetailSection(txDetails, symbol);
  } else if (isDisableL1ValidatorTx(txDetails)) {
    return disableL1ValidatorDetailSection(txDetails, symbol);
  } else if (isIncreaseL1ValidatorBalanceTx(txDetails)) {
    return increaseL1ValidatorBalanceDetailSection(txDetails, symbol);
  } else if (isRegisterL1ValidatorTx(txDetails)) {
    return registerL1ValidatorDetailSection(txDetails, symbol);
  } else if (isSetL1ValidatorWeightTx(txDetails)) {
    return setL1ValidatorWeightDetailSection(txDetails, symbol);
  } else if (isAddAutoRenewedValidatorTx(txDetails)) {
    if (!context) throw new Error('context (network, signerAccount) is required for AddAutoRenewedValidator');
    return addAutoRenewedValidatorDetailSection({
      tx: txDetails,
      symbol,
      network: context.network,
      signerAccount: context.signerAccount,
    });
  } else if (isSetAutoRenewedValidatorConfigTx(txDetails)) {
    return setAutoRenewedValidatorConfigDetailSection(txDetails, symbol);
  }
};

export const getTransactionDetailSections = (
  txDetails: TxDetails,
  symbol: string,
  context?: GetTransactionDetailSectionsContext,
): DetailSection[] | undefined => {
  const detailSections = _getDetailSectionsByType(txDetails, symbol, context);

  if (detailSections === undefined) {
    return undefined;
  }

  const spendSection = context?.spendDetails
    ? spendDetailsSection(txDetails, context.spendDetails, symbol, context.avaxAssetId)
    : undefined;

  const valueSection = valueDetailsSection(txDetails, symbol);

  const valueDetails: DetailSection[] = [
    ...amountDetailsSections(txDetails, symbol, context?.avaxAssetId),
    ...(valueSection ? [valueSection] : []),
  ];

  const sections = [...detailSections, ...(spendSection ? [spendSection] : [])];

  if (valueDetails.length === 0) {
    return sections;
  }

  return [...sections, { items: [collapsibleGroupItem('Transfer details', valueDetails)] }];
};
