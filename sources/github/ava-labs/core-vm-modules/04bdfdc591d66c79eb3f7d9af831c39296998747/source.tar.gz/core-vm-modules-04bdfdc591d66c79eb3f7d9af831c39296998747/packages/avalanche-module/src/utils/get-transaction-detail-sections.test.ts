import {
  DetailItemType,
  type Network,
  type NetworkToken,
  NetworkVMType,
  type TxDetails,
  TxType,
} from '@avalabs/vm-module-types';
import { getTransactionDetailSections } from './get-transaction-detail-sections';

const emptyValueDetails = {
  outputs: [],
  inputAmounts: {},
  outputAmounts: {},
  totalAvaxInput: 0n,
  totalAvaxOutput: 0n,
  totalAvaxBurned: 0n,
  isValidAvaxBurnedAmount: true,
};

const getValueDetailsSection = (txDetails: TxDetails, symbol: string) => {
  const items = getTransactionDetailSections(txDetails, symbol)?.flatMap((section) => section.items) ?? [];
  const group = items.find((item) => typeof item !== 'string' && item.type === DetailItemType.COLLAPSIBLE_GROUP);

  return group && typeof group !== 'string' && group.type === DetailItemType.COLLAPSIBLE_GROUP ? group.value : [];
};

const getTransactionOutputsSection = (txDetails: TxDetails, symbol: string) => {
  const [item] =
    getValueDetailsSection(txDetails, symbol).find((section) => section.title === 'Transaction Outputs')?.items ?? [];

  return typeof item === 'string' || item?.type !== DetailItemType.TRANSFER_LIST ? undefined : item.value;
};

const networkToken: NetworkToken = {
  decimals: 18,
  symbol: 'AVAX',
  name: 'Avalanche',
  logoUri: '',
};

const mockNetwork: Network = {
  chainId: 1,
  chainName: 'Test Network',
  rpcUrl: 'https://example.com',
  networkToken,
  vmName: NetworkVMType.PVM,
  logoUri: '',
};

const mockAccount = 'P-avax1mockaccount';

describe('getTransactionDetailSections - Detailed Tests', () => {
  it('should handle chain details', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      type: TxType.Base,
      chain: NetworkVMType.AVM,
      outputs: [
        {
          amount: 100n,
          owners: ['0xOwner1'],
          threshold: 1n,
          locktime: 1n,
          stakeableLocktime: 0n,
          isAvax: true,
          isStake: false,
          assetId: '0xAssetID',
        },
      ],
      txFee: 1n,
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol);
    const expectedDetails = [
      {
        items: [
          {
            label: 'Active chain',
            value: 'Avalanche X-Chain',
            alignment: 'horizontal',
            type: 'text',
          },
        ],
      },
      {
        items: [
          {
            label: 'Fee Amount',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
      {
        items: [
          {
            label: 'Transfer details',
            type: 'collapsibleGroup',
            value: [
              {
                title: 'Transaction Outputs',
                items: [
                  {
                    label: 'Transaction Outputs',
                    type: 'transferList',
                    value: [
                      {
                        addresses: ['0xOwner1'],
                        amount: 100n,
                        assetId: '0xAssetID',
                        isNativeToken: true,
                        symbol: 'AVAX',
                        decimals: 9,
                        threshold: 1,
                        lockedUntil: 1,
                        stakeableLockedUntil: 0,
                      },
                    ],
                  },
                ],
              },
            ],
          },
        ],
      },
    ];
    expect(details).toEqual(expectedDetails);
  });

  it('groups value detail sections into a collapsible section', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      type: TxType.Base,
      chain: NetworkVMType.AVM,
      inputAmounts: { '0xAssetID': 3n },
      outputAmounts: { '0xAssetID': 2n },
      outputs: [
        {
          amount: 100n,
          owners: ['0xOwner1'],
          threshold: 1n,
          locktime: 0n,
          stakeableLocktime: 0n,
          isAvax: true,
          isStake: false,
          assetId: '0xAssetID',
        },
      ],
      txFee: 1n,
    };

    const sections = getTransactionDetailSections(txDetails, networkToken.symbol) ?? [];

    expect(sections.map(({ title }) => title)).toEqual([undefined, undefined, undefined]);
    expect(getValueDetailsSection(txDetails, networkToken.symbol).map(({ title }) => title)).toEqual([
      'Input amounts',
      'Output amounts',
      'Transaction Outputs',
    ]);
  });

  it('skips collapsible group when there are no value details', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      type: TxType.Base,
      chain: NetworkVMType.AVM,
      txFee: 1n,
    };

    expect(getValueDetailsSection(txDetails, networkToken.symbol)).toEqual([]);
  });

  it('returns the proper details for a non-AVAX output', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      type: TxType.Base,
      chain: NetworkVMType.AVM,
      outputs: [
        {
          amount: 100n,
          owners: ['0xOwner1'],
          threshold: 1n,
          locktime: 0n,
          stakeableLocktime: 0n,
          isAvax: false,
          isStake: false,
          assetId: '0xAssetID',
          assetDescription: { assetID: '0xAssetID', name: 'Some Token', symbol: 'TKN', denomination: 2 },
        },
      ],
      txFee: 1n,
    };

    const transfers = getTransactionOutputsSection(txDetails, networkToken.symbol);

    // Previously rendered as AVAX at AVAX's scale.
    expect(transfers?.[0]).toMatchObject({ amount: 100n, decimals: 2, symbol: 'TKN', assetName: 'Some Token' });
  });

  it('returns the assetId for an undescribed non-AVAX output', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      type: TxType.Base,
      chain: NetworkVMType.AVM,
      outputs: [
        {
          amount: 100n,
          owners: ['0xOwner1'],
          threshold: 1n,
          locktime: 0n,
          stakeableLocktime: 0n,
          isAvax: false,
          isStake: false,
          assetId: '0xAssetID',
        },
      ],
      txFee: 1n,
    };

    const transfers = getTransactionOutputsSection(txDetails, networkToken.symbol);

    // Without a symbol the client shows the raw amount against the asset id, rather than a
    // number that would only look like a familiar unit.
    expect(transfers?.[0]).toMatchObject({ amount: 100n, assetId: '0xAssetID' });
    expect(transfers?.[0]?.symbol).toBeUndefined();
    expect(transfers?.[0]?.decimals).toBeUndefined();
  });

  it('returns the proper lock times for each output', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      type: TxType.Base,
      chain: NetworkVMType.AVM,
      outputs: [
        {
          amount: 100n,
          owners: ['0xOwner1'],
          threshold: 1n,
          locktime: 1700n,
          stakeableLocktime: 9900n,
          isAvax: true,
          isStake: false,
          assetId: '0xAssetID',
        },
      ],
      txFee: 1n,
    };

    const transfers = getTransactionOutputsSection(txDetails, networkToken.symbol);

    expect(transfers?.[0]).toMatchObject({ lockedUntil: 1700, stakeableLockedUntil: 9900 });
  });

  it('should handle export transactions', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      amount: 100n,
      chain: NetworkVMType.AVM,
      destination: NetworkVMType.PVM,
      type: TxType.Export,
      txFee: 1n,
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol);
    const expectedDetails = [
      {
        items: [
          {
            label: 'Source Chain',
            value: 'Avalanche X-Chain',
            alignment: 'horizontal',
            type: 'text',
          },
          {
            label: 'Target Chain',
            value: 'Avalanche P-Chain',
            alignment: 'horizontal',
            type: 'text',
          },
        ],
      },
      {
        items: [
          {
            label: 'Transaction Type',
            value: 'Export',
            alignment: 'horizontal',
            type: 'text',
          },
          {
            label: 'Amount',
            value: 100n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
      {
        items: [
          {
            label: 'Fee Amount',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
    ];
    expect(details).toEqual(expectedDetails);
  });

  it('should handle import transactions', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      amount: 100n,
      chain: NetworkVMType.AVM,
      source: NetworkVMType.PVM,
      type: TxType.Import,
      txFee: 1n,
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol);
    const expectedDetails = [
      {
        items: [
          {
            label: 'Source Chain',
            value: 'Avalanche P-Chain',
            alignment: 'horizontal',
            type: 'text',
          },
          {
            label: 'Destination Chain',
            value: 'Avalanche X-Chain',
            alignment: 'horizontal',
            type: 'text',
          },
        ],
      },
      {
        items: [
          {
            label: 'Transaction Type',
            value: 'Import',
            alignment: 'horizontal',
            type: 'text',
          },
          {
            label: 'Amount',
            value: 100n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
      {
        items: [
          {
            label: 'Fee Amount',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
    ];
    expect(details).toEqual(expectedDetails);
  });

  it('should handle subnet details', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      type: TxType.CreateSubnet,
      threshold: 2,
      controlKeys: ['0xKey1', '0xKey2'],
      txFee: 1n,
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol);
    const expectedDetails = [
      {
        title: 'L1 Details',
        items: [
          {
            label: 'Owners',
            value: ['0xKey1', '0xKey2'],
            type: 'addressList',
          },
          {
            label: 'Signature Threshold',
            value: '2/2',
            alignment: 'horizontal',
            type: 'text',
          },
        ],
      },
      {
        items: [
          {
            label: 'Fee Amount',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
    ];
    expect(details).toEqual(expectedDetails);
  });

  it('should handle staking transactions for permissionless delegators', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      type: TxType.AddPermissionlessDelegator,
      nodeID: 'NodeID',
      subnetID: 'SubnetID',
      start: '1691234567',
      end: '1692234567',
      stake: 50n,
      txFee: 1n,
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol, {
      network: mockNetwork,
      signerAccount: mockAccount,
    });
    const expectedDetails = [
      {
        items: [
          { label: 'Account', type: 'address', value: mockAccount },
          { label: 'Network', type: 'network', value: { name: mockNetwork.chainName, logoUri: mockNetwork.logoUri } },
        ],
      },
      {
        title: 'Staking Details',
        items: [
          {
            label: 'Node',
            value: 'NodeID',
            type: 'nodeID',
          },
          {
            label: 'Subnet ID',
            value: 'SubnetID',
            type: 'nodeID',
          },
          {
            label: 'Stake Amount',
            value: 50n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
          {
            label: 'Start',
            value: '1691234567',
            type: 'date',
          },
          {
            label: 'End',
            value: '1692234567',
            type: 'date',
          },
        ],
      },
      {
        items: [
          {
            label: 'Fee Amount',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
    ];
    expect(details).toEqual(expectedDetails);
  });

  it('should handle staking transactions for permissionless validators', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      type: TxType.AddPermissionlessValidator,
      nodeID: 'NodeID',
      subnetID: 'SubnetID',
      delegationFee: 1000,
      start: '1691234567',
      end: '1692234567',
      stake: 50n,
      txFee: 1n,
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol, {
      network: mockNetwork,
      signerAccount: mockAccount,
    });
    const expectedDetails = [
      {
        items: [
          { label: 'Account', type: 'address', value: mockAccount },
          { label: 'Network', type: 'network', value: { name: mockNetwork.chainName, logoUri: mockNetwork.logoUri } },
        ],
      },
      {
        title: 'Staking Details',
        items: [
          {
            label: 'Node',
            value: 'NodeID',
            type: 'nodeID',
          },
          {
            label: 'Subnet ID',
            value: 'SubnetID',
            type: 'nodeID',
          },
          {
            label: 'Stake Amount',
            value: 50n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
          {
            label: 'Delegation Fee',
            value: '0.1 %',
            alignment: 'horizontal',
            type: 'text',
          },
          {
            label: 'Start',
            value: '1691234567',
            type: 'date',
          },
          {
            label: 'End',
            value: '1692234567',
            type: 'date',
          },
        ],
      },
      {
        items: [
          {
            label: 'Fee Amount',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
    ];
    expect(details).toEqual(expectedDetails);
  });

  it('should handle AddSubnetValidator transactions', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      type: TxType.AddSubnetValidator,
      nodeID: 'NodeID',
      start: '1691234567',
      end: '1692234567',
      subnetID: 'SubnetID',
      stake: 100n,
      txFee: 1n,
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol);
    const expectedDetails = [
      {
        title: 'Staking Details',
        items: [
          {
            label: 'Subnet ID',
            value: 'SubnetID',
            type: 'nodeID',
          },
          {
            label: 'Node ID',
            value: 'NodeID',
            type: 'nodeID',
          },
          {
            label: 'Start Date',
            value: '1691234567',
            type: 'date',
          },
          {
            label: 'End Date',
            value: '1692234567',
            type: 'date',
          },
        ],
      },
      {
        items: [
          {
            label: 'Fee Amount',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
    ];
    expect(details).toEqual(expectedDetails);
  });

  it('should handle RemoveSubnetValidator transactions', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      type: TxType.RemoveSubnetValidator,
      nodeID: 'NodeID',
      subnetID: 'SubnetID',
      txFee: 1n,
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol);
    const expectedDetails = [
      {
        title: 'Staking Details',
        items: [
          {
            label: 'Node ID',
            value: 'NodeID',
            type: 'nodeID',
          },
          {
            label: 'Subnet ID',
            value: 'SubnetID',
            type: 'nodeID',
          },
        ],
      },
      {
        items: [
          {
            label: 'Fee Amount',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
    ];
    expect(details).toEqual(expectedDetails);
  });

  it('should handle blockchain details with formatted genesis data', () => {
    // Create a realistic genesis JSON object
    const genesisJson = {
      config: {
        chainId: 43114,
        homesteadBlock: 0,
      },
      alloc: {
        '0x1234567890abcdef': { balance: '0x1000000' },
      },
      timestamp: '0x0',
      gasLimit: '0x1312D00',
    };

    // Genesis data comes as a JSON string (not hex-encoded)
    const genesisDataString = JSON.stringify(genesisJson);
    const expectedFormattedGenesis = JSON.stringify(genesisJson, null, 2);

    const txDetails: TxDetails = {
      ...emptyValueDetails,
      type: TxType.CreateChain,
      chainID: 'chainID',
      chainName: 'chainName',
      vmID: 'vmID',
      genesisData: genesisDataString,
      txFee: 1n,
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol);
    const expectedDetails = [
      {
        title: 'Blockchain Details',
        items: [
          {
            label: 'Blockchain name',
            value: 'chainName',
            alignment: 'vertical',
            type: 'text',
          },
          {
            label: 'Blockchain ID',
            value: 'chainID',
            alignment: 'vertical',
            type: 'text',
          },
          {
            label: 'Virtual Machine ID',
            value: 'vmID',
            alignment: 'vertical',
            type: 'text',
          },
          {
            label: 'Genesis Data',
            value: expectedFormattedGenesis,
            type: 'data',
          },
        ],
      },
      {
        items: [
          {
            label: 'Fee Amount',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
    ];
    expect(details).toEqual(expectedDetails);
  });

  it('should handle blockchain details with invalid genesis data (error fallback)', () => {
    const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    // Use invalid JSON that cannot be parsed
    const invalidGenesisData = 'invalid-json-string';

    const txDetails: TxDetails = {
      ...emptyValueDetails,
      type: TxType.CreateChain,
      chainID: 'chainID',
      chainName: 'chainName',
      vmID: 'vmID',
      genesisData: invalidGenesisData,
      txFee: 1n,
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol);
    const expectedDetails = [
      {
        title: 'Blockchain Details',
        items: [
          {
            label: 'Blockchain name',
            value: 'chainName',
            alignment: 'vertical',
            type: 'text',
          },
          {
            label: 'Blockchain ID',
            value: 'chainID',
            alignment: 'vertical',
            type: 'text',
          },
          {
            label: 'Virtual Machine ID',
            value: 'vmID',
            alignment: 'vertical',
            type: 'text',
          },
          {
            label: 'Genesis Data',
            value: invalidGenesisData,
            type: 'data',
          },
        ],
      },
      {
        items: [
          {
            label: 'Fee Amount',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
    ];
    expect(details).toEqual(expectedDetails);
    consoleErrorSpy.mockRestore();
  });

  it('should handle convert subnet l1 validator details', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      chain: NetworkVMType.PVM,
      totalAvaxBurned: 1n,
      totalAvaxOutput: 1n,
      totalAvaxInput: 1n,
      isValidAvaxBurnedAmount: true,
      type: TxType.ConvertSubnetToL1,
      chainID: 'chainID',
      managerAddress: 'managerAddress',
      subnetID: 'subnetID',
      validators: [
        {
          balance: 100n,
          stake: 5n,
          nodeId: 'nodeId',
          remainingBalanceOwners: ['0xOwner1'],
          deactivationOwners: ['0xOwner2'],
        },
      ],
      txFee: 1n,
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol);
    const expectedDetails = [
      {
        title: 'L1 Details',
        items: [
          {
            label: 'Subnet ID',
            value: 'subnetID',
            type: 'nodeID',
          },
          {
            label: 'Chain ID',
            value: 'chainID',
            type: 'nodeID',
          },
          {
            label: 'Manager Address',
            value: 'managerAddress',
            type: 'address',
          },
        ],
      },
      {
        title: 'Validators',
        items: [
          {
            label: 'Node ID',
            value: 'nodeId',
            type: 'nodeID',
          },
          {
            label: 'Balance',
            value: 100n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
          {
            label: 'Stake',
            value: 5n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
          {
            label: 'Owner Able to Deactivate',
            value: '0xOwner2',
            alignment: 'vertical',
            type: 'text',
          },
          {
            label: 'Owner of the Remaining Balance',
            value: '0xOwner1',
            alignment: 'vertical',
            type: 'text',
          },
        ],
      },
      {
        items: [
          {
            label: 'Fee Amount',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
    ];
    expect(details).toEqual(expectedDetails);
  });

  it('should handle disable l1 validator details', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      chain: NetworkVMType.PVM,
      totalAvaxBurned: 1n,
      totalAvaxOutput: 1n,
      totalAvaxInput: 1n,
      isValidAvaxBurnedAmount: true,
      type: TxType.DisableL1Validator,
      validationId: 'validationId',
      txFee: 1n,
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol);
    const expectedDetails = [
      {
        title: 'L1 Details',
        items: [
          {
            label: 'Validation ID',
            value: 'validationId',
            type: 'nodeID',
          },
        ],
      },
      {
        items: [
          {
            label: 'Fee Amount',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
    ];
    expect(details).toEqual(expectedDetails);
  });

  it('should handle register l1 validator details', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      chain: NetworkVMType.PVM,
      totalAvaxBurned: 1n,
      totalAvaxOutput: 1n,
      totalAvaxInput: 1n,
      isValidAvaxBurnedAmount: true,
      type: TxType.RegisterL1Validator,
      balance: 1n,
      txFee: 1n,
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol);
    const expectedDetails = [
      {
        title: 'L1 Details',
        items: [
          {
            label: 'Initial balance',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
      {
        items: [
          {
            label: 'Fee Amount',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
    ];
    expect(details).toEqual(expectedDetails);
  });

  it('should handle set l1 validator weight details', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      chain: NetworkVMType.PVM,
      totalAvaxBurned: 1n,
      totalAvaxOutput: 1n,
      totalAvaxInput: 1n,
      isValidAvaxBurnedAmount: true,
      type: TxType.SetL1ValidatorWeight,
      txFee: 1n,
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol);
    const expectedDetails = [
      {
        items: [
          {
            label: 'Fee Amount',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
    ];
    expect(details).toEqual(expectedDetails);
  });

  it('should handle AddAutoRenewedValidator transactions (ACP-236 ppm conversion)', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      type: TxType.AddAutoRenewedValidator,
      nodeID: 'NodeID',
      stake: 50n,
      delegationFee: 300_000,
      autoCompoundRewardShares: 500_000,
      period: 1_209_600n,
      txFee: 1n,
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol, {
      network: mockNetwork,
      signerAccount: mockAccount,
    });
    const expectedDetails = [
      {
        items: [
          { label: 'Account', type: 'address', value: mockAccount },
          { label: 'Network', type: 'network', value: { name: mockNetwork.chainName, logoUri: mockNetwork.logoUri } },
        ],
      },
      {
        title: 'Staking Details',
        items: [
          { label: 'Node', value: 'NodeID', type: 'nodeID' },
          { label: 'Stake Amount', value: 50n, type: 'currency', maxDecimals: 9, symbol: 'AVAX' },
          { label: 'Delegation fee', value: '30 %', alignment: 'horizontal', type: 'text' },
          { label: 'Cycle duration', value: '14 days', alignment: 'horizontal', type: 'text' },
          { label: 'Compound rewards percentage', value: '50 %', alignment: 'horizontal', type: 'text' },
        ],
      },
      {
        items: [{ label: 'Fee Amount', value: 1n, type: 'currency', maxDecimals: 9, symbol: 'AVAX' }],
      },
    ];
    expect(details).toEqual(expectedDetails);
  });

  it.each([
    { raw: 0, expected: '0 %' },
    { raw: 1_000, expected: '0.1 %' },
    { raw: 300_000, expected: '30 %' },
    { raw: 1_000_000, expected: '100 %' },
  ])(
    'AddAutoRenewedValidator: autoCompoundRewardShares=$raw renders as $expected (ppm → percent)',
    ({ raw, expected }) => {
      const txDetails: TxDetails = {
        ...emptyValueDetails,
        type: TxType.AddAutoRenewedValidator,
        nodeID: 'NodeID',
        stake: 1n,
        delegationFee: 0,
        autoCompoundRewardShares: raw,
        period: 86_400n,
        txFee: 1n,
      };

      const details = getTransactionDetailSections(txDetails, networkToken.symbol, {
        network: mockNetwork,
        signerAccount: mockAccount,
      });
      const stakingItems = details?.find((s) => s.title === 'Staking Details')?.items;
      expect(stakingItems).toContainEqual({
        label: 'Compound rewards percentage',
        value: expected,
        alignment: 'horizontal',
        type: 'text',
      });
    },
  );

  it('should handle SetAutoRenewedValidatorConfig transactions (ACP-236 ppm conversion)', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      type: TxType.SetAutoRenewedValidatorConfig,
      txId: 'ValidatorTxId',
      autoCompoundRewardShares: 1_000_000,
      period: 2_592_000n,
      txFee: 1n,
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol);
    const expectedDetails = [
      {
        title: 'Staking Details',
        items: [
          { label: 'Validator Tx ID', value: 'ValidatorTxId', type: 'nodeID' },
          { label: 'Cycle duration', value: '30 days', alignment: 'horizontal', type: 'text' },
          { label: 'Compound rewards percentage', value: '100 %', alignment: 'horizontal', type: 'text' },
        ],
      },
      {
        items: [{ label: 'Fee Amount', value: 1n, type: 'currency', maxDecimals: 9, symbol: 'AVAX' }],
      },
    ];
    expect(details).toEqual(expectedDetails);
  });

  it('should handle increase l1 validator balance details', () => {
    const txDetails: TxDetails = {
      ...emptyValueDetails,
      chain: NetworkVMType.PVM,
      totalAvaxBurned: 1n,
      totalAvaxOutput: 1n,
      totalAvaxInput: 1n,
      isValidAvaxBurnedAmount: true,
      type: TxType.IncreaseL1ValidatorBalance,
      txFee: 1n,
      balance: 1n,
      validationId: 'validationId',
    };

    const details = getTransactionDetailSections(txDetails, networkToken.symbol);
    const expectedDetails = [
      {
        title: 'L1 Details',
        items: [
          {
            label: 'Validation ID',
            value: 'validationId',
            type: 'nodeID',
          },
          {
            label: 'Increase by amount',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
      {
        items: [
          {
            label: 'Fee Amount',
            value: 1n,
            type: 'currency',
            maxDecimals: 9,
            symbol: 'AVAX',
          },
        ],
      },
    ];
    expect(details).toEqual(expectedDetails);
  });
});
