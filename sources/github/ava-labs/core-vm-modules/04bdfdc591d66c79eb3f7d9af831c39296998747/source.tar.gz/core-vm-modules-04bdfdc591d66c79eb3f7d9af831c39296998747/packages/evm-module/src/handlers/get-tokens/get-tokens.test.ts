import { getTokens } from './get-tokens';

const PROXY_API_URL = 'https://proxy-api.avax.network';

global.fetch = jest.fn();

describe('get-tokens', () => {
  beforeAll(() => {
    jest.clearAllMocks();
  });

  it('should return an empty array if chain id is not for a valid network', async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => [],
    });

    const result = await getTokens({ chainId: 0, proxyApiUrl: PROXY_API_URL });

    expect(result).toEqual([]);
  });

  it('should return correct contract tokens for Avalanche C-Chain', async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => [
        {
          address: '0xB31f66AA3C1e785363F0875A1B74E27b85FD66c7',
          name: 'Wrapped AVAX',
          symbol: 'WAVAX',
          contractType: 'ERC-20',
          chainId: 43114,
          decimals: 18,
          isNative: false,
        },
        {
          address: '0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E',
          name: 'USD Coin',
          symbol: 'USDC',
          contractType: 'ERC-20',
          chainId: 43114,
          decimals: 6,
          isNative: false,
        },
      ],
    });

    const result = await getTokens({ chainId: 43114, proxyApiUrl: PROXY_API_URL });

    expect(result.length).toBeGreaterThan(0);
    expect(result.find((token) => token.symbol === 'WAVAX')).toBeDefined();
    expect(result.find((token) => token.symbol === 'USDC')).toBeDefined();
  });

  it('should return correct contract tokens for Ethereum', async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => [
        {
          address: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
          name: 'Tether USD',
          symbol: 'USDT',
          contractType: 'ERC-20',
          chainId: 1,
          decimals: 6,
          isNative: false,
        },
        {
          address: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
          name: 'USDCoin',
          symbol: 'USDC',
          contractType: 'ERC-20',
          chainId: 1,
          decimals: 6,
          isNative: false,
        },
        {
          address: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
          name: 'Wrapped BTC',
          symbol: 'WBTC',
          contractType: 'ERC-20',
          chainId: 1,
          decimals: 8,
          isNative: false,
        },
        {
          address: '0x514910771AF9Ca656af840dff83E8264EcF986CA',
          name: 'ChainLink Token',
          symbol: 'LINK',
          contractType: 'ERC-20',
          chainId: 1,
          decimals: 18,
          isNative: false,
        },
      ],
    });

    const result = await getTokens({ chainId: 1, proxyApiUrl: PROXY_API_URL });

    expect(result.length).toBeGreaterThan(0);
    expect(result.find((token) => token.symbol === 'USDT')).toBeDefined();
    expect(result.find((token) => token.symbol === 'USDC')).toBeDefined();
    expect(result.find((token) => token.symbol === 'WBTC')).toBeDefined();
    expect(result.find((token) => token.symbol === 'LINK')).toBeDefined();
  });

  it('should accept tokens with null nullable fields (e.g. Sepolia)', async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => [
        {
          internalId: 'eip155:11155111-0x779877a7b0d9e8603169ddbd7836e478b4624789',
          address: '0x779877a7b0d9e8603169ddbd7836e478b4624789',
          name: 'Chainlink Token',
          symbol: 'LINK',
          isNative: false,
          logoUri: null,
          decimals: 18,
          chainId: 11155111,
          contractType: 'ERC-20',
        },
      ],
    });

    const result = await getTokens({ chainId: 11155111, proxyApiUrl: PROXY_API_URL });

    expect(result.find((token) => token.symbol === 'LINK')).toBeDefined();
  });

  it('should filter out malformed tokens instead of rejecting the whole list', async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => [
        {
          address: '0xB31f66AA3C1e785363F0875A1B74E27b85FD66c7',
          name: 'Wrapped AVAX',
          symbol: 'WAVAX',
          contractType: 'ERC-20',
          chainId: 43114,
          decimals: 18,
          isNative: false,
        },
        // Missing required fields (decimals, isNative) and unknown contractType.
        {
          address: '0x0000000000000000000000000000000000000000',
          name: 'Broken Token',
          symbol: 'BROKE',
          contractType: 'SOME-UNKNOWN-TYPE',
          chainId: 43114,
        },
      ],
    });

    const result = await getTokens({ chainId: 43114, proxyApiUrl: PROXY_API_URL });

    expect(result).toHaveLength(1);
    expect(result[0]?.symbol).toBe('WAVAX');
  });
});
