import {
  type SigningData,
  type Network,
  type ApprovalController,
  type DisplayData,
  type RpcRequest,
  RpcMethod,
  type Alert,
  AlertType,
} from '@avalabs/vm-module-types';
import { rpcErrors } from '@metamask/rpc-errors';
import { toUtf8String } from 'ethers';
import { beautifySimpleMessage, beautifyComplexMessage } from './utils/beautify-message/beautify-message';
import { parseRequestParams } from './schemas/parse-request-params/parse-request-params';
import { isTypedData, isTypedDataV1 } from './utils/typeguards';
import { isTypedDataValid, isTypedDataV1Valid } from './utils/is-typed-data-valid';
import { sanitizeEip712Message } from './utils/eip712-type-check';
import { mergeAlerts } from './utils/merge-alerts';
import { processJsonRpcSimulation } from '../../utils/process-transaction-simulation';
import { textItem } from '@internal/utils/src/utils/detail-item';
import { rpcErrorOpts } from '@internal/utils';
import type Blockaid from '@blockaid/client';
import { getAgentIdentityFromContext } from '../../utils/get-agent-identity-from-context';
import { resolveAgentIdentity } from '../../utils/resolve-agent-identity';
import { buildAgentIdentityDetailSection } from '../../utils/build-agent-identity-detail-section';

const toUtf8StringOrHex = (data: string): string => {
  try {
    return toUtf8String(data);
  } catch {
    return data;
  }
};

export const ethSign = async ({
  request,
  network,
  approvalController,
  blockaid,
}: {
  request: RpcRequest;
  network: Network;
  approvalController: ApprovalController;
  blockaid: Blockaid;
}) => {
  const result = parseRequestParams({ method: request.method, params: request.params });

  if (!result.success) {
    console.error('invalid params', result.error);

    return {
      success: false,
      error: rpcErrors.invalidParams(rpcErrorOpts('Params are invalid', result.error)),
    };
  }
  const { method, data, address } = result.data;

  // validate typed data
  let typedDataValidationResult: ReturnType<typeof isTypedDataValid> | undefined;
  const isLegacyTypedDataMethod = method === RpcMethod.SIGN_TYPED_DATA || method === RpcMethod.SIGN_TYPED_DATA_V1;

  if (method === RpcMethod.SIGN_TYPED_DATA_V3 || method === RpcMethod.SIGN_TYPED_DATA_V4) {
    typedDataValidationResult = isTypedDataValid(data);
  } else if (isLegacyTypedDataMethod) {
    // Check for legacy flat V1 format or a full V3/V4-style typed data object
    if (isTypedDataV1(data)) {
      typedDataValidationResult = isTypedDataV1Valid(data);
    } else if (isTypedData(data)) {
      typedDataValidationResult = isTypedDataValid(data);
    }
  }

  if (typedDataValidationResult && !typedDataValidationResult.isValid && typedDataValidationResult.blocking) {
    return {
      success: false,
      error: rpcErrors.invalidParams(rpcErrorOpts('EIP-712 message is invalid', typedDataValidationResult.error)),
    };
  }

  // generate display data and signing data
  let signingData: SigningData | undefined;
  let messageDetails: string | undefined;
  let alert: Alert | undefined;

  if (typedDataValidationResult && !typedDataValidationResult.isValid) {
    alert = {
      type: AlertType.INFO,
      details: {
        title: 'Warning: Verify Message Content',
        description: 'This message contains non-standard elements. Please verify message content!',
        detailedDescription: (typedDataValidationResult.error as Error).toString(),
      },
    };
  }

  if (method === RpcMethod.ETH_SIGN) {
    signingData = {
      type: method,
      account: address,
      data: data,
    };

    messageDetails = data;
  } else if (method === RpcMethod.PERSONAL_SIGN) {
    signingData = {
      type: method,
      account: address,
      data: data,
    };

    // A payload that isn't valid UTF-8 is still signable, so fall back to the raw bytes
    // rather than throwing out of the handler.
    messageDetails = toUtf8StringOrHex(data);
  } else if (method === RpcMethod.SIGN_TYPED_DATA || method === RpcMethod.SIGN_TYPED_DATA_V1) {
    signingData = {
      type: method,
      account: address,
      data: data,
    };

    if (isTypedDataV1(data)) {
      messageDetails = beautifySimpleMessage(data);
    } else if (isTypedData(data)) {
      messageDetails = beautifyComplexMessage({ ...data, message: sanitizeEip712Message(data) });
    } else {
      messageDetails = beautifyComplexMessage(data);
    }
  } else if (method === RpcMethod.SIGN_TYPED_DATA_V3 || method === RpcMethod.SIGN_TYPED_DATA_V4) {
    signingData = {
      type: method,
      account: address,
      data: data,
    };

    const { types, primaryType, ...messageToDisplay } = data;
    messageDetails = beautifyComplexMessage({ ...messageToDisplay, message: sanitizeEip712Message(data) });
  }

  if (!signingData || !messageDetails) {
    return {
      success: false,
      error: rpcErrors.internal('Unable to generate signing data'),
    };
  }

  const simulationResult = await processJsonRpcSimulation({
    request,
    accountAddress: address,
    chainId: network.chainId,
    data: { method, params: request.params },
    dAppUrl: request.dappInfo.url,
    blockaid,
  });

  const declaration = getAgentIdentityFromContext(request);
  const agentIdentity = declaration
    ? await resolveAgentIdentity({
        declaration,
        rpcUrl: network.rpcUrl,
        chainId: network.chainId,
        chainName: network.chainName,
        customRpcHeaders: network.customRpcHeaders,
      })
    : undefined;

  const displayData: DisplayData = {
    title: 'Sign Message',
    dAppInfo: {
      name: request.dappInfo.name,
      action: `${request.dappInfo.name} is requesting to sign the following message`,
      logoUri: request.dappInfo.icon,
    },
    network: {
      chainId: network.chainId,
      name: network.chainName,
      logoUri: network.logoUri,
    },
    account: address,
    details: [
      {
        title: 'Message',
        items: [textItem('Message', messageDetails, 'vertical')],
      },
      ...(agentIdentity ? [buildAgentIdentityDetailSection(agentIdentity)] : []),
    ],
    alert: mergeAlerts(simulationResult?.alert, alert),
    balanceChange: simulationResult?.balanceChange,
    tokenApprovals: simulationResult?.tokenApprovals,
  };

  // prompt user for approval
  const response = await approvalController.requestApproval({ request, displayData, signingData });

  if ('error' in response) {
    return {
      error: response.error,
    };
  }

  if (!('signedData' in response)) {
    return {
      error: rpcErrors.internal('No signed data returned'),
    };
  }

  return { result: response.signedData };
};
