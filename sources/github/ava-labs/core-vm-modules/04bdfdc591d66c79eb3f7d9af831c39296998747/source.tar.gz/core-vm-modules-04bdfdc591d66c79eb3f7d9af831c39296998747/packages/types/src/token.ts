export enum TokenType {
  NATIVE = 'NATIVE',
  ERC20 = 'ERC20',
  ERC721 = 'ERC721',
  ERC1155 = 'ERC1155',
  NONERC = 'NONERC',
  SPL = 'SPL',
  HYPERCORE_SPOT = 'HYPERCORE_SPOT',
}

export interface NetworkToken {
  name: string;
  symbol: string;
  decimals: number;
  logoUri?: string;
  description?: string;
}

export type NetworkContractToken = ERC20Token | ERC1155Token | ERC721Token | NONERCToken | SPLToken;

export interface ERC20Token {
  address: string;
  chainId?: number;
  color?: string;
  type: TokenType.ERC20;
  decimals: number;
  logoUri?: string;
  name: string;
  symbol: string;
}

export interface SPLToken {
  address: string;
  name: string;
  symbol: string;
  // Discrepancy between what's returned by Proxy API and the other types here.
  // Proxy API returns `contractType`, but in VM Modules we populate `type`.
  contractType: TokenType.SPL;
  type: TokenType.SPL;
  caip2Id: string;
  decimals: number;
  chainId?: number;
  logoUri?: string;
  color?: string;
}

export interface ERC1155Token {
  address: string;
  type: TokenType.ERC1155;
  logoUri?: string;
  name?: string;
  symbol?: string;
}

export interface ERC721Token {
  address: string;
  type: TokenType.ERC721;
  logoUri?: string;
  name?: string;
  symbol?: string;
}

export interface NONERCToken {
  address: string;
  type: TokenType.NONERC;
  logoUri?: string;
  name?: string;
  symbol?: string;
}

/**
 * HyperCore spot token. Identity is the Hyperliquid spot `index`, not an EVM
 * contract. `evmContract` is present only when the asset is bridged to HyperEVM.
 */
export interface HypercoreSpotToken {
  type: TokenType.HYPERCORE_SPOT;
  index: number;
  name: string;
  symbol: string;
  decimals: number;
  logoUri?: string;
  /** Optional HyperEVM bridge contract; not required for HyperCore-only spot. */
  evmContract?: string;
}
