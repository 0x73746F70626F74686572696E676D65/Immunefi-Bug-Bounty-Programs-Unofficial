import type { Avalanche, BitcoinProvider, JsonRpcBatchInternal, SolanaProvider } from '@avalabs/core-wallets-sdk';
import type {
  BuildDerivationPathParams,
  BuildDerivationPathResponse,
  DeriveAddressesParams,
  DeriveAddressesResponse,
  DeriveAddressParams,
  DeriveAddressResponse,
  GetAddressParams,
  GetAddressResponse,
} from './account';
import type { GetBalancesParams, GetBalancesResponse } from './balance';
import { AppName, Environment, type Network } from './common';
import type { Manifest } from './manifest';
import type { NetworkFees } from './network-fee';
import type { RpcRequest, RpcResponse } from './rpc';
import type { NetworkContractToken, HypercoreSpotToken } from './token';
import type { GetTransactionHistory, TransactionHistoryResponse } from './transaction-history';
import type { ApprovalController } from './rpc';
import type { HyperSDKClient } from 'hypersdk-client';
import type { Agent } from 'http';

export type AppInfo = {
  name: AppName;
  version: string;
};

export type ConstructorParams = {
  approvalController: ApprovalController;
  environment: Environment;
  appInfo: AppInfo;
  runtime?: RuntimeParams;
};

export type RuntimeParams = {
  fetch?: typeof fetch;
  httpAgent?: Agent;
  /**
   * Resolves auth headers (e.g. a Firebase AppCheck token) attached to requests
   * against Core's authenticated proxies, such as Glacier via core-proxy-api.
   * Invoked per request, so short-lived tokens are re-read on every call.
   * Optional here; the EVM and Avalanche modules require it in their
   * constructor params since their Glacier calls cannot succeed without it.
   */
  getAuthHeaders?: () => Promise<Record<string, string>>;
};

export type NetworkFeeParam = Network & { caipId?: string };

export interface Module {
  getProvider: (
    network: Network,
  ) => Promise<JsonRpcBatchInternal | BitcoinProvider | Avalanche.JsonRpcProvider | HyperSDKClient | SolanaProvider>;
  getManifest: () => Manifest | undefined;
  getBalances: (params: GetBalancesParams) => Promise<GetBalancesResponse>;
  getTransactionHistory: (params: GetTransactionHistory) => Promise<TransactionHistoryResponse>;
  getNetworkFee: (network: NetworkFeeParam) => Promise<NetworkFees>;
  /**
   * @deprecated Please use `deriveAddress` instead
   */
  getAddress: (params: GetAddressParams) => Promise<GetAddressResponse>;
  deriveAddress: (params: DeriveAddressParams) => Promise<DeriveAddressResponse>;
  deriveAddresses: (params: DeriveAddressesParams) => Promise<DeriveAddressesResponse>;
  buildDerivationPath: (params: BuildDerivationPathParams) => BuildDerivationPathResponse;
  getTokens: (network: Network) => Promise<(NetworkContractToken | HypercoreSpotToken)[]>;
  onRpcRequest: (request: RpcRequest, chain: Network) => Promise<RpcResponse>;
}
