import type { NetworkToken, TransactionHistoryResponse } from '@avalabs/vm-module-types';
import { convertTransaction } from './convert-transaction';
import type { EvmGlacierService } from '../../../../services/glacier-service/glacier-service';

export const getTransactionsFromGlacier = async ({
  chainId,
  explorerUrl,
  networkToken,
  address,
  nextPageToken,
  offset,
  glacierService,
}: {
  chainId: number;
  explorerUrl: string;
  networkToken: NetworkToken;
  address: string;
  nextPageToken?: string;
  offset?: number;
  glacierService: EvmGlacierService;
}): Promise<TransactionHistoryResponse> => {
  try {
    const response = await glacierService.listTransactions({
      chainId: chainId.toString(),
      address,
      pageToken: nextPageToken,
      pageSize: offset,
    });

    const convertedTxs = await Promise.all(
      response.transactions
        .filter(
          // Currently not showing failed tx
          (tranasaction) => tranasaction.nativeTransaction.txStatus === '1',
        )
        .map((transactions) =>
          convertTransaction({
            transactions,
            explorerUrl,
            networkToken,
            chainId,
            address,
          }).then((tx) => tx),
        ),
    );

    const transactions = convertedTxs.filter(
      // Filtering txs with 0 value since there is no change in balance
      (transaction) => transaction.tokens.find((token) => Number(token.amount) !== 0),
    );

    return {
      transactions,
      nextPageToken: response.nextPageToken,
    };
  } catch {
    return {
      transactions: [],
      nextPageToken: '',
    };
  }
};
