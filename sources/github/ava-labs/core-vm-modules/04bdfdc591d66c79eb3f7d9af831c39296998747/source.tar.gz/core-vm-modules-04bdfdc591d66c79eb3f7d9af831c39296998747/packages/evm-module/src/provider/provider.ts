import { providerErrors } from '@metamask/rpc-errors';
import EventEmitter from 'events';
import {
  EventNames,
  type AccountsChangedEventData,
  type ChainAgnosticProvider,
  type ChainChangedEventData,
  type JsonRpcRequestPayload,
  type PartialBy,
  type UnlockStateChangedEventData,
  type EIP6963ProviderInfo,
} from '@avalabs/vm-module-types';
import { InitializationStep, ProviderReadyPromise } from '../utils/provider-ready-promise';

interface ProviderState {
  accounts: string[] | null;
  isConnected: boolean;
  isUnlocked: boolean;
  initialized: boolean;
}

enum DAppProviderRequest {
  INIT_DAPP_STATE = 'avalanche_getProviderState',
}

export class EVMProvider extends EventEmitter {
  #providerReadyPromise = new ProviderReadyPromise([InitializationStep.PROVIDER_STATE_LOADED]);
  #chainagnosticProvider?: ChainAgnosticProvider;

  readonly info: EIP6963ProviderInfo;

  chainId: string | null = null;
  selectedAddress: string | null = null;
  /**
   * The network ID of the currently connected Ethereum chain.
   * @deprecated
   */
  networkVersion: string | null = null;
  isAvalanche = true;
  isMetaMask = true;
  walletVersion: string | null = null;

  _isReady = false;
  _isConnected = false;
  _initialized = false;
  _isUnlocked = false;
  _sessionId = crypto.randomUUID();

  _state: ProviderState = {
    accounts: null,
    isConnected: false,
    isUnlocked: false,
    initialized: false,
  };

  // Metamask compatibility
  _metamask = {
    isUnlocked: () => Promise.resolve(this._isUnlocked),
  };

  constructor({
    maxListeners = 100,
    info,
    walletVersion,
  }: {
    maxListeners?: number;
    info: EIP6963ProviderInfo;
    walletVersion?: string;
  }) {
    super();
    this.info = info;
    this.walletVersion = walletVersion ?? null;
    this.setMaxListeners(maxListeners);
    this.#subscribe();
  }

  #subscribe() {
    window.addEventListener(EventNames.CORE_WALLET_ANNOUNCE_PROVIDER, (event) => {
      if (this.#chainagnosticProvider) {
        return;
      }
      this.#chainagnosticProvider = (<CustomEvent>event).detail.provider;

      this.#chainagnosticProvider?.subscribeToMessage(this.#handleBackgroundMessage);

      this.#init();
    });

    window.dispatchEvent(new Event(EventNames.CORE_WALLET_REQUEST_PROVIDER));
  }
  /**
   * Initializes provider state,  and collects dApp information
   */
  #init = async () => {
    try {
      const response = await this.#request({
        method: DAppProviderRequest.INIT_DAPP_STATE,
      });

      const { chainId, accounts, networkVersion, isUnlocked } =
        (response as {
          isUnlocked: boolean;
          chainId: string | null;
          networkVersion: string | null;
          accounts: string[];
        }) ?? {};

      if (isUnlocked) {
        this._isUnlocked = true;
        this._state.isUnlocked = true;
      }

      if (chainId && chainId !== '0x0' && networkVersion && networkVersion !== 'loading') {
        this.chainId = chainId;
        this.networkVersion = networkVersion;
        this.#connect({ chainId });
        this.#chainChanged({
          chainId,
          networkVersion,
        });
      }

      this.#accountsChanged(accounts || []);

      this.#providerReadyPromise.check(InitializationStep.PROVIDER_STATE_LOADED);
    } catch (e) {
      // the provider will have a partial state, but still should be able to function
    } finally {
      this._initialized = true;
      this._state.initialized = true;
      this._isReady = true;
      this.emit('_initialized');
    }
  };

  #request = async (data: PartialBy<JsonRpcRequestPayload<string>, 'id' | 'params'>) => {
    // Intercept eth_chainId requests, we know where we are.
    if (data.method === 'eth_chainId') {
      return this.chainId;
    }

    return this.#chainagnosticProvider?.request({
      data,
      scope: `eip155:${this.chainId}`,
      sessionId: this._sessionId,
    });
  };

  #getEventHandler = (method: string): ((params: unknown) => void) => {
    const handlerMap = {
      connect: this.#connect,
      disconnect: this.#disconnect,
      accountsChanged: this.#accountsChanged,
      chainChanged: this.#chainChanged,
      avalanche_unlockStateChanged: this.#unlockStateChanged,
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } as any;
    return handlerMap[method];
  };

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  #handleBackgroundMessage = ({ method, params }: any) => {
    const eventHandler = this.#getEventHandler(method);
    if (eventHandler) {
      return eventHandler(params);
    }

    this.emit(method, params);
  };

  isConnected = () => {
    return true;
  };

  request = async (data: PartialBy<JsonRpcRequestPayload<string>, 'id' | 'params'>) => {
    return this.#providerReadyPromise.call(() => {
      return this.#request(data);
    });
  };

  // shim to matamask legacy api
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  sendAsync = (payload: any, callback: any) => {
    if (Array.isArray(payload)) {
      return Promise.all(
        payload.map(
          (item) =>
            new Promise((resolve) => {
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              this.sendAsync(item, (_: any, res: any) => {
                // ignore error
                resolve(res);
              });
            }),
        ),
      ).then((result) => callback(null, result));
    }
    const { method, params, ...rest } = payload;
    this.request({ method, params })
      .then((result) => callback(null, { ...rest, method, result }))
      .catch((error) => callback(error, { ...rest, method, error }));
  };

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  send = (payload: any, callback?: any) => {
    if (typeof payload === 'string' && (!callback || Array.isArray(callback))) {
      return this.request({
        method: payload,
        params: callback,
      }).then((result) => ({
        id: undefined,
        jsonrpc: '2.0',
        result,
      }));
    }

    if (typeof payload === 'object' && typeof callback === 'function') {
      return this.sendAsync(payload, callback);
    }

    let result;
    switch (payload.method) {
      case 'eth_chainId':
        result = this.chainId;
        break;

      case 'eth_accounts':
        result = this.selectedAddress ? [this.selectedAddress] : [];
        break;

      case 'eth_coinbase':
        result = this.selectedAddress || null;
        break;

      default:
        throw new Error('Sync method not supported. Please provide a callback or use the `request` function.');
    }

    return {
      id: payload.id,
      jsonrpc: payload.jsonrpc,
      result,
    };
  };

  enable = () => {
    return this.request({ method: 'eth_requestAccounts' });
  };

  net_version = () => {
    return this.request({ method: 'net_version' });
  };

  #connect = (data: { chainId: string }) => {
    if (!this._isConnected) {
      this._isConnected = true;
      this._state.isConnected = true;
      this.emit('connect', data);
    }
  };

  #unlockStateChanged = ({ accounts, isUnlocked }: UnlockStateChangedEventData) => {
    if (isUnlocked) {
      this._isUnlocked = true;
      this._state.isUnlocked = true;
      this.#accountsChanged(accounts);
    } else {
      this._isUnlocked = false;
    }
  };

  #disconnect = () => {
    this._isConnected = false;
    this._state.isConnected = false;
    this._state.accounts = null;
    this.selectedAddress = null;
    const disconnectError = providerErrors.disconnected();

    this.emit('accountsChanged', []);
    this.emit('disconnect', disconnectError);
    this.emit('close', disconnectError);
  };

  #accountsChanged = (accounts: AccountsChangedEventData) => {
    if (accounts?.[0] === this.selectedAddress) {
      return;
    }

    this.selectedAddress = accounts?.[0] ?? null;
    this._state.accounts = accounts;
    this.emit('accountsChanged', accounts);
  };

  #chainChanged = ({ chainId, networkVersion }: ChainChangedEventData) => {
    this.#connect({ chainId });

    if (chainId !== this.chainId) {
      this.chainId = chainId;
      this.emit('chainChanged', chainId);
    }

    if (networkVersion !== this.networkVersion) {
      this.networkVersion = networkVersion;
      this.emit('networkChanged', networkVersion);
    }
  };
}
