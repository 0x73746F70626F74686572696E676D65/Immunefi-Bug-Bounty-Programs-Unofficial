# @avalabs/evm-module

## 4.2.0

### Minor Changes

- cce416d: add value details to avalanche tx approval screens

### Patch Changes

- Updated dependencies [cce416d]
  - @avalabs/vm-module-types@4.2.0

## 4.1.1

### Patch Changes

- 2497ece: update avalanche-sdks
- 2497ece: fix: bitcoin transaction building
- Updated dependencies [2497ece]
- Updated dependencies [2497ece]
  - @avalabs/vm-module-types@4.1.1

## 4.1.0

### Patch Changes

- Updated dependencies [cfaa839]
  - @avalabs/vm-module-types@4.1.0

## 4.0.6

### Patch Changes

- 3a36c29: fix: batched security fixes
  - @avalabs/vm-module-types@4.0.6

## 4.0.5

### Patch Changes

- c079206: Report `restakedRewards` on `TokenWithBalancePVM.balancePerType`.

  Rewards compounded into an auto-renewed validator are bonded into that validator's weight and have no UTXO until it exits, so Glacier reports them as a bare nAVAX total on the P-chain balance rather than in any UTXO category. `calculateAvaxTotalBalance` already counts them toward the total, but the amount was not surfaced anywhere a consumer could read it, so a wallet could show the compounded stake in its total while being unable to break it out.

  `convertPChainBalance` cannot route the field through its existing `balanceTypes` loop, which is typed `Record<string, AggregatedAssetAmount[]>`, so it is read directly and set alongside the derived categories.

  The field stays `undefined` rather than `0n` when Glacier omits it. Omission is not the same as zero: the field is dropped entirely on historical queries (`blockTimestamp > 0`), where absence means "unavailable", while a current-balance query for an address with no auto-renewed position returns `"0"`. Collapsing the two would report "nothing compounded" for a validator whose compounded stake simply could not be read.

  Requires `@avalabs/glacier-sdk` at `3.1.0-alpha.97` or later, which is where `PChainBalance.restakedRewards` is typed.

- Updated dependencies [c079206]
  - @avalabs/vm-module-types@4.0.5

## 4.0.4

### Patch Changes

- 4d9f873: Bump `@avalabs/avalanchejs` to `5.1.1-alpha.4` and the `@avalabs/*` SDK family to `3.1.0-alpha.97`.

  `avalanchejs` `5.1.1-alpha.4` fixes `Utxo#getOutputOwners()` throwing `unable to get output owner` for `nftfx.TransferOutput`, `nftfx.MintOutput` and `secp256k1fx.MintOutput`, all of which do carry `OutputOwners`. Because `getUtxoInfo()` called it before its own fallbacks could run, anything mapping `getUtxoInfo` over a UTXO set threw when the set contained a single NFT — even when the operation had no interest in that UTXO. On X-chain, where `nftfx` outputs are legal, one NFT anywhere in a wallet broke every X-chain operation for that wallet.

  `avalanche-module` pinned the affected `avalanchejs` exactly, so consumers could not fix this by bumping their own top-level dependency: they received a nested copy of the broken version through here unless they also carried a resolution override.

  The `@avalabs/*` SDKs move from `3.1.0-alpha.96` to `3.1.0-alpha.97` together because those packages are released with locked versioning, and `core-wallets-sdk@3.1.0-alpha.97` pins its siblings at `3.1.0-alpha.97` exactly. Bumping only `core-wallets-sdk` would leave duplicate copies of `core-utils-sdk`, `core-chains-sdk` and `glacier-sdk` in consumers' trees.

  `@avalabs/glacier-sdk` in particular must move in lockstep across **every** package that pins it (including the internal `@internal/utils`): its `CancelablePromise` declares a `#private` field, so TypeScript compares copies nominally, and two physically distinct installs are never assignable to each other — a split pin fails the build with `TS2345` on `GlacierFetchHttpRequest` even though the two versions' emitted types are byte-identical.

- Updated dependencies [4d9f873]
  - @avalabs/vm-module-types@4.0.4

## 4.0.3

### Patch Changes

- 807ed1e: fix: security hardening
  - @avalabs/vm-module-types@4.0.3

## 4.0.2

### Patch Changes

- 0ecf7dc: Fix avax balance calculation
- Updated dependencies [0ecf7dc]
  - @avalabs/vm-module-types@4.0.2

## 4.0.1

### Patch Changes

- 6b68f23: Update SDKs
- Updated dependencies [6b68f23]
  - @avalabs/vm-module-types@4.0.1

## 4.0.0

### Major Changes

- bccae50: Route Glacier calls through core-proxy-api and require per-request auth headers on the EVM and Avalanche modules.

  BREAKING: `EvmModule` and `AvalancheModule` now require `runtime.getAuthHeaders` in their constructor params — an async resolver for auth headers (e.g. a Firebase AppCheck token or a Core API key) invoked on every internal Glacier request. Without it those modules cannot function: `glacierApiUrl` now points at `core-proxy-api.avax.network/v1/proxy/glacier` (prod) / `core-proxy-api.avax-test.network/v1/proxy/glacier` (dev), which rejects unauthenticated requests, and the old `glacier-api.avax.network` host is losing its EVM endpoints as part of the Glacier migration.

  Also removed the client-side Glacier rate-limit key from the avalanche tx handlers (the proxy injects its own rate-limit bypass upstream; dev builds can supply a Core API key via `getAuthHeaders`) and the unused `glacierApiUrl` from bitcoin-module's env.

### Patch Changes

- Updated dependencies [bccae50]
  - @avalabs/vm-module-types@4.0.0

## 3.14.0

### Patch Changes

- @avalabs/vm-module-types@3.14.0

## 3.13.2

### Patch Changes

- 8d8e8d5: Add RL token as header
- Updated dependencies [8d8e8d5]
  - @avalabs/vm-module-types@3.13.2

## 3.13.1

### Patch Changes

- 5210b2d: Exports parseEercTransaction utility function
  - @avalabs/vm-module-types@3.13.1

## 3.13.0

### Minor Changes

- a1f270d: Recognize eERC (Encrypted ERC) transactions by interface and add "Operation" and "Privacy: eERC20" rows to the EVM transaction approval, gated behind a new EVM-module feature toggle.

  The EVM module now accepts its own `runtime.features` (e.g. `{ encryptedERCs: boolean }`) via `EvmRuntimeParams`, and exposes `updateRuntimeParams(partial)` to apply later partial updates (nested `features` are merged) since a module is constructed once. Non-eERC approvals and toggle-off behavior are unchanged.

### Patch Changes

- @avalabs/vm-module-types@3.13.0

## 3.12.1

### Patch Changes

- cf5a3e0: Improved simulation error handling for solana
- cf5a3e0: Add Glacier API key to the Solana provider RPC url and share the `addGlacierAPIKeyIfNeeded` helper between the EVM and SVM modules
- Updated dependencies [cf5a3e0]
  - @avalabs/vm-module-types@3.12.1

## 3.12.0

### Patch Changes

- Updated dependencies [3278272]
  - @avalabs/vm-module-types@3.12.0

## 3.11.0

### Minor Changes

- 2df9a78: Add HyperEVM scan compatible transaction history support.

### Patch Changes

- @avalabs/vm-module-types@3.11.0

## 3.10.0

### Minor Changes

- 363f4d5: Add optional `customTokensOnly` flag to `getBalances`. When set, the EVM module fetches balances only for the provided custom tokens, querying them directly via RPC so real on-chain balances are returned even when an indexed provider doesn't cover them.

### Patch Changes

- Updated dependencies [363f4d5]
  - @avalabs/vm-module-types@3.10.0

## 3.9.4

### Patch Changes

- f0a0ff7: Fixing the evm contract and 'to' transaction details for single transactions
  - @avalabs/vm-module-types@3.9.4

## 3.9.3

### Patch Changes

- 029f3ff: fix: stop routing forwarded dApp `eth_call`s through Multicall3 aggregation
  - @avalabs/vm-module-types@3.9.3

## 3.9.2

### Patch Changes

- d7d6378: Only surface a Blockaid transaction warning when the scan returns a genuine Warning or Malicious verdict
  - @avalabs/vm-module-types@3.9.2

## 3.9.1

### Patch Changes

- 41849c6: Fix sepolia balances
  - @avalabs/vm-module-types@3.9.1

## 3.9.0

### Minor Changes

- bf5f068: feat: add `deriveAddresses` batch interface backed by `@avalabs/crypto-sdk`

  Each module now exposes a batch `deriveAddresses(params)` method that
  resolves one public key per `accountIndex` via the `ApprovalController` and
  encodes addresses through `@avalabs/crypto-sdk`'s per-chain batch encoders
  (avalanche / evm / bitcoin / svm). The `hvm-module` keeps interface parity
  with local ed25519 + sha256 encoding since crypto-sdk has no HVM encoder
  yet. Adds `DeriveAddressesParams` / `DeriveAddressesResponse` types and a
  new `deriveAddresses` method on the `Module` interface.

### Patch Changes

- Updated dependencies [bf5f068]
  - @avalabs/vm-module-types@3.9.0

## 3.8.1

### Patch Changes

- 75ff0b7: fix: allow nullable logoUri in tokens schema
  - @avalabs/vm-module-types@3.8.1

## 3.8.0

### Minor Changes

- 1eaf0ca: auto-renewed validators - ACP-236

### Patch Changes

- Updated dependencies [1eaf0ca]
  - @avalabs/vm-module-types@3.8.0

## 3.7.3

### Patch Changes

- @avalabs/vm-module-types@3.7.3

## 3.7.2

### Patch Changes

- aed1605: Use polygon gas stations
- Updated dependencies [aed1605]
  - @avalabs/vm-module-types@3.7.2

## 3.7.1

### Patch Changes

- 017571e: fix sepolia erc20 balances
  - @avalabs/vm-module-types@3.7.1

## 3.7.0

### Minor Changes

- dd311fe: allow passing custom HTTP headers to RPC calls

### Patch Changes

- Updated dependencies [dd311fe]
  - @avalabs/vm-module-types@3.7.0

## 3.6.2

### Patch Changes

- f81549f: ethereum fusion cross chain as contract call
- f81549f: fix nft tx type
  - @avalabs/vm-module-types@3.6.2

## 3.6.1

### Patch Changes

- 88175bb: clean start for glacier
- Updated dependencies [88175bb]
  - @avalabs/vm-module-types@3.6.1

## 3.6.0

### Patch Changes

- 281614e: getAddressesByIndices supports internalIndices on P Chain; bump sdks
- Updated dependencies [281614e]
  - @avalabs/vm-module-types@3.6.0

## 3.5.1

### Patch Changes

- ab99fe7: Moralis ERC-20 history: fill missing token symbols (fallback to name, then shortened contract address) and trim blank native symbols so Activity shows a label on Base and other Moralis-backed chains.
- 7a303ce: triggering release
- ab99fe7: improve native tokens handling in transactions history
- Updated dependencies [ab99fe7]
  - @avalabs/vm-module-types@3.5.1

## 3.5.0

### Minor Changes

- 90b7306: use Morails for ethereum activity
- 34fb4c3: The modules use runtime.fetch if available

### Patch Changes

- Updated dependencies [34fb4c3]
  - @avalabs/vm-module-types@3.5.0

## 3.4.0

### Minor Changes

- 24ee483: using morails for activities for some chains

### Patch Changes

- @avalabs/vm-module-types@3.4.0

## 3.3.1

### Patch Changes

- 01ac012: Fix zero-value ERC-20 approval display on swap retry when Blockaid simulation reports 0 net exposure change
- 609b694: Hide ERC-20 approval section when allowance is not increasing (covers retry and reduced-allowance scenarios)
  - @avalabs/vm-module-types@3.3.1

## 3.3.0

### Patch Changes

- Updated dependencies [e0878b4]
- Updated dependencies [e0878b4]
  - @avalabs/vm-module-types@3.3.0

## 3.2.0

### Minor Changes

- a28c835: return token id and logo url in transaction simulation for an item

### Patch Changes

- Updated dependencies [a28c835]
  - @avalabs/vm-module-types@3.2.0

## 3.1.4

### Patch Changes

- efce0b3: fix: format genesis data
- Updated dependencies [efce0b3]
  - @avalabs/vm-module-types@3.1.4

## 3.1.3

### Patch Changes

- ed5a98e: bumped the backoff policy up on get tx hash broadcast
  - @avalabs/vm-module-types@3.1.3

## 3.1.2

### Patch Changes

- 81892a7: added retry tx logic to evm send tx via get tx hash and passing isGassless param in options
  - @avalabs/vm-module-types@3.1.2

## 3.1.1

### Patch Changes

- 2e0c5f7: changed exponential backoff params to try 10 times at a 500ms increment
- d311fe6: fix(evm-module): filter out spam transactions from history"
- Updated dependencies [2e0c5f7]
- Updated dependencies [d311fe6]
  - @avalabs/vm-module-types@3.1.1

## 3.1.0

### Minor Changes

- 18ad6d5: Add skipIntermediateTxs option to eth_sendTransactionBatch

### Patch Changes

- Updated dependencies [18ad6d5]
  - @avalabs/vm-module-types@3.1.0

## 3.0.7

### Patch Changes

- e29ce69: remove from address param for avalanche_signTransaction
- Updated dependencies [e29ce69]
  - @avalabs/vm-module-types@3.0.7

## 3.0.6

### Patch Changes

- e29ce69: remove from address param for avalanche_signTransaction
- Updated dependencies [e29ce69]
  - @avalabs/vm-module-types@3.0.6

## 3.0.5

### Patch Changes

- 48393c1: Added new body property to Alert type, keeping it backwards compatible
- Updated dependencies [48393c1]
  - @avalabs/vm-module-types@3.0.5

## 3.0.4

### Patch Changes

- 89bac4e: add onlyWaitForLastTx for batch transactions on EVM
- Updated dependencies [89bac4e]
  - @avalabs/vm-module-types@3.0.4

## 3.0.3

### Patch Changes

- @avalabs/vm-module-types@3.0.3

## 3.0.2

### Patch Changes

- e0ca7cc: change tx details order after parsing
- Updated dependencies [e0ca7cc]
  - @avalabs/vm-module-types@3.0.2

## 3.0.1

### Patch Changes

- cf99e2c: return contract address property for tx history items
- Updated dependencies [cf99e2c]
  - @avalabs/vm-module-types@3.0.1

## 3.0.0

### Patch Changes

- @avalabs/vm-module-types@3.0.0

## 2.2.1

### Patch Changes

- @avalabs/vm-module-types@2.2.1

## 2.2.0

### Patch Changes

- @avalabs/vm-module-types@2.2.0

## 2.1.0

### Patch Changes

- Updated dependencies [3a5223f]
  - @avalabs/vm-module-types@2.1.0

## 2.0.1

### Patch Changes

- 332c6f6: bump release
- Updated dependencies [332c6f6]
  - @avalabs/vm-module-types@2.0.1

## 2.0.0

### Major Changes

- ac90804: add index status and chain id to nft object

### Patch Changes

- @avalabs/vm-module-types@2.0.0

## 1.11.0

### Minor Changes

- f3f11ec: Allow updating gas limit

### Patch Changes

- Updated dependencies [f3f11ec]
  - @avalabs/vm-module-types@1.11.0

## 1.10.3

### Patch Changes

- ba3878e: Use prices from the watchlist for native tokens
  - @avalabs/vm-module-types@1.10.3

## 1.10.2

### Patch Changes

- ec6c4ff: Fix X-chain total balance calculation
- Updated dependencies [ec6c4ff]
  - @avalabs/vm-module-types@1.10.2

## 1.10.1

### Patch Changes

- 67e5683: update avalanche sdks to latest
- Updated dependencies [67e5683]
  - @avalabs/vm-module-types@1.10.1

## 1.10.0

### Patch Changes

- cc3811a: feat: support atomic txs on c-chain
- Updated dependencies [cc3811a]
  - @avalabs/vm-module-types@1.10.0

## 1.9.13

### Patch Changes

- @avalabs/vm-module-types@1.9.13

## 1.9.12

### Patch Changes

- 2515443: bump blockaid to 0.48.0
  - @avalabs/vm-module-types@1.9.12

## 1.9.11

### Patch Changes

- edd84ae: fix setApprovalForAll() calls
  - @avalabs/vm-module-types@1.9.11

## 1.9.10

### Patch Changes

- 9c19d70: Pass along the initial fee settings
- 1179c83: use getTransactionReceipt for waiting tx confirmation
  - @avalabs/vm-module-types@1.9.10

## 1.9.9

### Patch Changes

- @avalabs/vm-module-types@1.9.9

## 1.9.8

### Patch Changes

- @avalabs/vm-module-types@1.9.8

## 1.9.7

### Patch Changes

- @avalabs/vm-module-types@1.9.7

## 1.9.6

### Patch Changes

- 6712674: bump internal sdks to 3.1.0-alpha.58
- Updated dependencies [6712674]
  - @avalabs/vm-module-types@1.9.6

## 1.9.5

### Patch Changes

- Updated dependencies [74bb0e0]
- Updated dependencies [74bb0e0]
  - @avalabs/vm-module-types@1.9.5

## 1.9.4

### Patch Changes

- b38bc40: remove network as a separate item in display data
- e5d2d06: transaction callbacks: expose request instead of just request id
- b38bc40: adjust evm display data
- Updated dependencies [b38bc40]
- Updated dependencies [e5d2d06]
- Updated dependencies [b38bc40]
  - @avalabs/vm-module-types@1.9.4

## 1.9.3

### Patch Changes

- f0a0c85: expose explorer link via onTransactionConfirmed
- f0a0c85: add onTransactionPending callback
- Updated dependencies [f0a0c85]
- Updated dependencies [f0a0c85]
  - @avalabs/vm-module-types@1.9.3

## 1.9.2

### Patch Changes

- 76c5994: add glacier api key
  - @avalabs/vm-module-types@1.9.2

## 1.9.1

### Patch Changes

- eb4328a: adjust display data (title, action, alert) for next gen
- Updated dependencies [eb4328a]
  - @avalabs/vm-module-types@1.9.1

## 1.9.0

### Patch Changes

- @avalabs/vm-module-types@1.9.0

## 1.8.1

### Patch Changes

- c32f7e8: adjust message item format for all eth sign
  - @avalabs/vm-module-types@1.8.1

## 1.8.0

### Patch Changes

- @avalabs/vm-module-types@1.8.0

## 1.7.1

### Patch Changes

- @avalabs/vm-module-types@1.7.1

## 1.7.0

### Patch Changes

- @avalabs/vm-module-types@1.7.0

## 1.6.2

### Patch Changes

- @avalabs/vm-module-types@1.6.2

## 1.6.1

### Patch Changes

- @avalabs/vm-module-types@1.6.1

## 1.6.0

### Patch Changes

- Updated dependencies [7896a19]
  - @avalabs/vm-module-types@1.6.0

## 1.5.0

### Minor Changes

- b4b6652: get Solana transaction history
- 55f2c23: feat: introduce deriveAddress() method

### Patch Changes

- 00f59fe: Solana signing RPC calls
- 8acff70: bump internal sdks to 3.1.0-alpha.44
- Updated dependencies [00f59fe]
- Updated dependencies [b4b6652]
- Updated dependencies [8acff70]
- Updated dependencies [1c2d817]
- Updated dependencies [55f2c23]
  - @avalabs/vm-module-types@1.5.0

## 1.4.6

### Patch Changes

- 40def8f: adjust debank nft schema
  - @avalabs/vm-module-types@1.4.6

## 1.4.5

### Patch Changes

- f127197: Getting the token approvals from the traces array instead of the exposures array from the simulation result returned by Blockaid
  - @avalabs/vm-module-types@1.4.5

## 1.4.4

### Patch Changes

- 09a5996: Implementing the blank getNftBalances method on the DeBank service
  - @avalabs/vm-module-types@1.4.4

## 1.4.3

### Patch Changes

- e8e9306: chore: release optimization fix
  - @avalabs/vm-module-types@1.4.3

## 1.4.2

### Patch Changes

- 8af7654: Filtering out the ethereum chain from the supported chain list in the Glacier service so the DeBank service can provide the data
  - @avalabs/vm-module-types@1.4.2

## 1.4.1

### Patch Changes

- 0a75fcc: remove devnet logic
- 0a75fcc: upgrade internal sdks
- Updated dependencies [0a75fcc]
- Updated dependencies [0a75fcc]
  - @avalabs/vm-module-types@1.4.1

## 1.4.0

### Minor Changes

- 8969b33: Add EIP-2930 support

### Patch Changes

- 0954386: Fix broken lock file
- Updated dependencies [0954386]
- Updated dependencies [8969b33]
  - @avalabs/vm-module-types@1.4.0

## 1.3.0

### Minor Changes

- b7f273c: feat: eth_suggestPriceOptions for c-chain

### Patch Changes

- @avalabs/vm-module-types@1.3.0

## 1.2.1

### Patch Changes

- 682d1a8: fix: falsely malicious transaction validation
  - @avalabs/vm-module-types@1.2.1

## 1.2.0

### Minor Changes

- 1f54063: feat: return reputation for ERC20 tokens

### Patch Changes

- Updated dependencies [1f54063]
  - @avalabs/vm-module-types@1.2.0

## 1.1.0

### Minor Changes

- af15f8d: feat: batch signing for EVM, stable release for all
- af15f8d: feat: eth_sendTransactionBatch

### Patch Changes

- af15f8d: feat: add list of non-restricted methods to the manifests
- Updated dependencies [af15f8d]
- Updated dependencies [7bee314]
- Updated dependencies [af15f8d]
- Updated dependencies [af15f8d]
  - @avalabs/vm-module-types@1.1.0

## 0.12.1

### Patch Changes

- 20e096d: chore: update SDKs
- Updated dependencies [20e096d]
  - @avalabs/vm-module-types@0.12.1

## 0.12.0

### Patch Changes

- Updated dependencies [b504f6f]
  - @avalabs/vm-module-types@0.12.0

## 0.11.14

### Patch Changes

- @avalabs/vm-module-types@0.11.14

## 0.11.13

### Patch Changes

- @avalabs/vm-module-types@0.11.13

## 0.11.12

### Patch Changes

- 6c5f7e5: chore: update SDKs and AJS
- Updated dependencies [6c5f7e5]
  - @avalabs/vm-module-types@0.11.12

## 0.11.11

### Patch Changes

- 1286757: fix: request path for gas multiplier
  - @avalabs/vm-module-types@0.11.11

## 0.11.10

### Patch Changes

- b156e27: chore: use devnet
- Updated dependencies [b156e27]
  - @avalabs/vm-module-types@0.11.10

## 0.11.9

### Patch Changes

- a98e95e: accept chainId with number type
  - @avalabs/vm-module-types@0.11.9

## 0.11.8

### Patch Changes

- @avalabs/vm-module-types@0.11.8

## 0.11.7

### Patch Changes

- @avalabs/vm-module-types@0.11.7

## 0.11.6

### Patch Changes

- @avalabs/vm-module-types@0.11.6

## 0.11.5

### Patch Changes

- @avalabs/vm-module-types@0.11.5

## 0.11.4

### Patch Changes

- @avalabs/vm-module-types@0.11.4

## 0.11.3

### Patch Changes

- @avalabs/vm-module-types@0.11.3

## 0.11.2

### Patch Changes

- 70cf899: fix: make _to_ field optional for eth_sendTransaction
- Updated dependencies [70cf899]
  - @avalabs/vm-module-types@0.11.2

## 0.11.1

### Patch Changes

- @avalabs/vm-module-types@0.11.1

## 0.11.0

### Minor Changes

- 293b07b: feat: add bitcoin_signTransaction

### Patch Changes

- Updated dependencies [293b07b]
  - @avalabs/vm-module-types@0.11.0

## 0.10.0

### Minor Changes

- 3114489: feat: allow choosing token types to load balances for

### Patch Changes

- Updated dependencies [3114489]
  - @avalabs/vm-module-types@0.10.0

## 0.9.0

### Minor Changes

- beb8f78: Network fee getter and calculation

### Patch Changes

- Updated dependencies [beb8f78]
  - @avalabs/vm-module-types@0.9.0

## 0.8.0

### Minor Changes

- 2512485: feat: provide fee updater when requesting approval

### Patch Changes

- Updated dependencies [2512485]
  - @avalabs/vm-module-types@0.8.0

## 0.7.3

### Patch Changes

- Updated dependencies [0013947]
  - @avalabs/vm-module-types@0.7.3

## 0.7.2

### Patch Changes

- 8611fe5: handle erc1155 transfers
  - @avalabs/vm-module-types@0.7.2

## 0.7.1

### Patch Changes

- 8611fe5: handle erc1155 transfers
  - @avalabs/vm-module-types@0.7.1

## 0.7.0

### Minor Changes

- 544b726: fix(evm-module): intercept eth_chainId requests

### Patch Changes

- @avalabs/vm-module-types@0.7.0

## 0.6.0

### Minor Changes

- 045271a: Load NFTs on EVM

### Patch Changes

- Updated dependencies [045271a]
  - @avalabs/vm-module-types@0.6.0

## 0.5.1

### Patch Changes

- @avalabs/vm-module-types@0.5.1

## 0.5.0

### Minor Changes

- 5ae9d18: feat: add optional coreVersion param

### Patch Changes

- @avalabs/vm-module-types@0.5.0

## 0.4.2

### Patch Changes

- @avalabs/vm-module-types@0.4.2

## 0.4.1

### Patch Changes

- 9754446: bump internal sdks to 3.1.0-alpha.5
- Updated dependencies [8b7988e]
- Updated dependencies [9754446]
  - @avalabs/vm-module-types@0.4.1

## 0.4.0

### Minor Changes

- 04cc519: feat: add LINK tx detail type

### Patch Changes

- Updated dependencies [04cc519]
  - @avalabs/vm-module-types@0.4.0

## 0.3.1

### Patch Changes

- 34aed51: update chainIds in evm module
  - @avalabs/vm-module-types@0.3.1

## 0.3.0

### Minor Changes

- 1047507: adding evm provider with corresponding stuff

### Patch Changes

- Updated dependencies [1047507]
  - @avalabs/vm-module-types@0.3.0

## 0.2.0

### Minor Changes

- 1047507: adding evm provider with corresponding stuff

### Patch Changes

- Updated dependencies [1047507]
  - @avalabs/vm-module-types@0.2.0

## 0.1.12

### Patch Changes

- 132e988: avalanche_sendTransaction
- Updated dependencies [132e988]
  - @avalabs/vm-module-types@0.1.12

## 0.1.11

### Patch Changes

- Updated dependencies [d8dd608]
  - @avalabs/vm-module-types@0.1.11

## 0.1.10

### Patch Changes

- 4d3c33c: Improve balance fetching and error handling
- Updated dependencies [4d3c33c]
  - @avalabs/vm-module-types@0.1.10

## 0.1.9

### Patch Changes

- @avalabs/vm-module-types@0.1.9

## 0.1.8

### Patch Changes

- b3dcd76: adjust signing result type
- Updated dependencies [b3dcd76]
  - @avalabs/vm-module-types@0.1.8

## 0.1.7

### Patch Changes

- 9adad1d: Implement DeBank service
  - @avalabs/vm-module-types@0.1.7

## 0.1.6

### Patch Changes

- 5c3ee5b: Update use of TokenUnit.toDisplay
- Updated dependencies [5c3ee5b]
  - @avalabs/vm-module-types@0.1.6

## 0.1.5

### Patch Changes

- Updated dependencies [9cf6498]
  - @avalabs/vm-module-types@0.1.5

## 0.1.4

### Patch Changes

- @avalabs/vm-module-types@0.1.4

## 0.1.3

### Patch Changes

- Updated dependencies [806c131]
  - @avalabs/vm-module-types@0.1.3

## 0.1.2

### Patch Changes

- @avalabs/vm-module-types@0.1.2

## 0.1.1

### Patch Changes

- b666331: reference new sdks
- Updated dependencies [b666331]
  - @avalabs/vm-module-types@0.1.1

## 0.1.0

### Minor Changes

- c5dca36: ci updates, docs updates

### Patch Changes

- Updated dependencies [c5dca36]
  - @avalabs/vm-module-types@0.1.0

## 0.0.23

### Patch Changes

- fbdefd2: Replace BN with bigint
- Updated dependencies [fbdefd2]
  - @avalabs/vm-module-types@0.0.23

## 0.0.22

### Patch Changes

- a841a90: handle all eth\_\* methods
  - @avalabs/vm-module-types@0.0.22

## 0.0.21

### Patch Changes

- @avalabs/vm-module-types@0.0.21

## 0.0.20

### Patch Changes

- Updated dependencies [9bfa82d]
  - @avalabs/vm-module-types@0.0.20

## 0.0.19

### Patch Changes

- 5af458b: Add getBalances to avalanche-module
- Updated dependencies [5af458b]
  - @avalabs/vm-module-types@0.0.19

## 0.0.18

### Patch Changes

- af310d3: handle blockaid schema error
  - @avalabs/vm-module-types@0.0.18

## 0.0.17

### Patch Changes

- 3590edf: Transaction parsing, validation and simulation for EVM
- Updated dependencies [3590edf]
  - @avalabs/vm-module-types@0.0.17

## 0.0.16

### Patch Changes

- f39ff3a: Fixe internal dependencies
- bc48457: add support for all eth_sign methods
- Updated dependencies [bc48457]
  - @avalabs/vm-module-types@0.0.16

## 0.0.15

### Patch Changes

- f536d58: add module functions to evm-module
- Updated dependencies [f536d58]
  - @avalabs/vm-module-types@0.0.15
  - @internal/utils@0.0.3

## 0.0.14

### Patch Changes

- 0593258: add getBalances to evm-module
- Updated dependencies [0593258]
  - @avalabs/vm-module-types@0.0.14
  - @internal/utils@0.0.2

## 0.0.13

### Patch Changes

- d9fa0f5: added getNetworkFee to avalanche module
- Updated dependencies [af68c81]
- Updated dependencies [d9fa0f5]
  - @avalabs/vm-module-types@0.0.13

## 0.0.12

### Patch Changes

- d0c2cc9: make module interface more consistent
- 3d8a9a5: test auto sign commit
- 7bc6c6e: add eth_sendTransaction handler
- Updated dependencies [cd97708]
- Updated dependencies [d0c2cc9]
- Updated dependencies [7bc6c6e]
  - @avalabs/vm-module-types@0.0.12

## 0.0.11

### Patch Changes

- e62b48a: update getTransactionHistory:getTxType logic
  - @avalabs/vm-module-types@0.0.11

## 0.0.10

### Patch Changes

- 60f36fa: add getTokens function
- Updated dependencies [60f36fa]
  - @avalabs/vm-module-types@0.0.10

## 0.0.9

### Patch Changes

- 6ffa356: add module functions to evm-module
- Updated dependencies [6ffa356]
  - @avalabs/vm-module-types@0.0.9

## 0.0.8

### Patch Changes

- Updated dependencies [d1d080f]
  - @avalabs/vm-module-types@0.0.8

## 0.0.7

### Patch Changes

- bb98621: Move types to @avalabs/vm-module-types
- Updated dependencies [bb98621]
  - @avalabs/vm-module-types@0.0.7

## 0.0.6

### Patch Changes

- 1122704: test release
- Updated dependencies [1122704]
  - @avalabs/vm-module-types@0.0.6

## 0.0.5

### Patch Changes

- 0b0c52e: Move types to @avalabs/vm-module-types
- Updated dependencies [0b0c52e]
  - @avalabs/vm-module-types@0.0.3

## 0.0.4

### Patch Changes

- 4b7d5e9: Move types from packages-internal/types to packages/types
- Updated dependencies [4b7d5e9]
  - @avalabs/vm-module-types@0.0.2

## 0.0.3

### Patch Changes

- 5d5e2e2: Add GetNetworkFee and GetTransactionHistory to evm module

## 0.0.2

### Patch Changes

- 0992961: move types to devDependencies
