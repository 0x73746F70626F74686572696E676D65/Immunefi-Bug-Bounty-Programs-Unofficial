import {
  type SigningData,
  type Network,
  type ApprovalController,
  type DisplayData,
  type RpcRequest,
  RpcMethod,
  type SigningResult,
  type Hex,
  type AppInfo,
} from '@avalabs/vm-module-types';
import { Network as GlacierNetwork } from '@avalabs/glacier-sdk';
import { parseRequestParams } from './schema';
import { rpcErrors } from '@metamask/rpc-errors';
import { Avalanche } from '@avalabs/core-wallets-sdk';
import { avaxSerial, AVM, EVMUnsignedTx, PVM, UnsignedTx, utils } from '@avalabs/avalanchejs';
import { getProvider } from '../../utils/get-provider';
import { resolveUtxos } from '../../utils/resolve-utxos';
import { getCrossChainRecipients } from '../../utils/get-cross-chain-recipients';
import { parseTxDetails } from '../../utils/parse-tx-details';
import { parseTxDisplayTitle } from './utils/parse-tx-display-title';
import { getCoreHeaders, retry, rpcErrorOpts } from '@internal/utils';
import { getAddressesByIndices } from './utils/get-addresses-by-indices';
import { getTransactionDetailSections } from '../../utils/get-transaction-detail-sections';
import { getTransactionAlert } from '../../utils/get-transaction-alert';
import { getTransactionSpendDetails } from '../../utils/get-transaction-spend-details';
import { getSignerAddresses } from '../../utils/get-signer-addresses';
import { getUnsupportedExportError } from '../../utils/get-unsupported-export-error';
import { getExplorerAddressByNetwork } from '../get-transaction-history/utils';
import { getAccountFromContext } from '../../utils/get-account-from-context';

export const avalancheSendTransaction = async ({
  request,
  network,
  approvalController,
  glacierApiUrl,
  appInfo,
  getAuthHeaders,
}: {
  request: RpcRequest;
  network: Network;
  approvalController: ApprovalController;
  glacierApiUrl: string;
  appInfo: AppInfo;
  getAuthHeaders?: () => Promise<Record<string, string>>;
}) => {
  const result = parseRequestParams(request.params);

  if (!result.success) {
    return {
      error: rpcErrors.invalidParams(rpcErrorOpts('Transaction params are invalid', result.error)),
    };
  }

  try {
    const { transactionHex, chainAlias, externalIndices, internalIndices, utxos: providedUtxoHexes } = result.data;
    const vm = Avalanche.getVmByChainAlias(chainAlias);
    const txBytes = utils.hexToBuffer(transactionHex);
    const isTestnet = network.isTestnet ?? false;
    const provider = await getProvider(network);
    const contextResult = getAccountFromContext(request.context);

    if (!contextResult.success) {
      return {
        error: rpcErrors.invalidParams(contextResult.error),
      };
    }

    const { xpAddress: currentAddress, evmAddress, xpubXP, externalXPAddresses } = contextResult.data;

    const utxos = await resolveUtxos({
      utxoHexes: providedUtxoHexes,
      vm,
      getIndexedUtxos: async () =>
        Avalanche.getUtxosByTxFromGlacier({
          transactionHex,
          chainAlias,
          network: isTestnet ? GlacierNetwork.FUJI : GlacierNetwork.MAINNET,
          url: glacierApiUrl,
          headers: { ...getCoreHeaders(appInfo), ...(await getAuthHeaders?.()) },
        }),
    });

    let unsignedTx: UnsignedTx | EVMUnsignedTx;
    let signerAddressBytes = getSignerAddresses([
      currentAddress,
      evmAddress,
      ...externalXPAddresses.map(({ address }) => address),
    ]);

    if (chainAlias === 'C') {
      unsignedTx = await Avalanche.createAvalancheEvmUnsignedTx({
        txBytes,
        vm,
        utxos,
        fromAddress: currentAddress,
      });
    } else {
      const tx = utils.unpackWithManager(vm, txBytes) as avaxSerial.AvaxTx;

      if (xpubXP !== undefined && typeof xpubXP !== 'string') {
        return {
          error: rpcErrors.invalidParams('xpubXP must be a string'),
        };
      }

      const externalAddresses = await getAddressesByIndices({
        indices: externalIndices ?? [],
        chainAlias,
        isChange: false,
        network,
        xpubXP,
        externalXPAddresses,
      });

      const internalAddresses = await getAddressesByIndices({
        indices: internalIndices ?? [],
        chainAlias,
        isChange: true,
        network,
        xpubXP,
        externalXPAddresses,
      });

      const fromAddresses = [...new Set([currentAddress, ...externalAddresses, ...internalAddresses])];

      const fromAddressBytes = fromAddresses.map((address) => utils.parse(address)[2]);

      signerAddressBytes = [...signerAddressBytes, ...fromAddressBytes];

      unsignedTx = await Avalanche.createAvalancheUnsignedTx({
        tx,
        utxos,
        provider,
        fromAddressBytes,
      });
    }

    const txData = await Avalanche.parseAvalancheTx(unsignedTx, provider, currentAddress);

    const txDetails = parseTxDetails(txData);
    const title = parseTxDisplayTitle(txData);

    // Throw an error if we can't parse the transaction
    if (txData.type === 'unknown' || txDetails === undefined) {
      return {
        error: rpcErrors.internal('Unable to parse transaction data. Unsupported tx type'),
      };
    }

    // Return an error if it's an X/P -> C export transaction and contains any non-AVAX assets
    const avaxAssetId = provider.getContext().avaxAssetID;
    const unsupportedExport = getUnsupportedExportError({
      tx: unsignedTx.getTx(),
      txDetails,
      avaxAssetId,
    });

    if (unsupportedExport) {
      return { error: unsupportedExport };
    }

    const spendDetails = getTransactionSpendDetails({
      tx: unsignedTx.getTx(),
      inputUtxos: unsignedTx.getInputUtxos(),
      signerAddresses: signerAddressBytes,
    });

    const signingData: SigningData = {
      type: RpcMethod.AVALANCHE_SEND_TRANSACTION,
      unsignedTxJson: JSON.stringify(unsignedTx.toJSON()),
      data: txData,
      vm,
      externalIndices,
      internalIndices,
    };

    const details = getTransactionDetailSections(txDetails, network.networkToken.symbol, {
      network,
      signerAccount: currentAddress,
      recipients: getCrossChainRecipients(unsignedTx.getTx(), txDetails, isTestnet),
      avaxAssetId,
      spendDetails,
    });

    // Throw an error if we can't parse the transaction details
    if (details === undefined) {
      return {
        error: rpcErrors.internal('Unable to parse transaction display data. Unsupported tx type'),
      };
    }

    const displayData: DisplayData = {
      title,
      network: {
        chainId: network.chainId,
        name: network.chainName,
        logoUri: network.logoUri,
      },
      details,
      networkFeeSelector: false,
      alert: getTransactionAlert(txDetails, spendDetails, isTestnet),
    };

    // prompt user for approval
    const response = await approvalController.requestApproval({ request, displayData, signingData });

    if ('error' in response) {
      return {
        error: response.error,
      };
    }

    let txHash: Hex;

    try {
      txHash = (await getTxHash(provider, response, vm)) as Hex;
    } catch (error) {
      return {
        error: rpcErrors.internal(rpcErrorOpts('Unable to broadcast transaction', error)),
      };
    }

    waitForTransactionReceipt({
      explorerUrl: network.explorerUrl ?? '',
      provider,
      txHash,
      vm,
      onTransactionPending: approvalController.onTransactionPending,
      onTransactionConfirmed: approvalController.onTransactionConfirmed,
      onTransactionReverted: approvalController.onTransactionReverted,
      onTransactionStatusUnknown: approvalController.onTransactionStatusUnknown,
      request: request,
    });

    return { result: txHash };
  } catch (error) {
    console.error(error);
    return {
      error: rpcErrors.internal(rpcErrorOpts('Unable to create transaction', error)),
    };
  }
};

const getTxHash = async (provider: Avalanche.JsonRpcProvider, response: SigningResult, vm: 'EVM' | 'AVM' | 'PVM') => {
  if ('txHash' in response) {
    return response.txHash;
  }

  // broadcast the signed transaction
  const { txID } = await provider.issueTxHex(response.signedData, vm);
  return txID;
};

const waitForTransactionReceipt = async ({
  explorerUrl,
  provider,
  txHash,
  vm,
  onTransactionPending,
  onTransactionConfirmed,
  onTransactionReverted,
  onTransactionStatusUnknown,
  request,
}: {
  explorerUrl: string;
  provider: Avalanche.JsonRpcProvider;
  txHash: Hex;
  vm: 'EVM' | 'AVM' | 'PVM';
  onTransactionPending: ({
    txHash,
    request,
    explorerLink,
  }: {
    txHash: Hex;
    request: RpcRequest;
    explorerLink: string;
  }) => void;
  onTransactionConfirmed: ({
    txHash,
    explorerLink,
    request,
  }: {
    txHash: Hex;
    explorerLink: string;
    request: RpcRequest;
  }) => void;
  onTransactionReverted: ({ txHash, request }: { txHash: Hex; request: RpcRequest }) => void;
  onTransactionStatusUnknown?: ({
    txHash,
    explorerLink,
    request,
  }: {
    txHash: Hex;
    explorerLink: string;
    request: RpcRequest;
  }) => void;
  request: RpcRequest;
}) => {
  const maxTransactionStatusCheckRetries = 7;

  const explorerLink = getExplorerAddressByNetwork(explorerUrl, txHash);

  try {
    onTransactionPending({ txHash, request, explorerLink });

    if (vm === PVM) {
      // https://docs.avax.network/api-reference/p-chain/api#platformgettxstatus
      const result = await retry({
        operation: () => provider.getApiP().getTxStatus({ txID: txHash }),
        isSuccess: (result) => ['Committed', 'Dropped'].includes(result.status),
        maxRetries: maxTransactionStatusCheckRetries,
      });

      if (result.status === 'Committed') {
        onTransactionConfirmed({ txHash, explorerLink, request });
      } else {
        onTransactionReverted({ txHash, request });
      }
    } else if (vm === AVM) {
      // https://docs.avax.network/api-reference/x-chain/api#avmgettxstatus
      const result = await retry({
        operation: () => provider.getApiX().getTxStatus({ txID: txHash }),
        isSuccess: (result) => ['Accepted', 'Rejected'].includes(result.status),
        maxRetries: maxTransactionStatusCheckRetries,
      });

      if (result.status === 'Accepted') {
        onTransactionConfirmed({ txHash, explorerLink, request });
      } else {
        onTransactionReverted({ txHash, request });
      }
    } else {
      // https://docs.avax.network/api-reference/c-chain/api#avaxgetatomictx
      //
      // `getAtomicTxStatus` is deprecated by the node as of avalanchego v1.15.0
      // (Helicon), so acceptance is read from `getAtomicTx` instead. The node
      // sets `blockHeight` only once the atomic tx is accepted and serves both
      // Processing and Dropped txs without one, so its presence is the only
      // acceptance signal available here — which also means a dropped tx is no
      // longer distinguishable from a slow one and surfaces as an unknown
      // status once the poll budget runs out.
      await retry({
        operation: () => provider.getApiC().getAtomicTx({ txID: txHash }),
        isSuccess: (result) => result.blockHeight !== undefined,
        maxRetries: maxTransactionStatusCheckRetries,
      });

      // Unlike the P and X branches above, there is no second terminal state to
      // narrow here: `retry` only returns once `isSuccess` holds, so reaching
      // this line already means the node reported a block height.
      onTransactionConfirmed({ txHash, explorerLink, request });
    }
  } catch (error) {
    console.error(error);
    if (error instanceof Error && error.message.startsWith('Max retry exceeded.')) {
      // Running out of polling attempts is not evidence that the transaction
      // failed — it usually means the node stopped answering or is still
      // processing. Reporting a revert here would tell the user their funds
      // did not move when they very likely did, so this is surfaced as its own
      // non-terminal state instead.
      onTransactionStatusUnknown?.({ txHash, explorerLink, request });
    } else {
      onTransactionReverted({ txHash, request });
    }
  }
};
