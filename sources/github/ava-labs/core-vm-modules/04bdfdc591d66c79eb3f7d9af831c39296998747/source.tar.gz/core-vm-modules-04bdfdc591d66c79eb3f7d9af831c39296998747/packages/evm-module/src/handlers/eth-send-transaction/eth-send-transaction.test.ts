import { ethSendTransaction } from './eth-send-transaction';
import { parseRequestParams } from './schema';
import { estimateGasLimit } from '../../utils/estimate-gas-limit';
import { getNonce } from '../../utils/get-nonce';
import { rpcErrors } from '@metamask/rpc-errors';
import {
  AlertType,
  RpcMethod,
  TokenType,
  type ApprovalController,
  type Network,
  NetworkVMType,
} from '@avalabs/vm-module-types';
import { ZodError } from 'zod';
import { getProvider } from '../../utils/get-provider';
import { getTxUpdater } from '../../utils/evm-tx-updater';
import { resolveAgentIdentity } from '../../utils/resolve-agent-identity';
import waitForExpect from 'wait-for-expect';

// doesn't print the ugly console errors out
jest.spyOn(global.console, 'error').mockImplementation(() => {});

const mockGetProvider = getProvider as jest.MockedFunction<typeof getProvider>;

jest.mock('./schema');
jest.mock('../../utils/evm-tx-updater', () => ({
  getTxUpdater: jest.fn().mockReturnValue({
    updateTx: jest.fn(),
    cleanup: jest.fn(),
  }),
}));
jest.mock('../../utils/estimate-gas-limit');
jest.mock('../../utils/get-nonce');
jest.mock('../../utils/get-provider');
jest.mock('../../utils/resolve-agent-identity', () => ({
  resolveAgentIdentity: jest.fn(),
}));
const mockBlockaid = {
  evm: {
    transaction: {
      scan: jest.fn().mockResolvedValue({ validation: { result_type: 'Benign' } }),
    },
    jsonRpc: {
      scan: jest.fn(),
    },
  },
};

const mockOnTransactionConfirmed = jest.fn();
const mockOnTransactionReverted = jest.fn();
const mockOnTransactionPending = jest.fn();
const mockApprovalController: jest.Mocked<ApprovalController> = {
  requestApproval: jest.fn(),
  requestPublicKey: jest.fn(),
  onTransactionPending: mockOnTransactionPending,
  onTransactionConfirmed: mockOnTransactionConfirmed,
  onTransactionReverted: mockOnTransactionReverted,
};

const mockParseRequestParams = parseRequestParams as jest.MockedFunction<typeof parseRequestParams>;
const mockEstimateGasLimit = estimateGasLimit as jest.MockedFunction<typeof estimateGasLimit>;
const mockResolveAgentIdentity = resolveAgentIdentity as jest.MockedFunction<typeof resolveAgentIdentity>;
const mockGetNonce = getNonce as jest.MockedFunction<typeof getNonce>;
const mockSend = jest.fn();
const mockGetTransactionReceipt = jest.fn();

const mockProvider = {
  send: mockSend,
  getTransactionReceipt: mockGetTransactionReceipt,
};

// @ts-expect-error missing properties
mockGetProvider.mockResolvedValue(mockProvider);
const testNetwork: Network = {
  isTestnet: false,
  chainId: 1,
  chainName: 'chainName',
  rpcUrl: 'rpcUrl',
  logoUri: 'logoUri',
  explorerUrl: 'https://explorer.com',
  utilityAddresses: { multicall: 'multiContractAddress' },
  networkToken: {
    name: 'Ethereum',
    symbol: 'ETH',
    decimals: 9,
    description: 'Ethereum Token',
    logoUri: 'some logo uri',
  },
  vmName: NetworkVMType.EVM,
};

const testParams = {
  from: '0xfrom',
  to: '0xto',
  data: '0xdata',
  value: '0xvalue',
  nonce: '12',
  gas: '0x5208',
  chainId: '0x1',
  accessList: [{ address: '0x123', storageKeys: ['0xkey1', '0xkey2'] }],
};
const testDapp = { url: 'https://example.com', name: 'dapp', icon: 'icon' };
const testRequestParams = () => ({
  request: {
    requestId: '1',
    sessionId: '2',
    method: RpcMethod.ETH_SEND_TRANSACTION,
    chainId: 'eip155:1',
    dappInfo: testDapp,
    params: [testParams],
  },
  network: testNetwork,
  approvalController: mockApprovalController,
  blockaid: mockBlockaid as any, // eslint-disable-line @typescript-eslint/no-explicit-any
});

// The default transaction below carries an EIP-2930 access list, so absent a
// scan verdict the approval surfaces the informational access-list alert.
const accessListAlert = {
  type: AlertType.INFO,
  details: {
    title: 'Includes an access list',
    description:
      "This transaction includes EIP-2930 access-list data that pre-declares the accounts and storage it will touch. Its contents aren't part of the security preview.",
  },
};

const displayData = {
  title: 'Do you approve this transaction?',
  details: [
    {
      title: 'Transaction Details',
      items: [
        {
          label: 'Account',
          value: '0xfrom',
          type: 'address',
        },
        {
          label: 'Network',
          type: 'network',
          value: {
            name: testNetwork.chainName,
            logoUri: testNetwork.logoUri,
          },
        },
        {
          label: 'Website',
          value: testDapp,
          type: 'link',
        },
        {
          label: 'Contract',
          value: '0xto',
          type: 'address',
        },
      ],
    },
  ],
  networkFeeSelector: true,
  alert: accessListAlert,
  tokenApprovals: undefined,
  balanceChange: undefined,
  isSimulationSuccessful: true,
};

const signingData = {
  type: 'eth_sendTransaction',
  account: '0xfrom',
  data: {
    type: 2,
    nonce: 12,
    gasLimit: 21000,
    to: '0xto',
    from: '0xfrom',
    data: '0xdata',
    value: '0xvalue',
    chainId: 1,
    accessList: [{ address: '0x123', storageKeys: ['0xkey1', '0xkey2'] }],
  },
};

const testSignedTxHash = '0xsignedtxhash';
const testTxHash = '0xtxhash';

const testAgentIdentity = {
  agentId: '1599',
  agentRegistry: 'eip155:43114:0x8004A169FB4a3325136EB29fA0ceB6D2e539a432',
  owner: '0x1234567890123456789012345678901234567890',
  reputationScore: 88,
  metadataUri: 'ipfs://agent.json',
  trustLevel: 'high' as const,
};

describe('eth_sendTransaction handler', () => {
  beforeEach(() => {
    jest.clearAllMocks();

    mockParseRequestParams.mockReturnValue({
      success: true,
      data: [testParams],
    });

    mockApprovalController.requestApproval.mockResolvedValue({ signedData: testSignedTxHash });
    mockResolveAgentIdentity.mockResolvedValue(testAgentIdentity);
  });

  it.each([
    ['a different chain given as a number', 137],
    ['a different chain given as a decimal string', '137'],
    ['a different chain given as a hex string', '0x89'],
    ['a chain id that cannot be parsed', 'polygon'],
  ])('should reject %s without requesting approval', async (_, chainId) => {
    // The approval screen only names the connected network, so a transaction bound to
    // another chain would be approved as if it targeted this one.
    mockParseRequestParams.mockReturnValue({
      success: true,
      data: [{ ...testParams, chainId }],
    });

    const result = await ethSendTransaction(testRequestParams());

    expect(result).toMatchObject({
      error: expect.objectContaining({ message: expect.stringContaining('Transaction params are invalid') }),
    });
    expect(mockApprovalController.requestApproval).not.toHaveBeenCalled();
  });

  it('should accept a transaction that does not specify a chain id', async () => {
    const { chainId, ...paramsWithoutChainId } = testParams;
    mockParseRequestParams.mockReturnValue({
      success: true,
      data: [paramsWithoutChainId],
    });

    await ethSendTransaction(testRequestParams());

    expect(mockApprovalController.requestApproval).toHaveBeenCalled();
  });

  it('should return error if request params are invalid', async () => {
    const testError = new Error('Invalid params') as ZodError;
    mockParseRequestParams.mockReturnValue({
      success: false,
      error: testError,
    });

    const response = await ethSendTransaction(testRequestParams());

    expect(response).toEqual({
      error: rpcErrors.invalidParams({
        message: 'Transaction params are invalid: Invalid params',
        data: { cause: testError },
      }),
    });
  });

  it('should calculate gas limit if not provided', async () => {
    const updateTx = jest.fn();
    jest.mocked(getTxUpdater).mockReturnValueOnce({
      updateTx,
      cleanup: jest.fn(),
    });
    mockParseRequestParams.mockReturnValue({
      success: true,
      data: [
        {
          from: '0xfrom',
          to: '0xto',
          data: '0xdata',
          value: '0xvalue',
          nonce: '12',
          accessList: [{ address: '0x123', storageKeys: ['0xkey1', '0xkey2'] }],
        },
      ],
    });
    mockEstimateGasLimit.mockResolvedValue(21000);

    const requestParams = testRequestParams();

    await ethSendTransaction(requestParams);

    expect(mockGetProvider).toHaveBeenCalledWith({
      chainId: 1,
      chainName: 'chainName',
      rpcUrl: 'rpcUrl',
      multiContractAddress: 'multiContractAddress',
      pollingInterval: 1000,
    });

    expect(mockEstimateGasLimit).toHaveBeenCalledWith({
      provider: mockProvider,
      transactionParams: {
        from: '0xfrom',
        to: '0xto',
        data: '0xdata',
        value: '0xvalue',
        accessList: [{ address: '0x123', storageKeys: ['0xkey1', '0xkey2'] }],
      },
    });

    expect(mockApprovalController.requestApproval).toHaveBeenCalledWith({
      request: requestParams.request,
      displayData: {
        ...displayData,
        isSimulationSuccessful: false,
      },
      signingData,
      updateTx,
    });
  });

  it('should calculate nonce if not provided', async () => {
    const updateTx = jest.fn();
    jest.mocked(getTxUpdater).mockReturnValueOnce({
      updateTx,
      cleanup: jest.fn(),
    });
    mockParseRequestParams.mockReturnValue({
      success: true,
      data: [
        {
          from: '0xfrom',
          to: '0xto',
          data: '0xdata',
          value: '0xvalue',
          gas: '0x5208',
          accessList: [{ address: '0x123', storageKeys: ['0xkey1', '0xkey2'] }],
        },
      ],
    });
    mockGetNonce.mockResolvedValue(12);

    const requestParams = testRequestParams();
    await ethSendTransaction(requestParams);

    expect(mockGetProvider).toHaveBeenCalledWith({
      chainId: 1,
      chainName: 'chainName',
      rpcUrl: 'rpcUrl',
      multiContractAddress: 'multiContractAddress',
      pollingInterval: 1000,
    });

    expect(mockGetNonce).toHaveBeenCalledWith({
      provider: mockProvider,
      from: '0xfrom',
    });

    expect(mockApprovalController.requestApproval).toHaveBeenCalledWith({
      request: requestParams.request,
      displayData: {
        ...displayData,
        isSimulationSuccessful: false,
      },
      signingData,
      updateTx,
    });
  });

  it('should calculate both gas and nonce if not provided', async () => {
    const updateTx = jest.fn();
    jest.mocked(getTxUpdater).mockReturnValueOnce({
      updateTx,
      cleanup: jest.fn(),
    });
    mockParseRequestParams.mockReturnValue({
      success: true,
      data: [
        {
          from: '0xfrom',
          to: '0xto',
          data: '0xdata',
          value: '0xvalue',
          accessList: [{ address: '0x123', storageKeys: ['0xkey1', '0xkey2'] }],
        },
      ],
    });
    mockGetNonce.mockResolvedValue(12);
    mockEstimateGasLimit.mockResolvedValue(21000);

    const requestParams = testRequestParams();
    await ethSendTransaction(requestParams);

    expect(mockGetProvider).toHaveBeenCalledWith({
      chainId: 1,
      chainName: 'chainName',
      rpcUrl: 'rpcUrl',
      multiContractAddress: 'multiContractAddress',
      pollingInterval: 1000,
    });

    expect(mockGetNonce).toHaveBeenCalledWith({
      provider: mockProvider,
      from: '0xfrom',
    });

    expect(mockEstimateGasLimit).toHaveBeenCalledWith({
      provider: mockProvider,
      transactionParams: {
        from: '0xfrom',
        to: '0xto',
        data: '0xdata',
        value: '0xvalue',
        accessList: [{ address: '0x123', storageKeys: ['0xkey1', '0xkey2'] }],
      },
    });

    expect(mockApprovalController.requestApproval).toHaveBeenCalledWith({
      request: requestParams.request,
      displayData: {
        ...displayData,
        isSimulationSuccessful: false,
      },
      signingData,
      updateTx,
    });
  });

  it('should add alert object with Warning type to displayData when validation result is Warning', async () => {
    await testWithValidationResultType('Warning');
  });

  it('should not add an alert to displayData when validation result is Error', async () => {
    await testWithValidationResultType('Error');
  });

  it('should add alert object with Danger type to displayData when validation result is Malicious', async () => {
    await testWithValidationResultType('Malicious');
  });

  it('should process transaction and add token approvals and balance changes to displayData', async () => {
    const mockBlockaid = {
      evm: {
        transaction: {
          scan: jest.fn().mockResolvedValue({
            validation: { result_type: 'Benign' },
            simulation: {
              status: 'Success',
              account_summary: {
                traces: [
                  {
                    trace_type: 'ExposureTrace',
                    type: 'ERC20ExposureTrace',
                    asset: {
                      type: TokenType.ERC20,
                      address: '0xTokenAddress',
                      name: 'TokenName',
                      symbol: 'TKN',
                      decimals: 18,
                      logo_url: 'logo_url',
                    },
                    spender: '0xSpenderAddress',
                    exposed: {
                      raw_value: '1',
                      value: 1,
                      usd_price: 1,
                    },
                  },
                ],
                assets_diffs: [
                  {
                    asset: {
                      name: 'TokenName',
                      symbol: 'TKN',
                      decimals: 18,
                      logo_url: 'logo_url',
                      type: TokenType.ERC20,
                      address: '0xTokenAddress',
                    },
                    in: [{ value: '1', usd_price: '1' }],
                    out: [{ value: '1', usd_price: '1' }],
                  },
                ],
              },
            },
          }),
        },
      },
    };

    mockParseRequestParams.mockReturnValue({
      success: true,
      data: [
        {
          from: '0xfrom',
          to: '0xto',
          data: '0xdata',
          value: '0xvalue',
          nonce: '12',
          gas: '0x5208',
          accessList: [{ address: '0x123', storageKeys: ['0xkey1', '0xkey2'] }],
        },
      ],
    });

    const updateTx = jest.fn();
    jest.mocked(getTxUpdater).mockReturnValueOnce({
      updateTx,
      cleanup: jest.fn(),
    });

    const requestParams = {
      ...testRequestParams(),
      blockaid: mockBlockaid as any, // eslint-disable-line @typescript-eslint/no-explicit-any
    };

    await ethSendTransaction(requestParams);

    expect(mockGetProvider).toHaveBeenCalledWith({
      chainId: 1,
      chainName: 'chainName',
      rpcUrl: 'rpcUrl',
      multiContractAddress: 'multiContractAddress',
      pollingInterval: 1000,
    });

    expect(mockApprovalController.requestApproval).toHaveBeenCalledWith({
      request: requestParams.request,
      displayData: {
        ...displayData,
        tokenApprovals: {
          isEditable: true,
          approvals: [
            {
              token: {
                type: TokenType.ERC20,
                address: '0xTokenAddress',
                name: 'TokenName',
                symbol: 'TKN',
                decimals: 18,
                logoUri: 'logo_url',
              },
              spenderAddress: '0xSpenderAddress',
              value: '1',
              usdPrice: '1',
              logoUri: 'logo_url',
            },
          ],
        },
        balanceChange: {
          ins: [
            {
              token: {
                type: TokenType.ERC20,
                address: '0xTokenAddress',
                name: 'TokenName',
                symbol: 'TKN',
                decimals: 18,
                logoUri: 'logo_url',
              },
              items: [
                {
                  displayValue: '1',
                  usdPrice: '1',
                },
              ],
            },
          ],
          outs: [
            {
              token: {
                type: TokenType.ERC20,
                address: '0xTokenAddress',
                name: 'TokenName',
                symbol: 'TKN',
                decimals: 18,
                logoUri: 'logo_url',
              },
              items: [
                {
                  displayValue: '1',
                  usdPrice: '1',
                },
              ],
            },
          ],
        },
      },
      signingData,
      updateTx,
    });
  });

  it('should return error if gas limit calculation fails', async () => {
    mockParseRequestParams.mockReturnValue({
      success: true,
      data: [{ from: '0xfrom', to: '0xto', data: '0xdata', value: '0xvalue', nonce: '12' }],
    });

    mockEstimateGasLimit.mockRejectedValue(new Error('gas calculation error'));

    const requestParams = testRequestParams();
    const response = await ethSendTransaction(requestParams);

    expect(response).toEqual({
      error: rpcErrors.internal({
        message: 'Unable to calculate gas limit: gas calculation error',
        data: { cause: new Error('gas calculation error') },
      }),
    });
  });

  it('should return error if nonce calculation fails', async () => {
    mockParseRequestParams.mockReturnValue({
      success: true,
      data: [{ from: '0xfrom', to: '0xto', data: '0xdata', value: '0xvalue', gas: '0x5208' }],
    });
    mockGetNonce.mockRejectedValue(new Error('Nonce calculation error'));

    const requestParams = testRequestParams();
    const response = await ethSendTransaction(requestParams);

    expect(response).toEqual({
      error: rpcErrors.internal({
        message: 'Unable to calculate nonce: Nonce calculation error',
        data: { cause: new Error('Nonce calculation error') },
      }),
    });
  });

  describe('approval succeeds', () => {
    beforeEach(() => {
      jest.clearAllMocks();

      mockApprovalController.requestApproval.mockResolvedValue({ signedData: testSignedTxHash });
      mockSend.mockResolvedValue(testTxHash);
    });

    it('should broadcast the signed transaction and return transaction hash', async () => {
      const requestParams = testRequestParams();
      const response = await ethSendTransaction(requestParams);

      expect(mockGetProvider).toHaveBeenCalledWith({
        chainId: 1,
        chainName: 'chainName',
        rpcUrl: 'rpcUrl',
        multiContractAddress: 'multiContractAddress',
        pollingInterval: 1000,
      });

      expect(mockSend).toHaveBeenCalledWith('eth_sendRawTransaction', [testSignedTxHash]);

      expect(response).toStrictEqual({ result: testTxHash });
    });

    it('should notify when transaction is confirmed', async () => {
      mockGetTransactionReceipt.mockResolvedValue({ status: 1 });

      const requestParams = testRequestParams();
      const response = await ethSendTransaction(requestParams);

      expect(mockGetProvider).toHaveBeenCalledWith({
        chainId: 1,
        chainName: 'chainName',
        rpcUrl: 'rpcUrl',
        multiContractAddress: 'multiContractAddress',
        pollingInterval: 1000,
      });

      expect(response).toStrictEqual({ result: testTxHash });

      expect(mockGetTransactionReceipt).toHaveBeenCalledWith(testTxHash);

      await waitForExpect(() =>
        expect(mockOnTransactionConfirmed).toHaveBeenCalledWith({
          txHash: testTxHash,
          explorerLink: 'https://explorer.com/tx/' + testTxHash,
          request: requestParams.request,
        }),
      );
    });

    it('should notify when transaction is reverted', async () => {
      mockGetTransactionReceipt.mockResolvedValue({ status: 0 });

      const requestParams = testRequestParams();
      const response = await ethSendTransaction(requestParams);

      expect(mockGetProvider).toHaveBeenCalledWith({
        chainId: 1,
        chainName: 'chainName',
        rpcUrl: 'rpcUrl',
        multiContractAddress: 'multiContractAddress',
        pollingInterval: 1000,
      });

      expect(response).toStrictEqual({ result: testTxHash });

      expect(mockGetTransactionReceipt).toHaveBeenCalledWith(testTxHash);

      await waitForExpect(() =>
        expect(mockOnTransactionReverted).toHaveBeenCalledWith({ request: requestParams.request, txHash: testTxHash }),
      );
    });
  });

  describe('approval fails', () => {
    it('should return error', async () => {
      mockApprovalController.requestApproval.mockResolvedValue({ error: rpcErrors.internal('something went wrong') });

      const requestParams = testRequestParams();
      const response = await ethSendTransaction(requestParams);

      expect(response).toStrictEqual({ error: rpcErrors.internal('something went wrong') });
    });
  });
});

const testWithValidationResultType = async (resultType: 'Warning' | 'Error' | 'Malicious') => {
  const updateTx = jest.fn();
  jest.mocked(getTxUpdater).mockReturnValueOnce({
    updateTx,
    cleanup: jest.fn(),
  });

  const mockBlockaid = {
    evm: {
      transaction: {
        scan: jest.fn().mockResolvedValue({
          validation: { result_type: resultType },
          simulation: { status: 'Success', account_summary: { exposures: [], assets_diffs: [] } },
        }),
      },
    },
  };

  mockParseRequestParams.mockReturnValue({
    success: true,
    data: [
      {
        from: '0xfrom',
        to: '0xto',
        data: '0xdata',
        value: '0xvalue',
        nonce: '12',
        gas: '0x5208',
        accessList: [{ address: '0x123', storageKeys: ['0xkey1', '0xkey2'] }],
      },
    ],
  });

  const requestParams = {
    ...testRequestParams(),
    blockaid: mockBlockaid as any, // eslint-disable-line @typescript-eslint/no-explicit-any
  };

  await ethSendTransaction(requestParams);

  expect(mockGetProvider).toHaveBeenCalledWith({
    chainId: 1,
    chainName: 'chainName',
    rpcUrl: 'rpcUrl',
    multiContractAddress: 'multiContractAddress',
    pollingInterval: 1000,
  });

  if (resultType === 'Malicious') {
    expect(mockApprovalController.requestApproval).toHaveBeenCalledWith({
      request: requestParams.request,
      displayData: {
        ...displayData,
        alert: {
          type: AlertType.DANGER,
          details: {
            title: 'Scam transaction',
            description: 'This transaction has been flagged as malicious, I understand the risk.',
            body: ['This transaction is malicious', 'do not proceed'],
            actionTitles: {
              reject: 'Reject Transaction',
              proceed: 'Proceed Anyway',
            },
          },
        },
      },
      signingData,
      updateTx,
    });
  } else if (resultType === 'Warning') {
    expect(mockApprovalController.requestApproval).toHaveBeenCalledWith({
      request: requestParams.request,
      displayData: {
        ...displayData,
        alert: {
          type: AlertType.WARNING,
          details: {
            title: 'Suspicious transaction',
            description: 'Use caution, this transaction might be malicious.',
          },
        },
      },
      signingData,
      updateTx,
    });
  } else {
    // `result_type === 'Error'` is not a security verdict, so no scan alert claims
    // the slot and the informational access-list alert is surfaced instead.
    expect(mockApprovalController.requestApproval).toHaveBeenCalledWith({
      request: requestParams.request,
      displayData: { ...displayData, alert: accessListAlert },
      signingData,
      updateTx,
    });
  }
};

describe('agent identity propagation', () => {
  it('does not add an Agent Identity section when no declaration is provided', async () => {
    mockApprovalController.requestApproval.mockResolvedValue({ signedData: testSignedTxHash });

    await ethSendTransaction(testRequestParams());

    const displayData = mockApprovalController.requestApproval.mock.calls.at(-1)?.[0]?.displayData;
    expect(displayData?.details).not.toEqual(
      expect.arrayContaining([expect.objectContaining({ title: 'Agent Identity' })]),
    );
  });

  it('threads resolved agent identity into approval display data', async () => {
    mockResolveAgentIdentity.mockResolvedValue(testAgentIdentity);
    mockApprovalController.requestApproval.mockResolvedValue({ signedData: testSignedTxHash });
    await ethSendTransaction({
      ...testRequestParams(),
      request: {
        ...testRequestParams().request,
        context: {
          agentIdentity: {
            agentId: '1599',
            agentRegistry: 'eip155:43114:0x8004A169FB4a3325136EB29fA0ceB6D2e539a432',
          },
        },
      },
    });

    expect(mockResolveAgentIdentity).toHaveBeenCalledWith({
      declaration: {
        agentId: '1599',
        agentRegistry: 'eip155:43114:0x8004A169FB4a3325136EB29fA0ceB6D2e539a432',
      },
      rpcUrl: testNetwork.rpcUrl,
      chainId: testNetwork.chainId,
      chainName: testNetwork.chainName,
      customRpcHeaders: testNetwork.customRpcHeaders,
    });
    expect(mockApprovalController.requestApproval).toHaveBeenCalledWith(
      expect.objectContaining({
        displayData: expect.objectContaining({
          details: expect.arrayContaining([
            expect.objectContaining({
              title: 'Agent Identity',
              items: expect.arrayContaining([
                expect.objectContaining({ label: 'Agent ID', value: testAgentIdentity.agentId }),
                expect.objectContaining({ label: 'Registry', value: testAgentIdentity.agentRegistry }),
                expect.objectContaining({ label: 'Trust level', value: testAgentIdentity.trustLevel }),
              ]),
            }),
          ]),
        }),
      }),
    );
  });
});
