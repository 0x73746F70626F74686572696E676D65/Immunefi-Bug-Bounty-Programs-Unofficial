export default {
  darkMode: "class",
};
