import { assert } from 'chai'
import { useEnvironment } from './helpers'
import { resetHardhatContext } from "hardhat/plugins-testing"

const DEFAULTS = {
  accounts: 'remote',
  gas: 'auto',
  gasMultiplier: 1,
  gasPrice: 'auto',
  httpHeaders: {},
  timeout: 20000
}

describe('local networks config plugin', function() {
  describe('when there is no local config path', () => {
    useEnvironment(__dirname + '/helpers/fixtures/project/invalid-config')

    it('should not override any network config', function() {
      Object.entries(this.userNetworks).forEach(([networkName, userNetworkConfig]) => {
        const expectedConfig = Object.assign({}, DEFAULTS, userNetworkConfig);
        assert.deepStrictEqual(this.resolvedNetworks[networkName], expectedConfig)
      })
    })
  })

  describe('when there is a local config path', () => {
    describe('when the given local config path is not valid', () => {
      useEnvironment(__dirname + '/helpers/fixtures/project/invalid-config')

      it('should not override any network config', function() {
        Object.entries(this.userNetworks).forEach(([networkName, userNetworkConfig]) => {
          const expectedConfig = Object.assign({}, DEFAULTS, userNetworkConfig);
          assert.deepStrictEqual(this.resolvedNetworks[networkName], expectedConfig)
        })
      })
    })

    describe("when the given local config path is missing", () => {
      // Not a "quietly ignore" case: an explicitly configured but
      // unresolvable localNetworksConfig path is a hard error (see
      // index.ts's HardhatPluginError). This block predates that check
      // (it's inherited from the pre-fork v0.0.6 test suite) and used to
      // assert silent pass-through; updated to match the behavior actually
      // published in 0.1.0-pre.4 and running in both consumers today.
      it("should throw a HardhatPluginError", function () {
        const projectPath = __dirname + "/helpers/fixtures/project/missing-config"
        const previousCWD = process.cwd()
        process.chdir(projectPath)
        try {
          assert.throws(
            () => require("hardhat"),
            /configuration file not found under "localNetworksConfig" path/
          )
        } finally {
          resetHardhatContext()
          process.chdir(previousCWD)
        }
      })
    })

    describe('when the given local config path is valid', () => {
      const itLoadsTheLocalConfigProperly = (localConfig: any) => {
        it('should prioritize project config over local config', function() {
          const expectedConfig = Object.assign({}, DEFAULTS, this.userNetworks.shouldNotBeOverridden);
          assert.deepStrictEqual(this.resolvedNetworks.shouldNotBeOverridden, expectedConfig)
        })

        it('should extend project config with local config', function() {
          assert.deepStrictEqual(this.resolvedNetworks.shouldBeExtended, {
            ...DEFAULTS,
            ...localConfig.defaultConfig,
            ...localConfig.networks.shouldBeExtended,
            ...this.userNetworks.shouldBeExtended
          })
        })

        // Inherited from the pre-fork v0.0.6 test suite, which asserted the
        // opposite priority (project over local). The deepmerge.all(...)
        // order in index.ts puts localNetworksConfig.networks[name] last,
        // so local overrides project for a directly conflicting key - this
        // is the actual behavior published in 0.1.0-pre.4 and already
        // running in both consumers, verified via a live hre.config.networks
        // diff. Local-over-project matches the plugin's own purpose: letting
        // a developer's private local file override checked-in network
        // config, not the reverse.
        it("should extend project config with local config, local config taking priority", function() {
          assert.deepStrictEqual(this.resolvedNetworks.shouldBePartiallyExtended, {
            ...DEFAULTS,
            ...localConfig.defaultConfig,
            ...this.userNetworks.shouldBePartiallyExtended,
            ...localConfig.networks.shouldBePartiallyExtended
          })
        })

        it('should copy local configs', function() {
          assert.deepStrictEqual(this.resolvedNetworks.shouldBeCopiedFromLocalConfig, {
            ...localConfig.defaultConfig,
            ...localConfig.networks.shouldBeCopiedFromLocalConfig
          })
        })

        it('should extend project config with local default config', function() {
          assert.deepStrictEqual(this.resolvedNetworks.shouldBeOverriddenByDefaultConfig, {
            ...DEFAULTS,
            ...localConfig.defaultConfig,
            ...this.userNetworks.shouldBeOverriddenByDefaultConfig
          })
        })
      }

      describe('with a ts config file', () => {
        const localConfig = require('./helpers/fixtures/local/hardhat.config.ts')
        useEnvironment(__dirname + '/helpers/fixtures/project/valid-config-ts')
        itLoadsTheLocalConfigProperly(localConfig)
      })
      
      describe('with a json config file', () => {
        const localConfig = require('./helpers/fixtures/local/hardhat.config.json')
        useEnvironment(__dirname + '/helpers/fixtures/project/valid-config-json')
        itLoadsTheLocalConfigProperly(localConfig)
      })
    })

    describe("when a network is declared only in the project-local file and also has a home per-network override", () => {
      // Regression test for deviation (a) documented in index.ts's header:
      // this merge path used to omit homeLocalNetworksConfig.networks[networkName]
      // entirely, so a field set ONLY by the home file's per-network override
      // was silently dropped whenever the network wasn't already declared in
      // the project's own hardhat.config.ts. For a field both the local file
      // and the home file set, the local file's own value still wins (it's
      // later in the merge order, matching the other merge branches) - this
      // test targets `w`, which only the home fixture sets, to isolate the
      // fix's actual effect from that priority.
      useEnvironment(
        __dirname + "/helpers/fixtures/project/valid-config-ts",
        __dirname + "/helpers/fixtures/home-override"
      )

      it("pulls in a field set only by the home file's per-network override", function () {
        assert.strictEqual(
          this.resolvedNetworks.shouldBeCopiedFromLocalConfig.w,
          "from-home-only"
        )
      })

      it("still prioritizes the local file's own value for a field both set", function () {
        assert.strictEqual(
          this.resolvedNetworks.shouldBeCopiedFromLocalConfig.x,
          "a"
        )
      })
    })
  })
})
