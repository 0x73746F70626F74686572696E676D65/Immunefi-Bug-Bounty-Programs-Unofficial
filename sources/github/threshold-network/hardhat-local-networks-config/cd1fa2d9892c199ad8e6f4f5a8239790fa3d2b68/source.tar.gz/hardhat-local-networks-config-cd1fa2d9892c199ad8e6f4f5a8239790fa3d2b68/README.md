# @keep-network/hardhat-local-networks-config

A Hardhat plugin that lets a project's `networks` configuration be extended
from a project-local file and/or a `~/.hardhat/networks.json` file in the
developer's home directory, without committing per-developer network
settings (RPC URLs, private keys) to the repository.

## Installation

Add a git dependency in `package.json` (this package is not published to
the npm registry):

```json
"@keep-network/hardhat-local-networks-config": "github:threshold-network/hardhat-local-networks-config#<commit-sha>"
```

Then, in `hardhat.config.ts` (or `.js`):

```ts
import "@keep-network/hardhat-local-networks-config"
```

## Configuration

This plugin extends `HardhatUserConfig` with an optional `localNetworksConfig`
field naming the local config file to load:

```ts
const config: HardhatUserConfig = {
  localNetworksConfig: "./.hardhat/networks.ts",
}
```

The home file, `~/.hardhat/networks.json`, is always read if it exists -
it isn't a fallback for `localNetworksConfig`, and setting one doesn't
disable the other. `localNetworksConfig` adds a second, project-local
file that merges on top of it. Both JS/TS and JSON formats are supported
for either file.

## Usage

The local config file (`localNetworksConfig`, project-specific) and the home
file (`~/.hardhat/networks.json`, machine-wide) both support this shape; any
other field is ignored:

```ts
export interface LocalNetworksConfig {
  networks?: NetworksUserConfig
  defaultConfig?: NetworkUserConfig
}
```

`NetworksUserConfig`/`NetworkUserConfig` are Hardhat's own base types. Example:

```json
{
  "networks": {
    "sepolia": {
      "accounts": ["0x12..56"],
      "url": "https://sepolia.infura.io/v3/<API_KEY>"
    }
  },
  "defaultConfig": {
    "gasPrice": "auto"
  }
}
```

For a network declared in the project's own `hardhat.config.ts`, fields merge
with this priority (highest wins): local config's per-network entry, then the
project's own config, then the home file's per-network entry, then the home
file's `defaultConfig`. For a network declared *only* in the local config
file (not in the project's own `hardhat.config.ts` at all), the home file's
per-network entry still applies (see "Deliberate deviation" below) beneath
the local config's own per-network entry and `defaultConfig`.

## Why this fork exists

This plugin was originally [`hardhat-local-networks-config-plugin`](https://github.com/facuspagnuolo/hardhat-local-networks-config-plugin)
by Facu Spagnuolo, forked to [`keep-network/hardhat-local-networks-config`](https://github.com/keep-network/hardhat-local-networks-config).
Both repositories went unmaintained: no commits since 2022-03-15, no
releases since `0.1.0-pre.4`, and neither repository's default branch
actually contains the source that was published to npm — the real source
only ever existed on an unmerged `load-path-update` branch, and even that
differs slightly from the published tarball.

`threshold-network/keep-core` depended on the last two published
pre-release versions (`0.1.0-pre.0` and `0.1.0-pre.4`) from its two Solidity
packages (`random-beacon` and `ecdsa` respectively). This fork restores it
as a normal, maintained dependency instead of two consumers each vendoring
a private copy of frozen upstream code.

## Provenance of `src/`

Recovered directly from the published npm tarball for `0.1.0-pre.4`
(sha1 `cc0c8ac1f5e30f33378e7451f696ab17d504ab86`) — the only reliable
source of truth for what consumers actually ran, since neither
`facuspagnuolo/hardhat-local-networks-config-plugin` nor
`keep-network/hardhat-local-networks-config`'s default branch ever
matched what was published. `0.1.0-pre.0` (the version `random-beacon`
had pinned) predates this file's `type-extensions.ts` split and the
explicit `import "./type-extensions"` in `index.ts` — it shipped only a
hand-written `src/type-extensions.d.ts` augmenting `hardhat/types` rather
than `hardhat/types/config`. That's a source-shape difference between
the two originally-pinned versions, not a behavioral one: a `declare
module` augmentation has no runtime footprint beyond the side-effect
import itself, which both consuming packages' live `hre.config.networks`
verification already exercised successfully.

## Deliberate deviation from the published tarball

The published 0.1.0-pre.4 plugin has a latent bug: when a network is
declared only in the project-local config file (not in the consuming
project's own `hardhat.config.ts`), the merge for that network omits the
home file's (`~/.hardhat/networks.json`) per-network override entirely -
any field set only there is silently dropped. Fixed here (see `index.ts`'s
header for the exact change); a field the local file also sets still wins
(it's later in the merge order, matching the plugin's other merge
branches - this is intentional, not something the fix changes). Covered
by a regression test in `test/project.test.ts` that fails without the
fix. `extendConfig`'s callback is also named and exported as
`applyLocalNetworksConfig` so that regression test (and any consumer's
own tests) can exercise the merge logic directly.

This is behaviorally inert for both current `threshold-network/keep-core`
consumers as of this writing: neither `ecdsa` nor `random-beacon` sets
`localNetworksConfig` in its committed `hardhat.config.ts` (the option is
present but commented out in both), so the affected merge branch never
runs for either today. Confirmed via a live `hre.config.networks` diff
against both consumers' actual configs before and after switching from
the vendored copy to this package - byte-identical modulo Hardhat's own
per-run `initialDate` timestamp.

## License

MIT, unchanged from upstream. See `LICENSE`.
