// Synchronized with the published npm tarball of
// @keep-network/hardhat-local-networks-config 0.1.0-pre.4
// (sha1 cc0c8ac1f5e30f33378e7451f696ab17d504ab86) — the only reliable source
// of truth for what consumers actually ran; upstream git history diverges from
// the published artifact. Copyright (c) 2019 Nomic Labs LLC. Licensed under
// MIT — see ./LICENSE.
//
// Deliberate local deviations from the published tarball — only these two:
//  (a) the local-only merge path now includes the home (~/.hardhat/networks.json)
//      per-network override; upstream silently dropped it when a network was
//      declared in BOTH the project-local and home configs;
//  (b) the extendConfig callback is named and exported (applyLocalNetworksConfig)
//      so consumer regression tests can exercise the merge logic directly.
import fs from 'fs'
import path from 'path'
import { homedir } from 'os'
import deepmerge from 'deepmerge'
import { extendConfig } from 'hardhat/config'
import { HardhatConfig, NetworkConfig, NetworksUserConfig, NetworkUserConfig, HardhatUserConfig } from 'hardhat/types'
import { HardhatPluginError } from 'hardhat/plugins'
import { parseLocalNetworksConfigPath } from './utils'
import "./type-extensions"

const HARDHAT_CONFIG_DIR = '.hardhat'
const HARDHAT_NETWORK_CONFIG_FILE = 'networks.json'

export interface LocalNetworksConfig {
  networks?: NetworksUserConfig
  defaultConfig?: NetworkUserConfig
}

interface LocalNetworksConfigInternal extends LocalNetworksConfig {
  networks: NetworksUserConfig
  defaultConfig: NetworkUserConfig
}

export function applyLocalNetworksConfig(
  hardhatConfig: HardhatConfig,
  userConfig: HardhatUserConfig
): void {
  const homeLocalNetworksConfig = readHomeNetworksConfig()
  const localNetworksConfig = readLocalNetworksConfig(hardhatConfig, userConfig)

  const userNetworkConfigs = userConfig.networks || []
  Object.entries(userNetworkConfigs).forEach(([networkName, userNetworkConfig]) => {
    hardhatConfig.networks[networkName] = (deepmerge.all([
      hardhatConfig.networks[networkName] || {},
      homeLocalNetworksConfig.defaultConfig,
      homeLocalNetworksConfig.networks[networkName] || {},
      localNetworksConfig.defaultConfig,
      userNetworkConfig as object,
      localNetworksConfig.networks[networkName] || {},
    ]) as NetworkConfig)
  })

  Object.entries(localNetworksConfig.networks).forEach(([networkName, localNetworkConfig]) => {
    if (!hardhatConfig.networks[networkName]) {
      hardhatConfig.networks[networkName] = (deepmerge.all([
        hardhatConfig.networks[networkName] || {},
        homeLocalNetworksConfig.defaultConfig,
        homeLocalNetworksConfig.networks[networkName] || {}, // deviation (a): home per-network override was silently dropped here
        localNetworksConfig.defaultConfig,
        localNetworkConfig as object,
      ]) as NetworkConfig)
    }
  })

  Object.entries(homeLocalNetworksConfig.networks).forEach(([networkName, localNetworkConfig]) => {
    if (!hardhatConfig.networks[networkName]) {
      hardhatConfig.networks[networkName] = (deepmerge.all([
        hardhatConfig.networks[networkName] || {},
        homeLocalNetworksConfig.defaultConfig,
        localNetworksConfig.defaultConfig,
        localNetworkConfig as object,
      ]) as NetworkConfig)
    }
  })
}

extendConfig(applyLocalNetworksConfig)

export function readHomeNetworksConfig(): LocalNetworksConfigInternal {
  const configPath = getDefaultHomeLocalNetworksConfigPath()
  const networksConfig = fs.existsSync(configPath) ? require(configPath) : {}

  if (!networksConfig.networks) networksConfig.networks = []
  if (!networksConfig.defaultConfig) networksConfig.defaultConfig = {}

  return networksConfig
}

export function readLocalNetworksConfig(
  hardhatConfig: HardhatConfig,
  userConfig: HardhatUserConfig
): LocalNetworksConfigInternal {
  const localNetworksConfigPath = parseLocalNetworksConfigPath(userConfig, hardhatConfig.paths.root)

  if (localNetworksConfigPath && !fs.existsSync(localNetworksConfigPath)) {
    throw new HardhatPluginError(
      `hardhat-local-networks-config-plugin`,
      `configuration file not found under "localNetworksConfig" path: ${userConfig.localNetworksConfig}; ` +
        `resolved path: ${localNetworksConfigPath}`
    )
  }

  const localNetworksConfig = localNetworksConfigPath ? require(localNetworksConfigPath) : {}

  if (!localNetworksConfig.networks) localNetworksConfig.networks = []
  if (!localNetworksConfig.defaultConfig) localNetworksConfig.defaultConfig = {}

  return localNetworksConfig
}

export function getDefaultHomeLocalNetworksConfigPath() {
  return path.join(getHomeConfigDir(), HARDHAT_NETWORK_CONFIG_FILE)
}

export function getHomeConfigDir() {
  return path.join(homedir(), HARDHAT_CONFIG_DIR)
}
