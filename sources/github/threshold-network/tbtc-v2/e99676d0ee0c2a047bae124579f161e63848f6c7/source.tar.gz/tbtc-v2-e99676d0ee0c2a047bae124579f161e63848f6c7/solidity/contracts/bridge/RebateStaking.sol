// SPDX-License-Identifier: GPL-3.0-only

// ██████████████     ▐████▌     ██████████████
// ██████████████     ▐████▌     ██████████████
//               ▐████▌    ▐████▌
//               ▐████▌    ▐████▌
// ██████████████     ▐████▌     ██████████████
// ██████████████     ▐████▌     ██████████████
//               ▐████▌    ▐████▌
//               ▐████▌    ▐████▌
//               ▐████▌    ▐████▌
//               ▐████▌    ▐████▌
//               ▐████▌    ▐████▌
//               ▐████▌    ▐████▌

pragma solidity 0.8.17;

import "@openzeppelin/contracts-upgradeable/token/ERC20/IERC20Upgradeable.sol";
import "@openzeppelin/contracts-upgradeable/token/ERC20/utils/SafeERC20Upgradeable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";
import "@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/math/SafeCastUpgradeable.sol";

/// @title Contract for staking T token to get rebate on minting/redemption fees
contract RebateStaking is Initializable, OwnableUpgradeable {
    using SafeERC20Upgradeable for IERC20Upgradeable;

    error CallerNotBridge();
    error ParametersCannotBeZero();
    error RollingWindowCannotBeZero();
    error AmountCannotBeZero();
    error UnstakingAlreadyStarted();
    error AmountTooBig();
    error NoUnstakingProcess();
    error UnstakingNotFinished();
    error ZeroAddress();
    error NotAStaker();
    error WrongDelegatee();
    error AddressAlreadyTaken();

    enum RebateTreasuryFeeMode {
        Both,
        DepositOnly,
        RedemptionOnly
    }

    enum TreasuryFeeType {
        Deposit,
        Redemption
    }

    struct Rebate {
        uint32 timestamp;
        uint64 feeRebate;
        // Reserved storage space in case we need to add more variables.
        // The convention from OpenZeppelin suggests the storage space should
        // add up to 50 slots. Here we want to have more slots as there are
        // planned upgrades of the Bridge contract. If more entires are added to
        // the struct in the upcoming versions we need to reduce the array size.
        // See https://docs.openzeppelin.com/contracts/4.x/upgradeable#storage_gaps
        // slither-disable-next-line unused-state
        uint256[50] __gap;
    }

    struct Stake {
        uint96 stakedAmount;
        uint96 unstakingAmount;
        uint32 unstakingTimestamp;
        uint256 rollingWindowStartIndex;
        Rebate[] rebates;
        RebateTreasuryFeeMode rebateTreasuryFeeMode;
        address delegatee;
    }

    IERC20Upgradeable public token;
    address public bridge;

    uint256 public rollingWindow;
    uint256 public unstakingPeriod;
    uint256 public rebatePerToken;

    mapping(address => Stake) public stakes;
    mapping(address => address) public delegates;

    /// @notice Per-redeemer authorization for callback-path rebate
    ///         application. A staker authorizes a specific Bank balance owner
    ///         to trigger a rebate application crediting that staker's stake
    ///         on callback redemptions where `balanceOwner != redeemer`.
    ///         Many-to-one: many stakers may authorize the same balance owner
    ///         independently. Independent of `delegates` (which redirects
    ///         rebate accounting to a different staker rather than authorizing
    ///         a Bank balance owner).
    mapping(address => mapping(address => bool)) public rebateAuthorizations;

    // Reserved storage space in case we need to add more variables.
    // The convention from OpenZeppelin suggests the storage space should
    // add up to 50 slots. Here we want to have more slots as there are
    // planned upgrades of the Bridge contract. If more entires are added to
    // the struct in the upcoming versions we need to reduce the array size.
    // See https://docs.openzeppelin.com/contracts/4.x/upgradeable#storage_gaps
    // Upgrade note: `rebateAuthorizations` consumed one reserved slot,
    // reducing `__gap` from 49 to 48 for storage-layout compatibility.
    // slither-disable-next-line unused-state
    uint256[48] private __gap;

    event RollingWindowUpdated(uint256 rollingWindow);
    event UnstakingPeriodUpdated(uint256 unstakingPeriod);
    event RebatePerTokenUpdated(uint256 rebatePerToken);
    event RebateReceived(address staker, uint64 rebate);
    event RebateCanceled(address staker, uint256 requestedAt);
    event RebateTreasuryFeeModeUpdated(
        address indexed staker,
        RebateTreasuryFeeMode rebateTreasuryFeeMode
    );
    event Staked(address staker, uint256 amount);
    event UnstakeStarted(address staker, uint256 amount);
    event UnstakeFinished(address staker, uint256 amount);
    event DelegateeSet(address staker, address delegatee);
    event TransferFinished(address oldStaker, address newStaker);
    event RebateAuthorizationSet(
        address indexed redeemer,
        address indexed balanceOwner,
        bool authorized
    );

    /// @custom:oz-upgrades-unsafe-allow constructor
    constructor() {
        _disableInitializers();
    }

    modifier onlyBridge() {
        if (msg.sender != address(bridge)) revert CallerNotBridge();
        _;
    }

    /// @dev Initializes upgradable contract on deployment.
    function initialize(
        address _bridge,
        address _token,
        uint256 _rollingWindow,
        uint256 _unstakingPeriod,
        uint256 _rebatePerToken
    ) external initializer {
        if (
            _bridge == address(0) || _token == address(0) || _rollingWindow == 0
        ) {
            revert ParametersCannotBeZero();
        }
        bridge = _bridge;
        token = IERC20Upgradeable(_token);
        rollingWindow = _rollingWindow;
        unstakingPeriod = _unstakingPeriod;
        rebatePerToken = _rebatePerToken;

        __Ownable_init();
    }

    /// @notice Updates the rolling window.
    /// @param _newRollingWindow Duration of the rolling window.
    /// @dev Requirements:
    ///      - The caller must be the contract owner,
    ///      - The new rolling window cannot be zero
    function updateRollingWindow(uint256 _newRollingWindow) external onlyOwner {
        if (_newRollingWindow == 0) revert RollingWindowCannotBeZero();
        rollingWindow = _newRollingWindow;
        emit RollingWindowUpdated(rollingWindow);
    }

    /// @notice Updates the unstaking period.
    /// @param _newUnstakingPeriod Duration of the unstaking period.
    /// @dev Requirements:
    ///      - The caller must be the contract owner
    function updateUnstakingPeriod(uint256 _newUnstakingPeriod)
        external
        onlyOwner
    {
        unstakingPeriod = _newUnstakingPeriod;
        emit UnstakingPeriodUpdated(unstakingPeriod);
    }

    /// @notice Updates the rebate per token.
    /// @param _newRebatePerToken Rebate coefficient.
    /// @dev Requirements:
    ///      - The caller must be the contract owner
    function updateRebatePerToken(uint256 _newRebatePerToken)
        external
        onlyOwner
    {
        rebatePerToken = _newRebatePerToken;
        emit RebatePerTokenUpdated(rebatePerToken);
    }

    /// @notice Sets the rebate treasury fee mode for caller.
    /// @param _rebateTreasuryFeeMode New rebate treasury fee mode:
    ///        - 0: rebates for both deposits and redemptions,
    ///        - 1: rebates for deposits only,
    ///        - 2: rebates for redemptions only.
    function setRebateTreasuryFeeMode(
        RebateTreasuryFeeMode _rebateTreasuryFeeMode
    ) external {
        stakes[msg.sender].rebateTreasuryFeeMode = _rebateTreasuryFeeMode;
        emit RebateTreasuryFeeModeUpdated(msg.sender, _rebateTreasuryFeeMode);
    }

    /// @notice Sets a delegatee for a rebate.
    /// @param _delegatee Delegatee address.
    function setDelegatee(address _delegatee) external {
        Stake storage stakeInfo = stakes[msg.sender];
        if (stakeInfo.stakedAmount == 0) {
            revert NotAStaker();
        }
        if (stakeInfo.delegatee != address(0)) {
            delegates[stakeInfo.delegatee] = address(0);
        }
        if (_delegatee == address(0) || _delegatee == msg.sender) {
            stakeInfo.delegatee = address(0);
            emit DelegateeSet(msg.sender, msg.sender);
            return;
        }

        if (
            delegates[_delegatee] != address(0) ||
            stakes[_delegatee].stakedAmount != 0
        ) {
            revert WrongDelegatee();
        }
        stakeInfo.delegatee = _delegatee;
        delegates[_delegatee] = msg.sender;
        emit DelegateeSet(msg.sender, _delegatee);
    }

    /// @notice Authorizes or revokes a Bank balance owner to trigger rebate
    ///         application against the caller's stake on callback-path
    ///         redemptions. The caller must be a staker. Authorization is a
    ///         per-pair boolean; many stakers may authorize the same balance
    ///         owner concurrently. Independent of `setDelegatee`.
    /// @param balanceOwner The Bank balance owner authorized to be the
    ///        balance owner on a callback-path redemption that credits the
    ///        caller's stake. Must not be the zero address.
    /// @param authorized True to authorize, false to revoke.
    function setRebateAuthorization(address balanceOwner, bool authorized)
        external
    {
        Stake storage stakeInfo = stakes[msg.sender];
        if (stakeInfo.stakedAmount == 0) {
            revert NotAStaker();
        }
        if (balanceOwner == address(0)) revert ZeroAddress();
        rebateAuthorizations[msg.sender][balanceOwner] = authorized;
        emit RebateAuthorizationSet(msg.sender, balanceOwner, authorized);
    }

    /// @notice Returns true if `redeemer` currently has stake and has
    ///         authorized `balanceOwner` to trigger callback-path rebate
    ///         application crediting the `redeemer`'s stake.
    /// @dev Stale authorizations left by fully unstaked or force-transferred
    ///      addresses are inert. Callback-path delegation is a no-op by
    ///      construction: a zero-stake delegatee fails the `getStake > 0`
    ///      check before `applyForRebate` ever runs.
    /// @param redeemer The current staker address that would be credited with
    ///        the rebate.
    /// @param balanceOwner The Bank balance owner being checked.
    function isRebateAuthorized(address redeemer, address balanceOwner)
        external
        view
        returns (bool)
    {
        if (getStake(redeemer) == 0) {
            return false;
        }

        return rebateAuthorizations[redeemer][balanceOwner];
    }

    /// @notice Calculates cap for rebate for the specified user.
    /// @param user Address of depositor or redeemer
    function getRebateCap(address user) external view returns (uint64) {
        Stake storage stakeInfo = stakes[user];
        return getRebateCap(stakeInfo);
    }

    /// @notice Calculates cap for rebate for the specified user.
    /// @param stakeInfo Staker struct
    function getRebateCap(Stake storage stakeInfo)
        internal
        view
        returns (uint64)
    {
        if (rebatePerToken == 0) {
            return 0;
        }
        return
            SafeCastUpgradeable.toUint64(
                (stakeInfo.stakedAmount - stakeInfo.unstakingAmount) /
                    rebatePerToken
            );
    }

    /// @notice Calculates available rebate for the specified user.
    /// @param user Address of depositor or redeemer
    function getAvailableRebate(address user)
        external
        view
        returns (uint64 rebateInWindow)
    {
        Stake storage stakeInfo = stakes[user];
        uint64 rebateCap = getRebateCap(stakeInfo);
        if (rebateCap == 0) {
            return 0;
        }

        if (stakeInfo.rebates.length == 0) {
            return rebateCap;
        }

        /* solhint-disable-next-line not-rely-on-time */
        uint256 windowStart = block.timestamp - rollingWindow;
        for (
            uint256 i = stakeInfo.rollingWindowStartIndex;
            i < stakeInfo.rebates.length;
            i++
        ) {
            Rebate storage rebate = stakeInfo.rebates[i];
            if (rebate.timestamp >= windowStart) {
                rebateInWindow += rebate.feeRebate;
            }
        }

        return rebateCap - rebateInWindow;
    }

    /// @notice Calculates used rebate in the rolling window.
    /// @param stakeInfo Staker struct
    /// @return rebateInWindow Used rebate in the rolling window
    function getRebateInRollingWindow(Stake storage stakeInfo)
        internal
        returns (uint64 rebateInWindow)
    {
        if (stakeInfo.rebates.length == 0) {
            return 0;
        }

        /* solhint-disable-next-line not-rely-on-time */
        uint256 windowStart = block.timestamp - rollingWindow;
        uint256 rebatesLength = stakeInfo.rebates.length;
        for (
            uint256 i = stakeInfo.rollingWindowStartIndex;
            i < rebatesLength;
            i++
        ) {
            Rebate storage rebate = stakeInfo.rebates[i];
            if (rebate.timestamp < windowStart) {
                stakeInfo.rollingWindowStartIndex++;
            } else {
                rebateInWindow += rebate.feeRebate;
            }
        }

        return rebateInWindow;
    }

    /// @notice Checks if user is eligible for rebate
    /// @param user Address of depositor or redeemer
    /// @param treasuryFee Original fees
    /// @param treasuryFeeType Type of treasury fee:
    ///        - 0: deposit treasury fee,
    ///        - 1: redemption treasury fee.
    /// @return Updated fees considering rebate if applicable
    /// @dev Requirements:
    ///      - The caller must be the bridge contract
    function applyForRebate(
        address user,
        uint64 treasuryFee,
        TreasuryFeeType treasuryFeeType
    ) external onlyBridge returns (uint64) {
        user = getStaker(user);
        Stake storage stakeInfo = stakes[user];

        if (!isRebateEnabled(user, treasuryFeeType)) {
            return treasuryFee;
        }

        uint64 rebateCap = getRebateCap(stakeInfo);
        if (rebateCap == 0) {
            return treasuryFee;
        }

        uint64 currentRebate = getRebateInRollingWindow(stakeInfo);
        if (rebateCap <= currentRebate) {
            return treasuryFee;
        }
        uint64 rebate = rebateCap - currentRebate;
        if (rebate > treasuryFee) {
            rebate = treasuryFee;
        }

        Rebate storage value = stakeInfo.rebates.push();
        /* solhint-disable-next-line not-rely-on-time */
        value.timestamp = uint32(block.timestamp);
        value.feeRebate = rebate;
        emit RebateReceived(user, rebate);
        return treasuryFee - rebate;
    }

    /// @notice Returns true if rebate is enabled for given user and fee type.
    function isRebateEnabled(address user, TreasuryFeeType treasuryFeeType)
        internal
        view
        returns (bool)
    {
        RebateTreasuryFeeMode mode = stakes[user].rebateTreasuryFeeMode;

        // slither-disable-next-line incorrect-equality
        return
            mode == RebateTreasuryFeeMode.Both ||
            (mode == RebateTreasuryFeeMode.DepositOnly &&
                treasuryFeeType == TreasuryFeeType.Deposit) ||
            (mode == RebateTreasuryFeeMode.RedemptionOnly &&
                treasuryFeeType == TreasuryFeeType.Redemption);
    }

    /// @notice Returns address of delegating staker or user itself if there is no delegating staker.
    function getStaker(address user) internal view returns (address) {
        address staker = delegates[user];
        // slither-disable-next-line incorrect-equality
        if (stakes[user].stakedAmount == 0 && staker != address(0)) {
            return staker;
        }
        return user;
    }

    /// @notice Cancels rebate in case of reedem request was timed out
    /// @param user Address of depositor or redeemer
    /// @param requestedAt Timestamp when redeem was requested
    /// @dev Requirements:
    ///      - The caller must be the bridge contract.
    ///
    ///      Known limitation (pre-existing, not introduced by the rebate
    ///      authorization gate): the loop matches at most one rebate per
    ///      `requestedAt`. If a single staker has two or more rebates pushed
    ///      in the same block (e.g., as the resolved staker via `getStaker`
    ///      for two callback redemptions to different `redeemerOutputScript`s
    ///      in one transaction), only the first matching entry is zeroed.
    ///      Subsequent cancels for the same `requestedAt` re-zero the already
    ///      zeroed entry and break, leaving the other same-timestamp entries
    ///      in the rolling window until they age out. Effect is temporary
    ///      rolling-window cap denial, not permanent loss. Tracked as a
    ///      follow-up.
    function cancelRebate(address user, uint256 requestedAt)
        external
        onlyBridge
    {
        user = getStaker(user);
        Stake storage stakeInfo = stakes[user];
        if (stakeInfo.stakedAmount == 0) {
            return;
        }

        /* solhint-disable-next-line not-rely-on-time */
        uint256 windowStart = block.timestamp - rollingWindow;
        uint256 rebatesLength = stakeInfo.rebates.length;
        for (
            uint256 i = stakeInfo.rollingWindowStartIndex;
            i < rebatesLength;
            i++
        ) {
            Rebate storage rebate = stakeInfo.rebates[i];
            if (rebate.timestamp > requestedAt) {
                break;
            } else if (rebate.timestamp < windowStart) {
                stakeInfo.rollingWindowStartIndex++;
            } else if (requestedAt == rebate.timestamp) {
                rebate.feeRebate = 0;
                emit RebateCanceled(user, requestedAt);
                break;
            }
        }
    }

    /// @notice Stake T token to be eligible for rebate
    /// @param amount Amount of tokens to stake
    function stake(uint96 amount) external {
        if (amount == 0) revert AmountCannotBeZero();

        address otherStaker = delegates[msg.sender];
        if (otherStaker != address(0)) {
            stakes[otherStaker].delegatee = address(0);
            delegates[msg.sender] = address(0);
            emit DelegateeSet(otherStaker, otherStaker);
        }

        Stake storage stakeInfo = stakes[msg.sender];
        stakeInfo.stakedAmount += amount;
        emit Staked(msg.sender, amount);
        token.safeTransferFrom(msg.sender, address(this), amount);
    }

    /// @notice Start unstaking process
    /// @param amount Amount of tokens to unstake
    function startUnstaking(uint96 amount) external {
        if (amount == 0) revert AmountCannotBeZero();
        Stake storage stakeInfo = stakes[msg.sender];
        if (stakeInfo.unstakingTimestamp != 0) revert UnstakingAlreadyStarted();
        if (amount > stakeInfo.stakedAmount) revert AmountTooBig();
        /* solhint-disable-next-line not-rely-on-time */
        stakeInfo.unstakingTimestamp = uint32(block.timestamp);
        stakeInfo.unstakingAmount = amount;
        emit UnstakeStarted(msg.sender, amount);
    }

    /// @notice Finalize unstaking and withdraw tokens
    /// @param receiver Address of stake receiver
    function finalizeUnstaking(address receiver) external {
        if (receiver == address(0)) revert ZeroAddress();

        Stake storage stakeInfo = stakes[msg.sender];
        if (stakeInfo.unstakingTimestamp == 0) revert NoUnstakingProcess();
        if (
            /* solhint-disable-next-line not-rely-on-time */
            stakeInfo.unstakingTimestamp + unstakingPeriod > block.timestamp
        ) revert UnstakingNotFinished();

        stakeInfo.stakedAmount -= stakeInfo.unstakingAmount;
        uint96 amount = stakeInfo.unstakingAmount;
        stakeInfo.unstakingTimestamp = 0;
        stakeInfo.unstakingAmount = 0;
        if (stakeInfo.stakedAmount == 0 && stakeInfo.delegatee != address(0)) {
            delegates[stakeInfo.delegatee] = address(0);
            stakeInfo.delegatee = address(0);
        }

        emit UnstakeFinished(msg.sender, amount);
        token.safeTransfer(receiver, amount);
    }

    /// @notice Returns size of rebate array
    /// @param user Address of depositor or redeemer
    function getRebateLength(address user) external view returns (uint256) {
        return stakes[user].rebates.length;
    }

    /// @notice Returns timestamp and amount of rebate
    /// @param user Address of depositor or redeemer
    /// @param index Index of the element in the array
    /// @return timestamp Timestamp of rebate
    /// @return feeRebate Amount of rebate
    function getRebate(address user, uint256 index)
        external
        view
        returns (uint32 timestamp, uint64 feeRebate)
    {
        Rebate storage rebateInfo = stakes[user].rebates[index];
        timestamp = rebateInfo.timestamp;
        feeRebate = rebateInfo.feeRebate;
    }

    /// @notice Returns information about stake
    /// @param user Address of depositor or redeemer
    /// @return stakedAmount Amount of stake
    function getStake(address user) public view returns (uint96 stakedAmount) {
        Stake storage stakeInfo = stakes[user];
        stakedAmount = stakeInfo.stakedAmount;
    }

    /// @notice Returns information about unstaking
    /// @param user Address of depositor or redeemer
    /// @return unstakingAmount Amount that is currently unstaking
    /// @return unstakingTimestamp Amount of rebate
    function getUnstakingAmount(address user)
        external
        view
        returns (uint96 unstakingAmount, uint32 unstakingTimestamp)
    {
        Stake storage stakeInfo = stakes[user];
        unstakingAmount = stakeInfo.unstakingAmount;
        unstakingTimestamp = stakeInfo.unstakingTimestamp;
    }

    /// @notice Returns the rebate treasury fee mode for a user.
    /// @param user Address of the staker
    /// @return rebateTreasuryFeeMode Current mode:
    ///         - 0: rebates for both deposits and redemptions,
    ///         - 1: rebates for deposits only,
    ///         - 2: rebates for redemptions only.
    function getRebateTreasuryFeeMode(address user)
        external
        view
        returns (RebateTreasuryFeeMode rebateTreasuryFeeMode)
    {
        Stake storage stakeInfo = stakes[user];
        rebateTreasuryFeeMode = stakeInfo.rebateTreasuryFeeMode;
    }

    /// @notice Returns information about stake
    /// @param user Address of depositor or redeemer
    /// @return delegatee Delegatee address.
    function getDelegatee(address user)
        external
        view
        returns (address delegatee)
    {
        Stake storage stakeInfo = stakes[user];
        delegatee = stakeInfo.delegatee;
    }

    /// @notice Transfers ownership of stake from one address to another
    /// @param oldStaker Old staker address
    /// @param newStaker New staker address
    function forceStakeTransfer(address oldStaker, address newStaker)
        external
        onlyOwner
    {
        if (oldStaker == address(0)) revert ZeroAddress();
        if (newStaker == address(0)) revert ZeroAddress();

        Stake storage oldStake = stakes[oldStaker];
        if (oldStake.stakedAmount == 0) {
            revert NotAStaker();
        }

        Stake storage newStake = stakes[newStaker];
        if (newStake.stakedAmount != 0) {
            revert AddressAlreadyTaken();
        }
        if (delegates[newStaker] != address(0)) {
            revert WrongDelegatee();
        }

        newStake.stakedAmount = oldStake.stakedAmount;
        newStake.unstakingAmount = oldStake.unstakingAmount;
        newStake.unstakingTimestamp = oldStake.unstakingTimestamp;
        newStake.rebateTreasuryFeeMode = oldStake.rebateTreasuryFeeMode;
        newStake.rollingWindowStartIndex = oldStake.rollingWindowStartIndex;
        for (uint256 i = 0; i < oldStake.rebates.length; i++) {
            newStake.rebates.push(oldStake.rebates[i]);
        }
        if (oldStake.delegatee != address(0)) {
            address delegatee = oldStake.delegatee;
            newStake.delegatee = delegatee;
            delegates[delegatee] = newStaker;
            oldStake.delegatee = address(0);
            emit DelegateeSet(newStaker, delegatee);
        }

        oldStake.stakedAmount = 0;
        oldStake.unstakingAmount = 0;
        oldStake.unstakingTimestamp = 0;
        oldStake.rebateTreasuryFeeMode = RebateTreasuryFeeMode.Both;
        oldStake.rollingWindowStartIndex = 0;

        emit TransferFinished(oldStaker, newStaker);
    }
}
