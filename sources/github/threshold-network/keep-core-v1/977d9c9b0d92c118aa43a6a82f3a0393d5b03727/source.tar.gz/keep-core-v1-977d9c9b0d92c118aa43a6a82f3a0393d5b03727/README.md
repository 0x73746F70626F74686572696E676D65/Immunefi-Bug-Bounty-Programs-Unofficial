# Keep Network v1 (Archived)

This repository preserves the legacy **v1 random beacon** for historical
reference. It is **frozen** — no active development, no releases, no security
support.

## Layout

- [`solidity/`](./solidity/) — legacy v1 random beacon Solidity contracts
  (formerly `solidity-v1/` in
  [`threshold-network/keep-core`](https://github.com/threshold-network/keep-core)).
- [`docs/`](./docs/) — legacy v1 specifications, RFCs, and design documents
  (formerly `docs-v1/`).

## Current development

Active Threshold Network development lives in
[`threshold-network/keep-core`](https://github.com/threshold-network/keep-core).
The current v2 random beacon and ECDSA contracts live there under
`solidity/random-beacon/` and `solidity/ecdsa/`.

## History

Commits in this repository were preserved by extracting `docs-v1/` and
`solidity-v1/` from `threshold-network/keep-core` with
[`git filter-repo`](https://github.com/newren/git-filter-repo):

```bash
git filter-repo \
  --path docs-v1 \
  --path solidity-v1 \
  --path-rename docs-v1/:docs/ \
  --path-rename solidity-v1/:solidity/
```

Commit SHAs differ from the original repository as a result of the rewrite,
but blame and log inside the preserved paths remain intact.
