package paillier

import (
	"fmt"
	"math/big"

	"github.com/bnb-chain/tss-lib/common"
)

const (
	PARAM_E                = 512 // 2 * secp256k1 element bit length
	PARAM_L                = 256 // 1 * secp256k1 element bit length
	fsDomainTagFactorProof = "tss-lib.threshold.factorproof"
)

func fsSessionFactorProof(session []byte) []byte {
	return append([]byte(fsDomainTagFactorProof+"|"), session...)
}

type (
	FactorProof struct {
		// Commitment
		P     *big.Int
		Q     *big.Int
		A     *big.Int
		B     *big.Int
		T     *big.Int
		Sigma *big.Int
		// Response
		Z1 *big.Int
		Z2 *big.Int
		W1 *big.Int
		W2 *big.Int
		V  *big.Int
	}
)

// FactorProof is an implementation of the no small factor proof of
// Canetti, R., Gennaro, R., Goldfeder, S., Makriyannis, N., Peled, U.:
// UC Non-Interactive, Proactive, Threshold ECDSA with Identifiable Aborts.
// In: Cryptology ePrint Archive 2021/060
func (privateKey *PrivateKey) FactorProof(N, s, t *big.Int, session ...[]byte) *FactorProof {
	N0 := privateKey.PublicKey.N
	p, q := privateKey.GetPQ()

	a := common.GetRandomIntIn2PowerMulRange(PARAM_L+PARAM_E, new(big.Int).Sqrt(N0))
	b := common.GetRandomIntIn2PowerMulRange(PARAM_L+PARAM_E, new(big.Int).Sqrt(N0))

	mu := common.GetRandomIntIn2PowerMulRange(PARAM_L, N)
	v := common.GetRandomIntIn2PowerMulRange(PARAM_L, N)

	sigma := common.GetRandomIntIn2PowerMulRange(PARAM_L, new(big.Int).Mul(N0, N))
	r := common.GetRandomIntIn2PowerMulRange(PARAM_L+PARAM_E, new(big.Int).Mul(N0, N))

	x := common.GetRandomIntIn2PowerMulRange(PARAM_L+PARAM_E, N)
	y := common.GetRandomIntIn2PowerMulRange(PARAM_L+PARAM_E, N)

	modN := common.ModInt(N)

	P := modN.ExpMulExp(s, p, t, mu)
	Q := modN.ExpMulExp(s, q, t, v)
	A := modN.ExpMulExp(s, a, t, x)
	B := modN.ExpMulExp(s, b, t, y)
	T := modN.ExpMulExp(Q, a, t, r)

	// Use standard Fiat-Shamir transform.
	//
	// Section 2.3.1 ZK-Module:
	// Next, we present how to compile the protocols above using a random oracle via the Fiat-Shamir heuristic.
	// Namely, to generate a proof, the Prover computes the challenge e by querying the oracle on a suitable input,
	// which incorporates the theorem and the first message. Then, the Prover completes the transcript by computing
	// the last message with respect to e and communicates the entire transcript as the proof. Later, the Verifier
	// accepts the proof if it is a valid transcript of the underlying Σ-protocol and e is well-formed (verified by
	// querying the oracle as the Prover should have).
	e := FactorChallenge(N, s, t, N0, P, Q, A, B, T, sigma, session...)

	sigmaH := new(big.Int)
	sigmaH.Mul(v, p)
	sigmaH.Sub(sigma, sigmaH)

	z1 := common.AddMul(a, e, p)
	z2 := common.AddMul(b, e, q)
	w1 := common.AddMul(x, e, mu)
	w2 := common.AddMul(y, e, v)
	vv := common.AddMul(r, e, sigmaH)

	return &FactorProof{P, Q, A, B, T, sigma, z1, z2, w1, w2, vv}
}

func (pf FactorProof) FactorVerify(pkN, N, s, t *big.Int, session ...[]byte) (bool, error) {
	if common.AnyIsNil(pkN, N, s, t) {
		return false, fmt.Errorf("fac proof verify: nil bigint present in args")
	}
	if common.AnyIsNil(pf.P, pf.Q, pf.A, pf.B, pf.T, pf.Sigma, pf.Z1, pf.Z2, pf.W1, pf.W2, pf.V) {
		return false, fmt.Errorf("fac proof verify: nil bigint present in proof")
	}
	if !common.IsUsableUnknownOrderModulus(pkN, verifyMinModulusBitLen) {
		return false, fmt.Errorf("fac proof verify: invalid Paillier modulus %x", pkN)
	}
	if !common.IsUsableUnknownOrderModulus(N, verifyMinModulusBitLen) {
		return false, fmt.Errorf("fac proof verify: invalid auxiliary modulus %x", N)
	}
	for name, base := range map[string]*big.Int{
		"s": s,
		"t": t,
		"P": pf.P,
		"Q": pf.Q,
		"A": pf.A,
		"B": pf.B,
		"T": pf.T,
	} {
		if !common.IsCanonicalGenerator(N, base) {
			return false, fmt.Errorf("fac proof verify: base %s = %x is not invertible modulo N", name, base)
		}
	}

	// The Pedersen-style bases s and t must be distinct; with s == t the
	// binding degenerates. Sibling proofs (dlnproof, MtA range/respondent)
	// reject equal generators, so mirror that policy here.
	if s.Cmp(t) == 0 {
		return false, fmt.Errorf("fac proof verify: generators s and t must be distinct")
	}

	limit := big.NewInt(1)
	limit.Lsh(limit, PARAM_L+PARAM_E)
	limit.Mul(limit, new(big.Int).Sqrt(pkN))

	if pf.Z1.CmpAbs(limit) > 0 {
		return false, fmt.Errorf("fac proof verify: z1 = %x exceeds limit %x", pf.Z1, limit)
	}

	if pf.Z2.CmpAbs(limit) > 0 {
		return false, fmt.Errorf("fac proof verify: z2 = %x exceeds limit %x", pf.Z2, limit)
	}

	// FactorProof responses are signed in Threshold's fork. Keep the existing
	// inclusive absolute Z1/Z2 bound style, and reject W1/W2/Sigma/V before
	// any modular exponentiation so malformed proofs cannot amplify verifier
	// CPU cost with over-wide exponents.
	q := new(big.Int).Lsh(big.NewInt(1), PARAM_L)
	q3 := new(big.Int).Mul(q, q)
	q3.Mul(q3, q)
	qN := new(big.Int).Mul(q, N)
	qPkNN := new(big.Int).Mul(qN, pkN)
	q3N := new(big.Int).Mul(q3, N)
	q3PkNN := new(big.Int).Mul(q3N, pkN)
	limitW := new(big.Int).Lsh(q3N, 1)
	limitV := new(big.Int).Lsh(q3PkNN, 2)

	if pf.W1.CmpAbs(limitW) > 0 {
		return false, fmt.Errorf("fac proof verify: w1 = %x exceeds limit %x", pf.W1, limitW)
	}

	if pf.W2.CmpAbs(limitW) > 0 {
		return false, fmt.Errorf("fac proof verify: w2 = %x exceeds limit %x", pf.W2, limitW)
	}

	if pf.Sigma.CmpAbs(qPkNN) > 0 {
		return false, fmt.Errorf("fac proof verify: sigma = %x exceeds limit %x", pf.Sigma, qPkNN)
	}

	if pf.V.CmpAbs(limitV) > 0 {
		return false, fmt.Errorf("fac proof verify: v = %x exceeds limit %x", pf.V, limitV)
	}

	e := FactorChallenge(N, s, t, pkN, pf.P, pf.Q, pf.A, pf.B, pf.T, pf.Sigma, session...)
	if e.Sign() == 0 {
		return false, fmt.Errorf("fac proof verify: Fiat-Shamir challenge is zero")
	}

	modN := common.ModInt(N)

	R := modN.ExpMulExp(s, pkN, t, pf.Sigma)

	sz1tw1 := modN.ExpMulExp(s, pf.Z1, t, pf.W1)
	sz2tw2 := modN.ExpMulExp(s, pf.Z2, t, pf.W2)
	Qz1tv := modN.ExpMulExp(pf.Q, pf.Z1, t, pf.V)

	APe := modN.MulExp(pf.A, pf.P, e)
	BQe := modN.MulExp(pf.B, pf.Q, e)
	TRe := modN.MulExp(pf.T, R, e)

	if !common.Eq(sz1tw1, APe) {
		return false, fmt.Errorf("fac proof verify: s^z1*t^w1 = %x != A*P^e = %x", sz1tw1, APe)
	}

	if !common.Eq(sz2tw2, BQe) {
		return false, fmt.Errorf("fac proof verify: s^z2*t^w2 = %x != B*Q^e = %x", sz2tw2, BQe)
	}

	if !common.Eq(Qz1tv, TRe) {
		return false, fmt.Errorf("fac proof verify: Q^z1*t^v = %x != T*R^e = %x", Qz1tv, TRe)
	}

	return true, nil
}

// FactorChallenge derives the Fiat-Shamir challenge for the no-small-factor
// proof. The two paths emit different challenge distributions; both are
// internally consistent because prover and verifier always traverse the same
// branch for a given proof, but the absolute-value bounds on Z1/Z2/W1/W2 in
// FactorVerify (which use CmpAbs) accommodate the signed legacy challenge.
//
//   - Tagged path  (session != nil): e ∈ [0, 2^256), derived via
//     SHA512_256i_TAGGED + modular reduction. Honest responses Z1/Z2 = a+e*p,
//     b+e*q are positive.
//   - Legacy path (session absent):  e ∈ [-(2^256-1), 2^256), derived via
//     HashToN(2q-1, …) − (q-1). Honest responses can be negative; this is the
//     historical Threshold encoding, kept for wire-compat with non-session
//     callers.
func FactorChallenge(N, s, t, pkN, P, Q, A, B, T, sigma *big.Int, session ...[]byte) *big.Int {
	q := big.NewInt(1)
	q = q.Lsh(q, 256)                             // q = 2^256
	qMinus1 := new(big.Int).Sub(q, big.NewInt(1)) // q-1
	qDoubleMinus1 := new(big.Int).Add(q, qMinus1) // q+q-1 = 2q-1

	if len(session) > 0 {
		if len(session[0]) == 0 {
			panic("paillier: factor proof session tag must be non-empty")
		}
		eHash := common.SHA512_256i_TAGGED(fsSessionFactorProof(session[0]), N, s, t, pkN, P, Q, A, B, T, sigma)
		return common.ModReduceHash(q, eHash)
	}

	// 2. Verifier replies with e <- +-q
	// The q here is not the secret factor q, but rather the order of secp256k1,
	// or in practical terms 2^256 as the value h does not involve elliptic curve operations
	// and q acts as a security parameter only.
	//
	// Calculate +-q by taking HashToN(2*q-1, ...) - q + 1
	h := common.HashToN(qDoubleMinus1, N, s, t, pkN, P, Q, A, B, T, sigma)
	h.Sub(h, qMinus1) // h - (q-1) = h - q + 1

	return h
}
