// Copyright © 2019-2020 Binance
//
// This file is part of Binance. The full Binance copyright notice, including
// terms governing use, modification, and redistribution, is contained in the
// file LICENSE at the root of the source code distribution tree.

// Zero-knowledge proof of knowledge of the discrete logarithm over safe prime product

// A proof of knowledge of the discrete log of an element h2 = hx1 with respect to h1.
// In our protocol, we will run two of these in parallel to prove that two elements h1,h2 generate the same group modN.

package dlnproof

import (
	"fmt"
	"math/big"

	"github.com/bnb-chain/tss-lib/common"
)

const (
	Iterations             = 128
	verifyMinModulusBitLen = 2048
	fsDomainTagDLNProof    = "tss-lib.threshold.dlnproof"
)

func fsSessionDLNProof(session []byte) []byte {
	return append([]byte(fsDomainTagDLNProof+"|"), session...)
}

type (
	Proof struct {
		Alpha,
		T [Iterations]*big.Int
	}
)

var (
	one = big.NewInt(1)
)

func NewDLNProof(h1, h2, x, p, q, N *big.Int, session ...[]byte) *Proof {
	Session := optionalSession(session)
	pMulQ := new(big.Int).Mul(p, q)
	modN, modPQ := common.ModInt(N), common.ModInt(pMulQ)
	a := make([]*big.Int, Iterations)
	alpha := [Iterations]*big.Int{}
	for i := range alpha {
		a[i] = common.GetRandomPositiveInt(pMulQ)
		alpha[i] = modN.Exp(h1, a[i])
	}
	msg := append([]*big.Int{h1, h2, N}, alpha[:]...)
	c := common.SHA512_256i_TAGGED(fsSessionDLNProof(Session), msg...)
	t := [Iterations]*big.Int{}
	cIBI := new(big.Int)
	for i := range t {
		cI := c.Bit(i)
		cIBI = cIBI.SetInt64(int64(cI))
		t[i] = modPQ.Add(a[i], modPQ.Mul(cIBI, x))
	}
	return &Proof{alpha, t}
}

func (p *Proof) Verify(h1, h2, N *big.Int, session ...[]byte) bool {
	Session := optionalSession(session)
	if p == nil {
		return false
	}
	if !common.IsUsableUnknownOrderModulus(N, verifyMinModulusBitLen) {
		return false
	}
	modN := common.ModInt(N)
	if !common.IsCanonicalGenerator(N, h1) || !common.IsCanonicalGenerator(N, h2) {
		return false
	}
	if h1.Cmp(h2) == 0 {
		return false
	}
	for i := range p.T {
		if p.T[i] == nil || p.T[i].Cmp(one) <= 0 || p.T[i].Cmp(N) >= 0 {
			return false
		}
	}
	for i := range p.Alpha {
		if !common.IsCanonicalGenerator(N, p.Alpha[i]) {
			return false
		}
	}
	msg := append([]*big.Int{h1, h2, N}, p.Alpha[:]...)
	c := common.SHA512_256i_TAGGED(fsSessionDLNProof(Session), msg...)
	cIBI := new(big.Int)
	for i := 0; i < Iterations; i++ {
		cI := c.Bit(i)
		cIBI = cIBI.SetInt64(int64(cI))
		h1ExpTi := modN.Exp(h1, p.T[i])
		h2ExpCi := modN.Exp(h2, cIBI)
		alphaIMulH2ExpCi := modN.Mul(p.Alpha[i], h2ExpCi)
		if h1ExpTi.Cmp(alphaIMulH2ExpCi) != 0 {
			return false
		}
	}
	return true
}

func optionalSession(session [][]byte) []byte {
	if len(session) == 0 {
		return nil
	}
	if len(session[0]) == 0 {
		panic("dlnproof: session tag must be non-empty")
	}
	return session[0]
}

func UnmarshalDLNProof(alphas, ts [][]byte) (*Proof, error) {
	if len1 := len(alphas); len1 != Iterations {
		return nil, fmt.Errorf("UnmarshalDLNProof expected %d Alphas but received %d", Iterations, len1)
	}
	if len2 := len(ts); len2 != Iterations {
		return nil, fmt.Errorf("UnmarshalDLNProof expected %d Ts but received %d", Iterations, len2)
	}
	alpha := common.MultiBytesToBigInts(alphas)
	t := common.MultiBytesToBigInts(ts)

	var Alpha [Iterations]*big.Int
	var T [Iterations]*big.Int

	for i := 0; i < Iterations; i++ {
		Alpha[i] = alpha[i]
		T[i] = t[i]
	}
	return &Proof{Alpha, T}, nil
}
