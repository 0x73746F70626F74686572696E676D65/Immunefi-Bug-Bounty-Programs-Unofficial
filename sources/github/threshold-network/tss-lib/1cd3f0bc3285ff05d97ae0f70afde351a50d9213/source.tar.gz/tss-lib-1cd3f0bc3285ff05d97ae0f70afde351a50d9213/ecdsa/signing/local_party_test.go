// Copyright © 2019 Binance
//
// This file is part of Binance. The full Binance copyright notice, including
// terms governing use, modification, and redistribution, is contained in the
// file LICENSE at the root of the source code distribution tree.

package signing

import (
	"crypto/ecdsa"
	"encoding/hex"
	"errors"
	"fmt"
	"math/big"
	"runtime"
	"strings"
	"sync/atomic"
	"testing"

	"github.com/btcsuite/btcd/btcec"
	"github.com/ipfs/go-log"
	"github.com/stretchr/testify/assert"

	"github.com/bnb-chain/tss-lib/common"
	"github.com/bnb-chain/tss-lib/ecdsa/keygen"
	"github.com/bnb-chain/tss-lib/test"
	"github.com/bnb-chain/tss-lib/tss"
)

const (
	testParticipants = test.TestParticipants
	testThreshold    = test.TestThreshold
)

func setUp(level string) {
	if err := log.SetLogLevel("tss-lib", level); err != nil {
		panic(err)
	}
}

func TestStoreMessageRejectsContentDifferentReplay(t *testing.T) {
	lp, pIDs := newStoreMessageTestParty(t)

	msg1 := NewSignRound3Message(pIDs[1], big.NewInt(1))
	ok, err := lp.StoreMessage(msg1)
	assert.True(t, ok)
	assert.Nil(t, err)

	redelivery := NewSignRound3Message(pIDs[1], big.NewInt(1))
	assert.True(t, tss.IsSameMessage(msg1, redelivery))
	ok, err = lp.StoreMessage(redelivery)
	assert.True(t, ok)
	assert.Nil(t, err)

	replacement := NewSignRound3Message(pIDs[1], big.NewInt(2))
	assert.False(t, tss.IsSameMessage(msg1, replacement))
	ok, err = lp.StoreMessage(replacement)
	assert.False(t, ok)
	assert.Error(t, err)
	assert.True(t, errors.Is(err, tss.ErrDuplicateMessage))
}

func TestStoreMessageAllowsSelfReplacement(t *testing.T) {
	lp, pIDs := newStoreMessageTestParty(t)

	msg1 := NewSignRound3Message(pIDs[0], big.NewInt(1))
	replacement := NewSignRound3Message(pIDs[0], big.NewInt(2))

	ok, err := lp.StoreMessage(msg1)
	assert.True(t, ok)
	assert.Nil(t, err)
	ok, err = lp.StoreMessage(replacement)
	assert.True(t, ok)
	assert.Nil(t, err)
}

func newStoreMessageTestParty(t *testing.T) (*LocalParty, tss.SortedPartyIDs) {
	t.Helper()

	pIDs := tss.GenerateTestPartyIDs(2)
	params := tss.NewParameters(tss.S256(), tss.NewPeerContext(pIDs), pIDs[0], len(pIDs), 1)
	keys := keygen.NewLocalPartySaveData(len(pIDs))
	for i, id := range pIDs {
		keys.Ks[i] = id.KeyInt()
	}
	lp := NewLocalParty(big.NewInt(1), params, keys, nil, nil, 32).(*LocalParty)
	return lp, pIDs
}

func TestE2EConcurrent(t *testing.T) {
	setUp("info")
	threshold := testThreshold

	// PHASE: load keygen fixtures
	keys, signPIDs, err := keygen.LoadKeygenTestFixturesRandomSet(testThreshold+1, testParticipants)
	assert.NoError(t, err, "should load keygen fixtures")
	assert.Equal(t, testThreshold+1, len(keys))
	assert.Equal(t, testThreshold+1, len(signPIDs))

	// PHASE: signing
	// use a shuffled selection of the list of parties for this test
	p2pCtx := tss.NewPeerContext(signPIDs)
	parties := make([]*LocalParty, 0, len(signPIDs))

	errCh := make(chan *tss.Error, len(signPIDs))
	outCh := make(chan tss.Message, len(signPIDs))
	endCh := make(chan common.SignatureData, len(signPIDs))

	updater := test.SharedPartyUpdater

	msgData, err := hex.DecodeString("00f163ee51bcaeff9cdff5e0e3c1a646abd19885fffbab0b3b4236e0cf95c9f5")
	assert.NoError(t, err)
	msgInt := new(big.Int).SetBytes(msgData)

	// init the parties
	ceremonyNonce := big.NewInt(1)
	for i := 0; i < len(signPIDs); i++ {
		params := tss.NewParameters(tss.S256(), p2pCtx, signPIDs[i], len(signPIDs), threshold)
		params.SetSessionNonce(ceremonyNonce)

		P := NewLocalParty(msgInt, params, keys[i], outCh, endCh, len(msgData)).(*LocalParty)
		parties = append(parties, P)
		go func(P *LocalParty) {
			if err := P.Start(); err != nil {
				errCh <- err
			}
		}(P)
	}

	var ended int32
signing:
	for {
		fmt.Printf("ACTIVE GOROUTINES: %d\n", runtime.NumGoroutine())
		select {
		case err := <-errCh:
			common.Logger.Errorf("Error: %s", err)
			assert.FailNow(t, err.Error())
			break signing

		case msg := <-outCh:
			dest := msg.GetTo()
			if dest == nil {
				for _, P := range parties {
					if P.PartyID().Index == msg.GetFrom().Index {
						continue
					}
					go updater(P, msg, errCh)
				}
			} else {
				if dest[0].Index == msg.GetFrom().Index {
					t.Fatalf("party %d tried to send a message to itself (%d)", dest[0].Index, msg.GetFrom().Index)
				}
				go updater(parties[dest[0].Index], msg, errCh)
			}

		case <-endCh:
			atomic.AddInt32(&ended, 1)
			if atomic.LoadInt32(&ended) == int32(len(signPIDs)) {
				t.Logf("Done. Received signature data from %d participants", ended)
				R := parties[0].temp.bigR
				r := parties[0].temp.rx
				fmt.Printf("sign result: R(%s, %s), r=%s\n", R.X().String(), R.Y().String(), r.String())

				modN := common.ModInt(tss.S256().Params().N)

				// BEGIN check s correctness
				sumS := big.NewInt(0)
				for _, p := range parties {
					sumS = modN.Add(sumS, p.temp.si)
				}
				fmt.Printf("S: %s\n", sumS.String())
				// END check s correctness

				// BEGIN ECDSA verify
				pkX, pkY := keys[0].ECDSAPub.X(), keys[0].ECDSAPub.Y()
				pk := ecdsa.PublicKey{
					Curve: tss.EC(),
					X:     pkX,
					Y:     pkY,
				}
				ok := ecdsa.Verify(&pk, msgData, R.X(), sumS)
				assert.True(t, ok, "ecdsa verify must pass")
				assert.Equal(t, msgData, parties[0].data.M)
				t.Log("ECDSA signing test done.")
				// END ECDSA verify

				break signing
			}
		}
	}
}

func TestE2EWithHDKeyDerivation(t *testing.T) {
	setUp("info")
	threshold := testThreshold

	// PHASE: load keygen fixtures
	keys, signPIDs, err := keygen.LoadKeygenTestFixturesRandomSet(testThreshold+1, testParticipants)
	assert.NoError(t, err, "should load keygen fixtures")
	assert.Equal(t, testThreshold+1, len(keys))
	assert.Equal(t, testThreshold+1, len(signPIDs))

	chainCode := make([]byte, 32)
	max32b := new(big.Int).Lsh(new(big.Int).SetUint64(1), 256)
	max32b = new(big.Int).Sub(max32b, new(big.Int).SetUint64(1))
	fillBytes(common.GetRandomPositiveInt(max32b), chainCode)

	il, extendedChildPk, errorDerivation := derivingPubkeyFromPath(keys[0].ECDSAPub, chainCode, []uint32{12, 209, 3}, btcec.S256())
	assert.NoErrorf(t, errorDerivation, "there should not be an error deriving the child public key")

	keyDerivationDelta := il

	err = UpdatePublicKeyAndAdjustBigXj(keyDerivationDelta, keys, &extendedChildPk.PublicKey, btcec.S256())
	assert.NoErrorf(t, err, "there should not be an error setting the derived keys")

	// PHASE: signing
	// use a shuffled selection of the list of parties for this test
	p2pCtx := tss.NewPeerContext(signPIDs)
	parties := make([]*LocalParty, 0, len(signPIDs))

	errCh := make(chan *tss.Error, len(signPIDs))
	outCh := make(chan tss.Message, len(signPIDs))
	endCh := make(chan common.SignatureData, len(signPIDs))

	updater := test.SharedPartyUpdater

	// init the parties
	ceremonyNonce := big.NewInt(2)
	for i := 0; i < len(signPIDs); i++ {
		params := tss.NewParameters(tss.S256(), p2pCtx, signPIDs[i], len(signPIDs), threshold)
		params.SetSessionNonce(ceremonyNonce)

		P := NewLocalPartyWithKDD(big.NewInt(42), params, keys[i], keyDerivationDelta, outCh, endCh, 32).(*LocalParty)
		parties = append(parties, P)
		go func(P *LocalParty) {
			if err := P.Start(); err != nil {
				errCh <- err
			}
		}(P)
	}

	var ended int32
signing:
	for {
		select {
		case err := <-errCh:
			common.Logger.Errorf("Error: %s", err)
			assert.FailNow(t, err.Error())
			break signing

		case msg := <-outCh:
			dest := msg.GetTo()
			if dest == nil {
				for _, P := range parties {
					if P.PartyID().Index == msg.GetFrom().Index {
						continue
					}
					go updater(P, msg, errCh)
				}
			} else {
				if dest[0].Index == msg.GetFrom().Index {
					t.Fatalf("party %d tried to send a message to itself (%d)", dest[0].Index, msg.GetFrom().Index)
				}
				go updater(parties[dest[0].Index], msg, errCh)
			}

		case <-endCh:
			atomic.AddInt32(&ended, 1)
			if atomic.LoadInt32(&ended) == int32(len(signPIDs)) {
				t.Logf("Done. Received signature data from %d participants", ended)
				R := parties[0].temp.bigR
				r := parties[0].temp.rx
				fmt.Printf("sign result: R(%s, %s), r=%s\n", R.X().String(), R.Y().String(), r.String())

				modN := common.ModInt(tss.S256().Params().N)

				// BEGIN check s correctness
				sumS := big.NewInt(0)
				for _, p := range parties {
					sumS = modN.Add(sumS, p.temp.si)
				}
				fmt.Printf("S: %s\n", sumS.String())
				// END check s correctness

				// BEGIN ECDSA verify
				pkX, pkY := keys[0].ECDSAPub.X(), keys[0].ECDSAPub.Y()
				pk := ecdsa.PublicKey{
					Curve: tss.EC(),
					X:     pkX,
					Y:     pkY,
				}
				ok := ecdsa.Verify(&pk, big.NewInt(42).Bytes(), R.X(), sumS)
				assert.True(t, ok, "ecdsa verify must pass")
				t.Log("ECDSA signing test done.")
				// END ECDSA verify

				break signing
			}
		}
	}
}

// TestSigning_Start_RequiresSessionNonce pins that signing fails closed
// when no SessionNonce is set. Previously the round-1 code fell back to
// SHA512_256(messageBytes), making two concurrent ceremonies on the same
// canonical message reuse the same SSID and enabling Fiat-Shamir
// transcript splicing across runs. The fix removes the fallback and
// requires the caller to provide a per-ceremony nonce.
func TestSigning_Start_RequiresSessionNonce(t *testing.T) {
	setUp("info")
	keys, signPIDs, err := keygen.LoadKeygenTestFixturesRandomSet(testThreshold+1, testParticipants)
	assert.NoError(t, err, "should load keygen fixtures")

	p2pCtx := tss.NewPeerContext(signPIDs)
	outCh := make(chan tss.Message, len(signPIDs))
	endCh := make(chan common.SignatureData, len(signPIDs))

	params := tss.NewParameters(tss.S256(), p2pCtx, signPIDs[0], len(signPIDs), testThreshold)
	// Deliberately do NOT call params.SetSessionNonce — Start must fail closed.

	P := NewLocalParty(big.NewInt(42), params, keys[0], outCh, endCh, 32).(*LocalParty)
	tssErr := P.Start()
	if tssErr == nil {
		t.Fatal("Start must return an error without SessionNonce")
	}
	if !strings.Contains(tssErr.Error(), "SetSessionNonce") {
		t.Fatalf("error must reference SetSessionNonce, got: %v", tssErr)
	}
}

// TestNewLocalPartyWithKDD_FullBytesLen_NonPositive pins constructor-side
// validation for fullBytesLen. Previously, a negative fullBytesLen passed
// through to the round-1 code path, where `make([]byte, fullBytesLen)`
// panicked inside a protocol goroutine, bypassing tss.Error reporting and
// crossing goroutine boundaries. The constructor now panics synchronously
// at the caller's call site with a clear message.
func TestNewLocalPartyWithKDD_FullBytesLen_NonPositive(t *testing.T) {
	msg := big.NewInt(1)
	for _, length := range []int{-1, 0} {
		func() {
			defer func() {
				r := recover()
				if r == nil {
					t.Fatalf("expected panic for fullBytesLen=%d", length)
				}
				err, ok := r.(error)
				if !ok {
					t.Fatalf("panic value must be an error, got %T: %v", r, r)
				}
				if !strings.Contains(err.Error(), "fullBytesLen must be positive") {
					t.Fatalf("unexpected panic message: %v", err)
				}
			}()
			_ = NewLocalPartyWithKDD(msg, nil, keygen.LocalPartySaveData{}, nil, nil, nil, length)
		}()
	}
}

// TestNewLocalPartyWithKDD_FullBytesLen_TooSmall pins that a fullBytesLen
// smaller than the message's byte width is rejected at the constructor
// rather than later inside (*big.Int).FillBytes (which would panic with
// "big.Int.FillBytes: insufficient length" inside a protocol goroutine).
func TestNewLocalPartyWithKDD_FullBytesLen_TooSmall(t *testing.T) {
	// 16-bit msg needs at least 2 bytes; pass fullBytesLen=1 to trigger.
	msg := big.NewInt(0xABCD)
	defer func() {
		r := recover()
		if r == nil {
			t.Fatal("expected panic for fullBytesLen smaller than msg byte width")
		}
		err, ok := r.(error)
		if !ok {
			t.Fatalf("panic value must be an error, got %T: %v", r, r)
		}
		if !strings.Contains(err.Error(), "fullBytesLen=1 is too small") {
			t.Fatalf("unexpected panic message: %v", err)
		}
	}()
	_ = NewLocalPartyWithKDD(msg, nil, keygen.LocalPartySaveData{}, nil, nil, nil, 1)
}

func TestNewLocalPartyWithKDD_FullBytesLen_Required(t *testing.T) {
	defer func() {
		r := recover()
		if r == nil {
			t.Fatal("expected panic when fullBytesLen is omitted")
		}
		err, ok := r.(error)
		if !ok {
			t.Fatalf("panic value must be an error, got %T: %v", r, r)
		}
		if !strings.Contains(err.Error(), "fullBytesLen is required") {
			t.Fatalf("unexpected panic message: %v", err)
		}
	}()
	_ = NewLocalPartyWithKDD(big.NewInt(42), nil, keygen.LocalPartySaveData{}, nil, nil, nil)
}

func TestNewLocalPartyWithKDD_FullBytesLen_TooWide(t *testing.T) {
	pIDs := tss.GenerateTestPartyIDs(2)
	params := tss.NewParameters(tss.S256(), tss.NewPeerContext(pIDs), pIDs[0], len(pIDs), 1)
	defer func() {
		r := recover()
		if r == nil {
			t.Fatal("expected panic for fullBytesLen wider than the curve order")
		}
		err, ok := r.(error)
		if !ok {
			t.Fatalf("panic value must be an error, got %T: %v", r, r)
		}
		if !strings.Contains(err.Error(), "exceeds curve order byte length") {
			t.Fatalf("unexpected panic message: %v", err)
		}
	}()
	_ = NewLocalPartyWithKDD(big.NewInt(1), params, keygen.LocalPartySaveData{}, nil, nil, nil, 33)
}

func TestFillTo32BytesInPlace(t *testing.T) {
	s := big.NewInt(123456789)
	normalizedS := padToLengthBytesInPlace(s.Bytes(), 32)
	assert.True(t, big.NewInt(0).SetBytes(normalizedS).Cmp(s) == 0)
	assert.Equal(t, 32, len(normalizedS))
	assert.NotEqual(t, 32, len(s.Bytes()))
}

func fillBytes(x *big.Int, buf []byte) []byte {
	b := x.Bytes()
	if len(b) > len(buf) {
		panic("buffer too small")
	}
	offset := len(buf) - len(b)
	for i := range buf {
		if i < offset {
			buf[i] = 0
		} else {
			buf[i] = b[i-offset]
		}
	}
	return buf
}
