/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.alipay.sofa.jraft.storage.snapshot.local;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.alipay.sofa.jraft.entity.RaftOutter;
import com.alipay.sofa.jraft.option.RaftOptions;
import com.alipay.sofa.jraft.storage.BaseStorageTest;
import com.alipay.sofa.jraft.storage.snapshot.Snapshot;
import com.alipay.sofa.jraft.storage.snapshot.SnapshotReader;
import com.alipay.sofa.jraft.storage.snapshot.SnapshotWriter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class LocalSnapshotStorageTest extends BaseStorageTest {
    private LocalSnapshotStorage   snapshotStorage;
    private LocalSnapshotMetaTable table;
    private int                    lastSnapshotIndex = 99;

    @Override
    @Before
    public void setup() throws Exception {
        super.setup();

        String snapshotPath = this.path + File.separator + Snapshot.JRAFT_SNAPSHOT_PREFIX + lastSnapshotIndex;
        FileUtils.forceMkdir(new File(snapshotPath));
        this.table = new LocalSnapshotMetaTable(new RaftOptions());
        this.table.setMeta(RaftOutter.SnapshotMeta.newBuilder().setLastIncludedIndex(this.lastSnapshotIndex)
            .setLastIncludedTerm(1).build());
        this.table.saveToFile(snapshotPath + File.separator + Snapshot.JRAFT_SNAPSHOT_META_FILE);

        this.snapshotStorage = new LocalSnapshotStorage(path, null, new RaftOptions());
        assertTrue(this.snapshotStorage.init(null));
    }

    @Override
    @After
    public void teardown() throws Exception {
        super.teardown();
        this.snapshotStorage.shutdown();
    }

    @Test
    public void testGetLastSnapshotIndex() throws Exception {
        assertEquals(this.snapshotStorage.getLastSnapshotIndex(), lastSnapshotIndex);
        assertEquals(1, this.snapshotStorage.getRefs(this.lastSnapshotIndex).get());
    }

    @Test
    public void testCreateOpen() throws Exception {
        SnapshotWriter writer = this.snapshotStorage.create();
        assertNotNull(writer);
        RaftOutter.SnapshotMeta wroteMeta = RaftOutter.SnapshotMeta.newBuilder()
            .setLastIncludedIndex(this.lastSnapshotIndex + 1).setLastIncludedTerm(1).build();
        ((LocalSnapshotWriter) writer).saveMeta(wroteMeta);
        writer.addFile("data");
        assertEquals(1, this.snapshotStorage.getRefs(this.lastSnapshotIndex).get());
        writer.close();
        //release old
        assertEquals(0, this.snapshotStorage.getRefs(this.lastSnapshotIndex).get());
        //ref new
        assertEquals(1, this.snapshotStorage.getRefs(this.lastSnapshotIndex + 1).get());
        SnapshotReader reader = this.snapshotStorage.open();
        assertNotNull(reader);
        assertTrue(reader.listFiles().contains("data"));
        RaftOutter.SnapshotMeta readMeta = reader.load();
        assertEquals(wroteMeta, readMeta);
        assertEquals(2, this.snapshotStorage.getRefs(this.lastSnapshotIndex + 1).get());
        reader.close();
        assertEquals(1, this.snapshotStorage.getRefs(this.lastSnapshotIndex + 1).get());
    }

}
