/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.alipay.sofa.jraft.closure;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicLong;

import org.junit.Before;
import org.junit.Test;

import com.alipay.sofa.jraft.Status;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class SynchronizedClosureTest {
    private SynchronizedClosure done;

    @Before
    public void setup() {
        this.done = new SynchronizedClosure(1);
    }

    @Test
    public void testAwaitRun() throws Exception {
        CountDownLatch latch = new CountDownLatch(1);
        AtomicLong cost = new AtomicLong(0);
        new Thread() {
            @Override
            public void run() {
                try {
                    long start = System.currentTimeMillis();
                    done.await();
                    cost.set(System.currentTimeMillis() - start);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                latch.countDown();
            }
        }.start();

        int n = 1000;
        Thread.sleep(n);
        this.done.run(Status.OK());
        latch.await();
        assertEquals(n, cost.get(), 50);
        assertTrue(this.done.getStatus().isOk());
    }

    @Test
    public void testReset() throws Exception {
        testAwaitRun();
        this.done.await();
        assertTrue(true);
        this.done.reset();
        assertNull(this.done.getStatus());
        testAwaitRun();
        assertTrue(this.done.getStatus().isOk());
    }
}
