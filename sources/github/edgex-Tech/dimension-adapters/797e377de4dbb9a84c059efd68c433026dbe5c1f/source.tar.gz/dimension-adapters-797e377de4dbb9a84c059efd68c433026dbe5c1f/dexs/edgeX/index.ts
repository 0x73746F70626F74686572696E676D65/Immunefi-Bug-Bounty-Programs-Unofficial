import fetchURL, { fetchURLAutoHandleRateLimit } from "../../utils/fetchURL"
import { FetchResultVolume, SimpleAdapter, FetchOptions } from "../../adapters/types";
import { CHAIN } from "../../helpers/chains";

const metaDataEndpoint = "https://pro.edgex.exchange/api/v1/public/meta/getMetaData"
const klineDailyEndpoint = (contractId: string, startTime: number, endTime: number) => `https://pro.edgex.exchange/api/v1/public/quote/getKline?contractId=${contractId}&klineType=DAY_1&filterBeginKlineTimeInclusive=${startTime}&filterEndKlineTimeExclusive=${endTime}&priceType=LAST_PRICE`

interface KlineData {
  contractId: string;
  contractName: string;
  klineType: string;
  klineTime: string;
  priceType: string;
  trades: string;
  size: string;
  value: string;
}

interface ResponseData {
  dataList: KlineData[];
}

interface ApiResponse {
  code: string;
  data: ResponseData;
  msg: string | null;
  errorParam: string | null;
}

function parseContractIds(response: any): string[] {
  return response.data.contractList.map(contract => contract.contractId);
}


const fetch = async (options: FetchOptions): Promise<FetchResultVolume> => {
  const dayTimestamp = options.startOfDay * 1000
  const toTimestamp = dayTimestamp + 60 * 60 * 24 * 1000;
  const contractIds: string[] = parseContractIds(await fetchURL(metaDataEndpoint));
  const klines: Array<any> = [];
  for (const contractId of contractIds) {
    const response: ApiResponse = await fetchURLAutoHandleRateLimit(klineDailyEndpoint(contractId, dayTimestamp, toTimestamp), 5);
    klines.push(response.data.dataList);
  }
  const volumes = klines
    .flat()
    .map(kline => parseFloat(kline.value))
    .reduce((acc, value) => acc + value, 0);
  return { dailyVolume: volumes };
};

const adapter: SimpleAdapter = {
  fetch,
  chains: [CHAIN.EDGEX],
  start: '2024-08-06',
};

export default adapter;
