package order

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/edgex-Tech/edgex-golang-sdk/v2/sdk/internal"
	metadatapkg "github.com/edgex-Tech/edgex-golang-sdk/v2/sdk/metadata"
	"github.com/shopspring/decimal"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestGetActiveOrdersUsesListBooleanFilters(t *testing.T) {
	var gotPath string
	var gotMethod string
	var gotParams map[string]string

	mockCli := newMockClient(42, "", "https://example.com", func(urlStr, method string, data map[string]interface{}, params map[string]string) (*http.Response, error) {
		gotMethod = method
		gotParams = params
		req, _ := http.NewRequest(method, urlStr, nil)
		gotPath = req.URL.Path
		return &http.Response{
			StatusCode: http.StatusOK,
			Body:       io.NopCloser(strings.NewReader(`{"code":"SUCCESS","data":{"dataList":[]}}`)),
			Header:     make(http.Header),
		}, nil
	})

	client := NewClient(mockCli)
	_, err := client.GetActiveOrders(context.Background(), &GetActiveOrderParams{
		PaginationParams: PaginationParams{Size: "10"},
		OrderFilterParams: OrderFilterParams{
			FilterIsLiquidate:    boolPtr(true),
			FilterIsDeleverage:   boolPtr(false),
			FilterIsPositionTpsl: boolPtr(true),
		},
	})
	require.NoError(t, err)
	assert.Equal(t, "GET", gotMethod)
	assert.Equal(t, "/api/v2/private/order/getActiveOrderPage", gotPath)
	assert.Equal(t, "true", gotParams["filterIsLiquidateList"])
	assert.Equal(t, "false", gotParams["filterIsDeleverageList"])
	assert.Equal(t, "true", gotParams["filterIsPositionTpslList"])
	assert.NotContains(t, gotParams, "filterIsLiquidate")
	assert.NotContains(t, gotParams, "filterIsDeleverage")
	assert.NotContains(t, gotParams, "filterIsPositionTpsl")
}

func TestGetOrderFillTransactionsUsesListBooleanFilters(t *testing.T) {
	var gotParams map[string]string

	mockCli := newMockClient(42, "", "https://example.com", func(urlStr, method string, data map[string]interface{}, params map[string]string) (*http.Response, error) {
		gotParams = params
		return &http.Response{
			StatusCode: http.StatusOK,
			Body:       io.NopCloser(strings.NewReader(`{"code":"SUCCESS","data":{"dataList":[]}}`)),
			Header:     make(http.Header),
		}, nil
	})

	client := NewClient(mockCli)
	_, err := client.GetOrderFillTransactions(context.Background(), &OrderFillTransactionParams{
		PaginationParams: PaginationParams{Size: "10"},
		OrderFilterParams: OrderFilterParams{
			FilterIsLiquidate:    boolPtr(true),
			FilterIsDeleverage:   boolPtr(false),
			FilterIsPositionTpsl: boolPtr(true),
		},
	})
	require.NoError(t, err)
	assert.Equal(t, "true", gotParams["filterIsLiquidateList"])
	assert.Equal(t, "false", gotParams["filterIsDeleverageList"])
	assert.Equal(t, "true", gotParams["filterIsPositionTpslList"])
	assert.NotContains(t, gotParams, "filterIsLiquidate")
	assert.NotContains(t, gotParams, "filterIsDeleverage")
	assert.NotContains(t, gotParams, "filterIsPositionTpsl")
}

func TestGetHistoryOrderPageUsesListBooleanFilters(t *testing.T) {
	var gotPath string
	var gotMethod string
	var gotParams map[string]string

	mockCli := newMockClient(42, "", "https://example.com", func(urlStr, method string, data map[string]interface{}, params map[string]string) (*http.Response, error) {
		gotMethod = method
		gotParams = params
		req, _ := http.NewRequest(method, urlStr, nil)
		gotPath = req.URL.Path
		return &http.Response{
			StatusCode: http.StatusOK,
			Body:       io.NopCloser(strings.NewReader(`{"code":"SUCCESS","data":{"dataList":[],"nextPageOffsetData":""}}`)),
			Header:     make(http.Header),
		}, nil
	})

	client := NewClient(mockCli)
	_, err := client.GetHistoryOrderPage(context.Background(), &GetHistoryOrderParams{
		PaginationParams: PaginationParams{
			Size:       "10",
			OffsetData: "offset-1",
		},
		OrderFilterParams: OrderFilterParams{
			FilterCoinIdList:     []string{"1000"},
			FilterContractIdList: []string{"10000001"},
			FilterTypeList:       []string{"LIMIT"},
			FilterStatusList:     []string{"FILLED"},
			FilterIsLiquidate:    boolPtr(true),
			FilterIsDeleverage:   boolPtr(false),
			FilterIsPositionTpsl: boolPtr(true),
		},
		FilterStartCreatedTimeInclusive: 100,
		FilterEndCreatedTimeExclusive:   200,
	})
	require.NoError(t, err)
	assert.Equal(t, "GET", gotMethod)
	assert.Equal(t, "/api/v2/private/order/getHistoryOrderPage", gotPath)
	assert.Equal(t, "42", gotParams["accountId"])
	assert.Equal(t, "10", gotParams["size"])
	assert.Equal(t, "offset-1", gotParams["offsetData"])
	assert.Equal(t, "1000", gotParams["filterCoinIdList"])
	assert.Equal(t, "10000001", gotParams["filterContractIdList"])
	assert.Equal(t, "LIMIT", gotParams["filterTypeList"])
	assert.Equal(t, "FILLED", gotParams["filterStatusList"])
	assert.Equal(t, "true", gotParams["filterIsLiquidateList"])
	assert.Equal(t, "false", gotParams["filterIsDeleverageList"])
	assert.Equal(t, "true", gotParams["filterIsPositionTpslList"])
	assert.Equal(t, "100", gotParams["filterStartCreatedTimeInclusive"])
	assert.Equal(t, "200", gotParams["filterEndCreatedTimeExclusive"])
	assert.NotContains(t, gotParams, "filterIsLiquidate")
	assert.NotContains(t, gotParams, "filterIsDeleverage")
	assert.NotContains(t, gotParams, "filterIsPositionTpsl")
}

func boolPtr(v bool) *bool {
	return &v
}

func TestCreateOrderV2UsesEIP712Signature(t *testing.T) {
	var gotPath string
	var gotBody map[string]interface{}

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotPath = r.URL.Path
		defer r.Body.Close()
		_ = json.NewDecoder(r.Body).Decode(&gotBody)
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"code":"SUCCESS","data":{"orderId":"123"}}`))
	}))
	defer srv.Close()

	mockCli := newMockClient(42, "0x59c6995e998f97a5a0044966f0945380f7d7f4fbcbe8f85f8f19853f51e7f7b4", srv.URL, func(urlStr, method string, data map[string]interface{}, params map[string]string) (*http.Response, error) {
		payload, _ := json.Marshal(data)
		req, _ := http.NewRequest(method, urlStr, bytes.NewReader(payload))
		req.Header.Set("Content-Type", "application/json")
		return srv.Client().Do(req)
	})

	client := NewClient(mockCli)

	clientOrderID := "order-v2-fixed-id"
	expireTime := time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)

	res, err := client.CreateOrder(context.Background(), &CreateOrderParams{
		ContractId:    "10000001",
		Price:         "2000",
		Size:          "0.1",
		Type:          OrderTypeLimit,
		Side:          OrderSideBuy,
		TimeInForce:   string(TimeInForce_GOOD_TIL_CANCEL),
		ClientOrderId: &clientOrderID,
		ExpireTime:    expireTime,
	}, &metadatapkg.MetaData{
		Global: &metadatapkg.Global{
			NativeChainId:   "42161",
			ContractAddress: "0x0000000000000000000000000000000000000001",
		},
		CoinList: []metadatapkg.Coin{
			{CoinId: "2", Resolution: "1000000"},
		},
		ContractList: []metadatapkg.Contract{
			{
				ContractId:          "10000001",
				QuoteCoinId:         "2",
				Resolution:          "1000000000",
				DefaultTakerFeeRate: "0.0005",
				DefaultMakerFeeRate: "0.0002",
			},
		},
	}, decimal.RequireFromString("2000"))
	require.NoError(t, err)
	require.NotNil(t, res)
	require.NotNil(t, res.Data)
	assert.Equal(t, "/api/v2/private/order/createOrder", gotPath)

	assert.Equal(t, "order-v2-fixed-id", gotBody["clientOrderId"])
	assert.Equal(t, strconv.FormatInt(internal.CalcNonce(clientOrderID), 10), gotBody["l2Nonce"])
	assert.Equal(t, "200", gotBody["l2Value"])
	assert.Equal(t, "1", gotBody["l2LimitFee"])
	assert.Equal(t, strconv.FormatInt(expireTime.UnixMilli(), 10), gotBody["expireTime"])
	assert.Equal(t, strconv.FormatInt(expireTime.UnixMilli()+8*24*60*60*1000, 10), gotBody["l2ExpireTime"])

	l2Signature, ok := gotBody["l2Signature"].(string)
	require.True(t, ok)
	assert.True(t, strings.HasPrefix(l2Signature, "0x"))
	assert.Len(t, l2Signature, 132)
}

func TestCreateOrderV2RequiresTradingPrivateKey(t *testing.T) {
	mockCli := newMockClient(42, "", "http://127.0.0.1", nil)

	client := NewClient(mockCli)
	_, err := client.CreateOrder(context.Background(), &CreateOrderParams{
		ContractId: "10000001",
		Price:      "2000",
		Size:       "0.1",
		Type:       OrderTypeLimit,
		Side:       OrderSideBuy,
	}, &metadatapkg.MetaData{
		Global: &metadatapkg.Global{
			NativeChainId:   "42161",
			ContractAddress: "0x0000000000000000000000000000000000000001",
		},
		CoinList: []metadatapkg.Coin{
			{CoinId: "2", Resolution: "1000000"},
		},
		ContractList: []metadatapkg.Contract{
			{
				ContractId:          "10000001",
				QuoteCoinId:         "2",
				Resolution:          "1000000000",
				DefaultTakerFeeRate: "0.0005",
				DefaultMakerFeeRate: "0.0002",
			},
		},
	}, decimal.RequireFromString("2000"))
	require.Error(t, err)
	assert.Contains(t, err.Error(), "trading private key is required")
}

func TestParseResolutionDecimalSupportsHexAndFallback(t *testing.T) {
	res, err := parseResolutionDecimal("0xf4240", "")
	require.NoError(t, err)
	assert.Equal(t, "1000000", res.String())

	res, err = parseResolutionDecimal("bad-resolution", "1000000000")
	require.NoError(t, err)
	assert.Equal(t, "1000000000", res.String())
}
