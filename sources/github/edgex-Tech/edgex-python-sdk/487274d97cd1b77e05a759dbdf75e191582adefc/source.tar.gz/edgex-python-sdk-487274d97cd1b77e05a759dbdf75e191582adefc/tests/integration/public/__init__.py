# Public endpoint tests
