"""Integration tests for the transfer API."""

import unittest
import logging
from typing import Dict, Any

from edgex_sdk import (
    GetTransferOutByIdParams,
    GetTransferInByIdParams,
    GetWithdrawAvailableAmountParams,
    CreateTransferOutParams,
    TransferReason
)
from tests.integration.base_test import BaseIntegrationTest

# Configure logging
logger = logging.getLogger(__name__)


class TestTransferAPI(BaseIntegrationTest):
    """Integration tests for the transfer API."""

    def test_get_withdraw_available_amount(self):
        """Test get_withdraw_available_amount method."""
        # Try with coinId "1000" first (we know this exists from account tests)
        params = GetWithdrawAvailableAmountParams(
            coin_id="1000"  # The coin we know exists from account asset tests
        )

        try:
            amount = self.run_async(self.client.transfer.get_withdraw_available_amount(params))

            # Check response
            self.assertResponseSuccess(amount)

            # Check data structure
            data = amount.get("data", {})
            self.assertIsInstance(data, dict)

            if "availableAmount" in data:
                available = data["availableAmount"]
                logger.info(f"Available withdraw amount for coinId 1000: {available}")
            else:
                logger.info(f"Withdraw available amount response: {data}")

        except Exception as e:
            # If coinId 1000 doesn't work, try coinId "2" (USDT)
            logger.info(f"CoinId 1000 failed, trying coinId 2: {e}")
            try:
                params = GetWithdrawAvailableAmountParams(coin_id="2")
                amount = self.run_async(self.client.transfer.get_withdraw_available_amount(params))
                self.assertResponseSuccess(amount)
                data = amount.get("data", {})
                logger.info(f"Available withdraw amount for coinId 2: {data}")
            except Exception as e2:
                logger.warning(f"Both coinId 1000 and 2 failed: {e2}")
                self.skipTest(f"Withdraw available amount not available for test coins: {e2}")

    def test_get_transfer_out_by_id_validation(self):
        """Test get_transfer_out_by_id method validation."""
        # Test with dummy IDs to validate parameter structure
        params = GetTransferOutByIdParams(
            transfer_id_list=["dummy_id_1", "dummy_id_2"]
        )

        # Validate parameter structure
        self.assertIsInstance(params.transfer_id_list, list)
        self.assertTrue(len(params.transfer_id_list) > 0)

        logger.info("Transfer out by ID parameter validation passed")
        logger.info("Actual API call skipped (requires valid transfer IDs)")

    def test_get_transfer_in_by_id_validation(self):
        """Test get_transfer_in_by_id method validation."""
        # Test with dummy IDs to validate parameter structure
        params = GetTransferInByIdParams(
            transfer_id_list=["dummy_id_1", "dummy_id_2"]
        )

        # Validate parameter structure
        self.assertIsInstance(params.transfer_id_list, list)
        self.assertTrue(len(params.transfer_id_list) > 0)

        logger.info("Transfer in by ID parameter validation passed")
        logger.info("Actual API call skipped (requires valid transfer IDs)")

    def test_create_transfer_out_validation(self):
        """Test create_transfer_out method validation (without actually creating)."""
        # Test parameter validation without actually submitting
        params = CreateTransferOutParams(
            coin_id="1000",
            amount="10",
            receiver_account_id="675524849547870757",
            transfer_reason=TransferReason.USER_TRANSFER
        )

        # We won't actually call the API to avoid creating real transfers
        # Just test that the parameters are properly structured
        self.assertIsInstance(params.coin_id, str)
        self.assertIsInstance(params.amount, str)
        self.assertIsInstance(params.receiver_account_id, str)
        self.assertEqual(params.transfer_reason, TransferReason.USER_TRANSFER)

        # Test optional parameters
        self.assertEqual(params.l2_expire_time, "")
        self.assertEqual(params.l2_nonce, "")
        self.assertEqual(params.l2_signature, "")
        self.assertEqual(params.signer, "")
        self.assertIsNone(params.extra_type)
        self.assertIsNone(params.extra_data_json)

        logger.info("Transfer out parameter validation passed")
        logger.warning("Actual transfer creation skipped for safety")

if __name__ == "__main__":
    unittest.main()
