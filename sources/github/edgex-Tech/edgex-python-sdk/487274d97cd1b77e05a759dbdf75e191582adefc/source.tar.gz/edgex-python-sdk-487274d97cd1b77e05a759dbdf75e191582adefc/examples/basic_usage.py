"""
Basic usage example for the EdgeX Python SDK.

This example demonstrates the basic functionality of the SDK:
- Creating a client
- Getting server time and metadata
- Getting account assets and positions
- Getting market data (K-lines, order book depth)
- Creating orders (commented out to avoid actual order creation)
- Using WebSockets for real-time data
"""

import asyncio
import os
from datetime import datetime, timedelta

from edgex_sdk import (
    Client,
    OrderSide,
    GetKLineParams,
    GetOrderBookDepthParams,
    KlineType,
    WebSocketManager,
    CreateTransferOutParams,
    TransferReason,
    CreateWithdrawParams,
)
from edgex_sdk.account.client import RegisterAccountParams
from edgex_sdk.order.types import CancelOrderParams, CreateOrderParams, OrderType
from edgex_sdk.transfer.client import GetWithdrawAvailableAmountParams


async def main():
    # Load configuration from environment variables
    base_url = os.getenv("EDGEX_BASE_URL", "https://edgex-prod-v2.edgex.exchange")
    asset_base_url = os.getenv("EDGEX_ASSET_BASE_URL", "https://spot.edgex.exchange")
    account_id = int(os.getenv("EDGEX_ACCOUNT_ID", "your_account_id"))
    trading_private_key = os.getenv("EDGEX_TRADING_PRIVATE_KEY", "your_private_key")
    wallet_private_key = os.getenv("EDGEX_SIGNER_PRIVATE_KEY", trading_private_key)

    # Create a new client
    client = Client(
        base_url=base_url,
        asset_base_url=asset_base_url,
        account_id=account_id,
        trading_private_key=trading_private_key,
        wallet_private_key=wallet_private_key
    )

    # Get server time
    server_time = await client.get_server_time()
    print(f"Server Time: {server_time}")

    # Get exchange metadata first (required for transfer operations)
    metadata = await client.get_metadata()
    print(f"Available contracts: {len(metadata.get('data', {}).get('contractList', []))}")

    # Get account assets
    assets = await client.get_account_asset()
    print(f"Account Assets: {assets}")

    # Get K-line data for BTCUSDT (contract ID: 10000001)
    kline_params = GetKLineParams(
        contract_id="10000001",  # BTCUSDT
        kline_type=KlineType.MINUTE_1,
        size=10
    )
    klines = await client.quote.get_k_line(kline_params)
    print(f"K-lines: {klines}")

    # Get account positions
    positions = await client.get_account_positions()
    print(f"Account Positions: {positions}")

    # Get 24-hour market data for BNBUSDT (contract ID: 10000004)
    quote = await client.get_24_hour_quote("10000004")
    print(f"BNBUSDT Price: {quote}")

    # Get K-line data for BTCUSDT (contract ID: 10000001)
    kline_params = GetKLineParams(
        contract_id="10000001",  # BTCUSDT
        kline_type=KlineType.MINUTE_1,
        size=10
    )
    klines = await client.quote.get_k_line(kline_params)
    print(f"K-lines: {klines}")

    # Get order book depth for ETHUSDT (contract ID: 10000002)
    depth_params = GetOrderBookDepthParams(
        contract_id="10000002",  # ETHUSDT
        limit=15  # Valid values are 15 or 200
    )
    depth = await client.quote.get_order_book_depth(depth_params)
    print(f"Order Book Depth: {depth}")

    maxOrderSize = await client.get_max_order_size("10000001", 100000.0)
    print(f"Max Order size: {maxOrderSize}")
    
    # Create a limit order (commented out to avoid actual order creation)
    order = await client.create_order(CreateOrderParams(
        contract_id="10000004",  # BNBUSDT
        size="0.01",
        price="600.00",
        type=OrderType.LIMIT,
        side=OrderSide.BUY,
    ))
    print(f"Order created: {order}")

    # Create a market order 
    order = await client.create_order(CreateOrderParams(
        contract_id="10000004",  # BNBUSDT
        size="0.01",
        price="0",
        type=OrderType.MARKET,
        side=OrderSide.BUY
    ))
    print(f"Order created: {order}")

    param = CancelOrderParams(
        client_order_id ="676249092405330305"
    )
    cancelRes = await client.cancel_order(param)
    print(f"Cancel Order: {cancelRes}")

    # Create a transfer out order with new optional parameters
    try:
        transferMaxAmount = await client.transfer.get_transferout_available_amount("1000")
        print(transferMaxAmount)

        # Set expiration time to 24 hours from now
        expire_time = datetime.now() + timedelta(hours=24)

        transfer_result = await client.create_transfer_out(
            CreateTransferOutParams(
                coin_id="1000",
                amount="10",
                receiver_account_id="your-receiver-account-id",
                receiver_l2_key="your-receiver-l2-key", # "0x111111"
                transfer_reason=TransferReason.USER_TRANSFER,
                expire_time=expire_time,
                extra_type="CUSTOM_TYPE",
                extra_data_json='{"custom_field": "custom_value"}'
            ))
        print(f"Transfer out result: {transfer_result}")

    except ValueError as e:
        print(f"Failed to create transfer out: {e}")
    except Exception as e:
        print(f"Unexpected error: {e}")

    # Create a unified-asset withdrawal order
    withdrawResult = await client.create_withdraw(CreateWithdrawParams(
        amount_raw="10000000",
        user_address="your-evm-address",
        profile="mainnet-usdc"
    ))
    print(f"WithdrawResult: {withdrawResult}")

    # WebSocket example
    ws_url = os.getenv("EDGEX_WS_URL", "wss://edgex-quote-prod-v2.edgex.exchange")
    ws_manager = WebSocketManager(
        base_url=ws_url,
        account_id=account_id,
        api_key="",
        api_passphrase="",
        api_secret=""
    )

    # Define message handlers
    def ticker_handler(message):
        print(f"Ticker Update: {message}")

    def kline_handler(message):
        print(f"K-line Update: {message}")

    # Connect to public WebSocket for market data
    ws_manager.connect_public()

    # Subscribe to real-time updates for BNBUSDT (contract ID: 10000004)
    ws_manager.subscribe_ticker("10000004", ticker_handler)
    ws_manager.subscribe_kline("10000004", "1m", kline_handler)

    # Wait for updates
    await asyncio.sleep(30)

    # Disconnect all connections
    ws_manager.disconnect_all()

if __name__ == "__main__":
    asyncio.run(main())
