from .client import Client
from .order.types import (
    CreateOrderParams,
    CancelOrderParams,
    GetActiveOrderParams,
    OpenTpSlParams,
    OrderFillTransactionParams,
    GetHistoryOrderPageParams,
    OrderType,
    OrderSide,
    TimeInForce,
    TriggerPriceType,
)
from .transfer.client import (
    CreateTransferOutParams,
    TransferReason,
    GetTransferOutByIdParams,
    GetTransferInByIdParams,
    GetWithdrawAvailableAmountParams,
)
from .unified_asset.client import (
    CreateSpotDepositParams,
    CreateWithdrawParams,
    ZERO_ADDRESS,
    build_spot_deposit_attempt,
    profile_name_for_asset,
    resolve_withdraw_profile,
)
from .cctp.client import CCTPBridgeClient
from .account.client import (
    GetPositionTransactionPageParams,
    GetCollateralTransactionPageParams,
    GetPositionOrdersParams,
    GetPositionTermPageParams,
    GetAccountAssetSnapshotPageParams,
    GetAccountPageParams,
    SetMarginModeParams,
)
from .quote.client import (
    KlineType,
    PriceType,
    GetKLineParams,
    GetOrderBookDepthParams,
    GetMultiContractKLineParams,
    GetMarketStatusParams,
)


def __getattr__(name):
    if name == "WebSocketManager":
        from .ws.manager import Manager as WebSocketManager

        return WebSocketManager
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "Client",
    "CreateOrderParams",
    "CancelOrderParams",
    "GetActiveOrderParams",
    "OpenTpSlParams",
    "OrderFillTransactionParams",
    "GetHistoryOrderPageParams",
    "OrderType",
    "OrderSide",
    "TimeInForce",
    "TriggerPriceType",
    "CreateTransferOutParams",
    "TransferReason",
    "GetTransferOutByIdParams",
    "GetTransferInByIdParams",
    "GetWithdrawAvailableAmountParams",
    "CreateSpotDepositParams",
    "CreateWithdrawParams",
    "ZERO_ADDRESS",
    "build_spot_deposit_attempt",
    "profile_name_for_asset",
    "resolve_withdraw_profile",
    "CCTPBridgeClient",
    "GetPositionTransactionPageParams",
    "GetCollateralTransactionPageParams",
    "GetPositionOrdersParams",
    "GetPositionTermPageParams",
    "GetAccountAssetSnapshotPageParams",
    "GetAccountPageParams",
    "SetMarginModeParams",
    "KlineType",
    "PriceType",
    "GetKLineParams",
    "GetOrderBookDepthParams",
    "GetMultiContractKLineParams",
    "GetMarketStatusParams",
    "WebSocketManager",
]
