// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (C) 2024 PancakeSwap
pragma solidity ^0.8.0;

import {ActionConstants} from "infinity-periphery/src/libraries/ActionConstants.sol";
import {RouterImmutables} from "../../base/RouterImmutables.sol";
import {Payments} from "../Payments.sol";
import {Permit2Payments} from "../Permit2Payments.sol";
import {Constants} from "../../libraries/Constants.sol";
import {UniversalRouterHelper} from "../../libraries/UniversalRouterHelper.sol";
import {ERC20} from "solmate/src/tokens/ERC20.sol";
import {SafeTransferLib} from "solmate/src/utils/SafeTransferLib.sol";
import {Ownable, Ownable2Step} from "@openzeppelin/contracts/access/Ownable2Step.sol";
import {IStableSwap} from "../../interfaces/IStableSwap.sol";

/// @title Router for PancakeSwap Stable Trades
abstract contract StableSwapRouter is RouterImmutables, Permit2Payments, Ownable2Step {
    using SafeTransferLib for ERC20;
    using UniversalRouterHelper for address;

    error StableTooLittleReceived();
    error StableTooMuchRequested();
    error StableInvalidPath();
    error StableInvalidAmountIn();

    address public stableSwapFactory;
    address public stableSwapInfo;

    event SetStableSwap(address indexed factory, address indexed info);

    constructor(address _stableSwapFactory, address _stableSwapInfo) Ownable(msg.sender) {
        stableSwapFactory = _stableSwapFactory;
        stableSwapInfo = _stableSwapInfo;
    }

    /**
     * @notice Set Pancake Stable Swap Factory and Info
     * @dev Only callable by contract owner
     */
    function setStableSwap(address _factory, address _info) external onlyOwner {
        require(_factory != address(0) && _info != address(0));

        stableSwapFactory = _factory;
        stableSwapInfo = _info;

        emit SetStableSwap(stableSwapFactory, stableSwapInfo);
    }

    /// @dev if a single hop, path would be of size 2, and flag would be of size 1
    /// if 2 hops, path would be of size 3, and flag would be of size 2
    /// @dev at least one hop is required: a path of size 1 would pass the length check, skip the
    /// loop entirely and return amountIn as amtOut, turning the swap into a plain token transfer
    /// @return amtOut The amount of output tokens received after the swap
    function _stableSwap(address[] calldata path, uint256[] calldata flag, uint256 amountIn)
        private
        returns (uint256 amtOut)
    {
        if (path.length < 2 || path.length - 1 != flag.length) revert StableInvalidPath();

        uint256 outputTokenBal;
        for (uint256 i; i < flag.length; i++) {
            (address input, address output) = (path[i], path[i + 1]);

            outputTokenBal = ERC20(output).balanceOf(address(this));

            (uint256 k, uint256 j, address swapContract) = stableSwapFactory.getStableInfo(input, output, flag[i]);
            ERC20(input).safeApprove(swapContract, amountIn);
            IStableSwap(swapContract).exchange(k, j, amountIn, 0);

            // Update amountIn for the next hop. this is done as swapContract do not return the output amount
            // If this is the last hop, amountIn is the output amount
            amountIn = ERC20(output).balanceOf(address(this)) - outputTokenBal;
        }

        // after the swap iterations, amountIn is the output amount
        amtOut = amountIn;
    }

    /// @notice Performs a PancakeSwap stable exact input swap
    /// @param recipient The recipient of the output tokens
    /// @param amountIn The amount of input tokens for the trade, or ActionConstants.CONTRACT_BALANCE
    /// to swap the router's entire balance of path[0]
    /// @param amountOutMinimum The minimum desired amount of output tokens
    /// @param path The path of the trade as an array of token addresses
    /// @param flag token amount in a stable swap pool. 2 for 2pool, 3 for 3pool
    /// @param payer The address that will be paying the input
    function stableSwapExactInput(
        address recipient,
        uint256 amountIn,
        uint256 amountOutMinimum,
        address[] calldata path,
        uint256[] calldata flag,
        address payer
    ) internal {
        if (amountIn == ActionConstants.CONTRACT_BALANCE) {
            amountIn = ERC20(path[0]).balanceOf(address(this));
        } else if (amountIn != Constants.ALREADY_PAID) {
            payOrPermit2Transfer(path[0], payer, address(this), amountIn);
        }

        /// @dev Constants.ALREADY_PAID (0) is not a valid amount here: a stable pool pulls its input
        /// via transferFrom, so there is no "pool already funded" flow to piggyback on. Callers that
        /// want to trade the router's whole balance must pass ActionConstants.CONTRACT_BALANCE.
        /// Reverting also stops an empty CONTRACT_BALANCE from silently swapping nothing.
        if (amountIn == 0) revert StableInvalidAmountIn();

        uint256 amountOut = _stableSwap(path, flag, amountIn);
        if (amountOut < amountOutMinimum) revert StableTooLittleReceived();

        address tokenOut = path[path.length - 1];
        if (recipient != address(this)) pay(tokenOut, recipient, amountOut);
    }

    /// @notice Performs a PancakeSwap stable exact output swap
    /// @param recipient The recipient of the output tokens
    /// @param amountIn The amount of input token
    /// @param amountOut The amount of output tokens to receive for the trade
    /// @param path The path of the trade as an array of token addresses
    /// @param flag token amount in a stable swap pool. 2 for 2pool, 3 for 3pool
    /// @param payer The address that will be paying the input
    function stableSwapExactOutput(
        address recipient,
        uint256 amountIn,
        uint256 amountOut,
        address[] calldata path,
        uint256[] calldata flag,
        address payer
    ) internal {
        payOrPermit2Transfer(path[0], payer, address(this), amountIn);

        /// @dev amountIn is quoted off the pool via getStableAmountsIn, so the forward swap is
        /// expected to yield at least amountOut. Enforce it rather than paying amountOut out of
        /// whatever balance the router happens to hold.
        uint256 amtOut = _stableSwap(path, flag, amountIn);
        if (amtOut < amountOut) revert StableTooLittleReceived();

        /// @dev pay out the measured output rather than the requested amountOut: any surplus the
        /// pool returned belongs to the payer, and leaving it here makes it sweepable by anyone.
        /// This mirrors the exact input path, which also pays the measured amount.
        if (recipient != address(this)) pay(path[path.length - 1], recipient, amtOut);
    }

    function stableSwapExactOutputAmountIn(
        uint256 amountOut,
        uint256 amountInMaximum,
        address[] calldata path,
        uint256[] calldata flag
    ) internal returns (uint256 amountIn) {
        amountIn = stableSwapFactory.getStableAmountsIn(stableSwapInfo, path, flag, amountOut)[0];

        if (amountIn > amountInMaximum) revert StableTooMuchRequested();
    }
}
