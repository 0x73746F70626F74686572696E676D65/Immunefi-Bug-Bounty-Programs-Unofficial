# Solidity API

## TickLens

### getPopulatedTicksInWord

```solidity
function getPopulatedTicksInWord(address pool, int16 tickBitmapIndex) public view returns (struct ITickLens.PopulatedTick[] populatedTicks)
```

Get all the tick data for the populated ticks from a word of the tick bitmap of a pool

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| pool | address | The address of the pool for which to fetch populated tick data |
| tickBitmapIndex | int16 | The index of the word in the tick bitmap for which to parse the bitmap and fetch all the populated ticks |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| populatedTicks | struct ITickLens.PopulatedTick[] | An array of tick data for the given word in the tick bitmap |

