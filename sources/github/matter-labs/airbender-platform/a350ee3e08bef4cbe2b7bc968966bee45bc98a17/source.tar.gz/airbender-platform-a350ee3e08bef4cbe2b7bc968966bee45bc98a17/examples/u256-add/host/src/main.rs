use airbender_host::{
    Inputs, Program, Prover, Result, Runner, SecurityLevel, VerificationRequest, Verifier,
};
use ruint::aliases::U256;
use std::path::PathBuf;

fn main() -> Result<()> {
    let prove = std::env::args().skip(1).any(|arg| arg == "--prove");
    // We assume that the guest program is located in `../guest/dist/app`,
    // which is the default behavior of `cargo airbender build`.
    let dist_dir = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../guest/dist/app");
    let program = Program::load(&dist_dir)?;

    let a = U256::from(1u64);
    let b = U256::from(2u64);
    let c = U256::from(3u64);

    let mut inputs = Inputs::new();
    inputs.push(&a)?;
    inputs.push(&b)?;
    inputs.push(&c)?;

    let runner = program.transpiler_runner().build()?;
    let execution = runner.run(inputs.words())?;
    let exec_valid = execution.receipt.output[0] == 1;
    println!(
        "Execution finished: cycles={}, reached_end={}, valid={}",
        execution.cycles_executed, execution.reached_end, exec_valid
    );
    assert!(exec_valid, "guest reported invalid sum");

    if !prove {
        println!("Skipping proof generation (pass `--prove` to generate and verify proof).");
        return Ok(());
    }

    let security = SecurityLevel::default();
    let prover = program.dev_prover().with_security(security).build()?;
    let prove_result = prover.prove(inputs.words())?;
    let proof_valid = prove_result.receipt.output[0] == 1;
    println!(
        "Proof generated: cycles={}, valid={}",
        prove_result.cycles, proof_valid
    );

    let verifier = program.dev_verifier().build()?;
    let vk = verifier.generate_vk(security)?;
    verifier.verify(
        &prove_result.proof,
        &vk,
        VerificationRequest::dev(inputs.words(), &true),
    )?;
    println!("Proof verified.");

    assert_eq!(
        exec_valid, proof_valid,
        "execution and proof output mismatch"
    );

    Ok(())
}
