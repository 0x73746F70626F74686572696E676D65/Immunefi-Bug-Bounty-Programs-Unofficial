use crate::BigInt;

pub(crate) mod delegation;
pub mod u256;
pub mod u512;

pub trait DelegatedModParams<const N: usize>: Default {
    const MODULUS_BITSIZE: usize;

    /// Provides a reference to the modululs for delegation purposes
    fn modulus() -> &'static BigInt<N>;
}

pub trait DelegatedMontParams<const N: usize>: DelegatedModParams<N> {
    /// Provides a reference to the reduction const (`-1/Self::modulus mod 2^256`) for Montgomerry reduction
    fn reduction_const() -> &'static BigInt<4>;
}

pub trait DelegatedBarretParams<const N: usize>: DelegatedModParams<N> {
    /// Provides a reference to `-Self::modulus mod 2^256` for Barret reduction
    fn neg_modulus() -> &'static BigInt<4>;
}
