use clap::{Args, Parser, Subcommand, ValueEnum};
use std::path::PathBuf;

#[derive(Parser, Debug)]
#[command(
    name = "cargo-airbender",
    bin_name = "cargo airbender",
    version,
    about = "Airbender cargo subcommand"
)]
pub struct Cli {
    #[command(subcommand)]
    pub command: Commands,
}

impl Cli {
    /// Cargo invokes subcommand binaries as `cargo-airbender airbender <args>`.
    /// We strip the synthetic `airbender` token so clap can parse the command list naturally.
    pub fn parse_for_cargo() -> Self {
        let mut args: Vec<String> = std::env::args().collect();
        if args.get(1).map(String::as_str) == Some("airbender") {
            args.remove(1);
        }
        <Self as Parser>::parse_from(args)
    }
}

#[derive(Subcommand, Debug)]
pub enum Commands {
    /// Build and package guest artifacts into dist/.
    Build(BuildArgs),
    /// Create a new host + guest project from templates.
    New(NewArgs),
    /// Run app.bin via the transpiler.
    Run(RunArgs),
    /// Run app.bin with transpiler profiling and emit flamegraph SVG.
    Flamegraph(FlamegraphArgs),
    /// Generate a proof and write it as bincode.
    Prove(ProveArgs),
    /// Generate verification keys and write them as bincode.
    /// Requires GPU support in `cargo-airbender` (enabled by default).
    GenerateVk(GenerateVkArgs),
    /// Verify a proof against verification keys.
    VerifyProof(VerifyProofArgs),
    /// Remove Docker resources created by reproducible builds.
    Clean,
}

#[derive(Args, Debug)]
pub struct BuildArgs {
    #[arg(long, default_value = "app")]
    pub app_name: String,
    #[arg(long)]
    pub bin: Option<String>,
    #[arg(long)]
    pub target: Option<String>,
    #[arg(long)]
    pub dist: Option<PathBuf>,
    #[arg(long)]
    pub project: Option<PathBuf>,
    #[arg(long, value_enum, conflicts_with_all = ["debug", "release"])]
    pub profile: Option<BuildProfile>,
    #[arg(long, conflicts_with = "release")]
    pub debug: bool,
    #[arg(long, conflicts_with = "debug")]
    pub release: bool,
    #[arg(last = true, value_name = "CARGO_ARGS")]
    pub cargo_args: Vec<String>,
    /// Build inside a pinned Docker container for bit-for-bit reproducible output.
    /// Automatically passes `--locked` to cargo; the project must have a committed `Cargo.lock`.
    #[arg(long)]
    pub reproducible: bool,
    /// Override the directory bind-mounted as /src inside the reproducible build container.
    /// Only needed when the guest has path dependencies pointing outside its own cargo workspace
    /// root, e.g. in a monorepo where the guest shares crates with the host via relative paths.
    /// Has no effect without --reproducible.
    #[arg(long, requires = "reproducible")]
    pub workspace_root: Option<PathBuf>,
}

#[derive(ValueEnum, Debug, Clone, Copy)]
pub enum BuildProfile {
    Debug,
    Release,
}

#[derive(Args, Debug)]
pub struct NewArgs {
    pub path: Option<PathBuf>,
    #[arg(long)]
    pub name: Option<String>,
    #[arg(long)]
    pub enable_std: bool,
    #[arg(long, value_enum, default_value_t = NewAllocatorArg::Talc)]
    pub allocator: NewAllocatorArg,
    #[arg(
        long,
        value_enum,
        default_value_t = NewProverBackendArg::Dev,
        long_help = "Select host template proving backend.\n- dev: mock proof envelope for development (no cryptographic proving).\n- gpu: real GPU proving; requires CUDA-capable NVIDIA GPU at runtime. You can compile with ZKSYNC_USE_CUDA_STUBS=true, but running proving without CUDA setup panics."
    )]
    pub prover_backend: NewProverBackendArg,
    #[arg(short = 'y', long)]
    pub yes: bool,
    #[arg(long, conflicts_with = "sdk_version")]
    pub sdk_path: Option<PathBuf>,
    #[arg(long, conflicts_with = "sdk_path")]
    pub sdk_version: Option<String>,
}

#[derive(ValueEnum, Debug, Clone, Copy, PartialEq, Eq)]
pub enum NewAllocatorArg {
    Talc,
    Bump,
    Custom,
}

#[derive(ValueEnum, Debug, Clone, Copy, PartialEq, Eq)]
pub enum NewProverBackendArg {
    /// Use transpiler execution and emit a mock proof envelope (best for development).
    Dev,
    /// Use real GPU proving (requires CUDA-capable NVIDIA GPU at runtime).
    Gpu,
}

#[derive(Args, Debug)]
pub struct FlamegraphArgs {
    pub app_bin: PathBuf,
    #[arg(short, long)]
    pub input: PathBuf,
    #[arg(short, long, default_value = "flamegraph.svg")]
    pub output: PathBuf,
    #[arg(short, long)]
    pub cycles: Option<usize>,
    #[arg(long, default_value_t = 100)]
    pub sampling_rate: usize,
    #[arg(long)]
    pub inverse: bool,
    #[arg(long)]
    pub elf_path: Option<PathBuf>,
}

#[derive(Args, Debug)]
pub struct RunArgs {
    pub app_bin: PathBuf,
    #[arg(short, long)]
    pub input: PathBuf,
    #[arg(short, long)]
    pub cycles: Option<usize>,
    #[arg(long)]
    pub text_path: Option<PathBuf>,
    #[arg(
        long,
        help = "Enable transpiler JIT execution (x86_64 only); default is portable non-JIT mode"
    )]
    pub jit: bool,
}

#[derive(Args, Debug)]
pub struct ProveArgs {
    pub app_bin: PathBuf,
    #[arg(short, long)]
    pub input: PathBuf,
    #[arg(long)]
    pub output: PathBuf,
    #[arg(
        long,
        value_enum,
        default_value_t = ProverBackendArg::Dev,
        long_help = "Select proving backend.\n- dev: mock proof envelope for development (no cryptographic proving).\n- cpu: real CPU proving (base level only).\n- gpu: real GPU proving; requires GPU-enabled `cargo-airbender` (enabled by default)."
    )]
    pub backend: ProverBackendArg,
    #[arg(short, long)]
    pub threads: Option<usize>,
    #[arg(long)]
    pub cycles: Option<usize>,
    #[arg(long)]
    pub ram_bound: Option<usize>,
    #[arg(long, value_enum, default_value_t = ProverLevelArg::RecursionUnified)]
    pub level: ProverLevelArg,
    #[arg(
        long,
        value_enum,
        default_value_t = SecurityLevelArg::default(),
        help = "Security level recorded in proof artifacts (80 or 100 bits; default: 100)"
    )]
    pub security: SecurityLevelArg,
}

#[derive(Args, Debug)]
pub struct GenerateVkArgs {
    pub app_bin: PathBuf,
    #[arg(short, long, default_value = "vk.bin")]
    pub output: PathBuf,
    #[arg(long, value_enum, default_value_t = ProverLevelArg::RecursionUnified)]
    pub level: ProverLevelArg,
    #[arg(
        long,
        value_enum,
        default_value_t = SecurityLevelArg::default(),
        help = "Security level for verification keys (80 or 100 bits; default: 100)"
    )]
    pub security: SecurityLevelArg,
}

#[derive(Args, Debug)]
pub struct VerifyProofArgs {
    pub proof: PathBuf,
    #[arg(long)]
    pub vk: PathBuf,
    #[arg(
        long,
        value_name = "WORDS",
        help = "Comma-separated expected public output words (x10..x17), decimal or 0x hex"
    )]
    pub expected_output: Option<String>,
}

#[derive(ValueEnum, Debug, Clone, Copy)]
pub enum ProverBackendArg {
    Dev,
    Cpu,
    Gpu,
}

#[derive(ValueEnum, Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProverLevelArg {
    Base,
    RecursionUnrolled,
    RecursionUnified,
}

#[derive(ValueEnum, Debug, Clone, Copy, PartialEq, Eq)]
pub enum SecurityLevelArg {
    #[value(name = "80")]
    Bits80,
    #[value(name = "100")]
    Bits100,
}

impl Default for SecurityLevelArg {
    fn default() -> Self {
        Self::from(airbender_host::SecurityLevel::default())
    }
}

impl From<airbender_host::SecurityLevel> for SecurityLevelArg {
    fn from(security: airbender_host::SecurityLevel) -> Self {
        match security {
            airbender_host::SecurityLevel::Bits80 => Self::Bits80,
            airbender_host::SecurityLevel::Bits100 => Self::Bits100,
        }
    }
}

impl From<SecurityLevelArg> for airbender_host::SecurityLevel {
    fn from(security: SecurityLevelArg) -> Self {
        match security {
            SecurityLevelArg::Bits80 => Self::Bits80,
            SecurityLevelArg::Bits100 => Self::Bits100,
        }
    }
}

impl std::fmt::Display for SecurityLevelArg {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let host_security = airbender_host::SecurityLevel::from(*self);
        write!(formatter, "{host_security}")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_run_jit_flag() {
        let cli = Cli::parse_from([
            "cargo-airbender",
            "run",
            "app.bin",
            "--input",
            "input.hex",
            "--jit",
        ]);
        match cli.command {
            Commands::Run(args) => {
                assert_eq!(args.app_bin, PathBuf::from("app.bin"));
                assert_eq!(args.input, PathBuf::from("input.hex"));
                assert!(args.jit);
            }
            other => panic!("unexpected command: {other:?}"),
        }
    }

    #[test]
    fn parse_build_trailing_cargo_args() {
        let cli = Cli::parse_from([
            "cargo-airbender",
            "build",
            "--",
            "--features",
            "gpu",
            "--color",
            "always",
        ]);
        match cli.command {
            Commands::Build(args) => {
                assert_eq!(args.app_name, "app");
                assert_eq!(
                    args.cargo_args,
                    vec!["--features", "gpu", "--color", "always"]
                );
            }
            other => panic!("unexpected command: {other:?}"),
        }
    }

    #[test]
    fn parse_build_custom_app_name() {
        let cli = Cli::parse_from(["cargo-airbender", "build", "--app-name", "gpu-profile"]);
        match cli.command {
            Commands::Build(args) => {
                assert_eq!(args.app_name, "gpu-profile");
            }
            other => panic!("unexpected command: {other:?}"),
        }
    }

    #[test]
    fn parse_build_reproducible_flag() {
        let cli = Cli::parse_from(["cargo-airbender", "build", "--reproducible"]);
        match cli.command {
            Commands::Build(args) => {
                assert!(args.reproducible);
                assert_eq!(args.app_name, "app");
            }
            other => panic!("unexpected command: {other:?}"),
        }
    }

    #[test]
    fn parse_build_workspace_root_with_reproducible() {
        let cli = Cli::parse_from([
            "cargo-airbender",
            "build",
            "--reproducible",
            "--workspace-root",
            "/repo",
        ]);
        match cli.command {
            Commands::Build(args) => {
                assert!(args.reproducible);
                assert_eq!(args.workspace_root, Some(PathBuf::from("/repo")));
            }
            other => panic!("unexpected command: {other:?}"),
        }
    }

    #[test]
    fn parse_build_workspace_root_requires_reproducible() {
        let err = Cli::try_parse_from(["cargo-airbender", "build", "--workspace-root", "/repo"])
            .expect_err("--workspace-root without --reproducible should fail");
        assert!(err.to_string().contains("--reproducible"));
    }

    #[test]
    fn parse_build_rejects_top_level_cargo_flags() {
        let err = Cli::try_parse_from(["cargo-airbender", "build", "--features", "gpu"])
            .expect_err("parse should fail without -- forwarding separator");
        assert!(err.to_string().contains("--features"));
    }

    #[test]
    fn parse_new_enable_std() {
        let cli = Cli::parse_from([
            "cargo-airbender",
            "new",
            "./hello-airbender",
            "--enable-std",
        ]);
        match cli.command {
            Commands::New(args) => {
                assert_eq!(args.path, Some(PathBuf::from("./hello-airbender")));
                assert!(args.enable_std);
                assert_eq!(args.allocator, NewAllocatorArg::Talc);
                assert_eq!(args.prover_backend, NewProverBackendArg::Dev);
            }
            other => panic!("unexpected command: {other:?}"),
        }
    }

    #[test]
    fn parse_new_allocator_custom() {
        let cli = Cli::parse_from([
            "cargo-airbender",
            "new",
            "./hello-airbender",
            "--allocator",
            "custom",
        ]);
        match cli.command {
            Commands::New(args) => {
                assert_eq!(args.path, Some(PathBuf::from("./hello-airbender")));
                assert_eq!(args.allocator, NewAllocatorArg::Custom);
                assert_eq!(args.prover_backend, NewProverBackendArg::Dev);
            }
            other => panic!("unexpected command: {other:?}"),
        }
    }

    #[test]
    fn parse_new_prover_backend_gpu() {
        let cli = Cli::parse_from([
            "cargo-airbender",
            "new",
            "./hello-airbender",
            "--prover-backend",
            "gpu",
        ]);
        match cli.command {
            Commands::New(args) => {
                assert_eq!(args.path, Some(PathBuf::from("./hello-airbender")));
                assert_eq!(args.prover_backend, NewProverBackendArg::Gpu);
            }
            other => panic!("unexpected command: {other:?}"),
        }
    }

    #[test]
    fn parse_new_without_path() {
        let cli = Cli::parse_from(["cargo-airbender", "new"]);
        match cli.command {
            Commands::New(args) => {
                assert_eq!(args.path, None);
                assert!(!args.yes);
                assert_eq!(args.allocator, NewAllocatorArg::Talc);
                assert_eq!(args.prover_backend, NewProverBackendArg::Dev);
            }
            other => panic!("unexpected command: {other:?}"),
        }
    }

    #[test]
    fn parse_new_yes_flag() {
        let cli = Cli::parse_from(["cargo-airbender", "new", "--yes"]);
        match cli.command {
            Commands::New(args) => {
                assert!(args.yes);
            }
            other => panic!("unexpected command: {other:?}"),
        }
    }

    #[test]
    fn parse_verify_proof_expected_output() {
        let cli = Cli::parse_from([
            "cargo-airbender",
            "verify-proof",
            "proof.bin",
            "--vk",
            "vk.bin",
            "--expected-output",
            "42,0,0",
        ]);
        match cli.command {
            Commands::VerifyProof(args) => {
                assert_eq!(args.proof, PathBuf::from("proof.bin"));
                assert_eq!(args.vk, PathBuf::from("vk.bin"));
                assert_eq!(args.expected_output.as_deref(), Some("42,0,0"));
            }
            other => panic!("unexpected command: {other:?}"),
        }
    }

    #[test]
    fn parse_verify_proof_rejects_repeated_expected_output() {
        let err = Cli::try_parse_from([
            "cargo-airbender",
            "verify-proof",
            "proof.bin",
            "--vk",
            "vk.bin",
            "--expected-output",
            "1",
            "--expected-output",
            "2",
        ])
        .expect_err("repeated expected-output flag should fail");

        assert!(err.to_string().contains("cannot be used multiple times"));
    }

    #[test]
    fn parse_prove_security_100() {
        let cli = Cli::parse_from([
            "cargo-airbender",
            "prove",
            "app.bin",
            "--input",
            "input.hex",
            "--output",
            "proof.bin",
            "--backend",
            "gpu",
            "--security",
            "100",
        ]);
        match cli.command {
            Commands::Prove(args) => {
                assert_eq!(args.security, SecurityLevelArg::Bits100);
            }
            other => panic!("unexpected command: {other:?}"),
        }
    }

    #[test]
    fn parse_prove_security_defaults_to_100() {
        let cli = Cli::parse_from([
            "cargo-airbender",
            "prove",
            "app.bin",
            "--input",
            "input.hex",
            "--output",
            "proof.bin",
            "--backend",
            "gpu",
        ]);
        match cli.command {
            Commands::Prove(args) => {
                assert_eq!(args.security, SecurityLevelArg::Bits100);
            }
            other => panic!("unexpected command: {other:?}"),
        }
    }

    #[test]
    fn parse_generate_vk_security_80() {
        let cli = Cli::parse_from([
            "cargo-airbender",
            "generate-vk",
            "app.bin",
            "--security",
            "80",
        ]);
        match cli.command {
            Commands::GenerateVk(args) => {
                assert_eq!(args.security, SecurityLevelArg::Bits80);
            }
            other => panic!("unexpected command: {other:?}"),
        }
    }

    #[test]
    fn parse_generate_vk_security_defaults_to_100() {
        let cli = Cli::parse_from(["cargo-airbender", "generate-vk", "app.bin"]);
        match cli.command {
            Commands::GenerateVk(args) => {
                assert_eq!(args.security, SecurityLevelArg::Bits100);
            }
            other => panic!("unexpected command: {other:?}"),
        }
    }

    #[test]
    fn parse_prove_rejects_invalid_security() {
        let err = Cli::try_parse_from([
            "cargo-airbender",
            "prove",
            "app.bin",
            "--input",
            "input.hex",
            "--output",
            "proof.bin",
            "--security",
            "90",
        ])
        .expect_err("invalid security should fail");

        assert!(err.to_string().contains("invalid value"));
    }
}
