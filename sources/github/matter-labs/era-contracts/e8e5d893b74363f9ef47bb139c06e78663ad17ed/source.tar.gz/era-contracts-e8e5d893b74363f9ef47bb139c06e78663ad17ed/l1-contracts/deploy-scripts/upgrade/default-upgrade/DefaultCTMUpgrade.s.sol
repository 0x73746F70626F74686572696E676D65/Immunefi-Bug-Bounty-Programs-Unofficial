// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

// solhint-disable no-console, gas-custom-errors

import {Script, console2 as console} from "forge-std/Script.sol";

import {stdToml} from "forge-std/StdToml.sol";
import {ProxyAdmin} from "@openzeppelin/contracts-v4/proxy/transparent/ProxyAdmin.sol";
import {SafeCast} from "@openzeppelin/contracts-v4/utils/math/SafeCast.sol";

import {ITransparentUpgradeableProxy} from "@openzeppelin/contracts-v4/proxy/transparent/TransparentUpgradeableProxy.sol";
import {Utils} from "../../utils/Utils.sol";
import {StateTransitionDeployedAddresses, ChainCreationParamsConfig, ZkChainAddresses} from "../../utils/Types.sol";
import {IL1Bridgehub} from "contracts/core/bridgehub/IL1Bridgehub.sol";

import {L1Bridgehub} from "contracts/core/bridgehub/L1Bridgehub.sol";

import {IAdmin} from "contracts/state-transition/chain-interfaces/IAdmin.sol";
import {SemVer} from "contracts/common/libraries/SemVer.sol";
import {IChainTypeManager} from "contracts/state-transition/IChainTypeManager.sol";
import {ChainTypeManagerBase} from "contracts/state-transition/ChainTypeManagerBase.sol";
import {Diamond} from "contracts/state-transition/libraries/Diamond.sol";
import {IL2ContractDeployer} from "contracts/common/interfaces/IL2ContractDeployer.sol";

import {Governance} from "contracts/governance/Governance.sol";

import {Call} from "contracts/governance/Common.sol";
import {IZKChain} from "contracts/state-transition/chain-interfaces/IZKChain.sol";

import {UpgradeStageValidator} from "contracts/upgrades/UpgradeStageValidator.sol";
import {CTMDeployedAddresses} from "../../ctm/DeployCTMUtils.s.sol";

import {BytecodePublisher, PublishFactoryDepsResult} from "../../utils/bytecode/BytecodePublisher.s.sol";
import {L2ContractHelper} from "contracts/common/l2-helpers/L2ContractHelper.sol";
import {CoreContract} from "../../ecosystem/CoreContract.sol";
import {CoreOnGatewayHelper} from "../../ecosystem/CoreOnGatewayHelper.sol";
import {BytecodesSupplier} from "contracts/upgrades/BytecodesSupplier.sol";
import {GovernanceUpgradeTimer} from "contracts/upgrades/GovernanceUpgradeTimer.sol";
import {IChainAssetHandlerBase} from "contracts/core/chain-asset-handler/IChainAssetHandler.sol";
import {RollupDAManager} from "contracts/state-transition/data-availability/RollupDAManager.sol";
import {FixedForceDeploymentsData} from "contracts/state-transition/l2-deps/IL2GenesisUpgrade.sol";
import {IValidatorTimelock} from "contracts/state-transition/validators/interfaces/IValidatorTimelock.sol";

import {AddressIntrospector} from "../../utils/AddressIntrospector.sol";
import {DefaultL2UpgradeStrategy} from "./DefaultL2UpgradeStrategy.sol";
import {ICTMUpgrade} from "contracts/script-interfaces/ICTMUpgrade.sol";
import {CTMUpgradeParams} from "./UpgradeParams.sol";
import {CTMContract, DeployCTML1OrGateway} from "../../ctm/DeployCTML1OrGateway.sol";
import {UpgradeHelperLib} from "./UpgradeHelperLib.sol";
import {UpgradeUtils} from "./UpgradeUtils.sol";
import {IOwnable} from "contracts/common/interfaces/IOwnable.sol";

interface IAdminPreV31 {
    function upgradeChainFromVersion(uint256 _protocolVersion, Diamond.DiamondCutData calldata _cutData) external;
}

/// @notice Script used for default CTM upgrade flow. Should be run after Ecosystem upgrade
/// @dev For more complex upgrades, this script can be inherited and its functionality overridden if needed.
contract DefaultCTMUpgrade is Script, DefaultL2UpgradeStrategy, ICTMUpgrade {
    using stdToml for string;

    uint256 internal constant ERA_TEST_CREATE_CHAIN_ID = 555;
    uint256 internal constant ZKSYNC_OS_TEST_CREATE_CHAIN_ID = 556;

    // solhint-disable-next-line gas-struct-packing
    struct UpgradeDeployedAddresses {
        address upgradeTimer;
        address upgradeStageValidator;
    }

    // solhint-disable-next-line gas-struct-packing
    struct AdditionalConfig {
        address ctm;
        uint256 oldProtocolVersion;
        address ecosystemAdminAddress;
        uint256 governanceUpgradeTimerInitialDelay;
        bool hasPreV32IntrospectionOverride;
        bool usePreV32IntrospectionOverride;
    }

    // solhint-disable-next-line gas-struct-packing
    struct GatewayConfig {
        uint256 chainId;
    }

    // solhint-disable-next-line gas-struct-packing
    struct NewlyGeneratedData {
        bytes diamondCutData;
        bytes upgradeCutData;
    }

    /// @notice Internal state of the upgrade script
    struct EcosystemUpgradeConfig {
        bool initialized;
        bool fixedForceDeploymentsDataGenerated;
        bool upgradeCutPrepared;
        bool factoryDepsPublished;
        // TODO set it based on version of the BRIDGEHUB before upgrade

        bool ecosystemContractsDeployed;
        string outputPath;
    }

    struct PermanentCTMConfig {
        bytes32 create2FactorySalt;
        address ctmProxy;
        address bytecodesSupplier;
        bool isZKsyncOS;
        /// @dev ZK token asset ID, used by `InteropCenter.initL2` for fixed-fee bundles.
        ///      MUST be non-zero — `InteropCenter.initL2` reverts otherwise, which would abort the
        ///      L2 upgrade transaction.
        bytes32 zkTokenAssetId;
        /// @dev Whether the CTM's verifier is the testnet one, which accepts unproven batches.
        ///      Supplied by the caller alongside `isZKsyncOS`; protocol-ops reads it from
        ///      `upgrade-envs/permanent-values/<env>.toml` (true for every env except mainnet).
        ///      Not introspected off the deployed verifier: only the *testnet* verifiers declare
        ///      `IS_TESTNET_VERIFIER`, so the call reverts on a production one, and probing for that
        ///      would need the try/catch this repo forbids.
        bool testnetVerifier;
    }

    // The output of the script
    NewlyGeneratedData internal newlyGeneratedData;
    UpgradeDeployedAddresses internal upgradeAddresses;
    EcosystemUpgradeConfig internal upgradeConfig;

    // Input for the script
    AdditionalConfig internal newConfig;
    GatewayConfig internal gatewayConfig;

    // Discovered addresses
    ZkChainAddresses internal discoveredEraZkChain;
    ZkChainAddresses internal upToDateZkChain;
    L1Bridgehub internal bridgehub;

    PublishFactoryDepsResult internal factoryDepsResult;

    function initializeWithArgs(
        address ctmProxy,
        address bytecodesSupplier,
        bool isZKsyncOS,
        address rollupDAManager,
        bytes32 create2FactorySalt,
        string memory newConfigPath,
        string memory _outputPath,
        address governance,
        bytes32 zkTokenAssetId,
        bool testnetVerifier
    ) public virtual {
        string memory root = vm.projectRoot();
        newConfigPath = string.concat(root, newConfigPath);
        initializeConfigFromArgs(
            ctmProxy,
            bytecodesSupplier,
            isZKsyncOS,
            rollupDAManager,
            create2FactorySalt,
            newConfigPath,
            governance,
            zkTokenAssetId,
            testnetVerifier
        );

        console.log("Initialized config from %s", newConfigPath);
        upgradeConfig.outputPath = string.concat(root, _outputPath);
        upgradeConfig.initialized = true;
    }

    function initializeConfig(
        ChainCreationParamsConfig memory chainCreationParams,
        PermanentCTMConfig memory permanentConfig,
        // Optional
        address governance
    ) public {
        // Only override the salt when explicitly provided (non-zero).
        // When zero, the script falls back to the CREATE2_FACTORY_SALT env var or built-in default.
        if (permanentConfig.create2FactorySalt != bytes32(0)) {
            setCreate2Salt(permanentConfig.create2FactorySalt);
        }
        config.l1ChainId = block.chainid;
        newConfig.ctm = permanentConfig.ctmProxy;

        // The supplier is read off the CTM's `L1_BYTECODES_SUPPLIER()` immutable during discovery, so the
        // permanent-values entry is informational for this path.
        setAddressesBasedOnCTM();
        config.isZKsyncOS = permanentConfig.isZKsyncOS;
        // Must be non-zero: `InteropCenter.initL2` reverts on a zero asset ID. It runs on the genesis path
        // of `performForceDeployedContractsInit` only, so this aborts the genesis of chains created from the
        // release rather than this upgrade — caught here so the misconfiguration surfaces during
        // preparation instead of at a chain's creation.
        require(permanentConfig.zkTokenAssetId != bytes32(0), "zkTokenAssetId must be non-zero");
        config.zkTokenAssetId = permanentConfig.zkTokenAssetId;
        config.contracts.chainCreationParams = chainCreationParams;

        if (governance != address(0)) {
            config.ownerAddress = governance;
        } else {
            config.ownerAddress = ctmAddresses.admin.governance;
        }
        newConfig.ecosystemAdminAddress = ctmAddresses.admin.governance;
        config.contracts.governanceSecurityCouncilAddress = Governance(payable(ctmAddresses.admin.governance))
            .securityCouncil();
        // config.contracts.governanceMinDelay = Governance(payable(ctmAddresses.admin.governance)).minDelay();
        config.contracts.validatorTimelockExecutionDelay = IValidatorTimelock(
            ctmAddresses.stateTransition.proxies.validatorTimelock
        ).executionDelay();
        // Declared per environment rather than introspected off the deployed verifier: pre-v31 L1
        // state predates `ZKsyncOSTestnetVerifier.IS_TESTNET_VERIFIER`. Getting this wrong on
        // mainnet would install a verifier that accepts unproven batches, so it is a required key
        // with no default.
        config.testnetVerifier = permanentConfig.testnetVerifier;
        config.contracts.maxNumberOfChains = bridgehub.MAX_NUMBER_OF_ZK_CHAINS();
    }

    function initializeConfigFromArgs(
        address ctmProxy,
        address bytecodesSupplier,
        bool isZKsyncOS,
        address rollupDAManager,
        bytes32 create2FactorySalt,
        string memory newConfigPath,
        address governance,
        bytes32 zkTokenAssetId,
        bool testnetVerifier
    ) internal virtual {
        string memory toml = vm.readFile(newConfigPath);

        if (toml.keyExists("$.era_chain_id")) {
            config.eraChainId = toml.readUint("$.era_chain_id");
        }

        PermanentCTMConfig memory permanentConfig = PermanentCTMConfig({
            ctmProxy: ctmProxy,
            bytecodesSupplier: bytecodesSupplier,
            isZKsyncOS: isZKsyncOS,
            create2FactorySalt: create2FactorySalt,
            zkTokenAssetId: zkTokenAssetId,
            testnetVerifier: testnetVerifier
        });
        // Set config.isZKsyncOS before getChainCreationParamsConfig.
        config.isZKsyncOS = isZKsyncOS;
        ChainCreationParamsConfig memory chainCreationParams = getChainCreationParamsConfig(
            Utils.genesisConfigPath(isZKsyncOS)
        );

        // Optional override for pre-v32 introspection selection
        if (toml.keyExists("$.pre_v32_introspection")) {
            newConfig.hasPreV32IntrospectionOverride = true;
            newConfig.usePreV32IntrospectionOverride = toml.readBool("$.pre_v32_introspection");
        }

        initializeConfig(chainCreationParams, permanentConfig, governance);

        // Read governance upgrade timer initial delay from config
        if (toml.keyExists("$.governance_upgrade_timer_initial_delay")) {
            newConfig.governanceUpgradeTimerInitialDelay = toml.readUint("$.governance_upgrade_timer_initial_delay");
        }

        if (rollupDAManager != address(0)) {
            ctmAddresses.daAddresses.daContracts.rollupDAManager = rollupDAManager;
        }
    }

    /// @notice Full default upgrade preparation flow
    function prepareCTMUpgrade() public virtual {
        deployNewCTMContracts();
        console.log("CTM contracts are deployed!");
        publishBytecodes();
        console.log("Bytecodes published!");
        // TODO should we deploy state transition diamond facets here again?
        deployStateTransitionDiamondFacets();
        generateUpgradeData();
        console.log("Upgrade data generated!");
    }

    function deployUsedUpgradeContract() internal virtual returns (address) {
        return deploySimpleContract("DefaultUpgrade", false);
    }

    function deployGovernanceUpgradeTimer() internal virtual {
        upgradeAddresses.upgradeTimer = deploySimpleContract("GovernanceUpgradeTimer", false);
    }

    /// @notice Single-call entry point invoked by the protocol-ops CLI's `ecosystem
    ///         upgrade-prepare-all`, once per CTM proxy. Drives the whole CTM-side prepare phase
    ///         (deploy + bytecode publish + upgrade-cut generation + call serialization).
    function noGovernancePrepare(CTMUpgradeParams memory _params) public virtual {
        initializeWithArgs(
            _params.ctmProxy,
            _params.bytecodesSupplier,
            _params.isZKsyncOS,
            _params.rollupDAManager,
            _params.create2FactorySalt,
            _params.upgradeInputPath,
            _params.outputPath,
            _params.governance,
            _params.zkTokenAssetId,
            _params.testnetVerifier
        );
        prepareCTMUpgrade();
        prepareDefaultGovernanceCalls();
        prepareDefaultCTMAdminCalls();
        // Emit test-only calls (`test_create_chain`, `test_upgrade_chain`) into the CTM output TOML so
        // protocol-ops can lift them into merged `ecosystem.toml` for tx-simulator checks.
        prepareDefaultTestUpgradeCalls();
    }

    /// @notice Deploy everything that should be deployed.
    /// @dev Every release refreshes the same CTM-side set, so it lives here; the per-chain upgrade
    ///      contract is release-specific and comes from {deployUsedUpgradeContract}.
    function deployNewCTMContracts() public virtual {
        (ctmAddresses.stateTransition.defaultUpgrade) = deployUsedUpgradeContract();
        (ctmAddresses.stateTransition.genesisUpgrade) = deploySimpleContract("L1GenesisUpgrade", false);

        deployVerifiers();

        deployEIP7702Checker();
        deployUpgradeStageValidator();
        deployGovernanceUpgradeTimer();

        // Both proxies were introduced by the v31 upgrade, so every ecosystem this release can upgrade
        // already has them: only their implementations are redeployed, and stage 1 points the discovered
        // proxies at them. Deploying fresh proxies would move the addresses the new CTM implementation is
        // constructed with, leaving each upgraded chain's `s.priorityModeInfo.permissionlessValidator`
        // (written at its v31 upgrade) pointing at the old validator while new chains get the new one.
        require(
            ctmAddresses.stateTransition.proxies.bytecodesSupplier != address(0),
            "CTM has no BytecodesSupplier registered; it is expected from v31 on"
        );
        require(
            ctmAddresses.stateTransition.proxies.permissionlessValidator != address(0),
            "CTM has no PermissionlessValidator registered; it is expected from v31 on"
        );
        ctmAddresses.stateTransition.implementations.bytecodesSupplier = deploySimpleContract(
            "BytecodesSupplier",
            false
        );
        ctmAddresses.stateTransition.implementations.permissionlessValidator = deploySimpleContract(
            "PermissionlessValidator",
            false
        );

        // The constructor receives the new BytecodesSupplier and PermissionlessValidator proxy addresses.
        (, string memory ctmContractName) = DeployCTML1OrGateway.resolve(
            config.isZKsyncOS,
            CTMContract.ChainTypeManager
        );
        console.log("Deploying ChainTypeManager:", ctmContractName);
        ctmAddresses.stateTransition.implementations.chainTypeManager = deploySimpleContract(ctmContractName, false);

        ctmAddresses.stateTransition.implementations.serverNotifier = deploySimpleContract("ServerNotifier", false);

        // Deploy `MultisigCommitter` (a superset of ValidatorTimelock) as the default validator impl so the
        // upgrade does NOT downgrade proxies that already run a MultisigCommitter.
        ctmAddresses.stateTransition.implementations.validatorTimelock = deploySimpleContract(
            "MultisigCommitter",
            false
        );

        deployStateTransitionDiamondFacets();
    }

    /// @notice Extension point for a release that needs extra `[state_transition]` output keys.
    /// @dev Empty by default; a release that deploys something of its own serializes it here.
    function serializeVersionSpecificStateTransition() internal virtual {}

    /// @notice Extension point for a release that needs stage-1 calls no other release does.
    /// @dev Empty by design. Nothing in the default flow is version specific: anything that will also
    ///      apply to v34 and beyond belongs in the generic sections (see {prepareUpgradeCTMCalls}),
    ///      and anything that genuinely cannot belongs in that release's own script.
    function prepareVersionSpecificStage1GovernanceCallsL1() public virtual returns (Call[] memory calls) {}

    function deployUpgradeSpecificContractsL1() internal virtual {
        // Empty by default.
    }

    /// @notice Generate data required for the upgrade
    function generateUpgradeData() public virtual {
        require(upgradeConfig.initialized, "Not initialized");
        // TODO Return the require after getting the version from bridgehub
        //        require(upgradeConfig.ecosystemContractsDeployed, "Ecosystem contracts not deployed");

        // Important, this must come after the initializeExpectedL2Addresses
        getFixedForceDeploymentsData();
        console.log("Generated fixed force deployments data");
        Diamond.DiamondCutData memory diamondCut = getChainCreationDiamondCutData(ctmAddresses.stateTransition);
        // TODO probably don't need to assign it to diamondCutData
        config.contracts.diamondCutData = abi.encode(diamondCut);
        newlyGeneratedData.diamondCutData = config.contracts.diamondCutData;
        console.log("Prepared diamond cut data");
        Diamond.DiamondCutData memory upgradeCutData = generateUpgradeCutDataFromLocalConfig(
            ctmAddresses.stateTransition
        );
        newlyGeneratedData.upgradeCutData = abi.encode(upgradeCutData);
        upgradeConfig.upgradeCutPrepared = true;
        console.log("UpgradeCutGenerated");
        saveOutput(upgradeConfig.outputPath);
    }

    function generateUpgradeCutDataFromLocalConfig(
        StateTransitionDeployedAddresses memory _stateTransition
    ) public virtual returns (Diamond.DiamondCutData memory upgradeCutData) {
        upgradeCutData = generateUpgradeCutData(
            _stateTransition,
            config.contracts.chainCreationParams,
            config.l1ChainId,
            config.ownerAddress,
            factoryDepsResult,
            upToDateZkChain.zkChainProxy
        );
    }

    function getOwnerAddress() public virtual returns (address) {
        return config.ownerAddress;
    }

    function setNewProtocolVersion(uint256 _protocolVersion) public virtual {
        config.contracts.chainCreationParams.latestProtocolVersion = _protocolVersion;
    }

    function getNewProtocolVersion() public view virtual returns (uint256) {
        return config.contracts.chainCreationParams.latestProtocolVersion;
    }

    function getOldProtocolVersion() public view virtual returns (uint256) {
        return newConfig.oldProtocolVersion;
    }

    function getBridgehubAdmin() public virtual returns (address admin) {
        return coreAddresses.shared.bridgehubAdmin;
    }

    function getGatewayConfig() public virtual returns (GatewayConfig memory) {
        return gatewayConfig;
    }

    function getGovernanceUpgradeTimerInitialDelay() public view virtual returns (uint256) {
        return newConfig.governanceUpgradeTimerInitialDelay;
    }

    function getTestnetVerifier() public view virtual returns (bool) {
        return config.testnetVerifier;
    }

    /// @notice This function is meant to only be used in tests
    function prepareCreateNewChainCall(uint256 chainId) public view virtual returns (Call[] memory result) {
        require(coreAddresses.bridgehub.proxies.bridgehub != address(0), "bridgehubProxyAddress is zero in newConfig");

        bytes32 newChainAssetId = L1Bridgehub(coreAddresses.bridgehub.proxies.bridgehub).baseTokenAssetId(
            upToDateZkChain.chainId
        );
        result = new Call[](1);
        result[0] = Call({
            target: coreAddresses.bridgehub.proxies.bridgehub,
            value: 0,
            data: abi.encodeCall(
                IL1Bridgehub.createNewChain,
                (
                    chainId,
                    ctmAddresses.stateTransition.proxies.chainTypeManager,
                    newChainAssetId,
                    5,
                    msg.sender,
                    abi.encode(newlyGeneratedData.diamondCutData, generatedData.forceDeploymentsData),
                    new bytes[](0)
                )
            )
        });
    }

    function setAddressesBasedOnCTM() internal virtual {
        address ctm = newConfig.ctm;

        // Verify CTM contract exists
        require(ctm.code.length > 0, "CTM contract does not exist at specified address");

        // CTM exists - get bridgehub and determine which introspection to use
        address bridgehubAddr = ChainTypeManagerBase(ctm).BRIDGE_HUB();
        bridgehub = L1Bridgehub(bridgehubAddr);

        bool preV32Ecosystem;
        if (newConfig.hasPreV32IntrospectionOverride) {
            preV32Ecosystem = newConfig.usePreV32IntrospectionOverride;
        } else if (!AddressIntrospector.hasRegisteredChains(bridgehubAddr)) {
            // A chainless ecosystem has no protocol version to inspect. It cannot have been upgraded into
            // existence either, so it was deployed from scratch with the current contracts.
            preV32Ecosystem = false;
        } else {
            preV32Ecosystem = AddressIntrospector.shouldUsePreV32Introspection(bridgehubAddr);
        }

        if (preV32Ecosystem) {
            ctmAddresses = AddressIntrospector.getCTMAddressesV31(ctm, config.isZKsyncOS);
            coreAddresses = AddressIntrospector.getCoreDeployedAddressesV31(bridgehubAddr);
        } else {
            ctmAddresses = AddressIntrospector.getCTMAddresses(ChainTypeManagerBase(ctm));
            coreAddresses = AddressIntrospector.getCoreDeployedAddresses(bridgehubAddr);
        }

        config.ownerAddress = ctmAddresses.admin.governance;
        config.eraChainId = AddressIntrospector.getEraChainId(coreAddresses.bridges.proxies.l1AssetRouter);

        address eraChainAddress = bridgehub.getZKChain(config.eraChainId);
        if (eraChainAddress != address(0)) {
            // ERA chain exists, discover its addresses
            discoveredEraZkChain = AddressIntrospector.getZkChainAddresses(IZKChain(eraChainAddress));
            ctmAddresses.daAddresses.daContracts.rollupSLDAValidator = discoveredEraZkChain.l1DAValidator;
        } else {
            // ERA chain doesn't exist yet (fresh deployment), use up-to-date addresses
            console.log("ERA chain not found in bridgehub, using up-to-date addresses");
        }

        upToDateZkChain = AddressIntrospector.getUptoDateZkChainAddresses(ChainTypeManagerBase(ctm));

        uint256 ctmProtocolVersion = IChainTypeManager(ctm).protocolVersion();
        newConfig.oldProtocolVersion = ctmProtocolVersion;
        require(
            ctmProtocolVersion != getNewProtocolVersion(),
            "The new protocol version is already present on the ChainTypeManager"
        );
    }

    function getFixedForceDeploymentsData() internal override returns (FixedForceDeploymentsData memory data) {
        if (upgradeConfig.fixedForceDeploymentsDataGenerated) {
            return abi.decode(generatedData.forceDeploymentsData, (FixedForceDeploymentsData));
        }

        require(config.ownerAddress != address(0), "owner not set");

        data = _buildForceDeploymentsData(config.ownerAddress);
        bytes memory encodedData = abi.encode(data);
        generatedData.forceDeploymentsData = encodedData;
        upgradeConfig.fixedForceDeploymentsDataGenerated = true;
    }

    function getUpgradeAddedFacetCuts(
        StateTransitionDeployedAddresses memory stateTransition
    ) internal virtual returns (Diamond.FacetCut[] memory facetCuts) {
        return getChainCreationFacetCuts(stateTransition);
    }

    /////////////////////////// Blockchain interactions ////////////////////////////

    bool skipFactoryDepsCheck = false;

    function setSkipFactoryDepsCheck_TestOnly(bool _skipFactoryDepsCheck) public virtual {
        skipFactoryDepsCheck = _skipFactoryDepsCheck;
    }

    function publishBytecodes() public virtual {
        bytes[] memory allDeps = CoreOnGatewayHelper.getFullListOfFactoryDependencies(
            config.isZKsyncOS,
            getAdditionalFactoryDependencyContracts()
        );
        BytecodesSupplier supplier = BytecodesSupplier(ctmAddresses.stateTransition.proxies.bytecodesSupplier);

        PublishFactoryDepsResult memory result = BytecodePublisher.publishAndProcessFactoryDeps(
            config.isZKsyncOS,
            supplier,
            allDeps
        );

        // Era-only invariant: factoryDepsHashes[0..3] == (bootloader,
        // defaultAA, evmEmulator). ZKsyncOS has none of these concepts —
        // `chainCreationParams.{bootloader,defaultAA,evmEmulator}Hash` are
        // zero and the factoryDepsHashes describe a different, smaller set
        // of contracts, so indexing [1]/[2] would go out of bounds.
        if (!config.isZKsyncOS && result.factoryDepsHashes.length > 0) {
            console.logBytes32(config.contracts.chainCreationParams.bootloaderHash);
            console.log(result.factoryDepsHashes[0]);
            console.logBytes32(config.contracts.chainCreationParams.defaultAAHash);
            console.log(result.factoryDepsHashes[1]);
            console.logBytes32(config.contracts.chainCreationParams.evmEmulatorHash);
            console.log(result.factoryDepsHashes[2]);

            if (!skipFactoryDepsCheck) {
                require(
                    bytes32(result.factoryDepsHashes[0]) == config.contracts.chainCreationParams.bootloaderHash,
                    "bootloader hash factory dep mismatch"
                );
                require(
                    bytes32(result.factoryDepsHashes[1]) == config.contracts.chainCreationParams.defaultAAHash,
                    "default aa hash factory dep mismatch"
                );
                require(
                    bytes32(result.factoryDepsHashes[2]) == config.contracts.chainCreationParams.evmEmulatorHash,
                    "EVM emulator hash factory dep mismatch"
                );
            }
        }

        factoryDepsResult = result;
        upgradeConfig.factoryDepsPublished = true;
    }

    ////////////////////////////// Preparing calls /////////////////////////////////

    function prepareDefaultGovernanceCalls()
        public
        virtual
        returns (Call[] memory stage0Calls, Call[] memory stage1Calls, Call[] memory stage2Calls)
    {
        // Default upgrade is done it 3 stages:
        // 0. Pause migration to/from Gateway, other stage 0 calls.
        // 1. Perform upgrade
        // 2. Unpause migration to/from Gateway
        stage0Calls = prepareStage0GovernanceCalls();
        vm.serializeBytes("governance_calls", "stage0_calls", abi.encode(stage0Calls));
        stage1Calls = prepareStage1GovernanceCalls();
        vm.serializeBytes("governance_calls", "stage1_calls", abi.encode(stage1Calls));
        stage2Calls = prepareStage2GovernanceCalls();

        string memory governanceCallsSerialized = vm.serializeBytes(
            "governance_calls",
            "stage2_calls",
            abi.encode(stage2Calls)
        );

        vm.writeToml(governanceCallsSerialized, upgradeConfig.outputPath, ".governance_calls");
    }

    function prepareDefaultCTMAdminCalls() public virtual returns (Call[] memory calls) {
        Call[][] memory allCalls = new Call[][](1);
        allCalls[0] = prepareUpgradeServerNotifierCall();
        calls = UpgradeUtils.mergeCallsArray(allCalls);

        address chainAdmin = IOwnable(calls[0].target).owner();
        address chainAdminOwner = IOwnable(chainAdmin).owner();
        vm.serializeAddress("ctm_admin_calls", "chain_admin", chainAdmin);
        vm.serializeAddress("ctm_admin_calls", "chain_admin_owner", chainAdminOwner);

        string memory ctmAdminCallsSerialized = vm.serializeBytes(
            "ctm_admin_calls",
            "server_notifier_upgrade",
            abi.encode(calls)
        );

        vm.writeToml(ctmAdminCallsSerialized, upgradeConfig.outputPath, ".ctm_admin_calls");
    }

    /// @notice Whether to emit the `test_upgrade_chain` smoke call into `[test_upgrade_calls]`.
    /// @dev A release whose per-chain upgrade needs preconditions the artifact cannot express —
    ///      v33 requires a recorded priority-op lower bound and an upgrade timestamp — should not
    ///      pretend a single generated call covers it. Turning this off keeps the artifact honest;
    ///      the per-chain upgrade is then produced by `protocol_ops chain upgrade`, which emits the
    ///      real bundle, and the simulator scenario acknowledges the absence explicitly.
    function TESTONLY_emitsTestUpgradeChainCall() internal view virtual returns (bool) {
        return true;
    }

    function prepareDefaultTestUpgradeCalls() public virtual {
        if (TESTONLY_emitsTestUpgradeChainCall()) {
            (Call[] memory testUpgradeChainCall, address ZKChainAdmin) = TESTONLY_prepareTestUpgradeChainCall();
            vm.serializeAddress("test_upgrade_calls", "test_upgrade_chain_caller", ZKChainAdmin);
            vm.serializeBytes("test_upgrade_calls", "test_upgrade_chain", abi.encode(testUpgradeChainCall));
        }
        (Call[] memory testCreateChainCall, address bridgehubAdmin) = TESTONLY_prepareCreateChainCall();
        vm.serializeAddress("test_upgrade_calls", "test_create_chain_caller", bridgehubAdmin);

        string memory testUpgradeCallsSerialized = vm.serializeBytes(
            "test_upgrade_calls",
            "test_create_chain",
            abi.encode(testCreateChainCall)
        );

        vm.writeToml(testUpgradeCallsSerialized, upgradeConfig.outputPath, ".test_upgrade_calls");
    }

    function prepareUpgradeServerNotifierCall() public virtual returns (Call[] memory calls) {
        address serverNotifierProxyAdmin = Utils.getProxyAdminAddress(
            ctmAddresses.stateTransition.proxies.serverNotifier
        );

        Call memory call = Call({
            target: serverNotifierProxyAdmin,
            data: abi.encodeCall(
                ProxyAdmin.upgrade,
                (
                    ITransparentUpgradeableProxy(payable(ctmAddresses.stateTransition.proxies.serverNotifier)),
                    ctmAddresses.stateTransition.implementations.serverNotifier
                )
            ),
            value: 0
        });

        calls = new Call[](1);
        calls[0] = call;
    }

    /// @notice The zeroth step of upgrade. By default it just stops gateway migrations
    function prepareStage0GovernanceCalls() public virtual returns (Call[] memory calls) {
        Call[][] memory allCalls = new Call[][](2);

        allCalls[0] = prepareVersionSpecificStage0GovernanceCallsL1();
        allCalls[1] = prepareGovernanceUpgradeTimerStartCall();

        calls = UpgradeUtils.mergeCallsArray(allCalls);
    }

    /// @notice The first step of upgrade. It upgrades the proxies and sets the new version upgrade
    function prepareStage1GovernanceCalls() public virtual returns (Call[] memory calls) {
        Call[][] memory allCalls = new Call[][](8);

        allCalls[0] = prepareGovernanceUpgradeTimerCheckCall();
        allCalls[1] = prepareCheckMigrationsPausedCalls();
        console.log("prepareStage1GovernanceCalls: prepareUpgradeProxiesCalls");
        allCalls[2] = prepareUpgradeCTMCalls();
        console.log("prepareStage1GovernanceCalls: prepareSetDefaultUpgradeCall");
        allCalls[3] = prepareSetDefaultUpgradeCall();
        console.log("prepareStage1GovernanceCalls: prepareNewChainCreationParamsCall");
        allCalls[4] = prepareNewChainCreationParamsCall();
        console.log("prepareStage1GovernanceCalls: provideSetNewVersionUpgradeCall");
        allCalls[5] = provideSetNewVersionUpgradeCall();
        console.log("prepareStage1GovernanceCalls: prepareDAValidatorCall");
        allCalls[6] = prepareDAValidatorCall();
        console.log("prepareStage1GovernanceCalls: prepareGatewaySpecificStage1GovernanceCalls");
        allCalls[7] = prepareVersionSpecificStage1GovernanceCallsL1();
        calls = UpgradeUtils.mergeCallsArray(allCalls);
    }

    /// @notice The second step of upgrade. By default it unpauses migrations.
    function prepareStage2GovernanceCalls() public virtual returns (Call[] memory calls) {
        Call[][] memory allCalls = new Call[][](3);

        allCalls[0] = prepareCheckUpgradeIsPresent();
        allCalls[1] = prepareVersionSpecificStage2GovernanceCallsL1();
        allCalls[2] = prepareCheckMigrationsUnpausedCalls();

        calls = UpgradeUtils.mergeCallsArray(allCalls);
    }

    function prepareVersionSpecificStage0GovernanceCallsL1() public virtual returns (Call[] memory calls) {
        // Empty by default.
        return calls;
    }

    function prepareVersionSpecificStage2GovernanceCallsL1() public virtual returns (Call[] memory calls) {
        // Empty by default.
        return calls;
    }

    function provideSetNewVersionUpgradeCall() public virtual returns (Call[] memory calls) {
        require(
            ctmAddresses.stateTransition.proxies.chainTypeManager != address(0),
            "stateTransitionManagerAddress is zero in newConfig"
        );

        // Just retrieved it from the contract
        uint256 previousProtocolVersion = getOldProtocolVersion();
        uint256 deadline = UpgradeHelperLib.getOldProtocolDeadline();
        uint256 newProtocolVersion = getNewProtocolVersion();
        Diamond.DiamondCutData memory upgradeCut = abi.decode(
            newlyGeneratedData.upgradeCutData,
            (Diamond.DiamondCutData)
        );
        Call memory ctmCall = Call({
            target: ctmAddresses.stateTransition.proxies.chainTypeManager,
            data: abi.encodeCall(
                IChainTypeManager.setNewVersionUpgrade,
                (
                    upgradeCut,
                    previousProtocolVersion,
                    deadline,
                    newProtocolVersion,
                    ctmAddresses.stateTransition.verifiers.verifier
                )
            ),
            value: 0
        });

        calls = new Call[](1);
        calls[0] = ctmCall;
    }

    function preparePauseGatewayMigrationsCall() public view virtual returns (Call[] memory result) {
        require(
            coreAddresses.bridgehub.proxies.chainAssetHandler != address(0),
            "chainAssetHandlerProxy is zero in newConfig"
        );

        result = new Call[](1);
        result[0] = Call({
            target: coreAddresses.bridgehub.proxies.chainAssetHandler,
            value: 0,
            data: abi.encodeCall(IChainAssetHandlerBase.pauseMigration, ())
        });
    }

    /// @notice Start the upgrade timer.
    function prepareGovernanceUpgradeTimerStartCall() public virtual returns (Call[] memory calls) {
        require(upgradeAddresses.upgradeTimer != address(0), "upgradeTimer is zero");
        calls = new Call[](1);

        calls[0] = Call({
            target: upgradeAddresses.upgradeTimer,
            data: abi.encodeCall(GovernanceUpgradeTimer.startTimer, ()),
            value: 0
        });
    }

    /// @notice Double checking that the deadline has passed.
    function prepareGovernanceUpgradeTimerCheckCall() public virtual returns (Call[] memory calls) {
        require(upgradeAddresses.upgradeTimer != address(0), "upgradeTimer is zero");
        calls = new Call[](1);

        calls[0] = Call({
            target: upgradeAddresses.upgradeTimer,
            // Double checking that the deadline has passed.
            data: abi.encodeCall(GovernanceUpgradeTimer.checkDeadline, ()),
            value: 0
        });
    }

    /// @notice Points the CTM at the upgrade contract deployed by this release, so that later upgrades that need
    /// no custom upgrade logic (e.g. verifier-only ones) can reuse it.
    /// @dev Must be executed after the CTM implementation upgrade, as `setDefaultUpgrade` is only present
    /// starting from v32.
    function prepareSetDefaultUpgradeCall() public virtual returns (Call[] memory calls) {
        require(
            ctmAddresses.stateTransition.proxies.chainTypeManager != address(0),
            "stateTransitionManagerAddress is zero in newConfig"
        );
        address storedDefaultUpgrade = getCtmStoredDefaultUpgrade();
        require(storedDefaultUpgrade != address(0), "defaultUpgrade is zero in newConfig");
        calls = new Call[](1);

        calls[0] = Call({
            target: ctmAddresses.stateTransition.proxies.chainTypeManager,
            data: abi.encodeCall(IChainTypeManager.setDefaultUpgrade, (storedDefaultUpgrade)),
            value: 0
        });
    }

    /// @notice The upgrade contract to leave stored on the CTM as its `defaultUpgrade`.
    /// @dev Zero means "same as the contract this release's cut delegates to", which is the normal
    ///      case. A release only sets this when its own cut is one-shot — see
    ///      {getCtmStoredDefaultUpgrade}.
    address internal ctmStoredDefaultUpgrade;

    /// @notice The upgrade contract to leave stored on the CTM as its `defaultUpgrade`.
    /// @dev Defaults to this release's own upgrade contract, which is correct whenever that
    ///      contract carries no one-off logic. A release whose cut *does* carry one-off logic sets
    ///      {ctmStoredDefaultUpgrade} to a separately deployed generic contract instead:
    ///      `setDefaultUpgrade` is what *later* upgrades reuse when they need no custom logic of
    ///      their own, so storing a one-shot contract there would make every such upgrade revert
    ///      on preconditions that only ever held during this release. v33 is such a release.
    function getCtmStoredDefaultUpgrade() internal virtual returns (address) {
        return
            ctmStoredDefaultUpgrade == address(0)
                ? ctmAddresses.stateTransition.defaultUpgrade
                : ctmStoredDefaultUpgrade;
    }

    function prepareNewChainCreationParamsCall() public virtual returns (Call[] memory calls) {
        require(
            ctmAddresses.stateTransition.proxies.chainTypeManager != address(0),
            "stateTransitionManagerAddress is zero in newConfig"
        );
        calls = new Call[](1);

        calls[0] = Call({
            target: ctmAddresses.stateTransition.proxies.chainTypeManager,
            data: abi.encodeCall(
                IChainTypeManager.setChainCreationParams,
                (getChainCreationParams(ctmAddresses.stateTransition))
            ),
            value: 0
        });
    }

    /// @notice Checks to make sure that migrations are paused
    function prepareCheckMigrationsPausedCalls() public virtual returns (Call[] memory calls) {
        require(upgradeAddresses.upgradeStageValidator != address(0), "upgradeStageValidator is zero");
        calls = new Call[](1);

        calls[0] = Call({
            target: upgradeAddresses.upgradeStageValidator,
            // Double checking migrations are paused
            data: abi.encodeCall(UpgradeStageValidator.checkMigrationsPaused, ()),
            value: 0
        });
    }

    /// @notice Checks to make sure that migrations are paused
    function prepareCheckMigrationsUnpausedCalls() public virtual returns (Call[] memory calls) {
        require(upgradeAddresses.upgradeStageValidator != address(0), "upgradeStageValidator is zero");
        calls = new Call[](1);

        calls[0] = Call({
            target: upgradeAddresses.upgradeStageValidator,
            // Double checking migrations are unpaused
            data: abi.encodeCall(UpgradeStageValidator.checkMigrationsUnpaused, ()),
            value: 0
        });
    }

    /// @notice Checks to make sure that the upgrade has happened.
    function prepareCheckUpgradeIsPresent() public virtual returns (Call[] memory calls) {
        require(upgradeAddresses.upgradeStageValidator != address(0), "upgradeStageValidator is zero");
        calls = new Call[](1);

        calls[0] = Call({
            target: upgradeAddresses.upgradeStageValidator,
            // Double checking the presence of the upgrade
            data: abi.encodeCall(UpgradeStageValidator.checkProtocolUpgradePresence, ()),
            value: 0
        });
    }

    /// @notice Update implementations in proxies
    /// @notice Point every CTM-side proxy this flow keeps at its freshly deployed implementation.
    /// @dev Plain `ProxyAdmin.upgrade` (not `upgradeAndCall`) throughout: the new implementations are
    ///      deployed with no reinitializer call. For the validator timelock in particular, proxies already
    ///      running a `MultisigCommitter` are at `_initialized=2` with their multisig storage intact, so the
    ///      swap just restores the multisig code; calling `reinitializeV2()` again would revert "already
    ///      initialized".
    function prepareUpgradeCTMCalls() public virtual returns (Call[] memory calls) {
        calls = new Call[](4);

        calls[0] = _buildProxyUpgrade(
            ctmAddresses.stateTransition.proxies.chainTypeManager,
            ctmAddresses.stateTransition.implementations.chainTypeManager,
            "chainTypeManager"
        );
        calls[1] = _buildProxyUpgrade(
            ctmAddresses.stateTransition.proxies.validatorTimelock,
            ctmAddresses.stateTransition.implementations.validatorTimelock,
            "validatorTimelock"
        );
        calls[2] = _buildProxyUpgrade(
            ctmAddresses.stateTransition.proxies.bytecodesSupplier,
            ctmAddresses.stateTransition.implementations.bytecodesSupplier,
            "bytecodesSupplier"
        );
        calls[3] = _buildProxyUpgrade(
            ctmAddresses.stateTransition.proxies.permissionlessValidator,
            ctmAddresses.stateTransition.implementations.permissionlessValidator,
            "permissionlessValidator"
        );
    }

    /// @dev Resolves the `ProxyAdmin` per proxy. That is required for the three kept proxies, which
    ///      have their own admin instances, and equally correct for the CTM proxy, whose admin is the
    ///      CTM-wide one — so there is no need for a second variant that hard-codes it.
    function _buildProxyUpgrade(
        address _proxy,
        address _implementation,
        string memory _name
    ) private view returns (Call memory) {
        require(_proxy != address(0), string.concat("ctm upgrade: ", _name, " proxy not set"));
        require(_implementation != address(0), string.concat("ctm upgrade: ", _name, " impl not deployed"));

        return
            Call({
                target: Utils.getProxyAdminAddress(_proxy),
                data: abi.encodeCall(
                    ProxyAdmin.upgrade,
                    (ITransparentUpgradeableProxy(payable(_proxy)), _implementation)
                ),
                value: 0
            });
    }

    /// @notice Additional calls to newConfigure contracts
    function prepareDAValidatorCall() public virtual returns (Call[] memory calls) {
        calls = new Call[](0);

        /// kl todo add back, figure out how we deploy/upgrade the rollup da manager
        // calls[0] = Call({
        //     target: nonDisoverable.rollupDAManager,
        //     data: abi.encodeCall(
        //         RollupDAManager.updateDAPair,
        //         (ctmAddresses.stateTransition.daAddresses.daContracts.rollupSLDAValidator, getRollupL2DACommitmentScheme(), true)
        //     ),
        //     value: 0
        // });
    }

    function getAddresses() public view override returns (CTMDeployedAddresses memory) {
        return ctmAddresses;
    }

    /// @notice Tests that it is possible to upgrade a chain to the new version
    function TESTONLY_prepareTestUpgradeChainCall() private returns (Call[] memory calls, address admin) {
        address chainDiamondProxyAddress = L1Bridgehub(coreAddresses.bridgehub.proxies.bridgehub).getZKChain(
            upToDateZkChain.chainId
        );
        uint256 oldProtocolVersion = getOldProtocolVersion();
        Diamond.DiamondCutData memory upgradeCutData = generateUpgradeCutDataFromLocalConfig(
            ctmAddresses.stateTransition
        );

        admin = IZKChain(chainDiamondProxyAddress).getAdmin();

        (, uint32 oldProtocolVersionMinor, ) = SemVer.unpackSemVer(SafeCast.toUint96(oldProtocolVersion));
        // Pre-v31 chain diamonds only expose the legacy 2-arg selector; the v31 selector reverts with "F".
        bytes memory upgradeCallData = oldProtocolVersionMinor < 31
            ? abi.encodeCall(IAdminPreV31.upgradeChainFromVersion, (oldProtocolVersion, upgradeCutData))
            : abi.encodeCall(
                IAdmin.upgradeChainFromVersion,
                (chainDiamondProxyAddress, oldProtocolVersion, upgradeCutData)
            );

        calls = new Call[](1);
        calls[0] = Call({target: chainDiamondProxyAddress, data: upgradeCallData, value: 0});
    }

    /// @notice Tests that it is possible to create a new chain with the new version
    function getDefaultTestCreateChainId() public view virtual returns (uint256) {
        return config.isZKsyncOS ? ZKSYNC_OS_TEST_CREATE_CHAIN_ID : ERA_TEST_CREATE_CHAIN_ID;
    }

    function TESTONLY_prepareCreateChainCall() private returns (Call[] memory calls, address admin) {
        admin = getBridgehubAdmin();
        calls = new Call[](1);
        calls[0] = prepareCreateNewChainCall(getDefaultTestCreateChainId())[0];
    }

    function deployUpgradeStageValidator() internal {
        upgradeAddresses.upgradeStageValidator = deploySimpleContract("UpgradeStageValidator", false);
    }

    function getCreationCalldata(
        string memory contractName,
        bool isZKBytecode
    ) internal view virtual override returns (bytes memory) {
        require(!isZKBytecode, "ZK bytecodes are not supported in CTM upgrade");
        if (compareStrings(contractName, "UpgradeStageValidator")) {
            return abi.encode(ctmAddresses.stateTransition.proxies.chainTypeManager, getNewProtocolVersion());
        } else if (compareStrings(contractName, "GovernanceUpgradeTimer")) {
            uint256 initialDelay = newConfig.governanceUpgradeTimerInitialDelay;
            uint256 maxAdditionalDelay = 2 weeks;
            return abi.encode(initialDelay, maxAdditionalDelay, config.ownerAddress, newConfig.ecosystemAdminAddress);
        } else {
            return super.getCreationCalldata(contractName, isZKBytecode);
        }
    }

    function saveOutput(string memory outputPath) internal virtual override {
        // Serialize newly deployed state transition addresses
        vm.serializeAddress(
            "state_transition",
            "chain_type_manager_implementation_addr",
            ctmAddresses.stateTransition.implementations.chainTypeManager
        );
        vm.serializeAddress(
            "state_transition",
            "chain_type_manager_proxy",
            ctmAddresses.stateTransition.proxies.chainTypeManager
        );
        // Also save as state_transition_implementation_addr for backwards compatibility with zkstack CLI
        vm.serializeAddress(
            "state_transition",
            "state_transition_implementation_addr",
            ctmAddresses.stateTransition.implementations.chainTypeManager
        );
        vm.serializeAddress("state_transition", "verifier_addr", ctmAddresses.stateTransition.verifiers.verifier);
        vm.serializeAddress("state_transition", "admin_facet_addr", ctmAddresses.stateTransition.facets.adminFacet);
        vm.serializeAddress("state_transition", "mailbox_facet_addr", ctmAddresses.stateTransition.facets.mailboxFacet);
        vm.serializeAddress(
            "state_transition",
            "executor_facet_addr",
            ctmAddresses.stateTransition.facets.executorFacet
        );
        vm.serializeAddress("state_transition", "getters_facet_addr", ctmAddresses.stateTransition.facets.gettersFacet);
        vm.serializeAddress(
            "state_transition",
            "migrator_facet_addr",
            ctmAddresses.stateTransition.facets.migratorFacet
        );
        vm.serializeAddress(
            "state_transition",
            "committer_facet_addr",
            ctmAddresses.stateTransition.facets.committerFacet
        );
        vm.serializeAddress("state_transition", "diamond_init_addr", ctmAddresses.stateTransition.facets.diamondInit);
        vm.serializeAddress("state_transition", "genesis_upgrade_addr", ctmAddresses.stateTransition.genesisUpgrade);
        vm.serializeAddress(
            "state_transition",
            "verifier_fflonk_addr",
            ctmAddresses.stateTransition.verifiers.verifierFflonk
        );
        vm.serializeAddress(
            "state_transition",
            "verifier_plonk_addr",
            ctmAddresses.stateTransition.verifiers.verifierPlonk
        );
        vm.serializeAddress(
            "state_transition",
            "validator_timelock_implementation_addr",
            ctmAddresses.stateTransition.implementations.validatorTimelock
        );
        vm.serializeAddress(
            "state_transition",
            "validator_timelock_addr",
            ctmAddresses.stateTransition.proxies.validatorTimelock
        );
        vm.serializeAddress(
            "state_transition",
            "bytecodes_supplier_addr",
            ctmAddresses.stateTransition.proxies.bytecodesSupplier
        );
        vm.serializeAddress("state_transition", "eip7702_checker_addr", ctmAddresses.admin.eip7702Checker);
        vm.serializeAddress(
            "state_transition",
            "permissionless_validator_addr",
            ctmAddresses.stateTransition.proxies.permissionlessValidator
        );
        if (ctmAddresses.stateTransition.implementations.serverNotifier != address(0)) {
            vm.serializeAddress(
                "state_transition",
                "server_notifier_implementation_addr",
                ctmAddresses.stateTransition.implementations.serverNotifier
            );
        }
        // What the CTM ends up storing. Equal to `default_upgrade_addr` unless this release's
        // cut is one-shot, in which case the two deliberately differ.
        vm.serializeAddress("state_transition", "ctm_stored_default_upgrade_addr", getCtmStoredDefaultUpgrade());
        serializeVersionSpecificStateTransition();
        string memory stateTransition = vm.serializeAddress(
            "state_transition",
            "default_upgrade_addr",
            ctmAddresses.stateTransition.defaultUpgrade
        );

        // Serialize newly deployed upgrade addresses
        vm.serializeAddress("deployed_addresses", "chain_admin", discoveredEraZkChain.chainAdmin);
        vm.serializeAddress("deployed_addresses", "access_control_restriction_addr", address(0));
        vm.serializeAddress("deployed_addresses", "transparent_proxy_admin", ctmAddresses.admin.transparentProxyAdmin);
        vm.serializeAddress("deployed_addresses", "rollup_l1_da_validator_addr", discoveredEraZkChain.l1DAValidator);
        vm.serializeAddress("deployed_addresses", "validium_l1_da_validator_addr", address(0));
        vm.serializeAddress(
            "deployed_addresses",
            "l1_rollup_da_manager",
            ctmAddresses.daAddresses.daContracts.rollupDAManager
        );
        vm.serializeAddress("deployed_addresses", "upgrade_stage_validator", upgradeAddresses.upgradeStageValidator);

        string memory deployedAddresses = vm.serializeAddress(
            "deployed_addresses",
            "l1_governance_upgrade_timer",
            upgradeAddresses.upgradeTimer
        );

        vm.serializeAddress("admin", "timer_governance_addr", config.ownerAddress);
        string memory admin = vm.serializeAddress("admin", "ecosystem_admin_addr", newConfig.ecosystemAdminAddress);

        // Serialize generated upgrade data
        vm.serializeBytes("contracts_newConfig", "diamond_cut_data", newlyGeneratedData.diamondCutData);
        vm.serializeBytes("contracts_newConfig", "force_deployments_data", generatedData.forceDeploymentsData);

        // Serialize protocol version info (needed for upgrade)
        vm.serializeUint("contracts_newConfig", "new_protocol_version", getNewProtocolVersion());
        vm.serializeUint(
            "contracts_newConfig",
            "governance_upgrade_timer_initial_delay",
            newConfig.governanceUpgradeTimerInitialDelay
        );
        vm.serializeBool("contracts_newConfig", "is_testnet", config.testnetVerifier);
        string memory contractsConfig = vm.serializeUint(
            "contracts_newConfig",
            "old_protocol_version",
            newConfig.oldProtocolVersion
        );

        // Serialize root structure
        vm.serializeString("root", "deployed_addresses", deployedAddresses);
        vm.serializeString("root", "state_transition", stateTransition);
        vm.serializeString("root", "contracts_config", contractsConfig);
        vm.serializeString("root", "admin", admin);
        string memory toml = vm.serializeBytes("root", "chain_upgrade_diamond_cut", newlyGeneratedData.upgradeCutData);

        vm.writeToml(toml, outputPath);

        saveOutputVersionSpecific();
    }

    function saveOutputVersionSpecific() internal virtual {}

    function getCTMAddress() public view returns (address) {
        return newConfig.ctm;
    }

    function getChainUpgradeDiamondCutData() public view returns (bytes memory) {
        require(upgradeConfig.upgradeCutPrepared, "upgrade cut data not prepared");
        return newlyGeneratedData.upgradeCutData;
    }

    /// @dev Test-only: inject pre-computed upgrade cut data to avoid recomputing (memory optimization).
    function setChainUpgradeDiamondCutData_TestOnly(bytes memory _data) public {
        newlyGeneratedData.upgradeCutData = _data;
        upgradeConfig.upgradeCutPrepared = true;
    }

    /// @dev Test-only: inject pre-computed fixed force deployments data.
    function setFixedForceDeploymentsData_TestOnly(bytes memory _data) public {
        generatedData.forceDeploymentsData = _data;
        upgradeConfig.fixedForceDeploymentsDataGenerated = true;
    }

    /// @notice Returns the encoded FixedForceDeploymentsData bytes.
    function getEncodedFixedForceDeploymentsData() public view returns (bytes memory) {
        require(upgradeConfig.fixedForceDeploymentsDataGenerated, "force deployments data not generated");
        return generatedData.forceDeploymentsData;
    }

    ////////////////////////////// Misc utils /////////////////////////////////

    // add this to be excluded from coverage report
    function test() internal override {}
}
