// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Config} from "../../deploy-scripts/ecosystem/DeployL1CoreUtils.s.sol";
import {CoreDeployedAddresses} from "../../deploy-scripts/utils/Types.sol";

/// @title IDeployL1CoreContracts
/// @notice Interface for the L1 Core Contracts deployment script
interface IDeployL1CoreContracts {
    /// @notice Runs the deployment with default paths
    function run() external;

    /// @notice Same as `run`, with the input/output TOML paths (project-root
    /// relative) supplied by the caller instead of the conventional defaults.
    function runInner(string calldata inputPath, string calldata outputPath) external;

    /// @notice Runs the deployment for testing purposes
    /// @dev Accepts admin role after deployment for testing
    function runForTest() external;

    /// @notice Returns the deployed contract addresses
    /// @return The CoreDeployedAddresses struct containing all deployed addresses
    function getAddresses() external view returns (CoreDeployedAddresses memory);

    /// @notice Returns the deployment configuration
    /// @return The Config struct containing deployment parameters
    function getConfig() external view returns (Config memory);
}
