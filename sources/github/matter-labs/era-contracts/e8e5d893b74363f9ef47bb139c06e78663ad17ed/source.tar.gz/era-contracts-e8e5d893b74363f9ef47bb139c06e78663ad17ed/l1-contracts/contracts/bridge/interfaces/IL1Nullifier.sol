// SPDX-License-Identifier: MIT

pragma solidity 0.8.28;

import {IL1AssetRouter} from "../asset-router/IL1AssetRouter.sol";
import {IL1Bridgehub} from "../../core/bridgehub/IL1Bridgehub.sol";
import {IL1NativeTokenVault} from "../ntv/IL1NativeTokenVault.sol";
import {ConfirmTransferResultData} from "../../common/Messaging.sol";

/// @title L1 Nullifier contract interface
/// @author Matter Labs
/// @custom:security-contact security@matterlabs.dev
/// @notice Tracks initiated L1 -> L2 deposits so users can claim funds back if the L2 execution fails.
/// See {protocol-docs/bridging.md#l1nullifier-and-failed-deposit-recovery}.
interface IL1Nullifier {
    event BridgehubDepositFinalized(
        uint256 indexed chainId,
        bytes32 indexed txDataHash,
        bytes32 indexed l2DepositTxHash
    );

    function BRIDGE_HUB() external view returns (IL1Bridgehub);

    function l1AssetRouter() external view returns (IL1AssetRouter);

    function l1InteropHandler() external view returns (address);

    function depositHappened(uint256 _chainId, bytes32 _l2TxHash) external view returns (bytes32);

    /// @notice Records an initiated deposit (`depositHappened`), forwarded by the asset router as part of
    /// the Bridgehub's `requestL2TransactionTwoBridges` flow. Rejects duplicates.
    /// @param _chainId The chain ID of the ZK chain to which to confirm the deposit.
    /// @param _txDataHash The keccak256 hash of 0x01 || abi.encode(bytes32, bytes) to identify deposits.
    /// @param _txHash The hash of the L1->L2 transaction to confirm the deposit.
    function bridgehubConfirmL2TransactionForwarded(uint256 _chainId, bytes32 _txDataHash, bytes32 _txHash) external;

    function l1NativeTokenVault() external view returns (IL1NativeTokenVault);

    function setL1NativeTokenVault(IL1NativeTokenVault _nativeTokenVault) external;

    function setL1AssetRouter(address _l1AssetRouter) external;

    function setL1InteropHandler(address _l1InteropHandler) external;

    /// @notice Confirms the result of an initiated deposit (successful or failed) with a status proof,
    /// clears the recorded deposit and forwards the result to the asset router.
    /// @param _confirmTransferResultData The data to confirm the deposit result.
    function bridgeConfirmTransferResult(ConfirmTransferResultData calldata _confirmTransferResultData) external;

    /// @notice Withdraws funds from an initiated deposit that failed when finalizing on L2.
    /// @param _chainId The ZK chain id to which deposit was initiated.
    /// @param _depositSender The address of the entity that initiated the deposit.
    /// @param _assetId The unique identifier of the deposited L1 token.
    /// @param _assetData The encoded transfer data, which includes both the deposit amount and the address of the L2 receiver. Might include extra information.
    /// @param _l2TxHash The L2 transaction hash of the failed deposit finalization.
    /// @param _l2BatchNumber The L2 batch number where the deposit finalization was processed.
    /// @param _l2MessageIndex The position in the L2 logs Merkle tree of the l2Log that was sent with the message.
    /// @param _l2TxNumberInBatch The L2 transaction number in a batch, in which the log was sent.
    /// @param _merkleProof The Merkle proof of the processing L1 -> L2 transaction with deposit finalization.
    function bridgeRecoverFailedTransfer(
        uint256 _chainId,
        address _depositSender,
        bytes32 _assetId,
        bytes memory _assetData,
        bytes32 _l2TxHash,
        uint256 _l2BatchNumber,
        uint256 _l2MessageIndex,
        uint16 _l2TxNumberInBatch,
        bytes32[] calldata _merkleProof
    ) external;
}
