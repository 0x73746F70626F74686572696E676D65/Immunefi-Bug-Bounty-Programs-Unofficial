// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

// solhint-disable no-console, gas-custom-errors

import {Script, console2 as console} from "forge-std/Script.sol";
import {stdToml} from "forge-std/StdToml.sol";

import {IL1Bridgehub} from "contracts/core/bridgehub/IL1Bridgehub.sol";
import {BridgehubBase} from "contracts/core/bridgehub/BridgehubBase.sol";
import {IL1AssetRouter} from "contracts/bridge/asset-router/IL1AssetRouter.sol";
import {INativeTokenVaultBase} from "contracts/bridge/ntv/INativeTokenVaultBase.sol";
import {IL1Nullifier, L1Nullifier} from "contracts/bridge/L1Nullifier.sol";
import {IL1NativeTokenVault} from "contracts/bridge/ntv/IL1NativeTokenVault.sol";
import {ICTMDeploymentTracker} from "contracts/core/ctm-deployment/ICTMDeploymentTracker.sol";
import {IMessageRootBase} from "contracts/core/message-root/IMessageRoot.sol";
import {IOwnable} from "contracts/common/interfaces/IOwnable.sol";

import {L1Bridgehub} from "contracts/core/bridgehub/L1Bridgehub.sol";
import {L1ChainAssetHandler} from "contracts/core/chain-asset-handler/L1ChainAssetHandler.sol";
import {L1MessageRoot} from "contracts/core/message-root/L1MessageRoot.sol";
import {CTMDeploymentTracker} from "contracts/core/ctm-deployment/CTMDeploymentTracker.sol";
import {L1NativeTokenVault} from "contracts/bridge/ntv/L1NativeTokenVault.sol";
import {L1AssetRouter} from "contracts/bridge/asset-router/L1AssetRouter.sol";
import {BridgedStandardERC20} from "contracts/bridge/BridgedStandardERC20.sol";
import {ChainAdminOwnable} from "contracts/governance/ChainAdminOwnable.sol";

import {Config, CoreDeployedAddresses, DeployL1CoreUtils} from "./DeployL1CoreUtils.s.sol";
import {IDeployL1CoreContracts} from "contracts/script-interfaces/IDeployL1CoreContracts.sol";

contract DeployL1CoreContractsScript is Script, DeployL1CoreUtils, IDeployL1CoreContracts {
    using stdToml for string;

    function run() public virtual {
        console.log("Deploying L1 core contracts");

        runInner("/script-config/config-deploy-l1.toml", "/script-out/output-deploy-l1.toml");
    }

    function runForTest() public {
        _runFromEnv();

        // In the production environment, there will be a separate script dedicated to accepting the adminship
        // but for testing purposes we'll have to do it here.
        L1Bridgehub bridgehub = L1Bridgehub(coreAddresses.bridgehub.proxies.bridgehub);
        vm.broadcast(coreAddresses.shared.bridgehubAdmin);
        bridgehub.acceptAdmin();
    }

    function runForAnvil() public {
        // Deploy contracts but skip acceptAdmin() which requires
        // broadcasting from a contract address (ChainAdminOwnable).
        // The admin can be accepted manually if needed for testing.
        _runFromEnv();
    }

    function _runFromEnv() private {
        runInner(vm.envString("L1_CONFIG"), vm.envString("L1_OUTPUT"));
    }

    function getAddresses() public view returns (CoreDeployedAddresses memory) {
        return coreAddresses;
    }

    /// @notice Returns the address to use as the deployer/owner for contracts.
    function getDeployerAddress() public view returns (address) {
        return tx.origin;
    }

    function getConfig() public view returns (Config memory) {
        return config;
    }

    function runInner(string memory inputPath, string memory outputPath) public {
        string memory root = vm.projectRoot();
        inputPath = string.concat(root, inputPath);
        outputPath = string.concat(root, outputPath);

        initializeConfig(inputPath);

        (coreAddresses.shared.governance) = deploySimpleContract("Governance", false);
        (coreAddresses.shared.bridgehubAdmin) = deploySimpleContract("ChainAdminOwnable", false);
        coreAddresses.shared.transparentProxyAdmin = deployWithCreate2AndOwner(
            "ProxyAdmin",
            coreAddresses.shared.governance,
            false
        );

        // The single owner chainAdmin does not have a separate control restriction contract.
        // We set to it to zero explicitly so that it is clear to the reader.
        coreAddresses.shared.accessControlRestrictionAddress = address(0);
        (
            coreAddresses.bridgehub.implementations.bridgehub,
            coreAddresses.bridgehub.proxies.bridgehub
        ) = deployTuppWithContract("L1Bridgehub", false);
        (
            coreAddresses.bridgehub.implementations.chainAssetHandler,
            coreAddresses.bridgehub.proxies.chainAssetHandler
        ) = deployTuppWithContract("L1ChainAssetHandler", false);
        {
            string memory messageRootContract = vm.envOr("USE_DUMMY_MESSAGE_ROOT", false)
                ? "DummyL1MessageRoot"
                : "L1MessageRoot";
            (
                coreAddresses.bridgehub.implementations.messageRoot,
                coreAddresses.bridgehub.proxies.messageRoot
            ) = deployTuppWithContract(messageRootContract, false);
        }

        (
            coreAddresses.bridges.implementations.l1Nullifier,
            coreAddresses.bridges.proxies.l1Nullifier
        ) = deployTuppWithContract("L1Nullifier", false);
        (
            coreAddresses.bridges.implementations.l1AssetRouter,
            coreAddresses.bridges.proxies.l1AssetRouter
        ) = deployTuppWithContract("L1AssetRouter", false);
        (coreAddresses.bridges.bridgedStandardERC20Implementation) = deploySimpleContract(
            "BridgedStandardERC20",
            false
        );
        coreAddresses.bridges.bridgedTokenBeacon = deployWithCreate2AndOwner(
            "BridgedTokenBeacon",
            config.ownerAddress,
            false
        );
        (
            coreAddresses.bridges.implementations.l1NativeTokenVault,
            coreAddresses.bridges.proxies.l1NativeTokenVault
        ) = deployTuppWithContract("L1NativeTokenVault", false);
        (
            coreAddresses.bridges.implementations.l1InteropHandler,
            coreAddresses.bridges.proxies.l1InteropHandler
        ) = deployTuppWithContract("L1InteropHandler", false);
        setL1NativeTokenVaultParams();

        updateSharedBridge();
        (
            coreAddresses.bridgehub.implementations.ctmDeploymentTracker,
            coreAddresses.bridgehub.proxies.ctmDeploymentTracker
        ) = deployTuppWithContract("CTMDeploymentTracker", false);

        (
            coreAddresses.bridgehub.implementations.chainRegistrationSender,
            coreAddresses.bridgehub.proxies.chainRegistrationSender
        ) = deployTuppWithContract("ChainRegistrationSender", false);
        setBridgehubParams();

        updateOwners();

        saveOutput(outputPath);
    }

    function setBridgehubParams() internal {
        IL1Bridgehub bridgehub = IL1Bridgehub(coreAddresses.bridgehub.proxies.bridgehub);
        L1ChainAssetHandler chainAssetHandler = L1ChainAssetHandler(coreAddresses.bridgehub.proxies.chainAssetHandler);
        vm.startBroadcast(getDeployerAddress());
        bridgehub.addTokenAssetId(bridgehub.baseTokenAssetId(config.eraChainId));
        BridgehubBase(address(bridgehub)).setAddresses(
            coreAddresses.bridges.proxies.l1AssetRouter,
            ICTMDeploymentTracker(coreAddresses.bridgehub.proxies.ctmDeploymentTracker),
            IMessageRootBase(coreAddresses.bridgehub.proxies.messageRoot),
            coreAddresses.bridgehub.proxies.chainAssetHandler,
            coreAddresses.bridgehub.proxies.chainRegistrationSender
        );
        chainAssetHandler.setAddresses();
        vm.stopBroadcast();
        console.log("SharedBridge registered");
    }

    function updateSharedBridge() internal {
        vm.broadcast(getDeployerAddress());
        IL1NativeTokenVault(coreAddresses.bridges.proxies.l1NativeTokenVault).registerEthToken();
    }

    function setL1NativeTokenVaultParams() internal {
        IL1AssetRouter sharedBridge = IL1AssetRouter(coreAddresses.bridges.proxies.l1AssetRouter);
        IL1Nullifier l1Nullifier = IL1Nullifier(coreAddresses.bridges.proxies.l1Nullifier);
        vm.broadcast(getDeployerAddress());
        sharedBridge.setNativeTokenVault(INativeTokenVaultBase(coreAddresses.bridges.proxies.l1NativeTokenVault));
        vm.broadcast(getDeployerAddress());
        l1Nullifier.setL1NativeTokenVault(IL1NativeTokenVault(coreAddresses.bridges.proxies.l1NativeTokenVault));
        vm.broadcast(getDeployerAddress());
        l1Nullifier.setL1AssetRouter(coreAddresses.bridges.proxies.l1AssetRouter);
        vm.broadcast(getDeployerAddress());
        l1Nullifier.setL1InteropHandler(coreAddresses.bridges.proxies.l1InteropHandler);
        vm.broadcast(getDeployerAddress());
        sharedBridge.setL1InteropHandler(coreAddresses.bridges.proxies.l1InteropHandler);
    }

    function updateOwners() internal {
        vm.startBroadcast(getDeployerAddress());

        IL1Bridgehub bridgehub = IL1Bridgehub(coreAddresses.bridgehub.proxies.bridgehub);
        IOwnable(address(bridgehub)).transferOwnership(coreAddresses.shared.governance);
        bridgehub.setPendingAdmin(coreAddresses.shared.bridgehubAdmin);

        IL1AssetRouter sharedBridge = IL1AssetRouter(coreAddresses.bridges.proxies.l1AssetRouter);
        IOwnable(address(sharedBridge)).transferOwnership(coreAddresses.shared.governance);

        L1NativeTokenVault l1NativeTokenVault = L1NativeTokenVault(
            payable(coreAddresses.bridges.proxies.l1NativeTokenVault)
        );
        l1NativeTokenVault.transferOwnership(config.ownerAddress);

        IL1Nullifier l1Nullifier = IL1Nullifier(coreAddresses.bridges.proxies.l1Nullifier);
        IOwnable(address(l1Nullifier)).transferOwnership(coreAddresses.shared.governance);

        // The L1 interop handler's owner can pause/unpause withdrawal finalization.
        IOwnable(coreAddresses.bridges.proxies.l1InteropHandler).transferOwnership(coreAddresses.shared.governance);

        ICTMDeploymentTracker ctmDeploymentTracker = ICTMDeploymentTracker(
            coreAddresses.bridgehub.proxies.ctmDeploymentTracker
        );
        IOwnable(address(ctmDeploymentTracker)).transferOwnership(coreAddresses.shared.governance);

        IOwnable(coreAddresses.bridgehub.proxies.chainAssetHandler).transferOwnership(coreAddresses.shared.governance);

        vm.stopBroadcast();
        console.log("Owners updated");
    }

    function saveOutput(string memory outputPath) internal virtual {
        vm.serializeAddress("bridgehub", "bridgehub_proxy_addr", coreAddresses.bridgehub.proxies.bridgehub);
        vm.serializeAddress(
            "bridgehub",
            "bridgehub_implementation_addr",
            coreAddresses.bridgehub.implementations.bridgehub
        );
        vm.serializeAddress(
            "bridgehub",
            "chain_asset_handler_implementation_addr",
            coreAddresses.bridgehub.implementations.chainAssetHandler
        );
        vm.serializeAddress(
            "bridgehub",
            "chain_asset_handler_proxy_addr",
            coreAddresses.bridgehub.proxies.chainAssetHandler
        );
        vm.serializeAddress(
            "bridgehub",
            "chain_registration_sender_proxy_addr",
            coreAddresses.bridgehub.proxies.chainRegistrationSender
        );
        vm.serializeAddress(
            "bridgehub",
            "chain_registration_sender_implementation_addr",
            coreAddresses.bridgehub.implementations.chainRegistrationSender
        );
        vm.serializeAddress(
            "bridgehub",
            "ctm_deployment_tracker_proxy_addr",
            coreAddresses.bridgehub.proxies.ctmDeploymentTracker
        );
        vm.serializeAddress(
            "bridgehub",
            "ctm_deployment_tracker_implementation_addr",
            coreAddresses.bridgehub.implementations.ctmDeploymentTracker
        );
        vm.serializeAddress("bridgehub", "message_root_proxy_addr", coreAddresses.bridgehub.proxies.messageRoot);
        string memory bridgehub = vm.serializeAddress(
            "bridgehub",
            "message_root_implementation_addr",
            coreAddresses.bridgehub.implementations.messageRoot
        );

        vm.serializeAddress(
            "bridges",
            "l1_nullifier_implementation_addr",
            coreAddresses.bridges.implementations.l1Nullifier
        );
        vm.serializeAddress("bridges", "l1_nullifier_proxy_addr", coreAddresses.bridges.proxies.l1Nullifier);
        vm.serializeAddress(
            "bridges",
            "l1_interop_handler_implementation_addr",
            coreAddresses.bridges.implementations.l1InteropHandler
        );
        vm.serializeAddress("bridges", "l1_interop_handler_proxy_addr", coreAddresses.bridges.proxies.l1InteropHandler);
        vm.serializeAddress(
            "bridges",
            "shared_bridge_implementation_addr",
            coreAddresses.bridges.implementations.l1AssetRouter
        );
        string memory bridges = vm.serializeAddress(
            "bridges",
            "shared_bridge_proxy_addr",
            coreAddresses.bridges.proxies.l1AssetRouter
        );

        vm.serializeAddress("deployed_addresses", "governance_addr", coreAddresses.shared.governance);
        vm.serializeAddress(
            "deployed_addresses",
            "transparent_proxy_admin_addr",
            coreAddresses.shared.transparentProxyAdmin
        );
        vm.serializeAddress("deployed_addresses", "chain_admin", coreAddresses.shared.bridgehubAdmin);
        vm.serializeAddress(
            "deployed_addresses",
            "access_control_restriction_addr",
            coreAddresses.shared.accessControlRestrictionAddress
        );
        vm.serializeString("deployed_addresses", "bridgehub", bridgehub);
        vm.serializeString("deployed_addresses", "bridges", bridges);

        string memory deployedAddresses = vm.serializeAddress(
            "deployed_addresses",
            "native_token_vault_addr",
            coreAddresses.bridges.proxies.l1NativeTokenVault
        );

        vm.serializeAddress("contracts", "create2_factory_addr", create2FactoryState.create2FactoryAddress);
        string memory contracts = vm.serializeBytes32("contracts", "create2_factory_salt", _create2FactorySalt);

        vm.serializeString("root", "contracts", contracts);
        vm.serializeUint("root", "l1_chain_id", config.l1ChainId);
        vm.serializeUint("root", "era_chain_id", config.eraChainId);
        vm.serializeAddress("root", "deployer_addr", config.deployerAddress);
        vm.serializeString("root", "deployed_addresses", deployedAddresses);
        string memory toml = vm.serializeAddress("root", "owner_address", config.ownerAddress);

        vm.writeToml(toml, outputPath);
    }

    // add this to be excluded from coverage report
    function test() internal virtual override {}
}
