// SPDX-License-Identifier: MIT
// We use a floating point pragma here so it can be used within other projects that interact with the ZKsync ecosystem without using our exact pragma version.
pragma solidity ^0.8.24;

import {InteroperableAddress} from "../../vendor/draft-InteroperableAddress.sol";

import {IInteropHandlerBase} from "./IInteropHandlerBase.sol";
import {
    INTEROP_BUNDLE_VERSION,
    INTEROP_CALL_VERSION,
    BundleStatus,
    CallStatus,
    InteropBundle,
    InteropCall
} from "../../common/Messaging.sol";
import {IERC7786Recipient} from "../IERC7786Recipient.sol";
import {ReentrancyGuard} from "../../common/ReentrancyGuard.sol";
import {InteropDataEncoding} from "../InteropDataEncoding.sol";
import {
    BundleAlreadyProcessed,
    CallAlreadyExecuted,
    CallNotExecutable,
    CanNotUnbundle,
    EmptyBundle,
    ExecutingNotAllowed,
    UnbundlingNotAllowed,
    WrongCallStatusLength,
    WrongDestinationChainId,
    WrongDestinationBaseTokenAssetId,
    WrongSourceChainId,
    InvalidInteropBundleVersion,
    InvalidInteropCallVersion,
    ShadowAccountNotSupported
} from "../InteropErrors.sol";
import {InvalidSelector, PayloadTooShort, Unauthorized} from "../../common/L1ContractErrors.sol";

/// @title InteropHandlerBase
/// @author Matter Labs
/// @custom:security-contact security@matterlabs.dev
/// @notice Shared, proof-agnostic logic for executing, verifying and unbundling interop bundles. Both the L2
/// system contract (`L2InteropHandler`) and the L1-side `L1InteropHandler` inherit this base.
/// @dev The proof-typed entry points (`executeBundle`/`verifyBundle`) live in the derived contracts, because the
/// two layers authenticate a bundle differently: L2->L2 interop is atomic and proven via the AtomicFlowManager's
/// IMT (`AtomicFinalityProof`), while L2->L1 withdrawals are proven via L1 message inclusion
/// (`MessageInclusionProof`). This base owns only the pieces that do not depend on the proof type: bundle
/// decoding, the bundle/call status state machine, `unbundleBundle`, call execution, and the ERC-7786
/// `receiveMessage` rescue dispatch (whose proof-specific branches route back through virtual hooks).
abstract contract InteropHandlerBase is IInteropHandlerBase, IERC7786Recipient, ReentrancyGuard {
    /// @dev Deprecated. This slot previously held the L1 chain id, which is no longer used (the handler operates
    /// on `block.chainid`). Retained — not removed — to preserve the upgradeable storage layout.
    // slither-disable-next-line uninitialized-state
    uint256 internal __DEPRECATED_L1_CHAIN_ID;

    /// @inheritdoc IInteropHandlerBase
    mapping(bytes32 bundleHash => BundleStatus bundleStatus) public bundleStatus;

    /// @inheritdoc IInteropHandlerBase
    mapping(bytes32 bundleHash => mapping(uint256 callIndex => CallStatus callStatus)) public callStatus;

    /// @dev Reserved storage to allow future additions to this shared base without shifting the storage of
    /// the derived {L1InteropHandler}/{L2InteropHandler} (which currently declare no storage of their own).
    // slither-disable-next-line unused-state
    uint256[50] private __gap;

    /*//////////////////////////////////////////////////////////////
                        Environment-specific hooks
    //////////////////////////////////////////////////////////////*/

    /// @notice Handles the base-token value that rides along an interop call before it is forwarded.
    /// @dev L2 pulls the value from the `BaseTokenHolder`; L1 forbids non-zero value (withdrawals carry the amount in
    /// their transfer data, not as call value).
    function _handleCallValue(uint256 _value, uint256 _sourceChainId) internal virtual;

    /// @notice The base-token asset ID expected as the bundle's destination base token on this layer.
    function _expectedDestinationBaseTokenAssetId() internal view virtual returns (bytes32);

    /// @notice Guard invoked by the call-executing entry points (`executeBundle` and `unbundleBundle`).
    /// @dev On L1 this enforces the pausable check, so withdrawals can be halted; on L2 it is a no-op (the L2
    /// system contract is not pausable). `verifyBundle` is intentionally not guarded: it only records that a
    /// bundle was proven and moves no assets.
    function _ensureNotPaused() internal view virtual {}

    /// @notice Resolves the recipient a bundle call is dispatched to. Default trusts the caller-selected `_to`;
    /// L1 overrides it to pin every call to the canonical AssetRouter.
    function _interopCallTarget(address _to) internal view virtual returns (address) {
        return _to;
    }

    /// @notice The selector of the derived contract's `executeBundle`, used by `receiveMessage` dispatch.
    /// @dev It differs per layer because the proof type in the signature differs.
    function _executeBundleSelector() internal view virtual returns (bytes4);

    /// @notice The selector of the derived contract's `verifyBundle`, used by `receiveMessage` dispatch.
    function _verifyBundleSelector() internal view virtual returns (bytes4);

    /// @notice Proof-specific `receiveMessage` handler for the `executeBundle` selector. The derived contract
    /// decodes its own proof type, re-checks execution permission for `sender`, and re-enters `executeBundle`.
    function _receiveExecuteBundle(
        bytes calldata _payload,
        uint256 _senderChainId,
        address _senderAddress,
        bytes calldata _sender
    ) internal virtual;

    /// @notice Proof-specific `receiveMessage` handler for the `verifyBundle` selector (permissionless).
    function _receiveVerifyBundle(bytes calldata _payload) internal virtual;

    /*//////////////////////////////////////////////////////////////
                            Public entry points
    //////////////////////////////////////////////////////////////*/

    /// @inheritdoc IInteropHandlerBase
    function unbundleBundle(bytes memory _bundle, CallStatus[] calldata _providedCallStatus) public {
        _ensureNotPaused();

        (InteropBundle memory interopBundle, bytes32 bundleHash, BundleStatus status) = _getBundleData(_bundle);

        (uint256 unbundlerChainId, address unbundlerAddress) = InteroperableAddress.parseEvmV1(
            interopBundle.bundleAttributes.unbundlerAddress
        );

        // Unbundler permission gate; `msg.sender == address(this)` covers unbundling initiated through
        // `receiveMessage`, which validates the cross-chain sender itself.
        require(
            msg.sender == address(this) ||
                ((unbundlerChainId == block.chainid || unbundlerChainId == 0) && unbundlerAddress == msg.sender),
            UnbundlingNotAllowed(
                bundleHash,
                InteroperableAddress.formatEvmV1(block.chainid, msg.sender),
                interopBundle.bundleAttributes.unbundlerAddress
            )
        );

        require(
            interopBundle.calls.length == _providedCallStatus.length,
            WrongCallStatusLength(interopBundle.calls.length, _providedCallStatus.length)
        );

        require(status == BundleStatus.Verified || status == BundleStatus.Unbundled, CanNotUnbundle(bundleHash));

        // No destination-context re-validation is needed here: `Verified`/`Unbundled` status is only ever
        // reached through `_validateBundleDestinationContext` (executeBundle/verifyBundle), and every
        // context input is immutable afterwards — the chain ids are committed in the bundle hash and the
        // chain's base-token asset id is set-once (see `L2NativeTokenVault.updateL2`).

        // Mark the bundle Unbundled (CEI) before any external call runs.
        bundleStatus[bundleHash] = BundleStatus.Unbundled;

        uint256 callsLength = interopBundle.calls.length;
        for (uint256 i = 0; i < callsLength; ++i) {
            CallStatus recordedCallStatus = callStatus[bundleHash][i];
            CallStatus requestedCallStatus = _providedCallStatus[i];
            if (requestedCallStatus == CallStatus.Executed) {
                require(recordedCallStatus == CallStatus.Unprocessed, CallNotExecutable(bundleHash, i));
                callStatus[bundleHash][i] = CallStatus.Executed;
                emit CallProcessed(bundleHash, i, CallStatus.Executed);
            } else if (requestedCallStatus == CallStatus.Cancelled) {
                require(recordedCallStatus != CallStatus.Executed, CallAlreadyExecuted(bundleHash, i));
                if (recordedCallStatus == CallStatus.Unprocessed) {
                    callStatus[bundleHash][i] = CallStatus.Cancelled;
                    emit CallProcessed(bundleHash, i, CallStatus.Cancelled);
                }
            } // Any other requested status leaves the call untouched (skip).
        }

        _executeCalls({
            _sourceChainId: interopBundle.sourceChainId,
            _bundleHash: bundleHash,
            _interopBundle: interopBundle,
            _executeAllCalls: false,
            _providedCallStatus: _providedCallStatus
        });

        emit BundleUnbundled(bundleHash);
    }

    /// @notice ERC-7786 recipient entry point, used as a rescue mechanism when the sender is a contract whose
    ///         unbundler/executor is itself: it cannot call `unbundleBundle`/`executeBundle` directly, so it
    ///         sends a bundle whose call targets this handler's `receiveMessage` with the encoded call.
    /// @dev The proof-specific execute/verify branches are delegated to virtual hooks (`_receiveExecuteBundle`
    ///      / `_receiveVerifyBundle`) implemented per layer; the unbundle branch is proof-agnostic and handled
    ///      here. The dispatched selectors are the derived contract's own `executeBundle`/`verifyBundle`
    ///      selectors (which differ per layer by proof type). NOTE: never change these selectors — previously
    ///      sent messages must stay executable.
    /// @param sender ERC-7930 interoperable address of the message sender.
    /// @param payload ABI-encoded function call data with selector and parameters.
    /// @return selector The function selector of this receiveMessage function, as per ERC-7786.
    function receiveMessage(
        bytes32,
        /* receiveId */
        bytes calldata sender,
        bytes calldata payload
    ) external payable override returns (bytes4) {
        require(msg.sender == address(this), Unauthorized(msg.sender));

        // Revert cleanly on a payload too short to carry a selector, instead of the slice-out-of-bounds panic.
        require(payload.length >= 4, PayloadTooShort());
        bytes4 selector = bytes4(payload[:4]);

        (uint256 senderChainId, address senderAddress) = InteroperableAddress.parseEvmV1Calldata(sender);

        if (selector == _executeBundleSelector()) {
            _receiveExecuteBundle(payload, senderChainId, senderAddress, sender);
        } else if (selector == _verifyBundleSelector()) {
            _receiveVerifyBundle(payload);
        } else if (selector == this.unbundleBundle.selector) {
            _handleUnbundleBundle(payload, senderChainId, senderAddress, sender);
        } else {
            revert InvalidSelector(selector);
        }

        return IERC7786Recipient.receiveMessage.selector;
    }

    /*//////////////////////////////////////////////////////////////
                            Internal functions
    //////////////////////////////////////////////////////////////*/

    /// @notice Decode an ABI-encoded bundle, compute its hash, and fetch its current status.
    /// @param _bundle ABI-encoded InteropBundle.
    /// @return interopBundle The decoded InteropBundle struct.
    /// @return bundleHash Hash corresponding to the bundle that gets decoded.
    /// @return currentStatus The current BundleStatus of the bundle that gets decoded.
    function _getBundleData(
        bytes memory _bundle
    ) internal view returns (InteropBundle memory interopBundle, bytes32 bundleHash, BundleStatus currentStatus) {
        // Revert with a clean error on an empty bundle instead of the panic `abi.decode` would produce.
        require(_bundle.length != 0, EmptyBundle());
        interopBundle = abi.decode(_bundle, (InteropBundle));
        require(interopBundle.version == INTEROP_BUNDLE_VERSION, InvalidInteropBundleVersion());
        bundleHash = InteropDataEncoding.encodeInteropBundleHash(_bundle);
        currentStatus = bundleStatus[bundleHash];
    }

    /// @notice Execution-address permission gate shared by the derived `executeBundle` entry points.
    /// @dev Permissionless when no `executionAddress` is set; otherwise only that address (on this chain, or
    /// chain-agnostic via chainId 0) may execute — or this contract itself, when execution was initiated
    /// through `receiveMessage`.
    function _requireExecutionAllowed(bytes32 _bundleHash, InteropBundle memory _interopBundle) internal view {
        if (_interopBundle.bundleAttributes.executionAddress.length == 0) {
            return;
        }
        (uint256 executionChainId, address executionAddress) = InteroperableAddress.parseEvmV1(
            _interopBundle.bundleAttributes.executionAddress
        );
        require(
            (msg.sender == address(this) ||
                ((executionChainId == block.chainid || executionChainId == 0) && executionAddress == msg.sender)),
            ExecutingNotAllowed(
                _bundleHash,
                InteroperableAddress.formatEvmV1(block.chainid, msg.sender),
                _interopBundle.bundleAttributes.executionAddress
            )
        );
    }

    /// @notice Execution-address permission gate for the `receiveMessage` rescue path, shared by the derived
    /// `_receiveExecuteBundle` implementations (which differ only in proof type).
    /// @dev On the rescue path the executor is the wrapped message's sender (`_senderChainId`/`_senderAddress`),
    /// not `msg.sender` (which is always this contract here); permissionless when no `executionAddress` is set.
    function _requireRescueExecutionAllowed(
        bytes32 _bundleHash,
        InteropBundle memory _interopBundle,
        uint256 _senderChainId,
        address _senderAddress,
        bytes calldata _sender
    ) internal pure {
        if (_interopBundle.bundleAttributes.executionAddress.length == 0) {
            return;
        }
        (uint256 executionChainId, address executionAddress) = InteroperableAddress.parseEvmV1(
            _interopBundle.bundleAttributes.executionAddress
        );
        require(
            (executionChainId == _senderChainId || executionChainId == 0) && executionAddress == _senderAddress,
            ExecutingNotAllowed(_bundleHash, _sender, _interopBundle.bundleAttributes.executionAddress)
        );
    }

    /// @notice Requires a bundle to be executable: either never processed, or already proven (`Verified`).
    /// @dev Whitelist approach: any future status is rejected until explicitly allowed.
    function _requireExecutable(bytes32 _bundleHash, BundleStatus _status) internal pure {
        require(
            _status == BundleStatus.Unreceived || _status == BundleStatus.Verified,
            BundleAlreadyProcessed(_bundleHash)
        );
    }

    /// @notice Shared pre-gate for `executeBundle`: pause, caller permission, executability. The
    /// destination-context check lives only in {_validateVerifiable} (run by the verify gate); the atomic
    /// execute path, which has no verify gate, calls {_validateBundleDestinationContext} explicitly.
    function _validateExecutable(
        bytes32 _bundleHash,
        InteropBundle memory _interopBundle,
        BundleStatus _status
    ) internal view {
        _ensureNotPaused();
        _requireExecutionAllowed(_bundleHash, _interopBundle);
        _requireExecutable(_bundleHash, _status);
    }

    /// @notice Shared pre-gate validation for the derived `verifyBundle`: destination-context check plus a
    /// fresh-bundle (`Unreceived`) requirement. The handler then runs its typed proof gate and marks the
    /// bundle `Verified`.
    /// @param _proofSourceChainId See {_validateExecutable}.
    function _validateVerifiable(
        bytes32 _bundleHash,
        InteropBundle memory _interopBundle,
        uint256 _proofSourceChainId,
        BundleStatus _status
    ) internal view {
        _validateBundleDestinationContext(_bundleHash, _interopBundle, _proofSourceChainId);
        require(_status == BundleStatus.Unreceived, BundleAlreadyProcessed(_bundleHash));
    }

    /// @notice Marks a proven bundle `Verified` and emits the event. Shared tail of the derived `verifyBundle`.
    function _markVerified(bytes32 _bundleHash) internal {
        bundleStatus[_bundleHash] = BundleStatus.Verified;
        emit BundleVerified(_bundleHash);
    }

    /// @notice Marks the bundle `FullyExecuted` (CEI) and executes all of its calls — the shared tail of the
    /// derived `executeBundle`. `_executeAllCalls = true`, so any failing call reverts the whole flow, leaving
    /// no state changes.
    function _markFullyExecutedAndRun(bytes32 _bundleHash, InteropBundle memory _interopBundle) internal {
        bundleStatus[_bundleHash] = BundleStatus.FullyExecuted;

        uint256 callsLength = _interopBundle.calls.length;
        for (uint256 i = 0; i < callsLength; ++i) {
            callStatus[_bundleHash][i] = CallStatus.Executed;
        }

        _executeCalls({
            _sourceChainId: _interopBundle.sourceChainId,
            _bundleHash: _bundleHash,
            _interopBundle: _interopBundle,
            _executeAllCalls: true,
            _providedCallStatus: new CallStatus[](0)
        });

        emit BundleExecuted(_bundleHash);
    }

    /// @notice Executes calls in a bundle according to provided or default statuses.
    /// @param _sourceChainId Origin chain ID.
    /// @param _bundleHash Precomputed hash of the bundle.
    /// @param _interopBundle Decoded InteropBundle struct.
    /// @param _executeAllCalls If true, executes all calls; otherwise uses providedCallStatus.
    /// @param _providedCallStatus Desired status array when not executing all calls.
    function _executeCalls(
        uint256 _sourceChainId,
        bytes32 _bundleHash,
        InteropBundle memory _interopBundle,
        bool _executeAllCalls,
        CallStatus[] memory _providedCallStatus
    ) internal {
        uint256 callsLength = _interopBundle.calls.length;
        for (uint256 i = 0; i < callsLength; ++i) {
            if (!_executeAllCalls) {
                CallStatus requestedCallStatus = _providedCallStatus[i];
                if (requestedCallStatus != CallStatus.Executed) {
                    continue;
                }
            }
            InteropCall memory interopCall = _interopBundle.calls[i];
            require(interopCall.version == INTEROP_CALL_VERSION, InvalidInteropCallVersion());
            // `shadowAccount` is a reserved field this release does not support; reject `true` so a future
            // shadow-account call fails fast here instead of being silently executed as a non-shadow call.
            require(!interopCall.shadowAccount, ShadowAccountNotSupported());

            _handleCallValue(interopCall.value, _sourceChainId);

            // slither-disable-next-line arbitrary-send-eth
            bytes4 selector = IERC7786Recipient(_interopCallTarget(interopCall.to)).receiveMessage{
                value: interopCall.value
            }({
                receiveId: keccak256(abi.encodePacked(_bundleHash, i)),
                sender: InteroperableAddress.formatEvmV1(_sourceChainId, interopCall.from),
                payload: interopCall.data
            }); // attributes are not supported yet
            require(selector == IERC7786Recipient.receiveMessage.selector, InvalidSelector(selector));
        }
    }

    /// @notice Validates that a bundle is being executed/verified in the correct destination context.
    /// @param bundleHash Hash of the bundle.
    /// @param interopBundle Decoded bundle.
    /// @param proofChainId The source chain id as attested by the proof (message-inclusion `proof.chainId` on
    /// L1; the bundle's own `sourceChainId` for the self-binding atomic proof on L2).
    function _validateBundleDestinationContext(
        bytes32 bundleHash,
        InteropBundle memory interopBundle,
        uint256 proofChainId
    ) internal view {
        require(
            interopBundle.sourceChainId == proofChainId,
            WrongSourceChainId(bundleHash, interopBundle.sourceChainId, proofChainId)
        );

        require(
            interopBundle.destinationChainId == block.chainid,
            WrongDestinationChainId(bundleHash, interopBundle.destinationChainId, block.chainid)
        );

        bytes32 baseTokenAssetId = _expectedDestinationBaseTokenAssetId();
        require(
            interopBundle.destinationBaseTokenAssetId == baseTokenAssetId,
            WrongDestinationBaseTokenAssetId(bundleHash, baseTokenAssetId, interopBundle.destinationBaseTokenAssetId)
        );
    }

    /// @notice Shared `receiveMessage` handler for the (proof-agnostic) unbundle branch.
    function _handleUnbundleBundle(
        bytes calldata payload,
        uint256 senderChainId,
        address senderAddress,
        bytes calldata sender
    ) internal {
        (bytes memory bundle, CallStatus[] memory providedCallStatus) = abi.decode(payload[4:], (bytes, CallStatus[]));

        (InteropBundle memory interopBundle, bytes32 bundleHash, ) = _getBundleData(bundle);

        (uint256 unbundlerChainId, address unbundlerAddress) = InteroperableAddress.parseEvmV1(
            interopBundle.bundleAttributes.unbundlerAddress
        );

        require(
            (unbundlerChainId == senderChainId || unbundlerChainId == 0) && unbundlerAddress == senderAddress,
            UnbundlingNotAllowed(bundleHash, sender, interopBundle.bundleAttributes.unbundlerAddress)
        );

        this.unbundleBundle(bundle, providedCallStatus);
    }
}
