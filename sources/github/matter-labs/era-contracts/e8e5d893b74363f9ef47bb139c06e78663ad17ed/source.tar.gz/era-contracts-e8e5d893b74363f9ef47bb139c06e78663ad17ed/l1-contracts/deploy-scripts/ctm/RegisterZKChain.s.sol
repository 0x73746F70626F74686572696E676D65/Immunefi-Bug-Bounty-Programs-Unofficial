// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

// solhint-disable no-console, gas-custom-errors, reason-string

import {Script, console2 as console} from "forge-std/Script.sol";

import {stdToml} from "forge-std/StdToml.sol";

import {ProxyAdmin} from "@openzeppelin/contracts-v4/proxy/transparent/ProxyAdmin.sol";

import {IL1Bridgehub} from "contracts/core/bridgehub/IL1Bridgehub.sol";

import {IZKChain} from "contracts/state-transition/chain-interfaces/IZKChain.sol";
import {ValidatorTimelock} from "contracts/state-transition/validators/ValidatorTimelock.sol";
import {IValidatorTimelock} from "contracts/state-transition/validators/interfaces/IValidatorTimelock.sol";
import {Governance} from "contracts/governance/Governance.sol";
import {ChainAdmin} from "contracts/governance/ChainAdmin.sol";
import {ChainAdminOwnable} from "contracts/governance/ChainAdminOwnable.sol";

import {IChainAdminOwnable} from "contracts/governance/IChainAdminOwnable.sol";
import {AccessControlRestriction} from "contracts/governance/AccessControlRestriction.sol";
import {ADDRESS_ONE, Utils} from "../utils/Utils.sol";
import {Create2FactoryUtils} from "../utils/deploy/Create2FactoryUtils.s.sol";
import {PubdataPricingMode} from "contracts/state-transition/chain-deps/ZKChainStorage.sol";
import {AddressIntrospector} from "../utils/AddressIntrospector.sol";
import {ChainTypeManagerBase} from "contracts/state-transition/ChainTypeManagerBase.sol";

import {INativeTokenVaultBase} from "contracts/bridge/ntv/INativeTokenVaultBase.sol";
import {DataEncoding} from "contracts/common/libraries/DataEncoding.sol";

import {L1NullifierDev} from "contracts/dev-contracts/L1NullifierDev.sol";

import {IGovernance} from "contracts/governance/IGovernance.sol";
import {Ownable2Step} from "@openzeppelin/contracts-v4/access/Ownable2Step.sol";
import {Call} from "contracts/governance/Common.sol";

import {ETH_TOKEN_ADDRESS} from "contracts/common/Config.sol";
import {
    ZkChainAddresses,
    StateTransitionDeployedAddresses,
    CTMDeployedAddresses,
    CoreDeployedAddresses
} from "../utils/Types.sol";
import {IRegisterZKChain, RegisterZKChainConfig} from "contracts/script-interfaces/IRegisterZKChain.sol";
import {GetDiamondCutData} from "../utils/GetDiamondCutData.sol";

contract RegisterZKChainScript is Create2FactoryUtils, IRegisterZKChain {
    using stdToml for string;

    bytes32 internal constant STATE_TRANSITION_NEW_CHAIN_HASH = keccak256("NewZKChain(uint256,address)");

    /// @notice Returns the address to use as the deployer/owner for contracts.
    function getDeployerAddress() public view returns (address) {
        return tx.origin;
    }

    struct LegacySharedBridgeParams {
        bytes implementationConstructorParams;
        address implementationAddress;
        bytes proxyConstructorParams;
        address proxyAddress;
    }

    LegacySharedBridgeParams internal legacySharedBridgeParams;

    CTMDeployedAddresses internal ctmAddresses;
    CoreDeployedAddresses internal coreAddresses;

    RegisterZKChainConfig internal config;
    ZkChainAddresses internal output;

    function run(address _chainTypeManagerProxy, uint256 _chainChainId) public {
        runWithPaths(
            "/script-config/register-zk-chain.toml",
            "/script-out/output-register-zk-chain.toml",
            _chainTypeManagerProxy,
            _chainChainId
        );
    }

    /// @notice Same as `run`, with the input/output TOML paths (project-root
    /// relative) supplied by the caller instead of the conventional defaults.
    function runWithPaths(
        string memory inputPath,
        string memory outputPath,
        address _chainTypeManagerProxy,
        uint256 _chainChainId
    ) public {
        console.log("Deploying ZKChain");
        string memory root = vm.projectRoot();
        string memory path = string.concat(root, inputPath);
        initializeConfig(path, _chainTypeManagerProxy, _chainChainId);
        loadChainCreationData(_chainTypeManagerProxy);
        // TODO: some chains may not want to have a legacy shared bridge
        runInner(outputPath);
    }

    function loadChainCreationData(address _ctmAddress) internal {
        (config.diamondCutData, config.forceDeploymentsData) = GetDiamondCutData.getDiamondCutAndForceDeployment(
            _ctmAddress,
            false
        );
    }

    function runForTest(address _chainTypeManagerProxy, uint256 _chainChainId) public {
        console.log("Deploying ZKChain");

        // Avoid block.timestamp == 0 to keep paused-deposits sentinel semantics stable in tests.
        vm.warp(1);

        initializeConfigTest(_chainTypeManagerProxy, _chainChainId);
        runInner(vm.envString("ZK_CHAIN_OUT"));
    }

    /// @notice Register multiple chains in a single forge call (avoids nonce conflicts).
    /// Config files must already exist at /test/anvil-interop/config/chain-{chainId}.toml
    function runForTestBatch(address _chainTypeManagerProxy, uint256[] memory _chainIds) public {
        vm.warp(1);

        // Read shared CTM output once
        string memory root = vm.projectRoot();
        string memory ctmPath = string.concat(root, vm.envString("CTM_OUTPUT"));
        string memory ctmToml = vm.readFile(ctmPath);
        bytes memory _forceDeploymentsData = ctmToml.readBytes("$.contracts_config.force_deployments_data");
        bytes memory _diamondCutData = ctmToml.readBytes("$.contracts_config.diamond_cut_data");

        // Read on-chain addresses once (same for all chains)
        initializeConfigFromOnChain(_chainTypeManagerProxy);

        // Set shared config (loop-invariant)
        config.forceDeploymentsData = _forceDeploymentsData;
        config.diamondCutData = _diamondCutData;

        for (uint256 i = 0; i < _chainIds.length; i++) {
            console.log("Deploying ZKChain", _chainIds[i]);

            // Read per-chain config
            string memory chainConfigPath = string.concat(
                root,
                "/test/anvil-interop/config/chain-",
                vm.toString(_chainIds[i]),
                ".toml"
            );
            initializeConfig(chainConfigPath, _chainTypeManagerProxy, _chainIds[i]);

            // Register and save output
            string memory chainOutputPath = string.concat(
                "/test/anvil-interop/outputs/chain-",
                vm.toString(_chainIds[i]),
                "-output.toml"
            );
            runInner(chainOutputPath);
        }
    }

    function runInner(string memory outputPath) internal {
        string memory root = vm.projectRoot();

        outputPath = string.concat(root, outputPath);

        deployGovernance();
        deployChainAdmin();
        deployChainProxyAddress();
        checkTokenAddress();
        registerAssetIdOnBridgehub();
        registerTokenOnNTV();
        registerZKChain();
        addValidators();
        configureZkSyncStateTransition();
        setPendingAdmin();

        saveOutput(outputPath);
    }

    function initializeConfig(string memory path, address chainTypeManagerProxy, uint256 chainChainId) internal {
        // Grab config from output of l1 deployment
        string memory toml = vm.readFile(path);

        config.deployerAddress = getDeployerAddress();

        // Config file must be parsed key by key, otherwise values returned
        // are parsed alfabetically and not by key.
        // https://book.getfoundry.sh/cheatcodes/parse-toml

        initializeConfigFromOnChain(chainTypeManagerProxy);

        config.ownerAddress = toml.readAddress("$.owner_address");

        config.chainChainId = chainChainId;
        config.baseTokenGasPriceMultiplierNominator = uint128(
            toml.readUint("$.chain.base_token_gas_price_multiplier_nominator")
        );
        config.baseTokenGasPriceMultiplierDenominator = uint128(
            toml.readUint("$.chain.base_token_gas_price_multiplier_denominator")
        );
        config.baseToken = toml.readAddress("$.chain.base_token_addr");
        config.governanceSecurityCouncilAddress = toml.readAddress("$.chain.governance_security_council_address");
        config.governanceMinDelay = uint256(toml.readUint("$.chain.governance_min_delay"));
        config.bridgehubCreateNewChainSalt = toml.readUint("$.chain.bridgehub_create_new_chain_salt");
        config.validiumMode = toml.readBool("$.chain.validium_mode");
        config.validatorSenderOperatorEth = toml.readAddress("$.chain.validator_sender_operator_eth");
        config.validatorSenderOperatorBlobsEth = toml.readAddress("$.chain.validator_sender_operator_blobs_eth");

        // These were added to zkstack tool recently (9th Sept 2025).
        // So doing this for backwards compatibility.
        if (vm.keyExistsToml(toml, "$.chain.validator_sender_operator_prove")) {
            config.validatorSenderOperatorProve = toml.readAddress("$.chain.validator_sender_operator_prove");
        } else {
            config.validatorSenderOperatorProve = address(0);
        }
        if (vm.keyExistsToml(toml, "$.chain.validator_sender_operator_execute")) {
            config.validatorSenderOperatorExecute = toml.readAddress("$.chain.validator_sender_operator_execute");
        } else {
            config.validatorSenderOperatorExecute = address(0);
        }

        if (vm.keyExistsToml(toml, "$.initialize_legacy_bridge")) {
            config.initializeLegacyBridge = toml.readBool("$.initialize_legacy_bridge");
        }

        config.l1SharedBridgeProxy = coreAddresses.bridges.proxies.l1AssetRouter;

        (config.create2FactoryAddress, config.create2Salt) = getCreate2FactoryParams();

        if (vm.keyExistsToml(toml, "$.chain.allow_evm_emulator")) {
            config.allowEvmEmulator = toml.readBool("$.chain.allow_evm_emulator");
        }
    }

    function initializeConfigFromOnChain(address _ctmAddress) internal {
        ChainTypeManagerBase ctm = ChainTypeManagerBase(_ctmAddress);
        ctmAddresses = AddressIntrospector.getCTMAddresses(ctm);
        IL1Bridgehub bridgehub = IL1Bridgehub(ctm.BRIDGE_HUB());
        coreAddresses = AddressIntrospector.getCoreDeployedAddresses(address(bridgehub));
    }

    function getConfig() public view returns (RegisterZKChainConfig memory) {
        return config;
    }

    function initializeConfigTest(address chainTypeManagerProxy, uint256 chainChainId) internal {
        string memory root = vm.projectRoot();
        string memory path = string.concat(root, vm.envString("CTM_OUTPUT"));
        string memory toml = vm.readFile(path);
        config.forceDeploymentsData = toml.readBytes("$.contracts_config.force_deployments_data");
        config.diamondCutData = toml.readBytes("$.contracts_config.diamond_cut_data");
        path = string.concat(root, vm.envString("ZK_CHAIN_CONFIG"));
        initializeConfig(path, chainTypeManagerProxy, chainChainId);
    }

    function getOwnerAddress() public view returns (address) {
        return config.ownerAddress;
    }

    function checkTokenAddress() internal view {
        if (config.baseToken == address(0)) {
            revert("Token address is not set");
        }

        // Check if it's ethereum address
        if (config.baseToken == ADDRESS_ONE) {
            return;
        }

        if (config.baseToken.code.length == 0) {
            revert("Token address is not a contract address");
        }

        console.log("Using base token address:", config.baseToken);
    }

    function registerAssetIdOnBridgehub() internal {
        IL1Bridgehub bridgehub = IL1Bridgehub(coreAddresses.bridgehub.proxies.bridgehub);
        ChainAdminOwnable admin = ChainAdminOwnable(payable(coreAddresses.shared.bridgehubAdmin));
        INativeTokenVaultBase ntv = INativeTokenVaultBase(coreAddresses.bridges.proxies.l1NativeTokenVault);
        bytes32 baseTokenAssetId = ntv.assetId(config.baseToken);
        uint256 baseTokenOriginChain = ntv.originChainId(baseTokenAssetId);

        if (baseTokenAssetId == bytes32(0)) {
            baseTokenAssetId = DataEncoding.encodeNTVAssetId(block.chainid, config.baseToken);
        }

        if (bridgehub.assetIdIsRegistered(baseTokenAssetId)) {
            console.log("Base token asset id already registered on Bridgehub");
        } else {
            IChainAdminOwnable.Call[] memory calls = new IChainAdminOwnable.Call[](1);
            calls[0] = IChainAdminOwnable.Call({
                target: coreAddresses.bridgehub.proxies.bridgehub,
                value: 0,
                data: abi.encodeCall(bridgehub.addTokenAssetId, (baseTokenAssetId))
            });
            vm.broadcast(admin.owner());
            admin.multicall(calls, true);

            console.log("Base token asset id registered on Bridgehub");
        }
    }

    function registerTokenOnNTV() internal {
        INativeTokenVaultBase ntv = INativeTokenVaultBase(coreAddresses.bridges.proxies.l1NativeTokenVault);
        bytes32 baseTokenAssetId = ntv.assetId(config.baseToken);
        uint256 baseTokenOriginChain = ntv.originChainId(baseTokenAssetId);

        // If it hasn't been registered already with ntv
        if (baseTokenAssetId == bytes32(0)) {
            baseTokenAssetId = DataEncoding.encodeNTVAssetId(block.chainid, config.baseToken);
        }
        config.baseTokenAssetId = baseTokenAssetId;
        if (ntv.tokenAddress(baseTokenAssetId) != address(0) || config.baseToken == ETH_TOKEN_ADDRESS) {
            console.log("Token already registered on NTV");
        } else {
            vm.broadcast();
            ntv.registerToken(config.baseToken);
            console.log("Token registered on NTV");
        }
    }

    function deployGovernance() internal {
        bytes memory input = abi.encode(
            config.ownerAddress,
            config.governanceSecurityCouncilAddress,
            config.governanceMinDelay
        );
        address governance = deployViaCreate2(abi.encodePacked(type(Governance).creationCode, input));
        console.log("Governance deployed at:", governance);
        output.governance = governance;
    }

    function deployChainAdmin() internal {
        // TODO(EVM-924): provide an option to deploy a non-single owner ChainAdmin.
        (address chainAdmin, address accessControlRestriction) = deployChainAdminOwnable();

        output.accessControlRestrictionAddress = accessControlRestriction;
        output.chainAdmin = chainAdmin;
    }

    function deployChainAdminOwnable() internal returns (address chainAdmin, address accessControlRestriction) {
        chainAdmin = deployViaCreate2(
            abi.encodePacked(type(ChainAdminOwnable).creationCode, abi.encode(config.ownerAddress, address(0)))
        );
        // The single owner chainAdmin does not have a separate control restriction contract.
        // We set to it to zero explicitly so that it is clear to the reader.
        accessControlRestriction = address(0);

        console.log("ChainAdminOwnable deployed at:", accessControlRestriction);
    }

    // TODO(EVM-924): this function is unused
    function deployChainAdminWithRestrictions()
        internal
        returns (address chainAdmin, address accessControlRestriction)
    {
        bytes memory input = abi.encode(0, config.ownerAddress);
        accessControlRestriction = deployViaCreate2(
            abi.encodePacked(type(AccessControlRestriction).creationCode, input)
        );

        address[] memory restrictions = new address[](1);
        restrictions[0] = accessControlRestriction;

        input = abi.encode(restrictions);
        chainAdmin = deployViaCreate2(abi.encodePacked(type(ChainAdmin).creationCode, input));
    }

    function registerZKChain() internal {
        IL1Bridgehub bridgehub = IL1Bridgehub(coreAddresses.bridgehub.proxies.bridgehub);
        ChainAdminOwnable admin = ChainAdminOwnable(payable(coreAddresses.shared.bridgehubAdmin));

        IChainAdminOwnable.Call[] memory calls = new IChainAdminOwnable.Call[](1);
        calls[0] = IChainAdminOwnable.Call({
            target: coreAddresses.bridgehub.proxies.bridgehub,
            value: 0,
            data: abi.encodeCall(
                bridgehub.createNewChain,
                (
                    config.chainChainId,
                    ctmAddresses.stateTransition.proxies.chainTypeManager,
                    config.baseTokenAssetId,
                    config.bridgehubCreateNewChainSalt,
                    getDeployerAddress(),
                    abi.encode(config.diamondCutData, config.forceDeploymentsData),
                    getFactoryDeps()
                )
            )
        });
        vm.broadcast(admin.owner());
        admin.multicall(calls, true);
        console.log("ZK chain registered");

        // Get new diamond proxy address from emitted events
        address diamondProxyAddress = bridgehub.getZKChain(config.chainChainId);
        if (diamondProxyAddress == address(0)) {
            revert("Diamond proxy address not found");
        }
        output.diamondProxy = diamondProxyAddress;
        console.log("ZKChain diamond proxy deployed at:", diamondProxyAddress);
    }

    function addValidators() internal {
        ValidatorTimelock validatorTimelock = ValidatorTimelock(ctmAddresses.stateTransition.proxies.validatorTimelock);
        address chainAddress = IL1Bridgehub(coreAddresses.bridgehub.proxies.bridgehub).getZKChain(config.chainChainId);

        vm.startBroadcast(getDeployerAddress());

        // Eth-path operator (ZKsync Era): precommit / revert / upgrader. When dedicated ZKsync OS prove
        // and execute operators are set, they receive PROVER / EXECUTOR instead (see below).
        bool zkSyncOsValidatorSplit = config.validatorSenderOperatorProve != address(0) &&
            config.validatorSenderOperatorExecute != address(0);
        validatorTimelock.addValidatorRoles(
            chainAddress,
            config.validatorSenderOperatorEth,
            IValidatorTimelock.ValidatorRotationParams({
                rotatePrecommitterRole: true,
                rotateCommitterRole: false,
                rotateReverterRole: true,
                rotateProverRole: !zkSyncOsValidatorSplit,
                rotateExecutorRole: !zkSyncOsValidatorSplit,
                rotateUpgraderRole: true
            })
        );

        validatorTimelock.addValidatorRoles(
            chainAddress,
            config.validatorSenderOperatorBlobsEth,
            IValidatorTimelock.ValidatorRotationParams({
                rotatePrecommitterRole: false,
                rotateCommitterRole: true,
                rotateReverterRole: false,
                rotateProverRole: false,
                rotateExecutorRole: false,
                rotateUpgraderRole: false
            })
        );

        // ZKsync OS split: dedicated prove / execute operators.
        if (zkSyncOsValidatorSplit) {
            validatorTimelock.addValidatorRoles(
                chainAddress,
                config.validatorSenderOperatorProve,
                IValidatorTimelock.ValidatorRotationParams({
                    rotatePrecommitterRole: false,
                    rotateCommitterRole: false,
                    rotateReverterRole: false,
                    rotateProverRole: true,
                    rotateExecutorRole: false,
                    rotateUpgraderRole: false
                })
            );
            validatorTimelock.addValidatorRoles(
                chainAddress,
                config.validatorSenderOperatorExecute,
                IValidatorTimelock.ValidatorRotationParams({
                    rotatePrecommitterRole: false,
                    rotateCommitterRole: false,
                    rotateReverterRole: false,
                    rotateProverRole: false,
                    rotateExecutorRole: true,
                    rotateUpgraderRole: false
                })
            );
        }

        vm.stopBroadcast();

        console.log("Validators added with specific roles");
    }

    function configureZkSyncStateTransition() internal {
        IZKChain zkChain = IZKChain(output.diamondProxy);

        vm.startBroadcast(getDeployerAddress());
        zkChain.setTokenMultiplier(
            config.baseTokenGasPriceMultiplierNominator,
            config.baseTokenGasPriceMultiplierDenominator
        );

        if (config.validiumMode) {
            zkChain.setPubdataPricingMode(PubdataPricingMode.Validium);
        }

        vm.stopBroadcast();
        console.log("ZkSync State Transition configured");
    }

    function setPendingAdmin() internal {
        IZKChain zkChain = IZKChain(output.diamondProxy);

        vm.startBroadcast(getDeployerAddress());
        zkChain.setPendingAdmin(output.chainAdmin);
        vm.stopBroadcast();
        console.log("Owner for ", output.diamondProxy, "set to", output.chainAdmin);
    }

    function unpauseDeposits() internal {
        IZKChain zkChain = IZKChain(output.diamondProxy);
        if (zkChain.depositsPaused()) {
            vm.broadcast(msg.sender);
            zkChain.unpauseDeposits();
            console.log("Deposits unpaused");
        }
    }

    function deployChainProxyAddress() internal {
        address proxyAdmin = create2WithDeterministicOwner(type(ProxyAdmin).creationCode, output.chainAdmin);

        console.log("Transparent Proxy Admin deployed at:", proxyAdmin);
        output.chainProxyAdmin = proxyAdmin;
    }

    function getFactoryDeps() internal pure returns (bytes[] memory) {
        bytes[] memory factoryDeps = new bytes[](0);
        return factoryDeps;
    }

    function saveOutput(string memory outputPath) internal {
        vm.serializeAddress("root", "diamond_proxy_addr", output.diamondProxy);
        vm.serializeAddress("root", "chain_admin_addr", output.chainAdmin);
        if (output.l2LegacySharedBridge != address(0)) {
            vm.serializeAddress("root", "l2_legacy_shared_bridge_addr", output.l2LegacySharedBridge);
        }
        vm.serializeAddress("root", "access_control_restriction_addr", output.accessControlRestrictionAddress);
        vm.serializeAddress("root", "chain_proxy_admin_addr", output.chainProxyAdmin);

        string memory chain = vm.serializeUint("", "chain_id", config.chainChainId);
        vm.serializeString("root", "chain", chain);

        string memory toml = vm.serializeAddress("root", "governance_addr", output.governance);
        string memory root = vm.projectRoot();
        vm.writeToml(toml, outputPath);
        console.log("Output saved at:", outputPath);
    }

    function governanceExecuteCalls(bytes memory callsToExecute, address governanceAddr) internal {
        IGovernance governance = IGovernance(governanceAddr);
        Ownable2Step ownable = Ownable2Step(governanceAddr);

        Call[] memory calls = abi.decode(callsToExecute, (Call[]));

        IGovernance.Operation memory operation = IGovernance.Operation({
            calls: calls,
            predecessor: bytes32(0),
            salt: bytes32(0)
        });

        vm.startBroadcast(ownable.owner());
        governance.scheduleTransparent(operation, 0);
        // We assume that the total value is 0
        governance.execute{value: 0}(operation);
        vm.stopBroadcast();
    }
}
