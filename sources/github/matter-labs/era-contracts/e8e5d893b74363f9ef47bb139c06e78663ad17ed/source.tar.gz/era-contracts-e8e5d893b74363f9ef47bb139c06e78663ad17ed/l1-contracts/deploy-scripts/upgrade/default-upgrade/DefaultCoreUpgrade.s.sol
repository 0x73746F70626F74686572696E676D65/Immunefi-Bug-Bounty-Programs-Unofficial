// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

// solhint-disable no-console, gas-custom-errors

import {Script, console2 as console} from "forge-std/Script.sol";

import {stdToml} from "forge-std/StdToml.sol";
import {ProxyAdmin} from "@openzeppelin/contracts-v4/proxy/transparent/ProxyAdmin.sol";

import {ITransparentUpgradeableProxy} from "@openzeppelin/contracts-v4/proxy/transparent/TransparentUpgradeableProxy.sol";
import {UpgradeableBeacon} from "@openzeppelin/contracts-v4/proxy/beacon/UpgradeableBeacon.sol";

import {L1Bridgehub} from "contracts/core/bridgehub/L1Bridgehub.sol";

import {L1AssetRouter} from "contracts/bridge/asset-router/L1AssetRouter.sol";
import {Call} from "contracts/governance/Common.sol";

import {DeployL1CoreUtils} from "../../ecosystem/DeployL1CoreUtils.s.sol";

import {Governance} from "contracts/governance/Governance.sol";
import {IChainAssetHandlerBase} from "contracts/core/chain-asset-handler/IChainAssetHandler.sol";
import {BridgehubAddresses, CoreDeployedAddresses} from "../../utils/Types.sol";

import {AddressIntrospector} from "../../utils/AddressIntrospector.sol";
import {UpgradeUtils} from "./UpgradeUtils.sol";
import {Utils} from "../../utils/Utils.sol";

import {ChainCreationParamsLib} from "../../ctm/ChainCreationParamsLib.sol";
import {CoreUpgradeParams} from "./UpgradeParams.sol";
import {ICoreUpgrade} from "contracts/script-interfaces/ICoreUpgrade.sol";

/// @notice Script used for default ecosystem upgrade flow should be run as a first for the upgrade.
/// @dev For more complex upgrades, this script can be inherited and its functionality overridden if needed.
contract DefaultCoreUpgrade is Script, DeployL1CoreUtils, ICoreUpgrade {
    using stdToml for string;

    /// @notice Internal state of the upgrade script
    struct EcosystemUpgradeConfig {
        bool initialized;
        string outputPath;
    }

    struct AdditionalConfigParams {
        uint256 newProtocolVersion;
        bool isZKsyncOS;
        bool hasPreV32IntrospectionOverride;
        bool usePreV32IntrospectionOverride;
    }
    AdditionalConfigParams internal additionalConfig;

    EcosystemUpgradeConfig internal upgradeConfig;

    function initializeWithArgs(
        address bridgehubProxyAddress,
        bool isZKsyncOS,
        bytes32 create2FactorySalt,
        string memory upgradeInputPath,
        string memory _outputPath
    ) public virtual {
        string memory root = vm.projectRoot();
        upgradeInputPath = string.concat(root, upgradeInputPath);

        initializeConfigWithArgs(bridgehubProxyAddress, isZKsyncOS, create2FactorySalt, upgradeInputPath);

        upgradeConfig.outputPath = string.concat(root, _outputPath);
        upgradeConfig.initialized = true;
    }

    /// @notice Full default upgrade preparation flow
    function prepareEcosystemUpgrade() public virtual {
        deployNewEcosystemContractsL1();
        console.log("Ecosystem contracts are deployed!");
        saveOutput(upgradeConfig.outputPath);
        console.log("Core upgrade output saved!");
    }

    /// @notice Single-call entry point invoked by the protocol-ops CLI's `ecosystem
    ///         upgrade-prepare-all`. Runs the ecosystem-wide core deploys; CTM deploys are handled
    ///         by the matching CTM upgrade script.
    function noGovernancePrepare(CoreUpgradeParams memory _params) public virtual {
        initializeWithArgs(
            _params.bridgehubProxyAddress,
            _params.isZKsyncOS,
            _params.create2FactorySalt,
            _params.upgradeInputPath,
            _params.outputPath
        );
        prepareEcosystemUpgrade();
        prepareDefaultGovernanceCalls();
    }

    /// @notice Deploy the L1 core implementations behind the proxies {prepareUpgradeProxiesCalls}
    ///         upgrades. Every release refreshes all of them, so this lives here rather than being
    ///         restated per version; a release adds only what is new to it (a new proxy, say) by
    ///         overriding {deployVersionSpecificEcosystemContractsL1}.
    /// @dev Includes the interop handler's implementation even though its *proxy* first appears in
    ///      v33: the implementation is refreshed like any other core contract from then on, and the
    ///      release that introduces the proxy reuses this deploy rather than repeating it.
    function deployNewEcosystemContractsL1() public virtual {
        coreAddresses.bridgehub.implementations.bridgehub = deploySimpleContract("L1Bridgehub", false);
        coreAddresses.bridgehub.implementations.messageRoot = deploySimpleContract("L1MessageRoot", false);
        coreAddresses.bridges.implementations.l1Nullifier = deploySimpleContract("L1Nullifier", false);
        coreAddresses.bridges.implementations.l1AssetRouter = deploySimpleContract("L1AssetRouter", false);
        coreAddresses.bridges.implementations.l1NativeTokenVault = deploySimpleContract("L1NativeTokenVault", false);
        coreAddresses.bridgehub.implementations.ctmDeploymentTracker = deploySimpleContract(
            "CTMDeploymentTracker",
            false
        );
        coreAddresses.bridgehub.implementations.chainAssetHandler = deploySimpleContract("L1ChainAssetHandler", false);
        coreAddresses.bridgehub.implementations.chainRegistrationSender = deploySimpleContract(
            "ChainRegistrationSender",
            false
        );
        coreAddresses.bridges.implementations.l1InteropHandler = deploySimpleContract("L1InteropHandler", false);

        deployVersionSpecificEcosystemContractsL1();
    }

    /// @notice Hook for deploys that only one release needs — typically a proxy that did not exist
    ///         before it. Implementation refreshes belong in {deployNewEcosystemContractsL1}.
    function deployVersionSpecificEcosystemContractsL1() public virtual {}

    function getOwnerAddress() public virtual returns (address) {
        return config.ownerAddress;
    }

    function setOwners(address owner) public virtual {
        config.ownerAddress = owner;
    }

    function getNewProtocolVersion() public virtual returns (uint256) {
        return additionalConfig.newProtocolVersion;
    }

    function getProtocolUpgradeNonce() public virtual returns (uint256) {
        return (getNewProtocolVersion() >> 32);
    }

    function getOldProtocolDeadline() public virtual returns (uint256) {
        // Returns max deadline initially. After the upgrade is complete (stage2),
        // governance should call setNewVersionUpgrade with deadline=0 to force
        // all chains to upgrade immediately.
        return type(uint256).max;
    }

    function getDiscoveredBridgehub() public view returns (BridgehubAddresses memory) {
        return coreAddresses.bridgehub;
    }

    function getCoreAddresses() public view returns (CoreDeployedAddresses memory) {
        return coreAddresses;
    }

    function initializeConfigWithArgs(
        address bridgehubProxyAddress,
        bool isZKsyncOS,
        bytes32 create2FactorySalt,
        string memory upgradeInputPath
    ) public virtual {
        string memory upgradeToml = vm.readFile(upgradeInputPath);

        // Only override the salt when explicitly provided (non-zero).
        // When zero, the script falls back to the CREATE2_FACTORY_SALT env var or built-in default.
        if (create2FactorySalt != bytes32(0)) {
            setCreate2Salt(create2FactorySalt);
        }

        additionalConfig.isZKsyncOS = isZKsyncOS;

        // Optional override for pre-v32 introspection selection. Autodetection reads the protocol version of
        // a registered chain, which lags the L1 contracts: an ecosystem whose core contracts are already v32
        // while its chains have not upgraded yet (mid-upgrade, or a fixture deployed from current code with a
        // v31 genesis) must state so here.
        if (upgradeToml.keyExists("$.pre_v32_introspection")) {
            additionalConfig.hasPreV32IntrospectionOverride = true;
            additionalConfig.usePreV32IntrospectionOverride = upgradeToml.readBool("$.pre_v32_introspection");
        }

        // Protocol version comes from genesis config
        additionalConfig.newProtocolVersion = loadProtocolVersionFromGenesis();

        // Legacy Era gateway chain ID — baked into L1MessageRoot as immutable
        // ERA_GATEWAY_CHAIN_ID. Read from the upgrade input TOML ([legacy_gateway] section)
        // so the constructor gets the right value. Optional: absent on fresh/local.
        if (upgradeToml.keyExists("$.legacy_gateway.chain_id")) {
            config.legacyGatewayChainId = upgradeToml.readUint("$.legacy_gateway.chain_id");
        }

        coreAddresses.bridgehub.proxies.bridgehub = bridgehubProxyAddress;
        require(coreAddresses.bridgehub.proxies.bridgehub != address(0), "bridgehub_proxy_addr is zero");
        setAddressesBasedOnBridgehub();
        initializeL1CoreUtilsConfig();
    }

    function initializeL1CoreUtilsConfig() internal virtual {
        L1AssetRouter assetRouter = L1AssetRouter(coreAddresses.bridges.proxies.l1AssetRouter);
        L1Bridgehub bridgehub = L1Bridgehub(coreAddresses.bridgehub.proxies.bridgehub);
        Governance governance = Governance(payable(coreAddresses.shared.governance));
        config.l1ChainId = block.chainid;
        config.deployerAddress = getBroadcasterAddress();
        config.eraChainId = assetRouter.ERA_CHAIN_ID();
        config.eraDiamondProxyAddress = bridgehub.getZKChain(assetRouter.ERA_CHAIN_ID());

        config.ownerAddress = assetRouter.owner();

        config.contracts.governanceSecurityCouncilAddress = governance.securityCouncil();

        config.contracts.maxNumberOfChains = bridgehub.MAX_NUMBER_OF_ZK_CHAINS();

        config.tokens.tokenWethAddress = assetRouter.L1_WETH_TOKEN();
    }

    function setAddressesBasedOnBridgehub() internal virtual {
        address bridgehubProxy = coreAddresses.bridgehub.proxies.bridgehub;

        bool preV32Ecosystem;
        if (additionalConfig.hasPreV32IntrospectionOverride) {
            preV32Ecosystem = additionalConfig.usePreV32IntrospectionOverride;
        } else if (!AddressIntrospector.hasRegisteredChains(bridgehubProxy)) {
            // A chainless ecosystem has no protocol version to inspect. It cannot have been upgraded into
            // existence either, so it was deployed from scratch with the current contracts.
            preV32Ecosystem = false;
        } else {
            preV32Ecosystem = AddressIntrospector.shouldUsePreV32Introspection(bridgehubProxy);
        }

        if (preV32Ecosystem) {
            // v31 ecosystem: the nullifier has no `l1InteropHandler` getter yet, so the discovered
            // address stays zero and the upgrade deploys the handler itself.
            coreAddresses = AddressIntrospector.getCoreDeployedAddressesV31(bridgehubProxy);
        } else {
            coreAddresses = AddressIntrospector.getCoreDeployedAddresses(bridgehubProxy);
        }
    }

    function saveOutput(string memory outputPath) internal virtual {
        // Serialize bridgehub addresses
        vm.serializeAddress("bridgehub", "bridgehub_proxy_addr", coreAddresses.bridgehub.proxies.bridgehub);
        vm.serializeAddress(
            "bridgehub",
            "bridgehub_implementation_addr",
            coreAddresses.bridgehub.implementations.bridgehub
        );
        vm.serializeAddress(
            "bridgehub",
            "ctm_deployment_tracker_implementation_addr",
            coreAddresses.bridgehub.implementations.ctmDeploymentTracker
        );
        vm.serializeAddress(
            "bridgehub",
            "ctm_deployment_tracker_proxy_addr",
            coreAddresses.bridgehub.proxies.ctmDeploymentTracker
        );
        vm.serializeAddress(
            "bridgehub",
            "chain_asset_handler_implementation_addr",
            coreAddresses.bridgehub.implementations.chainAssetHandler
        );
        vm.serializeAddress(
            "bridgehub",
            "chain_asset_handler_proxy_addr",
            coreAddresses.bridgehub.proxies.chainAssetHandler
        );
        if (coreAddresses.bridgehub.proxies.chainRegistrationSender != address(0)) {
            require(
                coreAddresses.bridgehub.implementations.chainRegistrationSender != address(0),
                "chainRegistrationSenderImpl is zero"
            );
            vm.serializeAddress(
                "bridgehub",
                "chain_registration_sender_implementation_addr",
                coreAddresses.bridgehub.implementations.chainRegistrationSender
            );
            vm.serializeAddress(
                "bridgehub",
                "chain_registration_sender_proxy_addr",
                coreAddresses.bridgehub.proxies.chainRegistrationSender
            );
        }
        vm.serializeAddress("bridgehub", "message_root_proxy_addr", coreAddresses.bridgehub.proxies.messageRoot);
        string memory bridgehubSerialized = vm.serializeAddress(
            "bridgehub",
            "message_root_implementation_addr",
            coreAddresses.bridgehub.implementations.messageRoot
        );

        // Serialize bridges addresses
        vm.serializeAddress("bridges", "l1_nullifier_proxy_addr", coreAddresses.bridges.proxies.l1Nullifier);
        vm.serializeAddress(
            "bridges",
            "l1_nullifier_implementation_addr",
            coreAddresses.bridges.implementations.l1Nullifier
        );
        vm.serializeAddress(
            "bridges",
            "l1_asset_router_implementation_addr",
            coreAddresses.bridges.implementations.l1AssetRouter
        );
        vm.serializeAddress("bridges", "l1_asset_router_proxy_addr", coreAddresses.bridges.proxies.l1AssetRouter);
        // TODO: legacy name
        vm.serializeAddress(
            "bridges",
            "shared_bridge_implementation_addr",
            coreAddresses.bridges.implementations.l1AssetRouter
        );
        vm.serializeAddress(
            "bridges",
            "bridged_standard_erc20_impl",
            coreAddresses.bridges.bridgedStandardERC20Implementation
        );
        // Same keys as the from-scratch deployment writes, so downstream tooling reads one shape.
        vm.serializeAddress(
            "bridges",
            "l1_interop_handler_implementation_addr",
            coreAddresses.bridges.implementations.l1InteropHandler
        );
        vm.serializeAddress("bridges", "l1_interop_handler_proxy_addr", coreAddresses.bridges.proxies.l1InteropHandler);

        string memory bridgesSerialized = vm.serializeAddress(
            "bridges",
            "bridged_token_beacon",
            coreAddresses.bridges.bridgedTokenBeacon
        );

        vm.serializeString("deployed_addresses", "bridgehub", bridgehubSerialized);
        vm.serializeString("deployed_addresses", "bridges", bridgesSerialized);
        vm.serializeAddress(
            "deployed_addresses",
            "native_token_vault_addr",
            coreAddresses.bridges.proxies.l1NativeTokenVault
        );
        string memory deployedAddresses = vm.serializeAddress(
            "deployed_addresses",
            "native_token_vault_implementation_addr",
            coreAddresses.bridges.implementations.l1NativeTokenVault
        );

        string memory shared = vm.serializeAddress(
            "shared",
            "transparent_proxy_admin",
            coreAddresses.shared.transparentProxyAdmin
        );
        deployedAddresses = vm.serializeString("deployed_addresses", "shared", shared);

        string memory misc = vm.serializeAddress("misc", "deployer_addr", config.deployerAddress);
        vm.serializeString("root", "upgrade_addresses", deployedAddresses);
        string memory toml = vm.serializeString("root", "misc", misc);

        vm.writeToml(toml, outputPath);

        saveOutputVersionSpecific();
    }

    function saveOutputVersionSpecific() public virtual {}

    ////////////////////////////// Preparing calls /////////////////////////////////

    function prepareDefaultGovernanceCalls()
        public
        virtual
        returns (Call[] memory stage0Calls, Call[] memory stage1Calls, Call[] memory stage2Calls)
    {
        // Default upgrade is done it 3 stages:
        // 0. Pause migration to/from Gateway
        // 1. Perform upgrade
        // 2. Unpause migration to/from Gateway
        stage0Calls = prepareStage0GovernanceCalls();
        vm.serializeBytes("governance_calls", "stage0_calls", abi.encode(stage0Calls));
        stage1Calls = prepareStage1GovernanceCalls();
        vm.serializeBytes("governance_calls", "stage1_calls", abi.encode(stage1Calls));
        stage2Calls = prepareStage2GovernanceCalls();

        string memory governanceCallsSerialized = vm.serializeBytes(
            "governance_calls",
            "stage2_calls",
            abi.encode(stage2Calls)
        );

        vm.writeToml(governanceCallsSerialized, upgradeConfig.outputPath, ".governance_calls");
    }

    function prepareDefaultEcosystemAdminCalls() public virtual returns (Call[] memory calls) {
        // Empty by default.
        return calls;
    }

    function prepareUnpauseGatewayMigrationsCall() public view virtual returns (Call[] memory result) {
        require(coreAddresses.bridgehub.proxies.bridgehub != address(0), "bridgehubProxyAddress is zero in newConfig");

        result = new Call[](1);
        result[0] = Call({
            target: coreAddresses.bridgehub.proxies.chainAssetHandler,
            value: 0,
            data: abi.encodeCall(IChainAssetHandlerBase.unpauseMigration, ())
        });
    }

    /// @notice The zeroth step of upgrade. By default it just stops gateway migrations
    function prepareStage0GovernanceCalls() public virtual returns (Call[] memory calls) {
        Call[][] memory allCalls = new Call[][](3);

        allCalls[0] = preparePauseGatewayMigrationsCall();
        allCalls[1] = prepareVersionSpecificStage0GovernanceCallsL1();
        allCalls[2] = prepareDefaultEcosystemAdminCalls();

        calls = UpgradeUtils.mergeCallsArray(allCalls);
    }

    /// @notice The first step of upgrade. It upgrades the proxies and sets the new version upgrade
    function prepareStage1GovernanceCalls() public virtual returns (Call[] memory calls) {
        Call[][] memory allCalls = new Call[][](4);

        // Re-assert the migration pause as the first stage-1 call. When this upgrade is executed via the
        // EmergencyUpgradeBoard, PUH.executeEmergencyUpgrade runs a built-in unfreeze/unpause pre-step that
        // calls ChainAssetHandler.unpauseMigration(), clearing the pause set in stage 0; stage 1's
        // checkMigrationsPaused() would then revert with MigrationsNotPaused(). Harmless on the normal
        // governance path (the pause from stage 0 is simply re-asserted).
        allCalls[0] = preparePauseGatewayMigrationsCall();
        console.log("prepareStage1GovernanceCalls: prepareUpgradeProxiesCalls");
        allCalls[1] = prepareUpgradeProxiesCalls();
        allCalls[2] = provideSetNewVersionUpgradeCall();
        console.log("prepareStage1GovernanceCalls: prepareGatewaySpecificStage1GovernanceCalls");
        allCalls[3] = prepareVersionSpecificStage1GovernanceCallsL1();

        calls = UpgradeUtils.mergeCallsArray(allCalls);
    }

    /// @notice The second step of upgrade. By default it unpauses migrations.
    function prepareStage2GovernanceCalls() public virtual returns (Call[] memory calls) {
        Call[][] memory allCalls = new Call[][](2);

        allCalls[0] = prepareVersionSpecificStage2GovernanceCallsL1();
        allCalls[1] = prepareUnpauseGatewayMigrationsCall();

        calls = UpgradeUtils.mergeCallsArray(allCalls);
    }

    function prepareVersionSpecificStage0GovernanceCallsL1() public virtual returns (Call[] memory calls) {
        // Empty by default.
        return calls;
    }

    function prepareVersionSpecificStage1GovernanceCallsL1() public virtual returns (Call[] memory calls) {
        // Empty by default.
        return calls;
    }

    function prepareVersionSpecificStage2GovernanceCallsL1() public virtual returns (Call[] memory calls) {
        // Empty by default.
        return calls;
    }

    // TODO looks like we have to set it for bridgehub too
    function provideSetNewVersionUpgradeCall() public virtual returns (Call[] memory calls) {}

    function preparePauseGatewayMigrationsCall() public view virtual returns (Call[] memory result) {
        require(coreAddresses.bridgehub.proxies.chainAssetHandler != address(0), "chainAssetHandlerProxy is zero");

        result = new Call[](1);
        result[0] = Call({
            target: coreAddresses.bridgehub.proxies.chainAssetHandler,
            value: 0,
            data: abi.encodeCall(IChainAssetHandlerBase.pauseMigration, ())
        });
    }

    /// @notice Update implementations in proxies
    function prepareUpgradeProxiesCalls() public virtual returns (Call[] memory calls) {
        calls = new Call[](8);

        calls[0] = _buildCallProxyUpgrade(
            coreAddresses.bridgehub.proxies.bridgehub,
            coreAddresses.bridgehub.implementations.bridgehub
        );

        // Note, that we do not need to run the initializer
        calls[1] = _buildCallProxyUpgrade(
            coreAddresses.bridges.proxies.l1Nullifier,
            coreAddresses.bridges.implementations.l1Nullifier
        );

        calls[2] = _buildCallProxyUpgrade(
            coreAddresses.bridges.proxies.l1AssetRouter,
            coreAddresses.bridges.implementations.l1AssetRouter
        );

        calls[3] = _buildCallProxyUpgrade(
            coreAddresses.bridges.proxies.l1NativeTokenVault,
            coreAddresses.bridges.implementations.l1NativeTokenVault
        );

        // L1MessageRoot is a plain upgrade like the rest: v31's `initializeL1V31Upgrade` reinitializer was
        // removed in this release, and every ecosystem it can upgrade had already consumed that version.
        calls[4] = _buildCallProxyUpgrade(
            coreAddresses.bridgehub.proxies.messageRoot,
            coreAddresses.bridgehub.implementations.messageRoot
        );

        calls[5] = _buildCallProxyUpgrade(
            coreAddresses.bridgehub.proxies.ctmDeploymentTracker,
            coreAddresses.bridgehub.implementations.ctmDeploymentTracker
        );

        calls[6] = _buildCallProxyUpgrade(
            coreAddresses.bridgehub.proxies.chainAssetHandler,
            coreAddresses.bridgehub.implementations.chainAssetHandler
        );

        calls[7] = _buildCallProxyUpgrade(
            coreAddresses.bridgehub.proxies.chainRegistrationSender,
            coreAddresses.bridgehub.implementations.chainRegistrationSender
        );
    }

    function _buildCallProxyUpgrade(
        address proxyAddress,
        address newImplementationAddress
    ) internal virtual returns (Call memory call) {
        require(coreAddresses.shared.transparentProxyAdmin != address(0), "transparentProxyAdmin not newConfigured");

        call = Call({
            target: coreAddresses.shared.transparentProxyAdmin,
            data: abi.encodeCall(
                ProxyAdmin.upgrade,
                (ITransparentUpgradeableProxy(payable(proxyAddress)), newImplementationAddress)
            ),
            value: 0
        });
    }

    function _buildCallBeaconProxyUpgrade(
        address proxyAddress,
        address newImplementationAddress
    ) internal virtual returns (Call memory call) {
        call = Call({
            target: proxyAddress,
            data: abi.encodeCall(UpgradeableBeacon.upgradeTo, (newImplementationAddress)),
            value: 0
        });
    }

    // add this to be excluded from coverage report

    /// @notice Load protocol version from genesis config
    function loadProtocolVersionFromGenesis() internal virtual returns (uint256) {
        string memory genesisPath = Utils.genesisConfigPath(additionalConfig.isZKsyncOS);
        return
            ChainCreationParamsLib
                .getChainCreationParams(genesisPath, additionalConfig.isZKsyncOS)
                .latestProtocolVersion;
    }

    function getBroadcasterAddress() internal view virtual returns (address) {
        return tx.origin;
    }

    function test() internal override {}
}
