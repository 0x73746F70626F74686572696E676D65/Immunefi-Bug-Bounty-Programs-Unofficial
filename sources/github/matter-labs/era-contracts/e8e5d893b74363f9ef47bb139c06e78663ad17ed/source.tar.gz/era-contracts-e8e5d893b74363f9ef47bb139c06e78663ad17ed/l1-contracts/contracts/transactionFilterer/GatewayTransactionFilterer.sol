// SPDX-License-Identifier: MIT

pragma solidity 0.8.28;

import {Ownable2StepUpgradeable} from "@openzeppelin/contracts-upgradeable-v4/access/Ownable2StepUpgradeable.sol";

import {
    AlreadyDangerousContract,
    AlreadyWhitelisted,
    InvalidSelector,
    NotDangerousContract,
    NotWhitelisted,
    ZeroAddress
} from "../common/L1ContractErrors.sol";
import {L2_ASSET_ROUTER_ADDR, ZKSYNC_OS_DETERMINISTIC_CREATE2_ADDR} from "../common/l2-helpers/L2ContractAddresses.sol";
import {ITransactionFilterer} from "../state-transition/chain-interfaces/ITransactionFilterer.sol";
import {IBridgehubBase} from "../core/bridgehub/IBridgehubBase.sol";
import {AssetRouterBase} from "../bridge/asset-router/AssetRouterBase.sol";
import {IL2AssetRouter} from "../bridge/asset-router/IL2AssetRouter.sol";

/// @dev Calls to L2 contracts whose address is below this threshold are only allowed from whitelisted
/// senders. This covers the Era system-contract space (0x8000–0xffff, e.g. ContractDeployer) and
/// the Era built-in user-space contracts (0x10000–0x1ffff, e.g. the Era Create2Factory), which can
/// deploy arbitrary bytecode. Contracts predeployed during ZKsync OS genesis that sit *above* this
/// threshold (e.g. the Arachnid deterministic-deployment-proxy) are handled separately via the
/// `dangerousContracts` mapping.
address constant MIN_ALLOWED_ADDRESS = address(0x20000);

/// @author Matter Labs
/// @custom:security-contact security@matterlabs.dev
/// @dev Filters transactions received by the Mailbox
/// @dev Only allows whitelisted senders to deposit to Gateway
contract GatewayTransactionFilterer is ITransactionFilterer, Ownable2StepUpgradeable {
    /// @notice Event emitted when sender is whitelisted
    event WhitelistGranted(address indexed sender);

    /// @notice Event emitted when sender is removed from whitelist
    event WhitelistRevoked(address indexed sender);

    /// @notice Event emitted when a contract is added to the dangerous contracts list
    event DangerousContractAdded(address indexed contractAddress);

    /// @notice Event emitted when a contract is removed from the dangerous contracts list
    event DangerousContractRemoved(address indexed contractAddress);

    /// @notice The ecosystem's Bridgehub
    IBridgehubBase public immutable BRIDGE_HUB;

    /// @notice The L1 asset router
    address public immutable L1_ASSET_ROUTER;

    /// @notice Indicates whether the sender is whitelisted to deposit to Gateway
    mapping(address sender => bool whitelisted) public whitelistedSenders;

    /// @notice Contracts that may only be called by whitelisted senders, regardless of their address.
    /// @dev Used to restrict ZKsync OS genesis contracts that sit above MIN_ALLOWED_ADDRESS and
    /// would otherwise be freely callable. The Arachnid deterministic-deployment-proxy
    /// (ZKSYNC_OS_DETERMINISTIC_CREATE2_ADDR) is registered here during initialization.
    mapping(address contractAddress => bool isDangerous) public dangerousContracts;

    /// @dev Contract is expected to be used as proxy implementation.
    /// @dev Initialize the implementation to prevent Parity hack.
    constructor(IBridgehubBase _bridgeHub, address _assetRouter) {
        BRIDGE_HUB = _bridgeHub;
        L1_ASSET_ROUTER = _assetRouter;
        _disableInitializers();
    }

    /// @notice Initializes a contract filterer for later use. Expected to be used in the proxy.
    /// @param _owner The address which can upgrade the implementation.
    function initialize(address _owner) external initializer {
        if (_owner == address(0)) {
            revert ZeroAddress();
        }
        _transferOwnership(_owner);
        _initializeDangerousContracts();
    }

    /// @notice Whitelists the sender.
    /// @param sender Address of the tx sender.
    function grantWhitelist(address sender) external onlyOwner {
        if (whitelistedSenders[sender]) {
            revert AlreadyWhitelisted(sender);
        }
        whitelistedSenders[sender] = true;
        emit WhitelistGranted(sender);
    }

    /// @notice Revoke the sender from whitelist.
    /// @param sender Address of the tx sender.
    function revokeWhitelist(address sender) external onlyOwner {
        if (!whitelistedSenders[sender]) {
            revert NotWhitelisted(sender);
        }
        whitelistedSenders[sender] = false;
        emit WhitelistRevoked(sender);
    }

    /// @notice Adds a contract to the dangerous contracts list.
    /// @dev Dangerous contracts can only be called by whitelisted senders, regardless of their address.
    /// @param contractAddress The L2 address of the contract to mark as dangerous.
    function addDangerousContract(address contractAddress) external onlyOwner {
        if (dangerousContracts[contractAddress]) {
            revert AlreadyDangerousContract(contractAddress);
        }
        dangerousContracts[contractAddress] = true;
        emit DangerousContractAdded(contractAddress);
    }

    /// @notice Removes a contract from the dangerous contracts list.
    /// @param contractAddress The L2 address of the contract to unmark as dangerous.
    function removeDangerousContract(address contractAddress) external onlyOwner {
        if (!dangerousContracts[contractAddress]) {
            revert NotDangerousContract(contractAddress);
        }
        dangerousContracts[contractAddress] = false;
        emit DangerousContractRemoved(contractAddress);
    }

    /// @notice Checks if the transaction is allowed
    /// @param sender The sender of the transaction
    /// @param l2Calldata The calldata of the L2 transaction
    /// @return Whether the transaction is allowed
    function isTransactionAllowed(
        address sender,
        address contractL2,
        uint256,
        uint256,
        bytes calldata l2Calldata,
        address
    ) external view returns (bool) {
        if (sender == L1_ASSET_ROUTER) {
            bytes4 l2TxSelector = bytes4(l2Calldata[:4]);

            if (IL2AssetRouter.setAssetHandlerAddress.selector == l2TxSelector) {
                (, bytes32 decodedAssetId, ) = abi.decode(l2Calldata[4:], (uint256, bytes32, address));
                return _checkCTMAssetId(decodedAssetId);
            }

            if (AssetRouterBase.finalizeDeposit.selector != l2TxSelector) {
                revert InvalidSelector(l2TxSelector);
            }

            (, bytes32 decodedAssetId, ) = abi.decode(l2Calldata[4:], (uint256, bytes32, bytes));
            return _checkCTMAssetId(decodedAssetId);
        }

        // Dangerous contracts can only be called by whitelisted senders, even if their address
        // is above MIN_ALLOWED_ADDRESS.
        if (dangerousContracts[contractL2]) {
            return whitelistedSenders[sender];
        }

        // We always allow calls to the L2AssetRouter contract. We expect that it will not
        // cause deploying of any unwhitelisted code, but it is needed to facilitate withdrawals of chains.
        if (contractL2 > MIN_ALLOWED_ADDRESS || contractL2 == L2_ASSET_ROUTER_ADDR) {
            return true;
        }

        // Only whitelisted senders are allowed to use any built-in contracts.
        return whitelistedSenders[sender];
    }

    function _checkCTMAssetId(bytes32 assetId) internal view returns (bool) {
        address ctmAddress = BRIDGE_HUB.ctmAssetIdToAddress(assetId);
        return ctmAddress != address(0);
    }

    /// @dev Populates the initial set of dangerous contracts during initialization.
    /// Arachnid's deterministic-deployment-proxy (the standard EVM CREATE2 factory predeployed
    /// during ZKsync OS genesis) must be restricted because it allows arbitrary contract deployment,
    /// which must be gated to whitelisted senders on the Gateway.
    function _initializeDangerousContracts() internal {
        dangerousContracts[ZKSYNC_OS_DETERMINISTIC_CREATE2_ADDR] = true;
        emit DangerousContractAdded(ZKSYNC_OS_DETERMINISTIC_CREATE2_ADDR);
    }
}
