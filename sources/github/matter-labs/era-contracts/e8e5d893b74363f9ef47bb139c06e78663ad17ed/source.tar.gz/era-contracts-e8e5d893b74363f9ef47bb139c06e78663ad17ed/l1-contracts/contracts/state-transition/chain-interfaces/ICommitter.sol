// SPDX-License-Identifier: MIT
// We use a floating point pragma here so it can be used within other projects that interact with the ZKsync ecosystem without using our exact pragma version.
pragma solidity ^0.8.21;

import {IZKChainBase} from "./IZKChainBase.sol";
import {L2DACommitmentScheme} from "../../common/Config.sol";

/// @notice Data needed to commit new batch
/// @param batchNumber Number of the committed batch
/// @param timestamp Unix timestamp denoting the start of the batch execution
/// @param indexRepeatedStorageChanges The serial number of the shortcut index that's used as a unique identifier for storage keys that were used twice or more
/// @param newStateRoot The state root of the full state tree
/// @param numberOfLayer1Txs Number of priority operations to be processed
/// @param priorityOperationsHash Hash of all priority operations from this batch
/// @param bootloaderHeapInitialContentsHash Hash of the initial contents of the bootloader heap. In practice it serves as the commitment to the transactions in the batch.
/// @param eventsQueueStateHash Hash of the events queue state. In practice it serves as the commitment to the events in the batch.
/// @param systemLogs concatenation of all L2 -> L1 system logs in the batch
/// @param operatorDAInput Packed pubdata commitments/data.
/// @dev pubdataCommitments format: This will always start with a 1 byte pubdataSource flag. Current allowed values are 0 (calldata) or 1 (blobs)
///                             kzg: list of: opening point (16 bytes) || claimed value (32 bytes) || commitment (48 bytes) || proof (48 bytes) = 144 bytes
///                             calldata: pubdataCommitments.length - 1 - 32 bytes of pubdata
///                                       and 32 bytes appended to serve as the blob commitment part for the aux output part of the batch commitment
/// @dev For 2 blobs we will be sending 288 bytes of calldata instead of the full amount for pubdata.
/// @dev When using calldata, we only need to send one blob commitment since the max number of bytes in calldata fits in a single blob and we can pull the
///     linear hash from the system logs
struct CommitBatchInfo {
    uint64 batchNumber;
    uint64 timestamp;
    uint64 indexRepeatedStorageChanges;
    bytes32 newStateRoot;
    uint256 numberOfLayer1Txs;
    bytes32 priorityOperationsHash;
    bytes32 bootloaderHeapInitialContentsHash;
    bytes32 eventsQueueStateHash;
    bytes systemLogs;
    bytes operatorDAInput;
}

/// @notice Commit batch info for ZKsync OS
/// @param batchNumber Number of the committed batch
/// @param newStateCommitment State commitment of the new state.
/// @dev chain state commitment, this preimage is not opened on l1,
/// it's guaranteed that this commitment commits to any state that needed for execution
/// (state root, block number, block hashes)
/// @param numberOfLayer1Txs Number of priority operations to be processed
/// @param numberOfLayer2Txs Number of L2 transactions executed in the batch
/// @param priorityOperationsHash Hash of all priority operations from this batch
/// @param l2LogsTreeRoot Root hash of tree that contains L2 -> L1 messages from this batch
/// @param daCommitmentScheme commitment scheme used to generate pubdata commitment for this batch
/// @param daCommitment commitment to the batch pubdata to validate DA in the l1 da validator
// solhint-disable-next-line gas-struct-packing
struct CommitBatchInfoZKsyncOS {
    uint64 batchNumber;
    bytes32 newStateCommitment;
    uint256 numberOfLayer1Txs;
    uint256 numberOfLayer2Txs;
    bytes32 priorityOperationsHash;
    bytes32 dependencyRootsRollingHash;
    bytes32 l2LogsTreeRoot;
    L2DACommitmentScheme daCommitmentScheme;
    bytes32 daCommitment;
    uint64 firstBlockTimestamp;
    uint64 firstBlockNumber;
    uint64 lastBlockTimestamp;
    uint64 lastBlockNumber;
    uint256 chainId;
    bytes operatorDAInput;
    uint256 slChainId;
}

/// @notice Container for a list of transaction statuses to precommit.
/// @param txs A packed array of individual transaction status commitments for the batch. Each is expected to be
/// of length 33 and have the following format: <32-byte tx hash, 1-byte status>. where status is either 0 (failed) or 1 (success).
/// @param untrustedLastL2BlockNumberHint The "hint" for what the last L2 block number that these txs represent is.
struct PrecommitInfo {
    bytes packedTxsCommitments;
    uint256 untrustedLastL2BlockNumberHint;
}

/// @title The interface of the ZKsync Committer contract responsible for batch commitment operations.
/// @author Matter Labs
/// @custom:security-contact security@matterlabs.dev
interface ICommitter is IZKChainBase {
    /// @notice Precommits the status of all L2 transactions for the next batch on the shared bridge.
    /// @param _chainAddress The address of the DiamondProxy of the chain. Note, that it is not used in the implementation,
    /// because it is expected to be equal to the `address(this)`, but it is kept here to maintain the same interface on both
    /// `ValidatorTimelock` and `Executor` for easier and cheaper implementation of the timelock.
    /// @param _batchNumber The sequential batch number to precommit (must equal `s.totalBatchesCommitted + 1`).
    /// @param _precommitData ABI‐encoded transaction status list for the precommit.
    function precommitSharedBridge(address _chainAddress, uint256 _batchNumber, bytes calldata _precommitData) external;

    /// @notice Function called by the operator to commit new batches. It is responsible for:
    /// - Verifying the correctness of their timestamps.
    /// - Processing their L2->L1 logs.
    /// - Storing batch commitments.
    /// @param _chainAddress The address of the DiamondProxy of the chain. Note, that it is not used in the implementation,
    /// because it is expected to be equal to the `address(this)`, but it is kept here to maintain the same interface on both
    /// `ValidatorTimelock` and `Executor` for easier and cheaper implementation of the timelock.
    /// @param _processFrom The batch number from which the processing starts.
    /// @param _processTo The batch number at which the processing ends.
    /// @param _commitData The encoded data of the new batches to be committed.
    function commitBatchesSharedBridge(
        address _chainAddress,
        uint256 _processFrom,
        uint256 _processTo,
        bytes calldata _commitData
    ) external;

    /// @notice Event emitted when a batch is committed
    /// @param batchNumber Number of the batch committed
    /// @param batchHash Hash of the L2 batch
    /// @param commitment Calculated input for the ZKsync circuit
    /// @dev It has the name "BlockCommit" and not "BatchCommit" due to backward compatibility considerations
    event BlockCommit(uint256 indexed batchNumber, bytes32 indexed batchHash, bytes32 indexed commitment);

    /// @notice Reports the protocol version a batch was committed with, together with the system upgrade
    /// transaction hash applied in that batch (if any).
    /// @dev Emitted for every committed batch (both Era and ZKsync OS). For ZKsync OS the `upgradeTxHash` is
    /// additionally folded into the batch commitment, enabling independent recomputation of the commitment.
    /// @param batchNumber Number of the batch committed.
    /// @param protocolVersion The protocol version the batch was committed with.
    /// @param upgradeTxHash Hash of the system upgrade transaction applied in this batch; non-zero only for
    /// the first batch committed after a protocol upgrade.
    event ReportCommittedBatchProtocolVersion(
        uint64 indexed batchNumber,
        uint256 indexed protocolVersion,
        bytes32 indexed upgradeTxHash
    );

    /// @notice Emitted when a new precommitment is set for a batch.
    /// @param batchNumber The batch number for which the precommitment was recorded.
    /// @param untrustedLastL2BlockNumberHint The hint to what L2 block number the precommitment should correspond to. Note, that there are no
    /// guarantees on its correctness, it is just a way for the server to make external nodes' indexing simpler.
    /// @param precommitment The resulting rolling hash of all transaction statuses.
    event BatchPrecommitmentSet(
        uint256 indexed batchNumber,
        uint256 indexed untrustedLastL2BlockNumberHint,
        bytes32 precommitment
    );

    /// @notice Reports the block range for a zksync os batch.
    /// @dev IMPORTANT: in this release this range is not trusted and provided by the operator while not being included to the proof.
    event ReportCommittedBatchRangeZKsyncOS(
        uint64 indexed batchNumber,
        uint64 indexed firstBlockNumber,
        uint64 indexed lastBlockNumber
    );
}
