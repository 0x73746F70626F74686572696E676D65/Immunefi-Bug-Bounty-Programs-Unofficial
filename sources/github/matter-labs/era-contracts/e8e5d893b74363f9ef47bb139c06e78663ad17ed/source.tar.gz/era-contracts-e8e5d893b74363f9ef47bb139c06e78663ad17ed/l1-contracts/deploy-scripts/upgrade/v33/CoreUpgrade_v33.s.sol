// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

// solhint-disable no-console, gas-custom-errors

import {Script, console2 as console} from "forge-std/Script.sol";

import {IL1AssetRouter} from "contracts/bridge/asset-router/IL1AssetRouter.sol";
import {IL1Nullifier} from "contracts/bridge/interfaces/IL1Nullifier.sol";
import {L1InteropHandler} from "contracts/interop/interop-handler/L1InteropHandler.sol";

import {Call} from "contracts/governance/Common.sol";

import {DefaultCoreUpgrade} from "../default-upgrade/DefaultCoreUpgrade.s.sol";
import {BridgedOutPopulationLib} from "../default-upgrade/BridgedOutPopulationLib.sol";
import {ICoreUpgradeV33} from "contracts/script-interfaces/ICoreUpgradeV33.sol";
import {DeployL1CoreUtils} from "../../ecosystem/DeployL1CoreUtils.s.sol";

/// @notice Core (ecosystem-wide) half of the v33 upgrade flow. CTM-side deploys live in
///         `CTMUpgrade_v33`; the per-chain diamond cut is driven by `AdminFunctions.s.sol`.
///
/// @dev Everything generic lives in {DefaultCoreUpgrade}: the `noGovernancePrepare` entry point, the
///      refresh of all L1 core implementations, the stage-1 `ProxyAdmin.upgrade` calls that point the
///      core proxies at them. This file holds what is specific to v33: `L1InteropHandler`, which has
///      no proxy on an older ecosystem, and `stage3`'s `bridgedOut` population.
contract CoreUpgrade_v33 is Script, DefaultCoreUpgrade, ICoreUpgradeV33 {
    /// @dev Whether this run created the `L1InteropHandler` proxy, as opposed to finding one already
    ///      deployed. Gates the one-shot bridge setters in stage 1.
    bool internal deployedL1InteropHandler;

    /// @notice Post-governance step: populate `L1NativeTokenVault.bridgedOut` from the per-chain
    ///         legacy balances.
    /// @dev Runs after the governance stages and before the per-chain diamond cuts, so withdrawals on
    ///      each chain unblock as soon as its cut lands. Caller signs as any EOA — no governance
    ///      privileges needed — and the population is additive and resumable, so an interrupted run
    ///      can simply be repeated.
    function stage3(address bridgehubProxy) public virtual {
        console.log("Starting v33 stage3 post-governance bridgedOut population...");
        console.log("Bridgehub proxy:", bridgehubProxy);

        vm.startBroadcast();
        BridgedOutPopulationLib.populateBridgedOutForAllAssets(bridgehubProxy);
        vm.stopBroadcast();

        console.log("v33 stage3 bridgedOut population complete!");
    }

    /// @notice Deploy the interop handler, which this release introduces.
    /// @dev Two shapes have to work. Upgrading a v31 ecosystem, the intended production case, finds no
    ///      handler proxy and gets a fresh one that stage 1 wires into the bridges. An ecosystem that
    ///      already has the handler — a from-scratch deployment of these contracts, which the
    ///      integration suite upgrades in place, or a re-run — keeps its proxy, since that is where the
    ///      handler's state lives, and only has its implementation refreshed; the generic
    ///      `ProxyAdmin.upgrade` call in stage 1 points the proxy at it.
    /// @dev Ownership (fresh-deploy branch only): the proxy is initialized straight to governance via
    ///      the {getInitializeCalldata} override below, rather than to the deployer followed by a
    ///      transfer. `L1InteropHandler.initialize` sets the owner outright (`_transferOwnership`),
    ///      so there is no pending-owner step and nothing to accept in stage 1.
    ///      `Create2AndTransfer` does not apply here — it transfers from the CREATE2 deployer, which
    ///      only owns contracts that take ownership in their constructor (as `ProxyAdmin` does), not
    ///      a transparent proxy whose owner comes from an `initialize` call.
    function deployVersionSpecificEcosystemContractsL1() public virtual override {
        if (coreAddresses.bridges.proxies.l1InteropHandler == address(0)) {
            (
                coreAddresses.bridges.implementations.l1InteropHandler,
                coreAddresses.bridges.proxies.l1InteropHandler
            ) = deployTuppWithContract("L1InteropHandler", false);
            deployedL1InteropHandler = true;
        } else {
            coreAddresses.bridges.implementations.l1InteropHandler = deploySimpleContract("L1InteropHandler", false);
        }
    }

    /// @inheritdoc DeployL1CoreUtils
    /// @dev Hands the interop handler straight to governance; see {deployVersionSpecificEcosystemContractsL1}.
    ///      Every other contract keeps the shared deployment behaviour.
    function getInitializeCalldata(
        string memory contractName,
        bool isZKBytecode
    ) internal virtual override returns (bytes memory) {
        if (keccak256(bytes(contractName)) == keccak256(bytes("L1InteropHandler"))) {
            return abi.encodeCall(L1InteropHandler.initialize, (getOwnerAddress()));
        }
        return super.getInitializeCalldata(contractName, isZKBytecode);
    }

    /// @notice Stage-1 calls that wire a freshly deployed `L1InteropHandler` into the bridges.
    /// @dev Empty when the ecosystem already had a handler: both setters are one-shot, so re-issuing
    ///      them against an already-wired ecosystem would revert. Emitting them only for the branch of
    ///      {deployVersionSpecificEcosystemContractsL1} that created the proxy lets the same script
    ///      serve a v31 upgrade and a re-run.
    function prepareVersionSpecificStage1GovernanceCallsL1() public virtual override returns (Call[] memory calls) {
        // Checked before the early return: a zero address here means discovery failed to report the
        // handler, which is a broken run whether or not this script deployed it.
        address l1InteropHandlerProxy = coreAddresses.bridges.proxies.l1InteropHandler;
        require(l1InteropHandlerProxy != address(0), "L1InteropHandler proxy not deployed");

        if (!deployedL1InteropHandler) {
            return calls;
        }

        console.log("Wiring the freshly deployed L1InteropHandler:", l1InteropHandlerProxy);
        calls = new Call[](2);
        calls[0] = Call({
            target: coreAddresses.bridges.proxies.l1Nullifier,
            value: 0,
            data: abi.encodeCall(IL1Nullifier.setL1InteropHandler, (l1InteropHandlerProxy))
        });
        calls[1] = Call({
            target: coreAddresses.bridges.proxies.l1AssetRouter,
            value: 0,
            data: abi.encodeCall(IL1AssetRouter.setL1InteropHandler, (l1InteropHandlerProxy))
        });
    }
}
