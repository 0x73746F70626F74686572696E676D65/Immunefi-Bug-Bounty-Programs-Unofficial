// SPDX-License-Identifier: MIT

pragma solidity 0.8.24;

import {Test, console} from "forge-std/Test.sol";
import {Utils} from "../../Utils/Utils.sol";
import {RelayedSLDAValidator} from "contracts/state-transition/data-availability/RelayedSLDAValidator.sol";
import {L1DAValidatorOutput, PubdataSource} from "contracts/state-transition/chain-interfaces/IL1DAValidator.sol";
import {L2_TO_L1_MESSENGER_SYSTEM_CONTRACT_ADDR} from "contracts/common/L2ContractAddresses.sol";
import {IL1Messenger} from "contracts/common/interfaces/IL1Messenger.sol";

contract RelayedSLDAValidatorTest is Test {
    uint256 constant CHAIN_ID = 193;
    RelayedSLDAValidator daValidator;

    function setUp() public {
        daValidator = new RelayedSLDAValidator();
        vm.etch(L2_TO_L1_MESSENGER_SYSTEM_CONTRACT_ADDR, abi.encode(address(daValidator)));
        vm.mockCall(
            L2_TO_L1_MESSENGER_SYSTEM_CONTRACT_ADDR,
            abi.encodeWithSelector(IL1Messenger.sendToL1.selector),
            abi.encode(bytes32(0))
        );
    }

    /*//////////////////////////////////////////////////////////////////////////
                        RelayedSLDAValidator::checkDA
    //////////////////////////////////////////////////////////////////////////*/

    function test_RevertWhen_InvalidPubdataSource() public {
        bytes32 stateDiffHash = Utils.randomBytes32("stateDiffHash");
        bytes32 fullPubdataHash = Utils.randomBytes32("fullPubdataHash");
        uint8 blobsProvided = 1;
        uint256 maxBlobsSupported = 6;
        bytes32 blobLinearHash = Utils.randomBytes32("blobLinearHash");

        bytes memory daInput = abi.encodePacked(stateDiffHash, fullPubdataHash, blobsProvided, blobLinearHash);
        bytes memory l1DaInput = "verifydonttrust";

        bytes32 l2DAValidatorOutputHash = keccak256(daInput);

        bytes memory operatorDAInput = abi.encodePacked(daInput, l1DaInput);

        vm.expectRevert("l1-da-validator/invalid-pubdata-source");
        daValidator.checkDA(CHAIN_ID, l2DAValidatorOutputHash, operatorDAInput, maxBlobsSupported);
    }

    function test_revertWhen_PubdataInputTooSmall() public {
        bytes memory pubdata = "verifydont";
        console.logBytes(pubdata);

        bytes32 stateDiffHash = Utils.randomBytes32("stateDiffHash");
        uint8 blobsProvided = 1;
        uint256 maxBlobsSupported = 6;
        bytes32 blobLinearHash = Utils.randomBytes32("blobLinearHash");
        uint8 pubdataSource = uint8(PubdataSource.Calldata);
        bytes memory l1DaInput = "verifydonttrust";
        bytes32 fullPubdataHash = keccak256(pubdata);

        bytes memory daInput = abi.encodePacked(stateDiffHash, fullPubdataHash, blobsProvided, blobLinearHash);

        bytes32 l2DAValidatorOutputHash = keccak256(daInput);

        bytes memory operatorDAInput = abi.encodePacked(daInput, pubdataSource, l1DaInput);

        vm.expectRevert("pubdata too small");
        daValidator.checkDA(CHAIN_ID, l2DAValidatorOutputHash, operatorDAInput, maxBlobsSupported);
    }

    function test_checkDA() public {
        bytes memory pubdata = "verifydont";
        console.logBytes(pubdata);

        bytes32 stateDiffHash = Utils.randomBytes32("stateDiffHash");
        uint8 blobsProvided = 1;
        uint256 maxBlobsSupported = 6;
        bytes32 blobLinearHash = Utils.randomBytes32("blobLinearHash");
        uint8 pubdataSource = uint8(PubdataSource.Calldata);
        bytes memory l1DaInput = "verifydonttrustzkistheendgamemagicmoonmath";
        bytes32 fullPubdataHash = keccak256(pubdata);

        bytes memory daInput = abi.encodePacked(stateDiffHash, fullPubdataHash, blobsProvided, blobLinearHash);

        bytes32 l2DAValidatorOutputHash = keccak256(daInput);

        bytes memory operatorDAInput = abi.encodePacked(daInput, pubdataSource, l1DaInput);

        L1DAValidatorOutput memory output = daValidator.checkDA(
            CHAIN_ID,
            l2DAValidatorOutputHash,
            operatorDAInput,
            maxBlobsSupported
        );
        assertEq(output.stateDiffHash, stateDiffHash, "stateDiffHash");
        assertEq(output.blobsLinearHashes.length, maxBlobsSupported, "blobsLinearHashesLength");
        assertEq(output.blobsOpeningCommitments.length, maxBlobsSupported, "blobsOpeningCommitmentsLength");
    }
}
