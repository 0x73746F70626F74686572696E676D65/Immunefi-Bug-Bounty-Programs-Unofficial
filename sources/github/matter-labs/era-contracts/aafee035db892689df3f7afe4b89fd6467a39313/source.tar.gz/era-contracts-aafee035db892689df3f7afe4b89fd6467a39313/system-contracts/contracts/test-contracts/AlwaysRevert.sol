// SPDX-License-Identifier: MIT

pragma solidity ^0.8.0;

contract AlwaysRevert {
    fallback() external {
        revert("");
    }
}
