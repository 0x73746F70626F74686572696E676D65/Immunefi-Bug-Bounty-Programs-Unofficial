// SPDX-License-Identifier: MIT

pragma solidity ^0.8.13;

import "./interfaces/IAllowList.sol";

/// @author Matter Labs
abstract contract AllowListed {
    modifier senderCanCallFunction(IAllowList _allowList) {
        // Preventing the stack too deep error
        {
            require(_allowList.canCall(msg.sender, address(this), msg.sig), "nr");
        }
        _;
    }
}
