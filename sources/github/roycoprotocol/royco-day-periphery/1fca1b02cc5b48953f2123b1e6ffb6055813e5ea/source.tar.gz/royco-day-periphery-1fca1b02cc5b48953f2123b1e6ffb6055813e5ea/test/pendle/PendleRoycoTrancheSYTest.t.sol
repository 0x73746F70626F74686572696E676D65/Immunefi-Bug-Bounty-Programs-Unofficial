// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { Test } from "../../lib/forge-std/src/Test.sol";

import { ERC20Mock } from "../../lib/openzeppelin-contracts/contracts/mocks/token/ERC20Mock.sol";

import { IRoycoFactory } from "../../lib/royco-day/src/interfaces/factory/IRoycoFactory.sol";
import { AssetClaims, TrancheType } from "../../lib/royco-day/src/libraries/Types.sol";
import { toNAVUnits, toTrancheUnits } from "../../lib/royco-day/src/libraries/Units.sol";
import { PendleERC20SYUpgV2, PendleRoycoTrancheSY } from "../../src/pendle/PendleRoycoTrancheSY.sol";
import { PendleRoycoTrancheSYFactory } from "../../src/pendle/PendleRoycoTrancheSYFactory.sol";

import { MockDayKernel } from "../mock/MockDayKernel.sol";
import { MockRoycoFactory } from "../mock/MockRoycoFactory.sol";
import { MockTranche } from "../mock/MockTranche.sol";

/// @title PendleRoycoTrancheSYTest
/// @notice Audit-grade unit tests for PendleRoycoTrancheSY (proxy-initialized via PendleRoycoTrancheSYFactory)
contract PendleRoycoTrancheSYTest is Test {
    /// =====================================================================
    /// CONSTANTS
    /// =====================================================================
    address internal constant PENDLE_PAUSE_CONTROLLER = 0x2aD631F72fB16d91c4953A7f4260A97C2fE2f31e;
    /// @dev IStandardizedYield.AssetType { TOKEN = 0, LIQUIDITY = 1 }
    uint8 internal constant ASSET_TYPE_LIQUIDITY = 1;
    /// @dev PMath.ONE — Pendle's WAD constant; SY exchange rate is denominated per 1e18 SY wei
    uint256 internal constant PMATH_ONE = 1e18;

    /// =====================================================================
    /// STATE
    /// =====================================================================
    ERC20Mock internal asset;
    MockRoycoFactory internal mockRoycoFactory;
    MockDayKernel internal mockDayKernel;
    MockTranche internal seniorTranche;
    MockTranche internal juniorTranche;
    PendleRoycoTrancheSYFactory internal syFactory;

    PendleRoycoTrancheSY internal sy; // proxy-deployed, owned by PENDLE_PAUSE_CONTROLLER
    address internal kernel = makeAddr("kernel");
    address internal trancheAuthority = makeAddr("trancheAuthority");
    address internal rewardManager = makeAddr("rewardManager");

    /// =====================================================================
    /// SETUP
    /// =====================================================================

    function setUp() public {
        asset = new ERC20Mock();
        mockRoycoFactory = new MockRoycoFactory();
        mockDayKernel = new MockDayKernel();

        // The SY caches the tranche's kernel at construction, so the kernel must be wired before any SY deploys.
        seniorTranche = new MockTranche(address(asset), trancheAuthority, TrancheType.SENIOR);
        juniorTranche = new MockTranche(address(asset), trancheAuthority, TrancheType.JUNIOR);
        seniorTranche.setKernel(address(mockDayKernel));
        juniorTranche.setKernel(address(mockDayKernel));
        mockRoycoFactory.registerTranche(address(seniorTranche), kernel);
        mockRoycoFactory.registerTranche(address(juniorTranche), kernel);

        syFactory = new PendleRoycoTrancheSYFactory(IRoycoFactory(address(mockRoycoFactory)));
        sy = PendleRoycoTrancheSY(payable(syFactory.deploySY(address(seniorTranche), rewardManager)));
    }

    /// =====================================================================
    /// IMPLEMENTATION-LEVEL CONSTRUCTOR WIRING
    /// =====================================================================

    function test_constructor_implementation_setsYieldToken() public {
        // Direct (non-proxy) deploy of the implementation: yieldToken should be the tranche.
        PendleRoycoTrancheSY impl = new PendleRoycoTrancheSY(address(seniorTranche), rewardManager);
        assertEq(impl.yieldToken(), address(seniorTranche));
    }

    function test_constructor_implementation_setsOffchainRewardManager() public {
        PendleRoycoTrancheSY impl = new PendleRoycoTrancheSY(address(seniorTranche), rewardManager);
        assertEq(impl.offchainRewardManager(), rewardManager);
    }

    function test_constructor_implementation_zeroRewardManagerAllowed() public {
        PendleRoycoTrancheSY impl = new PendleRoycoTrancheSY(address(seniorTranche), address(0));
        assertEq(impl.offchainRewardManager(), address(0));
    }

    function test_constructor_implementation_decimalsMatchYieldToken() public {
        PendleRoycoTrancheSY impl = new PendleRoycoTrancheSY(address(seniorTranche), rewardManager);
        assertEq(impl.decimals(), seniorTranche.decimals());
    }

    function test_constructor_implementation_disableInitializers() public {
        // SYBaseUpgV2 calls _disableInitializers() in its constructor: direct init of the impl must revert.
        PendleRoycoTrancheSY impl = new PendleRoycoTrancheSY(address(seniorTranche), rewardManager);
        vm.expectRevert();
        impl.initialize("name", "symbol", address(this));
    }

    /// =====================================================================
    /// PROXY-INITIALIZED STATE
    /// =====================================================================

    function test_proxy_nameAndSymbol() public view {
        assertEq(sy.name(), string.concat("SY ", seniorTranche.name()));
        assertEq(sy.symbol(), string.concat("SY-", seniorTranche.symbol()));
    }

    function test_proxy_owner() public view {
        assertEq(sy.owner(), PENDLE_PAUSE_CONTROLLER);
    }

    function test_proxy_yieldTokenIsTranche() public view {
        assertEq(sy.yieldToken(), address(seniorTranche));
    }

    function test_proxy_offchainRewardManagerIsBaked() public view {
        assertEq(sy.offchainRewardManager(), rewardManager);
    }

    function test_proxy_decimalsMatchTranche() public view {
        assertEq(sy.decimals(), seniorTranche.decimals());
    }

    function test_proxy_cannotReinitialize() public {
        vm.expectRevert();
        sy.initialize("Other", "OTH", address(this));
    }

    function test_proxy_initialSupplyZero() public view {
        assertEq(sy.totalSupply(), 0);
    }

    /// =====================================================================
    /// exchangeRate (kernel preview + virtual-shares scaling)
    /// =====================================================================
    /// @dev The SY prices via the kernel's preview sync, not the tranche's own quote: the tranche conservatively
    ///      excludes the LPT's idle liquidity-premium senior shares, so its quote would flatline the rate while
    ///      premium accrues and step it at reinvestment; the kernel preview's claims carry the effective NAV so the
    ///      rate accrues premium continuously

    /**
     * @dev Sets the kernel preview so the virtual-shares rate is exact. The SY scales the previewed claims through
     *      day's primitive: rate = floor((claims.nav + 1) * 1e18 / (totalTrancheShares + 1)). With
     *      totalTrancheShares = 1e18 - 1 and claims.nav = p - 1, the rate is floor(p * 1e18 / 1e18) == p exactly
     *      for any p >= 1.
     */
    function _setPreviewForExactRate(uint256 _rateWAD) internal {
        AssetClaims memory claims;
        claims.nav = toNAVUnits(_rateWAD - 1);
        mockDayKernel.setPreview(claims, 1e18 - 1);
    }

    function test_exchangeRate_atParity() public {
        _setPreviewForExactRate(PMATH_ONE);
        assertEq(sy.exchangeRate(), PMATH_ONE);
    }

    function test_exchangeRate_aboveAndBelowPar() public {
        _setPreviewForExactRate(2e18); // 2x par
        assertEq(sy.exchangeRate(), 2 * PMATH_ONE);

        _setPreviewForExactRate(0.5e18); // 0.5x par
        assertEq(sy.exchangeRate(), PMATH_ONE / 2);
    }

    /// @notice With zero tranche supply the virtual-shares primitive returns zero claims (rate contributions), so the
    ///         rate is 0 even when the previewed NAV is nonzero
    function test_exchangeRate_zeroTrancheSupply_isZero() public {
        AssetClaims memory claims;
        claims.nav = toNAVUnits(uint256(5e18));
        mockDayKernel.setPreview(claims, 0);
        assertEq(sy.exchangeRate(), 0);
    }

    /// @notice Raising the previewed claims.nav against a fixed supply strictly raises the rate
    function test_exchangeRate_monotonicInPreviewedNav() public {
        uint256[4] memory navs = [uint256(1e18), 2e18, 3e18, 10e18];
        uint256 lastRate;
        for (uint256 i = 0; i < navs.length; i++) {
            AssetClaims memory claims;
            claims.nav = toNAVUnits(navs[i]);
            mockDayKernel.setPreview(claims, 1e18);
            uint256 rate = sy.exchangeRate();
            assertGt(rate, lastRate, "The rate must strictly rise with the previewed NAV at a fixed supply");
            lastRate = rate;
        }
    }

    /**
     * @notice The LPT rationale end-to-end: the kernel preview's claims carry the effective NAV, so a growing NAV
     *         over an identical LPT asset depth (premium accruing while raw depth is flat) grows the rate
     *         continuously. The tranche's own quote excludes the idle liquidity-premium senior shares, which would
     *         flatline the rate here and step it only at reinvestment.
     */
    function test_exchangeRate_premiumAccrual_growsRateWhileLptDepthFlat() public {
        AssetClaims memory claims;
        claims.lptAssets = toTrancheUnits(uint256(100e18));
        claims.nav = toNAVUnits(uint256(100e18));
        mockDayKernel.setPreview(claims, 100e18);
        uint256 rateBefore = sy.exchangeRate();

        // Premium accrues: the effective NAV grows while the LPT's raw asset depth is unchanged.
        claims.nav = toNAVUnits(uint256(105e18));
        mockDayKernel.setPreview(claims, 100e18);
        uint256 rateAfter = sy.exchangeRate();

        assertGt(rateAfter, rateBefore, "Accruing premium must grow the rate even while the LPT's raw depth is flat");
    }

    /// @notice Fuzz: the rate equals day's virtual-shares primitive floor((nav + 1) * 1e18 / (supply + 1)) verbatim,
    ///         and zero supply short-circuits to a zero rate
    /// @param _nav The previewed claims.nav over a wide domain
    /// @param _totalTrancheShares The previewed post-mint tranche share supply over a wide domain
    function testFuzz_exchangeRate_matchesVirtualSharesPrimitive(uint256 _nav, uint256 _totalTrancheShares) public {
        _nav = bound(_nav, 0, type(uint128).max);
        _totalTrancheShares = bound(_totalTrancheShares, 0, type(uint128).max);

        AssetClaims memory claims;
        claims.nav = toNAVUnits(_nav);
        mockDayKernel.setPreview(claims, _totalTrancheShares);

        uint256 expected = _totalTrancheShares == 0 ? 0 : (_nav + 1) * PMATH_ONE / (_totalTrancheShares + 1);
        assertEq(sy.exchangeRate(), expected);
    }

    /// =====================================================================
    /// assetInfo
    /// =====================================================================

    function test_assetInfo_returnsLiquidityAndTrancheAndDecimals() public view {
        (PendleERC20SYUpgV2.AssetType assetType, address assetAddress, uint8 assetDecimals) = sy.assetInfo();
        assertEq(uint8(assetType), ASSET_TYPE_LIQUIDITY);
        assertEq(assetAddress, address(seniorTranche));
        assertEq(assetDecimals, seniorTranche.decimals());
    }

    /// =====================================================================
    /// OWNER-ONLY (BoringOwnable: pause/unpause/transferOwnership)
    /// =====================================================================

    function test_pause_onlyOwner() public {
        vm.prank(PENDLE_PAUSE_CONTROLLER);
        sy.pause();
        assertTrue(sy.paused());
    }

    function test_pause_revertsForNonOwner() public {
        vm.expectRevert(bytes("Ownable: caller is not the owner"));
        sy.pause();
    }

    function test_unpause_onlyOwner() public {
        vm.startPrank(PENDLE_PAUSE_CONTROLLER);
        sy.pause();
        sy.unpause();
        vm.stopPrank();
        assertFalse(sy.paused());
    }

    function test_transferOwnership_directOnlyOwner() public {
        address newOwner = makeAddr("newOwner");

        vm.prank(PENDLE_PAUSE_CONTROLLER);
        sy.transferOwnership(newOwner, true, false);

        assertEq(sy.owner(), newOwner);
        assertEq(sy.pendingOwner(), address(0));
    }

    function test_transferOwnership_pendingPathRequiresClaim() public {
        address newOwner = makeAddr("newOwner");

        vm.prank(PENDLE_PAUSE_CONTROLLER);
        sy.transferOwnership(newOwner, false, false);

        // Owner unchanged until claim.
        assertEq(sy.owner(), PENDLE_PAUSE_CONTROLLER);
        assertEq(sy.pendingOwner(), newOwner);

        // Random caller cannot claim.
        vm.expectRevert(bytes("Ownable: caller != pending owner"));
        sy.claimOwnership();

        vm.prank(newOwner);
        sy.claimOwnership();
        assertEq(sy.owner(), newOwner);
    }

    function test_transferOwnership_revertsForNonOwner() public {
        vm.expectRevert(bytes("Ownable: caller is not the owner"));
        sy.transferOwnership(makeAddr("notOwner"), true, false);
    }

    /// =====================================================================
    /// REWARD INTERFACE (PendleERC20SYUpgV2 defaults)
    /// =====================================================================

    function test_rewards_defaultEmpty() public {
        assertEq(sy.getRewardTokens().length, 0);
        assertEq(sy.accruedRewards(makeAddr("user")).length, 0);
    }

    function test_claimOffchainRewards_onlyOffchainRewardManager() public {
        // claimOffchainRewards is gated to offchainRewardManager; non-manager calls revert.
        address[] memory empty = new address[](0);
        uint256[] memory amounts = new uint256[](0);
        bytes32[][] memory proofs = new bytes32[][](0);

        vm.expectRevert(bytes("MRA: unauthorized"));
        sy.claimOffchainRewards(makeAddr("recipient"), empty, empty, amounts, proofs);
    }
}
