// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { Test } from "../../lib/forge-std/src/Test.sol";
import { FundamentalStablecoinChainlinkOracle } from "../../src/oracle/fundamental-oracle/FundamentalStablecoinChainlinkOracle.sol";
import { FundamentalStablecoinChainlinkOracleFactory } from "../../src/oracle/fundamental-oracle/FundamentalStablecoinChainlinkOracleFactory.sol";
import { MockChainlinkOracle } from "./FundamentalStablecoinChainlinkOracleTest.t.sol";

/// @title FundamentalStablecoinChainlinkOracleFactoryTest
/// @notice Unit tests for the permissionless fundamental peg oracle factory
contract FundamentalStablecoinChainlinkOracleFactoryTest is Test {
    FundamentalStablecoinChainlinkOracleFactory internal oracleFactory;
    MockChainlinkOracle internal underlyingOracle;

    /// @dev 0.99 in the mock underlying's 8 decimal precision
    int256 internal constant MIN_PRICE_AT_PEG = 0.99e8;

    event OracleDeployed(address indexed oracle, int256 minPriceAtPeg, address indexed pegOracle);

    function setUp() public {
        oracleFactory = new FundamentalStablecoinChainlinkOracleFactory();
        underlyingOracle = new MockChainlinkOracle(8, "USDC / USD");
    }

    /// @notice A deployed peg oracle is wired to the underlying oracle, recorded in the registry, and anchors at-peg prices
    function test_deployOracle_deploysFunctionalPegOracle() public {
        address pegOracle = oracleFactory.deployOracle(address(underlyingOracle), MIN_PRICE_AT_PEG);

        assertEq(oracleFactory.oracleToMinPriceAtPegToPegOracle(address(underlyingOracle), MIN_PRICE_AT_PEG), pegOracle);
        assertEq(FundamentalStablecoinChainlinkOracle(pegOracle).ORACLE(), address(underlyingOracle));
        assertEq(FundamentalStablecoinChainlinkOracle(pegOracle).MIN_PRICE_AT_PEG(), MIN_PRICE_AT_PEG);

        // An at-peg report anchors to exactly 1 quote asset in the underlying oracle's precision
        underlyingOracle.setAnswer(0.995e8);
        (, int256 answer,,,) = FundamentalStablecoinChainlinkOracle(pegOracle).latestRoundData();
        assertEq(answer, 1e8);
    }

    /// @notice The deployed address matches the prediction
    function test_deployOracle_matchesPrediction() public {
        address predicted = oracleFactory.predictOracleAddress(address(underlyingOracle), MIN_PRICE_AT_PEG);
        assertEq(oracleFactory.deployOracle(address(underlyingOracle), MIN_PRICE_AT_PEG), predicted);
    }

    /// @notice The deployment event carries the underlying oracle, the peg price, and the deployed peg oracle
    function test_deployOracle_emitsEvent() public {
        address predicted = oracleFactory.predictOracleAddress(address(underlyingOracle), MIN_PRICE_AT_PEG);
        vm.expectEmit(true, true, true, true, address(oracleFactory));
        emit OracleDeployed(address(underlyingOracle), MIN_PRICE_AT_PEG, predicted);
        oracleFactory.deployOracle(address(underlyingOracle), MIN_PRICE_AT_PEG);
    }

    /// @notice Distinct peg prices for one underlying oracle deploy distinct peg oracles, both registered
    function test_deployOracle_distinctPegPricesDeployDistinctPegOracles() public {
        address pegOracleA = oracleFactory.deployOracle(address(underlyingOracle), MIN_PRICE_AT_PEG);
        address pegOracleB = oracleFactory.deployOracle(address(underlyingOracle), 0.98e8);

        assertTrue(pegOracleA != pegOracleB);
        assertEq(oracleFactory.oracleToMinPriceAtPegToPegOracle(address(underlyingOracle), MIN_PRICE_AT_PEG), pegOracleA);
        assertEq(oracleFactory.oracleToMinPriceAtPegToPegOracle(address(underlyingOracle), 0.98e8), pegOracleB);
    }

    /// @notice A duplicate deployment for the same (underlying oracle, peg price) pair reverts on the CREATE2 collision
    function test_deployOracle_duplicateReverts() public {
        oracleFactory.deployOracle(address(underlyingOracle), MIN_PRICE_AT_PEG);
        vm.expectRevert();
        oracleFactory.deployOracle(address(underlyingOracle), MIN_PRICE_AT_PEG);
    }

    /// @notice A codeless underlying oracle is rejected by the peg oracle's construction, which probes its decimals
    function test_deployOracle_revertsForCodelessUnderlyingOracle() public {
        vm.expectRevert();
        oracleFactory.deployOracle(makeAddr("CODELESS_ORACLE"), MIN_PRICE_AT_PEG);
    }

    /// @notice A peg price outside (0, 1 quote asset) is rejected by the peg oracle's construction
    function test_deployOracle_revertsForInvalidMinPriceAtPeg() public {
        vm.expectRevert(FundamentalStablecoinChainlinkOracle.INVALID_MIN_PRICE_AT_PEG.selector);
        oracleFactory.deployOracle(address(underlyingOracle), 0);

        vm.expectRevert(FundamentalStablecoinChainlinkOracle.INVALID_MIN_PRICE_AT_PEG.selector);
        oracleFactory.deployOracle(address(underlyingOracle), 1e8);
    }

    /// @notice The prediction is pure over its inputs: identical inputs predict identical addresses without deploying
    function testFuzz_predictOracleAddress_isDeterministicAcrossInputs(address _oracle, int256 _minPriceAtPeg) public view {
        assertEq(oracleFactory.predictOracleAddress(_oracle, _minPriceAtPeg), oracleFactory.predictOracleAddress(_oracle, _minPriceAtPeg));
    }
}
