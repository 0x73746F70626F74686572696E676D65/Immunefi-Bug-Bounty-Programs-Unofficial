// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { Test } from "../../lib/forge-std/src/Test.sol";

import { ERC20Mock } from "../../lib/openzeppelin-contracts/contracts/mocks/token/ERC20Mock.sol";
import { ShortStrings } from "../../lib/openzeppelin-contracts/contracts/utils/ShortStrings.sol";

import { IRoycoVaultTranche } from "../../lib/royco-day/src/interfaces/IRoycoVaultTranche.sol";
import { WAD, WAD_DECIMALS } from "../../lib/royco-day/src/libraries/Constants.sol";
import { TrancheType } from "../../lib/royco-day/src/libraries/Types.sol";
import { RoycoTrancheChainlinkOracle } from "../../src/oracle/tranche-share-to-nav-oracle/RoycoTrancheChainlinkOracle.sol";

import { MockTranche } from "../mock/MockTranche.sol";

/// @title RoycoTrancheChainlinkOracleTest
/// @notice Unit tests for RoycoTrancheChainlinkOracle backed by MockTranche
/// @dev MockTranche.convertToAssets(s) = s * sharePriceWAD / 1e18, so for s = WAD the oracle answer
///      is exactly the configured sharePriceWAD. This lets us drive the oracle's output deterministically.
contract RoycoTrancheChainlinkOracleTest is Test {
    /// =====================================================================
    /// STATE
    /// =====================================================================
    ERC20Mock internal asset;
    MockTranche internal seniorTranche;
    MockTranche internal juniorTranche;
    RoycoTrancheChainlinkOracle internal stOracle;
    RoycoTrancheChainlinkOracle internal jtOracle;

    address internal constant FACTORY_PLACEHOLDER = address(0xF);

    /// @dev The NAV asset symbol fixture used for every oracle in this suite
    string internal constant NAV_ASSET = "USD";

    /// =====================================================================
    /// SETUP
    /// =====================================================================

    function setUp() public {
        asset = new ERC20Mock();
        seniorTranche = new MockTranche(address(asset), FACTORY_PLACEHOLDER, TrancheType.SENIOR);
        juniorTranche = new MockTranche(address(asset), FACTORY_PLACEHOLDER, TrancheType.JUNIOR);
        stOracle = new RoycoTrancheChainlinkOracle(address(seniorTranche), NAV_ASSET);
        jtOracle = new RoycoTrancheChainlinkOracle(address(juniorTranche), NAV_ASSET);
    }

    /// =====================================================================
    /// CONSTRUCTOR
    /// =====================================================================

    function test_constructor_setsImmutable() public view {
        assertEq(stOracle.ROYCO_TRANCHE(), address(seniorTranche));
        assertEq(jtOracle.ROYCO_TRANCHE(), address(juniorTranche));
    }

    function test_constructor_navAssetRoundTrips() public view {
        // The NAV asset symbol survives the ShortString pack/unpack round-trip byte-for-byte.
        assertEq(stOracle.NAV_ASSET(), NAV_ASSET);
        assertEq(jtOracle.NAV_ASSET(), NAV_ASSET);
    }

    function test_constructor_revertsOnEmptyNavAsset() public {
        vm.expectRevert(RoycoTrancheChainlinkOracle.NULL_NAV_ASSET.selector);
        new RoycoTrancheChainlinkOracle(address(seniorTranche), "");
    }

    function test_constructor_revertsOnNavAssetOverThirtyOneBytes() public {
        // 32 bytes is the first length the ShortString packing rejects.
        string memory tooLong = "ABCDEFGHIJKLMNOPQRSTUVWXYZ012345";
        vm.expectRevert(abi.encodeWithSelector(ShortStrings.StringTooLong.selector, tooLong));
        new RoycoTrancheChainlinkOracle(address(seniorTranche), tooLong);
    }

    function test_constructor_acceptsThirtyOneByteNavAsset() public {
        // 31 bytes is the largest symbol the ShortString packing admits.
        string memory boundary = "ABCDEFGHIJKLMNOPQRSTUVWXYZ01234";
        RoycoTrancheChainlinkOracle boundaryOracle = new RoycoTrancheChainlinkOracle(address(seniorTranche), boundary);
        assertEq(boundaryOracle.NAV_ASSET(), boundary);
    }

    /// =====================================================================
    /// METADATA: decimals / version / description
    /// =====================================================================

    function test_decimals_isWAD() public view {
        assertEq(stOracle.decimals(), uint8(WAD_DECIMALS));
        assertEq(jtOracle.decimals(), uint8(WAD_DECIMALS));
    }

    function test_version_isOne() public view {
        assertEq(stOracle.version(), 1);
        assertEq(jtOracle.version(), 1);
    }

    function test_description_seniorComposesBaseQuotePair() public view {
        // Chainlink base/quote convention: `<tranche symbol> / <NAV asset>` with the MockTranche senior symbol MST.
        assertEq(stOracle.description(), "MST / USD");
        assertEq(stOracle.description(), string(abi.encodePacked(seniorTranche.symbol(), " / ", NAV_ASSET)));
    }

    function test_description_juniorComposesBaseQuotePair() public view {
        // Chainlink base/quote convention: `<tranche symbol> / <NAV asset>` with the MockTranche junior symbol MJT.
        assertEq(jtOracle.description(), "MJT / USD");
        assertEq(jtOracle.description(), string(abi.encodePacked(juniorTranche.symbol(), " / ", NAV_ASSET)));
    }

    function test_description_readsLiveTrancheSymbol() public {
        // description() reads the tranche's symbol at every call rather than freezing it at construction.
        vm.mockCall(address(seniorTranche), abi.encodeWithSignature("symbol()"), abi.encode("MST2"));
        assertEq(stOracle.description(), "MST2 / USD");
    }

    function test_description_propagatesSymbolRevert() public {
        // Unlike latestRoundData, description() does NOT wrap in try/catch. A reverting symbol() must surface.
        vm.mockCallRevert(address(seniorTranche), abi.encodeWithSignature("symbol()"), "symbol failed");

        vm.expectRevert(bytes("symbol failed"));
        stOracle.description();
    }

    /// =====================================================================
    /// latestRoundData
    /// =====================================================================

    function test_latestRoundData_initialPriceIsOne() public view {
        (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound) = stOracle.latestRoundData();
        assertEq(roundId, 1);
        assertEq(answer, int256(WAD));
        assertEq(startedAt, block.timestamp);
        assertEq(updatedAt, block.timestamp);
        assertEq(answeredInRound, 1);
    }

    function test_latestRoundData_reflectsYield() public {
        seniorTranche.simulateYield(0.1e18); // +10%

        (, int256 answer,,,) = stOracle.latestRoundData();
        assertEq(answer, int256(uint256(1.1e18)));
    }

    function test_latestRoundData_reflectsLoss() public {
        seniorTranche.simulateLoss(0.25e18); // -25%

        (, int256 answer,,,) = stOracle.latestRoundData();
        assertEq(answer, int256(uint256(0.75e18)));
    }

    function test_latestRoundData_followsExplicitSharePrice() public {
        seniorTranche.setSharePrice(2.5e18);

        (, int256 answer,,,) = stOracle.latestRoundData();
        assertEq(answer, int256(uint256(2.5e18)));
    }

    function test_latestRoundData_timestampsTrackBlockTime() public {
        uint256 future = block.timestamp + 7 days;
        vm.warp(future);

        (,, uint256 startedAt, uint256 updatedAt,) = stOracle.latestRoundData();
        assertEq(startedAt, future);
        assertEq(updatedAt, future);
    }

    function test_latestRoundData_recomputesEveryCall() public {
        (, int256 answerBefore,,,) = stOracle.latestRoundData();
        assertEq(answerBefore, int256(WAD));

        seniorTranche.simulateYield(0.5e18); // +50%

        (, int256 answerAfter,,,) = stOracle.latestRoundData();
        assertEq(answerAfter, int256(uint256(1.5e18)));
        assertGt(answerAfter, answerBefore);
    }

    function test_latestRoundData_juniorTrancheIndependent() public {
        seniorTranche.simulateYield(0.2e18); // ST only
        juniorTranche.simulateLoss(0.1e18); // JT only

        (, int256 stAnswer,,,) = stOracle.latestRoundData();
        (, int256 jtAnswer,,,) = jtOracle.latestRoundData();

        assertEq(stAnswer, int256(uint256(1.2e18)));
        assertEq(jtAnswer, int256(uint256(0.9e18)));
    }

    function test_latestRoundData_bubblesTrancheRevertReason() public {
        // Simulate any downstream failure (paused kernel, stale chainlink, quoter revert, etc.)
        // The oracle reads NAV via Day's typed tranche interface, which bubbles up the tranche's revert reason
        // rather than rewrapping it as "No data present"
        vm.mockCallRevert(address(seniorTranche), abi.encodeWithSelector(IRoycoVaultTranche.convertToAssets.selector, WAD), "downstream");

        vm.expectRevert(bytes("downstream"));
        stOracle.latestRoundData();
    }

    function test_latestRoundData_bubblesEmptyTrancheRevert() public {
        // An empty revert from the underlying bubbles up as an empty revert
        vm.mockCallRevert(address(seniorTranche), abi.encodeWithSelector(IRoycoVaultTranche.convertToAssets.selector, WAD), "");

        vm.expectRevert(bytes(""));
        stOracle.latestRoundData();
    }

    function test_latestRoundData_bubblesTrancheCustomError() public {
        // Custom-error reverts bubble up unchanged so consumers see the true downstream failure
        bytes memory customError = abi.encodeWithSignature("CustomError(uint256)", uint256(42));
        vm.mockCallRevert(address(seniorTranche), abi.encodeWithSelector(IRoycoVaultTranche.convertToAssets.selector, WAD), customError);

        vm.expectRevert(customError);
        stOracle.latestRoundData();
    }

    function test_latestRoundData_bubblesTranchePanic() public {
        // Panic(uint256) with arithmetic overflow code (0x11) bubbles up unchanged
        bytes memory panicData = abi.encodeWithSelector(bytes4(0x4e487b71), uint256(0x11));
        vm.mockCallRevert(address(seniorTranche), abi.encodeWithSelector(IRoycoVaultTranche.convertToAssets.selector, WAD), panicData);

        vm.expectRevert(panicData);
        stOracle.latestRoundData();
    }

    function test_latestRoundData_returnsZeroWhenSharePriceZero() public {
        // Documents behavior: the oracle does NOT reject a zero answer; downstream consumers must.
        seniorTranche.setSharePrice(0);

        (, int256 answer,,,) = stOracle.latestRoundData();
        assertEq(answer, 0);
    }

    function test_latestRoundData_int256CastBoundary() public {
        // At exactly int256.max, the cast is lossless and the oracle returns the max signed value.
        uint256 boundary = uint256(type(int256).max);
        // AssetClaims shaped return: zero collateral, LPT, and ST-share legs with the boundary NAV in the final word
        vm.mockCall(
            address(seniorTranche),
            abi.encodeWithSelector(IRoycoVaultTranche.convertToAssets.selector, WAD),
            abi.encode(uint256(0), uint256(0), uint256(0), boundary)
        );

        (, int256 answer,,,) = stOracle.latestRoundData();
        assertEq(answer, type(int256).max);
    }

    function test_latestRoundData_sameBlockInvarianceUnderConstantState() public view {
        (uint80 r1, int256 a1, uint256 s1, uint256 u1, uint80 ar1) = stOracle.latestRoundData();
        (uint80 r2, int256 a2, uint256 s2, uint256 u2, uint80 ar2) = stOracle.latestRoundData();

        assertEq(r1, r2);
        assertEq(a1, a2);
        assertEq(s1, s2);
        assertEq(u1, u2);
        assertEq(ar1, ar2);
    }

    /// =====================================================================
    /// getRoundData
    /// =====================================================================

    function test_getRoundData_roundOneEqualsLatest() public view {
        (uint80 r1, int256 a1, uint256 s1, uint256 u1, uint80 ar1) = stOracle.latestRoundData();
        (uint80 r2, int256 a2, uint256 s2, uint256 u2, uint80 ar2) = stOracle.getRoundData(1);

        assertEq(r1, r2);
        assertEq(a1, a2);
        assertEq(s1, s2);
        assertEq(u1, u2);
        assertEq(ar1, ar2);
    }

    function test_getRoundData_revertsOnRoundZero() public {
        vm.expectRevert(bytes("No data present"));
        stOracle.getRoundData(0);
    }

    function test_getRoundData_revertsOnRoundTwo() public {
        vm.expectRevert(bytes("No data present"));
        stOracle.getRoundData(2);
    }

    function test_getRoundData_revertsOnMaxRound() public {
        vm.expectRevert(bytes("No data present"));
        stOracle.getRoundData(type(uint80).max);
    }

    function test_getRoundData_bubblesUnderlyingRevert() public {
        // getRoundData(1) delegates to latestRoundData, which bubbles up the tranche's revert reason unchanged.
        vm.mockCallRevert(address(seniorTranche), abi.encodeWithSelector(IRoycoVaultTranche.convertToAssets.selector, WAD), "downstream");

        vm.expectRevert(bytes("downstream"));
        stOracle.getRoundData(1);
    }

    function test_getRoundData_juniorTrancheRoundOneEqualsLatest() public view {
        (uint80 r1, int256 a1, uint256 s1, uint256 u1, uint80 ar1) = jtOracle.latestRoundData();
        (uint80 r2, int256 a2, uint256 s2, uint256 u2, uint80 ar2) = jtOracle.getRoundData(1);

        assertEq(r1, r2);
        assertEq(a1, a2);
        assertEq(s1, s2);
        assertEq(u1, u2);
        assertEq(ar1, ar2);
    }

    function test_getRoundData_juniorTrancheRevertsOnNonOneRound() public {
        vm.expectRevert(bytes("No data present"));
        jtOracle.getRoundData(2);
    }

    /// =====================================================================
    /// FUZZ
    /// =====================================================================

    /// @dev Bounded to int256 max so the toInt256 cast inside the oracle stays in range.
    ///      Practical share prices are many orders of magnitude below this bound.
    function testFuzz_latestRoundData_matchesSharePrice(uint256 _sharePriceWAD) public {
        _sharePriceWAD = bound(_sharePriceWAD, 1, uint256(type(int256).max));
        seniorTranche.setSharePrice(_sharePriceWAD);

        (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound) = stOracle.latestRoundData();

        assertEq(roundId, 1);
        assertEq(answeredInRound, 1);
        assertEq(startedAt, block.timestamp);
        assertEq(updatedAt, block.timestamp);
        assertEq(uint256(answer), _sharePriceWAD);
    }

    function testFuzz_getRoundData_revertsForNonOneRound(uint80 _roundId) public {
        vm.assume(_roundId != 1);
        vm.expectRevert(bytes("No data present"));
        stOracle.getRoundData(_roundId);
    }

    /// @notice A code-less tranche address reverts: the typed interface call demands code at the target
    /// @dev Asserted through a raw staticcall: forge versions classify the extcodesize guard's failure differently, so
    ///      expectRevert matching is not portable across them
    function test_latestRoundData_codelessTrancheReverts() external {
        RoycoTrancheChainlinkOracle codelessOracle = new RoycoTrancheChainlinkOracle(makeAddr("NoCodeTranche"), NAV_ASSET);
        (bool success,) = address(codelessOracle).staticcall(abi.encodeCall(codelessOracle.latestRoundData, ()));
        assertFalse(success, "a code-less tranche must make the price query revert");
    }
}
