// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { Test } from "../../lib/forge-std/src/Test.sol";
import { Vm } from "../../lib/forge-std/src/Vm.sol";

import { ERC20Mock } from "../../lib/openzeppelin-contracts/contracts/mocks/token/ERC20Mock.sol";
import { ShortStrings } from "../../lib/openzeppelin-contracts/contracts/utils/ShortStrings.sol";

import { IRoycoAuth } from "../../lib/royco-day/src/interfaces/IRoycoAuth.sol";
import { IRoycoFactory } from "../../lib/royco-day/src/interfaces/factory/IRoycoFactory.sol";
import { WAD } from "../../lib/royco-day/src/libraries/Constants.sol";
import { TrancheType } from "../../lib/royco-day/src/libraries/Types.sol";
import { RoycoTrancheValidator } from "../../src/base/RoycoTrancheValidator.sol";
import { RoycoTrancheChainlinkOracle } from "../../src/oracle/tranche-share-to-nav-oracle/RoycoTrancheChainlinkOracle.sol";
import { RoycoTrancheChainlinkOracleFactory } from "../../src/oracle/tranche-share-to-nav-oracle/RoycoTrancheChainlinkOracleFactory.sol";

import { MockRoycoFactory } from "../mock/MockRoycoFactory.sol";
import { MockTranche } from "../mock/MockTranche.sol";

/// @title RoycoTrancheChainlinkOracleFactoryTest
/// @notice Audit-grade unit tests for RoycoTrancheChainlinkOracleFactory backed by MockTranche and MockRoycoFactory
/// @dev The factory is permissionless but verifies tranche provenance against the Royco factory's tranche registry:
///      only an address the Royco factory maps to a kernel deploys, everything else reverts NOT_A_ROYCO_TRANCHE.
///      The CREATE2 address depends on BOTH the tranche and the NAV asset symbol, so the same tranche can host one
///      live oracle per NAV asset while the trancheToOracle mapping tracks only the most recent deployment.
contract RoycoTrancheChainlinkOracleFactoryTest is Test {
    /// =====================================================================
    /// STATE
    /// =====================================================================
    ERC20Mock internal asset;
    MockTranche internal seniorTranche;
    MockTranche internal juniorTranche;
    MockRoycoFactory internal mockRoycoFactory;
    RoycoTrancheChainlinkOracleFactory internal oracleFactory;

    /// @dev Placeholder authority passed to the mock tranches (the oracle factory never queries it)
    address internal constant FACTORY_PLACEHOLDER = address(0xF);

    /// @dev Placeholder kernel registered against each mock tranche in the mock Royco factory
    address internal constant KERNEL_PLACEHOLDER = address(0xCAFE);

    /// @dev The NAV asset symbol fixture used for deployments in this suite
    string internal constant NAV_ASSET = "USD";

    /// @dev Mirrored from RoycoTrancheChainlinkOracleFactory for vm.expectEmit
    event OracleDeployed(address indexed tranche, address indexed oracle);

    /// =====================================================================
    /// SETUP
    /// =====================================================================

    function setUp() public {
        asset = new ERC20Mock();

        seniorTranche = new MockTranche(address(asset), FACTORY_PLACEHOLDER, TrancheType.SENIOR);
        juniorTranche = new MockTranche(address(asset), FACTORY_PLACEHOLDER, TrancheType.JUNIOR);

        mockRoycoFactory = new MockRoycoFactory();
        mockRoycoFactory.registerTranche(address(seniorTranche), KERNEL_PLACEHOLDER);
        mockRoycoFactory.registerTranche(address(juniorTranche), KERNEL_PLACEHOLDER);

        oracleFactory = new RoycoTrancheChainlinkOracleFactory(IRoycoFactory(address(mockRoycoFactory)));
    }

    /// =====================================================================
    /// CONSTRUCTOR
    /// =====================================================================

    function test_constructor_revertsOnNullRoycoFactory() public {
        vm.expectRevert(IRoycoAuth.NULL_ADDRESS.selector);
        new RoycoTrancheChainlinkOracleFactory(IRoycoFactory(address(0)));
    }

    function test_constructor_setsRoycoFactory() public view {
        assertEq(address(oracleFactory.ROYCO_FACTORY()), address(mockRoycoFactory));
    }

    /// =====================================================================
    /// deployOracle - happy path
    /// =====================================================================

    function test_deployOracle_seniorTranche() public {
        address predicted = oracleFactory.predictOracleAddress(address(seniorTranche), NAV_ASSET);

        vm.expectEmit(true, true, false, false, address(oracleFactory));
        emit OracleDeployed(address(seniorTranche), predicted);

        address deployed = oracleFactory.deployOracle(address(seniorTranche), NAV_ASSET);

        assertEq(deployed, predicted);
        assertGt(deployed.code.length, 0);
        assertEq(oracleFactory.trancheToOracle(address(seniorTranche)), deployed);
    }

    function test_deployOracle_juniorTranche() public {
        address predicted = oracleFactory.predictOracleAddress(address(juniorTranche), NAV_ASSET);

        vm.expectEmit(true, true, false, false, address(oracleFactory));
        emit OracleDeployed(address(juniorTranche), predicted);

        address deployed = oracleFactory.deployOracle(address(juniorTranche), NAV_ASSET);

        assertEq(deployed, predicted);
        assertGt(deployed.code.length, 0);
        assertEq(oracleFactory.trancheToOracle(address(juniorTranche)), deployed);
    }

    function test_deployOracle_oracleWiredToCorrectTranche() public {
        address deployed = oracleFactory.deployOracle(address(seniorTranche), NAV_ASSET);
        assertEq(RoycoTrancheChainlinkOracle(deployed).ROYCO_TRANCHE(), address(seniorTranche));
    }

    function test_deployOracle_deployedOracleIsFunctional() public {
        // Mock tranche default share price = 1e18, so latestRoundData returns WAD.
        address deployed = oracleFactory.deployOracle(address(seniorTranche), NAV_ASSET);
        (, int256 answer,,,) = RoycoTrancheChainlinkOracle(deployed).latestRoundData();
        assertEq(answer, int256(WAD));
    }

    function test_deployOracle_setsMappingsIndependentlyForBothTranches() public {
        address stOracle = oracleFactory.deployOracle(address(seniorTranche), NAV_ASSET);
        address jtOracle = oracleFactory.deployOracle(address(juniorTranche), NAV_ASSET);

        assertEq(oracleFactory.trancheToOracle(address(seniorTranche)), stOracle);
        assertEq(oracleFactory.trancheToOracle(address(juniorTranche)), jtOracle);
        assertTrue(stOracle != jtOracle);
    }

    function test_deployOracle_returnedAddressMatchesPredict() public {
        address predicted = oracleFactory.predictOracleAddress(address(seniorTranche), NAV_ASSET);
        address deployed = oracleFactory.deployOracle(address(seniorTranche), NAV_ASSET);
        assertEq(deployed, predicted);
    }

    /// =====================================================================
    /// deployOracle - NAV asset plumbing
    /// =====================================================================

    function test_deployOracle_navAssetRoundTripsThroughOracle() public {
        address deployed = oracleFactory.deployOracle(address(seniorTranche), NAV_ASSET);

        assertEq(RoycoTrancheChainlinkOracle(deployed).NAV_ASSET(), NAV_ASSET);
        // Chainlink base/quote convention: `<tranche symbol> / <NAV asset>` with the MockTranche senior symbol MST.
        assertEq(RoycoTrancheChainlinkOracle(deployed).description(), "MST / USD");
    }

    function test_deployOracle_emptyNavAsset_bubblesEmptyNavAsset() public {
        // The oracle constructor's NULL_NAV_ASSET guard bubbles through the factory's CREATE2 deployment.
        vm.expectRevert(RoycoTrancheChainlinkOracle.NULL_NAV_ASSET.selector);
        oracleFactory.deployOracle(address(seniorTranche), "");
    }

    function test_deployOracle_navAssetOverThirtyOneBytes_bubblesStringTooLong() public {
        // The ShortString packing's 31-byte limit bubbles through the factory's CREATE2 deployment.
        string memory tooLong = "ABCDEFGHIJKLMNOPQRSTUVWXYZ012345";
        vm.expectRevert(abi.encodeWithSelector(ShortStrings.StringTooLong.selector, tooLong));
        oracleFactory.deployOracle(address(seniorTranche), tooLong);
    }

    function test_deployOracle_differentNavAssetRedeploysAndOverwritesMapping() public {
        // Same tranche, different NAV asset: a different CREATE2 address, so no collision. The second deploy
        // succeeds and OVERWRITES the trancheToOracle entry while both oracles stay live at their deterministic
        // addresses.
        address usdPredicted = oracleFactory.predictOracleAddress(address(seniorTranche), "USD");
        address btcPredicted = oracleFactory.predictOracleAddress(address(seniorTranche), "BTC");
        assertTrue(usdPredicted != btcPredicted);

        address usdOracle = oracleFactory.deployOracle(address(seniorTranche), "USD");
        assertEq(oracleFactory.trancheToOracle(address(seniorTranche)), usdOracle);

        address btcOracle = oracleFactory.deployOracle(address(seniorTranche), "BTC");

        assertEq(usdOracle, usdPredicted);
        assertEq(btcOracle, btcPredicted);
        assertEq(oracleFactory.trancheToOracle(address(seniorTranche)), btcOracle);
        assertGt(usdOracle.code.length, 0);
        assertGt(btcOracle.code.length, 0);
        assertEq(RoycoTrancheChainlinkOracle(usdOracle).NAV_ASSET(), "USD");
        assertEq(RoycoTrancheChainlinkOracle(btcOracle).NAV_ASSET(), "BTC");
    }

    /// =====================================================================
    /// deployOracle - provenance verified against the Royco factory
    /// =====================================================================
    /// @dev Repurposed from the provenance-agnostic era: the factory now consults the Royco factory's tranche
    ///      registry, so deployment succeeds only for registered tranches and reverts NOT_A_ROYCO_TRANCHE for
    ///      every address the Royco factory never deployed.

    function test_deployOracle_revertsForUnregisteredTranche() public {
        // A tranche the Royco factory never deployed maps to no kernel and is rejected.
        MockTranche unregistered = new MockTranche(address(asset), FACTORY_PLACEHOLDER, TrancheType.SENIOR);

        vm.expectRevert(abi.encodeWithSelector(RoycoTrancheValidator.NOT_A_ROYCO_TRANCHE.selector, address(unregistered)));
        oracleFactory.deployOracle(address(unregistered), NAV_ASSET);
    }

    function test_deployOracle_succeedsOnceRegistered() public {
        // The same tranche that was just rejected deploys once the Royco factory registers it.
        MockTranche lateTranche = new MockTranche(address(asset), FACTORY_PLACEHOLDER, TrancheType.SENIOR);

        vm.expectRevert(abi.encodeWithSelector(RoycoTrancheValidator.NOT_A_ROYCO_TRANCHE.selector, address(lateTranche)));
        oracleFactory.deployOracle(address(lateTranche), NAV_ASSET);

        mockRoycoFactory.registerTranche(address(lateTranche), KERNEL_PLACEHOLDER);
        address deployed = oracleFactory.deployOracle(address(lateTranche), NAV_ASSET);

        assertEq(oracleFactory.trancheToOracle(address(lateTranche)), deployed);
        assertEq(RoycoTrancheChainlinkOracle(deployed).ROYCO_TRANCHE(), address(lateTranche));
    }

    function test_deployOracle_registeredCodelessAddressDeploys_noTrancheQueryAtDeployment() public {
        // The oracle constructor performs no call into the tranche, so even a registered code-less address deploys.
        // The registry is the sole provenance gate; the resulting oracle is only as good as the tranche behind it.
        address codeless = makeAddr("codelessTranche");
        mockRoycoFactory.registerTranche(codeless, KERNEL_PLACEHOLDER);
        address predicted = oracleFactory.predictOracleAddress(codeless, NAV_ASSET);

        address deployed = oracleFactory.deployOracle(codeless, NAV_ASSET);

        assertEq(deployed, predicted);
        assertEq(oracleFactory.trancheToOracle(codeless), deployed);
    }

    /// =====================================================================
    /// deployOracle - revert paths
    /// =====================================================================

    function test_deployOracle_revertsOnNullAddress() public {
        // The validator rejects the null address explicitly before consulting the registry.
        vm.expectRevert(IRoycoAuth.NULL_ADDRESS.selector);
        oracleFactory.deployOracle(address(0), NAV_ASSET);
    }

    function test_deployOracle_revertsOnRedeploy() public {
        oracleFactory.deployOracle(address(seniorTranche), NAV_ASSET);

        // Second deploy for the same tranche AND NAV asset collides at the deterministic CREATE2 address; the
        // `new` opcode reverts.
        vm.expectRevert();
        oracleFactory.deployOracle(address(seniorTranche), NAV_ASSET);
    }

    function test_deployOracle_failedRedeployDoesNotCorruptMapping() public {
        address firstOracle = oracleFactory.deployOracle(address(seniorTranche), NAV_ASSET);

        vm.expectRevert();
        oracleFactory.deployOracle(address(seniorTranche), NAV_ASSET);

        // Mapping still points at the original oracle.
        assertEq(oracleFactory.trancheToOracle(address(seniorTranche)), firstOracle);
    }

    /// =====================================================================
    /// predictOracleAddress
    /// =====================================================================

    function test_predictOracleAddress_isDeterministic() public view {
        address pred1 = oracleFactory.predictOracleAddress(address(seniorTranche), NAV_ASSET);
        address pred2 = oracleFactory.predictOracleAddress(address(seniorTranche), NAV_ASSET);
        assertEq(pred1, pred2);
    }

    function test_predictOracleAddress_differentTranchesProduceDifferentAddresses() public view {
        address stPred = oracleFactory.predictOracleAddress(address(seniorTranche), NAV_ASSET);
        address jtPred = oracleFactory.predictOracleAddress(address(juniorTranche), NAV_ASSET);
        assertTrue(stPred != jtPred);
    }

    function test_predictOracleAddress_differentNavAssetsProduceDifferentAddresses() public view {
        // The NAV asset is part of the CREATE2 init code, so it shifts the predicted address on its own.
        address usdPred = oracleFactory.predictOracleAddress(address(seniorTranche), "USD");
        address btcPred = oracleFactory.predictOracleAddress(address(seniorTranche), "BTC");
        assertTrue(usdPred != btcPred);
    }

    function test_predictOracleAddress_callerIndependent() public {
        // predict has no msg.sender dependency: same input from any caller yields the same address.
        address fromThisCaller = oracleFactory.predictOracleAddress(address(seniorTranche), NAV_ASSET);
        vm.prank(makeAddr("randomCaller"));
        address fromAnotherCaller = oracleFactory.predictOracleAddress(address(seniorTranche), NAV_ASSET);
        assertEq(fromThisCaller, fromAnotherCaller);
    }

    function test_predictOracleAddress_doesNotValidateTranche() public {
        // Predict is a pure deterministic function over its inputs; it consults neither the tranche nor the Royco
        // factory's registry. Even an unregistered or non-contract address yields a non-zero prediction.
        address random = makeAddr("random");
        assertTrue(oracleFactory.predictOracleAddress(random, NAV_ASSET) != address(0));
    }

    /// =====================================================================
    /// PERMISSIONLESS / DETERMINISM
    /// =====================================================================

    function test_deployOracle_permissionlessProducesSameAddressAcrossCallers() public {
        address predicted = oracleFactory.predictOracleAddress(address(seniorTranche), NAV_ASSET);

        vm.prank(makeAddr("randomCaller"));
        address deployed = oracleFactory.deployOracle(address(seniorTranche), NAV_ASSET);

        assertEq(deployed, predicted);
    }

    function test_deployOracle_eventCarriesCorrectTrancheAndOracleTopics() public {
        address predicted = oracleFactory.predictOracleAddress(address(juniorTranche), NAV_ASSET);

        vm.recordLogs();
        oracleFactory.deployOracle(address(juniorTranche), NAV_ASSET);
        Vm.Log[] memory logs = vm.getRecordedLogs();

        // Find the OracleDeployed log among possibly-emitted events.
        bytes32 expectedTopic0 = keccak256("OracleDeployed(address,address)");
        bool found;
        for (uint256 i = 0; i < logs.length; ++i) {
            if (logs[i].emitter != address(oracleFactory)) continue;
            if (logs[i].topics.length != 3 || logs[i].topics[0] != expectedTopic0) continue;
            assertEq(address(uint160(uint256(logs[i].topics[1]))), address(juniorTranche));
            assertEq(address(uint160(uint256(logs[i].topics[2]))), predicted);
            found = true;
            break;
        }
        assertTrue(found);
    }

    /// =====================================================================
    /// FUZZ
    /// =====================================================================

    function testFuzz_predictOracleAddress_doesNotRevert(address _tranche) public view {
        // Predict is total: must not revert for any input.
        oracleFactory.predictOracleAddress(_tranche, NAV_ASSET);
    }

    function testFuzz_predictOracleAddress_isDeterministicAcrossInputs(address _trancheA, address _trancheB) public view {
        // Same input → same address; different inputs → different addresses (CREATE2 is collision-resistant for different init codes).
        if (_trancheA == _trancheB) {
            assertEq(oracleFactory.predictOracleAddress(_trancheA, NAV_ASSET), oracleFactory.predictOracleAddress(_trancheB, NAV_ASSET));
        } else {
            assertTrue(oracleFactory.predictOracleAddress(_trancheA, NAV_ASSET) != oracleFactory.predictOracleAddress(_trancheB, NAV_ASSET));
        }
    }

    function testFuzz_deployOracle_callerIndependence(address _caller) public {
        vm.assume(_caller != address(0));
        address predicted = oracleFactory.predictOracleAddress(address(seniorTranche), NAV_ASSET);

        vm.prank(_caller);
        address deployed = oracleFactory.deployOracle(address(seniorTranche), NAV_ASSET);

        assertEq(deployed, predicted);
        assertEq(oracleFactory.trancheToOracle(address(seniorTranche)), deployed);
    }

    function testFuzz_deployOracle_revertsForAnyUnregisteredAddress(address _ostensibleTranche) public {
        vm.assume(_ostensibleTranche != address(0));
        vm.assume(mockRoycoFactory.trancheToKernel(_ostensibleTranche) == address(0));

        vm.expectRevert(abi.encodeWithSelector(RoycoTrancheValidator.NOT_A_ROYCO_TRANCHE.selector, _ostensibleTranche));
        oracleFactory.deployOracle(_ostensibleTranche, NAV_ASSET);
    }
}
