// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { Test } from "../../lib/forge-std/src/Test.sol";

import { ERC20Mock } from "../../lib/openzeppelin-contracts/contracts/mocks/token/ERC20Mock.sol";

import { IRoycoVaultTranche } from "../../lib/royco-day/src/interfaces/IRoycoVaultTranche.sol";
import { WAD } from "../../lib/royco-day/src/libraries/Constants.sol";
import { TrancheType } from "../../lib/royco-day/src/libraries/Types.sol";
import { ASSETS_MUST_BE_NON_NEGATIVE } from "../../lib/royco-day/src/libraries/Units.sol";
import { AggregatorV3Interface } from "../../src/interfaces/AggregatorV3Interface.sol";
import { FundamentalStablecoinChainlinkOracle } from "../../src/oracle/fundamental-oracle/FundamentalStablecoinChainlinkOracle.sol";
import { RoycoTrancheBaseAssetChainlinkOracle } from "../../src/oracle/tranche-share-to-base-asset-oracle/RoycoTrancheBaseAssetChainlinkOracle.sol";
import { RoycoTrancheChainlinkOracle } from "../../src/oracle/tranche-share-to-nav-oracle/RoycoTrancheChainlinkOracle.sol";

import { MockTranche } from "../mock/MockTranche.sol";

/**
 * @title RawReturnTranche
 * @notice A malicious/degenerate tranche double whose convertToAssets returns arbitrary raw bytes via assembly
 * @dev Two modes: exact stored bytes (any length, including non-word-multiples) for shape pinning, and a generated
 *      returndata bomb (bombWordCount words, all zero except a settable NAV word at the AssetClaims offset) so
 *      megabyte-scale returns don't require megabyte-scale storage writes
 */
contract RawReturnTranche {
    /// @notice The exact raw bytes to return from convertToAssets when no bomb is configured
    bytes public rawReturnData;

    /// @notice The number of 32-byte words in the generated returndata bomb (0 disables bomb mode)
    uint256 public bombWordCount;

    /// @notice The value of the bomb's fourth word, where the typed AssetClaims decoder reads the NAV (every other word is zero)
    uint256 public bombNavWord;

    /// @notice Sets the exact raw bytes returned from convertToAssets
    function setRawReturnData(bytes calldata _data) external {
        rawReturnData = _data;
    }

    /// @notice Arms bomb mode: convertToAssets will return `_wordCount` words carrying `_navWord` at the NAV offset
    function setBomb(uint256 _wordCount, uint256 _navWord) external {
        bombWordCount = _wordCount;
        bombNavWord = _navWord;
    }

    /**
     * @notice Returns the configured raw bytes (or the generated bomb) regardless of the requested share count
     * @dev Mirrors the tranche selector consumed by the periphery's typed readers; deliberately unconstrained so
     *      tests can pin the ABI decoder's behavior on every conceivable returndata shape
     */
    function convertToAssets(uint256) external view {
        uint256 wordCount = bombWordCount;
        if (wordCount != 0) {
            uint256 size = wordCount * 32;
            uint256 navWord = bombNavWord;
            assembly {
                let ptr := mload(0x40)
                // Every word except the fourth is untouched (zero) memory; only the NAV word carries data
                mstore(add(ptr, 0x60), navWord)
                return(ptr, size)
            }
        }
        bytes memory data = rawReturnData;
        assembly ("memory-safe") {
            return(add(data, 0x20), mload(data))
        }
    }
}

/// @title MetadataERC20
/// @notice Minimal ERC20-metadata double with constructor-configurable name, symbol, and decimals
contract MetadataERC20 {
    string public name;
    string public symbol;
    uint8 public decimals;

    constructor(string memory _name, string memory _symbol, uint8 _decimals) {
        name = _name;
        symbol = _symbol;
        decimals = _decimals;
    }
}

/**
 * @title MutableFeedMock
 * @notice Chainlink-compatible feed double with fully settable round data and MUTABLE decimals
 * @dev getRoundData echoes the requested round ID (proving the wrapper forwards it) while answeredInRound is
 *      independently configurable (proving the wrapper does not conflate the two); decimals can be changed after
 *      construction to pin the wrapper's live-forwarding of decimals against its construction-frozen ONE_QUOTE_ASSET
 */
contract MutableFeedMock is AggregatorV3Interface {
    uint8 internal feedDecimals;
    string internal feedDescription;

    uint80 internal roundId_ = 1;
    int256 internal answer_;
    uint256 internal startedAt_;
    uint256 internal updatedAt_;
    uint80 internal answeredInRound_ = 1;

    constructor(uint8 _decimals, string memory _description) {
        feedDecimals = _decimals;
        feedDescription = _description;
        startedAt_ = block.timestamp;
        updatedAt_ = block.timestamp;
    }

    /// @notice Mutates the feed's decimals after construction to model a live-upgraded underlying feed
    function setDecimals(uint8 _decimals) external {
        feedDecimals = _decimals;
    }

    /// @notice Sets the answer returned by both round-data queries
    function setAnswer(int256 _answer) external {
        answer_ = _answer;
    }

    /// @notice Sets every round-data field returned by the feed in one call
    function setRoundData(uint80 _roundId, int256 _answer, uint256 _startedAt, uint256 _updatedAt, uint80 _answeredInRound) external {
        roundId_ = _roundId;
        answer_ = _answer;
        startedAt_ = _startedAt;
        updatedAt_ = _updatedAt;
        answeredInRound_ = _answeredInRound;
    }

    function decimals() external view returns (uint8) {
        return feedDecimals;
    }

    function description() external view returns (string memory) {
        return feedDescription;
    }

    function version() external pure returns (uint256) {
        return 1;
    }

    function latestRoundData() external view returns (uint80, int256, uint256, uint256, uint80) {
        return (roundId_, answer_, startedAt_, updatedAt_, answeredInRound_);
    }

    function getRoundData(uint80 _roundId) external view returns (uint80, int256, uint256, uint256, uint80) {
        // Echo the requested round ID so callers can prove it was forwarded; keep answeredInRound independent
        return (_roundId, answer_, startedAt_, updatedAt_, answeredInRound_);
    }
}

/**
 * @title RoycoTrancheNavChainlinkOracleAdversarialTest
 * @notice Adversarial tests for RoycoTrancheChainlinkOracle against a tranche returning arbitrary raw bytes
 * @dev The oracle decodes the tranche's return as Day's typed AssetClaims (four static words) and answers the NAV
 *      word (the fourth, bytes 96..127) through the toInt256 guard. Returndata shorter than the four words fails
 *      the ABI decoder's size check with an EMPTY revert; anything longer decodes the four fixed-offset words and
 *      ignores the tail. These tests PIN that decoder behavior byte-for-byte
 */
contract RoycoTrancheNavChainlinkOracleAdversarialTest is Test {
    /// =====================================================================
    /// STATE
    /// =====================================================================
    RawReturnTranche internal rawTranche;
    RoycoTrancheChainlinkOracle internal oracle;

    /// =====================================================================
    /// SETUP
    /// =====================================================================

    function setUp() public {
        rawTranche = new RawReturnTranche();
        oracle = new RoycoTrancheChainlinkOracle(address(rawTranche), "USD");
    }

    /// =====================================================================
    /// int256 CAST BOUNDARY (toInt256)
    /// =====================================================================

    /// @notice A NAV of exactly int256.max is the largest value the toInt256 cast admits and must be answered losslessly
    function test_latestRoundData_navExactlyIntMax_passes() external {
        rawTranche.setRawReturnData(abi.encode(uint256(0), uint256(0), uint256(0), uint256(type(int256).max)));

        (, int256 answer,,,) = oracle.latestRoundData();
        assertEq(answer, type(int256).max, "A NAV of exactly int256.max must pass the toInt256 cast losslessly");
    }

    /// @notice A NAV of int256.max + 1 is the first value whose int256 cast goes negative and must revert ASSETS_MUST_BE_NON_NEGATIVE
    function test_latestRoundData_navIntMaxPlusOne_revertsNonNegative() external {
        rawTranche.setRawReturnData(abi.encode(uint256(0), uint256(0), uint256(0), uint256(type(int256).max) + 1));

        vm.expectRevert(ASSETS_MUST_BE_NON_NEGATIVE.selector);
        oracle.latestRoundData();
    }

    /// @notice A NAV of uint256.max (cast bit pattern -1) must also revert ASSETS_MUST_BE_NON_NEGATIVE
    function test_latestRoundData_navUintMax_revertsNonNegative() external {
        rawTranche.setRawReturnData(abi.encode(uint256(0), uint256(0), uint256(0), type(uint256).max));

        vm.expectRevert(ASSETS_MUST_BE_NON_NEGATIVE.selector);
        oracle.latestRoundData();
    }

    /**
     * @notice Fuzz: over the full uint256 NAV domain the oracle partitions exactly at int256.max —
     *         nav <= int256.max answers nav, nav > int256.max reverts ASSETS_MUST_BE_NON_NEGATIVE
     * @param _nav The raw NAV word placed in the final word of an AssetClaims-shaped four-word return
     */
    function testFuzz_latestRoundData_fullUintNavDomainPartitionsAtIntMax(uint256 _nav) external {
        rawTranche.setRawReturnData(abi.encode(uint256(0), uint256(0), uint256(0), _nav));

        if (_nav > uint256(type(int256).max)) {
            vm.expectRevert(ASSETS_MUST_BE_NON_NEGATIVE.selector);
            oracle.latestRoundData();
        } else {
            (, int256 answer,,,) = oracle.latestRoundData();
            assertEq(uint256(answer), _nav, "Any NAV within the int256 range must be answered unchanged");
        }
    }

    /// =====================================================================
    /// RETURNDATA BOMBS
    /// =====================================================================

    /**
     * @notice A 10,000-word (320 KB) returndata bomb does not break the oracle: the answer is still the NAV word
     * @dev Pins the typed decoder's tolerance for oversized returns — the decoder reads the four fixed-offset words
     *      and ignores the tail, so a bomb only costs gas, it cannot corrupt the answer
     */
    function test_latestRoundData_survivesTenThousandWordReturndataBomb() external {
        rawTranche.setBomb(10_000, 42e18);

        (, int256 answer,,,) = oracle.latestRoundData();
        assertEq(answer, 42e18, "The answer must be the fixed-offset NAV word even for a 10,000 word bomb");
    }

    /// @notice A returndata bomb whose NAV word exceeds int256.max still hits the toInt256 guard, not a silent wrap
    function test_latestRoundData_bombWithOverflowingNavWord_revertsNonNegative() external {
        rawTranche.setBomb(10_000, type(uint256).max);

        vm.expectRevert(ASSETS_MUST_BE_NON_NEGATIVE.selector);
        oracle.latestRoundData();
    }

    /// =====================================================================
    /// UNDERSIZED AND MISSHAPEN RETURNDATA (typed-decode rejection)
    /// =====================================================================

    /// @notice Empty returndata fails the decoder's four-word size check with an empty revert
    function test_latestRoundData_emptyReturn_revertsOnDecode() external {
        rawTranche.setRawReturnData(hex"");

        vm.expectRevert(bytes(""));
        oracle.latestRoundData();
    }

    /**
     * @notice A Royco Dawn shaped three-word return no longer decodes: Day's AssetClaims needs four words, so the
     *         decoder's size check rejects it with an empty revert
     * @dev PINS the Day-only posture — Dawn tranche shapes are not silently misread, they fail loudly at decode
     */
    function test_latestRoundData_dawnThreeWordReturn_revertsOnDecode() external {
        rawTranche.setRawReturnData(abi.encode(uint256(3e18), uint256(1e18), uint256(7e18)));

        vm.expectRevert(bytes(""));
        oracle.latestRoundData();
    }

    /// @notice A 127-byte return, one byte short of the four words, is rejected by the decoder's size check
    function test_latestRoundData_oneByteShortReturn_revertsOnDecode() external {
        bytes memory raw = new bytes(127);
        rawTranche.setRawReturnData(raw);

        vm.expectRevert(bytes(""));
        oracle.latestRoundData();
    }

    /// @notice A 129-byte return decodes: the four fixed-offset words are read and the trailing garbage byte is ignored
    function test_latestRoundData_trailingGarbageByteIgnored() external {
        rawTranche.setRawReturnData(abi.encodePacked(abi.encode(uint256(0), uint256(0), uint256(0), uint256(5e18)), bytes1(0xAA)));

        (, int256 answer,,,) = oracle.latestRoundData();
        assertEq(answer, 5e18, "A 129-byte return must decode the fixed-offset NAV word and ignore the trailing byte");
    }

    /**
     * @notice Fuzz: the typed decoder partitions all returndata at the four-word size — any return shorter than
     *         128 bytes reverts empty, and any longer return answers the fixed-offset NAV word (bytes 96..127),
     *         independently derived here with a byte-by-byte accumulator
     * @param _seed Seed for the pseudo-random returndata content
     * @param _length The returndata length, bounded to [0, 320] covering undersized, aligned, and misaligned shapes
     */
    function testFuzz_latestRoundData_typedDecodePartitionsAtFourWords(bytes32 _seed, uint256 _length) external {
        _length = bound(_length, 0, 320);
        bytes memory raw = new bytes(_length);
        for (uint256 i = 0; i < _length; ++i) {
            raw[i] = bytes1(uint8(uint256(keccak256(abi.encode(_seed, i)))));
        }

        if (_length < 128) {
            rawTranche.setRawReturnData(raw);
            vm.expectRevert(bytes(""));
            oracle.latestRoundData();
            return;
        }

        // Clear the top bit of the NAV word's most significant byte so the toInt256 guard stays in range
        raw[96] = bytes1(uint8(raw[96]) & 0x7F);
        rawTranche.setRawReturnData(raw);

        // Independent derivation: accumulate the NAV word (bytes 96..127) big-endian
        uint256 expected;
        for (uint256 i = 96; i < 128; ++i) {
            expected = (expected << 8) | uint8(raw[i]);
        }

        (, int256 answer,,,) = oracle.latestRoundData();
        assertEq(uint256(answer), expected, "The answer must be exactly the fixed-offset NAV word for any length >= 128");
    }
}

/**
 * @title RoycoTrancheBaseAssetChainlinkOracleAdversarialTest
 * @notice Adversarial tests for RoycoTrancheBaseAssetChainlinkOracle: the intentional unchecked int256 cast of the
 *         base asset claim on both the collateral-asset and LPT-asset legs, raw enum decode behavior on
 *         TRANCHE_TYPE, constructor failure propagation, and metadata against weird-decimals base assets
 */
contract RoycoTrancheBaseAssetChainlinkOracleAdversarialTest is Test {
    /// =====================================================================
    /// STATE
    /// =====================================================================
    ERC20Mock internal baseAsset;
    MockTranche internal seniorTranche;
    MockTranche internal liquidityTranche;
    RoycoTrancheBaseAssetChainlinkOracle internal oracle;
    RoycoTrancheBaseAssetChainlinkOracle internal lptOracle;

    /// @dev Calldata for the oracle's share price query: convertToAssets(1e18)
    bytes internal sharePriceQuery;

    /// =====================================================================
    /// SETUP
    /// =====================================================================

    function setUp() public {
        baseAsset = new ERC20Mock();
        seniorTranche = new MockTranche(address(baseAsset), address(this), TrancheType.SENIOR);
        liquidityTranche = new MockTranche(address(baseAsset), address(this), TrancheType.LIQUIDITY_PROVIDER);
        oracle = new RoycoTrancheBaseAssetChainlinkOracle(address(seniorTranche));
        lptOracle = new RoycoTrancheBaseAssetChainlinkOracle(address(liquidityTranche));
        sharePriceQuery = abi.encodeCall(IRoycoVaultTranche.convertToAssets, (WAD));
    }

    /// =====================================================================
    /// BASE ASSET CLAIM: UNCHECKED int256 CAST
    /// =====================================================================

    /// @notice A collateral claim of exactly int256.max is the largest claim answered as a positive price
    function test_latestRoundData_collateralClaimExactlyIntMax_answersIntMax() external {
        vm.mockCall(address(seniorTranche), sharePriceQuery, abi.encode(uint256(type(int256).max), uint256(0), uint256(0), uint256(0)));

        (, int256 answer,,,) = oracle.latestRoundData();
        assertEq(answer, type(int256).max, "A collateral claim of exactly int256.max must be answered as a positive price");
    }

    /**
     * @notice PINS the documented trust assumption: a collateral claim of int256.max + 1 (= 2^255) passes through
     *         the unchecked cast and is answered as type(int256).min with NO revert
     * @dev The oracle intentionally omits a range check here; Chainlink consumers reject non-positive answers
     *      downstream, so the wrap surfaces as a rejected negative price rather than a wrong positive one
     */
    function test_latestRoundData_collateralClaimIntMaxPlusOne_answersIntMinWithoutReverting() external {
        vm.mockCall(address(seniorTranche), sharePriceQuery, abi.encode(uint256(type(int256).max) + 1, uint256(0), uint256(0), uint256(0)));

        (, int256 answer,,,) = oracle.latestRoundData();
        assertEq(answer, type(int256).min, "A collateral claim of 2^255 must wrap to int256.min through the intentional unchecked cast");
    }

    /// @notice PINS the cast wrap at the top of the domain: a collateral claim of uint256.max is answered as -1 with no revert
    function test_latestRoundData_collateralClaimUintMax_answersMinusOneWithoutReverting() external {
        vm.mockCall(address(seniorTranche), sharePriceQuery, abi.encode(type(uint256).max, uint256(0), uint256(0), uint256(0)));

        (, int256 answer,,,) = oracle.latestRoundData();
        assertEq(answer, -1, "A collateral claim of uint256.max must wrap to -1 through the intentional unchecked cast");
    }

    /// @notice The LPT-asset leg passes through the same unchecked cast: an lptAssets claim of uint256.max answers -1
    function test_latestRoundData_lptClaimUintMax_answersMinusOneWithoutReverting() external {
        vm.mockCall(address(liquidityTranche), sharePriceQuery, abi.encode(uint256(0), type(uint256).max, uint256(0), uint256(0)));

        (, int256 answer,,,) = lptOracle.latestRoundData();
        assertEq(answer, -1, "An LPT-asset claim of uint256.max must wrap to -1 through the intentional unchecked cast");
    }

    /**
     * @notice Fuzz: each oracle answers ONLY its tranche type's claims leg and preserves that leg's exact bit
     *         pattern through the cast — claims <= int256.max answer non-negative and larger claims wrap negative,
     *         never reverting; the other legs never leak into the answer
     * @param _collateralAssets The collateral-asset claim word (the senior oracle's leg)
     * @param _lptAssets The LPT-asset claim word (the LPT oracle's leg)
     */
    function testFuzz_latestRoundData_castWrapPreservesBitPatternPerLeg(uint256 _collateralAssets, uint256 _lptAssets) external {
        vm.mockCall(address(seniorTranche), sharePriceQuery, abi.encode(_collateralAssets, _lptAssets, uint256(0), uint256(0)));
        vm.mockCall(address(liquidityTranche), sharePriceQuery, abi.encode(_collateralAssets, _lptAssets, uint256(0), uint256(0)));

        (, int256 seniorAnswer,,,) = oracle.latestRoundData();
        (, int256 lptAnswer,,,) = lptOracle.latestRoundData();

        assertEq(uint256(seniorAnswer), _collateralAssets, "The senior answer must preserve the collateral claim's exact bit pattern");
        assertEq(uint256(lptAnswer), _lptAssets, "The LPT answer must preserve the LPT-asset claim's exact bit pattern");
        if (_collateralAssets > uint256(type(int256).max)) {
            assertLt(seniorAnswer, 0, "A collateral claim above int256.max must surface as a negative answer, not a revert");
        } else {
            assertGe(seniorAnswer, 0, "A collateral claim within the int256 range must surface as a non-negative answer");
        }
    }

    /// =====================================================================
    /// CONSTRUCTOR: TRANCHE_TYPE ENUM DECODE LADDER
    /// =====================================================================

    /// @notice Raw TRANCHE_TYPE value 0 (SENIOR) deploys and prices via the collateral-asset leg
    function test_constructor_rawTrancheTypeZero_deploys() external {
        vm.mockCall(address(seniorTranche), abi.encodeWithSelector(IRoycoVaultTranche.TRANCHE_TYPE.selector), abi.encode(uint256(0)));

        RoycoTrancheBaseAssetChainlinkOracle deployed = new RoycoTrancheBaseAssetChainlinkOracle(address(seniorTranche));
        assertEq(uint8(deployed.TRANCHE_TYPE()), uint8(TrancheType.SENIOR), "A SENIOR raw value must be cached as the tranche type");
        assertEq(deployed.BASE_ASSET(), address(baseAsset), "A SENIOR tranche type must deploy with the tranche's base asset");
    }

    /// @notice Raw TRANCHE_TYPE value 1 (JUNIOR) deploys and prices via the collateral-asset leg
    function test_constructor_rawTrancheTypeOne_deploys() external {
        vm.mockCall(address(seniorTranche), abi.encodeWithSelector(IRoycoVaultTranche.TRANCHE_TYPE.selector), abi.encode(uint256(1)));

        RoycoTrancheBaseAssetChainlinkOracle deployed = new RoycoTrancheBaseAssetChainlinkOracle(address(seniorTranche));
        assertEq(uint8(deployed.TRANCHE_TYPE()), uint8(TrancheType.JUNIOR), "A JUNIOR raw value must be cached as the tranche type");
        assertEq(deployed.BASE_ASSET(), address(baseAsset), "A JUNIOR tranche type must deploy with the tranche's base asset");
    }

    /// @notice Raw TRANCHE_TYPE value 2 (LIQUIDITY_PROVIDER) deploys: LPTs are supported and price via the LPT-asset leg
    function test_constructor_rawTrancheTypeTwo_deploysAsLiquidityProvider() external {
        vm.mockCall(address(seniorTranche), abi.encodeWithSelector(IRoycoVaultTranche.TRANCHE_TYPE.selector), abi.encode(uint256(2)));

        RoycoTrancheBaseAssetChainlinkOracle deployed = new RoycoTrancheBaseAssetChainlinkOracle(address(seniorTranche));
        assertEq(uint8(deployed.TRANCHE_TYPE()), uint8(TrancheType.LIQUIDITY_PROVIDER), "A LIQUIDITY_PROVIDER raw value must be cached as the tranche type");
        assertEq(deployed.BASE_ASSET(), address(baseAsset), "A LIQUIDITY_PROVIDER tranche type must deploy with the tranche's base asset");
    }

    /**
     * @notice Raw TRANCHE_TYPE value 3 is outside the TrancheType enum: the return-data ABI decoder rejects it
     *         with an EMPTY revert
     * @dev PINS the decoder behavior: external-call return-data validation failures revert with no data
     *      (`revert(0, 0)`), unlike an in-contract enum conversion which would panic 0x21
     */
    function test_constructor_rawTrancheTypeThree_revertsEmptyOnEnumDecode() external {
        vm.mockCall(address(seniorTranche), abi.encodeWithSelector(IRoycoVaultTranche.TRANCHE_TYPE.selector), abi.encode(uint256(3)));

        vm.expectRevert(bytes(""));
        new RoycoTrancheBaseAssetChainlinkOracle(address(seniorTranche));
    }

    /**
     * @notice Fuzz: the full raw uint8 TRANCHE_TYPE domain partitions exactly two ways —
     *         0/1/2 deploy with the raw value cached, and >= 3 reverts empty on enum decode
     * @param _rawTrancheType The raw word returned from TRANCHE_TYPE()
     */
    function testFuzz_constructor_rawTrancheTypeDomainPartition(uint8 _rawTrancheType) external {
        vm.mockCall(address(seniorTranche), abi.encodeWithSelector(IRoycoVaultTranche.TRANCHE_TYPE.selector), abi.encode(uint256(_rawTrancheType)));

        if (_rawTrancheType <= 2) {
            RoycoTrancheBaseAssetChainlinkOracle deployed = new RoycoTrancheBaseAssetChainlinkOracle(address(seniorTranche));
            assertEq(deployed.ROYCO_TRANCHE(), address(seniorTranche), "Every in-range raw value must deploy successfully");
            assertEq(uint8(deployed.TRANCHE_TYPE()), _rawTrancheType, "The raw tranche type must be cached unchanged");
        } else {
            vm.expectRevert(bytes(""));
            new RoycoTrancheBaseAssetChainlinkOracle(address(seniorTranche));
        }
    }

    /// =====================================================================
    /// CONSTRUCTOR: TRANCHE FAILURE PROPAGATION
    /// =====================================================================

    /// @notice A tranche whose TRANCHE_TYPE() reverts during construction propagates its revert reason unchanged
    function test_constructor_trancheTypeReverts_propagatesReason() external {
        vm.mockCallRevert(address(seniorTranche), abi.encodeWithSelector(IRoycoVaultTranche.TRANCHE_TYPE.selector), "TRANCHE_TYPE_DOWN");

        vm.expectRevert(bytes("TRANCHE_TYPE_DOWN"));
        new RoycoTrancheBaseAssetChainlinkOracle(address(seniorTranche));
    }

    /// @notice A tranche whose asset() reverts during construction propagates its revert reason unchanged
    function test_constructor_trancheAssetReverts_propagatesReason() external {
        vm.mockCallRevert(address(seniorTranche), abi.encodeWithSelector(IRoycoVaultTranche.asset.selector), "ASSET_DOWN");

        vm.expectRevert(bytes("ASSET_DOWN"));
        new RoycoTrancheBaseAssetChainlinkOracle(address(seniorTranche));
    }

    /// @notice A tranche whose asset() reverts with a custom error propagates the error bytes unchanged
    function test_constructor_trancheAssetCustomError_propagatesBytes() external {
        bytes memory customError = abi.encodeWithSignature("TranchePaused(uint256)", uint256(7));
        vm.mockCallRevert(address(seniorTranche), abi.encodeWithSelector(IRoycoVaultTranche.asset.selector), customError);

        vm.expectRevert(customError);
        new RoycoTrancheBaseAssetChainlinkOracle(address(seniorTranche));
    }

    /// =====================================================================
    /// METADATA AGAINST WEIRD-DECIMALS BASE ASSETS
    /// =====================================================================

    /// @dev Deploys a tranche + oracle stack over the specified base asset
    function _deployOracleFor(address _baseAsset) internal returns (RoycoTrancheBaseAssetChainlinkOracle) {
        MockTranche tranche = new MockTranche(_baseAsset, address(this), TrancheType.SENIOR);
        return new RoycoTrancheBaseAssetChainlinkOracle(address(tranche));
    }

    /// @notice The oracle mirrors a 6-decimal base asset's decimals (USDC-style markets)
    function test_decimals_sixDecimalBaseAsset_mirrorsSix() external {
        MetadataERC20 usdc = new MetadataERC20("USD Coin", "USDC", 6);
        RoycoTrancheBaseAssetChainlinkOracle sixDecOracle = _deployOracleFor(address(usdc));

        assertEq(sixDecOracle.decimals(), 6, "The oracle must mirror a 6-decimal base asset's decimals");
    }

    /// @notice The oracle mirrors a 0-decimal base asset's decimals: integer-only quoting is passed through, not rejected
    function test_decimals_zeroDecimalBaseAsset_mirrorsZero() external {
        MetadataERC20 integerToken = new MetadataERC20("Integer Token", "INT0", 0);
        RoycoTrancheBaseAssetChainlinkOracle zeroDecOracle = _deployOracleFor(address(integerToken));

        assertEq(zeroDecOracle.decimals(), 0, "The oracle must mirror a 0-decimal base asset's decimals unchanged");
    }

    /// @notice The description composes the tranche and a 6-decimal base asset's symbols as a base/quote pair
    function test_description_sixDecimalBaseAsset_composesSymbol() external {
        MetadataERC20 usdc = new MetadataERC20("USD Coin", "USDC", 6);
        RoycoTrancheBaseAssetChainlinkOracle sixDecOracle = _deployOracleFor(address(usdc));

        assertEq(sixDecOracle.description(), "MST / USDC", "The description must compose the tranche and base asset symbols as a base/quote pair");
    }

    /// @notice The description composes correctly for a 0-decimal base asset: decimals play no role in the description
    function test_description_zeroDecimalBaseAsset_composesSymbol() external {
        MetadataERC20 integerToken = new MetadataERC20("Integer Token", "INT0", 0);
        RoycoTrancheBaseAssetChainlinkOracle zeroDecOracle = _deployOracleFor(address(integerToken));

        assertEq(zeroDecOracle.description(), "MST / INT0", "The description must compose the base asset symbol regardless of its decimals");
    }
}

/**
 * @title FundamentalStablecoinChainlinkOracleAdversarialTest
 * @notice Adversarial tests for FundamentalStablecoinChainlinkOracle: full-domain peg partition on an 18-decimal
 *         feed, constructor bounds fuzz, byte-exact round-data passthrough over fuzzed round IDs, staleness field
 *         passthrough, live-decimals mirroring against the construction-frozen ONE_QUOTE_ASSET, and description
 *         composition under weird and diverged decimals
 */
contract FundamentalStablecoinChainlinkOracleAdversarialTest is Test {
    /// =====================================================================
    /// STATE
    /// =====================================================================
    MutableFeedMock internal feed18;
    FundamentalStablecoinChainlinkOracle internal wrapper18;

    /// @dev 1.00 in 18-decimal precision
    int256 internal constant ONE_18 = 1e18;
    /// @dev 0.999 in 18-decimal precision
    int256 internal constant MIN_PEG_18 = 0.999e18;

    /// =====================================================================
    /// SETUP
    /// =====================================================================

    function setUp() public {
        feed18 = new MutableFeedMock(18, "DAI / USD");
        wrapper18 = new FundamentalStablecoinChainlinkOracle(address(feed18), MIN_PEG_18);
    }

    /// =====================================================================
    /// PEG-ANCHOR PARTITION OVER THE FULL int256 DOMAIN
    /// =====================================================================

    /**
     * @notice Fuzz: over the full int256 answer domain the 18-decimal wrapper partitions exactly at MIN_PRICE_AT_PEG —
     *         answers >= 0.999e18 anchor to 1e18, everything below (including zero and negatives) passes through
     * @param _answer The raw underlying feed answer, unconstrained over int256
     */
    function testFuzz_latestRoundData_pegAnchorPartitionFullIntDomain(int256 _answer) external {
        feed18.setAnswer(_answer);

        (, int256 wrappedAnswer,,,) = wrapper18.latestRoundData();
        if (_answer >= MIN_PEG_18) {
            assertEq(wrappedAnswer, ONE_18, "Any answer at or above the minimum peg price must anchor to exactly 1 quote asset");
        } else {
            assertEq(wrappedAnswer, _answer, "Any answer below the minimum peg price must pass through unchanged");
        }
    }

    /// @notice The int256 extremes land on the correct sides of the partition: int256.max anchors, int256.min passes through
    function test_latestRoundData_intExtremesPartitionCorrectly() external {
        feed18.setAnswer(type(int256).max);
        (, int256 answerAtMax,,,) = wrapper18.latestRoundData();
        assertEq(answerAtMax, ONE_18, "An answer of int256.max must anchor to 1 quote asset");

        feed18.setAnswer(type(int256).min);
        (, int256 answerAtMin,,,) = wrapper18.latestRoundData();
        assertEq(answerAtMin, type(int256).min, "An answer of int256.min must pass through unchanged");
    }

    /// @notice The threshold boundary pair on the 18-decimal feed: MIN_PEG anchors, MIN_PEG - 1 wei passes through
    function test_latestRoundData_thresholdBoundaryPair18Dec() external {
        feed18.setAnswer(MIN_PEG_18);
        (, int256 answerAtPeg,,,) = wrapper18.latestRoundData();
        assertEq(answerAtPeg, ONE_18, "An answer of exactly the minimum peg price must anchor to 1 quote asset");

        feed18.setAnswer(MIN_PEG_18 - 1);
        (, int256 answerBelowPeg,,,) = wrapper18.latestRoundData();
        assertEq(answerBelowPeg, MIN_PEG_18 - 1, "An answer one wei below the minimum peg price must pass through unchanged");
    }

    /// =====================================================================
    /// CONSTRUCTOR BOUNDS (18-DECIMAL FEED)
    /// =====================================================================

    /// @notice Fuzz: any minimum peg price outside (0, 1e18) is rejected with INVALID_MIN_PRICE_AT_PEG on an 18-decimal feed
    function testFuzz_constructor_rejectsOutOfRangeMinPeg18Dec(int256 _minPriceAtPeg) external {
        vm.assume(_minPriceAtPeg <= 0 || _minPriceAtPeg >= ONE_18);

        vm.expectRevert(FundamentalStablecoinChainlinkOracle.INVALID_MIN_PRICE_AT_PEG.selector);
        new FundamentalStablecoinChainlinkOracle(address(feed18), _minPriceAtPeg);
    }

    /// @notice Fuzz: any minimum peg price inside (0, 1e18) is accepted and stored unchanged on an 18-decimal feed
    function testFuzz_constructor_acceptsInRangeMinPeg18Dec(int256 _minPriceAtPeg) external {
        _minPriceAtPeg = bound(_minPriceAtPeg, 1, ONE_18 - 1);

        FundamentalStablecoinChainlinkOracle wrapper = new FundamentalStablecoinChainlinkOracle(address(feed18), _minPriceAtPeg);
        assertEq(wrapper.MIN_PRICE_AT_PEG(), _minPriceAtPeg, "Any in-range minimum peg price must be stored unchanged");
        assertEq(wrapper.ONE_QUOTE_ASSET(), ONE_18, "ONE_QUOTE_ASSET must be derived from the feed's 18 decimals");
    }

    /**
     * @notice PINS the 0-decimal impossibility: ONE_QUOTE_ASSET = 1 makes the valid range (0, 1) empty, so NO
     *         minimum peg price can construct a wrapper over a 0-decimal feed
     * @dev Both nearest candidates are probed: 0 fails the lower strict bound and 1 fails the upper strict bound
     */
    function test_constructor_zeroDecimalFeedIsUnconstructible() external {
        MutableFeedMock feed0 = new MutableFeedMock(0, "INT / USD");

        vm.expectRevert(FundamentalStablecoinChainlinkOracle.INVALID_MIN_PRICE_AT_PEG.selector);
        new FundamentalStablecoinChainlinkOracle(address(feed0), 0);

        vm.expectRevert(FundamentalStablecoinChainlinkOracle.INVALID_MIN_PRICE_AT_PEG.selector);
        new FundamentalStablecoinChainlinkOracle(address(feed0), 1);
    }

    /// =====================================================================
    /// ROUND-DATA PASSTHROUGH EXACTNESS
    /// =====================================================================

    /**
     * @notice Fuzz: getRoundData(anyRoundId) returns the underlying feed's tuple field-for-field, with the answer
     *         as the ONLY field the wrapper may rewrite (and only per the peg-anchor rule)
     * @dev The mock echoes the requested round ID into its returned roundId, so the roundId equality also proves
     *      the wrapper forwarded the requested ID to the underlying feed unmodified
     * @param _requestedRoundId The round ID requested from the wrapper
     * @param _answer The underlying feed answer, unconstrained over int256
     * @param _startedAt The underlying round's startedAt timestamp, unconstrained over uint256
     * @param _updatedAt The underlying round's updatedAt timestamp, unconstrained over uint256
     * @param _answeredInRound The underlying round's answeredInRound, configured independently of the requested ID
     */
    function testFuzz_getRoundData_fullTuplePassthroughExactness(
        uint80 _requestedRoundId,
        int256 _answer,
        uint256 _startedAt,
        uint256 _updatedAt,
        uint80 _answeredInRound
    )
        external
    {
        feed18.setRoundData(1, _answer, _startedAt, _updatedAt, _answeredInRound);

        (uint80 underlyingRoundId, int256 underlyingAnswer, uint256 underlyingStartedAt, uint256 underlyingUpdatedAt, uint80 underlyingAnsweredInRound) =
            feed18.getRoundData(_requestedRoundId);
        (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound) = wrapper18.getRoundData(_requestedRoundId);

        assertEq(roundId, underlyingRoundId, "The wrapper must pass the underlying round ID through unchanged");
        assertEq(roundId, _requestedRoundId, "The wrapper must forward the requested round ID to the underlying feed");
        assertEq(startedAt, underlyingStartedAt, "The wrapper must pass startedAt through unchanged");
        assertEq(updatedAt, underlyingUpdatedAt, "The wrapper must pass updatedAt through unchanged");
        assertEq(answeredInRound, underlyingAnsweredInRound, "The wrapper must pass answeredInRound through unchanged");
        if (_answer >= MIN_PEG_18) {
            assertEq(answer, ONE_18, "An answer at or above the minimum peg price must anchor to 1 quote asset");
            assertEq(underlyingAnswer, _answer, "The underlying answer itself must be untouched by the wrapper");
        } else {
            assertEq(answer, underlyingAnswer, "An answer below the minimum peg price must pass through unchanged");
        }
    }

    /**
     * @notice Fuzz: latestRoundData passes every non-answer field through unchanged, including staleness-relevant
     *         extremes — startedAt/updatedAt of 0 (never updated) and uint256.max survive untouched on both the
     *         anchored and pass-through answer paths
     * @param _roundId The underlying round ID
     * @param _answer The underlying feed answer, unconstrained over int256
     * @param _startedAt The underlying round's startedAt timestamp, unconstrained over uint256
     * @param _updatedAt The underlying round's updatedAt timestamp, unconstrained over uint256
     * @param _answeredInRound The underlying round's answeredInRound
     */
    function testFuzz_latestRoundData_stalenessFieldsPassThroughUnchanged(
        uint80 _roundId,
        int256 _answer,
        uint256 _startedAt,
        uint256 _updatedAt,
        uint80 _answeredInRound
    )
        external
    {
        feed18.setRoundData(_roundId, _answer, _startedAt, _updatedAt, _answeredInRound);

        (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound) = wrapper18.latestRoundData();

        assertEq(roundId, _roundId, "The wrapper must pass the underlying round ID through unchanged");
        assertEq(startedAt, _startedAt, "The wrapper must pass startedAt through unchanged for staleness checks downstream");
        assertEq(updatedAt, _updatedAt, "The wrapper must pass updatedAt through unchanged for staleness checks downstream");
        assertEq(answeredInRound, _answeredInRound, "The wrapper must pass answeredInRound through unchanged");
        assertEq(answer, _answer >= MIN_PEG_18 ? ONE_18 : _answer, "The answer must follow the peg-anchor partition exactly");
    }

    /// @notice Zero timestamps (a never-updated feed) pass through unchanged: the wrapper adds no staleness opinion of its own
    function test_latestRoundData_zeroTimestampsPassThrough() external {
        feed18.setRoundData(5, MIN_PEG_18, 0, 0, 5);

        (, int256 answer, uint256 startedAt, uint256 updatedAt,) = wrapper18.latestRoundData();
        assertEq(startedAt, 0, "A zero startedAt must pass through so downstream staleness checks can reject it");
        assertEq(updatedAt, 0, "A zero updatedAt must pass through so downstream staleness checks can reject it");
        assertEq(answer, ONE_18, "The anchored answer path must not disturb timestamp passthrough");
    }

    /// =====================================================================
    /// LIVE DECIMALS MIRRORING vs CONSTRUCTION-FROZEN ONE_QUOTE_ASSET
    /// =====================================================================

    /**
     * @notice Fuzz: decimals() mirrors the underlying feed LIVE across the whole 0..77 range while ONE_QUOTE_ASSET
     *         and MIN_PRICE_AT_PEG stay frozen at their construction-time snapshot
     * @dev PINS the intentional divergence: a feed that migrates its decimals after wrapper deployment changes the
     *      wrapper's reported decimals but NOT its anchoring arithmetic
     * @param _liveDecimals The feed's post-construction decimals, bounded to the 0..77 domain
     */
    function testFuzz_decimals_mirrorsLiveFeedWhileOneQuoteAssetStaysFrozen(uint8 _liveDecimals) external {
        _liveDecimals = uint8(bound(_liveDecimals, 0, 77));
        feed18.setDecimals(_liveDecimals);

        assertEq(wrapper18.decimals(), _liveDecimals, "decimals() must mirror the underlying feed's live value at every call");
        assertEq(wrapper18.ONE_QUOTE_ASSET(), ONE_18, "ONE_QUOTE_ASSET must stay frozen at its construction-time snapshot");
        assertEq(wrapper18.MIN_PRICE_AT_PEG(), MIN_PEG_18, "MIN_PRICE_AT_PEG must stay frozen at its construction-time snapshot");
    }

    /// =====================================================================
    /// DESCRIPTION COMPOSITION UNDER WEIRD DECIMALS
    /// =====================================================================

    /// @notice A 1-decimal underlying renders its threshold with a single fractional digit
    function test_description_oneDecimalFeedRendersSingleFractionalDigit() external {
        MutableFeedMock feed1 = new MutableFeedMock(1, "TKN / USD");
        FundamentalStablecoinChainlinkOracle wrapper1 = new FundamentalStablecoinChainlinkOracle(address(feed1), 5);

        assertEq(
            wrapper1.description(),
            "TKN / USD (Royco fundamental stablecoin peg wrapper: prices at or above 0.5 are reported as 1 quote asset)",
            "A 1-decimal feed must render the threshold as a single fractional digit"
        );
    }

    /// @notice A 2-decimal underlying renders its highest valid threshold as 0.99
    function test_description_twoDecimalFeedRendersTwoFractionalDigits() external {
        MutableFeedMock feed2 = new MutableFeedMock(2, "CENT / USD");
        FundamentalStablecoinChainlinkOracle wrapper2 = new FundamentalStablecoinChainlinkOracle(address(feed2), 99);

        assertEq(
            wrapper2.description(),
            "CENT / USD (Royco fundamental stablecoin peg wrapper: prices at or above 0.99 are reported as 1 quote asset)",
            "A 2-decimal feed must render the threshold with two fractional digits"
        );
    }

    /**
     * @notice PINS the live-decimals divergence in description(): the frozen MIN_PRICE_AT_PEG (0.999e18) is rendered
     *         with the feed's LIVE decimals, so after the feed migrates to 2 decimals the threshold renders as
     *         999000000000000000 / 10^2 = "9990000000000000.00"
     */
    function test_description_liveDecimalsShrink_rendersFrozenThresholdAtLivePrecision() external {
        feed18.setDecimals(2);

        assertEq(
            wrapper18.description(),
            "DAI / USD (Royco fundamental stablecoin peg wrapper: prices at or above 9990000000000000.00 are reported as 1 quote asset)",
            "The frozen threshold must be rendered at the feed's live 2-decimal precision"
        );
    }

    /**
     * @notice PINS the 0-live-decimals rendering: with no fractional digits the formatter emits the integer part
     *         followed by a bare trailing decimal point — "999000000000000000."
     * @dev The trailing dot is an intentional consequence of the fixed-width fractional rendering, not a bug to fix here
     */
    function test_description_zeroLiveDecimals_rendersTrailingDecimalPoint() external {
        feed18.setDecimals(0);

        assertEq(
            wrapper18.description(),
            "DAI / USD (Royco fundamental stablecoin peg wrapper: prices at or above 999000000000000000. are reported as 1 quote asset)",
            "A 0-decimal live feed must render the frozen threshold as its integer digits with a bare trailing decimal point"
        );
    }
}
