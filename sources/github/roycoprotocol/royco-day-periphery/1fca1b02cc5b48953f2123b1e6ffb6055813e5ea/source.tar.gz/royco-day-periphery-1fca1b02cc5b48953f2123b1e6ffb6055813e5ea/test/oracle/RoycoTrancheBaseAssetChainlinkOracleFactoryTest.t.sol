// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { Test } from "../../lib/forge-std/src/Test.sol";

import { ERC20Mock } from "../../lib/openzeppelin-contracts/contracts/mocks/token/ERC20Mock.sol";

import { IRoycoAuth } from "../../lib/royco-day/src/interfaces/IRoycoAuth.sol";
import { RoycoTrancheValidator } from "../../src/base/RoycoTrancheValidator.sol";
import { IRoycoFactory } from "../../lib/royco-day/src/interfaces/factory/IRoycoFactory.sol";
import { TrancheType } from "../../lib/royco-day/src/libraries/Types.sol";
import { RoycoTrancheBaseAssetChainlinkOracle } from "../../src/oracle/tranche-share-to-base-asset-oracle/RoycoTrancheBaseAssetChainlinkOracle.sol";
import { RoycoTrancheBaseAssetChainlinkOracleFactory } from
    "../../src/oracle/tranche-share-to-base-asset-oracle/RoycoTrancheBaseAssetChainlinkOracleFactory.sol";

import { MockRoycoFactory } from "../mock/MockRoycoFactory.sol";
import { MockTranche } from "../mock/MockTranche.sol";

/// @title RoycoTrancheBaseAssetChainlinkOracleFactoryTest
/// @notice Unit tests for the permissionless base asset oracle factory and its Royco factory provenance check
contract RoycoTrancheBaseAssetChainlinkOracleFactoryTest is Test {
    ERC20Mock internal baseAsset;
    MockTranche internal seniorTranche;
    MockRoycoFactory internal mockRoycoFactory;
    RoycoTrancheBaseAssetChainlinkOracleFactory internal factory;

    /// @dev Placeholder kernel registered against each mock tranche in the mock Royco factory
    address internal constant KERNEL_PLACEHOLDER = address(0xCAFE);

    /// @notice Mirrors the factory's OracleDeployed event for expectEmit assertions
    event OracleDeployed(address indexed tranche, address indexed oracle);

    function setUp() external {
        baseAsset = new ERC20Mock();
        seniorTranche = new MockTranche(address(baseAsset), address(this), TrancheType.SENIOR);
        mockRoycoFactory = new MockRoycoFactory();
        mockRoycoFactory.registerTranche(address(seniorTranche), KERNEL_PLACEHOLDER);
        factory = new RoycoTrancheBaseAssetChainlinkOracleFactory(IRoycoFactory(address(mockRoycoFactory)));
    }

    /// @notice The constructor rejects the null Royco factory
    function test_constructor_revertsOnNullRoycoFactory() external {
        vm.expectRevert(IRoycoAuth.NULL_ADDRESS.selector);
        new RoycoTrancheBaseAssetChainlinkOracleFactory(IRoycoFactory(address(0)));
    }

    /// @notice The constructor stores the Royco factory every ostensible tranche is verified against
    function test_constructor_setsRoycoFactory() external view {
        assertEq(address(factory.ROYCO_FACTORY()), address(mockRoycoFactory), "The Royco factory should be stored");
    }

    /// @notice Deploys an oracle for a registered tranche, records the mapping, and emits the deployment event
    function test_deployOracle_deploysRecordsAndEmits() external {
        address predicted = factory.predictOracleAddress(address(seniorTranche));

        vm.expectEmit(true, true, true, true, address(factory));
        emit OracleDeployed(address(seniorTranche), predicted);
        address oracle = factory.deployOracle(address(seniorTranche));

        assertEq(factory.trancheToOracle(address(seniorTranche)), oracle, "The oracle should be recorded for the tranche");
        assertEq(RoycoTrancheBaseAssetChainlinkOracle(oracle).ROYCO_TRANCHE(), address(seniorTranche), "The oracle should be wired to the tranche");
        assertEq(RoycoTrancheBaseAssetChainlinkOracle(oracle).BASE_ASSET(), address(baseAsset), "The oracle should resolve the base asset");
    }

    /// @notice The predicted CREATE2 address must match the actually deployed address
    function test_predictOracleAddress_matchesDeployment() external {
        address predicted = factory.predictOracleAddress(address(seniorTranche));
        address deployed = factory.deployOracle(address(seniorTranche));
        assertEq(deployed, predicted, "Predicted and deployed addresses should match");
    }

    /// @notice Deployment reverts for an address the Royco factory never deployed
    function test_deployOracle_revertsForUnregisteredTranche() external {
        MockTranche unregistered = new MockTranche(address(baseAsset), address(this), TrancheType.SENIOR);

        vm.expectRevert(abi.encodeWithSelector(RoycoTrancheValidator.NOT_A_ROYCO_TRANCHE.selector, address(unregistered)));
        factory.deployOracle(address(unregistered));
    }

    /// @notice The null tranche address is unregistered by construction and rejected by the provenance check
    function test_deployOracle_revertsOnNullTranche() external {
        vm.expectRevert(IRoycoAuth.NULL_ADDRESS.selector);
        factory.deployOracle(address(0));
    }

    /// @notice A registered liquidity provider tranche deploys successfully and prices via the LPT-asset leg
    function test_deployOracle_succeedsForLiquidityProviderTranche() external {
        MockTranche liquidityTranche = new MockTranche(address(baseAsset), address(this), TrancheType.LIQUIDITY_PROVIDER);
        mockRoycoFactory.registerTranche(address(liquidityTranche), KERNEL_PLACEHOLDER);

        address oracle = factory.deployOracle(address(liquidityTranche));

        assertEq(factory.trancheToOracle(address(liquidityTranche)), oracle, "The oracle should be recorded for the LPT");
        assertEq(uint8(RoycoTrancheBaseAssetChainlinkOracle(oracle).TRANCHE_TYPE()), uint8(TrancheType.LIQUIDITY_PROVIDER), "The tranche type should be cached");
        assertEq(RoycoTrancheBaseAssetChainlinkOracle(oracle).BASE_ASSET(), address(baseAsset), "The base asset should resolve from the LPT's asset");
    }

    /// @notice A tranche rejected while unregistered deploys successfully once the Royco factory registers it
    function test_deployOracle_succeedsOnceRegistered() external {
        MockTranche lateTranche = new MockTranche(address(baseAsset), address(this), TrancheType.JUNIOR);

        vm.expectRevert(abi.encodeWithSelector(RoycoTrancheValidator.NOT_A_ROYCO_TRANCHE.selector, address(lateTranche)));
        factory.deployOracle(address(lateTranche));

        mockRoycoFactory.registerTranche(address(lateTranche), KERNEL_PLACEHOLDER);
        address oracle = factory.deployOracle(address(lateTranche));

        assertEq(factory.trancheToOracle(address(lateTranche)), oracle, "The oracle should be recorded once the tranche is registered");
        assertEq(RoycoTrancheBaseAssetChainlinkOracle(oracle).ROYCO_TRANCHE(), address(lateTranche), "The oracle should be wired to the tranche");
    }
}
