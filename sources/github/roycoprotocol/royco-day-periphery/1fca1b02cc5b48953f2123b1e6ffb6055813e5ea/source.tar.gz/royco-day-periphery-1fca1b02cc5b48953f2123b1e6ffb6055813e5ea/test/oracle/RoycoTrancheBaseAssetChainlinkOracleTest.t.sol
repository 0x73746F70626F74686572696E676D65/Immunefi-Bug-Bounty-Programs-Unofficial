// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { Test } from "../../lib/forge-std/src/Test.sol";

import { ERC20Mock } from "../../lib/openzeppelin-contracts/contracts/mocks/token/ERC20Mock.sol";

import { IRoycoVaultTranche } from "../../lib/royco-day/src/interfaces/IRoycoVaultTranche.sol";
import { WAD } from "../../lib/royco-day/src/libraries/Constants.sol";
import { TrancheType } from "../../lib/royco-day/src/libraries/Types.sol";
import { TRANCHE_UNIT } from "../../lib/royco-day/src/libraries/Units.sol";
import { RoycoTrancheBaseAssetChainlinkOracle } from "../../src/oracle/tranche-share-to-base-asset-oracle/RoycoTrancheBaseAssetChainlinkOracle.sol";

import { MockTranche } from "../mock/MockTranche.sol";

/// @title RoycoTrancheBaseAssetChainlinkOracleTest
/// @notice Unit tests for RoycoTrancheBaseAssetChainlinkOracle backed by MockTranche
/// @dev The oracle answers the base asset claims of the tranche's typed AssetClaims for 1 whole share (1e18): the
///      LPT-asset leg for the liquidity provider tranche and the collateral-asset leg otherwise
contract RoycoTrancheBaseAssetChainlinkOracleTest is Test {
    ERC20Mock internal baseAsset;
    MockTranche internal seniorTranche;
    MockTranche internal liquidityTranche;
    RoycoTrancheBaseAssetChainlinkOracle internal oracle;
    RoycoTrancheBaseAssetChainlinkOracle internal lptOracle;

    function setUp() external {
        baseAsset = new ERC20Mock();
        seniorTranche = new MockTranche(address(baseAsset), address(this), TrancheType.SENIOR);
        liquidityTranche = new MockTranche(address(baseAsset), address(this), TrancheType.LIQUIDITY_PROVIDER);
        oracle = new RoycoTrancheBaseAssetChainlinkOracle(address(seniorTranche));
        lptOracle = new RoycoTrancheBaseAssetChainlinkOracle(address(liquidityTranche));
    }

    /// @notice Constructor caches the tranche, its type, and its base asset for every tranche type
    function test_constructor_cachesTrancheTypeAndBaseAsset() external view {
        assertEq(oracle.ROYCO_TRANCHE(), address(seniorTranche), "The oracle should be wired to the tranche");
        assertEq(uint8(oracle.TRANCHE_TYPE()), uint8(TrancheType.SENIOR), "The oracle should cache the tranche type");
        assertEq(oracle.BASE_ASSET(), address(baseAsset), "The base asset should resolve from the tranche's asset");

        assertEq(lptOracle.ROYCO_TRANCHE(), address(liquidityTranche), "The LPT oracle should be wired to the tranche");
        assertEq(uint8(lptOracle.TRANCHE_TYPE()), uint8(TrancheType.LIQUIDITY_PROVIDER), "The LPT oracle should cache the tranche type");
        assertEq(lptOracle.BASE_ASSET(), address(baseAsset), "The LPT oracle's base asset should resolve from the tranche's asset");
    }

    /// @notice The answer for a senior tranche is the collateral-asset leg of the asset claims for 1 whole share
    function test_latestRoundData_seniorTranchePricesViaCollateralLeg() external {
        // At a 2x share price, 1e18 shares are worth 2e18 base assets
        baseAsset.mint(address(this), 10e18);
        baseAsset.approve(address(seniorTranche), 10e18);
        seniorTranche.deposit(_toTrancheUnits(10e18), address(this));
        seniorTranche.setSharePrice(2e18);

        (, int256 answer,,,) = oracle.latestRoundData();
        assertEq(answer, 2e18, "Answer should be the collateral asset claim for 1 whole share");
    }

    /// @notice The answer for a liquidity provider tranche is the LPT-asset leg of the asset claims for 1 whole share
    function test_latestRoundData_liquidityProviderTranchePricesViaLptLeg() external {
        // The LPT-type mock reports its claims in the LPT-asset leg; at a 3x share price 1e18 shares are worth 3e18 assets
        liquidityTranche.setSharePrice(3e18);

        (, int256 answer,,,) = lptOracle.latestRoundData();
        assertEq(answer, 3e18, "Answer should be the LPT asset claim for 1 whole share");
    }

    /// @notice A senior oracle reads ONLY the collateral-asset leg: the lptAssets, stShares, and nav legs are ignored
    function test_latestRoundData_seniorIgnoresNonCollateralLegs() external {
        vm.mockCall(
            address(seniorTranche),
            abi.encodeCall(IRoycoVaultTranche.convertToAssets, (WAD)),
            abi.encode(uint256(3e18), uint256(1e18), uint256(2e18), uint256(4e18))
        );

        (, int256 answer,,,) = oracle.latestRoundData();
        assertEq(answer, 3e18, "Answer should be the collateralAssets leg alone, never a sum with the other legs");
    }

    /// @notice An LPT oracle reads ONLY the LPT-asset leg: the held-senior-shares leg is intentionally excluded
    function test_latestRoundData_lptIgnoresStSharesAndOtherLegs() external {
        vm.mockCall(
            address(liquidityTranche),
            abi.encodeCall(IRoycoVaultTranche.convertToAssets, (WAD)),
            abi.encode(uint256(9e18), uint256(5e18), uint256(2e18), uint256(8e18))
        );

        (, int256 answer,,,) = lptOracle.latestRoundData();
        assertEq(answer, 5e18, "Answer should be the lptAssets leg alone, excluding the held senior shares");
    }

    /// @notice A reverting tranche query bubbles up its revert reason verbatim
    function test_latestRoundData_bubblesTrancheRevertReason() external {
        vm.mockCallRevert(address(seniorTranche), abi.encodeCall(IRoycoVaultTranche.convertToAssets, (WAD)), "SOME_TRANCHE_ERROR");

        vm.expectRevert(bytes("SOME_TRANCHE_ERROR"));
        oracle.latestRoundData();
    }

    /// @notice getRoundData only serves round 1
    function test_getRoundData_revertsForInvalidRound() external {
        vm.expectRevert(bytes("No data present"));
        oracle.getRoundData(2);
    }

    /// @notice The oracle reports the base asset's decimals
    function test_decimals_matchesBaseAsset() external view {
        assertEq(oracle.decimals(), 18, "Decimals should mirror the base asset");
        assertEq(lptOracle.decimals(), 18, "LPT oracle decimals should mirror the base asset");
    }

    /// @notice The description composes `<tranche symbol> / <base asset symbol>` per the Chainlink base/quote convention
    function test_description_composesBaseQuotePair() external view {
        assertEq(
            oracle.description(),
            string(abi.encodePacked(seniorTranche.symbol(), " / ", baseAsset.symbol())),
            "Description should compose the tranche and base asset symbols as a base/quote pair"
        );
        assertEq(oracle.description(), "MST / E20M", "The senior description should be the exact base/quote string");
        assertEq(
            lptOracle.description(),
            string(abi.encodePacked(liquidityTranche.symbol(), " / ", baseAsset.symbol())),
            "LPT description should compose the tranche and base asset symbols as a base/quote pair"
        );
    }

    /// @notice The oracle reports version 1
    function test_version_isOne() external view {
        assertEq(oracle.version(), 1, "Version should be 1");
    }

    /// @notice getRoundData for round 1 mirrors latestRoundData
    function test_getRoundData_roundOneMirrorsLatest() external view {
        (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound) = oracle.getRoundData(1);
        (uint80 latestRoundId, int256 latestAnswer, uint256 latestStartedAt, uint256 latestUpdatedAt, uint80 latestAnsweredInRound) = oracle.latestRoundData();
        assertEq(roundId, latestRoundId, "Round IDs should match");
        assertEq(answer, latestAnswer, "Answers should match");
        assertEq(startedAt, latestStartedAt, "Started timestamps should match");
        assertEq(updatedAt, latestUpdatedAt, "Updated timestamps should match");
        assertEq(answeredInRound, latestAnsweredInRound, "Answered in round should match");
    }

    /// @dev Wraps a raw amount as tranche units for MockTranche calls
    function _toTrancheUnits(uint256 _amount) internal pure returns (TRANCHE_UNIT) {
        return TRANCHE_UNIT.wrap(_amount);
    }

    /// @notice Fuzz: the senior answer tracks the share price through the collateral-asset leg
    /// @param _sharePriceWAD The tranche share price in WAD
    function testFuzz_latestRoundData_seniorMatchesSharePrice(uint256 _sharePriceWAD) external {
        _sharePriceWAD = bound(_sharePriceWAD, 0, type(uint128).max);
        seniorTranche.setSharePrice(_sharePriceWAD);

        (, int256 answer,,,) = oracle.latestRoundData();
        // For 1e18 shares of a senior tranche at the configured price, the collateral claim equals the share price
        assertEq(answer, int256(_sharePriceWAD), "Answer should equal the share price via the collateral-asset leg");
    }

    /// @notice Fuzz: the LPT answer tracks the share price through the LPT-asset leg
    /// @param _sharePriceWAD The tranche share price in WAD
    function testFuzz_latestRoundData_lptMatchesSharePrice(uint256 _sharePriceWAD) external {
        _sharePriceWAD = bound(_sharePriceWAD, 0, type(uint128).max);
        liquidityTranche.setSharePrice(_sharePriceWAD);

        (, int256 answer,,,) = lptOracle.latestRoundData();
        // For 1e18 shares of an LPT at the configured price, the LPT-asset claim equals the share price
        assertEq(answer, int256(_sharePriceWAD), "Answer should equal the share price via the LPT-asset leg");
    }
}
