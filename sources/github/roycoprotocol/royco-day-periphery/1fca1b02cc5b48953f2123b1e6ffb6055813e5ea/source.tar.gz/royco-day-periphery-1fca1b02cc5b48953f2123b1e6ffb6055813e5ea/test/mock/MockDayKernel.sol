// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { AssetClaims, SyncedAccountingState, TrancheType } from "../../lib/royco-day/src/libraries/Types.sol";

/// @title MockDayKernel
/// @notice A minimal mock of the Royco Day kernel's preview sync for testing periphery consumers
contract MockDayKernel {
    /// @dev The synced accounting state the preview answers (zero-initialized unless set)
    SyncedAccountingState internal state;

    /// @dev The cumulative tranche claims the preview answers
    AssetClaims internal claims;

    /// @dev The post-mint tranche share supply the preview answers
    uint256 internal totalTrancheShares;

    /// @notice Sets the cumulative claims and post-mint share supply the preview answers
    function setPreview(AssetClaims calldata _claims, uint256 _totalTrancheShares) external {
        claims = _claims;
        totalTrancheShares = _totalTrancheShares;
    }

    /// @notice Answers the configured preview for any tranche type
    function previewSyncTrancheAccountingFor(TrancheType) external view returns (SyncedAccountingState memory, AssetClaims memory, uint256) {
        return (state, claims, totalTrancheShares);
    }
}
