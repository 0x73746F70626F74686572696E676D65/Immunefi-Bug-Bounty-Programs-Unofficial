// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { Test, stdError } from "../../lib/forge-std/src/Test.sol";
import { Vm } from "../../lib/forge-std/src/Vm.sol";

import { ERC20Mock } from "../../lib/openzeppelin-contracts/contracts/mocks/token/ERC20Mock.sol";
import { ERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/ERC20.sol";

import { ITransparentUpgradeableProxy } from "../../lib/openzeppelin-contracts-v4/contracts/proxy/transparent/TransparentUpgradeableProxy.sol";

import { Errors } from "../../lib/Pendle-SY-Public/contracts/core/libraries/Errors.sol";

import { IRoycoFactory } from "../../lib/royco-day/src/interfaces/factory/IRoycoFactory.sol";
import { AssetClaims, SyncedAccountingState, TrancheType } from "../../lib/royco-day/src/libraries/Types.sol";
import { toNAVUnits, toTrancheUnits } from "../../lib/royco-day/src/libraries/Units.sol";
import { PendleRoycoTrancheSY } from "../../src/pendle/PendleRoycoTrancheSY.sol";
import { PendleRoycoTrancheSYFactory } from "../../src/pendle/PendleRoycoTrancheSYFactory.sol";

import { MockDayKernel } from "../mock/MockDayKernel.sol";
import { MockRoycoFactory } from "../mock/MockRoycoFactory.sol";
import { MockTranche } from "../mock/MockTranche.sol";

/// @notice A kernel double whose previewSyncTrancheAccountingFor answers arbitrary raw bytes, set per test
/// @dev Pins the SY's typed decode of the kernel's (SyncedAccountingState, AssetClaims, uint256) preview tuple
contract RawReturnKernel {
    bytes internal returndata;

    /// @notice Arms the raw bytes every subsequent call to this kernel returns
    function setReturndata(bytes calldata _returnData) external {
        returndata = _returnData;
    }

    fallback() external {
        bytes memory data = returndata;
        assembly ("memory-safe") {
            return(add(data, 0x20), mload(data))
        }
    }
}

/**
 * @notice A malicious Royco tranche double: a registered tranche share whose transferFrom reenters the calling SY's
 *         deposit/redeem mid-wrap, optionally catching the inner revert to record it byte-exactly
 * @dev The SY pulls tranche shares via safeTransferFrom inside its nonReentrant deposit, so the share's transferFrom
 *      hook is the only mid-flight foothold a tranche has left into the wrap; this pins Pendle's reentrancy guard
 */
contract MaliciousTranche is ERC20 {
    enum ReentryMode {
        NONE,
        REENTER_DEPOSIT,
        REENTER_REDEEM
    }

    /// @dev The kernel the SY caches at construction (never consulted by the deposit/redeem paths under test)
    address public immutable KERNEL_ADDRESS;

    // Reentry configuration and recorded outcome
    ReentryMode public reentryMode;
    bool public catchReentry;
    bool public reentrySucceeded;
    bytes public lastReentryRevertData;

    constructor(address _kernel) ERC20("Malicious Tranche", "EVIL") {
        KERNEL_ADDRESS = _kernel;
    }

    /// @notice The tranche's kernel, read by the SY constructor
    function kernel() external view returns (address) {
        return KERNEL_ADDRESS;
    }

    /// @notice The tranche's type, read by the SY constructor
    function TRANCHE_TYPE() external pure returns (TrancheType) {
        return TrancheType.SENIOR;
    }

    /// @notice Mints tranche shares to a depositor, standing in for an honest tranche deposit
    function mint(address _to, uint256 _amount) external {
        _mint(_to, _amount);
    }

    /// @notice Arms a reentry into the pulling SY during transferFrom, optionally catching the inner revert to record it
    function setReentry(ReentryMode _mode, bool _catch) external {
        reentryMode = _mode;
        catchReentry = _catch;
    }

    /// @notice Performs the honest share transfer, then reenters the pulling SY per the armed mode
    function transferFrom(address _from, address _to, uint256 _amount) public override returns (bool success) {
        success = super.transferFrom(_from, _to, _amount);

        PendleRoycoTrancheSY syCaller = PendleRoycoTrancheSY(payable(msg.sender));
        if (reentryMode == ReentryMode.REENTER_DEPOSIT) {
            if (catchReentry) {
                try syCaller.deposit(address(this), address(this), 1, 0) returns (uint256) {
                    reentrySucceeded = true;
                } catch (bytes memory _err) {
                    lastReentryRevertData = _err;
                }
            } else {
                syCaller.deposit(address(this), address(this), 1, 0);
            }
        } else if (reentryMode == ReentryMode.REENTER_REDEEM) {
            if (catchReentry) {
                try syCaller.redeem(address(this), 1, address(this), 0, false) returns (uint256) {
                    reentrySucceeded = true;
                } catch (bytes memory _err) {
                    lastReentryRevertData = _err;
                }
            } else {
                syCaller.redeem(address(this), 1, address(this), 0, false);
            }
        }
    }
}

/**
 * @title PendleRoycoTrancheSYAdversarialTest
 * @notice Adversarial tests for PendleRoycoTrancheSY + PendleRoycoTrancheSYFactory: yieldToken-only token surface,
 *         exchangeRate rate boundaries and kernel-preview returndata decode, reentrant tranche shares probing
 *         Pendle's nonReentrant guard, factory slot/proxy-admin/naming edges, and wrap/unwrap exactness fuzz
 * @dev Complements (never duplicates) PendleRoycoTrancheSYTest and PendleRoycoTrancheSYFactoryTest, which cover the
 *      happy-path wrap flows and factory wiring
 */
contract PendleRoycoTrancheSYAdversarialTest is Test {
    /// =====================================================================
    /// CONSTANTS
    /// =====================================================================
    address internal constant PENDLE_PROXY_ADMIN = 0xA28c08f165116587D4F3E708743B4dEe155c5E64;
    address internal constant PENDLE_PAUSE_CONTROLLER = 0x2aD631F72fB16d91c4953A7f4260A97C2fE2f31e;
    /// @dev EIP-1967 admin storage slot: bytes32(uint256(keccak256("eip1967.proxy.admin")) - 1)
    bytes32 internal constant ADMIN_SLOT = 0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103;
    /// @dev PMath.ONE — the SY queries convertToAssets with exactly this share count inside exchangeRate
    uint256 internal constant PMATH_ONE = 1e18;

    /// =====================================================================
    /// STATE
    /// =====================================================================
    ERC20Mock internal asset;
    MockRoycoFactory internal mockRoycoFactory;
    MockDayKernel internal mockDayKernel;
    MockTranche internal seniorTranche;
    PendleRoycoTrancheSYFactory internal syFactory;
    PendleRoycoTrancheSY internal sy;

    address internal kernel = makeAddr("kernel");
    address internal trancheAuthority = makeAddr("trancheAuthority");
    address internal rewardManager = makeAddr("rewardManager");
    address internal alice = makeAddr("alice");
    address internal bob = makeAddr("bob");

    /// =====================================================================
    /// SETUP
    /// =====================================================================

    function setUp() public {
        asset = new ERC20Mock();
        mockRoycoFactory = new MockRoycoFactory();
        mockDayKernel = new MockDayKernel();
        // The SY caches the tranche's kernel at construction, so the kernel must be wired before any SY deploys.
        seniorTranche = new MockTranche(address(asset), trancheAuthority, TrancheType.SENIOR);
        seniorTranche.setKernel(address(mockDayKernel));
        mockRoycoFactory.registerTranche(address(seniorTranche), kernel);
        syFactory = new PendleRoycoTrancheSYFactory(IRoycoFactory(address(mockRoycoFactory)));
        sy = PendleRoycoTrancheSY(payable(syFactory.deploySY(address(seniorTranche), rewardManager)));
    }

    /// =====================================================================
    /// HELPERS
    /// =====================================================================

    /// @dev Deploys a MaliciousTranche registered with the mock Royco factory and an SY over it via the factory
    function _deployMaliciousSetup() internal returns (MaliciousTranche malTranche, PendleRoycoTrancheSY malSy) {
        malTranche = new MaliciousTranche(address(mockDayKernel));
        mockRoycoFactory.registerTranche(address(malTranche), kernel);
        malSy = PendleRoycoTrancheSY(payable(syFactory.deploySY(address(malTranche), address(0))));
    }

    /// @dev Mints malicious tranche shares to a user and wraps them into the SY, returning the SY shares minted
    function _wrapMaliciousShares(MaliciousTranche _tranche, PendleRoycoTrancheSY _sy, address _user, uint256 _shares) internal returns (uint256 sharesOut) {
        _tranche.mint(_user, _shares);
        vm.startPrank(_user);
        _tranche.approve(address(_sy), _shares);
        sharesOut = _sy.deposit(_user, address(_tranche), _shares, 0);
        vm.stopPrank();
    }

    /// @dev Claims + supply whose virtual-shares scaling is exact: with totalTrancheShares = 1e18 - 1 and
    ///      claims.nav = p - 1, the rate floor((p - 1 + 1) * 1e18 / (1e18 - 1 + 1)) == p exactly for any p >= 1
    function _exactRateClaims(uint256 _rateWAD) internal pure returns (AssetClaims memory claims, uint256 totalTrancheShares) {
        claims.nav = toNAVUnits(_rateWAD - 1);
        totalTrancheShares = 1e18 - 1;
    }

    /// @dev Encodes the honest (SyncedAccountingState, AssetClaims, uint256) preview return tuple with a zero state
    function _encodeHonestPreview(AssetClaims memory _claims, uint256 _totalTrancheShares) internal pure returns (bytes memory) {
        SyncedAccountingState memory state;
        return abi.encode(state, _claims, _totalTrancheShares);
    }

    /// @dev Deploys an SY over a registered tranche wired to a RawReturnKernel whose preview returndata is test-set bytes
    function _deployRawKernelSY() internal returns (RawReturnKernel rawKernel, PendleRoycoTrancheSY rawSy) {
        rawKernel = new RawReturnKernel();
        MockTranche rawTranche = new MockTranche(address(asset), trancheAuthority, TrancheType.SENIOR);
        rawTranche.setKernel(address(rawKernel));
        mockRoycoFactory.registerTranche(address(rawTranche), kernel);
        rawSy = PendleRoycoTrancheSY(payable(syFactory.deploySY(address(rawTranche), address(0))));
    }

    /// @dev Returns the first _length bytes of _data
    function _slice(bytes memory _data, uint256 _length) internal pure returns (bytes memory out) {
        out = new bytes(_length);
        for (uint256 i = 0; i < _length; ++i) {
            out[i] = _data[i];
        }
    }

    /// =====================================================================
    /// TOKEN SURFACE: yieldToken ONLY
    /// =====================================================================

    /**
     * @notice The base asset deposit path no longer exists: the tranche's base asset is rejected at the DEPOSIT level
     *         with SYInvalidTokenIn before any funds move, and every view agrees the tranche share is the only token in
     */
    function test_deposit_baseAsset_alwaysRevertsSYInvalidTokenIn() public {
        asset.mint(alice, 1e18);
        vm.startPrank(alice);
        asset.approve(address(sy), type(uint256).max);
        vm.expectRevert(abi.encodeWithSelector(Errors.SYInvalidTokenIn.selector, address(asset)));
        sy.deposit(alice, address(asset), 1e18, 0);
        vm.stopPrank();

        assertFalse(sy.isValidTokenIn(address(asset)), "The base asset must never be a valid token in");
        assertFalse(sy.isValidTokenIn(makeAddr("randomToken")), "A random token must never be a valid token in");
        assertEq(sy.getTokensIn().length, 1, "The tranche share must be the only token in");
        assertEq(sy.getTokensIn()[0], address(seniorTranche), "getTokensIn must list exactly the tranche share");

        vm.expectRevert(abi.encodeWithSelector(Errors.SYInvalidTokenIn.selector, address(asset)));
        sy.previewDeposit(address(asset), 1e18);
    }

    /// =====================================================================
    /// exchangeRate: RATE BOUNDARIES AND KERNEL RETURNDATA DECODE
    /// =====================================================================

    /// @notice The scaled NAV is a raw uint256 unwrapped verbatim: a rate of type(uint256).max must be returned
    ///         exactly, with no revert (the SY, unlike the Chainlink oracles, performs no int256 cast)
    function test_exchangeRate_maxUint256Nav_returnedVerbatim() public {
        // p = uint256.max: nav = p - 1, so the virtual-value add lands exactly on uint256.max and the
        // mulDiv(max, 1e18, 1e18) intermediate is 512-bit exact.
        (AssetClaims memory claims, uint256 supply) = _exactRateClaims(type(uint256).max);
        mockDayKernel.setPreview(claims, supply);
        assertEq(sy.exchangeRate(), type(uint256).max, "exchangeRate must pass the scaled uint256 NAV through verbatim at type(uint256).max");
    }

    /// @notice A rate of 2^255 (one above int256.max) must NOT revert: exchangeRate never casts to int256, in deliberate
    ///         contrast with RoycoTrancheChainlinkOracle which rejects the same NAV with ASSETS_MUST_BE_NON_NEGATIVE
    function test_exchangeRate_navAboveInt256Max_doesNotRevert() public {
        uint256 rate = uint256(1) << 255;
        (AssetClaims memory claims, uint256 supply) = _exactRateClaims(rate);
        mockDayKernel.setPreview(claims, supply);
        assertEq(sy.exchangeRate(), rate, "exchangeRate must not perform any signed cast on the scaled NAV");
    }

    /// @notice A previewed claims.nav of type(uint256).max overflows the checked virtual-value add, so the rate
    ///         reverts with an arithmetic panic rather than wrapping
    function test_exchangeRate_maxNavPlusVirtualValue_overflowReverts() public {
        AssetClaims memory claims;
        claims.nav = toNAVUnits(type(uint256).max);
        mockDayKernel.setPreview(claims, 1e18 - 1);
        vm.expectRevert(stdError.arithmeticError);
        sy.exchangeRate();
    }

    /// @notice DECODE PIN: empty preview returndata fails the typed (state, claims, supply) tuple decode, so
    ///         exchangeRate reverts (no raw-word fallback exists)
    function test_exchangeRate_emptyKernelReturndata_reverts() public {
        (RawReturnKernel rawKernel, PendleRoycoTrancheSY rawSy) = _deployRawKernelSY();
        rawKernel.setReturndata("");
        vm.expectRevert();
        rawSy.exchangeRate();
    }

    /// @notice DECODE PIN: preview returndata truncated anywhere short of the full head-encoded tuple fails the
    ///         typed decode, while the untruncated payload prices exactly (anti-vacuity)
    function test_exchangeRate_truncatedKernelReturndata_reverts() public {
        (RawReturnKernel rawKernel, PendleRoycoTrancheSY rawSy) = _deployRawKernelSY();
        (AssetClaims memory claims, uint256 supply) = _exactRateClaims(2e18);
        bytes memory honest = _encodeHonestPreview(claims, supply);

        // Anti-vacuity: the untruncated payload decodes to the exact rate.
        rawKernel.setReturndata(honest);
        assertEq(rawSy.exchangeRate(), 2e18, "The untruncated honest preview tuple must price exactly");

        // Drop the trailing supply word.
        rawKernel.setReturndata(_slice(honest, honest.length - 32));
        vm.expectRevert();
        rawSy.exchangeRate();

        // Truncate mid-struct to a single word.
        rawKernel.setReturndata(_slice(honest, 32));
        vm.expectRevert();
        rawSy.exchangeRate();
    }

    /// @notice A 16KB returndata bomb behind a well-formed preview tuple decodes cleanly: the ABI decoder ignores
    ///         trailing bytes, so the rate must equal the honest quote rather than revert or corrupt
    function test_exchangeRate_returndataBombAfterPreview_decodesCleanly() public {
        (RawReturnKernel rawKernel, PendleRoycoTrancheSY rawSy) = _deployRawKernelSY();
        (AssetClaims memory claims, uint256 supply) = _exactRateClaims(7e18);
        bytes memory garbage = new bytes(16_384);
        for (uint256 i = 0; i < garbage.length; ++i) {
            garbage[i] = 0xFF;
        }
        rawKernel.setReturndata(bytes.concat(_encodeHonestPreview(claims, supply), garbage));
        assertEq(rawSy.exchangeRate(), 7e18, "A well-formed preview tuple must decode cleanly regardless of trailing garbage");
    }

    /**
     * @notice Fuzz the honest preview tuple with garbage in every word the rate must ignore: the claims' non-NAV legs
     *         and the SyncedAccountingState fields over the full uint256 domain. With the supply pinned to 1e18 - 1
     *         the rate is exactly nav + 1 (the virtual-shares scaling at that supply) regardless of every other word
     * @param _collateralAssets The collateral-asset claim leg (ignored by exchangeRate)
     * @param _lptAssets The LPT-asset claim leg (ignored by exchangeRate)
     * @param _stShares The senior-share claim leg (ignored by exchangeRate)
     * @param _stateGarbage The value stuffed into the SyncedAccountingState's uint256/NAV fields (ignored)
     * @param _nav The NAV leg driving the rate
     */
    function testFuzz_exchangeRate_ignoresNonNavWords(
        uint256 _collateralAssets,
        uint256 _lptAssets,
        uint256 _stShares,
        uint256 _stateGarbage,
        uint256 _nav
    ) public {
        // nav + 1 (the virtual value) must not overflow.
        _nav = bound(_nav, 0, type(uint256).max - 1);

        (RawReturnKernel rawKernel, PendleRoycoTrancheSY rawSy) = _deployRawKernelSY();

        AssetClaims memory claims;
        claims.collateralAssets = toTrancheUnits(_collateralAssets);
        claims.lptAssets = toTrancheUnits(_lptAssets);
        claims.stShares = _stShares;
        claims.nav = toNAVUnits(_nav);

        SyncedAccountingState memory state;
        state.collateralNAV = toNAVUnits(_stateGarbage);
        state.lptRawNAV = toNAVUnits(_stateGarbage);
        state.stEffectiveNAV = toNAVUnits(_stateGarbage);
        state.jtEffectiveNAV = toNAVUnits(_stateGarbage);
        state.jtImpermanentLoss = toNAVUnits(_stateGarbage);
        state.lptLiquidityPremium = toNAVUnits(_stateGarbage);
        state.coverageUtilizationWAD = _stateGarbage;
        state.minLiquidityWAD = _stateGarbage;

        rawKernel.setReturndata(abi.encode(state, claims, uint256(1e18 - 1)));

        assertEq(rawSy.exchangeRate(), _nav + 1, "The rate must depend only on the previewed NAV leg and tranche supply");
    }

    /// =====================================================================
    /// REENTRANT TRANCHE: Pendle's nonReentrant GUARD
    /// =====================================================================

    /**
     * @notice PIN: SYBaseUpgV2.deposit is nonReentrant. A tranche share that reenters SY.deposit from inside its own
     *         transferFrom is stopped by the guard, the inner Error("ReentrancyGuard: reentrant call") bubbles through
     *         the token and reverts the ENTIRE outer deposit, and every ledger unwinds to its pre-attack state
     */
    function test_deposit_reentrantTranche_depositReentryBlockedByGuard() public {
        (MaliciousTranche malTranche, PendleRoycoTrancheSY malSy) = _deployMaliciousSetup();
        malTranche.setReentry(MaliciousTranche.ReentryMode.REENTER_DEPOSIT, false);

        malTranche.mint(alice, 10e18);
        vm.startPrank(alice);
        malTranche.approve(address(malSy), 10e18);

        vm.expectRevert(bytes("ReentrancyGuard: reentrant call"));
        malSy.deposit(alice, address(malTranche), 10e18, 0);
        vm.stopPrank();

        // Post-revert unwind audit: the guard's rejection must revert the whole flow, not just the inner call.
        assertEq(malTranche.balanceOf(alice), 10e18, "The depositor's tranche shares must be fully restored after the reentrancy revert");
        assertEq(malTranche.balanceOf(address(malSy)), 0, "The SY's mid-flight share pull must be unwound by the outer revert");
        assertEq(malSy.totalSupply(), 0, "No SY may be minted when the reentrant tranche bubbles the guard's revert");
    }

    /// @notice PIN: SYBaseUpgV2.redeem shares the same reentrancy status as deposit, so a tranche share reentering
    ///         SY.redeem from inside its transferFrom is rejected by the identical guard error
    function test_deposit_reentrantTranche_redeemReentryBlockedByGuard() public {
        (MaliciousTranche malTranche, PendleRoycoTrancheSY malSy) = _deployMaliciousSetup();
        malTranche.setReentry(MaliciousTranche.ReentryMode.REENTER_REDEEM, false);

        malTranche.mint(alice, 10e18);
        vm.startPrank(alice);
        malTranche.approve(address(malSy), 10e18);

        vm.expectRevert(bytes("ReentrancyGuard: reentrant call"));
        malSy.deposit(alice, address(malTranche), 10e18, 0);
        vm.stopPrank();

        assertEq(malSy.totalSupply(), 0, "A cross-function deposit->redeem reentry must revert the entire deposit");
    }

    /**
     * @notice Control-run vs hooked-run: a tranche that catches its own failed reentry cannot perturb settlement.
     *         The recorded inner revert must be byte-exact Error("ReentrancyGuard: reentrant call") — the guard's
     *         rejection, not an incidental failure — and the hooked wrap must settle wei-identical to the control
     */
    function test_deposit_reentrantTranche_caughtReentry_outerSettlesIdenticalToControl() public {
        (MaliciousTranche malTranche, PendleRoycoTrancheSY malSy) = _deployMaliciousSetup();

        // Control run: no reentry armed.
        uint256 controlShares = _wrapMaliciousShares(malTranche, malSy, alice, 5e18);
        assertEq(controlShares, 5e18, "The control wrap of 5e18 tranche shares at 1:1 must mint exactly 5e18 SY");

        // Hooked run: the tranche attempts the reentry, catches the guard's revert, and lets the wrap proceed.
        malTranche.setReentry(MaliciousTranche.ReentryMode.REENTER_DEPOSIT, true);
        uint256 hookedShares = _wrapMaliciousShares(malTranche, malSy, bob, 5e18);

        // Anti-vacuity + byte-exactness: the probe really ran and was rejected by the guard specifically.
        assertFalse(malTranche.reentrySucceeded(), "The armed reentry must never succeed against the nonReentrant guard");
        assertEq(
            malTranche.lastReentryRevertData(),
            abi.encodeWithSignature("Error(string)", "ReentrancyGuard: reentrant call"),
            "The recorded rejection must be the reentrancy guard's error, byte-exact, not an incidental failure"
        );

        // The attacked run must settle wei-identical to the control run.
        assertEq(hookedShares, controlShares, "A caught reentry attempt must not change the shares minted by one wei");
        assertEq(malSy.balanceOf(bob), controlShares, "The hooked depositor's SY balance must match the control depositor's");
        assertEq(malSy.totalSupply(), malTranche.balanceOf(address(malSy)), "The SY must remain exactly fully backed after the caught reentry");
    }

    /// =====================================================================
    /// FACTORY: SLOT KEYING, v4.9.3 PROXY ADMIN SEMANTICS, NAMING EDGES
    /// =====================================================================

    /**
     * @notice The registry is keyed by the (tranche, rewardManager) PAIR: the same tranche deploys independently under
     *         two reward managers, redeploying an occupied pair reverts SY_ALREADY_DEPLOYED, and the failed redeploy
     *         corrupts neither the occupied slot nor the adjacent one
     */
    function test_deploySY_sameTrancheDifferentRewardManagers_independentSlots() public {
        address rm2 = makeAddr("rewardManager2");

        // setUp already occupied (seniorTranche, rewardManager); the same tranche under rm2 must deploy fresh.
        address sy2 = syFactory.deploySY(address(seniorTranche), rm2);
        assertTrue(sy2 != address(sy), "The same tranche under a different reward manager must yield a distinct SY");
        assertEq(syFactory.trancheToOffchainRewardManagerToSY(address(seniorTranche), rm2), sy2, "The second pair's slot must record its own SY");

        // Both occupied pairs must now reject redeployment.
        vm.expectRevert(PendleRoycoTrancheSYFactory.SY_ALREADY_DEPLOYED.selector);
        syFactory.deploySY(address(seniorTranche), rewardManager);
        vm.expectRevert(PendleRoycoTrancheSYFactory.SY_ALREADY_DEPLOYED.selector);
        syFactory.deploySY(address(seniorTranche), rm2);

        // Neither failed redeploy may corrupt either slot.
        assertEq(syFactory.trancheToOffchainRewardManagerToSY(address(seniorTranche), rewardManager), address(sy), "The first slot must survive both failed redeploys");
        assertEq(syFactory.trancheToOffchainRewardManagerToSY(address(seniorTranche), rm2), sy2, "The second slot must survive both failed redeploys");
        assertEq(PendleRoycoTrancheSY(payable(sy2)).offchainRewardManager(), rm2, "The second SY's baked reward manager must be the second pair's key");
    }

    /**
     * @notice OZ v4.9.3 TransparentUpgradeableProxy sets the constructor's admin_ argument DIRECTLY into the EIP-1967
     *         admin slot via _changeAdmin (no ProxyAdmin is auto-deployed — that is v5 behavior), so the slot must hold
     *         PENDLE_PROXY_ADMIN itself, and the proxy must emit Upgraded(implementation) then AdminChanged(0, admin)
     */
    function test_deploySY_proxyAdmin_v493SetsPendleAdminDirectly_eventExact() public {
        MockTranche freshTranche = new MockTranche(address(asset), trancheAuthority, TrancheType.JUNIOR);
        freshTranche.setKernel(address(mockDayKernel));
        mockRoycoFactory.registerTranche(address(freshTranche), kernel);
        vm.recordLogs();
        address freshSy = syFactory.deploySY(address(freshTranche), rewardManager);
        Vm.Log[] memory logs = vm.getRecordedLogs();

        // The admin slot holds Pendle's proxy admin address verbatim: v4.9.3 deploys no intermediary ProxyAdmin.
        bytes32 storedAdmin = vm.load(freshSy, ADMIN_SLOT);
        assertEq(address(uint160(uint256(storedAdmin))), PENDLE_PROXY_ADMIN, "The EIP-1967 admin slot must hold PENDLE_PROXY_ADMIN directly");
        assertEq(PENDLE_PROXY_ADMIN.code.length, 0, "v4.9.3 must NOT deploy a ProxyAdmin contract at the admin address (that is v5 behavior)");

        // Pull the implementation from the factory's SYDeployed topics for the Upgraded cross-check.
        address implementation;
        bool foundUpgraded;
        bool foundAdminChanged;
        for (uint256 i = 0; i < logs.length; ++i) {
            if (logs[i].emitter == address(syFactory) && logs[i].topics[0] == keccak256("SYDeployed(address,address,address)")) {
                implementation = address(uint160(uint256(logs[i].topics[3])));
            }
        }
        assertTrue(implementation != address(0), "The SYDeployed event must carry the implementation address");

        // ERC1967 event exactness, emitted by the proxy itself during construction.
        for (uint256 i = 0; i < logs.length; ++i) {
            if (logs[i].emitter != freshSy) continue;
            if (logs[i].topics[0] == keccak256("Upgraded(address)")) {
                assertEq(address(uint160(uint256(logs[i].topics[1]))), implementation, "Upgraded must carry the exact implementation as its indexed topic");
                foundUpgraded = true;
            } else if (logs[i].topics[0] == keccak256("AdminChanged(address,address)")) {
                assertEq(logs[i].topics.length, 1, "AdminChanged carries no indexed topics under ERC1967");
                assertEq(logs[i].data, abi.encode(address(0), PENDLE_PROXY_ADMIN), "AdminChanged must record the zero-to-Pendle admin transition byte-exactly");
                foundAdminChanged = true;
            }
        }
        assertTrue(foundUpgraded, "The proxy must emit Upgraded during construction");
        assertTrue(foundAdminChanged, "The proxy must emit AdminChanged during construction");
    }

    /**
     * @notice v4.9.3 transparency pin: the admin's calls are dispatched by the proxy and NEVER forwarded — an admin
     *         call to an SY function reverts with the canonical transparency error, while the ITransparentUpgradeableProxy
     *         admin()/implementation() dispatch answers the admin correctly
     */
    function test_proxy_adminCannotFallbackToImplementation() public {
        // Any non-admin caller reaches the implementation normally.
        assertEq(sy.name(), string.concat("SY ", seniorTranche.name()));

        // The admin is walled off from the implementation entirely.
        vm.prank(PENDLE_PROXY_ADMIN);
        vm.expectRevert(bytes("TransparentUpgradeableProxy: admin cannot fallback to proxy target"));
        sy.name();

        // The admin's dedicated dispatch surface answers with the wired admin.
        vm.prank(PENDLE_PROXY_ADMIN);
        address reportedAdmin = ITransparentUpgradeableProxy(address(sy)).admin();
        assertEq(reportedAdmin, PENDLE_PROXY_ADMIN, "The proxy's admin dispatch must report PENDLE_PROXY_ADMIN");
    }

    /// @notice A tranche with empty name and symbol composes to the bare "SY " / "SY-" prefixes — the factory applies
    ///         no validation or padding to tranche metadata
    function test_deploySY_emptyTrancheMetadata_composesBarePrefixes() public {
        MockTranche bare = new MockTranche(address(asset), trancheAuthority, TrancheType.SENIOR);
        bare.setKernel(address(mockDayKernel));
        mockRoycoFactory.registerTranche(address(bare), kernel);
        vm.mockCall(address(bare), abi.encodeWithSignature("name()"), abi.encode(""));
        vm.mockCall(address(bare), abi.encodeWithSignature("symbol()"), abi.encode(""));

        PendleRoycoTrancheSY bareSy = PendleRoycoTrancheSY(payable(syFactory.deploySY(address(bare), rewardManager)));

        assertEq(bareSy.name(), "SY ", "An empty tranche name must compose to the bare 'SY ' prefix");
        assertEq(bareSy.symbol(), "SY-", "An empty tranche symbol must compose to the bare 'SY-' prefix");
    }

    /// @notice A 100-character tranche name/symbol composes to an exact 103-character concatenation with no truncation
    function test_deploySY_hundredCharTrancheMetadata_composesExactly() public {
        bytes memory nameBytes = new bytes(100);
        for (uint256 i = 0; i < 100; ++i) {
            nameBytes[i] = bytes1(uint8(0x41 + (i % 26))); // A-Z repeating
        }
        string memory longString = string(nameBytes);

        MockTranche verbose = new MockTranche(address(asset), trancheAuthority, TrancheType.SENIOR);
        verbose.setKernel(address(mockDayKernel));
        mockRoycoFactory.registerTranche(address(verbose), kernel);
        vm.mockCall(address(verbose), abi.encodeWithSignature("name()"), abi.encode(longString));
        vm.mockCall(address(verbose), abi.encodeWithSignature("symbol()"), abi.encode(longString));

        PendleRoycoTrancheSY verboseSy = PendleRoycoTrancheSY(payable(syFactory.deploySY(address(verbose), rewardManager)));

        assertEq(verboseSy.name(), string.concat("SY ", longString), "A 100-char tranche name must compose without truncation");
        assertEq(verboseSy.symbol(), string.concat("SY-", longString), "A 100-char tranche symbol must compose without truncation");
        assertEq(bytes(verboseSy.name()).length, 103, "The composed name must be exactly 3 prefix chars plus 100 tranche chars");
    }

    /// =====================================================================
    /// WRAP / UNWRAP: 1:1 EXACTNESS FUZZ
    /// =====================================================================

    /**
     * @notice PROPERTY: wrapping tranche shares and unwrapping them round-trips EXACTLY for any share amount in
     *         [1, uint248.max] (the SY's supply is a uint248) and any share price over the full uint256 domain —
     *         the wrap is a pure 1:1 pass-through with zero spread, so minSharesOut/minTokenOut can be set exactly
     * @param _shares The tranche share amount to round-trip, bounded only by the SY's uint248 supply accumulator
     * @param _sharePriceWAD The tranche share price over the full uint256 domain (must be irrelevant to the wrap)
     */
    function testFuzz_wrapUnwrap_fullRoundTripExactAtAnyPriceAndAmount(uint256 _shares, uint256 _sharePriceWAD) public {
        _shares = bound(_shares, 1, type(uint248).max);
        seniorTranche.setSharePrice(_sharePriceWAD);

        // Grant alice the tranche shares directly: acquisition math is out of scope for the wrap property.
        deal(address(seniorTranche), alice, _shares, true);

        vm.startPrank(alice);
        seniorTranche.approve(address(sy), _shares);
        // minSharesOut == _shares: the exact boundary must pass for every amount and price.
        uint256 syShares = sy.deposit(alice, address(seniorTranche), _shares, _shares);
        assertEq(syShares, _shares, "The wrap must mint exactly one SY wei per tranche share wei at any price");
        assertEq(seniorTranche.balanceOf(address(sy)), _shares, "The SY must custody exactly the wrapped tranche shares");

        // minTokenOut == _shares: the exact boundary must pass on the way out too.
        uint256 sharesBack = sy.redeem(alice, syShares, address(seniorTranche), _shares, false);
        vm.stopPrank();

        assertEq(sharesBack, _shares, "The unwrap must return exactly one tranche share wei per SY wei at any price");
        assertEq(seniorTranche.balanceOf(alice), _shares, "The round trip must restore the depositor's tranche shares to the wei");
        assertEq(sy.totalSupply(), 0, "The SY supply must return to zero after a full round trip");
        assertEq(seniorTranche.balanceOf(address(sy)), 0, "The SY must hold no residual tranche shares after a full round trip");
    }

    /**
     * @notice PROPERTY: after wrapping _shares and unwrapping an arbitrary portion, every wei is conserved across the
     *         two ledgers — alice's tranche shares plus the SY's custody always sum to _shares, and the SY supply
     *         always equals its custody exactly
     * @param _shares The tranche share amount to wrap
     * @param _redeemShares The portion of the wrapped shares to unwrap
     */
    function testFuzz_wrapUnwrap_partialRedeemConservesEveryWei(uint256 _shares, uint256 _redeemShares) public {
        _shares = bound(_shares, 1, type(uint248).max);
        _redeemShares = bound(_redeemShares, 1, _shares);

        deal(address(seniorTranche), alice, _shares, true);

        vm.startPrank(alice);
        seniorTranche.approve(address(sy), _shares);
        sy.deposit(alice, address(seniorTranche), _shares, _shares);
        sy.redeem(alice, _redeemShares, address(seniorTranche), _redeemShares, false);
        vm.stopPrank();

        assertEq(sy.balanceOf(alice), _shares - _redeemShares, "The remaining SY balance must be exactly the unredeemed portion");
        assertEq(seniorTranche.balanceOf(alice), _redeemShares, "The redeemed tranche shares must equal the redeemed SY exactly");
        assertEq(
            seniorTranche.balanceOf(alice) + seniorTranche.balanceOf(address(sy)),
            _shares,
            "Every tranche share wei must be conserved between the depositor and the SY"
        );
        assertEq(sy.totalSupply(), seniorTranche.balanceOf(address(sy)), "The SY supply must equal its tranche share custody after any partial redeem");
    }
}
