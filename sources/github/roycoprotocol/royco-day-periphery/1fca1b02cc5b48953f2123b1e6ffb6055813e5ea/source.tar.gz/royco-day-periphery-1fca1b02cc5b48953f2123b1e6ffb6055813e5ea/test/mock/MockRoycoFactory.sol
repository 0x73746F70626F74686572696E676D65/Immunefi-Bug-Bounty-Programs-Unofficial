// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

/// @title MockRoycoFactory
/// @notice A minimal mock of the Royco factory's tranche registry for testing the periphery's provenance checks
contract MockRoycoFactory {
    /// @notice The kernel each registered tranche resolves to (the null address for an unregistered tranche)
    mapping(address tranche => address kernel) public trancheToKernel;

    /// @dev The market authority this mock answers, mirroring the factory's access manager wiring
    address internal roycoAuthority;

    /// @notice Registers a tranche against a kernel, mirroring the factory's market-deployment registration
    function registerTranche(address _tranche, address _kernel) external {
        trancheToKernel[_tranche] = _kernel;
    }

    /// @notice Sets the market authority this mock answers
    function setRoycoAuthority(address _roycoAuthority) external {
        roycoAuthority = _roycoAuthority;
    }

    /// @notice Returns the market authority, mirroring the factory's ROYCO_AUTHORITY
    function ROYCO_AUTHORITY() external view returns (address) {
        return roycoAuthority;
    }
}
