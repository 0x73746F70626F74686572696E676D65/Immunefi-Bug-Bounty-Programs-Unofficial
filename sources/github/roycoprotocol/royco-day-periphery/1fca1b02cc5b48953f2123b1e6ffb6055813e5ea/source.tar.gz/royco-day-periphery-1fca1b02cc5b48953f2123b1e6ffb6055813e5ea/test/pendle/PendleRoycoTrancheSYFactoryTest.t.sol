// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { Test } from "../../lib/forge-std/src/Test.sol";
import { Vm } from "../../lib/forge-std/src/Vm.sol";

import { ERC20Mock } from "../../lib/openzeppelin-contracts/contracts/mocks/token/ERC20Mock.sol";

import { IRoycoAuth } from "../../lib/royco-day/src/interfaces/IRoycoAuth.sol";
import { RoycoTrancheValidator } from "../../src/base/RoycoTrancheValidator.sol";
import { IRoycoFactory } from "../../lib/royco-day/src/interfaces/factory/IRoycoFactory.sol";
import { TrancheType } from "../../lib/royco-day/src/libraries/Types.sol";
import { PendleRoycoTrancheSY } from "../../src/pendle/PendleRoycoTrancheSY.sol";
import { PendleRoycoTrancheSYFactory } from "../../src/pendle/PendleRoycoTrancheSYFactory.sol";

import { MockDayKernel } from "../mock/MockDayKernel.sol";
import { MockRoycoFactory } from "../mock/MockRoycoFactory.sol";
import { MockTranche } from "../mock/MockTranche.sol";

/// @title PendleRoycoTrancheSYFactoryTest
/// @notice Audit-grade unit tests for PendleRoycoTrancheSYFactory backed by MockRoycoFactory + MockTranche
/// @dev The factory is permissionless but verifies tranche provenance against the Royco factory's tranche registry:
///      deploySY only proceeds for ostensible tranches the registry maps to a kernel, reverting NOT_A_ROYCO_TRANCHE
///      for everything else (including the null address, which is never registered)
contract PendleRoycoTrancheSYFactoryTest is Test {
    /// =====================================================================
    /// CONSTANTS (mirrored from spec)
    /// =====================================================================
    address internal constant PENDLE_PROXY_ADMIN = 0xA28c08f165116587D4F3E708743B4dEe155c5E64;
    address internal constant PENDLE_PAUSE_CONTROLLER = 0x2aD631F72fB16d91c4953A7f4260A97C2fE2f31e;
    /// @dev EIP-1967 admin storage slot: bytes32(uint256(keccak256("eip1967.proxy.admin")) - 1)
    bytes32 internal constant ADMIN_SLOT = 0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103;

    /// =====================================================================
    /// STATE
    /// =====================================================================
    ERC20Mock internal asset;
    MockRoycoFactory internal mockRoycoFactory;
    MockDayKernel internal mockDayKernel;
    MockTranche internal seniorTranche;
    MockTranche internal juniorTranche;
    PendleRoycoTrancheSYFactory internal syFactory;

    address internal kernel = makeAddr("kernel");
    address internal trancheAuthority = makeAddr("trancheAuthority");
    address internal rewardManager = makeAddr("rewardManager");

    /// @dev Mirrored from PendleRoycoTrancheSYFactory for vm.expectEmit
    event SYDeployed(address indexed tranche, address indexed sy, address indexed implementation);

    /// =====================================================================
    /// SETUP
    /// =====================================================================

    function setUp() public {
        asset = new ERC20Mock();
        mockRoycoFactory = new MockRoycoFactory();
        mockDayKernel = new MockDayKernel();

        // The SY caches the tranche's kernel at construction, so the kernel must be wired before any SY deploys.
        seniorTranche = new MockTranche(address(asset), trancheAuthority, TrancheType.SENIOR);
        juniorTranche = new MockTranche(address(asset), trancheAuthority, TrancheType.JUNIOR);
        seniorTranche.setKernel(address(mockDayKernel));
        juniorTranche.setKernel(address(mockDayKernel));
        mockRoycoFactory.registerTranche(address(seniorTranche), kernel);
        mockRoycoFactory.registerTranche(address(juniorTranche), kernel);

        syFactory = new PendleRoycoTrancheSYFactory(IRoycoFactory(address(mockRoycoFactory)));
    }

    /// =====================================================================
    /// CONSTRUCTOR + CONSTANTS
    /// =====================================================================

    function test_constants_matchPendleSpec() public view {
        assertEq(syFactory.PENDLE_PROXY_ADMIN(), PENDLE_PROXY_ADMIN);
        assertEq(syFactory.PENDLE_PAUSE_CONTROLLER(), PENDLE_PAUSE_CONTROLLER);
    }

    function test_constructor_setsRoycoFactory() public view {
        assertEq(address(syFactory.ROYCO_FACTORY()), address(mockRoycoFactory));
    }

    function test_constructor_revertsOnNullRoycoFactory() public {
        vm.expectRevert(IRoycoAuth.NULL_ADDRESS.selector);
        new PendleRoycoTrancheSYFactory(IRoycoFactory(address(0)));
    }

    /// =====================================================================
    /// deploySY - happy path
    /// =====================================================================

    function test_deploySY_seniorTranche() public {
        address sy = syFactory.deploySY(address(seniorTranche), rewardManager);

        assertGt(sy.code.length, 0);
        assertEq(syFactory.trancheToOffchainRewardManagerToSY(address(seniorTranche), rewardManager), sy);
    }

    function test_deploySY_juniorTranche() public {
        address sy = syFactory.deploySY(address(juniorTranche), rewardManager);

        assertGt(sy.code.length, 0);
        assertEq(syFactory.trancheToOffchainRewardManagerToSY(address(juniorTranche), rewardManager), sy);
    }

    function test_deploySY_eventEmittedWithCorrectTopics() public {
        vm.recordLogs();
        address sy = syFactory.deploySY(address(seniorTranche), rewardManager);
        Vm.Log[] memory logs = vm.getRecordedLogs();

        bytes32 expectedTopic0 = keccak256("SYDeployed(address,address,address)");
        bool found;
        for (uint256 i = 0; i < logs.length; ++i) {
            if (logs[i].emitter != address(syFactory)) continue;
            if (logs[i].topics.length != 4 || logs[i].topics[0] != expectedTopic0) continue;
            assertEq(address(uint160(uint256(logs[i].topics[1]))), address(seniorTranche));
            assertEq(address(uint160(uint256(logs[i].topics[2]))), sy);
            assertGt(uint256(logs[i].topics[3]), 0); // implementation address non-zero
            found = true;
            break;
        }
        assertTrue(found, "SYDeployed log not found");
    }

    function test_deploySY_zeroRewardManagerAllowed() public {
        // Spec allows null reward manager when no offchain rewards exist for this SY.
        address sy = syFactory.deploySY(address(seniorTranche), address(0));
        assertEq(PendleRoycoTrancheSY(payable(sy)).offchainRewardManager(), address(0));
    }

    function test_deploySY_setsMappingsIndependentlyForBothTranches() public {
        address stSY = syFactory.deploySY(address(seniorTranche), rewardManager);
        address jtSY = syFactory.deploySY(address(juniorTranche), rewardManager);

        assertEq(syFactory.trancheToOffchainRewardManagerToSY(address(seniorTranche), rewardManager), stSY);
        assertEq(syFactory.trancheToOffchainRewardManagerToSY(address(juniorTranche), rewardManager), jtSY);
        assertTrue(stSY != jtSY);
    }

    /// =====================================================================
    /// deploySY - SY initialization correctness
    /// =====================================================================

    function test_deploySY_namingConventionFollowsPendleSpec() public {
        // Spec: SY name = "SY " + name(); SY symbol = "SY-" + symbol().
        address stSY = syFactory.deploySY(address(seniorTranche), rewardManager);
        assertEq(PendleRoycoTrancheSY(payable(stSY)).name(), string.concat("SY ", seniorTranche.name()));
        assertEq(PendleRoycoTrancheSY(payable(stSY)).symbol(), string.concat("SY-", seniorTranche.symbol()));

        address jtSY = syFactory.deploySY(address(juniorTranche), rewardManager);
        assertEq(PendleRoycoTrancheSY(payable(jtSY)).name(), string.concat("SY ", juniorTranche.name()));
        assertEq(PendleRoycoTrancheSY(payable(jtSY)).symbol(), string.concat("SY-", juniorTranche.symbol()));
    }

    function test_deploySY_ownerIsPendlePauseController() public {
        // Spec: ownership must be set to Pendle's pause controller (BoringOwnable single-owner).
        address sy = syFactory.deploySY(address(seniorTranche), rewardManager);
        assertEq(PendleRoycoTrancheSY(payable(sy)).owner(), PENDLE_PAUSE_CONTROLLER);
    }

    function test_deploySY_factoryDoesNotRetainOwnership() public {
        address sy = syFactory.deploySY(address(seniorTranche), rewardManager);
        assertTrue(PendleRoycoTrancheSY(payable(sy)).owner() != address(syFactory));
    }

    function test_deploySY_proxyAdminIsPendleProxyAdmin() public {
        // Spec: proxy admin must be Pendle's ProxyAdmin set DIRECTLY as admin (no new ProxyAdmin deployed).
        address sy = syFactory.deploySY(address(seniorTranche), rewardManager);
        bytes32 storedAdmin = vm.load(sy, ADMIN_SLOT);
        assertEq(address(uint160(uint256(storedAdmin))), PENDLE_PROXY_ADMIN);
    }

    function test_deploySY_yieldTokenIsTranche() public {
        address sy = syFactory.deploySY(address(seniorTranche), rewardManager);
        assertEq(PendleRoycoTrancheSY(payable(sy)).yieldToken(), address(seniorTranche));
    }

    function test_deploySY_offchainRewardManagerIsBakedIntoImpl() public {
        address sy = syFactory.deploySY(address(seniorTranche), rewardManager);
        assertEq(PendleRoycoTrancheSY(payable(sy)).offchainRewardManager(), rewardManager);
    }

    function test_deploySY_decimalsMatchTranche() public {
        address sy = syFactory.deploySY(address(seniorTranche), rewardManager);
        assertEq(PendleRoycoTrancheSY(payable(sy)).decimals(), seniorTranche.decimals());
    }

    function test_deploySY_implementationDiffersFromProxy() public {
        vm.recordLogs();
        address sy = syFactory.deploySY(address(seniorTranche), rewardManager);
        Vm.Log[] memory logs = vm.getRecordedLogs();

        // Pull implementation from the SYDeployed event's third indexed topic.
        bytes32 expectedTopic0 = keccak256("SYDeployed(address,address,address)");
        address implementation;
        for (uint256 i = 0; i < logs.length; ++i) {
            if (logs[i].emitter != address(syFactory)) continue;
            if (logs[i].topics.length != 4 || logs[i].topics[0] != expectedTopic0) continue;
            implementation = address(uint160(uint256(logs[i].topics[3])));
            break;
        }
        assertTrue(implementation != address(0));
        assertTrue(implementation != sy);
        assertGt(implementation.code.length, 0);
    }

    function test_deploySY_yieldTokenIsOnlyValidTokenInAndOut() public {
        // The SY is a pure 1:1 wrapper: the tranche share is the only token in and out (the base asset deposit
        // path is gone), and initialization wires no base asset approval to the tranche.
        PendleRoycoTrancheSY sy = PendleRoycoTrancheSY(payable(syFactory.deploySY(address(seniorTranche), rewardManager)));

        address[] memory tokensIn = sy.getTokensIn();
        assertEq(tokensIn.length, 1);
        assertEq(tokensIn[0], address(seniorTranche));
        address[] memory tokensOut = sy.getTokensOut();
        assertEq(tokensOut.length, 1);
        assertEq(tokensOut[0], address(seniorTranche));

        assertTrue(sy.isValidTokenIn(address(seniorTranche)));
        assertFalse(sy.isValidTokenIn(address(asset)));
        assertTrue(sy.isValidTokenOut(address(seniorTranche)));
        assertFalse(sy.isValidTokenOut(address(asset)));

        assertEq(asset.allowance(address(sy), address(seniorTranche)), 0);
    }

    /// =====================================================================
    /// deploySY - provenance verification
    /// =====================================================================
    /// @dev Every ostensible tranche is checked against the Royco factory's tranche registry: only addresses the
    ///      registry maps to a kernel deploy, everything else reverts NOT_A_ROYCO_TRANCHE with the offender embedded

    function test_deploySY_revertsOnUnregisteredTranche() public {
        // A structurally valid tranche the Royco factory never deployed must be rejected.
        MockTranche unregistered = new MockTranche(address(asset), trancheAuthority, TrancheType.SENIOR);

        vm.expectRevert(abi.encodeWithSelector(RoycoTrancheValidator.NOT_A_ROYCO_TRANCHE.selector, address(unregistered)));
        syFactory.deploySY(address(unregistered), rewardManager);
    }

    function test_deploySY_succeedsForAnyRegisteredTranche() public {
        // Any tranche the registry maps to a kernel deploys, no matter which kernel or who registered it.
        MockTranche fresh = new MockTranche(address(asset), trancheAuthority, TrancheType.SENIOR);
        fresh.setKernel(address(mockDayKernel));
        mockRoycoFactory.registerTranche(address(fresh), makeAddr("otherKernel"));

        address sy = syFactory.deploySY(address(fresh), rewardManager);

        assertEq(syFactory.trancheToOffchainRewardManagerToSY(address(fresh), rewardManager), sy);
        assertEq(PendleRoycoTrancheSY(payable(sy)).yieldToken(), address(fresh));
    }

    /// =====================================================================
    /// deploySY - revert paths
    /// =====================================================================

    function test_deploySY_revertsOnNullTranche() public {
        // The null address is rejected before the registry is ever consulted
        vm.expectRevert(IRoycoAuth.NULL_ADDRESS.selector);
        syFactory.deploySY(address(0), rewardManager);
    }

    function test_deploySY_revertsOnEOATranche() public {
        // Unregistered EOA: rejected by the provenance check before any code is touched.
        address eoa = makeAddr("eoa");
        vm.expectRevert(abi.encodeWithSelector(RoycoTrancheValidator.NOT_A_ROYCO_TRANCHE.selector, eoa));
        syFactory.deploySY(eoa, rewardManager);

        // Registered EOA: no code, so the SY constructor's high-level decimals() call on the tranche fails the
        // code-existence check.
        mockRoycoFactory.registerTranche(eoa, kernel);
        vm.expectRevert();
        syFactory.deploySY(eoa, rewardManager);
    }

    function test_deploySY_revertsOnDuplicateDeployment() public {
        // Same (tranche, rewardManager) pair must collide.
        syFactory.deploySY(address(seniorTranche), rewardManager);
        vm.expectRevert(PendleRoycoTrancheSYFactory.SY_ALREADY_DEPLOYED.selector);
        syFactory.deploySY(address(seniorTranche), rewardManager);
    }

    function test_deploySY_failedRedeployDoesNotCorruptMapping() public {
        // Re-deploying with the same (tranche, rewardManager) pair reverts and leaves the slot intact.
        address firstSY = syFactory.deploySY(address(seniorTranche), rewardManager);

        vm.expectRevert(PendleRoycoTrancheSYFactory.SY_ALREADY_DEPLOYED.selector);
        syFactory.deploySY(address(seniorTranche), rewardManager);

        assertEq(syFactory.trancheToOffchainRewardManagerToSY(address(seniorTranche), rewardManager), firstSY);
        assertEq(PendleRoycoTrancheSY(payable(firstSY)).offchainRewardManager(), rewardManager);
    }

    /// =====================================================================
    /// PERMISSIONLESS / FRONT-RUN NEUTRALIZATION (C-1 fix)
    /// =====================================================================

    function test_deploySY_permissionless_anyCallerCanDeploy() public {
        // deploySY is intentionally permissionless: any address can deploy.
        vm.prank(makeAddr("randomCaller"));
        address sy = syFactory.deploySY(address(seniorTranche), rewardManager);
        assertEq(syFactory.trancheToOffchainRewardManagerToSY(address(seniorTranche), rewardManager), sy);
    }

    function test_deploySY_frontRunDoesNotLockOutLegitimateDeployer() public {
        // C-1 fix: keying trancheToSY by (tranche, rewardManager) means a malicious front-run
        // only occupies the attacker's own slot. The legitimate (tranche, rewardManager) pair
        // remains free, and the legitimate SY is the one Pendle will list.
        address attacker = makeAddr("attacker");
        vm.prank(attacker);
        address attackerSY = syFactory.deploySY(address(seniorTranche), attacker);

        // Legitimate deployer can still deploy with their own reward manager.
        address legitSY = syFactory.deploySY(address(seniorTranche), rewardManager);

        assertTrue(legitSY != attackerSY);
        assertEq(syFactory.trancheToOffchainRewardManagerToSY(address(seniorTranche), attacker), attackerSY);
        assertEq(syFactory.trancheToOffchainRewardManagerToSY(address(seniorTranche), rewardManager), legitSY);
        assertEq(PendleRoycoTrancheSY(payable(legitSY)).offchainRewardManager(), rewardManager);
        assertEq(PendleRoycoTrancheSY(payable(attackerSY)).offchainRewardManager(), attacker);
    }

    /// =====================================================================
    /// FUZZ
    /// =====================================================================

    function testFuzz_deploySY_callerIndependence(address _caller) public {
        vm.assume(_caller != address(0));
        vm.prank(_caller);
        address sy = syFactory.deploySY(address(seniorTranche), rewardManager);

        assertEq(syFactory.trancheToOffchainRewardManagerToSY(address(seniorTranche), rewardManager), sy);
        assertEq(PendleRoycoTrancheSY(payable(sy)).owner(), PENDLE_PAUSE_CONTROLLER);
        assertEq(PendleRoycoTrancheSY(payable(sy)).yieldToken(), address(seniorTranche));
    }

    function testFuzz_deploySY_rewardManagerPassThrough(address _rewardManager) public {
        address sy = syFactory.deploySY(address(seniorTranche), _rewardManager);
        assertEq(PendleRoycoTrancheSY(payable(sy)).offchainRewardManager(), _rewardManager);
    }
}
