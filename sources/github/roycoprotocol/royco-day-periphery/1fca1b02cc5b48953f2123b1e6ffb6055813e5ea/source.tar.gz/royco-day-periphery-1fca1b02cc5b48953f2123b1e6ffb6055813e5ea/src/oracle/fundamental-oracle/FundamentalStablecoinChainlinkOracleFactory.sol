// SPDX-License-Identifier: LicenseRef-PolyForm-Perimeter-1.0.1
pragma solidity ^0.8.28;

import { Create2 } from "../../../lib/openzeppelin-contracts/contracts/utils/Create2.sol";
import { FundamentalStablecoinChainlinkOracle } from "./FundamentalStablecoinChainlinkOracle.sol";

/**
 * @title FundamentalStablecoinChainlinkOracleFactory
 * @author Shivaansh Kapoor, Ankur Dubey
 * @notice Permissionless factory that deploys fundamental peg oracles wrapping stablecoin Chainlink (compatible) oracles
 * @dev The underlying oracle and peg price are validated by the peg oracle's own construction, which probes the
 *      underlying oracle's decimals and bounds the minimum peg price against its precision
 */
contract FundamentalStablecoinChainlinkOracleFactory {
    /// @dev The global deployment salt used for all oracles
    bytes32 private constant ORACLE_DEPLOYMENT_SALT = keccak256(abi.encode("ROYCO_FUNDAMENTAL_STABLECOIN_CHAINLINK_ORACLE"));

    /// @notice The deployed peg oracle for each (underlying oracle, minimum peg price) pair
    mapping(address oracle => mapping(int256 minPriceAtPeg => address pegOracle)) public oracleToMinPriceAtPegToPegOracle;

    /// @notice Emitted when a peg oracle is deployed for an underlying oracle
    event OracleDeployed(address indexed oracle, int256 minPriceAtPeg, address indexed pegOracle);

    /**
     * @notice Deploys a fundamental peg oracle wrapping the specified underlying oracle
     * @param _oracle The underlying stablecoin Chainlink (compatible) oracle to wrap
     * @param _minPriceAtPeg The minimum price at which the underlying stablecoin is considered pegged to 1 quote asset, denominated in the underlying oracle's precision
     * @return pegOracle The deployed peg oracle's address
     */
    function deployOracle(address _oracle, int256 _minPriceAtPeg) external returns (address pegOracle) {
        // Deploy the peg oracle for this underlying oracle and peg price
        oracleToMinPriceAtPegToPegOracle[_oracle][_minPriceAtPeg] = pegOracle = address(
            new FundamentalStablecoinChainlinkOracle{ salt: ORACLE_DEPLOYMENT_SALT }(_oracle, _minPriceAtPeg)
        );
        emit OracleDeployed(_oracle, _minPriceAtPeg, pegOracle);
    }

    /// @notice Predicts the peg oracle address that would be deployed for the specified underlying oracle and minimum peg price
    function predictOracleAddress(address _oracle, int256 _minPriceAtPeg) external view returns (address) {
        return Create2.computeAddress(
            ORACLE_DEPLOYMENT_SALT, keccak256(abi.encodePacked(type(FundamentalStablecoinChainlinkOracle).creationCode, abi.encode(_oracle, _minPriceAtPeg)))
        );
    }
}
