// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.28;

import { TransparentUpgradeableProxy } from "../../lib/openzeppelin-contracts-v4/contracts/proxy/transparent/TransparentUpgradeableProxy.sol";
import { IRoycoVaultTranche } from "../../lib/royco-day/src/interfaces/IRoycoVaultTranche.sol";
import { IRoycoFactory } from "../../lib/royco-day/src/interfaces/factory/IRoycoFactory.sol";
import { RoycoTrancheValidator } from "../base/RoycoTrancheValidator.sol";
import { PendleERC20SYUpgV2, PendleRoycoTrancheSY } from "./PendleRoycoTrancheSY.sol";

/**
 * @title PendleRoycoTrancheSYFactory
 * @author Shivaansh Kapoor, Ankur Dubey
 * @notice Permissionless factory that deploys upgradeable Pendle SYs for Royco tranche shares
 * @dev Each SY is deployed behind an OZ v4.9.3 TransparentUpgradeableProxy administered by Pendle's ProxyAdmin,
 *      Ownership transferred to Pendle's pause controller to be compliant with Pendle's deployment requirements.
 * @dev Every ostensible tranche is verified against the Royco factory's tranche registry before an SY is deployed for it
 */
contract PendleRoycoTrancheSYFactory is RoycoTrancheValidator {
    /// @notice Pendle's canonical proxy admin
    address public constant PENDLE_PROXY_ADMIN = 0xA28c08f165116587D4F3E708743B4dEe155c5E64;

    /// @notice Pendle's pause controller and SY owner
    address public constant PENDLE_PAUSE_CONTROLLER = 0x2aD631F72fB16d91c4953A7f4260A97C2fE2f31e;

    /// @notice The deployed Pendle SY for each (Royco tranche, offchain reward manager) pair
    mapping(address tranche => mapping(address offchainRewardManager => address sy)) public trancheToOffchainRewardManagerToSY;

    /**
     * @notice Emitted when a Pendle SY is deployed for a tranche
     * @param tranche The Royco tranche the SY was deployed for
     * @param sy The deployed SY proxy
     * @param implementation The SY implementation behind the proxy
     */
    event SYDeployed(address indexed tranche, address indexed sy, address indexed implementation);

    /// @dev Thrown when an SY has already been deployed for the specified tranche
    error SY_ALREADY_DEPLOYED();

    /// @param _roycoFactory The Royco factory whose tranche registry every ostensible tranche is verified against
    constructor(IRoycoFactory _roycoFactory) RoycoTrancheValidator(_roycoFactory) { }

    /**
     * @notice Deploys a Pendle SY for the specified Royco tranche
     * @param _ostensibleRoycoTranche The ostensible Royco tranche to deploy the SY for, verified against the Royco factory
     * @param _offchainRewardManager The offchain reward manager (zero if the SY has no offchain rewards)
     * @return sy The deployed SY proxy address
     */
    function deploySY(address _ostensibleRoycoTranche, address _offchainRewardManager) external returns (address sy) {
        // Validate the ostensible tranche against the Royco factory
        _validateRoycoTranche(_ostensibleRoycoTranche);
        // Validate that an SY hasn't been deployed already for this (tranche, reward manager) pair
        require(trancheToOffchainRewardManagerToSY[_ostensibleRoycoTranche][_offchainRewardManager] == address(0), SY_ALREADY_DEPLOYED());

        // Deploy the SY implementation with its immutable arguments
        address implementation = address(new PendleRoycoTrancheSY(_ostensibleRoycoTranche, _offchainRewardManager));

        // Marshal the initialization data for the SY proxy with Pendle's pause controller set as the owner
        bytes memory initData = abi.encodeCall(
            PendleERC20SYUpgV2.initialize,
            (
                string(abi.encodePacked("SY ", IRoycoVaultTranche(_ostensibleRoycoTranche).name())),
                string(abi.encodePacked("SY-", IRoycoVaultTranche(_ostensibleRoycoTranche).symbol())),
                PENDLE_PAUSE_CONTROLLER
            )
        );

        // Deploy the tranche SY proxy: Pendle requires the v4.9.3 transparent proxy with their proxy admin set directly as the admin
        trancheToOffchainRewardManagerToSY[_ostensibleRoycoTranche][_offchainRewardManager] = sy = address(
            new TransparentUpgradeableProxy(implementation, PENDLE_PROXY_ADMIN, initData)
        );
        emit SYDeployed(_ostensibleRoycoTranche, sy, implementation);
    }
}
