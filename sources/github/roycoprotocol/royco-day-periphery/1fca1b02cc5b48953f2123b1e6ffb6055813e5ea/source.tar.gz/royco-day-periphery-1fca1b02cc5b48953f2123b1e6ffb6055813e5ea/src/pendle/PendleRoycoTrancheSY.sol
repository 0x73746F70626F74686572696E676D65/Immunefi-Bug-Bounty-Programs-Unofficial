// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.28;

import { PMath, PendleERC20SYUpgV2 } from "../../lib/Pendle-SY-Public/contracts/core/StandardizedYield/implementations/PendleERC20SYUpgV2.sol";
import { MerklRewardAbstract__NoStorage } from "../../lib/Pendle-SY-Public/contracts/core/misc/MerklRewardAbstract__NoStorage.sol";
import { IRoycoDayKernel } from "../../lib/royco-day/src/interfaces/IRoycoDayKernel.sol";
import { IRoycoVaultTranche } from "../../lib/royco-day/src/interfaces/IRoycoVaultTranche.sol";
import { AssetClaims, TrancheType } from "../../lib/royco-day/src/libraries/Types.sol";
import { toUint256 } from "../../lib/royco-day/src/libraries/Units.sol";
import { AssetLedgerLogic } from "../../lib/royco-day/src/libraries/logic/AssetLedgerLogic.sol";

/**
 * @title PendleRoycoTrancheSY
 * @author Shivaansh Kapoor, Ankur Dubey
 * @notice Pendle Standardized Yield wrapper for Royco (Senior, Junior, and Liquidity Provider) tranche shares
 */
contract PendleRoycoTrancheSY is PendleERC20SYUpgV2, MerklRewardAbstract__NoStorage {
    /// @dev The kernel of the Royco tranche for this SY
    IRoycoDayKernel private immutable TRANCHE_KERNEL;

    /// @dev The type of the Royco tranche for this SY
    TrancheType private immutable TRANCHE_TYPE;

    /**
     * @notice Constructs the Pendle SY for the specified Royco tranche
     * @param _roycoTranche The address of the Royco tranche which constitutes the yield bearing token of this SY
     * @param _offchainRewardManager The address of the offchain reward manager (null address if none exists for this SY)
     */
    constructor(address _roycoTranche, address _offchainRewardManager)
        PendleERC20SYUpgV2(_roycoTranche)
        MerklRewardAbstract__NoStorage(_offchainRewardManager)
    {
        TRANCHE_KERNEL = IRoycoDayKernel(IRoycoVaultTranche(_roycoTranche).kernel());
        TRANCHE_TYPE = IRoycoVaultTranche(_roycoTranche).TRANCHE_TYPE();
    }

    /**
     * @notice Returns the exchange rate of one tranche share in terms of the market's NAV units (USD, BTC, ETH, etc.)
     * @dev Prices via the kernel's preview sync rather than the tranche's own quote: the tranche conservatively
     *      excludes the LPT's idle liquidity-premium senior shares, which would flatline the rate while premium
     *      accrues and step it at reinvestment, so the kernel's effective-NAV claims price the premium continuously
     * @return The exchange rate such that: exchangeRate * syBalance / 1e18 = asset value
     */
    function exchangeRate() public view override(PendleERC20SYUpgV2) returns (uint256) {
        // Preview the sync to read the tranche's post-sync effective-NAV claims and post-mint share supply
        (, AssetClaims memory claims, uint256 totalTrancheShares) = TRANCHE_KERNEL.previewSyncTrancheAccountingFor(TRANCHE_TYPE);
        // Pendle's exchangeRate is NAV per 1e18 SY wei
        // For this 1:1 SY over an 18 decimal Royco tranche, PMath.ONE == 1 whole tranche share == 1 whole tranche SY
        // Scale the claims to 1 whole tranche SY through the protocol's own virtual-shares primitive
        return toUint256(AssetLedgerLogic._scaleAssetClaims(claims, PMath.ONE, totalTrancheShares, true).nav);
    }

    /**
     * @notice Returns metadata about the asset that the exchange rate is denominated in
     * @return assetType Always LIQUIDITY, as the exchange rate is denominated in the market's NAV units
     * @return assetAddress The Royco tranche address
     * @return assetDecimals Decimals of the asset (matches exchange rate denomination)
     */
    function assetInfo() external view override(PendleERC20SYUpgV2) returns (AssetType assetType, address assetAddress, uint8 assetDecimals) {
        return (AssetType.LIQUIDITY, yieldToken, decimals);
    }
}
