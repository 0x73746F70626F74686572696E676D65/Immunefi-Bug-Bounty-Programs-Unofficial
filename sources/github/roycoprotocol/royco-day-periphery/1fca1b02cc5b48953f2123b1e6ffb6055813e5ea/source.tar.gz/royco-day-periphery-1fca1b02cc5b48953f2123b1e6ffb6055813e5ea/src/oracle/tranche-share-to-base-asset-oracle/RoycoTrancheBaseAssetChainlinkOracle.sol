// SPDX-License-Identifier: LicenseRef-PolyForm-Perimeter-1.0.1
pragma solidity ^0.8.28;

import { IERC20Metadata } from "../../../lib/openzeppelin-contracts/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import { IRoycoVaultTranche } from "../../../lib/royco-day/src/interfaces/IRoycoVaultTranche.sol";
import { WAD } from "../../../lib/royco-day/src/libraries/Constants.sol";
import { AssetClaims, TrancheType } from "../../../lib/royco-day/src/libraries/Types.sol";
import { toUint256 } from "../../../lib/royco-day/src/libraries/Units.sol";
import { AggregatorV3Interface } from "../../interfaces/AggregatorV3Interface.sol";

/**
 * @title RoycoTrancheBaseAssetChainlinkOracle
 * @author Shivaansh Kapoor, Ankur Dubey
 * @notice A Chainlink compatible oracle exposing the price of 1 share of a Royco tranche in its base asset
 * @dev The senior and junior tranches price via the collateral-asset leg of their claims and the liquidity provider
 *      tranche via the LPT-asset leg. An LPT's held senior shares are not denominated in its base asset, so that leg is
 *      excluded from the answer: the price is conservative while unreinvested liquidity premium is held
 */
contract RoycoTrancheBaseAssetChainlinkOracle is AggregatorV3Interface {
    /// @notice The address of the Royco tranche that this oracle prices 1 share for in its base asset
    address public immutable ROYCO_TRANCHE;

    /// @notice The type of the Royco tranche, selecting which claims leg the tranche's base asset is denominated in
    TrancheType public immutable TRANCHE_TYPE;

    /// @notice The address of the base asset
    address public immutable BASE_ASSET;

    /// @notice Constructs the share price oracle for the specified Royco tranche
    /// @param _roycoTranche The Royco tranche that this oracle will be configured for
    constructor(address _roycoTranche) {
        ROYCO_TRANCHE = _roycoTranche;
        TRANCHE_TYPE = IRoycoVaultTranche(_roycoTranche).TRANCHE_TYPE();
        BASE_ASSET = IRoycoVaultTranche(_roycoTranche).asset();
    }

    /// @inheritdoc AggregatorV3Interface
    function decimals() external view override(AggregatorV3Interface) returns (uint8) {
        return IERC20Metadata(BASE_ASSET).decimals();
    }

    /// @inheritdoc AggregatorV3Interface
    /// @notice Composed as `<tranche symbol> / <base asset symbol>`, per the Chainlink base/quote description convention
    function description() external view override(AggregatorV3Interface) returns (string memory) {
        return string(abi.encodePacked(IRoycoVaultTranche(ROYCO_TRANCHE).symbol(), " / ", IERC20Metadata(BASE_ASSET).symbol()));
    }

    /// @inheritdoc AggregatorV3Interface
    function version() external pure override(AggregatorV3Interface) returns (uint256) {
        return 1;
    }

    /// @inheritdoc AggregatorV3Interface
    /// @notice The specified round ID must be 1 for this oracle
    function getRoundData(uint80 _roundId)
        external
        view
        override(AggregatorV3Interface)
        returns (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound)
    {
        // Revert if no data is available for the specified round ID
        require(_roundId == 1, "No data present");
        return latestRoundData();
    }

    /// @inheritdoc AggregatorV3Interface
    /// @notice The price returned is the price of 1 share of the Royco tranche in its base asset
    function latestRoundData()
        public
        view
        override(AggregatorV3Interface)
        returns (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound)
    {
        // Return the base asset claims tied to 1 tranche share (1e18 == WAD): the LPT-asset leg for the liquidity provider tranche, the collateral-asset leg otherwise
        AssetClaims memory claims = IRoycoVaultTranche(ROYCO_TRANCHE).convertToAssets(WAD);
        return (
            1,
            int256(toUint256(TRANCHE_TYPE == TrancheType.LIQUIDITY_PROVIDER ? claims.lptAssets : claims.collateralAssets)),
            block.timestamp,
            block.timestamp,
            1
        );
    }
}
