// SPDX-License-Identifier: LicenseRef-PolyForm-Perimeter-1.0.1
pragma solidity ^0.8.28;

import { IRoycoAuth } from "../../lib/royco-day/src/interfaces/IRoycoAuth.sol";
import { IRoycoFactory } from "../../lib/royco-day/src/interfaces/factory/IRoycoFactory.sol";

/**
 * @title RoycoTrancheValidator
 * @author Shivaansh Kapoor, Ankur Dubey
 * @notice Abstract base for periphery contracts that verify ostensible Royco tranches against the Royco factory's tranche registry
 */
abstract contract RoycoTrancheValidator {
    /// @notice The Royco factory whose tranche registry every ostensible tranche is verified against
    IRoycoFactory public immutable ROYCO_FACTORY;

    /// @dev Thrown when the ostensible tranche was not deployed by the Royco factory
    error NOT_A_ROYCO_TRANCHE(address ostensibleRoycoTranche);

    /// @notice Constructs the Royco tranche validator base contract
    /// @param _roycoFactory The Royco factory whose tranche registry every ostensible tranche is verified against
    constructor(IRoycoFactory _roycoFactory) {
        require(address(_roycoFactory) != address(0), IRoycoAuth.NULL_ADDRESS());
        ROYCO_FACTORY = _roycoFactory;
    }

    /**
     * @notice Validates that the ostensible tranche was deployed by the Royco factory
     * @dev A tranche the Royco factory never deployed maps to no kernel
     * @param _ostensibleRoycoTranche The ostensible Royco tranche to validate
     * @return kernel The kernel of the validated tranche's market
     */
    function _validateRoycoTranche(address _ostensibleRoycoTranche) internal view returns (address kernel) {
        require(_ostensibleRoycoTranche != address(0), IRoycoAuth.NULL_ADDRESS());
        kernel = ROYCO_FACTORY.trancheToKernel(_ostensibleRoycoTranche);
        require(kernel != address(0), NOT_A_ROYCO_TRANCHE(_ostensibleRoycoTranche));
    }
}
