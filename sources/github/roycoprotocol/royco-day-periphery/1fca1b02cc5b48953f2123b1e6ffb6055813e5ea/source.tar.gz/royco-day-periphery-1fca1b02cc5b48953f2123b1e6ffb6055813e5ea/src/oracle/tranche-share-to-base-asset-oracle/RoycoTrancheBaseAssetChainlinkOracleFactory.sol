// SPDX-License-Identifier: LicenseRef-PolyForm-Perimeter-1.0.1
pragma solidity ^0.8.28;

import { Create2 } from "../../../lib/openzeppelin-contracts/contracts/utils/Create2.sol";
import { IRoycoFactory } from "../../../lib/royco-day/src/interfaces/factory/IRoycoFactory.sol";
import { RoycoTrancheValidator } from "../../base/RoycoTrancheValidator.sol";
import { RoycoTrancheBaseAssetChainlinkOracle } from "./RoycoTrancheBaseAssetChainlinkOracle.sol";

/**
 * @title RoycoTrancheBaseAssetChainlinkOracleFactory
 * @author Shivaansh Kapoor, Ankur Dubey
 * @notice Permissionless factory that deploys Chainlink compatible oracles for Royco tranche share prices in their base asset
 * @dev Every ostensible tranche is verified against the Royco factory's tranche registry before an oracle is deployed for it
 */
contract RoycoTrancheBaseAssetChainlinkOracleFactory is RoycoTrancheValidator {
    /// @dev The global deployment salt used for all oracles
    bytes32 private constant ORACLE_DEPLOYMENT_SALT = keccak256(abi.encode("ROYCO_TRANCHE_BASE_ASSET_CHAINLINK_ORACLE"));

    /// @notice The deployed share price oracle for each Royco tranche
    mapping(address tranche => address oracle) public trancheToOracle;

    /// @notice Emitted when an oracle is deployed for a tranche
    event OracleDeployed(address indexed tranche, address indexed oracle);

    /// @param _roycoFactory The Royco factory whose tranche registry every ostensible tranche is verified against
    constructor(IRoycoFactory _roycoFactory) RoycoTrancheValidator(_roycoFactory) { }

    /**
     * @notice Deploys a share-price oracle for the specified tranche
     * @param _ostensibleRoycoTranche The ostensible Royco tranche to deploy the oracle for, verified against the Royco factory
     * @return oracle The deployed oracle's address
     */
    function deployOracle(address _ostensibleRoycoTranche) external returns (address oracle) {
        // Validate the ostensible tranche against the Royco factory
        _validateRoycoTranche(_ostensibleRoycoTranche);
        // Deploy the share price oracle for this tranche
        trancheToOracle[_ostensibleRoycoTranche] = oracle = address(
            new RoycoTrancheBaseAssetChainlinkOracle{ salt: ORACLE_DEPLOYMENT_SALT }(_ostensibleRoycoTranche)
        );
        emit OracleDeployed(_ostensibleRoycoTranche, oracle);
    }

    /// @notice Predicts the oracle address that would be deployed for the specified tranche
    function predictOracleAddress(address _tranche) external view returns (address) {
        return Create2.computeAddress(
            ORACLE_DEPLOYMENT_SALT, keccak256(abi.encodePacked(type(RoycoTrancheBaseAssetChainlinkOracle).creationCode, abi.encode(_tranche)))
        );
    }
}
