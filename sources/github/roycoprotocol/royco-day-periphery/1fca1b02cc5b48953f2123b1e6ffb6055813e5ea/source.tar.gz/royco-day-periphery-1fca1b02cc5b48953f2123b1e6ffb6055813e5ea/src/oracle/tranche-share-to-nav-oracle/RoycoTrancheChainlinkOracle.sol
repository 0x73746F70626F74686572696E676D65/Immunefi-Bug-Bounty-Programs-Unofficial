// SPDX-License-Identifier: LicenseRef-PolyForm-Perimeter-1.0.1
pragma solidity ^0.8.28;

import { ShortString, ShortStrings } from "../../../lib/openzeppelin-contracts/contracts/utils/ShortStrings.sol";
import { IRoycoVaultTranche } from "../../../lib/royco-day/src/interfaces/IRoycoVaultTranche.sol";
import { WAD, WAD_DECIMALS } from "../../../lib/royco-day/src/libraries/Constants.sol";
import { toInt256 } from "../../../lib/royco-day/src/libraries/Units.sol";
import { AggregatorV3Interface } from "../../interfaces/AggregatorV3Interface.sol";

/**
 * @title RoycoTrancheChainlinkOracle
 * @author Shivaansh Kapoor, Ankur Dubey
 * @notice A Chainlink compatible oracle exposing the price of 1 share of a Royco tranche in its NAV units (USD, BTC, ETH, etc.)
 * @dev Prices through the tranche's own conservative quote: an LPT's idle liquidity-premium senior shares are excluded
 *      from the answer, so the reported price never dips when reinvestment realizes slippage
 * @dev Not usable through the Royco quoters until the tranche has non-zero supply and non-zero NAV: a zero-supply or
 *      wiped tranche answers 0, and the Chainlink quoters reject non-positive answers — sequence deployments accordingly
 */
contract RoycoTrancheChainlinkOracle is AggregatorV3Interface {
    using ShortStrings for *;

    /// @notice The address of the Royco tranche that this oracle prices 1 share for in NAV units (USD, BTC, ETH, etc.)
    address public immutable ROYCO_TRANCHE;

    /// @dev The NAV asset's symbol (USD, BTC, ETH, etc.), packed into a single word so the description composes without storage
    ShortString private immutable _NAV_ASSET;

    /// @dev Thrown when the NAV asset's symbol is empty
    error NULL_NAV_ASSET();

    /**
     * @notice Constructs the share price oracle for the specified Royco tranche
     * @param _roycoTranche The Royco tranche that this oracle will be configured for
     * @param _navAsset The symbol of the NAV asset the tranche's shares are priced in (USD, BTC, ETH, etc.), at most 31 bytes
     */
    constructor(address _roycoTranche, string memory _navAsset) {
        require(bytes(_navAsset).length != 0, NULL_NAV_ASSET());
        ROYCO_TRANCHE = _roycoTranche;
        _NAV_ASSET = _navAsset.toShortString();
    }

    /// @notice The symbol of the NAV asset this oracle prices 1 tranche share in
    function NAV_ASSET() external view returns (string memory) {
        return _NAV_ASSET.toString();
    }

    /// @inheritdoc AggregatorV3Interface
    /// @notice All Royco tranches use 18 (WAD) decimals of precision for their NAV units
    function decimals() external pure override(AggregatorV3Interface) returns (uint8) {
        return uint8(WAD_DECIMALS);
    }

    /// @inheritdoc AggregatorV3Interface
    /// @notice Composed as `<tranche symbol> / <NAV asset>`, per the Chainlink base/quote description convention
    function description() external view override(AggregatorV3Interface) returns (string memory) {
        return string(abi.encodePacked(IRoycoVaultTranche(ROYCO_TRANCHE).symbol(), " / ", _NAV_ASSET.toString()));
    }

    /// @inheritdoc AggregatorV3Interface
    function version() external pure override(AggregatorV3Interface) returns (uint256) {
        return 1;
    }

    /// @inheritdoc AggregatorV3Interface
    /// @notice The specified round ID must be 1 for this oracle
    function getRoundData(uint80 _roundId)
        external
        view
        override(AggregatorV3Interface)
        returns (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound)
    {
        // Revert if no data is available for the specified round ID
        require(_roundId == 1, "No data present");
        return latestRoundData();
    }

    /**
     * @inheritdoc AggregatorV3Interface
     * @notice The price returned is the price of 1 share of the Royco tranche in its NAV units (USD, BTC, ETH, etc.)
     * @dev A reverting tranche query bubbles up its revert reason
     */
    function latestRoundData()
        public
        view
        override(AggregatorV3Interface)
        returns (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound)
    {
        // Return the NAV of the asset claims tied to 1 tranche share (1e18 == WAD)
        return (1, toInt256(IRoycoVaultTranche(ROYCO_TRANCHE).convertToAssets(WAD).nav), block.timestamp, block.timestamp, 1);
    }
}
