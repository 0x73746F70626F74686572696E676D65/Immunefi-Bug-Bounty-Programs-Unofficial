// SPDX-License-Identifier: LicenseRef-PolyForm-Perimeter-1.0.1
pragma solidity ^0.8.28;

import { Create2 } from "../../../lib/openzeppelin-contracts/contracts/utils/Create2.sol";
import { IRoycoFactory } from "../../../lib/royco-day/src/interfaces/factory/IRoycoFactory.sol";
import { RoycoTrancheValidator } from "../../base/RoycoTrancheValidator.sol";
import { RoycoTrancheChainlinkOracle } from "./RoycoTrancheChainlinkOracle.sol";

/**
 * @title RoycoTrancheChainlinkOracleFactory
 * @author Shivaansh Kapoor, Ankur Dubey
 * @notice Permissionless factory that deploys Chainlink compatible oracles for Royco tranche share prices
 * @dev Every ostensible tranche is verified against the Royco factory's tranche registry before an oracle is deployed for it
 */
contract RoycoTrancheChainlinkOracleFactory is RoycoTrancheValidator {
    /// @dev The global deployment salt used for all oracles
    bytes32 private constant ORACLE_DEPLOYMENT_SALT = keccak256(abi.encode("ROYCO_TRANCHE_NAV_CHAINLINK_ORACLE"));

    /// @notice The deployed share price oracle for each Royco tranche
    mapping(address tranche => address oracle) public trancheToOracle;

    /// @notice Emitted when an oracle is deployed for a tranche
    event OracleDeployed(address indexed tranche, address indexed oracle);

    /// @param _roycoFactory The Royco factory whose tranche registry every ostensible tranche is verified against
    constructor(IRoycoFactory _roycoFactory) RoycoTrancheValidator(_roycoFactory) { }

    /**
     * @notice Deploys a share-price oracle for the specified tranche
     * @param _ostensibleRoycoTranche The ostensible Royco tranche to deploy the oracle for, verified against the Royco factory
     * @param _navAsset The symbol of the NAV asset the tranche's shares are priced in (USD, BTC, ETH, etc.), at most 31 bytes
     * @return oracle The deployed oracle's address
     */
    function deployOracle(address _ostensibleRoycoTranche, string calldata _navAsset) external returns (address oracle) {
        // Validate the ostensible tranche against the Royco factory
        _validateRoycoTranche(_ostensibleRoycoTranche);
        // Deploy the share price oracle for this tranche
        trancheToOracle[_ostensibleRoycoTranche] = oracle = address(
            new RoycoTrancheChainlinkOracle{ salt: ORACLE_DEPLOYMENT_SALT }(_ostensibleRoycoTranche, _navAsset)
        );
        emit OracleDeployed(_ostensibleRoycoTranche, oracle);
    }

    /// @notice Predicts the oracle address that would be deployed for the specified tranche and NAV asset symbol
    function predictOracleAddress(address _tranche, string calldata _navAsset) external view returns (address) {
        return Create2.computeAddress(
            ORACLE_DEPLOYMENT_SALT, keccak256(abi.encodePacked(type(RoycoTrancheChainlinkOracle).creationCode, abi.encode(_tranche, _navAsset)))
        );
    }
}
