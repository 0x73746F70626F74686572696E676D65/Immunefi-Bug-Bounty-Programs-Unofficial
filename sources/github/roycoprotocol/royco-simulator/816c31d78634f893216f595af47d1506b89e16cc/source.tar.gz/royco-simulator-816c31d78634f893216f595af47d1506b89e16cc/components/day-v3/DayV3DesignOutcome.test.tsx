import assert from "node:assert/strict";
import { renderToStaticMarkup } from "react-dom/server";

import DayV3DesignOutcome from "@/components/day-v3/DayV3DesignOutcome";

const markup = renderToStaticMarkup(
  <DayV3DesignOutcome
    current={{
      sourceApyPct: 5.8,
      protectedDrawdownPct: 10,
      coveragePct: 10,
      juniorPer100: 12.5,
      immediateExitSharePct: 5,
      minimumProceedsPer100: 99,
      slpPer100: null,
      proceeds: null,
      seniorApyPct: null,
      juniorApyPct: null,
      slpApyPct: null,
      basis: "blocked",
      message: "No feasible pool satisfies these exit terms.",
    }}
  />,
);

assert.match(markup, /Protection/);
assert.match(markup, /10\.0% drawdown/);
assert.match(markup, /10\.0% minimum coverage · \$12\.5 Junior/);
assert.match(markup, /Immediate exit/);
assert.match(markup, /\$5\.0 at once/);
assert.match(markup, /Payout floor/);
assert.match(markup, /\$99/);
assert.match(markup, /Needs changes/);
assert.match(markup, /reducing depth at NAV/);
assert.match(markup, /allowing a larger maximum discount/);
assert.match(
  markup,
  /shortening conversion time or lowering the external spread assumption/,
);
assert.doesNotMatch(markup, /Design outcome/);
assert.doesNotMatch(markup, /Saved designs/);
assert.doesNotMatch(markup, /Save for comparison/);

console.log("Day V3 design outcome presentation: PASS");
