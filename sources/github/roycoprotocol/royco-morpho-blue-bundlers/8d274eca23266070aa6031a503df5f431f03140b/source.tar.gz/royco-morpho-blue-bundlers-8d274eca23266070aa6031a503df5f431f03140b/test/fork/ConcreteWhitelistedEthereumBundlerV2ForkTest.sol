// SPDX-License-Identifier: GPL-2.0-or-later
pragma solidity ^0.8.0;

import {ConcreteWhitelistedEthereumBundlerV2} from "../../src/ethereum/ConcreteWhitelistedEthereumBundlerV2.sol";
import {IWhitelistDepositHook} from "../../src/interfaces/concrete/IWhitelistDepositHook.sol";
import {ErrorsLib} from "../../src/libraries/ErrorsLib.sol";
import {TransferBundler} from "../../src/TransferBundler.sol";
import {SafeTransferLib, ERC20} from "../../lib/solmate/src/utils/SafeTransferLib.sol";

import "../../lib/forge-std/src/Test.sol";

contract ConcreteWhitelistedEthereumBundlerV2ForkTest is Test {
    using SafeTransferLib for ERC20;

    address constant MORPHO = 0xBBBBBbbBBb9cC5e90e3b3Af64bdAF62C37EEFFCb;
    address constant WHITELIST_HOOK = 0x5c4952751CF5C9D4eA3ad84F3407C56Ba2342F13;
    address constant WETH = 0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2;

    ConcreteWhitelistedEthereumBundlerV2 bundler;

    function setUp() public {
        vm.createSelectFork(vm.rpcUrl("ethereum"));

        bundler = new ConcreteWhitelistedEthereumBundlerV2(MORPHO, WHITELIST_HOOK);
    }

    /// @notice A non-whitelisted address cannot call multicall.
    function testNonWhitelistedCannotMulticall() public {
        address user = makeAddr("nonWhitelisted");

        assertFalse(IWhitelistDepositHook(WHITELIST_HOOK).isWhitelisted(user));

        bytes[] memory data = new bytes[](0);

        vm.prank(user);
        vm.expectRevert(bytes(ErrorsLib.NOT_WHITELISTED_CONCRETE));
        bundler.multicall(data);
    }

    /// @notice Fuzz: any non-whitelisted address is rejected.
    function testNonWhitelistedCannotMulticallFuzz(address user) public {
        vm.assume(!IWhitelistDepositHook(WHITELIST_HOOK).isWhitelisted(user));

        bytes[] memory data = new bytes[](0);

        vm.prank(user);
        vm.expectRevert(bytes(ErrorsLib.NOT_WHITELISTED_CONCRETE));
        bundler.multicall(data);
    }

    /// @notice A whitelisted address can call multicall.
    function testWhitelistedCanMulticall() public {
        address user = makeAddr("whitelisted");

        vm.mockCall(
            WHITELIST_HOOK, abi.encodeCall(IWhitelistDepositHook.isWhitelisted, (user)), abi.encode(true)
        );

        bytes[] memory data = new bytes[](0);

        vm.prank(user);
        bundler.multicall(data);
    }

    /// @notice A whitelisted address can execute real bundler actions (transfer in + transfer out).
    function testWhitelistedCanExecuteActions() public {
        address user = makeAddr("whitelisted");
        address receiver = makeAddr("receiver");

        vm.mockCall(
            WHITELIST_HOOK, abi.encodeCall(IWhitelistDepositHook.isWhitelisted, (user)), abi.encode(true)
        );

        deal(WETH, user, 1 ether);

        vm.prank(user);
        ERC20(WETH).safeApprove(address(bundler), type(uint256).max);

        bytes[] memory data = new bytes[](2);
        data[0] = abi.encodeCall(TransferBundler.erc20TransferFrom, (WETH, 1 ether));
        data[1] = abi.encodeCall(TransferBundler.erc20Transfer, (WETH, receiver, 1 ether));

        vm.prank(user);
        bundler.multicall(data);

        assertEq(ERC20(WETH).balanceOf(receiver), 1 ether, "receiver should have received WETH");
        assertEq(ERC20(WETH).balanceOf(user), 0, "user should have no WETH remaining");
    }

    /// @notice A non-whitelisted address cannot execute bundler actions.
    function testNonWhitelistedCannotExecuteActions() public {
        address user = makeAddr("nonWhitelisted");
        address receiver = makeAddr("receiver");

        assertFalse(IWhitelistDepositHook(WHITELIST_HOOK).isWhitelisted(user));

        deal(WETH, user, 1 ether);

        vm.prank(user);
        ERC20(WETH).safeApprove(address(bundler), type(uint256).max);

        bytes[] memory data = new bytes[](2);
        data[0] = abi.encodeCall(TransferBundler.erc20TransferFrom, (WETH, 1 ether));
        data[1] = abi.encodeCall(TransferBundler.erc20Transfer, (WETH, receiver, 1 ether));

        vm.prank(user);
        vm.expectRevert(bytes(ErrorsLib.NOT_WHITELISTED_CONCRETE));
        bundler.multicall(data);

        assertEq(ERC20(WETH).balanceOf(user), 1 ether, "user WETH should be untouched");
        assertEq(ERC20(WETH).balanceOf(receiver), 0, "receiver should have received nothing");
    }

    /// @notice If a user's whitelist status is revoked, they can no longer use the bundler.
    function testWhitelistRevokedCannotMulticall() public {
        address user = makeAddr("wasWhitelisted");

        // User is initially whitelisted.
        vm.mockCall(
            WHITELIST_HOOK, abi.encodeCall(IWhitelistDepositHook.isWhitelisted, (user)), abi.encode(true)
        );

        bytes[] memory data = new bytes[](0);

        vm.prank(user);
        bundler.multicall(data);

        // Whitelist is revoked.
        vm.clearMockedCalls();
        vm.mockCall(
            WHITELIST_HOOK, abi.encodeCall(IWhitelistDepositHook.isWhitelisted, (user)), abi.encode(false)
        );

        vm.prank(user);
        vm.expectRevert(bytes(ErrorsLib.NOT_WHITELISTED_CONCRETE));
        bundler.multicall(data);
    }
}
