// SPDX-License-Identifier: GPL-2.0-or-later
pragma solidity 0.8.24;

import {ConcreteWhitelistedEthereumBundlerV2} from "../src/ethereum/ConcreteWhitelistedEthereumBundlerV2.sol";

import {Script, console} from "../lib/forge-std/src/Script.sol";

contract DeployConcreteWhitelistedEthereumBundlerV2 is Script {
    address constant MORPHO = 0xBBBBBbbBBb9cC5e90e3b3Af64bdAF62C37EEFFCb;
    address constant WHITELIST_HOOK = 0x5c4952751CF5C9D4eA3ad84F3407C56Ba2342F13;

    function run() external returns (ConcreteWhitelistedEthereumBundlerV2 bundler) {
        vm.broadcast();
        bundler = new ConcreteWhitelistedEthereumBundlerV2(MORPHO, WHITELIST_HOOK);

        console.log("ConcreteWhitelistedEthereumBundlerV2 deployed at:", address(bundler));
        console.log("  MORPHO:", MORPHO);
        console.log("  WHITELIST_DEPOSIT_HOOK:", address(bundler.WHITELIST_DEPOSIT_HOOK()));
    }
}
