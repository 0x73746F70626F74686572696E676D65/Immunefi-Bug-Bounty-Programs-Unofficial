/// SPDX-License-Identifier: GPL-2.0-or-later
pragma solidity ^0.8.0;

interface IWhitelistDepositHook {
    /// @notice Checks if the given `account` is whitelisted.
    /// @param account The address to check.
    /// @return True if the account is whitelisted, false otherwise.
    function isWhitelisted(address account) external view returns (bool);
}
