// SPDX-License-Identifier: GPL-2.0-or-later
pragma solidity 0.8.24;

import {IWhitelistDepositHook} from "../interfaces/concrete/IWhitelistDepositHook.sol";
import {BaseBundler} from "../BaseBundler.sol";
import {ErrorsLib} from "../libraries/ErrorsLib.sol";
import {EthereumBundlerV2} from "./EthereumBundlerV2.sol";

/// @title ConcreteWhitelistedEthereumBundlerV2
/// @author Waymont
/// @notice Concrete whitelisted Ethereum bundler contract.
contract ConcreteWhitelistedEthereumBundlerV2 is EthereumBundlerV2 {
    /// @notice The whitelist deposit hook contract.
    IWhitelistDepositHook public immutable WHITELIST_DEPOSIT_HOOK;

    constructor(address morpho, address whitelistDepositHook) EthereumBundlerV2(morpho) {
        require(whitelistDepositHook != address(0), ErrorsLib.ZERO_ADDRESS);
        WHITELIST_DEPOSIT_HOOK = IWhitelistDepositHook(whitelistDepositHook);
    }

    /// @inheritdoc BaseBundler
    /// @dev Adds the whitelist deposit hook check to the sender authorization.
    function multicall(bytes[] memory data) public payable virtual override(BaseBundler) {
        require(WHITELIST_DEPOSIT_HOOK.isWhitelisted(msg.sender), ErrorsLib.NOT_WHITELISTED_CONCRETE);
        super.multicall(data);
    }
}
