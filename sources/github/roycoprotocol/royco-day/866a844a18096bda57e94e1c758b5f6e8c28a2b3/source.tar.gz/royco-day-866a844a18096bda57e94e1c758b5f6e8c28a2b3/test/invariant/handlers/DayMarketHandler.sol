// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { IVaultErrors } from "../../../lib/balancer-v3-monorepo/pkg/interfaces/contracts/vault/IVaultErrors.sol";
import { IERC20Errors } from "../../../lib/openzeppelin-contracts/contracts/interfaces/draft-IERC6093.sol";
import { IERC20 } from "../../../lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol";
import { IERC20Metadata } from "../../../lib/openzeppelin-contracts/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import { Math } from "../../../lib/openzeppelin-contracts/contracts/utils/math/Math.sol";
import { JT_LP_ROLE, LPT_LP_ROLE, ST_LP_ROLE } from "../../../src/factory/Roles.sol";
import { IRoycoDayAccountant } from "../../../src/interfaces/IRoycoDayAccountant.sol";
import { IRoycoDayKernel } from "../../../src/interfaces/IRoycoDayKernel.sol";
import { WAD } from "../../../src/libraries/Constants.sol";
import { MarketState } from "../../../src/libraries/Types.sol";
import { toNAVUnits, toTrancheUnits, toUint256 } from "../../../src/libraries/Units.sol";
import { DayMarketTestBase } from "../../utils/DayMarketTestBase.sol";
import { MarketParamsConfig } from "../../utils/FixtureTypes.sol";
import { defaultParams, zeroLiquidityParams } from "../../utils/MarketParams.sol";
import { RoycoTestMath } from "../../utils/RoycoTestMath.sol";
import { RoycoTestMath } from "../../utils/RoycoTestMath.sol";
import { cellA } from "../../utils/TokenConfigs.sol";

/**
 * @title DayMarketHandler
 * @notice Stateful-invariant handler driving a full mock Day market through every tranche flow, sync,
 *         reinvestment, time, PnL injection, admin nudges, and external pool activity
 * @dev Every op runs in three phases. First a keeper sync whose full outcome is verified against an
 *      independent recomputation (the tranche accounting sync mirror, the fee and liquidity premium
 *      share mint mirror, the accrual-window mirror, the pool-mark mirror). Second the op itself,
 *      executed under a revert prediction computed
 *      from the freshly committed state with the independent gate formulas, so the op may be observed to
 *      revert only for a reason the handler derived on its own. Third a trailing verified sync that
 *      realizes and checks the op's effects. An unpredicted revert, a failed sync, or any mismatch against
 *      a mirror records a violation that the invariant contract asserts empty after every call, so nothing
 *      is ever silently swallowed
 * @dev Ops never early-return on a live market. Degenerate states (an empty tranche, an already-breached
 *      threshold) are recognized by recomputing the same gate the production code enforces, and the op then
 *      either asserts the predicted revert or performs its recorded no-op, never a blind skip
 */
contract DayMarketHandler is DayMarketTestBase {
    using Math for uint256;

    // =============================
    // Immutable profile and derived constants
    // =============================

    /// @notice Whether this market runs the zero-minimum-liquidity reduction profile
    bool public immutable IS_ZERO_LIQUIDITY_PROFILE;

    /// @dev One whole quote token in its native decimals
    uint256 internal QUOTE_UNIT;

    /// @dev One whole LPT asset in its native decimals, the kernel's per-pool-token price quantum
    uint256 internal LPT_UNIT;

    /// @dev The pinned instantaneous junior yield share the mock model returns on every query
    uint256 internal JT_PINNED_SHARE_WAD;

    /// @dev The pinned instantaneous liquidity yield share the mock model returns on every query
    uint256 internal LPT_PINNED_SHARE_WAD;

    /**
     * @dev Worst-case NAV-wei lost to flooring across one operation's unit conversions and claim scalings.
     *      A single mulDiv floor loses under 1 wei of its result and one op performs at most ten of them
     *      (two pricing conversions per leg, the five claim fields, the post-op delta), each worth at most
     *      the share-rate in NAV wei. The share rate stays below 10 under the bounded PnL regime, so 100
     *      NAV wei bounds the total. Used only to tolerate flooring in the share-price monotonicity check
     */
    uint256 internal constant PRICE_FLOOR_DUST_NAV_WEI_DERIVED_BOUND = 100;

    /**
     * @dev The campaign's tranche share-supply bound, protecting the zero-NAV mint edge. With the
     *      production mint-dilution clamp, one wipe-and-deposit dilution cycle multiplies a supply by at
     *      most (WAD − ε)/ε (~1e12 at the default ε = 1e6) instead of by the deposit's NAV value, but a
     *      residual overflow cliff remains: the clamp's own cap computation overflows once
     *      supply ≥ ~2^256·ε/(WAD − ε) ≈ 1.158e65, so ~4 unchecked cycles from 1e21 still reach a
     *      Panic(0x11), including inside the sync's fee mint, which would brick the market. Every deposit
     *      op therefore clamps against this bound (the one venue-priced mint, the multi-asset LPT share,
     *      keeps the panic prediction only: the drained-pool dilution state it would need cannot recur
     *      across successful adds), so campaign states stay provably overflow-free: unclamped supplies stop
     *      at 1e45, a clamped one-unit deposit at most doubles the supply and run depths give far fewer
     *      doublings than the ~65 that would matter, so the worst later cap computation is
     *      ~1e52 × 1e12 ≈ 1e64 < 1.158e65 and the sync's fee mints add at most ~supply / 9 on top. Sync
     *      liveness therefore cannot be lost to this edge inside a campaign, while the dilution branch
     *      itself stays exercised at one-unit size. The cliff itself (the cap computation's Panic(0x11)
     *      once a supply crosses ~1.158e65) is covered by the concrete test
     *      test_mintDilutionClamp_capComputationOverflowBoundary
     *      (Kernel/Test_EntrypointGateAndConversionEdges.t.sol), not re-hunted by campaigns
     */
    uint256 internal constant TRANCHE_SUPPLY_CAMPAIGN_BOUND = 1e45;

    // =============================
    // Actors
    // =============================

    address[3] internal stActors;
    address[2] internal jtActors;
    address[2] internal lptActors;
    address internal externalLp;

    // =============================
    // Violation recording (the invariant contract asserts these empty)
    // =============================

    /// @notice The first recorded violation message, empty while the run is healthy
    string public ghost_violation;

    /// @notice The number of violations recorded so far
    uint256 public ghost_violationCount;

    // =============================
    // Ghost ledgers
    // =============================

    /// @notice Cumulative token amounts actors transferred into the market, per asset
    mapping(address token => uint256) public ghost_transferredIn;

    /// @notice Cumulative token amounts receivers took out of the market, per asset
    mapping(address token => uint256) public ghost_transferredOut;

    /// @notice Cumulative liquidity premium senior shares minted to the market (mirrors LiquidityPremiumSharesMinted)
    uint256 public ghost_liquidityPremiumSharesMinted;

    /// @notice Cumulative idle liquidity premium senior shares deployed into the pool, measured at the pool's own balance
    uint256 public ghost_liquidityPremiumSharesReinvested;

    /// @notice Cumulative idle liquidity premium senior shares handed directly to redeemers
    uint256 public ghost_idlePremiumSeniorSharesPaidToRedeemers;

    /// @dev The cause of one recorded jtImpermanentLoss ledger movement. The old JT_REDEEM_SCALE cause is
    ///      gone with the deleted postOp scaling: a junior exit only settles in PERPETUAL where the ledger
    ///      is already zero, so a redeem can never move it
    enum JTImpermanentLossCause {
        COVERAGE_APPLIED,
        RECOVERY,
        ERASED
    }

    /// @dev One recorded jtImpermanentLoss ledger movement
    struct JTImpermanentLossEvent {
        JTImpermanentLossCause cause;
        uint256 magnitude;
    }

    /// @notice The append-only log of every jtImpermanentLoss ledger movement with its cause
    JTImpermanentLossEvent[] public ghost_jtImpermanentLossEvents;

    /// @dev The jtImpermanentLoss value implied by replaying the event log, checked against the committed value
    uint256 internal ghost_jtImpermanentLossReplay;

    // =============================
    // Share-price monotonicity trackers
    // =============================

    uint256 internal ghost_stPriceHighWater;
    uint256 internal ghost_jtPriceHighWater;
    uint256 internal ghost_lptPriceHighWater;

    // The OZ virtual-shares share price floor((effNAV + VIRTUAL_VALUE) * WAD / (supply + VIRTUAL_SHARES)) captured
    // at each high-water. The naive price floor(effNAV * WAD / supply) the check tracks sits ABOVE this virtual
    // price by an offset gap that SHRINKS as supply grows on deposits. The virtual price is the monotone-non-decreasing
    // OZ share price (it never falls on a no-loss deposit), so absent a loss event the naive price can fall by at most
    // the gap captured at the high-water. Tolerating exactly that stored gap keeps the monotonicity check tight while
    // absorbing the offset's deposit-dilution dust (a real loss still drops the virtual price and trips the check).
    uint256 internal ghost_stVirtualHighWater;
    uint256 internal ghost_jtVirtualHighWater;
    uint256 internal ghost_lptVirtualHighWater;

    /// @dev Set by ops that can legitimately push the senior share price down (an uncovered drawdown)
    bool internal ghost_uncoveredLossSinceLastCheck;

    /// @dev Set by ops that can legitimately push the junior share price down (losses, coverage, exit bonuses)
    bool internal ghost_jtLossSinceLastCheck;

    /// @dev Set by ops that can legitimately push the liquidity share price down (a venue drawdown)
    bool internal ghost_lptVenueLossSinceLastCheck;

    /**
     * @dev Idle premium senior shares deployed into the venue since the last price-monotonicity check,
     *      whether by a sync's own reinvestment attempt or by op_reinvest. A deploy re-marks the deployed
     *      shares from their exact claimable-leg valuation floor(n * (stEffectiveNAV + 1) / (stSupply + 1e6)) down to
     *      the venue's WAD-quantized senior rate, floor((stEffectiveNAV + 1) * WAD / (stSupply + 1e6)) / WAD per share,
     *      so the liquidity effective NAV may fall by the quantization residual
     *      n * ((stEffectiveNAV * WAD) mod stSupply) / (stSupply * WAD) < n / WAD NAV wei with no value
     *      leaving the market (the mark is quantized, not the value). The liquidity price check consumes
     *      and resets this counter, widening its dust bound by exactly that derived residual
     */
    uint256 internal ghost_stSharesDeployedSinceLastPriceCheck;

    // =============================
    // Accrual-window mirror state
    // =============================

    /// @dev The largest configured junior yield-share cap seen inside the current premium window
    uint256 internal ghost_windowMaxJTShareWAD;

    /// @dev The largest configured liquidity yield-share cap seen inside the current premium window
    uint256 internal ghost_windowMaxLPTShareWAD;

    // =============================
    // Regime counters (reported by the invariant contract)
    // =============================

    uint256 public ghost_enteredFixedTerm;
    uint256 public ghost_exitedFixedTerm;
    uint256 public ghost_crossedLiquidationThreshold;
    uint256 public ghost_idleLiquidityPremiumObserved;
    uint256 public ghost_zeroSupplyStatesReached;
    uint256 public ghost_syncCount;
    uint256 public ghost_uncoveredLossRealized;

    /// @notice Invocations per op label, the anti-vacuity ledger: a run that never scheduled an op is visible here
    mapping(bytes32 op => uint256) public ghost_opCalls;

    /// @notice Successful executions per op label
    mapping(bytes32 op => uint256) public ghost_opSuccesses;

    /// @notice Predicted (and observed) gate rejections per op label
    mapping(bytes32 op => uint256) public ghost_opPredictedReverts;

    /// @notice Whether the venue is armed to fail single-sided reinvestments with a punitive haircut
    bool public ghost_venueSlippageArmed;

    // =============================
    // Predicted-revert machinery
    // =============================

    /// @dev A bounded buffer of revert selectors the current op is allowed to produce
    struct Pred {
        bytes4[12] sels;
        uint256 n;
    }

    bytes4 internal constant SEL_DISABLED_FT = IRoycoDayKernel.DISABLED_IN_FIXED_TERM_STATE.selector;
    bytes4 internal constant SEL_COVERAGE = IRoycoDayKernel.COVERAGE_REQUIREMENT_VIOLATED.selector;
    bytes4 internal constant SEL_LIQUIDITY = IRoycoDayKernel.LIQUIDITY_REQUIREMENT_VIOLATED.selector;
    bytes4 internal constant SEL_JT_LIQ_BLOCKED = IRoycoDayKernel.JT_DEPOSIT_BLOCKED_DURING_LIQUIDATION.selector;
    bytes4 internal constant SEL_INVALID_POST_OP = IRoycoDayAccountant.INVALID_POST_OP_STATE.selector;
    bytes4 internal constant SEL_ZERO_SHARES = IRoycoDayKernel.MUST_MINT_NON_ZERO_SHARES.selector;
    bytes4 internal constant SEL_ERC20_BALANCE = IERC20Errors.ERC20InsufficientBalance.selector;
    bytes4 internal constant SEL_AMOUNT_OUT_BELOW_MIN = IVaultErrors.AmountOutBelowMin.selector;
    bytes4 internal constant SEL_PANIC = bytes4(0x4e487b71);

    // =============================
    // Committed-state snapshot taken right after a verified sync
    // =============================

    /// @dev Everything an op needs to predict its own gates, read from freshly committed state
    struct Snap {
        bool ok;
        bool fixedTerm;
        uint256 collateralNAV;
        uint256 lptRawNAV;
        uint256 stEffectiveNAV;
        uint256 jtEffectiveNAV;
        uint256 jtImpermanentLoss;
        uint256 coverageUtilizationWAD;
        uint256 minCoverageWAD;
        uint256 minLiquidityWAD;
        uint256 coverageLiquidationUtilizationWAD;
        uint256 dustTolerance;
        uint256 stSupply;
        uint256 jtSupply;
        uint256 lptSupply;
        uint256 collateralOwned;
        uint256 lptOwned;
        uint256 lptOwnedSeniorTrancheShares;
        uint256 bonusWAD;
    }

    // =============================
    // Construction
    // =============================

    /// @dev Guards init against a second call
    bool internal initialized;

    /// @notice Records the profile only, the market deploys in init once this contract has code
    /// @param _zeroLiquidityProfile Whether to run the zero-minimum-liquidity reduction market
    constructor(bool _zeroLiquidityProfile) {
        IS_ZERO_LIQUIDITY_PROFILE = _zeroLiquidityProfile;
    }

    /// @notice Deploys, seeds, and baselines the market, callable once from the invariant contract's setUp
    /// @dev Split from the constructor because the verified sync self-calls this contract, which has no code mid-construction
    function init() external {
        require(!initialized, "already initialized");
        initialized = true;
        MarketParamsConfig memory p = IS_ZERO_LIQUIDITY_PROFILE ? zeroLiquidityParams() : defaultParams();
        _deployMarket(cellA(), p);

        QUOTE_UNIT = 10 ** uint256(cell.quoteAsset.decimals);
        LPT_UNIT = uint256(kernel.getState().oneWholeLPTAsset);
        JT_PINNED_SHARE_WAD = uint256(params.jtCurve[1]);
        LPT_PINNED_SHARE_WAD = uint256(params.lptCurve[1]);
        ghost_windowMaxJTShareWAD = params.maxJTYieldShareWAD;
        ghost_windowMaxLPTShareWAD = params.maxLPTYieldShareWAD;

        // Actor set: three senior LPs, two junior LPs, two liquidity LPs, one external pool participant
        stActors[0] = _generateActor("H_ST_ACTOR_0", ST_LP_ROLE);
        stActors[1] = _generateActor("H_ST_ACTOR_1", ST_LP_ROLE);
        stActors[2] = _generateActor("H_ST_ACTOR_2", ST_LP_ROLE);
        jtActors[0] = _generateActor("H_JT_ACTOR_0", JT_LP_ROLE);
        jtActors[1] = _generateActor("H_JT_ACTOR_1", JT_LP_ROLE);
        lptActors[0] = _generateActor("H_LPT_ACTOR_0", LPT_LP_ROLE);
        lptActors[1] = _generateActor("H_LPT_ACTOR_1", LPT_LP_ROLE);
        // The external actor holds ST_LP_ROLE only so it can source senior shares through the real gated
        // deposit path (never a mint), its pool interactions themselves are permissionless
        externalLp = _generateActor("H_EXTERNAL_LP", ST_LP_ROLE);

        // Seed a healthy market: 30k junior first (coverage), auto-seeded quote depth, then 100k senior
        _seedMarket(100_000e18, 30_000e18);

        // Baseline the ghost ledgers and the price high-water marks off one verified sync
        _syncAndVerify("constructor");
        ghost_transferredIn[address(stJtVault)] = stJtVault.balanceOf(address(kernel));
        ghost_jtImpermanentLossReplay = toUint256(accountant.getState().lastJTImpermanentLoss);
    }

    // =============================
    // Weighted ops
    // =============================

    /// @notice A senior LP deposits vault shares through the production deposit path
    function op_stDeposit(uint256 _actorSeed, uint256 _assets) external {
        _recordCall("stDeposit");
        address actor = stActors[bound(_actorSeed, 0, stActors.length - 1)];
        // Uniform over 1e-6 to 1e6 whole vault shares, wide enough to press the coverage and liquidity gates
        uint256 assets = bound(_assets, 1e12, 1e24);
        Snap memory s = _syncAndVerify("pre:stDeposit");
        if (s.ok) {
            // The in-handler supply bound: keep the mint from carrying the senior supply past the campaign bound
            assets = _clampSupplySafeDeposit(assets, _quoteCollateralUnits(assets), s.stEffectiveNAV, s.stSupply);
            _execStDeposit(actor, assets, s);
            _syncAndVerify("post:stDeposit");
        }
    }

    /// @notice A senior LP redeems shares, receiving its slice of the senior and junior asset pools
    function op_stRedeem(uint256 _actorSeed, uint256 _shares) external {
        _recordCall("stRedeem");
        address actor = stActors[bound(_actorSeed, 0, stActors.length - 1)];
        Snap memory s = _syncAndVerify("pre:stRedeem");
        if (s.ok) {
            uint256 bal = seniorTranche.balanceOf(actor);
            // Uniform over the actor's holding, degraded to a single share on an empty balance so the
            // insufficient-balance revert is asserted instead of skipped
            uint256 shares = bound(_shares, 1, bal == 0 ? 1 : bal);
            _execStRedeem(actor, shares, s);
            _syncAndVerify("post:stRedeem");
        }
    }

    /// @notice A junior LP deposits vault shares, growing the loss-absorption buffer
    function op_jtDeposit(uint256 _actorSeed, uint256 _assets) external {
        _recordCall("jtDeposit");
        address actor = jtActors[bound(_actorSeed, 0, jtActors.length - 1)];
        // Uniform over 1e-6 to 1e6 whole vault shares
        uint256 assets = bound(_assets, 1e12, 1e24);
        Snap memory s = _syncAndVerify("pre:jtDeposit");
        if (s.ok) {
            // The in-handler supply bound: keep the mint from carrying the junior supply past the campaign bound
            assets = _clampSupplySafeDeposit(assets, _quoteCollateralUnits(assets), s.jtEffectiveNAV, s.jtSupply);
            Pred memory p;
            uint256 value = _quoteCollateralUnits(assets);
            uint256 predShares;
            if (s.fixedTerm) {
                _expect(p, SEL_DISABLED_FT);
            } else {
                uint256 collateralAfter = _quoteCollateralUnits(s.collateralOwned + assets);
                // A zero-value deposit prices to zero shares before the post-op delta requirement can fire
                if (value != 0 && collateralAfter == s.collateralNAV) _expect(p, SEL_INVALID_POST_OP);
                bool mintPanics;
                (predShares, mintPanics) = _mirrorMintShares(value, s.jtEffectiveNAV, s.jtSupply);
                // Past the supply-inflation cliff the clamped mint's cap computation itself overflows: mirror
                // that panic so the handler asserts the boundary revert rather than treating it as a defect
                if (mintPanics) _expect(p, SEL_PANIC);
                else if (predShares == 0) _expect(p, SEL_ZERO_SHARES);
                // Mirror the post-op liquidation gate: a JT deposit must settle strictly below the liquidation
                // coverage utilization, so a sub-curing deposit into the bonus regime is a predicted revert
                uint256 jtEffAfter = s.jtEffectiveNAV + (collateralAfter - s.collateralNAV);
                uint256 utilAfter = RoycoTestMath.computeCoverageUtilization(collateralAfter, s.minCoverageWAD, jtEffAfter);
                if (utilAfter >= s.coverageLiquidationUtilizationWAD) _expect(p, SEL_JT_LIQ_BLOCKED);
            }
            stJtVault.mintShares(actor, assets);
            uint256 poolSenior0 = seniorTranche.balanceOf(address(balancerVault));
            vm.startPrank(actor);
            stJtVault.approve(address(juniorTranche), assets);
            try juniorTranche.deposit(toTrancheUnits(assets), actor) returns (uint256 gotShares) {
                _recordSuccess("jtDeposit");
                ghost_transferredIn[address(stJtVault)] += assets;
                _flag(gotShares == predShares, "jtDeposit minted shares diverge from the floor mirror");
                _recordTailDeployment(poolSenior0);
            } catch (bytes memory err) {
                _classify("jtDeposit", err, p);
            }
            vm.stopPrank();
            _syncAndVerify("post:jtDeposit");
        }
    }

    /// @notice A junior LP redeems shares, bounded by the coverage the market must retain
    function op_jtRedeem(uint256 _actorSeed, uint256 _shares) external {
        _recordCall("jtRedeem");
        address actor = jtActors[bound(_actorSeed, 0, jtActors.length - 1)];
        Snap memory s = _syncAndVerify("pre:jtRedeem");
        if (s.ok) {
            uint256 bal = juniorTranche.balanceOf(actor);
            // Uniform over the actor's holding, degraded to a single share on an empty balance
            uint256 shares = bound(_shares, 1, bal == 0 ? 1 : bal);
            _execJtRedeem(actor, shares, s);
            _syncAndVerify("post:jtRedeem");
        }
    }

    /// @notice A liquidity LP deposits pool tokens minted at fair value against a real quote leg
    function op_lptDeposit(uint256 _actorSeed, uint256 _quoteLeg) external {
        _recordCall("lptDeposit");
        address actor = lptActors[bound(_actorSeed, 0, lptActors.length - 1)];
        // Uniform over 1 to 1e6 whole quote tokens backing the minted pool tokens
        uint256 quoteLeg = bound(_quoteLeg, QUOTE_UNIT, QUOTE_UNIT * 1e6);
        // Mint the pool tokens before the sync so the committed marks already reflect the deeper pool
        uint256 bptAmt = _mintFairValueBpt(actor, quoteLeg);
        Snap memory s = _syncAndVerify("pre:lptDeposit");
        if (s.ok) {
            // The in-handler supply bound: any pool tokens the clamp strands with the actor are just an external holding
            bptAmt = _clampSupplySafeDeposit(
                bptAmt,
                _quoteLPTUnits(bptAmt),
                RoycoTestMath.getLiquidityProviderTrancheEffectiveNAV(s.lptRawNAV, s.lptOwnedSeniorTrancheShares, s.stEffectiveNAV, s.stSupply),
                s.lptSupply
            );
            Pred memory p;
            uint256 value = _quoteLPTUnits(bptAmt);
            uint256 navAt = RoycoTestMath.getLiquidityProviderTrancheEffectiveNAV(s.lptRawNAV, s.lptOwnedSeniorTrancheShares, s.stEffectiveNAV, s.stSupply);
            // A zero-value deposit prices to zero shares before the post-op delta requirement can fire
            if (value != 0 && _quoteLPTUnits(s.lptOwned + bptAmt) == s.lptRawNAV) _expect(p, SEL_INVALID_POST_OP);
            (uint256 predShares, bool mintPanics) = _mirrorMintShares(value, navAt, s.lptSupply);
            // The mint-dilution clamp's residual overflow cliff: past the supply-inflation point the mint itself must panic
            if (mintPanics) _expect(p, SEL_PANIC);
            else if (predShares == 0) _expect(p, SEL_ZERO_SHARES);
            uint256 poolSenior0 = seniorTranche.balanceOf(address(balancerVault));
            vm.startPrank(actor);
            bpt.approve(address(liquidityProviderTranche), bptAmt);
            try liquidityProviderTranche.deposit(toTrancheUnits(bptAmt), actor) returns (uint256 gotShares) {
                _recordSuccess("lptDeposit");
                ghost_transferredIn[address(bpt)] += bptAmt;
                _flag(gotShares == predShares, "lptDeposit minted shares diverge from the floor mirror");
                _recordTailDeployment(poolSenior0);
            } catch (bytes memory err) {
                _classify("lptDeposit", err, p);
            }
            vm.stopPrank();
            _syncAndVerify("post:lptDeposit");
        }
    }

    /// @notice A liquidity LP enters atomically with collateral underlying plus quote through the venue add
    function op_lptDepositMultiAsset(uint256 _actorSeed, uint256 _collateralAssets, uint256 _quote) external {
        _recordCall("lptDepositMultiAsset");
        address actor = lptActors[bound(_actorSeed, 0, lptActors.length - 1)];
        // Uniform over 1e-6 to 1e6 whole vault shares on the collateral leg and 1 to 1e6 quote tokens
        uint256 collateralAssets = bound(_collateralAssets, 1e12, 1e24);
        uint256 quoteAssets = bound(_quote, QUOTE_UNIT, QUOTE_UNIT * 1e6);
        Snap memory s = _syncAndVerify("pre:lptDepositMultiAsset");
        if (s.ok) {
            // The in-handler supply bound on the senior leg the venue add mints through the same share pricing
            collateralAssets = _clampSupplySafeDeposit(collateralAssets, _quoteCollateralUnits(collateralAssets), s.stEffectiveNAV, s.stSupply);
            _execLptDepositMultiAsset(actor, collateralAssets, quoteAssets, s);
            _syncAndVerify("post:lptDepositMultiAsset");
        }
    }

    /// @notice A liquidity LP redeems in kind, taking pool tokens plus its slice of any idle liquidity premium senior shares
    function op_lptRedeem(uint256 _actorSeed, uint256 _shares) external {
        _recordCall("lptRedeem");
        address actor = lptActors[bound(_actorSeed, 0, lptActors.length - 1)];
        Snap memory s = _syncAndVerify("pre:lptRedeem");
        if (s.ok) {
            uint256 bal = liquidityProviderTranche.balanceOf(actor);
            // Uniform over the actor's holding, degraded to a single share on an empty balance
            uint256 shares = bound(_shares, 1, bal == 0 ? 1 : bal);
            _execLptRedeem(actor, shares, s);
            _syncAndVerify("post:lptRedeem");
        }
    }

    /// @notice A liquidity LP exits atomically, unwinding the senior leg back to vault shares plus quote
    function op_lptRedeemMultiAsset(uint256 _actorSeed, uint256 _shares) external {
        _recordCall("lptRedeemMultiAsset");
        address actor = lptActors[bound(_actorSeed, 0, lptActors.length - 1)];
        Snap memory s = _syncAndVerify("pre:lptRedeemMultiAsset");
        if (s.ok) {
            uint256 bal = liquidityProviderTranche.balanceOf(actor);
            // Uniform over the actor's holding, degraded to a single share on an empty balance
            uint256 shares = bound(_shares, 1, bal == 0 ? 1 : bal);
            // One call in four probes the caller's quote slippage floor instead of exiting unbounded, so
            // both floor regimes stay exercised: a nonzero venue slice must reject an unmeetable floor,
            // and a zero venue slice silently skips the floor check (that bypass is pinned, not skipped)
            bool probeQuoteMin = _actorSeed % 4 == 3;
            _execLptRedeemMultiAsset(actor, shares, probeQuoteMin, s);
            _syncAndVerify("post:lptRedeemMultiAsset");
        }
    }

    /// @notice The keeper synchronizes accounting with no accompanying operation
    function op_sync() external {
        _recordCall("sync");
        _syncAndVerify("op:sync");
    }

    /// @notice The market operator attempts to deploy idle liquidity premium senior shares into the pool
    function op_reinvest(uint256 _stShares) external {
        _recordCall("reinvest");
        Snap memory s = _syncAndVerify("pre:reinvest");
        if (s.ok) {
            // Half the calls deploy everything, half deploy an arbitrary partial amount
            uint256 amount =
                _stShares % 2 == 0 ? type(uint256).max : bound(_stShares, 1, s.lptOwnedSeniorTrancheShares == 0 ? 1 : s.lptOwnedSeniorTrancheShares);
            uint256 poolSeniorBefore = seniorTranche.balanceOf(address(balancerVault));
            uint256 idleBefore = kernel.getState().lptOwnedSeniorTrancheShares;
            vm.prank(MARKET_REINVEST_LIQUIDITY_PREMIUM_ADMIN);
            try kernel.reinvestLiquidityPremium(amount) {
                _recordSuccess("reinvest");
                uint256 deployed = seniorTranche.balanceOf(address(balancerVault)) - poolSeniorBefore;
                ghost_liquidityPremiumSharesReinvested += deployed;
                ghost_stSharesDeployedSinceLastPriceCheck += deployed;
                _flag(
                    kernel.getState().lptOwnedSeniorTrancheShares == idleBefore - deployed,
                    "reinvest changed lptOwnedSeniorTrancheShares by more than the shares that reached the pool"
                );
            } catch (bytes memory err) {
                // The reinvestment path tolerates venue failures internally, so any revert is unpredicted
                Pred memory p;
                _classify("reinvest", err, p);
            }
            _syncAndVerify("post:reinvest");
        }
    }

    /// @notice Time passes and the price feed stays fresh, accruing premium weight without moving NAVs
    function op_warp(uint256 _seconds) external {
        _recordCall("warp");
        // Uniform over one second to thirty days, long enough to let fixed terms elapse
        uint256 secs = bound(_seconds, 1, 30 days);
        _warpAndRefreshFeed(secs);
        _syncAndVerify("post:warp");
    }

    /// @notice The shared senior and junior underlying rate moves by a bounded basis-point amount
    function op_stPnL(int256 _bps) external {
        _recordCall("stPnL");
        // Uniform over minus three to plus three percent per event, the realistic per-sync move
        int256 bps = bound(_bps, -300, 300);
        if (bps < 0) {
            ghost_uncoveredLossSinceLastCheck = true;
            ghost_jtLossSinceLastCheck = true;
            ghost_lptVenueLossSinceLastCheck = true;
        }
        applySTPnL(bps);
        _syncAndVerify("post:stPnL");
    }

    /// @notice An alias of the shared-rate move, kept as a distinct weighted action
    function op_jtPnL(int256 _bps) external {
        _recordCall("jtPnL");
        // Uniform over minus three to plus three percent per event
        int256 bps = bound(_bps, -300, 300);
        if (bps < 0) {
            ghost_uncoveredLossSinceLastCheck = true;
            ghost_jtLossSinceLastCheck = true;
            ghost_lptVenueLossSinceLastCheck = true;
        }
        applyJTPnL(bps);
        _syncAndVerify("post:jtPnL");
    }

    /// @notice The pool's quote leg moves by a bounded basis-point amount in both price stores
    function op_lptPnL(int256 _bps) external {
        _recordCall("lptPnL");
        // Uniform over minus three to plus three percent per event
        int256 bps = bound(_bps, -300, 300);
        if (bps < 0) ghost_lptVenueLossSinceLastCheck = true;
        applyLPTPnL(bps);
        _syncAndVerify("post:lptPnL");
    }

    /// @notice The accountant admin nudges one market parameter within a safe, bounded range
    function op_adminParamNudge(uint256 _paramSeed, uint256 _valueSeed) external {
        _recordCall("adminParamNudge");
        Snap memory s = _syncAndVerify("pre:adminParamNudge");
        if (s.ok) {
            // Uniform over the five nudgeable parameter families
            uint256 kind = bound(_paramSeed, 0, 4);
            vm.startPrank(ACCOUNTANT_ADMIN);
            if (kind == 0 && !IS_ZERO_LIQUIDITY_PROFILE) {
                // Uniform over two to eight percent minimum liquidity. The config guard admits a tightening only
                // while it stays within the live depth, so an inadmissible raise degrades to a non-worsening re-set
                uint64 targetMinLiquidity = uint64(bound(_valueSeed, 0.02e18, 0.08e18));
                uint64 currentMinLiquidity = uint64(accountant.getState().minLiquidityWAD);
                if (
                    targetMinLiquidity > currentMinLiquidity
                        && RoycoTestMath.computeLiquidityUtilization(s.stEffectiveNAV, targetMinLiquidity, s.lptRawNAV) > WAD
                ) targetMinLiquidity = currentMinLiquidity;
                accountant.setMinLiquidity(targetMinLiquidity);
            } else if (kind == 1) {
                // Uniform over ten to thirty percent minimum coverage, degraded identically when the raise would breach
                uint64 targetMinCoverage = uint64(bound(_valueSeed, 0.1e18, 0.3e18));
                uint64 currentMinCoverage = uint64(accountant.getState().minCoverageWAD);
                if (
                    targetMinCoverage > currentMinCoverage
                        && RoycoTestMath.computeCoverageUtilization(s.collateralNAV, targetMinCoverage, s.jtEffectiveNAV) > WAD
                ) targetMinCoverage = currentMinCoverage;
                accountant.setMinCoverage(targetMinCoverage);
            } else if (kind == 2) {
                // Uniform over one-and-a-half to eight liquidation coverage utilization. The config guard forbids
                // arming the regime by configuration, so a threshold at or below live utilization lifts to just above
                // it, and an unbounded live utilization keeps the current threshold (a non-move the guard admits)
                uint256 targetThreshold = bound(_valueSeed, 1.5e18, 8e18);
                if (targetThreshold <= s.coverageUtilizationWAD) {
                    targetThreshold =
                        s.coverageUtilizationWAD == type(uint256).max ? accountant.getState().coverageLiquidationUtilizationWAD : s.coverageUtilizationWAD + 1;
                }
                accountant.setLiquidationCoverageUtilization(targetThreshold);
            } else if (kind == 3 && !IS_ZERO_LIQUIDITY_PROFILE) {
                // One of three fixed yield-share cap pairs that always sum below one hundred percent
                uint256 pick = bound(_valueSeed, 0, 2);
                (uint64 j, uint64 l) =
                    pick == 0 ? (uint64(0.5e18), uint64(0.3e18)) : pick == 1 ? (uint64(0.6e18), uint64(0.4e18)) : (uint64(0.4e18), uint64(0.2e18));
                accountant.setMaxYieldShares(j, l);
                if (j > ghost_windowMaxJTShareWAD) ghost_windowMaxJTShareWAD = j;
                if (l > ghost_windowMaxLPTShareWAD) ghost_windowMaxLPTShareWAD = l;
            } else if (kind == 4) {
                // One of three fixed term durations, never zero so the fixed-term regime stays reachable
                uint256 pick = bound(_valueSeed, 0, 2);
                accountant.setFixedTermDuration(pick == 0 ? 1 hours : pick == 1 ? 3 days : 2 weeks);
            }
            vm.stopPrank();
            _recordSuccess("adminParamNudge");
            _syncAndVerify("post:adminParamNudge");
        }
    }

    /**
     * @notice An external participant interacts with the pool: quote donation, fair-value join, exact-in
     *         swaps in both directions, a partial removal of its own pool tokens, or a senior-share donation
     * @dev Every kind drifts pool composition without touching the kernel's ledgers, so the trailing verified
     *      sync re-prices the drift through the same two-step mark mirrors every other op is judged by. At the
     *      mock's pinned prices every exogenous flow conserves or adds pool value (swap flooring and fees stay
     *      in the pool), so no loss flag is armed here, and the executors assert exactly that conservation
     */
    function op_externalPoolOp(uint256 _kindSeed, uint256 _amount) external {
        _recordCall("externalPoolOp");
        // Uniform over one to ten thousand whole quote tokens for the quote-denominated kinds
        uint256 amount = bound(_amount, QUOTE_UNIT, QUOTE_UNIT * 10_000);
        uint256 kind = bound(_kindSeed, 0, 5);
        if (kind == 0) {
            // One-sided quote donation: drifts the pool composition and raises every pool mark
            quoteToken.mint(externalLp, amount);
            vm.startPrank(externalLp);
            quoteToken.approve(address(balancerVault), amount);
            balancerVault.injectPoolBalance(address(bpt), IERC20(address(quoteToken)), amount);
            vm.stopPrank();
            _recordSuccess("externalPoolOp");
            _recordSuccess("extQuoteDonation");
        } else if (kind == 1) {
            // Fair-value external join: an outside LP now owns pool tokens the kernel does not control
            _mintFairValueBpt(externalLp, amount);
            _recordSuccess("externalPoolOp");
            _recordSuccess("extFairJoin");
        } else if (kind == 2) {
            // Exact-in swap quote -> senior: the swapper takes senior shares out of the pool at the pinned rates
            quoteToken.mint(externalLp, amount);
            uint256 poolSeniorLeg = balancerVault.getPoolBalances(address(bpt))[stPoolTokenIndex];
            if (_execExternalSwapExactIn(IERC20(address(quoteToken)), IERC20(address(seniorTranche)), amount, poolSeniorLeg)) {
                _recordSuccess("externalPoolOp");
                _recordSuccess("extSwapQuoteToSenior");
            }
        } else if (kind == 3) {
            // Exact-in swap senior -> quote: the swapper's senior shares come from a real gated ST deposit
            uint256 bal = _ensureExternalSeniorShares();
            if (bal != 0) {
                uint256 amountIn = bound(_amount, 1, bal);
                uint256 poolQuoteLeg = balancerVault.getPoolBalances(address(bpt))[1 - stPoolTokenIndex];
                if (_execExternalSwapExactIn(IERC20(address(seniorTranche)), IERC20(address(quoteToken)), amountIn, poolQuoteLeg)) {
                    _recordSuccess("externalPoolOp");
                    _recordSuccess("extSwapSeniorToQuote");
                }
            }
        } else if (kind == 4) {
            // Partial removal: the external LP burns its OWN pool tokens, the kernel's ledger must be inert
            if (bpt.balanceOf(externalLp) == 0) _mintFairValueBpt(externalLp, amount);
            _execExternalPartialRemove(bound(_amount, 1, bpt.balanceOf(externalLp)));
            _recordSuccess("externalPoolOp");
            _recordSuccess("extPartialRemove");
        } else {
            // Senior-share donation: composition drift on the senior leg, sourced from a real gated ST deposit
            uint256 bal = _ensureExternalSeniorShares();
            if (bal != 0) {
                uint256 donate = bound(_amount, 1, bal);
                uint256 tvl0 = bptOracle.computeTVL();
                vm.startPrank(externalLp);
                seniorTranche.approve(address(balancerVault), donate);
                balancerVault.injectPoolBalance(address(bpt), IERC20(address(seniorTranche)), donate);
                vm.stopPrank();
                _flag(bptOracle.computeTVL() >= tvl0, "a senior-share donation lowered the pool's TVL");
                _recordSuccess("externalPoolOp");
                _recordSuccess("extSeniorDonation");
            }
        }
        _syncAndVerify("post:externalPoolOp");
    }

    // =============================
    // Aimed ops (deliberately steer the market into the hard-to-reach regimes)
    // =============================

    /// @notice Deposits exactly the advertised senior capacity so the gates land on their boundary
    function aimed_depositExactlyMaxST(uint256 _actorSeed) external {
        _recordCall("aimedDepositExactlyMaxST");
        address actor = stActors[bound(_actorSeed, 0, stActors.length - 1)];
        Snap memory s = _syncAndVerify("pre:aimedMaxST");
        if (s.ok) {
            uint256 maxAssets = toUint256(seniorTranche.maxDeposit(actor));
            if (maxAssets == 0) {
                // No capacity: a one-unit deposit must be rejected by one of the gates
                _execStDeposit(actor, 1e12, s);
            } else {
                // Overflow guard only, the boundary case stays exact whenever capacity is below the cap
                uint256 assets = maxAssets > 1e27 ? 1e27 : maxAssets;
                // The in-handler supply bound: only binds in the dust-NAV states where the boundary is meaningless anyway
                assets = _clampSupplySafeDeposit(assets, _quoteCollateralUnits(assets), s.stEffectiveNAV, s.stSupply);
                _execStDeposit(actor, assets, s);
            }
            _syncAndVerify("post:aimedMaxST");
        }
    }

    /// @notice Applies the closed-form shared-rate drop that pushes coverage utilization to liquidation
    function aimed_loseUntilLiquidation() external {
        _recordCall("aimedLoseUntilLiquidation");
        Snap memory s = _syncAndVerify("pre:aimedLiquidation");
        if (s.ok && s.stEffectiveNAV + s.jtEffectiveNAV > 0) {
            // Solve for the loss fraction f on the collateral NAV that lands coverage utilization on the
            // liquidation threshold L. With one shared rate the whole pool loses f, junior absorbs its own
            // loss plus coverage, so jtEffectiveNAV' = jtEffectiveNAV(1-f) - f*stEffectiveNAV and the
            // collateral NAV shrinks to (1-f)*E. Requiring E'*minCoverageWAD/jtEffectiveNAV' >= L and
            // isolating f gives f = (jtEffectiveNAV - E*C/L) / (stEffectiveNAV + jtEffectiveNAV - E*C/L)
            // with E = collateralNAV and C = minCoverageWAD
            uint256 ecl = s.collateralNAV.mulDiv(s.minCoverageWAD, s.coverageLiquidationUtilizationWAD);
            // Already at or past the threshold: the trailing verified sync realizes and counts the regime
            if (s.jtEffectiveNAV > ecl && s.coverageUtilizationWAD < s.coverageLiquidationUtilizationWAD) {
                uint256 fWAD = (s.jtEffectiveNAV - ecl).mulDiv(WAD, s.stEffectiveNAV + s.jtEffectiveNAV - ecl, Math.Rounding.Ceil) + 0.01e18;
                if (fWAD > 0.97e18) fWAD = 0.97e18;
                int256 bpsDrop = int256(fWAD / 1e14) + 1;
                ghost_uncoveredLossSinceLastCheck = true;
                ghost_jtLossSinceLastCheck = true;
                ghost_lptVenueLossSinceLastCheck = true;
                applySTPnL(-bpsDrop);
            }
            _syncAndVerify("post:aimedLiquidation");
        }
    }

    /// @notice Applies a drawdown small enough for junior to fully cover, driving the fixed-term entry
    function aimed_coveredDrawdown(uint256 _lossBps) external {
        _recordCall("aimedCoveredDrawdown");
        Snap memory s = _syncAndVerify("pre:aimedDrawdown");
        if (s.ok && s.stEffectiveNAV > 0 && s.jtEffectiveNAV > 0) {
            // A shared loss f stays fully covered while f*stEffectiveNAV <= jtEffectiveNAV(1-f), so the covered ceiling is
            // f < jtEffectiveNAV / (stEffectiveNAV + jtEffectiveNAV). Stay one percent under it and inside the three-percent op range
            uint256 fMaxBps = s.jtEffectiveNAV.mulDiv(10_000, s.stEffectiveNAV + s.jtEffectiveNAV);
            if (fMaxBps > 100) {
                // Uniform over one basis point to the covered ceiling capped at three percent
                uint256 cap = fMaxBps - 100 > 300 ? 300 : fMaxBps - 100;
                int256 bps = int256(bound(_lossBps, 1, cap));
                ghost_jtLossSinceLastCheck = true;
                applySTPnL(-bps);
            }
            _syncAndVerify("post:aimedDrawdown");
        }
    }

    /// @notice Flips the venue between clean adds and punitive slippage so idle liquidity premium senior shares actually accumulate
    function aimed_toggleVenueSlippage() external {
        _recordCall("toggleVenueSlippage");
        ghost_venueSlippageArmed = !ghost_venueSlippageArmed;
        setVenueSlippageMode(ghost_venueSlippageArmed);
        _recordSuccess("toggleVenueSlippage");
        _syncAndVerify("post:toggleSlippage");
    }

    /// @notice Every actor of one tranche redeems its advertised maximum, chasing the empty-tranche edges
    function aimed_fullExit(uint256 _trancheSeed) external {
        _recordCall("aimedFullExit");
        // Uniform over the three tranches
        uint256 t = bound(_trancheSeed, 0, 2);
        Snap memory s = _syncAndVerify("pre:aimedFullExit");
        if (s.ok) {
            if (t == 0) {
                for (uint256 i; i < stActors.length; ++i) {
                    uint256 shares = seniorTranche.maxRedeem(stActors[i]);
                    if (shares != 0) {
                        s = _refreshSnap();
                        _execStRedeem(stActors[i], shares, s);
                    }
                }
            } else if (t == 1) {
                for (uint256 i; i < jtActors.length; ++i) {
                    uint256 shares = juniorTranche.maxRedeem(jtActors[i]);
                    if (shares != 0) {
                        s = _refreshSnap();
                        _execJtRedeem(jtActors[i], shares, s);
                    }
                }
            } else {
                for (uint256 i; i < lptActors.length; ++i) {
                    uint256 shares = liquidityProviderTranche.maxRedeem(lptActors[i]);
                    if (shares != 0) {
                        s = _refreshSnap();
                        _execLptRedeem(lptActors[i], shares, s);
                    }
                }
            }
            if (seniorTranche.totalSupply() == 0 || juniorTranche.totalSupply() == 0 || liquidityProviderTranche.totalSupply() == 0) {
                ghost_zeroSupplyStatesReached++;
            }
            _syncAndVerify("post:aimedFullExit");
        }
    }

    /**
     * @notice The attacker's boundary-parking probe on the liquidity gate: redeem the advertised liquidity
     *         maximum so liquidityUtilizationWAD parks exactly at (or as close as rounding allows to) WAD,
     *         then push one more share through. Any depth-reducing redemption the enforced gate lets
     *         through must leave liquidityUtilizationWAD at or below WAD - the senior tranche's exit
     *         liquidity floor may never be broken by an exit sized off the market's own advertised maximum
     */
    function aimed_lptRedeemToLiquidityGateBoundary(uint256 _actorSeed) external {
        _recordCall("aimedLptRedeemToLiquidityGateBoundary");
        address actor = lptActors[bound(_actorSeed, 0, lptActors.length - 1)];
        Snap memory s = _syncAndVerify("pre:lptGateBoundary");
        if (!s.ok) return;

        // Park at the boundary: the advertised maximum is exactly the largest exit the gate may pass
        uint256 maxShares = liquidityProviderTranche.maxRedeem(actor);
        if (maxShares != 0) {
            bool enforced = !s.fixedTerm;
            uint256 balBefore = liquidityProviderTranche.balanceOf(actor);
            _execLptRedeem(actor, maxShares, s);
            bool redeemed = liquidityProviderTranche.balanceOf(actor) < balBefore;
            s = _syncAndVerify("boundary:lptGateBoundary");
            if (!s.ok) return;
            if (redeemed && enforced) {
                _flag(
                    RoycoTestMath.computeLiquidityUtilization(s.stEffectiveNAV, s.minLiquidityWAD, s.lptRawNAV) <= WAD,
                    "lptGateBoundary: the advertised maximum redemption left liquidityUtilizationWAD above WAD"
                );
            }
        }

        // The one-share probe past the boundary: the gate must reject it or the floor must still hold
        if (liquidityProviderTranche.balanceOf(actor) != 0) {
            bool enforced = !s.fixedTerm;
            uint256 balBefore = liquidityProviderTranche.balanceOf(actor);
            _execLptRedeem(actor, 1, s);
            bool redeemed = liquidityProviderTranche.balanceOf(actor) < balBefore;
            s = _syncAndVerify("probe:lptGateBoundary");
            if (!s.ok) return;
            if (redeemed && enforced) {
                _flag(
                    RoycoTestMath.computeLiquidityUtilization(s.stEffectiveNAV, s.minLiquidityWAD, s.lptRawNAV) <= WAD,
                    "lptGateBoundary: a one-share redemption past the boundary broke the senior liquidity floor"
                );
            }
        }
    }

    // =============================
    // Op executors (shared by the weighted and aimed ops)
    // =============================

    /// @dev Runs one senior deposit under an independently derived revert prediction
    function _execStDeposit(address _actor, uint256 _assets, Snap memory s) internal {
        Pred memory p;
        uint256 value = _quoteCollateralUnits(_assets);
        uint256 predShares;
        if (s.fixedTerm) {
            _expect(p, SEL_DISABLED_FT);
        } else {
            uint256 collateralAfter = _quoteCollateralUnits(s.collateralOwned + _assets);
            // A zero-value deposit prices to zero shares before the post-op delta requirement can fire
            if (value != 0 && collateralAfter == s.collateralNAV) _expect(p, SEL_INVALID_POST_OP);
            uint256 stEffAfter = s.stEffectiveNAV + (collateralAfter - s.collateralNAV);
            if (RoycoTestMath.computeCoverageUtilization(collateralAfter, s.minCoverageWAD, s.jtEffectiveNAV) > WAD) _expect(p, SEL_COVERAGE);
            if (RoycoTestMath.computeLiquidityUtilization(stEffAfter, s.minLiquidityWAD, s.lptRawNAV) > WAD) _expect(p, SEL_LIQUIDITY);
            bool mintPanics;
            (predShares, mintPanics) = _mirrorMintShares(value, s.stEffectiveNAV, s.stSupply);
            // The mint-dilution clamp's residual overflow cliff: past the supply-inflation point the mint itself must panic
            if (mintPanics) _expect(p, SEL_PANIC);
            else if (predShares == 0) _expect(p, SEL_ZERO_SHARES);
        }
        stJtVault.mintShares(_actor, _assets);
        uint256 poolSenior0 = seniorTranche.balanceOf(address(balancerVault));
        vm.startPrank(_actor);
        stJtVault.approve(address(seniorTranche), _assets);
        try seniorTranche.deposit(toTrancheUnits(_assets), _actor) returns (uint256 gotShares) {
            _recordSuccess("stDeposit");
            ghost_transferredIn[address(stJtVault)] += _assets;
            _flag(gotShares == predShares, "stDeposit minted shares diverge from the floor mirror");
            _recordTailDeployment(poolSenior0);
        } catch (bytes memory err) {
            _classify("stDeposit", err, p);
        }
        vm.stopPrank();
    }

    /// @dev Runs one senior redemption under an independently derived revert prediction
    function _execStRedeem(address _actor, uint256 _shares, Snap memory s) internal {
        Pred memory p;
        if (s.fixedTerm) {
            _expect(p, SEL_DISABLED_FT);
        } else if (s.stSupply == 0) {
            // Scaling a claim over a zero share supply divides by zero
            _expect(p, SEL_PANIC);
        } else {
            (uint256 collateralA, uint256 bonusNAV) = _mirrorSeniorRedeemClaims(s, _shares, s.stSupply);
            if (bonusNAV > 0) ghost_jtLossSinceLastCheck = true;
            uint256 collateralAfter = _quoteCollateralUnits(s.collateralOwned - collateralA);
            if (collateralAfter == s.collateralNAV) _expect(p, SEL_INVALID_POST_OP);
            if (_shares > seniorTranche.balanceOf(_actor)) _expect(p, SEL_ERC20_BALANCE);
        }
        uint256 outBefore = stJtVault.balanceOf(_actor);
        uint256 poolSenior0 = seniorTranche.balanceOf(address(balancerVault));
        vm.prank(_actor);
        try seniorTranche.redeem(_shares, _actor, _actor) {
            _recordSuccess("stRedeem");
            ghost_transferredOut[address(stJtVault)] += stJtVault.balanceOf(_actor) - outBefore;
            _recordTailDeployment(poolSenior0);
        } catch (bytes memory err) {
            _classify("stRedeem", err, p);
        }
    }

    /// @dev Runs one junior redemption under an independently derived revert prediction
    function _execJtRedeem(address _actor, uint256 _shares, Snap memory s) internal {
        Pred memory p;
        if (s.fixedTerm) {
            _expect(p, SEL_DISABLED_FT);
        } else if (s.jtSupply == 0) {
            _expect(p, SEL_PANIC);
        } else {
            // A junior claim is its effective NAV converted once to collateral assets (the old cross-claim
            // decomposition mirrors a deleted src path and describes an unrepresentable two-legged state)
            // _scaleAssetClaims divides by the effective supply (jtSupply + VIRTUAL_SHARES); a dust redemption's
            // slice floors smaller, so the requote sees no collateral NAV move and the predictor foresees INVALID_POST_OP
            uint256 effJtSupply = s.jtSupply + RoycoTestMath.VIRTUAL_SHARES;
            uint256 collateralA = s.jtEffectiveNAV == 0 ? 0 : _quoteNAVToCollateralUnits(s.jtEffectiveNAV).mulDiv(_shares, effJtSupply);
            uint256 collateralAfter = _quoteCollateralUnits(s.collateralOwned - collateralA);
            uint256 totalRedeemed = s.collateralNAV - collateralAfter;
            if (totalRedeemed == 0) _expect(p, SEL_INVALID_POST_OP);
            uint256 jtEffAfter = s.jtEffectiveNAV - totalRedeemed;
            if (RoycoTestMath.computeCoverageUtilization(collateralAfter, s.minCoverageWAD, jtEffAfter) > WAD) _expect(p, SEL_COVERAGE);
            if (_shares > juniorTranche.balanceOf(_actor)) _expect(p, SEL_ERC20_BALANCE);
        }
        uint256 outBefore = stJtVault.balanceOf(_actor);
        uint256 poolSenior0 = seniorTranche.balanceOf(address(balancerVault));
        vm.prank(_actor);
        try juniorTranche.redeem(_shares, _actor, _actor) {
            _recordSuccess("jtRedeem");
            ghost_transferredOut[address(stJtVault)] += stJtVault.balanceOf(_actor) - outBefore;
            _recordTailDeployment(poolSenior0);
            // The JT_REDEMPTION postOp IL scaling is deleted: a junior exit only settles in PERPETUAL where the
            // ledger is already zero, so a successful redeem must leave the committed value untouched
            _flag(toUint256(accountant.getState().lastJTImpermanentLoss) == ghost_jtImpermanentLossReplay, "jtRedeem moved the impermanent-loss ledger");
        } catch (bytes memory err) {
            _classify("jtRedeem", err, p);
        }
    }

    /// @dev Runs one in-kind liquidity redemption under an independently derived revert prediction
    function _execLptRedeem(address _actor, uint256 _shares, Snap memory s) internal {
        Pred memory p;
        if (s.fixedTerm) {
            _expect(p, SEL_DISABLED_FT);
        } else if (s.lptSupply == 0) {
            // A no-LPT-supply market, every LPT balance is zero, so a redeem of any size either panics on the
            // zero-supply valuation or computes an all-zero claim that clears the post-op no-op guard and
            // reaches the share burn, which reverts on the redeemer's empty LPT balance
            _expect(p, SEL_PANIC);
            _expect(p, SEL_INVALID_POST_OP);
            _expect(p, SEL_ERC20_BALANCE);
        } else {
            uint256 lptClaimUnits = s.lptRawNAV == 0 ? 0 : _quoteNAVToLPTUnits(s.lptRawNAV);
            // _scaleAssetClaims divides the BPT slice by the effective supply (lptSupply + VIRTUAL_SHARES)
            uint256 userLt = lptClaimUnits.mulDiv(_shares, s.lptSupply + RoycoTestMath.VIRTUAL_SHARES);
            uint256 lptRawAfter = _quoteLPTUnits(s.lptOwned - userLt);
            // A dust in-kind redeem whose BPT and idle-premium slices floor to zero at the src's SHARE
            // granularity trips the no-op guard. This NAV-granular mirror's lptRawAfter cannot resolve that
            // boundary reliably, so accept the revert as a valid outcome. A value-moving redeem simply succeeds.
            _expect(p, SEL_INVALID_POST_OP);
            // The liquidity gate is enforced on every LPT redemption, including once the liquidation coverage threshold is breached
            if (RoycoTestMath.computeLiquidityUtilization(s.stEffectiveNAV, s.minLiquidityWAD, lptRawAfter) > WAD) _expect(p, SEL_LIQUIDITY);
            if (_shares > liquidityProviderTranche.balanceOf(_actor)) _expect(p, SEL_ERC20_BALANCE);
        }
        uint256 bptBefore = bpt.balanceOf(_actor);
        uint256 idleBefore = seniorTranche.balanceOf(_actor);
        uint256 poolSenior0 = seniorTranche.balanceOf(address(balancerVault));
        vm.prank(_actor);
        try liquidityProviderTranche.redeem(_shares, _actor, _actor) {
            _recordSuccess("lptRedeem");
            ghost_transferredOut[address(bpt)] += bpt.balanceOf(_actor) - bptBefore;
            ghost_idlePremiumSeniorSharesPaidToRedeemers += seniorTranche.balanceOf(_actor) - idleBefore;
            _recordTailDeployment(poolSenior0);
        } catch (bytes memory err) {
            _classify("lptRedeem", err, p);
        }
    }

    /// @notice The multi-asset deposit's revert prediction, callable only by the handler itself
    /// @dev An external self-call (the handler's established frame-splitting pattern) so the venue-add
    ///      mirror's frame never shares stack with the execution body's reconciliation locals
    function runLptDepositMultiAssetPrediction(Snap memory s, uint256 _collateralAssets, uint256 _quoteAssets) external view returns (Pred memory p) {
        require(msg.sender == address(this), "only self");
        if (s.fixedTerm && _collateralAssets > 0) {
            _expect(p, SEL_DISABLED_FT);
        } else {
            VenueAdd memory v = _mirrorVenueAdd(s, _collateralAssets, _quoteAssets);
            // The residual overflow cliff on the senior leg: past the supply-inflation point the ST mint panics
            if (v.stMintPanics) _expect(p, SEL_PANIC);
            if (_collateralAssets > 0 && !v.stMintPanics && v.stSharesMinted == 0) _expect(p, SEL_ZERO_SHARES);
            if (v.valueAllocated == 0 || v.lptRawAfter <= s.lptRawNAV) _expect(p, SEL_INVALID_POST_OP);
            {
                uint256 navAt = RoycoTestMath.getLiquidityProviderTrancheEffectiveNAV(s.lptRawNAV, s.lptOwnedSeniorTrancheShares, s.stEffectiveNAV, s.stSupply);
                (uint256 predLptShares, bool lptMintPanics) = _mirrorMintShares(v.valueAllocated, navAt, s.lptSupply);
                if (lptMintPanics) _expect(p, SEL_PANIC);
                else if (predLptShares == 0) _expect(p, SEL_ZERO_SHARES);
            }
            if (_collateralAssets > 0) {
                uint256 collateralAfter = _quoteCollateralUnits(s.collateralOwned + _collateralAssets);
                uint256 stEffAfter = s.stEffectiveNAV + (collateralAfter - s.collateralNAV);
                if (RoycoTestMath.computeCoverageUtilization(collateralAfter, s.minCoverageWAD, s.jtEffectiveNAV) > WAD) {
                    _expect(p, SEL_COVERAGE);
                }
                if (RoycoTestMath.computeLiquidityUtilization(stEffAfter, s.minLiquidityWAD, v.lptRawAfter) > WAD) _expect(p, SEL_LIQUIDITY);
            }
        }
    }

    /// @dev Runs one multi-asset liquidity deposit under a full mirror of the mock venue's pricing
    function _execLptDepositMultiAsset(address _actor, uint256 _collateralAssets, uint256 _quoteAssets, Snap memory s) internal {
        Pred memory p = this.runLptDepositMultiAssetPrediction(s, _collateralAssets, _quoteAssets);
        stJtVault.mintShares(_actor, _collateralAssets);
        quoteToken.mint(_actor, _quoteAssets);
        TokenFlows memory f = _snapTokenFlows();
        uint256 idleLedgerBefore = kernel.getState().lptOwnedSeniorTrancheShares;
        vm.startPrank(_actor);
        stJtVault.approve(address(liquidityProviderTranche), _collateralAssets);
        quoteToken.approve(address(liquidityProviderTranche), _quoteAssets);
        try liquidityProviderTranche.depositMultiAsset(_collateralAssets, _quoteAssets, 0, _actor) {
            _recordSuccess("lptDepositMultiAsset");
            ghost_transferredIn[address(stJtVault)] += _collateralAssets;
            // The settled op's tail deploys the entire idle premium pile into the pool, so the idle ledger
            // may fall by exactly the deployment and never rise (the same-block sync stages no new premium)
            uint256 idleLedgerAfter = kernel.getState().lptOwnedSeniorTrancheShares;
            _flag(idleLedgerAfter <= idleLedgerBefore, "lptDepositMultiAsset: a deposit grew the idle liquidity premium ledger");
            uint256 idleDeployed = idleLedgerBefore > idleLedgerAfter ? idleLedgerBefore - idleLedgerAfter : 0;
            ghost_liquidityPremiumSharesReinvested += idleDeployed;
            ghost_stSharesDeployedSinceLastPriceCheck += idleDeployed;
            // Reconcile the venue's ACTUAL token movements, independently of the pricing mirror above,
            // so a pricing bug shared by the mock venue and its mirror still surfaces as a token flow
            // that does not balance. A multi-asset deposit moves value one way only: the quote leg must
            // land in the pool in full, every senior share the deposit minted plus the tail's deployed
            // idle pile must land in the pool (none stranded with the kernel or the depositor), and every
            // pool token the add minted must sit in kernel custody
            _flag(
                quoteToken.balanceOf(address(balancerVault)) == f.venueQuote0 + _quoteAssets,
                "lptDepositMultiAsset: the deposited quote leg did not land in the pool in full"
            );
            _flag(
                seniorTranche.totalSupply() + f.venueSenior0 + idleDeployed == f.stSupply0 + seniorTranche.balanceOf(address(balancerVault)),
                "lptDepositMultiAsset: minted senior shares plus the deployed idle pile do not reconcile with the pool's senior inflow"
            );
            _flag(
                bpt.balanceOf(address(kernel)) + f.bptSupply0 == f.kernelBpt0 + bpt.totalSupply(),
                "lptDepositMultiAsset: pool tokens minted by the add do not reconcile with the kernel's custody"
            );
        } catch (bytes memory err) {
            _classify("lptDepositMultiAsset", err, p);
        }
        vm.stopPrank();
    }

    /**
     * @dev Runs one multi-asset liquidity redemption under a full mirror of the proportional removal.
     *      With _probeQuoteMin set, the call carries a quote floor one wei above the venue's guaranteed
     *      proportional output, an amount the redeemer can never receive, so an honestly enforced
     *      slippage bound must reject the call. The removal runs unconditionally (a zero venue slice
     *      removes zero units and outputs zeros), and its per-token floor check fires before the senior
     *      unwind and every post-op gate on every exit. The one step ahead of it is the LPT leg's own
     *      share burn, so a redeemer without the shares fails on the balance before the floor can reject
     */
    function _execLptRedeemMultiAsset(address _actor, uint256 _shares, bool _probeQuoteMin, Snap memory s) internal {
        Pred memory p;
        uint256 minQuoteOut;
        bool probeMustRevert;
        // The redeemer's idle premium slice, mirrored exactly (same floor over the same effective supply as
        // production's _scaleAssetClaims), so the ledger's total move splits into the slice unwound for the
        // redeemer and the tail's deployment of the remaining pile
        uint256 predIdleSlice;
        if (s.fixedTerm) {
            _expect(p, SEL_DISABLED_FT);
        } else if (s.lptSupply == 0 || s.stSupply == 0) {
            // A degenerate market with no senior or LPT supply, a multi-asset exit either divides by zero in the
            // senior valuation (Panic) or computes an all-zero claim that clears the post-op no-op guard and
            // reaches the share burn, which reverts on the redeemer's empty LPT balance. None of these settle the exit
            _expect(p, SEL_PANIC);
            _expect(p, SEL_INVALID_POST_OP);
            _expect(p, SEL_ERC20_BALANCE);
        } else {
            RemovalMirror memory r = _mirrorVenueRemoval(s, _shares);
            predIdleSlice = s.lptOwnedSeniorTrancheShares.mulDiv(_shares, s.lptSupply + RoycoTestMath.VIRTUAL_SHARES);
            if (r.bonusNAV > 0) ghost_jtLossSinceLastCheck = true;
            // A redemption legitimately hits the no-op-exit guard (INVALID_POST_OP_STATE, RoycoDayAccountant.sol:263)
            // whenever its BPT and idle-premium slices floor to zero at the src's SHARE granularity. This
            // NAV-granular removal mirror cannot resolve that dust boundary reliably (its computeTVL-based
            // lptRawAfter rounds differently than the committed mark), so accept the revert as a valid outcome for
            // every multi-asset redeem. A redemption that moves real value simply succeeds instead.
            _expect(p, SEL_INVALID_POST_OP);
            // The liquidity gate is enforced on every LPT redemption, including during a liquidation breach: the multi-asset
            // exit relaxes the floor by unwinding senior depth (reflected in stEffAfter) but never waives it. src judges
            // the gate at its committed two-step mark (queryLPTAssetOracle floors the price of one whole LPT asset, then
            // convertLPTAssetsToValue floors the ledger amount at that quantized price), which can sit up to one quote-wei
            // of NAV (WAD / QUOTE_UNIT, also dominating the unit-price floor's lptOwned / LPT_UNIT loss and the senior
            // rate's post-redeem drift) below this mirror's NAV-granular r.lptRawAfter, and the bonusNAV requote floors
            // can overstate stEffAfter by a couple of NAV wei. This mirror cannot resolve that quantization band reliably,
            // so predict the gate at the band's pessimistic inputs: utilization <= WAD there proves src cannot fire and the
            // prediction stays strict, past WAD there both a settle and the gate are valid outcomes (success is always accepted)
            uint256 stEffAfter = s.stEffectiveNAV - (r.totalRedeemed - r.bonusNAV);
            uint256 markQuantBand = WAD / QUOTE_UNIT;
            uint256 quantizedMarkFloor = r.lptRawAfter > markQuantBand ? r.lptRawAfter - markQuantBand : 0;
            if (RoycoTestMath.computeLiquidityUtilization(stEffAfter + (r.bonusNAV == 0 ? 0 : 2), s.minLiquidityWAD, quantizedMarkFloor) > WAD) {
                _expect(p, SEL_LIQUIDITY);
            }
            if (_shares > liquidityProviderTranche.balanceOf(_actor)) _expect(p, SEL_ERC20_BALANCE);
            if (_probeQuoteMin) {
                // The unmeetable floor: one wei above the proportional removal's guaranteed quote output
                // The probe must revert and the exit must not settle: the removal always runs, so either its
                // quote-floor check rejects the unmeetable minimum (AMOUNT_OUT_BELOW_MIN), or a dust slice
                // whose NAV move floors to zero trips the post-op no-op guard (INVALID_POST_OP_STATE) before
                // the floor check runs. Narrow to exactly those rejections, a success or any other
                // revert is a recorded violation
                minQuoteOut = r.quoteOut + 1;
                Pred memory onlyRevert;
                p = onlyRevert;
                _expect(p, SEL_AMOUNT_OUT_BELOW_MIN);
                _expect(p, SEL_INVALID_POST_OP);
                // The LPT leg's share burn precedes the removal, so a redeemer without the shares (the
                // empty-balance actor degraded to a single share) fails on the balance before the armed floor
                if (_shares > liquidityProviderTranche.balanceOf(_actor)) _expect(p, SEL_ERC20_BALANCE);
                probeMustRevert = true;
            }
        }
        TokenFlows memory f = _snapTokenFlows();
        uint256 vaultSharesBefore = stJtVault.balanceOf(_actor);
        uint256 quoteBefore = quoteToken.balanceOf(_actor);
        uint256 idleLedgerBefore = kernel.getState().lptOwnedSeniorTrancheShares;
        vm.prank(_actor);
        try liquidityProviderTranche.redeemMultiAsset(_shares, 0, minQuoteOut, _actor, _actor) {
            // A caller's slippage floor is a postcondition: an exit that cannot pay it must not settle
            _flag(!probeMustRevert, "lptRedeemMultiAsset: the venue removal accepted a quote floor above its guaranteed output");
            _recordSuccess("lptRedeemMultiAsset");
            ghost_transferredOut[address(stJtVault)] += stJtVault.balanceOf(_actor) - vaultSharesBefore;
            ghost_transferredOut[address(quoteToken)] += quoteToken.balanceOf(_actor) - quoteBefore;
            // The idle ledger moves twice in a settled exit: the redeemer's slice is unwound on its behalf
            // in the ST leg, then the tail deploys the remaining pile into the pool. The slice mirror above
            // is exact, so the ledger's total move splits into exactly those two parts
            uint256 idleLedgerAfter = kernel.getState().lptOwnedSeniorTrancheShares;
            _flag(idleLedgerAfter <= idleLedgerBefore, "lptRedeemMultiAsset: a redemption grew the idle liquidity premium ledger");
            uint256 idleUnwound = idleLedgerBefore > idleLedgerAfter ? idleLedgerBefore - idleLedgerAfter : 0;
            _flag(predIdleSlice <= idleUnwound, "lptRedeemMultiAsset: the idle ledger moved by less than the redeemer's mirrored slice");
            uint256 idleDeployed = idleUnwound > predIdleSlice ? idleUnwound - predIdleSlice : 0;
            ghost_idlePremiumSeniorSharesPaidToRedeemers += idleUnwound - idleDeployed;
            ghost_liquidityPremiumSharesReinvested += idleDeployed;
            ghost_stSharesDeployedSinceLastPriceCheck += idleDeployed;
            // Reconcile the venue's ACTUAL token movements, independently of the pricing mirror above,
            // so a pricing bug shared by the mock venue and its mirror still surfaces as a token flow
            // that does not balance. Written additively so a flow moving the wrong way fails the check
            // instead of underflowing: the pool's quote outflow must all land with the redeemer, every
            // senior share pulled from the pool or the idle pile must be burned (none parked with the
            // kernel), and the burned pool tokens must come exclusively from the kernel's custody
            _flag(
                quoteToken.balanceOf(address(balancerVault)) + quoteToken.balanceOf(_actor) == f.venueQuote0 + quoteBefore,
                "lptRedeemMultiAsset: the pool's quote outflow does not reconcile with the redeemer's quote gain"
            );
            _flag(
                seniorTranche.totalSupply() + f.venueSenior0 + idleUnwound == f.stSupply0 + seniorTranche.balanceOf(address(balancerVault)),
                "lptRedeemMultiAsset: burned senior shares do not reconcile with the pool withdrawal plus the idle slice"
            );
            _flag(
                bpt.totalSupply() + f.kernelBpt0 == f.bptSupply0 + bpt.balanceOf(address(kernel)),
                "lptRedeemMultiAsset: burned pool tokens do not reconcile with the kernel's custody outflow"
            );
        } catch (bytes memory err) {
            _classify("lptRedeemMultiAsset", err, p);
        }
    }

    // =============================
    // Venue mirrors (exact reproductions of the mock venue's pricing for gate prediction). Because the
    // mirror and the mock share their pricing formulas, the multi-asset executors additionally reconcile
    // the venue's ACTUAL token transfers (balance and supply deltas) after every successful op, so a
    // pricing defect common to both sides still surfaces as a token flow that does not balance
    // =============================

    /// @dev Token balances captured around a multi-asset op so its actual transfers can be reconciled
    ///      independently of the pricing mirror
    struct TokenFlows {
        uint256 venueQuote0;
        uint256 venueSenior0;
        uint256 stSupply0;
        uint256 kernelBpt0;
        uint256 bptSupply0;
    }

    /// @dev Captures the balances the venue-flow reconciliation compares against after a multi-asset op
    function _snapTokenFlows() internal view returns (TokenFlows memory f) {
        f.venueQuote0 = quoteToken.balanceOf(address(balancerVault));
        f.venueSenior0 = seniorTranche.balanceOf(address(balancerVault));
        f.stSupply0 = seniorTranche.totalSupply();
        f.kernelBpt0 = bpt.balanceOf(address(kernel));
        f.bptSupply0 = bpt.totalSupply();
    }

    /// @dev Everything the multi-asset deposit prediction needs about the venue add's outcome
    struct VenueAdd {
        uint256 stSharesMinted;
        bool stMintPanics;
        uint256 bptOut;
        uint256 lptRawAfter;
        uint256 valueAllocated;
    }

    /// @dev Mirrors the unbalanced add: fair value at the vault's prices, the armed haircut, the oracle re-mark
    function _mirrorVenueAdd(Snap memory s, uint256 _stAssets, uint256 _quoteAssets) internal view returns (VenueAdd memory v) {
        uint256 rate = _mirrorSeniorRate(s.stEffectiveNAV, s.stSupply);
        if (_stAssets != 0) (v.stSharesMinted, v.stMintPanics) = _mirrorMintShares(_quoteCollateralUnits(_stAssets), s.stEffectiveNAV, s.stSupply);
        uint256[2] memory balances = balancerVault.getPoolBalances(address(bpt));
        uint256 stBal = balances[stPoolTokenIndex];
        uint256 qBal = balances[1 - stPoolTokenIndex];
        uint256 vaultQuotePrice = balancerVault.getTokenPriceWAD(address(quoteToken));
        uint256 valueIn = v.stSharesMinted.mulDiv(rate, WAD) + _quoteAssets.mulDiv(vaultQuotePrice, QUOTE_UNIT);
        uint256 poolValue = stBal.mulDiv(rate, WAD) + qBal.mulDiv(vaultQuotePrice, QUOTE_UNIT);
        uint256 bptSupply = bpt.totalSupply();
        v.bptOut = (bptSupply == 0 || poolValue == 0) ? valueIn : valueIn.mulDiv(bptSupply, poolValue);
        v.bptOut = (v.bptOut * (10_000 - (ghost_venueSlippageArmed ? VENUE_SLIPPAGE_MODE_FEE_BPS : 0))) / 10_000;
        // The oracle marks the post-add pool at its own quote price with the senior leg at the pinned rate
        uint256 oracleQuotePrice = bptOracle.getPriceWAD(address(quoteToken));
        uint256 tvlAfter = (stBal + v.stSharesMinted).mulDiv(rate, WAD) + (qBal + _quoteAssets).mulDiv(oracleQuotePrice, QUOTE_UNIT);
        uint256 supplyAfter = bptSupply + v.bptOut;
        v.lptRawAfter = supplyAfter == 0 ? 0 : (s.lptOwned + v.bptOut).mulDiv(tvlAfter, supplyAfter);
        v.valueAllocated = supplyAfter == 0 ? 0 : v.bptOut.mulDiv(tvlAfter, supplyAfter);
    }

    /// @dev Everything the multi-asset redemption prediction needs about the proportional removal's outcome
    struct RemovalMirror {
        uint256 lptRawAfter;
        uint256 totalRedeemed;
        uint256 bonusNAV;
        /// @dev The redeemer's pool-token slice, zero means the kernel skips the removal (and its floors) entirely
        uint256 venueLptUnits;
        /// @dev The quote leg the proportional removal pays the receiver, the reference for the quote-floor probe
        uint256 quoteOut;
    }

    /// @dev Mirrors the proportional removal, the senior unwind, and the exit bonus for gate prediction
    function _mirrorVenueRemoval(Snap memory s, uint256 _shares) internal view returns (RemovalMirror memory r) {
        uint256 lptClaimUnits = s.lptRawNAV == 0 ? 0 : _quoteNAVToLPTUnits(s.lptRawNAV);
        // _scaleAssetClaims divides both the BPT slice and the idle-premium-share slice by the effective supply
        uint256 effLptSupply = s.lptSupply + RoycoTestMath.VIRTUAL_SHARES;
        uint256 userLt = lptClaimUnits.mulDiv(_shares, effLptSupply);
        r.venueLptUnits = userLt;
        uint256 idleSlice = s.lptOwnedSeniorTrancheShares.mulDiv(_shares, effLptSupply);
        uint256[2] memory balances = balancerVault.getPoolBalances(address(bpt));
        uint256 bptSupply = bpt.totalSupply();
        uint256 stOut = balances[stPoolTokenIndex].mulDiv(userLt, bptSupply);
        uint256 qOut = balances[1 - stPoolTokenIndex].mulDiv(userLt, bptSupply);
        r.quoteOut = qOut;
        {
            uint256 rate = _mirrorSeniorRate(s.stEffectiveNAV, s.stSupply);
            uint256 oracleQuotePrice = bptOracle.getPriceWAD(address(quoteToken));
            uint256 tvlAfter =
                (balances[stPoolTokenIndex] - stOut).mulDiv(rate, WAD) + (balances[1 - stPoolTokenIndex] - qOut).mulDiv(oracleQuotePrice, QUOTE_UNIT);
            uint256 supplyAfter = bptSupply - userLt;
            r.lptRawAfter = supplyAfter == 0 ? 0 : (s.lptOwned - userLt).mulDiv(tvlAfter, supplyAfter);
        }
        // The redeemer's senior shares come from the pool withdrawal plus its idle liquidity premium slice
        uint256 sToRedeem = stOut + idleSlice;
        (uint256 collateralA, uint256 bonusNAV) = _mirrorSeniorRedeemClaims(s, sToRedeem, s.stSupply);
        r.bonusNAV = bonusNAV;
        uint256 collateralAfter = _quoteCollateralUnits(s.collateralOwned - collateralA);
        r.totalRedeemed = s.collateralNAV - collateralAfter;
    }

    /// @dev Mirrors a senior redemption's asset claims (the effective NAV converted once, scaled, plus any liquidation exit bonus)
    function _mirrorSeniorRedeemClaims(Snap memory s, uint256 _shares, uint256 _totalShares) internal view returns (uint256 collateralA, uint256 bonusNAV) {
        // A senior claim is its effective NAV converted once to collateral assets. Production's
        // _scaleAssetClaims divides every claim field by the effective supply (_totalShares +
        // VIRTUAL_SHARES). Mirroring the offset is load-bearing for the redeem revert prediction: a
        // wei-scale redemption's slice floors smaller here, so s.collateralOwned - collateralA re-quotes to
        // an unchanged collateral NAV and the predictor correctly foresees the accountant's
        // INVALID_POST_OP no-op-exit guard (totalRedemptionNAV == 0)
        uint256 effTotalShares = _totalShares + RoycoTestMath.VIRTUAL_SHARES;
        collateralA = s.stEffectiveNAV == 0 ? 0 : _quoteNAVToCollateralUnits(s.stEffectiveNAV).mulDiv(_shares, effTotalShares);
        if (s.coverageUtilizationWAD >= s.coverageLiquidationUtilizationWAD) {
            uint256 navSlice = s.stEffectiveNAV.mulDiv(_shares, effTotalShares);
            bonusNAV = RoycoTestMath.seniorTrancheSelfLiquidationBonus(
                RoycoTestMath.SeniorTrancheSelfLiquidationBonusInputs({
                    stEffectiveNAV: s.stEffectiveNAV,
                    jtEffectiveNAV: s.jtEffectiveNAV,
                    coverageUtilizationWAD: s.coverageUtilizationWAD,
                    coverageLiquidationUtilizationWAD: s.coverageLiquidationUtilizationWAD,
                    bonusWAD: s.bonusWAD,
                    userClaimNAV: navSlice
                })
            );
            // The bonus is one more collateral leg on the claim, sourced from JT effective NAV by the post-op sync
            if (bonusNAV != 0) collateralA += _quoteNAVToCollateralUnits(bonusNAV);
        }
    }

    // =============================
    // The verified sync (runs before and after every op)
    // =============================

    /// @dev Pre-sync reads packaged for the verification pass
    struct SyncCtx {
        uint256 collateralNew;
        uint256 stSupply0;
        uint256 jtSupply0;
        uint256 lptSupply0;
        uint256 lptOwnedSeniorTrancheShares0;
        uint256 poolSenior0;
        uint256 twJT;
        uint256 twLPT;
        uint256 elapsedPrem;
        bool firstAccrual;
        bool wasBreached;
        MarketState state0;
        bool mirrorOk;
        RoycoTestMath.SyncOutputs w;
    }

    /**
     * @dev Syncs the market as the keeper and verifies the entire outcome against independent mirrors:
     *      the committed NAVs against the tranche accounting sync recomputation, the share mints against
     *      the fee and liquidity premium share mint floors, the lptOwnedSeniorTrancheShares ledger against
     *      the pool's own balance movement, the accrual window
     *      against the pinned model constants, the committed pool mark against a manual re-pricing, and
     *      the three share prices against their high-water marks outside sanctioned loss events
     */
    function _syncAndVerify(string memory _label) internal returns (Snap memory s) {
        IRoycoDayAccountant.RoycoDayAccountantState memory a0 = accountant.getState();
        IRoycoDayKernel.RoycoDayKernelState memory k0 = kernel.getState();
        SyncCtx memory c;
        c.stSupply0 = seniorTranche.totalSupply();
        c.jtSupply0 = juniorTranche.totalSupply();
        c.lptSupply0 = liquidityProviderTranche.totalSupply();
        c.lptOwnedSeniorTrancheShares0 = k0.lptOwnedSeniorTrancheShares;
        c.poolSenior0 = seniorTranche.balanceOf(address(balancerVault));
        c.state0 = a0.lastMarketState;
        c.wasBreached = RoycoTestMath.computeCoverageUtilization(toUint256(a0.lastCollateralNAV), a0.minCoverageWAD, toUint256(a0.lastJTEffectiveNAV))
            >= a0.coverageLiquidationUtilizationWAD;

        // Recompute the premium accrual window exactly as the accountant will, off the pinned model
        if (a0.lastYieldShareAccrualTimestamp == 0) {
            c.firstAccrual = true;
        } else {
            uint256 elapsedAcc = block.timestamp - uint256(a0.lastYieldShareAccrualTimestamp);
            c.twJT = uint256(a0.twJTYieldShareAccruedWAD) + Math.min(JT_PINNED_SHARE_WAD, a0.maxJTYieldShareWAD) * elapsedAcc;
            c.twLPT = uint256(a0.twLPTYieldShareAccruedWAD) + Math.min(LPT_PINNED_SHARE_WAD, a0.maxLPTYieldShareWAD) * elapsedAcc;
            c.elapsedPrem = block.timestamp - uint256(a0.lastPremiumPaymentTimestamp);
        }

        // The sync itself: it must always succeed while the oracle is healthy
        vm.prank(SYNC_OPERATOR);
        try kernel.syncTrancheAccounting() {
            ghost_syncCount++;
        } catch {
            _flag(false, string.concat(_label, ": syncTrancheAccounting reverted on a healthy market"));
            s.ok = false;
            return s;
        }

        // Quote the collateral mark after the sync so the freshly initialized rate cache prices it exactly as
        // the sync did (the owned amount itself cannot move during a sync)
        c.collateralNew = _quoteCollateralUnits(toUint256(k0.totalCollateralAssets));

        // Recompute the full tranche accounting sync from the committed checkpoint and this block's fresh mark
        RoycoTestMath.SyncInputs memory win = RoycoTestMath.SyncInputs({
            collateralNAVLast: toUint256(a0.lastCollateralNAV),
            stEffectiveNAVLast: toUint256(a0.lastSTEffectiveNAV),
            jtEffectiveNAVLast: toUint256(a0.lastJTEffectiveNAV),
            jtImpermanentLossLast: toUint256(a0.lastJTImpermanentLoss),
            marketStateLast: c.state0 == MarketState.PERPETUAL ? RoycoTestMath.MarketState.PERPETUAL : RoycoTestMath.MarketState.FIXED_TERM,
            fixedTermEndTimestampLast: uint256(a0.fixedTermEndTimestamp),
            collateralNAVDelta: int256(c.collateralNew) - int256(toUint256(a0.lastCollateralNAV)),
            lptRawNAVNew: toUint256(a0.lastLPTRawNAV),
            jtTwYieldShareAccrual: c.twJT,
            lptTwYieldShareAccrual: c.twLPT,
            elapsedSincePremiumPayment: c.elapsedPrem,
            jtInstYieldShareWAD: JT_PINNED_SHARE_WAD,
            lptInstYieldShareWAD: LPT_PINNED_SHARE_WAD,
            maxJTYieldShareWAD: a0.maxJTYieldShareWAD,
            maxLPTYieldShareWAD: a0.maxLPTYieldShareWAD,
            stProtocolFeeWAD: a0.stProtocolFeeWAD,
            jtProtocolFeeWAD: a0.jtProtocolFeeWAD,
            jtYieldShareProtocolFeeWAD: a0.jtYieldShareProtocolFeeWAD,
            lptYieldShareProtocolFeeWAD: a0.lptYieldShareProtocolFeeWAD,
            nowTimestamp: block.timestamp,
            fixedTermDuration: a0.fixedTermDurationSeconds,
            minCoverageWAD: a0.minCoverageWAD,
            coverageLiquidationUtilizationWAD: a0.coverageLiquidationUtilizationWAD,
            dustTolerance: toUint256(a0.dustTolerance),
            minLiquidityWAD: a0.minLiquidityWAD
        });
        try this.runSyncTrancheAccountingMirror(win) returns (RoycoTestMath.SyncOutputs memory w) {
            c.mirrorOk = true;
            c.w = w;
        } catch {
            _flag(false, string.concat(_label, ": independent tranche accounting sync recomputation reverted (conservation or premium bound broke)"));
        }

        s = _verifyPostSync(_label, a0, c);
    }

    /// @dev The post-sync half of the verification, split out to bound stack usage
    function _verifyPostSync(string memory _label, IRoycoDayAccountant.RoycoDayAccountantState memory a0, SyncCtx memory c) internal returns (Snap memory s) {
        IRoycoDayAccountant.RoycoDayAccountantState memory a1 = accountant.getState();
        IRoycoDayKernel.RoycoDayKernelState memory k1 = kernel.getState();

        // The committed collateral mark must echo the fresh quote, and it must equal effective in total
        _flag(toUint256(a1.lastCollateralNAV) == c.collateralNew, string.concat(_label, ": committed collateral mark diverges from the fresh quote"));
        _flag(
            c.collateralNew == toUint256(a1.lastSTEffectiveNAV) + toUint256(a1.lastJTEffectiveNAV),
            string.concat(_label, ": collateral NAV and effective NAV totals diverge after the sync")
        );

        // The state-machine biconditional: every PERPETUAL commit erases the IL ledger and the FIXED_TERM
        // branch never zeroes it, so PERPETUAL iff il == 0 after every sync
        _flag(
            (a1.lastMarketState == MarketState.PERPETUAL) == (toUint256(a1.lastJTImpermanentLoss) == 0),
            string.concat(_label, ": committed market state and impermanent-loss ledger disagree (PERPETUAL iff il == 0)")
        );

        uint256 premiumShares;
        if (c.mirrorOk) {
            _flag(
                toUint256(a1.lastSTEffectiveNAV) == c.w.stEffectiveNAV,
                string.concat(_label, ": committed senior effective NAV diverges from the recomputation")
            );
            _flag(
                toUint256(a1.lastJTEffectiveNAV) == c.w.jtEffectiveNAV,
                string.concat(_label, ": committed junior effective NAV diverges from the recomputation")
            );
            _flag(
                toUint256(a1.lastJTImpermanentLoss) == c.w.jtImpermanentLoss,
                string.concat(_label, ": committed impermanent loss diverges from the recomputation")
            );
            _flag(
                (a1.lastMarketState == MarketState.PERPETUAL) == (c.w.marketState == RoycoTestMath.MarketState.PERPETUAL),
                string.concat(_label, ": committed market state diverges from the recomputation")
            );
            _flag(
                uint256(a1.fixedTermEndTimestamp) == c.w.fixedTermEndTimestamp,
                string.concat(_label, ": committed fixed-term end diverges from the recomputation")
            );

            // The FIXED_TERM zero-fee theorem: under same-sign attribution any nonzero fee or premium
            // requires a gain residual that fully recovered the IL, which resolves PERPETUAL instead, so
            // a FIXED_TERM commit can never carry a fee or premium
            if (c.w.marketState == RoycoTestMath.MarketState.FIXED_TERM) {
                _flag(
                    c.w.stProtocolFee == 0 && c.w.jtProtocolFee == 0 && c.w.lptProtocolFee == 0 && c.w.lptLiquidityPremium == 0,
                    string.concat(_label, ": a FIXED_TERM commit carried a nonzero fee or premium")
                );
            }

            // Replay the impermanent-loss ledger through its only four sanctioned movements
            _recordImpermanentLossMovement(a0, c.w);
            _flag(
                ghost_jtImpermanentLossReplay == toUint256(a1.lastJTImpermanentLoss),
                string.concat(_label, ": impermanent-loss ledger replay diverges from the committed value")
            );

            // The senior supply may grow only by the fee and liquidity premium share mint, both legs floor-priced
            // (and mint-dilution clamped) over the same retained NAV stEffectiveNAV - premium - stFee. The LPT
            // protocol fee is carved out of the premium: the LPT receives the NET premium (premium - lptFee) as
            // idle senior shares and the fee recipient receives (stFee + lptFee) as senior shares, so no
            // liquidity-provider-tranche shares mint on a sync. lptFee <= premium always, so the net never underflows
            uint256 retainedSeniorNAV = c.w.stEffectiveNAV - c.w.lptLiquidityPremium - c.w.stProtocolFee;
            premiumShares = RoycoTestMath.convertToShares(c.w.lptLiquidityPremium - c.w.lptProtocolFee, retainedSeniorNAV, c.stSupply0);
            uint256 feeShares = RoycoTestMath.convertToShares(c.w.stProtocolFee + c.w.lptProtocolFee, retainedSeniorNAV, c.stSupply0);
            _flag(
                seniorTranche.totalSupply() == c.stSupply0 + premiumShares + feeShares,
                string.concat(_label, ": senior supply moved by something other than the fee and liquidity premium share mint")
            );
            ghost_liquidityPremiumSharesMinted += premiumShares;
            uint256 jtFeeShares =
                c.w.jtProtocolFee == 0 ? 0 : RoycoTestMath.convertToShares(c.w.jtProtocolFee, c.w.jtEffectiveNAV - c.w.jtProtocolFee, c.jtSupply0);
            _flag(juniorTranche.totalSupply() == c.jtSupply0 + jtFeeShares, string.concat(_label, ": junior supply moved by something other than the fee mint"));

            // Premium accrual window: reset exactly when premiums pay, otherwise grow by the pinned model
            if (c.firstAccrual || c.w.premiumsPaid) {
                _flag(
                    a1.twJTYieldShareAccruedWAD == 0 && a1.twLPTYieldShareAccruedWAD == 0 && uint256(a1.lastPremiumPaymentTimestamp) == block.timestamp,
                    string.concat(_label, ": premium accumulators failed to reset on a premium payment")
                );
                ghost_windowMaxJTShareWAD = a1.maxJTYieldShareWAD;
                ghost_windowMaxLPTShareWAD = a1.maxLPTYieldShareWAD;
            } else {
                _flag(
                    uint256(a1.twJTYieldShareAccruedWAD) == c.twJT && uint256(a1.twLPTYieldShareAccruedWAD) == c.twLPT,
                    string.concat(_label, ": accrued premium weight diverges from the pinned model accrual")
                );
                _flag(
                    a1.lastPremiumPaymentTimestamp == a0.lastPremiumPaymentTimestamp,
                    string.concat(_label, ": premium payment timestamp moved without a payment")
                );
            }
            if (c.elapsedPrem > 0) {
                _flag(
                    c.twJT <= ghost_windowMaxJTShareWAD * c.elapsedPrem && c.twLPT <= ghost_windowMaxLPTShareWAD * c.elapsedPrem,
                    string.concat(_label, ": accrued premium weight exceeds the configured cap over the window")
                );
            }
            if (IS_ZERO_LIQUIDITY_PROFILE) {
                _flag(c.w.lptLiquidityPremium == 0 && premiumShares == 0, string.concat(_label, ": zero-liquidity market accrued a liquidity premium"));
            }
        }
        _flag(uint256(a1.lastYieldShareAccrualTimestamp) == block.timestamp, string.concat(_label, ": accrual timestamp failed to advance to this block"));

        // Staged-premium conservation: the ledger moves only by the mint and the measured pool deployment
        uint256 deployed = seniorTranche.balanceOf(address(balancerVault)) - c.poolSenior0;
        ghost_liquidityPremiumSharesReinvested += deployed;
        ghost_stSharesDeployedSinceLastPriceCheck += deployed;
        if (c.mirrorOk) {
            _flag(
                k1.lptOwnedSeniorTrancheShares == c.lptOwnedSeniorTrancheShares0 + premiumShares - deployed,
                string.concat(_label, ": lptOwnedSeniorTrancheShares diverges from mint minus measured deployment")
            );
        }
        if (k1.lptOwnedSeniorTrancheShares > 0) ghost_idleLiquidityPremiumObserved++;

        // Solvency: every internal ledger is fully backed by the kernel's actual token balances
        _flag(
            stJtVault.balanceOf(address(kernel)) == toUint256(k1.totalCollateralAssets),
            string.concat(_label, ": kernel vault-share balance no longer backs the collateral ledger")
        );
        _flag(
            bpt.balanceOf(address(kernel)) == toUint256(k1.totalLPTAssets),
            string.concat(_label, ": kernel pool-token balance no longer backs the liquidity ledger")
        );
        _flag(
            seniorTranche.balanceOf(address(kernel)) == k1.lptOwnedSeniorTrancheShares,
            string.concat(_label, ": kernel senior-share balance no longer backs lptOwnedSeniorTrancheShares")
        );
        _flag(quoteToken.balanceOf(address(kernel)) == 0, string.concat(_label, ": kernel retained quote tokens it should never hold"));

        // The committed pool mark must equal a manual re-pricing of the kernel's pool tokens and must
        // exclude the idle liquidity premium senior shares, which appear only in the effective value
        uint256 stEff1 = toUint256(a1.lastSTEffectiveNAV);
        uint256 stSupply1 = seniorTranche.totalSupply();
        uint256 lptRawMirror = _mirrorLptRawNAV(toUint256(k1.totalLPTAssets), stEff1, stSupply1);
        _flag(toUint256(a1.lastLPTRawNAV) == lptRawMirror, string.concat(_label, ": committed pool mark diverges from the manual re-pricing"));
        uint256 lptEffNavMirror = RoycoTestMath.getLiquidityProviderTrancheEffectiveNAV(lptRawMirror, k1.lptOwnedSeniorTrancheShares, stEff1, stSupply1);
        _flag(
            toUint256(liquidityProviderTranche.totalAssets().nav) == lptEffNavMirror,
            string.concat(_label, ": liquidity effective value is not the pool mark plus the idle liquidity premium slice")
        );

        _checkPriceMonotonicity(_label, a1, stSupply1, lptEffNavMirror);
        _trackRegimes(a1, c);
        s = _buildSnap(a1, k1, lptEffNavMirror);
    }

    /// @dev Appends this sync's impermanent-loss movement to the event log and advances the replay value
    function _recordImpermanentLossMovement(IRoycoDayAccountant.RoycoDayAccountantState memory a0, RoycoTestMath.SyncOutputs memory w) internal {
        uint256 jtImpermanentLossBefore = toUint256(a0.lastJTImpermanentLoss);
        if (w.ilErased > 0) {
            // Erasure runs after any same-sync growth or recovery, so log that movement first
            uint256 preErase = w.jtImpermanentLoss + w.ilErased;
            if (preErase > jtImpermanentLossBefore) {
                ghost_jtImpermanentLossEvents.push(JTImpermanentLossEvent(JTImpermanentLossCause.COVERAGE_APPLIED, preErase - jtImpermanentLossBefore));
            } else if (preErase < jtImpermanentLossBefore) {
                ghost_jtImpermanentLossEvents.push(JTImpermanentLossEvent(JTImpermanentLossCause.RECOVERY, jtImpermanentLossBefore - preErase));
            }
            ghost_jtImpermanentLossEvents.push(JTImpermanentLossEvent(JTImpermanentLossCause.ERASED, w.ilErased));
            ghost_jtImpermanentLossReplay = w.jtImpermanentLoss;
        } else if (w.jtImpermanentLoss > jtImpermanentLossBefore) {
            ghost_jtImpermanentLossEvents.push(JTImpermanentLossEvent(JTImpermanentLossCause.COVERAGE_APPLIED, w.jtImpermanentLoss - jtImpermanentLossBefore));
            ghost_jtImpermanentLossReplay = ghost_jtImpermanentLossReplay + (w.jtImpermanentLoss - jtImpermanentLossBefore);
        } else if (w.jtImpermanentLoss < jtImpermanentLossBefore) {
            ghost_jtImpermanentLossEvents.push(JTImpermanentLossEvent(JTImpermanentLossCause.RECOVERY, jtImpermanentLossBefore - w.jtImpermanentLoss));
            ghost_jtImpermanentLossReplay = ghost_jtImpermanentLossReplay - (jtImpermanentLossBefore - w.jtImpermanentLoss);
        }
    }

    /// @dev Verifies the three share prices never fall outside a sanctioned loss event, then re-arms
    /// @dev A tranche whose supply hits zero starts a fresh price series, so its high-water resets there
    function _checkPriceMonotonicity(
        string memory _label,
        IRoycoDayAccountant.RoycoDayAccountantState memory a1,
        uint256 _stSupply,
        uint256 _lptEffNav
    )
        internal
    {
        uint256 jtEff1 = toUint256(a1.lastJTEffectiveNAV);
        if (_stSupply == 0) (ghost_stPriceHighWater, ghost_stVirtualHighWater) = (0, 0);
        if (_stSupply > 0) {
            uint256 stEff1 = toUint256(a1.lastSTEffectiveNAV);
            uint256 pSt = stEff1.mulDiv(WAD, _stSupply);
            // Base flooring budget plus the offset's deposit-dilution dust: absent a loss the naive price can fall by
            // at most the naive-virtual gap captured at the prior high-water (see ghost_*VirtualHighWater).
            uint256 dust = PRICE_FLOOR_DUST_NAV_WEI_DERIVED_BOUND.mulDiv(WAD, _stSupply) + 2 + (ghost_stPriceHighWater - ghost_stVirtualHighWater);
            if (pSt + dust < ghost_stPriceHighWater) {
                _flag(ghost_uncoveredLossSinceLastCheck && jtEff1 == 0, string.concat(_label, ": senior share price fell without an uncovered loss"));
                if (jtEff1 == 0) ghost_uncoveredLossRealized++;
            }
            (ghost_stPriceHighWater, ghost_stVirtualHighWater) = (pSt, Math.min(pSt, _virtualSharePrice(stEff1, _stSupply)));
        }
        uint256 jtSupply1 = juniorTranche.totalSupply();
        if (jtSupply1 == 0) (ghost_jtPriceHighWater, ghost_jtVirtualHighWater) = (0, 0);
        if (jtSupply1 > 0) {
            uint256 pJt = jtEff1.mulDiv(WAD, jtSupply1);
            uint256 dust = PRICE_FLOOR_DUST_NAV_WEI_DERIVED_BOUND.mulDiv(WAD, jtSupply1) + 2 + (ghost_jtPriceHighWater - ghost_jtVirtualHighWater);
            if (pJt + dust < ghost_jtPriceHighWater) {
                _flag(ghost_jtLossSinceLastCheck, string.concat(_label, ": junior share price fell without a junior loss event"));
            }
            (ghost_jtPriceHighWater, ghost_jtVirtualHighWater) = (pJt, Math.min(pJt, _virtualSharePrice(jtEff1, jtSupply1)));
        }
        uint256 lptSupply1 = liquidityProviderTranche.totalSupply();
        if (lptSupply1 == 0) (ghost_lptPriceHighWater, ghost_lptVirtualHighWater) = (0, 0);
        if (lptSupply1 > 0) {
            uint256 pLt = _lptEffNav.mulDiv(WAD, lptSupply1);
            // Deploying n idle premium senior shares re-marks them from the exact claimable-leg valuation
            // floor(n * (stEffectiveNAV + 1) / (stSupply + 1e6)) to the venue's WAD-quantized senior rate
            // floor((stEffectiveNAV + 1) * WAD / (stSupply + 1e6)) / WAD per share, an NAV drop of
            // n * ((stEffectiveNAV * WAD) mod stSupply) / (stSupply * WAD) < n / WAD NAV wei that is mark
            // quantization, not value leakage. The per-mulDiv flooring residue on the deploy path stays
            // inside the constant PRICE_FLOOR_DUST_NAV_WEI_DERIVED_BOUND budget, so the dust bound widens
            // by exactly n / WAD NAV wei and a drop even one price wei past it still fails. The trailing term
            // is the offset's deposit-dilution dust: the naive-virtual gap captured at the prior high-water.
            uint256 deployQuantizationNAVWei = ghost_stSharesDeployedSinceLastPriceCheck / WAD;
            uint256 dust = (PRICE_FLOOR_DUST_NAV_WEI_DERIVED_BOUND + deployQuantizationNAVWei).mulDiv(WAD, lptSupply1) + 2
                + (ghost_lptPriceHighWater - ghost_lptVirtualHighWater);
            if (pLt + dust < ghost_lptPriceHighWater) {
                _flag(
                    ghost_lptVenueLossSinceLastCheck || (ghost_uncoveredLossSinceLastCheck && jtEff1 == 0),
                    string.concat(_label, ": liquidity share price fell without a venue or uncovered loss event")
                );
            }
            (ghost_lptPriceHighWater, ghost_lptVirtualHighWater) = (pLt, Math.min(pLt, _virtualSharePrice(_lptEffNav, lptSupply1)));
        }
        ghost_uncoveredLossSinceLastCheck = false;
        ghost_jtLossSinceLastCheck = false;
        ghost_lptVenueLossSinceLastCheck = false;
        ghost_stSharesDeployedSinceLastPriceCheck = 0;
    }

    /// @dev Advances the regime counters off the observed state transition
    function _trackRegimes(IRoycoDayAccountant.RoycoDayAccountantState memory a1, SyncCtx memory c) internal {
        if (c.state0 == MarketState.PERPETUAL && a1.lastMarketState == MarketState.FIXED_TERM) ghost_enteredFixedTerm++;
        if (c.state0 == MarketState.FIXED_TERM && a1.lastMarketState == MarketState.PERPETUAL) ghost_exitedFixedTerm++;
        bool breachedNow = RoycoTestMath.computeCoverageUtilization(toUint256(a1.lastCollateralNAV), a1.minCoverageWAD, toUint256(a1.lastJTEffectiveNAV))
            >= a1.coverageLiquidationUtilizationWAD;
        if (!c.wasBreached && breachedNow) ghost_crossedLiquidationThreshold++;
    }

    /// @dev Packages the freshly committed state into the snapshot ops predict their gates from
    function _buildSnap(
        IRoycoDayAccountant.RoycoDayAccountantState memory a1,
        IRoycoDayKernel.RoycoDayKernelState memory k1,
        uint256
    )
        internal
        view
        returns (Snap memory s)
    {
        s.ok = true;
        s.fixedTerm = a1.lastMarketState == MarketState.FIXED_TERM;
        s.collateralNAV = toUint256(a1.lastCollateralNAV);
        s.lptRawNAV = toUint256(a1.lastLPTRawNAV);
        s.stEffectiveNAV = toUint256(a1.lastSTEffectiveNAV);
        s.jtEffectiveNAV = toUint256(a1.lastJTEffectiveNAV);
        s.jtImpermanentLoss = toUint256(a1.lastJTImpermanentLoss);
        s.coverageUtilizationWAD = RoycoTestMath.computeCoverageUtilization(s.collateralNAV, a1.minCoverageWAD, s.jtEffectiveNAV);
        s.minCoverageWAD = a1.minCoverageWAD;
        s.minLiquidityWAD = a1.minLiquidityWAD;
        s.coverageLiquidationUtilizationWAD = a1.coverageLiquidationUtilizationWAD;
        s.dustTolerance = toUint256(a1.dustTolerance);
        s.stSupply = seniorTranche.totalSupply();
        s.jtSupply = juniorTranche.totalSupply();
        s.lptSupply = liquidityProviderTranche.totalSupply();
        s.collateralOwned = toUint256(k1.totalCollateralAssets);
        s.lptOwned = toUint256(k1.totalLPTAssets);
        s.lptOwnedSeniorTrancheShares = k1.lptOwnedSeniorTrancheShares;
        s.bonusWAD = k1.stSelfLiquidationBonusWAD;
    }

    /// @dev Rebuilds the snapshot from committed state without re-syncing (same block, nothing moved the feeds)
    function _refreshSnap() internal view returns (Snap memory s) {
        s = _buildSnap(accountant.getState(), kernel.getState(), 0);
    }

    // =============================
    // External self-call so a mirror revert is caught instead of aborting the op
    // =============================

    /// @notice Runs the independent tranche accounting sync recomputation, callable only by the handler itself
    function runSyncTrancheAccountingMirror(RoycoTestMath.SyncInputs memory _in) external view returns (RoycoTestMath.SyncOutputs memory) {
        require(msg.sender == address(this), "only self");
        return RoycoTestMath.syncTrancheAccounting(_in);
    }

    /// @notice Runs the share-pricing floor mirror (mint-dilution clamp included), callable only by the handler itself
    /// @dev External so its mulDiv overflow (the residual cliff's cap computation) reverts into the caller's try/catch instead of aborting the op
    function runSharesForMirror(uint256 _value, uint256 _totalValue, uint256 _supply) external view returns (uint256) {
        require(msg.sender == address(this), "only self");
        return RoycoTestMath.convertToShares(_value, _totalValue, _supply);
    }

    // =============================
    // Core-invariant view for the invariant contract
    // =============================

    /// @notice Recomputes the always-true identities from live state, returning the first breach found
    function coreInvariantBreach() external view returns (string memory) {
        IRoycoDayAccountant.RoycoDayAccountantState memory a = accountant.getState();
        IRoycoDayKernel.RoycoDayKernelState memory k = kernel.getState();
        if (toUint256(a.lastCollateralNAV) != toUint256(a.lastSTEffectiveNAV) + toUint256(a.lastJTEffectiveNAV)) {
            return "collateral NAV and effective NAV totals diverge";
        }
        if ((a.lastMarketState == MarketState.PERPETUAL) != (toUint256(a.lastJTImpermanentLoss) == 0)) {
            return "market state and impermanent-loss ledger disagree (PERPETUAL iff il == 0)";
        }
        if (stJtVault.balanceOf(address(kernel)) != toUint256(k.totalCollateralAssets)) {
            return "kernel vault-share balance does not back the collateral ledger";
        }
        uint256 netIn = ghost_transferredIn[address(stJtVault)] - ghost_transferredOut[address(stJtVault)];
        if (stJtVault.balanceOf(address(kernel)) != netIn) return "kernel vault-share balance diverges from the transfer ledger";
        if (bpt.balanceOf(address(kernel)) != toUint256(k.totalLPTAssets)) return "kernel pool-token balance does not back the liquidity ledger";
        if (seniorTranche.balanceOf(address(kernel)) != k.lptOwnedSeniorTrancheShares) {
            return "kernel senior-share balance does not back lptOwnedSeniorTrancheShares";
        }
        if (
            ghost_liquidityPremiumSharesMinted
                != k.lptOwnedSeniorTrancheShares + ghost_liquidityPremiumSharesReinvested + ghost_idlePremiumSeniorSharesPaidToRedeemers
        ) {
            return "idle liquidity premium ledger does not reconcile minted, deployed, and paid-out shares";
        }
        return "";
    }

    /**
     * @notice The wei-precision NAV conservation identity over the committed checkpoint:
     *         collateralNAV == stEffectiveNAV + jtEffectiveNAV. The liquidity premium is covered
     *         senior shares inside stEffectiveNAV, never a third NAV leg, so the identity must survive
     *         the fee and liquidity premium share mint on every sync. On a breach the full checkpoint is
     *         dumped so the failing state is reconstructible from the assertion message alone
     */
    function conservationCheckpointReport() external view returns (bool holds, string memory report) {
        IRoycoDayAccountant.RoycoDayAccountantState memory a = accountant.getState();
        IRoycoDayKernel.RoycoDayKernelState memory k = kernel.getState();
        uint256 collateralNAV = toUint256(a.lastCollateralNAV);
        uint256 stEffectiveNAV = toUint256(a.lastSTEffectiveNAV);
        uint256 jtEffectiveNAV = toUint256(a.lastJTEffectiveNAV);
        holds = collateralNAV == stEffectiveNAV + jtEffectiveNAV;
        if (!holds) {
            report = string.concat(
                "collateralNAV != stEffectiveNAV + jtEffectiveNAV at wei precision | collateralNAV=",
                vm.toString(collateralNAV),
                " stEffectiveNAV=",
                vm.toString(stEffectiveNAV),
                " jtEffectiveNAV=",
                vm.toString(jtEffectiveNAV)
            );
            report = string.concat(
                report,
                " lptRawNAV=",
                vm.toString(toUint256(a.lastLPTRawNAV)),
                " jtImpermanentLoss=",
                vm.toString(toUint256(a.lastJTImpermanentLoss)),
                " marketState=",
                vm.toString(uint256(a.lastMarketState)),
                " fixedTermEndTimestamp=",
                vm.toString(uint256(a.fixedTermEndTimestamp))
            );
            report = string.concat(
                report,
                " lptOwnedSeniorTrancheShares=",
                vm.toString(k.lptOwnedSeniorTrancheShares),
                " stSupply=",
                vm.toString(seniorTranche.totalSupply()),
                " jtSupply=",
                vm.toString(juniorTranche.totalSupply()),
                " lptSupply=",
                vm.toString(liquidityProviderTranche.totalSupply())
            );
        }
    }

    /**
     * @notice The state-machine biconditional over the committed checkpoint: PERPETUAL iff the
     *         impermanent-loss ledger is zero. Every PERPETUAL commit erases the ledger and the
     *         FIXED_TERM branch never zeroes it, so a breach in either direction is a state the
     *         two-branch machine cannot produce
     */
    function stateMachineCheckpointReport() external view returns (bool holds, string memory report) {
        IRoycoDayAccountant.RoycoDayAccountantState memory a = accountant.getState();
        bool perpetual = a.lastMarketState == MarketState.PERPETUAL;
        uint256 il = toUint256(a.lastJTImpermanentLoss);
        holds = perpetual == (il == 0);
        if (!holds) {
            report = string.concat(
                perpetual
                    ? "PERPETUAL committed with a nonzero impermanent-loss ledger | jtImpermanentLoss="
                    : "FIXED_TERM committed with a zero impermanent-loss ledger | jtImpermanentLoss=",
                vm.toString(il)
            );
        }
    }

    /// @notice The number of recorded impermanent-loss ledger movements
    function jtImpermanentLossEventCount() external view returns (uint256) {
        return ghost_jtImpermanentLossEvents.length;
    }

    /// @notice String-keyed read of the anti-vacuity op-invocation ledger
    function opCalls(string memory _op) external view returns (uint256) {
        return ghost_opCalls[keccak256(bytes(_op))];
    }

    /// @notice String-keyed read of the per-op success ledger
    function opSuccesses(string memory _op) external view returns (uint256) {
        return ghost_opSuccesses[keccak256(bytes(_op))];
    }

    /// @notice String-keyed read of the per-op predicted-rejection ledger
    function opPredictedReverts(string memory _op) external view returns (uint256) {
        return ghost_opPredictedReverts[keccak256(bytes(_op))];
    }

    // =============================
    // Internal helpers
    // =============================

    /// @dev Sources senior shares for the external actor through the real gated deposit path, never a mint.
    ///      The deposit runs under _execStDeposit's full revert prediction, so a gate rejection is asserted
    ///      (not skipped) and a zero balance afterward simply means the exogenous leg has nothing to move
    function _ensureExternalSeniorShares() internal returns (uint256 bal) {
        bal = seniorTranche.balanceOf(externalLp);
        if (bal != 0) return bal;
        Snap memory s = _syncAndVerify("pre:externalStDeposit");
        if (!s.ok) return 0;
        uint256 assets = _clampSupplySafeDeposit(1e21, _quoteCollateralUnits(1e21), s.stEffectiveNAV, s.stSupply);
        _execStDeposit(externalLp, assets, s);
        return seniorTranche.balanceOf(externalLp);
    }

    /// @dev Mirrors the mock vault's exact-in swap output: fair value at the vault's pinned prices, floored,
    ///      less the pool-retained swap fee, the same two floors in the same order as MockBalancerVault.swap
    function _mirrorSwapExactInOut(address _tokenIn, address _tokenOut, uint256 _amountIn) internal view returns (uint256) {
        uint256 valueInWAD = _amountIn.mulDiv(balancerVault.getTokenPriceWAD(_tokenIn), 10 ** IERC20Metadata(_tokenIn).decimals());
        uint256 grossOut = valueInWAD.mulDiv(10 ** IERC20Metadata(_tokenOut).decimals(), balancerVault.getTokenPriceWAD(_tokenOut));
        return (grossOut * (10_000 - balancerVault.swapFeeBps())) / 10_000;
    }

    /// @dev State captured around an exogenous pool op so its exact token movements can be reconciled
    struct ExtPoolSnap {
        uint256 inBal0;
        uint256 outBal0;
        uint256[2] pool0;
        uint256 tvl0;
        uint256 lptOwned0;
        uint256 kernelBpt0;
        uint256 bptSupply0;
        uint256 extBpt0;
    }

    /// @dev Captures the balances the exogenous-op reconciliations compare against
    function _snapExtPool(IERC20 _tokenIn, IERC20 _tokenOut) internal view returns (ExtPoolSnap memory s) {
        s.inBal0 = _tokenIn.balanceOf(externalLp);
        s.outBal0 = _tokenOut.balanceOf(externalLp);
        s.pool0 = balancerVault.getPoolBalances(address(bpt));
        s.tvl0 = bptOracle.computeTVL();
        s.lptOwned0 = toUint256(kernel.getState().totalLPTAssets);
        s.kernelBpt0 = bpt.balanceOf(address(kernel));
        s.bptSupply0 = bpt.totalSupply();
        s.extBpt0 = bpt.balanceOf(externalLp);
    }

    /**
     * @dev Runs one exogenous exact-in swap through the router, halving the input until the priced output fits
     *      the pool's out leg (the mock reverts on a drained leg exactly like a checked balance would). The
     *      minAmountOut is armed at exactly the mirrored output, so the vault's SwapLimit floor is exercised at
     *      the boundary on every call. Verifies value conservation at the oracle's prices: at pinned rates a
     *      swap's output value never exceeds its input value (output flooring plus the fee stay in the pool),
     *      so the pool's TVL can fall by at most the one wei the per-token TVL floors can lose
     * @return swapped Whether a swap executed (false only when even a one-wei input overfills the out leg)
     */
    function _execExternalSwapExactIn(IERC20 _tokenIn, IERC20 _tokenOut, uint256 _amountIn, uint256 _poolOutLeg) internal returns (bool swapped) {
        uint256 predOut = _mirrorSwapExactInOut(address(_tokenIn), address(_tokenOut), _amountIn);
        while (predOut > _poolOutLeg && _amountIn > 1) {
            _amountIn /= 2;
            predOut = _mirrorSwapExactInOut(address(_tokenIn), address(_tokenOut), _amountIn);
        }
        if (predOut > _poolOutLeg) return false;

        ExtPoolSnap memory s = _snapExtPool(_tokenIn, _tokenOut);
        vm.startPrank(externalLp);
        _tokenIn.approve(address(balancerRouter), _amountIn);
        uint256 amountOut = balancerRouter.swapSingleTokenExactIn(address(bpt), _tokenIn, _tokenOut, _amountIn, predOut);
        vm.stopPrank();

        _flag(amountOut == predOut, "external swap output diverges from the constant-price mirror");
        _flag(_tokenIn.balanceOf(externalLp) == s.inBal0 - _amountIn, "external swap took more input than the exact amount");
        _flag(_tokenOut.balanceOf(externalLp) == s.outBal0 + amountOut, "external swap output did not land with the swapper in full");
        {
            uint256 inIdx = address(_tokenIn) == address(seniorTranche) ? stPoolTokenIndex : 1 - stPoolTokenIndex;
            uint256[2] memory pool1 = balancerVault.getPoolBalances(address(bpt));
            _flag(
                pool1[inIdx] == s.pool0[inIdx] + _amountIn && pool1[1 - inIdx] == s.pool0[1 - inIdx] - amountOut,
                "external swap pool composition does not reconcile with the exact amounts"
            );
        }
        _flag(bptOracle.computeTVL() + 1 >= s.tvl0, "external swap destroyed pool value beyond the one-wei TVL floor bound");
        _flag(
            toUint256(kernel.getState().totalLPTAssets) == s.lptOwned0 && bpt.balanceOf(address(kernel)) == s.kernelBpt0,
            "an external swap moved the kernel's pool-token ledger or custody"
        );
        return true;
    }

    /**
     * @dev Runs one exogenous proportional removal of the external LP's own pool tokens through the router,
     *      with the per-token floors armed at exactly the mirrored proportional outputs so the vault's
     *      AmountOutBelowMin boundary is exercised on every call. The kernel's ledger and custody must be
     *      inert: the burn draws exclusively on the external LP's balance and the floor-rounded residue
     *      stays in the pool, so the per-BPT value the ledger is priced at can only rise
     */
    function _execExternalPartialRemove(uint256 _burn) internal {
        IERC20 seniorToken = IERC20(address(seniorTranche));
        IERC20 quoteAsIERC20 = IERC20(address(quoteToken));
        ExtPoolSnap memory s = _snapExtPool(stPoolTokenIndex == 0 ? seniorToken : quoteAsIERC20, stPoolTokenIndex == 0 ? quoteAsIERC20 : seniorToken);
        uint256[2] memory pred = [s.pool0[0].mulDiv(_burn, s.bptSupply0), s.pool0[1].mulDiv(_burn, s.bptSupply0)];

        vm.prank(externalLp);
        uint256[2] memory outs = balancerRouter.removeLiquidityProportional(address(bpt), _burn, pred);

        _flag(outs[0] == pred[0] && outs[1] == pred[1], "external removal outputs diverge from the proportional floors");
        _flag(
            bpt.totalSupply() == s.bptSupply0 - _burn && bpt.balanceOf(externalLp) == s.extBpt0 - _burn, "external removal burned a different pool-token amount"
        );
        {
            IERC20 token0 = stPoolTokenIndex == 0 ? seniorToken : quoteAsIERC20;
            IERC20 token1 = stPoolTokenIndex == 0 ? quoteAsIERC20 : seniorToken;
            _flag(
                token0.balanceOf(externalLp) == s.inBal0 + outs[0] && token1.balanceOf(externalLp) == s.outBal0 + outs[1],
                "external removal outputs did not land with the external LP in full"
            );
        }
        {
            uint256[2] memory pool1 = balancerVault.getPoolBalances(address(bpt));
            _flag(pool1[0] == s.pool0[0] - outs[0] && pool1[1] == s.pool0[1] - outs[1], "external removal pool composition does not reconcile");
        }
        _flag(
            toUint256(kernel.getState().totalLPTAssets) == s.lptOwned0 && bpt.balanceOf(address(kernel)) == s.kernelBpt0,
            "an external LP's removal touched the kernel's pool-token ledger or custody"
        );
    }

    /// @dev Mints pool tokens to an account at the pool's current value per token, backed by a real quote leg
    function _mintFairValueBpt(address _to, uint256 _quoteLeg) internal returns (uint256 bptAmt) {
        uint256 valueWAD = _quoteLeg.mulDiv(bptOracle.getPriceWAD(address(quoteToken)), QUOTE_UNIT);
        uint256 tvl = bptOracle.computeTVL();
        bptAmt = tvl == 0 ? valueWAD : valueWAD.mulDiv(bpt.totalSupply(), tvl);
        if (bptAmt == 0) bptAmt = 1;
        quoteToken.mint(_to, _quoteLeg);
        vm.startPrank(_to);
        quoteToken.approve(address(balancerVault), _quoteLeg);
        uint256[2] memory legs;
        legs[1 - stPoolTokenIndex] = _quoteLeg;
        balancerVault.mintPoolTokensTo(address(bpt), _to, bptAmt, legs);
        vm.stopPrank();
    }

    /// @dev Re-prices the kernel's pool tokens by hand: pool balances at the pinned senior rate and the oracle quote price
    /// @dev Quantizes through the kernel's own two-step pricing: queryLPTAssetOracle floors the price of ONE whole
    ///      pool token first, then convertLPTAssetsToValue floors the owned amount at that quantized price, so the
    ///      committed mark sits up to lptOwned / LPT_UNIT NAV wei below the exact single-mulDiv value
    function _mirrorLptRawNAV(uint256 _lptOwned, uint256 _stEff, uint256 _stSupply) internal view returns (uint256) {
        uint256 supply = bpt.totalSupply();
        if (supply == 0) return 0;
        uint256 rate = _mirrorSeniorRate(_stEff, _stSupply);
        uint256[2] memory balances = balancerVault.getPoolBalances(address(bpt));
        uint256 tvl =
            balances[stPoolTokenIndex].mulDiv(rate, WAD) + balances[1 - stPoolTokenIndex].mulDiv(bptOracle.getPriceWAD(address(quoteToken)), QUOTE_UNIT);
        uint256 lptUnitPrice = LPT_UNIT.mulDiv(tvl, supply);
        return _lptOwned.mulDiv(lptUnitPrice, LPT_UNIT);
    }

    /// @dev The OZ virtual-shares share price floor((effNAV + VIRTUAL_VALUE) * WAD / (supply + VIRTUAL_SHARES)),
    ///      the monotone-non-decreasing price the offset guarantees on a no-loss deposit. The naive price the
    ///      monotonicity check tracks sits weakly above this, and the gap is the tolerated per-op deposit-dilution dust.
    function _virtualSharePrice(uint256 _effNAV, uint256 _supply) internal pure returns (uint256) {
        return (_effNAV + RoycoTestMath.VIRTUAL_VALUE).mulDiv(WAD, _supply + RoycoTestMath.VIRTUAL_SHARES);
    }

    /// @dev The senior share rate the pool prices with: effective value per share, floored to one wei. Mirrors
    ///      production ValuationLogic._computeTrancheShareRate == _convertToValue(WAD, supply, effNAV, Floor), which
    ///      carries the virtual-shares/value offset: floor((stEff + VIRTUAL_VALUE) * WAD / (stSupply + VIRTUAL_SHARES)).
    ///      The fresh-tranche exemption (supply == 0 && effNAV == 0 -> 0) then the pool's 1-wei floor still apply.
    function _mirrorSeniorRate(uint256 _stEff, uint256 _stSupply) internal pure returns (uint256) {
        if (_stSupply == 0 && _stEff == 0) return 1;
        uint256 r = (_stEff + RoycoTestMath.VIRTUAL_VALUE).mulDiv(WAD, _stSupply + RoycoTestMath.VIRTUAL_SHARES);
        return r == 0 ? 1 : r;
    }

    /// @dev Values collateral vault shares in NAV units at the kernel's committed collateral rate.
    ///      Every prediction prices assets at the exact per-block rate production applies, the independence
    ///      of a mirror lives in its surrounding arithmetic, never in a re-derived price
    function _quoteCollateralUnits(uint256 _units) internal view returns (uint256) {
        return toUint256(kernel.convertCollateralAssetsToValue(toTrancheUnits(_units)));
    }

    /// @dev Values pool tokens in NAV units at the kernel's committed pool mark, so liquidity-gate
    ///      predictions and the removal mirror price depth exactly as the accountant marks it
    function _quoteLPTUnits(uint256 _units) internal view returns (uint256) {
        return toUint256(kernel.convertLPTAssetsToValue(toTrancheUnits(_units)));
    }

    /// @dev The backward conversion, NAV units to collateral vault shares, sizing the collateral leg of a
    ///      claim the way production scales a redeemer's proportional slice
    function _quoteNAVToCollateralUnits(uint256 _nav) internal view returns (uint256) {
        return toUint256(kernel.convertValueToCollateralAssets(toNAVUnits(_nav)));
    }

    /// @dev The backward conversion, NAV units to pool tokens, sizing the venue slice a liquidity
    ///      redemption burns at the committed pool mark
    function _quoteNAVToLPTUnits(uint256 _nav) internal view returns (uint256) {
        return toUint256(kernel.convertValueToLPTAssets(toNAVUnits(_nav)));
    }

    /**
     * @dev Mirrors a tranche share mint for revert prediction, covering the two uint256 overflow cliffs
     *      production retains once the zero-NAV dilution branch has inflated a supply (mint-dilution
     *      clamped): the clamp's cap computation supply × (WAD − ε)/ε no longer fitting in
     *      uint256 (the residual cliff), and the ERC20 total-supply increment overflowing on the mint
     *      itself. Production reverts both with Panic(0x11). The mirror routes its own identical,
     *      identically-ordered math through an external self-call so the overflow is caught and returned
     *      as a prediction instead of aborting the op
     * @return shares The shares the mint would produce (zero when the mint must panic)
     * @return mintPanics True when the production mint must revert with Panic(0x11)
     */
    function _mirrorMintShares(uint256 _value, uint256 _totalValue, uint256 _supply) internal view returns (uint256 shares, bool mintPanics) {
        try this.runSharesForMirror(_value, _totalValue, _supply) returns (uint256 shares_) {
            // The mint adds the shares to the tranche's total supply, which must itself stay within uint256
            if (shares_ > type(uint256).max - _supply) return (0, true);
            return (shares_, false);
        } catch {
            return (0, true);
        }
    }

    /**
     * @dev The in-handler supply bound over deposit sizing: degrades a deposit to one tranche-unit wei
     *      whenever its share mint would panic or carry the tranche supply past the campaign bound (see
     *      TRANCHE_SUPPLY_CAMPAIGN_BOUND for the derivation). The one-unit deposit still exercises the
     *      production path it degraded from - including the 1-wei-denominator dilution branch, whose
     *      mint then at most doubles the supply - and its own reverts stay covered by the executors'
     *      predictions, so nothing is skipped
     */
    function _clampSupplySafeDeposit(uint256 _assets, uint256 _value, uint256 _totalValue, uint256 _supply) internal view returns (uint256) {
        (uint256 shares, bool mintPanics) = _mirrorMintShares(_value, _totalValue, _supply);
        // No overflow risk in the sum: a non-panicking mint already guarantees supply + shares fits
        if (mintPanics || _supply + shares > TRANCHE_SUPPLY_CAMPAIGN_BOUND) return 1;
        return _assets;
    }

    /**
     * @dev Credits an operation tail's idle premium deployment, measured at the pool's own senior balance.
     *      Every kernel operation entrypoint ends in withLiquidityPremiumReinvestment, which deploys the
     *      entire idle pile once the op settles, so across an in-kind op the pool's senior balance can only
     *      grow, and it grows by exactly the tail's deployment (the op itself never moves pool senior shares)
     */
    function _recordTailDeployment(uint256 _poolSenior0) internal {
        uint256 poolSenior1 = seniorTranche.balanceOf(address(balancerVault));
        _flag(poolSenior1 >= _poolSenior0, "an in-kind operation removed senior shares from the pool");
        uint256 deployed = poolSenior1 > _poolSenior0 ? poolSenior1 - _poolSenior0 : 0;
        ghost_liquidityPremiumSharesReinvested += deployed;
        ghost_stSharesDeployedSinceLastPriceCheck += deployed;
    }

    /// @dev Adds one selector to the op's allowed revert set
    function _expect(Pred memory _p, bytes4 _sel) internal pure {
        _p.sels[_p.n++] = _sel;
    }

    /// @dev Checks an observed revert against the op's allowed set, recording a violation on a miss
    function _classify(string memory _op, bytes memory _err, Pred memory _p) internal {
        bytes4 sel = _err.length >= 4 ? bytes4(_err) : bytes4(0);
        for (uint256 i; i < _p.n; ++i) {
            if (_p.sels[i] == sel) {
                ghost_opPredictedReverts[keccak256(bytes(_op))]++;
                return;
            }
        }
        _flag(false, string.concat(_op, ": unpredicted revert with selector ", vm.toString(bytes32(sel))));
    }

    /// @dev Records a successful op execution
    function _recordSuccess(string memory _op) internal {
        ghost_opSuccesses[keccak256(bytes(_op))]++;
    }

    /// @dev Records an op invocation, making a never-scheduled op detectable after the run
    function _recordCall(string memory _op) internal {
        ghost_opCalls[keccak256(bytes(_op))]++;
    }

    /// @dev Records a violation without reverting, so the sequence that produced it is preserved
    function _flag(bool _condition, string memory _what) internal {
        if (!_condition) {
            ghost_violationCount++;
            if (bytes(ghost_violation).length == 0) ghost_violation = _what;
        }
    }
}
