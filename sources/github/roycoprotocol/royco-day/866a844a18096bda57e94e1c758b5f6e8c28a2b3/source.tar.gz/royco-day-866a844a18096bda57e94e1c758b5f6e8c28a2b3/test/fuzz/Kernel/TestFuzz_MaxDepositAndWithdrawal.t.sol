// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { Math } from "../../../lib/openzeppelin-contracts/contracts/utils/math/Math.sol";
import { IRoycoDayAccountant } from "../../../src/interfaces/IRoycoDayAccountant.sol";
import { IRoycoDayKernel } from "../../../src/interfaces/IRoycoDayKernel.sol";
import { WAD } from "../../../src/libraries/Constants.sol";
import { toTrancheUnits, toUint256 } from "../../../src/libraries/Units.sol";
import { MarketFuzzTestBase } from "../../utils/MarketFuzzTestBase.sol";
import { RoycoTestMath } from "../../utils/RoycoTestMath.sol";

/**
 * @title TestFuzz_MaxDepositAndWithdrawal_Kernel
 * @notice Fuzzes the three gated max deposit/withdrawal reads through the full production stack (tranche -> kernel -> accountant):
 *         executing exactly the reported max succeeds and leaves both the coverage and liquidity gates at or below
 *         100%, and one wei (or share) beyond the max plus its derived dust slack reverts on the derived gate
 * @dev Every market is seeded flat at a 1.0 vault rate and 1.0 prices, so one vault-share wei == one BPT wei ==
 *      one NAV wei on the seed. Default parameters throughout: 20% minimum coverage, 5% minimum liquidity, the
 *      single 1 wei collateral NAV dust tolerance. The senior-deposit max is a NAV amount and stays exact integer
 *      algebra, but the two redemption maxes are SHARE counts: maxRedeem converts its NAV bound to shares through
 *      the virtual-shares offset primitive (supply + VIRTUAL_SHARES over claimNAV + VIRTUAL_VALUE), so shares and
 *      NAV no longer coincide. Each redemption gate binds on the WITHDRAWN NAV (floor(claimNAV x shares / (supply + 1))),
 *      so the tests invert that floor to the largest gate-respecting share count and check one share past it reverts:
 *      - senior deposit: the single dustTolerance = 1 wei of NAV slack on each leg
 *      - junior redemption: the reported share max sits at or below the inverted coverage boundary sStar
 *      - liquidity redemption: the reported share max sits at or below the inverted liquidity boundary sStar
 */
contract TestFuzz_MaxDepositAndWithdrawal_Kernel is MarketFuzzTestBase {
    /**
     * Scenario: a flat seeded market reports its max senior deposit, the depositor fills exactly that capacity,
     * then consumes the dust slack up to the algebraic gate boundary, and the very next wei reverts on the gate
     * that binds. This is the no-overfill guarantee: the advertised max is achievable and nothing beyond the
     * boundary can enter.
     *
     * Derivation (flat marks collateralNAV = st + jt with stEffectiveNAV = st, jtEffectiveNAV = jt, lptRawNAV = depth,
     * exact because 0.2e18 and 0.05e18 divide WAD):
     *   coverage gate:  ceil((st + jt + d) * 0.2e18 / jt) <= WAD  <=>  d <= 4*jt - st            (covBound)
     *   liquidity gate: ceil((st + d) * 0.05e18 / depth) <= WAD   <=>  d <= 20*depth - st        (liqBound)
     *   reported max = min(covBound - dustTolerance, liqBound - dustTolerance) = min(covBound, liqBound) - 1
     * so the slack to the true boundary B = min(covBound, liqBound) is exactly 1 wei, and B + 1 wei must revert:
     * on the coverage error when covBound <= liqBound (coverage is checked first), else on the liquidity error.
     */
    function testFuzz_MaxSeniorDeposit_FillsCapacityExactlyAndOneMoreWeiReverts(uint256 _stSeed, uint256 _jtSeed, uint256 _extraQuoteSeed) public {
        uint256 st = bound(_stSeed, 1e18, 1e27); // uniform over 9 orders of magnitude of senior seed size
        uint256 jt = bound(_jtSeed, st / 2, 2 * st); // uniform coverage ratios from 2:1 to 1:2, always seedable (needs jt >= st/4)
        // uniform extra pool depth from 1 quote wei to ~4x the senior NAV, sweeping which leg (coverage or liquidity) binds
        uint256 extraQuote = bound(_extraQuoteSeed, 1, 4 * st / QUOTE_TO_NAV_SCALE);
        uint256 depth = _seedFlatMarket(st, jt, extraQuote);

        // The algebraic gate boundaries and the production max with its dust slack (derivation above)
        uint256 covBound = 4 * jt - st;
        uint256 liqBound = 20 * depth - st;
        uint256 expectedMax = Math.min(covBound, liqBound) - 1;
        uint256 reportedMax = toUint256(seniorTranche.maxDeposit(ST_PROVIDER));
        assertEq(reportedMax, expectedMax, "reported max senior deposit must equal min(4jt - st, 20depth - st) - 1");
        assertEq(RoycoTestMath.maxSTDeposit(st + jt, st, jt, depth, 0.2e18, 0.05e18, 1), expectedMax, "independent mirror must agree with the reported max");

        // Filling exactly the reported max must succeed and leave both gates at or below 100%
        _depositSenior(reportedMax);
        IRoycoDayAccountant.RoycoDayAccountantState memory acct = accountant.getState();
        assertEq(toUint256(acct.lastCollateralNAV), st + jt + reportedMax, "the max deposit must land wei-exactly on the collateral mark");
        assertLe(
            RoycoTestMath.computeCoverageUtilization(st + jt + reportedMax, 0.2e18, jt),
            WAD,
            "coverage utilization must hold at or below 100% after filling the max"
        );
        assertLe(
            RoycoTestMath.computeLiquidityUtilization(st + reportedMax, 0.05e18, depth),
            WAD,
            "liquidity utilization must hold at or below 100% after filling the max"
        );

        // Consuming the dust slack lands exactly on the algebraic boundary and still passes
        uint256 boundary = Math.min(covBound, liqBound);
        uint256 slack = boundary - reportedMax;
        _depositSenior(slack);
        assertEq(toUint256(accountant.getState().lastCollateralNAV), st + jt + boundary, "the slack deposit must land exactly on the algebraic gate boundary");
        assertLe(
            RoycoTestMath.computeCoverageUtilization(st + jt + boundary, 0.2e18, jt),
            WAD,
            "coverage utilization must sit at or below 100% exactly at the boundary"
        );
        assertLe(
            RoycoTestMath.computeLiquidityUtilization(st + boundary, 0.05e18, depth),
            WAD,
            "liquidity utilization must sit at or below 100% exactly at the boundary"
        );

        // One wei past the boundary trips whichever gate binds: coverage is checked before liquidity, so the
        // coverage error surfaces whenever covBound <= liqBound, otherwise only liquidity is violated
        bytes4 expectedError =
            covBound <= liqBound ? IRoycoDayKernel.COVERAGE_REQUIREMENT_VIOLATED.selector : IRoycoDayKernel.LIQUIDITY_REQUIREMENT_VIOLATED.selector;
        vm.expectRevert(expectedError);
        seniorTranche.previewDeposit(toTrancheUnits(uint256(1)));
        stJtVault.mintShares(ST_PROVIDER, 1);
        vm.prank(ST_PROVIDER);
        stJtVault.approve(address(seniorTranche), 1);
        vm.expectRevert(expectedError);
        vm.prank(ST_PROVIDER);
        seniorTranche.deposit(toTrancheUnits(uint256(1)), ST_PROVIDER);
    }

    /**
     * Scenario: the junior LP redeems exactly its reported max, then consumes the remaining dust-and-fudge slack
     * up to the algebraic coverage boundary, and one more share reverts on the coverage gate. This guarantees the
     * junior tranche can always exit down to the senior tranche's required coverage floor but never through it.
     *
     * Algebraic boundary (flat marks, the junior supply == jt effNAV, but redeeming s shares withdraws
     * floor(jt * s / (jt + VIRTUAL_SHARES)) NAV under the redemption-side offset; a JT withdrawal removes its
     * NAV from the coinvested collateral too):
     *   post-redemption coverage gate for a total withdrawal w: ceil((st + jt - w) * 0.2e18 / (jt - w)) <= WAD
     *   <=> 4w <= 4*jt - st <=> w <= floor((4jt - st)/4). Inverting the withdrawn-NAV floor at that boundary gives the
     *   largest gate-respecting share count sStar; the dust-held-back reported max sits at or below it, and one share
     *   past sStar withdraws boundary + 1 NAV and reverts on coverage. The independent mirror pins the reported max.
     */
    function testFuzz_MaxJuniorRedemption_DrainsCoverageSurplusAndOneMoreShareReverts(uint256 _stSeed, uint256 _jtSeed) public {
        uint256 st = bound(_stSeed, 1e18, 1e27); // uniform over 9 orders of magnitude of senior seed size
        uint256 jt = bound(_jtSeed, st / 2, 2 * st); // uniform coverage ratios from 2:1 to 1:2, surplus always positive
        _seedFlatMarket(st, jt, 0);

        // The independent mirror pins the exact reported max. maxRedeem now converts the NAV bound to shares through
        // the offset-aware primitive (supply + VIRTUAL_SHARES over effNAV + VIRTUAL_VALUE), capped by the balance, so
        // the reported max is a SHARE count that no longer equals the withdrawable NAV 1:1 (flat seed: jt supply == jt effNAV)
        uint256 maxWithdrawNAV = RoycoTestMath.maxJTWithdrawal(st + jt, jt, 0.2e18, 1);
        uint256 reportedMax = juniorTranche.maxRedeem(JT_PROVIDER);
        assertEq(
            reportedMax,
            Math.min(juniorTranche.balanceOf(JT_PROVIDER), RoycoTestMath.convertToShares(maxWithdrawNAV, jt, jt)),
            "independent mirror must agree with the reported max junior redemption"
        );

        // The coverage gate binds on the WITHDRAWN NAV, not the share count: redeeming s shares withdraws
        // floor(jt x s / (jt + VIRTUAL_SHARES)) NAV (flat marks, the junior claim is its effective NAV), and the
        // post-redemption coverage requirement caps that at w <= floor((4jt - st)/4). Inverting the floor at that
        // boundary gives the largest redeemable share count sStar; one share past it withdraws boundary + 1 NAV
        // and breaches coverage
        uint256 boundaryNAV = (4 * jt - st) / 4;
        uint256 sStar = ((boundaryNAV + 1) * (jt + 1) - 1) / jt;
        // The dust-held-back advisory max must never exceed the true coverage-bounded share max
        assertLe(reportedMax, sStar, "the reported max must not advertise past the true coverage-bounded share max");

        // One share past the true max makes the withdrawn NAV exceed floor((4jt - st)/4) and violates the coverage
        // requirement, from the preview and the execution alike (both from the untouched pre-redemption state, the
        // reverting calls mutate nothing)
        vm.expectRevert(IRoycoDayKernel.COVERAGE_REQUIREMENT_VIOLATED.selector);
        juniorTranche.previewRedeem(sStar + 1);
        vm.expectRevert(IRoycoDayKernel.COVERAGE_REQUIREMENT_VIOLATED.selector);
        vm.prank(JT_PROVIDER);
        juniorTranche.redeem(sStar + 1, JT_PROVIDER, JT_PROVIDER);

        // Redeeming exactly the true max succeeds and leaves the coverage gate at or below 100%, with the withdrawn NAV
        // landing on or just under the algebraic boundary (the offset granularity may leave it a wei short of exact)
        vm.prank(JT_PROVIDER);
        juniorTranche.redeem(sStar, JT_PROVIDER, JT_PROVIDER);
        uint256 jtEffAfter = toUint256(accountant.getState().lastJTEffectiveNAV);
        assertLe(jt - jtEffAfter, boundaryNAV, "the max redemption's withdrawn NAV must respect the algebraic coverage boundary");
        assertLe(
            RoycoTestMath.computeCoverageUtilization(toUint256(accountant.getState().lastCollateralNAV), 0.2e18, jtEffAfter),
            WAD,
            "coverage utilization must hold at or below 100% after the max redemption"
        );
    }

    /**
     * Scenario: the liquidity LP redeems exactly its reported max, then the single wei of dust slack, and one
     * more share reverts on the liquidity gate. This is the no-run guarantee: pooled depth can be pulled down
     * to the senior tranche's required liquidity floor but never below it.
     *
     * Derivation (flat marks, NAV-per-BPT exactly 1.0, and the LPT supply == depth lptRawNAV on the seed, but redeeming s
     * shares withdraws floor(depth * s / (depth + VIRTUAL_SHARES)) NAV under the redemption-side offset):
     *   post-redemption liquidity gate for a total withdrawal w:
     *     ceil(st * 0.05e18 / (depth - w)) <= WAD  <=>  ceil(st/20) <= depth - w  <=>  w <= depth - ceil(st/20)
     *   Inverting the withdrawn-NAV floor at that boundary gives the largest gate-respecting share count sStar; the
     *   view's advisory max (its NAV bound depth - floor(st/20) - 1 converted to shares) sits at or below sStar, and one
     *   share past sStar drops the pool below the required floor ceil(st/20) and reverts on liquidity.
     */
    function testFuzz_MaxLiquidityRedemption_DrainsToLiquidityFloorAndOneMoreShareReverts(uint256 _stSeed, uint256 _jtSeed, uint256 _extraQuoteSeed) public {
        uint256 st = bound(_stSeed, 1e18, 1e27); // uniform over 9 orders of magnitude of senior seed size
        uint256 jt = bound(_jtSeed, st / 2, 2 * st); // uniform coverage ratios from 2:1 to 1:2 (coverage is not under test here)
        // uniform surplus depth from 1 quote wei to ~4x the senior NAV, so the withdrawable surplus varies widely
        uint256 extraQuote = bound(_extraQuoteSeed, 1, 4 * st / QUOTE_TO_NAV_SCALE);
        uint256 depth = _seedFlatMarket(st, jt, extraQuote);

        // The algebraic 5% liquidity floor the pool must retain, rounded up against the redeemer (no dust pad here)
        uint256 requiredFloor = (st + 19) / 20;

        // The independent mirror pins the exact reported max. maxRedeem converts the NAV bound to shares through the
        // offset-aware primitive (supply + VIRTUAL_SHARES over lptRawNAV + VIRTUAL_VALUE), capped by the balance, so the
        // reported max is a SHARE count that no longer equals the withdrawable NAV 1:1. The claim NAV is the pool depth
        // (depth == lptRawNAV), but the LPT SUPPLY no longer equals depth: the fresh auto-seed mints 1:1 while the
        // extraQuote seed mints through the offset, so the conversion must use the actual live LPT supply, not depth.
        uint256 supply = liquidityProviderTranche.totalSupply();
        uint256 maxWithdrawNAV = RoycoTestMath.maxLPTWithdrawal(depth, st, 0.05e18, 1); // == depth - floor(st/20) - 1
        uint256 reportedMax = liquidityProviderTranche.maxRedeem(LPT_PROVIDER);
        assertEq(
            reportedMax,
            Math.min(liquidityProviderTranche.balanceOf(LPT_PROVIDER), RoycoTestMath.convertToShares(maxWithdrawNAV, depth, supply)),
            "independent mirror must agree with the reported max"
        );

        // The liquidity gate binds on the WITHDRAWN BPT/NAV, not the share count: redeeming s shares withdraws
        // floor(depth x s / (supply + VIRTUAL_SHARES)) NAV (NAV-per-BPT is exactly 1.0, and the redeemer's slice scales
        // against supply + VIRTUAL_SHARES), and the pool must retain the 5% floor requiredFloor = ceil(st/20), so
        // withdrawn <= depth - requiredFloor. Inverting the floor at that boundary gives the largest redeemable share
        // count sStar; one share past it drops the pool below the floor
        uint256 boundaryNAV = depth - requiredFloor;
        uint256 sStar = ((boundaryNAV + 1) * (supply + 1) - 1) / depth;
        // The dust-held-back advisory max must never exceed the true liquidity-bounded share max
        assertLe(reportedMax, sStar, "the reported max must not advertise past the true liquidity-bounded share max");

        // One share past the true max drops the retained depth below the required floor and violates the liquidity
        // requirement, from the preview and the execution alike (both from the untouched pre-redemption state)
        vm.expectRevert(IRoycoDayKernel.LIQUIDITY_REQUIREMENT_VIOLATED.selector);
        liquidityProviderTranche.previewRedeem(sStar + 1);
        vm.expectRevert(IRoycoDayKernel.LIQUIDITY_REQUIREMENT_VIOLATED.selector);
        vm.prank(LPT_PROVIDER);
        liquidityProviderTranche.redeem(sStar + 1, LPT_PROVIDER, LPT_PROVIDER);

        // Redeeming exactly the true max succeeds and leaves the pool at or above the required liquidity floor
        vm.prank(LPT_PROVIDER);
        liquidityProviderTranche.redeem(sStar, LPT_PROVIDER, LPT_PROVIDER);
        uint256 lptRawAfter = toUint256(accountant.getState().lastLPTRawNAV);
        assertGe(lptRawAfter, requiredFloor, "the max redemption must leave the required liquidity floor in the pool");
        assertLe(
            RoycoTestMath.computeLiquidityUtilization(st, 0.05e18, lptRawAfter),
            WAD,
            "liquidity utilization must hold at or below 100% after the max redemption"
        );
    }

    /**
     * Scenario: crash the shared collateral price to an arbitrary depth (from no crash at all to a fully wiped
     * junior buffer), then attempt an arbitrary-size JT deposit. The deposit must settle strictly below the liquidation
     * coverage utilization or revert on the exact layered gate the mirror derives, so no gate can under- or over-fire.
     *
     * Mirror (the crash routes the whole loss through the junior buffer first, then the senior residual): the
     * post-crash mark is c1 = quote(1400e18) with stEff1 = min(1000e18, c1) and jtEff1 = c1 - stEff1. The deposit
     * re-marks the whole holding, so c2 = quote(1400e18 + a) and the settled buffer is jtEff1 + (c2 - c1). The gates
     * layer in execution order: a covered drawdown past the dust tolerance opens the JT observation period and
     * rejects on the fixed-term gate first (unless the buffer is wiped or the liquidation threshold is breached,
     * both of which force the market perpetual to keep senior exits open), then a deposit whose own quote floors
     * to zero rejects on the zero-share mint, and only then does the post-op liquidation gate decide
     */
    function testFuzz_JTDeposit_LiquidationGateFiresExactlyOnTheMirror(uint256 _rateSeed, uint256 _assetsSeed) public {
        _seedFlatMarket(1000e18, 400e18, 2e8);
        // Uniform from no crash at all to a 95% drawdown (any price at or below ~0.714 wipes the junior buffer)
        int256 bpsDrop = int256(bound(_rateSeed, 0, 9500));
        uint256 assets = bound(_assetsSeed, 1, 1e24);
        applySTPnL(-bpsDrop);
        uint256 liquidationThreshold = params.coverageLiquidationUtilizationWAD;

        // The mirror's post-crash and post-deposit marks from the kernel's live conversion (derivation above)
        uint256 c1 = toUint256(kernel.convertCollateralAssetsToValue(toTrancheUnits(uint256(1400e18))));
        uint256 jtEff1 = c1 - Math.min(1000e18, c1);
        uint256 c2 = toUint256(kernel.convertCollateralAssetsToValue(toTrancheUnits(1400e18 + assets)));
        uint256 depositValue = toUint256(kernel.convertCollateralAssetsToValue(toTrancheUnits(assets)));
        uint256 utilizationPre = RoycoTestMath.computeCoverageUtilization(c1, params.minCoverageWAD, jtEff1);
        uint256 utilizationAfter = RoycoTestMath.computeCoverageUtilization(c2, params.minCoverageWAD, jtEff1 + (c2 - c1));

        // The pre-op sync decides the market state the deposit is checked against: a covered above-dust drawdown
        // enters the JT observation period unless the wiped buffer or the breached threshold forces perpetual
        bool entersFixedTerm = (1400e18 - c1) > params.dustTolerance && jtEff1 != 0 && utilizationPre < liquidationThreshold;

        stJtVault.mintShares(JT_PROVIDER, assets);
        vm.startPrank(JT_PROVIDER);
        stJtVault.approve(address(juniorTranche), assets);
        if (entersFixedTerm) {
            // The observation period rejects every JT deposit before size or the liquidation gate can matter
            vm.expectRevert(IRoycoDayKernel.DISABLED_IN_FIXED_TERM_STATE.selector);
            juniorTranche.deposit(toTrancheUnits(assets), JT_PROVIDER);
        } else if (depositValue == 0) {
            // A deposit that quotes to zero value prices to zero shares and rejects before the post-op gate
            vm.expectRevert(IRoycoDayKernel.MUST_MINT_NON_ZERO_SHARES.selector);
            juniorTranche.deposit(toTrancheUnits(assets), JT_PROVIDER);
        } else if (utilizationAfter >= liquidationThreshold) {
            // A sub-curing deposit into the bonus regime reverts on the gate
            vm.expectRevert(IRoycoDayKernel.JT_DEPOSIT_BLOCKED_DURING_LIQUIDATION.selector);
            juniorTranche.deposit(toTrancheUnits(assets), JT_PROVIDER);
        } else {
            // Every other deposit settles, and the settled marks sit strictly below the liquidation threshold
            uint256 mintedShares = juniorTranche.deposit(toTrancheUnits(assets), JT_PROVIDER);
            assertGt(mintedShares, 0, "a settled JT deposit must mint shares");
            IRoycoDayAccountant.RoycoDayAccountantState memory acct = accountant.getState();
            assertLt(
                RoycoTestMath.computeCoverageUtilization(toUint256(acct.lastCollateralNAV), params.minCoverageWAD, toUint256(acct.lastJTEffectiveNAV)),
                liquidationThreshold,
                "a settled JT deposit must leave the market strictly below the liquidation threshold"
            );
        }
        vm.stopPrank();
    }
}
