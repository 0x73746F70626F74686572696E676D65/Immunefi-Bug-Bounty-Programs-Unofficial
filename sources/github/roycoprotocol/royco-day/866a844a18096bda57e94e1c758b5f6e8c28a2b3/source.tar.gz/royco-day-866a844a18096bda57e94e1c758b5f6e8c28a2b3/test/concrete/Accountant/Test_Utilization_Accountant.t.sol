// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { IRoycoDayAccountant } from "../../../src/interfaces/IRoycoDayAccountant.sol";
import { WAD, ZERO_NAV_UNITS } from "../../../src/libraries/Constants.sol";
import { MarketState, Operation, SyncedAccountingState } from "../../../src/libraries/Types.sol";
import { toNAVUnits } from "../../../src/libraries/Units.sol";
import { toUint256 } from "../../../src/libraries/Units.sol";
import { AccountantTestBase } from "../../utils/AccountantTestBase.sol";

/**
 * @title Test_Utilization_Accountant
 * @notice The coverage and liquidity utilization computations on the post-op surface: the zero
 *         short-circuits and their precedence over the max edges, ceil bias exactness, the whole collateral
 *         NAV in the coverage numerator, and the pre-op placeholder versus post-op fresh-value contract
 * @notice The accountant does not enforce the coverage or liquidity requirement: it returns the computed
 *         utilizations and the kernel reverts past WAD. These tests assert the returned value the kernel gate
 *         would act on, never a revert from the accountant
 */
contract Test_Utilization_Accountant is AccountantTestBase {
    function setUp() public {
        stranger = makeAddr("stranger");
        _deploy(_defaultParams());
    }

    /**
     * zero minimum requirements short-circuit both utilizations to 0 before any max edge can fire —
     * a live collateral NAV against a zero junior buffer and zero market-making inventory reads (0, 0), so
     * the deposit reads utilizations the kernel gate lets through
     */
    function test_Utilization_bothZeroWhenMinimumRequirementsZero() public {
        IRoycoDayAccountant.RoycoDayAccountantInitParams memory p = _defaultParams();
        p.minCoverageWAD = 0;
        p.minLiquidityWAD = 0;
        _deploy(p);
        SyncedAccountingState memory state = kernel.doPostOp(Operation.ST_DEPOSIT, toNAVUnits(uint256(100e18)), ZERO_NAV_UNITS, ZERO_NAV_UNITS);
        assertEq(state.coverageUtilizationWAD, 0, "zero minimum coverage short-circuits before the empty-buffer max edge");
        assertEq(state.liquidityUtilizationWAD, 0, "zero minimum liquidity short-circuits before the empty-inventory max edge");
    }

    /**
     * a zero collateral NAV reads a zero coverage utilization and a zero senior effective NAV reads
     * a zero liquidity utilization, each taking precedence over its own zero-denominator max edge, so a
     * market drained by a full senior redemption reads (0, 0) instead of (max, max)
     */
    function test_Utilization_zeroCollateralAndZeroSTEffectivePrecedeMaxEdges() public {
        kernel.doPostOp(Operation.ST_DEPOSIT, toNAVUnits(uint256(100e18)), ZERO_NAV_UNITS, ZERO_NAV_UNITS);
        SyncedAccountingState memory state = kernel.doPostOp(Operation.ST_REDEMPTION, ZERO_NAV_UNITS, ZERO_NAV_UNITS, ZERO_NAV_UNITS);
        assertEq(state.coverageUtilizationWAD, 0, "zero collateral NAV so coverage utilization is zero, preceding the empty-buffer max edge");
        assertEq(state.liquidityUtilizationWAD, 0, "zero senior effective NAV precedes the zero-inventory max edge");
    }

    /**
     * a live collateral NAV against a zero junior buffer reads a uint256 max coverage utilization, and live
     * senior value against a zero market-making inventory reads a uint256 max liquidity utilization — the
     * value the kernel coverage gate would reject the next senior deposit on
     */
    function test_Utilization_bothMaxWhenBuffersZero() public {
        SyncedAccountingState memory state = kernel.doPostOp(Operation.ST_DEPOSIT, toNAVUnits(uint256(100e18)), ZERO_NAV_UNITS, ZERO_NAV_UNITS);
        assertEq(state.coverageUtilizationWAD, type(uint256).max, "zero junior buffer against live collateral reads max");
        assertEq(state.liquidityUtilizationWAD, type(uint256).max, "zero inventory against live senior value reads max");
        // The accountant does not enforce, so the next senior deposit still settles and reads max coverage, the would-breach value the kernel gate rejects
        SyncedAccountingState memory next = kernel.doPostOp(Operation.ST_DEPOSIT, toNAVUnits(uint256(100e18 + 1)), ZERO_NAV_UNITS, ZERO_NAV_UNITS);
        assertEq(next.coverageUtilizationWAD, type(uint256).max, "the deeper senior deposit reads max coverage, the value the kernel gate rejects");
    }

    /**
     * ceil bias exactness on awkward values against independent math — each utilization matches the
     * spec formula and satisfies util * denominator >= product > (util - 1) * denominator
     */
    function test_Utilization_ceilBiasExactness() public {
        _seedState(SEED_ST_EFF, 300e18, 0, 100e18, MarketState.PERPETUAL);
        SyncedAccountingState memory state =
            kernel.doPostOp(Operation.ST_DEPOSIT, toNAVUnits(SEED_ST_EFF + 300e18 + 7), toNAVUnits(uint256(100e18)), ZERO_NAV_UNITS);
        uint256 coverageUtilization = state.coverageUtilizationWAD;
        uint256 covProduct = (SEED_ST_EFF + 300e18 + 7) * uint256(DEFAULT_MIN_COVERAGE_WAD);
        assertEq(
            coverageUtilization, _specCoverageUtilization(SEED_ST_EFF + 300e18 + 7, DEFAULT_MIN_COVERAGE_WAD, 300e18), "coverage matches the independent ceil"
        );
        assertGe(coverageUtilization * 300e18, covProduct, "coverage ceil bias covers the exact product");
        assertLt((coverageUtilization - 1) * 300e18, covProduct, "coverage ceil tightness, one less would under-cover");
        uint256 liquidityUtilization = state.liquidityUtilizationWAD;
        uint256 liqProduct = (SEED_ST_EFF + 7) * uint256(DEFAULT_MIN_LIQUIDITY_WAD);
        assertEq(liquidityUtilization, _specLiquidityUtilization(SEED_ST_EFF + 7, DEFAULT_MIN_LIQUIDITY_WAD, 100e18), "liquidity matches the independent ceil");
        assertGe(liquidityUtilization * 100e18, liqProduct, "liquidity ceil bias covers the exact product");
        assertLt((liquidityUtilization - 1) * 100e18, liqProduct, "liquidity ceil tightness, one less would under-cover");
    }

    /**
     * the coverage numerator is the whole coinvested collateral NAV, the junior share included
     * Derivation: after a 50e18 junior deposit, ceil(1250e18 * 0.1e18 / 250e18) = 0.5e18,
     * while a numerator excluding the junior share (the senior effective NAV alone) would read
     * ceil(1000e18 * 0.1e18 / 250e18) = 0.4e18
     */
    function test_Utilization_coverageNumeratorIsWholeCollateralNAV() public {
        _seedFlatWithLPT(SEED_LPT_RAW);
        SyncedAccountingState memory state =
            kernel.doPostOp(Operation.JT_DEPOSIT, toNAVUnits(SEED_ST_EFF + 250e18), toNAVUnits(SEED_LPT_RAW), ZERO_NAV_UNITS);
        assertEq(state.coverageUtilizationWAD, 0.5e18, "coverage numerator is the whole collateral NAV");
    }

    /**
     * a zero minimum liquidity reads zero even against a zero market-making inventory, taking precedence
     * over the zero-inventory max edge, so the senior deposit reads a liquidity utilization the kernel gate lets through
     */
    function test_Utilization_liquidityZeroWhenMinLiquidityZero() public {
        IRoycoDayAccountant.RoycoDayAccountantInitParams memory p = _defaultParams();
        p.minLiquidityWAD = 0;
        _deploy(p);
        _seedFlatWithLPT(0);
        SyncedAccountingState memory state =
            kernel.doPostOp(Operation.ST_DEPOSIT, toNAVUnits(SEED_ST_EFF + SEED_JT_EFF + 100e18), ZERO_NAV_UNITS, ZERO_NAV_UNITS);
        assertEq(state.liquidityUtilizationWAD, 0, "zero minimum liquidity precedes the zero-inventory max edge");
        assertLe(state.coverageUtilizationWAD, WAD, "coverage gate satisfied on its own terms");
    }

    /// a zero market-making inventory against a live requirement reads uint256 max, the value the kernel liquidity gate rejects
    function test_Utilization_liquidityMaxWhenLPTRawZero() public {
        _seedFlatWithLPT(0);
        SyncedAccountingState memory state =
            kernel.doPostOp(Operation.ST_DEPOSIT, toNAVUnits(SEED_ST_EFF + SEED_JT_EFF + 10e18), ZERO_NAV_UNITS, ZERO_NAV_UNITS);
        assertEq(state.liquidityUtilizationWAD, type(uint256).max, "zero inventory against a live requirement reads max");
        // The accountant does not enforce, so a deeper senior deposit still settles and reads max liquidity, the would-breach value the kernel gate rejects
        SyncedAccountingState memory next = kernel.doPostOp(Operation.ST_DEPOSIT, toNAVUnits(SEED_ST_EFF + SEED_JT_EFF + 11e18), ZERO_NAV_UNITS, ZERO_NAV_UNITS);
        assertEq(next.liquidityUtilizationWAD, type(uint256).max, "the deeper senior deposit reads max liquidity, the value the kernel gate rejects");
    }

    /**
     * the pre-op returned state carries zero placeholders for the liquidity raw NAV and utilization (the
     * kernel refreshes them after committing the fresh mark) without clobbering the committed liquidity mark,
     * while the post-op returns the fresh real values
     */
    function test_Utilization_preOpPlaceholdersAndPostOpFreshValues() public {
        _seedFlatWithLPT(SEED_LPT_RAW);
        SyncedAccountingState memory preOpState = kernel.doPreOp(toNAVUnits(SEED_ST_EFF + SEED_JT_EFF));
        assertEq(toUint256(preOpState.lptRawNAV), 0, "pre-op lt raw NAV is a zero placeholder");
        assertEq(preOpState.liquidityUtilizationWAD, 0, "pre-op liquidity utilization is a zero placeholder");
        assertEq(toUint256(accountant.getState().lastLPTRawNAV), SEED_LPT_RAW, "the placeholder never clobbers the committed lt mark");

        // The post-op returns the freshly marked liquidity values: liquidityUtilization = ceil(1010e18 * 0.05e18 / 100e18) = 0.505e18
        SyncedAccountingState memory postOpState =
            kernel.doPostOp(Operation.ST_DEPOSIT, toNAVUnits(SEED_ST_EFF + SEED_JT_EFF + 10e18), toNAVUnits(SEED_LPT_RAW), ZERO_NAV_UNITS);
        assertEq(toUint256(postOpState.lptRawNAV), SEED_LPT_RAW, "post-op returns the real lt raw NAV");
        assertEq(postOpState.liquidityUtilizationWAD, 0.505e18, "post-op returns the fresh liquidity utilization");
    }
}
