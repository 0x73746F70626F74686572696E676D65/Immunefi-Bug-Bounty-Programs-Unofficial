// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { AssetClaims } from "../../../src/libraries/Types.sol";
import { toUint256 } from "../../../src/libraries/Units.sol";
import { EntryPointTestBase } from "../../utils/EntryPointTestBase.sol";
import { defaultParams } from "../../utils/MarketParams.sol";
import { cellA } from "../../utils/TokenConfigs.sol";

/**
 * @title TestFuzz_EntryPointAmountsAndBonuses
 * @notice Fuzzes the entry point's conservation properties over request amounts and executor bonus rates: escrow
 *         accounting balances exactly, third-party bonus splits conserve the total claims, and a flat queued
 *         request is economically identical to a direct tranche interaction
 */
contract TestFuzz_EntryPointAmountsAndBonuses is EntryPointTestBase {
    uint256 internal stUnit;

    function setUp() public {
        _deployMarket(cellA(), defaultParams());
        stUnit = 10 ** uint256(cell.collateralAsset.decimals);
        _seedMarket(1000 * stUnit, 500 * stUnit);
        _deployEntryPoint();
    }

    /// @notice A flat queued deposit mints exactly what a direct tranche deposit of the same amount mints
    function testFuzz_flatQueuedDeposit_equalsDirectDeposit(uint256 _assets) public {
        _assets = bound(_assets, 1e6, 100 * stUnit);

        (uint256 nonce,) = _requestDeposit(USER_A, address(juniorTranche), _assets, USER_A, 0);
        _warpPastDepositDelay();
        uint256 queuedShares = _executeDepositMax(USER_A, USER_A, nonce);

        uint256 directShares = _acquireTrancheShares(USER_B, address(juniorTranche), _assets);
        assertEq(queuedShares, directShares, "a flat queued deposit must mint exactly the direct-deposit shares");
        assertEq(entryPoint.getProtocolFeeSharesPendingCollection(address(juniorTranche)), 0, "a flat queue must forfeit nothing");
    }

    /// @notice Third-party deposit execution conserves the mint: bonus shares + receiver shares == the user's minted
    ///         shares exactly, and the full asset escrow reaches the tranche (the bonus never touches the assets)
    function testFuzz_thirdPartyDeposit_bonusConservation(uint256 _assets, uint64 _bonusWAD) public {
        _assets = bound(_assets, 1e6, 100 * stUnit);
        // The request-time validation enforces strictly-below-100% bonuses
        _bonusWAD = uint64(bound(_bonusWAD, 0, 1e18 - 1));

        (uint256 nonce,) = _requestDeposit(USER_A, address(juniorTranche), _assets, USER_A, _bonusWAD);
        _warpPastDepositDelay();

        uint256 executorBefore = juniorTranche.balanceOf(EXECUTOR);
        uint256 receiverBefore = juniorTranche.balanceOf(USER_A);
        uint256 escrowBefore = stJtVault.balanceOf(address(entryPoint));
        uint256 userShares = _executeDepositMax(EXECUTOR, USER_A, nonce);

        uint256 executorDelta = juniorTranche.balanceOf(EXECUTOR) - executorBefore;
        uint256 receiverDelta = juniorTranche.balanceOf(USER_A) - receiverBefore;
        // The executor's bonus is the flooring share fraction of the user's post-forfeiture mint
        assertEq(executorDelta, (userShares * _bonusWAD) / 1e18, "the bonus must be the flooring share fraction of the user's minted shares");
        // Conservation: a single bonus floor splits the mint wei-exactly between the executor and receiver
        assertEq(executorDelta + receiverDelta, userShares, "bonus shares plus receiver shares must equal the minted shares exactly");
        assertEq(escrowBefore - stJtVault.balanceOf(address(entryPoint)), _assets, "the full escrow must leave the entry point");
        // Nothing is stranded: the entry point holds only the forfeited protocol fee shares
        assertEq(
            juniorTranche.balanceOf(address(entryPoint)),
            entryPoint.getProtocolFeeSharesPendingCollection(address(juniorTranche)),
            "only forfeited fee shares may remain in the entry point"
        );
    }

    /// @notice Third-party redemption execution conserves claims: executor slice + receiver slice == total delivered
    function testFuzz_thirdPartyRedemption_claimConservation(uint256 _assets, uint64 _bonusWAD) public {
        _assets = bound(_assets, 1e6, 100 * stUnit);
        _bonusWAD = uint64(bound(_bonusWAD, 0, 1e18 - 1));

        uint256 shares = _acquireTrancheShares(USER_A, address(juniorTranche), _assets);
        (uint256 nonce,) = _requestRedemption(USER_A, address(juniorTranche), shares, USER_B, _bonusWAD);
        _warpPastRedemptionDelay();

        uint256 executorBefore = stJtVault.balanceOf(EXECUTOR);
        uint256 receiverBefore = stJtVault.balanceOf(USER_B);
        AssetClaims memory userClaims = _executeRedemptionMax(EXECUTOR, USER_A, nonce);

        uint256 executorDelta = stJtVault.balanceOf(EXECUTOR) - executorBefore;
        uint256 receiverDelta = stJtVault.balanceOf(USER_B) - receiverBefore;
        assertEq(receiverDelta, toUint256(userClaims.collateralAssets), "the receiver must get exactly the reported user claims");
        assertEq(stJtVault.balanceOf(address(entryPoint)), 0, "no claim assets may remain in the entry point");
        // The executor's slice is the plain flooring bonus fraction of the total delivered (the entry point's
        // bonus scale carries no virtual-shares offset). Conservation of the ACTUAL claim holds exactly (remit sets
        // the receiver leg to total-minus-bonus with no re-conversion), and with the single collateral leg there is
        // exactly ONE bonus floor, so the split is wei-exact
        assertEq(executorDelta, ((executorDelta + receiverDelta) * _bonusWAD) / 1e18, "the bonus split must conserve the total claims exactly");
    }

    /// @notice Escrow accounting is exact for any partial execution amount
    function testFuzz_partialDepositExecution_escrowAccounting(uint256 _assets, uint256 _slice) public {
        _assets = bound(_assets, 1e6, 100 * stUnit);
        _slice = bound(_slice, 1, _assets);

        (uint256 nonce,) = _requestDeposit(USER_A, address(juniorTranche), _assets, USER_A, 0);
        _warpPastDepositDelay();
        _executeDeposit(USER_A, USER_A, nonce, _slice);

        assertEq(toUint256(entryPoint.getDepositRequest(USER_A, nonce).assets), _assets - _slice, "the remaining escrow must be tracked exactly");
        assertEq(stJtVault.balanceOf(address(entryPoint)), _assets - _slice, "the entry point's asset balance must equal the remaining escrow");
    }

    /// @notice Cancellation always returns exactly the unexecuted escrow, for any partial execution prefix
    function testFuzz_cancelAfterPartial_returnsExactRemainder(uint256 _assets, uint256 _slice) public {
        _assets = bound(_assets, 1e6, 100 * stUnit);
        _slice = bound(_slice, 1, _assets - 1);

        (uint256 nonce,) = _requestDeposit(USER_A, address(juniorTranche), _assets, USER_A, 0);
        _warpPastDepositDelay();
        _executeDeposit(USER_A, USER_A, nonce, _slice);

        uint256 balanceBefore = stJtVault.balanceOf(USER_A);
        _cancelDeposit(USER_A, nonce, USER_A);
        assertEq(stJtVault.balanceOf(USER_A) - balanceBefore, _assets - _slice, "the cancel must return exactly the unexecuted remainder");
    }
}
