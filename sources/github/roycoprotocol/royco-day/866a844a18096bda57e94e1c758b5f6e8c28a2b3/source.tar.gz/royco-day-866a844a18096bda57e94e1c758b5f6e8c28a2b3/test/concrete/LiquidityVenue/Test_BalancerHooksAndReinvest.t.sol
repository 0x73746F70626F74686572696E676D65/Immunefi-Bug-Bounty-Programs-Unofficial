// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { Vm } from "../../../lib/forge-std/src/Vm.sol";
import { IRoycoDayKernel } from "../../../src/interfaces/IRoycoDayKernel.sol";
import { IRoycoVaultTranche } from "../../../src/interfaces/IRoycoVaultTranche.sol";
import { AssetClaims } from "../../../src/libraries/Types.sol";
import { toTrancheUnits, toUint256 } from "../../../src/libraries/Units.sol";
import { MockBPTOracle } from "../../mocks/MockBPTOracle.sol";
import { DayMarketTestBase } from "../../utils/DayMarketTestBase.sol";
import { defaultParams } from "../../utils/MarketParams.sol";
import { cellA } from "../../utils/TokenConfigs.sol";

/**
 * @title Test_ReinvestLiquidityPremiumGate_Kernel
 * @notice The liquidity premium reinvestment's slippage gate: the minimum-BPT-out floor pinned from both sides of the
 *         exact boundary, the partial-amount path that deploys only part of the idle pile, and two edges where the
 *         gate's fair-value floor degrades — rounding to zero (the add runs unprotected) and dividing by a zero
 *         oracle TVL (every tranche operation reverts)
 * @dev The gate is the manipulation defense on the single-sided add: a venue fill one wei under it must be a
 *      tolerated no-op (the idle liquidity premium senior shares stay claimable), a fill exactly at it must deploy
 */
contract Test_ReinvestLiquidityPremiumGate_Kernel is DayMarketTestBase {
    function setUp() public virtual {
        _deployMarket(cellA(), defaultParams());
    }

    /**
     * @notice The gate floors the add at exactly 0.999e18 BPT for the seeded pile (hand-derived below), pinned from
     *         BOTH sides: a venue minting exactly one wei less defers (tolerated failure, idle pile and committed
     *         state untouched), a venue minting exactly the floor deploys the entire pile with its event
     * @dev Attacker intent: park the venue's fill exactly at the threshold to check the comparison direction, an
     *      off-by-one here either strands healthy reinvestments or accepts a sandwiched fill one wei too poor
     */
    function test_ReinvestLiquidityPremium_MinBptOutBoundary_BothSides() public {
        uint256 idleShares = _accrueIdlePremiumSeniorShares();
        _assertSeededGateFixture(idleShares);

        // The gate's floor, hand-derived from the pinned fixture state rather than by re-running the production
        // conversion chain: the whole idle pile values through the offset-aware _convertToValue to
        // floor((108e18 + 1) x 846660395108184383 / (101599247412982126057 + 1)) = 899999999999999999 at the committed
        // senior rate (the offset on the idle count and the supply cancels, so the value is unchanged from the naive ratio),
        // the 0.9e18 NET premium it was minted for (the 1e18 gross premium less the 0.1e18 LPT protocol fee), less a single
        // floor-rounding wei. The pool's NAV per BPT is exactly 1.0 (6.000001e18 BPT backing 6.000001e18 of value), so the
        // fair BPT is that same figure, and the 0.1% max reinvestment slippage discount floors the add at
        // ceil(899999999999999999 x 999 / 1000) = 899100000000000000
        uint256 minOut = 0.8991e18;

        uint256 lptOwnedBefore = toUint256(kernel.getState().totalLPTAssets);
        uint256 committedLptRawNAVBefore = toUint256(accountant.getState().lastLPTRawNAV);

        // Side 1: one wei under the gate, the inner add reverts, the failure is tolerated, and NOTHING moves
        balancerVault.setNextBptOutOverride(minOut - 1);
        vm.prank(MARKET_REINVEST_LIQUIDITY_PREMIUM_ADMIN);
        kernel.reinvestLiquidityPremium(type(uint256).max);
        assertEq(kernel.getState().lptOwnedSeniorTrancheShares, idleShares, "under the gate: the idle pile must be untouched");
        assertEq(toUint256(kernel.getState().totalLPTAssets), lptOwnedBefore, "under the gate: no BPT may be credited");
        assertEq(toUint256(accountant.getState().lastLPTRawNAV), committedLptRawNAVBefore, "under the gate: the committed LPT raw NAV must be unmoved");

        // Side 2: exactly the gate, the entire pile deploys, exactly minOut BPT is credited, and the event fires
        balancerVault.setNextBptOutOverride(minOut);
        vm.expectEmit(address(kernel));
        emit IRoycoDayKernel.LiquidityPremiumReinvested(idleShares, toTrancheUnits(minOut));
        vm.prank(MARKET_REINVEST_LIQUIDITY_PREMIUM_ADMIN);
        kernel.reinvestLiquidityPremium(type(uint256).max);
        assertEq(kernel.getState().lptOwnedSeniorTrancheShares, 0, "at the gate: the entire idle pile must deploy");
        assertEq(toUint256(kernel.getState().totalLPTAssets), lptOwnedBefore + minOut, "at the gate: exactly minOut BPT must be credited");
    }

    /**
     * @notice A partial reinvestment deploys only the requested senior shares and leaves the remainder idle and
     *         claimable, with the event carrying the exact partial amounts
     * @dev The remainder staying in lptOwnedSeniorTrancheShares is what keeps a redeeming LPT holder whole on the
     *      undeployed slice, so a partial deploy that silently zeroed the pile would burn the premium
     */
    function test_ReinvestLiquidityPremium_PartialAmount_LeavesRemainderIdle() public {
        uint256 idleShares = _accrueIdlePremiumSeniorShares();
        _assertSeededGateFixture(idleShares);

        // Deploy the floor-rounded half of the pinned pile: 846660395108184383 / 2 = 423330197554092191
        uint256 half = 423_330_197_554_092_191;

        // The gate's floor for the half, hand-derived from the pinned fixture state through the offset-aware
        // _convertToValue: the half values to floor((108e18 + 1) x 423330197554092191 / (101599247412982126057 + 1))
        // = 449999999999999999 at the committed senior rate (half the NET premium less a floor-rounding wei), the pool's
        // NAV per BPT is exactly 1.0 so the fair BPT is the same figure, and the 0.1% discount floors the add at
        // ceil(449999999999999999 x 999 / 1000) = 449550000000000000
        uint256 minOut = 0.44955e18;

        uint256 lptOwnedBefore = toUint256(kernel.getState().totalLPTAssets);

        balancerVault.setNextBptOutOverride(minOut);
        vm.expectEmit(address(kernel));
        emit IRoycoDayKernel.LiquidityPremiumReinvested(half, toTrancheUnits(minOut));
        vm.prank(MARKET_REINVEST_LIQUIDITY_PREMIUM_ADMIN);
        kernel.reinvestLiquidityPremium(half);

        assertEq(kernel.getState().lptOwnedSeniorTrancheShares, idleShares - half, "the undeployed remainder must stay idle and claimable");
        assertEq(toUint256(kernel.getState().totalLPTAssets), lptOwnedBefore + minOut, "exactly the partial add's BPT must be credited");
    }

    /**
     * @notice When the oracle's fair-value floor rounds to zero, the reinvestment defers: the add is skipped and the
     *         premium shares stay idle and claimable, exactly as a breached gate leaves them
     * @dev The gate marks the staged premium to its fair BPT as floor(bptSupply x premiumValue / TVL) discounted by
     *      the slippage tolerance. Once the pool's TVL dwarfs the premium's value that floor rounds to 0, and
     *      ceil(0 x 999 / 1000) is still 0. A zero floor would send minBptAmountOut = 0 to the venue — no slippage
     *      protection at all — so rather than let a ~1e18-value pile clear for as little as 1 wei, the reinvestment
     *      returns early and leaves the shares idle. This is the exact regime where a sandwich costs the LPT the most
     *      relative to what it receives, so deferring is the safe outcome.
     */
    function test_ReinvestLiquidityPremium_ZeroMinOutFloor_DefersAddAndLeavesSharesIdle() public {
        uint256 idleShares = _accrueIdlePremiumSeniorShares();
        _assertSeededGateFixture(idleShares);

        // Sync once more: the +10% gain is already committed, so this sync accrues no new premium and the reinvest
        // call's own internal pre-op sync below also mints nothing, leaving the idle pile intact for the explicit reinvestment
        vm.prank(SYNC_OPERATOR);
        kernel.syncTrancheAccounting();
        assertEq(kernel.getState().lptOwnedSeniorTrancheShares, idleShares, "arrange: the no-gain sync must not touch the idle pile");

        // Pin the oracle to a TVL that rounds the fair-value floor to zero. The pile values to under 1e18 NAV
        // (899999999999999999, the net premium pinned above) and the BPT supply is 6.000001e18, so the fair-BPT
        // numerator bptSupply x premiumValue is under 5.5e36, any TVL above that rounds floor(numerator / TVL) to 0,
        // and 1e40 clears the boundary by more than a thousandfold
        bptOracle.setMode(MockBPTOracle.Mode.MANUAL);
        bptOracle.setTVL(1e40);

        uint256 lptOwnedBefore = toUint256(kernel.getState().totalLPTAssets);

        // With a zero fair-value floor the reinvestment returns early before any venue add: it never reaches the
        // Vault, so no fill can occur and the idle pile is left untouched
        vm.prank(MARKET_REINVEST_LIQUIDITY_PREMIUM_ADMIN);
        kernel.reinvestLiquidityPremium(idleShares);

        assertEq(kernel.getState().lptOwnedSeniorTrancheShares, idleShares, "the idle pile stays idle and claimable when the fair-value floor rounds to zero");
        assertEq(toUint256(kernel.getState().totalLPTAssets), lptOwnedBefore, "no BPT is credited: the zero-floor add is deferred, not executed");
    }

    // =============================
    // Helpers
    /**
     * @notice A cold standalone reinvestment stages the premium accrued since the last sync into the pile, deploys
     *         the ENTIRE enlarged pile, and re-commits the LPT raw NAV at the post-deployment venue state
     * @dev The cache-miss path: outside an operation's price frame the rate cache is cleared, so the standalone
     *      entrypoint syncs first (staging the pending premium and producing the fresh rate) and then deploys.
     *      The re-commit afterward is load-bearing: the deployment settles after the sync's commit, so without it
     *      the committed depth would understate the freshly deployed market-making inventory
     */
    function test_ReinvestLiquidityPremium_ColdCall_StagesAccruedPremiumDeploysAndRecommits() public {
        uint256 stagedPile = _accrueIdlePremiumSeniorShares();

        // Accrue a second premium window WITHOUT syncing, so the standalone call's own sync must stage it
        _warpAndRefreshFeed(1 days);
        applySTPnL(1000);

        // Measure what the cold call's internal sync will stage, on a snapshot that is always reverted
        uint256 snap = vm.snapshotState();
        vm.prank(SYNC_OPERATOR);
        kernel.syncTrancheAccounting();
        uint256 enlargedPile = kernel.getState().lptOwnedSeniorTrancheShares;
        vm.revertToState(snap);
        assertGt(enlargedPile, stagedPile, "arrange: the unsynced window must carry pending premium to stage");

        uint256 poolSenior0 = seniorTranche.balanceOf(address(balancerVault));
        uint256 totalLPT0 = toUint256(kernel.getState().totalLPTAssets);

        // The cold call syncs (staging the pending premium), deploys the entire enlarged pile, and re-commits
        vm.prank(MARKET_REINVEST_LIQUIDITY_PREMIUM_ADMIN);
        kernel.reinvestLiquidityPremium(type(uint256).max);

        assertEq(kernel.getState().lptOwnedSeniorTrancheShares, 0, "the entire enlarged pile must deploy");
        assertEq(
            seniorTranche.balanceOf(address(balancerVault)) - poolSenior0,
            enlargedPile,
            "the pool must receive exactly the staged pile plus the newly staged premium"
        );
        uint256 totalLPTAfter = toUint256(kernel.getState().totalLPTAssets);
        assertGt(totalLPTAfter, totalLPT0, "the deployment must credit freshly minted BPT to the ledger");
        // The re-commit: the committed depth must price the post-deployment ledger at the post-deployment venue mark
        assertEq(
            toUint256(accountant.getState().lastLPTRawNAV),
            toUint256(kernel.convertLPTAssetsToValue(toTrancheUnits(totalLPTAfter))),
            "the committed LPT raw NAV must reflect the freshly deployed inventory at the live mark"
        );
    }

    /**
     * @notice An operation's tail and a cold standalone call deploy identically from the same settled state
     * @dev The tail consumes the operation frame's cached senior rate while the standalone call resyncs for a
     *      fresh one, but on identical settled state both must value the pile the same and mint the same BPT.
     *      A junior deposit is the probe operation: it moves neither the senior rate nor the pool, so its tail
     *      deploys from exactly the state the standalone path sees
     */
    function test_ReinvestLiquidityPremium_TailAndColdCall_DeployIdenticallyFromSameState() public {
        _accrueIdlePremiumSeniorShares();

        // Path 1: a junior deposit whose settled tail deploys the pile at the frame's cached rate
        uint256 snap = vm.snapshotState();
        _depositInkind(juniorTranche, JT_PROVIDER, 1e18);
        uint256 tailBptOut = toUint256(kernel.getState().totalLPTAssets);
        uint256 tailIdleAfter = kernel.getState().lptOwnedSeniorTrancheShares;
        vm.revertToState(snap);

        // Path 2: the standalone cold call at the identical state
        vm.prank(MARKET_REINVEST_LIQUIDITY_PREMIUM_ADMIN);
        kernel.reinvestLiquidityPremium(type(uint256).max);

        assertEq(tailIdleAfter, 0, "the tail must deploy the entire pile");
        assertEq(kernel.getState().lptOwnedSeniorTrancheShares, 0, "the standalone call must deploy the entire pile");
        assertEq(toUint256(kernel.getState().totalLPTAssets), tailBptOut, "both paths must mint identical BPT from the same settled state");
    }

    /**
     * @notice A gated (deferring) tail reinvestment never blocks the operation that carries it: the deposit
     *         settles, the pile stays idle and claimable, and no reinvestment event fires
     * @dev The tail tolerates its inner add's revert by design, so an armed venue haircut converts the
     *      deployment into a no-op instead of failing the user's operation
     */
    function test_InKindOperation_SettlesWhileTailReinvestmentDefers() public {
        uint256 idleShares = _accrueIdlePremiumSeniorShares();
        // Re-arm the punitive haircut so the tail's gated add deterministically defers
        setVenueSlippageMode(true);

        vm.recordLogs();
        uint256 minted = _depositInkind(seniorTranche, ST_PROVIDER, 1e18);
        assertGt(minted, 0, "the deposit must settle despite the deferring tail");
        assertEq(kernel.getState().lptOwnedSeniorTrancheShares, idleShares, "the pile must stay idle and claimable through the deferral");

        // No reinvestment event may fire on a deferred tail
        Vm.Log[] memory logs = vm.getRecordedLogs();
        for (uint256 i = 0; i < logs.length; i++) {
            assertTrue(
                logs[i].topics[0] != IRoycoDayKernel.LiquidityPremiumReinvested.selector, "a deferred tail must not emit LiquidityPremiumReinvested"
            );
        }
    }

    // =============================

    /// @dev Funds and executes an in-kind vault-share deposit on the given tranche as the given provider
    function _depositInkind(IRoycoVaultTranche _tranche, address _provider, uint256 _assets) internal returns (uint256 shares) {
        stJtVault.mintShares(_provider, _assets);
        vm.startPrank(_provider);
        stJtVault.approve(address(_tranche), _assets);
        shares = _tranche.deposit(toTrancheUnits(_assets), _provider);
        vm.stopPrank();
    }

    /**
     * @dev Accrues an idle liquidity premium senior share pile: arm venue slippage so the sync's reinvestment
     *      attempt defers, accrue senior gain across a real time window, sync, then disarm so the boundary tests
     *      control the venue's mint exactly via the one-shot override. Returns the idle lptOwnedSeniorTrancheShares
     */
    function _accrueIdlePremiumSeniorShares() internal returns (uint256 idleShares) {
        _seedMarket(100e18, 50e18);

        // The first sync initializes the premium accrual clock
        vm.prank(SYNC_OPERATOR);
        kernel.syncTrancheAccounting();

        // Arm the 50% unbalanced haircut so the gated reinvestment deterministically fails and the premium stays idle
        setVenueSlippageMode(true);

        // Accrue senior gain across a real time window, then sync: the LPT premium mints as idle senior shares
        _warpAndRefreshFeed(1 days);
        applySTPnL(1000); // +10%
        vm.prank(SYNC_OPERATOR);
        kernel.syncTrancheAccounting();

        idleShares = kernel.getState().lptOwnedSeniorTrancheShares;
        assertGt(idleShares, 0, "arrange: the premium must be idle (venue slippage armed)");

        setVenueSlippageMode(false);
    }

    /**
     * @dev Pins the exact post-accrual fixture state every hand-computed gate literal in this contract is derived
     *      from, so a fixture drift fails loudly here instead of silently invalidating a pinned floor.
     *      Derivation from the seeded market (100e18 senior, 50e18 junior, +10% vault rate over one day):
     *      - the collateral NAV moves 150e18 to 165e18 and the pro-rata attribution hands the senior side
     *        floor(15e18 x 100e18 / 150e18) = 10e18 of the gain, and the junior's pinned 20% risk
     *        premium routes 2e18 of it to the junior side, so the committed senior effective NAV is 108e18
     *      - the liquidity provider tranche's pinned 10% premium carves 1e18 out of the gain, and the 10% senior protocol
     *        fee takes 0.7e18 (10% of the 7e18 senior residual after the 2e18 and 1e18 carve-outs), so the
     *        retained senior NAV is 108e18 - 1e18 - 0.7e18 = 106.3e18
     *      - the 10% LPT protocol fee carves lptFee = floor(1e18 x 0.1e18 / WAD) = 0.1e18 out of the LPT premium, so
     *        the LPT is minted the NET premium and the protocol recipient is minted the ST fee PLUS that LPT fee, both
     *        as senior shares against the retained NAV and the pre-mint 100e18 supply
     *      - premium shares minted to the LPT (net of the LPT fee), through the offset-aware _convertToShares (numerator
     *        supply gains VIRTUAL_SHARES = 1, denominator gains VIRTUAL_VALUE = 1):
     *        floor((100e18 + 1) x (1e18 - 0.1e18) / (106.3e18 + 1)) = 846660395108184383 idle senior shares
     *      - fee shares minted to the protocol recipient (ST fee plus LPT fee):
     *        floor((100e18 + 1) x (0.7e18 + 0.1e18) / (106.3e18 + 1)) = 752587017873941674, so the senior supply lands at
     *        100e18 + 846660395108184383 + 752587017873941674 = 101599247412982126057 (no LPT tranche shares mint on a sync)
     *      - the pool holds 6.000001e18 BPT backing 6.000001e18 of quote-leg value (the 6e6-quote-wei auto-seed
     *        plus the genesis backing of the dead minimum supply), so its NAV per BPT is exactly 1.0
     */
    function _assertSeededGateFixture(uint256 _idleShares) internal view {
        assertEq(_idleShares, 846_660_395_108_184_383, "fixture pin: the idle premium pile");
        assertEq(toUint256(accountant.getState().lastSTEffectiveNAV), 108e18, "fixture pin: the committed senior effective NAV");
        assertEq(seniorTranche.totalSupply(), 101_599_247_412_982_126_057, "fixture pin: the post-mint senior supply");
        assertEq(balancerVault.totalSupply(address(bpt)), 6_000_001_000_000_000_000, "fixture pin: the pool's BPT supply");
        assertEq(bptOracle.computeTVL(), 6_000_001_000_000_000_000, "fixture pin: the pool's oracle TVL (NAV per BPT exactly 1.0)");
    }
}

/**
 * @title Test_MultiAssetPreviewParity_LiquidityProviderTranche
 * @notice Multi-asset LPT deposit and redeem preview parity: exact at zero venue fee, exact under a nonzero venue
 *         fee, and exact for the multi-asset redemption
 * @dev Preview-vs-execution parity is the one property a preview cannot prove about itself, so each test runs both
 *      paths in the same block and compares
 */
contract Test_MultiAssetPreviewParity_LiquidityProviderTranche is DayMarketTestBase {
    function setUp() public virtual {
        _deployMarket(cellA(), defaultParams());
    }

    /**
     * @notice Zero venue fee gives EXACT preview parity: a fair (fee-less) add leaves TVL-per-BPT unchanged, so the
     *         executed path's post-add mark equals the preview's discarded-quote pre-add mark and the share math
     *         coincides to the wei
     */
    function test_LPTDepositMultiAsset_PreviewParityExact_ZeroVenueFee() public {
        (uint256 previewShares, uint256 mintedShares) = _previewThenExecuteMultiAssetDeposit(5e18, 5e6);
        assertEq(mintedShares, previewShares, "zero venue fee: the multi-asset deposit preview must equal execution in the same block");
        assertGt(mintedShares, 0, "arrange: the deposit must be non-degenerate");
    }

    /**
     * @notice A nonzero venue fee keeps EXACT preview parity: the preview runs the real add through the venue via
     *         execute-and-revert, so the fee-haircut BPT and the post-add depositNAV mark are identical in both
     *         modes and the share math coincides to the wei
     * @dev This pins the migration away from the discarded-quote preview, which could only lower-bound execution
     *      under a fee because it marked the fresh BPT before the depositor's own fee accrued to TVL-per-BPT
     */
    function test_LPTDepositMultiAsset_PreviewParityExact_WithVenueFee() public {
        balancerVault.setUnbalancedFeeBps(30);
        (uint256 previewShares, uint256 mintedShares) = _previewThenExecuteMultiAssetDeposit(5e18, 5e6);
        assertEq(mintedShares, previewShares, "nonzero venue fee: the multi-asset deposit preview must equal execution in the same block");
        assertGt(mintedShares, 0, "arrange: the deposit must be non-degenerate");
    }

    /// @notice previewRedeemMultiAsset equals the executed redeemMultiAsset (senior tranche claims plus quote out), same block
    function test_LPTRedeemMultiAsset_PreviewMatchesExecution() public {
        _seedMarket(100e18, 50e18);
        _seedLPT(10e18, 0, 10e6); // quote-only LPT depth on top of the auto-seed

        uint256 lptShares = liquidityProviderTranche.balanceOf(LPT_PROVIDER) / 2;
        assertGt(lptShares, 0, "arrange: LPT_PROVIDER must hold shares to redeem");

        vm.startPrank(LPT_PROVIDER);
        (AssetClaims memory previewClaims, uint256 previewQuote) = liquidityProviderTranche.previewRedeemMultiAsset(lptShares);
        (AssetClaims memory claims, uint256 quoteOut) = liquidityProviderTranche.redeemMultiAsset(lptShares, 0, 0, LPT_PROVIDER, LPT_PROVIDER);
        vm.stopPrank();

        assertEq(quoteOut, previewQuote, "the quote leg preview must equal execution");
        assertEq(keccak256(abi.encode(claims)), keccak256(abi.encode(previewClaims)), "the senior tranche claims preview must equal execution");
    }

    // =============================
    // Helpers
    // =============================

    /**
     * @dev Seeds the market, refreshes the transient senior share rate cache (the seeding syncs above ran inside
     *      THIS test transaction and the last pre-op cache write predates the senior supply, so the venue would
     *      price the ST leg at the 1-wei floor, a state production never sees since every user interaction is its
     *      own transaction and syncs pre-op), then previews and executes the same multi-asset deposit in one block
     */
    function _previewThenExecuteMultiAssetDeposit(uint256 _collateralLeg, uint256 _quoteLeg) internal returns (uint256 previewShares, uint256 mintedShares) {
        _seedMarket(100e18, 50e18);
        vm.prank(SYNC_OPERATOR);
        kernel.syncTrancheAccounting();

        stJtVault.mintShares(LPT_PROVIDER, _collateralLeg);
        quoteToken.mint(LPT_PROVIDER, _quoteLeg);

        vm.startPrank(LPT_PROVIDER);
        stJtVault.approve(address(liquidityProviderTranche), _collateralLeg);
        quoteToken.approve(address(liquidityProviderTranche), _quoteLeg);
        (previewShares,) = liquidityProviderTranche.previewDepositMultiAsset(_collateralLeg, _quoteLeg);
        (mintedShares,) = liquidityProviderTranche.depositMultiAsset(_collateralLeg, _quoteLeg, 0, LPT_PROVIDER);
        vm.stopPrank();
    }
}
