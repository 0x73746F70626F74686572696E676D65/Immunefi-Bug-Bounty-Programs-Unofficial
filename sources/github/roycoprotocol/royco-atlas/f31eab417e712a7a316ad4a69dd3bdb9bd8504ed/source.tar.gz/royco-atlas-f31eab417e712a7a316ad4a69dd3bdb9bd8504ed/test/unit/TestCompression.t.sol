// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import "../RoycoTestBase.sol";

contract TestCompression is RoycoTestBase {
    address roycoAccount;

    function setUp() public override {
        // Setup wallets and Royco core contracts
        super.setUp();

        // Deploy the Royco Account
        address[] memory owners = new address[](1);
        owners[0] = ALICE_ADDRESS;
        SIGNERS.push(ALICE);

        vm.prank(ALICE_ADDRESS);
        (, roycoAccount) = ROYCO.deployRoycoAccount(owners, 1);
    }

    function testCompress() external {
        AbsoluteOrder memory order = AbsoluteOrder({
            nonce: type(uint32).max,
            roycoAccount: roycoAccount,
            taker: address(0xbBbBBBBbbBBBbbbBbbBbbbbBBbBbbbbBbBbbBBbB),
            targetMarketHash: keccak256(new bytes(12)),
            signalComparator: Comparator.NEQ,
            rhsSignalOperand: Operand(address(0), abi.encode(uint256(255))),
            signalConditionType: SignalConditionType.PRE_CONDITION,
            executionParams: abi.encode(hex"eeeeeeeeeeeeeeeeee"),
            quantity: type(uint256).max,
            expiry: uint40(block.timestamp),
            positionManager: address(0xdeaDDeADDEaDdeaDdEAddEADDEAdDeadDEADDEaD),
            positionManagerArgs: abi.encode("aaaaaaaaaaaaa"),
            preConditions: new Condition[](0),
            postConditions: new Condition[](0),
            feeToken: address(0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48),
            feeAmount: 255,
            feePaidByMaker: true,
            signature: new bytes(0)
        });

        // Sign the EIP-712 order hash
        bytes32 orderHash = ROYCO.hashOrder(order);
        order.signature = signOrderHash(orderHash, SIGNERS);

        console2.logBytes(abi.encode(order));

        console2.logBytes(ROYCO.compressOrder(order));
    }
}
