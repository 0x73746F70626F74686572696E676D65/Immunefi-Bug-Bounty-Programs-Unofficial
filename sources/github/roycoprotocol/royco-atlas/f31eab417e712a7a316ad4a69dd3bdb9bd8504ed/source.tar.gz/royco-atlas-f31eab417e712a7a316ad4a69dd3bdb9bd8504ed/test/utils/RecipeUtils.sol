pragma solidity ^0.8.0;

import { IERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol";
import { Recipe } from "../../src/core/common/Types.sol";
import { RoycoAccountHandler } from "../../src/core/royco-account/RoycoAccountHandler.sol";

contract RecipeUtils {
    function _buildAaveV3DepositRecipe(address _tokenAddress, address _aavePoolV3, address _roycoAccountHandler) internal pure returns (Recipe memory) {
        // Initialize commands and state
        bytes32[] memory commands = new bytes32[](4);
        bytes[] memory state = new bytes[](5);

        state[0] = abi.encode(_aavePoolV3);
        state[1] = abi.encode(_tokenAddress);
        state[2] = abi.encode(uint16(0));

        // GET address of the royco account executing the lend

        // STATICCALL
        uint8 f = uint8(0x02);

        // Input list: No arguments (END_OF_ARGS = 0xff)
        bytes6 inputData = hex"ffffffffffff";

        // Output specifier
        // 0xff ignores the output if any
        uint8 o = 0x03;

        // Encode args and add command to Recipe
        commands[0] = (bytes32(abi.encodePacked(bytes4(keccak256("roycoAccount()")), f, inputData, o, _roycoAccountHandler)));

        // GET amount to lend

        // STATICCALL
        f = uint8(0x02);

        // Input list: No arguments (END_OF_ARGS = 0xff)
        inputData = hex"ffffffffffff";

        // Output specifier
        // 0xff ignores the output if any
        o = 0x04;

        // Encode args and add command to Recipe
        commands[1] = (bytes32(abi.encodePacked(bytes4(keccak256("amount()")), f, inputData, o, _roycoAccountHandler)));

        // Approve tokens to aave pool

        // CALL
        f = uint8(0x01);

        // Input list: aave pool address, amount to lend
        inputData = hex"0004ffffffff";

        // Output specifier
        // 0xff ignores the output if any
        o = 0xff;

        // Encode args and add command to Recipe
        commands[2] = (bytes32(abi.encodePacked(IERC20.approve.selector, f, inputData, o, _tokenAddress)));

        // Supply Tokens to aave

        // CALL
        f = uint8(0x01);

        // Input list: address of token to supply, amount of asset to supply, wallet to receive aTokens (royco account), referal code (none == uint16(0))
        inputData = hex"01040302ffff";

        // Output specifier
        // 0xff ignores the output if any
        o = 0xff;

        // Encode args and add command to Recipe
        commands[3] = (bytes32(abi.encodePacked(bytes4(keccak256("supply(address,uint256,address,uint16)")), f, inputData, o, _aavePoolV3)));

        return Recipe(commands, state);
    }

    function _buildAaveV3WithdrawalRecipe(address _tokenAddress, address _aavePoolV3, address _roycoAccountHandler) internal pure returns (Recipe memory) {
        // Initialize commands and state
        bytes32[] memory commands = new bytes32[](3);
        bytes[] memory state = new bytes[](3);

        state[0] = abi.encode(_tokenAddress);

        // GET address of the royco account executing the lend

        // STATICCALL
        uint8 f = uint8(0x02);

        // Input list: No arguments (END_OF_ARGS = 0xff)
        bytes6 inputData = hex"ffffffffffff";

        // Output specifier
        // 0xff ignores the output if any
        uint8 o = 0x01;

        // Encode args and add command to Recipe
        commands[0] = (bytes32(abi.encodePacked(bytes4(keccak256("roycoAccount()")), f, inputData, o, _roycoAccountHandler)));

        // GET amount to lend

        // STATICCALL
        f = uint8(0x02);

        // Input list: No arguments (END_OF_ARGS = 0xff)
        inputData = hex"ffffffffffff";

        // Output specifier
        // 0xff ignores the output if any
        o = 0x02;

        // Encode args and add command to Recipe
        commands[1] = (bytes32(abi.encodePacked(bytes4(keccak256("amount()")), f, inputData, o, _roycoAccountHandler)));

        // Withdraw Tokens from aave

        // CALL
        f = uint8(0x01);

        // Input list: address of token to withdraw, amount of asset to withdraw, wallet to receive assets (royco account)
        inputData = hex"000201ffffff";

        // Output specifier
        // 0xff ignores the output if any
        o = 0xff;

        // Encode args and add command to Recipe
        commands[2] = (bytes32(abi.encodePacked(bytes4(keccak256("withdraw(address,uint256,address)")), f, inputData, o, _aavePoolV3)));

        return Recipe(commands, state);
    }

    function _buildAaveV3LiquidityQuery(address _aaveV3LiqQueryHelper, address _tokenAddress) internal pure returns (Recipe memory) {
        // Initialize commands and state
        bytes32[] memory commands = new bytes32[](1);
        bytes[] memory state = new bytes[](1);

        state[0] = abi.encode(_tokenAddress);

        // GET the max withdrawable assets for the msg.sender (royco account)

        // STATICCALL
        uint8 f = uint8(0x02);

        // Input list: address of token the query is for
        bytes6 inputData = hex"00ffffffffff";

        // Output specifier
        // 0xff ignores the output if any
        // Write it to index 0. Where all liq queries are mandated to store the result.
        uint8 o = 0x00;

        // Encode args and add command to Recipe
        commands[0] = (bytes32(abi.encodePacked(bytes4(keccak256("getMaxWithdrawableAssets(address)")), f, inputData, o, _aaveV3LiqQueryHelper)));

        return Recipe(commands, state);
    }

    function _buildMorphoBlueDepositRecipe(
        address _morphoBlue,
        address _roycoAccountHandler,
        address _loanToken,
        address _collateralToken,
        address _oracle,
        address _irm,
        uint256 _lltv
    )
        internal
        pure
        returns (Recipe memory)
    {
        // Initialize commands and state
        bytes32[] memory commands = new bytes32[](5);
        bytes[] memory state = new bytes[](10);

        state[0] = abi.encode(_morphoBlue);
        state[1] = abi.encode(_loanToken);
        state[2] = abi.encode(_collateralToken);
        state[3] = abi.encode(_oracle);
        state[4] = abi.encode(_irm);
        state[5] = abi.encode(_lltv);
        state[6] = abi.encode(uint256(0));
        state[7] = abi.encode(new bytes(0));

        // GET address of the royco account executing the lend

        // STATICCALL
        uint8 f = uint8(0x02);

        // Input list: No arguments (END_OF_ARGS = 0xff)
        bytes6 inputData = hex"ffffffffffff";

        // Output specifier
        // 0xff ignores the output if any
        uint8 o = 0x08;

        // Encode args and add command to Recipe
        commands[0] = (bytes32(abi.encodePacked(bytes4(keccak256("roycoAccount()")), f, inputData, o, _roycoAccountHandler)));

        // GET amount to lend

        // STATICCALL
        f = uint8(0x02);

        // Input list: No arguments (END_OF_ARGS = 0xff)
        inputData = hex"ffffffffffff";

        // Output specifier
        // 0xff ignores the output if any
        o = 0x09;

        // Encode args and add command to Recipe
        commands[1] = (bytes32(abi.encodePacked(bytes4(keccak256("amount()")), f, inputData, o, _roycoAccountHandler)));

        // Approve tokens to Morpho blue

        // CALL
        f = uint8(0x01);

        // Input list: Morpho Blue address, amount to lend
        inputData = hex"0009ffffffff";

        // Output specifier
        // 0xff ignores the output if any
        o = 0xff;

        // Encode args and add command to Recipe
        commands[2] = (bytes32(abi.encodePacked(IERC20.approve.selector, f, inputData, o, _loanToken)));

        // Supply Tokens to Morpho Blue

        // CALL
        // Extended command
        f = uint8(0x41);

        // Input list: next command has the input list encoded
        inputData = hex"ffffffffffff";

        // Output specifier
        // 0xff ignores the output if any
        o = 0xff;

        // Encode args and add command to Recipe
        commands[3] = (
            bytes32(
                abi.encodePacked(
                    bytes4(keccak256("supply((address,address,address,address,uint256),uint256,uint256,address,bytes)")), f, inputData, o, _morphoBlue
                )
            )
        );

        // Input list for the previous command
        commands[4] = hex"010203040509060887ffffffffffffffffffffffffffffffffffffffffffffff";

        return Recipe(commands, state);
    }

    function _buildMorphoBlueWithdrawalRecipe(
        address _morphoBlue,
        address _roycoAccountHandler,
        address _loanToken,
        address _collateralToken,
        address _oracle,
        address _irm,
        uint256 _lltv
    )
        internal
        pure
        returns (Recipe memory)
    {
        // Initialize commands and state
        bytes32[] memory commands = new bytes32[](4);
        bytes[] memory state = new bytes[](9);

        state[0] = abi.encode(_morphoBlue);
        state[1] = abi.encode(_loanToken);
        state[2] = abi.encode(_collateralToken);
        state[3] = abi.encode(_oracle);
        state[4] = abi.encode(_irm);
        state[5] = abi.encode(_lltv);
        state[6] = abi.encode(uint256(0));

        // GET address of the royco account executing the lend

        // STATICCALL
        uint8 f = uint8(0x02);

        // Input list: No arguments (END_OF_ARGS = 0xff)
        bytes6 inputData = hex"ffffffffffff";

        // Output specifier
        // 0xff ignores the output if any
        uint8 o = 0x07;

        // Encode args and add command to Recipe
        commands[0] = (bytes32(abi.encodePacked(bytes4(keccak256("roycoAccount()")), f, inputData, o, _roycoAccountHandler)));

        // GET amount to withdraw

        // STATICCALL
        f = uint8(0x02);

        // Input list: No arguments (END_OF_ARGS = 0xff)
        inputData = hex"ffffffffffff";

        // Output specifier
        // 0xff ignores the output if any
        o = 0x08;

        // Encode args and add command to Recipe
        commands[1] = (bytes32(abi.encodePacked(bytes4(keccak256("amount()")), f, inputData, o, _roycoAccountHandler)));

        // Withdraw Tokens from Morpho Blue

        // CALL
        // Extended command
        f = uint8(0x41);

        // Input list: next command has the input list encoded
        inputData = hex"ffffffffffff";

        // Output specifier
        // 0xff ignores the output if any
        o = 0xff;

        // Encode args and add command to Recipe
        commands[2] = (
            bytes32(
                abi.encodePacked(
                    bytes4(keccak256("withdraw((address,address,address,address,uint256),uint256,uint256,address,address)")), f, inputData, o, _morphoBlue
                )
            )
        );

        // Input list for the previous command
        commands[3] = hex"010203040508060707ffffffffffffffffffffffffffffffffffffffffffffff";

        return Recipe(commands, state);
    }

    function _buildMorphoBlueLiquidityQuery(
        address _morphoBlueLiqQueryHelper,
        address _loanToken,
        address _collateralToken,
        address _oracle,
        address _irm,
        uint256 _lltv
    )
        internal
        pure
        returns (Recipe memory)
    {
        // Initialize commands and state
        bytes32[] memory commands = new bytes32[](1);
        bytes[] memory state = new bytes[](5);

        state[0] = abi.encode(_loanToken);
        state[1] = abi.encode(_collateralToken);
        state[2] = abi.encode(_oracle);
        state[3] = abi.encode(_irm);
        state[4] = abi.encode(_lltv);

        // GET the max withdrawable assets for the msg.sender (royco account)

        // CALL
        uint8 f = uint8(0x01);

        // Input list: Morpho market params
        bytes6 inputData = hex"0001020304ff";

        // Output specifier
        // 0xff ignores the output if any
        // Write it to index 0. Where all liq queries are mandated to store the result.
        uint8 o = 0x00;

        // Encode args and add command to Recipe
        commands[0] = (
            bytes32(
                abi.encodePacked(
                    bytes4(keccak256("getMaxWithdrawableAssets((address,address,address,address,uint256))")), f, inputData, o, _morphoBlueLiqQueryHelper
                )
            )
        );

        return Recipe(commands, state);
    }
}
