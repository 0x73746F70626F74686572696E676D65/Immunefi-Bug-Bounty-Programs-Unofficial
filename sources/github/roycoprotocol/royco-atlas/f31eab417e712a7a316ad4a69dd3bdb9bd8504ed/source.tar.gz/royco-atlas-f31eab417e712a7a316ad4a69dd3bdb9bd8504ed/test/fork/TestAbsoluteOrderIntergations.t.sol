// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import "../RoycoTestBase.sol";

contract TestAbsoluteOrderIntergations is RoycoTestBase {
    address roycoAccount;

    function setUp() public override {
        mainnetFork = vm.createFork(MAINNET_RPC_URL);
        vm.selectFork(mainnetFork);

        // Setup wallets and Royco core contracts
        super.setUp();

        // Setup the mainnet Aave node, signal, and APR market
        setUpMainnetAaveMarket();

        // Setup the mainnet Morpho node, signal, and APR market
        setUpMainnetMorphoUsdcWBtcMarket();

        // Deploy the Royco Account
        address[] memory owners = new address[](1);
        owners[0] = ALICE_ADDRESS;
        SIGNERS.push(ALICE);

        vm.prank(ALICE_ADDRESS);
        (, roycoAccount) = ROYCO.deployRoycoAccount(owners, 1);
    }

    function testSimpleMorphoReallocationAtlasOrder(
        uint256 _initialRoycoAccountBalance,
        uint256 _nativeBalanceWeight,
        uint256 _aaveWeight,
        uint256 _fillAmount
    )
        external
    {
        _initialRoycoAccountBalance = bound(_initialRoycoAccountBalance, 100e6, 100_000_000e6);
        _nativeBalanceWeight = bound(_nativeBalanceWeight, 1, 10);
        _aaveWeight = bound(_aaveWeight, 1, 10);
        _fillAmount = bound(_fillAmount, 1e6, _initialRoycoAccountBalance - 1e6);

        uint256 totalWeight = _nativeBalanceWeight + _aaveWeight;

        uint256 roycoAccountBalance = (_initialRoycoAccountBalance * _nativeBalanceWeight) / totalWeight;
        uint256 aaveBalance = (_initialRoycoAccountBalance * _aaveWeight) / totalWeight;

        // Deal the account the amount of USDC
        deal(MAINNET_USDC, roycoAccount, _initialRoycoAccountBalance);

        // Deposit into the Aave node
        vm.prank(roycoAccount);
        ROYCO.deposit(SUPPLY_AAVE_USDC_NODE_HASH, aaveBalance, new bytes(0));

        // Pull from native balance first, then aave position
        bytes32[] memory positionQueue = new bytes32[](2);
        positionQueue[0] = bytes32(0);
        positionQueue[1] = SUPPLY_AAVE_USDC_NODE_HASH;

        // Get the signal value for the supply USDC to aave market
        Operand memory signal = ROYCO.getMarketSignal(SUPPLY_MORPHO_USDC_WBTC_APR_MARKET_HASH);
        (, bytes memory signalReturnData) = signal.target.call(signal.data);
        uint256 morphoSupplyAprRAY = abi.decode(signalReturnData, (uint256));

        // Morpho market RHS operand
        // Static value a bit less than what the signal is currently returning
        Operand memory rhsSignalOperand =
            Operand(address(0), abi.encode(uint256(morphoSupplyAprRAY - uint32(uint256(keccak256(abi.encode(_aaveWeight, _fillAmount)))))));

        // Marshal the absolute order
        AbsoluteOrder memory order = AbsoluteOrder({
            nonce: 0,
            roycoAccount: roycoAccount,
            taker: address(0),
            targetMarketHash: SUPPLY_MORPHO_USDC_WBTC_APR_MARKET_HASH,
            signalComparator: Comparator.GT,
            rhsSignalOperand: rhsSignalOperand,
            signalConditionType: SignalConditionType.PRE_CONDITION, // Since this is checked before, the lhs will always be gt rhs
            executionParams: new bytes(0),
            quantity: _initialRoycoAccountBalance, // Quantity is everything in the Royco Account
            expiry: type(uint40).max,
            positionManager: FIFO_POSITION_MANAGER,
            positionManagerArgs: abi.encode(positionQueue),
            preConditions: new Condition[](0),
            postConditions: new Condition[](0),
            feeToken: address(0),
            feeAmount: 0,
            feePaidByMaker: false,
            signature: new bytes(0)
        });

        // Sign the EIP-712 order hash
        order.signature = signOrderHash(ROYCO.hashOrder(order), SIGNERS);

        // Fill the order
        vm.prank(BOB_ADDRESS, BOB_ADDRESS);
        ROYCO.fillOrder(order, _fillAmount);

        // Execute the liquidity query
        vm.startPrank(address(ROYCO));
        uint256 morphoLiqQueryResult = ROYCO_MIDDLEWARE.executeLiquidityQuery(roycoAccount, SUPPLY_MORPHO_USDC_WBTC_NODE_HASH);
        uint256 aaveLiqQueryResult = ROYCO_MIDDLEWARE.executeLiquidityQuery(roycoAccount, SUPPLY_AAVE_USDC_NODE_HASH);
        vm.stopPrank();

        // The entire fill amount should be in morpho
        assertApproxEqRel(morphoLiqQueryResult, _fillAmount, 0.001e18);
        // The aave and account balance should be updated accordingly
        assertApproxEqRel(_fillAmount > roycoAccountBalance ? 0 : roycoAccountBalance - _fillAmount, IERC20(MAINNET_USDC).balanceOf(roycoAccount), 0.001e18);
        assertApproxEqRel(_fillAmount > roycoAccountBalance ? aaveBalance - (_fillAmount - roycoAccountBalance) : aaveBalance, aaveLiqQueryResult, 0.001e18);
    }
}
