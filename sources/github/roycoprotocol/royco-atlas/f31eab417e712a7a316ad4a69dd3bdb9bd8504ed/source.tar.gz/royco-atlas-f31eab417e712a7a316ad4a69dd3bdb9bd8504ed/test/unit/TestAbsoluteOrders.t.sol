// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import "../RoycoTestBase.sol";

contract TestAbsoluteOrders is RoycoTestBase {
    address roycoAccount;

    function setUp() public override {
        // Setup wallets and Royco core contracts
        super.setUp();

        // Deploy the Royco Account
        address[] memory owners = new address[](1);
        owners[0] = ALICE_ADDRESS;
        SIGNERS.push(ALICE);

        vm.prank(ALICE_ADDRESS);
        (, roycoAccount) = ROYCO.deployRoycoAccount(owners, 1);
    }

    function test_RevertIf_InvalidSig_TestAbsOrders(bytes memory _signature) external {
        // Marshal the absolute order
        AbsoluteOrder memory order = AbsoluteOrder({
            nonce: 0,
            roycoAccount: roycoAccount,
            taker: address(0),
            targetMarketHash: bytes32(0),
            signalComparator: Comparator.EQ,
            rhsSignalOperand: Operand(address(0), abi.encode(uint256(0))),
            signalConditionType: SignalConditionType.PRE_CONDITION,
            executionParams: new bytes(0),
            quantity: 0,
            expiry: type(uint40).max,
            positionManager: address(0),
            positionManagerArgs: new bytes(0),
            preConditions: new Condition[](0),
            postConditions: new Condition[](0),
            feeToken: address(0),
            feeAmount: 0,
            feePaidByMaker: false,
            signature: new bytes(0)
        });

        // Sign the EIP-712 order hash
        order.signature = _signature;

        vm.assume(keccak256(_signature) != keccak256(signOrderHash(ROYCO.hashOrder(order), SIGNERS)));

        vm.expectRevert();
        // Fill the order
        ROYCO.fillOrder(order, 0);
    }

    function test_RevertIf_Cancelled_TestAbsOrders(uint32 _nonce) external {
        // Marshal the absolute order
        AbsoluteOrder memory order = AbsoluteOrder({
            nonce: _nonce,
            roycoAccount: roycoAccount,
            taker: address(0),
            targetMarketHash: bytes32(0),
            signalComparator: Comparator.EQ,
            rhsSignalOperand: Operand(address(0), abi.encode(uint256(0))),
            signalConditionType: SignalConditionType.PRE_CONDITION,
            executionParams: new bytes(0),
            quantity: 0,
            expiry: type(uint40).max,
            positionManager: address(0),
            positionManagerArgs: new bytes(0),
            preConditions: new Condition[](0),
            postConditions: new Condition[](0),
            feeToken: address(0),
            feeAmount: 0,
            feePaidByMaker: false,
            signature: new bytes(0)
        });
        // Sign the EIP-712 order hash
        bytes32 orderHash = ROYCO.hashOrder(order);
        order.signature = signOrderHash(orderHash, SIGNERS);

        vm.prank(roycoAccount);
        ROYCO.cancelOrder(orderHash);

        vm.expectRevert(OrderProcessor.CancelledOrder.selector);
        // Fill the order
        ROYCO.fillOrder(order, 0);
    }

    function test_RevertIf_Expired_TestAbsOrders(uint40 _expiry) external {
        // Marshal the absolute order
        AbsoluteOrder memory order = AbsoluteOrder({
            nonce: 0,
            roycoAccount: roycoAccount,
            taker: address(0),
            targetMarketHash: bytes32(0),
            signalComparator: Comparator.EQ,
            rhsSignalOperand: Operand(address(0), abi.encode(uint256(0))),
            signalConditionType: SignalConditionType.PRE_CONDITION,
            executionParams: new bytes(0),
            quantity: 0,
            expiry: _expiry,
            positionManager: address(0),
            positionManagerArgs: new bytes(0),
            preConditions: new Condition[](0),
            postConditions: new Condition[](0),
            feeToken: address(0),
            feeAmount: 0,
            feePaidByMaker: false,
            signature: new bytes(0)
        });
        // Sign the EIP-712 order hash
        bytes32 orderHash = ROYCO.hashOrder(order);
        order.signature = signOrderHash(orderHash, SIGNERS);

        vm.warp(_expiry + uint128(uint256(orderHash)));

        vm.expectRevert(OrderProcessor.ExpiredOrder.selector);
        // Fill the order
        ROYCO.fillOrder(order, 0);
    }

    function test_RevertIf_InvalidTaker_TestAbsOrders(address _taker, address _whitelistedTaker) external {
        vm.assume(_taker != _whitelistedTaker && _whitelistedTaker != address(0));

        // Marshal the absolute order
        AbsoluteOrder memory order = AbsoluteOrder({
            nonce: 0,
            roycoAccount: roycoAccount,
            taker: _whitelistedTaker,
            targetMarketHash: bytes32(0),
            signalComparator: Comparator.EQ,
            rhsSignalOperand: Operand(address(0), abi.encode(uint256(0))),
            signalConditionType: SignalConditionType.PRE_CONDITION,
            executionParams: new bytes(0),
            quantity: 0,
            expiry: type(uint40).max,
            positionManager: address(0),
            positionManagerArgs: new bytes(0),
            preConditions: new Condition[](0),
            postConditions: new Condition[](0),
            feeToken: address(0),
            feeAmount: 0,
            feePaidByMaker: false,
            signature: new bytes(0)
        });
        // Sign the EIP-712 order hash
        bytes32 orderHash = ROYCO.hashOrder(order);
        order.signature = signOrderHash(orderHash, SIGNERS);

        vm.expectRevert(OrderProcessor.InvalidTaker.selector);
        // Fill the order
        vm.prank(_taker);
        ROYCO.fillOrder(order, 0);
    }
}
