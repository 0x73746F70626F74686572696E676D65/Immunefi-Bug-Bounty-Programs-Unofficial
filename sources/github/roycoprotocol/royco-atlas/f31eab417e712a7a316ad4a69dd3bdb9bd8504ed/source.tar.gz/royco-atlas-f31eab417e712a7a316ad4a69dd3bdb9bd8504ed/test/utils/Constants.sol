pragma solidity ^0.8.0;

contract Constants {
    // -----------------------------------------
    // SAFE
    // -----------------------------------------
    address constant MAINNET_SAFE_CANONICAL_SINGLETON = 0x41675C099F32341bf84BFc5382aF534df5C7461a;
    address constant MAINNET_SAFE_MULTISEND = 0xA238CBeb142c10Ef7Ad8442C6D1f9E89e07e7761;

    // -----------------------------------------
    // Tokens
    // -----------------------------------------
    address constant MAINNET_USDC = 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48;
    address constant MAINNET_AUSDC = 0x98C23E9d8f34FEFb1B7BD6a91B7FF122F4e16F5c;
    address constant MAINNET_WBTC = 0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599;

    // -----------------------------------------
    // Integrations
    // -----------------------------------------
    address constant AAVE_V3_POOL = 0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2;
    address constant AAVE_V3_POOL_DATA_PROVIDER = 0x497a1994c46d4f6C864904A9f1fac6328Cb7C8a6;
    address constant AAVE_V3_ORACLE = 0x54586bE62E3c3580375aE3723C145253060Ca0C2;

    address constant MORPHO = 0xBBBBBbbBBb9cC5e90e3b3Af64bdAF62C37EEFFCb;
    address constant MORPHO_ADAPTIVE_CURVE_IRM = 0x870aC11D48B15DB9a138Cf899d20F13F79Ba00BC;
    address constant MORPHO_WBTC_USDC_ORACLE = 0xDddd770BADd886dF3864029e4B377B5F6a2B6b83;
    uint256 constant MORPHO_WBTC_USDC_LLTV = 860_000_000_000_000_000;
}
