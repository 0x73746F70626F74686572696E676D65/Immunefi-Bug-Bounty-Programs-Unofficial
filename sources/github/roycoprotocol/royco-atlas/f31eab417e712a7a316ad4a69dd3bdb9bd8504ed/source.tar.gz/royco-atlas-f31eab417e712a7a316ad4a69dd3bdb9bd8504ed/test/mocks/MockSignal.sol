// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

contract MockSignal {
    function getRandomUintSignal() external view returns (uint256) {
        return uint256(keccak256(abi.encode(block.timestamp, msg.sender, block.number, msg.sig)));
    }

    function getRandomBooleanSignal() external view returns (uint256) {
        return uint256(keccak256(abi.encode(block.timestamp, msg.sender, block.number, msg.sig))) % 2;
    }
}
