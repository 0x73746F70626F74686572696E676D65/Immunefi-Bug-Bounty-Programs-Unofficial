// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import { Clones } from "../../lib/openzeppelin-contracts/contracts/proxy/Clones.sol";
import "../RoycoTestBase.sol";

contract TestRoycoAccountFactory is RoycoTestBase {
    using Clones for address;

    function testRoycoAccountDeployment(uint96 _numAccounts, address _user, uint256 _threshold) external prankModifier(_user) {
        _numAccounts = uint96(bound(uint256(_numAccounts), 1, 20));
        uint256 numOwners = bound(_threshold, 1, 20);
        _threshold = bound(numOwners, 1, numOwners);

        address[] memory owners = new address[](numOwners);
        for (uint256 i = 0; i < numOwners; ++i) {
            owners[i] = vm.addr(uint256(keccak256(abi.encodePacked(i, _numAccounts, _user, _threshold))));
        }

        for (uint256 i = 0; i < _numAccounts; ++i) {
            (uint96 expectedAccountId, address expectedSafeAddress) = ROYCO.getNextRoycoAccountCounterfactualAddress(_user);

            vm.expectEmit(true, false, false, true);
            emit RoycoAccountFactory.RoycoAccountDeployed(_user, expectedSafeAddress);

            (uint96 accountId, address roycoAccount) = ROYCO.deployRoycoAccount(owners, _threshold);

            assertEq(i, accountId);
            assertEq(expectedAccountId, accountId);
            assertEq(expectedSafeAddress, roycoAccount);
            address guard =
                abi.decode(ISafe(payable(roycoAccount)).getStorageAt(0x4a204f620c8c5ccdca3fd54d003badd85ba500436a431f0cbda4f558c93c34c8, 20), (address));
            assertEq(address(ROYCO_MIDDLEWARE), guard);
            assert(ISafe(payable(roycoAccount)).isModuleEnabled(address(ROYCO_MIDDLEWARE)));
            assert(ROYCO.roycoAccountToExists(roycoAccount));
        }
    }
}
