// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import "../RoycoTestBase.sol";

contract TestAaveV3Integration is RoycoTestBase {
    address roycoAccount;

    function setUp() public override {
        mainnetFork = vm.createFork(MAINNET_RPC_URL);
        vm.selectFork(mainnetFork);

        // Setup wallets and Royco core contracts
        super.setUp();

        // Setup the mainnet Aave node, signal, and market
        setUpMainnetAaveMarket();

        // Deploy the Royco Account
        address[] memory owners = new address[](1);
        owners[0] = ALICE_ADDRESS;
        vm.prank(ALICE_ADDRESS);
        (, roycoAccount) = ROYCO.deployRoycoAccount(owners, 1);
    }

    function testAaveV3Signal() external {
        Operand memory signal = ROYCO.getMarketSignal(SUPPLY_AAVE_USDC_APR_MARKET_HASH);
        (, bytes memory signalReturnData) = signal.target.call(signal.data);
        uint256 supplyAprRAY = abi.decode(signalReturnData, (uint256));
        assertGt(supplyAprRAY, 0);
    }

    function testDepositIntoAaveV3(uint256 _amountIn, uint256 _secondsToWarp) external {
        _amountIn = bound(_amountIn, 1000e6, 100_000_000e6);
        _secondsToWarp = bound(_secondsToWarp, 1 hours, 365 days);

        // Get the signal value for the supply USDC to aave market
        Operand memory signal = ROYCO.getMarketSignal(SUPPLY_AAVE_USDC_APR_MARKET_HASH);
        bytes memory signalReturnData;

        // Get the initial supply APR for USDC on Aave
        (, signalReturnData) = signal.target.call(signal.data);
        uint256 preDepositSupplyAprRAY = abi.decode(signalReturnData, (uint256));

        // Deal the account the amount of USDC
        deal(MAINNET_USDC, roycoAccount, _amountIn);

        vm.expectEmit();
        emit Royco.AccountDeposited(roycoAccount, SUPPLY_AAVE_USDC_NODE_HASH, _amountIn, new bytes(0));

        // Deposit into the aave node
        vm.prank(roycoAccount);
        ROYCO.deposit(SUPPLY_AAVE_USDC_NODE_HASH, _amountIn, new bytes(0));

        // Get the aUSDC balance of the Royco Account
        uint256 aTokenBalance = IERC20(MAINNET_AUSDC).balanceOf(roycoAccount);
        // Make sure it is equal to the amount deposited (max off by 1 BPS)
        assertApproxEqRel(aTokenBalance, _amountIn, 0.0001e18);

        // Execute the liquidity query
        vm.prank(address(ROYCO));
        uint256 originalQueryResult = ROYCO_MIDDLEWARE.executeLiquidityQuery(roycoAccount, SUPPLY_AAVE_USDC_NODE_HASH);
        // Ensure that it returns the number of aTokens minted to the royco account
        assertEq(originalQueryResult, aTokenBalance);

        // Ensure the supply APR signal value is less after
        (, signalReturnData) = signal.target.call(signal.data);
        uint256 postDepositSupplyAprRAY = abi.decode(signalReturnData, (uint256));
        assertLt(postDepositSupplyAprRAY, preDepositSupplyAprRAY);

        // Time travel by _secondsToWarp
        skip(_secondsToWarp);

        // Get the aUSDC balance of the Royco Account
        aTokenBalance = IERC20(MAINNET_AUSDC).balanceOf(roycoAccount);

        // Execute the liquidity query
        vm.prank(address(ROYCO));
        uint256 currentQueryResult = ROYCO_MIDDLEWARE.executeLiquidityQuery(roycoAccount, SUPPLY_AAVE_USDC_NODE_HASH);
        // Interest should've accrued, so current result should be greater
        assertGt(currentQueryResult, originalQueryResult);
        assertEq(aTokenBalance, currentQueryResult);
    }

    function testWithdrawFromAaveV3(uint256 _amountIn, uint256 _secondsToWarp) external {
        _amountIn = bound(_amountIn, 100e6, 100_000_000e6);
        _secondsToWarp = bound(_secondsToWarp, 1 hours, 365 days);

        // Deal the account the amount of USDC
        deal(MAINNET_USDC, roycoAccount, _amountIn);

        // Deposit into the aave node
        vm.prank(roycoAccount);
        ROYCO.deposit(SUPPLY_AAVE_USDC_NODE_HASH, _amountIn, new bytes(0));

        // Time travel by _secondsToWarp
        skip(_secondsToWarp);

        // Execute the liquidity query
        vm.prank(address(ROYCO));
        uint256 originalQueryResult = ROYCO_MIDDLEWARE.executeLiquidityQuery(roycoAccount, SUPPLY_AAVE_USDC_NODE_HASH);

        // Withdraw some amount bounded by max withdrawable
        uint256 amountOut = bound(_amountIn, 1e6, originalQueryResult);

        vm.expectEmit();
        emit Royco.AccountWithdrew(roycoAccount, SUPPLY_AAVE_USDC_NODE_HASH, amountOut);

        // Withdraw from the aave node
        vm.prank(roycoAccount);
        ROYCO.withdraw(SUPPLY_AAVE_USDC_NODE_HASH, amountOut);

        // Get the aUSDC balance of the Royco Account
        uint256 aTokenBalance = IERC20(MAINNET_AUSDC).balanceOf(roycoAccount);

        // Execute the liquidity query
        vm.prank(address(ROYCO));
        uint256 currentQueryResult = ROYCO_MIDDLEWARE.executeLiquidityQuery(roycoAccount, SUPPLY_AAVE_USDC_NODE_HASH);
        // Check that the correct amount was withdrawn and liq query is correctly configured
        assertApproxEqRel(currentQueryResult, originalQueryResult - amountOut, 0.01e18);
        assertEq(aTokenBalance, currentQueryResult);
    }
}
