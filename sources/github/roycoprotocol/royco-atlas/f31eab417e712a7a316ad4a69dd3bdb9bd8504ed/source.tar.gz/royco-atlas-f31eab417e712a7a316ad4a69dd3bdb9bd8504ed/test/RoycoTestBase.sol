// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import { Test, console2 } from "../lib/forge-std/src/Test.sol";
import { Vm } from "../lib/forge-std/src/Vm.sol";
import "../lib/safe-smart-account/contracts/Safe.sol";
import { CompatibilityFallbackHandler } from "../lib/safe-smart-account/contracts/handler/CompatibilityFallbackHandler.sol";
import { MultiSendCallOnly } from "../lib/safe-smart-account/contracts/libraries/MultiSendCallOnly.sol";
import "../src/core/Royco.sol";
import "../src/core/common/Types.sol";
import { AaveV3LiquidityQueryHelper } from "../src/periphery/liq-queries-helpers/AaveV3LiquidityQueryHelper.sol";
import { MorphoBlueLiquidityQueryHelper } from "../src/periphery/liq-queries-helpers/MorphoBlueLiquidityQueryHelper.sol";
import { FifoPositionManager } from "../src/periphery/position-managers/FifoPositionManager.sol";
import { AaveV3Signals } from "../src/periphery/signals/lending/AaveV3Signals.sol";
import { MarketParams, MorphoBlueSignals } from "../src/periphery/signals/lending/MorphoBlueSignals.sol";
import { MockERC20 } from "./mocks/MockERC20.sol";
import { Constants } from "./utils/Constants.sol";
import { RecipeUtils } from "./utils/RecipeUtils.sol";

contract RoycoTestBase is Test, RecipeUtils, Constants {
    // -----------------------------------------
    // Test Base State
    // -----------------------------------------
    Vm.Wallet internal OWNER;
    address internal OWNER_ADDRESS;

    Vm.Wallet internal ALICE;
    Vm.Wallet internal BOB;
    Vm.Wallet internal CHARLIE;
    Vm.Wallet internal DAN;

    address internal ALICE_ADDRESS;
    address internal BOB_ADDRESS;
    address internal CHARLIE_ADDRESS;
    address internal DAN_ADDRESS;

    Vm.Wallet[] internal SIGNERS;

    MockERC20 internal mockToken;

    // -----------------------------------------
    // Royco Core
    // -----------------------------------------
    address internal SAFE_CANONICAL_SINGLETON;
    address internal SAFE_MULTISEND;
    address internal SAFE_COMPATIBILITY_FALLBACK_HANDLER;
    address internal ROYCO_ACCOUNT_HANDLER;
    RoycoMiddleware internal ROYCO_MIDDLEWARE;
    Royco internal ROYCO;

    // -----------------------------------------
    // Position Managers
    // -----------------------------------------

    address internal FIFO_POSITION_MANAGER;

    // -----------------------------------------
    // Signals
    // -----------------------------------------
    address AAVE_V3_SIGNALS;
    address MORPHO_BLUE_SIGNALS;

    // -----------------------------------------
    // Lending Nodes and Markets
    // -----------------------------------------
    bytes32 SUPPLY_AAVE_USDC_NODE_HASH;
    bytes32 SUPPLY_MORPHO_USDC_WBTC_NODE_HASH;

    bytes32 SUPPLY_AAVE_USDC_APR_MARKET_HASH;
    bytes32 SUPPLY_MORPHO_USDC_WBTC_APR_MARKET_HASH;

    // -----------------------------------------
    // Fork State
    // -----------------------------------------
    string MAINNET_RPC_URL = vm.envString("MAINNET_RPC_URL");
    uint256 mainnetFork;

    // -----------------------------------------
    // Modifiers
    // -----------------------------------------
    modifier prankModifier(address pranker) {
        vm.startPrank(pranker);
        _;
        vm.stopPrank();
    }

    // -----------------------------------------
    // Setup Functions
    // -----------------------------------------
    function setUp() public virtual {
        setupWallets();
        setUpRoycoContracts();
        mockToken = new MockERC20();
    }

    function setupWallets() public {
        // Init wallets with 1000 ETH each
        OWNER = initWallet("OWNER", 1000 ether);
        ALICE = initWallet("ALICE", 1000 ether);
        BOB = initWallet("BOB", 1000 ether);
        CHARLIE = initWallet("CHARLIE", 1000 ether);
        DAN = initWallet("DAN", 1000 ether);

        // Set addresses
        OWNER_ADDRESS = OWNER.addr;
        ALICE_ADDRESS = ALICE.addr;
        BOB_ADDRESS = BOB.addr;
        CHARLIE_ADDRESS = CHARLIE.addr;
        DAN_ADDRESS = DAN.addr;
    }

    function setUpRoycoContracts() public virtual {
        SAFE_CANONICAL_SINGLETON = address(new Safe());
        SAFE_MULTISEND = address(new MultiSendCallOnly());
        SAFE_COMPATIBILITY_FALLBACK_HANDLER = address(new CompatibilityFallbackHandler());
        ROYCO_MIDDLEWARE = new RoycoMiddleware(OWNER_ADDRESS);

        ROYCO = new Royco(OWNER_ADDRESS, SAFE_MULTISEND, SAFE_CANONICAL_SINGLETON, address(ROYCO_MIDDLEWARE));

        RoycoMiddleware(ROYCO_MIDDLEWARE).initialize(address(ROYCO));
        ROYCO_ACCOUNT_HANDLER = RoycoMiddleware(ROYCO_MIDDLEWARE).ROYCO_ACCOUNT_HANDLER();

        FIFO_POSITION_MANAGER = address(new FifoPositionManager(address(ROYCO)));

        vm.prank(OWNER_ADDRESS);
        RoycoMiddleware(ROYCO_MIDDLEWARE).whitelistPositionManager(FIFO_POSITION_MANAGER);
    }

    function setUpMainnetAaveMarket() public virtual {
        // Setup supply USDC on Aave, node, signal, and market
        SUPPLY_AAVE_USDC_NODE_HASH = ROYCO.insertNode(
            MAINNET_USDC,
            _buildAaveV3DepositRecipe(MAINNET_USDC, AAVE_V3_POOL, ROYCO_ACCOUNT_HANDLER),
            _buildAaveV3LiquidityQuery(address(new AaveV3LiquidityQueryHelper(AAVE_V3_POOL, AAVE_V3_POOL_DATA_PROVIDER, AAVE_V3_ORACLE)), MAINNET_USDC),
            _buildAaveV3WithdrawalRecipe(MAINNET_USDC, AAVE_V3_POOL, ROYCO_ACCOUNT_HANDLER),
            MAINNET_USDC
        );
        AAVE_V3_SIGNALS = address(new AaveV3Signals(AAVE_V3_POOL));
        Operand memory aaveAprSignal = Operand(AAVE_V3_SIGNALS, abi.encodeCall(AaveV3Signals.getCurrentSupplyApr, (MAINNET_USDC)));
        SUPPLY_AAVE_USDC_APR_MARKET_HASH = ROYCO.createMarket(SUPPLY_AAVE_USDC_NODE_HASH, aaveAprSignal);
    }

    function setUpMainnetMorphoUsdcWBtcMarket() public virtual {
        // Setup supply USDC on Morpho WBTC/USDC node, signal, and market
        SUPPLY_MORPHO_USDC_WBTC_NODE_HASH = ROYCO.insertNode(
            MAINNET_USDC,
            _buildMorphoBlueDepositRecipe(
                MORPHO, ROYCO_ACCOUNT_HANDLER, MAINNET_USDC, MAINNET_WBTC, MORPHO_WBTC_USDC_ORACLE, MORPHO_ADAPTIVE_CURVE_IRM, MORPHO_WBTC_USDC_LLTV
            ),
            _buildMorphoBlueLiquidityQuery(
                address(new MorphoBlueLiquidityQueryHelper(MORPHO)),
                MAINNET_USDC,
                MAINNET_WBTC,
                MORPHO_WBTC_USDC_ORACLE,
                MORPHO_ADAPTIVE_CURVE_IRM,
                MORPHO_WBTC_USDC_LLTV
            ),
            _buildMorphoBlueWithdrawalRecipe(
                MORPHO, ROYCO_ACCOUNT_HANDLER, MAINNET_USDC, MAINNET_WBTC, MORPHO_WBTC_USDC_ORACLE, MORPHO_ADAPTIVE_CURVE_IRM, MORPHO_WBTC_USDC_LLTV
            ),
            MAINNET_USDC
        );

        MORPHO_BLUE_SIGNALS = address(new MorphoBlueSignals(MORPHO));
        Operand memory morphoAprSignal = Operand(
            MORPHO_BLUE_SIGNALS,
            abi.encodeCall(
                MorphoBlueSignals.getCurrentSupplyApr,
                (MarketParams(MAINNET_USDC, MAINNET_WBTC, MORPHO_WBTC_USDC_ORACLE, MORPHO_ADAPTIVE_CURVE_IRM, MORPHO_WBTC_USDC_LLTV))
            )
        );
        SUPPLY_MORPHO_USDC_WBTC_APR_MARKET_HASH = ROYCO.createMarket(SUPPLY_MORPHO_USDC_WBTC_NODE_HASH, morphoAprSignal);
    }

    function initWallet(string memory name, uint256 amount) public returns (Vm.Wallet memory) {
        Vm.Wallet memory wallet = vm.createWallet(name);
        vm.label(wallet.addr, name);
        vm.deal(wallet.addr, amount);
        return wallet;
    }

    function signOrderHash(bytes32 _orderHash, Vm.Wallet[] memory _signers) public pure returns (bytes memory signatures) {
        // Safe expects signers to be in order
        _sort(_signers);

        // Add the signatures to the bytes buffer and return
        for (uint256 i; i < _signers.length; ++i) {
            (uint8 v, bytes32 r, bytes32 s) = vm.sign(_signers[i].privateKey, _orderHash);
            signatures = abi.encodePacked(signatures, r, s, v);
        }
    }

    function _sort(Vm.Wallet[] memory _signers) private pure {
        for (uint256 i; i < _signers.length; ++i) {
            uint256 min = i;
            for (uint256 j = i + 1; j < _signers.length; ++j) {
                if (_signers[j].addr < _signers[min].addr) min = j;
            }
            if (min != i) (_signers[i], _signers[min]) = (_signers[min], _signers[i]);
        }
    }

    function _logAbsoluteOrder(AbsoluteOrder memory order) internal pure {
        console2.log(unicode"──────────────── ABSOLUTE ORDER ────────────────");
        console2.log("nonce              :", order.nonce);
        console2.log("roycoAccount       :", order.roycoAccount);
        console2.log("taker              :", order.taker);
        console2.log("targetMarketHash   :");
        console2.logBytes32(order.targetMarketHash);
        console2.log("signalComparator   :", uint256(order.signalComparator));
        _logOperand("rhsSignalOperand    :", order.rhsSignalOperand);
        console2.log("checkBeforeFill    :", uint256(order.signalConditionType));
        console2.log("executionParams    :");
        console2.logBytes(order.executionParams);
        console2.log("quantity           :", order.quantity);
        console2.log("expiry             :", order.expiry);
        console2.log("positionManager    :", order.positionManager);
        console2.logBytes(order.positionManagerArgs);
        console2.log("feeToken           :", order.feeToken);
        console2.log("feeAmount          :", order.feeAmount);

        console2.log("--- preChecks (%s)", order.preConditions.length);
        for (uint256 i; i < order.preConditions.length; ++i) {
            _logCondition(i, order.preConditions[i]);
        }

        console2.log("--- postChecks (%s)", order.postConditions.length);
        for (uint256 i; i < order.postConditions.length; ++i) {
            _logCondition(i, order.postConditions[i]);
        }

        console2.log("Signature   :");
        console2.logBytes(order.signature);
        console2.log(unicode"───────────────────────────────────────────────");
    }

    function _logOperand(string memory label, Operand memory op) private pure {
        console2.log(label);
        console2.log("   target :", op.target);
        console2.log("   data :");
        console2.logBytes(op.data);
    }

    function _logCondition(uint256 idx, Condition memory cond) private pure {
        console2.log(unicode"  ▸ Condition [%s]", idx);
        _logOperand("      lhs", cond.lhs);
        console2.log("      cmp :", uint256(cond.cmp));
        _logOperand("      rhs", cond.rhs);
    }
}
