// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import "../lib/forge-std/src/Script.sol";
import { Royco } from "../src/core/Royco.sol";
import { RoycoMiddleware } from "../src/core/royco-account/RoycoMiddleware.sol";
import { AaveV3LiquidityQueryHelper } from "../src/periphery/liq-queries-helpers/AaveV3LiquidityQueryHelper.sol";
import { MorphoBlueLiquidityQueryHelper } from "../src/periphery/liq-queries-helpers/MorphoBlueLiquidityQueryHelper.sol";
import { FifoPositionManager } from "../src/periphery/position-managers/FifoPositionManager.sol";
import { AaveV3Signals } from "../src/periphery/signals/lending/AaveV3Signals.sol";
import { MorphoBlueSignals } from "../src/periphery/signals/lending/MorphoBlueSignals.sol";
import { Constants } from "../test/utils/Constants.sol";

contract DeployRoyco is Script, Constants {
    function run() external {
        uint256 deployerPrivateKey = vm.envUint("PRIVATE_KEY");
        address deployerAddress = vm.addr(deployerPrivateKey);

        vm.startBroadcast(deployerPrivateKey);

        // Core contracts deployment and setup
        RoycoMiddleware roycoMiddleware = new RoycoMiddleware(deployerAddress);
        console2.log("Royco Middleware Deployed:", address(roycoMiddleware));

        address royco = address(new Royco(deployerAddress, MAINNET_SAFE_MULTISEND, MAINNET_SAFE_CANONICAL_SINGLETON, address(roycoMiddleware)));
        console2.log("Royco Deployed:", royco);

        roycoMiddleware.initialize(royco);

        // Deploy periphery contracts
        address positionManager = address(new FifoPositionManager(royco));
        console2.log("FIFO Position Manager:", positionManager);

        address signals = address(new AaveV3Signals(AAVE_V3_POOL));
        console2.log("Aave V3 Signals:", signals);

        signals = address(new MorphoBlueSignals(MORPHO));
        console2.log("Morpho Blue Signals:", signals);

        address liqQueryHelper = address(new AaveV3LiquidityQueryHelper(AAVE_V3_POOL, AAVE_V3_POOL_DATA_PROVIDER, AAVE_V3_ORACLE));
        console2.log("Aave V3 Liquidity Query Helper:", liqQueryHelper);

        liqQueryHelper = address(new MorphoBlueLiquidityQueryHelper(MORPHO));
        console2.log("Morpho Blue Liquidity Query Helper:", liqQueryHelper);

        vm.stopBroadcast();
    }
}
