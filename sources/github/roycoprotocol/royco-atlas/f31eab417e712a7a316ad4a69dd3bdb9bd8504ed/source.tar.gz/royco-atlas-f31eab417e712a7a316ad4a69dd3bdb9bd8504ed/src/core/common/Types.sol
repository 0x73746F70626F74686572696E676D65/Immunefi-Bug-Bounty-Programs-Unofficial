// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

/**
 * @title AbsoluteOrder
 * @notice An Absolute Order on Royco.
 */
struct AbsoluteOrder {
    // A unique nonce for this order. Used to probabilistically guarantee hash uniqueness.
    uint32 nonce;
    // The Royco account of the maker to use for the source liquidity and signature verification
    address roycoAccount;
    // The taker whitelisted to fill this order
    // The null address indicates a permissionlessly fillable order
    address taker;
    // The target market to deposit liquidity into if the order conditions are met
    bytes32 targetMarketHash;
    // The comparator used for the market's signal
    Comparator signalComparator;
    // The RHS operand to evaluate the following expression with: (Market Signal Value [signalComparator] RHS Operand)
    Operand rhsSignalOperand;
    // Enum value indicating whether the market's signal condition should be checked. If so, before or after the reallocation is done.
    SignalConditionType signalConditionType;
    // The runtime parameters passed when executing the deposit recipe of the target market
    bytes executionParams;
    // The max amount of liquidity to allocate to the target market if the orders conditions are met
    uint256 quantity;
    // The timestamp at which the order is considered valid until
    uint40 expiry;
    // The address of the positionManager to use to provide the source markets and amounts for the reallocation
    address positionManager;
    // Arbitrary bytes passed to the positionManager
    bytes positionManagerArgs;
    // The pre-conditions to evaluate in the context of the account before order execution
    Condition[] preConditions;
    // The post-conditions to evaluate in the context of the account after order execution
    Condition[] postConditions;
    // The token to use for fee remittance
    // Null address means that the fee will be taken in the native asset
    address feeToken;
    // The amount of the fee token to be transferred from the taker to the maker for filling the entire quantity of the order
    uint256 feeAmount;
    // Boolean indicating whether the fee should be paid by the maker or the taker
    bool feePaidByMaker;
    // The signature produced by the Royco Account over the EIP-712 encoded order digest
    bytes signature;
}

/**
 * @title SignalConditionType
 * @notice An enumeration of signal condition types.
 * @dev Specifies when (or if) a market signal condition must be checked during an order fill.
 */
enum SignalConditionType {
    // Do not check the market signal condition (no-op)
    NOP,
    // Check the market signal condition before the liquidity reallocation
    PRE_CONDITION,
    // Check the market signal condition after the liquidity reallocation
    POST_CONDITION
}

/**
 * @title Condition
 * @notice An expression of a condition used for account and order level checks.
 * @custom:field lhs The left-hand side operand of the condition.
 * @custom:field cmp The comparator to evaluate the operands with.
 * @custom:field rhs The right-hand side operand of the condition.
 */
struct Condition {
    Operand lhs;
    Comparator cmp;
    Operand rhs;
}

/**
 * @title Operand
 * @notice An operand used as the LHS or RHS of a condition.
 * @dev Must resolve to a uint256.
 * @custom:field target The address to call to get the uint256 operand value. If set to the null address, the operand is a static uint256 encoded in the data field.
 * @custom:field data The encoded calldata to call the target with.
 */
struct Operand {
    address target;
    bytes data;
}

/**
 * @title Comparator
 * @notice Enumeration of binary comparators used to evalutate conditions.
 */
enum Comparator {
    LT,
    GT,
    LTE,
    GTE,
    EQ,
    NEQ
}

/**
 * @title RoycoAccountConditionsConfig
 * @notice A struct holding the pre and post conditions for a account.
 * @custom:field preChecks The pre-conditions to be checked by the account before each transaction.
 * @custom:field postChecks The post-conditions to be checked by the account after each transaction.
 */
struct RoycoAccountConditionsConfig {
    Condition[] preConditions;
    Condition[] postConditions;
}

/**
 * @title ConditionType
 * @notice An enumeration of condition types in Royco.
 */
enum ConditionType {
    ACCOUNT_LEVEL_PRE_CONDITION,
    ACCOUNT_LEVEL_POST_CONDITION,
    ORDER_LEVEL_PRE_CONDITION,
    ORDER_LEVEL_POST_CONDITION,
    MARKET_SIGNAL_CONDITION
}

/**
 * @title Recipe
 * @notice A struct holding the weiroll commands and state for a recipe.
 * @custom:field commands The weiroll commands to be executed by the recipe.
 * @custom:field state The weiroll state to be passed to the recipe.
 */
struct Recipe {
    bytes32[] commands;
    bytes[] state;
}
