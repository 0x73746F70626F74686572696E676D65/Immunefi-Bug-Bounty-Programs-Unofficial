// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

/**
 * @title Source
 * @notice Specifies a single liquidity source used when fulfilling an order.
 * @param nodeHash  The identifier of the node in the OLG to pull liquiditiy from.
 *                  The sentinel value (bytes32(0)) indicates that the source is the Royco account's token balance.
 * @param amountOut The number of tokens to pull/withdraw from the node.
 */
struct Source {
    bytes32 nodeHash;
    uint256 amountOut;
}

/**
 * @title IPositionManager
 * @notice The interface that must be implemented by a Royco Position manager.
 * @notice Used to provide granular control over how liquidity is sourced for an order to be fulfilled.
 */
interface IPositionManager {
    /**
     * @notice Returns the sources and the amounts of liquidity to pull to facilitate a Royco order fill.
     * @param _roycoAccount The Royco account to source the liquidity from.
     * @param _token The ERC20 token to source the liquidity in.
     * @param _totalLiquidityToSource The total amount of liquidity (in the token's precision) to source.
     * @param _positionManagerArgs Arbitrary arguments passed via an order. Use is Position Manager dependent.
     * @return sources The sources and the amounts of liquidity to pull from each.
     */
    function getLiquiditySources(
        address _roycoAccount,
        address _token,
        uint256 _totalLiquidityToSource,
        bytes calldata _positionManagerArgs
    )
        external
        returns (Source[] memory sources);
}
