// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import { Operand as Signal } from "../common/Types.sol";
import { OpenLiquidityGraph } from "./OpenLiquidityGraph.sol";

/**
 * @title Marketplace
 * @notice Extends the OpenLiquidityGraph to define discrete, negotiable markets tied to OLG nodes.
 *         Each market is associated with a signal value (e.g., APY, price, utilization, etc.) queried from an external oracle or contract.
 */
abstract contract Marketplace is OpenLiquidityGraph {
    /**
     * @notice A market tied to a specific node in the Open Liquidity Graph and associated with a negotiable signal.
     * @dev The signal is a scalar value that defines the negotiation axis for this market.
     * @param nodeHash A pointer to the node in the OLG that defines the market's deposit and withdrawal behavior.
     * @param marketSignal The signal associated with this market, defining its position on the negotiation axis.
     */
    struct Market {
        bytes32 nodeHash;
        Signal marketSignal;
    }

    /**
     * @notice A mapping from the market hash (identifier) to the Market state.
     */
    mapping(bytes32 marketHash => Market market) public marketHashToMarket;

    /**
     * @notice Emitted when a node is inserted into the OLG.
     * @param creator The address that created the market.
     * @param marketHash The unique identifier of the market.
     * @param nodeHash The unique identifier of the node that the market points to in the OLG.
     * @param signalProvider The address of the contract that returns the market's signal value.
     * @param data The encoded calldata used to query the signal for the market.
     * @param data The encoded calldata used to query the signal for the market.
     */
    event MarketCreated(address indexed creator, bytes32 marketHash, bytes32 indexed nodeHash, address indexed signalProvider, bytes data);

    /// @notice Thrown when trying to create a market with the sentinel node hash.
    error InvalidNodeHash();

    /// @notice Thrown when trying to icreate a marketthat already exists.
    error MarketAlreadyExists();

    /**
     * @notice Creates a market for a node in the OLG with a signal to negotiate on (APY, price, utilization, etc.)
     * @param _nodeHash The unique identifier of the node that the market points to in the OLG.
     * @param _marketSignal An encoded signal that returns a single, discrete value (uint256) associated with a market when called.
     * @return marketHash The unique identifier of the market.
     */
    function createMarket(bytes32 _nodeHash, Signal calldata _marketSignal) external returns (bytes32 marketHash) {
        // Make sure that the intended nodeHash isn't the sentinal node hash
        require(_nodeHash != bytes32(0), InvalidNodeHash());

        // Compute the unique identifier for this market
        marketHash = keccak256(abi.encode(_nodeHash, _marketSignal));

        // Get the market storage pointer and make sure that it doesn't exist already.
        Market storage market = marketHashToMarket[marketHash];
        require(market.nodeHash == bytes32(0), MarketAlreadyExists());

        // Store the market in persistent storage
        market.nodeHash = _nodeHash;
        market.marketSignal = _marketSignal;

        // Emit an event to signal market creation
        emit MarketCreated(msg.sender, marketHash, _nodeHash, _marketSignal.target, _marketSignal.data);
    }

    /**
     * @notice Gets the signal for the specified market.
     * @param _marketHash The unique identifier of the market to get the signal for.
     * @return marketSignal The market's encoded signal.
     */
    function getMarketSignal(bytes32 _marketHash) external view returns (Signal memory marketSignal) {
        marketSignal = marketHashToMarket[_marketHash].marketSignal;
    }
}
