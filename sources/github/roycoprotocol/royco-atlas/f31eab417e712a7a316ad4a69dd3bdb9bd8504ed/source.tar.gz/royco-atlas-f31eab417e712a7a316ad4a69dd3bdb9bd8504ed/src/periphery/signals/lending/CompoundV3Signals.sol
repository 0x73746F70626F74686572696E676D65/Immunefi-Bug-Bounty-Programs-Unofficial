// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.20;

import { IComet } from "../../interfaces/ICompoundV3.sol";

/**
 * @title CompoundV3Signals
 * @notice A contract which retrieves market signals from Compound V3 (Comet).
 */
contract CompoundV3Signals {
    /**
     * @notice Retrieves the current supply APR for the specified Comet market, scaled by RAY (1e27).
     * @dev Each Comet instance has a single base asset that is lent and borrowed against potentially multiple collateral assets.
     * @param _comet The address of the Comet (Compound V3) market.
     * @return supplyAprRAY The supply APR for the base asset in the Comet market scaled by RAY (1e27).
     */
    function getCurrentSupplyApr(address _comet) external view returns (uint256 supplyAprRAY) {
        // Get the supply rate per second in WAD for the specified Comet instance
        uint64 supplyRatePerSecondWAD = IComet(_comet).supplyRate(IComet(_comet).utilization());

        // Convert this to a yearly rate in RAY by scaling by the number of seconds in a year * (10^27 / 10^18)
        supplyAprRAY = (supplyRatePerSecondWAD * 365 days * 1e9);
    }
}
