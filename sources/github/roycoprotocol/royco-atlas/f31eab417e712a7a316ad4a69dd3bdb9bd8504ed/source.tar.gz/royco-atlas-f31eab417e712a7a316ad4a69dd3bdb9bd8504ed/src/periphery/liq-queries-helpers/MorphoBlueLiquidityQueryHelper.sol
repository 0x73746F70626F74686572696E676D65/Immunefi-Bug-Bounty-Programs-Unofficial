// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.20;

import { IMorpho, Id, Market, MarketParams, Position } from "../interfaces/IMorphoBlue.sol";

/**
 * @title MorphoBlueLiquidityQueryHelper
 * @notice A helper contract which exposes a function to get the invoker's maximum number of automatically withdrawable tokens from a Morpho Blue market.
 */
contract MorphoBlueLiquidityQueryHelper {
    /// @notice The address of the Morpho Blue deployment.
    IMorpho public immutable MORPHO;

    /**
     * @notice Initialize the Morpho Blue liquidity query helper contract.
     * @param _morpho The address of the Morpho Blue deployment.
     */
    constructor(address _morpho) {
        // Initialize the helper state
        MORPHO = IMorpho(_morpho);
    }

    /**
     * @notice Returns the maximum assets a user can withdraw right now from a Morpho market.
     * @dev If the invoker has any existant debt in this market, the function will return 0.
     * @param _marketParams The market params of the Morpho market to get the max withdrawable assets for the invoker.
     */
    function getMaxWithdrawableAssets(MarketParams calldata _marketParams) external returns (uint256) {
        // Compute the market's ID given the params
        Id morphoMarketId = Id.wrap(keccak256(abi.encode(_marketParams)));

        // Accrue interest to ensure the market's data is updated
        // TODO: Is it worth calling this function to incur a couple BPS difference in real vs returned utilization
        // If it is, consider emulating the accrual instead of persisting it
        MORPHO.accrueInterest(_marketParams);

        // Get the user's position in the market
        Position memory position = MORPHO.position(morphoMarketId, msg.sender);
        // If the user has any debt, they can't withdraw anything
        if (position.borrowShares != 0) return 0;

        // Get the market's current data
        Market memory market = MORPHO.market(morphoMarketId);

        // Calculate the assets withdrawable by the user
        uint256 withdrawableAssets = (position.supplyShares * market.totalSupplyAssets) / market.totalSupplyShares;
        // Calculate the idle assets in the market
        uint256 idleAssets = market.totalSupplyAssets - market.totalBorrowAssets;

        // If there are less idle assets in the market than withdrawable by the user, return the idle assets as max withdrawable
        if (idleAssets < withdrawableAssets) return idleAssets;
        // Else, return the max withdrawable assets based on the user's supplied assets
        return withdrawableAssets;
    }
}
