// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import { IERC20, SafeERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/utils/SafeERC20.sol";
import { EIP712 } from "../../lib/openzeppelin-contracts/contracts/utils/cryptography/EIP712.sol";
import { IPositionManager, Source } from "../periphery/position-managers/interfaces/IPositionManager.sol";
import { Marketplace } from "./base/Marketplace.sol";
import { AbsoluteOrder, OrderProcessor } from "./base/OrderProcessor.sol";
import { RoycoAccountFactory } from "./base/RoycoAccountFactory.sol";
import { Condition, Recipe, SignalConditionType } from "./common/Types.sol";

import { OrderCompressionLib } from "./libraries/OrderCompressionLib.sol";
import { RoycoMiddleware } from "./royco-account/RoycoMiddleware.sol";

/**
 * @title Royco
 */
contract Royco is RoycoAccountFactory, Marketplace, OrderProcessor {
    using OrderCompressionLib for AbsoluteOrder;
    using SafeERC20 for IERC20;

    /// @notice Mapping to keep track of fees accrued to each account
    mapping(address account => mapping(address token => uint256 feesAccrued)) accountToTokenToFeesAccrued;

    event AccountDeposited(address roycoAccount, bytes32 targetNode, uint256 amountIn, bytes executionParams);
    event AccountWithdrew(address roycoAccount, bytes32 targetNode, uint256 amountOut);
    event AbsoluteOrderFilled(bytes32 indexed orderhash, bytes32 indexed targetMarket, address indexed maker, address taker, uint256 amountFilled);
    event FeesClaimed(address indexed claimant, address feeToken, uint256 feesClaimed, address recipient);

    error FailedToClaimFees();
    error FailedToFreeLiquidity();
    error FailedToRefundFee();

    /**
     * @notice Initializes the Royco Atlas contract
     * @param _owner The owner of the contract.
     * @param _multiSend The Safe `MultiSendCallOnly` contract.
     * @param _safeSingleton The Royco account (or Royco accountL2) implementation.
     * @param _roycoMiddleware The default middleware contract that is installed as a Safe guard and module when a new Royco account is deployed.
     */
    constructor(
        address _owner,
        address _multiSend,
        address _safeSingleton,
        address _roycoMiddleware
    )
        RoycoAccountFactory(_owner, _multiSend, _safeSingleton, _roycoMiddleware)
        OrderProcessor("Royco Atlas", "1")
    { }

    function deposit(bytes32 _targetNodeHash, uint256 _amountIn, bytes calldata _executionParams) external {
        // Get the node to deposit into
        Node storage targetNode = nodeHashToNode[_targetNodeHash];

        // Deposit the `_amountIn` of the node's input token into the target node
        // Funds are expected to be in the invoker (Royco account)
        RoycoMiddleware(roycoMiddleware).executeDeposit(msg.sender, targetNode.depositRecipe, _amountIn, _executionParams);

        // Emit an event to signal deposit
        emit AccountDeposited(msg.sender, _targetNodeHash, _amountIn, _executionParams);
    }

    function withdraw(bytes32 _targetNodeHash, uint256 _amountOut) external {
        // Get the node to withdraw from
        Node storage targetNode = nodeHashToNode[_targetNodeHash];

        // If the amount out is set to max, withdraw all the liquidity in the node
        if (_amountOut == type(uint256).max) {
            // Execute the liquidity query to get the maximum amount of withdrawable output tokens
            _amountOut = RoycoMiddleware(roycoMiddleware).executeLiquidityQuery(msg.sender, _targetNodeHash);
        }

        // Withdraw the `_amountOut` of the node's output token from the target node
        RoycoMiddleware(roycoMiddleware).executeWithdrawal(msg.sender, targetNode.withdrawalRecipe, _amountOut);

        // Emit an event to signal withdrawal
        emit AccountWithdrew(msg.sender, _targetNodeHash, _amountOut);
    }

    function compressOrder(AbsoluteOrder calldata _order) external view returns (bytes memory) {
        return _order.compress();
    }

    /**
     * @notice Fills an absolute order.
     * @dev Reallocates the amount filled to the target market of the order if all the conditions are satisfied.
     * @param _order The signed absolute order to fill.
     * @param _fillAmount The amount of the order to fill.
     */
    function fillOrder(AbsoluteOrder calldata _order, uint256 _fillAmount) external payable {
        // Run basic validity checks on this order
        (address roycoAccount, bytes32 orderHash) = _conductBasicOrderChecks(_order);
        // Check that the maker is a valid Royco account
        _checkIsRoycoAccount(roycoAccount);

        // Cache the order's quantity
        uint256 orderQuantity = _order.quantity;
        // If the fill amount is set to max, fill the remaining quantity of the order
        if (_fillAmount == type(uint256).max) {
            _fillAmount = orderQuantity - orderHashToAmountFilled[orderHash];
        }

        // Account for the order fill
        _accountForFill(orderHash, orderQuantity, _fillAmount);

        // If any pre-conditions, check that the they are satisfied
        if (_order.preConditions.length != 0) {
            RoycoMiddleware(roycoMiddleware).checkPreConditions(roycoAccount, _order.preConditions);
        }

        // Get the target market for this order
        Market storage targetMarket = marketHashToMarket[_order.targetMarketHash];

        // Check the signal condition before the fill if specified
        _checkMarketSignalCondition(_order.signalConditionType, false, roycoAccount, targetMarket, _order);

        // Get the node associated with the target market from storage
        Node storage targetNode = nodeHashToNode[targetMarket.nodeHash];
        address targetInputToken = targetNode.inputToken;

        // If the fee token is equivalent to the node's input token and the maker is paying the fee, source fill amount + the fee amount
        // Else, the fee tokens are expected to be present in the Royco account
        uint256 totalAmountToFree = (_order.feeToken == targetInputToken && _order.feePaidByMaker) ? _fillAmount + _order.feeAmount : _fillAmount;

        // Free up the liquidity to deposit into the target market
        _freeLiquidity(
            roycoAccount,
            targetInputToken,
            totalAmountToFree,
            // Get the sources of liquidity for the reallocation via the Position Manager specified in the order
            IPositionManager(_order.positionManager).getLiquiditySources(roycoAccount, targetInputToken, totalAmountToFree, _order.positionManagerArgs)
        );

        // Remit any fees if specified
        _remitFees(roycoAccount, _order.feePaidByMaker, _order.feeToken, _order.feeAmount, orderQuantity, _fillAmount);

        // Deposit the freed liquidity into the target market
        RoycoMiddleware(roycoMiddleware).executeDeposit(roycoAccount, targetNode.depositRecipe, _fillAmount, _order.executionParams);

        // Check the signal condition after the fill if specified
        _checkMarketSignalCondition(_order.signalConditionType, true, roycoAccount, targetMarket, _order);

        // If any post-conditions, check that the they are satisfied
        if (_order.postConditions.length != 0) {
            RoycoMiddleware(roycoMiddleware).checkPostConditions(roycoAccount, _order.postConditions);
        }

        // Emit an event to signal order fill
        emit AbsoluteOrderFilled(orderHash, _order.targetMarketHash, roycoAccount, msg.sender, _fillAmount);
    }

    function cancelOrder(bytes32 _orderHash) external {
        // Mark the order as cancelled for this user
        accountToOrderHashToIsCancelled[msg.sender][_orderHash] = true;
        // Emit an event to signal cancellation
        emit OrderCancelled(msg.sender, _orderHash);
    }

    function claimFees(address _feeToken, address _recipient) external {
        // Get the fees accrued by the invoker
        uint256 feesAccrued = accountToTokenToFeesAccrued[msg.sender][_feeToken];
        // Return if nothing is owed
        if (feesAccrued == 0) return;

        // If fee token is the null address, fees are in the native asset
        if (_feeToken == address(0)) {
            (bool success,) = payable(_recipient).call{ value: feesAccrued }("");
            require(success, FailedToClaimFees());
        } else {
            // Transfer accrued fees to the invoker
            IERC20(_feeToken).safeTransfer(_recipient, feesAccrued);
        }

        // Emit event to signal claim
        emit FeesClaimed(msg.sender, _feeToken, feesAccrued, _recipient);
    }

    function _checkMarketSignalCondition(
        SignalConditionType _signalConditionType,
        bool _reallocatedLiquidity,
        address _roycoAccount,
        Market storage _market,
        AbsoluteOrder calldata _order
    )
        internal
    {
        // If no need to check the market's signal condition right now, return preemptively
        if (
            _signalConditionType == SignalConditionType.NOP || (_signalConditionType == SignalConditionType.PRE_CONDITION && _reallocatedLiquidity)
                || (_signalConditionType == SignalConditionType.POST_CONDITION && !_reallocatedLiquidity)
        ) return;

        // Marshal the market signal condition with the signal value on the LHS and the comparator and RHS Operand from the order
        Condition memory marketSignalCondition = Condition(_market.marketSignal, _order.signalComparator, _order.rhsSignalOperand);
        // Check the signal condition in the context of the Royco Account
        RoycoMiddleware(roycoMiddleware).checkMarketSignalCondition(_roycoAccount, marketSignalCondition);
    }

    function _freeLiquidity(address _roycoAccount, address _token, uint256 _totalAmountToFree, Source[] memory _sources) internal {
        // Marshal the recipe and amountsOut for the middleware contract
        uint256 numSources = _sources.length;
        Recipe[] memory withdrawalRecipes = new Recipe[](numSources);
        uint256[] memory amountsOut = new uint256[](numSources);
        uint256 accountBalanceUsed;
        uint256 numWithdrawals;
        for (uint256 i = 0; i < numSources; ++i) {
            bytes32 nodeHash = _sources[i].nodeHash;
            // If node hash is the sentinel value, use the account's existent token balance
            if (nodeHash == bytes32(0)) {
                accountBalanceUsed += _sources[i].amountOut;
            } else {
                // Else, add this source to the withdrawal recipes to execute
                withdrawalRecipes[numWithdrawals] = nodeHashToNode[nodeHash].withdrawalRecipe;
                amountsOut[numWithdrawals++] = _sources[i].amountOut;
            }
        }

        // Resize the recipe and amountsOut arrays to reflect the actual number of withdrawals
        assembly ("memory-safe") {
            mstore(withdrawalRecipes, numWithdrawals)
            mstore(amountsOut, numWithdrawals)
        }

        // Cache the pre-withdrawal balance of the token for the Royco account excluding the existent account balance used for routing
        // Serves as an insufficient balance check
        uint256 preWithdrawalBalance = IERC20(_token).balanceOf(_roycoAccount) - accountBalanceUsed;
        // Execute the necessary withdrawals to free up the liquidity
        RoycoMiddleware(roycoMiddleware).executeBatchWithdrawal(_roycoAccount, withdrawalRecipes, amountsOut);
        // Compute the balance delta after executing the withdrawals
        uint256 balanceDelta = IERC20(_token).balanceOf(_roycoAccount) - preWithdrawalBalance;

        // Ensure that the balance delta is equivalent to the total amount to free executing the withdrawals
        require(balanceDelta == _totalAmountToFree, FailedToFreeLiquidity());
    }

    function _remitFees(
        address _roycoAccount,
        bool _feePaidByMaker,
        address _feeToken,
        uint256 _feeAmount,
        uint256 _orderQuantity,
        uint256 _fillAmount
    )
        internal
    {
        // Return if no fees to remit
        if (_feeAmount == 0) return;

        // Compute the fees owed as a percentage of quantity filled times the amount filled
        uint256 feesOwed = (_feeAmount * _fillAmount) / _orderQuantity;

        if (_feePaidByMaker) {
            // Pull the fees from the user's Royco account
            RoycoMiddleware(_roycoAccount).pullFees(_roycoAccount, _feeToken, _feeAmount);
        } else {
            // If fee token is the null address, fees are paid in the native asset
            if (_feeToken == address(0)) {
                // If excess fees sent with the transaction, refund them
                // Serves as an insufficient fee remittance check
                uint256 excessFees = msg.value - feesOwed;
                if (excessFees != 0) {
                    (bool success,) = payable(msg.sender).call{ value: excessFees }("");
                    require(success, FailedToRefundFee());
                }
            } else {
                // Transfer fee tokens from the taker to this contract
                IERC20(_feeToken).safeTransferFrom(msg.sender, address(this), feesOwed);
            }
        }

        // Accrue the fees owed to the payee
        accountToTokenToFeesAccrued[_feePaidByMaker ? msg.sender : _roycoAccount][_feeToken] += feesOwed;
    }

    /// @notice Called when Royco recevies native asset fee remittances from a Royco Account
    receive() external payable { }
}
