// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import { Ownable, Ownable2Step } from "../../../lib/openzeppelin-contracts/contracts/access/Ownable2Step.sol";
import { IERC20 } from "../../../lib/openzeppelin-contracts/contracts/token/ERC20/utils/SafeERC20.sol";
import { BaseTransactionGuard, GuardManager, ITransactionGuard } from "../../../lib/safe-smart-account/contracts/base/GuardManager.sol";
import { IModuleManager } from "../../../lib/safe-smart-account/contracts/interfaces/IModuleManager.sol";
import { Enum } from "../../../lib/safe-smart-account/contracts/libraries/Enum.sol";
import { OpenLiquidityGraph } from "../base/OpenLiquidityGraph.sol";
import { Condition, ConditionType, Recipe, RoycoAccountConditionsConfig } from "../common/Types.sol";
import { RoycoAccountHandler } from "./RoycoAccountHandler.sol";

/**
 * @title RoycoMiddleware
 * TODO
 * 1. Should royco() be updateable, if so how?
 * 2. Codehash check on initialize
 * 3. Who should be allowed to set/update the checks?
 * 4. Duplicated account checks management with the ExecutionModule, might centralize it at some point. Makes fetching checks less efficient though.
 * 5. Figure out a way to lock down the safe, and to what degree.
 */
contract RoycoMiddleware is BaseTransactionGuard, Ownable2Step {
    // The address of the Royco Account Handler Contract
    address public immutable ROYCO_ACCOUNT_HANDLER;

    // The address of the main Royco contract
    address public royco;

    // Stores the account checks associated with each account
    mapping(address roycoAccount => RoycoAccountConditionsConfig conditions) private roycoAccountToConditions;

    mapping(address positionManager => bool whitelisted) public positionManagerToIsWhitelisted;

    constructor(address _owner) Ownable(_owner) {
        ROYCO_ACCOUNT_HANDLER = address(new RoycoAccountHandler());
    }

    event RoycoAccountConditionsSet(address roycoAccount, RoycoAccountConditionsConfig roycoAccountChecks);

    error OnlyRoyco();
    error OnlyRoycoOrPositionManager();
    error AlreadyInitialized();
    error AuthorizedFlowsProhibited();
    error ConditionCheckFailed(address roycoAccount, ConditionType conditionType);
    error LiquidityQueryExecutionFailed(address roycoAccount, bytes returnData);
    error DepositFailed(address roycoAccount);
    error WithdrawalFailed(address roycoAccount);
    error FailedToPullFees(address roycoAccount);

    modifier onlyRoyco() {
        require(msg.sender == royco, OnlyRoyco());
        _;
    }

    modifier onlyRoycoOrPositionManager() {
        require(msg.sender == royco || positionManagerToIsWhitelisted[msg.sender], OnlyRoycoOrPositionManager());
        _;
    }

    function initialize(address _royco) external {
        require(royco == address(0), AlreadyInitialized());
        royco = _royco;
    }

    function whitelistPositionManager(address _positionManager) external onlyOwner {
        positionManagerToIsWhitelisted[_positionManager] = true;
    }

    function blacklistPositionManager(address _positionManager) external onlyOwner {
        positionManagerToIsWhitelisted[_positionManager] = false;
    }

    /// @inheritdoc ITransactionGuard
    function checkTransaction(
        address to,
        uint256,
        bytes calldata,
        Enum.Operation,
        uint256,
        uint256,
        uint256,
        address,
        address payable,
        bytes calldata,
        address
    )
        external
        override
    {
        // Prohibit all authorized flows for now.
        require(to != msg.sender, AuthorizedFlowsProhibited());

        // Check the pre-conditions specified by the account
        RoycoAccountConditionsConfig storage conditions = roycoAccountToConditions[msg.sender];
        if (conditions.preConditions.length > 0) {
            require(_checkConditions(msg.sender, conditions.preConditions), ConditionCheckFailed(msg.sender, ConditionType.ACCOUNT_LEVEL_PRE_CONDITION));
        }
    }

    /// @inheritdoc ITransactionGuard
    function checkAfterExecution(bytes32, bool) external override {
        // Check the post-conditions specified by the account
        RoycoAccountConditionsConfig storage conditions = roycoAccountToConditions[msg.sender];
        if (conditions.postConditions.length > 0) {
            require(_checkConditions(msg.sender, conditions.postConditions), ConditionCheckFailed(msg.sender, ConditionType.ACCOUNT_LEVEL_POST_CONDITION));
        }
    }

    function checkPreConditions(address _roycoAccount, Condition[] calldata _orderPreConditions) external onlyRoyco {
        // Check the pre-conditions specified by the account
        RoycoAccountConditionsConfig storage conditions = roycoAccountToConditions[_roycoAccount];
        if (conditions.preConditions.length > 0) {
            require(_checkConditions(_roycoAccount, conditions.preConditions), ConditionCheckFailed(_roycoAccount, ConditionType.ACCOUNT_LEVEL_PRE_CONDITION));
        }

        // Check the pre-conditions specified by the order
        if (_orderPreConditions.length > 0) {
            require(_checkConditions(_roycoAccount, _orderPreConditions), ConditionCheckFailed(_roycoAccount, ConditionType.ORDER_LEVEL_PRE_CONDITION));
        }
    }

    function checkPostConditions(address _roycoAccount, Condition[] calldata _orderPostConditions) external onlyRoyco {
        // Check the post-conditions specified by the account
        RoycoAccountConditionsConfig storage conditions = roycoAccountToConditions[_roycoAccount];
        if (conditions.postConditions.length > 0) {
            require(_checkConditions(_roycoAccount, conditions.postConditions), ConditionCheckFailed(_roycoAccount, ConditionType.ACCOUNT_LEVEL_POST_CONDITION));
        }

        // Check the post-conditions specified by the order
        if (_orderPostConditions.length > 0) {
            require(_checkConditions(_roycoAccount, _orderPostConditions), ConditionCheckFailed(_roycoAccount, ConditionType.ORDER_LEVEL_POST_CONDITION));
        }
    }

    function checkMarketSignalCondition(address _roycoAccount, Condition calldata _marketSignalCondition) external onlyRoyco {
        // Check that the market signal condition is satisfied
        require(
            IModuleManager(_roycoAccount).execTransactionFromModule(
                ROYCO_ACCOUNT_HANDLER, 0, abi.encodeCall(RoycoAccountHandler.evaluateCondition, (_marketSignalCondition)), Enum.Operation.DelegateCall
            ),
            ConditionCheckFailed(_roycoAccount, ConditionType.MARKET_SIGNAL_CONDITION)
        );
    }

    function executeLiquidityQueries(
        address _roycoAccount,
        bytes32[] calldata _nodeHashes
    )
        external
        onlyRoycoOrPositionManager
        returns (uint256[] memory queryResults)
    {
        // Get the liquidity queries for the specified nodes from the OLG
        Recipe[] memory liquidityQueries = OpenLiquidityGraph(royco).getLiquidityQueries(_nodeHashes);

        // Execute the liquidity queries in the context of the Royco account
        (bool success, bytes memory returnData) = IModuleManager(_roycoAccount).execTransactionFromModuleReturnData(
            ROYCO_ACCOUNT_HANDLER, 0, abi.encodeCall(RoycoAccountHandler.executeLiquidityQueries, (liquidityQueries)), Enum.Operation.DelegateCall
        );
        require(success, LiquidityQueryExecutionFailed(_roycoAccount, returnData));

        // Decode and return the query responses
        queryResults = abi.decode(returnData, (uint256[]));
    }

    function executeLiquidityQuery(address _roycoAccount, bytes32 _nodeHash) external onlyRoycoOrPositionManager returns (uint256 queryResult) {
        // Get the liquidity query for the specified node from the OLG
        Recipe memory liquidityQuery = OpenLiquidityGraph(royco).getLiquidityQuery(_nodeHash);

        // Execute the liquidity queries in the context of the Royco account
        (bool success, bytes memory returnData) = IModuleManager(_roycoAccount).execTransactionFromModuleReturnData(
            ROYCO_ACCOUNT_HANDLER, 0, abi.encodeCall(RoycoAccountHandler.executeLiquidityQuery, (liquidityQuery)), Enum.Operation.DelegateCall
        );
        require(success, LiquidityQueryExecutionFailed(_roycoAccount, returnData));

        // Decode and return the query response
        queryResult = abi.decode(returnData, (uint256));
    }

    function executeDeposit(address _roycoAccount, Recipe calldata _depositRecipe, uint256 _amountIn, bytes calldata _executionParams) external onlyRoyco {
        require(
            IModuleManager(_roycoAccount).execTransactionFromModule(
                ROYCO_ACCOUNT_HANDLER,
                0,
                abi.encodeCall(RoycoAccountHandler.executeDeposit, (_depositRecipe, _amountIn, _executionParams)),
                Enum.Operation.DelegateCall
            ),
            DepositFailed(_roycoAccount)
        );
    }

    function executeWithdrawal(address _roycoAccount, Recipe calldata _withdrawalRecipe, uint256 _amountOut) external onlyRoyco {
        require(
            IModuleManager(_roycoAccount).execTransactionFromModule(
                ROYCO_ACCOUNT_HANDLER, 0, abi.encodeCall(RoycoAccountHandler.executeWithdrawal, (_withdrawalRecipe, _amountOut)), Enum.Operation.DelegateCall
            ),
            WithdrawalFailed(_roycoAccount)
        );
    }

    function executeBatchWithdrawal(address _roycoAccount, Recipe[] calldata _withdrawalRecipes, uint256[] calldata _amountsOut) external onlyRoyco {
        require(
            IModuleManager(_roycoAccount).execTransactionFromModule(
                ROYCO_ACCOUNT_HANDLER,
                0,
                abi.encodeCall(RoycoAccountHandler.executeBatchWithdrawal, (_withdrawalRecipes, _amountsOut)),
                Enum.Operation.DelegateCall
            ),
            WithdrawalFailed(_roycoAccount)
        );
    }

    function pullFees(address _roycoAccount, address _feeToken, uint256 _feeAmount) external onlyRoyco {
        // If fee token is the null address, fees are paid in the native asset
        if (_feeToken == address(0)) {
            require(IModuleManager(_roycoAccount).execTransactionFromModule(msg.sender, _feeAmount, "", Enum.Operation.Call), FailedToPullFees(_roycoAccount));
            // Else, pull the ERC20 tokens
        } else {
            require(
                IModuleManager(_roycoAccount).execTransactionFromModule(
                    _feeToken, 0, abi.encodeCall(IERC20.transfer, (msg.sender, _feeAmount)), Enum.Operation.Call
                ),
                FailedToPullFees(_roycoAccount)
            );
        }
    }

    function setRoycoAccountConditions(address _roycoAccount, RoycoAccountConditionsConfig calldata _roycoAccountChecks) external onlyRoyco {
        roycoAccountToConditions[_roycoAccount] = _roycoAccountChecks;
        emit RoycoAccountConditionsSet(_roycoAccount, _roycoAccountChecks);
    }

    function getRoycoAccountConditions(address _roycoAccount) external view returns (RoycoAccountConditionsConfig memory roycoAccountChecks) {
        return roycoAccountToConditions[_roycoAccount];
    }

    /**
     * @notice Checks the conditions in the context of a Royco Account.
     * @dev This function reverts if the conditional checks fail.
     * @param _roycoAccount The Royco account to check the conditions for.
     * @param _conditions The storage pointer to the conditions to be checked.
     */
    function _checkConditions(address _roycoAccount, Condition[] storage _conditions) internal returns (bool satisfied) {
        satisfied = IModuleManager(_roycoAccount).execTransactionFromModule(
            ROYCO_ACCOUNT_HANDLER, 0, abi.encodeCall(RoycoAccountHandler.evaluateConditions, (_conditions)), Enum.Operation.DelegateCall
        );
    }

    /**
     * @notice Checks the conditions in the context of a Royco Account.
     * @dev This function reverts if the conditional checks fail.
     * @param _roycoAccount The Royco account to check the conditions for.
     * @param _conditions The conditions to be checked.
     */
    function _checkConditions(address _roycoAccount, Condition[] calldata _conditions) internal returns (bool satisfied) {
        satisfied = IModuleManager(_roycoAccount).execTransactionFromModule(
            ROYCO_ACCOUNT_HANDLER, 0, abi.encodeCall(RoycoAccountHandler.evaluateConditions, (_conditions)), Enum.Operation.DelegateCall
        );
    }
}
