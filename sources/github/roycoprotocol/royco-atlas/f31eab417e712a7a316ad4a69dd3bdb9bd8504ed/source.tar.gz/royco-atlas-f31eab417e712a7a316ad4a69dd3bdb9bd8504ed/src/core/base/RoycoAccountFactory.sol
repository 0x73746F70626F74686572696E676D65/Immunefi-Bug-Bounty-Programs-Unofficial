// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import { Ownable, Ownable2Step } from "../../../lib/openzeppelin-contracts/contracts/access/Ownable2Step.sol";
import { Clones } from "../../../lib/openzeppelin-contracts/contracts/proxy/Clones.sol";
import { Enum, IGuardManager, IModuleManager, IOwnerManager, ISafe } from "../../../lib/safe-smart-account/contracts/interfaces/ISafe.sol";
import { MultiSendCallOnly } from "../../../lib/safe-smart-account/contracts/libraries/MultiSendCallOnly.sol";

/**
 * @title RoycoAccountFactory
 * @notice A factory for deploying Royco Accounts/Safes as EIP-1167 minimal proxy clones.
 * @dev Each Royco Account is a fully functional Safe initialized with Royco Middleware as the executor module and guard.
 */
abstract contract RoycoAccountFactory is Ownable2Step {
    using Clones for address;

    /// @notice The address of Safe's `MultiSendCallOnly` contract.
    address public immutable MULTISEND;

    /// @notice The address of the Safe singleton implementation.
    /// @dev New Royco accounts are deployed as a EIP-1167 minimal proxy clone pointing to this implementation.
    address public safeSingleton;

    /// @notice The address of the default middleware contract that is installed as a Safe guard and module when a new Royco account is deployed.
    address public roycoMiddleware;

    /// @notice Mapping to keep track of each Royco account deployed via this factory.
    mapping(address roycoAccount => bool exists) public roycoAccountToExists;

    /**
     * @notice Mapping to keep track of the user's next account ID.
     * @dev The ID is used in conjunction with the user's address to compute the salt for counterfactual Royco account deployment.
     * @dev Deployment Salt = User Address (upper 20 bytes) concatenated with their next account ID (lower 12 bytes).
     */
    mapping(address user => uint96 accountId) public userToNextAccountId;

    /**
     * @notice Emitted when a new Royco Safe is deployed for a user.
     * @param user The address of the user the Royco account was deployed for.
     * @param roycoAccount Address of the newly deployed Royco account proxy.
     */
    event RoycoAccountDeployed(address indexed user, address roycoAccount);

    /**
     * @notice Emitted when the Safe singleton implementation is updated.
     * @param newSafeSingleton Address of the new singleton implementation used for future deployments.
     */
    event SafeSingletonSet(address newSafeSingleton);

    /**
     * @notice Emitted when the default Royco guard is updated.
     * @param newRoycoGuard Address of the new guard contract used for future deployments.
     */
    event RoycoGuardSet(address newRoycoGuard);

    /**
     * @notice Emitted when the default Royco executor module is updated.
     * @param newRoycoExecutor The address of the new executor module used for future deployments.
     */
    event RoycoMiddlewareSet(address newRoycoExecutor);

    /// @notice Thrown when an ostensible Royco account wasn't deployed by this factory.
    error NotRoycoAccount();

    /**
     * @notice Initializes the Royco account Factory.
     * @param _owner The owner of the factory.
     * @param _multiSend The Safe `MultiSendCallOnly` contract.
     * @param _safeSingleton The Royco account (or Royco accountL2) implementation.
     * @param _roycoMiddleware The default middleware contract that is installed as a Safe guard and module when a new Royco account is deployed.
     */
    constructor(address _owner, address _multiSend, address _safeSingleton, address _roycoMiddleware) Ownable(_owner) {
        // Initialize the Account Factory state
        MULTISEND = _multiSend;

        safeSingleton = _safeSingleton;
        emit SafeSingletonSet(_safeSingleton);

        roycoMiddleware = _roycoMiddleware;
        emit RoycoMiddlewareSet(_roycoMiddleware);
    }

    /**
     * @notice Deploys a Royco account for the invokers next Royco Account ID.
     * @param _owners The initial owners of the Safe.
     * @param _threshold The number of required confirmations required to execute a Safe transaction.
     * @return accountId The Account ID corresponding to the invokers Royco account deployment.
     * @return roycoAccount The address of the newly deployed Royco account.
     */
    function deployRoycoAccount(address[] calldata _owners, uint256 _threshold) external returns (uint96 accountId, address roycoAccount) {
        // Cache the user's next account ID and increment it
        accountId = userToNextAccountId[msg.sender]++;

        // Deploy the user's Royco account with this account's next deployment salt
        roycoAccount = safeSingleton.cloneDeterministic(keccak256(abi.encodePacked(msg.sender, accountId)));

        // Set the Safe signers and threshold
        // Install the default Royco guard and executor module
        _setupRoycoAccount(roycoAccount, _owners, _threshold);

        // Mark this Royco account as deployed by this factory
        roycoAccountToExists[roycoAccount] = true;

        // Emit an event to signal deployment
        emit RoycoAccountDeployed(msg.sender, roycoAccount);
    }

    /**
     * @notice Returns the next account ID and counterfactual deployment address for a user's Royco account.
     * @param _user The address of the user to compute the next counterfactual Royco account deployment address for.
     * @return accountId The user's next account ID tied to the Royco account deployment.
     * @return roycoAccount The counterfactual address of the Royco account corrseponding to the specified account ID of the user.
     */
    function getNextRoycoAccountCounterfactualAddress(address _user) external view returns (uint96 accountId, address roycoAccount) {
        accountId = userToNextAccountId[_user];
        roycoAccount = safeSingleton.predictDeterministicAddress(keccak256(abi.encodePacked(_user, accountId)));
    }

    /**
     * @notice Update the Safe singleton used by new deployments.
     * @param _newSafeSingleton The new Safe (or SafeL2) singleton.
     */
    function setSafeSingleton(address _newSafeSingleton) external onlyOwner {
        safeSingleton = _newSafeSingleton;
        emit SafeSingletonSet(_newSafeSingleton);
    }

    /**
     * @notice Update the default executor module that is enabled when a new Royco account is deployed.
     * @param _newRoycoMiddleware The new default executor module.
     */
    function setRoycoMiddleware(address _newRoycoMiddleware) external onlyOwner {
        roycoMiddleware = _newRoycoMiddleware;
        emit RoycoMiddlewareSet(_newRoycoMiddleware);
    }

    /**
     * @notice Completes the setup and Royco specific initialization of the newly deployed Safe.
     * @param _roycoAccount The address of the newly deployed Royco account.
     * @param _owners The initial owners of the Safe.
     * @param _threshold The number of required confirmations required to execute a Safe transaction.
     */
    function _setupRoycoAccount(address _roycoAccount, address[] calldata _owners, uint256 _threshold) internal {
        // Marshal a initialization bundle to execute on Safe setup
        // Installs the Royco middleware contract as a guard and executor module respectively
        // This entire setup occurs in a single transaction via the `MultiSendCallOnly` contract
        address middleware = roycoMiddleware;
        bytes memory roycoAccountInitBundle = abi.encodePacked(
            // First transaction in the bundle
            Enum.Operation.Call, // Basic CALL
            _roycoAccount, // Target is the deployed Royco account
            uint256(0), // msg.value is 0
            uint256(36), // Length of the `setGuard` calldata (4 byte selector + 32 byte encoded address)
            abi.encodeCall(IGuardManager.setGuard, middleware), // marshalled call to `setGuard`
            // Second transaction in the bundle
            Enum.Operation.Call, // Basic CALL
            _roycoAccount, // Target is the deployed Royco account
            uint256(0), // msg.value is 0
            uint256(36), // Length of the `enableModule` calldata (4 byte selector + 32 byte encoded address)
            abi.encodeCall(IModuleManager.enableModule, middleware) // marshalled call to `enableModule`
        );

        // Marshal the `multiSend` call with the previously marshalled initialization bundle
        bytes memory multiSendBundle = abi.encodeCall(MultiSendCallOnly.multiSend, roycoAccountInitBundle);

        // Setup the Safe with the specified signers and threshold
        // Execute the Royco specific initialization in a single transaction via the `MultiSendCallOnly` contract
        ISafe(payable(_roycoAccount)).setup(
            _owners,
            _threshold,
            MULTISEND, // DELEGATECALL target
            multiSendBundle, // The initialization calldata to execute
            address(0),
            address(0),
            0,
            payable(address(0))
        );
    }

    /**
     * @notice Checks if the ostensible Royco account was deployed by this factory.
     * @dev Internally reverts if the ostensible Royco account wasn't deployed by this factory.
     */
    function _checkIsRoycoAccount(address _ostensibleRoycoAccount) internal view {
        require(roycoAccountToExists[_ostensibleRoycoAccount], NotRoycoAccount());
    }
}
