// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import { EIP712 } from "../../../lib/openzeppelin-contracts/contracts/utils/cryptography/EIP712.sol";
import { ISafe } from "../../../lib/safe-smart-account/contracts/interfaces/ISafe.sol";
import { AbsoluteOrder, Condition, Operand } from "../common/Types.sol";

/**
 * @title OrderProcessor
 * @notice A contract which implements utilities for order hashing, basic order checks, and accounting.
 */
abstract contract OrderProcessor is EIP712 {
    /// @notice EIP-712 typehash of an Operand
    bytes32 public constant OPERAND_TYPEHASH = keccak256("Operand(address target,bytes data)");

    /// @notice EIP-712 typehash of a Condition
    bytes32 public constant CONDITION_TYPEHASH = keccak256("Condition(Operand lhs,uint8 cmp,Operand rhs)Operand(address target,bytes data)");

    /// @notice EIP-712 typehash of an Absolute Order
    bytes32 public ABSOLUTE_ORDER_TYPEHASH = keccak256(
        "AbsoluteOrder(uint32 nonce,address roycoAccount,address taker,bytes32 targetMarketHash,uint8 signalComparator,Operand rhsSignalOperand,uint8 signalConditionType,bytes executionParams,uint256 quantity,uint40 expiry,address positionManager,bytes positionManagerArgs,Condition[] preConditions,Condition[] postConditions,address feeToken,uint256 feeAmount,bool feePaidByMaker)Condition(Operand lhs,uint8 cmp,Operand rhs)Operand(address target,bytes data)"
    );

    /// @notice Mapping to keep track of cancelled orders per account
    mapping(address account => mapping(bytes32 orderHash => bool cancelled)) public accountToOrderHashToIsCancelled;

    /// @notice Mapping from order hash to the amount filled so far
    mapping(bytes32 orderHash => uint256 amountFilled) public orderHashToAmountFilled;

    /**
     * @notice Emitted when an order is cancelled.
     * @param account The account that the order hash is marked as cancelled for.
     * @param orderHash The order hash marked as cancelled for the account.
     */
    event OrderCancelled(address indexed account, bytes32 orderHash);

    /// @notice Thrown when trying to fill an order that has been cancelled.
    error CancelledOrder();

    /// @notice Thrown when trying to fill an order that has expired.
    error ExpiredOrder();

    /// @notice Thrown when the taker that is trying to fill an order isn't the whitelisted taker.
    error InvalidTaker();

    /// @notice Thrown when trying to fill an order for more than the specified quantity.
    error AmountFilledExceedsQuantity();

    /**
     * @notice Initializes the order processor.
     * @param _name The user readable name of the signing domain, i.e. the name of the DApp or the protocol.
     * @param _version The current major version of the signing domain.
     */
    constructor(string memory _name, string memory _version) EIP712(_name, _version) { }

    /**
     * @notice Returns the EIP-712 digest for an Absolute Order.
     * @param _order The AbsoluteOrder struct used to produce an EIP-712 digest.
     * @return orderHash The EIP-712 digest of the Absolute order.
     */
    function hashOrder(AbsoluteOrder calldata _order) public view returns (bytes32 orderHash) {
        orderHash = _hashTypedDataV4(
            keccak256(
                abi.encode(
                    ABSOLUTE_ORDER_TYPEHASH,
                    _order.nonce,
                    _order.roycoAccount,
                    _order.taker,
                    _order.targetMarketHash,
                    _order.signalComparator,
                    _hashOperand(_order.rhsSignalOperand),
                    _order.signalConditionType,
                    keccak256(_order.executionParams),
                    _order.quantity,
                    _order.expiry,
                    _order.positionManager,
                    keccak256(_order.positionManagerArgs),
                    _hashConditions(_order.preConditions),
                    _hashConditions(_order.postConditions),
                    _order.feeToken,
                    _order.feeAmount,
                    _order.feePaidByMaker
                )
            )
        );
    }

    /**
     * @notice Conducts basic checks on an order: signature, cancellation status, expiration, and whitelisted taker (if set).
     * @param _order The AbsoluteOrder to conduct the checks on.
     * @return roycoAccount The Royco account that was the maker of the order.
     * @return orderHash The EIP-712 digest of the order.
     */
    function _conductBasicOrderChecks(AbsoluteOrder calldata _order) internal view returns (address roycoAccount, bytes32 orderHash) {
        roycoAccount = _order.roycoAccount;
        orderHash = hashOrder(_order);
        // Check the signature is valid
        _verifyRoycoAccountSignature(roycoAccount, orderHash, _order.signature);
        // Check that the order hasn't been cancelled
        require(!accountToOrderHashToIsCancelled[roycoAccount][orderHash], CancelledOrder());
        // Check that the order hasn't expired
        require(block.timestamp < _order.expiry, ExpiredOrder());
        // Check that the taker is valid
        // Ensure that this call is being executed in the top most call frame for this transaction if a whitelisted taker isn't specified
        // Guarantees that the order's pre and post conditions can't be artificially satisfied in the same transaction
        // EOAs that have set code (EIP-7702) can't execute the transaction unless they are the whitelisted taker
        address taker = _order.taker;
        require((taker == address(0) && msg.sender == tx.origin && msg.sender.code.length == 0) || taker == msg.sender || taker == roycoAccount, InvalidTaker());
    }

    /**
     * @notice Verifies a signature against a digest for a Royco account.
     * @dev The Safe returns internally with an error code if the signature is invalid.
     * @param _roycoAccount The address of the Royco account to check the signature for.
     * @param _digest The digest to check the Royco account's signature against.
     * @param _signature The signature to validate.
     */
    function _verifyRoycoAccountSignature(address _roycoAccount, bytes32 _digest, bytes calldata _signature) internal view {
        // The executor parameter is set to the invoker on the call to check signatures
        // This removes the need for one of the taker's signature if the taker is a signer on the Royco account (maker)
        ISafe(payable(_roycoAccount)).checkSignatures(msg.sender, _digest, _signature);
    }

    /**
     * @notice Accounts for an order being filled.
     * @param _orderHash The hash of the order being filled.
     * @param _quantity The total quantity of the order
     * @param _fillAmount The amount being filled by the taker.
     */
    function _accountForFill(bytes32 _orderHash, uint256 _quantity, uint256 _fillAmount) internal {
        // Update and cache the amount filled for this order
        uint256 amountFilled = (orderHashToAmountFilled[_orderHash] += _fillAmount);
        // Ensure that the order's amount filled doesn't exceed its quantity
        require(amountFilled <= _quantity, AmountFilledExceedsQuantity());
    }

    /**
     * @notice Returns the EIP-712 digest of an array of conditions.
     * @param _conditions An array of conditions to produce a EIP-712 digest for.
     * @return conditionsHash The EIP-712 digest for the conditions array.
     */
    function _hashConditions(Condition[] calldata _conditions) internal pure returns (bytes32 conditionsHash) {
        // Get the number of conditions to hash
        uint256 numConditions = _conditions.length;
        // Preemptively return is no conditions
        if (numConditions == 0) return keccak256("");

        // Compute the number of bytes needed to store the concatenated hashes
        uint256 bufferLen = numConditions * 32;
        // Pointer to the concatenated hashes buffer
        uint256 buffer;
        assembly ("memory-safe") {
            // Set the concatenated hashes buffer pointer to the free memory pointer
            buffer := mload(0x40)
            // Seek the free memory pointer to the end of the concatenated hashes buffer
            // Free memory pointer is guaranteed be word aligned since bufferLen is a multiple of 32
            mstore(0x40, add(buffer, bufferLen))
        }

        // Pointer to the current word to write the condition hash to
        uint256 ptr = buffer;
        for (uint256 i = 0; i < numConditions; ++i) {
            // Hash the condition
            bytes32 conditionHash = _hashCondition(_conditions[i]);
            assembly ("memory-safe") {
                // Store the condition hash at the next free word in the buffer
                mstore(ptr, conditionHash)
                // Seek the pointer to the next free word in the buffer
                ptr := add(ptr, 0x20)
            }
        }

        // Hash and return the concatenated condition hashes stored in the buffer
        assembly ("memory-safe") {
            conditionsHash := keccak256(buffer, bufferLen)
        }
    }

    /**
     * @notice Returns the EIP-712 digest of a condition.
     * @param _condition The condition to produce a EIP-712 digest for.
     * @return conditionHash The EIP-712 digest for the condition.
     */
    function _hashCondition(Condition calldata _condition) internal pure returns (bytes32 conditionHash) {
        conditionHash = keccak256(abi.encode(CONDITION_TYPEHASH, _hashOperand(_condition.lhs), _condition.cmp, _hashOperand(_condition.rhs)));
    }

    /**
     * @notice Returns the EIP-712 digest of an operand.
     * @param _operand The operand to produce a EIP-712 digest for.
     * @return operandHash The EIP-712 digest for the operand.
     */
    function _hashOperand(Operand calldata _operand) internal pure returns (bytes32 operandHash) {
        operandHash = keccak256(abi.encode(OPERAND_TYPEHASH, _operand.target, keccak256(_operand.data)));
    }
}
