// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import { Recipe } from "../common/Types.sol";

/**
 * @title OpenLiquidityGraph
 * @notice The Open Liquidity Graph is a directed graph connecting nodes (DeFi protocols).
 * Each directed edge represents the ability to automatically move from the source node to the target node without any potential loss (slippage, fees, realization of impermanent loss, or delays).
 * An edge exists between two nodes if the source node's output token is identical to the target node's input token. A clique is a fully connected subgraph in the OLG that revolves around a single ERC20 token.
 * Moreover, if a node’s input and output tokens are the same, it is considered to be a member of that token’s clique. Hence, a node cannot be a part of more than one clique.
 * Each node can also have a set of unidirectional edges to nodes which do not withdraw the input token. By definition, these nodes cannot be a part of a clique.
 * They can either be intermediate nodes that connect two cliques or “sinks”. All nodes within a clique share the same unidirectional edges.
 */
abstract contract OpenLiquidityGraph {
    /**
     * @notice Node - A node in the Open Liquidity Graph.
     * @dev If a node has identical input and output tokens, it is considered to be a part of that token's clique.
     *      If a node has different non-null input and output tokens, it is referred to as an intermediate node.
     *      If a node has a non-null input token and a null output token, it is referred to as an sink node.
     * @custom:field inputToken The token needed to execute the deposit recipe. This cannot be null.
     * @custom:field depositRecipe The Weiroll Recipe executed when entering a node in the OLG. The input tokens are expected to be in the sourcer when executing the recipe.
     * @custom:field liquidityQuery The Weiroll Recipe that returns the liquidity (number of withdrawable output tokens) held by an underlying position in this node.
     * @custom:field withdrawalRecipe The Weiroll Recipe executed when exiting a node in the OLG.
     * @custom:field outputToken The token returned by executing the withdrawal recipe. If null, the withdrawal recipe remits multiple tokens or can incur potential loss (slippage, fees, realization of impermanent loss, or delays).
     */
    struct Node {
        address inputToken;
        Recipe depositRecipe;
        Recipe liquidityQuery;
        Recipe withdrawalRecipe;
        address outputToken;
    }

    /**
     * @notice Mapping from node's hash to its fields.
     */
    mapping(bytes32 nodeHash => Node node) public nodeHashToNode;

    /**
     * @notice Emitted when a node is inserted into the OLG.
     * @return creator The address that inserted the node in the OLG.
     * @return nodeHash The unique identifier of the node in the OLG.
     * @param inputToken The token needed to execute the deposit recipe.
     * @param depositRecipe The Weiroll Recipe executed when entering a node in the OLG.
     * @param liquidityQuery The Weiroll Recipe that returns the liquidity held by an underlying position for this node.
     * @param withdrawalRecipe The Weiroll Recipe executed when exiting a node in the OLG.
     * @param outputToken The token returned by executing the withdrawal recipe.
     */
    event NodeInserted(
        address indexed creator,
        bytes32 nodeHash,
        address indexed inputToken,
        Recipe depositRecipe,
        Recipe liquidityQuery,
        Recipe withdrawalRecipe,
        address indexed outputToken
    );

    /**
     * @notice Thrown when trying to insert a node with the sentinel input token.
     */
    error InvalidInputToken();

    /**
     * @notice Thrown when trying to insert a node that already exists in the OLG.
     */
    error NodeAlreadyExists();

    /**
     * @notice Inserts a node into the Open Liquidity Graph.
     * @param _inputToken The token needed to execute the deposit recipe.
     * @param _depositRecipe The Weiroll Recipe executed when entering a node in the OLG. The input tokens are expected to be in the sourcer when executing the recipe.
     * @param _liquidityQuery The Weiroll Recipe that returns the liquidity held by an underlying position in this node. Must not mutate state.
     * @param _withdrawalRecipe The Weiroll Recipe executed when exiting a node in the OLG.
     * @param _outputToken The token returned by executing the withdrawal recipe.
     * @return nodeHash The unique identifier of the node in the OLG.
     */
    function insertNode(
        address _inputToken,
        Recipe calldata _depositRecipe,
        Recipe calldata _liquidityQuery,
        Recipe calldata _withdrawalRecipe,
        address _outputToken
    )
        external
        returns (bytes32 nodeHash)
    {
        // Make sure that the intended input token isn't the sentinel value
        require(_inputToken != address(0), InvalidInputToken());

        // Compute the unique identifier for this node
        nodeHash = keccak256(abi.encode(_inputToken, _depositRecipe, _liquidityQuery, _withdrawalRecipe, _outputToken));

        // Get the node storage pointer and make sure that it doesn't exist in the OLG already.
        Node storage node = nodeHashToNode[nodeHash];
        require(node.inputToken == address(0), NodeAlreadyExists());

        // Insert the node into the OLG
        node.inputToken = _inputToken;
        node.depositRecipe = _depositRecipe;
        node.liquidityQuery = _liquidityQuery;
        node.withdrawalRecipe = _withdrawalRecipe;
        node.outputToken = _outputToken;

        // Emit an event to signal node insertion
        emit NodeInserted(msg.sender, nodeHash, _inputToken, _depositRecipe, _liquidityQuery, _withdrawalRecipe, _outputToken);
    }

    /**
     * @notice Checks if there is an edge from the source node -> the target node.
     * @param _sourceNodeHash The unique unique identifier of the source node.
     * @param _targetNodeHash The unique unique identifier of the target node.
     * @return exists Boolean indicating whether an edge exists from the source node -> the target node.
     */
    function edgeExists(bytes32 _sourceNodeHash, bytes32 _targetNodeHash) public view returns (bool exists) {
        address sourceOutputToken = nodeHashToNode[_sourceNodeHash].outputToken;
        // Edge exists if the source node's output token is non-null and is equivalent to the target node's input token.
        exists = sourceOutputToken != address(0) && sourceOutputToken == nodeHashToNode[_targetNodeHash].inputToken;
    }

    /**
     * @notice Returns the liquidity query recipe for a node.
     * @param nodeHashes The unique identifier of the nodes in the OLG.
     * @return liquidityQueries The read-only recipes that report underlying liquidity.
     */
    function getLiquidityQueries(bytes32[] calldata nodeHashes) public view returns (Recipe[] memory liquidityQueries) {
        uint256 numQueries = nodeHashes.length;
        liquidityQueries = new Recipe[](numQueries);
        for (uint256 i = 0; i < numQueries; ++i) {
            liquidityQueries[i] = getLiquidityQuery(nodeHashes[i]);
        }
    }

    /**
     * @notice Returns the liquidity query recipe for a node.
     * @param nodeHash The unique identifier of the node in the OLG.
     * @return liquidityQuery The read-only recipe that reports underlying liquidity.
     */
    function getLiquidityQuery(bytes32 nodeHash) public view returns (Recipe memory liquidityQuery) {
        liquidityQuery = nodeHashToNode[nodeHash].liquidityQuery;
    }
}
