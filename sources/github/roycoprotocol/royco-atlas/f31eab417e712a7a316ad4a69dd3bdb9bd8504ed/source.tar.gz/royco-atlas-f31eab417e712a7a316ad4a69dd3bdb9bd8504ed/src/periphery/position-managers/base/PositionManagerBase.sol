// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import { RoycoAccountFactory } from "../../../core/Royco.sol";
import { IPositionManager, Source } from "../interfaces/IPositionManager.sol";

/**
 * @title PositionManagerBase
 * @notice Defines the base state and behavior of a Position Manager in Royco.
 */
abstract contract PositionManagerBase is IPositionManager {
    /// @notice The address of the canonical Royco deployment
    address public immutable ROYCO;

    /// @notice The address of the Royco Middleware contract used to interact with accounts.
    address public immutable ROYCO_MIDDLEWARE;

    /// @notice Thrown when the invoker of the `getLiquiditySources` function isn't the Royco contract
    error OnlyRoyco();

    /// @notice Thrown when there is insufficient source liquidity in the Royco account.
    error NotEnoughLiquidityAvailable();

    /// @notice Modifier to restrict the invoker of the `getLiquiditySources` function to the Royco contract
    modifier onlyRoyco() {
        require(msg.sender == ROYCO, OnlyRoyco());
        _;
    }

    /**
     * @notice Initializes the base state of a Position Manager.
     * @param _royco The address of the canonical Royco deployment.
     */
    constructor(address _royco) {
        // Immutably set the Royco contract
        ROYCO = _royco;
        // Immutably set the Royco Middleware contract associated with this deployment
        ROYCO_MIDDLEWARE = RoycoAccountFactory(_royco).roycoMiddleware();
    }
}
