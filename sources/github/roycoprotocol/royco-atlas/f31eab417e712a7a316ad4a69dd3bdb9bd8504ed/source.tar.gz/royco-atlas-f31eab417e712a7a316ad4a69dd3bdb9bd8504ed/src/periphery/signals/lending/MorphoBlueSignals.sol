// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import { IIrm, IMorpho, Id, Market, MarketParams } from "../../interfaces/IMorphoBlue.sol";

/**
 * @title MorphoBlueSignals
 * @notice A contract which retrieves market signals from Morpho Blue.
 */
contract MorphoBlueSignals {
    /// @notice Constant value for WAD (10^18)
    uint256 private constant WAD = 1e18;

    /// @notice The address of the Morpho Blue deployment
    IMorpho public immutable MORPHO;

    /**
     * @notice Initializes the Morpho Blue signals contract.
     * @param _morpho The address of the Morpho Blue deployment.
     */
    constructor(address _morpho) {
        MORPHO = IMorpho(_morpho);
    }

    /**
     * @notice Retrieves the current supply APR for the specified asset, scaled by RAY (1e27).
     * @param _marketParams The market params struct for the Morpho market to get the APR for.
     * @return supplyAprRAY The supply APR for the Morpho Market scaled by RAY (1e27).
     */
    function getCurrentSupplyApr(MarketParams calldata _marketParams) external returns (uint256 supplyAprRAY) {
        // Compute the market's ID given the params
        Id morphoMarketId = Id.wrap(keccak256(abi.encode(_marketParams)));

        // Accrue interest to ensure the market's data is updated
        // TODO: Is it worth calling this function to incur a couple BPS difference in real vs returned utilization
        // If it is, consider emulating the accrual instead of persisting it
        MORPHO.accrueInterest(_marketParams);

        // Get the market's current data
        Market memory market = MORPHO.market(morphoMarketId);

        // Get the borrow rate per second scaled by WAD from the IRM
        uint256 borrowRatePerSecondWAD = IIrm(_marketParams.irm).borrowRateView(_marketParams, market);

        // supply rate per second = borrow rate per second * utilization * (1 - fee)
        uint256 totalBorrowedAssets = market.totalBorrowAssets;
        uint256 utilization = totalBorrowedAssets == 0 ? 0 : (totalBorrowedAssets * WAD) / market.totalSupplyAssets;
        uint256 supplyRatePerSecondWAD = ((borrowRatePerSecondWAD * utilization * (WAD - market.fee)) / (WAD * WAD));

        // Convert the supply rate per second in WAD to a yearly rate in RAY
        supplyAprRAY = (supplyRatePerSecondWAD * 365 days * 1e9);
    }
}
