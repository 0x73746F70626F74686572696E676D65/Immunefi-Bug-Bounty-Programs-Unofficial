// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import { VM } from "../../../lib/enso-weiroll/contracts/VM.sol";
import { Comparator, Condition, Operand, Recipe } from "../common/Types.sol";

/**
 * @title RoycoAccountHandler
 * @notice A contract used to execute Weiroll recipes and condition checks in the context of a Royco Account.
 *         Also used to transiently store and retrieve any runtime recipe parameters used for execution.
 */
contract RoycoAccountHandler is VM {
    /**
     * @notice Immutable variable which etches the handler's address in its bytcode.
     * @dev This is used to set the amounts in and out in addition to execution params in the handler during recipe execution
     */
    address public immutable SELF;

    /**
     * @notice The address of the Royco account currently executing the recipe.
     * @dev This is stored in transient slot 0.
     */
    address transient public roycoAccount;

    /**
     * @notice The amount to deposit or withdraw upon recipe execution
     * @dev Deposit recipes interpret this as the amount of input tokens to deposit.
     * @dev Withdrawal recipes interpret this as the amount of output tokens to withdraw.
     * @dev This is stored in transient slot 1.
     */
    uint256 transient public amount;

    /// @notice Thrown when storing recipe params in the handler fails
    error FailedToStoreParams();

    /// @notice Thrown when a condition check is unsatisfied (evaluates to false)
    error ConditionCheckFailed();

    /// @notice Thrown when the recipe params are set already and trying to be set again by a different royco account
    error OnlyRoycoAccount();

    /**
     * @notice Initializes the Royco Account Handler contract.
     */
    constructor() {
        // Etch the handler's address in its bytcode: used for setting runtime recipe params.
        SELF = address(this);
    }

    /**
     * @notice Executes the deposit recipe for a Royco account.
     * @dev The Royco account must delegate call this function. Handled by Royco Middleware.
     * @param _depositRecipe The deposit recipe to execute.
     * @param _amountIn The amount of input tokens to deposit. Retrieved and used by the deposit recipe.
     * @param _executionParams Optional execution parameters used by the deposit recipe. Use is recipe dependent.
     */
    function executeDeposit(Recipe calldata _depositRecipe, uint256 _amountIn, bytes calldata _executionParams) external {
        // Store the royco account address, amount to deposit, and execution params in the transient storage of the handler contract
        (bool success,) = SELF.call(abi.encodeCall(RoycoAccountHandler.storeRecipeParams, (_amountIn, _executionParams)));
        require(success, FailedToStoreParams());
        // Execute the recipe and return the result
        _execute(_depositRecipe.commands, _depositRecipe.state);
    }

    /**
     * @notice Executes a batch of withdrawal recipes for a Royco account.
     * @dev The Royco account must delegate call this function. Handled by Royco Middleware.
     * @param _withdrawalRecipes The withdrawal recipes to execute.
     * @param _amountsOut The amount of output tokens to withdraw for each recipe. Retrieved and used by the withdrawal recipe.
     */
    function executeBatchWithdrawal(Recipe[] calldata _withdrawalRecipes, uint256[] calldata _amountsOut) external {
        // Cache the number of recipes to execute
        uint256 numRecipes = _withdrawalRecipes.length;
        for (uint256 i = 0; i < numRecipes; ++i) {
            // Store the recipe 
            executeWithdrawal( _withdrawalRecipes[i], _amountsOut[i]);
        }
    }

    /**
     * @notice Executes a withdrawal recipe for a Royco account.
     * @dev The Royco account must delegate call this function. Handled by Royco Middleware.
     * @param _withdrawalRecipe The withdrawal recipe to execute.
     * @param _amountOut The amount of output tokens to withdraw. Retrieved and used by the withdrawal recipe.
     */
    function executeWithdrawal(Recipe calldata _withdrawalRecipe, uint256 _amountOut) public {
        // Store the royco account address, amount to withdraw, and execution params in the transient storage of the handler contract
        (bool success,) = SELF.call(abi.encodeCall(RoycoAccountHandler.storeRecipeParams, (_amountOut, new bytes(0))));
        require(success, FailedToStoreParams());
        // Execute the recipe and return the result
        _execute(_withdrawalRecipe.commands, _withdrawalRecipe.state);
    }

    /**
     * @notice Executes a batch of liquidity queries for a Royco account.
     * @dev The Royco account must delegate call this function. Handled by Royco Middleware.
     * @param _liquidityQueries The liquidity queries to execute.
     * @return queryResults An array of results returned by the liquidity queries.
     */
    function executeLiquidityQueries(Recipe[] calldata _liquidityQueries) external returns (uint256[] memory queryResults) {
        // Cache the number of liquidity queries to execute
        uint256 numQueries = _liquidityQueries.length;
        // Allocate the array to return query results
        queryResults = new uint256[](numQueries);

        // Execute each liquidity query sequentially and store the result in the return array
        for (uint256 i = 0; i < numQueries; ++i) {
            queryResults[i] = executeLiquidityQuery(_liquidityQueries[i]);
        }
    }

    /**
     * @notice Executes a liquidity query for a Royco account.
     * @dev The Royco account must delegate call this function. Handled by Royco Middleware.
     * @param _liquidityQuery The liquidity query to execute.
     * @return queryResult The result returned by the liquidity query.
     */
    function executeLiquidityQuery(Recipe calldata _liquidityQuery) public returns (uint256 queryResult) {
        // Execute the liquidity query, decode its output, and return it
        bytes[] memory returnData = _execute(_liquidityQuery.commands, _liquidityQuery.state);
        queryResult = abi.decode(returnData[0], (uint256));
    }

    /**
     * @notice Evaluates a set of conditions.
     * @dev The Royco account must delegate call this function. Handled by Royco Middleware.
     * @dev Internally reverts if a condition is not satisfied.
     * @param _conditions An array of condition structs to evaluate.
     */
    function evaluateConditions(Condition[] calldata _conditions) external {
        uint256 numConditions = _conditions.length;
        for (uint256 i; i < numConditions; ++i) {
            evaluateCondition(_conditions[i]);
        }
    }

    /**
     * @notice Evaluates a condition.
     * @dev The Royco account must delegate call this function. Handled by Royco Middleware.
     * @dev Internally reverts if a condition is not satisfied.
     * @param _condition The condition struct to evaluate.
     */
    function evaluateCondition(Condition calldata _condition) public {
        _evaluateDiscreteCondition(_resolveOperand(_condition.lhs), _condition.cmp, _resolveOperand(_condition.rhs));
    }

    /**
     * @notice Stores the runtime recipe parameters in the handler before a recipe is executed.
     * @dev The parameters are stored in and can be read from the transient storage of the handler (SELF).
     * @dev This function automatically sets the Royco account executing this call in the `roycoAccount` transient variable.
     * @param _amount The amount parameter to set in the handler's transient storage. 
     *                This is interpreted as amount to deposit for deposit recipes and amount to withdraw for withdrawal recipes.
     * @param _executionParams Optional execution parameters used by deposit recipes. Use is recipe dependent.
     */
    function storeRecipeParams(uint256 _amount, bytes calldata _executionParams) external {
        // Ensure that the params are only set once during the lifetime of the transaction
        require(roycoAccount == address(0) || msg.sender == roycoAccount, OnlyRoycoAccount());

        // Store the address of the royco account currently executing the recipe in transient storage
        // The Royco Account delegate calls into the handler's recipe execution functions which calls this function on SELF
        // Hence, msg.sender == The Royco Account executing the recipe
        roycoAccount = msg.sender;

        // Store the amount to deposit or withdraw in transient storage
        amount = _amount;

        // Return if no execution params to set
        if (_executionParams.length == 0) return;

        // Store the execution params in transient storage
        assembly ("memory-safe") {
            // Get the length in bytes of execution params
            let executionParamsLen := _executionParams.length
            // Store the length of the params in transient slot 2 (after slot 0 and 1 used by roycoAccount and amount)
            tstore(2, executionParamsLen)
            // Get the calldata pointer for the start of the execution params data
            let ptr := _executionParams.offset
            // Compute the end of the calldata buffer
            let bufferEnd := add(ptr, executionParamsLen)

            // Copy the execution params data to transient storage
            for { let tslot := 3 } // The first word of the execution params is written after the length slot
            lt(ptr, bufferEnd) {
                // Keep looping until the entire buffer is copied to transient storage
                ptr := add(ptr, 0x20) // Each iteration writes 32 bytes to the transient slot
                tslot := add(tslot, 1) // Each word is sequentially written in transient storage
            } {
                // Write the current word to the next free transient slot
                tstore(tslot, calldataload(ptr))
            }
        }
    }

    /**
     * @notice Gets the recipe's execution parameters from the handler's transient storage during recipe execution.
     * @return executionParams Optional execution parameters used by the deposit recipe. Use is recipe dependent.
     */
    function getExecutionParams() external view returns (bytes memory executionParams) {
        assembly ("memory-safe") {
            // Set the execution params pointer to the free memory pointer
            executionParams := mload(0x40)
            // Get the length of the execution params
            let executionParamsLen := tload(2)
            // Store the length of execution params in the first word of the buffer
            mstore(executionParams, executionParamsLen)
            // Pointer to the first byte of the actual execution params
            let ptr := add(executionParams, 0x20)
            // Compute the end of the memory buffer
            let bufferEnd := add(ptr, executionParamsLen)
            // Seek the free memory pointer to after the execution params buffer
            // Apply a mask on the buffer length to ensure that the free memory pointer is word aligned
            mstore(0x40, add(ptr, and(add(executionParamsLen, 0x1F), not(0x1F))))

            // Copy the transiently stored execution params into the memory buffer
            for { let tslot := 3 } // Transient slot for the first word of the params
            lt(ptr, bufferEnd) {
                // Keep looping until the params are fully copied
                ptr := add(ptr, 0x20) // Each iteration copies 32 bytes to the buffer
                tslot := add(tslot, 1) // Each word is stored in sequential transient slots
            } {
                // Copy the current transient slot's word into the buffer's next word
                mstore(ptr, tload(tslot))
            }
        }
    }

    /**
     * @notice Resolves an operand struct to a discrete (uint256) value.
     * @dev Internally reverts if an operand can't be resolved.
     * @param _operand The operand struct to resolve to a discrete (uint256) value.
     * @return resolvedOperand The discrete (uint256) value of the operand after resolution.
     */
    function _resolveOperand(Operand calldata _operand) internal returns (uint256 resolvedOperand) {
        // If the target is the null address, data contains a uint256 literal
        if (_operand.target == address(0)) {
            // Decode the literal
            resolvedOperand = abi.decode(_operand.data, (uint256));
        } else {
            // Else make the external call, ensure that it succeeds, and decode the returned uint256
            (bool success, bytes memory returnData) = _operand.target.call(_operand.data);
            require(success, ConditionCheckFailed());
            resolvedOperand = abi.decode(returnData, (uint256));
        }
    }

    /**
     * @notice Evaluates a condition with discrete operands and a comparator.
     * @dev Internally reverts if the condition is unsatisfied.
     * @param _lhs The discrete left-hand side operand.
     * @param _cmp The binary comparator used to evaluate the condition.
     * @param _rhs The discrete right-hand side operand.
     */
    function _evaluateDiscreteCondition(uint256 _lhs, Comparator _cmp, uint256 _rhs) internal pure {
        // Initialize a boolean indicating whether the condition is satified
        bool satisfied;
        assembly ("memory-safe") {
            // Switch to evalutate the condition and set the value of satisfied to the result
            switch _cmp
            // Less than case
            case 0 { satisfied := lt(_lhs, _rhs) }
            // Greater than case
            case 1 { satisfied := gt(_lhs, _rhs) }
            // Less than or equal to case
            case 2 { satisfied := or(lt(_lhs, _rhs), eq(_lhs, _rhs)) }
            // Greater than or equal to case
            case 3 { satisfied := or(gt(_lhs, _rhs), eq(_lhs, _rhs)) }
            // Equal to case
            case 4 { satisfied := eq(_lhs, _rhs) }
            // Not equal to case
            case 5 { satisfied := not(eq(_lhs, _rhs)) }
        }
        // Throw an error if the condition is not satisfied
        require(satisfied, ConditionCheckFailed());
    }
}
