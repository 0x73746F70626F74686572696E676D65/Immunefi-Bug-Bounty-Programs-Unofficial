// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import { IERC20 } from "../../../lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol";
import { IAaveOracle, IPool, IPoolDataProvider } from "../interfaces/IAaveV3.sol";

/**
 * @title AaveV3LiquidityQueryHelper
 * @notice A helper contract which exposes a function to get the invoker's maximum number of automatically withdrawable tokens from Aave V3.
 */
contract AaveV3LiquidityQueryHelper {
    /// @notice The address of the Aave V3 Pool deployment.
    IPool public immutable POOL;

    /// @notice The address of the Aave V3 Pool Data Provider deployment.
    IPoolDataProvider public immutable DATA_PROVIDER;

    /// @notice The address of the Aave V3 Oracle deployment.
    IAaveOracle public immutable ORACLE;

    /**
     * @notice Initialize the Aave V3 liquidity query helper contract.
     * @param _pool The address of the Aave V3 Pool deployment.
     * @param _dataProvider The address of the Aave V3 PoolDataProvider deployment.
     * @param _oracle The address of the Aave V3 Price Oracle deployment.
     */
    constructor(address _pool, address _dataProvider, address _oracle) {
        // Initialize the helper state
        POOL = IPool(_pool);
        DATA_PROVIDER = IPoolDataProvider(_dataProvider);
        ORACLE = IAaveOracle(_oracle);
    }

    /**
     * @notice Returns the maximum assets a user can withdraw right now from Aave V3.
     * @dev If the invoker has any existant debt and the asset is enabled as collateral, the function will return 0.
     * @param _asset The asset to return the max withdrawable amount for.
     */
    function getMaxWithdrawableAssets(address _asset) external view returns (uint256) {
        // Get the aToken balance of the user (invoker) for the specified asset
        // This is redeemable 1 to 1 for the underlying asset
        (uint256 aTokenBalance,,,,,,,,) = DATA_PROVIDER.getUserReserveData(_asset, msg.sender);

        // Get the balance of the underlying asset in the aToken contract
        // This is the upper bound of withdrawable tokens
        (address aToken,,) = DATA_PROVIDER.getReserveTokensAddresses(_asset);
        uint256 idleAssets = IERC20(_asset).balanceOf(aToken);
        if (idleAssets < aTokenBalance) aTokenBalance = idleAssets;

        // We need to account for the user's total debt and collateral to determine max withdrawable assets
        ( /*uint256 totalCollateralBase*/ , uint256 totalDebtBase,,,,) = POOL.getUserAccountData(msg.sender);

        // If the user has no debt, you can withdraw the entire a token balance
        if (totalDebtBase == 0) return aTokenBalance;

        // Get the reserve config for the specified asset
        ( /*uint256 reserveDecimals*/ ,, uint256 liquidationThresholdBPS,,, bool usageAsCollateralEnabled,,,,) =
            DATA_PROVIDER.getReserveConfigurationData(_asset);

        // If this asset can't be used as collateral, it won't affect the user's HF, so they can withdraw everything
        if (!usageAsCollateralEnabled || liquidationThresholdBPS == 0) return aTokenBalance;

        // If the user has any debt and this asset is being used as collateral, nothing is withdrawable
        return 0;

        // TODO: Decide whether existent debt should negate a position's withdrawability completely
        // Below is the logic for calculating max withdrawable if withdrawals are enabled for users with existent debt

        // Get the oracle price for the asset in WAD to do the HF calculations on base values of the user's account state
        // uint256 price = ORACLE.getAssetPrice(_asset); // 1e18

        // HF = (totalCollateralBase * (liquidationThresholdBPS / 10_000)) / totalDebtBase
        // Withdraw of collateral stipulates that HF >= 1
        // If the user withdraws x tokens, here is the inequality to satisfy:
        // ((totalCollateralBase - (x * price))  * (liquidationThresholdBPS / 10_000) ) / totalDebtBase == 1
        // x = (totalCollateralBase - (totalDebtBase * 10_000) / liquidationThresholdBPS))) / price
        // uint256 maxWithdrawableBase = (totalCollateralBase - (totalDebtBase * 10_000) / liquidationThresholdBPS) / price;

        // // Convert the max withdrawable from base asset to target asset
        // uint256 maxWithdrawableAssets = (maxWithdrawableBase * (10 ** reserveDecimals) * ORACLE.BASE_CURRENCY_UNIT()) / 1e18;

        // // Make sure you are returning more than the aToken balance for this asset (can't comingle withdrawals with other lent assets)
        // if (maxWithdrawableAssets >= aTokenBalance) return aTokenBalance;
        // return maxWithdrawableAssets;
    }
}
