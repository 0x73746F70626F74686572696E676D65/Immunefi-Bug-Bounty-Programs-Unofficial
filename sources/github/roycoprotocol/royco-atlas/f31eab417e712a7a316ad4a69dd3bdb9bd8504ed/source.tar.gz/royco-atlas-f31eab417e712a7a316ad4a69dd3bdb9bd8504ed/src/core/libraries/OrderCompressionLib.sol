pragma solidity ^0.8.0;

import { LibZip } from "../../../lib/solady/src/utils/LibZip.sol";
import { AbsoluteOrder } from "../common/Types.sol";

library OrderCompressionLib {
    using LibZip for bytes;

    function compress(AbsoluteOrder calldata _order) internal pure returns (bytes memory compressedOrder) {
        assembly ("memory-safe") {
            /**
             * @notice Compresses and writes a dynamic bytes array starting at the specified pointer in the compressed order buffer.
             * @param ptr The pointer in the compressed order buffer to start writing the bytes array at.
             * @param bytesLenPtr The pointer to the length of the bytes array in calldata.
             * @param nextPtr The pointer in the compressed order buffer to resume writing data at.
             */
            function writeBytes(ptr, bytesLenPtr) -> nextPtr {
                // Retrieve the length of the bytes array
                let bufferLen := calldataload(bytesLenPtr)
                // Store the length of the bytes array in the next 2 bytes
                mstore(ptr, shl(240, bufferLen))
                // Copy the bytes array into the subsequent buffer of its length
                calldatacopy(add(ptr, 2), add(bytesLenPtr, 32), bufferLen)
                // Update the next pointer to write data at to be after the bytes array
                nextPtr := add(add(ptr, 2), bufferLen)
            }

            /**
             * @notice Compresses and writes an operand starting at the specified pointer in the compressed order buffer.
             * @param ptr The pointer in the compressed order buffer to start writing the operand at.
             * @param operandPtr The pointer to the operand in calldata.
             * @param nextPtr The pointer in the compressed order buffer to resume writing data at.
             */
            function writeOperand(ptr, operandPtr) -> nextPtr {
                let target := calldataload(operandPtr)
                // Store the operand target in the next 20 bytes
                mstore(ptr, shl(96, target))
                // Check if the specified target is the null address or not
                // If the target is the null address (default case), the data is an encoded uint256
                // Else (case 0), the data is a dynamically encoded bytes array
                switch iszero(target)
                case 0 {
                    // Data is a dynamically encoded bytes array
                    // Write the operand's data in subsequent memory
                    nextPtr := writeBytes(add(ptr, 20), add(operandPtr, 64))
                }
                default {
                    // Data is an encoded uint256
                    mstore(add(ptr, 20), calldataload(add(operandPtr, 96)))
                    // Increment the pointer to be after the target and the uint256
                    nextPtr := add(ptr, 52)
                }
            }

            /**
             * @notice Compresses and writes an array of conditions.
             * @param ptr The pointer in the compressed order buffer to start writing the conditions array at.
             * @param conditionsPtr The pointer to the length of the conditions array in calldata.
             * @param nextPtr The pointer in the compressed order buffer to resume writing data at.
             */
            function writeConditions(ptr, conditionsPtr) -> nextPtr {
                // Get the number of the conditions to write
                let conditionsLen := calldataload(conditionsPtr)
                // Write the array length in the next 2 bytes
                mstore(ptr, shl(240, conditionsLen))
                // Update the pointer to be after the length
                ptr := add(ptr, 2)
                // Write each condition in a compressed format
                for { let i := 0 } lt(i, conditionsLen) { i := add(i, 1) } {
                    // Get the pointer to the condition head
                    let conditionPtr := add(conditionsPtr, calldataload(add(conditionsPtr, add(32, mul(i, 32)))))
                    // Write the condition's LHS operand in the subsequent bytes and get the updated write pointer
                    ptr := writeOperand(ptr, add(conditionPtr, calldataload(conditionPtr)))
                    // Write the condition's comparator in the following byte
                    mstore8(ptr, calldataload(add(conditionPtr, 32)))
                    // Write the condition's RHS operand in the subsequent bytes and get the updated write pointer
                    ptr := writeOperand(add(ptr, 1), add(conditionPtr, calldataload(add(conditionPtr, 64))))
                }
                // Update the next pointer to write data at to be after the conditions array
                nextPtr := ptr
            }

            // Allocate the buffer for the compressed order starting at the free memory pointer
            compressedOrder := mload(0x40)
            // A pointer starting at the first byte (after length) of the compressed order buffer
            let ptr := add(compressedOrder, 32)

            // Store the nonce in the first 4 bytes of the buffer
            mstore(ptr, shl(224, calldataload(_order)))
            // Store the royco account in the next 20 bytes
            mstore(add(ptr, 4), shl(96, calldataload(add(_order, 32))))
            // Store the taker in the next 20 bytes
            mstore(add(ptr, 24), shl(96, calldataload(add(_order, 64))))
            // Store the target market hash in the next 32 bytes
            mstore(add(ptr, 44), calldataload(add(_order, 96)))
            // Store the signal comparator in the next byte
            mstore8(add(ptr, 76), calldataload(add(_order, 128)))
            // Write the RHS signal operand in the following bytes and update the pointer to after the operand
            ptr := writeOperand(add(ptr, 77), add(_order, calldataload(add(_order, 160))))
            // Write the signal condition type in the next byte
            mstore8(ptr, calldataload(add(_order, 192)))
            // Write the execution params in the following bytes and update the pointer to after the params
            ptr := writeBytes(add(ptr, 1), add(_order, calldataload(add(_order, 224))))
            // Write the quantity in the next 32 bytes
            mstore(ptr, calldataload(add(_order, 256)))
            // Write the expiry in the next 5 bytes
            mstore(add(ptr, 32), shl(216, calldataload(add(_order, 288))))
            // Write the position manager in the next 20 bytes
            mstore(add(ptr, 37), shl(96, calldataload(add(_order, 320))))
            // Write the position manager args in the following bytes and update the pointer to after the args
            ptr := writeBytes(add(ptr, 57), add(_order, calldataload(add(_order, 352))))
            // Write the pre-conditions
            ptr := writeConditions(ptr, add(_order, calldataload(add(_order, 384))))
            // Write the post-conditions
            ptr := writeConditions(ptr, add(_order, calldataload(add(_order, 416))))
            // Write the fee token in the next 20 bytes
            mstore(ptr, shl(96, calldataload(add(_order, 448))))
            // Write the fee amount in the next 20 bytes
            mstore(add(ptr, 20), calldataload(add(_order, 480)))
            // Write the boolean inditicating whether the fee is paid by the maker in in the next byte
            mstore8(add(ptr, 52), calldataload(add(_order, 512)))
            // Write the signature in the following bytes
            ptr := writeBytes(add(ptr, 53), add(_order, calldataload(add(_order, 544))))

            // Compute the final size of the compressed order including its length
            let bufferSize := sub(ptr, compressedOrder)
            // Store the length of the compressed order buffer (subtract 32 bytes for its length)
            mstore(compressedOrder, sub(bufferSize, 32))
            // Seek the free memory pointer to after the compressed order buffer including its length
            mstore(0x40, add(compressedOrder, bufferSize))
        }

        // Apply FastLZ compression to further compress the order
        return compressedOrder.flzCompress();
    }

    function decompress(bytes memory _compressedOrder) internal pure returns (AbsoluteOrder memory order) {
        // Apply FastLZ decompression to partially decompress the order
        bytes memory partiallyDecompressedOrder = _compressedOrder.flzDecompress();
    }
}
