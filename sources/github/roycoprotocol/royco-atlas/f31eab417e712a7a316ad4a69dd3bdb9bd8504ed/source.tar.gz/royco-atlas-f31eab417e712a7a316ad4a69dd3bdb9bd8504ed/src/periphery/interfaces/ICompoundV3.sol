// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

interface IComet {
    function utilization() external view returns (uint256);
    function supplyRate(uint256 utilization) external view returns (uint64);
}
