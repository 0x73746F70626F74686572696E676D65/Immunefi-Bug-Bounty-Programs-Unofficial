// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import { IPool } from "../../interfaces/IAaveV3.sol";

/**
 * @title AaveV3Signals
 * @notice A contract which retrieves market signals from Aave V3.
 */
contract AaveV3Signals {
    /// @notice The address of the Aave V3 Pool deployment
    address public immutable POOL;

    /// @notice Thrown when call to get an asset's supply APR reverts
    error FailedToGetReserveData();

    /**
     * @notice Initializes the Aave V3 signals contract.
     * @param _pool The address of the Aave V3 Pool deployment.
     */
    constructor(address _pool) {
        POOL = _pool;
    }

    /**
     * @notice Retrieves the current supply APR for the specified asset in the pool, scaled by RAY (1e27).
     * @param _asset The asset to retrieve the supply APR for.
     * @return supplyAprRAY The supply APR for the asset in the pool scaled by RAY (1e27).
     */
    function getCurrentSupplyApr(address _asset) external view returns (uint256 supplyAprRAY) {
        // Make a static call to the Pool to retrieve the current reserve data and check that it succeeds
        (bool success, bytes memory ret) = POOL.staticcall(abi.encodeCall(IPool.getReserveData, (_asset)));
        require(success, FailedToGetReserveData());

        // Decode the first three elements of the reserve data, discarding the rest, and return the APR
        (,, supplyAprRAY) = abi.decode(ret, (uint256, uint128, uint128));
    }
}
