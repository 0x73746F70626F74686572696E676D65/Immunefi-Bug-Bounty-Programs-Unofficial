// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

import { IERC20 } from "../../../lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol";
import { RoycoMiddleware } from "../../core/Royco.sol";
import { PositionManagerBase, Source } from "./base/PositionManagerBase.sol";

/**
 * @title FifoPositionManager
 * @notice A Position Manager which sources liquidity from a user specified queue of nodes in the OLG.
 */
contract FifoPositionManager is PositionManagerBase {
    /**
     * @notice Initializes the FIFO Position Manager contract.
     * @param _royco The address of the canonical Royco deployment.
     */
    constructor(address _royco) PositionManagerBase(_royco) { }

    /**
     * @notice Returns the sources and the amounts of liquidity to pull to facilitate a Royco order fill.
     * @param _roycoAccount The Royco account to source the liquidity from.
     * @param _token The ERC20 token to source the liquidity in.
     * @param _totalLiquidityToSource The total amount of liquidity (in the token's precision) to source.
     * @param _positionManagerArgs An ABI encoded queue of nodes defining the order of sources to pull the liquidity from.
     *                             The sentinel value (bytes32(0)) indicates that the source is the Royco account's token balance.
     * @return sources The sources and the amounts of liquidity to pull from each.
     */
    function getLiquiditySources(
        address _roycoAccount,
        address _token,
        uint256 _totalLiquidityToSource,
        bytes calldata _positionManagerArgs
    )
        external
        override
        onlyRoyco
        returns (Source[] memory sources)
    {
        // Get the queue of nodes to process the withdrawals with in a FIFO manner
        bytes32[] memory nodeWithdrawalQueue = abi.decode(_positionManagerArgs, (bytes32[]));

        // Iterate through the queue, execute the liquidity queries until enough liquidity is freed
        uint256 queueLength = nodeWithdrawalQueue.length;
        sources = new Source[](queueLength);
        uint256 numSources;
        for (uint256 i = 0; (i < queueLength) && (_totalLiquidityToSource != 0); ++i) {
            // Cache the node hash
            bytes32 nodeHash = nodeWithdrawalQueue[i];
            uint256 liquidity;
            // If the nodeHash is the sentinel value, use the Royco account's token balance as the source
            if (nodeHash == bytes32(0)) {
                liquidity = IERC20(_token).balanceOf(_roycoAccount);
            } else {
                // Get the liquidity present in the OLG node for this Royco Account
                liquidity = RoycoMiddleware(ROYCO_MIDDLEWARE).executeLiquidityQuery(_roycoAccount, nodeHash);
            }

            // If no liquidity exists in this node, continue to the next one
            if (liquidity == 0) continue;

            // Compute the liquidity that needs to be freed from this node based on the amount still needed
            uint256 liquidityToFree = liquidity > _totalLiquidityToSource ? _totalLiquidityToSource : liquidity;

            // Update the sources
            sources[numSources++] = Source(nodeHash, liquidityToFree);
            // Decrement the liquidity needed after accounting for the free
            _totalLiquidityToSource -= liquidityToFree;
        }

        // If the queue doesn't contain enough liquidity, throw an error
        require(_totalLiquidityToSource == 0, NotEnoughLiquidityAvailable());

        // Update the length of the sources array to the actual number and return
        assembly ("memory-safe") {
            mstore(sources, numSources)
        }
    }
}
