# Royco Atlas: Crypto's Capital Marketplace [![CI](https://github.com/roycoprotocol/royco-atlas/actions/workflows/test.yml/badge.svg)](https://github.com/roycoprotocol/royco-atlas/actions/workflows/test.yml)


## Overview

### Background
In DeFi, everyone needs liquidity. Projects depend on liquidity for many things: protocol functionality, token trading, price stability, security, market sentiment, etc.

However, there is finite supply of liquidity – so projects fight and compete to offer better incentives, narrative, and yields in hopes of attracting liquidity.

What if LPs didn’t have to choose 1 platform to bring their liquidity to? What if LPs could bring their liquidity to multiple venues at the same time? What if liquidity was no longer a scarce resource? What if liquidity could be everywhere, all the time, all at once?

### Introducing Royco Atlas 
Royco Atlas is a protocol that allows LPs to submit conditional orders (aka “ghost orders”) that enable liquidity to remain actively deployed in one venue, yet instantly and atomically callable to another venue (or multiple) when certain onchain conditions are met. With enforceable onchain guarantees, these intents enable liquidity to be logically present in multiple venues at once without compromising execution integrity or capital efficiency.