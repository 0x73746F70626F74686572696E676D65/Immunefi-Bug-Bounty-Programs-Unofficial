import {
  assert,
  describe,
  test,
  clearStore,
  beforeAll,
  afterAll
} from "matchstick-as/assembly/index"
import { Address, BigInt } from "@graphprotocol/graph-ts"
import { OwnershipTransferred } from "../generated/schema"
import { OwnershipTransferred as OwnershipTransferredEvent } from "../generated/WrappedVaultFactory/WrappedVaultFactory"
import { handleOwnershipTransferred } from "../src/wrapped-vault-factory"
import { createOwnershipTransferredEvent } from "./wrapped-vault-factory-utils"

// Tests structure (matchstick-as >=0.5.0)
// https://thegraph.com/docs/en/developer/matchstick/#tests-structure-0-5-0

describe("Describe entity assertions", () => {
  beforeAll(() => {
    let user = Address.fromString("0x0000000000000000000000000000000000000001")
    let newOwner = Address.fromString(
      "0x0000000000000000000000000000000000000001"
    )
    let newOwnershipTransferredEvent = createOwnershipTransferredEvent(
      user,
      newOwner
    )
    handleOwnershipTransferred(newOwnershipTransferredEvent)
  })

  afterAll(() => {
    clearStore()
  })

  // For more test scenarios, see:
  // https://thegraph.com/docs/en/developer/matchstick/#write-a-unit-test

  test("OwnershipTransferred created and stored", () => {
    assert.entityCount("OwnershipTransferred", 1)

    // 0xa16081f360e3847006db660bae1c6d1b2e17ec2a is the default address used in newMockEvent() function
    assert.fieldEquals(
      "OwnershipTransferred",
      "0xa16081f360e3847006db660bae1c6d1b2e17ec2a-1",
      "user",
      "0x0000000000000000000000000000000000000001"
    )
    assert.fieldEquals(
      "OwnershipTransferred",
      "0xa16081f360e3847006db660bae1c6d1b2e17ec2a-1",
      "newOwner",
      "0x0000000000000000000000000000000000000001"
    )

    // More assert options:
    // https://thegraph.com/docs/en/developer/matchstick/#asserts
  })
})
