// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { IERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol";
import { MockERC20 } from "../utils/MockERC20.sol";
import { RoycoForkMainnetBase } from "../utils/RoycoForkMainnetBase.sol";
import { RoycoReserve, RoycoRoles } from "../utils/RoycoTestBase.sol";

contract ReserveTest is RoycoForkMainnetBase {
    uint256 internal constant SEED_BALANCE = 1_000_000 * 1e18;

    function setUp() external {
        _setUpRoyco();
    }

    function test_Deployment() external view {
        assertEq(reserve.owner(), OWNER_ADDRESS);
        assertTrue(reserve.hasAllRoles(address(teller), RoycoRoles.TELLER));
        assertTrue(reserve.hasAllRoles(address(flashLender), RoycoRoles.LENDER));
        assertTrue(reserve.hasAllRoles(RESERVE_MANAGER_ADDRESS, RoycoRoles.RESERVE_MANAGER));
        assertTrue(reserve.hasAllRoles(address(sRoyUSD), RoycoRoles.STAKING));
        assertEq(reserve.ROY_USD(), address(royUSD));
    }

    function testFuzz_FreeReserves(uint256 _amount, uint256 _collateralIndex, uint256 _recipientIndex, uint256 _seedMultiplier) external {
        _seedReserveWithAllAssets(_seedMultiplier);
        uint256 baseSeed = bound(_seedMultiplier, 1_000_000, SEED_BALANCE);

        address collateral = collateralAssets[_collateralIndex % collateralAssets.length];
        address recipient = _getRandomRecipient(_recipientIndex);
        uint8 decimals = MockERC20(collateral).decimals();
        uint256 maxAmount = baseSeed * (10 ** decimals) / (10 ** 18);
        if (maxAmount < 1000) maxAmount = 1000;
        _amount = bound(_amount, 1, maxAmount);

        uint256 recipientBalanceBefore = IERC20(collateral).balanceOf(recipient);
        uint256 reserveBalanceBefore = IERC20(collateral).balanceOf(address(reserve));

        // Store balances of other assets to verify they remain unchanged
        uint256[] memory otherAssetBalancesBefore = new uint256[](collateralAssets.length + 1);
        for (uint256 i = 0; i < collateralAssets.length; i++) {
            if (collateralAssets[i] != collateral) {
                otherAssetBalancesBefore[i] = IERC20(collateralAssets[i]).balanceOf(address(reserve));
            }
        }
        otherAssetBalancesBefore[collateralAssets.length] = IERC20(address(royUSD)).balanceOf(address(reserve));

        // Test with RESERVE_MANAGER role
        vm.expectEmit(true, true, false, true);
        emit IERC20.Transfer(address(reserve), recipient, _amount);

        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.freeReserves(collateral, recipient, _amount);

        assertEq(IERC20(collateral).balanceOf(recipient), recipientBalanceBefore + _amount);
        assertEq(IERC20(collateral).balanceOf(address(reserve)), reserveBalanceBefore - _amount);

        // Verify other asset balances remain unchanged
        for (uint256 i = 0; i < collateralAssets.length; i++) {
            if (collateralAssets[i] != collateral) {
                assertEq(IERC20(collateralAssets[i]).balanceOf(address(reserve)), otherAssetBalancesBefore[i]);
            }
        }
        assertEq(IERC20(address(royUSD)).balanceOf(address(reserve)), otherAssetBalancesBefore[collateralAssets.length]);
    }

    function testFuzz_FreeReservesWithTeller(uint256 _amount, uint256 _collateralIndex, uint256 _recipientIndex, uint256 _seedMultiplier) external {
        _seedReserveWithAllAssets(_seedMultiplier);
        uint256 baseSeed = bound(_seedMultiplier, 1_000_000, SEED_BALANCE);

        address collateral = collateralAssets[_collateralIndex % collateralAssets.length];
        address recipient = _getRandomRecipient(_recipientIndex);
        uint8 decimals = MockERC20(collateral).decimals();
        uint256 maxAmount = baseSeed * (10 ** decimals) / (10 ** 18);
        if (maxAmount < 1000) maxAmount = 1000;
        _amount = bound(_amount, 1, maxAmount);

        uint256 recipientBalanceBefore = IERC20(collateral).balanceOf(recipient);
        uint256 reserveBalanceBefore = IERC20(collateral).balanceOf(address(reserve));

        // Store balances of other assets to verify they remain unchanged
        uint256[] memory otherAssetBalancesBefore = new uint256[](collateralAssets.length + 1);
        for (uint256 i = 0; i < collateralAssets.length; i++) {
            if (collateralAssets[i] != collateral) {
                otherAssetBalancesBefore[i] = IERC20(collateralAssets[i]).balanceOf(address(reserve));
            }
        }
        otherAssetBalancesBefore[collateralAssets.length] = IERC20(address(royUSD)).balanceOf(address(reserve));

        // Test with TELLER role
        vm.expectEmit(true, true, false, true);
        emit IERC20.Transfer(address(reserve), recipient, _amount);

        vm.prank(address(teller));
        reserve.freeReserves(collateral, recipient, _amount);

        assertEq(IERC20(collateral).balanceOf(recipient), recipientBalanceBefore + _amount);
        assertEq(IERC20(collateral).balanceOf(address(reserve)), reserveBalanceBefore - _amount);

        // Verify other asset balances remain unchanged
        for (uint256 i = 0; i < collateralAssets.length; i++) {
            if (collateralAssets[i] != collateral) {
                assertEq(IERC20(collateralAssets[i]).balanceOf(address(reserve)), otherAssetBalancesBefore[i]);
            }
        }
        assertEq(IERC20(address(royUSD)).balanceOf(address(reserve)), otherAssetBalancesBefore[collateralAssets.length]);
    }

    function testFuzz_FreeReservesWithLender(uint256 _amount, uint256 _collateralIndex, uint256 _recipientIndex, uint256 _seedMultiplier) external {
        _seedReserveWithAllAssets(_seedMultiplier);
        uint256 baseSeed = bound(_seedMultiplier, 1_000_000, SEED_BALANCE);

        address collateral = collateralAssets[_collateralIndex % collateralAssets.length];
        address recipient = _getRandomRecipient(_recipientIndex);
        uint8 decimals = MockERC20(collateral).decimals();
        uint256 maxAmount = baseSeed * (10 ** decimals) / (10 ** 18);
        if (maxAmount < 1000) maxAmount = 1000;
        _amount = bound(_amount, 1, maxAmount);

        uint256 recipientBalanceBefore = IERC20(collateral).balanceOf(recipient);
        uint256 reserveBalanceBefore = IERC20(collateral).balanceOf(address(reserve));

        // Store balances of other assets to verify they remain unchanged
        uint256[] memory otherAssetBalancesBefore = new uint256[](collateralAssets.length + 1);
        for (uint256 i = 0; i < collateralAssets.length; i++) {
            if (collateralAssets[i] != collateral) {
                otherAssetBalancesBefore[i] = IERC20(collateralAssets[i]).balanceOf(address(reserve));
            }
        }
        otherAssetBalancesBefore[collateralAssets.length] = IERC20(address(royUSD)).balanceOf(address(reserve));

        // Test with LENDER role
        vm.expectEmit(true, true, false, true);
        emit IERC20.Transfer(address(reserve), recipient, _amount);

        vm.prank(address(flashLender));
        reserve.freeReserves(collateral, recipient, _amount);

        assertEq(IERC20(collateral).balanceOf(recipient), recipientBalanceBefore + _amount);
        assertEq(IERC20(collateral).balanceOf(address(reserve)), reserveBalanceBefore - _amount);

        // Verify other asset balances remain unchanged
        for (uint256 i = 0; i < collateralAssets.length; i++) {
            if (collateralAssets[i] != collateral) {
                assertEq(IERC20(collateralAssets[i]).balanceOf(address(reserve)), otherAssetBalancesBefore[i]);
            }
        }
        assertEq(IERC20(address(royUSD)).balanceOf(address(reserve)), otherAssetBalancesBefore[collateralAssets.length]);
    }

    function testFuzz_FreeReservesRevertsOnRoyUSD(uint256 _amount, uint256 _recipientIndex) external {
        address recipient = _getRandomRecipient(_recipientIndex);
        _amount = bound(_amount, 1, type(uint128).max);

        vm.prank(RESERVE_MANAGER_ADDRESS);
        vm.expectRevert(RoycoReserve.InvalidCollateralAsset.selector);
        reserve.freeReserves(address(royUSD), recipient, _amount);
    }

    function testFuzz_FreeUnstakedAssets(uint256 _amount, uint256 _recipientIndex, uint256 _seedMultiplier) external {
        _seedReserveWithAllAssets(_seedMultiplier);
        uint256 baseSeed = bound(_seedMultiplier, 1_000_000, SEED_BALANCE);

        address recipient = _getRandomRecipient(_recipientIndex);
        _amount = bound(_amount, 1, baseSeed);

        uint256 recipientBalanceBefore = IERC20(address(royUSD)).balanceOf(recipient);
        uint256 reserveBalanceBefore = IERC20(address(royUSD)).balanceOf(address(reserve));

        // Store balances of collateral assets to verify they remain unchanged
        uint256[] memory collateralBalancesBefore = new uint256[](collateralAssets.length);
        for (uint256 i = 0; i < collateralAssets.length; i++) {
            collateralBalancesBefore[i] = IERC20(collateralAssets[i]).balanceOf(address(reserve));
        }

        // Test with STAKING role (sRoyUSD contract)
        vm.expectEmit(true, true, false, true);
        emit IERC20.Transfer(address(reserve), recipient, _amount);

        vm.prank(address(sRoyUSD));
        reserve.freeUnstakedAssets(recipient, _amount);

        assertEq(IERC20(address(royUSD)).balanceOf(recipient), recipientBalanceBefore + _amount);
        assertEq(IERC20(address(royUSD)).balanceOf(address(reserve)), reserveBalanceBefore - _amount);

        // Verify collateral asset balances remain unchanged
        for (uint256 i = 0; i < collateralAssets.length; i++) {
            assertEq(IERC20(collateralAssets[i]).balanceOf(address(reserve)), collateralBalancesBefore[i]);
        }
    }

    function testFuzz_HypothecateAndWithdraw_USDC_AaveV3(
        uint256 _seedAmount,
        uint256 _depositBps,
        uint256 _withdrawBps,
        uint256 _extraFree,
        uint256 _recipientIndex
    )
        external
    {
        address recipient = _getRandomRecipient(_recipientIndex);

        _seedAmount = bound(_seedAmount, 1_000_000e6, 10_000_000e6);
        _depositBps = bound(_depositBps, 1, 10_000); // 0.01% - 100%
        _withdrawBps = bound(_withdrawBps, 1, 9999); // 0.01% - 99.99%

        deal(USDC, address(reserve), _seedAmount);

        uint256 toDeposit = (_seedAmount * _depositBps) / 10_000;
        uint256 toWithdraw = (toDeposit * _withdrawBps) / 10_000;

        // Deposit a portion of the seed amount
        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.hypothecateReserves(USDC, toDeposit);
        uint256 adapterBalance = IERC20(aEthUSDC).balanceOf(address(adapter));
        assertEq(IERC20(USDC).balanceOf(address(reserve)), _seedAmount - toDeposit, "USDC balance of reserve should be seed amount - toDeposit");
        assertApproxEqAbs(adapterBalance, toDeposit, 3, "aEthUSDC balance of adapter should be toDeposit");

        // Withdraw a portion back to reserve
        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.withdrawAssetsToReserve(USDC, toWithdraw);
        adapterBalance = IERC20(aEthUSDC).balanceOf(address(adapter));
        assertEq(
            IERC20(USDC).balanceOf(address(reserve)),
            _seedAmount - toDeposit + toWithdraw,
            "USDC balance of reserve should be seed amount - toDeposit + toWithdraw"
        );
        assertApproxEqAbs(adapterBalance, toDeposit - toWithdraw, 3, "aEthUSDC balance of adapter should be toDeposit - toWithdraw");

        // Validate recipient flow via freeReserves topping up from adapter if needed
        uint256 idle = IERC20(USDC).balanceOf(address(reserve));
        uint256 amountToFree = idle + bound(_extraFree, 1, adapterBalance);
        uint256 recipientBefore = IERC20(USDC).balanceOf(recipient);

        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.freeReserves(USDC, recipient, amountToFree);

        assertEq(IERC20(USDC).balanceOf(recipient) - recipientBefore, amountToFree, "USDC balance of recipient should be amountToFree");
    }

    function testFork_RevertIf_NoAdapterConfigured_OnHypothecate() external {
        uint256 seedAmount = 1_000_000e6;
        deal(USDC, address(reserve), seedAmount);

        // Unset adapter for USDC
        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.setCollateralAdapter(USDC, address(0)); // schedule
        vm.warp(vm.getBlockTimestamp() + RESERVE_SET_ADAPTER_DELAY);
        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.setCollateralAdapter(USDC, address(0)); // execute

        vm.prank(RESERVE_MANAGER_ADDRESS);
        vm.expectRevert(RoycoReserve.NoAdapterConfigured.selector);
        reserve.hypothecateReserves(USDC, 100_000e6);

        vm.prank(RESERVE_MANAGER_ADDRESS);
        vm.expectRevert(RoycoReserve.NoAdapterConfigured.selector);
        reserve.withdrawAssetsToReserve(USDC, 100_000e6);
    }

    function testFork_RevertIf_InvalidCollateral_OnHypothecateAndWithdraw() external {
        // Hypothecate and withdraw should revert on ROY_USD
        vm.prank(RESERVE_MANAGER_ADDRESS);
        vm.expectRevert(RoycoReserve.InvalidCollateralAsset.selector);
        reserve.hypothecateReserves(address(royUSD), 1e18);

        vm.prank(RESERVE_MANAGER_ADDRESS);
        vm.expectRevert(RoycoReserve.InvalidCollateralAsset.selector);
        reserve.withdrawAssetsToReserve(address(royUSD), 1e18);
    }

    function testFork_Roles_Guards() external {
        uint256 seedAmount = 500_000e6;
        deal(USDC, address(reserve), seedAmount);

        vm.prank(ALICE_ADDRESS);
        vm.expectRevert();
        reserve.hypothecateReserves(USDC, 10_000e6);

        vm.prank(ALICE_ADDRESS);
        vm.expectRevert();
        reserve.withdrawAssetsToReserve(USDC, 10_000e6);
    }

    function testFuzz_AllowanceSafety_MultipleHypothecate(uint256 _seedAmount, uint256 _dep1Bps, uint256 _dep2Bps) external {
        _seedAmount = bound(_seedAmount, 1_000_000e6, 10_000_000e6);
        _dep1Bps = bound(_dep1Bps, 1, 9000); // up to 90%
        _dep2Bps = bound(_dep2Bps, 1, 9000);

        deal(USDC, address(reserve), _seedAmount);

        // First deposit
        uint256 toDeposit1 = (_seedAmount * _dep1Bps) / 10_000;
        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.hypothecateReserves(USDC, toDeposit1);

        // Second deposit based on remaining idle to avoid over-deposit
        uint256 idle = IERC20(USDC).balanceOf(address(reserve));
        uint256 plannedDep2 = (_seedAmount * _dep2Bps) / 10_000;
        uint256 toDeposit2 = plannedDep2 > idle ? idle : plannedDep2;
        if (toDeposit2 > 0) {
            vm.prank(RESERVE_MANAGER_ADDRESS);
            reserve.hypothecateReserves(USDC, toDeposit2);
        }

        // Withdraw all back to ensure cumulative approves/transferFroms are sound
        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.withdrawAssetsToReserve(USDC, type(uint256).max);

        // Allow tiny rounding deltas on forked Aave accounting
        assertGe(IERC20(USDC).balanceOf(address(reserve)), _seedAmount - 3);
    }

    function testFork_DepositZero_Reverts() external {
        uint256 seedAmount = 100_000e6;
        deal(USDC, address(reserve), seedAmount);

        vm.prank(RESERVE_MANAGER_ADDRESS);
        vm.expectRevert();
        reserve.hypothecateReserves(USDC, 0);
    }

    function testFork_WithdrawZero_Reverts() external {
        uint256 seedAmount = 100_000e6;
        deal(USDC, address(reserve), seedAmount);

        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.hypothecateReserves(USDC, 50_000e6);

        vm.prank(RESERVE_MANAGER_ADDRESS);
        vm.expectRevert();
        reserve.withdrawAssetsToReserve(USDC, 0);
    }

    function testFuzz_WithdrawMax_AllBackToReserve(uint256 _seedAmount, uint256 _depositBps) external {
        _seedAmount = bound(_seedAmount, 1_000_000e6, 10_000_000e6);
        _depositBps = bound(_depositBps, 1, 10_000);

        deal(USDC, address(reserve), _seedAmount);

        uint256 toDeposit = (_seedAmount * _depositBps) / 10_000;
        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.hypothecateReserves(USDC, toDeposit);

        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.withdrawAssetsToReserve(USDC, type(uint256).max);

        // All adapter-held USDC should be returned to reserve (allow small rounding)
        assertGe(IERC20(USDC).balanceOf(address(reserve)), _seedAmount - 3);
    }

    function testFuzz_AccrueInterest_ThenWithdrawAll(uint256 _seedAmount, uint256 _depositBps, uint256 _days) external {
        _seedAmount = bound(_seedAmount, 1_000_000e6, 10_000_000e6);
        _depositBps = bound(_depositBps, 1, 10_000);
        _days = bound(_days, 1, 14);

        deal(USDC, address(reserve), _seedAmount);

        uint256 toDeposit = (_seedAmount * _depositBps) / 10_000;
        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.hypothecateReserves(USDC, toDeposit);

        // Simulate time passing for interest accrual
        skip(_days * 1 days);

        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.withdrawAssetsToReserve(USDC, type(uint256).max);

        // Expect roughly seed amount back (principal + accrued), allow tiny rounding
        assertGe(IERC20(USDC).balanceOf(address(reserve)), _seedAmount - 3);
    }

    function testFuzz_GetReserveTotalBalance_EqualsIdlePlusAToken_And_FreeAll(uint256 _initialSeed, uint256 _depositBps, uint256 _recipientIndex) external {
        // Bounds
        _initialSeed = bound(_initialSeed, 1_000_000e6, 10_000_000e6);
        _depositBps = bound(_depositBps, 1, 10_000); // 0.01% - 100%

        address recipient = _getRandomRecipient(_recipientIndex);

        // Start with some USDC in reserve
        deal(USDC, address(reserve), _initialSeed);

        // Optionally deposit a portion into Aave via adapter to create a split between idle and aToken balances
        uint256 reserveIdle = IERC20(USDC).balanceOf(address(reserve));
        uint256 toDeposit = (reserveIdle * _depositBps) / 10_000;
        if (toDeposit > 0) {
            vm.prank(RESERVE_MANAGER_ADDRESS);
            reserve.hypothecateReserves(USDC, toDeposit);
        }

        // Compute expected total: idle in reserve + aToken held by adapter
        uint256 idle = IERC20(USDC).balanceOf(address(reserve));
        uint256 aTokenBal = IERC20(aEthUSDC).balanceOf(address(adapter));
        uint256 expectedTotal = idle + aTokenBal;

        // Query reported total from reserve
        uint256 reportedTotal = reserve.getReserveTotalBalance(USDC);

        // Allow tiny rounding on forked accounting
        assertApproxEqRel(reportedTotal, expectedTotal, 0.001e18, "getReserveTotalBalance should equal idle + aToken");

        // Free exactly the reported total and validate transfer amount
        uint256 recipientBefore = IERC20(USDC).balanceOf(recipient);
        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.freeReserves(USDC, recipient, reportedTotal);

        assertEq(IERC20(USDC).balanceOf(recipient) - recipientBefore, reportedTotal, "freeReserves should transfer exactly the reported total");

        // After freeing all, both idle and adapter aToken should be (near) zero
        assertEq(IERC20(USDC).balanceOf(address(reserve)), 0, "idle balance should be 0 after freeing all");
        assertEq(IERC20(aEthUSDC).balanceOf(address(adapter)), 0, "aToken balance should be 0 after freeing all");
    }

    function test_RevertIf_SetCollateralAdapter_CalledBeforeDelay() external {
        address newAdapter = makeAddr("newAdapter");

        // Schedule the operation
        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.setCollateralAdapter(address(mockUSDC), newAdapter);

        // Try to execute immediately (should revert)
        vm.prank(RESERVE_MANAGER_ADDRESS);
        vm.expectRevert();
        reserve.setCollateralAdapter(address(mockUSDC), newAdapter);
    }

    function _seedReserveWithAllAssets(uint256 _seedMultiplier) internal {
        uint256 baseSeed = bound(_seedMultiplier, 1_000_000, SEED_BALANCE);

        // Seed with collateral assets
        for (uint256 i = 0; i < collateralAssets.length; i++) {
            uint8 decimals = MockERC20(collateralAssets[i]).decimals();
            uint256 amount = baseSeed * (10 ** decimals) / (10 ** 18);
            // Ensure minimum amount for tokens with lower decimals
            if (amount < 1000) amount = 1000;
            MockERC20(collateralAssets[i]).mint(address(reserve), amount);
        }

        // Seed with RoyUSD
        vm.prank(address(teller));
        royUSD.mint(address(reserve), baseSeed);
    }
}
