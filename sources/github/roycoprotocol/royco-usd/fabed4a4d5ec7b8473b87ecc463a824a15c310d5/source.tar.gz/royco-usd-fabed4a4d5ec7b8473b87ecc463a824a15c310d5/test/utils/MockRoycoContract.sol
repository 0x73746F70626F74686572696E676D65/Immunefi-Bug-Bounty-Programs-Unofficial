// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { RoycoAuth } from "../../src/auth/RoycoAuth.sol";

contract MockRoycoContract is RoycoAuth {
    constructor(address _owner) RoycoAuth(_owner) { }
}
