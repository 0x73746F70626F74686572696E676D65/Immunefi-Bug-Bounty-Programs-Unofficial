// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { StdInvariant } from "../../lib/forge-std/src/StdInvariant.sol";
import { Test } from "../../lib/forge-std/src/Test.sol";
import { ERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/ERC20.sol";
import { RoyUSD, RoycoTeller, RoycoTestBase } from "../utils/RoycoTestBase.sol";

contract TellerInvariantHandler is RoycoTestBase {
    uint256 public totalMinted;
    uint256 public totalRedeemed;

    function setUp() external {
        _setUpRoyco();
        totalMinted = SEED_AMOUNT;
    }

    function mint(uint256 _amountToMint, uint256 _collateralIndex) external {
        address[] memory collateralAssetsList = teller.getCollateralAssets();
        if (collateralAssetsList.length == 0) return;

        address collateralAsset = collateralAssetsList[_collateralIndex % collateralAssetsList.length];
        uint256 maxMintable = _getMaxMintable(collateralAsset);

        if (maxMintable == 0) return;

        _amountToMint = bound(_amountToMint, 1, maxMintable);
        address recipient = _getRandomRecipient(_collateralIndex);

        vm.prank(MINTER_ADDRESS);
        teller.mint(_amountToMint, collateralAsset, recipient);

        totalMinted += _amountToMint;
    }

    function redeemSingle(uint256 _amountToRedeem, uint256 _collateralIndex) external {
        uint256 royUsdBalance = ERC20(royUSD).balanceOf(REDEEMER_ADDRESS);
        if (royUsdBalance == 0) return;

        _amountToRedeem = bound(_amountToRedeem, 1, royUsdBalance);
        address[] memory collateralAssetsList = teller.getCollateralAssets();
        if (collateralAssetsList.length == 0) return;

        address collateralAsset = collateralAssetsList[_collateralIndex % collateralAssetsList.length];
        address recipient = _getRandomRecipient(_collateralIndex);

        uint256 availableReserves = ERC20(collateralAsset).balanceOf(address(reserve));
        uint256 quotedOutput = teller.quoteRedemptionOutput(_amountToRedeem, collateralAsset);

        if (availableReserves < quotedOutput) return;

        vm.prank(REDEEMER_ADDRESS);
        teller.redeem(_amountToRedeem, collateralAsset, recipient);

        totalRedeemed += _amountToRedeem;
    }

    function redeemMultiple(uint256 _amountToRedeem, uint256 _recipientIndex) external {
        uint256 royUsdBalance = ERC20(royUSD).balanceOf(REDEEMER_ADDRESS);
        if (royUsdBalance == 0) return;

        _amountToRedeem = bound(_amountToRedeem, 1, royUsdBalance);
        address recipient = _getRandomRecipient(_recipientIndex);

        address[] memory collateralAssetsList = teller.getCollateralAssets();
        uint256 totalReserveValue = 0;
        uint256 oneRoyUSD = 10 ** ERC20(address(royUSD)).decimals();

        for (uint256 i = 0; i < collateralAssetsList.length; i++) {
            uint256 balance = ERC20(collateralAssetsList[i]).balanceOf(address(reserve));
            uint256 pricePerRoyUSD = teller.collateralAssetToPrice(collateralAssetsList[i]);
            totalReserveValue += (balance * oneRoyUSD) / pricePerRoyUSD;
        }

        if (totalReserveValue < _amountToRedeem) return;

        vm.prank(REDEEMER_ADDRESS);
        teller.redeem(_amountToRedeem, recipient);

        totalRedeemed += _amountToRedeem;
    }
}

contract TellerInvariantTest is StdInvariant, Test {
    TellerInvariantHandler public handler;

    function setUp() external {
        handler = new TellerInvariantHandler();
        handler.setUp();

        bytes4[] memory selectors = new bytes4[](3);
        selectors[0] = TellerInvariantHandler.mint.selector;
        selectors[1] = TellerInvariantHandler.redeemSingle.selector;
        selectors[2] = TellerInvariantHandler.redeemMultiple.selector;

        targetSelector(FuzzSelector({ addr: address(handler), selectors: selectors }));

        targetContract(address(handler));
    }

    function invariant_ReserveValueGeRoyUSDSupply() external view {
        uint256 totalSupply = ERC20(address(handler.royUSD())).totalSupply();
        uint256 totalReserveValue = 0;

        address[] memory collateralAssetsList = handler.teller().getCollateralAssets();
        uint256 oneRoyUSD = 10 ** ERC20(address(handler.royUSD())).decimals();

        for (uint256 i = 0; i < collateralAssetsList.length; i++) {
            address collateralAsset = collateralAssetsList[i];
            uint256 reserveBalance = ERC20(collateralAsset).balanceOf(address(handler.reserve()));
            uint256 pricePerRoyUSD = handler.teller().collateralAssetToPrice(collateralAsset);

            uint256 valueInRoyUSD = (reserveBalance * oneRoyUSD) / pricePerRoyUSD;
            totalReserveValue += valueInRoyUSD;
        }

        assertGe(totalReserveValue, totalSupply, "Reserve value should be >= Total supply of RoyUSD");
    }

    function invariant_SupplyConsistency() external view {
        uint256 netMinted = handler.totalMinted() - handler.totalRedeemed();
        uint256 actualSupply = ERC20(address(handler.royUSD())).totalSupply();

        assertEq(netMinted, actualSupply, "Actual supply should be == net minted amount");
    }
}
