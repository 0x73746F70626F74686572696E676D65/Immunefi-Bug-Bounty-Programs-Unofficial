// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { Test } from "../../lib/forge-std/src/Test.sol";
import { Vm } from "../../lib/forge-std/src/Vm.sol";
import { RoyUSD } from "../../src/RoyUSD.sol";
import { RoycoRoles } from "../../src/auth/RoycoRoles.sol";
import { RoycoFlashLender } from "../../src/open-market-operations/RoycoFlashLender.sol";
import { RoycoLiquidityFacility } from "../../src/open-market-operations/RoycoLiquidityFacility.sol";
import { RoycoReserve } from "../../src/reserve/RoycoReserve.sol";
import { StakedRoyUSD } from "../../src/savings/StakedRoyUSD.sol";
import { RoycoTeller } from "../../src/teller/RoycoTeller.sol";
import { ERC20, MockERC20 } from "./MockERC20.sol";

contract RoycoTestBase is Test {
    // -----------------------------------------
    // Timelock / Delay Constants (seconds)
    // -----------------------------------------
    uint256 internal constant RESERVE_SET_ADAPTER_DELAY = 1 hours;
    uint256 internal constant TELLER_COLLATERAL_UPDATE_DELAY = 1 hours;
    uint256 internal constant LENDER_UPDATE_CONFIG_DELAY = 1 hours;
    uint256 internal constant LENDER_SET_TREASURY_DELAY = 1 hours;
    uint256 internal constant SROYUSD_SET_WHITELIST_DELAY = 1 hours;
    uint256 internal constant SROYUSD_SET_UNSTAKING_DURATION_DELAY = 1 hours;
    // -----------------------------------------
    // Test Wallets
    // -----------------------------------------
    Vm.Wallet internal OWNER;
    address internal OWNER_ADDRESS;

    Vm.Wallet internal MINTER;
    address internal MINTER_ADDRESS;

    Vm.Wallet internal REDEEMER;
    address internal REDEEMER_ADDRESS;

    Vm.Wallet internal COLLATERAL_MANAGER;
    address internal COLLATERAL_MANAGER_ADDRESS;

    Vm.Wallet internal RESERVE_MANAGER;
    address internal RESERVE_MANAGER_ADDRESS;

    Vm.Wallet internal ALLOCATOR;
    address internal ALLOCATOR_ADDRESS;

    Vm.Wallet internal OPEN_MARKET_DESK;
    address internal OPEN_MARKET_DESK_ADDRESS;

    Vm.Wallet internal TREASURY;
    address internal TREASURY_ADDRESS;

    Vm.Wallet internal YIELD_DISTRIBUTOR;
    address internal YIELD_DISTRIBUTOR_ADDRESS;

    Vm.Wallet internal STAKING_MANAGER;
    address internal STAKING_MANAGER_ADDRESS;

    Vm.Wallet internal BLACKLIST_MANAGER;
    address internal BLACKLIST_MANAGER_ADDRESS;

    Vm.Wallet internal SCHEDULER_MANAGER;
    address internal SCHEDULER_MANAGER_ADDRESS;

    Vm.Wallet internal ALICE;
    Vm.Wallet internal BOB;
    Vm.Wallet internal CHARLIE;
    Vm.Wallet internal DAN;

    address internal ALICE_ADDRESS;
    address internal BOB_ADDRESS;
    address internal CHARLIE_ADDRESS;
    address internal DAN_ADDRESS;

    address[] internal recipients;

    // -----------------------------------------
    // Collateral Assets
    // -----------------------------------------

    MockERC20 internal mockUSDC;
    MockERC20 internal mockUSDT;
    MockERC20 internal mockUSDS;
    address[] internal collateralAssets;

    // -----------------------------------------
    // Royco Deployments
    // -----------------------------------------

    uint256 internal SEED_AMOUNT;

    RoyUSD public royUSD;
    StakedRoyUSD public sRoyUSD;
    RoycoReserve public reserve;
    RoycoTeller public teller;
    RoycoFlashLender public flashLender;
    RoycoLiquidityFacility public liquidityFacility;

    modifier prankModifier(address _pranker) {
        vm.startPrank(_pranker);
        _;
        vm.stopPrank();
    }

    function _setUpRoyco() internal virtual {
        _setupWallets();
        _setupCollateralAssets(10_000_000_000);

        royUSD = new RoyUSD(OWNER_ADDRESS, type(uint256).max);
        reserve = new RoycoReserve(OWNER_ADDRESS, address(royUSD), RESERVE_SET_ADAPTER_DELAY);
        teller = new RoycoTeller(OWNER_ADDRESS, address(royUSD), address(reserve), collateralAssets, TELLER_COLLATERAL_UPDATE_DELAY);

        uint256 numCollateralAssets = collateralAssets.length;
        address[] memory lendableAssets = new address[](numCollateralAssets + 1);
        uint240[] memory lendableAssetsLoanCaps = new uint240[](numCollateralAssets + 1);
        uint16[] memory lendableAssetsFees = new uint16[](numCollateralAssets + 1);
        for (uint256 i = 0; i < numCollateralAssets; ++i) {
            lendableAssets[i] = collateralAssets[i];
            lendableAssetsLoanCaps[i] = type(uint240).max;
        }
        lendableAssets[numCollateralAssets] = address(royUSD);
        lendableAssetsLoanCaps[numCollateralAssets] = type(uint240).max;

        flashLender = new RoycoFlashLender(
            OWNER_ADDRESS,
            address(royUSD),
            address(reserve),
            TREASURY_ADDRESS,
            lendableAssets,
            lendableAssetsLoanCaps,
            lendableAssetsFees,
            LENDER_UPDATE_CONFIG_DELAY,
            LENDER_SET_TREASURY_DELAY
        );

        liquidityFacility = new RoycoLiquidityFacility(OWNER_ADDRESS, address(royUSD), LENDER_UPDATE_CONFIG_DELAY);

        _setUpRoyUSDRoles(address(teller), address(flashLender), address(liquidityFacility), SCHEDULER_MANAGER_ADDRESS);
        _setUpTellerRoles(MINTER_ADDRESS, REDEEMER_ADDRESS, COLLATERAL_MANAGER_ADDRESS, SCHEDULER_MANAGER_ADDRESS);
        _setUpFlashLenderRoles(OPEN_MARKET_DESK_ADDRESS, SCHEDULER_MANAGER_ADDRESS);
        _setUpLiquidityFacilityRoles(OPEN_MARKET_DESK_ADDRESS, SCHEDULER_MANAGER_ADDRESS);

        // Seed with 10,000 RoyUSD for initial staking deposit
        SEED_AMOUNT = 10_000 * (10 ** royUSD.decimals());
        vm.startPrank(MINTER_ADDRESS);
        mockUSDC.approve(address(teller), type(uint256).max);
        mockUSDT.approve(address(teller), type(uint256).max);
        mockUSDS.approve(address(teller), type(uint256).max);
        teller.mint(SEED_AMOUNT, address(mockUSDC), OWNER_ADDRESS);
        vm.stopPrank();

        vm.prank(REDEEMER_ADDRESS);
        royUSD.approve(address(teller), type(uint256).max);

        // Compute sRoyUSD address using CREATE2 to approve the seed amount
        bytes32 salt = keccak256("sRoyUSD");
        bytes memory creationCode = abi.encodePacked(
            type(StakedRoyUSD).creationCode,
            abi.encode(
                OWNER_ADDRESS,
                address(royUSD),
                address(reserve),
                2 weeks,
                OWNER_ADDRESS,
                SEED_AMOUNT,
                OWNER_ADDRESS,
                SROYUSD_SET_WHITELIST_DELAY,
                SROYUSD_SET_UNSTAKING_DURATION_DELAY
            )
        );
        address predictedSRoyUSD = vm.computeCreate2Address(salt, keccak256(creationCode), OWNER_ADDRESS);

        vm.startPrank(OWNER_ADDRESS);
        royUSD.approve(predictedSRoyUSD, SEED_AMOUNT);
        sRoyUSD = new StakedRoyUSD{ salt: salt }(
            OWNER_ADDRESS,
            address(royUSD),
            address(reserve),
            2 weeks,
            OWNER_ADDRESS,
            SEED_AMOUNT,
            OWNER_ADDRESS,
            SROYUSD_SET_WHITELIST_DELAY,
            SROYUSD_SET_UNSTAKING_DURATION_DELAY
        );
        vm.stopPrank();
        _setUpSRoyUSDRoles(YIELD_DISTRIBUTOR_ADDRESS, STAKING_MANAGER_ADDRESS, BLACKLIST_MANAGER_ADDRESS, SCHEDULER_MANAGER_ADDRESS);
        _setUpReserveRoles(address(teller), address(flashLender), RESERVE_MANAGER_ADDRESS, ALLOCATOR_ADDRESS, address(sRoyUSD), SCHEDULER_MANAGER_ADDRESS);
    }

    function _setupCollateralAssets(uint256 _SEED_AMOUNT) internal {
        mockUSDC = new MockERC20("USD Coin", "USDC", 6);
        mockUSDC.mint(MINTER_ADDRESS, _SEED_AMOUNT * (10 ** 6));
        collateralAssets.push(address(mockUSDC));

        mockUSDT = new MockERC20("Tether USD", "USDT", 6);
        mockUSDT.mint(MINTER_ADDRESS, _SEED_AMOUNT * (10 ** 6));
        collateralAssets.push(address(mockUSDT));

        mockUSDS = new MockERC20("USDS Stablecoin", "USDS", 18);
        mockUSDS.mint(MINTER_ADDRESS, _SEED_AMOUNT * (10 ** 18));
        collateralAssets.push(address(mockUSDS));
    }

    function _setupWallets() internal {
        // Init wallets with 1000 ETH each
        OWNER = _initWallet("OWNER", 1000 ether);
        MINTER = _initWallet("MINTER", 1000 ether);
        REDEEMER = _initWallet("REDEEMER", 1000 ether);
        COLLATERAL_MANAGER = _initWallet("COLLATERAL_MANAGER", 1000 ether);
        RESERVE_MANAGER = _initWallet("RESERVE_MANAGER", 1000 ether);
        ALLOCATOR = _initWallet("ALLOCATOR", 1000 ether);
        OPEN_MARKET_DESK = _initWallet("OPEN_MARKET_DESK", 1000 ether);
        TREASURY = _initWallet("TREASURY", 1000 ether);
        YIELD_DISTRIBUTOR = _initWallet("YIELD_DISTRIBUTOR", 1000 ether);
        STAKING_MANAGER = _initWallet("STAKING_MANAGER", 1000 ether);
        BLACKLIST_MANAGER = _initWallet("BLACKLIST_MANAGER", 1000 ether);
        ALICE = _initWallet("ALICE", 1000 ether);
        BOB = _initWallet("BOB", 1000 ether);
        CHARLIE = _initWallet("CHARLIE", 1000 ether);
        DAN = _initWallet("DAN", 1000 ether);
        SCHEDULER_MANAGER = _initWallet("SCHEDULER_MANAGER", 1000 ether);

        // Set addresses
        OWNER_ADDRESS = OWNER.addr;
        MINTER_ADDRESS = MINTER.addr;
        REDEEMER_ADDRESS = REDEEMER.addr;
        COLLATERAL_MANAGER_ADDRESS = COLLATERAL_MANAGER.addr;
        RESERVE_MANAGER_ADDRESS = RESERVE_MANAGER.addr;
        ALLOCATOR_ADDRESS = ALLOCATOR.addr;
        OPEN_MARKET_DESK_ADDRESS = OPEN_MARKET_DESK.addr;
        TREASURY_ADDRESS = TREASURY.addr;
        YIELD_DISTRIBUTOR_ADDRESS = YIELD_DISTRIBUTOR.addr;
        STAKING_MANAGER_ADDRESS = STAKING_MANAGER.addr;
        BLACKLIST_MANAGER_ADDRESS = BLACKLIST_MANAGER.addr;
        ALICE_ADDRESS = ALICE.addr;
        BOB_ADDRESS = BOB.addr;
        CHARLIE_ADDRESS = CHARLIE.addr;
        DAN_ADDRESS = DAN.addr;
        SCHEDULER_MANAGER_ADDRESS = SCHEDULER_MANAGER.addr;

        recipients.push(ALICE_ADDRESS);
        recipients.push(BOB_ADDRESS);
        recipients.push(CHARLIE_ADDRESS);
        recipients.push(DAN_ADDRESS);
    }

    function _initWallet(string memory name, uint256 amount) internal returns (Vm.Wallet memory) {
        Vm.Wallet memory wallet = vm.createWallet(name);
        vm.label(wallet.addr, name);
        vm.deal(wallet.addr, amount);
        return wallet;
    }

    function _setUpRoyUSDRoles(
        address _teller,
        address _flashLender,
        address _liquidityFacility,
        address _schedulerManager
    )
        internal
        prankModifier(OWNER_ADDRESS)
    {
        royUSD.grantRoles(_teller, RoycoRoles.TELLER);
        royUSD.grantRoles(_flashLender, RoycoRoles.LENDER);
        royUSD.grantRoles(_liquidityFacility, RoycoRoles.LENDER);
        royUSD.grantRoles(_schedulerManager, RoycoRoles.SCHEDULER_MANAGER);
    }

    function _setUpSRoyUSDRoles(
        address _yieldDistributor,
        address _stakingManager,
        address _blacklistManager,
        address _schedulerManager
    )
        internal
        prankModifier(OWNER_ADDRESS)
    {
        sRoyUSD.grantRoles(_yieldDistributor, RoycoRoles.YIELD_DISTRIBUTOR);
        sRoyUSD.grantRoles(_stakingManager, RoycoRoles.STAKING_MANAGER);
        sRoyUSD.grantRoles(_blacklistManager, RoycoRoles.BLACKLIST_MANAGER);
        sRoyUSD.grantRoles(_schedulerManager, RoycoRoles.SCHEDULER_MANAGER);
    }

    function _setUpReserveRoles(
        address _teller,
        address _flashLender,
        address _reserveManager,
        address _allocator,
        address _staker,
        address _schedulerManager
    )
        internal
        prankModifier(OWNER_ADDRESS)
    {
        reserve.grantRoles(_teller, RoycoRoles.TELLER);
        reserve.grantRoles(_flashLender, RoycoRoles.LENDER);
        reserve.grantRoles(_reserveManager, RoycoRoles.RESERVE_MANAGER);
        reserve.grantRoles(_allocator, RoycoRoles.RESERVE_ALLOCATOR);
        reserve.grantRoles(_staker, RoycoRoles.STAKING);
        reserve.grantRoles(_schedulerManager, RoycoRoles.SCHEDULER_MANAGER);
    }

    function _setUpTellerRoles(
        address _minter,
        address _redeemer,
        address _collateralManager,
        address _schedulerManager
    )
        internal
        prankModifier(OWNER_ADDRESS)
    {
        teller.grantRoles(_minter, RoycoRoles.MINTER);
        teller.grantRoles(_redeemer, RoycoRoles.REDEEMER);
        teller.grantRoles(_collateralManager, RoycoRoles.COLLATERAL_MANAGER);
        teller.grantRoles(_schedulerManager, RoycoRoles.SCHEDULER_MANAGER);
    }

    function _setUpFlashLenderRoles(address _openMarketDesk, address _schedulerManager) internal prankModifier(OWNER_ADDRESS) {
        flashLender.grantRoles(_openMarketDesk, RoycoRoles.OPEN_MARKET_DESK);
        flashLender.grantRoles(_schedulerManager, RoycoRoles.SCHEDULER_MANAGER);
    }

    function _setUpLiquidityFacilityRoles(address _openMarketDesk, address _schedulerManager) internal prankModifier(OWNER_ADDRESS) {
        liquidityFacility.grantRoles(_openMarketDesk, RoycoRoles.OPEN_MARKET_DESK);
        liquidityFacility.grantRoles(_schedulerManager, RoycoRoles.SCHEDULER_MANAGER);
    }

    function _getRandomRecipient(uint256 _seed) internal view returns (address) {
        return recipients[_seed % recipients.length];
    }

    function _getMaxMintable(address _collateralAsset) internal view returns (uint256) {
        return ERC20(_collateralAsset).balanceOf(MINTER_ADDRESS) * (10 ** (ERC20(royUSD).decimals() - ERC20(_collateralAsset).decimals()));
    }
}
