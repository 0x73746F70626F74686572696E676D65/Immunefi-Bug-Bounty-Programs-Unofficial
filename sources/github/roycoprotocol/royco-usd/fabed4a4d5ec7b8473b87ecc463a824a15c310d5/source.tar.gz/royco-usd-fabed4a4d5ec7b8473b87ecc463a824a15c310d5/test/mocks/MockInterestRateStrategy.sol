// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

/**
 * @title MockInterestRateStrategy
 * @notice Mock implementation of Aave V3 interest rate strategy for testing
 * @dev This contract implements the exact interface expected by AaveV3LiquidityFacilityAdapter
 */
contract MockInterestRateStrategy {
    // Interest rate strategy parameters (in RAY - 27 decimals)
    uint256 public constant OPTIMAL_USAGE_RATIO = 800000000000000000000000000; // 80%
    uint256 public constant MAX_EXCESS_USAGE_RATIO = 200000000000000000000000000; // 20%
    uint256 public constant OPTIMAL_STABLE_TO_TOTAL_DEBT_RATIO = 200000000000000000000000000; // 20%
    uint256 public constant MAX_EXCESS_STABLE_TO_TOTAL_DEBT_RATIO = 800000000000000000000000000; // 80%
    
    // Rate parameters
    uint256 private immutable BASE_VARIABLE_BORROW_RATE;
    uint256 private immutable VARIABLE_RATE_SLOPE_1;
    uint256 private immutable VARIABLE_RATE_SLOPE_2;
    uint256 private immutable STABLE_RATE_SLOPE_1;
    uint256 private immutable STABLE_RATE_SLOPE_2;
    uint256 private immutable BASE_STABLE_BORROW_RATE;
    uint256 private immutable STABLE_RATE_EXCESS_OFFSET;
    uint256 private immutable MAX_VARIABLE_BORROW_RATE;

    constructor(
        uint256 _baseVariableBorrowRate,
        uint256 _variableRateSlope1,
        uint256 _variableRateSlope2,
        uint256 _stableRateSlope1,
        uint256 _stableRateSlope2,
        uint256 _baseStableBorrowRate,
        uint256 _stableRateExcessOffset,
        uint256 _maxVariableBorrowRate
    ) {
        BASE_VARIABLE_BORROW_RATE = _baseVariableBorrowRate;
        VARIABLE_RATE_SLOPE_1 = _variableRateSlope1;
        VARIABLE_RATE_SLOPE_2 = _variableRateSlope2;
        STABLE_RATE_SLOPE_1 = _stableRateSlope1;
        STABLE_RATE_SLOPE_2 = _stableRateSlope2;
        BASE_STABLE_BORROW_RATE = _baseStableBorrowRate;
        STABLE_RATE_EXCESS_OFFSET = _stableRateExcessOffset;
        MAX_VARIABLE_BORROW_RATE = _maxVariableBorrowRate;
    }

    function getVariableRateSlope1() external view returns (uint256) {
        return VARIABLE_RATE_SLOPE_1;
    }

    function getVariableRateSlope2() external view returns (uint256) {
        return VARIABLE_RATE_SLOPE_2;
    }

    function getStableRateSlope1() external view returns (uint256) {
        return STABLE_RATE_SLOPE_1;
    }

    function getStableRateSlope2() external view returns (uint256) {
        return STABLE_RATE_SLOPE_2;
    }

    function getStableRateExcessOffset() external view returns (uint256) {
        return STABLE_RATE_EXCESS_OFFSET;
    }

    function getBaseStableBorrowRate() external view returns (uint256) {
        return BASE_STABLE_BORROW_RATE;
    }

    function getBaseVariableBorrowRate() external view returns (uint256) {
        return BASE_VARIABLE_BORROW_RATE;
    }

    function getMaxVariableBorrowRate() external view returns (uint256) {
        return MAX_VARIABLE_BORROW_RATE;
    }
}