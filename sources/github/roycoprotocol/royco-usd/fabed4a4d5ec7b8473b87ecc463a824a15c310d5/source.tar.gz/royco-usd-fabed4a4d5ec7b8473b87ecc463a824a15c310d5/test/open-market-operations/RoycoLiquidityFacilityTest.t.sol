// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { InitializableImmutableAdminUpgradeabilityProxy } from
    "../../lib/aave-v3-core/contracts/protocol/libraries/aave-upgradeability/InitializableImmutableAdminUpgradeabilityProxy.sol";
import { console } from "../../lib/forge-std/src/console.sol";
import { IERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol";

import { IACLManager } from "../../lib/aave-v3-core/contracts/interfaces/IACLManager.sol";
import { IAaveOracle } from "../../lib/aave-v3-core/contracts/interfaces/IAaveOracle.sol";
import { IPool } from "../../lib/aave-v3-core/contracts/interfaces/IPool.sol";
import { IPoolAddressesProvider } from "../../lib/aave-v3-core/contracts/interfaces/IPoolAddressesProvider.sol";
import { IPoolConfigurator } from "../../lib/aave-v3-core/contracts/interfaces/IPoolConfigurator.sol";

import { ConfiguratorInputTypes } from "../../lib/aave-v3-core/contracts/protocol/libraries/types/ConfiguratorInputTypes.sol";
import { DataTypes } from "../../lib/aave-v3-core/contracts/protocol/libraries/types/DataTypes.sol";

// Helpers (read-only ProtocolDataProvider on mainnet)

import { IPoolDataProvider } from "../../lib/aave-v3-core/contracts/interfaces/IPoolDataProvider.sol";

// Your system
import { AaveV3LiquidityFacilityAdapter } from "../../src/market-adapters/aave/AaveV3LiquidityFacilityAdapter.sol";
import { RoycoLiquidityFacility, RoycoRoles } from "../../src/open-market-operations/RoycoLiquidityFacility.sol";
import { RoycoForkMainnetBase } from "../utils/RoycoForkMainnetBase.sol";

// Test-only price feed
import { MockV3Aggregator } from "../mocks/MockV3Aggregator.sol";

contract RoycoLiquidityFacilityTest is RoycoForkMainnetBase {
    uint256 internal constant FACILITY_SET_ADAPTER_CONFIG_DELAY = 1 hours;

    // Adapter instance
    AaveV3LiquidityFacilityAdapter public facilityAdapter;

    // Facility config
    uint96 internal constant TARGET_BORROW_RATE_RAY = 50_000_000_000_000_000_000_000_000; // 5% RAY
    uint160 internal constant SUPPLY_CAP = 10_000_000; // 10M whole tokens

    // ===== Aave v3 mainnet canonical addresses (Ethereum) =====
    address internal constant AAVE_ADDRESSES_PROVIDER = 0x2f39d218133AFaB8F2B819B1066c7E434Ad94E9e;
    address internal constant AAVE_PROTOCOL_DATA_PROVIDER = 0x7B4EB56E7CD4b454BA8ff71E4518426369a138a3;

    // USDC (to source its IRM)
    address internal constant USDC_IRM = 0x9ec6F08190DeA04A54f8Afc53Db96134e5E3FdFB; // from your trace

    // We’ll read live reserve state from the real Pool
    IPool internal aavePool;
    IPoolAddressesProvider internal addressesProvider;
    IPoolConfigurator internal poolConfigurator;
    IACLManager internal aclManager;
    IAaveOracle internal aaveOracle;
    IPoolDataProvider internal protocolDataProvider;

    // RoyUSD price feed (Chainlink-like)
    MockV3Aggregator internal royUSDPriceFeed;

    // Deployed tokenization (pulled from ProtocolDataProvider after initReserves)
    address internal aRoyUSD;
    address internal variableDebtRoyUSD;
    address internal stableDebtRoyUSD;

    // Locally deployed impls (correct way for forks/tests)
    address internal aTokenImpl;
    address internal stableDebtTokenImpl;
    address internal variableDebtTokenImpl;

    function setUp() external {
        // Deploy RoyUSD + LiquidityFacility + base roles
        _setUpRoyco();
    }

    function _setupRoyUSDInAavePool_UsingUsdcIRM() internal {
        // 0) Resolve Aave core
        addressesProvider = IPoolAddressesProvider(AAVE_ADDRESSES_PROVIDER);
        aavePool = IPool(addressesProvider.getPool());
        poolConfigurator = IPoolConfigurator(addressesProvider.getPoolConfigurator());
        aclManager = IACLManager(addressesProvider.getACLManager());
        aaveOracle = IAaveOracle(addressesProvider.getPriceOracle());
        protocolDataProvider = IPoolDataProvider(AAVE_PROTOCOL_DATA_PROVIDER);

        // 1) Elevate this contract to ASSET_LISTING_ADMIN + POOL_ADMIN (impersonate the ACL admin)
        address aclAdmin = addressesProvider.getACLAdmin();
        vm.deal(aclAdmin, 2 ether);
        vm.startPrank(aclAdmin);
        aclManager.addPoolAdmin(address(this));
        aclManager.addAssetListingAdmin(address(this));
        vm.stopPrank();

        // 2) Set RoyUSD oracle to $1.00 (Aave v3 baseCurrencyUnit = 1e8)
        royUSDPriceFeed = new MockV3Aggregator(8, 1e8);
        address[] memory assets = new address[](1);
        address[] memory sources = new address[](1);
        assets[0] = address(royUSD);
        sources[0] = address(royUSDPriceFeed);
        vm.prank(aclAdmin);
        aaveOracle.setAssetSources(assets, sources);

        ConfiguratorInputTypes.InitReserveInput[] memory inputs = new ConfiguratorInputTypes.InitReserveInput[](1);
        inputs[0] = ConfiguratorInputTypes.InitReserveInput({
            aTokenImpl: 0xB76cf0f1d2e1a606c14044607c8c44878AAE7186,
            stableDebtTokenImpl: 0x15C5620dfFaC7c7366EED66C20Ad222DDbB1eD57,
            variableDebtTokenImpl: 0x2b31CaA35900f4c8fe6151cCAF8d0Ea4A89743A1,
            underlyingAssetDecimals: royUSD.decimals(),
            interestRateStrategyAddress: USDC_IRM,
            underlyingAsset: address(royUSD),
            treasury: 0x464C71f6c2F760DdA6093dCB91C24c39e5d6e18c,
            incentivesController: address(0),
            aTokenName: "Aave Ethereum RoyUSD",
            aTokenSymbol: "aROYUSD",
            variableDebtTokenName: "Aave Ethereum Variable Debt RoyUSD",
            variableDebtTokenSymbol: "variableDebtROYUSD",
            stableDebtTokenName: "Aave Ethereum Stable Debt RoyUSD",
            stableDebtTokenSymbol: "stableDebtROYUSD",
            params: ""
        });

        vm.prank(address(this));
        poolConfigurator.initReserves(inputs);

        vm.startPrank(address(this));
        // Risk params for RoyUSD
        poolConfigurator.setReserveBorrowing(address(royUSD), true);
        poolConfigurator.setReserveStableRateBorrowing(address(royUSD), false);
        poolConfigurator.configureReserveAsCollateral(address(royUSD), 9500, 9700, 200); // 95% LTV, 97% LT, 2% LB
        poolConfigurator.setReserveFactor(address(royUSD), 1000); // 10%
        poolConfigurator.setSupplyCap(address(royUSD), 100_000_000); // 100m (WHOLE tokens)
        poolConfigurator.setBorrowCap(address(royUSD), 80_000_000); // 80m (WHOLE tokens)
        poolConfigurator.setLiquidationProtocolFee(address(royUSD), 100); // 1%
        vm.stopPrank();

        // 6) Pull the actual tokenization addresses
        (aRoyUSD, stableDebtRoyUSD, variableDebtRoyUSD) = protocolDataProvider.getReserveTokensAddresses(address(royUSD));
        require(aRoyUSD != address(0) && variableDebtRoyUSD != address(0), "reserve not initialized");

        // 7) Plug in your adapter to the real pool
        facilityAdapter = new AaveV3LiquidityFacilityAdapter(
            OWNER_ADDRESS,
            address(liquidityFacility),
            AAVE_V3_POOL, // from your base, should equal addressesProvider.getPool()
            address(royUSD)
        );
    }

    function _configureFacilityAdapter() internal {
        // Stage config
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        liquidityFacility.setAdapterConfig(address(facilityAdapter), TARGET_BORROW_RATE_RAY, SUPPLY_CAP);

        // Wait and finalize config
        vm.warp(vm.getBlockTimestamp() + FACILITY_SET_ADAPTER_CONFIG_DELAY);
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        liquidityFacility.setAdapterConfig(address(facilityAdapter), TARGET_BORROW_RATE_RAY, SUPPLY_CAP);
    }

    // // ===== Minimal assertion test =====
    // function test_RoyUSDReserveDeployedCorrectly_UsesUsdcIRM() external {
    //     _setupRoyUSDInAavePool_UsingUsdcIRM();
    //     _configureFacilityAdapter();
    //     // Oracle
    //     uint256 price = aaveOracle.getAssetPrice(address(royUSD));
    //     assertEq(price, 1e8, "RoyUSD should be $1.00");

    //     // IRM must match USDC’s
    //     DataTypes.ReserveData memory rd = aavePool.getReserveData(address(royUSD));
    //     assertEq(rd.interestRateStrategyAddress, USDC_IRM, "IRM != USDC IRM");

    //     // Tokenization deployed
    //     assertTrue(rd.aTokenAddress != address(0), "aToken not deployed");
    //     assertTrue(rd.variableDebtTokenAddress != address(0), "variable debt not deployed");
    //     assertTrue(rd.stableDebtTokenAddress != address(0), "stable debt not deployed");

    //     // Indices
    //     assertGt(rd.liquidityIndex, 0, "liquidityIndex uninitialized");
    //     assertGt(rd.variableBorrowIndex, 0, "variableBorrowIndex uninitialized");

    //     // Tokenization matches provider
    //     assertEq(rd.aTokenAddress, aRoyUSD, "aToken mismatch");
    //     assertEq(rd.variableDebtTokenAddress, variableDebtRoyUSD, "variable debt mismatch");
    //     assertEq(rd.stableDebtTokenAddress, stableDebtRoyUSD, "stable debt mismatch");

    //     console.log("RoyUSD listed with **USDC IRM** on Aave v3 (mainnet fork).");
    // }
}
