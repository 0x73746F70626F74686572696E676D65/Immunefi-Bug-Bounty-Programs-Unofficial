// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { IERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol";
import { RoyUSD } from "../../src/RoyUSD.sol";

import { RoycoRoles } from "../../src/auth/RoycoRoles.sol";
import { AaveV3MarketAdapter } from "../../src/market-adapters/aave/AaveV3MarketAdapter.sol";
import { RoycoReserve } from "../../src/reserve/RoycoReserve.sol";
import { RoycoTestBase } from "./RoycoTestBase.sol";

contract RoycoForkMainnetBase is RoycoTestBase {
    // Mainnet token and Aave addresses
    address internal constant USDC = 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48;
    address internal constant aEthUSDC = 0x98C23E9d8f34FEFb1B7BD6a91B7FF122F4e16F5c;
    address internal constant AAVE_V3_POOL = 0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2;

    // Adapter used in fork tests
    AaveV3MarketAdapter public adapter;

    uint256 internal forkBlock = 22_000_000;

    function _setUpRoyco() internal override {
        // Fork Ethereum mainnet via env var (required)
        vm.createSelectFork(vm.envString("MAINNET_RPC_URL"));

        // Deploy core
        super._setUpRoyco();

        // Configure Aave adapter for USDC
        address[] memory assets = new address[](1);
        assets[0] = USDC;
        adapter = new AaveV3MarketAdapter(OWNER_ADDRESS, address(reserve), AAVE_V3_POOL, assets);
        // schedule
        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.setCollateralAdapter(USDC, address(adapter));
        // wait delay then execute
        vm.warp(vm.getBlockTimestamp() + RESERVE_SET_ADAPTER_DELAY);
        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.setCollateralAdapter(USDC, address(adapter));
    }
}
