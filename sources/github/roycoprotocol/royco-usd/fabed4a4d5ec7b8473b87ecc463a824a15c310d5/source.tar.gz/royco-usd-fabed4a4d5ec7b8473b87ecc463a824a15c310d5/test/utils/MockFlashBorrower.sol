// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { IERC3156FlashBorrower } from "../../lib/openzeppelin-contracts/contracts/interfaces/IERC3156FlashLender.sol";
import { MockERC20 } from "./MockERC20.sol";

contract MockFlashBorrower is IERC3156FlashBorrower {
    bytes32 internal constant CALLBACK_SUCCESS = keccak256("ERC3156FlashBorrower.onFlashLoan");

    bool public failCallbackOnLoan;

    bool public failPrincipalRepaymentOnLoan;

    bool public failFeeRepaymentOnLoan;

    function setFailCallbackOnLoan(bool _fail) external {
        failCallbackOnLoan = _fail;
    }

    function setFailPrincipalRepaymentOnLoan(bool _fail) external {
        failPrincipalRepaymentOnLoan = _fail;
    }

    function setFailFeeRepaymentOnLoan(bool _fail) external {
        failFeeRepaymentOnLoan = _fail;
    }

    function onFlashLoan(address, address _token, uint256 _amount, uint256 _fee, bytes calldata) external returns (bytes32) {
        if (!failPrincipalRepaymentOnLoan) MockERC20(_token).approve(msg.sender, _amount + _fee);
        if (!failFeeRepaymentOnLoan && _fee > 0) MockERC20(_token).mint(address(this), _fee);

        return failCallbackOnLoan ? bytes32(0) : CALLBACK_SUCCESS;
    }
}
