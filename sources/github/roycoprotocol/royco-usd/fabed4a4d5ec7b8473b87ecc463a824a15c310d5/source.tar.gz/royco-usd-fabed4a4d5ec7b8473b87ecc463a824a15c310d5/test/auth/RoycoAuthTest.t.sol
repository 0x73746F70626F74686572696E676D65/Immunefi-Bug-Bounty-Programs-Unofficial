// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { RoycoReserve } from "../../src/reserve/RoycoReserve.sol";
import { MockRoycoContract, RoycoAuth } from "../utils/MockRoycoContract.sol";
import { RoycoRoles, RoycoTestBase, StakedRoyUSD } from "../utils/RoycoTestBase.sol";

contract RoycoAuthTest is RoycoTestBase {
    function setUp() external {
        _setUpRoyco();
    }

    function test_Deployment(address _owner) external {
        vm.assume(_owner != address(0));

        MockRoycoContract roycoContract = new MockRoycoContract(_owner);
        assertEq(roycoContract.owner(), _owner);
    }

    function test_RevertIf_OwnershipRenounced(address _owner) external {
        vm.assume(_owner != address(0));

        MockRoycoContract roycoContract = new MockRoycoContract(_owner);
        vm.expectRevert(RoycoAuth.CannotRenounceOwnership.selector);
        vm.prank(_owner);
        roycoContract.renounceOwnership();
    }

    function test_RevertIf_UpdateExecutionDelay_ByNonSchedulerManager() external {
        bytes4[] memory selectors = new bytes4[](1);
        selectors[0] = RoycoReserve.setCollateralAdapter.selector;
        uint256[] memory delays = new uint256[](1);
        delays[0] = 1 days;

        // Try to update delay as owner (should revert)
        vm.prank(OWNER_ADDRESS);
        vm.expectRevert();
        reserve.updateExecutionDelay(selectors, delays);

        // Try to update delay as reserve manager (should revert)
        vm.prank(RESERVE_MANAGER_ADDRESS);
        vm.expectRevert();
        reserve.updateExecutionDelay(selectors, delays);

        // Try to update delay as random address (should revert)
        vm.prank(ALICE_ADDRESS);
        vm.expectRevert();
        reserve.updateExecutionDelay(selectors, delays);
    }

    function test_UpdateExecutionDelay_BySchedulerManager() external {
        bytes4[] memory selectors = new bytes4[](1);
        selectors[0] = RoycoReserve.setCollateralAdapter.selector;
        uint256[] memory delays = new uint256[](1);
        delays[0] = 1 days;

        // Update delay as scheduler manager (should succeed)
        vm.prank(SCHEDULER_MANAGER_ADDRESS);
        reserve.updateExecutionDelay(selectors, delays);

        // Verify the delay was updated
        assertEq(reserve.executionDelay(RoycoReserve.setCollateralAdapter.selector), 1 days);
    }

    function test_RevertIf_CancelScheduledOperation_ByNonSchedulerManager() external {
        // First schedule an operation
        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.setCollateralAdapter(address(mockUSDC), makeAddr("adapter"));

        // Try to cancel as owner (should revert)
        vm.prank(OWNER_ADDRESS);
        vm.expectRevert();
        reserve.cancelScheduledOperation(RoycoReserve.setCollateralAdapter.selector);

        // Try to cancel as reserve manager (should revert)
        vm.prank(RESERVE_MANAGER_ADDRESS);
        vm.expectRevert();
        reserve.cancelScheduledOperation(RoycoReserve.setCollateralAdapter.selector);

        // Try to cancel as random address (should revert)
        vm.prank(ALICE_ADDRESS);
        vm.expectRevert();
        reserve.cancelScheduledOperation(RoycoReserve.setCollateralAdapter.selector);
    }

    function test_CancelScheduledOperation_BySchedulerManager() external {
        // First schedule an operation
        vm.prank(RESERVE_MANAGER_ADDRESS);
        reserve.setCollateralAdapter(address(mockUSDC), makeAddr("adapter"));

        // Verify operation is scheduled
        (bytes32 calldataHash, uint256 executeAt) = reserve.scheduledOperations(RoycoReserve.setCollateralAdapter.selector);
        assertTrue(executeAt > 0, "Operation should be scheduled");

        // Cancel as scheduler manager (should succeed)
        vm.prank(SCHEDULER_MANAGER_ADDRESS);
        reserve.cancelScheduledOperation(RoycoReserve.setCollateralAdapter.selector);

        // Verify operation is cancelled
        (calldataHash, executeAt) = reserve.scheduledOperations(RoycoReserve.setCollateralAdapter.selector);
        assertEq(executeAt, 0, "Operation should be cancelled");
    }

    // ============ Test Delay Updateability ============

    function test_UpdateExecutionDelay_MultipleSelectors() external {
        // Test updating multiple selectors on the same contract (reserve)
        bytes4[] memory reserveSelectors = new bytes4[](1);
        reserveSelectors[0] = RoycoReserve.setCollateralAdapter.selector;

        uint256[] memory reserveDelays = new uint256[](1);
        reserveDelays[0] = 1 days;

        // Update delays for reserve selectors
        vm.prank(SCHEDULER_MANAGER_ADDRESS);
        reserve.updateExecutionDelay(reserveSelectors, reserveDelays);

        // Test updating multiple selectors on the same contract (sRoyUSD)
        bytes4[] memory stakingSelectors = new bytes4[](2);
        stakingSelectors[0] = StakedRoyUSD.setUnstakingDuration.selector;
        stakingSelectors[1] = StakedRoyUSD.blacklistStaker.selector;

        uint256[] memory stakingDelays = new uint256[](2);
        stakingDelays[0] = 2 days;
        stakingDelays[1] = 3 days;

        // Update delays for staking selectors
        vm.prank(SCHEDULER_MANAGER_ADDRESS);
        sRoyUSD.updateExecutionDelay(stakingSelectors, stakingDelays);

        // Verify all delays were updated
        assertEq(reserve.executionDelay(RoycoReserve.setCollateralAdapter.selector), 1 days);
        assertEq(sRoyUSD.executionDelay(StakedRoyUSD.setUnstakingDuration.selector), 2 days);
        assertEq(sRoyUSD.executionDelay(StakedRoyUSD.blacklistStaker.selector), 3 days);
    }

    function test_UpdateExecutionDelay_ZeroDelay() external {
        bytes4[] memory selectors = new bytes4[](1);
        selectors[0] = RoycoReserve.setCollateralAdapter.selector;
        uint256[] memory delays = new uint256[](1);
        delays[0] = 0;

        // Update delay to zero (should succeed)
        vm.prank(SCHEDULER_MANAGER_ADDRESS);
        reserve.updateExecutionDelay(selectors, delays);

        // Verify the delay was set to zero
        assertEq(reserve.executionDelay(RoycoReserve.setCollateralAdapter.selector), 0);
    }

    function test_RevertIf_UpdateExecutionDelay_LengthMismatch() external {
        bytes4[] memory selectors = new bytes4[](2);
        selectors[0] = RoycoReserve.setCollateralAdapter.selector;
        selectors[1] = StakedRoyUSD.setUnstakingDuration.selector;

        uint256[] memory delays = new uint256[](1);
        delays[0] = 1 days;

        // Try to update with mismatched lengths (should revert)
        vm.prank(SCHEDULER_MANAGER_ADDRESS);
        vm.expectRevert();
        reserve.updateExecutionDelay(selectors, delays);
    }
}
