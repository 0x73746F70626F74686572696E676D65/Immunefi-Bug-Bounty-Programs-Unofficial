pragma solidity ^0.8.28;

import { ERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/ERC20.sol";

import { CollateralRegistry } from "../../src/teller/base/CollateralRegistry.sol";
import { MockERC20 } from "../utils/MockERC20.sol";
import { RoyUSD, RoycoRoles, RoycoTeller, RoycoTestBase } from "../utils/RoycoTestBase.sol";

contract RoyUSDTest is RoycoTestBase {
    function setUp() external {
        _setUpRoyco();
    }

    function test_Deployment() external view {
        assertEq(teller.owner(), OWNER_ADDRESS);
        assertTrue(teller.hasAllRoles(MINTER_ADDRESS, RoycoRoles.MINTER));
        assertTrue(teller.hasAllRoles(REDEEMER_ADDRESS, RoycoRoles.REDEEMER));
        assertTrue(teller.hasAllRoles(COLLATERAL_MANAGER_ADDRESS, RoycoRoles.COLLATERAL_MANAGER));
        assertEq(teller.RESERVE(), address(reserve));
    }

    function testFuzz_Mint(uint256 _amountToMint, uint256 _collateralIndex) external {
        address collateralAsset = collateralAssets[_collateralIndex % 3];
        uint256 maxMintable = _getMaxMintable(collateralAsset);
        _amountToMint = bound(_amountToMint, 0, maxMintable);

        uint256 preMintReserves = ERC20(collateralAsset).balanceOf(address(reserve));
        uint256 quotedCostInCollateral = teller.quoteMintCost(_amountToMint, collateralAsset);
        address recipient = _getRandomRecipient(_collateralIndex);

        vm.expectEmit(true, true, false, true);
        emit RoycoTeller.Mint(MINTER_ADDRESS, recipient, _amountToMint, collateralAsset, quotedCostInCollateral);

        vm.prank(MINTER_ADDRESS);
        teller.mint(_amountToMint, collateralAsset, recipient);

        assertEq(ERC20(royUSD).balanceOf(recipient), _amountToMint);
        assertEq(ERC20(collateralAsset).balanceOf(address(reserve)) - preMintReserves, quotedCostInCollateral);
    }

    function testFuzz_RedeemSingle(uint256 _amountToMint, uint256 _collateralIndex) external {
        address collateralAsset = collateralAssets[_collateralIndex % 3];
        uint256 maxMintable = _getMaxMintable(collateralAsset);
        _amountToMint = bound(_amountToMint, 1e18, maxMintable);

        vm.prank(MINTER_ADDRESS);
        teller.mint(_amountToMint, collateralAsset, REDEEMER_ADDRESS);

        uint256 amountToRedeem = bound(_amountToMint, 1e12, _amountToMint);
        uint256 quotedCollateralOutput = teller.quoteRedemptionOutput(amountToRedeem, collateralAsset);
        address recipient = _getRandomRecipient(_collateralIndex);

        vm.expectEmit(true, true, false, true);
        emit RoycoTeller.Redeem(REDEEMER_ADDRESS, recipient, amountToRedeem, collateralAsset, quotedCollateralOutput);

        vm.prank(REDEEMER_ADDRESS);
        teller.redeem(amountToRedeem, collateralAsset, recipient);

        assertEq(ERC20(collateralAsset).balanceOf(recipient), quotedCollateralOutput);
        assertEq(ERC20(royUSD).balanceOf(REDEEMER_ADDRESS), _amountToMint - amountToRedeem);
    }

    function testFuzz_RedeemMultiple(uint256 _amountToMint, uint256 _collateralIndex) external {
        uint256 totalMinted = 0;
        uint256[] memory preRedeemReserves = new uint256[](3);

        // Mint with multiple different collateral assets
        for (uint256 i = 0; i < 3; i++) {
            address collateralAsset = collateralAssets[i];
            uint256 maxMintable = _getMaxMintable(collateralAsset);
            uint256 amountToMint = bound(_amountToMint, 0, maxMintable / 3);

            if (amountToMint > 0) {
                preRedeemReserves[i] = ERC20(collateralAsset).balanceOf(address(reserve));
                vm.prank(MINTER_ADDRESS);
                teller.mint(amountToMint, collateralAsset, REDEEMER_ADDRESS);
                totalMinted += amountToMint;
            }
        }

        vm.assume(totalMinted > 0);
        uint256 amountToRedeem = bound(_amountToMint, 1, totalMinted);
        address recipient = _getRandomRecipient(_collateralIndex);

        uint256[] memory preRedeemBalances = new uint256[](3);
        for (uint256 i = 0; i < 3; i++) {
            preRedeemBalances[i] = ERC20(collateralAssets[i]).balanceOf(recipient);
        }

        // Capture reserve balances before redemption to simulate the batch redemption logic
        uint256[] memory preRedeemReserveBalances = new uint256[](3);
        for (uint256 i = 0; i < 3; i++) {
            preRedeemReserveBalances[i] = ERC20(collateralAssets[i]).balanceOf(address(reserve));
        }

        vm.prank(REDEEMER_ADDRESS);
        teller.redeem(amountToRedeem, recipient);

        // Simulate the batch redemption logic to verify exact amounts received
        uint256 remainingToRedeem = amountToRedeem;
        for (uint256 i = 0; i < 3; i++) {
            address collateralAsset = collateralAssets[i];
            uint256 availableCollateral = preRedeemReserveBalances[i];
            uint256 actualReceived = ERC20(collateralAsset).balanceOf(recipient) - preRedeemBalances[i];

            if (availableCollateral > 0 && remainingToRedeem > 0) {
                uint256 quotedOutput = teller.quoteRedemptionOutput(remainingToRedeem, collateralAsset);
                if (quotedOutput == 0) continue;

                if (availableCollateral >= quotedOutput) {
                    // Full redemption satisfied with this asset
                    assertEq(actualReceived, quotedOutput);
                    remainingToRedeem = 0;
                    break;
                } else {
                    // Partial redemption with available collateral
                    assertEq(actualReceived, availableCollateral);
                    // Calculate how much RoyUSD was redeemed for this collateral amount
                    uint256 pricePerRoyUSD = teller.collateralAssetToPrice(collateralAsset);
                    uint256 royUsdRedeemed = (availableCollateral * 1e18) / pricePerRoyUSD;
                    remainingToRedeem -= royUsdRedeemed;
                }
            } else {
                assertEq(actualReceived, 0);
            }
        }

        assertEq(remainingToRedeem, 0);
        assertEq(ERC20(royUSD).balanceOf(REDEEMER_ADDRESS), totalMinted - amountToRedeem);
    }

    function testFuzz_RevertIf_InsufficientReserves(uint256 _amountToMint, uint256 _collateralIndex) external {
        address collateralAsset = collateralAssets[_collateralIndex % 3];
        uint256 maxMintable = _getMaxMintable(collateralAsset);
        _amountToMint = bound(_amountToMint, 1, maxMintable);

        vm.prank(MINTER_ADDRESS);
        teller.mint(_amountToMint, collateralAsset, REDEEMER_ADDRESS);

        for (uint256 i = 0; i < 3; i++) {
            address asset = collateralAssets[i];
            uint256 balance = ERC20(asset).balanceOf(address(reserve));
            if (balance > 0) {
                vm.prank(RESERVE_MANAGER_ADDRESS);
                reserve.freeReserves(asset, RESERVE_MANAGER_ADDRESS, balance);
            }
        }

        vm.expectRevert(RoycoTeller.InsufficientReserves.selector);
        vm.prank(REDEEMER_ADDRESS);
        teller.redeem(_amountToMint, _getRandomRecipient(_collateralIndex));
    }

    function test_RevertIf_AddCollateralAsset_CalledBeforeDelay() external {
        address newAsset = makeAddr("newAsset");

        // Schedule the operation
        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        teller.addCollateralAsset(newAsset);

        // Try to execute immediately (should revert)
        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        vm.expectRevert();
        teller.addCollateralAsset(newAsset);
    }

    function test_RevertIf_RemoveCollateralAsset_CalledBeforeDelay() external {
        // Schedule the operation
        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        teller.removeCollateralAsset(address(mockUSDC));

        // Try to execute immediately (should revert)
        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        vm.expectRevert();
        teller.removeCollateralAsset(address(mockUSDC));
    }
}
