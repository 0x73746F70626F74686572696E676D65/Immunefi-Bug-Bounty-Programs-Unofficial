// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { RoyUSD, RoycoRoles, RoycoTestBase } from "../utils/RoycoTestBase.sol";

contract RoyUSDTest is RoycoTestBase {
    function setUp() external {
        _setUpRoyco();
    }

    function test_Deployment() external view {
        assertEq(royUSD.owner(), OWNER_ADDRESS);
        assertTrue(royUSD.hasAllRoles(address(teller), RoycoRoles.TELLER));
        assertTrue(royUSD.hasAllRoles(address(flashLender), RoycoRoles.LENDER));
        assertEq(royUSD.maxSupply(), type(uint256).max);
    }

    function testFuzz_SetMaxSupply(uint256 _maxSupply) external prankModifier(OWNER_ADDRESS) {
        _maxSupply = bound(_maxSupply, royUSD.totalSupply(), type(uint256).max);

        vm.expectEmit(false, false, false, true, address(royUSD));
        emit RoyUSD.MaxSupplySet(_maxSupply);

        royUSD.setMaxSupply(_maxSupply);
        assertEq(royUSD.maxSupply(), _maxSupply);
    }

    function testFuzz_RevertIf_MaxSupplyExceeded(uint248 _amountToMint, uint256 _maxSupply) external {
        _setUpRoyUSDRoles(address(this), address(0), address(0), SCHEDULER_MANAGER_ADDRESS);
        royUSD.mint(address(this), _amountToMint);

        _maxSupply = bound(_maxSupply, 0, royUSD.totalSupply() - 1);
        vm.expectRevert(RoyUSD.MaxSupplyExceeded.selector);
        vm.prank(OWNER_ADDRESS);
        royUSD.setMaxSupply(_maxSupply);
    }
}
