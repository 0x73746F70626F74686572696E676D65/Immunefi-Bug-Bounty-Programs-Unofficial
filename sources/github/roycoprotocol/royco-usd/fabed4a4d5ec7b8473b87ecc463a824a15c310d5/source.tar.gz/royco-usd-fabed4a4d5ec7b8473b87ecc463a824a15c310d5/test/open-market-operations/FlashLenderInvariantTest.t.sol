// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { StdInvariant } from "../../lib/forge-std/src/StdInvariant.sol";
import { Test } from "../../lib/forge-std/src/Test.sol";
import { ERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/ERC20.sol";
import { MockERC20 } from "../utils/MockERC20.sol";
import { MockFlashBorrower } from "../utils/MockFlashBorrower.sol";
import { RoyUSD, RoycoFlashLender, RoycoRoles, RoycoTestBase } from "../utils/RoycoTestBase.sol";

contract FlashLenderInvariantHandler is RoycoTestBase {
    uint256 public totalRoyUSDFeesCollected; // Only fees from RoyUSD flash mints

    // Track initial states
    mapping(address => uint256) public initialReserveBalances;
    uint256 public initialRoyUSDSupply;

    // Track additional mints/additions
    mapping(address => uint256) public totalAdditionalReserveMints;

    // Flash borrower for testing
    MockFlashBorrower public borrower;

    function setUp() external {
        _setUpRoyco();
        borrower = new MockFlashBorrower();

        // Grant borrower roles for RoyUSD operations
        vm.prank(OWNER_ADDRESS);
        royUSD.grantRoles(address(borrower), RoycoRoles.TELLER);

        // Ensure borrower is in good state
        borrower.setFailCallbackOnLoan(false);
        borrower.setFailPrincipalRepaymentOnLoan(false);
        borrower.setFailFeeRepaymentOnLoan(false);

        // Store initial state
        initialRoyUSDSupply = royUSD.totalSupply();

        address[] memory collateralAssetsList = teller.getCollateralAssets();
        for (uint256 i = 0; i < collateralAssetsList.length; i++) {
            address asset = collateralAssetsList[i];
            initialReserveBalances[asset] = ERC20(asset).balanceOf(address(reserve));
        }
    }

    function flashLoanCollateral(uint256 _loanAmount, uint256 _collateralIndex, uint16 _feeBPS) external {
        address[] memory collateralAssetsList = teller.getCollateralAssets();
        if (collateralAssetsList.length == 0) return;

        address collateralAsset = collateralAssetsList[_collateralIndex % collateralAssetsList.length];
        uint256 maxLoanable = flashLender.maxFlashLoan(collateralAsset);

        if (maxLoanable == 0) return;

        _loanAmount = bound(_loanAmount, 1, maxLoanable);
        _feeBPS = uint16(bound(_feeBPS, 0, 1000)); // Max 10% fee

        // Set fee configuration
        vm.prank(OWNER_ADDRESS);
        flashLender.setFlashLoanConfig(collateralAsset, type(uint240).max, _feeBPS);

        // Execute flash loan
        flashLender.flashLoan(borrower, collateralAsset, _loanAmount, new bytes(0));
    }

    function flashMintRoyUSD(uint256 _mintAmount, uint16 _feeBPS) external {
        uint256 maxMintable = flashLender.maxFlashLoan(address(royUSD));

        if (maxMintable == 0) return;

        _mintAmount = bound(_mintAmount, 1, maxMintable);
        _feeBPS = uint16(bound(_feeBPS, 0, 1000)); // Max 10% fee

        // Set fee configuration for RoyUSD
        vm.prank(OWNER_ADDRESS);
        flashLender.setFlashLoanConfig(address(royUSD), type(uint240).max, _feeBPS);

        uint256 fee = flashLender.flashFee(address(royUSD), _mintAmount);

        // Execute flash mint
        flashLender.flashLoan(borrower, address(royUSD), _mintAmount, new bytes(0));

        totalRoyUSDFeesCollected += fee; // Track RoyUSD fees separately
    }

    function setFlashLoanConfiguration(uint256 _assetIndex, uint240 _maxLoanAmount, uint16 _feeBPS) external {
        address asset;
        if (_assetIndex % 2 == 0) {
            asset = address(royUSD);
        } else {
            address[] memory collateralAssetsList = teller.getCollateralAssets();
            if (collateralAssetsList.length == 0) return;
            asset = collateralAssetsList[_assetIndex % collateralAssetsList.length];
        }

        _feeBPS = uint16(bound(_feeBPS, 0, 1000));

        vm.prank(OWNER_ADDRESS);
        flashLender.setFlashLoanConfig(asset, _maxLoanAmount, _feeBPS);
    }

    function addReservesToCollateral(uint256 _amount, uint256 _collateralIndex) external {
        address[] memory collateralAssetsList = teller.getCollateralAssets();
        if (collateralAssetsList.length == 0) return;

        address collateralAsset = collateralAssetsList[_collateralIndex % collateralAssetsList.length];
        _amount = bound(_amount, 1, type(uint128).max);

        // Mint tokens to the reserve to simulate more liquidity
        MockERC20(collateralAsset).mint(address(reserve), _amount);

        // Track the additional mints
        totalAdditionalReserveMints[collateralAsset] += _amount;
    }

    function getCurrentRoyUSDSupply() external view returns (uint256) {
        return royUSD.totalSupply();
    }

    function getCurrentReserveBalance(address asset) external view returns (uint256) {
        return ERC20(asset).balanceOf(address(reserve));
    }

    function getExpectedReserveBalance(address asset) external view returns (uint256) {
        return initialReserveBalances[asset] + totalAdditionalReserveMints[asset];
    }
}

contract FlashLenderInvariantTest is StdInvariant, Test {
    FlashLenderInvariantHandler public handler;

    function setUp() external {
        handler = new FlashLenderInvariantHandler();
        handler.setUp();

        bytes4[] memory selectors = new bytes4[](4);
        selectors[0] = FlashLenderInvariantHandler.flashLoanCollateral.selector;
        selectors[1] = FlashLenderInvariantHandler.flashMintRoyUSD.selector;
        selectors[2] = FlashLenderInvariantHandler.setFlashLoanConfiguration.selector;
        selectors[3] = FlashLenderInvariantHandler.addReservesToCollateral.selector;

        targetSelector(FuzzSelector({ addr: address(handler), selectors: selectors }));
        targetContract(address(handler));
    }

    function invariant_ReserveBalancesPreserved() external view {
        address[] memory collateralAssetsList = handler.teller().getCollateralAssets();

        for (uint256 i = 0; i < collateralAssetsList.length; i++) {
            address collateralAsset = collateralAssetsList[i];
            uint256 currentBalance = handler.getCurrentReserveBalance(collateralAsset);
            uint256 expectedBalance = handler.getExpectedReserveBalance(collateralAsset);

            // Reserve balance should exactly equal initial + additional mints
            // Flash loans should not change the reserve balance (borrows and repays same amount)
            assertEq(currentBalance, expectedBalance, "Reserve balance should equal initial + additional mints");
        }
    }

    function invariant_RoyUSDSupplyOnlyIncreasesByFees() external view {
        uint256 currentSupply = handler.getCurrentRoyUSDSupply();
        uint256 initialSupply = handler.initialRoyUSDSupply();
        uint256 royUSDFeesCollected = handler.totalRoyUSDFeesCollected();

        // Supply should only increase by collected fees from RoyUSD flash mints
        // Flash loans should restore the original supply (burn principal, keep fees)
        assertEq(currentSupply, initialSupply + royUSDFeesCollected, "RoyUSD supply should only increase by RoyUSD fees collected");
    }

    function invariant_NoTokensStuckInLender() external view {
        address[] memory collateralAssetsList = handler.teller().getCollateralAssets();

        // Lender should never hold any collateral tokens
        for (uint256 i = 0; i < collateralAssetsList.length; i++) {
            address collateralAsset = collateralAssetsList[i];
            uint256 flashLenderBalance = ERC20(collateralAsset).balanceOf(address(handler.flashLender()));

            assertEq(flashLenderBalance, 0, "Lender should not hold any collateral tokens");
        }

        // Lender should never hold RoyUSD tokens
        uint256 flashLenderRoyUSDBalance = ERC20(address(handler.royUSD())).balanceOf(address(handler.flashLender()));
        assertEq(flashLenderRoyUSDBalance, 0, "Lender should not hold any RoyUSD tokens");
    }
}
