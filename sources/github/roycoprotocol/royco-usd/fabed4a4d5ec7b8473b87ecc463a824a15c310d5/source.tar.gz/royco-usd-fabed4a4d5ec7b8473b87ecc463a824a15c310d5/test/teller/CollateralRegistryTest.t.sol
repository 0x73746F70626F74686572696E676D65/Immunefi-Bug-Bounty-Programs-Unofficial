// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { ERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/ERC20.sol";

import { RoycoAuth } from "../../src/auth/RoycoAuth.sol";
import { CollateralRegistry } from "../../src/teller/base/CollateralRegistry.sol";
import { MockERC20 } from "../utils/MockERC20.sol";
import { RoyUSD, RoycoRoles, RoycoTeller, RoycoTestBase } from "../utils/RoycoTestBase.sol";

contract CollateralRegistryTest is RoycoTestBase {
    function setUp() external {
        _setUpRoyco();
    }

    function test_Deployment() external view {
        assertEq(teller.ROY_USD(), address(royUSD));
        assertEq(teller.getCollateralAssets(), collateralAssets);
    }

    function test_AddCollateral() external {
        MockERC20 newCollateral = new MockERC20("New Token", "NEW", 18);
        address newCollateralAddress = address(newCollateral);

        // Schedule phase - expect OperationScheduled event
        vm.expectEmit(true, true, true, true);
        emit RoycoAuth.OperationScheduled(
            RoycoTeller.addCollateralAsset.selector,
            keccak256(abi.encodeWithSelector(RoycoTeller.addCollateralAsset.selector, newCollateralAddress)),
            COLLATERAL_MANAGER_ADDRESS,
            vm.getBlockTimestamp() + TELLER_COLLATERAL_UPDATE_DELAY
        );

        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        teller.addCollateralAsset(newCollateralAddress); // schedule

        vm.warp(vm.getBlockTimestamp() + TELLER_COLLATERAL_UPDATE_DELAY);

        // Execute phase - expect CollateralAssetAdded event
        vm.expectEmit(true, false, false, false);
        emit CollateralRegistry.CollateralAssetAdded(newCollateralAddress);

        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        teller.addCollateralAsset(newCollateralAddress); // execute

        address[] memory assets = teller.getCollateralAssets();
        bool found = false;
        for (uint256 i = 0; i < assets.length; i++) {
            if (assets[i] == newCollateralAddress) {
                found = true;
                break;
            }
        }
        assertTrue(found);

        assertEq(teller.collateralAssetToPrice(newCollateralAddress), 10 ** newCollateral.decimals());
    }

    function test_RevertIf_AddRoyUSDAsCollateral() external {
        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        teller.addCollateralAsset(address(royUSD)); // schedule
        vm.warp(vm.getBlockTimestamp() + TELLER_COLLATERAL_UPDATE_DELAY);
        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        vm.expectRevert(CollateralRegistry.InvalidCollateralAsset.selector);
        teller.addCollateralAsset(address(royUSD)); // execute
    }

    function test_RevertIf_AddNonTokenCollateral() external {
        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        teller.addCollateralAsset(address(0)); // schedule
        vm.warp(vm.getBlockTimestamp() + TELLER_COLLATERAL_UPDATE_DELAY);
        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        vm.expectRevert();
        teller.addCollateralAsset(address(0)); // execute
    }

    function test_RevertIf_AddExistantCollateral() external {
        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        teller.addCollateralAsset(address(mockUSDC)); // schedule
        vm.warp(vm.getBlockTimestamp() + TELLER_COLLATERAL_UPDATE_DELAY);
        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        vm.expectRevert(CollateralRegistry.InvalidCollateralAsset.selector);
        teller.addCollateralAsset(address(mockUSDC)); // execute
    }

    function test_RemoveCollateral() external {
        address collateralToRemove = address(mockUSDC);

        // Schedule phase - expect OperationScheduled event
        vm.expectEmit(true, true, true, true);
        emit RoycoAuth.OperationScheduled(
            RoycoTeller.removeCollateralAsset.selector,
            keccak256(abi.encodeWithSelector(RoycoTeller.removeCollateralAsset.selector, collateralToRemove)),
            COLLATERAL_MANAGER_ADDRESS,
            vm.getBlockTimestamp() + TELLER_COLLATERAL_UPDATE_DELAY
        );

        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        teller.removeCollateralAsset(collateralToRemove); // schedule

        vm.warp(vm.getBlockTimestamp() + TELLER_COLLATERAL_UPDATE_DELAY);

        // Execute phase - expect CollateralAssetRemoved event
        vm.expectEmit(true, false, false, false);
        emit CollateralRegistry.CollateralAssetRemoved(collateralToRemove);

        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        teller.removeCollateralAsset(collateralToRemove); // execute

        address[] memory assets = teller.getCollateralAssets();
        for (uint256 i = 0; i < assets.length; i++) {
            assertNotEq(assets[i], collateralToRemove);
        }

        assertEq(teller.collateralAssetToPrice(collateralToRemove), 0);
    }

    function test_RevertIf_RemoveNonexistantCollateral() external {
        MockERC20 nonExistentCollateral = new MockERC20("Non Existent", "NE", 18);

        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        teller.removeCollateralAsset(address(nonExistentCollateral)); // schedule
        vm.warp(vm.getBlockTimestamp() + TELLER_COLLATERAL_UPDATE_DELAY);
        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        vm.expectRevert(CollateralRegistry.InvalidCollateralAsset.selector);
        teller.removeCollateralAsset(address(nonExistentCollateral)); // execute
    }

    function test_RevertIf_RemoveZeroAddressCollateral() external {
        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        teller.removeCollateralAsset(address(0)); // schedule
        vm.warp(vm.getBlockTimestamp() + TELLER_COLLATERAL_UPDATE_DELAY);
        vm.prank(COLLATERAL_MANAGER_ADDRESS);
        vm.expectRevert(CollateralRegistry.InvalidCollateralAsset.selector);
        teller.removeCollateralAsset(address(0)); // execute
    }
}
