// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { IERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol";
import { RoycoRoles } from "../../src/auth/RoycoRoles.sol";
import { RoyUSD, RoycoTestBase, StakedRoyUSD } from "../utils/RoycoTestBase.sol";

contract StakedRoyUSDTest is RoycoTestBase {
    function setUp() external {
        _setUpRoyco();
    }

    function test_Deployment() external view {
        // Ownership and wiring
        assertEq(sRoyUSD.owner(), OWNER_ADDRESS);
        assertEq(address(sRoyUSD.asset()), address(royUSD));
        assertEq(sRoyUSD.RESERVE(), address(reserve));

        // Token metadata
        assertEq(sRoyUSD.decimals(), RoyUSD(address(royUSD)).decimals());

        // Config seeded in base
        assertEq(sRoyUSD.unstakingDuration(), 2 weeks);

        // Initial deposit
        assertEq(sRoyUSD.balanceOf(OWNER_ADDRESS), SEED_AMOUNT);
    }

    function testFuzz_StakeAndCommenceUnstake(uint256 _mintAmount, uint256 _stakeBps, uint256 _unstakeBps) external {
        // Mint RoyUSD to ALICE via teller using mockUSDC
        _mintAmount = bound(_mintAmount, 1e18, 100_000e18);
        vm.prank(MINTER_ADDRESS);
        teller.mint(_mintAmount, address(mockUSDC), ALICE_ADDRESS);

        // Stake a portion
        _stakeBps = bound(_stakeBps, 1, 10_000);
        uint256 stakeAssets = (_mintAmount * _stakeBps) / 10_000;

        vm.startPrank(ALICE_ADDRESS);
        IERC20(address(royUSD)).approve(address(sRoyUSD), stakeAssets);
        sRoyUSD.deposit(stakeAssets, ALICE_ADDRESS);
        vm.stopPrank();

        // Commence unstake for a portion of staked assets
        uint256 maxAssets = sRoyUSD.previewRedeem(sRoyUSD.balanceOf(ALICE_ADDRESS));
        _unstakeBps = bound(_unstakeBps, 1, 10_000);
        uint256 assetsToUnstake = (maxAssets * _unstakeBps) / 10_000;
        if (assetsToUnstake == 0) assetsToUnstake = 1;

        uint256 reserveBalanceBefore = IERC20(address(royUSD)).balanceOf(address(reserve));

        vm.prank(ALICE_ADDRESS);
        sRoyUSD.commenceAssetsUnstakingPeriod(assetsToUnstake);

        // Assert unstaking state
        (uint216 amountToUnstake, uint40 whenUnstakeable) = sRoyUSD.stakerToUnstakingState(ALICE_ADDRESS);
        assertEq(uint256(amountToUnstake), assetsToUnstake);
        assertEq(uint256(whenUnstakeable), vm.getBlockTimestamp() + sRoyUSD.unstakingDuration());

        // Assert funds moved to reserve
        uint256 reserveBalanceAfter = IERC20(address(royUSD)).balanceOf(address(reserve));
        assertEq(reserveBalanceAfter - reserveBalanceBefore, assetsToUnstake);

        // Advance time by the configured unstaking duration and complete unstake
        skip(sRoyUSD.unstakingDuration());

        uint256 aliceRoyBefore = IERC20(address(royUSD)).balanceOf(ALICE_ADDRESS);

        vm.prank(ALICE_ADDRESS);
        sRoyUSD.unstake(ALICE_ADDRESS);

        // Unstaking state cleared
        (uint216 amountToUnstakeAfter, uint40 whenUnstakeableAfter) = sRoyUSD.stakerToUnstakingState(ALICE_ADDRESS);
        assertEq(uint256(amountToUnstakeAfter), 0);
        assertEq(uint256(whenUnstakeableAfter), 0);

        // Reserve sent assets back to Alice
        uint256 reserveBalanceFinal = IERC20(address(royUSD)).balanceOf(address(reserve));
        assertEq(reserveBalanceAfter - reserveBalanceFinal, assetsToUnstake);
        assertEq(IERC20(address(royUSD)).balanceOf(ALICE_ADDRESS) - aliceRoyBefore, assetsToUnstake);
    }

    function testFuzz_StakeAndCommenceUnstake_ByShares(uint256 _mintAmount, uint256 _stakeBps, uint256 _unstakeBps) external {
        // Mint RoyUSD to ALICE via teller using mockUSDC
        _mintAmount = bound(_mintAmount, 1e18, 100_000e18);
        vm.prank(MINTER_ADDRESS);
        teller.mint(_mintAmount, address(mockUSDC), ALICE_ADDRESS);

        // Stake a portion
        _stakeBps = bound(_stakeBps, 1, 10_000);
        uint256 stakeAssets = (_mintAmount * _stakeBps) / 10_000;

        vm.startPrank(ALICE_ADDRESS);
        IERC20(address(royUSD)).approve(address(sRoyUSD), stakeAssets);
        sRoyUSD.deposit(stakeAssets, ALICE_ADDRESS);
        vm.stopPrank();

        // Determine shares to burn and corresponding assets
        uint256 totalShares = sRoyUSD.balanceOf(ALICE_ADDRESS);
        _unstakeBps = bound(_unstakeBps, 1, 10_000);
        uint256 sharesToBurn = (totalShares * _unstakeBps) / 10_000;
        if (sharesToBurn == 0) sharesToBurn = 1;
        uint256 assetsToUnstake = sRoyUSD.previewRedeem(sharesToBurn);

        uint256 reserveBalanceBefore = IERC20(address(royUSD)).balanceOf(address(reserve));

        vm.prank(ALICE_ADDRESS);
        sRoyUSD.commenceSharesUnstakingPeriod(sharesToBurn);

        // Assert unstaking state reflects the converted assets
        (uint216 amountToUnstake, uint40 whenUnstakeable) = sRoyUSD.stakerToUnstakingState(ALICE_ADDRESS);
        assertEq(uint256(amountToUnstake), assetsToUnstake);
        assertEq(uint256(whenUnstakeable), vm.getBlockTimestamp() + sRoyUSD.unstakingDuration());

        // Reserve should have received the assets being unstaked
        uint256 reserveBalanceAfter = IERC20(address(royUSD)).balanceOf(address(reserve));
        assertEq(reserveBalanceAfter - reserveBalanceBefore, assetsToUnstake);

        // Advance time and complete unstake
        skip(sRoyUSD.unstakingDuration());

        uint256 aliceRoyBefore = IERC20(address(royUSD)).balanceOf(ALICE_ADDRESS);
        vm.prank(ALICE_ADDRESS);
        sRoyUSD.unstake(ALICE_ADDRESS);

        // Unstaking state cleared and balances updated
        (uint216 amountToUnstakeAfter, uint40 whenUnstakeableAfter) = sRoyUSD.stakerToUnstakingState(ALICE_ADDRESS);
        assertEq(uint256(amountToUnstakeAfter), 0);
        assertEq(uint256(whenUnstakeableAfter), 0);

        uint256 reserveBalanceFinal = IERC20(address(royUSD)).balanceOf(address(reserve));
        assertEq(reserveBalanceAfter - reserveBalanceFinal, assetsToUnstake);
        assertEq(IERC20(address(royUSD)).balanceOf(ALICE_ADDRESS) - aliceRoyBefore, assetsToUnstake);
    }

    function test_Unstake_Reverts_NothingToUnstake() external {
        // No commence called; direct unstake should revert
        vm.prank(ALICE_ADDRESS);
        vm.expectRevert(StakedRoyUSD.NothingToUnstake.selector);
        sRoyUSD.unstake(ALICE_ADDRESS);
    }

    function testFuzz_Unstake_Reverts_UnstakingPeriodInProgress(uint256 _mintAmount, uint256 _stakeBps, uint256 _unstakeBps) external {
        // Mint and stake
        _mintAmount = bound(_mintAmount, 1e18, 100_000e18);
        vm.prank(MINTER_ADDRESS);
        teller.mint(_mintAmount, address(mockUSDC), ALICE_ADDRESS);

        _stakeBps = bound(_stakeBps, 1, 10_000);
        uint256 stakeAssets = (_mintAmount * _stakeBps) / 10_000;

        vm.startPrank(ALICE_ADDRESS);
        IERC20(address(royUSD)).approve(address(sRoyUSD), stakeAssets);
        sRoyUSD.deposit(stakeAssets, ALICE_ADDRESS);
        vm.stopPrank();

        // Commence unstake for a portion
        uint256 maxAssets = sRoyUSD.previewRedeem(sRoyUSD.balanceOf(ALICE_ADDRESS));
        _unstakeBps = bound(_unstakeBps, 1, 10_000);
        uint256 assetsToUnstake = (maxAssets * _unstakeBps) / 10_000;
        if (assetsToUnstake == 0) assetsToUnstake = 1;

        vm.prank(ALICE_ADDRESS);
        sRoyUSD.commenceAssetsUnstakingPeriod(assetsToUnstake);

        // Attempt to unstake before duration elapses
        vm.prank(ALICE_ADDRESS);
        vm.expectRevert(StakedRoyUSD.UnstakingPeriodInProgress.selector);
        sRoyUSD.unstake(ALICE_ADDRESS);
    }

    function testFuzz_YieldDistribution_MultipleDepositors(uint256 _seed) external {
        _seed = bound(_seed, 1, 1000);

        // Create depositors
        uint256 numDepositors = bound(_seed, 3, 10);
        uint256[] memory stakeAmounts = new uint256[](numDepositors);
        address[] memory depositors = new address[](numDepositors);

        // Setup depositor 0 (seed depositor - already has SEED_AMOUNT staked)
        depositors[0] = OWNER_ADDRESS;
        stakeAmounts[0] = SEED_AMOUNT;

        // Setup depositors with smaller, more predictable amounts
        for (uint256 i = 1; i < numDepositors; i++) {
            depositors[i] = makeAddr(string(abi.encodePacked("DEPOSITOR_", i)));

            // Generate different stake amounts
            uint256 baseAmount = bound(_seed * (i + 1), 10_000e18, 100_000e18);
            stakeAmounts[i] = baseAmount;

            // Mint RoyUSD to depositor
            vm.prank(MINTER_ADDRESS);
            teller.mint(stakeAmounts[i], address(mockUSDC), depositors[i]);

            // Stake the RoyUSD
            vm.startPrank(depositors[i]);
            IERC20(address(royUSD)).approve(address(sRoyUSD), stakeAmounts[i]);
            sRoyUSD.deposit(stakeAmounts[i], depositors[i]);
            vm.stopPrank();
        }

        {
            // Calculate total staked amount
            uint256 totalStaked = 0;
            for (uint256 i = 0; i < numDepositors; i++) {
                totalStaked += stakeAmounts[i];
            }

            // Generate yield amount
            uint256 yieldAmount = bound(_seed, totalStaked / 10, totalStaked / 2);

            // Mint yield to YIELD_DISTRIBUTOR
            vm.prank(MINTER_ADDRESS);
            teller.mint(yieldAmount, address(mockUSDC), YIELD_DISTRIBUTOR_ADDRESS);

            // Record asset values before yield distribution

            uint256[] memory assetsBeforeYield = new uint256[](numDepositors);
            for (uint256 i = 0; i < numDepositors; i++) {
                uint256 shares = sRoyUSD.balanceOf(depositors[i]);
                assetsBeforeYield[i] = sRoyUSD.previewRedeem(shares);
            }

            // Distribute yield
            vm.startPrank(YIELD_DISTRIBUTOR_ADDRESS);
            IERC20(address(royUSD)).approve(address(sRoyUSD), yieldAmount);
            sRoyUSD.distributeYield(yieldAmount);
            vm.stopPrank();

            // Verify yield is vesting (not immediately available)
            assertEq(sRoyUSD.getUnvestedAssets(), yieldAmount, "All yield should be unvested initially");

            // Fast forward to end of vesting period
            skip(sRoyUSD.VESTING_DURATION());

            // Verify all yield is now vested
            assertEq(sRoyUSD.getUnvestedAssets(), 0, "All yield should be vested after duration");

            // Check that each depositor received yield proportional to their stake
            for (uint256 i = 0; i < numDepositors; i++) {
                uint256 shares = sRoyUSD.balanceOf(depositors[i]);
                uint256 assetsAfter = sRoyUSD.previewRedeem(shares);
                uint256 assetsBefore = assetsBeforeYield[i];
                uint256 actualYieldReceived = assetsAfter - assetsBefore;

                // Each depositor should receive some yield (at least 1 wei)
                assertGt(actualYieldReceived, 0, "Depositor should receive some yield");

                // Calculate expected yield based on proportional stake
                uint256 expectedYield = (yieldAmount * stakeAmounts[i]) / totalStaked;

                // The yield received should be close to the expected proportional amount
                assertApproxEqRel(actualYieldReceived, expectedYield, 0.05e18, "Depositor yield should be close to expected yield");
            }

            // Verify total yield distributed is close to expected
            uint256 totalYieldDistributed = 0;
            for (uint256 i = 0; i < numDepositors; i++) {
                uint256 shares = sRoyUSD.balanceOf(depositors[i]);
                uint256 assetsAfter = sRoyUSD.previewRedeem(shares);
                uint256 assetsBefore = assetsBeforeYield[i];
                totalYieldDistributed += assetsAfter - assetsBefore;
            }

            // Total yield distributed should be reasonable
            assertApproxEqAbs(totalYieldDistributed, yieldAmount, 10, "Total yield distributed should be equal to original yield");
        }

        // Now test the commence withdraw mechanism
        for (uint256 i = 0; i < numDepositors; i++) {
            address depositor = depositors[i];
            uint256 assetsToWithdraw = sRoyUSD.previewRedeem(sRoyUSD.balanceOf(depositors[i]));

            uint256 depositorRoyUSDBefore = IERC20(address(royUSD)).balanceOf(depositors[i]);
            uint256 depositorSharesBefore = sRoyUSD.balanceOf(depositors[i]);
            uint256 reserveRoyUSDBefore = IERC20(address(royUSD)).balanceOf(address(reserve));

            // Commence unstaking using the custom mechanism
            vm.prank(depositors[i]);
            uint256 sharesBurned = sRoyUSD.commenceAssetsUnstakingPeriod(assetsToWithdraw);

            // Verify unstaking state
            {
                (uint256 amountToUnstake, uint256 unstakeableAt) = sRoyUSD.stakerToUnstakingState(depositors[i]);
                assertEq(amountToUnstake, assetsToWithdraw, "Amount to unstake should match");
                assertGe(unstakeableAt, vm.getBlockTimestamp() + sRoyUSD.unstakingDuration(), "UnstakeableAt should be in the future");
            }

            // Verify RoyUSD was moved to reserve
            uint256 reserveRoyUSDAfter = IERC20(address(royUSD)).balanceOf(address(reserve));
            assertEq(reserveRoyUSDAfter - reserveRoyUSDBefore, assetsToWithdraw, "RoyUSD should be moved to reserve");

            // Wait for unstaking duration to pass
            skip(sRoyUSD.unstakingDuration());

            // Call unstake to complete the process
            vm.prank(depositors[i]);
            sRoyUSD.unstake(depositors[i]);

            uint256 depositorRoyUSDAfter = IERC20(address(royUSD)).balanceOf(depositor);
            uint256 depositorSharesAfter = sRoyUSD.balanceOf(depositor);
            uint256 reserveRoyUSDFinal = IERC20(address(royUSD)).balanceOf(address(reserve));

            // Verify unstaking state is cleared
            {
                (uint256 amountToUnstake, uint256 unstakeableAt) = sRoyUSD.stakerToUnstakingState(depositor);
                assertEq(amountToUnstake, 0, "Amount to unstake should be cleared");
                assertEq(unstakeableAt, 0, "UnstakeableAt should be cleared");
            }

            // Verify RoyUSD was returned to depositor
            assertEq(depositorRoyUSDAfter - depositorRoyUSDBefore, assetsToWithdraw, "RoyUSD should be returned to depositor");
            if (reserveRoyUSDFinal >= reserveRoyUSDAfter) {
                assertEq(reserveRoyUSDFinal - reserveRoyUSDAfter, assetsToWithdraw, "RoyUSD should be removed from reserve");
            }

            // Verify shares were burned (use the returned shares value)
            assertEq(depositorSharesBefore - depositorSharesAfter, sharesBurned, "Shares should be burned");
        }
    }

    function testFuzz_Withdraw_MultipleDepositors_ZeroUnstakingDuration(uint256 _seed) external {
        _seed = bound(_seed, 1, 1000);

        // Set unstaking duration to 0 to enable ERC4626 withdraw function
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.setUnstakingDuration(0); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_UNSTAKING_DURATION_DELAY);
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.setUnstakingDuration(0); // execute

        // Create depositors
        uint256 numDepositors = bound(_seed, 3, 10);
        address[] memory depositors = new address[](numDepositors);
        uint256[] memory stakeAmounts = new uint256[](numDepositors);

        // Setup depositor 0 (seed depositor - already has SEED_AMOUNT staked)
        depositors[0] = OWNER_ADDRESS;
        stakeAmounts[0] = SEED_AMOUNT;

        // Setup depositors with smaller, more predictable amounts
        for (uint256 i = 1; i < numDepositors; i++) {
            depositors[i] = makeAddr(string(abi.encodePacked("DEPOSITOR_", i)));

            // Generate different stake amounts
            uint256 baseAmount = bound(_seed * (i + 1), 10_000e18, 100_000e18);
            stakeAmounts[i] = baseAmount;

            // Mint RoyUSD to depositor
            vm.prank(MINTER_ADDRESS);
            teller.mint(stakeAmounts[i], address(mockUSDC), depositors[i]);

            // Stake the RoyUSD
            vm.startPrank(depositors[i]);
            IERC20(address(royUSD)).approve(address(sRoyUSD), stakeAmounts[i]);
            sRoyUSD.deposit(stakeAmounts[i], depositors[i]);
            vm.stopPrank();
        }

        // Calculate total staked amount
        uint256 totalStaked = 0;
        for (uint256 i = 0; i < numDepositors; i++) {
            totalStaked += stakeAmounts[i];
        }

        // Generate yield amount
        uint256 yieldAmount = bound(_seed, totalStaked / 10, totalStaked / 2);

        // Mint yield to YIELD_DISTRIBUTOR
        vm.prank(MINTER_ADDRESS);
        teller.mint(yieldAmount, address(mockUSDC), YIELD_DISTRIBUTOR_ADDRESS);

        // Record asset values before yield distribution
        uint256[] memory assetsBeforeYield = new uint256[](numDepositors);
        for (uint256 i = 0; i < numDepositors; i++) {
            uint256 shares = sRoyUSD.balanceOf(depositors[i]);
            assetsBeforeYield[i] = sRoyUSD.previewRedeem(shares);
        }

        // Distribute yield
        vm.startPrank(YIELD_DISTRIBUTOR_ADDRESS);
        IERC20(address(royUSD)).approve(address(sRoyUSD), yieldAmount);
        sRoyUSD.distributeYield(yieldAmount);
        vm.stopPrank();

        // Verify yield is vesting (not immediately available)
        assertEq(sRoyUSD.getUnvestedAssets(), yieldAmount, "All yield should be unvested initially");

        // Fast forward to end of vesting period
        skip(sRoyUSD.VESTING_DURATION());

        // Verify all yield is now vested
        assertEq(sRoyUSD.getUnvestedAssets(), 0, "All yield should be vested after duration");

        // Check that each depositor received yield proportional to their stake
        for (uint256 i = 0; i < numDepositors; i++) {
            uint256 shares = sRoyUSD.balanceOf(depositors[i]);
            uint256 assetsAfter = sRoyUSD.previewRedeem(shares);
            uint256 assetsBefore = assetsBeforeYield[i];
            uint256 actualYieldReceived = assetsAfter - assetsBefore;

            // Each depositor should receive some yield (at least 1 wei)
            assertGt(actualYieldReceived, 0, "Depositor should receive some yield");

            // Calculate expected yield based on proportional stake
            uint256 expectedYield = (yieldAmount * stakeAmounts[i]) / totalStaked;

            // The yield received should be close to the expected proportional amount
            assertApproxEqRel(actualYieldReceived, expectedYield, 0.005e18, "Depositor yield should be close to expected yield");
        }

        // Now test withdrawals using ERC4626 withdraw function
        for (uint256 i = 0; i < numDepositors; i++) {
            address depositor = depositors[i];
            uint256 shares = sRoyUSD.balanceOf(depositors[i]);
            uint256 assetsToWithdraw = sRoyUSD.previewRedeem(shares);

            // Withdraw a portion of the assets (10-90% based on seed)
            uint256 withdrawBps = bound(_seed * (i + 1), 1000, 9000); // 10-90%
            uint256 withdrawAmount = (assetsToWithdraw * withdrawBps) / 10_000;
            if (withdrawAmount == 0) withdrawAmount = 1; // Ensure non-zero withdrawal

            uint256 depositorRoyUSDBefore = IERC20(address(royUSD)).balanceOf(depositor);
            uint256 depositorSharesBefore = sRoyUSD.balanceOf(depositor);

            // Use ERC4626 withdraw function
            vm.prank(depositor);
            uint256 sharesBurned = sRoyUSD.withdraw(withdrawAmount, depositor, depositor);

            uint256 depositorRoyUSDAfter = IERC20(address(royUSD)).balanceOf(depositor);
            uint256 depositorSharesAfter = sRoyUSD.balanceOf(depositor);

            // Verify withdrawal worked correctly
            assertEq(depositorRoyUSDAfter - depositorRoyUSDBefore, withdrawAmount, "RoyUSD balance should increase by withdraw amount");
            assertEq(depositorSharesBefore - depositorSharesAfter, sharesBurned, "Shares should decrease by burned amount");

            // Allow for small rounding differences in ERC4626 share calculation
            uint256 expectedWithdrawAmount = sRoyUSD.previewRedeem(sharesBurned);
            assertApproxEqAbs(expectedWithdrawAmount, withdrawAmount, 10, "Burned shares should approximately equal withdraw amount");
        }

        // Verify that the ERC4626 withdraw function worked correctly
        // Each depositor should have successfully withdrawn some portion of their assets
        for (uint256 i = 0; i < numDepositors; i++) {
            uint256 remainingShares = sRoyUSD.balanceOf(depositors[i]);
            uint256 remainingAssets = sRoyUSD.previewRedeem(remainingShares);

            // Each depositor should have some remaining assets (not all withdrawn)
            assertGt(remainingAssets, 0, "Depositor should have some remaining assets");

            // Each depositor should have some remaining shares
            assertGt(remainingShares, 0, "Depositor should have some remaining shares");
        }
    }

    function test_RevertIf_VestingInProgress_OnDistributeYield() external {
        // First, distribute some yield
        uint256 yieldAmount = 1000e18;
        vm.prank(MINTER_ADDRESS);
        teller.mint(yieldAmount, address(mockUSDC), YIELD_DISTRIBUTOR_ADDRESS);

        vm.startPrank(YIELD_DISTRIBUTOR_ADDRESS);
        IERC20(address(royUSD)).approve(address(sRoyUSD), yieldAmount);
        sRoyUSD.distributeYield(yieldAmount);
        vm.stopPrank();

        // Try to distribute more yield while previous yield is still vesting
        uint256 moreYield = 500e18;
        vm.prank(MINTER_ADDRESS);
        teller.mint(moreYield, address(mockUSDC), YIELD_DISTRIBUTOR_ADDRESS);

        vm.startPrank(YIELD_DISTRIBUTOR_ADDRESS);
        IERC20(address(royUSD)).approve(address(sRoyUSD), moreYield);
        vm.expectRevert(StakedRoyUSD.VestingInProgress.selector);
        sRoyUSD.distributeYield(moreYield);
        vm.stopPrank();
    }

    function test_RevertIf_MustUnstakeAssets_OnCommenceUnstaking() external {
        // Mint and stake some RoyUSD
        uint256 stakeAmount = 1000e18;
        vm.prank(MINTER_ADDRESS);
        teller.mint(stakeAmount, address(mockUSDC), ALICE_ADDRESS);

        vm.startPrank(ALICE_ADDRESS);
        IERC20(address(royUSD)).approve(address(sRoyUSD), stakeAmount);
        sRoyUSD.deposit(stakeAmount, ALICE_ADDRESS);
        vm.stopPrank();

        // Commence unstaking
        uint256 unstakeAmount = 500e18;
        vm.prank(ALICE_ADDRESS);
        sRoyUSD.commenceAssetsUnstakingPeriod(unstakeAmount);

        // Wait for unstaking duration to pass
        skip(sRoyUSD.unstakingDuration());

        // Try to commence unstaking again before calling unstake()
        vm.prank(ALICE_ADDRESS);
        vm.expectRevert(StakedRoyUSD.MustUnstakeAssets.selector);
        sRoyUSD.commenceAssetsUnstakingPeriod(unstakeAmount);
    }

    function test_RevertIf_UnsupportedFunction_OnRenounceRoles() external {
        // Try to call renounceRoles which is disabled
        vm.prank(OWNER_ADDRESS);
        vm.expectRevert(StakedRoyUSD.UnsupportedFunction.selector);
        sRoyUSD.renounceRoles(0);
    }

    function test_RevertIf_UnsupportedFunction_OnERC4626Withdraw() external {
        // Mint and stake some RoyUSD
        uint256 stakeAmount = 1000e18;
        vm.prank(MINTER_ADDRESS);
        teller.mint(stakeAmount, address(mockUSDC), ALICE_ADDRESS);

        vm.startPrank(ALICE_ADDRESS);
        IERC20(address(royUSD)).approve(address(sRoyUSD), stakeAmount);
        sRoyUSD.deposit(stakeAmount, ALICE_ADDRESS);
        vm.stopPrank();

        // Try to use ERC4626 withdraw function (should revert because unstaking duration > 0)
        vm.prank(ALICE_ADDRESS);
        vm.expectRevert(StakedRoyUSD.UnsupportedFunction.selector);
        sRoyUSD.withdraw(100e18, ALICE_ADDRESS, ALICE_ADDRESS);
    }

    function test_RevertIf_UnsupportedFunction_OnERC4626Redeem() external {
        // Mint and stake some RoyUSD
        uint256 stakeAmount = 1000e18;
        vm.prank(MINTER_ADDRESS);
        teller.mint(stakeAmount, address(mockUSDC), ALICE_ADDRESS);

        vm.startPrank(ALICE_ADDRESS);
        IERC20(address(royUSD)).approve(address(sRoyUSD), stakeAmount);
        sRoyUSD.deposit(stakeAmount, ALICE_ADDRESS);
        vm.stopPrank();

        // Try to use ERC4626 redeem function (should revert because unstaking duration > 0)
        uint256 shares = sRoyUSD.balanceOf(ALICE_ADDRESS);
        vm.prank(ALICE_ADDRESS);
        vm.expectRevert(StakedRoyUSD.UnsupportedFunction.selector);
        sRoyUSD.redeem(shares / 2, ALICE_ADDRESS, ALICE_ADDRESS);
    }

    function test_SetUnstakingDuration_ByOwner() external {
        uint256 newDuration = 30 days;

        vm.prank(OWNER_ADDRESS);
        sRoyUSD.setUnstakingDuration(uint24(newDuration)); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_UNSTAKING_DURATION_DELAY);
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.setUnstakingDuration(uint24(newDuration)); // execute

        assertEq(sRoyUSD.unstakingDuration(), newDuration, "Unstaking duration should be updated");
    }

    function test_SetUnstakingDuration_ByStakingManager() external {
        uint256 newDuration = 45 days;

        vm.prank(STAKING_MANAGER_ADDRESS);
        sRoyUSD.setUnstakingDuration(uint24(newDuration)); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_UNSTAKING_DURATION_DELAY);
        vm.prank(STAKING_MANAGER_ADDRESS);
        sRoyUSD.setUnstakingDuration(uint24(newDuration)); // execute

        assertEq(sRoyUSD.unstakingDuration(), newDuration, "Unstaking duration should be updated");
    }

    function test_RevertIf_SetUnstakingDuration_ByUnauthorized() external {
        uint256 newDuration = 30 days;

        vm.prank(ALICE_ADDRESS);
        vm.expectRevert();
        sRoyUSD.setUnstakingDuration(uint24(newDuration));
    }

    function test_RevertIf_SetUnstakingDuration_ExceedsMax() external {
        uint256 newDuration = sRoyUSD.MAX_UNSTAKING_DURATION() + 1;

        vm.prank(OWNER_ADDRESS);
        sRoyUSD.setUnstakingDuration(uint24(newDuration)); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_UNSTAKING_DURATION_DELAY);
        vm.prank(OWNER_ADDRESS);
        vm.expectRevert(StakedRoyUSD.InvalidUnstakingDuration.selector);
        sRoyUSD.setUnstakingDuration(uint24(newDuration)); // execute
    }

    function test_SetUnstakingDuration_ToMaxAllowed() external {
        uint256 maxDuration = sRoyUSD.MAX_UNSTAKING_DURATION();

        vm.prank(OWNER_ADDRESS);
        sRoyUSD.setUnstakingDuration(uint24(maxDuration)); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_UNSTAKING_DURATION_DELAY);
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.setUnstakingDuration(uint24(maxDuration)); // execute

        assertEq(sRoyUSD.unstakingDuration(), maxDuration, "Unstaking duration should be set to max");
    }

    function test_SetUnstakingDuration_ToZero() external {
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.setUnstakingDuration(0); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_UNSTAKING_DURATION_DELAY);
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.setUnstakingDuration(0); // execute

        assertEq(sRoyUSD.unstakingDuration(), 0, "Unstaking duration should be set to zero");
    }

    function testFuzz_SetUnstakingDuration_ValidRange(uint256 _duration) external {
        _duration = bound(_duration, 0, sRoyUSD.MAX_UNSTAKING_DURATION());

        vm.prank(OWNER_ADDRESS);
        sRoyUSD.setUnstakingDuration(uint24(_duration)); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_UNSTAKING_DURATION_DELAY);
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.setUnstakingDuration(uint24(_duration)); // execute

        assertEq(sRoyUSD.unstakingDuration(), _duration, "Unstaking duration should be set correctly");
    }

    function test_BlacklistStaker_ByOwner() external {
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY);
        vm.prank(OWNER_ADDRESS);
        vm.expectEmit(true, false, false, true);
        emit StakedRoyUSD.BlacklistUpdated(ALICE_ADDRESS, true);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // execute

        assertTrue(sRoyUSD.hasAnyRole(ALICE_ADDRESS, RoycoRoles.BLACKLISTED_STAKER), "Alice should be blacklisted");
    }

    function test_BlacklistStaker_ByBlacklistManager() external {
        vm.prank(BLACKLIST_MANAGER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY);
        vm.prank(BLACKLIST_MANAGER_ADDRESS);
        vm.expectEmit(true, false, false, true);
        emit StakedRoyUSD.BlacklistUpdated(ALICE_ADDRESS, true);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // execute

        assertTrue(sRoyUSD.hasAnyRole(ALICE_ADDRESS, RoycoRoles.BLACKLISTED_STAKER), "Alice should be blacklisted");
    }

    function test_BlacklistStaker_ByStakingManager() external {
        vm.prank(STAKING_MANAGER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY);
        vm.prank(STAKING_MANAGER_ADDRESS);
        vm.expectEmit(true, false, false, true);
        emit StakedRoyUSD.BlacklistUpdated(ALICE_ADDRESS, true);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // execute

        assertTrue(sRoyUSD.hasAnyRole(ALICE_ADDRESS, RoycoRoles.BLACKLISTED_STAKER), "Alice should be blacklisted");
    }

    function test_RevertIf_BlacklistStaker_ByUnauthorized() external {
        vm.prank(ALICE_ADDRESS);
        vm.expectRevert();
        sRoyUSD.blacklistStaker(BOB_ADDRESS);
    }

    function test_WhitelistStaker_ByOwner() external {
        // First blacklist Alice
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // schedule
        uint256 executeAt = vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY;
        vm.warp(executeAt);
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // execute
        assertTrue(sRoyUSD.hasAnyRole(ALICE_ADDRESS, RoycoRoles.BLACKLISTED_STAKER), "Alice should be blacklisted");

        // Then whitelist Alice
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.whitelistStaker(ALICE_ADDRESS); // schedule
        executeAt = vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY;
        vm.warp(executeAt);
        vm.prank(OWNER_ADDRESS);
        vm.expectEmit(true, false, false, true);
        emit StakedRoyUSD.BlacklistUpdated(ALICE_ADDRESS, false);
        sRoyUSD.whitelistStaker(ALICE_ADDRESS); // execute

        assertFalse(sRoyUSD.hasAnyRole(ALICE_ADDRESS, RoycoRoles.BLACKLISTED_STAKER), "Alice should not be blacklisted");
    }

    function test_WhitelistStaker_ByBlacklistManager() external {
        // First blacklist Alice
        vm.prank(BLACKLIST_MANAGER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // schedule
        uint256 executeAt = vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY;
        vm.warp(executeAt);
        vm.prank(BLACKLIST_MANAGER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // execute

        // Then whitelist Alice
        vm.prank(BLACKLIST_MANAGER_ADDRESS);
        sRoyUSD.whitelistStaker(ALICE_ADDRESS); // schedule
        executeAt = vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY;
        vm.warp(executeAt);
        vm.prank(BLACKLIST_MANAGER_ADDRESS);
        vm.expectEmit(true, false, false, true);
        emit StakedRoyUSD.BlacklistUpdated(ALICE_ADDRESS, false);
        sRoyUSD.whitelistStaker(ALICE_ADDRESS); // execute

        assertFalse(sRoyUSD.hasAnyRole(ALICE_ADDRESS, RoycoRoles.BLACKLISTED_STAKER), "Alice should not be blacklisted");
    }

    function test_WhitelistStaker_ByStakingManager() external {
        // First blacklist Alice
        vm.prank(STAKING_MANAGER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // schedule
        uint256 executeAt = vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY;
        vm.warp(executeAt);
        vm.prank(STAKING_MANAGER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // execute

        // Then whitelist Alice
        vm.prank(STAKING_MANAGER_ADDRESS);
        sRoyUSD.whitelistStaker(ALICE_ADDRESS); // schedule
        executeAt = vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY;
        vm.warp(executeAt);
        vm.prank(STAKING_MANAGER_ADDRESS);
        vm.expectEmit(true, false, false, true);
        emit StakedRoyUSD.BlacklistUpdated(ALICE_ADDRESS, false);
        sRoyUSD.whitelistStaker(ALICE_ADDRESS); // execute

        assertFalse(sRoyUSD.hasAnyRole(ALICE_ADDRESS, RoycoRoles.BLACKLISTED_STAKER), "Alice should not be blacklisted");
    }

    function test_RevertIf_WhitelistStaker_ByUnauthorized() external {
        vm.prank(ALICE_ADDRESS);
        vm.expectRevert();
        sRoyUSD.whitelistStaker(BOB_ADDRESS);
    }

    function test_RevertIf_Blacklisted_Deposit() external {
        // Blacklist Alice
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY);
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // execute // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY);
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // execute

        // Mint RoyUSD to Alice
        uint256 amount = 1000e18;
        vm.prank(MINTER_ADDRESS);
        teller.mint(amount, address(mockUSDC), ALICE_ADDRESS);

        // Try to deposit (should revert)
        vm.startPrank(ALICE_ADDRESS);
        IERC20(address(royUSD)).approve(address(sRoyUSD), amount);
        vm.expectRevert(StakedRoyUSD.Blacklisted.selector);
        sRoyUSD.deposit(amount, ALICE_ADDRESS);
        vm.stopPrank();
    }

    function test_RevertIf_Blacklisted_Transfer() external {
        // Mint and stake some RoyUSD for Alice
        uint256 amount = 1000e18;
        vm.prank(MINTER_ADDRESS);
        teller.mint(amount, address(mockUSDC), ALICE_ADDRESS);

        vm.startPrank(ALICE_ADDRESS);
        IERC20(address(royUSD)).approve(address(sRoyUSD), amount);
        sRoyUSD.deposit(amount, ALICE_ADDRESS);
        vm.stopPrank();

        // Blacklist Alice
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY);
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // execute

        // Try to transfer (should revert)
        uint256 transferAmount = sRoyUSD.balanceOf(ALICE_ADDRESS) / 2;
        vm.prank(ALICE_ADDRESS);
        vm.expectRevert(StakedRoyUSD.Blacklisted.selector);
        sRoyUSD.transfer(BOB_ADDRESS, transferAmount);
    }

    function test_RevertIf_Blacklisted_CommenceUnstaking() external {
        // Mint and stake some RoyUSD for Alice
        uint256 amount = 1000e18;
        vm.prank(MINTER_ADDRESS);
        teller.mint(amount, address(mockUSDC), ALICE_ADDRESS);

        vm.startPrank(ALICE_ADDRESS);
        IERC20(address(royUSD)).approve(address(sRoyUSD), amount);
        sRoyUSD.deposit(amount, ALICE_ADDRESS);
        vm.stopPrank();

        // Blacklist Alice
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY);
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // execute

        // Try to commence unstaking (should revert)
        vm.prank(ALICE_ADDRESS);
        vm.expectRevert(StakedRoyUSD.Blacklisted.selector);
        sRoyUSD.commenceAssetsUnstakingPeriod(amount / 2);
    }

    function test_RevertIf_Blacklisted_Unstake() external {
        // Mint and stake some RoyUSD for Alice
        uint256 amount = 1000e18;
        vm.prank(MINTER_ADDRESS);
        teller.mint(amount, address(mockUSDC), ALICE_ADDRESS);

        vm.startPrank(ALICE_ADDRESS);
        IERC20(address(royUSD)).approve(address(sRoyUSD), amount);
        sRoyUSD.deposit(amount, ALICE_ADDRESS);
        vm.stopPrank();

        // Commence unstaking
        vm.prank(ALICE_ADDRESS);
        sRoyUSD.commenceAssetsUnstakingPeriod(amount / 2);

        // Wait for unstaking duration
        skip(sRoyUSD.unstakingDuration());

        // Blacklist Alice
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY);
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // execute

        // Try to unstake (should revert)
        vm.prank(ALICE_ADDRESS);
        vm.expectRevert(StakedRoyUSD.Blacklisted.selector);
        sRoyUSD.unstake(ALICE_ADDRESS);
    }

    function test_RevertIf_Blacklisted_ReceiveTransfer() external {
        // Mint and stake some RoyUSD for Alice
        uint256 amount = 1000e18;
        vm.prank(MINTER_ADDRESS);
        teller.mint(amount, address(mockUSDC), ALICE_ADDRESS);

        vm.startPrank(ALICE_ADDRESS);
        IERC20(address(royUSD)).approve(address(sRoyUSD), amount);
        sRoyUSD.deposit(amount, ALICE_ADDRESS);
        vm.stopPrank();

        // Blacklist Bob
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(BOB_ADDRESS); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY);
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(BOB_ADDRESS); // execute

        // Try to transfer to Bob (should revert)
        uint256 transferAmount = sRoyUSD.balanceOf(ALICE_ADDRESS) / 2;
        vm.prank(ALICE_ADDRESS);
        vm.expectRevert(StakedRoyUSD.Blacklisted.selector);
        sRoyUSD.transfer(BOB_ADDRESS, transferAmount);
    }

    function test_Blacklisted_CanBeWhitelisted_AndResumeOperations() external {
        // Mint and stake some RoyUSD for Alice
        uint256 amount = 1000e18;
        vm.prank(MINTER_ADDRESS);
        teller.mint(amount, address(mockUSDC), ALICE_ADDRESS);

        vm.startPrank(ALICE_ADDRESS);
        IERC20(address(royUSD)).approve(address(sRoyUSD), amount);
        sRoyUSD.deposit(amount, ALICE_ADDRESS);
        vm.stopPrank();

        // Blacklist Alice
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY);
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // execute

        // Verify Alice cannot transfer
        uint256 transferAmount = sRoyUSD.balanceOf(ALICE_ADDRESS) / 2;
        vm.prank(ALICE_ADDRESS);
        vm.expectRevert(StakedRoyUSD.Blacklisted.selector);
        sRoyUSD.transfer(BOB_ADDRESS, transferAmount);

        // Whitelist Alice
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.whitelistStaker(ALICE_ADDRESS); // schedule
        uint256 executeAt = vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY;
        vm.warp(executeAt);
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.whitelistStaker(ALICE_ADDRESS); // execute

        // Verify Alice can now transfer
        vm.prank(ALICE_ADDRESS);
        sRoyUSD.transfer(BOB_ADDRESS, transferAmount);

        assertEq(sRoyUSD.balanceOf(BOB_ADDRESS), transferAmount, "Bob should receive the transfer");
        assertEq(sRoyUSD.balanceOf(ALICE_ADDRESS), amount - transferAmount, "Alice should have remaining balance");
    }

    function test_Blacklisted_CannotRenounceRoles() external {
        // Blacklist Alice
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // schedule
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY);
        vm.prank(OWNER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS); // execute

        // Try to renounce roles (should revert with UnsupportedFunction)
        vm.prank(ALICE_ADDRESS);
        vm.expectRevert(StakedRoyUSD.UnsupportedFunction.selector);
        sRoyUSD.renounceRoles(0);
    }

    function testFuzz_BlacklistAndWhitelist_MultipleAddresses(uint256 _seed) external {
        _seed = bound(_seed, 1, 100);

        // Create multiple addresses to blacklist/whitelist
        address[] memory addresses = new address[](5);
        for (uint256 i = 0; i < 5; i++) {
            addresses[i] = makeAddr(string(abi.encodePacked("USER_", i)));
        }

        // Blacklist all addresses
        uint256 executeAt;
        for (uint256 i = 0; i < addresses.length; i++) {
            vm.prank(OWNER_ADDRESS);
            sRoyUSD.blacklistStaker(addresses[i]); // schedule
            executeAt = vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY;
            vm.warp(executeAt);
            vm.prank(OWNER_ADDRESS);
            sRoyUSD.blacklistStaker(addresses[i]); // execute
            assertTrue(sRoyUSD.hasAnyRole(addresses[i], RoycoRoles.BLACKLISTED_STAKER), "Address should be blacklisted");
        }

        // Whitelist all addresses
        for (uint256 i = 0; i < addresses.length; i++) {
            vm.prank(OWNER_ADDRESS);
            sRoyUSD.whitelistStaker(addresses[i]); // schedule
            executeAt = vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY;
            vm.warp(executeAt);
            vm.prank(OWNER_ADDRESS);
            sRoyUSD.whitelistStaker(addresses[i]); // execute
            assertFalse(sRoyUSD.hasAnyRole(addresses[i], RoycoRoles.BLACKLISTED_STAKER), "Address should not be blacklisted");
        }
    }

    function test_RevertIf_SetUnstakingDuration_CalledBeforeDelay() external {
        uint24 newDuration = 1 days;

        // Schedule the operation
        vm.prank(STAKING_MANAGER_ADDRESS);
        sRoyUSD.setUnstakingDuration(newDuration);

        // Try to execute immediately (should revert)
        vm.prank(STAKING_MANAGER_ADDRESS);
        vm.expectRevert();
        sRoyUSD.setUnstakingDuration(newDuration);
    }

    function test_RevertIf_BlacklistStaker_CalledBeforeDelay() external {
        // Schedule the operation
        vm.prank(BLACKLIST_MANAGER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS);

        // Try to execute immediately (should revert)
        vm.prank(BLACKLIST_MANAGER_ADDRESS);
        vm.expectRevert();
        sRoyUSD.blacklistStaker(ALICE_ADDRESS);
    }

    function test_RevertIf_WhitelistStaker_CalledBeforeDelay() external {
        // First blacklist Alice
        vm.prank(BLACKLIST_MANAGER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS);
        vm.warp(vm.getBlockTimestamp() + SROYUSD_SET_WHITELIST_DELAY);
        vm.prank(BLACKLIST_MANAGER_ADDRESS);
        sRoyUSD.blacklistStaker(ALICE_ADDRESS);

        // Schedule whitelist operation
        vm.prank(BLACKLIST_MANAGER_ADDRESS);
        sRoyUSD.whitelistStaker(ALICE_ADDRESS);

        // Try to execute immediately (should revert)
        vm.prank(BLACKLIST_MANAGER_ADDRESS);
        vm.expectRevert();
        sRoyUSD.whitelistStaker(ALICE_ADDRESS);
    }
}
