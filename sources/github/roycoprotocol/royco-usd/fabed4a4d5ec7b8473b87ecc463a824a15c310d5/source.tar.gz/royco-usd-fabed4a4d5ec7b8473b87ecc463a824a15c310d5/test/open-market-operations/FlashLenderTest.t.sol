// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { IERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol";
import { RoycoAuth } from "../../src/auth/RoycoAuth.sol";
import { MockERC20 } from "../utils/MockERC20.sol";
import { MockFlashBorrower } from "../utils/MockFlashBorrower.sol";
import { RoycoFlashLender, RoycoRoles, RoycoTestBase } from "../utils/RoycoTestBase.sol";

contract FlashLenderTest is RoycoTestBase {
    MockFlashBorrower internal borrower;

    function setUp() external {
        _setUpRoyco();
        borrower = new MockFlashBorrower();

        // Reset borrower state for each test
        borrower.setFailCallbackOnLoan(false);
        borrower.setFailPrincipalRepaymentOnLoan(false);
        borrower.setFailFeeRepaymentOnLoan(false);
    }

    function test_Deployment() external view {
        assertEq(flashLender.owner(), OWNER_ADDRESS);
        assertTrue(flashLender.hasAllRoles(OPEN_MARKET_DESK_ADDRESS, RoycoRoles.OPEN_MARKET_DESK));
        assertEq(flashLender.treasury(), TREASURY_ADDRESS);
        (uint240 maxLoanAmount, uint16 feeBPS) = flashLender.assetToLoanConfig(address(royUSD));
        assertEq(maxLoanAmount, type(uint240).max);
        assertEq(feeBPS, 0);
        address[] memory collateralAssets = teller.getCollateralAssets();
        for (uint256 i = 0; i < collateralAssets.length; ++i) {
            (maxLoanAmount, feeBPS) = flashLender.assetToLoanConfig(collateralAssets[i]);
            assertEq(maxLoanAmount, type(uint240).max);
            assertEq(feeBPS, 0);
        }
    }

    function testFuzz_MaxFlashLoanAmount(uint256 _collateralIndex, uint232 _reserveAmount) external {
        address collateralAsset = collateralAssets[_collateralIndex % collateralAssets.length];
        MockERC20(collateralAsset).mint(address(reserve), _reserveAmount);
        assertEq(MockERC20(collateralAsset).balanceOf(address(reserve)), flashLender.maxFlashLoan(collateralAsset));
    }

    function testFuzz_MaxFlashMintAmount(uint256 _supplyCap) external {
        uint256 royUSDSupply = royUSD.totalSupply();
        _supplyCap = bound(_supplyCap, royUSDSupply, type(uint256).max);

        vm.prank(OWNER_ADDRESS);
        royUSD.setMaxSupply(_supplyCap);

        uint256 maxMintable = _supplyCap - royUSDSupply;
        assertEq(maxMintable > type(uint240).max ? type(uint240).max : maxMintable, flashLender.maxFlashLoan(address(royUSD)));
    }

    function testFuzz_FlashLoanFee(uint256 _collateralIndex, uint240 _loanCap, uint16 _feeBPS) external {
        address collateralAsset = collateralAssets[_collateralIndex % collateralAssets.length];

        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(collateralAsset, _loanCap, _feeBPS); // schedule
        vm.warp(vm.getBlockTimestamp() + LENDER_UPDATE_CONFIG_DELAY);
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(collateralAsset, _loanCap, _feeBPS); // execute

        uint256 loanAmount = bound(_loanCap, 0, _loanCap);
        uint256 feeToBePaid = flashLender.flashFee(collateralAsset, loanAmount);
        assertEq(feeToBePaid, (loanAmount * _feeBPS) / 10_000);
    }

    function testFuzz_FlashMintFee(uint240 _loanCap, uint16 _feeBPS) external {
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(address(royUSD), _loanCap, _feeBPS); // schedule
        vm.warp(vm.getBlockTimestamp() + LENDER_UPDATE_CONFIG_DELAY);
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(address(royUSD), _loanCap, _feeBPS); // execute

        uint256 loanAmount = bound(_loanCap, 0, _loanCap);
        uint256 feeToBePaid = flashLender.flashFee(address(royUSD), loanAmount);
        assertEq(feeToBePaid, (loanAmount * _feeBPS) / 10_000);
    }

    function testFuzz_FlashLoan(uint256 _collateralIndex, uint240 _reserveAmount, uint256 _loanAmount, uint256 _feeBPS) external {
        address collateralAsset = collateralAssets[_collateralIndex % collateralAssets.length];
        _reserveAmount = uint240(bound(uint256(_reserveAmount), 1e6, uint256(type(uint240).max)));
        MockERC20(collateralAsset).mint(address(reserve), _reserveAmount);
        _loanAmount = bound(_loanAmount, 1e6, flashLender.maxFlashLoan(collateralAsset));
        _feeBPS = bound(_feeBPS, 0, 1000);

        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(collateralAsset, type(uint240).max, uint16(_feeBPS)); // schedule
        vm.warp(vm.getBlockTimestamp() + LENDER_UPDATE_CONFIG_DELAY);
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(collateralAsset, type(uint240).max, uint16(_feeBPS)); // execute

        uint256 feeToBePaid = flashLender.flashFee(collateralAsset, _loanAmount);
        assertEq(feeToBePaid, (_loanAmount * _feeBPS) / 10_000);

        uint256 preLoanReserveBalance = MockERC20(collateralAsset).balanceOf(address(reserve));

        vm.expectEmit(true, true, true, true, collateralAsset);
        emit IERC20.Transfer(address(borrower), address(reserve), _loanAmount);
        if (feeToBePaid > 0) {
            vm.expectEmit(true, true, true, true, collateralAsset);
            emit IERC20.Transfer(address(borrower), TREASURY_ADDRESS, feeToBePaid);
        }
        vm.expectEmit(true, true, true, true);
        emit RoycoFlashLender.FlashLoan(address(this), address(borrower), collateralAsset, _loanAmount, feeToBePaid);

        flashLender.flashLoan(borrower, collateralAsset, _loanAmount, new bytes(0));
        assertEq(MockERC20(collateralAsset).balanceOf(address(reserve)), preLoanReserveBalance);
        assertEq(MockERC20(collateralAsset).balanceOf(TREASURY_ADDRESS), feeToBePaid);
    }

    function testFuzz_FlashMint(uint256 _supplyCap, uint256 _loanAmount, uint256 _feeBPS) external {
        uint256 preLoanRoyUSDSupply = royUSD.totalSupply();
        _supplyCap = bound(_supplyCap, preLoanRoyUSDSupply, type(uint256).max);
        _feeBPS = bound(_feeBPS, 0, 1000);

        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(address(royUSD), type(uint240).max, uint16(_feeBPS)); // schedule
        vm.warp(vm.getBlockTimestamp() + LENDER_UPDATE_CONFIG_DELAY);
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(address(royUSD), type(uint240).max, uint16(_feeBPS)); // execute

        vm.prank(OWNER_ADDRESS);
        royUSD.setMaxSupply(_supplyCap);

        _loanAmount = bound(_loanAmount, 0, flashLender.maxFlashLoan(address(royUSD)) / 2);

        uint256 feeToBePaid = flashLender.flashFee(address(royUSD), _loanAmount);
        assertEq(feeToBePaid, (_loanAmount * _feeBPS) / 10_000);

        // Allow the borrower to mint the fee
        vm.prank(OWNER_ADDRESS);
        royUSD.grantRoles(address(borrower), RoycoRoles.TELLER);

        vm.expectEmit(true, true, true, true, address(royUSD));
        emit IERC20.Transfer(address(borrower), address(0), _loanAmount);
        if (feeToBePaid > 0) {
            vm.expectEmit(true, true, true, true, address(royUSD));
            emit IERC20.Transfer(address(borrower), TREASURY_ADDRESS, feeToBePaid);
        }
        vm.expectEmit(true, true, true, true);
        emit RoycoFlashLender.FlashLoan(address(this), address(borrower), address(royUSD), _loanAmount, feeToBePaid);

        flashLender.flashLoan(borrower, address(royUSD), _loanAmount, new bytes(0));
        assertEq(royUSD.totalSupply(), preLoanRoyUSDSupply + feeToBePaid);
        assertEq(royUSD.balanceOf(TREASURY_ADDRESS), feeToBePaid);
        assertEq(royUSD.balanceOf(address(borrower)), 0);
    }

    function testFuzz_SetFlashLoanConfig(uint256 _assetIndex, uint240 _maxLoanAmount, uint16 _feeBPS) external {
        address asset;
        if (_assetIndex % 2 == 0) {
            asset = address(royUSD);
        } else {
            asset = collateralAssets[_assetIndex % collateralAssets.length];
        }

        // Schedule phase - expect OperationScheduled event
        vm.expectEmit(true, true, true, true);
        emit RoycoAuth.OperationScheduled(
            RoycoFlashLender.setFlashLoanConfig.selector,
            keccak256(abi.encodeWithSelector(RoycoFlashLender.setFlashLoanConfig.selector, asset, _maxLoanAmount, _feeBPS)),
            OPEN_MARKET_DESK_ADDRESS,
            vm.getBlockTimestamp() + LENDER_UPDATE_CONFIG_DELAY
        );

        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(asset, _maxLoanAmount, _feeBPS); // schedule

        vm.warp(vm.getBlockTimestamp() + LENDER_UPDATE_CONFIG_DELAY);

        // Execute phase - expect FlashLoanConfigSet event
        vm.expectEmit(true, true, true, true);
        emit RoycoFlashLender.FlashLoanConfigSet(asset, _maxLoanAmount, _feeBPS);

        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(asset, _maxLoanAmount, _feeBPS); // execute

        (uint240 storedMaxLoanAmount, uint16 storedFeeBPS) = flashLender.assetToLoanConfig(asset);
        assertEq(storedMaxLoanAmount, _maxLoanAmount);
        assertEq(storedFeeBPS, _feeBPS);
    }

    function testFuzz_SetFlashLoanConfigs(uint8 _numAssets, uint240 _maxLoanAmount, uint16 _feeBPS) external {
        _numAssets = uint8(bound(_numAssets, 1, 5));

        address[] memory assets = new address[](_numAssets);
        uint240[] memory maxLoanAmounts = new uint240[](_numAssets);
        uint16[] memory feeBPSArray = new uint16[](_numAssets);

        for (uint256 i = 0; i < _numAssets; i++) {
            if (i == 0) {
                assets[i] = address(royUSD);
            } else {
                assets[i] = collateralAssets[(i - 1) % collateralAssets.length];
            }
            maxLoanAmounts[i] = _maxLoanAmount;
            feeBPSArray[i] = _feeBPS;
        }

        // Schedule phase - expect OperationScheduled event
        vm.expectEmit(true, true, true, true);
        emit RoycoAuth.OperationScheduled(
            RoycoFlashLender.setFlashLoanConfigs.selector,
            keccak256(abi.encodeWithSelector(RoycoFlashLender.setFlashLoanConfigs.selector, assets, maxLoanAmounts, feeBPSArray)),
            OPEN_MARKET_DESK_ADDRESS,
            vm.getBlockTimestamp() + LENDER_UPDATE_CONFIG_DELAY
        );

        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfigs(assets, maxLoanAmounts, feeBPSArray); // schedule

        vm.warp(vm.getBlockTimestamp() + LENDER_UPDATE_CONFIG_DELAY);

        // Execute phase - expect FlashLoanConfigSet events for each asset
        for (uint256 i = 0; i < _numAssets; i++) {
            vm.expectEmit(true, true, true, true);
            emit RoycoFlashLender.FlashLoanConfigSet(assets[i], _maxLoanAmount, _feeBPS);
        }

        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfigs(assets, maxLoanAmounts, feeBPSArray); // execute

        for (uint256 i = 0; i < _numAssets; i++) {
            (uint240 storedMaxLoanAmount, uint16 storedFeeBPS) = flashLender.assetToLoanConfig(assets[i]);
            assertEq(storedMaxLoanAmount, _maxLoanAmount);
            assertEq(storedFeeBPS, _feeBPS);
        }
    }

    function testFuzz_SetTreasury(address _newTreasury) external {
        vm.assume(_newTreasury != address(0));

        // Schedule phase - expect OperationScheduled event
        vm.expectEmit(true, true, true, true);
        emit RoycoAuth.OperationScheduled(
            RoycoFlashLender.setTreasury.selector,
            keccak256(abi.encodeWithSelector(RoycoFlashLender.setTreasury.selector, _newTreasury)),
            OPEN_MARKET_DESK_ADDRESS,
            vm.getBlockTimestamp() + LENDER_SET_TREASURY_DELAY
        );

        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setTreasury(_newTreasury); // schedule

        vm.warp(vm.getBlockTimestamp() + LENDER_SET_TREASURY_DELAY);

        // Execute phase - expect TreasurySet event
        vm.expectEmit(true, true, true, true);
        emit RoycoFlashLender.TreasurySet(_newTreasury);

        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setTreasury(_newTreasury); // execute

        assertEq(flashLender.treasury(), _newTreasury);
    }

    function testFuzz_RevertIf_LoanCallbackFails(uint256 _loanAmount) external {
        address collateralAsset = collateralAssets[0];
        MockERC20(collateralAsset).mint(address(reserve), type(uint128).max);
        _loanAmount = bound(_loanAmount, 1, flashLender.maxFlashLoan(collateralAsset));

        borrower.setFailCallbackOnLoan(true);

        vm.expectRevert(RoycoFlashLender.FlashLoanCallbackFailed.selector);
        flashLender.flashLoan(borrower, collateralAsset, _loanAmount, new bytes(0));
    }

    function testFuzz_RevertIf_MintCallbackFails(uint256 _loanAmount) external {
        _loanAmount = bound(_loanAmount, 1, flashLender.maxFlashLoan(address(royUSD)) / 2);

        // Allow the borrower to mint the fee
        vm.prank(OWNER_ADDRESS);
        royUSD.grantRoles(address(borrower), RoycoRoles.TELLER);

        borrower.setFailCallbackOnLoan(true);

        vm.expectRevert(RoycoFlashLender.FlashLoanCallbackFailed.selector);
        flashLender.flashLoan(borrower, address(royUSD), _loanAmount, new bytes(0));
    }

    function testFuzz_RevertIf_ExceedsMaxLoanAmount(uint256 _loanAmount) external {
        address collateralAsset = collateralAssets[0];
        uint256 maxLoan = flashLender.maxFlashLoan(collateralAsset);
        _loanAmount = bound(_loanAmount, maxLoan + 1, type(uint256).max);

        vm.expectRevert(RoycoFlashLender.MaxLoanAmountExceeded.selector);
        flashLender.flashLoan(borrower, collateralAsset, _loanAmount, new bytes(0));
    }

    function testFuzz_RevertIf_ExceedsMaxMintAmount(uint256 _loanAmount) external {
        uint256 maxMint = flashLender.maxFlashLoan(address(royUSD));
        _loanAmount = bound(_loanAmount, maxMint + 1, type(uint256).max);

        vm.expectRevert(RoycoFlashLender.MaxLoanAmountExceeded.selector);
        flashLender.flashLoan(borrower, address(royUSD), _loanAmount, new bytes(0));
    }

    function testFuzz_RevertIf_InsufficientPrincipalRepayment(uint256 _loanAmount) external {
        address collateralAsset = collateralAssets[0];
        MockERC20(collateralAsset).mint(address(reserve), type(uint128).max);
        _loanAmount = bound(_loanAmount, 1, flashLender.maxFlashLoan(collateralAsset));

        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(collateralAsset, type(uint240).max, 100); // schedule
        vm.warp(vm.getBlockTimestamp() + LENDER_UPDATE_CONFIG_DELAY);
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(collateralAsset, type(uint240).max, 100); // execute

        borrower.setFailPrincipalRepaymentOnLoan(true);

        vm.expectRevert();
        flashLender.flashLoan(borrower, collateralAsset, _loanAmount, new bytes(0));
    }

    function testFuzz_RevertIf_InsufficientFeeRepayment(uint256 _loanAmount) external {
        address collateralAsset = collateralAssets[0];
        MockERC20(collateralAsset).mint(address(reserve), type(uint128).max);
        _loanAmount = bound(_loanAmount, 100, flashLender.maxFlashLoan(collateralAsset)); // Ensure min loan to generate fee

        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(collateralAsset, type(uint240).max, 100); // schedule
        vm.warp(vm.getBlockTimestamp() + LENDER_UPDATE_CONFIG_DELAY);
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(collateralAsset, type(uint240).max, 100); // execute

        borrower.setFailFeeRepaymentOnLoan(true);

        vm.expectRevert();
        flashLender.flashLoan(borrower, collateralAsset, _loanAmount, new bytes(0));
    }

    function testFuzz_RevertIf_InsufficientRoyUSDRepayment(uint256 _loanAmount) external {
        _loanAmount = bound(_loanAmount, 1, flashLender.maxFlashLoan(address(royUSD)) / 2);

        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(address(royUSD), type(uint240).max, 100); // schedule
        vm.warp(vm.getBlockTimestamp() + LENDER_UPDATE_CONFIG_DELAY);
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(address(royUSD), type(uint240).max, 100); // execute

        // Grant roles to the borrower
        vm.prank(OWNER_ADDRESS);
        royUSD.grantRoles(address(borrower), RoycoRoles.TELLER);

        borrower.setFailPrincipalRepaymentOnLoan(true);

        vm.expectRevert();
        flashLender.flashLoan(borrower, address(royUSD), _loanAmount, new bytes(0));
    }

    function testFuzz_RevertIf_InsufficientRoyUSDFeeRepayment(uint256 _loanAmount) external {
        _loanAmount = bound(_loanAmount, 100, flashLender.maxFlashLoan(address(royUSD)) / 2); // Ensure min loan to generate fee

        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(address(royUSD), type(uint240).max, 100); // schedule
        vm.warp(vm.getBlockTimestamp() + LENDER_UPDATE_CONFIG_DELAY);
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(address(royUSD), type(uint240).max, 100); // execute

        // Grant roles to the borrower
        vm.prank(OWNER_ADDRESS);
        royUSD.grantRoles(address(borrower), RoycoRoles.TELLER);

        borrower.setFailFeeRepaymentOnLoan(true);

        vm.expectRevert();
        flashLender.flashLoan(borrower, address(royUSD), _loanAmount, new bytes(0));
    }

    function test_RevertIf_SetFlashLoanConfig_CalledBeforeDelay() external {
        // Schedule the operation
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfig(address(mockUSDC), 1000e6, 50);

        // Try to execute immediately (should revert)
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        vm.expectRevert();
        flashLender.setFlashLoanConfig(address(mockUSDC), 1000e6, 50);
    }

    function test_RevertIf_SetFlashLoanConfigs_CalledBeforeDelay() external {
        address[] memory assets = new address[](1);
        assets[0] = address(mockUSDC);
        uint240[] memory maxLoanAmounts = new uint240[](1);
        maxLoanAmounts[0] = 1000e6;
        uint16[] memory feeBPS = new uint16[](1);
        feeBPS[0] = 50;

        // Schedule the operation
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setFlashLoanConfigs(assets, maxLoanAmounts, feeBPS);

        // Try to execute immediately (should revert)
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        vm.expectRevert();
        flashLender.setFlashLoanConfigs(assets, maxLoanAmounts, feeBPS);
    }

    function test_RevertIf_SetTreasury_CalledBeforeDelay() external {
        address newTreasury = makeAddr("newTreasury");

        // Schedule the operation
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        flashLender.setTreasury(newTreasury);

        // Try to execute immediately (should revert)
        vm.prank(OPEN_MARKET_DESK_ADDRESS);
        vm.expectRevert();
        flashLender.setTreasury(newTreasury);
    }
}
