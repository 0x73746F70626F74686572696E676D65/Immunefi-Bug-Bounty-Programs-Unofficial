// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { RateLimiter } from "../../lib/devtools/packages/oapp-evm/contracts/oapp/utils/RateLimiter.sol";
import { OFTAdapter } from "../../lib/devtools/packages/oft-evm/contracts/OFTAdapter.sol";
import { OFTCore } from "../../lib/devtools/packages/oft-evm/contracts/OFTCore.sol";
import { Ownable } from "../../lib/openzeppelin-contracts/contracts/access/Ownable.sol";
import { Pausable } from "../../lib/openzeppelin-contracts/contracts/utils/Pausable.sol";
import { RoycoOFTBase } from "./RoycoOFTBase.sol";

/// @notice OFTAdapter uses a deployed ERC-20 token and SafeERC20 to interact with the OFTCore contract.
/// @dev Bootstrapped from https://docs.layerzero.network/v2/developers/evm/oft/quickstart
contract RoycoOFTAdapter is OFTAdapter, RateLimiter, Pausable, RoycoOFTBase {
    /// @notice Initializes the RoycoOFTAdapter contract
    /// @param _token The address of the underlying ERC20 token
    /// @param _lzEndpoint The LayerZero endpoint address
    /// @param _owner The owner of the contract
    /// @param _rateLimitConfigs The rate limit configurations for the OFTAdapter across various destination endpoints
    /// @param _oftSetupConfig The configuration for the OFT setup
    constructor(
        address _token,
        address _lzEndpoint,
        address _owner,
        RateLimitConfig[] memory _rateLimitConfigs,
        OFTSetupConfig memory _oftSetupConfig
    )
        OFTAdapter(_token, _lzEndpoint, _owner)
        Ownable(_owner)
        RoycoOFTBase(_lzEndpoint, _oftSetupConfig)
    {
        _setRateLimits(_rateLimitConfigs);
    }

    /// @notice Sets the rate limits for the OFTAdapter
    /// @param _rateLimitConfigs The rate limit configurations
    function setRateLimits(RateLimitConfig[] memory _rateLimitConfigs) external onlyOwner {
        _setRateLimits(_rateLimitConfigs);
    }

    /// @dev Override _debit to enforce rate limits on token transfers and pausability
    /// @inheritdoc OFTAdapter
    function _debit(
        address _from,
        uint256 _amountLD,
        uint256 _minAmountLD,
        uint32 _dstEid
    )
        internal
        override(OFTAdapter, OFTCore)
        whenNotPaused
        returns (uint256 amountSentLD, uint256 amountReceivedLD)
    {
        // Check rate limit before allowing the transfer
        _outflow(_dstEid, _amountLD);

        return super._debit(_from, _amountLD, _minAmountLD, _dstEid);
    }

    /// @notice Pauses the OFTAdapter
    /// @dev Only the owner can pause the OFTAdapter
    function pause() external onlyOwner {
        _pause();
    }

    /// @notice Unpauses the OFTAdapter
    /// @dev Only the owner can unpause the OFTAdapter
    function unpause() external onlyOwner {
        _unpause();
    }
}
