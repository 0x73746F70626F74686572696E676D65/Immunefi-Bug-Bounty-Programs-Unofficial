// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { Ownable, OwnableRoles } from "../../lib/solady/src/auth/OwnableRoles.sol";
import { RoycoRoles } from "./RoycoRoles.sol";

/**
 * @title RoycoAuth
 * @notice Extended OwnableRoles contract with unrenounceable ownership
 * @dev Inherits from Solady's OwnableRoles and prevents ownership renunciation.
 *      Role constants are defined in the RoycoRoles library for modular access.
 */
abstract contract RoycoAuth is OwnableRoles {
    /**
     * @notice Struct to store the scheduled operation
     * @custom:field calldataHash The calldata hash of the operation
     * @custom:field executeAt The timestamp at which the operation can be executed
     */
    struct ScheduledOperation {
        bytes32 calldataHash;
        uint256 executeAt;
    }

    /// @notice Mapping of function selectors to their execution delays in seconds
    mapping(bytes4 selector => uint256 delay) public executionDelay;

    /// @notice Mapping of function selectors to their scheduled operations
    mapping(bytes4 selector => ScheduledOperation operation) public scheduledOperations;

    /**
     * @notice Emitted when an operation is scheduled
     * @param selector The function selector of the operation
     * @param calldataHash The hash of the operation's calldata
     * @param scheduler The address that scheduled the operation
     * @param executeAt The timestamp when the operation can be executed
     */
    event OperationScheduled(bytes4 indexed selector, bytes32 indexed calldataHash, address indexed scheduler, uint256 executeAt);

    /**
     * @notice Emitted when the execution delay is updated for a function
     * @param selector The function selector
     * @param delay The new execution delay in seconds
     */
    event ExecutionDelayUpdated(bytes4 indexed selector, uint256 delay);

    /**
     * @notice Emitted when an operation is canceled
     * @param selector The function selector of the canceled operation
     * @param canceler The address that canceled the operation
     */
    event OperationCanceled(bytes4 indexed selector, address indexed canceler);

    /**
     * @notice Emitted when the execution delay is updated for multiple functions
     * @param selectors Array of function selectors
     * @param delays Array of new execution delays in seconds
     */
    event ExecutionDelayUpdated(bytes4[] indexed selectors, uint256[] indexed delays);

    /// @notice Error thrown when the owner attempts to renounce ownership
    error CannotRenounceOwnership();

    /// @notice Error thrown when no delay is set for a function
    error NoDelaySetForFunction();

    /**
     * @notice Error thrown when the operation is not ready
     * @param currentTimestamp The current block timestamp
     * @param executeAt The timestamp when the operation can be executed
     */
    error OperationNotReady(uint256 currentTimestamp, uint256 executeAt);

    /**
     * @notice Error thrown when the calldata hash is invalid
     * @param expectedHash The expected calldata hash
     * @param actualHash The actual calldata hash provided
     */
    error InvalidCalldataHash(bytes32 expectedHash, bytes32 actualHash);

    /**
     * @notice Error thrown when the operation is not scheduled
     * @param selector The function selector of the operation
     */
    error OperationNotScheduled(bytes4 selector);

    /**
     * @notice Error thrown when the execution delay is not set for a function
     * @param selector The function selector
     */
    error ExecutionDelayNotSetForFunction(bytes4 selector);

    /**
     * @notice Error thrown when the execution delay length mismatch
     * @param selectorsLength The length of the selectors array
     * @param delaysLength The length of the delays array
     */
    error ExecutionDelayLengthMismatch(uint256 selectorsLength, uint256 delaysLength);

    /**
     * @notice Initializes the authentication base for Royco contracts
     * @param _owner The administator responsible for granting and revoking authorizations for restricted functions
     */
    constructor(address _owner) {
        // Initialize the owner
        require(_owner != address(0), NewOwnerIsZeroAddress());
        _initializeOwner(_owner);
    }

    /**
     * @notice Modifier to check if the caller is the owner or has a role with a delay set
     * @param role The role to check
     * @dev If an operation has not been scheduled, it will be scheduled with the delay set for the function
     * @dev If an operation has been scheduled, it will be executed if the calldata hash is the same and the operation is ready
     */
    modifier onlyOwnerOrRolesWithDelay(uint256 role) {
        // Inherit from the OwnableRoles contract
        _checkOwnerOrRoles(role);

        // Check if the function has a delay set
        uint256 delay = executionDelay[msg.sig];
        require(delay > 0, NoDelaySetForFunction());

        ScheduledOperation storage operation = scheduledOperations[msg.sig];
        bytes32 calldataHash = keccak256(msg.data);

        if (operation.executeAt == 0) {
            // If the operation has not been scheduled, schedule it with the delay set for the function
            uint256 executeAt = block.timestamp + delay;
            operation.executeAt = executeAt;
            operation.calldataHash = calldataHash;
            emit OperationScheduled(msg.sig, calldataHash, msg.sender, executeAt);
        } else {
            // If the operation has been scheduled, execute it if the calldata hash is the same and the operation is ready
            require(block.timestamp >= operation.executeAt, OperationNotReady(block.timestamp, operation.executeAt));
            require(operation.calldataHash == calldataHash, InvalidCalldataHash(operation.calldataHash, calldataHash));
            // Return the control flow to the caller
            _;
            delete scheduledOperations[msg.sig];
        }
    }

    /**
     * @notice Updates the execution delay for a function
     * @param selectors The selectors of the functions to update the delay for
     * @param delays The new delays for the functions
     */
    function updateExecutionDelay(bytes4[] calldata selectors, uint256[] calldata delays) external onlyRoles(RoycoRoles.SCHEDULER_MANAGER) {
        require(selectors.length == delays.length, ExecutionDelayLengthMismatch(selectors.length, delays.length));
        for (uint256 i = 0; i < selectors.length; i++) {
            _updateExecutionDelay(selectors[i], delays[i]);
        }
    }

    /**
     * @notice Cancels a scheduled operation
     * @param selector The selector of the operation to cancel
     */
    function cancelScheduledOperation(bytes4 selector) external onlyRoles(RoycoRoles.SCHEDULER_MANAGER) {
        ScheduledOperation storage operation = scheduledOperations[selector];
        require(operation.executeAt > 0, OperationNotScheduled(selector));
        delete scheduledOperations[selector];
        emit OperationCanceled(selector, msg.sender);
    }

    /// @dev Ownership is not renouncable
    function renounceOwnership() public payable override onlyOwner {
        revert CannotRenounceOwnership();
    }

    /**
     * @notice Internal function to update the execution delay for a specific function selector
     * @param selector The function selector to update the delay for
     * @param delay The new delay in seconds before the function can be executed
     */
    function _updateExecutionDelay(bytes4 selector, uint256 delay) internal {
        executionDelay[selector] = delay;
        emit ExecutionDelayUpdated(selector, delay);
    }

    /**
     * @inheritdoc Ownable
     * @dev Prevents double-initialization.
     */
    function _guardInitializeOwner() internal pure override returns (bool) {
        return true;
    }
}
