// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { CREATE3 } from "lib/solady/src/utils/CREATE3.sol";

contract Create3Factory {
    error DeploymentFailed(bytes data);

    function deploy(bytes memory _creationCode, bytes32 _salt) public returns (address) {
        address addr = CREATE3.deployDeterministic(_creationCode, _salt);
        require(addr != address(0), DeploymentFailed(abi.encodePacked(_creationCode, _salt)));

        return addr;
    }

    function predictDeterministicAddress(bytes32 _salt) public view returns (address) {
        return CREATE3.predictDeterministicAddress(_salt, address(this));
    }
}
