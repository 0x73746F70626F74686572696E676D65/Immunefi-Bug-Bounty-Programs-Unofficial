// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { IDefaultInterestRateStrategy } from "../../../../lib/aave-v3-core/contracts/interfaces/IDefaultInterestRateStrategy.sol";
import { IPool as IAaveV3Pool } from "../../../../lib/aave-v3-core/contracts/interfaces/IPool.sol";
import { DataTypes } from "../../../../lib/aave-v3-core/contracts/protocol/libraries/types/DataTypes.sol";
import { IERC20 } from "../../../lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol";
import { Math } from "../../../lib/openzeppelin-contracts/contracts/utils/math/Math.sol";
import { RoycoAuth, RoycoRoles } from "../../auth/RoycoAuth.sol";
import { ILiquidityFacilityAdapter, Operation } from "../../interfaces/ILiquidityFacilityAdapter.sol";
import { AaveV3AdapterBase } from "./base/AaveV3AdapterBase.sol";

/**
 * @title AaveV3LiquidityFacilityAdapter
 */
contract AaveV3LiquidityFacilityAdapter is AaveV3AdapterBase, ILiquidityFacilityAdapter {
    using Math for uint256;

    /// @notice Constant for RAY
    uint256 constant RAY = 1e27;

    /// @notice The RoyUSD token contract address
    address public immutable ROY_USD;

    /// @notice The AToken contract address for RoyUSD
    address public immutable AROY_USD;

    /// @notice Thrown when the AToken is the zero address
    error FailedToGetReserveData();

    /**
     * @notice Initializes the AaveV3LiquidityFacilityAdapter
     * @param _owner The administrator responsible for granting and revoking roles for restricted functions
     * @param _allocator The allocator address authorized to call allocation functions
     * @param _aaveV3Pool The Aave V3 Pool contract address
     * @param _royUSD The RoyUSD token contract address
     */
    constructor(address _owner, address _allocator, address _aaveV3Pool, address _royUSD) AaveV3AdapterBase(_owner, _allocator, _aaveV3Pool) {
        ROY_USD = _royUSD;
        // Cache the AToken for RoyUSD
        AROY_USD = _getATokenForAsset(_royUSD);
    }

    /// @inheritdoc ILiquidityFacilityAdapter
    function allocateLiquidity(uint256 _amount) external override {
        _allocateLiquidity(ROY_USD, _amount);
    }

    /// @inheritdoc ILiquidityFacilityAdapter
    function freeLiquidity(uint256 _amount) external override {
        _freeLiquidity(ROY_USD, _amount);
    }

    /// @inheritdoc ILiquidityFacilityAdapter
    function execLiquidityQuery() external view override returns (uint256) {
        return _execLiquidityQuery(AROY_USD);
    }

    /// @inheritdoc ILiquidityFacilityAdapter
    function getOpToHitTargetBorrowRate(uint256 _targetBorrowRateRAY) external view override returns (Operation, uint256) {
        /**
         * ──────────────────────────────────────────────
         * Aave Variable Borrow Rate Model (Piecewise Linear)
         * ──────────────────────────────────────────────
         *
         * Region 1:  (Utilization U ≤ U_opt)
         * ---------------------------------
         * r_borrow = r_base + (U / U_opt) * slope1
         *
         * • Linear increase from base rate up to the kink
         * • At U = 0        → r = r_base
         * • At U = U_opt    → r = r_base + slope1
         *
         *
         * Region 2:  (Utilization U > U_opt)
         * ---------------------------------
         * r_borrow = r_base + slope1 + ((U - U_opt) / (1 - U_opt)) * slope2
         *
         * • Steeper slope beyond the kink
         * • At U = U_opt    → r = r_base + slope1  (continuous join)
         * • At U = 1.0      → r = r_base + slope1 + slope2
         *
         * ──────────────────────────────────────────────
         * Notes:
         * • Kink (or "optimal utilization") separates the two linear regions.
         * • slope1 and slope2 are *rate deltas*, not absolute APRs.
         * • r_base is the minimum borrow rate at zero utilization.
         * ──────────────────────────────────────────────
         */

        // Get the reserve data for RoyUSD
        DataTypes.ReserveData memory reserveData = IAaveV3Pool(address(POOL)).getReserveData(ROY_USD);

        // Get the IRM params
        IDefaultInterestRateStrategy interestRateStrategy = IDefaultInterestRateStrategy(reserveData.interestRateStrategyAddress);
        uint256 optimalUsageRatioRAY = interestRateStrategy.OPTIMAL_USAGE_RATIO();
        uint256 baseVariableBorrowRateRAY = interestRateStrategy.getBaseVariableBorrowRate();
        uint256 variableRateSlope1RAY = interestRateStrategy.getVariableRateSlope1();
        uint256 variableRateSlope2RAY = interestRateStrategy.getVariableRateSlope2();
        uint256 maxVariableBorrowRateRAY = interestRateStrategy.getMaxVariableBorrowRate();
        // Kink rate is determined by setting the utilization == optimal utilization in the formula for calculating rate before optimal util
        uint256 kinkRateRAY = baseVariableBorrowRateRAY + variableRateSlope1RAY;

        // If target is LE base, amount to supply diverges
        // If target is GE max, withdraw as much as possible
        if (_targetBorrowRateRAY <= baseVariableBorrowRateRAY) return (Operation.SUPPLY, type(uint256).max);
        else if (_targetBorrowRateRAY >= maxVariableBorrowRateRAY) return (Operation.WITHDRAW, type(uint256).max);

        // Solve for the target utilization by plugging in the target borrow rate specified
        uint256 targetUtilizationRAY;
        if (_targetBorrowRateRAY <= kinkRateRAY) {
            // If target rate is below or equal to the kink: U = U_opt * (r - r_base) / slope1
            uint256 rateAboveBaseRAY = _targetBorrowRateRAY - baseVariableBorrowRateRAY;
            targetUtilizationRAY = rateAboveBaseRAY.mulDiv(optimalUsageRatioRAY, variableRateSlope1RAY);
        } else {
            // If target rate is above the kink: U = U_opt + (1 - Uopt) * (r - (r_base + slope1)) / slope2
            uint256 rateAboveKinkRAY = _targetBorrowRateRAY - kinkRateRAY;
            uint256 maxExcessUsageRatioRAY = RAY - optimalUsageRatioRAY;
            targetUtilizationRAY = optimalUsageRatioRAY + rateAboveKinkRAY.mulDiv(maxExcessUsageRatioRAY, variableRateSlope2RAY);
            // Bound to max utilization (100%)
            if (targetUtilizationRAY > RAY) targetUtilizationRAY = RAY;
        }

        // Calculate the total debt in the pool.
        uint256 totalDebt = IERC20(reserveData.variableDebtTokenAddress).totalSupply() + IERC20(reserveData.stableDebtTokenAddress).totalSupply();
        if (totalDebt == 0) return (Operation.NOP, 0);

        // Get the liquidity (currently in the pool + outstanding debt)
        uint256 currentLiquidity = IERC20(AROY_USD).totalSupply();
        // Compute the desired liquidity from this formula: U_target = (total debt / total liquidity)
        uint256 desiredLiquidity = totalDebt.mulDiv(RAY, targetUtilizationRAY);
        // Compute how much to supply or withdraw depending on the direction to move the current liquidity in
        return (desiredLiquidity > currentLiquidity)
            ? (Operation.SUPPLY, (desiredLiquidity - currentLiquidity))
            : (Operation.WITHDRAW, (currentLiquidity - desiredLiquidity));
    }
}
