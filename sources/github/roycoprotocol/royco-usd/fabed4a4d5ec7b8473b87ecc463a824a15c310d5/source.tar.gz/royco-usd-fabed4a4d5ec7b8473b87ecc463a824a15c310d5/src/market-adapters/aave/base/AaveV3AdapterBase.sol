// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { IPool } from "../../../../lib/aave-v3-core/contracts/interfaces/IPool.sol";
import { IERC20, SafeERC20 } from "../../../../lib/openzeppelin-contracts/contracts/token/ERC20/utils/SafeERC20.sol";
import { AdapterBase } from "../../AdapterBase.sol";

interface IAaveV3Pool is IPool {
    /**
     * @notice Returns the aToken address of a reserve.
     * @param asset The address of the underlying asset of the reserve
     * @return The address of the aToken
     */
    function getReserveAToken(address asset) external view returns (address);
}

/**
 * @title AaveV3AdapterBase
 * @notice Base contract for Aave V3 market adapters that provides common functionality for interacting with Aave V3 pools
 */
abstract contract AaveV3AdapterBase is AdapterBase {
    using SafeERC20 for IERC20;

    /// @notice The Aave V3 Pool deployment
    address public immutable POOL;

    /**
     * @notice Initializes the AaveV3AdapterBase
     * @param _owner The administrator responsible for granting and revoking roles for restricted functions
     * @param _allocator The allocator address authorized to call allocation functions
     * @param _aaveV3Pool The Aave V3 Pool contract address
     */
    constructor(address _owner, address _allocator, address _aaveV3Pool) AdapterBase(_owner, _allocator) {
        // Set immutable state
        POOL = _aaveV3Pool;
    }

    /**
     * @notice Allocates liquidity by supplying an ERC20 asset to the Aave V3 pool
     * @dev Adapter is assumed to be prefunded with the specified amount of assets before calling this function
     * @param _asset The address of the ERC20 asset to supply
     * @param _amount The amount of the asset to supply to Aave V3
     */
    function _allocateLiquidity(address _asset, uint256 _amount) internal onlyAllocator {
        // Adapter is assumed to be prefunded with the specified amount of assets
        IERC20(_asset).forceApprove(POOL, _amount);
        IAaveV3Pool(POOL).supply(_asset, _amount, address(this), 0);
    }

    /**
     * @notice Frees liquidity by withdrawing an ERC20 asset from the Aave V3 pool
     * @dev Withdraws the specified amount directly to the caller (allocator)
     * @param _asset The address of the ERC20 asset to withdraw
     * @param _amount The amount of the asset to withdraw from Aave V3
     */
    function _freeLiquidity(address _asset, uint256 _amount) internal onlyAllocator {
        // Withdraw from Aave to the allocator directly
        IAaveV3Pool(POOL).withdraw(_asset, _amount, msg.sender);
    }

    /**
     * @notice Executes a liquidity query to check the balance of aTokens
     * @dev Queries the balance of the specified aToken for the caller
     * @param _aToken The address of the aToken to query the balance for
     * @return The balance of the underlying asset held by the adapter
     */
    function _execLiquidityQuery(address _aToken) internal view returns (uint256) {
        return IERC20(_aToken).balanceOf(address(this));
    }

    /**
     * @notice Gets the aToken address for a given underlying asset
     * @dev Queries the Aave V3 pool for the aToken corresponding to the specified asset
     * @param _asset The address of the underlying ERC20 asset
     * @return The address of the corresponding AToken
     */
    function _getATokenForAsset(address _asset) internal view returns (address) {
        return IAaveV3Pool(POOL).getReserveAToken(_asset);
    }
}
