// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { ERC20Burnable } from "../lib/openzeppelin-contracts/contracts/token/ERC20/extensions/ERC20Burnable.sol";
import { ERC20, ERC20Permit } from "../lib/openzeppelin-contracts/contracts/token/ERC20/extensions/ERC20Permit.sol";
import { RoycoAuth, RoycoRoles } from "./auth/RoycoAuth.sol";

/**
 * @title RoyUSD
 * @notice Royco's synthetic dollar backed by stable collateral assets
 * @dev Minting restricted to authorized Teller(s) and Lender(s). Redeemable 1:1 for the collateral via the Teller(s).
 */
contract RoyUSD is RoycoAuth, ERC20Permit, ERC20Burnable {
    /// @notice Maximum allowed token supply
    uint256 public maxSupply;

    /// @notice Emitted when maximum supply is updated
    event MaxSupplySet(uint256 maxSupply);

    /// @notice Thrown when a mint or setting a new max supply would exceed the current maximum supply or supply respectively
    error MaxSupplyExceeded();

    /// @notice Ensures total supply doesn't exceed maximum supply
    modifier checkMaxSupply() {
        _;
        require(totalSupply() <= maxSupply, MaxSupplyExceeded());
    }

    /**
     * @notice Initializes the RoyUSD token
     * @param _owner The administator responsible for granting and revoking authorizations for restricted functions
     * @param _maxSupply The maximum supply limit for the token
     */
    constructor(address _owner, uint256 _maxSupply) RoycoAuth(_owner) ERC20("Royco USD", "RoyUSD") ERC20Permit("Royco USD") {
        _setMaxSupply(_maxSupply);
    }

    /**
     * @notice Mints tokens to a specified address
     * @dev Only authorized Teller(s) can call this function
     * @param _to The address to mint tokens to
     * @param _amount The amount of tokens to mint
     */
    function mint(address _to, uint256 _amount) external onlyRoles(RoycoRoles.TELLER | RoycoRoles.LENDER) checkMaxSupply {
        _mint(_to, _amount);
    }

    /**
     * @notice Sets the maximum supply cap
     * @param _maxSupply The new maximum supply limit
     */
    function setMaxSupply(uint256 _maxSupply) external onlyOwner checkMaxSupply {
        _setMaxSupply(_maxSupply);
    }

    /**
     * @notice Internal function to set maximum supply
     * @param _maxSupply The maximum supply limit
     */
    function _setMaxSupply(uint256 _maxSupply) internal {
        maxSupply = _maxSupply;
        emit MaxSupplySet(_maxSupply);
    }
}
