// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { RoycoAuth, RoycoRoles } from "../../auth/RoycoAuth.sol";
import { IMarketAdapter } from "../../interfaces/IMarketAdapter.sol";
import { AaveV3AdapterBase } from "./base/AaveV3AdapterBase.sol";

/**
 * @title AaveV3MarketAdapter
 * @notice Deploys assets into Aave V3 and withdraws back to the reserve
 * @dev This adapter forwards the entire deposit and withdrawal to the Aave V3 Pool, and does not hold any tokens itself or manage a split of tokens between the reserve and the Aave V3 Pool
 * @dev Only callable by the configured reserve contract
 */
contract AaveV3MarketAdapter is AaveV3AdapterBase, IMarketAdapter {
    /// @notice Cache of an asset to its respective AToken
    mapping(address asset => address aToken) public assetToAToken;

    /**
     * @notice Emitted when the AToken is set for a particular asset
     * @param asset The asset the AToken was set for
     * @param aToken The AToken for the asset
     */
    event ATokenSet(address asset, address aToken);

    /// @notice Thrown when the AToken is the zero address
    error InvalidAToken();

    /**
     * @notice Initializes the AaveV3MarketAdapter
     * @param _owner The administrator responsible for granting and revoking roles for restricted functions
     * @param _allocator The allocator address authorized to call allocation functions
     * @param _aaveV3Pool The Aave V3 Pool contract address
     * @param _assets Initial assets to configure ATokens for
     */
    constructor(address _owner, address _allocator, address _aaveV3Pool, address[] memory _assets) AaveV3AdapterBase(_owner, _allocator, _aaveV3Pool) {
        // Cache ATokens for the specified assets in the adapter's storage
        _setATokens(_assets);
    }

    /// @inheritdoc IMarketAdapter
    function allocateLiquidity(address _asset, uint256 _amount) external override {
        _allocateLiquidity(_asset, _amount);
    }

    /// @inheritdoc IMarketAdapter
    function freeLiquidity(address _asset, uint256 _amount) external override {
        _freeLiquidity(_asset, _amount);
    }

    /// @inheritdoc IMarketAdapter
    function execLiquidityQuery(address _asset) external view override returns (uint256) {
        return _execLiquidityQuery(assetToAToken[_asset]);
    }

    /**
     * @notice Sets the ATokens for multiple assets
     * @param _assets Array of asset addresses to set ATokens for
     */
    function setATokens(address[] calldata _assets) external onlyOwnerOrRoles(RoycoRoles.ADAPTER_MANAGER) {
        _setATokens(_assets);
    }

    /**
     * @notice Internal function to set ATokens for multiple assets
     * @param _assets Array of asset addresses to set ATokens for
     */
    function _setATokens(address[] memory _assets) internal {
        uint256 numAssets = _assets.length;
        for (uint256 i = 0; i < numAssets; ++i) {
            address asset = _assets[i];
            address aToken = (assetToAToken[asset] = _getATokenForAsset(asset));
            emit ATokenSet(asset, aToken);
        }
    }
}
