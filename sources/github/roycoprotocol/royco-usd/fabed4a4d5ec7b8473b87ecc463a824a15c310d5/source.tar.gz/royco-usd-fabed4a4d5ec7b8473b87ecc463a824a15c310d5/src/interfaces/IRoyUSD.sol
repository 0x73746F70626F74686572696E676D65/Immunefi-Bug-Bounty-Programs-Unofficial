// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import { IERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol";
import { IERC20Metadata } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import { IERC20Permit } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/extensions/IERC20Permit.sol";

interface IRoyUSD is IERC20, IERC20Metadata, IERC20Permit {
    function maxSupply() external view returns (uint256);

    function mint(address _to, uint256 _amount) external;

    function burn(uint256 value) external;

    function burnFrom(address account, uint256 value) external;
}
