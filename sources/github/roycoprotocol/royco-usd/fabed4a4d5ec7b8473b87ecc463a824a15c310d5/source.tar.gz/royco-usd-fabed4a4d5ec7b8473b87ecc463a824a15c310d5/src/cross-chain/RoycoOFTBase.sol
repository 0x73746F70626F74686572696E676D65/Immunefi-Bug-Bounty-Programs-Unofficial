// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { ILayerZeroEndpointV2 } from "../../lib/LayerZero-v2/packages/layerzero-v2/evm/protocol/contracts/interfaces/ILayerZeroEndpointV2.sol";
import { OFT } from "../../lib/devtools/packages/oft-evm/contracts/OFT.sol";
import { OFTCore } from "../../lib/devtools/packages/oft-evm/contracts/OFTCore.sol";
import { Ownable } from "../../lib/openzeppelin-contracts/contracts/access/Ownable.sol";

/// @title RoycoOFTBase
/// @notice Base contract for the RoycoOFT and RoycoOFTAdapter contracts
/// @dev Bootstraps the OFT contracts with the necessary configurations
abstract contract RoycoOFTBase is OFTCore {
    // Custom errors
    error InvalidLength();
    error InvalidSendLibrary();
    error InvalidReceiveLibrary();

    struct OFTSetupConfig {
        // The destination endpoint IDs
        uint32[] dstEids;
        // The corresponding peers addresses
        bytes32[] peers;
    }

    constructor(address _lzEndpoint, OFTSetupConfig memory _oftSetupConfig) {
        require(_oftSetupConfig.dstEids.length == _oftSetupConfig.peers.length, InvalidLength());

        // Set send library configs
        for (uint256 i = 0; i < _oftSetupConfig.dstEids.length; i++) {
            // Set send library
            address sendLibrary = ILayerZeroEndpointV2(_lzEndpoint).defaultSendLibrary(_oftSetupConfig.dstEids[i]);
            require(sendLibrary != address(0), InvalidSendLibrary());
            ILayerZeroEndpointV2(_lzEndpoint).setSendLibrary(address(this), _oftSetupConfig.dstEids[i], sendLibrary);

            // Set receive library
            address receiveLibrary = ILayerZeroEndpointV2(_lzEndpoint).defaultReceiveLibrary(_oftSetupConfig.dstEids[i]);
            require(receiveLibrary != address(0), InvalidReceiveLibrary());
            ILayerZeroEndpointV2(_lzEndpoint).setReceiveLibrary(address(this), _oftSetupConfig.dstEids[i], receiveLibrary, 0);

            // Set peer
            _setPeer(_oftSetupConfig.dstEids[i], _oftSetupConfig.peers[i]);
        }
    }
}
