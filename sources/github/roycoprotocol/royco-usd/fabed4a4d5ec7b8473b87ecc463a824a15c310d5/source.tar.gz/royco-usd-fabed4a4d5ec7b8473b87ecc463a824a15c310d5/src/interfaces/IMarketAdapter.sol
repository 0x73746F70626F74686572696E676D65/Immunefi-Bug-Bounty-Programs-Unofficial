// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

/**
 * @title IMarketAdapter
 * @notice Generic interface for market adapters that deploy ERC20 assets into money or capital markets.
 */
interface IMarketAdapter {
    /**
     * @notice Deposits an ERC20 asset into the external market
     * @dev Must transfer in the specified amount of assets to the adapter prior to calling
     * @param _asset The ERC20 asset to deposit
     * @param _amount The amount of the asset to deposit
     */
    function allocateLiquidity(address _asset, uint256 _amount) external;

    /**
     * @notice Withdraws an ERC20 asset from the external market
     * @dev Must transfer withdrawn tokens back to the caller
     * @param _asset The ERC20 asset to withdraw
     * @param _amount The amount of the asset to withdraw
     */
    function freeLiquidity(address _asset, uint256 _amount) external;

    /**
     * @notice Returns the balance of an ERC20 asset in the external market held by the adapter
     * @param _asset The ERC20 asset to get the balance of
     * @return The balance of the asset held by the adapter in the external market
     */
    function execLiquidityQuery(address _asset) external view returns (uint256);
}
