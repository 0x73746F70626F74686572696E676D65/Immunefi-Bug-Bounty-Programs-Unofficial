// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

/**
 * @title RoycoRoles
 * @notice Library containing role constants for the Royco protocol access control system
 * @dev Defines bit-shifted role constants used with OwnableRoles for granular permission management.
 *      Each role is represented as a unique bit position (1 << n) to allow for efficient
 *      bitwise operations and role combinations.
 */
library RoycoRoles {
    // -----------------------------------------
    // Royco Contract Roles
    // -----------------------------------------
    /// @notice Role for teller contract operations
    uint256 public constant TELLER = 1 << 0;
    /// @notice Role for minting/lending RoyUSD and reserves
    uint256 public constant LENDER = 1 << 1;
    /// @notice Role for the staking contract responsible for staking/unstaking assets and managing yield
    uint256 public constant STAKING = 1 << 2;

    // -----------------------------------------
    // Reserve Roles
    // -----------------------------------------
    /// @notice Role for managing reserve operations
    uint256 public constant RESERVE_MANAGER = 1 << 3;
    /// @notice Role for managing reserve allocations
    uint256 public constant RESERVE_ALLOCATOR = 1 << 4;

    // -----------------------------------------
    // Teller Roles
    // -----------------------------------------
    /// @notice Role for minting RoyUSD tokens
    uint256 public constant MINTER = 1 << 5;
    /// @notice Role for redeeming RoyUSD tokens
    uint256 public constant REDEEMER = 1 << 6;
    /// @notice Role for managing collateral operations
    uint256 public constant COLLATERAL_MANAGER = 1 << 7;

    // -----------------------------------------
    // Open Market Operations Roles
    // -----------------------------------------
    /// @notice Role for managing mint/loan caps and fees for RoyUSD and the reserve assets
    uint256 public constant OPEN_MARKET_DESK = 1 << 8;

    // -----------------------------------------
    // Staking Roles
    // -----------------------------------------
    /// @notice Role for distributing yield to RoyUSD stakers
    uint256 public constant YIELD_DISTRIBUTOR = 1 << 9;
    /// @notice Role for the staking contract manager
    uint256 public constant STAKING_MANAGER = 1 << 10;
    /// @notice Role for the manager of the staking blacklist
    uint256 public constant BLACKLIST_MANAGER = 1 << 11;
    /// @notice Role for a blacklisted staker
    uint256 public constant BLACKLISTED_STAKER = 1 << 12;
    /// @notice Role for an expedited unstaker
    uint256 public constant EXPEDITED_UNSTAKER = 1 << 13;

    // -----------------------------------------
    // Adapter Roles
    // -----------------------------------------
    /// @notice Role for managing adapter operations
    uint256 public constant ADAPTER_MANAGER = 1 << 14;

    ///
    // Scheduler Manager Roles
    // -----------------------------------------
    /// @notice Role for managing scheduler operations
    uint256 public constant SCHEDULER_MANAGER = 1 << 15;
}
