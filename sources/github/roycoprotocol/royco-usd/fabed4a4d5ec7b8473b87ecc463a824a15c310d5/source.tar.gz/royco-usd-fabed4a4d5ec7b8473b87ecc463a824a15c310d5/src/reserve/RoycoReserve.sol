// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { IERC20, SafeERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/utils/SafeERC20.sol";
import { RoycoAuth, RoycoRoles } from "../auth/RoycoAuth.sol";
import { IMarketAdapter } from "../interfaces/IMarketAdapter.sol";
import { IRoycoReserve } from "../interfaces/IRoycoReserve.sol";

/**
 * @title RoycoReserve
 * @notice A vault contract that holds collateral assets and allows authorized entities to transfer them
 * @dev Inherits from RoycoAuth to restrict access to privileged functions
 */
contract RoycoReserve is RoycoAuth, IRoycoReserve {
    using SafeERC20 for IERC20;

    /// @notice The RoyUSD token contract address
    address public immutable ROY_USD;

    /// @notice Maps each collateral asset to its adapter (if any). address(0) means keep tokens idle in reserve
    mapping(address collateral => address adapter) public collateralToAdapter;

    /// @notice Emitted when a collateral adapter is set
    event CollateralAdapterSet(address collateralAsset, address adapter);

    /// @notice Thrown when trying to free RoyUSD as a collateral asset
    /// @dev Should theoretically never be raised
    error InvalidCollateralAsset();

    /// @notice Thrown when trying to free a collateral asset that has no adapter configured
    error NoAdapterConfigured();

    /// @notice Given an amount, it must be greater than 0
    error InvalidAmount();

    /**
     * @notice Ensures the provided amount is greater than zero
     * @dev Reverts with InvalidAmount error if the amount is zero
     * @param _amount The amount to validate
     */
    modifier checkNonZeroAmount(uint256 _amount) {
        require(_amount > 0, InvalidAmount());
        _;
    }

    /**
     * @notice Ensures the provided asset is not the RoyUSD token
     * @dev Prevents operations on RoyUSD as a collateral asset, which should theoretically never happen
     * @param _asset The asset address to validate
     */
    modifier checkNotRoyUSD(address _asset) {
        require(_asset != ROY_USD, InvalidCollateralAsset());
        _;
    }

    /**
     * @notice Initializes the RoycoReserve contract with access control
     * @param _owner The administrator responsible for granting and revoking roles for restricted functions
     * @param _royUSD The RoyUSD token contract address
     * @param _setCollateralAdapterDelay The delay for the collateral adapter set function
     */
    constructor(address _owner, address _royUSD, uint256 _setCollateralAdapterDelay) RoycoAuth(_owner) {
        ROY_USD = _royUSD;

        // Update the execution delay for the collateral adapter set function
        _updateExecutionDelay(RoycoReserve.setCollateralAdapter.selector, _setCollateralAdapterDelay);
    }

    /**
     * @notice Sets or updates the adapter for a collateral asset
     * @dev Only owner or RESERVE_MANAGER can call. Set to address(0) to disable deployment for an asset
     */
    function setCollateralAdapter(address _collateralAsset, address _adapter) external override onlyOwnerOrRolesWithDelay(RoycoRoles.RESERVE_MANAGER) {
        collateralToAdapter[_collateralAsset] = _adapter;
        emit CollateralAdapterSet(_collateralAsset, _adapter);
    }

    /**
     * @notice Deposits collateral into the configured adapter
     * @dev Pulls tokens from the sender directly into the adapter, then calls adapter.deposit().
     *      If adapter is address(0), tokens are pulled to the reserve and kept idle.
     * @param _collateralAsset The ERC20 asset to deposit
     * @param _amount The amount of collateral to deposit
     */
    function hypothecateReserves(
        address _collateralAsset,
        uint256 _amount
    )
        external
        override
        onlyOwnerOrRoles(RoycoRoles.RESERVE_MANAGER | RoycoRoles.RESERVE_ALLOCATOR)
        checkNonZeroAmount(_amount)
        checkNotRoyUSD(_collateralAsset)
    {
        address adapter = collateralToAdapter[_collateralAsset];
        require(adapter != address(0), NoAdapterConfigured());

        IERC20(_collateralAsset).safeTransfer(adapter, _amount);
        IMarketAdapter(adapter).allocateLiquidity(_collateralAsset, _amount);
    }

    /**
     * @notice Withdraws assets from the configured adapter to the reserve
     * @dev Only callable by addresses with the RESERVE_MANAGER role
     * @param _collateralAsset The ERC20 asset to withdraw
     * @param _amount The amount of collateral to withdraw
     */
    function withdrawAssetsToReserve(
        address _collateralAsset,
        uint256 _amount
    )
        external
        override
        onlyOwnerOrRoles(RoycoRoles.RESERVE_MANAGER | RoycoRoles.RESERVE_ALLOCATOR)
        checkNonZeroAmount(_amount)
        checkNotRoyUSD(_collateralAsset)
    {
        address adapter = collateralToAdapter[_collateralAsset];
        require(adapter != address(0), NoAdapterConfigured());

        IMarketAdapter(adapter).freeLiquidity(_collateralAsset, _amount);
    }

    /**
     * @notice Transfers collateral assets from the reserve to a specified recipient
     * @dev Only callable by addresses with the RESERVE_MANAGER, TELLER, or LENDER role
     * @param _collateralAsset The address of the ERC20 token to transfer
     * @param _recipient The address that will receive the tokens
     * @param _amount The amount of tokens to transfer
     */
    function freeReserves(
        address _collateralAsset,
        address _recipient,
        uint256 _amount
    )
        external
        override
        onlyRolesOrOwner(RoycoRoles.RESERVE_MANAGER | RoycoRoles.TELLER | RoycoRoles.LENDER)
        checkNonZeroAmount(_amount)
        checkNotRoyUSD(_collateralAsset)
    {
        // If a hypothecation adapter is configured, attempt to withdraw funds to the reserve iff
        // the reserve has insufficient funds
        address adapter = collateralToAdapter[_collateralAsset];
        if (adapter != address(0)) {
            uint256 reserveBalance = IERC20(_collateralAsset).balanceOf(address(this));
            unchecked {
                uint256 amountToWithdraw = _amount > reserveBalance ? _amount - reserveBalance : 0;
                if (amountToWithdraw > 0) {
                    IMarketAdapter(adapter).freeLiquidity(_collateralAsset, amountToWithdraw);
                }
            }
        }

        // Transfer from reserve to recipient
        IERC20(_collateralAsset).safeTransfer(_recipient, _amount);
    }

    /**
     * @notice Transfers unstaked RoyUSD assets from the reserve to a specified recipient
     * @dev Only callable by addresses with the STAKING role
     * @param _recipient The address that will receive the RoyUSD tokens
     * @param _amount The amount of RoyUSD tokens to transfer
     */
    function freeUnstakedAssets(address _recipient, uint256 _amount) external override onlyRolesOrOwner(RoycoRoles.STAKING) checkNonZeroAmount(_amount) {
        IERC20(ROY_USD).safeTransfer(_recipient, _amount);
    }

    /**
     * @notice Returns the amount of collateral that can be withdrawn from the reserve
     * @param _collateralAsset The ERC20 asset to withdraw
     * @return The amount of collateral that can be withdrawn
     */
    function getReserveTotalBalance(address _collateralAsset) external view override returns (uint256) {
        uint256 reserveBalance = IERC20(_collateralAsset).balanceOf(address(this));
        address adapter = collateralToAdapter[_collateralAsset];
        if (adapter != address(0)) {
            reserveBalance += IMarketAdapter(adapter).execLiquidityQuery(_collateralAsset);
        }
        return reserveBalance;
    }
}
