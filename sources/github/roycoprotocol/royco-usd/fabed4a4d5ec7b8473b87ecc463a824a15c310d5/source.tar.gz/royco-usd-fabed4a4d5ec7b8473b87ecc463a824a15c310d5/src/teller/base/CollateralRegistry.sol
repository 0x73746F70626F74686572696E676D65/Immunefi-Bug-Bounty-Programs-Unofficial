// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { IERC20Metadata } from "../../../lib/openzeppelin-contracts/contracts/token/ERC20/ERC20.sol";
import { Math } from "../../../lib/openzeppelin-contracts/contracts/utils/math/Math.sol";
import { EnumerableSet } from "../../../lib/openzeppelin-contracts/contracts/utils/structs/EnumerableSet.sol";

/**
 * @title CollateralRegistry
 * @notice Abstract contract for managing a registry of approved collateral assets
 * @dev Provides functionality to add, remove, and validate collateral assets with their decimal scaling factors
 */
abstract contract CollateralRegistry {
    using EnumerableSet for EnumerableSet.AddressSet;
    using Math for uint256;

    /// @notice The RoyUSD token contract address
    address public immutable ROY_USD;

    /// @notice One unit of RoyUSD scaled to its decimal precision
    uint256 internal immutable ONE_ROY_USD;

    /// @notice Set of approved collateral asset addresses
    EnumerableSet.AddressSet internal collateralAssets;

    /// @notice Mapping from collateral asset to the price of 1 RoyUSD in that asset (scaled by its decimals)
    /// @dev Each collateral asset is a stablecoin/synthetic dollar and is mintable/redeemable 1:1 with RoyUSD
    mapping(address collateralAsset => uint256 price) public collateralAssetToPrice;

    /**
     * @notice Emitted when a new collateral asset is added to the registry
     * @param collateralAsset The address of the collateral asset that was added
     */
    event CollateralAssetAdded(address collateralAsset);

    /**
     * @notice Emitted when a collateral asset is removed from the registry
     * @param collateralAsset The address of the collateral asset that was removed
     */
    event CollateralAssetRemoved(address collateralAsset);

    /// @notice Error thrown when trying to do any operation with an invalid collateral asset
    /// @dev RoyUSD can never be a collateral asset
    error InvalidCollateralAsset();

    /**
     * @notice Initializes the collateral registry
     * @param _royUSD The RoyUSD token contract address
     * @param _collateralAssets Array of initial collateral asset addresses to approve
     */
    constructor(address _royUSD, address[] memory _collateralAssets) {
        // Set immutable state
        ROY_USD = _royUSD;
        ONE_ROY_USD = 10 ** IERC20Metadata(_royUSD).decimals();

        // Set the initial collateral assets
        uint256 numCollateralAssets = _collateralAssets.length;
        for (uint256 i = 0; i < numCollateralAssets; ++i) {
            _addCollateralAsset(_collateralAssets[i]);
        }
    }

    /**
     * @notice Returns all approved collateral assets and the total count
     * @return An array of collateral asset addresses
     */
    function getCollateralAssets() external view returns (address[] memory) {
        return collateralAssets.values();
    }

    /**
     * @notice Quotes the amount of collateral asset required to mint a specified amount of RoyUSD
     * @param _amountRoyUSD The amount of RoyUSD tokens to mint
     * @param _collateralAsset The address of the collateral asset to use for minting
     * @return The amount of collateral asset required to mint the specified RoyUSD amount
     */
    function quoteMintCost(uint256 _amountRoyUSD, address _collateralAsset) external view returns (uint256) {
        return _computeCostInCollateralAsset(_amountRoyUSD, _getPricePerRoyUSD(_collateralAsset), Math.Rounding.Ceil);
    }

    /**
     * @notice Quotes the amount of RoyUSD required to redeem a specified amount of collateral asset
     * @param _amountCollateralAsset The amount of collateral asset to redeem
     * @param _collateralAsset The address of the collateral asset to redeem
     * @return The amount of RoyUSD required to redeem the specified collateral asset amount
     */
    function quoteRedemptionCost(uint256 _amountCollateralAsset, address _collateralAsset) external view returns (uint256) {
        return _computeCostInRoyUSD(_amountCollateralAsset, _getPricePerRoyUSD(_collateralAsset), Math.Rounding.Ceil);
    }

    /**
     * @notice Quotes the amount of RoyUSD that would be minted for a specified amount of collateral asset
     * @param _amountCollateralAsset The amount of collateral asset to provide for minting
     * @param _collateralAsset The address of the collateral asset to use for minting
     * @return The amount of RoyUSD that would be minted for the specified collateral asset amount
     */
    function quoteMintOutput(uint256 _amountCollateralAsset, address _collateralAsset) external view returns (uint256) {
        return _computeCostInRoyUSD(_amountCollateralAsset, _getPricePerRoyUSD(_collateralAsset), Math.Rounding.Floor);
    }

    /**
     * @notice Quotes the amount of collateral asset that would be redeemed for a specified amount of RoyUSD
     * @param _amountRoyUSD The amount of RoyUSD to burn for redemption
     * @param _collateralAsset The address of the collateral asset to redeem
     * @return The amount of collateral asset that would be redeemed for the specified RoyUSD amount
     */
    function quoteRedemptionOutput(uint256 _amountRoyUSD, address _collateralAsset) external view returns (uint256) {
        return _computeCostInCollateralAsset(_amountRoyUSD, _getPricePerRoyUSD(_collateralAsset), Math.Rounding.Floor);
    }

    /**
     * @notice Internal function to add a new collateral asset to the registry
     * @dev Sets the price to 1 collateral asset per RoyUSD: assumes 1:1 parity with RoyUSD
     * @param _collateralAsset The address of the collateral asset to add
     */
    function _addCollateralAsset(address _collateralAsset) internal {
        require(_collateralAsset != ROY_USD && collateralAssets.add(_collateralAsset), InvalidCollateralAsset());

        collateralAssetToPrice[_collateralAsset] = 10 ** IERC20Metadata(_collateralAsset).decimals();
        emit CollateralAssetAdded(_collateralAsset);
    }

    /**
     * @notice Internal function to remove a collateral asset from the registry
     * @dev Removes the asset from the set and clears its price mapping
     * @param _collateralAsset The address of the collateral asset to remove
     */
    function _removeCollateralAsset(address _collateralAsset) internal {
        require(collateralAssets.remove(_collateralAsset), InvalidCollateralAsset());

        delete collateralAssetToPrice[_collateralAsset];
        emit CollateralAssetRemoved(_collateralAsset);
    }

    /**
     * @notice Retrieves the price of one whole RoyUSD denominated in the specified collateral asset
     * @dev Reverts if the collateral asset is not enabled
     * @param _collateralAsset The address of the collateral asset to get the price for
     * @return pricePerRoyUSD The amount of collateral asset required to mint/buy one whole RoyUSD token
     */
    function _getPricePerRoyUSD(address _collateralAsset) internal view returns (uint256 pricePerRoyUSD) {
        // Get the price per whole RoyUSD in the collateral asset and check existance
        require((pricePerRoyUSD = collateralAssetToPrice[_collateralAsset]) != 0, InvalidCollateralAsset());
    }

    /**
     * @notice Calculates the cost of a specified amount of RoyUSD in terms of collateral asset units
     * @param _amountRoyUSD The amount of RoyUSD tokens to calculate the cost for
     * @param _pricePerRoyUSD The price of one whole RoyUSD in collateral asset units
     * @param _rounding The rounding direction (Ceil for minting, Floor for redemption)
     * @return The amount of collateral asset required for the specified RoyUSD amount
     */
    function _computeCostInCollateralAsset(uint256 _amountRoyUSD, uint256 _pricePerRoyUSD, Math.Rounding _rounding) internal view returns (uint256) {
        // Calculate the cost of the specified amount of RoyUSD in collateral assets (1:1 price ratio with decimal scaling)
        return _amountRoyUSD.mulDiv(_pricePerRoyUSD, ONE_ROY_USD, _rounding);
    }

    /**
     * @notice Calculates the equivalent amount of RoyUSD for a specified amount of collateral asset
     * @param _amountCollateralAsset The amount of collateral asset to calculate the RoyUSD equivalent for
     * @param _pricePerRoyUSD The price of one whole RoyUSD in collateral asset units
     * @param _rounding The rounding direction (Ceil for redeemAny to favor the Teller)
     * @return The equivalent amount of RoyUSD for the specified collateral asset amount
     */
    function _computeCostInRoyUSD(uint256 _amountCollateralAsset, uint256 _pricePerRoyUSD, Math.Rounding _rounding) internal view returns (uint256) {
        // Calculate the cost of the specified amount of collateral assets in RoyUSD (1:1 price ratio with decimal scaling)
        return _amountCollateralAsset.mulDiv(ONE_ROY_USD, _pricePerRoyUSD, _rounding);
    }

    /**
     * @notice Internal function to get a collateral asset by its index in the registry
     * @param _index The index of the collateral asset in the enumerable set
     * @return The address of the collateral asset at the specified index
     */
    function _getCollateralAsset(uint256 _index) internal view returns (address) {
        return collateralAssets.at(_index);
    }

    /**
     * @notice Internal function to get the total number of collateral assets in the registry
     * @return The number of collateral assets currently registered
     */
    function _getNumCollateralAssets() internal view returns (uint256) {
        return collateralAssets.length();
    }
}
