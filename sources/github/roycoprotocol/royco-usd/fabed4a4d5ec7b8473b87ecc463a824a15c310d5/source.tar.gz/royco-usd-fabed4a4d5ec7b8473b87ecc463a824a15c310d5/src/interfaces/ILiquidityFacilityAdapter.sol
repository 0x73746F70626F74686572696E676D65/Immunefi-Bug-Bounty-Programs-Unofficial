// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

/// @title Enum representation of operations that the liquidity facility can execute
enum Operation {
    NOP,
    SUPPLY,
    WITHDRAW
}

/**
 * @title ILiquidityFacilityAdapter
 * @notice Generic interface for liquidity facility adapters that deploy RoyUSD into external money markets.
 */
interface ILiquidityFacilityAdapter {
    /**
     * @notice Deposits RoyUSD into the external money market
     * @dev Must approve the adapter to spend the specified amount of RoyUSD
     * @param _amount The amount of RoyUSD to deposit
     */
    function allocateLiquidity(uint256 _amount) external;

    /**
     * @notice Withdraws RoyUSD from the external money market
     * @dev Must transfer withdrawn tokens back to the caller
     * @param _amount The amount of RoyUSD to withdraw
     */
    function freeLiquidity(uint256 _amount) external;

    /**
     * @notice Returns the balance of RoyUSD in the money market held by the adapter
     * @return The balance of RoyUSD
     */
    function execLiquidityQuery() external view returns (uint256);

    /**
     * @notice Compute how much RoyUSD to supply or withdraw to hit a target variable borrow rate.
     * @param _targetBorrowRateRAY Target variable borrow APR scaled by RAY
     * @return Enum indicating what operation the liquidity facility should execute
     * @return The amount of RoyUSD supply or withdraw (depending on the operation)
     */
    function getOpToHitTargetBorrowRate(uint256 _targetBorrowRateRAY) external view returns (Operation, uint256);
}
