// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { RoycoAuth } from "../auth/RoycoAuth.sol";

/**
 * @title AdapterBase
 * @notice Base contract for market adapters that interface with external protocols
 * @dev Abstract contract providing common functionality for market adapters.
 *      Inherits authentication controls from RoycoAuth and restricts access to designated allocator.
 */
abstract contract AdapterBase is RoycoAuth {
    /// @notice The address of the allocator responsible for allocating and freeing liquidity from the external market
    address public immutable ALLOCATOR;

    /// @notice Thrown when the caller is not the configured allocator
    error OnlyAllocator();

    /// @notice Modifier to check that the function invoker is the configured allocator
    modifier onlyAllocator() {
        require(msg.sender == ALLOCATOR, OnlyAllocator());
        _;
    }

    /**
     * @notice Initializes the adapter base with owner and allocator addresses
     * @param _owner The administrator responsible for granting and revoking authorizations for restricted functions
     * @param _allocator The address authorized to allocate and free liquidity from the external market
     */
    constructor(address _owner, address _allocator) RoycoAuth(_owner) {
        // Set immutable state
        ALLOCATOR = _allocator;
    }
}
