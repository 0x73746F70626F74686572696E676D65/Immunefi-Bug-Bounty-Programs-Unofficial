// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { OFT } from "../../lib/devtools/packages/oft-evm/contracts/OFT.sol";
import { Ownable } from "../../lib/openzeppelin-contracts/contracts/access/Ownable.sol";
import { RoycoOFTBase } from "./RoycoOFTBase.sol";

/// @title RoycoOFT
/// @notice Minimal omnichain token for non-mainnet chains that pairs with the mainnet OFT Adapter
/// @dev Burns on source and mints on destination via LayerZero OFT core
contract RoycoOFT is OFT, RoycoOFTBase {
    /// @notice Initializes the RoyUSDOFT contract
    /// @param _name Token name (should match canonical token)
    /// @param _symbol Token symbol (should match canonical token)
    /// @param _lzEndpoint LayerZero endpoint on this chain
    /// @param _oftSetupConfig The configuration for the OFT setup
    /// @param _owner Contract owner (admin for peer/config changes)
    constructor(
        string memory _name,
        string memory _symbol,
        address _lzEndpoint,
        address _owner,
        OFTSetupConfig memory _oftSetupConfig
    )
        Ownable(_owner)
        OFT(_name, _symbol, _lzEndpoint, _owner)
        RoycoOFTBase(_lzEndpoint, _oftSetupConfig)
    { }
}
