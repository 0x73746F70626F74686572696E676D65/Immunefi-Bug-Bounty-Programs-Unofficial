// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { IERC20, SafeERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/utils/SafeERC20.sol";
import { RoycoAuth, RoycoRoles } from "../auth/RoycoAuth.sol";
import { ILiquidityFacilityAdapter, Operation } from "../interfaces/ILiquidityFacilityAdapter.sol";
import { IRoyUSD } from "../interfaces/IRoyUSD.sol";

/**
 * @title RoycoLiquidityFacility
 * @notice Automated liquidity management facility for money markets supporting RoyUSD supply/withdrawal operations
 * @notice The liquidity facility aims to tether the borrow rate for RoyUSD across select money markets
 */
contract RoycoLiquidityFacility is RoycoAuth {
    using SafeERC20 for IERC20;

    /// @notice The RoyUSD token contract address
    address public immutable ROY_USD;

    /// @notice Mapping from adapter address to its money market configuration
    mapping(address adapter => MoneyMarketConfig config) public adapterToConfig;

    /**
     * @notice Configuration parameters for a money market adapter
     * @custom:field targetBorrowRateRAY The target borrow rate for RoyUSD in this money market (scaled by RAY)
     * @custom:field supplyCap The maximum amount of RoyUSD that can be supplied to this money market
     */
    struct MoneyMarketConfig {
        uint96 targetBorrowRateRAY;
        uint160 supplyCap;
    }

    /**
     * @notice Emitted when RoyUSD is supplied to a money market
     * @param adapter The address of the adapter through which RoyUSD was supplied
     * @param amountSupplied The amount of RoyUSD supplied to the money market
     */
    event RoyUSDSupplied(address indexed adapter, uint256 amountSupplied);

    /**
     * @notice Emitted when RoyUSD is withdrawn from a money market
     * @param adapter The address of the adapter through which RoyUSD was withdrawn
     * @param amountWithdrawn The amount of RoyUSD withdrawn from the money market
     */
    event RoyUSDWithdrawn(address indexed adapter, uint256 amountWithdrawn);

    /**
     * @notice Emitted when adapter configuration is updated for a money market
     * @param adapter The address of the adapter whose configuration was updated
     * @param targetBorrowRateRAY The new target borrow rate in RAY (27 decimal precision)
     * @param supplyCap The new supply cap for this money market
     */
    event AdapterConfigSet(address indexed adapter, uint96 targetBorrowRateRAY, uint160 supplyCap);

    /// @notice Error thrown when arrays have different lengths
    error ArrayLengthMismatch();

    /**
     * @notice Initializes the liquidity facility with required contracts
     * @param _owner The administrator responsible for granting and revoking authorizations for restricted functions
     * @param _royUSD The RoyUSD token contract address
     * @param _setAdapterConfigDelay The delay for adapter configuration update functions
     */
    constructor(address _owner, address _royUSD, uint256 _setAdapterConfigDelay) RoycoAuth(_owner) {
        // Set immutable state
        ROY_USD = _royUSD;

        // Update the execution delays for the admin functions
        _updateExecutionDelay(RoycoLiquidityFacility.setAdapterConfig.selector, _setAdapterConfigDelay);
        _updateExecutionDelay(RoycoLiquidityFacility.setAdapterConfigs.selector, _setAdapterConfigDelay);
    }

    /**
     * @notice Rebalances RoyUSD liquidity in a money market to achieve the target borrow rate
     * @dev Queries the adapter for required operations (supply/withdraw) and executes them within configured limits
     * @param _adapter The address of the adapter for the money market to rebalance
     */
    function rebalance(address _adapter) external {
        // Retrieve the adapter config
        MoneyMarketConfig memory config = adapterToConfig[_adapter];

        // Get the operation to execute in order to hit the target borrow rate for this money market
        (Operation op, uint256 amount) = ILiquidityFacilityAdapter(_adapter).getOpToHitTargetBorrowRate(config.targetBorrowRateRAY);
        // Return if no operation to execute
        if (op == Operation.NOP) return;

        // Retrieve the amount of RoyUSD currently supplied in the money market
        uint256 currentlySupplied = ILiquidityFacilityAdapter(_adapter).execLiquidityQuery();
        if (op == Operation.SUPPLY) {
            // Compute the amount to supply (bounded by the configured supply cap)
            uint256 amountToSupply = config.supplyCap > currentlySupplied + amount ? amount : config.supplyCap - currentlySupplied;
            // Mint the amount of RoyUSD to supply to the adapter
            IRoyUSD(ROY_USD).mint(_adapter, amountToSupply);
            // Supply the RoyUSD to the money market
            ILiquidityFacilityAdapter(_adapter).allocateLiquidity(amountToSupply);
            emit RoyUSDSupplied(_adapter, amountToSupply);
        } else if (op == Operation.WITHDRAW) {
            // TODO: Account for interest earned. Don't burn interest, transfer to the treasury.
            // Compute the amount to withdraw (bounded by the amount currently supplied)
            uint256 amountToWithdraw = amount > currentlySupplied ? currentlySupplied : amount;
            // Withdraw the RoyUSD from the money market
            ILiquidityFacilityAdapter(_adapter).freeLiquidity(amountToWithdraw);
            // Burn the RoyUSD withdrawn
            IRoyUSD(ROY_USD).burn(amountToWithdraw);
            emit RoyUSDWithdrawn(_adapter, amountToWithdraw);
        }
    }

    /**
     * @notice Configures adapter parameters for a specific money market
     * @dev Only the owner or addresses with OPEN_MARKET_DESK role can call this function.
     * @param _adapter The address of the adapter to configure
     * @param _targetBorrowRateRAY The target borrow rate in RAY (27 decimal precision)
     * @param _supplyCap The maximum amount of RoyUSD that can be supplied to this money market
     */
    function setAdapterConfig(
        address _adapter,
        uint96 _targetBorrowRateRAY,
        uint160 _supplyCap
    )
        external
        onlyOwnerOrRolesWithDelay(RoycoRoles.OPEN_MARKET_DESK)
    {
        _setAdapterConfig(_adapter, _targetBorrowRateRAY, _supplyCap);
    }

    /**
     * @notice Batch configures adapter parameters for multiple money markets
     * @dev Only the owner or addresses with OPEN_MARKET_DESK role can call this function.
     * @param _adapters Array of adapter addresses to configure
     * @param _targetBorrowRatesRAY Array of target borrow rates corresponding to each adapter, in RAY (27 decimal precision)
     * @param _supplyCaps Array of supply caps corresponding to each adapter
     */
    function setAdapterConfigs(
        address[] calldata _adapters,
        uint96[] calldata _targetBorrowRatesRAY,
        uint160[] calldata _supplyCaps
    )
        external
        onlyOwnerOrRolesWithDelay(RoycoRoles.OPEN_MARKET_DESK)
    {
        _setAdapterConfigs(_adapters, _targetBorrowRatesRAY, _supplyCaps);
    }

    /**
     * @dev Internal helper function to batch set adapter configurations for multiple money markets
     * @param _adapters Array of adapter addresses to configure
     * @param _targetBorrowRatesRAY Array of target borrow rates for each adapter in RAY (27 decimal precision)
     * @param _supplyCaps Array of supply caps for each adapter
     */
    function _setAdapterConfigs(address[] calldata _adapters, uint96[] calldata _targetBorrowRatesRAY, uint160[] calldata _supplyCaps) internal {
        // Ensure arrays are identically sized
        uint256 numAdapters = _adapters.length;
        require(numAdapters == _targetBorrowRatesRAY.length && numAdapters == _supplyCaps.length, ArrayLengthMismatch());

        // Set configs for each
        for (uint256 i = 0; i < numAdapters; ++i) {
            _setAdapterConfig(_adapters[i], _targetBorrowRatesRAY[i], _supplyCaps[i]);
        }
    }

    /**
     * @dev Internal helper function to set adapter configuration for a money market
     * @param _adapter The address of the adapter to update the configuration for
     * @param _targetBorrowRateRAY The target borrow rate in RAY (27 decimal precision)
     * @param _supplyCap The maximum amount of RoyUSD that can be supplied to this money market
     */
    function _setAdapterConfig(address _adapter, uint96 _targetBorrowRateRAY, uint160 _supplyCap) internal {
        // Set the adapter configuration
        adapterToConfig[_adapter] = MoneyMarketConfig(_targetBorrowRateRAY, _supplyCap);

        emit AdapterConfigSet(_adapter, _targetBorrowRateRAY, _supplyCap);
    }
}
