// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { IERC20Metadata } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/ERC20.sol";
import { IERC20, SafeERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/utils/SafeERC20.sol";
import { Math } from "../../lib/openzeppelin-contracts/contracts/utils/math/Math.sol";
import { RoycoAuth, RoycoRoles } from "../auth/RoycoAuth.sol";
import { IRoyUSD } from "../interfaces/IRoyUSD.sol";
import { IRoycoReserve } from "../interfaces/IRoycoReserve.sol";
import { CollateralRegistry } from "./base/CollateralRegistry.sol";

/**
 * @title RoycoTeller
 * @notice The Teller enables minting/buying and redeeming/selling RoyUSD in exchange for specific collateral assets.
 *         This acts as the defacto Peg Stability Module (PSM) for RoyUSD, enabling peg arbitrage and consequently
 *         keeping the market price of RoyUSD tethered to 1 USD.
 */
contract RoycoTeller is RoycoAuth, CollateralRegistry {
    using SafeERC20 for IERC20;

    /// @notice The reserve contract that holds the RoyUSD collateral, revenues, and unstaked assets
    address public immutable RESERVE;

    /**
     * @notice Emitted when RoyUSD is minted against collateral
     * @param minter The address that initiated the mint
     * @param recipient The address that received the minted RoyUSD
     * @param royUsdAmount The amount of RoyUSD minted
     * @param collateralAsset The collateral asset used for minting
     * @param collateralAmount The amount of collateral deposited
     */
    event Mint(address indexed minter, address indexed recipient, uint256 royUsdAmount, address collateralAsset, uint256 collateralAmount);

    /**
     * @notice Emitted when RoyUSD is redeemed for a single collateral asset
     * @param redeemer The address that initiated the redemption
     * @param recipient The address that received the collateral
     * @param royUsdAmount The amount of RoyUSD burned
     * @param collateralAsset The collateral asset redeemed
     * @param collateralAmount The amount of collateral received
     */
    event Redeem(address indexed redeemer, address indexed recipient, uint256 royUsdAmount, address collateralAsset, uint256 collateralAmount);

    /**
     * @notice Emitted when RoyUSD is redeemed for multiple collateral assets
     * @param redeemer The address that initiated the redemption
     * @param recipient The address that received the collateral
     * @param totalRoyUsdAmount The total amount of RoyUSD burned
     * @param collateralAssets Array of collateral assets redeemed
     * @param collateralAmounts Array of collateral amounts received
     */
    event Redeem(address indexed redeemer, address indexed recipient, uint256 totalRoyUsdAmount, address[] collateralAssets, uint256[] collateralAmounts);

    /// @notice Error thrown when insufficient reserves exist for redemption
    error InsufficientReserves();

    /**
     * @notice Initializes the Royco Teller (PSM)
     * @param _owner The administator responsible for granting and revoking authorizations for restricted functions
     * @param _royUSD The RoyUSD token contract address
     * @param _reserve The RoyUSD reserve contract address
     * @param _collateralAssets Array of initial collateral asset addresses to approve
     * @param collateralAssetUpdateDelay The delay for the collateral asset update functions
     */
    constructor(
        address _owner,
        address _royUSD,
        address _reserve,
        address[] memory _collateralAssets,
        uint256 collateralAssetUpdateDelay
    )
        RoycoAuth(_owner)
        CollateralRegistry(_royUSD, _collateralAssets)
    {
        // Set immutable state
        RESERVE = _reserve;

        // Update the execution delay for the collateral asset update function
        _updateExecutionDelay(RoycoTeller.addCollateralAsset.selector, collateralAssetUpdateDelay);
        _updateExecutionDelay(RoycoTeller.removeCollateralAsset.selector, collateralAssetUpdateDelay);
    }

    /**
     * @notice Mints RoyUSD tokens by depositing approved collateral assets
     * @dev Transfers collateral from caller to the reserve and mints equivalent RoyUSD to recipient
     * @dev Restricted to the MINTER_ROLE
     * @param _amountToMint The amount of RoyUSD to buy/mint
     * @param _collateralAsset The approved collateral asset to use to buy/mint RoyUSD
     * @param _recipient The address to receive the minted RoyUSD tokens
     */
    function mint(uint256 _amountToMint, address _collateralAsset, address _recipient) external onlyRoles(RoycoRoles.MINTER) {
        // Calculate the cost of buying/minting the specified amount of RoyUSD from the Teller
        // Round up in favor of the Teller
        uint256 costInCollateral = _computeCostInCollateralAsset(_amountToMint, _getPricePerRoyUSD(_collateralAsset), Math.Rounding.Ceil);

        // Debit the cost of minting in the collateral asset from the minter
        IERC20(_collateralAsset).safeTransferFrom(msg.sender, RESERVE, costInCollateral);

        // Credit RoyUSD to the minter
        IRoyUSD(ROY_USD).mint(_recipient, _amountToMint);

        emit Mint(msg.sender, _recipient, _amountToMint, _collateralAsset, costInCollateral);
    }

    /**
     * @notice Redeems RoyUSD tokens for a specific collateral asset
     * @dev Burns RoyUSD from caller and transfers equivalent collateral from reserve to recipient
     * @dev Restricted to the REDEEMER_ROLE
     * @param _amountToRedeem The amount of RoyUSD to sell/redeem
     * @param _collateralAsset The collateral asset to sell/redeem RoyUSD for
     * @param _recipient The address to receive the collateral assets
     */
    function redeem(uint256 _amountToRedeem, address _collateralAsset, address _recipient) external onlyRoles(RoycoRoles.REDEEMER) {
        // Debit RoyUSD from the redeemer
        IRoyUSD(ROY_USD).burnFrom(msg.sender, _amountToRedeem);

        // Calculate the amount of collateral the redeemer bought from the Teller for the specified amount of RoyUSD
        // Round down in favor of the Teller
        uint256 collateralBought = _computeCostInCollateralAsset(_amountToRedeem, _getPricePerRoyUSD(_collateralAsset), Math.Rounding.Floor);

        // Transfer the purchased collateral assets from the reserve to the redeemer's specified recipient
        IRoycoReserve(RESERVE).freeReserves(_collateralAsset, _recipient, collateralBought);

        emit Redeem(msg.sender, _recipient, _amountToRedeem, _collateralAsset, collateralBought);
    }

    /**
     * @notice Redeems RoyUSD tokens for available collateral assets in reserve holdings
     * @dev Burns RoyUSD from caller and greedily transfers a basket of available collateral from reserve
     * @dev Restricted to the REDEEMER_ROLE
     * @param _amountToRedeem The amount of RoyUSD to burn
     * @param _recipient The address to receive the collateral assets
     */
    function redeem(uint256 _amountToRedeem, address _recipient) external onlyRoles(RoycoRoles.REDEEMER) {
        // Debit RoyUSD from the redeemer
        IRoyUSD(ROY_USD).burnFrom(msg.sender, _amountToRedeem);

        // Declare variables for event emission
        uint256 numCollateralAssets = _getNumCollateralAssets();
        address[] memory assetsBought = new address[](numCollateralAssets);
        uint256[] memory amountsBought = new uint256[](numCollateralAssets);
        uint256 numCollateralsBought;

        // Variable for keeping tracking of how much RoyUSD remains to be redeemed/sold
        uint256 amountToRedeem = _amountToRedeem;
        for (uint256 i = 0; i < numCollateralAssets; ++i) {
            // Get the amount of the collateral asset held in the reserve
            address collateralAsset = _getCollateralAsset(i);
            uint256 availableCollateral = IRoycoReserve(RESERVE).getReserveTotalBalance(collateralAsset);
            if (availableCollateral == 0) continue;

            // Calculate the amount of collateral the redeemer is buying from the Teller for the remaining amount of RoyUSD being redeemed
            // Round down in favor of the Teller
            uint256 pricePerRoyUSD = _getPricePerRoyUSD(collateralAsset);
            uint256 collateralToBuy = _computeCostInCollateralAsset(amountToRedeem, pricePerRoyUSD, Math.Rounding.Floor);
            if (collateralToBuy == 0) continue;

            // At this point, some of this collateral asset will be bought to facilitate the redemption
            assetsBought[numCollateralsBought] = collateralAsset;

            // If the remaning RoyUSD can be sold in exchange for this collateral asset, fulfill the redemption
            if (availableCollateral >= collateralToBuy) {
                // Mark the redemption as fulfilled
                amountToRedeem = 0;
                // Transfer the purchased collateral assets from the reserve to the redeemer's specified recipient
                IRoycoReserve(RESERVE).freeReserves(collateralAsset, _recipient, collateralToBuy);
                amountsBought[numCollateralsBought++] = collateralToBuy;
                break;
            } else {
                // Reduce the redemption amount by the amount of RoyUSD sold in exchange for the available collateral
                amountToRedeem -= _computeCostInRoyUSD(availableCollateral, pricePerRoyUSD, Math.Rounding.Ceil);
                // Transfer the purchased collateral assets from the reserve to the redeemer's specified recipient
                IRoycoReserve(RESERVE).freeReserves(collateralAsset, _recipient, availableCollateral);
                amountsBought[numCollateralsBought++] = availableCollateral;
            }
        }

        // Ensure that the entire specified amount has been redeemed
        require(amountToRedeem == 0, InsufficientReserves());

        // Resize the arrays for event emission
        assembly ("memory-safe") {
            mstore(assetsBought, numCollateralsBought)
            mstore(amountsBought, numCollateralsBought)
        }

        emit Redeem(msg.sender, _recipient, _amountToRedeem, assetsBought, amountsBought);
    }

    /**
     * @notice Adds a new collateral asset to the approved registry
     * @dev Only authorized addresses can call this function
     * @dev Restricted to the ADMIN_ROLE
     * @param _collateralAsset The address of the collateral asset to add
     */
    function addCollateralAsset(address _collateralAsset) external onlyOwnerOrRolesWithDelay(RoycoRoles.COLLATERAL_MANAGER) {
        _addCollateralAsset(_collateralAsset);
    }

    /**
     * @notice Removes a collateral asset from the approved registry
     * @dev Only authorized addresses can call this function
     * @dev Restricted to the ADMIN_ROLE
     * @param _collateralAsset The address of the collateral asset to remove
     */
    function removeCollateralAsset(address _collateralAsset) external onlyOwnerOrRolesWithDelay(RoycoRoles.COLLATERAL_MANAGER) {
        _removeCollateralAsset(_collateralAsset);
    }
}
