// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { ERC20Permit } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/extensions/ERC20Permit.sol";
import { ERC20, ERC4626, IERC20Metadata, Math } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/extensions/ERC4626.sol";
import { IERC20, SafeERC20 } from "../../lib/openzeppelin-contracts/contracts/token/ERC20/utils/SafeERC20.sol";
import { SafeCast } from "../../lib/openzeppelin-contracts/contracts/utils/math/SafeCast.sol";
import { RoycoAuth, RoycoRoles } from "../auth/RoycoAuth.sol";
import { IRoycoReserve } from "../interfaces/IRoycoReserve.sol";

/**
 * @title StakedRoyUSD
 * @notice A vault for staking RoyUSD tokens to earn yield with time-locked unstaking.
 * @dev This vault is not 4626 compliant for users without the EXPEDITED_UNSTAKER role
 *      if it is configured with a non-zero unstaking duration.
 */
contract StakedRoyUSD is RoycoAuth, ERC4626, ERC20Permit {
    using SafeERC20 for IERC20;
    using SafeCast for *;

    /// @notice The maximum duration (in seconds) the unstaking duration can be set to
    uint256 public constant MAX_UNSTAKING_DURATION = 180 days;

    /// @notice The duration (in seconds) after yield is distributed to this contract that the yield will linearly vest for
    /// @dev Yield distributions should generally follow this cadence
    uint256 public constant VESTING_DURATION = 7 days;

    /// @notice The precision/decimals of sRoyUSD. Identical to that of RoyUSD.
    uint8 internal immutable SHARES_PRECISION;

    /// @notice The address of the RoycoReserve contract that holds unstaked assets
    address public immutable RESERVE;

    /**
     * @notice Stores information for commenced unstake(s) invoked by the staker
     * @custom:field amountToUnstake The amount of RoyUSD assets to be unstaked
     * @custom:field unstakeableAt The timestamp when the unstaked assets can be withdrawn
     */
    struct UnstakingState {
        uint216 amountToUnstake;
        uint40 unstakeableAt;
    }

    /// @notice Maps each staker address to their unstaking state
    mapping(address staker => UnstakingState state) public stakerToUnstakingState;

    /// @notice The duration (in seconds) after unstaking a staker must wait to withdraw their sRoyUSD for the underlying
    uint256 public unstakingDuration;

    /// @notice The amount of yield from the last distribution that is still vesting
    uint216 public lastDistributionAmount;

    /// @notice The timestamp when the last yield distribution was initiated
    uint40 public lastDistributionTimestamp;

    /**
     * @notice Emitted when yield is distributed to the staking contract
     * @param distributionAmount The amount of RoyUSD yield distributed
     */
    event YieldDistributed(uint256 distributionAmount);

    /**
     * @notice Emitted when a staker begins the unstaking process
     * @param staker The address of the staker
     * @param sharesBurned The amount of sRoyUSD shares burned
     * @param assetsToUnstake The amount of RoyUSD assets to be unstaked
     * @param assetsUnstakeableAt The timestamp when assets can be withdrawn
     */
    event UnstakingCommenced(address indexed staker, uint256 sharesBurned, uint216 assetsToUnstake, uint40 assetsUnstakeableAt);

    /**
     * @notice Emitted when a staker completes the unstaking process and withdraws their assets
     * @param staker The address of the staker
     * @param assetsUnstaked The amount of RoyUSD assets unstaked
     */
    event AssetsUnstaked(address indexed staker, uint256 assetsUnstaked);

    /**
     * @notice Emitted when the unstaking duration is updated
     * @param unstakingDuration The new unstaking duration in seconds
     */
    event UnstakingDurationSet(uint256 unstakingDuration);

    /**
     * @notice Emitted when the staker blacklist is updated
     * @param staker The address of the staker
     * @param blacklisted Boolean indicating whether the staker was added or removed from the blacklist
     */
    event BlacklistUpdated(address indexed staker, bool blacklisted);

    /// @notice Thrown when trying to set an unstaking duration that exceeds the maximum allowed
    error InvalidUnstakingDuration();

    /// @notice Thrown when trying to unstake without commencing unstaking first
    error NothingToUnstake();

    /// @notice Thrown when trying to commence unstaking while having assets that can already be unstaked
    error MustUnstakeAssets();

    /// @notice Thrown when trying to withdraw unstaked assets before the unstaking period has completed
    error UnstakingPeriodInProgress();

    /// @notice Thrown when trying to call ERC4626 functions while unstaking duration is active
    error UnsupportedFunction();

    /// @notice Thrown when trying to distribute yield while previous yield is still vesting
    error VestingInProgress();

    /// @notice Thrown when a blacklisted address attempts to stake, unstake, or transfer assets
    error Blacklisted();

    /// @notice Given an amount, it must be greater than 0
    error InvalidAmount();

    /**
     * @notice Modifier to ensure that expedited unstaking is enabled for the caller.
     * @dev ERC4626 withdraw/redeem functions are only available if the caller has the EXPEDITED_UNSTAKER role or when unstaking duration is 0
     */
    modifier checkExpeditedUnstakingEnabled() {
        require(hasAnyRole(msg.sender, RoycoRoles.EXPEDITED_UNSTAKER) || unstakingDuration == 0, UnsupportedFunction());
        _;
    }

    /**
     * @notice Modifier to prevent blacklisted addresses from performing operations
     * @dev Checks if the given address has the BLACKLISTED_STAKER role. Null address cannot be blacklisted.
     * @param _user The address to check for blacklist status
     */
    modifier checkBlacklisted(address _user) {
        require(_user == address(0) || !hasAnyRole(_user, RoycoRoles.BLACKLISTED_STAKER), Blacklisted());
        _;
    }

    /**
     * @notice Ensures the provided amount is greater than zero
     * @dev Reverts with InvalidAmount error if the amount is zero
     * @param _amount The amount to validate
     */
    modifier checkNonZeroAmount(uint256 _amount) {
        require(_amount > 0, InvalidAmount());
        _;
    }

    /**
     * @notice Initializes the StakedRoyUSD contract
     * @param _owner The administrator responsible for granting and revoking roles for restricted functions
     * @param _royUSD The address of the RoyUSD token that will be staked
     * @param _reserve The address of the RoycoReserve contract that holds unstaked assets
     * @param _unstakingDuration The initial unstaking duration in seconds (must be <= MAX_UNSTAKING_DURATION)
     * @param _initialDepositor The address that will deposit the initial assets
     * @param _initialDepositAssets The amount of assets to deposit
     * @param _initialDepositRecipient The address that will receive the initial assets
     * @param _setWhitelistDelay The delay for the whitelist update function
     * @param _setUnstakingDurationDelay The delay for the unstaking duration update function
     */
    constructor(
        address _owner,
        address _royUSD,
        address _reserve,
        uint256 _unstakingDuration,
        address _initialDepositor,
        uint256 _initialDepositAssets,
        address _initialDepositRecipient,
        uint256 _setWhitelistDelay,
        uint256 _setUnstakingDurationDelay
    )
        RoycoAuth(_owner)
        ERC20("Staked RoyUSD", "sRoyUSD")
        ERC20Permit("Staked RoyUSD")
        ERC4626(IERC20(_royUSD))
    {
        SHARES_PRECISION = IERC20Metadata(_royUSD).decimals();
        RESERVE = _reserve;

        // Validate and set the unstaking duration
        _setUnstakingDuration(_unstakingDuration);

        // Seed the vault to mitigate inflation attacks
        _deposit(_initialDepositor, _initialDepositRecipient, _initialDepositAssets, previewDeposit(_initialDepositAssets));

        // Update the execution delay for the whitelist update function
        _updateExecutionDelay(StakedRoyUSD.blacklistStaker.selector, _setWhitelistDelay);
        _updateExecutionDelay(StakedRoyUSD.whitelistStaker.selector, _setWhitelistDelay);

        // Update the execution delay for the unstaking duration update function
        _updateExecutionDelay(StakedRoyUSD.setUnstakingDuration.selector, _setUnstakingDurationDelay);
    }

    /**
     * @notice Initiates the unstaking process for a specified amount of RoyUSD assets
     * @dev Burns sRoyUSD shares corresponding to the asset amount and starts the unstaking timer
     * @param _assets The amount of RoyUSD assets to unstake
     * @return shares The amount of sRoyUSD shares burned (rounded up for precision)
     */
    function commenceAssetsUnstakingPeriod(uint256 _assets) external returns (uint256 shares) {
        // Calculate the shares to burn for the specified amount of assets to unstake
        shares = _convertToShares(_assets, Math.Rounding.Ceil);

        // Commence the unstaking period and burn the corresponding amount of shares
        _commenceUnstakingPeriod(_assets, shares);
    }

    /**
     * @notice Initiates the unstaking process for a specified amount of sRoyUSD shares
     * @dev Burns the specified shares and calculates corresponding RoyUSD assets to unstake.
     *      This provides an alternative to commenceAssetsUnstakingPeriod() for users who
     *      prefer to specify the exact number of shares to unstake rather than assets.
     * @param _shares The amount of sRoyUSD shares to burn and unstake
     * @return assets The amount of RoyUSD assets that will be unstaked (rounded down for precision)
     */
    function commenceSharesUnstakingPeriod(uint256 _shares) external returns (uint256 assets) {
        // Calculate the assets to unstake for the specified amount of shares to burn
        assets = _convertToAssets(_shares, Math.Rounding.Floor);

        // Commence the unstaking period and burn the corresponding amount of shares
        _commenceUnstakingPeriod(assets, _shares);
    }

    /**
     * @notice Completes the unstaking process and transfers RoyUSD assets to the recipient
     * @dev Can only be called after the unstaking period has elapsed. Both the caller and recipient
     *      must not be blacklisted.
     * @param _recipient The address that will receive the unstaked RoyUSD assets
     */
    function unstake(address _recipient) external checkBlacklisted(msg.sender) checkBlacklisted(_recipient) {
        // Retrieve and validate the staker's commenced unstaking information
        UnstakingState storage unstakingState = stakerToUnstakingState[msg.sender];
        uint216 amountToUnstake = unstakingState.amountToUnstake;
        require(amountToUnstake > 0, NothingToUnstake());
        require(block.timestamp >= unstakingState.unstakeableAt, UnstakingPeriodInProgress());

        // Clear the unstaking state
        delete unstakingState.amountToUnstake;
        delete unstakingState.unstakeableAt;

        // Send the unstaked assets to the user
        IRoycoReserve(RESERVE).freeUnstakedAssets(_recipient, amountToUnstake);

        emit AssetsUnstaked(msg.sender, amountToUnstake);
    }

    /**
     * @notice Distributes yield to the staking contract for linear vesting over VESTING_DURATION
     * @dev Only callable by addresses with YIELD_DISTRIBUTOR role. Reverts if previous yield is still vesting.
     * @param _distributionAmount The amount of RoyUSD yield to distribute to stakers
     */
    function distributeYield(uint256 _distributionAmount) external onlyRoles(RoycoRoles.YIELD_DISTRIBUTOR) {
        // Commence the new yield distribution
        _commenceYieldDistribution(_distributionAmount);

        // Transfer the yield into the staking contract
        IERC20(asset()).safeTransferFrom(msg.sender, address(this), _distributionAmount);

        emit YieldDistributed(_distributionAmount);
    }

    /**
     * @notice Returns the amount of yield that is still vesting and not yet included in totalAssets
     * @dev Calculates unvested amount based on linear vesting over VESTING_DURATION
     * @return The amount of RoyUSD yield that is still vesting
     */
    function getUnvestedAssets() public view returns (uint256) {
        uint256 totalAssetsToVest = lastDistributionAmount;
        uint256 elapsed = block.timestamp - lastDistributionTimestamp;
        return VESTING_DURATION > elapsed ? totalAssetsToVest - ((totalAssetsToVest * elapsed) / VESTING_DURATION) : 0;
    }

    /**
     * @notice Returns the total amount of vested RoyUSD assets managed by the vault
     * @dev Overrides ERC4626 to exclude unvested yield from the total asset calculation
     * @return The total amount of vested RoyUSD tokens available for share calculations
     */
    function totalAssets() public view override returns (uint256) {
        return IERC20(asset()).balanceOf(address(this)) - getUnvestedAssets();
    }

    /**
     * @inheritdoc ERC20
     * @dev Required override since both ERC4626 and ERC20 define this function.
     *      Uses the same decimals as the underlying RoyUSD asset.
     */
    function decimals() public view override(ERC4626, ERC20) returns (uint8) {
        return SHARES_PRECISION;
    }

    /**
     * @inheritdoc ERC4626
     * @dev Adds a check to ensure that expedited unstaking is enabled.
     *      Only enabled for users with the EXPEDITED_UNSTAKER role or when the unstaking duration is 0.
     *      When disabled, use commenceAssetsUnstakingPeriod() instead.
     */
    function withdraw(uint256 _assets, address _receiver, address _owner) public override checkExpeditedUnstakingEnabled returns (uint256) {
        return super.withdraw(_assets, _receiver, _owner);
    }

    /**
     * @inheritdoc ERC4626
     * @dev Adds a check to ensure that expedited unstaking is enabled.
     *      Only enabled for users with the EXPEDITED_UNSTAKER role and or the unstaking duration is 0.
     *      When disabled, use commenceAssetsUnstakingPeriod() instead.
     */
    function redeem(uint256 _shares, address _receiver, address _owner) public override checkExpeditedUnstakingEnabled returns (uint256) {
        return super.redeem(_shares, _receiver, _owner);
    }

    /**
     * @notice Updates the unstaking duration that stakers must wait before withdrawing assets
     * @dev Only callable by the owner or addresses with STAKING_MANAGER role
     * @param _newUstakingDuration The new unstaking duration in seconds (must be <= MAX_UNSTAKING_DURATION)
     */
    function setUnstakingDuration(uint24 _newUstakingDuration) external onlyOwnerOrRolesWithDelay(RoycoRoles.STAKING_MANAGER) {
        _setUnstakingDuration(_newUstakingDuration);
    }

    /**
     * @notice Adds an address to the blacklist, preventing all token operations
     * @dev Only callable by the owner or addresses with STAKING_MANAGER role.
     *      Blacklisted addresses cannot transfer, stake, unstake, or receive tokens.
     * @param _staker The address to blacklist
     */
    function blacklistStaker(address _staker) external onlyOwnerOrRolesWithDelay(RoycoRoles.BLACKLIST_MANAGER | RoycoRoles.STAKING_MANAGER) {
        _grantRoles(_staker, RoycoRoles.BLACKLISTED_STAKER);
        emit BlacklistUpdated(_staker, true);
    }

    /**
     * @notice Removes an address from the blacklist, restoring normal token operations
     * @dev Only callable by the owner or addresses with STAKING_MANAGER role.
     *      Once whitelisted, the address can resume all normal token operations.
     * @param _staker The address to remove from the blacklist
     */
    function whitelistStaker(address _staker) external onlyOwnerOrRolesWithDelay(RoycoRoles.BLACKLIST_MANAGER | RoycoRoles.STAKING_MANAGER) {
        _removeRoles(_staker, RoycoRoles.BLACKLISTED_STAKER);
        emit BlacklistUpdated(_staker, false);
    }

    /**
     * @notice Prevents blacklisted addresses from removing themselves from the blacklist
     * @dev Overrides RoycoAuth to disable role renouncement, ensuring blacklisted
     *      addresses cannot unilaterally remove their blacklist status. Only authorized
     *      managers can remove addresses from the blacklist via whitelistStaker().
     */
    function renounceRoles(uint256) public payable override {
        revert UnsupportedFunction();
    }

    /**
     * @notice Internal function to start the unstaking process
     * @dev Burns shares, transfers assets to reserve, and updates the staker's unstake state
     * @param _assets The amount of RoyUSD assets to unstake
     * @param _shares The amount of sRoyUSD shares to burn
     */
    function _commenceUnstakingPeriod(uint256 _assets, uint256 _shares) internal {
        // Withdraw the assets to the reserve and burn the shares
        _withdraw(msg.sender, RESERVE, msg.sender, _assets, _shares);

        // Modify the current unstake state for the staker
        // Effectively resets the unstake duration for any previously unstaked but unwithdrawable assets
        UnstakingState storage unstakingState = stakerToUnstakingState[msg.sender];

        // Ensure that there are no assets that can but haven't been unstaked
        uint40 unstakeableAt = unstakingState.unstakeableAt;
        require(unstakeableAt == 0 || block.timestamp < unstakeableAt, MustUnstakeAssets());

        // Commence this unstake
        uint216 assetsToUnstake = (unstakingState.amountToUnstake += _assets.toUint216());
        unstakingState.unstakeableAt = unstakeableAt = (block.timestamp + unstakingDuration).toUint40();

        emit UnstakingCommenced(msg.sender, _shares, assetsToUnstake, unstakeableAt);
    }

    /**
     * @notice Internal function to initiate yield distribution with linear vesting
     * @dev Ensures no previous yield is vesting before starting new distribution
     * @param _distributionAmount The amount of RoyUSD yield to distribute
     */
    function _commenceYieldDistribution(uint256 _distributionAmount) internal {
        // Make sure all the assets are vested
        require(getUnvestedAssets() == 0, VestingInProgress());

        // Update the last distribution state
        lastDistributionAmount = _distributionAmount.toUint216();
        lastDistributionTimestamp = block.timestamp.toUint40();
    }

    /**
     * @notice Internal function to set the unstaking duration
     * @dev Validates that the duration doesn't exceed the maximum allowed
     * @param _unstakingDuration The new unstaking duration in seconds
     */
    function _setUnstakingDuration(uint256 _unstakingDuration) internal {
        require(_unstakingDuration <= MAX_UNSTAKING_DURATION, InvalidUnstakingDuration());
        unstakingDuration = _unstakingDuration;
        emit UnstakingDurationSet(_unstakingDuration);
    }

    /**
     * @inheritdoc ERC4626
     * @dev Adds blacklist enforcement. The caller must not be blacklisted.
     */
    function _deposit(
        address _caller,
        address _receiver,
        uint256 _assets,
        uint256 _shares
    )
        internal
        override
        checkBlacklisted(_caller)
        checkNonZeroAmount(_assets)
        checkNonZeroAmount(_shares)
    {
        super._deposit(_caller, _receiver, _assets, _shares);
    }

    /**
     * @inheritdoc ERC4626
     * @dev Adds blacklist enforcement. The caller and receiver must not be blacklisted.
     */
    function _withdraw(
        address _caller,
        address _receiver,
        address _owner,
        uint256 _assets,
        uint256 _shares
    )
        internal
        override
        checkBlacklisted(_caller)
        checkBlacklisted(_receiver)
        checkNonZeroAmount(_assets)
        checkNonZeroAmount(_shares)
    {
        super._withdraw(_caller, _receiver, _owner, _assets, _shares);
    }

    /**
     * @inheritdoc ERC20
     * @dev Adds blacklist enforcement. Both the sender and receiver must not be blacklisted.
     */
    function _update(address _from, address _to, uint256 _value) internal override checkBlacklisted(_from) checkBlacklisted(_to) {
        super._update(_from, _to, _value);
    }
}
