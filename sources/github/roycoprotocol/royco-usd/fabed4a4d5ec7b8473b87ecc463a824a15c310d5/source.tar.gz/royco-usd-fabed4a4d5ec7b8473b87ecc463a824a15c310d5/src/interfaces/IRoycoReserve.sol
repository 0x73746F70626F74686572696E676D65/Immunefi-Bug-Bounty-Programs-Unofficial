// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

/**
 * @title IRoycoReserve
 * @notice Interface for the RoycoReserve contract that manages collateral assets
 * @dev Defines the external functions for transferring collateral from the reserve
 */
interface IRoycoReserve {
    /**
     * @notice Transfers unstaked RoyUSD assets from the reserve to a specified recipient
     * @dev Only callable by addresses with the STAKING role
     * @param _recipient The address that will receive the RoyUSD tokens
     * @param _amount The amount of RoyUSD tokens to transfer
     */
    function freeUnstakedAssets(address _recipient, uint256 _amount) external;

    /**
     * @notice Sets or updates the adapter for a collateral asset
     * @dev Only owner or RESERVE_MANAGER can call. Set to address(0) to disable deployment for an asset
     */
    function setCollateralAdapter(address _collateralAsset, address _adapter) external;

    /**
     * @notice Deposits collateral into the configured adapter
     * @param _collateralAsset The ERC20 asset to deposit
     * @param _amount The amount to deposit
     */
    function hypothecateReserves(address _collateralAsset, uint256 _amount) external;

    /**
     * @notice Withdraws assets from the configured adapter to the reserve
     * @param _collateralAsset The ERC20 asset to withdraw
     * @param _amount The amount to withdraw
     */
    function withdrawAssetsToReserve(address _collateralAsset, uint256 _amount) external;

    /**
     * @notice Transfers collateral assets from the reserve to a specified recipient
     * @dev Only callable by addresses with the RESERVE_MANAGER, TELLER, or LENDER role
     * @param _collateralAsset The ERC20 asset to withdraw
     * @param _amount The amount to withdraw
     */
    function freeReserves(address _collateralAsset, address _recipient, uint256 _amount) external;

    /**
     * @notice Returns the total balance of a collateral asset in the reserve
     * @param _collateralAsset The ERC20 asset to get the balance of
     * @return The total balance of the asset
     */
    function getReserveTotalBalance(address _collateralAsset) external view returns (uint256);
}
