// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { RoycoOFT } from "../src/cross-chain/RoycoOFT.sol";
import { RoycoOFTAdapter } from "../src/cross-chain/RoycoOFTAdapter.sol";
import { RoycoOFTBase } from "../src/cross-chain/RoycoOFTBase.sol";

import { Create3Factory } from "../src/utils/Factory.sol";
import { Create2DeployUtils } from "./utils/Create2DeployUtils.sol";
import { Create3DeployUtils } from "./utils/Create3DeployUtils.sol";
import { ILayerZeroEndpointV2 } from "lib/LayerZero-v2/packages/layerzero-v2/evm/protocol/contracts/interfaces/ILayerZeroEndpointV2.sol";

import { RateLimiter } from "lib/devtools/packages/oapp-evm/contracts/oapp/utils/RateLimiter.sol";
import { Script } from "lib/forge-std/src/Script.sol";

import { console2 } from "lib/forge-std/src/console2.sol";
import { Strings } from "lib/openzeppelin-contracts/contracts/utils/Strings.sol";

struct LayerZeroChainConfig {
    uint32 eid;
    address lzEndpoint;
}

contract OFTConfigure is Script, Create3DeployUtils {
    // Environment variables
    uint256[] chainIdsToDeployOn = vm.envUint("CHAIN_IDS_TO_DEPLOY_ON", ",");
    uint256 deployerKey = vm.envUint("PRIVATE_KEY");
    bool revertIfAlreadyDeployed = vm.envBool("REVERT_IF_ALREADY_DEPLOYED");
    address canonicalTokenAddress = vm.envAddress("CANONICAL_TOKEN_ADDRESS");
    uint256 canonicalChainId = vm.envUint("CANONICAL_CHAIN_ID");
    address ownerAddress = vm.envAddress("OWNER_ADDRESS");
    string name = vm.envString("OFT_TOKEN_NAME");
    string symbol = vm.envString("OFT_TOKEN_SYMBOL");
    Create3Factory factory = Create3Factory(vm.envAddress("CREATE_3_FACTORY_ADDRESS"));
    bool debug = vm.envBool("DEBUG");

    // State
    mapping(uint256 chainId => LayerZeroChainConfig layerZeroChainConfig) layerZeroChainConfig;
    mapping(uint256 chainId => uint256 forkId) forkIds;
    mapping(string contractName => bytes32 salt) deploymentSalts;
    mapping(uint256 chainId => RoycoOFTBase.OFTSetupConfig oftSetupConfig) oftSetupConfigs;

    // Custom errors
    error ForkIdNotFound(uint256 chainId);
    error LzEndpointNotFound(uint256 chainId);
    error OFTNotFound(uint256 chainId);
    error ChainIdNotFound(uint256 chainId);

    constructor() {
        // Setup forks
        for (uint256 i = 0; i < chainIdsToDeployOn.length; i++) {
            forkIds[chainIdsToDeployOn[i]] = vm.createFork(vm.envString(string(abi.encodePacked("RPC_URL_", Strings.toString(chainIdsToDeployOn[i])))));
        }

        // Setup deployment salts
        string memory version = vm.envString("CONTRACTS_DEPLOYMENT_VERSION");
        console2.log("Deployment Version:", version);
        deploymentSalts[type(RoycoOFTAdapter).name] = keccak256(abi.encodePacked("ROYCO_OFT_ADAPTER_", version));
        deploymentSalts[type(RoycoOFT).name] = keccak256(abi.encodePacked("ROYCO_OFT_", version));

        // Setup LayerZero chain configs
        //////// Testnet ////////
        // Sepolia Testnet
        layerZeroChainConfig[11_155_111] = LayerZeroChainConfig({ eid: 40_161, lzEndpoint: 0x6EDCE65403992e310A62460808c4b910D972f10f });
        // Base Sepolia Testnet
        layerZeroChainConfig[84_532] = LayerZeroChainConfig({ eid: 40_245, lzEndpoint: 0x6EDCE65403992e310A62460808c4b910D972f10f });
        // Arbitrum Sepolia Testnet
        layerZeroChainConfig[421_614] = LayerZeroChainConfig({ eid: 40_231, lzEndpoint: 0x6EDCE65403992e310A62460808c4b910D972f10f });
        //////// Mainnet ////////
        // Ethereum Mainnet
        layerZeroChainConfig[1] = LayerZeroChainConfig({ eid: 30_101, lzEndpoint: 0x1a44076050125825900e736c501f859c50fE728c });
        // Base Mainnet
        layerZeroChainConfig[8453] = LayerZeroChainConfig({ eid: 30_184, lzEndpoint: 0x1a44076050125825900e736c501f859c50fE728c });
        // Arbitrum Mainnet
        layerZeroChainConfig[42_161] = LayerZeroChainConfig({ eid: 30_110, lzEndpoint: 0x1a44076050125825900e736c501f859c50fE728c });
    }

    function run() public {
        if (debug) console2.log("Deployer Address:", vm.addr(deployerKey));

        // Generate the cross-linking configuration for the OFT contracts
        _prepareOFTSetupConfigs(chainIdsToDeployOn, canonicalChainId);

        // Deploy RoycoOFTAdapter on the canonical chain
        vm.selectFork(forkIds[canonicalChainId]);
        vm.startBroadcast(deployerKey);

        // Print balance of the deployer
        if (debug) console2.log("Deployer balance:", address(vm.addr(deployerKey)).balance);
        RoycoOFTAdapter oftAdapter;
        {
            if (debug) console2.log("Deploying RoycoOFTAdapter on chain id:", canonicalChainId);
            address lzEndpoint = layerZeroChainConfig[canonicalChainId].lzEndpoint;
            require(lzEndpoint != address(0), LzEndpointNotFound(canonicalChainId));
            oftAdapter = _deployRoycoOFTAdapter(canonicalTokenAddress, lzEndpoint, ownerAddress, oftSetupConfigs[canonicalChainId], revertIfAlreadyDeployed);
            if (debug) console2.log("RoycoOFTAdapter deployed at:", address(oftAdapter), " on chain id:", canonicalChainId);
        }

        vm.stopBroadcast();

        // Deploy the OFT Token Contracts on each chain
        for (uint256 i = 0; i < chainIdsToDeployOn.length; i++) {
            uint256 chainId = chainIdsToDeployOn[i];
            if (chainId == canonicalChainId) continue;

            vm.selectFork(forkIds[chainId]);
            vm.startBroadcast(deployerKey);

            address lzEndpoint = layerZeroChainConfig[chainId].lzEndpoint;
            require(lzEndpoint != address(0), LzEndpointNotFound(chainId));

            if (debug) console2.log("Deploying RoycoOFT on chain id:", chainId);
            RoycoOFT oft = _deployRoycoOFT(name, symbol, lzEndpoint, ownerAddress, oftSetupConfigs[chainId], revertIfAlreadyDeployed);
            if (debug) console2.log("RoycoOFT deployed at:", address(oft), " on chain id:", chainId);

            vm.stopBroadcast();
        }
    }

    // Generate the cross-linking configuration for the OFT contracts
    function _prepareOFTSetupConfigs(uint256[] memory _chainIds, uint256 _canonicalChainId) internal {
        vm.selectFork(forkIds[_canonicalChainId]);
        address expectedAdapterAddress = generateDeterminsticAddress(factory, deploymentSalts[type(RoycoOFTAdapter).name]);
        address expectedOFTAddress = generateDeterminsticAddress(factory, deploymentSalts[type(RoycoOFT).name]);

        for (uint256 i = 0; i < _chainIds.length; i++) {
            uint256 chainId = _chainIds[i];
            RoycoOFTBase.OFTSetupConfig storage oftSetupConfig = oftSetupConfigs[chainId];

            for (uint256 j = 0; j < _chainIds.length; j++) {
                uint256 chainToConfigure = _chainIds[j];
                if (chainToConfigure == chainId) continue;

                // The peer is the OFT contract on the canonical chain
                address peer;
                if (chainToConfigure == _canonicalChainId) {
                    peer = expectedAdapterAddress;
                } else {
                    peer = expectedOFTAddress;
                }

                // Get the LayerZero chain config
                LayerZeroChainConfig storage dstLayerZeroChainConfig = layerZeroChainConfig[chainToConfigure];
                require(dstLayerZeroChainConfig.lzEndpoint != address(0), LzEndpointNotFound(chainToConfigure));

                oftSetupConfig.dstEids.push(dstLayerZeroChainConfig.eid);
                oftSetupConfig.peers.push(bytes32(uint256(uint160(peer))));
            }
        }
    }

    function _deployRoycoOFTAdapter(
        address _canonicalTokenAddress,
        address _lzEndpoint,
        address _owner,
        RoycoOFTBase.OFTSetupConfig memory _oftSetupConfig,
        bool _revertIfAlreadyDeployed
    )
        internal
        returns (RoycoOFTAdapter)
    {
        // Initialize with empty rate limit configs
        RateLimiter.RateLimitConfig[] memory rateLimitConfigs = new RateLimiter.RateLimitConfig[](0);

        bytes memory creationCode =
            abi.encodePacked(type(RoycoOFTAdapter).creationCode, abi.encode(_canonicalTokenAddress, _lzEndpoint, _owner, rateLimitConfigs, _oftSetupConfig));
        (address deployedAddress,) = deployWithSanityChecks(factory, deploymentSalts[type(RoycoOFTAdapter).name], creationCode, _revertIfAlreadyDeployed);

        return RoycoOFTAdapter(deployedAddress);
    }

    function _deployRoycoOFT(
        string memory _name,
        string memory _symbol,
        address _lzEndpoint,
        address _owner,
        RoycoOFTBase.OFTSetupConfig memory _oftSetupConfig,
        bool _revertIfAlreadyDeployed
    )
        internal
        returns (RoycoOFT)
    {
        bytes memory creationCode = abi.encodePacked(type(RoycoOFT).creationCode, abi.encode(_name, _symbol, _lzEndpoint, _owner, _oftSetupConfig));
        (address deployedAddress,) = deployWithSanityChecks(factory, deploymentSalts[type(RoycoOFT).name], creationCode, _revertIfAlreadyDeployed);
        return RoycoOFT(deployedAddress);
    }
}
