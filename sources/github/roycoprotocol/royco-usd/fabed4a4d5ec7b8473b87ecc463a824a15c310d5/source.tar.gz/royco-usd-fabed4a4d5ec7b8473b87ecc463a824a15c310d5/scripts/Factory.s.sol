// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import { Create3Factory } from "../src/utils/Factory.sol";
import { Create2DeployUtils } from "./utils/Create2DeployUtils.sol";
import { Script } from "lib/forge-std/src/Script.sol";
import { console2 } from "lib/forge-std/src/console2.sol";
import { Strings } from "lib/openzeppelin-contracts/contracts/utils/Strings.sol";

contract FactoryDeployScript is Script, Create2DeployUtils {
    bool debug = vm.envBool("DEBUG");
    bytes32 salt = keccak256(abi.encodePacked("ROYCO_CREATE3_FACTORY"));
    uint256 deployerKey = vm.envUint("PRIVATE_KEY");
    uint256[] chainIdsToDeployOn = vm.envUint("CHAIN_IDS_TO_DEPLOY_ON", ",");

    // State
    mapping(uint256 chainId => uint256 forkId) forkIds;

    constructor() {
        for (uint256 i = 0; i < chainIdsToDeployOn.length; i++) {
            forkIds[chainIdsToDeployOn[i]] = vm.createFork(vm.envString(string(abi.encodePacked("RPC_URL_", Strings.toString(chainIdsToDeployOn[i])))));
        }
    }

    function run() public {
        for (uint256 i = 0; i < chainIdsToDeployOn.length; i++) {
            uint256 chainId = chainIdsToDeployOn[i];
            vm.selectFork(forkIds[chainId]);
            vm.startBroadcast(deployerKey);
            (address deployedAddress,) = deployWithSanityChecks(salt, abi.encodePacked(type(Create3Factory).creationCode), false);
            if (debug) console2.log("Factory deployed at:", address(deployedAddress));
            vm.stopBroadcast();
        }
    }
}
