// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.30;

import { Script } from "../../lib/forge-std/src/Script.sol";
import { console2 } from "../../lib/forge-std/src/console2.sol";
import { Create3Factory } from "../../src/utils/Factory.sol";

contract Create3DeployUtils is Script {
    error DeploymentFailed(bytes data);
    error AlreadyDeployed(address deployedAddress);
    error NotDeployedToExpectedAddress(address expectedAddress, address deployedAddress);
    error AddressDoesNotContainBytecode(address deployedAddress);
    error SaltCannotBeZero();

    function deployWithSanityChecks(
        Create3Factory _factory,
        bytes32 _salt,
        bytes memory _creationCode,
        bool _revertIfAlreadyDeployed
    )
        internal
        returns (address, bool isAlreadyDeployed)
    {
        bool debug = vm.envOr("DEBUG", false);

        require(_salt != bytes32(0), SaltCannotBeZero());

        address expectedAddress = _factory.predictDeterministicAddress(_salt);

        if (address(expectedAddress).code.length != 0) {
            if (debug) console2.log("Contract already deployed at: ", expectedAddress);

            require(!_revertIfAlreadyDeployed, AlreadyDeployed(expectedAddress));

            return (expectedAddress, true);
        }

        address addr = _factory.deploy(_creationCode, _salt);

        require(addr == expectedAddress, NotDeployedToExpectedAddress(expectedAddress, addr));
        require(address(addr).code.length != 0, AddressDoesNotContainBytecode(addr));

        if (debug) console2.log("Contract deployed at: ", addr);

        return (addr, false);
    }

    function generateDeterminsticAddress(Create3Factory _factory, bytes32 _salt) internal view returns (address) {
        return _factory.predictDeterministicAddress(_salt);
    }
}
