// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.28;

import { IERC20 } from "../lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol";
import { RoyUSD } from "../src/RoyUSD.sol";
import { RoycoRoles } from "../src/auth/RoycoRoles.sol";
import { AaveV3MarketAdapter } from "../src/market-adapters/aave/AaveV3MarketAdapter.sol";
import { RoycoFlashLender } from "../src/open-market-operations/RoycoFlashLender.sol";
import { RoycoReserve } from "../src/reserve/RoycoReserve.sol";
import { StakedRoyUSD } from "../src/savings/StakedRoyUSD.sol";
import { RoycoTeller } from "../src/teller/RoycoTeller.sol";
import { Create2DeployUtils } from "./utils/Create2DeployUtils.sol";
import { Script } from "lib/forge-std/src/Script.sol";
import { console2 } from "lib/forge-std/src/console2.sol";

struct DeployedContracts {
    RoyUSD royUSD;
    RoycoReserve reserve;
    RoycoTeller teller;
    RoycoFlashLender flashLender;
    StakedRoyUSD sRoyUSD;
}

contract DeployAll is Script, Create2DeployUtils {
    mapping(string contractName => bytes32 salt) public deploymentSalt;

    // Custom errors
    error LenderConfigLengthMismatch();
    error MaxLoanAmountOverflow();
    error FeeBPSOverflow();

    constructor() {
        string memory version = vm.envString("CONTRACTS_DEPLOYMENT_VERSION");
        console2.log("Contracts deployment version:", version);

        deploymentSalt[type(RoyUSD).name] = keccak256(abi.encodePacked("ROY_USD_", version));
        deploymentSalt[type(RoycoReserve).name] = keccak256(abi.encodePacked("ROYCO_RESERVE_", version));
        deploymentSalt[type(RoycoTeller).name] = keccak256(abi.encodePacked("ROYCO_TELLER_", version));
        deploymentSalt[type(RoycoFlashLender).name] = keccak256(abi.encodePacked("ROYCO_FLASH_LENDER_", version));
        deploymentSalt[type(StakedRoyUSD).name] = keccak256(abi.encodePacked("STAKED_ROY_USD_", version));
        deploymentSalt[type(AaveV3MarketAdapter).name] = keccak256(abi.encodePacked("AAVE_V3_RESERVE_ADAPTER_", version));
    }

    function run() public returns (DeployedContracts memory deployed) {
        // Read all environment variables
        bool debug = vm.envBool("DEBUG");
        uint256 deployerKey = vm.envUint("PRIVATE_KEY");
        address deployerAddress = vm.addr(deployerKey);
        if (debug) console2.log("Deployer Address:", deployerAddress);

        address ownerAddress = vm.envAddress("OWNER_ADDRESS");
        address treasury = vm.envAddress("TREASURY");
        bool revertIfAlreadyDeployed = vm.envBool("REVERT_IF_ALREADY_DEPLOYED");
        address[] memory collateralAssets = vm.envAddress("COLLATERAL_ASSETS", ",");
        address[] memory adapterAssets = vm.envOr({ name: "RESERVE_ADAPTER_ASSETS", delim: ",", defaultValue: collateralAssets });
        address aaveV3Pool = vm.envAddress("AAVE_V3_POOL");
        uint256 maxSupply = vm.envUint("ROYUSD_MAX_SUPPLY");

        // Lender configuration
        address[] memory flashLenderAssets = vm.envAddress("LENDER_ASSETS", ",");
        uint256[] memory maxLoanAmountsU256 = vm.envUint("LENDER_MAX_LOAN_AMOUNTS", ",");
        uint256[] memory feeBPSU256 = vm.envUint("LENDER_FEE_BPS", ",");

        // StakedRoyUSD configuration
        uint256 unstakingDuration = vm.envUint("STAKED_UNSTAKING_DURATION");
        uint256 initialDepositAssets = vm.envUint("STAKED_INITIAL_DEPOSIT_ASSETS");
        address initialDepositRecipient = vm.envAddress("STAKED_INITIAL_DEPOSIT_RECIPIENT");

        // Role addresses
        address minterAddress = vm.envAddress("MINTER_ADDRESS");
        address redeemerAddress = vm.envAddress("REDEEMER_ADDRESS");
        address collateralManagerAddress = vm.envAddress("COLLATERAL_MANAGER_ADDRESS");
        address openMarketDeskAddress = vm.envAddress("OPEN_MARKET_DESK_ADDRESS");
        address reserveManagerAddress = vm.envAddress("RESERVE_MANAGER_ADDRESS");
        address reserveAllocatorAddress = vm.envAddress("RESERVE_ALLOCATOR_ADDRESS");
        address yieldDistributorAddress = vm.envAddress("YIELD_DISTRIBUTOR_ADDRESS");
        address stakingManagerAddress = vm.envAddress("STAKING_MANAGER_ADDRESS");
        address blacklistManagerAddress = vm.envAddress("BLACKLIST_MANAGER_ADDRESS");
        address schedulerManagerAddress = vm.envAddress("SCHEDULER_MANAGER_ADDRESS");

        // Delay configuration
        uint256 reserveSetAdapterDelay = vm.envOr("RESERVE_SET_ADAPTER_DELAY", uint256(3600)); // 1 hour default
        uint256 tellerCollateralUpdateDelay = vm.envOr("TELLER_COLLATERAL_UPDATE_DELAY", uint256(3600)); // 1 hour default
        uint256 flashLenderUpdateConfigDelay = vm.envOr("LENDER_UPDATE_CONFIG_DELAY", uint256(3600)); // 1 hour default
        uint256 flashLenderSetTreasuryDelay = vm.envOr("LENDER_SET_TREASURY_DELAY", uint256(3600)); // 1 hour default
        uint256 sRoyUSDSetWhitelistDelay = vm.envOr("SROYUSD_SET_WHITELIST_DELAY", uint256(3600)); // 1 hour default
        uint256 sRoyUSDSetUnstakingDurationDelay = vm.envOr("SROYUSD_SET_UNSTAKING_DURATION_DELAY", uint256(3600)); // 1 hour default

        // Print all environment variables
        _printEnvironmentVariables(
            debug,
            ownerAddress,
            treasury,
            maxSupply,
            collateralAssets,
            flashLenderAssets,
            maxLoanAmountsU256,
            feeBPSU256,
            unstakingDuration,
            initialDepositAssets,
            initialDepositRecipient,
            minterAddress,
            redeemerAddress,
            collateralManagerAddress,
            openMarketDeskAddress,
            yieldDistributorAddress,
            stakingManagerAddress,
            blacklistManagerAddress,
            adapterAssets,
            aaveV3Pool,
            reserveManagerAddress,
            reserveAllocatorAddress,
            schedulerManagerAddress,
            reserveSetAdapterDelay,
            tellerCollateralUpdateDelay,
            flashLenderUpdateConfigDelay,
            flashLenderSetTreasuryDelay,
            sRoyUSDSetWhitelistDelay,
            sRoyUSDSetUnstakingDurationDelay
        );

        vm.startBroadcast(deployerKey);

        // 1. Deploy RoyUSD
        deployed.royUSD = _deployRoyUSD(ownerAddress, maxSupply, revertIfAlreadyDeployed);
        if (debug) console2.log("RoyUSD deployed at:", address(deployed.royUSD));

        // 2. Deploy RoycoReserve
        deployed.reserve = _deployRoycoReserve(ownerAddress, address(deployed.royUSD), reserveSetAdapterDelay, revertIfAlreadyDeployed);
        if (debug) console2.log("RoycoReserve deployed at:", address(deployed.reserve));

        // 3. Deploy RoycoTeller
        deployed.teller = _deployRoycoTeller(
            ownerAddress, address(deployed.royUSD), address(deployed.reserve), collateralAssets, tellerCollateralUpdateDelay, revertIfAlreadyDeployed
        );
        if (debug) console2.log("RoycoTeller deployed at:", address(deployed.teller));

        // 4. Deploy RoycoFlashLender
        deployed.flashLender = _deployRoycoFlashLender(
            ownerAddress,
            address(deployed.royUSD),
            address(deployed.reserve),
            treasury,
            flashLenderAssets,
            maxLoanAmountsU256,
            feeBPSU256,
            flashLenderUpdateConfigDelay,
            flashLenderSetTreasuryDelay,
            revertIfAlreadyDeployed
        );
        if (debug) console2.log("RoycoFlashLender deployed at:", address(deployed.flashLender));

        // 5. Setup inital roles and permissions
        _setupRoles(
            deployed,
            minterAddress,
            redeemerAddress,
            collateralManagerAddress,
            openMarketDeskAddress,
            reserveManagerAddress,
            reserveAllocatorAddress,
            schedulerManagerAddress,
            debug
        );

        // 6. Deploy and configure the Reserve Adapter
        address adapter = _deployMarketAdapter(ownerAddress, address(deployed.reserve), aaveV3Pool, adapterAssets, revertIfAlreadyDeployed);
        if (debug) console2.log("AaveV3MarketAdapter deployed at:", adapter);
        // Configure adapter on the reserve for each asset
        for (uint256 i = 0; i < adapterAssets.length; ++i) {
            deployed.reserve.setCollateralAdapter(adapterAssets[i], adapter);
        }

        // 7. Mint RoyUSD to the deployer address
        if (debug) console2.log("Minting RoyUSD to the deployer address");
        uint256 mintAmount = 1_000_000 * (10 ** deployed.royUSD.decimals());
        IERC20(collateralAssets[0]).approve(address(deployed.teller), mintAmount);
        deployed.teller.grantRoles(deployerAddress, RoycoRoles.MINTER);
        deployed.teller.mint(mintAmount, collateralAssets[0], deployerAddress);

        // 8. Deploy StakedRoyUSD
        deployed.sRoyUSD = _deployStakedRoyUSD(
            ownerAddress,
            deployerAddress,
            address(deployed.royUSD),
            address(deployed.reserve),
            unstakingDuration,
            initialDepositAssets,
            initialDepositRecipient,
            sRoyUSDSetWhitelistDelay,
            sRoyUSDSetUnstakingDurationDelay,
            revertIfAlreadyDeployed
        );
        if (debug) console2.log("StakedRoyUSD deployed at:", address(deployed.sRoyUSD));

        // 9. Setup sRoyUSD roles
        _setupStakedRoyUSDRoles(deployed, yieldDistributorAddress, stakingManagerAddress, blacklistManagerAddress, schedulerManagerAddress, debug);

        vm.stopBroadcast();

        return deployed;
    }

    function _deployRoyUSD(address ownerAddress, uint256 maxSupply, bool revertIfAlreadyDeployed) internal returns (RoyUSD) {
        bytes memory creationCode = abi.encodePacked(type(RoyUSD).creationCode, abi.encode(ownerAddress, maxSupply));

        (address deployedAddress,) = deployWithSanityChecks(deploymentSalt[type(RoyUSD).name], creationCode, revertIfAlreadyDeployed);

        return RoyUSD(deployedAddress);
    }

    function _deployRoycoReserve(
        address ownerAddress,
        address royUSD,
        uint256 setCollateralAdapterDelay,
        bool revertIfAlreadyDeployed
    )
        internal
        returns (RoycoReserve)
    {
        bytes memory creationCode = abi.encodePacked(type(RoycoReserve).creationCode, abi.encode(ownerAddress, royUSD, setCollateralAdapterDelay));

        (address deployedAddress,) = deployWithSanityChecks(deploymentSalt[type(RoycoReserve).name], creationCode, revertIfAlreadyDeployed);

        return RoycoReserve(deployedAddress);
    }

    function _deployMarketAdapter(
        address ownerAddress,
        address reserve,
        address aaveV3Pool,
        address[] memory assets,
        bool revertIfAlreadyDeployed
    )
        internal
        returns (address)
    {
        bytes memory creationCode = abi.encodePacked(type(AaveV3MarketAdapter).creationCode, abi.encode(reserve, aaveV3Pool, ownerAddress, assets));
        (address deployedAddress,) = deployWithSanityChecks(deploymentSalt[type(AaveV3MarketAdapter).name], creationCode, revertIfAlreadyDeployed);
        return deployedAddress;
    }

    function _deployRoycoTeller(
        address ownerAddress,
        address royUSD,
        address reserve,
        address[] memory collateralAssets,
        uint256 collateralAssetUpdateDelay,
        bool revertIfAlreadyDeployed
    )
        internal
        returns (RoycoTeller)
    {
        bytes memory creationCode =
            abi.encodePacked(type(RoycoTeller).creationCode, abi.encode(ownerAddress, royUSD, reserve, collateralAssets, collateralAssetUpdateDelay));

        (address deployedAddress,) = deployWithSanityChecks(deploymentSalt[type(RoycoTeller).name], creationCode, revertIfAlreadyDeployed);

        return RoycoTeller(deployedAddress);
    }

    function _deployRoycoFlashLender(
        address ownerAddress,
        address royUSD,
        address reserve,
        address treasury,
        address[] memory assets,
        uint256[] memory maxLoanAmountsU256,
        uint256[] memory feeBPSU256,
        uint256 updateConfigDelay,
        uint256 setTreasuryDelay,
        bool revertIfAlreadyDeployed
    )
        internal
        returns (RoycoFlashLender)
    {
        require(assets.length == maxLoanAmountsU256.length && assets.length == feeBPSU256.length, LenderConfigLengthMismatch());

        uint240[] memory maxLoanAmounts = new uint240[](assets.length);
        uint16[] memory feeBPS = new uint16[](assets.length);
        for (uint256 i = 0; i < assets.length; ++i) {
            require(maxLoanAmountsU256[i] <= type(uint240).max, MaxLoanAmountOverflow());
            require(feeBPSU256[i] <= type(uint16).max, FeeBPSOverflow());
            maxLoanAmounts[i] = uint240(maxLoanAmountsU256[i]);
            feeBPS[i] = uint16(feeBPSU256[i]);
        }

        bytes memory creationCode = abi.encodePacked(
            type(RoycoFlashLender).creationCode,
            abi.encode(ownerAddress, royUSD, reserve, treasury, assets, maxLoanAmounts, feeBPS, updateConfigDelay, setTreasuryDelay)
        );

        (address deployedAddress,) = deployWithSanityChecks(deploymentSalt[type(RoycoFlashLender).name], creationCode, revertIfAlreadyDeployed);

        return RoycoFlashLender(deployedAddress);
    }

    function _deployStakedRoyUSD(
        address ownerAddress,
        address deployerAddress,
        address royUSD,
        address reserve,
        uint256 unstakingDuration,
        uint256 initialDepositAssets,
        address initialDepositRecipient,
        uint256 setWhitelistDelay,
        uint256 setUnstakingDurationDelay,
        bool revertIfAlreadyDeployed
    )
        internal
        returns (StakedRoyUSD)
    {
        bytes memory creationCode = abi.encodePacked(
            type(StakedRoyUSD).creationCode,
            abi.encode(
                ownerAddress,
                royUSD,
                reserve,
                unstakingDuration,
                deployerAddress,
                initialDepositAssets,
                initialDepositRecipient,
                setWhitelistDelay,
                setUnstakingDurationDelay
            )
        );

        // Approve the initial deposit assets to the expected address
        address expectedAddress = generateDeterminsticAddress(deploymentSalt[type(StakedRoyUSD).name], creationCode);
        IERC20(royUSD).approve(expectedAddress, initialDepositAssets);

        (address deployedAddress,) = deployWithSanityChecks(deploymentSalt[type(StakedRoyUSD).name], creationCode, revertIfAlreadyDeployed);

        return StakedRoyUSD(deployedAddress);
    }

    function _setupRoles(
        DeployedContracts memory deployed,
        address minterAddress,
        address redeemerAddress,
        address collateralManagerAddress,
        address openMarketDeskAddress,
        address reserveManagerAddress,
        address reserveAllocatorAddress,
        address schedulerManagerAddress,
        bool debug
    )
        internal
    {
        // Setup RoyUSD roles
        deployed.royUSD.grantRoles(address(deployed.teller), RoycoRoles.TELLER);
        deployed.royUSD.grantRoles(address(deployed.flashLender), RoycoRoles.LENDER);
        deployed.royUSD.grantRoles(schedulerManagerAddress, RoycoRoles.SCHEDULER_MANAGER);
        if (debug) console2.log("RoyUSD roles configured");

        // Setup Reserve roles
        deployed.reserve.grantRoles(address(deployed.teller), RoycoRoles.TELLER);
        deployed.reserve.grantRoles(address(deployed.flashLender), RoycoRoles.LENDER);
        deployed.reserve.grantRoles(reserveManagerAddress, RoycoRoles.RESERVE_MANAGER);
        deployed.reserve.grantRoles(reserveAllocatorAddress, RoycoRoles.RESERVE_ALLOCATOR);
        deployed.reserve.grantRoles(schedulerManagerAddress, RoycoRoles.SCHEDULER_MANAGER);
        if (debug) console2.log("Reserve roles configured");

        // Setup Teller roles
        deployed.teller.grantRoles(minterAddress, RoycoRoles.MINTER);
        deployed.teller.grantRoles(redeemerAddress, RoycoRoles.REDEEMER);
        deployed.teller.grantRoles(collateralManagerAddress, RoycoRoles.COLLATERAL_MANAGER);
        deployed.teller.grantRoles(schedulerManagerAddress, RoycoRoles.SCHEDULER_MANAGER);
        if (debug) console2.log("Teller roles configured");

        // Setup FlashLender roles
        deployed.flashLender.grantRoles(openMarketDeskAddress, RoycoRoles.OPEN_MARKET_DESK);
        deployed.flashLender.grantRoles(schedulerManagerAddress, RoycoRoles.SCHEDULER_MANAGER);
        if (debug) console2.log("FlashLender roles configured");
    }

    function _setupStakedRoyUSDRoles(
        DeployedContracts memory deployed,
        address yieldDistributorAddress,
        address stakingManagerAddress,
        address blacklistManagerAddress,
        address schedulerManagerAddress,
        bool debug
    )
        internal
    {
        deployed.reserve.grantRoles(address(deployed.sRoyUSD), RoycoRoles.STAKING);
        deployed.sRoyUSD.grantRoles(yieldDistributorAddress, RoycoRoles.YIELD_DISTRIBUTOR);
        deployed.sRoyUSD.grantRoles(stakingManagerAddress, RoycoRoles.STAKING_MANAGER);
        deployed.sRoyUSD.grantRoles(blacklistManagerAddress, RoycoRoles.BLACKLIST_MANAGER);
        deployed.sRoyUSD.grantRoles(schedulerManagerAddress, RoycoRoles.SCHEDULER_MANAGER);
        if (debug) console2.log("StakedRoyUSD roles configured");
    }

    function _printEnvironmentVariables(
        bool debug,
        address ownerAddress,
        address treasury,
        uint256 maxSupply,
        address[] memory collateralAssets,
        address[] memory flashLenderAssets,
        uint256[] memory maxLoanAmountsU256,
        uint256[] memory feeBPSU256,
        uint256 unstakingDuration,
        uint256 initialDepositAssets,
        address initialDepositRecipient,
        address minterAddress,
        address redeemerAddress,
        address collateralManagerAddress,
        address openMarketDeskAddress,
        address yieldDistributorAddress,
        address stakingManagerAddress,
        address blacklistManagerAddress,
        address[] memory adapterAssets,
        address aaveV3Pool,
        address reserveManagerAddress,
        address reserveAllocatorAddress,
        address schedulerManagerAddress,
        uint256 reserveSetAdapterDelay,
        uint256 tellerCollateralUpdateDelay,
        uint256 flashLenderUpdateConfigDelay,
        uint256 flashLenderSetTreasuryDelay,
        uint256 sRoyUSDSetWhitelistDelay,
        uint256 sRoyUSDSetUnstakingDurationDelay
    )
        internal
        view
    {
        console2.log("=== DEPLOYMENT CONFIGURATION ===");
        console2.log("Owner Address:", ownerAddress);
        console2.log("Treasury:", treasury);
        console2.log("RoyUSD Max Supply:", maxSupply);
        console2.log("Debug Mode:", debug);
        console2.log("Revert If Already Deployed:", vm.envBool("REVERT_IF_ALREADY_DEPLOYED"));
        console2.log("Deployment Version:", vm.envString("CONTRACTS_DEPLOYMENT_VERSION"));

        console2.log("\n=== COLLATERAL ASSETS ===");
        console2.log("Collateral Assets Count:", collateralAssets.length);
        for (uint256 i = 0; i < collateralAssets.length; i++) {
            console2.log("  [%d]: %s", i, collateralAssets[i]);
        }

        console2.log("\n=== LENDER CONFIGURATION ===");
        console2.log("Lender Assets Count:", flashLenderAssets.length);
        for (uint256 i = 0; i < flashLenderAssets.length; i++) {
            console2.log("  Asset [%d]: %s", i, flashLenderAssets[i]);
            console2.log("  Max Loan [%d]: %s", i, maxLoanAmountsU256[i]);
            console2.log("  Fee BPS [%d]: %s", i, feeBPSU256[i]);
        }

        console2.log("\n=== RESERVE ADAPTER CONFIGURATION ===");
        console2.log("Aave V3 Pool:", aaveV3Pool);
        console2.log("Adapter Assets Count:", adapterAssets.length);
        for (uint256 i = 0; i < adapterAssets.length; i++) {
            console2.log("  [%d]: %s", i, adapterAssets[i]);
        }

        console2.log("\n=== STAKED ROYUSD CONFIGURATION ===");
        console2.log("Unstaking Duration:", unstakingDuration);
        console2.log("Initial Deposit Assets:", initialDepositAssets);
        console2.log("Initial Deposit Recipient:", initialDepositRecipient);

        console2.log("\n=== ROLE ADDRESSES ===");
        console2.log("Minter Address:", minterAddress);
        console2.log("Redeemer Address:", redeemerAddress);
        console2.log("Collateral Manager Address:", collateralManagerAddress);
        console2.log("Lending Manager Address:", openMarketDeskAddress);
        console2.log("Reserve Manager Address:", reserveManagerAddress);
        console2.log("Reserve Allocator Address:", reserveAllocatorAddress);
        console2.log("Yield Distributor Address:", yieldDistributorAddress);
        console2.log("Staking Manager Address:", stakingManagerAddress);
        console2.log("Blacklist Manager Address:", blacklistManagerAddress);
        console2.log("Scheduler Manager Address:", schedulerManagerAddress);

        console2.log("\n=== DELAY CONFIGURATION ===");
        console2.log("Reserve Set Adapter Delay:", reserveSetAdapterDelay);
        console2.log("Teller Collateral Update Delay:", tellerCollateralUpdateDelay);
        console2.log("Lender Update Config Delay:", flashLenderUpdateConfigDelay);
        console2.log("Lender Set Treasury Delay:", flashLenderSetTreasuryDelay);
        console2.log("StakedRoyUSD Set Whitelist Delay:", sRoyUSDSetWhitelistDelay);
        console2.log("StakedRoyUSD Set Unstaking Duration Delay:", sRoyUSDSetUnstakingDurationDelay);

        console2.log("\n=== NETWORK CONFIGURATION ===");
        console2.log("Chain ID:", block.chainid);
        console2.log("Block Number:", block.number);
        console2.log("Block Timestamp:", block.timestamp);
        console2.log("================================");
    }
}
