# Royco USD [![CI](https://github.com/roycoprotocol/royco-usd/actions/workflows/test.yml/badge.svg)](https://github.com/roycoprotocol/royco-usd/actions/workflows/test.yml)

## Overview

RoyUSD is a **synthetic dollar** designed to maintain price parity with USD. It is backed by stable collateral assets like USDC, USDT, and USDS. The RoyUSD backing is held partially liquid to service redemptions, with the rest being deployed into on/off chain strategies to produce the maximum risk adjusted yield for stakers.

RoyUSD employs a variety of different mechanisms to ensure that its price remains tethered to 1 USD on secondary markets:
1. **Liquidity** - A healthy portion of the reserves are fully liquid at all times in order to service a large influx of redemptions. Any reserves deployed into on/off chain strategies are easily liquidatable in order to replenish reserves. Reserves deployed into certain onchain venues (Aave, Morpho, etc.) can be pulled automatically to service redemptions, given that the underlying protocol has enough liquidity.
2. **Peg Arbitrage** - Minters can directly mint and sell RoyUSD into secondary markets when the price is above $1. Redeemers can buy and redeem RoyUSD from secondary markets when the price is below $1.
3. **Flash mints and loans** - Allows arbitragers, liquidators, etc. to execute strategies without the need for upfront capital.

## Core Architecture
### 1. **Royco USD (RoyUSD) Token**
The core synthetic dollar token with the following characteristics:
- **ERC20** Standard token with burnability and support for permits
- **Supply cap enforcement** Prevents excessive minting and phased rollout
- **Role-based access control** Restricts minting to authorized Tellers and Lenders (see below)
- **1:1 mint/redeem** for underlying collateral via the Teller system

### 2. **Teller**
The **Peg Stability Module (PSM)** that maintains RoyUSD's dollar peg:
- **Minting**: Exchange approved collateral assets for RoyUSD at 1:1 ratio
- **Single Redemption**: Burn RoyUSD to receive a single collateral asset back  
- **Basket redemption**: Greedy redemption across all supported collateral assets (useful for large redemptions)
- **Arbitrage facilitation**: Enables market participants to maintain the peg
- **Quoting**: Provides quotes for buying/minting and selling/redeeming RoyUSD from/to the Teller.

### 3. **Reserve**
The central vault managing the collateral assets and their deployment into various venues:
- **Collateral custody**: Secure storage of backing assets
- **Capital Deployment**: Deploy idle assets into on/off chain yield-generating opportunities
- **Liquidity management**: Withdraw assets on-demand for redemptions (including ones deployed into certain onchain venues)

### 4. **Staked Royco USD (sRoyUSD)**
A high yield savings account for RoyUSD holders:
- **Yield accumulation**: Earn returns on staked RoyUSD
- **Time-locked unstaking**: Unstaking delays for stability and liquidity adjustments
- **Linear vesting**: 7-day yield vesting to ensure fair distribution
- **Expedited unstaking**: Role-based fast withdrawals to reduce sRoyUSD sell pressure on secondary markets in the case of mass liquidations

### 5. **Flash Lender**
ERC-3156 compliant flash mint and loan infrastructure:
- **Flash minting**: Mint RoyUSD temporarily without upfront capital
- **Flash loaning reserves**: Temporarily borrow collateral assets from the reserve
- **Configuration**: Adjustable loan limits and fees per asset

### 6. **Liquidity Facility**
Automated RoyUSD interest rate management across money markets:
- **Rate tethering**: Maintain a governance defined RoyUSD borrow rate per money market
- **Automated rebalancing**: Mint and supply or withdraw and burn RoyUSD to hit target borrow rates on various money markets
- **Risk management**: Supply limits per money market and RoyUSD mints are backed by overcollateralized loans in the underlying money markets.

## External Market Adapters
### **AaveV3 Integration**
- **AaveV3 Market Adapter**: Deploy collateral assets into Aave for yield on reserves
- **AaveV3 Liquidity Facility Adapter**: Supply and withdraw RoyUSD to/from Aave markets to stabilize the borrow rate

## Cross-Chain Infrastructure
### **LayerZero OFT Integration**
- **RoycoOFT**: Native omnichain token for non-mainnet deployments
- **RoycoOFTAdapter**: Bridge mainnet RoyUSD and sRoyUSD to other chains
- **Unified liquidity**: Seamless cross-chain asset movement
