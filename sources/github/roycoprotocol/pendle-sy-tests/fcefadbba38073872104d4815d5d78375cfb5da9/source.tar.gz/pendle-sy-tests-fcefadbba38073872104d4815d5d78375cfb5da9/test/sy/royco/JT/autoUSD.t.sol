// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.28;

import {PendleRoycoTrancheSYTestBase} from "../base/PendleRoycoTrancheSYTestBase.sol";

contract PendleRoycoAutoUSDJuniorSYTest is PendleRoycoTrancheSYTestBase {
    function ROYCO_TRANCHE() internal pure override returns (address) {
        return 0x9393B9E494dfb6403F7D53369226528537fF0752;
    }

    function SY_NAME() internal pure override returns (string memory) {
        return "SY autoUSD Junior";
    }

    function SY_SYMBOL() internal pure override returns (string memory) {
        return "SY-autoUSD-JT";
    }
}
