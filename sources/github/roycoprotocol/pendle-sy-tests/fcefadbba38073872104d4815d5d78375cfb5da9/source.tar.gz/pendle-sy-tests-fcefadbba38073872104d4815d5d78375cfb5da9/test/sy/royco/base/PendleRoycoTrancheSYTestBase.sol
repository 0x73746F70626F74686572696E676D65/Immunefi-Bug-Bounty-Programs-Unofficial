// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.28;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {IERC4626} from "pendle-sy/interfaces/IERC4626.sol";
import {IStandardizedYield} from "pendle-sy/interfaces/IStandardizedYield.sol";
import {
    PendleERC4626NoRedeemUpgSY
} from "pendle-sy/core/StandardizedYield/implementations/PendleERC4626NoRedeemUpgSY.sol";
import {
    PendleRoycoTrancheSY
} from "pendle-sy-public/core/StandardizedYield/implementations/Royco/PendleRoycoTrancheSY.sol";
import {IRoycoFactory} from "pendle-sy-public/interfaces/Royco/IRoycoFactory.sol";
import {IRoycoVaultTranche} from "pendle-sy-public/interfaces/Royco/IRoycoVaultTranche.sol";
import {PMath} from "pendle-core/core/libraries/math/PMath.sol";

import {SYTest} from "../../../common/SYTest.t.sol";

abstract contract PendleRoycoTrancheSYTestBase is SYTest {
    using PMath for uint256;

    address internal constant ROYCO_FACTORY = 0xD567cCbb336Eb71eC2537057E2bCF6DB840bB71d;
    address internal constant OFFCHAIN_REWARD_MANAGER = address(0);

    function ROYCO_TRANCHE() internal pure virtual returns (address);

    function SY_NAME() internal pure virtual returns (string memory);

    function SY_SYMBOL() internal pure virtual returns (string memory);

    function setUpFork() internal override {
        vm.createSelectFork("ethereum");
    }

    function deploySY() internal override {
        vm.startPrank(deployer);

        address logic = address(new PendleRoycoTrancheSY(ROYCO_FACTORY, ROYCO_TRANCHE(), OFFCHAIN_REWARD_MANAGER));
        sy = IStandardizedYield(
            deployTransparentProxy(
                logic, deployer, abi.encodeCall(PendleERC4626NoRedeemUpgSY.initialize, (SY_NAME(), SY_SYMBOL()))
            )
        );

        vm.stopPrank();
    }

    function initializeSY() internal override {
        super.initializeSY();
        startToken = IERC4626(ROYCO_TRANCHE()).asset();
    }

    function hasFee() internal pure override returns (bool) {
        return false;
    }

    function hasReward() internal pure override returns (bool) {
        return false;
    }

    /// @notice Grants the SY permission to deposit base asset into the tranche
    function _grantBaseAssetDepositPermission() internal virtual {
        vm.mockCall(
            ROYCO_FACTORY,
            abi.encodeCall(IRoycoFactory.canCall, (address(sy), ROYCO_TRANCHE(), IRoycoVaultTranche.deposit.selector)),
            abi.encode(true, uint32(0))
        );
    }

    // ══════════════════════════════════════════════════════════════════════════════
    //                           DEPOSIT/REDEEM UNIT TESTS
    // ══════════════════════════════════════════════════════════════════════════════

    /// @notice Test deposit with tranche token
    function test_deposit_withTrancheToken() public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];
        uint256 depositAmount = refAmountFor(tranche);

        fundToken(alice, tranche, depositAmount);

        uint256 syBefore = IERC20(address(sy)).balanceOf(alice);
        uint256 syReceived = deposit(alice, tranche, depositAmount);

        assertEq(syReceived, depositAmount, "SY received should equal tranche deposited (1:1)");
        assertEq(IERC20(address(sy)).balanceOf(alice), syBefore + syReceived, "Balance should increase");
    }

    /// @notice Test redeem to tranche token
    function test_redeem_toTrancheToken() public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];
        uint256 depositAmount = refAmountFor(tranche);

        // First deposit
        fundToken(alice, tranche, depositAmount);
        uint256 syReceived = deposit(alice, tranche, depositAmount);

        // Then redeem
        uint256 trancheBefore = IERC20(tranche).balanceOf(alice);
        uint256 trancheReceived = redeem(alice, tranche, syReceived);

        assertEq(trancheReceived, syReceived, "Tranche received should equal SY redeemed (1:1)");
        assertEq(IERC20(tranche).balanceOf(alice), trancheBefore + trancheReceived, "Balance should increase");
    }

    /// @notice Test deposit/redeem cycle maintains value (no fees)
    function test_depositRedeem_cycle_noLoss() public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];
        uint256 depositAmount = refAmountFor(tranche);

        fundToken(alice, tranche, depositAmount);

        // Deposit
        uint256 syReceived = deposit(alice, tranche, depositAmount);

        // Redeem
        uint256 trancheReceived = redeem(alice, tranche, syReceived);

        assertEq(trancheReceived, depositAmount, "Should get back exact amount deposited");
    }

    /// @notice Test multiple deposits accumulate correctly
    function test_deposit_multiple() public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];
        uint256 depositAmount = refAmountFor(tranche);

        fundToken(alice, tranche, depositAmount * 3);

        uint256 sy1 = deposit(alice, tranche, depositAmount);
        uint256 sy2 = deposit(alice, tranche, depositAmount);
        uint256 sy3 = deposit(alice, tranche, depositAmount);

        assertEq(IERC20(address(sy)).balanceOf(alice), sy1 + sy2 + sy3, "Total SY should be sum of deposits");
        assertEq(IERC20(address(sy)).balanceOf(alice), depositAmount * 3, "Total should be 3x deposit");
    }

    /// @notice Test partial redeems
    function test_redeem_partial() public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];
        uint256 depositAmount = refAmountFor(tranche);

        fundToken(alice, tranche, depositAmount);
        uint256 syReceived = deposit(alice, tranche, depositAmount);

        // Redeem in parts
        uint256 redeemAmount1 = syReceived / 3;
        uint256 redeemAmount2 = syReceived / 3;
        uint256 redeemAmount3 = syReceived - redeemAmount1 - redeemAmount2;

        uint256 tranche1 = redeem(alice, tranche, redeemAmount1);
        uint256 tranche2 = redeem(alice, tranche, redeemAmount2);
        uint256 tranche3 = redeem(alice, tranche, redeemAmount3);

        assertEq(tranche1 + tranche2 + tranche3, depositAmount, "Total redeemed should equal deposited");
        assertEq(IERC20(address(sy)).balanceOf(alice), 0, "SY balance should be 0 after full redeem");
    }

    /// @notice Test multiple users can deposit/redeem independently
    function test_depositRedeem_multipleUsers() public {
        address tranche = ROYCO_TRANCHE();
        uint256 depositAmount = refAmountFor(tranche);

        // Fund all wallets
        for (uint256 i = 0; i < wallets.length; i++) {
            fundToken(wallets[i], tranche, depositAmount);
        }

        // All deposit
        uint256[] memory syBalances = new uint256[](wallets.length);
        for (uint256 i = 0; i < wallets.length; i++) {
            syBalances[i] = deposit(wallets[i], tranche, depositAmount);
            assertEq(syBalances[i], depositAmount, "Each user should receive equal SY");
        }

        // All redeem
        for (uint256 i = 0; i < wallets.length; i++) {
            uint256 trancheReceived = redeem(wallets[i], tranche, syBalances[i]);
            assertEq(trancheReceived, depositAmount, "Each user should get back their deposit");
        }
    }

    // ══════════════════════════════════════════════════════════════════════════════
    //                              FUZZ TESTS
    // ══════════════════════════════════════════════════════════════════════════════

    /// @notice Fuzz test deposit amounts
    function testFuzz_deposit_trancheToken(uint256 depositAmount) public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];

        // Bound to reasonable amounts (1 wei to 1M tokens)
        uint256 decimals = IERC20Metadata(tranche).decimals();
        depositAmount = bound(depositAmount, 1, 1_000_000 * 10 ** decimals);

        fundToken(alice, tranche, depositAmount);

        uint256 preview = sy.previewDeposit(tranche, depositAmount);
        uint256 actual = deposit(alice, tranche, depositAmount);

        assertEq(actual, preview, "Actual should match preview");
        assertEq(actual, depositAmount, "SY should equal tranche 1:1");
    }

    /// @notice Fuzz test redeem amounts
    function testFuzz_redeem_trancheToken(uint256 depositAmount) public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];

        uint256 decimals = IERC20Metadata(tranche).decimals();
        depositAmount = bound(depositAmount, 1, 1_000_000 * 10 ** decimals);

        fundToken(alice, tranche, depositAmount);
        uint256 syReceived = deposit(alice, tranche, depositAmount);

        uint256 preview = sy.previewRedeem(tranche, syReceived);
        uint256 actual = redeem(alice, tranche, syReceived);

        assertEq(actual, preview, "Actual should match preview");
        assertEq(actual, depositAmount, "Should get back original amount");
    }

    /// @notice Fuzz test deposit/redeem cycle
    function testFuzz_depositRedeem_cycle(uint256 depositAmount, uint256 numCycles) public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];

        uint256 decimals = IERC20Metadata(tranche).decimals();
        depositAmount = bound(depositAmount, 10 ** decimals, 100_000 * 10 ** decimals);
        numCycles = bound(numCycles, 1, 5);

        fundToken(alice, tranche, depositAmount);

        uint256 currentAmount = depositAmount;
        for (uint256 i = 0; i < numCycles; i++) {
            uint256 syReceived = deposit(alice, tranche, currentAmount);
            currentAmount = redeem(alice, tranche, syReceived);
        }

        assertEq(currentAmount, depositAmount, "Should maintain value after cycles");
    }

    /// @notice Fuzz test partial redeems
    function testFuzz_redeem_partial(uint256 depositAmount, uint256 redeemPercent) public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];

        uint256 decimals = IERC20Metadata(tranche).decimals();
        depositAmount = bound(depositAmount, 10 ** decimals, 100_000 * 10 ** decimals);
        redeemPercent = bound(redeemPercent, 1, 100);

        fundToken(alice, tranche, depositAmount);
        uint256 syReceived = deposit(alice, tranche, depositAmount);

        uint256 redeemAmount = (syReceived * redeemPercent) / 100;
        if (redeemAmount == 0) redeemAmount = 1;

        uint256 trancheReceived = redeem(alice, tranche, redeemAmount);
        assertEq(trancheReceived, redeemAmount, "Should redeem exact amount");

        uint256 remainingSy = IERC20(address(sy)).balanceOf(alice);
        assertEq(remainingSy, syReceived - redeemAmount, "Remaining SY should be correct");
    }

    // ══════════════════════════════════════════════════════════════════════════════
    //                          EXCHANGE RATE TESTS
    // ══════════════════════════════════════════════════════════════════════════════

    /// @notice Test exchange rate is consistent with deposit/redeem
    function test_exchangeRate_consistency() public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];
        uint256 depositAmount = refAmountFor(tranche);

        uint256 exchangeRateBefore = sy.exchangeRate();

        fundToken(alice, tranche, depositAmount);
        deposit(alice, tranche, depositAmount);

        uint256 exchangeRateAfter = sy.exchangeRate();

        // Exchange rate should not change from deposits (no yield accrued instantly)
        assertEq(exchangeRateAfter, exchangeRateBefore, "Exchange rate should be stable");
    }

    /// @notice Test exchange rate returns valid value
    function test_exchangeRate_valid() public view {
        uint256 rate = sy.exchangeRate();
        assertGt(rate, 0, "Exchange rate should be positive");
        // Rate should be reasonable (between 0.001 and 1000 in 1e18 terms)
        assertGt(rate, 1e15, "Exchange rate should be > 0.001");
        assertLt(rate, 1000e18, "Exchange rate should be < 1000");
    }

    // ══════════════════════════════════════════════════════════════════════════════
    //                         BASE ASSET DEPOSIT TESTS
    // ══════════════════════════════════════════════════════════════════════════════

    /// @notice Test _canDepositViaBaseAsset returns false when no permission granted
    function test_canDepositViaBaseAsset_false() public view {
        address[] memory tokensIn = sy.getTokensIn();
        address tranche = ROYCO_TRANCHE();
        address baseAsset = IERC4626(tranche).asset();

        // Without permission, only tranche should be valid
        assertEq(tokensIn.length, 1, "Should have 1 token when no permission");
        assertEq(tokensIn[0], tranche, "Only token should be tranche");
        assertTrue(sy.isValidTokenIn(tranche), "Tranche should be valid");
        assertFalse(sy.isValidTokenIn(baseAsset), "Base asset should NOT be valid");
    }

    /// @notice Test _canDepositViaBaseAsset returns true when permission granted (delay=0)
    function test_canDepositViaBaseAsset_true_noDelay() public {
        // Grant permission at the start of this test
        _grantBaseAssetDepositPermission();

        address tranche = ROYCO_TRANCHE();
        address baseAsset = IERC4626(tranche).asset();
        address[] memory tokensIn = sy.getTokensIn();

        // With permission, both base asset and tranche should be valid
        assertEq(tokensIn.length, 2, "Should have 2 tokens when permission granted");
        assertEq(tokensIn[0], baseAsset, "First token should be base asset");
        assertEq(tokensIn[1], tranche, "Second token should be tranche");
        assertTrue(sy.isValidTokenIn(baseAsset), "Base asset should be valid");
        assertTrue(sy.isValidTokenIn(tranche), "Tranche should be valid");

        // Verify previewDeposit works for base asset
        uint256 depositAmount = refAmountFor(baseAsset);
        uint256 previewOut = sy.previewDeposit(baseAsset, depositAmount);
        assertGt(previewOut, 0, "Preview should return non-zero for base asset deposit");
    }

    /// @notice Test _canDepositViaBaseAsset returns false when permission granted but delay > 0
    function test_canDepositViaBaseAsset_false_withDelay() public {
        // Grant permission but with a delay
        _grantBaseAssetDepositPermissionWithDelay(1);

        address tranche = ROYCO_TRANCHE();
        address baseAsset = IERC4626(tranche).asset();
        address[] memory tokensIn = sy.getTokensIn();

        // With delay > 0, should behave as if no permission
        assertEq(tokensIn.length, 1, "Should have 1 token when delay > 0");
        assertEq(tokensIn[0], tranche, "Only token should be tranche");
        assertFalse(sy.isValidTokenIn(baseAsset), "Base asset should NOT be valid with delay");
    }

    /// @notice Test deposit with base asset when permission granted
    function test_deposit_withBaseAsset_permissionGranted() public {
        // Grant permission at the start of this test
        _grantBaseAssetDepositPermission();

        address tranche = ROYCO_TRANCHE();
        address baseAsset = IERC4626(tranche).asset();
        address alice = wallets[0];

        assertTrue(sy.isValidTokenIn(baseAsset), "Base asset should be valid with permission");

        // Fund with base asset
        uint256 depositAmount = refAmountFor(baseAsset);
        fundToken(alice, baseAsset, depositAmount);

        // Preview should work
        uint256 previewOut = sy.previewDeposit(baseAsset, depositAmount);
        assertGt(previewOut, 0, "Preview should return non-zero");

        // Note: Actual deposit may fail on Royco side due to coverage checks
        // but we've validated the SY permission logic works correctly
    }

    /// @notice Fuzz test _canDepositViaBaseAsset with both branches
    function testFuzz_canDepositViaBaseAsset_bothBranches(bool grantPermission, uint32 delay) public {
        address tranche = ROYCO_TRANCHE();
        address baseAsset = IERC4626(tranche).asset();

        if (grantPermission) {
            if (delay == 0) {
                _grantBaseAssetDepositPermission();
            } else {
                _grantBaseAssetDepositPermissionWithDelay(delay);
            }
        }

        address[] memory tokensIn = sy.getTokensIn();
        bool baseAssetShouldBeValid = grantPermission && delay == 0;

        if (baseAssetShouldBeValid) {
            assertEq(tokensIn.length, 2, "Should have 2 tokens when permission granted with no delay");
            assertTrue(sy.isValidTokenIn(baseAsset), "Base asset should be valid");
        } else {
            assertEq(tokensIn.length, 1, "Should have 1 token when no permission or delay > 0");
            assertFalse(sy.isValidTokenIn(baseAsset), "Base asset should NOT be valid");
        }

        // Tranche should always be valid
        assertTrue(sy.isValidTokenIn(tranche), "Tranche should always be valid");
    }

    /// @notice Grants permission with a delay (to test delay > 0 branch)
    function _grantBaseAssetDepositPermissionWithDelay(uint32 delay) internal {
        vm.mockCall(
            ROYCO_FACTORY,
            abi.encodeCall(IRoycoFactory.canCall, (address(sy), ROYCO_TRANCHE(), IRoycoVaultTranche.deposit.selector)),
            abi.encode(true, delay)
        );
    }

    // ══════════════════════════════════════════════════════════════════════════════
    //                              EDGE CASES
    // ══════════════════════════════════════════════════════════════════════════════

    /// @notice Test deposit with zero amount reverts
    function test_deposit_zeroAmount_reverts() public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];

        vm.startPrank(alice);
        IERC20(tranche).approve(address(sy), 0);
        vm.expectRevert();
        sy.deposit(alice, tranche, 0, 0);
        vm.stopPrank();
    }

    /// @notice Test redeem with zero amount reverts
    function test_redeem_zeroAmount_reverts() public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];

        // First deposit something
        fundToken(alice, tranche, refAmountFor(tranche));
        deposit(alice, tranche, refAmountFor(tranche));

        vm.prank(alice);
        vm.expectRevert();
        sy.redeem(alice, 0, tranche, 0, false);
    }

    /// @notice Test deposit with invalid token reverts
    function test_deposit_invalidToken_reverts() public {
        address alice = wallets[0];
        address invalidToken = makeAddr("invalidToken");

        vm.prank(alice);
        vm.expectRevert();
        sy.deposit(alice, invalidToken, 1e18, 0);
    }

    /// @notice Test redeem with invalid token reverts
    function test_redeem_invalidToken_reverts() public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];
        address invalidToken = makeAddr("invalidToken");

        // First deposit something
        fundToken(alice, tranche, refAmountFor(tranche));
        deposit(alice, tranche, refAmountFor(tranche));

        vm.prank(alice);
        vm.expectRevert();
        sy.redeem(alice, 1e18, invalidToken, 0, false);
    }

    /// @notice Test redeem more than balance reverts
    function test_redeem_exceedsBalance_reverts() public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];

        fundToken(alice, tranche, refAmountFor(tranche));
        uint256 syReceived = deposit(alice, tranche, refAmountFor(tranche));

        vm.prank(alice);
        vm.expectRevert();
        sy.redeem(alice, syReceived + 1, tranche, 0, false);
    }

    /// @notice Override to only use tranche token for preview tests
    /// Base asset deposit permissions are tested separately in dedicated tests
    function getTokensInForPreviewTest() internal view virtual override returns (address[] memory res) {
        res = new address[](1);
        res[0] = ROYCO_TRANCHE();
    }

    // ══════════════════════════════════════════════════════════════════════════════
    //                         PREVIEW TESTS (BASE ASSET)
    // ══════════════════════════════════════════════════════════════════════════════

    /// @notice Test previewDeposit for base asset when permission granted
    function test_previewDeposit_baseAsset_withPermission() public {
        _grantBaseAssetDepositPermission();

        address tranche = ROYCO_TRANCHE();
        address baseAsset = IERC4626(tranche).asset();
        uint256 depositAmount = refAmountFor(baseAsset);

        // Preview should return expected tranche shares
        uint256 expectedShares = IERC4626(tranche).previewDeposit(depositAmount);
        uint256 previewOut = sy.previewDeposit(baseAsset, depositAmount);

        assertEq(previewOut, expectedShares, "Preview should match ERC4626 conversion");
    }

    /// @notice Fuzz test previewDeposit for base asset
    function testFuzz_previewDeposit_baseAsset(uint256 depositAmount) public {
        _grantBaseAssetDepositPermission();

        address tranche = ROYCO_TRANCHE();
        address baseAsset = IERC4626(tranche).asset();
        uint256 decimals = IERC20Metadata(baseAsset).decimals();
        depositAmount = bound(depositAmount, 1, 1_000_000 * 10 ** decimals);

        uint256 expectedShares = IERC4626(tranche).previewDeposit(depositAmount);
        uint256 previewOut = sy.previewDeposit(baseAsset, depositAmount);

        assertEq(previewOut, expectedShares, "Preview should match ERC4626 conversion");
    }

    // ══════════════════════════════════════════════════════════════════════════════
    //                         TOKEN OUT TESTS
    // ══════════════════════════════════════════════════════════════════════════════

    /// @notice Test getTokensOut returns only tranche
    function test_getTokensOut_onlyTranche() public view {
        address[] memory tokensOut = sy.getTokensOut();
        address tranche = ROYCO_TRANCHE();

        assertEq(tokensOut.length, 1, "Should have exactly 1 token out");
        assertEq(tokensOut[0], tranche, "Token out should be tranche");
    }

    /// @notice Test isValidTokenOut
    function test_isValidTokenOut() public {
        address tranche = ROYCO_TRANCHE();
        address baseAsset = IERC4626(tranche).asset();

        assertTrue(sy.isValidTokenOut(tranche), "Tranche should be valid token out");
        assertFalse(sy.isValidTokenOut(baseAsset), "Base asset should NOT be valid token out");
        assertFalse(sy.isValidTokenOut(address(0)), "Zero address should NOT be valid");
        assertFalse(sy.isValidTokenOut(makeAddr("random")), "Random address should NOT be valid");
    }

    // ══════════════════════════════════════════════════════════════════════════════
    //                         IMMUTABLE STATE TESTS
    // ══════════════════════════════════════════════════════════════════════════════

    /// @notice Test immutable state is correctly set
    function test_immutableState() public view {
        address tranche = ROYCO_TRANCHE();
        PendleRoycoTrancheSY roycoSy = PendleRoycoTrancheSY(payable(address(sy)));

        assertEq(address(roycoSy.ROYCO_FACTORY()), ROYCO_FACTORY, "ROYCO_FACTORY should be set");
        assertEq(roycoSy.yieldToken(), tranche, "yieldToken should be tranche");
        assertEq(roycoSy.asset(), IERC4626(tranche).asset(), "asset should be tranche's asset");
    }

    /// @notice Test SY metadata
    function test_syMetadata() public view {
        assertEq(sy.name(), SY_NAME(), "Name should match");
        assertEq(sy.symbol(), SY_SYMBOL(), "Symbol should match");
        assertEq(sy.decimals(), 18, "Decimals should be 18");
    }

    // ══════════════════════════════════════════════════════════════════════════════
    //                         INITIALIZATION TESTS
    // ══════════════════════════════════════════════════════════════════════════════

    /// @notice Test double initialization reverts
    function test_initialize_twice_reverts() public {
        vm.expectRevert();
        PendleERC4626NoRedeemUpgSY(payable(address(sy))).initialize("New Name", "NEW");
    }

    // ══════════════════════════════════════════════════════════════════════════════
    //                         TRANSFER TESTS
    // ══════════════════════════════════════════════════════════════════════════════

    /// @notice Test SY tokens are transferable
    function test_transfer() public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];
        address bob = wallets[1];
        uint256 depositAmount = refAmountFor(tranche);

        fundToken(alice, tranche, depositAmount);
        uint256 syReceived = deposit(alice, tranche, depositAmount);

        uint256 aliceBefore = IERC20(address(sy)).balanceOf(alice);
        uint256 bobBefore = IERC20(address(sy)).balanceOf(bob);

        vm.prank(alice);
        IERC20(address(sy)).transfer(bob, syReceived);

        assertEq(IERC20(address(sy)).balanceOf(alice), aliceBefore - syReceived, "Alice balance should decrease");
        assertEq(IERC20(address(sy)).balanceOf(bob), bobBefore + syReceived, "Bob balance should increase");

        // Bob should be able to redeem
        uint256 trancheReceived = redeem(bob, tranche, syReceived);
        assertEq(trancheReceived, depositAmount, "Bob should receive full tranche amount");
    }

    /// @notice Fuzz test transfers
    function testFuzz_transfer(uint256 depositAmount, uint256 transferPercent) public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];
        address bob = wallets[1];

        uint256 decimals = IERC20Metadata(tranche).decimals();
        depositAmount = bound(depositAmount, 10 ** decimals, 100_000 * 10 ** decimals);
        transferPercent = bound(transferPercent, 1, 100);

        fundToken(alice, tranche, depositAmount);
        uint256 syReceived = deposit(alice, tranche, depositAmount);

        uint256 transferAmount = (syReceived * transferPercent) / 100;
        if (transferAmount == 0) transferAmount = 1;

        vm.prank(alice);
        IERC20(address(sy)).transfer(bob, transferAmount);

        assertEq(IERC20(address(sy)).balanceOf(bob), transferAmount, "Bob should receive transfer");
        assertEq(IERC20(address(sy)).balanceOf(alice), syReceived - transferAmount, "Alice should have remainder");
    }

    // ══════════════════════════════════════════════════════════════════════════════
    //                         ASSET INFO TESTS
    // ══════════════════════════════════════════════════════════════════════════════

    /// @notice Test assetInfo returns correct values for identical asset tranches
    function test_assetInfo_identicalAssets() public view {
        address tranche = ROYCO_TRANCHE();
        address baseAsset = IERC4626(tranche).asset();

        (IStandardizedYield.AssetType assetType, address assetAddress, uint8 assetDecimals) = sy.assetInfo();

        // For tranches with identical assets, should return TOKEN type with base asset
        assertEq(uint8(assetType), uint8(IStandardizedYield.AssetType.TOKEN), "Asset type should be TOKEN");
        assertEq(assetAddress, baseAsset, "Asset address should be base asset");
        assertEq(assetDecimals, IERC20Metadata(baseAsset).decimals(), "Decimals should match base asset");
    }

    // ══════════════════════════════════════════════════════════════════════════════
    //                         SLIPPAGE PROTECTION TESTS
    // ══════════════════════════════════════════════════════════════════════════════

    /// @notice Test deposit respects minSharesOut
    function test_deposit_minSharesOut() public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];
        uint256 depositAmount = refAmountFor(tranche);

        fundToken(alice, tranche, depositAmount);

        // Should succeed with exact minSharesOut
        uint256 preview = sy.previewDeposit(tranche, depositAmount);

        vm.startPrank(alice);
        IERC20(tranche).approve(address(sy), depositAmount);
        uint256 received = sy.deposit(alice, tranche, depositAmount, preview);
        vm.stopPrank();

        assertEq(received, preview, "Should receive exact preview amount");
    }

    /// @notice Test deposit fails if minSharesOut not met
    function test_deposit_minSharesOut_reverts() public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];
        uint256 depositAmount = refAmountFor(tranche);

        fundToken(alice, tranche, depositAmount);

        uint256 preview = sy.previewDeposit(tranche, depositAmount);

        vm.startPrank(alice);
        IERC20(tranche).approve(address(sy), depositAmount);
        vm.expectRevert();
        sy.deposit(alice, tranche, depositAmount, preview + 1); // Request more than possible
        vm.stopPrank();
    }

    /// @notice Test redeem respects minTokenOut
    function test_redeem_minTokenOut() public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];
        uint256 depositAmount = refAmountFor(tranche);

        fundToken(alice, tranche, depositAmount);
        uint256 syReceived = deposit(alice, tranche, depositAmount);

        uint256 preview = sy.previewRedeem(tranche, syReceived);

        vm.prank(alice);
        uint256 received = sy.redeem(alice, syReceived, tranche, preview, false);

        assertEq(received, preview, "Should receive exact preview amount");
    }

    /// @notice Test redeem fails if minTokenOut not met
    function test_redeem_minTokenOut_reverts() public {
        address tranche = ROYCO_TRANCHE();
        address alice = wallets[0];
        uint256 depositAmount = refAmountFor(tranche);

        fundToken(alice, tranche, depositAmount);
        uint256 syReceived = deposit(alice, tranche, depositAmount);

        uint256 preview = sy.previewRedeem(tranche, syReceived);

        vm.prank(alice);
        vm.expectRevert();
        sy.redeem(alice, syReceived, tranche, preview + 1, false); // Request more than possible
    }
}
