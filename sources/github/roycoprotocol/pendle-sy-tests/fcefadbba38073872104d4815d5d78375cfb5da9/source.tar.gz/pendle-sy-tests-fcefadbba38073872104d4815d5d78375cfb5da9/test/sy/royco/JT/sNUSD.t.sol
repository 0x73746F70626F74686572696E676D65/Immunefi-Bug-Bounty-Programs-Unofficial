// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.28;

import {PendleRoycoTrancheSYTestBase} from "../base/PendleRoycoTrancheSYTestBase.sol";

contract PendleRoycoSNUSDJuniorSYTest is PendleRoycoTrancheSYTestBase {
    function ROYCO_TRANCHE() internal pure override returns (address) {
        return 0x58c578d7e4f291ee1A11399D03e4418443e7A134;
    }

    function SY_NAME() internal pure override returns (string memory) {
        return "SY sNUSD Junior";
    }

    function SY_SYMBOL() internal pure override returns (string memory) {
        return "SY-sNUSD-JT";
    }
}
