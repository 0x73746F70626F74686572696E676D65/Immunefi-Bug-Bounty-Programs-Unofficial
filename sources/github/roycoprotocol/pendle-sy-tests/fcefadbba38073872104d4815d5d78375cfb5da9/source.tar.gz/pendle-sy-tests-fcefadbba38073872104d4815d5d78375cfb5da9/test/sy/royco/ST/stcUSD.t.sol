// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.28;

import {PendleRoycoTrancheSYTestBase} from "../base/PendleRoycoTrancheSYTestBase.sol";

contract PendleRoycoStcUSDSeniorSYTest is PendleRoycoTrancheSYTestBase {
    function ROYCO_TRANCHE() internal pure override returns (address) {
        return 0x245b23aa7fA1Ca796513ce68117c34fEFCC154a9;
    }

    function SY_NAME() internal pure override returns (string memory) {
        return "SY stcUSD Senior";
    }

    function SY_SYMBOL() internal pure override returns (string memory) {
        return "SY-stcUSD-ST";
    }
}
