// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.28;

import {PendleRoycoTrancheSYTestBase} from "../base/PendleRoycoTrancheSYTestBase.sol";

contract PendleRoycoStcUSDJuniorSYTest is PendleRoycoTrancheSYTestBase {
    function ROYCO_TRANCHE() internal pure override returns (address) {
        return 0xc9a140ECf16A16a08aD8E8F5F2d92970d77F6587;
    }

    function SY_NAME() internal pure override returns (string memory) {
        return "SY stcUSD Junior";
    }

    function SY_SYMBOL() internal pure override returns (string memory) {
        return "SY-stcUSD-JT";
    }
}
