// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.28;

import {PendleRoycoTrancheSYTestBase} from "../base/PendleRoycoTrancheSYTestBase.sol";

contract PendleRoycoAutoUSDSeniorSYTest is PendleRoycoTrancheSYTestBase {
    function ROYCO_TRANCHE() internal pure override returns (address) {
        return 0x0725475f51340f1B228bE7cB253bC7C2E3a3610B;
    }

    function SY_NAME() internal pure override returns (string memory) {
        return "SY autoUSD Senior";
    }

    function SY_SYMBOL() internal pure override returns (string memory) {
        return "SY-autoUSD-ST";
    }
}
