// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.28;

import {PendleRoycoTrancheSYTestBase} from "../base/PendleRoycoTrancheSYTestBase.sol";

contract PendleRoycoSNUSDSeniorSYTest is PendleRoycoTrancheSYTestBase {
    function ROYCO_TRANCHE() internal pure override returns (address) {
        return 0x3B2df77f0eaA0CA98aAabFFa96B03eaF08ec6c8e;
    }

    function SY_NAME() internal pure override returns (string memory) {
        return "SY sNUSD Senior";
    }

    function SY_SYMBOL() internal pure override returns (string memory) {
        return "SY-sNUSD-ST";
    }
}
