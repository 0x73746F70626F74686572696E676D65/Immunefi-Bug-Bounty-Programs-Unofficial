#!/usr/bin/env pypy3
# optimizer.py

import os
import sys
import math
from collections import defaultdict, Counter
from typing import List, Dict, Tuple, Optional
from datetime import datetime, timezone, timedelta, date

import numpy as np
from dotenv import load_dotenv

from pools import get_pools, NormalizedPool
from apy import fetch_historical_borrow_apy  # returns fields incl. totalSupplyUsd, totalBorrowUsd, apyBaseBorrow, apyRewardBorrow, borrowableUsd
# REMOVED IRM: from irm import get_borrow_apy_usdc


# =========================
# Config
# =========================

# Load .env before any os.getenv reads
load_dotenv()

PROTOCOLS: List[str] = ["aave-v3", "compound-v3", "morpho-blue"]
COLLATERAL_ASSETS: List[str] = ["PT-USDE-25SEP2025"]  # <collateral>/<BORROW_ASSET> pairs
BORROW_ASSET: str = os.getenv("BORROW_ASSET", "USDC").upper()

LOOKBACK_DAYS: int = int(os.getenv("LOOKBACK_DAYS", "26"))

# Env-to-bool parser: "0", "false", "no" => False; anything else => True
INCLUDE_REWARDS: bool = os.getenv("INCLUDE_REWARDS", "0").strip().lower() not in ("0", "false", "no")

def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)))
    except Exception:
        return default

# Pair-specific collateral/borrow (overridable via env)
PAIR_PARAMS = {
    "PT-USDE-25SEP2025": dict(
        collateral_usd=_env_float("COLLATERAL_USD_PT_USDE_25SEP2025", 10_000_000.0),
        borrow_usdc=_env_float("BORROW_USD_PT_USDE_25SEP2025",        5_000_000.0),
    )
}

API_KEY = os.getenv("DEFI_LLAMA_API_KEY")
if not API_KEY:
    raise RuntimeError("DEFI_LLAMA_API_KEY environment variable is not set")

DEBUG_DIAG = True  # print venue selection & data coverage diagnostics


# =========================
# Helpers
# =========================

def _parse_iso_utc(ts: str) -> datetime:
    """Parse ISO8601-ish timestamp into timezone-aware UTC datetime."""
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00")).astimezone(timezone.utc)
    except Exception:
        base = ts.split(".")[0].replace("Z", "")
        return datetime.fromisoformat(base).replace(tzinfo=timezone.utc)

def _day(dt: datetime) -> date:
    return dt.astimezone(timezone.utc).date()

def _to_float(x) -> Optional[float]:
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


# Record layout:
# ( net_apy_pct_snapshot, totalBorrowUsd, totalSupplyUsd, apyRewardBorrow, borrowableUsd, apyBaseBorrow_snapshot )
Record = Tuple[float, Optional[float], Optional[float], Optional[float], Optional[float], Optional[float]]


def _build_compound_usdc_map(pools: List[NormalizedPool]) -> Dict[str, str]:
    """Map: chain -> Compound v3 USDC base pool_id (Comet)."""
    return {
        p["chain"]: p["pool_id"]
        for p in pools
        if p["protocol"] == "compound-v3" and p["collateral"] == "USDC" and p["borrow"] == "USDC"
    }


def _borrow_pool_id_for(p: NormalizedPool, comp_usdc_by_chain: Dict[str, str]) -> str:
    """
    For Compound v3 collateral rows, borrow APY is read from the chain's USDC Comet.
    For others (Morpho Blue, Aave), use their own pool_id.

    IMPORTANT: If Comp v3 collateral row is seen but we don’t find the USDC Comet
    for that chain, we must skip (return empty string) rather than falling back.
    """
    if p["protocol"] == "compound-v3" and p["collateral"] != "USDC":
        pid = comp_usdc_by_chain.get(p["chain"])
        return pid or ""  # strict: skip if missing Comet
    return p["pool_id"]


# REMOVED IRM: deleted _irm_estimate_or_none()

def _load_daily_records_for_pool(
    api_key: str,
    pool_id: str,
    cutoff_date: date,
) -> Dict[date, Record]:
    """
    Fetch historical points for pool_id and keep last observation per UTC day on/after cutoff_date.

    Returns:
      {date -> (net_apy_pct_snapshot, totalBorrowUsd, totalSupplyUsd, reward_pct, borrowableUsd, baseBorrow_pct)}
    """
    # IMPORTANT: do NOT pre-filter by capacity here; we want a single feasibility gate later.
    series = fetch_historical_borrow_apy(api_key, pool_id, min_borrowable_usd=0.0)
    last_per_day: Dict[date, Tuple[datetime, Record]] = {}

    for pt in series:
        ts = pt.get("timestamp")
        base = _to_float(pt.get("apyBaseBorrow"))
        reward = _to_float(pt.get("apyRewardBorrow"))
        tb_usd = _to_float(pt.get("totalBorrowUsd"))
        ts_usd = _to_float(pt.get("totalSupplyUsd"))
        borrowable = _to_float(pt.get("borrowableUsd"))  # already supply - borrow in apy.py

        if ts is None:
            continue

        dt = _parse_iso_utc(str(ts))
        d = _day(dt)
        # Inclusive cutoff so we don't lose the most recent day
        if d < cutoff_date:
            continue

        # NO IRM: require base borrow APY from feed; if missing, skip
        if base is None:
            continue

        net_apy = base - (reward if (INCLUDE_REWARDS and reward is not None) else 0.0)

        rec: Record = (net_apy, tb_usd, ts_usd, reward, borrowable, base)
        prev = last_per_day.get(d)
        if prev is None or dt > prev[0]:
            last_per_day[d] = (dt, rec)

    return {d: rec for d, (_, rec) in last_per_day.items()}


def _union_days_dicts(dicts: List[Dict[date, Record]]) -> List[date]:
    all_days = set()
    for dct in dicts:
        all_days.update(dct.keys())
    return sorted(all_days)


def _avg(vals: List[float]) -> Optional[float]:
    return float(np.mean(vals)) if vals else None


def _apy_pct_to_daily_rate(apy_pct: float) -> float:
    """APY percent -> daily effective rate (365-day basis)."""
    apy_dec = apy_pct / 100.0
    return (1.0 + apy_dec) ** (1.0 / 365.0) - 1.0


def _weighted_avg(pairs: List[Tuple[float, float]]) -> Optional[float]:
    """pairs: [(value, weight>0)]. Returns sum(v*w)/sum(w)."""
    if not pairs:
        return None
    wsum = sum(w for _, w in pairs if w is not None and w > 0)
    if wsum <= 0:
        return None
    vsum = sum(v * w for v, w in pairs if w is not None and w > 0)
    return vsum / wsum


# NO IRM: just return the snapshot net APY from the feed
def _net_apy_snapshot(rec: Record) -> Optional[float]:
    return rec[0]  # already base - reward (if rewards included)


def _feasible(rec: Record, required_borrow: float) -> bool:
    """Feasible if borrowableUsd is known and >= required_borrow."""
    borrowable = rec[4]
    return (borrowable is not None) and (borrowable >= required_borrow)


# =========================
# Venue series builder (Morpho: keep ALL; Compound/Aave: select best coverage per chain)
# =========================

def _build_per_venue_series(
    pools: List[NormalizedPool],
    cutoff_date: date
) -> Dict[Tuple[str, str, str], Dict[date, Record]]:
    comp_map = _build_compound_usdc_map(pools)

    per_venue: Dict[Tuple[str, str, str], Dict[date, Record]] = {}
    fetched: Dict[str, Dict[date, Record]] = {}
    compound_candidates: Dict[str, Dict[str, Dict[date, Record]]] = defaultdict(dict)  # chain -> {pid -> series}
    aave_candidates: Dict[str, Dict[str, Dict[date, Record]]] = defaultdict(dict)      # chain -> {pid -> series}

    for p in pools:
        eff_pool_id = _borrow_pool_id_for(p, comp_map)
        if not eff_pool_id:
            continue

        if eff_pool_id not in fetched:
            series = _load_daily_records_for_pool(API_KEY, eff_pool_id, cutoff_date)
            fetched[eff_pool_id] = series or {}
        series = fetched[eff_pool_id]
        if not series:
            continue

        if p["protocol"] == "compound-v3":
            compound_candidates[p["chain"]][eff_pool_id] = series
        elif p["protocol"] == "aave-v3":
            aave_candidates[p["chain"]][eff_pool_id] = series
        else:
            # keep ALL morpho markets
            per_venue[(p["protocol"], p["chain"], eff_pool_id)] = series

    # choose best-coverage USDC Comet per chain for Compound v3
    if compound_candidates and DEBUG_DIAG:
        print("\n[Diagnostics] Compound v3 USDC Comet selection by chain:")
    for chain, pid_map in compound_candidates.items():
        best_pid, best_series = max(pid_map.items(), key=lambda t: len(t[1]))
        per_venue[("compound-v3", chain, best_pid)] = best_series
        if DEBUG_DIAG:
            alist = ", ".join([f"{pid[:8]}…:{len(s)}d" for pid, s in pid_map.items()])
            print(f"  {chain:<10} best={best_pid[:8]}… days={len(best_series)}  all=[{alist}]")
    if compound_candidates and DEBUG_DIAG:
        print()

    # choose best-coverage Aave USDC reserve per chain
    if aave_candidates and DEBUG_DIAG:
        print("[Diagnostics] Aave v3 USDC reserve selection by chain:")
    for chain, pid_map in aave_candidates.items():
        best_pid, best_series = max(pid_map.items(), key=lambda t: len(t[1]))
        per_venue[("aave-v3", chain, best_pid)] = best_series
        if DEBUG_DIAG:
            alist = ", ".join([f"{pid[:8]}…:{len(s)}d" for pid, s in pid_map.items()])
            print(f"  {chain:<10} best={best_pid[:8]}… days={len(best_series)}  all=[{alist}]")
    if aave_candidates and DEBUG_DIAG:
        print()

    # Reward coverage diagnostics
    if DEBUG_DIAG:
        print("[Diagnostics] Reward coverage by venue (days with non-null apyRewardBorrow):")
        for (proto, chain, pid), series in per_venue.items():
            total = len(series)
            reward_days = sum(1 for rec in series.values() if rec[3] is not None)
            print(f"  {proto}|{chain:<10}|{pid[:8]}  reward_days={reward_days}/{total}")
        print()

    return per_venue


# =========================
# Sections: Reports + Backtest
# =========================

def _print_configuration():
    print("\n============================================")
    print(" Configuration")
    print(f"Lookback days:           {LOOKBACK_DAYS}")
    print(f"Include rewards:         {INCLUDE_REWARDS}")
    print(f"Borrow asset:            {BORROW_ASSET}")
    print(f"Global fetch gate:       0 (disabled; single feasibility gate in backtest)")
    for c in COLLATERAL_ASSETS:
        print(f"  {c}/{BORROW_ASSET}  collateral=${PAIR_PARAMS[c]['collateral_usd']:,.0f}  borrow=${PAIR_PARAMS[c]['borrow_usdc']:,.0f}")
    print("============================================")


def _build_pool_index(pools: List[NormalizedPool]) -> Dict[Tuple[str, str, str], List[NormalizedPool]]:
    """Index pools by (protocol, chain, pool_id) → list of rows (collateral/borrow combos)."""
    idx: Dict[Tuple[str, str, str], List[NormalizedPool]] = defaultdict(list)
    for p in pools:
        idx[(p["protocol"], p["chain"], p["pool_id"])].append(p)
    return idx


def _report_unweighted_pair_means(per_venue: Dict[Tuple[str, str, str], Dict[date, Record]], pools: List[NormalizedPool]):
    print("\n============================================")
    print(" Average *Net* Borrow APY per Pair (chain-agnostic)")
    print("   net = apyBaseBorrow - apyRewardBorrow (if rewards included)")
    print("============================================")

    pool_idx = _build_pool_index(pools)

    for collateral in COLLATERAL_ASSETS:
        relevant_series: List[Dict[date, Record]] = []
        used_labels: set[str] = set()

        for (proto, chain, pid), series in per_venue.items():
            # Aave: include once per chain (USDC borrow is collateral-agnostic)
            if proto == "aave-v3":
                label = f"{proto}|{chain}"
                if label not in used_labels:
                    used_labels.add(label)
                    relevant_series.append(series)
                continue

            # Non-Aave: include only if this exact PID corresponds to (collateral, BORROW_ASSET)
            rows = pool_idx.get((proto, chain, pid), [])
            if any(r["collateral"] == collateral and r["borrow"] == BORROW_ASSET for r in rows):
                label = f"{proto}|{chain}|{pid[:8]}"
                if label not in used_labels:
                    used_labels.add(label)
                    relevant_series.append(series)

        if not relevant_series:
            print(f"{collateral}/{BORROW_ASSET}:  no data")
            continue

        # Cross-sectional daily mean across venues with data, then time-average
        days = _union_days_dicts(relevant_series)
        daily_means: List[float] = []
        for d in days:
            vals = [series[d][0] for series in relevant_series if d in series]  # net_apy snapshot
            if vals:
                daily_means.append(float(np.mean(vals)))

        pair_mean = _avg(daily_means)
        if pair_mean is None:
            print(f"{collateral}/{BORROW_ASSET}:  venues={len(used_labels):<2d}  days=0    mean=NA")
        else:
            print(f"{collateral}/{BORROW_ASSET}:  venues={len(used_labels):<2d}  days={len(daily_means):<4d}  mean={pair_mean:.3f}%")


def _report_weighted_pair_means_DW(per_venue: Dict[Tuple[str, str, str], Dict[date, Record]], pools: List[NormalizedPool]):
    print("\n---------------------------------------------------------------------")
    print(" Weighted *Net* Borrow APY per Pair × Protocol (chain-agnostic, DW-mean)")
    print("   DW-mean = for each day: weighted mean across chains (weights=totalBorrowUsd),")
    print("             then average those daily weighted means across days (unweighted).")
    print("---------------------------------------------------------------------\n")

    pool_idx = _build_pool_index(pools)

    for collateral in COLLATERAL_ASSETS:
        # Gather per-protocol, per-chain series relevant to this pair
        per_proto_series: Dict[str, List[Dict[date, Record]]] = {pr: [] for pr in PROTOCOLS}

        for (proto, chain, pid), series in per_venue.items():
            if proto == "aave-v3":
                # Aave is collateral-agnostic
                if series not in per_proto_series[proto]:
                    per_proto_series[proto].append(series)
            else:
                rows = pool_idx.get((proto, chain, pid), [])
                if any(r["collateral"] == collateral and r["borrow"] == BORROW_ASSET for r in rows):
                    if series not in per_proto_series[proto]:
                        per_proto_series[proto].append(series)

        print(f"{collateral}/{BORROW_ASSET}:")
        any_row = False
        for proto in PROTOCOLS:
            series_list = per_proto_series.get(proto, [])
            if not series_list:
                continue

            # Build DW-mean: for each day, compute weighted mean across this protocol's chains
            days = _union_days_dicts(series_list)
            day_means: List[float] = []
            total_points = 0
            total_weight = 0.0

            for d in days:
                pairs = []
                for s in series_list:
                    if d in s:
                        (net_apy, tb_usd, *_rest) = s[d]
                        if tb_usd is not None and tb_usd > 0:
                            pairs.append((net_apy, tb_usd))
                            total_points += 1
                            total_weight += tb_usd
                wm = _weighted_avg(pairs) if pairs else None
                if wm is not None and not math.isnan(wm):
                    day_means.append(wm)

            dw_mean = _avg(day_means)
            if dw_mean is not None:
                print(f"  {proto:<13}  days={len(day_means):<4d}  points={total_points:<6d}  weight_sum=${total_weight:,.0f}  weighted_mean={dw_mean:.3f}%")
                any_row = True

        if not any_row:
            print("  no data")
        print()

def _backtest_pair(
    collateral: str,
    per_venue: Dict[Tuple[str, str, str], Dict[date, Record]],
    pools: List[NormalizedPool],
    borrow_usdc: float
) -> None:
    """
    Strategy: each day choose feasible venue (borrowable≥borrow_usdc) with **snapshot net APY** minimum.
    Benchmark: for every venue, compute apples-to-apples overlap vs strategy with the venue snapshot each day.
    """
    # ----- column widths for pretty alignment -----
    LABEL_W = 30
    DAYS_W  = 8
    COV_W   = 6
    MEAN_W  = 12
    COST_W  = 18
    DELTA_W = 14
    DATE_W  = 12  # YYYY-MM-DD

    pool_idx = _build_pool_index(pools)

    # Relevant venues for this pair
    relevant_by_label: Dict[str, Dict[date, Record]] = {}
    for (proto, chain, pid), series in per_venue.items():
        if proto == "aave-v3":
            relevant_by_label[f"{proto}|{chain}"] = series
            continue

        rows = pool_idx.get((proto, chain, pid), [])
        if any(r["collateral"] == collateral and r["borrow"] == BORROW_ASSET for r in rows):
            relevant_by_label[f"{proto}|{chain}|{pid[:8]}"] = series

    if not relevant_by_label:
        print("  No venues found.")
        return

    # Feasibility diagnostics (before strategy)
    print("  Feasibility (borrowable ≥ requested):")
    for lbl, series in sorted(relevant_by_label.items()):
        days = len(series)
        feas = sum(1 for d in series if _feasible(series[d], borrow_usdc))
        print(f"    {lbl:<{LABEL_W}} {feas}/{days} days")
    print()

    # Strategy: pick min snapshot net APY among feasible venues each day (NO IRM)
    all_days = _union_days_dicts(list(relevant_by_label.values()))
    best_by_day: Dict[date, Tuple[str, float]] = {}  # date -> (label, net_apy%)
    for d in all_days:
        best_label = None
        best_apy = None
        for lbl, series in relevant_by_label.items():
            rec = series.get(d)
            if not rec:
                continue
            if not _feasible(rec, borrow_usdc):
                continue
            adj = _net_apy_snapshot(rec)
            if adj is None:
                continue
            if (best_apy is None) or (adj < best_apy):
                best_apy = adj
                best_label = lbl
        if best_label is not None:
            best_by_day[d] = (best_label, best_apy)

    strat_days = sorted(best_by_day.keys())
    if not strat_days:
        print("  Strategy has no feasible days.")
        return

    strat_mean = _avg([best_by_day[d][1] for d in strat_days]) or 0.0
    strat_cost = BORROW_cost(borrow_usdc, [best_by_day[d][1] for d in strat_days])

    print(f"  Strategy window: {len(strat_days)} days (of {LOOKBACK_DAYS} total)")
    print(f"  Strategy (daily rebalance): mean_APY={strat_mean:.3f}%  total_cost=${strat_cost:,.2f}\n")

    # Apples-to-apples vs each static venue on overlap days
    print("  Park-in-one-venue (apples-to-apples vs strategy on overlap days):")
    header = (
        f"    {'venue':<{LABEL_W}}"
        f" {'cov_days':>{DAYS_W}}"
        f" {'cov%':>{COV_W}}"
        f" {'venue_mean':>{MEAN_W}}"
        f" {'strat_mean':>{MEAN_W}}"
        f" {'venue_cost_USD':>{COST_W}}"
        f" {'strat_cost_USD':>{COST_W}}"
        f" {'Δcost':>{DELTA_W}}"
    )
    print(header)

    # Build a quick lookup for strategy daily apy
    strat_apy_by_day = {d: apy for d, (_, apy) in best_by_day.items()}

    rows = []
    for lbl, series in sorted(relevant_by_label.items()):
        # Overlap with strategy window AND venue feasible on the day
        overlap = [d for d in strat_days if d in series and _feasible(series[d], borrow_usdc)]
        if not overlap:
            continue

        venue_apys = []
        strat_apys = []
        for d in overlap:
            v_adj = _net_apy_snapshot(series[d])  # NO IRM
            if v_adj is None:
                continue
            venue_apys.append(v_adj)
            strat_apys.append(strat_apy_by_day[d])

        if not venue_apys:
            continue

        v_mean = _avg(venue_apys)
        s_mean = _avg(strat_apys)
        v_cost = BORROW_cost(borrow_usdc, venue_apys)
        s_cost = BORROW_cost(borrow_usdc, strat_apys)

        cov_days = len(overlap)
        cov_pct = 100.0 * cov_days / max(1, len(strat_days))

        rows.append((lbl, cov_days, cov_pct, v_mean, s_mean, v_cost, s_cost, v_cost - s_cost))

    # Sort by Δcost descending (how much more you’d pay by parking vs strategy)
    rows.sort(key=lambda r: r[7], reverse=True)

    for (lbl, covd, covpct, vmean, smean, vcost, scost, dcost) in rows:
        vmean_disp = f"{vmean:.3f}%" if vmean is not None else "nan%"
        smean_disp = f"{smean:.3f}%" if smean is not None else "nan%"
        line = (
            f"    {lbl:<{LABEL_W}}"
            f" {covd:>{DAYS_W}d}"
            f" {covpct:>{COV_W - 1}.1f}%"
            f" {vmean_disp:>{MEAN_W}}"
            f" {smean_disp:>{MEAN_W}}"
            f" {('$' + format(vcost, ',.2f')).rjust(COST_W)}"
            f" {('$' + format(scost, ',.2f')).rjust(COST_W)}"
            f" {('$' + format(dcost, '+,.2f')).rjust(DELTA_W)}"
        )
        print(line)
    print()

    # Show venues with zero feasible overlap against the strategy window (so nothing is invisible)
    covered = {lbl for (lbl, *_rest) in rows}
    non_overlap = [lbl for lbl in sorted(relevant_by_label.keys()) if lbl not in covered]
    if non_overlap:
        print("  (No feasible-overlap vs strategy window):")
        for lbl in non_overlap:
            series = relevant_by_label[lbl]
            feas_total = sum(1 for d in series if _feasible(series[d], borrow_usdc))
            print(f"    {lbl:<{LABEL_W}} feasible_any={feas_total}d, overlap=0d")
        print()

    # ---- Strategy daily picks (top 10) ----
    picks = Counter([lbl for _, (lbl, _) in best_by_day.items()])
    if picks:
        print("  Strategy daily picks (top 10):")
        for lbl, cnt in picks.most_common(10):
            print(f"    {lbl:<{LABEL_W}} {cnt:>4d} days")
        print()

    # ---- Daily breakdown (picked venue each day) ----
    print("  Daily breakdown (picked venue each day):")
    print(f"    {'date':<{DATE_W}}{'picked_venue':<{LABEL_W}}{'apy':>{MEAN_W}}")
    for d in strat_days:
        lbl, apy = best_by_day[d]
        print(f"    {d.isoformat():<{DATE_W}}{lbl:<{LABEL_W}}{(f'{apy:.3f}%'):>{MEAN_W}}")
    print()


def BORROW_cost(nominal_usdc: float, apy_series_pct: List[float]) -> float:
    """Sum daily effective interest with compounding ignored (linear add of daily effective costs)."""
    daily_rates = [_apy_pct_to_daily_rate(x) for x in apy_series_pct]
    return nominal_usdc * sum(daily_rates)


# =========================
# Main
# =========================

def run() -> int:
    pools: List[NormalizedPool] = get_pools(PROTOCOLS, COLLATERAL_ASSETS)
    if not pools:
        print("No pools found with the given filters.")
        return 0

    # Basic pool diagnostics
    if DEBUG_DIAG:
        by_proto = Counter(p["protocol"] for p in pools)
        print("[Pools] counts by protocol:", dict(by_proto))

    # Exact-day cutoff: include on/after this date, yielding up to LOOKBACK_DAYS dates
    now_utc = datetime.now(timezone.utc)
    cutoff_date = (now_utc - timedelta(days=LOOKBACK_DAYS)).date()

    # Build venue series
    per_venue = _build_per_venue_series(pools, cutoff_date)

    _print_configuration()
    _report_unweighted_pair_means(per_venue, pools)
    _report_weighted_pair_means_DW(per_venue, pools)

    print("\n==============================================================")
    print(" Backtest — Optimized Daily Rebalance vs Park-in-one-venue")
    print(" (Snapshot net borrow APY; NO IRM)")
    print("==============================================================\n")

    for collateral in COLLATERAL_ASSETS:
        params = PAIR_PARAMS[collateral]
        borrow_usdc = params["borrow_usdc"]
        coll_usd = params["collateral_usd"]

        print(f"{collateral}/{BORROW_ASSET} — Collateral=${coll_usd:,.0f}, Borrow=${borrow_usdc:,.0f}")
        _backtest_pair(collateral, per_venue, pools, borrow_usdc)

    return 0


if __name__ == "__main__":
    sys.exit(run())
