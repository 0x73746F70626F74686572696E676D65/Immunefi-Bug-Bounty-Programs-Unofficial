from typing import List, Dict, Any, TypedDict
import json
import os

class NormalizedPool(TypedDict):
    chain: str
    protocol: str
    collateral: str
    borrow: str
    pool_id: str

def get_pools(protocols: List[str], collateral_assets: List[str]) -> List[NormalizedPool]:
    with open("DefiLlamaPools.txt", "r") as f:
        data = json.load(f)

    if isinstance(data, dict) and "data" in data:
        pools: List[Dict[str, Any]] = data["data"]
    elif isinstance(data, list):
        pools = data
    else:
        raise ValueError("Unexpected JSON format")

    protocol_set = {p.lower() for p in protocols}
    collateral_set = {c.upper() for c in collateral_assets}

    # --- Precompute Aave-supported symbols per chain (for gating chains) ---
    aave_supported_by_chain: Dict[str, set] = {}
    for p in pools:
        if str(p.get("project", "")).lower() != "aave-v3":
            continue
        ch = str(p.get("chain", ""))
        sym = str(p.get("symbol", "")).upper()
        aave_supported_by_chain.setdefault(ch, set()).add(sym)

    results: List[NormalizedPool] = []
    seen_pool_ids: set[str] = set()

    def add_row(row: NormalizedPool) -> None:
        pid = row["pool_id"]
        if pid and pid not in seen_pool_ids:
            results.append(row)
            seen_pool_ids.add(pid)

    for pool in pools:
        project = str(pool.get("project", "")).lower()
        if project not in protocol_set:
            continue

        chain = str(pool.get("chain", ""))
        symbol = str(pool.get("symbol", "")).upper()
        pool_id = str(pool.get("pool", "")) or ""
        pool_meta = str(pool.get("poolMeta", "") or "")
        minted_coin = str(pool.get("mintedCoin", "")).upper()
        borrowable = bool(pool.get("borrowable"))

        if project == "morpho-blue":
            # minted coin must be exactly USDC; symbol is the collateral we care about
            if minted_coin != "USDC" or symbol not in collateral_set:
                continue
            add_row(NormalizedPool(
                chain=chain, protocol="morpho-blue",
                collateral=symbol, borrow="USDC", pool_id=pool_id
            ))

        elif project == "compound-v3":
            # include collateral rows tied to the USDC Comet (we'll resolve to Comet in optimizer)
            if pool_meta.strip().lower() == "usdc-pool" and symbol in collateral_set and symbol != "USDC":
                add_row(NormalizedPool(
                    chain=chain, protocol="compound-v3",
                    collateral=symbol, borrow="USDC", pool_id=pool_id
                ))
            # include the USDC base row (the Comet where borrow APY lives)
            if symbol == "USDC" and borrowable:
                add_row(NormalizedPool(
                    chain=chain, protocol="compound-v3",
                    collateral="USDC", borrow="USDC", pool_id=pool_id
                ))

        elif project == "aave-v3":
            # only include USDC reserve rows
            if symbol != "USDC":
                continue
            # Only add Aave USDC for chains that support at least one requested collateral
            supported = aave_supported_by_chain.get(chain, set())
            if not any(coll in supported for coll in collateral_set):
                continue
            add_row(NormalizedPool(
                chain=chain, protocol="aave-v3",
                collateral="N/A", borrow="USDC", pool_id=pool_id
            ))

    if os.getenv("POOLS_DEBUG", "0").strip().lower() not in ("0", "false", "no"):
        print(json.dumps(results, indent=2))
    return results
