import math
from typing import Final

def get_borrow_apy_usdc(utilization: float) -> float:
    """
    Compound-style kinked IRM → borrow APY (%) for USDC.

    Defaults (Gauntlet/Compound USDC Comet proposals):
      base_apr        = 0.015    # 1.5%
      slope_low_apr   = 0.061    # 6.1% per 1.0 util (u ≤ 0.90)
      kink_util       = 0.90     # 90% utilization kink
      slope_high_apr  = 3.20     # 320% per 1.0 util (u > 0.90)

    Input:
      utilization in [0, 1]

    Output:
      Borrow APY as a percent (e.g., 6.25 means 6.25% APY),
      using exp(APR) - 1 to align with per-second accrual → annualized.
    """
    # --- USDC defaults (Compound v3 / Comet style) ---
    base_apr       = 0.015
    slope_low_apr  = 0.061
    kink_util      = 0.90
    slope_high_apr = 3.20

    # clip to [0, 1]
    u = 0.0 if utilization < 0.0 else 1.0 if utilization > 1.0 else float(utilization)

    # piecewise APR
    if u <= kink_util:
        r_apr = base_apr + slope_low_apr * u
    else:
        r_apr = base_apr + slope_low_apr * kink_util + slope_high_apr * (u - kink_util)

    # APR -> APY with continuous compounding
    apy_decimal = math.exp(r_apr) - 1.0
    return apy_decimal * 100.0
