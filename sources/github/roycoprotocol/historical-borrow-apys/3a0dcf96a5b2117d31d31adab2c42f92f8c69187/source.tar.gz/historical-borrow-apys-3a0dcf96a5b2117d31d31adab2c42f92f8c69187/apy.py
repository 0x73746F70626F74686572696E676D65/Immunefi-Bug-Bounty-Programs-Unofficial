import requests
from urllib.parse import quote
from typing import List, Dict, Any, Optional


def _to_float(x) -> Optional[float]:
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def fetch_historical_borrow_apy(
    api_key: str,
    pool_id: str,
    min_borrowable_usd: float = 0
) -> List[Dict[str, Any]]:
    """
    Fetch historical borrow APY series for a pool and compute borrowable as liquidity:
      borrowableUsd = max(0, totalSupplyUsd - totalBorrowUsd)

    Only points with borrowableUsd >= min_borrowable_usd are kept (if threshold > 0).

    Returned fields per point:
      timestamp (ISO-8601), apyBaseBorrow (percent or None), apyRewardBorrow (percent or None),
      totalSupplyUsd, totalBorrowUsd, borrowableUsd.
    """
    url = f"https://pro-api.llama.fi/{api_key}/yields/chartLendBorrow/{quote(pool_id, safe='')}"
    resp = requests.get(url, timeout=30)
    resp.raise_for_status()
    series = resp.json().get("data", []) or []

    out: List[Dict[str, Any]] = []
    for pt in series:
        ts = pt.get("timestamp")
        base = _to_float(pt.get("apyBaseBorrow"))
        reward = _to_float(pt.get("apyRewardBorrow"))
        total_sup = _to_float(pt.get("totalSupplyUsd"))
        total_bor = _to_float(pt.get("totalBorrowUsd"))

        if ts is None:
            continue

        # Compute borrowable = supply - borrow (ignore ceilings)
        borrowable = None
        if total_sup is not None and total_bor is not None:
            borrowable = max(0.0, total_sup - total_bor)

        # Enforce threshold (if requested)
        if min_borrowable_usd > 0 and (borrowable is None or borrowable < min_borrowable_usd):
            continue

        out.append({
            "timestamp": ts,
            "apyBaseBorrow": base,             # can be None; optimizer will fallback from utilization
            "apyRewardBorrow": reward,
            "totalSupplyUsd": total_sup,
            "totalBorrowUsd": total_bor,
            "borrowableUsd": borrowable,
        })

    return out
