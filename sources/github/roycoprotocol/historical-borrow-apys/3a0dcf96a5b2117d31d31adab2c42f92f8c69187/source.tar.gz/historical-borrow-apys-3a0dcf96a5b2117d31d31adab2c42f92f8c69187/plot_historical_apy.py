#!/usr/bin/env pypy3

import os
import sys
from typing import List, Dict, Tuple
from datetime import datetime, timezone, timedelta

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.dates import AutoDateLocator, ConciseDateFormatter

from pools import get_pools, NormalizedPool
from apy import fetch_historical_borrow_apy 
from irm import get_borrow_apy_usdc
from dotenv import load_dotenv

# ---- Global state ----
load_dotenv()
PROTOCOLS: List[str] = ["aave-v3", "compound-v3", "morpho-blue"]
COLLATERAL_ASSETS: List[str] = ["WETH", "WBTC", "CBBTC"]  # the pairs are <collateral>/USDC

API_KEY = os.getenv("DEFI_LLAMA_API_KEY")
if not API_KEY:
    raise RuntimeError("DEFI_LLAMA_API_KEY environment variable is not set")

# Borrowable-capacity threshold (per point) enforced in the helper
MIN_BORROWABLE_USD = float(os.getenv("MIN_BORROWABLE_USD", "0"))

LOOKBACK_DAYS = int(os.getenv("LOOKBACK_DAYS", "183"))   # ~6 months; tunable via env
INCLUDE_REWARDS = True                                   # subtract reward APY from base if present

# Outlier clipping (percentile-based)
OUTLIER_CLIP = os.getenv("OUTLIER_CLIP", "1").strip() not in ("0", "false", "False")
OUTLIER_LOW_PCT = float(os.getenv("OUTLIER_LOW_PCT", "0.5"))   # keep >= this percentile
OUTLIER_HIGH_PCT = float(os.getenv("OUTLIER_HIGH_PCT", "99.5"))  # keep <= this percentile


def _parse_iso_utc(ts: str) -> datetime:
    """Parse API ISO-8601 timestamps into aware UTC datetimes."""
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00")).astimezone(timezone.utc)
    except Exception:
        base = ts.split(".")[0].replace("Z", "")
        return datetime.fromisoformat(base).replace(tzinfo=timezone.utc)


def _clip_outliers(xs: List[datetime], ys: List[float]) -> Tuple[List[datetime], List[float]]:
    """Clip outliers in ys using percentile bounds; return filtered xs, ys."""
    if not OUTLIER_CLIP or not ys or (OUTLIER_LOW_PCT <= 0 and OUTLIER_HIGH_PCT >= 100):
        return xs, ys

    lo = max(0.0, min(OUTLIER_LOW_PCT, 100.0))
    hi = max(0.0, min(OUTLIER_HIGH_PCT, 100.0))
    if hi <= lo:
        return xs, ys

    arr = np.asarray(ys, dtype=float)
    low_val = float(np.percentile(arr, lo))
    high_val = float(np.percentile(arr, hi))
    mask = (arr >= low_val) & (arr <= high_val)

    xs_f = [x for x, m in zip(xs, mask) if m]
    ys_f = [y for y, m in zip(ys, mask) if m]
    return xs_f, ys_f


def _fetch_series(pool_id: str, cutoff: datetime) -> Tuple[List[datetime], List[float]]:
    """
    Return X (UTC datetimes) and Y (NET borrow APY in %) for a pool id, filtered to cutoff.
    Net borrow APY = apyBaseBorrow - apyRewardBorrow (if INCLUDE_REWARDS and reward present).
    """
    series = fetch_historical_borrow_apy(API_KEY, pool_id, min_borrowable_usd=MIN_BORROWABLE_USD)
    xs: List[datetime] = []
    ys: List[float] = []

    for pt in series:
        ts = pt.get("timestamp")
        base = pt.get("apyBaseBorrow")
        reward = pt.get("apyRewardBorrow")
        if ts is None or base is None:
            continue
        dt = _parse_iso_utc(str(ts))
        if dt < cutoff:
            continue
        # rewards reduce effective borrow cost
        eff_apy = float(base) - (float(reward) if (INCLUDE_REWARDS and reward is not None) else 0.0)
        xs.append(dt)
        ys.append(eff_apy)

    # Outlier handling (percentile clip)
    xs, ys = _clip_outliers(xs, ys)
    return xs, ys


def _build_compound_usdc_map(pools: List[NormalizedPool]) -> Dict[str, str]:
    """
    Build a mapping of chain -> Compound v3 USDC base pool_id.
    Assumes get_pools includes the USDC base row for compound-v3 with collateral == 'USDC'.
    """
    return {
        p["chain"]: p["pool_id"]
        for p in pools
        if p["protocol"] == "compound-v3" and p["collateral"] == "USDC" and p["borrow"] == "USDC"
    }


def _plot_pair(
    pair_collateral: str,
    pools: List[NormalizedPool],
    cutoff: datetime,
    comp_usdc_by_chain: Dict[str, str],
) -> bool:
    """
    Plot a single chart for <pair_collateral>/USDC (NET borrow APY).
    Returns True if at least one series was plotted.
    """
    # Collateral->USDC pools (Morpho/Compound etc.)
    pair_pools = [
        p for p in pools
        if p["protocol"] != "aave-v3" and p["collateral"] == pair_collateral and p["borrow"] == "USDC"
    ]

    # Aave USDC pools (borrow side) — included on every chart
    aave_pools = [p for p in pools if p["protocol"] == "aave-v3" and p["borrow"] == "USDC"]

    if not pair_pools and not aave_pools:
        return False

    os.makedirs("./charts", exist_ok=True)

    # Wide canvas for readability
    fig, ax = plt.subplots(figsize=(24, 10))
    any_series = False

    # Plot collateral->USDC series
    for p in pair_pools:
        # For Compound v3, the borrow APY is on the USDC base ("Comet") market per chain.
        pool_id = p["pool_id"]
        if p["protocol"] == "compound-v3":
            pool_id = comp_usdc_by_chain.get(p["chain"], pool_id)

        xs, ys = _fetch_series(pool_id, cutoff)
        if not xs:
            continue
        label = f"{p['protocol']} | {p['chain']}"
        ax.plot(xs, ys, linewidth=1.8, alpha=0.95, label=label)
        any_series = True

    # Plot Aave USDC borrow lines
    for p in aave_pools:
        xs, ys = _fetch_series(p["pool_id"], cutoff)
        if not xs:
            continue
        label = f"aave-v3 | {p['chain']}"
        ax.plot(xs, ys, linewidth=1.6, alpha=0.8, linestyle="--", label=label)
        any_series = True

    if not any_series:
        plt.close(fig)
        return False

    # Formatting
    ax.set_title(
        f"Historical NET Borrow APY — {pair_collateral}/USDC (Last {LOOKBACK_DAYS} days, base"
        + (" - rewards" if INCLUDE_REWARDS else "")
        + ")",
        fontsize=16, loc="left"
    )
    ax.set_ylabel("Net Borrow APY (%)")
    ax.set_xlabel("Date (UTC)")
    ax.grid(True, linestyle="--", linewidth=0.6, alpha=0.35)

    # X-axis date formatting
    locator = AutoDateLocator()
    ax.xaxis.set_major_locator(locator)
    ax.xaxis.set_major_formatter(ConciseDateFormatter(locator))

    # Legend outside right
    ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), borderaxespad=0.0, frameon=False, fontsize=9)

    plt.tight_layout(rect=(0, 0, 0.8, 1))  # leave room for legend

    out_path = f"./charts/borrow_apy_{pair_collateral}_USDC_last_{LOOKBACK_DAYS}d.png"
    fig.savefig(out_path, dpi=180)
    plt.close(fig)
    print(f"Saved {out_path}")
    return True


def main() -> int:
    pools: List[NormalizedPool] = get_pools(PROTOCOLS, COLLATERAL_ASSETS)
    if not pools:
        print("No pools found with the given filters.")
        return 0

    comp_usdc_by_chain = _build_compound_usdc_map(pools)

    now_utc = datetime.now(timezone.utc)
    cutoff = now_utc - timedelta(days=LOOKBACK_DAYS)

    any_chart = False
    for collateral in COLLATERAL_ASSETS:
        ok = _plot_pair(collateral, pools, cutoff, comp_usdc_by_chain)
        any_chart = any_chart or ok

    if not any_chart:
        print("No qualifying historical series after filters.")
        return 0

    return 0


if __name__ == "__main__":
    sys.exit(main())
