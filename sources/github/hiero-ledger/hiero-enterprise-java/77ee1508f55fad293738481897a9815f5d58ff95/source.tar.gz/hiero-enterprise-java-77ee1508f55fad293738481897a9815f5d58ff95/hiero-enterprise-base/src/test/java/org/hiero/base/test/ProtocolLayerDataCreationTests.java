package org.hiero.base.test;

import static org.hiero.base.implementation.ProtocolLayerClientImpl.MAX_GAS_LIMIT;

import com.hedera.hashgraph.sdk.AccountId;
import com.hedera.hashgraph.sdk.ContractFunctionResult;
import com.hedera.hashgraph.sdk.ContractId;
import com.hedera.hashgraph.sdk.EvmHookStorageUpdate;
import com.hedera.hashgraph.sdk.FileId;
import com.hedera.hashgraph.sdk.Hbar;
import com.hedera.hashgraph.sdk.HookEntityId;
import com.hedera.hashgraph.sdk.HookId;
import com.hedera.hashgraph.sdk.NftId;
import com.hedera.hashgraph.sdk.PrivateKey;
import com.hedera.hashgraph.sdk.Status;
import com.hedera.hashgraph.sdk.TokenId;
import com.hedera.hashgraph.sdk.TokenType;
import com.hedera.hashgraph.sdk.TopicId;
import com.hedera.hashgraph.sdk.TransactionId;
import com.hedera.hashgraph.sdk.proto.ContractFunctionResultOrBuilder;
import java.lang.reflect.Constructor;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.IntStream;
import java.util.stream.LongStream;
import org.hiero.base.data.Account;
import org.hiero.base.data.ContractParam;
import org.hiero.base.protocol.data.AccountBalanceRequest;
import org.hiero.base.protocol.data.AccountBalanceResponse;
import org.hiero.base.protocol.data.AccountCreateRequest;
import org.hiero.base.protocol.data.AccountCreateResult;
import org.hiero.base.protocol.data.AccountDeleteRequest;
import org.hiero.base.protocol.data.AccountDeleteResult;
import org.hiero.base.protocol.data.AccountInfoRequest;
import org.hiero.base.protocol.data.AccountInfoResponse;
import org.hiero.base.protocol.data.AccountUpdateRequest;
import org.hiero.base.protocol.data.AccountUpdateResult;
import org.hiero.base.protocol.data.ContractCallRequest;
import org.hiero.base.protocol.data.ContractCallResult;
import org.hiero.base.protocol.data.ContractCreateRequest;
import org.hiero.base.protocol.data.ContractCreateResult;
import org.hiero.base.protocol.data.ContractDeleteRequest;
import org.hiero.base.protocol.data.ContractDeleteResult;
import org.hiero.base.protocol.data.FileAppendRequest;
import org.hiero.base.protocol.data.FileAppendResult;
import org.hiero.base.protocol.data.FileContentsRequest;
import org.hiero.base.protocol.data.FileContentsResponse;
import org.hiero.base.protocol.data.FileCreateRequest;
import org.hiero.base.protocol.data.FileCreateResult;
import org.hiero.base.protocol.data.FileDeleteRequest;
import org.hiero.base.protocol.data.FileDeleteResult;
import org.hiero.base.protocol.data.FileInfoRequest;
import org.hiero.base.protocol.data.FileInfoResponse;
import org.hiero.base.protocol.data.FileUpdateRequest;
import org.hiero.base.protocol.data.FileUpdateResult;
import org.hiero.base.protocol.data.HbarAllowanceApproveRequest;
import org.hiero.base.protocol.data.HbarAllowanceApproveResult;
import org.hiero.base.protocol.data.HbarTransferRequest;
import org.hiero.base.protocol.data.HbarTransferResult;
import org.hiero.base.protocol.data.HookStoreRequest;
import org.hiero.base.protocol.data.HookStoreResult;
import org.hiero.base.protocol.data.NftAllowanceDeleteRequest;
import org.hiero.base.protocol.data.NftAllowanceDeleteResult;
import org.hiero.base.protocol.data.TokenAirdropRequest;
import org.hiero.base.protocol.data.TokenAirdropResult;
import org.hiero.base.protocol.data.TokenAssociateRequest;
import org.hiero.base.protocol.data.TokenAssociateResult;
import org.hiero.base.protocol.data.TokenBurnRequest;
import org.hiero.base.protocol.data.TokenBurnResult;
import org.hiero.base.protocol.data.TokenCancelAirdropRequest;
import org.hiero.base.protocol.data.TokenCreateRequest;
import org.hiero.base.protocol.data.TokenCreateResult;
import org.hiero.base.protocol.data.TokenDeleteRequest;
import org.hiero.base.protocol.data.TokenDeleteResult;
import org.hiero.base.protocol.data.TokenDissociateRequest;
import org.hiero.base.protocol.data.TokenDissociateResult;
import org.hiero.base.protocol.data.TokenFreezeRequest;
import org.hiero.base.protocol.data.TokenFreezeResult;
import org.hiero.base.protocol.data.TokenGrantKycRequest;
import org.hiero.base.protocol.data.TokenGrantKycResult;
import org.hiero.base.protocol.data.TokenMintRequest;
import org.hiero.base.protocol.data.TokenMintResult;
import org.hiero.base.protocol.data.TokenRejectRequest;
import org.hiero.base.protocol.data.TokenRejectResult;
import org.hiero.base.protocol.data.TokenRevokeKycRequest;
import org.hiero.base.protocol.data.TokenRevokeKycResult;
import org.hiero.base.protocol.data.TokenTransferRequest;
import org.hiero.base.protocol.data.TokenTransferResult;
import org.hiero.base.protocol.data.TokenUnfreezeRequest;
import org.hiero.base.protocol.data.TokenUnfreezeResult;
import org.hiero.base.protocol.data.TokenUpdateNftsRequest;
import org.hiero.base.protocol.data.TokenUpdateNftsResult;
import org.hiero.base.protocol.data.TokenUpdateRequest;
import org.hiero.base.protocol.data.TokenUpdateResult;
import org.hiero.base.protocol.data.TokenWipeRequest;
import org.hiero.base.protocol.data.TokenWipeResult;
import org.hiero.base.protocol.data.TopicCreateRequest;
import org.hiero.base.protocol.data.TopicCreateResult;
import org.hiero.base.protocol.data.TopicDeleteRequest;
import org.hiero.base.protocol.data.TopicDeleteResult;
import org.hiero.base.protocol.data.TopicSubmitMessageRequest;
import org.hiero.base.protocol.data.TopicSubmitMessageResult;
import org.hiero.base.protocol.data.TopicUpdateRequest;
import org.hiero.base.protocol.data.TopicUpdateResult;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ProtocolLayerDataCreationTests {

  @Test
  void testAccountBalanceRequestCreation() {
    // given
    final String accountIdString = "0.0.12345";
    final AccountId accountId = AccountId.fromString(accountIdString);

    // then
    Assertions.assertDoesNotThrow(() -> AccountBalanceRequest.of(accountIdString));
    Assertions.assertDoesNotThrow(() -> AccountBalanceRequest.of(accountId));
    Assertions.assertDoesNotThrow(() -> new AccountBalanceRequest(accountId, null, null));
    Assertions.assertThrows(
        NullPointerException.class, () -> AccountBalanceRequest.of((String) null));
    Assertions.assertThrows(
        NullPointerException.class, () -> new AccountBalanceRequest(null, null, null));
  }

  @Test
  void testAccountBalanceResponseCreation() {
    // given
    final Hbar balance = Hbar.fromTinybars(1000);

    // then
    Assertions.assertDoesNotThrow(() -> AccountBalanceResponse.of(balance));
    Assertions.assertDoesNotThrow(() -> new AccountBalanceResponse(balance));
    Assertions.assertThrows(NullPointerException.class, () -> AccountBalanceResponse.of(null));
    Assertions.assertThrows(NullPointerException.class, () -> new AccountBalanceResponse(null));
    Assertions.assertThrows(
        IllegalArgumentException.class, () -> AccountBalanceResponse.of(Hbar.fromTinybars(-1000)));
    Assertions.assertThrows(
        IllegalArgumentException.class, () -> new AccountBalanceResponse(Hbar.fromTinybars(-1000)));
  }

  @Test
  void testAccountInfoRequestCreation() {
    // given
    final String accountIdString = "0.0.12345";
    final AccountId accountId = AccountId.fromString(accountIdString);

    // then
    Assertions.assertDoesNotThrow(() -> AccountInfoRequest.of(accountIdString));
    Assertions.assertDoesNotThrow(() -> AccountInfoRequest.of(accountId));
    Assertions.assertDoesNotThrow(() -> new AccountInfoRequest(accountId, null, null));
    Assertions.assertDoesNotThrow(
        () -> new AccountInfoRequest(accountId, Hbar.from(1), Hbar.from(2)));
    Assertions.assertThrows(NullPointerException.class, () -> AccountInfoRequest.of((String) null));
    Assertions.assertThrows(
        NullPointerException.class, () -> AccountInfoRequest.of((AccountId) null));
    Assertions.assertThrows(
        NullPointerException.class, () -> new AccountInfoRequest(null, null, null));
  }

  @Test
  void testAccountInfoResponseCreation() {
    // given
    final AccountId accountId = AccountId.fromString("0.0.12345");
    final PrivateKey privateKey = PrivateKey.generateED25519();
    final Instant expirationTime = Instant.now().plus(Duration.ofDays(90));
    final Duration autoRenewPeriod = Duration.ofDays(90);

    // then
    Assertions.assertDoesNotThrow(
        () ->
            new AccountInfoResponse(
                accountId,
                "0000000000000000000000000000000000003039",
                false,
                privateKey.getPublicKey(),
                Hbar.from(10),
                false,
                expirationTime,
                autoRenewPeriod,
                "memo",
                0L,
                0,
                null,
                null,
                0L,
                null));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new AccountInfoResponse(
                null,
                "0000000000000000000000000000000000003039",
                false,
                privateKey.getPublicKey(),
                Hbar.from(10),
                false,
                expirationTime,
                autoRenewPeriod,
                "memo",
                0L,
                0,
                null,
                null,
                0L,
                null));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new AccountInfoResponse(
                accountId,
                "0000000000000000000000000000000000003039",
                false,
                privateKey.getPublicKey(),
                Hbar.fromTinybars(-1),
                false,
                expirationTime,
                autoRenewPeriod,
                "memo",
                0L,
                0,
                null,
                null,
                0L,
                null));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new AccountInfoResponse(
                accountId,
                "0000000000000000000000000000000000003039",
                false,
                privateKey.getPublicKey(),
                Hbar.from(10),
                false,
                expirationTime,
                autoRenewPeriod,
                "memo",
                -1L,
                0,
                null,
                null,
                0L,
                null));
    Assertions.assertDoesNotThrow(
        () ->
            new AccountInfoResponse(
                accountId,
                "0000000000000000000000000000000000003039",
                false,
                privateKey.getPublicKey(),
                Hbar.from(10),
                false,
                expirationTime,
                autoRenewPeriod,
                "memo",
                0L,
                -1,
                null,
                null,
                0L,
                null));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new AccountInfoResponse(
                accountId,
                "0000000000000000000000000000000000003039",
                false,
                privateKey.getPublicKey(),
                Hbar.from(10),
                false,
                expirationTime,
                autoRenewPeriod,
                "memo",
                0L,
                -2,
                null,
                null,
                0L,
                null));
  }

  @Test
  void testAccountCreateRequestCreation() {
    // given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(10);
    final Hbar initialBalance = Hbar.fromTinybars(1000);

    // then
    Assertions.assertDoesNotThrow(() -> AccountCreateRequest.of());
    Assertions.assertDoesNotThrow(() -> AccountCreateRequest.of(initialBalance));
    Assertions.assertDoesNotThrow(
        () ->
            new AccountCreateRequest(
                Hbar.fromTinybars(1000), transactionValidDuration, initialBalance));
    Assertions.assertThrows(NullPointerException.class, () -> AccountCreateRequest.of(null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new AccountCreateRequest(null, transactionValidDuration, initialBalance));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new AccountCreateRequest(maxTransactionFee, null, initialBalance));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new AccountCreateRequest(maxTransactionFee, transactionValidDuration, null));
    Assertions.assertThrows(
        IllegalArgumentException.class, () -> AccountCreateRequest.of(Hbar.fromTinybars(-1000)));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> new AccountCreateRequest(maxTransactionFee, Duration.ZERO, initialBalance));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> new AccountCreateRequest(maxTransactionFee, Duration.ofSeconds(-10), initialBalance));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new AccountCreateRequest(
                Hbar.fromTinybars(-1000), transactionValidDuration, initialBalance));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new AccountCreateRequest(
                maxTransactionFee, transactionValidDuration, Hbar.fromTinybars(-1000)));
  }

  @Test
  void testAccountCreateResultCreation() {
    // given
    final AccountId accountId = new AccountId(0, 0, 12345);
    final PrivateKey privateKey = PrivateKey.generateECDSA();
    final Account account = Account.of(accountId, privateKey);
    final TransactionId transactionId = TransactionId.generate(accountId);
    final Status status = Status.SUCCESS;
    final byte[] transactionHash = new byte[] {};
    final Instant consensusTimestamp = Instant.now();
    final Hbar transactionFee = Hbar.fromTinybars(1000);

    // then
    Assertions.assertDoesNotThrow(
        () ->
            new AccountCreateResult(
                transactionId,
                status,
                transactionHash,
                consensusTimestamp,
                transactionFee,
                account));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new AccountCreateResult(
                null, status, transactionHash, consensusTimestamp, transactionFee, account));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new AccountCreateResult(
                transactionId, null, transactionHash, consensusTimestamp, transactionFee, account));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new AccountCreateResult(
                transactionId, status, null, consensusTimestamp, transactionFee, account));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new AccountCreateResult(
                transactionId, status, transactionHash, null, transactionFee, account));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new AccountCreateResult(
                transactionId, status, transactionHash, consensusTimestamp, null, account));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new AccountCreateResult(
                transactionId, status, transactionHash, consensusTimestamp, transactionFee, null));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new AccountCreateResult(
                transactionId,
                status,
                transactionHash,
                consensusTimestamp,
                Hbar.fromTinybars(-1000),
                account));
  }

  @Test
  void testAccountDeleteRequestCreation() {
    // given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(10);
    final Account toDelete = Account.of(new AccountId(0, 0, 12345), PrivateKey.generateECDSA());
    final Account transferFundsToAccount =
        Account.of(new AccountId(0, 0, 54321), PrivateKey.generateECDSA());

    // then
    Assertions.assertDoesNotThrow(() -> AccountDeleteRequest.of(toDelete));
    Assertions.assertDoesNotThrow(() -> AccountDeleteRequest.of(toDelete, transferFundsToAccount));
    Assertions.assertDoesNotThrow(() -> AccountDeleteRequest.of(toDelete, null));
    Assertions.assertDoesNotThrow(
        () ->
            new AccountDeleteRequest(
                maxTransactionFee, transactionValidDuration, toDelete, transferFundsToAccount));
    Assertions.assertDoesNotThrow(
        () ->
            new AccountDeleteRequest(maxTransactionFee, transactionValidDuration, toDelete, null));
    Assertions.assertThrows(NullPointerException.class, () -> AccountDeleteRequest.of(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> AccountDeleteRequest.of(null, transferFundsToAccount));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new AccountDeleteRequest(
                null, transactionValidDuration, toDelete, transferFundsToAccount));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new AccountDeleteRequest(maxTransactionFee, null, toDelete, transferFundsToAccount));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new AccountDeleteRequest(
                maxTransactionFee, transactionValidDuration, null, transferFundsToAccount));
    Assertions.assertThrows(
        IllegalArgumentException.class, () -> AccountDeleteRequest.of(toDelete, toDelete));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new AccountDeleteRequest(
                Hbar.from(-1000), transactionValidDuration, toDelete, transferFundsToAccount));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new AccountDeleteRequest(
                maxTransactionFee, Duration.ZERO, toDelete, transferFundsToAccount));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new AccountDeleteRequest(
                maxTransactionFee, Duration.ofSeconds(-10), toDelete, transferFundsToAccount));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new AccountDeleteRequest(
                maxTransactionFee, transactionValidDuration, toDelete, toDelete));
  }

  @Test
  void testAccountDeleteResultCreation() {
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;
    final byte[] transactionHash = new byte[] {};
    final Instant consensusTimestamp = Instant.now();
    final Hbar transactionFee = Hbar.fromTinybars(1000);

    Assertions.assertDoesNotThrow(
        () ->
            new AccountDeleteResult(
                transactionId, status, transactionHash, consensusTimestamp, transactionFee));
    Assertions.assertDoesNotThrow(
        () -> new AccountDeleteResult(transactionId, status, transactionHash, null, null));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new AccountDeleteResult(
                null, status, transactionHash, consensusTimestamp, transactionFee));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new AccountDeleteResult(
                transactionId, null, transactionHash, consensusTimestamp, transactionFee));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new AccountDeleteResult(
                transactionId, status, null, consensusTimestamp, transactionFee));
  }

  @Test
  void testAccountUpdateRequestCreation() {
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(10);
    final Account toUpdate = Account.of(new AccountId(0, 0, 12345), PrivateKey.generateECDSA());
    final PrivateKey updatedPrivateKey = PrivateKey.generateECDSA();
    final String memo = "updated-memo";

    Assertions.assertDoesNotThrow(
        () -> AccountUpdateRequest.updateKey(toUpdate, updatedPrivateKey));
    Assertions.assertDoesNotThrow(() -> AccountUpdateRequest.updateMemo(toUpdate, memo));
    Assertions.assertDoesNotThrow(() -> AccountUpdateRequest.of(toUpdate, updatedPrivateKey, memo));
    Assertions.assertDoesNotThrow(
        () ->
            new AccountUpdateRequest(
                maxTransactionFee, transactionValidDuration, toUpdate, updatedPrivateKey, null));
    Assertions.assertDoesNotThrow(
        () ->
            new AccountUpdateRequest(
                maxTransactionFee, transactionValidDuration, toUpdate, null, memo));
    Assertions.assertDoesNotThrow(
        () ->
            new AccountUpdateRequest(
                maxTransactionFee, transactionValidDuration, toUpdate, null, " "));
    Assertions.assertThrows(
        NullPointerException.class, () -> AccountUpdateRequest.updateKey(null, updatedPrivateKey));
    Assertions.assertThrows(
        NullPointerException.class, () -> AccountUpdateRequest.updateKey(toUpdate, null));
    Assertions.assertThrows(
        NullPointerException.class, () -> AccountUpdateRequest.updateMemo(toUpdate, null));
    Assertions.assertThrows(
        NullPointerException.class, () -> AccountUpdateRequest.updateMemo(null, memo));
    Assertions.assertThrows(
        NullPointerException.class, () -> AccountUpdateRequest.of(null, updatedPrivateKey, memo));
    Assertions.assertThrows(
        NullPointerException.class, () -> AccountUpdateRequest.of(toUpdate, null, memo));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> AccountUpdateRequest.of(toUpdate, updatedPrivateKey, null));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new AccountUpdateRequest(
                maxTransactionFee, transactionValidDuration, toUpdate, null, null));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new AccountUpdateRequest(
                Hbar.fromTinybars(-1000),
                transactionValidDuration,
                toUpdate,
                updatedPrivateKey,
                memo));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new AccountUpdateRequest(
                maxTransactionFee, Duration.ZERO, toUpdate, updatedPrivateKey, memo));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new AccountUpdateRequest(
                maxTransactionFee, Duration.ofSeconds(-1), toUpdate, updatedPrivateKey, memo));
  }

  @Test
  void testAccountUpdateResultCreation() {
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    Assertions.assertDoesNotThrow(() -> new AccountUpdateResult(transactionId, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new AccountUpdateResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new AccountUpdateResult(transactionId, null));
  }

  @Test
  void testTopicCreateRequestCreation() {
    // given
    final Hbar validMaxTransactionFee = Hbar.fromTinybars(1000);
    final Duration validTransactionDuration = Duration.ofSeconds(120);
    final PrivateKey adminKey = PrivateKey.generateECDSA();

    Assertions.assertDoesNotThrow(
        () ->
            new TopicCreateRequest(
                validMaxTransactionFee, validTransactionDuration, adminKey, null, null));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TopicCreateRequest(null, null, adminKey, null, null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TopicCreateRequest(null, validTransactionDuration, null, null, null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TopicCreateRequest(validMaxTransactionFee, null, null, null, null));
  }

  @Test
  void testTopicUpdateRequestCreation() {
    // given
    final Hbar validMaxTransactionFee = Hbar.fromTinybars(1000);
    final Duration validTransactionDuration = Duration.ofSeconds(120);
    final PrivateKey adminKey = PrivateKey.generateECDSA();
    final TopicId topicId = TopicId.fromString("1.2.3");

    Assertions.assertDoesNotThrow(
        () ->
            new TopicUpdateRequest(
                validMaxTransactionFee,
                validTransactionDuration,
                topicId,
                adminKey,
                null,
                null,
                null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TopicUpdateRequest(validMaxTransactionFee, null, null, null, null, null, null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TopicUpdateRequest(null, validTransactionDuration, null, null, null, null, null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TopicUpdateRequest(null, null, topicId, null, null, null, null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TopicUpdateRequest(null, null, null, adminKey, null, null, null));
  }

  @Test
  void testContractCallRequestCreation() {
    // given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(10);
    final String contractIdString = "0.0.12345";
    final ContractId contractId = ContractId.fromString(contractIdString);
    final String functionName = "functionName";
    final int gas = 1_000_000;
    final ContractParam<Long> contractParam = ContractParam.int32(1);
    final List<ContractParam<?>> constructorParams = List.of(contractParam);

    Assertions.assertDoesNotThrow(
        () -> ContractCallRequest.of(contractIdString, functionName, maxTransactionFee, gas));
    Assertions.assertDoesNotThrow(
        () ->
            ContractCallRequest.of(
                contractIdString, functionName, maxTransactionFee, gas, contractParam));
    Assertions.assertDoesNotThrow(
        () ->
            ContractCallRequest.of(
                contractIdString, functionName, maxTransactionFee, gas, constructorParams));
    Assertions.assertDoesNotThrow(
        () -> ContractCallRequest.of(contractId, functionName, maxTransactionFee, gas));
    Assertions.assertDoesNotThrow(
        () ->
            ContractCallRequest.of(
                contractId, functionName, maxTransactionFee, gas, contractParam));
    Assertions.assertDoesNotThrow(
        () ->
            ContractCallRequest.of(
                contractId, functionName, maxTransactionFee, gas, constructorParams));
    Assertions.assertDoesNotThrow(
        () ->
            new ContractCallRequest(
                maxTransactionFee,
                transactionValidDuration,
                contractId,
                functionName,
                gas,
                constructorParams));

    Assertions.assertThrows(
        NullPointerException.class,
        () -> ContractCallRequest.of((String) null, functionName, maxTransactionFee, gas));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> ContractCallRequest.of(contractIdString, null, maxTransactionFee, gas));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> ContractCallRequest.of(contractIdString, functionName, null, gas));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> ContractCallRequest.of(contractIdString, functionName, maxTransactionFee, -1));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            ContractCallRequest.of(
                contractIdString, functionName, maxTransactionFee, MAX_GAS_LIMIT + 1));

    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            ContractCallRequest.of(
                contractIdString, functionName, maxTransactionFee, gas, (ContractParam<?>) null));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            ContractCallRequest.of(
                contractIdString,
                functionName,
                maxTransactionFee,
                gas,
                (List<ContractParam<?>>) null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> ContractCallRequest.of((ContractId) null, functionName, maxTransactionFee, gas));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> ContractCallRequest.of(contractId, null, maxTransactionFee, gas));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            ContractCallRequest.of(
                contractId, functionName, maxTransactionFee, gas, (ContractParam<?>) null));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            ContractCallRequest.of(
                contractId, functionName, maxTransactionFee, gas, (List<ContractParam<?>>) null));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractCallRequest(
                null, transactionValidDuration, contractId, functionName, gas, constructorParams));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractCallRequest(
                maxTransactionFee, null, contractId, functionName, gas, constructorParams));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractCallRequest(
                maxTransactionFee,
                transactionValidDuration,
                null,
                functionName,
                gas,
                constructorParams));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractCallRequest(
                maxTransactionFee,
                transactionValidDuration,
                contractId,
                null,
                gas,
                constructorParams));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractCallRequest(
                maxTransactionFee, transactionValidDuration, contractId, functionName, gas, null));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new ContractCallRequest(
                Hbar.from(-100),
                transactionValidDuration,
                contractId,
                functionName,
                gas,
                constructorParams));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new ContractCallRequest(
                maxTransactionFee,
                Duration.ZERO,
                contractId,
                functionName,
                gas,
                constructorParams));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new ContractCallRequest(
                maxTransactionFee,
                Duration.ofSeconds(-1),
                contractId,
                functionName,
                gas,
                constructorParams));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new ContractCallRequest(
                maxTransactionFee,
                transactionValidDuration,
                contractId,
                "",
                gas,
                constructorParams));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new ContractCallRequest(
                maxTransactionFee,
                transactionValidDuration,
                contractId,
                "   ",
                gas,
                constructorParams));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new ContractCallRequest(
                maxTransactionFee,
                transactionValidDuration,
                contractId,
                " blankPrefix",
                gas,
                constructorParams));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new ContractCallRequest(
                maxTransactionFee,
                transactionValidDuration,
                contractId,
                "blankSuffix ",
                gas,
                constructorParams));
  }

  @Test
  void testContractCallResultCreation() throws Exception {
    // given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;
    final byte[] transactionHash = new byte[] {};
    final Instant consensusTimestamp = Instant.now();
    final Hbar transactionFee = Hbar.fromTinybars(1000);
    final com.hedera.hashgraph.sdk.proto.ContractFunctionResult contractFunctionResultProto =
        com.hedera.hashgraph.sdk.proto.ContractFunctionResult.newBuilder().build();
    final Constructor<ContractFunctionResult> constructor =
        ContractFunctionResult.class.getDeclaredConstructor(ContractFunctionResultOrBuilder.class);
    constructor.setAccessible(true);
    ContractFunctionResult contractFunctionResult =
        constructor.newInstance(contractFunctionResultProto);

    // then
    Assertions.assertDoesNotThrow(
        () ->
            new ContractCallResult(
                transactionId,
                status,
                transactionHash,
                consensusTimestamp,
                transactionFee,
                contractFunctionResult));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractCallResult(
                null,
                status,
                transactionHash,
                consensusTimestamp,
                transactionFee,
                contractFunctionResult));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractCallResult(
                transactionId,
                null,
                transactionHash,
                consensusTimestamp,
                transactionFee,
                contractFunctionResult));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractCallResult(
                transactionId,
                status,
                null,
                consensusTimestamp,
                transactionFee,
                contractFunctionResult));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractCallResult(
                transactionId,
                status,
                transactionHash,
                null,
                transactionFee,
                contractFunctionResult));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractCallResult(
                transactionId,
                status,
                transactionHash,
                consensusTimestamp,
                null,
                contractFunctionResult));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractCallResult(
                transactionId, status, transactionHash, consensusTimestamp, transactionFee, null));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new ContractCallResult(
                transactionId,
                status,
                transactionHash,
                consensusTimestamp,
                Hbar.fromTinybars(-1),
                contractFunctionResult));
  }

  @Test
  void testContractCreateRequestCreation() {
    // given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(10);
    final String fileIdString = "0.0.12345";
    final int gas = 1_000_000;
    final FileId fileId = FileId.fromString(fileIdString);
    final ContractParam<Long> contractParam = ContractParam.int32(1);
    final List<ContractParam<?>> constructorParams = List.of(contractParam);
    final PrivateKey adminKey = PrivateKey.generateECDSA();

    // then
    Assertions.assertDoesNotThrow(
        () -> ContractCreateRequest.of(fileIdString, maxTransactionFee, gas, adminKey));
    Assertions.assertDoesNotThrow(
        () ->
            ContractCreateRequest.of(
                fileIdString, maxTransactionFee, gas, adminKey, contractParam));
    Assertions.assertDoesNotThrow(
        () ->
            ContractCreateRequest.of(
                fileIdString, maxTransactionFee, gas, adminKey, constructorParams));
    Assertions.assertDoesNotThrow(
        () -> ContractCreateRequest.of(fileId, maxTransactionFee, gas, adminKey));
    Assertions.assertDoesNotThrow(
        () -> ContractCreateRequest.of(fileId, maxTransactionFee, gas, adminKey, contractParam));
    Assertions.assertDoesNotThrow(
        () ->
            ContractCreateRequest.of(fileId, maxTransactionFee, gas, adminKey, constructorParams));

    Assertions.assertDoesNotThrow(
        () ->
            new ContractCreateRequest(
                maxTransactionFee,
                transactionValidDuration,
                fileId,
                gas,
                adminKey,
                constructorParams));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> ContractCreateRequest.of((String) null, maxTransactionFee, gas, adminKey));
    Assertions.assertThrows(
        NullPointerException.class, () -> ContractCreateRequest.of(fileId, null, gas, adminKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            ContractCreateRequest.of(
                (String) null, maxTransactionFee, gas, adminKey, contractParam));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            ContractCreateRequest.of(
                (String) null, maxTransactionFee, gas, adminKey, constructorParams));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> ContractCreateRequest.of(fileIdString, null, gas, adminKey, constructorParams));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            ContractCreateRequest.of(
                fileIdString, maxTransactionFee, gas, adminKey, (ContractParam<?>) null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> ContractCreateRequest.of((FileId) null, maxTransactionFee, gas, adminKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            ContractCreateRequest.of(
                (FileId) null, maxTransactionFee, gas, adminKey, contractParam));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            ContractCreateRequest.of(
                (FileId) null, maxTransactionFee, gas, adminKey, constructorParams));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            ContractCreateRequest.of(
                fileId, maxTransactionFee, gas, adminKey, (ContractParam<?>) null));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            ContractCreateRequest.of(
                fileId, maxTransactionFee, gas, adminKey, (List<ContractParam<?>>) null));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractCreateRequest(
                null, transactionValidDuration, fileId, gas, adminKey, constructorParams));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractCreateRequest(
                maxTransactionFee, null, fileId, gas, adminKey, constructorParams));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractCreateRequest(
                maxTransactionFee,
                transactionValidDuration,
                null,
                gas,
                adminKey,
                constructorParams));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractCreateRequest(
                maxTransactionFee, transactionValidDuration, fileId, gas, adminKey, null));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new ContractCreateRequest(
                Hbar.from(-100),
                transactionValidDuration,
                fileId,
                gas,
                adminKey,
                constructorParams));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new ContractCreateRequest(
                maxTransactionFee, Duration.ZERO, fileId, gas, adminKey, constructorParams));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new ContractCreateRequest(
                maxTransactionFee,
                Duration.ofSeconds(-1),
                fileId,
                gas,
                adminKey,
                constructorParams));
  }

  @Test
  void testContractCreateResultCreation() {
    // given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;
    final ContractId contractId = ContractId.fromString("0.0.12345");

    // then
    Assertions.assertDoesNotThrow(
        () -> new ContractCreateResult(transactionId, status, contractId));
    Assertions.assertThrows(
        NullPointerException.class, () -> new ContractCreateResult(null, status, contractId));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new ContractCreateResult(transactionId, null, contractId));
    Assertions.assertThrows(
        NullPointerException.class, () -> new ContractCreateResult(transactionId, status, null));
  }

  @Test
  void testContractDeleteRequestCreation() {
    // given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(10);
    final String contractIdAsString = "0.0.12345";
    final ContractId contractId = ContractId.fromString(contractIdAsString);
    final ContractId transferFeeToContractId = ContractId.fromString("0.0.54321");
    final AccountId transferFeeToAccountId = new AccountId(0, 0, 54321);
    final PrivateKey adminKey = PrivateKey.generateECDSA();

    // then
    Assertions.assertDoesNotThrow(
        () -> ContractDeleteRequest.of(contractId, transferFeeToContractId, adminKey));
    Assertions.assertDoesNotThrow(
        () ->
            new ContractDeleteRequest(
                maxTransactionFee,
                transactionValidDuration,
                contractId,
                transferFeeToContractId,
                transferFeeToAccountId,
                adminKey));
    Assertions.assertDoesNotThrow(
        () ->
            new ContractDeleteRequest(
                maxTransactionFee,
                transactionValidDuration,
                contractId,
                null,
                transferFeeToAccountId,
                adminKey));
    Assertions.assertDoesNotThrow(
        () ->
            new ContractDeleteRequest(
                maxTransactionFee,
                transactionValidDuration,
                contractId,
                transferFeeToContractId,
                null,
                adminKey));
    Assertions.assertDoesNotThrow(
        () ->
            new ContractDeleteRequest(
                maxTransactionFee, transactionValidDuration, contractId, null, null, adminKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> ContractDeleteRequest.of(null, transferFeeToContractId, adminKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> ContractDeleteRequest.of(null, transferFeeToAccountId, adminKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> ContractDeleteRequest.of(contractId, transferFeeToContractId, null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> ContractDeleteRequest.of(contractId, transferFeeToAccountId, null));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractDeleteRequest(
                null,
                transactionValidDuration,
                contractId,
                transferFeeToContractId,
                transferFeeToAccountId,
                adminKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractDeleteRequest(
                maxTransactionFee,
                null,
                contractId,
                transferFeeToContractId,
                transferFeeToAccountId,
                adminKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractDeleteRequest(
                maxTransactionFee,
                transactionValidDuration,
                null,
                transferFeeToContractId,
                transferFeeToAccountId,
                adminKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new ContractDeleteRequest(
                maxTransactionFee,
                transactionValidDuration,
                contractId,
                transferFeeToContractId,
                transferFeeToAccountId,
                null));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new ContractDeleteRequest(
                Hbar.from(-100),
                transactionValidDuration,
                contractId,
                transferFeeToContractId,
                transferFeeToAccountId,
                adminKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new ContractDeleteRequest(
                maxTransactionFee,
                Duration.ZERO,
                contractId,
                transferFeeToContractId,
                transferFeeToAccountId,
                adminKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new ContractDeleteRequest(
                maxTransactionFee,
                Duration.ofSeconds(-1),
                contractId,
                transferFeeToContractId,
                transferFeeToAccountId,
                adminKey));
  }

  @Test
  void testContractDeleteResultCreation() {
    // given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    // then
    Assertions.assertDoesNotThrow(() -> new ContractDeleteResult(transactionId, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new ContractDeleteResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new ContractDeleteResult(transactionId, null));
  }

  @Test
  void testFileAppendRequestCreation() {
    // given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(10);
    final String fileIdString = "0.0.12345";
    final FileId fileId = FileId.fromString(fileIdString);
    final byte[] contents = new byte[] {};
    final byte[] largeContents =
        IntStream.range(0, 2050).mapToObj(i -> "a").reduce("", (a, b) -> a + b).getBytes();
    final String fileMemo = "fileMemo";
    final String longFileMemo =
        IntStream.range(0, 102).mapToObj(i -> "a").reduce("", (a, b) -> a + b);

    // then
    Assertions.assertDoesNotThrow(() -> FileAppendRequest.of(fileIdString, contents));
    Assertions.assertDoesNotThrow(() -> FileAppendRequest.of(fileId, contents));
    Assertions.assertDoesNotThrow(
        () ->
            new FileAppendRequest(
                maxTransactionFee, transactionValidDuration, fileId, contents, fileMemo));
    Assertions.assertDoesNotThrow(
        () ->
            new FileAppendRequest(
                maxTransactionFee, transactionValidDuration, fileId, contents, null));
    Assertions.assertThrows(
        NullPointerException.class, () -> FileAppendRequest.of((String) null, contents));
    Assertions.assertThrows(
        NullPointerException.class, () -> FileAppendRequest.of(fileIdString, null));
    Assertions.assertThrows(
        NullPointerException.class, () -> FileAppendRequest.of((FileId) null, contents));
    Assertions.assertThrows(NullPointerException.class, () -> FileAppendRequest.of(fileId, null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new FileAppendRequest(null, transactionValidDuration, fileId, contents, fileMemo));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new FileAppendRequest(maxTransactionFee, null, fileId, contents, fileMemo));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new FileAppendRequest(
                maxTransactionFee, transactionValidDuration, null, contents, fileMemo));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new FileAppendRequest(
                maxTransactionFee, transactionValidDuration, fileId, null, fileMemo));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new FileAppendRequest(
                Hbar.fromTinybars(-100), transactionValidDuration, fileId, contents, fileMemo));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> new FileAppendRequest(maxTransactionFee, Duration.ZERO, fileId, contents, fileMemo));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new FileAppendRequest(
                maxTransactionFee, Duration.ofSeconds(-1), fileId, contents, fileMemo));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new FileAppendRequest(
                maxTransactionFee, transactionValidDuration, fileId, largeContents, fileMemo));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new FileAppendRequest(
                maxTransactionFee, transactionValidDuration, fileId, largeContents, longFileMemo));
  }

  @Test
  public void testTokenTransferResultCreation() {
    // given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    // then
    Assertions.assertDoesNotThrow(() -> new TokenTransferResult(transactionId, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenTransferResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenTransferResult(transactionId, null));
  }

  @Test
  public void testTokenAirdropResultCreation() {
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    Assertions.assertDoesNotThrow(() -> new TokenAirdropResult(transactionId, status));
    Assertions.assertThrows(NullPointerException.class, () -> new TokenAirdropResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenAirdropResult(transactionId, null));
  }

  @Test
  public void testTokenRejectResultCreation() {
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    Assertions.assertDoesNotThrow(() -> new TokenRejectResult(transactionId, status));
    Assertions.assertThrows(NullPointerException.class, () -> new TokenRejectResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenRejectResult(transactionId, null));
  }

  @Test
  public void testHbarTransferResultCreation() {
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    Assertions.assertDoesNotThrow(() -> new HbarTransferResult(transactionId, status));
    Assertions.assertThrows(NullPointerException.class, () -> new HbarTransferResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new HbarTransferResult(transactionId, null));
  }

  @Test
  public void testHbarAllowanceApproveResultCreation() {
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    Assertions.assertDoesNotThrow(() -> new HbarAllowanceApproveResult(transactionId, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new HbarAllowanceApproveResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new HbarAllowanceApproveResult(transactionId, null));
  }

  @Test
  public void testNftAllowanceDeleteResultCreation() {
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    Assertions.assertDoesNotThrow(() -> new NftAllowanceDeleteResult(transactionId, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new NftAllowanceDeleteResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new NftAllowanceDeleteResult(transactionId, null));
  }

  @Test
  public void testTokenMintResultCreation() {
    // Given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;
    final List<Long> serials = List.of(1L, 2L, 3L);
    final Long totalSupply = 1L;

    // Then
    Assertions.assertDoesNotThrow(
        () -> new TokenMintResult(transactionId, status, serials, totalSupply));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenMintResult(null, status, serials, totalSupply));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TokenMintResult(transactionId, null, serials, totalSupply));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TokenMintResult(transactionId, status, null, totalSupply));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TokenMintResult(transactionId, status, serials, null));
  }

  @Test
  public void testTokenCreateResultCreation() {
    // Given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;
    final TokenId tokenId = TokenId.fromString("0.0.12345");

    // Then
    Assertions.assertDoesNotThrow(() -> new TokenCreateResult(transactionId, status, tokenId));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenCreateResult(null, status, tokenId));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenCreateResult(transactionId, null, tokenId));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenCreateResult(transactionId, status, null));
  }

  @Test
  public void testTokenBurnResultCreation() {
    // Given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;
    final Long totalSupply = 1L;

    // Then
    Assertions.assertDoesNotThrow(() -> new TokenBurnResult(transactionId, status, totalSupply));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenBurnResult(null, status, totalSupply));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenBurnResult(transactionId, null, totalSupply));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenBurnResult(transactionId, status, null));
  }

  @Test
  public void testTokenWipeResultCreation() {
    // Given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;
    final Long totalSupply = 0L;

    // Then
    Assertions.assertDoesNotThrow(() -> new TokenWipeResult(transactionId, status, totalSupply));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenWipeResult(null, status, totalSupply));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenWipeResult(transactionId, null, totalSupply));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenWipeResult(transactionId, status, null));
  }

  @Test
  public void testTokenAssociateResultCreation() {
    // Given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    // Then
    Assertions.assertDoesNotThrow(() -> new TokenAssociateResult(transactionId, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenAssociateResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenAssociateResult(transactionId, null));
  }

  @Test
  public void testTokenDissociateResultCreation() {
    // Given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    // Then
    Assertions.assertDoesNotThrow(() -> new TokenDissociateResult(transactionId, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenDissociateResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenDissociateResult(transactionId, null));
  }

  @Test
  public void testTokenFreezeResultCreation() {
    // Given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    // Then
    Assertions.assertDoesNotThrow(() -> new TokenFreezeResult(transactionId, status));
    Assertions.assertThrows(NullPointerException.class, () -> new TokenFreezeResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenFreezeResult(transactionId, null));
  }

  @Test
  public void testTokenUnfreezeResultCreation() {
    // Given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    // Then
    Assertions.assertDoesNotThrow(() -> new TokenUnfreezeResult(transactionId, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenUnfreezeResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenUnfreezeResult(transactionId, null));
  }

  @Test
  public void testTokenGrantKycResultCreation() {
    // Given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    // Then
    Assertions.assertDoesNotThrow(() -> new TokenGrantKycResult(transactionId, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenGrantKycResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenGrantKycResult(transactionId, null));
  }

  @Test
  public void testTokenRevokeKycResultCreation() {
    // Given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    // Then
    Assertions.assertDoesNotThrow(() -> new TokenRevokeKycResult(transactionId, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenRevokeKycResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenRevokeKycResult(transactionId, null));
  }

  @Test
  void testFileUpdateResultCreation() {
    // Given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    // Then
    Assertions.assertDoesNotThrow(() -> new FileUpdateResult(transactionId, status));
    Assertions.assertThrows(NullPointerException.class, () -> new FileUpdateResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new FileUpdateResult(transactionId, null));
  }

  @Test
  void testFileInfoResponseCreation() {
    // Given
    final FileId fileId = FileId.fromString("0.0.12345");
    final int size = 100;
    final boolean deleted = false;
    final Instant expirationTime = Instant.now().plus(Duration.ofDays(30));

    // Then
    Assertions.assertDoesNotThrow(
        () -> new FileInfoResponse(fileId, size, deleted, expirationTime));
  }

  @Test
  void testFileDeleteResultCreation() {
    // Given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    // Then
    Assertions.assertDoesNotThrow(() -> new FileDeleteResult(transactionId, status));
    Assertions.assertThrows(NullPointerException.class, () -> new FileDeleteResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new FileDeleteResult(transactionId, null));
  }

  @Test
  void testFileCreateResultCreation() {
    // Given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;
    final FileId fileId = FileId.fromString("0.0.12345");

    // Then
    Assertions.assertDoesNotThrow(() -> new FileCreateResult(transactionId, status, fileId));
    Assertions.assertThrows(
        NullPointerException.class, () -> new FileCreateResult(null, status, fileId));
    Assertions.assertThrows(
        NullPointerException.class, () -> new FileCreateResult(transactionId, null, fileId));
    Assertions.assertThrows(
        NullPointerException.class, () -> new FileCreateResult(transactionId, status, null));
  }

  @Test
  void testFileContentsResponseCreation() {
    // Given
    final FileId fileId = FileId.fromString("0.0.12345");
    final byte[] contents = new byte[] {1, 2, 3};

    // Then
    Assertions.assertDoesNotThrow(() -> new FileContentsResponse(fileId, contents));
    Assertions.assertThrows(
        NullPointerException.class, () -> new FileContentsResponse(null, contents));
    Assertions.assertThrows(
        NullPointerException.class, () -> new FileContentsResponse(fileId, null));
  }

  @Test
  void testFileAppendResultCreation() {
    // Given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    // Then
    Assertions.assertDoesNotThrow(() -> new FileAppendResult(transactionId, status));
    Assertions.assertThrows(NullPointerException.class, () -> new FileAppendResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new FileAppendResult(transactionId, null));
  }

  @Test
  void testTokenTransferRequestCreation() {
    // given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final TokenId tokenId = TokenId.fromString("0.0.1234");
    final List<Long> serials = List.of(1L, 2L);
    final AccountId sender = AccountId.fromString("0.0.5678");
    final AccountId receiver = AccountId.fromString("0.0.9876");
    final PrivateKey senderKey = PrivateKey.generateECDSA();
    final List<Long> emptySerials = List.of();
    final List<Long> negativeSerials = List.of(-1L);
    final Long amount = 1l;

    // then
    Assertions.assertDoesNotThrow(
        () ->
            new TokenTransferRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                emptySerials,
                amount,
                sender,
                receiver,
                senderKey));
    Assertions.assertDoesNotThrow(
        () ->
            new TokenTransferRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                serials,
                null,
                sender,
                receiver,
                senderKey));
    Assertions.assertDoesNotThrow(
        () -> TokenTransferRequest.of(tokenId, 1L, sender, receiver, senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenTransferRequest(
                null,
                transactionValidDuration,
                tokenId,
                serials,
                amount,
                sender,
                receiver,
                senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenTransferRequest(
                maxTransactionFee, null, tokenId, serials, null, sender, receiver, senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenTransferRequest(
                maxTransactionFee,
                transactionValidDuration,
                null,
                serials,
                null,
                sender,
                receiver,
                senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenTransferRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                null,
                amount,
                sender,
                receiver,
                senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenTransferRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                serials,
                null,
                null,
                receiver,
                senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenTransferRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                serials,
                null,
                sender,
                null,
                senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenTransferRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                serials,
                null,
                sender,
                receiver,
                null));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new TokenTransferRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                emptySerials,
                null,
                sender,
                receiver,
                senderKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new TokenTransferRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                negativeSerials,
                null,
                sender,
                receiver,
                senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenTransferRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                null,
                null,
                sender,
                receiver,
                senderKey));
  }

  @Test
  void testTokenAirdropRequestCreation() {
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final TokenId tokenId = TokenId.fromString("0.0.1234");
    final List<Long> serials = List.of(1L, 2L);
    final AccountId sender = AccountId.fromString("0.0.5678");
    final AccountId receiver = AccountId.fromString("0.0.9876");
    final AccountId receiver2 = AccountId.fromString("0.0.9877");
    final PrivateKey senderKey = PrivateKey.generateECDSA();
    final Map<Long, AccountId> serialToReceiver = Map.of(1L, receiver, 2L, receiver2);

    Assertions.assertDoesNotThrow(
        () ->
            new TokenAirdropRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                serialToReceiver,
                sender,
                senderKey));
    Assertions.assertDoesNotThrow(
        () -> TokenAirdropRequest.of(tokenId, 1L, sender, receiver, senderKey));
    Assertions.assertDoesNotThrow(
        () -> TokenAirdropRequest.of(tokenId, serials, sender, receiver, senderKey));
    Assertions.assertDoesNotThrow(
        () -> TokenAirdropRequest.of(tokenId, serialToReceiver, sender, senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenAirdropRequest(
                null, transactionValidDuration, tokenId, serialToReceiver, sender, senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenAirdropRequest(
                maxTransactionFee, null, tokenId, serialToReceiver, sender, senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenAirdropRequest(
                maxTransactionFee,
                transactionValidDuration,
                null,
                serialToReceiver,
                sender,
                senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenAirdropRequest(
                maxTransactionFee, transactionValidDuration, tokenId, null, sender, senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenAirdropRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                serialToReceiver,
                null,
                senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenAirdropRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                serialToReceiver,
                sender,
                null));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new TokenAirdropRequest(
                maxTransactionFee, transactionValidDuration, tokenId, Map.of(), sender, senderKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new TokenAirdropRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                Map.of(-1L, receiver),
                sender,
                senderKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new TokenAirdropRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                Map.of(0L, receiver),
                sender,
                senderKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> TokenAirdropRequest.of(tokenId, List.of(), sender, receiver, senderKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new TokenAirdropRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                IntStream.rangeClosed(1, 21)
                    .boxed()
                    .collect(
                        java.util.stream.Collectors.toMap(
                            i -> (long) i, i -> receiver, (a, b) -> a, LinkedHashMap::new)),
                sender,
                senderKey));
  }

  @Test
  void testTokenCancelAirdropRequestCreation() {
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final TokenId tokenId = TokenId.fromString("0.0.1234");
    final List<Long> serials = List.of(1L, 2L);
    final AccountId sender = AccountId.fromString("0.0.5678");
    final AccountId receiver = AccountId.fromString("0.0.9876");
    final AccountId receiver2 = AccountId.fromString("0.0.9877");
    final PrivateKey senderKey = PrivateKey.generateECDSA();
    final Map<Long, AccountId> serialToReceiver = Map.of(1L, receiver, 2L, receiver2);

    Assertions.assertDoesNotThrow(
        () ->
            new TokenCancelAirdropRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                serialToReceiver,
                sender,
                senderKey));
    Assertions.assertDoesNotThrow(
        () -> TokenCancelAirdropRequest.of(tokenId, 1L, sender, receiver, senderKey));
    Assertions.assertDoesNotThrow(
        () -> TokenCancelAirdropRequest.of(tokenId, serials, sender, receiver, senderKey));
    Assertions.assertDoesNotThrow(
        () -> TokenCancelAirdropRequest.of(tokenId, serialToReceiver, sender, senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenCancelAirdropRequest(
                null, transactionValidDuration, tokenId, serialToReceiver, sender, senderKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new TokenCancelAirdropRequest(
                maxTransactionFee, transactionValidDuration, tokenId, Map.of(), sender, senderKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new TokenCancelAirdropRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                Map.of(-1L, receiver),
                sender,
                senderKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> TokenCancelAirdropRequest.of(tokenId, List.of(), sender, receiver, senderKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new TokenCancelAirdropRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                IntStream.rangeClosed(1, 11)
                    .boxed()
                    .collect(
                        java.util.stream.Collectors.toMap(
                            i -> (long) i, i -> receiver, (a, b) -> a, LinkedHashMap::new)),
                sender,
                senderKey));
  }

  @Test
  void testTokenRejectRequestCreation() {
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final TokenId tokenId = TokenId.fromString("0.0.1234");
    final List<Long> serials = List.of(1L, 2L);
    final AccountId owner = AccountId.fromString("0.0.5678");
    final PrivateKey ownerKey = PrivateKey.generateECDSA();

    Assertions.assertDoesNotThrow(
        () ->
            new TokenRejectRequest(
                maxTransactionFee, transactionValidDuration, tokenId, serials, owner, ownerKey));
    Assertions.assertDoesNotThrow(() -> TokenRejectRequest.of(tokenId, 1L, owner, ownerKey));
    Assertions.assertDoesNotThrow(() -> TokenRejectRequest.of(tokenId, serials, owner, ownerKey));
    Assertions.assertDoesNotThrow(
        () ->
            TokenRejectRequest.of(
                tokenId, LongStream.rangeClosed(1, 10).boxed().toList(), owner, ownerKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenRejectRequest(
                null, transactionValidDuration, tokenId, serials, owner, ownerKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TokenRejectRequest(maxTransactionFee, null, tokenId, serials, owner, ownerKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenRejectRequest(
                maxTransactionFee, transactionValidDuration, null, serials, owner, ownerKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenRejectRequest(
                maxTransactionFee, transactionValidDuration, tokenId, null, owner, ownerKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenRejectRequest(
                maxTransactionFee, transactionValidDuration, tokenId, serials, null, ownerKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenRejectRequest(
                maxTransactionFee, transactionValidDuration, tokenId, serials, owner, null));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenRejectRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                Arrays.asList(1L, null),
                owner,
                ownerKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> TokenRejectRequest.of(tokenId, List.of(), owner, ownerKey));
    Assertions.assertThrows(
        IllegalArgumentException.class, () -> TokenRejectRequest.of(tokenId, 0L, owner, ownerKey));
    Assertions.assertThrows(
        IllegalArgumentException.class, () -> TokenRejectRequest.of(tokenId, -1L, owner, ownerKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> TokenRejectRequest.of(tokenId, List.of(1L, 1L), owner, ownerKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            TokenRejectRequest.of(
                tokenId, LongStream.rangeClosed(1, 11).boxed().toList(), owner, ownerKey));
  }

  @Test
  void testHbarTransferRequestCreation() {
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final AccountId sender = AccountId.fromString("0.0.5678");
    final AccountId receiver = AccountId.fromString("0.0.9876");
    final PrivateKey senderKey = PrivateKey.generateECDSA();
    final Hbar amount = Hbar.from(1);

    Assertions.assertDoesNotThrow(
        () ->
            new HbarTransferRequest(
                maxTransactionFee, transactionValidDuration, sender, receiver, amount, senderKey));
    Assertions.assertDoesNotThrow(
        () -> HbarTransferRequest.of(sender, receiver, amount, senderKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> HbarTransferRequest.of(sender, sender, amount, senderKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> HbarTransferRequest.of(sender, receiver, Hbar.ZERO, senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new HbarTransferRequest(
                null, transactionValidDuration, sender, receiver, amount, senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new HbarTransferRequest(maxTransactionFee, null, sender, receiver, amount, senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new HbarTransferRequest(
                maxTransactionFee, transactionValidDuration, null, receiver, amount, senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new HbarTransferRequest(
                maxTransactionFee, transactionValidDuration, sender, null, amount, senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new HbarTransferRequest(
                maxTransactionFee, transactionValidDuration, sender, receiver, null, senderKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new HbarTransferRequest(
                maxTransactionFee, transactionValidDuration, sender, receiver, amount, null));
  }

  @Test
  void testHbarAllowanceApproveRequestCreation() {
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final AccountId owner = AccountId.fromString("0.0.5678");
    final AccountId spender = AccountId.fromString("0.0.9876");
    final PrivateKey ownerKey = PrivateKey.generateECDSA();
    final Hbar amount = Hbar.from(1);

    Assertions.assertDoesNotThrow(
        () ->
            new HbarAllowanceApproveRequest(
                maxTransactionFee, transactionValidDuration, owner, spender, amount, ownerKey));
    Assertions.assertDoesNotThrow(
        () -> HbarAllowanceApproveRequest.of(owner, spender, amount, ownerKey));
    Assertions.assertDoesNotThrow(
        () -> HbarAllowanceApproveRequest.of(owner, spender, Hbar.ZERO, ownerKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> HbarAllowanceApproveRequest.of(owner, owner, amount, ownerKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> HbarAllowanceApproveRequest.of(owner, spender, Hbar.from(-1), ownerKey));
  }

  @Test
  void testNftAllowanceDeleteRequestCreation() {
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final AccountId owner = AccountId.fromString("0.0.5678");
    final PrivateKey ownerKey = PrivateKey.generateECDSA();
    final NftId nftId = new NftId(TokenId.fromString("0.0.12345"), 1L);

    Assertions.assertDoesNotThrow(
        () ->
            new NftAllowanceDeleteRequest(
                maxTransactionFee, transactionValidDuration, owner, nftId, ownerKey));
    Assertions.assertDoesNotThrow(() -> NftAllowanceDeleteRequest.of(owner, nftId, ownerKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            NftAllowanceDeleteRequest.of(
                owner, new NftId(TokenId.fromString("0.0.12345"), -1L), ownerKey));
    Assertions.assertThrows(
        NullPointerException.class, () -> NftAllowanceDeleteRequest.of(null, nftId, ownerKey));
    Assertions.assertThrows(
        NullPointerException.class, () -> NftAllowanceDeleteRequest.of(owner, null, ownerKey));
    Assertions.assertThrows(
        NullPointerException.class, () -> NftAllowanceDeleteRequest.of(owner, nftId, null));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new NftAllowanceDeleteRequest(
                maxTransactionFee, transactionValidDuration, null, nftId, ownerKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new NftAllowanceDeleteRequest(
                maxTransactionFee, transactionValidDuration, owner, null, ownerKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new NftAllowanceDeleteRequest(
                maxTransactionFee, transactionValidDuration, owner, nftId, null));
  }

  @Test
  void testTokenMintRequestCreation() {
    // given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final TokenId tokenId = TokenId.fromString("0.0.12345");
    final PrivateKey supplyKey = PrivateKey.generateECDSA();
    final Long amount = 10L;
    final List<byte[]> validMetadata = List.of("valid".getBytes(StandardCharsets.UTF_8));
    final byte[] largeMetadata = new byte[101];

    // then
    Assertions.assertDoesNotThrow(
        () ->
            new TokenMintRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                supplyKey,
                amount,
                validMetadata));
    Assertions.assertDoesNotThrow(
        () ->
            new TokenMintRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                supplyKey,
                null,
                validMetadata));
    Assertions.assertDoesNotThrow(
        () ->
            new TokenMintRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                supplyKey,
                amount,
                List.of()));
    Assertions.assertDoesNotThrow(() -> TokenMintRequest.of(tokenId, supplyKey, "valid metadata"));
    Assertions.assertDoesNotThrow(() -> TokenMintRequest.of(tokenId, supplyKey, amount));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenMintRequest(
                maxTransactionFee,
                transactionValidDuration,
                null,
                supplyKey,
                amount,
                validMetadata));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenMintRequest(
                maxTransactionFee, transactionValidDuration, tokenId, null, amount, validMetadata));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenMintRequest(
                maxTransactionFee, transactionValidDuration, tokenId, supplyKey, amount, null));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new TokenMintRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                supplyKey,
                0L,
                validMetadata));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new TokenMintRequest(
                maxTransactionFee, transactionValidDuration, tokenId, supplyKey, null, List.of()));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new TokenMintRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                supplyKey,
                null,
                List.of(largeMetadata)));
  }

  @Test
  void testTokenCreateRequestCreation() {
    // Given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final String name = "Token Name";
    final String symbol = "TKN";
    final AccountId treasuryAccountId = AccountId.fromString("0.0.12345");
    final PrivateKey treasuryKey = PrivateKey.generateECDSA();
    final PrivateKey supplyKey = PrivateKey.generateECDSA();
    final TokenType tokenType = TokenType.FUNGIBLE_COMMON;

    // Then
    Assertions.assertDoesNotThrow(
        () ->
            new TokenCreateRequest(
                maxTransactionFee,
                transactionValidDuration,
                name,
                symbol,
                treasuryAccountId,
                treasuryKey,
                tokenType,
                supplyKey,
                treasuryKey,
                null,
                null,
                null,
                null));
    Assertions.assertDoesNotThrow(
        () -> TokenCreateRequest.of(name, symbol, treasuryAccountId, treasuryKey));
    Assertions.assertDoesNotThrow(
        () ->
            TokenCreateRequest.of(
                name,
                symbol,
                treasuryAccountId,
                treasuryKey,
                tokenType,
                supplyKey,
                PrivateKey.generateECDSA()));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenCreateRequest(
                null,
                transactionValidDuration,
                name,
                symbol,
                treasuryAccountId,
                treasuryKey,
                tokenType,
                supplyKey,
                treasuryKey,
                null,
                null,
                null,
                null));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenCreateRequest(
                maxTransactionFee,
                null,
                name,
                symbol,
                treasuryAccountId,
                treasuryKey,
                tokenType,
                supplyKey,
                treasuryKey,
                null,
                null,
                null,
                null));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenCreateRequest(
                maxTransactionFee,
                transactionValidDuration,
                null,
                symbol,
                treasuryAccountId,
                treasuryKey,
                tokenType,
                supplyKey,
                treasuryKey,
                null,
                null,
                null,
                null));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenCreateRequest(
                maxTransactionFee,
                transactionValidDuration,
                name,
                null,
                treasuryAccountId,
                treasuryKey,
                tokenType,
                supplyKey,
                treasuryKey,
                null,
                null,
                null,
                null));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenCreateRequest(
                maxTransactionFee,
                transactionValidDuration,
                name,
                symbol,
                null,
                treasuryKey,
                tokenType,
                supplyKey,
                treasuryKey,
                null,
                null,
                null,
                null));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenCreateRequest(
                maxTransactionFee,
                transactionValidDuration,
                name,
                symbol,
                treasuryAccountId,
                treasuryKey,
                null,
                supplyKey,
                treasuryKey,
                null,
                null,
                null,
                null));
  }

  @Test
  void testTokenDeleteRequestCreation() {
    // Given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final TokenId tokenId = TokenId.fromString("0.0.12345");
    final PrivateKey supplyKey = PrivateKey.generateECDSA();

    // Then
    Assertions.assertDoesNotThrow(
        () ->
            new TokenDeleteRequest(
                maxTransactionFee, transactionValidDuration, tokenId, supplyKey));
    Assertions.assertDoesNotThrow(() -> TokenDeleteRequest.of(tokenId, supplyKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TokenDeleteRequest(null, transactionValidDuration, tokenId, supplyKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TokenDeleteRequest(maxTransactionFee, null, tokenId, supplyKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TokenDeleteRequest(maxTransactionFee, transactionValidDuration, null, supplyKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TokenDeleteRequest(maxTransactionFee, transactionValidDuration, tokenId, null));
  }

  @Test
  void testTokenDeleteResultCreation() {
    // Given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    // Then
    Assertions.assertDoesNotThrow(() -> new TokenDeleteResult(transactionId, status));
    Assertions.assertThrows(NullPointerException.class, () -> new TokenDeleteResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenDeleteResult(transactionId, null));
  }

  @Test
  void testTokenUpdateRequestCreation() {
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final TokenId tokenId = TokenId.fromString("0.0.12345");
    final PrivateKey adminKey = PrivateKey.generateECDSA();
    final String name = "Updated NFT";
    final String symbol = "UNFT";
    final String tooLongSymbol =
        IntStream.range(0, 101).mapToObj(i -> "a").reduce("", (a, b) -> a + b);

    Assertions.assertDoesNotThrow(
        () ->
            new TokenUpdateRequest(
                maxTransactionFee, transactionValidDuration, tokenId, adminKey, name, symbol));
    Assertions.assertDoesNotThrow(() -> TokenUpdateRequest.of(tokenId, adminKey, name, symbol));
    Assertions.assertDoesNotThrow(() -> TokenUpdateRequest.of(tokenId, adminKey, name, null));
    Assertions.assertDoesNotThrow(() -> TokenUpdateRequest.of(tokenId, adminKey, null, symbol));
    Assertions.assertDoesNotThrow(() -> TokenUpdateRequest.of("0.0.12345", adminKey, name, symbol));
    Assertions.assertThrows(
        IllegalArgumentException.class, () -> TokenUpdateRequest.of(tokenId, adminKey, null, null));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> TokenUpdateRequest.of(tokenId, adminKey, name, tooLongSymbol));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenUpdateRequest(
                null, transactionValidDuration, tokenId, adminKey, name, symbol));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TokenUpdateRequest(maxTransactionFee, null, tokenId, adminKey, name, symbol));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenUpdateRequest(
                maxTransactionFee, transactionValidDuration, null, adminKey, name, symbol));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenUpdateRequest(
                maxTransactionFee, transactionValidDuration, tokenId, null, name, symbol));
  }

  @Test
  void testTokenUpdateResultCreation() {
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    Assertions.assertDoesNotThrow(() -> new TokenUpdateResult(transactionId, status));
    Assertions.assertThrows(NullPointerException.class, () -> new TokenUpdateResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenUpdateResult(transactionId, null));
  }

  @Test
  void testTokenUpdateNftsRequestCreation() {
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final TokenId tokenId = TokenId.fromString("0.0.12345");
    final PrivateKey metadataKey = PrivateKey.generateECDSA();
    final List<Long> serials = List.of(1L, 2L);
    final byte[] metadata = "updated".getBytes(StandardCharsets.UTF_8);
    final byte[] largeMetadata = new byte[101];

    Assertions.assertDoesNotThrow(
        () ->
            new TokenUpdateNftsRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                serials,
                metadata,
                metadataKey));
    Assertions.assertDoesNotThrow(
        () -> TokenUpdateNftsRequest.of(tokenId, serials, metadata, metadataKey));
    Assertions.assertDoesNotThrow(
        () -> TokenUpdateNftsRequest.of(tokenId, 1L, metadata, metadataKey));
    Assertions.assertDoesNotThrow(
        () -> TokenUpdateNftsRequest.of("0.0.12345", serials, metadata, metadataKey));

    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> TokenUpdateNftsRequest.of(tokenId, List.of(), metadata, metadataKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            TokenUpdateNftsRequest.of(
                tokenId,
                List.of(1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L, 9L, 10L, 11L),
                metadata,
                metadataKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> TokenUpdateNftsRequest.of(tokenId, List.of(-1L), metadata, metadataKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> TokenUpdateNftsRequest.of(tokenId, serials, largeMetadata, metadataKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenUpdateNftsRequest(
                null, transactionValidDuration, tokenId, serials, metadata, metadataKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenUpdateNftsRequest(
                maxTransactionFee, null, tokenId, serials, metadata, metadataKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenUpdateNftsRequest(
                maxTransactionFee, transactionValidDuration, null, serials, metadata, metadataKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenUpdateNftsRequest(
                maxTransactionFee, transactionValidDuration, tokenId, null, metadata, metadataKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenUpdateNftsRequest(
                maxTransactionFee, transactionValidDuration, tokenId, serials, null, metadataKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenUpdateNftsRequest(
                maxTransactionFee, transactionValidDuration, tokenId, serials, metadata, null));
  }

  @Test
  void testTokenUpdateNftsResultCreation() {
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    Assertions.assertDoesNotThrow(() -> new TokenUpdateNftsResult(transactionId, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenUpdateNftsResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TokenUpdateNftsResult(transactionId, null));
  }

  @Test
  void testTokenBurnRequestCreation() {
    // Given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final TokenId tokenId = TokenId.fromString("0.0.12345");
    final PrivateKey supplyKey = PrivateKey.generateECDSA();
    final Long amount = 100L;
    final Set<Long> serials = Set.of(1L, 2L, 3L);

    // Then
    Assertions.assertDoesNotThrow(
        () ->
            new TokenBurnRequest(
                maxTransactionFee, transactionValidDuration, tokenId, supplyKey, amount, serials));
    Assertions.assertDoesNotThrow(() -> TokenBurnRequest.of(tokenId, 1L, supplyKey));
    Assertions.assertDoesNotThrow(() -> TokenBurnRequest.of(tokenId, serials, supplyKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenBurnRequest(
                null, transactionValidDuration, tokenId, supplyKey, amount, serials));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TokenBurnRequest(maxTransactionFee, null, tokenId, supplyKey, amount, serials));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenBurnRequest(
                maxTransactionFee, transactionValidDuration, null, supplyKey, amount, serials));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenBurnRequest(
                maxTransactionFee, transactionValidDuration, tokenId, null, amount, serials));
    Assertions.assertDoesNotThrow(
        () ->
            new TokenBurnRequest(
                maxTransactionFee, transactionValidDuration, tokenId, supplyKey, null, serials));
    Assertions.assertDoesNotThrow(
        () ->
            new TokenBurnRequest(
                maxTransactionFee, transactionValidDuration, tokenId, supplyKey, amount, null));
  }

  @Test
  void testTokenWipeRequestCreation() {
    // Given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final TokenId tokenId = TokenId.fromString("0.0.12345");
    final AccountId accountId = AccountId.fromString("0.0.54321");
    final PrivateKey wipeKey = PrivateKey.generateECDSA();
    final Set<Long> serials = Set.of(1L, 2L, 3L);

    // Then
    Assertions.assertDoesNotThrow(
        () ->
            new TokenWipeRequest(
                maxTransactionFee, transactionValidDuration, tokenId, accountId, serials, wipeKey));
    Assertions.assertDoesNotThrow(() -> TokenWipeRequest.of(tokenId, accountId, 1L, wipeKey));
    Assertions.assertDoesNotThrow(() -> TokenWipeRequest.of(tokenId, accountId, serials, wipeKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenWipeRequest(
                null, transactionValidDuration, tokenId, accountId, serials, wipeKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TokenWipeRequest(maxTransactionFee, null, tokenId, accountId, serials, wipeKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenWipeRequest(
                maxTransactionFee, transactionValidDuration, null, accountId, serials, wipeKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenWipeRequest(
                maxTransactionFee, transactionValidDuration, tokenId, null, serials, wipeKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenWipeRequest(
                maxTransactionFee, transactionValidDuration, tokenId, accountId, null, wipeKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenWipeRequest(
                maxTransactionFee, transactionValidDuration, tokenId, accountId, serials, null));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new TokenWipeRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                accountId,
                Set.of(),
                wipeKey));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new TokenWipeRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenId,
                accountId,
                Set.of(-1L),
                wipeKey));
  }

  @Test
  void testTokenAssociateRequestCreation() {
    // Given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final TokenId tokenId = TokenId.fromString("0.0.1");
    final List<TokenId> tokenIds = List.of(TokenId.fromString("0.0.12345"));
    final AccountId accountId = AccountId.fromString("0.0.54321");
    final PrivateKey accountPrivateKey = PrivateKey.generateECDSA();

    // Then
    Assertions.assertDoesNotThrow(
        () ->
            new TokenAssociateRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenIds,
                accountId,
                accountPrivateKey));
    Assertions.assertDoesNotThrow(
        () -> TokenAssociateRequest.of(tokenId, accountId, accountPrivateKey));
    Assertions.assertDoesNotThrow(
        () -> TokenAssociateRequest.of(tokenIds, accountId, accountPrivateKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenAssociateRequest(
                maxTransactionFee, transactionValidDuration, null, accountId, accountPrivateKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenAssociateRequest(
                maxTransactionFee, transactionValidDuration, tokenIds, null, accountPrivateKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenAssociateRequest(
                maxTransactionFee, transactionValidDuration, tokenIds, accountId, null));
  }

  @Test
  void testTokenDissociateRequestCreation() {
    // Given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final TokenId tokenId = TokenId.fromString("0.0.1");
    final List<TokenId> tokenIds = List.of(TokenId.fromString("0.0.12345"));
    final AccountId accountId = AccountId.fromString("0.0.54321");
    final PrivateKey accountPrivateKey = PrivateKey.generateECDSA();

    // Then
    Assertions.assertDoesNotThrow(
        () ->
            new TokenDissociateRequest(
                maxTransactionFee,
                transactionValidDuration,
                tokenIds,
                accountId,
                accountPrivateKey));
    Assertions.assertDoesNotThrow(
        () -> TokenDissociateRequest.of(tokenIds, accountId, accountPrivateKey));
    Assertions.assertDoesNotThrow(
        () -> TokenDissociateRequest.of(tokenId, accountId, accountPrivateKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenDissociateRequest(
                maxTransactionFee, transactionValidDuration, null, accountId, accountPrivateKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenDissociateRequest(
                maxTransactionFee, transactionValidDuration, tokenIds, null, accountPrivateKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenDissociateRequest(
                maxTransactionFee, transactionValidDuration, tokenIds, accountId, null));
  }

  @Test
  void testTokenFreezeRequestCreation() {
    // Given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final TokenId tokenId = TokenId.fromString("0.0.12345");
    final AccountId accountId = AccountId.fromString("0.0.54321");
    final PrivateKey freezeKey = PrivateKey.generateECDSA();

    // Then
    Assertions.assertDoesNotThrow(
        () ->
            new TokenFreezeRequest(
                maxTransactionFee, transactionValidDuration, tokenId, accountId, freezeKey));
    Assertions.assertDoesNotThrow(() -> TokenFreezeRequest.of(tokenId, accountId, freezeKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenFreezeRequest(null, transactionValidDuration, tokenId, accountId, freezeKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TokenFreezeRequest(maxTransactionFee, null, tokenId, accountId, freezeKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenFreezeRequest(
                maxTransactionFee, transactionValidDuration, null, accountId, freezeKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenFreezeRequest(
                maxTransactionFee, transactionValidDuration, tokenId, null, freezeKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenFreezeRequest(
                maxTransactionFee, transactionValidDuration, tokenId, accountId, null));
  }

  @Test
  void testTokenUnfreezeRequestCreation() {
    // Given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final TokenId tokenId = TokenId.fromString("0.0.12345");
    final AccountId accountId = AccountId.fromString("0.0.54321");
    final PrivateKey freezeKey = PrivateKey.generateECDSA();

    // Then
    Assertions.assertDoesNotThrow(
        () ->
            new TokenUnfreezeRequest(
                maxTransactionFee, transactionValidDuration, tokenId, accountId, freezeKey));
    Assertions.assertDoesNotThrow(() -> TokenUnfreezeRequest.of(tokenId, accountId, freezeKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenUnfreezeRequest(
                null, transactionValidDuration, tokenId, accountId, freezeKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TokenUnfreezeRequest(maxTransactionFee, null, tokenId, accountId, freezeKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenUnfreezeRequest(
                maxTransactionFee, transactionValidDuration, null, accountId, freezeKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenUnfreezeRequest(
                maxTransactionFee, transactionValidDuration, tokenId, null, freezeKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenUnfreezeRequest(
                maxTransactionFee, transactionValidDuration, tokenId, accountId, null));
  }

  @Test
  void testTokenGrantKycRequestCreation() {
    // Given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final TokenId tokenId = TokenId.fromString("0.0.12345");
    final AccountId accountId = AccountId.fromString("0.0.54321");
    final PrivateKey kycKey = PrivateKey.generateECDSA();

    // Then
    Assertions.assertDoesNotThrow(
        () ->
            new TokenGrantKycRequest(
                maxTransactionFee, transactionValidDuration, tokenId, accountId, kycKey));
    Assertions.assertDoesNotThrow(() -> TokenGrantKycRequest.of(tokenId, accountId, kycKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TokenGrantKycRequest(null, transactionValidDuration, tokenId, accountId, kycKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TokenGrantKycRequest(maxTransactionFee, null, tokenId, accountId, kycKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenGrantKycRequest(
                maxTransactionFee, transactionValidDuration, null, accountId, kycKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenGrantKycRequest(
                maxTransactionFee, transactionValidDuration, tokenId, null, kycKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenGrantKycRequest(
                maxTransactionFee, transactionValidDuration, tokenId, accountId, null));
  }

  @Test
  void testTokenRevokeKycRequestCreation() {
    // Given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final TokenId tokenId = TokenId.fromString("0.0.12345");
    final AccountId accountId = AccountId.fromString("0.0.54321");
    final PrivateKey kycKey = PrivateKey.generateECDSA();

    // Then
    Assertions.assertDoesNotThrow(
        () ->
            new TokenRevokeKycRequest(
                maxTransactionFee, transactionValidDuration, tokenId, accountId, kycKey));
    Assertions.assertDoesNotThrow(() -> TokenRevokeKycRequest.of(tokenId, accountId, kycKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenRevokeKycRequest(null, transactionValidDuration, tokenId, accountId, kycKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TokenRevokeKycRequest(maxTransactionFee, null, tokenId, accountId, kycKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenRevokeKycRequest(
                maxTransactionFee, transactionValidDuration, null, accountId, kycKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenRevokeKycRequest(
                maxTransactionFee, transactionValidDuration, tokenId, null, kycKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TokenRevokeKycRequest(
                maxTransactionFee, transactionValidDuration, tokenId, accountId, null));
  }

  @Test
  void testFileUpdateRequestCreation() {
    // Given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final FileId fileId = FileId.fromString("0.0.12345");
    final byte[] contents = new byte[100];
    final Instant expirationTime = Instant.now().plus(Duration.ofDays(1));
    final String fileMemo = "Test file memo";

    // Then
    Assertions.assertDoesNotThrow(
        () ->
            new FileUpdateRequest(
                maxTransactionFee,
                transactionValidDuration,
                fileId,
                contents,
                expirationTime,
                fileMemo));
    Assertions.assertDoesNotThrow(
        () ->
            new FileUpdateRequest(
                maxTransactionFee,
                transactionValidDuration,
                fileId,
                null,
                expirationTime,
                fileMemo));
    Assertions.assertDoesNotThrow(
        () ->
            new FileUpdateRequest(
                maxTransactionFee, transactionValidDuration, fileId, contents, null, fileMemo));
    Assertions.assertDoesNotThrow(() -> FileUpdateRequest.of(fileId, contents));
    Assertions.assertDoesNotThrow(() -> FileUpdateRequest.of(fileId, expirationTime));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () ->
            new FileUpdateRequest(
                maxTransactionFee,
                transactionValidDuration,
                fileId,
                new byte[FileUpdateRequest.FILE_CREATE_MAX_BYTES + 1],
                expirationTime,
                fileMemo));
  }

  @Test
  void testFileInfoRequestCreation() {
    // Given
    final FileId validFileId = FileId.fromString("0.0.12345");
    final Hbar queryPayment = Hbar.fromTinybars(1000);
    final Hbar maxQueryPayment = Hbar.fromTinybars(2000);

    // Then
    Assertions.assertDoesNotThrow(() -> new FileInfoRequest(validFileId, null, null));
    Assertions.assertDoesNotThrow(() -> new FileInfoRequest(validFileId, queryPayment, null));
    Assertions.assertDoesNotThrow(() -> new FileInfoRequest(validFileId, null, maxQueryPayment));
    Assertions.assertDoesNotThrow(
        () -> new FileInfoRequest(validFileId, queryPayment, maxQueryPayment));
    Assertions.assertDoesNotThrow(() -> FileInfoRequest.of(validFileId));
    Assertions.assertDoesNotThrow(() -> FileInfoRequest.of("0.0.12345"));
    Assertions.assertThrows(
        NullPointerException.class, () -> new FileInfoRequest(null, queryPayment, maxQueryPayment));
    Assertions.assertThrows(NullPointerException.class, () -> FileInfoRequest.of((String) null));
    Assertions.assertThrows(NullPointerException.class, () -> FileInfoRequest.of((FileId) null));
  }

  @Test
  void testFileContentsRequestCreation() {
    // Given
    final FileId validFileId = FileId.fromString("0.0.12345");
    final Hbar queryPayment = Hbar.fromTinybars(1000);
    final Hbar maxQueryPayment = Hbar.fromTinybars(2000);

    // Then
    Assertions.assertDoesNotThrow(() -> new FileContentsRequest(validFileId, null, null));
    Assertions.assertDoesNotThrow(() -> new FileContentsRequest(validFileId, queryPayment, null));
    Assertions.assertDoesNotThrow(
        () -> new FileContentsRequest(validFileId, null, maxQueryPayment));
    Assertions.assertDoesNotThrow(
        () -> new FileContentsRequest(validFileId, queryPayment, maxQueryPayment));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new FileContentsRequest(null, queryPayment, maxQueryPayment));
    Assertions.assertDoesNotThrow(() -> FileContentsRequest.of(validFileId));
    Assertions.assertDoesNotThrow(() -> FileContentsRequest.of("0.0.12345"));
    Assertions.assertThrows(
        NullPointerException.class, () -> FileContentsRequest.of((String) null));
    Assertions.assertThrows(
        NullPointerException.class, () -> FileContentsRequest.of((FileId) null));
  }

  @Test
  void testFileCreateRequestCreation() {
    // given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(10);
    final byte[] contents = new byte[] {};
    final Instant expirationTime = Instant.MAX;
    final byte[] largeContents =
        IntStream.range(0, 2050).mapToObj(i -> "a").reduce("", (a, b) -> a + b).getBytes();
    final String fileMemo = "fileMemo";

    // then
    Assertions.assertDoesNotThrow(() -> FileCreateRequest.of(contents));
    Assertions.assertDoesNotThrow(() -> FileCreateRequest.of(contents, null));
    Assertions.assertDoesNotThrow(
        () ->
            new FileCreateRequest(
                maxTransactionFee, transactionValidDuration, contents, expirationTime, fileMemo));
    Assertions.assertDoesNotThrow(
        () ->
            new FileCreateRequest(
                maxTransactionFee, transactionValidDuration, contents, null, fileMemo));
    Assertions.assertDoesNotThrow(
        () ->
            new FileCreateRequest(
                maxTransactionFee, transactionValidDuration, contents, expirationTime, null));
    Assertions.assertDoesNotThrow(
        () ->
            new FileCreateRequest(
                maxTransactionFee, transactionValidDuration, contents, null, null));
    Assertions.assertThrows(
        IllegalArgumentException.class, () -> FileCreateRequest.of(largeContents));
    Assertions.assertThrows(NullPointerException.class, () -> FileCreateRequest.of(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> FileCreateRequest.of(null, expirationTime));
    Assertions.assertThrows(NullPointerException.class, () -> FileCreateRequest.of(null, null));
    Assertions.assertThrows(
        NullPointerException.class, () -> new FileCreateRequest(null, null, null, null, null));
  }

  @Test
  void testFileDeleteRequestCreation() {
    // given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(10);
    final String fileIdString = "0.0.12345";
    final FileId fileId = FileId.fromString(fileIdString);

    // then
    Assertions.assertDoesNotThrow(() -> FileDeleteRequest.of(fileId));
    Assertions.assertDoesNotThrow(() -> FileDeleteRequest.of(fileIdString));
    Assertions.assertDoesNotThrow(
        () -> new FileDeleteRequest(maxTransactionFee, transactionValidDuration, fileId));
    Assertions.assertThrows(NullPointerException.class, () -> FileDeleteRequest.of((FileId) null));
    Assertions.assertThrows(NullPointerException.class, () -> FileDeleteRequest.of((String) null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new FileDeleteRequest(maxTransactionFee, transactionValidDuration, null));
    Assertions.assertThrows(
        NullPointerException.class, () -> new FileDeleteRequest(maxTransactionFee, null, null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new FileDeleteRequest(null, transactionValidDuration, null));
    Assertions.assertThrows(
        NullPointerException.class, () -> new FileDeleteRequest(null, null, null));
  }

  @Test
  void testTopicSubmitMessageResultCreation() {
    // given
    final TransactionId validTransactionId =
        TransactionId.fromString("0.0.123451@1697590800.123456789");
    final Status validStatus = Status.SUCCESS;

    // then
    Assertions.assertDoesNotThrow(
        () -> new TopicSubmitMessageResult(validTransactionId, validStatus));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TopicSubmitMessageResult(null, validStatus));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TopicSubmitMessageResult(validTransactionId, null));
  }

  @Test
  void testTopicDeleteResultCreation() {
    // given
    final TransactionId validTransactionId =
        TransactionId.fromString("0.0.123451@1697590800.123456789");
    final Status validStatus = Status.SUCCESS;

    // then
    Assertions.assertDoesNotThrow(() -> new TopicDeleteResult(validTransactionId, validStatus));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TopicDeleteResult(null, validStatus));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TopicDeleteResult(validTransactionId, null));
  }

  @Test
  void testTopicSubmitMessageRequestCreation() {
    // Given
    final TopicId validTopicId = TopicId.fromString("0.0.12345");
    final String validMessage = "This is a valid message";
    final byte[] validMessageBytes = validMessage.getBytes(StandardCharsets.UTF_8);
    final byte[] largeMessage = new byte[1025];
    final Hbar validMaxTransactionFee = Hbar.fromTinybars(100_000);
    final Duration validTransactionValidDuration = Duration.ofMinutes(2);

    // Then
    Assertions.assertDoesNotThrow(() -> TopicSubmitMessageRequest.of(validTopicId, validMessage));
    Assertions.assertDoesNotThrow(
        () -> TopicSubmitMessageRequest.of(validTopicId, validMessageBytes));
    Assertions.assertDoesNotThrow(
        () ->
            new TopicSubmitMessageRequest(
                validMaxTransactionFee,
                validTransactionValidDuration,
                validTopicId,
                null,
                validMessage.getBytes(StandardCharsets.UTF_8)));
    Assertions.assertThrows(
        NullPointerException.class, () -> TopicSubmitMessageRequest.of(null, validMessage));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> TopicSubmitMessageRequest.of(validTopicId, (String) null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> TopicSubmitMessageRequest.of(validTopicId, (byte[]) null));
    Assertions.assertThrows(
        IllegalArgumentException.class,
        () -> TopicSubmitMessageRequest.of(validTopicId, largeMessage));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TopicSubmitMessageRequest(
                validMaxTransactionFee,
                validTransactionValidDuration,
                null,
                null,
                validMessage.getBytes(StandardCharsets.UTF_8)));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new TopicSubmitMessageRequest(
                validMaxTransactionFee, validTransactionValidDuration, validTopicId, null, null));
  }

  @Test
  void testTopicDeleteRequestCreation() {
    // given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(10);
    final String topicIdString = "0.0.12345";
    final TopicId topicId = TopicId.fromString(topicIdString);
    final PrivateKey adminKey = PrivateKey.generateECDSA();

    // then
    Assertions.assertDoesNotThrow(() -> TopicDeleteRequest.of(adminKey, topicId));
    Assertions.assertDoesNotThrow(
        () ->
            new TopicDeleteRequest(maxTransactionFee, transactionValidDuration, adminKey, topicId));

    Assertions.assertThrows(NullPointerException.class, () -> TopicDeleteRequest.of(null, null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TopicDeleteRequest(maxTransactionFee, null, null, null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TopicDeleteRequest(null, transactionValidDuration, null, null));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TopicDeleteRequest(null, null, adminKey, null));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TopicDeleteRequest(null, null, null, topicId));
  }

  @Test
  void testTopicCreateResultCreation() {
    // given
    final TransactionId validTransactionId =
        TransactionId.fromString("0.0.123451@1697590800.123456789");
    final Status validStatus = Status.SUCCESS;
    final TopicId validTopicId = TopicId.fromString("0.0.12345");

    // then
    Assertions.assertDoesNotThrow(
        () -> new TopicCreateResult(validTransactionId, validStatus, validTopicId));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TopicCreateResult(null, validStatus, validTopicId));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TopicCreateResult(validTransactionId, null, validTopicId));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new TopicCreateResult(validTransactionId, validStatus, null));
  }

  @Test
  void testTopicUpdateResultCreation() {
    // given
    final TransactionId validTransactionId =
        TransactionId.fromString("0.0.123451@1697590800.123456789");
    final Status validStatus = Status.SUCCESS;

    // then
    Assertions.assertDoesNotThrow(() -> new TopicUpdateResult(validTransactionId, validStatus));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TopicUpdateResult(null, validStatus));
    Assertions.assertThrows(
        NullPointerException.class, () -> new TopicUpdateResult(validTransactionId, null));
  }

  @Test
  void testHookStoreRequestCreation() {
    // given
    final Hbar maxTransactionFee = Hbar.fromTinybars(1000);
    final Duration transactionValidDuration = Duration.ofSeconds(120);
    final HookId hookId = new HookId(new HookEntityId(new ContractId(0, 0, 1234)), 1L);
    final List<EvmHookStorageUpdate> storageUpdates =
        List.of(new EvmHookStorageUpdate.EvmHookStorageSlot(new byte[] {1}, new byte[] {2}));
    final PrivateKey signerKey = PrivateKey.generateED25519();
    final List<PrivateKey> signerKeys = List.of(signerKey);

    // then
    Assertions.assertDoesNotThrow(
        () ->
            new HookStoreRequest(
                maxTransactionFee, transactionValidDuration, hookId, storageUpdates, signerKeys));
    Assertions.assertDoesNotThrow(() -> HookStoreRequest.of(hookId, storageUpdates, signerKey));
    Assertions.assertDoesNotThrow(() -> HookStoreRequest.of(hookId, storageUpdates, signerKeys));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new HookStoreRequest(
                null, transactionValidDuration, hookId, storageUpdates, signerKeys));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> new HookStoreRequest(maxTransactionFee, null, hookId, storageUpdates, signerKeys));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new HookStoreRequest(
                maxTransactionFee, transactionValidDuration, null, storageUpdates, signerKeys));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new HookStoreRequest(
                maxTransactionFee, transactionValidDuration, hookId, null, signerKeys));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new HookStoreRequest(
                maxTransactionFee, transactionValidDuration, hookId, storageUpdates, null));
    Assertions.assertThrows(
        NullPointerException.class,
        () ->
            new HookStoreRequest(
                maxTransactionFee,
                transactionValidDuration,
                hookId,
                storageUpdates,
                List.of(signerKey, null)));
    Assertions.assertThrows(
        NullPointerException.class, () -> HookStoreRequest.of(null, storageUpdates, signerKey));
    Assertions.assertThrows(
        NullPointerException.class, () -> HookStoreRequest.of(hookId, null, signerKey));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> HookStoreRequest.of(hookId, storageUpdates, (PrivateKey) null));
    Assertions.assertThrows(
        NullPointerException.class,
        () -> HookStoreRequest.of(hookId, storageUpdates, (List<PrivateKey>) null));
  }

  @Test
  void testHookStoreResultCreation() {
    // given
    final TransactionId transactionId = TransactionId.generate(new AccountId(0, 0, 12345));
    final Status status = Status.SUCCESS;

    // then
    Assertions.assertDoesNotThrow(() -> new HookStoreResult(transactionId, status));
    Assertions.assertThrows(NullPointerException.class, () -> new HookStoreResult(null, status));
    Assertions.assertThrows(
        NullPointerException.class, () -> new HookStoreResult(transactionId, null));
  }
}
