package org.hiero.base.implementation;

import com.google.protobuf.ByteString;
import com.hedera.hashgraph.sdk.AccountAllowanceApproveTransaction;
import com.hedera.hashgraph.sdk.AccountAllowanceDeleteTransaction;
import com.hedera.hashgraph.sdk.AccountBalance;
import com.hedera.hashgraph.sdk.AccountBalanceQuery;
import com.hedera.hashgraph.sdk.AccountCreateTransaction;
import com.hedera.hashgraph.sdk.AccountDeleteTransaction;
import com.hedera.hashgraph.sdk.AccountId;
import com.hedera.hashgraph.sdk.AccountInfo;
import com.hedera.hashgraph.sdk.AccountInfoQuery;
import com.hedera.hashgraph.sdk.AccountUpdateTransaction;
import com.hedera.hashgraph.sdk.ContractCreateTransaction;
import com.hedera.hashgraph.sdk.ContractDeleteTransaction;
import com.hedera.hashgraph.sdk.ContractExecuteTransaction;
import com.hedera.hashgraph.sdk.ContractFunctionParameters;
import com.hedera.hashgraph.sdk.FileAppendTransaction;
import com.hedera.hashgraph.sdk.FileContentsQuery;
import com.hedera.hashgraph.sdk.FileCreateTransaction;
import com.hedera.hashgraph.sdk.FileDeleteTransaction;
import com.hedera.hashgraph.sdk.FileInfo;
import com.hedera.hashgraph.sdk.FileInfoQuery;
import com.hedera.hashgraph.sdk.FileUpdateTransaction;
import com.hedera.hashgraph.sdk.HookStoreTransaction;
import com.hedera.hashgraph.sdk.NftId;
import com.hedera.hashgraph.sdk.PendingAirdropId;
import com.hedera.hashgraph.sdk.PrivateKey;
import com.hedera.hashgraph.sdk.PublicKey;
import com.hedera.hashgraph.sdk.Query;
import com.hedera.hashgraph.sdk.SubscriptionHandle;
import com.hedera.hashgraph.sdk.TokenAirdropTransaction;
import com.hedera.hashgraph.sdk.TokenAssociateTransaction;
import com.hedera.hashgraph.sdk.TokenBurnTransaction;
import com.hedera.hashgraph.sdk.TokenCancelAirdropTransaction;
import com.hedera.hashgraph.sdk.TokenCreateTransaction;
import com.hedera.hashgraph.sdk.TokenDeleteTransaction;
import com.hedera.hashgraph.sdk.TokenDissociateTransaction;
import com.hedera.hashgraph.sdk.TokenFreezeTransaction;
import com.hedera.hashgraph.sdk.TokenGrantKycTransaction;
import com.hedera.hashgraph.sdk.TokenMintTransaction;
import com.hedera.hashgraph.sdk.TokenRejectTransaction;
import com.hedera.hashgraph.sdk.TokenRevokeKycTransaction;
import com.hedera.hashgraph.sdk.TokenUnfreezeTransaction;
import com.hedera.hashgraph.sdk.TokenUpdateNftsTransaction;
import com.hedera.hashgraph.sdk.TokenUpdateTransaction;
import com.hedera.hashgraph.sdk.TokenWipeTransaction;
import com.hedera.hashgraph.sdk.TopicCreateTransaction;
import com.hedera.hashgraph.sdk.TopicDeleteTransaction;
import com.hedera.hashgraph.sdk.TopicMessageQuery;
import com.hedera.hashgraph.sdk.TopicMessageSubmitTransaction;
import com.hedera.hashgraph.sdk.TopicUpdateTransaction;
import com.hedera.hashgraph.sdk.Transaction;
import com.hedera.hashgraph.sdk.TransactionReceipt;
import com.hedera.hashgraph.sdk.TransactionRecord;
import com.hedera.hashgraph.sdk.TransactionResponse;
import com.hedera.hashgraph.sdk.TransferTransaction;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import org.hiero.base.HieroContext;
import org.hiero.base.HieroException;
import org.hiero.base.data.Account;
import org.hiero.base.data.ContractParam;
import org.hiero.base.interceptors.ReceiveRecordInterceptor;
import org.hiero.base.interceptors.ReceiveRecordInterceptor.ReceiveRecordHandler;
import org.hiero.base.protocol.ProtocolLayerClient;
import org.hiero.base.protocol.TransactionListener;
import org.hiero.base.protocol.data.AccountBalanceRequest;
import org.hiero.base.protocol.data.AccountBalanceResponse;
import org.hiero.base.protocol.data.AccountCreateRequest;
import org.hiero.base.protocol.data.AccountCreateResult;
import org.hiero.base.protocol.data.AccountDeleteRequest;
import org.hiero.base.protocol.data.AccountDeleteResult;
import org.hiero.base.protocol.data.AccountInfoRequest;
import org.hiero.base.protocol.data.AccountInfoResponse;
import org.hiero.base.protocol.data.AccountUpdateRequest;
import org.hiero.base.protocol.data.AccountUpdateResult;
import org.hiero.base.protocol.data.ContractCallRequest;
import org.hiero.base.protocol.data.ContractCallResult;
import org.hiero.base.protocol.data.ContractCreateRequest;
import org.hiero.base.protocol.data.ContractCreateResult;
import org.hiero.base.protocol.data.ContractDeleteRequest;
import org.hiero.base.protocol.data.ContractDeleteResult;
import org.hiero.base.protocol.data.FileAppendRequest;
import org.hiero.base.protocol.data.FileAppendResult;
import org.hiero.base.protocol.data.FileContentsRequest;
import org.hiero.base.protocol.data.FileContentsResponse;
import org.hiero.base.protocol.data.FileCreateRequest;
import org.hiero.base.protocol.data.FileCreateResult;
import org.hiero.base.protocol.data.FileDeleteRequest;
import org.hiero.base.protocol.data.FileDeleteResult;
import org.hiero.base.protocol.data.FileInfoRequest;
import org.hiero.base.protocol.data.FileInfoResponse;
import org.hiero.base.protocol.data.FileUpdateRequest;
import org.hiero.base.protocol.data.FileUpdateResult;
import org.hiero.base.protocol.data.HbarAllowanceApproveRequest;
import org.hiero.base.protocol.data.HbarAllowanceApproveResult;
import org.hiero.base.protocol.data.HbarTransferRequest;
import org.hiero.base.protocol.data.HbarTransferResult;
import org.hiero.base.protocol.data.HookStoreRequest;
import org.hiero.base.protocol.data.HookStoreResult;
import org.hiero.base.protocol.data.NftAllowanceDeleteRequest;
import org.hiero.base.protocol.data.NftAllowanceDeleteResult;
import org.hiero.base.protocol.data.TokenAirdropRequest;
import org.hiero.base.protocol.data.TokenAirdropResult;
import org.hiero.base.protocol.data.TokenAssociateRequest;
import org.hiero.base.protocol.data.TokenAssociateResult;
import org.hiero.base.protocol.data.TokenBurnRequest;
import org.hiero.base.protocol.data.TokenBurnResult;
import org.hiero.base.protocol.data.TokenCancelAirdropRequest;
import org.hiero.base.protocol.data.TokenCancelAirdropResult;
import org.hiero.base.protocol.data.TokenCreateRequest;
import org.hiero.base.protocol.data.TokenCreateResult;
import org.hiero.base.protocol.data.TokenDeleteRequest;
import org.hiero.base.protocol.data.TokenDeleteResult;
import org.hiero.base.protocol.data.TokenDissociateRequest;
import org.hiero.base.protocol.data.TokenDissociateResult;
import org.hiero.base.protocol.data.TokenFreezeRequest;
import org.hiero.base.protocol.data.TokenFreezeResult;
import org.hiero.base.protocol.data.TokenGrantKycRequest;
import org.hiero.base.protocol.data.TokenGrantKycResult;
import org.hiero.base.protocol.data.TokenMintRequest;
import org.hiero.base.protocol.data.TokenMintResult;
import org.hiero.base.protocol.data.TokenRejectRequest;
import org.hiero.base.protocol.data.TokenRejectResult;
import org.hiero.base.protocol.data.TokenRevokeKycRequest;
import org.hiero.base.protocol.data.TokenRevokeKycResult;
import org.hiero.base.protocol.data.TokenTransferRequest;
import org.hiero.base.protocol.data.TokenTransferResult;
import org.hiero.base.protocol.data.TokenUnfreezeRequest;
import org.hiero.base.protocol.data.TokenUnfreezeResult;
import org.hiero.base.protocol.data.TokenUpdateNftsRequest;
import org.hiero.base.protocol.data.TokenUpdateNftsResult;
import org.hiero.base.protocol.data.TokenUpdateRequest;
import org.hiero.base.protocol.data.TokenUpdateResult;
import org.hiero.base.protocol.data.TokenWipeRequest;
import org.hiero.base.protocol.data.TokenWipeResult;
import org.hiero.base.protocol.data.TopicCreateRequest;
import org.hiero.base.protocol.data.TopicCreateResult;
import org.hiero.base.protocol.data.TopicDeleteRequest;
import org.hiero.base.protocol.data.TopicDeleteResult;
import org.hiero.base.protocol.data.TopicMessageRequest;
import org.hiero.base.protocol.data.TopicMessageResult;
import org.hiero.base.protocol.data.TopicSubmitMessageRequest;
import org.hiero.base.protocol.data.TopicSubmitMessageResult;
import org.hiero.base.protocol.data.TopicUpdateRequest;
import org.hiero.base.protocol.data.TopicUpdateResult;
import org.hiero.base.protocol.data.TransactionType;
import org.jspecify.annotations.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProtocolLayerClientImpl implements ProtocolLayerClient {

  private static final Logger log = LoggerFactory.getLogger(ProtocolLayerClientImpl.class);

  public static final int DEFAULT_GAS = 5_000_000;
  public static final int MAX_GAS_LIMIT = 15_000_000;

  private final List<TransactionListener> listeners;

  private final HieroContext hieroContext;

  private final AtomicReference<ReceiveRecordInterceptor> recordInterceptor =
      new AtomicReference<>(ReceiveRecordInterceptor.DEFAULT_INTERCEPTOR);

  public ProtocolLayerClientImpl(@NonNull final HieroContext hieroContext) {
    this.hieroContext = Objects.requireNonNull(hieroContext, "hieroContext must not be null");
    listeners = new CopyOnWriteArrayList<>();
  }

  public void setRecordInterceptor(@NonNull final ReceiveRecordInterceptor recordInterceptor) {
    Objects.requireNonNull(recordInterceptor, "recordInterceptor must not be null");
    this.recordInterceptor.set(recordInterceptor);
  }

  @Override
  public AccountBalanceResponse executeAccountBalanceQuery(
      @NonNull final AccountBalanceRequest request) throws HieroException {
    final AccountBalanceQuery query =
        new AccountBalanceQuery()
            .setAccountId(request.accountId())
            .setQueryPayment(request.queryPayment())
            .setMaxQueryPayment(request.maxQueryPayment());
    final AccountBalance balance = executeQueryAndWait(query);
    return new AccountBalanceResponse(balance.hbars);
  }

  @Override
  public AccountInfoResponse executeAccountInfoQuery(@NonNull final AccountInfoRequest request)
      throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    final AccountInfoQuery query =
        new AccountInfoQuery()
            .setAccountId(request.accountId())
            .setQueryPayment(request.queryPayment())
            .setMaxQueryPayment(request.maxQueryPayment());
    final AccountInfo accountInfo = executeQueryAndWait(query);
    return new AccountInfoResponse(
        accountInfo.accountId,
        accountInfo.contractAccountId == null ? "" : accountInfo.contractAccountId,
        accountInfo.isDeleted,
        accountInfo.key,
        accountInfo.balance,
        accountInfo.isReceiverSignatureRequired,
        accountInfo.expirationTime,
        accountInfo.autoRenewPeriod,
        accountInfo.accountMemo == null ? "" : accountInfo.accountMemo,
        accountInfo.ownedNfts,
        accountInfo.maxAutomaticTokenAssociations,
        accountInfo.aliasKey,
        accountInfo.ledgerId,
        accountInfo.ethereumNonce,
        accountInfo.stakingInfo);
  }

  @Override
  public FileContentsResponse executeFileContentsQuery(@NonNull final FileContentsRequest request)
      throws HieroException {
    final FileContentsQuery query =
        new FileContentsQuery()
            .setFileId(request.fileId())
            .setQueryPayment(request.queryPayment())
            .setMaxQueryPayment(request.maxQueryPayment());
    final ByteString byteString = executeQueryAndWait(query);
    final byte[] bytes = byteString.toByteArray();
    return new FileContentsResponse(request.fileId(), bytes);
  }

  @Override
  public FileInfoResponse executeFileInfoQuery(@NonNull final FileInfoRequest request)
      throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    final FileInfoQuery query =
        new FileInfoQuery()
            .setFileId(request.fileId())
            .setQueryPayment(request.queryPayment())
            .setMaxQueryPayment(request.maxQueryPayment());
    final FileInfo fileInfo = executeQueryAndWait(query);
    if (fileInfo.size > Integer.MAX_VALUE) {
      throw new HieroException("File size is too large to be represented as an integer");
    }
    return new FileInfoResponse(
        request.fileId(), (int) fileInfo.size, fileInfo.isDeleted, fileInfo.expirationTime);
  }

  @Override
  public FileCreateResult executeFileCreateTransaction(@NonNull final FileCreateRequest request)
      throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    Objects.requireNonNull(request.contents(), "content must not be null");
    if (request.contents().length > FileCreateRequest.FILE_CREATE_MAX_SIZE) {
      throw new HieroException(
          "File contents of 1 transaction must be less than "
              + FileCreateRequest.FILE_CREATE_MAX_SIZE
              + " bytes. Use FileAppend for larger files.");
    }
    final FileCreateTransaction transaction =
        new FileCreateTransaction()
            .setMaxTransactionFee(request.maxTransactionFee())
            .setTransactionValidDuration(request.transactionValidDuration())
            .setContents(request.contents())
            .setTransactionMemo(request.fileMemo())
            .setKeys(Objects.requireNonNull(hieroContext.getOperatorAccount().publicKey()));
    if (request.expirationTime() != null) {
      transaction.setExpirationTime(request.expirationTime());
    }

    final TransactionReceipt receipt =
        executeTransactionAndWaitOnReceipt(transaction, TransactionType.FILE_CREATE);
    return new FileCreateResult(receipt.transactionId, receipt.status, receipt.fileId);
  }

  @Override
  public FileUpdateResult executeFileUpdateRequestTransaction(
      @NonNull final FileUpdateRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    if (request.contents() != null
        && request.contents().length > FileCreateRequest.FILE_CREATE_MAX_SIZE) {
      throw new HieroException(
          "File contents of 1 transaction must be less than "
              + FileCreateRequest.FILE_CREATE_MAX_SIZE
              + " bytes. Use FileAppend for larger files.");
    }
    final FileUpdateTransaction transaction =
        new FileUpdateTransaction()
            .setMaxTransactionFee(request.maxTransactionFee())
            .setTransactionValidDuration(request.transactionValidDuration())
            .setFileId(request.fileId())
            .setTransactionMemo(request.fileMemo());
    if (request.contents() != null) {
      transaction.setContents(request.contents());
    }
    if (request.expirationTime() != null) {
      transaction.setExpirationTime(request.expirationTime());
    }
    final TransactionReceipt receipt =
        executeTransactionAndWaitOnReceipt(transaction, TransactionType.FILE_UPDATE);
    return new FileUpdateResult(receipt.transactionId, receipt.status);
  }

  @Override
  public FileAppendResult executeFileAppendRequestTransaction(
      @NonNull final FileAppendRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    Objects.requireNonNull(request.contents(), "content must not be null");
    if (request.contents().length > FileCreateRequest.FILE_CREATE_MAX_SIZE) {
      throw new HieroException(
          "File contents of 1 transaction must be less than "
              + FileCreateRequest.FILE_CREATE_MAX_SIZE
              + " bytes. Use multiple FileAppend for larger files.");
    }
    final FileAppendTransaction transaction =
        new FileAppendTransaction()
            .setMaxTransactionFee(request.maxTransactionFee())
            .setTransactionValidDuration(request.transactionValidDuration())
            .setFileId(request.fileId())
            .setContents(request.contents())
            .setTransactionMemo(request.fileMemo());

    final TransactionReceipt receipt =
        executeTransactionAndWaitOnReceipt(transaction, TransactionType.FILE_APPEND);
    return new FileAppendResult(receipt.transactionId, receipt.status);
  }

  @Override
  public FileDeleteResult executeFileDeleteTransaction(@NonNull final FileDeleteRequest request)
      throws HieroException {
    final FileDeleteTransaction transaction =
        new FileDeleteTransaction()
            .setMaxTransactionFee(request.maxTransactionFee())
            .setTransactionValidDuration(request.transactionValidDuration())
            .setFileId(request.fileId());
    final TransactionReceipt receipt =
        executeTransactionAndWaitOnReceipt(transaction, TransactionType.FILE_DELETE);
    return new FileDeleteResult(receipt.transactionId, receipt.status);
  }

  @Override
  public ContractCreateResult executeContractCreateTransaction(
      @NonNull final ContractCreateRequest request) throws HieroException {
    final ContractFunctionParameters constructorParams =
        createParameters(request.constructorParams());
    final ContractCreateTransaction transaction =
        new ContractCreateTransaction()
            .setMaxTransactionFee(request.maxTransactionFee())
            .setTransactionValidDuration(request.transactionValidDuration())
            .setBytecodeFileId(request.fileId())
            .setGas(request.gas())
            .setConstructorParameters(constructorParams);

    if (request.adminKey() != null) {
      transaction.setAdminKey(request.adminKey());
    }

    sign(transaction, request.adminKey());
    final TransactionReceipt receipt =
        executeTransactionAndWaitOnReceipt(transaction, TransactionType.CONTRACT_CREATE);
    return new ContractCreateResult(receipt.transactionId, receipt.status, receipt.contractId);
  }

  @Override
  public ContractDeleteResult executeContractDeleteTransaction(
      @NonNull final ContractDeleteRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    final ContractDeleteTransaction transaction =
        new ContractDeleteTransaction()
            .setMaxTransactionFee(request.maxTransactionFee())
            .setTransactionValidDuration(request.transactionValidDuration())
            .setContractId(request.contractId());
    if (request.transferFeeToContractId() != null) {
      transaction.setTransferContractId(request.transferFeeToContractId());
    }
    if (request.transferFeeToAccountId() != null) {
      transaction.setTransferAccountId(request.transferFeeToAccountId());
    }

    sign(transaction, request.adminKey());
    final TransactionReceipt receipt =
        executeTransactionAndWaitOnReceipt(transaction, TransactionType.CONTRACT_DELETE);
    return new ContractDeleteResult(receipt.transactionId, receipt.status);
  }

  @Override
  @NonNull
  public ContractCallResult executeContractCallTransaction(
      @NonNull final ContractCallRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    final ContractFunctionParameters functionParams = createParameters(request.functionParams());
    final ContractExecuteTransaction transaction =
        new ContractExecuteTransaction()
            .setMaxTransactionFee(request.maxTransactionFee())
            .setTransactionValidDuration(request.transactionValidDuration())
            .setContractId(request.contractId())
            .setFunction(request.functionName(), functionParams)
            .setGas(request.gas());
    final TransactionRecord record =
        executeTransactionAndWaitOnRecord(transaction, TransactionType.CONTRACT_CALL);
    return new ContractCallResult(
        record.transactionId,
        record.receipt.status,
        record.transactionHash.toByteArray(),
        record.consensusTimestamp,
        record.transactionFee,
        record.contractFunctionResult);
  }

  @Override
  @NonNull
  public AccountCreateResult executeAccountCreateTransaction(
      @NonNull final AccountCreateRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    final PrivateKey privateKey = PrivateKey.generateED25519();
    final PublicKey publicKey = privateKey.getPublicKey();
    final AccountCreateTransaction transaction =
        new AccountCreateTransaction()
            .setMaxTransactionFee(request.maxTransactionFee())
            .setTransactionValidDuration(request.transactionValidDuration())
            .setKey(publicKey)
            .setInitialBalance(request.initialBalance());
    final TransactionRecord record =
        executeTransactionAndWaitOnRecord(transaction, TransactionType.ACCOUNT_CREATE);
    final Account newAccount = Account.of(record.receipt.accountId, publicKey, privateKey);
    return new AccountCreateResult(
        record.transactionId,
        record.receipt.status,
        record.transactionHash.toByteArray(),
        record.consensusTimestamp,
        record.transactionFee,
        newAccount);
  }

  @Override
  @NonNull
  public AccountDeleteResult executeAccountDeleteTransaction(
      @NonNull final AccountDeleteRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    final AccountDeleteTransaction transaction =
        new AccountDeleteTransaction()
            .setMaxTransactionFee(request.maxTransactionFee())
            .setTransactionValidDuration(request.transactionValidDuration())
            .setAccountId(request.toDelete().accountId());
    if (request.transferFundsToAccount() != null) {
      transaction.setTransferAccountId(request.transferFundsToAccount().accountId());
      sign(
          transaction,
          request.toDelete().privateKey(),
          request.transferFundsToAccount().privateKey());
    } else {
      transaction.setTransferAccountId(hieroContext.getOperatorAccount().accountId());
      sign(
          transaction,
          request.toDelete().privateKey(),
          hieroContext.getOperatorAccount().privateKey());
    }
    final TransactionRecord record =
        executeTransactionAndWaitOnRecord(transaction, TransactionType.ACCOUNT_DELETE);
    return new AccountDeleteResult(
        record.transactionId,
        record.receipt.status,
        record.transactionHash.toByteArray(),
        record.consensusTimestamp,
        record.transactionFee);
  }

  @Override
  @NonNull
  public AccountUpdateResult executeAccountUpdateTransaction(
      @NonNull final AccountUpdateRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    final AccountUpdateTransaction transaction =
        new AccountUpdateTransaction()
            .setMaxTransactionFee(request.maxTransactionFee())
            .setTransactionValidDuration(request.transactionValidDuration())
            .setAccountId(request.toUpdate().accountId());
    if (request.memo() != null) {
      transaction.setAccountMemo(request.memo());
    }
    if (request.updatedPrivateKey() != null) {
      transaction.setKey(request.updatedPrivateKey().getPublicKey());
      sign(transaction, request.toUpdate().privateKey(), request.updatedPrivateKey());
    } else {
      sign(transaction, request.toUpdate().privateKey());
    }
    final TransactionReceipt receipt =
        executeTransactionAndWaitOnReceipt(transaction, TransactionType.ACCOUNT_UPDATE);
    return new AccountUpdateResult(receipt.transactionId, receipt.status);
  }

  public TopicCreateResult executeTopicCreateTransaction(@NonNull final TopicCreateRequest request)
      throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    Objects.requireNonNull(request.maxTransactionFee(), "maxTransactionFee must not be null");
    Objects.requireNonNull(
        request.transactionValidDuration(), "transactionValidDuration must not be null");
    try {
      final TopicCreateTransaction transaction =
          new TopicCreateTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setAdminKey(request.adminKey());
      if (request.memo() != null) {
        transaction.setTopicMemo(request.memo());
      }
      if (request.submitKey() != null) {
        transaction.setSubmitKey(request.submitKey());
      }
      sign(transaction, request.adminKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOPIC_CREATE);
      return new TopicCreateResult(receipt.transactionId, receipt.status, receipt.topicId);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute create topic transaction", e);
    }
  }

  @Override
  public @NonNull TopicUpdateResult executeTopicUpdateTransaction(
      @NonNull TopicUpdateRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    Objects.requireNonNull(request.maxTransactionFee(), "maxTransactionFee must not be null");
    Objects.requireNonNull(
        request.transactionValidDuration(), "transactionValidDuration must not be null");
    try {
      final TopicUpdateTransaction transaction =
          new TopicUpdateTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setTopicId(request.topicId());
      if (request.memo() != null) {
        transaction.setTopicMemo(request.memo());
      }
      if (request.submitKey() != null) {
        transaction.setSubmitKey(request.submitKey());
      }
      if (request.updatedAdminKey() != null) {
        transaction.setAdminKey(request.updatedAdminKey());
      }
      if (request.updatedAdminKey() != null) {
        sign(transaction, request.adminKey(), request.updatedAdminKey());
      } else {
        sign(transaction, request.adminKey());
      }
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOPIC_UPDATE);
      return new TopicUpdateResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute update topic transaction", e);
    }
  }

  public TopicDeleteResult executeTopicDeleteTransaction(@NonNull final TopicDeleteRequest request)
      throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TopicDeleteTransaction transaction =
          new TopicDeleteTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setTopicId(request.topicId());
      sign(transaction, request.adminKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOPIC_DELETE);
      return new TopicDeleteResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute delete topic transaction", e);
    }
  }

  public TopicSubmitMessageResult executeTopicMessageSubmitTransaction(
      @NonNull final TopicSubmitMessageRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TopicMessageSubmitTransaction transaction =
          new TopicMessageSubmitTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setTopicId(request.topicId())
              .setMessage(request.message());
      if (request.submitKey() != null) {
        sign(transaction, request.submitKey());
      }
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOPIC_MESSAGE_SUBMIT);
      return new TopicSubmitMessageResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute submit message transaction", e);
    }
  }

  @Override
  public TopicMessageResult executeTopicMessageQuery(TopicMessageRequest request)
      throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TopicMessageQuery query = new TopicMessageQuery().setTopicId(request.topicId());
      if (request.startTime() != null) {
        query.setStartTime(request.startTime());
      }
      if (request.endTime() != null) {
        query.setEndTime(request.endTime());
      }
      if (request.limit() >= 0) {
        query.setLimit(request.limit());
      }
      final SubscriptionHandle subscribe =
          query.subscribe(hieroContext.getClient(), request.subscription());
      return new TopicMessageResult();
    } catch (final Exception e) {
      throw new HieroException("Failed to execute query message transaction", e);
    }
  }

  public TokenCreateResult executeTokenCreateTransaction(@NonNull final TokenCreateRequest request)
      throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TokenCreateTransaction transaction =
          new TokenCreateTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setTokenName(request.name())
              .setTokenSymbol(request.symbol())
              .setTreasuryAccountId(request.treasuryAccountId())
              .setTokenType(request.tokenType())
              .setSupplyKey(request.supplyKey());
      if (request.adminKey() != null) {
        transaction.setAdminKey(request.adminKey());
      }
      if (request.metadataKey() != null) {
        transaction.setMetadataKey(request.metadataKey());
      }
      if (request.wipeKey() != null) {
        transaction.setWipeKey(request.wipeKey());
      }
      if (request.freezeKey() != null) {
        transaction.setFreezeKey(request.freezeKey());
      }
      if (request.kycKey() != null) {
        transaction.setKycKey(request.kycKey());
      }
      sign(transaction, request.treasuryKey(), request.supplyKey(), request.adminKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOKEN_CREATE);
      return new TokenCreateResult(receipt.transactionId, receipt.status, receipt.tokenId);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute create token transaction", e);
    }
  }

  @Override
  public TokenDeleteResult executeTokenDeleteTransaction(@NonNull final TokenDeleteRequest request)
      throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TokenDeleteTransaction transaction =
          new TokenDeleteTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setTokenId(request.tokenId());
      sign(transaction, request.adminKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOKEN_DELETE);
      return new TokenDeleteResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute delete token transaction", e);
    }
  }

  @Override
  public TokenUpdateResult executeTokenUpdateTransaction(@NonNull final TokenUpdateRequest request)
      throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TokenUpdateTransaction transaction =
          new TokenUpdateTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setTokenId(request.tokenId());
      if (request.name() != null) {
        transaction.setTokenName(request.name());
      }
      if (request.symbol() != null) {
        transaction.setTokenSymbol(request.symbol());
      }
      sign(transaction, request.adminKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOKEN_UPDATE);
      return new TokenUpdateResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute update token transaction", e);
    }
  }

  @Override
  public TokenUpdateNftsResult executeTokenUpdateNftsTransaction(
      @NonNull final TokenUpdateNftsRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TokenUpdateNftsTransaction transaction =
          new TokenUpdateNftsTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setTokenId(request.tokenId())
              .setSerials(request.serials())
              .setMetadata(request.metadata());
      sign(transaction, request.metadataKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.NFT_UPDATE);
      return new TokenUpdateNftsResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute update token nfts transaction", e);
    }
  }

  public TokenAssociateResult executeTokenAssociateTransaction(
      @NonNull final TokenAssociateRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TokenAssociateTransaction transaction =
          new TokenAssociateTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setTokenIds(request.tokenIds())
              .setAccountId(request.accountId());
      sign(transaction, request.accountPrivateKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOKEN_ASSOCIATE);
      return new TokenAssociateResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute associate token transaction", e);
    }
  }

  @Override
  public @NonNull TokenDissociateResult executeTokenDissociateTransaction(
      @NonNull TokenDissociateRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TokenDissociateTransaction transaction =
          new TokenDissociateTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setAccountId(request.accountId())
              .setTokenIds(request.tokenIds());
      sign(transaction, request.accountKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOKEN_DISSOCIATE);
      return new TokenDissociateResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute dissociate token transaction", e);
    }
  }

  @Override
  public TokenFreezeResult executeTokenFreezeTransaction(@NonNull final TokenFreezeRequest request)
      throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TokenFreezeTransaction transaction =
          new TokenFreezeTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setTokenId(request.tokenId())
              .setAccountId(request.accountId());
      sign(transaction, request.freezeKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOKEN_FREEZE);
      return new TokenFreezeResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute freeze token transaction", e);
    }
  }

  @Override
  public TokenUnfreezeResult executeTokenUnfreezeTransaction(
      @NonNull final TokenUnfreezeRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TokenUnfreezeTransaction transaction =
          new TokenUnfreezeTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setTokenId(request.tokenId())
              .setAccountId(request.accountId());
      sign(transaction, request.freezeKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOKEN_UNFREEZE);
      return new TokenUnfreezeResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute unfreeze token transaction", e);
    }
  }

  @Override
  public TokenGrantKycResult executeTokenGrantKycTransaction(
      @NonNull final TokenGrantKycRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TokenGrantKycTransaction transaction =
          new TokenGrantKycTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setTokenId(request.tokenId())
              .setAccountId(request.accountId());
      sign(transaction, request.kycKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOKEN_GRANT_KYC);
      return new TokenGrantKycResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute grant kyc token transaction", e);
    }
  }

  @Override
  public TokenRevokeKycResult executeTokenRevokeKycTransaction(
      @NonNull final TokenRevokeKycRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TokenRevokeKycTransaction transaction =
          new TokenRevokeKycTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setTokenId(request.tokenId())
              .setAccountId(request.accountId());
      sign(transaction, request.kycKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOKEN_REVOKE_KYC);
      return new TokenRevokeKycResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute revoke kyc token transaction", e);
    }
  }

  public TokenBurnResult executeBurnTokenTransaction(@NonNull final TokenBurnRequest request)
      throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TokenBurnTransaction transaction =
          new TokenBurnTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setTokenId(request.tokenId());
      if (request.amount() != null) {
        transaction.setAmount(request.amount());
      } else if (request.serials() != null) {
        transaction.setSerials(List.copyOf(request.serials()));
      } else {
        throw new IllegalArgumentException("either amount or serial must be provided");
      }

      sign(transaction, request.supplyKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOKEN_BURN);
      return new TokenBurnResult(receipt.transactionId, receipt.status, receipt.totalSupply);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute burn token transaction", e);
    }
  }

  @Override
  public TokenWipeResult executeWipeTokenTransaction(@NonNull final TokenWipeRequest request)
      throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TokenWipeTransaction transaction =
          new TokenWipeTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setTokenId(request.tokenId())
              .setAccountId(request.accountId())
              .setSerials(List.copyOf(request.serials()));
      sign(transaction, request.wipeKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOKEN_WIPE);
      return new TokenWipeResult(receipt.transactionId, receipt.status, receipt.totalSupply);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute wipe token transaction", e);
    }
  }

  public TokenMintResult executeMintTokenTransaction(@NonNull final TokenMintRequest request)
      throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TokenMintTransaction transaction =
          new TokenMintTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setTokenId(request.tokenId());
      if (request.amount() != null) {
        transaction.setAmount(request.amount());
      } else if (request.metadata() != null) {
        transaction.setMetadata(request.metadata());
      } else {
        throw new IllegalArgumentException("either amount or metadata must be provided");
      }
      sign(transaction, request.supplyKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOKEN_MINT);
      return new TokenMintResult(
          receipt.transactionId, receipt.status, receipt.serials, receipt.totalSupply);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute mint token transaction", e);
    }
  }

  public TokenTransferResult executeTransferTransaction(@NonNull final TokenTransferRequest request)
      throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TransferTransaction transaction =
          new TransferTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration());
      if (!request.serials().isEmpty()) {
        request
            .serials()
            .forEach(
                serial ->
                    transaction.addNftTransfer(
                        new NftId(request.tokenId(), serial),
                        request.sender(),
                        request.receiver()));
      } else if (request.amount() != null) {
        transaction.addTokenTransfer(request.tokenId(), request.sender(), request.amount() * -1);
        transaction.addTokenTransfer(request.tokenId(), request.receiver(), request.amount());
      } else {
        throw new IllegalArgumentException("either amount or serial must be provided");
      }
      sign(transaction, request.senderKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.CRYPTO_TRANSFER);
      return new TokenTransferResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute transfer nft transaction", e);
    }
  }

  @Override
  public TokenAirdropResult executeTokenAirdropTransaction(
      @NonNull final TokenAirdropRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TokenAirdropTransaction transaction =
          new TokenAirdropTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration());
      request
          .serialToReceiver()
          .forEach(
              (serial, receiver) ->
                  transaction.addNftTransfer(
                      request.tokenId().nft(serial), request.sender(), receiver));
      sign(transaction, request.senderKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOKEN_AIRDROP);
      return new TokenAirdropResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute token airdrop transaction", e);
    }
  }

  @Override
  public TokenCancelAirdropResult executeTokenCancelAirdropTransaction(
      @NonNull final TokenCancelAirdropRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TokenCancelAirdropTransaction transaction =
          new TokenCancelAirdropTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration());
      request
          .serialToReceiver()
          .forEach(
              (serial, receiver) ->
                  transaction.addPendingAirdrop(
                      new PendingAirdropId(
                          request.sender(), receiver, request.tokenId().nft(serial))));
      sign(transaction, request.senderKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOKEN_CANCEL_AIRDROP);
      return new TokenCancelAirdropResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute token cancel airdrop transaction", e);
    }
  }

  @Override
  public TokenRejectResult executeTokenRejectTransaction(@NonNull final TokenRejectRequest request)
      throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TokenRejectTransaction transaction =
          new TokenRejectTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setOwnerId(request.owner())
              .setNftIds(request.serials().stream().map(request.tokenId()::nft).toList());
      sign(transaction, request.ownerKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.TOKEN_REJECT);
      return new TokenRejectResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute token reject transaction", e);
    }
  }

  @Override
  public HbarTransferResult executeHbarTransferTransaction(
      @NonNull final HbarTransferRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final TransferTransaction transaction =
          new TransferTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .addHbarTransfer(request.sender(), request.amount().negated())
              .addHbarTransfer(request.receiver(), request.amount());
      sign(transaction, request.senderKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.CRYPTO_TRANSFER);
      return new HbarTransferResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute HBAR transfer transaction", e);
    }
  }

  @Override
  public HbarAllowanceApproveResult executeHbarAllowanceApproveTransaction(
      @NonNull final HbarAllowanceApproveRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final AccountAllowanceApproveTransaction transaction =
          new AccountAllowanceApproveTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .approveHbarAllowance(request.owner(), request.spender(), request.amount());
      sign(transaction, request.ownerKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.ALLOWANCE_APPROVAL);
      return new HbarAllowanceApproveResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute HBAR allowance approve transaction", e);
    }
  }

  @Override
  public NftAllowanceDeleteResult executeNftAllowanceDeleteTransaction(
      @NonNull final NftAllowanceDeleteRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final AccountAllowanceDeleteTransaction transaction =
          new AccountAllowanceDeleteTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .deleteAllTokenNftAllowances(request.nftId(), request.owner());
      sign(transaction, request.ownerKey());
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.ALLOWANCE_DELETION);
      return new NftAllowanceDeleteResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute NFT allowance delete transaction", e);
    }
  }

  @Override
  public @NonNull HookStoreResult executeHookStoreTransaction(
      @NonNull final HookStoreRequest request) throws HieroException {
    Objects.requireNonNull(request, "request must not be null");
    try {
      final HookStoreTransaction transaction =
          new HookStoreTransaction()
              .setMaxTransactionFee(request.maxTransactionFee())
              .setTransactionValidDuration(request.transactionValidDuration())
              .setHookId(request.hookId())
              .setStorageUpdates(request.storageUpdates());
      if (!request.signerKeys().isEmpty()) {
        sign(transaction, request.signerKeys().toArray(PrivateKey[]::new));
      }
      final TransactionReceipt receipt =
          executeTransactionAndWaitOnReceipt(transaction, TransactionType.HOOK_STORE);
      return new HookStoreResult(receipt.transactionId, receipt.status);
    } catch (final Exception e) {
      throw new HieroException("Failed to execute hook store transaction", e);
    }
  }

  @NonNull
  private <T extends Transaction<T>> Transaction<T> sign(
      Transaction<T> transaction, final PrivateKey... keys) {
    if (keys != null) {
      transaction.freezeWith(hieroContext.getClient());
      for (PrivateKey key : keys) {
        if (key != null) {
          transaction.sign(key);
        }
      }
    }
    return transaction;
  }

  @NonNull
  private ContractFunctionParameters createParameters(
      @NonNull final List<ContractParam<?>> params) {
    Objects.requireNonNull(params, "params must not be null");
    final ContractFunctionParameters constructorParams = new ContractFunctionParameters();
    final Consumer<ContractParam> consumer =
        param -> param.supplier().addParamToFunctionParameters(param.value(), constructorParams);
    params.forEach(consumer);
    return constructorParams;
  }

  @NonNull
  private <T extends Transaction<T>> TransactionReceipt executeTransactionAndWaitOnReceipt(
      @NonNull final T transaction, @NonNull final TransactionType type) throws HieroException {
    Objects.requireNonNull(transaction, "transaction must not be null");
    Objects.requireNonNull(type, "type must not be null");
    try {
      log.debug("Sending transaction of type {}", transaction.getClass().getSimpleName());
      final TransactionResponse response = transaction.execute(hieroContext.getClient());
      listeners.forEach(
          listener -> {
            try {
              listener.transactionSubmitted(type, response.transactionId);
            } catch (Exception e) {
              log.error("Failed to notify listener", e);
            }
          });
      try {
        log.debug(
            "Waiting for receipt of transaction '{}' of type {}",
            response.transactionId,
            transaction.getClass().getSimpleName());
        final TransactionReceipt receipt = response.getReceipt(hieroContext.getClient());
        listeners.forEach(
            listener -> {
              try {
                listener.transactionHandled(type, response.transactionId, receipt.status);
              } catch (Exception e) {
                log.error("Failed to notify listener", e);
              }
            });
        return receipt;
      } catch (Exception e) {
        throw new HieroException(
            "Failed to receive receipt of transaction '"
                + response.transactionId
                + "' of type "
                + transaction.getClass(),
            e);
      }
    } catch (final Exception e) {
      throw new HieroException(
          "Failed to execute transaction of type " + transaction.getClass().getSimpleName(), e);
    }
  }

  @NonNull
  private <T extends Transaction<T>> TransactionRecord executeTransactionAndWaitOnRecord(
      @NonNull final T transaction, @NonNull final TransactionType type) throws HieroException {
    final TransactionReceipt receipt = executeTransactionAndWaitOnReceipt(transaction, type);
    try {
      log.debug(
          "Waiting for record of transaction '{}' of type {}",
          receipt.transactionId,
          transaction.getClass().getSimpleName());

      final ReceiveRecordHandler data =
          new ReceiveRecordHandler(
              transaction, receipt, r -> r.transactionId.getRecord(hieroContext.getClient()));
      return recordInterceptor.get().getRecordFor(data);
    } catch (final Exception e) {
      throw new HieroException(
          "Failed to receive record of transaction '"
              + receipt.transactionId
              + "' of type "
              + transaction.getClass(),
          e);
    }
  }

  @NonNull
  private <R, Q extends Query<R, Q>> R executeQueryAndWait(@NonNull final Q query)
      throws HieroException {
    Objects.requireNonNull(query, "query must not be null");
    try {
      log.debug("Sending query of type {}", query.getClass().getSimpleName());
      return query.execute(hieroContext.getClient());
    } catch (Exception e) {
      throw new HieroException("Failed to execute query", e);
    }
  }

  @NonNull
  @Override
  public Runnable addTransactionListener(@NonNull TransactionListener listener) {
    listeners.add(listener);
    return () -> listeners.remove(listener);
  }

  @Override
  public AccountId getOperatorAccountId() {
    return hieroContext.getOperatorAccount().accountId();
  }
}
