package org.hiero.base.protocol.data;

import com.hedera.hashgraph.sdk.AccountId;
import com.hedera.hashgraph.sdk.Hbar;
import com.hedera.hashgraph.sdk.PrivateKey;
import com.hedera.hashgraph.sdk.TokenType;
import java.time.Duration;
import java.util.Objects;
import org.hiero.base.data.Account;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

public record TokenCreateRequest(
    @NonNull Hbar maxTransactionFee,
    @NonNull Duration transactionValidDuration,
    @NonNull String name,
    @NonNull String symbol,
    @NonNull AccountId treasuryAccountId,
    @NonNull PrivateKey treasuryKey,
    @NonNull TokenType tokenType,
    @Nullable PrivateKey supplyKey,
    @Nullable PrivateKey adminKey,
    @Nullable PrivateKey metadataKey,
    @Nullable PrivateKey wipeKey,
    @Nullable PrivateKey freezeKey,
    @Nullable PrivateKey kycKey)
    implements TransactionRequest {

  static final int MAX_SYMBOL_LENGTH = 100;

  public TokenCreateRequest {
    Objects.requireNonNull(maxTransactionFee, "Max transaction fee cannot be null");
    Objects.requireNonNull(transactionValidDuration, "Transaction valid duration cannot be null");
    Objects.requireNonNull(name, "Name cannot be null");
    Objects.requireNonNull(symbol, "Symbol cannot be null");
    Objects.requireNonNull(treasuryAccountId, "Treasury account ID cannot be null");
    Objects.requireNonNull(tokenType, "Token type cannot be null");
    if (symbol.length() > MAX_SYMBOL_LENGTH) {
      throw new IllegalArgumentException(
          "Symbol length must be less than or equal to " + MAX_SYMBOL_LENGTH);
    }
  }

  public static TokenCreateRequest of(
      @NonNull final String name, @NonNull final String symbol, @NonNull final Account account) {
    return of(
        name,
        symbol,
        account.accountId(),
        account.privateKey(),
        TokenType.FUNGIBLE_COMMON,
        account.privateKey());
  }

  public static TokenCreateRequest of(
      @NonNull final String name,
      @NonNull final String symbol,
      @NonNull TokenType tokenType,
      @NonNull final Account account) {
    return of(
        name, symbol, account.accountId(), account.privateKey(), tokenType, account.privateKey());
  }

  public static TokenCreateRequest of(
      @NonNull final String name,
      @NonNull final String symbol,
      @NonNull final AccountId treasuryAccountId,
      @NonNull final PrivateKey treasuryKey) {
    return of(name, symbol, treasuryAccountId, treasuryKey, TokenType.FUNGIBLE_COMMON);
  }

  public static TokenCreateRequest of(
      @NonNull final String name,
      @NonNull final String symbol,
      @NonNull final AccountId treasuryAccountId,
      @NonNull final PrivateKey treasuryKey,
      @NonNull final TokenType tokenType) {
    return new TokenCreateRequest(
        Hbar.from(100),
        TransactionRequest.DEFAULT_TRANSACTION_VALID_DURATION,
        name,
        symbol,
        treasuryAccountId,
        treasuryKey,
        tokenType,
        null,
        treasuryKey,
        null,
        null,
        null,
        null);
  }

  public static TokenCreateRequest of(
      @NonNull final String name,
      @NonNull final String symbol,
      @NonNull final AccountId treasuryAccountId,
      @NonNull final PrivateKey treasuryKey,
      @NonNull final TokenType tokenType,
      @NonNull final PrivateKey supplyKey) {
    return new TokenCreateRequest(
        Hbar.from(100),
        TransactionRequest.DEFAULT_TRANSACTION_VALID_DURATION,
        name,
        symbol,
        treasuryAccountId,
        treasuryKey,
        tokenType,
        supplyKey,
        treasuryKey,
        null,
        null,
        null,
        null);
  }

  public static TokenCreateRequest of(
      @NonNull final String name,
      @NonNull final String symbol,
      @NonNull final AccountId treasuryAccountId,
      @NonNull final PrivateKey treasuryKey,
      @NonNull final TokenType tokenType,
      @NonNull final PrivateKey supplyKey,
      @NonNull final PrivateKey metadataKey) {
    return new TokenCreateRequest(
        Hbar.from(100),
        TransactionRequest.DEFAULT_TRANSACTION_VALID_DURATION,
        name,
        symbol,
        treasuryAccountId,
        treasuryKey,
        tokenType,
        supplyKey,
        treasuryKey,
        metadataKey,
        null,
        null,
        null);
  }

  /**
   * Creates a token create request with supply, optional metadata, and wipe keys.
   *
   * @param wipeKey the wipe key; required to wipe tokens from non-treasury accounts
   */
  public static TokenCreateRequest of(
      @NonNull final String name,
      @NonNull final String symbol,
      @NonNull final AccountId treasuryAccountId,
      @NonNull final PrivateKey treasuryKey,
      @NonNull final TokenType tokenType,
      @NonNull final PrivateKey supplyKey,
      @Nullable final PrivateKey metadataKey,
      @NonNull final PrivateKey wipeKey) {
    Objects.requireNonNull(wipeKey, "Wipe key cannot be null");
    return new TokenCreateRequest(
        Hbar.from(100),
        TransactionRequest.DEFAULT_TRANSACTION_VALID_DURATION,
        name,
        symbol,
        treasuryAccountId,
        treasuryKey,
        tokenType,
        supplyKey,
        treasuryKey,
        metadataKey,
        wipeKey,
        null,
        null);
  }

  /**
   * Creates a token create request with supply, optional metadata, wipe, and freeze keys.
   *
   * @param wipeKey the wipe key; optional unless wiping from non-treasury accounts
   * @param freezeKey the freeze key; required to freeze or unfreeze accounts for the token
   */
  public static TokenCreateRequest of(
      @NonNull final String name,
      @NonNull final String symbol,
      @NonNull final AccountId treasuryAccountId,
      @NonNull final PrivateKey treasuryKey,
      @NonNull final TokenType tokenType,
      @NonNull final PrivateKey supplyKey,
      @Nullable final PrivateKey metadataKey,
      @Nullable final PrivateKey wipeKey,
      @Nullable final PrivateKey freezeKey) {
    return new TokenCreateRequest(
        Hbar.from(100),
        TransactionRequest.DEFAULT_TRANSACTION_VALID_DURATION,
        name,
        symbol,
        treasuryAccountId,
        treasuryKey,
        tokenType,
        supplyKey,
        treasuryKey,
        metadataKey,
        wipeKey,
        freezeKey,
        null);
  }

  /**
   * Creates a token create request with supply, optional metadata, wipe, freeze, and KYC keys.
   *
   * @param wipeKey the wipe key; optional unless wiping from non-treasury accounts
   * @param freezeKey the freeze key; required to freeze or unfreeze accounts for the token
   * @param kycKey the KYC key; required to grant or revoke KYC for the token
   */
  public static TokenCreateRequest of(
      @NonNull final String name,
      @NonNull final String symbol,
      @NonNull final AccountId treasuryAccountId,
      @NonNull final PrivateKey treasuryKey,
      @NonNull final TokenType tokenType,
      @NonNull final PrivateKey supplyKey,
      @Nullable final PrivateKey metadataKey,
      @Nullable final PrivateKey wipeKey,
      @Nullable final PrivateKey freezeKey,
      @Nullable final PrivateKey kycKey) {
    return new TokenCreateRequest(
        Hbar.from(100),
        TransactionRequest.DEFAULT_TRANSACTION_VALID_DURATION,
        name,
        symbol,
        treasuryAccountId,
        treasuryKey,
        tokenType,
        supplyKey,
        treasuryKey,
        metadataKey,
        wipeKey,
        freezeKey,
        kycKey);
  }
}
