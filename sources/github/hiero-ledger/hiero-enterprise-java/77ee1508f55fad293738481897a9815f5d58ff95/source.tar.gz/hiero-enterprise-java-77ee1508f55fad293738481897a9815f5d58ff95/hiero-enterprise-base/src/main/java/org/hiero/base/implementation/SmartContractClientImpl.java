package org.hiero.base.implementation;

import static org.hiero.base.implementation.ProtocolLayerClientImpl.MAX_GAS_LIMIT;

import com.hedera.hashgraph.sdk.AccountId;
import com.hedera.hashgraph.sdk.ContractFunctionResult;
import com.hedera.hashgraph.sdk.ContractId;
import com.hedera.hashgraph.sdk.FileId;
import com.hedera.hashgraph.sdk.Hbar;
import com.hedera.hashgraph.sdk.PrivateKey;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Objects;
import org.hiero.base.FileClient;
import org.hiero.base.HieroException;
import org.hiero.base.SmartContractClient;
import org.hiero.base.data.Account;
import org.hiero.base.data.ContractCallResult;
import org.hiero.base.data.ContractParam;
import org.hiero.base.protocol.ProtocolLayerClient;
import org.hiero.base.protocol.data.ContractCallRequest;
import org.hiero.base.protocol.data.ContractCreateRequest;
import org.hiero.base.protocol.data.ContractCreateResult;
import org.hiero.base.protocol.data.ContractDeleteRequest;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SmartContractClientImpl implements SmartContractClient {

  private static final Logger log = LoggerFactory.getLogger(SmartContractClientImpl.class);

  private final ProtocolLayerClient protocolLayerClient;

  private final FileClient fileClient;

  private final Account operatorAccount;

  public SmartContractClientImpl(
      @NonNull final ProtocolLayerClient protocolLayerClient,
      @NonNull final FileClient fileClient,
      @NonNull final Account operationalAccount) {
    this.protocolLayerClient =
        Objects.requireNonNull(protocolLayerClient, "protocolLayerClient must not be null");
    this.fileClient = Objects.requireNonNull(fileClient, "fileClient must not be null");
    this.operatorAccount = Objects.requireNonNull(operationalAccount, "operationalAccount");
  }

  @NonNull
  @Override
  public ContractId createContract(
      @NonNull final FileId fileId,
      @NonNull final Hbar maxTransactionFee,
      final int gas,
      @Nullable final ContractParam<?>... constructorParams)
      throws HieroException {
    Objects.requireNonNull(fileId, "fileId must not be null");
    Objects.requireNonNull(maxTransactionFee, "maxTransactionFee must not be null");

    if (gas < 0 || gas > MAX_GAS_LIMIT) {
      throw new IllegalArgumentException(
          "gas must be between 0 and " + MAX_GAS_LIMIT + " inclusive");
    }

    try {
      final ContractCreateRequest request =
          buildContractCreateRequest(fileId, maxTransactionFee, gas, null, constructorParams);
      final ContractCreateResult result =
          protocolLayerClient.executeContractCreateTransaction(request);
      return result.contractId();
    } catch (Exception e) {
      throw new HieroException("Failed to create contract with fileId " + fileId, e);
    }
  }

  @NonNull
  @Override
  public ContractId createContract(
      @NonNull final byte[] contents,
      @NonNull final Hbar maxTransactionFee,
      final int gas,
      @Nullable final ContractParam<?>... constructorParams)
      throws HieroException {
    Objects.requireNonNull(contents, "contents must not be null");
    Objects.requireNonNull(maxTransactionFee, "maxTransactionFee must not be null");

    final FileId fileId = fileClient.createFile(contents);
    try {
      return createContract(fileId, maxTransactionFee, gas, constructorParams);
    } catch (Exception e) {
      throw new HieroException("Failed to create contract out of byte array", e);
    } finally {
      fileClient.deleteFile(fileId);
    }
  }

  @NonNull
  @Override
  public ContractId createContract(
      @NonNull final Path pathToBin,
      @NonNull final Hbar maxTransactionFee,
      final int gas,
      @Nullable final ContractParam<?>... constructorParams)
      throws HieroException {
    Objects.requireNonNull(pathToBin, "pathToBin must not be null");
    Objects.requireNonNull(maxTransactionFee, "maxTransactionFee must not be null");

    try {
      final byte[] bytes = Files.readAllBytes(pathToBin);
      return createContract(bytes, maxTransactionFee, gas, constructorParams);
    } catch (Exception e) {
      throw new HieroException("Failed to create contract from path " + pathToBin, e);
    }
  }

  @Override
  public @NonNull ContractId createContract(
      @NonNull FileId fileId,
      @NonNull Hbar maxTransactionFee,
      int gas,
      @NonNull PrivateKey adminKey,
      @Nullable ContractParam<?>... constructorParams)
      throws HieroException {
    Objects.requireNonNull(fileId, "fileId must not be null");
    Objects.requireNonNull(maxTransactionFee, "maxTransactionFee must not be null");
    Objects.requireNonNull(adminKey, "adminKey must not be null");

    if (gas < 0 || gas > MAX_GAS_LIMIT) {
      throw new IllegalArgumentException(
          "gas must be between 0 and " + MAX_GAS_LIMIT + " inclusive");
    }

    try {
      final ContractCreateRequest request =
          buildContractCreateRequest(fileId, maxTransactionFee, gas, adminKey, constructorParams);
      final ContractCreateResult result =
          protocolLayerClient.executeContractCreateTransaction(request);
      return result.contractId();
    } catch (Exception e) {
      throw new HieroException("Failed to create contract with fileId " + fileId, e);
    }
  }

  @Override
  public @NonNull ContractId createContract(
      byte[] contents,
      @NonNull Hbar maxTransactionFee,
      int gas,
      @NonNull PrivateKey adminKey,
      @Nullable ContractParam<?>... constructorParams)
      throws HieroException {
    Objects.requireNonNull(contents, "contents must not be null");
    Objects.requireNonNull(maxTransactionFee, "maxTransactionFee must not be null");
    Objects.requireNonNull(adminKey, "adminKey must not be null");

    final FileId fileId = fileClient.createFile(contents);
    try {
      return createContract(fileId, maxTransactionFee, gas, adminKey, constructorParams);
    } catch (Exception e) {
      throw new HieroException("Failed to create contract out of byte array", e);
    } finally {
      fileClient.deleteFile(fileId);
    }
  }

  @Override
  public @NonNull ContractId createContract(
      @NonNull Path pathToBin,
      @NonNull Hbar maxTransactionFee,
      int gas,
      @NonNull PrivateKey adminKey,
      @Nullable ContractParam<?>... constructorParams)
      throws HieroException {
    Objects.requireNonNull(pathToBin, "pathToBin must not be null");
    Objects.requireNonNull(maxTransactionFee, "maxTransactionFee must not be null");
    Objects.requireNonNull(adminKey, "adminKey must not be null");

    try {
      final byte[] bytes = Files.readAllBytes(pathToBin);
      return createContract(bytes, maxTransactionFee, gas, adminKey, constructorParams);
    } catch (Exception e) {
      throw new HieroException("Failed to create contract from path " + pathToBin, e);
    }
  }

  private @NonNull ContractCreateRequest buildContractCreateRequest(
      @NonNull FileId fileId,
      @NonNull Hbar maxTransactionFee,
      int gas,
      @Nullable PrivateKey adminKey,
      ContractParam<?>... constructorParams) {
    Objects.requireNonNull(fileId, "fileId must not be null");
    Objects.requireNonNull(maxTransactionFee, "maxTransactionFee must not be null");

    if (constructorParams == null) {
      return ContractCreateRequest.of(fileId, maxTransactionFee, gas, adminKey);
    }

    return ContractCreateRequest.of(
        fileId, maxTransactionFee, gas, adminKey, Arrays.asList(constructorParams));
  }

  @NonNull
  @Override
  public ContractCallResult callContractFunction(
      @NonNull final ContractId contractId,
      @NonNull final String functionName,
      @NonNull final Hbar maxTransactionFee,
      final int gas,
      @Nullable ContractParam<?>... params)
      throws HieroException {

    Objects.requireNonNull(contractId, "contractId must not be null");
    Objects.requireNonNull(functionName, "functionName must not be null");
    Objects.requireNonNull(maxTransactionFee, "maxTransactionFee must not be null");

    if (gas < 0 || gas > MAX_GAS_LIMIT) {
      throw new IllegalArgumentException(
          "gas must be between 0 and " + MAX_GAS_LIMIT + " inclusive");
    }

    try {
      final ContractCallRequest request =
          ContractCallRequest.of(contractId, functionName, maxTransactionFee, gas, params);
      final ContractFunctionResult result =
          protocolLayerClient.executeContractCallTransaction(request).contractFunctionResult();
      return new ContractCallResultImpl(result);
    } catch (Exception e) {
      throw new HieroException(
          "Failed to call function '" + functionName + "' on contract with id " + contractId, e);
    }
  }

  @Override
  public void deleteContract(@NonNull ContractId contractId, @NonNull PrivateKey adminKey)
      throws HieroException {
    Objects.requireNonNull(contractId, "contractId must not be null");
    Objects.requireNonNull(adminKey, "adminKey must not be null");

    deleteContract(contractId, operatorAccount.accountId(), adminKey);
  }

  @Override
  public void deleteContract(
      @NonNull ContractId contractId,
      @NonNull ContractId toContractId,
      @NonNull PrivateKey adminKey)
      throws HieroException {
    Objects.requireNonNull(contractId, "contractId must not be null");
    Objects.requireNonNull(toContractId, "toContractId must not be null");
    Objects.requireNonNull(adminKey, "adminKey must not be null");

    final ContractDeleteRequest request =
        ContractDeleteRequest.of(contractId, toContractId, adminKey);
    protocolLayerClient.executeContractDeleteTransaction(request);
  }

  @Override
  public void deleteContract(
      @NonNull ContractId contractId, @NonNull AccountId toAccountId, @NonNull PrivateKey adminKey)
      throws HieroException {
    Objects.requireNonNull(contractId, "contractId must not be null");
    Objects.requireNonNull(toAccountId, "toAccountId must not be null");
    Objects.requireNonNull(adminKey, "adminKey must not be null");

    final ContractDeleteRequest request =
        ContractDeleteRequest.of(contractId, toAccountId, adminKey);
    protocolLayerClient.executeContractDeleteTransaction(request);
  }
}
