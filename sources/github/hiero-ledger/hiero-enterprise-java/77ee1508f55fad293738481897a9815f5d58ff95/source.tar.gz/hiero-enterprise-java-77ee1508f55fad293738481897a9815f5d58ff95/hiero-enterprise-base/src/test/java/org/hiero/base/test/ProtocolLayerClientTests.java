package org.hiero.base.test;

import com.hedera.hashgraph.sdk.Client;
import org.hiero.base.HieroContext;
import org.hiero.base.data.Account;
import org.hiero.base.implementation.ProtocolLayerClientImpl;
import org.hiero.base.protocol.ProtocolLayerClient;
import org.jspecify.annotations.NonNull;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ProtocolLayerClientTests {

  @Test
  void testNullConstructorParam() {
    Assertions.assertThrows(NullPointerException.class, () -> new ProtocolLayerClientImpl(null));
  }

  @Test
  void testNullParams() {
    // given
    final HieroContext context =
        new HieroContext() {
          @Override
          public @NonNull Account getOperatorAccount() {
            return null;
          }

          @Override
          public @NonNull Client getClient() {
            return null;
          }
        };
    final ProtocolLayerClient client = new ProtocolLayerClientImpl(context);

    // then
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeAccountBalanceQuery(null));
    Assertions.assertThrows(NullPointerException.class, () -> client.executeAccountInfoQuery(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeFileContentsQuery(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeFileAppendRequestTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeFileDeleteTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeFileCreateTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeFileUpdateRequestTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeContractCreateTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeContractCallTransaction(null));
    Assertions.assertThrows(NullPointerException.class, () -> client.executeFileInfoQuery(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeAccountDeleteTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeContractDeleteTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeAccountCreateTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeAccountUpdateTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTokenCreateTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTokenAssociateTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTokenDeleteTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTokenUpdateTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTokenUpdateNftsTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTokenDissociateTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTopicCreateTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTopicDeleteTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTopicMessageSubmitTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeBurnTokenTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeWipeTokenTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeMintTokenTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTokenFreezeTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTokenUnfreezeTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTransferTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTokenAirdropTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTokenCancelAirdropTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTokenRejectTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTokenGrantKycTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeTokenRevokeKycTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeHbarTransferTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeHbarAllowanceApproveTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeNftAllowanceDeleteTransaction(null));
    Assertions.assertThrows(
        NullPointerException.class, () -> client.executeHookStoreTransaction(null));
  }
}
