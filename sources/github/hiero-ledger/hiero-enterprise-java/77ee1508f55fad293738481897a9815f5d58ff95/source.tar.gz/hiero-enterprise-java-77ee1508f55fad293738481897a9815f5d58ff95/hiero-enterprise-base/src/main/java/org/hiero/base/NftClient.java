package org.hiero.base;

import com.hedera.hashgraph.sdk.AccountId;
import com.hedera.hashgraph.sdk.PrivateKey;
import com.hedera.hashgraph.sdk.TokenId;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import org.hiero.base.data.Account;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

/**
 * Interface for interacting with a Hiero network. This interface provides methods for interacting
 * with Hedera NFTs, like creating and deleting NFTs. An implementation of this interface is using
 * an internal account to interact with a Hiero network. That account is the account that is used to
 * pay for the transactions that are sent to the Hedera network and called 'operator account'.
 */
public interface NftClient {

  /**
   * Create a new NFT type. That type is 'owned' by the operator account. The operator account is
   * used as suppler account and as treasury account for the NFT type.
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull TokenId createNftType(@NonNull String name, @NonNull String symbol)
      throws HieroException;

  /**
   * Create a new NFT type. The operator account is used as treasury account for the NFT type.
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @param supplierKey the private key of the supplier account
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull TokenId createNftType(
      @NonNull String name, @NonNull String symbol, @NonNull PrivateKey supplierKey)
      throws HieroException;

  /**
   * Create a new NFT type. The operator account is used as treasury account for the NFT type.
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @param supplierKey the private key of the supplier account
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull
  default TokenId createNftType(
      @NonNull String name, @NonNull String symbol, @NonNull String supplierKey)
      throws HieroException {
    Objects.requireNonNull(supplierKey, "supplierKey must not be null");
    return createNftType(name, symbol, PrivateKey.fromStringDER(supplierKey));
  }

  /**
   * Create a new NFT type. The operator account is used as supplier account for the NFT type.
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @param treasuryAccountId the ID of the treasury account
   * @param treasuryKey the private key of the treasury account
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull TokenId createNftType(
      @NonNull String name,
      @NonNull String symbol,
      @NonNull AccountId treasuryAccountId,
      @NonNull PrivateKey treasuryKey)
      throws HieroException;

  /**
   * Create a new NFT type. The operator account is used as supplier account for the NFT type.
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @param treasuryAccountId the ID of the treasury account
   * @param treasuryKey the private key of the treasury account
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull
  default TokenId createNftType(
      @NonNull String name,
      @NonNull String symbol,
      @NonNull String treasuryAccountId,
      @NonNull String treasuryKey)
      throws HieroException {
    Objects.requireNonNull(treasuryAccountId, "treasuryAccountId must not be null");
    Objects.requireNonNull(treasuryKey, "treasuryKey must not be null");
    return createNftType(
        name,
        symbol,
        AccountId.fromString(treasuryAccountId),
        PrivateKey.fromStringDER(treasuryKey));
  }

  /**
   * Create a new NFT type. The operator account is used as supplier account for the NFT type.
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @param treasuryAccount the treasury account
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull
  default TokenId createNftType(
      @NonNull String name, @NonNull String symbol, @NonNull Account treasuryAccount)
      throws HieroException {
    Objects.requireNonNull(treasuryAccount, "treasuryAccount must not be null");
    return createNftType(name, symbol, treasuryAccount.accountId(), treasuryAccount.privateKey());
  }

  /**
   * Create a new NFT type.
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @param treasuryAccountId the ID of the treasury account
   * @param treasuryKey the private key of the treasury account
   * @param supplierKey the private key of the supplier account
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull TokenId createNftType(
      @NonNull String name,
      @NonNull String symbol,
      @NonNull AccountId treasuryAccountId,
      @NonNull PrivateKey treasuryKey,
      @NonNull PrivateKey supplierKey)
      throws HieroException;

  /**
   * Create a new NFT type.
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @param treasuryAccountId the ID of the treasury account
   * @param treasuryKey the private key of the treasury account
   * @param supplierKey the private key of the supplier account
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull
  default TokenId createNftType(
      @NonNull String name,
      @NonNull String symbol,
      @NonNull String treasuryAccountId,
      @NonNull String treasuryKey,
      @NonNull String supplierKey)
      throws HieroException {
    Objects.requireNonNull(treasuryAccountId, "treasuryAccountId must not be null");
    Objects.requireNonNull(treasuryKey, "treasuryKey must not be null");
    Objects.requireNonNull(supplierKey, "supplierKey must not be null");
    return createNftType(
        name,
        symbol,
        AccountId.fromString(treasuryAccountId),
        PrivateKey.fromStringDER(treasuryKey),
        PrivateKey.fromStringDER(supplierKey));
  }

  /**
   * Create a new NFT type.
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @param treasuryAccount the treasury account
   * @param supplierKey the private key of the supplier account
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull
  default TokenId createNftType(
      @NonNull String name,
      @NonNull String symbol,
      @NonNull Account treasuryAccount,
      @NonNull PrivateKey supplierKey)
      throws HieroException {
    Objects.requireNonNull(treasuryAccount, "treasuryAccount must not be null");
    return createNftType(
        name, symbol, treasuryAccount.accountId(), treasuryAccount.privateKey(), supplierKey);
  }

  /**
   * Create a new NFT type with a metadata key. The operator account is used as treasury. The
   * metadata key can authorize updates to NFT serial metadata, including after transfer out of the
   * treasury (HIP-850).
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @param supplierKey the private key of the supplier account
   * @param metadataKey the private key authorized to update NFT serial metadata
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull TokenId createNftType(
      @NonNull String name,
      @NonNull String symbol,
      @NonNull PrivateKey supplierKey,
      @NonNull PrivateKey metadataKey)
      throws HieroException;

  /**
   * Create a new NFT type with a metadata key. The metadata key can authorize updates to NFT serial
   * metadata, including after transfer out of the treasury (HIP-850).
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @param treasuryAccountId the ID of the treasury account
   * @param treasuryKey the private key of the treasury account
   * @param supplierKey the private key of the supplier account
   * @param metadataKey the private key authorized to update NFT serial metadata
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull TokenId createNftType(
      @NonNull String name,
      @NonNull String symbol,
      @NonNull AccountId treasuryAccountId,
      @NonNull PrivateKey treasuryKey,
      @NonNull PrivateKey supplierKey,
      @NonNull PrivateKey metadataKey)
      throws HieroException;

  /**
   * Create a new NFT type with a metadata key.
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @param treasuryAccountId the ID of the treasury account
   * @param treasuryKey the private key of the treasury account
   * @param supplierKey the private key of the supplier account
   * @param metadataKey the private key authorized to update NFT serial metadata
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull
  default TokenId createNftType(
      @NonNull String name,
      @NonNull String symbol,
      @NonNull String treasuryAccountId,
      @NonNull String treasuryKey,
      @NonNull String supplierKey,
      @NonNull String metadataKey)
      throws HieroException {
    Objects.requireNonNull(treasuryAccountId, "treasuryAccountId must not be null");
    Objects.requireNonNull(treasuryKey, "treasuryKey must not be null");
    Objects.requireNonNull(supplierKey, "supplierKey must not be null");
    Objects.requireNonNull(metadataKey, "metadataKey must not be null");
    return createNftType(
        name,
        symbol,
        AccountId.fromString(treasuryAccountId),
        PrivateKey.fromStringDER(treasuryKey),
        PrivateKey.fromStringDER(supplierKey),
        PrivateKey.fromStringDER(metadataKey));
  }

  /**
   * Create a new NFT type with a metadata key.
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @param treasuryAccount the treasury account
   * @param supplierKey the private key of the supplier account
   * @param metadataKey the private key authorized to update NFT serial metadata
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull
  default TokenId createNftType(
      @NonNull String name,
      @NonNull String symbol,
      @NonNull Account treasuryAccount,
      @NonNull PrivateKey supplierKey,
      @NonNull PrivateKey metadataKey)
      throws HieroException {
    Objects.requireNonNull(treasuryAccount, "treasuryAccount must not be null");
    return createNftType(
        name,
        symbol,
        treasuryAccount.accountId(),
        treasuryAccount.privateKey(),
        supplierKey,
        metadataKey);
  }

  /**
   * Create a new NFT type with optional metadata and KYC keys. The operator account is used as
   * treasury.
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @param supplierKey the private key of the supplier account
   * @param metadataKey the private key authorized to update NFT serial metadata, or null
   * @param kycKey the private key authorized to grant or revoke KYC, or null
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull TokenId createNftType(
      @NonNull String name,
      @NonNull String symbol,
      @NonNull PrivateKey supplierKey,
      @Nullable PrivateKey metadataKey,
      @Nullable PrivateKey kycKey)
      throws HieroException;

  /**
   * Create a new NFT type with optional metadata and KYC keys.
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @param treasuryAccountId the ID of the treasury account
   * @param treasuryKey the private key of the treasury account
   * @param supplierKey the private key of the supplier account
   * @param metadataKey the private key authorized to update NFT serial metadata, or null
   * @param kycKey the private key authorized to grant or revoke KYC, or null
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull TokenId createNftType(
      @NonNull String name,
      @NonNull String symbol,
      @NonNull AccountId treasuryAccountId,
      @NonNull PrivateKey treasuryKey,
      @NonNull PrivateKey supplierKey,
      @Nullable PrivateKey metadataKey,
      @Nullable PrivateKey kycKey)
      throws HieroException;

  /**
   * Create a new NFT type with optional metadata and KYC keys.
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @param treasuryAccountId the ID of the treasury account
   * @param treasuryKey the private key of the treasury account
   * @param supplierKey the private key of the supplier account
   * @param metadataKey the private key authorized to update NFT serial metadata, or null
   * @param kycKey the private key authorized to grant or revoke KYC, or null
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull
  default TokenId createNftType(
      @NonNull String name,
      @NonNull String symbol,
      @NonNull String treasuryAccountId,
      @NonNull String treasuryKey,
      @NonNull String supplierKey,
      @Nullable String metadataKey,
      @Nullable String kycKey)
      throws HieroException {
    Objects.requireNonNull(treasuryAccountId, "treasuryAccountId must not be null");
    Objects.requireNonNull(treasuryKey, "treasuryKey must not be null");
    Objects.requireNonNull(supplierKey, "supplierKey must not be null");
    return createNftType(
        name,
        symbol,
        AccountId.fromString(treasuryAccountId),
        PrivateKey.fromStringDER(treasuryKey),
        PrivateKey.fromStringDER(supplierKey),
        metadataKey == null ? null : PrivateKey.fromStringDER(metadataKey),
        kycKey == null ? null : PrivateKey.fromStringDER(kycKey));
  }

  /**
   * Create a new NFT type with optional metadata and KYC keys.
   *
   * @param name the name of the NFT type
   * @param symbol the symbol of the NFT type
   * @param treasuryAccount the treasury account
   * @param supplierKey the private key of the supplier account
   * @param metadataKey the private key authorized to update NFT serial metadata, or null
   * @param kycKey the private key authorized to grant or revoke KYC, or null
   * @return the ID of the new NFT type
   * @throws HieroException if the NFT type could not be created
   */
  @NonNull
  default TokenId createNftType(
      @NonNull String name,
      @NonNull String symbol,
      @NonNull Account treasuryAccount,
      @NonNull PrivateKey supplierKey,
      @Nullable PrivateKey metadataKey,
      @Nullable PrivateKey kycKey)
      throws HieroException {
    Objects.requireNonNull(treasuryAccount, "treasuryAccount must not be null");
    return createNftType(
        name,
        symbol,
        treasuryAccount.accountId(),
        treasuryAccount.privateKey(),
        supplierKey,
        metadataKey,
        kycKey);
  }

  /**
   * Associate an account with an NFT type. If an account is associated with an NFT type, the
   * account can hold NFTs of that type. Otherwise, the account cannot hold NFTs of that type and
   * tranfer NFTs of that type will fail.
   *
   * @param tokenId the ID of the NFT type
   * @param accountId the ID of the account
   * @param accountKey the private key of the account
   * @throws HieroException if the account could not be associated with the NFT type
   */
  void associateNft(
      @NonNull TokenId tokenId, @NonNull AccountId accountId, @NonNull PrivateKey accountKey)
      throws HieroException;

  /**
   * Associate an account with an NFT type. If an account is associated with an NFT type, the
   * account can hold NFTs of that type. Otherwise, the account cannot hold NFTs of that type and
   * tranfer NFTs of that type will fail.
   *
   * @param tokenId the ID of the NFT type
   * @param accountId the ID of the account
   * @param accountKey the private key of the account
   * @throws HieroException if the account could not be associated with the NFT type
   */
  default void associateNft(
      @NonNull String tokenId, @NonNull String accountId, @NonNull String accountKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(accountId, "accountId must not be null");
    Objects.requireNonNull(accountKey, "accountKey must not be null");
    associateNft(
        TokenId.fromString(tokenId),
        AccountId.fromString(accountId),
        PrivateKey.fromStringDER(accountKey));
  }

  /**
   * Associate an account with an NFT type. If an account is associated with an NFT type, the
   * account can hold NFTs of that type. Otherwise, the account cannot hold NFTs of that type and
   * tranfer NFTs of that type will fail.
   *
   * @param tokenId the ID of the NFT type
   * @param account the account
   * @throws HieroException if the account could not be associated with the NFT type
   */
  default void associateNft(@NonNull TokenId tokenId, @NonNull Account account)
      throws HieroException {
    Objects.requireNonNull(account, "account must not be null");
    associateNft(tokenId, account.accountId(), account.privateKey());
  }

  /**
   * Associate an account with an NFT type. If an account is associated with an NFT type, the
   * account can hold NFTs of that type. Otherwise, the account cannot hold NFTs of that type and
   * tranfer NFTs of that type will fail.
   *
   * @param tokenIds the List of ID for NFT type
   * @param accountId the accountId
   * @param accountKey the account privateKey
   * @throws HieroException if the account could not be associated with the NFT type
   */
  void associateNft(
      @NonNull List<TokenId> tokenIds, @NonNull AccountId accountId, @NonNull PrivateKey accountKey)
      throws HieroException;

  /**
   * Associate an account with an NFT type. If an account is associated with an NFT type, the
   * account can hold NFTs of that type. Otherwise, the account cannot hold NFTs of that type and
   * tranfer NFTs of that type will fail.
   *
   * @param tokenIds the List of ID for NFT type
   * @param account the account
   * @throws HieroException if the account could not be associated with the NFT type
   */
  default void associateNft(@NonNull List<TokenId> tokenIds, @NonNull Account account)
      throws HieroException {
    Objects.requireNonNull(account, "accountId must not be null");
    associateNft(tokenIds, account.accountId(), account.privateKey());
  }
  ;

  /**
   * Dissociate an account with an NFT type.
   *
   * @param tokenId the ID of the NFT type
   * @param accountId the accountId
   * @param accountKey the account privateKey
   * @throws HieroException if the account could not be associated with the NFT type
   */
  void dissociateNft(
      @NonNull TokenId tokenId, @NonNull AccountId accountId, @NonNull PrivateKey accountKey)
      throws HieroException;

  /**
   * Dissociate an account with an NFT type.
   *
   * @param tokenId the ID of the NFT type
   * @param accountId the accountId
   * @param accountKey the account privateKey
   * @throws HieroException if the account could not be associated with the NFT type
   */
  default void dissociateNft(
      @NonNull String tokenId, @NonNull String accountId, @NonNull String accountKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(accountId, "accountId must not be null");
    Objects.requireNonNull(accountKey, "accountKey must not be null");
    dissociateNft(
        TokenId.fromString(tokenId),
        AccountId.fromString(accountId),
        PrivateKey.fromStringDER(accountKey));
  }
  ;

  /**
   * Dissociate an account with an NFT type.
   *
   * @param tokenId the ID of the NFT type
   * @param account the account
   * @throws HieroException if the account could not be associated with the NFT type
   */
  default void dissociateNft(@NonNull TokenId tokenId, @NonNull Account account)
      throws HieroException {
    Objects.requireNonNull(account, "accountId must not be null");
    dissociateNft(tokenId, account.accountId(), account.privateKey());
  }
  ;

  /**
   * Dissociate an account with an NFT type.
   *
   * @param tokenIds the List of ID for NFT type
   * @param accountId the accountId
   * @param accountKey the account privateKey
   * @throws HieroException if the account could not be associated with the NFT type
   */
  void dissociateNft(
      @NonNull List<TokenId> tokenIds, @NonNull AccountId accountId, @NonNull PrivateKey accountKey)
      throws HieroException;

  /**
   * Dissociate an account with an NFT type.
   *
   * @param tokenIds the List of ID for NFT type
   * @param account the account
   * @throws HieroException if the account could not be associated with the NFT type
   */
  default void dissociateNft(@NonNull List<TokenId> tokenIds, @NonNull Account account)
      throws HieroException {
    Objects.requireNonNull(account, "accountId must not be null");
    dissociateNft(tokenIds, account.accountId(), account.privateKey());
  }
  ;

  /**
   * Freezes an account for the given NFT type. The operator account key is used as the freeze key.
   * A frozen account cannot send or receive NFTs of that type.
   *
   * @param tokenId the ID of the NFT type
   * @param accountId the ID of the account to freeze
   * @throws HieroException if the account could not be frozen for the NFT type
   */
  void freezeNft(@NonNull TokenId tokenId, @NonNull AccountId accountId) throws HieroException;

  /**
   * Freezes an account for the given NFT type. Must be signed by the token freeze key.
   *
   * @param tokenId the ID of the NFT type
   * @param accountId the ID of the account to freeze
   * @param freezeKey the freeze key of the NFT type
   * @throws HieroException if the account could not be frozen for the NFT type
   */
  void freezeNft(
      @NonNull TokenId tokenId, @NonNull AccountId accountId, @NonNull PrivateKey freezeKey)
      throws HieroException;

  /**
   * Freezes an account for the given NFT type.
   *
   * @param tokenId the ID of the NFT type
   * @param accountId the ID of the account to freeze
   * @param freezeKey the freeze key of the NFT type
   * @throws HieroException if the account could not be frozen for the NFT type
   */
  default void freezeNft(
      @NonNull String tokenId, @NonNull String accountId, @NonNull String freezeKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(accountId, "accountId must not be null");
    Objects.requireNonNull(freezeKey, "freezeKey must not be null");
    freezeNft(
        TokenId.fromString(tokenId),
        AccountId.fromString(accountId),
        PrivateKey.fromStringDER(freezeKey));
  }

  /**
   * Freezes an account for the given NFT type.
   *
   * @param tokenId the ID of the NFT type
   * @param account the account to freeze
   * @throws HieroException if the account could not be frozen for the NFT type
   */
  default void freezeNft(@NonNull TokenId tokenId, @NonNull Account account) throws HieroException {
    Objects.requireNonNull(account, "account must not be null");
    freezeNft(tokenId, account.accountId(), account.privateKey());
  }

  /**
   * Unfreezes an account for the given NFT type. The operator account key is used as the freeze
   * key.
   *
   * @param tokenId the ID of the NFT type
   * @param accountId the ID of the account to unfreeze
   * @throws HieroException if the account could not be unfrozen for the NFT type
   */
  void unfreezeNft(@NonNull TokenId tokenId, @NonNull AccountId accountId) throws HieroException;

  /**
   * Unfreezes an account for the given NFT type. Must be signed by the token freeze key.
   *
   * @param tokenId the ID of the NFT type
   * @param accountId the ID of the account to unfreeze
   * @param freezeKey the freeze key of the NFT type
   * @throws HieroException if the account could not be unfrozen for the NFT type
   */
  void unfreezeNft(
      @NonNull TokenId tokenId, @NonNull AccountId accountId, @NonNull PrivateKey freezeKey)
      throws HieroException;

  /**
   * Unfreezes an account for the given NFT type.
   *
   * @param tokenId the ID of the NFT type
   * @param accountId the ID of the account to unfreeze
   * @param freezeKey the freeze key of the NFT type
   * @throws HieroException if the account could not be unfrozen for the NFT type
   */
  default void unfreezeNft(
      @NonNull String tokenId, @NonNull String accountId, @NonNull String freezeKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(accountId, "accountId must not be null");
    Objects.requireNonNull(freezeKey, "freezeKey must not be null");
    unfreezeNft(
        TokenId.fromString(tokenId),
        AccountId.fromString(accountId),
        PrivateKey.fromStringDER(freezeKey));
  }

  /**
   * Unfreezes an account for the given NFT type.
   *
   * @param tokenId the ID of the NFT type
   * @param account the account to unfreeze
   * @throws HieroException if the account could not be unfrozen for the NFT type
   */
  default void unfreezeNft(@NonNull TokenId tokenId, @NonNull Account account)
      throws HieroException {
    Objects.requireNonNull(account, "account must not be null");
    unfreezeNft(tokenId, account.accountId(), account.privateKey());
  }

  /**
   * Grants KYC for an account on the given NFT type. The operator account key is used as the KYC
   * key.
   *
   * @param tokenId the ID of the NFT type
   * @param accountId the ID of the account to grant KYC for
   * @throws HieroException if KYC could not be granted for the account
   */
  void grantKycNft(@NonNull TokenId tokenId, @NonNull AccountId accountId) throws HieroException;

  /**
   * Grants KYC for an account on the given NFT type. Must be signed by the token KYC key.
   *
   * @param tokenId the ID of the NFT type
   * @param accountId the ID of the account to grant KYC for
   * @param kycKey the KYC key of the NFT type
   * @throws HieroException if KYC could not be granted for the account
   */
  void grantKycNft(
      @NonNull TokenId tokenId, @NonNull AccountId accountId, @NonNull PrivateKey kycKey)
      throws HieroException;

  /**
   * Grants KYC for an account on the given NFT type.
   *
   * @param tokenId the ID of the NFT type
   * @param accountId the ID of the account to grant KYC for
   * @param kycKey the KYC key of the NFT type
   * @throws HieroException if KYC could not be granted for the account
   */
  default void grantKycNft(
      @NonNull String tokenId, @NonNull String accountId, @NonNull String kycKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(accountId, "accountId must not be null");
    Objects.requireNonNull(kycKey, "kycKey must not be null");
    grantKycNft(
        TokenId.fromString(tokenId),
        AccountId.fromString(accountId),
        PrivateKey.fromStringDER(kycKey));
  }

  /**
   * Grants KYC for an account on the given NFT type.
   *
   * @param tokenId the ID of the NFT type
   * @param account the account to grant KYC for
   * @throws HieroException if KYC could not be granted for the account
   */
  default void grantKycNft(@NonNull TokenId tokenId, @NonNull Account account)
      throws HieroException {
    Objects.requireNonNull(account, "account must not be null");
    grantKycNft(tokenId, account.accountId(), account.privateKey());
  }

  /**
   * Revokes KYC for an account on the given NFT type. The operator account key is used as the KYC
   * key.
   *
   * @param tokenId the ID of the NFT type
   * @param accountId the ID of the account to revoke KYC for
   * @throws HieroException if KYC could not be revoked for the account
   */
  void revokeKycNft(@NonNull TokenId tokenId, @NonNull AccountId accountId) throws HieroException;

  /**
   * Revokes KYC for an account on the given NFT type. Must be signed by the token KYC key.
   *
   * @param tokenId the ID of the NFT type
   * @param accountId the ID of the account to revoke KYC for
   * @param kycKey the KYC key of the NFT type
   * @throws HieroException if KYC could not be revoked for the account
   */
  void revokeKycNft(
      @NonNull TokenId tokenId, @NonNull AccountId accountId, @NonNull PrivateKey kycKey)
      throws HieroException;

  /**
   * Revokes KYC for an account on the given NFT type.
   *
   * @param tokenId the ID of the NFT type
   * @param accountId the ID of the account to revoke KYC for
   * @param kycKey the KYC key of the NFT type
   * @throws HieroException if KYC could not be revoked for the account
   */
  default void revokeKycNft(
      @NonNull String tokenId, @NonNull String accountId, @NonNull String kycKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(accountId, "accountId must not be null");
    Objects.requireNonNull(kycKey, "kycKey must not be null");
    revokeKycNft(
        TokenId.fromString(tokenId),
        AccountId.fromString(accountId),
        PrivateKey.fromStringDER(kycKey));
  }

  /**
   * Revokes KYC for an account on the given NFT type.
   *
   * @param tokenId the ID of the NFT type
   * @param account the account to revoke KYC for
   * @throws HieroException if KYC could not be revoked for the account
   */
  default void revokeKycNft(@NonNull TokenId tokenId, @NonNull Account account)
      throws HieroException {
    Objects.requireNonNull(account, "account must not be null");
    revokeKycNft(tokenId, account.accountId(), account.privateKey());
  }

  /**
   * Mint a new NFT of the given type. The NFT is minted by the operator account. The operator
   * account is used as supply account for the NFT.
   *
   * @param tokenId the ID of the NFT type
   * @param metadata the metadata of the NFT
   * @return the serial number of the new NFT
   * @throws HieroException if the NFT could not be minted
   */
  long mintNft(@NonNull TokenId tokenId, @NonNull byte[] metadata) throws HieroException;

  /**
   * Mint a new NFT of the given type. The NFT is minted by the operator account. The operator
   * account is used as supply account for the NFT.
   *
   * @param tokenId the ID of the NFT type
   * @param metadata the metadata of the NFT
   * @return the serial number of the new NFT
   * @throws HieroException if the NFT could not be minted
   */
  default long mintNft(@NonNull String tokenId, @NonNull byte[] metadata) throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    return mintNft(TokenId.fromString(tokenId), metadata);
  }

  /**
   * Mint a new NFT of the given type.
   *
   * @param tokenId the ID of the NFT type
   * @param metadata the metadata of the NFT
   * @param supplyKey the private key of the supply account
   * @return the serial number of the new NFT
   * @throws HieroException if the NFT could not be minted
   */
  long mintNft(@NonNull TokenId tokenId, @NonNull PrivateKey supplyKey, @NonNull byte[] metadata)
      throws HieroException;

  /**
   * Mint a new NFT of the given type.
   *
   * @param tokenId the ID of the NFT type
   * @param metadata the metadata of the NFT
   * @param supplyKey the private key of the supply account
   * @return the serial number of the new NFT
   * @throws HieroException if the NFT could not be minted
   */
  default long mintNft(@NonNull String tokenId, @NonNull String supplyKey, @NonNull byte[] metadata)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(supplyKey, "supplyKey must not be null");
    return mintNft(TokenId.fromString(tokenId), PrivateKey.fromStringDER(supplyKey), metadata);
  }

  /**
   * Mint new NFTs of the given type. The NFTs are minted by the operator account. The operator
   * account is used as supply account for the NFTs.
   *
   * @param tokenId the ID of the NFT type
   * @param metadata the metadata of the NFTs
   * @return the serial numbers of the new NFTs
   * @throws HieroException if the NFTs could not be minted
   */
  @NonNull List<Long> mintNfts(@NonNull TokenId tokenId, @NonNull byte[]... metadata)
      throws HieroException;

  /**
   * Mint new NFTs of the given type. The NFTs are minted by the operator account. The operator
   * account is used as supply account for the NFTs.
   *
   * @param tokenId the ID of the NFT type
   * @param metadata the metadata of the NFTs
   * @return the serial numbers of the new NFTs
   * @throws HieroException if the NFTs could not be minted
   */
  @NonNull
  default List<Long> mintNfts(@NonNull String tokenId, @NonNull byte[]... metadata)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    return mintNfts(TokenId.fromString(tokenId), metadata);
  }

  /**
   * Mint new NFTs of the given type.
   *
   * @param tokenId the ID of the NFT type
   * @param metadata the metadata of the NFTs
   * @param supplyKey the private key of the supply account
   * @return the serial numbers of the new NFTs
   * @throws HieroException if the NFTs could not be minted
   */
  @NonNull List<Long> mintNfts(
      @NonNull TokenId tokenId, @NonNull PrivateKey supplyKey, @NonNull byte[]... metadata)
      throws HieroException;

  /**
   * Mint new NFTs of the given type.
   *
   * @param tokenId the ID of the NFT type
   * @param metadata the metadata of the NFTs
   * @param supplyKey the private key of the supply account
   * @return the serial numbers of the new NFTs
   * @throws HieroException if the NFTs could not be minted
   */
  @NonNull
  default List<Long> mintNfts(
      @NonNull String tokenId, @NonNull String supplyKey, @NonNull byte[]... metadata)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(supplyKey, "supplyKey must not be null");
    return mintNfts(TokenId.fromString(tokenId), PrivateKey.fromStringDER(supplyKey), metadata);
  }

  /**
   * Burn an NFT.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumber the serial number of the NFT
   * @return total supply for the NFT type after the burn
   * @throws HieroException if the NFT could not be burned
   */
  default long burnNft(@NonNull TokenId tokenId, long serialNumber) throws HieroException {
    return burnNfts(tokenId, Set.of(serialNumber));
  }

  /**
   * Burn an NFT.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumber the serial number of the NFT
   * @param supplyKey the private key of the supply account
   * @return total supply for the NFT type after the burn
   * @throws HieroException if the NFT could not be burned
   */
  default long burnNft(@NonNull TokenId tokenId, long serialNumber, @NonNull PrivateKey supplyKey)
      throws HieroException {
    return burnNfts(tokenId, Set.of(serialNumber), supplyKey);
  }

  /**
   * Burn NFTs.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumbers the serial numbers of the NFTs
   * @return total supply for the NFT type after the burn
   * @throws HieroException if the NFTs could not be burned
   */
  long burnNfts(@NonNull TokenId tokenId, @NonNull Set<Long> serialNumbers) throws HieroException;

  /**
   * Burn NFTs.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumbers the serial numbers of the NFTs
   * @param supplyKey the private key of the supply account
   * @return total supply for the NFT type after the burn
   * @throws HieroException if the NFTs could not be burned
   */
  long burnNfts(
      @NonNull TokenId tokenId, @NonNull Set<Long> serialNumbers, @NonNull PrivateKey supplyKey)
      throws HieroException;

  /**
   * Wipes an NFT from an account. The operator account key is used as the wipe key. The account
   * must not be the token treasury. Wiping burns the NFT and decreases total supply.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumber the serial number of the NFT
   * @param accountId the account to wipe the NFT from
   * @return total supply for the NFT type after the wipe
   * @throws HieroException if the NFT could not be wiped
   */
  default long wipeNft(@NonNull TokenId tokenId, long serialNumber, @NonNull AccountId accountId)
      throws HieroException {
    return wipeNfts(tokenId, Set.of(serialNumber), accountId);
  }

  /**
   * Wipes an NFT from an account. Must be signed by the token wipe key. The account must not be the
   * token treasury.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumber the serial number of the NFT
   * @param accountId the account to wipe the NFT from
   * @param wipeKey the wipe key of the NFT type
   * @return total supply for the NFT type after the wipe
   * @throws HieroException if the NFT could not be wiped
   */
  default long wipeNft(
      @NonNull TokenId tokenId,
      long serialNumber,
      @NonNull AccountId accountId,
      @NonNull PrivateKey wipeKey)
      throws HieroException {
    return wipeNfts(tokenId, Set.of(serialNumber), accountId, wipeKey);
  }

  /**
   * Wipes an NFT from an account.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumber the serial number of the NFT
   * @param account the account to wipe the NFT from
   * @param wipeKey the wipe key of the NFT type
   * @return total supply for the NFT type after the wipe
   * @throws HieroException if the NFT could not be wiped
   */
  default long wipeNft(
      @NonNull TokenId tokenId,
      long serialNumber,
      @NonNull Account account,
      @NonNull PrivateKey wipeKey)
      throws HieroException {
    Objects.requireNonNull(account, "account must not be null");
    return wipeNft(tokenId, serialNumber, account.accountId(), wipeKey);
  }

  /**
   * Wipes NFTs from an account. The operator account key is used as the wipe key. The account must
   * not be the token treasury. Wiping burns the NFTs and decreases total supply.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumbers the serial numbers of the NFTs
   * @param accountId the account to wipe the NFTs from
   * @return total supply for the NFT type after the wipe
   * @throws HieroException if the NFTs could not be wiped
   */
  long wipeNfts(
      @NonNull TokenId tokenId, @NonNull Set<Long> serialNumbers, @NonNull AccountId accountId)
      throws HieroException;

  /**
   * Wipes NFTs from an account. Must be signed by the token wipe key. The account must not be the
   * token treasury.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumbers the serial numbers of the NFTs
   * @param accountId the account to wipe the NFTs from
   * @param wipeKey the wipe key of the NFT type
   * @return total supply for the NFT type after the wipe
   * @throws HieroException if the NFTs could not be wiped
   */
  long wipeNfts(
      @NonNull TokenId tokenId,
      @NonNull Set<Long> serialNumbers,
      @NonNull AccountId accountId,
      @NonNull PrivateKey wipeKey)
      throws HieroException;

  /**
   * Wipes NFTs from an account.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumbers the serial numbers of the NFTs
   * @param account the account to wipe the NFTs from
   * @param wipeKey the wipe key of the NFT type
   * @return total supply for the NFT type after the wipe
   * @throws HieroException if the NFTs could not be wiped
   */
  default long wipeNfts(
      @NonNull TokenId tokenId,
      @NonNull Set<Long> serialNumbers,
      @NonNull Account account,
      @NonNull PrivateKey wipeKey)
      throws HieroException {
    Objects.requireNonNull(account, "account must not be null");
    return wipeNfts(tokenId, serialNumbers, account.accountId(), wipeKey);
  }

  /**
   * Transfer an NFT to another account.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumber the serial number of the NFT
   * @param fromAccountId the ID of the account that holds the NFT
   * @param fromAccountKey the private key of the account that holds the NFT
   * @param toAccountId the ID of the account that should receive the NFT
   * @throws HieroException if the NFT could not be transferred
   */
  void transferNft(
      @NonNull TokenId tokenId,
      long serialNumber,
      @NonNull AccountId fromAccountId,
      @NonNull PrivateKey fromAccountKey,
      @NonNull AccountId toAccountId)
      throws HieroException;

  /**
   * Transfer an NFT to another account.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumber the serial number of the NFT
   * @param fromAccount the account that holds the NFT
   * @param toAccountId the ID of the account that should receive the NFT
   * @throws HieroException if the NFT could not be transferred
   */
  default void transferNft(
      @NonNull TokenId tokenId,
      long serialNumber,
      @NonNull Account fromAccount,
      @NonNull AccountId toAccountId)
      throws HieroException {
    Objects.requireNonNull(fromAccount, "fromAccount must not be null");
    transferNft(
        tokenId, serialNumber, fromAccount.accountId(), fromAccount.privateKey(), toAccountId);
  }

  /**
   * Transfer NFTs to another account.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumbers the serial numbers of the NFTs
   * @param fromAccountId the ID of the account that holds the NFTs
   * @param fromAccountKey the private key of the account that holds the NFTs
   * @param toAccountId the ID of the account that should receive the NFTs
   * @throws HieroException if the NFTs could not be transferred
   */
  void transferNfts(
      @NonNull TokenId tokenId,
      @NonNull List<Long> serialNumbers,
      @NonNull AccountId fromAccountId,
      @NonNull PrivateKey fromAccountKey,
      @NonNull AccountId toAccountId)
      throws HieroException;

  /**
   * Transfer NFTs to another account.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumbers the serial numbers of the NFTs
   * @param fromAccount the account that holds the NFTs
   * @param toAccountId the ID of the account that should receive the NFTs
   * @throws HieroException if the NFTs could not be transferred
   */
  default void transferNfts(
      @NonNull TokenId tokenId,
      @NonNull List<Long> serialNumbers,
      @NonNull Account fromAccount,
      @NonNull AccountId toAccountId)
      throws HieroException {
    Objects.requireNonNull(fromAccount, "fromAccount must not be null");
    transferNfts(
        tokenId, serialNumbers, fromAccount.accountId(), fromAccount.privateKey(), toAccountId);
  }

  /**
   * Airdrops an NFT to another account. Unlike a standard transfer, if the receiver lacks available
   * auto-association slots the airdrop may become pending rather than failing.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumber the serial number of the NFT
   * @param fromAccountId the ID of the account that holds the NFT
   * @param fromAccountKey the private key of the account that holds the NFT
   * @param toAccountId the ID of the account that should receive the NFT
   * @throws HieroException if the NFT could not be airdropped
   */
  void airdropNft(
      @NonNull TokenId tokenId,
      long serialNumber,
      @NonNull AccountId fromAccountId,
      @NonNull PrivateKey fromAccountKey,
      @NonNull AccountId toAccountId)
      throws HieroException;

  /**
   * Airdrops an NFT to another account. Unlike a standard transfer, if the receiver lacks available
   * auto-association slots the airdrop may become pending rather than failing.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumber the serial number of the NFT
   * @param fromAccount the account that holds the NFT
   * @param toAccountId the ID of the account that should receive the NFT
   * @throws HieroException if the NFT could not be airdropped
   */
  default void airdropNft(
      @NonNull TokenId tokenId,
      long serialNumber,
      @NonNull Account fromAccount,
      @NonNull AccountId toAccountId)
      throws HieroException {
    Objects.requireNonNull(fromAccount, "fromAccount must not be null");
    airdropNft(
        tokenId, serialNumber, fromAccount.accountId(), fromAccount.privateKey(), toAccountId);
  }

  /**
   * Airdrops NFTs to another account. Unlike a standard transfer, if the receiver lacks available
   * auto-association slots the airdrop may become pending rather than failing.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumbers the serial numbers of the NFTs
   * @param fromAccountId the ID of the account that holds the NFTs
   * @param fromAccountKey the private key of the account that holds the NFTs
   * @param toAccountId the ID of the account that should receive the NFTs
   * @throws HieroException if the NFTs could not be airdropped
   */
  void airdropNfts(
      @NonNull TokenId tokenId,
      @NonNull List<Long> serialNumbers,
      @NonNull AccountId fromAccountId,
      @NonNull PrivateKey fromAccountKey,
      @NonNull AccountId toAccountId)
      throws HieroException;

  /**
   * Airdrops NFTs to another account. Unlike a standard transfer, if the receiver lacks available
   * auto-association slots the airdrop may become pending rather than failing.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumbers the serial numbers of the NFTs
   * @param fromAccount the account that holds the NFTs
   * @param toAccountId the ID of the account that should receive the NFTs
   * @throws HieroException if the NFTs could not be airdropped
   */
  default void airdropNfts(
      @NonNull TokenId tokenId,
      @NonNull List<Long> serialNumbers,
      @NonNull Account fromAccount,
      @NonNull AccountId toAccountId)
      throws HieroException {
    Objects.requireNonNull(fromAccount, "fromAccount must not be null");
    airdropNfts(
        tokenId, serialNumbers, fromAccount.accountId(), fromAccount.privateKey(), toAccountId);
  }

  /**
   * Airdrops NFTs to one or more accounts. Each map entry sends the given serial to the mapped
   * receiver. Unlike a standard transfer, if a receiver lacks available auto-association slots the
   * airdrop may become pending rather than failing.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumberToAccountId map of NFT serial number to receiving account ID
   * @param fromAccountId the ID of the account that holds the NFTs
   * @param fromAccountKey the private key of the account that holds the NFTs
   * @throws HieroException if the NFTs could not be airdropped
   */
  void airdropNfts(
      @NonNull TokenId tokenId,
      @NonNull Map<Long, AccountId> serialNumberToAccountId,
      @NonNull AccountId fromAccountId,
      @NonNull PrivateKey fromAccountKey)
      throws HieroException;

  /**
   * Airdrops NFTs to one or more accounts. Each map entry sends the given serial to the mapped
   * receiver. Unlike a standard transfer, if a receiver lacks available auto-association slots the
   * airdrop may become pending rather than failing.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumberToAccountId map of NFT serial number to receiving account ID
   * @param fromAccount the account that holds the NFTs
   * @throws HieroException if the NFTs could not be airdropped
   */
  default void airdropNfts(
      @NonNull TokenId tokenId,
      @NonNull Map<Long, AccountId> serialNumberToAccountId,
      @NonNull Account fromAccount)
      throws HieroException {
    Objects.requireNonNull(fromAccount, "fromAccount must not be null");
    airdropNfts(
        tokenId, serialNumberToAccountId, fromAccount.accountId(), fromAccount.privateKey());
  }

  /**
   * Cancels a pending NFT airdrop. The sender of the pending airdrop must sign the transaction.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumber the serial number of the pending NFT airdrop
   * @param fromAccountId the ID of the account that airdropped the NFT (sender)
   * @param fromAccountKey the private key of the sender account
   * @param toAccountId the ID of the account that was to receive the NFT (receiver)
   * @throws HieroException if the pending airdrop could not be canceled
   */
  void cancelAirdropNft(
      @NonNull TokenId tokenId,
      long serialNumber,
      @NonNull AccountId fromAccountId,
      @NonNull PrivateKey fromAccountKey,
      @NonNull AccountId toAccountId)
      throws HieroException;

  /**
   * Cancels a pending NFT airdrop. The sender of the pending airdrop must sign the transaction.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumber the serial number of the pending NFT airdrop
   * @param fromAccount the account that airdropped the NFT (sender)
   * @param toAccountId the ID of the account that was to receive the NFT (receiver)
   * @throws HieroException if the pending airdrop could not be canceled
   */
  default void cancelAirdropNft(
      @NonNull TokenId tokenId,
      long serialNumber,
      @NonNull Account fromAccount,
      @NonNull AccountId toAccountId)
      throws HieroException {
    Objects.requireNonNull(fromAccount, "fromAccount must not be null");
    cancelAirdropNft(
        tokenId, serialNumber, fromAccount.accountId(), fromAccount.privateKey(), toAccountId);
  }

  /**
   * Cancels pending NFT airdrops to a single receiver. The sender must sign the transaction.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumbers the serial numbers of the pending NFT airdrops
   * @param fromAccountId the ID of the account that airdropped the NFTs (sender)
   * @param fromAccountKey the private key of the sender account
   * @param toAccountId the ID of the account that was to receive the NFTs (receiver)
   * @throws HieroException if the pending airdrops could not be canceled
   */
  void cancelAirdropNfts(
      @NonNull TokenId tokenId,
      @NonNull List<Long> serialNumbers,
      @NonNull AccountId fromAccountId,
      @NonNull PrivateKey fromAccountKey,
      @NonNull AccountId toAccountId)
      throws HieroException;

  /**
   * Cancels pending NFT airdrops to a single receiver. The sender must sign the transaction.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumbers the serial numbers of the pending NFT airdrops
   * @param fromAccount the account that airdropped the NFTs (sender)
   * @param toAccountId the ID of the account that was to receive the NFTs (receiver)
   * @throws HieroException if the pending airdrops could not be canceled
   */
  default void cancelAirdropNfts(
      @NonNull TokenId tokenId,
      @NonNull List<Long> serialNumbers,
      @NonNull Account fromAccount,
      @NonNull AccountId toAccountId)
      throws HieroException {
    Objects.requireNonNull(fromAccount, "fromAccount must not be null");
    cancelAirdropNfts(
        tokenId, serialNumbers, fromAccount.accountId(), fromAccount.privateKey(), toAccountId);
  }

  /**
   * Cancels pending NFT airdrops to one or more receivers. Each map entry identifies a pending
   * airdrop by serial and the intended receiver. The sender must sign the transaction.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumberToAccountId map of NFT serial number to receiving account ID
   * @param fromAccountId the ID of the account that airdropped the NFTs (sender)
   * @param fromAccountKey the private key of the sender account
   * @throws HieroException if the pending airdrops could not be canceled
   */
  void cancelAirdropNfts(
      @NonNull TokenId tokenId,
      @NonNull Map<Long, AccountId> serialNumberToAccountId,
      @NonNull AccountId fromAccountId,
      @NonNull PrivateKey fromAccountKey)
      throws HieroException;

  /**
   * Cancels pending NFT airdrops to one or more receivers. Each map entry identifies a pending
   * airdrop by serial and the intended receiver. The sender must sign the transaction.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumberToAccountId map of NFT serial number to receiving account ID
   * @param fromAccount the account that airdropped the NFTs (sender)
   * @throws HieroException if the pending airdrops could not be canceled
   */
  default void cancelAirdropNfts(
      @NonNull TokenId tokenId,
      @NonNull Map<Long, AccountId> serialNumberToAccountId,
      @NonNull Account fromAccount)
      throws HieroException {
    Objects.requireNonNull(fromAccount, "fromAccount must not be null");
    cancelAirdropNfts(
        tokenId, serialNumberToAccountId, fromAccount.accountId(), fromAccount.privateKey());
  }

  /**
   * Rejects an NFT, for example an unwanted airdrop, by returning it to the treasury of the NFT
   * type. No custom fees are charged. The owner stays associated with the NFT type. Rejection fails
   * if the NFT type is paused or the owner is frozen for it.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumber the serial number of the NFT
   * @param ownerAccountId the ID of the account that holds the NFT
   * @param ownerAccountKey the private key of the account that holds the NFT
   * @throws HieroException if the NFT could not be rejected
   */
  void rejectNft(
      @NonNull TokenId tokenId,
      long serialNumber,
      @NonNull AccountId ownerAccountId,
      @NonNull PrivateKey ownerAccountKey)
      throws HieroException;

  /**
   * Rejects an NFT, for example an unwanted airdrop, by returning it to the treasury of the NFT
   * type. No custom fees are charged. The owner stays associated with the NFT type. Rejection fails
   * if the NFT type is paused or the owner is frozen for it.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumber the serial number of the NFT
   * @param ownerAccount the account that holds the NFT
   * @throws HieroException if the NFT could not be rejected
   */
  default void rejectNft(@NonNull TokenId tokenId, long serialNumber, @NonNull Account ownerAccount)
      throws HieroException {
    Objects.requireNonNull(ownerAccount, "ownerAccount must not be null");
    rejectNft(tokenId, serialNumber, ownerAccount.accountId(), ownerAccount.privateKey());
  }

  /**
   * Rejects NFTs, for example unwanted airdrops, by returning them to the treasury of the NFT type.
   * No custom fees are charged. The owner stays associated with the NFT type. Rejection fails if
   * the NFT type is paused or the owner is frozen for it. At most 10 NFTs can be rejected at once.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumbers the serial numbers of the NFTs
   * @param ownerAccountId the ID of the account that holds the NFTs
   * @param ownerAccountKey the private key of the account that holds the NFTs
   * @throws HieroException if the NFTs could not be rejected
   */
  void rejectNfts(
      @NonNull TokenId tokenId,
      @NonNull List<Long> serialNumbers,
      @NonNull AccountId ownerAccountId,
      @NonNull PrivateKey ownerAccountKey)
      throws HieroException;

  /**
   * Rejects NFTs, for example unwanted airdrops, by returning them to the treasury of the NFT type.
   * No custom fees are charged. The owner stays associated with the NFT type. Rejection fails if
   * the NFT type is paused or the owner is frozen for it. At most 10 NFTs can be rejected at once.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumbers the serial numbers of the NFTs
   * @param ownerAccount the account that holds the NFTs
   * @throws HieroException if the NFTs could not be rejected
   */
  default void rejectNfts(
      @NonNull TokenId tokenId, @NonNull List<Long> serialNumbers, @NonNull Account ownerAccount)
      throws HieroException {
    Objects.requireNonNull(ownerAccount, "ownerAccount must not be null");
    rejectNfts(tokenId, serialNumbers, ownerAccount.accountId(), ownerAccount.privateKey());
  }

  /**
   * Updates an NFT type (token class) name and symbol. The operator account key is used as the
   * admin key. The NFT type must have been created with that key as admin (the default for {@link
   * #createNftType} when the operator is the treasury).
   *
   * @param tokenId the ID of the NFT type to update
   * @param name the new name of the NFT type
   * @param symbol the new symbol of the NFT type
   * @throws HieroException if the NFT type could not be updated
   */
  void updateNftType(@NonNull TokenId tokenId, @NonNull String name, @NonNull String symbol)
      throws HieroException;

  /**
   * Updates an NFT type (token class) name and symbol. Must be signed by the admin key that was set
   * when the NFT type was created.
   *
   * @param tokenId the ID of the NFT type to update
   * @param name the new name of the NFT type
   * @param symbol the new symbol of the NFT type
   * @param adminKey the admin private key of the NFT type
   * @throws HieroException if the NFT type could not be updated
   */
  void updateNftType(
      @NonNull TokenId tokenId,
      @NonNull String name,
      @NonNull String symbol,
      @NonNull PrivateKey adminKey)
      throws HieroException;

  /**
   * Updates an NFT type (token class) name and symbol.
   *
   * @param tokenId the ID of the NFT type to update
   * @param name the new name of the NFT type
   * @param symbol the new symbol of the NFT type
   * @param adminKey the admin private key of the NFT type
   * @throws HieroException if the NFT type could not be updated
   */
  default void updateNftType(
      @NonNull String tokenId,
      @NonNull String name,
      @NonNull String symbol,
      @NonNull String adminKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(adminKey, "adminKey must not be null");
    updateNftType(TokenId.fromString(tokenId), name, symbol, PrivateKey.fromStringDER(adminKey));
  }

  /**
   * Updates an NFT type (token class) name and symbol. The operator account key is used as the
   * admin key.
   *
   * @param tokenId the ID of the NFT type to update
   * @param name the new name of the NFT type
   * @param symbol the new symbol of the NFT type
   * @throws HieroException if the NFT type could not be updated
   */
  default void updateNftType(@NonNull String tokenId, @NonNull String name, @NonNull String symbol)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    updateNftType(TokenId.fromString(tokenId), name, symbol);
  }

  /**
   * Updates the metadata of a single NFT serial. The operator account key is used as the metadata
   * key (or supply key while the NFT is held in treasury; see HIP-850).
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumber the serial number of the NFT
   * @param metadata the new metadata (at most 100 bytes)
   * @throws HieroException if the NFT metadata could not be updated
   */
  default void updateNftMetadata(
      @NonNull TokenId tokenId, long serialNumber, @NonNull byte[] metadata) throws HieroException {
    updateNftsMetadata(tokenId, List.of(serialNumber), metadata);
  }

  /**
   * Updates the metadata of a single NFT serial. Must be signed by the token metadata key, or by
   * the supply key while the NFT is held in the treasury (HIP-850).
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumber the serial number of the NFT
   * @param metadataKey the metadata key (or supply key for treasury-held NFTs)
   * @param metadata the new metadata (at most 100 bytes)
   * @throws HieroException if the NFT metadata could not be updated
   */
  default void updateNftMetadata(
      @NonNull TokenId tokenId,
      long serialNumber,
      @NonNull PrivateKey metadataKey,
      @NonNull byte[] metadata)
      throws HieroException {
    updateNftsMetadata(tokenId, List.of(serialNumber), metadataKey, metadata);
  }

  /**
   * Updates the metadata of NFT serials. The operator account key is used as the metadata key (or
   * supply key while the NFTs are held in treasury; see HIP-850). At most 10 serials may be updated
   * in one call.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumbers the serial numbers to update
   * @param metadata the new metadata (at most 100 bytes)
   * @throws HieroException if the NFT metadata could not be updated
   */
  void updateNftsMetadata(
      @NonNull TokenId tokenId, @NonNull List<Long> serialNumbers, @NonNull byte[] metadata)
      throws HieroException;

  /**
   * Updates the metadata of NFT serials. Must be signed by the token metadata key, or by the supply
   * key while the NFTs are held in the treasury (HIP-850). At most 10 serials may be updated in one
   * call.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumbers the serial numbers to update
   * @param metadataKey the metadata key (or supply key for treasury-held NFTs)
   * @param metadata the new metadata (at most 100 bytes)
   * @throws HieroException if the NFT metadata could not be updated
   */
  void updateNftsMetadata(
      @NonNull TokenId tokenId,
      @NonNull List<Long> serialNumbers,
      @NonNull PrivateKey metadataKey,
      @NonNull byte[] metadata)
      throws HieroException;

  /**
   * Updates the metadata of NFT serials.
   *
   * @param tokenId the ID of the NFT type
   * @param serialNumbers the serial numbers to update
   * @param metadataKey the metadata key (or supply key for treasury-held NFTs)
   * @param metadata the new metadata (at most 100 bytes)
   * @throws HieroException if the NFT metadata could not be updated
   */
  default void updateNftsMetadata(
      @NonNull String tokenId,
      @NonNull List<Long> serialNumbers,
      @NonNull String metadataKey,
      @NonNull byte[] metadata)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(metadataKey, "metadataKey must not be null");
    updateNftsMetadata(
        TokenId.fromString(tokenId),
        serialNumbers,
        PrivateKey.fromStringDER(metadataKey),
        metadata);
  }

  /**
   * Deletes an NFT type (token class). All NFTs of that type must have been burned first. The
   * operator account key is used as the admin key. The NFT type must have been created with that
   * key as admin (the default for {@link #createNftType} when the operator is the treasury).
   *
   * @param tokenId the ID of the NFT type to delete
   * @throws HieroException if the NFT type could not be deleted
   */
  void deleteNftType(@NonNull TokenId tokenId) throws HieroException;

  /**
   * Deletes an NFT type (token class). All NFTs of that type must have been burned first. Must be
   * signed by the admin key that was set when the NFT type was created.
   *
   * @param tokenId the ID of the NFT type to delete
   * @param adminKey the admin private key of the NFT type
   * @throws HieroException if the NFT type could not be deleted
   */
  void deleteNftType(@NonNull TokenId tokenId, @NonNull PrivateKey adminKey) throws HieroException;

  /**
   * Deletes an NFT type (token class). All NFTs of that type must have been burned first.
   *
   * @param tokenId the ID of the NFT type to delete
   * @param adminKey the admin private key of the NFT type
   * @throws HieroException if the NFT type could not be deleted
   */
  default void deleteNftType(@NonNull String tokenId, @NonNull String adminKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(adminKey, "adminKey must not be null");
    deleteNftType(TokenId.fromString(tokenId), PrivateKey.fromStringDER(adminKey));
  }

  default void deleteNftType(@NonNull String tokenId) throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    deleteNftType(TokenId.fromString(tokenId));
  }
}
