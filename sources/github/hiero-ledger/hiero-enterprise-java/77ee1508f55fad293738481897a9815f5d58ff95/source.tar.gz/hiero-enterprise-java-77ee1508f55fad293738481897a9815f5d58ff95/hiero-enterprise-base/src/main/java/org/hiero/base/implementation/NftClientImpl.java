package org.hiero.base.implementation;

import com.hedera.hashgraph.sdk.AccountId;
import com.hedera.hashgraph.sdk.PrivateKey;
import com.hedera.hashgraph.sdk.TokenId;
import com.hedera.hashgraph.sdk.TokenType;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import org.hiero.base.HieroException;
import org.hiero.base.NftClient;
import org.hiero.base.data.Account;
import org.hiero.base.protocol.ProtocolLayerClient;
import org.hiero.base.protocol.data.TokenAirdropRequest;
import org.hiero.base.protocol.data.TokenAssociateRequest;
import org.hiero.base.protocol.data.TokenBurnRequest;
import org.hiero.base.protocol.data.TokenBurnResult;
import org.hiero.base.protocol.data.TokenCancelAirdropRequest;
import org.hiero.base.protocol.data.TokenCreateRequest;
import org.hiero.base.protocol.data.TokenCreateResult;
import org.hiero.base.protocol.data.TokenDeleteRequest;
import org.hiero.base.protocol.data.TokenDissociateRequest;
import org.hiero.base.protocol.data.TokenFreezeRequest;
import org.hiero.base.protocol.data.TokenGrantKycRequest;
import org.hiero.base.protocol.data.TokenMintRequest;
import org.hiero.base.protocol.data.TokenMintResult;
import org.hiero.base.protocol.data.TokenRejectRequest;
import org.hiero.base.protocol.data.TokenRevokeKycRequest;
import org.hiero.base.protocol.data.TokenTransferRequest;
import org.hiero.base.protocol.data.TokenUnfreezeRequest;
import org.hiero.base.protocol.data.TokenUpdateNftsRequest;
import org.hiero.base.protocol.data.TokenUpdateRequest;
import org.hiero.base.protocol.data.TokenWipeRequest;
import org.hiero.base.protocol.data.TokenWipeResult;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

public class NftClientImpl implements NftClient {

  private final ProtocolLayerClient client;

  private final Account operationalAccount;

  public NftClientImpl(
      @NonNull final ProtocolLayerClient client, @NonNull final Account operationalAccount) {
    this.client = Objects.requireNonNull(client, "client must not be null");
    this.operationalAccount =
        Objects.requireNonNull(operationalAccount, "operationalAccount must not be null");
  }

  @Override
  public TokenId createNftType(@NonNull final String name, @NonNull final String symbol)
      throws HieroException {
    return createNftType(name, symbol, operationalAccount);
  }

  @Override
  public TokenId createNftType(
      @NonNull final String name,
      @NonNull final String symbol,
      @NonNull final PrivateKey supplierKey)
      throws HieroException {
    return createNftType(name, symbol, operationalAccount, supplierKey);
  }

  @Override
  public TokenId createNftType(
      @NonNull final String name,
      @NonNull final String symbol,
      @NonNull final AccountId treasuryAccountId,
      @NonNull final PrivateKey treasuryKey)
      throws HieroException {
    return createNftType(
        name, symbol, treasuryAccountId, treasuryKey, operationalAccount.privateKey());
  }

  @Override
  public TokenId createNftType(
      @NonNull final String name,
      @NonNull final String symbol,
      @NonNull final AccountId treasuryAccountId,
      @NonNull final PrivateKey treasuryKey,
      @NonNull final PrivateKey supplierKey)
      throws HieroException {
    final TokenCreateRequest request =
        TokenCreateRequest.of(
            name,
            symbol,
            treasuryAccountId,
            treasuryKey,
            TokenType.NON_FUNGIBLE_UNIQUE,
            supplierKey);
    final TokenCreateResult tokenCreateResult = client.executeTokenCreateTransaction(request);
    return tokenCreateResult.tokenId();
  }

  @Override
  public TokenId createNftType(
      @NonNull final String name,
      @NonNull final String symbol,
      @NonNull final PrivateKey supplierKey,
      @NonNull final PrivateKey metadataKey)
      throws HieroException {
    return createNftType(name, symbol, supplierKey, metadataKey, null);
  }

  @Override
  public TokenId createNftType(
      @NonNull final String name,
      @NonNull final String symbol,
      @NonNull final AccountId treasuryAccountId,
      @NonNull final PrivateKey treasuryKey,
      @NonNull final PrivateKey supplierKey,
      @NonNull final PrivateKey metadataKey)
      throws HieroException {
    return createNftType(
        name, symbol, treasuryAccountId, treasuryKey, supplierKey, metadataKey, null);
  }

  @Override
  public TokenId createNftType(
      @NonNull final String name,
      @NonNull final String symbol,
      @NonNull final PrivateKey supplierKey,
      @Nullable final PrivateKey metadataKey,
      @Nullable final PrivateKey kycKey)
      throws HieroException {
    return createNftType(
        name,
        symbol,
        operationalAccount.accountId(),
        operationalAccount.privateKey(),
        supplierKey,
        metadataKey,
        kycKey);
  }

  @Override
  public TokenId createNftType(
      @NonNull final String name,
      @NonNull final String symbol,
      @NonNull final AccountId treasuryAccountId,
      @NonNull final PrivateKey treasuryKey,
      @NonNull final PrivateKey supplierKey,
      @Nullable final PrivateKey metadataKey,
      @Nullable final PrivateKey kycKey)
      throws HieroException {
    final TokenCreateRequest request =
        TokenCreateRequest.of(
            name,
            symbol,
            treasuryAccountId,
            treasuryKey,
            TokenType.NON_FUNGIBLE_UNIQUE,
            supplierKey,
            metadataKey,
            null,
            null,
            kycKey);
    final TokenCreateResult tokenCreateResult = client.executeTokenCreateTransaction(request);
    return tokenCreateResult.tokenId();
  }

  @Override
  public void associateNft(
      @NonNull final TokenId tokenId,
      @NonNull final AccountId accountId,
      @NonNull final PrivateKey accountKey)
      throws HieroException {
    final TokenAssociateRequest request = TokenAssociateRequest.of(tokenId, accountId, accountKey);
    client.executeTokenAssociateTransaction(request);
  }

  @Override
  public void associateNft(
      @NonNull List<TokenId> tokenIds, @NonNull AccountId accountId, @NonNull PrivateKey accountKey)
      throws HieroException {
    Objects.requireNonNull(tokenIds, "tokenIds must not be null");
    Objects.requireNonNull(accountId, "accountId must not be null");
    Objects.requireNonNull(accountKey, "accountKey must not be null");
    if (tokenIds.isEmpty()) {
      throw new IllegalArgumentException("tokenIds must not be empty");
    }
    final TokenAssociateRequest request = TokenAssociateRequest.of(tokenIds, accountId, accountKey);
    client.executeTokenAssociateTransaction(request);
  }

  @Override
  public void dissociateNft(
      @NonNull TokenId tokenId, @NonNull AccountId accountId, @NonNull PrivateKey accountKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(accountId, "accountId must not be null");
    Objects.requireNonNull(accountKey, "accountKey must not be null");
    final TokenDissociateRequest request =
        TokenDissociateRequest.of(tokenId, accountId, accountKey);
    client.executeTokenDissociateTransaction(request);
  }

  @Override
  public void dissociateNft(
      @NonNull List<TokenId> tokenIds, @NonNull AccountId accountId, @NonNull PrivateKey accountKey)
      throws HieroException {
    Objects.requireNonNull(tokenIds, "tokenIds must not be null");
    Objects.requireNonNull(accountId, "accountId must not be null");
    Objects.requireNonNull(accountKey, "accountKey must not be null");
    if (tokenIds.isEmpty()) {
      throw new IllegalArgumentException("tokenIds must not be empty");
    }
    final TokenDissociateRequest request =
        TokenDissociateRequest.of(tokenIds, accountId, accountKey);
    client.executeTokenDissociateTransaction(request);
  }

  @Override
  public void freezeNft(@NonNull TokenId tokenId, @NonNull AccountId accountId)
      throws HieroException {
    freezeNft(tokenId, accountId, operationalAccount.privateKey());
  }

  @Override
  public void freezeNft(
      @NonNull TokenId tokenId, @NonNull AccountId accountId, @NonNull PrivateKey freezeKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(accountId, "accountId must not be null");
    Objects.requireNonNull(freezeKey, "freezeKey must not be null");
    final TokenFreezeRequest request = TokenFreezeRequest.of(tokenId, accountId, freezeKey);
    client.executeTokenFreezeTransaction(request);
  }

  @Override
  public void unfreezeNft(@NonNull TokenId tokenId, @NonNull AccountId accountId)
      throws HieroException {
    unfreezeNft(tokenId, accountId, operationalAccount.privateKey());
  }

  @Override
  public void unfreezeNft(
      @NonNull TokenId tokenId, @NonNull AccountId accountId, @NonNull PrivateKey freezeKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(accountId, "accountId must not be null");
    Objects.requireNonNull(freezeKey, "freezeKey must not be null");
    final TokenUnfreezeRequest request = TokenUnfreezeRequest.of(tokenId, accountId, freezeKey);
    client.executeTokenUnfreezeTransaction(request);
  }

  @Override
  public void grantKycNft(@NonNull TokenId tokenId, @NonNull AccountId accountId)
      throws HieroException {
    grantKycNft(tokenId, accountId, operationalAccount.privateKey());
  }

  @Override
  public void grantKycNft(
      @NonNull TokenId tokenId, @NonNull AccountId accountId, @NonNull PrivateKey kycKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(accountId, "accountId must not be null");
    Objects.requireNonNull(kycKey, "kycKey must not be null");
    final TokenGrantKycRequest request = TokenGrantKycRequest.of(tokenId, accountId, kycKey);
    client.executeTokenGrantKycTransaction(request);
  }

  @Override
  public void revokeKycNft(@NonNull TokenId tokenId, @NonNull AccountId accountId)
      throws HieroException {
    revokeKycNft(tokenId, accountId, operationalAccount.privateKey());
  }

  @Override
  public void revokeKycNft(
      @NonNull TokenId tokenId, @NonNull AccountId accountId, @NonNull PrivateKey kycKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(accountId, "accountId must not be null");
    Objects.requireNonNull(kycKey, "kycKey must not be null");
    final TokenRevokeKycRequest request = TokenRevokeKycRequest.of(tokenId, accountId, kycKey);
    client.executeTokenRevokeKycTransaction(request);
  }

  @Override
  public long mintNft(@NonNull TokenId tokenId, @NonNull byte[] metadata) throws HieroException {
    return mintNft(tokenId, operationalAccount.privateKey(), metadata);
  }

  @Override
  public long mintNft(
      @NonNull TokenId tokenId, @NonNull PrivateKey supplyKey, @NonNull byte[] metadata)
      throws HieroException {
    return mintNfts(tokenId, supplyKey, metadata).getFirst();
  }

  @Override
  public @NonNull List<Long> mintNfts(@NonNull TokenId tokenId, @NonNull byte[]... metadata)
      throws HieroException {
    return mintNfts(tokenId, operationalAccount.privateKey(), metadata);
  }

  @Override
  public @NonNull List<Long> mintNfts(
      @NonNull TokenId tokenId, @NonNull PrivateKey supplyKey, @NonNull byte[]... metadata)
      throws HieroException {
    final TokenMintRequest request = TokenMintRequest.of(tokenId, supplyKey, metadata);
    final TokenMintResult result = client.executeMintTokenTransaction(request);
    return Collections.unmodifiableList(result.serials());
  }

  @Override
  public long burnNfts(@NonNull TokenId tokenId, @NonNull Set<Long> serialNumbers)
      throws HieroException {
    return burnNfts(tokenId, serialNumbers, operationalAccount.privateKey());
  }

  @Override
  public long burnNfts(
      @NonNull TokenId tokenId, @NonNull Set<Long> serialNumbers, @NonNull PrivateKey supplyKey)
      throws HieroException {
    final TokenBurnRequest request = TokenBurnRequest.of(tokenId, serialNumbers, supplyKey);
    final TokenBurnResult result = client.executeBurnTokenTransaction(request);
    return result.totalSupply();
  }

  @Override
  public long wipeNfts(
      @NonNull TokenId tokenId, @NonNull Set<Long> serialNumbers, @NonNull AccountId accountId)
      throws HieroException {
    return wipeNfts(tokenId, serialNumbers, accountId, operationalAccount.privateKey());
  }

  @Override
  public long wipeNfts(
      @NonNull TokenId tokenId,
      @NonNull Set<Long> serialNumbers,
      @NonNull AccountId accountId,
      @NonNull PrivateKey wipeKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(serialNumbers, "serialNumbers must not be null");
    Objects.requireNonNull(accountId, "accountId must not be null");
    Objects.requireNonNull(wipeKey, "wipeKey must not be null");
    final TokenWipeRequest request =
        TokenWipeRequest.of(tokenId, accountId, serialNumbers, wipeKey);
    final TokenWipeResult result = client.executeWipeTokenTransaction(request);
    return result.totalSupply();
  }

  @Override
  public void transferNft(
      @NonNull final TokenId tokenId,
      final long serialNumber,
      @NonNull final AccountId fromAccountId,
      @NonNull final PrivateKey fromAccountKey,
      @NonNull final AccountId toAccountId)
      throws HieroException {
    transferNfts(tokenId, List.of(serialNumber), fromAccountId, fromAccountKey, toAccountId);
  }

  @Override
  public void transferNfts(
      @NonNull final TokenId tokenId,
      @NonNull final List<Long> serialNumber,
      @NonNull final AccountId fromAccountId,
      @NonNull final PrivateKey fromAccountKey,
      @NonNull final AccountId toAccountId)
      throws HieroException {
    final TokenTransferRequest request =
        TokenTransferRequest.of(tokenId, serialNumber, fromAccountId, toAccountId, fromAccountKey);
    client.executeTransferTransaction(request);
  }

  @Override
  public void airdropNft(
      @NonNull final TokenId tokenId,
      final long serialNumber,
      @NonNull final AccountId fromAccountId,
      @NonNull final PrivateKey fromAccountKey,
      @NonNull final AccountId toAccountId)
      throws HieroException {
    airdropNfts(tokenId, List.of(serialNumber), fromAccountId, fromAccountKey, toAccountId);
  }

  @Override
  public void airdropNfts(
      @NonNull final TokenId tokenId,
      @NonNull final List<Long> serialNumbers,
      @NonNull final AccountId fromAccountId,
      @NonNull final PrivateKey fromAccountKey,
      @NonNull final AccountId toAccountId)
      throws HieroException {
    Objects.requireNonNull(serialNumbers, "serialNumbers must not be null");
    Objects.requireNonNull(toAccountId, "toAccountId must not be null");
    if (serialNumbers.isEmpty()) {
      throw new IllegalArgumentException("serials must not be empty");
    }
    final Map<Long, AccountId> serialNumberToAccountId = new LinkedHashMap<>();
    for (final Long serialNumber : serialNumbers) {
      serialNumberToAccountId.put(serialNumber, toAccountId);
    }
    airdropNfts(tokenId, serialNumberToAccountId, fromAccountId, fromAccountKey);
  }

  @Override
  public void airdropNfts(
      @NonNull final TokenId tokenId,
      @NonNull final Map<Long, AccountId> serialNumberToAccountId,
      @NonNull final AccountId fromAccountId,
      @NonNull final PrivateKey fromAccountKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(serialNumberToAccountId, "serialNumberToAccountId must not be null");
    Objects.requireNonNull(fromAccountId, "fromAccountId must not be null");
    Objects.requireNonNull(fromAccountKey, "fromAccountKey must not be null");
    final TokenAirdropRequest request =
        TokenAirdropRequest.of(tokenId, serialNumberToAccountId, fromAccountId, fromAccountKey);
    client.executeTokenAirdropTransaction(request);
  }

  @Override
  public void cancelAirdropNft(
      @NonNull final TokenId tokenId,
      final long serialNumber,
      @NonNull final AccountId fromAccountId,
      @NonNull final PrivateKey fromAccountKey,
      @NonNull final AccountId toAccountId)
      throws HieroException {
    cancelAirdropNfts(tokenId, List.of(serialNumber), fromAccountId, fromAccountKey, toAccountId);
  }

  @Override
  public void cancelAirdropNfts(
      @NonNull final TokenId tokenId,
      @NonNull final List<Long> serialNumbers,
      @NonNull final AccountId fromAccountId,
      @NonNull final PrivateKey fromAccountKey,
      @NonNull final AccountId toAccountId)
      throws HieroException {
    Objects.requireNonNull(serialNumbers, "serialNumbers must not be null");
    Objects.requireNonNull(toAccountId, "toAccountId must not be null");
    if (serialNumbers.isEmpty()) {
      throw new IllegalArgumentException("serials must not be empty");
    }
    final Map<Long, AccountId> serialNumberToAccountId = new LinkedHashMap<>();
    for (final Long serialNumber : serialNumbers) {
      serialNumberToAccountId.put(serialNumber, toAccountId);
    }
    cancelAirdropNfts(tokenId, serialNumberToAccountId, fromAccountId, fromAccountKey);
  }

  @Override
  public void cancelAirdropNfts(
      @NonNull final TokenId tokenId,
      @NonNull final Map<Long, AccountId> serialNumberToAccountId,
      @NonNull final AccountId fromAccountId,
      @NonNull final PrivateKey fromAccountKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(serialNumberToAccountId, "serialNumberToAccountId must not be null");
    Objects.requireNonNull(fromAccountId, "fromAccountId must not be null");
    Objects.requireNonNull(fromAccountKey, "fromAccountKey must not be null");
    final TokenCancelAirdropRequest request =
        TokenCancelAirdropRequest.of(
            tokenId, serialNumberToAccountId, fromAccountId, fromAccountKey);
    client.executeTokenCancelAirdropTransaction(request);
  }

  @Override
  public void rejectNft(
      @NonNull final TokenId tokenId,
      final long serialNumber,
      @NonNull final AccountId ownerAccountId,
      @NonNull final PrivateKey ownerAccountKey)
      throws HieroException {
    rejectNfts(tokenId, List.of(serialNumber), ownerAccountId, ownerAccountKey);
  }

  @Override
  public void rejectNfts(
      @NonNull final TokenId tokenId,
      @NonNull final List<Long> serialNumbers,
      @NonNull final AccountId ownerAccountId,
      @NonNull final PrivateKey ownerAccountKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(serialNumbers, "serialNumbers must not be null");
    Objects.requireNonNull(ownerAccountId, "ownerAccountId must not be null");
    Objects.requireNonNull(ownerAccountKey, "ownerAccountKey must not be null");
    final TokenRejectRequest request =
        TokenRejectRequest.of(tokenId, serialNumbers, ownerAccountId, ownerAccountKey);
    client.executeTokenRejectTransaction(request);
  }

  @Override
  public void updateNftType(@NonNull TokenId tokenId, @NonNull String name, @NonNull String symbol)
      throws HieroException {
    updateNftType(tokenId, name, symbol, operationalAccount.privateKey());
  }

  @Override
  public void updateNftType(
      @NonNull TokenId tokenId,
      @NonNull String name,
      @NonNull String symbol,
      @NonNull PrivateKey adminKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(name, "name must not be null");
    Objects.requireNonNull(symbol, "symbol must not be null");
    Objects.requireNonNull(adminKey, "adminKey must not be null");
    final TokenUpdateRequest request = TokenUpdateRequest.of(tokenId, adminKey, name, symbol);
    client.executeTokenUpdateTransaction(request);
  }

  @Override
  public void updateNftsMetadata(
      @NonNull TokenId tokenId, @NonNull List<Long> serialNumbers, @NonNull byte[] metadata)
      throws HieroException {
    updateNftsMetadata(tokenId, serialNumbers, operationalAccount.privateKey(), metadata);
  }

  @Override
  public void updateNftsMetadata(
      @NonNull TokenId tokenId,
      @NonNull List<Long> serialNumbers,
      @NonNull PrivateKey metadataKey,
      @NonNull byte[] metadata)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(serialNumbers, "serialNumbers must not be null");
    Objects.requireNonNull(metadataKey, "metadataKey must not be null");
    Objects.requireNonNull(metadata, "metadata must not be null");
    final TokenUpdateNftsRequest request =
        TokenUpdateNftsRequest.of(tokenId, serialNumbers, metadata, metadataKey);
    client.executeTokenUpdateNftsTransaction(request);
  }

  @Override
  public void deleteNftType(@NonNull final TokenId tokenId) throws HieroException {
    deleteNftType(tokenId, operationalAccount.privateKey());
  }

  @Override
  public void deleteNftType(@NonNull final TokenId tokenId, @NonNull final PrivateKey adminKey)
      throws HieroException {
    Objects.requireNonNull(tokenId, "tokenId must not be null");
    Objects.requireNonNull(adminKey, "adminKey must not be null");
    final TokenDeleteRequest request = TokenDeleteRequest.of(tokenId, adminKey);
    client.executeTokenDeleteTransaction(request);
  }
}
