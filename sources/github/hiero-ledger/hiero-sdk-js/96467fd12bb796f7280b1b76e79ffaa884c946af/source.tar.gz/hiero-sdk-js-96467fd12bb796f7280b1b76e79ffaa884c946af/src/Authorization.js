// SPDX-License-Identifier: Apache-2.0

import EvmAddress from "./EvmAddress.js";
import {
    bytesOrHexToBytes,
    toMinimalBytes,
    bytesToLong,
} from "./encoding/rlpNumber.js";

/**
 * @typedef {import("long").default} Long
 */

/**
 * @typedef {[Uint8Array, Uint8Array, Uint8Array, Uint8Array, Uint8Array, Uint8Array]} AuthorizationTuple
 * - the positional `[chainId, address, nonce, yParity, r, s]` representation
 *   used on the wire / RLP encoding.
 */

/**
 * A structured, read-only view of a single EIP-7702 / HIP-1340 authorization,
 * layered over the positional `[chainId, address, nonce, yParity, r, s]` tuple
 * stored by `EthereumTransactionDataEip7702`.
 *
 * Per the cross-SDK proposal the authorization is immutable: it has no setters,
 * and is created either at construction time or from an existing tuple. The
 * envelope keeps the tuple representation as the source of truth.
 */
export default class Authorization {
    /**
     * Each argument is normalized to minimal big-endian bytes. Integer-like
     * fields accept a `number | bigint | Long | Uint8Array | string`; `address` also
     * accepts an {@link EvmAddress}.
     *
     * @param {number | bigint | Long | Uint8Array | string} chainId
     * @param {EvmAddress | Uint8Array | string} address
     * @param {number | bigint | Long | Uint8Array | string} nonce
     * @param {number | bigint | Long | Uint8Array | string} yParity
     * @param {Uint8Array | string} r
     * @param {Uint8Array | string} s
     */
    constructor(chainId, address, nonce, yParity, r, s) {
        /** @type {Uint8Array} */
        this._chainId = toMinimalBytes(chainId);
        /** @type {Uint8Array} */
        this._address =
            address instanceof EvmAddress
                ? address.toBytes()
                : bytesOrHexToBytes(address);
        /** @type {Uint8Array} */
        this._nonce = toMinimalBytes(nonce);
        /** @type {Uint8Array} */
        this._yParity = toMinimalBytes(yParity);
        /** @type {Uint8Array} */
        this._r = bytesOrHexToBytes(r);
        /** @type {Uint8Array} */
        this._s = bytesOrHexToBytes(s);
    }

    /**
     * Build an authorization from the positional
     * `[chainId, address, nonce, yParity, r, s]` tuple.
     *
     * @param {AuthorizationTuple} tuple
     * @returns {Authorization}
     */
    static fromTuple(tuple) {
        const [chainId, address, nonce, yParity, r, s] = tuple;
        return new Authorization(chainId, address, nonce, yParity, r, s);
    }

    /**
     * Convert back into the positional tuple used by the envelope's
     * `authorizationList` field.
     *
     * @returns {AuthorizationTuple}
     */
    toTuple() {
        return [
            this._chainId,
            this._address,
            this._nonce,
            this._yParity,
            this._r,
            this._s,
        ];
    }

    /**
     * @returns {Long} the chain id as an unsigned integer
     */
    getChainId() {
        return bytesToLong(this._chainId);
    }

    /**
     * @returns {Uint8Array} the raw chain id bytes
     */
    getChainIdBytes() {
        return this._chainId;
    }

    /**
     * @returns {?EvmAddress} the delegated address, or `null` when none is set
     */
    getAddress() {
        return this._address.length === 0
            ? null
            : EvmAddress.fromBytes(this._address);
    }

    /**
     * @returns {Uint8Array} the raw address bytes
     */
    getAddressBytes() {
        return this._address;
    }

    /**
     * @returns {Long} the nonce as an unsigned integer
     */
    getNonce() {
        return bytesToLong(this._nonce);
    }

    /**
     * @returns {Uint8Array} the raw nonce bytes
     */
    getNonceBytes() {
        return this._nonce;
    }

    /**
     * @returns {Long} the y-parity (recovery id) of the authorization signature
     */
    getYParity() {
        return bytesToLong(this._yParity);
    }

    /**
     * Alias of {@link getYParity}.
     *
     * @returns {Long}
     */
    getRecoveryId() {
        return this.getYParity();
    }

    /**
     * @returns {Uint8Array} the authorization signature `r` value
     */
    getR() {
        return this._r;
    }

    /**
     * @returns {Uint8Array} the authorization signature `s` value
     */
    getS() {
        return this._s;
    }
}
