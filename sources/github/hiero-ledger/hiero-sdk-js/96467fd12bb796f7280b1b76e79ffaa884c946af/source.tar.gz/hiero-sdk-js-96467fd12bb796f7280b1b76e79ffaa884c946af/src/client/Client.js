// SPDX-License-Identifier: Apache-2.0

import AccountId from "../account/AccountId.js";
import AccountInfoQuery from "../account/AccountInfoQuery.js";
import Hbar from "../Hbar.js";
import Network from "./Network.js";
import MirrorNetwork from "./MirrorNetwork.js";
import PublicKey from "../PublicKey.js";
import PrivateKey from "../PrivateKey.js";
import LedgerId from "../LedgerId.js";
import FileId from "../file/FileId.js";
import Logger from "../logger/Logger.js"; // eslint-disable-line
import { convertToNumber } from "../util.js";
import AddressBookQuery from "../network/AddressBookQuery.js";
import {
    DEFAULT_GRPC_DEADLINE,
    DEFAULT_LOCAL_MAX_ATTEMPTS,
    DEFAULT_MAX_ATTEMPTS,
    DEFAULT_REQUEST_TIMEOUT,
} from "../constants/ClientConstants.js";
import FetchHttpTransport from "../http/FetchHttpTransport.js";
import HttpTransportError, {
    HttpTransportErrorCode,
} from "../http/HttpTransportError.js";
import MirrorNodeHttpClient from "../mirror_node/MirrorNodeHttpClient.js";
import MirrorNodeHttpConfig from "../mirror_node/MirrorNodeHttpConfig.js";
import MirrorNodeHttpRetryPolicy from "../mirror_node/MirrorNodeHttpRetryPolicy.js";
import {
    isLoopbackBaseUrl,
    resolveMirrorRestBaseUrl,
} from "../mirror_node/localMirrorRestBaseUrl.js";

/**
 * Grace period `close()` gives mirror REST reads still in flight before the
 * transport the client built is torn down. Deliberately far below the
 * per-attempt read timeout: waiting out a stalled read on a shutdown path
 * is worse than aborting it.
 */
const DEFAULT_MIRROR_NODE_HTTP_CLOSE_TIMEOUT = 5 * 1000;

/**
 * @typedef {import("../channel/Channel.js").default} Channel
 * @typedef {import("../channel/MirrorChannel.js").default} MirrorChannel
 * @typedef {import("../address_book/NodeAddressBook.js").default} NodeAddressBook
 * @typedef {import("../http/HttpTransport.js").default} HttpTransport
 * @typedef {import("../http/HttpTransportConfiguration.js").default} HttpTransportConfiguration
 * @typedef {import("../mirror_node/localMirrorRestBaseUrl.js").MirrorRestEndpointFamily} MirrorRestEndpointFamily
 */

/**
 * What a mirror REST query passes when it asks the client for an adapter.
 *
 * @typedef {object} MirrorNodeHttpClientRequest
 * @property {MirrorRestEndpointFamily} [family] - the endpoint family,
 * `"rest"` by default; only matters on a local network, where the families
 * are served on different ports
 * @property {string} [baseUrl] - an explicit base URL instead of the next
 * round-robin mirror node
 * @property {?number} [maxAttempts] - per-query override of the policy field
 * @property {?number} [maxBackoff] - per-query override of the policy field
 * @property {?number} [totalDeadline] - an explicit per-call timeout in
 * milliseconds; `0`, `null` or `undefined` inherit the policy's
 * @property {?Logger} [logger]
 */

/**
 * @typedef {object} Operator
 * @property {string | PrivateKey} privateKey
 * @property {string | AccountId} accountId
 */

/**
 * @typedef {object} ClientOperator
 * @property {PublicKey} publicKey
 * @property {AccountId} accountId
 * @property {(message: Uint8Array) => Promise<Uint8Array>} transactionSigner
 */

/**
 * @typedef {object} ClientConfiguration
 * @property {{[key: string]: (string | AccountId)} | string} [network]
 * @property {string[] | string} [mirrorNetwork]
 * @property {Operator} [operator]
 * @property {boolean} [scheduleNetworkUpdate]
 * @property {number} [shard]
 * @property {number} [realm]
 * @property {number} [grpcDeadline]
 * @property {number} [requestTimeout]
 */

/**
 * @typedef {"mainnet" | "testnet" | "previewnet"} NetworkName
 */

/**
 * The `Client` class is the main entry point for interacting with the Hedera Hashgraph network.
 * It provides methods for managing network connections, setting operators, handling transactions
 * and queries, and configuring various client settings.
 *
 * @abstract
 * @template {Channel} ChannelT
 * @template {MirrorChannel} MirrorChannelT
 */
export default class Client {
    /**
     * @protected
     * @hideconstructor
     * @param {ClientConfiguration} [props]
     */
    constructor(props) {
        /**
         * List of mirror network URLs.
         *
         * @internal
         * @type {MirrorNetwork}
         */
        this._mirrorNetwork = new MirrorNetwork(
            this._createMirrorNetworkChannel(),
        );

        /**
         * Map of node account ID (as a string)
         * to the node URL.
         *
         * @internal
         * @type {Network}
         */
        this._network = new Network(this._createNetworkChannel());

        /**
         * @internal
         * @type {?ClientOperator}
         */
        this._operator = null;

        /**
         * @private
         * @type {?Hbar}
         */
        this._defaultMaxTransactionFee = null;

        /**
         * @private
         * @type {Hbar}
         */
        this._defaultMaxQueryPayment = new Hbar(1);

        if (props != null) {
            if (props.operator != null) {
                this.setOperator(
                    props.operator.accountId,
                    props.operator.privateKey,
                );
            }
        }

        /** @type {number} */
        this._maxAttempts =
            props != null && this._isLocalNetwork(props.network)
                ? DEFAULT_LOCAL_MAX_ATTEMPTS
                : DEFAULT_MAX_ATTEMPTS;

        /** @private */
        this._signOnDemand = false;

        /** @private */
        this._autoValidateChecksums = false;

        /** @private */
        this._minBackoff = 250;

        /** @private */
        this._maxBackoff = 8000;

        /** @private */
        this._defaultRegenerateTransactionId = true;

        /**
         * When enabled, allows receipt queries to fail over to other nodes
         * if the submitting node is unresponsive. Default is false to preserve
         * existing semantics where receipt queries are pinned to the submitting node.
         *
         * Tradeoff: Improved availability vs the rare case where only the submitting
         * node may have final failure information.
         *
         * @private
         */
        this._allowReceiptNodeFailover = false;

        /** @private */
        this._requestTimeout = DEFAULT_REQUEST_TIMEOUT;

        /** @private */
        this._grpcDeadline = DEFAULT_GRPC_DEADLINE;

        /**
         * @type {boolean}
         */
        this._isUpdatingNetwork = false;

        /** @private */
        this._networkUpdatePeriod = 24 * 60 * 60 * 1000;

        /** @private */
        this._isShutdown = false;

        this._shard = 0;

        this._realm = 0;

        if (props != null && props.scheduleNetworkUpdate !== false) {
            this._scheduleNetworkUpdate();
        }

        if (props != null && props.shard != null) {
            this._shard = props.shard;
        }

        if (props != null && props.realm != null) {
            this._realm = props.realm;
        }

        if (props != null && props.grpcDeadline != null) {
            this.setGrpcDeadline(props.grpcDeadline);
        }

        if (props != null && props.requestTimeout != null) {
            this.setRequestTimeout(props.requestTimeout);
        }

        // Validate that requestTimeout is larger than grpcDeadline after both are set
        if (this._requestTimeout <= this._grpcDeadline) {
            console.warn(
                `DEPRECATION WARNING: requestTimeout (${this._requestTimeout}ms) should be larger than grpcDeadline (${this._grpcDeadline}ms). ` +
                    `This configuration may cause operations to fail unexpectedly. ` +
                    `This will throw an error in the next major version. Please adjust your timeout values.`,
            );
        }

        /** @internal */
        /** @type {NodeJS.Timeout} */
        this._timer;

        /**
         * Logger
         *
         * @external
         * @type {Logger | null}
         */
        this._logger = null;

        /**
         * Everything this client holds for mirror node REST access, as
         * supplied. Never null.
         *
         * @private
         * @type {MirrorNodeHttpConfig}
         */
        this._mirrorNodeHttpConfig = new MirrorNodeHttpConfig();

        /**
         * The HTTP transport this client built for itself on the first
         * mirror REST call, and therefore owns and closes. Stays `null` while
         * no mirror REST call has been made or a transport was injected.
         *
         * @private
         * @type {?HttpTransport}
         */
        this._ownedMirrorNodeHttpTransport = null;

        /**
         * Aborted by `close()`, so a mirror REST call in progress starts no
         * new attempt and does not sleep out a backoff.
         *
         * @private
         * @type {?AbortController}
         */
        this._closeController =
            typeof AbortController !== "undefined"
                ? new AbortController()
                : null;
    }

    /**
     * @deprecated
     * @param {NetworkName} networkName
     * @returns {this}
     */
    setNetworkName(networkName) {
        // uses custom NetworkName type
        // remove if phasing out set|get NetworkName
        console.warn("Deprecated: Use `setLedgerId` instead");
        return this.setLedgerId(networkName);
    }

    /**
     * @deprecated
     * @returns {string | null}
     */
    get networkName() {
        console.warn("Deprecated: Use `ledgerId` instead");
        return this.ledgerId != null ? this.ledgerId.toString() : null;
    }

    /**
     * @param {string|LedgerId} ledgerId
     * @returns {this}
     */
    setLedgerId(ledgerId) {
        this._network.setLedgerId(
            typeof ledgerId === "string"
                ? LedgerId.fromString(ledgerId)
                : ledgerId,
        );

        return this;
    }

    /**
     * @returns {LedgerId | null}
     */
    get ledgerId() {
        return this._network._ledgerId != null ? this._network.ledgerId : null;
    }

    /**
     * @param {{[key: string]: (string | AccountId)} | string} network
     * @returns {void}
     */
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    setNetwork(network) {
        // TODO: This logic _can_ be de-duplicated and likely should
        throw new Error("not implemented");
    }

    /**
     * @param {NodeAddressBook} addressBook
     * @returns {this}
     */
    setNetworkFromAddressBook(addressBook) {
        this._network.setNetworkFromAddressBook(addressBook);
        return this;
    }

    /**
     * @returns {{[key: string]: (string | AccountId)}}
     */
    get network() {
        return this._network.network;
    }

    /**
     * @returns {number}
     */
    get shard() {
        return this._shard;
    }

    /**
     * @returns {number}
     */
    get realm() {
        return this._realm;
    }

    /**
     * @returns {boolean}
     */
    get isLocalNetwork() {
        return this._isLocalNetwork();
    }

    /**
     * @private
     * @param {{[key: string]: (string | AccountId)} | string} [network]
     * @returns {boolean}
     */
    _isLocalNetwork(network = this.network) {
        if (typeof network === "string") {
            return network === "local-node";
        }

        if (network == null) {
            return false;
        }

        return Object.keys(network).some(
            (key) => key.includes("127.0.0.1") || key.includes("localhost"),
        );
    }

    /**
     * @param {string[] | string} mirrorNetwork
     * @returns {void}
     */
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    setMirrorNetwork(mirrorNetwork) {
        throw new Error("not implemented");
    }

    /**
     * @returns {string[]}
     */
    get mirrorNetwork() {
        return this._mirrorNetwork.network;
    }

    /**
     * @returns {string}
     * @throws {Error} When no mirror network is configured or available
     */
    get mirrorRestApiBaseUrl() {
        return this._mirrorNetwork.mirrorRestApiBaseUrl;
    }

    /**
     * Replace the mirror node HTTP configuration: the transport the mirror
     * REST queries use (or `null` to let the SDK build one), how the SDK
     * builds it, the retry policy, and the caller headers.
     *
     * The whole value is replaced, not merged, so derive from the current
     * one to change a single field:
     *
     * ```javascript
     * const cfg = client.getMirrorNodeHttpConfig();
     * client.setMirrorNodeHttpConfig({
     *     ...cfg,
     *     retryPolicy: { ...cfg.retryPolicy, maxAttempts: 3 },
     * });
     * ```
     *
     * A transport set here is owned by the application and never closed by
     * the SDK; it is used from the next mirror REST call on. The
     * `transportConfiguration` applies only to a transport the SDK builds,
     * which happens once, on the first mirror REST call.
     *
     * @param {MirrorNodeHttpConfig | ConstructorParameters<typeof MirrorNodeHttpConfig>[0]} config
     * @returns {this}
     */
    setMirrorNodeHttpConfig(config) {
        this._mirrorNodeHttpConfig = MirrorNodeHttpConfig.from(config);
        return this;
    }

    /**
     * The mirror node HTTP configuration as supplied, never as resolved:
     * `transport` stays `null` even after the SDK has built its own, so
     * inspecting a client never constructs one and
     * `setMirrorNodeHttpConfig(getMirrorNodeHttpConfig())` is a no-op.
     *
     * @returns {MirrorNodeHttpConfig}
     */
    getMirrorNodeHttpConfig() {
        return this._mirrorNodeHttpConfig;
    }

    /**
     * @returns {MirrorNodeHttpConfig}
     */
    get mirrorNodeHttpConfig() {
        return this._mirrorNodeHttpConfig;
    }

    /**
     * The transport mirror REST calls go through: the injected one when the
     * configuration carries one, else the one this client built for itself,
     * built on first use.
     *
     * @internal
     * @returns {HttpTransport}
     */
    _mirrorNodeHttpTransport() {
        if (this._isShutdown) {
            throw new HttpTransportError(
                HttpTransportErrorCode.CLIENT_CLOSED_ERROR,
                "the client is closed",
            );
        }

        const injected = this._mirrorNodeHttpConfig.transport;
        if (injected != null) {
            return injected;
        }

        if (this._ownedMirrorNodeHttpTransport == null) {
            this._ownedMirrorNodeHttpTransport =
                this._createDefaultHttpTransport(
                    this._mirrorNodeHttpConfig.transportConfiguration,
                );
        }

        return this._ownedMirrorNodeHttpTransport;
    }

    /**
     * Build the transport this runtime uses when none is injected. The
     * base class builds the `fetch`-backed one; `NodeClient` overrides this
     * with the Node transport and its private connection pool.
     *
     * @protected
     * @param {HttpTransportConfiguration} configuration
     * @returns {HttpTransport}
     */
    _createDefaultHttpTransport(configuration) {
        return FetchHttpTransport.create(configuration);
    }

    /**
     * The adapter for one mirror REST call: the next round-robin mirror
     * node resolved for the endpoint family, the client's transport, and the
     * retry policy resolved as package default, then the client's policy,
     * then the query's own overrides, field by field. A `totalDeadline` of
     * `0` inherits `requestTimeout`.
     *
     * @internal
     * @param {MirrorNodeHttpClientRequest} [request]
     * @returns {MirrorNodeHttpClient}
     */
    _mirrorNodeHttpClient(request = {}) {
        // A closed client fails with `client-closed-error`, not with the
        // "no mirror network" error that clearing the network would cause.
        const transport = this._mirrorNodeHttpTransport();
        const baseUrl = resolveMirrorRestBaseUrl(
            request.baseUrl ??
                this._mirrorNetwork.nextMirrorNodeForRest()
                    .mirrorRestApiBaseUrl,
            request.family ?? "rest",
        );
        const retryPolicy = this._resolveMirrorNodeHttpRetryPolicy(
            baseUrl,
            request,
        );

        return MirrorNodeHttpClient.create(baseUrl, transport, retryPolicy, {
            requestHeaders: this._mirrorNodeHttpConfig.requestHeaders,
            closeSignal:
                this._closeController != null
                    ? this._closeController.signal
                    : null,
            logger: request.logger ?? this._logger,
        });
    }

    /**
     * @private
     * @param {string} baseUrl
     * @param {MirrorNodeHttpClientRequest} request
     * @returns {MirrorNodeHttpRetryPolicy}
     */
    _resolveMirrorNodeHttpRetryPolicy(baseUrl, request) {
        let policy = this._mirrorNodeHttpConfig.retryPolicy;

        // A mirror node still starting under a local test harness needs a
        // startup budget, not a flaky-request budget. Only the package
        // default moves; an explicit policy overrides it as anywhere else.
        // Identity, not value equality: an explicit policy that happens to
        // equal the defaults, such as `{ maxAttempts: 5 }`, is still explicit.
        if (
            policy === MirrorNodeHttpRetryPolicy.DEFAULT &&
            isLoopbackBaseUrl(baseUrl)
        ) {
            policy = MirrorNodeHttpRetryPolicy.LOCAL_DEFAULT;
        }

        /** @type {ConstructorParameters<typeof MirrorNodeHttpRetryPolicy>[0]} */
        const overrides = {};
        if (request.maxAttempts != null) {
            overrides.maxAttempts = request.maxAttempts;
        }
        if (request.maxBackoff != null) {
            overrides.maxBackoff = request.maxBackoff;
        }
        if (request.totalDeadline != null && request.totalDeadline > 0) {
            overrides.totalDeadline = request.totalDeadline;
        }
        if (Object.keys(overrides).length > 0) {
            policy = new MirrorNodeHttpRetryPolicy({ ...policy, ...overrides });
        }

        if (policy.totalDeadline === 0) {
            policy = new MirrorNodeHttpRetryPolicy({
                ...policy,
                totalDeadline: this._requestTimeout,
            });
        }

        return policy;
    }

    /**
     * @returns {boolean}
     */
    get signOnDemand() {
        return this._signOnDemand;
    }

    /**
     * @param {boolean} signOnDemand
     */
    setSignOnDemand(signOnDemand) {
        this._signOnDemand = signOnDemand;
    }

    /**
     * @returns {boolean}
     */
    isTransportSecurity() {
        return this._network.isTransportSecurity();
    }

    /**
     * @param {boolean} transportSecurity
     * @returns {this}
     */
    setTransportSecurity(transportSecurity) {
        this._network.setTransportSecurity(transportSecurity);
        return this;
    }

    /**
     * Set the account that will, by default, pay for transactions and queries built with this client.
     * NOTE: When using string for private key, the string needs to contain DER headers
     *
     * @param {AccountId | string} accountId
     * @param {PrivateKey | string} privateKey
     * @returns {this}
     */
    setOperator(accountId, privateKey) {
        const key =
            typeof privateKey === "string"
                ? PrivateKey.fromStringDer(privateKey)
                : privateKey;

        return this.setOperatorWith(accountId, key.publicKey, (message) =>
            Promise.resolve(key.sign(message)),
        );
    }

    /**
     * @returns {?ClientOperator}
     */
    getOperator() {
        return this._operator;
    }

    /**
     * Sets the account that will, by default, pay for transactions and queries built with
     * this client.
     *
     * @param {AccountId | string} accountId
     * @param {PublicKey | string} publicKey
     * @param {(message: Uint8Array) => Promise<Uint8Array>} transactionSigner
     * @returns {this}
     */
    setOperatorWith(accountId, publicKey, transactionSigner) {
        const accountId_ =
            accountId instanceof AccountId
                ? accountId
                : AccountId.fromString(accountId);

        if (this._network._ledgerId != null) {
            accountId_.validateChecksum(this);
        }

        this._operator = {
            transactionSigner,

            accountId: accountId_,

            publicKey:
                publicKey instanceof PublicKey
                    ? publicKey
                    : PublicKey.fromString(publicKey),
        };

        return this;
    }

    /**
     * @param {boolean} value
     * @returns {this}
     */
    setAutoValidateChecksums(value) {
        this._autoValidateChecksums = value;
        return this;
    }

    /**
     * @returns {boolean}
     */
    isAutoValidateChecksumsEnabled() {
        return this._autoValidateChecksums;
    }

    /**
     * @returns {?AccountId}
     */
    get operatorAccountId() {
        return this._operator != null ? this._operator.accountId : null;
    }

    /**
     * @returns {?PublicKey}
     */
    get operatorPublicKey() {
        return this._operator != null ? this._operator.publicKey : null;
    }

    /**
     * @returns {?Hbar}
     */
    get defaultMaxTransactionFee() {
        return this._defaultMaxTransactionFee;
    }

    /**
     * @deprecated - Use `defaultMaxTransactionFee` instead
     * @returns {?Hbar}
     */
    get maxTransactionFee() {
        return this.defaultMaxTransactionFee;
    }

    /**
     * Set the defaultimum fee to be paid for transactions
     * executed by this client.
     *
     * @param {Hbar} defaultMaxTransactionFee
     * @returns {this}
     */
    setDefaultMaxTransactionFee(defaultMaxTransactionFee) {
        if (defaultMaxTransactionFee.toTinybars().toInt() < 0) {
            throw new Error("defaultMaxTransactionFee must be non-negative");
        }
        this._defaultMaxTransactionFee = defaultMaxTransactionFee;
        return this;
    }

    /**
     * @deprecated - Use `setDefaultMaxTransactionFee()` instead
     * Set the maximum fee to be paid for transactions
     * executed by this client.
     * @param {Hbar} maxTransactionFee
     * @returns {this}
     */
    setMaxTransactionFee(maxTransactionFee) {
        return this.setDefaultMaxTransactionFee(maxTransactionFee);
    }

    /**
     * @returns {boolean}
     */
    get defaultRegenerateTransactionId() {
        return this._defaultRegenerateTransactionId;
    }

    /**
     * Set if a new transaction ID should be generated when a `TRANSACTION_EXPIRED` status
     * is returned.
     *
     * @param {boolean} defaultRegenerateTransactionId
     * @returns {this}
     */
    setDefaultRegenerateTransactionId(defaultRegenerateTransactionId) {
        this._defaultRegenerateTransactionId = defaultRegenerateTransactionId;
        return this;
    }

    /**
     * @returns {boolean}
     */
    get allowReceiptNodeFailover() {
        return this._allowReceiptNodeFailover;
    }

    /**
     * Enable or disable receipt query failover to other nodes when the submitting node
     * is unresponsive. When enabled, receipt queries will start with the submitting node
     * but can fail over to other nodes in the network if needed.
     *
     * Default is `false` to preserve existing behavior where receipt queries are pinned
     * to the submitting node only.
     *
     * **Tradeoff**: Enabling this improves availability for high-throughput/relay use cases,
     * but in rare cases only the submitting node may have the final failure information.
     *
     * @param {boolean} allowReceiptNodeFailover
     * @returns {this}
     */
    setAllowReceiptNodeFailover(allowReceiptNodeFailover) {
        this._allowReceiptNodeFailover = allowReceiptNodeFailover;
        return this;
    }

    /**
     * @returns {Hbar}
     */
    get defaultMaxQueryPayment() {
        return this._defaultMaxQueryPayment;
    }

    /**
     * @deprecated in a favor of defaultMaxQueryPayment
     * @returns {Hbar}
     */
    get maxQueryPayment() {
        return this.defaultMaxQueryPayment;
    }

    /**
     * Set the maximum payment allowable for queries.
     *
     * @param {Hbar} defaultMaxQueryPayment
     * @returns {Client<ChannelT, MirrorChannelT>}
     */
    setDefaultMaxQueryPayment(defaultMaxQueryPayment) {
        const isMaxQueryPaymentNegative =
            convertToNumber(defaultMaxQueryPayment.toTinybars()) < 0;
        if (isMaxQueryPaymentNegative) {
            throw new Error("defaultMaxQueryPayment must be non-negative");
        }
        this._defaultMaxQueryPayment = defaultMaxQueryPayment;
        return this;
    }
    /**
     * @deprecated in a favor of setDefaultMaxQueryPayment()
     * Set the maximum payment allowable for queries.
     * @param {Hbar} maxQueryPayment
     * @returns {Client<ChannelT, MirrorChannelT>}
     */
    setMaxQueryPayment(maxQueryPayment) {
        return this.setDefaultMaxQueryPayment(maxQueryPayment);
    }

    /**
     * @returns {number}
     */
    get maxAttempts() {
        return this._maxAttempts;
    }

    /**
     * @param {number} maxAttempts
     * @returns {this}
     */
    setMaxAttempts(maxAttempts) {
        this._maxAttempts = maxAttempts;
        return this;
    }

    /**
     * @returns {number}
     */
    get maxNodeAttempts() {
        return this._network.maxNodeAttempts;
    }

    /**
     * @param {number} maxNodeAttempts
     * @returns {this}
     */
    setMaxNodeAttempts(maxNodeAttempts) {
        this._network.setMaxNodeAttempts(maxNodeAttempts);
        return this;
    }

    /**
     * @returns {number}
     */
    get nodeWaitTime() {
        return this._network.minBackoff;
    }

    /**
     * @param {number} nodeWaitTime
     * @returns {this}
     */
    setNodeWaitTime(nodeWaitTime) {
        this._network.setMinBackoff(nodeWaitTime);
        return this;
    }

    /**
     * Gets the maximum number of nodes that a transaction or query will attempt to execute against.
     *
     * @returns {number} The current maximum nodes per transaction setting.
     *   Returns -1 if no limit is set (uses network defaults).
     */
    get maxNodesPerTransaction() {
        return this._network.maxNodesPerTransaction;
    }

    /**
     * Sets the maximum number of nodes that a transaction or query will execute against.
     *
     * - **Before freezing**: Limits automatic node selection when no explicit nodes are set
     * - **After freezing**: Trims frozen transactions to the first N nodes while preserving signatures
     * - **Special values**: 0 disables limiting, values > available nodes cause no trimming
     *
     * @param {number} maxNodesPerTransaction - Maximum nodes per transaction. Set to 0 to disable.
     * @returns {this} The client instance for method chaining
     */
    setMaxNodesPerTransaction(maxNodesPerTransaction) {
        this._network.setMaxNodesPerTransaction(maxNodesPerTransaction);
        return this;
    }

    /**
     * @param {?number} minBackoff
     * @returns {this}
     */
    setMinBackoff(minBackoff) {
        if (minBackoff == null) {
            throw new Error("minBackoff cannot be null.");
        }
        if (minBackoff > this._maxBackoff) {
            throw new Error("minBackoff cannot be larger than maxBackoff.");
        }
        this._minBackoff = minBackoff;
        return this;
    }

    /**
     * @returns {number}
     */
    get minBackoff() {
        return this._minBackoff;
    }

    /**
     * @param {?number} maxBackoff
     * @returns {this}
     */
    setMaxBackoff(maxBackoff) {
        if (maxBackoff == null) {
            throw new Error("maxBackoff cannot be null.");
        } else if (maxBackoff < this._minBackoff) {
            throw new Error("maxBackoff cannot be smaller than minBackoff.");
        }
        this._maxBackoff = maxBackoff;
        return this;
    }

    /**
     * @returns {number}
     */
    get maxBackoff() {
        return this._maxBackoff;
    }

    /**
     * @param {number} nodeMinBackoff
     * @returns {this}
     */
    setNodeMinBackoff(nodeMinBackoff) {
        this._network.setMinBackoff(nodeMinBackoff);
        return this;
    }

    /**
     * @returns {number}
     */
    get nodeMinBackoff() {
        return this._network.minBackoff;
    }

    /**
     * @param {number} nodeMaxBackoff
     * @returns {this}
     */
    setNodeMaxBackoff(nodeMaxBackoff) {
        this._network.setMaxBackoff(nodeMaxBackoff);
        return this;
    }

    /**
     * @returns {number}
     */
    get nodeMaxBackoff() {
        return this._network.maxBackoff;
    }

    /**
     * @param {number} nodeMinReadmitPeriod
     * @returns {this}
     */
    setNodeMinReadmitPeriod(nodeMinReadmitPeriod) {
        this._network.setNodeMinReadmitPeriod(nodeMinReadmitPeriod);
        return this;
    }

    /**
     * @returns {number}
     */
    get nodeMinReadmitPeriod() {
        return this._network.nodeMinReadmitPeriod;
    }

    /**
     * @param {number} nodeMaxReadmitPeriod
     * @returns {this}
     */
    setNodeMaxReadmitPeriod(nodeMaxReadmitPeriod) {
        this._network.setNodeMaxReadmitPeriod(nodeMaxReadmitPeriod);
        return this;
    }

    /**
     * @returns {number}
     */
    get nodeMaxReadmitPeriod() {
        return this._network.nodeMaxReadmitPeriod;
    }

    /**
     * Set the total request timeout for complete operations.
     *
     * @param {number} requestTimeout - Maximum time in milliseconds for complete Transaction/Query operations
     * @returns {this}
     */
    setRequestTimeout(requestTimeout) {
        if (requestTimeout <= 0) {
            throw new Error("requestTimeout must be a positive number");
        }
        if (requestTimeout <= this._grpcDeadline) {
            console.warn(
                `DEPRECATION WARNING: requestTimeout (${requestTimeout}ms) should be larger than grpcDeadline (${this._grpcDeadline}ms). ` +
                    `This configuration may cause operations to fail unexpectedly. ` +
                    `This will throw an error in the next major version. Please adjust your timeout values.`,
            );
        }
        this._requestTimeout = requestTimeout;
        return this;
    }

    /**
     * Get the total request timeout for complete operations.
     *
     * @returns {number} Maximum time in milliseconds for complete Transaction/Query operations
     */
    get requestTimeout() {
        return this._requestTimeout;
    }

    /**
     * Set the global gRPC deadline for all requests.
     *
     * @param {number} grpcDeadline - Maximum time in milliseconds for a single gRPC request
     * @returns {this}
     */
    setGrpcDeadline(grpcDeadline) {
        if (grpcDeadline <= 0) {
            throw new Error("grpcDeadline must be a positive number");
        }
        if (grpcDeadline >= this._requestTimeout) {
            console.warn(
                `DEPRECATION WARNING: grpcDeadline (${grpcDeadline}ms) should be smaller than requestTimeout (${this._requestTimeout}ms). ` +
                    `This configuration may cause operations to fail unexpectedly. ` +
                    `This will throw an error in the next major version. Please adjust your timeout values.`,
            );
        }
        this._grpcDeadline = grpcDeadline;
        return this;
    }

    /**
     * Get the global gRPC deadline for all requests.
     *
     * @returns {number} Maximum time in milliseconds for a single gRPC request
     */
    get grpcDeadline() {
        return this._grpcDeadline;
    }

    /**
     * @returns {number}
     */
    get networkUpdatePeriod() {
        return this._networkUpdatePeriod;
    }

    /**
     * @param {number} networkUpdatePeriod
     * @returns {this}
     */
    setNetworkUpdatePeriod(networkUpdatePeriod) {
        clearTimeout(this._timer);
        this._networkUpdatePeriod = networkUpdatePeriod;
        this._scheduleNetworkUpdate();
        return this;
    }
    /**
     * Set logger
     *
     * @param {Logger} logger
     * @returns {this}
     */
    setLogger(logger) {
        this._logger = logger;
        return this;
    }

    /**
     * Get logger if set
     *
     * @returns {?Logger}
     */
    get logger() {
        return this._logger;
    }

    /**
     * Probe the liveness of the node with the given account ID by sending a
     * `CryptoService/getAccountInfo` query for account `<shard>.<realm>.2`
     * with `ResponseType = COST_ANSWER` — the node answers with the query fee
     * without executing the query, so no HBAR is charged and no operator is
     * required. A cost response means success; a gRPC failure propagates.
     *
     * @param {AccountId | string} accountId
     */
    async ping(accountId) {
        await new AccountInfoQuery()
            .setAccountId(new AccountId(this._shard, this._realm, 2))
            .setNodeAccountIds([
                accountId instanceof AccountId
                    ? accountId
                    : AccountId.fromString(accountId),
            ])
            .getCost(this);
    }

    async pingAll() {
        for (const nodeAccountId of Object.values(this._network.network)) {
            await this.ping(nodeAccountId);
        }
    }

    /**
     * Update the network address book.
     * @returns {Promise<this>}
     */
    async updateNetwork() {
        if (this._isUpdatingNetwork) {
            return this;
        }

        this._isUpdatingNetwork = true;

        try {
            const addressBook = await new AddressBookQuery()
                .setFileId(
                    FileId.getAddressBookFileIdFor(this._shard, this._realm),
                )
                .execute(this);
            this.setNetworkFromAddressBook(addressBook);
        } catch (error) {
            if (this._logger) {
                this._logger.trace(
                    `failed to update client address book: ${
                        /** @type {Error} */ (error).toString()
                    }`,
                );
            }
        } finally {
            this._isUpdatingNetwork = false;
        }

        return this;
    }

    /**
     * Close the client: the consensus and mirror gRPC channels, the
     * scheduled network update, and the mirror HTTP transport this client
     * built for itself, which is given a 5 s grace period for reads in
     * flight before being torn down. A transport the application injected
     * is never closed. Mirror REST calls still running start no new
     * attempt.
     *
     * @returns {void}
     */
    close() {
        this._network.close();
        this._mirrorNetwork.close();
        this._isShutdown = true;
        clearTimeout(this._timer);

        if (this._closeController != null) {
            this._closeController.abort(
                new HttpTransportError(
                    HttpTransportErrorCode.CLIENT_CLOSED_ERROR,
                    "the client is closed",
                ),
            );
        }

        const owned = this._ownedMirrorNodeHttpTransport;
        if (owned != null) {
            this._ownedMirrorNodeHttpTransport = null;
            // The drain is asynchronous and deliberately not awaited:
            // `close()` has always been synchronous.
            const result = owned.close(DEFAULT_MIRROR_NODE_HTTP_CLOSE_TIMEOUT);
            if (result != null && typeof result.catch === "function") {
                result.catch(() => {});
            }
        }
    }

    /**
     * @abstract
     * @returns {(address: string) => ChannelT}
     */
    _createNetworkChannel() {
        return () => {
            throw new Error("not implemented");
        };
    }

    /**
     * @abstract
     * @returns {(address: string) => MirrorChannelT}
     */
    _createMirrorNetworkChannel() {
        return () => {
            throw new Error("not implemented");
        };
    }

    /**
     * @private
     */
    _scheduleNetworkUpdate() {
        // This is the automatic network update promise that _eventually_ completes
        // eslint-disable-next-line @typescript-eslint/no-misused-promises
        this._timer = setTimeout(async () => {
            await this.updateNetwork();

            if (!this._isShutdown) {
                // Recall this method to continuously update the network
                // every `networkUpdatePeriod` amount of itme
                this._scheduleNetworkUpdate();
            }
        }, this._networkUpdatePeriod);
    }

    /**
     * @returns {boolean}
     */
    get isClientShutDown() {
        return this._isShutdown;
    }

    /**
     * Validates that all nodes in a network are in the same shard and realm.
     *
     * @param {{[key: string]: (string | AccountId)}} network
     */
    static _validateNetworkConsistency(network) {
        if (Object.keys(network).length === 0) {
            return;
        }

        const [, nodeAccountId] = Object.entries(network)[0];

        const accountIdStr = nodeAccountId.toString();

        const [firstNodeShard, firstNodeRealm] = accountIdStr
            .split(".")
            .map(Number);

        const isNetworkValid = Object.values(network).every((accountId) => {
            const accountIdStr = accountId.toString();

            const [currentShard, currentRealm] = accountIdStr
                .split(".")
                .map(Number);
            return (
                currentShard === firstNodeShard &&
                currentRealm === firstNodeRealm
            );
        });

        if (!isNetworkValid) {
            throw new Error(
                "Network is not valid, all nodes must be in the same shard and realm",
            );
        }
    }

    /**
     * Extracts shard and realm values from a network configuration.
     * Note: This method assumes the network is consistent (all nodes in same shard/realm).
     * Use validateNetworkConsistency() first to ensure this.
     *
     * @param {{[key: string]: (string | AccountId)}} network
     * @returns {{shard: number, realm: number}}
     */
    static _extractShardRealm(network) {
        const entries = Object.entries(network);
        if (entries.length === 0) {
            return { shard: 0, realm: 0 };
        }

        const [, firstNodeAccountId] = entries[0];

        const accountIdStr = firstNodeAccountId.toString();
        const [shard, realm] = accountIdStr.split(".").map(Number);

        return { shard, realm };
    }
}
