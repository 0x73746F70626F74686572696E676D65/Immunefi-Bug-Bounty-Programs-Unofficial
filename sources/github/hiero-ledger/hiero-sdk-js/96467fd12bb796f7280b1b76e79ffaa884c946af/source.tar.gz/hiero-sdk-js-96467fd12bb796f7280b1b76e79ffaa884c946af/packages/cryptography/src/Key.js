export default class Key {}
