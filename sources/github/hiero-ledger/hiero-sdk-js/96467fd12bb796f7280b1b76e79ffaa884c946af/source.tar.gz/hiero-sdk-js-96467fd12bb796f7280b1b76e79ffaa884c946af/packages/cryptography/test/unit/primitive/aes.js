import * as hex from "../../../src/encoding/hex.js";
import {
    CipherAlgorithm,
    createCipheriv,
    createDecipheriv,
    messageDigest,
} from "../../../src/primitive/aes.js";

// Single isomorphic AES implementation (@noble/ciphers) — runs in node and browser.
describe("AES", function () {
    const testKey = new Uint8Array(16).fill(1);
    const testIv = new Uint8Array(16).fill(2);
    const testData = new Uint8Array([3, 4, 5, 6, 7, 8, 9, 10]);
    let encryptedCTR;
    let encryptedCBC;

    beforeEach(async function () {
        encryptedCTR = await createCipheriv(
            CipherAlgorithm.Aes128Ctr,
            testKey,
            testIv,
            testData,
        );

        encryptedCBC = await createCipheriv(
            CipherAlgorithm.Aes128Cbc,
            testKey,
            testIv,
            testData,
        );
    });

    // Known-answer vectors produced by node's `crypto.createCipheriv` /
    // `createHash("md5")`, the implementation @noble/ciphers replaced. Round-trip
    // tests alone would not catch a change in padding, key handling or byte
    // order — these pin the wire format that existing keystores and encrypted
    // PEMs depend on.
    describe("known-answer vectors (node crypto parity)", function () {
        it("matches AES-128-CTR", async function () {
            const result = await createCipheriv(
                CipherAlgorithm.Aes128Ctr,
                testKey,
                testIv,
                testData,
            );

            expect(hex.encode(result)).to.equal("14d211f57ea13c9a");
        });

        it("matches AES-128-CBC, including PKCS#7 padding", async function () {
            const result = await createCipheriv(
                CipherAlgorithm.Aes128Cbc,
                testKey,
                testIv,
                testData,
            );

            // 8 bytes of plaintext pad out to one 16-byte block
            expect(hex.encode(result)).to.equal(
                "72b2c56c3db0a46495c3a7565397ceb6",
            );
        });

        it("matches the OpenSSL MD5(passphrase || iv[0:8]) key derivation", async function () {
            const result = await messageDigest(
                "testPassphrase",
                hex.encode(testIv),
            );

            expect(hex.encode(result)).to.equal(
                "fa445ea03cc9a19636ce9948d0b8d983",
            );
        });
    });

    describe("createCipheriv", function () {
        it("should encrypt data using AES-128-CTR (deterministic)", async function () {
            const result = await createCipheriv(
                CipherAlgorithm.Aes128Ctr,
                testKey,
                testIv,
                testData,
            );

            expect(result).to.be.an.instanceOf(Uint8Array);
            expect(result.length).to.be.greaterThan(0);

            const result2 = await createCipheriv(
                CipherAlgorithm.Aes128Ctr,
                testKey,
                testIv,
                testData,
            );
            expect(hex.encode(result)).to.equal(hex.encode(result2));
        });

        it("should encrypt data using AES-128-CBC", async function () {
            const result = await createCipheriv(
                CipherAlgorithm.Aes128Cbc,
                testKey,
                testIv,
                testData,
            );

            expect(result).to.be.an.instanceOf(Uint8Array);
            expect(result.length).to.be.greaterThan(0);
        });

        it("should throw an error for unsupported algorithm", async function () {
            try {
                await createCipheriv(
                    "UNSUPPORTED-ALGORITHM",
                    testKey,
                    testIv,
                    testData,
                );
                expect.fail("Should have thrown an error");
            } catch (error) {
                expect(error.message).to.include(
                    "non-exhaustive switch statement",
                );
            }
        });

        it("should use only the first 16 bytes of key", async function () {
            const longKey = new Uint8Array(32).fill(1);
            longKey[16] = 99; // This shouldn't affect the result

            const result1 = await createCipheriv(
                CipherAlgorithm.Aes128Ctr,
                testKey,
                testIv,
                testData,
            );

            const result2 = await createCipheriv(
                CipherAlgorithm.Aes128Ctr,
                longKey,
                testIv,
                testData,
            );

            expect(hex.encode(result1)).to.equal(hex.encode(result2));
        });
    });

    describe("createDecipheriv", function () {
        it("should decrypt data encrypted with AES-128-CTR", async function () {
            const decrypted = await createDecipheriv(
                CipherAlgorithm.Aes128Ctr,
                testKey,
                testIv,
                encryptedCTR,
            );

            expect(decrypted).to.be.an.instanceOf(Uint8Array);
            expect(hex.encode(decrypted)).to.equal(hex.encode(testData));
        });

        it("should decrypt data encrypted with AES-128-CBC", async function () {
            const decrypted = await createDecipheriv(
                CipherAlgorithm.Aes128Cbc,
                testKey,
                testIv,
                encryptedCBC,
            );

            expect(decrypted).to.be.an.instanceOf(Uint8Array);
            expect(hex.encode(decrypted)).to.equal(hex.encode(testData));
        });

        it("should throw an error for unsupported algorithm", async function () {
            try {
                await createDecipheriv(
                    "UNSUPPORTED-ALGORITHM",
                    testKey,
                    testIv,
                    encryptedCTR,
                );
                expect.fail("Should have thrown an error");
            } catch (error) {
                expect(error.message).to.include(
                    "non-exhaustive switch statement",
                );
            }
        });
    });

    describe("messageDigest", function () {
        it("should be deterministic with same inputs", async function () {
            const passphrase = "testPassphrase";
            const iv = hex.encode(testIv);

            const result1 = await messageDigest(passphrase, iv);
            const result2 = await messageDigest(passphrase, iv);

            expect(result1).to.be.an.instanceOf(Uint8Array);
            expect(hex.encode(result1)).to.equal(hex.encode(result2));
        });

        it("should only use the first 8 bytes of the decoded IV", async function () {
            const passphrase = "testPassphrase";
            const iv1 = hex.encode(testIv);

            const testIv2 = new Uint8Array(16).fill(2);
            testIv2[8] = 99; // beyond the first 8 bytes — must not affect the result
            const iv2 = hex.encode(testIv2);

            const result1 = await messageDigest(passphrase, iv1);
            const result2 = await messageDigest(passphrase, iv2);

            expect(hex.encode(result1)).to.equal(hex.encode(result2));
        });
    });

    describe("Encryption and Decryption Round Trip", function () {
        it("should round-trip data with AES-128-CTR", async function () {
            const encrypted = await createCipheriv(
                CipherAlgorithm.Aes128Ctr,
                testKey,
                testIv,
                testData,
            );
            const decrypted = await createDecipheriv(
                CipherAlgorithm.Aes128Ctr,
                testKey,
                testIv,
                encrypted,
            );

            expect(hex.encode(decrypted)).to.equal(hex.encode(testData));
        });

        it("should round-trip data with AES-128-CBC", async function () {
            const encrypted = await createCipheriv(
                CipherAlgorithm.Aes128Cbc,
                testKey,
                testIv,
                testData,
            );
            const decrypted = await createDecipheriv(
                CipherAlgorithm.Aes128Cbc,
                testKey,
                testIv,
                encrypted,
            );

            expect(hex.encode(decrypted)).to.equal(hex.encode(testData));
        });
    });
});
