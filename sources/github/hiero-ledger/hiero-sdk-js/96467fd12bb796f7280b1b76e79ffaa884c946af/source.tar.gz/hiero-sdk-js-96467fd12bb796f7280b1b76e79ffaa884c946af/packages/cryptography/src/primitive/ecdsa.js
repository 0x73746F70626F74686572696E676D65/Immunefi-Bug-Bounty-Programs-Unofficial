import { keccak256 } from "./keccak.js";
import * as hex from "../encoding/hex.js";
import { secp256k1 } from "@noble/curves/secp256k1.js";
import { equalBytes } from "./utils.js";

/**
 * @typedef {import("../EcdsaPrivateKey.js").KeyPair} KeyPair
 */

/**
 * @returns {KeyPair}
 */
export function generate() {
    const privateKey = secp256k1.utils.randomSecretKey();
    const publicKey = secp256k1.getPublicKey(privateKey, true);

    return {
        privateKey,
        publicKey,
    };
}

/**
 * @returns {Promise<KeyPair>}
 */

/**
 *
 */
export async function generateAsync() {
    return Promise.resolve(generate());
}

/**
 * @param {Uint8Array} data
 * @returns {KeyPair}
 */

/**
 *
 * @param data
 */
export function fromBytes(data) {
    const privateKey = new Uint8Array(data);
    const publicKey = secp256k1.getPublicKey(privateKey, true);

    return {
        privateKey: privateKey,
        publicKey: publicKey,
    };
}

/**
 * @param {Uint8Array} data
 * @returns {Uint8Array}
 */

/**
 *
 * @param data
 */
export function getFullPublicKey(data) {
    return secp256k1.getPublicKey(data, false);
}

/**
 * @param {Uint8Array} keydata
 * @param {Uint8Array} message
 * @returns {Uint8Array}
 */

/**
 *
 * @param keydata
 * @param message
 */
export function sign(keydata, message) {
    const msg = hex.encode(message);
    const data = hex.decode(keccak256(`0x${msg}`));

    // `data` is already a keccak256 digest, so noble must not hash it again
    // (v2 defaults to prehash: true, i.e. sha256 of the input).
    return secp256k1.sign(data, keydata, { prehash: false });
}

/**
 * @param {Uint8Array} keydata
 * @param {Uint8Array} message
 * @param {Uint8Array} signature
 * @returns {boolean}
 */

/**
 *
 * @param keydata
 * @param message
 * @param signature
 */
export function verify(keydata, message, signature) {
    const msg = hex.encode(message);
    const data = hex.decode(keccak256(`0x${msg}`));

    // Accept a 65-byte recoverable signature (r || s || v) by verifying its
    // 64-byte r||s prefix, as the pre-@noble-v2 implementation did.
    const sig = signature.length === 65 ? signature.subarray(0, 64) : signature;

    try {
        return secp256k1.verify(sig, data, keydata, { prehash: false });
    } catch {
        // noble v2 throws on malformed signature bytes (e.g. wrong length)
        // where the previous implementation returned false; signatures are
        // untrusted input, so keep the boolean contract.
        return false;
    }
}

/**
 * @param {Uint8Array} privateKey
 * @param {Uint8Array} signature - 64-byte compact signature (r || s)
 * @param {Uint8Array} message - Original message (not hashed)
 * @returns {number} Recovery ID (0–3), or -1
 */
export function getRecoveryId(privateKey, signature, message) {
    const expectedPubKey = secp256k1.getPublicKey(privateKey, false);
    const hash = hex.decode(keccak256(`0x${hex.encode(message)}`));

    for (let recovery = 0; recovery < 4; recovery++) {
        try {
            const sig = secp256k1.Signature.fromBytes(
                signature,
                "compact",
            ).addRecoveryBit(recovery);

            const recovered = sig.recoverPublicKey(hash).toBytes(false);

            if (equalBytes(recovered, expectedPubKey)) {
                return recovery;
            }
        } catch {
            // Ignore invalid recoveries
        }
    }

    throw new Error("Unexpected error: could not construct a recoverable key.");
}
