import {
    MirrorNodeAccountBalanceQuery,
    AccountId,
    PrivateKey,
    Hbar,
    AccountCreateTransaction,
    AccountDeleteTransaction,
    TransferTransaction,
    Transaction,
    Status,
} from "@hiero-ledger/sdk";
import { retryOnStatus, untilMirror } from "../wait-for-mirror.js";

import dotenv from "dotenv";
import { clientForName } from "../client.js";

dotenv.config();

/**
 * How to transfer Hbar to an account with the receiver signature enabled.
 *
 * Demonstrates two-party signing across a byte serialization boundary:
 * the user signs locally, sends the bytes to an "exchange" (simulated in
 * this example by just calling Transaction.fromBytes / sign / toBytes),
 * and the operator submits the doubly-signed transaction.
 */
async function main() {
    if (
        process.env.OPERATOR_ID == null ||
        process.env.OPERATOR_KEY == null ||
        process.env.HEDERA_NETWORK == null
    ) {
        throw new Error(
            "Environment variables OPERATOR_ID, OPERATOR_KEY, and HEDERA_NETWORK are required.",
        );
    }

    console.log("MultiApp Transfer Example Start!");

    const operatorId = AccountId.fromString(process.env.OPERATOR_ID);
    const operatorKey = PrivateKey.fromStringDer(process.env.OPERATOR_KEY);
    const client = clientForName(process.env.HEDERA_NETWORK).setOperator(
        operatorId,
        operatorKey,
    );

    // Step 1: Generate ECDSA key pairs.
    // The exchange should possess this key — we generate it here for demo only.
    const exchangePrivateKey = PrivateKey.generateECDSA();
    const exchangePublicKey = exchangePrivateKey.publicKey;

    // The user's key — the only key we should actually possess in real life.
    const userPrivateKey = PrivateKey.generateECDSA();
    const userPublicKey = userPrivateKey.publicKey;

    // Step 2: Create exchange and user accounts.
    console.log("Creating exchange and receiver accounts...");

    // The exchange creates an account that requires its signature on inbound
    // transfers (validated through some side channel like a REST API).
    const exchangeCreateTx = new AccountCreateTransaction()
        .setReceiverSignatureRequired(true)
        .setKeyWithoutAlias(exchangePublicKey)
        .freezeWith(client);
    const exchangeSigned = await exchangeCreateTx.sign(exchangePrivateKey);
    const exchangeAccountId = (
        await (await exchangeSigned.execute(client)).getReceipt(client)
    ).accountId;

    // The user account — operator's signature is implicit (operator pays the fee),
    // user's public key controls the account.
    const userAccountId = (
        await (
            await new AccountCreateTransaction()
                .setInitialBalance(new Hbar(2))
                .setKeyWithoutAlias(userPublicKey)
                .execute(client)
        ).getReceipt(client)
    ).accountId;

    const senderBalanceBefore = await hbarBalance(
        client,
        userAccountId,
        undefined,
        true,
    );
    const exchangeBalanceBefore = await hbarBalance(
        client,
        exchangeAccountId,
        undefined,
        true,
    );
    console.log(
        `User account (${userAccountId.toString()}) balance: ${senderBalanceBefore.toString()}`,
    );
    console.log(
        `Exchange account (${exchangeAccountId.toString()}) balance: ${exchangeBalanceBefore.toString()}`,
    );

    // Step 3: Build the transfer; sign with the user; serialize; "send to exchange".
    const transferAmount = new Hbar(1);
    const transferTx = await new TransferTransaction()
        .addHbarTransfer(userAccountId, transferAmount.negated())
        .addHbarTransfer(exchangeAccountId, transferAmount)
        // The exchange-provided memo required to validate the transaction.
        .setTransactionMemo("https://some-exchange.com/user1/account1")
        .freezeWith(client)
        .sign(userPrivateKey);

    // The exchange must sign the transaction in order for it to be accepted by
    // the network. In real life this would be a REST call to the exchange API.
    const userSignedBytes = transferTx.toBytes();
    console.log(
        "Sending user-signed transaction bytes to exchange for countersignature...",
    );
    const exchangeSignedTx =
        await Transaction.fromBytes(userSignedBytes).sign(exchangePrivateKey);
    const finalSignedBytes = exchangeSignedTx.toBytes();
    console.log("Exchange countersigned; received bytes back.");

    // Parse the bytes returned from the exchange and execute.
    const finalTx = Transaction.fromBytes(finalSignedBytes);
    console.log(
        `Transferring ${transferAmount.toString()} from the user account to the exchange account...`,
    );

    const transferResponse = await finalTx.execute(client);
    await transferResponse.getReceipt(client);

    const senderBalance = await hbarBalance(
        client,
        userAccountId,
        senderBalanceBefore,
    );

    const exchangeBalance = await hbarBalance(
        client,
        exchangeAccountId,
        exchangeBalanceBefore,
    );
    console.log(
        `User account (${userAccountId.toString()}) balance: ${senderBalance.toString()}`,
    );

    console.log(
        `Exchange account (${exchangeAccountId.toString()}) balance: ${exchangeBalance.toString()}`,
    );

    // Cleanup: delete both accounts, returning balances to the operator.
    const exchangeDeleteTx = new AccountDeleteTransaction()
        .setAccountId(exchangeAccountId)
        .setTransferAccountId(operatorId)
        .freezeWith(client);
    const exchangeDeleteSigned =
        await exchangeDeleteTx.sign(exchangePrivateKey);
    await (await exchangeDeleteSigned.execute(client)).getReceipt(client);

    const userDeleteTx = new AccountDeleteTransaction()
        .setAccountId(userAccountId)
        .setTransferAccountId(operatorId)
        .freezeWith(client);
    const userDeleteSigned = await userDeleteTx.sign(userPrivateKey);
    await (await userDeleteSigned.execute(client)).getReceipt(client);

    client.close();

    console.log("MultiApp Transfer Example Complete!");
}

void main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });

/**
 * Read an HBAR balance from the mirror node.
 *
 * The mirror node ingests consensus state asynchronously, so a read straight
 * after a transaction can still return the previous value. Pass `previous` to
 * poll until the value moves; the loop is bounded so an example cannot hang.
 *
 * @param {import("@hiero-ledger/sdk").Client} client
 * @param {import("@hiero-ledger/sdk").AccountId | string} accountId
 * @param {import("@hiero-ledger/sdk").Hbar} [previous]
 * @param {boolean} [retryMissing]
 * @returns {Promise<import("@hiero-ledger/sdk").Hbar>}
 */
async function hbarBalance(client, accountId, previous, retryMissing = false) {
    return untilMirror(
        async (remainingMs) => {
            const { hbars } = await new MirrorNodeAccountBalanceQuery()
                .setAccountId(accountId)
                .execute(client, remainingMs);

            // Without a previous value there is nothing to wait for.
            if (previous == null) {
                return hbars;
            }

            return hbars.toTinybars().equals(previous.toTinybars())
                ? null
                : hbars;
        },
        {
            retryError: retryMissing
                ? retryOnStatus(Status.InvalidAccountId)
                : undefined,
        },
    );
}
