// SPDX-License-Identifier: Apache-2.0
package org.hiero.gradle.test

import org.assertj.core.api.Assertions.assertThat
import org.gradle.testkit.runner.TaskOutcome
import org.hiero.gradle.test.fixtures.GradleProject
import org.junit.jupiter.api.Test

class JpmsPatchTest {

    @Test
    fun `all JPMS patching rules are working`() {
        val p = GradleProject().withMinimalStructure()
        val versionPatching =
            """
            configurations.all { attributes.attribute(TargetJvmVersion.TARGET_JVM_VERSION_ATTRIBUTE, 25) }
            dependencies.components.withModule("com.goterl:resource-loader") { this.status = "release" }
            dependencies.components.withModule("com.goterl:lazysodium-java") { this.status = "release" }
            dependencies.components.all { if(listOf("alpha", "beta", "rc", "cr", ".m").any { id.version.lowercase().contains(it) }) status = "integration" }
            """
        p.aggregationBuildFile(
            """
            dependencies { implementation(project(":module-a")) }
            $versionPatching
        """
                .trimIndent()
        )
        p.dependencyVersionsFile(
            """
            val modules = extraJavaModuleInfo.moduleSpecs.get().values.map { it.identifier }
            dependencies {
                api(platform("io.netty:netty-bom:latest.release"))
            }
            dependencies.constraints {
                modules.forEach {
                    api("${'$'}it:latest.release")
                }
                api("com.squareup.okhttp3:okhttp:4.+!!") // Keep okhttp on 4.x as this is currently only used transitively
                api("io.vertx:vertx-core:4.+!!") // Keep vertx-core on 4.x as this is currently only used transitively
                api("org.jetbrains:annotations:latest.release")
                api("org.mockito:mockito-core:latest.release")
                api("org.mockito:mockito-junit-jupiter:latest.release")
                api("com.google.guava:guava:latest.release")
            }
            """
                .trimIndent()
        )
        p.moduleBuildFile(
            """
            plugins {
                id("java-library")
                id("org.hiero.gradle.base.jpms-modules")
            }
            val modules = extraJavaModuleInfo.moduleSpecs.get().values.map { it.moduleName }.distinct().filter { it !in listOf(
                "tech.pegasys.jckzg4844",
                "org.hyperledger.besu.nativelib.bls12_381",
                "org.hyperledger.besu.nativelib.common",
                // Cannot use both 'prometheus-metrics-exposition-formats' and 'prometheus-metrics-exposition-formats-no-protobuf' together
                "io.prometheus.metrics.expositionformats.noprotobuf"
            ) }
            file("src/main/java/module-info.java").writeText(
                "module org.example.module.a {\n${'$'}{modules.joinToString("") { "  requires ${'$'}it;\n"}}\n}")
            $versionPatching
            """
                .trimIndent()
        )
        p.help() // generate 'module-info.java' through code above

        val result = p.run("assemble")

        assertThat(result.task(":module-a:compileJava")?.outcome).isEqualTo(TaskOutcome.SUCCESS)
    }
}
