import type { CoreApi } from '@/core/core-api/core-api.interface';
import type { HederaMirrornodeService } from '@/core/services/mirrornode/hedera-mirrornode-service.interface';

import '@/core/utils/json-serialize';

import {
  makeAliasMock,
  makeArgs,
  makeLogger,
  makeMirrorMock,
  makeStateMock,
} from '@/__tests__/mocks/mocks';
import { assertOutput } from '@/__tests__/utils/assert-output';
import { NotFoundError } from '@/core/errors';
import { KeyAlgorithm } from '@/core/shared/constants';
import { AliasType, SupportedNetwork } from '@/core/types/shared.types';
import { AccountViewOutputSchema } from '@/plugins/account/commands/view';
import { accountView } from '@/plugins/account/commands/view/handler';
import { AccountStateServiceImpl } from '@/plugins/account/services/account-state.service';

jest.mock('../../services/account-state.service', () => ({
  AccountStateServiceImpl: jest.fn(),
}));

const MockedHelper = AccountStateServiceImpl as jest.Mock;

describe('account plugin - view command (ADR-003)', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('returns account details when found in state', async () => {
    const logger = makeLogger();

    const mirrorMock = makeMirrorMock({
      accountInfo: {
        accountId: '0.0.1111',
        balance: { balance: 1000, timestamp: '1234567890.000000000' },
        evmAddress: '0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
        accountPublicKey:
          '0230a1f42abc4794541e4a4389ec7e822666b8a7693c4cc3dedd2746b32f9c015b',
        keyAlgorithm: KeyAlgorithm.ECDSA,
      },
    });
    const api: Partial<CoreApi> = {
      mirror: mirrorMock as HederaMirrornodeService,
      logger,
      state: makeStateMock(),
      alias: {
        ...makeAliasMock(),
        resolve: jest.fn().mockReturnValue({
          alias: 'acc1',
          type: AliasType.Account,
          network: SupportedNetwork.TESTNET,
          entityId: '0.0.1111',
        }),
      },
    };
    const args = makeArgs({ ...api, logger }, { account: 'acc1' });

    const result = await accountView(args);

    expect(logger.info).toHaveBeenCalledWith('Viewing account details: acc1');
    expect(mirrorMock.getAccountOrThrow).toHaveBeenCalledWith('0.0.1111');

    const output = assertOutput(result.result, AccountViewOutputSchema);
    expect(output.accountId).toBe('0.0.1111');
    expect(output.balance).toBe(1000n);
  });

  test('returns account details when resolved via alias (not in state)', async () => {
    const logger = makeLogger();

    MockedHelper.mockImplementation(() => ({
      loadAccount: jest.fn().mockReturnValue(null),
    }));

    const mirrorMock = makeMirrorMock({
      accountInfo: {
        accountId: '0.0.2222',
        balance: { balance: 2000, timestamp: '1234567890.000000000' },
        evmAddress: '0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',
        accountPublicKey:
          '0230a1f42abc4794541e4a4389ec7e822666b8a7693c4cc3dedd2746b32f9c015b',
        keyAlgorithm: KeyAlgorithm.ECDSA,
      },
    });
    const alias = makeAliasMock();
    (alias.resolve as jest.Mock).mockReturnValue({
      alias: 'acc2',
      type: AliasType.Account,
      network: SupportedNetwork.TESTNET,
      entityId: '0.0.2222',
      createdAt: new Date().toISOString(),
    });
    const api: Partial<CoreApi> = {
      mirror: mirrorMock as HederaMirrornodeService,
      logger,
      state: makeStateMock(),
      alias,
    };
    const args = makeArgs({ ...api, logger }, { account: 'acc2' });

    const result = await accountView(args);

    expect(logger.info).toHaveBeenCalledWith('Viewing account details: acc2');
    expect(mirrorMock.getAccountOrThrow).toHaveBeenCalledWith('0.0.2222');

    const output = assertOutput(result.result, AccountViewOutputSchema);
    expect(output.accountId).toBe('0.0.2222');
  });

  test('throws error when mirror.getAccountOrThrow throws', async () => {
    const logger = makeLogger();

    MockedHelper.mockImplementation(() => ({
      loadAccount: jest.fn().mockResolvedValue(null),
    }));

    const mirrorMock = makeMirrorMock({
      getAccountImpl: jest.fn().mockRejectedValue(new Error('mirror down')),
    });
    const api: Partial<CoreApi> = {
      mirror: mirrorMock as HederaMirrornodeService,
      logger,
      state: makeStateMock(),
    };
    const args = makeArgs({ ...api, logger }, { account: '0.0.3333' });

    await expect(accountView(args)).rejects.toThrow();
  });

  test('throws NotFoundError when account not found', async () => {
    const logger = makeLogger();

    const mirrorMock = makeMirrorMock();
    const api: Partial<CoreApi> = {
      mirror: mirrorMock as HederaMirrornodeService,
      logger,
      state: makeStateMock(),
    };
    const account = 'broken';
    const args = makeArgs({ ...api, logger }, { account });

    await expect(accountView(args)).rejects.toThrow(NotFoundError);
  });
});
