import type { CoreApi } from '@/core/core-api/core-api.interface';
import type { SupportedNetwork } from '@/core/types/shared.types';
import type { TokenCreateFtFromFileOutput } from '@/plugins/token/commands/create-ft-from-file';

import '@/core/utils/json-serialize';

import * as fs from 'fs/promises';
import * as path from 'path';

import { STATE_STORAGE_FILE_PATH } from '@/__tests__/test-constants';
import { setDefaultOperatorForNetwork } from '@/__tests__/utils/network-and-operator-setup';
import { createCoreApi } from '@/core';
import { tokenCreateFtFromFile } from '@/plugins/token';

const TEMP_DIR = path.join(__dirname, 'temp-token-files');

describe('Token Custom Fees Integration Tests', () => {
  let coreApi: CoreApi;
  let network: SupportedNetwork;

  beforeAll(async () => {
    coreApi = createCoreApi(STATE_STORAGE_FILE_PATH);
    await setDefaultOperatorForNetwork(coreApi);
    network = coreApi.network.getCurrentNetwork();

    await fs.mkdir(TEMP_DIR, { recursive: true });
  });

  afterAll(async () => {
    await fs.rm(TEMP_DIR, { recursive: true, force: true });
  });

  it('should create FT with fixed HBAR fee', async () => {
    const operator = coreApi.network.getCurrentOperatorOrThrow();
    const operatorAccountId = operator.accountId;
    const operatorKey = process.env.OPERATOR_KEY!;
    const operatorWithKey = `${operatorAccountId}:${operatorKey}`;

    const tokenFile = {
      name: `FixedHbarFeeToken-${Date.now()}`,
      tokenName: `FixedHbarFeeToken-${Date.now()}`,
      symbol: 'FHBAR',
      decimals: 8,
      supplyType: 'infinite',
      initialSupply: '1000000',
      treasuryKey: operatorWithKey,
      adminKey: operatorWithKey,
      customFees: [
        {
          type: 'fixed',
          amount: 100,
          unitType: 'HBAR',
          collectorId: operatorAccountId,
          exempt: false,
        },
      ],
      memo: 'Token with fixed HBAR fee',
    };

    const filePath = path.join(TEMP_DIR, 'fixed-hbar-fee.json');
    await fs.writeFile(filePath, JSON.stringify(tokenFile, null, 2));

    const result = await tokenCreateFtFromFile({
      args: { file: filePath },
      api: coreApi,
    });

    const output = result.result as TokenCreateFtFromFileOutput;
    expect(output.tokenId).toBeDefined();
    expect(output.name).toBe(tokenFile.tokenName);
    expect(output.network).toBe(network);
  });

  it('should create FT with fractional fee', async () => {
    const operator = coreApi.network.getCurrentOperatorOrThrow();
    const operatorAccountId = operator.accountId;
    const operatorKey = process.env.OPERATOR_KEY!;
    const operatorWithKey = `${operatorAccountId}:${operatorKey}`;

    const tokenFile = {
      name: `FractionalFeeToken-${Date.now()}`,
      tokenName: `FractionalFeeToken-${Date.now()}`,
      symbol: 'FFRAC',
      decimals: 8,
      supplyType: 'infinite',
      initialSupply: '1000000',
      treasuryKey: operatorWithKey,
      adminKey: operatorWithKey,
      customFees: [
        {
          type: 'fractional',
          numerator: 1,
          denominator: 10,
          min: 10,
          max: 1000,
          netOfTransfers: true,
          collectorId: operatorAccountId,
          exempt: false,
        },
      ],
      memo: 'Token with fractional fee',
    };

    const filePath = path.join(TEMP_DIR, 'fractional-fee.json');
    await fs.writeFile(filePath, JSON.stringify(tokenFile, null, 2));

    const result = await tokenCreateFtFromFile({
      args: { file: filePath },
      api: coreApi,
    });

    const output = result.result as TokenCreateFtFromFileOutput;
    expect(output.tokenId).toBeDefined();
    expect(output.name).toBe(tokenFile.tokenName);
    expect(output.network).toBe(network);
  });

  it('should create FT with fixed TOKEN fee', async () => {
    const operator = coreApi.network.getCurrentOperatorOrThrow();
    const operatorAccountId = operator.accountId;
    const operatorKey = process.env.OPERATOR_KEY!;
    const operatorWithKey = `${operatorAccountId}:${operatorKey}`;

    const tokenFile = {
      name: `FixedTokenFeeToken-${Date.now()}`,
      tokenName: `FixedTokenFeeToken-${Date.now()}`,
      symbol: 'FTOK',
      decimals: 8,
      supplyType: 'infinite',
      initialSupply: '1000000',
      treasuryKey: operatorWithKey,
      adminKey: operatorWithKey,
      customFees: [
        {
          type: 'fixed',
          amount: 50,
          unitType: 'TOKEN',
          collectorId: operatorAccountId,
          exempt: false,
        },
      ],
      memo: 'Token with fixed TOKEN fee',
    };

    const filePath = path.join(TEMP_DIR, 'fixed-token-fee.json');
    await fs.writeFile(filePath, JSON.stringify(tokenFile, null, 2));

    const result = await tokenCreateFtFromFile({
      args: { file: filePath },
      api: coreApi,
    });

    const output = result.result as TokenCreateFtFromFileOutput;
    expect(output.tokenId).toBeDefined();
    expect(output.name).toBe(tokenFile.tokenName);
    expect(output.network).toBe(network);
  });
});
