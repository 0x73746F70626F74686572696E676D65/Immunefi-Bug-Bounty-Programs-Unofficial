# Config Plugin

Configuration management plugin for the Hiero CLI.

## 🏗️ Architecture

This plugin follows the plugin architecture principles:

- **Stateless**: Plugin is functionally stateless
- **Dependency Injection**: Services are injected into command handlers
- **Manifest-Driven**: Capabilities declared via manifest with output specifications
- **Structured Output**: All command handlers return `CommandResult` with standardized output
- **Type Safety**: Full TypeScript support

## 📁 Structure

```
src/plugins/config/
├── manifest.ts              # Plugin manifest with command definitions
├── schema.ts                # Config option type inference utilities
├── commands/
│   ├── list/
│   │   ├── handler.ts      # List config options handler
│   │   ├── output.ts       # Output schema and template
│   │   └── index.ts        # Command exports
│   ├── get/
│   │   ├── handler.ts      # Get config option handler
│   │   ├── input.ts        # Input schema
│   │   ├── output.ts       # Output schema and template
│   │   └── index.ts        # Command exports
│   └── set/
│       ├── handler.ts      # Set config option handler
│       ├── input.ts        # Input schema
│       ├── output.ts       # Output schema and template
│       └── index.ts        # Command exports
├── __tests__/unit/         # Unit tests
└── index.ts                # Plugin exports
```

## 🚀 Commands

All commands return `CommandResult` with structured output data in the `result` field. Errors are thrown as typed `CliError` instances and handled uniformly by the core framework.

Each command defines a Zod schema for output validation and a Handlebars template for human-readable formatting.

### Config List

List all available configuration options with their current values, types, and allowed values (for enum options).

```bash
hcli config list
```

**Output:**

```json
{
  "options": [
    {
      "name": "default_key_manager",
      "type": "enum",
      "value": "local",
      "allowedValues": ["local", "local_encrypted"]
    },
    {
      "name": "log_level",
      "type": "enum",
      "value": "silent",
      "allowedValues": ["silent", "error", "warn", "info", "debug"]
    },
    {
      "name": "ed25519_support",
      "type": "boolean",
      "value": false
    },
    {
      "name": "skip_confirmations",
      "type": "boolean",
      "value": false
    },
    {
      "name": "default_max_transaction_fee",
      "type": "string",
      "value": ""
    }
  ],
  "totalCount": 5
}
```

### Config Get

Get the value of a specific configuration option.

```bash
hcli config get -o default_key_manager
```

**Options:**

- `-o, --option <string>` - Option name to read (required)

**Output:**

```json
{
  "name": "default_key_manager",
  "type": "enum",
  "value": "local",
  "allowedValues": ["local", "local_encrypted"]
}
```

### Config Set

Set the value of a configuration option by passing the option name as a named flag. Exactly one flag must be provided per invocation.

```bash
hcli config set --default_key_manager local_encrypted
hcli config set --log_level info
hcli config set --ed25519_support true
hcli config set --skip_confirmations false
hcli config set --default_max_transaction_fee 20      # 20 ℏ ceiling
hcli config set --default_max_transaction_fee 200000000t  # tinybars
hcli config set --default_max_transaction_fee 0       # clear (use SDK default)
```

**Options (pass exactly one):**

- `--default_key_manager <string>` - Set default key manager (`local` | `local_encrypted`)
- `--ed25519_support <string>` - Set Ed25519 support (`true` | `false`)
- `--log_level <string>` - Set log level (`silent` | `error` | `warn` | `info` | `debug`)
- `--skip_confirmations <string>` - Set skip confirmations (`true` | `false`)
- `--default_max_transaction_fee <string>` - Default max transaction fee ceiling applied to every client/transaction. Accepts HBAR (e.g. `20`) or tinybars (`200000000t`). Set to `0` to clear it (falls back to the SDK default). The per-run global flag `--max-transaction-fee` overrides this value.

**Output:**

```json
{
  "name": "default_key_manager",
  "type": "enum",
  "previousValue": "local",
  "newValue": "local_encrypted"
}
```

## 🔧 Core API Integration

The plugin uses the Core API services:

- `api.config` - Configuration option management (list, get, set)
- `api.logger` - Logging

## 📤 Output Formatting

All commands return structured output through the `CommandResult` interface:

```typescript
interface CommandResult {
  result: object;
}
```

**Output Structure:**

- **Output Schemas**: Each command defines a Zod schema in `output.ts` for type-safe output validation
- **Human Templates**: Handlebars templates provide human-readable output formatting
- **Error Handling**: All errors are returned in the result structure, ensuring consistent error handling
- **Format Selection**: Output format is controlled by the CLI's `--format` option (default: `human`, or `json` for machine-readable output)

The `result` field contains a structured object conforming to the Zod schema defined in each command's `output.ts` file, ensuring type safety and consistent output structure.

## 🧪 Testing

Unit tests located in `__tests__/unit/`:

```bash
npm test -- src/plugins/config/__tests__/unit
```

Test coverage includes:

- Listing configuration options
- Getting configuration option values
- Setting configuration option values
- Type validation for boolean, number, string, and enum values
- Error handling for invalid option names or values
- Enum value validation
