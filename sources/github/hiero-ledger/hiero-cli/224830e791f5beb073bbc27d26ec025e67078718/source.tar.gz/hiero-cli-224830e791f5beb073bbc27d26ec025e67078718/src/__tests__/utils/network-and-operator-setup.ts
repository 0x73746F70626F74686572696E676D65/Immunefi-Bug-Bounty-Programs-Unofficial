import type { CoreApi } from '@/core/core-api/core-api.interface';
import type { NetworkGetOperatorOutput } from '@/plugins/network/commands/get-operator';

import { z } from 'zod';

import { EntityIdSchema } from '@/core/schemas/common-schemas';
import { SupportedNetwork } from '@/core/types/shared.types';
import { networkGetOperator } from '@/plugins/network/commands/get-operator';
import { networkSetOperator } from '@/plugins/network/commands/set-operator';
import { networkUse } from '@/plugins/network/commands/use';

const INTEGRATION_NETWORKS = [
  SupportedNetwork.TESTNET,
  SupportedNetwork.LOCALNET,
] as const;

const envSchema = z.object({
  OPERATOR_ID: z
    .string()
    .min(1, 'OPERATOR_ID is required')
    .trim()
    .pipe(EntityIdSchema)
    .describe('Hedera entity ID in format 0.0.{number}'),
  OPERATOR_KEY: z.string().min(1, 'OPERATOR_KEY is required').trim(),
  NETWORK: z.enum(INTEGRATION_NETWORKS, {
    error: () => ({
      message: 'Network must be testnet or localnet',
    }),
  }),
});

export const setDefaultOperatorForNetwork = async (
  coreApi: CoreApi,
): Promise<void> => {
  // Validate environment variables with Zod
  const env = envSchema.parse({
    OPERATOR_ID: process.env.OPERATOR_ID,
    OPERATOR_KEY: process.env.OPERATOR_KEY,
    NETWORK: process.env.NETWORK,
  });

  const useNetworkArgs: Record<string, unknown> = {
    global: env.NETWORK,
  };
  await networkUse({
    args: useNetworkArgs,
    api: coreApi,
  });

  const getOperatorResult = await networkGetOperator({
    args: {},
    api: coreApi,
  });
  const getOperatorOutput =
    getOperatorResult.result as NetworkGetOperatorOutput;
  if (getOperatorOutput.operator?.accountId != env.OPERATOR_ID) {
    const setOperatorArgs: Record<string, unknown> = {
      operator: `${env.OPERATOR_ID}:${env.OPERATOR_KEY}`,
    };
    await networkSetOperator({
      args: setOperatorArgs,
      api: coreApi,
    });
  }
};
