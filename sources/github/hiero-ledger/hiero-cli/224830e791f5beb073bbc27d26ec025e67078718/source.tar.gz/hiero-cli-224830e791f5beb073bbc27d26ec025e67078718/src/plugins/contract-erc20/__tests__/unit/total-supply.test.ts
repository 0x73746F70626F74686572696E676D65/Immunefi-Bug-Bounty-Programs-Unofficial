import type { CoreApi, Logger } from '@/core';

import { ZodError } from 'zod';

import { makeHederaSdkContractMock } from '@/__tests__/mocks/hedera-sdk-contract-mock';
import { makeLogger } from '@/__tests__/mocks/mocks';
import { assertOutput } from '@/__tests__/utils/assert-output';
import { StateError } from '@/core/errors';
import { SupportedNetwork } from '@/core/types/shared.types';
import { makeContractErc20CallCommandArgs } from '@/plugins/contract-erc20/__tests__/unit/helpers/fixtures';
import { makeApiMocks } from '@/plugins/contract-erc20/__tests__/unit/helpers/mocks';
import { ContractErc20CallTotalSupplyOutputSchema } from '@/plugins/contract-erc20/commands/total-supply';
import { contractErc20TotalSupply } from '@/plugins/contract-erc20/commands/total-supply/handler';
import { ContractErc20CallTotalSupplyInputSchema } from '@/plugins/contract-erc20/commands/total-supply/input';

jest.mock('@hiero-ledger/sdk', () => makeHederaSdkContractMock());

describe('contract-erc20 plugin - totalSupply command (unit)', () => {
  let api: jest.Mocked<CoreApi>;
  let logger: jest.Mocked<Logger>;

  beforeEach(() => {
    jest.clearAllMocks();
    logger = makeLogger();
    api = makeApiMocks({
      contractQuery: {
        queryContractFunction: jest.fn().mockResolvedValue({
          contractId: '0.0.1234',
          queryResult: [1000000000000000000n],
        }),
      },
    }).api;
  });

  test('calls ERC-20 totalSupply successfully and returns expected output', async () => {
    const args = makeContractErc20CallCommandArgs({ api, logger });

    const result = await contractErc20TotalSupply(args);

    expect(result.result).toBeDefined();

    const parsed = assertOutput(
      result.result,
      ContractErc20CallTotalSupplyOutputSchema,
    );

    expect(parsed.contractId).toBe('0.0.1234');
    expect(parsed.totalSupply).toBe('1000000000000000000');
    expect(parsed.network).toBe(SupportedNetwork.TESTNET);

    expect(
      args.api.identityResolution.resolveReferenceToEntityOrEvmAddress,
    ).toHaveBeenCalledWith({
      entityReference: 'some-alias-or-id',
      referenceType: expect.any(String),
      network: SupportedNetwork.TESTNET,
      aliasType: expect.any(String),
    });
    expect(args.api.contractQuery.queryContractFunction).toHaveBeenCalledWith(
      expect.objectContaining({
        contractIdOrEvmAddress: '0.0.1234',
        functionName: 'totalSupply',
      }),
    );
  });

  test('throws StateError when contractQuery returns empty queryResult', async () => {
    const args = makeContractErc20CallCommandArgs({ api, logger });
    (
      args.api.contractQuery.queryContractFunction as jest.Mock
    ).mockResolvedValue({
      contractId: '0.0.1234',
      queryResult: [],
    });

    await expect(contractErc20TotalSupply(args)).rejects.toThrow(StateError);
  });

  test('throws when queryContractFunction throws', async () => {
    const args = makeContractErc20CallCommandArgs({ api, logger });
    (
      args.api.contractQuery.queryContractFunction as jest.Mock
    ).mockRejectedValue(new Error('contract query error'));

    await expect(contractErc20TotalSupply(args)).rejects.toThrow(
      'contract query error',
    );
  });

  test('schema validation fails when contract is missing', () => {
    expect(() => {
      ContractErc20CallTotalSupplyInputSchema.parse({});
    }).toThrow(ZodError);
  });
});
