/**
 * List Accounts Command Output Schema and Template
 */
import { z } from 'zod';

import {
  EntityIdSchema,
  EvmAddressSchema,
  KeyTypeSchema,
  NetworkSchema,
} from '@/core/schemas/common-schemas';

/**
 * List Accounts Command Output Schema
 */
export const AccountListOutputSchema = z.object({
  accounts: z.array(
    z.object({
      name: z.string().describe('Local name (alias)').optional(),
      accountId: EntityIdSchema,
      type: KeyTypeSchema,
      network: NetworkSchema,
      evmAddress: EvmAddressSchema,
      keyRefId: z.string().describe('Key reference ID').optional(), // Only included when --private flag is used
    }),
  ),
  totalCount: z.number().describe('Total number of accounts'),
});

export type AccountListOutput = z.infer<typeof AccountListOutputSchema>;

/**
 * Human-readable template for list accounts output
 */
export const ACCOUNT_LIST_TEMPLATE = `
{{#if (eq totalCount 0)}}
📝 No accounts found in the address book
{{else}}
📝 Found {{totalCount}} account(s):

{{#each accounts}}
{{add1 @index}}. Name (Alias): {{#if name}}{{name}}{{else}}-{{/if}}
   Account ID: {{hashscanLink accountId "account" network}}
   Type: {{type}}
   Network: {{network}}
   EVM Address: {{evmAddress}}
{{#if keyRefId}}
   Key Reference ID: {{keyRefId}}
{{/if}}

{{/each}}
{{/if}}
`.trim();
