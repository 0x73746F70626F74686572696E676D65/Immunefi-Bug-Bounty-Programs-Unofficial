/**
 * Core API Implementation
 * Combines all services into a single Core API instance
 */
import type { CoreApi } from '@/core';
import type { AccountService } from '@/core/services/account/account-transaction-service.interface';
import type { AliasService } from '@/core/services/alias/alias-service.interface';
import type { AllowanceService } from '@/core/services/allowance/allowance-service.interface';
import type { BatchTransactionService } from '@/core/services/batch/batch-transaction-service.interface';
import type { ConfigService } from '@/core/services/config/config-service.interface';
import type { ContractCompilerService } from '@/core/services/contract-compiler/contract-compiler-service.interface';
import type { ContractQueryService } from '@/core/services/contract-query/contract-query-service.interface';
import type { ContractTransactionService } from '@/core/services/contract-transaction/contract-transaction-service.interface';
import type { ContractVerifierService } from '@/core/services/contract-verifier/contract-verifier-service.interface';
import type { IdentityResolutionService } from '@/core/services/identity-resolution/identity-resolution-service.interface';
import type { KeyResolverService } from '@/core/services/key-resolver/key-resolver-service.interface';
import type { KmsService } from '@/core/services/kms/kms-service.interface';
import type { Logger } from '@/core/services/logger/logger-service.interface';
import type { HederaMirrornodeService } from '@/core/services/mirrornode/hedera-mirrornode-service.interface';
import type { NetworkService } from '@/core/services/network/network-service.interface';
import type { OutputService } from '@/core/services/output/output-service.interface';
import type { PluginManagementService } from '@/core/services/plugin-management/plugin-management-service.interface';
import type { ReceiptService } from '@/core/services/receipt/receipt-service.interface';
import type { ScheduleTransactionService } from '@/core/services/schedule-transaction/schedule-transaction-service.interface';
import type { StateService } from '@/core/services/state/state-service.interface';
import type { TokenService } from '@/core/services/token/token-service.interface';
import type { TopicService } from '@/core/services/topic/topic-transaction-service.interface';
import type { TransferService } from '@/core/services/transfer/transfer-service.interface';
import type { TxExecuteService } from '@/core/services/tx-execute/tx-execute-service.interface';
import type { TxSignService } from '@/core/services/tx-sign/tx-sign-service.interface';
import type { LogLevel } from '@/core/types/shared.types';

import { AccountServiceImpl } from '@/core/services/account/account-transaction-service';
import { AliasServiceImpl } from '@/core/services/alias/alias-service';
import { AllowanceServiceImpl } from '@/core/services/allowance/allowance-service';
import { BatchTransactionServiceImpl } from '@/core/services/batch/batch-transaction-service';
import { ConfigServiceImpl } from '@/core/services/config/config-service';
import { ConfigOptionKey } from '@/core/services/config/config-service.interface';
import { ContractCompilerServiceImpl } from '@/core/services/contract-compiler/contract-compiler-service';
import { ContractQueryServiceImpl } from '@/core/services/contract-query/contract-query-service';
import { ContractTransactionServiceImpl } from '@/core/services/contract-transaction/contract-transaction-service';
import { ContractVerifierServiceImpl } from '@/core/services/contract-verifier/contract-verifier-service';
import { IdentityResolutionServiceImpl } from '@/core/services/identity-resolution/identity-resolution-service';
import { KeyResolverServiceImpl } from '@/core/services/key-resolver/key-resolver-service';
import { KmsServiceImpl } from '@/core/services/kms/kms-service';
import { LoggerService } from '@/core/services/logger/logger-service';
import { HederaMirrornodeServiceDefaultImpl } from '@/core/services/mirrornode/hedera-mirrornode-service';
import { NetworkServiceImpl } from '@/core/services/network/network-service';
import { OutputServiceImpl } from '@/core/services/output/output-service';
import { PluginManagementServiceImpl } from '@/core/services/plugin-management/plugin-management-service';
import { ReceiptServiceImpl } from '@/core/services/receipt/receipt-service';
import { ScheduleTransactionServiceImpl } from '@/core/services/schedule-transaction/schedule-transaction-service';
import { ZustandGenericStateServiceImpl } from '@/core/services/state/state-service';
import { TokenServiceImpl } from '@/core/services/token/token-service';
import { TopicServiceImpl } from '@/core/services/topic/topic-transaction-service';
import { TransferServiceImpl } from '@/core/services/transfer/transfer-service';
import { TxExecuteServiceImpl } from '@/core/services/tx-execute/tx-execute-service';
import { TxSignServiceImpl } from '@/core/services/tx-sign/tx-sign-service';

export class CoreApiImplementation implements CoreApi {
  public account: AccountService;
  public token: TokenService;
  public txSign: TxSignService;
  public txExecute: TxExecuteService;
  public topic: TopicService;
  public state: StateService;
  public mirror: HederaMirrornodeService;
  public network: NetworkService;
  public config: ConfigService;
  public logger: Logger;
  public alias: AliasService;
  public kms: KmsService;
  public transfer: TransferService;
  public allowance: AllowanceService;
  public output: OutputService;
  public pluginManagement: PluginManagementService;
  public keyResolver: KeyResolverService;
  public contract: ContractTransactionService;
  public contractCompiler: ContractCompilerService;
  public contractVerifier: ContractVerifierService;
  public contractQuery: ContractQueryService;
  public identityResolution: IdentityResolutionService;
  public batch: BatchTransactionService;
  public schedule: ScheduleTransactionService;
  public receipt: ReceiptService;

  constructor(storageDir?: string) {
    this.logger = new LoggerService();
    this.state = new ZustandGenericStateServiceImpl(this.logger, storageDir);

    this.network = new NetworkServiceImpl(this.state, this.logger);

    // Initialize config service first (needed by KMS)
    this.config = new ConfigServiceImpl(this.state);

    // Configure logger level from config service
    const configuredLogLevel = this.config.getOption<LogLevel>(
      ConfigOptionKey.log_level,
    );
    this.logger.setLevel(configuredLogLevel);

    this.logger.info('🚀 Starting Hiero CLI...');

    // Initialize new services
    this.alias = new AliasServiceImpl(this.state, this.logger);
    this.kms = new KmsServiceImpl(
      this.logger,
      this.state,
      this.network,
      this.config,
    );
    this.txSign = new TxSignServiceImpl(
      this.logger,
      this.kms,
      this.network,
      this.config,
    );
    this.txExecute = new TxExecuteServiceImpl(
      this.logger,
      this.kms,
      this.network,
      this.config,
    );

    // Initialize all services with dependencies
    this.account = new AccountServiceImpl(this.logger);
    this.token = new TokenServiceImpl(this.logger);
    this.topic = new TopicServiceImpl();
    this.contract = new ContractTransactionServiceImpl();
    this.contractCompiler = new ContractCompilerServiceImpl();
    this.contractVerifier = new ContractVerifierServiceImpl(this.network);

    this.mirror = new HederaMirrornodeServiceDefaultImpl(this.network);
    this.keyResolver = new KeyResolverServiceImpl(
      this.mirror,
      this.alias,
      this.network,
      this.kms,
      this.logger,
    );

    this.transfer = new TransferServiceImpl();
    this.allowance = new AllowanceServiceImpl();
    this.output = new OutputServiceImpl();

    this.pluginManagement = new PluginManagementServiceImpl(this.state);
    this.contractQuery = new ContractQueryServiceImpl(this.mirror, this.logger);
    this.identityResolution = new IdentityResolutionServiceImpl(
      this.alias,
      this.mirror,
    );
    this.batch = new BatchTransactionServiceImpl(this.logger);
    this.schedule = new ScheduleTransactionServiceImpl(this.logger);
    this.receipt = new ReceiptServiceImpl(this.logger, this.network);
  }
}

/**
 * Factory function to create a Core API instance
 */
export function createCoreApi(storageDir?: string): CoreApi {
  return new CoreApiImplementation(storageDir);
}
