import { z } from 'zod';

import {
  AccountNameSchema,
  AccountReferenceSchema,
  AmountInputSchema,
  KeyManagerTypeSchema,
  KeySchema,
  KeyTypeSchema,
} from '@/core/schemas';
import { ZOD_CUSTOM_ISSUE_CODE } from '@/core/shared/constants';

export const AccountCreateInputSchema = z
  .object({
    balance: AmountInputSchema.describe(
      'Initial HBAR balance. Format: "100" (HBAR) or "100t" (tinybars)',
    ),
    autoAssociations: z
      .number()
      .int()
      .min(0, 'Auto associations must be non-negative')
      .max(
        5000,
        'Maximum number of automatic token associations cannot exceed 5000',
      )
      .default(0)
      .describe('Maximum number of automatic token associations'),
    name: AccountNameSchema.optional().describe('Optional account name/alias'),
    payer: AccountReferenceSchema.optional().describe(
      'Optional payer account for transaction fees',
    ),
    keyManager: KeyManagerTypeSchema.optional().describe(
      'Key manager type (defaults to config setting)',
    ),
    keyType: KeyTypeSchema.optional().describe(
      'Cryptographic key type for the account',
    ),
    key: KeySchema.optional().describe(
      'Existing key for the account. Accepts any key format.',
    ),
  })
  .superRefine((data, ctx) => {
    if (data.key !== undefined && data.keyType !== undefined) {
      ctx.addIssue({
        code: ZOD_CUSTOM_ISSUE_CODE,
        message: 'Cannot specify both --key and --key-type',
        path: ['keyType'],
      });
    }
  });

export type AccountCreateInput = z.infer<typeof AccountCreateInputSchema>;
