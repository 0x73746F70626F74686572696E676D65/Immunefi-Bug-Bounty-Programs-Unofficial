import type { CoreApi } from '@/core/core-api/core-api.interface';
import type { ConfigGetOutput } from '@/plugins/config/commands/get';
import type { ConfigListOutput } from '@/plugins/config/commands/list';
import type { ConfigSetOutput } from '@/plugins/config/commands/set';

import '@/core/utils/json-serialize';

import { STATE_STORAGE_FILE_PATH } from '@/__tests__/test-constants';
import { setDefaultOperatorForNetwork } from '@/__tests__/utils/network-and-operator-setup';
import { createCoreApi } from '@/core';
import { ConfigOptionKey } from '@/core/services/config/config-service.interface';
import { configGet } from '@/plugins/config/commands/get/handler';
import { configList } from '@/plugins/config/commands/list/handler';
import { configSet } from '@/plugins/config/commands/set/handler';

describe('Config Integration Tests', () => {
  let coreApi: CoreApi;

  beforeAll(async () => {
    coreApi = createCoreApi(STATE_STORAGE_FILE_PATH);
    await setDefaultOperatorForNetwork(coreApi);
  });

  it('should list config options', async () => {
    const listConfigResult = await configList({
      args: {},
      api: coreApi,
    });

    const listConfigOutput = listConfigResult.result as ConfigListOutput;
    expect(listConfigOutput.totalCount).toBe(6);
    const optionNames = listConfigOutput.options.map((option) => option.name);
    expect(optionNames).toEqual(
      expect.arrayContaining([
        ConfigOptionKey.ed25519_support,
        ConfigOptionKey.log_level,
        ConfigOptionKey.default_key_manager,
        ConfigOptionKey.skip_confirmations,
        ConfigOptionKey.portal_pat,
        ConfigOptionKey.default_max_transaction_fee,
      ]),
    );
  });

  it('should set config option and then verify it with with get method', async () => {
    const setConfigArgs: Record<string, unknown> = {
      [ConfigOptionKey.ed25519_support]: 'true',
    };
    const setConfigResult = await configSet({
      args: setConfigArgs,
      api: coreApi,
    });
    const setConfigOutput = setConfigResult.result as ConfigSetOutput;
    expect(setConfigOutput.previousValue).toBe(false);
    expect(setConfigOutput.newValue).toBe(true);

    const getConfigArgs: Record<string, unknown> = {
      option: ConfigOptionKey.ed25519_support,
    };
    const getConfigResult = await configGet({
      args: getConfigArgs,
      api: coreApi,
    });
    const getConfigOutput = getConfigResult.result as ConfigGetOutput;
    expect(getConfigOutput.name).toBe(ConfigOptionKey.ed25519_support);
    expect(getConfigOutput.value).toBe(true);
    expect(getConfigOutput.type).toBe('boolean');
  });
});
