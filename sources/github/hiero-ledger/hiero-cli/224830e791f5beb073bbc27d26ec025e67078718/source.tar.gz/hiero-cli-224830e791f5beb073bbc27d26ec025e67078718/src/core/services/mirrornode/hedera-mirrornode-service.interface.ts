/**
 * Comprehensive Hedera Mirror Node Service Interface
 * Provides access to all Hedera Mirror Node API endpoints
 */
import type {
  AccountNftsResponse,
  AccountResponse,
  ContractCallRequest,
  ContractCallResponse,
  ContractInfo,
  ExchangeRateResponse,
  GetAccountsQueryParams,
  GetAccountsResponse,
  HbarAllowancesResponse,
  MirrorNodePageParams,
  NftAllowancesResponse,
  NftInfo,
  ScheduleInfo,
  TokenAirdropsResponse,
  TokenAllowancesResponse,
  TokenBalancesResponse,
  TokenInfo,
  TopicInfo,
  TopicMessage,
  TopicMessageQueryParams,
  TopicMessagesQueryParams,
  TopicMessagesResponse,
  TransactionDetailsResponse,
} from './types';

export interface HederaMirrornodeService {
  /**
   * Get account information or throw
   */
  getAccountOrThrow(accountId: string): Promise<AccountResponse>;
  /**
   * Get account information
   */
  getAccount(accountId: string): Promise<AccountResponse | null>;

  /**
   * Get account token balances
   */
  getAccountTokenBalances(
    accountId: string,
    tokenId?: string,
  ): Promise<TokenBalancesResponse>;

  /**
   * Get HBAR allowances granted by an account
   */
  getHbarAllowances(
    accountId: string,
    params?: MirrorNodePageParams,
  ): Promise<HbarAllowancesResponse>;

  getAllHbarAllowances(accountId: string): Promise<HbarAllowancesResponse>;

  /**
   * Get fungible token allowances granted by an account
   */
  getTokenAllowances(
    accountId: string,
    params?: MirrorNodePageParams,
  ): Promise<TokenAllowancesResponse>;

  getAllTokenAllowances(accountId: string): Promise<TokenAllowancesResponse>;

  /**
   * Get NFT allowances granted by an account
   */
  getNftAllowances(
    accountId: string,
    params?: MirrorNodePageParams,
  ): Promise<NftAllowancesResponse>;

  getAllNftAllowances(accountId: string): Promise<NftAllowancesResponse>;

  /**
   * List account entities on network with optional filters and pagination
   */
  getAccounts(
    queryParams?: GetAccountsQueryParams,
  ): Promise<GetAccountsResponse>;

  /**
   * Get topic messages with pagination support
   */
  getTopicMessage(queryParams: TopicMessageQueryParams): Promise<TopicMessage>;

  /**
   * Get topic messages with pagination support
   */
  getTopicMessages(
    queryParams: TopicMessagesQueryParams,
  ): Promise<TopicMessagesResponse>;

  /**
   * Get token information
   */
  getTokenInfo(tokenId: string): Promise<TokenInfo>;

  /**
   * Get schedule entity by id (Mirror Node GET /api/v1/schedules/{scheduleId})
   */
  getScheduled(scheduleId: string): Promise<ScheduleInfo>;

  /**
   * Get NFT information by token ID and serial number
   */
  getNftInfo(tokenId: string, serialNumber: number): Promise<NftInfo>;

  /**
   * Get all NFTs owned by an account (first page, up to limit)
   */
  getAccountNfts(
    accountId: string,
    limit?: number,
  ): Promise<AccountNftsResponse>;

  /**
   * Get topic information
   */
  getTopicInfo(topicId: string): Promise<TopicInfo>;

  /**
   * Get transaction record
   */
  getTransactionRecord(
    transactionId: string,
    nonce?: number,
  ): Promise<TransactionDetailsResponse>;

  /**
   * Get contract information
   */
  getContractInfo(contractId: string): Promise<ContractInfo>;

  /**
   * Get pending airdrops for an account
   */
  getPendingAirdrops(
    accountId: string,
    params?: { limit?: number; cursor?: string },
  ): Promise<TokenAirdropsResponse>;

  /**
   * Get outstanding airdrops for an account
   */
  getOutstandingAirdrops(accountId: string): Promise<TokenAirdropsResponse>;

  /**
   * Get exchange rate
   */
  getExchangeRate(timestamp?: string): Promise<ExchangeRateResponse>;

  /**
   * Execute a smart contract call via the Mirror Node.
   *
   * Wraps POST /api/v1/contracts/call.
   */
  postContractCall(request: ContractCallRequest): Promise<ContractCallResponse>;
}
