import type { CoreApi } from '@/core/core-api/core-api.interface';
import type { SupportedNetwork } from '@/core/types/shared.types';
import type { AccountBalanceOutput } from '@/plugins/account/commands/balance';
import type { AccountCreateOutput } from '@/plugins/account/commands/create';
import type { AccountViewOutput } from '@/plugins/account/commands/view';
import type { TokenAssociateOutput } from '@/plugins/token/commands/associate';
import type { TokenCreateFtOutput } from '@/plugins/token/commands/create-ft';
import type { TokenTransferFtOutput } from '@/plugins/token/commands/transfer-ft';
import type { TokenViewOutput } from '@/plugins/token/commands/view';

import '@/core/utils/json-serialize';

import { STATE_STORAGE_FILE_PATH } from '@/__tests__/test-constants';
import { delay, waitFor } from '@/__tests__/utils/common-utils';
import { setDefaultOperatorForNetwork } from '@/__tests__/utils/network-and-operator-setup';
import { createCoreApi } from '@/core';
import { KeyAlgorithm } from '@/core/shared/constants';
import { SupplyType } from '@/core/types/shared.types';
import { accountBalance, accountCreate, accountView } from '@/plugins/account';
import {
  tokenAssociate,
  tokenCreateFt,
  tokenTransferFt,
  tokenView,
} from '@/plugins/token';

describe('Transfer Token Integration Tests', () => {
  let coreApi: CoreApi;
  let network: SupportedNetwork;

  beforeAll(async () => {
    coreApi = createCoreApi(STATE_STORAGE_FILE_PATH);
    await setDefaultOperatorForNetwork(coreApi);
    network = coreApi.network.getCurrentNetwork();
  });
  it('should create a token associate with account and transfer to it from operator account and verify with account balance method', async () => {
    const alias = `account-transfer-token-${Date.now()}`;
    const createAccountArgs: Record<string, unknown> = {
      name: alias,
      balance: 1,
      'key-type': KeyAlgorithm.ECDSA,
      'auto-associations': 10,
    };
    const createAccountResult = await accountCreate({
      args: createAccountArgs,
      api: coreApi,
    });

    const createAccountOutput =
      createAccountResult.result as AccountCreateOutput;
    expect(createAccountOutput.name).toBe(alias);
    expect(createAccountOutput.type).toBe(KeyAlgorithm.ECDSA);
    expect(createAccountOutput.network).toBe(network);

    const viewAccountArgs: Record<string, unknown> = {
      account: alias,
    };
    const viewAccountResult = await waitFor(
      () => accountView({ args: viewAccountArgs, api: coreApi }),
      (result) => !!(result.result as AccountViewOutput).accountId,
    );
    const viewAccountOutput = viewAccountResult.result as AccountViewOutput;
    expect(viewAccountOutput.accountId).toBe(createAccountOutput.accountId);
    expect(viewAccountOutput.balance).toBe(100000000n); // result in tinybars
    expect(viewAccountOutput.evmAddress).toBe(createAccountOutput.evmAddress);
    expect(viewAccountOutput.publicKey).toBe(createAccountOutput.publicKey);

    const createTokenArgs: Record<string, unknown> = {
      tokenName: 'Test Token Transfer',
      symbol: 'TTT',
      initialSupply: '10',
      supplyType: SupplyType.INFINITE,
      name: 'test-token-transfer',
    };
    const createTokenResult = await tokenCreateFt({
      args: createTokenArgs,
      api: coreApi,
    });
    const createTokenOutput = createTokenResult.result as TokenCreateFtOutput;
    expect(createTokenOutput.network).toBe(network);
    expect(createTokenOutput.decimals).toBe(0);
    expect(createTokenOutput.initialSupply).toBe('10');
    expect(createTokenOutput.name).toBe('Test Token Transfer');
    expect(createTokenOutput.alias).toBe('test-token-transfer');
    expect(createTokenOutput.treasuryId).toBe(process.env.OPERATOR_ID);
    expect(createTokenOutput.symbol).toBe('TTT');
    expect(createTokenOutput.supplyType).toBe(SupplyType.INFINITE);

    await waitFor(
      () =>
        tokenView({ args: { token: createTokenOutput.alias }, api: coreApi }),
      (result) => !!(result.result as TokenViewOutput).tokenId,
    );

    const associateTokenArgs: Record<string, unknown> = {
      token: createTokenOutput.tokenId,
      account: alias,
    };
    const associateTokenResult = await tokenAssociate({
      args: associateTokenArgs,
      api: coreApi,
    });
    const associateTokenOutput =
      associateTokenResult.result as TokenAssociateOutput;
    expect(associateTokenOutput.tokenId).toBe(createTokenOutput.tokenId);
    expect(associateTokenOutput.accountId).toBe(createAccountOutput.accountId);

    await delay(5000);

    const transferTokenArgs: Record<string, unknown> = {
      token: createTokenOutput.tokenId,
      from: `${process.env.OPERATOR_ID}:${process.env.OPERATOR_KEY}`,
      to: alias,
      amount: '5',
    };
    const transferTokenResult = await tokenTransferFt({
      args: transferTokenArgs,
      api: coreApi,
    });
    const transferTokenOutput =
      transferTokenResult.result as TokenTransferFtOutput;
    expect(transferTokenOutput.tokenId).toBe(createTokenOutput.tokenId);
    expect(transferTokenOutput.from).toBe(process.env.OPERATOR_ID);
    expect(transferTokenOutput.to).toBe(createAccountOutput.accountId);
    expect(transferTokenOutput.amount).toBe(5n);

    const accountBalanceArgs: Record<string, unknown> = {
      account: alias,
      hbarOnly: false,
      token: createTokenOutput.tokenId,
    };
    const accountBalanceResult = await waitFor(
      () => accountBalance({ args: accountBalanceArgs, api: coreApi }),
      (result) =>
        (result.result as AccountBalanceOutput).tokenBalances?.at(0)
          ?.balance === 5n,
    );
    const accountBalanceOutput =
      accountBalanceResult.result as AccountBalanceOutput;
    expect(accountBalanceOutput.tokenBalances?.length).toBe(1);
    expect(accountBalanceOutput.tokenBalances?.at(0)?.tokenId).toBe(
      createTokenOutput.tokenId,
    );
    expect(accountBalanceOutput.tokenBalances?.at(0)?.balance).toBe(5n);
  }, 90000);
});
