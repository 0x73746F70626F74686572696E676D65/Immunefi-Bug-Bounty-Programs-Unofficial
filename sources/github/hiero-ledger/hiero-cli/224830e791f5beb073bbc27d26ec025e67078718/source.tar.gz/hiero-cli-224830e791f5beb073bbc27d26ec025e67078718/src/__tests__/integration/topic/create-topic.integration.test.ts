import type { CoreApi } from '@/core/core-api/core-api.interface';
import type { SupportedNetwork } from '@/core/types/shared.types';
import type { TopicCreateOutput } from '@/plugins/topic/commands/create';
import type { TopicListOutput } from '@/plugins/topic/commands/list';

import '@/core/utils/json-serialize';

import { STATE_STORAGE_FILE_PATH } from '@/__tests__/test-constants';
import { setDefaultOperatorForNetwork } from '@/__tests__/utils/network-and-operator-setup';
import { createCoreApi } from '@/core';
import { topicCreate, topicList } from '@/plugins/topic';

describe('Create Topic Integration Tests', () => {
  let coreApi: CoreApi;
  let network: SupportedNetwork;

  beforeAll(async () => {
    coreApi = createCoreApi(STATE_STORAGE_FILE_PATH);
    await setDefaultOperatorForNetwork(coreApi);
    network = coreApi.network.getCurrentNetwork();
  });
  it('should create a topic and verify with list method', async () => {
    const createTopicArgs: Record<string, unknown> = {
      memo: 'Test topic',
      adminKey: [`${process.env.OPERATOR_ID}:${process.env.OPERATOR_KEY}`],
      submitKey: [`${process.env.OPERATOR_ID}:${process.env.OPERATOR_KEY}`],
      name: 'test-topic',
    };
    const createTopicResult = await topicCreate({
      args: createTopicArgs,
      api: coreApi,
    });

    const createTopicOutput = createTopicResult.result as TopicCreateOutput;
    expect(createTopicOutput.name).toBe('test-topic');
    expect(createTopicOutput.network).toBe(network);
    expect(createTopicOutput.memo).toBe('Test topic');
    expect(createTopicOutput.adminKeyPresent).toBe(true);
    expect(createTopicOutput.submitKeyPresent).toBe(true);

    const listTopicArgs: Record<string, unknown> = {
      network: network,
    };
    const listTopicResult = await topicList({
      args: listTopicArgs,
      api: coreApi,
    });
    const listTopicOutput = listTopicResult.result as TopicListOutput;
    const topic = listTopicOutput.topics.find(
      (topic) => topic.name == 'test-topic',
    );
    expect(topic).not.toBeNull();
    expect(topic?.name).toBe('test-topic');
    expect(topic?.network).toBe(network);
    expect(topic?.memo).toBe('Test topic');
    expect(topic?.adminKeyPresent).toBe(true);
    expect(topic?.submitKeyPresent).toBe(true);
    expect(topic?.createdAt).toBe(createTopicOutput.createdAt);
    expect(topic?.topicId).toBe(createTopicOutput.topicId);
  });
});
