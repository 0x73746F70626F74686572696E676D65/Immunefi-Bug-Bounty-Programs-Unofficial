import type { CoreApi } from '@/core/core-api/core-api.interface';
import type { HederaMirrornodeService } from '@/core/services/mirrornode/hedera-mirrornode-service.interface';

import '@/core/utils/json-serialize';

import {
  makeAliasMock,
  makeArgs,
  makeKmsMock,
  makeLogger,
  makeMirrorMock,
  makeNetworkMock,
  makeStateMock,
} from '@/__tests__/mocks/mocks';
import { assertOutput } from '@/__tests__/utils/assert-output';
import { SupportedNetwork } from '@/core';
import { StateError } from '@/core/errors';
import { KeyAlgorithm } from '@/core/shared/constants';
import { AliasType } from '@/core/types/shared.types';
import { AccountImportOutputSchema } from '@/plugins/account/commands/import';
import { accountImport } from '@/plugins/account/commands/import/handler';
import { AccountStateServiceImpl } from '@/plugins/account/services/account-state.service';

jest.mock('../../services/account-state.service', () => ({
  AccountStateServiceImpl: jest.fn(),
}));

const MockedHelper = AccountStateServiceImpl as jest.Mock;

describe('account plugin - import command (ADR-003)', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('imports account successfully', async () => {
    const logger = makeLogger();
    const saveAccountMock = jest.fn().mockReturnValue(undefined);

    MockedHelper.mockImplementation(() => ({
      hasAccountById: jest.fn().mockReturnValue(false),
      hasAccount: jest.fn().mockReturnValue(false),
      saveAccount: saveAccountMock,
    }));

    const mirrorMock = makeMirrorMock();
    const networkMock = makeNetworkMock();
    const kms = makeKmsMock();
    const alias = makeAliasMock();

    const api: Partial<CoreApi> = {
      mirror: mirrorMock as HederaMirrornodeService,
      network: networkMock,
      kms,
      alias,
      logger,
    };

    const args = makeArgs(
      { ...api, logger },
      {
        key: '0.0.9999:abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890',
        name: 'imported',
      },
    );

    const result = await accountImport(args);

    expect(mirrorMock.getAccountOrThrow).toHaveBeenCalledWith('0.0.9999');
    expect(alias.register).toHaveBeenCalledWith(
      expect.objectContaining({
        alias: 'imported',
        type: AliasType.Account,
        network: SupportedNetwork.TESTNET,
        entityId: '0.0.9999',
        publicKey: expect.any(String),
        keyRefId: 'kr_test123',
      }),
    );
    expect(saveAccountMock).toHaveBeenCalledWith(
      `${SupportedNetwork.TESTNET}:0.0.9999`,
      expect.objectContaining({
        name: 'imported',
        accountId: '0.0.9999',
        network: SupportedNetwork.TESTNET,
        keyRefId: 'kr_test123',
        evmAddress: '0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
      }),
    );

    const output = assertOutput(result.result, AccountImportOutputSchema);
    expect(output.accountId).toBe('0.0.9999');
    expect(output.name).toBe('imported');
    expect(output.type).toBe(KeyAlgorithm.ECDSA);
    expect(output.network).toBe(SupportedNetwork.TESTNET);
    expect(output.evmAddress).toBe(
      '0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
    );
  });

  test('returns failure if account with same name already exists', async () => {
    const logger = makeLogger();

    MockedHelper.mockImplementation(() => ({
      hasAccountById: jest.fn().mockReturnValue(false),
      hasAccount: jest.fn().mockReturnValue(true),
      saveAccount: jest.fn(),
    }));

    const mirrorMock = makeMirrorMock();
    const networkMock = makeNetworkMock();
    const kms = makeKmsMock();
    const alias = makeAliasMock();

    const api: Partial<CoreApi> = {
      mirror: mirrorMock as HederaMirrornodeService,
      network: networkMock,
      kms,
      alias,
      logger,
      state: makeStateMock(),
    };

    const args = makeArgs(
      { ...api, logger },
      {
        key: '0.0.1111:ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',
      },
    );

    await expect(accountImport(args)).rejects.toThrow(StateError);
  });

  test('throws error when mirror.getAccount fails', async () => {
    const logger = makeLogger();

    MockedHelper.mockImplementation(() => ({
      hasAccountById: jest.fn().mockReturnValue(false),
      hasAccount: jest.fn().mockReturnValue(false),
      saveAccount: jest.fn(),
    }));

    const mirrorMock = makeMirrorMock({
      getAccountImpl: jest.fn().mockRejectedValue(new Error('mirror down')),
    });
    const networkMock = makeNetworkMock();
    const kms = makeKmsMock();
    const alias = makeAliasMock();

    const api: Partial<CoreApi> = {
      mirror: mirrorMock as HederaMirrornodeService,
      network: networkMock,
      kms,
      alias,
      logger,
      state: makeStateMock(),
    };

    const args = makeArgs(
      { ...api, logger },
      {
        key: '0.0.2222:eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee',
      },
    );

    await expect(accountImport(args)).rejects.toThrow();
  });
});
