import type { CoreApi } from '@/core/core-api/core-api.interface';
import type { SupportedNetwork } from '@/core/types/shared.types';
import type { AccountBalanceOutput } from '@/plugins/account/commands/balance';
import type { AccountCreateOutput } from '@/plugins/account/commands/create';
import type { AccountViewOutput } from '@/plugins/account/commands/view';
import type { TokenCreateFtOutput } from '@/plugins/token/commands/create-ft';
import type { TokenMintFtOutput } from '@/plugins/token/commands/mint-ft';

import '@/core/utils/json-serialize';

import { STATE_STORAGE_FILE_PATH } from '@/__tests__/test-constants';
import { waitFor } from '@/__tests__/utils/common-utils';
import { setDefaultOperatorForNetwork } from '@/__tests__/utils/network-and-operator-setup';
import { createCoreApi } from '@/core';
import { KeyAlgorithm } from '@/core/shared/constants';
import { SupplyType } from '@/core/types/shared.types';
import { accountBalance, accountCreate, accountView } from '@/plugins/account';
import { tokenCreateFt, tokenMintFt } from '@/plugins/token';

describe('Mint FT Integration Tests', () => {
  let coreApi: CoreApi;
  let network: SupportedNetwork;

  beforeAll(async () => {
    coreApi = createCoreApi(STATE_STORAGE_FILE_PATH);
    await setDefaultOperatorForNetwork(coreApi);
    network = coreApi.network.getCurrentNetwork();
  });

  it('should create a token with supply key, mint tokens to treasury and verify with account balance method', async () => {
    const createAccountArgs: Record<string, unknown> = {
      name: 'account-mint-ft',
      balance: 1,
      'key-type': KeyAlgorithm.ECDSA,
      'auto-associations': 10,
    };
    const createAccountResult = await accountCreate({
      args: createAccountArgs,
      api: coreApi,
    });

    const createAccountOutput =
      createAccountResult.result as AccountCreateOutput;
    expect(createAccountOutput.name).toBe('account-mint-ft');
    expect(createAccountOutput.type).toBe(KeyAlgorithm.ECDSA);
    expect(createAccountOutput.network).toBe(network);

    const viewAccountArgs: Record<string, unknown> = {
      account: 'account-mint-ft',
    };
    const viewAccountResult = await waitFor(
      () => accountView({ args: viewAccountArgs, api: coreApi }),
      (result) => !!(result.result as AccountViewOutput).accountId,
    );
    const viewAccountOutput = viewAccountResult.result as AccountViewOutput;
    expect(viewAccountOutput.accountId).toBe(createAccountOutput.accountId);
    expect(viewAccountOutput.balance).toBe(100000000n);
    expect(viewAccountOutput.evmAddress).toBe(createAccountOutput.evmAddress);
    expect(viewAccountOutput.publicKey).toBe(createAccountOutput.publicKey);

    const createTokenArgs: Record<string, unknown> = {
      tokenName: 'Test Token Mint',
      symbol: 'TTM',
      treasury: 'account-mint-ft',
      initialSupply: '100',
      supplyType: SupplyType.INFINITE,
      supplyKey: [`${process.env.OPERATOR_ID}:${process.env.OPERATOR_KEY}`],
      name: 'test-token-mint',
    };
    const createTokenResult = await tokenCreateFt({
      args: createTokenArgs,
      api: coreApi,
    });
    const createTokenOutput = createTokenResult.result as TokenCreateFtOutput;
    expect(createTokenOutput.network).toBe(network);
    expect(createTokenOutput.decimals).toBe(0);
    expect(createTokenOutput.initialSupply).toBe('100');
    expect(createTokenOutput.name).toBe('Test Token Mint');
    expect(createTokenOutput.alias).toBe('test-token-mint');
    expect(createTokenOutput.treasuryId).toBe(createAccountOutput.accountId);
    expect(createTokenOutput.symbol).toBe('TTM');
    expect(createTokenOutput.supplyType).toBe(SupplyType.INFINITE);

    const accountBalanceBeforeMintArgs: Record<string, unknown> = {
      account: 'account-mint-ft',
      hbarOnly: false,
      token: createTokenOutput.tokenId,
    };
    const accountBalanceBeforeMintOutput = await waitFor(
      () =>
        accountBalance({
          args: accountBalanceBeforeMintArgs,
          api: coreApi,
        }).then((r) => r.result as AccountBalanceOutput),
      (output) => (output.tokenBalances?.length ?? 0) > 0,
    );
    expect(accountBalanceBeforeMintOutput.tokenBalances?.length).toBe(1);
    expect(accountBalanceBeforeMintOutput.tokenBalances?.at(0)?.tokenId).toBe(
      createTokenOutput.tokenId,
    );
    expect(accountBalanceBeforeMintOutput.tokenBalances?.at(0)?.balance).toBe(
      100n,
    );

    const mintFtArgs: Record<string, unknown> = {
      token: createTokenOutput.tokenId,
      amount: '50',
      supplyKey: [`${process.env.OPERATOR_ID}:${process.env.OPERATOR_KEY}`],
    };
    const mintFtResult = await tokenMintFt({
      args: mintFtArgs,
      api: coreApi,
    });
    const mintFtOutput = mintFtResult.result as TokenMintFtOutput;
    expect(mintFtOutput.tokenId).toBe(createTokenOutput.tokenId);
    expect(mintFtOutput.amount).toBe(50n);
    expect(mintFtOutput.network).toBe(network);
    expect(mintFtOutput.transactionId).toBeDefined();

    const accountBalanceAfterMintArgs: Record<string, unknown> = {
      account: 'account-mint-ft',
      hbarOnly: false,
      token: createTokenOutput.tokenId,
    };
    const accountBalanceAfterMintOutput = await waitFor(
      () =>
        accountBalance({
          args: accountBalanceAfterMintArgs,
          api: coreApi,
        }).then((r) => r.result as AccountBalanceOutput),
      (output) => output.tokenBalances?.at(0)?.balance === 150n,
    );
    expect(accountBalanceAfterMintOutput.tokenBalances?.length).toBe(1);
    expect(accountBalanceAfterMintOutput.tokenBalances?.at(0)?.tokenId).toBe(
      createTokenOutput.tokenId,
    );
    expect(accountBalanceAfterMintOutput.tokenBalances?.at(0)?.balance).toBe(
      150n,
    );
  });
});
