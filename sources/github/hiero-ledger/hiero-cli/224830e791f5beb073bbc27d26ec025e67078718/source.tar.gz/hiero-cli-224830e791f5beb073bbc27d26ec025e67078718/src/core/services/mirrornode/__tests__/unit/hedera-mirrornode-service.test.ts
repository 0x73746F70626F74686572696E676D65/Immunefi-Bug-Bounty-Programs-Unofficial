/**
 * Unit tests for HederaMirrornodeServiceDefaultImpl
 * Tests all public methods with success paths, error paths, and edge cases
 */

import { MOCK_CONTRACT_ID } from '@/__tests__/mocks/fixtures';
import {
  createMockContractInfo,
  makeNetworkMock,
} from '@/__tests__/mocks/mocks';
import { NetworkError, NotFoundError, ValidationError } from '@/core/errors';
import { HederaMirrornodeServiceDefaultImpl } from '@/core/services/mirrornode/hedera-mirrornode-service';
import {
  AccountBalanceOperator,
  MirrorNodeKeyType,
} from '@/core/services/mirrornode/types';
import {
  MirrorNodeRequestOrderParameter,
  SupportedNetwork,
} from '@/core/types/shared.types';

import {
  createMockAccountAPIResponse,
  createMockAccountListItemAPIResponse,
  createMockAccountNftsResponse,
  createMockExchangeRateResponse,
  createMockGetAccountsAPIResponse,
  createMockMirrorNodeScheduleByIdJson,
  createMockMirrorNodeTokenByIdJson,
  createMockNftInfo,
  createMockTokenAirdropsResponse,
  createMockTokenBalancesResponse,
  createMockTopicInfo,
  createMockTopicMessage,
  createMockTopicMessagesAPIResponse,
  createMockTransactionDetailsResponse,
} from './mocks';

// Mock fetch globally
global.fetch = jest.fn();

// Mock @hiero-ledger/sdk
jest.mock('@hiero-ledger/sdk');

// Test constants
const TEST_ACCOUNT_ID = '0.0.1234';
const TEST_TOKEN_ID = '0.0.2000';
const TEST_SERIAL_NUMBER = 1;
const TEST_TOPIC_ID = '0.0.3000';
const TEST_SCHEDULE_ID = '0.0.5678';
const TEST_TX_ID = '0.0.1234-1700000000-000000000';

// Network URLs
const TESTNET_BASE_URL = 'https://testnet.mirrornode.hedera.com';
const TESTNET_API_URL = `${TESTNET_BASE_URL}/api/v1`;
const MAINNET_BASE_URL = 'https://mainnet-public.mirrornode.hedera.com';
const MAINNET_API_URL = `${MAINNET_BASE_URL}/api/v1`;

// Timestamps & Values
const TEST_TIMESTAMP = '2024-01-01T12:00:00.000Z';
const TEST_SEQUENCE_NUMBER = 1;

// Setup helper
const setupService = (network: SupportedNetwork = SupportedNetwork.TESTNET) => {
  jest.clearAllMocks();

  const networkService = makeNetworkMock(network);
  const service = new HederaMirrornodeServiceDefaultImpl(networkService);

  return { service, network, networkService };
};

describe('HederaMirrornodeServiceDefaultImpl', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('constructor', () => {
    it('should initialize with testnet LedgerId', () => {
      const { service } = setupService(SupportedNetwork.TESTNET);
      expect(service).toBeDefined();
    });

    it('should initialize with mainnet LedgerId', () => {
      const { service } = setupService(SupportedNetwork.MAINNET);
      expect(service).toBeDefined();
    });

    it('should initialize with previewnet LedgerId', () => {
      const { service } = setupService(SupportedNetwork.PREVIEWNET);
      expect(service).toBeDefined();
    });
  });

  describe('getAccount', () => {
    it('should fetch account successfully', async () => {
      const { service } = setupService(SupportedNetwork.TESTNET);
      const mockResponse = createMockAccountAPIResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getAccount(TEST_ACCOUNT_ID);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/accounts/${TEST_ACCOUNT_ID}`,
      );
      expect(result).not.toBeNull();
      expect(result!.accountId).toBe(TEST_ACCOUNT_ID);
      expect(result!.balance.balance).toBe(mockResponse.balance.balance);
      expect(result!.accountPublicKey).toBe('ed25519_abcd1234');
      expect(result!.evmAddress).toBe(
        '0x1234567890123456789012345678901234567890',
      );
    });

    it('should construct correct URL for different networks', async () => {
      const { service } = setupService(SupportedNetwork.MAINNET);
      const mockResponse = createMockAccountAPIResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      await service.getAccount(TEST_ACCOUNT_ID);

      expect(global.fetch).toHaveBeenCalledWith(
        `${MAINNET_API_URL}/accounts/${TEST_ACCOUNT_ID}`,
      );
    });

    it('should automatically use new network URL after network switch', async () => {
      const { service, networkService } = setupService(
        SupportedNetwork.TESTNET,
      );
      const mockResponse = createMockAccountAPIResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      await service.getAccount(TEST_ACCOUNT_ID);
      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/accounts/${TEST_ACCOUNT_ID}`,
      );

      networkService.getCurrentNetwork = jest
        .fn()
        .mockReturnValue(SupportedNetwork.MAINNET);
      await service.getAccount(TEST_ACCOUNT_ID);
      expect(global.fetch).toHaveBeenCalledWith(
        `${MAINNET_API_URL}/accounts/${TEST_ACCOUNT_ID}`,
      );
    });

    it('should throw error when response has no key field', async () => {
      const { service } = setupService();
      const mockResponse = createMockAccountAPIResponse({ key: undefined });
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      await expect(service.getAccount(TEST_ACCOUNT_ID)).rejects.toThrow(
        NotFoundError,
      );
    });

    it('should handle response without optional evm_address field', async () => {
      const { service } = setupService();
      const mockResponse = createMockAccountAPIResponse({
        evm_address: undefined,
      });
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getAccount(TEST_ACCOUNT_ID);

      expect(result).not.toBeNull();
      expect(result!.evmAddress).toBeUndefined();
    });

    it('should return null on HTTP 404', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });

      const result = await service.getAccount(TEST_ACCOUNT_ID);

      expect(result).toBeNull();
    });

    it('should throw NetworkError on HTTP 400', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 400,
        statusText: 'Bad Request',
      });

      await expect(service.getAccount(TEST_ACCOUNT_ID)).rejects.toThrow(
        NetworkError,
      );
    });

    it('should include mirror node API messages in NetworkError on HTTP 400', async () => {
      const { service } = setupService();
      const apiErrorBody = {
        _status: {
          messages: [
            { message: 'Invalid parameter: account.id' },
            {
              message:
                'Invalid Transaction id. Please use \\shard.realm.num-sss-nnn\\ format where sss are seconds and nnn are nanoseconds',
            },
          ],
        },
      };
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        json: jest.fn().mockResolvedValue(apiErrorBody),
      });

      const error = await service.getAccount(TEST_ACCOUNT_ID).catch((e) => e);

      expect(error).toBeInstanceOf(NetworkError);
      expect(error.context?.apiMessages).toEqual([
        'Invalid parameter: account.id',
        'Invalid Transaction id. Please use \\shard.realm.num-sss-nnn\\ format where sss are seconds and nnn are nanoseconds',
      ]);
      expect(error.getTemplate()).toContain('Detailed error message:');
      expect(error.getTemplate()).toContain('{{#each context.apiMessages}}');
    });

    it('should throw error on HTTP 500', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
      });

      await expect(service.getAccount(TEST_ACCOUNT_ID)).rejects.toThrow(
        NetworkError,
      );
    });

    it('should throw error when account field is missing', async () => {
      const { service } = setupService();
      const mockResponse = createMockAccountAPIResponse({
        account: '',
      });
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      await expect(service.getAccount(TEST_ACCOUNT_ID)).rejects.toThrow(
        NotFoundError,
      );
    });
  });

  describe('getAccountOrThrow', () => {
    it('should return account when getAccount returns valid data', async () => {
      const { service } = setupService();
      const mockResponse = createMockAccountAPIResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getAccountOrThrow(TEST_ACCOUNT_ID);

      expect(result.accountId).toBe(TEST_ACCOUNT_ID);
      expect(result.balance.balance).toBe(mockResponse.balance.balance);
      expect(result.accountPublicKey).toBe('ed25519_abcd1234');
    });

    it('should throw NotFoundError when getAccount returns null (404)', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });

      await expect(service.getAccountOrThrow(TEST_ACCOUNT_ID)).rejects.toThrow(
        NotFoundError,
      );
      await expect(service.getAccountOrThrow(TEST_ACCOUNT_ID)).rejects.toThrow(
        `Account ${TEST_ACCOUNT_ID} not found`,
      );
    });

    it('should propagate NetworkError when getAccount throws (e.g. 400)', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 400,
        statusText: 'Bad Request',
      });

      await expect(service.getAccountOrThrow(TEST_ACCOUNT_ID)).rejects.toThrow(
        NetworkError,
      );
    });
  });

  describe('getAccountTokenBalances', () => {
    it('should fetch token balances without tokenId filter', async () => {
      const { service } = setupService();
      const mockResponse = createMockTokenBalancesResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getAccountTokenBalances(TEST_ACCOUNT_ID);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/accounts/${TEST_ACCOUNT_ID}/tokens?`,
      );
      expect(result.tokens).toHaveLength(1);
      expect(result.tokens[0].token_id).toBe(TEST_TOKEN_ID);
    });

    it('should fetch token balances with tokenId filter', async () => {
      const { service } = setupService();
      const mockResponse = createMockTokenBalancesResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      await service.getAccountTokenBalances(TEST_ACCOUNT_ID, TEST_TOKEN_ID);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/accounts/${TEST_ACCOUNT_ID}/tokens?&token.id=${TEST_TOKEN_ID}`,
      );
    });

    it('should handle empty tokens array', async () => {
      const { service } = setupService();
      const mockResponse = createMockTokenBalancesResponse({ tokens: [] });
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getAccountTokenBalances(TEST_ACCOUNT_ID);

      expect(result.tokens).toHaveLength(0);
    });

    it('should throw error on HTTP 404', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });

      await expect(
        service.getAccountTokenBalances(TEST_ACCOUNT_ID),
      ).rejects.toThrow(NotFoundError);
    });

    it('should throw NetworkError on HTTP 400 with apiMessages', async () => {
      const { service } = setupService();
      const apiErrorBody = {
        _status: {
          messages: [{ message: 'Invalid account id' }],
        },
      };
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        json: jest.fn().mockResolvedValue(apiErrorBody),
      });

      const error = await service
        .getAccountTokenBalances(TEST_ACCOUNT_ID)
        .catch((e) => e);

      expect(error).toBeInstanceOf(NetworkError);
      expect(error.context?.apiMessages).toEqual(['Invalid account id']);
    });
  });

  describe('allowance endpoints', () => {
    it('should fetch HBAR allowances with correct URL', async () => {
      const { service } = setupService();
      const mockResponse = {
        allowances: [
          {
            owner: TEST_ACCOUNT_ID,
            spender: '0.0.5678',
            amount: 100000000,
          },
        ],
        links: { next: null },
      };
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getHbarAllowances(TEST_ACCOUNT_ID);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/accounts/${TEST_ACCOUNT_ID}/allowances/crypto`,
      );
      expect(result.allowances).toHaveLength(1);
      expect(result.allowances[0].amount).toBe(100000000n);
    });

    it('should fetch token allowances with pagination params', async () => {
      const { service } = setupService();
      const mockResponse = {
        allowances: [
          {
            owner: TEST_ACCOUNT_ID,
            spender: '0.0.5678',
            token_id: TEST_TOKEN_ID,
            amount: '1000',
          },
        ],
        links: { next: '/api/v1/accounts/0.0.1234/allowances/tokens?cursor=2' },
      };
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getTokenAllowances(TEST_ACCOUNT_ID, {
        limit: 100,
        cursor: 'abc123',
      });

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/accounts/${TEST_ACCOUNT_ID}/allowances/tokens?limit=100&cursor=abc123`,
      );
      expect(result.links?.next).toBe(
        '/api/v1/accounts/0.0.1234/allowances/tokens?cursor=2',
      );
      expect(result.allowances[0].amount).toBe(1000n);
    });

    it('should reject unsafe numeric allowance amounts', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue({
          allowances: [
            {
              owner: TEST_ACCOUNT_ID,
              spender: '0.0.5678',
              amount: Number.MAX_SAFE_INTEGER + 1,
            },
          ],
          links: { next: null },
        }),
      });

      await expect(service.getHbarAllowances(TEST_ACCOUNT_ID)).rejects.toThrow(
        ValidationError,
      );
    });

    it('should fetch all HBAR allowance pages', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock)
        .mockResolvedValueOnce({
          ok: true,
          json: jest.fn().mockResolvedValue({
            allowances: [
              { owner: TEST_ACCOUNT_ID, spender: '0.0.5678', amount: '1' },
            ],
            links: {
              next: '/api/v1/accounts/0.0.1234/allowances/crypto?cursor=page2',
            },
          }),
        })
        .mockResolvedValueOnce({
          ok: true,
          json: jest.fn().mockResolvedValue({
            allowances: [
              { owner: TEST_ACCOUNT_ID, spender: '0.0.9999', amount: 2 },
            ],
            links: { next: null },
          }),
        });

      const result = await service.getAllHbarAllowances(TEST_ACCOUNT_ID);

      expect(result.allowances.map((allowance) => allowance.amount)).toEqual([
        1n,
        2n,
      ]);
      expect(global.fetch).toHaveBeenNthCalledWith(
        1,
        `${TESTNET_API_URL}/accounts/${TEST_ACCOUNT_ID}/allowances/crypto?limit=100`,
      );
      expect(global.fetch).toHaveBeenNthCalledWith(
        2,
        `${TESTNET_API_URL}/accounts/${TEST_ACCOUNT_ID}/allowances/crypto?limit=100&cursor=page2`,
      );
    });

    it('should throw NetworkError on repeated allowance cursor', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock)
        .mockResolvedValueOnce({
          ok: true,
          json: jest.fn().mockResolvedValue({
            allowances: [],
            links: {
              next: '/api/v1/accounts/0.0.1234/allowances/tokens?cursor=page2',
            },
          }),
        })
        .mockResolvedValueOnce({
          ok: true,
          json: jest.fn().mockResolvedValue({
            allowances: [],
            links: {
              next: '/api/v1/accounts/0.0.1234/allowances/tokens?cursor=page2',
            },
          }),
        });

      await expect(
        service.getAllTokenAllowances(TEST_ACCOUNT_ID),
      ).rejects.toThrow(NetworkError);
    });

    it('should throw NetworkError when allowance pagination limit is exceeded', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockImplementation(() =>
          Promise.resolve({
            allowances: [],
            links: {
              next: `/api/v1/accounts/0.0.1234/allowances/nfts?cursor=${String(
                (global.fetch as jest.Mock).mock.calls.length,
              )}`,
            },
          }),
        ),
      });

      await expect(
        service.getAllNftAllowances(TEST_ACCOUNT_ID),
      ).rejects.toThrow(NetworkError);
      expect(global.fetch).toHaveBeenCalledTimes(100);
    });

    it('should fetch NFT allowances and parse all-serial approval', async () => {
      const { service } = setupService();
      const mockResponse = {
        allowances: [
          {
            owner: TEST_ACCOUNT_ID,
            spender: '0.0.5678',
            token_id: TEST_TOKEN_ID,
            serial_number: null,
            approved_for_all: true,
          },
        ],
        links: { next: null },
      };
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getNftAllowances(TEST_ACCOUNT_ID);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/accounts/${TEST_ACCOUNT_ID}/allowances/nfts`,
      );
      expect(result.allowances[0].approved_for_all).toBe(true);
    });

    it('should throw NotFoundError for allowance HTTP 404', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });

      await expect(service.getHbarAllowances(TEST_ACCOUNT_ID)).rejects.toThrow(
        NotFoundError,
      );
    });
  });

  describe('getAccounts', () => {
    it('should fetch accounts without params and return mapped DTO', async () => {
      const { service } = setupService();
      const mockAccount = createMockAccountListItemAPIResponse();
      const mockResponse = createMockGetAccountsAPIResponse([mockAccount]);
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getAccounts();

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/accounts?balance=false&limit=25&order=asc`,
      );
      expect(result.accounts).toHaveLength(1);
      expect(result.accounts[0].accountId).toBe(TEST_ACCOUNT_ID);
      expect(result.accounts[0].createdTimestamp).toBe(
        mockAccount.created_timestamp,
      );
      expect(result.accounts[0].accountPublicKey).toBe('ed25519_abcd1234');
      expect(result.accounts[0].evmAddress).toBe(
        '0x1234567890123456789012345678901234567890',
      );
      expect(result.accounts[0].balance?.balance).toBe(1000000);
      expect(result.accounts[0].balance?.tokens).toEqual([
        { tokenId: '0.0.2000', balance: 100 },
      ]);
    });

    it('should build correct query string with all params', async () => {
      const { service } = setupService();
      const mockResponse = createMockGetAccountsAPIResponse([]);
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      await service.getAccounts({
        accountBalance: { operator: AccountBalanceOperator.GTE, value: 1000 },
        accountId: TEST_ACCOUNT_ID,
        accountPublicKey:
          '3c3d546321ff6f63d701d2ec5c277095874e19f4a235bee1e6bb19258bf362be',
        balance: false,
        limit: 10,
        order: MirrorNodeRequestOrderParameter.DESC,
      });

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/accounts?account.balance=gte:1000&account.id=0.0.1234&account.publickey=3c3d546321ff6f63d701d2ec5c277095874e19f4a235bee1e6bb19258bf362be&balance=false&limit=10&order=desc`,
      );
    });

    it('should handle single page response (no links.next)', async () => {
      const { service } = setupService();
      const mockAccount = createMockAccountListItemAPIResponse();
      const mockResponse = createMockGetAccountsAPIResponse([mockAccount], {
        links: undefined,
      });
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getAccounts();

      expect(global.fetch).toHaveBeenCalledTimes(1);
      expect(result.accounts).toHaveLength(1);
    });

    it('should handle pagination with links.next', async () => {
      const { service } = setupService();
      const acc1 = createMockAccountListItemAPIResponse({
        account: '0.0.1',
      });
      const acc2 = createMockAccountListItemAPIResponse({
        account: '0.0.2',
      });

      (global.fetch as jest.Mock)
        .mockResolvedValueOnce({
          ok: true,
          json: jest.fn().mockResolvedValue({
            accounts: [acc1],
            links: { next: '/accounts?limit=25&order=asc' },
          }),
        })
        .mockResolvedValueOnce({
          ok: true,
          json: jest.fn().mockResolvedValue({
            accounts: [acc2],
            links: undefined,
          }),
        });

      const result = await service.getAccounts();

      expect(global.fetch).toHaveBeenCalledTimes(2);
      expect(result.accounts).toHaveLength(2);
      expect(result.accounts[0].accountId).toBe('0.0.1');
      expect(result.accounts[1].accountId).toBe('0.0.2');
    });

    it('should stop pagination at 100 pages', async () => {
      const { service } = setupService();

      (global.fetch as jest.Mock).mockImplementation(() =>
        Promise.resolve({
          ok: true,
          json: jest.fn().mockResolvedValue({
            accounts: [createMockAccountListItemAPIResponse()],
            links: { next: '/accounts?next=page' },
          }),
        }),
      );

      const result = await service.getAccounts();

      expect(global.fetch).toHaveBeenCalledTimes(100);
      expect(result.accounts).toHaveLength(100);
    });

    it('should construct next URL correctly: baseUrl + links.next', async () => {
      const { service } = setupService();
      const nextPath = '/api/v1/accounts?limit=25&order=asc&next=token';

      (global.fetch as jest.Mock)
        .mockResolvedValueOnce({
          ok: true,
          json: jest.fn().mockResolvedValue({
            accounts: [createMockAccountListItemAPIResponse()],
            links: { next: nextPath },
          }),
        })
        .mockResolvedValueOnce({
          ok: true,
          json: jest.fn().mockResolvedValue({
            accounts: [createMockAccountListItemAPIResponse()],
            links: undefined,
          }),
        });

      await service.getAccounts();

      expect(global.fetch).toHaveBeenNthCalledWith(
        2,
        `${TESTNET_BASE_URL}${nextPath}`,
      );
    });

    it('should handle account with null balance (balance=false query)', async () => {
      const { service } = setupService();
      const mockAccount = createMockAccountListItemAPIResponse({
        balance: null,
      });
      const mockResponse = createMockGetAccountsAPIResponse([mockAccount]);
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getAccounts({ balance: false });

      expect(result.accounts).toHaveLength(1);
      expect(result.accounts[0].accountId).toBe(mockAccount.account);
      expect(result.accounts[0].balance).toBeUndefined();
    });

    it('should return empty list on HTTP 404', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });
      const result = await service.getAccounts();
      expect(result.accounts).toHaveLength(0);
    });

    it('should throw NetworkError on HTTP 400 with apiMessages', async () => {
      const { service } = setupService();
      const apiErrorBody = {
        _status: {
          messages: [{ message: 'Invalid query parameter' }],
        },
      };
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        json: jest.fn().mockResolvedValue(apiErrorBody),
      });

      const error = await service.getAccounts().catch((e) => e);

      expect(error).toBeInstanceOf(NetworkError);
      expect(error.context?.apiMessages).toEqual(['Invalid query parameter']);
    });

    it('should handle empty accounts array', async () => {
      const { service } = setupService();
      const mockResponse = createMockGetAccountsAPIResponse([]);
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getAccounts();

      expect(result.accounts).toHaveLength(0);
    });

    it('should map account with null key correctly', async () => {
      const { service } = setupService();
      const mockAccount = createMockAccountListItemAPIResponse({
        key: null,
      });
      const mockResponse = createMockGetAccountsAPIResponse([mockAccount]);
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getAccounts();

      expect(result.accounts[0].accountId).toBe(TEST_ACCOUNT_ID);
      expect(result.accounts[0].accountPublicKey).toBeUndefined();
      expect(result.accounts[0].keyAlgorithm).toBeUndefined();
    });

    it('should map account with key and keyAlgorithm', async () => {
      const { service } = setupService();
      const mockAccount = createMockAccountListItemAPIResponse({
        key: {
          _type: MirrorNodeKeyType.ECDSA_SECP256K1,
          key: 'ecdsa_key_123',
        },
      });
      const mockResponse = createMockGetAccountsAPIResponse([mockAccount]);
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getAccounts();

      expect(result.accounts[0].accountPublicKey).toBe('ecdsa_key_123');
      expect(result.accounts[0].keyAlgorithm).toBeDefined();
    });
  });

  describe('getTopicMessage', () => {
    it('should fetch single message with correct URL', async () => {
      const { service } = setupService();
      const mockMessage = createMockTopicMessage();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockMessage),
      });

      const result = await service.getTopicMessage({
        topicId: TEST_TOPIC_ID,
        sequenceNumber: TEST_SEQUENCE_NUMBER,
      });

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/topics/${TEST_TOPIC_ID}/messages/${TEST_SEQUENCE_NUMBER}`,
      );
      expect(result.topic_id).toBe(TEST_TOPIC_ID);
      expect(result.sequence_number).toBe(TEST_SEQUENCE_NUMBER);
    });
  });

  describe('getTopicMessages', () => {
    it('should fetch messages without filter', async () => {
      const { service } = setupService();
      const mockMessages = [createMockTopicMessage()];
      const mockResponse = createMockTopicMessagesAPIResponse(mockMessages);
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getTopicMessages({ topicId: TEST_TOPIC_ID });

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/topics/${TEST_TOPIC_ID}/messages?order=desc&limit=100`,
      );
      expect(result.messages).toHaveLength(1);
      expect(result.topicId).toBe(TEST_TOPIC_ID);
    });

    it('should fetch messages with filter', async () => {
      const { service } = setupService();
      const mockMessages = [createMockTopicMessage()];
      const mockResponse = createMockTopicMessagesAPIResponse(mockMessages);
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      await service.getTopicMessages({
        topicId: TEST_TOPIC_ID,
        filters: [{ field: 'sequenceNumber', operation: 'gt', value: 10 }],
      });

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/topics/${TEST_TOPIC_ID}/messages?sequenceNumber=gt:10&order=desc&limit=100`,
      );
    });

    it('should handle single page response (no links.next)', async () => {
      const { service } = setupService();
      const mockMessages = [createMockTopicMessage()];
      const mockResponse = createMockTopicMessagesAPIResponse(mockMessages, {
        links: undefined,
      });
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getTopicMessages({ topicId: TEST_TOPIC_ID });

      expect(global.fetch).toHaveBeenCalledTimes(1);
      expect(result.messages).toHaveLength(1);
    });

    it('should handle pagination with links.next', async () => {
      const { service } = setupService();
      const msgs1 = [createMockTopicMessage({ sequence_number: 1 })];
      const msgs2 = [createMockTopicMessage({ sequence_number: 2 })];

      (global.fetch as jest.Mock)
        .mockResolvedValueOnce({
          ok: true,
          json: jest.fn().mockResolvedValue({
            messages: msgs1,
            links: { next: '/topics/0.0.3000/messages?timestamp=lt:123' },
          }),
        })
        .mockResolvedValueOnce({
          ok: true,
          json: jest.fn().mockResolvedValue({
            messages: msgs2,
            links: undefined,
          }),
        });

      const result = await service.getTopicMessages({ topicId: TEST_TOPIC_ID });

      expect(global.fetch).toHaveBeenCalledTimes(2);
      expect(result.messages).toHaveLength(2);
      expect(result.messages[0].sequence_number).toBe(1);
      expect(result.messages[1].sequence_number).toBe(2);
    });

    it('should stop pagination at 100 pages', async () => {
      const { service } = setupService();

      (global.fetch as jest.Mock).mockImplementation(() =>
        Promise.resolve({
          ok: true,
          json: jest.fn().mockResolvedValue({
            messages: [createMockTopicMessage()],
            links: { next: '/topics/0.0.3000/messages?next=page' },
          }),
        }),
      );

      const result = await service.getTopicMessages({ topicId: TEST_TOPIC_ID });

      expect(global.fetch).toHaveBeenCalledTimes(100);
      expect(result.messages).toHaveLength(100);
    });

    it('should construct next URL correctly: baseUrl + links.next', async () => {
      const { service } = setupService();
      const nextPath = '/api/v1/topics/0.0.3000/messages?timestamp=lt:123';

      (global.fetch as jest.Mock)
        .mockResolvedValueOnce({
          ok: true,
          json: jest.fn().mockResolvedValue({
            messages: [createMockTopicMessage()],
            links: { next: nextPath },
          }),
        })
        .mockResolvedValueOnce({
          ok: true,
          json: jest.fn().mockResolvedValue({
            messages: [createMockTopicMessage()],
            links: undefined,
          }),
        });

      await service.getTopicMessages({ topicId: TEST_TOPIC_ID });

      expect(global.fetch).toHaveBeenNthCalledWith(
        2,
        `${TESTNET_BASE_URL}${nextPath}`,
      );
    });

    it('should return empty messages on HTTP 404', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });

      const result = await service.getTopicMessages({
        topicId: TEST_TOPIC_ID,
      });

      expect(result.messages).toHaveLength(0);
      expect(result.topicId).toBe(TEST_TOPIC_ID);
    });

    it('should throw NetworkError on HTTP 400 with apiMessages', async () => {
      const { service } = setupService();
      const apiErrorBody = {
        _status: {
          messages: [{ message: 'Invalid topic id' }],
        },
      };
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        json: jest.fn().mockResolvedValue(apiErrorBody),
      });

      const error = await service
        .getTopicMessages({ topicId: TEST_TOPIC_ID })
        .catch((e) => e);

      expect(error).toBeInstanceOf(NetworkError);
      expect(error.context?.apiMessages).toEqual(['Invalid topic id']);
    });

    it('should handle empty messages array', async () => {
      const { service } = setupService();
      const mockResponse = createMockTopicMessagesAPIResponse([]);
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getTopicMessages({ topicId: TEST_TOPIC_ID });

      expect(result.messages).toHaveLength(0);
    });
  });

  describe('getTokenInfo', () => {
    it('should fetch token info with correct URL', async () => {
      const { service } = setupService();
      const mockJson = createMockMirrorNodeTokenByIdJson();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockJson),
      });

      const result = await service.getTokenInfo(TEST_TOKEN_ID);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/tokens/${TEST_TOKEN_ID}`,
      );
      expect(result.token_id).toBe(TEST_TOKEN_ID);
      expect(result.symbol).toBe('TEST');
      expect(result.treasury_account_id).toBe(TEST_ACCOUNT_ID);
    });

    it('should throw error on HTTP 404', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });

      await expect(service.getTokenInfo(TEST_TOKEN_ID)).rejects.toThrow(
        NotFoundError,
      );
    });
  });

  describe('getScheduled', () => {
    it('should fetch schedule info with correct URL', async () => {
      const { service } = setupService();
      const mockJson = createMockMirrorNodeScheduleByIdJson({
        schedule_id: TEST_SCHEDULE_ID,
      });
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockJson),
      });

      const result = await service.getScheduled(TEST_SCHEDULE_ID);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/schedules/${TEST_SCHEDULE_ID}`,
      );
      expect(result.schedule_id).toBe(TEST_SCHEDULE_ID);
      expect(result.creator_account_id).toBe(TEST_ACCOUNT_ID);
      expect(result.payer_account_id).toBe(TEST_ACCOUNT_ID);
      expect(result.wait_for_expiry).toBe(false);
    });

    it('should throw error on HTTP 404', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });

      await expect(service.getScheduled(TEST_SCHEDULE_ID)).rejects.toThrow(
        NotFoundError,
      );
    });

    it('should work with mainnet network', async () => {
      const { service } = setupService(SupportedNetwork.MAINNET);
      const mockJson = createMockMirrorNodeScheduleByIdJson();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockJson),
      });

      await service.getScheduled(TEST_SCHEDULE_ID);

      expect(global.fetch).toHaveBeenCalledWith(
        `${MAINNET_API_URL}/schedules/${TEST_SCHEDULE_ID}`,
      );
    });
  });

  describe('getNftInfo', () => {
    it('should fetch NFT info with correct URL', async () => {
      const { service } = setupService();
      const mockNftInfo = createMockNftInfo();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockNftInfo),
      });

      const result = await service.getNftInfo(
        TEST_TOKEN_ID,
        TEST_SERIAL_NUMBER,
      );

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/tokens/${TEST_TOKEN_ID}/nfts/${TEST_SERIAL_NUMBER}`,
      );
      expect(result.token_id).toBe(TEST_TOKEN_ID);
      expect(result.serial_number).toBe(TEST_SERIAL_NUMBER);
      expect(result.account_id).toBe(TEST_ACCOUNT_ID);
    });

    it('should throw error on HTTP 404', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });

      await expect(
        service.getNftInfo(TEST_TOKEN_ID, TEST_SERIAL_NUMBER),
      ).rejects.toThrow(NotFoundError);
    });

    it('should work with mainnet network', async () => {
      const { service } = setupService(SupportedNetwork.MAINNET);
      const mockNftInfo = createMockNftInfo();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockNftInfo),
      });

      await service.getNftInfo(TEST_TOKEN_ID, TEST_SERIAL_NUMBER);

      expect(global.fetch).toHaveBeenCalledWith(
        `${MAINNET_API_URL}/tokens/${TEST_TOKEN_ID}/nfts/${TEST_SERIAL_NUMBER}`,
      );
    });
  });

  describe('getAccountNfts', () => {
    it('should fetch account NFTs with default limit', async () => {
      const { service } = setupService();
      const mockResponse = createMockAccountNftsResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getAccountNfts(TEST_ACCOUNT_ID);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/accounts/${TEST_ACCOUNT_ID}/nfts?limit=100`,
      );
      expect(result.nfts).toHaveLength(1);
      expect(result.nfts[0].token_id).toBe(TEST_TOKEN_ID);
      expect(result.nfts[0].serial_number).toBe(TEST_SERIAL_NUMBER);
    });

    it('should fetch account NFTs with custom limit', async () => {
      const { service } = setupService();
      const mockResponse = createMockAccountNftsResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      await service.getAccountNfts(TEST_ACCOUNT_ID, 50);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/accounts/${TEST_ACCOUNT_ID}/nfts?limit=50`,
      );
    });

    it('should handle empty nfts array', async () => {
      const { service } = setupService();
      const mockResponse = createMockAccountNftsResponse({ nfts: [] });
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getAccountNfts(TEST_ACCOUNT_ID);

      expect(result.nfts).toHaveLength(0);
    });

    it('should include truncation info when links.next is present', async () => {
      const { service } = setupService();
      const mockResponse = createMockAccountNftsResponse({
        links: { next: '/api/v1/accounts/0.0.1234/nfts?limit=100&cursor=xyz' },
      });
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.getAccountNfts(TEST_ACCOUNT_ID);

      expect(result.links?.next).toBeTruthy();
    });

    it('should throw NotFoundError on HTTP 404', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });

      await expect(service.getAccountNfts(TEST_ACCOUNT_ID)).rejects.toThrow(
        NotFoundError,
      );
    });

    it('should throw NetworkError on network failure', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockRejectedValue(new Error('Network error'));

      await expect(service.getAccountNfts(TEST_ACCOUNT_ID)).rejects.toThrow(
        NetworkError,
      );
    });
  });

  describe('getTopicInfo', () => {
    it('should fetch topic info with correct URL', async () => {
      const { service } = setupService();
      const mockTopicInfo = createMockTopicInfo();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockTopicInfo),
      });

      const result = await service.getTopicInfo(TEST_TOPIC_ID);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/topics/${TEST_TOPIC_ID}`,
      );
      expect(result.topic_id).toBe(TEST_TOPIC_ID);
    });

    it('should throw error on HTTP 404', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });

      await expect(service.getTopicInfo(TEST_TOPIC_ID)).rejects.toThrow(
        NotFoundError,
      );
    });
  });

  describe('getTransactionRecord', () => {
    it('should fetch transaction without nonce', async () => {
      const { service } = setupService();
      const mockTxResponse = createMockTransactionDetailsResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockTxResponse),
      });

      const result = await service.getTransactionRecord(TEST_TX_ID);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/transactions/${TEST_TX_ID}`,
      );
      expect(result.transactions[0].transaction_id).toBe(TEST_TX_ID);
    });

    it('should fetch transaction with nonce parameter', async () => {
      const { service } = setupService();
      const mockTxResponse = createMockTransactionDetailsResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockTxResponse),
      });

      await service.getTransactionRecord(TEST_TX_ID, 1);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/transactions/${TEST_TX_ID}?nonce=1`,
      );
    });

    it('should handle nonce = 0 (falsy but valid)', async () => {
      const { service } = setupService();
      const mockTxResponse = createMockTransactionDetailsResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockTxResponse),
      });

      await service.getTransactionRecord(TEST_TX_ID, 0);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/transactions/${TEST_TX_ID}?nonce=0`,
      );
    });

    it('should throw error on HTTP 404', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });

      await expect(service.getTransactionRecord(TEST_TX_ID)).rejects.toThrow(
        NotFoundError,
      );
    });
  });

  describe('getContractInfo', () => {
    it('should fetch contract info with correct URL', async () => {
      const { service } = setupService();
      const mockContractInfo = createMockContractInfo();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockContractInfo),
      });

      const result = await service.getContractInfo(MOCK_CONTRACT_ID);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/contracts/${MOCK_CONTRACT_ID}`,
      );
      expect(result.contract_id).toBe(MOCK_CONTRACT_ID);
    });

    it('should throw error on HTTP 404', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });

      await expect(service.getContractInfo(MOCK_CONTRACT_ID)).rejects.toThrow(
        NotFoundError,
      );
    });
  });

  describe('getPendingAirdrops', () => {
    it('should fetch pending airdrops with correct URL', async () => {
      const { service } = setupService();
      const mockAirdrops = createMockTokenAirdropsResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockAirdrops),
      });

      const result = await service.getPendingAirdrops(TEST_ACCOUNT_ID);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/accounts/${TEST_ACCOUNT_ID}/airdrops/pending`,
      );
      expect(result.airdrops).toHaveLength(1);
    });

    it('should handle empty airdrops array', async () => {
      const { service } = setupService();
      const mockAirdrops = createMockTokenAirdropsResponse({ airdrops: [] });
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockAirdrops),
      });

      const result = await service.getPendingAirdrops(TEST_ACCOUNT_ID);

      expect(result.airdrops).toHaveLength(0);
    });

    it('should throw error on HTTP 404', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });

      await expect(service.getPendingAirdrops(TEST_ACCOUNT_ID)).rejects.toThrow(
        NotFoundError,
      );
    });

    it('should append limit and cursor as query params', async () => {
      const { service } = setupService();
      const mockAirdrops = createMockTokenAirdropsResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockAirdrops),
      });

      await service.getPendingAirdrops(TEST_ACCOUNT_ID, {
        limit: 100,
        cursor: 'abc123',
      });

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/accounts/${TEST_ACCOUNT_ID}/airdrops/pending?limit=100&cursor=abc123`,
      );
    });
  });

  describe('getOutstandingAirdrops', () => {
    it('should fetch outstanding airdrops with correct URL', async () => {
      const { service } = setupService();
      const mockAirdrops = createMockTokenAirdropsResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockAirdrops),
      });

      const result = await service.getOutstandingAirdrops(TEST_ACCOUNT_ID);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/accounts/${TEST_ACCOUNT_ID}/airdrops/outstanding`,
      );
      expect(result.airdrops).toHaveLength(1);
    });

    it('should handle empty airdrops array', async () => {
      const { service } = setupService();
      const mockAirdrops = createMockTokenAirdropsResponse({ airdrops: [] });
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockAirdrops),
      });

      const result = await service.getOutstandingAirdrops(TEST_ACCOUNT_ID);

      expect(result.airdrops).toHaveLength(0);
    });

    it('should throw error on HTTP 404', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });

      await expect(
        service.getOutstandingAirdrops(TEST_ACCOUNT_ID),
      ).rejects.toThrow(NotFoundError);
    });
  });

  describe('getExchangeRate', () => {
    it('should fetch exchange rate without timestamp', async () => {
      const { service } = setupService();
      const mockExchangeRate = createMockExchangeRateResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockExchangeRate),
      });

      const result = await service.getExchangeRate();

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/network/exchangerate`,
      );
      expect(result.current_rate.hbar_equivalent).toBe(1);
    });

    it('should fetch exchange rate with timestamp', async () => {
      const { service } = setupService();
      const mockExchangeRate = createMockExchangeRateResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockExchangeRate),
      });

      await service.getExchangeRate(TEST_TIMESTAMP);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/network/exchangerate?timestamp=${encodeURIComponent(TEST_TIMESTAMP)}`,
      );
    });

    it('should encode timestamp with encodeURIComponent', async () => {
      const { service } = setupService();
      const timestampWithSpecialChars = '2024-01-01T12:00:00+00:00';
      const mockExchangeRate = createMockExchangeRateResponse();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockExchangeRate),
      });

      await service.getExchangeRate(timestampWithSpecialChars);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/network/exchangerate?timestamp=${encodeURIComponent(timestampWithSpecialChars)}`,
      );
    });

    it('should throw error on HTTP 404', async () => {
      const { service } = setupService();
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });

      await expect(service.getExchangeRate()).rejects.toThrow(NetworkError);
    });
  });

  describe('postContractCall', () => {
    it('should POST contract call with correct URL, headers and body and return result', async () => {
      const { service } = setupService();
      const requestBody = {
        to: '0x1234567890123456789012345678901234567890',
        data: '0xabcdef',
        gas: 1_500_000,
      };
      const mockResponse = { result: '0xabcdef1234567890' };

      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue(mockResponse),
      });

      const result = await service.postContractCall(requestBody);

      expect(global.fetch).toHaveBeenCalledWith(
        `${TESTNET_API_URL}/contracts/call`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestBody),
        },
      );
      expect(result).toEqual(mockResponse);
    });

    it('should throw error when mirror node returns non-ok response', async () => {
      const { service } = setupService();
      const requestBody = {
        to: '0x1234567890123456789012345678901234567890',
      };

      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
      });

      await expect(service.postContractCall(requestBody)).rejects.toThrow(
        NetworkError,
      );
    });
  });
});
