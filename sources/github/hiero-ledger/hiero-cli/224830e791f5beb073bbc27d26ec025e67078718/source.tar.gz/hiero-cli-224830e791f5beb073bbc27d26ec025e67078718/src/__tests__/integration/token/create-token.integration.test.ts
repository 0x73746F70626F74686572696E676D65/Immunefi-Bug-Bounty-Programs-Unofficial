import type { CoreApi } from '@/core/core-api/core-api.interface';
import type { SupportedNetwork } from '@/core/types/shared.types';
import type { AccountBalanceOutput } from '@/plugins/account/commands/balance';
import type { AccountCreateOutput } from '@/plugins/account/commands/create';
import type { AccountViewOutput } from '@/plugins/account/commands/view';
import type { TokenCreateFtOutput } from '@/plugins/token/commands/create-ft';

import '@/core/utils/json-serialize';

import { STATE_STORAGE_FILE_PATH } from '@/__tests__/test-constants';
import { waitFor } from '@/__tests__/utils/common-utils';
import { setDefaultOperatorForNetwork } from '@/__tests__/utils/network-and-operator-setup';
import { createCoreApi } from '@/core';
import { KeyAlgorithm } from '@/core/shared/constants';
import { SupplyType } from '@/core/types/shared.types';
import { accountBalance, accountCreate, accountView } from '@/plugins/account';
import { tokenCreateFt } from '@/plugins/token';

describe('Create Token Integration Tests', () => {
  let coreApi: CoreApi;
  let network: SupportedNetwork;

  beforeAll(async () => {
    coreApi = createCoreApi(STATE_STORAGE_FILE_PATH);
    await setDefaultOperatorForNetwork(coreApi);
    network = coreApi.network.getCurrentNetwork();
  });
  it('should create a token and verify with account balance method', async () => {
    const createAccountArgs: Record<string, unknown> = {
      name: 'account-create-token',
      balance: 1,
      'key-type': KeyAlgorithm.ECDSA,
      'auto-associations': 10,
    };
    const createAccountResult = await accountCreate({
      args: createAccountArgs,
      api: coreApi,
    });

    const createAccountOutput =
      createAccountResult.result as AccountCreateOutput;
    expect(createAccountOutput.name).toBe('account-create-token');
    expect(createAccountOutput.type).toBe(KeyAlgorithm.ECDSA);
    expect(createAccountOutput.network).toBe(network);

    const viewAccountArgs: Record<string, unknown> = {
      account: 'account-create-token',
    };
    const viewAccountResult = await waitFor(
      () => accountView({ args: viewAccountArgs, api: coreApi }),
      (result) => !!(result.result as AccountViewOutput).accountId,
    );
    const viewAccountOutput = viewAccountResult.result as AccountViewOutput;
    expect(viewAccountOutput.accountId).toBe(createAccountOutput.accountId);
    expect(viewAccountOutput.balance).toBe(100000000n); // result in tinybars
    expect(viewAccountOutput.evmAddress).toBe(createAccountOutput.evmAddress);
    expect(viewAccountOutput.publicKey).toBe(createAccountOutput.publicKey);

    const createTokenArgs: Record<string, unknown> = {
      tokenName: 'Test Token',
      symbol: 'TT',
      treasury: 'account-create-token',
      initialSupply: '10',
      supplyType: SupplyType.FINITE,
      maxSupply: '100',
      adminKey: ['account-create-token'],
      name: 'test-token',
    };
    const createTokenResult = await tokenCreateFt({
      args: createTokenArgs,
      api: coreApi,
    });
    const createTokenOutput = createTokenResult.result as TokenCreateFtOutput;
    expect(createTokenOutput.network).toBe(network);
    expect(createTokenOutput.decimals).toBe(0);
    expect(createTokenOutput.initialSupply).toBe('10');
    expect(createTokenOutput.name).toBe('Test Token');
    expect(createTokenOutput.alias).toBe('test-token');
    expect(createTokenOutput.treasuryId).toBe(viewAccountOutput.accountId);
    expect(createTokenOutput.symbol).toBe('TT');
    expect(createTokenOutput.supplyType).toBe(SupplyType.FINITE);

    const accountBalanceArgs: Record<string, unknown> = {
      account: 'account-create-token',
      hbarOnly: false,
      token: createTokenOutput.tokenId,
    };
    const accountBalanceResult = await waitFor(
      () => accountBalance({ args: accountBalanceArgs, api: coreApi }),
      (result) =>
        (result.result as AccountBalanceOutput).tokenBalances?.length === 1,
    );
    const accountBalanceOutput =
      accountBalanceResult.result as AccountBalanceOutput;
    expect(accountBalanceOutput.tokenBalances?.length).toBe(1);
    expect(accountBalanceOutput.tokenBalances?.at(0)?.tokenId).toBe(
      createTokenOutput.tokenId,
    );
    expect(accountBalanceOutput.tokenBalances?.at(0)?.balance).toBe(
      BigInt(createTokenOutput.initialSupply),
    );
  });
});
