import type { CoreApi } from '@/core/core-api/core-api.interface';
import type { SupportedNetwork } from '@/core/types/shared.types';
import type { TokenCreateFtOutput } from '@/plugins/token/commands/create-ft';
import type { TokenImportOutput } from '@/plugins/token/commands/import';
import type { TokenListOutput } from '@/plugins/token/commands/list';

import '@/core/utils/json-serialize';

import { STATE_STORAGE_FILE_PATH } from '@/__tests__/test-constants';
import { waitFor } from '@/__tests__/utils/common-utils';
import { setDefaultOperatorForNetwork } from '@/__tests__/utils/network-and-operator-setup';
import { createCoreApi } from '@/core';
import { SupplyType } from '@/core/types/shared.types';
import {
  tokenCreateFt,
  tokenDelete,
  tokenImport,
  tokenList,
} from '@/plugins/token';
import { TOKEN_NAMESPACE } from '@/plugins/token/constants';

describe('Import Token Integration Tests', () => {
  const TOKEN_NAME = 'TokenImport';

  let coreApi: CoreApi;
  let network: SupportedNetwork;
  let tokenId: string;

  beforeAll(async () => {
    coreApi = createCoreApi(STATE_STORAGE_FILE_PATH);
    await setDefaultOperatorForNetwork(coreApi);
    network = coreApi.network.getCurrentNetwork();

    const createTokenArgs: Record<string, unknown> = {
      tokenName: TOKEN_NAME,
      symbol: 'TIMP',
      initialSupply: '10',
      supplyType: SupplyType.INFINITE,
      name: `token-import-${Date.now()}`,
      adminKey: [`${process.env.OPERATOR_ID}:${process.env.OPERATOR_KEY}`],
    };
    const createTokenResult = await tokenCreateFt({
      args: createTokenArgs,
      api: coreApi,
    });

    const createTokenOutput = createTokenResult.result as TokenCreateFtOutput;
    tokenId = createTokenOutput.tokenId;
    coreApi.state.delete(
      TOKEN_NAMESPACE,
      `${coreApi.network.getCurrentNetwork()}:${tokenId}`,
    );

    await waitFor(
      () => tokenImport({ args: { token: tokenId }, api: coreApi }),
      (result) => !!(result.result as TokenImportOutput).tokenId,
    );
    await tokenDelete({
      args: { token: tokenId, stateOnly: true },
      api: coreApi,
    });
  });

  afterEach(async () => {
    await tokenDelete({
      args: { token: tokenId, stateOnly: true },
      api: coreApi,
    });
  });

  afterAll(async () => {
    await tokenDelete({
      args: { token: tokenId },
      api: coreApi,
    });
  });

  it('should import a token by ID and verify with list', async () => {
    const importTokenArgs: Record<string, unknown> = {
      token: tokenId,
    };
    const importTokenResult = await tokenImport({
      args: importTokenArgs,
      api: coreApi,
    });

    const importTokenOutput = importTokenResult.result as TokenImportOutput;
    expect(importTokenOutput.tokenId).toBe(tokenId);
    expect(importTokenOutput.name).toBe(TOKEN_NAME);
    expect(importTokenOutput.network).toBe(network);
    expect(importTokenOutput.alias).toBeUndefined();

    const listTokenArgs: Record<string, unknown> = {};
    const listTokenResult = await tokenList({
      args: listTokenArgs,
      api: coreApi,
    });
    const listTokenOutput = listTokenResult.result as TokenListOutput;
    const token = listTokenOutput.tokens.find((t) => t.tokenId === tokenId);
    expect(token).not.toBeNull();
    expect(token?.tokenId).toBe(tokenId);
    expect(token?.network).toBe(network);
  });

  it('should import a token with alias and verify with list', async () => {
    const alias = `imported-token-${Date.now()}`;
    const importTokenArgs: Record<string, unknown> = {
      token: tokenId,
      name: alias,
    };
    const importTokenResult = await tokenImport({
      args: importTokenArgs,
      api: coreApi,
    });

    const importTokenOutput = importTokenResult.result as TokenImportOutput;
    expect(importTokenOutput.tokenId).toBe(tokenId);
    expect(importTokenOutput.name).toBe(TOKEN_NAME);
    expect(importTokenOutput.alias).toBe(alias);
    expect(importTokenOutput.network).toBe(network);

    const listTokenArgs: Record<string, unknown> = {};
    const listTokenResult = await tokenList({
      args: listTokenArgs,
      api: coreApi,
    });
    const listTokenOutput = listTokenResult.result as TokenListOutput;
    const token = listTokenOutput.tokens.find((t) => t.tokenId === tokenId);
    expect(token).not.toBeNull();
    expect(token?.name).toBe(TOKEN_NAME);
  });
});
