/**
 * Contract ERC20 Name Command Exports
 * For use by tests and external consumers
 */
export { contractErc20Name, ContractErc20NameCommand } from './handler';
export type { ContractErc20CallNameOutput } from './output';
export {
  CONTRACT_ERC20_CALL_NAME_CREATE_TEMPLATE,
  ContractErc20CallNameOutputSchema,
} from './output';
