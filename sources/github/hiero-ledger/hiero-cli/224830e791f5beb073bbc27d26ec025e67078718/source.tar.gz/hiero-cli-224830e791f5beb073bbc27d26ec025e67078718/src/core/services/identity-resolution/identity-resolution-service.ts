import type { AliasService, HederaMirrornodeService } from '@/core';
import type { IdentityResolutionService } from '@/core/services/identity-resolution/identity-resolution-service.interface';
import type {
  AccountResolutionParams,
  AccountResolutionResult,
  ContractResolutionParams,
  ContractResolutionResult,
  ReferenceResolutionParams,
  ReferenceResolutionResult,
} from '@/core/services/identity-resolution/types';

import { StateError } from '@/core/errors';
import { AliasType, EntityReferenceType } from '@/core/types/shared.types';

export class IdentityResolutionServiceImpl implements IdentityResolutionService {
  private readonly aliasService: AliasService;
  private readonly mirrorService: HederaMirrornodeService;

  constructor(
    aliasService: AliasService,
    mirrorService: HederaMirrornodeService,
  ) {
    this.aliasService = aliasService;
    this.mirrorService = mirrorService;
  }

  async resolveAccount(
    params: AccountResolutionParams,
  ): Promise<AccountResolutionResult> {
    const accountReferenceResolutionResult =
      this.resolveReferenceToEntityOrEvmAddress({
        entityReference: params.accountReference,
        referenceType: params.type,
        network: params.network,
        aliasType: AliasType.Account,
      });
    const accountInfo = await this.mirrorService.getAccountOrThrow(
      accountReferenceResolutionResult.entityIdOrEvmAddress,
    );
    return {
      accountId: accountInfo.accountId,
      accountPublicKey: accountInfo.accountPublicKey,
      evmAddress: accountInfo.evmAddress,
    };
  }

  async resolveContract(
    params: ContractResolutionParams,
  ): Promise<ContractResolutionResult> {
    const contractReferenceResolutionResult =
      this.resolveReferenceToEntityOrEvmAddress({
        entityReference: params.contractReference,
        referenceType: params.type,
        network: params.network,
        aliasType: AliasType.Contract,
      });
    const contractInfo = await this.mirrorService.getContractInfo(
      contractReferenceResolutionResult.entityIdOrEvmAddress,
    );
    return {
      contractId: contractInfo.contract_id,
      evmAddress: contractInfo.evm_address,
    };
  }

  resolveReferenceToEntityOrEvmAddress(
    params: ReferenceResolutionParams,
  ): ReferenceResolutionResult {
    const entityIdOrEvmAddress =
      params.referenceType === EntityReferenceType.ALIAS
        ? this.aliasService.resolveOrThrow(
            params.entityReference,
            params.aliasType,
            params.network,
          ).entityId
        : params.entityReference;
    if (!entityIdOrEvmAddress) {
      throw new StateError(
        `Entity ${params.entityReference} is missing an entity ID in its alias record`,
        {
          context: {
            entityReference: params.entityReference,
            aliasType: params.aliasType,
          },
        },
      );
    }
    return { entityIdOrEvmAddress };
  }
}
