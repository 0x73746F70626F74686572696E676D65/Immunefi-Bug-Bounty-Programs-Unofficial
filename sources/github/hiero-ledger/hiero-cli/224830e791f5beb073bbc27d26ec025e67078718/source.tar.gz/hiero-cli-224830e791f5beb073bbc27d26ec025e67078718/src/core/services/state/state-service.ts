/**
 * Zustand Generic State Service Implementation
 * Rich state management with actions, selectors, and subscriptions
 */
import type { Logger } from '@/core/services/logger/logger-service.interface';
import type { StateService } from './state-service.interface';

import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';
import { create } from 'zustand';
import { createJSONStorage, devtools, persist } from 'zustand/middleware';

import { FileError } from '@/core/errors';

/**
 * Namespace Store Interface
 */
interface NamespaceStore {
  data: Record<string, unknown>;
  loading: boolean;
  error: string | null;

  // Actions
  setItem: (key: string, value: unknown) => void;
  getItem: (key: string) => unknown;
  removeItem: (key: string) => void;
  clear: () => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;

  // Selectors
  list: () => unknown[];
  has: (key: string) => boolean;
  count: () => number;
  getKeys: () => string[];
}

/**
 * Create a Zustand store for a namespace
 */
function createNamespaceStore(
  namespace: string,
  logger: Logger,
  storageDir: string,
) {
  return create<NamespaceStore>()(
    devtools(
      persist(
        (set, get) => ({
          data: {},
          loading: false,
          error: null,

          setItem: (key: string, value: unknown) => {
            logger.debug(`[ZUSTAND:${namespace}] Setting key: ${key}`);
            set((state) => ({
              data: { ...state.data, [key]: value },
              error: null,
            }));
          },

          getItem: (key: string) => {
            logger.debug(`[ZUSTAND:${namespace}] Getting key: ${key}`);
            return get().data[key];
          },

          removeItem: (key: string) => {
            logger.debug(`[ZUSTAND:${namespace}] Removing key: ${key}`);
            set((state) => {
              const rest = { ...state.data } as Record<string, unknown>;
              delete rest[key];
              return { data: rest };
            });
          },

          clear: () => {
            logger.debug(`[ZUSTAND:${namespace}] Clearing all data`);
            set({ data: {}, error: null });
          },

          setLoading: (loading: boolean) => {
            set({ loading });
          },

          setError: (error: string | null) => {
            set({ error });
          },

          list: () => {
            logger.debug(`[ZUSTAND:${namespace}] Listing all items`);
            return Object.values(get().data);
          },

          has: (key: string) => {
            return key in get().data;
          },

          count: () => {
            return Object.keys(get().data).length;
          },

          getKeys: () => {
            return Object.keys(get().data);
          },
        }),
        {
          name: `${namespace}-storage`,
          storage: createJSONStorage(() => ({
            getItem: (name) => {
              try {
                const filePath = path.join(storageDir, `${name}.json`);

                if (fs.existsSync(filePath)) {
                  return fs.readFileSync(filePath, 'utf8');
                }
                return null;
              } catch (error) {
                throw new FileError(`Failed to load state: ${name}`, {
                  context: { namespace, name },
                  cause: error,
                });
              }
            },
            setItem: (name, value) => {
              try {
                if (!fs.existsSync(storageDir)) {
                  fs.mkdirSync(storageDir, { recursive: true });
                }
                const filePath = path.join(storageDir, `${name}.json`);
                // Pretty-print the JSON for better readability
                const parsed: unknown = JSON.parse(value);
                const prettyJson = JSON.stringify(parsed, null, 2);
                fs.writeFileSync(filePath, prettyJson);
                logger.debug(`[ZUSTAND:${namespace}] Saved to: ${filePath}`);
              } catch (error) {
                throw new FileError(`Failed to save state: ${name}`, {
                  context: { namespace, name },
                  cause: error,
                });
              }
            },
            removeItem: (name) => {
              try {
                const filePath = path.join(storageDir, `${name}.json`);
                if (fs.existsSync(filePath)) {
                  fs.unlinkSync(filePath);
                  logger.debug(`[ZUSTAND:${namespace}] Removed: ${filePath}`);
                }
              } catch (error) {
                throw new FileError(`Failed to remove state: ${name}`, {
                  context: { namespace, name },
                  cause: error,
                });
              }
            },
          })),
        },
      ),
      { name: `${namespace} Store` },
    ),
  );
}

/**
 * Zustand Generic State Service Implementation
 */
export class ZustandGenericStateServiceImpl implements StateService {
  private storageDir: string;
  private logger: Logger;
  private stores: Map<string, ReturnType<typeof createNamespaceStore>> =
    new Map();

  constructor(logger: Logger, storageDir?: string) {
    this.logger = logger;
    this.storageDir =
      storageDir || path.join(os.homedir(), '.hiero-cli', 'state');
    this.ensureStorageDir();

    // Discover existing namespaces from storage files
    this.discoverExistingNamespaces();
  }

  /**
   * Discover existing namespaces from storage files
   */
  private discoverExistingNamespaces(): void {
    if (!fs.existsSync(this.storageDir)) {
      return;
    }

    try {
      const files = fs.readdirSync(this.storageDir);
      const namespaces = new Set<string>();

      // Extract namespace names from storage filenames
      files.forEach((file) => {
        if (file.endsWith('-storage.json')) {
          const namespace = file.replace(/-storage\.json$/, '');
          namespaces.add(namespace);
        }
      });

      // Pre-initialize discovered namespaces
      for (const namespace of namespaces) {
        this.getOrCreateStore(namespace);
      }

      if (namespaces.size > 0) {
        this.logger.debug(
          `[ZUSTAND STATE] Discovered ${namespaces.size} existing namespaces: ${Array.from(namespaces).join(', ')}`,
        );
      }
    } catch (error) {
      throw new FileError('Failed to discover existing namespaces', {
        context: { storageDir: this.storageDir },
        cause: error,
      });
    }
  }

  /**
   * Get the storage directory path
   */
  getStorageDirectory(): string {
    return this.storageDir;
  }

  /**
   * Check if the state storage is initialized
   */
  isInitialized(): boolean {
    return fs.existsSync(this.storageDir);
  }

  get<T>(namespace: string, key: string): T | undefined {
    const store = this.getOrCreateStore(namespace);
    return store.getState().getItem(key) as T | undefined;
  }

  set<T>(namespace: string, key: string, value: T): void {
    const store = this.getOrCreateStore(namespace);
    store.getState().setItem(key, value);
  }

  delete(namespace: string, key: string): void {
    const store = this.getOrCreateStore(namespace);
    store.getState().removeItem(key);
  }

  list<T>(namespace: string): T[] {
    const store = this.getOrCreateStore(namespace);
    return store.getState().list() as T[];
  }

  clear(namespace: string): void {
    const store = this.getOrCreateStore(namespace);
    store.getState().clear();
  }

  has(namespace: string, key: string): boolean {
    const store = this.getOrCreateStore(namespace);
    return store.getState().has(key);
  }

  getNamespaces(): string[] {
    return Array.from(this.stores.keys());
  }

  getKeys(namespace: string): string[] {
    const store = this.getOrCreateStore(namespace);
    return store.getState().getKeys();
  }

  subscribe<T>(namespace: string, callback: (data: T[]) => void): () => void {
    const store = this.getOrCreateStore(namespace);
    return store.subscribe((state) => {
      callback(Object.values(state.data) as T[]);
    });
  }

  getActions(namespace: string): unknown {
    const store = this.getOrCreateStore(namespace);
    return store.getState();
  }

  getState(namespace: string): unknown {
    const store = this.getOrCreateStore(namespace);
    return store.getState();
  }

  private ensureStorageDir(): void {
    if (!fs.existsSync(this.storageDir)) {
      try {
        fs.mkdirSync(this.storageDir, { recursive: true });
        this.logger.debug(
          `[ZUSTAND STATE] Created storage directory: ${this.storageDir}`,
        );
      } catch (error) {
        throw new FileError('Failed to create storage directory', {
          context: { storageDir: this.storageDir },
          cause: error,
        });
      }
    }
  }

  private getOrCreateStore(namespace: string) {
    if (!this.stores.has(namespace)) {
      const store = createNamespaceStore(
        namespace,
        this.logger,
        this.storageDir,
      );
      this.stores.set(namespace, store);
      this.logger.debug(
        `[ZUSTAND STATE] Created store for namespace: ${namespace}`,
      );
    }
    return this.stores.get(namespace)!;
  }
}
