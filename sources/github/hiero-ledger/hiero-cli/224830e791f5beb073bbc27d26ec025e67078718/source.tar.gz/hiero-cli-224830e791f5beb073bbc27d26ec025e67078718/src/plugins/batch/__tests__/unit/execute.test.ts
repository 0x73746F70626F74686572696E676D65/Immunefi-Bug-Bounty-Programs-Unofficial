import type { CoreApi } from '@/core/core-api/core-api.interface';

import { createMockTransaction } from '@/__tests__/mocks/hedera-sdk-mocks';
import { makeArgs, makeLogger } from '@/__tests__/mocks/mocks';
import { assertOutput } from '@/__tests__/utils/assert-output';
import { NotFoundError, ValidationError } from '@/core/errors';
import { SupportedNetwork } from '@/core/types/shared.types';
import {
  BatchExecuteCommand,
  BatchExecuteOutputSchema,
} from '@/plugins/batch/commands/execute';

import {
  BATCH_NAME,
  mockBatchDataWithTransactions,
  mockExecutedBatchData,
} from './helpers/fixtures';
import { makeBatchApiMocks, makeBatchStateServiceMock } from './helpers/mocks';

jest.mock('@hiero-ledger/sdk', () => {
  const actual = jest.requireActual('@hiero-ledger/sdk');
  return {
    ...actual,
    Transaction: {
      ...actual.Transaction,
      fromBytes: jest.fn().mockReturnValue({
        transactionId: {
          toString: jest.fn().mockReturnValue('0.0.1234@1234567890.000'),
        },
      }),
    },
  };
});

describe('batch plugin - execute command', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('executes batch successfully', async () => {
    const logger = makeLogger();
    const saveBatchMock = jest.fn();
    const batchState = makeBatchStateServiceMock({
      getBatch: jest.fn().mockReturnValue({
        ...mockBatchDataWithTransactions,
        transactions: [...mockBatchDataWithTransactions.transactions],
      }),
      saveBatch: saveBatchMock,
    });

    const { networkMock, kmsMock, txSignMock, txExecuteMock } =
      makeBatchApiMocks();

    const mockBatchTransaction = createMockTransaction();
    const batchServiceMock = {
      createBatchTransaction: jest.fn().mockReturnValue({
        transaction: mockBatchTransaction,
      }),
    };

    txExecuteMock.execute = jest.fn().mockResolvedValue({
      success: true,
      transactionId: '0.0.1234@1234567890.000000000',
      receipt: { status: { status: 'success' } },
    });

    const api: Partial<CoreApi> = {
      network: networkMock,
      kms: kmsMock,
      txSign: txSignMock,
      txExecute: txExecuteMock,
      batch: batchServiceMock,
    };

    const args = makeArgs({ ...api, logger }, { name: BATCH_NAME });
    const result = await new BatchExecuteCommand(batchState).execute(args);

    expect(saveBatchMock).toHaveBeenCalledWith(
      expect.any(String),
      expect.objectContaining({
        executed: true,
        success: true,
      }),
    );

    const output = assertOutput(result.result, BatchExecuteOutputSchema);
    expect(output.batchName).toBe(BATCH_NAME);
    expect(output.success).toBe(true);
    expect(output.transactionId).toBe('0.0.1234@1234567890.000000000');
    expect(output.network).toBe(SupportedNetwork.TESTNET);
  });

  test('marks batch as failed when execution fails', async () => {
    const logger = makeLogger();
    const saveBatchMock = jest.fn();
    const batchState = makeBatchStateServiceMock({
      getBatch: jest.fn().mockReturnValue({
        ...mockBatchDataWithTransactions,
        transactions: [...mockBatchDataWithTransactions.transactions],
      }),
      saveBatch: saveBatchMock,
    });

    const { networkMock, kmsMock, txSignMock, txExecuteMock } =
      makeBatchApiMocks();

    const mockBatchTransaction = createMockTransaction();
    const batchServiceMock = {
      createBatchTransaction: jest.fn().mockReturnValue({
        transaction: mockBatchTransaction,
      }),
    };

    txExecuteMock.execute = jest.fn().mockResolvedValue({
      success: false,
      transactionId: '0.0.1234@1234567890.000000001',
      receipt: { status: { status: 'failed' } },
    });

    const api: Partial<CoreApi> = {
      network: networkMock,
      kms: kmsMock,
      txSign: txSignMock,
      txExecute: txExecuteMock,
      batch: batchServiceMock,
    };

    const args = makeArgs({ ...api, logger }, { name: BATCH_NAME });
    const result = await new BatchExecuteCommand(batchState).execute(args);

    expect(saveBatchMock).toHaveBeenCalledWith(
      expect.any(String),
      expect.objectContaining({
        executed: true,
        success: false,
      }),
    );

    const output = assertOutput(result.result, BatchExecuteOutputSchema);
    expect(output.success).toBe(false);
  });

  test('throws NotFoundError when batch does not exist', async () => {
    const logger = makeLogger();
    const batchState = makeBatchStateServiceMock({
      getBatch: jest.fn().mockReturnValue(null),
    });

    const { networkMock, kmsMock } = makeBatchApiMocks();
    const api: Partial<CoreApi> = { network: networkMock, kms: kmsMock };

    const args = makeArgs({ ...api, logger }, { name: BATCH_NAME });

    await expect(
      new BatchExecuteCommand(batchState).execute(args),
    ).rejects.toThrow(NotFoundError);
  });

  test('throws ValidationError when batch already executed', async () => {
    const logger = makeLogger();
    const batchState = makeBatchStateServiceMock({
      getBatch: jest.fn().mockReturnValue({ ...mockExecutedBatchData }),
    });

    const { networkMock, kmsMock } = makeBatchApiMocks();
    const api: Partial<CoreApi> = { network: networkMock, kms: kmsMock };

    const args = makeArgs({ ...api, logger }, { name: BATCH_NAME });

    await expect(
      new BatchExecuteCommand(batchState).execute(args),
    ).rejects.toThrow(ValidationError);
  });

  test('throws NotFoundError when operator not found', async () => {
    const logger = makeLogger();
    const batchState = makeBatchStateServiceMock({
      getBatch: jest.fn().mockReturnValue({
        ...mockBatchDataWithTransactions,
        transactions: [...mockBatchDataWithTransactions.transactions],
      }),
    });

    const { networkMock, kmsMock } = makeBatchApiMocks();
    networkMock.getOperator = jest.fn().mockReturnValue(null);

    const api: Partial<CoreApi> = { network: networkMock, kms: kmsMock };

    const args = makeArgs({ ...api, logger }, { name: BATCH_NAME });

    await expect(
      new BatchExecuteCommand(batchState).execute(args),
    ).rejects.toThrow(NotFoundError);
  });

  test('throws NotFoundError when batch key not found in kms', async () => {
    const logger = makeLogger();
    const batchState = makeBatchStateServiceMock({
      getBatch: jest.fn().mockReturnValue({
        ...mockBatchDataWithTransactions,
        transactions: [...mockBatchDataWithTransactions.transactions],
      }),
    });

    const { networkMock, kmsMock } = makeBatchApiMocks();
    kmsMock.get = jest.fn().mockReturnValue(undefined);

    const api: Partial<CoreApi> = { network: networkMock, kms: kmsMock };

    const args = makeArgs({ ...api, logger }, { name: BATCH_NAME });

    await expect(
      new BatchExecuteCommand(batchState).execute(args),
    ).rejects.toThrow(NotFoundError);
  });
});
