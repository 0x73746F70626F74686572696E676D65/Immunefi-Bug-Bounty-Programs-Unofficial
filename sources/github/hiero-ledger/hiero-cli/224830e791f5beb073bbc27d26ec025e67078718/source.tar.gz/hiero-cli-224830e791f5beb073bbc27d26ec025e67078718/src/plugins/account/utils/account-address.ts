import { AccountId, PublicKey } from '@hiero-ledger/sdk';

import { ValidationError } from '@/core/errors';
import { KeyAlgorithm } from '@/core/shared/constants';

interface BuildAccountEvmAddressParams {
  accountId: string;
  publicKey: string;
  keyType: KeyAlgorithm;
  existingEvmAddress?: string | null;
}

const ensureHexAddressPrefix = (address: string): string => {
  if (!address) {
    return address;
  }
  return address.startsWith('0x') ? address : `0x${address}`;
};

export function buildEvmAddressFromAccountId(accountId: string): string {
  if (!accountId) {
    throw new ValidationError(
      'accountId is required to derive account addresses',
    );
  }
  const solidityAddress = AccountId.fromString(accountId).toSolidityAddress();
  return `0x${solidityAddress}`;
}

export function buildAccountEvmAddress({
  accountId,
  publicKey,
  keyType,
  existingEvmAddress,
}: BuildAccountEvmAddressParams): string {
  if (!accountId) {
    throw new ValidationError(
      'accountId is required to derive account addresses',
    );
  }

  const solidityAddress = AccountId.fromString(accountId).toSolidityAddress();
  const solidityAddressFull = `0x${solidityAddress}`;

  const evmAddress: string | undefined =
    existingEvmAddress && existingEvmAddress !== ''
      ? ensureHexAddressPrefix(existingEvmAddress)
      : undefined;

  if (evmAddress) {
    return evmAddress;
  }

  if (keyType === KeyAlgorithm.ECDSA) {
    if (!publicKey) {
      throw new ValidationError(
        'publicKey is required to derive EVM address for ECDSA keys',
      );
    }
    const ecdsaPublicKey = PublicKey.fromStringECDSA(publicKey);
    const alias = ecdsaPublicKey.toEvmAddress();
    return ensureHexAddressPrefix(alias);
  }

  return solidityAddressFull;
}
