import type { CommandHandlerArgs, CommandResult } from '@/core';
import type { KeyManager } from '@/core/services/kms/kms-types.interface';
import type { AccountData } from '@/plugins/account/schema';
import type { AccountStateService } from '@/plugins/account/services/account-state.service.interface';
import type { AccountCreateOutput } from './output';
import type {
  CreateBuildTransactionResult,
  CreateExecuteTransactionResult,
  CreateNormalisedParams,
  CreateSignTransactionResult,
} from './types';

import { BaseTransactionCommand } from '@/core/commands/command';
import { StateError, TransactionError } from '@/core/errors';
import { ConfigOptionKey } from '@/core/services/config/config-service.interface';
import { HBAR_DECIMALS, KeyAlgorithm } from '@/core/shared/constants';
import { AliasType } from '@/core/types/shared.types';
import { composeKey } from '@/core/utils/key-composer';
import { processBalanceInput } from '@/core/utils/process-balance-input';
import { AccountStateServiceImpl } from '@/plugins/account/services/account-state.service';
import { buildEvmAddressFromAccountId } from '@/plugins/account/utils/account-address';
import { validateSufficientBalance } from '@/plugins/account/utils/account-validation';

import { AccountCreateInputSchema } from './input';

export const ACCOUNT_CREATE_COMMAND_NAME = 'account_create';

export class AccountCreateCommand extends BaseTransactionCommand<
  CreateNormalisedParams,
  CreateBuildTransactionResult,
  CreateSignTransactionResult,
  CreateExecuteTransactionResult
> {
  constructor(private readonly accountState: AccountStateService) {
    super(ACCOUNT_CREATE_COMMAND_NAME);
  }

  async normalizeParams(
    args: CommandHandlerArgs,
  ): Promise<CreateNormalisedParams> {
    const { api } = args;

    const validArgs = AccountCreateInputSchema.parse(args.args);

    const balance = processBalanceInput(validArgs.balance, HBAR_DECIMALS);
    const maxAutoAssociations = validArgs.autoAssociations;
    const alias = validArgs.name;
    const name = alias;
    const keyManagerArg = validArgs.keyManager;
    const network = api.network.getCurrentNetwork();

    api.alias.availableOrThrow(alias, network);

    const keyManager =
      keyManagerArg ||
      api.config.getOption<KeyManager>(ConfigOptionKey.default_key_manager);

    const operator = api.network.getCurrentOperatorOrThrow();
    const payer = api.network.getPayer();
    const balanceCheckAccountId = payer?.accountId ?? operator.accountId;
    const payerOrOperator = await api.mirror.getAccountOrThrow(
      operator.accountId,
    );
    const payerOrOperatorBalance = BigInt(payerOrOperator.balance.balance);
    validateSufficientBalance(
      payerOrOperatorBalance,
      balance,
      balanceCheckAccountId,
    );

    api.logger.info(`Creating account with name: ${alias}`);

    let keyRefId: string;
    let publicKey: string;
    let keyType: KeyAlgorithm;

    if (validArgs.key) {
      const resolved = await api.keyResolver.getPublicKey(
        validArgs.key,
        keyManager,
        false,
        ['account:create', `account:${name}`],
      );
      keyRefId = resolved.keyRefId;
      publicKey = resolved.publicKey;
      const kmsRecord = api.kms.get(keyRefId);
      if (!kmsRecord) {
        throw new StateError(`KMS record not found for keyRefId: ${keyRefId}`);
      }
      keyType = kmsRecord.keyAlgorithm;
    } else {
      keyType = validArgs.keyType ?? KeyAlgorithm.ECDSA;
      const created = api.kms.createLocalPrivateKey(keyType, keyManager, [
        'account:create',
        `account:${name}`,
      ]);
      keyRefId = created.keyRefId;
      publicKey = created.publicKey;
    }

    return {
      balance,
      maxAutoAssociations,
      alias,
      name,
      publicKey,
      keyRefId,
      keyType,
      network,
      keyRefIds: [],
    };
  }

  async buildTransaction(
    args: CommandHandlerArgs,
    normalisedParams: CreateNormalisedParams,
  ): Promise<CreateBuildTransactionResult> {
    const { api } = args;
    return api.account.createAccount({
      balanceRaw: normalisedParams.balance,
      maxAutoAssociations: normalisedParams.maxAutoAssociations,
      publicKey: normalisedParams.publicKey,
    });
  }

  async signTransaction(
    args: CommandHandlerArgs,
    _normalisedParams: CreateNormalisedParams,
    buildTransactionResult: CreateBuildTransactionResult,
  ): Promise<CreateSignTransactionResult> {
    const { api } = args;
    const signedTransaction = await api.txSign.sign(
      buildTransactionResult.transaction,
      [],
    );
    return { signedTransaction };
  }

  async executeTransaction(
    args: CommandHandlerArgs,
    _normalisedParams: CreateNormalisedParams,
    _buildTransactionResult: CreateBuildTransactionResult,
    signTransactionResult: CreateSignTransactionResult,
  ): Promise<CreateExecuteTransactionResult> {
    const { api } = args;
    return {
      transactionResult: await api.txExecute.execute(
        signTransactionResult.signedTransaction,
      ),
    };
  }

  async outputPreparation(
    args: CommandHandlerArgs,
    normalisedParams: CreateNormalisedParams,
    buildTransactionResult: CreateBuildTransactionResult,
    _signTransactionResult: CreateSignTransactionResult,
    executeTransactionResult: CreateExecuteTransactionResult,
  ): Promise<CommandResult> {
    const { transactionResult } = executeTransactionResult;
    const { api } = args;

    if (!transactionResult.success) {
      throw new TransactionError(
        `Failed to create account (txId: ${transactionResult.transactionId})`,
        false,
      );
    }

    if (!transactionResult.accountId) {
      throw new StateError(
        'Transaction completed but did not return an account ID, unable to derive addresses',
      );
    }

    const evmAddress = buildEvmAddressFromAccountId(
      transactionResult.accountId,
    );

    if (normalisedParams.alias) {
      api.alias.register({
        alias: normalisedParams.alias,
        type: AliasType.Account,
        network: normalisedParams.network,
        entityId: transactionResult.accountId,
        evmAddress,
        publicKey: normalisedParams.publicKey,
        keyRefId: normalisedParams.keyRefId,
        createdAt: transactionResult.consensusTimestamp,
      });
    }

    const accountData: AccountData = {
      name: normalisedParams.name,
      accountId: transactionResult.accountId,
      type: normalisedParams.keyType,
      publicKey: buildTransactionResult.publicKey,
      evmAddress,
      keyRefId: normalisedParams.keyRefId,
      network: normalisedParams.network,
    };
    const accountKey = composeKey(
      normalisedParams.network,
      transactionResult.accountId,
    );
    this.accountState.saveAccount(accountKey, accountData);

    const outputData: AccountCreateOutput = {
      accountId: accountData.accountId,
      name: accountData.name,
      type: accountData.type,
      network: accountData.network,
      transactionId: transactionResult.transactionId || '',
      evmAddress,
      publicKey: accountData.publicKey,
    };

    return { result: outputData };
  }
}

export async function accountCreate(
  args: CommandHandlerArgs,
): Promise<CommandResult> {
  return new AccountCreateCommand(
    new AccountStateServiceImpl(
      args.api.state,
      args.api.logger,
      args.api.receipt,
      args.api.mirror,
      args.api.alias,
      args.api.kms,
      args.api.network,
    ),
  ).execute(args);
}
