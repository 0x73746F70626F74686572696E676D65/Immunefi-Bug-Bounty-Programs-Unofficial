#!/usr/bin/env node

import './core/utils/json-serialize';

import { CommanderError, program } from 'commander';

import pkg from '../package.json';

import { ConfigOptionKey, createCoreApi } from './core';
import { PluginManager } from './core/plugins/plugin-manager';
import { ErrorBoundaryServiceImpl } from './core/services/error-boundary/error-boundary-service';
import { PayerResolutionServiceImpl } from './core/services/payer-resolution/payer-resolution-service';
import { DEFAULT_PLUGIN_STATE } from './core/shared/config/cli-options';
import { validateNetwork } from './core/shared/validation/validate-network.zod';
import { validateOutputFormat } from './core/shared/validation/validate-output-format.zod';
import { addDisabledPluginsHelp } from './core/utils/add-disabled-plugins-help';
import { processBalanceInput } from './core/utils/process-balance-input';

program
  .name('hcli')
  .version(pkg.version || '0.0.0', '-v, --version')
  .description('A CLI tool for managing Hedera environments')
  .option('-F, --format <type>', 'Output format: human (default) or json')
  .option(
    '-N, --network <network>',
    'Target network (testnet, mainnet, previewnet, localnet)',
  )
  .option(
    '-P, --payer <payer>',
    'Payer account (alias or account-id:private-key format); defaults to operator if omitted',
  )
  .option('-Y, --confirm', 'Skip confirmation prompts')
  .option(
    '-M, --max-transaction-fee <amount>',
    'Max transaction fee ceiling for this run: HBAR (e.g. "20") or tinybars ("200000000t"). Overrides the default_max_transaction_fee config; 0 means no override.',
  )
  .showHelpAfterError('use --help for available options')
  .configureHelp({
    showGlobalOptions: true,
  })
  .exitOverride()
  .configureOutput({ outputError: () => {} });

// Initialize the simplified plugin system
async function initializeCLI() {
  const coreApi = createCoreApi();
  const errorBoundary = new ErrorBoundaryServiceImpl(
    coreApi.output,
    coreApi.logger,
  );

  try {
    program.parseOptions(process.argv.slice(2));
    const opts = program.opts();
    const format = validateOutputFormat(opts.format);

    coreApi.output.setFormat(format);

    if (format === 'json') {
      program.showHelpAfterError(false);
    } else {
      program.showHelpAfterError('use --help for available options');
    }

    const networkOverride = validateNetwork(opts.network || opts.N);

    if (networkOverride) {
      coreApi.network.setNetwork(networkOverride);
    }

    const payer = (opts.payer || opts.P) as string | undefined;
    if (payer) {
      const payerResolution = new PayerResolutionServiceImpl(
        coreApi.keyResolver,
        coreApi.network,
        coreApi.config,
        coreApi.logger,
      );
      await payerResolution.resolvePayer(payer);
    }

    const maxTransactionFee = (opts.maxTransactionFee || opts.M) as
      | string
      | undefined;
    if (maxTransactionFee !== undefined) {
      // Validate eagerly so a bad value fails fast; 0 means "no override".
      const tinybars = processBalanceInput(maxTransactionFee);
      if (tinybars > 0n) {
        coreApi.config.setRuntimeOverride(
          ConfigOptionKey.default_max_transaction_fee,
          maxTransactionFee,
        );
      }
    }

    // Setup global error handlers with validated format
    errorBoundary.registerGlobalHandlers();

    const pluginManager = new PluginManager(coreApi);

    // Initialize plugins, register disabled stubs, and load all manifests
    const pluginState = await pluginManager.initializePlugins(
      program,
      DEFAULT_PLUGIN_STATE,
    );

    // Register plugin commands
    pluginManager.registerCommands(program);

    // Add disabled plugins section to help output
    addDisabledPluginsHelp(program, pluginState);

    coreApi.logger.info('✅ CLI ready');

    // Parse arguments and execute command
    await program.parseAsync(process.argv);
    process.exit(0);
  } catch (error) {
    if (error instanceof CommanderError && error.exitCode === 0) {
      process.exit(0);
    }
    errorBoundary.handle(error);
    process.exit(1);
  }
}

// Start the CLI
void initializeCLI();
