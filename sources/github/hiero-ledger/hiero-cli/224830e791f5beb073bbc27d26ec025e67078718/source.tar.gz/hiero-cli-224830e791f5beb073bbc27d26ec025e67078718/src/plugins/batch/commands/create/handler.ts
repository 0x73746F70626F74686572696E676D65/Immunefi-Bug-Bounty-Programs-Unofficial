import type { CommandHandlerArgs, CommandResult } from '@/core';
import type { Command } from '@/core/commands/command.interface';
import type { KeyManager } from '@/core/services/kms/kms-types.interface';
import type { BatchStateService } from '@/plugins/batch/services/batch-state.service.interface';
import type { BatchCreateOutput } from './output';

import { ValidationError } from '@/core/errors';
import { ConfigOptionKey } from '@/core/services/config/config-service.interface';
import { composeKey } from '@/core/utils/key-composer';
import { BatchStateServiceImpl } from '@/plugins/batch/services/batch-state.service';

import { BatchCreateInputSchema } from './input';

export class BatchCreateCommand implements Command {
  constructor(private readonly batchState: BatchStateService) {}

  async execute(args: CommandHandlerArgs): Promise<CommandResult> {
    const { api } = args;
    const validArgs = BatchCreateInputSchema.parse(args.args);
    const name = validArgs.name;
    const batchKey = validArgs.key;
    const network = api.network.getCurrentNetwork();
    const key = composeKey(network, name);

    if (this.batchState.hasBatch(key)) {
      throw new ValidationError(`Batch with name '${key}' already exists`);
    }

    const keyManager =
      validArgs.keyManager ||
      api.config.getOption<KeyManager>(ConfigOptionKey.default_key_manager);

    const resolved = await api.keyResolver.resolveSigningKey(
      batchKey,
      keyManager,
      true,
      ['batch:signer'],
    );

    const batchData = {
      name,
      keyRefId: resolved.keyRefId,
      executed: false,
      success: false,
      transactions: [],
    };

    this.batchState.saveBatch(key, batchData);

    const outputData: BatchCreateOutput = {
      name: batchData.name,
      keyRefId: batchData.keyRefId,
    };

    return { result: outputData };
  }
}

export async function batchCreate(
  args: CommandHandlerArgs,
): Promise<CommandResult> {
  const { api } = args;
  const batchState = new BatchStateServiceImpl(api.state, api.logger);
  return new BatchCreateCommand(batchState).execute(args);
}
