import type { CommandHandlerArgs, CommandResult } from '@/core';
import type { Command } from '@/core/commands/command.interface';
import type { KeyManager } from '@/core/services/kms/kms-types.interface';
import type { AccountData } from '@/plugins/account/schema';
import type { AccountStateService } from '@/plugins/account/services/account-state.service.interface';
import type { AccountImportOutput } from './output';

import { StateError } from '@/core/errors';
import { ConfigOptionKey } from '@/core/services/config/config-service.interface';
import { AliasType } from '@/core/types/shared.types';
import { composeKey } from '@/core/utils/key-composer';
import { AccountStateServiceImpl } from '@/plugins/account/services/account-state.service';
import { buildAccountEvmAddress } from '@/plugins/account/utils/account-address';

import { AccountImportInputSchema } from './input';

export class AccountImportCommand implements Command {
  constructor(private readonly accountState: AccountStateService) {}

  async execute(args: CommandHandlerArgs): Promise<CommandResult> {
    const { api } = args;
    const validArgs = AccountImportInputSchema.parse(args.args);

    const alias = validArgs.name;
    const keyManagerArg = validArgs.keyManager;
    const network = api.network.getCurrentNetwork();

    const keyManager =
      keyManagerArg ||
      api.config.getOption<KeyManager>(ConfigOptionKey.default_key_manager);

    const resolved = await api.keyResolver.resolveAccountCredentials(
      validArgs.key,
      keyManager,
      false,
      ['account:import'],
    );

    const accountId = resolved.accountId;
    const accountKey = composeKey(network, accountId);

    if (this.accountState.hasAccount(accountKey)) {
      throw new StateError('Account with this ID is already saved in state');
    }
    api.alias.availableOrThrow(alias, network);

    const accountInfo = await api.mirror.getAccountOrThrow(accountId);

    api.logger.info(`Importing account: ${accountKey} (${accountId})`);

    const evmAddress = buildAccountEvmAddress({
      accountId,
      publicKey: resolved.publicKey,
      keyType: accountInfo.keyAlgorithm,
      existingEvmAddress: accountInfo.evmAddress,
    });

    if (alias) {
      api.alias.register({
        alias,
        type: AliasType.Account,
        network: api.network.getCurrentNetwork(),
        entityId: accountId,
        evmAddress,
        publicKey: resolved.publicKey,
        keyRefId: resolved.keyRefId,
        createdAt: new Date().toISOString(),
      });
    }

    const account: AccountData = {
      name: alias,
      accountId,
      type: accountInfo.keyAlgorithm,
      publicKey: resolved.publicKey,
      evmAddress,
      keyRefId: resolved.keyRefId,
      network: api.network.getCurrentNetwork(),
    };

    this.accountState.saveAccount(accountKey, account);

    const outputData: AccountImportOutput = {
      accountId,
      name: alias,
      type: account.type,
      network: account.network,
      balance: BigInt(accountInfo.balance.balance.toString()),
      evmAddress,
    };

    return { result: outputData };
  }
}

export const accountImport = (args: CommandHandlerArgs) =>
  new AccountImportCommand(
    new AccountStateServiceImpl(
      args.api.state,
      args.api.logger,
      args.api.receipt,
      args.api.mirror,
      args.api.alias,
      args.api.kms,
      args.api.network,
    ),
  ).execute(args);
