### ADR-008: Smart contract plugin implementation (proposal)

- Status: Proposed
- Date: 2026-01-20
- Related: `src/core/*`, `src/plugins/*`

## Context

The Hiero CLI requires implementation of Smart Contract plugin that would handle deployment and verification of smart contract on Hedera network.

Goals:

- Compilation of Smart Contract defined in Solidity
- Deployment of compiled Smart Contract to the Hedera network
- Verification of deployed Smart Contract
- Command for listing deployed smart contract

## Decision

- We will use Solidity Compiler `solc` for compiling Solidity files which hold Smart Contract definitions
- We will use Hashgraph SDK to deploy compiled Smart Contract code
- For verification of deployed Smart Contract we will use `Smart Contract Verification API`
- This three steps mentioned above will be executed in a single command
- Deployed Smart Contract's information should be persisted in state and we should implement `list` command to view them

## Implementation Strategy

**1. Contract plugin**

Contract plugin will consist of two commands:

- `create` - the definition of this command will look like this

```ts
{
  name: 'create',
          summary: 'Create smart contract',
          description:
  'Command manages smart contract creation by compiling smart contract definition file, deploy and verification',
          options: [
    {
      name: 'name',
      short: 'n',
      type: 'string',
      required: true,
      description: 'Smart contract name represented in the state',
    },
    {
      name: 'file',
      short: 'f',
      type: 'string',
      required: false,
      description:
              'Smart contract definition file path (absolute or relative) to a Solidity file',
    },
    {
      name: 'default',
      short: 'd',
      type: 'string',
      required: false,
      description:
              'Use built-in contract template: erc20 or erc721 (mutually exclusive with file)',
    },
    {
      name: 'base-path',
      short: 'b',
      type: 'string',
      required: false,
      description:
              'Base path to the smart contract file directory. Defaults to current directory',
    },
    {
      name: 'gas',
      short: 'g',
      type: 'number',
      required: false,
      default: 2000000,
      description: 'Gas for smart contract creation. Default: 2000000',
    },
    {
      name: 'admin-key',
      short: 'a',
      type: 'string',
      required: false,
      description: 'Smart contract admin key.',
    },
    {
      name: 'memo',
      short: 'm',
      type: 'string',
      required: false,
      description: 'Smart contract memo.',
    },
    {
      name: 'constructor-parameter',
      short: 'c',
      type: 'repeatable',
      required: false,
      description:
              'Repeatable parameter to be set for smart contract constructor',
    },
    {
      name: 'key-manager',
      short: 'k',
      type: 'string',
      required: false,
      description:
              'Key manager to use: local or local_encrypted (defaults to config setting)',
    },
    {
      name: 'initial-balance',
      short: 'i',
      type: 'string',
      required: false,
      description:
              'Initial HBAR balance for the contract. Format: "100" (HBAR) or "100t" (tinybars)',
    },
    {
      name: 'auto-renew-period',
      short: 'r',
      type: 'string',
      required: false,
      description: 'Auto-renew period: seconds as integer, or with suffix s/m/h/d (e.g. 500, 500s, 50m, 2h, 30d)',
    },
    {
      name: 'auto-renew-account-id',
      type: 'string',
      required: false,
      description: 'Account ID (0.0.xxx) that will pay for auto-renewal of the contract',
    },
    {
      name: 'max-automatic-token-associations',
      type: 'number',
      required: false,
      description: 'Maximum number of automatic token associations (-1 for unlimited, 0 to disable)',
    },
    {
      name: 'staked-account-id',
      type: 'string',
      required: false,
      description: 'Account ID (0.0.xxx) to stake this contract to (mutually exclusive with staked-node-id)',
    },
    {
      name: 'staked-node-id',
      type: 'number',
      required: false,
      description: 'Node ID to stake this contract to (mutually exclusive with staked-account-id)',
    },
    {
      name: 'decline-staking-reward',
      type: 'boolean',
      required: false,
      description: 'Whether to decline staking rewards for this contract',
    },
  ],
          handler: contractCreate,
          output: {
    schema: ContractCreateOutputSchema,
            humanTemplate: CONTRACT_CREATE_TEMPLATE,
  },
},
```

The `create` command will take the following options:

- option `name` - it will be used for representing contract in the state as alias
- option `file` - it will be pointing to the smart contract file definition you want to deploy to Hedera network. Either `file` or `default` must be provided, but not both.
- option `default` - use a built-in contract template (`erc20` or `erc721`) instead of a custom file. When used, the contract source is loaded from the CLI package and constructor parameters default to predefined values (FungibleToken/FTK/1000000 for erc20, NonFungibleToken/NFTK for erc721) unless overridden with `constructor-parameter`. Either `file` or `default` must be provided, but not both.
- option `base-path` - it will be pointing to the directory in which you want to execute compilation of smart contract so that all imports will be searched from the level of this directory. It will default to the current directory when using `file`, or to the CLI package root when using `default`.
- option `admin-key` - it will be used for setting up an admin key for smart contract
- option `constructor-parameter` - a new type of parameter `repeatable`. The `repeatable` parameter can be set many times and each assign results in putting new value to the list of this option. This `constructor-parameter` will be a list consisting of parameters that are needed for constructor of deployed smart contract. When using `default`, constructor parameters are optional and default values are applied if omitted.
- option `memo` - it will be used to pass string field as contract memo
- option `key-manager` - points to the key manager for using in the command execution
- option `initial-balance` - sets an initial HBAR balance funded to the contract at deployment. Accepts HBAR (`"100"`) or tinybar (`"100t"`) format.
- option `auto-renew-period` - sets the auto-renew interval. Accepts a plain integer (seconds) or a value with suffix: `s` (seconds), `m` (minutes), `h` (hours), `d` (days) — e.g. `500`, `50m`, `2h`, `30d`
- option `auto-renew-account-id` - account ID whose balance is charged for contract auto-renewal
- option `max-automatic-token-associations` - maximum number of token associations that can be created automatically. Use `-1` for unlimited, `0` to disable.
- option `staked-account-id` - account ID to stake this contract to for staking rewards. Mutually exclusive with `staked-node-id`.
- option `staked-node-id` - node ID to stake this contract to for staking rewards. Mutually exclusive with `staked-account-id`.
- option `decline-staking-reward` - set to `true` to opt the contract out of staking rewards

Examples of this command execution:

```bash
# Deploy custom contract from file
hcli contract create --name test-contract --file ../directory/contracts/Contract.sol --base-path ../directory --constructor-parameter Alice -c 11111

# Deploy built-in ERC20 template with default constructor params (FungibleToken, FTK, 1000000)
hcli contract create --name my-token --default erc20

# Deploy built-in ERC721 template with default constructor params (NonFungibleToken, NFTK)
hcli contract create --name my-nft --default erc721

# Deploy built-in ERC20 with custom constructor params
hcli contract create --name my-token --default erc20 -c "CustomToken" -c "CTK" -c "500000"
```

- `list` - command responsible for listing deployed contracts

```ts

{
        name: 'list',
        summary: 'List all contracts',
        description: 'List all smart contracts stored in the state',
        options: [],
        handler: contractList,
        output: {
          schema: ContractListOutputSchema,
          humanTemplate: CONTRACT_LIST_TEMPLATE,
        },
},
```

**2. Contract schema**

The contract schema will be represented as follows

```ts
export const ContractDataSchema = z.object({
  contractId: EntityIdSchema.describe('Contract ID'),
  contractName: ContractNameSchema,

  contractEvmAddress: EvmAddressSchema.describe(
    'Deployed contract EVM address',
  ),
  adminPublicKey: z.string().optional(),

  network: z.enum(SupportedNetwork, {
    error: () => ({
      message: 'Network must be mainnet, testnet, previewnet, or localnet',
    }),
  }),

  memo: z.string().max(100).optional(),
});

// TypeScript type inferred from Zod schema
export type ContractData = z.infer<typeof ContractDataSchema>;
```

It will be stored in separate file. Also the alias will be used, so we would additionally put this information into the `alias` state with the type `contract`.

**3. Core services**

Our implementation will introduce three new services and it would be:

3.1. `ContractCompilerService` - service responsible for using Solidity Compiler `solc` and its high-level API to compile provided smart contract file written in Solidity language.
The result will provide us with binary, abi and metadata result that we can use for deploying the smart contract on Hedera network

```ts
export interface ContractCompilerService {
  compileContract(params: CompilationParams): CompilationResult;
}
```

```ts
export interface CompilationParams {
  contractFilename: string;
  contractName: string;
  contractContent: string;
  basePath: string;
}

export interface CompilationResult {
  bytecode: string;
  abiDefinition: string;
  metadata: string;
}
```

What does this service do:

- firstly it build a Solidity compiler input

```ts
const input: SolcInput = {
  language: 'Solidity',
  sources: {
    [params.contractFilename]: {
      content: params.contractContent,
    },
  },
  settings: {
    outputSelection: {
      '*': {
        '*': ['abi', 'evm.bytecode.object', 'metadata'],
      },
    },
  },
};
```

This tells Solidity compiler that we want to compile one file written in `Solidity` language and the output should be:
deployable bytecode `evm.bytecode.object`, ABI definitoin of the cotnract `abi`, JSON metadata of the contract `metadata`

- runs the Solidity compiler by executing `solc.compile` with resolved imports and compiler input

```ts
const output = JSON.parse(
  solc.compile(JSON.stringify(input), {
    import: this.createImportPath(params.basePath),
  }),
) as SolcOutput;
```

- the last thing is extracting ABI, metadata and bytecode of compiled smart contract and returning these values

**3.2. `ContractTransactionService`** - this service constructs a smart-contract deployment transaction by attaching bytecode, optional metadata, gas settings, and ABI-encoded constructor parameters, returning a ready-to-sign contract creation transaction.

Purposes of service are:

- creating a contract deployment transaction

- configuring optional deployment parameters:
  - `bytecode`, `gas`, `adminKey`, `memo` — core deployment settings
  - `initialBalanceRaw` — initial HBAR balance (in tinybars) funded to the contract at deployment
  - `autoRenewPeriod` — auto-renew interval in seconds
  - `autoRenewAccountId` — account responsible for paying auto-renewal fees
  - `maxAutomaticTokenAssociations` — cap on automatic token associations
  - `stakedAccountId` / `stakedNodeId` — staking target (mutually exclusive)
  - `declineStakingReward` — opt the contract out of staking rewards

- encoding constructor arguments using the contract’s ABI

- returning a ready-to-sign transaction object

**3.3 `ContractVerifierService`** - service responsible for verifying smart contract on Hedera Hashscan using `Smart Contract Verification API`.
It takes a smart contract's source code and address, packages them up, and ships them off to HashScan so that the contract can be marked as "Verified" on the block explorer.

The `verifyContract` will construct payload that is visible below

```json
{
    "address": "0000000000000000000000000000000000753312", // address of smart contract (result of smart contract deployment
    "chain": "296", // chainId of specific Hedera chain on network
    "files": { // files will consist of two files, one is content of metadata (result of Solidity compiler output) and the second one is cotnract definition in Solidity
        "metadata.json": "" // to the
        "LookupContract.sol":""

    }
}
```

and then use it as payload when creating POST request using `axios` to the address `https://server-verify.hashscan.io/verify` and send POST request to address 'https://server-verify.hashscan.io/verify'.

## Testing

1. Implementation of unit tests for new core services and handlers for new commands.
2. Integration tests for deploying smart contract and listing contracts in the state will need to be created.
