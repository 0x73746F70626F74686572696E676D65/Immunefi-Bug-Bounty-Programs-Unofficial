// SPDX-License-Identifier: Apache-2.0

import com.diffplug.gradle.spotless.SpotlessTask
import com.github.gradle.node.npm.task.NpmSetupTask
import java.nio.file.Paths
import task.Release

description = "Hedera Mirror Node imports data from consensus nodes and serves it via an API"

plugins {
    id("com.diffplug.spotless")
    id("com.github.node-gradle.node")
    id("idea")
    id("java-platform")
    id("snykcode-extension")
}

// Can't use typed variable syntax due to Dependabot limitations
extra.apply {
    set("besuVersion", "26.2.0")
    set("blockNodeVersion", "0.42.0")
    set("consensusNodeVersion", "0.78.0-rc.9")
    set("hederaCryptographyVersion", "3.15.0")
    set("jackson-bom.version", "3.2.3") // Temporary until next Spring Boot
    set("jackson-2-bom.version", "2.22.3") // Temporary until next Spring Boot
    set("jooq.version", "3.21.7") // Must match buildSrc/build.gradle.kts
    set("mapStructVersion", "1.6.3")
    set("netty.version", "4.2.18.Final") // Temporary until next Spring Boot
    set("nodeJsVersion", "24.21.0")
    set("tomcat.version", "11.0.26") // Temporary until next Spring Boot
    set("tuweniVersion", "2.3.1")
}

// Creates a platform/BOM with specific versions so subprojects don't need to specify a version when
// using a dependency
dependencies {
    constraints {
        val besuVersion = rootProject.extra["besuVersion"] as String
        val blockNodeVersion = rootProject.extra["blockNodeVersion"] as String
        val consensusNodeVersion = rootProject.extra["consensusNodeVersion"] as String
        val hederaCryptographyVersion = rootProject.extra["hederaCryptographyVersion"] as String
        val mapStructVersion = rootProject.extra["mapStructVersion"] as String
        val tuweniVersion = rootProject.extra["tuweniVersion"] as String

        api("com.asarkar.grpc:grpc-test:2.0.1")
        api("com.esaulpaugh:headlong:13.3.1")
        api("com.github.luben:zstd-jni:1.5.7-19")
        api("com.github.meanbeanlib:meanbean:3.0.0-M9")
        api("com.github.vertical-blank:sql-formatter:2.0.5")
        api("com.bucket4j:bucket4j-core:8.10.1")
        api("com.google.guava:guava:33.7.1-jre")
        api("com.graphql-java-generator:graphql-java-client-runtime:4.0.2")
        api("com.graphql-java:graphql-java-extended-scalars:24.0")
        api("com.graphql-java:graphql-java-extended-validation:24.0")
        api("com.hedera.cryptography:hedera-cryptography-wraps:$hederaCryptographyVersion")
        api("com.hedera.cryptography:libsecp256k1:$hederaCryptographyVersion")
        // Needs to use variable for compare workflow
        api("com.hedera.hashgraph:app:$consensusNodeVersion")
        api("com.hedera.hashgraph:app-service-entity-id-impl:$consensusNodeVersion")
        api("com.hedera.hashgraph:hedera-protobuf-java-api:$consensusNodeVersion")
        api("com.hedera.hashgraph:sdk:2.78.0-beta.1")
        api("com.ongres.scram:client:2.1")
        api("commons-beanutils:commons-beanutils:1.11.0")
        api("commons-io:commons-io:2.22.0")
        api("io.cucumber:cucumber-bom:7.34.9")
        api("io.fabric8:kubernetes-client-bom:7.9.0")
        api("io.github.mweirauch:micrometer-jvm-extras:0.3.0")
        api("io.hypersistence:hypersistence-utils-hibernate-71:3.16.0")
        api("jakarta.inject:jakarta.inject-api:2.0.1")
        api("net.java.dev.jna:jna:5.19.1")
        api("org.apache.commons:commons-collections4:4.6.0")
        api("org.apache.commons:commons-compress:1.28.0")
        api("org.apache.commons:commons-math3:3.6.1")
        api("org.apache.tuweni:tuweni-bytes:$tuweniVersion")
        api("org.apache.tuweni:tuweni-units:$tuweniVersion")
        api("org.apache.velocity:velocity-engine-core:2.4.1")
        api("org.bouncycastle:bcpkix-jdk18on:1.86") // Temporary until next hedera-app
        api("org.bouncycastle:bcprov-jdk18on:1.86")
        api("org.gaul:s3proxy:4.1.1")
        api("org.graalvm.nativeimage:svm:25.0.4.1.1")
        api("org.hiero.block-node:protobuf-sources:$blockNodeVersion")
        api("org.hyperledger.besu.internal:besu-crypto-algorithms:$besuVersion")
        api("org.hyperledger.besu:besu-datatypes:$besuVersion")
        api("org.hyperledger.besu:evm:$besuVersion")
        api("org.mapstruct:mapstruct:$mapStructVersion")
        api("org.mapstruct:mapstruct-processor:$mapStructVersion")
        api("org.msgpack:jackson-dataformat-msgpack:0.9.12")
        api("org.web3j:core:6.0.0")
        api("software.amazon.awssdk:bom:2.55.4")
        api("tech.pegasys:jc-kzg-4844:1.0.0")
        api("uk.org.webcompere:system-stubs-jupiter:2.1.8")
    }
}

allprojects { apply(plugin = "jacoco") }

idea {
    module {
        isDownloadJavadoc = true
        isDownloadSources = true
    }
}

// Spotless uses Prettier and it requires Node.js
node {
    val nodeJsVersion = rootProject.extra["nodeJsVersion"] as String
    download = true
    version = nodeJsVersion
    workDir = rootDir.resolve(".gradle").resolve("nodejs")
}

repositories {
    gradlePluginPortal()
    mavenCentral()
}

spotless {
    val licenseHeader = "// SPDX-License-Identifier: Apache-2.0\n\n"
    val nodeExec =
        when (System.getProperty("os.name").lowercase().contains("windows")) {
            true -> Paths.get("node.exe")
            else -> Paths.get("bin", "node")
        }
    val npmExec =
        when (System.getProperty("os.name").lowercase().contains("windows")) {
            true -> Paths.get("npm.cmd")
            else -> Paths.get("bin", "npm")
        }
    val npmSetup = tasks.named("npmSetup").get() as NpmSetupTask
    val nodeDir = npmSetup.npmDir.get().asFile.toPath()
    val npmExecutable = nodeDir.resolve(npmExec)
    val nodeExecutable = nodeDir.resolve(nodeExec)

    isEnforceCheck = false

    if (!System.getenv().containsKey("CI")) {
        ratchetFrom("origin/main")
    }

    format("go") {
        endWithNewline()
        licenseHeader(licenseHeader, "package")
        target("rosetta/**/*.go")
        targetExclude("**/build/**")
        trimTrailingWhitespace()
    }
    format("helm") {
        endWithNewline()
        leadingTabsToSpaces(2)
        licenseHeader(licenseHeader.replaceFirst("//", "#"), "^[a-zA-Z0-9{]+")
        target("charts/**/*.yaml", "charts/**/*.yml")
        trimTrailingWhitespace()
    }
    format("javascript") {
        endWithNewline()
        leadingTabsToSpaces(2)
        licenseHeader(licenseHeader, "$")
        prettier()
            .nodeExecutable(nodeExecutable)
            .npmExecutable(npmExecutable)
            .npmInstallCache(Paths.get("${rootProject.rootDir}", ".gradle", "spotless"))
            .config(mapOf("bracketSpacing" to false, "printWidth" to 120, "singleQuote" to true))
        target("rest/**/*.js", "tools/**/*.js")
        targetExclude(
            "**/build/**",
            "**/buildDist/**",
            "**/dist/**",
            "**/node_modules/**",
            "**/__tests__/integration/*.spec.test.js",
            "tools/mirror-report/index.js",
        )
    }
    java {
        endWithNewline()
        licenseHeader(licenseHeader, "package")
        palantirJavaFormat()
        removeUnusedImports()
        target("**/*.java")
        targetExclude(
            "**/build/**",
            "rest/**",
            "rosetta/**",
            // Known issue with Java 21: https://github.com/palantir/palantir-java-format/issues/933
            "rest-java/**/EntityServiceImpl.java",
            "tools/**",
        )
        toggleOffOn()
        trimTrailingWhitespace()
    }
    kotlin {
        endWithNewline()
        ktfmt().kotlinlangStyle()
        licenseHeader(licenseHeader, "package")
        target("buildSrc/**/*.kt")
        targetExclude("**/build/**")
    }
    kotlinGradle {
        endWithNewline()
        ktfmt().kotlinlangStyle()
        licenseHeader(licenseHeader, "(description|import|plugins)")
        target("*.kts", "*/*.kts", "buildSrc/**/*.kts", "rest/*/*.kts")
        targetExclude("**/build/**", "**/node_modules/**")
        trimTrailingWhitespace()
    }
    format("miscellaneous") {
        endWithNewline()
        leadingTabsToSpaces(2)
        prettier()
            .nodeExecutable(nodeExecutable)
            .npmExecutable(npmExecutable)
            .npmInstallCache(Paths.get("${rootProject.rootDir}", ".gradle", "spotless"))
        target("**/*.json", "**/*.md")
        targetExclude(
            "**/build/**",
            "**/charts/**/dashboards/**",
            "**/node_modules/**",
            "**/package-lock.json",
        )
        trimTrailingWhitespace()
    }
    format("proto") {
        endWithNewline()
        leadingTabsToSpaces(4)
        licenseHeader(licenseHeader, "(package|syntax)")
        target("protobuf/**/*.proto")
        targetExclude("**/build/**")
        trimTrailingWhitespace()
    }
    format("shell") {
        endWithNewline()
        leadingTabsToSpaces(2)
        licenseHeader("#!/usr/bin/env bash\n\n" + licenseHeader.replaceFirst("//", "#"), "^[^#\\s]")
        target("**/*.sh")
        targetExclude("**/build/**", "**/node_modules/**")
        trimTrailingWhitespace()
    }
    sql {
        endWithNewline()
        leadingTabsToSpaces()
        licenseHeader(licenseHeader.replaceFirst("//", "--"), "^[^-\\s]")
        target(
            "common/src/test/resources/*.sql",
            "importer/**/*.sql",
            "rest/__tests__/data/**/*.sql",
        )
        targetExclude("**/build/**", "**/db/migration/**")
        trimTrailingWhitespace()
    }
    format("yaml") {
        endWithNewline()
        leadingTabsToSpaces(2)
        prettier()
            .nodeExecutable(nodeExecutable)
            .npmExecutable(npmExecutable)
            .npmInstallCache(Paths.get("${rootProject.rootDir}", ".gradle", "spotless"))
        licenseHeader(licenseHeader.replaceFirst("//", "#"), "^[a-zA-Z0-9{]+")
        target("**/*.yaml", "**/*.yml")
        targetExclude("**/build/**", "charts/**", "**/node_modules/**")
        trimTrailingWhitespace()
    }
}

tasks.nodeSetup { onlyIf { !this.nodeDir.get().asFile.exists() } }

tasks.register<Release>("release") {
    description = "Replaces release version in files."
    group = "release"
    directory = layout.settingsDirectory
}

tasks.withType<SpotlessTask>().configureEach { dependsOn(tasks.nodeSetup) }
