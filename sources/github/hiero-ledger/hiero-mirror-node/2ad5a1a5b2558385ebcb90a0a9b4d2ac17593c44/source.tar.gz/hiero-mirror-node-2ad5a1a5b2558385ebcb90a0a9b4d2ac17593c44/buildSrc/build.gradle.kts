// SPDX-License-Identifier: Apache-2.0

plugins { `kotlin-dsl` }

repositories { gradlePluginPortal() }

dependencies {
    // Temporary until all plugins upgrade
    constraints {
        add("implementation", "com.fasterxml.jackson.core:jackson-databind") {
            version { require("2.22.3") }
        }
        add("implementation", "tools.jackson.core:jackson-databind") {
            version { require("3.2.3") }
        }
        add("implementation", "org.apache.ant:ant") {
            version { require("1.10.18") }
        }
    }

    val dockerJavaVersion = "3.7.1"
    val jooqVersion = "3.21.8" // Always make the version in project root build.gradle.kts match

    // Add docker-java dependencies before gradle-docker-plugin to avoid the docker-java jars
    // embedded in the plugin being used by testcontainers-postgresql
    implementation("com.github.docker-java:docker-java-api:$dockerJavaVersion")
    implementation("com.github.docker-java:docker-java-core:$dockerJavaVersion")
    implementation("com.bmuschko:gradle-docker-plugin:10.0.0")
    implementation("com.diffplug.spotless:spotless-plugin-gradle:8.10.2")
    implementation("com.github.node-gradle:gradle-node-plugin:7.1.0")
    implementation("com.google.protobuf:protobuf-gradle-plugin:0.10.0")
    implementation("com.gorylenko.gradle-git-properties:gradle-git-properties:4.0.1")
    implementation("com.gradleup.shadow:shadow-gradle-plugin:9.6.1")
    implementation("com.graphql-java-generator:graphql-gradle-plugin3:4.0.2")
    implementation("gradle.plugin.io.snyk.gradle.plugin:snyk:0.7.0")
    implementation("io.freefair.gradle:lombok-plugin:9.7.0")
    implementation("io.spring.gradle:dependency-management-plugin:1.1.7")
    implementation("net.ltgt.gradle:gradle-errorprone-plugin:5.1.1")
    implementation("org.apache.commons:commons-compress:1.28.0")
    implementation("org.cyclonedx:cyclonedx-gradle-plugin:3.4.1")
    implementation("org.flywaydb:flyway-database-postgresql:13.7.0")
    implementation("org.graalvm.buildtools:native-gradle-plugin:1.1.14")
    implementation("org.gradle:test-retry-gradle-plugin:1.6.6")
    implementation("org.jooq:jooq-codegen-gradle:$jooqVersion")
    implementation("org.jooq:jooq-meta:$jooqVersion")
    implementation("org.jooq:jooq-postgres-extensions:${jooqVersion}")
    implementation("org.openapitools:openapi-generator-gradle-plugin:7.25.0")
    implementation("org.owasp:dependency-check-gradle:13.0.0")
    implementation("org.springframework.boot:spring-boot-gradle-plugin:4.1.1")
    implementation("org.testcontainers:testcontainers-postgresql:2.0.5")
    implementation("org.web3j:web3j-gradle-plugin:5.0.2")
}

// These transitive dependencies are vulnerable and not used
configurations.all {
    exclude(group = "io.netty")
    exclude(group = "io.vertx")
}

val gitHook =
    tasks.register<Exec>("gitHook") {
        commandLine("git", "config", "core.hookspath", "buildSrc/src/main/resources/hooks")
        description = "Adds our git hook that runs Spotless apply"
    }

tasks.processResources { dependsOn(gitHook) }
