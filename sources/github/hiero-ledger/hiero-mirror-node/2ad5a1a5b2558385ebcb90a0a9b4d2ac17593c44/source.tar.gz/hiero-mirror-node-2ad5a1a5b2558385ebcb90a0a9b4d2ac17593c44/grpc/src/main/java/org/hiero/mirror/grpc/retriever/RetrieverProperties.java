// SPDX-License-Identifier: Apache-2.0

package org.hiero.mirror.grpc.retriever;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.time.Duration;
import lombok.Data;
import org.hibernate.validator.constraints.time.DurationMin;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

@Data
@Validated
@ConfigurationProperties("hiero.mirror.grpc.retriever")
public class RetrieverProperties {

    public static final int MAX_PAGE_SIZE = 10000;
    public static final int MIN_PAGE_SIZE = 1;

    private boolean enabled = true;

    @Max(MAX_PAGE_SIZE)
    @Min(MIN_PAGE_SIZE)
    private int maxPageSize = 1000;

    @NotNull
    private Duration pollingFrequency = Duration.ofSeconds(2L);

    @NotNull
    private Duration timeout = Duration.ofSeconds(60L);

    @NotNull
    @Valid
    private UnthrottledProperties unthrottled = new UnthrottledProperties();

    @Data
    @Validated
    public static class UnthrottledProperties {

        @Max(MAX_PAGE_SIZE)
        @Min(MIN_PAGE_SIZE)
        private int maxPageSize = 5000;

        @Min(4)
        private long maxPolls = 12;

        @DurationMin(millis = 10)
        @NotNull
        private Duration pollingFrequency = Duration.ofMillis(20);
    }
}
