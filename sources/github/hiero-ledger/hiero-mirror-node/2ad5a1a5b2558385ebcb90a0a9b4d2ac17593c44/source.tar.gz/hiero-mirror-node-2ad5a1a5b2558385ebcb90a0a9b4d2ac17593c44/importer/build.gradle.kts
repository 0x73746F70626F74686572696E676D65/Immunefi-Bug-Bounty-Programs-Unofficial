// SPDX-License-Identifier: Apache-2.0

import com.google.protobuf.gradle.id

description = "Mirror Node Importer"

plugins {
    id("com.google.protobuf")
    id("spring-conventions")
}

configurations.all {
    exclude(group = "io.vertx") // Unused and frequently has vulnerabilities
}

dependencies {
    val blockNodeVersion = rootProject.extra["blockNodeVersion"] as String

    implementation(platform("software.amazon.awssdk:bom"))
    implementation(project(":common"))
    implementation("com.esaulpaugh:headlong")
    implementation("com.fasterxml.jackson.dataformat:jackson-dataformat-csv")
    implementation("com.hedera.cryptography:hedera-cryptography-wraps")
    implementation("commons-io:commons-io")
    implementation("io.github.mweirauch:micrometer-jvm-extras")
    implementation("io.grpc:grpc-protobuf")
    implementation("io.grpc:grpc-stub")
    implementation("io.micrometer:micrometer-registry-prometheus")
    implementation("io.projectreactor:reactor-core")
    implementation("jakarta.inject:jakarta.inject-api")
    implementation("net.java.dev.jna:jna")
    implementation("org.apache.commons:commons-compress")
    implementation("org.apache.commons:commons-collections4")
    implementation("org.apache.velocity:velocity-engine-core")
    implementation("org.flywaydb:flyway-database-postgresql")
    implementation("org.msgpack:jackson-dataformat-msgpack")
    implementation("org.postgresql:postgresql")
    implementation("org.springframework.boot:spring-boot-configuration-processor")
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    implementation("org.springframework.boot:spring-boot-starter-cache")
    implementation("org.springframework.boot:spring-boot-starter-data-redis")
    implementation("org.springframework.boot:spring-boot-starter-flyway")
    implementation("software.amazon.awssdk:netty-nio-client")
    implementation("software.amazon.awssdk:s3")
    implementation("software.amazon.awssdk:sts")
    protobuf("org.hiero.block-node:protobuf-sources:$blockNodeVersion")
    implementation("com.github.luben:zstd-jni")
    runtimeOnly("io.grpc:grpc-netty")
    testImplementation(project(path = ":common", configuration = "testClasses"))
    testImplementation("com.asarkar.grpc:grpc-test")
    testImplementation("com.github.vertical-blank:sql-formatter")
    testImplementation("com.google.protobuf:protobuf-java-util")
    testImplementation("commons-beanutils:commons-beanutils")
    testImplementation("io.grpc:grpc-inprocess")
    testImplementation("io.grpc:grpc-netty")
    testImplementation("io.projectreactor:reactor-test")
    testImplementation("org.apache.commons:commons-math3")
    testImplementation("org.awaitility:awaitility")
    testImplementation("org.gaul:s3proxy") {
        exclude(group = "com.github.openstack4j.core")
        exclude(group = "com.github.openstack4j.core.connectors")
        exclude(group = "com.google.cloud")
        exclude(group = "io.opentelemetry")
    }
    testImplementation("org.junit.platform:junit-platform-launcher")
    testImplementation("org.springframework.boot:spring-boot-starter-flyway-test")
    testImplementation("org.springframework.boot:spring-boot-testcontainers")
    testImplementation("org.testcontainers:testcontainers-postgresql")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

protobuf {
    plugins {
        id("grpc")
    }
}
