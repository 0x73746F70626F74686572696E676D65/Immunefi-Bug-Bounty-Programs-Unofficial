// SPDX-License-Identifier: Apache-2.0

package org.hiero.mirror.importer.downloader.block;

import io.grpc.ManagedChannelBuilder;

public interface ManagedChannelBuilderProvider {

    ManagedChannelBuilder<?> get(String host, int port, boolean useTls);
}
