// SPDX-License-Identifier: Apache-2.0

package org.hiero.mirror.common.domain.entity;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.hiero.mirror.common.domain.entity.EntityId.NUM_BITS;
import static org.hiero.mirror.common.domain.entity.EntityId.REALM_BITS;
import static org.hiero.mirror.common.domain.entity.EntityId.SHARD_BITS;

import com.hederahashgraph.api.proto.java.AccountID;
import com.hederahashgraph.api.proto.java.ContractID;
import com.hederahashgraph.api.proto.java.FileID;
import com.hederahashgraph.api.proto.java.ScheduleID;
import com.hederahashgraph.api.proto.java.TokenID;
import com.hederahashgraph.api.proto.java.TopicID;
import org.hiero.mirror.common.exception.InvalidEntityException;
import org.hiero.mirror.common.util.DomainUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;

@ExtendWith(OutputCaptureExtension.class)
final class EntityIdTest {

    @Test
    void isEmpty() {
        assertThat(EntityId.isEmpty(null)).isTrue();
        assertThat(EntityId.isEmpty(EntityId.EMPTY)).isTrue();
        assertThat(EntityId.isEmpty(EntityId.ZERO)).isTrue();
        assertThat(EntityId.isEmpty(EntityId.of(0L))).isTrue();
        assertThat(EntityId.isEmpty(EntityId.of(1L))).isFalse();
    }

    @ParameterizedTest
    @CsvSource({
        "0, 0, 0, 0",
        "0, 0, 10, 10",
        "0, 0, 4294967295, 4294967295",
        "10, 10, 10, 180146733873889290",
        "1023, 65535, 274877906943, -1",
        "1023, 0, 0, -18014398509481984"
    })
    void testEntityEncoding(long shard, long realm, long num, long encodedId) {
        assertThat(EntityId.of(shard, realm, num).getId()).isEqualTo(encodedId);
        assertThat(EntityId.of(encodedId)).isEqualTo(EntityId.of(shard, realm, num));
    }

    @Test
    void throwsExceptionEncoding() {
        assertThatThrownBy(() -> EntityId.of(1L << SHARD_BITS, 0, 0)).isInstanceOf(InvalidEntityException.class);
        assertThatThrownBy(() -> EntityId.of(0, 1L << REALM_BITS, 0)).isInstanceOf(InvalidEntityException.class);
        assertThatThrownBy(() -> EntityId.of(0, 0, 1L << NUM_BITS)).isInstanceOf(InvalidEntityException.class);
        assertThatThrownBy(() -> EntityId.of(-1, 0, 0)).isInstanceOf(InvalidEntityException.class);
        assertThatThrownBy(() -> EntityId.of(0, -1, 0)).isInstanceOf(InvalidEntityException.class);
        assertThatThrownBy(() -> EntityId.of(0, 0, -1)).isInstanceOf(InvalidEntityException.class);
    }

    @Test
    void testToString() {
        assertThat(EntityId.of(0, 1, 2).toString()).isEqualTo("0.1.2");
        assertThat(EntityId.of(-1).toString()).isEqualTo("1023.65535.274877906943");
    }

    @CsvSource({
        "null",
        ".",
        "0..1",
        "0",
        "0.0",
        "0.0.0.1",
        "-1.-2.-3",
        "0.0.9223372036854775808",
        "foo.bar.baz",
        // Malformed inputs that must be rejected rather than silently reinterpreted into a valid id
        "1.-2.3.4", // negative token dropped by the filter must not collapse "1.-2.3.4" into "1.3.4"
        "1..2.3", // empty token
        ".1.2.3", // leading dot
        "1.2.3." // trailing dot
    })
    @DisplayName("Convert String to EntityId and fail")
    @ParameterizedTest(name = "with {0}")
    void ofStringNegative(String string) {
        assertThatThrownBy(() -> EntityId.of(string)).isInstanceOf(IllegalArgumentException.class);
    }

    @DisplayName("Convert String to EntityId")
    @Test
    void ofStringPositive() {
        assertThat(EntityId.of("0.0.1")).isEqualTo(EntityId.of(0, 0, 1));
        assertThat(EntityId.of("0.1.2")).isEqualTo(EntityId.of(0, 1, 2));
        assertThat(EntityId.of("1.2.3")).isEqualTo(EntityId.of(1, 2, 3));
        assertThat(EntityId.of("0.0.0")).isEqualTo(EntityId.EMPTY);
    }

    @ParameterizedTest
    @CsvSource(
            emptyValue = "''",
            value = {
                "0.0.0,                   true",
                "0.0.1,                   true",
                "0.1.2,                   true",
                "1.2.3,                   true",
                ",                        false",
                "'',                      false",
                "0,                       false",
                "1,                       false",
                "0.1,                     false",
                "a.b.c,                   false",
                "0.1.2.3,                 false",
                "1.0.-1,                  false",
                "1.-2.3.4,                false",
                "1..2.3,                  false",
                "0.0.9223372036854775808, false",
            })
    void isValid(String id, boolean result) {
        assertThat(EntityId.isValid(id)).isEqualTo(result);
    }

    @Test
    void ofAccountId(CapturedOutput output) {
        final var accountId = AccountID.newBuilder()
                .setShardNum(1)
                .setRealmNum(2)
                .setAccountNum(3)
                .build();
        final var accountIdBad = AccountID.newBuilder()
                .setShardNum(-1)
                .setRealmNum(2)
                .setAccountNum(9223372036854775807L)
                .build();
        assertThat(EntityId.of(accountId))
                .isEqualTo(EntityId.tryOf(accountId))
                .isNotEqualTo(EntityId.EMPTY)
                .returns(1L, EntityId::getShard)
                .returns(2L, EntityId::getRealm)
                .returns(3L, EntityId::getNum);
        assertThatThrownBy(() -> EntityId.of(accountIdBad)).isInstanceOf(InvalidEntityException.class);
        System.setProperty(EntityId.INVALID_ENTITY_EXCEPTION_PROPERTY, "false");
        assertThat(EntityId.of(accountIdBad)).isEqualTo(EntityId.EMPTY);
        assertThat(output.getAll()).contains(DomainUtils.RECOVERABLE_ERROR);
        System.setProperty(EntityId.INVALID_ENTITY_EXCEPTION_PROPERTY, "true");
    }

    @Test
    void tryOfAccountId(CapturedOutput output) {
        final var accountId = AccountID.newBuilder()
                .setShardNum(-1)
                .setRealmNum(2)
                .setAccountNum(9223372036854775807L)
                .build();
        assertThat(EntityId.tryOf(accountId)).isEqualTo(EntityId.EMPTY);
        assertThat(output.getAll()).contains(DomainUtils.RECOVERABLE_ERROR);
    }

    @Test
    void ofTokenId(CapturedOutput output) {
        final var tokenId = TokenID.newBuilder()
                .setShardNum(1)
                .setRealmNum(2)
                .setTokenNum(3)
                .build();
        final var tokenIdBad = TokenID.newBuilder()
                .setShardNum(-1)
                .setRealmNum(2)
                .setTokenNum(9223372036854775807L)
                .build();
        assertThat(EntityId.of(tokenId))
                .isEqualTo(EntityId.tryOf(tokenId))
                .isNotEqualTo(EntityId.EMPTY)
                .returns(1L, EntityId::getShard)
                .returns(2L, EntityId::getRealm)
                .returns(3L, EntityId::getNum);
        assertThatThrownBy(() -> EntityId.of(tokenIdBad)).isInstanceOf(InvalidEntityException.class);
        System.setProperty(EntityId.INVALID_ENTITY_EXCEPTION_PROPERTY, "false");
        assertThat(EntityId.of(tokenIdBad)).isEqualTo(EntityId.EMPTY);
        assertThat(output.getAll()).contains(DomainUtils.RECOVERABLE_ERROR);
        System.setProperty(EntityId.INVALID_ENTITY_EXCEPTION_PROPERTY, "true");
    }

    @Test
    void tryOfTokenIdError(CapturedOutput output) {
        final var tokenId = TokenID.newBuilder()
                .setShardNum(-1)
                .setRealmNum(2)
                .setTokenNum(9223372036854775807L)
                .build();
        assertThat(EntityId.tryOf(tokenId)).isEqualTo(EntityId.EMPTY);
        assertThat(output.getAll()).contains(DomainUtils.RECOVERABLE_ERROR);
    }

    @Test
    void toAccountId() {
        assertThat(EntityId.of(1, 2, 3).toAccountID())
                .isEqualTo(AccountID.newBuilder()
                        .setShardNum(1)
                        .setRealmNum(2)
                        .setAccountNum(3)
                        .build());
    }

    @Test
    void toContractId() {
        assertThat(EntityId.of(1, 2, 3).toContractID())
                .isEqualTo(ContractID.newBuilder()
                        .setShardNum(1)
                        .setRealmNum(2)
                        .setContractNum(3)
                        .build());
    }

    @Test
    void toFileId() {
        assertThat(EntityId.of(1, 2, 3).toFileID())
                .isEqualTo(FileID.newBuilder()
                        .setShardNum(1)
                        .setRealmNum(2)
                        .setFileNum(3)
                        .build());
    }

    @Test
    void toScheduleId() {
        assertThat(EntityId.of(1, 2, 3).toScheduleID())
                .isEqualTo(ScheduleID.newBuilder()
                        .setShardNum(1)
                        .setRealmNum(2)
                        .setScheduleNum(3)
                        .build());
    }

    @Test
    void toTokenId() {
        assertThat(EntityId.of(1, 2, 3).toTokenID())
                .isEqualTo(TokenID.newBuilder()
                        .setShardNum(1)
                        .setRealmNum(2)
                        .setTokenNum(3)
                        .build());
    }

    @Test
    void toTopicId() {
        assertThat(EntityId.of(1, 2, 3).toTopicID())
                .isEqualTo(TopicID.newBuilder()
                        .setShardNum(1)
                        .setRealmNum(2)
                        .setTopicNum(3)
                        .build());
    }
}
