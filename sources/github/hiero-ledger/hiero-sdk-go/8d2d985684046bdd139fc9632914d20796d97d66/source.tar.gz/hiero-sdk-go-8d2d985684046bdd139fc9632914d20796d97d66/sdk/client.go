package hiero

// SPDX-License-Identifier: Apache-2.0

import (
	"context"
	_ "embed"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"time"
)

//go:embed addressbook/mainnet.pb
var mainnetAddress []byte
var mainnetNodes, _ = NodeAddressBookFromBytes(mainnetAddress)

//go:embed addressbook/previewnet.pb
var previewnetAddress []byte
var previewnetNodes, _ = NodeAddressBookFromBytes(previewnetAddress)

//go:embed addressbook/testnet.pb
var testnetAddress []byte
var testnetNodes, _ = NodeAddressBookFromBytes(testnetAddress)

// Client is the Hiero protocol wrapper for the SDK used by all
// transaction and query types.
type Client struct {
	defaultMaxTransactionFee Hbar
	defaultMaxQueryPayment   Hbar

	operator *_Operator

	network                         _Network
	mirrorNetwork                   *_MirrorNetwork
	autoValidateChecksums           bool
	defaultRegenerateTransactionIDs bool
	allowReceiptNodeFailover        bool
	maxAttempts                     *int
	grpcDeadline                    time.Duration

	maxBackoff time.Duration
	minBackoff time.Duration

	requestTimeout             time.Duration
	defaultNetworkUpdatePeriod time.Duration
	networkUpdateContext       context.Context
	cancelNetworkUpdate        context.CancelFunc
	logger                     Logger
	shard                      uint64
	realm                      uint64

	mirrorHttp *mirrorHttpState
}

// TransactionSigner is a closure or function that defines how transactions will be signed
type TransactionSigner func(message []byte) []byte

type _Operator struct {
	accountID  AccountID
	privateKey *PrivateKey
	publicKey  PublicKey
	signer     TransactionSigner
}

var mainnetMirror = []string{"mainnet-public.mirrornode.hedera.com:443"}
var testnetMirror = []string{"testnet.mirrornode.hedera.com:443"}
var previewnetMirror = []string{"previewnet.mirrornode.hedera.com:443"}

// ClientForMirrorNetwork constructs a client given a set of mirror network nodes.
func ClientForMirrorNetwork(mirrorNetwork []string) (*Client, error) {
	return ClientForMirrorNetworkWithShardAndRealm(mirrorNetwork, 0, 0)
}

// constructs a client given a set of mirror network nodes and the shard/realm of the address book.
func ClientForMirrorNetworkWithShardAndRealm(mirrorNetwork []string, shard uint64, realm uint64) (*Client, error) {
	net := _NewNetwork()
	client := _NewClient(net, mirrorNetwork, nil, true, shard, realm)
	addressbook, err := NewAddressBookQuery().
		SetFileID(GetAddressBookFileIDFor(shard, realm)).
		Execute(client)
	if err != nil {
		return nil, fmt.Errorf("failed to query address book: %v", err)
	}
	client.SetNetworkFromAddressBook(addressbook)
	return client, nil
}

// Deprecated: Use ClientForMirrorNetworkWithShardAndRealm instead.
func ClientForMirrorNetworkWithRealmAndShard(mirrorNetwork []string, realm uint64, shard uint64) (*Client, error) {
	return ClientForMirrorNetworkWithShardAndRealm(mirrorNetwork, shard, realm)
}

// ClientForNetwork constructs a client given a set of nodes.
// Deprecated
// Use ClientForNetworkV2 instead.
func ClientForNetwork(network map[string]AccountID) *Client {
	net := _NewNetwork()
	client := _NewClient(net, []string{}, nil, true, 0, 0)
	_ = client.SetNetwork(network)
	return client
}

// ClientForNetworkV2 constructs a client given a set of nodes.
func ClientForNetworkV2(network map[string]AccountID) (*Client, error) {
	isValidNetwork := true
	var shard uint64
	var realm uint64

	if len(network) == 0 {
		return nil, errors.New("network is empty")
	}

	for _, accountID := range network {
		if shard == 0 {
			shard = accountID.Shard
		}
		if realm == 0 {
			realm = accountID.Realm
		}
		if shard != accountID.Shard || realm != accountID.Realm {
			isValidNetwork = false
			break
		}
	}

	if !isValidNetwork {
		return nil, errors.New("network is not valid, all nodes must be in the same shard and realm")
	}

	net := _NewNetwork()
	client := _NewClient(net, []string{}, nil, true, shard, realm)
	err := client.SetNetwork(network)
	if err != nil {
		return nil, err
	}
	return client, nil
}

// ClientForMainnet returns a preconfigured client for use with the standard
// Hiero mainnet.
// Most users will want to set an _Operator account with .SetOperator so
// transactions can be automatically given TransactionIDs and signed.
func ClientForMainnet() *Client {
	return _NewClient(*_NetworkForMainnet(mainnetNodes._ToMap()), mainnetMirror, NewLedgerIDMainnet(), true, 0, 0)
}

// ClientForTestnet returns a preconfigured client for use with the standard
// Hiero testnet.
// Most users will want to set an _Operator account with .SetOperator so
// transactions can be automatically given TransactionIDs and signed.
func ClientForTestnet() *Client {
	return _NewClient(*_NetworkForTestnet(testnetNodes._ToMap()), testnetMirror, NewLedgerIDTestnet(), true, 0, 0)
}

// ClientForPreviewnet returns a preconfigured client for use with the standard
// Hiero previewnet.
// Most users will want to set an _Operator account with .SetOperator so
// transactions can be automatically given TransactionIDs and signed.
func ClientForPreviewnet() *Client {
	return _NewClient(*_NetworkForPreviewnet(previewnetNodes._ToMap()), previewnetMirror, NewLedgerIDPreviewnet(), true, 0, 0)
}

// newClient takes in a map of _Node addresses to their respective IDS (_Network)
// and returns a Client instance which can be used to
func _NewClient(network _Network, mirrorNetwork []string, ledgerId *LedgerID, shouldScheduleNetworkUpdate bool, shard uint64, realm uint64) *Client {
	ctx, cancel := context.WithCancel(context.Background())
	logger := NewLogger("hiero-sdk-go", LogLevel(os.Getenv("HEDERA_SDK_GO_LOG_LEVEL")))
	var defaultLogger Logger = logger

	client := Client{
		defaultMaxQueryPayment:          NewHbar(1),
		network:                         network,
		mirrorNetwork:                   _NewMirrorNetwork(),
		autoValidateChecksums:           false,
		maxAttempts:                     nil,
		minBackoff:                      250 * time.Millisecond,
		maxBackoff:                      8 * time.Second,
		grpcDeadline:                    10 * time.Second,
		requestTimeout:                  2 * time.Minute,
		defaultRegenerateTransactionIDs: true,
		allowReceiptNodeFailover:        false,
		defaultNetworkUpdatePeriod:      24 * time.Hour,
		networkUpdateContext:            ctx,
		cancelNetworkUpdate:             cancel,
		mirrorHttp:                      newMirrorHttpState(),
		logger:                          defaultLogger,
		shard:                           shard,
		realm:                           realm,
	}

	client.SetMirrorNetwork(mirrorNetwork)
	if ledgerId != nil {
		client.SetLedgerID(*ledgerId)
	}

	// We can't ask for AddressBook from non existent Mirror node
	if len(mirrorNetwork) > 0 && shouldScheduleNetworkUpdate {
		// Update the Addressbook, before the default timeout starts
		client._UpdateAddressBook()
		go client._ScheduleNetworkUpdate(ctx, client.defaultNetworkUpdatePeriod)
	}

	return &client
}

func (client *Client) _UpdateAddressBook() {
	addressbook, err := NewAddressBookQuery().
		SetFileID(GetAddressBookFileIDFor(client.shard, client.realm)).
		Execute(client)
	if err == nil && len(addressbook.NodeAddresses) > 0 {
		client.SetNetworkFromAddressBook(addressbook)
	}
}

func (client *Client) _ScheduleNetworkUpdate(ctx context.Context, duration time.Duration) {
	for {
		select {
		case <-ctx.Done():
			return
		case <-time.After(duration):
			client._UpdateAddressBook()
		}
	}
}

// CancelScheduledNetworkUpdate cancels the scheduled network update the network address book
func (client *Client) CancelScheduledNetworkUpdate() {
	client.cancelNetworkUpdate()
}

// SetNetworkUpdatePeriod sets how often the client will update the network address book
func (client *Client) SetNetworkUpdatePeriod(period time.Duration) *Client {
	client.defaultNetworkUpdatePeriod = period
	client.CancelScheduledNetworkUpdate()
	client.networkUpdateContext, client.cancelNetworkUpdate = context.WithCancel(context.Background())
	go client._ScheduleNetworkUpdate(client.networkUpdateContext, period)
	return client
}

// GetNetworkUpdatePeriod returns the current network update period
func (client *Client) GetNetworkUpdatePeriod() time.Duration {
	return client.defaultNetworkUpdatePeriod
}

// ClientForName set up the client for the selected network.
func ClientForName(name string) (*Client, error) {
	switch name {
	case string(NetworkNameTestnet):
		return ClientForTestnet(), nil
	case string(NetworkNamePreviewnet):
		return ClientForPreviewnet(), nil
	case string(NetworkNameMainnet):
		return ClientForMainnet(), nil
	case "local", "localhost":
		network := make(map[string]AccountID)
		network["127.0.0.1:35211"] = AccountID{Account: 3}
		mirror := []string{"127.0.0.1:5600"}
		client, err := ClientForNetworkV2(network)
		if err != nil {
			return nil, err
		}
		client.SetMirrorNetwork(mirror)
		return client, nil
	default:
		return &Client{}, fmt.Errorf("%q is not recognized as a valid Hiero _Network", name)
	}
}

type _ConfigOperator struct {
	AccountID  string `json:"accountId"`
	PrivateKey string `json:"privateKey"` //nolint
}

// TODO: Implement complete spec: https://gitlab.com/launchbadge/hedera/sdk/python/-/issues/45
type _ClientConfig struct {
	Network       interface{}      `json:"network"`
	MirrorNetwork interface{}      `json:"mirrorNetwork"`
	Shard         uint64           `json:"shard"`
	Realm         uint64           `json:"realm"`
	Operator      *_ConfigOperator `json:"operator"`
}

// ClientFromConfig takes in the byte slice representation of a JSON string or
// document and returns Client based on the configuration.
func ClientFromConfig(jsonBytes []byte) (*Client, error) {
	return clientFromConfig(jsonBytes, true)
}

// ClientFromConfigWithoutScheduleNetworkUpdate does not schedule network update
// the user has to call SetNetworkUpdatePeriod manually
func ClientFromConfigWithoutScheduleNetworkUpdate(jsonBytes []byte) (*Client, error) {
	client, err := clientFromConfig(jsonBytes, false)
	client.SetNetworkUpdatePeriod(0)
	return client, err
}

func clientFromConfig(jsonBytes []byte, shouldScheduleNetworkUpdate bool) (*Client, error) {
	var clientConfig _ClientConfig
	var client *Client

	err := json.Unmarshal(jsonBytes, &clientConfig)
	if err != nil {
		return nil, err
	}

	network := _NewNetwork()
	networkAddresses := make(map[string]AccountID)

	switch net := clientConfig.Network.(type) {
	case map[string]interface{}:
		for url, inter := range net {
			switch id := inter.(type) {
			case string:
				accountID, err := AccountIDFromString(id)
				if err != nil {
					return client, err
				}
				networkAddresses[url] = accountID
			default:
				return client, errors.New("network is expected to be map of string to string, or string")
			}
		}
		err = network.SetNetwork(networkAddresses)
		if err != nil {
			return &Client{}, err
		}
	case string:
		if len(net) > 0 {
			switch net {
			case string(NetworkNameMainnet):
				network = *_NetworkForMainnet(mainnetNodes._ToMap())
			case string(NetworkNamePreviewnet):
				network = *_NetworkForPreviewnet(previewnetNodes._ToMap())
			case string(NetworkNameTestnet):
				network = *_NetworkForTestnet(testnetNodes._ToMap())
			}
		}
	default:
		return client, errors.New("network is expected to be map of string to string, or string")
	}

	switch mirror := clientConfig.MirrorNetwork.(type) {
	case []interface{}:
		arr := make([]string, len(mirror))
		for i, inter := range mirror {
			switch str := inter.(type) {
			case string:
				arr[i] = str
			default:
				return client, errors.New("mirrorNetwork is expected to be either string or an array of strings")
			}
		}
		client = _NewClient(network, arr, nil, shouldScheduleNetworkUpdate, clientConfig.Shard, clientConfig.Realm)
	case string:
		if len(mirror) > 0 {
			switch mirror {
			case string(NetworkNameMainnet):
				client = _NewClient(network, mainnetMirror, NewLedgerIDMainnet(), shouldScheduleNetworkUpdate, clientConfig.Shard, clientConfig.Realm)
			case string(NetworkNameTestnet):
				client = _NewClient(network, testnetMirror, NewLedgerIDTestnet(), shouldScheduleNetworkUpdate, clientConfig.Shard, clientConfig.Realm)
			case string(NetworkNamePreviewnet):
				client = _NewClient(network, previewnetMirror, NewLedgerIDPreviewnet(), shouldScheduleNetworkUpdate, clientConfig.Shard, clientConfig.Realm)
			}
		}
	case nil:
		client = _NewClient(network, []string{}, nil, true, clientConfig.Shard, clientConfig.Realm)
	default:
		return client, errors.New("mirrorNetwork is expected to be a string, an array of strings or nil")
	}

	// if the _Operator is not provided, finish here
	if clientConfig.Operator == nil {
		return client, nil
	}

	operatorID, err := AccountIDFromString(clientConfig.Operator.AccountID)
	if err != nil {
		return client, err
	}

	operatorKey, err := PrivateKeyFromString(clientConfig.Operator.PrivateKey)

	if err != nil {
		return client, err
	}

	operator := _Operator{
		accountID:  operatorID,
		privateKey: &operatorKey,
		publicKey:  operatorKey.PublicKey(),
		signer:     operatorKey.Sign,
	}

	client.operator = &operator

	return client, nil
}

// ClientFromConfigFile takes a filename string representing the path to a JSON encoded
// Client file and returns a Client based on the configuration.
func ClientFromConfigFile(filename string) (*Client, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}

	defer func() {
		err = file.Close()
	}()

	configBytes, err := io.ReadAll(file)
	if err != nil {
		return nil, err
	}

	return ClientFromConfig(configBytes)
}

// Close is used to disconnect the Client from the _Network
func (client *Client) Close() error {
	client.CancelScheduledNetworkUpdate()

	// Close the mirror HTTP transport first so an error below cannot leak it.
	client.closeMirrorHttp(mirrorHttpDefaultCloseGrace)

	err := client.network._Close()
	if err != nil {
		return err
	}
	err = client.mirrorNetwork._Close()
	if err != nil {
		return err
	}

	return nil
}

// SetNetwork replaces all nodes in this Client with a new set of nodes.
func (client *Client) SetNetwork(network map[string]AccountID) error {
	return client.network.SetNetwork(network)
}

// GetNetwork returns the current set of nodes in this Client.
func (client *Client) GetNetwork() map[string]AccountID {
	return client.network._GetNetwork()
}

// SetMaxNodeReadmitTime The maximum amount of time to wait before attempting to
// reconnect to a node that has been removed from the network.
func (client *Client) SetMaxNodeReadmitTime(readmitTime time.Duration) {
	client.network._SetMaxNodeReadmitPeriod(readmitTime)
}

// GetMaxNodeReadmitTime returns the maximum amount of time to wait before attempting to
// reconnect to a node that has been removed from the network.
func (client *Client) GetMaxNodeReadmitPeriod() time.Duration {
	return client.network._GetMaxNodeReadmitPeriod()
}

// SetMinNodeReadmitTime The minimum amount of time to wait before attempting to
// reconnect to a node that has been removed from the network.
func (client *Client) SetMinNodeReadmitTime(readmitTime time.Duration) {
	client.network._SetMinNodeReadmitPeriod(readmitTime)
}

// GetMinNodeReadmitTime returns the minimum amount of time to wait before attempting to
// reconnect to a node that has been removed from the network.
func (client *Client) GetMinNodeReadmitPeriod() time.Duration {
	return client.network._GetMinNodeReadmitPeriod()
}

// SetMaxBackoff The maximum amount of time to wait between retries.
// Every retry attempt will increase the wait time exponentially until it reaches this time.
func (client *Client) SetMaxBackoff(max time.Duration) {
	if max.Nanoseconds() < 0 {
		panic("maxBackoff must be a positive duration")
	} else if max.Nanoseconds() < client.minBackoff.Nanoseconds() {
		panic("maxBackoff must be greater than or equal to minBackoff")
	}
	client.maxBackoff = max
}

// GetMaxBackoff returns the maximum amount of time to wait between retries.
func (client *Client) GetMaxBackoff() time.Duration {
	return client.maxBackoff
}

// SetMinBackoff sets the minimum amount of time to wait between retries.
func (client *Client) SetMinBackoff(min time.Duration) {
	if min.Nanoseconds() < 0 {
		panic("minBackoff must be a positive duration")
	} else if client.maxBackoff.Nanoseconds() < min.Nanoseconds() {
		panic("minBackoff must be less than or equal to maxBackoff")
	}
	client.minBackoff = min
}

// GetMinBackoff returns the minimum amount of time to wait between retries.
func (client *Client) GetMinBackoff() time.Duration {
	return client.minBackoff
}

// SetMaxAttempts sets the maximum number of times to attempt a transaction or query.
func (client *Client) SetMaxAttempts(max int) {
	client.maxAttempts = &max
}

// GetMaxAttempts returns the maximum number of times to attempt a transaction or query.
func (client *Client) GetMaxAttempts() int {
	if client.maxAttempts == nil {
		return -1
	}

	return *client.maxAttempts
}

// SetMaxNodeAttempts sets the maximum number of times to attempt a transaction or query on a single node.
func (client *Client) SetMaxNodeAttempts(max int) {
	client.network._SetMaxNodeAttempts(max)
}

// GetMaxNodeAttempts returns the maximum number of times to attempt a transaction or query on a single node.
func (client *Client) GetMaxNodeAttempts() int {
	return client.network._GetMaxNodeAttempts()
}

// Deprecated: use SetNodeMinBackoff
func (client *Client) SetNodeWaitTime(nodeWait time.Duration) {
	client.network._SetNodeMinBackoff(nodeWait)
}

// Deprecated: use GetNodeMinBackoff
func (client *Client) GetNodeWaitTime() time.Duration {
	return client.network._GetNodeMinBackoff()
}

// SetNodeMinBackoff sets the minimum amount of time to wait between retries on a single node.
func (client *Client) SetNodeMinBackoff(nodeWait time.Duration) {
	client.network._SetNodeMinBackoff(nodeWait)
}

// GetNodeMinBackoff returns the minimum amount of time to wait between retries on a single node.
func (client *Client) GetNodeMinBackoff() time.Duration {
	return client.network._GetNodeMinBackoff()
}

// SetNodeMaxBackoff sets the maximum amount of time to wait between retries on a single node.
func (client *Client) SetNodeMaxBackoff(nodeWait time.Duration) {
	client.network._SetNodeMaxBackoff(nodeWait)
}

// GetNodeMaxBackoff returns the maximum amount of time to wait between retries on a single node.
func (client *Client) GetNodeMaxBackoff() time.Duration {
	return client.network._GetNodeMaxBackoff()
}

// GetGrpcDeadline returns the grpc deadline for a single grpc request.
// All executable objects will inherit this deadline from the client
func (client Client) GetGrpcDeadline() time.Duration {
	return client.grpcDeadline
}

// SetGrpcDeadline returns the grpc deadline for a single grpc request.
// All executable objects will inherit this deadline from the client
func (client *Client) SetGrpcDeadline(deadline time.Duration) {
	client.grpcDeadline = deadline
}

// SetMaxNodesPerTransaction sets the maximum number of nodes to try for a single transaction.
func (client *Client) SetMaxNodesPerTransaction(max int) {
	client.network._SetMaxNodesPerTransaction(max)
}

// SetNetwork replaces all _Nodes in the Client with a new set of _Nodes.
// (e.g. for an Address Book update).
func (client *Client) SetMirrorNetwork(mirrorNetwork []string) {
	_ = client.mirrorNetwork._SetNetwork(mirrorNetwork)
}

// GetNetwork returns the mirror network node list.
func (client *Client) GetMirrorNetwork() []string {
	return client.mirrorNetwork._GetNetwork()
}

// GetShard returns the shard for the Client.
func (client *Client) GetShard() uint64 {
	return client.shard
}

// GetRealm returns the realm for the Client.
func (client *Client) GetRealm() uint64 {
	return client.realm
}

// SetTransportSecurity sets if transport security should be used to connect to consensus nodes.
// If transport security is enabled all connections to consensus nodes will use TLS, and
// the server's certificate hash will be compared to the hash stored in the NodeAddressBook
// for the given network.
// *Note*: If transport security is enabled, but {@link Client#isVerifyCertificates()} is disabled
// then server certificates will not be verified.
func (client *Client) SetTransportSecurity(tls bool) *Client {
	client.network._SetTransportSecurity(tls)

	return client
}

// SetCertificateVerification sets if server certificates should be verified against an existing address book.
func (client *Client) SetCertificateVerification(verify bool) *Client {
	client.network._SetVerifyCertificate(verify)

	return client
}

// GetCertificateVerification returns if server certificates should be verified against an existing address book.
func (client *Client) GetCertificateVerification() bool {
	return client.network._GetVerifyCertificate()
}

// Deprecated: Use SetLedgerID instead
func (client *Client) SetNetworkName(name NetworkName) {
	ledgerID, _ := LedgerIDFromNetworkName(name)
	client.SetLedgerID(*ledgerID)
}

// Deprecated: Use GetLedgerID instead
func GetNetworkName(client Client) *NetworkName {
	if ledgerID := client.GetLedgerID(); ledgerID != nil {
		if name, err := ledgerID.ToNetworkName(); err == nil {
			return &name
		}
	}
	return nil
}

// SetLedgerID sets the ledger ID for the Client.
func (client *Client) SetLedgerID(id LedgerID) {
	client.network._SetLedgerID(id)
}

// GetLedgerID returns the ledger ID for the Client.
// Will return nil if the client is initialized with custom nodes via [ClientForNetwork].
func (client *Client) GetLedgerID() *LedgerID {
	return client.network._GetLedgerID()
}

// SetAutoValidateChecksums sets if an automatic entity ID checksum validation should be performed.
func (client *Client) SetAutoValidateChecksums(validate bool) {
	client.autoValidateChecksums = validate
}

// GetAutoValidateChecksums returns if an automatic entity ID checksum validation should be performed.
func (client *Client) GetAutoValidateChecksums() bool {
	return client.autoValidateChecksums
}

// SetDefaultRegenerateTransactionIDs sets if an automatic transaction ID regeneration should be performed.
func (client *Client) SetDefaultRegenerateTransactionIDs(regen bool) {
	client.defaultRegenerateTransactionIDs = regen
}

// GetDefaultRegenerateTransactionIDs returns if an automatic transaction ID regeneration should be performed.
func (client *Client) GetDefaultRegenerateTransactionIDs() bool {
	return client.defaultRegenerateTransactionIDs
}

// SetAllowReceiptNodeFailover sets if the client should allow the receipt node to failover.
func (client *Client) SetAllowReceiptNodeFailover(allowFailover bool) {
	client.allowReceiptNodeFailover = allowFailover
}

// GetAllowReceiptNodeFailover returns if the client should allow the receipt node to failover.
func (client *Client) GetAllowReceiptNodeFailover() bool {
	return client.allowReceiptNodeFailover
}

// SetNodeMinReadmitPeriod sets the minimum amount of time to wait before attempting to
// reconnect to a node that has been removed from the network.
func (client *Client) SetNodeMinReadmitPeriod(period time.Duration) {
	client.network._SetNodeMinReadmitPeriod(period)
}

// SetNodeMaxReadmitPeriod sets the maximum amount of time to wait before attempting to
// reconnect to a node that has been removed from the network.
func (client *Client) SetNodeMaxReadmitPeriod(period time.Duration) {
	client.network._SetNodeMaxReadmitPeriod(period)
}

// GetNodeMinReadmitPeriod returns the minimum amount of time to wait before attempting to
// reconnect to a node that has been removed from the network.
func (client *Client) GetNodeMinReadmitPeriod() time.Duration {
	return client.network._GetNodeMinReadmitPeriod()
}

// GetNodeMaxReadmitPeriod returns the maximum amount of time to wait before attempting to
// reconnect to a node that has been removed from the network.
func (client *Client) GetNodeMaxReadmitPeriod() time.Duration {
	return client.network._GetNodeMaxReadmitPeriod()
}

// SetOperator sets that account that will, by default, be paying for
// transactions and queries built with the client and the associated key
// with which to automatically sign transactions.
func (client *Client) SetOperator(accountID AccountID, privateKey PrivateKey) *Client {
	client.operator = &_Operator{
		accountID:  accountID,
		privateKey: &privateKey,
		publicKey:  privateKey.PublicKey(),
		signer:     privateKey.Sign,
	}

	return client
}

// SetOperatorWith sets that account that will, by default, be paying for
// transactions and queries built with the client, the account's PublicKey
// and a callback that will be invoked when a transaction needs to be signed.
func (client *Client) SetOperatorWith(accountID AccountID, publicKey PublicKey, signer TransactionSigner) *Client {
	client.operator = &_Operator{
		accountID:  accountID,
		privateKey: nil,
		publicKey:  publicKey,
		signer:     signer,
	}

	return client
}

// SetRequestTimeout sets the timeout for the total time budget for a complete Transaction or Query execute operation
func (client *Client) SetRequestTimeout(timeout time.Duration) {
	client.requestTimeout = timeout
}

// GetRequestTimeout returns the timeout for  the total time budget for a complete Transaction or Query execute operation
func (client *Client) GetRequestTimeout() time.Duration {
	return client.requestTimeout
}

// GetOperatorAccountID returns the ID for the _Operator
func (client *Client) GetOperatorAccountID() AccountID {
	if client.operator != nil {
		return client.operator.accountID
	}

	return AccountID{}
}

// GetOperatorPublicKey returns the Key for the _Operator
func (client *Client) GetOperatorPublicKey() PublicKey {
	if client.operator != nil {
		return client.operator.publicKey
	}

	return PublicKey{}
}

// treasuryAccountNum is the treasury system account, present on every network from genesis.
const treasuryAccountNum = 2

// Ping checks the liveness of the given consensus node, returning nil if the node is reachable.
//
// It sends a COST_ANSWER getAccountInfo query for the treasury account, which a healthy node answers
// with the query fee without executing it: nothing is charged and no operator is required.
//
// The probe follows the client's retry settings. A node already in backoff is never contacted, so
// Ping fails without reaching the network; readmission happens when the backoff elapses, not on a
// successful Ping.
func (client *Client) Ping(nodeID AccountID) error {
	_, err := NewAccountInfoQuery().
		SetAccountID(AccountID{Account: treasuryAccountNum}).
		SetNodeAccountIDs([]AccountID{nodeID}).
		GetCost(client)
	return err
}

func (client *Client) PingAll() {
	for _, s := range client.GetNetwork() {
		_ = client.Ping(s)
	}
}

// SetNetworkFromAddressBook replaces all nodes in this Client with the nodes in the Address Book.
func (client *Client) SetNetworkFromAddressBook(addressBook NodeAddressBook) *Client {
	client.network._SetNetworkFromAddressBook(addressBook)
	return client
}

// SetDefaultMaxQueryPayment sets the default maximum payment allowed for queries.
func (client *Client) SetDefaultMaxQueryPayment(defaultMaxQueryPayment Hbar) error {
	if defaultMaxQueryPayment.AsTinybar() < 0 {
		return errors.New("DefaultMaxQueryPayment must be non-negative")
	}

	client.defaultMaxQueryPayment = defaultMaxQueryPayment
	return nil
}

// GetDefaultMaxQueryPayment returns the default maximum payment allowed for queries.
func (client *Client) GetDefaultMaxQueryPayment() Hbar {
	return client.defaultMaxQueryPayment
}

// SetDefaultMaxTransactionFee sets the default maximum fee allowed for transactions.
func (client *Client) SetDefaultMaxTransactionFee(defaultMaxTransactionFee Hbar) error {
	if defaultMaxTransactionFee.AsTinybar() < 0 {
		return errors.New("DefaultMaxTransactionFee must be non-negative")
	}

	client.defaultMaxTransactionFee = defaultMaxTransactionFee
	return nil
}

// GetDefaultMaxTransactionFee returns the default maximum fee allowed for transactions.
func (client *Client) GetDefaultMaxTransactionFee() Hbar {
	return client.defaultMaxTransactionFee
}

func (client *Client) SetLogger(logger Logger) *Client {
	client.logger = logger
	return client
}

func (client *Client) GetLogger() Logger {
	return client.logger
}

func (client *Client) SetLogLevel(level LogLevel) *Client {
	client.logger.SetLevel(level)
	return client
}

func (client *Client) GetMirrorRestApiBaseUrl() (string, error) {
	mirrorNode, err := client.mirrorNetwork._GetNextMirrorNode()
	if err != nil {
		return "", err
	}
	return mirrorNode.getBaseRestUrl()
}
