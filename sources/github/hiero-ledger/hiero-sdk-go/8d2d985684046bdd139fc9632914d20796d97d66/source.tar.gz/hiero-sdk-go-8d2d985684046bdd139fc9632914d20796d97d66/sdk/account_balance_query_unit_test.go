//go:build all || unit

package hiero

// SPDX-License-Identifier: Apache-2.0

import (
	"sync/atomic"
	"testing"
	"time"

	"github.com/hiero-ledger/hiero-sdk-go/v2/proto/services"

	"github.com/stretchr/testify/assert"

	"github.com/stretchr/testify/require"
)

type recordingLogger struct {
	warnings []string
}

func (l *recordingLogger) SetSilent(bool)                     {}
func (l *recordingLogger) SetLevel(LogLevel)                  {}
func (l *recordingLogger) SubLoggerWithLevel(LogLevel) Logger { return l }
func (l *recordingLogger) Error(string, ...interface{})       {}
func (l *recordingLogger) Warn(msg string, _ ...interface{})  { l.warnings = append(l.warnings, msg) }
func (l *recordingLogger) Info(string, ...interface{})        {}
func (l *recordingLogger) Debug(string, ...interface{})       {}
func (l *recordingLogger) Trace(string, ...interface{})       {}

// Not parallel: it swaps the package level logger.
func TestUnitAccountBalanceQueryConstructorWarns(t *testing.T) {
	recorder := &recordingLogger{}
	previous := accountBalanceQueryLogger
	accountBalanceQueryLogger = recorder
	defer func() { accountBalanceQueryLogger = previous }()

	NewAccountBalanceQuery()

	require.Len(t, recorder.warnings, 1)
	require.Equal(t, accountBalanceQueryDeprecationMessage, recorder.warnings[0])
	require.Contains(t, recorder.warnings[0], "AccountBalanceQuery is no longer supported")
}

func TestUnitAccountBalanceQueryValidate(t *testing.T) {
	t.Parallel()

	client, err := _NewMockClient()
	client.SetLedgerID(*NewLedgerIDTestnet())
	require.NoError(t, err)
	client.SetAutoValidateChecksums(true)
	accountID, err := AccountIDFromString("0.0.123-esxsf")
	require.NoError(t, err)

	balanceQuery := NewAccountBalanceQuery().
		SetAccountID(accountID)

	err = balanceQuery.validateNetworkOnIDs(client)
	require.NoError(t, err)
}

func TestUnitAccountBalanceQueryValidateWrong(t *testing.T) {
	t.Parallel()

	client, err := _NewMockClient()
	client.SetLedgerID(*NewLedgerIDTestnet())
	require.NoError(t, err)
	client.SetAutoValidateChecksums(true)
	accountID, err := AccountIDFromString("0.0.123-rmkykd")
	require.NoError(t, err)

	balanceQuery := NewAccountBalanceQuery().
		SetAccountID(accountID)

	err = balanceQuery.validateNetworkOnIDs(client)
	assert.Error(t, err)
	if err != nil {
		assert.Equal(t, "network mismatch or wrong checksum given, given checksum: rmkykd, correct checksum esxsf, network: testnet", err.Error())
	}
}

func TestUnitAccountBalanceQueryGet(t *testing.T) {
	t.Parallel()

	spenderAccountID1 := AccountID{Account: 7}

	balance := NewAccountBalanceQuery().
		SetAccountID(spenderAccountID1).
		SetNodeAccountIDs([]AccountID{{Account: 10}, {Account: 11}, {Account: 12}})

	balance.GetAccountID()
	balance.GetNodeAccountIDs()
	balance.GetPaymentTransactionID()
}

func TestUnitAccountBalanceQuerySetNothing(t *testing.T) {
	t.Parallel()

	balance := NewAccountBalanceQuery()

	balance.GetAccountID()
	balance.GetNodeAccountIDs()
	balance.GetPaymentTransactionID()
}

func TestUnitAccountBalanceQueryCoverage(t *testing.T) {
	t.Parallel()

	checksum := "dmqui"
	contract := ContractID{Contract: 3, checksum: &checksum}
	account := AccountID{Account: 3, checksum: &checksum}
	nodeAccountID := []AccountID{{Account: 10}}
	transactionID := TransactionIDGenerate(AccountID{Account: 324})

	client, err := _NewMockClient()
	client.SetLedgerID(*NewLedgerIDTestnet())
	require.NoError(t, err)
	client.SetAutoValidateChecksums(true)

	query := NewAccountBalanceQuery().
		SetMaxRetry(3).
		SetMaxBackoff(time.Second * 30).
		SetMinBackoff(time.Second * 10).
		SetAccountID(account).
		SetContractID(contract).
		SetNodeAccountIDs(nodeAccountID).
		SetPaymentTransactionID(transactionID).
		SetMaxQueryPayment(NewHbar(23)).
		SetQueryPayment(NewHbar(3))

	err = query.validateNetworkOnIDs(client)

	require.NoError(t, err)
	query.GetNodeAccountIDs()
	query.GetMaxBackoff()
	query.GetMinBackoff()
	query.getName()
	query.GetAccountID()
	query.GetContractID()

	_AccountBalanceFromProtobuf(nil)
	bal := AccountBalance{Hbars: NewHbar(2)}
	bal._ToProtobuf()
}

// accountBalanceHandler records that a request reached the mock server and answers it successfully.
func accountBalanceHandler(called *atomic.Bool, responseType services.ResponseType) func(*services.Query) *services.Response {
	return func(*services.Query) *services.Response {
		called.Store(true)
		return &services.Response{
			Response: &services.Response_CryptogetAccountBalance{
				CryptogetAccountBalance: &services.CryptoGetAccountBalanceResponse{
					Header: &services.ResponseHeader{NodeTransactionPrecheckCode: services.ResponseCodeEnum_OK, ResponseType: responseType},
				},
			},
		}
	}
}

func TestUnitAccountBalanceQueryExecuteSendsNoRequest(t *testing.T) {
	t.Parallel()

	var called atomic.Bool
	client, server := NewMockClientAndServer([][]interface{}{{accountBalanceHandler(&called, services.ResponseType_ANSWER_ONLY)}})
	defer server.Close()

	_, err := NewAccountBalanceQuery().
		SetNodeAccountIDs([]AccountID{{Account: 3}}).
		SetAccountID(AccountID{Account: 1800}).
		Execute(client)

	require.ErrorIs(t, err, errAccountBalanceQueryDeprecated)
	require.ErrorContains(t, err, "AccountBalanceQuery is no longer supported")
	assert.False(t, called.Load())
}

func TestUnitAccountBalanceQueryGetCostSendsNoRequest(t *testing.T) {
	t.Parallel()

	var called atomic.Bool
	client, server := NewMockClientAndServer([][]interface{}{{accountBalanceHandler(&called, services.ResponseType_COST_ANSWER)}})
	defer server.Close()

	_, err := NewAccountBalanceQuery().
		SetNodeAccountIDs([]AccountID{{Account: 3}}).
		SetAccountID(AccountID{Account: 1800}).
		GetCost(client)

	require.ErrorIs(t, err, errAccountBalanceQueryDeprecated)
	assert.False(t, called.Load())
}

func TestUnitAccountBalanceQueryNoClient(t *testing.T) {
	t.Parallel()

	_, err := NewAccountBalanceQuery().
		Execute(nil)

	require.ErrorIs(t, err, errAccountBalanceQueryDeprecated)
}
