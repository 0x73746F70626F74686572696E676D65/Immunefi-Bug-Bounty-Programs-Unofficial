# Hiero TSC Nominees for September 2025 Election

In September 2025, the Hiero Technical Steering Committee (TSC) will hold an election for the maintainer seat that is currently held by [George Spasov](https://github.com/Perseverance)

- The **nomination** period for candidates will run from **August 26** (start of day UTC) to **September 9**, 2025 (end of day UTC).
- The **election** will be held from **September 10** (start of day UTC) to **September 21**, 2025 (end of day UTC).
- The **announcement** of the new TSC member will take place at the TSC meeting on **September 23**, 2025.

![Election timeline](timeline.png)

## How to Nominate a Candidate

To nominate a candidate, create a single markdown file titled "[candidate-name].md" with the name of the candidate as
the file name (with spaces replaced by dashes). See [sample-nomination.md](sample-nomination.md) for a template to follow. 

A nominee must fullfill the following requirements (as defined in the [TSC Charter](https://github.com/hiero-ledger/governance/blob/main/hiero-technical-charter.md)):

> - TSC Members are expected to cover deep technical domains including consensus technologies,
>   technical operations, tokenization, smart contracts, ecosystem applications such as wallets, exchanges, etc. (3.viii. in charter)
> - Nominees for the TSC shall (2.ix.b. in charter):
>  - Commit that they have the available bandwidth to make the time to invest in the TSC,
>  - Demonstrate an advanced level of professional experience as engineers in the scope of the Project, and
>  - Operate neutrally in discussions and put the goals and success of the Project in balance with any particular sub-project governed by the TSC.

A PR that contains a new nomination file must be approved by the nominee before it can be merged.
The nominee must review the nomination file and ensure that all information is correct, including the github username.
Once the nominee has reviewed the file, they should comment on the PR with "I approve this nomination" to indicate their approval.

Any PR that fullfills the requirements before the end of the 9th September 2025 (UTC) will be considered for the election.

## Who is allowed to vote

Every [maintainer](https://github.com/hiero-ledger/governance/blob/main/roles-and-groups.md#maintainers) of the Hiero project is allowed to vote.
You can find an overview on all our maintainer groups and the individual maintainers [here](https://github.com/orgs/hiero-ledger/teams?query=maintainer).
At Hiero we have already over 60 maintainers today.

## How can I vote

As mentioned the election is open for voting until **September 21**, 2025 (end of day UTC).
If you are a maintainer you should have received an invite to the voting as a GitHub notification.
Even if you missed that notification you can vote [here](https://vote.heliosvoting.org/helios/e/hiero-tsc-election-september-2025/vote).
If you have questions about that tool or the voting process the [video we recorded for a previous election](https://www.youtube.com/watch?v=aF-eLgFQQwg) might be helpfull.
