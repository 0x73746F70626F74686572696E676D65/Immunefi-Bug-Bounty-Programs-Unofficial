// SPDX-License-Identifier: Apache-2.0

<!-- --------------------------------------------------------------------------------------------------------------- -->
<!--                                                     TEMPLATE                                                    -->
<!-- --------------------------------------------------------------------------------------------------------------- -->

<template>

  <PageFrameV2 :pageTitle="pageTitle">
    <template #page-title>
      Contract
      <span style="white-space: nowrap; font-size: smaller">
        {{ parsedContractId }}
      </span>
    </template>

    <template #left-toolbar>
      <Tabs
          :tab-ids="tabIds"
          :tab-labels="tabLabels"
          :selected-tab="selectedTabId"
          @update:selected-tab="onUpdate($event)"
      >
        <template #extra>
          <ArrowLink
              v-if="parsedContractId && accountRoute"
              :route="accountRoute" id="showAccountLink"
              :is-contrasted="true"
              text="Associated account"
          />
        </template>
      </Tabs>
    </template>

    <template #right-toolbar>
      <ButtonView
          v-if="enableVerification && !isVerified"
          :size="ButtonSize.small"
          :for-toolbar="true"
          @action="showVerifyDialog = true"
      >
        VERIFY
      </ButtonView>
    </template>

    <template v-if="notification" #banner>
      <NotificationBanner :message="notification"/>
    </template>

    <router-view/>

  </PageFrameV2>

  <ContractVerificationInfoDialog
      v-model:show-dialog="showVerifyDialog"
      :contract-address="contractAddress"
  />

</template>

<!-- --------------------------------------------------------------------------------------------------------------- -->
<!--                                                      SCRIPT                                                     -->
<!-- --------------------------------------------------------------------------------------------------------------- -->

<script setup lang="ts">

import {computed, onBeforeUnmount, onMounted, ref} from 'vue';
import ButtonView from "@/elements/ButtonView.vue";
import NotificationBanner from "@/components/NotificationBanner.vue";
import PageFrameV2 from "@/components/page/PageFrameV2.vue";
import Tabs from "@/components/Tabs.vue";
import {ButtonSize} from "@/dialogs/core/DialogUtils.ts";
import {ContractAnalyzer} from "@/utils/analyzer/ContractAnalyzer.ts";
import {ContractLocParser} from "@/utils/parser/ContractLocParser";
import {routeManager} from "@/utils/RouteManager.ts";
import ContractVerificationInfoDialog from "@/dialogs/verification/ContractVerificationInfoDialog.vue";
import ArrowLink from "@/components/ArrowLink.vue";

const props = defineProps({
  contractId: {
    type: String,
    required: true
  },
  network: String
})

const tabIds = routeManager.contractDetailsOperator.tabIds
const tabLabels = routeManager.contractDetailsOperator.tabLabels
const selectedTabId = routeManager.contractDetailsOperator.selectedTabId

const onUpdate = (tabId: string | null) => {
  if (tabId !== null) {
    routeManager.routeToContract(props.contractId, null, tabId, true)
  }
}

//
// ContractLocParser
//
const contractLocParser = new ContractLocParser(computed(() => props.contractId ?? null))
onMounted(() => contractLocParser.mount())
onBeforeUnmount(() => contractLocParser.unmount())
const parsedContractId = contractLocParser.contractId
const contractAddress = contractLocParser.ethereumAddress
const notification = contractLocParser.errorNotification
const pageTitle = computed(() =>
    parsedContractId.value !== null ? "Contract " + parsedContractId.value : null
)

//
//  ContractAnalyzer
//
const contractAnalyzer = new ContractAnalyzer(parsedContractId)
onMounted(() => contractAnalyzer.mount())
onBeforeUnmount(() => contractAnalyzer.unmount())
const isVerified = contractAnalyzer.isVerified
const enableVerification = routeManager.enableVerification

const showVerifyDialog = ref(false)

//
// Account route
//

const accountRoute = computed(() => {
  return parsedContractId.value !== null ? routeManager.makeRouteToAccount(parsedContractId.value) : null
})


</script>

<!-- --------------------------------------------------------------------------------------------------------------- -->
<!--                                                       STYLE                                                     -->
<!-- --------------------------------------------------------------------------------------------------------------- -->

<style scoped>

</style>
