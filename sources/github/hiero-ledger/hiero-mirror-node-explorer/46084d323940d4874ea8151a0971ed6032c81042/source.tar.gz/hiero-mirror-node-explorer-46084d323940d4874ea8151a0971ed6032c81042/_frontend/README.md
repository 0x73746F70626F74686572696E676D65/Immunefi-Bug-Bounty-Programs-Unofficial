# Hiero Mirror Node Explorer

[![OpenSSF Scorecard](https://api.scorecard.dev/projects/github.com/hiero-ledger/hiero-mirror-node-explorer/badge)](https://scorecard.dev/viewer/?uri=github.com/hiero-ledger/hiero-mirror-node-explorer)
[![CII Best Practices](https://bestpractices.coreinfrastructure.org/projects/10697/badge)](https://bestpractices.coreinfrastructure.org/projects/10697)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

Visual Explorer for the Hiero DLT.

## Quickstart

### Clone the project

```bash
git clone https://github.com/hiero-ledger/hiero-mirror-node-explorer.git
cd hiero-mirror-node-explorer/_frontend
```

### Install dependencies

```bash
npm ci
```

### Compile and hot-reload for development

```bash
npm run dev
```

### Compile and minify for production

```bash
npm run build
```

## Configuration

The configuration of the explorer is based on these 2 files, which need to be found at the root of the app in order for the
Explorer to start:

- `/public/core-config.json`
- `/public/networks-config.json`

Details for these configuration files can be found in [CONFIGURATION.md](https://github.com/hiero-ledger/hiero-mirror-node-explorer/blob/main/_frontend/CONFIGURATION.md).

## Development

### Lint files (find and fix problems)

```bash
npm run lint
```

### Run unit tests

```bash
npm run test:unit
```

### Run end-to-end tests interactively

```bash
npm run test:e2e:dev
```

### Run end-to-end tests in headless browser mode

```bash
npm run test:e2e
```

## Run in Docker

### Build the Docker image (skip to use pre-built image)

```bash
npm run docker:build
```

### Copy and adjust configuration of Hiero networks as needed

```bash
cp networks-config-http-example.json public/networks-config.json
```

### Start the Docker container (fetches a pre-built image if not built locally)

```bash
npm run docker:start
```

### Launch Explorer

```bash
open http://localhost:8080
```

### Stop the Docker container

```bash
npm run docker:stop
```

## Run in Kubernetes

To run in [Kubernetes](https://kubernetes.io) the hiero-explorer [Helm](https://helm.sh) chart can be used. First,
obtain access to a Kubernetes cluster running version 1.23 or greater. [Minikube](https://minikube.sigs.k8s.io/docs/)
can be used for a local Kubernetes cluster.

```bash
helm upgrade --install hiero-explorer chart/
```

### Configure custom networks

Core configuration and network configuration need to be provided to the Explorer in the `values.yaml` file
(see [CONFIGURATION.md](https://github.com/hiero-ledger/hiero-mirror-node-explorer/blob/main/_frontend/CONFIGURATION.md) for details on configuration parameters).

The network configuration needs to provide at least the description on one supported networks.

An example:

```yaml
 config: |
  [
    {
      "name": "testnet",
      "displayName": "TESTNET",
      "url": "https://testnet.mirrornode.hedera.com/",
      "ledgerID": "01"
    }
  ]
```

## Testing smart contract verification with a local sourcify server

The default sourcify configuration in `networks-config.json` allows the explorer to contact a local installation of sourcify for verifying contracts.
Note that the production sourcify server will not accept verification requests from an explorer running on localhost.

Use the following commands to use sourcify locally:

### Check environment set-up for running sourcify locally

```bash
npm run sourcify:setup
```

### Start sourcify service. This should open a page saying that the server is alive

```bash
npm run sourcify:start
```

### Stop sourcify service

```bash
npm run sourcify:stop
```

Please see
[sourcify-setup/README.md](https://github.com/hashgraph/hedera-mirror-node-explorer/blob/main/_frontend/sourcify-setup/README.md) for more details.

## Contributing

Contributions are welcome. Please see the
[contributing guide](https://github.com/hashgraph/.github/blob/main/CONTRIBUTING.md)
to see how you can get involved.

## Help/Community

- Join our [community discussions](https://discord.lfdecentralizedtrust.org/) on discord.

## About Users and Maintainers

- Users and Maintainers guidelines are located in **[Hiero-Ledger's roles and groups guidelines](https://github.com/hiero-ledger/governance/blob/main/roles-and-groups.md#maintainers).**

## Code of Conduct

Hiero uses the Linux Foundation Decentralised Trust [Code of Conduct](https://www.lfdecentralizedtrust.org/code-of-conduct).

## License

[Apache License 2.0](LICENSE)
