// SPDX-License-Identifier: Apache-2.0

<!-- --------------------------------------------------------------------------------------------------------------- -->
<!--                                                     TEMPLATE                                                    -->
<!-- --------------------------------------------------------------------------------------------------------------- -->

<template>

  <DashboardCardV2>

    <template #title>
      <ContractSectionTitle :contract-id="props.contractId">Contract Source</ContractSectionTitle>
    </template>

    <template #right-control>
      <div v-if="isVerified" class="contract-code-controls">
        <DownloadButton @click="handleDownload"/>
        <SelectView v-model="selectedSource" :small="true">
          <option value="">All source files</option>
          <optgroup label="Main contract file">
            <option :value="contractFileName">{{ sourceFileName }}</option>
          </optgroup>
          <optgroup label="Include files">
            <option v-for="file in solidityFiles" v-bind:key="file.path"
                    v-bind:value="file.name"
                    v-show="isImportFile(file)">
              {{ relevantPath(file.path) }}
            </option>
          </optgroup>
        </SelectView>
      </div>
    </template>

    <template #content>
      <template v-if="isVerified">
        <ContractSourceValue :source-files="solidityFiles" :filter="selectedSource"/>
      </template>

      <template v-else-if="isAnalyzing">
        <EmptyTable :loading="true"/>
      </template>

      <template v-else>
        <DocSnippet
            doc-hint="See how to verify a contract"
            doc-url="https://docs.hedera.com/hedera/core-concepts/smart-contracts/verifying-smart-contracts-beta"
        >
          <p>The contract source code will be available once the contract is verified.</p>
        </DocSnippet>
      </template>
    </template>

  </DashboardCardV2>

</template>

<!-- --------------------------------------------------------------------------------------------------------------- -->
<!--                                                      SCRIPT                                                     -->
<!-- --------------------------------------------------------------------------------------------------------------- -->

<script setup lang="ts">

import DashboardCardV2 from "@/components/DashboardCardV2.vue";
import ContractSectionTitle from "@/components/contract/ContractSectionTitle.vue";
import ContractSourceValue from "@/components/values/ContractSourceValue.vue";
import {computed, onBeforeUnmount, onMounted, ref, watch} from "vue";
import {ContractAnalyzer} from "@/utils/analyzer/ContractAnalyzer.ts";
import DownloadButton from "@/components/DownloadButton.vue";
import SelectView from "@/elements/SelectView.vue";
import JSZip from "jszip";
import {saveAs} from "file-saver";
import {SourcifyResponseItem} from "@/utils/cache/SourcifyCache.ts";
import DocSnippet from "@/components/DocSnippet.vue";
import EmptyTable from "@/components/EmptyTable.vue";

const props = defineProps({
  contractId: String,
  network: String
})

//
// ContractAnalyzer
//

const contractId = computed(() => props.contractId ?? null)
const contractAnalyzer = new ContractAnalyzer(contractId)
onMounted(() => contractAnalyzer.mount())
onBeforeUnmount(() => contractAnalyzer.unmount())
const isVerified = contractAnalyzer.isVerified
const solidityFiles = contractAnalyzer.solidityFiles
const sourceFileName = contractAnalyzer.sourceFileName
const contractFileName = contractAnalyzer.contractFileName
const isAnalyzing = contractAnalyzer.isAnalyzing

const selectedSource = ref('')
watch(contractAnalyzer.contractFileName,
    () => selectedSource.value = contractAnalyzer.contractFileName.value ?? '', {immediate: true})

const isImportFile = (file: SourcifyResponseItem): boolean => {
  return file.name !== contractAnalyzer.contractFileName.value
}


//
// handleDownload
//

const handleDownload = async () => {
  if (selectedSource.value === '') {
    const zip = new JSZip();
    for (const fileItem of contractAnalyzer.solidityFiles.value) {
      zip.file(fileItem.path, fileItem.content);
    }
    zip.generateAsync({type: "blob"})
        .then(function (content: Blob) {
          const zipName = contractAnalyzer.contractAddress.value + '.zip'
          saveAs(content, zipName);
        });
  } else {
    const item = contractAnalyzer.solidityFiles.value.find(item => item.name === selectedSource.value)
    if (item) {
      const blob = new Blob([item.content], {type: "text/plain"})
      if (blob !== null) {
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.setAttribute('href', url)
        a.setAttribute('download', item.name);
        a.click()
      }
    } else {
      console.log("WARNING: cannot find item for path " + selectedSource.value)
    }
  }
}

const relevantPath = (fullPath: string): string => {
  return fullPath.substring(fullPath.indexOf('sources') + 8)
}


</script>

<!-- --------------------------------------------------------------------------------------------------------------- -->
<!--                                                      STYLE                                                      -->
<!-- --------------------------------------------------------------------------------------------------------------- -->

<style scoped>

div.contract-code-controls {
  align-items: center;
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

</style>
