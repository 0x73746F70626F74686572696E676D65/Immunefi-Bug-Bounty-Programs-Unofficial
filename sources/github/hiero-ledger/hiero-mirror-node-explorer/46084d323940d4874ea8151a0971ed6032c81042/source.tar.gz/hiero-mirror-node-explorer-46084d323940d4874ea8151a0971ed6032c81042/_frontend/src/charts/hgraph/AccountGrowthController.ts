// SPDX-License-Identifier: Apache-2.0

import {ThemeController} from "@/components/ThemeController.ts";
import {RouteManager} from "@/utils/RouteManager.ts";
import {GenericMetricController} from "@/charts/hgraph/GenericMetricController.ts";
import {EcosystemMetric} from "@/charts/hgraph/EcosystemMetric.ts";
import {ChartRange} from "@/charts/core/ChartRange.ts";
import {ChartConfiguration} from "chart.js/auto";

export class AccountGrowthController extends GenericMetricController {

    //
    // Public
    //

    public constructor(themeController: ThemeController, routeManager: RouteManager) {
        super("Accounts Created Over Time", "account_growth", themeController, routeManager,
            [ChartRange.month, ChartRange.all, ChartRange.year, ChartRange.day])
    }

    //
    // ChartController
    //

    protected makeChartConfig(metrics: EcosystemMetric[],
                              range: ChartRange/*,
                              context: CanvasRenderingContext2D*/): ChartConfiguration {
        return this.makeBarChartConfig(metrics, range, false, "# of accounts")
    }
}
