// SPDX-License-Identifier: Apache-2.0
package com.hedera.hashgraph.sdk;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.protobuf.ByteString;
import com.hedera.hashgraph.sdk.proto.RegisteredServiceEndpoint;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Represent a Registered Block Node
 */
public class BlockNodeServiceEndpoint extends RegisteredServiceEndpointBase<BlockNodeServiceEndpoint> {
    /**
     * An indicator of what API this endpoint supports.
     */
    private List<BlockNodeApi> endpointApis = new ArrayList<>();

    /**
     * Constructor.
     */
    public BlockNodeServiceEndpoint() {}

    /**
     * Returns the list of APIs supported by this endpoint.
     *
     * @return the list of supported block node APIs
     */
    public List<BlockNodeApi> getEndpointApis() {
        return endpointApis;
    }

    /**
     * Sets the list of APIs supported by this endpoint.
     *
     * @param endpointApis the list of APIs to support; must not be null
     * @return {@code this}
     */
    public BlockNodeServiceEndpoint setEndpointApis(List<BlockNodeApi> endpointApis) {
        Objects.requireNonNull(endpointApis, "endpointApis must not be null");
        this.endpointApis = new ArrayList<>(endpointApis);
        return this;
    }

    /**
     * Adds a single API to the list of supported APIs for this endpoint.
     *
     * @param endpointApi the API to add; must not be null
     * @return {@code this}
     */
    public BlockNodeServiceEndpoint addEndpointApi(BlockNodeApi endpointApi) {
        Objects.requireNonNull(endpointApi, "endpointApi must not be null");
        this.endpointApis.add(endpointApi);
        return this;
    }

    /**
     * Create a BlockNodeServiceEndpoint object from protobuf
     *
     * @param serviceEndpoint the protobuf object
     * @return the new instance of BlockNodeServiceEndpoint
     */
    static BlockNodeServiceEndpoint fromProtobuf(
            com.hedera.hashgraph.sdk.proto.RegisteredServiceEndpoint serviceEndpoint) {
        Objects.requireNonNull(serviceEndpoint, "serviceEndpoint must not be null");

        var blockNodeEndpoint = new BlockNodeServiceEndpoint()
                .setPort(serviceEndpoint.getPort())
                .setRequiresTls(serviceEndpoint.getRequiresTls());

        if (serviceEndpoint.hasBlockNode()) {
            for (var apiProto : serviceEndpoint.getBlockNode().getEndpointApiList()) {
                blockNodeEndpoint.addEndpointApi(BlockNodeApi.valueOf(apiProto));
            }
        }

        if (serviceEndpoint.hasIpAddress()) {
            blockNodeEndpoint.setIpAddress(serviceEndpoint.getIpAddress().toByteArray());
        }

        if (serviceEndpoint.hasDomainName()) {
            blockNodeEndpoint.setDomainName(serviceEndpoint.getDomainName());
        }

        return blockNodeEndpoint;
    }

    @Override
    com.hedera.hashgraph.sdk.proto.RegisteredServiceEndpoint toProtobuf() {
        if (ipAddress == null && domainName == null) {
            throw new IllegalArgumentException(
                    "RegisteredServiceEndpoint must define either an ipAddress or a domainName");
        }

        var blockNodeBuilder = RegisteredServiceEndpoint.BlockNodeEndpoint.newBuilder()
                .addAllEndpointApi(endpointApis.stream().map(api -> api.code).toList());

        var registeredServiceEndpoint = com.hedera.hashgraph.sdk.proto.RegisteredServiceEndpoint.newBuilder()
                .setPort(port)
                .setRequiresTls(requiresTls)
                .setBlockNode(blockNodeBuilder);

        if (ipAddress != null) {
            registeredServiceEndpoint.setIpAddress(ByteString.copyFrom(this.ipAddress));
        }

        if (domainName != null) {
            registeredServiceEndpoint.setDomainName(this.domainName);
        }

        return registeredServiceEndpoint.build();
    }

    /**
     * Parses BlockNodeServiceEndpoint from the type-specific JSON object the MirrorNode.
     *
     * @param json the json containing block node specific data
     * @return {@code this}
     */
    static BlockNodeServiceEndpoint fromJson(JsonObject json) {
        Objects.requireNonNull(json, "json must not be null");

        List<String> apis = new ArrayList<>();
        if (json.has("endpoint_apis")) {
            for (JsonElement api : json.getAsJsonArray("endpoint_apis")) {
                apis.add(api.getAsString());
            }
        }

        return new BlockNodeServiceEndpoint()
                .setEndpointApis(
                        apis.stream().map(a -> BlockNodeApi.valueOf(a)).collect(Collectors.toUnmodifiableList()));
    }

    @Override
    public String toString() {
        return toStringHelper().add("endpointApis", endpointApis).toString();
    }
}
