// SPDX-License-Identifier: Apache-2.0
package com.hedera.hashgraph.sdk;

import com.google.common.base.MoreObjects;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hedera.hashgraph.sdk.proto.ExchangeRateSet;
import com.hedera.hashgraph.sdk.proto.TimestampSeconds;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import org.bouncycastle.util.encoders.Hex;

/**
 * The consensus result for a transaction, which might not be currently
 * known, or may succeed or fail.
 */
public final class TransactionReceipt {

    /**
     * The transaction's ID
     */
    @Nullable
    public final TransactionId transactionId;
    /**
     * Whether the transaction succeeded or failed (or is unknown).
     */
    public final Status status;

    /**
     * The exchange rate of Hbars to cents (USD).
     */
    public final ExchangeRate exchangeRate;

    /**
     * Next exchange rate which will take effect when current rate expires
     */
    public final ExchangeRate nextExchangeRate;

    /**
     * The account ID, if a new account was created.
     */
    @Nullable
    public final AccountId accountId;

    /**
     * The file ID, if a new file was created.
     */
    @Nullable
    public final FileId fileId;

    /**
     * The contract ID, if a new contract was created.
     */
    @Nullable
    public final ContractId contractId;

    /**
     * The topic ID, if a new topic was created.
     */
    @Nullable
    public final TopicId topicId;

    /**
     * The token ID, if a new token was created.
     */
    @Nullable
    public final TokenId tokenId;

    /**
     * Updated sequence number for a consensus service topic.
     * Set for {@link TopicMessageSubmitTransaction}.
     */
    @Nullable
    public final Long topicSequenceNumber;

    /**
     * Updated running hash for a consensus service topic.
     * Set for {@link TopicMessageSubmitTransaction}.
     */
    @Nullable
    public final ByteString topicRunningHash;

    /**
     * In the receipt of TokenMint, TokenWipe, TokenBurn, For fungible tokens - the current total
     * supply of this token. For non fungible tokens - the total number of NFTs issued for a given
     * tokenID
     */
    public final Long totalSupply;

    /**
     * In the receipt of a ScheduleCreate, the id of the newly created Scheduled Entity
     */
    @Nullable
    public final ScheduleId scheduleId;

    /**
     * In the receipt of a ScheduleCreate or ScheduleSign that resolves to SUCCESS, the
     * TransactionID that should be used to query for the receipt or record of the relevant
     * scheduled transaction
     */
    @Nullable
    public final TransactionId scheduledTransactionId;

    /**
     * In the receipt of a TokenMint for tokens of type NON_FUNGIBLE_UNIQUE, the serial numbers of
     * the newly created NFTs
     */
    public final List<Long> serials;

    /**
     * In the receipt of a NodeCreate, NodeUpdate, NodeDelete, the id of the newly created node.
     * An affected node identifier.<br/>
     * This value SHALL be set following a `createNode` transaction.<br/>
     * This value SHALL be set following a `updateNode` transaction.<br/>
     * This value SHALL be set following a `deleteNode` transaction.<br/>
     * This value SHALL NOT be set following any other transaction.
     */
    public final long nodeId;

    /**
     * The identifier of a newly created RegisteredNode.
     * <p>
     * This value SHALL be set following a `createRegisteredNode`
     * transaction.<br/>
     * This value SHALL NOT be set following any other transaction.<br/>
     * This value SHALL be unique within a given network.
     */
    public final long registeredNodeId;

    /**
     * The receipts of processing all transactions with the given id, in consensus time order.
     */
    public final List<TransactionReceipt> duplicates;

    /**
     * The receipts (if any) of all child transactions spawned by the transaction with the
     * given top-level id, in consensus order. Always empty if the top-level status is UNKNOWN.
     */
    public final List<TransactionReceipt> children;

    TransactionReceipt(
            @Nullable TransactionId transactionId,
            Status status,
            ExchangeRate exchangeRate,
            ExchangeRate nextExchangeRate,
            @Nullable AccountId accountId,
            @Nullable FileId fileId,
            @Nullable ContractId contractId,
            @Nullable TopicId topicId,
            @Nullable TokenId tokenId,
            @Nullable Long topicSequenceNumber,
            @Nullable ByteString topicRunningHash,
            Long totalSupply,
            @Nullable ScheduleId scheduleId,
            @Nullable TransactionId scheduledTransactionId,
            List<Long> serials,
            long nodeId,
            long registeredNodeId,
            List<TransactionReceipt> duplicates,
            List<TransactionReceipt> children) {
        this.transactionId = transactionId;
        this.status = status;
        this.exchangeRate = exchangeRate;
        this.nextExchangeRate = nextExchangeRate;
        this.accountId = accountId;
        this.fileId = fileId;
        this.contractId = contractId;
        this.topicId = topicId;
        this.tokenId = tokenId;
        this.topicSequenceNumber = topicSequenceNumber;
        this.topicRunningHash = topicRunningHash;
        this.totalSupply = totalSupply;
        this.scheduleId = scheduleId;
        this.scheduledTransactionId = scheduledTransactionId;
        this.serials = serials;
        this.nodeId = nodeId;
        this.registeredNodeId = registeredNodeId;
        this.duplicates = duplicates;
        this.children = children;
    }

    /**
     * Create transaction receipt from protobuf.
     *
     * @param transactionReceipt        the protobuf
     * @param duplicates                list of duplicates
     * @param children                  list of children
     * @return                          the new transaction receipt
     */
    static TransactionReceipt fromProtobuf(
            com.hedera.hashgraph.sdk.proto.TransactionReceipt transactionReceipt,
            List<TransactionReceipt> duplicates,
            List<TransactionReceipt> children,
            @Nullable TransactionId transactionId) {
        var status = Status.valueOf(transactionReceipt.getStatus());

        var rate = transactionReceipt.getExchangeRate();
        var exchangeRate = ExchangeRate.fromProtobuf(rate.getCurrentRate());
        var nextExchangeRate = ExchangeRate.fromProtobuf(rate.getNextRate());

        var accountId =
                transactionReceipt.hasAccountID() ? AccountId.fromProtobuf(transactionReceipt.getAccountID()) : null;

        var fileId = transactionReceipt.hasFileID() ? FileId.fromProtobuf(transactionReceipt.getFileID()) : null;

        var contractId =
                transactionReceipt.hasContractID() ? ContractId.fromProtobuf(transactionReceipt.getContractID()) : null;

        var topicId = transactionReceipt.hasTopicID() ? TopicId.fromProtobuf(transactionReceipt.getTopicID()) : null;

        var tokenId = transactionReceipt.hasTokenID() ? TokenId.fromProtobuf(transactionReceipt.getTokenID()) : null;

        var topicSequenceNumber =
                transactionReceipt.getTopicSequenceNumber() == 0 ? null : transactionReceipt.getTopicSequenceNumber();

        var topicRunningHash =
                transactionReceipt.getTopicRunningHash().isEmpty() ? null : transactionReceipt.getTopicRunningHash();

        var totalSupply = transactionReceipt.getNewTotalSupply();

        var scheduleId =
                transactionReceipt.hasScheduleID() ? ScheduleId.fromProtobuf(transactionReceipt.getScheduleID()) : null;

        var scheduledTransactionId = transactionReceipt.hasScheduledTransactionID()
                ? TransactionId.fromProtobuf(transactionReceipt.getScheduledTransactionID())
                : null;

        var serials = transactionReceipt.getSerialNumbersList();

        var nodeId = transactionReceipt.getNodeId();

        var registeredNodeId = transactionReceipt.getRegisteredNodeId();

        return new TransactionReceipt(
                transactionId,
                status,
                exchangeRate,
                nextExchangeRate,
                accountId,
                fileId,
                contractId,
                topicId,
                tokenId,
                topicSequenceNumber,
                topicRunningHash,
                totalSupply,
                scheduleId,
                scheduledTransactionId,
                serials,
                nodeId,
                registeredNodeId,
                duplicates,
                children);
    }

    /**
     * Create a transaction receipt from a protobuf.
     *
     * @param transactionReceipt        the protobuf
     * @return                          the new transaction receipt
     */
    public static TransactionReceipt fromProtobuf(
            com.hedera.hashgraph.sdk.proto.TransactionReceipt transactionReceipt) {
        return fromProtobuf(transactionReceipt, new ArrayList<>(), new ArrayList<>(), null);
    }

    static TransactionReceipt fromProtobuf(
            com.hedera.hashgraph.sdk.proto.TransactionReceipt transactionReceipt,
            @Nullable TransactionId transactionId) {
        return fromProtobuf(transactionReceipt, new ArrayList<>(), new ArrayList<>(), transactionId);
    }

    /**
     * Create a transaction receipt from a byte array.
     *
     * @param bytes                     the byte array
     * @return                          the new transaction receipt
     * @throws InvalidProtocolBufferException       when there is an issue with the protobuf
     */
    public static TransactionReceipt fromBytes(byte[] bytes) throws InvalidProtocolBufferException {
        return fromProtobuf(com.hedera.hashgraph.sdk.proto.TransactionReceipt.parseFrom(bytes).toBuilder()
                .build());
    }

    /**
     * Validate the transaction status in the receipt.
     *
     * @param shouldValidate Whether to perform transaction status validation
     * @return {@code this}
     * @throws ReceiptStatusException when shouldValidate is true and the transaction status is not SUCCESS
     */
    public TransactionReceipt validateStatus(boolean shouldValidate) throws ReceiptStatusException {
        if (shouldValidate && status != Status.SUCCESS && status != Status.FEE_SCHEDULE_FILE_PART_UPLOADED) {
            throw new ReceiptStatusException(transactionId, this);
        }
        return this;
    }

    /**
     * Create the protobuf.
     *
     * @return                          the protobuf representation
     */
    com.hedera.hashgraph.sdk.proto.TransactionReceipt toProtobuf() {
        var transactionReceiptBuilder = com.hedera.hashgraph.sdk.proto.TransactionReceipt.newBuilder()
                .setStatus(status.code)
                .setExchangeRate(ExchangeRateSet.newBuilder()
                        .setCurrentRate(com.hedera.hashgraph.sdk.proto.ExchangeRate.newBuilder()
                                .setHbarEquiv(exchangeRate.hbars)
                                .setCentEquiv(exchangeRate.cents)
                                .setExpirationTime(TimestampSeconds.newBuilder()
                                        .setSeconds(exchangeRate.expirationTime.getEpochSecond())))
                        .setNextRate(com.hedera.hashgraph.sdk.proto.ExchangeRate.newBuilder()
                                .setHbarEquiv(nextExchangeRate.hbars)
                                .setCentEquiv(nextExchangeRate.cents)
                                .setExpirationTime(TimestampSeconds.newBuilder()
                                        .setSeconds(nextExchangeRate.expirationTime.getEpochSecond()))))
                .setNewTotalSupply(totalSupply);

        if (accountId != null) {
            transactionReceiptBuilder.setAccountID(accountId.toProtobuf());
        }

        if (fileId != null) {
            transactionReceiptBuilder.setFileID(fileId.toProtobuf());
        }

        if (contractId != null) {
            transactionReceiptBuilder.setContractID(contractId.toProtobuf());
        }

        if (topicId != null) {
            transactionReceiptBuilder.setTopicID(topicId.toProtobuf());
        }

        if (tokenId != null) {
            transactionReceiptBuilder.setTokenID(tokenId.toProtobuf());
        }

        if (topicSequenceNumber != null) {
            transactionReceiptBuilder.setTopicSequenceNumber(topicSequenceNumber);
        }

        if (topicRunningHash != null) {
            transactionReceiptBuilder.setTopicRunningHash(topicRunningHash);
        }

        if (scheduleId != null) {
            transactionReceiptBuilder.setScheduleID(scheduleId.toProtobuf());
        }

        if (scheduledTransactionId != null) {
            transactionReceiptBuilder.setScheduledTransactionID(scheduledTransactionId.toProtobuf());
        }

        for (var serial : serials) {
            transactionReceiptBuilder.addSerialNumbers(serial);
        }

        transactionReceiptBuilder.setNodeId(nodeId);

        transactionReceiptBuilder.setRegisteredNodeId(registeredNodeId);

        return transactionReceiptBuilder.build();
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("transactionId", transactionId)
                .add("status", status)
                .add("exchangeRate", exchangeRate)
                .add("nextExchangeRate", nextExchangeRate)
                .add("accountId", accountId)
                .add("fileId", fileId)
                .add("contractId", contractId)
                .add("topicId", topicId)
                .add("tokenId", tokenId)
                .add("topicSequenceNumber", topicSequenceNumber)
                .add("topicRunningHash", topicRunningHash != null ? Hex.encode(topicRunningHash.toByteArray()) : null)
                .add("totalSupply", totalSupply)
                .add("scheduleId", scheduleId)
                .add("scheduledTransactionId", scheduledTransactionId)
                .add("serials", serials)
                .add("nodeId", nodeId)
                .add("registeredNodeId", registeredNodeId)
                .add("duplicates", duplicates)
                .add("children", children)
                .toString();
    }

    /**
     * Build a JSON representation of this receipt
     *
     * @return the JSON object
     */
    JsonObject toJsonObject() {
        var json = new JsonObject();
        json.addProperty("status", status.toString());
        addNullableString(json, "accountId", accountId != null ? accountId.toString() : null);
        addNullableString(json, "fileId", fileId != null ? fileId.toString() : null);
        addNullableString(json, "contractId", contractId != null ? contractId.toString() : null);
        addNullableString(json, "topicId", topicId != null ? topicId.toString() : null);
        addNullableString(json, "tokenId", tokenId != null ? tokenId.toString() : null);
        addNullableString(json, "scheduleId", scheduleId != null ? scheduleId.toString() : null);
        json.add("exchangeRate", exchangeRate.toJsonObject());
        json.add("nextExchangeRate", nextExchangeRate.toJsonObject());
        addNullableString(
                json, "topicSequenceNumber", topicSequenceNumber != null ? String.valueOf(topicSequenceNumber) : null);
        addNullableString(
                json,
                "topicRunningHash",
                topicRunningHash != null ? Hex.toHexString(topicRunningHash.toByteArray()) : null);
        json.addProperty("totalSupply", String.valueOf(totalSupply));
        addNullableString(
                json,
                "scheduledTransactionId",
                scheduledTransactionId != null ? scheduledTransactionId.toString() : null);
        var serialsArray = new JsonArray();
        for (var serial : serials) {
            serialsArray.add(String.valueOf(serial));
        }
        json.add("serials", serialsArray);
        var duplicatesArray = new JsonArray();
        for (var duplicate : duplicates) {
            duplicatesArray.add(duplicate.toJsonObject());
        }
        json.add("duplicates", duplicatesArray);
        var childrenArray = new JsonArray();
        for (var child : children) {
            childrenArray.add(child.toJsonObject());
        }
        json.add("children", childrenArray);
        json.addProperty("registeredNodeId", String.valueOf(registeredNodeId));
        json.addProperty("nodeId", String.valueOf(nodeId));
        return json;
    }

    private static void addNullableString(JsonObject json, String key, @Nullable String value) {
        if (value != null) {
            json.addProperty(key, value);
        } else {
            json.add(key, JsonNull.INSTANCE);
        }
    }

    /**
     * Serialize this receipt to a JSON string, matching the JS SDK's
     * {@code JSON.stringify(receipt.toJSON())} so all SDKs produce identical JSON.
     *
     * @return the JSON string
     */
    public String toJson() {
        return new GsonBuilder().disableHtmlEscaping().create().toJson(toJsonObject());
    }

    /**
     * Create the byte array.
     *
     * @return                          the byte array representation
     */
    public byte[] toBytes() {
        return toProtobuf().toByteArray();
    }
}
