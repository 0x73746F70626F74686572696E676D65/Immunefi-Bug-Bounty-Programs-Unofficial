// SPDX-License-Identifier: Apache-2.0
group = "org.hiero"

val bouncycastle = "1.86"
val grpc = "1.84.0"
val protobuf = "4.36.2"
val slf4j = "2.0.20"
val mockito = "5.24.0"

dependencies {
    api(platform("org.springframework.boot:spring-boot-dependencies:4.1.1"))
    api(platform("io.netty:netty-bom:4.2.18.Final"))
}

dependencies.constraints {
    api("com.esaulpaugh:headlong:13.3.1") { because("com.esaulpaugh.headlong") }
    api("com.google.code.findbugs:jsr305:3.0.2") { because("java.annotation") }
    api("com.google.code.gson:gson:2.14.0") { because("com.google.gson") }
    api("com.google.protobuf:protobuf-java:$protobuf") { because("com.google.protobuf") }
    api("com.google.protobuf:protobuf-javalite:$protobuf") { because("com.google.protobuf") }
    api("io.grpc:grpc-api:$grpc") { because("io.grpc") }
    api("io.grpc:grpc-inprocess:$grpc") { because("io.grpc.inprocess") }
    api("io.grpc:grpc-protobuf-lite:$grpc") { because("io.grpc.protobuf.lite") }
    api("io.grpc:grpc-protobuf:$grpc") { because("io.grpc.protobuf") }
    api("io.grpc:grpc-stub:$grpc") { because("io.grpc.stub") }
    api("io.grpc:grpc-netty:$grpc")
    api("io.grpc:grpc-netty-shaded:$grpc")
    api("io.grpc:grpc-okhttp:$grpc")
    api("org.bouncycastle:bcpkix-jdk18on:$bouncycastle") { because("org.bouncycastle.pkix") }
    api("org.bouncycastle:bcprov-jdk18on:$bouncycastle") { because("org.bouncycastle.provider") }
    api("org.slf4j:slf4j-api:$slf4j") { because("org.slf4j") }

    // Testing
    api("com.fasterxml.jackson.core:jackson-core:2.22.3") { because("com.fasterxml.jackson.core") }
    api("com.google.guava:guava:33.7.1-android") { because("com.google.common") }
    api("io.github.json-snapshot:json-snapshot:1.0.17") { because("json.snapshot") }
    api("org.apache.commons:commons-lang3:3.20.0") { because("org.apache.commons.lang3") }
    api("org.assertj:assertj-core:3.27.7") { because("org.assertj.core") }
    api("org.junit.jupiter:junit-jupiter-api:6.1.3") { because("org.junit.jupiter.api") }
    api("org.mockito:mockito-core:$mockito") { because("org.mockito") }
    api("org.mockito:mockito-junit-jupiter:$mockito") { because("org.mockito.junit.jupiter") }

    api("com.google.protobuf:protoc:$protobuf")
    api("io.grpc:protoc-gen-grpc-java:$grpc")

    api("com.thetransactioncompany:jsonrpc2-server:2.0")

    // Temporary override due to SNYK-JAVA-ORGAPACHETOMCATEMBED-16643259
    // TO BE removed when spring-boot-dependencies gets updated
    api("org.apache.tomcat.embed:tomcat-embed-core:11.0.26")
    api("org.springframework:spring-webmvc:7.0.9")
    api("org.springframework:spring-context:7.0.9")
    api("org.springframework:spring-web:7.0.9")
    api("ch.qos.logback:logback-core:1.6.4")

    tasks.checkVersionConsistency {
        // Versions of additional tools that are not part of the product or test module paths
        excludes.add("com.google.protobuf:protoc")
        excludes.add("io.grpc:protoc-gen-grpc-java")
        // Versions that are not used but published as constraints for users
        excludes.add("io.grpc:grpc-netty")
        excludes.add("io.grpc:grpc-okhttp")
    }
}
