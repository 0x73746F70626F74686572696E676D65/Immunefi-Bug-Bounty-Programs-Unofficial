import { MikroORM } from '@mikro-orm/core'
import { PostgreSqlDriver, SchemaGenerator } from '@mikro-orm/postgresql'
import { INestApplication } from '@nestjs/common'
import { Server } from 'net'
import request from 'supertest'

import { AuthorizationTokenType } from '../src/common/const'
import { jwtConfigDefaults } from '../src/core/config/configs/jwt.config'
import { UserRole } from '../src/core/database'
import { LoginRequest, LogoutRequest, RefreshRequest } from '../src/oauth/dto'
import { RegisterUserRequest } from '../src/user/dto'
import { initializeMikroOrm, startTestApp } from './helpers'

describe('E2E authorization', () => {
  let ormSchemaGenerator: SchemaGenerator
  let orm: MikroORM<PostgreSqlDriver>

  let nestApp: INestApplication
  let app: Server

  beforeAll(async () => {
    orm = await initializeMikroOrm()
    ormSchemaGenerator = orm.schema

    await ormSchemaGenerator.refresh()

    nestApp = await startTestApp()
    app = nestApp.getHttpServer() as Server
  })

  afterAll(async () => {
    if (nestApp) await nestApp.close()
    if (ormSchemaGenerator) await ormSchemaGenerator.clear()
    if (orm) await orm.close(true)
  })

  let userSeq = 0
  const newUser = () => ({
    name: 'user' + Date.now().toString() + '-' + userSeq++,
    password: 'Password1234!',
  })

  test('auth flow', async () => {
    const user = newUser()
    const createUserResponse = await request(app)
      .post('/api/v1/user/register')
      .send({
        name: user.name,
        password: user.password,
        role: UserRole.Issuer,
      } satisfies RegisterUserRequest)

    expect(createUserResponse.status).toBe(201)

    const loginUserResponse = await request(app)
      .post('/api/v1/oauth/token')
      .send({
        name: user.name,
        password: user.password,
      } satisfies LoginRequest)

    expect(loginUserResponse.status).toBe(200)
    expect(loginUserResponse.body.access).toBeDefined()
    expect(loginUserResponse.body.refresh).toBeDefined()
    expect(loginUserResponse.body.token_type).toBe(AuthorizationTokenType)

    await new Promise((res) => setTimeout(res, 1000))

    const refreshTokenResponse = await request(app)
      .post('/api/v1/oauth/refresh')
      .auth(loginUserResponse.body.access, { type: 'bearer' })
      .send({
        refresh: loginUserResponse.body.refresh,
      } satisfies RefreshRequest)

    expect(refreshTokenResponse.status).toBe(200)

    expect(refreshTokenResponse.body.access).toBeDefined()
    expect(refreshTokenResponse.body.refresh).toBeDefined()
    expect(refreshTokenResponse.body.token_type).toBe(AuthorizationTokenType)

    expect(refreshTokenResponse.body.access).not.toBe(loginUserResponse.body.access)
    expect(refreshTokenResponse.body.refresh).not.toBe(loginUserResponse.body.refresh)

    const refreshPayload = JSON.parse(
      Buffer.from(refreshTokenResponse.body.refresh.split('.')[1], 'base64').toString('utf8'),
    ) as { iat: number; exp: number }
    expect(refreshPayload.exp - refreshPayload.iat).toBe(jwtConfigDefaults.refreshExpiry)

    const revokeTokenResponse = await request(app)
      .post('/api/v1/oauth/revoke')
      .auth(refreshTokenResponse.body.access, { type: 'bearer' })
      .send({
        refresh: loginUserResponse.body.refresh,
      } satisfies LogoutRequest)

    expect(revokeTokenResponse.status).toBe(205)
  })

  test('login fails with wrong password', async () => {
    const user = newUser()
    const createUserResponse = await request(app)
      .post('/api/v1/user/register')
      .send({
        name: user.name,
        password: user.password,
        role: UserRole.Issuer,
      } satisfies RegisterUserRequest)

    expect(createUserResponse.status).toBe(201)

    const loginUserResponse = await request(app)
      .post('/api/v1/oauth/token')
      .send({
        name: user.name,
        password: 'WrongPassword123!',
      } satisfies LoginRequest)

    expect(loginUserResponse.status).toBe(401)
  })

  test('profile endpoint requires authentication', async () => {
    const response = await request(app).get('/api/v1/user/profile')

    expect(response.status).toBe(401)
  })

  test('logout rejects revoking a refresh token owned by another user', async () => {
    const register = (u: LoginRequest) =>
      request(app)
        .post('/api/v1/user/register')
        .send({ name: u.name, password: u.password, role: UserRole.Issuer } satisfies RegisterUserRequest)

    const login = (u: LoginRequest) => request(app).post('/api/v1/oauth/token').send(u)

    const alice = newUser()
    const bob = newUser()

    expect((await register(alice)).status).toBe(201)
    expect((await register(bob)).status).toBe(201)

    const aliceLogin = await login(alice)
    const bobLogin = await login(bob)
    expect(aliceLogin.status).toBe(200)
    expect(bobLogin.status).toBe(200)

    // Bob authenticates with his own (valid) access token but targets Alice's refresh token → rejected.
    const crossRevoke = await request(app)
      .post('/api/v1/oauth/revoke')
      .auth(bobLogin.body.access, { type: 'bearer' })
      .send({ refresh: aliceLogin.body.refresh } satisfies LogoutRequest)

    expect(crossRevoke.status).toBe(401)

    // Alice's session is provably untouched - it's still refreshes successfully.
    // Delay so the rotated access JWT does not collide with the original within the same second.
    await new Promise((res) => setTimeout(res, 1000))

    const aliceRefresh = await request(app)
      .post('/api/v1/oauth/refresh')
      .auth(aliceLogin.body.access, { type: 'bearer' })
      .send({ refresh: aliceLogin.body.refresh } satisfies RefreshRequest)

    expect(aliceRefresh.status).toBe(200)

    // Alice can still revoke her (now rotated) session herself.
    const selfRevoke = await request(app)
      .post('/api/v1/oauth/revoke')
      .auth(aliceRefresh.body.access, { type: 'bearer' })
      .send({ refresh: aliceRefresh.body.refresh } satisfies LogoutRequest)

    expect(selfRevoke.status).toBe(205)
  })
})
