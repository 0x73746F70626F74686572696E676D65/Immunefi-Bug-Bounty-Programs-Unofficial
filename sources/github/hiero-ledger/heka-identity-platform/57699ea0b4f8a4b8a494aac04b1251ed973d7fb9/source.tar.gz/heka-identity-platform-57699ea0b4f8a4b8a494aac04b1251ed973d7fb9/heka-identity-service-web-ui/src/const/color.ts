export const defaultSchemaBackgroundColor = '#FFFFFF';
