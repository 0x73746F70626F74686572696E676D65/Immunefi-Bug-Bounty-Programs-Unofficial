// swift-tools-version:5.6
// ⚠️ DEPRECATION: Swift 5.x support is deprecated. Please use Swift 6.0+.

// SPDX-License-Identifier: Apache-2.0

import PackageDescription

let exampleTargets = [
    "AccountAlias",
    "AccountAllowance",
    "AccountHooks",
    "AddNftAllowance",
    "BatchTransaction",
    "ConsensusPubSub",
    "ConsensusPubSubChunked",
    "ConsensusPubSubWithSubmitKey",
    "ContractHooks",
    "CreateAccount",
    "CreateAccountThresholdKey",
    "CreateAccountWithAlias",
    "CreateFile",
    "CreateSimpleContract",
    "CreateStatefulContract",
    "CreateTopic",
    "CreateTopicWithRevenue",
    "EstimateTransactionFee",
    "CreateUpdateDeleteNode",
    "DeleteAccount",
    "DeleteFile",
    "FileAppendChunked",
    "GenerateKey",
    "GenerateKeyWithMnemonic",
    "GetAccountBalance",
    "GetAccountInfo",
    "GetAddressBook",
    "GetExchangeRates",
    "GetFileContents",
    "HighVolumeAccountCreate",
    "InitializeClientWithMirrorNetwork",
    "HookStore",
    "LongTermScheduledTransaction",
    "MirrorNodeContractQuery",
    "ModifyTokenKeys",
    "MultiAppTransfer",
    "MultiSigOffline",
    "Prng",
    "RegisteredNodeLifecycle",
    "Schedule",
    "ScheduledTransactionMultiSigThreshold",
    "ScheduledTransfer",
    "ScheduleIdenticalTransaction",
    "ScheduleMultiSigTransaction",
    "Staking",
    "StakingWithUpdate",
    "TopicWithAdminKey",
    "TransferCrypto",
    "TransferTokens",
    "TransferWithHooks",
    "UpdateAccountPublicKey",
    "ValidateChecksum",
    "TokenUpdateMetadata",
    "NftUpdateMetadata",
    "TokenAirdrop",
].map { name in
    Target.executableTarget(
        name: "\(name)Example",
        dependencies: [
            "Hiero",
            "HieroExampleUtilities",
            .product(name: "SwiftDotenv", package: "swift-dotenv"),
        ],
        path: "Examples/\(name)",
        swiftSettings: [.unsafeFlags(["-parse-as-library"])]
    )
}

let package = Package(
    name: "Hiero",
    platforms: [
        .macOS(.v10_15),
        .iOS(.v13),
    ],
    products: [
        .library(name: "Hiero", targets: ["Hiero"])
    ],
    dependencies: [
        .package(url: "https://github.com/objecthub/swift-numberkit.git", .upToNextMajor(from: "2.5.1")),
        .package(url: "https://github.com/thebarndog/swift-dotenv.git", .upToNextMajor(from: "1.0.0")),
        .package(url: "https://github.com/grpc/grpc-swift.git", .upToNextMajor(from: "1.23.0")),
        .package(url: "https://github.com/apple/swift-protobuf.git", .upToNextMajor(from: "1.29.0")),
        .package(url: "https://github.com/vsanthanam/AnyAsyncSequence.git", .upToNextMajor(from: "1.0.0")),
        .package(url: "https://github.com/apple/swift-atomics.git", .upToNextMajor(from: "1.1.0")),
        // swift-asn1 wants swift 5.7+ past 0.4
        .package(url: "https://github.com/apple/swift-asn1.git", .upToNextMinor(from: "0.3.0")),
        .package(url: "https://github.com/GigaBitcoin/secp256k1.swift.git", .upToNextMinor(from: "0.12.0")),
        .package(url: "https://github.com/apple/swift-docc-plugin", .upToNextMajor(from: "1.0.0")),
        .package(url: "https://github.com/pointfreeco/swift-snapshot-testing.git", .upToNextMajor(from: "1.0.0")),
        .package(url: "https://github.com/vapor/vapor.git", .upToNextMajor(from: "4.101.3")),
        .package(url: "https://github.com/krzyzanowskim/CryptoSwift.git", from: "1.8.0"),
        .package(url: "https://github.com/apple/swift-crypto.git", .upToNextMajor(from: "3.0.0")),
    ],
    targets: [
        .target(
            name: "HieroProtobufs",
            dependencies: [
                .product(name: "SwiftProtobuf", package: "swift-protobuf"),
                .product(name: "GRPC", package: "grpc-swift"),
            ],
            exclude: [
                "Protos",
                "update_protos.py",
                "sync_status_codes.py",
            ]
        ),
        // weird name, but whatever, internal targets
        .target(
            name: "HieroExampleUtilities",
            resources: [.process("Resources")]
        ),
        .target(
            name: "Hiero",
            dependencies: [
                "HieroProtobufs",
                "AnyAsyncSequence",
                .product(name: "SwiftASN1", package: "swift-asn1"),
                .product(name: "SwiftProtobuf", package: "swift-protobuf"),
                .product(name: "NumberKit", package: "swift-numberkit"),
                .product(name: "GRPC", package: "grpc-swift"),
                .product(name: "Atomics", package: "swift-atomics"),
                .product(name: "secp256k1", package: "secp256k1.swift"),
                .product(name: "CryptoSwift", package: "CryptoSwift"),
                .product(name: "Crypto", package: "swift-crypto"),
            ]
            // todo: find some way to enable these locally.
            // swiftSettings: [
            //     .unsafeFlags(["-Xfrontend", "-warn-concurrency", "-Xfrontend", "-enable-actor-data-race-checks"])
            // ]
        ),
        .executableTarget(
            name: "HieroTCK",
            dependencies: [
                "Hiero",
                .product(name: "Vapor", package: "vapor"),
            ]
        ),
        .testTarget(
            name: "HieroTestSupport",
            dependencies: [
                "Hiero",
                "HieroProtobufs",
                .product(name: "SwiftDotenv", package: "swift-dotenv"),
                .product(name: "SnapshotTesting", package: "swift-snapshot-testing"),
            ],
            path: "Tests/HieroTestSupport"
        ),
        .testTarget(
            name: "HieroUnitTests",
            dependencies: [
                "Hiero",
                "HieroTestSupport",
                .product(name: "SnapshotTesting", package: "swift-snapshot-testing"),
            ],
            exclude: ["__Snapshots__"]
        ),
        .testTarget(
            name: "HieroIntegrationTests",
            dependencies: [
                "Hiero",
                "HieroTestSupport",
                .product(name: "SwiftDotenv", package: "swift-dotenv"),
                "HieroExampleUtilities",
            ]
        ),
    ] + exampleTargets
)
