// SPDX-License-Identifier: Apache-2.0

import Foundation

// swiftlint:disable:next type_body_length
public enum Status: Equatable {
    // swiftlint:disable explicit_acl
    typealias RawValue = Int32

    /// The transaction passed the precheck validations.
    case ok  // = 0

    /// For any error not handled by specific error codes listed below.
    case invalidTransaction  // = 1

    /// Payer account does not exist.
    case payerAccountNotFound  // = 2

    /// Node Account provided does not match the node account of the node the transaction was submitted to.
    case invalidNodeAccount  // = 3

    /// Pre-Check error when TransactionValidStart + transactionValidDuration is less than current consensus time.
    case transactionExpired  // = 4

    /// Transaction start time is greater than current consensus time
    case invalidTransactionStart  // = 5

    /// The given transactionValidDuration was either non-positive, or greater than the maximum valid duration of 180 secs.
    case invalidTransactionDuration  // = 6

    /// The transaction signature is not valid
    case invalidSignature  // = 7

    /// Transaction memo size exceeded 100 bytes
    case memoTooLong  // = 8

    /// The fee provided in the transaction is insufficient for this type of transaction
    case insufficientTxFee  // = 9

    /// The payer account has insufficient cryptocurrency to pay the transaction fee
    case insufficientPayerBalance  // = 10

    /// This transaction ID is a duplicate of one that was submitted to this node or reached consensus in the last 180 seconds (receipt period)
    case duplicateTransaction  // = 11

    /// If API is throttled out
    case busy  // = 12

    /// The API is not currently supported
    case notSupported  // = 13

    /// The file id is invalid or does not exist
    case invalidFileID  // = 14

    /// The account id is invalid or does not exist
    case invalidAccountID  // = 15

    /// The contract id is invalid or does not exist
    case invalidContractID  // = 16

    /// Transaction id is not valid
    case invalidTransactionID  // = 17

    /// Receipt for given transaction id does not exist
    case receiptNotFound  // = 18

    /// Record for given transaction id does not exist
    case recordNotFound  // = 19

    /// The solidity id is invalid or entity with this solidity id does not exist
    case invalidSolidityID  // = 20

    /// The responding node has submitted the transaction to the network. Its final status is still unknown.
    case unknown  // = 21

    /// The transaction succeeded
    case success  // = 22

    /// There was a system error and the transaction failed because of invalid request parameters.
    case failInvalid  // = 23

    /// There was a system error while performing fee calculation, reserved for future.
    case failFee  // = 24

    /// There was a system error while performing balance checks, reserved for future.
    case failBalance  // = 25

    /// Key not provided in the transaction body
    case keyRequired  // = 26

    /// Unsupported algorithm/encoding used for keys in the transaction
    case badEncoding  // = 27

    /// When the account balance is not sufficient for the transfer
    case insufficientAccountBalance  // = 28

    /// During an update transaction when the system is not able to find the Users Solidity address
    case invalidSolidityAddress  // = 29

    /// Not enough gas was supplied to execute transaction
    case insufficientGas  // = 30

    /// contract byte code size is over the limit
    case contractSizeLimitExceeded  // = 31

    /// local execution (query) is requested for a function which changes state
    case localCallModificationException  // = 32

    /// Contract REVERT OPCODE executed
    case contractRevertExecuted  // = 33

    /// For any contract execution related error not handled by specific error codes listed above.
    case contractExecutionException  // = 34

    /// In Query validation, account with +ve(amount) value should be Receiving node account, the receiver account should be only one account in the list
    case invalidReceivingNodeAccount  // = 35

    /// Header is missing in Query request
    case missingQueryHeader  // = 36

    /// The update of the account failed
    case accountUpdateFailed  // = 37

    /// Provided key encoding was not supported by the system
    case invalidKeyEncoding  // = 38

    /// null solidity address
    case nullSolidityAddress  // = 39

    /// update of the contract failed
    case contractUpdateFailed  // = 40

    /// the query header is invalid
    case invalidQueryHeader  // = 41

    /// Invalid fee submitted
    case invalidFeeSubmitted  // = 42

    /// Payer signature is invalid
    case invalidPayerSignature  // = 43

    /// The keys were not provided in the request.
    case keyNotProvided  // = 44

    /// Expiration time provided in the transaction was invalid.
    case invalidExpirationTime  // = 45

    /// WriteAccess Control Keys are not provided for the file
    case noWaclKey  // = 46

    /// The contents of file are provided as empty.
    case fileContentEmpty  // = 47

    /// The crypto transfer credit and debit do not sum equal to 0
    case invalidAccountAmounts  // = 48

    /// Transaction body provided is empty
    case emptyTransactionBody  // = 49

    /// Invalid transaction body provided
    case invalidTransactionBody  // = 50

    /// the type of key (base ed25519 key, KeyList, or ThresholdKey) does not match the type of signature (base ed25519 signature, SignatureList, or ThresholdKeySignature)
    case invalidSignatureTypeMismatchingKey  // = 51

    /// the number of key (KeyList, or ThresholdKey) does not match that of signature (SignatureList, or ThresholdKeySignature). e.g. if a keyList has 3 base keys, then the corresponding signatureList should also have 3 base signatures.
    case invalidSignatureCountMismatchingKey  // = 52

    /// the livehash body is empty
    case emptyLiveHashBody  // = 53

    /// the livehash data is missing
    case emptyLiveHash  // = 54

    /// the keys for a livehash are missing
    case emptyLiveHashKeys  // = 55

    /// the livehash data is not the output of a SHA-384 digest
    case invalidLiveHashSize  // = 56

    /// the query body is empty
    case emptyQueryBody  // = 57

    /// the crypto livehash query is empty
    case emptyLiveHashQuery  // = 58

    /// the livehash is not present
    case liveHashNotFound  // = 59

    /// the account id passed has not yet been created.
    case accountIDDoesNotExist  // = 60

    /// the livehash already exists for a given account
    case liveHashAlreadyExists  // = 61

    /// File WACL keys are invalid
    case invalidFileWacl  // = 62

    /// Serialization failure
    case serializationFailed  // = 63

    /// The size of the Transaction is greater than transactionMaxBytes
    case transactionOversize  // = 64

    /// The Transaction has more than 50 levels
    case transactionTooManyLayers  // = 65

    /// Contract is marked as deleted
    case contractDeleted  // = 66

    /// the platform node is either disconnected or lagging behind.
    case platformNotActive  // = 67

    /// one public key matches more than one prefixes on the signature map
    case keyPrefixMismatch  // = 68

    /// transaction not created by platform due to large backlog
    case platformTransactionNotCreated  // = 69

    /// auto renewal period is not a positive number of seconds
    case invalidRenewalPeriod  // = 70

    /// the response code when a smart contract id is passed for a crypto API request
    case invalidPayerAccountID  // = 71

    /// the account has been marked as deleted
    case accountDeleted  // = 72

    /// the file has been marked as deleted
    case fileDeleted  // = 73

    /// same accounts repeated in the transfer account list
    case accountRepeatedInAccountAmounts  // = 74

    /// attempting to set negative balance value for crypto account
    case settingNegativeAccountBalance  // = 75

    /// when deleting smart contract that has crypto balance either transfer account or transfer smart contract is required
    case obtainerRequired  // = 76

    /// when deleting smart contract that has crypto balance you can not use the same contract id as transferContractId as the one being deleted
    case obtainerSameContractID  // = 77

    /// transferAccountId or transferContractId specified for contract delete does not exist
    case obtainerDoesNotExist  // = 78

    /// attempting to modify (update or delete a immutable smart contract, i.e. one created without a admin key)
    case modifyingImmutableContract  // = 79

    /// Unexpected exception thrown by file system functions
    case fileSystemException  // = 80

    /// the duration is not a subset of [MINIMUM_AUTORENEW_DURATION,MAXIMUM_AUTORENEW_DURATION]
    case autorenewDurationNotInRange  // = 81

    /// Decoding the smart contract binary to a byte array failed. Check that the input is a valid hex string.
    case errorDecodingBytestring  // = 82

    /// File to create a smart contract was of length zero
    case contractFileEmpty  // = 83

    /// Bytecode for smart contract is of length zero
    case contractBytecodeEmpty  // = 84

    /// Attempt to set negative initial balance
    case invalidInitialBalance  // = 85

    /// [Deprecated] Attempt to set negative receive record threshold
    case invalidReceiveRecordThreshold  // = 86

    /// [Deprecated] Attempt to set negative send record threshold
    case invalidSendRecordThreshold  // = 87

    /// Special Account Operations should be performed by only Genesis account, return this code if it is not Genesis Account
    case accountIsNotGenesisAccount  // = 88

    /// The fee payer account doesn't have permission to submit such Transaction
    case payerAccountUnauthorized  // = 89

    /// FreezeTransactionBody is invalid
    case invalidFreezeTransactionBody  // = 90

    /// FreezeTransactionBody does not exist
    case freezeTransactionBodyNotFound  // = 91

    /// Exceeded the number of accounts (both from and to) allowed for crypto transfer list
    case transferListSizeLimitExceeded  // = 92

    /// Smart contract result size greater than specified maxResultSize
    case resultSizeLimitExceeded  // = 93

    /// The payer account is not a special account(account 0.0.55)
    case notSpecialAccount  // = 94

    /// Negative gas was offered in smart contract call
    case contractNegativeGas  // = 95

    /// Negative value / initial balance was specified in a smart contract call / create
    case contractNegativeValue  // = 96

    /// Failed to update fee file
    case invalidFeeFile  // = 97

    /// Failed to update exchange rate file
    case invalidExchangeRateFile  // = 98

    /// Payment tendered for contract local call cannot cover both the fee and the gas
    case insufficientLocalCallGas  // = 99

    /// Entities with Entity ID below 1000 are not allowed to be deleted
    case entityNotAllowedToDelete  // = 100

    /// Violating one of these rules: 1) treasury account can update all entities below 0.0.1000, 2) account 0.0.50 can update all entities from 0.0.51 - 0.0.80, 3) Network Function Master Account A/c 0.0.50 - Update all Network Function accounts & perform all the Network Functions listed below, 4) Network Function Accounts: i) A/c 0.0.55 - Update Address Book files (0.0.101/102), ii) A/c 0.0.56 - Update Fee schedule (0.0.111), iii) A/c 0.0.57 - Update Exchange Rate (0.0.112).
    case authorizationFailed  // = 101

    /// Fee Schedule Proto uploaded but not valid (append or update is required)
    case fileUploadedProtoInvalid  // = 102

    /// Fee Schedule Proto uploaded but not valid (append or update is required)
    case fileUploadedProtoNotSavedToDisk  // = 103

    /// Fee Schedule Proto File Part uploaded
    case feeScheduleFilePartUploaded  // = 104

    /// The change on Exchange Rate exceeds Exchange_Rate_Allowed_Percentage
    case exchangeRateChangeLimitExceeded  // = 105

    /// Contract permanent storage exceeded the currently allowable limit
    case maxContractStorageExceeded  // = 106

    /// Transfer Account should not be same as Account to be deleted
    case transferAccountSameAsDeleteAccount  // = 107

    case totalLedgerBalanceInvalid  // = 108

    /// The expiration date/time on a smart contract may not be reduced
    case expirationReductionNotAllowed  // = 110

    /// Gas exceeded currently allowable gas limit per transaction
    case maxGasLimitExceeded  // = 111

    /// File size exceeded the currently allowable limit
    case maxFileSizeExceeded  // = 112

    /// When a valid signature is not provided for operations on account with receiverSigRequired=true
    case receiverSigRequired  // = 113

    /// The Topic ID specified is not in the system.
    case invalidTopicID  // = 150

    /// A provided admin key was invalid. Verify the bytes for an Ed25519 public key are exactly 32 bytes; and the bytes for a compressed ECDSA(secp256k1) key are exactly 33 bytes, with the first byte either 0x02 or 0x03..
    case invalidAdminKey  // = 155

    /// A provided submit key was invalid.
    case invalidSubmitKey  // = 156

    /// An attempted operation was not authorized (ie - a deleteTopic for a topic with no adminKey).
    case unauthorized  // = 157

    /// A ConsensusService message is empty.
    case invalidTopicMessage  // = 158

    /// The autoRenewAccount specified is not a valid, active account.
    case invalidAutorenewAccount  // = 159

    /// An adminKey was not specified on the topic, so there must not be an autoRenewAccount.
    case autorenewAccountNotAllowed  // = 160

    /// The topic has expired, was not automatically renewed, and is in a 7 day grace period before the topic will be deleted unrecoverably. This error response code will not be returned until autoRenew functionality is supported by HAPI.
    case topicExpired  // = 162

    /// chunk number must be from 1 to total (chunks) inclusive.
    case invalidChunkNumber  // = 163

    /// For every chunk, the payer account that is part of initialTransactionID must match the Payer Account of this transaction. The entire initialTransactionID should match the transactionID of the first chunk, but this is not checked or enforced by Hedera except when the chunk number is 1.
    case invalidChunkTransactionID  // = 164

    /// Account is frozen and cannot transact with the token
    case accountFrozenForToken  // = 165

    /// An involved account already has more than <tt>tokens.maxPerAccount</tt> associations with non-deleted tokens.
    case tokensPerAccountLimitExceeded  // = 166

    /// The token is invalid or does not exist
    case invalidTokenID  // = 167

    /// Invalid token decimals
    case invalidTokenDecimals  // = 168

    /// Invalid token initial supply
    case invalidTokenInitialSupply  // = 169

    /// Treasury Account does not exist or is deleted
    case invalidTreasuryAccountForToken  // = 170

    /// Token Symbol is not UTF-8 capitalized alphabetical string
    case invalidTokenSymbol  // = 171

    /// Freeze key is not set on token
    case tokenHasNoFreezeKey  // = 172

    /// Amounts in transfer list are not net zero
    case transfersNotZeroSumForToken  // = 173

    /// A token symbol was not provided
    case missingTokenSymbol  // = 174

    /// The provided token symbol was too long
    case tokenSymbolTooLong  // = 175

    /// KYC must be granted and account does not have KYC granted
    case accountKycNotGrantedForToken  // = 176

    /// KYC key is not set on token
    case tokenHasNoKycKey  // = 177

    /// Token balance is not sufficient for the transaction
    case insufficientTokenBalance  // = 178

    /// Token transactions cannot be executed on deleted token
    case tokenWasDeleted  // = 179

    /// Supply key is not set on token
    case tokenHasNoSupplyKey  // = 180

    /// Wipe key is not set on token
    case tokenHasNoWipeKey  // = 181

    /// The requested token mint amount would cause an invalid total supply
    case invalidTokenMintAmount  // = 182

    /// The requested token burn amount would cause an invalid total supply
    case invalidTokenBurnAmount  // = 183

    /// A required token-account relationship is missing
    case tokenNotAssociatedToAccount  // = 184

    /// The target of a wipe operation was the token treasury account
    case cannotWipeTokenTreasuryAccount  // = 185

    /// The provided KYC key was invalid.
    case invalidKycKey  // = 186

    /// The provided wipe key was invalid.
    case invalidWipeKey  // = 187

    /// The provided freeze key was invalid.
    case invalidFreezeKey  // = 188

    /// The provided supply key was invalid.
    case invalidSupplyKey  // = 189

    /// Token Name is not provided
    case missingTokenName  // = 190

    /// Token Name is too long
    case tokenNameTooLong  // = 191

    /// The provided wipe amount must not be negative, zero or bigger than the token holder balance
    case invalidWipingAmount  // = 192

    /// Token does not have Admin key set, thus update/delete transactions cannot be performed
    case tokenIsImmutable  // = 193

    /// An <tt>associateToken</tt> operation specified a token already associated to the account
    case tokenAlreadyAssociatedToAccount  // = 194

    /// An attempted operation is invalid until all token balances for the target account are zero
    case transactionRequiresZeroTokenBalances  // = 195

    /// An attempted operation is invalid because the account is a treasury
    case accountIsTreasury  // = 196

    /// Same TokenIDs present in the token list
    case tokenIDRepeatedInTokenList  // = 197

    /// Exceeded the number of token transfers (both from and to) allowed for token transfer list
    case tokenTransferListSizeLimitExceeded  // = 198

    /// TokenTransfersTransactionBody has no TokenTransferList
    case emptyTokenTransferBody  // = 199

    /// TokenTransfersTransactionBody has a TokenTransferList with no AccountAmounts
    case emptyTokenTransferAccountAmounts  // = 200

    /// The Scheduled entity does not exist; or has now expired, been deleted, or been executed
    case invalidScheduleID  // = 201

    /// The Scheduled entity cannot be modified. Admin key not set
    case scheduleIsImmutable  // = 202

    /// The provided Scheduled Payer does not exist
    case invalidSchedulePayerID  // = 203

    /// The Schedule Create Transaction TransactionID account does not exist
    case invalidScheduleAccountID  // = 204

    /// The provided sig map did not contain any new valid signatures from required signers of the scheduled transaction
    case noNewValidSignatures  // = 205

    /// The required signers for a scheduled transaction cannot be resolved, for example because they do not exist or have been deleted
    case unresolvableRequiredSigners  // = 206

    /// Only whitelisted transaction types may be scheduled
    case scheduledTransactionNotInWhitelist  // = 207

    /// At least one of the signatures in the provided sig map did not represent a valid signature for any required signer
    case someSignaturesWereInvalid  // = 208

    /// The scheduled field in the TransactionID may not be set to true
    case transactionIDFieldNotAllowed  // = 209

    /// A schedule already exists with the same identifying fields of an attempted ScheduleCreate (that is, all fields other than scheduledPayerAccountID)
    case identicalScheduleAlreadyCreated  // = 210

    /// A string field in the transaction has a UTF-8 encoding with the prohibited zero byte
    case invalidZeroByteInString  // = 211

    /// A schedule being signed or deleted has already been deleted
    case scheduleAlreadyDeleted  // = 212

    /// A schedule being signed or deleted has already been executed
    case scheduleAlreadyExecuted  // = 213

    /// ConsensusSubmitMessage request's message size is larger than allowed.
    case messageSizeTooLarge  // = 214

    /// An operation was assigned to more than one throttle group in a given bucket
    case operationRepeatedInBucketGroups  // = 215

    /// The capacity needed to satisfy all opsPerSec groups in a bucket overflowed a signed 8-byte integral type
    case bucketCapacityOverflow  // = 216

    /// Given the network size in the address book, the node-level capacity for an operation would never be enough to accept a single request; usually means a bucket burstPeriod should be increased
    case nodeCapacityNotSufficientForOperation  // = 217

    /// A bucket was defined without any throttle groups
    case bucketHasNoThrottleGroups  // = 218

    /// A throttle group was granted zero opsPerSec
    case throttleGroupHasZeroOpsPerSec  // = 219

    /// The throttle definitions file was updated, but some supported operations were not assigned a bucket
    case successButMissingExpectedOperation  // = 220

    /// The new contents for the throttle definitions system file were not valid protobuf
    case unparseableThrottleDefinitions  // = 221

    /// The new throttle definitions system file were invalid, and no more specific error could be divined
    case invalidThrottleDefinitions  // = 222

    /// The transaction references an account which has passed its expiration without renewal funds available, and currently remains in the ledger only because of the grace period given to expired entities
    case accountExpiredAndPendingRemoval  // = 223

    /// Invalid token max supply
    case invalidTokenMaxSupply  // = 224

    /// Invalid token nft serial number
    case invalidTokenNftSerialNumber  // = 225

    /// Invalid nft id
    case invalidNftID  // = 226

    /// Nft metadata is too long
    case metadataTooLong  // = 227

    /// Repeated operations count exceeds the limit
    case batchSizeLimitExceeded  // = 228

    /// The range of data to be gathered is out of the set boundaries
    case invalidQueryRange  // = 229

    /// A custom fractional fee set a denominator of zero
    case fractionDividesByZero  // = 230

    /// [Deprecated] The transaction payer could not afford a custom fee
    case insufficientPayerBalanceForCustomFee  // = 231

    /// More than 10 custom fees were specified
    case customFeesListTooLong  // = 232

    /// Any of the feeCollector accounts for customFees is invalid
    case invalidCustomFeeCollector  // = 233

    /// Any of the token Ids in customFees is invalid
    case invalidTokenIDInCustomFees  // = 234

    /// Any of the token Ids in customFees are not associated to feeCollector
    case tokenNotAssociatedToFeeCollector  // = 235

    /// A token cannot have more units minted due to its configured supply ceiling
    case tokenMaxSupplyReached  // = 236

    /// The transaction attempted to move an NFT serial number from an account other than its owner
    case senderDoesNotOwnNftSerialNo  // = 237

    /// A custom fee schedule entry did not specify either a fixed or fractional fee
    case customFeeNotFullySpecified  // = 238

    /// Only positive fees may be assessed at this time
    case customFeeMustBePositive  // = 239

    /// Fee schedule key is not set on token
    case tokenHasNoFeeScheduleKey  // = 240

    /// A fractional custom fee exceeded the range of a 64-bit signed integer
    case customFeeOutsideNumericRange  // = 241

    /// A royalty cannot exceed the total fungible value exchanged for an NFT
    case royaltyFractionCannotExceedOne  // = 242

    /// Each fractional custom fee must have its maximum_amount, if specified, at least its minimum_amount
    case fractionalFeeMaxAmountLessThanMinAmount  // = 243

    /// A fee schedule update tried to clear the custom fees from a token whose fee schedule was already empty
    case customScheduleAlreadyHasNoFees  // = 244

    /// Only tokens of type FUNGIBLE_COMMON can be used to as fee schedule denominations
    case customFeeDenominationMustBeFungibleCommon  // = 245

    /// Only tokens of type FUNGIBLE_COMMON can have fractional fees
    case customFractionalFeeOnlyAllowedForFungibleCommon  // = 246

    /// The provided custom fee schedule key was invalid
    case invalidCustomFeeScheduleKey  // = 247

    /// The requested token mint metadata was invalid
    case invalidTokenMintMetadata  // = 248

    /// The requested token burn metadata was invalid
    case invalidTokenBurnMetadata  // = 249

    /// The treasury for a unique token cannot be changed until it owns no NFTs
    case currentTreasuryStillOwnsNfts  // = 250

    /// An account cannot be dissociated from a unique token if it owns NFTs for the token
    case accountStillOwnsNfts  // = 251

    /// A NFT can only be burned when owned by the unique token's treasury
    case treasuryMustOwnBurnedNft  // = 252

    /// An account did not own the NFT to be wiped
    case accountDoesNotOwnWipedNft  // = 253

    /// An AccountAmount token transfers list referenced a token type other than FUNGIBLE_COMMON
    case accountAmountTransfersOnlyAllowedForFungibleCommon  // = 254

    /// All the NFTs allowed in the current price regime have already been minted
    case maxNftsInPriceRegimeHaveBeenMinted  // = 255

    /// The payer account has been marked as deleted
    case payerAccountDeleted  // = 256

    /// The reference chain of custom fees for a transferred token exceeded the maximum length of 2
    case customFeeChargingExceededMaxRecursionDepth  // = 257

    /// More than 20 balance adjustments were to satisfy a CryptoTransfer and its implied custom fee payments
    case customFeeChargingExceededMaxAccountAmounts  // = 258

    /// The sender account in the token transfer transaction could not afford a custom fee
    case insufficientSenderAccountBalanceForCustomFee  // = 259

    /// Currently no more than 4,294,967,295 NFTs may be minted for a given unique token type
    case serialNumberLimitReached  // = 260

    /// Only tokens of type NON_FUNGIBLE_UNIQUE can have royalty fees
    case customRoyaltyFeeOnlyAllowedForNonFungibleUnique  // = 261

    /// The account has reached the limit on the automatic associations count.
    case noRemainingAutomaticAssociations  // = 262

    /// Already existing automatic associations are more than the new maximum automatic associations.
    case existingAutomaticAssociationsExceedGivenLimit  // = 263

    /// Cannot set the number of automatic associations for an account more than the maximum allowed token associations <tt>tokens.maxPerAccount</tt>.
    case requestedNumAutomaticAssociationsExceedsAssociationLimit  // = 264

    /// Token is paused. This Token cannot be a part of any kind of Transaction until unpaused.
    case tokenIsPaused  // = 265

    /// Pause key is not set on token
    case tokenHasNoPauseKey  // = 266

    /// The provided pause key was invalid
    case invalidPauseKey  // = 267

    /// The update file in a freeze transaction body must exist.
    case freezeUpdateFileDoesNotExist  // = 268

    /// The hash of the update file in a freeze transaction body must match the in-memory hash.
    case freezeUpdateFileHashDoesNotMatch  // = 269

    /// A FREEZE_UPGRADE transaction was handled with no previous update prepared.
    case noUpgradeHasBeenPrepared  // = 270

    /// A FREEZE_ABORT transaction was handled with no scheduled freeze.
    case noFreezeIsScheduled  // = 271

    /// The update file hash when handling a FREEZE_UPGRADE transaction differs from the file hash at the time of handling the PREPARE_UPGRADE transaction.
    case updateFileHashChangedSincePrepareUpgrade  // = 272

    /// The given freeze start time was in the (consensus) past.
    case freezeStartTimeMustBeFuture  // = 273

    /// The prepared update file cannot be updated or appended until either the upgrade has been completed, or a FREEZE_ABORT has been handled.
    case preparedUpdateFileIsImmutable  // = 274

    /// Once a freeze is scheduled, it must be aborted before any other type of freeze can can be performed.
    case freezeAlreadyScheduled  // = 275

    /// If an NMT upgrade has been prepared, the following operation must be a FREEZE_UPGRADE. (To issue a FREEZE_ONLY, submit a FREEZE_ABORT first.)
    case freezeUpgradeInProgress  // = 276

    /// If an NMT upgrade has been prepared, the subsequent FREEZE_UPGRADE transaction must confirm the id of the file to be used in the upgrade.
    case updateFileIDDoesNotMatchPrepared  // = 277

    /// If an NMT upgrade has been prepared, the subsequent FREEZE_UPGRADE transaction must confirm the hash of the file to be used in the upgrade.
    case updateFileHashDoesNotMatchPrepared  // = 278

    /// Consensus throttle did not allow execution of this transaction. System is throttled at consensus level.
    case consensusGasExhausted  // = 279

    /// A precompiled contract succeeded, but was later reverted.
    case revertedSuccess  // = 280

    /// All contract storage allocated to the current price regime has been consumed.
    case maxStorageInPriceRegimeHasBeenUsed  // = 281

    /// An alias used in a CryptoTransfer transaction is not the serialization of a primitive Key message--that is, a Key with a single Ed25519 or ECDSA(secp256k1) public key and no unknown protobuf fields.
    case invalidAliasKey  // = 282

    /// A fungible token transfer expected a different number of decimals than the involved type actually has.
    case unexpectedTokenDecimals  // = 283

    /// [Deprecated] The proxy account id is invalid or does not exist.
    case invalidProxyAccountID  // = 284

    /// The transfer account id in CryptoDelete transaction is invalid or does not exist.
    case invalidTransferAccountID  // = 285

    /// The fee collector account id in TokenFeeScheduleUpdate is invalid or does not exist.
    case invalidFeeCollectorAccountID  // = 286

    /// The alias already set on an account cannot be updated using CryptoUpdate transaction.
    case aliasIsImmutable  // = 287

    /// An approved allowance specifies a spender account that is the same as the hbar/token owner account.
    case spenderAccountSameAsOwner  // = 288

    /// The establishment or adjustment of an approved allowance cause the token allowance to exceed the token maximum supply.
    case amountExceedsTokenMaxSupply  // = 289

    /// The specified amount for an approved allowance cannot be negative.
    case negativeAllowanceAmount  // = 290

    /// [Deprecated] The approveForAll flag cannot be set for a fungible token.
    case cannotApproveForAllFungibleCommon  // = 291

    /// The spender does not have an existing approved allowance with the hbar/token owner.
    case spenderDoesNotHaveAllowance  // = 292

    /// The transfer amount exceeds the current approved allowance for the spender account.
    case amountExceedsAllowance  // = 293

    /// The payer account of an approveAllowances or adjustAllowance transaction is attempting to go beyond the maximum allowed number of allowances.
    case maxAllowancesExceeded  // = 294

    /// No allowances have been specified in the approval transaction.
    case emptyAllowances  // = 295

    /// [Deprecated] Spender is repeated more than once in Crypto or Token or NFT allowance lists in a single CryptoApproveAllowance transaction.
    case spenderAccountRepeatedInAllowances  // = 296

    /// [Deprecated] Serial numbers are repeated in nft allowance for a single spender account
    case repeatedSerialNumsInNftAllowances  // = 297

    /// Fungible common token used in NFT allowances
    case fungibleTokenInNftAllowances  // = 298

    /// Non fungible token used in fungible token allowances
    case nftInFungibleTokenAllowances  // = 299

    /// The account id specified as the owner is invalid or does not exist.
    case invalidAllowanceOwnerID  // = 300

    /// The account id specified as the spender is invalid or does not exist.
    case invalidAllowanceSpenderID  // = 301

    /// [Deprecated] [Deprecated] If the CryptoDeleteAllowance transaction has repeated crypto or token or Nft allowances to delete.
    case repeatedAllowancesToDelete  // = 302

    /// If the account Id specified as the delegating spender is invalid or does not exist.
    case invalidDelegatingSpender  // = 303

    /// The delegating Spender cannot grant approveForAll allowance on a NFT token type for another spender.
    case delegatingSpenderCannotGrantApproveForAll  // = 304

    /// The delegating Spender cannot grant allowance on a NFT serial for another spender as it doesnt not have approveForAll granted on token-owner.
    case delegatingSpenderDoesNotHaveApproveForAll  // = 305

    /// The scheduled transaction could not be created because it's expiration_time was too far in the future.
    case scheduleExpirationTimeTooFarInFuture  // = 306

    /// The scheduled transaction could not be created because it's expiration_time was less than or equal to the consensus time.
    case scheduleExpirationTimeMustBeHigherThanConsensusTime  // = 307

    /// The scheduled transaction could not be created because it would cause throttles to be violated on the specified expiration_time.
    case scheduleFutureThrottleExceeded  // = 308

    /// The scheduled transaction could not be created because it would cause the gas limit to be violated on the specified expiration_time.
    case scheduleFutureGasLimitExceeded  // = 309

    /// The ethereum transaction either failed parsing or failed signature validation, or some other EthereumTransaction error not covered by another response code.
    case invalidEthereumTransaction  // = 310

    /// EthereumTransaction was signed against a chainId that this network does not support.
    case wrongChainID  // = 311

    /// This transaction specified an ethereumNonce that is not the current ethereumNonce of the account.
    case wrongNonce  // = 312

    /// The ethereum transaction specified an access list, which the network does not support.
    case accessListUnsupported  // = 313

    /// A schedule being signed or deleted has passed it's expiration date and is pending execution if needed and then expiration.
    case schedulePendingExpiration  // = 314

    /// A selfdestruct or ContractDelete targeted a contract that is a token treasury.
    case contractIsTokenTreasury  // = 315

    /// A selfdestruct or ContractDelete targeted a contract with non-zero token balances.
    case contractHasNonZeroTokenBalances  // = 316

    /// A contract referenced by a transaction is "detached"; that is, expired and lacking any hbar funds for auto-renewal payment---but still within its post-expiry grace period.
    case contractExpiredAndPendingRemoval  // = 317

    /// A ContractUpdate requested removal of a contract's auto-renew account, but that contract has no auto-renew account.
    case contractHasNoAutoRenewAccount  // = 318

    /// A delete transaction submitted via HAPI set permanent_removal=true
    case permanentRemovalRequiresSystemInitiation  // = 319

    /// [Deprecated] A CryptoCreate or ContractCreate used the deprecated proxyAccountID field.
    case proxyAccountIDFieldIsDeprecated  // = 320

    /// An account set the staked_account_id to itself in CryptoUpdate or ContractUpdate transactions.
    case selfStakingIsNotAllowed  // = 321

    /// The staking account id or staking node id given is invalid or does not exist.
    case invalidStakingID  // = 322

    /// Native staking, while implemented, has not yet enabled by the council.
    case stakingNotEnabled  // = 323

    /// The range provided in UtilPrng transaction is negative.
    case invalidPrngRange  // = 324

    /// The maximum number of entities allowed in the current price regime have been created.
    case maxEntitiesInPriceRegimeHaveBeenCreated  // = 325

    /// The full prefix signature for precompile is not valid
    case invalidFullPrefixSignatureForPrecompile  // = 326

    /// The combined balances of a contract and its auto-renew account (if any) did not cover the rent charged for net new storage used in a transaction.
    case insufficientBalancesForStorageRent  // = 327

    /// A contract transaction tried to use more than the allowed number of child records, via either system contract records or internal contract creations.
    case maxChildRecordsExceeded  // = 328

    /// The combined balances of a contract and its auto-renew account (if any) or balance of an account did not cover the auto-renewal fees in a transaction.
    case insufficientBalancesForRenewalFees  // = 329

    /// A transaction's protobuf message includes unknown fields; could mean that a client expects not-yet-released functionality to be available.
    case transactionHasUnknownFields  // = 330

    /// The account cannot be modified. Account's key is not set
    case accountIsImmutable  // = 331

    /// An alias that is assigned to an account or contract cannot be assigned to another account or contract.
    case aliasAlreadyAssigned  // = 332

    /// A provided metadata key was invalid. Verification includes, for example, checking the size of Ed25519 and ECDSA(secp256k1) public keys.
    case invalidMetadataKey  // = 333

    /// Metadata key is not set on token
    case tokenHasNoMetadataKey  // = 334

    /// Token Metadata is not provided
    case missingTokenMetadata  // = 335

    /// NFT serial numbers are missing in the TokenUpdateNftsTransactionBody
    case missingSerialNumbers  // = 336

    /// Admin key is not set on token
    case tokenHasNoAdminKey  // = 337

    /// A transaction failed because the consensus node identified is deleted from the address book.
    case nodeDeleted  // = 338

    /// A transaction failed because the consensus node identified is not valid or does not exist in state.
    case invalidNodeID  // = 339

    /// A transaction failed because one or more entries in the list of service endpoints for the `gossip_endpoint` field is invalid.<br/> The most common cause for this response is a service endpoint that has the domain name (DNS) set rather than address and port.
    case invalidGossipEndpoint  // = 340

    /// A transaction failed because the node account identifier provided does not exist or is not valid.<br/> One common source of this error is providing a node account identifier using the "alias" form rather than "numeric" form. It is also used for atomic batch transaction for child transaction if the node account id is not 0.0.0.
    case invalidNodeAccountID  // = 341

    /// A transaction failed because the description field cannot be encoded as UTF-8 or is more than 100 bytes when encoded.
    case invalidNodeDescription  // = 342

    /// A transaction failed because one or more entries in the list of service endpoints for the `service_endpoint` field is invalid.<br/> The most common cause for this response is a service endpoint that has the domain name (DNS) set rather than address and port.
    case invalidServiceEndpoint  // = 343

    /// A transaction failed because the TLS certificate provided for the node is missing or invalid. <p> #### Probable Causes The certificate MUST be a TLS certificate of a type permitted for gossip signatures.<br/> The value presented MUST be a UTF-8 NFKD encoding of the TLS certificate.<br/> The certificate encoded MUST be in PEM format.<br/> The `gossip_ca_certificate` field is REQUIRED and MUST NOT be empty.
    case invalidGossipCaCertificate  // = 344

    /// A transaction failed because the hash provided for the gRPC certificate is present but invalid. <p> #### Probable Causes The `grpc_certificate_hash` MUST be a SHA-384 hash.<br/> The input hashed MUST be a UTF-8 NFKD encoding of the actual TLS certificate.<br/> The certificate to be encoded MUST be in PEM format.
    case invalidGrpcCertificate  // = 345

    /// The maximum automatic associations value is not valid.<br/> The most common cause for this error is a value less than `-1`.
    case invalidMaxAutoAssociations  // = 346

    /// The maximum number of nodes allowed in the address book have been created.
    case maxNodesCreated  // = 347

    /// In ServiceEndpoint, domain_name and ipAddressV4 are mutually exclusive
    case ipFqdnCannotBeSetForSameEndpoint  // = 348

    /// Fully qualified domain name is not allowed in gossip_endpoint
    case gossipEndpointCannotHaveFqdn  // = 349

    /// In ServiceEndpoint, domain_name size too large
    case fqdnSizeTooLarge  // = 350

    /// ServiceEndpoint is invalid
    case invalidEndpoint  // = 351

    /// The number of gossip endpoints exceeds the limit
    case gossipEndpointsExceededLimit  // = 352

    /// The transaction attempted to use duplicate `TokenReference`.<br/> This affects `TokenReject` attempting to reject same token reference more than once.
    case tokenReferenceRepeated  // = 353

    /// The account id specified as the owner in `TokenReject` is invalid or does not exist.
    case invalidOwnerID  // = 354

    /// The transaction attempted to use more than the allowed number of `TokenReference`.
    case tokenReferenceListSizeLimitExceeded  // = 355

    /// The number of service endpoints exceeds the limit
    case serviceEndpointsExceededLimit  // = 356

    /// The IPv4 address is invalid
    case invalidIpv4Address  // = 357

    /// The transaction attempted to use empty `TokenReference` list.
    case emptyTokenReferenceList  // = 358

    /// The node account is not allowed to be updated
    case updateNodeAccountNotAllowed  // = 359

    /// The token has no metadata or supply key
    case tokenHasNoMetadataOrSupplyKey  // = 360

    /// The list of `PendingAirdropId`s is empty and MUST NOT be empty.
    case emptyPendingAirdropIdList  // = 361

    /// A `PendingAirdropId` is repeated in a `claim` or `cancel` transaction.
    case pendingAirdropIdRepeated  // = 362

    /// The number of `PendingAirdropId` values in the list exceeds the maximum allowable number.
    case pendingAirdropIdListTooLong  // = 363

    /// A pending airdrop already exists for the specified NFT.
    case pendingNftAirdropAlreadyExists  // = 364

    /// The identified account is sender for one or more pending airdrop(s) and cannot be deleted. <p> The requester SHOULD cancel all pending airdrops before resending this transaction.
    case accountHasPendingAirdrops  // = 365

    /// Consensus throttle did not allow execution of this transaction.<br/> The transaction should be retried after a modest delay.
    case throttledAtConsensus  // = 366

    /// The provided pending airdrop id is invalid.<br/> This pending airdrop MAY already be claimed or cancelled. <p> The client SHOULD query a mirror node to determine the current status of the pending airdrop.
    case invalidPendingAirdropId  // = 367

    /// The token to be airdropped has a fallback royalty fee and cannot be sent or claimed via an airdrop transaction.
    case tokenAirdropWithFallbackRoyalty  // = 368

    /// This airdrop claim is for a pending airdrop with an invalid token.<br/> The token might be deleted, or the sender may not have enough tokens to fulfill the offer. <p> The client SHOULD query mirror node to determine the status of the pending airdrop and whether the sender can fulfill the offer.
    case invalidTokenInPendingAirdrop  // = 369

    /// A scheduled transaction configured to wait for expiry to execute was given an expiry time at which there is already too many transactions scheduled to expire; its creation must be retried with a different expiry.
    case scheduleExpiryIsBusy  // = 370

    /// The provided gRPC certificate hash is invalid.
    case invalidGrpcCertificateHash  // = 371

    /// A scheduled transaction configured to wait for expiry to execute was not given an explicit expiration time.
    case missingExpiryTime  // = 372

    /// A contract operation attempted to schedule another transaction after it had already scheduled a recursive contract call.
    case noSchedulingAllowedAfterScheduledRecursion  // = 373

    /// A contract can schedule recursive calls a finite number of times (this is approximately four million times with typical network configuration.)
    case recursiveSchedulingLimitReached  // = 374

    /// The target network is waiting for the ledger ID to be set, which is a side effect of finishing the network's TSS construction.
    case waitingForLedgerID  // = 375

    /// The provided fee exempt key list size exceeded the limit.
    case maxEntriesForFeeExemptKeyListExceeded  // = 376

    /// The provided fee exempt key list contains duplicated keys.
    case feeExemptKeyListContainsDuplicatedKeys  // = 377

    /// The provided fee exempt key list contains an invalid key.
    case invalidKeyInFeeExemptKeyList  // = 378

    /// The provided fee schedule key contains an invalid key.
    case invalidFeeScheduleKey  // = 379

    /// If a fee schedule key is not set when we create a topic we cannot add it on update.
    case feeScheduleKeyCannotBeUpdated  // = 380

    /// If the topic's custom fees are updated the topic SHOULD have a fee schedule key
    case feeScheduleKeyNotSet  // = 381

    /// The fee amount is exceeding the amount that the payer is willing to pay.
    case maxCustomFeeLimitExceeded  // = 382

    /// There are no corresponding custom fees.
    case noValidMaxCustomFee  // = 383

    /// The provided list contains invalid max custom fee.
    case invalidMaxCustomFees  // = 384

    /// The provided max custom fee list contains fees with duplicate denominations.
    case duplicateDenominationInMaxCustomFeeList  // = 385

    /// The provided max custom fee list contains fees with duplicate account id.
    case duplicateAccountIDInMaxCustomFeeList  // = 386

    /// Max custom fees list is not supported for this operation.
    case maxCustomFeesIsNotSupported  // = 387

    /// The list of batch transactions is empty
    case batchListEmpty  // = 388

    /// The list of batch transactions contains duplicated transactions
    case batchListContainsDuplicates  // = 389

    /// The list of batch transactions contains a transaction type that is in the AtomicBatch blacklist as configured in the network.
    case batchTransactionInBlacklist  // = 390

    /// The inner transaction of a batch transaction failed
    case innerTransactionFailed  // = 391

    /// The inner transaction of a batch transaction is missing a batch key
    case missingBatchKey  // = 392

    /// The batch key is set for a non batch transaction
    case batchKeySetOnNonInnerTransaction  // = 393

    /// The batch key is not valid
    case invalidBatchKey  // = 394

    /// The provided schedule expiry time is not configurable.
    case scheduleExpiryNotConfigurable  // = 395

    /// The network just started at genesis and is creating system entities.
    case creatingSystemEntities  // = 396

    /// The least common multiple of the throttle group's milliOpsPerSec is too large and it's overflowing.
    case throttleGroupLcmOverflow  // = 397

    /// Token airdrop transactions can not contain multiple senders for a single token.
    case airdropContainsMultipleSendersForAToken  // = 398

    /// The GRPC proxy endpoint is set in the NodeCreate or NodeUpdate transaction, which the network does not support.
    case grpcWebProxyNotSupported  // = 399

    /// An NFT transfers list referenced a token type other than NON_FUNGIBLE_UNIQUE.
    case nftTransfersOnlyAllowedForNonFungibleUnique  // = 400

    /// A HAPI client cannot set the SignedTransaction#use_serialized_tx_message_hash_algorithm field.
    case invalidSerializedTxMessageHashAlgorithm  // = 401

    /// A HookStore referenced a valid entity number but with the wrong entity type.
    case wrongHookEntityType  // = 499

    /// An EVM hook execution was throttled due to high network gas utilization.
    case evmHookGasThrottled  // = 500

    /// A user tried to create a hook with an id already in use.
    case hookIDInUse  // = 501

    /// A transaction tried to execute a hook that did not match the specified type or was malformed in some other way.
    case badHookRequest  // = 502

    /// A CryptoTransfer relying on a ACCOUNT_ALLOWANCE hook was rejected.
    case rejectedByAccountAllowanceHook  // = 503

    /// A hook id was not found.
    case hookNotFound  // = 504

    /// An EVM hook mapping slot, storage key, or storage value exceeded 32 bytes.
    case evmHookStorageUpdateBytesTooLong  // = 505

    /// An EVM hook's mapping slot, storage key, or storage value failed to use the minimal representation (i.e., no leading zeros).
    case evmHookStorageUpdateBytesMustUseMinimalRepresentation  // = 506

    /// A hook id was invalid.
    case invalidHookID  // = 507

    /// An EVM hook storage update had no contents.
    case emptyEvmHookStorageUpdate  // = 508

    /// A user repeated the same hook id in a creation details list.
    case hookIDRepeatedInCreationDetails  // = 509

    /// Hooks are not not enabled on the target Hiero network.
    case hooksNotEnabled  // = 510

    /// The target hook is not an EVM hook.
    case hookIsNotAnEvmHook  // = 511

    /// A hook was deleted.
    case hookDeleted  // = 512

    /// The HookStore tried to update too many storage slots in a single transaction.
    case tooManyEvmHookStorageUpdates  // = 513

    /// An EVM hook mapping slot, storage key, or storage value failed to use the minimal representation (i.e., no leading zeros).
    case hookCreationBytesMustUseMinimalRepresentation  // = 514

    /// A EVM hook mapping slot, storage key, or storage value exceeded 32 bytes.
    case hookCreationBytesTooLong  // = 515

    /// A hook creation spec was not found.
    case invalidHookCreationSpec  // = 516

    /// A hook extension point was empty.
    case hookExtensionEmpty  // = 517

    /// A hook admin key was invalid.
    case invalidHookAdminKey  // = 518

    /// The hook deletion requires the hook to have zero storage slots.
    case hookDeletionRequiresZeroStorageSlots  // = 519

    /// Cannot set both a hook call and an approval on the same AccountAmount or NftTransfer message.
    case cannotSetHooksAndApproval  // = 520

    /// The attempted operation is invalid until all the target entity's hooks have been deleted.
    case transactionRequiresZeroHooks  // = 521

    /// The HookCall set in the transaction is invalid
    case invalidHookCall  // = 522

    /// Hooks are not supported to be used in TokenAirdrop transactions
    case hooksAreNotSupportedInAirdrops  // = 523

    /// This operation cannot be completed because the target account is a "Node Account".<br/> This account is currently in use as the "Node Account" for a consensus node, and therefore the requested change is not permitted. The transaction may be resubmitted once the account is no longer in use as a "Node Account" for any consensus node.
    case accountIsLinkedToANode  // = 524

    /// Hooks are not supported to be used in Batch transactions and Scheduled transactions. They are only supported in a top level CryptoTransfer transaction.
    case hooksExecutionsRequireTopLevelCryptoTransfer  // = 525

    /// This operation cannot be completed because the target account has a zero balance.<br/> Node accounts require a positive balance. The transaction may be resubmitted once the account has been funded.
    case nodeAccountHasZeroBalance  // = 526

    /// This operation cannot be completed because the target account is a "Fee Collection Account".<br/> Any attempt to transfer to a fee collection account is not permitted.
    case transferToFeeCollectionAccountNotAllowed  // = 527

    /// The number of hook invocations exceeds the maximum allowed per transaction.
    case tooManyHookInvocations  // = 528

    /// A registered node ID is invalid or does not exist.
    case invalidRegisteredNodeID  // = 529

    /// A registered service endpoint is invalid.<br/> The port is out of range, or the address field is not set.
    case invalidRegisteredEndpoint  // = 530

    /// The number of registered service endpoints exceeds the configured limit.
    case registeredEndpointsExceededLimit  // = 531

    /// A registered service endpoint has an invalid address.<br/> The IP address length is not 4 (IPv4) or 16 (IPv6), or the domain name is not a valid ASCII FQDN.
    case invalidRegisteredEndpointAddress  // = 532

    /// A registered service endpoint does not specify an endpoint type.<br/> Exactly one of block_node, mirror_node, or rpc_relay MUST be set.
    case invalidRegisteredEndpointType  // = 533

    /// A registered node cannot be deleted because it is still associated with a consensus node via their associated registered node list.
    case registeredNodeStillAssociated  // = 534

    /// The number of associated registered nodes exceeds the maximum allowed limit.
    case maxRegisteredNodesExceeded  // = 535

    /// swift-format-ignore: AlwaysUseLowerCamelCase
    case unrecognized(Int32)

    // minimal edit from protoc generated: (changed from `init?`)
    // swiftlint:disable:next function_body_length
    public init(rawValue: Int32) {
        switch rawValue {
        case 0: self = .ok
        case 1: self = .invalidTransaction
        case 2: self = .payerAccountNotFound
        case 3: self = .invalidNodeAccount
        case 4: self = .transactionExpired
        case 5: self = .invalidTransactionStart
        case 6: self = .invalidTransactionDuration
        case 7: self = .invalidSignature
        case 8: self = .memoTooLong
        case 9: self = .insufficientTxFee
        case 10: self = .insufficientPayerBalance
        case 11: self = .duplicateTransaction
        case 12: self = .busy
        case 13: self = .notSupported
        case 14: self = .invalidFileID
        case 15: self = .invalidAccountID
        case 16: self = .invalidContractID
        case 17: self = .invalidTransactionID
        case 18: self = .receiptNotFound
        case 19: self = .recordNotFound
        case 20: self = .invalidSolidityID
        case 21: self = .unknown
        case 22: self = .success
        case 23: self = .failInvalid
        case 24: self = .failFee
        case 25: self = .failBalance
        case 26: self = .keyRequired
        case 27: self = .badEncoding
        case 28: self = .insufficientAccountBalance
        case 29: self = .invalidSolidityAddress
        case 30: self = .insufficientGas
        case 31: self = .contractSizeLimitExceeded
        case 32: self = .localCallModificationException
        case 33: self = .contractRevertExecuted
        case 34: self = .contractExecutionException
        case 35: self = .invalidReceivingNodeAccount
        case 36: self = .missingQueryHeader
        case 37: self = .accountUpdateFailed
        case 38: self = .invalidKeyEncoding
        case 39: self = .nullSolidityAddress
        case 40: self = .contractUpdateFailed
        case 41: self = .invalidQueryHeader
        case 42: self = .invalidFeeSubmitted
        case 43: self = .invalidPayerSignature
        case 44: self = .keyNotProvided
        case 45: self = .invalidExpirationTime
        case 46: self = .noWaclKey
        case 47: self = .fileContentEmpty
        case 48: self = .invalidAccountAmounts
        case 49: self = .emptyTransactionBody
        case 50: self = .invalidTransactionBody
        case 51: self = .invalidSignatureTypeMismatchingKey
        case 52: self = .invalidSignatureCountMismatchingKey
        case 53: self = .emptyLiveHashBody
        case 54: self = .emptyLiveHash
        case 55: self = .emptyLiveHashKeys
        case 56: self = .invalidLiveHashSize
        case 57: self = .emptyQueryBody
        case 58: self = .emptyLiveHashQuery
        case 59: self = .liveHashNotFound
        case 60: self = .accountIDDoesNotExist
        case 61: self = .liveHashAlreadyExists
        case 62: self = .invalidFileWacl
        case 63: self = .serializationFailed
        case 64: self = .transactionOversize
        case 65: self = .transactionTooManyLayers
        case 66: self = .contractDeleted
        case 67: self = .platformNotActive
        case 68: self = .keyPrefixMismatch
        case 69: self = .platformTransactionNotCreated
        case 70: self = .invalidRenewalPeriod
        case 71: self = .invalidPayerAccountID
        case 72: self = .accountDeleted
        case 73: self = .fileDeleted
        case 74: self = .accountRepeatedInAccountAmounts
        case 75: self = .settingNegativeAccountBalance
        case 76: self = .obtainerRequired
        case 77: self = .obtainerSameContractID
        case 78: self = .obtainerDoesNotExist
        case 79: self = .modifyingImmutableContract
        case 80: self = .fileSystemException
        case 81: self = .autorenewDurationNotInRange
        case 82: self = .errorDecodingBytestring
        case 83: self = .contractFileEmpty
        case 84: self = .contractBytecodeEmpty
        case 85: self = .invalidInitialBalance
        case 86: self = .invalidReceiveRecordThreshold
        case 87: self = .invalidSendRecordThreshold
        case 88: self = .accountIsNotGenesisAccount
        case 89: self = .payerAccountUnauthorized
        case 90: self = .invalidFreezeTransactionBody
        case 91: self = .freezeTransactionBodyNotFound
        case 92: self = .transferListSizeLimitExceeded
        case 93: self = .resultSizeLimitExceeded
        case 94: self = .notSpecialAccount
        case 95: self = .contractNegativeGas
        case 96: self = .contractNegativeValue
        case 97: self = .invalidFeeFile
        case 98: self = .invalidExchangeRateFile
        case 99: self = .insufficientLocalCallGas
        case 100: self = .entityNotAllowedToDelete
        case 101: self = .authorizationFailed
        case 102: self = .fileUploadedProtoInvalid
        case 103: self = .fileUploadedProtoNotSavedToDisk
        case 104: self = .feeScheduleFilePartUploaded
        case 105: self = .exchangeRateChangeLimitExceeded
        case 106: self = .maxContractStorageExceeded
        case 107: self = .transferAccountSameAsDeleteAccount
        case 108: self = .totalLedgerBalanceInvalid
        case 110: self = .expirationReductionNotAllowed
        case 111: self = .maxGasLimitExceeded
        case 112: self = .maxFileSizeExceeded
        case 113: self = .receiverSigRequired
        case 150: self = .invalidTopicID
        case 155: self = .invalidAdminKey
        case 156: self = .invalidSubmitKey
        case 157: self = .unauthorized
        case 158: self = .invalidTopicMessage
        case 159: self = .invalidAutorenewAccount
        case 160: self = .autorenewAccountNotAllowed
        case 162: self = .topicExpired
        case 163: self = .invalidChunkNumber
        case 164: self = .invalidChunkTransactionID
        case 165: self = .accountFrozenForToken
        case 166: self = .tokensPerAccountLimitExceeded
        case 167: self = .invalidTokenID
        case 168: self = .invalidTokenDecimals
        case 169: self = .invalidTokenInitialSupply
        case 170: self = .invalidTreasuryAccountForToken
        case 171: self = .invalidTokenSymbol
        case 172: self = .tokenHasNoFreezeKey
        case 173: self = .transfersNotZeroSumForToken
        case 174: self = .missingTokenSymbol
        case 175: self = .tokenSymbolTooLong
        case 176: self = .accountKycNotGrantedForToken
        case 177: self = .tokenHasNoKycKey
        case 178: self = .insufficientTokenBalance
        case 179: self = .tokenWasDeleted
        case 180: self = .tokenHasNoSupplyKey
        case 181: self = .tokenHasNoWipeKey
        case 182: self = .invalidTokenMintAmount
        case 183: self = .invalidTokenBurnAmount
        case 184: self = .tokenNotAssociatedToAccount
        case 185: self = .cannotWipeTokenTreasuryAccount
        case 186: self = .invalidKycKey
        case 187: self = .invalidWipeKey
        case 188: self = .invalidFreezeKey
        case 189: self = .invalidSupplyKey
        case 190: self = .missingTokenName
        case 191: self = .tokenNameTooLong
        case 192: self = .invalidWipingAmount
        case 193: self = .tokenIsImmutable
        case 194: self = .tokenAlreadyAssociatedToAccount
        case 195: self = .transactionRequiresZeroTokenBalances
        case 196: self = .accountIsTreasury
        case 197: self = .tokenIDRepeatedInTokenList
        case 198: self = .tokenTransferListSizeLimitExceeded
        case 199: self = .emptyTokenTransferBody
        case 200: self = .emptyTokenTransferAccountAmounts
        case 201: self = .invalidScheduleID
        case 202: self = .scheduleIsImmutable
        case 203: self = .invalidSchedulePayerID
        case 204: self = .invalidScheduleAccountID
        case 205: self = .noNewValidSignatures
        case 206: self = .unresolvableRequiredSigners
        case 207: self = .scheduledTransactionNotInWhitelist
        case 208: self = .someSignaturesWereInvalid
        case 209: self = .transactionIDFieldNotAllowed
        case 210: self = .identicalScheduleAlreadyCreated
        case 211: self = .invalidZeroByteInString
        case 212: self = .scheduleAlreadyDeleted
        case 213: self = .scheduleAlreadyExecuted
        case 214: self = .messageSizeTooLarge
        case 215: self = .operationRepeatedInBucketGroups
        case 216: self = .bucketCapacityOverflow
        case 217: self = .nodeCapacityNotSufficientForOperation
        case 218: self = .bucketHasNoThrottleGroups
        case 219: self = .throttleGroupHasZeroOpsPerSec
        case 220: self = .successButMissingExpectedOperation
        case 221: self = .unparseableThrottleDefinitions
        case 222: self = .invalidThrottleDefinitions
        case 223: self = .accountExpiredAndPendingRemoval
        case 224: self = .invalidTokenMaxSupply
        case 225: self = .invalidTokenNftSerialNumber
        case 226: self = .invalidNftID
        case 227: self = .metadataTooLong
        case 228: self = .batchSizeLimitExceeded
        case 229: self = .invalidQueryRange
        case 230: self = .fractionDividesByZero
        case 231: self = .insufficientPayerBalanceForCustomFee
        case 232: self = .customFeesListTooLong
        case 233: self = .invalidCustomFeeCollector
        case 234: self = .invalidTokenIDInCustomFees
        case 235: self = .tokenNotAssociatedToFeeCollector
        case 236: self = .tokenMaxSupplyReached
        case 237: self = .senderDoesNotOwnNftSerialNo
        case 238: self = .customFeeNotFullySpecified
        case 239: self = .customFeeMustBePositive
        case 240: self = .tokenHasNoFeeScheduleKey
        case 241: self = .customFeeOutsideNumericRange
        case 242: self = .royaltyFractionCannotExceedOne
        case 243: self = .fractionalFeeMaxAmountLessThanMinAmount
        case 244: self = .customScheduleAlreadyHasNoFees
        case 245: self = .customFeeDenominationMustBeFungibleCommon
        case 246: self = .customFractionalFeeOnlyAllowedForFungibleCommon
        case 247: self = .invalidCustomFeeScheduleKey
        case 248: self = .invalidTokenMintMetadata
        case 249: self = .invalidTokenBurnMetadata
        case 250: self = .currentTreasuryStillOwnsNfts
        case 251: self = .accountStillOwnsNfts
        case 252: self = .treasuryMustOwnBurnedNft
        case 253: self = .accountDoesNotOwnWipedNft
        case 254: self = .accountAmountTransfersOnlyAllowedForFungibleCommon
        case 255: self = .maxNftsInPriceRegimeHaveBeenMinted
        case 256: self = .payerAccountDeleted
        case 257: self = .customFeeChargingExceededMaxRecursionDepth
        case 258: self = .customFeeChargingExceededMaxAccountAmounts
        case 259: self = .insufficientSenderAccountBalanceForCustomFee
        case 260: self = .serialNumberLimitReached
        case 261: self = .customRoyaltyFeeOnlyAllowedForNonFungibleUnique
        case 262: self = .noRemainingAutomaticAssociations
        case 263: self = .existingAutomaticAssociationsExceedGivenLimit
        case 264: self = .requestedNumAutomaticAssociationsExceedsAssociationLimit
        case 265: self = .tokenIsPaused
        case 266: self = .tokenHasNoPauseKey
        case 267: self = .invalidPauseKey
        case 268: self = .freezeUpdateFileDoesNotExist
        case 269: self = .freezeUpdateFileHashDoesNotMatch
        case 270: self = .noUpgradeHasBeenPrepared
        case 271: self = .noFreezeIsScheduled
        case 272: self = .updateFileHashChangedSincePrepareUpgrade
        case 273: self = .freezeStartTimeMustBeFuture
        case 274: self = .preparedUpdateFileIsImmutable
        case 275: self = .freezeAlreadyScheduled
        case 276: self = .freezeUpgradeInProgress
        case 277: self = .updateFileIDDoesNotMatchPrepared
        case 278: self = .updateFileHashDoesNotMatchPrepared
        case 279: self = .consensusGasExhausted
        case 280: self = .revertedSuccess
        case 281: self = .maxStorageInPriceRegimeHasBeenUsed
        case 282: self = .invalidAliasKey
        case 283: self = .unexpectedTokenDecimals
        case 284: self = .invalidProxyAccountID
        case 285: self = .invalidTransferAccountID
        case 286: self = .invalidFeeCollectorAccountID
        case 287: self = .aliasIsImmutable
        case 288: self = .spenderAccountSameAsOwner
        case 289: self = .amountExceedsTokenMaxSupply
        case 290: self = .negativeAllowanceAmount
        case 291: self = .cannotApproveForAllFungibleCommon
        case 292: self = .spenderDoesNotHaveAllowance
        case 293: self = .amountExceedsAllowance
        case 294: self = .maxAllowancesExceeded
        case 295: self = .emptyAllowances
        case 296: self = .spenderAccountRepeatedInAllowances
        case 297: self = .repeatedSerialNumsInNftAllowances
        case 298: self = .fungibleTokenInNftAllowances
        case 299: self = .nftInFungibleTokenAllowances
        case 300: self = .invalidAllowanceOwnerID
        case 301: self = .invalidAllowanceSpenderID
        case 302: self = .repeatedAllowancesToDelete
        case 303: self = .invalidDelegatingSpender
        case 304: self = .delegatingSpenderCannotGrantApproveForAll
        case 305: self = .delegatingSpenderDoesNotHaveApproveForAll
        case 306: self = .scheduleExpirationTimeTooFarInFuture
        case 307: self = .scheduleExpirationTimeMustBeHigherThanConsensusTime
        case 308: self = .scheduleFutureThrottleExceeded
        case 309: self = .scheduleFutureGasLimitExceeded
        case 310: self = .invalidEthereumTransaction
        case 311: self = .wrongChainID
        case 312: self = .wrongNonce
        case 313: self = .accessListUnsupported
        case 314: self = .schedulePendingExpiration
        case 315: self = .contractIsTokenTreasury
        case 316: self = .contractHasNonZeroTokenBalances
        case 317: self = .contractExpiredAndPendingRemoval
        case 318: self = .contractHasNoAutoRenewAccount
        case 319: self = .permanentRemovalRequiresSystemInitiation
        case 320: self = .proxyAccountIDFieldIsDeprecated
        case 321: self = .selfStakingIsNotAllowed
        case 322: self = .invalidStakingID
        case 323: self = .stakingNotEnabled
        case 324: self = .invalidPrngRange
        case 325: self = .maxEntitiesInPriceRegimeHaveBeenCreated
        case 326: self = .invalidFullPrefixSignatureForPrecompile
        case 327: self = .insufficientBalancesForStorageRent
        case 328: self = .maxChildRecordsExceeded
        case 329: self = .insufficientBalancesForRenewalFees
        case 330: self = .transactionHasUnknownFields
        case 331: self = .accountIsImmutable
        case 332: self = .aliasAlreadyAssigned
        case 333: self = .invalidMetadataKey
        case 334: self = .tokenHasNoMetadataKey
        case 335: self = .missingTokenMetadata
        case 336: self = .missingSerialNumbers
        case 337: self = .tokenHasNoAdminKey
        case 338: self = .nodeDeleted
        case 339: self = .invalidNodeID
        case 340: self = .invalidGossipEndpoint
        case 341: self = .invalidNodeAccountID
        case 342: self = .invalidNodeDescription
        case 343: self = .invalidServiceEndpoint
        case 344: self = .invalidGossipCaCertificate
        case 345: self = .invalidGrpcCertificate
        case 346: self = .invalidMaxAutoAssociations
        case 347: self = .maxNodesCreated
        case 348: self = .ipFqdnCannotBeSetForSameEndpoint
        case 349: self = .gossipEndpointCannotHaveFqdn
        case 350: self = .fqdnSizeTooLarge
        case 351: self = .invalidEndpoint
        case 352: self = .gossipEndpointsExceededLimit
        case 353: self = .tokenReferenceRepeated
        case 354: self = .invalidOwnerID
        case 355: self = .tokenReferenceListSizeLimitExceeded
        case 356: self = .serviceEndpointsExceededLimit
        case 357: self = .invalidIpv4Address
        case 358: self = .emptyTokenReferenceList
        case 359: self = .updateNodeAccountNotAllowed
        case 360: self = .tokenHasNoMetadataOrSupplyKey
        case 361: self = .emptyPendingAirdropIdList
        case 362: self = .pendingAirdropIdRepeated
        case 363: self = .pendingAirdropIdListTooLong
        case 364: self = .pendingNftAirdropAlreadyExists
        case 365: self = .accountHasPendingAirdrops
        case 366: self = .throttledAtConsensus
        case 367: self = .invalidPendingAirdropId
        case 368: self = .tokenAirdropWithFallbackRoyalty
        case 369: self = .invalidTokenInPendingAirdrop
        case 370: self = .scheduleExpiryIsBusy
        case 371: self = .invalidGrpcCertificateHash
        case 372: self = .missingExpiryTime
        case 373: self = .noSchedulingAllowedAfterScheduledRecursion
        case 374: self = .recursiveSchedulingLimitReached
        case 375: self = .waitingForLedgerID
        case 376: self = .maxEntriesForFeeExemptKeyListExceeded
        case 377: self = .feeExemptKeyListContainsDuplicatedKeys
        case 378: self = .invalidKeyInFeeExemptKeyList
        case 379: self = .invalidFeeScheduleKey
        case 380: self = .feeScheduleKeyCannotBeUpdated
        case 381: self = .feeScheduleKeyNotSet
        case 382: self = .maxCustomFeeLimitExceeded
        case 383: self = .noValidMaxCustomFee
        case 384: self = .invalidMaxCustomFees
        case 385: self = .duplicateDenominationInMaxCustomFeeList
        case 386: self = .duplicateAccountIDInMaxCustomFeeList
        case 387: self = .maxCustomFeesIsNotSupported
        case 388: self = .batchListEmpty
        case 389: self = .batchListContainsDuplicates
        case 390: self = .batchTransactionInBlacklist
        case 391: self = .innerTransactionFailed
        case 392: self = .missingBatchKey
        case 393: self = .batchKeySetOnNonInnerTransaction
        case 394: self = .invalidBatchKey
        case 395: self = .scheduleExpiryNotConfigurable
        case 396: self = .creatingSystemEntities
        case 397: self = .throttleGroupLcmOverflow
        case 398: self = .airdropContainsMultipleSendersForAToken
        case 399: self = .grpcWebProxyNotSupported
        case 400: self = .nftTransfersOnlyAllowedForNonFungibleUnique
        case 401: self = .invalidSerializedTxMessageHashAlgorithm
        case 499: self = .wrongHookEntityType
        case 500: self = .evmHookGasThrottled
        case 501: self = .hookIDInUse
        case 502: self = .badHookRequest
        case 503: self = .rejectedByAccountAllowanceHook
        case 504: self = .hookNotFound
        case 505: self = .evmHookStorageUpdateBytesTooLong
        case 506: self = .evmHookStorageUpdateBytesMustUseMinimalRepresentation
        case 507: self = .invalidHookID
        case 508: self = .emptyEvmHookStorageUpdate
        case 509: self = .hookIDRepeatedInCreationDetails
        case 510: self = .hooksNotEnabled
        case 511: self = .hookIsNotAnEvmHook
        case 512: self = .hookDeleted
        case 513: self = .tooManyEvmHookStorageUpdates
        case 514: self = .hookCreationBytesMustUseMinimalRepresentation
        case 515: self = .hookCreationBytesTooLong
        case 516: self = .invalidHookCreationSpec
        case 517: self = .hookExtensionEmpty
        case 518: self = .invalidHookAdminKey
        case 519: self = .hookDeletionRequiresZeroStorageSlots
        case 520: self = .cannotSetHooksAndApproval
        case 521: self = .transactionRequiresZeroHooks
        case 522: self = .invalidHookCall
        case 523: self = .hooksAreNotSupportedInAirdrops
        case 524: self = .accountIsLinkedToANode
        case 525: self = .hooksExecutionsRequireTopLevelCryptoTransfer
        case 526: self = .nodeAccountHasZeroBalance
        case 527: self = .transferToFeeCollectionAccountNotAllowed
        case 528: self = .tooManyHookInvocations
        case 529: self = .invalidRegisteredNodeID
        case 530: self = .invalidRegisteredEndpoint
        case 531: self = .registeredEndpointsExceededLimit
        case 532: self = .invalidRegisteredEndpointAddress
        case 533: self = .invalidRegisteredEndpointType
        case 534: self = .registeredNodeStillAssociated
        case 535: self = .maxRegisteredNodesExceeded
        default: self = .unrecognized(rawValue)
        }
    }

    public var rawValue: Int32 {
        switch self {
        case .ok: return 0
        case .invalidTransaction: return 1
        case .payerAccountNotFound: return 2
        case .invalidNodeAccount: return 3
        case .transactionExpired: return 4
        case .invalidTransactionStart: return 5
        case .invalidTransactionDuration: return 6
        case .invalidSignature: return 7
        case .memoTooLong: return 8
        case .insufficientTxFee: return 9
        case .insufficientPayerBalance: return 10
        case .duplicateTransaction: return 11
        case .busy: return 12
        case .notSupported: return 13
        case .invalidFileID: return 14
        case .invalidAccountID: return 15
        case .invalidContractID: return 16
        case .invalidTransactionID: return 17
        case .receiptNotFound: return 18
        case .recordNotFound: return 19
        case .invalidSolidityID: return 20
        case .unknown: return 21
        case .success: return 22
        case .failInvalid: return 23
        case .failFee: return 24
        case .failBalance: return 25
        case .keyRequired: return 26
        case .badEncoding: return 27
        case .insufficientAccountBalance: return 28
        case .invalidSolidityAddress: return 29
        case .insufficientGas: return 30
        case .contractSizeLimitExceeded: return 31
        case .localCallModificationException: return 32
        case .contractRevertExecuted: return 33
        case .contractExecutionException: return 34
        case .invalidReceivingNodeAccount: return 35
        case .missingQueryHeader: return 36
        case .accountUpdateFailed: return 37
        case .invalidKeyEncoding: return 38
        case .nullSolidityAddress: return 39
        case .contractUpdateFailed: return 40
        case .invalidQueryHeader: return 41
        case .invalidFeeSubmitted: return 42
        case .invalidPayerSignature: return 43
        case .keyNotProvided: return 44
        case .invalidExpirationTime: return 45
        case .noWaclKey: return 46
        case .fileContentEmpty: return 47
        case .invalidAccountAmounts: return 48
        case .emptyTransactionBody: return 49
        case .invalidTransactionBody: return 50
        case .invalidSignatureTypeMismatchingKey: return 51
        case .invalidSignatureCountMismatchingKey: return 52
        case .emptyLiveHashBody: return 53
        case .emptyLiveHash: return 54
        case .emptyLiveHashKeys: return 55
        case .invalidLiveHashSize: return 56
        case .emptyQueryBody: return 57
        case .emptyLiveHashQuery: return 58
        case .liveHashNotFound: return 59
        case .accountIDDoesNotExist: return 60
        case .liveHashAlreadyExists: return 61
        case .invalidFileWacl: return 62
        case .serializationFailed: return 63
        case .transactionOversize: return 64
        case .transactionTooManyLayers: return 65
        case .contractDeleted: return 66
        case .platformNotActive: return 67
        case .keyPrefixMismatch: return 68
        case .platformTransactionNotCreated: return 69
        case .invalidRenewalPeriod: return 70
        case .invalidPayerAccountID: return 71
        case .accountDeleted: return 72
        case .fileDeleted: return 73
        case .accountRepeatedInAccountAmounts: return 74
        case .settingNegativeAccountBalance: return 75
        case .obtainerRequired: return 76
        case .obtainerSameContractID: return 77
        case .obtainerDoesNotExist: return 78
        case .modifyingImmutableContract: return 79
        case .fileSystemException: return 80
        case .autorenewDurationNotInRange: return 81
        case .errorDecodingBytestring: return 82
        case .contractFileEmpty: return 83
        case .contractBytecodeEmpty: return 84
        case .invalidInitialBalance: return 85
        case .invalidReceiveRecordThreshold: return 86
        case .invalidSendRecordThreshold: return 87
        case .accountIsNotGenesisAccount: return 88
        case .payerAccountUnauthorized: return 89
        case .invalidFreezeTransactionBody: return 90
        case .freezeTransactionBodyNotFound: return 91
        case .transferListSizeLimitExceeded: return 92
        case .resultSizeLimitExceeded: return 93
        case .notSpecialAccount: return 94
        case .contractNegativeGas: return 95
        case .contractNegativeValue: return 96
        case .invalidFeeFile: return 97
        case .invalidExchangeRateFile: return 98
        case .insufficientLocalCallGas: return 99
        case .entityNotAllowedToDelete: return 100
        case .authorizationFailed: return 101
        case .fileUploadedProtoInvalid: return 102
        case .fileUploadedProtoNotSavedToDisk: return 103
        case .feeScheduleFilePartUploaded: return 104
        case .exchangeRateChangeLimitExceeded: return 105
        case .maxContractStorageExceeded: return 106
        case .transferAccountSameAsDeleteAccount: return 107
        case .totalLedgerBalanceInvalid: return 108
        case .expirationReductionNotAllowed: return 110
        case .maxGasLimitExceeded: return 111
        case .maxFileSizeExceeded: return 112
        case .receiverSigRequired: return 113
        case .invalidTopicID: return 150
        case .invalidAdminKey: return 155
        case .invalidSubmitKey: return 156
        case .unauthorized: return 157
        case .invalidTopicMessage: return 158
        case .invalidAutorenewAccount: return 159
        case .autorenewAccountNotAllowed: return 160
        case .topicExpired: return 162
        case .invalidChunkNumber: return 163
        case .invalidChunkTransactionID: return 164
        case .accountFrozenForToken: return 165
        case .tokensPerAccountLimitExceeded: return 166
        case .invalidTokenID: return 167
        case .invalidTokenDecimals: return 168
        case .invalidTokenInitialSupply: return 169
        case .invalidTreasuryAccountForToken: return 170
        case .invalidTokenSymbol: return 171
        case .tokenHasNoFreezeKey: return 172
        case .transfersNotZeroSumForToken: return 173
        case .missingTokenSymbol: return 174
        case .tokenSymbolTooLong: return 175
        case .accountKycNotGrantedForToken: return 176
        case .tokenHasNoKycKey: return 177
        case .insufficientTokenBalance: return 178
        case .tokenWasDeleted: return 179
        case .tokenHasNoSupplyKey: return 180
        case .tokenHasNoWipeKey: return 181
        case .invalidTokenMintAmount: return 182
        case .invalidTokenBurnAmount: return 183
        case .tokenNotAssociatedToAccount: return 184
        case .cannotWipeTokenTreasuryAccount: return 185
        case .invalidKycKey: return 186
        case .invalidWipeKey: return 187
        case .invalidFreezeKey: return 188
        case .invalidSupplyKey: return 189
        case .missingTokenName: return 190
        case .tokenNameTooLong: return 191
        case .invalidWipingAmount: return 192
        case .tokenIsImmutable: return 193
        case .tokenAlreadyAssociatedToAccount: return 194
        case .transactionRequiresZeroTokenBalances: return 195
        case .accountIsTreasury: return 196
        case .tokenIDRepeatedInTokenList: return 197
        case .tokenTransferListSizeLimitExceeded: return 198
        case .emptyTokenTransferBody: return 199
        case .emptyTokenTransferAccountAmounts: return 200
        case .invalidScheduleID: return 201
        case .scheduleIsImmutable: return 202
        case .invalidSchedulePayerID: return 203
        case .invalidScheduleAccountID: return 204
        case .noNewValidSignatures: return 205
        case .unresolvableRequiredSigners: return 206
        case .scheduledTransactionNotInWhitelist: return 207
        case .someSignaturesWereInvalid: return 208
        case .transactionIDFieldNotAllowed: return 209
        case .identicalScheduleAlreadyCreated: return 210
        case .invalidZeroByteInString: return 211
        case .scheduleAlreadyDeleted: return 212
        case .scheduleAlreadyExecuted: return 213
        case .messageSizeTooLarge: return 214
        case .operationRepeatedInBucketGroups: return 215
        case .bucketCapacityOverflow: return 216
        case .nodeCapacityNotSufficientForOperation: return 217
        case .bucketHasNoThrottleGroups: return 218
        case .throttleGroupHasZeroOpsPerSec: return 219
        case .successButMissingExpectedOperation: return 220
        case .unparseableThrottleDefinitions: return 221
        case .invalidThrottleDefinitions: return 222
        case .accountExpiredAndPendingRemoval: return 223
        case .invalidTokenMaxSupply: return 224
        case .invalidTokenNftSerialNumber: return 225
        case .invalidNftID: return 226
        case .metadataTooLong: return 227
        case .batchSizeLimitExceeded: return 228
        case .invalidQueryRange: return 229
        case .fractionDividesByZero: return 230
        case .insufficientPayerBalanceForCustomFee: return 231
        case .customFeesListTooLong: return 232
        case .invalidCustomFeeCollector: return 233
        case .invalidTokenIDInCustomFees: return 234
        case .tokenNotAssociatedToFeeCollector: return 235
        case .tokenMaxSupplyReached: return 236
        case .senderDoesNotOwnNftSerialNo: return 237
        case .customFeeNotFullySpecified: return 238
        case .customFeeMustBePositive: return 239
        case .tokenHasNoFeeScheduleKey: return 240
        case .customFeeOutsideNumericRange: return 241
        case .royaltyFractionCannotExceedOne: return 242
        case .fractionalFeeMaxAmountLessThanMinAmount: return 243
        case .customScheduleAlreadyHasNoFees: return 244
        case .customFeeDenominationMustBeFungibleCommon: return 245
        case .customFractionalFeeOnlyAllowedForFungibleCommon: return 246
        case .invalidCustomFeeScheduleKey: return 247
        case .invalidTokenMintMetadata: return 248
        case .invalidTokenBurnMetadata: return 249
        case .currentTreasuryStillOwnsNfts: return 250
        case .accountStillOwnsNfts: return 251
        case .treasuryMustOwnBurnedNft: return 252
        case .accountDoesNotOwnWipedNft: return 253
        case .accountAmountTransfersOnlyAllowedForFungibleCommon: return 254
        case .maxNftsInPriceRegimeHaveBeenMinted: return 255
        case .payerAccountDeleted: return 256
        case .customFeeChargingExceededMaxRecursionDepth: return 257
        case .customFeeChargingExceededMaxAccountAmounts: return 258
        case .insufficientSenderAccountBalanceForCustomFee: return 259
        case .serialNumberLimitReached: return 260
        case .customRoyaltyFeeOnlyAllowedForNonFungibleUnique: return 261
        case .noRemainingAutomaticAssociations: return 262
        case .existingAutomaticAssociationsExceedGivenLimit: return 263
        case .requestedNumAutomaticAssociationsExceedsAssociationLimit: return 264
        case .tokenIsPaused: return 265
        case .tokenHasNoPauseKey: return 266
        case .invalidPauseKey: return 267
        case .freezeUpdateFileDoesNotExist: return 268
        case .freezeUpdateFileHashDoesNotMatch: return 269
        case .noUpgradeHasBeenPrepared: return 270
        case .noFreezeIsScheduled: return 271
        case .updateFileHashChangedSincePrepareUpgrade: return 272
        case .freezeStartTimeMustBeFuture: return 273
        case .preparedUpdateFileIsImmutable: return 274
        case .freezeAlreadyScheduled: return 275
        case .freezeUpgradeInProgress: return 276
        case .updateFileIDDoesNotMatchPrepared: return 277
        case .updateFileHashDoesNotMatchPrepared: return 278
        case .consensusGasExhausted: return 279
        case .revertedSuccess: return 280
        case .maxStorageInPriceRegimeHasBeenUsed: return 281
        case .invalidAliasKey: return 282
        case .unexpectedTokenDecimals: return 283
        case .invalidProxyAccountID: return 284
        case .invalidTransferAccountID: return 285
        case .invalidFeeCollectorAccountID: return 286
        case .aliasIsImmutable: return 287
        case .spenderAccountSameAsOwner: return 288
        case .amountExceedsTokenMaxSupply: return 289
        case .negativeAllowanceAmount: return 290
        case .cannotApproveForAllFungibleCommon: return 291
        case .spenderDoesNotHaveAllowance: return 292
        case .amountExceedsAllowance: return 293
        case .maxAllowancesExceeded: return 294
        case .emptyAllowances: return 295
        case .spenderAccountRepeatedInAllowances: return 296
        case .repeatedSerialNumsInNftAllowances: return 297
        case .fungibleTokenInNftAllowances: return 298
        case .nftInFungibleTokenAllowances: return 299
        case .invalidAllowanceOwnerID: return 300
        case .invalidAllowanceSpenderID: return 301
        case .repeatedAllowancesToDelete: return 302
        case .invalidDelegatingSpender: return 303
        case .delegatingSpenderCannotGrantApproveForAll: return 304
        case .delegatingSpenderDoesNotHaveApproveForAll: return 305
        case .scheduleExpirationTimeTooFarInFuture: return 306
        case .scheduleExpirationTimeMustBeHigherThanConsensusTime: return 307
        case .scheduleFutureThrottleExceeded: return 308
        case .scheduleFutureGasLimitExceeded: return 309
        case .invalidEthereumTransaction: return 310
        case .wrongChainID: return 311
        case .wrongNonce: return 312
        case .accessListUnsupported: return 313
        case .schedulePendingExpiration: return 314
        case .contractIsTokenTreasury: return 315
        case .contractHasNonZeroTokenBalances: return 316
        case .contractExpiredAndPendingRemoval: return 317
        case .contractHasNoAutoRenewAccount: return 318
        case .permanentRemovalRequiresSystemInitiation: return 319
        case .proxyAccountIDFieldIsDeprecated: return 320
        case .selfStakingIsNotAllowed: return 321
        case .invalidStakingID: return 322
        case .stakingNotEnabled: return 323
        case .invalidPrngRange: return 324
        case .maxEntitiesInPriceRegimeHaveBeenCreated: return 325
        case .invalidFullPrefixSignatureForPrecompile: return 326
        case .insufficientBalancesForStorageRent: return 327
        case .maxChildRecordsExceeded: return 328
        case .insufficientBalancesForRenewalFees: return 329
        case .transactionHasUnknownFields: return 330
        case .accountIsImmutable: return 331
        case .aliasAlreadyAssigned: return 332
        case .invalidMetadataKey: return 333
        case .tokenHasNoMetadataKey: return 334
        case .missingTokenMetadata: return 335
        case .missingSerialNumbers: return 336
        case .tokenHasNoAdminKey: return 337
        case .nodeDeleted: return 338
        case .invalidNodeID: return 339
        case .invalidGossipEndpoint: return 340
        case .invalidNodeAccountID: return 341
        case .invalidNodeDescription: return 342
        case .invalidServiceEndpoint: return 343
        case .invalidGossipCaCertificate: return 344
        case .invalidGrpcCertificate: return 345
        case .invalidMaxAutoAssociations: return 346
        case .maxNodesCreated: return 347
        case .ipFqdnCannotBeSetForSameEndpoint: return 348
        case .gossipEndpointCannotHaveFqdn: return 349
        case .fqdnSizeTooLarge: return 350
        case .invalidEndpoint: return 351
        case .gossipEndpointsExceededLimit: return 352
        case .tokenReferenceRepeated: return 353
        case .invalidOwnerID: return 354
        case .tokenReferenceListSizeLimitExceeded: return 355
        case .serviceEndpointsExceededLimit: return 356
        case .invalidIpv4Address: return 357
        case .emptyTokenReferenceList: return 358
        case .updateNodeAccountNotAllowed: return 359
        case .tokenHasNoMetadataOrSupplyKey: return 360
        case .emptyPendingAirdropIdList: return 361
        case .pendingAirdropIdRepeated: return 362
        case .pendingAirdropIdListTooLong: return 363
        case .pendingNftAirdropAlreadyExists: return 364
        case .accountHasPendingAirdrops: return 365
        case .throttledAtConsensus: return 366
        case .invalidPendingAirdropId: return 367
        case .tokenAirdropWithFallbackRoyalty: return 368
        case .invalidTokenInPendingAirdrop: return 369
        case .scheduleExpiryIsBusy: return 370
        case .invalidGrpcCertificateHash: return 371
        case .missingExpiryTime: return 372
        case .noSchedulingAllowedAfterScheduledRecursion: return 373
        case .recursiveSchedulingLimitReached: return 374
        case .waitingForLedgerID: return 375
        case .maxEntriesForFeeExemptKeyListExceeded: return 376
        case .feeExemptKeyListContainsDuplicatedKeys: return 377
        case .invalidKeyInFeeExemptKeyList: return 378
        case .invalidFeeScheduleKey: return 379
        case .feeScheduleKeyCannotBeUpdated: return 380
        case .feeScheduleKeyNotSet: return 381
        case .maxCustomFeeLimitExceeded: return 382
        case .noValidMaxCustomFee: return 383
        case .invalidMaxCustomFees: return 384
        case .duplicateDenominationInMaxCustomFeeList: return 385
        case .duplicateAccountIDInMaxCustomFeeList: return 386
        case .maxCustomFeesIsNotSupported: return 387
        case .batchListEmpty: return 388
        case .batchListContainsDuplicates: return 389
        case .batchTransactionInBlacklist: return 390
        case .innerTransactionFailed: return 391
        case .missingBatchKey: return 392
        case .batchKeySetOnNonInnerTransaction: return 393
        case .invalidBatchKey: return 394
        case .scheduleExpiryNotConfigurable: return 395
        case .creatingSystemEntities: return 396
        case .throttleGroupLcmOverflow: return 397
        case .airdropContainsMultipleSendersForAToken: return 398
        case .grpcWebProxyNotSupported: return 399
        case .nftTransfersOnlyAllowedForNonFungibleUnique: return 400
        case .invalidSerializedTxMessageHashAlgorithm: return 401
        case .wrongHookEntityType: return 499
        case .evmHookGasThrottled: return 500
        case .hookIDInUse: return 501
        case .badHookRequest: return 502
        case .rejectedByAccountAllowanceHook: return 503
        case .hookNotFound: return 504
        case .evmHookStorageUpdateBytesTooLong: return 505
        case .evmHookStorageUpdateBytesMustUseMinimalRepresentation: return 506
        case .invalidHookID: return 507
        case .emptyEvmHookStorageUpdate: return 508
        case .hookIDRepeatedInCreationDetails: return 509
        case .hooksNotEnabled: return 510
        case .hookIsNotAnEvmHook: return 511
        case .hookDeleted: return 512
        case .tooManyEvmHookStorageUpdates: return 513
        case .hookCreationBytesMustUseMinimalRepresentation: return 514
        case .hookCreationBytesTooLong: return 515
        case .invalidHookCreationSpec: return 516
        case .hookExtensionEmpty: return 517
        case .invalidHookAdminKey: return 518
        case .hookDeletionRequiresZeroStorageSlots: return 519
        case .cannotSetHooksAndApproval: return 520
        case .transactionRequiresZeroHooks: return 521
        case .invalidHookCall: return 522
        case .hooksAreNotSupportedInAirdrops: return 523
        case .accountIsLinkedToANode: return 524
        case .hooksExecutionsRequireTopLevelCryptoTransfer: return 525
        case .nodeAccountHasZeroBalance: return 526
        case .transferToFeeCollectionAccountNotAllowed: return 527
        case .tooManyHookInvocations: return 528
        case .invalidRegisteredNodeID: return 529
        case .invalidRegisteredEndpoint: return 530
        case .registeredEndpointsExceededLimit: return 531
        case .invalidRegisteredEndpointAddress: return 532
        case .invalidRegisteredEndpointType: return 533
        case .registeredNodeStillAssociated: return 534
        case .maxRegisteredNodesExceeded: return 535
        case .unrecognized(let i): return i
        }
    }

}

extension Status: CaseIterable {
    // The compiler won't synthesize support with the unrecognized case.
    public static let allCases: [Status] = [
        .ok,
        .invalidTransaction,
        .payerAccountNotFound,
        .invalidNodeAccount,
        .transactionExpired,
        .invalidTransactionStart,
        .invalidTransactionDuration,
        .invalidSignature,
        .memoTooLong,
        .insufficientTxFee,
        .insufficientPayerBalance,
        .duplicateTransaction,
        .busy,
        .notSupported,
        .invalidFileID,
        .invalidAccountID,
        .invalidContractID,
        .invalidTransactionID,
        .receiptNotFound,
        .recordNotFound,
        .invalidSolidityID,
        .unknown,
        .success,
        .failInvalid,
        .failFee,
        .failBalance,
        .keyRequired,
        .badEncoding,
        .insufficientAccountBalance,
        .invalidSolidityAddress,
        .insufficientGas,
        .contractSizeLimitExceeded,
        .localCallModificationException,
        .contractRevertExecuted,
        .contractExecutionException,
        .invalidReceivingNodeAccount,
        .missingQueryHeader,
        .accountUpdateFailed,
        .invalidKeyEncoding,
        .nullSolidityAddress,
        .contractUpdateFailed,
        .invalidQueryHeader,
        .invalidFeeSubmitted,
        .invalidPayerSignature,
        .keyNotProvided,
        .invalidExpirationTime,
        .noWaclKey,
        .fileContentEmpty,
        .invalidAccountAmounts,
        .emptyTransactionBody,
        .invalidTransactionBody,
        .invalidSignatureTypeMismatchingKey,
        .invalidSignatureCountMismatchingKey,
        .emptyLiveHashBody,
        .emptyLiveHash,
        .emptyLiveHashKeys,
        .invalidLiveHashSize,
        .emptyQueryBody,
        .emptyLiveHashQuery,
        .liveHashNotFound,
        .accountIDDoesNotExist,
        .liveHashAlreadyExists,
        .invalidFileWacl,
        .serializationFailed,
        .transactionOversize,
        .transactionTooManyLayers,
        .contractDeleted,
        .platformNotActive,
        .keyPrefixMismatch,
        .platformTransactionNotCreated,
        .invalidRenewalPeriod,
        .invalidPayerAccountID,
        .accountDeleted,
        .fileDeleted,
        .accountRepeatedInAccountAmounts,
        .settingNegativeAccountBalance,
        .obtainerRequired,
        .obtainerSameContractID,
        .obtainerDoesNotExist,
        .modifyingImmutableContract,
        .fileSystemException,
        .autorenewDurationNotInRange,
        .errorDecodingBytestring,
        .contractFileEmpty,
        .contractBytecodeEmpty,
        .invalidInitialBalance,
        .invalidReceiveRecordThreshold,
        .invalidSendRecordThreshold,
        .accountIsNotGenesisAccount,
        .payerAccountUnauthorized,
        .invalidFreezeTransactionBody,
        .freezeTransactionBodyNotFound,
        .transferListSizeLimitExceeded,
        .resultSizeLimitExceeded,
        .notSpecialAccount,
        .contractNegativeGas,
        .contractNegativeValue,
        .invalidFeeFile,
        .invalidExchangeRateFile,
        .insufficientLocalCallGas,
        .entityNotAllowedToDelete,
        .authorizationFailed,
        .fileUploadedProtoInvalid,
        .fileUploadedProtoNotSavedToDisk,
        .feeScheduleFilePartUploaded,
        .exchangeRateChangeLimitExceeded,
        .maxContractStorageExceeded,
        .transferAccountSameAsDeleteAccount,
        .totalLedgerBalanceInvalid,
        .expirationReductionNotAllowed,
        .maxGasLimitExceeded,
        .maxFileSizeExceeded,
        .receiverSigRequired,
        .invalidTopicID,
        .invalidAdminKey,
        .invalidSubmitKey,
        .unauthorized,
        .invalidTopicMessage,
        .invalidAutorenewAccount,
        .autorenewAccountNotAllowed,
        .topicExpired,
        .invalidChunkNumber,
        .invalidChunkTransactionID,
        .accountFrozenForToken,
        .tokensPerAccountLimitExceeded,
        .invalidTokenID,
        .invalidTokenDecimals,
        .invalidTokenInitialSupply,
        .invalidTreasuryAccountForToken,
        .invalidTokenSymbol,
        .tokenHasNoFreezeKey,
        .transfersNotZeroSumForToken,
        .missingTokenSymbol,
        .tokenSymbolTooLong,
        .accountKycNotGrantedForToken,
        .tokenHasNoKycKey,
        .insufficientTokenBalance,
        .tokenWasDeleted,
        .tokenHasNoSupplyKey,
        .tokenHasNoWipeKey,
        .invalidTokenMintAmount,
        .invalidTokenBurnAmount,
        .tokenNotAssociatedToAccount,
        .cannotWipeTokenTreasuryAccount,
        .invalidKycKey,
        .invalidWipeKey,
        .invalidFreezeKey,
        .invalidSupplyKey,
        .missingTokenName,
        .tokenNameTooLong,
        .invalidWipingAmount,
        .tokenIsImmutable,
        .tokenAlreadyAssociatedToAccount,
        .transactionRequiresZeroTokenBalances,
        .accountIsTreasury,
        .tokenIDRepeatedInTokenList,
        .tokenTransferListSizeLimitExceeded,
        .emptyTokenTransferBody,
        .emptyTokenTransferAccountAmounts,
        .invalidScheduleID,
        .scheduleIsImmutable,
        .invalidSchedulePayerID,
        .invalidScheduleAccountID,
        .noNewValidSignatures,
        .unresolvableRequiredSigners,
        .scheduledTransactionNotInWhitelist,
        .someSignaturesWereInvalid,
        .transactionIDFieldNotAllowed,
        .identicalScheduleAlreadyCreated,
        .invalidZeroByteInString,
        .scheduleAlreadyDeleted,
        .scheduleAlreadyExecuted,
        .messageSizeTooLarge,
        .operationRepeatedInBucketGroups,
        .bucketCapacityOverflow,
        .nodeCapacityNotSufficientForOperation,
        .bucketHasNoThrottleGroups,
        .throttleGroupHasZeroOpsPerSec,
        .successButMissingExpectedOperation,
        .unparseableThrottleDefinitions,
        .invalidThrottleDefinitions,
        .accountExpiredAndPendingRemoval,
        .invalidTokenMaxSupply,
        .invalidTokenNftSerialNumber,
        .invalidNftID,
        .metadataTooLong,
        .batchSizeLimitExceeded,
        .invalidQueryRange,
        .fractionDividesByZero,
        .insufficientPayerBalanceForCustomFee,
        .customFeesListTooLong,
        .invalidCustomFeeCollector,
        .invalidTokenIDInCustomFees,
        .tokenNotAssociatedToFeeCollector,
        .tokenMaxSupplyReached,
        .senderDoesNotOwnNftSerialNo,
        .customFeeNotFullySpecified,
        .customFeeMustBePositive,
        .tokenHasNoFeeScheduleKey,
        .customFeeOutsideNumericRange,
        .royaltyFractionCannotExceedOne,
        .fractionalFeeMaxAmountLessThanMinAmount,
        .customScheduleAlreadyHasNoFees,
        .customFeeDenominationMustBeFungibleCommon,
        .customFractionalFeeOnlyAllowedForFungibleCommon,
        .invalidCustomFeeScheduleKey,
        .invalidTokenMintMetadata,
        .invalidTokenBurnMetadata,
        .currentTreasuryStillOwnsNfts,
        .accountStillOwnsNfts,
        .treasuryMustOwnBurnedNft,
        .accountDoesNotOwnWipedNft,
        .accountAmountTransfersOnlyAllowedForFungibleCommon,
        .maxNftsInPriceRegimeHaveBeenMinted,
        .payerAccountDeleted,
        .customFeeChargingExceededMaxRecursionDepth,
        .customFeeChargingExceededMaxAccountAmounts,
        .insufficientSenderAccountBalanceForCustomFee,
        .serialNumberLimitReached,
        .customRoyaltyFeeOnlyAllowedForNonFungibleUnique,
        .noRemainingAutomaticAssociations,
        .existingAutomaticAssociationsExceedGivenLimit,
        .requestedNumAutomaticAssociationsExceedsAssociationLimit,
        .tokenIsPaused,
        .tokenHasNoPauseKey,
        .invalidPauseKey,
        .freezeUpdateFileDoesNotExist,
        .freezeUpdateFileHashDoesNotMatch,
        .noUpgradeHasBeenPrepared,
        .noFreezeIsScheduled,
        .updateFileHashChangedSincePrepareUpgrade,
        .freezeStartTimeMustBeFuture,
        .preparedUpdateFileIsImmutable,
        .freezeAlreadyScheduled,
        .freezeUpgradeInProgress,
        .updateFileIDDoesNotMatchPrepared,
        .updateFileHashDoesNotMatchPrepared,
        .consensusGasExhausted,
        .revertedSuccess,
        .maxStorageInPriceRegimeHasBeenUsed,
        .invalidAliasKey,
        .unexpectedTokenDecimals,
        .invalidProxyAccountID,
        .invalidTransferAccountID,
        .invalidFeeCollectorAccountID,
        .aliasIsImmutable,
        .spenderAccountSameAsOwner,
        .amountExceedsTokenMaxSupply,
        .negativeAllowanceAmount,
        .cannotApproveForAllFungibleCommon,
        .spenderDoesNotHaveAllowance,
        .amountExceedsAllowance,
        .maxAllowancesExceeded,
        .emptyAllowances,
        .spenderAccountRepeatedInAllowances,
        .repeatedSerialNumsInNftAllowances,
        .fungibleTokenInNftAllowances,
        .nftInFungibleTokenAllowances,
        .invalidAllowanceOwnerID,
        .invalidAllowanceSpenderID,
        .repeatedAllowancesToDelete,
        .invalidDelegatingSpender,
        .delegatingSpenderCannotGrantApproveForAll,
        .delegatingSpenderDoesNotHaveApproveForAll,
        .scheduleExpirationTimeTooFarInFuture,
        .scheduleExpirationTimeMustBeHigherThanConsensusTime,
        .scheduleFutureThrottleExceeded,
        .scheduleFutureGasLimitExceeded,
        .invalidEthereumTransaction,
        .wrongChainID,
        .wrongNonce,
        .accessListUnsupported,
        .schedulePendingExpiration,
        .contractIsTokenTreasury,
        .contractHasNonZeroTokenBalances,
        .contractExpiredAndPendingRemoval,
        .contractHasNoAutoRenewAccount,
        .permanentRemovalRequiresSystemInitiation,
        .proxyAccountIDFieldIsDeprecated,
        .selfStakingIsNotAllowed,
        .invalidStakingID,
        .stakingNotEnabled,
        .invalidPrngRange,
        .maxEntitiesInPriceRegimeHaveBeenCreated,
        .invalidFullPrefixSignatureForPrecompile,
        .insufficientBalancesForStorageRent,
        .maxChildRecordsExceeded,
        .insufficientBalancesForRenewalFees,
        .transactionHasUnknownFields,
        .accountIsImmutable,
        .aliasAlreadyAssigned,
        .invalidMetadataKey,
        .tokenHasNoMetadataKey,
        .missingTokenMetadata,
        .missingSerialNumbers,
        .tokenHasNoAdminKey,
        .nodeDeleted,
        .invalidNodeID,
        .invalidGossipEndpoint,
        .invalidNodeAccountID,
        .invalidNodeDescription,
        .invalidServiceEndpoint,
        .invalidGossipCaCertificate,
        .invalidGrpcCertificate,
        .invalidMaxAutoAssociations,
        .maxNodesCreated,
        .ipFqdnCannotBeSetForSameEndpoint,
        .gossipEndpointCannotHaveFqdn,
        .fqdnSizeTooLarge,
        .invalidEndpoint,
        .gossipEndpointsExceededLimit,
        .tokenReferenceRepeated,
        .invalidOwnerID,
        .tokenReferenceListSizeLimitExceeded,
        .serviceEndpointsExceededLimit,
        .invalidIpv4Address,
        .emptyTokenReferenceList,
        .updateNodeAccountNotAllowed,
        .tokenHasNoMetadataOrSupplyKey,
        .emptyPendingAirdropIdList,
        .pendingAirdropIdRepeated,
        .pendingAirdropIdListTooLong,
        .pendingNftAirdropAlreadyExists,
        .accountHasPendingAirdrops,
        .throttledAtConsensus,
        .invalidPendingAirdropId,
        .tokenAirdropWithFallbackRoyalty,
        .invalidTokenInPendingAirdrop,
        .scheduleExpiryIsBusy,
        .invalidGrpcCertificateHash,
        .missingExpiryTime,
        .noSchedulingAllowedAfterScheduledRecursion,
        .recursiveSchedulingLimitReached,
        .waitingForLedgerID,
        .maxEntriesForFeeExemptKeyListExceeded,
        .feeExemptKeyListContainsDuplicatedKeys,
        .invalidKeyInFeeExemptKeyList,
        .invalidFeeScheduleKey,
        .feeScheduleKeyCannotBeUpdated,
        .feeScheduleKeyNotSet,
        .maxCustomFeeLimitExceeded,
        .noValidMaxCustomFee,
        .invalidMaxCustomFees,
        .duplicateDenominationInMaxCustomFeeList,
        .duplicateAccountIDInMaxCustomFeeList,
        .maxCustomFeesIsNotSupported,
        .batchListEmpty,
        .batchListContainsDuplicates,
        .batchTransactionInBlacklist,
        .innerTransactionFailed,
        .missingBatchKey,
        .batchKeySetOnNonInnerTransaction,
        .invalidBatchKey,
        .scheduleExpiryNotConfigurable,
        .creatingSystemEntities,
        .throttleGroupLcmOverflow,
        .airdropContainsMultipleSendersForAToken,
        .grpcWebProxyNotSupported,
        .nftTransfersOnlyAllowedForNonFungibleUnique,
        .invalidSerializedTxMessageHashAlgorithm,
        .wrongHookEntityType,
        .evmHookGasThrottled,
        .hookIDInUse,
        .badHookRequest,
        .rejectedByAccountAllowanceHook,
        .hookNotFound,
        .evmHookStorageUpdateBytesTooLong,
        .evmHookStorageUpdateBytesMustUseMinimalRepresentation,
        .invalidHookID,
        .emptyEvmHookStorageUpdate,
        .hookIDRepeatedInCreationDetails,
        .hooksNotEnabled,
        .hookIsNotAnEvmHook,
        .hookDeleted,
        .tooManyEvmHookStorageUpdates,
        .hookCreationBytesMustUseMinimalRepresentation,
        .hookCreationBytesTooLong,
        .invalidHookCreationSpec,
        .hookExtensionEmpty,
        .invalidHookAdminKey,
        .hookDeletionRequiresZeroStorageSlots,
        .cannotSetHooksAndApproval,
        .transactionRequiresZeroHooks,
        .invalidHookCall,
        .hooksAreNotSupportedInAirdrops,
        .accountIsLinkedToANode,
        .hooksExecutionsRequireTopLevelCryptoTransfer,
        .nodeAccountHasZeroBalance,
        .transferToFeeCollectionAccountNotAllowed,
        .tooManyHookInvocations,
        .invalidRegisteredNodeID,
        .invalidRegisteredEndpoint,
        .registeredEndpointsExceededLimit,
        .invalidRegisteredEndpointAddress,
        .invalidRegisteredEndpointType,
        .registeredNodeStillAssociated,
        .maxRegisteredNodesExceeded,
    ]
}

// minimal edit from proto-generated file:
extension Status {
    internal static let nameMap: NameMap =
        [
            0: "OK",
            1: "INVALID_TRANSACTION",
            2: "PAYER_ACCOUNT_NOT_FOUND",
            3: "INVALID_NODE_ACCOUNT",
            4: "TRANSACTION_EXPIRED",
            5: "INVALID_TRANSACTION_START",
            6: "INVALID_TRANSACTION_DURATION",
            7: "INVALID_SIGNATURE",
            8: "MEMO_TOO_LONG",
            9: "INSUFFICIENT_TX_FEE",
            10: "INSUFFICIENT_PAYER_BALANCE",
            11: "DUPLICATE_TRANSACTION",
            12: "BUSY",
            13: "NOT_SUPPORTED",
            14: "INVALID_FILE_ID",
            15: "INVALID_ACCOUNT_ID",
            16: "INVALID_CONTRACT_ID",
            17: "INVALID_TRANSACTION_ID",
            18: "RECEIPT_NOT_FOUND",
            19: "RECORD_NOT_FOUND",
            20: "INVALID_SOLIDITY_ID",
            21: "UNKNOWN",
            22: "SUCCESS",
            23: "FAIL_INVALID",
            24: "FAIL_FEE",
            25: "FAIL_BALANCE",
            26: "KEY_REQUIRED",
            27: "BAD_ENCODING",
            28: "INSUFFICIENT_ACCOUNT_BALANCE",
            29: "INVALID_SOLIDITY_ADDRESS",
            30: "INSUFFICIENT_GAS",
            31: "CONTRACT_SIZE_LIMIT_EXCEEDED",
            32: "LOCAL_CALL_MODIFICATION_EXCEPTION",
            33: "CONTRACT_REVERT_EXECUTED",
            34: "CONTRACT_EXECUTION_EXCEPTION",
            35: "INVALID_RECEIVING_NODE_ACCOUNT",
            36: "MISSING_QUERY_HEADER",
            37: "ACCOUNT_UPDATE_FAILED",
            38: "INVALID_KEY_ENCODING",
            39: "NULL_SOLIDITY_ADDRESS",
            40: "CONTRACT_UPDATE_FAILED",
            41: "INVALID_QUERY_HEADER",
            42: "INVALID_FEE_SUBMITTED",
            43: "INVALID_PAYER_SIGNATURE",
            44: "KEY_NOT_PROVIDED",
            45: "INVALID_EXPIRATION_TIME",
            46: "NO_WACL_KEY",
            47: "FILE_CONTENT_EMPTY",
            48: "INVALID_ACCOUNT_AMOUNTS",
            49: "EMPTY_TRANSACTION_BODY",
            50: "INVALID_TRANSACTION_BODY",
            51: "INVALID_SIGNATURE_TYPE_MISMATCHING_KEY",
            52: "INVALID_SIGNATURE_COUNT_MISMATCHING_KEY",
            53: "EMPTY_LIVE_HASH_BODY",
            54: "EMPTY_LIVE_HASH",
            55: "EMPTY_LIVE_HASH_KEYS",
            56: "INVALID_LIVE_HASH_SIZE",
            57: "EMPTY_QUERY_BODY",
            58: "EMPTY_LIVE_HASH_QUERY",
            59: "LIVE_HASH_NOT_FOUND",
            60: "ACCOUNT_ID_DOES_NOT_EXIST",
            61: "LIVE_HASH_ALREADY_EXISTS",
            62: "INVALID_FILE_WACL",
            63: "SERIALIZATION_FAILED",
            64: "TRANSACTION_OVERSIZE",
            65: "TRANSACTION_TOO_MANY_LAYERS",
            66: "CONTRACT_DELETED",
            67: "PLATFORM_NOT_ACTIVE",
            68: "KEY_PREFIX_MISMATCH",
            69: "PLATFORM_TRANSACTION_NOT_CREATED",
            70: "INVALID_RENEWAL_PERIOD",
            71: "INVALID_PAYER_ACCOUNT_ID",
            72: "ACCOUNT_DELETED",
            73: "FILE_DELETED",
            74: "ACCOUNT_REPEATED_IN_ACCOUNT_AMOUNTS",
            75: "SETTING_NEGATIVE_ACCOUNT_BALANCE",
            76: "OBTAINER_REQUIRED",
            77: "OBTAINER_SAME_CONTRACT_ID",
            78: "OBTAINER_DOES_NOT_EXIST",
            79: "MODIFYING_IMMUTABLE_CONTRACT",
            80: "FILE_SYSTEM_EXCEPTION",
            81: "AUTORENEW_DURATION_NOT_IN_RANGE",
            82: "ERROR_DECODING_BYTESTRING",
            83: "CONTRACT_FILE_EMPTY",
            84: "CONTRACT_BYTECODE_EMPTY",
            85: "INVALID_INITIAL_BALANCE",
            86: "INVALID_RECEIVE_RECORD_THRESHOLD",
            87: "INVALID_SEND_RECORD_THRESHOLD",
            88: "ACCOUNT_IS_NOT_GENESIS_ACCOUNT",
            89: "PAYER_ACCOUNT_UNAUTHORIZED",
            90: "INVALID_FREEZE_TRANSACTION_BODY",
            91: "FREEZE_TRANSACTION_BODY_NOT_FOUND",
            92: "TRANSFER_LIST_SIZE_LIMIT_EXCEEDED",
            93: "RESULT_SIZE_LIMIT_EXCEEDED",
            94: "NOT_SPECIAL_ACCOUNT",
            95: "CONTRACT_NEGATIVE_GAS",
            96: "CONTRACT_NEGATIVE_VALUE",
            97: "INVALID_FEE_FILE",
            98: "INVALID_EXCHANGE_RATE_FILE",
            99: "INSUFFICIENT_LOCAL_CALL_GAS",
            100: "ENTITY_NOT_ALLOWED_TO_DELETE",
            101: "AUTHORIZATION_FAILED",
            102: "FILE_UPLOADED_PROTO_INVALID",
            103: "FILE_UPLOADED_PROTO_NOT_SAVED_TO_DISK",
            104: "FEE_SCHEDULE_FILE_PART_UPLOADED",
            105: "EXCHANGE_RATE_CHANGE_LIMIT_EXCEEDED",
            106: "MAX_CONTRACT_STORAGE_EXCEEDED",
            107: "TRANSFER_ACCOUNT_SAME_AS_DELETE_ACCOUNT",
            108: "TOTAL_LEDGER_BALANCE_INVALID",
            110: "EXPIRATION_REDUCTION_NOT_ALLOWED",
            111: "MAX_GAS_LIMIT_EXCEEDED",
            112: "MAX_FILE_SIZE_EXCEEDED",
            113: "RECEIVER_SIG_REQUIRED",
            150: "INVALID_TOPIC_ID",
            155: "INVALID_ADMIN_KEY",
            156: "INVALID_SUBMIT_KEY",
            157: "UNAUTHORIZED",
            158: "INVALID_TOPIC_MESSAGE",
            159: "INVALID_AUTORENEW_ACCOUNT",
            160: "AUTORENEW_ACCOUNT_NOT_ALLOWED",
            162: "TOPIC_EXPIRED",
            163: "INVALID_CHUNK_NUMBER",
            164: "INVALID_CHUNK_TRANSACTION_ID",
            165: "ACCOUNT_FROZEN_FOR_TOKEN",
            166: "TOKENS_PER_ACCOUNT_LIMIT_EXCEEDED",
            167: "INVALID_TOKEN_ID",
            168: "INVALID_TOKEN_DECIMALS",
            169: "INVALID_TOKEN_INITIAL_SUPPLY",
            170: "INVALID_TREASURY_ACCOUNT_FOR_TOKEN",
            171: "INVALID_TOKEN_SYMBOL",
            172: "TOKEN_HAS_NO_FREEZE_KEY",
            173: "TRANSFERS_NOT_ZERO_SUM_FOR_TOKEN",
            174: "MISSING_TOKEN_SYMBOL",
            175: "TOKEN_SYMBOL_TOO_LONG",
            176: "ACCOUNT_KYC_NOT_GRANTED_FOR_TOKEN",
            177: "TOKEN_HAS_NO_KYC_KEY",
            178: "INSUFFICIENT_TOKEN_BALANCE",
            179: "TOKEN_WAS_DELETED",
            180: "TOKEN_HAS_NO_SUPPLY_KEY",
            181: "TOKEN_HAS_NO_WIPE_KEY",
            182: "INVALID_TOKEN_MINT_AMOUNT",
            183: "INVALID_TOKEN_BURN_AMOUNT",
            184: "TOKEN_NOT_ASSOCIATED_TO_ACCOUNT",
            185: "CANNOT_WIPE_TOKEN_TREASURY_ACCOUNT",
            186: "INVALID_KYC_KEY",
            187: "INVALID_WIPE_KEY",
            188: "INVALID_FREEZE_KEY",
            189: "INVALID_SUPPLY_KEY",
            190: "MISSING_TOKEN_NAME",
            191: "TOKEN_NAME_TOO_LONG",
            192: "INVALID_WIPING_AMOUNT",
            193: "TOKEN_IS_IMMUTABLE",
            194: "TOKEN_ALREADY_ASSOCIATED_TO_ACCOUNT",
            195: "TRANSACTION_REQUIRES_ZERO_TOKEN_BALANCES",
            196: "ACCOUNT_IS_TREASURY",
            197: "TOKEN_ID_REPEATED_IN_TOKEN_LIST",
            198: "TOKEN_TRANSFER_LIST_SIZE_LIMIT_EXCEEDED",
            199: "EMPTY_TOKEN_TRANSFER_BODY",
            200: "EMPTY_TOKEN_TRANSFER_ACCOUNT_AMOUNTS",
            201: "INVALID_SCHEDULE_ID",
            202: "SCHEDULE_IS_IMMUTABLE",
            203: "INVALID_SCHEDULE_PAYER_ID",
            204: "INVALID_SCHEDULE_ACCOUNT_ID",
            205: "NO_NEW_VALID_SIGNATURES",
            206: "UNRESOLVABLE_REQUIRED_SIGNERS",
            207: "SCHEDULED_TRANSACTION_NOT_IN_WHITELIST",
            208: "SOME_SIGNATURES_WERE_INVALID",
            209: "TRANSACTION_ID_FIELD_NOT_ALLOWED",
            210: "IDENTICAL_SCHEDULE_ALREADY_CREATED",
            211: "INVALID_ZERO_BYTE_IN_STRING",
            212: "SCHEDULE_ALREADY_DELETED",
            213: "SCHEDULE_ALREADY_EXECUTED",
            214: "MESSAGE_SIZE_TOO_LARGE",
            215: "OPERATION_REPEATED_IN_BUCKET_GROUPS",
            216: "BUCKET_CAPACITY_OVERFLOW",
            217: "NODE_CAPACITY_NOT_SUFFICIENT_FOR_OPERATION",
            218: "BUCKET_HAS_NO_THROTTLE_GROUPS",
            219: "THROTTLE_GROUP_HAS_ZERO_OPS_PER_SEC",
            220: "SUCCESS_BUT_MISSING_EXPECTED_OPERATION",
            221: "UNPARSEABLE_THROTTLE_DEFINITIONS",
            222: "INVALID_THROTTLE_DEFINITIONS",
            223: "ACCOUNT_EXPIRED_AND_PENDING_REMOVAL",
            224: "INVALID_TOKEN_MAX_SUPPLY",
            225: "INVALID_TOKEN_NFT_SERIAL_NUMBER",
            226: "INVALID_NFT_ID",
            227: "METADATA_TOO_LONG",
            228: "BATCH_SIZE_LIMIT_EXCEEDED",
            229: "INVALID_QUERY_RANGE",
            230: "FRACTION_DIVIDES_BY_ZERO",
            231: "INSUFFICIENT_PAYER_BALANCE_FOR_CUSTOM_FEE",
            232: "CUSTOM_FEES_LIST_TOO_LONG",
            233: "INVALID_CUSTOM_FEE_COLLECTOR",
            234: "INVALID_TOKEN_ID_IN_CUSTOM_FEES",
            235: "TOKEN_NOT_ASSOCIATED_TO_FEE_COLLECTOR",
            236: "TOKEN_MAX_SUPPLY_REACHED",
            237: "SENDER_DOES_NOT_OWN_NFT_SERIAL_NO",
            238: "CUSTOM_FEE_NOT_FULLY_SPECIFIED",
            239: "CUSTOM_FEE_MUST_BE_POSITIVE",
            240: "TOKEN_HAS_NO_FEE_SCHEDULE_KEY",
            241: "CUSTOM_FEE_OUTSIDE_NUMERIC_RANGE",
            242: "ROYALTY_FRACTION_CANNOT_EXCEED_ONE",
            243: "FRACTIONAL_FEE_MAX_AMOUNT_LESS_THAN_MIN_AMOUNT",
            244: "CUSTOM_SCHEDULE_ALREADY_HAS_NO_FEES",
            245: "CUSTOM_FEE_DENOMINATION_MUST_BE_FUNGIBLE_COMMON",
            246: "CUSTOM_FRACTIONAL_FEE_ONLY_ALLOWED_FOR_FUNGIBLE_COMMON",
            247: "INVALID_CUSTOM_FEE_SCHEDULE_KEY",
            248: "INVALID_TOKEN_MINT_METADATA",
            249: "INVALID_TOKEN_BURN_METADATA",
            250: "CURRENT_TREASURY_STILL_OWNS_NFTS",
            251: "ACCOUNT_STILL_OWNS_NFTS",
            252: "TREASURY_MUST_OWN_BURNED_NFT",
            253: "ACCOUNT_DOES_NOT_OWN_WIPED_NFT",
            254: "ACCOUNT_AMOUNT_TRANSFERS_ONLY_ALLOWED_FOR_FUNGIBLE_COMMON",
            255: "MAX_NFTS_IN_PRICE_REGIME_HAVE_BEEN_MINTED",
            256: "PAYER_ACCOUNT_DELETED",
            257: "CUSTOM_FEE_CHARGING_EXCEEDED_MAX_RECURSION_DEPTH",
            258: "CUSTOM_FEE_CHARGING_EXCEEDED_MAX_ACCOUNT_AMOUNTS",
            259: "INSUFFICIENT_SENDER_ACCOUNT_BALANCE_FOR_CUSTOM_FEE",
            260: "SERIAL_NUMBER_LIMIT_REACHED",
            261: "CUSTOM_ROYALTY_FEE_ONLY_ALLOWED_FOR_NON_FUNGIBLE_UNIQUE",
            262: "NO_REMAINING_AUTOMATIC_ASSOCIATIONS",
            263: "EXISTING_AUTOMATIC_ASSOCIATIONS_EXCEED_GIVEN_LIMIT",
            264: "REQUESTED_NUM_AUTOMATIC_ASSOCIATIONS_EXCEEDS_ASSOCIATION_LIMIT",
            265: "TOKEN_IS_PAUSED",
            266: "TOKEN_HAS_NO_PAUSE_KEY",
            267: "INVALID_PAUSE_KEY",
            268: "FREEZE_UPDATE_FILE_DOES_NOT_EXIST",
            269: "FREEZE_UPDATE_FILE_HASH_DOES_NOT_MATCH",
            270: "NO_UPGRADE_HAS_BEEN_PREPARED",
            271: "NO_FREEZE_IS_SCHEDULED",
            272: "UPDATE_FILE_HASH_CHANGED_SINCE_PREPARE_UPGRADE",
            273: "FREEZE_START_TIME_MUST_BE_FUTURE",
            274: "PREPARED_UPDATE_FILE_IS_IMMUTABLE",
            275: "FREEZE_ALREADY_SCHEDULED",
            276: "FREEZE_UPGRADE_IN_PROGRESS",
            277: "UPDATE_FILE_ID_DOES_NOT_MATCH_PREPARED",
            278: "UPDATE_FILE_HASH_DOES_NOT_MATCH_PREPARED",
            279: "CONSENSUS_GAS_EXHAUSTED",
            280: "REVERTED_SUCCESS",
            281: "MAX_STORAGE_IN_PRICE_REGIME_HAS_BEEN_USED",
            282: "INVALID_ALIAS_KEY",
            283: "UNEXPECTED_TOKEN_DECIMALS",
            284: "INVALID_PROXY_ACCOUNT_ID",
            285: "INVALID_TRANSFER_ACCOUNT_ID",
            286: "INVALID_FEE_COLLECTOR_ACCOUNT_ID",
            287: "ALIAS_IS_IMMUTABLE",
            288: "SPENDER_ACCOUNT_SAME_AS_OWNER",
            289: "AMOUNT_EXCEEDS_TOKEN_MAX_SUPPLY",
            290: "NEGATIVE_ALLOWANCE_AMOUNT",
            291: "CANNOT_APPROVE_FOR_ALL_FUNGIBLE_COMMON",
            292: "SPENDER_DOES_NOT_HAVE_ALLOWANCE",
            293: "AMOUNT_EXCEEDS_ALLOWANCE",
            294: "MAX_ALLOWANCES_EXCEEDED",
            295: "EMPTY_ALLOWANCES",
            296: "SPENDER_ACCOUNT_REPEATED_IN_ALLOWANCES",
            297: "REPEATED_SERIAL_NUMS_IN_NFT_ALLOWANCES",
            298: "FUNGIBLE_TOKEN_IN_NFT_ALLOWANCES",
            299: "NFT_IN_FUNGIBLE_TOKEN_ALLOWANCES",
            300: "INVALID_ALLOWANCE_OWNER_ID",
            301: "INVALID_ALLOWANCE_SPENDER_ID",
            302: "REPEATED_ALLOWANCES_TO_DELETE",
            303: "INVALID_DELEGATING_SPENDER",
            304: "DELEGATING_SPENDER_CANNOT_GRANT_APPROVE_FOR_ALL",
            305: "DELEGATING_SPENDER_DOES_NOT_HAVE_APPROVE_FOR_ALL",
            306: "SCHEDULE_EXPIRATION_TIME_TOO_FAR_IN_FUTURE",
            307: "SCHEDULE_EXPIRATION_TIME_MUST_BE_HIGHER_THAN_CONSENSUS_TIME",
            308: "SCHEDULE_FUTURE_THROTTLE_EXCEEDED",
            309: "SCHEDULE_FUTURE_GAS_LIMIT_EXCEEDED",
            310: "INVALID_ETHEREUM_TRANSACTION",
            311: "WRONG_CHAIN_ID",
            312: "WRONG_NONCE",
            313: "ACCESS_LIST_UNSUPPORTED",
            314: "SCHEDULE_PENDING_EXPIRATION",
            315: "CONTRACT_IS_TOKEN_TREASURY",
            316: "CONTRACT_HAS_NON_ZERO_TOKEN_BALANCES",
            317: "CONTRACT_EXPIRED_AND_PENDING_REMOVAL",
            318: "CONTRACT_HAS_NO_AUTO_RENEW_ACCOUNT",
            319: "PERMANENT_REMOVAL_REQUIRES_SYSTEM_INITIATION",
            320: "PROXY_ACCOUNT_ID_FIELD_IS_DEPRECATED",
            321: "SELF_STAKING_IS_NOT_ALLOWED",
            322: "INVALID_STAKING_ID",
            323: "STAKING_NOT_ENABLED",
            324: "INVALID_PRNG_RANGE",
            325: "MAX_ENTITIES_IN_PRICE_REGIME_HAVE_BEEN_CREATED",
            326: "INVALID_FULL_PREFIX_SIGNATURE_FOR_PRECOMPILE",
            327: "INSUFFICIENT_BALANCES_FOR_STORAGE_RENT",
            328: "MAX_CHILD_RECORDS_EXCEEDED",
            329: "INSUFFICIENT_BALANCES_FOR_RENEWAL_FEES",
            330: "TRANSACTION_HAS_UNKNOWN_FIELDS",
            331: "ACCOUNT_IS_IMMUTABLE",
            332: "ALIAS_ALREADY_ASSIGNED",
            333: "INVALID_METADATA_KEY",
            334: "TOKEN_HAS_NO_METADATA_KEY",
            335: "MISSING_TOKEN_METADATA",
            336: "MISSING_SERIAL_NUMBERS",
            337: "TOKEN_HAS_NO_ADMIN_KEY",
            338: "NODE_DELETED",
            339: "INVALID_NODE_ID",
            340: "INVALID_GOSSIP_ENDPOINT",
            341: "INVALID_NODE_ACCOUNT_ID",
            342: "INVALID_NODE_DESCRIPTION",
            343: "INVALID_SERVICE_ENDPOINT",
            344: "INVALID_GOSSIP_CA_CERTIFICATE",
            345: "INVALID_GRPC_CERTIFICATE",
            346: "INVALID_MAX_AUTO_ASSOCIATIONS",
            347: "MAX_NODES_CREATED",
            348: "IP_FQDN_CANNOT_BE_SET_FOR_SAME_ENDPOINT",
            349: "GOSSIP_ENDPOINT_CANNOT_HAVE_FQDN",
            350: "FQDN_SIZE_TOO_LARGE",
            351: "INVALID_ENDPOINT",
            352: "GOSSIP_ENDPOINTS_EXCEEDED_LIMIT",
            353: "TOKEN_REFERENCE_REPEATED",
            354: "INVALID_OWNER_ID",
            355: "TOKEN_REFERENCE_LIST_SIZE_LIMIT_EXCEEDED",
            356: "SERVICE_ENDPOINTS_EXCEEDED_LIMIT",
            357: "INVALID_IPV4_ADDRESS",
            358: "EMPTY_TOKEN_REFERENCE_LIST",
            359: "UPDATE_NODE_ACCOUNT_NOT_ALLOWED",
            360: "TOKEN_HAS_NO_METADATA_OR_SUPPLY_KEY",
            361: "EMPTY_PENDING_AIRDROP_ID_LIST",
            362: "PENDING_AIRDROP_ID_REPEATED",
            363: "PENDING_AIRDROP_ID_LIST_TOO_LONG",
            364: "PENDING_NFT_AIRDROP_ALREADY_EXISTS",
            365: "ACCOUNT_HAS_PENDING_AIRDROPS",
            366: "THROTTLED_AT_CONSENSUS",
            367: "INVALID_PENDING_AIRDROP_ID",
            368: "TOKEN_AIRDROP_WITH_FALLBACK_ROYALTY",
            369: "INVALID_TOKEN_IN_PENDING_AIRDROP",
            370: "SCHEDULE_EXPIRY_IS_BUSY",
            371: "INVALID_GRPC_CERTIFICATE_HASH",
            372: "MISSING_EXPIRY_TIME",
            373: "NO_SCHEDULING_ALLOWED_AFTER_SCHEDULED_RECURSION",
            374: "RECURSIVE_SCHEDULING_LIMIT_REACHED",
            375: "WAITING_FOR_LEDGER_ID",
            376: "MAX_ENTRIES_FOR_FEE_EXEMPT_KEY_LIST_EXCEEDED",
            377: "FEE_EXEMPT_KEY_LIST_CONTAINS_DUPLICATED_KEYS",
            378: "INVALID_KEY_IN_FEE_EXEMPT_KEY_LIST",
            379: "INVALID_FEE_SCHEDULE_KEY",
            380: "FEE_SCHEDULE_KEY_CANNOT_BE_UPDATED",
            381: "FEE_SCHEDULE_KEY_NOT_SET",
            382: "MAX_CUSTOM_FEE_LIMIT_EXCEEDED",
            383: "NO_VALID_MAX_CUSTOM_FEE",
            384: "INVALID_MAX_CUSTOM_FEES",
            385: "DUPLICATE_DENOMINATION_IN_MAX_CUSTOM_FEE_LIST",
            386: "DUPLICATE_ACCOUNT_ID_IN_MAX_CUSTOM_FEE_LIST",
            387: "MAX_CUSTOM_FEES_IS_NOT_SUPPORTED",
            388: "BATCH_LIST_EMPTY",
            389: "BATCH_LIST_CONTAINS_DUPLICATES",
            390: "BATCH_TRANSACTION_IN_BLACKLIST",
            391: "INNER_TRANSACTION_FAILED",
            392: "MISSING_BATCH_KEY",
            393: "BATCH_KEY_SET_ON_NON_INNER_TRANSACTION",
            394: "INVALID_BATCH_KEY",
            395: "SCHEDULE_EXPIRY_NOT_CONFIGURABLE",
            396: "CREATING_SYSTEM_ENTITIES",
            397: "THROTTLE_GROUP_LCM_OVERFLOW",
            398: "AIRDROP_CONTAINS_MULTIPLE_SENDERS_FOR_A_TOKEN",
            399: "GRPC_WEB_PROXY_NOT_SUPPORTED",
            400: "NFT_TRANSFERS_ONLY_ALLOWED_FOR_NON_FUNGIBLE_UNIQUE",
            401: "INVALID_SERIALIZED_TX_MESSAGE_HASH_ALGORITHM",
            499: "WRONG_HOOK_ENTITY_TYPE",
            500: "EVM_HOOK_GAS_THROTTLED",
            501: "HOOK_ID_IN_USE",
            502: "BAD_HOOK_REQUEST",
            503: "REJECTED_BY_ACCOUNT_ALLOWANCE_HOOK",
            504: "HOOK_NOT_FOUND",
            505: "EVM_HOOK_STORAGE_UPDATE_BYTES_TOO_LONG",
            506: "EVM_HOOK_STORAGE_UPDATE_BYTES_MUST_USE_MINIMAL_REPRESENTATION",
            507: "INVALID_HOOK_ID",
            508: "EMPTY_EVM_HOOK_STORAGE_UPDATE",
            509: "HOOK_ID_REPEATED_IN_CREATION_DETAILS",
            510: "HOOKS_NOT_ENABLED",
            511: "HOOK_IS_NOT_AN_EVM_HOOK",
            512: "HOOK_DELETED",
            513: "TOO_MANY_EVM_HOOK_STORAGE_UPDATES",
            514: "HOOK_CREATION_BYTES_MUST_USE_MINIMAL_REPRESENTATION",
            515: "HOOK_CREATION_BYTES_TOO_LONG",
            516: "INVALID_HOOK_CREATION_SPEC",
            517: "HOOK_EXTENSION_EMPTY",
            518: "INVALID_HOOK_ADMIN_KEY",
            519: "HOOK_DELETION_REQUIRES_ZERO_STORAGE_SLOTS",
            520: "CANNOT_SET_HOOKS_AND_APPROVAL",
            521: "TRANSACTION_REQUIRES_ZERO_HOOKS",
            522: "INVALID_HOOK_CALL",
            523: "HOOKS_ARE_NOT_SUPPORTED_IN_AIRDROPS",
            524: "ACCOUNT_IS_LINKED_TO_A_NODE",
            525: "HOOKS_EXECUTIONS_REQUIRE_TOP_LEVEL_CRYPTO_TRANSFER",
            526: "NODE_ACCOUNT_HAS_ZERO_BALANCE",
            527: "TRANSFER_TO_FEE_COLLECTION_ACCOUNT_NOT_ALLOWED",
            528: "TOO_MANY_HOOK_INVOCATIONS",
            529: "INVALID_REGISTERED_NODE_ID",
            530: "INVALID_REGISTERED_ENDPOINT",
            531: "REGISTERED_ENDPOINTS_EXCEEDED_LIMIT",
            532: "INVALID_REGISTERED_ENDPOINT_ADDRESS",
            533: "INVALID_REGISTERED_ENDPOINT_TYPE",
            534: "REGISTERED_NODE_STILL_ASSOCIATED",
            535: "MAX_REGISTERED_NODES_EXCEEDED",
        ]
}

extension Status: Sendable {}
